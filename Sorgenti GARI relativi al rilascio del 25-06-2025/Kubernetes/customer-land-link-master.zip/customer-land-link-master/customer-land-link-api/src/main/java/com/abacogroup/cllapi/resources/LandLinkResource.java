package com.abacogroup.cllapi.resources;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.cllapi.api.LandLinkAnomaliesRes;
import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.api.LandLinkSectorSummaryRes;
import com.abacogroup.cllapi.api.req.LandLinkBulkCloseReq;
import com.abacogroup.cllapi.api.req.LandLinkCloseReq;
import com.abacogroup.cllapi.api.req.LandLinkSearchReq;
import com.abacogroup.cllapi.api.req.LandLinkUpdateReq;
import com.abacogroup.cllapi.core.LandLinkService;
import com.abacogroup.cllapi.exceptions.GroupException;
import com.abacogroup.cllapi.exceptions.GroupException.ErrEnum;
import com.abacogroup.cllapi.exceptions.LandLinkException;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.common.resources.ResourceConstants;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.SchemaProperty;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path(ResourceConstants.API_PRIV + "/parties/{partyId}/land-links")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Land Links", description = "Operations on land links")
public class LandLinkResource {

	private final LandLinkService landLinkService;

	public LandLinkResource(LandLinkService landLinkService) {
		this.landLinkService = landLinkService;
	}

	@GET
	@Path("/summary")
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Operation(description = "Get land links summary by sector and title", summary = "land links summary")
	@ApiResponse(responseCode = "200", description = "Get the list of sector land link summary", useReturnTypeSchema = true)
	public List<LandLinkSectorSummaryRes> getLandLinkSummary(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party ID") @PathParam("partyId") Long partyId
	) {

		return landLinkService.getSummary(new ReqContext(user, lang), partyId);
	}

	@GET
	@Path("/{referenceDate}")
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Operation(description = "Get the list of filtered land links.  *MOCK parameters are ignored by server*", summary = "search land links")
	@ApiResponse(responseCode = "200", description = "Get the list of filtered land links", useReturnTypeSchema = true)
	public InfiniteListResults<LandLinkRes> searchLandLinks(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "reference date", schema = @Schema(format = AbsoluteDate.DATE_PATTERN))
			@PathParam("referenceDate") @Size(min = 8, max = 8) String referenceDate,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
			@BeanParam @Valid LandLinkSearchReq searchReq) {


		return landLinkService.search(new ReqContext(user, lang), AbsoluteDate.of(referenceDate), searchReq, true, nextKey, null);
	}

	@GET
	@Path("/{referenceDate}/count")
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Operation(description = "Get the total size of filtered land links", summary = "get total size of land links")
	@ApiResponse(responseCode = "200", description = "Get total the size of filtered land links", useReturnTypeSchema = true)
	public int countAllFilteredLandLinks(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "reference date", schema = @Schema(format = AbsoluteDate.DATE_PATTERN))
			@PathParam("referenceDate") @Size(min = 8, max = 8) String referenceDate,
			@BeanParam @Valid LandLinkSearchReq searchReq) {

		return landLinkService.countAllForSearch(new ReqContext(user, lang), AbsoluteDate.of(referenceDate), searchReq);
	}

	@GET
	@Path("/{referenceDate}/{landLinkId}")
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Operation(description = "Get land link by id", summary = "get land link detail")
	@ApiResponse(responseCode = "200", description = "land link found", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "land link not found", content = @Content(mediaType = MediaType.APPLICATION_JSON,
			schema = @Schema(implementation = LandLinkException.ErrorBody.class)))
	public LandLinkRes getLandLink(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "reference date", schema = @Schema(format = AbsoluteDate.DATE_PATTERN))
			@PathParam("referenceDate") @Size(min = 8, max = 8) String referenceDate,
			@Parameter(description = "land link id") @PathParam("landLinkId") Long landLinkId) {

		ReqContext reqContext = new ReqContext(user, lang);
		return landLinkService.getRes(reqContext, AbsoluteDate.of(referenceDate), partyId, landLinkId);
	}

	@GET
	@Path("/{referenceDate}/{landLinkId}/anomalies")
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Operation(description = "Get land link anomalies by id", summary = "get land link anomalies grouped by level")
	@ApiResponse(responseCode = "200", description = "land link anomalies", content = @Content(schema = @Schema(type = "object"),
			schemaProperties = {
					@SchemaProperty(name = "INFO", schema = @Schema(implementation = AnomalySearchResponse.class)),
					@SchemaProperty(name = "WARN", schema = @Schema(implementation = AnomalySearchResponse.class)),
					@SchemaProperty(name = "DANGER", schema = @Schema(implementation = AnomalySearchResponse.class)),
			}, mediaType = MediaType.APPLICATION_JSON))
	@ApiResponse(responseCode = "400", description = "land link not found", content = @Content(mediaType = MediaType.APPLICATION_JSON,
			schema = @Schema(implementation = LandLinkException.ErrorBody.class)))
	public LandLinkAnomaliesRes getLandLinkAnomalies(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "reference date", schema = @Schema(format = AbsoluteDate.DATE_PATTERN))
			@PathParam("referenceDate") @Size(min = 8, max = 8) String referenceDate,
			@Parameter(description = "land link id") @PathParam("landLinkId") Long landLinkId) {

		ReqContext reqContext = new ReqContext(user, lang);
		return landLinkService.getAnomalies(reqContext, AbsoluteDate.of(referenceDate), partyId, landLinkId);
	}

	@PUT
	@Path("/{landLinkId}")
	@RolesAllowed("CUSTOMER_LAND_LINK|WRITE")
	@Operation(description = "update land link title type percentage", summary = "update land link")
	@ApiResponse(responseCode = "200", description = "Get the updated land link", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "land link not found or closed", content = @Content(mediaType = MediaType.APPLICATION_JSON,
			schema = @Schema(implementation = LandLinkException.ErrorBody.class)))
	public LandLinkRes updateLandLink(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "land link id") @PathParam("landLinkId") Long landLinkId,
			@Valid LandLinkUpdateReq updateReq) {

		return landLinkService.update(new ReqContext(user, lang), partyId, landLinkId, updateReq);
	}

	@PUT
	@Path("/{landLinkId}/day-to")
	@RolesAllowed("CUSTOMER_LAND_LINK|WRITE")
	@Operation(description = "Close a land link", summary = "close land link")
	@ApiResponse(responseCode = "200", description = "Close a specific land link by Id")
	public Response closeLandLink(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "land link id") @PathParam("landLinkId") Long id,
			@NotNull @Valid LandLinkCloseReq closeReq) {

		ReqContext reqContext = new ReqContext(user, lang);

		landLinkService.closeOne(reqContext, partyId, id, closeReq.getDayTo());

		return Response.ok(Map.of()).build();
	}

	@PUT
	@Path("/day-to")
	@RolesAllowed("CUSTOMER_LAND_LINK|WRITE")
	@Operation(summary = "close land links", description = "Close many land links at same day. not existing and already closed links are ignored")
	@ApiResponse(responseCode = "200", description = "land links closed successfully")
	@ApiResponse(responseCode = "400", description = "invalid range date", content = @Content(mediaType = MediaType.APPLICATION_JSON,
			schema = @Schema(implementation = LandLinkException.ErrorBody.class)))
	public Response closeManyLandLinks(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@NotNull @Valid LandLinkBulkCloseReq closeReq) {

		if (closeReq.getLandLinkIds().stream().anyMatch(Objects::isNull)) {
			throw new GroupException(ErrEnum.EMPTY_GROUP, "one or more element is 'null'");
		}

		ReqContext reqContext = new ReqContext(user, lang);
		landLinkService.closeMany(reqContext, partyId, closeReq.getLandLinkIds(), closeReq.getDayTo());
		return Response.ok(Map.of()).build();
	}

}
