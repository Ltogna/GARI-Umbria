package com.abacogroup.cllapi.bundle.config;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.cllapi.api.enums.DocTypeRelationScope;
import com.abacogroup.cllapi.bundle.BundleConstants;
import com.abacogroup.cllapi.bundle.config.i18n.I18nAware;
import com.abacogroup.cllapi.bundle.config.i18n.I18nEntry;
import com.abacogroup.cllapi.bundle.config.i18n.I18nHelper;
import com.abacogroup.cllapi.bundle.config.i18n.I18nMap;
import com.abacogroup.cllapi.db.dao.DocTypeRelationDAO;
import com.abacogroup.cllapi.db.dao.I18nDAO;
import com.abacogroup.cllapi.db.dao.TitleTypeDAO;
import com.abacogroup.cllapi.db.ntt.DocTypeRelationEntity;
import com.abacogroup.common.service.AuditHelper;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.dynamicdocuments.services.SavedDocumentType;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DynamicDocConfigMessageProcessor implements ConfigMessageProcessor {

	private final TitleTypeDAO titleTypeDAO;
	private final DocTypeRelationDAO docTypeRelationDAO;
	private final DocumentTypeService documentTypeService;
	private final I18nHelper i18nHelper;

	private final ObjectMapper objectMapper = new ObjectMapper().disable(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES);

	public DynamicDocConfigMessageProcessor(TitleTypeDAO titleTypeDAO, DocTypeRelationDAO docTypeRelationDAO, DocumentTypeService documentTypeService,
			I18nDAO i18nDAO) {
		this.titleTypeDAO = titleTypeDAO;
		this.docTypeRelationDAO = docTypeRelationDAO;
		this.documentTypeService = documentTypeService;
		this.i18nHelper = new I18nHelper(i18nDAO);
	}

	@Override
	public String getDomainName() {
		return BundleConstants.DOMAIN_DYNAMIC_DOCUMENTS;
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();

		List<Path> paths = message.getConfigFiles();
		var map = paths.stream()
				.filter(p -> FilenameUtils.isExtension(p.getFileName().toString(), "json"))
				.collect(Collectors.groupingBy(x -> {
					if (StringUtils.startsWithIgnoreCase(x.getFileName().toString(), "settings")) {
						if (StringUtils.containsIgnoreCase(x.getFileName().toString(), "delete")) {
							return "delete";
						} else {
							return "settings";
						}
					} else {
						return "DD";
					}
				},
						Collectors.toCollection(ArrayList::new)));

		map.getOrDefault("delete", new ArrayList<>()).forEach(path -> this.deleteSettings(tenantId, path));
		map.getOrDefault("DD", new ArrayList<>()).forEach(path -> this.saveDocumentType(tenantId, path));
		map.getOrDefault("settings", new ArrayList<>()).forEach(path -> this.saveSettings(tenantId, path));
	}

	private void saveSettings(String tenantId, Path path) {
		log.info("processing DD settings from bundle file: {}", path);
		try {
			List<DDocSettingEntry> settings = readFile(path);
			// save the docType relations
			saveDocTypeRelations(tenantId, settings);

		} catch (Exception e) {
			throw new BundleException(String.format("error processing DD settings from bundle file '%s': '%s'", path, e.getMessage()), e);
		}
	}

	private void deleteSettings(String tenantId, Path path) {
		try {

			List<DDocSettingEntry> settings = readFile(path);

			// expire the docType relations
			deleteDocTypeRelations(tenantId, settings);

		} catch (Exception e) {
			throw new BundleException(String.format("error processing DD settings from bundle file '%s': '%s'", path, e.getMessage()), e);
		}
	}

	private SavedDocumentType saveDocumentType(String tenantId, Path path) {
		log.info("processing DD from bundle file: {}", path);
		try {
			String jsonContent = Files.readString(path);

			return documentTypeService.saveDocumentType(tenantId, jsonContent, BundleConstants.SYSTEM_USER);
		} catch (IOException e) {
			throw new BundleException(String.format("error saving %s", path), e);
		}
	}

	private void deleteDocTypeRelations(String tenantId, List<DDocSettingEntry> settings) {
		settings.stream().forEach(relation -> docTypeRelationDAO.useTransaction(handle -> {
			Long titleTypeId = null;
			if(relation.getTitleType() != null) {
				titleTypeId = titleTypeDAO.findByCode(tenantId, relation.getTitleType()).orElseThrow(
						() -> new BundleException(
								String.format("the relation to be deleted contains a title type %s that does not exist", relation.getTitleType())))
						.getId();
			}
			handle.findByTitleTypeScopeCodeAndDefCode(tenantId, titleTypeId, relation.getScopeCode(), relation.getDefinitionCode())
			.ifPresentOrElse(e -> {
				Consumer<DocTypeRelationEntity> expireFun = handle::expireRow;
				AuditHelper.expire(e, BundleConstants.SYSTEM_USER, expireFun, handle.getCurrentTimestamp());
			},
					() -> log.warn("cannot remove docTypeRelation not found for definition {} and titleCode {} !",
							relation.getDefinitionCode(), relation.getTitleType()));
		}));
	}

	private void saveDocTypeRelations(String tenantId, List<DDocSettingEntry> entries) {
		entries.forEach(entry -> {
			DocumentDefinition documentDefinition = this.getDocumentDefinition(tenantId, entry.getDefinitionCode());
			// restore fk ids
			Long titleTypeId = null;
			if(entry.getTitleType() != null) {
				titleTypeId = titleTypeDAO.findByCode(tenantId, entry.getTitleType()).orElseThrow(
						() -> new BundleException(String.format("title type : %s  does not exist", entry.getTitleType())))
						.getId();
			}

			DocTypeRelationEntity entity = DocTypeRelationEntity.builder()
					.setTenantId(tenantId)
					.setDefinitionCode(documentDefinition.getCode())
					.setTitleTypeId(titleTypeId)
					.setFlRequired(entry.isRequired() ? 1 : 0)
					.setFlReqOnAdd(entry.isReqOnAdd() ? 1 : 0)
					.setFlReqOnClose(entry.isReqOnClose() ? 1 : 0)
					.setScopeCode(entry.getScopeCode())
					.build();

			docTypeRelationDAO.findByTitleTypeScopeCodeAndDefCode(tenantId, titleTypeId, entity.getScopeCode(), entity.getDefinitionCode())
			.ifPresent(e -> AuditHelper.expire(e, BundleConstants.SYSTEM_USER, docTypeRelationDAO::expireRow, 
					docTypeRelationDAO.getCurrentTimestamp()));
			AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, docTypeRelationDAO, entity);
			docTypeRelationDAO.insert(entity);	
		});

		this.processI18N(tenantId, entries);
	}

	private void processI18N(String tenantId, List<DDocSettingEntry> entries) {
		List<String> definitionCodes = entries.stream()
				.map(e -> e.getDefinitionCode())
				.distinct()
				.collect(Collectors.toList());

		definitionCodes.stream()
		.map(e -> this.getDocumentDefinition(tenantId, e))
		.forEach(
				(defCode) -> {
					{
						i18nHelper.upsert(tenantId, "cll_doc_type_relations", "definition_code", new DocTypeI18nAware(defCode));
					}
				});
	}

	protected List<DDocSettingEntry> readFile(Path path) {
		try {
			String json = Files.readString(path);
			return objectMapper.readValue(json, new TypeReference<>() {
			});

		} catch (IOException e) {
			throw new BundleException(String.format("error reading file %s", path), e);
		}
	}

	private DocumentDefinition getDocumentDefinition(String tenantId, String definitionCode) {
		DocumentDefinition documentDefinition = documentTypeService.getDocumentDefinition(tenantId, definitionCode)
				.orElseThrow(() -> new BundleException(String.format("docType '%s' does not exists", definitionCode)));
		return documentDefinition;
	}

	@Data
	protected static class DDocSettingEntry {
		private String definitionCode;

		private boolean required;
		private boolean reqOnAdd;
		private boolean reqOnClose;

		private String titleType;

		private DocTypeRelationScope scopeCode = DocTypeRelationScope.GROUPS; 
	}

	private static class DocTypeI18nAware implements I18nAware {
		private final DocumentDefinition documentDefinition;

		public DocTypeI18nAware(DocumentDefinition documentDefinition) {
			this.documentDefinition = documentDefinition;
		}

		@Override
		public String getI18nCode() {
			return documentDefinition.getCode();
		}

		@Override
		public Set<I18nEntry> getI18n() {
			return new I18nMap(documentDefinition.getTitle()).getI18n();
		}
	}
}
