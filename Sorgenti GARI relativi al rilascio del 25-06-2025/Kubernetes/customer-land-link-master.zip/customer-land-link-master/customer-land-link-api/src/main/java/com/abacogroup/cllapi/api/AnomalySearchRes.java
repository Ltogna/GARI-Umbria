package com.abacogroup.cllapi.api;

import com.abacogroup.cllcli.api.v1.AnomalyLevelEnum;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class AnomalySearchRes {

	private Long id;
	private String entityCode;
	private String entityId;
	private String typeGroupCode;
	private String typeCode;

	private AnomalyLevelEnum level;

}
