package com.abacogroup.cllapi.db.ntt.mapper;

import com.abacogroup.anomalyregistry.api.v1.req.AnomalyRequest;
import com.abacogroup.cllapi.db.ntt.AnomalyEntity;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface CllAnomalyMapper {

	CllAnomalyMapper INSTANCE = Mappers.getMapper(CllAnomalyMapper.class);

	@Mapping(source = "request.typeGroupCode", target = "typeGroupCode")
	@Mapping(source = "request.typeCode", target = "typeCode")
	@Mapping(source = "request.entityCode", target = "entityCode")
	@Mapping(source = "request.entityId", target = "entityId")
	@Mapping(source = "validFrom", target = "validFrom")
	@Mapping(source = "validTo", target = "validTo")
	@Mapping(source = "tenantId", target = "tenantId")
	AnomalyEntity toEntity(AnomalyRequest request, AbsoluteDate validFrom, AbsoluteDate validTo, String tenantId);

}
