package com.abacogroup.cllapi.core.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;
import java.util.Collection;
import lombok.Data;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
public class CllEventMessage {

	private final String tenant;
	private final String username;
	private final String lang;
	private final Long partyId;
	private final LocalDateTime date;
	private final Collection<Long> groupIds;
	private final Collection<Long> landLinkIds;
	private final CllEventType eventType;
	private final Collection<Long> landLinkPkids;

	@JsonCreator
	public CllEventMessage(
			@JsonProperty("tenant") String tenant,
			@JsonProperty("username") String username,
			@JsonProperty("lang") String lang,
			@JsonProperty("partyId") Long partyId,
			@JsonProperty("date") LocalDateTime date,
			@JsonProperty("groupIds") Collection<Long> groupIds,
			@JsonProperty("landLinkIds") Collection<Long> landLinkIds,
			@JsonProperty("eventType") CllEventType eventType,
			@JsonProperty("landLinkPkids") Collection<Long> landLinkPkids
	) {
		this.tenant = tenant;
		this.username = username;
		this.lang = lang;
		this.partyId = partyId;
		this.date = date;
		this.groupIds = groupIds;
		this.landLinkIds = landLinkIds;
		this.eventType = eventType;
		this.landLinkPkids = landLinkPkids;
	}

	public String getRoutingKey() {
		return eventType.getTopic();
	}

}
