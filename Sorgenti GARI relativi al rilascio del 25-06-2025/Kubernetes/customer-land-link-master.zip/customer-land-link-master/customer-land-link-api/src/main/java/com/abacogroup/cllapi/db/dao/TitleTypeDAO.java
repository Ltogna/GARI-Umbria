package com.abacogroup.cllapi.db.dao;

import java.util.List;
import java.util.Optional;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.cllapi.api.TitleType;
import com.abacogroup.cllapi.db.ntt.TitleTypeEntity;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.model.AuditEntity;

public interface TitleTypeDAO extends Transactional<TitleTypeDAO>, EnhancedSqlObject {

	String CURRENT_RECORD = " AND (§current_timestamp§ between tt.dt_insert and tt.dt_delete) ";
	String I18NTitleType = ", coalesce (§i18n(:tenantId, 'cll_title_type', 'code', code, :lang)§, code) as i18n_code\n ";

	@SqlQuery("select * from cll_title_type tt"
			+ " WHERE tt.tenant_id= :tenantId"
			+ " and tt.id = :id"
			+ CURRENT_RECORD)
	@RegisterBeanMapper(TitleTypeEntity.class)
	Optional<TitleTypeEntity> findById(@Bind("tenantId") String tenantId, @Bind("id") Long id);

	@SqlQuery("select * from cll_title_type tt"
			+ " WHERE tt.tenant_id= :tenantId"
			+ " and tt.code = :code"
			+ CURRENT_RECORD)
	@RegisterBeanMapper(TitleTypeEntity.class)
	Optional<TitleTypeEntity> findByCode(@Bind("tenantId") String tenantId, @Bind("code") String code);

	@SqlQuery("select * from cll_title_type tt "
			+ "where tt.tenant_id= :tenantId"
			+ CURRENT_RECORD)
	@RegisterBeanMapper(TitleTypeEntity.class)
	List<TitleTypeEntity> findAll(@Bind("tenantId") String tenantId);

	@SqlUpdate("insert into cll_title_type (code, tenant_id, fl_day_to_req, dt_insert, user_id_insert, dt_delete, user_id_delete, fl_day_to_editable, fl_allow_future_day_from )"
			+ " values (:code, :tenantId, :flDayToReq, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete, :flDayToEditable, :flAllowFutureDayFrom)")
	@GetGeneratedKeys("id")
	Long insert(@BindBean TitleTypeEntity entity);
	
	@SqlUpdate("update cll_title_type \n"
			+ "   set fl_day_to_req = :flDayToReq, \n"
			+ "       fl_day_to_editable = :flDayToEditable, \n"
			+ "       fl_allow_future_day_from = :flAllowFutureDayFrom \n"
			+ " where id = :id \n"
			+ "   and code = :code \n"
			+ "   and tenant_id = :tenantId ")
	void update(@BindBean TitleTypeEntity entity);

	@SqlQuery("SELECT * FROM cll_title_type  "
			+ " WHERE tenant_id = :tenantId "
			+ " AND id = :id "
			+ " AND (§current_timestamp§ between dt_insert and dt_delete)")
	@RegisterBeanMapper(TitleTypeEntity.class)
	Optional<TitleTypeEntity> findById(
			@BindBean ReqContext ctx,
			@Bind("id") Long id);

	@SqlQuery("SELECT tt.id, tt.code , tt.fl_day_to_req, tt.fl_day_to_editable, tt.fl_allow_future_day_from " + I18NTitleType + "FROM cll_title_type tt "
			+ " WHERE tt.tenant_id = :tenantId "
			+ " AND tt.id = :id "
			+ CURRENT_RECORD)
	@RegisterBeanMapper(TitleType.class)
	Optional<TitleType> searchById(
			@BindBean ReqContext ctx,
			@Bind("id") Long id);

	@SqlQuery("SELECT tt.id, tt.code , tt.fl_day_to_req, tt.fl_day_to_editable, tt.fl_allow_future_day_from " + I18NTitleType
			+ " FROM cll_title_type tt where tt.tenant_id = :tenantId " + CURRENT_RECORD
			+ " ORDER BY tt.id")
	@RegisterBeanMapper(TitleType.class)
	List<TitleType> searchAll(@BindBean ReqContext ctx);

	@SqlUpdate("update cll_title_type set dt_delete =:dtDelete, user_id_delete=:userIdDelete where id = :id")
	void expireRow(@BindBean TitleTypeEntity entity);

	@SqlUpdate("update cll_title_type set dt_delete =:dtDelete, user_id_delete=:userIdDelete "
			+ "where code in (<keys>) "
			+ "and tenant_id = :tenantId "
			+ "AND (§current_timestamp§ between dt_insert and dt_delete) ")
	void expireRowsByKey(@BindBean AuditEntity audit,
			@Bind("tenantId") String tenantId,
			@BindList("keys") List<String> keys);

	@SqlQuery("select count(*) FROM cll_title_type where tenant_id = :tenantId ")
	Long countAll(@Bind("tenantId") String tenantId);

	@SqlUpdate("INSERT INTO cll_title_type (code,tenant_id,fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete) "
			+ " select code, :newTenantId as tenant_id, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete  "
			+ " FROM cll_title_type  "
			+ " where tenant_id = :sourceTenant "
			+ " AND (§current_timestamp§ between dt_insert and dt_delete)")
	void insertNewTenant(@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId,
			@BindBean AuditEntity audit);

	
}
