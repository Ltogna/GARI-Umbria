package com.abacogroup.cllapi.api;

import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)

public class ParcelSearchRes {

	private ParcelRes parcel;

	@JsonIgnore
	private Long partyId;

	/**
	 * Elenco dei CUAA conduttori dell’azienda in un periodo che si interseca con quello di conduzione del Gruppo di Conduzione selezionato.
	 */
	@Deprecated
	private List<PartyResponseV1> conduttori = new ArrayList<>();

	private List<LandLinkLeadingRes> leadings;

	protected ParcelSearchRes() {

	}

	//	@Deprecated
	//	public ParcelSearchRes(ParcelRes parcel, Long partyId, List<PartyResponseV1> conduttori) {
	//		this.parcel = parcel;
	//		this.partyId = partyId;
	//		this.conduttori = conduttori;
	//	}

	public ParcelSearchRes(ParcelRes parcel, Long partyId, List<LandLinkLeadingRes> leadings) {
		this.parcel = parcel;
		this.partyId = partyId;
		this.leadings = leadings;
	}

	public boolean isConduzione() {
		if (null == leadings) {
			return false;
		}
		return !leadings.isEmpty();
	}

	public boolean isConduzioneByCurrentParty() {
		if (null == leadings) {
			return false;
		}
		return leadings.stream()
				.map(LandLinkLeadingRes::getPartyId)
				.anyMatch(x -> partyId.equals(x));
	}

}
