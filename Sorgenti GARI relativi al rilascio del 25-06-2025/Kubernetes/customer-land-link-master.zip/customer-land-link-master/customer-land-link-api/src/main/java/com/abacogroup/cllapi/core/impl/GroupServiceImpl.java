package com.abacogroup.cllapi.core.impl;

import static com.abacogroup.cllapi.exceptions.LandLinkException.ErrEnum.INVALID_DAY_FROM;
import static com.abacogroup.cllapi.exceptions.LandLinkException.ErrEnum.INVALID_DAY_TO;

import java.time.Clock;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.core.result.ResultIterator;

import com.abacogroup.cllapi.api.GroupRes;
import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.api.req.GroupCloneReq;
import com.abacogroup.cllapi.api.req.GroupCreateReq;
import com.abacogroup.cllapi.api.req.GroupSearchReq;
import com.abacogroup.cllapi.api.req.GroupUpdateReq;
import com.abacogroup.cllapi.api.req.LandLinkBatchCreateReq;
import com.abacogroup.cllapi.core.GroupService;
import com.abacogroup.cllapi.core.LandLinkEventProducer;
import com.abacogroup.cllapi.core.LandLinkService;
import com.abacogroup.cllapi.core.PartyClientService;
import com.abacogroup.cllapi.core.TitleTypeService;
import com.abacogroup.cllapi.core.dto.CllEventType;
import com.abacogroup.cllapi.core.embededqueue.EventPublisher;
import com.abacogroup.cllapi.db.dao.CllSettingsDAO;
import com.abacogroup.cllapi.db.dao.GroupDAO;
import com.abacogroup.cllapi.db.dao.LandLinkDAO;
import com.abacogroup.cllapi.db.ntt.GroupEntity;
import com.abacogroup.cllapi.db.ntt.GroupEntityExtended;
import com.abacogroup.cllapi.db.ntt.LandLinkEntity;
import com.abacogroup.cllapi.db.ntt.TitleTypeEntity;
import com.abacogroup.cllapi.exceptions.GroupException;
import com.abacogroup.cllapi.exceptions.LandLinkException;
import com.abacogroup.cllapi.exceptions.TitleTypeException;
import com.abacogroup.cllapi.exceptions.TitleTypeException.ErrEnum;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.common.service.AuditHelper;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class GroupServiceImpl implements GroupService {

	private final GroupDAO groupDAO;
	private final LandLinkDAO landLinkDAO;
	private final LandLinkEventProducer landLinkEventProducer;
	private final EventPublisher anomalyQueue;
	private final TitleTypeService titleTypeService;
	private final LandLinkService landLinkService;
	private final PartyClientService partyClientService;
	private final Clock appClock;

	private final CllSettingsDAO cllSettingsDAO;

	public GroupServiceImpl(GroupDAO groupDAO, LandLinkDAO landLinkDAO, LandLinkEventProducer landLinkEventProducer, EventPublisher anomalyQueue, TitleTypeService titleTypeService,
			LandLinkService landLinkService,
			PartyClientService partyClientService, Clock appClock, CllSettingsDAO cllSettingsDAO) {
		this.groupDAO = groupDAO;
		this.landLinkDAO = landLinkDAO;
		this.landLinkEventProducer = landLinkEventProducer;
		this.anomalyQueue = anomalyQueue;
		this.titleTypeService = titleTypeService;
		this.landLinkService = landLinkService;
		this.partyClientService = partyClientService;
		this.appClock = appClock;
		this.cllSettingsDAO = cllSettingsDAO;
	}

	@Override
	public Optional<GroupEntity> loadById(ReqContext reqContext, Long id) {
		return groupDAO.findById(reqContext.getTenantId(), id);
	}

	@Override
	public Optional<GroupEntityExtended> loadExtended(ReqContext reqContext, Long partyId, Long id) {
		return groupDAO.findExtendedByIdAndPartyId(reqContext.getTenantId(), id, partyId);
	}

	@Override
	public GroupRes getRes(ReqContext reqContext, Long partyId, Long groupId) {

		return groupDAO.getByIdAndPartyId(reqContext, groupId, partyId)
				.orElseThrow(() -> new GroupException(GroupException.ErrEnum.NOT_FOUND,
						String.format("group with id '%d' not found", groupId)));
	}

	@Override
	public InfiniteListResults<LandLinkRes> searchGroupLandLinks(ReqContext reqContext, Long partyId, Long groupId, String nextKey) {

		GroupEntity groupEntity = groupDAO.findByIdAndPartyId(reqContext.getTenantId(), groupId, partyId)
				.orElseThrow(() -> new GroupException(GroupException.ErrEnum.NOT_FOUND,
						String.format("group with id '%d' not found", groupId)));

		return landLinkService.searchByGroup(reqContext, groupEntity.getPartyId(), groupEntity.getId(), nextKey);
	}
	
	@Override
	public List<LandLinkRes> searchGroupLandLinks(ReqContext reqContext, Long partyId, Long groupId) {
		
		GroupEntity groupEntity = groupDAO.findByIdAndPartyId(reqContext.getTenantId(), groupId, partyId)
				.orElseThrow(() -> new GroupException(GroupException.ErrEnum.NOT_FOUND,
						String.format("group with id '%d' not found", groupId)));
		
		return landLinkService.searchByGroup(reqContext, groupEntity.getPartyId(), groupEntity.getId());
	}

	@Override
	public GroupRes insert(ReqContext reqContext, Long partyId, GroupCreateReq createReq) {

		this.validatePartyId(reqContext, partyId);

		TitleTypeEntity titleType = this.loadTitleType(reqContext, createReq.getTitleTypeId());

		final AbsoluteDate finalDayFrom = getValidDayFrom(createReq.getDayFrom(), titleType);
		final AbsoluteDate finalDayTo = getValidDayTo(createReq.getDayTo(), titleType);

		this.validateGroupDescr(reqContext, partyId, null, createReq.getDescr());

		Long groupId = groupDAO.inTransaction(handle -> {
			GroupEntity groupEntity = this.insertNoValidated(reqContext, partyId, createReq.getTitleTypeId(), createReq.getDescr());
			Long newGroupId = groupEntity.getId();
			landLinkService.insertInternal(reqContext, groupEntity, finalDayFrom, finalDayTo, createReq.getLandLinks());
			landLinkEventProducer.pushGroupEvent(List.of(newGroupId), partyId, reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
					CllEventType.NEW_GROUP);
			anomalyQueue.pushGroupEvent(List.of(newGroupId), finalDayFrom, partyId, reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
					CllEventType.NEW_GROUP);
			return newGroupId;
		});

		return this.getRes(reqContext, partyId, groupId);
	}

	@Override
	public GroupRes clone(ReqContext reqContext, Long partyId, Long sourceGroupId, GroupCloneReq cloneReq) {

		this.validatePartyId(reqContext, partyId);

		GroupEntityExtended sourceGroupEntity = this.loadClosedGroup(reqContext, partyId, sourceGroupId);

		TitleTypeEntity titleType = this.loadTitleType(reqContext, cloneReq.getTitleTypeId());

		final AbsoluteDate finalDayFrom = getValidDayFrom(cloneReq.getDayFrom(), titleType);
		final AbsoluteDate finalDayTo = getValidDayTo(cloneReq.getDayTo(), titleType);

		if (finalDayFrom.toLocalDate().isBefore(sourceGroupEntity.getDayTo().toLocalDate())) {
			throw new LandLinkException(INVALID_DAY_FROM, "dayFrom cannot be before source dayTo " + sourceGroupEntity.getDayTo());
		}

		this.validateGroupDescr(reqContext, partyId, null, cloneReq.getDescr());

		Long groupId = groupDAO.inTransaction(handle -> {
			GroupEntity groupEntity = this.insertNoValidated(reqContext, partyId, cloneReq.getTitleTypeId(), cloneReq.getDescr());
			landLinkService.cloneInternal(reqContext, groupEntity, cloneReq.getTitleTypePerc(), finalDayFrom, finalDayTo, sourceGroupEntity.getId());
			Long newGroupId = groupEntity.getId();
			landLinkEventProducer.pushGroupEvent(List.of(newGroupId), partyId, reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
					CllEventType.NEW_GROUP);

			anomalyQueue.pushGroupEvent(List.of(newGroupId), finalDayFrom, partyId, reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
					CllEventType.NEW_GROUP);
			return newGroupId;
		});

		return this.getRes(reqContext, partyId, groupId);
	}

	protected GroupEntity insertNoValidated(ReqContext reqContext, Long partyId, Long titleTypeId, String descr) {

		GroupEntity newGroup = GroupEntity.builder()
				.setPartyId(partyId)
				.setTitleTypeId(titleTypeId)
				.setDescr(StringUtils.trimToNull(descr))
				.setTenantId(reqContext.getTenantId())
				.build();

		AuditHelper.setAuditForInsert(reqContext.getUsername(), groupDAO, newGroup);

		Long id = groupDAO.issuePk();
		groupDAO.insertMasterRow(id, newGroup);
		groupDAO.insertDetailRow(id, newGroup);

		newGroup.setId(id);
		newGroup.setPkid(id);
		return newGroup;
	}

	@Override
	public GroupRes update(ReqContext reqContext, Long partyId, Long groupId, GroupUpdateReq req) {

		GroupEntityExtended groupEntity = loadOpenGroup(reqContext, partyId, groupId);
		AbsoluteDate actualDayFrom = groupEntity.getDayFrom();

		TitleTypeEntity titleType = this.loadTitleType(reqContext, groupEntity.getTitleTypeId());

		final AbsoluteDate finalDayFrom = getValidDayFrom(req.getDayFrom(), titleType);
		final AbsoluteDate finalDayTo = getValidDayTo(req.getDayTo(), titleType);

		this.validateGroupDescr(reqContext, partyId, groupEntity.getId(), req.getDescr());
		groupEntity.setDescr(StringUtils.trimToNull(req.getDescr()));

		groupDAO.useTransaction(handle -> {

			Long pkid = AuditHelper.update(groupEntity, reqContext.getUsername(),
					handle::expireRow,
					handle::insertVersionRow,
					handle.getCurrentTimestamp());
			groupEntity.setPkid(pkid);

			if (!finalDayFrom.equals(groupEntity.getDayFrom()) || !finalDayTo.equals(groupEntity.getDayTo())) {
				landLinkService.updateDatesByGroup(reqContext, finalDayFrom, finalDayTo, groupId);
				//TODO update DD dates (validFrom / validTO)
			}
			landLinkEventProducer.pushGroupEvent(List.of(groupId), partyId, reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
					CllEventType.UPDATE_GROUP);
			anomalyQueue.pushGroupEvent(List.of(groupId), actualDayFrom, partyId, reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
					CllEventType.UPDATE_GROUP);
		});

		return this.getRes(reqContext, partyId, groupId);
	}

	@Override
	public GroupRes addLandLinks(ReqContext reqContext, Long partyId, Long groupId, List<LandLinkBatchCreateReq> createReq) {

		groupDAO.useTransaction( h -> {

			GroupEntityExtended groupEntity = loadOpenGroup(reqContext, partyId, groupId);

			final AbsoluteDate finalDayFrom = groupEntity.getDayFrom();
			final AbsoluteDate finalDayTo = groupEntity.getDayTo();

			landLinkService.insertInternal(reqContext, groupEntity, finalDayFrom, finalDayTo, createReq);

			landLinkEventProducer.pushGroupEvent(List.of(groupId), partyId, reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
					CllEventType.UPDATE_GROUP);
			anomalyQueue.pushGroupEvent(List.of(groupId), groupEntity.getDayFrom(), partyId, reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
					CllEventType.UPDATE_GROUP);
		});

		return this.getRes(reqContext, partyId, groupId);
	}

	@Override
	public void deleteLandLinkByGroupIdAndParcelId(ReqContext reqContext, Long partyId, Long groupId, Long parcelId) {

		GroupEntityExtended groupEntity = groupDAO.findExtendedByIdAndPartyId(reqContext.getTenantId(), groupId, partyId)
				.orElseThrow(() -> new GroupException(GroupException.ErrEnum.NOT_FOUND,
						String.format("group with id '%d' not found", groupId)));

		groupDAO.useTransaction(handle -> {

			List<Long> landLinkPkids = this.getAllLandLinkPkidsByGroupId(reqContext.getTenantId(), partyId, groupId);
			landLinkService.expireByGroupAndParcelId(reqContext, partyId, groupId, parcelId);

			if(groupDAO.findExtendedByIdAndPartyId(reqContext.getTenantId(), groupId, partyId)
					.map(GroupEntityExtended::getLinkCount)
					.map(count -> count <= 0)
					.orElse(false)) {
				AuditHelper.expire(groupEntity, reqContext.getUsername(), handle::expireRow, handle.getCurrentTimestamp());

				landLinkEventProducer.pushGroupEvent(List.of(groupEntity.getId()), partyId, reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
						CllEventType.UPDATE_GROUP, landLinkPkids);
				anomalyQueue.pushGroupEvent(List.of(groupEntity.getId()), groupEntity.getDayFrom(), partyId, reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
						CllEventType.UPDATE_GROUP);
			}
		});
	}

	@Override
	public GroupRes close(ReqContext reqContext, Long partyId, Long groupId, AbsoluteDate dayTo) {

		GroupEntityExtended groupEntity = loadExtendedOrThrow(reqContext, partyId, groupId);

		if (dayTo.equals(groupEntity.getDayTo())) {
			return this.getRes(reqContext, groupEntity.getPartyId(), groupEntity.getId());
		}

		Boolean allowEditDayToParcelInThePast = cllSettingsDAO.getOne(reqContext.getTenantId())
				.getAllowEditDayToParcelInThePast();
		this.validateCanClose(groupEntity, dayTo, LocalDate.now(appClock), allowEditDayToParcelInThePast, reqContext);

		// TODO check mandatory documents

		landLinkService.closeByGroups(reqContext, partyId, List.of(groupEntity.getId()), dayTo);

		return this.getRes(reqContext, groupEntity.getPartyId(), groupEntity.getId());
	}

	@Override
	public void closeMany(ReqContext reqContext, Long partyId, Collection<Long> groupIds, AbsoluteDate dayTo) {

		Boolean allowEditDayToParcelInThePast = cllSettingsDAO.getOne(reqContext.getTenantId())
				.getAllowEditDayToParcelInThePast();
		LocalDate now = LocalDate.now(appClock);
		groupDAO.useTransaction(h -> {
			try (ResultIterator<GroupEntityExtended> groups = h.findExtendedByIdInAndPartyId(
					reqContext.getTenantId(), groupIds, partyId)) {
				groups.forEachRemaining(groupEntity -> this.validateCanClose(groupEntity, dayTo, now,
						allowEditDayToParcelInThePast, reqContext));
			}
			// TODO check mandatory documents
			landLinkService.closeByGroups(reqContext, partyId, groupIds, dayTo);
		});

	}

	@Override
	public void expire(ReqContext reqContext, Long partyId, Long groupId) {
		List<Long> landLinkPkids = this.getAllLandLinkPkidsByGroupId(reqContext.getTenantId(), partyId, groupId);
		landLinkService.expireByGroup(reqContext, partyId, groupId);
		
		groupDAO.useTransaction(handle -> {
			Optional<GroupEntityExtended> group = loadExtended(reqContext, partyId, groupId);
			group.ifPresent(g -> {
				AuditHelper.expire(g, reqContext.getUsername(), handle::expireRow, handle.getCurrentTimestamp());
				
				landLinkEventProducer.pushGroupEvent(List.of(g.getId()), partyId, reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
						CllEventType.UPDATE_GROUP, landLinkPkids);
				anomalyQueue.pushGroupEvent(List.of(g.getId()), g.getDayFrom(), partyId, reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
						CllEventType.UPDATE_GROUP);
			});
		});
	}

	@Override
	public InfiniteListResults<GroupRes> search(ReqContext reqContext, AbsoluteDate referenceDate, Long partyId, GroupSearchReq searchRequest, String nextKey) {
		Criteria criteria = searchRequest.getCriteria(reqContext);
		OrderBy sort = searchRequest.getSort();

		return groupDAO.infinite(
				() -> searchRequest.isShowElapsed()
						? groupDAO.searchElapsed(referenceDate.getValue(), partyId, criteria, sort, reqContext)
						: groupDAO.search(referenceDate.getValue(), partyId, criteria, sort, reqContext),
				nextKey, searchRequest.getPageSize());
	}

	@Override
	public List<GroupEntity> getDuplicates(ReqContext reqContext, Long partyId, String descr) {
		return groupDAO.getDuplicates(reqContext, partyId, StringUtils.trimToEmpty(descr));
	}

	@Override
	public Long countDuplicates(ReqContext reqContext, Long partyId, Long groupId, String descr) {
		return this.getDuplicates(reqContext, partyId, StringUtils.trimToEmpty(descr))
				.stream()
				.filter(g -> !g.getId().equals(groupId))
				.count();

	}

	private GroupEntityExtended loadOpenGroup(ReqContext reqContext, Long partyId, Long groupId) {
		GroupEntityExtended groupEntity = loadExtendedOrThrow(reqContext, partyId, groupId);

		if (groupEntity.getDayTo().toLocalDate().compareTo(LocalDate.now(appClock)) < 0) {
			throw new GroupException(GroupException.ErrEnum.CLOSED_GROUP,
					String.format("group with id '%d' and party '%d' was closed on %s in tenant %s",
							groupId, partyId, groupEntity.getDayTo(), reqContext.getTenantId()));
		}

		return groupEntity;
	}

	private GroupEntityExtended loadClosedGroup(ReqContext reqContext, Long partyId, Long groupId) {
		GroupEntityExtended groupEntity = loadExtendedOrThrow(reqContext, partyId, groupId);

		if (groupEntity.getDayTo().toLocalDate().isAfter(LocalDate.now(appClock))) {
			throw new GroupException(GroupException.ErrEnum.OPEN_GROUP,
					String.format("group with id '%d' and party '%d' is not closed for tenant %s",
							groupId, partyId, reqContext.getTenantId()));
		}
		return groupEntity;
	}

	private TitleTypeEntity loadTitleType(ReqContext reqContext, Long titleTypeId) {
		return titleTypeService.loadById(reqContext, titleTypeId)
				.orElseThrow(() -> new TitleTypeException(ErrEnum.NOT_FOUND,
						String.format("titleType '%s' does not exists", titleTypeId)));
	}

	private void validateCanClose(GroupEntityExtended groupEntity, AbsoluteDate dayTo, LocalDate now,
			Boolean allowEditDayToParcelInThePast, ReqContext reqContext) {

		if (dayTo.equals(groupEntity.getDayTo())) {
			return;
		}

		if (Boolean.TRUE.equals(!allowEditDayToParcelInThePast) && now.isAfter(groupEntity.getDayTo().toLocalDate())) {
			throw new GroupException(GroupException.ErrEnum.CLOSED_GROUP,
					String.format("group with id '%d' and tenant %s was closed on %s",
							groupEntity.getId(), reqContext.getTenantId(), groupEntity.getDayTo()));
		}

		if (dayTo.toLocalDate().isAfter(groupEntity.getDayTo().toLocalDate())) {
			throw new GroupException(GroupException.ErrEnum.INVALID_DAY_TO,
					String.format("close date cannot be after %s in group with id '%s' and tenant %s",
							groupEntity.getDayTo(), groupEntity.getId(), reqContext.getTenantId()));
		}
		if (dayTo.toLocalDate().isBefore(groupEntity.getDayFrom().toLocalDate())) {
			throw new GroupException(GroupException.ErrEnum.INVALID_DAY_TO,
					String.format("invalid date range %s - %s in group with id '%s' and tenant %s",
							groupEntity.getDayFrom(), dayTo, groupEntity.getId(),
							reqContext.getTenantId()));
		}

	}

	private void validatePartyId(ReqContext reqContext, Long partyId) {
		PartyResponseV1 party = partyClientService.getById(reqContext, partyId)
				.orElseThrow(() -> new GroupException(GroupException.ErrEnum.INVALID_PARTY,
						String.format("no party found with id %s  and tenant %s", partyId, reqContext.getTenantId())));
		log.trace("party {} loaded", party.getId());
	}

	private void validateGroupDescr(ReqContext reqContext, Long partyId, Long groupId, String descr) {
		if (StringUtils.isNotBlank(descr)
				&& this.countDuplicates(reqContext, partyId, groupId, descr) > 0L) {
			throw new GroupException(GroupException.ErrEnum.DUPLICATE_DESCR,
					String.format("party %s has already a group with descr '%s' in tenant %s",
							partyId, descr, reqContext.getTenantId()));
		}
	}

	private AbsoluteDate getValidDayFrom(AbsoluteDate dayFrom, TitleTypeEntity titleType) {
		if (dayFrom == null || StringUtils.isBlank(dayFrom.getValue())) {
			throw new LandLinkException(INVALID_DAY_FROM, "dayFrom cannot be null");
		} else if (titleType.getFlAllowFutureDayFrom() == 0 && LocalDate.now(appClock).isBefore(dayFrom.toLocalDate())) {
			throw new LandLinkException(INVALID_DAY_FROM, "dayFrom cannot be in the future");
		} else {
			return AbsoluteDate.of(dayFrom.getValue());
		}
	}

	private AbsoluteDate getValidDayTo(AbsoluteDate dayTo, TitleTypeEntity titleType) {
		if (titleType.getFlDayToReq() == 0 && titleType.getFlDayToEditable() == 0) {
			return AbsoluteDate.of(AuditEntity.dateActive);
		} else if (titleType.getFlDayToReq() == 0 && titleType.getFlDayToEditable() == 1) {
			if (dayTo == null) {
				return AbsoluteDate.of(AuditEntity.dateActive);
			} else if (LocalDate.now(appClock).isAfter(dayTo.toLocalDate())) {
				throw new LandLinkException(INVALID_DAY_TO, "dayTo must be in the future");
			} else {
				return AbsoluteDate.of(dayTo.getValue());
			}
		} else if (dayToIsNotDefine(dayTo)) {
			throw new LandLinkException(INVALID_DAY_TO, "dayTo cannot be null");
		} else if (LocalDate.now(appClock).isAfter(dayTo.toLocalDate())) {
			throw new LandLinkException(INVALID_DAY_TO, "dayTo must be in the future");
		} else {
			return AbsoluteDate.of(dayTo.getValue());
		}
	}

	private boolean dayToIsNotDefine(AbsoluteDate dayTo) {
		return dayTo == null || StringUtils.isBlank(dayTo.getValue()) || AbsoluteDate.of(AuditEntity.dateActive).equals(dayTo);
	}

	private GroupEntityExtended loadExtendedOrThrow(ReqContext reqContext, Long partyId, Long groupId) {
		return this.loadExtended(reqContext, partyId, groupId)
				.orElseThrow(() -> new GroupException(GroupException.ErrEnum.NOT_FOUND,
						String.format("group with id '%d' and party '%d' not found in tenant %s",
								groupId, partyId, reqContext.getTenantId())));
	}
	
	private List<Long> getAllLandLinkPkidsByGroupId(String tenantId, Long partyId, Long groupId){
		return landLinkDAO.findByGroupIdAndPartyId(groupId, partyId, tenantId).stream()
				.map(LandLinkEntity::getPkid)
				.collect(Collectors.toList());
	}
}
