package com.abacogroup.cllapi.db.dao;

import com.abacogroup.cllapi.api.CllSettings;
import com.abacogroup.cllapi.db.ntt.CllSettingsEntity;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.model.AuditEntity;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import java.util.Optional;

public interface CllSettingsDAO extends Transactional<CllSettingsDAO>, EnhancedSqlObject {

	String CURRENT_RECORD = " AND (§current_timestamp§ between stt.dt_insert and stt.dt_delete) ";

	@SqlQuery("select * from cll_settings stt"
			+ " WHERE stt.tenant_id= :tenantId"
			+ CURRENT_RECORD)
	@RegisterBeanMapper(CllSettingsEntity.class)
	Optional<CllSettingsEntity> loadOne(@Bind("tenantId") String tenantId);
	
	@SqlQuery("select stt.lpis_sub_separator, stt.fl_allow_editdayto_parcelinthepast "
			+ " from cll_settings stt "
			+ " WHERE stt.tenant_id= :tenantId"
			+ CURRENT_RECORD)
	@RegisterBeanMapper(CllSettings.class)
	CllSettings getOne(@Bind("tenantId") String tenantId);

	@SqlUpdate("insert into cll_settings (tenant_id, lpis_sub_separator, fl_allow_editdayto_parcelinthepast, dt_insert, user_id_insert, dt_delete, user_id_delete )"
			+ " values (:tenantId, :lpisSubSeparator, :allowEditDayToParcelInThePast, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete )")
	@GetGeneratedKeys("pkid")
	Long insert(@BindBean CllSettingsEntity entity);

	@SqlUpdate("update cll_settings set dt_delete =:dtDelete, user_id_delete=:userIdDelete where pkid = :pkid")
	void expire(@BindBean CllSettingsEntity entity);

	@SqlUpdate("INSERT INTO cll_settings (tenant_id,lpis_sub_separator, fl_allow_editdayto_parcelinthepast, dt_insert, user_id_insert, dt_delete, user_id_delete) "
			+ " select :newTenantId as tenant_id, lpis_sub_separator, fl_allow_editdayto_parcelinthepast, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete  "
			+ " FROM cll_settings  "
			+ " where tenant_id = :sourceTenant "
			+ " AND (§current_timestamp§ between dt_insert and dt_delete)")
	void insertNewTenant(@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId,
			@BindBean AuditEntity audit);

	@SqlQuery("select count(*) from cll_settings stt"
			+ " WHERE stt.tenant_id= :tenantId"
			+ CURRENT_RECORD)
	@RegisterBeanMapper(CllSettingsEntity.class)
	Long countAll(@Bind("tenantId") String tenantId);

}
