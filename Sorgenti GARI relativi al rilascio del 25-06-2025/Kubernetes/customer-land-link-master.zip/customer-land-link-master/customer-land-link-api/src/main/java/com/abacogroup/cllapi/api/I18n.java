package com.abacogroup.cllapi.api;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;
import org.jdbi.v3.core.mapper.reflect.ColumnName;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class I18n {

	private String tableName;
	private String fieldName;
	@ColumnName("i18n_value")
	private String i18nValue;
	private String lang;
	private String i18nText;
}
