package com.abacogroup.cllapi.exceptions;

import com.abacogroup.common.exceptions.AbstractAppException;
import io.swagger.v3.oas.annotations.media.Schema;

public class LandLinkException extends AbstractAppException {

	public LandLinkException(ErrEnum code, String message) {
		super(new ErrorBody(code.name(), message));
	}

	public enum ErrEnum {
		INVALID_TYPE,
		INVALID_DAY_FROM,
		INVALID_DAY_TO,
		NOT_FOUND,
		PARCEL_NOT_FOUND,
		DUPLICATED_PARCELS,
		CLOSED_LAND_LINK,
		NO_AVAILABLE_DATE,
	}

	@Schema(name = "LandLinkExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = {
				"INVALID_TYPE",
				"INVALID_DAY_FROM",
				"INVALID_DAY_TO",
				"NOT_FOUND",
				"PARCEL_NOT_FOUND",
				"DUPLICATED_PARCELS",
				"CLOSED_LAND_LINK",
				"NO_AVAILABLE_DATE",
		})
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}
}
