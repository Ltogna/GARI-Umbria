package com.abacogroup.cllapi.db.ntt;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PartyEntity {
	
	private Long partyId;
	
}
