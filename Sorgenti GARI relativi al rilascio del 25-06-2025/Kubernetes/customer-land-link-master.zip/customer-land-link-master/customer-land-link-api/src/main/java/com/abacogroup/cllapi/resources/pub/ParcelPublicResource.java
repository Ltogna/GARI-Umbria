package com.abacogroup.cllapi.resources.pub;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.cllapi.api.req.ParcelSearchReq;
import com.abacogroup.cllapi.core.ParcelV1Service;
import com.abacogroup.cllapi.exceptions.InvalidPayloadException;
import com.abacogroup.cllapi.exceptions.InvalidPayloadException.ErrEnum;
import com.abacogroup.cllcli.api.v1.LandLinkLeadingResV1;
import com.abacogroup.cllcli.api.v1.LandLinkLeadingResWithHolderResV1;
import com.abacogroup.cllcli.api.v1.ParcelSearchResponseV1;
import com.abacogroup.cllcli.resources.PublicResourceConstants;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(PublicResourceConstants.API_V1_PUB)
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Parcels")
@Tag(name = "Public APIs", description = "All public APIs")
public class ParcelPublicResource {

    private final ParcelV1Service parcelService;

    public ParcelPublicResource(ParcelV1Service parcelService) {
        this.parcelService = parcelService;
    }

    /**
     * Deprecated
     * To fix the behavior, remove partyid should search for parcels and add CLL information only
     * {partyId} is misleading and wrong
     */
    @GET
    @Path("/parties/{partyId}/parcels")
    @Deprecated(since = "v0.0.6")
    // @RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
    @Operation(description = "Get the list of filtered parcels", summary = "search parcels")
    @ApiResponse(responseCode = "200", description = "Get the list of filtered parcels", useReturnTypeSchema = true)
    public InfiniteListResults<ParcelSearchResponseV1> searchParcels(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
            @Parameter(description = "party id") @PathParam("partyId") Long partyId,
            @Parameter(description = "Include the geometries data") @QueryParam("include_geometries") @DefaultValue("false") Boolean includeGeometries,
            @Parameter(description = "Include the landcovers detail") @QueryParam("include_landcovers") @DefaultValue("false") Boolean includeLandCovers,
            @Parameter(description = "Include lpis data") @QueryParam("include_lpis_data") @DefaultValue("true") Boolean includeLpisData,
            @Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
            @Parameter(description = "page size") @QueryParam("page_size") Integer pageSize,
            @BeanParam @Valid ParcelSearchReq searchReq) {

        if (StringUtils.isNotBlank(searchReq.getSubParcelCode()) && StringUtils.isBlank(searchReq.getParcelCode())) {
            throw new InvalidPayloadException(ErrEnum.INVALID_PAYLOAD, "subParcelCode is only to be evaluated if there is ParcelCode along with");
        }

        return parcelService.search(new ReqContext(user, lang), partyId, searchReq, includeGeometries, includeLandCovers, includeLpisData, nextKey, pageSize);
    }
    
    @POST
    @Path("/parties/{partyId}/parcels")
    // @RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
    @Operation(description = "Get the list of filtered parcels", summary = "search parcels")
    @ApiResponse(responseCode = "200", description = "Get the list of filtered parcels", useReturnTypeSchema = true)
    public InfiniteListResults<ParcelSearchResponseV1> getParcels(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
            @Parameter(description = "party id") @PathParam("partyId") Long partyId,
            @Parameter(description = "Include the geometries data") @QueryParam("include_geometries") @DefaultValue("false") Boolean includeGeometries,
            @Parameter(description = "Include the landcovers detail") @QueryParam("include_landcovers") @DefaultValue("false") Boolean includeLandCovers,
            @Parameter(description = "Include lpis data") @QueryParam("include_lpis_data") @DefaultValue("true") Boolean includeLpisData,
            @Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
            @Parameter(description = "page size") @QueryParam("page_size") Integer pageSize,
            @Valid @NotNull ParcelSearchReq searchReq) {

        if (StringUtils.isNotBlank(searchReq.getSubParcelCode()) && StringUtils.isBlank(searchReq.getParcelCode())) {
            throw new InvalidPayloadException(ErrEnum.INVALID_PAYLOAD, "subParcelCode is only to be evaluated if there is ParcelCode along with");
        }
        //TODO fix me plis!!!!
        searchReq.setTargetPartyId(partyId);
        return parcelService.search(new ReqContext(user, lang), partyId, searchReq, includeGeometries, includeLandCovers, includeLpisData, nextKey, pageSize);
    }


    @GET
    @Path("/parcel/{parcelId}/parties")
    // @RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
    @Operation(description = "Get the leading list for a parcel", summary = "get parcel's leading list")
    @ApiResponse(responseCode = "200", description = "Get the leading list for a parcel", useReturnTypeSchema = true)
    public List<LandLinkLeadingResV1> getParcelLeadingList(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
            @Parameter(description = "parcel id") @PathParam("parcelId") Long parcelId,
            @Parameter(description = "reference date default today") @QueryParam("reference_date") @Size(min = 8, max = 8) String referenceDate) {
    	
        AbsoluteDate refDate = Optional.ofNullable(referenceDate)
                .map(StringUtils::trimToNull)
                .map(AbsoluteDate::of)
                .orElse(AbsoluteDate.of(LocalDate.now()));
        
        return parcelService.getParcelLeadingList(new ReqContext(user, lang), parcelId, refDate);
    }
    
    @GET
    @Path("/parcel/{parcelId}/history")
    @RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
    @Operation(description = "Get the leading list for a parcel", summary = "get parcel's leading list")
    @ApiResponse(responseCode = "200", description = "Get the leading list for a parcel", useReturnTypeSchema = true)
    public List<LandLinkLeadingResWithHolderResV1> getParcelLeadingHistory(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
            @Parameter(description = "parcel id") @PathParam("parcelId") Long parcelId,
            @Parameter(description = "load mandates holders") @QueryParam("load_holders") @DefaultValue("false") Boolean loadHolders) {
        
        return parcelService.getParcelLeadingHistory(new ReqContext(user, lang), parcelId, loadHolders);
    }
    
}
