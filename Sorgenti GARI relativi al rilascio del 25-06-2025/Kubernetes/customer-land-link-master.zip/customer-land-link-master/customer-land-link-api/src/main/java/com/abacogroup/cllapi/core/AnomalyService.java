package com.abacogroup.cllapi.core;

import com.abacogroup.cllapi.api.AnomalySearchRes;
import com.abacogroup.cllapi.api.req.AnomalySearchReq;
import com.abacogroup.cllapi.core.dto.AnomalyMaxLevelDto;
import com.abacogroup.cllapi.core.dto.LandLink;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface AnomalyService {

	Map<Long, AnomalyMaxLevelDto> getLandLinksAnomalies(ReqContext context, AbsoluteDate refDate, Collection<? extends LandLink> landLinks);

	List<AnomalySearchRes> search(ReqContext context, String entityCode, AnomalySearchReq searchRequest, AbsoluteDate referenceDate);

}
