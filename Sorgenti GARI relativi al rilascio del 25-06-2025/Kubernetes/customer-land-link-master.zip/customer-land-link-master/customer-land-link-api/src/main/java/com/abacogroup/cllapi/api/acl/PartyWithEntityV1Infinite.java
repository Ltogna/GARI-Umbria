package com.abacogroup.cllapi.api.acl;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PartyWithEntityV1Infinite {
	
	private String nextKey;
	private List<PartyWithEntityV1> records;
	private Long count; 

}
