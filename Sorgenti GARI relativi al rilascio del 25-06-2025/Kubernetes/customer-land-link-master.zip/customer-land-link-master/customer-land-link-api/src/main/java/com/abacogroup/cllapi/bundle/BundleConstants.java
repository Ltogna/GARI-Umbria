package com.abacogroup.cllapi.bundle;

public interface BundleConstants {

	String DOMAIN_DYNAMIC_DOCUMENTS = "dynamic_documents";
	String TITLE_TYPES = "title_types";
	String CLL_SETTINGS = "cll_settings";

	String SYSTEM_USER = "system";

	String JSONL_COMMENT = "--";
}
