package com.abacogroup.cllapi.core.impl;

import com.abacogroup.cllapi.api.CllSettings;
import com.abacogroup.cllapi.db.dao.CllSettingsDAO;
import com.abacogroup.cllapi.resources.pub.mapper.CllSettingsMapper;
import com.abacogroup.cllcli.api.v1.CllSettingsResponseV1;
import com.abacogroup.common.resources.ReqContext;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CllSettingsV1ServiceImpl implements com.abacogroup.cllapi.core.CllSettingsV1Service {


	private final CllSettingsDAO cllSettingsDAO;

	public CllSettingsV1ServiceImpl(CllSettingsDAO cllSettingsDAO) {

		this.cllSettingsDAO = cllSettingsDAO;

	}

	@Override
	public CllSettingsResponseV1 getSettings(ReqContext context) {
		CllSettings cllSettings = cllSettingsDAO.getOne(context.getTenantId());

		return CllSettingsMapper.INSTANCE.toResponseV1(cllSettings);
	}


}
