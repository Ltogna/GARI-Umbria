package com.abacogroup.cllapi.db.dao;

import com.abacogroup.cllapi.api.GroupRes;
import com.abacogroup.cllapi.db.ntt.GroupEntity;
import com.abacogroup.cllapi.db.ntt.GroupEntityExtended;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface GroupDAO extends Transactional<GroupDAO>, EnhancedSqlObject {


	String BASE_SEARCH =
	" select g.id, gd.pkid, g.tenant_id, g.party_id, g.title_type_id, gd.descr "
			+ " , min(lld.day_from) as dayFrom, max(lld.day_to) as dayTo, count(lld.id) as linkCount "
			+ " , tt.id as title_id, tt.code as title_code, tt.fl_day_to_req as title_fl_day_to_req, tt.fl_day_to_editable as title_fl_day_to_editable, "
			+ " tt.fl_allow_future_day_from as title_fl_allow_future_day_from, coalesce (§i18n(:tenantId, 'cll_title_type', 'code', tt.code, :lang)§, tt.code) as title_i18n_code "
			+ " from cll_group g "
			+ " inner join cll_group_detail gd on g.id = gd.group_id  and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) "
			+ " left join cll_land_link_detail lld on lld.group_id = g.id and lld.tenant_id = g.tenant_id "
			+ " inner join cll_title_type tt on g.title_type_id = tt.id and tt.tenant_id = g.tenant_id AND (§current_timestamp§ between tt.dt_insert and tt.dt_delete) "
			+ " WHERE <criteria> "
			+ " and (§current_timestamp§ between lld.dt_insert and lld.dt_delete) "
			+ " and g.tenant_id= :tenantId "
			+ " and g.party_id = :partyId "
			+ " and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) "
			+ " group by g.id,  gd.pkid, lld.group_id "
			+ ",g.tenant_id, g.party_id, g.title_type_id, gd.descr, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete "//ORA-00979
			+ " , tt.id, tt.code, tt.fl_day_to_req, tt.fl_day_to_editable, tt.fl_allow_future_day_from \n";

	String BASE_SELECT_EXTENDED_BY_ID = "select g.id, gd.pkid, g.tenant_id, g.party_id, g.title_type_id, gd.descr, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete " +
			" , min(lld.day_from) as dayFrom, max(lld.day_to) as dayTo, count(lld.id) as linkCount " +
			" from cll_group g " +
			" join cll_group_detail gd on g.id = gd.group_id  and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) " +
			" left join cll_land_link_detail lld on lld.group_id = g.id and lld.tenant_id = g.tenant_id " +
			"     and (§current_timestamp§ between lld.dt_insert and lld.dt_delete) " +
			" WHERE g.tenant_id= :tenantId " +
			" and g.id = :id " +
			" and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) " +
			" group by g.id,  gd.pkid, lld.group_id "
			+ " ,g.tenant_id, g.party_id, g.title_type_id, gd.descr, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete" ;

	@SqlQuery("select g.id, gd.pkid, g.tenant_id, g.party_id, g.title_type_id, gd.descr, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete " +
			" from cll_group g " +
			" join cll_group_detail gd on g.id = gd.group_id " +
			" WHERE g.tenant_id= :tenantId " +
			" and g.id = :id " +
			" and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) ")
	@RegisterBeanMapper(GroupEntity.class)
	Optional<GroupEntity> findById(@Bind("tenantId") String tenantId, @Bind("id") Long id);

	@SqlQuery("select g.id, gd.pkid, g.tenant_id, g.party_id, g.title_type_id, gd.descr, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete " +
			" from cll_group g " +
			" join cll_group_detail gd on g.id = gd.group_id " +
			" WHERE g.tenant_id= :tenantId " +
			" and g.id = :id " +
			" and g.party_id = :partyId " +
			" and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) ")
	@RegisterBeanMapper(GroupEntity.class)
	Optional<GroupEntity> findByIdAndPartyId(@Bind("tenantId") String tenantId, @Bind("id") Long id, @Bind("partyId") Long partyId);


	@SqlQuery("select g.id, gd.pkid, g.tenant_id, g.party_id, g.title_type_id, gd.descr, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete " +
			" from cll_group g " +
			" join cll_group_detail gd on g.id = gd.group_id " +
			" WHERE g.tenant_id= :tenantId " +
			" and g.party_id = :partyId " +
			" and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) ")
	@RegisterBeanMapper(GroupEntity.class)
	List<GroupEntity> findByPartyId(@Bind("tenantId") String tenantId,@Bind("partyId") Long partyId);

	@SqlQuery("select distinct g.id "
			+ " from cll_group g "
			+ " WHERE g.tenant_id= :tenantId "
			+ " and g.party_id = :partyId "
			+ " order by g.id ")
	List<Long> findGroupIdsByPartyIdIncludeExpired(@Bind("tenantId") String tenantId,@Bind("partyId") Long partyId);


	@SqlQuery(BASE_SELECT_EXTENDED_BY_ID)
	//ORA [42000][979] ORA-00979
	@RegisterBeanMapper(GroupEntityExtended.class)
	Optional<GroupEntityExtended> findExtendedById(@Bind("tenantId") String tenantId, @Bind("id") Long id);

	@SqlQuery(BASE_SELECT_EXTENDED_BY_ID
			+ " having (:referenceDate between min(lld.day_from) and max(lld.day_to)) ")
	@RegisterBeanMapper(GroupEntityExtended.class)
	Optional<GroupEntityExtended> findActiveGroupById(@Bind("tenantId") String tenantId, @Bind("id") Long id,@Bind("referenceDate") String referenceDate);


	@SqlQuery("select g.id, gd.pkid, g.tenant_id, g.party_id, g.title_type_id, gd.descr, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete " +
			" , min(lld.day_from) as dayFrom, max(lld.day_to) as dayTo, count(lld.id) as linkCount " +
			" from cll_group g " +
			" join cll_group_detail gd on g.id = gd.group_id  and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) " +
			" left join cll_land_link_detail lld on lld.group_id = g.id and lld.tenant_id = g.tenant_id " +
			"     and (§current_timestamp§ between lld.dt_insert and lld.dt_delete) " +
			" WHERE g.tenant_id= :tenantId " +
			" and g.id = :id " +
			" and g.party_id = :partyId " +
			" and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) " +
			" group by g.id,  gd.pkid, lld.group_id " +
			//ORA [42000][979] ORA-00979
			" ,g.tenant_id, g.party_id, g.title_type_id, gd.descr, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete")
	@RegisterBeanMapper(GroupEntityExtended.class)
	Optional<GroupEntityExtended> findExtendedByIdAndPartyId(@Bind("tenantId") String tenantId, @Bind("id") Long id, @Bind("partyId") Long partyId);

	@SqlQuery("select g.id, gd.pkid, g.tenant_id, g.party_id, g.title_type_id, gd.descr, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete " +
			" , min(lld.day_from) as dayFrom, max(lld.day_to) as dayTo, count(lld.id) as linkCount " +
			" from cll_group g " +
			" join cll_group_detail gd on g.id = gd.group_id  and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) " +
			" left join cll_land_link_detail lld on lld.group_id = g.id and lld.tenant_id = g.tenant_id " +
			"     and (§current_timestamp§ between lld.dt_insert and lld.dt_delete) " +
			" WHERE g.tenant_id= :tenantId " +
			" and g.id in (<ids>) " +
			" and g.party_id = :partyId " +
			" and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) " +
			" group by g.id,  gd.pkid, lld.group_id " +
			//ORA [42000][979] ORA-00979
			" ,g.tenant_id, g.party_id, g.title_type_id, gd.descr, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete")
	@RegisterBeanMapper(GroupEntityExtended.class)
	ResultIterator<GroupEntityExtended> findExtendedByIdInAndPartyId(
			@Bind("tenantId") String tenantId,
			@BindList("ids") Collection<Long> ids,
			@Bind("partyId") Long partyId);

	@SqlQuery("select g.id, gd.pkid, g.tenant_id, g.party_id, g.title_type_id, gd.descr, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete " +
			" , min(lld.day_from) as dayFrom, max(lld.day_to) as dayTo, count(lld.id) as linkCount " +
			" from cll_group g " +
			" join cll_group_detail gd on g.id = gd.group_id  and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) " +
			" left join cll_land_link_detail lld on lld.group_id = g.id and lld.tenant_id = g.tenant_id " +
			"     and (§current_timestamp§ between lld.dt_insert and lld.dt_delete) " +
			" WHERE g.tenant_id= :tenantId " +
			" and g.id in (<ids>) " +
			" and g.party_id = :partyId " +
			" and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) " +
			" group by g.id,  gd.pkid, lld.group_id " +
			//ORA [42000][979] ORA-00979
			" ,g.tenant_id, g.party_id, g.title_type_id, gd.descr, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete")
	@RegisterBeanMapper(GroupEntityExtended.class)
	void consumeExtendedByIdInAndPartyId(
			@Bind("tenantId") String tenantId,
			@BindList("ids") Collection<Long> ids,
			@Bind("partyId") Long partyId,
			Consumer<GroupEntityExtended> consumer
	);

	@SqlQuery("select g.id, gd.pkid, g.tenant_id, g.party_id, g.title_type_id, gd.descr, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete " +
			" , min(lld.day_from) as dayFrom, max(lld.day_to) as dayTo, count(lld.id) as linkCount " +
			" from cll_group g " +
			" join cll_group_detail gd on g.id = gd.group_id  and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) " +
			" join cll_land_link_detail lld_filter on lld_filter.group_id = g.id and lld_filter.tenant_id = g.tenant_id " +
			" left join cll_land_link_detail lld on lld.group_id = g.id and lld.tenant_id = g.tenant_id " +
			"     and (§current_timestamp§ between lld.dt_insert and lld.dt_delete) " +
			" WHERE g.tenant_id= :tenantId " +
			" and lld_filter.id in (<landLinkIds>) " +
			" and g.party_id = :partyId " +
			" and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) " +
			" group by g.id,  gd.pkid, lld.group_id " +
			//ORA [42000][979] ORA-00979
			" ,g.tenant_id, g.party_id, g.title_type_id, gd.descr, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete")
	@RegisterBeanMapper(GroupEntityExtended.class)
	void consumeExtendedByLandKLinkIdInAndPartyId(
			@Bind("tenantId") String tenantId,
			@BindList("landLinkIds") Collection<Long> landLinkIds,
			@Bind("partyId") Long partyId,
			Consumer<GroupEntityExtended> consumer
	);


	@SqlQuery(BASE_SEARCH
			+ " having (:referenceDate between min(lld.day_from) and max(lld.day_to)) "
			+ " ORDER BY <orderBy> ")
	@RegisterBeanMapper(GroupRes.class)
	ResultIterator<GroupRes> search(
			@Bind("referenceDate") String referenceDate,
			@Bind("partyId") Long partyId,
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx);

	@SqlQuery(BASE_SEARCH
			+ " having (:referenceDate < min(lld.day_from) or :referenceDate > max(lld.day_to)) "
			+ " ORDER BY <orderBy> ")
	@RegisterBeanMapper(GroupRes.class)
	ResultIterator<GroupRes> searchElapsed(
			@Bind("referenceDate") String referenceDate,
			@Bind("partyId") Long partyId,
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx);

	@SqlQuery(" select g.id, gd.pkid, g.tenant_id, g.party_id, g.title_type_id, gd.descr "
			+ " from cll_group g "
			+ " inner join cll_group_detail gd on g.id = gd.group_id  and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) "
			+ " WHERE g.party_id= :partyId "
			+ " and upper(gd.descr) = upper ( :descr ) "
			+ " and g.tenant_id= :tenantId "
			+ " and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) ")
	@RegisterBeanMapper(GroupEntity.class)
	List<GroupEntity> getDuplicates(
			@BindBean ReqContext ctx,
			@Bind("partyId") Long partyId,
			@Bind("descr") String descr);

	@SqlQuery("select g.id, gd.pkid, g.tenant_id, g.party_id, g.title_type_id, gd.descr, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete " +
			" , min(lld.day_from) as dayFrom, max(lld.day_to) as dayTo, count(lld.id) as linkCount " +
			" , tt.id as title_id, tt.code as title_code, tt.fl_day_to_req as title_fl_day_to_req, tt.fl_day_to_editable as title_fl_day_to_editable," +
			" tt.fl_allow_future_day_from as title_fl_allow_future_day_from, coalesce (§i18n(:tenantId, 'cll_title_type', 'code', tt.code, :lang)§, tt.code) as title_i18n_code " +
			" from cll_group g " +
			" join cll_group_detail gd on g.id = gd.group_id  and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) " +
			" left join cll_land_link_detail lld on lld.group_id = g.id and lld.tenant_id = g.tenant_id " +
			"     and (§current_timestamp§ between lld.dt_insert and lld.dt_delete) " +
			" inner join cll_title_type tt on g.title_type_id = tt.id and tt.tenant_id = g.tenant_id AND (§current_timestamp§ between tt.dt_insert and tt.dt_delete) " +
			" WHERE g.tenant_id= :tenantId " +
			" and g.id = :id " +
			" and g.party_id = :partyId " +
			" and (§current_timestamp§ between gd.dt_insert and gd.dt_delete) " +
			" group by g.id,  gd.pkid, lld.group_id "
			+ " ,g.tenant_id, g.party_id, g.title_type_id, gd.descr, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete " +
			" , tt.id, tt.code, tt.fl_day_to_req, tt.fl_day_to_editable, tt.fl_allow_future_day_from ")
	@RegisterBeanMapper(GroupRes.class)
	Optional<GroupRes> getByIdAndPartyId(@BindBean ReqContext ctx, @Bind("id") Long id, @Bind("partyId") Long partyId);

	@SqlQuery("§select_nextval(cll_group_detail_pkid_seq)§")
	Long issuePk();

	@SqlUpdate("INSERT INTO cll_group (id, tenant_id, party_id, title_type_id ) " +
			"VALUES ( :sequenceId, :tenantId, :partyId, :titleTypeId )")
	void insertMasterRow(@Bind("sequenceId") Long id, @BindBean GroupEntity entity);

	/**
	 * usato in creazione
	 * <p>
	 * unica e sola differenza tra insertDetailRow e insertVersionRow è che la prima conosce già la pk da inserire come pkid e come group_id
	 */
	@SqlUpdate("INSERT INTO cll_group_detail (pkid, group_id, descr, dt_insert, user_id_insert, dt_delete, user_id_delete) " +
			"VALUES (:sequenceId, :sequenceId, :descr, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete) ")
	void insertDetailRow(@Bind("sequenceId") Long id, @BindBean GroupEntity entity);

	/**
	 * usato in aggiornamento
	 */
	@SqlUpdate("INSERT INTO cll_group_detail (group_id, descr, dt_insert, user_id_insert, dt_delete, user_id_delete) " +
			"VALUES (:id, :descr, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	@GetGeneratedKeys("pkid")
	long insertVersionRow(@BindBean GroupEntity entity);

	@SqlUpdate("update cll_group_detail set dt_delete =:dtDelete, user_id_delete=:userIdDelete where pkid = :pkid " +
			" and (§current_timestamp§ between dt_insert and dt_delete) ")
	void expireRow(@BindBean GroupEntity entity);
}
