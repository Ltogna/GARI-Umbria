package com.abacogroup.cllapi.api.req;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class GroupCloneReq extends GroupUpdateReq {

	@NotNull
	private Long titleTypeId;

	@NotNull
	@DecimalMax("100.00")
	@DecimalMin("0.00")
	@Schema(multipleOf = 0.00000001)
	@Builder.Default
	private BigDecimal titleTypePerc = BigDecimal.valueOf(100);

}
