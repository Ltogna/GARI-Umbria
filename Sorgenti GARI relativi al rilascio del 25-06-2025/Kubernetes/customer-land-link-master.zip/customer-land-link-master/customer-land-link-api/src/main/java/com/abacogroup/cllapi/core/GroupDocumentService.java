package com.abacogroup.cllapi.core;

import com.abacogroup.cllapi.api.GroupDocumentRes;
import com.abacogroup.cllapi.api.req.GroupDocumentSearchReq;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import jakarta.ws.rs.core.Response;

public interface GroupDocumentService {

	GroupDocumentRes insert(ReqContext reqContext, Long partyId, Long groupId, InsertDocument document);

	void expire(ReqContext reqContext, Long partyId, Long groupId, Long documentId);

	GroupDocumentRes update(ReqContext reqContext, Long partyId, Long groupId, Long documentId, Document updateReq);

	GroupDocumentRes getGroupDocument(ReqContext reqContext, Long partyId, Long groupId, Long documentId);

	InfiniteListResults<GroupDocumentRes> search(ReqContext reqContext, Long partyId, Long groupId, GroupDocumentSearchReq searchReq, String nextKey);

	Long countDocumentsByGroupIdAndDefinitionCode(ReqContext reqContext, Long groupId, String code);

	Response getDocumentFileContent(ReqContext reqContext, Long partyId, Long groupId, Long documentId, String fileId);

	Response getDocumentFileMetadata(ReqContext reqContext, Long partyId, Long groupId, Long documentId, String fileId);
}
