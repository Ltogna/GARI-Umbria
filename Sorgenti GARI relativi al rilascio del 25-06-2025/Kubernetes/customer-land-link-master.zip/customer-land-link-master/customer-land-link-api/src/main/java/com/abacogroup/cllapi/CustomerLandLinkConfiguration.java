package com.abacogroup.cllapi;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.Configuration;
import io.dropwizard.db.DataSourceFactory;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class CustomerLandLinkConfiguration extends Configuration {

	private boolean cors = true;

	private String variant;

	@Valid
	@NotNull
	private DataSourceFactory database;

	private RabbitmqConfig rabbitmqConfig;

	@Valid
	private Sso2Config sso2Config;

	@Valid
	private BundleConfig bundleConfig;

	private String dynamicDocumentsBucket;

	@Valid
	private FileStoreConfig fileStoreConfig;

	@Valid
	private LpisConfig lpisConfig;

	@Valid
	private PartyConfig partyConfig;
	
	@Valid
	private PartiesAclConfig partiesAclConfig;

	@Valid
	private AnomaliesRegistryConfig anomaliesRegistryConfig;

	@Valid
	@NotNull
	@Getter
	@Setter
	private JerseyClientConfiguration jerseyClient = new JerseyClientConfiguration();

	@JsonProperty("devtools-enabled")
	private boolean devToolsEnabled = false;

	@Data
	public static class RabbitmqConfig {

		private String host;
		private String user;
		private String password;
		private String virtualhost;
		private Integer port;
	}

	@Data
	public static class FileStoreConfig {
		private String url;
	}

	@Data
	public static class LpisConfig {
		private String url;
	}

	@Data
	public static class PartyConfig {
		private String url;
	}
	
	@Data
	public static class PartiesAclConfig {
		private String url;
	}

	@Data
	public static class AnomaliesRegistryConfig {
		private String url;
	}

	@Data
	public static class Sso2Config {
		private String url;
		private String tasksAuthPhrase;
	}

	@Data
	public static class BundleConfig {

		@NotBlank
		private String configLocation;

		private String initBaseTempDir;

	}
}
