package com.abacogroup.cllapi.api.req;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import jakarta.validation.constraints.NotBlank;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class GroupDuplicatesReq {

	@Parameter(in = ParameterIn.QUERY, description = "descr")
	@QueryParam("descr")
	@NotBlank
	private String descr;

	@Parameter(in = ParameterIn.QUERY, description = "group Id")
	@QueryParam("groupId")
	private Long groupId;

}
