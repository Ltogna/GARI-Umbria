package com.abacogroup.cllapi.core.embededqueue;

import com.abacogroup.anomalyregistry.api.v1.req.AnomalyRequest;
import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyClient;
import com.abacogroup.cllapi.api.DocTypeRelationRes;
import com.abacogroup.cllapi.api.enums.DocTypeRelationScope;
import com.abacogroup.cllapi.core.dto.CllEventType;
import com.abacogroup.cllapi.db.dao.AnomaliesDAO;
import com.abacogroup.cllapi.db.dao.DAOContainer;
import com.abacogroup.cllapi.db.dao.DocTypeRelationDAO;
import com.abacogroup.cllapi.db.dao.GroupDAO;
import com.abacogroup.cllapi.db.dao.GroupDocumentDAO;
import com.abacogroup.cllapi.db.dao.LandLinkDAO;
import com.abacogroup.cllapi.db.ntt.AnomalyEntity;
import com.abacogroup.cllapi.db.ntt.LandLinkEntity;
import com.abacogroup.cllapi.db.ntt.mapper.CllAnomalyMapper;
import com.abacogroup.cllapi.resources.mapper.DocTypeRelationMapper;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.common.service.AuditHelper;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import jakarta.ws.rs.core.SecurityContext;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.ListUtils;

@Slf4j
public class AnomalyHelper {
	private static String groupPrefix = "customer-land-link.";
	private static String groupSuffixLL = "land-link";
	private static String groupSuffixDD = "dynamic-documents";

	public static final String LL_ANOMALY_P55 = "P55";
	public static final String LL_ANOMALY_P55_6 = "P55.6";
	public static final String DD_ANOMALY_ATTO = "ATTO";

	public static final String PARCEL_ENTITY_CODE = "REFERENCE_PARCEL";
	public static final String GROUP_CLL_ENTITY_CODE = "REFERENCE_CLL_GROUP";
	public static final String PARTY_CLL_ENTITY_CODE = "REFERENCE_PARTY";
	public static final String PARTY_PARCEL_ENTITY_CODE = "REFERENCE_PARTY_PARCEL";

	private final LandLinkDAO landLinkDAO;
	private final GroupDAO groupDAO;
	private final GroupDocumentDAO groupDocumentDAO;
	private final DocTypeRelationDAO docTypeRelationDAO;
	private final DocumentService documentService;

	private final Clock appClock;

	private final AnomaliesDAO anomaliesDAO;
	private final AnomalyClient anomalyClient;
	private final Sso2Client sso2Client;
	
    private static final AbsoluteDate MAX_DATE = AbsoluteDate.of("99991231");

	public AnomalyHelper(DAOContainer daocontainer,
			DocumentService documentService,
			Clock appClock, AnomalyClient anomalyClient,
			Sso2Client sso2Client) {

		this.landLinkDAO = daocontainer.getLandLinkDAO();
		this.groupDAO = daocontainer.getGroupDAO();
		this.groupDocumentDAO = daocontainer.getGroupDocumentDAO();
		this.docTypeRelationDAO = daocontainer.getDocTypeRelationDAO();
		this.documentService = documentService;
		this.appClock = appClock;
		this.anomaliesDAO = daocontainer.getAnomaliesDAO();
		this.anomalyClient = anomalyClient;
		this.sso2Client = sso2Client;
	}

	public static void setVariant(String variant) {
		groupPrefix = variant + ".";
	}

	public static String getGroupLL() {
		return groupPrefix + groupSuffixLL;
	}

	public static String getGroupDD() {
		return groupPrefix + groupSuffixDD;
	}

	public static String partyParcelEntityId(Long partyId, Long parcelId) {
		if (null == parcelId || null == partyId) {
			return null;
		}
		return partyId + "-" + parcelId;
	}

	public void onMultipleGroupEvent(CllEventType eventType, Collection<Long> groupIds, Long partyId, AbsoluteDate fromDate,
			String tenantId, String username, String lang) {
		log.info("processing {} event on groups {}", eventType, groupIds);
		ReqContext reqContext = new ReqContext(tenantId, username, lang);

		this.expireAllATTOAnomalies(reqContext, groupIds);
		groupDAO.consumeExtendedByIdInAndPartyId(tenantId, groupIds, partyId, group -> {
			//1. check DD anomalies
			this.collectATTOAnomalies(eventType, reqContext, group.getId(), group.getTitleTypeId(), group.getDayFrom(), group.getDayTo());
		});

		if (!eventType.equals(CllEventType.UPDATE_GROUP_DOCS)) {
			List<Long> allParcels = landLinkDAO.findParcelIdsByPartyIdAndGroupIdInIncludeExpired(tenantId, partyId, groupIds);

			// P55
			this.expireAllP55Anomalies(reqContext, allParcels);
			allParcels.forEach(parcelId -> this.collectP55Anomalies(reqContext, parcelId));

			// P55_6
			this.expireAllP55_6Anomalies(reqContext, allParcels, partyId);
			allParcels.forEach(parcelId -> this.collectP55_6Anomalies(reqContext, parcelId, partyId));
		}


		this.syncAnomalyRegistry(partyId, tenantId, username, lang);

	}

	public void onMultipleLandLinkEvent(CllEventType eventType, Collection<Long> linkIds, Long partyId,
			String tenantId, String username, String lang) {
		log.info("processing {} event on land links {}", eventType, linkIds);
		ReqContext reqContext = new ReqContext(tenantId, username, lang);

		//If it's a landLink event, we have to check DD anomalies for the group of this LL
		if (eventType.equals(CllEventType.UPDATE_LAND_LINKS) || eventType.equals(CllEventType.CLOSE_LAND_LINKS)) {
			groupDAO.consumeExtendedByLandKLinkIdInAndPartyId(tenantId, linkIds, partyId, group -> {
				AbsoluteDate dayTo = group.getDayTo() != null ? group.getDayTo() : MAX_DATE;
				this.expireAllATTOAnomalies(reqContext, List.of(group.getId()));
				this.collectATTOAnomalies(eventType, reqContext, group.getId(), group.getTitleTypeId(), group.getDayFrom(), dayTo);
			});
		}

		List<Long> allParcels = landLinkDAO.findParcelIdsByPartyIdInAndLandLinkIdInIncludeExpired(tenantId, partyId, linkIds);

		// P55
		this.expireAllP55Anomalies(reqContext, allParcels);
		allParcels.forEach(parcelId -> this.collectP55Anomalies(reqContext, parcelId));

		// P55_6
		this.expireAllP55_6Anomalies(reqContext, allParcels, partyId);
		allParcels.forEach(parcelId -> this.collectP55_6Anomalies(reqContext, parcelId, partyId));


		this.syncAnomalyRegistry(partyId, tenantId, username, lang);
	}

	private void expireAllATTOAnomalies(ReqContext reqContext, Collection<Long> groupIds) {
		LocalDateTime currentTimestamp = anomaliesDAO.getCurrentTimestamp();
		groupIds.stream()
				.map(this::anomalyRequestForGroupATTO)
				.map(atto -> CllAnomalyMapper.INSTANCE.toEntity(atto, null, null, reqContext.getTenantId()))
				.map(anomaliesDAO::findByAnomalyTypeAndEntity)
				.flatMap(Collection::stream)
				.forEach(actual -> AuditHelper.expire(actual, reqContext.getUsername(), anomaliesDAO::expireRow, currentTimestamp));
	}

	private void collectATTOAnomalies(CllEventType eventType, ReqContext reqContext, Long groupId, Long titleTypeId, AbsoluteDate dayFrom, AbsoluteDate dayTo) {
		log.debug("processing {} anomalies for group {} docs", DD_ANOMALY_ATTO, groupId);

		if (eventType.equals(CllEventType.CLOSE_LAND_LINKS) && LocalDate.now(appClock).isAfter(dayTo.toLocalDate())) {
			return;
		}

		// get list of doc types by groupId
		List<DocTypeRelationRes> groupDocTypes = this.getByGroupId(reqContext, groupId, titleTypeId);

		if (groupDocTypes == null || groupDocTypes.isEmpty()) {
			return;
		}

		//check if required dd are not present
		List<DocTypeRelationRes> missingGroupDocs = groupDocTypes.stream()
				.filter(dd -> dd.getFlRequired() == 1 && dd.getFlDocPresent() == 0)
				.collect(Collectors.toList());

		if (!missingGroupDocs.isEmpty()) {
			AnomalyEntity anomalyEntityForGroup = CllAnomalyMapper.INSTANCE.toEntity(anomalyRequestForGroupATTO(groupId),
					dayFrom, dayTo, reqContext.getTenantId());
			AuditHelper.setAuditForInsert(anomalyEntityForGroup, reqContext.getUsername(), anomaliesDAO);
			anomaliesDAO.insert(anomalyEntityForGroup);
		}
	}

	private void expireAllP55Anomalies(ReqContext reqContext, Collection<Long> parcelIds) {
		LocalDateTime currentTimestamp = anomaliesDAO.getCurrentTimestamp();
		parcelIds.stream()
				.map(this::anomalyRequestForParcelP55)
				.map(p55 -> CllAnomalyMapper.INSTANCE.toEntity(p55, null, null, reqContext.getTenantId()))
				.map(anomaliesDAO::findByAnomalyTypeAndEntity)
				.flatMap(Collection::stream)
				.forEach(actual -> AuditHelper.expire(actual, reqContext.getUsername(), anomaliesDAO::expireRow, currentTimestamp));
	}

	private void collectP55Anomalies(ReqContext reqContext, Long parcelId) {
		log.debug("processing {} anomalies on parcel {}", LL_ANOMALY_P55, parcelId);

		// 2. search other ll by parcelID
		List<LandLinkEntity> results = landLinkDAO.findByPartyIdAndGroupIdAndParcelIdIn(reqContext, null, null, List.of(parcelId));

		if (results == null || results.isEmpty()) {
			return;
		}

		List<LocalDate> rangeDates = this.calculateDateRanges(results);

		for (int i = 0; i < rangeDates.size() - 1; i++) {
			BigDecimal sectorPercentage = calculatePercentageOnRange(results, rangeDates.get(i), rangeDates.get(i + 1));

			AbsoluteDate validFrom = AbsoluteDate.of(rangeDates.get(i));
			AbsoluteDate validTo = AbsoluteDate.of(rangeDates.get(i + 1).minusDays(1)); // restore inclusive
			log.debug("percentage of parcel {} from {} to {}: {}", parcelId, validFrom, validTo, sectorPercentage);

			if (sectorPercentage.compareTo(BigDecimal.valueOf(100)) > 0) {
				AnomalyEntity anomalyEntity = CllAnomalyMapper.INSTANCE.toEntity(anomalyRequestForParcelP55(parcelId),
						validFrom, validTo, reqContext.getTenantId());

				AuditHelper.setAuditForInsert(anomalyEntity, reqContext.getUsername(), anomaliesDAO);
				anomaliesDAO.insert(anomalyEntity);
			}
		}
	}

	private void expireAllP55_6Anomalies(ReqContext reqContext, Collection<Long> parcelIds, Long partyId) {
		LocalDateTime currentTimestamp = anomaliesDAO.getCurrentTimestamp();
		parcelIds.stream()
				.map(parcelId -> this.anomalyRequestForPartyParcelP55_6(partyId, parcelId))
				.map(p55_6 -> CllAnomalyMapper.INSTANCE.toEntity(p55_6, null, null, reqContext.getTenantId()))
				.map(anomaliesDAO::findByAnomalyTypeAndEntity)
				.flatMap(Collection::stream)
				.forEach(actual -> AuditHelper.expire(actual, reqContext.getUsername(), anomaliesDAO::expireRow, currentTimestamp));
	}

	private void collectP55_6Anomalies(ReqContext reqContext, Long parcelId, Long partyId) {
		log.debug("processing {} anomalies on parcel {} and party {}", LL_ANOMALY_P55_6, parcelId, partyId);

		// 2. search other ll by parcelID
		List<LandLinkEntity> results = landLinkDAO.findByPartyIdAndGroupIdAndParcelIdIn(reqContext, partyId, null, List.of(parcelId));

		if (results == null || results.isEmpty()) {
			return;
		}

		List<LocalDate> rangeDates = this.calculateDateRanges(results);

		for (int i = 0; i < rangeDates.size() - 1; i++) {
			BigDecimal sectorPercentage = calculatePercentageOnRange(results, rangeDates.get(i), rangeDates.get(i + 1));

			AbsoluteDate validFrom = AbsoluteDate.of(rangeDates.get(i));
			AbsoluteDate validTo = AbsoluteDate.of(rangeDates.get(i + 1).minusDays(1)); // restore inclusive
			log.debug("percentage of parcel {} in party {} from {} to {}: {}", parcelId, partyId, validFrom, validTo, sectorPercentage);

			if (sectorPercentage.compareTo(BigDecimal.valueOf(100)) > 0) {
				AnomalyEntity anomalyEntity = CllAnomalyMapper.INSTANCE.toEntity(anomalyRequestForPartyParcelP55_6(partyId, parcelId),
						validFrom, validTo, reqContext.getTenantId());

				AuditHelper.setAuditForInsert(anomalyEntity, reqContext.getUsername(), anomaliesDAO);
				anomaliesDAO.insert(anomalyEntity);
			}
		}
	}

	private BigDecimal calculatePercentageOnRange(List<LandLinkEntity> landLinkEntities, LocalDate dayFromInclusive, LocalDate dayToExclusive) {

		LocalDate dayFromExclusive = dayFromInclusive.minusDays(1);

		return landLinkEntities.stream()
				.filter(ll -> ll.getDayFrom().toLocalDate().isBefore(dayToExclusive)
						&& ll.getDayTo().toLocalDate().isAfter(dayFromExclusive))
				.peek(ll -> log.debug(ll.toString()))
				.map(LandLinkEntity::getTitleTypePerc)
				.reduce(BigDecimal.ZERO, BigDecimal::add);
	}

	private List<LocalDate> calculateDateRanges(List<LandLinkEntity> landLinkEntities) {
		return landLinkEntities.stream()
				.flatMap(ll -> Stream.of(
						ll.getDayFrom().toLocalDate(), // inclusive
						ll.getDayTo().toLocalDate().plusDays(1))) // exclusive
				.distinct()
				.sorted(LocalDate::compareTo)
				.collect(Collectors.toList());
	}

	private void syncAnomalyRegistry(Long partyId, String tenantId, String username, String lang) {
		AbsoluteDate currentDate = AbsoluteDate.of(LocalDateTime.now(appClock));

		List<Long> allGroups = groupDAO.findGroupIdsByPartyIdIncludeExpired(tenantId, partyId);

		Map<Boolean, Set<AnomalyRequest>> attoAnomalies = allGroups.stream()
				.map(this::anomalyRequestForGroupATTO)
				.collect(Collectors.partitioningBy(
						a -> anomaliesDAO.countByAnomalyTypeAndEntity(
								CllAnomalyMapper.INSTANCE.toEntity(a, null, null, tenantId)) > 0L,
						Collectors.toSet()));

		List<Long> allParcels = landLinkDAO.findParcelIdsByPartyIdIncludeExpired(tenantId, partyId);

		Map<Boolean, Set<AnomalyRequest>> p55Anomalies = allParcels.stream()
				.map(this::anomalyRequestForParcelP55)
				.collect(Collectors.partitioningBy(
						a -> anomaliesDAO.countByAnomalyTypeAndEntity(
								CllAnomalyMapper.INSTANCE.toEntity(a, null, null, tenantId)) > 0L,
						Collectors.toSet()));

		Set<AnomalyRequest> anomaliesToAdd = new HashSet<>();
		anomaliesToAdd.addAll(attoAnomalies.get(true));
		anomaliesToAdd.addAll(p55Anomalies.get(true));

		Set<AnomalyRequest> anomaliesToExpire = new HashSet<>();
		anomaliesToExpire.addAll(attoAnomalies.get(false));
		anomaliesToExpire.addAll(p55Anomalies.get(false));

		AnomalyRequest anomalyRequestForGroupPartyATTO = anomalyRequestForPartyATTO(partyId);
		if (allGroups.isEmpty()) {
			anomaliesToExpire.add(anomalyRequestForGroupPartyATTO);
		} else {
			List<String> entityIds = allGroups.stream().map(Object::toString).collect(Collectors.toList());
			List<List<String>> chunks = ListUtils.partition(entityIds, 999);
			Long attoAnomaliesCount = chunks.stream()
					.map(chunk -> anomaliesDAO.countByAnomalyTypeAndEntityIn(tenantId, currentDate.getValue(), // <- there is a date here
							getGroupDD(), DD_ANOMALY_ATTO, GROUP_CLL_ENTITY_CODE, chunk))
					.reduce(0L, Long::sum);
			if (attoAnomaliesCount > 0L) {
				anomaliesToAdd.add(anomalyRequestForGroupPartyATTO);
			} else {
				anomaliesToExpire.add(anomalyRequestForGroupPartyATTO);
			}
		}

		AnomalyRequest anomalyRequestForParcelPartyP55_6 = anomalyRequestForPartyP55_6(partyId);
		if (allParcels.isEmpty()) {
			anomaliesToExpire.add(anomalyRequestForParcelPartyP55_6);
		} else {
			List<String> entityIds = allParcels.stream().map(parcelId -> partyParcelEntityId(partyId, parcelId)).collect(Collectors.toList());
			List<List<String>> chunks = ListUtils.partition(entityIds, 999);
			Long p55_6AnomaliesCount = chunks.stream()
					.map(chunk -> anomaliesDAO.countByAnomalyTypeAndEntityIn(tenantId, // <- there isn't a date here!!!!!!
							getGroupLL(), LL_ANOMALY_P55_6, PARTY_PARCEL_ENTITY_CODE, chunk))
					.reduce(0L, Long::sum);

			if (p55_6AnomaliesCount > 0L) {
				anomaliesToAdd.add(anomalyRequestForParcelPartyP55_6);
			} else {
				anomaliesToExpire.add(anomalyRequestForParcelPartyP55_6);
			}
		}

		this.pushAnomalies(anomaliesToAdd, anomaliesToExpire, new ReqContext(tenantId, username, lang));
	}

	/**
	 * @param anomaliesToAdd
	 * @param anomaliesToExpire
	 * @param reqContext
	 * @deprecated in attesa del nuovo anomaly registry
	 */
	@Deprecated
	private void pushAnomalies(Set<AnomalyRequest> anomaliesToAdd, Set<AnomalyRequest> anomaliesToExpire, ReqContext reqContext) {
		try {
			SecurityContext securityContext = sso2Client.createSecurityContextFromUserName(reqContext.getTenantId(), reqContext.getUsername());
			User user = (User) securityContext.getUserPrincipal();

			if (!anomaliesToExpire.isEmpty()) {
				log.info("pushing {} anomalies to expire", anomaliesToExpire.size());
				anomalyClient.expire(reqContext.getLang(), user, new ArrayList<>(anomaliesToExpire));
			}

			if (!anomaliesToAdd.isEmpty()) {
				log.info("pushing {} anomalies to add", anomaliesToAdd.size());
				anomalyClient.add(reqContext.getLang(), user, new ArrayList<>(anomaliesToAdd));
			}

		} catch (Throwable t) {
			throw new RuntimeException("error pushing anomalies", t);
		}

	}

	//------------------------------- service utilities


	public List<DocTypeRelationRes> getByGroupId(ReqContext context, Long groupId, Long titleTypeId) {
		return docTypeRelationDAO.getByTitleTypeAndScopeCode(context, titleTypeId, DocTypeRelationScope.GROUPS)
				.stream()
				.map(gd -> DocTypeRelationMapper.addFlDocPresent(context, gd, groupId, groupDocumentDAO))
				.collect(Collectors.toList());
	}

	private AnomalyRequest anomalyRequestForPartyATTO(Long partyId) {
		return new AnomalyRequest()
				.setEntityCode(PARTY_CLL_ENTITY_CODE)
				.setEntityId(partyId.toString())
				.setTypeCode(DD_ANOMALY_ATTO)
				.setTypeGroupCode(getGroupDD());
	}

	private AnomalyRequest anomalyRequestForGroupATTO(Long groupId) {
		return new AnomalyRequest()
				.setEntityCode(GROUP_CLL_ENTITY_CODE)
				.setEntityId(groupId.toString())
				.setTypeCode(DD_ANOMALY_ATTO)
				.setTypeGroupCode(getGroupDD());
	}

	private AnomalyRequest anomalyRequestForParcelP55(Long parcelId) {
		return new AnomalyRequest()
				.setEntityCode(PARCEL_ENTITY_CODE)
				.setEntityId(parcelId.toString())
				.setTypeCode(LL_ANOMALY_P55)
				.setTypeGroupCode(getGroupLL());
	}

	private AnomalyRequest anomalyRequestForPartyParcelP55_6(Long partyId, Long parcelId) {
		return new AnomalyRequest()
				.setEntityCode(PARTY_PARCEL_ENTITY_CODE)
				.setEntityId(partyParcelEntityId(partyId, parcelId))
				.setTypeCode(LL_ANOMALY_P55_6)
				.setTypeGroupCode(getGroupLL());
	}

	private AnomalyRequest anomalyRequestForPartyP55_6(Long partyId) {
		return new AnomalyRequest()
				.setEntityCode(PARTY_CLL_ENTITY_CODE)
				.setEntityId(partyId.toString())
				.setTypeCode(LL_ANOMALY_P55_6)
				.setTypeGroupCode(getGroupLL());
	}
}
