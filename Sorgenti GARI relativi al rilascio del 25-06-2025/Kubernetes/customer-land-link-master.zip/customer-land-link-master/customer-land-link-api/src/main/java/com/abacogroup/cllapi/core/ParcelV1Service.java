package com.abacogroup.cllapi.core;

import java.util.List;

import com.abacogroup.cllapi.api.req.ParcelSearchReq;
import com.abacogroup.cllcli.api.v1.LandLinkLeadingResV1;
import com.abacogroup.cllcli.api.v1.LandLinkLeadingResWithHolderResV1;
import com.abacogroup.cllcli.api.v1.ParcelSearchResponseV1;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;

public interface ParcelV1Service {

    InfiniteListResults<ParcelSearchResponseV1> search(ReqContext context, Long partyId, ParcelSearchReq searchReq, Boolean includeGeometries, Boolean includeLandCovers, Boolean includeLpisData, String nextKey, Integer pageSize);

    List<LandLinkLeadingResV1> getParcelLeadingList(ReqContext context, Long parcelId, AbsoluteDate referenceDate);

	List<LandLinkLeadingResWithHolderResV1> getParcelLeadingHistory(ReqContext reqContext, Long parcelId, Boolean loadMandatesHolders);
}
