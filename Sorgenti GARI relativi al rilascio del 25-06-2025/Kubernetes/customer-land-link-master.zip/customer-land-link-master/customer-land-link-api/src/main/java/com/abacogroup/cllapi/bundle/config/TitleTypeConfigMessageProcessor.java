package com.abacogroup.cllapi.bundle.config;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.cllapi.bundle.BundleConstants;
import com.abacogroup.cllapi.bundle.config.i18n.I18nAware;
import com.abacogroup.cllapi.bundle.config.i18n.I18nEntry;
import com.abacogroup.cllapi.bundle.config.i18n.I18nHelper;
import com.abacogroup.cllapi.bundle.config.i18n.I18nMap;
import com.abacogroup.cllapi.db.dao.I18nDAO;
import com.abacogroup.cllapi.db.dao.TitleTypeDAO;
import com.abacogroup.cllapi.db.ntt.TitleTypeEntity;
import com.abacogroup.common.service.AuditHelper;
import com.abacogroup.jdbi.model.AuditEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TitleTypeConfigMessageProcessor implements ConfigMessageProcessor {

	private final ObjectMapper mapper;
	private final TitleTypeDAO titleTypeDAO;
	private final I18nHelper i18nHelper;

	public TitleTypeConfigMessageProcessor(ObjectMapper mapper, TitleTypeDAO titleTypeDAO, I18nDAO i18nDAO) {
		this.mapper = mapper;
		this.titleTypeDAO = titleTypeDAO;
		this.i18nHelper = new I18nHelper(i18nDAO);
	}

	@Override
	public String getDomainName() {
		return BundleConstants.TITLE_TYPES;
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();
		Map<FileOperationEnum, ArrayList<Path>> map = collectFilesByOperation(message);

		map.getOrDefault(FileOperationEnum.DELETE, new ArrayList<>()).forEach(path -> removeContent(tenantId, path));
		map.getOrDefault(FileOperationEnum.DEFAULT, new ArrayList<>()).forEach(path -> addContent(tenantId, path));
	}


	private void addContent(String tenantId, Path path) {
		try {
			List<TitleTypeEntry> entries = deleteDuplicates.apply(readFileToMap(path));
			
			LocalDateTime now = titleTypeDAO.getCurrentTimestamp();
			
			entries
					.stream()
					.map(e -> TitleTypeEntity.builder()
							.setTenantId(tenantId)
							.setCode(e.getCode())
							.setFlDayToReq(e.isDayToRequired() ? 1 : 0)
							.setFlDayToEditable(e.isDayToEditable() ? 1 : 0)
							.setFlAllowFutureDayFrom(e.isAllowFutureDayFrom() ? 1: 0)
							.setUserIdInsert(BundleConstants.SYSTEM_USER)
							.setDtInsert(now)
							.setDtDelete(AuditEntity.dateActive)
							.setUserIdDelete(null)
							.build())
					.peek(e -> log.info("saving title type with code '{}' and tenant '{}'", e.getCode(), tenantId))
					.forEach(e -> {
						titleTypeDAO.findByCode(tenantId, e.getCode()).ifPresentOrElse(
									actual -> {
										e.setId(actual.getId());
										titleTypeDAO.update(e);
									},
									() -> titleTypeDAO.insert(e)
								);

												
					});

			i18nHelper.upsert(tenantId, "cll_title_type", "code", entries);
			
		} catch (Exception e) {
			throw new BundleException(String.format("error applying changes from file %s", path), e);
		}
	}

	private void removeContent(String tenantId, Path path) {
		try {
			List<DeleteTitleTypeEntry> entries = readDeleteFileToMap(path);
			List<String> codes = entries.stream().map(DeleteTitleTypeEntry::getCode).distinct().collect(Collectors.toList());

			log.info("deleting {} titleTypes for tenant {}: {}",
					codes.size(),
					tenantId,
					StringUtils.abbreviate(
							String.join(", ", codes),
							"...", 100));

			AuditHelper.expire(new TitleTypeEntity(), BundleConstants.SYSTEM_USER,
					a -> titleTypeDAO.expireRowsByKey(a, tenantId, codes),
					titleTypeDAO.getCurrentTimestamp());
		} catch (Exception e) {
			throw new BundleException(String.format("error applying changes from file %s", path), e);
		}
	}

	protected List<TitleTypeEntry> readFileToMap(Path path) {
		try {
			String json = Files.readString(path);
			return mapper.readValue(json, new TypeReference<>() {
			});
		} catch (IOException e) {
			throw new BundleException(String.format("error reading file %s", path), e);
		}
	}

	protected List<DeleteTitleTypeEntry> readDeleteFileToMap(Path path) {
		try {
			String json = Files.readString(path);
			return mapper.readValue(json, new TypeReference<>() {
			});

		} catch (IOException e) {
			throw new BundleException(String.format("error reading file %s", path), e);
		}
	}

	private static Map<FileOperationEnum, ArrayList<Path>> collectFilesByOperation(ConfigDataMessage message) {
		Function<String, FileOperationEnum> groupingPredicate = x -> {
			if (StringUtils.containsIgnoreCase(x, "delete")) {
				return FileOperationEnum.DELETE;
			} else {
				return FileOperationEnum.DEFAULT;
			}
		};

		List<Path> paths = message.getConfigFiles();
		return paths.stream()
				.filter(p -> FilenameUtils.isExtension(FilenameUtils.getName(p.getFileName().toString()).toLowerCase(), "json"))
				.collect(Collectors.groupingBy(x -> groupingPredicate.apply(x.toString()),
						Collectors.toCollection(ArrayList::new)));
	}

	private final Function<List<TitleTypeEntry>, List<TitleTypeEntry>> deleteDuplicates = (l) ->
			new ArrayList<>(l.stream()
					.collect(Collectors.groupingBy(TitleTypeEntry::getCode,
							LinkedHashMap::new,
							Collectors.reducing(new TitleTypeEntry(), (a, b) -> b)
					)).values());

	private enum FileOperationEnum {
		DELETE,
		DEFAULT,
	}

	@Data
	private static class TitleTypeEntry implements I18nAware {
		@NotNull
		private String code;

		private boolean dayToRequired = false;
		private boolean dayToEditable = false;
		private boolean allowFutureDayFrom = false;

		private I18nMap description;

		@JsonIgnore
		@Override
		public String getI18nCode() {
			return getCode();
		}

		@JsonIgnore
		@Override
		public Set<I18nEntry> getI18n() {
			return getDescription().getI18n();
		}

	}

	@Data
	private static class DeleteTitleTypeEntry {

		@NotNull
		private String code;

	}
}
