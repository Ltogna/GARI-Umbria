package com.abacogroup.cllapi.api.acl;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.constraints.NotNull;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class EntityV1 {
	
	@Schema(description = "Entity id", type = "integer", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Long id;
	
	@Schema(description = "Code of Entity", type = "string")
	private String code;
	
	@Schema(description = "Entity's name", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String name;
	
	@Schema(description = "Entity's type", implementation = EntityTypeV1.class, requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private EntityTypeV1 entityType;
	
	@Schema(description = "Registry party id", type = "string")
	private String registryPartyId;
	
	@Schema(description = "Description of the entity", type = "string")
	private String description;
	
	@Schema(description = "Entity's parent Id", type = "integer")
	private Long parentId;
	
	@Schema(description = "Parent's name", type = "string")
	private String parentName;
	
	@Schema(description = "Parent's code", type = "string")
	private String parentCode;
	
	@Schema(description = "Entity's tree path", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String path;
	
	@Schema(description = "Start validity date - format YYYYMMDD", type = "string", format = "YYYYMMDD", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private AbsoluteDate dayFrom;
	
	@Schema(description = "End validity date - format YYYYMMDD", type = "string", format = "YYYYMMDD")
	private AbsoluteDate dayTo;
	
	@Schema(description = "If true the entity is closed", type = "boolean")
	private Boolean closed;
	
	@Schema(description = "first closing day, it's always dayTo + 1; format YYYYMMDD", type = "string", format = "YYYYMMDD")
	@Getter(AccessLevel.NONE)
	private AbsoluteDate closeDay;
	
	public AbsoluteDate getCloseDay() {
	 	return !this.dayTo.equals(AbsoluteDate.of("99991231")) ? AbsoluteDate.of(this.dayTo.toLocalDate().plusDays(1)) : this.dayTo;
	}
}