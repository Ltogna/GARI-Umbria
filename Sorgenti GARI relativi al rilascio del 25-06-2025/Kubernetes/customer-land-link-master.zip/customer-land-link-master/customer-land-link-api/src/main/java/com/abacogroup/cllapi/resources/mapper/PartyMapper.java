package com.abacogroup.cllapi.resources.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partyregistry.api.v1.PartyResponseV1;

@Mapper
public interface PartyMapper {

	PartyMapper INSTANCE = Mappers.getMapper(PartyMapper.class);

	@Mapping(target = "gender", ignore = true)
	@Mapping(target = "taxCode", ignore = true)
	@Mapping(target = "vatNumber", ignore = true)
	@Mapping(target = "legalStatus", ignore = true)
	@Mapping(target = "birthDate", ignore = true)
	@Mapping(target = "deathDate", ignore = true)
	@Mapping(target = "birthMunicipality", ignore = true)
	@Mapping(target = "nationality", ignore = true)
	@Mapping(target = "birthMunicipalityDetail", ignore = true)
	@Mapping(target = "addressResidential", ignore = true)
	@Mapping(target = "addressHome", ignore = true)
	@Mapping(target = "addressBilling", ignore = true)
	@Mapping(target = "tags", ignore = true)
	PartyResponseV1 toFilteredDataPartyRes(PartyResponseV1 party);
	
}
