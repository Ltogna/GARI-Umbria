package com.abacogroup.cllapi.core;

import com.abacogroup.cllapi.api.LandLinkAnomaliesRes;
import com.abacogroup.cllapi.api.LandLinkLeadingRes;
import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.api.LandLinkSectorSummaryRes;
import com.abacogroup.cllapi.api.req.LandLinkBatchCreateReq;
import com.abacogroup.cllapi.api.req.LandLinkSearchReq;
import com.abacogroup.cllapi.api.req.LandLinkUpdateReq;
import com.abacogroup.cllapi.db.ntt.GroupEntity;
import com.abacogroup.cllapi.db.ntt.LandLinkEntity;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface LandLinkService {

	Optional<LandLinkEntity> loadEntity(String tenantId, Long id);

	Optional<LandLinkEntity> loadEntity(String tenantId, Long id, AbsoluteDate currentTime);

	LandLinkRes getRes(ReqContext reqContext, AbsoluteDate referenceDate, Long partyId, Long landLinkId);

	LandLinkAnomaliesRes getAnomalies(ReqContext reqContext, AbsoluteDate referenceDate, Long partyId, Long landLinkId);

	InfiniteListResults<LandLinkRes> search(ReqContext reqContext, AbsoluteDate referenceDate, LandLinkSearchReq searchRequest, Boolean includeLpisData, String nextKey, Integer pageSize);
	List<LandLinkRes> search(ReqContext reqContext, AbsoluteDate referenceDate, LandLinkSearchReq searchRequest);

	int countAllForSearch(ReqContext reqContext, AbsoluteDate referenceDate, LandLinkSearchReq searchRequest);

	List<LandLinkSectorSummaryRes> getSummary(ReqContext reqContext, Long partyId);

	InfiniteListResults<LandLinkRes> searchByGroup(ReqContext reqContext, Long partyId, Long groupId, String nextKey);
	List<LandLinkRes> searchByGroup(ReqContext reqContext, Long partyId, Long groupId);

	List<LandLinkEntity> insertInternal(ReqContext reqContext, GroupEntity group,
			AbsoluteDate dayFrom, AbsoluteDate dayTo, List<LandLinkBatchCreateReq> landLinks);

	List<LandLinkEntity> cloneInternal(ReqContext reqContext, GroupEntity group, BigDecimal titleTypePerc,
			AbsoluteDate dayFrom, AbsoluteDate dayTo, Long sourceGroupId);

	void closeByGroups(ReqContext reqContext, Long partyId, Collection<Long> groupIds, AbsoluteDate dayTo);

	void closeOne(ReqContext reqContext, Long partyId, Long id, AbsoluteDate dayTo);

	void closeMany(ReqContext reqContext, Long partyId, Collection<Long> ids, AbsoluteDate dayTo);

	void updateDatesByGroup(ReqContext reqContext, AbsoluteDate dayFrom, AbsoluteDate dayTo, Long groupId);

	LandLinkRes update(ReqContext reqContext, Long partyId, Long id, LandLinkUpdateReq updateReq);

	void expire(ReqContext reqContext, Long partyId, Long id);

	void expireByGroupAndParcelId(ReqContext reqContext, Long partyId, Long groupId, Long parcelId);

	void expireMany(ReqContext reqContext, Collection<Long> ids);

	void expireByGroup(ReqContext reqContext, Long partyId, Long groupId);

	List<LandLinkLeadingRes> searchByParcelIdAndRange(ReqContext context, Long parcelId, AbsoluteDate dayFrom, AbsoluteDate dayTo);
}
