package com.abacogroup.cllapi.core;

import com.abacogroup.cllapi.api.DocTypeRelationRes;
import com.abacogroup.cllapi.api.GroupDocumentDefinition;
import com.abacogroup.cllapi.api.enums.DocTypeRelationScope;
import com.abacogroup.common.resources.ReqContext;
import java.util.List;

public interface DocTypeService {
	List<DocTypeRelationRes> getByGroupIdOrLandLinkId(ReqContext context, Long groupId, Long landLinkId, DocTypeRelationScope scopeCode);

	GroupDocumentDefinition getDefinition(ReqContext reqContext, String definitionCode);
}
