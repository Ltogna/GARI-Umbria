package com.abacogroup.cllapi.resources.mapper;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;

import com.abacogroup.cllapi.api.DocumentRes;
import com.abacogroup.cllapi.exceptions.InvalidDocumentException;
import com.abacogroup.cllapi.exceptions.InvalidDocumentException.ErrEnum;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.bean.SummaryFieldDefinition;
import com.abacogroup.dynamicdocuments.bean.SummaryFieldValue;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;

public class DocumentMapper {

	public static <T extends DocumentRes> T addSummaryFields(ReqContext reqContext, T documentRes,
			DocumentTypeService documentTypeService, DocumentService documentService, String dynamicDocumentsBucket) {
		Document document = documentService.getDocumentFromId(documentRes.getDocumentId());
		Optional<DocumentDefinition> def = documentTypeService
				.getDocumentDefinition(reqContext.getTenantId(), documentRes.getDefinitionCode());

		List<SummaryFieldDefinition> summaryFields = null;
		if (def.isPresent()) {
			summaryFields = documentTypeService.getSummaryFields(def.get(), reqContext.getLang());

			List<SummaryFieldValue> listValues = documentService.getSummaryValues(def.get(), document, reqContext.getLang());
			LinkedHashMap<String, Object> summaryFieldsData = new LinkedHashMap<>();
			listValues.forEach(
					summaryFieldValue -> summaryFieldsData.put(summaryFieldValue.getCode(), summaryFieldValue.getValue())
			);
			documentRes.setSummaryFieldDefinitions(summaryFields);
			documentRes.setData(summaryFieldsData);
			documentRes.setBucketName(dynamicDocumentsBucket);
		}
		return documentRes;
	}

	public static <T extends DocumentRes> T addData(T documentRes, DocumentService documentService, String dynamicDocumentsBucket) {
		Document document = Optional.ofNullable(documentService.getDocumentFromId(documentRes.getDocumentId()))
				.orElseThrow(() -> new InvalidDocumentException(ErrEnum.DYNAMIC_DOCUMENT_NOT_FOUND, "doc not found " + documentRes.getDocumentId()));
		documentRes.setData(new LinkedHashMap<>(document.getFields()));
		documentRes.setBucketName(dynamicDocumentsBucket);
		return documentRes;
	}
}
