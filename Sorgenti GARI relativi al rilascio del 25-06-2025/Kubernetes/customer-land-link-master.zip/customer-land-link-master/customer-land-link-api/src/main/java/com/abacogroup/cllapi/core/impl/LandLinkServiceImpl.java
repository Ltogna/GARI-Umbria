package com.abacogroup.cllapi.core.impl;

import static com.abacogroup.cllapi.exceptions.LandLinkException.ErrEnum.DUPLICATED_PARCELS;
import static com.abacogroup.cllapi.exceptions.LandLinkException.ErrEnum.INVALID_DAY_FROM;
import static com.abacogroup.cllapi.exceptions.LandLinkException.ErrEnum.INVALID_DAY_TO;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.cllapi.api.LandLinkAnomaliesRes;
import com.abacogroup.cllapi.api.LandLinkLeadingRes;
import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.api.LandLinkSectorSummaryRes;
import com.abacogroup.cllapi.api.LandLinkTitleSummaryRes;
import com.abacogroup.cllapi.api.ParcelRes;
import com.abacogroup.cllapi.api.SectorRes;
import com.abacogroup.cllapi.api.TitleType;
import com.abacogroup.cllapi.api.req.LandLinkBatchCreateReq;
import com.abacogroup.cllapi.api.req.LandLinkSearchReq;
import com.abacogroup.cllapi.api.req.LandLinkUpdateReq;
import com.abacogroup.cllapi.core.AnomalyService;
import com.abacogroup.cllapi.core.LandLinkEventProducer;
import com.abacogroup.cllapi.core.LandLinkService;
import com.abacogroup.cllapi.core.LpisClientService;
import com.abacogroup.cllapi.core.TitleTypeService;
import com.abacogroup.cllapi.core.dto.AnomalyDto;
import com.abacogroup.cllapi.core.dto.AnomalyMaxLevelDto;
import com.abacogroup.cllapi.core.dto.CllEventType;
import com.abacogroup.cllapi.core.dto.LandLinkParcelDto;
import com.abacogroup.cllapi.core.embededqueue.EventPublisher;
import com.abacogroup.cllapi.db.dao.CllSettingsDAO;
import com.abacogroup.cllapi.db.dao.LandLinkDAO;
import com.abacogroup.cllapi.db.ntt.GroupEntity;
import com.abacogroup.cllapi.db.ntt.LandLinkEntity;
import com.abacogroup.cllapi.exceptions.LandLinkException;
import com.abacogroup.cllapi.exceptions.LandLinkException.ErrEnum;
import com.abacogroup.cllapi.resources.mapper.ParcelMapper;
import com.abacogroup.cllapi.resources.mapper.SectorMapper;
import com.abacogroup.cllcli.api.v1.AnomalyLevelEnum;
import com.abacogroup.cllcli.api.v1.enums.ParcelSearchLevel;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.common.service.AuditHelper;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lpisgisserver.api.v1.PublicParcel;
import com.abacogroup.lpisgisserver.api.v1.PublicSector;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.core.result.ResultIterator;

@Slf4j
public class LandLinkServiceImpl implements LandLinkService {

    private static final Boolean DO_NOT_INCLUDE_GEOMETRIES = false;
	private final LandLinkDAO landLinkDAO;
    private final TitleTypeService titleTypeService;
    private final LpisClientService lpisClientService;

    //private final AnomalyClientService anomalyClientService;
    private final AnomalyService anomalyService;

    private final LandLinkEventProducer landLinkEventProducer;
    private final EventPublisher anomalyQueue;
    private final Clock appClock;
    private final CllSettingsDAO cllSettingsDAO;

    public LandLinkServiceImpl(LandLinkDAO landLinkDAO, TitleTypeService titleTypeService, LpisClientService lpisClientService,
                               AnomalyService anomalyService, LandLinkEventProducer landLinkEventProducer, EventPublisher anomalyQueue, Clock appClock,
                               CllSettingsDAO cllSettingsDAO) {
        this.landLinkDAO = landLinkDAO;
        this.titleTypeService = titleTypeService;
        this.lpisClientService = lpisClientService;
        this.anomalyService = anomalyService;
        this.landLinkEventProducer = landLinkEventProducer;
        this.anomalyQueue = anomalyQueue;
        this.appClock = appClock;
        this.cllSettingsDAO = cllSettingsDAO;
    }

    @Override
    public Optional<LandLinkEntity> loadEntity(String tenantId, Long id) {
        return loadEntity(tenantId, id, AbsoluteDate.of(LocalDateTime.now(appClock)));
    }

    @Override
    public Optional<LandLinkEntity> loadEntity(String tenantId, Long id, AbsoluteDate currentTime) {
        return landLinkDAO.findByIdAndTenantAndReferenceDate(id, tenantId, currentTime.getValue());
    }

    @Override
    public LandLinkRes getRes(ReqContext reqContext, AbsoluteDate referenceDate, Long partyId, Long landLinkId) {

        return landLinkDAO.getByIdAndPartyIdAndReferenceDate(reqContext, landLinkId, partyId, referenceDate.getValue())
                .map(ll -> this.mapParcelData(reqContext, referenceDate, ll))
                .map(ll -> this.mapAnomalyData(reqContext, referenceDate, ll))
                .orElseThrow(() -> new LandLinkException(LandLinkException.ErrEnum.NOT_FOUND,
                        String.format("land link with id '%d' not found in tenant %s in date %s",
                                landLinkId, reqContext.getTenantId(), referenceDate.getValue())));
    }

    @Override
    public LandLinkAnomaliesRes getAnomalies(ReqContext reqContext, AbsoluteDate referenceDate, Long partyId, Long landLinkId) {
        LandLinkEntity entity = landLinkDAO.findByIdAndPartyIdAndReferenceDate(reqContext.getTenantId(), landLinkId, partyId, referenceDate.getValue())
                .orElseThrow(() -> new LandLinkException(LandLinkException.ErrEnum.NOT_FOUND,
                        String.format("link %s not found or closed in tenant %s ", landLinkId, reqContext.getTenantId())));

        Map<Long, AnomalyMaxLevelDto> anomalies = anomalyService.getLandLinksAnomalies(reqContext, referenceDate, List.of(entity));

        Map<AnomalyLevelEnum, List<AnomalySearchResponse>> anomalyLevelMap = anomalies.get(landLinkId).getAnomalies().stream()
                .collect(Collectors.groupingBy(AnomalyDto::getLevel,
                        Collectors.mapping(AnomalyDto::getAnomaly, Collectors.toList())));

        return new LandLinkAnomaliesRes(anomalyLevelMap);
    }

    @Override
    public InfiniteListResults<LandLinkRes> search(ReqContext reqContext, AbsoluteDate referenceDate, LandLinkSearchReq searchRequest,
                                                   Boolean includeLpisData, String nextKey, Integer pageSize) {
        Criteria criteria = searchRequest.getCriteria(reqContext);
        OrderBy sort = searchRequest.getSortComplete();
        String separator = getLpisSubSeparator(reqContext);

        InfiniteListResults<LandLinkRes> results;
        if (searchRequest.getAnomalyLevel() != null) {
            results = this.doSearchWithAnomalies(reqContext, referenceDate, searchRequest.getAnomalyLevel(),
                    criteria, sort, nextKey, searchRequest.getPageSize());
        } else {
            results = landLinkDAO.infinite(
                    () -> landLinkDAO.search(referenceDate.getValue(), separator, criteria, sort, reqContext),
                    nextKey, pageSize != null ? pageSize : searchRequest.getPageSize());

            this.mapAnomalyData(reqContext, referenceDate, results);
        }

        if (Boolean.TRUE.equals(includeLpisData)) {
            mapParcelData(reqContext, searchRequest.getIncludeGeometries(), referenceDate, results);
        }
        return results;
    }

    @Override
    public List<LandLinkRes> search(ReqContext reqContext, AbsoluteDate referenceDate, LandLinkSearchReq searchRequest) {
        Criteria criteria = searchRequest.getCriteria(reqContext);
        OrderBy sort = searchRequest.getSortComplete();
        String separator = getLpisSubSeparator(reqContext);

        List<LandLinkRes> results = new ArrayList<>();
        landLinkDAO.useTransaction(handle -> {
            try (ResultIterator<LandLinkRes> resultIterator = handle.search(referenceDate.getValue(), separator, criteria, sort, reqContext)) {
                resultIterator.forEachRemaining(results::add);
            }
        });
        mapParcelData(reqContext, DO_NOT_INCLUDE_GEOMETRIES, referenceDate, results);

        return results;
    }

    protected InfiniteListResults<LandLinkRes> doSearchWithAnomalies(ReqContext reqContext, AbsoluteDate referenceDate,
                                                                     AnomalyLevelEnum wantedLevel, Criteria criteria, OrderBy sort, String nextKey, int pageSize) {
        String tmpNextKey = nextKey;
        String separator = getLpisSubSeparator(reqContext);
        List<LandLinkRes> results = new ArrayList<>();
        do {
            InfiniteListResults<LandLinkRes> page = landLinkDAO.infinite(
                    () -> landLinkDAO.search(referenceDate.getValue(), separator, criteria, sort, reqContext),
                    tmpNextKey, pageSize);

            Map<Long, AnomalyMaxLevelDto> landLinksAnomalies = anomalyService.getLandLinksAnomalies(reqContext, referenceDate, page.getRecords());

            page.getRecords().stream()
                    .filter(ll -> landLinksAnomalies.get(ll.getId()).getAnomalies().stream()
                            .map(AnomalyDto::getLevel)
                            .anyMatch(wantedLevel::equals))
                    .map(ll -> {
                        AnomalyMaxLevelDto anomalyMaxLevelDto = landLinksAnomalies.get(ll.getId());
                        
                        ll.setMaxAnomalyLevel(anomalyMaxLevelDto.getMaxLevel());
                        ll.setAnomalyCount(anomalyMaxLevelDto.getAnomalyCount());
                        ll.setAnomalies(anomalyMaxLevelDto.getAnomalies()
                                .stream()
                                .map(AnomalyDto::getAnomaly)
                                .collect(Collectors.toList())
                        );
                        
                        return ll;
                    })
                    .forEach(results::add);

            tmpNextKey = page.getNextKey();
        } while (results.size() < pageSize && tmpNextKey != null);

        return new InfiniteListResultsImpl<>(results, tmpNextKey);
    }

    @Override
    public int countAllForSearch(ReqContext reqContext, AbsoluteDate referenceDate, LandLinkSearchReq searchRequest) {
        Criteria criteria = searchRequest.getCriteria(reqContext);
        return landLinkDAO.countAllForSearch(referenceDate.getValue(), criteria, reqContext);
    }

    @Override
    public List<LandLinkSectorSummaryRes> getSummary(ReqContext reqContext, Long partyId) {
        AbsoluteDate today = AbsoluteDate.of(LocalDateTime.now(appClock));

        Map<String, Map<Long, Collection<LandLinkParcelDto>>> summaryIdMap = this.loadSummaryData(reqContext, partyId, today);

        List<TitleType> titleTypes = titleTypeService.searchAll(reqContext);

        List<LandLinkSectorSummaryRes> summaryRes = new ArrayList<>();
        summaryIdMap.forEach((sectorCode, titlesMap) -> {
            PublicSector sector = lpisClientService.getSectorDetails(reqContext, sectorCode);
            LandLinkSectorSummaryRes sectorSummaryRes = this.buildSectorSummary(titlesMap, SectorMapper.INSTANCE.toSectorRes(sector));

            List<LandLinkTitleSummaryRes> titleSummaryRes = titleTypes.stream()
                    .map(titleType -> this.buildTitleSummary(titlesMap.getOrDefault(titleType.getId(), new HashSet<>()), titleType))
                    .collect(Collectors.toList());

            sectorSummaryRes.setTitleSummaryRes(titleSummaryRes);

            summaryRes.add(sectorSummaryRes);
        });

        summaryRes.sort(Comparator.comparing(llss -> llss.getSector().getShortDescr()));
        return summaryRes;
    }

    private LandLinkTitleSummaryRes buildTitleSummary(Collection<LandLinkParcelDto> landLinks, TitleType titleType) {
        LandLinkTitleSummaryRes titleSummaryRes = new LandLinkTitleSummaryRes()
                .setTitleType(titleType);

        titleSummaryRes.setLinkCount((long) landLinks.size());

        titleSummaryRes.setTotParcelAreaSqm(landLinks.stream()
                .map(LandLinkParcelDto::getAreaSqm)
                .reduce(0L, Long::sum));

        titleSummaryRes.setTotTitleTypeAreaSqm(landLinks.stream()
                .map(LandLinkParcelDto::getTitleTypeAreaSqm)
                .reduce(0L, Long::sum));
        return titleSummaryRes;
    }

    private LandLinkSectorSummaryRes buildSectorSummary(Map<Long, Collection<LandLinkParcelDto>> titlesMap, SectorRes sectorRes) {

        LandLinkSectorSummaryRes sectorSummaryRes = new LandLinkSectorSummaryRes()
                .setSector(sectorRes);

        sectorSummaryRes.setLinkCount(titlesMap.values().stream()
                .flatMap(Collection::stream)
                .map(LandLinkParcelDto::getParcelId)
                .distinct()
                .count());

        sectorSummaryRes.setTotParcelAreaSqm(titlesMap.values().stream()
                .flatMap(Collection::stream)
                .map(LandLinkParcelDto::getAreaSqm)
                .reduce(0L, Long::sum));

        sectorSummaryRes.setTotTitleTypeAreaSqm(titlesMap.values().stream()
                .flatMap(Collection::stream)
                .map(LandLinkParcelDto::getTitleTypeAreaSqm)
                .reduce(0L, Long::sum));
        return sectorSummaryRes;
    }

    private Map<String, Map<Long, Collection<LandLinkParcelDto>>> loadSummaryData(ReqContext reqContext, Long partyId, AbsoluteDate today) {
        Map<String, Map<Long, Collection<LandLinkParcelDto>>> summaryIdMap = new HashMap<>();
        Map<Long, List<LandLinkParcelDto>> parcelsWithoutArea = new HashMap<>();

        landLinkDAO.useTransaction(h -> {
            try (ResultIterator<LandLinkEntity> resultIterator = h.findMinimalByPartyIdAndReferenceDate(partyId, reqContext.getTenantId(),
                    today.getValue())) {
                resultIterator.forEachRemaining(ll -> {
                    Collection<LandLinkParcelDto> landLinkParcelDtos = summaryIdMap.computeIfAbsent(ll.getSectorCode(), k -> new HashMap<>())
                            .computeIfAbsent(ll.getTitleTypeId(), k -> new HashSet<>());

                    LandLinkParcelDto landLinkParcelDto = new LandLinkParcelDto(ll.getParcelId(), ll.getTitleTypePerc(), 0L);

                    parcelsWithoutArea.computeIfAbsent(ll.getParcelId(), k -> new ArrayList<>()).add(landLinkParcelDto);
                    landLinkParcelDtos.add(landLinkParcelDto);
                });
            }
        });

        lpisClientService.consumeParcelsByIdIn(reqContext, DO_NOT_INCLUDE_GEOMETRIES, today, new ArrayList<>(parcelsWithoutArea.keySet()),
                parcel -> parcelsWithoutArea.get(parcel.getId()).forEach(dto -> dto.setAreaSqm(parcel.getAreaSqm())));

        return summaryIdMap;
    }

    @Override
    public InfiniteListResults<LandLinkRes> searchByGroup(ReqContext reqContext, Long partyId, Long groupId, String nextKey) {
        LandLinkSearchReq emptySearchReq = new LandLinkSearchReq();
        OrderBy sort = emptySearchReq.getSortComplete();
        String separator = getLpisSubSeparator(reqContext);

        InfiniteListResults<LandLinkRes> results = landLinkDAO.infinite(
                () -> landLinkDAO.searchByGroup(partyId, groupId, separator, sort, reqContext),
                nextKey, emptySearchReq.getPageSize());

        AbsoluteDate today = AbsoluteDate.of(LocalDateTime.now(appClock));
        mapAnomalyData(reqContext, today, results);
        mapParcelData(reqContext, DO_NOT_INCLUDE_GEOMETRIES, today, results);

        return results;
    }
    
    @Override
    public List<LandLinkRes> searchByGroup(ReqContext reqContext, Long partyId, Long groupId) {
    	LandLinkSearchReq emptySearchReq = new LandLinkSearchReq();
    	OrderBy sort = emptySearchReq.getSortComplete();
    	String separator = getLpisSubSeparator(reqContext);

        List<LandLinkRes> results = new ArrayList<>();
        landLinkDAO.useTransaction(handle -> {
            try (ResultIterator<LandLinkRes> resultIterator = handle.searchByGroup(partyId, groupId, separator, sort, reqContext)) {
                resultIterator.forEachRemaining(results::add);
            }
        });
    	
    	AbsoluteDate today = AbsoluteDate.of(LocalDateTime.now(appClock));
    	mapAnomalyData(reqContext, today, results);
    	mapParcelData(reqContext, DO_NOT_INCLUDE_GEOMETRIES, today, results);
    	
    	return results;
    }

    @Override
    public List<LandLinkLeadingRes> searchByParcelIdAndRange(ReqContext context, Long parcelId, AbsoluteDate dayFrom, AbsoluteDate dayTo) {
        //  input GROUP    01/03/2023         999912				PROPRTY
        //  x			   01/01/2020		  999912     < FOUND (intersect)
        //  x			   01/01/2020		  01/03/2023 < NOT FOUND
        //  x			   01/01/2020		  28/02/2023 < NOT FOUND
        //  x			   01/01/2020		  02/03/2023 <  FOUND (intersect)

        //  input GROUP    01/03/2023         10/06/2030				AFFITTO
        //  x			   01/01/2020		  999912     				< FOUND (intersect)
        //  x			   10/03/2023		  10/03/2024 				< FOUND (intersect)
        //  x			   01/01/2020		  01/03/2023 				< NOT FOUND
        //  x			   01/01/2020		  28/02/2023 				< NOT FOUND
        //  x			   01/01/2020		  02/03/2023 				< FOUND (intersect)

        // (:dayFrom < cll_land_link_detail.day_to)
        //return landLinkDAO.searchByParcelIdAndRange(parcelId, dayFrom.getValue(), context);
        return landLinkDAO.searchByParcelIdAndRange(parcelId, dayFrom.getValue(), dayTo.getValue(), context);
    }

    public List<LandLinkEntity> findByPartyIdAndParcelIdInAndGroupNotInRange(ReqContext context, Long partyId, Long groupId, AbsoluteDate dayFrom,
                                                                             AbsoluteDate dayTo,
                                                                             List<Long> parcelIds) {

        String to = Optional.ofNullable(StringUtils.trimToNull(dayTo.getValue())).orElse("99991231");
        return landLinkDAO.findByPartyIdAndParcelIdInAndGroupNotInRange(context, groupId, partyId, dayFrom.getValue(), to, parcelIds);
    }

    @Override
    public List<LandLinkEntity> insertInternal(ReqContext reqContext, GroupEntity group,
                                               AbsoluteDate dayFrom, AbsoluteDate dayTo, List<LandLinkBatchCreateReq> landLinks) {

        //
    	AbsoluteDate referenceDate = dayTo; // dayFrom is not correct because the landlink is created now or in dayto
    	if(dayTo.toLocalDate().isAfter(LocalDate.now(appClock))) {
    		referenceDate = AbsoluteDate.of(LocalDate.now(appClock));
    	}
    	
    	List<LandLinkBatchCreateReq> updatedLandLinks = persistTemporaryParcels(reqContext, landLinks);
    	
        List<PublicParcel> parcels = lpisClientService.getParcelsByIdIn(reqContext, referenceDate,
        		updatedLandLinks.stream().map(LandLinkBatchCreateReq::getParcelId).distinct().collect(Collectors.toList()), 
        		ParcelSearchLevel.SEARCH_OUTDATED);
        Map<Long, PublicParcel> publicParcelMap = parcels.stream()
                .collect(Collectors.toMap(PublicParcel::getId,
                        Function.identity()));

        return landLinkDAO.inTransaction(handle -> {

            Set<Long> parcelIds = updatedLandLinks.stream().map(LandLinkBatchCreateReq::getParcelId).collect(Collectors.toSet());
            List<LandLinkEntity> alreadyPresentParcels = handle.findByPartyIdAndGroupIdAndParcelIdIn(reqContext,
                    group.getPartyId(), group.getId(), parcelIds);
            Map<Long, AbsoluteDate> parcelsDayToMap = alreadyPresentParcels.stream()
                    .collect(Collectors.groupingBy(
                            LandLinkEntity::getParcelId,
                            Collectors.mapping(LandLinkEntity::getDayTo,
                                    Collectors.reducing(AbsoluteDate.of(dayFrom.toLocalDate().minusDays(1)),
                                            BinaryOperator.maxBy(Comparator.comparing(AbsoluteDate::toLocalDate))))
                    ));

            LandLinkEntity[] landLinkEntities = updatedLandLinks.stream()
                    .map(req -> mapToEntity(reqContext, group, dayFrom, dayTo, parcelsDayToMap,
                            req, publicParcelMap.get(req.getParcelId()), handle.issuePk()))
                    .toArray(LandLinkEntity[]::new);

            AuditHelper.setAuditForInsert(reqContext.getUsername(), handle, landLinkEntities);

            handle.insertNew(landLinkEntities);

            return new ArrayList<>(List.of(landLinkEntities));

        });

    }

    @Deprecated
    private void checkForDuplicateLandLinks(ReqContext reqContext, GroupEntity group, List<LandLinkBatchCreateReq> landLinks) {

    	List<LandLinkRes> oldLandLinksList = searchByGroup(reqContext, group.getPartyId(), group.getId());

    	landLinks.forEach(l -> oldLandLinksList.stream()
    			.filter(oldLink -> l.getParcelId().equals(oldLink.getParcel().getId()))
    			.findAny()
    			.ifPresent(v -> {
    				throw new LandLinkException(LandLinkException.ErrEnum.DUPLICATED_PARCELS, 
    						String.format("found duplicate parcel! id: %s", v.getParcel().getId()));
    			}));
    }

	private List<LandLinkBatchCreateReq> persistTemporaryParcels(ReqContext reqContext, List<LandLinkBatchCreateReq> landLinks) {
    	if(landLinks == null || landLinks.isEmpty()) {
    		return new ArrayList<>();
    	}

    	List<LandLinkBatchCreateReq> updatedList = new ArrayList<>();

    	landLinks.forEach(link -> {
    		if(link.getParcelId() > 0) {
    			updatedList.add(link);
    		} else {
    			PublicParcel parcel = lpisClientService.persistTemporaryParcels(reqContext, link.getParcelId());
    			updatedList.add(LandLinkBatchCreateReq.builder()
    					.setParcelId(parcel.getId())
    					.setTitleTypePerc(link.getTitleTypePerc())
    					.build());
    		}
    	});

    	return updatedList;		
    }

    @Deprecated
	private void validateOverlaps(ReqContext reqContext, GroupEntity group,
                                  AbsoluteDate dayFrom, AbsoluteDate dayTo, LandLinkEntity[] landLinks) {
        List<LandLinkEntity> list = this.findByPartyIdAndParcelIdInAndGroupNotInRange(
                reqContext, group.getPartyId(), group.getId(), dayFrom, dayTo,
                Arrays.stream(landLinks).map(LandLinkEntity::getParcelId).distinct().collect(Collectors.toList()));

        if (!list.isEmpty()) {
            String parcelRefs = list.stream()
                    .map(l -> l.getParcelId().toString())
                    .collect(Collectors.joining(", "));

            String msg = String.format("found %s duplicates parcels! id: %s", list.size(), StringUtils.abbreviate(parcelRefs, "...", 200));
            throw new LandLinkException(DUPLICATED_PARCELS, msg);
        }
    }

    @Override
    public List<LandLinkEntity> cloneInternal(ReqContext reqContext, GroupEntity group, BigDecimal titleTypePerc,
                                              AbsoluteDate dayFrom, AbsoluteDate dayTo, Long sourceGroupId) {

        return landLinkDAO.inTransaction(handle -> {

            Set<Long> mappedParcels = new HashSet<>();
            LandLinkEntity[] landLinkEntities = StreamSupport.stream(Spliterators.spliteratorUnknownSize(
                            landLinkDAO.findByGroupIdInAndPartyId(
                                    List.of(sourceGroupId), group.getPartyId(), reqContext.getTenantId()),
                            Spliterator.ORDERED), false)
                    .filter(source -> mappedParcels.add(source.getParcelId()))
                    .map(source -> this.mapToClonedEntity(reqContext, group, titleTypePerc, dayFrom, dayTo, source, handle.issuePk()))
                    .toArray(LandLinkEntity[]::new);

            AuditHelper.setAuditForInsert(reqContext.getUsername(), handle, landLinkEntities);

            handle.insertNew(landLinkEntities);

            return new ArrayList<>(List.of(landLinkEntities));

        });

    }

    /**
     * closes only ll where ll.day_to > dayTo
     * TODO ask about ll closed before dayTo
     *
     * @param reqContext
     * @param partyId
     * @param groupIds
     * @param dayTo
     */
    @Override
    public void closeByGroups(ReqContext reqContext, Long partyId, Collection<Long> groupIds, AbsoluteDate dayTo) {

        Integer landLinkStartingAfterDayToCount = landLinkDAO.countByGroupIdInAndPartyIdAndDayFromBefore(
                groupIds, partyId, dayTo.getValue(), reqContext.getTenantId());
        if (landLinkStartingAfterDayToCount > 0) {
            throw new LandLinkException(INVALID_DAY_TO, String.format("there are %s land links starting after %s", landLinkStartingAfterDayToCount, dayTo));
        }

        this.doClose(reqContext, partyId, dayTo,
                () -> landLinkDAO.findByGroupIdInAndPartyIdAndReferenceDate(
                        groupIds, partyId, dayTo.getValue(), reqContext.getTenantId()));
    }

    @Override
    public void closeOne(ReqContext reqContext, Long partyId, Long id, AbsoluteDate dayTo) {

        LandLinkEntity landLinkEntity = landLinkDAO.findByIdAndPartyId(reqContext.getTenantId(), id, partyId)
                .orElseThrow(() -> new LandLinkException(LandLinkException.ErrEnum.NOT_FOUND,
                        String.format("link %s does not exist", id)));

        if (dayTo.equals(landLinkEntity.getDayTo())) {
            return;
        }

        Integer landLinkStartingAfterDayToCount = landLinkDAO.countByLandLinkIdInAndPartyIdAndDayFromBeforeUsingParcelIds(
                List.of(id), partyId, dayTo.getValue(), reqContext.getTenantId());
        if (landLinkStartingAfterDayToCount > 0) {
            throw new LandLinkException(INVALID_DAY_TO, String.format("there are %s land links starting after %s with same parcel", landLinkStartingAfterDayToCount, dayTo));
        }

        this.doClose(reqContext, partyId, dayTo, () -> List.of(landLinkEntity).iterator());
    }

    @Override
    public void closeMany(ReqContext reqContext, Long partyId, Collection<Long> ids, AbsoluteDate dayTo) {
        Integer landLinkStartingAfterDayToCount = landLinkDAO.countByLandLinkIdInAndPartyIdAndDayFromBeforeUsingParcelIds(
                ids, partyId, dayTo.getValue(), reqContext.getTenantId());
        if (landLinkStartingAfterDayToCount > 0) {
            throw new LandLinkException(INVALID_DAY_TO, String.format("there are %s land links starting after %s with same parcel", landLinkStartingAfterDayToCount, dayTo));
        }

        this.doClose(reqContext, partyId, dayTo,
                () -> landLinkDAO.findByIdInAndPartyId(ids, partyId, reqContext.getTenantId()));
    }

    private void doClose(ReqContext reqContext, Long partyId, AbsoluteDate dayTo, Supplier<Iterator<LandLinkEntity>> llResultIteratorSupplier) {
        if (dayTo == null || StringUtils.isBlank(dayTo.getValue())) {
            throw new LandLinkException(INVALID_DAY_TO, "close date cannot be null");
            //} else if (LocalDate.now(appClock).isBefore(dayTo.toLocalDate())) {
            //throw new LandLinkException(INVALID_DAY_TO, "close date cannot be in the future");
            // 77 remove perché la data di end puo essere rivesta, purché nel range
            // si può solo tornare indietro|
            //  |___________|
            //  |_______|
            //  |____|
            //  |____|__x  < illegal
        }

        Boolean allowEditDayToParcelInThePast = cllSettingsDAO.getOne(reqContext.getTenantId())
                .getAllowEditDayToParcelInThePast();
        LocalDate now = LocalDate.now(appClock);
        List<Long> updatedIds = new ArrayList<>();
        landLinkDAO.useTransaction(handle -> {
            Iterator<LandLinkEntity> llResultIterator = null;
            List<AbsoluteDate> allDayFrom = new ArrayList<>();
            try {
                llResultIterator = llResultIteratorSupplier.get();
                llResultIterator.forEachRemaining(ll -> {
                    checkCloseDayToValidity(reqContext, dayTo, allowEditDayToParcelInThePast, now, ll);

                    ll.setDayTo(dayTo);

                    log.debug("closing land link {}", ll);
                    LandLinkEntity landLinkEntity = doUpdate(reqContext, handle, ll);
                    updatedIds.add(landLinkEntity.getId());
                    allDayFrom.add(ll.getDayFrom());
                });
            } finally {
                if (llResultIterator instanceof ResultIterator) {
                    ((ResultIterator<?>) llResultIterator).close();
                }
            }

            if (!updatedIds.isEmpty()) {
                landLinkEventProducer.pushLandLinkEvent(updatedIds, partyId,
                        reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), CllEventType.CLOSE_LAND_LINKS);
                AbsoluteDate fromDate = allDayFrom.stream()
                        .min(Comparator.comparing(AbsoluteDate::toLocalDate))
                        .orElse(null);
                anomalyQueue.pushLandLinkEvent(updatedIds, fromDate, partyId,
                        reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), CllEventType.CLOSE_LAND_LINKS);
            }
        });

    }

	private void checkCloseDayToValidity(ReqContext reqContext, AbsoluteDate dayTo,
			Boolean allowEditDayToParcelInThePast, LocalDate now, LandLinkEntity ll) {
		if (ll.getDayTo().equals(dayTo)) {
		    return;
		}

		if (!allowEditDayToParcelInThePast && now.isAfter(ll.getDayTo().toLocalDate())) {
		    throw new LandLinkException(LandLinkException.ErrEnum.CLOSED_LAND_LINK,
		            String.format("land link with id '%d' and tenant %s was closed on %s",
		                    ll.getId(), reqContext.getTenantId(), ll.getDayTo()));
		}

		if (dayTo.toLocalDate().isAfter(ll.getDayTo().toLocalDate())) {
		    throw new LandLinkException(INVALID_DAY_TO,
		            String.format("close date cannot be after %s in land link with id '%s' and tenant %s",
		                    ll.getDayTo(), ll.getId(), reqContext.getTenantId()));
		}
		if (dayTo.toLocalDate().isBefore(ll.getDayFrom().toLocalDate())) {
		    throw new LandLinkException(INVALID_DAY_TO,
		            String.format("invalid date range %s - %s in land link with id '%s' and tenant %s",
		                    ll.getDayFrom(), dayTo, ll.getId(), reqContext.getTenantId()));
		}
	}

    @Override
    public void updateDatesByGroup(ReqContext reqContext, AbsoluteDate dayFrom, AbsoluteDate dayTo, Long groupId) {

        AbsoluteDate today = AbsoluteDate.of(LocalDateTime.now(appClock));

        landLinkDAO.useTransaction(handle -> {
            try (ResultIterator<LandLinkEntity> llResultIterator = handle.findByGroupIdAndTenant(groupId, reqContext.getTenantId())) {
                Map<Long, List<LandLinkEntity>> llByParcel = StreamSupport.stream(Spliterators.spliteratorUnknownSize(llResultIterator, 0), false)
                        .collect(Collectors.groupingBy(LandLinkEntity::getParcelId));

                for (List<LandLinkEntity> sameParcelLls : llByParcel.values()) {
                    checkParcelsLandLinkRangeDate(dayFrom, dayTo, sameParcelLls);

                    if (sameParcelLls.size() == 1) {
                        LandLinkEntity ll = sameParcelLls.get(0);
                        ll.setDayFrom(dayFrom);
                        setParcelLandLinkDayToOrThrow(dayTo, today, ll);
                        doUpdate(reqContext, handle, ll);
                    } else {
                        sameParcelLls.stream().min(Comparator.comparing(ll -> ll.getDayFrom().toLocalDate()))
                                .ifPresent(ll -> {
                                    ll.setDayFrom(dayFrom);
                                    doUpdate(reqContext, handle, ll);
                                });
                        sameParcelLls.stream().max(Comparator.comparing(ll -> ll.getDayTo().toLocalDate()))
                                .ifPresent(ll -> {
                                    setParcelLandLinkDayToOrThrow(dayTo, today, ll);
                                    doUpdate(reqContext, handle, ll);
                                });
                    }
                }
            }
        });
    }

	private void setParcelLandLinkDayToOrThrow(AbsoluteDate dayTo, AbsoluteDate today, LandLinkEntity ll) {
		if (!ll.getDayTo().toLocalDate().isBefore(today.toLocalDate())) {
		    ll.setDayTo(dayTo);
		}
		if (ll.getDayTo().toLocalDate().isBefore(ll.getDayFrom().toLocalDate())) {
		    throw new LandLinkException(INVALID_DAY_TO, String.format("invalid date range %s - %s in land link '%s'",
		            ll.getDayFrom(), ll.getDayTo(), ll.getId()));
		}
	}

	private void checkParcelsLandLinkRangeDate(AbsoluteDate dayFrom, AbsoluteDate dayTo,
			List<LandLinkEntity> sameParcelLls) {
		for (LandLinkEntity ll : sameParcelLls) {
		    if (ll.getDayFrom().toLocalDate().isAfter(dayTo.toLocalDate())) {
		        throw new LandLinkException(INVALID_DAY_TO, String.format("invalid date range %s - %s in land link '%s'",
		                ll.getDayFrom(), dayTo, ll.getId()));
		    }
		    if (ll.getDayTo().toLocalDate().isBefore(dayFrom.toLocalDate())) {
		        throw new LandLinkException(INVALID_DAY_FROM, String.format("invalid date range %s - %s in land link '%s'",
		                dayFrom, ll.getDayTo(), ll.getId()));
		    }
		}
	}

    @Override
    public LandLinkRes update(ReqContext reqContext, Long partyId, Long id, LandLinkUpdateReq updateReq) {

        AbsoluteDate today = AbsoluteDate.of(LocalDateTime.now(appClock));
        var entity = landLinkDAO.findByIdAndPartyIdAndReferenceDate(reqContext.getTenantId(), id, partyId, today.getValue())
                .orElseThrow(() -> new LandLinkException(LandLinkException.ErrEnum.NOT_FOUND,
                        String.format("link %s not found or closed in tenant %s ", id, reqContext.getTenantId())));

        entity.setTitleTypePerc(updateReq.getTitleTypePerc());

        landLinkDAO.useTransaction(handle -> {

            doUpdate(reqContext, handle, entity);
            Long updatedLandLinkId = entity.getId();
            landLinkEventProducer.pushLandLinkEvent(List.of(updatedLandLinkId), partyId,
                    reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), CllEventType.UPDATE_LAND_LINKS);

            anomalyQueue.pushLandLinkEvent(List.of(updatedLandLinkId), entity.getDayFrom(), partyId,
                    reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), CllEventType.UPDATE_LAND_LINKS);
        });

        return this.getRes(reqContext, today, entity.getPartyId(), entity.getId());
    }

    @Override
    public void expire(ReqContext reqContext, Long partyId, Long id) {

    	Optional<LandLinkEntity> landLink = landLinkDAO.findByIdAndTenant(id, reqContext.getTenantId());
    	
    	landLink.ifPresent(landLinkEntity -> landLinkDAO.useTransaction(handle -> {
    		Consumer<LandLinkEntity> expire = handle::expireRow;
    		AuditHelper.expire(landLinkEntity, reqContext.getUsername(), expire, handle.getCurrentTimestamp());
    		
    		landLinkEventProducer.pushLandLinkEvent(List.of(landLinkEntity.getId()), partyId,
                    reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), CllEventType.CLOSE_LAND_LINKS, List.of(landLinkEntity.getPkid()));

            anomalyQueue.pushLandLinkEvent(List.of(landLinkEntity.getId()), landLinkEntity.getDayFrom(), partyId,
                    reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), CllEventType.CLOSE_LAND_LINKS);
    	}));
    }

    @Override
    public void expireByGroupAndParcelId(ReqContext reqContext, Long partyId, Long groupId, Long parcelId) {

        landLinkDAO.useTransaction(handle -> {

            List<LandLinkEntity> landLinkEntities = handle.findByPartyIdAndGroupIdAndParcelIdIn(reqContext, partyId, groupId, List.of(parcelId));
            List<Long> expiredIds = new ArrayList<>();
            List<Long> expiredPkids = new ArrayList<>();
            List<AbsoluteDate> allDayFrom = new ArrayList<>();
            for (LandLinkEntity landLinkEntity : landLinkEntities) {
                Consumer<LandLinkEntity> expire = handle::expireRow;
                AuditHelper.expire(landLinkEntity, reqContext.getUsername(), expire, handle.getCurrentTimestamp());

                expiredIds.add(landLinkEntity.getId());
                expiredPkids.add(landLinkEntity.getPkid());
                allDayFrom.add(landLinkEntity.getDayFrom());
            }

            if (!expiredIds.isEmpty()) {
                landLinkEventProducer.pushLandLinkEvent(expiredIds, partyId,
                        reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), CllEventType.CLOSE_LAND_LINKS, expiredPkids);
                AbsoluteDate fromDate = allDayFrom.stream()
                        .min(Comparator.comparing(AbsoluteDate::toLocalDate))
                        .orElse(null);
                anomalyQueue.pushLandLinkEvent(expiredIds, fromDate, partyId,
                        reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), CllEventType.CLOSE_LAND_LINKS);
            }
        });
    }

    @Override
    public void expireMany(ReqContext reqContext, Collection<Long> ids) {

        landLinkDAO.useTransaction(handle -> {
            Consumer<LandLinkEntity> expire = auditEntity -> handle.expireByIdIn(auditEntity, reqContext.getTenantId(), ids);
            AuditHelper.expire(new LandLinkEntity(), reqContext.getUsername(), expire, handle.getCurrentTimestamp());

        });

    }

    @Override
    public void expireByGroup(ReqContext reqContext, Long partyId, Long groupId) {

    	List<LandLinkEntity> landLinks = landLinkDAO.findByGroupIdAndPartyId(groupId, partyId, reqContext.getTenantId());
        landLinkDAO.useTransaction(handle -> {
            Consumer<LandLinkEntity> expire = auditEntity -> handle.expireByGroupId(auditEntity, reqContext.getTenantId(), groupId);
            AuditHelper.expire(new LandLinkEntity(), reqContext.getUsername(), expire, handle.getCurrentTimestamp());
            
            List<Long> updatedIds = landLinks.stream()
            		.map(LandLinkEntity::getId)
            		.collect(Collectors.toList());
            
            List<Long> updatedPkids = landLinks.stream()
            		.map(LandLinkEntity::getPkid)
            		.collect(Collectors.toList());
            
            landLinkEventProducer.pushLandLinkEvent(updatedIds, partyId,
                    reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), CllEventType.CLOSE_LAND_LINKS, updatedPkids);
            AbsoluteDate fromDate = landLinks.stream()
            		.map(LandLinkEntity::getDayFrom)
                    .min(Comparator.comparing(AbsoluteDate::toLocalDate))
                    .orElse(null);
            anomalyQueue.pushLandLinkEvent(updatedIds, fromDate, partyId,
                    reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), CllEventType.CLOSE_LAND_LINKS);
        });
    }

    private LandLinkEntity doUpdate(ReqContext reqContext, LandLinkDAO landLinkDAO, LandLinkEntity landLinkEntity) {
        Consumer<LandLinkEntity> expire = landLinkDAO::expireRow;
        Function<LandLinkEntity, Long> insert = landLinkDAO::insertVersion;

        long currentPkId = AuditHelper.update(landLinkEntity, reqContext.getUsername(), expire, insert, landLinkDAO.getCurrentTimestamp());
        landLinkEntity.setPkid(currentPkId);

        return landLinkEntity;
    }

    private void mapParcelData(ReqContext reqContext, Boolean inclueGeometries, AbsoluteDate referenceDate, InfiniteListResults<LandLinkRes> results) {
        List<Long> parcelIds = results.getRecords().stream()
                .map(LandLinkRes::getParcel)
                .map(ParcelRes::getId)
                .collect(Collectors.toList());

        Map<Long, PublicParcel> parcelMap = new HashMap<>();
        lpisClientService.consumeParcelsByIdIn(reqContext, inclueGeometries, referenceDate, parcelIds,
                publicParcel -> parcelMap.put(publicParcel.getId(), publicParcel));

        results.getRecords().forEach(landLinkRes -> Optional.ofNullable(parcelMap.get(landLinkRes.getParcel().getId()))
                .ifPresentOrElse(pp -> landLinkRes.setParcel(ParcelMapper.INSTANCE.toParcelRes(pp)),
                        () -> log.warn("unable to find a parcel with id {} and tenant {} (land link id: {})",
                                landLinkRes.getParcel().getId(), reqContext.getTenantId(), landLinkRes.getId())));
    }

    private void mapParcelData(ReqContext reqContext, Boolean inclueGeometries, AbsoluteDate referenceDate, List<LandLinkRes> results) {
        List<Long> parcelIds = results.stream()
                .map(LandLinkRes::getParcel)
                .map(ParcelRes::getId)
                .collect(Collectors.toList());

        Map<Long, PublicParcel> parcelMap = new HashMap<>();
        lpisClientService.consumeParcelsByIdIn(reqContext, inclueGeometries, referenceDate, parcelIds,
                publicParcel -> parcelMap.put(publicParcel.getId(), publicParcel));

        results.forEach(landLinkRes -> Optional.ofNullable(parcelMap.get(landLinkRes.getParcel().getId()))
                .ifPresentOrElse(pp -> landLinkRes.setParcel(ParcelMapper.INSTANCE.toParcelRes(pp)),
                        () -> log.warn("unable to find a parcel with id {} and tenant {} (land link id: {})",
                                landLinkRes.getParcel().getId(), reqContext.getTenantId(), landLinkRes.getId())));
    }

    private void mapAnomalyData(ReqContext reqContext, AbsoluteDate referenceDate, InfiniteListResults<LandLinkRes> results) {
        this.mapAnomalyData(reqContext, referenceDate, results.getRecords());
    }

    private void mapAnomalyData(ReqContext reqContext, AbsoluteDate referenceDate, List<LandLinkRes> records) {
        Map<Long, AnomalyMaxLevelDto> landLinksAnomalies = anomalyService.getLandLinksAnomalies(reqContext, referenceDate, records);

        records.forEach(landLinkRes -> {
            AnomalyMaxLevelDto max = landLinksAnomalies.get(landLinkRes.getId());
            landLinkRes.setMaxAnomalyLevel(max.getMaxLevel());
            landLinkRes.setAnomalyCount(max.getAnomalyCount());
        });
    }

    private LandLinkRes mapParcelData(ReqContext reqContext, AbsoluteDate referenceDate, LandLinkRes landLinkRes) {

        lpisClientService.getParcelById(reqContext, referenceDate, landLinkRes.getParcel().getId())
                .ifPresentOrElse(pp -> landLinkRes.setParcel(ParcelMapper.INSTANCE.toParcelRes(pp)),
                        () -> log.warn("unable to find a parcel with id {} and tenant {} (land link id: {})",
                                landLinkRes.getParcel().getId(), reqContext.getTenantId(), landLinkRes.getId()));

        return landLinkRes;
    }

    private LandLinkRes mapAnomalyData(ReqContext reqContext, AbsoluteDate referenceDate, LandLinkRes landLinkRes) {
        this.mapAnomalyData(reqContext, referenceDate, List.of(landLinkRes));

        return landLinkRes;
    }

    private LandLinkEntity mapToEntity(ReqContext reqContext, GroupEntity group,
            AbsoluteDate finalDayFrom, AbsoluteDate finalDayTo, Map<Long, AbsoluteDate> parcelsDayToMap,
            LandLinkBatchCreateReq req, PublicParcel publicParcel, long pk) {

        if (null == publicParcel) {
            throw new LandLinkException(LandLinkException.ErrEnum.PARCEL_NOT_FOUND,
                    String.format("unable to find a parcel with id %s and tenant %s on remote server", req.getParcelId(), reqContext.getTenantId()));
        }

        AbsoluteDate lastParcelDayTo = parcelsDayToMap.get(req.getParcelId());
        if (null != lastParcelDayTo) {
            if (!lastParcelDayTo.toLocalDate().isBefore(finalDayTo.toLocalDate())) {
                throw new LandLinkException(ErrEnum.NO_AVAILABLE_DATE, String.format("no room for parcel with id '%d'", req.getParcelId()));
            }

            finalDayFrom = AbsoluteDate.of(lastParcelDayTo.toLocalDate().plusDays(1));
        }
        parcelsDayToMap.put(req.getParcelId(), finalDayTo);

        String separator = getLpisSubSeparator(reqContext);

        return LandLinkEntity.builder()
                .setId(pk)
                .setPkid(pk)
                .setTenantId(reqContext.getTenantId())
                .setGroupId(group.getId())
                .setPartyId(group.getPartyId())
                .setTitleTypeId(group.getTitleTypeId())
                .setTitleTypePerc(req.getTitleTypePerc())
                .setParcelId(req.getParcelId())
                .setSectorCode(publicParcel.getSector().getSectorCode())
                .setBlockCode(publicParcel.getBlock().getBlockCode())
                .setParcelCode(StringUtils.substringBefore(publicParcel.getParcel(), separator))
                .setSubParcelCode(StringUtils.trimToNull(StringUtils.substringAfter(publicParcel.getParcel(), separator)))
                .setDayFrom(finalDayFrom)
                .setDayTo(finalDayTo)
                .build();
    }

    private LandLinkEntity mapToClonedEntity(ReqContext reqContext, GroupEntity group,
                                             BigDecimal titleTypePerc, AbsoluteDate finalDayFrom, AbsoluteDate finalDayTo, LandLinkEntity source, long pk) {

        return LandLinkEntity.builder()
                .setId(pk)
                .setPkid(pk)
                .setTenantId(reqContext.getTenantId())
                .setGroupId(group.getId())
                .setPartyId(group.getPartyId())
                .setTitleTypeId(group.getTitleTypeId())
                .setTitleTypePerc(titleTypePerc)
                .setParcelId(source.getParcelId())
                .setSectorCode(source.getSectorCode())
                .setBlockCode(source.getBlockCode())
                .setParcelCode(source.getParcelCode())
                .setSubParcelCode(source.getSubParcelCode())
                .setDayFrom(finalDayFrom)
                .setDayTo(finalDayTo)
                .build();
    }

    private String getLpisSubSeparator(ReqContext reqContext) {
        return cllSettingsDAO.getOne(reqContext.getTenantId()).getLpisSubSeparator();
    }

}
