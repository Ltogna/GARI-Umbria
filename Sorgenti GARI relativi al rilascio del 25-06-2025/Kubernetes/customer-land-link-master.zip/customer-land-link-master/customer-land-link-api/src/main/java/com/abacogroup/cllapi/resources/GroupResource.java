package com.abacogroup.cllapi.resources;

import com.abacogroup.cllapi.api.GroupRes;
import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.api.req.GroupBulkCloseReq;
import com.abacogroup.cllapi.api.req.GroupCloneReq;
import com.abacogroup.cllapi.api.req.GroupCloseReq;
import com.abacogroup.cllapi.api.req.GroupCreateReq;
import com.abacogroup.cllapi.api.req.GroupDuplicatesReq;
import com.abacogroup.cllapi.api.req.GroupSearchReq;
import com.abacogroup.cllapi.api.req.GroupUpdateReq;
import com.abacogroup.cllapi.api.req.LandLinkBatchCreateReq;
import com.abacogroup.cllapi.core.GroupService;
import com.abacogroup.cllapi.exceptions.GroupException;
import com.abacogroup.cllapi.exceptions.GroupException.ErrEnum;
import com.abacogroup.cllapi.exceptions.LandLinkException;
import com.abacogroup.cllapi.exceptions.TitleTypeException;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.common.resources.ResourceConstants;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Path(ResourceConstants.API_PRIV + "/parties/{partyId}/groups")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Groups", description = "Operations on land link groups")
public class GroupResource {

	private final GroupService groupService;

	public GroupResource(GroupService groupService) {
		this.groupService = groupService;
	}

	@GET
	@Path("/all/{referenceDate}")
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Operation(description = "Get the list of filtered groups", summary = "search groups")
	@ApiResponse(responseCode = "200", description = "Get the list of filtered groups", useReturnTypeSchema = true)
	public InfiniteListResults<GroupRes> searchGroups(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "reference date", schema = @Schema(format = AbsoluteDate.DATE_PATTERN))
			@PathParam("referenceDate") @Size(min = 8, max = 8) String referenceDate,
			@Parameter(description = "party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
			@BeanParam GroupSearchReq groupSearchReq) {

		ReqContext reqContext = new ReqContext(user, lang);

		return groupService.search(reqContext, AbsoluteDate.of(referenceDate), partyId, groupSearchReq, nextKey);
	}

	@GET
	@Path("/{groupId}")
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Operation(description = "Get group by id", summary = "get group")
	@ApiResponse(responseCode = "200", description = "group found", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "group not found", content = @Content(mediaType = MediaType.APPLICATION_JSON,
			schema = @Schema(implementation = GroupException.ErrorBody.class)))
	public GroupRes getGroup(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "group id") @PathParam("groupId") Long groupId) {

		ReqContext reqContext = new ReqContext(user, lang);
		return groupService.getRes(reqContext, partyId, groupId);
	}

	@GET
	@Path("/{groupId}/land-links")
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Operation(description = "Get group land links by id", summary = "get group land links")
	@ApiResponse(responseCode = "200", description = "group land links found", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "group not found", content = @Content(mediaType = MediaType.APPLICATION_JSON,
			schema = @Schema(implementation = GroupException.ErrorBody.class)))
	public InfiniteListResults<LandLinkRes> getGroupLandLinks(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "group id") @PathParam("groupId") Long groupId,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey) {

		ReqContext reqContext = new ReqContext(user, lang);
		return groupService.searchGroupLandLinks(reqContext, partyId, groupId, nextKey);
	}

	@POST
	@RolesAllowed("CUSTOMER_LAND_LINK|WRITE")
	@Operation(description = "create a group with its land links", summary = "create group")
	@ApiResponse(responseCode = "200", description = "newly created group", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "error creating group", content = @Content(mediaType = MediaType.APPLICATION_JSON,
			schema = @Schema(oneOf = { GroupException.ErrorBody.class, TitleTypeException.ErrorBody.class, LandLinkException.ErrorBody.class })))
	public GroupRes createGroup(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@NotNull @Valid GroupCreateReq createReq) {

		ReqContext reqContext = new ReqContext(user, lang);
		return groupService.insert(reqContext, partyId, createReq);
	}

	@POST
	@Path("/{groupId}")
	@RolesAllowed("CUSTOMER_LAND_LINK|WRITE")
	@Operation(description = "Clone group using its parcels", summary = "clone group")
	@ApiResponse(responseCode = "200", description = "newly created group", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "error creating group", content = @Content(mediaType = MediaType.APPLICATION_JSON,
			schema = @Schema(oneOf = { GroupException.ErrorBody.class, TitleTypeException.ErrorBody.class, LandLinkException.ErrorBody.class })))
	public GroupRes cloneGroup(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "group id") @PathParam("groupId") Long groupId,
			@NotNull @Valid GroupCloneReq cloneReq) {

		ReqContext reqContext = new ReqContext(user, lang);
		return groupService.clone(reqContext, partyId, groupId, cloneReq);
	}

	@PUT
	@Path("/{groupId}")
	@RolesAllowed("CUSTOMER_LAND_LINK|WRITE")
	@Operation(description = "update an existing not closed group", summary = "update group")
	@ApiResponse(responseCode = "200", description = "updated group", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "error updating group", content = @Content(mediaType = MediaType.APPLICATION_JSON,
			schema = @Schema(oneOf = { GroupException.ErrorBody.class, TitleTypeException.ErrorBody.class, LandLinkException.ErrorBody.class })))
	public GroupRes updateGroup(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "group id") @PathParam("groupId") Long groupId,
			@NotNull @Valid GroupUpdateReq updateReq) {

		ReqContext reqContext = new ReqContext(user, lang);
		return groupService.update(reqContext, partyId, groupId, updateReq);
	}

	@POST
	@Path("/{groupId}/land-links")
	@RolesAllowed("CUSTOMER_LAND_LINK|WRITE")
	@Operation(description = "Add land links to existing group", summary = "add group land links")
	@ApiResponse(responseCode = "200", description = "group land links added", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "group not found", content = @Content(mediaType = MediaType.APPLICATION_JSON,
			schema = @Schema(implementation = GroupException.ErrorBody.class)))
	public GroupRes addGroupLandLinks(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "group id") @PathParam("groupId") Long groupId,
			@Valid @NotEmpty List<LandLinkBatchCreateReq> landLinkBatchCreateReqs) {

		ReqContext reqContext = new ReqContext(user, lang);
		return groupService.addLandLinks(reqContext, partyId, groupId, landLinkBatchCreateReqs);
	}

	@PUT
	@Path("/{groupId}/day-to")
	@RolesAllowed("CUSTOMER_LAND_LINK|WRITE")
	@Operation(description = "update an existing not closed group and close all land links", summary = "close group")
	@ApiResponse(responseCode = "200", description = "closed group", useReturnTypeSchema = true)
	public GroupRes closeGroup(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "group id") @PathParam("groupId") Long groupId,
			@NotNull @Valid GroupCloseReq closeReq) {

		ReqContext reqContext = new ReqContext(user, lang);
		return groupService.close(reqContext, partyId, groupId, closeReq.getDayTo());
	}

	@PUT
	@Path("/day-to")
	@RolesAllowed("CUSTOMER_LAND_LINK|WRITE")
	@Operation(summary = "close many groups",
			description = "update many groups and close all their land links. not existing and already closed groups are ignored")
	@ApiResponse(responseCode = "200", description = "groups closed successfully")
	@ApiResponse(responseCode = "400", description = "invalid range date", content = @Content(mediaType = MediaType.APPLICATION_JSON,
			schema = @Schema(implementation = LandLinkException.ErrorBody.class)))
	public Response closeManyGroups(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@NotNull @Valid GroupBulkCloseReq closeReq) {

		if (closeReq.getGroupIds().stream().anyMatch(Objects::isNull)) {
			throw new GroupException(ErrEnum.EMPTY_GROUP, "one or more element is 'null'");
		}

		ReqContext reqContext = new ReqContext(user, lang);
		groupService.closeMany(reqContext, partyId, closeReq.getGroupIds(), closeReq.getDayTo());
		return Response.ok(Map.of()).build();
	}

	@GET
	@Path("/descr/duplicate")
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Operation(description = "get duplicated groups", summary = "get duplicated groups")
	@ApiResponse(responseCode = "200", description = "get duplicated group", useReturnTypeSchema = true)
	public Long getDuplicates(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@BeanParam @Valid GroupDuplicatesReq duplicatesReq) {

		ReqContext reqContext = new ReqContext(user, lang);

		return groupService.countDuplicates(reqContext, partyId, duplicatesReq.getGroupId(), duplicatesReq.getDescr());
	}
	
	@DELETE
	@Path("/{groupId}/parcels")
	@RolesAllowed("CUSTOMER_LAND_LINK|WRITE")
	@Operation(description = "delete all landLinks and group by group id", summary = "delete all landLinks from group")
	@ApiResponse(responseCode = "200", description = "all landLinks deleted", useReturnTypeSchema = true)
	public Response deleteAllLandLinksAndGroupByGroupId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "group id") @PathParam("groupId") Long groupId){

		ReqContext reqContext = new ReqContext(user, lang);
		groupService.expire(reqContext, partyId, groupId);
		return Response.noContent().build();
	}
	
	@DELETE
	@Path("/{groupId}/parcels/{parcelId}")
	@RolesAllowed("CUSTOMER_LAND_LINK|WRITE")
	@Operation(description = "delete landlinks by group id and parcel id", summary = "delete landLink by parcel id")
	@ApiResponse(responseCode = "200", description = "landlink deleted", useReturnTypeSchema = true)
	public Response deleteLandLinkByGroupIdAndParcelId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "group id") @PathParam("groupId") Long groupId,
			@Parameter(description = "parcel id") @PathParam("parcelId") Long parcelId) {

		ReqContext reqContext = new ReqContext(user, lang);
		groupService.deleteLandLinkByGroupIdAndParcelId(reqContext, partyId, groupId, parcelId);
		return Response.noContent().build();
	}
}
