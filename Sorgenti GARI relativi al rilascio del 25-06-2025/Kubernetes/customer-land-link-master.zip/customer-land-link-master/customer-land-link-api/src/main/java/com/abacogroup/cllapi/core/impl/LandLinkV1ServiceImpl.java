package com.abacogroup.cllapi.core.impl;

import static java.util.stream.Collectors.toList;

import java.util.List;
import java.util.stream.Collectors;

import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.api.LandLinkSectorSummaryRes;
import com.abacogroup.cllapi.api.req.LandLinkSearchReq;
import com.abacogroup.cllapi.core.LandLinkService;
import com.abacogroup.cllapi.core.LandLinkV1Service;
import com.abacogroup.cllapi.core.PartyClientService;
import com.abacogroup.cllapi.db.dao.LandLinkDAO;
import com.abacogroup.cllapi.db.ntt.PartyEntity;
import com.abacogroup.cllapi.resources.pub.mapper.LandLinkResponseMapper;
import com.abacogroup.cllapi.resources.pub.mapper.SummaryResponseMapper;
import com.abacogroup.cllcli.api.v1.LandLinkAnomaliesResV1;
import com.abacogroup.cllcli.api.v1.LandLinkResV1;
import com.abacogroup.cllcli.api.v1.LandLinkSectorSummaryResponseV1;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;

public class LandLinkV1ServiceImpl implements LandLinkV1Service {

	private final LandLinkService landLinkService;
	private final PartyClientService partyClientService;
	
	private final LandLinkDAO landLinkDAO;

	public LandLinkV1ServiceImpl(LandLinkService landLinkService, PartyClientService partyClientService, LandLinkDAO landLinkDAO) {
		this.landLinkService = landLinkService;
		this.partyClientService = partyClientService;
		this.landLinkDAO = landLinkDAO;
	}

	@Override
	public List<LandLinkSectorSummaryResponseV1> getSummary(ReqContext reqContext, Long partyId) {
		List<LandLinkSectorSummaryRes> summary = landLinkService.getSummary(reqContext, partyId);
		return SummaryResponseMapper.INSTANCE.toResponseV1List(summary);
	}

	@Override
	public InfiniteListResults<LandLinkResV1> search(ReqContext reqContext, AbsoluteDate referenceDate, LandLinkSearchReq searchRequest, Boolean includeLpisData,
			String nextKey, Integer pageSize) {
		InfiniteListResults<LandLinkRes> infiniteListResults = landLinkService.search(reqContext, referenceDate, searchRequest, includeLpisData, nextKey, pageSize);
		List<LandLinkResV1> landLinkList = infiniteListResults.getRecords().stream().map(LandLinkResponseMapper.INSTANCE::toResponseV1).collect(toList());
		
		return new InfiniteListResultsImpl<>(landLinkList, infiniteListResults.getNextKey());
	}

	@Override
	public List<LandLinkResV1> search(ReqContext reqContext, AbsoluteDate referenceDate, LandLinkSearchReq searchRequest) {
		List<LandLinkRes> parcelList = landLinkService.search(reqContext, referenceDate, searchRequest);
		return LandLinkResponseMapper.INSTANCE.toResponseV1List(parcelList);
	}

	@Override
	public LandLinkAnomaliesResV1 getAnomalies(ReqContext reqContext, AbsoluteDate referenceDate, Long partyId, Long landLinkId) {
		return LandLinkAnomaliesResV1.builder()
				.setAnomaliesGrouped(landLinkService.getAnomalies(reqContext, referenceDate, partyId, landLinkId).getAnomaliesGrouped())
				.build();
	}

	@Override
	public InfiniteListResults<PartyResponseV1> getPartiesForSector(ReqContext reqContext, AbsoluteDate referenceDate, Boolean includePartyRegData,
			List<String> sectorCodes, String nextKey, Integer pageSize) {

		InfiniteListResults<PartyEntity> parties = landLinkDAO.infinite(
                () -> landLinkDAO.findByTenantAndSectorCode(reqContext.getTenantId(), referenceDate, sectorCodes),
                nextKey, pageSize);
		
		if(Boolean.TRUE.equals(includePartyRegData)) {
			
			return new InfiniteListResultsImpl<>(partyClientService.getByIds(reqContext, parties.getRecords().stream().map(PartyEntity::getPartyId).collect(Collectors.toList())), parties.getNextKey());
			
		}
		
		return new InfiniteListResultsImpl<>(parties.getRecords().stream().map(partyntt -> {
			PartyResponseV1 p = new PartyResponseV1();
			p.setId(partyntt.getPartyId());
			return p;
		}).collect(Collectors.toList()), parties.getNextKey());
	}
}
