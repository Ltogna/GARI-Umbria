package com.abacogroup.cllapi.api.acl;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@EqualsAndHashCode(callSuper=true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class PartyWithEntityV1 extends PartyV1 {
	
	@Schema(description = "Entity's type", implementation = EntityV1.class, requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private EntityV1 entity;
	
	@Schema(description = "if true, mandate is editable", type = "boolean", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Boolean editable;
}
