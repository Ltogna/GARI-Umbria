package com.abacogroup.cllapi.api;

import java.math.BigDecimal;

import org.jdbi.v3.core.mapper.Nested;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class LandLinkLeadingRes {

	private Long id;

	@Nested("group_detail")
	private GroupBaseRes group;

	private Long partyId;
	@Nested("party_detail")
	private PartyResponseV1 party;

	@Nested("title")
	private TitleType titleType;

	@Schema(multipleOf = 0.00000001)
	@Default
	private BigDecimal titleTypePerc = BigDecimal.valueOf(100);

	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;

}
