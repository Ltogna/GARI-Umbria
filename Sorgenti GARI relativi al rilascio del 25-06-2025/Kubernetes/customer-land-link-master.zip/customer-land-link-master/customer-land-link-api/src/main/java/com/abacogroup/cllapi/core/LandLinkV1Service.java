package com.abacogroup.cllapi.core;

import java.util.List;

import com.abacogroup.cllapi.api.req.LandLinkSearchReq;
import com.abacogroup.cllcli.api.v1.LandLinkAnomaliesResV1;
import com.abacogroup.cllcli.api.v1.LandLinkResV1;
import com.abacogroup.cllcli.api.v1.LandLinkSectorSummaryResponseV1;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;

public interface LandLinkV1Service {
	List<LandLinkSectorSummaryResponseV1> getSummary(ReqContext reqContext, Long partyId);

	InfiniteListResults<LandLinkResV1> search(ReqContext reqContext, AbsoluteDate referenceDate, LandLinkSearchReq searchRequest, Boolean includeLpisData, String nextKey, Integer pageSize);
	
	List<LandLinkResV1> search(ReqContext reqContext, AbsoluteDate referenceDate, LandLinkSearchReq searchRequest);

	LandLinkAnomaliesResV1 getAnomalies(ReqContext reqContext, AbsoluteDate referenceDate, Long partyId, Long landLinkId);
	
	InfiniteListResults<PartyResponseV1> getPartiesForSector(ReqContext reqContext, AbsoluteDate referenceDate, Boolean includePartyRegData, List<String> sectorcodes, String nextKey, Integer pageSize);
}
