package com.abacogroup.cllapi.db.ntt;

import com.abacogroup.cllcli.api.v1.enums.ParcelSearchLevel;
import com.abacogroup.jdbi.model.AuditEntity;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.jdbi.v3.core.mapper.reflect.ColumnName;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class CllSettingsEntity implements AuditEntity {
	private Long pkid;

	private String tenantId;
	private String lpisSubSeparator;
	@Builder.Default()
	private ParcelSearchLevel parcelSearchLevel = ParcelSearchLevel.ADD_TEMP_PARCELS_IF_NOT_EXISTS;
	

	@Builder.Default
	@ColumnName("fl_allow_editdayto_parcelinthepast")
	private int allowEditDayToParcelInThePast = 0;

	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;
}
