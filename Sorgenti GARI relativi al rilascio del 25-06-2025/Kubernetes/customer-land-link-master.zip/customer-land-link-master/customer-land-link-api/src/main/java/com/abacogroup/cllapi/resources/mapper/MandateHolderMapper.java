package com.abacogroup.cllapi.resources.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.cllapi.api.MandateHolder;
import com.abacogroup.cllapi.api.acl.EntityV1;

@Mapper
public interface MandateHolderMapper {

	MandateHolderMapper INSTANCE = Mappers.getMapper(MandateHolderMapper.class);

	@Mapping(source = "entityType", target = "type")
	MandateHolder toMandateHolder(EntityV1 res);

}
