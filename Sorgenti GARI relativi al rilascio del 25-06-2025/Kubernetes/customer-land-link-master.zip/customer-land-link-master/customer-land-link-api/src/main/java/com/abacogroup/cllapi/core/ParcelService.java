package com.abacogroup.cllapi.core;

import java.util.List;

import com.abacogroup.cllapi.api.LandLinkLeadingRes;
import com.abacogroup.cllapi.api.LandLinkLeadingResWithHolder;
import com.abacogroup.cllapi.api.ParcelSearchRes;
import com.abacogroup.cllapi.api.req.ParcelSearchReq;
import com.abacogroup.cllcli.api.v1.enums.ParcelSearchLevel;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;

public interface ParcelService {

    InfiniteListResults<ParcelSearchRes> search(ReqContext context, Long partyId, ParcelSearchReq searchReq, Boolean includeGeometries,
    		Boolean includeLandCovers, Boolean includeLpisData, ParcelSearchLevel parcelSearchLevel, String nextKey, Integer pageSize);

    List<ParcelSearchRes> searchByGroup(ReqContext context, Long partyId, Long groupId, ParcelSearchReq searchReq);

    List<LandLinkLeadingRes> getParcelLeadingList(ReqContext context, Long parcelId, AbsoluteDate referenceDate);

	List<LandLinkLeadingResWithHolder> getParcelLeadingHistory(ReqContext context, Long parcelId, Boolean loadMandatesHolders);

}
