package com.abacogroup.cllapi.exceptions;

import com.abacogroup.common.exceptions.AbstractAppException;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class InvalidTitleTypeException extends AbstractAppException {
	public InvalidTitleTypeException(InvalidTitleTypeException.ErrEnum code, String message) {
		super(new InvalidTitleTypeException.ErrorBody(code.name(), message));
	}

	public enum ErrEnum {
		GENERIC,
		TITLE_TYPE_NOT_FOUND,
		TITLE_TYPE_ERROR,
	}

	@Schema(name = "InvalidTitleTypeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { "TITLE_TYPE_NOT_FOUND" })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}

}
