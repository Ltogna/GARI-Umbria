package com.abacogroup.cllapi.resources.pub;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.cllapi.core.LandLinkV1Service;
import com.abacogroup.cllcli.api.v1.req.SearchPartiesForSectorsRequestV1;
import com.abacogroup.cllcli.resources.PublicResourceConstants;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(PublicResourceConstants.API_V1_PUB + "/sectors")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Sectors")
@Tag(name = "Public APIs", description = "All public APIs")
public class SectorPublicResource {

    private final LandLinkV1Service landLinkV1Service;

    public SectorPublicResource(LandLinkV1Service landLinkV1Service) {
        this.landLinkV1Service =landLinkV1Service;
    }

    @GET
    @Path("/{sectorCode}/parties")
    @RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
    @Operation(description = "Get the list of parties for the sector", summary = "sectors")
    @ApiResponse(responseCode = "200", description = "Get the list of filtered parcels", useReturnTypeSchema = true)
    public InfiniteListResults<PartyResponseV1> getPartiesForSector(
            @HeaderParam("accept-language") @DefaultValue("en") String lang,
            @Parameter(hidden = true) @Auth User user,
            @Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
            @Parameter(description = "sector code") @PathParam("sectorCode") String sectorCode,
            @Parameter(description = "reference date default today") @QueryParam("reference_date") @Size(min = 8, max = 8) String referenceDate,
            @Parameter(description = "Include Party Registry data (deafult false)") @QueryParam("include_partyreg_data") @DefaultValue("false") Boolean includePartyRegData,
            @Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
            @Parameter(description = "page size") @QueryParam("page_size") @DefaultValue("10") Integer pageSize) {

        
    	ReqContext reqContext = new ReqContext(user, lang);
    	
    	AbsoluteDate refDate = Optional.ofNullable(referenceDate)
                .map(StringUtils::trimToNull)
                .map(AbsoluteDate::of)
                .orElse(AbsoluteDate.of(LocalDate.now()));
    	
        return landLinkV1Service.getPartiesForSector(reqContext, refDate, includePartyRegData, Arrays.asList(sectorCode), nextKey, pageSize);
    }

    @POST
    @Path("/parties")
    @RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
    @Operation(description = "Get the list of parties for the sectors list passed in payload", summary = "sectors")
    @ApiResponse(responseCode = "200", description = "Get the list of filtered parcels", useReturnTypeSchema = true)
    public InfiniteListResults<PartyResponseV1> getPartiesForSectorsList(
    		@HeaderParam("accept-language") @DefaultValue("en") String lang,
    		@Parameter(hidden = true) @Auth User user,
    		@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
    		@Parameter(description = "reference date default today") @QueryParam("reference_date") @Size(min = 8, max = 8) String referenceDate,
    		@Parameter(description = "Include Party Registry data (deafult false)") @QueryParam("include_partyreg_data") @DefaultValue("false") Boolean includePartyRegData,
    		@Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
    		@Parameter(description = "page size") @QueryParam("page_size") @DefaultValue("10") Integer pageSize,
    		@NotNull @Valid SearchPartiesForSectorsRequestV1 searchPartiesReq) {
    		
    	
    	ReqContext reqContext = new ReqContext(user, lang);
    	
    	AbsoluteDate refDate = Optional.ofNullable(referenceDate)
                .map(StringUtils::trimToNull)
                .map(AbsoluteDate::of)
                .orElse(AbsoluteDate.of(LocalDate.now()));
    	
        return landLinkV1Service.getPartiesForSector(reqContext, refDate, includePartyRegData, searchPartiesReq.getSectors(), nextKey, pageSize);
    }
    

}
