package com.abacogroup.cllapi.core.dto;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class LandLinkPayload {
	private Long landLinkId;

	private Long groupId;
	private String groupDescr;

	private Long titleTypeId;
	private String titleTypeCode;
	private BigDecimal titleTypePerc;

	private Long parcelId;
	private String sectorCode;
	private String blockCode;
	private String parcelCode;
	private String subParcelCode;

	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;
}
