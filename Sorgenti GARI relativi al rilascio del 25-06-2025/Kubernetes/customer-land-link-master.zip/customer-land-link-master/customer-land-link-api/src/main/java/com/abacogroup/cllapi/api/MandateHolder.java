package com.abacogroup.cllapi.api;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class MandateHolder {
	
	@Schema(description = "Holder id", type = "integer", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Long id;
	
	@Schema(description = "Code of Holder", type = "string")
	private String code;
	
	@Schema(description = "Holder name", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String name;
	
	@Schema(description = "Holder's type", implementation = MandateHolderType.class, requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private MandateHolderType type;
}
