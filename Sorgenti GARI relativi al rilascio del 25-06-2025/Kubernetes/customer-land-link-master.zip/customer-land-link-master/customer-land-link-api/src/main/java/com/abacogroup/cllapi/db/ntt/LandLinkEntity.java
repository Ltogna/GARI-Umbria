package com.abacogroup.cllapi.db.ntt;

import com.abacogroup.cllapi.core.dto.LandLink;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class LandLinkEntity implements AuditEntity, LandLink {

	private Long id;
	private Long pkid;

	private Long groupId;
	private String tenantId;
	private Long partyId;

	private Long titleTypeId;
	private BigDecimal titleTypePerc;

	private Long parcelId;
	private String sectorCode;
	private String blockCode;
	private String parcelCode;
	private String subParcelCode;

	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;

	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;
}
