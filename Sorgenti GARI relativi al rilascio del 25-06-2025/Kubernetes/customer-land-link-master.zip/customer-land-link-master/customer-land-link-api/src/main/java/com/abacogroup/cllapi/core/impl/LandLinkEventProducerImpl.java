package com.abacogroup.cllapi.core.impl;

import java.io.IOException;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Collection;

import org.jdbi.v3.core.Jdbi;

import com.abacogroup.cllapi.core.LandLinkEventProducer;
import com.abacogroup.cllapi.core.dto.CllEventMessage;
import com.abacogroup.cllapi.core.dto.CllEventType;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisherWorkQueue;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.dropwizard.core.setup.Environment;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LandLinkEventProducerImpl extends RabbitMqPublisherWorkQueue<CllEventMessage> implements LandLinkEventProducer {

	private final Clock appClock;

	public LandLinkEventProducerImpl(Environment environment, Jdbi jdbi, ObjectMapper mapper,
			CllRabbitMqPublisher cllRabbitMqPublisher, Clock appClock) throws IOException {
		super("publish-to-rabbitmq", new JdbiRepository(jdbi));
		this.appClock = appClock;

		setConsumer(cllRabbitMqPublisher);
		setMetricRegistry(environment.metrics());
		setObjectMapper(mapper);

		start();
	}

	@Override
	public void pushGroupEvent(Collection<Long> groupIds, Long partyId, String tenant, String username, String lang, CllEventType eventType, Collection<Long> landLinkPkids) {

		add(new CllEventMessage(tenant, username, lang, partyId, LocalDateTime.now(appClock), groupIds, null, eventType, landLinkPkids), appClock.millis());
	}
	
	@Override
	public void pushGroupEvent(Collection<Long> groupIds, Long partyId, String tenant, String username, String lang, CllEventType eventType) {
		
		add(new CllEventMessage(tenant, username, lang, partyId, LocalDateTime.now(appClock), groupIds, null, eventType, null), appClock.millis());
	}
	
	@Override
	public void pushLandLinkEvent(Collection<Long> landLinkIds, Long partyId, String tenant, String username, String lang, CllEventType eventType) {

		add(new CllEventMessage(tenant, username, lang, partyId, LocalDateTime.now(appClock), null, landLinkIds, eventType, null), appClock.millis());
	}
	
	@Override
	public void pushLandLinkEvent(Collection<Long> landLinkIds, Long partyId, String tenant, String username, String lang, CllEventType eventType, Collection<Long> landLinkPkids) {

		add(new CllEventMessage(tenant, username, lang, partyId, LocalDateTime.now(appClock), null, landLinkIds, eventType, landLinkPkids), appClock.millis());
	}

	@Override
	protected Class<CllEventMessage> getJobClass() {
		return CllEventMessage.class;
	}

}
