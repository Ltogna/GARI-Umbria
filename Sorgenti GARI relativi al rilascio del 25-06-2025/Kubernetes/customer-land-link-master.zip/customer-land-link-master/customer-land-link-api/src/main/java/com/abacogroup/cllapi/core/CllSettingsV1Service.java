package com.abacogroup.cllapi.core;

import com.abacogroup.cllcli.api.v1.CllSettingsResponseV1;
import com.abacogroup.common.resources.ReqContext;

public interface CllSettingsV1Service {
    CllSettingsResponseV1 getSettings(ReqContext context);
}
