package com.abacogroup.cllapi.db.dao;

import java.util.List;
import java.util.Optional;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.cllapi.api.LandLinkDocumentRes;
import com.abacogroup.cllapi.db.ntt.LandLinkDocumentEntity;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;

public interface LandLinkDocumentDAO extends Transactional<LandLinkDocumentDAO>, EnhancedSqlObject {


	@SqlQuery("select lld.pkid, \n"
			+ "   lld.land_link_id, \n"
			+ "   lld.definition_code, \n"
			+ "   lld.document_id, \n"
			+ "   lld.dt_insert, \n"
			+ "   lld.user_id_insert, \n"
			+ "   lld.dt_delete, \n"
			+ "   lld.user_id_delete\n"
			+ " FROM cll_land_link_documents lld "
			+ " join cll_land_link_detail ld on ld.id = lld.land_link_id "
			+ " where lld.land_link_id = :landLinkId "
			+ " and ld.tenant_id = :tenantId "
			+ " and <criteria> "
			+ " and (§current_timestamp§ between ld.dt_insert and ld.dt_delete) "
			+ " and (§current_timestamp§ between lld.dt_insert and lld.dt_delete) "
			+ " ORDER BY <orderBy> ")
	@RegisterBeanMapper(LandLinkDocumentRes.class)
	ResultIterator<LandLinkDocumentRes> search(
			@Bind("landLinkId") Long landLinkId,
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx);

	@SqlQuery("select count(*) "
			+ " FROM cll_land_link_documents lld "
			+ " join cll_land_link_detail ld on ld.id = lld.land_link_id "
			+ " where lld.definition_code = :definitionCode "
			+ " and ld.id = :landLinkId "
			+ " and ld.tenant_id = :tenantId "
			+ " and (§current_timestamp§ between ld.dt_insert and ld.dt_delete) "
			+ " and (§current_timestamp§ between lld.dt_insert and lld.dt_delete) ")
	Long countByDefinitionCodeAndLandLinkId(
			@Bind("tenantId") String tenantId,
			@Bind("definitionCode") String definitionCode,
			@Bind("landLinkId") Long landLinkId);

	@SqlQuery("select lld.pkid, \n"
			+ "   lld.land_link_id, \n"
			+ "   lld.definition_code, \n"
			+ "   lld.document_id, \n"
			+ "   lld.dt_insert, \n"
			+ "   lld.user_id_insert, \n"
			+ "   lld.dt_delete, \n"
			+ "   lld.user_id_delete\n"
			+ " FROM cll_land_link_documents lld "
			+ " join cll_land_link_detail ld on ld.id = lld.land_link_id "
			+ " where lld.document_id = :documentId "
			+ " and ld.id = :landLinkId "
			+ " and ld.tenant_id = :tenantId "
			+ " and (§current_timestamp§ between ld.dt_insert and ld.dt_delete) "
			+ " and (§current_timestamp§ between lld.dt_insert and lld.dt_delete) ")
	@RegisterBeanMapper(LandLinkDocumentRes.class)
	Optional<LandLinkDocumentRes> getByDocumentIdAndLandLinkId(
			@Bind("documentId") Long documentId,
			@Bind("landLinkId") Long landLinkId,
			@BindBean ReqContext ctx);

	@SqlQuery("select lld.pkid, \n"
			+ "   lld.land_link_id, \n"
			+ "   lld.definition_code, \n"
			+ "   lld.document_id, \n"
			+ "   lld.dt_insert, \n"
			+ "   lld.user_id_insert, \n"
			+ "   lld.dt_delete, \n"
			+ "   lld.user_id_delete\n"
			+ " FROM cll_land_link_documents lld "
			+ " join cll_land_link_detail ld on ld.id = lld.land_link_id "
			+ " where ld.id = :landLinkId "
			+ " and lld.definition_code = :definitionCode "
			+ " and ld.tenant_id = :tenantId "
			+ " and (§current_timestamp§ between ld.dt_insert and ld.dt_delete) "
			+ " and (§current_timestamp§ between lld.dt_insert and lld.dt_delete) ")
	@RegisterBeanMapper(LandLinkDocumentRes.class)
	List<LandLinkDocumentRes> getByLandLinkIdAndDefinitionCode(
			@Bind("landLinkId") Long landLinkId,
			@Bind("definitionCode") String definitionCode,
			@BindBean ReqContext ctx);

	@SqlQuery("select lld.pkid, \n"
			+ "   lld.land_link_id, \n"
			+ "   lld.definition_code, \n"
			+ "   lld.document_id, \n"
			+ "   lld.dt_insert, \n"
			+ "   lld.user_id_insert, \n"
			+ "   lld.dt_delete, \n"
			+ "   lld.user_id_delete\n"
			+ " FROM cll_land_link_documents lld "
			+ " join cll_land_link_detail ld on ld.id = lld.land_link_id "
			+ " where lld.document_id = :documentId "
			+ " and ld.id = :landLinkId "
			+ " and ld.tenant_id = :tenantId "
			+ " and (§current_timestamp§ between ld.dt_insert and ld.dt_delete) "
			+ " and (§current_timestamp§ between lld.dt_insert and lld.dt_delete) ")
	@RegisterBeanMapper(LandLinkDocumentEntity.class)
	Optional<LandLinkDocumentEntity> findByDocumentIdAndLandLinkId(
			@Bind("tenantId") String tenantId,
			@Bind("documentId") Long documentId,
			@Bind("landLinkId") Long landLinkId);

	@SqlUpdate(
			"INSERT INTO cll_land_link_documents (land_link_id, definition_code, document_id, dt_insert, user_id_insert, dt_delete, user_id_delete) "
					+ " VALUES (:landLinkId, :definitionCode, :documentId, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	@GetGeneratedKeys("pkid")
	Long insert(@BindBean LandLinkDocumentEntity entity);

	@SqlUpdate("update cll_land_link_documents set dt_delete =:dtDelete, user_id_delete=:userIdDelete where pkid = :pkid")
	void expireRow(@BindBean LandLinkDocumentEntity entity);
}
