package com.abacogroup.cllapi.api;

import com.abacogroup.cllapi.api.enums.DocTypeRelationScope;
import com.abacogroup.dynamicdocuments.bean.SummaryFieldDefinition;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class DocTypeRelationRes {

	private String definitionCode;  //docType
	private String definitionCodeI18n;

	private Long titleTypeId;  // FK
	private DocTypeRelationScope scopeCode;

	private int flRequired;
	private int flReqOnAdd;
	private int flReqOnClose;

	private int flDocPresent; // flag used to indicate if there is already documents inserted of this docType

	private  boolean multiple;
	private List<SummaryFieldDefinition> summaryFieldDefinitions;

}
