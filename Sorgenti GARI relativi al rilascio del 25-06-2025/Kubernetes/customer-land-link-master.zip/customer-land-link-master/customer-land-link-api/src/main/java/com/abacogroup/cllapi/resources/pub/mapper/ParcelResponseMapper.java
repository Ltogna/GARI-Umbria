package com.abacogroup.cllapi.resources.pub.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.cllapi.api.LandLinkLeadingRes;
import com.abacogroup.cllapi.api.LandLinkLeadingResWithHolder;
import com.abacogroup.cllapi.api.ParcelSearchRes;
import com.abacogroup.cllcli.api.v1.LandLinkLeadingResV1;
import com.abacogroup.cllcli.api.v1.LandLinkLeadingResWithHolderResV1;
import com.abacogroup.cllcli.api.v1.ParcelSearchResponseV1;

@Mapper
public interface ParcelResponseMapper {

    ParcelResponseMapper INSTANCE = Mappers.getMapper(ParcelResponseMapper.class);

    ParcelSearchResponseV1 toResponseV1List(ParcelSearchRes resList);


    List<LandLinkLeadingResV1> landLinkLeadingResListToLandLinkLeadingResV1List(List<LandLinkLeadingRes> list);
    List<LandLinkLeadingResWithHolderResV1> landLinkLeadingResListWithHolderToLandLinkLeadingResV1List(List<LandLinkLeadingResWithHolder> list);

}
