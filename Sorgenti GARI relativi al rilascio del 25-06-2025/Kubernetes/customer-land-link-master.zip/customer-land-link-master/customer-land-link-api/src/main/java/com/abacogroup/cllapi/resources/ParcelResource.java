package com.abacogroup.cllapi.resources;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.cllapi.api.ParcelSearchRes;
import com.abacogroup.cllapi.api.req.ParcelSearchReq;
import com.abacogroup.cllapi.core.ParcelService;
import com.abacogroup.cllapi.exceptions.InvalidPayloadException;
import com.abacogroup.cllapi.exceptions.InvalidPayloadException.ErrEnum;
import com.abacogroup.cllcli.api.v1.enums.ParcelSearchLevel;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.common.resources.ResourceConstants;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PRIV + "/parties/{partyId}")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Parcels", description = "Operations on Parcels")
public class ParcelResource {

	private final ParcelService parcelService;

	public ParcelResource(ParcelService parcelService) {
		this.parcelService = parcelService;
	}

	@GET
	@Path("/parcels")
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Operation(description = "Get the list of filtered parcels", summary = "search parcels")
	@ApiResponse(responseCode = "200", description = "Get the list of filtered parcels", useReturnTypeSchema = true)
	public InfiniteListResults<ParcelSearchRes> searchParcels(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "Include the geometries data") @QueryParam("include_geometries") @DefaultValue("false") Boolean includeGeometries,
			@Parameter(description = "Include the landcovers detail") @QueryParam("include_landcovers") @DefaultValue("false") Boolean includeLandCovers,
			@Parameter(description = "parcel search level, allowed values: 'SEARCH_ONLY_VALID', 'SEARCH_OUTDATED','ADD_TEMP_PARCELS_IF_NOT_EXISTS', default:'SEARCH_OUTDATED'") 
			@QueryParam("search_level") @DefaultValue("SEARCH_OUTDATED") ParcelSearchLevel parcelSearchLevel,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
			@Parameter(description = "page size") @QueryParam("page_size") Integer pageSize,
			@BeanParam @Valid ParcelSearchReq searchReq) {

		if (StringUtils.isNotBlank(searchReq.getSubParcelCode()) && StringUtils.isBlank(searchReq.getParcelCode())) {
			throw new InvalidPayloadException(ErrEnum.INVALID_PAYLOAD, "subParcelCode is only to be evaluated if there is ParcelCode along with");
		}

		return parcelService.search(new ReqContext(user, lang), partyId, searchReq, includeGeometries, includeLandCovers, true, parcelSearchLevel, nextKey, pageSize);
	}

	@GET
	@Path("/group/{groupId}/parcels")
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Operation(description = "Get the list of parcels for a group", summary = "search parcels by group")
	@ApiResponse(responseCode = "200", description = "Get the list of parcels by group", useReturnTypeSchema = true)
	public List<ParcelSearchRes> searchParcelsByGroup(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "group id") @PathParam("groupId") Long groupId,
			@BeanParam @Valid ParcelSearchReq searchReq) {

		if (StringUtils.isNotBlank(searchReq.getSubParcelCode()) && StringUtils.isBlank(searchReq.getParcelCode())) {
			throw new InvalidPayloadException(ErrEnum.INVALID_PAYLOAD, "subParcelCode is only to be evaluated if there is ParcelCode along with");
		}

		return parcelService.searchByGroup(new ReqContext(user, lang), partyId, groupId, searchReq);
	}
}
