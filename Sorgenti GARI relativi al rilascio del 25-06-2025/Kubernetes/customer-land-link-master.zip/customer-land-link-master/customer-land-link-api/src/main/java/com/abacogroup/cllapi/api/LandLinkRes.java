package com.abacogroup.cllapi.api;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.cllapi.core.dto.AnomalyDto;
import com.abacogroup.cllapi.core.dto.LandLink;
import com.abacogroup.cllcli.api.v1.AnomalyLevelEnum;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Optional;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.jdbi.v3.core.mapper.Nested;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class LandLinkRes implements LandLink {

	private Long id;
	//	private Long pkid;

	@Nested("group_detail")
	private GroupBaseRes group;

	//	private String tenantId;
	private Long partyId; // TODO full dto?

	@Nested("title")
	private TitleType titleType;

	@Schema(multipleOf = 0.00000001)
	@Default
	private BigDecimal titleTypePerc = BigDecimal.valueOf(100);

	@Nested("parcel_detail")
	private ParcelRes parcel;

	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;

	private AnomalyLevelEnum maxAnomalyLevel;
	@Default
	private Long anomalyCount = 0L;

	private List<AnomalySearchResponse> anomalies;

	public Long getTitleTypeAreaSqm() {
		return titleTypePerc.multiply(BigDecimal.valueOf(Optional.ofNullable(parcel).map(ParcelRes::getAreaSqm).orElse(0L)))
				.divide(BigDecimal.valueOf(100), 0, RoundingMode.HALF_UP).longValue();
	}

	@JsonIgnore
	@Override
	public Long getGroupId() {
		return Optional.ofNullable(group)
				.map(GroupBaseRes::getId)
				.orElse(null);
	}

	@JsonIgnore
	@Override
	public Long getParcelId() {
		return Optional.ofNullable(parcel)
				.map(ParcelRes::getId)
				.orElse(null);
	}
}
