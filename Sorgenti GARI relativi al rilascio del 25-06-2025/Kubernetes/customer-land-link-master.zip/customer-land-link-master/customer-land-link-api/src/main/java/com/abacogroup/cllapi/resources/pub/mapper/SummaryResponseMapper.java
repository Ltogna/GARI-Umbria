package com.abacogroup.cllapi.resources.pub.mapper;

import com.abacogroup.cllapi.api.LandLinkSectorSummaryRes;
import com.abacogroup.cllcli.api.v1.LandLinkSectorSummaryResponseV1;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface SummaryResponseMapper {

	SummaryResponseMapper INSTANCE = Mappers.getMapper(SummaryResponseMapper.class);

	List<LandLinkSectorSummaryResponseV1> toResponseV1List(List<LandLinkSectorSummaryRes> resList);

}
