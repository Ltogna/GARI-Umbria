package com.abacogroup.cllapi.resources.mapper;

import com.abacogroup.cllapi.api.GroupDocumentDefinition;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface GroupDocumentDefinitionMapper {

	GroupDocumentDefinitionMapper INSTANCE = Mappers.getMapper(GroupDocumentDefinitionMapper.class);

	GroupDocumentDefinition toGroupDocumentDefinition(DocumentDefinition dd);

}
