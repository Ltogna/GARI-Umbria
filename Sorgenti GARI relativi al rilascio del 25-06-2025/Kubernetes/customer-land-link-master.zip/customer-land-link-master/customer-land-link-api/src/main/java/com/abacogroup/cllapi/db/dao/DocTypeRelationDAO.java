package com.abacogroup.cllapi.db.dao;

import com.abacogroup.cllapi.api.DocTypeRelationRes;
import com.abacogroup.cllapi.api.enums.DocTypeRelationScope;
import com.abacogroup.cllapi.db.ntt.DocTypeRelationEntity;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.model.AuditEntity;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface DocTypeRelationDAO extends Transactional<DocTypeRelationDAO>, EnhancedSqlObject {

	String CURRENT_RECORD = " AND (§current_timestamp§ between cdtr.dt_insert and cdtr.dt_delete) ";
	String I18NDefCode = ", coalesce (§i18n(:tenantId, 'cll_doc_type_relations', 'definition_code', cdtr.definition_code, :lang)§, cdtr.definition_code) as definition_code_i18n\n ";

	@SqlUpdate("INSERT INTO cll_doc_type_relations"
			+ " (tenant_id,title_type_id, definition_code, fl_required, fl_req_on_add, fl_req_on_close, "
			+ "dt_insert, user_id_insert, dt_delete, user_id_delete, scope_code) "
			+ "VALUES (:tenantId, :titleTypeId, :definitionCode, :flRequired, :flReqOnAdd, :flReqOnClose, "
			+ ":dtInsert, :userIdInsert, :dtDelete, :userIdDelete, :scopeCode)")
	@GetGeneratedKeys("pkid")
	Long insert(@BindBean DocTypeRelationEntity entity);

	@SqlQuery("select count(*)  from cll_doc_type_relations "
			+ " WHERE (§current_timestamp§ between dt_insert and dt_delete)"
			+ " AND tenant_id= :tenantId")
	@RegisterBeanMapper(DocTypeRelationEntity.class)
	Long count(@Bind("tenantId") String tenantId);

	@SqlQuery("select cdtr.pkid,cdtr.tenant_id,cdtr.title_type_id, cdtr.definition_code, cdtr.fl_required, cdtr.fl_req_on_add, cdtr.fl_req_on_close, "
			+ " cdtr.dt_insert, cdtr.user_id_insert, cdtr.dt_delete, cdtr.user_id_delete, cdtr.scope_code"
			+ " from cll_doc_type_relations cdtr"
			+ " left join cll_title_type ctt on ctt.id = cdtr.title_type_id AND ctt.tenant_id= :tenantId AND (§current_timestamp§ between cdtr.dt_insert and cdtr.dt_delete)  "
			+ " WHERE cdtr.tenant_id= :tenantId"
			+ " AND ((:titleType is not null AND cdtr.title_type_id = :titleType) "
			+ "    OR (:titleType is null and cdtr.title_type_id is null)) "
			+ " AND cdtr.definition_code = :defCode "
			+ " AND cdtr.scope_code = :scopeCode "
			+ CURRENT_RECORD)
	@RegisterBeanMapper(DocTypeRelationEntity.class)
	Optional<DocTypeRelationEntity> findByTitleTypeScopeCodeAndDefCode(@Bind("tenantId") String tenantId, @Bind("titleType") Long titleType,
			@Bind("scopeCode") DocTypeRelationScope scopeCode, @Bind("defCode") String defCode);

	@SqlQuery("select cdtr.pkid,cdtr.title_type_id, cdtr.definition_code, cdtr.fl_required, "
			+ " cdtr.fl_req_on_add, cdtr.fl_req_on_close, cdtr.scope_code "
			+ I18NDefCode
			+ " from cll_doc_type_relations cdtr"
			+ " left join cll_title_type ctt on ctt.id = cdtr.title_type_id AND ctt.tenant_id= :tenantId"
			+ " WHERE cdtr.tenant_id= :tenantId"
			+ " AND cdtr.scope_code = :scopeCode "
			+ " AND (cdtr.title_type_id = :titleType or cdtr.title_type_id is null) "
			+ CURRENT_RECORD)
	@RegisterBeanMapper(DocTypeRelationRes.class)
	List<DocTypeRelationRes> getByTitleTypeAndScopeCode(@BindBean ReqContext reqContext, @Bind("titleType") Long titleType,
			@Bind("scopeCode") DocTypeRelationScope scopeCode);
	
	@SqlQuery("select * from cll_doc_type_relations ")
	@RegisterBeanMapper(DocTypeRelationRes.class)
	List<DocTypeRelationRes> onlyForMe();

	@SqlUpdate("update cll_doc_type_relations set dt_delete =:dtDelete, user_id_delete =:userIdDelete where pkid = :pkid")
	void expireRow(@BindBean DocTypeRelationEntity entity);

	@SqlQuery("select count(*) FROM cll_doc_type_relations where tenant_id = :tenantId ")
	Long countAll(@Bind("tenantId") String tenantId);

	@SqlUpdate("INSERT INTO cll_doc_type_relations ("
			+ " tenant_id, title_type_id, definition_code, fl_required, fl_req_on_add, fl_req_on_close, "
			+ " dt_insert, user_id_insert, dt_delete, user_id_delete, scope_code )\n"
			+ " select :newTenantId , "
			+ " (select dst_tt.id from cll_title_type dst_tt where dst_tt.code = src_tt.code and dst_tt.tenant_id= :newTenantId AND (§current_timestamp§ between dst_tt.dt_insert and dst_tt.dt_delete)) as dest_title_type_id , "
			+ " definition_code, "
			+ " fl_required, "
			+ " fl_req_on_add, "
			+ " fl_req_on_close, "
			+ " :dtInsert, :userIdInsert, :dtDelete, :userIdDelete, scope_code "
			+ " FROM cll_doc_type_relations cdtr "
			+ " left join cll_title_type src_tt on src_tt.id = cdtr.title_type_id and src_tt.tenant_id= :sourceTenant AND (§current_timestamp§ between src_tt.dt_insert and src_tt.dt_delete) "
			+ " where cdtr.tenant_id = :sourceTenant "
			+ CURRENT_RECORD)
	void insertNewTenant(
			@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId,
			@BindBean AuditEntity audit);

}
