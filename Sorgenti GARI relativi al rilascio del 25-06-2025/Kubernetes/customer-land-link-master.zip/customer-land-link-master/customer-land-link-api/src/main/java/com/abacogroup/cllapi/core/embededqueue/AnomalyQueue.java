package com.abacogroup.cllapi.core.embededqueue;

import static com.abacogroup.embeddedqueue.QueueErrorListener.ErrorAction.MARK_AS_ERRORED;

import com.abacogroup.cllapi.CustomerLandLinkConfiguration;
import com.abacogroup.cllapi.core.dto.CllEventType;
import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.Repository;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.codahale.metrics.MetricRegistry;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

@Slf4j
public class AnomalyQueue extends WorkQueue<AnomalyJob> implements EventPublisher {

	private static final String Q_ID = "cll-anomaly-process";
	private static final long Q_TIMEOUT_MS = 1000L * 60 * 10;
	private static int Q_THREADS = 1;

	private final CustomerLandLinkConfiguration customerLandLinkConfiguration;
	private final AnomalyHelper anomalyHelper;

	private final Jdbi jdbi;
	private final Clock appClock;

	public AnomalyQueue(Repository repo, MetricRegistry registry,
			CustomerLandLinkConfiguration customerLandLinkConfiguration,
			AnomalyHelper anomalyHelper, Jdbi jdbi, Clock appClock) {
		super(Q_ID, repo, Q_THREADS, Q_TIMEOUT_MS);
		this.customerLandLinkConfiguration = customerLandLinkConfiguration;
		this.anomalyHelper = anomalyHelper;
		this.jdbi = jdbi;
		this.appClock = appClock;
		this.setMetricRegistry(registry);
//		super.setWaitTimeMs(1000);

		ThrowingConsumer<AnomalyJob> consumer = createConsumer();
		this.setConsumer(consumer);

		QueueErrorListener<AnomalyJob> errorListener = createErrorListener();
		this.setErrorListener(errorListener);

		this.start();
	}

	@Override
	public void pushGroupEvent(List<Long> groupIds, AbsoluteDate fromDate, Long partyId, String tenantId, String username, String lang, CllEventType eventType) {
		add(new AnomalyJob(tenantId, username, lang, partyId, LocalDateTime.now(appClock), fromDate, groupIds, null, eventType), appClock.millis());
	}

	@Override
	public void pushLandLinkEvent(List<Long> landLinkIds, AbsoluteDate fromDate, Long partyId, String tenantId, String username, String lang, CllEventType eventType) {
		add(new AnomalyJob(tenantId, username, lang, partyId, LocalDateTime.now(appClock), fromDate, null, landLinkIds, eventType), appClock.millis());
	}

	private ThrowingConsumer<AnomalyJob> createConsumer() {
		return anomalyJob -> {
			log.info("start processing anomalyJob");
			this.processJob(anomalyJob);
		};
	}

	public void processJob(AnomalyJob job) {
		log.info("received event {}", job.getEventType());
		jdbi.useTransaction(h -> {
			if (null != job.getGroupIds() && !job.getGroupIds().isEmpty()) {

				anomalyHelper.onMultipleGroupEvent(job.getEventType(), job.getGroupIds(), job.getPartyId(), job.getFromDate(),
						job.getTenant(), job.getUsername(), job.getLang());

			} else if (null != job.getLandLinkIds() && !job.getLandLinkIds().isEmpty()) {

				anomalyHelper.onMultipleLandLinkEvent(job.getEventType(), job.getLandLinkIds(), job.getPartyId(),
						job.getTenant(), job.getUsername(), job.getLang());

			}
		});
	}

	private QueueErrorListener<AnomalyJob> createErrorListener() {
		return (anomalyJob, exp) -> {
			//TODO ..
			//this.sendEvent(anomalyJob);
			return MARK_AS_ERRORED;
		};
	}

	@Override
	protected Class<AnomalyJob> getJobClass() {
		return AnomalyJob.class;
	}

}
