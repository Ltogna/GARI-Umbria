package com.abacogroup.cllapi.exceptions;

import com.abacogroup.common.exceptions.AbstractAppException;
import io.swagger.v3.oas.annotations.media.Schema;

public class InvalidDocumentException extends AbstractAppException {

	public InvalidDocumentException(InvalidDocumentException.ErrEnum code, String message) {
		super(new InvalidDocumentException.ErrorBody(code.name(), message));
	}

	public enum ErrEnum {
		DYNAMIC_DOCUMENT_ERR,
		DYNAMIC_DOCUMENT_NOT_FOUND,
		DYNAMIC_DOCUMENT_FILE_NOT_FOUND

	}

	@Schema(name = "InvalidDocumentExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { "DYNAMIC_DOCUMENT_ERR", "DYNAMIC_DOCUMENT_NOT_FOUND", "DYNAMIC_DOCUMENT_FILE_NOT_FOUND" })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}
}
