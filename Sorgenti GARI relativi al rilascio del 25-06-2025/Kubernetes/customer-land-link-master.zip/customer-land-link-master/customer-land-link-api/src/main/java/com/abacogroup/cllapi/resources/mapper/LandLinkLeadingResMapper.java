package com.abacogroup.cllapi.resources.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.cllapi.api.LandLinkLeadingRes;
import com.abacogroup.cllapi.api.LandLinkLeadingResWithHolder;

@Mapper
public interface LandLinkLeadingResMapper {

	LandLinkLeadingResMapper INSTANCE = Mappers.getMapper(LandLinkLeadingResMapper.class);

	LandLinkLeadingResWithHolder toLandLinkLeadindResWithHolder(LandLinkLeadingRes sector);

}
