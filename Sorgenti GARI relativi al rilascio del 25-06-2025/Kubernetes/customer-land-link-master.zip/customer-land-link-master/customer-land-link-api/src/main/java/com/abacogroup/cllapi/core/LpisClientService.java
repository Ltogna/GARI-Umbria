package com.abacogroup.cllapi.core;

import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

import com.abacogroup.cllcli.api.v1.enums.ParcelSearchLevel;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lpisgisserver.api.v1.PublicParcel;
import com.abacogroup.lpisgisserver.api.v1.PublicParcelBlockList;
import com.abacogroup.lpisgisserver.api.v1.PublicSector;

public interface LpisClientService {

	/**
	 * @param context
	 * @param referenceDate
	 * @param sectorDescrFilter al momento insiste solo su sector:short_descr
	 * @param blockDescrFilter
	 * @param parcelFilter
	 * @return
	 */
	List<PublicParcel> searchParcels(ReqContext context, AbsoluteDate referenceDate, String sectorDescrFilter, String blockDescrFilter, String parcelFilter,
			Boolean includeGeometries, Boolean includeLandCovers, Integer pageSize);

	List<PublicParcel> getParcelsByIdIn(ReqContext context, AbsoluteDate referenceDate, List<Long> parcelIds, ParcelSearchLevel parcelSearchLevel);

	void consumeParcelsByIdIn(ReqContext context, Boolean inclueGeometries, AbsoluteDate referenceDate, List<Long> parcelIds, Consumer<PublicParcel> consumer);

	InfiniteListResults<PublicParcel> searchParcels(ReqContext context, AbsoluteDate referenceDate, String sectorDescrFilter, String blockDescrFilter,
			String parcelFilter, Boolean includeGeometries, Boolean includeLandCovers, ParcelSearchLevel parcelSearchLevel, String nextKey, Integer pageSize);

	List<PublicParcel> getParcelsBySectorCode(ReqContext context, AbsoluteDate referenceDate, String sectorCode);
	
	PublicParcel persistTemporaryParcels(ReqContext context, Long parcelId);

	List<PublicSector> getSectors(ReqContext context, String filter);
	
	PublicParcelBlockList getBlocks(ReqContext context, String sectorCode, String filter);

	PublicSector getSectorDetails(ReqContext context, String sectorCode);

	Optional<PublicParcel> getParcelById(ReqContext context, AbsoluteDate referenceDate, Long parcelId);
}
