package com.abacogroup.cllapi.bundle.config.i18n;

import java.util.Set;

public interface I18nAware {

	String getI18nCode();

	Set<I18nEntry> getI18n();
}
