package com.abacogroup.cllapi.api.req;

import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.common.resources.ResourceConstants;
import com.abacogroup.common.resources.req.BaseSearchReq;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.OrderByElement;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import jakarta.ws.rs.QueryParam;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@Accessors(chain = true)
@SuperBuilder(setterPrefix = "set")
public class GroupSearchReq implements BaseSearchReq {

	@Parameter(in = ParameterIn.QUERY, description = "group description")
	@QueryParam("descr")
	private String descr;

	@Parameter(in = ParameterIn.QUERY, description = "title Type Id")
	@QueryParam("titleTypeId")
	private Long titleTypeId;

	@Parameter(in = ParameterIn.QUERY, description = "show elapsed groups")
	@Default
	@QueryParam("showElapsed")
	private boolean showElapsed = false;

	/**
	 * @deprecated use party id from path variable
	 */
	@Deprecated(forRemoval = true)
	@Parameter(in = ParameterIn.QUERY, description = "party Id", deprecated = true)
	@QueryParam("partyId")
	private Long partyId;

	@Override
	public int getPageSize() {
		return ResourceConstants.PAGE_SIZE;
	}

	@Override
	public Criteria getCriteria(ReqContext reqContext) {
		List<Criteria> specs = new ArrayList<>();

		//like descr
		Optional.ofNullable(this.getDescr())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("gd.descr").caseInsensitiveContains(v)));

		Optional.ofNullable(this.getTitleTypeId())
				.map(v -> CriteriaBuilder.number("g.title_type_id").eq(v))
				.ifPresent(specs::add);

		return CriteriaBuilder.and(specs.toArray(new Criteria[0]));
	}

	@Override
	public OrderByElement getSort() {
		return OrderByBuilder.field(" g.id");
	}
}
