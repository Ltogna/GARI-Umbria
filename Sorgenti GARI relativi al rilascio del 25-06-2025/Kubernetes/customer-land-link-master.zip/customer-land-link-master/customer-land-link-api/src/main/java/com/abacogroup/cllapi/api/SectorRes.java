package com.abacogroup.cllapi.api;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class SectorRes {

	private Long id;

	private String description;

	private String shortDescr;

	private String sectorCode;
}
