package com.abacogroup.cllapi.api.acl;

import jakarta.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class EntityTypeV1 {
	
	@Schema(description = "Entity type id", type = "integer", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Long id;
	
	@Schema(description = "Entity type code", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String code;
	
	@Schema(description = "Entity type code description", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String description;
	
	@Schema(description = "If true Entity code is required", type = "boolean", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Boolean flEntityCodeMandatory;
}