package com.abacogroup.cllapi.resources.pub;

import com.abacogroup.cllapi.core.CllSettingsV1Service;
import com.abacogroup.cllcli.api.v1.CllSettingsResponseV1;
import com.abacogroup.cllcli.resources.PublicResourceConstants;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;

@Path(PublicResourceConstants.API_V1_PUB + "/settings")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "CLL Settings")
@Tag(name = "Public APIs", description = "All public APIs")
public class CllSettingsPublicResource {

	private final CllSettingsV1Service cllSettingsV1Service;

	public CllSettingsPublicResource(CllSettingsV1Service cllSettingsV1Service) {
		this.cllSettingsV1Service = cllSettingsV1Service;
	}

	@GET
	@Path("")
	//	@RolesAllowed({ "*****|EDITOR", "*****|VIEWER" })
	@Operation(description = "Get application settings by tenant", summary = "CLL settings")
	@ApiResponse(responseCode = "200", description = "settings", useReturnTypeSchema = true)
	public CllSettingsResponseV1 getCllSettings(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId
	) {

		return cllSettingsV1Service.getSettings(new ReqContext(user, lang));
	}


}
