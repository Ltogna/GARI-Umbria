package com.abacogroup.cllapi.db.dao;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DAOContainer {
	private I18nDAO i18nDAO;
	private LandLinkDAO landLinkDAO;
	private TitleTypeDAO titleTypeDAO;
	private GroupDAO groupDAO;
	private DocTypeRelationDAO docTypeRelationDAO;
	private GroupDocumentDAO groupDocumentDAO;
	private LandLinkDocumentDAO landLinkDocumentDAO;
	private CllSettingsDAO cllSettingsDAO;
	private AnomalyCategoriesDAO anomalyCategoriesDAO;
	private AnomaliesDAO anomaliesDAO;
	private SupportDAO supportDAO;
}
