package com.abacogroup.cllapi.core;

import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import java.util.List;
import java.util.Optional;

public interface PartyClientService {

	Optional<PartyResponseV1> getById(ReqContext context, Long id);

	List<PartyResponseV1> getByIds(ReqContext context, List<Long> ids);

	Optional<PartyResponseV1> getByCode(ReqContext context, String code);

}
