package com.abacogroup.cllapi.db.dao;

import com.abacogroup.cllapi.api.GroupDocumentRes;
import com.abacogroup.cllapi.db.ntt.GroupDocumentEntity;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface GroupDocumentDAO extends Transactional<GroupDocumentDAO>, EnhancedSqlObject {

	String FIELDS = " gd.pkid, gd.group_id, gd.definition_code, gd.document_id, gd.dt_insert, gd.user_id_insert, gd.dt_delete, gd.user_id_delete\n";

	String CURRENT_RECORD = " AND (§current_timestamp§ between gd.dt_insert and gd.dt_delete) ";

	@SqlQuery("select " + FIELDS
			+ " FROM cll_group_documents gd "
			+ " join cll_group g on g.id = gd.group_id "
			+ " where gd.group_id = :groupId "
			+ " and g.tenant_id = :tenantId "
			+ " and <criteria> "
			+ CURRENT_RECORD
			+ " ORDER BY <orderBy> ")
	@RegisterBeanMapper(GroupDocumentRes.class)
	ResultIterator<GroupDocumentRes> search(
			@Bind("groupId") Long groupId,
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx);

	@SqlQuery("select count(*) "
			+ " FROM cll_group_documents gd "
			+ " join cll_group g on g.id = gd.group_id "
			+ " where gd.definition_code = :definitionCode "
			+ " and g.id = :groupId "
			+ " and g.tenant_id = :tenantId "
			+ CURRENT_RECORD)
	Long countByDefinitionCodeAndGroupId(
			@Bind("tenantId") String tenantId,
			@Bind("definitionCode") String definitionCode,
			@Bind("groupId") Long groupId);

	@SqlQuery("select " + FIELDS
			+ " FROM cll_group_documents gd "
			+ " join cll_group g on g.id = gd.group_id "
			+ " where gd.document_id = :documentId "
			+ " and g.id = :groupId "
			+ " and g.tenant_id = :tenantId "
			+ CURRENT_RECORD)
	@RegisterBeanMapper(GroupDocumentRes.class)
	Optional<GroupDocumentRes> getByDocumentIdAndGroupId(
			@Bind("documentId") Long documentId,
			@Bind("groupId") Long groupId,
			@BindBean ReqContext ctx);

	@SqlQuery("select " + FIELDS
			+ " FROM cll_group_documents gd "
			+ " join cll_group g on g.id = gd.group_id "
			+ " where g.id = :groupId "
			+ " and gd.definition_code = :definitionCode "
			+ " and g.tenant_id = :tenantId "
			+ CURRENT_RECORD)
	@RegisterBeanMapper(GroupDocumentRes.class)
	List<GroupDocumentRes> getByGroupIdAndDefinitionCode(
			@Bind("groupId") Long groupId,
			@Bind("definitionCode") String definitionCode,
			@BindBean ReqContext ctx);

	@SqlQuery("select " + FIELDS
			+ " FROM cll_group_documents gd "
			+ " join cll_group g on g.id = gd.group_id "
			+ " where gd.document_id = :documentId "
			+ " and g.id = :groupId "
			+ " and g.tenant_id = :tenantId "
			+ CURRENT_RECORD)
	@RegisterBeanMapper(GroupDocumentEntity.class)
	Optional<GroupDocumentEntity> findByDocumentIdAndGroupId(
			@Bind("tenantId") String tenantId,
			@Bind("documentId") Long documentId,
			@Bind("groupId") Long groupId);

	@SqlUpdate(
			"INSERT INTO cll_group_documents (group_id, definition_code, document_id, dt_insert, user_id_insert, dt_delete, user_id_delete) "
					+ " VALUES (:groupId, :definitionCode, :documentId, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	@GetGeneratedKeys("pkid")
	Long insert(@BindBean GroupDocumentEntity entity);

	@SqlUpdate("update cll_group_documents set dt_delete =:dtDelete, user_id_delete=:userIdDelete where pkid = :pkid")
	void expireRow(@BindBean GroupDocumentEntity entity);
}
