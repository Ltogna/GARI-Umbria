package com.abacogroup.cllapi.resources.mapper;

import com.abacogroup.cllapi.api.ParcelRes;
import com.abacogroup.lpisgisserver.api.v1.PublicParcel;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ParcelMapper {

	ParcelMapper INSTANCE = Mappers.getMapper(ParcelMapper.class);

	ParcelRes toParcelRes(PublicParcel parcel);

}
