package com.abacogroup.cllapi.exceptions;

import com.abacogroup.common.exceptions.AbstractAppException;
import io.swagger.v3.oas.annotations.media.Schema;

public class TitleTypeException extends AbstractAppException {

	public TitleTypeException(ErrEnum code, String message) {
		super(new ErrorBody(code.name(), message));
	}

	public enum ErrEnum {
		NOT_FOUND,

	}

	@Schema(name = "TitleTypeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { "NOT_FOUND" })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}
}
