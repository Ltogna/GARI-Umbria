package com.abacogroup.cllapi.resources.pub.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.cllapi.api.GroupDocumentRes;
import com.abacogroup.cllapi.api.req.GroupDocumentSearchReq;
import com.abacogroup.cllcli.api.v1.GroupDocumentResponseV1;
import com.abacogroup.cllcli.api.v1.req.GroupDocumentSearchRequestV1;

@Mapper
public interface GroupDocumentPublicMapper {

	GroupDocumentPublicMapper INSTANCE = Mappers.getMapper(GroupDocumentPublicMapper.class);

	GroupDocumentResponseV1 toResponseV1(GroupDocumentRes res);
	
	GroupDocumentSearchReq fromCreateRequestV1(GroupDocumentSearchRequestV1 createRequestV1);

}
