package com.abacogroup.cllapi.core.impl;

import com.abacogroup.cllapi.api.TitleType;
import com.abacogroup.cllapi.core.TitleTypeService;
import com.abacogroup.cllapi.db.dao.TitleTypeDAO;
import com.abacogroup.cllapi.db.ntt.TitleTypeEntity;
import com.abacogroup.common.resources.ReqContext;
import java.util.List;
import java.util.Optional;

public class TitleTypeServiceImpl implements TitleTypeService {

	private final TitleTypeDAO titleTypeDAO;

	public TitleTypeServiceImpl(TitleTypeDAO titleTypeDAO) {
		this.titleTypeDAO = titleTypeDAO;
	}

	@Override
	public Optional<TitleTypeEntity> loadById(ReqContext reqContext, Long id) {
		return titleTypeDAO.findById(reqContext, id);
	}

	@Override
	public Optional<TitleType> getById(ReqContext reqContext, Long id) {
		return titleTypeDAO.searchById(reqContext, id);
	}

	@Override
	public List<TitleType> searchAll(ReqContext reqContext) {
		return titleTypeDAO.searchAll(reqContext);
	}
}
