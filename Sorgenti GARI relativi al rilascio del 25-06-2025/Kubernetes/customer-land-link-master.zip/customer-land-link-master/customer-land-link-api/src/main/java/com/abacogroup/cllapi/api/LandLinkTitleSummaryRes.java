package com.abacogroup.cllapi.api;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@Accessors(chain = true)
@NoArgsConstructor
public class LandLinkTitleSummaryRes {

	private TitleType titleType;

	private Long linkCount;
	private Long totParcelAreaSqm;
	private Long totTitleTypeAreaSqm;
}
