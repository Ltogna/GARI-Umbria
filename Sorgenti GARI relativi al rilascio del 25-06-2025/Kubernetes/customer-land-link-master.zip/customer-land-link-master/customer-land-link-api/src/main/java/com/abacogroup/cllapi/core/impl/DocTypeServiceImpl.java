package com.abacogroup.cllapi.core.impl;

import java.util.List;
import java.util.stream.Collectors;

import com.abacogroup.cllapi.api.DocTypeRelationRes;
import com.abacogroup.cllapi.api.GroupDocumentDefinition;
import com.abacogroup.cllapi.api.enums.DocTypeRelationScope;
import com.abacogroup.cllapi.core.DocTypeService;
import com.abacogroup.cllapi.core.GroupDocumentService;
import com.abacogroup.cllapi.core.GroupService;
import com.abacogroup.cllapi.core.LandLinkDocumentService;
import com.abacogroup.cllapi.core.TitleTypeService;
import com.abacogroup.cllapi.db.dao.DAOContainer;
import com.abacogroup.cllapi.db.dao.DocTypeRelationDAO;
import com.abacogroup.cllapi.db.dao.LandLinkDAO;
import com.abacogroup.cllapi.db.ntt.GroupEntity;
import com.abacogroup.cllapi.db.ntt.LandLinkEntity;
import com.abacogroup.cllapi.db.ntt.TitleTypeEntity;
import com.abacogroup.cllapi.exceptions.GroupException;
import com.abacogroup.cllapi.exceptions.InvalidDocumentException;
import com.abacogroup.cllapi.exceptions.InvalidTitleTypeException;
import com.abacogroup.cllapi.exceptions.InvalidTitleTypeException.ErrEnum;
import com.abacogroup.cllapi.exceptions.LandLinkException;
import com.abacogroup.cllapi.resources.mapper.DocTypeRelationMapper;
import com.abacogroup.cllapi.resources.mapper.GroupDocumentDefinitionMapper;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;

public class DocTypeServiceImpl implements DocTypeService {

	private final DocTypeRelationDAO docTypeRelationDAO;
	private final LandLinkDAO landLinkDAO;

	private final TitleTypeService titleTypeService;
	private final GroupService groupService;
	private final GroupDocumentService groupDocumentService;
	private final LandLinkDocumentService landLinkDocumentService;
	private final DocumentTypeService documentTypeService;

	private final String dynamicDocumentsBucket;

	public DocTypeServiceImpl(DAOContainer container, TitleTypeService titleTypeService, GroupService groupService,
			GroupDocumentService groupDocumentService, LandLinkDocumentService landLinkDocumentService, 
			DocumentTypeService documentTypeService, String dynamicDocumentsBucket) {
		this.docTypeRelationDAO = container.getDocTypeRelationDAO();
		this.landLinkDAO = container.getLandLinkDAO();
		this.titleTypeService = titleTypeService;
		this.groupService = groupService;
		this.groupDocumentService = groupDocumentService;
		this.landLinkDocumentService = landLinkDocumentService;
		this.documentTypeService = documentTypeService;
		this.dynamicDocumentsBucket = dynamicDocumentsBucket;
	}

	@Override
	public List<DocTypeRelationRes> getByGroupIdOrLandLinkId(ReqContext context, Long groupId, Long landLinkId, DocTypeRelationScope scope) {
		
		if(landLinkId != null) {
			LandLinkEntity landLink = loadLandLink(context, landLinkId);
			
			if(groupId != null) {
				if(!landLink.getGroupId().equals(groupId)) {
					throw new LandLinkException(LandLinkException.ErrEnum.NOT_FOUND, String.format("Land link %s not found", landLinkId));
				}
			} else {
				groupId = landLink.getGroupId();
			}
		}
		
		// load groupEntity to extract its titleType
		GroupEntity group = loadGroup(context, groupId);
		// validate titleType
		loadTitleType(context, group.getTitleTypeId());

		final Long finalGroupId = groupId;
		return docTypeRelationDAO.getByTitleTypeAndScopeCode(context, group.getTitleTypeId(), scope)
				.stream()
				.map(dt -> DocTypeRelationMapper.addSummaryFields(context, dt, documentTypeService))
				.map(d -> {
					switch (scope) {
					case LANDLINKS:
						if(landLinkId != null) {
							return DocTypeRelationMapper.addFlDocPresent(context, d, landLinkId, landLinkDocumentService);
						} else {
							return d;
						}
					case GROUPS:
						return DocTypeRelationMapper.addFlDocPresent(context, d, finalGroupId, groupDocumentService);
					default:
						return d;
					}
				})
				.collect(Collectors.toList());
	}

	@Override
	public GroupDocumentDefinition getDefinition(ReqContext reqContext, String definitionCode) {
		return documentTypeService.getDocumentDefinition(reqContext.getTenantId(), definitionCode)
				.map(GroupDocumentDefinitionMapper.INSTANCE::toGroupDocumentDefinition)
				.map(groupDocumentDefinition -> groupDocumentDefinition.setBucketName(dynamicDocumentsBucket))
				.orElseThrow(
						() -> new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR,
								String.format("error loading definition for %s", definitionCode)));
	}

	private TitleTypeEntity loadTitleType(ReqContext reqContext, Long id) {
		return titleTypeService.loadById(reqContext, id)
				.orElseThrow(() -> new InvalidTitleTypeException(ErrEnum.TITLE_TYPE_NOT_FOUND, String.format("titleType %s not found", id)));
	}

	private GroupEntity loadGroup(ReqContext reqContext, Long id) {
		return groupService.loadById(reqContext, id)
				.orElseThrow(() -> new GroupException(GroupException.ErrEnum.NOT_FOUND, String.format("group %s not found", id)));
	}
	
	private LandLinkEntity loadLandLink(ReqContext reqContext, Long id) {
		return landLinkDAO.findByIdAndTenant(id, reqContext.getTenantId())
				.orElseThrow(() ->new LandLinkException(LandLinkException.ErrEnum.NOT_FOUND, String.format("Land link %s not found", id)));
	}
}
