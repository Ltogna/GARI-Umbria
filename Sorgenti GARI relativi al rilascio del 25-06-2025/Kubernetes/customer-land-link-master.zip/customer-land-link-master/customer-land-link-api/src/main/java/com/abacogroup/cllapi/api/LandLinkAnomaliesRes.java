package com.abacogroup.cllapi.api;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.cllcli.api.v1.AnomalyLevelEnum;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class LandLinkAnomaliesRes {

	@Default
	@JsonAnyGetter
	@JsonAnySetter
	@JsonProperty(access = Access.WRITE_ONLY)
	private Map<AnomalyLevelEnum, List<AnomalySearchResponse>> anomaliesGrouped = new HashMap<>();

}
