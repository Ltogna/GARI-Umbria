package com.abacogroup.cllapi.resources.pub.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllcli.api.v1.LandLinkResV1;

@Mapper
public interface LandLinkResponseMapper {

	LandLinkResponseMapper INSTANCE = Mappers.getMapper(LandLinkResponseMapper.class);

	LandLinkResV1 toResponseV1(LandLinkRes resList);

	List<LandLinkResV1> toResponseV1List(List<LandLinkRes> resList);

}
