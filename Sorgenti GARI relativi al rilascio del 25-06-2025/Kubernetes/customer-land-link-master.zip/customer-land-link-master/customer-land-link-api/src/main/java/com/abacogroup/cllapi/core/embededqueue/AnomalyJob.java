package com.abacogroup.cllapi.core.embededqueue;

import com.abacogroup.cllapi.core.dto.CllEventType;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import java.time.LocalDateTime;
import java.util.Collection;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(setterPrefix = "set")
@AllArgsConstructor
@NoArgsConstructor
public class AnomalyJob {

	private String tenant;
	private String username;
	private String lang;
	private Long partyId;
	private LocalDateTime date;
	private AbsoluteDate fromDate;
	private Collection<Long> groupIds;
	private Collection<Long> landLinkIds;
	private CllEventType eventType;

}
