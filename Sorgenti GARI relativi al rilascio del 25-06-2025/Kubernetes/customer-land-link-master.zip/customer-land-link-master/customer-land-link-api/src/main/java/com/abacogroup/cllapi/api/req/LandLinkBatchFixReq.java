package com.abacogroup.cllapi.api.req;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LandLinkBatchFixReq {
	
	private String tenantId;
	private String username;
	private AbsoluteDate referenceDate;
	private Long rentLinkId;
	private Long propertyLinkId;
	
}
