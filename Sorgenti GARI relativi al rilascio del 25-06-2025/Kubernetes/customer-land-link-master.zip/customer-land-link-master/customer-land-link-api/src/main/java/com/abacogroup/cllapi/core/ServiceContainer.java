package com.abacogroup.cllapi.core;

import com.abacogroup.cllapi.core.impl.SupportService;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ServiceContainer {
	private DocumentService documentService;
	private DocumentTypeService documentTypeService;
	private PartyClientService partyClientService;
	private PartiesAclClientService partiesAclClientService;
	private LpisClientService lpisClientService;
	private AnomalyService anomalyService;
	private TitleTypeService titleTypeService;
	private LandLinkService landLinkService;
	private GroupService groupService;
	private GroupDocumentService groupDocumentService;
	private LandLinkDocumentService landLinkDocumentService;
	private DocTypeService docTypeRelationService;
	private ParcelService parcelService;
	private LandLinkV1Service landLinkV1Service;
	private CllSettingsV1Service cllSettingsV1Service;
	private ParcelV1Service parcelV1Service;
	private SupportService supportService;
}
