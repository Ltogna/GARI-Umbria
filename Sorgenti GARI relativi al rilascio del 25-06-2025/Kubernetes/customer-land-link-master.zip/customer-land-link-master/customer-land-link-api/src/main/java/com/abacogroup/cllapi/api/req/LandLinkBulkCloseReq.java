package com.abacogroup.cllapi.api.req;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;
import lombok.Builder.Default;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class LandLinkBulkCloseReq extends LandLinkCloseReq {

	@Valid
	@NotEmpty
	@Default
	private List<@NotNull Long> landLinkIds = new ArrayList<>();
}
