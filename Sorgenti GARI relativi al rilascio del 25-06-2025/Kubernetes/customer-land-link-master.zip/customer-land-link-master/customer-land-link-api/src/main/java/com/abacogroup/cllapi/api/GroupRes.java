package com.abacogroup.cllapi.api;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;
import org.jdbi.v3.core.mapper.Nested;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class GroupRes extends GroupBaseRes {

	private Long partyId; // TODO full dto?
	@Nested("title")
	private TitleType titleType;

	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;

	private Long linkCount;

}
