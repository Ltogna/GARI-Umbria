package com.abacogroup.cllapi.core;

import com.abacogroup.cllapi.api.TitleType;
import com.abacogroup.cllapi.db.ntt.TitleTypeEntity;
import com.abacogroup.common.resources.ReqContext;
import java.util.List;
import java.util.Optional;

public interface TitleTypeService {

	Optional<TitleTypeEntity> loadById(ReqContext reqContext, Long id);
	
	Optional<TitleType> getById(ReqContext reqContext, Long id);

	List<TitleType> searchAll(ReqContext reqContext);
}
