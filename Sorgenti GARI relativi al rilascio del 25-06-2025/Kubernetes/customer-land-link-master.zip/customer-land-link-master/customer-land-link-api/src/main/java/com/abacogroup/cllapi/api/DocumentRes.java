package com.abacogroup.cllapi.api;

import com.abacogroup.dynamicdocuments.bean.SummaryFieldDefinition;
import java.util.LinkedHashMap;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
public class DocumentRes {

	private String definitionCode;
	private Long documentId;

	private String bucketName;

	private List<SummaryFieldDefinition> summaryFieldDefinitions;
	private LinkedHashMap<String, Object> data;

}
