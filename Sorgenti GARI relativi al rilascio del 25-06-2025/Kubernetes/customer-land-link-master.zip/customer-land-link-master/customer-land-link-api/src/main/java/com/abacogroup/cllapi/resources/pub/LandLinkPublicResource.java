package com.abacogroup.cllapi.resources.pub;

import java.util.List;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.cllapi.api.req.LandLinkSearchReq;
import com.abacogroup.cllapi.core.LandLinkV1Service;
import com.abacogroup.cllapi.exceptions.LandLinkException;
import com.abacogroup.cllcli.api.v1.LandLinkAnomaliesResV1;
import com.abacogroup.cllcli.api.v1.LandLinkResV1;
import com.abacogroup.cllcli.api.v1.LandLinkSectorSummaryResponseV1;
import com.abacogroup.cllcli.resources.PublicResourceConstants;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.SchemaProperty;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(PublicResourceConstants.API_V1_PUB + "/parties/{partyId}/land-links")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Land Links")
@Tag(name = "Public APIs", description = "All public APIs")
public class LandLinkPublicResource {

	private final LandLinkV1Service landLinkService;

	public LandLinkPublicResource(LandLinkV1Service landLinkService) {
		this.landLinkService = landLinkService;
	}

	@GET
	@Path("/{referenceDate}")
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Operation(description = "Get the list of filtered land links.  *MOCK parameters are ignored by server*", summary = "search land links")
	@ApiResponse(responseCode = "200", description = "Get the list of filtered land links", useReturnTypeSchema = true)
	public InfiniteListResults<LandLinkResV1> searchLandLinks(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "reference date", schema = @Schema(format = AbsoluteDate.DATE_PATTERN)) @PathParam("referenceDate") @Size(min = 8, max = 8) String referenceDate,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
			@BeanParam @Valid LandLinkSearchReq searchReq) {


		return landLinkService.search(new ReqContext(user, lang), AbsoluteDate.of(referenceDate), searchReq, true, nextKey, null);
	}


	@GET
	@Path("/summary")
	//	@RolesAllowed({ "*****|EDITOR", "*****|VIEWER" })
	@Operation(description = "Get land links summary by sector and title", summary = "land links summary")
	@ApiResponse(responseCode = "200", description = "Get the list of sector land link summary", useReturnTypeSchema = true)
	public List<LandLinkSectorSummaryResponseV1> getLandLinkSummary(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party ID") @PathParam("partyId") Long partyId
			) {

		return landLinkService.getSummary(new ReqContext(user, lang), partyId);
	}

	@GET
	@Path("/{referenceDate}/{landLinkId}/anomalies")
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Operation(description = "Get land link anomalies by id", summary = "get land link anomalies grouped by level")
	@ApiResponse(responseCode = "200", description = "land link anomalies", content = @Content(schema = @Schema(type = "object"),
	schemaProperties = {
			@SchemaProperty(name = "INFO", schema = @Schema(implementation = AnomalySearchResponse.class)),
			@SchemaProperty(name = "WARN", schema = @Schema(implementation = AnomalySearchResponse.class)),
			@SchemaProperty(name = "DANGER", schema = @Schema(implementation = AnomalySearchResponse.class)),
	}, mediaType = MediaType.APPLICATION_JSON))
	@ApiResponse(responseCode = "400", description = "land link not found", content = @Content(mediaType = MediaType.APPLICATION_JSON,
	schema = @Schema(implementation = LandLinkException.ErrorBody.class)))
	public LandLinkAnomaliesResV1 getLandLinkAnomalies(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "reference date", schema = @Schema(format = AbsoluteDate.DATE_PATTERN))
			@PathParam("referenceDate") @Size(min = 8, max = 8) String referenceDate,
			@Parameter(description = "land link id") @PathParam("landLinkId") Long landLinkId) {

		ReqContext reqContext = new ReqContext(user, lang);
		return landLinkService.getAnomalies(reqContext, AbsoluteDate.of(referenceDate), partyId, landLinkId);
	}


}
