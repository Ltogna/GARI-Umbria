package com.abacogroup.cllapi.db.ntt;

import com.abacogroup.cllcli.api.v1.AnomalyLevelEnum;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class AnomalyCategoriesEntity {
	private String groupCode;
	private String code;
	private AnomalyLevelEnum level;
	private Integer flExclude;
}
