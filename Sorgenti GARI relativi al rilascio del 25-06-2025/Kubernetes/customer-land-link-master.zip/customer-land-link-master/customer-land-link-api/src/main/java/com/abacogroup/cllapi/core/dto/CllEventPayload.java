package com.abacogroup.cllapi.core.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import lombok.Builder.Default;
import lombok.Data;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@Accessors(chain = true)
@SuperBuilder(setterPrefix = "set")
public class CllEventPayload {
	
	private String tenant;
	private String username;
	private String lang;
	private CllEventType eventType;
	
	private LocalDateTime date;

	private Long partyId;

	@Default
	private List<LandLinkPayload> landLinks = new ArrayList();
}
