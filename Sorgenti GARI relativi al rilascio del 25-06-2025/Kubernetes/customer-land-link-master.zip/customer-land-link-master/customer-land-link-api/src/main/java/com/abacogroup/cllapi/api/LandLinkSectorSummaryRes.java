package com.abacogroup.cllapi.api;

import java.util.ArrayList;
import java.util.List;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@Accessors(chain = true)
@NoArgsConstructor
public class LandLinkSectorSummaryRes {

	private SectorRes sector;

	private Long linkCount;
	private Long totParcelAreaSqm;
	private Long totTitleTypeAreaSqm;

	@Default
	private List<LandLinkTitleSummaryRes> titleSummaryRes = new ArrayList<>();

}
