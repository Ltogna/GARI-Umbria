package com.abacogroup.cllapi.resources.pub;
import com.abacogroup.cllapi.core.GroupDocumentService;
import com.abacogroup.cllapi.exceptions.GroupException;
import com.abacogroup.cllapi.resources.pub.mapper.GroupDocumentPublicMapper;
import com.abacogroup.cllcli.api.v1.GroupDocumentResponseV1;
import com.abacogroup.cllcli.api.v1.req.GroupDocumentSearchRequestV1;
import com.abacogroup.cllcli.resources.PublicResourceConstants;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Path(PublicResourceConstants.API_V1_PUB + "/parties/{partyId}/groups/{groupId}/documents")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Group documents", description = "Operations on group documents")
@Tag(name = "Public APIs", description = "All public APIs")
public class GroupDocumentPublicResource {

	private final GroupDocumentService groupDocumentService;

	public GroupDocumentPublicResource(GroupDocumentService groupDocumentService) {
		this.groupDocumentService = groupDocumentService;
	}

	@Operation(summary = "List of documents of a specific type", description = "Get list of documents filtered with criteria")
	@ApiResponse(responseCode = "200", description = "Successfully, returns a list of documents (sorted/filtered)", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "group not found", content = @Content(mediaType = MediaType.APPLICATION_JSON,
			schema = @Schema(implementation = GroupException.ErrorBody.class)))
	@GET
	@Path("")
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	public InfiniteListResults<GroupDocumentResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "party ID") @PathParam("partyId") Long partyId,
			@Parameter(description = "group ID") @PathParam("groupId") Long groupId,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
			@BeanParam GroupDocumentSearchRequestV1 searchReq) {

		ReqContext reqContext = new ReqContext(user, lang);
		return groupDocumentService.search(reqContext, partyId, groupId, GroupDocumentPublicMapper.INSTANCE.fromCreateRequestV1(searchReq), nextKey)
				.map(GroupDocumentPublicMapper.INSTANCE::toResponseV1);
	}

}
