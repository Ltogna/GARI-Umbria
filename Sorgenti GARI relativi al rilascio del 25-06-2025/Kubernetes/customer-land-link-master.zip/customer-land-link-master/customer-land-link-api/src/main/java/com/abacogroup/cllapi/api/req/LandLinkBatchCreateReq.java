package com.abacogroup.cllapi.api.req;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class LandLinkBatchCreateReq extends LandLinkUpdateReq {

	@NotNull
	private Long parcelId;

}
