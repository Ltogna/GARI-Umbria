package com.abacogroup.common.resources.req;

import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;

public interface BaseSearchReq {

	@JsonIgnore
	@Schema(hidden = true)
	int getPageSize();

	@JsonIgnore
	@Schema(hidden = true)
	Criteria getCriteria(ReqContext reqContext);

	@JsonIgnore
	@Schema(hidden = true)
	OrderByElement getSort();
}
