package com.abacogroup.cllapi.core.impl;

import com.abacogroup.common.core.cli.AuthorizationStrategy;
import com.abacogroup.common.core.cli.TokenRelayStrategy;
import com.abacogroup.dropwizard.auth.sso2.User;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;
import java.time.Duration;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.ServerErrorException;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FileStoreProxyClient {

	private final WebTarget fileTarget;
	private final AuthorizationStrategy authorizationStrategy;
	private RetryRegistry retryRegistry;

	public FileStoreProxyClient(WebTarget fsTarget) {
		this.fileTarget = fsTarget.path("/{tenantId}/public/v1/files");
		this.authorizationStrategy = new TokenRelayStrategy();

		this.retryRegistry = RetryRegistry.of(RetryConfig.custom()
				.maxAttempts(2)
				.waitDuration(Duration.ofMillis(500))
				.failAfterMaxAttempts(true)
				.retryExceptions(ProcessingException.class, ServerErrorException.class)
				.build());
	}

	public Response getFileContent(String lang, User user, String bucket, String id) {

		String tenantId = user.getTenant();

		WebTarget webTarget = fileTarget.path("/{bucketName}/{id}")
				.resolveTemplate("tenantId", tenantId)
				.resolveTemplate("bucketName", bucket)
				.resolveTemplate("id", id);

		log.trace(webTarget.toString());

		return retryRegistry.retry(webTarget.getUri().toString())
				.executeSupplier(() -> webTarget
						.request()
						.header("accept-language", lang)
						.header("Authorization", authorizationStrategy.getAuthorization(user)) // TODO non null
						.get());

	}

	public Response getFileMetadata(String lang, User user, String bucket, String id) {

		String tenantId = user.getTenant();

		WebTarget webTarget = fileTarget.path("/{bucketName}/{id}")
				.resolveTemplate("tenantId", tenantId)
				.resolveTemplate("bucketName", bucket)
				.resolveTemplate("id", id);

		log.trace(webTarget.toString());

		return retryRegistry.retry(webTarget.getUri().toString())
				.executeSupplier(() -> webTarget
						.request()
						.header("accept-language", lang)
						.header("Authorization", authorizationStrategy.getAuthorization(user)) // TODO non null
						.head());

	}

}
