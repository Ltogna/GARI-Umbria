package com.abacogroup.cllapi.api;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
public class LandLinkDocumentRes extends DocumentRes {

	private Long landLinkId;

}
