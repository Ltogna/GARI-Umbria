package com.abacogroup.cllapi.core.dto;

import com.abacogroup.cllcli.api.v1.AnomalyLevelEnum;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@Accessors(chain = true)
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
@AllArgsConstructor
public class AnomalyMaxLevelDto {

	@Default
	private List<AnomalyDto> anomalies = new ArrayList<>();

	public Long getAnomalyCount() {
		if (null == anomalies) {
			return 0L;
		}

		return (long) anomalies.size();
	}

	public AnomalyLevelEnum getMaxLevel() {
		return Optional.ofNullable(anomalies)
				.stream().flatMap(Collection::stream)
				.map(AnomalyDto::getLevel)
				.min(Comparator.comparingInt(Enum::ordinal))
				.orElse(null);
	}

}
