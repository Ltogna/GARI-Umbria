package com.abacogroup.cllapi.resources.pub.mapper;

import com.abacogroup.cllapi.api.CllSettings;
import com.abacogroup.cllcli.api.v1.CllSettingsResponseV1;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface CllSettingsMapper {

	CllSettingsMapper INSTANCE = Mappers.getMapper(CllSettingsMapper.class);

	CllSettingsResponseV1 toResponseV1(CllSettings res);

}
