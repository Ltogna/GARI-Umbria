package com.abacogroup.cllapi.api;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
public class BlockRes {
	private Long id;

	private String description;

	private String shortDescr;

	private String blockCode;
}
