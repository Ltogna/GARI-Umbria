package com.abacogroup.cllapi.resources.mapper;

import com.abacogroup.cllapi.api.DocTypeRelationRes;
import com.abacogroup.cllapi.core.GroupDocumentService;
import com.abacogroup.cllapi.core.LandLinkDocumentService;
import com.abacogroup.cllapi.db.dao.GroupDocumentDAO;
import com.abacogroup.cllapi.db.dao.LandLinkDocumentDAO;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import java.util.Optional;

public class DocTypeRelationMapper {

	public static DocTypeRelationRes addFlDocPresent(ReqContext reqContext, DocTypeRelationRes docTypeRelation, Long groupId,
			GroupDocumentService groupDocumentService) {
		Long documentsCount = groupDocumentService.countDocumentsByGroupIdAndDefinitionCode(reqContext, groupId, docTypeRelation.getDefinitionCode());

		docTypeRelation.setFlDocPresent(documentsCount > 0L ? 1 : 0);

		return docTypeRelation;
	}
	
	public static DocTypeRelationRes addFlDocPresent(ReqContext reqContext, DocTypeRelationRes docTypeRelation, Long landLinkId,
			LandLinkDocumentService landLinkDocumentService) {
		Long documentsCount = landLinkDocumentService.countDocumentsByLandLinkIdAndDefinitionCode(reqContext, landLinkId, docTypeRelation.getDefinitionCode());

		docTypeRelation.setFlDocPresent(documentsCount > 0L ? 1 : 0);

		return docTypeRelation;
	}

	public static DocTypeRelationRes addFlDocPresent(ReqContext reqContext, DocTypeRelationRes docTypeRelation, Long groupId,
			GroupDocumentDAO groupDocumentDAO) {
		Long documentsCount = groupDocumentDAO.countByDefinitionCodeAndGroupId(reqContext.getTenantId(), docTypeRelation.getDefinitionCode(), groupId);
		docTypeRelation.setFlDocPresent(documentsCount > 0L ? 1 : 0);
		return docTypeRelation;
	}
	
	public static DocTypeRelationRes addFlDocPresent(ReqContext reqContext, DocTypeRelationRes docTypeRelation, Long landLinkId,
			LandLinkDocumentDAO landLinkDocumentDAO) {
		Long documentsCount = landLinkDocumentDAO.countByDefinitionCodeAndLandLinkId(reqContext.getTenantId(), docTypeRelation.getDefinitionCode(), landLinkId);
		docTypeRelation.setFlDocPresent(documentsCount > 0L ? 1 : 0);
		return docTypeRelation;
	}

	public static DocTypeRelationRes addSummaryFields(ReqContext reqContext, DocTypeRelationRes docTypeRelationRes, DocumentTypeService documentTypeService) {
		Optional<DocumentDefinition> def = documentTypeService.getDocumentDefinition(reqContext.getTenantId(), docTypeRelationRes.getDefinitionCode());

		def.ifPresent(d -> {
			docTypeRelationRes.setSummaryFieldDefinitions(documentTypeService.getSummaryFields(def.get(), reqContext.getLang()));
			docTypeRelationRes.setMultiple(d.getMetadata().getMaxOccurs() != null && d.getMetadata().getMaxOccurs() > 1);
		});
		return docTypeRelationRes;
	}

}
