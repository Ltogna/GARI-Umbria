package com.abacogroup.cllapi.resources.pub.mapper;

import com.abacogroup.cllapi.api.GroupRes;
import com.abacogroup.cllapi.api.req.GroupCreateReq;
import com.abacogroup.cllcli.api.v1.GroupResponseV1;
import com.abacogroup.cllcli.api.v1.req.GroupCreateRequestV1;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface GroupPublicMapper {

	GroupPublicMapper INSTANCE = Mappers.getMapper(GroupPublicMapper.class);

	GroupResponseV1 toResponseV1(GroupRes res);

	GroupCreateReq fromCreateRequestV1(GroupCreateRequestV1 createRequestV1);

}
