package com.abacogroup.cllapi.resources;

import com.abacogroup.cllapi.api.BlockRes;
import com.abacogroup.cllapi.api.SectorRes;
import com.abacogroup.cllapi.core.LpisClientService;
import com.abacogroup.cllapi.resources.mapper.BlockMapper;
import com.abacogroup.cllapi.resources.mapper.SectorMapper;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.common.resources.ResourceConstants;
import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import java.util.stream.Collectors;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PRIV + "/sectors")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Sectors", description = "Operations on sectors")
public class SectorResource {

	private final LpisClientService lpisClientService;

	public SectorResource(LpisClientService lpisClientService) {
		this.lpisClientService = lpisClientService;
	}

	@GET
	@Path("")
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Operation(description = "Get the list of sectors ")
	@ApiResponse(responseCode = "200", description = "Get the list of sectors", useReturnTypeSchema = true)
	public List<SectorRes> getSectors(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "filter") @QueryParam("filter") String filter,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId) {

		return lpisClientService.getSectors(new ReqContext(user, lang), filter)
				.stream().map(SectorMapper.INSTANCE::toSectorRes)
				.collect(Collectors.toList());
	}	
	
	@GET
	@Path("/{sector_code}/blocks")
	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Operation(description = "Get the list of sectors ")
	@ApiResponse(responseCode = "200", description = "Get the list of blocks", useReturnTypeSchema = true)
	public List<BlockRes> getBlocks(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
		@Parameter(description = "sector code") @PathParam("sector_code") String sectorCode,
			@Parameter(description = "filter") @QueryParam("filter") String filter){

		return lpisClientService.getBlocks(new ReqContext(user, lang), sectorCode, filter).getBlocksList()
				.stream().map(BlockMapper.INSTANCE::toBlockRes)
				.collect(Collectors.toList());
	}
}
