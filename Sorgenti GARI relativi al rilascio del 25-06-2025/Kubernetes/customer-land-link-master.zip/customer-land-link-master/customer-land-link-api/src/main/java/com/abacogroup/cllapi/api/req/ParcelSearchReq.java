package com.abacogroup.cllapi.api.req;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import jakarta.validation.constraints.NotEmpty;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Data
@NoArgsConstructor
@Accessors(chain = true)

public class ParcelSearchReq {

	@Parameter(in = ParameterIn.QUERY, description = "cuaa")
	@Deprecated(forRemoval = true)
	@QueryParam("partyCode")
	private String partyCode;
	
	@Parameter(in = ParameterIn.QUERY, description = "target party id")
	@Deprecated(forRemoval = true)
	@QueryParam("targetPartyId")
	private Long targetPartyId;

	/**
	 * il comune
	 */
	@Parameter(in = ParameterIn.QUERY, description = "sector code, comune")
	@QueryParam("sectorCode")
	private String sectorCode;

	@Parameter(in = ParameterIn.QUERY, description = "block code, foglio")
	@QueryParam("blockCode")
	private String blockCode;

	@Parameter(in = ParameterIn.QUERY, description = "parcel , codice particella")
	@QueryParam("parcelCode")
	private String parcelCode;

	@Parameter(in = ParameterIn.QUERY, description = "subalterno , codice subalterno")
	@QueryParam("subParcelCode")
	private String subParcelCode;

	@Parameter(in = ParameterIn.QUERY, description = "dayFrom , data apertura gruppo")
	@QueryParam("dayFrom")
	@NotEmpty
	private String dayFrom;
	
	
	private List<String> sectorCodeList;

	@Deprecated
	@Parameter(in = ParameterIn.QUERY, description = "subalterno , codice subalterno", deprecated = true)
	@QueryParam("subParcel")
	public ParcelSearchReq setSubParcel(String subParcelCode) {
		if (StringUtils.isNotBlank(subParcelCode)) {
			this.subParcelCode = subParcelCode;
		}
		return this;
	}

	@Deprecated
	@Parameter(in = ParameterIn.QUERY, description = "cuaa", deprecated = true)
	@QueryParam("cuaa")
	public ParcelSearchReq setCuaa(String cuaa) {
		if (StringUtils.isNotBlank(cuaa)) {
			this.partyCode = cuaa;
		}
		return this;
	}
}
