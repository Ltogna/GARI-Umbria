package com.abacogroup.cllapi.api;

import org.jdbi.v3.core.mapper.reflect.ColumnName;

import com.abacogroup.cllcli.api.v1.enums.ParcelSearchLevel;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class CllSettings {
	
	public String lpisSubSeparator;

	@ColumnName("fl_allow_editdayto_parcelinthepast")
	private Boolean allowEditDayToParcelInThePast;
	
	@Builder.Default()
	private ParcelSearchLevel parcelSearchLevel = ParcelSearchLevel.ADD_TEMP_PARCELS_IF_NOT_EXISTS;
	
	
}
