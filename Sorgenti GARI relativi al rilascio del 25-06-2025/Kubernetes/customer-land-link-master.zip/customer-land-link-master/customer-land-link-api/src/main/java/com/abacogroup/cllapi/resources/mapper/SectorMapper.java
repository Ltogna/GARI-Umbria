package com.abacogroup.cllapi.resources.mapper;

import com.abacogroup.cllapi.api.SectorRes;
import com.abacogroup.lpisgisserver.api.v1.PublicParcelSector;
import com.abacogroup.lpisgisserver.api.v1.PublicSector;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface SectorMapper {

	SectorMapper INSTANCE = Mappers.getMapper(SectorMapper.class);

	SectorRes toSectorRes(PublicSector sector);
	SectorRes toSectorRes(PublicParcelSector sector);

}
