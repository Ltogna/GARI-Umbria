package com.abacogroup.cllapi.core.impl;

import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.GROUP_CLL_ENTITY_CODE;
import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.PARCEL_ENTITY_CODE;
import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.PARTY_PARCEL_ENTITY_CODE;
import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.partyParcelEntityId;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalyTypeSearchRequest;
import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyTypeClient;
import com.abacogroup.cllapi.api.AnomalySearchRes;
import com.abacogroup.cllapi.api.req.AnomalySearchReq;
import com.abacogroup.cllapi.core.AnomalyService;
import com.abacogroup.cllapi.core.dto.AnomalyDto;
import com.abacogroup.cllapi.core.dto.AnomalyMaxLevelDto;
import com.abacogroup.cllapi.core.dto.LandLink;
import com.abacogroup.cllapi.db.dao.AnomaliesDAO;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import java.time.Clock;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AnomalyServiceImpl implements AnomalyService {

	private final AnomaliesDAO anomaliesDAO;
	private final AnomalyTypeClient anomalyTypeClient;
	private final Clock appClock;

	private final Cache<String, String> anomalyDescriptionCache;

	public AnomalyServiceImpl(AnomaliesDAO anomaliesDAO, AnomalyTypeClient anomalyTypeClient, Clock appClock) {
		this.anomaliesDAO = anomaliesDAO;
		this.anomalyTypeClient = anomalyTypeClient;
		this.appClock = appClock;

		this.anomalyDescriptionCache = Caffeine.newBuilder()
				.maximumSize(1000)
				.expireAfterWrite(Duration.ofDays(1))
				.build();
	}

	public void resetCache() {
		anomalyDescriptionCache.cleanUp();
	}

	@Override
	public Map<Long, AnomalyMaxLevelDto> getLandLinksAnomalies(ReqContext context, AbsoluteDate refDate, Collection<? extends LandLink> landLinks) {

		Set<String> groupRefs = landLinks.stream()
				.map(LandLink::getGroupId).filter(Objects::nonNull).map(Object::toString)
				.collect(Collectors.toSet());
		Map<String, List<AnomalyDto>> groupAnomalies = this.getGroupedByEntityIdIn(context, GROUP_CLL_ENTITY_CODE, groupRefs, refDate);

		Set<String> parcelRefs = landLinks.stream()
				.map(LandLink::getParcelId).filter(Objects::nonNull).map(Object::toString)
				.collect(Collectors.toSet());
		Map<String, List<AnomalyDto>> parcelAnomalies = this.getGroupedByEntityIdIn(context, PARCEL_ENTITY_CODE, parcelRefs, refDate);

		Set<String> partyParcelRefs = landLinks.stream()
				.map(ll -> partyParcelEntityId(ll.getPartyId(), ll.getParcelId())).filter(Objects::nonNull)
				.collect(Collectors.toSet());
		Map<String, List<AnomalyDto>> partyParcelAnomalies = this.getGroupedByEntityIdIn(context, PARTY_PARCEL_ENTITY_CODE, partyParcelRefs, refDate);

		Map<Long, AnomalyMaxLevelDto> result = new HashMap<>();
		for (LandLink landLink : landLinks) {
			List<AnomalyDto> llAnomalies = Stream.of(
							Optional.ofNullable(landLink.getGroupId())
									.map(Object::toString)
									.map(groupAnomalies::get)
									.orElse(new ArrayList<>()),
							Optional.ofNullable(landLink.getParcelId())
									.map(Objects::toString)
									.map(parcelAnomalies::get)
									.orElse(new ArrayList<>()),
							Optional.ofNullable(partyParcelEntityId(landLink.getPartyId(), landLink.getParcelId()))
									.map(partyParcelAnomalies::get)
									.orElse(new ArrayList<>())
					).flatMap(Collection::stream)
					.sorted(Comparator.comparing(a -> ((AnomalyDto) a).getLevel().ordinal())
							.thenComparing(a -> ((AnomalyDto) a).getAnomaly().getEntityCode())
							.thenComparing(a -> ((AnomalyDto) a).getAnomaly().getType().getCode()))
					.collect(Collectors.toList());

			result.put(landLink.getId(), new AnomalyMaxLevelDto(llAnomalies));
		}

		return result;
	}

	@Override
	public List<AnomalySearchRes> search(ReqContext context, String entityCode, AnomalySearchReq searchRequest, AbsoluteDate referenceDate) {
		Criteria criteria = searchRequest.getCriteria(context);
		OrderByElement sort = searchRequest.getSort();
		AbsoluteDate today = AbsoluteDate.of(LocalDateTime.now(appClock));
		return anomaliesDAO.search(context, Optional.ofNullable(referenceDate).orElse(today).getValue(), entityCode, criteria, sort);
	}

	private Map<String, List<AnomalyDto>> getGroupedByEntityIdIn(ReqContext context, String entityCode, Collection<String> entityIds, AbsoluteDate refDate) {
		if (entityIds.isEmpty()) {
			return new HashMap<>();
		}

		return search(context, entityCode, new AnomalySearchReq().setEntityId(new ArrayList<>(entityIds)),
				refDate)
				.stream()
				.map(res -> mapToAnomalyDto(context, res))
				.filter(dto -> null != dto.getLevel())
				.collect(Collectors.groupingBy(dto -> dto.getAnomaly().getEntityId()));
	}

	private AnomalyDto mapToAnomalyDto(ReqContext context, AnomalySearchRes res) {
		AnomalySearchResponse anomaly = this.mapToAnomalySearchResponse(context, res);
		return new AnomalyDto().setAnomaly(anomaly).setLevel(res.getLevel());
	}
	
	private AnomalySearchResponse mapToAnomalySearchResponse(ReqContext context, AnomalySearchRes res) {
		// fetch i18n of anomaly typeCode
		String i18nCode = this.getCachedAnomalyDescription(context, res.getTypeGroupCode(), res.getTypeCode());

		return AnomalySearchResponse.builder()
				.setId(res.getId())
				.setType(AnomalyTypeResponse.builder()
						.setCode(res.getTypeCode())
						.setGroupCode(res.getTypeGroupCode())
						.setI18nCode(i18nCode)
						.build())
				.setEntityId(res.getEntityId())
				.setEntityCode(res.getEntityCode())
				.build();
	}

	private String getCachedAnomalyDescription(ReqContext context, String group, String code) {
		String key = String.format("%s-%s-%s", context.getLang(), group, code);
		return anomalyDescriptionCache.asMap().computeIfAbsent(key, k -> getAnomalyDescription(context, group, code));
	}

	private String getAnomalyDescription(ReqContext context, String group, String code) {
		AnomalyTypeSearchRequest anmTypeSearchRequest = new AnomalyTypeSearchRequest().setCode(code);
		List<AnomalyTypeResponse> anomalyType = searchAnomalyTypes(context, anmTypeSearchRequest);
		return Optional.of(anomalyType)
				.stream().flatMap(Collection::stream)
				.filter(t -> t.getGroupCode().equalsIgnoreCase(group))
				.findFirst()
				.or(() -> Optional.of(anomalyType)
						.filter(l -> !l.isEmpty())
						.map(l -> l.get(0)))
				.map(AnomalyTypeResponse::getI18nCode)
				.orElse(null);
	}

	private List<AnomalyTypeResponse> searchAnomalyTypes(ReqContext context, AnomalyTypeSearchRequest anomalyTypeSearchRequest) {
		try {
			return this.anomalyTypeClient.searchAll(
					context.getLang(),
					context.getUser(),
					anomalyTypeSearchRequest);
		} catch (Exception e) {
			log.error("cannot search anomalies types {} ", e.getMessage());
		}
		return new ArrayList<>();
	}
}
