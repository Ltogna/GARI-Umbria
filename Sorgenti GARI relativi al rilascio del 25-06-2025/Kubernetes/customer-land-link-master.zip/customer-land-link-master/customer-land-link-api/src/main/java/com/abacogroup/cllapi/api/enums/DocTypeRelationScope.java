package com.abacogroup.cllapi.api.enums;

public enum DocTypeRelationScope {
	GROUPS, 
	LANDLINKS
}
