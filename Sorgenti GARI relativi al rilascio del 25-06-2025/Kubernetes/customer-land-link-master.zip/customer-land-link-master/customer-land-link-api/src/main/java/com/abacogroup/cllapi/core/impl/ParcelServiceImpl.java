package com.abacogroup.cllapi.core.impl;

import java.time.Clock;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.cllapi.api.LandLinkLeadingRes;
import com.abacogroup.cllapi.api.LandLinkLeadingResWithHolder;
import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.api.ParcelSearchRes;
import com.abacogroup.cllapi.api.req.LandLinkSearchReq;
import com.abacogroup.cllapi.api.req.ParcelSearchReq;
import com.abacogroup.cllapi.core.LandLinkService;
import com.abacogroup.cllapi.core.LpisClientService;
import com.abacogroup.cllapi.core.ParcelService;
import com.abacogroup.cllapi.core.PartiesAclClientService;
import com.abacogroup.cllapi.core.PartyClientService;
import com.abacogroup.cllapi.db.dao.CllSettingsDAO;
import com.abacogroup.cllapi.resources.mapper.LandLinkLeadingResMapper;
import com.abacogroup.cllapi.resources.mapper.ParcelMapper;
import com.abacogroup.cllcli.api.v1.enums.ParcelSearchLevel;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lpisgisserver.api.v1.PublicParcel;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ParcelServiceImpl implements ParcelService {

    private final LpisClientService lpisClientService;
    private final LandLinkService landLinkService;
    private final PartyClientService partyClientService;
    private final PartiesAclClientService partiesAclClientService;
    private final CllSettingsDAO cllSettingsDAO;
    private final Clock appClock;
    
    private static final AbsoluteDate MIN_DATE = AbsoluteDate.of("19700101");
    private static final AbsoluteDate MAX_DATE = AbsoluteDate.of("99991231");

    public ParcelServiceImpl(LpisClientService lpisClientService, LandLinkService landLinkService, PartyClientService partyClientService,
                             PartiesAclClientService partyaAclClientService, CllSettingsDAO cllSettingsDAO, Clock appClock) {
        this.lpisClientService = lpisClientService;
        this.landLinkService = landLinkService;
        this.partyClientService = partyClientService;
        this.partiesAclClientService = partyaAclClientService;
        this.cllSettingsDAO = cllSettingsDAO;
        this.appClock = appClock;

    }

    @Override
    public InfiniteListResults<ParcelSearchRes> search(ReqContext context, Long partyId, ParcelSearchReq searchReq,
                                                       Boolean includeGeometries, Boolean includeLandCovers, Boolean includeLpisData,
                                                       ParcelSearchLevel parcelSearchLevel, String nextKey, Integer pageSize) {
        AbsoluteDate referenceDate = Optional.ofNullable(searchReq.getDayFrom()).map(AbsoluteDate::of)
                .orElseGet(() -> AbsoluteDate.of(LocalDate.now(appClock)));

        if (StringUtils.isNotBlank(searchReq.getPartyCode()) || searchReq.getTargetPartyId() != null) {
            //TODO DUBBIO REF DATE per lpis alla data corrente in creazione e lpis alla data della CLL per la visualizzazione delle cll
            return doSearchCll(context, partyId, searchReq, nextKey, referenceDate, includeLpisData, pageSize);
        } else {
            return doSearchLpis(context, partyId, searchReq, nextKey, AbsoluteDate.of(LocalDate.now(appClock)), 
            		includeGeometries, includeLandCovers, pageSize, parcelSearchLevel);
        }
    }

    @Override
    public List<ParcelSearchRes> searchByGroup(ReqContext context, Long partyId, Long groupId, ParcelSearchReq searchReq) {
        AbsoluteDate referenceDate = Optional.ofNullable(searchReq.getDayFrom()).map(AbsoluteDate::of)
                .orElseGet(() -> AbsoluteDate.of(LocalDate.now(appClock)));

        return doSearchCllByGroupId(context, partyId, groupId, searchReq, referenceDate);

    }

    private InfiniteListResults<ParcelSearchRes> doSearchCll(ReqContext context, Long partyId, ParcelSearchReq searchReq,
                                                             String nextKey, AbsoluteDate refDate, Boolean includeLpisData, Integer pageSize) {
        String code = searchReq.getPartyCode();
        Long targetPartyId = searchReq.getTargetPartyId();
        if (targetPartyId == null) {
            targetPartyId = partyClientService.getByCode(context, code)
                    .map(PartyResponseV1::getId)
                    .orElse(null);

            if (targetPartyId == null) {
                return new InfiniteListResultsImpl<>(new ArrayList<>(), null);
            }
        }

        LandLinkSearchReq landLinkSearchReq = new LandLinkSearchReq()
                .setParcelCode(searchReq.getParcelCode())
                .setSubParcelCode(searchReq.getSubParcelCode())
                .setBlockCode(searchReq.getBlockCode())
                .setSectorCode(searchReq.getSectorCode())
                .setSectorCodeList(searchReq.getSectorCodeList())
                .setPartyId(targetPartyId);

        InfiniteListResults<LandLinkRes> landLinkDetails = landLinkService.search(context, refDate, landLinkSearchReq, includeLpisData, nextKey, pageSize);
        return landLinkDetails.map(ll -> new ParcelSearchRes(ll.getParcel(),
                partyId, getConduttori(context, ll.getParcel().getId(), AbsoluteDate.of(searchReq.getDayFrom()), AbsoluteDate.of(AuditEntity.dateActive))));
    }

    private List<ParcelSearchRes> doSearchCllByGroupId(ReqContext context, Long partyId, Long groupId, ParcelSearchReq searchReq, AbsoluteDate refDate) {


        LandLinkSearchReq landLinkSearchReq = new LandLinkSearchReq()
                .setGroupId(groupId)
                .setParcelCode(searchReq.getParcelCode())
                .setSubParcelCode(searchReq.getSubParcelCode())
                .setBlockCode(searchReq.getBlockCode())
                .setSectorCode(searchReq.getSectorCode())
                .setPartyId(partyId);

        List<LandLinkRes> landLinkDetails = landLinkService.search(context, refDate, landLinkSearchReq);
        return landLinkDetails.stream().map(ll -> {
                    return new ParcelSearchRes(ll.getParcel(), partyId,
                            getConduttori(context, ll.getParcel().getId(),
                                    AbsoluteDate.of(searchReq.getDayFrom()),
                                    AbsoluteDate.of(AuditEntity.dateActive)));
                }
        ).collect(Collectors.toList());
    }

    private InfiniteListResults<ParcelSearchRes> doSearchLpis(ReqContext context, Long partyId, ParcelSearchReq searchReq,
                                                              String nextKey, AbsoluteDate referenceDate, Boolean includeGeometries,
                                                              Boolean includeLandCovers, Integer pageSize, ParcelSearchLevel parcelSearchLevel) {
        String actualParcelCodeFilter = searchReq.getParcelCode();
        if (StringUtils.isNotBlank(searchReq.getSubParcelCode())) {
            var settings = cllSettingsDAO.getOne(context.getTenantId());
            actualParcelCodeFilter = String.format("%s%s%s", actualParcelCodeFilter, settings.getLpisSubSeparator(), searchReq.getSubParcelCode());
        }

        InfiniteListResults<PublicParcel> parcels = lpisClientService.searchParcels(context,
                referenceDate,
                searchReq.getSectorCode(),
                searchReq.getBlockCode(),
                actualParcelCodeFilter,
                includeGeometries,
                includeLandCovers,
                parcelSearchLevel,
                nextKey,
                pageSize);
        return parcels.map(publicParcel -> new ParcelSearchRes(ParcelMapper.INSTANCE.toParcelRes(publicParcel),
                partyId, getConduttori(context, publicParcel.getId(), AbsoluteDate.of(searchReq.getDayFrom()), AbsoluteDate.of(AuditEntity.dateActive))));
    }

    private List<LandLinkLeadingRes> getConduttori(ReqContext context, Long parcelId, AbsoluteDate dayFrom, AbsoluteDate dayTo) {
        // Elenco dei CUAA conduttori dell’azienda in un periodo che si interseca con quello di conduzione del Gruppo di Conduzione selezionato.
        List<LandLinkLeadingRes> landLinks = landLinkService
                .searchByParcelIdAndRange(context, parcelId, dayFrom,
                        dayTo);

        if (landLinks.isEmpty()) {
            return new ArrayList<>();
        }
        List<Long> partiesId = landLinks.stream().map(l -> l.getPartyId()).distinct().collect(Collectors.toList());

        Map<Long, PartyResponseV1> partiesMap = partyClientService.getByIds(context, partiesId).stream()
                .collect(Collectors.toMap(PartyResponseV1::getId,
                        Function.identity()));

        return landLinks.stream()
                .map(ll -> {

                    ll.setParty(partiesMap.getOrDefault(ll.getPartyId(), PartyClientServiceImpl.partyClientFallback(ll.getPartyId())));
                    return ll;
                })
                .collect(Collectors.toList());
    }

    @Override
    public List<LandLinkLeadingRes> getParcelLeadingList(ReqContext context, Long parcelId, AbsoluteDate referenceDate) {
        return getConduttori(context, parcelId, referenceDate, referenceDate);

    }

	@Override
	public List<LandLinkLeadingResWithHolder> getParcelLeadingHistory(ReqContext context, Long parcelId, Boolean loadMandatesHolders) {
		List<LandLinkLeadingRes> response = getConduttori(context, parcelId, MIN_DATE, MAX_DATE);
		
		if(loadMandatesHolders) {
			return response.stream()
					.map(LandLinkLeadingResMapper.INSTANCE::toLandLinkLeadindResWithHolder)
	                .map(ll -> { // For a 
	                	ll.setMandateHolder(partiesAclClientService.getHolderByPartyId(context, ll.getPartyId(), ll.getDayFrom(), ll.getDayTo()));
	                    return ll;
	                })
	                .collect(Collectors.toList());
		}
		
		return response.stream()
				.map(LandLinkLeadingResMapper.INSTANCE::toLandLinkLeadindResWithHolder)
                .collect(Collectors.toList());
		
	}
}
