package com.abacogroup.cllapi.db.dao;

import com.abacogroup.cllapi.api.AnomalySearchRes;
import com.abacogroup.cllapi.db.ntt.AnomalyEntity;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface AnomaliesDAO extends Transactional<AnomaliesDAO>, EnhancedSqlObject {

	@SqlQuery("SELECT * FROM cll_anomalies " +
			" where entity_id = :entityId and entity_code = :entityCode " +
			" and type_code = :typeCode and type_group_code = :typeGroupCode " +
			" and tenant_id = :tenantId and valid_from = :validFrom " +
			" and (§current_timestamp§ between dt_insert and dt_delete) ")
	@RegisterBeanMapper(AnomalyEntity.class)
	Optional<AnomalyEntity> findByAnomalyTypeAndEntityAndValidFrom(@BindBean AnomalyEntity entity);

	@SqlQuery("SELECT * FROM cll_anomalies " +
			" where entity_id = :entityId and entity_code = :entityCode " +
			" and type_code = :typeCode and type_group_code = :typeGroupCode " +
			" and tenant_id = :tenantId " +
			" and (§current_timestamp§ between dt_insert and dt_delete) ")
	@RegisterBeanMapper(AnomalyEntity.class)
	List<AnomalyEntity> findByAnomalyTypeAndEntity(@BindBean AnomalyEntity entity);

	@SqlQuery("SELECT count(*) FROM cll_anomalies " +
			" where entity_id = :entityId and entity_code = :entityCode " +
			" and type_code = :typeCode and type_group_code = :typeGroupCode " +
			" and tenant_id = :tenantId " +
			" and (§current_timestamp§ between dt_insert and dt_delete) ")
	Long countByAnomalyTypeAndEntity(@BindBean AnomalyEntity entity);

	@SqlQuery("SELECT count(*) FROM cll_anomalies " +
			" where entity_id in (<entityIds>) and entity_code = :entityCode " +
			" and type_code = :typeCode and type_group_code = :typeGroupCode " +
			" and tenant_id = :tenantId " +
			" and (:referenceDate between valid_from and valid_to) " +
			" and (§current_timestamp§ between dt_insert and dt_delete) ")
	Long countByAnomalyTypeAndEntityIn(
			@Bind("tenantId") String tenantId,
			@Bind("referenceDate") String referenceDate,
			@Bind("typeGroupCode") String typeGroupCode,
			@Bind("typeCode") String typeCode,
			@Bind("entityCode") String entityCode,
			@BindList("entityIds") Collection<String> entityIds);

	@SqlQuery("SELECT count(*) FROM cll_anomalies " +
			" where entity_id in (<entityIds>) and entity_code = :entityCode " +
			" and type_code = :typeCode and type_group_code = :typeGroupCode " +
			" and tenant_id = :tenantId " +
			" and (§current_timestamp§ between dt_insert and dt_delete) ")
	Long countByAnomalyTypeAndEntityIn(
			@Bind("tenantId") String tenantId,
			@Bind("typeGroupCode") String typeGroupCode,
			@Bind("typeCode") String typeCode,
			@Bind("entityCode") String entityCode,
			@BindList("entityIds") Collection<String> entityIds);

	@SqlUpdate("INSERT INTO cll_anomalies " +
			"(tenant_id, type_group_code, type_code, entity_code, entity_id, valid_from, valid_to, dt_insert, user_id_insert, dt_delete, user_id_delete) " +
			"VALUES (:tenantId, :typeGroupCode, :typeCode, :entityCode, :entityId, :validFrom, :validTo, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	@GetGeneratedKeys("id")
	Long insert(@BindBean AnomalyEntity anomaly);

	@SqlUpdate("update cll_anomalies set dt_delete =:dtDelete, user_id_delete=:userIdDelete " +
			" where id = :id and tenant_id = :tenantId " +
			" and (§current_timestamp§ between dt_insert and dt_delete) ")
	void expireRow(@BindBean AnomalyEntity entity);

	@SqlQuery(" SELECT id , type_group_code, type_code , entity_code , entity_id , \"level\" "
			+ " FROM cll_anomalies an "
			+ " left join cll_anomaly_categories ac on an.type_group_code=ac.group_code AND an.type_code=ac.code AND ac.fl_exclude=0 AND ac.tenant_id = :tenantId "
			+ " WHERE an.tenant_id = :tenantId AND (§current_timestamp§ between an.dt_insert and an.dt_delete) "
			+ " and an.entity_code= UPPER(:entityCode) "
			+ " and (:referenceDate between an.valid_from and an.valid_to) "
			+ " and <criteria> "
			+ " ORDER BY <orderBy> ")
	@RegisterBeanMapper(AnomalySearchRes.class)
	List<AnomalySearchRes> search(
			@BindBean ReqContext ctx,
			@Bind("referenceDate") String referenceDate,
			@Bind("entityCode") String entityCode,
			@BindCriteria Criteria criteria,
			@DefineOrder OrderBy orderBy);

}
