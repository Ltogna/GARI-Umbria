package com.abacogroup.cllapi.core.dto;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.cllcli.api.v1.AnomalyLevelEnum;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@Accessors(chain = true)
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class AnomalyDto {

	private AnomalySearchResponse anomaly;
	private AnomalyLevelEnum level;

}
