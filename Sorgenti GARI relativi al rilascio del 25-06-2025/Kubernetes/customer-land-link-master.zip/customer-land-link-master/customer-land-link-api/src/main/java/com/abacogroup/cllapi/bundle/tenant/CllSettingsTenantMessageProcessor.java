package com.abacogroup.cllapi.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.cllapi.bundle.BundleConstants;
import com.abacogroup.cllapi.db.dao.CllSettingsDAO;
import com.abacogroup.cllapi.db.ntt.CllSettingsEntity;
import com.abacogroup.common.service.AuditHelper;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CllSettingsTenantMessageProcessor implements TenantMessageProcessor {

	private final CllSettingsDAO cllSettingsDAO;

	public CllSettingsTenantMessageProcessor(CllSettingsDAO cllSettingsDAO) {
		this.cllSettingsDAO = cllSettingsDAO;
	}

	@Override
	public void onMessage(TenantMessage tenantMessage) {
		String tenantId = tenantMessage.getTenantId();
		if (cllSettingsDAO.countAll(tenantId) > 0L) {
			log.warn("settings already present for tenant {}", tenantId);
		} else {
			CllSettingsEntity auditType = new CllSettingsEntity();
			AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, cllSettingsDAO, auditType);
			cllSettingsDAO.insertNewTenant(ALL_TENANTS, tenantId, auditType);
			log.info("cll settings successfully inserted for tenant {}", tenantId);
		}
	}
}
