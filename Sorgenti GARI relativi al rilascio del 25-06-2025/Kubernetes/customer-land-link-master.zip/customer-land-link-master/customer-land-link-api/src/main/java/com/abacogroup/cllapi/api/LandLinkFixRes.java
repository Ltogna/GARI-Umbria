package com.abacogroup.cllapi.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LandLinkFixRes {

	private Long propLandLinkId;
	private Long landLinkId;
}
