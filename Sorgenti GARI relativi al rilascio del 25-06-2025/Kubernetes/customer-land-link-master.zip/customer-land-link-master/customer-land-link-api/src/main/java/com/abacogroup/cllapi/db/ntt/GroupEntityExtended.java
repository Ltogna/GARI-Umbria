package com.abacogroup.cllapi.db.ntt;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class GroupEntityExtended extends GroupEntity implements AuditEntity {

	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;

	private Long linkCount;

}
