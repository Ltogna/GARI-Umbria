package com.abacogroup.cllapi.core.embededqueue;

import com.abacogroup.cllapi.core.dto.CllEventType;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import java.util.List;

public interface EventPublisher {
	void pushGroupEvent(List<Long> groupIds, AbsoluteDate fromDate, Long partyId, String tenantId, String username, String lang, CllEventType eventType);

	void pushLandLinkEvent(List<Long> landLinkIds, AbsoluteDate fromDate, Long partyId, String tenantId, String username, String lang, CllEventType eventType);
}
