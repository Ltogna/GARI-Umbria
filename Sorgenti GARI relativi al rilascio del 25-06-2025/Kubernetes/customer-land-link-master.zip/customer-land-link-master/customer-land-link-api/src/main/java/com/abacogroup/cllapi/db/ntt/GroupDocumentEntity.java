package com.abacogroup.cllapi.db.ntt;

import com.abacogroup.jdbi.model.AuditEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class GroupDocumentEntity implements AuditEntity {

	private Long pkid;
	private Long groupId;
	private String definitionCode;
	private Long documentId;

	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;

}
