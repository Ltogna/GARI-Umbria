package com.abacogroup.cllapi.core.embededqueue;

import static com.abacogroup.embeddedqueue.QueueErrorListener.ErrorAction.MARK_AS_ERRORED;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

import com.abacogroup.cllapi.api.req.LandLinkBatchCreateReq;
import com.abacogroup.cllapi.api.req.LandLinkBatchFixReq;
import com.abacogroup.cllapi.core.GroupService;
import com.abacogroup.cllapi.core.LandLinkService;
import com.abacogroup.cllapi.db.ntt.GroupEntity;
import com.abacogroup.cllapi.db.ntt.LandLinkEntity;
import com.abacogroup.cllapi.exceptions.GroupException;
import com.abacogroup.cllapi.exceptions.InvalidPayloadException;
import com.abacogroup.cllapi.exceptions.InvalidPayloadException.ErrEnum;
import com.abacogroup.cllapi.exceptions.LandLinkException;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.Repository;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.codahale.metrics.MetricRegistry;

import jakarta.ws.rs.core.SecurityContext;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LandLinkBatchFixQueue extends WorkQueue<LandLinkBatchFixReq> {

	private static final String QUEUE_ID = "ll-batch-fix-queue";
	private static final long Q_TIMEOUT_MS = 1000L * 60 * 10;
	private static int Q_THREADS = 1;
	
	private final Sso2Client sso2Client;
	private final GroupService groupService;
	private final LandLinkService landLinkService;
	
	private static final String LANG = "en";
	
	public LandLinkBatchFixQueue(Repository repo, MetricRegistry registry, GroupService groupService, LandLinkService landLinkService,
			Sso2Client sso2Client) {
		super(QUEUE_ID, repo, Q_THREADS, Q_TIMEOUT_MS);
		this.groupService = groupService;
		this.landLinkService = landLinkService;
		this.sso2Client = sso2Client;
		this.setMetricRegistry(registry);
		
		ThrowingConsumer<LandLinkBatchFixReq> consumer = createConsumer();
		this.setConsumer(consumer);
		
		QueueErrorListener<LandLinkBatchFixReq> errorListener = createErrorListener();
		this.setErrorListener(errorListener);
		
		this.start();		
	}
	
	private ThrowingConsumer<LandLinkBatchFixReq> createConsumer() {
		return req -> {
			log.info("start processing LandLinkBatchFixJob");
			this.accept(req);
		};
	}
	

	public void add(ReqContext reqContext, Long rentLinkId, Long propertyLinkId, AbsoluteDate referenceDate) {
		LandLinkBatchFixReq payload = LandLinkBatchFixReq.builder()
				.tenantId(reqContext.getUser().getTenant())
				.username(reqContext.getUsername())
				.rentLinkId(rentLinkId)
				.propertyLinkId(propertyLinkId)
				.referenceDate(referenceDate)
				.build();
		
		add(payload, System.currentTimeMillis());
	}

	private QueueErrorListener<LandLinkBatchFixReq> createErrorListener() {
		return (job, exp) -> MARK_AS_ERRORED;
	}

	public void accept(LandLinkBatchFixReq payload) throws Exception {
		SecurityContext securityContext = sso2Client.createSecurityContextFromUserName(payload.getTenantId(), payload.getUsername());
		User user = (User) securityContext.getUserPrincipal();
		
		ReqContext reqContext = new ReqContext(user, LANG);
		sso2Client.ensureLongLivingAuthToken(reqContext.getUser());
		
		log.info("received propLandLinkId: {} and rentLandLinkId: {}", payload.getPropertyLinkId(), payload.getRentLinkId());
		LandLinkEntity landLinkRent = landLinkService.loadEntity(reqContext.getTenantId(), payload.getRentLinkId(), payload.getReferenceDate())
				.orElseThrow(() -> new LandLinkException(LandLinkException.ErrEnum.NOT_FOUND,
                        String.format("link %s not found or closed in tenant %s ", payload.getRentLinkId(), reqContext.getTenantId())));
		
		
		LandLinkEntity landLinkProp = landLinkService.loadEntity(reqContext.getTenantId(), payload.getPropertyLinkId(), payload.getReferenceDate())
				.orElseThrow(() -> new LandLinkException(LandLinkException.ErrEnum.NOT_FOUND,
						String.format("link %s not found or closed in tenant %s ", payload.getPropertyLinkId(), reqContext.getTenantId())));
		
		if(!Objects.equals(landLinkProp.getParcelId(), landLinkRent.getParcelId())) {
			throw new InvalidPayloadException(ErrEnum.INVALID_PAYLOAD, "Property parcel and Rent parcel are not same!!");
		}
		
		GroupEntity groupProp = groupService.loadById(reqContext, landLinkProp.getGroupId())
				.orElseThrow(() -> new GroupException(GroupException.ErrEnum.NOT_FOUND, String.format("group %s not found", landLinkProp.getGroupId())));
		
		landLinkService.expire(reqContext, landLinkProp.getPartyId(), landLinkProp.getId());
		
		LandLinkBatchCreateReq oldLandLink = LandLinkBatchCreateReq.builder()
				.setParcelId(landLinkProp.getParcelId())
				.setTitleTypePerc(landLinkProp.getTitleTypePerc())
				.build();
		
		
		BigDecimal newPerc = landLinkProp.getTitleTypePerc().subtract(landLinkRent.getTitleTypePerc());
		if(newPerc.compareTo(BigDecimal.ZERO) < 0) {
			newPerc = BigDecimal.ZERO;
		}
		LandLinkBatchCreateReq newLandLink = LandLinkBatchCreateReq.builder()
				.setParcelId(landLinkProp.getParcelId())
				.setTitleTypePerc(newPerc)
				.build();
		
		
		//insert before Rent interval
		DatesFromTo beforeRentInterval = getBeforeRentInterval(new DatesFromTo(landLinkRent.getDayFrom(), landLinkRent.getDayTo()), new DatesFromTo(landLinkProp.getDayFrom(), landLinkProp.getDayTo()));
		if(beforeRentInterval != null) {
			landLinkService.insertInternal(reqContext, groupProp, beforeRentInterval.getFrom(), beforeRentInterval.getTo(), List.of(oldLandLink));
		}
		
		//insert current Rent interval
		DatesFromTo currentRentInterval = getCurrentRentInterval(new DatesFromTo(landLinkRent.getDayFrom(), landLinkRent.getDayTo()), new DatesFromTo(landLinkProp.getDayFrom(), landLinkProp.getDayTo()));
		DatesFromTo afterRentInterval = getAfterRentInterval(new DatesFromTo(landLinkRent.getDayFrom(), landLinkRent.getDayTo()), new DatesFromTo(landLinkProp.getDayFrom(), landLinkProp.getDayTo()));
		if(currentRentInterval != null) {
//	secondo Fabio il current deve andare fino al 99991231... landLinkService.insertInternal(reqContext, groupProp, currentRentInterval.getFrom(), currentRentInterval.getTo(), List.of(newLandLink));
			landLinkService.insertInternal(reqContext, groupProp, currentRentInterval.getFrom(), afterRentInterval.getTo(), List.of(newLandLink));
		}
		
//		//insert After Rent interval Quindi, sempre secondo Fabio, questo non serve
//		if(afterRentInterval != null) {
//			landLinkService.insertInternal(reqContext, groupProp, afterRentInterval.getFrom(), afterRentInterval.getTo(), List.of(oldLandLink));
//		}
		
	}

    private DatesFromTo getBeforeRentInterval(DatesFromTo rentDates, DatesFromTo propDates) {
        if (propDates.getFrom().toLocalDate().isBefore(rentDates.getFrom().toLocalDate())) {
            LocalDate beforeRentEnd = rentDates.getFrom().toLocalDate().minusDays(1);
            AbsoluteDate beforeRentStart = propDates.getFrom();
            if (beforeRentEnd.isBefore(beforeRentStart.toLocalDate())) {
                return null; // No interval before rent
            }
            return new DatesFromTo(beforeRentStart, AbsoluteDate.of(beforeRentEnd));
        }
        return null;
    }

    private DatesFromTo getCurrentRentInterval(DatesFromTo rentDates, DatesFromTo propDates) {
        AbsoluteDate rentStart = propDates.getFrom().toLocalDate().isBefore(rentDates.getFrom().toLocalDate()) ? rentDates.getFrom() : propDates.getFrom();
        AbsoluteDate rentEnd = propDates.getTo().toLocalDate().isAfter(rentDates.getTo().toLocalDate()) ? rentDates.getTo() : propDates.getTo();
        
        if (rentStart.toLocalDate().isAfter(rentEnd.toLocalDate())) {
            return null; // No overlap between prop and rent periods
        }
        return new DatesFromTo(rentStart, rentEnd);
    }

    private DatesFromTo getAfterRentInterval(DatesFromTo rentDates, DatesFromTo propDates) {
        if (propDates.getTo().toLocalDate().isAfter(rentDates.getTo().toLocalDate())) {
            LocalDate afterRentStart = rentDates.getTo().toLocalDate().plusDays(1);
            AbsoluteDate afterRentEnd = propDates.getTo();
            if (afterRentStart.isAfter(afterRentEnd.toLocalDate())) {
                return null; // No interval after rent
            }
            return new DatesFromTo(AbsoluteDate.of(afterRentStart), afterRentEnd);
        }
        return null;
    }

	
	@Data
	@AllArgsConstructor
	class DatesFromTo {
		private AbsoluteDate from;
		private AbsoluteDate to;
	}

	@Data
	class ThreeDatesRanges {
		private DatesFromTo previous;
		private DatesFromTo current;
		private DatesFromTo following;

		public boolean preFromIsBeforePreTo() {
			return this.previous.getFrom().toLocalDate().isBefore(this.previous.getTo().toLocalDate());
		}

		public boolean followToIsAfterFollowFrom() {
			return this.getFollowing().getTo().toLocalDate().isAfter(this.getFollowing().getFrom().toLocalDate());
		}

	}

	@Override
	protected Class<LandLinkBatchFixReq> getJobClass() {
		return LandLinkBatchFixReq.class;
	}

}
