package com.abacogroup.cllapi.exceptions;

import com.abacogroup.common.exceptions.AbstractAppException;
import io.swagger.v3.oas.annotations.media.Schema;

public class InvalidPayloadException extends AbstractAppException {

	public InvalidPayloadException(ErrEnum code, String message) {
		super(new InvalidPayloadException.ErrorBody(code.name(), message));
	}

	public enum ErrEnum {
		INVALID_PAYLOAD
	}

	@Schema(name = "InvalidPayloadExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { "INVALID_PAYLOAD" })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}

}
