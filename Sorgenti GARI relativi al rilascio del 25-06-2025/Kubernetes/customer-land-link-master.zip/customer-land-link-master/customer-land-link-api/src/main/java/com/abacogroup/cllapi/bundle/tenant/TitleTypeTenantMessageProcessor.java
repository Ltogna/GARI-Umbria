package com.abacogroup.cllapi.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.cllapi.bundle.BundleConstants;
import com.abacogroup.cllapi.db.dao.TitleTypeDAO;
import com.abacogroup.cllapi.db.ntt.TitleTypeEntity;
import com.abacogroup.common.service.AuditHelper;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TitleTypeTenantMessageProcessor implements TenantMessageProcessor {

	private final TitleTypeDAO titleTypeDAO;

	public TitleTypeTenantMessageProcessor(TitleTypeDAO titleTypeDAO) {
		this.titleTypeDAO = titleTypeDAO;
	}

	@Override
	public void onMessage(TenantMessage message) {
		String tenantId = message.getTenantId();
		if (titleTypeDAO.countAll(tenantId) > 0L) {
			log.warn("title types definitions already present for tenant {}", tenantId);
		} else {
			TitleTypeEntity auditType = new TitleTypeEntity();
			AuditHelper.setAuditForInsert(BundleConstants.SYSTEM_USER, titleTypeDAO, auditType);
			titleTypeDAO.insertNewTenant(ALL_TENANTS, tenantId, auditType);
			log.info("title types definitions successfully inserted for tenant {}", tenantId);
		}
	}
}
