package com.abacogroup.cllapi.db.ntt;

import com.abacogroup.jdbi.model.AuditEntity;
import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class TitleTypeEntity implements AuditEntity {

	private Long id;
	private String code;
	private String tenantId;
	@Builder.Default
	private int flDayToReq = 0;
	@Builder.Default
	private int flDayToEditable = 0;
	@Builder.Default
	private int flAllowFutureDayFrom = 0;

	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;
}
