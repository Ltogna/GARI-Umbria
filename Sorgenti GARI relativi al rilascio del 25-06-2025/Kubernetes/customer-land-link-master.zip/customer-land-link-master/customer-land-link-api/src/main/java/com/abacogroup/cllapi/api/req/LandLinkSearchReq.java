package com.abacogroup.cllapi.api.req;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.cllcli.api.v1.AnomalyLevelEnum;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.common.resources.ResourceConstants;
import com.abacogroup.common.resources.req.BaseSearchReq;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * Riferimenti catastali
 * o Codice comune – descrizione comune o sezione (sigla provincia) – foglio – codice
 * particella/subalterno
 * o Es. A061 – AFFI (VR) – 1 – 00001/A;
 *       sectorCode - shortDescr - blockCode - parcel
 *
 *
 * sector = comune
 * block = foglio
 * parcel_filter = particella/subalterno
 */
@Data
@NoArgsConstructor
@Accessors(chain = true)
public class LandLinkSearchReq implements BaseSearchReq {

	@Parameter(in = ParameterIn.PATH, description = "the party Id")
	@NotNull
	@PathParam("partyId")
	private Long partyId;

	@Parameter(in = ParameterIn.QUERY, description = "group id")
	@QueryParam("groupId")
	private Long groupId;

	@Parameter(in = ParameterIn.QUERY, description = "title Type Id")
	@QueryParam("titleTypeId")
	private Long titleTypeId;
	
	@Parameter(in = ParameterIn.QUERY, description = "title Type Id")
	@QueryParam("titleTypeCode")
	private String titleTypeCode;

	@Parameter(in = ParameterIn.QUERY, description = "parcel Id")
	@QueryParam("parcelId")
	private Long parcelId;

	@Parameter(in = ParameterIn.QUERY, example = "A001", description = "sectorCode aka comune")
	@QueryParam("sectorCode")
	private String sectorCode;
	
	@JsonIgnore
	private List<String> sectorCodeList;

	@Parameter(in = ParameterIn.QUERY, example = "11", description = "blockCode aka foglio")
	@QueryParam("blockCode")
	private String blockCode;

	@Parameter(in = ParameterIn.QUERY, example = "00095",
			description = "parcel Code aka codice parcella o particella (in parcel_filter [parcelCode]/[subParcelCode])")
	@QueryParam("parcelCode")
	private String parcelCode;

	@Parameter(in = ParameterIn.QUERY, example = "A",
			description = "sub Parcel aka subalterno (in parcel_filter [parcelCode]/[subParcelCode])")
	@QueryParam("subParcelCode")
	private String subParcelCode;

	@Parameter(in = ParameterIn.QUERY, description = "anomaly Level")
	@QueryParam("anomalyLevel")
	private AnomalyLevelEnum anomalyLevel;
	
	@Parameter(description = "Include the geometries data") 
	@QueryParam("include_geometries") 
	@DefaultValue("False") 
	private Boolean includeGeometries;

	@Deprecated
	@Parameter(in = ParameterIn.QUERY, example = "A", deprecated = true,
			description = "sub Parcel aka subalterno (in parcel_filter [parcelCode]/[subParcelCode])")
	@QueryParam("subParcel")
	public LandLinkSearchReq setSubParcel(String subParcelCode) {
		if (StringUtils.isNotBlank(subParcelCode)) {
			this.subParcelCode = subParcelCode;
		}
		return this;
	}

	@Override
	public int getPageSize() {
		return ResourceConstants.PAGE_SIZE;
	}

	@Override
	public Criteria getCriteria(ReqContext reqContext) {
		List<Criteria> specs = new ArrayList<>();

		Optional.ofNullable(this.getPartyId())
				.map(v -> CriteriaBuilder.number("lld.party_id").eq(v))
				.ifPresent(specs::add);

		Optional.ofNullable(this.getGroupId())
				.map(v -> CriteriaBuilder.number("lld.group_id").eq(v))
				.ifPresent(specs::add);

		Optional.ofNullable(this.getPartyId())
				.map(v -> CriteriaBuilder.number("lld.party_id").eq(v))
				.ifPresent(specs::add);

		Optional.ofNullable(this.getTitleTypeId())
				.map(v -> CriteriaBuilder.number("lld.title_type_id").eq(v))
				.ifPresent(specs::add);
		
		Optional.ofNullable(this.getTitleTypeCode())
				.map(v -> CriteriaBuilder.string("tt.code").eq(v))
				.ifPresent(specs::add);

		Optional.ofNullable(this.getParcelId())
				.map(v -> CriteriaBuilder.number("lld.parcel_id").eq(v))
				.ifPresent(specs::add);

		Optional.ofNullable(this.getBlockCode())
				.map(StringUtils::trimToNull)
				.map(v -> CriteriaBuilder.string("lld.block_code").eq(v))
				.ifPresent(specs::add);
		Optional.ofNullable(this.getSectorCode())
				.map(StringUtils::trimToNull)
				.map(StringUtils::upperCase)
				.map(v -> CriteriaBuilder.string("lld.sector_code").eq(v))
				.ifPresent(specs::add);
		Optional.ofNullable(this.getParcelCode())
				.map(StringUtils::trimToNull)
				.map(v -> StringUtils.leftPad(v, 5, '0'))
				.map(v -> CriteriaBuilder.string("lld.parcel_code").eq(v))
				.ifPresent(specs::add);
		Optional.ofNullable(this.getSubParcelCode())
				.map(StringUtils::trimToNull)
				.map(StringUtils::upperCase)
				.map(v -> CriteriaBuilder.string("lld.sub_parcel_code").eq(v))
				.ifPresent(specs::add);
		Optional.ofNullable(this.getSectorCodeList())
				.map(v -> CriteriaBuilder.string("lld.sector_code").in(v))
				.ifPresent(specs::add);

		return CriteriaBuilder.and(specs.toArray(new Criteria[0]));
	}

	@Deprecated
	@Override
	public OrderByElement getSort() {
		return OrderByBuilder.field("lld.sector_code");
	}

	@JsonIgnore
	@Schema(hidden = true)
	public OrderBy getSortComplete() {
		return OrderByBuilder.from(
				OrderByBuilder.field("lld.sector_code"),
				OrderByBuilder.field("lld.block_code"),
				OrderByBuilder.field("lld.parcel_code"),
				OrderByBuilder.field("lld.sub_parcel_code")
		);
	}
}
