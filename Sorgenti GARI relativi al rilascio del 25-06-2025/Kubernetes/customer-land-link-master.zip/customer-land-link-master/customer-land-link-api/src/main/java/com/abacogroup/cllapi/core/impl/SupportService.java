package com.abacogroup.cllapi.core.impl;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.List;

import com.abacogroup.cllapi.api.LandLinkFixRes;
import com.abacogroup.cllapi.core.embededqueue.LandLinkBatchFixQueue;
import com.abacogroup.cllapi.db.dao.SupportDAO;
import com.abacogroup.cllapi.db.dao.TitleTypeDAO;
import com.abacogroup.cllapi.db.ntt.TitleTypeEntity;
import com.abacogroup.cllapi.exceptions.InvalidTitleTypeException;
import com.abacogroup.cllapi.exceptions.InvalidTitleTypeException.ErrEnum;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;

public class SupportService {

	private final SupportDAO supportDAO;
	private final TitleTypeDAO titleTypeDAO;
	
	private final Clock appClock;
	
	private final LandLinkBatchFixQueue landLinkBatchFixQueue;
	
	private static final String PROPERTY_CODE = "PROPRIETA";

	public SupportService(SupportDAO supportDAO, TitleTypeDAO titleTypeDAO,
			LandLinkBatchFixQueue landLinkBatchFixQueue, Clock appClock) {
		this.supportDAO = supportDAO;
		this.titleTypeDAO = titleTypeDAO;
		
		this.landLinkBatchFixQueue = landLinkBatchFixQueue;		
		this.appClock = appClock;
		
	}

	public void fixLandLinkBatch(ReqContext reqContext, Long partyId, AbsoluteDate referenceDate) {
		String tenant = reqContext.getUser().getTenant();
		
		final AbsoluteDate finalRefDate = referenceDate != null ? referenceDate : AbsoluteDate.of(LocalDateTime.now(appClock));
		
		TitleTypeEntity titleTypeEntity = titleTypeDAO.findByCode(tenant, PROPERTY_CODE)
		.orElseThrow(() -> new InvalidTitleTypeException(ErrEnum.TITLE_TYPE_NOT_FOUND, String.format("titleType %s not found", PROPERTY_CODE)));

		List<LandLinkFixRes> landLinkIds = supportDAO.getLandLinkBatch(tenant, titleTypeEntity.getId(), partyId);
		
		landLinkIds.stream().forEach(ll -> landLinkBatchFixQueue.add(reqContext, ll.getLandLinkId(), ll.getPropLandLinkId(), finalRefDate));
	}
	
}
