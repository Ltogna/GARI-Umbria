package com.abacogroup.cllapi.api.req;

import java.util.ArrayList;
import java.util.List;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Builder.Default;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class GroupCreateReq extends GroupUpdateReq {

	@NotNull
	private Long titleTypeId;

	@NotEmpty
	@Valid
	@Default
	private List<LandLinkBatchCreateReq> landLinks = new ArrayList<>();

}
