package com.abacogroup.cllapi;

import java.io.IOException;
import java.net.URI;
import java.time.Clock;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;
import java.util.concurrent.TimeoutException;

import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.jdbi.v3.core.Jdbi;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyClient;
import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyTypeClient;
import com.abacogroup.anomalyregistry.core.cli.v1.impl.AnomalyClientImpl;
import com.abacogroup.anomalyregistry.core.cli.v1.impl.AnomalyTypeClientImpl;
import com.abacogroup.bundles.Constants;
import com.abacogroup.bundles.initializer.BundleInitServiceBuilder;
import com.abacogroup.bundles.initializer.InitService;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.listener.ListenerBuilder;
import com.abacogroup.bundles.listener.RabbitListener;
import com.abacogroup.bundles.listener.configdata.ConfigDataLogProducer;
import com.abacogroup.bundles.listener.configdata.ProcessorOrderPolicyEnum;
import com.abacogroup.bundles.listener.configdata.builder.ConfigDataConsumerBuilder;
import com.abacogroup.bundles.listener.tenant.builder.NewTenantEventConsumerBuilder;
import com.abacogroup.cllapi.CustomerLandLinkConfiguration.BundleConfig;
import com.abacogroup.cllapi.CustomerLandLinkConfiguration.RabbitmqConfig;
import com.abacogroup.cllapi.bundle.config.AnomalyCategoriesConfigMessageProcessor;
import com.abacogroup.cllapi.bundle.config.CllSettingsConfigMessageProcessor;
import com.abacogroup.cllapi.bundle.config.DynamicDocConfigMessageProcessor;
import com.abacogroup.cllapi.bundle.config.TitleTypeConfigMessageProcessor;
import com.abacogroup.cllapi.bundle.tenant.AnomalyCategoriesTenantMessageProcessor;
import com.abacogroup.cllapi.bundle.tenant.CllSettingsTenantMessageProcessor;
import com.abacogroup.cllapi.bundle.tenant.DynamicDocTenantMessageProcessor;
import com.abacogroup.cllapi.bundle.tenant.I18nTenantMessageProcessor;
import com.abacogroup.cllapi.bundle.tenant.TitleTypeTenantMessageProcessor;
import com.abacogroup.cllapi.core.AnomalyService;
import com.abacogroup.cllapi.core.GroupDocumentService;
import com.abacogroup.cllapi.core.GroupService;
import com.abacogroup.cllapi.core.LandLinkDocumentService;
import com.abacogroup.cllapi.core.LandLinkEventProducer;
import com.abacogroup.cllapi.core.LandLinkService;
import com.abacogroup.cllapi.core.LpisClientService;
import com.abacogroup.cllapi.core.ParcelService;
import com.abacogroup.cllapi.core.PartiesAclClientService;
import com.abacogroup.cllapi.core.PartyClientService;
import com.abacogroup.cllapi.core.ServiceContainer;
import com.abacogroup.cllapi.core.TitleTypeService;
import com.abacogroup.cllapi.core.embededqueue.AnomalyHelper;
import com.abacogroup.cllapi.core.embededqueue.AnomalyQueue;
import com.abacogroup.cllapi.core.embededqueue.EventPublisher;
import com.abacogroup.cllapi.core.embededqueue.LandLinkBatchFixQueue;
import com.abacogroup.cllapi.core.impl.AnomalyServiceImpl;
import com.abacogroup.cllapi.core.impl.CllRabbitMqPublisher;
import com.abacogroup.cllapi.core.impl.CllSettingsV1ServiceImpl;
import com.abacogroup.cllapi.core.impl.DocTypeServiceImpl;
import com.abacogroup.cllapi.core.impl.FileStoreProxyClient;
import com.abacogroup.cllapi.core.impl.GroupDocumentServiceImpl;
import com.abacogroup.cllapi.core.impl.GroupServiceImpl;
import com.abacogroup.cllapi.core.impl.LandLinkDocumentServiceImpl;
import com.abacogroup.cllapi.core.impl.LandLinkEventProducerImpl;
import com.abacogroup.cllapi.core.impl.LandLinkServiceImpl;
import com.abacogroup.cllapi.core.impl.LandLinkV1ServiceImpl;
import com.abacogroup.cllapi.core.impl.LpisClientServiceImpl;
import com.abacogroup.cllapi.core.impl.ParcelServiceImpl;
import com.abacogroup.cllapi.core.impl.ParcelV1ServiceImpl;
import com.abacogroup.cllapi.core.impl.PartiesAclClientServiceImpl;
import com.abacogroup.cllapi.core.impl.PartyClientServiceImpl;
import com.abacogroup.cllapi.core.impl.SupportService;
import com.abacogroup.cllapi.core.impl.TitleTypeServiceImpl;
import com.abacogroup.cllapi.db.dao.AnomaliesDAO;
import com.abacogroup.cllapi.db.dao.AnomalyCategoriesDAO;
import com.abacogroup.cllapi.db.dao.CllSettingsDAO;
import com.abacogroup.cllapi.db.dao.DAOContainer;
import com.abacogroup.cllapi.db.dao.DocTypeRelationDAO;
import com.abacogroup.cllapi.db.dao.GroupDAO;
import com.abacogroup.cllapi.db.dao.GroupDocumentDAO;
import com.abacogroup.cllapi.db.dao.I18nDAO;
import com.abacogroup.cllapi.db.dao.LandLinkDAO;
import com.abacogroup.cllapi.db.dao.LandLinkDocumentDAO;
import com.abacogroup.cllapi.db.dao.SupportDAO;
import com.abacogroup.cllapi.db.dao.TitleTypeDAO;
import com.abacogroup.cllapi.jackson.AbsoluteDateSerializer;
import com.abacogroup.cllapi.jackson.WKTGeometryDeserializer;
import com.abacogroup.cllapi.jackson.WKTGeometrySerializer;
import com.abacogroup.cllapi.resources.DevtoolsResource;
import com.abacogroup.cllapi.resources.DocTypeResource;
import com.abacogroup.cllapi.resources.GroupDocumentResource;
import com.abacogroup.cllapi.resources.GroupResource;
import com.abacogroup.cllapi.resources.LandLinkDocumentResource;
import com.abacogroup.cllapi.resources.LandLinkResource;
import com.abacogroup.cllapi.resources.ParcelResource;
import com.abacogroup.cllapi.resources.SectorResource;
import com.abacogroup.cllapi.resources.SupportResource;
import com.abacogroup.cllapi.resources.TitleTypeResource;
import com.abacogroup.cllapi.resources.pub.CllSettingsPublicResource;
import com.abacogroup.cllapi.resources.pub.GroupDocumentPublicResource;
import com.abacogroup.cllapi.resources.pub.GroupPublicResource;
import com.abacogroup.cllapi.resources.pub.LandLinkPublicResource;
import com.abacogroup.cllapi.resources.pub.ParcelPublicResource;
import com.abacogroup.cllapi.resources.pub.SectorPublicResource;
import com.abacogroup.cllapi.resources.pub.TitleTypePublicResource;
import com.abacogroup.common.core.cli.TokenRelayStrategy;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.SsoAuthorizer;
import com.abacogroup.dynamicdocuments.auth.impl.Sso2AuthenticatorProvider;
import com.abacogroup.dynamicdocuments.files.AbacoFileStore;
import com.abacogroup.dynamicdocuments.files.FileStoreSupport;
import com.abacogroup.dynamicdocuments.http.JaxRsClient;
import com.abacogroup.dynamicdocuments.http.RestClient;
import com.abacogroup.dynamicdocuments.http.Sso2AuthenticationProvider;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.filestore.client.FileStoreClient;
import com.abacogroup.jdbi.OraJdbiPlugin;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.jdbi.config.AbacoJdbiConfig;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.tracing.dropwizard.AbacoApplication;
import com.abacogroup.tracing.jaxrs.client.AddRequestId;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.forms.MultiPartBundle;
import io.dropwizard.jdbi3.JdbiFactory;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import io.dropwizard.migrations.MigrationsBundle;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import io.swagger.v3.oas.integration.ClasspathOpenApiConfigurationLoader;
import io.swagger.v3.oas.integration.api.OpenAPIConfiguration;
import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration.Dynamic;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CustomerLandLinkApplication extends AbacoApplication<CustomerLandLinkConfiguration> {

	public static final String APP_PREFIX = "cll";
	public static final String APP_NAME = "customer-land-link-api";

	public static void main(final String[] args) {
		try {
			new CustomerLandLinkApplication().run(args);
		} catch (Exception e) {
			log.error("Error during run cll application: ", e);
			System.exit(1);
		}
	}

	@Override
	public String getName() {
		return APP_NAME;
	}

	@Override
	public void initialize(final Bootstrap<CustomerLandLinkConfiguration> bootstrap) {
		bootstrap.addBundle(new MigrationsBundle<>() {
			@Override
			public DataSourceFactory getDataSourceFactory(CustomerLandLinkConfiguration configuration) {
				return configuration.getDatabase();
			}
		});

		SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
				new EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);

		bootstrap.addBundle(new MultiPartBundle());
	}

	@Override
	public void doRun(final CustomerLandLinkConfiguration configuration, final Environment environment) throws Exception {

		ObjectMapper objectMapper = environment.getObjectMapper();
		configureObjectMapper(objectMapper);

		Jdbi jdbi = jdbi(configuration, environment);
		Connection rabbitmqConnection = this.createRabbitmqConnection(configuration);

		if (configuration.getVariant() != null)
			AnomalyHelper.setVariant(configuration.getVariant());

		DAOContainer daoContainer = buildDAOContainer(jdbi);

		final Sso2Client sso2Client = this.register(initSso2Client(configuration, environment));

		setUpResourcesAndBundles(configuration, environment, objectMapper, jdbi, rabbitmqConnection, daoContainer, sso2Client);
		
		this.initAuth(configuration, environment, sso2Client);
		this.initMultiTenant(environment);
		this.initOpenApi(environment.jersey());
		this.setupCORS(configuration, environment);

	}
	
	
	private void setUpResourcesAndBundles(CustomerLandLinkConfiguration configuration, Environment environment, ObjectMapper objectMapper, Jdbi jdbi, Connection rabbitmqConnection, DAOContainer daoContainer, Sso2Client sso2Client) throws Exception {
		
		Clock appClock = Clock.systemDefaultZone();
		
		ServiceContainer serviceContainer = buildServiceContainer(configuration, environment, objectMapper, jdbi, rabbitmqConnection, daoContainer, sso2Client);
		
		setUpResources(configuration, environment, jdbi, rabbitmqConnection, appClock, serviceContainer);
		
		setUpRabbitConsumerAndProducers(configuration, objectMapper, jdbi, rabbitmqConnection, serviceContainer.getDocumentTypeService(), daoContainer);
		this.afterServicesUp();
	}

	private void setUpResources(CustomerLandLinkConfiguration configuration, Environment environment, Jdbi jdbi,
			Connection rabbitmqConnection, Clock appClock, ServiceContainer serviceContainer) {
		
		List<Object> resources = new ArrayList<>();
		// private
		resources.add(new TitleTypeResource(serviceContainer.getTitleTypeService()));
		resources.add(new LandLinkResource(serviceContainer.getLandLinkService()));
		resources.add(new GroupResource(serviceContainer.getGroupService()));
		resources.add(new DocTypeResource(serviceContainer.getDocTypeRelationService()));
		resources.add(new SectorResource(serviceContainer.getLpisClientService()));
		resources.add(new ParcelResource(serviceContainer.getParcelService()));
		resources.add(new GroupDocumentResource(serviceContainer.getGroupDocumentService()));
		resources.add(new LandLinkDocumentResource(serviceContainer.getLandLinkDocumentService(), appClock));
		resources.add(new SupportResource(serviceContainer.getSupportService()));
		// public
		resources.add(new LandLinkPublicResource(serviceContainer.getLandLinkV1Service()));
		resources.add(new CllSettingsPublicResource(serviceContainer.getCllSettingsV1Service()));
		resources.add(new ParcelPublicResource(serviceContainer.getParcelV1Service()));
		resources.add(new TitleTypePublicResource(serviceContainer.getTitleTypeService()));
		resources.add(new GroupPublicResource(serviceContainer.getGroupService()));
		resources.add(new GroupDocumentPublicResource(serviceContainer.getGroupDocumentService()));
		resources.add(new SectorPublicResource(serviceContainer.getLandLinkV1Service()));

		if (configuration.isDevToolsEnabled()) {
			resources.add(new DevtoolsResource(rabbitmqConnection, jdbi));
		}

		// environment.jersey().register(new PartyExceptionMapper());
		resources.forEach(environment.jersey()::register);
	}

	private ServiceContainer buildServiceContainer(CustomerLandLinkConfiguration configuration, Environment environment, ObjectMapper objectMapper, Jdbi jdbi, Connection rabbitmqConnection, DAOContainer daoContainer, Sso2Client sso2Client) throws IOException {
		final WebTarget lpisTarget = this.initLpisTarget(configuration, environment, objectMapper);
		final WebTarget partyTarget = this.initPartyTarget(configuration, environment);
		final WebTarget partiesAclTarget = this.initPartiesAclTarget(configuration, environment);
		final WebTarget anomalyTarget = this.initAnomalyTarget(configuration, environment);
		
		Clock appClock = Clock.systemDefaultZone();
		
		final DocumentTypeService documentTypeService = register(new DocumentTypeService(jdbi));

		final DocumentService documentService = buildDocumentService(configuration, environment, objectMapper,sso2Client, documentTypeService);

		final PartyClientService partyClientService = this.register(new PartyClientServiceImpl(partyTarget));
		final PartiesAclClientService partiesAclClientService = this.register(new PartiesAclClientServiceImpl(partiesAclTarget));
		final LpisClientService lpisClientService = this.register(new LpisClientServiceImpl(lpisTarget));

		final AnomalyClient anomalyClient = this.register(new AnomalyClientImpl(anomalyTarget, new TokenRelayStrategy()));
		final AnomalyTypeClient anomalyTypeClient = this.register(new AnomalyTypeClientImpl(anomalyTarget, new TokenRelayStrategy()));

		final AnomalyService anomalyService = this.register(new AnomalyServiceImpl(daoContainer.getAnomaliesDAO(), anomalyTypeClient, appClock));

		final AnomalyHelper anomalyHelper = this.register(new AnomalyHelper(daoContainer, documentService, appClock, anomalyClient, sso2Client));
		final EventPublisher anomalyQueue = buildAnomalyQueue(configuration, environment, appClock, jdbi, anomalyHelper);

		final LandLinkEventProducer landLinkEventProducer = this.register(this.createLandLinkEventProducer(configuration, environment, jdbi, objectMapper, rabbitmqConnection, daoContainer.getLandLinkDAO(), appClock));

		final TitleTypeService titleTypeService = this.register(new TitleTypeServiceImpl(daoContainer.getTitleTypeDAO()));
		final LandLinkService landLinkService = this.register(new LandLinkServiceImpl(daoContainer.getLandLinkDAO(), titleTypeService, lpisClientService, anomalyService, landLinkEventProducer, anomalyQueue, appClock, daoContainer.getCllSettingsDAO()));

		final GroupService groupService = this.register(new GroupServiceImpl(daoContainer.getGroupDAO(), daoContainer.getLandLinkDAO(), landLinkEventProducer, anomalyQueue, titleTypeService, landLinkService, partyClientService, appClock, daoContainer.getCllSettingsDAO()));

		final FileStoreProxyClient fileStoreProxyClient = this.register(new FileStoreProxyClient(this.initFileStoreTarget(configuration, environment)));

		final GroupDocumentService groupDocumentService = this.register(new GroupDocumentServiceImpl(groupService, daoContainer.getGroupDocumentDAO(), documentService, documentTypeService, fileStoreProxyClient, configuration.getDynamicDocumentsBucket(), landLinkEventProducer, anomalyQueue, appClock));
		
		final LandLinkDocumentService landLinkDocumentService = this.register(new LandLinkDocumentServiceImpl(landLinkService, daoContainer.getLandLinkDocumentDAO(), documentService, documentTypeService, fileStoreProxyClient, configuration.getDynamicDocumentsBucket(), landLinkEventProducer, anomalyQueue, appClock));

		final ParcelService parcelService = this.register(new ParcelServiceImpl(lpisClientService, landLinkService, partyClientService, partiesAclClientService, daoContainer.getCllSettingsDAO(), appClock));
		
		final LandLinkBatchFixQueue landLinkBatchFixQueue = buildLandLinkBatchFixQueue(environment, jdbi, groupService, landLinkService, sso2Client);		
		
		return ServiceContainer.builder()
				.anomalyService(anomalyService)
				.cllSettingsV1Service(this.register(new CllSettingsV1ServiceImpl(daoContainer.getCllSettingsDAO())))
				.docTypeRelationService(this.register(new DocTypeServiceImpl(daoContainer, titleTypeService, groupService, groupDocumentService, landLinkDocumentService, documentTypeService, configuration.getDynamicDocumentsBucket())))
				.documentService(documentService)
				.documentTypeService(documentTypeService)
				.groupDocumentService(groupDocumentService)
				.groupService(groupService)
				.landLinkDocumentService(landLinkDocumentService)
				.landLinkService(landLinkService)
				.landLinkV1Service(this.register(new LandLinkV1ServiceImpl(landLinkService, partyClientService, daoContainer.getLandLinkDAO())))
				.lpisClientService(lpisClientService)
				.parcelService(parcelService)
				.parcelV1Service(this.register(new ParcelV1ServiceImpl(parcelService)))
				.partiesAclClientService(partiesAclClientService)
				.partyClientService(partyClientService)
				.supportService(this.register(new SupportService(daoContainer.getSupportDAO(), daoContainer.getTitleTypeDAO(), landLinkBatchFixQueue, appClock)))
				.titleTypeService(titleTypeService)
				.build();
	}

	private DocumentService buildDocumentService(CustomerLandLinkConfiguration configuration, Environment environment,
			ObjectMapper objectMapper, Sso2Client sso2Client, final DocumentTypeService documentTypeService) {
		FileStoreClient fileStoreClient = new FileStoreClient(URI.create(configuration.getFileStoreConfig().getUrl()), objectMapper);
		FileStoreSupport fileStoreSupport = this.register(new AbacoFileStore(fileStoreClient, new Sso2AuthenticatorProvider(sso2Client)));
		RestClient restClient = this.register(this.initRestClient(configuration, environment, sso2Client));

		final DocumentService documentService = register(DocumentService.create(documentTypeService, restClient, fileStoreSupport, configuration.getDynamicDocumentsBucket()));
		return documentService;
	}
	
	private void setUpRabbitConsumerAndProducers(final CustomerLandLinkConfiguration configuration, ObjectMapper objectMapper, Jdbi jdbi,
			Connection rabbitmqConnection, final DocumentTypeService documentTypeService, DAOContainer daoContainer) throws Exception {
		log.info("creating CONSUMERS rabbitConsumerManager");

		final String serviceName = configuration.getVariant() != null ? configuration.getVariant() : APP_NAME;

		RabbitListener rabbitListener = ListenerBuilder
				.newBuilder(rabbitmqConnection)
				.withConfigDataConsumer(this.register(ConfigDataConsumerBuilder.newBuilder(jdbi, rabbitmqConnection)
						.route(serviceName)
						.processor(this.register(new TitleTypeConfigMessageProcessor(objectMapper, daoContainer.getTitleTypeDAO(), daoContainer.getI18nDAO())))
						.processor(this.register(new DynamicDocConfigMessageProcessor(daoContainer.getTitleTypeDAO(), daoContainer.getDocTypeRelationDAO(),
								documentTypeService, daoContainer.getI18nDAO())))
						.processor(this.register(new CllSettingsConfigMessageProcessor(objectMapper, daoContainer.getCllSettingsDAO())))
						.processor(this.register(new AnomalyCategoriesConfigMessageProcessor(daoContainer.getAnomalyCategoriesDAO(), objectMapper)))

						.configLogProducer(configDataLogProducerBean(objectMapper, rabbitmqConnection))
						.withOrderPolicy(ProcessorOrderPolicyEnum.PROCESSOR)
						.build()))

				.withNewTenantEventConsumer(NewTenantEventConsumerBuilder.newBuilder(jdbi)
						.route(serviceName)
						.processor(this.register(new TitleTypeTenantMessageProcessor(daoContainer.getTitleTypeDAO())))
						.processor(this.register(new DynamicDocTenantMessageProcessor(daoContainer.getDocTypeRelationDAO(), documentTypeService)))
						.processor(this.register(new CllSettingsTenantMessageProcessor(daoContainer.getCllSettingsDAO())))
						.processor(this.register(new AnomalyCategoriesTenantMessageProcessor(daoContainer.getAnomalyCategoriesDAO())))
						.processor(this.register(new I18nTenantMessageProcessor(daoContainer.getI18nDAO())))
						.build())
				.buildListener();

		log.info("creating INITIALIZERS");
		BundleConfig bundleConfig = configuration.getBundleConfig();

		InitService bundleInitService = BundleInitServiceBuilder
				.producer(this.register(new BundleInitServiceProducer(rabbitmqConnection)))
				.configLocation(bundleConfig.getConfigLocation())
				// .baseTempDir()
				.build();

		this.startRabbitConsumerAndProducers(bundleInitService, rabbitListener);
	}

	private DAOContainer buildDAOContainer(Jdbi jdbi) {
		return DAOContainer.builder()
				.i18nDAO(jdbi.onDemand(I18nDAO.class))
				.landLinkDAO(jdbi.onDemand(LandLinkDAO.class))
				.titleTypeDAO(jdbi.onDemand(TitleTypeDAO.class))
				.groupDAO(jdbi.onDemand(GroupDAO.class))
				.docTypeRelationDAO(jdbi.onDemand(DocTypeRelationDAO.class))
				.groupDocumentDAO(jdbi.onDemand(GroupDocumentDAO.class))
				.landLinkDocumentDAO(jdbi.onDemand(LandLinkDocumentDAO.class))
				.cllSettingsDAO(jdbi.onDemand(CllSettingsDAO.class))
				.anomalyCategoriesDAO(jdbi.onDemand(AnomalyCategoriesDAO.class))
				.anomaliesDAO(jdbi.onDemand(AnomaliesDAO.class))
				.supportDAO(jdbi.onDemand(SupportDAO.class))
				.build();
	}

	protected EventPublisher buildAnomalyQueue(CustomerLandLinkConfiguration configuration, Environment environment, Clock appClock, Jdbi jdbi,
			AnomalyHelper anomalyHelper) {
		final EventPublisher anomalyQueue = this.register(
				new AnomalyQueue(new JdbiRepository(jdbi), environment.metrics(), configuration, anomalyHelper, jdbi, appClock));
		return anomalyQueue;
	}
	
	protected LandLinkBatchFixQueue buildLandLinkBatchFixQueue(Environment environment, Jdbi jdbi, GroupService groupService, LandLinkService landLinkService,
			Sso2Client sso2Client) {
		final LandLinkBatchFixQueue queue = this.register(
				new LandLinkBatchFixQueue(new JdbiRepository(jdbi), environment.metrics(), groupService, landLinkService, sso2Client));
		return queue;
	}
	
	protected void afterServicesUp() throws Exception {
		log.debug("application started");

	}

	protected ConfigDataLogProducer configDataLogProducerBean(ObjectMapper objectMapper, Connection rabbitmqConnection) {
		return this.register(new ConfigDataLogProducer(objectMapper, rabbitmqConnection, Constants.DEFAULT_EXCHANGE_NAME));
	}

	protected LandLinkEventProducer createLandLinkEventProducer(CustomerLandLinkConfiguration config, Environment environment, Jdbi jdbi,
			ObjectMapper objectMapper,
			Connection rabbitmqConnection, LandLinkDAO landLinkDAO, Clock appClock) throws IOException {
		CllRabbitMqPublisher.setExchange(config.getVariant() != null ? config.getVariant() : CllRabbitMqPublisher.DEFAULT_EXCHANGE);
		CllRabbitMqPublisher cllRabbitMqPublisher = new CllRabbitMqPublisher(rabbitmqConnection, landLinkDAO);
		cllRabbitMqPublisher.setObjectMapper(objectMapper);

		return new LandLinkEventProducerImpl(environment, jdbi, objectMapper, cllRabbitMqPublisher, appClock);
	}

	private WebTarget initLpisTarget(CustomerLandLinkConfiguration configuration, Environment environment, ObjectMapper mapper) {
		final Client client = new JerseyClientBuilder(environment)
				.using(mapper)
				.using(configuration.getJerseyClient())
				.build("lpis-client");
		client.register(new AddRequestId());

		return client.target(configuration.getLpisConfig().getUrl());
	}

	private WebTarget initPartyTarget(CustomerLandLinkConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("party-client");
		client.register(new AddRequestId());
 
		return client.target(configuration.getPartyConfig().getUrl());
	}
	
	private WebTarget initPartiesAclTarget(CustomerLandLinkConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("parties-acl-client");
		client.register(new AddRequestId());
		
		return client.target(configuration.getPartiesAclConfig().getUrl());
	}

	private WebTarget initAnomalyTarget(CustomerLandLinkConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("anomaly-client");
		client.register(new AddRequestId());

		return client.target(configuration.getAnomaliesRegistryConfig().getUrl());
	}

	private WebTarget initFileStoreTarget(CustomerLandLinkConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("file-store-client");
		client.register(new AddRequestId());

		return client.target(configuration.getFileStoreConfig().getUrl());
	}

	private Sso2Client initSso2Client(CustomerLandLinkConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("sso2-client");
		client.register(new AddRequestId());

		WebTarget webTarget = client.target(configuration.getSso2Config().getUrl());
		return new Sso2Client(configuration.getSso2Config().getTasksAuthPhrase(), webTarget);
	}

	private RestClient initRestClient(CustomerLandLinkConfiguration configuration, Environment environment, Sso2Client sso2Client) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("restclient");
		client.register(new AddRequestId());

		return new JaxRsClient(client, new Sso2AuthenticationProvider(sso2Client));
	}

	protected void startRabbitConsumerAndProducers(InitService initService, RabbitListener rabbitListener) throws Exception {
		rabbitListener.start();
		initService.start();
	}

	protected Connection createRabbitmqConnection(CustomerLandLinkConfiguration configuration)
			throws IOException, TimeoutException {
		RabbitmqConfig rabbitmqConfig = configuration.getRabbitmqConfig();

		ConnectionFactory factory = new ConnectionFactory();

		if (rabbitmqConfig.getHost() != null) {
			factory.setHost(rabbitmqConfig.getHost());
		}
		if (rabbitmqConfig.getUser() != null) {
			factory.setUsername(rabbitmqConfig.getUser());
		}
		if (rabbitmqConfig.getPassword() != null) {
			factory.setPassword(rabbitmqConfig.getPassword());
		}
		if (rabbitmqConfig.getVirtualhost() != null) {
			factory.setVirtualHost(rabbitmqConfig.getVirtualhost());
		}
		if (rabbitmqConfig.getPort() != null) {
			factory.setPort(rabbitmqConfig.getPort());
		}
		factory.setAutomaticRecoveryEnabled(true);

		return factory.newConnection();
	}

	protected void configureObjectMapper(ObjectMapper objectMapper) {
		objectMapper.registerModule(new JavaTimeModule());
		objectMapper
				.setTimeZone(TimeZone.getDefault())
				.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		objectMapper.configure(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES, false);

		SimpleModule module = new SimpleModule("custom-deserializers", Version.unknownVersion());
		module.addDeserializer(Geometry.class, new WKTGeometryDeserializer());
		module.addSerializer(Geometry.class, new WKTGeometrySerializer());
		module.addSerializer(AbsoluteDate.class, new AbsoluteDateSerializer());
		objectMapper.registerModule(module);
	}

	protected void initAuth(CustomerLandLinkConfiguration configuration, Environment environment, Sso2Client sso2Cli) {
		// AuthUtils.installAuthFilter(environment, sso2Cli, new SsoAuthorizer(sso2Cli));

		AuthUtils.installAuthFilter(
				environment,
				sso2Cli,
				new SsoAuthorizer(sso2Cli,
						context -> (context.equals("CUSTOMER_LAND_LINK") && configuration.getVariant() != null ? configuration.getVariant().toUpperCase()
								: context)));

	}

	protected Jdbi jdbi(final CustomerLandLinkConfiguration configuration, final Environment environment) {
		final JdbiFactory factory = new JdbiFactory();
		final Jdbi jdbi = factory.build(environment, configuration.getDatabase(), APP_NAME);

		jdbi.configure(AbacoJdbiConfig.class, cfg -> cfg.setTablesPrefix(APP_PREFIX));
		String driverClassName = Optional.ofNullable(configuration.getDatabase().getDriverClass()).orElse("");
		if (driverClassName.equalsIgnoreCase("org.postgresql.Driver")) {
			jdbi.installPlugin(new PgJdbiPlugin());
		} else {
			jdbi.installPlugin(new OraJdbiPlugin());
		}
		return jdbi;
	}

	protected <T> T register(T service) {
		return service;
	}

	protected void initOpenApi(JerseyEnvironment jersey) throws IOException {

		OpenAPIConfiguration oasConfig = new ClasspathOpenApiConfigurationLoader()
				.load("openapi-configuration.yaml");
		jersey.register(new OpenApiResource().openApiConfiguration(oasConfig));
	}

	private void setupCORS(CustomerLandLinkConfiguration configuration, Environment environment) {
		if (!configuration.isCors()) {
			log.info("CORS is disabled");
			return;
		}

		log.info("CORS is enabled");
		Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,DELETE");
		// Add URL mapping
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

	private void initMultiTenant(Environment environment) {
		environment.jersey().register(new MultitenantFilter("tenant"));
	}

}
