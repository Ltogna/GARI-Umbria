package com.abacogroup.cllapi.resources.pub;

import com.abacogroup.cllapi.core.TitleTypeService;
import com.abacogroup.cllapi.exceptions.TitleTypeException;
import com.abacogroup.cllapi.exceptions.TitleTypeException.ErrEnum;
import com.abacogroup.cllapi.resources.pub.mapper.TitleTypePublicMapper;
import com.abacogroup.cllcli.api.v1.TitleTypeReponseV1;
import com.abacogroup.cllcli.resources.PublicResourceConstants;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@Path(PublicResourceConstants.API_V1_PUB + "/title-types")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Title Types", description = "Operations on Title Types")
@Tag(name = "Public APIs", description = "All public APIs")
public class TitleTypePublicResource {

	private final TitleTypeService titleTypeService;

	public TitleTypePublicResource(TitleTypeService titleTypeService) {
		this.titleTypeService = titleTypeService;
	}

	@GET
//	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Operation(description = "Get the list of all title types", summary = "get all title types")
	@ApiResponse(responseCode = "200", description = "Get the list of title types", useReturnTypeSchema = true)
	public List<TitleTypeReponseV1> searchTitleTypes(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId) {

		return TitleTypePublicMapper.INSTANCE.toResponseV1List(
				titleTypeService.searchAll(new ReqContext(user, lang)));
	}

	@GET
	@Path("/{titleTypeId}")
//	@RolesAllowed({ "CUSTOMER_LAND_LINK|READ", "CUSTOMER_LAND_LINK|WRITE" })
	@Operation(description = "Get title type by id", summary = "get title type")
	@ApiResponse(responseCode = "200", description = "title type found", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "title type not found", content = @Content(mediaType = MediaType.APPLICATION_JSON,
			schema = @Schema(implementation = TitleTypeException.ErrorBody.class)))
	public TitleTypeReponseV1 getTitleType(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "title type id") @PathParam("titleTypeId") Long titleTypeId) {

		ReqContext reqContext = new ReqContext(user, lang);
		return titleTypeService.getById(reqContext, titleTypeId)
				.map(TitleTypePublicMapper.INSTANCE::toResponseV1)
				.orElseThrow(() -> new TitleTypeException(ErrEnum.NOT_FOUND, "title type not found"));
	}

}
