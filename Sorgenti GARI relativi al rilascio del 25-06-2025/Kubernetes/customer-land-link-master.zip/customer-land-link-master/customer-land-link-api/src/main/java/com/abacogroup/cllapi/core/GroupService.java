package com.abacogroup.cllapi.core;

import com.abacogroup.cllapi.api.GroupRes;
import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.api.req.GroupCloneReq;
import com.abacogroup.cllapi.api.req.GroupCreateReq;
import com.abacogroup.cllapi.api.req.GroupSearchReq;
import com.abacogroup.cllapi.api.req.GroupUpdateReq;
import com.abacogroup.cllapi.api.req.LandLinkBatchCreateReq;
import com.abacogroup.cllapi.db.ntt.GroupEntity;
import com.abacogroup.cllapi.db.ntt.GroupEntityExtended;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface GroupService {

	Optional<GroupEntity> loadById(ReqContext reqContext, Long id);

	Optional<GroupEntityExtended> loadExtended(ReqContext reqContext, Long partyId, Long id);

	GroupRes getRes(ReqContext reqContext, Long partyId, Long groupId);

	InfiniteListResults<LandLinkRes> searchGroupLandLinks(ReqContext reqContext, Long partyId, Long groupId, String nextKey);
	List<LandLinkRes> searchGroupLandLinks(ReqContext reqContext, Long partyId, Long groupId); 

	GroupRes insert(ReqContext reqContext, Long partyId, GroupCreateReq createReq);

	GroupRes clone(ReqContext reqContext, Long partyId, Long groupId, GroupCloneReq cloneReq);

	GroupRes update(ReqContext reqContext, Long partyId, Long groupId, GroupUpdateReq req);

	GroupRes addLandLinks(ReqContext reqContext, Long partyId, Long groupId, List<LandLinkBatchCreateReq> createReq);

	GroupRes close(ReqContext reqContext, Long partyId, Long groupId, AbsoluteDate dayTo);
	
	void deleteLandLinkByGroupIdAndParcelId(ReqContext reqContext, Long partyId, Long groupId, Long parcelId);    
	
	void closeMany(ReqContext reqContext, Long partyId, Collection<Long> groupIds, AbsoluteDate dayTo);

	void expire(ReqContext reqContext, Long partyId, Long groupId);

	InfiniteListResults<GroupRes> search(ReqContext reqContext, AbsoluteDate referenceDate, Long partyId, GroupSearchReq searchRequest, String nextKey);

	List<GroupEntity> getDuplicates(ReqContext reqContext, Long partyId, String descr);

	Long countDuplicates(ReqContext reqContext, Long partyId, Long groupId, String descr);
}
