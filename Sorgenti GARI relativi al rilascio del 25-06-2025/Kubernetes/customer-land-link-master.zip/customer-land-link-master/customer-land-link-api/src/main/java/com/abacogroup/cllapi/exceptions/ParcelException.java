package com.abacogroup.cllapi.exceptions;

import com.abacogroup.common.exceptions.AbstractAppException;
import io.swagger.v3.oas.annotations.media.Schema;

public class ParcelException extends AbstractAppException {

	public ParcelException(ErrEnum code, String message) {
		super(new ErrorBody(code.name(), message));
	}

	public enum ErrEnum {
		PARTY_NOT_FOUND,
		PARCEL_NOT_FOUND

	}

	@Schema(name = "ParcelExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { "PARTY_NOT_FOUND" })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}
}
