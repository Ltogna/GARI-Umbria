package com.abacogroup.common.resources;

public interface ResourceConstants {

	int PAGE_SIZE = 10;

	String API_PRIV = "/{tenant}/api-priv/v1";
}
