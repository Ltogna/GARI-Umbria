package com.abacogroup.cllapi.core.impl;

import static com.abacogroup.cllapi.exceptions.InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_FILE_NOT_FOUND;
import static com.abacogroup.cllapi.exceptions.InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_NOT_FOUND;

import com.abacogroup.cllapi.api.GroupDocumentRes;
import com.abacogroup.cllapi.api.req.GroupDocumentSearchReq;
import com.abacogroup.cllapi.core.GroupDocumentService;
import com.abacogroup.cllapi.core.GroupService;
import com.abacogroup.cllapi.core.LandLinkEventProducer;
import com.abacogroup.cllapi.core.dto.CllEventType;
import com.abacogroup.cllapi.core.embededqueue.EventPublisher;
import com.abacogroup.cllapi.db.dao.GroupDocumentDAO;
import com.abacogroup.cllapi.db.ntt.GroupDocumentEntity;
import com.abacogroup.cllapi.db.ntt.GroupEntity;
import com.abacogroup.cllapi.db.ntt.GroupEntityExtended;
import com.abacogroup.cllapi.exceptions.GroupException;
import com.abacogroup.cllapi.exceptions.GroupException.ErrEnum;
import com.abacogroup.cllapi.resources.mapper.DocumentMapper;
import com.abacogroup.cllapi.exceptions.InvalidDocumentException;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.common.service.AuditHelper;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.dynamicdocuments.bean.documentdefinition.fieldset.field.FieldType;
import com.abacogroup.dynamicdocuments.exceptions.UnknownDocumentException;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import java.time.Clock;
import java.time.OffsetDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Stream;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class GroupDocumentServiceImpl implements GroupDocumentService {

	private final GroupService groupService;

	//	private final DocTypeService docTypeService;
	private final GroupDocumentDAO dao;
	private final DocumentService documentService;
	private final DocumentTypeService documentTypeService;
	private final FileStoreProxyClient fileStoreProxyClient;
	private final String dynamicDocumentsBucket;
	private final LandLinkEventProducer landLinkEventProducer;
	private final EventPublisher anomalyQueue;

	private final Clock appClock;

	public GroupDocumentServiceImpl(GroupService groupService, GroupDocumentDAO dao, DocumentService documentService, DocumentTypeService documentTypeService,
			FileStoreProxyClient fileStoreProxyClient, String dynamicDocumentsBucket, LandLinkEventProducer landLinkEventProducer, EventPublisher anomalyQueue,
			Clock appClock) {
		this.groupService = groupService;
		this.dao = dao;
		this.documentService = documentService;
		this.documentTypeService = documentTypeService;
		this.fileStoreProxyClient = fileStoreProxyClient;
		this.dynamicDocumentsBucket = dynamicDocumentsBucket;
		this.landLinkEventProducer = landLinkEventProducer;
		this.anomalyQueue = anomalyQueue;
		this.appClock = appClock;
	}

	@Override
	public GroupDocumentRes insert(ReqContext reqContext, Long partyId, Long groupId, InsertDocument document) {

		if (StringUtils.isBlank(document.getDefCode())) {
			throw new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR, "missing defCode");
		}

		GroupEntityExtended groupEntity = loadGroup(reqContext, partyId, groupId);
		document.setBusinessId(groupEntity.getId());

		String definitionCode = document.getDefCode();
		DocumentDefinition definition = this.documentTypeService.getDocumentDefinition(reqContext.getTenantId(), definitionCode)
				.orElseThrow(() -> new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR, "invalid defCode"));

		//		if (docTypeService.getByGroupId(reqContext, groupId)
		//				.stream()
		//				.map(DocTypeRelationRes::getDefinitionCode).noneMatch(x -> x.equalsIgnoreCase(definitionCode))) {
		//			throw new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR, "invalid defCode for group");
		//		}

		int maxOccurs = 0;
		if (null != definition.getMetadata()) {
			maxOccurs = Optional.ofNullable(definition.getMetadata().getMaxOccurs()).orElse(0);
		}
		if (maxOccurs <= this.countDocumentsByGroupIdAndDefinitionCode(reqContext, groupId, definitionCode)) {
			throw new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR, "over maxOccurs");
		}

		Long documentId = dao.inTransaction(handle -> {
			Long id = store(reqContext, document.getDoc(), document.getDefCode(), reqContext.getUser().getUserId(),
					document.getBusinessId(), document.getLabel());

			GroupDocumentEntity entity = new GroupDocumentEntity();
			entity.setGroupId(groupEntity.getId());
			entity.setDefinitionCode(document.getDefCode());
			entity.setDocumentId(id);
			AuditHelper.setAuditForInsert(entity, reqContext.getUsername(), dao);
			this.dao.insert(entity);

			landLinkEventProducer.pushGroupEvent(List.of(groupEntity.getId()), groupEntity.getPartyId(),
					reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), CllEventType.UPDATE_GROUP_DOCS);

			anomalyQueue.pushGroupEvent(List.of(groupEntity.getId()), groupEntity.getDayFrom(), groupEntity.getPartyId(),
					reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
					CllEventType.UPDATE_GROUP_DOCS);
			return id;
		});

		return getGroupDocument(reqContext, groupEntity, documentId);
	}

	private Long store(ReqContext reqContext, Document document, String definitionCode, String userID, Long groupId,
			String label) {
		//TODO validate DD dates against group dates
		document.setValidFrom(Optional.ofNullable(document.getValidFrom()).orElse(OffsetDateTime.now()));
		document.setValidTo(Optional.ofNullable(document.getValidTo())
				.orElse(AuditEntity.dateActive.atOffset(appClock.getZone().getRules().getOffset(appClock.instant()))));

		return documentService.insertDocument(reqContext.getTenantId(), definitionCode, document, userID, groupId, label);
	}

	@Override
	public void expire(ReqContext reqContext, Long partyId, Long groupId, Long documentId) {
		GroupEntityExtended groupEntity = loadGroup(reqContext, partyId, groupId);
		GroupDocumentEntity entity = dao.findByDocumentIdAndGroupId(reqContext.getTenantId(), documentId, groupEntity.getId())
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Group Document not found"));

		Document doc = Optional.of(documentService.getDocumentFromId(documentId))
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Document not found"));

		doc.setValidTo(OffsetDateTime.now(appClock));
		dao.useTransaction(handle -> {
			documentService.updateDocument(documentId, doc, reqContext.getUser().getUserId());
			Consumer<GroupDocumentEntity> expire = handle::expireRow;
			AuditHelper.expire(entity, reqContext.getUsername(), expire, handle.getCurrentTimestamp());

			landLinkEventProducer.pushGroupEvent(List.of(groupEntity.getId()), groupEntity.getPartyId(),
					reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), CllEventType.UPDATE_GROUP_DOCS);

			anomalyQueue.pushGroupEvent(List.of(groupEntity.getId()), groupEntity.getDayFrom(), groupEntity.getPartyId(),
					reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
					CllEventType.UPDATE_GROUP_DOCS);
		});
	}

	@Override
	public GroupDocumentRes update(ReqContext reqContext, Long partyId, Long groupId, Long documentId, Document updateReq) {
		GroupEntityExtended groupEntity = loadGroup(reqContext, partyId, groupId);
		GroupDocumentEntity entity = dao.findByDocumentIdAndGroupId(reqContext.getTenantId(), documentId, groupEntity.getId())
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Group Document not found"));

		Document doc = Optional.of(documentService.getDocumentFromId(documentId))
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Document not found"));
		//TODO validate DD dates against group dates
		doc.setValidFrom(Optional.ofNullable(updateReq.getValidFrom()).orElse(doc.getValidFrom()));
		doc.setValidTo(Optional.ofNullable(updateReq.getValidTo()).orElse(doc.getValidTo()));
		doc.setFields(Optional.ofNullable(updateReq.getFields()).orElse(doc.getFields()));
		entity.setGroupId(groupEntity.getId());
		entity.setDocumentId(documentId);

		updateDocument(reqContext, documentId, entity, doc, groupEntity);

		return getGroupDocument(reqContext, groupEntity, documentId);
	}

	private Long updateDocument(ReqContext reqContext, Long documentId, GroupDocumentEntity entity, Document doc, GroupEntityExtended group) {
		return dao.inTransaction(handle -> {
			documentService.updateDocument(documentId, doc, reqContext.getUser().getUserId());
			Consumer<GroupDocumentEntity> expire = handle::expireRow;
			Function<GroupDocumentEntity, Long> insert = handle::insert;

			Long updatedGroupDocId = AuditHelper.update(entity, reqContext.getUsername(), expire, insert, handle.getCurrentTimestamp());
			landLinkEventProducer.pushGroupEvent(List.of(group.getId()), group.getPartyId(),
					reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(), CllEventType.UPDATE_GROUP_DOCS);

			anomalyQueue.pushGroupEvent(List.of(group.getId()), group.getDayFrom(), group.getPartyId(),
					reqContext.getTenantId(), reqContext.getUsername(), reqContext.getLang(),
					CllEventType.UPDATE_GROUP_DOCS);

			return updatedGroupDocId;
		});
	}

	@Override
	public GroupDocumentRes getGroupDocument(ReqContext reqContext, Long partyId, Long groupId, Long documentId) {
		GroupEntity groupEntity = loadGroup(reqContext, partyId, groupId);

		return getGroupDocument(reqContext, groupEntity, documentId);
	}

	public GroupDocumentRes getGroupDocument(ReqContext reqContext, GroupEntity groupEntity, Long documentId) {
		return dao.getByDocumentIdAndGroupId(documentId, groupEntity.getId(), reqContext)
				.map(groupDocument -> DocumentMapper.addData(groupDocument, documentService, dynamicDocumentsBucket))
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, "Document not found"));
	}

	@Override
	public InfiniteListResults<GroupDocumentRes> search(ReqContext reqContext, Long partyId, Long groupId, GroupDocumentSearchReq searchReq, String nextKey) {
		GroupEntity groupEntity = loadGroup(reqContext, partyId, groupId);

		Criteria criteria = searchReq.getCriteria(reqContext);
		OrderBy orderBy = searchReq.getSort();

		return dao.infinite(() -> dao.search(groupEntity.getId(), criteria, orderBy, reqContext), nextKey, searchReq.getPageSize())
				.map(pd -> DocumentMapper.addSummaryFields(reqContext, pd, documentTypeService, documentService, dynamicDocumentsBucket));
	}

	@Override
	public Long countDocumentsByGroupIdAndDefinitionCode(ReqContext reqContext, Long groupId, String code) {
		return dao.countByDefinitionCodeAndGroupId(reqContext.getTenantId(), code, groupId);
	}

	@Override
	public Response getDocumentFileContent(ReqContext reqContext, Long partyId, Long groupId, Long documentId, String fileId) {
		this.validateCanReadFile(reqContext, partyId, groupId, documentId, fileId);

		return fileStoreProxyClient.getFileContent(reqContext.getLang(), reqContext.getUser(), dynamicDocumentsBucket, fileId);
	}

	@Override
	public Response getDocumentFileMetadata(ReqContext reqContext, Long partyId, Long groupId, Long documentId, String fileId) {
		this.validateCanReadFile(reqContext, partyId, groupId, documentId, fileId);

		return fileStoreProxyClient.getFileMetadata(reqContext.getLang(), reqContext.getUser(), dynamicDocumentsBucket, fileId);
	}

	private void validateCanReadFile(ReqContext reqContext, Long partyId, Long groupId, Long documentId, String fileId) {
		GroupEntity groupEntity = loadGroup(reqContext, partyId, groupId);

		GroupDocumentEntity groupDocumentEntity = dao.findByDocumentIdAndGroupId(reqContext.getTenantId(), documentId, groupEntity.getId())
				.orElseThrow(() -> new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND,
						String.format("Document  %s not found", documentId)));

		Document document;
		try {
			document = documentService.getDocumentFromId(groupDocumentEntity.getDocumentId());
		} catch (UnknownDocumentException ude) {
			throw new InvalidDocumentException(DYNAMIC_DOCUMENT_NOT_FOUND, ude.getMessage());
		}
		DocumentDefinition definition = documentTypeService.getDocumentDefinition(reqContext.getTenantId(), groupDocumentEntity.getDefinitionCode())
				.orElseThrow(() -> new InvalidDocumentException(InvalidDocumentException.ErrEnum.DYNAMIC_DOCUMENT_ERR,
						String.format("error loading definition for %s", groupDocumentEntity.getDefinitionCode())));

		boolean containsFileId = definition.getFieldSets().stream()
				.flatMap(fieldSet -> fieldSet.getFields().stream())
				.filter(field -> FieldType.FILE.equals(field.getType()))
				.map(field -> document.getFields().get(field.getCode()))
				.filter(Objects::nonNull)
				.flatMap(fieldValue -> fieldValue instanceof Collection ? ((Collection<?>) fieldValue).stream() : Stream.of(fieldValue))
				.anyMatch(fileId::equals);

		if (!containsFileId) {
			throw new InvalidDocumentException(DYNAMIC_DOCUMENT_FILE_NOT_FOUND,
					String.format("document '%s' of group '%s' does not contain file with id '%s'",
							documentId, groupEntity.getId(), fileId));
		}
	}

	private GroupEntityExtended loadGroup(ReqContext reqContext, Long partyId, Long groupId) {
		return groupService.loadExtended(reqContext, partyId, groupId)
				.orElseThrow(() -> new GroupException(ErrEnum.NOT_FOUND, String.format("group %s not found", groupId)));
	}

}

