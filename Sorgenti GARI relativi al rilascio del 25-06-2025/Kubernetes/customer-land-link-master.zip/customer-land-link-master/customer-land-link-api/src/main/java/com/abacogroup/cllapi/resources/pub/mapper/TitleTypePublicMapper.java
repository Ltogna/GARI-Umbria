package com.abacogroup.cllapi.resources.pub.mapper;

import com.abacogroup.cllapi.api.TitleType;
import com.abacogroup.cllcli.api.v1.TitleTypeReponseV1;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TitleTypePublicMapper {

	TitleTypePublicMapper INSTANCE = Mappers.getMapper(TitleTypePublicMapper.class);

	TitleTypeReponseV1 toResponseV1(TitleType res);

	List<TitleTypeReponseV1> toResponseV1List(List<TitleType> resList);

}
