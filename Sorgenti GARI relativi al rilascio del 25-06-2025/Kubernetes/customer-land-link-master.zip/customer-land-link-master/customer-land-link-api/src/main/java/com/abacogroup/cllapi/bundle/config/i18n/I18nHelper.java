package com.abacogroup.cllapi.bundle.config.i18n;

import com.abacogroup.cllapi.db.dao.I18nDAO;
import com.abacogroup.cllapi.db.ntt.I18nEntity;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class I18nHelper {

	private final I18nDAO i18nDAO;

	public I18nHelper(I18nDAO i18nDAO) {
		this.i18nDAO = i18nDAO;
	}

	public void upsert(String tenantId, String tableName, String fieldName, I18nAware holder) {
		I18nEntity[] records = holder.getI18n()
				.stream()
				.map(i18NEntry -> I18nEntity.builder()
						.setTenantId(tenantId)
						.setFieldName(fieldName)
						.setTableName(tableName)
						.setI18nValue(holder.getI18nCode())
						.setLang(i18NEntry.getLang())
						.setI18nText(i18NEntry.getCode())
						.build()).collect(Collectors.toSet())
				.toArray(I18nEntity[]::new);

		if (records.length > 0) {
			log.info("updating {} labels for tenant {} and table {}", records.length, tenantId, tableName);
			i18nDAO.deleteBatch(records);
			i18nDAO.insert(records);
		} else {
			//	log.info("no labels found for tenant {} and table {}", tenantId, tableName);
		}
	}

	public void upsert(String tenantId, String tableName, String fieldName, List<? extends I18nAware> list) {

		List<I18nEntity> entities = new ArrayList<>();
		list.forEach(holder -> entities.addAll(holder.getI18n()
				.stream()
				.map(i18NEntry -> I18nEntity.builder()
						.setTenantId(tenantId)
						.setFieldName(fieldName)
						.setTableName(tableName)
						.setI18nValue(holder.getI18nCode())
						.setLang(i18NEntry.getLang())
						.setI18nText(i18NEntry.getCode())
						.build())
				.collect(Collectors.toSet())));

		//pulisce le entry mantenendo, a parità di KEY, l'ultimo valore
		I18nEntity[] records = entities
				.stream()
				.collect(Collectors.groupingBy(e -> buildKey.apply(e),
						Collectors.reducing(new I18nEntity(), (item1, item2) -> item2)
				))
				.values()
				.toArray(I18nEntity[]::new);

		if (records.length > 0) {
			log.info("updating {} labels for tenant {} and table {}", records.length, tenantId, tableName);
			i18nDAO.deleteBatch(records);
			i18nDAO.insert(records);
		} else {
			//	log.info("no labels found for tenant {} and table {}", tenantId, tableName);
		}
	}

	/**
	 * costruisce la key di un oggetto I18nEntity
	 * <p>
	 * la key comprende tutto tranne i18nText (la vera e propria traduzione)
	 */
	private Function<I18nEntity, String> buildKey = (s) -> String.format("%s_%s_%s_%s_%s",
			s.getTenantId(),
			s.getTableName(),
			s.getFieldName(),
			s.getI18nValue(),
			s.getLang());

}
