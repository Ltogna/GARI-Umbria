package com.abacogroup.cllapi.core.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections4.ListUtils;

import com.abacogroup.cllapi.core.PartyClientService;
import com.abacogroup.cllapi.core.client.ClientHelper;
import com.abacogroup.cllapi.resources.mapper.PartyMapper;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import com.abacogroup.partyregistry.api.v1.req.PartyByIdInSearchRequestV1;

import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PartyClientServiceImpl implements PartyClientService {

	private static final String PATH_PARAM_TENANT = "tenant";
	private static final String PATH_PARAM_CODE = "code";
	
	private static final String QUERY_PARAM_WITH_MANAGE = "withManage";
	
	private final ClientHelper clientHelper;
	
	public PartyClientServiceImpl(WebTarget target) {
		this.clientHelper = new ClientHelper(target);
	}

	@Override
	public Optional<PartyResponseV1> getById(ReqContext context, Long id) {

		List<PartyResponseV1> party = this.getByIds(context, Arrays.asList(id));
		
		if(party == null || party.size() != 1) {
			log.error("cannot fetch party with id '{}'", id);
			return Optional.empty();
		}
		
		return Optional.ofNullable(party.get(0));
		
	}

	@Override
	public List<PartyResponseV1> getByIds(ReqContext context, List<Long> ids) {
		
		final String getPartyByIds = "{tenant}/public/v1/parties";
		
		Map<String, Object> pathVariables = Map.of(
				PATH_PARAM_TENANT, context.getTenantId()
		);
		
		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		queryParams.add(QUERY_PARAM_WITH_MANAGE, -1);
		
		PartyByIdInSearchRequestV1 payload = new PartyByIdInSearchRequestV1();
		payload.setIds(ids);
		
		
		List<PartyResponseV1> parties = ListUtils.partition(ids, 100).stream()
				.map(partyIdsChunk -> Map.of("ids", partyIdsChunk))
				.map(requestBody -> 
						clientHelper.<List<PartyResponseV1>>post(getPartyByIds, context, pathVariables, queryParams, requestBody, 
								new GenericType<>() { }
						)
					)
				.flatMap(Collection::stream)
				.map(PartyMapper.INSTANCE::toFilteredDataPartyRes)
				.collect(Collectors.toList());
		
		if(parties == null || parties.size() != ids.size()) {
			log.error("cannot fetch party with ids '{}': {}", ids);
			return new ArrayList<>();
		}
		
		return parties;
	}

	@Override
	public Optional<PartyResponseV1> getByCode(ReqContext context, String code) {
		
		final String getPartyBycode = "{tenant}/public/v1/parties/code/{code}";

		Map<String, Object> pathVariables = Map.of(
				PATH_PARAM_TENANT, context.getTenantId(),
				PATH_PARAM_CODE, code
		);
		
		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		queryParams.add(QUERY_PARAM_WITH_MANAGE, -1);
		
		
		PartyResponseV1 party = PartyMapper.INSTANCE.toFilteredDataPartyRes(
				  clientHelper.get(getPartyBycode, context, pathVariables, queryParams, new GenericType<>() { })
				);
		
		if(party == null) {
			log.error("cannot fetch party with code '{}'", code);
			return Optional.empty();
		}
		
		return Optional.ofNullable(party);
		
	}

	public static PartyResponseV1 partyClientFallback(Long id) {
		PartyResponseV1 partyResponseV1 = new PartyResponseV1();
		partyResponseV1.setId(id);
		partyResponseV1.setCode("-");
		partyResponseV1.setFirstName("");
		partyResponseV1.setLastName("");		
		return partyResponseV1;
	}
}
