package com.abacogroup.cllapi.api.req;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class GroupCloseReq {

	@NotNull
	private AbsoluteDate dayTo;
}
