#!/bin/sh

umask 0002 && \
java -jar original-${project.build.finalName}.jar server config.yml
