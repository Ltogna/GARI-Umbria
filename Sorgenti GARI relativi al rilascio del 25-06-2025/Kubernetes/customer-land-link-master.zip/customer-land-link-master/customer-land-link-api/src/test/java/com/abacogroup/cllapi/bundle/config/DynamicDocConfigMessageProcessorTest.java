package com.abacogroup.cllapi.bundle.config;

import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.db.dao.DocTypeRelationDAO;
import com.abacogroup.cllapi.db.dao.I18nDAO;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class DynamicDocConfigMessageProcessorTest extends JdbiTest {

	public static final String BUNDLE_PATH = "src/test/resources/com/abacogroup/cllapi/bundle/config/DynamicDocConfigMessageProcessorTest/dynamic_documents";
	private static final String TENANT_ID = String.format("%s_t", DynamicDocConfigMessageProcessorTest.class.getSimpleName());
	private static final String CURRENT_USER = String.format("%s_u", DynamicDocConfigMessageProcessorTest.class.getSimpleName());
	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", TENANT_ID,
			"user_id", CURRENT_USER
	);
	private final DynamicDocConfigMessageProcessor processor = getService(DynamicDocConfigMessageProcessor.class);
	private final I18nDAO dao = getJdbi().onDemand(I18nDAO.class);

	@Test
	void onMessage() {

		ConfigDataMessage msg = new ConfigDataMessage();
		List<Path> paths = FileSupport.listFilesRecursive(Path.of(BUNDLE_PATH));

		msg.setConfigFiles(paths);
		msg.setTenantId(TENANT_ID);

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			DocTypeRelationDAO docTypeRelationDAO = handle.attach(DocTypeRelationDAO.class);
			assertThat(docTypeRelationDAO.count(TENANT_ID)).isEqualTo(0L);

			processor.onMessage(msg);

			assertThat(docTypeRelationDAO.count(TENANT_ID)).isEqualTo(3L);

			String label = this.dao.searchLabel(TENANT_ID, "cll_doc_type_relations", "definition_code", "DEF_1", "en");
			assertThat(label).isEqualTo("def_one");

			handle.rollback();
		});

	}
}
