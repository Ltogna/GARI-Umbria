package com.abacogroup.cllapi.db.dao;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.db.ntt.TitleTypeEntity;
import com.abacogroup.cllapi.db.ntt.TitleTypeEntity.TitleTypeEntityBuilder;
import com.abacogroup.common.service.AuditHelper;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;

@ExtendWith(DropwizardExtensionsSupport.class)
class TitleTypeDAOTest extends JdbiTest {

	private static final String TENANT_ID = String.format("%s_t", TitleTypeDAOTest.class.getSimpleName());
	private static final String USER_ID = String.format("%s_u", TitleTypeDAOTest.class.getSimpleName());
	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", TENANT_ID,
			"user_id", USER_ID
	);

	private final TitleTypeDAO dao = getDAO(TitleTypeDAO.class);

	@Test
	void test_findById() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long id = -101L;

			Optional<TitleTypeEntity> result = dao.findById(TENANT_ID, id);
			assertThat(result).isPresent();
			assertThat(result.get().getTenantId()).isEqualTo(TENANT_ID);
			assertThat(result.get().getId()).isEqualTo(id);
			assertThat(result.get().getCode()).isEqualTo("RENT");

			handle.rollback();
		});

	}

	@Test
	void test_findAll() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<TitleTypeEntity> results = dao.findAll(TENANT_ID);
			assertThat(results).hasSize(3);
			assertThat(results).extracting(TitleTypeEntity::getCode).containsExactlyInAnyOrder("OWNERSHIP", "RENT", "SHARECROPPING");

			handle.rollback();
		});
	}

	@Test
	void test_insert_then_expire() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			String code = "CIVIC_USE";

			TitleTypeEntity entity = TitleTypeEntity.builder()
					.setCode(code).setTenantId(TENANT_ID)
					.build();

			AuditHelper.setAuditForInsert(entity, USER_ID, dao);
			Long id = dao.insert(entity);

			Optional<TitleTypeEntity> inserted = dao.findById(TENANT_ID, id);
			assertTrue(inserted.isPresent());
			assertThat(inserted.get().getCode()).isEqualTo(code);

			AuditHelper.setAuditForExpire(USER_ID, dao, inserted.get());

			dao.expireRow(inserted.get());

			assertTrue(dao.findById(TENANT_ID, id).isEmpty());

			handle.rollback();
		});

	}

	//-----------------------------
	private static TitleTypeEntityBuilder<?, ?> titleTypeEntityBuilder(String code) {
		return TitleTypeEntity.builder()
				.setTenantId(TENANT_ID)
				.setFlDayToReq(0)
				.setFlDayToEditable(0)
				.setFlAllowFutureDayFrom(0)
				.setCode(code);
	}

}
