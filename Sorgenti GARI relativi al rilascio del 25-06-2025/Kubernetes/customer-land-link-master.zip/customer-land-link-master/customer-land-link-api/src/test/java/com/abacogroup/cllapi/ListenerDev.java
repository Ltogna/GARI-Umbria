package com.abacogroup.cllapi;

import static com.abacogroup.cllapi.core.dto.CllEventType.TOPIC_PREFIX;
import static com.abacogroup.cllapi.core.impl.CllRabbitMqPublisher.DEFAULT_EXCHANGE;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeoutException;

import org.json.JSONObject;
import org.junit.jupiter.api.Disabled;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Disabled
public class ListenerDev {

	// ----- startLister -----
	public static void main(String[] args) throws IOException, TimeoutException {
		ListenerDev listenerDevTest = new ListenerDev();
		listenerDevTest.listenEvents(listenerDevTest.createConnection());
	}

	private Connection createConnection() throws IOException, TimeoutException {
		ConnectionFactory factory = new ConnectionFactory();

		// factory.setHost(...);
		// factory.setUsername(...);
		// factory.setPassword(...);
		// factory.setVirtualHost(...);
		factory.setPort(5677);

		factory.setAutomaticRecoveryEnabled(true);

		Connection connection = factory.newConnection();

		return connection;
	}

	private void listenEvents(Connection rabbitmqConnection) throws IOException {
		Channel channel = rabbitmqConnection.createChannel();

		channel.exchangeDeclare(DEFAULT_EXCHANGE, "topic", true);
		String queueName = channel.queueDeclare().getQueue();

		channel.queueBind(queueName, DEFAULT_EXCHANGE, TOPIC_PREFIX + ".#");

		DeliverCallback deliverCallback = (consumerTag, delivery) -> {
			String message = new String(delivery.getBody(), StandardCharsets.UTF_8);
			String routingKey = delivery.getEnvelope().getRoutingKey();
			log.info(" [\uD83D\uDC07 \uD83D\uDC4C] Received message in '{}'", routingKey);
			JSONObject json = new JSONObject(message);
			System.out.println(json.toString(2));
		};
		channel.basicConsume(queueName, true, deliverCallback, consumerTag -> {
		});
	}

}
