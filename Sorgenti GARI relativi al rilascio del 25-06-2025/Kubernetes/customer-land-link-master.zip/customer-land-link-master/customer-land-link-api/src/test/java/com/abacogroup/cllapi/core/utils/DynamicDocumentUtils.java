package com.abacogroup.cllapi.core.utils;

import com.abacogroup.dynamicdocuments.bean.Document;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class DynamicDocumentUtils {

	//TODO to be improved
	@SuppressWarnings({ "all" })
	public static Map<String, Object> createDoc(Map<String, Object> item) {
		Map<String, Object> fields = new HashMap<>();
		for (Entry<String, Object> entry : item.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			fields.put(key, value);
		}
		return fields;
	}

	public static void updateField(Document doc, String key, Object value) {
		doc.getFields().put(key, value);
	}
}
