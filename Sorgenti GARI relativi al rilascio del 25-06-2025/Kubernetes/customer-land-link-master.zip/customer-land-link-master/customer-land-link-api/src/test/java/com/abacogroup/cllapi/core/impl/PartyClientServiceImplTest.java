package com.abacogroup.cllapi.core.impl;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;

import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.core.PartyClientService;
import com.abacogroup.cllapi.core.client.ClientHelper;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import com.abacogroup.testcommon.ReqContextUtils;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;

@ExtendWith(DropwizardExtensionsSupport.class)
class PartyClientServiceImplTest extends JdbiTest {

	private final PartyClientService service = getService(PartyClientServiceImpl.class);
	private ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	@Test
	void getPartyById() {

		ClientHelper clientHelper = Mockito.mock(ClientHelper.class);

		PartyResponseV1 party = new PartyResponseV1().setId(1L).setLastName("Last").setFirstName("First").setCode("myCode");
		List<PartyResponseV1> responseV1 = new ArrayList<>(1);
		responseV1.add(party);

		given(clientHelper.<List<PartyResponseV1>>post(Mockito.eq("{tenant}/public/v1/parties"), any(), any(), any(), any(), any()))
		.willReturn(responseV1);
		
		this.testSupport.injectMock(service, clientHelper);

		assertThat(service.getById(ctx.getReqContext(), 1L).isPresent());
		assertThat(service.getById(ctx.getReqContext(), 1L)).isEqualTo(Optional.of(party));

		assertThat(service.getById(ctx.getReqContext(), 2L).isEmpty());

	}
}
