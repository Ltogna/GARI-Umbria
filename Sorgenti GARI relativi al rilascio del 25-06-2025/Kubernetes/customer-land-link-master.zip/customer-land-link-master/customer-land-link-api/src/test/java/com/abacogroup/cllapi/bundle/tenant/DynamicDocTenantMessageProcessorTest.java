package com.abacogroup.cllapi.bundle.tenant;

import static com.abacogroup.bundles.Constants.ALL_TENANTS;
import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.db.dao.DocTypeRelationDAO;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class DynamicDocTenantMessageProcessorTest extends JdbiTest {

	private static final String TENANT_ID = String.format("%s_t", DynamicDocTenantMessageProcessorTest.class.getSimpleName());
	private final DynamicDocTenantMessageProcessor processor = getService(DynamicDocTenantMessageProcessor.class);

	private final TitleTypeTenantMessageProcessor titleTypeTenantMessageProcessor = getService(TitleTypeTenantMessageProcessor.class);

	@Test
	void onMessage() {

		DocTypeRelationDAO docTypeRelationDAO = getDAO(DocTypeRelationDAO.class);

		getJdbi().useHandle(handle -> {
			handle.begin();

			Long relations = docTypeRelationDAO.countAll(ALL_TENANTS);
			assertThat(relations).isGreaterThan(0);

			// insert titleTypes with new tenant
			titleTypeTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(TENANT_ID));

			processor.onMessage(new TenantMessage()
					.setTenantId(TENANT_ID));

			assertThat(docTypeRelationDAO.countAll(TENANT_ID)).isEqualTo(relations);

			handle.rollback();
		});
	}

}
