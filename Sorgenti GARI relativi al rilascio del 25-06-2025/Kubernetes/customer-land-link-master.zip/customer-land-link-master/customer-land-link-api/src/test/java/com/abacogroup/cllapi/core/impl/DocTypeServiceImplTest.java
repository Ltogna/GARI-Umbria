package com.abacogroup.cllapi.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.api.DocTypeRelationRes;
import com.abacogroup.cllapi.api.GroupDocumentDefinition;
import com.abacogroup.cllapi.api.GroupDocumentRes;
import com.abacogroup.cllapi.api.enums.DocTypeRelationScope;
import com.abacogroup.cllapi.api.req.GroupDocumentSearchReq;
import com.abacogroup.cllapi.bundle.tenant.DynamicDocTenantMessageProcessor;
import com.abacogroup.cllapi.bundle.tenant.TitleTypeTenantMessageProcessor;
import com.abacogroup.cllapi.core.DocTypeService;
import com.abacogroup.cllapi.core.GroupDocumentService;
import com.abacogroup.cllapi.core.utils.DynamicDocumentUtils;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.testcommon.ReqContextUtils;

import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;

@ExtendWith(DropwizardExtensionsSupport.class)
class DocTypeServiceImplTest extends JdbiTest {

	private final DocTypeService service = getService(DocTypeServiceImpl.class);
	private final DynamicDocTenantMessageProcessor ddProcessor = getService(DynamicDocTenantMessageProcessor.class);
	private final TitleTypeTenantMessageProcessor titleTypeProcessor = getService(TitleTypeTenantMessageProcessor.class);
	private final GroupDocumentService groupDocumentService = getService(GroupDocumentServiceImpl.class);

	private ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	@BeforeEach
	void setUp() throws AuthenticationException {
		DocumentService documentService = this.getService(DocumentService.class);
		this.injectMock(groupDocumentService, documentService);
	}

	@Test
	void test_getByGroupId() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			titleTypeProcessor.onMessage(new TenantMessage()
					.setTenantId(ctx.getTenantId()));
			ddProcessor.onMessage(new TenantMessage()
					.setTenantId(ctx.getTenantId()));

			// get titleType Id of MEZZADRIA
			String titleTypeCode = "MEZZADRIA";
			Long titleId = handle.select(
					"select id from cll_title_type "
							+ " WHERE tenant_id= ? "
							+ " and code = ?"
							+ " and (§current_timestamp§ between dt_insert and dt_delete) ",
					ctx.getTenantId(), titleTypeCode)
					.mapTo(Long.class)
					.first();
			// add group
			List<String> initScripts = List.of("add_groups");
			Map customTestMap = new HashMap<>(ctx.getTestScriptParams());
			customTestMap.put("titleId", titleId);

			execSqlFiles(this.getClass(), initScripts, customTestMap);

			Long partyId = 555L;
			Long groupId = -78L;
			DocTypeRelationScope scopeCode = DocTypeRelationScope.GROUPS;
			List<DocTypeRelationRes> docTypes = service.getByGroupIdOrLandLinkId(ctx.getReqContext(), groupId, null, scopeCode);
			Assertions.assertThat(docTypes).hasSize(1);
			Assertions.assertThat(docTypes.get(0).getFlDocPresent()).isEqualTo(0);

			// insert a Document
			String definitionCode = "DEF_3";
			Map<String, Object> doc_def3 = Map.of(
					"id_type", "farm",
					"release_agent", "Comune di Palermo",
					"release_date", "2021-12-03T00:00:00+02:00");

			Document doc = new Document();
			Map<String, Object> fields = DynamicDocumentUtils.createDoc(doc_def3);
			doc.setFields(fields);
			InsertDocument ins = new InsertDocument();
			ins.setDoc(doc);
			ins.setDefCode(definitionCode);
			ins.setBusinessId(groupId);

			// insert groupDocument
			groupDocumentService.insert(ctx.getReqContext(), partyId, groupId, ins);

			List<GroupDocumentRes> docs = groupDocumentService.search(ctx.getReqContext(),
					555L, groupId, new GroupDocumentSearchReq().setDefinitionCode(definitionCode), null)
					.getRecords();
			assertThat(docs).hasSize(1);

			// asserts
			docTypes = service.getByGroupIdOrLandLinkId(ctx.getReqContext(), groupId, null, scopeCode);
			Assertions.assertThat(docTypes).hasSize(1);
			Assertions.assertThat(docTypes.get(0).getFlDocPresent()).isEqualTo(1);
			Assertions.assertThat(docTypes.get(0).getSummaryFieldDefinitions()).isNotNull();

			handle.rollback();
		});

	}

	@Test
	void test_getByGroupId_for_group_that_has_more_than_one_docType() {

		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			titleTypeProcessor.onMessage(new TenantMessage()
					.setTenantId(ctx.getTenantId()));

			ddProcessor.onMessage(new TenantMessage()
					.setTenantId(ctx.getTenantId()));

			// get titleType Id of PROPRIETA
			String titleTypeCode = "PROPRIETA";
			Long titleId = handle.select(
					"select id from cll_title_type "
							+ " WHERE tenant_id= ? "
							+ " and code = ?"
							+ " and (§current_timestamp§ between dt_insert and dt_delete) ",
					ctx.getTenantId(), titleTypeCode)
					.mapTo(Long.class)
					.first();

			// add group
			List<String> initScripts = List.of("add_groups");
			Map customTestMap = new HashMap<>(ctx.getTestScriptParams());
			customTestMap.put("titleId", titleId);

			execSqlFiles(this.getClass(), initScripts, customTestMap);

			Long partyId = 555L;
			Long groupId = -78L;
			DocTypeRelationScope scopeCode = DocTypeRelationScope.GROUPS;
			List<DocTypeRelationRes> docTypes = service.getByGroupIdOrLandLinkId(ctx.getReqContext(), groupId, null, scopeCode);
			Assertions.assertThat(docTypes).hasSize(3)
					.extracting(DocTypeRelationRes::getDefinitionCode, DocTypeRelationRes::getFlDocPresent)
					.containsExactly(tuple("DEF_1", 0), tuple("DEF_3", 0), tuple("DEF_FILE", 0));

			// insert Document of DEF_3
			String definitionCode = "DEF_3";
			Map<String, Object> doc_def3 = Map.of(
					"id_type", "farm",
					"release_agent", "Comune di Palermo",
					"release_date", "2021-12-03T00:00:00+02:00");

			Document doc = new Document();
			Map<String, Object> fields = DynamicDocumentUtils.createDoc(doc_def3);
			doc.setFields(fields);
			InsertDocument ins = new InsertDocument();
			ins.setDoc(doc);
			ins.setDefCode(definitionCode);
			ins.setBusinessId(groupId);

			// insert groupDocument
			groupDocumentService.insert(ctx.getReqContext(), partyId, groupId, ins);

			// asserts
			List<GroupDocumentRes> docs = groupDocumentService.search(ctx.getReqContext(),
					555L, groupId, new GroupDocumentSearchReq().setDefinitionCode(definitionCode), null)
					.getRecords();
			assertThat(docs).hasSize(1);

			docTypes = service.getByGroupIdOrLandLinkId(ctx.getReqContext(), groupId, null, scopeCode);
			Assertions.assertThat(docTypes).hasSize(3)
					.extracting(DocTypeRelationRes::getDefinitionCode, DocTypeRelationRes::getFlDocPresent)
					.containsExactly(tuple("DEF_1", 0), tuple("DEF_3", 1), tuple("DEF_FILE", 0));

			handle.rollback();
		});

	}

	@Test
	void test_getDefinition() {

		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			ddProcessor.onMessage(new TenantMessage()
					.setTenantId(ctx.getTenantId()));

			String definitionCode = "DEF_1";

			// test
			GroupDocumentDefinition docDef = service.getDefinition(ctx.getReqContext(), definitionCode);
			assertThat(docDef).isNotNull();

			assertThat(docDef.getCode()).isEqualTo(definitionCode);
			assertThat(docDef.getDescription()).isEqualTo("Dati1");
			assertThat(docDef.getBucketName()).isNotNull();

			handle.rollback();
		});
	}
}
