package com.abacogroup.cllapi.core.impl;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.LongStream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.cllapi.CustomerLandLinkConfiguration;
import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.core.LpisClientService;
import com.abacogroup.cllapi.core.client.ClientHelper;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.api.v1.PublicParcel;
import com.abacogroup.lpisgisserver.api.v1.PublicSector;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.SecurityContext;

@Disabled
@ExtendWith(DropwizardExtensionsSupport.class)
class LpisClientServiceImpl_IT extends JdbiTest {

	private final LpisClientService lpisClientService = getService(LpisClientServiceImpl.class);

	private ReqContext reqContext;

	@BeforeEach
	void setUp() throws AuthenticationException {
		User user = (User) buildAuthContext("master", "admin").getUserPrincipal();
		reqContext = new ReqContext(user, "it");
		this.injectMock(lpisClientService,
				new ClientHelper(getGenericWebTarget("https://iacs-dev.fe.abacogroup.eu/lpis-server-api")));
	}

	@Test
	void ddos_lpis() {
		List<PublicParcel> list = lpisClientService.searchParcels(reqContext, AbsoluteDate.of(LocalDate.now()),
				null, null, null, false, false, 10);
		list.stream().forEach(publicParcel -> {
			// System.out.println(publicParcel);
		});
		list = lpisClientService.searchParcels(reqContext, AbsoluteDate.of(LocalDate.now()),
				"AFFI (VR)", null, null, false, false, 10);
		list.stream().forEach(publicParcel -> {
			// System.out.println(publicParcel);
		});

		list = lpisClientService.searchParcels(reqContext, AbsoluteDate.of(LocalDate.now()),
				null, "1", null, false, false, 10);
		list.stream().forEach(publicParcel -> {
			// System.out.println(publicParcel);
		});

		list = lpisClientService.searchParcels(reqContext, AbsoluteDate.of(LocalDate.now()),
				null, null, "000010000100001000010000100001000010000100001000010000100001000010000100001", false, false, 10);
		list.stream().forEach(publicParcel -> {
			System.out.println(publicParcel);
		});

		Optional<PublicParcel> parcel = lpisClientService.getParcelById(reqContext, AbsoluteDate.of(LocalDate.now()), 3783502L);
		System.out.println(parcel);

		assertTrue(true);
	}

	@Test
	void test_getSectors() {
		List<PublicSector> sectors = lpisClientService.getSectors(reqContext, null);
		sectors.stream().forEach(s -> {
			System.out.println(s);
		});

		System.out.println("--------- filter : AFF");
		sectors = lpisClientService.getSectors(reqContext, "AFF");
		sectors.stream().forEach(s -> {
			System.out.println(s);
		});

		assertTrue(true);
	}

	@Test
	void test_getSectorDetail() {
		PublicSector sector = lpisClientService.getSectorDetails(reqContext, "A061");
		// sectorCode A061 - id : 8634 - descr : AFFI - A061 (VR)
		System.out.println(sector.getId());
		System.out.println(sector.getDescription());

		assertTrue(true);
	}

	// ----- getParcelById -----
	@Test
	void test_getParcelById_ok() {
		Optional<PublicParcel> parcel = lpisClientService.getParcelById(reqContext, AbsoluteDate.of(LocalDate.now()), 3783502L);

		System.out.println(parcel);

		assertTrue(true);
	}

	// ----- getParcelsByIdIn -----
	@Test
	void test_getParcelsByIdIn_ok() {
		List<Long> ids = LongStream.range(3783502L, 3783502L + 455L).boxed().collect(Collectors.toList());
		List<PublicParcel> parcels = lpisClientService.getParcelsByIdIn(reqContext, AbsoluteDate.of(LocalDate.now()), ids, null);

		System.out.printf("size req: %d, size res: %d\n", ids.size(), parcels.size());
		parcels.forEach(p -> System.out.println(p.getParcel()));

		assertTrue(true);
	}

	// ----- consumeParcelsByIdIn -----
	@Test
	void test_consumeParcelsByIdIn_ok() {
		List<Long> ids = LongStream.range(3783502L, 3783502L + 455L).boxed().collect(Collectors.toList());
		lpisClientService.consumeParcelsByIdIn(reqContext, false, AbsoluteDate.of(LocalDate.now()), ids,
				System.out::println);
		// p -> System.out.println(p.getParcel()));
		assertTrue(true);
	}

	public SecurityContext buildAuthContext(String tenant, String username) throws AuthenticationException {
		Sso2Client sso2Client = getService(Sso2Client.class);
		return sso2Client.createSecurityContextFromUserName(tenant, username);
	}

	private WebTarget initLpisTarget(CustomerLandLinkConfiguration configuration, Environment environment, ObjectMapper mapper) {
		final Client client = new JerseyClientBuilder(environment)
				.using(mapper)
				.using(configuration.getJerseyClient())
				.build("lpis-client");
		WebTarget lpis = client.target(configuration.getLpisConfig().getUrl());
		return lpis;
	}
}
