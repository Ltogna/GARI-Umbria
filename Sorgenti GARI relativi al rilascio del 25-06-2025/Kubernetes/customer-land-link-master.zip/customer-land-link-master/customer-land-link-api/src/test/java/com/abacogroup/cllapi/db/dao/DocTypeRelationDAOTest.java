package com.abacogroup.cllapi.db.dao;

import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.api.enums.DocTypeRelationScope;
import com.abacogroup.cllapi.db.ntt.DocTypeRelationEntity;
import com.abacogroup.cllapi.db.ntt.TitleTypeEntity;
import com.abacogroup.common.service.AuditHelper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class DocTypeRelationDAOTest extends JdbiTest {

	private static final String TENANT_ID = String.format("%s_t", DocTypeRelationDAOTest.class.getSimpleName());
	private static final String USER_ID = String.format("%s_u", DocTypeRelationDAOTest.class.getSimpleName());

	private final TitleTypeDAO titleTypeDAO = getDAO(TitleTypeDAO.class);
	private final DocTypeRelationDAO dao = getDAO(DocTypeRelationDAO.class);

	@Test
	void insert() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			String code = "CIVIC_USE";

			// save DdocConfigs
			TitleTypeEntity titleTypeEntity = TitleTypeEntity.builder()
					.setCode(code)
					.setTenantId(TENANT_ID)
					.build();
			AuditHelper.setAuditForInsert(titleTypeEntity, USER_ID, titleTypeDAO);
			Long titleTypeId = titleTypeDAO.insert(titleTypeEntity);

			DocTypeRelationEntity entity = DocTypeRelationEntity.builder()
					.setTenantId(TENANT_ID)
					.setTitleTypeId(titleTypeId)
					.setDefinitionCode("code1")
					.setFlRequired(0)
					.setFlReqOnAdd(1)
					.setFlReqOnClose(1)
					.setScopeCode(DocTypeRelationScope.GROUPS)
					.build();
			AuditHelper.setAuditForInsert(entity, USER_ID, dao);
			Long insertedId = dao.insert(entity);
			assertThat(insertedId).isNotNull();

			handle.rollback();
		});

	}
}
