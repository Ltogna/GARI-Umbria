package com.abacogroup.cllapi;

import java.io.IOException;
import java.lang.reflect.Field;
import java.time.Clock;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeoutException;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.Slf4JSqlLogger;
import org.mockito.Mockito;

import com.abacogroup.bundles.initializer.InitService;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.listener.RabbitListener;
import com.abacogroup.bundles.listener.configdata.ConfigDataLogProducer;
import com.abacogroup.cllapi.core.LandLinkEventProducer;
import com.abacogroup.cllapi.core.dto.CllEventType;
import com.abacogroup.cllapi.core.embededqueue.AnomalyHelper;
import com.abacogroup.cllapi.core.embededqueue.EventPublisher;
import com.abacogroup.cllapi.db.dao.LandLinkDAO;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.testcommon.ApplicationTestSupport;
import com.abacogroup.testcommon.TestApplication;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.rabbitmq.client.Connection;

import io.dropwizard.auth.AuthFilter;
import io.dropwizard.auth.PolymorphicAuthDynamicFeature;
import io.dropwizard.auth.PolymorphicAuthValueFactoryProvider;
import io.dropwizard.auth.basic.BasicCredentialAuthFilter;
import io.dropwizard.auth.chained.ChainedAuthFilter;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CustomerLandLinkTestApplication extends CustomerLandLinkApplication implements TestApplication {

	public static Jdbi jdbi;

	private ApplicationTestSupport applicationTestSupport = new ApplicationTestSupport();

	public static ObjectMapper getObjectMapper() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		// brutto, ma consente di accentrare la configurazione senza snaturare application
		new CustomerLandLinkApplication().configureObjectMapper(mapper);
		return mapper;
	}

	public static Jdbi getLol() {
		return jdbi;
	}

	@Override
	public ApplicationTestSupport getAppTestSupport() {
		return applicationTestSupport;
	}

	@Override
	public Jdbi getJdbi() {
		return jdbi;
	}

	@Override
	public void doRun(CustomerLandLinkConfiguration configuration, Environment environment) throws Exception {
		super.doRun(configuration, environment);

	}

	@Override
	protected Jdbi jdbi(CustomerLandLinkConfiguration configuration, Environment environment) {
		Jdbi jdbi = super.jdbi(configuration, environment);
		jdbi.setSqlLogger(new Slf4JSqlLogger());
		CustomerLandLinkTestApplication.jdbi = jdbi;

		applicationTestSupport.execMigrations(environment, configuration.getDatabase());
		return jdbi;
	}

	@Override
	protected <T> T register(T service) {
		if (isBetterToMock(service)) {
			if (service instanceof EventPublisher) {
				service = (T) Mockito.mock(EventPublisher.class);
			} else {
				service = (T) Mockito.mock(service.getClass());
			}
		}

		applicationTestSupport.register(service);
		return super.register(service);
	}


	@Override
	protected EventPublisher buildAnomalyQueue(CustomerLandLinkConfiguration configuration, Environment environment, Clock appClock, Jdbi jdbi,
			AnomalyHelper anomalyHelper) {
		return this.register(Mockito.mock(EventPublisher.class));
	}

	@Override
	protected ConfigDataLogProducer configDataLogProducerBean(ObjectMapper objectMapper, com.rabbitmq.client.Connection rabbitmqConnection) {
		if (!applicationTestSupport.isInitRabbit()) {
			return Mockito.mock(ConfigDataLogProducer.class);
		}
		return super.configDataLogProducerBean(objectMapper, rabbitmqConnection);
	}

	@Override
	public LandLinkEventProducer createLandLinkEventProducer(CustomerLandLinkConfiguration configuration, Environment environment, Jdbi jdbi,
			ObjectMapper objectMapper,
			Connection rabbitmqConnection, LandLinkDAO landLinkDAO, Clock appClock) throws IOException {
		return new LandLinkEventProducer() {
			@Override
			public void pushGroupEvent(Collection<Long> groupIds, Long partyId, String tenant, String username, String lang, CllEventType eventType) {
				log.info("MOCK {} event for group ids: {}", eventType, groupIds);
			}

			@Override
			public void pushGroupEvent(Collection<Long> groupIds, Long partyId, String tenant, String username, String lang, CllEventType eventType, Collection<Long> landLinkPkids) {
				log.info("MOCK {} event for group ids: {} and land link pkids: {}", eventType, groupIds, landLinkPkids);
			}

			@Override
			public void pushLandLinkEvent(Collection<Long> landLinkIds, Long partyId, String tenant, String username,
					String lang, CllEventType eventType) {
				log.info("MOCK {} event for land link ids: {}", eventType, landLinkIds);
			}
			
			@Override
			public void pushLandLinkEvent(Collection<Long> landLinkIds, Long partyId, String tenant, String username,
					String lang, CllEventType eventType, Collection<Long> landLinkPkids) {
				log.info("MOCK {} event for land link ids: {} and land link pkids: {}", eventType, landLinkIds, landLinkPkids);
			}
		};
	}

	@Override
	protected void initOpenApi(JerseyEnvironment jersey) {
		log.info("OPEN-API DISABELD");
	}

	@Override
	protected void initAuth(CustomerLandLinkConfiguration configuration, Environment environment, Sso2Client sso2Cli) {
		List<AuthFilter<?, ? extends User>> filters = new ArrayList<>();
		filters.add(new BasicCredentialAuthFilter.Builder<User>()
				.setAuthenticator(credentials -> Optional.of(new User(credentials.getUsername(), "master")))
				.setAuthorizer((principal, role, x) -> true)
				.setRealm("GUEST authenticator")
				.buildAuthFilter());

		ChainedAuthFilter usersFilter = new ChainedAuthFilter(filters);

		final PolymorphicAuthDynamicFeature<? extends User> feature = new PolymorphicAuthDynamicFeature<>(
				ImmutableMap.of(User.class, usersFilter));

		PolymorphicAuthValueFactoryProvider.Binder<? extends User> binder = new PolymorphicAuthValueFactoryProvider.Binder<>(
				ImmutableSet.of(User.class));

		environment.jersey().register(feature);
		environment.jersey().register(binder);
		// */
	}

	@Override
	protected void startRabbitConsumerAndProducers(InitService initService, RabbitListener rabbitListener) throws Exception {
		if (!applicationTestSupport.isInitRabbit()) {
			System.out.println("startup producers and consumers OFF");
		} else {
			super.startRabbitConsumerAndProducers(initService, rabbitListener);
		}
	}

	@Override
	protected void afterServicesUp() throws IOException {
		if (!applicationTestSupport.isExecMigrations()) {
			return;
		}
		applicationTestSupport.installBundle(jdbi, String.format("%s.%s", APP_NAME, "zip"));
	}

	protected static <T, M> void injectMockByField(T target, String filedName) {
		try {
			Class<T> targetClazz = (Class<T>) target.getClass();
			Field field = Arrays.stream(FieldUtils.getAllFields(targetClazz))
					.filter(f -> f.getName().equals(filedName))
					.findFirst()
					.orElseThrow();

			FieldUtils.writeField(target, field.getName(), Mockito.mock(field.getType()), true);
		} catch (IllegalAccessException ex) {
			throw new RuntimeException("errore in inject", ex);
		}
	}

	@Override
	protected com.rabbitmq.client.Connection createRabbitmqConnection(CustomerLandLinkConfiguration configuration) throws IOException, TimeoutException {
		if (applicationTestSupport.isInitRabbit()) {
			return super.createRabbitmqConnection(configuration);
		} else {
			log.info("RABBIT CONNECTION DISABLED");
			return null;
		}
	}

	private void initMultiTenant(Environment environment) {
		environment.jersey().register(new MultitenantFilter("tenant"));
	}

	private <T> boolean isBetterToMock(T service) {
		return (service instanceof ConfigDataLogProducer
				|| (service instanceof BundleInitServiceProducer) && !applicationTestSupport.isInitRabbit())
				|| service instanceof EventPublisher;
	}
}
