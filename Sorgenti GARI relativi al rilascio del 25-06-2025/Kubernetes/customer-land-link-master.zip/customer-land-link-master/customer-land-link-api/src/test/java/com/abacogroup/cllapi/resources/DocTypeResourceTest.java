package com.abacogroup.cllapi.resources;

import static com.abacogroup.cllapi.core.client.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.locationtech.jts.triangulate.ConformingDelaunayTriangulationBuilder;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import com.abacogroup.cllapi.api.DocTypeRelationRes;
import com.abacogroup.cllapi.api.DocTypeRelationRes.DocTypeRelationResBuilder;
import com.abacogroup.cllapi.api.GroupDocumentDefinition;
import com.abacogroup.cllapi.api.enums.DocTypeRelationScope;
import com.abacogroup.cllapi.core.DocTypeService;
import com.abacogroup.cllapi.core.client.WebCliHelper;
import com.abacogroup.cllapi.core.impl.DocTypeServiceImpl;
import com.abacogroup.common.resources.ReqContext;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.UriBuilder;

@ExtendWith(DropwizardExtensionsSupport.class)
class DocTypeResourceTest {

	private final DocTypeService docTypeRelationService = Mockito.mock(DocTypeServiceImpl.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new DocTypeResource(docTypeRelationService));

	@Test
	void should_search_docTypes() {
		Long groupId = 100L;
		DocTypeRelationScope scopeCode = DocTypeRelationScope.GROUPS;
		
		UriBuilder uriBuilder = UriBuilder.fromResource(DocTypeResource.class).path(DocTypeResource.class, "search");
		String uri = uriBuilder.build(TENANT).toString();

		List<DocTypeRelationRes> mockRes = (List.of(
				docTypeRelationRes("DEF_1").build(),
				docTypeRelationRes("DEF_2").build(),
				docTypeRelationRes("DEF_3").build()));

		given(docTypeRelationService.getByGroupIdOrLandLinkId(any(), eq(groupId), any(), eq(scopeCode))).willReturn(mockRes);

		List<DocTypeRelationRes> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.queryParam("groupId", groupId)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(docTypeRelationService).getByGroupIdOrLandLinkId(reqCtxCaptor.capture(), eq(groupId), any(), eq(scopeCode));

	}

	@Test
	void test_getDefinition() {
		String definitionCode = "DEF_1";

		UriBuilder uriBuilder = UriBuilder.fromResource(DocTypeResource.class).path(DocTypeResource.class, "getDefinition");

		String uri = uriBuilder.build(TENANT, definitionCode).toString();

		GroupDocumentDefinition mockRes = new GroupDocumentDefinition();
		mockRes.setBucketName("group_docs");
		mockRes.setCode(definitionCode);

		given(docTypeRelationService.getDefinition(any(), eq(definitionCode))).willReturn(mockRes);

		GroupDocumentDefinition res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(docTypeRelationService).getDefinition(reqCtxCaptor.capture(), eq(definitionCode));
	}

	private DocTypeRelationResBuilder<?, ?> docTypeRelationRes(String defCode) {
		return DocTypeRelationRes.builder()
				.setDefinitionCode(defCode)
				.setFlDocPresent(0)
				.setFlReqOnAdd(1)
				.setFlReqOnClose(0)
				.setFlRequired(1);
	}

}
