package com.abacogroup.cllapi.bundle.config;

import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.core.TitleTypeService;
import com.abacogroup.cllapi.core.impl.TitleTypeServiceImpl;
import com.abacogroup.common.resources.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class TitleTypeConfigMessageProcessorTest extends JdbiTest {

	private final TitleTypeConfigMessageProcessor processor = getService(TitleTypeConfigMessageProcessor.class);

	private final TitleTypeService titleTypeService = this.getService(TitleTypeServiceImpl.class);

	@Test
	void shouldAdd() {
		var tenant = "t";
		var ctx = new ReqContext(tenant, "u", "it");
		var message = new ConfigDataMessage()
				.setTenantId(tenant)
				.setConfigFiles(List.of(
						file2Path.apply("types.json")
				));
		getJdbi().useHandle(handle -> {
			handle.begin();
			processor.onMessage(message);

			assertThat(titleTypeService.searchAll(ctx))
					.hasSize(3);

			handle.rollback();
		});
	}

	@Test
	void shouldDelete() {
		var tenant = "t";
		var ctx = new ReqContext(tenant, "u", "it");

		var message = new ConfigDataMessage()
				.setTenantId(tenant)
				.setConfigFiles(List.of(
						file2Path.apply("delete_types.json")
				));
		getJdbi().useHandle(handle -> {
			handle.begin();

			var insertMessage = new ConfigDataMessage()
					.setTenantId(tenant)
					.setConfigFiles(List.of(
							file2Path.apply("types.json")
					));
			processor.onMessage(insertMessage);
			assertThat(titleTypeService.searchAll(ctx))
					.hasSize(3);

			processor.onMessage(message);
			assertThat(titleTypeService.searchAll(ctx))
					.hasSize(1);

			handle.rollback();
		});
	}
}
