package com.abacogroup.cllapi.resources;

import static com.abacogroup.cllapi.core.client.WebCliHelper.BASIC_USERNAME;
import static com.abacogroup.cllapi.core.client.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import com.abacogroup.cllapi.api.GroupDocumentRes;
import com.abacogroup.cllapi.api.GroupDocumentRes.GroupDocumentResBuilder;
import com.abacogroup.cllapi.api.req.GroupDocumentSearchReq;
import com.abacogroup.cllapi.core.GroupDocumentService;
import com.abacogroup.cllapi.core.client.WebCliHelper;
import com.abacogroup.cllapi.core.impl.GroupDocumentServiceImpl;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.List;
import java.util.Map;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class GroupDocumentResourceTest {

	private final GroupDocumentService groupDocumentService = Mockito.mock(GroupDocumentServiceImpl.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new GroupDocumentResource(groupDocumentService));

	@Test
	void should_search() {
		Long partyId = 555L;
		Long groupId = 100L;
		String definitionCode = "DEF_1";
		String nextKey = "11";

		GroupDocumentSearchReq searchReq = new GroupDocumentSearchReq()
				.setDefinitionCode(definitionCode);

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> queryMap = mapper.convertValue(searchReq, Map.class);

		UriBuilder uriBuilder = UriBuilder.fromResource(GroupDocumentResource.class).path(GroupDocumentResource.class, "search");
		queryMap.forEach(uriBuilder::queryParam);
		String uri = uriBuilder.build(TENANT, partyId, groupId).toString();
		System.out.println(uri);

		InfiniteListResultsImpl<GroupDocumentRes> mockRes = new InfiniteListResultsImpl<>(List.of(
				groupDocumentResBuilder(101L, groupId, definitionCode).build(),
				groupDocumentResBuilder(102L, groupId, definitionCode).build(),
				groupDocumentResBuilder(103L, groupId, definitionCode).build()), nextKey);

		given(groupDocumentService.search(any(), anyLong(), anyLong(), any(), any())).willReturn(mockRes);

		InfiniteListResultsImpl<GroupDocumentRes> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.queryParam("nextKey", nextKey)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.extracting(InfiniteListResultsImpl::getRecords)
				.isEqualTo(mockRes.getRecords());

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupDocumentService).search(reqCtxCaptor.capture(), eq(partyId), eq(groupId), eq(searchReq), eq(nextKey));
	}

	// ----- getByDocumentId -----
	@Test
	void test_getByDocumentId_ok() {
		Long partyId = 555L;
		Long groupId = 100L;
		Long documentId = 123L;

		UriBuilder uriBuilder = UriBuilder.fromResource(GroupDocumentResource.class).path(GroupDocumentResource.class, "getByDocumentId");
		String uri = uriBuilder.build(TENANT, partyId, groupId, documentId).toString();
		System.out.println(uri);

		GroupDocumentRes mockRes = groupDocumentResBuilder(101L, groupId, "DEF_TEST").build();
		given(groupDocumentService.getGroupDocument(any(), anyLong(), anyLong(), anyLong())).willReturn(mockRes);

		GroupDocumentRes res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull().isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupDocumentService).getGroupDocument(reqCtxCaptor.capture(), eq(partyId), eq(groupId), eq(documentId));
	}

	// ----- getDocumentFileContent -----
	@Test
	void test_getDocumentFileContent_ok() {
		Long partyId = 555L;
		Long groupId = 100L;
		Long documentId = 123L;
		String fileId = "theFileId";

		UriBuilder uriBuilder = UriBuilder.fromResource(GroupDocumentResource.class).path(GroupDocumentResource.class, "getDocumentFileContent");
		String uri = uriBuilder.build(TENANT, partyId, groupId, documentId, "my-bucket", fileId).toString();
		System.out.println(uri);

		Response mockRes = Response.ok("my file content".getBytes(), MediaType.TEXT_PLAIN_TYPE).build();
		given(groupDocumentService.getDocumentFileContent(any(), anyLong(), anyLong(), anyLong(), anyString())).willReturn(mockRes);

		Response res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get();

		assertThat(res).isNotNull();
		assertThat(res.readEntity(String.class)).isNotNull()
				.isEqualTo("my file content");

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupDocumentService).getDocumentFileContent(reqCtxCaptor.capture(), eq(partyId), eq(groupId), eq(documentId), eq(fileId));
	}

	// ----- getDocumentFileMetadata -----
	@Test
	void test_getDocumentFileMetadata_ok() {
		Long partyId = 555L;
		Long groupId = 100L;
		Long documentId = 123L;
		String fileId = "theFileId";

		UriBuilder uriBuilder = UriBuilder.fromResource(GroupDocumentResource.class).path(GroupDocumentResource.class, "getDocumentFileMetadata");
		String uri = uriBuilder.build(TENANT, partyId, groupId, documentId, "my-bucket", fileId).toString();
		System.out.println(uri);

		Response mockRes = Response.ok("my file content".getBytes(), MediaType.TEXT_PLAIN_TYPE)
				.header("hKey", "hValue").build();
		given(groupDocumentService.getDocumentFileMetadata(any(), anyLong(), anyLong(), anyLong(), anyString())).willReturn(mockRes);

		Response res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.head();

		assertThat(res).isNotNull();
		assertThat(res.getHeaderString("Content-type")).isNotNull()
				.isEqualTo(MediaType.TEXT_PLAIN_TYPE.toString());
		assertThat(res.getHeaderString("hKey")).isNotNull()
				.isEqualTo("hValue");

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupDocumentService).getDocumentFileMetadata(reqCtxCaptor.capture(), eq(partyId), eq(groupId), eq(documentId), eq(fileId));
	}

	@Test
	void test_add_doc_ok() {
		Long partyId = 555L;
		Long groupId = 100L;
		String definitionCode = "DEF_1";

		String uri = UriBuilder.fromResource(GroupDocumentResource.class)
				.build(TENANT, partyId, groupId).toString();
		System.out.println(uri);

		GroupDocumentRes mockRes = groupDocumentResBuilder(100L, groupId, definitionCode).build();
		given(groupDocumentService.insert(any(), anyLong(), anyLong(), any())).willReturn(mockRes);
		InsertDocument doc = new InsertDocument();
		doc.setDefCode(definitionCode);
		doc.setBusinessId(groupId);

		GroupDocumentRes res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.post(Entity.json(doc), new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupDocumentService).insert(reqCtxCaptor.capture(), eq(partyId), eq(groupId), eq(doc));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	@Test
	void test_update_doc_ok() {
		Long partyId = 555L;
		Long groupId = 100L;
		Long docId = 1L;
		String definitionCode = "DEF_1";

		String uri = UriBuilder.fromResource(GroupDocumentResource.class).path(GroupDocumentResource.class, "update")
				.build(TENANT, partyId, groupId, docId).toString();

		GroupDocumentRes mockRes = groupDocumentResBuilder(docId, groupId, definitionCode).build();
		given(groupDocumentService.update(any(), anyLong(), anyLong(), anyLong(), any())).willReturn(mockRes);

		Document req = new Document();

		GroupDocumentRes res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.put(Entity.json(req), new GenericType<>() {
				});

		assertThat(res).isNotNull().isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupDocumentService).update(reqCtxCaptor.capture(), eq(partyId), eq(groupId), eq(docId), eq(req));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	@Test
	void test_delete_doc_ok() {
		Long partyId = 555L;
		Long groupId = 100L;
		Long docId = 1L;

		String uri = UriBuilder.fromResource(GroupDocumentResource.class).path(GroupDocumentResource.class, "delete")
				.build(TENANT, partyId, groupId, docId).toString();
		System.out.println(uri);

		Response res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.delete(new GenericType<>() {
				});

		assertThat(res).isNotNull();
		assertThat(res.getStatus()).isEqualTo(200);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupDocumentService).expire(reqCtxCaptor.capture(), eq(partyId), eq(groupId), eq(docId));
		ReqContext reqContext = reqCtxCaptor.getValue();
		System.out.println(reqContext);
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	private GroupDocumentResBuilder<?, ?> groupDocumentResBuilder(Long docId, Long groupId, String defCode) {
		return GroupDocumentRes.builder()
				.setGroupId(groupId)
				.setDefinitionCode(defCode)
				.setDocumentId(docId);
	}

}
