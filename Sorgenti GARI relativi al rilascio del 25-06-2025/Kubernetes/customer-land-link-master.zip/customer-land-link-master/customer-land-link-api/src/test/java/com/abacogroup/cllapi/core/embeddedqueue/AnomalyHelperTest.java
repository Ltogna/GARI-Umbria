package com.abacogroup.cllapi.core.embeddedqueue;

import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.DD_ANOMALY_ATTO;
import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.GROUP_CLL_ENTITY_CODE;
import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.LL_ANOMALY_P55;
import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.LL_ANOMALY_P55_6;
import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.PARCEL_ENTITY_CODE;
import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.PARTY_CLL_ENTITY_CODE;
import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.PARTY_PARCEL_ENTITY_CODE;
import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.getGroupDD;
import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.getGroupLL;
import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.partyParcelEntityId;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

import com.abacogroup.anomalyregistry.api.v1.req.AnomalyRequest;
import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyClient;
import com.abacogroup.anomalyregistry.core.cli.v1.impl.AnomalyClientImpl;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.api.GroupDocumentRes;
import com.abacogroup.cllapi.api.LandLinkLeadingRes;
import com.abacogroup.cllapi.api.LandLinkLeadingRes.LandLinkLeadingResBuilder;
import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.api.LandLinkRes.LandLinkResBuilder;
import com.abacogroup.cllapi.api.ParcelRes;
import com.abacogroup.cllapi.api.TitleType;
import com.abacogroup.cllapi.bundle.tenant.DynamicDocTenantMessageProcessor;
import com.abacogroup.cllapi.bundle.tenant.TitleTypeTenantMessageProcessor;
import com.abacogroup.cllapi.core.GroupDocumentService;
import com.abacogroup.cllapi.core.TitleTypeService;
import com.abacogroup.cllapi.core.dto.CllEventType;
import com.abacogroup.cllapi.core.embededqueue.AnomalyHelper;
import com.abacogroup.cllapi.core.impl.GroupDocumentServiceImpl;
import com.abacogroup.cllapi.core.impl.TitleTypeServiceImpl;
import com.abacogroup.cllapi.core.utils.DynamicDocumentUtils;
import com.abacogroup.cllapi.db.dao.AnomaliesDAO;
import com.abacogroup.cllapi.db.ntt.AnomalyEntity;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.dynamicdocuments.files.FileStoreSupport;
import com.abacogroup.dynamicdocuments.http.RestClient;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.testcommon.ReqContextUtils;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import jakarta.ws.rs.core.SecurityContext;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import org.assertj.core.groups.Tuple;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class AnomalyHelperTest extends JdbiTest {

	private final AnomalyHelper anomalyHelper = getService(AnomalyHelper.class);
	private final AnomalyClient anomalyClientMock = Mockito.mock(AnomalyClientImpl.class);
	private final ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	private final TitleTypeService titleTypeService = this.getService(TitleTypeServiceImpl.class);
	private final GroupDocumentService groupDocumentService = getService(GroupDocumentServiceImpl.class);

	private final Sso2Client sso2Client = Mockito.mock(Sso2Client.class);
	private final DocumentService documentService = this.getService(DocumentService.class);

	@BeforeEach
	void setUp() {
		this.injectMock(anomalyHelper, anomalyClientMock);
		this.injectMock(anomalyHelper, sso2Client);

		this.setUpDocumentService();

		this.injectMock(groupDocumentService, documentService);
	}

	@SneakyThrows
	private void setUpDocumentService() {
		SecurityContext securityContext = Mockito.mock(SecurityContext.class);

		given(securityContext.getUserPrincipal()).willReturn(new User(ctx.getUserId(), ctx.getTenantId()));
		given(sso2Client.createSecurityContextFromUserId(anyString(), anyString()))
				.willReturn(securityContext);
		given(sso2Client.createSecurityContextFromUserName(any(), any()))
				.willReturn(securityContext);

		this.injectMock(documentService, mock(RestClient.class));
		this.injectMock(documentService, mock(FileStoreSupport.class));
	}

	@Test
	public void givenGroupWithoutAnomalies_whenOnGroup_thenExpireAnomalies() {
		// titleType AFFITO : there are no required docs
		getJdbi().useHandle(handle -> {
			handle.begin();
			initBundleStuff();

			long partyId = 555L;
			long groupId = -1L;
			long propertyTitleType = getPropertyTitleType("AFFITTO");
			AbsoluteDate fromDate = AbsoluteDate.of("20220101");

			//setup
			List<String> initScripts = List.of("add_group_and_ll");
			Map<String, Object> params = new HashMap<>(ctx.getTestScriptParams());
			params.put("title_type", propertyTitleType);
			params.put("party_id", partyId);
			execSqlFiles(this.getClass(), initScripts, params);

			//test
			anomalyHelper.onMultipleGroupEvent(CllEventType.NEW_GROUP, List.of(groupId), partyId, fromDate,
					ctx.getTenantId(), ctx.getUserId(), ctx.getReqContext().getLang());

			//asserts
			AnomaliesDAO anomaliesDAO = handle.attach(AnomaliesDAO.class);
			assertThat(findGroupAnomalies(anomaliesDAO, groupId)).isEmpty();
			assertThat(findParcelAnomalies(anomaliesDAO, 697674L)).isEmpty();
			assertThat(findParcelAnomalies(anomaliesDAO, 697673L)).isEmpty();
			assertThat(findPartyParcelAnomalies(anomaliesDAO, partyId, 697673L)).isEmpty();
			assertThat(findPartyParcelAnomalies(anomaliesDAO, partyId, 697673L)).isEmpty();
			// no anomalies to add
			Mockito.verify(anomalyClientMock, Mockito.times(0))
					.add(any(), any(), any());
			// 5 anomalies to expire : 2 ATTO (1 party, 1 group), 2 P55, 1 P55.6 (party)
			ArgumentCaptor<List<AnomalyRequest>> captor = ArgumentCaptor.forClass(List.class);
			Mockito.verify(anomalyClientMock, Mockito.times(1))
					.expire(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()), captor.capture());

			assertThat(captor.getValue()).hasSize(5)
					.containsExactlyInAnyOrder(
							givenAnomalyReq(getGroupDD(), DD_ANOMALY_ATTO, GROUP_CLL_ENTITY_CODE, "-1"),
							givenAnomalyReq(getGroupDD(), DD_ANOMALY_ATTO, PARTY_CLL_ENTITY_CODE, "555"),
							givenAnomalyReq(getGroupLL(), LL_ANOMALY_P55_6, PARTY_CLL_ENTITY_CODE, "555"),
							givenAnomalyReq(getGroupLL(), LL_ANOMALY_P55, PARCEL_ENTITY_CODE, "697673"),
							givenAnomalyReq(getGroupLL(), LL_ANOMALY_P55, PARCEL_ENTITY_CODE, "697674")
					);

			handle.rollback();
		});
	}

	@Test
	public void givenGroupWithAnomalies_whenOnGroup_thenAddAnomalies() {
		// titleType PROPRIETA : there are 3 required doc types: [ DEF_1, DEF_3 , DEF_FILE ]
		getJdbi().useHandle(handle -> {
			handle.begin();
			initBundleStuff();

			long partyId = 555L;
			long groupId = -1L;
			long propertyTitleType = getPropertyTitleType("PROPRIETA");
			AbsoluteDate fromDate = AbsoluteDate.of("20220101");

			//SETUP
			List<String> initScripts = List.of("add_group_and_ll");
			Map<String, Object> params = new HashMap<>(ctx.getTestScriptParams());
			params.put("title_type", propertyTitleType);
			params.put("party_id", partyId);
			execSqlFiles(this.getClass(), initScripts, params);

			// TEST
			anomalyHelper.onMultipleGroupEvent(CllEventType.NEW_GROUP, List.of(groupId), partyId, fromDate,
					ctx.getTenantId(), ctx.getUserId(), ctx.getReqContext().getLang());

			//ASSERTS :  (ATTO anomaly for each LL + no LL anomalies )
			AnomaliesDAO anomaliesDAO = handle.attach(AnomaliesDAO.class);
			assertThat(findGroupAnomalies(anomaliesDAO, groupId))
					.hasSize(1)
					.element(0)
					.extracting(
							AnomalyEntity::getEntityId,
							AnomalyEntity::getEntityCode,
							AnomalyEntity::getTypeGroupCode,
							AnomalyEntity::getTypeCode,
							AnomalyEntity::getValidFrom,
							AnomalyEntity::getValidTo
					).containsExactly(
							String.valueOf(groupId),
							GROUP_CLL_ENTITY_CODE,
							AnomalyHelper.getGroupDD(),
							DD_ANOMALY_ATTO,
							fromDate,
							AbsoluteDate.of("99991231")
					);
			assertThat(findParcelAnomalies(anomaliesDAO, 697674L)).isEmpty();
			assertThat(findParcelAnomalies(anomaliesDAO, 697673L)).isEmpty();
			ArgumentCaptor<List<AnomalyRequest>> captor = ArgumentCaptor.forClass(List.class);
			Mockito.verify(anomalyClientMock, Mockito.times(1))
					.add(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()), captor.capture());
			assertEquals(captor.getValue().size(), 2);

			var anomalies = captor.getValue();
			assertThat(anomalies).hasSize(2);
			assertThat(anomalies).extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactly(Tuple.tuple(GROUP_CLL_ENTITY_CODE, "-1", "ATTO"),
							Tuple.tuple(PARTY_CLL_ENTITY_CODE, "555", "ATTO"));
			anomalies.forEach(System.out::println);

			// Setup : insert new land links for the same parcel and in the same range of dates
			Mockito.reset(anomalyClientMock);

			initScripts = List.of("add_more_group_and_ll");
			params = new HashMap<>(ctx.getTestScriptParams());
			params.put("title_type", propertyTitleType);
			params.put("party_id", partyId);
			execSqlFiles(this.getClass(), initScripts, params);

			// TEST
			anomalyHelper.onMultipleGroupEvent(CllEventType.UPDATE_GROUP, List.of(groupId), partyId, fromDate,
					ctx.getTenantId(), ctx.getUserId(), ctx.getReqContext().getLang());

			//ASSERTS : add ATTO anomaly per ll + add LL anomaly ( percentage : 120% / 90% )
			assertThat(findGroupAnomalies(anomaliesDAO, groupId))
					.hasSize(1)
					.element(0)
					.extracting(
							AnomalyEntity::getEntityId,
							AnomalyEntity::getEntityCode,
							AnomalyEntity::getTypeGroupCode,
							AnomalyEntity::getTypeCode,
							AnomalyEntity::getValidFrom,
							AnomalyEntity::getValidTo
					).containsExactly(
							String.valueOf(groupId),
							GROUP_CLL_ENTITY_CODE,
							getGroupDD(),
							DD_ANOMALY_ATTO,
							fromDate,
							AbsoluteDate.of("99991231")
					);
			assertThat(findParcelAnomalies(anomaliesDAO, 697674L))
					.hasSize(1)
					.element(0)
					.extracting(
							AnomalyEntity::getEntityId,
							AnomalyEntity::getEntityCode,
							AnomalyEntity::getTypeGroupCode,
							AnomalyEntity::getTypeCode,
							AnomalyEntity::getValidFrom,
							AnomalyEntity::getValidTo
					).containsExactly(
							String.valueOf(697674L),
							PARCEL_ENTITY_CODE,
							getGroupLL(),
							LL_ANOMALY_P55,
							fromDate,
							AbsoluteDate.of("20221231")
					);
			assertThat(findParcelAnomalies(anomaliesDAO, 697673L)).isEmpty();
			assertThat(findPartyParcelAnomalies(anomaliesDAO, partyId, 697674L))
					.hasSize(1)
					.element(0)
					.extracting(
							AnomalyEntity::getEntityId,
							AnomalyEntity::getEntityCode,
							AnomalyEntity::getTypeGroupCode,
							AnomalyEntity::getTypeCode,
							AnomalyEntity::getValidFrom,
							AnomalyEntity::getValidTo
					).containsExactly(
							partyParcelEntityId(partyId, 697674L),
							PARTY_PARCEL_ENTITY_CODE,
							getGroupLL(),
							LL_ANOMALY_P55_6,
							fromDate,
							AbsoluteDate.of("20221231")
					);
			assertThat(findPartyParcelAnomalies(anomaliesDAO, partyId, 697673L)).isEmpty();

			Mockito.verify(anomalyClientMock, Mockito.times(1))
					.add(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()), captor.capture());
			List<AnomalyRequest> firstConnectionValues = captor.getValue();
			assertThat(firstConnectionValues).hasSize(4)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(
							Tuple.tuple(PARCEL_ENTITY_CODE, "697674", "P55"),
							Tuple.tuple(PARTY_CLL_ENTITY_CODE, "555", "P55.6"),
							Tuple.tuple(GROUP_CLL_ENTITY_CODE, "-1", "ATTO"),
							Tuple.tuple(PARTY_CLL_ENTITY_CODE, "555", "ATTO")
					);

			Mockito.verify(anomalyClientMock, Mockito.times(1))
					.expire(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()), captor.capture());
			List<AnomalyRequest> secondConnectionValues = captor.getValue();
			assertThat(secondConnectionValues).hasSize(2)
					.extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(
							Tuple.tuple(PARCEL_ENTITY_CODE, "697673", "P55"),
							Tuple.tuple(GROUP_CLL_ENTITY_CODE, "-2", "ATTO")
					);

			handle.rollback();
		});
	}

	@Test
	public void given_differentCases_of_Group_DD_then_test_ATTO_anomalies() {
		// MEZZADRIA : DEF_3 doc is required
		getJdbi().useHandle(handle -> {
			handle.begin();
			initBundleStuff();

			long groupId = -1L; //from_sql
			long propertyTitleType = getPropertyTitleType("MEZZADRIA");
			long partyId = 555L; //to sql
			AbsoluteDate fromDate = AbsoluteDate.of("20220101");

			List<String> initScripts = List.of("add_group_and_ll");
			Map<String, Object> params = new HashMap<>(ctx.getTestScriptParams());
			params.put("title_type", propertyTitleType);
			params.put("party_id", partyId);
			execSqlFiles(this.getClass(), initScripts, params);

			anomalyHelper.onMultipleGroupEvent(CllEventType.NEW_GROUP, List.of(groupId), partyId, fromDate,
					ctx.getTenantId(), ctx.getUserId(), ctx.getReqContext().getLang());

			//case 1:  it should add 1 ATTO anomaly per LL :
			AnomaliesDAO anomaliesDAO = handle.attach(AnomaliesDAO.class);
			assertThat(findGroupAnomalies(anomaliesDAO, groupId))
					.hasSize(1)
					.element(0)
					.extracting(
							AnomalyEntity::getEntityId,
							AnomalyEntity::getEntityCode,
							AnomalyEntity::getTypeGroupCode,
							AnomalyEntity::getTypeCode,
							AnomalyEntity::getValidFrom,
							AnomalyEntity::getValidTo
					).containsExactly(
							String.valueOf(groupId),
							GROUP_CLL_ENTITY_CODE,
							getGroupDD(),
							DD_ANOMALY_ATTO,
							fromDate,
							AbsoluteDate.of("99991231")
					);
			assertThat(findParcelAnomalies(anomaliesDAO, 697674L)).isEmpty();
			assertThat(findParcelAnomalies(anomaliesDAO, 697673L)).isEmpty();

			ArgumentCaptor<List<AnomalyRequest>> captor = ArgumentCaptor.forClass(List.class);
			Mockito.verify(anomalyClientMock, Mockito.times(1))
					.add(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()), captor.capture());

			var anomalies = captor.getValue();
			assertThat(anomalies).hasSize(2);
			assertThat(anomalies).extracting(AnomalyRequest::getEntityCode, AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactly(Tuple.tuple(GROUP_CLL_ENTITY_CODE, "-1", "ATTO"),
							Tuple.tuple(PARTY_CLL_ENTITY_CODE, "555", "ATTO"));

			//case 2. when I add a DD with valid date range then, atto anomalies should expire for all ll in the group
			Mockito.reset(anomalyClientMock);

			String definitionCode = "DEF_3";
			Map<String, Object> doc_def1 = Map.of(
					"id_type", "id_assignment",
					"release_agent", "Comune di Palermo",
					"release_date", "2021-12-03T00:00:00+02:00");
			Document doc = new Document();
			Map<String, Object> fields = DynamicDocumentUtils.createDoc(doc_def1);
			doc.setFields(fields);
			doc.setValidFrom(OffsetDateTime.now());
			doc.setValidTo(OffsetDateTime.of(2024, 2, 1, 11, 0, 0, 0, ZoneOffset.UTC));
			InsertDocument ins = new InsertDocument();
			ins.setDoc(doc);
			ins.setDefCode(definitionCode);
			ins.setBusinessId(groupId);

			// insert doc : DEF3
			GroupDocumentRes documentInserted = groupDocumentService.insert(ctx.getReqContext(), partyId, groupId, ins);

			anomalyHelper.onMultipleGroupEvent(CllEventType.UPDATE_GROUP_DOCS, List.of(groupId), partyId, fromDate,
					ctx.getTenantId(), ctx.getUserId(), ctx.getReqContext().getLang());

			// Asserts case 2
			assertThat(findGroupAnomalies(anomaliesDAO, groupId)).isEmpty();
			assertThat(findParcelAnomalies(anomaliesDAO, 697674L)).isEmpty();
			assertThat(findParcelAnomalies(anomaliesDAO, 697673L)).isEmpty();
			Mockito.verify(anomalyClientMock, Mockito.times(1))
					.expire(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()),
							captor.capture());
			List<AnomalyRequest> anomaliesToExpire = captor.getValue();

			assertThat(anomaliesToExpire).hasSize(5)
					.containsExactlyInAnyOrder(
							givenAnomalyReq(getGroupDD(), DD_ANOMALY_ATTO, GROUP_CLL_ENTITY_CODE, "-1"),
							givenAnomalyReq(getGroupDD(), DD_ANOMALY_ATTO, PARTY_CLL_ENTITY_CODE, "555"),
							givenAnomalyReq(getGroupLL(), LL_ANOMALY_P55_6, PARTY_CLL_ENTITY_CODE, "555"),
							givenAnomalyReq(getGroupLL(), LL_ANOMALY_P55, PARCEL_ENTITY_CODE, "697673"),
							givenAnomalyReq(getGroupLL(), LL_ANOMALY_P55, PARCEL_ENTITY_CODE, "697674")
					);

			handle.rollback();

		});
	}

	@Test
	public void givenInValidGroup_whenOnLandLinkUpdate_thenExpireAnomalies() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			initBundleStuff();

			long groupId = -1L; //from_sql
			long propertyTitleType = getPropertyTitleType("AFFITTO");
			long partyId = 555L; //to sql
			long landLinkId = -1011L;
			AbsoluteDate fromDate = AbsoluteDate.of("20220101");

			List<String> initScripts = List.of("add_group_and_ll", "add_more_group_and_ll");
			Map<String, Object> params = new HashMap<>(ctx.getTestScriptParams());
			params.put("title_type", propertyTitleType);
			params.put("party_id", partyId);
			execSqlFiles(this.getClass(), initScripts, params);

			anomalyHelper.onMultipleGroupEvent(CllEventType.NEW_GROUP, List.of(groupId), partyId, fromDate,
					ctx.getTenantId(), ctx.getUserId(), ctx.getReqContext().getLang());

			//ASSERTS : add P55 anomaly for LL with parcel 697674  (percentage:120%)
			AnomaliesDAO anomaliesDAO = handle.attach(AnomaliesDAO.class);
			assertThat(findGroupAnomalies(anomaliesDAO, groupId)).isEmpty();
			assertThat(findParcelAnomalies(anomaliesDAO, 697674L))
					.hasSize(1)
					.element(0)
					.extracting(
							AnomalyEntity::getEntityId,
							AnomalyEntity::getEntityCode,
							AnomalyEntity::getTypeGroupCode,
							AnomalyEntity::getTypeCode,
							AnomalyEntity::getValidFrom,
							AnomalyEntity::getValidTo
					).containsExactly(
							String.valueOf(697674L),
							PARCEL_ENTITY_CODE,
							getGroupLL(),
							LL_ANOMALY_P55,
							fromDate,
							AbsoluteDate.of("20221231")
					);
			assertThat(findParcelAnomalies(anomaliesDAO, 697673L)).isEmpty();
			assertThat(findPartyParcelAnomalies(anomaliesDAO, partyId, 697674L))
					.hasSize(1)
					.element(0)
					.extracting(
							AnomalyEntity::getEntityId,
							AnomalyEntity::getEntityCode,
							AnomalyEntity::getTypeGroupCode,
							AnomalyEntity::getTypeCode,
							AnomalyEntity::getValidFrom,
							AnomalyEntity::getValidTo
					).containsExactly(
							partyParcelEntityId(partyId, 697674L),
							PARTY_PARCEL_ENTITY_CODE,
							getGroupLL(),
							LL_ANOMALY_P55_6,
							fromDate,
							AbsoluteDate.of("20221231")
					);
			assertThat(findPartyParcelAnomalies(anomaliesDAO, partyId, 697673L)).isEmpty();

			ArgumentCaptor<List<AnomalyRequest>> captor = ArgumentCaptor.forClass(List.class);
			Mockito.verify(anomalyClientMock, Mockito.times(1))
					.add(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()), captor.capture());

			List<AnomalyRequest> anomalies = captor.getValue();
			assertThat(anomalies).hasSize(2)
					.extracting(AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(
							Tuple.tuple("697674", LL_ANOMALY_P55),
							Tuple.tuple("555", LL_ANOMALY_P55_6)
					);

			// update percentage of landLink with parcel 697674 to 10%
			Mockito.reset(anomalyClientMock);

			String sql = " update cll_land_link_detail "
					+ " set title_type_perc = ? "
					+ " where id = ? and group_id = ? and tenant_id = ? ";
			handle.execute(sql, 10, landLinkId, groupId, ctx.getTenantId());

			anomalyHelper.onMultipleLandLinkEvent(CllEventType.UPDATE_LAND_LINKS, List.of(landLinkId), partyId,
					ctx.getTenantId(), ctx.getUserId(), ctx.getReqContext().getLang());

			//ASSERTS
			assertThat(findGroupAnomalies(anomaliesDAO, groupId)).isEmpty();
			assertThat(findParcelAnomalies(anomaliesDAO, 697674L)).isEmpty();
			assertThat(findParcelAnomalies(anomaliesDAO, 697673L)).isEmpty();
			assertThat(findPartyParcelAnomalies(anomaliesDAO, partyId, 697674L)).isEmpty();
			assertThat(findPartyParcelAnomalies(anomaliesDAO, partyId, 697673L)).isEmpty();

			Mockito.verify(anomalyClientMock, Mockito.times(1))
					.expire(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()), captor.capture());

			List<AnomalyRequest> anomaliesToExpire = captor.getValue();
			assertThat(anomaliesToExpire).hasSize(6)
					.containsExactlyInAnyOrder(
							givenAnomalyReq(getGroupDD(), DD_ANOMALY_ATTO, GROUP_CLL_ENTITY_CODE, "-1"),
							givenAnomalyReq(getGroupDD(), DD_ANOMALY_ATTO, GROUP_CLL_ENTITY_CODE, "-2"),
							givenAnomalyReq(getGroupDD(), DD_ANOMALY_ATTO, PARTY_CLL_ENTITY_CODE, "555"),
							givenAnomalyReq(getGroupLL(), LL_ANOMALY_P55_6, PARTY_CLL_ENTITY_CODE, "555"),
							givenAnomalyReq(getGroupLL(), LL_ANOMALY_P55, PARCEL_ENTITY_CODE, "697673"),
							givenAnomalyReq(getGroupLL(), LL_ANOMALY_P55, PARCEL_ENTITY_CODE, "697674")
					);

			handle.rollback();

		});
	}

	@Test
	public void givenNewGroup_onGroupEvent_thenMoreAnomaliesOnSameParcel() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			initBundleStuff();

			long groupId = -11L; //from_sql
			long propertyTitleType = getPropertyTitleType("AFFITTO");
			long partyId = 555L; //to sql
			long parcelId = 1111L;
			AbsoluteDate fromDate = AbsoluteDate.of("20220401");

			List<String> initScripts = List.of("add_groups_and_ll_with_many_p55");
			Map<String, Object> params = new HashMap<>(ctx.getTestScriptParams());
			params.put("title_type", propertyTitleType);
			params.put("party_id", partyId);
			execSqlFiles(this.getClass(), initScripts, params);

			anomalyHelper.onMultipleGroupEvent(CllEventType.NEW_GROUP, List.of(groupId), partyId, fromDate,
					ctx.getTenantId(), ctx.getUserId(), ctx.getReqContext().getLang());

			//ASSERTS : add 4 P55 anomalies for LL with parcel 1111  (percentage:140%)
			AnomaliesDAO anomaliesDAO = handle.attach(AnomaliesDAO.class);
			assertThat(findGroupAnomalies(anomaliesDAO, groupId)).isEmpty();
			assertThat(findParcelAnomalies(anomaliesDAO, parcelId))
					.hasSize(4)
					.extracting(
							AnomalyEntity::getEntityId,
							AnomalyEntity::getEntityCode,
							AnomalyEntity::getTypeGroupCode,
							AnomalyEntity::getTypeCode,
							AnomalyEntity::getValidFrom,
							AnomalyEntity::getValidTo
					).containsExactlyInAnyOrder(
							tuple(
									String.valueOf(parcelId),
									PARCEL_ENTITY_CODE,
									getGroupLL(),
									LL_ANOMALY_P55,
									AbsoluteDate.of("20220301"),
									AbsoluteDate.of("20220331")
							), tuple(
									String.valueOf(parcelId),
									PARCEL_ENTITY_CODE,
									getGroupLL(),
									LL_ANOMALY_P55,
									AbsoluteDate.of("20220401"),
									AbsoluteDate.of("20220430")
							), tuple(
									String.valueOf(parcelId),
									PARCEL_ENTITY_CODE,
									getGroupLL(),
									LL_ANOMALY_P55,
									AbsoluteDate.of("20220601"),
									AbsoluteDate.of("20220630")
							), tuple(
									String.valueOf(parcelId),
									PARCEL_ENTITY_CODE,
									getGroupLL(),
									LL_ANOMALY_P55,
									AbsoluteDate.of("20220701"),
									AbsoluteDate.of("20220731")
							)
					);
			assertThat(findParcelAnomalies(anomaliesDAO, 2222L)).isEmpty();
			assertThat(findParcelAnomalies(anomaliesDAO, 3333L)).isEmpty();
			assertThat(findPartyParcelAnomalies(anomaliesDAO, partyId, parcelId))
					.hasSize(2)
					.extracting(
							AnomalyEntity::getEntityId,
							AnomalyEntity::getEntityCode,
							AnomalyEntity::getTypeGroupCode,
							AnomalyEntity::getTypeCode,
							AnomalyEntity::getValidFrom,
							AnomalyEntity::getValidTo
					).containsExactlyInAnyOrder(
							tuple(
									partyParcelEntityId(partyId, parcelId),
									PARTY_PARCEL_ENTITY_CODE,
									getGroupLL(),
									LL_ANOMALY_P55_6,
									AbsoluteDate.of("20220301"),
									AbsoluteDate.of("20220430")
							), tuple(
									partyParcelEntityId(partyId, parcelId),
									PARTY_PARCEL_ENTITY_CODE,
									getGroupLL(),
									LL_ANOMALY_P55_6,
									AbsoluteDate.of("20220701"),
									AbsoluteDate.of("20220731")
							)
					);
			assertThat(findPartyParcelAnomalies(anomaliesDAO, partyId, 2222L)).isEmpty();
			assertThat(findPartyParcelAnomalies(anomaliesDAO, partyId, 3333L)).isEmpty();
			assertThat(handle.select(
					"select count(*) from cll_anomalies where id in (?, ?, ?) and (§current_timestamp§ between dt_insert and dt_delete)",
					-1L, -2L, -3L
			).mapTo(Integer.class).first()).isEqualTo(0);

			ArgumentCaptor<List<AnomalyRequest>> captor = ArgumentCaptor.forClass(List.class);

			Mockito.verify(anomalyClientMock, Mockito.times(1))
					.add(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()), captor.capture());
			assertThat(captor.getValue()).hasSize(2)
					.extracting(AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(
							Tuple.tuple("1111", "P55"),
							Tuple.tuple("555", "P55.6")
					);

			Mockito.verify(anomalyClientMock, Mockito.times(1))
					.expire(eq(ctx.getReqContext().getLang()), eq(ctx.getReqContext().getUser()), captor.capture());
			assertThat(captor.getValue()).hasSize(6)
					.extracting(AnomalyRequest::getEntityId, AnomalyRequest::getTypeCode)
					.containsExactlyInAnyOrder(
							Tuple.tuple("-10", "ATTO"),
							Tuple.tuple("-11", "ATTO"),
							Tuple.tuple("-13", "ATTO"),
							Tuple.tuple("555", "ATTO"),
							Tuple.tuple("2222", "P55"),
							Tuple.tuple("3333", "P55")
					);


			handle.rollback();

		});
	}

	//******************************************************************************

	private AnomalyRequest givenAnomalyReq(String typeGroupCode, String typeCode, String entityCode, String entityId) {
		return new AnomalyRequest().setTypeGroupCode(typeGroupCode).setTypeCode(typeCode).setEntityCode(entityCode).setEntityId(entityId);
	}

	private List<AnomalyEntity> findParcelAnomalies(AnomaliesDAO anomaliesDAO, Long parcelId) {
		return anomaliesDAO.findByAnomalyTypeAndEntity(AnomalyEntity.builder()
				.setTenantId(ctx.getTenantId())
				.setEntityId(String.valueOf(parcelId))
				.setEntityCode(PARCEL_ENTITY_CODE)
				.setTypeGroupCode(getGroupLL())
				.setTypeCode(LL_ANOMALY_P55)
				.build());
	}

	private List<AnomalyEntity> findPartyParcelAnomalies(AnomaliesDAO anomaliesDAO, Long partyId, Long parcelId) {
		return anomaliesDAO.findByAnomalyTypeAndEntity(AnomalyEntity.builder()
				.setTenantId(ctx.getTenantId())
				.setEntityId(AnomalyHelper.partyParcelEntityId(partyId, parcelId))
				.setEntityCode(PARTY_PARCEL_ENTITY_CODE)
				.setTypeGroupCode(getGroupLL())
				.setTypeCode(LL_ANOMALY_P55_6)
				.build());
	}

	private List<AnomalyEntity> findGroupAnomalies(AnomaliesDAO anomaliesDAO, Long groupId) {
		return anomaliesDAO.findByAnomalyTypeAndEntity(AnomalyEntity.builder()
				.setTenantId(ctx.getTenantId())
				.setEntityId(String.valueOf(groupId))
				.setEntityCode(GROUP_CLL_ENTITY_CODE)
				.setTypeGroupCode(AnomalyHelper.getGroupDD())
				.setTypeCode(DD_ANOMALY_ATTO)
				.build());
	}

	private List<AnomalyEntity> findPartyAnomalies(AnomaliesDAO anomaliesDAO, Long partyId) {
		return anomaliesDAO.findByAnomalyTypeAndEntity(AnomalyEntity.builder()
				.setTenantId(ctx.getTenantId())
				.setEntityId(String.valueOf(partyId))
				.setEntityCode(PARTY_CLL_ENTITY_CODE)
				.setTypeGroupCode(AnomalyHelper.getGroupDD())
				.setTypeCode(DD_ANOMALY_ATTO)
				.build());
	}

	private void initBundleStuff() {
		DynamicDocTenantMessageProcessor dynamicDocTenantMessageProcessor = this.getService(DynamicDocTenantMessageProcessor.class);
		TitleTypeTenantMessageProcessor processor = this.getService(TitleTypeTenantMessageProcessor.class);
		processor.onMessage(new TenantMessage()
				.setTenantId(ctx.getTenantId()));
		dynamicDocTenantMessageProcessor.onMessage(new TenantMessage()
				.setTenantId(ctx.getTenantId()));
	}

	private long getPropertyTitleType(String titleType) {
		return titleTypeService.searchAll(ctx.getReqContext()).stream().filter(t -> t.getCode().toLowerCase().equalsIgnoreCase(titleType))
				.map(TitleType::getId).findFirst().orElseThrow();
	}

	private static LandLinkResBuilder<?, ?> landLinkResBuilder(Long id, double perc, long parcelId) {
		return LandLinkRes.builder()
				.setId(id)
				.setParcel(ParcelRes.builder().setId(parcelId).build())
				.setTitleTypePerc(BigDecimal.valueOf(perc));
	}

	private static LandLinkLeadingResBuilder<?, ?> landLinkLeadingResBuilder(Long id, double perc, long parcelId) {
		return LandLinkLeadingRes.builder()
				.setId(id)
				.setTitleTypePerc(BigDecimal.valueOf(perc));
	}
}
