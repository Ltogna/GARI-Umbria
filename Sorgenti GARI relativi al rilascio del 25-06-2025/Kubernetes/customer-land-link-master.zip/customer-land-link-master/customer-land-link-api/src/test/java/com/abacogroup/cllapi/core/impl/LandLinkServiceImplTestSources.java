package com.abacogroup.cllapi.core.impl;

import static org.assertj.core.api.Assertions.tuple;

import com.abacogroup.cllapi.api.req.LandLinkSearchReq;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import java.util.stream.Stream;
import org.assertj.core.groups.Tuple;
import org.junit.jupiter.params.provider.Arguments;

class LandLinkServiceImplTestSources {

	/**
	 * tuple(-11101L, 10101L),
	 * tuple(-11102L, 12502L),
	 * tuple(-11103L, 10203L),
	 * tuple(-12101L, 202011L),
	 * tuple(-12102L, 20502L),
	 * tuple(-12103L, 20501L), // 20211202
	 * tuple(-14101L, 401011L),
	 * tuple(-14102L, 401012L),
	 *
	 * tuple(-11201L, 10204L),
	 * tuple(-13201L, 30101L),
	 * tuple(-13202L, 30102L),
	 * tuple(-13203L, 30103L),
	 * tuple(-14201L, 40102L), // 20220101
	 *
	 * tuple(-12301L, 20205L),
	 * tuple(-12302L, 20305L),
	 * tuple(-14301L, 40103L),
	 *
	 * tuple(-12401L, 20205L), // 20200202
	 * tuple(-12402L, 20305L), // 20200202
	 * tuple(-14401L, 40103L), // 20200202
	 *
	 * tuple(-14901L, 40103L),
	 *
	 * LandLinkResV1::getId,
	 * landLinkRes -> landLinkRes.getParcel().getId()
	 *
	 * tuple([gr-sec-tt-N]L, [sec-0blk-0prc(-sub)]L),
	 */
	static Stream<Arguments> test_search_ok() {
		return Stream.of(
				Arguments.of("basic_search TODAY", new LandLinkSearchReq(), AbsoluteDate.of("20230314"), new Tuple[] {
						tuple(-11101L, 10101L),
						tuple(-11102L, 12502L),
						tuple(-11103L, 10203L),
						tuple(-12101L, 202011L),
						tuple(-12102L, 20502L),
						tuple(-14101L, 401011L),
						tuple(-14102L, 401012L),
						tuple(-11201L, 10204L),
						tuple(-13201L, 30101L),
						tuple(-13202L, 30102L),
						tuple(-13203L, 30103L),
						tuple(-12301L, 20205L),
						tuple(-12302L, 20305L),
						tuple(-14301L, 40103L),
						tuple(-14901L, 40103L),
				})
				, Arguments.of("basic_search PAST", new LandLinkSearchReq(), AbsoluteDate.of("20200101"), new Tuple[] {
						tuple(-12401L, 20205L), // 20200202
						tuple(-12402L, 20305L), // 20200202
						tuple(-14401L, 40103L), // 20200202
						tuple(-14901L, 40103L)
				})
				, Arguments.of("by cadrastal ref", new LandLinkSearchReq()
								.setSectorCode("A004").setBlockCode("1").setParcelCode("3"),
						AbsoluteDate.of("20230314"), new Tuple[] {
								tuple(-14301L, 40103L),
								tuple(-14901L, 40103L)
						})
				, Arguments.of("by cadrastal ref w/subParcel", new LandLinkSearchReq()
								.setSectorCode("A004").setBlockCode("1").setParcelCode("1").setSubParcelCode("B"),
						AbsoluteDate.of("20230314"), new Tuple[] {
								tuple(-14102L, 401012L),
						})
				, Arguments.of("by sector and block", new LandLinkSearchReq()
								.setSectorCode("A004").setBlockCode("1"),
						AbsoluteDate.of("20230314"), new Tuple[] {
								tuple(-14101L, 401011L),
								tuple(-14102L, 401012L),
								tuple(-14301L, 40103L),
								tuple(-14901L, 40103L)
						})
				, Arguments.of("by party id", new LandLinkSearchReq().setPartyId(666L), AbsoluteDate.of("20230314"), new Tuple[] {
						tuple(-14901L, 40103L)
				})
				, Arguments.of("by cadrastal ref and party", new LandLinkSearchReq().setPartyId(555L)
								.setSectorCode("A004").setBlockCode("1").setParcelCode("3"),
						AbsoluteDate.of("20230314"), new Tuple[] {
								tuple(-14301L, 40103L),
						})
				, Arguments.of("by sector and party", new LandLinkSearchReq().setPartyId(555L)
								.setSectorCode("A001"),
						AbsoluteDate.of("20230314"), new Tuple[] {
								tuple(-11101L, 10101L),
								tuple(-11102L, 12502L),
								tuple(-11103L, 10203L),
								tuple(-11201L, 10204L),
						})


		);
	}
}
