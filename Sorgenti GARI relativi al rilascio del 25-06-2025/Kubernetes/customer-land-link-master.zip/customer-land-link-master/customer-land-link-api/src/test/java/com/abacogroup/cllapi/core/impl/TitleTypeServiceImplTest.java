package com.abacogroup.cllapi.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.AssertionsForClassTypes.tuple;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.api.TitleType;
import com.abacogroup.cllapi.core.TitleTypeService;
import com.abacogroup.common.resources.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class TitleTypeServiceImplTest extends JdbiTest {

	private static final String TENANT_ID = String.format("%s_t", TitleTypeServiceImplTest.class.getSimpleName());
	private static final String USER_ID = String.format("%s_u", TitleTypeServiceImplTest.class.getSimpleName());
	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", TENANT_ID,
			"user_id", USER_ID
	);

	private static final ReqContext reqContext =
			new ReqContext(TENANT_ID, USER_ID, "en");

	private final TitleTypeService service = getService(TitleTypeServiceImpl.class);

	@Test
	void test_searchAll() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			List<TitleType> list = this.service.searchAll(reqContext);

			assertThat(list).hasSize(3)
					.extracting(TitleType::getCode, TitleType::getI18nCode)
					.containsExactly(
							tuple("SHARECROPPING", "sharecropping_en"),
							tuple("RENT", "rent_en"),
							tuple("OWNERSHIP", "ownership_en")
					);

			handle.rollback();
		});

	}

	@Test
	void test_getById() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			Long id = -100L;
			Optional<TitleType> res = this.service.getById(reqContext, id);
			assertTrue(res.isPresent());
			assertThat(res.get().getCode()).isEqualTo("OWNERSHIP");
			assertThat(res.get().getI18nCode()).isEqualTo("ownership_en");

			handle.rollback();
		});

	}
}
