package com.abacogroup.cllapi.bundle.tenant;

import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.core.TitleTypeService;
import com.abacogroup.cllapi.core.impl.TitleTypeServiceImpl;
import com.abacogroup.common.resources.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class TitleTypeTenantMessageProcessorTest extends JdbiTest {

	private final TitleTypeTenantMessageProcessor processor = getService(TitleTypeTenantMessageProcessor.class);

	private final TitleTypeService titleTypeService = this.getService(TitleTypeServiceImpl.class);

	@Test
	void should_new_tenant() {
		var tenant = "t";
		var ctx = new ReqContext(tenant, "u", "it");

		getJdbi().useHandle(handle -> {

			handle.begin();

			processor.onMessage(new TenantMessage()
					.setTenantId(tenant));
			assertThat(titleTypeService.searchAll(ctx))
					.hasSize(5);

			handle.rollback();
		});
	}

}

