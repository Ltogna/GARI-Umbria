package com.abacogroup.cllapi.db.dao;

import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.core.dto.LandLinkPayload;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.testcommon.ReqContextUtils;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.math.BigDecimal;
import java.util.List;
import org.assertj.core.data.Percentage;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class LandLinkDAOTest extends JdbiTest {

	private ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	private LandLinkDAO landLinkDAO = getDAO(LandLinkDAO.class);

	// ----- getPayloadByPartyIdAndIdIn -----
	@Test
	void test_getPayloadByPartyIdAndIdIn_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			List<Long> ids = List.of(-103L, -202L, -101L);
			List<LandLinkPayload> landLinkPayloads = landLinkDAO.getPayloadByPartyIdAndIdIn(ctx.getTenantId(), 555L, ids);
			assertThat(landLinkPayloads)
					.hasSize(3)
					.extracting(LandLinkPayload::getLandLinkId)
					.containsExactlyInAnyOrderElementsOf(ids);
			assertThat(landLinkPayloads.get(0))
					.usingRecursiveComparison()
					.ignoringFields("titleTypePerc")
					.isEqualTo(LandLinkPayload.builder()
							.setLandLinkId(-202L)
							.setGroupId(-2L)
							.setGroupDescr("group 2")
							.setTitleTypeId(-2L)
							.setTitleTypeCode("RENT")
							.setTitleTypePerc(null)
							.setParcelId(212L)
							.setSectorCode("A002")
							.setBlockCode("1")
							.setParcelCode("00002")
							.setSubParcelCode(null)
							.setDayFrom(AbsoluteDate.of("20200202"))
							.setDayTo(AbsoluteDate.of("20300302"))
							.build());
			assertThat(landLinkPayloads.get(0).getTitleTypePerc()).isCloseTo(BigDecimal.valueOf(100), Percentage.withPercentage(0));

			handle.rollback();
		});

	}

	// ----- getPayloadByPartyIdAndGroupIdIn -----
	@Test
	void test_getPayloadByPartyIdAndGroupIdIn_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			List<Long> ids = List.of(-1L, -2L);
			List<LandLinkPayload> landLinkPayloads = landLinkDAO.getPayloadByPartyIdAndGroupIdIn(ctx.getTenantId(), 555L, ids);
			assertThat(landLinkPayloads)
					.hasSize(5)
					.extracting(LandLinkPayload::getLandLinkId)
					.containsExactly(-202L,-201L,  -103L, -102L, -101L);

			handle.rollback();
		});
	}
}
