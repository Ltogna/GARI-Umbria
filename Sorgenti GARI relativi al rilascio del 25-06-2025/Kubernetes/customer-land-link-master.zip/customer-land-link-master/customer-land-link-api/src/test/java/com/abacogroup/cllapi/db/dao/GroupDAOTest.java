package com.abacogroup.cllapi.db.dao;

import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.db.ntt.GroupEntity;
import com.abacogroup.cllapi.db.ntt.GroupEntity.GroupEntityBuilder;
import com.abacogroup.cllapi.db.ntt.GroupEntityExtended;
import com.abacogroup.common.service.AuditHelper;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class GroupDAOTest extends JdbiTest {

	private static final String TENANT_ID = String.format("%s_t", GroupDAOTest.class.getSimpleName());
	private static final String USER_ID = String.format("%s_u", GroupDAOTest.class.getSimpleName());
	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", TENANT_ID,
			"user_id", USER_ID
	);

	private final GroupDAO dao = getDAO(GroupDAO.class);

	@Test
	void test_insert() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			GroupEntity newGroup = groupEntityBuilder().build();
			AuditHelper.setAuditForInsert(USER_ID, dao, newGroup);

			Long id = dao.issuePk();
			dao.insertMasterRow(id, newGroup);
			dao.insertDetailRow(id, newGroup);

			assertThat(dao.findById(TENANT_ID, id)).isPresent()
					.get()
					.hasFieldOrPropertyWithValue("id", id)
					.hasFieldOrPropertyWithValue("pkid", id)
					.hasNoNullFieldsOrPropertiesExcept("userIdDelete")
					.usingRecursiveComparison()
					.ignoringFields("id", "pkid")
					.isEqualTo(newGroup);

			handle.rollback();
		});

	}

	@Test
	void test_update() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			long id = -1L;
			GroupEntity group1 = dao.findById(TENANT_ID, id).get();
			AuditHelper.setAuditForExpire(USER_ID, dao, group1);

			dao.expireRow(group1);

			assertThat(dao.findById(TENANT_ID, id)).isNotPresent();

			GroupEntity newGroup = groupEntityBuilder().setId(id)
					.setPartyId(444L) // will not change
					.setTitleTypeId(-100L) // will not change
					.setDescr("group 1 updated") // will change
					.build();
			AuditHelper.setAuditForInsert(USER_ID, dao, newGroup);
			long pkid = dao.insertVersionRow(newGroup);

			assertThat(dao.findById(TENANT_ID, id)).isPresent()
					.get()
					.hasFieldOrPropertyWithValue("pkid", pkid)
					.hasFieldOrPropertyWithValue("partyId", group1.getPartyId())
					.hasFieldOrPropertyWithValue("titleTypeId", group1.getTitleTypeId())
					.hasNoNullFieldsOrPropertiesExcept("userIdDelete")
					.usingRecursiveComparison()
					.ignoringFields("pkid", "partyId", "titleTypeId")
					.isEqualTo(newGroup);

			handle.rollback();
		});

	}

	// ----- findExtendedById -----
	@Test
	void test_findExtendedById_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			assertThat(dao.findExtendedByIdAndPartyId(TENANT_ID, -1L, 555L)).isPresent()
					.get()
					.extracting(GroupEntity::getId,
							GroupEntityExtended::getDayFrom,
							GroupEntityExtended::getDayTo,
							GroupEntityExtended::getLinkCount)
					.containsExactly(-1L, AbsoluteDate.of("20200202"), AbsoluteDate.of(AuditEntity.dateActive), 3L);

			assertThat(dao.findExtendedByIdAndPartyId(TENANT_ID, -2L, 555L)).isPresent()
					.get()
					.extracting(GroupEntity::getId,
							GroupEntityExtended::getDayFrom,
							GroupEntityExtended::getDayTo,
							GroupEntityExtended::getLinkCount)
					.containsExactly(-2L, null, null, 0L);

			handle.rollback();
		});
	}

	// ###################################################################################################################################################### //

	private static GroupEntityBuilder<?, ?> groupEntityBuilder() {
		return GroupEntity.builder()
				.setTenantId(TENANT_ID)
				.setPartyId(555L)
				.setTitleTypeId(-100L)
				.setDescr("test new group");
	}

}
