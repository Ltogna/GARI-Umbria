package com.abacogroup.cllapi.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;

import java.io.IOException;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.assertj.core.groups.Tuple;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;

import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.api.LandLinkLeadingRes;
import com.abacogroup.cllapi.api.ParcelSearchRes;
import com.abacogroup.cllapi.api.req.ParcelSearchReq;
import com.abacogroup.cllapi.core.LandLinkService;
import com.abacogroup.cllapi.core.LpisClientService;
import com.abacogroup.cllapi.core.ParcelService;
import com.abacogroup.cllapi.core.PartyClientService;
import com.abacogroup.cllcli.api.v1.enums.ParcelSearchLevel;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lpisgisserver.api.v1.PublicParcel;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import com.abacogroup.testcommon.ReqContextUtils;
import com.fasterxml.jackson.core.type.TypeReference;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;

@ExtendWith(DropwizardExtensionsSupport.class)
class ParcelServiceImplTest extends JdbiTest {

    private final ParcelService parcelService = this.getService(ParcelServiceImpl.class);
    private final LandLinkService landLinkService = this.getService(LandLinkServiceImpl.class);
    private final ReqContextUtils ctx = new ReqContextUtils(this.getClass());
    private final LpisClientService lpisClientServiceMock = Mockito.mock(LpisClientServiceImpl.class);
    private final PartyClientService partyClientServiceMock = Mockito.mock(PartyClientServiceImpl.class);
    private ReqContext reqContext;

    @BeforeEach
    void setUp() {
        // User user = (User) buildAuthContext("master", "admin").getUserPrincipal();
        User user = ctx.getReqContext().getUser(); // new User("admin", "master");
        reqContext = new ReqContext(user, "it");
        // this.injectMock(lpisClientService,
        // new ClientHelper(getGenericWebTarget("https://iacs-dev.fe.abacogroup.eu/lpis-server-api")));

        this.injectMock(landLinkService, lpisClientServiceMock);

        this.injectMock(parcelService, landLinkService);
        this.injectMock(parcelService, lpisClientServiceMock);
        this.injectMock(parcelService, partyClientServiceMock);

        given(partyClientServiceMock.getById(eq(reqContext), any(Long.class)))
                .willAnswer(a -> Optional.of(new PartyResponseV1().setId(a.getArgument(1))));
    }

    @Test
    void test_search_no_cuaa() {

        Clock clock = mock(Clock.class);
        injectMock(parcelService, clock);
        LocalDateTime now = LocalDateTime.now();
        given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
        given(clock.getZone()).willReturn(ZoneId.of("UTC"));

        getJdbi().useHandle(handle -> {
            handle.begin();

            List<String> initScripts = List.of("case_01");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            ParcelSearchReq parcelSearchReq = new ParcelSearchReq()
                    .setSectorCode("s_code")
                    .setBlockCode("b_code")
                    .setParcelCode("p_code")
                    .setDayFrom("20230310");

            // just records, no nextKey / count
            Path lpisResponse = file2Path.apply("lpis_response_1.json");

            List<PublicParcel> parcels;
            try {
                parcels = getMapper().readValue(lpisResponse.toFile(), new TypeReference<>() {
                });
            } catch (IOException e) {
                throw new IllegalStateException(e);
            }

            InfiniteListResults<PublicParcel> lpisApiRes = new InfiniteListResultsImpl<>(parcels, "_next");

            given(lpisClientServiceMock.searchParcels(
                    eq(reqContext),
                    eq(AbsoluteDate.of(now)),
                    eq(parcelSearchReq.getSectorCode()),
                    eq(parcelSearchReq.getBlockCode()),
                    eq(parcelSearchReq.getParcelCode()),
                    eq(false),
                    eq(false),
                    any(),
                    eq(null),
                    eq(10))).willReturn(lpisApiRes);

            InfiniteListResults<ParcelSearchRes> res = parcelService.search(reqContext, 1L, parcelSearchReq, false, false, true, ParcelSearchLevel.SEARCH_ONLY_VALID, null, 10);
            res.getRecords().stream().forEach(System.out::println);

            assertThat(res.getRecords())
                    .extracting(parcelSearchRes -> parcelSearchRes.getParcel().getId(),
                            z -> z.getLeadings().stream().map(LandLinkLeadingRes::getPartyId).collect(Collectors.toList()))
                    .containsExactly(
                            Tuple.tuple(3783502L, List.of()),
                            Tuple.tuple(3564508L, List.of()),
                            Tuple.tuple(151851L, List.of()),
                            Tuple.tuple(151852L, List.of()),
                            Tuple.tuple(4076488L, List.of()),
                            Tuple.tuple(4076489L, List.of()),
                            Tuple.tuple(16030594L, List.of()),

                            // TODO caso border-line da chiedere meglio e/o vedere nella doc
                            Tuple.tuple(16030604L, List.of()), // questa è stata in possesso del party 1 fino al 20230309 (qui si parte il 20230310)
                            // TODO aggiungere caso al giorno stesso che comunque risulta List.of()

                            Tuple.tuple(16030606L, List.of(1L)), // questa è una particella condotta nel periodo dal party corrente 1L
                            Tuple.tuple(697674L, List.of(555L, 666L)) // questa è una particella condotta nel periodo dal party 666L
                    );

            Mockito.verify(lpisClientServiceMock).searchParcels(
                    eq(reqContext),
                    eq(AbsoluteDate.of(now)),
                    eq(parcelSearchReq.getSectorCode()),
                    eq(parcelSearchReq.getBlockCode()),
                    eq(parcelSearchReq.getParcelCode()),
                    eq(false),
                    eq(false),
                    any(),
                    any(),
                    any());

            handle.rollback();
        });

    }

    @Test
    void test_search_with_cuaa() {

        getJdbi().useHandle(handle -> {
            handle.begin();

            List<String> initScripts = List.of("case_01");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            ParcelSearchReq parcelSearchReq = new ParcelSearchReq()
                    .setCuaa("11223344")
                    // .setSectorCode("s_code")
                    // .setBlockCode("b_code")
                    // .setParcelCode("p_code")
                    .setDayFrom("20230310");

            given(partyClientServiceMock.getByCode(eq(reqContext), any()))
                    .willAnswer(a -> Optional.of(new PartyResponseV1()
                            .setCode(a.getArgument(1))
                            .setId(666L)));

            // //just records, no nextKey / count
            Path lpisResponse = file2Path.apply("lpis_response_1.json");

            List<PublicParcel> parcels;
            try {
                parcels = getMapper().readValue(lpisResponse.toFile(), new TypeReference<>() {
                });
            } catch (IOException e) {
                throw new IllegalStateException(e);
            }

            Map<Long, PublicParcel> parcelMap = parcels.stream().collect(Collectors.toMap(PublicParcel::getId, Function.identity()));

            given(lpisClientServiceMock.getParcelById(any(), any(), any())).willAnswer(a -> Optional.of(parcelMap.get(a.getArgument(2))));
            doAnswer(i -> {
                ((List<Long>) i.getArgument(3))
                        .stream()
                        .map(parcelMap::get)
                        .forEach(i.getArgument(4));
                return null;
            }).when(lpisClientServiceMock).consumeParcelsByIdIn(any(), any(), any(), any(), any());

            InfiniteListResults<ParcelSearchRes> res = parcelService.search(reqContext, 1L, parcelSearchReq, false, false, true, ParcelSearchLevel.SEARCH_ONLY_VALID, null, 10);
            res.getRecords().forEach(System.out::println);

            assertThat(res.getRecords())
                    .extracting(parcelSearchRes -> parcelSearchRes.getParcel().getId(),
                            z -> z.getLeadings().stream()
                                    .map(LandLinkLeadingRes::getPartyId)
                                    .collect(Collectors.toList()))
                    .containsExactly(
                            Tuple.tuple(697674L, List.of(555L, 666L)) // questa è una particella condotta nel periodo dal party 666L
                    );

            handle.rollback();
        });
    }


    @Test
    void test_getParcelLeadingList() {

        getJdbi().useHandle(handle -> {
            handle.begin();

            List<String> initScripts = List.of("case_01");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());


            given(partyClientServiceMock.getByCode(eq(reqContext), any()))
                    .willAnswer(a -> Optional.of(new PartyResponseV1()
                            .setCode(a.getArgument(1))
                            .setId(666L)));

            // //just records, no nextKey / count
            Path lpisResponse = file2Path.apply("lpis_response_1.json");

            List<PublicParcel> parcels;
            try {
                parcels = getMapper().readValue(lpisResponse.toFile(), new TypeReference<>() {
                });
            } catch (IOException e) {
                throw new IllegalStateException(e);
            }

            Map<Long, PublicParcel> parcelMap = parcels.stream().collect(Collectors.toMap(PublicParcel::getId, Function.identity()));

            given(lpisClientServiceMock.getParcelById(any(), any(), any())).willAnswer(a -> Optional.of(parcelMap.get(a.getArgument(2))));
            doAnswer(i -> {
                ((List<Long>) i.getArgument(3))
                        .stream()
                        .map(parcelMap::get)
                        .forEach(i.getArgument(4));
                return null;
            }).when(lpisClientServiceMock).consumeParcelsByIdIn(any(), any(), any(), any(), any());

            List<LandLinkLeadingRes> res = parcelService.getParcelLeadingList(reqContext, 697674L, AbsoluteDate.of("20230310"));
            assertThat(res)
                    .extracting(LandLinkLeadingRes::getPartyId)
                    .containsExactly(666L);

            List<LandLinkLeadingRes> res2 = parcelService.getParcelLeadingList(reqContext, 697674L, AbsoluteDate.of("20231028"));
            assertThat(res2)
                    .extracting(LandLinkLeadingRes::getPartyId)
                    .containsExactlyInAnyOrder(555L, 666L);

            List<LandLinkLeadingRes> res22 = parcelService.getParcelLeadingList(reqContext, 697674L, AbsoluteDate.of("20231029"));
            assertThat(res22)
                    .extracting(LandLinkLeadingRes::getPartyId)
                    .containsExactlyInAnyOrder(555L, 666L);

            List<LandLinkLeadingRes> res3 = parcelService.getParcelLeadingList(reqContext, 697674L, AbsoluteDate.of("20231030"));
            assertThat(res3)
                    .extracting(LandLinkLeadingRes::getPartyId)
                    .containsExactlyInAnyOrder(666L);

            List<LandLinkLeadingRes> res4 = parcelService.getParcelLeadingList(reqContext, 697674L, AbsoluteDate.of("20231031"));
            assertThat(res4)
                    .extracting(LandLinkLeadingRes::getPartyId)
                    .containsExactlyInAnyOrder(666L);

            handle.rollback();
        });
    }

}
