package com.abacogroup.cllapi.bundle.tenant;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.db.dao.CllSettingsDAO;
import com.abacogroup.testcommon.ReqContextUtils;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class CllSettingsTenantMessageProcessorTest extends JdbiTest {

	private final CllSettingsTenantMessageProcessor tenantProcessor = getService(CllSettingsTenantMessageProcessor.class);
	private final CllSettingsDAO cllSettingsDAO = this.getDAO(CllSettingsDAO.class);
	private ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	@Test
	void should_new_tenant() {
		getJdbi().useHandle(handle -> {

			handle.begin();

			Assertions.assertThat(cllSettingsDAO.countAll(ctx.getTenantId()))
					.isEqualTo(0L);

			tenantProcessor.onMessage(new TenantMessage()
					.setTenantId(ctx.getTenantId()));

			Assertions.assertThat(cllSettingsDAO.countAll(ctx.getTenantId()))
					.isEqualTo(1L);

			handle.rollback();
		});
	}

}
