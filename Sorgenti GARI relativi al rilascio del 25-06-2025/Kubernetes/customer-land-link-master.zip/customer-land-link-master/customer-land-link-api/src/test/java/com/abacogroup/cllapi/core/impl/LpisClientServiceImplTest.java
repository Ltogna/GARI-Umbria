package com.abacogroup.cllapi.core.impl;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.LongStream;

import org.apache.commons.lang3.StringUtils;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;

import com.abacogroup.cllapi.core.client.WebCliHelper;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lpisgisserver.api.v1.PublicParcel;
import com.abacogroup.lpisgisserver.api.v1.PublicParcelsList;

import io.dropwizard.auth.Auth;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.client.WebTarget;

@ExtendWith(DropwizardExtensionsSupport.class)
class LpisClientServiceImplTest {

	public static final String URL = "/{tenant}/public/v1/lpis";
	private static final User USER = new User(WebCliHelper.BASIC_USERNAME, WebCliHelper.FAKE_JWT, WebCliHelper.TENANT, "");

	private static final PingResource mockResource = spy(new PingResource());

	private static final ResourceExtension EXT = WebCliHelper.createEXT(mockResource);
	private final WebTarget baseTarget = EXT.target("");
	private LpisClientServiceImpl client;

	@BeforeEach
	void setUp() {
		reset(mockResource);
		client = new LpisClientServiceImpl(baseTarget);

	}

	@Test
	void test_searchParcels() {
		// search sectorDescrFilter = S1 && blockDescrFilter = B1
		List<PublicParcel> results = client.searchParcels(new ReqContext(USER, "en"), AbsoluteDate.of("20230221"), "S1", "B1", null, null, null, null);

		Assertions.assertThat(results).isNotNull();
		Assertions.assertThat(results).hasSize(1)
				.containsExactly(
						PublicParcel.builder().setId(2L).setParcel("P2").build());
		verify(mockResource).searchParcels(
				eq("en"), any(User.class), eq(USER.getTenant()), eq("20230221"), eq("S1"), eq("B1"), eq(null), eq(false), eq(false), any());

		// search all
		results = client.searchParcels(new ReqContext(USER, "en"), AbsoluteDate.of("20230201"), null, null, null, null, null, null);
		Assertions.assertThat(results).hasSize(3)
				.containsExactly(PublicParcel.builder().setId(1L).setParcel("P1").build(),
						PublicParcel.builder().setId(2L).setParcel("P2").build(),
						PublicParcel.builder().setId(1L).setParcel("P1").build());
		verify(mockResource).searchParcels(
				eq("en"), any(User.class), eq(USER.getTenant()), eq("20230201"), eq(null), eq(null), eq(null), eq(false), eq(false), any());

	}

	@Test
	void test_getParcelsBySectorCode() {
		List<PublicParcel> results = client.getParcelsBySectorCode(new ReqContext(USER, "en"), AbsoluteDate.of("20230227"), "S1");

		Assertions.assertThat(results).isNotNull();
		Assertions.assertThat(results).hasSize(3)
				.containsExactly(
						PublicParcel.builder().setId(1L).setParcel("P1").build(),
						PublicParcel.builder().setId(2L).setParcel("P2").build(),
						PublicParcel.builder().setId(3L).setParcel("P3").build()
				);
		verify(mockResource).getParcelsBySectorCode(
				eq("en"), any(User.class), eq(USER.getTenant()), eq("20230227"), eq("S1"), eq(false), eq(false), any());
	}

	// ----- getParcelsByIdIn -----
	@Test
	void test_getParcelsByIdIn_ok() {

		List<Long> ids = LongStream.range(1L, 321L).boxed().collect(Collectors.toList());
		List<PublicParcel> results = client.getParcelsByIdIn(new ReqContext(USER, "en"), AbsoluteDate.of("20230227"), ids, null);

		Assertions.assertThat(results).isNotNull().hasSize(ids.size());
		InOrder inOrder = inOrder(mockResource);
		inOrder.verify(mockResource).getParcelsByIdIn(eq("en"), any(User.class), eq(USER.getTenant()), eq("20230227"),
				eq(false), eq(false), eq(Map.of("parcel_id_list", ids.subList(0, 100))));
		inOrder.verify(mockResource).getParcelsByIdIn(eq("en"), any(User.class), eq(USER.getTenant()), eq("20230227"),
				eq(false), eq(false), eq(Map.of("parcel_id_list", ids.subList(100, 200))));
		inOrder.verify(mockResource).getParcelsByIdIn(eq("en"), any(User.class), eq(USER.getTenant()), eq("20230227"),
				eq(false), eq(false), eq(Map.of("parcel_id_list", ids.subList(200, 300))));
		inOrder.verify(mockResource).getParcelsByIdIn(eq("en"), any(User.class), eq(USER.getTenant()), eq("20230227"),
				eq(false), eq(false), eq(Map.of("parcel_id_list", ids.subList(300, ids.size()))));
		inOrder.verifyNoMoreInteractions();

	}

	// ----- consumeParcelsByIdIn -----
	@Test
	void test_consumeParcelsByIdIn_ok() {
		List<Long> ids = LongStream.range(1L, 321L).boxed().collect(Collectors.toList());
		AtomicReference<Integer> i = new AtomicReference<>(0);
		client.consumeParcelsByIdIn(new ReqContext(USER, "en"), false, AbsoluteDate.of("20230227"), ids,
				p -> {
					i.getAndSet(i.get() + 1);
				});

		Assertions.assertThat(i.get()).isEqualTo(ids.size());
		InOrder inOrder = inOrder(mockResource);
		inOrder.verify(mockResource).getParcelsByIdIn(eq("en"), any(User.class), eq(USER.getTenant()), eq("20230227"),
				eq(false), eq(false), eq(Map.of("parcel_id_list", ids.subList(0, 100))));
		inOrder.verify(mockResource).getParcelsByIdIn(eq("en"), any(User.class), eq(USER.getTenant()), eq("20230227"),
				eq(false), eq(false), eq(Map.of("parcel_id_list", ids.subList(100, 200))));
		inOrder.verify(mockResource).getParcelsByIdIn(eq("en"), any(User.class), eq(USER.getTenant()), eq("20230227"),
				eq(false), eq(false), eq(Map.of("parcel_id_list", ids.subList(200, 300))));
		inOrder.verify(mockResource).getParcelsByIdIn(eq("en"), any(User.class), eq(USER.getTenant()), eq("20230227"),
				eq(false), eq(false), eq(Map.of("parcel_id_list", ids.subList(300, ids.size()))));
		inOrder.verifyNoMoreInteractions();
	}

	@Path(URL)
	public static class PingResource {
		@GET
		@Path("parcels/{referenceDate}")
		public InfiniteListResults<PublicParcel> searchParcels(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@PathParam("referenceDate") String referenceDate,
				@QueryParam("sector_descr_filter") String sectorDescrFilter,
				@QueryParam("block_descr_filter") String blockDescrFilter,
				@QueryParam("parcel_filter") String parcelFilter,
				@QueryParam("include_landcovers") @DefaultValue("false") Boolean includeLandCovers,
				@QueryParam("include_geometries") @DefaultValue("false") Boolean includeGeometries,
				@QueryParam("next_key") String nextKey) {
			if (sectorDescrFilter != null && sectorDescrFilter.equals("S1") && blockDescrFilter != null && blockDescrFilter.equals("B1")) {
				return new InfiniteListResultsImpl<PublicParcel>(List.of(
						PublicParcel.builder().setId(2L).setParcel("P2").build()
				), null);
			} else {
				return new InfiniteListResultsImpl<PublicParcel>(List.of(
						PublicParcel.builder().setId(1L).setParcel("P1").build(),
						PublicParcel.builder().setId(2L).setParcel("P2").build(),
						PublicParcel.builder().setId(1L).setParcel("P1").build()
				), null);
			}
		}

		@POST
		@Path("parcels/{referenceDate}")
		public PublicParcelsList getParcelsByIdIn(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@PathParam("referenceDate") String referenceDate,
				@QueryParam("include_landcovers") @DefaultValue("false") Boolean includeLandCovers,
				@QueryParam("include_geometries") @DefaultValue("false") Boolean includeGeometries,
				@NotNull @Valid Map<String, List<Long>> payload) {
			return PublicParcelsList.builder()
					.setParcelsList(payload.get("parcel_id_list")
							.stream()
							.map(id -> PublicParcel.builder()
									.setId(id)
									.setParcel(StringUtils.leftPad(id.toString(), 5, "0"))
									.build())
							.collect(Collectors.toList()))
					.build();
		}

		@GET
		@Path("sectors/{sector_code}/parcels/{reference_date}")
		public InfiniteListResults<PublicParcel> getParcelsBySectorCode(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@PathParam("reference_date") String referenceDate,
				@PathParam("sector_code") String sectorCode,
				@QueryParam("include_landcovers") @DefaultValue("false") Boolean includeLandCovers,
				@QueryParam("include_geometries") @DefaultValue("false") Boolean includeGeometries,
				@QueryParam("next_key") String nextKey) {

			return new InfiniteListResultsImpl<PublicParcel>(List.of(
					PublicParcel.builder().setId(1L).setParcel("P1").build(),
					PublicParcel.builder().setId(2L).setParcel("P2").build(),
					PublicParcel.builder().setId(3L).setParcel("P3").build()
			), null);
		}
	}
}

