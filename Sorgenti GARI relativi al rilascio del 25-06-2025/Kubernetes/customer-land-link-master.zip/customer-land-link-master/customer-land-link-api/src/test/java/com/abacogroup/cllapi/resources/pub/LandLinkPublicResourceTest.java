package com.abacogroup.cllapi.resources.pub;

import static com.abacogroup.cllapi.core.client.WebCliHelper.BASIC_USERNAME;
import static com.abacogroup.cllapi.core.client.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import com.abacogroup.cllapi.api.BlockRes;
import com.abacogroup.cllapi.api.GroupBaseRes;
import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.api.LandLinkRes.LandLinkResBuilder;
import com.abacogroup.cllapi.api.ParcelRes;
import com.abacogroup.cllapi.api.SectorRes;
import com.abacogroup.cllapi.api.TitleType;
import com.abacogroup.cllapi.core.LandLinkV1Service;
import com.abacogroup.cllapi.core.client.WebCliHelper;
import com.abacogroup.cllapi.core.impl.LandLinkV1ServiceImpl;
import com.abacogroup.cllcli.api.v1.LandLinkSectorSummaryResponseV1;
import com.abacogroup.cllcli.api.v1.LandLinkTitleSummaryResponseV1;
import com.abacogroup.cllcli.api.v1.TitleTypeReponseV1;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.api.v1.PublicParcelSector;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.UriBuilder;

@ExtendWith(DropwizardExtensionsSupport.class)
class LandLinkPublicResourceTest {

	private final LandLinkV1Service landLinkService = Mockito.mock(LandLinkV1ServiceImpl.class);

	private final ResourceExtension EXT = WebCliHelper.createEXT(new LandLinkPublicResource(landLinkService));



	// ----- getLandLinkSummary -----
	@Test
	void test_getLandLinkSummary_ok() {
		Long partyId = 555L;

		UriBuilder uriBuilder = UriBuilder.fromResource(LandLinkPublicResource.class).path(LandLinkPublicResource.class, "getLandLinkSummary");
		String uri = uriBuilder.build(TENANT, partyId).toString();
		System.out.println(uri);

		List<LandLinkSectorSummaryResponseV1> mockRes = List.of(
				buildSectorSummary(15L, 37485L, 37485L, 123L, "A061", "AFFI (VR)",
						buildTitleSummary(11L, 27000L, 27000L, 1L, "PROPRIETA"),
						buildTitleSummary(4L, 10485L, 10485L, 2L, "AFFITTO"),
						buildTitleSummary(0L, 0L, 0L, 3L, "MEZZADRIA"),
						buildTitleSummary(0L, 0L, 0L, 4L, "ALTRA FORMA"),
						buildTitleSummary(0L, 0L, 0L, 5L, "USO CIVICO")),
				buildSectorSummary(5L, 17485L, 7485L, 456L, "A737", "BELFIORE (VR)",
						buildTitleSummary(0L, 0L, 0L, 1L, "PROPRIETA"),
						buildTitleSummary(5L, 17485L, 7485L, 2L, "AFFITTO"),
						buildTitleSummary(0L, 0L, 0L, 3L, "MEZZADRIA"),
						buildTitleSummary(0L, 0L, 0L, 4L, "ALTRA FORMA"),
						buildTitleSummary(0L, 0L, 0L, 5L, "USO CIVICO"))
		);
		given(landLinkService.getSummary(any(), anyLong())).willReturn(mockRes);

		List<LandLinkSectorSummaryResponseV1> res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(landLinkService).getSummary(reqCtxCaptor.capture(), eq(partyId));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}



	// ################################################################################################################################################## //

	private static LandLinkSectorSummaryResponseV1 buildSectorSummary(long linkCount, long totParcelAreaSqm, long totTitleTypeAreaSqm, long id, String sectorCode,
			String shortDescr, LandLinkTitleSummaryResponseV1... titleSummaryRes) {
		return LandLinkSectorSummaryResponseV1.builder()
				.setLinkCount(linkCount)
				.setTotParcelAreaSqm(totParcelAreaSqm)
				.setTotTitleTypeAreaSqm(totTitleTypeAreaSqm)
				.setSector(PublicParcelSector.builder()
						.setId(id)
						.setSectorCode(sectorCode)
						.setShortDescr(shortDescr)
						.setDescription(shortDescr + " - " + sectorCode)
						.build())
				.setTitleSummaryRes(List.of(titleSummaryRes))
				.build();
	}

	private static LandLinkTitleSummaryResponseV1 buildTitleSummary(long linkCount, long totParcelAreaSqm, long totTitleTypeAreaSqm, long id, String code) {
		return LandLinkTitleSummaryResponseV1.builder()
				.setLinkCount(linkCount)
				.setTotParcelAreaSqm(totParcelAreaSqm)
				.setTotTitleTypeAreaSqm(totTitleTypeAreaSqm)
				.setTitleType(TitleTypeReponseV1.builder()
						.setId(id)
						.setCode(code)
						.setFlDayToReq(0)
						.setFlDayToEditable(0)
						.setFlAllowFutureDayFrom(0)
						.setI18nCode(code)
						.build())
				.build();
	}

	private static LandLinkResBuilder<?, ?> landLinkResBuilder(Long partyId, Long groupId) {
		return LandLinkRes.builder()
				.setId(-1L)
				.setGroup(GroupBaseRes.builder()
						.setId(groupId)
						.setDescr("Group " + groupId)
						.build())
				.setPartyId(partyId)
				.setTitleType(TitleType.builder()
						.setId(-1L)
						.setI18nCode("TITLE TYPE 1")
						.setCode("TT1")
						.setFlDayToReq(0)
						.build())
				.setTitleTypePerc(BigDecimal.valueOf(100).setScale(8, RoundingMode.HALF_UP))
				.setParcel(
						ParcelRes.builder()
								.setParcel("01234/A")
								.setSector(SectorRes.builder()
										.setSectorCode("A001")
										.build())
								.setBlock(BlockRes.builder()
										.setBlockCode("1")
										.build())
								.setAreaSqm(15000L)
								.build()
				)
				.setDayFrom(AbsoluteDate.of("20200202"))
				.setDayTo(AbsoluteDate.of("99991231"))
				.setMaxAnomalyLevel(null);
	}

}
