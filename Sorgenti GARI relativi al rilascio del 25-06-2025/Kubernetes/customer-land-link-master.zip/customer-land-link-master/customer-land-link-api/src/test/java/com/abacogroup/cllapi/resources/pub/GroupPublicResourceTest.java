package com.abacogroup.cllapi.resources.pub;

import static com.abacogroup.cllapi.core.client.WebCliHelper.BASIC_USERNAME;
import static com.abacogroup.cllapi.core.client.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import com.abacogroup.cllapi.api.BlockRes;
import com.abacogroup.cllapi.api.GroupBaseRes;
import com.abacogroup.cllapi.api.GroupRes;
import com.abacogroup.cllapi.api.GroupRes.GroupResBuilder;
import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.api.LandLinkRes.LandLinkResBuilder;
import com.abacogroup.cllapi.api.ParcelRes;
import com.abacogroup.cllapi.api.SectorRes;
import com.abacogroup.cllapi.api.TitleType;
import com.abacogroup.cllapi.api.req.GroupCreateReq;
import com.abacogroup.cllapi.api.req.LandLinkBatchCreateReq;
import com.abacogroup.cllapi.api.req.LandLinkBatchCreateReq.LandLinkBatchCreateReqBuilder;
import com.abacogroup.cllapi.core.GroupService;
import com.abacogroup.cllapi.core.client.WebCliHelper;
import com.abacogroup.cllapi.core.impl.GroupServiceImpl;
import com.abacogroup.cllcli.api.v1.GroupResponseV1;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.UriBuilder;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class GroupPublicResourceTest {

	private final GroupService groupService = Mockito.mock(GroupServiceImpl.class);

	private final GroupPublicResource resource = new GroupPublicResource(groupService);
	private final ResourceExtension EXT = WebCliHelper.createEXT(resource);

	// ----- createGroup -----
	@Test
	void test_createGroup_ok() {
		Long partyId = 555L;
		Long groupId = 111L;
		String uri = UriBuilder.fromResource(resource.getClass())//.path(resource.getClass(), "createGroup")
				.build(TENANT, partyId).toString();
		System.out.println(uri);

		GroupRes mockRes = groupResBuilder(groupId, partyId).build();
		given(groupService.insert(any(), anyLong(), any())).willReturn(mockRes);
		GroupCreateReq groupCreateReq = GroupCreateReq.builder()

				.setTitleTypeId(111L)
				.setDescr("test group")
				.setDayFrom(AbsoluteDate.of("20211202"))
				.setDayTo(AbsoluteDate.of("99991231"))
				.setLandLinks(List.of(landLinkBatchCreateReqBuilder().build()))
				.build();

		GroupResponseV1 res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.post(Entity.json(groupCreateReq), new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.usingRecursiveComparison()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupService).insert(reqCtxCaptor.capture(), eq(partyId), eq(groupCreateReq));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// ################################################################################################################################################## //

	private static LandLinkResBuilder<?, ?> landLinkResBuilder(Long partyId, Long groupId) {
		return LandLinkRes.builder()
				.setId(-1L)
				.setGroup(GroupBaseRes.builder()
						.setId(groupId)
						.setDescr("Group "+groupId)
						.build())
				.setPartyId(partyId)
				.setTitleType(TitleType.builder()
						.setId(-1L)
						.setI18nCode("TITLE TYPE 1")
						.setCode("TT1")
						.setFlDayToReq(0)
						.build())
				.setTitleTypePerc(BigDecimal.valueOf(100).setScale(8, RoundingMode.HALF_UP))
				.setParcel(
						ParcelRes.builder()
								.setParcel("01234/A")
								.setSector(SectorRes.builder()
										.setSectorCode("A001")
										.build())
								.setBlock(BlockRes.builder()
										.setBlockCode("1")
										.build())
								.setAreaSqm(15000L)
								.build()
				)
				.setDayFrom(AbsoluteDate.of("20200202"))
				.setDayTo(AbsoluteDate.of("99991231"))
				.setMaxAnomalyLevel(null);
	}

	private static LandLinkBatchCreateReqBuilder<?, ?> landLinkBatchCreateReqBuilder() {
		return landLinkBatchCreateReqBuilder(100, 123456L, "A001", "1");
	}

	private static LandLinkBatchCreateReqBuilder<?, ?> landLinkBatchCreateReqBuilder(double perc, long parcelId, String sectorCode, String blockCode) {
		return LandLinkBatchCreateReq.builder()
				.setTitleTypePerc(BigDecimal.valueOf(perc))
				.setParcelId(parcelId);
	}

	private static GroupResBuilder<?, ?> groupResBuilder() {
		return groupResBuilder(-1L, 555L);
	}

	private static GroupResBuilder<?, ?> groupResBuilder(long id, long partyId) {
		return GroupRes.builder()
				.setId(id)
				.setDescr("mock group 1")
				.setPartyId(partyId)
				.setTitleType(TitleType.builder()
						.setId(-1L)
						.setI18nCode("TITLE TYPE 1")
						.setCode("TT1")
						.setFlDayToReq(0)
						.build())
				.setDayFrom(AbsoluteDate.of("20200202"))
				.setDayTo(AbsoluteDate.of("99991231"))
				.setLinkCount(7L);
	}

}
