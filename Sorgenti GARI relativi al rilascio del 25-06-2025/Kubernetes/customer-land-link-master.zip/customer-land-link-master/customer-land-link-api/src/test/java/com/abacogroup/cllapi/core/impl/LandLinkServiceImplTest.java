package com.abacogroup.cllapi.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;
import static org.assertj.core.api.AssertionsForClassTypes.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyTypeClient;
import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.api.AnomalySearchRes;
import com.abacogroup.cllapi.api.GroupBaseRes;
import com.abacogroup.cllapi.api.LandLinkAnomaliesRes;
import com.abacogroup.cllapi.api.LandLinkLeadingRes;
import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.api.LandLinkSectorSummaryRes;
import com.abacogroup.cllapi.api.LandLinkTitleSummaryRes;
import com.abacogroup.cllapi.api.TitleType;
import com.abacogroup.cllapi.api.req.LandLinkBatchCreateReq;
import com.abacogroup.cllapi.api.req.LandLinkBatchCreateReq.LandLinkBatchCreateReqBuilder;
import com.abacogroup.cllapi.api.req.LandLinkSearchReq;
import com.abacogroup.cllapi.api.req.LandLinkUpdateReq;
import com.abacogroup.cllapi.core.AnomalyService;
import com.abacogroup.cllapi.core.LandLinkService;
import com.abacogroup.cllapi.core.LpisClientService;
import com.abacogroup.cllapi.core.embededqueue.AnomalyHelper;
import com.abacogroup.cllapi.db.dao.AnomaliesDAO;
import com.abacogroup.cllapi.db.dao.CllSettingsDAO;
import com.abacogroup.cllapi.db.ntt.CllSettingsEntity;
import com.abacogroup.cllapi.db.ntt.LandLinkEntity;
import com.abacogroup.cllapi.db.ntt.LandLinkEntity.LandLinkEntityBuilder;
import com.abacogroup.cllapi.exceptions.LandLinkException;
import com.abacogroup.cllapi.exceptions.LandLinkException.ErrEnum;
import com.abacogroup.cllcli.api.v1.AnomalyLevelEnum;
import com.abacogroup.cllcli.api.v1.enums.ParcelSearchLevel;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lpisgisserver.api.v1.PublicParcel;
import com.abacogroup.lpisgisserver.api.v1.PublicParcelBlock;
import com.abacogroup.lpisgisserver.api.v1.PublicParcelSector;
import com.abacogroup.lpisgisserver.api.v1.PublicSector;
import com.abacogroup.testcommon.ReqContextUtils;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Stream;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.api.Assertions;
import org.assertj.core.data.Percentage;
import org.assertj.core.groups.Tuple;
import org.jdbi.v3.core.Handle;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

@ExtendWith(DropwizardExtensionsSupport.class)
class LandLinkServiceImplTest extends JdbiTest {

    private AnomaliesDAO anomaliesDAO = mock(AnomaliesDAO.class);
    private AnomalyTypeClient anomalyTypeClient = mock(AnomalyTypeClient.class);
    private AnomalyService anomalyService = getService(AnomalyServiceImpl.class);

    private final LandLinkService landLinkService = getService(LandLinkServiceImpl.class);
    private final ReqContextUtils ctx = new ReqContextUtils(this.getClass());

    @BeforeEach
    void setUp() {
        injectMock(anomalyService, anomaliesDAO);
        injectMock(anomalyService, anomalyTypeClient);
        ((AnomalyServiceImpl) anomalyService).resetCache();
    }

    @Test
    void test_searchByParcelIdAndRange() {
        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            List<String> initScripts = List.of("link_crud_01", "add_links", "add_more_links");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            Long parcelId = 123105L;
            AbsoluteDate dayFrom = AbsoluteDate.of("20230301");

            List<LandLinkLeadingRes> links = landLinkService
                    .searchByParcelIdAndRange(
                            ctx.getReqContext(),
                            parcelId,
                            dayFrom,
                            AbsoluteDate.of(AuditEntity.dateActive)
                    );

            assertThat(links).hasSize(2).extracting(
                    LandLinkLeadingRes::getId
            ).containsExactly(-105L, -104L);

            assertThat(links).hasSize(2).extracting(
                    LandLinkLeadingRes::getDayTo
            ).allMatch(date -> date.toLocalDate().isAfter(dayFrom.toLocalDate()));

            handle.rollback();
        });
    }

    @Test
    void should_searchLandLinksByPartyIdAndRange() {
        //searchByPartyIdAndRange_01.sql

        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();
            List<String> initScripts = List.of("searchByPartyIdAndRange_01");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            //2021 2022 2023
            List<LandLinkEntity> list = new ArrayList<>(((LandLinkServiceImpl) landLinkService).findByPartyIdAndParcelIdInAndGroupNotInRange(
                    ctx.getReqContext(),
                    666L,
                    -1L,
                    AbsoluteDate.of("20210101"),
                    AbsoluteDate.of("20231231"),
                    List.of(697674L)
            ));

            assertThat(list).hasSize(2);

            handle.rollback();

        });
    }

    // ----- search -----
    @Test
    void test_search_mappingOK() {
        Clock clock = mock(Clock.class);
        injectMock(landLinkService, clock);
        LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 14, 17, 44);
        given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
        given(clock.getZone()).willReturn(ZoneId.of("UTC"));
                
        LpisClientService lpisClientService = mock(LpisClientService.class);
        PublicParcel mockParcel = buildMockParcel(40103L, 123456L, "3", null, 4L, "AFFI (VR)", 1);
        injectMock(landLinkService, lpisClientService);
        doAnswer(i -> {
            ((Consumer<PublicParcel>) i.getArgument(4)).accept(mockParcel);
            return null;
        }).when(lpisClientService).consumeParcelsByIdIn(any(), any(), any(), any(), any());

        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            givenCloseDayConfig(handle, true);
            List<String> initScripts = List.of("search_test_data");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            long partyId = 555L;
            LandLinkSearchReq searchRequest = new LandLinkSearchReq()
                    .setPartyId(partyId)
                    .setSectorCode("a004")
                    .setBlockCode("1")
                    .setParcelCode("3");
            InfiniteListResults<LandLinkRes> searchRes = landLinkService.search(ctx.getReqContext(), AbsoluteDate.of(now), searchRequest, true, null, null);

            assertThat(searchRes).isNotNull();
            assertThat(searchRes.getRecords()).hasSize(1)
                    .element(0)
                    .satisfies(res -> {
                        assertThat(res.getId()).isEqualTo(-14301L);
                        assertThat(res.getPartyId()).isEqualTo(555L);
                        assertThat(res.getGroup()).isEqualTo(GroupBaseRes.builder()
                                .setId(-3L).setDescr("GROUP 3").build());
                        assertThat(res.getTitleType())

                                .isEqualTo(TitleType.builder()
                                        .setId(-3L).setCode("TEST").setI18nCode("TEST")
                                        .setDayToReq(true)
                                        .setFlDayToReq(1)
                                        .setDayToEditable(true)
                                        .setFlDayToEditable(1)
                                        .setAllowFutureDayFrom(false)
                                        .setFlAllowFutureDayFrom(0)
                                        .build());
                        assertThat(res.getTitleTypePerc()).isCloseTo(new BigDecimal("0.01"), Percentage.withPercentage(0));
                        assertThat(res.getTitleTypeAreaSqm()).isEqualTo(mockParcel.getAreaSqm() / 10000);
                        assertThat(res.getParcel()).isNotNull()
                                .usingRecursiveComparison()
                                .isEqualTo(mockParcel);
                        assertThat(res.getDayFrom()).isEqualTo(AbsoluteDate.of("20200202"));
                        assertThat(res.getDayTo()).isEqualTo(AbsoluteDate.of("20300302"));
                        assertThat(res.getMaxAnomalyLevel()).isNull();
                    });

            handle.rollback();
        });
    }

    @MethodSource("com.abacogroup.cllapi.core.impl.LandLinkServiceImplTestSources#test_search_ok")
    @ParameterizedTest
    void test_search_ok(String ignoredTitle, LandLinkSearchReq searchRequest, AbsoluteDate referenceDate, Tuple[] tuples) {
        Clock clock = mock(Clock.class);
        injectMock(landLinkService, clock);
        LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 14, 17, 44);
        given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
        given(clock.getZone()).willReturn(ZoneId.of("UTC"));

        LpisClientService lpisClientService = mock(LpisClientService.class);
        injectMock(landLinkService, lpisClientService);

        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();
            
            givenCloseDayConfig(handle, true);
            
            List<String> initScripts = List.of("search_test_data");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            String nextKey = null;
            List<LandLinkRes> resList = new ArrayList<>();
            do {
                InfiniteListResults<LandLinkRes> searchRes = landLinkService.search(ctx.getReqContext(), referenceDate, searchRequest, true, nextKey, null);
                resList.addAll(searchRes.getRecords());
                nextKey = searchRes.getNextKey();
            } while (nextKey != null);

            assertThat(resList)
                    .hasSize(tuples.length)
                    .extracting(
                            LandLinkRes::getId,
                            landLinkRes -> landLinkRes.getParcel().getId()
                    ).containsExactlyInAnyOrder(tuples);

            handle.rollback();
        });
    }

    @Test
    void test_search_MappingAnomaliesOK() {
        Clock clock = mock(Clock.class);
        injectMock(landLinkService, clock);
        LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 24, 15, 55);
        given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
        given(clock.getZone()).willReturn(ZoneId.of("UTC"));

        LpisClientService lpisClientService = mock(LpisClientService.class);
        injectMock(landLinkService, lpisClientService);

        given(anomaliesDAO.search(any(), any(), eq(AnomalyHelper.PARCEL_ENTITY_CODE), any(), any()))
                .willReturn(List.of(
                        givenAnomalySearchRes("10101", "01", AnomalyLevelEnum.INFO), // info
                        givenAnomalySearchRes("202011", "00", null),
                        givenAnomalySearchRes("30102", "01", AnomalyLevelEnum.INFO),
                        givenAnomalySearchRes("30102", "03", AnomalyLevelEnum.DANGER), // danger
                        givenAnomalySearchRes("30101", "02", AnomalyLevelEnum.WARN), // warn
                        givenAnomalySearchRes("30101", "02", AnomalyLevelEnum.WARN),
                        givenAnomalySearchRes("12502", "00", null), // null
                        givenAnomalySearchRes("30101", "02", AnomalyLevelEnum.WARN),
                        givenAnomalySearchRes("30102", "02", AnomalyLevelEnum.WARN),
                        givenAnomalySearchRes("10203", "not_mine", null), // null
                        givenAnomalySearchRes("202011", "02", AnomalyLevelEnum.WARN) // warn
                ));
        given(anomalyTypeClient.searchAll(any(), any(), any())).willReturn(new ArrayList<>());

        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            givenCloseDayConfig(handle, true);
            //List<String> initScripts = List.of("search_test_data", "anomaly_categories");
            List<String> initScripts = List.of("search_test_data");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            long partyId = 555L;
            LandLinkSearchReq searchRequest = new LandLinkSearchReq()
                    .setPartyId(partyId);
            InfiniteListResults<LandLinkRes> searchRes = landLinkService.search(ctx.getReqContext(), AbsoluteDate.of(now), searchRequest, true, null, null);

            assertThat(searchRes).isNotNull();
            assertThat(searchRes.getRecords()).hasSize(10)
                    .extracting(
                            LandLinkRes::getId,
                            LandLinkRes::getMaxAnomalyLevel,
                            LandLinkRes::getAnomalyCount
                    ).containsExactlyInAnyOrder(
                            tuple(-11101L, AnomalyLevelEnum.INFO, 1L),
                            tuple(-11102L, null, 0L), // 00
                            tuple(-11103L, null, 0L), // not_mine
                            tuple(-12101L, AnomalyLevelEnum.WARN, 1L),
                            tuple(-12102L, null, 0L),
                            tuple(-12301L, null, 0L),
                            tuple(-12302L, null, 0L),
                            tuple(-11201L, null, 0L),
                            tuple(-13201L, AnomalyLevelEnum.WARN, 3L),
                            tuple(-13202L, AnomalyLevelEnum.DANGER, 3L)
                    );

            handle.rollback();
        });
    }

    @Disabled
    @Test
    void test_data_ok() {
        for (int i = 1; i < 50; i++) {
            String id = StringUtils.leftPad(String.valueOf(i), 3, '0');
            System.out.println(
                    "insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)");
            System.out.printf(
                    "values (-1%s, -1%s, 1%s, '00%s', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);\n",
                    id, id, id, id);
        }

		assertTrue(true);
    }

    @Test
    void test_search_anomaliesOK() {
        Clock clock = mock(Clock.class);
        injectMock(landLinkService, clock);
        LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 24, 15, 55);
        given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
        given(clock.getZone()).willReturn(ZoneId.of("UTC"));
		
        LpisClientService lpisClientService = mock(LpisClientService.class);
        injectMock(landLinkService, lpisClientService);

        given(anomaliesDAO.search(any(), any(), eq(AnomalyHelper.PARCEL_ENTITY_CODE), any(), any()))
                .willReturn(List.of( // x 2
                        givenAnomalySearchRes("1001", "01", AnomalyLevelEnum.INFO),
                        givenAnomalySearchRes("1002", "02", AnomalyLevelEnum.WARN),
                        givenAnomalySearchRes("1003", "03", AnomalyLevelEnum.DANGER),
                        givenAnomalySearchRes("1008", "03", AnomalyLevelEnum.DANGER),
                        givenAnomalySearchRes("1008", "02", AnomalyLevelEnum.WARN),
                        givenAnomalySearchRes("1008", "01", AnomalyLevelEnum.INFO)
                ))
                .willReturn(List.of( // x 3
                        givenAnomalySearchRes("1011", "01", AnomalyLevelEnum.INFO),
                        givenAnomalySearchRes("1011", "WD40", AnomalyLevelEnum.INFO),
                        givenAnomalySearchRes("1012", "02", AnomalyLevelEnum.WARN),
                        givenAnomalySearchRes("1013", "03", AnomalyLevelEnum.DANGER),
                        givenAnomalySearchRes("1015", "00", null),
                        givenAnomalySearchRes("1016", "WD40", AnomalyLevelEnum.INFO),
                        givenAnomalySearchRes("1018", "03", AnomalyLevelEnum.DANGER),
                        givenAnomalySearchRes("1018", "02", AnomalyLevelEnum.WARN),
                        givenAnomalySearchRes("1018", "01", AnomalyLevelEnum.INFO)
                ))
                .willReturn(List.of( // x 7
                        givenAnomalySearchRes("1021", "01", AnomalyLevelEnum.INFO),
                        givenAnomalySearchRes("1022", "01", AnomalyLevelEnum.INFO),
                        givenAnomalySearchRes("1023", "01", AnomalyLevelEnum.INFO),
                        givenAnomalySearchRes("1024", "01", AnomalyLevelEnum.INFO),
                        givenAnomalySearchRes("1027", "01", AnomalyLevelEnum.INFO),
                        givenAnomalySearchRes("1029", "01", AnomalyLevelEnum.INFO),
                        givenAnomalySearchRes("1030", "01", AnomalyLevelEnum.INFO)
                ));
        given(anomalyTypeClient.searchAll(any(), any(), any())).willReturn(new ArrayList<>());

        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            givenCloseDayConfig(handle, true);
            
            //List<String> initScripts = List.of("search_anomalies_test_data", "anomaly_categories");
            List<String> initScripts = List.of("search_anomalies_test_data");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            long partyId = 555L;
            LandLinkSearchReq searchRequest = new LandLinkSearchReq()
                    .setAnomalyLevel(AnomalyLevelEnum.INFO)
                    .setPartyId(partyId);
            InfiniteListResults<LandLinkRes> searchRes = landLinkService.search(ctx.getReqContext(), AbsoluteDate.of(now), searchRequest, true, null, null);

            assertThat(searchRes).isNotNull();
            assertThat(searchRes.getNextKey()).isNotNull().isEqualTo("31");
            assertThat(searchRes.getRecords()).hasSize(12)
                    .extracting(
                            LandLinkRes::getId,
                            LandLinkRes::getMaxAnomalyLevel,
                            LandLinkRes::getAnomalyCount
                    ).containsExactlyInAnyOrder(
                            tuple(-1001L, AnomalyLevelEnum.INFO, 1L),
                            tuple(-1008L, AnomalyLevelEnum.DANGER, 3L),
                            tuple(-1011L, AnomalyLevelEnum.INFO, 2L),
                            tuple(-1016L, AnomalyLevelEnum.INFO, 1L),
                            tuple(-1018L, AnomalyLevelEnum.DANGER, 3L),
                            tuple(-1021L, AnomalyLevelEnum.INFO, 1L),
                            tuple(-1022L, AnomalyLevelEnum.INFO, 1L),
                            tuple(-1023L, AnomalyLevelEnum.INFO, 1L),
                            tuple(-1024L, AnomalyLevelEnum.INFO, 1L),
                            tuple(-1027L, AnomalyLevelEnum.INFO, 1L),
                            tuple(-1029L, AnomalyLevelEnum.INFO, 1L),
                            tuple(-1030L, AnomalyLevelEnum.INFO, 1L)
                    );

            handle.rollback();
        });
    }

    //---- count-----
    @Test
    void test_countAllForSearch_comparingWith_getCount_of_infiniteListResults_ok() {
        Clock clock = mock(Clock.class);
        injectMock(landLinkService, clock);
        LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 14, 17, 44);
        given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
        given(clock.getZone()).willReturn(ZoneId.of("UTC"));

        LpisClientService lpisClientService = mock(LpisClientService.class);
        injectMock(landLinkService, lpisClientService);

        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            givenCloseDayConfig(handle, true);
            
            List<String> initScripts = List.of("search_test_data");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            int totalSize = landLinkService.countAllForSearch(ctx.getReqContext(), AbsoluteDate.of("20230314"), new LandLinkSearchReq());
            Assertions.assertThat(totalSize).isEqualTo(15);

            // use getCount() of InfiniteListResults for the same search
            InfiniteListResults<LandLinkRes> searchRes = landLinkService.search(ctx.getReqContext(), AbsoluteDate.of("20230314"), new LandLinkSearchReq(),
                    true, null, null);
            Assertions.assertThat(searchRes.getCount()).isEqualTo(10); //it returns 10 due to the pageSize=10 while the totalSize=15

            // use count() method
            totalSize = landLinkService.countAllForSearch(ctx.getReqContext(), AbsoluteDate.of("20200101"), new LandLinkSearchReq());
            Assertions.assertThat(totalSize).isEqualTo(4);

            // use getCount() of InfiniteListResults for the same search
            searchRes = landLinkService.search(ctx.getReqContext(), AbsoluteDate.of("20200101"), new LandLinkSearchReq(),
                    true, null, null);
            Assertions.assertThat(searchRes.getCount()).isEqualTo(4); //it returns 4 < the pageSize=10

            handle.rollback();
        });
    }

    // ----- getSummary -----
    @Test
    void test_getSummary_ok() {

        Clock clock = mock(Clock.class);
        injectMock(landLinkService, clock);
        LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 10, 16, 49);
        given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
        given(clock.getZone()).willReturn(ZoneId.of("UTC"));

        LpisClientService lpisClientService = mock(LpisClientService.class);
        injectMock(landLinkService, lpisClientService);
        given(lpisClientService.getSectorDetails(any(), eq("A001")))
                .willReturn(PublicSector.builder().setId(1L).setSectorCode("A001")
                        .setDescription("VILLASOR - A001 (SU)").setShortDescr("VILLASOR (SU)").build());
        given(lpisClientService.getSectorDetails(any(), eq("A002")))
                .willReturn(PublicSector.builder().setId(2L).setSectorCode("A002")
                        .setDescription("ASSEMINI - A002 (CA)").setShortDescr("ASSEMINI (CA)").build());
        given(lpisClientService.getSectorDetails(any(), eq("A003")))
                .willReturn(PublicSector.builder().setId(3L).setSectorCode("A003")
                        .setDescription("DECIMOMANNU - A003 (CA)").setShortDescr("DECIMOMANNU (CA)").build());
        given(lpisClientService.getSectorDetails(any(), eq("A004")))
                .willReturn(PublicSector.builder().setId(4L).setSectorCode("A004")
                        .setDescription("UTA - A004 (CA)").setShortDescr("UTA (CA)").build());
        doAnswer(i -> {
            Stream.of(
                    buildMockParcel(10101L, 15987L), // A001 t1 %100
                    buildMockParcel(12502L, 30000L), // A001 t1 %33.33333333
                    buildMockParcel(10203L, 59688L), // A001 t1 %50
                    buildMockParcel(10204L, 9963L), // A001 t2 %100
                    buildMockParcel(20201L, 23232L), // A002 t1 %100
                    buildMockParcel(20502L, 88888L), // A002 t1 %50
                    buildMockParcel(20205L, 12023L), // A002 t3 %100
                    buildMockParcel(20305L, 88888L), // A002 t3 %75
                    buildMockParcel(30101L, 12458L), // A003 t2 %100
                    buildMockParcel(30102L, 9236L), // A003 t2 %100
                    buildMockParcel(30103L, 19992L), // A003 t2 %100
                    buildMockParcel(40101L, 25000L), // A004 t1 %100
                    buildMockParcel(40102L, 25000L), // A004 t2 %100
                    buildMockParcel(40103L, 50000L)  // A004 t3 %100
            ).forEach(i.getArgument(4));
            return null;
        }).when(lpisClientService).consumeParcelsByIdIn(any(), any(), any(), any(), any());

        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            List<String> initScripts = List.of("summary_test_data");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            long partyId = 555L;
            List<LandLinkSectorSummaryRes> summary = landLinkService.getSummary(ctx.getReqContext(), partyId);

            assertThat(summary).hasSize(4);
            assertThat(summary).extracting("sector.sectorCode")
                    .containsExactly("A002", "A003", "A004", "A001");
            assertThat(summary).extracting(LandLinkSectorSummaryRes::getLinkCount)
                    .containsExactly(4L, 3L, 3L, 4L);
            assertThat(summary).extracting(LandLinkSectorSummaryRes::getTotParcelAreaSqm)
                    .containsExactly(213031L, 41686L, 100000L, 115638L);
            assertThat(summary).extracting(LandLinkSectorSummaryRes::getTotTitleTypeAreaSqm)
                    .containsExactly(146365L, 41686L, 100000L, 65794L);
            assertThat(summary).extracting(LandLinkSectorSummaryRes::getTitleSummaryRes)
                    .allSatisfy(ts -> assertThat(ts)
                            .extracting(landLinkTitleSummaryRes -> landLinkTitleSummaryRes.getTitleType().getId())
                            .containsExactly(-3L, -2L, -1L));
            assertThat(summary.get(0).getTitleSummaryRes()).extracting(LandLinkTitleSummaryRes::getTotTitleTypeAreaSqm)
                    .containsExactly(78689L, 0L, 67676L);
            assertThat(summary.get(1).getTitleSummaryRes()).extracting(LandLinkTitleSummaryRes::getTotTitleTypeAreaSqm)
                    .containsExactly(0L, 41686L, 0L);
            assertThat(summary.get(2).getTitleSummaryRes()).extracting(LandLinkTitleSummaryRes::getTotTitleTypeAreaSqm)
                    .containsExactly(50000L, 25000L, 25000L);
            assertThat(summary.get(3).getTitleSummaryRes()).extracting(LandLinkTitleSummaryRes::getTotTitleTypeAreaSqm)
                    .containsExactly(0L, 9963L, 55831L);

            handle.rollback();
        });
    }

    // ----- expireMany -----
    @Test
    void test_expireMany_ok() {
        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            List<String> initScripts = List.of("link_crud_01", "add_links");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            List<Long> ids = List.of(-101L, -102L, -103L);
            String sql = " select count(*) from cll_land_link_detail where id in (<ids>) " +
                    " and (§current_timestamp§ between dt_insert and dt_delete) ";
            assertThat(handle.select(sql)
                    .bindList("ids", ids)
                    .mapTo(Integer.class).first()).isEqualTo(3);

            landLinkService.expireMany(ctx.getReqContext(), ids);

            assertThat(handle.select(sql)
                    .bindList("ids", ids)
                    .mapTo(Integer.class).first()).isEqualTo(0);

            handle.rollback();
        });
    }

    // ----- expireByGroup -----
    @Test
    void test_expireByGroup_ok() {
        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            List<String> initScripts = List.of("link_crud_01", "add_links");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            long groupId = -1L;
            long partyId = -1L;
            String sql = " select count(*) from cll_land_link_detail where group_id = ? " +
                    " and (§current_timestamp§ between dt_insert and dt_delete) ";
            assertThat(handle.select(sql, groupId)
                    .mapTo(Integer.class).first()).isEqualTo(4);

            landLinkService.expireByGroup(ctx.getReqContext(), partyId, groupId);

            assertThat(handle.select(sql, groupId)
                    .mapTo(Integer.class).first()).isEqualTo(0);

            handle.rollback();
        });
    }

    // ----- closeByGroups -----
    @Test
    void test_closeByGroups_ok() {

        Clock clock = mock(Clock.class);
        injectMock(landLinkService, clock);
        LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 1, 12, 6);
        given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
        given(clock.getZone()).willReturn(ZoneId.of("UTC"));

        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            givenCloseDayConfig(handle, false);
            List<String> initScripts = List.of("link_crud_01", "add_links");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            long groupId = -1L;
            String sql = " select day_to from cll_land_link_detail where group_id = ? " +
                    " and (§current_timestamp§ between dt_insert and dt_delete) ";
            assertThat(handle.select(sql, groupId)
                    .mapTo(AbsoluteDate.class).list())
                    .containsExactlyInAnyOrder(
                            AbsoluteDate.of(AuditEntity.dateActive),
                            AbsoluteDate.of(AuditEntity.dateActive),
                            AbsoluteDate.of("20211202"),
                            AbsoluteDate.of("20210531")
                    );

            AbsoluteDate dayTo = AbsoluteDate.of("20221231");
            landLinkService.closeByGroups(ctx.getReqContext(), 555L, List.of(groupId), dayTo);

            assertThat(handle.select(sql, groupId)
                    .mapTo(AbsoluteDate.class).list())
                    .containsExactlyInAnyOrder(dayTo, dayTo, AbsoluteDate.of("20211202"), AbsoluteDate.of("20210531"));

            handle.rollback();
        });
    }

    // ----- closeMany -----
    @Test
    void test_closeMany_ok() {
        Clock clock = mock(Clock.class);
        injectMock(landLinkService, clock);
        LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 1, 12, 6);
        given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
        given(clock.getZone()).willReturn(ZoneId.of("UTC"));

        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            givenCloseDayConfig(handle, true);
            List<String> initScripts = List.of("link_crud_01", "add_links");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            List<Long> ids = List.of(-1011L, -102L);
            String sql = " select day_to from cll_land_link_detail where id in (<ids>) " +
                    " and (§current_timestamp§ between dt_insert and dt_delete) ";
            assertThat(handle.select(sql)
                    .bindList("ids", ids)
                    .mapTo(AbsoluteDate.class).list())
                    .containsExactlyInAnyOrder(
                            AbsoluteDate.of(AuditEntity.dateActive),
                            AbsoluteDate.of(AuditEntity.dateActive)
                    );

            AbsoluteDate dayTo = AbsoluteDate.of("20221231");
            landLinkService.closeMany(ctx.getReqContext(), 555L, ids, dayTo);

            assertThat(handle.select(sql)
                    .bindList("ids", ids)
                    .mapTo(AbsoluteDate.class).list())
                    .containsExactlyInAnyOrder(dayTo, dayTo);

            handle.rollback();
        });
    }

    @Test
    void test_closeMany_alreadyClosedOk() {
        Clock clock = mock(Clock.class);
        injectMock(landLinkService, clock);
        LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 1, 12, 6);
        given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
        given(clock.getZone()).willReturn(ZoneId.of("UTC"));

        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            givenCloseDayConfig(handle, true);
            List<String> initScripts = List.of("link_crud_01", "add_links");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            List<Long> ids = List.of(-102L, -103L);
            String sql = " select day_to from cll_land_link_detail where id in (<ids>) " +
                    " and (§current_timestamp§ between dt_insert and dt_delete) ";
            assertThat(handle.select(sql)
                    .bindList("ids", ids)
                    .mapTo(AbsoluteDate.class).list())
                    .containsExactlyInAnyOrder(
                            AbsoluteDate.of(AuditEntity.dateActive),
                            AbsoluteDate.of("20211202")
                    );

            AbsoluteDate dayTo = AbsoluteDate.of("20201231");
            landLinkService.closeMany(ctx.getReqContext(), 555L, ids, dayTo);

            assertThat(handle.select(sql)
                    .bindList("ids", ids)
                    .mapTo(AbsoluteDate.class).list())
                    .containsExactlyInAnyOrder(dayTo, dayTo);

            handle.rollback();
        });
    }

    @Test
    void test_closeMany_alreadyClosedKoByConfig() {
        Clock clock = mock(Clock.class);
        injectMock(landLinkService, clock);
        LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 1, 12, 6);
        given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
        given(clock.getZone()).willReturn(ZoneId.of("UTC"));

        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            givenCloseDayConfig(handle, false);
            List<String> initScripts = List.of("link_crud_01", "add_links");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            List<Long> ids = List.of(-102L, -103L);
            AbsoluteDate dayTo = AbsoluteDate.of("20201231");
            LandLinkException landLinkException = assertThrows(LandLinkException.class,
                    () -> landLinkService.closeMany(ctx.getReqContext(), 555L, ids, dayTo));

            assertThat(landLinkException).isNotNull()
                    .extracting(LandLinkException::getCode)
                    .isEqualTo(LandLinkException.ErrEnum.CLOSED_LAND_LINK.toString());
            System.out.println(landLinkException.getErrorBody().getMessage());

            handle.rollback();
        });
    }

    @Test
    void test_closeMany_alreadyClosedKoByDayTo() {
        Clock clock = mock(Clock.class);
        injectMock(landLinkService, clock);
        LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 1, 12, 6);
        given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
        given(clock.getZone()).willReturn(ZoneId.of("UTC"));

        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            givenCloseDayConfig(handle, true);
            List<String> initScripts = List.of("link_crud_01", "add_links");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            List<Long> ids = List.of(-101L, -103L);
            AbsoluteDate dayTo = AbsoluteDate.of("20221231");
            LandLinkException landLinkException = assertThrows(LandLinkException.class,
                    () -> landLinkService.closeMany(ctx.getReqContext(), 555L, ids, dayTo));

            assertThat(landLinkException).isNotNull()
                    .extracting(LandLinkException::getCode)
                    .isEqualTo(LandLinkException.ErrEnum.INVALID_DAY_TO.toString());
            System.out.println(landLinkException.getErrorBody().getMessage());

            handle.rollback();
        });
    }

    @Test
    void test_closeMany_closeBeforeDayFromKo() {
        Clock clock = mock(Clock.class);
        injectMock(landLinkService, clock);
        LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 1, 12, 6);
        given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
        given(clock.getZone()).willReturn(ZoneId.of("UTC"));

        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            givenCloseDayConfig(handle, true);
            List<String> initScripts = List.of("link_crud_01", "add_links");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            List<Long> ids = List.of(-101L, -102L);
            AbsoluteDate dayTo = AbsoluteDate.of("20001231");
            LandLinkException landLinkException = assertThrows(LandLinkException.class,
                    () -> landLinkService.closeMany(ctx.getReqContext(), 555L, ids, dayTo));

            assertThat(landLinkException).isNotNull()
                    .extracting(LandLinkException::getCode)
                    .isEqualTo(LandLinkException.ErrEnum.INVALID_DAY_TO.toString());
            System.out.println(landLinkException.getErrorBody().getMessage());

            handle.rollback();
        });
    }

    @Test
    void test_closeMany_sameParcelStartingAfterDayToKO() {
        Clock clock = mock(Clock.class);
        injectMock(landLinkService, clock);
        LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 1, 12, 6);
        given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
        given(clock.getZone()).willReturn(ZoneId.of("UTC"));

        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            givenCloseDayConfig(handle, false);
            List<String> initScripts = List.of("link_crud_01", "add_links");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            List<Long> ids = List.of(-102L, -101L);
            AbsoluteDate dayTo = AbsoluteDate.of("20201231");
            LandLinkException landLinkException = assertThrows(LandLinkException.class,
                    () -> landLinkService.closeMany(ctx.getReqContext(), 555L, ids, dayTo));

            assertThat(landLinkException).isNotNull()
                    .extracting(LandLinkException::getCode)
                    .isEqualTo(ErrEnum.INVALID_DAY_TO.toString());
            System.out.println(landLinkException.getErrorBody().getMessage());

            handle.rollback();
        });
    }

    // ----- closeOne -----
    @Test
    void test_closeOne_KO() {
        Clock clock = mock(Clock.class);
        injectMock(landLinkService, clock);
        // setup today = 2023-03-01
        LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 1, 12, 6);
        given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
        given(clock.getZone()).willReturn(ZoneId.of("UTC"));

        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            givenCloseDayConfig(handle, false);
            List<String> initScripts = List.of("link_crud_01", "add_links");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            // case1 : ll already closed
            Long llAlreadyClosedId = -103L;
            AbsoluteDate dayTo = AbsoluteDate.of("20220201");

            String sql = " select day_to from cll_land_link_detail"
                    + " WHERE tenant_id = :tenantId and id = :id "
                    + " and (§current_timestamp§ between dt_insert and dt_delete) ";

            assertThat(handle.select(sql)
                    .bind("id", llAlreadyClosedId)
                    .bind("tenantId", ctx.getTenantId())
                    .mapTo(AbsoluteDate.class)
                    .equals(AbsoluteDate.of("20211202")));

            assertThatThrownBy(() -> {
                landLinkService.closeOne(ctx.getReqContext(), 555L, llAlreadyClosedId, dayTo);
            }).isInstanceOf(LandLinkException.class)
                    .hasMessageContaining("was closed");

            //case 3 : dayTo out of range [newDayTo < dayFrom]
            Long llId = -102L;
            LandLinkEntity entity = landLinkService.loadEntity(ctx.getTenantId(), llId).orElse(null);
            AbsoluteDate invalidDayTo = AbsoluteDate.of("20191231");

            assertThat(entity.getDayFrom()).isEqualTo(AbsoluteDate.of("20200202"));
            assertThat(entity.getDayTo()).isEqualTo(AbsoluteDate.of("99991231"));

            assertThatThrownBy(() -> {
                landLinkService.closeOne(ctx.getReqContext(), 555L, entity.getId(), invalidDayTo);
            }).isInstanceOf(LandLinkException.class)
                    .hasMessageContaining("invalid date range");

            handle.rollback();
        });
    }

    // ----- update -----
    @Test
    void test_update_ok() {
        Clock clock = mock(Clock.class);
        injectMock(landLinkService, clock);
        LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 15, 15, 24);
        given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
        given(clock.getZone()).willReturn(ZoneId.of("UTC"));

        LpisClientService lpisClientService = mock(LpisClientService.class);
        PublicParcel mockParcel = buildMockParcel(123102L, 123456L, "3", null, 4L, "AFFI (VR)", 1);
        injectMock(landLinkService, lpisClientService);
        given(lpisClientService.getParcelById(any(), any(), any())).willReturn(Optional.of(mockParcel));

        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            List<String> initScripts = List.of("link_crud_01", "add_links");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            long llId = -102L;
            LandLinkUpdateReq updateReq = LandLinkUpdateReq.builder()
                    .setTitleTypePerc(BigDecimal.valueOf(81.0005184))
                    .build();

            LandLinkRes linkRes = landLinkService.update(ctx.getReqContext(), 555L, llId, updateReq);

            assertThat(linkRes).isNotNull()
                    .extracting(LandLinkRes::getTitleTypeAreaSqm).isEqualTo(100000L);
            String sql = " select title_type_perc from cll_land_link_detail where id = ? " +
                    " and (§current_timestamp§ between dt_insert and dt_delete) ";
            assertThat(handle.select(sql, llId)
                    .mapTo(BigDecimal.class).first())
                    .isCloseTo(updateReq.getTitleTypePerc(), Percentage.withPercentage(0));

            handle.rollback();
        });
    }

    // ----- getAnomalies -----
    @Test
    void test_getAnomalies_ok() {
        Clock clock = mock(Clock.class);
        injectMock(landLinkService, clock);
        LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 24, 18, 00);
        given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
        given(clock.getZone()).willReturn(ZoneId.of("UTC"));
		
        String parcelId = "30102";
        given(anomaliesDAO.search(any(), any(), eq(AnomalyHelper.PARCEL_ENTITY_CODE), any(), any()))
                .willReturn(List.of(
                        givenAnomalySearchRes(parcelId, "01", AnomalyLevelEnum.INFO),
                        givenAnomalySearchRes(parcelId, "VAT69", AnomalyLevelEnum.DANGER),
                        givenAnomalySearchRes(parcelId, "01", AnomalyLevelEnum.INFO),
                        givenAnomalySearchRes(parcelId, "01", AnomalyLevelEnum.INFO),
                        givenAnomalySearchRes(parcelId, "WD40", AnomalyLevelEnum.INFO),
                        givenAnomalySearchRes(parcelId, "not_mine", null), // ignored
                        givenAnomalySearchRes(parcelId, "03", AnomalyLevelEnum.DANGER),
                        givenAnomalySearchRes(parcelId, "02", AnomalyLevelEnum.WARN),
                        givenAnomalySearchRes(parcelId, "00", null), // ignored
                        givenAnomalySearchRes(parcelId, "02", AnomalyLevelEnum.WARN)
                ));
        given(anomalyTypeClient.searchAll(any(), any(), any())).willReturn(new ArrayList<>());

        setUnusedBindingAllowed(true);
        getJdbi().useHandle(handle -> {
            handle.begin();

            //List<String> initScripts = List.of("search_test_data", "anomaly_categories");
            List<String> initScripts = List.of("search_test_data");
            execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

            long partyId = 555L;
            Long llId = -13202L;
            LandLinkAnomaliesRes anomalies = landLinkService.getAnomalies(ctx.getReqContext(), AbsoluteDate.of(now), partyId, llId);

            assertThat(anomalies).isNotNull();
            assertThat(anomalies.getAnomaliesGrouped()).isNotNull()
                    .hasSize(3)
                    .containsKeys(AnomalyLevelEnum.INFO, AnomalyLevelEnum.WARN, AnomalyLevelEnum.DANGER);
            assertThat(anomalies.getAnomaliesGrouped().get(AnomalyLevelEnum.INFO)).isNotNull()
                    .hasSize(4)
                    .extracting(AnomalySearchResponse::getEntityId, a -> a.getType().getGroupCode(), a -> a.getType().getCode())
                    .containsExactlyInAnyOrder(
                            tuple(parcelId, "test", "01"),
                            tuple(parcelId, "test", "01"),
                            tuple(parcelId, "test", "01"),
                            tuple(parcelId, "test", "WD40")
                    );
            assertThat(anomalies.getAnomaliesGrouped().get(AnomalyLevelEnum.WARN)).isNotNull()
                    .hasSize(2)
                    .extracting(AnomalySearchResponse::getEntityId, a -> a.getType().getGroupCode(), a -> a.getType().getCode())
                    .containsExactlyInAnyOrder(
                            tuple(parcelId, "test", "02"),
                            tuple(parcelId, "test", "02")
                    );
            assertThat(anomalies.getAnomaliesGrouped().get(AnomalyLevelEnum.DANGER)).isNotNull()
                    .hasSize(2)
                    .extracting(AnomalySearchResponse::getEntityId, a -> a.getType().getGroupCode(), a -> a.getType().getCode())
                    .containsExactlyInAnyOrder(
                            tuple(parcelId, "test", "03"),
                            tuple(parcelId, "test", "VAT69")
                    );

            handle.rollback();
        });
    }

    private void givenCloseDayConfig(Handle handle, boolean allowEditDayToParcelInThePast) {    	
        handle.attach(CllSettingsDAO.class).insert(CllSettingsEntity.builder()
                .setLpisSubSeparator("/")
                .setAllowEditDayToParcelInThePast(allowEditDayToParcelInThePast ? 1 : 0)
                .setParcelSearchLevel(ParcelSearchLevel.SEARCH_ONLY_VALID)
                .setTenantId(ctx.getTenantId())
                .setDtInsert(LocalDateTime.ofEpochSecond(0, 0, ZoneOffset.UTC))
                .setDtDelete(AuditEntity.dateActive)
                .setUserIdInsert(ctx.getUserId())
                .build());
    }

    private PublicParcel buildMockParcel(long id, long area_sqm) {
        return buildMockParcel(id, area_sqm, "99", null, 4L, "AAA", 1);
    }

    private PublicParcel buildMockParcel(long id, long area_sqm, String parcelCode, String parcelSubCode, Long sectorId, String shortDescr, Integer blockNum) {
        String sectorCode = shortDescr.charAt(0) + StringUtils.leftPad(sectorId.toString(), 3, '0');
        String parcel = StringUtils.leftPad(parcelCode, 5, '0')
                + (parcelSubCode == null ? "" : "/" + parcelSubCode);
        return PublicParcel.builder()
                .setId(id)
                .setParcel(parcel)
                .setSector(PublicParcelSector.builder()
                        .setId(sectorId)
                        .setSectorCode(sectorCode)
                        .setShortDescr(shortDescr)
                        .setDescription(shortDescr + " - " + sectorCode)
                        .build())
                .setBlock(PublicParcelBlock.builder()
                        .setId(sectorId * 100 + blockNum)
                        .setSectorId(sectorId)
                        .setBlockCode(blockNum.toString())
                        .setShortDescr(blockNum.toString())
                        .setDescription(blockNum.toString())
                        .build())
                .setAreaSqm(area_sqm)
                .setSrs("SRS_test")
                .setDayFrom(AbsoluteDate.of("19700101"))
                .setDayTo(AbsoluteDate.of("99991231"))
                .build();
    }

    private AnomalySearchResponse givenAnomaly(String entityId, String code) {
        return AnomalySearchResponse.builder()
                .setEntityCode("ENTITY")
                .setEntityId(entityId)
                .setType(AnomalyTypeResponse.builder()
                        .setCode(code)
                        .setGroupCode("test")
                        .setI18nCode("Anomalia di tipo " + code)
                        .build())
                .build();
    }

    private AnomalySearchRes givenAnomalySearchRes(String entityId, String code, AnomalyLevelEnum level) {
        return AnomalySearchRes.builder()
                .setEntityCode("ENTITY")
                .setEntityId(entityId)
                .setTypeCode(code)
                .setTypeGroupCode("test")
                .setLevel(level)
                .build();
    }

    private LandLinkBatchCreateReqBuilder<?, ?> landLinkBatchCreateReqBuilder() {
        return landLinkBatchCreateReqBuilder(100, 123456L, "A001", "1");
    }

    private LandLinkBatchCreateReqBuilder<?, ?> landLinkBatchCreateReqBuilder(double perc, long parcelId, String sectorCode, String blockCode) {
        return LandLinkBatchCreateReq.builder()
                .setTitleTypePerc(BigDecimal.valueOf(perc))
                .setParcelId(parcelId);
    }

    protected LandLinkEntityBuilder<?, ?> newLandLink(String tenant, double perc, Long parcelId,
            String dayFrom, String dayTo) {

        return LandLinkEntity.builder()
                .setGroupId(-1L)
                .setTenantId(tenant)
                .setPartyId(-11223L)

                .setTitleTypeId(-1L)
                .setTitleTypePerc(new BigDecimal(perc, new MathContext(8, RoundingMode.HALF_EVEN)))

                .setParcelId(parcelId)
                .setSectorCode(String.format("%s_sector_code", parcelId))
                .setBlockCode(String.format("%s_block_code", parcelId))

                .setDayFrom(AbsoluteDate.of(dayFrom))
                .setDayTo(AbsoluteDate.of(dayTo))
                ;
    }

}
