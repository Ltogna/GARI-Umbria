package com.abacogroup.cllapi.resources.pub;

import static com.abacogroup.cllapi.core.client.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import com.abacogroup.cllapi.api.GroupDocumentRes;
import com.abacogroup.cllapi.api.GroupDocumentRes.GroupDocumentResBuilder;
import com.abacogroup.cllapi.api.req.GroupDocumentSearchReq;
import com.abacogroup.cllapi.core.GroupDocumentService;
import com.abacogroup.cllapi.core.client.WebCliHelper;
import com.abacogroup.cllapi.core.impl.GroupDocumentServiceImpl;
import com.abacogroup.cllcli.api.v1.GroupDocumentResponseV1;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.UriBuilder;

@ExtendWith(DropwizardExtensionsSupport.class)
class GroupDocumentPublicResourceTest {

	private final GroupDocumentService groupDocumentService = Mockito.mock(GroupDocumentServiceImpl.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new GroupDocumentPublicResource(groupDocumentService));

	@Test
	void should_search() {
		Long partyId = 555L;
		Long groupId = 100L;
		String definitionCode = "DEF_1";
		String nextKey = "11";

		GroupDocumentSearchReq searchReq = new GroupDocumentSearchReq()
				.setDefinitionCode(definitionCode);

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> queryMap = mapper.convertValue(searchReq, Map.class);

		UriBuilder uriBuilder = UriBuilder.fromResource(GroupDocumentPublicResource.class).path(GroupDocumentPublicResource.class, "search");
		queryMap.forEach(uriBuilder::queryParam);
		String uri = uriBuilder.build(TENANT, partyId, groupId).toString();
		System.out.println(uri);

		InfiniteListResultsImpl<GroupDocumentRes> mockRes = new InfiniteListResultsImpl<>(List.of(
				groupDocumentResBuilder(101L, groupId, definitionCode).build(),
				groupDocumentResBuilder(102L, groupId, definitionCode).build(),
				groupDocumentResBuilder(103L, groupId, definitionCode).build()), nextKey);

		given(groupDocumentService.search(any(), anyLong(), anyLong(), any(), any())).willReturn(mockRes);

		InfiniteListResultsImpl<GroupDocumentResponseV1> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.queryParam("nextKey", nextKey)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.extracting(InfiniteListResultsImpl::getRecords)
				.usingRecursiveComparison()
				.isEqualTo(mockRes.getRecords());

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupDocumentService).search(reqCtxCaptor.capture(), eq(partyId), eq(groupId), eq(searchReq), eq(nextKey));
	}

	private GroupDocumentResBuilder<?, ?> groupDocumentResBuilder(Long docId, Long groupId, String defCode) {
		return GroupDocumentRes.builder()
				.setGroupId(groupId)
				.setDefinitionCode(defCode)
				.setDocumentId(docId);
	}

}
