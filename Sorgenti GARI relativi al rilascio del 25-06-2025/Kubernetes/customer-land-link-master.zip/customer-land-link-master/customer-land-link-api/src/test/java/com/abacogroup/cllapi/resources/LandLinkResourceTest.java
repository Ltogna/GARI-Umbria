package com.abacogroup.cllapi.resources;

import static com.abacogroup.cllapi.core.client.WebCliHelper.BASIC_USERNAME;
import static com.abacogroup.cllapi.core.client.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import com.abacogroup.cllapi.api.BlockRes;
import com.abacogroup.cllapi.api.GroupBaseRes;
import com.abacogroup.cllapi.api.LandLinkAnomaliesRes;
import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.api.LandLinkRes.LandLinkResBuilder;
import com.abacogroup.cllapi.api.LandLinkSectorSummaryRes;
import com.abacogroup.cllapi.api.LandLinkTitleSummaryRes;
import com.abacogroup.cllapi.api.ParcelRes;
import com.abacogroup.cllapi.api.SectorRes;
import com.abacogroup.cllapi.api.TitleType;
import com.abacogroup.cllapi.api.req.LandLinkBulkCloseReq;
import com.abacogroup.cllapi.api.req.LandLinkCloseReq;
import com.abacogroup.cllapi.api.req.LandLinkSearchReq;
import com.abacogroup.cllapi.api.req.LandLinkUpdateReq;
import com.abacogroup.cllapi.core.LandLinkService;
import com.abacogroup.cllapi.core.client.WebCliHelper;
import com.abacogroup.cllapi.core.impl.LandLinkServiceImpl;
import com.abacogroup.cllcli.api.v1.AnomalyLevelEnum;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class LandLinkResourceTest {

	private final LandLinkService landLinkService = Mockito.mock(LandLinkServiceImpl.class);

	private final ResourceExtension EXT = WebCliHelper.createEXT(new LandLinkResource(landLinkService));

	// ----- searchLandLinks -----
	@Test
	void test_searchLandLinks_ok() {
		Long partyId = 555L;
		Long groupId = 111L;
		AbsoluteDate referenceDate = AbsoluteDate.of("20230307");

		LandLinkSearchReq searchReq = new LandLinkSearchReq()
				.setGroupId(groupId)
				.setTitleTypeId(123L)
				.setSectorCode("A001")
				.setBlockCode("11")
				.setParcelCode("00078")
				.setSubParcelCode("A")
				.setAnomalyLevel(AnomalyLevelEnum.DANGER)
				.setIncludeGeometries(false);
		
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> queryMap = mapper.convertValue(searchReq, Map.class);
		queryMap.entrySet().removeIf(e -> null == e.getValue());

		UriBuilder uriBuilder = UriBuilder.fromResource(LandLinkResource.class).path(LandLinkResource.class, "searchLandLinks");
		queryMap.forEach(uriBuilder::queryParam);
		String uri = uriBuilder.build(TENANT, partyId, referenceDate.getValue()).toString();
		System.out.println(uri);

		InfiniteListResultsImpl<LandLinkRes> mockRes = new InfiniteListResultsImpl<>(List.of(
				landLinkResBuilder(partyId, groupId).setId(1L).build(),
				landLinkResBuilder(partyId, groupId).setId(2L).build(),
				landLinkResBuilder(partyId, groupId).setId(3L).build()
		), "11");
		given(landLinkService.search(any(), any(), any(), any(), any(), any())).willReturn(mockRes);

		InfiniteListResultsImpl<LandLinkRes> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.extracting(InfiniteListResultsImpl::getRecords)
				.isEqualTo(mockRes.getRecords());

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(landLinkService).search(reqCtxCaptor.capture(), eq(referenceDate), eq(searchReq.setPartyId(partyId)), anyBoolean(), isNull(), any());
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// ----- countAllFilteredLandLinks -----
	@Test
	void test_countLandLinksFiltered_ok() {
		Long partyId = 555L;
		AbsoluteDate referenceDate = AbsoluteDate.of("20230307");

		LandLinkSearchReq searchReq = new LandLinkSearchReq();
		searchReq.setIncludeGeometries(false);

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> queryMap = mapper.convertValue(searchReq, Map.class);
		queryMap.entrySet().removeIf(e -> null == e.getValue());

		UriBuilder uriBuilder = UriBuilder.fromResource(LandLinkResource.class).path(LandLinkResource.class, "countAllFilteredLandLinks");
		queryMap.forEach(uriBuilder::queryParam);
		String uri = uriBuilder.build(TENANT, partyId, referenceDate.getValue()).toString();
		System.out.println(uri);

		given(landLinkService.countAllForSearch(any(), any(), any())).willReturn(3);

		int res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isEqualTo(3);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(landLinkService).countAllForSearch(reqCtxCaptor.capture(), eq(referenceDate), eq(searchReq.setPartyId(partyId)));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// ----- getLandLinkById -----
	@Test
	void test_getLandLink_ok() {
		Long partyId = 555L;
		Long groupId = 98L;
		Long landLinkId = 111L;
		AbsoluteDate referenceDate = AbsoluteDate.of("20230307");

		UriBuilder uriBuilder = UriBuilder.fromResource(LandLinkResource.class).path(LandLinkResource.class, "getLandLink");
		String uri = uriBuilder.build(TENANT, partyId, referenceDate.getValue(), landLinkId).toString();

		LandLinkRes mockRes = landLinkResBuilder(partyId, groupId).setId(landLinkId).setPartyId(partyId).build();

		given(landLinkService.getRes(any(), any(), any(), any())).willReturn(mockRes);

		LandLinkRes res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(landLinkService).getRes(reqCtxCaptor.capture(), eq(referenceDate), eq(partyId), eq(landLinkId));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// ----- getLandLinkAnomalies -----
	@Test
	void test_getLandLinkAnomalies_ok() {
		Long partyId = 555L;
		Long landLinkId = 111L;
		AbsoluteDate referenceDate = AbsoluteDate.of("20230307");

		UriBuilder uriBuilder = UriBuilder.fromResource(LandLinkResource.class).path(LandLinkResource.class, "getLandLinkAnomalies");
		String uri = uriBuilder.build(TENANT, partyId, referenceDate.getValue(), landLinkId).toString();

		LandLinkAnomaliesRes mockRes = new LandLinkAnomaliesRes(Map.of(
				AnomalyLevelEnum.INFO, List.of(
						givenAnomaly(landLinkId.toString(), "X56"),
						givenAnomaly(landLinkId.toString(), "D64"),
						givenAnomaly(landLinkId.toString(), "G54")
				), AnomalyLevelEnum.WARN, List.of(
						givenAnomaly(landLinkId.toString(), "R22"),
						givenAnomaly(landLinkId.toString(), "S93")
				), AnomalyLevelEnum.DANGER, List.of(
						givenAnomaly(landLinkId.toString(), "F23"),
						givenAnomaly(landLinkId.toString(), "W14"),
						givenAnomaly(landLinkId.toString(), "C19")
				)
		));

		given(landLinkService.getAnomalies(any(), any(), any(), any())).willReturn(mockRes);

		LandLinkAnomaliesRes res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(landLinkService).getAnomalies(reqCtxCaptor.capture(), eq(referenceDate), eq(partyId), eq(landLinkId));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// ----- getLandLinkSummary -----
	@Test
	void test_getLandLinkSummary_ok() {
		Long partyId = 555L;

		UriBuilder uriBuilder = UriBuilder.fromResource(LandLinkResource.class).path(LandLinkResource.class, "getLandLinkSummary");
		String uri = uriBuilder.build(TENANT, partyId).toString();
		System.out.println(uri);

		List<LandLinkSectorSummaryRes> mockRes = List.of(
				buildSectorSummary(15L, 37485L, 37485L, 123L, "A061", "AFFI (VR)",
						buildTitleSummary(11L, 27000L, 27000L, 1L, "PROPRIETA"),
						buildTitleSummary(4L, 10485L, 10485L, 2L, "AFFITTO"),
						buildTitleSummary(0L, 0L, 0L, 3L, "MEZZADRIA"),
						buildTitleSummary(0L, 0L, 0L, 4L, "ALTRA FORMA"),
						buildTitleSummary(0L, 0L, 0L, 5L, "USO CIVICO")),
				buildSectorSummary(5L, 17485L, 7485L, 456L, "A737", "BELFIORE (VR)",
						buildTitleSummary(0L, 0L, 0L, 1L, "PROPRIETA"),
						buildTitleSummary(5L, 17485L, 7485L, 2L, "AFFITTO"),
						buildTitleSummary(0L, 0L, 0L, 3L, "MEZZADRIA"),
						buildTitleSummary(0L, 0L, 0L, 4L, "ALTRA FORMA"),
						buildTitleSummary(0L, 0L, 0L, 5L, "USO CIVICO"))
		);
		given(landLinkService.getSummary(any(), anyLong())).willReturn(mockRes);

		List<LandLinkSectorSummaryRes> res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(landLinkService).getSummary(reqCtxCaptor.capture(), eq(partyId));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// ----- updateLandLink -----
	@Test
	void test_updateLandLink_ok() {
		Long partyId = 555L;
		Long landLinkId = 123L;
		AbsoluteDate referenceDate = AbsoluteDate.of("20230307");

		BigDecimal titleTypePerc = new BigDecimal("98.76543210");
		LandLinkUpdateReq updateReq = LandLinkUpdateReq.builder()
				.setTitleTypePerc(titleTypePerc)
				.build();

		UriBuilder uriBuilder = UriBuilder.fromResource(LandLinkResource.class).path(LandLinkResource.class, "updateLandLink");
		String uri = uriBuilder.build(TENANT, partyId, landLinkId).toString();
		System.out.println(uri);

		LandLinkRes mockRes = landLinkResBuilder(partyId, 111L).setId(landLinkId).setTitleTypePerc(titleTypePerc).build();
		given(landLinkService.update(any(), any(), any(), any())).willReturn(mockRes);

		LandLinkRes res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.put(Entity.json(updateReq), new GenericType<>() {
				});

		assertThat(res).isNotNull().isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(landLinkService).update(reqCtxCaptor.capture(), eq(partyId), eq(landLinkId), eq(updateReq));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// ----- close LandLink -----
	@Test
	void test_closeLandLink_ok() {
		Long partyId = 555L;
		Long landLinkId = 100L;

		String uri = UriBuilder.fromResource(LandLinkResource.class).path(LandLinkResource.class, "closeLandLink")
				.build(TENANT, partyId, landLinkId).toString();
		System.out.println(uri);

		doNothing().when(landLinkService).closeOne(any(), any(), any(), any());

		LandLinkCloseReq landLinkCloseReq = LandLinkCloseReq.builder().setDayTo(AbsoluteDate.of("20211202")).build();

		Response res = EXT.getJerseyTest()
				.target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.put(Entity.json(landLinkCloseReq), new GenericType<>() {
				});

		assertThat(res.getStatus()).isEqualTo(200);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(landLinkService).closeOne(reqCtxCaptor.capture(), eq(partyId), eq(landLinkId), eq(landLinkCloseReq.getDayTo()));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// ----- closeManyLandLinks -----
	@Test
	void test_closeManyLandLinks_ok() {
		Long partyId = 555L;

		String uri = UriBuilder.fromResource(LandLinkResource.class).path(LandLinkResource.class, "closeManyLandLinks")
				.build(TENANT, partyId).toString();
		System.out.println(uri);

		LandLinkBulkCloseReq landLinkCloseReq = LandLinkBulkCloseReq.builder()
				.setDayTo(AbsoluteDate.of("20211202"))
				.setLandLinkIds(List.of(1L, 2L, 3L))
				.build();

		Response res = EXT.getJerseyTest()
				.target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.put(Entity.json(landLinkCloseReq), new GenericType<>() {
				});

		assertThat(res.getStatus()).isEqualTo(200);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(landLinkService).closeMany(reqCtxCaptor.capture(), eq(partyId), eq(landLinkCloseReq.getLandLinkIds()), eq(landLinkCloseReq.getDayTo()));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// ################################################################################################################################################## //

	private static AnomalySearchResponse givenAnomaly(String entityId, String code) {
		return AnomalySearchResponse.builder()
				.setEntityCode("ENTITY")
				.setEntityId(entityId)
				.setType(AnomalyTypeResponse.builder()
						.setCode(code)
						.setGroupCode("test")
						.setI18nCode("Anomalia di tipo "+code)
						.build())
				.build();
	}

	private static LandLinkSectorSummaryRes buildSectorSummary(long linkCount, long totParcelAreaSqm, long totTitleTypeAreaSqm, long id, String sectorCode,
			String shortDescr, LandLinkTitleSummaryRes... titleSummaryRes) {
		return LandLinkSectorSummaryRes.builder()
				.setLinkCount(linkCount)
				.setTotParcelAreaSqm(totParcelAreaSqm)
				.setTotTitleTypeAreaSqm(totTitleTypeAreaSqm)
				.setSector(SectorRes.builder()
						.setId(id)
						.setSectorCode(sectorCode)
						.setShortDescr(shortDescr)
						.setDescription(shortDescr + " - " + sectorCode)
						.build())
				.setTitleSummaryRes(List.of(titleSummaryRes))
				.build();
	}

	private static LandLinkTitleSummaryRes buildTitleSummary(long linkCount, long totParcelAreaSqm, long totTitleTypeAreaSqm, long id, String code) {
		return LandLinkTitleSummaryRes.builder()
				.setLinkCount(linkCount)
				.setTotParcelAreaSqm(totParcelAreaSqm)
				.setTotTitleTypeAreaSqm(totTitleTypeAreaSqm)
				.setTitleType(TitleType.builder()
						.setId(id)
						.setCode(code)
						.setFlDayToReq(0)
						.setFlDayToEditable(0)
						.setFlAllowFutureDayFrom(0)
						.setI18nCode(code)
						.build())
				.build();
	}

	private static LandLinkResBuilder<?, ?> landLinkResBuilder(Long partyId, Long groupId) {
		return LandLinkRes.builder()
				.setId(-1L)
				.setGroup(GroupBaseRes.builder()
						.setId(groupId)
						.setDescr("Group " + groupId)
						.build())
				.setPartyId(partyId)
				.setTitleType(TitleType.builder()
						.setId(-1L)
						.setI18nCode("TITLE TYPE 1")
						.setCode("TT1")
						.setFlDayToReq(0)
						.setFlDayToEditable(0)
						.setFlAllowFutureDayFrom(0)
						.build())
				.setTitleTypePerc(BigDecimal.valueOf(100).setScale(8, RoundingMode.HALF_UP))
				.setParcel(
						ParcelRes.builder()
								.setParcel("01234/A")
								.setSector(SectorRes.builder()
										.setSectorCode("A001")
										.build())
								.setBlock(BlockRes.builder()
										.setBlockCode("1")
										.build())
								.setAreaSqm(15000L)
								.build()
				)
				.setDayFrom(AbsoluteDate.of("20200202"))
				.setDayTo(AbsoluteDate.of("99991231"))
				.setMaxAnomalyLevel(null);
	}

}
