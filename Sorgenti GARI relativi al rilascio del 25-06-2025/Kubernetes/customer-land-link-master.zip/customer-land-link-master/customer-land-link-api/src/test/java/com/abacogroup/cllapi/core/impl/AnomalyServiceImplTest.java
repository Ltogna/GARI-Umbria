package com.abacogroup.cllapi.core.impl;

import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.DD_ANOMALY_ATTO;
import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.LL_ANOMALY_P55;
import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.LL_ANOMALY_P55_6;
import static com.abacogroup.cllapi.core.embededqueue.AnomalyHelper.PARTY_PARCEL_ENTITY_CODE;
import static com.abacogroup.cllcli.api.v1.AnomalyLevelEnum.DANGER;
import static com.abacogroup.cllcli.api.v1.AnomalyLevelEnum.WARN;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.anomalyregistry.api.v1.req.AnomalyTypeSearchRequest;
import com.abacogroup.cllapi.api.GroupRes;
import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.api.ParcelRes;
import com.abacogroup.cllapi.core.dto.AnomalyDto;
import com.abacogroup.cllapi.core.dto.AnomalyMaxLevelDto;
import com.abacogroup.cllapi.core.embededqueue.AnomalyHelper;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;

import com.abacogroup.anomalyregistry.api.v1.AnomalyTypeResponse;
import com.abacogroup.anomalyregistry.core.cli.v1.AnomalyTypeClient;
import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.api.AnomalySearchRes;
import com.abacogroup.cllapi.api.req.AnomalySearchReq;
import com.abacogroup.cllapi.core.AnomalyService;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.testcommon.ReqContextUtils;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;

@ExtendWith(DropwizardExtensionsSupport.class)
class AnomalyServiceImplTest extends JdbiTest {

	private final AnomalyService anomalyService = getService(AnomalyServiceImpl.class);
	private final AnomalyTypeClient anomalyTypeClient = Mockito.mock(AnomalyTypeClient.class);
	private final ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	@BeforeEach
	void setUp() {
		this.injectMock(anomalyService, anomalyTypeClient);
		((AnomalyServiceImpl) anomalyService).resetCache();
	}

	// ----- getLandLinksAnomalies -----
	@Test
	void test_getLandLinksAnomalies_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {

			handle.begin();
			execSqlFiles(this.getClass(), List.of("add_anomalies"), ctx.getTestScriptParams());

			LandLinkRes ll1 = givenLandLink(111L, 555L, 16L, 123416L);
			LandLinkRes ll2 = givenLandLink(222L, 555L, 16L, 123422L);
			LandLinkRes ll3 = givenLandLink(333L, 555L, 99L, 123419L);
			LandLinkRes llNULL = givenLandLink(999L, null, null, null);

			given(anomalyTypeClient.searchAll(any(), any(), any()))
					.willAnswer(i -> {
						AnomalyTypeSearchRequest searchRequest = i.getArgument(2);

						return List.of(
								AnomalyTypeResponse.builder()
										.setGroupCode("test")
										.setI18nCode("it - " + searchRequest.getCode())
										.build()
						);
					});

			//test
			Map<Long, AnomalyMaxLevelDto> landLinksAnomalies = anomalyService.getLandLinksAnomalies(ctx.getReqContext(), AbsoluteDate.of("20240701"),
					List.of(ll1, ll2, ll3, llNULL));

			assertThat(landLinksAnomalies).hasSize(4)
					.containsKeys(ll1.getId(), ll2.getId(), ll3.getId(), llNULL.getId());

			assertThat(landLinksAnomalies.get(ll1.getId()).getAnomalies()).hasSize(3)
					.extracting(AnomalyDto::getLevel, a -> a.getAnomaly().getType().getCode(), a -> a.getAnomaly().getId())
					.containsExactly(
						tuple(DANGER, LL_ANOMALY_P55_6, -6L),
						tuple(WARN, DD_ANOMALY_ATTO, -5L),
						tuple(WARN, LL_ANOMALY_P55, -2L)
					);
			assertThat(landLinksAnomalies.get(ll2.getId()).getAnomalies()).hasSize(2)
					.extracting(AnomalyDto::getLevel, a -> a.getAnomaly().getType().getCode(), a -> a.getAnomaly().getId())
					.containsExactly(
							tuple(WARN, DD_ANOMALY_ATTO, -5L),
							tuple(WARN, LL_ANOMALY_P55, -4L)
					);
			assertThat(landLinksAnomalies.get(ll3.getId()).getAnomalies()).hasSize(2)
					.extracting(AnomalyDto::getLevel, a -> a.getAnomaly().getType().getCode(), a -> a.getAnomaly().getId())
					.containsExactly(
							tuple(DANGER, LL_ANOMALY_P55_6, -7L),
							tuple(WARN, LL_ANOMALY_P55, -3L)
					);
			assertThat(landLinksAnomalies.get(llNULL.getId()).getAnomalies()).isEmpty();

			//mappping
			assertThat(landLinksAnomalies.get(ll1.getId()).getAnomalies().get(0))
					.isEqualTo(
							AnomalyDto.builder()
									.setLevel(DANGER)
									.setAnomaly(AnomalySearchResponse.builder()
											.setId(-6L)
											.setEntityId("555-123416")
											.setEntityCode(PARTY_PARCEL_ENTITY_CODE)
											.setType(AnomalyTypeResponse.builder()
													.setId(null)
													.setGroupCode("parcel")
													.setCode(LL_ANOMALY_P55_6)
													.setI18nCode("it - P55.6")
													.build())
											.build())
									.build()
					);

			handle.rollback();
		});
	}

	@Test
	void test_getLandLinksAnomalies_allNullOkEmpty() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {

			handle.begin();
			execSqlFiles(this.getClass(), List.of("add_anomalies"), ctx.getTestScriptParams());

			LandLinkRes ll1NULL = givenLandLink(991L, null, null, null);
			LandLinkRes ll2NULL = givenLandLink(992L, null, null, null);

			//test
			Map<Long, AnomalyMaxLevelDto> landLinksAnomalies = anomalyService.getLandLinksAnomalies(ctx.getReqContext(), AbsoluteDate.of("20240701"),
					List.of(ll1NULL, ll2NULL));

			assertThat(landLinksAnomalies).hasSize(2)
					.containsKeys(ll1NULL.getId(), ll2NULL.getId());
			assertThat(landLinksAnomalies.get(ll1NULL.getId()).getAnomalies()).isEmpty();
			assertThat(landLinksAnomalies.get(ll2NULL.getId()).getAnomalies()).isEmpty();

			handle.rollback();
		});
	}

	private LandLinkRes givenLandLink(Long id, Long partyId, Long groupId, Long parcelId) {
		return LandLinkRes.builder()
				.setId(id)
				.setPartyId(partyId)
				.setParcel(ParcelRes.builder()
						.setId(parcelId)
						.build())
				.setGroup(GroupRes.builder()
						.setId(groupId)
						.build())
				.build();
	}

	// search
	@ParameterizedTest
	@MethodSource("test_search")
	void test_search(String ignoredTitle, String entityCode, AnomalySearchReq request, List<Long> ids) {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {

			handle.begin();
			//setup
			Mockito.when(anomalyTypeClient.searchAll(Mockito.eq(ctx.getReqContext().getLang()), any(), any()))
					.thenReturn(List.of(AnomalyTypeResponse.builder().setId(1L).setCode("P55").setGroupCode("parcel").setI18nCode("particella").build()));
			List<String> initScripts = List.of("add_anomalies");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());
			// test
			List<AnomalySearchRes> anomalies =
					anomalyService.search(ctx.getReqContext(), entityCode, request, AbsoluteDate.of("20240701"));
			// asserts
			assertThat(anomalies).isNotNull();
			assertThat(anomalies.stream().map(AnomalySearchRes::getId).collect(Collectors.toList()))
					.hasSize(ids.size())
					.isEqualTo(ids);

			handle.rollback();
		});
	}

	static Stream<Arguments> test_search() {
		return Stream.of(
				Arguments.of("search entityCode parcel", "REFERENCE_PARCEL", 
						new AnomalySearchReq(),
						List.of(-4L, -3L, -2L, -1L)),

				Arguments.of("search entityCode dd", "REFERENCE_CLL_GROUP",
						new AnomalySearchReq().setGroupCode(List.of("dd")),
						List.of(-5L)),

				Arguments.of("search entityIds", "REFERENCE_PARCEL", 
						new AnomalySearchReq().setGroupCode(List.of("parcel")).setEntityId(List.of("123412", "123422")),
						List.of(-4L, -1L)));
	}
}
