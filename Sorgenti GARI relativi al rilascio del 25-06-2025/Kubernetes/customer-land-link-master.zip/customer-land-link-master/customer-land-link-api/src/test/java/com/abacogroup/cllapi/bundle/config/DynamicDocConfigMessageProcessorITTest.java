package com.abacogroup.cllapi.bundle.config;

import static org.assertj.core.api.Assertions.assertThat;

import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.db.dao.DocTypeRelationDAO;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;

@ExtendWith(DropwizardExtensionsSupport.class)
class DynamicDocConfigMessageProcessorITTest extends JdbiTest {

	private static final String TENANT_ID = String.format("%s_t", DynamicDocConfigMessageProcessorITTest.class.getSimpleName());
	private static final String CURRENT_USER = String.format("%s_u", DynamicDocConfigMessageProcessorITTest.class.getSimpleName());
	private static final Map<String, Object> testScriptParams = Map.of(
			"test_tenant", TENANT_ID,
			"user_id", CURRENT_USER);
	private final DynamicDocConfigMessageProcessor processor = getService(DynamicDocConfigMessageProcessor.class);
	private final Supplier<Path> specificBundlePath = () -> Path.of(
			"src/test/resources",
			(this.getClass().getName() + "." + processor.getDomainName()).replaceAll("\\.", "/"));

	@Test
	void given_delete_files_test_onMessage() {
		List<Path> paths = FileSupport.listFilesRecursive(specificBundlePath.get());
		ConfigDataMessage msg = new ConfigDataMessage();
		msg.setConfigFiles(paths);
		msg.setTenantId(TENANT_ID);

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_doc_type_relations");
			execSqlFiles(this.getClass(), initScripts, testScriptParams);

			DocTypeRelationDAO docTypeRelationDAO = handle.attach(DocTypeRelationDAO.class);
			assertThat(docTypeRelationDAO.count(TENANT_ID)).isEqualTo(5L);

			processor.onMessage(msg);

			assertThat(docTypeRelationDAO.count(TENANT_ID)).isEqualTo(2L);

			handle.rollback();
		});

	}
}
