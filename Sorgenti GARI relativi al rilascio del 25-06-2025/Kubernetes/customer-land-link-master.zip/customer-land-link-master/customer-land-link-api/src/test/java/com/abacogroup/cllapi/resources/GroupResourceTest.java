package com.abacogroup.cllapi.resources;

import static com.abacogroup.cllapi.core.client.WebCliHelper.BASIC_USERNAME;
import static com.abacogroup.cllapi.core.client.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import com.abacogroup.cllapi.api.BlockRes;
import com.abacogroup.cllapi.api.GroupBaseRes;
import com.abacogroup.cllapi.api.GroupRes;
import com.abacogroup.cllapi.api.GroupRes.GroupResBuilder;
import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.api.LandLinkRes.LandLinkResBuilder;
import com.abacogroup.cllapi.api.ParcelRes;
import com.abacogroup.cllapi.api.SectorRes;
import com.abacogroup.cllapi.api.TitleType;
import com.abacogroup.cllapi.api.req.GroupBulkCloseReq;
import com.abacogroup.cllapi.api.req.GroupCloneReq;
import com.abacogroup.cllapi.api.req.GroupCloseReq;
import com.abacogroup.cllapi.api.req.GroupCreateReq;
import com.abacogroup.cllapi.api.req.GroupDuplicatesReq;
import com.abacogroup.cllapi.api.req.GroupSearchReq;
import com.abacogroup.cllapi.api.req.GroupUpdateReq;
import com.abacogroup.cllapi.api.req.LandLinkBatchCreateReq;
import com.abacogroup.cllapi.api.req.LandLinkBatchCreateReq.LandLinkBatchCreateReqBuilder;
import com.abacogroup.cllapi.core.GroupService;
import com.abacogroup.cllapi.core.client.WebCliHelper;
import com.abacogroup.cllapi.core.impl.GroupServiceImpl;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class GroupResourceTest {

	private final GroupService groupService = Mockito.mock(GroupServiceImpl.class);

	private final ResourceExtension EXT = WebCliHelper.createEXT(new GroupResource(groupService));

	// ----- searchGroups -----
	@Test
	void test_searchGroups_ok() {
		Long partyId = 555L;
		AbsoluteDate referenceDate = AbsoluteDate.of("20230307");

		GroupSearchReq searchReq = new GroupSearchReq()
				.setDescr("group100")
				.setPartyId(partyId)
				.setTitleTypeId(100L);

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> queryMap = mapper.convertValue(searchReq, Map.class);

		UriBuilder uriBuilder = UriBuilder.fromResource(GroupResource.class).path(GroupResource.class, "searchGroups");
		queryMap.forEach(uriBuilder::queryParam);
		String uri = uriBuilder.build(TENANT, partyId, referenceDate.getValue()).toString();
		System.out.println(uri);

		InfiniteListResultsImpl<GroupRes> mockRes = new InfiniteListResultsImpl<>(List.of(
				groupResBuilder(-1L, partyId).build(),
				groupResBuilder(-2L, partyId).build(),
				groupResBuilder(-3L, partyId).build()
		), "11");
		given(groupService.search(any(), any(), any(), any(), any())).willReturn(mockRes);

		InfiniteListResultsImpl<GroupRes> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.extracting(InfiniteListResultsImpl::getRecords)
				.isEqualTo(mockRes.getRecords());

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupService).search(reqCtxCaptor.capture(), eq(referenceDate), eq(partyId), eq(searchReq), isNull());
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));

	}

	// ----- getGroup -----
	@Test
	void test_getGroup_ok() {
		Long partyId = 555L;
		Long groupId = 111L;
		String uri = UriBuilder.fromResource(GroupResource.class).path(GroupResource.class, "getGroup")
				.build(TENANT, partyId, groupId).toString();
		System.out.println(uri);

		GroupRes mockRes = groupResBuilder(groupId, partyId).build();
		given(groupService.getRes(any(), anyLong(), anyLong())).willReturn(mockRes);

		GroupRes res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupService).getRes(reqCtxCaptor.capture(), eq(partyId), eq(groupId));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// ----- getGroupLandLinks -----
	@Test
	void test_getGroupLandLinks_ok() {
		Long partyId = 555L;
		Long groupId = 111L;
		String uri = UriBuilder.fromResource(GroupResource.class).path(GroupResource.class, "getGroupLandLinks")
				.build(TENANT, partyId, groupId).toString();
		System.out.println(uri);

		InfiniteListResultsImpl<LandLinkRes> mockRes = new InfiniteListResultsImpl<>(List.of(
				landLinkResBuilder(partyId, groupId).setId(1L).build(),
				landLinkResBuilder(partyId, groupId).setId(2L).build(),
				landLinkResBuilder(partyId, groupId).setId(3L).build()
		), "11");
		given(groupService.searchGroupLandLinks(any(), anyLong(), anyLong(), any())).willReturn(mockRes);

		InfiniteListResultsImpl<LandLinkRes> res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.extracting(InfiniteListResultsImpl::getRecords)
				.isEqualTo(mockRes.getRecords());

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupService).searchGroupLandLinks(reqCtxCaptor.capture(), eq(partyId), eq(groupId), isNull());
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));

	}

	// ----- createGroup -----
	@Test
	void test_createGroup_ok() {
		Long partyId = 555L;
		Long groupId = 111L;
		String uri = UriBuilder.fromResource(GroupResource.class)//.path(GroupResource.class, "createGroup")
				.build(TENANT, partyId).toString();
		System.out.println(uri);

		GroupRes mockRes = groupResBuilder(groupId, partyId).build();
		given(groupService.insert(any(), anyLong(), any())).willReturn(mockRes);
		GroupCreateReq groupCreateReq = GroupCreateReq.builder()

				.setTitleTypeId(111L)
				.setDescr("test group")
				.setDayFrom(AbsoluteDate.of("20211202"))
				.setDayTo(AbsoluteDate.of("99991231"))
				.setLandLinks(List.of(landLinkBatchCreateReqBuilder().build()))
				.build();

		GroupRes res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.post(Entity.json(groupCreateReq), new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupService).insert(reqCtxCaptor.capture(), eq(partyId), eq(groupCreateReq));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// ----- updateGroup -----
	@Test
	void test_updateGroup_ok() {
		Long partyId = 555L;
		Long groupId = 111L;
		String uri = UriBuilder.fromResource(GroupResource.class).path(GroupResource.class, "updateGroup")
				.build(TENANT, partyId, groupId).toString();
		System.out.println(uri);

		GroupRes mockRes = groupResBuilder(groupId, partyId).build();
		given(groupService.update(any(), anyLong(), anyLong(), any())).willReturn(mockRes);
		GroupUpdateReq groupUpdateReq = GroupUpdateReq.builder()
				.setDescr("test group upd")
				.setDayFrom(AbsoluteDate.of("20211202"))
				.setDayTo(AbsoluteDate.of("99991231"))
				.build();

		GroupRes res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.put(Entity.json(groupUpdateReq), new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupService).update(reqCtxCaptor.capture(), eq(partyId), eq(groupId), eq(groupUpdateReq));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// ----- addGroupLandLinks -----
	@Test
	void test_addGroupLandLinks_ok() {
		Long partyId = 555L;
		Long groupId = 111L;
		String uri = UriBuilder.fromResource(GroupResource.class).path(GroupResource.class, "addGroupLandLinks")
				.build(TENANT, partyId, groupId).toString();
		System.out.println(uri);

		GroupRes mockRes = groupResBuilder(groupId, partyId).build();
		given(groupService.addLandLinks(any(), anyLong(), anyLong(), any())).willReturn(mockRes);
		List<LandLinkBatchCreateReq> reqs = List.of(landLinkBatchCreateReqBuilder().build());

		GroupRes res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.post(Entity.json(reqs), new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupService).addLandLinks(reqCtxCaptor.capture(), eq(partyId), eq(groupId), eq(reqs));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// ----- closeGroup -----
	@Test
	void test_closeGroup_ok() {
		Long partyId = 555L;
		Long groupId = 111L;
		String uri = UriBuilder.fromResource(GroupResource.class).path(GroupResource.class, "closeGroup")
				.build(TENANT, partyId, groupId).toString();
		System.out.println(uri);

		GroupRes mockRes = groupResBuilder(groupId, partyId).build();
		given(groupService.close(any(), anyLong(), anyLong(), any())).willReturn(mockRes);
		GroupCloseReq groupCloseReq = GroupCloseReq.builder().setDayTo(AbsoluteDate.of("20211202")).build();

		GroupRes res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.put(Entity.json(groupCloseReq), new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupService).close(reqCtxCaptor.capture(), eq(partyId), eq(groupId), eq(groupCloseReq.getDayTo()));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// ----- closeManyGroups -----
	@Test
	void test_closeManyGroups_ok() {
		Long partyId = 555L;
		String uri = UriBuilder.fromResource(GroupResource.class).path(GroupResource.class, "closeManyGroups")
				.build(TENANT, partyId).toString();
		System.out.println(uri);

		GroupBulkCloseReq groupCloseReq = GroupBulkCloseReq.builder()
				.setDayTo(AbsoluteDate.of("20211202"))
				.setGroupIds(List.of(-1L, -2L, -3L))
				.build();

		Response res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.put(Entity.json(groupCloseReq));

		assertThat(res.getStatus()).isEqualTo(200);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupService).closeMany(reqCtxCaptor.capture(), eq(partyId), eq(groupCloseReq.getGroupIds()), eq(groupCloseReq.getDayTo()));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// ----- getDuplicates -----
	@Test
	void test_getDuplicates_ok() {
		Long partyId = 555L;
		Long groupId = 111L;
		String descr = "group test duplicates  ";

		GroupDuplicatesReq duplicatesReq = new GroupDuplicatesReq()
				.setDescr(descr)
				.setGroupId(groupId);

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> queryMap = mapper.convertValue(duplicatesReq, Map.class);

		UriBuilder uriBuilder = UriBuilder.fromResource(GroupResource.class).path(GroupResource.class, "getDuplicates");
		queryMap.forEach(uriBuilder::queryParam);

		String uri = uriBuilder.build(TENANT, partyId).toString();
		System.out.println(uri);

		given(groupService.countDuplicates(any(), anyLong(), anyLong(), anyString())).willReturn(0L);

		Long res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(0L);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupService).countDuplicates(reqCtxCaptor.capture(), eq(partyId), eq(groupId), eq(descr));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// ----- cloneGroup -----
	@Test
	void test_cloneGroup_ok() {
		Long partyId = 555L;
		Long groupId = 111L;
		String uri = UriBuilder.fromResource(GroupResource.class).path(GroupResource.class, "cloneGroup")
				.build(TENANT, partyId, groupId).toString();
		System.out.println(uri);

		GroupRes mockRes = groupResBuilder(groupId, partyId).build();
		given(groupService.clone(any(), anyLong(), anyLong(), any())).willReturn(mockRes);
		GroupCloneReq groupCloneReq = GroupCloneReq.builder()
				.setDescr("test group upd")
				.setDayFrom(AbsoluteDate.of("20211202"))
				.setDayTo(AbsoluteDate.of("99991231"))
				.setTitleTypePerc(BigDecimal.valueOf(90.1))
				.setTitleTypeId(123L)
				.build();

		GroupRes res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.post(Entity.json(groupCloneReq), new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(groupService).clone(reqCtxCaptor.capture(), eq(partyId), eq(groupId), eq(groupCloneReq));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// ################################################################################################################################################## //

	private static LandLinkResBuilder<?, ?> landLinkResBuilder(Long partyId, Long groupId) {
		return LandLinkRes.builder()
				.setId(-1L)
				.setGroup(GroupBaseRes.builder()
						.setId(groupId)
						.setDescr("Group "+groupId)
						.build())
				.setPartyId(partyId)
				.setTitleType(TitleType.builder()
						.setId(-1L)
						.setI18nCode("TITLE TYPE 1")
						.setCode("TT1")
						.setFlDayToReq(0)
						.setFlDayToEditable(0)
						.setFlAllowFutureDayFrom(0)
						.build())
				.setTitleTypePerc(BigDecimal.valueOf(100).setScale(8, RoundingMode.HALF_UP))
				.setParcel(
						ParcelRes.builder()
								.setParcel("01234/A")
								.setSector(SectorRes.builder()
										.setSectorCode("A001")
										.build())
								.setBlock(BlockRes.builder()
										.setBlockCode("1")
										.build())
								.setAreaSqm(15000L)
								.build()
				)
				.setDayFrom(AbsoluteDate.of("20200202"))
				.setDayTo(AbsoluteDate.of("99991231"))
				.setMaxAnomalyLevel(null);
	}

	private static LandLinkBatchCreateReqBuilder<?, ?> landLinkBatchCreateReqBuilder() {
		return landLinkBatchCreateReqBuilder(100, 123456L, "A001", "1");
	}

	private static LandLinkBatchCreateReqBuilder<?, ?> landLinkBatchCreateReqBuilder(double perc, long parcelId, String sectorCode, String blockCode) {
		return LandLinkBatchCreateReq.builder()
				.setTitleTypePerc(BigDecimal.valueOf(perc))
				.setParcelId(parcelId);
	}

	private static GroupResBuilder<?, ?> groupResBuilder() {
		return groupResBuilder(-1L, 555L);
	}

	private static GroupResBuilder<?, ?> groupResBuilder(long id, long partyId) {
		return GroupRes.builder()
				.setId(id)
				.setDescr("mock group 1")
				.setPartyId(partyId)
				.setTitleType(TitleType.builder()
						.setId(-1L)
						.setI18nCode("TITLE TYPE 1")
						.setCode("TT1")
						.setFlDayToReq(0)
						.setFlDayToEditable(0)
						.setFlAllowFutureDayFrom(0)
						.build())
				.setDayFrom(AbsoluteDate.of("20200202"))
				.setDayTo(AbsoluteDate.of("99991231"))
				.setLinkCount(7L);
	}

}
