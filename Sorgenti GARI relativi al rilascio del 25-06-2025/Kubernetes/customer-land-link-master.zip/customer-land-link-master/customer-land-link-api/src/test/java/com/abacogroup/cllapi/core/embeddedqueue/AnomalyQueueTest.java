package com.abacogroup.cllapi.core.embeddedqueue;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.core.dto.CllEventType;
import com.abacogroup.cllapi.core.embededqueue.AnomalyHelper;
import com.abacogroup.cllapi.core.embededqueue.AnomalyQueue;
import com.abacogroup.cllapi.exceptions.LandLinkException;
import com.abacogroup.cllapi.exceptions.LandLinkException.ErrEnum;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.testcommon.ReqContextUtils;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneId;
import java.util.List;
import lombok.SneakyThrows;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
@Disabled
@ExtendWith(DropwizardExtensionsSupport.class)
class AnomalyQueueTest extends JdbiTest {

	private final AnomalyQueue anomalyQueue = getService(AnomalyQueue.class);
	private final AnomalyHelper anomalyHelperMock = Mockito.mock(AnomalyHelper.class);

	private final Clock clock = mock(Clock.class);
	private final ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	@AfterEach
	void tearDown() {
		getJdbi().useHandle(h -> h.execute("delete from equ_jobs"));
	}

	@BeforeEach
	void setUp() {
		injectMock(anomalyQueue, anomalyHelperMock);
		injectMock(anomalyQueue, clock);
	}

	@Test
	@SneakyThrows
	void test_queue_when_pushGroupEvent() {
		// #### given
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		// #### when
		CllEventType eventType = CllEventType.NEW_GROUP;
		List<Long> groupIds = List.of(1L, 2L, 3L);
		Long partyId = 12345L;
		AbsoluteDate fromDate = AbsoluteDate.of("99991231");

		anomalyQueue.pushGroupEvent(groupIds, fromDate, partyId, ctx.getTenantId(), ctx.getUserId(), ctx.getReqContext().getLang(), eventType);
		Thread.sleep(1000);

		// #### then
		Mockito.verify(anomalyHelperMock).onMultipleGroupEvent(eq(eventType), eq(groupIds), eq(partyId), eq(fromDate),
				eq(ctx.getTenantId()), eq(ctx.getUserId()), eq(ctx.getReqContext().getLang()));
	}

	@Test
	@SneakyThrows
	void test_queue_when_pushLandLinkEvent() {
		// #### given
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		// #### when
		CllEventType eventType = CllEventType.UPDATE_LAND_LINKS;
		List<Long> landLinkIds = List.of(1L, 2L);
		Long partyId = 12345L;
		AbsoluteDate fromDate = AbsoluteDate.of("99991231");

		anomalyQueue.pushLandLinkEvent(landLinkIds, fromDate, partyId, ctx.getTenantId(), ctx.getUserId(), ctx.getReqContext().getLang(), eventType);
		Thread.sleep(1000);

		// #### then
		Mockito.verify(anomalyHelperMock).onMultipleLandLinkEvent(eq(eventType), eq(landLinkIds), eq(partyId),
				eq(ctx.getTenantId()), eq(ctx.getUserId()), eq(ctx.getReqContext().getLang()));
	}

}
