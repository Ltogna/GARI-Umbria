package com.abacogroup.cllapi.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hamcrest.MatcherAssert;
import org.jdbi.v3.core.Handle;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.api.LandLinkDocumentRes;
import com.abacogroup.cllapi.api.req.LandLinkDocumentSearchReq;
import com.abacogroup.cllapi.bundle.tenant.DynamicDocTenantMessageProcessor;
import com.abacogroup.cllapi.bundle.tenant.TitleTypeTenantMessageProcessor;
import com.abacogroup.cllapi.core.LandLinkDocumentService;
import com.abacogroup.cllapi.core.utils.DynamicDocumentUtils;
import com.abacogroup.cllapi.exceptions.InvalidDocumentException;
import com.abacogroup.cllapi.exceptions.InvalidDocumentException.ErrEnum;
import com.abacogroup.cllapi.exceptions.LandLinkException;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.dynamicdocuments.files.FileStoreSupport;
import com.abacogroup.dynamicdocuments.http.RestClient;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.testcommon.ReqContextUtils;

import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import jakarta.ws.rs.core.Response;

@ExtendWith(DropwizardExtensionsSupport.class)
class LandLinkDocumentServiceImplTest extends JdbiTest {

	private final LandLinkDocumentService service = getService(LandLinkDocumentServiceImpl.class);
	private final TitleTypeTenantMessageProcessor titleTypeTenantMessageProcessor = getService(TitleTypeTenantMessageProcessor.class);
	private final DynamicDocTenantMessageProcessor ddTenantMessageProcessor = getService(DynamicDocTenantMessageProcessor.class);
	private final FileStoreProxyClient fileStoreProxyClient = mock(FileStoreProxyClient.class);

	private ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	@BeforeEach
	void setUp() throws AuthenticationException {
		DocumentService documentService = this.getService(DocumentService.class);

		this.injectMock(documentService, mock(RestClient.class));
		this.injectMock(documentService, mock(FileStoreSupport.class));
		this.injectMock(service, documentService);

		this.injectMock(service, fileStoreProxyClient);
	}

	@Test
	void test_InsertUpdateExpireLandLinkDocument_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			titleTypeTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));
			ddTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));

			// add group
			List<String> initScripts = List.of("add_groups", "add_links");
			Map<String, Object> customTestMap = new HashMap<>(ctx.getTestScriptParams());
			customTestMap.put("titleId", getTitleTypeId(handle, "PROPRIETA"));

			execSqlFiles(this.getClass(), initScripts, customTestMap);

			Long partyId = 555L;
			Long landLinkId = -101L;
			AbsoluteDate refDate = AbsoluteDate.of(LocalDateTime.now());

			String definitionCode = "DEF_1";
			Map<String, Object> doc_def1 = Map.of(
					"id_type", "id_assignment",
					"code", "cp",
					"release_agent", "Comune di Palermo",
					"release_date", "2021-12-03T00:00:00+02:00");

			Document doc = new Document();
			Map<String, Object> fields = DynamicDocumentUtils.createDoc(doc_def1);
			doc.setFields(fields);
			InsertDocument ins = new InsertDocument();
			ins.setDoc(doc);
			ins.setDefCode(definitionCode);
			ins.setBusinessId(landLinkId);

			// test save
			service.insert(ctx.getReqContext(), partyId, landLinkId, refDate,  ins);

			LandLinkDocumentSearchReq searchReq = new LandLinkDocumentSearchReq().setDefinitionCode(definitionCode);
			List<LandLinkDocumentRes> docs = service
					.search(ctx.getReqContext(), partyId, landLinkId, refDate, searchReq, null).getRecords();
			assertThat(docs).hasSize(1);
			MatcherAssert.assertThat(docs.get(0).getData().get("id_type"), is("Deed of Assignment"));
			MatcherAssert.assertThat(docs.get(0).getData().get("code"), is("Copy"));

			// test update
			DynamicDocumentUtils.updateField(doc, "release_agent", "Comune di Verona");
			service.update(ctx.getReqContext(), partyId, landLinkId, refDate, docs.get(0).getDocumentId(), doc);

			List<LandLinkDocumentRes> updatedDoc = service
					.search(ctx.getReqContext(), partyId, landLinkId, refDate, searchReq, null).getRecords();
			assertThat(updatedDoc).hasSize(1);
			
			LandLinkDocumentRes res = service.getLandLinkDocument(ctx.getReqContext(), partyId, landLinkId, refDate, updatedDoc.get(0).getDocumentId());
			assertThat(res)
					.isNotNull()
					.extracting(LandLinkDocumentRes::getLandLinkId)
					.isEqualTo(landLinkId);
			assertThat(res)
			.isNotNull()
			.extracting(LandLinkDocumentRes::getData)
			.isEqualTo(Map.of(
							"id_type", "id_assignment",
							"code", "cp",
							"release_agent", "Comune di Verona",
							"release_date", "2021-12-03T00:00:00+02:00"));
			// test expire
			service.expire(ctx.getReqContext(), partyId, landLinkId, refDate, docs.get(0).getDocumentId());

			assertThat(service.search(ctx.getReqContext(), partyId, landLinkId, refDate, searchReq, null).getRecords()).hasSize(0);

			// -------------
			handle.rollback();
		});
	}

	// ----- getDocumentFileContent -----
	@Test
	void test_getDocumentFileContent_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			titleTypeTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));
			ddTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));

			// add group and file
			List<String> initScripts = List.of("add_groups", "add_links");
			Map<String, Object> customTestMap = new HashMap<>(ctx.getTestScriptParams());
			customTestMap.put("titleId", getTitleTypeId(handle, "PROPRIETA"));

			execSqlFiles(this.getClass(), initScripts, customTestMap);

			Long partyId = 555L;
			Long landLinkId = -101L;
			AbsoluteDate refDate = AbsoluteDate.of(LocalDateTime.now());
			String definitionCode = "DEF_FILE";
			String fileId = "123456";
			Response mockResponse = Response.ok().build();
			given(fileStoreProxyClient.getFileContent(anyString(), any(), anyString(), anyString())).willReturn(mockResponse);

			LandLinkDocumentRes documentRes = givenDocument(partyId, landLinkId, refDate, definitionCode, Map.of(
					"descr", "test",
					"file", fileId));

			Response documentFileContent = service.getDocumentFileContent(ctx.getReqContext(), partyId, landLinkId, refDate, documentRes.getDocumentId(), fileId);

			assertThat(documentFileContent).isNotNull().isSameAs(mockResponse);

			handle.rollback();
		});
	}

	@Test
	void test_getDocumentFileContent_NotExistingLandLink() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			titleTypeTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));
			ddTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));

			// add group and file

			Long partyId = 555L;
			Long landLinkId = -101L;
			AbsoluteDate refDate = AbsoluteDate.of(LocalDateTime.now());
			String fileId = "123456";

			LandLinkException landLinkException = assertThrows(LandLinkException.class,
					() -> service.getDocumentFileContent(ctx.getReqContext(), partyId, landLinkId, refDate, 999L, fileId));

			assertThat(landLinkException).isNotNull()
					.extracting(LandLinkException::getCode).isEqualTo(LandLinkException.ErrEnum.NOT_FOUND.toString());

			handle.rollback();
		});
	}

	@Test
	void test_getDocumentFileContent_notExistingDoc() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			titleTypeTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));
			ddTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));

			// add group and file
			List<String> initScripts = List.of("add_groups", "add_links");
			Map<String, Object> customTestMap = new HashMap<>(ctx.getTestScriptParams());
			customTestMap.put("titleId", getTitleTypeId(handle, "PROPRIETA"));

			execSqlFiles(this.getClass(), initScripts, customTestMap);

			Long partyId = 555L;
			Long landLinkId = -101L;
			AbsoluteDate refDate = AbsoluteDate.of(LocalDateTime.now());
			String fileId = "123456";
			Response mockResponse = Response.ok().build();
			given(fileStoreProxyClient.getFileContent(anyString(), any(), anyString(), anyString())).willReturn(mockResponse);

			InvalidDocumentException documentException = assertThrows(InvalidDocumentException.class,
					() -> service.getDocumentFileContent(ctx.getReqContext(), partyId, landLinkId, refDate, 999L, fileId));

			assertThat(documentException).isNotNull()
					.extracting(InvalidDocumentException::getCode).isEqualTo(ErrEnum.DYNAMIC_DOCUMENT_NOT_FOUND.toString());

			handle.rollback();
		});
	}

	@Test
	void test_getDocumentFileContent_notExistingFile() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			titleTypeTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));
			ddTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));

			// add group and file
			List<String> initScripts = List.of("add_groups", "add_links");
			Map<String, Object> customTestMap = new HashMap<>(ctx.getTestScriptParams());
			customTestMap.put("titleId", getTitleTypeId(handle, "PROPRIETA"));

			execSqlFiles(this.getClass(), initScripts, customTestMap);

			Long partyId = 555L;
			Long landLinkId = -101L;
			AbsoluteDate refDate = AbsoluteDate.of(LocalDateTime.now());
			String definitionCode = "DEF_FILE";
			String fileId = "123456";
			Response mockResponse = Response.ok().build();
			given(fileStoreProxyClient.getFileContent(anyString(), any(), anyString(), anyString())).willReturn(mockResponse);

			LandLinkDocumentRes documentRes = givenDocument(partyId, landLinkId, refDate, definitionCode, Map.of(
					"descr", "test", 
					"file", fileId));

			InvalidDocumentException documentException = assertThrows(InvalidDocumentException.class,
					() -> service.getDocumentFileContent(ctx.getReqContext(), partyId, landLinkId, refDate, documentRes.getDocumentId(), "987654"));

			assertThat(documentException).isNotNull()
					.extracting(InvalidDocumentException::getCode).isEqualTo(ErrEnum.DYNAMIC_DOCUMENT_FILE_NOT_FOUND.toString());

			handle.rollback();
		});
	}

	// ----- getDocumentFileMetadata -----
	@Test
	void test_getDocumentFileMetadata_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			titleTypeTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));
			ddTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));

			// add group and file
			List<String> initScripts = List.of("add_groups", "add_links");
			Map<String, Object> customTestMap = new HashMap<>(ctx.getTestScriptParams());
			customTestMap.put("titleId", getTitleTypeId(handle, "PROPRIETA"));

			execSqlFiles(this.getClass(), initScripts, customTestMap);

			Long partyId = 555L;
			Long landLinkId = -101L;
			AbsoluteDate refDate = AbsoluteDate.of(LocalDateTime.now());
			String definitionCode = "DEF_FILE";
			String fileId = "123456";
			Response mockResponse = Response.ok().build();
			given(fileStoreProxyClient.getFileMetadata(anyString(), any(), anyString(), anyString())).willReturn(mockResponse);

			LandLinkDocumentRes documentRes = givenDocument(partyId, landLinkId, refDate, definitionCode, Map.of(
					"descr", "test",
					"file", fileId));

			Response documentFileMetadata = service.getDocumentFileMetadata(ctx.getReqContext(), partyId, landLinkId, refDate, documentRes.getDocumentId(), fileId);

			assertThat(documentFileMetadata).isNotNull().isSameAs(mockResponse);

			handle.rollback();
		});
	}

	private LandLinkDocumentRes givenDocument(Long partyId, Long landLinkId, AbsoluteDate referenceDate,
			String definitionCode, Map<String, Object> docData) {
		Document doc = new Document();
		Map<String, Object> fields = DynamicDocumentUtils.createDoc(docData);
		doc.setFields(fields);
		InsertDocument ins = new InsertDocument();
		ins.setDoc(doc);
		ins.setDefCode(definitionCode);
		ins.setBusinessId(landLinkId);

		return service.insert(ctx.getReqContext(), partyId, landLinkId, referenceDate, ins);
	}

	private Long getTitleTypeId(Handle handle, String titleType) {
		Long titleId = handle.select(
				"select id from cll_title_type "
						+ " WHERE tenant_id= ? "
						+ " and code = ?"
						+ " and (§current_timestamp§ between dt_insert and dt_delete) ",
				ctx.getTenantId(), titleType)
				.mapTo(Long.class)
				.first();
		return titleId;
	}
}
