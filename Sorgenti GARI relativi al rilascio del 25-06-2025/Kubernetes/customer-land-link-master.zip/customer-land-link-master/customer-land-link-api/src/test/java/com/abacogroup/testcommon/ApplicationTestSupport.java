package com.abacogroup.testcommon;

import static com.abacogroup.cllapi.CustomerLandLinkApplication.APP_NAME;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.generic.GenericType;

import com.abacogroup.bundles.listener.configdata.ConfigDataConsumer;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.db.ManagedDataSource;
import liquibase.Liquibase;
import liquibase.database.jvm.JdbcConnection;
import liquibase.resource.ClassLoaderResourceAccessor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ApplicationTestSupport {

	private static Map<Class, Object> services = new HashMap<>();

	private static Properties testProperties;

	public ApplicationTestSupport() {
		this.loadTestProperties();
	}

	public Map<Class, Object> getServices() {
		return services;
	}

	public boolean isExecMigrations() {
		return Boolean.parseBoolean(Optional.ofNullable(testProperties)
				.map(p -> p.getProperty("execMigrations", "true"))
				.orElse("true"));
	}

	public boolean isInitRabbit() {
		return Boolean.parseBoolean(
				Optional.ofNullable(testProperties)
						.map(p -> p.getProperty("initRabbit", "false"))
						.orElse("false"));
	}

	public <T> T register(T service) {
		services.put(service.getClass(), service);
		return service;
	}

	public void execMigrations(Environment environment, DataSourceFactory dataSourceFactory) {
		boolean exeMigrations = isExecMigrations();
		if (!exeMigrations) {
			log.info("AUTOMATIC MIGRATION TURNED OFF... check loadTestProperties() for details");
			return;
		}
		System.out.println("-------- EXEC_MIGRATIONS -----------");
		ManagedDataSource managedDataSource = dataSourceFactory
				.build(environment.metrics(), "migrations-cp-test");
		try (Connection connection = managedDataSource.getConnection()) {
			Liquibase migrator = new Liquibase("migrations-test.xml", new ClassLoaderResourceAccessor(),
					new JdbcConnection(connection));
			migrator.update("");
		} catch (Throwable t) {
			log.error(t.toString());
			fail();
		}
		System.out.println("-------- EXEC_MIGRATIONS_END -----------");
	}

	public void installBundle(Jdbi jdbi, String bundleZipName) throws IOException {
		if (!this.isExecMigrations()) {
			return;
		}

		Long start = System.currentTimeMillis();
		Map<String, String> checksums = jdbi.withHandle(handle -> handle.createQuery("select changeset, md5 from bnd_registry")
				.setMapKeyColumn("changeset")
				.setMapValueColumn("md5")
				.collectInto(new GenericType<>() {
				}));

		var path = Path.of(String.format("src/test/resources/%s-bundle.zip.json", APP_NAME));

		if (!path.toFile().exists()) {
			System.out.println("*************************************");
			System.out.println("");
			System.out.println(String.format("MISSING %s !!!", path));
			System.out.println(String.format("test bundle install skipped", path));
			System.out.println("");
			System.out.println("*************************************");
			return;
		}

		String json = Files.readString(path);
		Map<String, String> expectedChecksums = new ObjectMapper().readValue(json, Map.class);

		if (!checksums.isEmpty() && !expectedChecksums.equals(checksums)) {
			throw new IllegalArgumentException("ci sono divergenze tra i checksum presenti sul db e quelli expected!");
		}
		Path zipPath = Path.of(String.format("src/test/resources/%s-bundle.zip", APP_NAME));
		if (checksums.isEmpty()) {
			try {
				byte[] payload = FileUtils.readFileToByteArray(zipPath.toFile());
				ConfigDataConsumer configDataManager = (ConfigDataConsumer) this.getServices().get(ConfigDataConsumer.class);
				configDataManager.process(payload, UUID.randomUUID().toString(), Map.of("tenant", "*"));
			} catch (Throwable t) {
				log.error(t.toString());
				fail();
			}
		} else {
			log.info("the test bundle install was skipped");
		}
		log.info(String.format("checkSum check in %s millis", System.currentTimeMillis() - start));
	}

	private void loadTestProperties() {
		String filename = "src/test/resources/test.properties";
		log.debug("loading extra test properties from {}", filename);
		try (InputStream input = new FileInputStream(filename)) {
			Properties prop = new Properties();
			prop.load(input);
			testProperties = prop;
		} catch (IOException ex) {
			log.warn("{} not found", filename);
		}
	}

}
