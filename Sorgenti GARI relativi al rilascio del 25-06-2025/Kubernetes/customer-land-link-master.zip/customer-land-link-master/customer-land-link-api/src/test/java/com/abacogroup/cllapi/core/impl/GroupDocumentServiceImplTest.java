package com.abacogroup.cllapi.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.api.GroupDocumentRes;
import com.abacogroup.cllapi.api.req.GroupDocumentSearchReq;
import com.abacogroup.cllapi.bundle.tenant.DynamicDocTenantMessageProcessor;
import com.abacogroup.cllapi.bundle.tenant.TitleTypeTenantMessageProcessor;
import com.abacogroup.cllapi.core.GroupDocumentService;
import com.abacogroup.cllapi.core.utils.DynamicDocumentUtils;
import com.abacogroup.cllapi.exceptions.GroupException;
import com.abacogroup.cllapi.exceptions.InvalidDocumentException;
import com.abacogroup.cllapi.exceptions.InvalidDocumentException.ErrEnum;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.dynamicdocuments.files.FileStoreSupport;
import com.abacogroup.dynamicdocuments.http.RestClient;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.testcommon.ReqContextUtils;
import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import jakarta.ws.rs.core.Response;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.hamcrest.MatcherAssert;
import org.jdbi.v3.core.Handle;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class GroupDocumentServiceImplTest extends JdbiTest {

	private final GroupDocumentService service = getService(GroupDocumentServiceImpl.class);
	private final TitleTypeTenantMessageProcessor titleTypeTenantMessageProcessor = getService(TitleTypeTenantMessageProcessor.class);
	private final DynamicDocTenantMessageProcessor ddTenantMessageProcessor = getService(DynamicDocTenantMessageProcessor.class);
	private final FileStoreProxyClient fileStoreProxyClient = mock(FileStoreProxyClient.class);

	private ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	@BeforeEach
	void setUp() throws AuthenticationException {
		DocumentService documentService = this.getService(DocumentService.class);

		this.injectMock(documentService, mock(RestClient.class));
		this.injectMock(documentService, mock(FileStoreSupport.class));
		this.injectMock(service, documentService);

		this.injectMock(service, fileStoreProxyClient);
	}

	@Test
	void test_InsertUpdateExpireGroupDocument_ok() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			titleTypeTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));
			ddTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));

			// add group
			List<String> initScripts = List.of("add_groups");
			Map<String, Object> customTestMap = new HashMap<>(ctx.getTestScriptParams());
			customTestMap.put("titleId", getTitleTypeId(handle, "PROPRIETA"));

			execSqlFiles(this.getClass(), initScripts, customTestMap);

			Long partyId = 555L;
			Long groupId = -78L;

			String definitionCode = "DEF_1";
			Map<String, Object> doc_def1 = Map.of(
					"id_type", "id_assignment",
					"code", "cp",
					"release_agent", "Comune di Palermo",
					"release_date", "2021-12-03T00:00:00+02:00");

			Document doc = new Document();
			Map<String, Object> fields = DynamicDocumentUtils.createDoc(doc_def1);
			doc.setFields(fields);
			InsertDocument ins = new InsertDocument();
			ins.setDoc(doc);
			ins.setDefCode(definitionCode);
			ins.setBusinessId(groupId);

			// test save
			service.insert(ctx.getReqContext(), partyId, groupId, ins);

			GroupDocumentSearchReq searchReq = new GroupDocumentSearchReq().setDefinitionCode(definitionCode);
			List<GroupDocumentRes> docs = service
					.search(ctx.getReqContext(), partyId, groupId, searchReq, null).getRecords();
			assertThat(docs).hasSize(1);
			MatcherAssert.assertThat(docs.get(0).getData().get("id_type"), is("Deed of Assignment"));
			MatcherAssert.assertThat(docs.get(0).getData().get("code"), is("Copy"));

			// test update
			DynamicDocumentUtils.updateField(doc, "release_agent", "Comune di Verona");
			service.update(ctx.getReqContext(), partyId, groupId, docs.get(0).getDocumentId(), doc);

			List<GroupDocumentRes> updatedDoc = service
					.search(ctx.getReqContext(), partyId, groupId, searchReq, null).getRecords();
			assertThat(updatedDoc).hasSize(1);

			GroupDocumentRes res = service.getGroupDocument(ctx.getReqContext(), partyId, groupId, updatedDoc.get(0).getDocumentId());
			assertThat(res)
					.isNotNull()
					.extracting(GroupDocumentRes::getGroupId)
					.isEqualTo(groupId);
			assertThat(res)
			.isNotNull()
			.extracting(GroupDocumentRes::getData)
			.isEqualTo(Map.of(
							"id_type", "id_assignment",
							"code", "cp",
							"release_agent", "Comune di Verona",
							"release_date", "2021-12-03T00:00:00+02:00"));
			// test expire
			service.expire(ctx.getReqContext(), partyId, groupId, docs.get(0).getDocumentId());

			assertThat(service.search(ctx.getReqContext(), partyId, groupId, searchReq, null).getRecords()).hasSize(0);

			// -------------
			handle.rollback();
		});
	}

	// ----- getDocumentFileContent -----
	@Test
	void test_getDocumentFileContent_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			titleTypeTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));
			ddTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));

			// add group and file
			List<String> initScripts = List.of("add_groups");
			Map<String, Object> customTestMap = new HashMap<>(ctx.getTestScriptParams());
			customTestMap.put("titleId", getTitleTypeId(handle, "PROPRIETA"));

			execSqlFiles(this.getClass(), initScripts, customTestMap);

			Long partyId = 555L;
			Long groupId = -78L;
			String definitionCode = "DEF_FILE";
			String fileId = "123456";
			Response mockResponse = Response.ok().build();
			given(fileStoreProxyClient.getFileContent(anyString(), any(), anyString(), anyString())).willReturn(mockResponse);

			GroupDocumentRes documentRes = givenDocument(partyId, groupId, definitionCode, Map.of(
					"descr", "test",
					"file", fileId));

			Response documentFileContent = service.getDocumentFileContent(ctx.getReqContext(), partyId, groupId, documentRes.getDocumentId(), fileId);

			assertThat(documentFileContent).isNotNull().isSameAs(mockResponse);

			handle.rollback();
		});
	}

	@Test
	void test_getDocumentFileContent_NotExistingGroup() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			titleTypeTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));
			ddTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));

			// add group and file

			Long partyId = 555L;
			Long groupId = 999L;
			String fileId = "123456";

			GroupException groupException = assertThrows(GroupException.class,
					() -> service.getDocumentFileContent(ctx.getReqContext(), partyId, groupId, 999L, fileId));

			assertThat(groupException).isNotNull()
					.extracting(GroupException::getCode).isEqualTo(GroupException.ErrEnum.NOT_FOUND.toString());

			handle.rollback();
		});
	}

	@Test
	void test_getDocumentFileContent_notExistingDoc() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			titleTypeTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));
			ddTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));

			// add group and file
			List<String> initScripts = List.of("add_groups");
			Map<String, Object> customTestMap = new HashMap<>(ctx.getTestScriptParams());
			customTestMap.put("titleId", getTitleTypeId(handle, "PROPRIETA"));

			execSqlFiles(this.getClass(), initScripts, customTestMap);

			Long partyId = 555L;
			Long groupId = -78L;
			String fileId = "123456";
			Response mockResponse = Response.ok().build();
			given(fileStoreProxyClient.getFileContent(anyString(), any(), anyString(), anyString())).willReturn(mockResponse);

			InvalidDocumentException documentException = assertThrows(InvalidDocumentException.class,
					() -> service.getDocumentFileContent(ctx.getReqContext(), partyId, groupId, 999L, fileId));

			assertThat(documentException).isNotNull()
					.extracting(InvalidDocumentException::getCode).isEqualTo(ErrEnum.DYNAMIC_DOCUMENT_NOT_FOUND.toString());

			handle.rollback();
		});
	}

	@Test
	void test_getDocumentFileContent_notExistingFile() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			titleTypeTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));
			ddTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));

			// add group and file
			List<String> initScripts = List.of("add_groups");
			Map<String, Object> customTestMap = new HashMap<>(ctx.getTestScriptParams());
			customTestMap.put("titleId", getTitleTypeId(handle, "PROPRIETA"));

			execSqlFiles(this.getClass(), initScripts, customTestMap);

			Long partyId = 555L;
			Long groupId = -78L;
			String definitionCode = "DEF_FILE";
			String fileId = "123456";
			Response mockResponse = Response.ok().build();
			given(fileStoreProxyClient.getFileContent(anyString(), any(), anyString(), anyString())).willReturn(mockResponse);

			GroupDocumentRes documentRes = givenDocument(partyId, groupId, definitionCode, Map.of(
					"descr", "test",
					"file", fileId));

			InvalidDocumentException documentException = assertThrows(InvalidDocumentException.class,
					() -> service.getDocumentFileContent(ctx.getReqContext(), partyId, groupId, documentRes.getDocumentId(), "987654"));

			assertThat(documentException).isNotNull()
					.extracting(InvalidDocumentException::getCode).isEqualTo(ErrEnum.DYNAMIC_DOCUMENT_FILE_NOT_FOUND.toString());

			handle.rollback();
		});
	}

	// ----- getDocumentFileMetadata -----
	@Test
	void test_getDocumentFileMetadata_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			titleTypeTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));
			ddTenantMessageProcessor.onMessage(new TenantMessage().setTenantId(ctx.getTenantId()));

			// add group and file
			List<String> initScripts = List.of("add_groups");
			Map<String, Object> customTestMap = new HashMap<>(ctx.getTestScriptParams());
			customTestMap.put("titleId", getTitleTypeId(handle, "PROPRIETA"));

			execSqlFiles(this.getClass(), initScripts, customTestMap);

			Long partyId = 555L;
			Long groupId = -78L;
			String definitionCode = "DEF_FILE";
			String fileId = "123456";
			Response mockResponse = Response.ok().build();
			given(fileStoreProxyClient.getFileMetadata(anyString(), any(), anyString(), anyString())).willReturn(mockResponse);

			GroupDocumentRes documentRes = givenDocument(partyId, groupId, definitionCode, Map.of(
					"descr", "test",
					"file", fileId));

			Response documentFileMetadata = service.getDocumentFileMetadata(ctx.getReqContext(), partyId, groupId, documentRes.getDocumentId(), fileId);

			assertThat(documentFileMetadata).isNotNull().isSameAs(mockResponse);

			handle.rollback();
		});
	}

	private GroupDocumentRes givenDocument(Long partyId, Long groupId, String definitionCode, Map<String, Object> docData) {
		Document doc = new Document();
		Map<String, Object> fields = DynamicDocumentUtils.createDoc(docData);
		doc.setFields(fields);
		InsertDocument ins = new InsertDocument();
		ins.setDoc(doc);
		ins.setDefCode(definitionCode);
		ins.setBusinessId(groupId);

		return service.insert(ctx.getReqContext(), partyId, groupId, ins);
	}

	private Long getTitleTypeId(Handle handle, String titleType) {
		Long titleId = handle.select(
				"select id from cll_title_type "
						+ " WHERE tenant_id= ? "
						+ " and code = ?"
						+ " and (§current_timestamp§ between dt_insert and dt_delete) ",
				ctx.getTenantId(), titleType)
				.mapTo(Long.class)
				.first();
		return titleId;
	}

}
