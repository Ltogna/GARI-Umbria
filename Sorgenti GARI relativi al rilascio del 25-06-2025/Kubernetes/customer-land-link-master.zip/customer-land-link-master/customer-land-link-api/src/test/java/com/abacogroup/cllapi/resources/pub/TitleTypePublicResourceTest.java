package com.abacogroup.cllapi.resources.pub;

import static com.abacogroup.cllapi.core.client.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import com.abacogroup.cllapi.api.TitleType;
import com.abacogroup.cllapi.api.TitleType.TitleTypeBuilder;
import com.abacogroup.cllapi.core.TitleTypeService;
import com.abacogroup.cllapi.core.client.WebCliHelper;
import com.abacogroup.cllcli.api.v1.TitleTypeReponseV1;
import com.abacogroup.common.resources.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.UriBuilder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class TitleTypePublicResourceTest {

	private final TitleTypeService titleTypeService = Mockito.mock(TitleTypeService.class);

	private final TitleTypePublicResource resource = new TitleTypePublicResource(titleTypeService);
	private final ResourceExtension EXT = WebCliHelper.createEXT(resource);


	// ----- searchTitleTypes -----
	@Test
	void test_searchTitleTypes_ok() {

		Map<String, Object> queryMap = new HashMap<>();

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass());//.path(resource.getClass(), "searchTitleTypes");
		queryMap.forEach(uriBuilder::queryParam);
		String uri = uriBuilder.build(TENANT).toString();
		System.out.println(uri);

		var mockRes = givenTitleType().build();
		given(titleTypeService.searchAll(any()))
				.willReturn(List.of(mockRes));

		List<TitleTypeReponseV1> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.usingRecursiveComparison()
				.isEqualTo(List.of(mockRes));

		verify(titleTypeService).searchAll(any(ReqContext.class));
	}

	// ----- getTitleType -----
	@Test
	void test_getTitleType_ok() {
		Long id = -1L;

		Map<String, Object> queryMap = new HashMap<>();

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "getTitleType");
		queryMap.forEach(uriBuilder::queryParam);
		String uri = uriBuilder.build(TENANT, id).toString();
		System.out.println(uri);

		var mockRes = givenTitleType().build();
		given(titleTypeService.getById(any(), anyLong()))
				.willReturn(Optional.of(mockRes));

		TitleTypeReponseV1 res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.usingRecursiveComparison()
				.isEqualTo(mockRes);

		verify(titleTypeService).getById(any(ReqContext.class), eq(id));
	}





	// ################################################################################################################################################## //

	private static TitleTypeBuilder<?, ?> givenTitleType() {
		return TitleType.builder()
				.setId(-1L)
				.setI18nCode("TITLE TYPE 1")
				.setCode("TT1")
				.setDayToReq(false)
				.setFlDayToReq(0)
				.setFlDayToEditable(0)
				.setFlAllowFutureDayFrom(0);
	}

}
