package com.abacogroup.cllapi.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.abacogroup.cllapi.api.BlockRes;
import com.abacogroup.cllapi.api.GroupBaseRes;
import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.api.LandLinkRes.LandLinkResBuilder;
import com.abacogroup.cllapi.api.LandLinkSectorSummaryRes;
import com.abacogroup.cllapi.api.LandLinkTitleSummaryRes;
import com.abacogroup.cllapi.api.ParcelRes;
import com.abacogroup.cllapi.api.SectorRes;
import com.abacogroup.cllapi.api.TitleType;
import com.abacogroup.cllapi.core.LandLinkService;
import com.abacogroup.cllapi.core.LandLinkV1Service;
import com.abacogroup.cllapi.core.PartyClientService;
import com.abacogroup.cllapi.db.dao.LandLinkDAO;
import com.abacogroup.cllcli.api.v1.LandLinkSectorSummaryResponseV1;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;

class LandLinkV1ServiceImplTest {

	private final LandLinkService landLinkService = Mockito.mock(LandLinkServiceImpl.class);
	private final PartyClientService partyClientService = Mockito.mock(PartyClientService.class); 
	private final LandLinkDAO landLinkDAO = Mockito.mock(LandLinkDAO.class);
	private final LandLinkV1Service landLinkV1Service = new LandLinkV1ServiceImpl(landLinkService, partyClientService, landLinkDAO);

	// ----- getSummary -----
	@Test
	void test_getSummary_ok() {
		Long partyId = 555L;
		ReqContext reqContext = new ReqContext("test", "user", "en");
		List<LandLinkSectorSummaryRes> mockRes = List.of(
				buildSectorSummary(15L, 37485L, 37485L, 123L, "A061", "AFFI (VR)",
						buildTitleSummary(11L, 27000L, 27000L, 1L, "PROPRIETA"),
						buildTitleSummary(4L, 10485L, 10485L, 2L, "AFFITTO"),
						buildTitleSummary(0L, 0L, 0L, 3L, "MEZZADRIA"),
						buildTitleSummary(0L, 0L, 0L, 4L, "ALTRA FORMA"),
						buildTitleSummary(0L, 0L, 0L, 5L, "USO CIVICO")),
				buildSectorSummary(5L, 17485L, 7485L, 456L, "A737", "BELFIORE (VR)",
						buildTitleSummary(0L, 0L, 0L, 1L, "PROPRIETA"),
						buildTitleSummary(5L, 17485L, 7485L, 2L, "AFFITTO"),
						buildTitleSummary(0L, 0L, 0L, 3L, "MEZZADRIA"),
						buildTitleSummary(0L, 0L, 0L, 4L, "ALTRA FORMA"),
						buildTitleSummary(0L, 0L, 0L, 5L, "USO CIVICO"))
		);
		given(landLinkService.getSummary(any(), anyLong())).willReturn(mockRes);

		List<LandLinkSectorSummaryResponseV1> summary = landLinkV1Service.getSummary(reqContext, partyId);

		verify(landLinkService).getSummary(same(reqContext), same(partyId));
		assertThat(summary).isNotNull()
				.usingRecursiveComparison()
				.isEqualTo(mockRes);
	}

	// ################################################################################################################################################## //

	private static LandLinkSectorSummaryRes buildSectorSummary(long linkCount, long totParcelAreaSqm, long totTitleTypeAreaSqm, long id, String sectorCode,
			String shortDescr, LandLinkTitleSummaryRes... titleSummaryRes) {
		return LandLinkSectorSummaryRes.builder()
				.setLinkCount(linkCount)
				.setTotParcelAreaSqm(totParcelAreaSqm)
				.setTotTitleTypeAreaSqm(totTitleTypeAreaSqm)
				.setSector(SectorRes.builder()
						.setId(id)
						.setSectorCode(sectorCode)
						.setShortDescr(shortDescr)
						.setDescription(shortDescr + " - " + sectorCode)
						.build())
				.setTitleSummaryRes(List.of(titleSummaryRes))
				.build();
	}

	private static LandLinkTitleSummaryRes buildTitleSummary(long linkCount, long totParcelAreaSqm, long totTitleTypeAreaSqm, long id, String code) {
		return LandLinkTitleSummaryRes.builder()
				.setLinkCount(linkCount)
				.setTotParcelAreaSqm(totParcelAreaSqm)
				.setTotTitleTypeAreaSqm(totTitleTypeAreaSqm)
				.setTitleType(TitleType.builder()
						.setId(id)
						.setCode(code)
						.setFlDayToReq(0)
						.setFlDayToEditable(0)
						.setFlAllowFutureDayFrom(0)
						.setI18nCode(code)
						.build())
				.build();
	}

	private static LandLinkResBuilder<?, ?> landLinkResBuilder(Long partyId, Long groupId) {
		return LandLinkRes.builder()
				.setId(-1L)
				.setGroup(GroupBaseRes.builder()
						.setId(groupId)
						.setDescr("Group " + groupId)
						.build())
				.setPartyId(partyId)
				.setTitleType(TitleType.builder()
						.setId(-1L)
						.setI18nCode("TITLE TYPE 1")
						.setCode("TT1")
						.setFlDayToReq(0)
						.setFlDayToEditable(0)
						.setFlAllowFutureDayFrom(0)
						.build())
				.setTitleTypePerc(BigDecimal.valueOf(100).setScale(8, RoundingMode.HALF_UP))
				.setParcel(
						ParcelRes.builder()
								.setParcel("01234/A")
								.setSector(SectorRes.builder()
										.setSectorCode("A001")
										.build())
								.setBlock(BlockRes.builder()
										.setBlockCode("1")
										.build())
								.setAreaSqm(15000L)
								.build()
				)
				.setDayFrom(AbsoluteDate.of("20200202"))
				.setDayTo(AbsoluteDate.of("99991231"))
				.setMaxAnomalyLevel(null);
	}

}
