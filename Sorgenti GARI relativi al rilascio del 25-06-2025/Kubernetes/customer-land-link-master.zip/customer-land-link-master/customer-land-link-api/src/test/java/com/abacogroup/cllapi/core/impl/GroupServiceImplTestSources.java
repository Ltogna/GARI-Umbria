package com.abacogroup.cllapi.core.impl;

import static com.abacogroup.cllapi.exceptions.LandLinkException.ErrEnum.INVALID_DAY_FROM;
import static com.abacogroup.cllapi.exceptions.LandLinkException.ErrEnum.INVALID_DAY_TO;
import static org.assertj.core.api.Assertions.tuple;
import static org.junit.jupiter.params.provider.Arguments.arguments;

import com.abacogroup.cllapi.api.req.GroupSearchReq;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import java.util.stream.Stream;
import org.assertj.core.groups.Tuple;
import org.junit.jupiter.params.provider.Arguments;

class GroupServiceImplTestSources {

	static Stream<Arguments> test_insert_datesK0() {
		// String testName, long titleTypeId, AbsoluteDate dayFrom, AbsoluteDate dayTo, LandLinkException.ErrEnum errCode
		return Stream.of(
				arguments("dayFrom null", -100L, AbsoluteDate.of(""), AbsoluteDate.of("99991231"), INVALID_DAY_FROM),
				arguments("dayFrom in the future", -100L, AbsoluteDate.of("20240101"), AbsoluteDate.of("99991231"), INVALID_DAY_FROM),
				arguments("dayTo null (title type with dayTo required)", -101L, AbsoluteDate.of("20200202"), AbsoluteDate.of(""), INVALID_DAY_TO),
				arguments("dayTo 99991231 (title type with dayTo required)", -101L, AbsoluteDate.of("20200202"), AbsoluteDate.of("99991231"), INVALID_DAY_TO),
				arguments("dayTo in the past", -101L, AbsoluteDate.of("20200202"), AbsoluteDate.of("20211202"), INVALID_DAY_TO)
		);
	}

	/**
	 * GroupRes::getId,
	 * GroupRes::getLinkCount,
	 * g -> g.getDayFrom().getValue(),
	 * g -> g.getDayTo().getValue()
	 */
	static Stream<Arguments> test_search() {
		return Stream.of(
				Arguments.of("basic_search", new GroupSearchReq(), AbsoluteDate.of("20230309"), new Tuple[] {
						tuple(-3L, 3L, "20220101", "20261231"),
						tuple(-2L, 3L, "20200202", "20250505"),
						tuple(-1L, 4L, "20200202", "99991231")}),

				Arguments.of("by descr 1", new GroupSearchReq().setDescr("group"), AbsoluteDate.of("20230309"), new Tuple[] {
						tuple(-3L, 3L, "20220101", "20261231"),
						tuple(-2L, 3L, "20200202", "20250505"),
						tuple(-1L, 4L, "20200202", "99991231")}),

				Arguments.of("by descr 2", new GroupSearchReq().setDescr("test"), AbsoluteDate.of("20230309"), new Tuple[] {
						tuple(-3L, 3L, "20220101", "20261231")}),

				Arguments.of("by descr (group2: dayTo 2022< refDate)", new GroupSearchReq().setDescr("group 2"), AbsoluteDate.of("20250506"), new Tuple[0]),

				Arguments.of("by titleTypeId", new GroupSearchReq().setTitleTypeId(-100L), AbsoluteDate.of("20230309"), new Tuple[] {
						tuple(-1L, 4L, "20200202", "99991231")}),
				Arguments.of("by titleTypeId", new GroupSearchReq().setTitleTypeId(-101L), AbsoluteDate.of("20230309"), new Tuple[] {
						tuple(-3L, 3L, "20220101", "20261231")}),

				Arguments.of("by expired titleTypeId", new GroupSearchReq().setTitleTypeId(-103L), AbsoluteDate.of("20230309"), new Tuple[0]),

				Arguments.of("by past refDay and descr", new GroupSearchReq().setDescr("group 1"), AbsoluteDate.of("20211202"), new Tuple[] {
						tuple(-1L, 4L, "20200202", "99991231")}),

				Arguments.of("by descr and titleTypeId", new GroupSearchReq().setTitleTypeId(-100L).setDescr("group 1"), AbsoluteDate.of("20230309"), new Tuple[] {
						tuple(-1L, 4L, "20200202", "99991231")}),

				Arguments.of("by descr and titleTypeId", new GroupSearchReq().setTitleTypeId(-100L).setDescr("wrong descr"), AbsoluteDate.of("20230309"), new Tuple[0]),

				Arguments.of("by past ref date", new GroupSearchReq(), AbsoluteDate.of("20210101"), new Tuple[] {
						tuple(-5L, 2L, "20200202", "20211202"),
						tuple(-2L, 3L, "20200202", "20250505"),
						tuple(-1L, 4L, "20200202", "99991231")}),

				Arguments.of("search elapsed", new GroupSearchReq().setShowElapsed(true), AbsoluteDate.of("20230309"), new Tuple[] {
						tuple(-5L, 2L, "20200202", "20211202"),
						tuple(-9L, 1L,"20011002","20200202")
				}),
				Arguments.of("search elapsed by descr", new GroupSearchReq().setShowElapsed(true).setDescr("group 5"), AbsoluteDate.of("20230309"), new Tuple[] {
						tuple(-5L, 2L, "20200202", "20211202")
				}),
				Arguments.of("search elapsed by titleTypeId", new GroupSearchReq().setShowElapsed(true).setTitleTypeId(-100L), AbsoluteDate.of("20230309"), new Tuple[] {
						tuple(-9L, 1L,"20011002","20200202")
				})
		);
	}
}
