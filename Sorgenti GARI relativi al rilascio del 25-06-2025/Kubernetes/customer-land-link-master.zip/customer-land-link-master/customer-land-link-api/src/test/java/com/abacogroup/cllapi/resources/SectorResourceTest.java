package com.abacogroup.cllapi.resources;

import static com.abacogroup.cllapi.core.client.WebCliHelper.BASIC_USERNAME;
import static com.abacogroup.cllapi.core.client.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import java.util.List;
import java.util.stream.Collectors;

import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import com.abacogroup.cllapi.api.SectorRes;
import com.abacogroup.cllapi.core.LpisClientService;
import com.abacogroup.cllapi.core.client.WebCliHelper;
import com.abacogroup.cllapi.core.impl.LpisClientServiceImpl;
import com.abacogroup.cllapi.resources.mapper.SectorMapper;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.lpisgisserver.api.v1.PublicSector;
import com.abacogroup.lpisgisserver.api.v1.PublicSector.PublicSectorBuilder;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.UriBuilder;

@ExtendWith(DropwizardExtensionsSupport.class)
public class SectorResourceTest {

	private final LpisClientService lpisClientService = Mockito.mock(LpisClientServiceImpl.class);

	private final ResourceExtension EXT = WebCliHelper.createEXT(new SectorResource(lpisClientService));

	@Test
	void test_getSectors_ok() {
		String filter = "AFF";

		UriBuilder uriBuilder = UriBuilder.fromResource(SectorResource.class).path(SectorResource.class, "getSectors");
		uriBuilder.queryParam("filter", filter);

		String uri = uriBuilder.build(TENANT).toString();
		System.out.println(uri);

		List<PublicSector> mockRes = List.of(
				publicSectorBuilder(1L, "A061").build(),
				publicSectorBuilder(2L, "A062").build());

		given(lpisClientService.getSectors(any(), any())).willReturn(mockRes);

		List<SectorRes> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes.stream().map(SectorMapper.INSTANCE::toSectorRes)
						.collect(Collectors.toList()));

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(lpisClientService).getSectors(reqCtxCaptor.capture(), eq(filter));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	// #######################################################################

	private static PublicSectorBuilder<?, ?> publicSectorBuilder(Long id, String sectorCode) {
		return PublicSector.builder()
				.setId(id)
				.setSectorCode(sectorCode)
				.setDescription("descr " + sectorCode)
				.setShortDescr("shortdescr " + sectorCode);
	}

}
