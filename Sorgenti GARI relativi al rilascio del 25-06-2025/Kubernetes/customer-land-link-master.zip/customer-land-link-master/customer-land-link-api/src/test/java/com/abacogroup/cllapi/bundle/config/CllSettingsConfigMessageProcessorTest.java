package com.abacogroup.cllapi.bundle.config;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.db.dao.CllSettingsDAO;
import com.abacogroup.testcommon.ReqContextUtils;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class CllSettingsConfigMessageProcessorTest extends JdbiTest {

	private final CllSettingsConfigMessageProcessor processor = getService(CllSettingsConfigMessageProcessor.class);

	private final CllSettingsDAO dao = this.getDAO(CllSettingsDAO.class);

	private ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	@Test
	void test_when_one_setting_is_defined() {
		var message = new ConfigDataMessage()
				.setTenantId(ctx.getTenantId())
				.setConfigFiles(List.of(
						file2Path.apply("cll_settings_0.json")
				));

		getJdbi().useHandle(handle -> {
			handle.begin();
			processor.onMessage(message);

			Assertions.assertThat(dao.countAll(ctx.getTenantId()))
					.isEqualTo(1L);

			Assertions.assertThat(dao.loadOne(ctx.getTenantId()).get().getLpisSubSeparator())
					.isEqualTo("-");

			handle.rollback();
		});
	}

	@Test
	void test_when_many_settings_are_defined_then_persist_last_one() {
		var message = new ConfigDataMessage()
				.setTenantId(ctx.getTenantId())
				.setConfigFiles(List.of(
						file2Path.apply("cll_settings_1.json"), //wins this!
						file2Path.apply("cll_settings_0.json")
				));

		getJdbi().useHandle(handle -> {
			handle.begin();
			processor.onMessage(message);

			Assertions.assertThat(dao.countAll(ctx.getTenantId()))
					.isEqualTo(1L);

			Assertions.assertThat(dao.loadOne(ctx.getTenantId()).get().getLpisSubSeparator())
					.isEqualTo("/");

			handle.rollback();
		});
	}

}
