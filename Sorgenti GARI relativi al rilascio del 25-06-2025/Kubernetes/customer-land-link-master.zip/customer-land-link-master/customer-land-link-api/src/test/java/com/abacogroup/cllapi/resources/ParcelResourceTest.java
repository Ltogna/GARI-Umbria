package com.abacogroup.cllapi.resources;

import static com.abacogroup.cllapi.core.client.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import com.abacogroup.cllapi.api.ParcelRes;
import com.abacogroup.cllapi.api.ParcelSearchRes;
import com.abacogroup.cllapi.api.ParcelSearchRes.ParcelSearchResBuilder;
import com.abacogroup.cllapi.api.SectorRes;
import com.abacogroup.cllapi.api.req.ParcelSearchReq;
import com.abacogroup.cllapi.core.ParcelService;
import com.abacogroup.cllapi.core.client.WebCliHelper;
import com.abacogroup.cllapi.core.impl.ParcelServiceImpl;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.UriBuilder;

@ExtendWith(DropwizardExtensionsSupport.class)
class ParcelResourceTest {

	private final ParcelService parcelService = Mockito.mock(ParcelServiceImpl.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new ParcelResource(parcelService));

	private ObjectMapper mapper = new ObjectMapper();




	@Test
	void should_searchParcels() {
		Long partyId = 555L;
		AbsoluteDate referenceDate = AbsoluteDate.of("20230307");

		ParcelSearchReq searchReq = new ParcelSearchReq()
				.setCuaa("CUAA")
				.setSectorCode("A001")
				.setBlockCode("1")
				.setParcelCode("00001")
				.setSubParcel("A")
				.setDayFrom(referenceDate.getValue());

		Map<String, Object> queryMap = mapper.convertValue(searchReq, Map.class);

		UriBuilder uriBuilder = UriBuilder.fromResource(ParcelResource.class).path(ParcelResource.class, "searchParcels");

		queryMap.entrySet().stream().filter(e -> e.getValue() != null)
				.forEach(e -> uriBuilder.queryParam(e.getKey(), e.getValue()));
		String uri = uriBuilder.build(TENANT, partyId).toString();
		System.out.println(uri);

		InfiniteListResultsImpl<ParcelSearchRes> mockRes = new InfiniteListResultsImpl<>(List.of(
				parcelSearchResBuilder(partyId, 101L, "1").build(),
				parcelSearchResBuilder(partyId, 102L, "2").build(),
				parcelSearchResBuilder(partyId, 103L, "3").build()
		), "11");
		given(parcelService.search(any(ReqContext.class), anyLong(), any(ParcelSearchReq.class), any(), any(), any(), any(), any(), any())).willReturn(mockRes);

		InfiniteListResultsImpl<ParcelSearchRes> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.extracting(InfiniteListResultsImpl::getRecords)
				.isEqualTo(mockRes.getRecords());

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(parcelService).search(reqCtxCaptor.capture(), eq(partyId), eq(searchReq), any(), any(), any(), any(), isNull(), any());

	}
	@Test
	void should_searchParcelsByGroup() {
		Long partyId = 555L;
		Long groupId = 1L;
		AbsoluteDate referenceDate = AbsoluteDate.of("20230307");

		ParcelSearchReq searchReq = new ParcelSearchReq()
				.setCuaa("CUAA")
				.setSectorCode("A001")
				.setBlockCode("1")
				.setParcelCode("00001")
				.setSubParcel("A")
				.setDayFrom(referenceDate.getValue());

		Map<String, Object> queryMap = mapper.convertValue(searchReq, Map.class);

		UriBuilder uriBuilder = UriBuilder.fromResource(ParcelResource.class).path(ParcelResource.class, "searchParcelsByGroup");

		queryMap.entrySet().stream().filter(e -> e.getValue() != null)
				.forEach(e -> uriBuilder.queryParam(e.getKey(), e.getValue()));
		String uri = uriBuilder.build(TENANT, partyId, groupId).toString();
		System.out.println(uri);

		List<ParcelSearchRes> mockRes =List.of(
				parcelSearchResBuilder(partyId, 101L, "1").build(),
				parcelSearchResBuilder(partyId, 102L, "2").build(),
				parcelSearchResBuilder(partyId, 103L, "3").build()
		);
		given(parcelService.searchByGroup(any(ReqContext.class), anyLong(),anyLong(), any(ParcelSearchReq.class))).willReturn(mockRes);

		List<ParcelSearchRes> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(parcelService).searchByGroup(reqCtxCaptor.capture(), eq(partyId), eq(groupId), eq(searchReq));

	}

	private ParcelSearchResBuilder<?, ?> parcelSearchResBuilder(Long partyId, Long parcelId, String sectorCode) {
		return ParcelSearchRes.builder()
				//.setPartyId(partyId)
				.setParcel(ParcelRes.builder()
						.setId(parcelId)
						.setSector(SectorRes.builder()
								.setSectorCode(sectorCode)
								.build())
						.build());
	}
}
