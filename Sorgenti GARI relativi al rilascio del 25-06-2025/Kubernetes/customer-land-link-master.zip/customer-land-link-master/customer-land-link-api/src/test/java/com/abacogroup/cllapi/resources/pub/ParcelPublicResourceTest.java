package com.abacogroup.cllapi.resources.pub;

import static com.abacogroup.cllapi.core.client.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;

import com.abacogroup.cllapi.core.ParcelV1Service;
import com.abacogroup.cllapi.core.client.WebCliHelper;
import com.abacogroup.cllapi.core.impl.ParcelV1ServiceImpl;
import com.abacogroup.cllcli.api.v1.LandLinkLeadingResV1;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;
import java.util.List;

@ExtendWith(DropwizardExtensionsSupport.class)
class ParcelPublicResourceTest {

    private final ParcelV1Service parcelV1Service = Mockito.mock(ParcelV1ServiceImpl.class);

    private final ResourceExtension EXT = WebCliHelper.createEXT(new ParcelPublicResource(parcelV1Service));


    @Test
    void test_getParcelLeadingList() {
        Long parcelId = 100L;

        UriBuilder uriBuilder = UriBuilder.fromResource(ParcelPublicResource.class)
                .path(ParcelPublicResource.class, "getParcelLeadingList");
        String uri = uriBuilder.build(TENANT, parcelId).toString();

        given(parcelV1Service.getParcelLeadingList(any(ReqContext.class), anyLong(), any(AbsoluteDate.class)))
                .willReturn(List.of(LandLinkLeadingResV1.builder()
                        .setPartyId(555L)
                        .setId(-999L)
                        .build()));

        Response res = EXT.getJerseyTest().target()
                .path(uri)
                .queryParam("referenceDate", "20230930")
                .request()
                .header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
                .get(new GenericType<>() {
                });

        assertThat(res.getStatus()).isEqualTo(200);

        //test the public uri
        assertThat(uri).isEqualTo(String.format("/master/public/v1/parcel/%d/parties", parcelId));
    }

    @Test
    void test_searchParcels() {
        Long partyId = 555L;

        UriBuilder uriBuilder = UriBuilder.fromResource(ParcelPublicResource.class)
                .path(ParcelPublicResource.class, "searchParcels");
        String uri = uriBuilder.build(TENANT, partyId).toString();

        given(parcelV1Service.search(any(), any(), any(), any(), any(), any(), any(), any()))
                .willReturn(new InfiniteListResultsImpl<>(List.of(), null));

        Response res = EXT.getJerseyTest().target()
                .path(uri)
                .queryParam("dayFrom", "20230930")
                .request()
                .header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
                .get(new GenericType<>() {
                });

        assertThat(res.getStatus()).isEqualTo(200);
        //test the public uri
        assertThat(uri).isEqualTo(String.format("/master/public/v1/parties/%d/parcels", partyId));
    }
}
