package com.abacogroup.cllapi.resources;

import static com.abacogroup.cllapi.core.client.WebCliHelper.BASIC_USERNAME;
import static com.abacogroup.cllapi.core.client.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import java.time.Clock;
import java.util.List;
import java.util.Map;

import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import com.abacogroup.cllapi.api.LandLinkDocumentRes;
import com.abacogroup.cllapi.api.LandLinkDocumentRes.LandLinkDocumentResBuilder;
import com.abacogroup.cllapi.api.req.LandLinkDocumentSearchReq;
import com.abacogroup.cllapi.core.LandLinkDocumentService;
import com.abacogroup.cllapi.core.client.WebCliHelper;
import com.abacogroup.cllapi.core.impl.LandLinkDocumentServiceImpl;
import com.abacogroup.common.resources.ReqContext;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;

@ExtendWith(DropwizardExtensionsSupport.class)
class LandLinkDocumentResourceTest {

	private final Clock appClock = Clock.systemDefaultZone();
	private final LandLinkDocumentService landLinkDocumentService = Mockito.mock(LandLinkDocumentServiceImpl.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new LandLinkDocumentResource(landLinkDocumentService, appClock));

	@Test
	void should_search() {
		Long partyId = 555L;
		Long landLinkId = 100L;
		String definitionCode = "DEF_1";
		String nextKey = "11";

		LandLinkDocumentSearchReq searchReq = new LandLinkDocumentSearchReq()
				.setDefinitionCode(definitionCode);

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> queryMap = mapper.convertValue(searchReq, Map.class);

		UriBuilder uriBuilder = UriBuilder.fromResource(LandLinkDocumentResource.class).path(LandLinkDocumentResource.class, "search");
		queryMap.forEach(uriBuilder::queryParam);
		String uri = uriBuilder.build(TENANT, partyId, landLinkId).toString();
		System.out.println(uri);

		InfiniteListResultsImpl<LandLinkDocumentRes> mockRes = new InfiniteListResultsImpl<>(List.of(
				landLinkDocumentResBuilder(101L, landLinkId, definitionCode).build(),
				landLinkDocumentResBuilder(102L, landLinkId, definitionCode).build(),
				landLinkDocumentResBuilder(103L, landLinkId, definitionCode).build()), nextKey);

		given(landLinkDocumentService.search(any(), anyLong(), anyLong(), any(), any(), any())).willReturn(mockRes);

		InfiniteListResultsImpl<LandLinkDocumentRes> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.queryParam("nextKey", nextKey)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.extracting(InfiniteListResultsImpl::getRecords)
				.isEqualTo(mockRes.getRecords());

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(landLinkDocumentService).search(reqCtxCaptor.capture(), eq(partyId), eq(landLinkId), any(), eq(searchReq), eq(nextKey));
	}

	// ----- getByDocumentId -----
	@Test
	void test_getByDocumentId_ok() {
		Long partyId = 555L;
		Long landLinkId = 100L;
		Long documentId = 123L;

		UriBuilder uriBuilder = UriBuilder.fromResource(LandLinkDocumentResource.class).path(LandLinkDocumentResource.class, "getByDocumentId");
		String uri = uriBuilder.build(TENANT, partyId, landLinkId, documentId).toString();
		System.out.println(uri);

		LandLinkDocumentRes mockRes = landLinkDocumentResBuilder(101L, landLinkId, "DEF_TEST").build();
		given(landLinkDocumentService.getLandLinkDocument(any(), anyLong(), anyLong(), any(), anyLong())).willReturn(mockRes);

		LandLinkDocumentRes res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull().isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(landLinkDocumentService).getLandLinkDocument(reqCtxCaptor.capture(), eq(partyId), eq(landLinkId), any(), eq(documentId));
	}

	// ----- getDocumentFileContent -----
	@Test
	void test_getDocumentFileContent_ok() {
		Long partyId = 555L;
		Long landLinkId = 100L;
		Long documentId = 123L;
		String fileId = "theFileId";

		UriBuilder uriBuilder = UriBuilder.fromResource(LandLinkDocumentResource.class).path(LandLinkDocumentResource.class, "getDocumentFileContent");
		String uri = uriBuilder.build(TENANT, partyId, landLinkId, documentId, "my-bucket", fileId).toString();
		System.out.println(uri);

		Response mockRes = Response.ok("my file content".getBytes(), MediaType.TEXT_PLAIN_TYPE).build();
		given(landLinkDocumentService.getDocumentFileContent(any(), anyLong(), anyLong(), any(), anyLong(), anyString())).willReturn(mockRes);

		Response res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get();

		assertThat(res).isNotNull();
		assertThat(res.readEntity(String.class)).isNotNull()
				.isEqualTo("my file content");

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(landLinkDocumentService).getDocumentFileContent(reqCtxCaptor.capture(), eq(partyId), eq(landLinkId), any(), eq(documentId), eq(fileId));
	}

	// ----- getDocumentFileMetadata -----
	@Test
	void test_getDocumentFileMetadata_ok() {
		Long partyId = 555L;
		Long landLinkId = 100L;
		Long documentId = 123L;
		String fileId = "theFileId";

		UriBuilder uriBuilder = UriBuilder.fromResource(LandLinkDocumentResource.class).path(LandLinkDocumentResource.class, "getDocumentFileMetadata");
		String uri = uriBuilder.build(TENANT, partyId, landLinkId, documentId, "my-bucket", fileId).toString();
		System.out.println(uri);

		Response mockRes = Response.ok("my file content".getBytes(), MediaType.TEXT_PLAIN_TYPE)
				.header("hKey", "hValue").build();
		given(landLinkDocumentService.getDocumentFileMetadata(any(), anyLong(), anyLong(), any(), anyLong(), anyString())).willReturn(mockRes);

		Response res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.head();

		assertThat(res).isNotNull();
		assertThat(res.getHeaderString("Content-type")).isNotNull()
				.isEqualTo(MediaType.TEXT_PLAIN_TYPE.toString());
		assertThat(res.getHeaderString("hKey")).isNotNull()
				.isEqualTo("hValue");

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(landLinkDocumentService).getDocumentFileMetadata(reqCtxCaptor.capture(), eq(partyId), eq(landLinkId), any(), eq(documentId), eq(fileId));
	}

	@Test
	void test_add_doc_ok() {
		Long partyId = 555L;
		Long landLinkId = 100L;
		String definitionCode = "DEF_1";

		String uri = UriBuilder.fromResource(LandLinkDocumentResource.class)
				.build(TENANT, partyId, landLinkId).toString();
		System.out.println(uri);

		LandLinkDocumentRes mockRes = landLinkDocumentResBuilder(100L, landLinkId, definitionCode).build();
		given(landLinkDocumentService.insert(any(), anyLong(), anyLong(), any(), any())).willReturn(mockRes);
		InsertDocument doc = new InsertDocument();
		doc.setDefCode(definitionCode);
		doc.setBusinessId(landLinkId);

		LandLinkDocumentRes res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.post(Entity.json(doc), new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(landLinkDocumentService).insert(reqCtxCaptor.capture(), eq(partyId), eq(landLinkId), any(), eq(doc));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	@Test
	void test_update_doc_ok() {
		Long partyId = 555L;
		Long landLinkId = 100L;
		Long docId = 1L;
		String definitionCode = "DEF_1";

		String uri = UriBuilder.fromResource(LandLinkDocumentResource.class).path(LandLinkDocumentResource.class, "update")
				.build(TENANT, partyId, landLinkId, docId).toString();

		LandLinkDocumentRes mockRes = landLinkDocumentResBuilder(docId, landLinkId, definitionCode).build();
		given(landLinkDocumentService.update(any(), anyLong(), anyLong(), any(), anyLong(), any())).willReturn(mockRes);

		Document req = new Document();

		LandLinkDocumentRes res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.put(Entity.json(req), new GenericType<>() {
				});

		assertThat(res).isNotNull().isEqualTo(mockRes);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(landLinkDocumentService).update(reqCtxCaptor.capture(), eq(partyId), eq(landLinkId), any(), eq(docId), eq(req));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	@Test
	void test_delete_doc_ok() {
		Long partyId = 555L;
		Long landLinkId = 100L;
		Long docId = 1L;

		String uri = UriBuilder.fromResource(LandLinkDocumentResource.class).path(LandLinkDocumentResource.class, "delete")
				.build(TENANT, partyId, landLinkId, docId).toString();
		System.out.println(uri);

		Response res = EXT.getJerseyTest().target()
				.path(uri)
				.request()
				.header("Authorization", WebCliHelper.JWT_MOCK_CREDENTIALS)
				.delete(new GenericType<>() {
				});

		assertThat(res).isNotNull();
		assertThat(res.getStatus()).isEqualTo(200);

		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(landLinkDocumentService).expire(reqCtxCaptor.capture(), eq(partyId), eq(landLinkId), any(), eq(docId));
		ReqContext reqContext = reqCtxCaptor.getValue();
		System.out.println(reqContext);
		MatcherAssert.assertThat(reqContext.getTenantId(), is(TENANT));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(BASIC_USERNAME));
	}

	private LandLinkDocumentResBuilder<?, ?> landLinkDocumentResBuilder(Long docId, Long landLinkId, String defCode) {
		return LandLinkDocumentRes.builder()
				.setLandLinkId(landLinkId)
				.setDefinitionCode(defCode)
				.setDocumentId(docId);
	}

}
