package com.abacogroup.cllapi.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

import com.abacogroup.cllapi.JdbiTest;
import com.abacogroup.cllapi.api.CllSettings;
import com.abacogroup.cllapi.api.GroupRes;
import com.abacogroup.cllapi.api.LandLinkRes;
import com.abacogroup.cllapi.api.req.GroupCloneReq;
import com.abacogroup.cllapi.api.req.GroupCreateReq;
import com.abacogroup.cllapi.api.req.GroupDuplicatesReq;
import com.abacogroup.cllapi.api.req.GroupSearchReq;
import com.abacogroup.cllapi.api.req.GroupUpdateReq;
import com.abacogroup.cllapi.api.req.LandLinkBatchCreateReq;
import com.abacogroup.cllapi.api.req.LandLinkBatchCreateReq.LandLinkBatchCreateReqBuilder;
import com.abacogroup.cllapi.core.LandLinkService;
import com.abacogroup.cllapi.core.LpisClientService;
import com.abacogroup.cllapi.core.PartyClientService;
import com.abacogroup.cllapi.db.dao.CllSettingsDAO;
import com.abacogroup.cllapi.db.dao.GroupDAO;
import com.abacogroup.cllapi.db.ntt.CllSettingsEntity;
import com.abacogroup.cllapi.db.ntt.GroupEntity;
import com.abacogroup.cllapi.db.ntt.GroupEntityExtended;
import com.abacogroup.cllapi.db.ntt.LandLinkEntity;
import com.abacogroup.cllapi.exceptions.GroupException;
import com.abacogroup.cllapi.exceptions.GroupException.ErrEnum;
import com.abacogroup.cllapi.exceptions.LandLinkException;
import com.abacogroup.cllcli.api.v1.enums.ParcelSearchLevel;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lpisgisserver.api.v1.PublicParcel;
import com.abacogroup.lpisgisserver.api.v1.PublicParcelBlock;
import com.abacogroup.lpisgisserver.api.v1.PublicParcelSector;
import com.abacogroup.testcommon.ReqContextUtils;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import org.assertj.core.groups.Tuple;
import org.jdbi.v3.core.Handle;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class GroupServiceImplTest extends JdbiTest {

	private ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	private GroupServiceImpl groupService = this.getService(GroupServiceImpl.class);
	private LandLinkService landLinkService = this.getService(LandLinkServiceImpl.class);

	private PartyClientService partyClientServiceMock = Mockito.mock(PartyClientService.class);
	private LpisClientService lpisClientService = Mockito.mock(LpisClientService.class);

	private CllSettingsDAO settingsDAO = Mockito.mock(CllSettingsDAO.class);

	@BeforeEach
	void setUp() {
		given(settingsDAO.getOne(any())).willReturn(CllSettings.builder().setLpisSubSeparator("/").setAllowEditDayToParcelInThePast(true).build());
		injectMock(landLinkService, lpisClientService);
		injectMock(landLinkService, settingsDAO);

		injectMock(groupService, partyClientServiceMock);
		injectMock(groupService, landLinkService);
	}

	//---search groups-----
	@ParameterizedTest
	@MethodSource("com.abacogroup.cllapi.core.impl.GroupServiceImplTestSources#test_search")
	void test_search(String ignoredTitle, GroupSearchReq request, AbsoluteDate referenceDate, Tuple[] tuples) {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links", "add_more_groups_and_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			Long partyId = 555L;

			InfiniteListResults<GroupRes> res = groupService.search(ctx.getReqContext(), referenceDate, partyId, request, null);

			assertThat(res).isNotNull();
			assertThat(res.getRecords()).hasSize(tuples.length)
					.extracting(
							GroupRes::getId,
							GroupRes::getLinkCount,
							g -> g.getDayFrom().getValue(),
							g -> g.getDayTo().getValue()
					).containsExactlyInAnyOrder(tuples);

			handle.rollback();
		});
	}

	// ----- searchGroupLandLinks -----
	@Test
	void test_searchGroupLandLinks_ok() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -1L;
			long partyId = 555L;
			InfiniteListResults<LandLinkRes> results = groupService.searchGroupLandLinks(ctx.getReqContext(), partyId, groupId, null);

			assertThat(results).isNotNull();
			assertThat(results.getRecords()).hasSize(4)
					.extracting(
							LandLinkRes::getId,
							landLinkRes -> landLinkRes.getGroup().getId(),
							LandLinkRes::getPartyId,
							landLinkRes1 -> landLinkRes1.getTitleType().getId(),

							LandLinkRes::getDayFrom,
							LandLinkRes::getDayTo
					).containsExactlyInAnyOrder(
							Tuple.tuple(-101L, groupId, partyId, -100L, AbsoluteDate.of("20200202"), AbsoluteDate.of("20210531")),
							Tuple.tuple(-1011L, groupId, partyId, -100L, AbsoluteDate.of("20210601"), AbsoluteDate.of("99991231")),
							Tuple.tuple(-102L, groupId, partyId, -100L, AbsoluteDate.of("20200202"), AbsoluteDate.of("99991231")),
							Tuple.tuple(-103L, groupId, partyId, -100L, AbsoluteDate.of("20200202"), AbsoluteDate.of("20211202"))
					);

			handle.rollback();
		});
	}

	@Test
	void test_searchGroupLandLinks_notExistingGroupKo() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = 999L;
			long partyId = 555L;

			GroupException groupException = assertThrows(GroupException.class,
					() -> groupService.searchGroupLandLinks(ctx.getReqContext(), partyId, groupId, null));

			assertThat(groupException).isNotNull()
					.extracting(GroupException::getCode).isEqualTo(ErrEnum.NOT_FOUND.toString());

			handle.rollback();
		});
	}

	@Test
	void test_searchGroupLandLinks_emptyGroupEmptyResult() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -2L;
			long partyId = 555L;
			InfiniteListResults<LandLinkRes> results = groupService.searchGroupLandLinks(ctx.getReqContext(), partyId, groupId, null);

			assertThat(results).isNotNull();
			assertThat(results.getRecords()).isEmpty();

			handle.rollback();
		});
	}

	// ----- insert -----
	@Test
	void test_insert_ok() {
		LandLinkBatchCreateReq r1 = landLinkBatchCreateReqBuilder(100, 111111L).build();
		LandLinkBatchCreateReq r2 = landLinkBatchCreateReqBuilder(50, 222222L).build();
		LandLinkBatchCreateReq r3 = landLinkBatchCreateReqBuilder(33.123456789, 333333L).build();
		LandLinkBatchCreateReq r4 = landLinkBatchCreateReqBuilder(33.3333333333, 444444L).build();
		LandLinkBatchCreateReq r5 = landLinkBatchCreateReqBuilder(99.9999999999, 555555L).build();
		long partyId = 555L;

		given(lpisClientService.getParcelsByIdIn(any(), any(), any(), any())).willAnswer(a -> {
			return List.of(
					PublicParcel.builder().setId(111111L).setParcel("00042/A").setSector(PublicParcelSector.builder().setSectorCode("A001").build())
							.setBlock(PublicParcelBlock.builder().setBlockCode("1").build()).build(),
					PublicParcel.builder().setId(222222L).setParcel("00042/B").setSector(PublicParcelSector.builder().setSectorCode("B001").build())
							.setBlock(PublicParcelBlock.builder().setBlockCode("1").build()).build(),
					PublicParcel.builder().setId(333333L).setParcel("00042").setSector(PublicParcelSector.builder().setSectorCode("C001").build())
							.setBlock(PublicParcelBlock.builder().setBlockCode("1").build()).build(),
					PublicParcel.builder().setId(444444L).setParcel("00042/C").setSector(PublicParcelSector.builder().setSectorCode("C001").build())
							.setBlock(PublicParcelBlock.builder().setBlockCode("1").build()).build(),
					PublicParcel.builder().setId(555555L).setParcel("00042/VV").setSector(PublicParcelSector.builder().setSectorCode("C001").build())
							.setBlock(PublicParcelBlock.builder().setBlockCode("1").build()).build()
			);
		});

		given(partyClientServiceMock.getById(any(), any()))
				.willAnswer(a -> Optional.of(PartyClientServiceImpl.partyClientFallback(a.getArgument(1))));

		GroupCreateReq groupCreateReq = GroupCreateReq.builder()
				.setTitleTypeId(-100L)
				.setDescr("test group 1")
				.setDayFrom(AbsoluteDate.of("20200202"))
				.setDayTo(AbsoluteDate.of("99991231"))
				.setLandLinks(List.of(r1, r2, r3, r4, r5))
				.build();

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			givenCloseDayConfig(handle, false); // insert lpis separator
			List<String> initScripts = List.of("add_title_types");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			GroupRes newlyCreatedGroup = groupService.insert(ctx.getReqContext(), partyId, groupCreateReq);

			assertThat(newlyCreatedGroup).isNotNull()
					.extracting(
							GroupRes::getPartyId,
							groupRes -> groupRes.getTitleType().getId(),
							GroupRes::getDescr,
							GroupRes::getDayFrom,
							GroupRes::getDayTo,
							GroupRes::getLinkCount
					).containsExactly(
							partyId,
							groupCreateReq.getTitleTypeId(),
							groupCreateReq.getDescr(),
							groupCreateReq.getDayFrom(),
							groupCreateReq.getDayTo(),
							5L
					);
			assertThat(handle.attach(GroupDAO.class).findById(ctx.getTenantId(), newlyCreatedGroup.getId())).isPresent().get()
					.hasFieldOrPropertyWithValue("tenantId", ctx.getTenantId())
					.extracting(GroupEntity::getPkid).isEqualTo(newlyCreatedGroup.getId());
			Long groupId = newlyCreatedGroup.getId();
			assertThat(handle.select("   select * from cll_land_link_detail where group_id = ? ", groupId)
					.mapToBean(LandLinkEntity.class)
					.list()).hasSize(5)
					.extracting(
							LandLinkEntity::getGroupId,
							LandLinkEntity::getPartyId,
							LandLinkEntity::getTitleTypeId,

							landLinkEntity -> landLinkEntity.getTitleTypePerc().setScale(8, RoundingMode.HALF_UP),
							LandLinkEntity::getParcelId,
							LandLinkEntity::getSectorCode,
							LandLinkEntity::getBlockCode,
							LandLinkEntity::getParcelCode,
							LandLinkEntity::getSubParcelCode,

							LandLinkEntity::getDayFrom,
							LandLinkEntity::getDayTo
					).containsExactlyInAnyOrder(
							Tuple.tuple(groupId, partyId, groupCreateReq.getTitleTypeId(),
									r1.getTitleTypePerc().setScale(8, RoundingMode.HALF_UP), r1.getParcelId(), "A001", "1", "00042", "A",
									groupCreateReq.getDayFrom(), groupCreateReq.getDayTo()),
							Tuple.tuple(groupId, partyId, groupCreateReq.getTitleTypeId(),
									r2.getTitleTypePerc().setScale(8, RoundingMode.HALF_UP), r2.getParcelId(), "B001", "1", "00042", "B",
									groupCreateReq.getDayFrom(), groupCreateReq.getDayTo()),
							Tuple.tuple(groupId, partyId, groupCreateReq.getTitleTypeId(),
									r3.getTitleTypePerc().setScale(8, RoundingMode.HALF_UP), r3.getParcelId(), "C001", "1", "00042", null,
									groupCreateReq.getDayFrom(), groupCreateReq.getDayTo()),
							Tuple.tuple(groupId, partyId, groupCreateReq.getTitleTypeId(),
									r4.getTitleTypePerc().setScale(8, RoundingMode.HALF_UP), r4.getParcelId(), "C001", "1", "00042", "C",
									groupCreateReq.getDayFrom(), groupCreateReq.getDayTo()),
							Tuple.tuple(groupId, partyId, groupCreateReq.getTitleTypeId(),
									r5.getTitleTypePerc().setScale(8, RoundingMode.HALF_UP), r5.getParcelId(), "C001", "1", "00042", "VV",
									groupCreateReq.getDayFrom(), groupCreateReq.getDayTo())
					);

			handle.rollback();
		});
	}

	@MethodSource("com.abacogroup.cllapi.core.impl.GroupServiceImplTestSources#test_insert_datesK0")
	@ParameterizedTest
	void test_insert_datesK0(String testName, long titleTypeId, AbsoluteDate dayFrom, AbsoluteDate dayTo, LandLinkException.ErrEnum errCode) {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		long partyId = 555L;

		given(partyClientServiceMock.getById(any(), any()))
				.willAnswer(a -> Optional.of(PartyClientServiceImpl.partyClientFallback(a.getArgument(1))));

		LandLinkBatchCreateReq r1 = landLinkBatchCreateReqBuilder(100, 111111L).build();
		GroupCreateReq groupCreateReq = GroupCreateReq.builder()
				.setTitleTypeId(titleTypeId)
				.setDescr("test group " + testName)
				.setDayFrom(dayFrom)
				.setDayTo(dayTo)
				.setLandLinks(List.of(r1))
				.build();

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			LandLinkException landLinkException = assertThrows(LandLinkException.class,
					() -> groupService.insert(ctx.getReqContext(), partyId, groupCreateReq));

			assertThat(landLinkException).isNotNull()
					.extracting(LandLinkException::getCode).isEqualTo(errCode.toString());

			handle.rollback();
		});
	}

	@Test
	void test_insert_descrKo() {
		LandLinkBatchCreateReq r1 = landLinkBatchCreateReqBuilder(100, 111111L).build();
		LandLinkBatchCreateReq r2 = landLinkBatchCreateReqBuilder(50, 222222L).build();

		long partyId = 555L;

		given(partyClientServiceMock.getById(any(), any()))
				.willAnswer(a -> Optional.of(PartyClientServiceImpl.partyClientFallback(a.getArgument(1))));

		GroupCreateReq groupCreateReq = GroupCreateReq.builder()
				.setTitleTypeId(-100L)
				.setDescr("Group 1")
				.setDayFrom(AbsoluteDate.of("20200202"))
				.setDayTo(AbsoluteDate.of("99991231"))
				.setLandLinks(List.of(r1, r2))
				.build();

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			GroupException groupException = assertThrows(GroupException.class,
					() -> groupService.insert(ctx.getReqContext(), partyId, groupCreateReq));

			assertThat(groupException).isNotNull()
					.extracting(GroupException::getCode).isEqualTo(ErrEnum.DUPLICATE_DESCR.toString());

			handle.rollback();
		});
	}

	@Test
	void test_insert_duplicateInSameGroupKo() {
		LandLinkBatchCreateReq r1 = landLinkBatchCreateReqBuilder(100, 111111L).build();
		LandLinkBatchCreateReq r2 = landLinkBatchCreateReqBuilder(50, 222222L).build();
		LandLinkBatchCreateReq r3 = landLinkBatchCreateReqBuilder(33.123456789, 111111L).build();
		long partyId = 555L;

		given(lpisClientService.getParcelsByIdIn(any(), any(), any(), any())).willAnswer(a -> List.of(
				PublicParcel.builder().setId(111111L).setParcel("00042/A").setSector(PublicParcelSector.builder().setSectorCode("A001").build())
						.setBlock(PublicParcelBlock.builder().setBlockCode("1").build()).build(),
				PublicParcel.builder().setId(222222L).setParcel("00042/B").setSector(PublicParcelSector.builder().setSectorCode("B001").build())
						.setBlock(PublicParcelBlock.builder().setBlockCode("1").build()).build()
		));

		given(partyClientServiceMock.getById(any(), any()))
				.willAnswer(a -> Optional.of(PartyClientServiceImpl.partyClientFallback(a.getArgument(1))));

		GroupCreateReq groupCreateReq = GroupCreateReq.builder()
				.setTitleTypeId(-100L)
				.setDescr("test group 1")
				.setDayFrom(AbsoluteDate.of("20200202"))
				.setDayTo(AbsoluteDate.of("99991231"))
				.setLandLinks(List.of(r1, r2, r3))
				.build();

		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			givenCloseDayConfig(handle, false); // insert lpis separator
			List<String> initScripts = List.of("add_title_types");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			LandLinkException landLinkException = assertThrows(LandLinkException.class,
					() -> groupService.insert(ctx.getReqContext(), partyId, groupCreateReq));

			assertThat(landLinkException).isNotNull()
					.extracting(LandLinkException::getCode).isEqualTo(LandLinkException.ErrEnum.NO_AVAILABLE_DATE.toString());

			handle.rollback();
		});
	}

	// ----- clone -----
	@Test
	void test_clone_ok() {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 21, 12, 42);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links", "add_links_to_group_9");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -9L;
			long partyId = 555L;

			given(partyClientServiceMock.getById(any(), any()))
					.willAnswer(a -> Optional.of(PartyClientServiceImpl.partyClientFallback(a.getArgument(1))));

			GroupCloneReq groupReq = GroupCloneReq.builder()
					.setDescr("group 9 cloned")
					.setTitleTypeId(-102L)
					.setDayFrom(AbsoluteDate.of("20200202"))
					.setDayTo(AbsoluteDate.of("20300302"))
					.setTitleTypePerc(BigDecimal.valueOf(99.95))
					.build();

			GroupRes newlyCreatedGroup = groupService.clone(ctx.getReqContext(), partyId, groupId, groupReq);

			assertThat(newlyCreatedGroup).isNotNull()
					.extracting(
							GroupRes::getPartyId,
							groupRes -> groupRes.getTitleType().getId(),
							GroupRes::getDescr,
							GroupRes::getDayFrom,
							GroupRes::getDayTo,
							GroupRes::getLinkCount
					).containsExactly(
							partyId,
							groupReq.getTitleTypeId(),
							groupReq.getDescr(),
							groupReq.getDayFrom(),
							groupReq.getDayTo(),
							2L
					);
			assertThat(newlyCreatedGroup.getId()).isNotNull().isGreaterThan(groupId);
			Long newGroupId = newlyCreatedGroup.getId();
			assertThat(handle.select("   select * from cll_land_link_detail where group_id = ? ", newGroupId)
					.mapToBean(LandLinkEntity.class)
					.list()).hasSize(2)
					.extracting(
							LandLinkEntity::getGroupId,
							LandLinkEntity::getPartyId,
							LandLinkEntity::getTitleTypeId,

							landLinkEntity -> landLinkEntity.getTitleTypePerc().setScale(8, RoundingMode.HALF_UP),
							LandLinkEntity::getParcelId,
							LandLinkEntity::getSectorCode,
							LandLinkEntity::getBlockCode,
							LandLinkEntity::getParcelCode,
							LandLinkEntity::getSubParcelCode,

							LandLinkEntity::getDayFrom,
							LandLinkEntity::getDayTo
					).containsExactlyInAnyOrder(
							Tuple.tuple(newGroupId, partyId, groupReq.getTitleTypeId(),
									groupReq.getTitleTypePerc().setScale(8, RoundingMode.HALF_UP), 911L, "A009", "1", "00001", null,
									groupReq.getDayFrom(), groupReq.getDayTo()),
							Tuple.tuple(newGroupId, partyId, groupReq.getTitleTypeId(),
									groupReq.getTitleTypePerc().setScale(8, RoundingMode.HALF_UP), 922L, "A009", "1", "00001", null,
									groupReq.getDayFrom(), groupReq.getDayTo())
					);

			handle.rollback();
		});

	}

	@Test
	void test_clone_open_group_then_exception() {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 21, 12, 42);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -1L;
			long partyId = 555L;

			given(partyClientServiceMock.getById(any(), any()))
					.willAnswer(a -> Optional.of(PartyClientServiceImpl.partyClientFallback(a.getArgument(1))));

			// clone open group
			GroupCloneReq groupReq = GroupCloneReq.builder()
					.setTitleTypeId(-100L)
					.setDayFrom(AbsoluteDate.of("20200202"))
					.setDayTo(AbsoluteDate.of("20300302"))
					.setTitleTypePerc(BigDecimal.valueOf(100))
					.build();

			GroupException groupException = assertThrows(GroupException.class,
					() -> groupService.clone(ctx.getReqContext(), partyId, groupId, groupReq));

			assertThat(groupException).isNotNull()
					.extracting(GroupException::getCode).isEqualTo(ErrEnum.OPEN_GROUP.toString());

			handle.rollback();
		});
	}

	// ----- update -----
	@Test
	void test_update_dayToNotReqOK() {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -1L;
			long partyId = 555L;
			GroupDAO groupDAO = handle.attach(GroupDAO.class);
			GroupEntity actualGroup = groupDAO.findById(ctx.getTenantId(), groupId).orElseGet(Assertions::fail);

			GroupUpdateReq groupReq = GroupUpdateReq.builder()
					.setDescr("group 1 updated")
					.setDayFrom(AbsoluteDate.of("20011001"))
					.build();

			GroupRes group = groupService.update(ctx.getReqContext(), partyId, groupId, groupReq);

			AbsoluteDate infDate = AbsoluteDate.of("99991231");
			assertThat(group).isNotNull();
			assertThat(groupDAO.findExtendedByIdAndPartyId(ctx.getTenantId(), groupId, partyId)).isPresent().get()
					.hasFieldOrPropertyWithValue("descr", groupReq.getDescr())
					.hasFieldOrPropertyWithValue("dayFrom", groupReq.getDayFrom())
					.hasFieldOrPropertyWithValue("dayTo", infDate)
					.hasNoNullFieldsOrPropertiesExcept("userIdDelete")
					.usingRecursiveComparison()
					.comparingOnlyFields("partyId", "titleTypeId", "id", "tenantId")
					.isEqualTo(actualGroup);
			assertThat(handle.select("   select * from cll_land_link_detail where group_id = ? " +
							" and §current_timestamp§ between dt_insert and dt_delete ", groupId)
					.mapToBean(LandLinkEntity.class)
					.list()).hasSize(4)
					.extracting(
							LandLinkEntity::getId,
							LandLinkEntity::getGroupId,
							LandLinkEntity::getPartyId,
							LandLinkEntity::getTitleTypeId,

							LandLinkEntity::getDayFrom,
							LandLinkEntity::getDayTo
					).containsExactlyInAnyOrder(
							Tuple.tuple(-101L, groupId, group.getPartyId(), group.getTitleType().getId(), groupReq.getDayFrom(), AbsoluteDate.of("20210531")),
							Tuple.tuple(-1011L, groupId, group.getPartyId(), group.getTitleType().getId(), AbsoluteDate.of("20210601"), infDate),
							Tuple.tuple(-102L, groupId, group.getPartyId(), group.getTitleType().getId(), groupReq.getDayFrom(), infDate),
							Tuple.tuple(-103L, groupId, group.getPartyId(), group.getTitleType().getId(), groupReq.getDayFrom(), AbsoluteDate.of("20211202"))
					);

			handle.rollback();
		});
	}

	@Test
	void test_update_dayToReqOK() {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -2L;
			long partyId = 555L;
			GroupDAO groupDAO = handle.attach(GroupDAO.class);
			GroupEntity actualGroup = groupDAO.findById(ctx.getTenantId(), groupId).orElseGet(Assertions::fail);

			GroupUpdateReq groupReq = GroupUpdateReq.builder()
					.setDescr("group 2 updated")
					.setDayFrom(AbsoluteDate.of("20011001"))
					.setDayTo(AbsoluteDate.of("20250505"))
					.build();

			GroupRes group = groupService.update(ctx.getReqContext(), partyId, groupId, groupReq);

			assertThat(group).isNotNull();
			assertThat(groupDAO.findExtendedByIdAndPartyId(ctx.getTenantId(), groupId, partyId)).isPresent().get()
					.hasFieldOrPropertyWithValue("descr", groupReq.getDescr())
					.hasFieldOrPropertyWithValue("dayFrom", groupReq.getDayFrom())
					.hasFieldOrPropertyWithValue("dayTo", groupReq.getDayTo())
					.hasNoNullFieldsOrPropertiesExcept("userIdDelete")
					.usingRecursiveComparison()
					.comparingOnlyFields("partyId", "titleTypeId", "id", "tenantId")
					.isEqualTo(actualGroup);
			assertThat(handle.select("   select * from cll_land_link_detail where group_id = ? " +
							" and §current_timestamp§ between dt_insert and dt_delete ", groupId)
					.mapToBean(LandLinkEntity.class)
					.list()).hasSize(3)
					.extracting(
							LandLinkEntity::getId,
							LandLinkEntity::getGroupId,
							LandLinkEntity::getPartyId,
							LandLinkEntity::getTitleTypeId,

							LandLinkEntity::getDayFrom,
							LandLinkEntity::getDayTo
					).containsExactlyInAnyOrder(
							Tuple.tuple(-201L, groupId, group.getPartyId(), group.getTitleType().getId(),
									groupReq.getDayFrom(), groupReq.getDayTo()),
							Tuple.tuple(-202L, groupId, group.getPartyId(), group.getTitleType().getId(),
									groupReq.getDayFrom(), groupReq.getDayTo()),
							Tuple.tuple(-203L, groupId, group.getPartyId(), group.getTitleType().getId(),
									groupReq.getDayFrom(), AbsoluteDate.of("20211202"))
					);

			handle.rollback();
		});
	}

	@Test
	void test_update_dayToReqKO() {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -2L;
			long partyId = 555L;
			GroupDAO groupDAO = handle.attach(GroupDAO.class);
			GroupEntityExtended actualGroup = groupDAO.findExtendedByIdAndPartyId(ctx.getTenantId(), groupId, partyId).orElseGet(Assertions::fail);

			GroupUpdateReq groupReq = GroupUpdateReq.builder()
					.setDescr("group 2 updated")
					.setDayFrom(AbsoluteDate.of("20220101"))
					.setDayTo(AbsoluteDate.of("20231231"))
					.build();

			LandLinkException landLinkException = assertThrows(LandLinkException.class,
					() -> groupService.update(ctx.getReqContext(), partyId, groupId, groupReq));

			assertThat(landLinkException).isNotNull()
					.extracting(LandLinkException::getCode).isEqualTo(LandLinkException.ErrEnum.INVALID_DAY_FROM.toString());

			handle.rollback();
		});
	}

	@Test
	void test_update_descrKO() {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -2L;
			long partyId = 555L;
			GroupDAO groupDAO = handle.attach(GroupDAO.class);
			GroupEntityExtended actualGroup = groupDAO.findExtendedByIdAndPartyId(ctx.getTenantId(), groupId, partyId).orElseGet(Assertions::fail);

			GroupUpdateReq groupReq = GroupUpdateReq.builder()
					.setDescr("group 1")
					.setDayFrom(actualGroup.getDayFrom())
					.setDayTo(actualGroup.getDayTo())
					.build();

			GroupException groupException = assertThrows(GroupException.class,
					() -> groupService.update(ctx.getReqContext(), partyId, groupId, groupReq));

			assertThat(groupException).isNotNull()
					.extracting(GroupException::getCode).isEqualTo(ErrEnum.DUPLICATE_DESCR.toString());

			handle.rollback();
		});
	}

	@Test
	void test_update_closedKO() {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -9L;
			long partyId = 555L;
			GroupDAO groupDAO = handle.attach(GroupDAO.class);
			GroupEntityExtended actualGroup = groupDAO.findExtendedByIdAndPartyId(ctx.getTenantId(), groupId, partyId).orElseGet(Assertions::fail);

			GroupUpdateReq groupReq = GroupUpdateReq.builder()
					.setDescr("group 9")
					.setDayFrom(actualGroup.getDayFrom())
					.setDayTo(actualGroup.getDayTo())
					.build();

			GroupException groupException = assertThrows(GroupException.class,
					() -> groupService.update(ctx.getReqContext(), partyId, groupId, groupReq));

			assertThat(groupException).isNotNull()
					.extracting(GroupException::getCode).isEqualTo(ErrEnum.CLOSED_GROUP.toString());

			handle.rollback();
		});
	}

	// ----- addLandLinks -----
	@Test
	void test_addLandLinks_ok() {
		LandLinkBatchCreateReq r1 = landLinkBatchCreateReqBuilder(100, 111111L).build();
		LandLinkBatchCreateReq r2 = landLinkBatchCreateReqBuilder(50, 222222L).build();

		given(lpisClientService.getParcelsByIdIn(any(), any(), any(), any())).willAnswer(a -> List.of(
				PublicParcel.builder().setId(111111L).setParcel("00042/A").setSector(PublicParcelSector.builder().setSectorCode("A001").build())
						.setBlock(PublicParcelBlock.builder().setBlockCode("1").build()).build(),
				PublicParcel.builder().setId(222222L).setParcel("00042/B").setSector(PublicParcelSector.builder().setSectorCode("B001").build())
						.setBlock(PublicParcelBlock.builder().setBlockCode("1").build()).build()
		));

		getJdbi().useHandle(handle -> {
			handle.begin();

			givenCloseDayConfig(handle, false); // insert lpis separator
			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -1L;
			long partyId = 555L;
			GroupDAO groupDAO = handle.attach(GroupDAO.class);
			GroupEntityExtended actualGroup = groupDAO.findExtendedByIdAndPartyId(ctx.getTenantId(), groupId, partyId).orElseGet(Assertions::fail);

			GroupRes group = groupService.addLandLinks(ctx.getReqContext(), partyId, groupId, List.of(r1, r2));

			AbsoluteDate infDate = AbsoluteDate.of("99991231");
			assertThat(group).isNotNull()
					.extracting(
							GroupRes::getId,
							GroupRes::getPartyId,
							GroupRes::getDayFrom,
							GroupRes::getDayTo,
							GroupRes::getLinkCount
					).containsExactly(
							actualGroup.getId(),
							actualGroup.getPartyId(),
							actualGroup.getDayFrom(),
							actualGroup.getDayTo(),
							6L
					);
			assertThat(handle.select("   select * from cll_land_link_detail where group_id = ? " +
							" and §current_timestamp§ between dt_insert and dt_delete ", groupId)
					.mapToBean(LandLinkEntity.class)
					.list()).hasSize(6)
					.extracting(
							LandLinkEntity::getGroupId,
							LandLinkEntity::getPartyId,
							LandLinkEntity::getTitleTypeId,

							landLinkEntity -> landLinkEntity.getTitleTypePerc().setScale(8, RoundingMode.HALF_UP),
							LandLinkEntity::getParcelId,
							LandLinkEntity::getSectorCode,
							LandLinkEntity::getBlockCode,

							LandLinkEntity::getDayFrom,
							LandLinkEntity::getDayTo
					).containsExactlyInAnyOrder(
							Tuple.tuple(groupId, actualGroup.getPartyId(), actualGroup.getTitleTypeId(),
									r1.getTitleTypePerc().setScale(8, RoundingMode.HALF_UP), r1.getParcelId(), "A001", "1",
									actualGroup.getDayFrom(), actualGroup.getDayTo()),
							Tuple.tuple(groupId, actualGroup.getPartyId(), actualGroup.getTitleTypeId(),
									r2.getTitleTypePerc().setScale(8, RoundingMode.HALF_UP), r2.getParcelId(), "B001", "1",
									actualGroup.getDayFrom(), actualGroup.getDayTo()),

							Tuple.tuple(groupId, actualGroup.getPartyId(), actualGroup.getTitleTypeId(),
									BigDecimal.valueOf(100).setScale(8, RoundingMode.HALF_UP), 123101L, "sc101", "bc101",
									actualGroup.getDayFrom(), AbsoluteDate.of("20210531")),
							Tuple.tuple(groupId, actualGroup.getPartyId(), actualGroup.getTitleTypeId(),
									BigDecimal.valueOf(80).setScale(8, RoundingMode.HALF_UP), 123101L, "sc101", "bc101",
									AbsoluteDate.of("20210601"), actualGroup.getDayTo()),
							Tuple.tuple(groupId, actualGroup.getPartyId(), actualGroup.getTitleTypeId(),
									BigDecimal.valueOf(50).setScale(8, RoundingMode.HALF_UP), 123102L, "sc102", "bc102",
									actualGroup.getDayFrom(), actualGroup.getDayTo()),
							Tuple.tuple(groupId, actualGroup.getPartyId(), actualGroup.getTitleTypeId(),
									BigDecimal.valueOf(100).setScale(8, RoundingMode.HALF_UP), 123103L, "sc103", "bc103",
									actualGroup.getDayFrom(), AbsoluteDate.of("20211202"))
					);

			handle.rollback();
		});
	}

	@Test
	void test_addLandLinks_sameParcelOkDatesAfterClosed() {
		LandLinkBatchCreateReq r1 = landLinkBatchCreateReqBuilder(70, 123103L).build();
		LandLinkBatchCreateReq r2 = landLinkBatchCreateReqBuilder(50, 222222L).build();

		given(lpisClientService.getParcelsByIdIn(any(), any(), any(), any())).willAnswer(a -> List.of(
				PublicParcel.builder().setId(123103L).setParcel("00103").setSector(PublicParcelSector.builder().setSectorCode("sc103").build())
						.setBlock(PublicParcelBlock.builder().setBlockCode("bc103").build()).build(),
				PublicParcel.builder().setId(222222L).setParcel("00042/B").setSector(PublicParcelSector.builder().setSectorCode("B001").build())
						.setBlock(PublicParcelBlock.builder().setBlockCode("1").build()).build()
		));

		getJdbi().useHandle(handle -> {
			handle.begin();

			givenCloseDayConfig(handle, false); // insert lpis separator
			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -1L;
			long partyId = 555L;
			GroupDAO groupDAO = handle.attach(GroupDAO.class);
			GroupEntityExtended actualGroup = groupDAO.findExtendedByIdAndPartyId(ctx.getTenantId(), groupId, partyId).orElseGet(Assertions::fail);

			GroupRes group = groupService.addLandLinks(ctx.getReqContext(), partyId, groupId, List.of(r1, r2));

			AbsoluteDate infDate = AbsoluteDate.of("99991231");
			assertThat(group).isNotNull()
					.extracting(
							GroupRes::getId,
							GroupRes::getPartyId,
							GroupRes::getDayFrom,
							GroupRes::getDayTo,
							GroupRes::getLinkCount
					).containsExactly(
							actualGroup.getId(),
							actualGroup.getPartyId(),
							actualGroup.getDayFrom(),
							actualGroup.getDayTo(),
							6L
					);
			assertThat(handle.select("   select * from cll_land_link_detail where group_id = ? " +
							" and §current_timestamp§ between dt_insert and dt_delete ", groupId)
					.mapToBean(LandLinkEntity.class)
					.list()).hasSize(6)
					.extracting(
							LandLinkEntity::getGroupId,
							LandLinkEntity::getPartyId,
							LandLinkEntity::getTitleTypeId,

							landLinkEntity -> landLinkEntity.getTitleTypePerc().setScale(8, RoundingMode.HALF_UP),
							LandLinkEntity::getParcelId,
							LandLinkEntity::getSectorCode,
							LandLinkEntity::getBlockCode,

							LandLinkEntity::getDayFrom,
							LandLinkEntity::getDayTo
					).containsExactlyInAnyOrder(
							Tuple.tuple(groupId, actualGroup.getPartyId(), actualGroup.getTitleTypeId(),
									r2.getTitleTypePerc().setScale(8, RoundingMode.HALF_UP), r2.getParcelId(), "B001", "1",
									actualGroup.getDayFrom(), actualGroup.getDayTo()),

							Tuple.tuple(groupId, actualGroup.getPartyId(), actualGroup.getTitleTypeId(),
									BigDecimal.valueOf(100).setScale(8, RoundingMode.HALF_UP), 123101L, "sc101", "bc101",
									actualGroup.getDayFrom(), AbsoluteDate.of("20210531")),
							Tuple.tuple(groupId, actualGroup.getPartyId(), actualGroup.getTitleTypeId(),
									BigDecimal.valueOf(80).setScale(8, RoundingMode.HALF_UP), 123101L, "sc101", "bc101",
									AbsoluteDate.of("20210601"), actualGroup.getDayTo()),
							Tuple.tuple(groupId, actualGroup.getPartyId(), actualGroup.getTitleTypeId(),
									BigDecimal.valueOf(50).setScale(8, RoundingMode.HALF_UP), 123102L, "sc102", "bc102",
									actualGroup.getDayFrom(), actualGroup.getDayTo()),
							Tuple.tuple(groupId, actualGroup.getPartyId(), actualGroup.getTitleTypeId(),
									BigDecimal.valueOf(100).setScale(8, RoundingMode.HALF_UP), 123103L, "sc103", "bc103",
									actualGroup.getDayFrom(), AbsoluteDate.of("20211202")),
							Tuple.tuple(groupId, actualGroup.getPartyId(), actualGroup.getTitleTypeId(),
									BigDecimal.valueOf(70).setScale(8, RoundingMode.HALF_UP), 123103L, "sc103", "bc103",
									AbsoluteDate.of("20211203"), actualGroup.getDayTo())
					);

			handle.rollback();
		});
	}

	@Test
	void test_addLandLinks_sameParcelTwiceKo() {
		LandLinkBatchCreateReq r1 = landLinkBatchCreateReqBuilder(70, 123103L).build();
		LandLinkBatchCreateReq r2 = landLinkBatchCreateReqBuilder(50, 222222L).build();
		LandLinkBatchCreateReq r3 = landLinkBatchCreateReqBuilder(95, 123103L).build();

		given(lpisClientService.getParcelsByIdIn(any(), any(), any(), any())).willAnswer(a -> List.of(
				PublicParcel.builder().setId(123103L).setParcel("00103").setSector(PublicParcelSector.builder().setSectorCode("sc103").build())
						.setBlock(PublicParcelBlock.builder().setBlockCode("bc103").build()).build(),
				PublicParcel.builder().setId(222222L).setParcel("00042/B").setSector(PublicParcelSector.builder().setSectorCode("B001").build())
						.setBlock(PublicParcelBlock.builder().setBlockCode("1").build()).build()
		));

		getJdbi().useHandle(handle -> {
			handle.begin();

			givenCloseDayConfig(handle, false); // insert lpis separator
			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -1L;
			long partyId = 555L;
			GroupDAO groupDAO = handle.attach(GroupDAO.class);
			GroupEntityExtended actualGroup = groupDAO.findExtendedByIdAndPartyId(ctx.getTenantId(), groupId, partyId).orElseGet(Assertions::fail);

			LandLinkException landLinkException = assertThrows(LandLinkException.class,
					() -> groupService.addLandLinks(ctx.getReqContext(), partyId, groupId, List.of(r1, r2, r3)));

			assertThat(landLinkException).isNotNull()
					.extracting(LandLinkException::getCode).isEqualTo(LandLinkException.ErrEnum.NO_AVAILABLE_DATE.toString());

			handle.rollback();
		});
	}

	@Test
	void test_addLandLinks_closedKO() {
		LandLinkBatchCreateReq r1 = landLinkBatchCreateReqBuilder(100, 111111L).build();
		LandLinkBatchCreateReq r2 = landLinkBatchCreateReqBuilder(50, 222222L).build();

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -9L;
			long partyId = 555L;

			GroupException groupException = assertThrows(GroupException.class,
					() -> groupService.addLandLinks(ctx.getReqContext(), partyId, groupId, List.of(r1, r2)));

			assertThat(groupException).isNotNull()
					.extracting(GroupException::getCode).isEqualTo(ErrEnum.CLOSED_GROUP.toString());

			handle.rollback();
		});
	}

	// ----- close -----
	@Test
	void test_close_ok() {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		getJdbi().useHandle(handle -> {
			handle.begin();

			givenCloseDayConfig(handle, false);
			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -1L;
			long partyId = 555L;
			GroupDAO groupDAO = handle.attach(GroupDAO.class);
			GroupEntityExtended actualGroup = groupDAO.findExtendedByIdAndPartyId(ctx.getTenantId(), groupId, partyId).orElseGet(Assertions::fail);

			AbsoluteDate closeDate = AbsoluteDate.of("20221231");
			GroupRes group = groupService.close(ctx.getReqContext(), partyId, groupId, closeDate);

			assertThat(group).isNotNull();
			assertThat(groupDAO.findExtendedByIdAndPartyId(ctx.getTenantId(), groupId, partyId)).isPresent().get()
					.hasFieldOrPropertyWithValue("dayFrom", actualGroup.getDayFrom())
					.hasFieldOrPropertyWithValue("dayTo", closeDate);
			assertThat(handle.select("   select * from cll_land_link_detail where group_id = ? " +
							" and §current_timestamp§ between dt_insert and dt_delete ", groupId)
					.mapToBean(LandLinkEntity.class)
					.list()).hasSize(4)
					.extracting(
							LandLinkEntity::getId,
							LandLinkEntity::getGroupId,
							LandLinkEntity::getDayFrom,
							LandLinkEntity::getDayTo
					).containsExactlyInAnyOrder(
							Tuple.tuple(-101L, groupId, actualGroup.getDayFrom(), AbsoluteDate.of("20210531")),
							Tuple.tuple(-1011L, groupId, AbsoluteDate.of("20210601"), closeDate),
							Tuple.tuple(-102L, groupId, actualGroup.getDayFrom(), closeDate),
							Tuple.tuple(-103L, groupId, actualGroup.getDayFrom(), AbsoluteDate.of("20211202"))
					);

			handle.rollback();
		});
	}

	@Test
	void test_close_afterCloseDateKO() {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		getJdbi().useHandle(handle -> {
			handle.begin();

			givenCloseDayConfig(handle, true);
			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -2L;
			long partyId = 555L;
			GroupDAO groupDAO = handle.attach(GroupDAO.class);
			GroupEntityExtended actualGroup = groupDAO.findExtendedByIdAndPartyId(ctx.getTenantId(), groupId, partyId).orElseGet(Assertions::fail);

			AbsoluteDate closeDate = AbsoluteDate.of("20301231");
			GroupException exception = assertThrows(GroupException.class,
					() -> groupService.close(ctx.getReqContext(), partyId, groupId, closeDate));

			assertThat(exception).isNotNull()
					.extracting(GroupException::getCode).isEqualTo(ErrEnum.INVALID_DAY_TO.toString());
			System.out.println(exception.getErrorBody().getMessage());

			handle.rollback();
		});
	}

	@Test
	void test_close_beforeFromDayKO() {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		getJdbi().useHandle(handle -> {
			handle.begin();

			givenCloseDayConfig(handle, true);
			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -2L;
			long partyId = 555L;
			GroupDAO groupDAO = handle.attach(GroupDAO.class);
			GroupEntityExtended actualGroup = groupDAO.findExtendedByIdAndPartyId(ctx.getTenantId(), groupId, partyId).orElseGet(Assertions::fail);

			AbsoluteDate closeDate = AbsoluteDate.of("20001231");
			GroupException exception = assertThrows(GroupException.class,
					() -> groupService.close(ctx.getReqContext(), partyId, groupId, closeDate));

			assertThat(exception).isNotNull()
					.extracting(GroupException::getCode).isEqualTo(ErrEnum.INVALID_DAY_TO.toString());
			System.out.println(exception.getErrorBody().getMessage());

			handle.rollback();
		});
	}

	@Test
	void test_close_closedOkByConfig() {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		getJdbi().useHandle(handle -> {
			handle.begin();

			givenCloseDayConfig(handle, true);
			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -9L;
			long partyId = 555L;

			GroupDAO groupDAO = handle.attach(GroupDAO.class);
			GroupEntityExtended actualGroup = groupDAO.findExtendedByIdAndPartyId(ctx.getTenantId(), groupId, partyId).orElseGet(Assertions::fail);

			AbsoluteDate closeDate = AbsoluteDate.of("20150101");
			GroupRes group = groupService.close(ctx.getReqContext(), partyId, groupId, closeDate);

			assertThat(group).isNotNull();
			assertThat(groupDAO.findExtendedByIdAndPartyId(ctx.getTenantId(), groupId, partyId)).isPresent().get()
					.hasFieldOrPropertyWithValue("dayFrom", actualGroup.getDayFrom())
					.hasFieldOrPropertyWithValue("dayTo", closeDate);
			assertThat(handle.select("   select * from cll_land_link_detail where group_id = ? " +
							" and §current_timestamp§ between dt_insert and dt_delete ", groupId)
					.mapToBean(LandLinkEntity.class)
					.list()).hasSize(1)
					.extracting(
							LandLinkEntity::getId,
							LandLinkEntity::getGroupId,
							LandLinkEntity::getDayFrom,
							LandLinkEntity::getDayTo
					).containsExactlyInAnyOrder(
							Tuple.tuple(-901L, groupId, actualGroup.getDayFrom(), closeDate)
					);

			handle.rollback();
		});
	}

	@Test
	void test_close_closedKoByConfig() {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		getJdbi().useHandle(handle -> {
			handle.begin();

			givenCloseDayConfig(handle, false);
			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -9L;
			long partyId = 555L;

			AbsoluteDate closeDate = AbsoluteDate.of("20150101");
			GroupException groupException = assertThrows(GroupException.class,
					() -> groupService.close(ctx.getReqContext(), partyId, groupId, closeDate));

			assertThat(groupException).isNotNull()
					.extracting(GroupException::getCode).isEqualTo(ErrEnum.CLOSED_GROUP.toString());

			handle.rollback();
		});
	}

	@Test
	void test_close_beforeDuplicateStartKO() {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		getJdbi().useHandle(handle -> {
			handle.begin();

			givenCloseDayConfig(handle, false);
			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			long groupId = -1L;
			long partyId = 555L;

			AbsoluteDate closeDate = AbsoluteDate.of("20210101");
			LandLinkException landLinkException = assertThrows(LandLinkException.class,
					() -> groupService.close(ctx.getReqContext(), partyId, groupId, closeDate));

			assertThat(landLinkException).isNotNull()
					.extracting(LandLinkException::getCode).isEqualTo(LandLinkException.ErrEnum.INVALID_DAY_TO.toString());

			handle.rollback();
		});
	}


	// ----- closeMany -----
	@Test
	void test_closeMany_ok() {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		getJdbi().useHandle(handle -> {
			handle.begin();

			givenCloseDayConfig(handle, false);
			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			List<Long> groupIds = List.of(-1L, -2L);
			long partyId = 555L;

			AbsoluteDate closeDate = AbsoluteDate.of("20221231");
			groupService.closeMany(ctx.getReqContext(), partyId, groupIds, closeDate);

			assertThat(handle.select("   select * from cll_land_link_detail where group_id in (?, ?) " +
							" and §current_timestamp§ between dt_insert and dt_delete ", groupIds.toArray())
					.mapToBean(LandLinkEntity.class)
					.list()).hasSize(7)
					.extracting(
							LandLinkEntity::getId,
							LandLinkEntity::getGroupId,
							LandLinkEntity::getDayTo
					).containsExactlyInAnyOrder(
							Tuple.tuple(-101L, -1L, AbsoluteDate.of("20210531")),
							Tuple.tuple(-1011L, -1L, closeDate),
							Tuple.tuple(-102L, -1L, closeDate),
							Tuple.tuple(-103L, -1L, AbsoluteDate.of("20211202")),
							Tuple.tuple(-201L, -2L, closeDate),
							Tuple.tuple(-202L, -2L, closeDate),
							Tuple.tuple(-203L, -2L, AbsoluteDate.of("20211202"))
					);

			handle.rollback();
		});
	}

	@Test
	void test_closeMany_closedKoByConfig() {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		getJdbi().useHandle(handle -> {
			handle.begin();

			givenCloseDayConfig(handle, false);
			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			List<Long> groupIds = List.of(-9L);
			long partyId = 555L;

			AbsoluteDate closeDate = AbsoluteDate.of("20150101");
			GroupException groupException = assertThrows(GroupException.class,
					() -> groupService.closeMany(ctx.getReqContext(), partyId, groupIds, closeDate));

			assertThat(groupException).isNotNull()
					.extracting(GroupException::getCode).isEqualTo(ErrEnum.CLOSED_GROUP.toString());

			handle.rollback();
		});
	}

	@Test
	void test_closeMany_beforeDayFromKO() {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		getJdbi().useHandle(handle -> {
			handle.begin();

			givenCloseDayConfig(handle, true);
			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			List<Long> groupIds = List.of(-9L, -1L);
			long partyId = 555L;

			AbsoluteDate closeDate = AbsoluteDate.of("20150101");
			GroupException groupException = assertThrows(GroupException.class,
					() -> groupService.closeMany(ctx.getReqContext(), partyId, groupIds, closeDate));

			assertThat(groupException).isNotNull()
					.extracting(GroupException::getCode).isEqualTo(ErrEnum.INVALID_DAY_TO.toString());
			System.out.println(groupException.getErrorBody().getMessage());

			handle.rollback();
		});
	}

	@Test
	void test_closeMany_afterCloseDateKO() {
		Clock clock = mock(Clock.class);
		injectMock(groupService, clock);
		LocalDateTime now = LocalDateTime.of(2023, Month.MARCH, 6, 10, 51);
		given(clock.instant()).willReturn(Instant.from(now.atZone(ZoneId.of("UTC"))));
		given(clock.getZone()).willReturn(ZoneId.of("UTC"));

		getJdbi().useHandle(handle -> {
			handle.begin();

			givenCloseDayConfig(handle, true);
			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			List<Long> groupIds = List.of(-2L, -1L);
			long partyId = 555L;

			AbsoluteDate closeDate = AbsoluteDate.of("20300101");
			GroupException groupException = assertThrows(GroupException.class,
					() -> groupService.closeMany(ctx.getReqContext(), partyId, groupIds, closeDate));

			assertThat(groupException).isNotNull()
					.extracting(GroupException::getCode).isEqualTo(ErrEnum.INVALID_DAY_TO.toString());
			System.out.println(groupException.getErrorBody().getMessage());

			handle.rollback();
		});
	}

	// ----- expire -----
	@Test
	void test_expire_ok() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());
			GroupDAO groupDAO = handle.attach(GroupDAO.class);
			assertThat(groupDAO.findById(ctx.getTenantId(), -2L)).isPresent();

			groupService.expire(ctx.getReqContext(), 555L, -2L);

			assertThat(groupDAO.findById(ctx.getTenantId(), -2L)).isNotPresent();

			handle.rollback();
		});

	}

	@Test
	void test_get_Duplicated() {
		setUnusedBindingAllowed(true);
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());

			Long partyId = 555L;
			Long groupId = -1L;
			String descr = "group 1";
			GroupDuplicatesReq req = new GroupDuplicatesReq().setDescr(descr).setGroupId(groupId);

			assertThat(groupService.getDuplicates(ctx.getReqContext(), partyId, req.getDescr())).hasSize(1);

			// exclude groupId (-1L)
			assertThat(groupService.getDuplicates(ctx.getReqContext(), partyId, req.getDescr()).stream()
					.filter(g -> !g.getId().equals(req.getGroupId()))
					.count()).isEqualTo(0);

			descr = "new group";
			assertThat(groupService.getDuplicates(ctx.getReqContext(), partyId, descr)).hasSize(0);

			handle.rollback();
		});
	}

	// ----- deleteLandLinkByGroupIdAndParcelId -----
	@Test
	void test_deleteLandLinkByGroupIdAndParcelId_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());
			GroupDAO groupDAO = handle.attach(GroupDAO.class);
			assertThat(groupDAO.findExtendedById(ctx.getTenantId(), -1L)).isPresent().get()
					.extracting(GroupEntityExtended::getLinkCount)
					.isEqualTo(4L);

			groupService.deleteLandLinkByGroupIdAndParcelId(ctx.getReqContext(), 555L, -1L, 123101L);

			assertThat(groupDAO.findExtendedById(ctx.getTenantId(), -1L)).isPresent().get()
					.extracting(GroupEntityExtended::getLinkCount)
					.isEqualTo(2L);

			handle.rollback();
		});
	}

	@Test
	void test_deleteLandLinkByGroupIdAndParcelId_lastThenDeleteGroupOk() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			List<String> initScripts = List.of("add_title_types", "add_groups", "add_links");
			execSqlFiles(this.getClass(), initScripts, ctx.getTestScriptParams());
			GroupDAO groupDAO = handle.attach(GroupDAO.class);
			assertThat(groupDAO.findExtendedById(ctx.getTenantId(), -9L)).isPresent().get()
					.extracting(GroupEntityExtended::getLinkCount)
					.isEqualTo(1L);

			groupService.deleteLandLinkByGroupIdAndParcelId(ctx.getReqContext(), 555L, -9L, 911L);

			assertThat(groupDAO.findExtendedById(ctx.getTenantId(), -9L)).isEmpty();

			handle.rollback();
		});
	}

	// ###################################################################################################################################################### //

	private void givenCloseDayConfig(Handle handle, boolean allowEditDayToParcelInThePast) {
		handle.attach(CllSettingsDAO.class).insert(CllSettingsEntity.builder()
				.setLpisSubSeparator("/")
				.setAllowEditDayToParcelInThePast(allowEditDayToParcelInThePast ? 1 : 0)
				.setParcelSearchLevel(ParcelSearchLevel.SEARCH_ONLY_VALID)
				.setTenantId(ctx.getTenantId())
				.setDtInsert(LocalDateTime.ofEpochSecond(0,0, ZoneOffset.UTC))
				.setDtDelete(AuditEntity.dateActive)
				.setUserIdInsert(ctx.getUserId())
				.build());
	}


	private static LandLinkBatchCreateReqBuilder<?, ?> landLinkBatchCreateReqBuilder() {
		return landLinkBatchCreateReqBuilder(100, 123456L);
	}

	private static LandLinkBatchCreateReqBuilder<?, ?> landLinkBatchCreateReqBuilder(double perc, long parcelId) {
		return LandLinkBatchCreateReq.builder()
				.setTitleTypePerc(BigDecimal.valueOf(perc))
				.setParcelId(parcelId);
	}

}
