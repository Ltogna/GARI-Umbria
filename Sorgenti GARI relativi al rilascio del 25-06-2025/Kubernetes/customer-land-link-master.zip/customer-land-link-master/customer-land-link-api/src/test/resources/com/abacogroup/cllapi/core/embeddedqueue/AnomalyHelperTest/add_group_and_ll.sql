
--g1
insert into cll_group (id, tenant_id, party_id, title_type_id)
values (-1, :test_tenant, :party_id, :title_type);

insert into cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, -100, 'group 1', to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

--- ll  g1
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1011, -1011, -1, :test_tenant, :party_id, :title_type, 90,
        697674, 'A061', '1', '00349', '20220101', '20221231',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

--- ll  g1
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1012, -1012, -1, :test_tenant, :party_id, :title_type, 40,
        697673, 'A061', '1', '00349', '20240101', '99991231',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);
