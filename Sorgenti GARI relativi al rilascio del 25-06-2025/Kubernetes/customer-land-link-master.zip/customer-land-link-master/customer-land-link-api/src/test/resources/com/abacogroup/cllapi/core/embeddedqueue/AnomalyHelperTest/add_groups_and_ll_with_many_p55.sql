---------- see testP55.xsls ----------
--g10
insert into cll_group (id, tenant_id, party_id, title_type_id)
values (-10, :test_tenant, :party_id, :title_type);
insert into cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-10, -10, 'group 10', to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1001, -1001, -10, :test_tenant, :party_id, :title_type, 60,
        1111, 'A061', '1', '01111', '20220101', '20220430',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1002, -1002, -10, :test_tenant, :party_id, :title_type, 100,
        2222, 'A061', '1', '02222', '20220101', '99991231',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1003, -1003, -10, :test_tenant, :party_id, :title_type, 100,
        3333, 'A061', '1', '02222', '20220101', '99991231',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('2020-02-02', 'YYYY-MM-DD'), null);

--g11
insert into cll_group (id, tenant_id, party_id, title_type_id)
values (-11, :test_tenant, :party_id, :title_type);
insert into cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-11, -11, 'group 11', to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1101, -1101, -11, :test_tenant, :party_id, :title_type, 60,
        1111, 'A061', '1', '01111', '20220301', '20220731',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1103, -1103, -11, :test_tenant, :party_id, :title_type, 1,
        3333, 'A061', '1', '02222', '20220101', '20220131',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('2020-02-02', 'YYYY-MM-DD'), null);

--g12
insert into cll_group (id, tenant_id, party_id, title_type_id)
values (-12, :test_tenant, 999, :title_type);
insert into cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-12, -12, 'group 12', to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1201, -1201, -12, :test_tenant, 999, :title_type, 40,
        1111, 'A061', '1', '01111', '20220401', '20220731',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1202, -1202, -12, :test_tenant, 999, :title_type, 60,
        3333, 'A061', '1', '01111', '20220401', '20220731',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('2020-02-02', 'YYYY-MM-DD'), null);

--g13
insert into cll_group (id, tenant_id, party_id, title_type_id)
values (-13, :test_tenant, :party_id, :title_type);
insert into cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-13, -13, 'group 13', to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1301, -1301, -13, :test_tenant, :party_id, :title_type, 40,
        1111, 'A061', '1', '01111', '20220601', '20220630',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1302, -1302, -13, :test_tenant, :party_id, :title_type, 60,
        1111, 'A061', '1', '01111', '20220701', '20220831',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);



----------------------------------------------------------------
insert into cll_anomalies (id, tenant_id, type_group_code, type_code, entity_code, entity_id, valid_from, valid_to,
                           dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, :test_tenant, 'customer-land-link.land-link', 'P55', 'REFERENCE_PARCEL', '3333', '20220401', '20220731',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_anomalies (id, tenant_id, type_group_code, type_code, entity_code, entity_id, valid_from, valid_to,
                           dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2, :test_tenant, 'customer-land-link.land-link', 'P55', 'REFERENCE_PARCEL', '3333', '20220101', '20220131',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_anomalies (id, tenant_id, type_group_code, type_code, entity_code, entity_id, valid_from, valid_to,
                           dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-3, :test_tenant, 'customer-land-link.land-link', 'P55.6', 'REFERENCE_PARTY_PARCEL', :party_id || '-3333', '20220101', '20220131',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);
