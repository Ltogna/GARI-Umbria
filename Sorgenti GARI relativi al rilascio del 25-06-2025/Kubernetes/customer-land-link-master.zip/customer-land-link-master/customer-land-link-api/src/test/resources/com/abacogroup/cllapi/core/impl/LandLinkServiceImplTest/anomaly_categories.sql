insert into cll_anomaly_categories (tenant_id, group_code, code, "level", fl_exclude)
values (:test_tenant, 'test', '01', 'INFO', 0);
insert into cll_anomaly_categories (tenant_id, group_code, code, "level", fl_exclude)
values (:test_tenant, 'test', '02', 'WARN', 0);
insert into cll_anomaly_categories (tenant_id, group_code, code, "level", fl_exclude)
values (:test_tenant, 'test', '03', 'DANGER', 0);
insert into cll_anomaly_categories (tenant_id, group_code, code, "level", fl_exclude)
values (:test_tenant, 'test', '00', 'INFO', 1);

insert into cll_anomaly_categories (tenant_id, group_code, code, "level", fl_exclude)
values (:test_tenant, 'test', 'VAT69', 'DANGER', 0);
insert into cll_anomaly_categories (tenant_id, group_code, code, "level", fl_exclude)
values (:test_tenant, 'test', 'WD40', 'INFO', 0);
