insert into cll_title_type(id, code, tenant_id, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, 'TYPE', :test_tenant, 0, 0, 0, TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'admin', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_title_type(id, code, tenant_id, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2, 'TITLE', :test_tenant, 1, 1, 0, TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'admin', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_title_type(id, code, tenant_id, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-3, 'TEST', :test_tenant, 1, 1, 0, TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'admin', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_group (id, tenant_id, party_id, title_type_id)
values (-1, :test_tenant, 555, -1);
insert into cll_group_detail(pkid, group_id, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, -1, 'GROUP', TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'admin', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

--- links (title type will no match group) ---

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-11101, -11101, -1, :test_tenant, 555, -1, 100,
        10101, '00001', 'A001', '1', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-11102, -11102, -1, :test_tenant, 555, -1, 33.33333333,
        12502, '00002', 'A001', '25', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-11103, -11103, -1, :test_tenant, 555, -1, 50,
        10203, '00003', 'A001', '2', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-11201, -11201, -1, :test_tenant, 555, -2, 100,
        10204, '00004', 'A001', '2', '20200202', '20300302',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-12101, -12101, -1, :test_tenant, 555, -1, 100,
        20201, '00001', 'A002', '2', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-12102, -12102, -1, :test_tenant, 555, -1, 50,
        20502, '00002', 'A002', '5', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-12103, -12103, -1, :test_tenant, 555, -1, 50,
        20501, '00001', 'A002', '5', '20200202', '20211202', -- venduta
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-12301, -12301, -1, :test_tenant, 555, -3, 100,
        20205, '00005', 'A002', '2', '20200202', '20300302',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-12302, -12302, -1, :test_tenant, 555, -3, 75,
        20305, '00005', 'A002', '3', '20200202', '20300302',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-13201, -13201, -1, :test_tenant, 555, -2, 100,
        30101, '00001', 'A003', '1', '20200202', '20300302',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-13202, -13202, -1, :test_tenant, 555, -2, 100,
        30102, '00002', 'A003', '1', '20200202', '20300302',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-13203, -13203, -1, :test_tenant, 555, -2, 100,
        30103, '00003', 'A003', '1', '20200202', '20300302',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-14101, -14101, -1, :test_tenant, 555, -1, 100,
        40101, '00001', 'A004', '1', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-14201, -14201, -1, :test_tenant, 555, -2, 100,
        40102, '00002', 'A004', '1', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-14301, -14301, -1, :test_tenant, 555, -3, 100,
        40103, '00003', 'A004', '1', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

/*

 		10101 --> ((15987 * 100        ) / 100)
		12502 --> ((30000 * 33.33333333) / 100)
		10203 --> ((59688 * 50         ) / 100)
		10204 --> ((9963  * 100        ) / 100)

		20201 --> ((23232 * 100        ) / 100)
		20502 --> ((88888 * 50         ) / 100)
		20205 --> ((12023 * 100        ) / 100)
		20305 --> ((88888 * 75         ) / 100)

		30101 --> ((12458 * 100        ) / 100)
		30102 --> ((9236  * 100        ) / 100)
		30103 --> ((19992 * 100        ) / 100)

		40101 --> ((25000 * 100        ) / 100)
		40102 --> ((25000 * 100        ) / 100)
		40103 --> ((50000 * 100        ) / 100)

 */
