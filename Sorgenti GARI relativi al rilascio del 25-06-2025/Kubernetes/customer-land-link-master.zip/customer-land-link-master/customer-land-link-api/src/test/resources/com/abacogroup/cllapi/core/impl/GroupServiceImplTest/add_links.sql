

-- g 1 p 1
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-101, -1011, -1, :test_tenant, 555, -100, 100,
        123101, 'sc101', 'bc101', '00101', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-06-23', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-101, -1012, -1, :test_tenant, 555, -100, 100,
        123101, 'sc101', 'bc101', '00101', '20200202', '20210531',
        TO_DATE('2022-06-23', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1011, -10111, -1, :test_tenant, 555, -100, 80,
        123101, 'sc101', 'bc101', '00101', '20210601', '99991231',
        TO_DATE('2022-06-24', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- g 1 p 2
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-102, -1021, -1, :test_tenant, 555, -100, 50,
        123102, 'sc102', 'bc102', '00102', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- g 1 p 3
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-103, -1031, -1, :test_tenant, 555, -100, 100,
        123103, 'sc103', 'bc103', '00103', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-12-11', 'YYYY-MM-DD'), :user_id);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-103, -1032, -1, :test_tenant, 555, -100, 100,
        123103, 'sc103', 'bc103', '00103', '20200202', '20211202',
        TO_DATE('2022-12-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

----------------------------------

-- g 2 p 1
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-201, -2011, -2, :test_tenant, 555, -102, 100,
        123201, 'sc201', 'bc201', '00201', '20200202', '20250505',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- g 2 p 2
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-202, -2021, -2, :test_tenant, 555, -102, 50,
        123202, 'sc202', 'bc202', '00202', '20200202', '20250505',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- g 2 p 3
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-203, -2031, -2, :test_tenant, 555, -102, 100,
        123203, 'sc203', 'bc203', '00203', '20200202', '20250505',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-12-11', 'YYYY-MM-DD'), :user_id);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-203, -2032, -2, :test_tenant, 555, -102, 100,
        123203, 'sc203', 'bc203', '00203', '20200202', '20211202',
        TO_DATE('2022-12-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


------------------------------------------------------------------

-- g 9 p 1
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-901, -9011, -9, :test_tenant, 555, -100, 100,
        911, 'A009', '1', '00001', '20011002', '20200202',
        TO_DATE('2001-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
