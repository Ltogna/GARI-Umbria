insert into cll_anomaly_categories (tenant_id, group_code, code, "level", fl_exclude)
values (:test_tenant, 'parcel', 'P55', 'WARN', 0);
insert into cll_anomaly_categories (tenant_id, group_code, code, "level", fl_exclude)
values (:test_tenant, 'parcel', 'P55.6', 'DANGER', 0);
insert into cll_anomaly_categories (tenant_id, group_code, code, "level", fl_exclude)
values (:test_tenant, 'dd', 'ATTO', 'WARN', 0);
--**********************

insert into cll_anomalies (id,tenant_id,type_group_code,type_code,entity_code,entity_id,valid_from,valid_to,dt_insert,user_id_insert,dt_delete,user_id_delete)
values (-1,:test_tenant,'parcel','P55','REFERENCE_PARCEL','123412','20230101','99991231', to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_anomalies (id,tenant_id,type_group_code,type_code,entity_code,entity_id,valid_from,valid_to,dt_insert,user_id_insert,dt_delete,user_id_delete)
values (-2,:test_tenant,'parcel','P55','REFERENCE_PARCEL','123416','20230101','99991231', to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_anomalies (id,tenant_id,type_group_code,type_code,entity_code,entity_id,valid_from,valid_to,dt_insert,user_id_insert,dt_delete,user_id_delete)
values (-3,:test_tenant,'parcel','P55','REFERENCE_PARCEL','123419','20230101','99991231', to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_anomalies (id,tenant_id,type_group_code,type_code,entity_code,entity_id,valid_from,valid_to,dt_insert,user_id_insert,dt_delete,user_id_delete)
values (-4,:test_tenant,'parcel','P55','REFERENCE_PARCEL','123422','20230101','99991231', to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_anomalies (id,tenant_id,type_group_code,type_code,entity_code,entity_id,valid_from,valid_to,dt_insert,user_id_insert,dt_delete,user_id_delete)
values (-5,:test_tenant,'dd','ATTO','REFERENCE_CLL_GROUP','16','20230101','99991231', to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_anomalies (id,tenant_id,type_group_code,type_code,entity_code,entity_id,valid_from,valid_to,dt_insert,user_id_insert,dt_delete,user_id_delete)
values (-6,:test_tenant,'parcel','P55.6','REFERENCE_PARTY_PARCEL','555-123416','20230101','99991231', to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_anomalies (id,tenant_id,type_group_code,type_code,entity_code,entity_id,valid_from,valid_to,dt_insert,user_id_insert,dt_delete,user_id_delete)
values (-7,:test_tenant,'parcel','P55.6','REFERENCE_PARTY_PARCEL','555-123419','20230101','99991231', to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_anomalies (id,tenant_id,type_group_code,type_code,entity_code,entity_id,valid_from,valid_to,dt_insert,user_id_insert,dt_delete,user_id_delete)
values (-8,:test_tenant,'parcel','P55.6','REFERENCE_PARTY_PARCEL','999-123419','20230101','99991231', to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);
