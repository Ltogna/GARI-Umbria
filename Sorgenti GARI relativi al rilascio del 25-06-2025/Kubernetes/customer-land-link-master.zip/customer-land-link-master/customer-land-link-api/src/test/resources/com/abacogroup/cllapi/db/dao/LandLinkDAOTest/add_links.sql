INSERT INTO cll_title_type(id, tenant_id, code, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-1, :test_tenant, 'OWNERSHIP', 0, 0, 0, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id,  TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO cll_title_type (id, tenant_id, code, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2, :test_tenant, 'RENT', 1, 1, 0, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

---

INSERT INTO cll_group (id, tenant_id, party_id, title_type_id)
VALUES (-1, :test_tenant, 555, -1);
INSERT INTO cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-1, -1, 'group 1', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO cll_group (id, tenant_id, party_id, title_type_id)
VALUES (-2, :test_tenant, 555, -2);
INSERT INTO cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2, -2, 'group 2', TO_DATE('2023-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

---

-- g 1 p 1
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-101, -101, -1, :test_tenant, 555, -1, 100,
        111, 'A001', '1', '00001', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- g 1 p 2
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-102, -102, -1, :test_tenant, 555, -1, 100,
        112, 'A001', '1', '00002', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- g 1 p 3
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-103, -103, -1, :test_tenant, 555, -1, 100,
        113, 'A001', '1', '00003', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- g 2 p 1
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-201, -201, -2, :test_tenant, 555, -2, 100,
        211, 'A002', '1', '00001', '20200202', '20300302',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- g 2 p 2
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-202, -202, -2, :test_tenant, 555, -2, 100,
        212, 'A002', '1', '00002', '20200202', '20300302',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

