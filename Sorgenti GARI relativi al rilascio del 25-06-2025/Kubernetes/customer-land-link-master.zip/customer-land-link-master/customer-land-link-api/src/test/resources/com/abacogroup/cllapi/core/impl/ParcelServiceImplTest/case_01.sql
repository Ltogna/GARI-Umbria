insert into cll_settings (pkid, tenant_id, lpis_sub_separator, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, :test_tenant, '/', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'),
        null);

INSERT INTO cll_title_type
(id, tenant_id, code, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-100, :test_tenant, 'OWNERSHIP', 0, 0, 0, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id,
        TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);


INSERT INTO cll_group (id, tenant_id, party_id, title_type_id)
VALUES (-1, :test_tenant, 666, -100);

INSERT INTO cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-1, -100, 'group1 del party 666', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id,
        TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


INSERT INTO cll_group (id, tenant_id, party_id, title_type_id)
VALUES (-2, :test_tenant, 1, -100);

INSERT INTO cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2, -101, 'group1 del party 1', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id,
        TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


-- il party 666 ha in conduzione l'ultimo record del json
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1011, -1011, -1, :test_tenant, 666, -100, 97,
        697674, 'A061', '1', '00349', '20200202', '99991231',
        TO_DATE('2020-02-22', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


--il party corrente 1  ha in conduzione la penultima del json
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1012, -1012, -2, :test_tenant, 1, -100, 99,
        16030606, 'A061', '5', '00828', '20200202', '99991231',
        TO_DATE('2020-02-22', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

--il party corrente 1  HA AVUTO conduzione la terzultima del json fino alla giorno precedente rispetto al test
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1013, -1013, -2, :test_tenant, 1, -100, 100,
        16030604, 'A061', '5', '00827', '20200202', '20230308',
        TO_DATE('2020-02-22', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


---

INSERT INTO cll_group (id, tenant_id, party_id, title_type_id)
VALUES (-20, :test_tenant, 555, -100);


insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2011, -2011, -20, :test_tenant, 555, -100, 3,
        697674, 'A061', '1', '00349', '20231028', '20231029',
        TO_DATE('2020-02-22', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
