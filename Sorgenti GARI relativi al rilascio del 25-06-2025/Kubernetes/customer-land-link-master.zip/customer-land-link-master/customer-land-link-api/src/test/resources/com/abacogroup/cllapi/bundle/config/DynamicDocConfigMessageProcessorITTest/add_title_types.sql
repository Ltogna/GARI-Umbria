INSERT INTO cll_title_type (id, tenant_id, code, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-1, :test_tenant, 'OWNERSHIP', 0, 0, 0, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id,
        TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);

INSERT INTO cll_title_type
    (id, tenant_id, code, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2, :test_tenant, 'RENT', 1, 1, 0, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id,
        TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);

INSERT INTO cll_title_type
    (id, tenant_id, code, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-3, :test_tenant, 'SHARECROPPING', 1, 1, 0, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id,
        TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);
