-- group 1
INSERT INTO cll_group (id, tenant_id, party_id, title_type_id)
VALUES (-78, :test_tenant, 555, :titleId);
INSERT INTO cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-78, -100, 'group 1', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
