INSERT INTO cll_group (id, tenant_id, party_id, title_type_id)
VALUES (-1, :test_tenant, 555, -100);
INSERT INTO cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-1, -100, 'group 1', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO cll_group (id, tenant_id, party_id, title_type_id)
VALUES (-2, :test_tenant, 555, -102);
INSERT INTO cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2, -201, 'group 2 old', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('2023-01-01', 'YYYY-MM-DD'), :user_id);
INSERT INTO cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-2, -202, 'group 2', TO_DATE('2023-01-01', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

INSERT INTO cll_group (id, tenant_id, party_id, title_type_id)
VALUES (-9, :test_tenant, 555, -100);
INSERT INTO cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-9, -901, 'group closed', TO_DATE('2001-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

