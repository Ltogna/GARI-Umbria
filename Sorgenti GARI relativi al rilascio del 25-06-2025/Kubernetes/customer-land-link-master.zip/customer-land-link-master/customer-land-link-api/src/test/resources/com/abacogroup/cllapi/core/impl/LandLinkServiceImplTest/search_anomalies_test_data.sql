insert into cll_title_type(id, code, tenant_id, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, 'TYPE', :test_tenant, 0, 0, 0, TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'admin', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_title_type(id, code, tenant_id, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2, 'TITLE', :test_tenant, 1, 1, 0, TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'admin', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_title_type(id, code, tenant_id, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-3, 'TEST', :test_tenant, 1, 1, 0, TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'admin', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


-- GROUP 1 --

insert into cll_group (id, tenant_id, party_id, title_type_id)
values (-1, :test_tenant, 555, -1);
insert into cll_group_detail(pkid, group_id, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, -1, 'GROUP 1', TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'admin', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1001, -1001, 1001, '00001', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1002, -1002, 1002, '00002', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1003, -1003, 1003, '00003', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1004, -1004, 1004, '00004', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1005, -1005, 1005, '00005', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1006, -1006, 1006, '00006', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1007, -1007, 1007, '00007', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1008, -1008, 1008, '00008', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1009, -1009, 1009, '00009', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1010, -1010, 1010, '00010', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1011, -1011, 1011, '00011', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1012, -1012, 1012, '00012', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1013, -1013, 1013, '00013', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1014, -1014, 1014, '00014', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1015, -1015, 1015, '00015', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1016, -1016, 1016, '00016', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1017, -1017, 1017, '00017', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1018, -1018, 1018, '00018', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1019, -1019, 1019, '00019', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1020, -1020, 1020, '00020', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1021, -1021, 1021, '00021', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1022, -1022, 1022, '00022', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1023, -1023, 1023, '00023', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1024, -1024, 1024, '00024', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1025, -1025, 1025, '00025', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1026, -1026, 1026, '00026', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1027, -1027, 1027, '00027', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1028, -1028, 1028, '00028', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1029, -1029, 1029, '00029', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1030, -1030, 1030, '00030', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1031, -1031, 1031, '00031', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1032, -1032, 1032, '00032', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1033, -1033, 1033, '00033', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1034, -1034, 1034, '00034', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1035, -1035, 1035, '00035', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1036, -1036, 1036, '00036', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1037, -1037, 1037, '00037', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1038, -1038, 1038, '00038', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1039, -1039, 1039, '00039', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1040, -1040, 1040, '00040', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1041, -1041, 1041, '00041', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1042, -1042, 1042, '00042', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1043, -1043, 1043, '00043', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1044, -1044, 1044, '00044', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1045, -1045, 1045, '00045', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1046, -1046, 1046, '00046', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1047, -1047, 1047, '00047', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1048, -1048, 1048, '00048', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, parcel_id, parcel_code, group_id, tenant_id, party_id, title_type_id, title_type_perc, sector_code, block_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1049, -1049, 1049, '00049', -1, :test_tenant, 555, -1, 100, 'A001', '1', '20200202', '99991231', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
