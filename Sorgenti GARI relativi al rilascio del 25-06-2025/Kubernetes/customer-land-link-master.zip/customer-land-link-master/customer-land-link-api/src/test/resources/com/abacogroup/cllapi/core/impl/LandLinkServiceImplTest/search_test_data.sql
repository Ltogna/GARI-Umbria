insert into cll_title_type(id, code, tenant_id, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, 'TYPE', :test_tenant, 0, 0, 0, TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'admin', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_title_type(id, code, tenant_id, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2, 'TITLE', :test_tenant, 1, 1, 0, TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'admin', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_title_type(id, code, tenant_id, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-3, 'TEST', :test_tenant, 1, 1, 0, TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'admin', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


-- GROUP 1 --

insert into cll_group (id, tenant_id, party_id, title_type_id)
values (-1, :test_tenant, 555, -1);
insert into cll_group_detail(pkid, group_id, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, -1, 'GROUP 1', TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'admin', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-11101, -11101, -1, :test_tenant, 555, -1, 100,
        10101, '00001', 'A001', '1', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-11102, -11102, -1, :test_tenant, 555, -1, 33.33333333,
        12502, '00002', 'A001', '25', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-11103, -11103, -1, :test_tenant, 555, -1, 50,
        10203, '00003', 'A001', '2', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sub_parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-12101, -12101, -1, :test_tenant, 555, -1, 100,
        202011, '00001', 'A', 'A002', '2', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-12102, -12102, -1, :test_tenant, 555, -1, 50,
        20502, '00002', 'A002', '5', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-12103, -12103, -1, :test_tenant, 555, -1, 50,
        20501, '00001', 'A002', '5', '20200202', '20211202', -- venduta
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sub_parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-14101, -14101, -1, :test_tenant, 555, -1, 100,
        401011, '00001', 'A', 'A004', '1', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sub_parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-14102, -14102, -1, :test_tenant, 555, -1, 100,
        401012, '00001', 'B', 'A004', '1', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- GROUP 2 --

insert into cll_group (id, tenant_id, party_id, title_type_id)
values (-2, :test_tenant, 555, -2);
insert into cll_group_detail(pkid, group_id, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2, -2, 'GROUP 2', TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'admin', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-11201, -11201, -2, :test_tenant, 555, -2, 100,
        10204, '00004', 'A001', '2', '20200202', '20300302',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-13201, -13201, -2, :test_tenant, 555, -2, 100,
        30101, '00001', 'A003', '1', '20200202', '20300302',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-13202, -13202, -2, :test_tenant, 555, -2, 100,
        30102, '00002', 'A003', '1', '20200202', '20300302',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-13203, -13203, -2, :test_tenant, 555, -2, 0.01,
        30103, '00003', 'A003', '1', '20200202', '20300302',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-14201, -14201, -2, :test_tenant, 555, -2, 100,
        40102, '00002', 'A004', '1', '20200202', '20220101', -- venduta
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- GROUP 3 --

insert into cll_group (id, tenant_id, party_id, title_type_id)
values (-3, :test_tenant, 555, -3);
insert into cll_group_detail(pkid, group_id, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-3, -3, 'GROUP 3', TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'admin', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-12301, -12301, -3, :test_tenant, 555, -3, 100,
        20205, '00005', 'A002', '2', '20200202', '20300302',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-12302, -12302, -3, :test_tenant, 555, -3, 75,
        20305, '00005', 'A002', '3', '20200202', '20300302',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-14301, -14301, -3, :test_tenant, 555, -3, 0.01,
        40103, '00003', 'A004', '1', '20200202', '20300302',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- GROUP 4 closed (same parcels as group 3 but different range) --

insert into cll_group (id, tenant_id, party_id, title_type_id)
values (-4, :test_tenant, 555, -2);
insert into cll_group_detail(pkid, group_id, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-4, -4, 'GROUP OLD', TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'admin', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-12401, -12401, -4, :test_tenant, 555, -2, 100,
        20205, '00005', 'A002', '2', '20011002', '20200202',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-12402, -12402, -4, :test_tenant, 555, -2, 75,
        20305, '00005', 'A002', '3', '20011002', '20200202',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-14401, -14401, -4, :test_tenant, 555, -2, 100,
        40103, '00003', 'A004', '1', '20011002', '20200202',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);


-- GROUP X (other party) --

insert into cll_group (id, tenant_id, party_id, title_type_id)
values (-999, :test_tenant, 666, -1);
insert into cll_group_detail(pkid, group_id, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-999, -999, 'GROUP X', TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'admin', TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- same parcel as -14301 (gr 3)
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-14901, -14901, -999, :test_tenant, 666, -1, 100,
        40103, '00003', 'A004', '1', '20011002', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
