insert into cll_anomaly_categories (tenant_id, group_code, code, "level", fl_exclude)
values ('*', 'test', '01', 'INFO', 0);
insert into cll_anomaly_categories (tenant_id, group_code, code, "level", fl_exclude)
values ('*', 'test', '02', 'WARN', 0);
insert into cll_anomaly_categories (tenant_id, group_code, code, "level", fl_exclude)
values ('*', 'test', '03', 'DANGER', 0);
insert into cll_anomaly_categories (tenant_id, group_code, code, "level", fl_exclude)
values ('*', 'test', '00', 'INFO', 1);
