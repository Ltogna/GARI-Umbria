INSERT INTO cll_title_type
    (id, tenant_id, code, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-100, :test_tenant, 'OWNERSHIP', 0, 0, 0, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id,
        TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);

INSERT INTO cll_title_type
    (id, tenant_id, code, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-101, :test_tenant, 'RENT', 1, 1, 0, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id,
        TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);


INSERT INTO cll_title_type
    (id, tenant_id, code, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-102, :test_tenant, 'SHARECROPPING', 1, 1, 0, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id,
        TO_DATE('9999-12-31', 'YYYY-MM-DD'), :user_id);


INSERT INTO cll_title_type
    (id, tenant_id, code, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-103, :test_tenant, 'OTHER_TYPE', 1, 1, 0, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id,
        TO_DATE('2022-05-12', 'YYYY-MM-DD'), 'test_delete');
