insert into cll_title_type(id, code, tenant_id, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from,
                           dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, 'TYPE', :test_tenant, 1, 1, 0,
        to_date('2023-01-20', 'YYYY-MM-DD'), 'admin', to_date('9999-12-31', 'YYYY-MM-DD'), null);
insert into cll_title_type(id, code, tenant_id, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from,
                           dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2, 'TITLE', :test_tenant, 0, 0, 0,
        to_date('2023-01-20', 'YYYY-MM-DD'), 'admin', to_date('9999-12-31', 'YYYY-MM-DD'), null);


insert into cll_group (id, tenant_id, party_id, title_type_id)
values (-1, :test_tenant, 555, -1);

insert into cll_group_detail(pkid, group_id, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, -1, 'GROUP',
        to_date('2023-01-20', 'YYYY-MM-DD'), 'admin', to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_group (id, tenant_id, party_id, title_type_id)
values (-2, :test_tenant, 555, -2);

insert into cll_group_detail(pkid, group_id, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2, -2, 'GROUP_2',
        to_date('2023-01-01', 'YYYY-MM-DD'), 'admin', to_date('9999-12-31', 'YYYY-MM-DD'), null);
