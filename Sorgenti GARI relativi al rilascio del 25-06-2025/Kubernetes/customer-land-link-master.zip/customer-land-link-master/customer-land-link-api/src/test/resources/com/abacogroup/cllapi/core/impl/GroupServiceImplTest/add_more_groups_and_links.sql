-- group 3 - rent
INSERT INTO cll_group (id, tenant_id, party_id, title_type_id)
VALUES (-3, :test_tenant, 555, -101);
INSERT INTO cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-3, -301, 'group test 3', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- g 3 p 1
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-301, -301, -3, :test_tenant, 555, -101, 100,
        123301, 'sc301', 'bc301', '00301', '20220101', '20261231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- g 3 p 2
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-302, -302, -3, :test_tenant, 555, -101, 50,
        123302, 'sc302', 'bc302', '00302', '20220101', '20261231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- g3 p 3
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-303, -303, -3, :test_tenant, 555, -101, 50,
        12302, 'sc303', 'bc303', '00303', '20220101', '20261231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

---------------------------------------------------------------------------------------------------------------
-- group 4 - other party
INSERT INTO cll_group (id, tenant_id, party_id, title_type_id)
VALUES (-4, :test_tenant, 666, -101);
INSERT INTO cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-4, -401, 'group 4', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- g 4 p 1
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-401, -4011, -4, :test_tenant, 666, -101, 50,
        123401, 'sc401', 'bc401', '00401', '20200202', '20261231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-----------------------------------------------------------------------------------------------------------------

-- group 5 - closed
INSERT INTO cll_group (id, tenant_id, party_id, title_type_id)
VALUES (-5, :test_tenant, 555, -101);
INSERT INTO cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-5, -501, 'group 5', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- g 5 p 1
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-501, -501, -5, :test_tenant, 555, -101, 100,
        123501, 'sc501', 'bc501', '00501', '20200202', '20211202',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- g 5 p 2
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-502, -502, -5, :test_tenant, 555, -101, 50,
        123502, 'sc502', 'bc502', '00502', '20200202', '20211202',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

--------------------------------------------------
-- group 6 - expired title type
INSERT INTO cll_group (id, tenant_id, party_id, title_type_id)
VALUES (-6, :test_tenant, 555, -103);
INSERT INTO cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
VALUES (-6, -601, 'group 6', TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- g 6 p 1
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-601, -601, -6, :test_tenant, 555, -103, 100,
        123601, 'sc601', 'bc601', '00601', '20011002', '20251231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
