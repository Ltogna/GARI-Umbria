

-- g 9 p 1
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-902, -9021, -9, :test_tenant, 555, -100, 100,
        922, 'A009', '1', '00001', '20011002', '20100102',
        TO_DATE('2001-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-903, -9031, -9, :test_tenant, 555, -100, 50,
        922, 'A009', '1', '00001', '20100103', '20111102',
        TO_DATE('2001-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-904, -9041, -9, :test_tenant, 555, -100, 100,
        922, 'A009', '1', '00001', '20111103', '20200202',
        TO_DATE('2001-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
