

-- g 1 p 1
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-101, -1011, -1, :test_tenant, 555, -101, 100,
        123101, 'sc101', 'bc101', '00002', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- g 1 p 2
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-102, -1021, -1, :test_tenant, 555, -101, 50,
        123102, 'sc102', 'bc102', '00002', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);

-- g 1 p 3
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-103, -1031, -1, :test_tenant, 555, -101, 100,
        123103, 'sc103', 'bc103', '00002', '20200202', '99991231',
        TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('2022-12-11', 'YYYY-MM-DD'), :user_id);
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-103, -1032, -1, :test_tenant, 555, -101, 100,
        123103, 'sc103', 'bc103', '00002', '20200202', '20211202',
        TO_DATE('2022-12-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), null);
