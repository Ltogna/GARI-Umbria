--OWNERSHIP : DEF_1 - DEF_2   /  RENT : DEF_1 - DEF_3 / SHARECROPPING : DEF_1

INSERT INTO cll_doc_type_relations (tenant_id, title_type_id, definition_code,
                                    fl_required, fl_req_on_add, fl_req_on_close, dt_insert, user_id_insert, dt_delete, scope_code)
VALUES (:test_tenant, -1, 'DEF_1', 1, 1, 0, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), 'GROUPS');
INSERT
INTO cll_doc_type_relations (tenant_id, title_type_id, definition_code,
                             fl_required, fl_req_on_add, fl_req_on_close, dt_insert, user_id_insert, dt_delete, scope_code)
VALUES (:test_tenant, -1, 'DEF_2', 1, 1, 0, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), 'GROUPS');


INSERT INTO cll_doc_type_relations (tenant_id, title_type_id, definition_code,
                                    fl_required, fl_req_on_add, fl_req_on_close, dt_insert, user_id_insert, dt_delete, scope_code)
VALUES (:test_tenant, -2, 'DEF_1', 1, 1, 0, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), 'GROUPS');


INSERT INTO cll_doc_type_relations (tenant_id, title_type_id, definition_code,
                                    fl_required, fl_req_on_add, fl_req_on_close, dt_insert, user_id_insert, dt_delete, scope_code)
VALUES (:test_tenant, -2, 'DEF_3', 1, 1, 0, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), 'GROUPS');


INSERT INTO cll_doc_type_relations (tenant_id, title_type_id, definition_code,
                                    fl_required, fl_req_on_add, fl_req_on_close, dt_insert, user_id_insert, dt_delete, scope_code)
VALUES (:test_tenant, -3, 'DEF_1', 1, 1, 0, TO_DATE('2022-05-11', 'YYYY-MM-DD'), :user_id, TO_DATE('9999-12-31', 'YYYY-MM-DD'), 'GROUPS');

