-- for parcel 123105
-- g 1 p 1
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, parcel_code, sector_code, block_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-104, -1040, -2, :test_tenant, 555, -2, 100,
        123105, 'sc101', '00123', 'bc101', '20200202', '20230501',
        to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

-- g 1 p 2
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-105, -1041, -1, :test_tenant, 555, -1, 50,
        123105, 'sc102', 'bc102', '00123', '20200202', '99991231',
        to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

-- expired
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-106, -1036, -1, :test_tenant, 555, -1, 100,
        123105, 'sc103', 'bc103', '00123', '20200202', '20220101',
        to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('2022-12-11', 'YYYY-MM-DD'), :user_id);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-107, -1045, -1, :test_tenant, 555, -1, 100,
        123109, 'sc103', 'bc103', '00123', '20200202', '20230301',
        to_date('2022-12-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);
