-- add title types
insert into cll_title_type
    (id, tenant_id, code, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-100, :test_tenant, 'OWNERSHIP', 0, 0, 0, to_date('2022-05-11', 'YYYY-MM-DD'), :user_id,
        to_date('9999-12-31', 'YYYY-MM-DD'), :user_id);

insert into cll_title_type
    (id, tenant_id, code, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-101, :test_tenant, 'RENT', 0, 0, 0, to_date('2022-05-11', 'YYYY-MM-DD'), :user_id,
        to_date('9999-12-31', 'YYYY-MM-DD'), :user_id);

insert into cll_title_type
    (id, tenant_id, code, fl_day_to_req, fl_day_to_editable, fl_allow_future_day_from, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-103, :test_tenant, 'SHARECROPPING', 1, 1, 0, to_date('2022-05-11', 'YYYY-MM-DD'), :user_id,
        to_date('9999-12-31', 'YYYY-MM-DD'), :user_id);

-- add groups

--g1
insert into cll_group (id, tenant_id, party_id, title_type_id)
values (-1, :test_tenant, 666, -100);

insert into cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1, -100, 'group 1', to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

-- g2
insert into cll_group (id, tenant_id, party_id, title_type_id)
values (-2, :test_tenant, 666, -101);

insert into cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2, -101, 'group 2', to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

--g3
insert into cll_group (id, tenant_id, party_id, title_type_id)
values (-3, :test_tenant, 666, -101);

insert into cll_group_detail (group_id, pkid, descr, dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-3, -103, 'group 3', to_date('2022-05-11', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);


---

/*

# range
° found
# not found

G        2020 2021 2022 2023 2024
0       |    |XXXXXXXXXXXXXX|    |    |
1       |    |    |°°°°|    |####|    |
1       |°°°°°°°°°|    |    |    |    |
2       |####|    |    |°°°°°°°°°|    |
2       |°°°°°°°°°°°°°°°°°°°°°°°°|    |

 */

--group 1
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1011, -1011, -1, :test_tenant, 666, -100, 97,
        697674, 'A061', '1', '00349', '20220101', '20221231',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1012, -1012, -1, :test_tenant, 666, -100, 97,
        697673, 'A061', '1', '00349', '20240101', '99991231',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-1013, -1013, -1, :test_tenant, 666, -100, 97,
        697675, 'A061', '1', '00349', '20200101', '20211231',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);


-- group2
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2011, -2011, -2, :test_tenant, 666, -101, 97,
        697674, 'A061', '1', '00349', '20230101', '20241231',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);

insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2012, -2012, -2, :test_tenant, 666, -101, 97,
        697680, 'A061', '1', '00349', '20200101', '20201231',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);


-- group3
insert into cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc,
                                  parcel_id, sector_code, block_code, parcel_code, day_from, day_to,
                                  dt_insert, user_id_insert, dt_delete, user_id_delete)
values (-2013, -2013, -3, :test_tenant, 666, -103, 90,
        697674, 'A061', '1', '00349', '20210101', '20241231',
        to_date('2019-01-01', 'YYYY-MM-DD'), :user_id, to_date('9999-12-31', 'YYYY-MM-DD'), null);
