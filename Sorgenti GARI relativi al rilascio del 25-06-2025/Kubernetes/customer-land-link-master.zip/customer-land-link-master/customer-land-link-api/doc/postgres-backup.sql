--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8 (Debian 13.8-1.pgdg110+1)
-- Dumped by pg_dump version 13.8 (Debian 13.8-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: tiger; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA tiger;


ALTER SCHEMA tiger OWNER TO postgres;

--
-- Name: tiger_data; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA tiger_data;


ALTER SCHEMA tiger_data OWNER TO postgres;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO postgres;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: postgis_tiger_geocoder; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder WITH SCHEMA tiger;


--
-- Name: EXTENSION postgis_tiger_geocoder; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_tiger_geocoder IS 'PostGIS tiger geocoder and reverse geocoder';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bnd_lock; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.bnd_lock (
    locked integer NOT NULL
);


ALTER TABLE public.bnd_lock OWNER TO cll;

--
-- Name: bnd_registry; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.bnd_registry (
    tenant_id character varying(100) NOT NULL,
    changeset character varying(255) NOT NULL,
    md5 character varying(32) NOT NULL,
    dt_insert timestamp without time zone
);


ALTER TABLE public.bnd_registry OWNER TO cll;

--
-- Name: bnd_tenant; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.bnd_tenant (
    tenant_id character varying(100) NOT NULL,
    dt_insert timestamp without time zone
);


ALTER TABLE public.bnd_tenant OWNER TO cll;

--
-- Name: cll_anomaly_categories; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.cll_anomaly_categories (
    tenant_id character varying(100) NOT NULL,
    group_code character varying(100) NOT NULL,
    code character varying(100) NOT NULL,
    level character varying(100) NOT NULL,
    fl_exclude numeric(1,0) DEFAULT 0 NOT NULL,
    CONSTRAINT cll_anomaly_categories_ck1 CHECK ((fl_exclude = ANY (ARRAY[(0)::numeric, (1)::numeric])))
);


ALTER TABLE public.cll_anomaly_categories OWNER TO cll;

--
-- Name: TABLE cll_anomaly_categories; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON TABLE public.cll_anomaly_categories IS 'Cll anomaly categories table';


--
-- Name: COLUMN cll_anomaly_categories.tenant_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_anomaly_categories.tenant_id IS 'the tenant''s id';


--
-- Name: COLUMN cll_anomaly_categories.group_code; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_anomaly_categories.group_code IS 'group code of anomaly';


--
-- Name: COLUMN cll_anomaly_categories.code; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_anomaly_categories.code IS 'code of anomaly';


--
-- Name: COLUMN cll_anomaly_categories.level; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_anomaly_categories.level IS 'level of anomaly';


--
-- Name: COLUMN cll_anomaly_categories.fl_exclude; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_anomaly_categories.fl_exclude IS 'flag for exclude category, default 0';


--
-- Name: cll_doc_type_relations; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.cll_doc_type_relations (
    pkid bigint NOT NULL,
    tenant_id character varying(100) NOT NULL,
    title_type_id bigint NOT NULL,
    definition_code character varying(100) NOT NULL,
    fl_required integer NOT NULL,
    fl_req_on_add integer NOT NULL,
    fl_req_on_close integer NOT NULL,
    dt_insert timestamp without time zone NOT NULL,
    user_id_insert character varying(100) NOT NULL,
    dt_delete timestamp without time zone NOT NULL,
    user_id_delete character varying(100),
    CONSTRAINT cll_doc_type_relations_ck1 CHECK ((fl_required = ANY (ARRAY[0, 1]))),
    CONSTRAINT cll_doc_type_relations_ck2 CHECK ((fl_req_on_add = ANY (ARRAY[0, 1]))),
    CONSTRAINT cll_doc_type_relations_ck3 CHECK ((fl_req_on_close = ANY (ARRAY[0, 1])))
);


ALTER TABLE public.cll_doc_type_relations OWNER TO cll;

--
-- Name: TABLE cll_doc_type_relations; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON TABLE public.cll_doc_type_relations IS 'doc type relations table';


--
-- Name: COLUMN cll_doc_type_relations.pkid; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_doc_type_relations.pkid IS 'The document type relation id - primary key';


--
-- Name: COLUMN cll_doc_type_relations.tenant_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_doc_type_relations.tenant_id IS 'The tenant id';


--
-- Name: COLUMN cll_doc_type_relations.title_type_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_doc_type_relations.title_type_id IS 'The title type id';


--
-- Name: COLUMN cll_doc_type_relations.definition_code; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_doc_type_relations.definition_code IS 'The definition code of the document';


--
-- Name: COLUMN cll_doc_type_relations.fl_required; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_doc_type_relations.fl_required IS 'Flag used to define whether the document is always required or not';


--
-- Name: COLUMN cll_doc_type_relations.fl_req_on_add; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_doc_type_relations.fl_req_on_add IS 'Flag used to define whether the document is required when creating a new group';


--
-- Name: COLUMN cll_doc_type_relations.fl_req_on_close; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_doc_type_relations.fl_req_on_close IS 'Flag used to define whether the document is required when closing a group';


--
-- Name: COLUMN cll_doc_type_relations.dt_insert; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_doc_type_relations.dt_insert IS 'The database''s timestamp when this record was created';


--
-- Name: COLUMN cll_doc_type_relations.user_id_insert; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_doc_type_relations.user_id_insert IS 'The user id which inserted this record';


--
-- Name: COLUMN cll_doc_type_relations.dt_delete; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_doc_type_relations.dt_delete IS 'The database''s timestamp when this record was logically deleted';


--
-- Name: COLUMN cll_doc_type_relations.user_id_delete; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_doc_type_relations.user_id_delete IS 'The user id which logically deleted this record';


--
-- Name: cll_doc_type_relations_pkid_seq; Type: SEQUENCE; Schema: public; Owner: cll
--

ALTER TABLE public.cll_doc_type_relations ALTER COLUMN pkid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cll_doc_type_relations_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cll_group; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.cll_group (
    id bigint NOT NULL,
    tenant_id character varying(100) NOT NULL,
    party_id bigint NOT NULL,
    title_type_id bigint NOT NULL
);


ALTER TABLE public.cll_group OWNER TO cll;

--
-- Name: TABLE cll_group; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON TABLE public.cll_group IS 'tags table';


--
-- Name: COLUMN cll_group.id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group.id IS 'The tag id- primary key';


--
-- Name: COLUMN cll_group.tenant_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group.tenant_id IS 'The tenant id';


--
-- Name: COLUMN cll_group.party_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group.party_id IS 'The party id- retrieved from external service';


--
-- Name: COLUMN cll_group.title_type_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group.title_type_id IS 'The title type id';


--
-- Name: cll_group_detail_pkid_seq; Type: SEQUENCE; Schema: public; Owner: cll
--

CREATE SEQUENCE public.cll_group_detail_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cll_group_detail_pkid_seq OWNER TO cll;

--
-- Name: cll_group_detail; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.cll_group_detail (
    pkid bigint DEFAULT nextval('public.cll_group_detail_pkid_seq'::regclass) NOT NULL,
    group_id bigint NOT NULL,
    descr character varying(255),
    dt_insert timestamp without time zone NOT NULL,
    user_id_insert character varying(100) NOT NULL,
    dt_delete timestamp without time zone NOT NULL,
    user_id_delete character varying(100)
);


ALTER TABLE public.cll_group_detail OWNER TO cll;

--
-- Name: TABLE cll_group_detail; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON TABLE public.cll_group_detail IS 'group details table ( child table of Cll group table)';


--
-- Name: COLUMN cll_group_detail.pkid; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group_detail.pkid IS 'The current group detail id';


--
-- Name: COLUMN cll_group_detail.group_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group_detail.group_id IS 'The group id';


--
-- Name: COLUMN cll_group_detail.descr; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group_detail.descr IS 'The description of group';


--
-- Name: COLUMN cll_group_detail.dt_insert; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group_detail.dt_insert IS 'The database''s timestamp when this record was created';


--
-- Name: COLUMN cll_group_detail.user_id_insert; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group_detail.user_id_insert IS 'The user id which inserted this record';


--
-- Name: COLUMN cll_group_detail.dt_delete; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group_detail.dt_delete IS 'The database''s timestamp when this record was logically deleted';


--
-- Name: COLUMN cll_group_detail.user_id_delete; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group_detail.user_id_delete IS 'The user id which logically deleted this record';


--
-- Name: cll_group_documents; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.cll_group_documents (
    pkid bigint NOT NULL,
    group_id bigint NOT NULL,
    definition_code character varying(100) NOT NULL,
    document_id bigint NOT NULL,
    dt_insert timestamp without time zone NOT NULL,
    user_id_insert character varying(100) NOT NULL,
    dt_delete timestamp without time zone NOT NULL,
    user_id_delete character varying(100)
);


ALTER TABLE public.cll_group_documents OWNER TO cll;

--
-- Name: TABLE cll_group_documents; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON TABLE public.cll_group_documents IS 'group documents table';


--
-- Name: COLUMN cll_group_documents.pkid; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group_documents.pkid IS 'group document id- primary key';


--
-- Name: COLUMN cll_group_documents.group_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group_documents.group_id IS 'The group id';


--
-- Name: COLUMN cll_group_documents.definition_code; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group_documents.definition_code IS 'The definition code of the document';


--
-- Name: COLUMN cll_group_documents.document_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group_documents.document_id IS 'The document id';


--
-- Name: COLUMN cll_group_documents.dt_insert; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group_documents.dt_insert IS 'The database''s timestamp when this record was created';


--
-- Name: COLUMN cll_group_documents.user_id_insert; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group_documents.user_id_insert IS 'The user id which inserted this record';


--
-- Name: COLUMN cll_group_documents.dt_delete; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group_documents.dt_delete IS 'The database''s timestamp when this record was logically deleted';


--
-- Name: COLUMN cll_group_documents.user_id_delete; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_group_documents.user_id_delete IS 'The user id which logically deleted this record';


--
-- Name: cll_group_documents_pkid_seq; Type: SEQUENCE; Schema: public; Owner: cll
--

ALTER TABLE public.cll_group_documents ALTER COLUMN pkid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cll_group_documents_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cll_i18n_values; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.cll_i18n_values (
    tenant_id character varying(100) NOT NULL,
    table_name character varying(100) NOT NULL,
    field_name character varying(100) NOT NULL,
    i18n_value character varying(4000) NOT NULL,
    lang character varying(20) NOT NULL,
    i18n_text character varying(4000) NOT NULL
);


ALTER TABLE public.cll_i18n_values OWNER TO cll;

--
-- Name: TABLE cll_i18n_values; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON TABLE public.cll_i18n_values IS 'Internationalized values table';


--
-- Name: COLUMN cll_i18n_values.tenant_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_i18n_values.tenant_id IS 'The tenant id';


--
-- Name: COLUMN cll_i18n_values.table_name; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_i18n_values.table_name IS 'The table name';


--
-- Name: COLUMN cll_i18n_values.field_name; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_i18n_values.field_name IS 'The field name';


--
-- Name: COLUMN cll_i18n_values.i18n_value; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_i18n_values.i18n_value IS 'The value to be internationalized';


--
-- Name: COLUMN cll_i18n_values.lang; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_i18n_values.lang IS 'The language of internationalization';


--
-- Name: COLUMN cll_i18n_values.i18n_text; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_i18n_values.i18n_text IS 'The internationalized text';


--
-- Name: cll_land_link_detail_pkid_seq; Type: SEQUENCE; Schema: public; Owner: cll
--

CREATE SEQUENCE public.cll_land_link_detail_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cll_land_link_detail_pkid_seq OWNER TO cll;

--
-- Name: cll_land_link_detail; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.cll_land_link_detail (
    id bigint NOT NULL,
    pkid bigint DEFAULT nextval('public.cll_land_link_detail_pkid_seq'::regclass) NOT NULL,
    group_id bigint NOT NULL,
    tenant_id character varying(100) NOT NULL,
    party_id bigint NOT NULL,
    title_type_id bigint NOT NULL,
    title_type_perc numeric(11,8) NOT NULL,
    parcel_id bigint NOT NULL,
    sector_code character varying(255) NOT NULL,
    block_code character varying(255) NOT NULL,
    parcel_code character varying(255) NOT NULL,
    sub_parcel_code character varying(255),
    day_from character varying(8) NOT NULL,
    day_to character varying(8) NOT NULL,
    dt_insert timestamp without time zone NOT NULL,
    user_id_insert character varying(100) NOT NULL,
    dt_delete timestamp without time zone NOT NULL,
    user_id_delete character varying(100)
);


ALTER TABLE public.cll_land_link_detail OWNER TO cll;

--
-- Name: TABLE cll_land_link_detail; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON TABLE public.cll_land_link_detail IS 'land link details table';


--
-- Name: COLUMN cll_land_link_detail.id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.id IS 'The land link detail id- used as reference';


--
-- Name: COLUMN cll_land_link_detail.pkid; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.pkid IS 'The current land link detail id';


--
-- Name: COLUMN cll_land_link_detail.group_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.group_id IS 'The group id';


--
-- Name: COLUMN cll_land_link_detail.tenant_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.tenant_id IS 'The tenant id';


--
-- Name: COLUMN cll_land_link_detail.party_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.party_id IS 'The party id- retrieved from external service';


--
-- Name: COLUMN cll_land_link_detail.title_type_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.title_type_id IS 'The title type id';


--
-- Name: COLUMN cll_land_link_detail.title_type_perc; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.title_type_perc IS 'The title type percentage';


--
-- Name: COLUMN cll_land_link_detail.parcel_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.parcel_id IS 'The parcel id- retrieved from external service';


--
-- Name: COLUMN cll_land_link_detail.sector_code; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.sector_code IS 'The sector code- retrieved from external service';


--
-- Name: COLUMN cll_land_link_detail.block_code; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.block_code IS 'The block code- retrieved from external service';


--
-- Name: COLUMN cll_land_link_detail.parcel_code; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.parcel_code IS 'The parcel code- retrieved from external service';


--
-- Name: COLUMN cll_land_link_detail.sub_parcel_code; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.sub_parcel_code IS 'The sub parcel code- retrieved from external service';


--
-- Name: COLUMN cll_land_link_detail.day_from; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.day_from IS 'The start validity date - format YYYYMMDD';


--
-- Name: COLUMN cll_land_link_detail.day_to; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.day_to IS 'The end validity date - format YYYYMMDD';


--
-- Name: COLUMN cll_land_link_detail.dt_insert; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.dt_insert IS 'The database''s timestamp when this record was created';


--
-- Name: COLUMN cll_land_link_detail.user_id_insert; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.user_id_insert IS 'The user id which inserted this record';


--
-- Name: COLUMN cll_land_link_detail.dt_delete; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.dt_delete IS 'The database''s timestamp when this record was logically deleted';


--
-- Name: COLUMN cll_land_link_detail.user_id_delete; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_land_link_detail.user_id_delete IS 'The user id which logically deleted this record';


--
-- Name: cll_settings; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.cll_settings (
    pkid bigint NOT NULL,
    tenant_id character varying(100) NOT NULL,
    lpis_sub_separator character varying(100) NOT NULL,
    dt_insert timestamp without time zone NOT NULL,
    user_id_insert character varying(100) NOT NULL,
    dt_delete timestamp without time zone NOT NULL,
    user_id_delete character varying(100)
);


ALTER TABLE public.cll_settings OWNER TO cll;

--
-- Name: TABLE cll_settings; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON TABLE public.cll_settings IS 'settings table';


--
-- Name: COLUMN cll_settings.pkid; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_settings.pkid IS 'The setting id- primary key';


--
-- Name: COLUMN cll_settings.tenant_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_settings.tenant_id IS 'The tenant id';


--
-- Name: COLUMN cll_settings.lpis_sub_separator; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_settings.lpis_sub_separator IS 'The sub separator value- [used in lpis module]';


--
-- Name: COLUMN cll_settings.dt_insert; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_settings.dt_insert IS 'The database''s timestamp when this record was created';


--
-- Name: COLUMN cll_settings.user_id_insert; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_settings.user_id_insert IS 'The user id which inserted this record';


--
-- Name: COLUMN cll_settings.dt_delete; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_settings.dt_delete IS 'The database''s timestamp when this record was logically deleted';


--
-- Name: COLUMN cll_settings.user_id_delete; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_settings.user_id_delete IS 'The user id which logically deleted this record';


--
-- Name: cll_settings_pkid_seq; Type: SEQUENCE; Schema: public; Owner: cll
--

ALTER TABLE public.cll_settings ALTER COLUMN pkid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cll_settings_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cll_title_type; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.cll_title_type (
    id bigint NOT NULL,
    code character varying(255) NOT NULL,
    tenant_id character varying(100) NOT NULL,
    fl_day_to_req smallint NOT NULL,
    fl_day_to_editable smallint NOT NULL,
    dt_insert timestamp without time zone NOT NULL,
    user_id_insert character varying(100) NOT NULL,
    dt_delete timestamp without time zone NOT NULL,
    user_id_delete character varying(100),
    CONSTRAINT cll_title_type_ck1 CHECK ((fl_day_to_req = ANY (ARRAY[0, 1])))
);


ALTER TABLE public.cll_title_type OWNER TO cll;

--
-- Name: TABLE cll_title_type; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON TABLE public.cll_title_type IS 'title types table';


--
-- Name: COLUMN cll_title_type.id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_title_type.id IS 'The title type id- primary key';


--
-- Name: COLUMN cll_title_type.code; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_title_type.code IS 'The title type code';


--
-- Name: COLUMN cll_title_type.tenant_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_title_type.tenant_id IS 'The tenant id';


--
-- Name: COLUMN cll_title_type.fl_day_to_req; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_title_type.fl_day_to_req IS 'Flag used to define whether dayTo field (of land link) is required or not';


--
-- Name: COLUMN cll_title_type.fl_day_to_editable; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_title_type.fl_day_to_editable IS 'Flag used to define whether dayTo field (of land link) is editable or not';


--
-- Name: COLUMN cll_title_type.dt_insert; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_title_type.dt_insert IS 'The database''s timestamp when this record was created';


--
-- Name: COLUMN cll_title_type.user_id_insert; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_title_type.user_id_insert IS 'The user id which inserted this record';


--
-- Name: COLUMN cll_title_type.dt_delete; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_title_type.dt_delete IS 'The database''s timestamp when this record was logically deleted';


--
-- Name: COLUMN cll_title_type.user_id_delete; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.cll_title_type.user_id_delete IS 'The user id which logically deleted this record';


--
-- Name: cll_title_type_id_seq; Type: SEQUENCE; Schema: public; Owner: cll
--

ALTER TABLE public.cll_title_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cll_title_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO cll;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO cll;

--
-- Name: doc_document; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.doc_document (
    id bigint NOT NULL,
    doc_type_id bigint NOT NULL,
    tenant_id character varying(100) NOT NULL,
    business_id bigint,
    label character varying(100),
    user_insert character varying(100) NOT NULL,
    user_delete character varying(100),
    dt_insert timestamp without time zone NOT NULL,
    dt_delete timestamp without time zone NOT NULL
);


ALTER TABLE public.doc_document OWNER TO cll;

--
-- Name: doc_document_content; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.doc_document_content (
    id bigint NOT NULL,
    doc_document_id bigint NOT NULL,
    doc_type_spec_id bigint NOT NULL,
    parent_id bigint,
    doc_content jsonb NOT NULL,
    dt_start timestamp without time zone NOT NULL,
    dt_end timestamp without time zone NOT NULL,
    user_insert character varying(100) NOT NULL,
    user_delete character varying(100),
    dt_insert timestamp without time zone NOT NULL,
    dt_delete timestamp without time zone NOT NULL
);


ALTER TABLE public.doc_document_content OWNER TO cll;

--
-- Name: doc_document_content_id_seq; Type: SEQUENCE; Schema: public; Owner: cll
--

ALTER TABLE public.doc_document_content ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.doc_document_content_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: doc_document_id_seq; Type: SEQUENCE; Schema: public; Owner: cll
--

ALTER TABLE public.doc_document ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.doc_document_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: doc_type; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.doc_type (
    id bigint NOT NULL,
    code character varying(100) NOT NULL,
    tenant_id character varying(100) NOT NULL,
    user_insert character varying(100) NOT NULL,
    user_delete character varying(100),
    dt_insert timestamp without time zone NOT NULL,
    dt_delete timestamp without time zone NOT NULL
);


ALTER TABLE public.doc_type OWNER TO cll;

--
-- Name: doc_type_id_seq; Type: SEQUENCE; Schema: public; Owner: cll
--

ALTER TABLE public.doc_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.doc_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: doc_type_spec; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.doc_type_spec (
    id bigint NOT NULL,
    doc_type_id bigint NOT NULL,
    version character varying(100) NOT NULL,
    description character varying(100) NOT NULL,
    definition jsonb NOT NULL,
    parent_id bigint,
    user_insert character varying(100) NOT NULL,
    user_delete character varying(100),
    dt_insert timestamp without time zone NOT NULL,
    dt_delete timestamp without time zone NOT NULL
);


ALTER TABLE public.doc_type_spec OWNER TO cll;

--
-- Name: doc_type_spec_id_seq; Type: SEQUENCE; Schema: public; Owner: cll
--

ALTER TABLE public.doc_type_spec ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.doc_type_spec_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: equ_jobs; Type: TABLE; Schema: public; Owner: cll
--

CREATE TABLE public.equ_jobs (
    pkid bigint NOT NULL,
    queue_id character varying(20) NOT NULL,
    fl_status smallint NOT NULL,
    priority_order bigint NOT NULL,
    dt_lock timestamp without time zone,
    error_message text,
    payload text
);


ALTER TABLE public.equ_jobs OWNER TO cll;

--
-- Name: TABLE equ_jobs; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON TABLE public.equ_jobs IS 'Jobs in queue';


--
-- Name: COLUMN equ_jobs.pkid; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.equ_jobs.pkid IS 'The primary key';


--
-- Name: COLUMN equ_jobs.queue_id; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.equ_jobs.queue_id IS 'the queue for this job';


--
-- Name: COLUMN equ_jobs.fl_status; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.equ_jobs.fl_status IS 'the job status: 0 = waiting, 1=doing, 2=done, 8=to be rescheduled, 9=error';


--
-- Name: COLUMN equ_jobs.priority_order; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.equ_jobs.priority_order IS 'the priority order, smaller numbers are processed first';


--
-- Name: COLUMN equ_jobs.dt_lock; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.equ_jobs.dt_lock IS 'the job lock date (when the processing started)';


--
-- Name: COLUMN equ_jobs.error_message; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.equ_jobs.error_message IS 'The error message, if any exceptions was thrown during processing';


--
-- Name: COLUMN equ_jobs.payload; Type: COMMENT; Schema: public; Owner: cll
--

COMMENT ON COLUMN public.equ_jobs.payload IS 'the job payload, in json';


--
-- Name: equ_seq; Type: SEQUENCE; Schema: public; Owner: cll
--

CREATE SEQUENCE public.equ_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 20;


ALTER TABLE public.equ_seq OWNER TO cll;

--
-- Data for Name: bnd_lock; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.bnd_lock (locked) FROM stdin;
\.


--
-- Data for Name: bnd_registry; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.bnd_registry (tenant_id, changeset, md5, dt_insert) FROM stdin;
*	inner-cll-0001.zip	7561fd1815e8d30b8296d2e9fb41ce9f	2023-04-03 17:05:53.868418
*	cll-0001.zip	2c0f5122ed9223d69e958048f0f78890	2023-04-03 17:06:19.482958
*	cll-0002.zip	8d549707d77434b92e96d2d21ac44f23	2023-04-03 17:06:19.482958
\.


--
-- Data for Name: bnd_tenant; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.bnd_tenant (tenant_id, dt_insert) FROM stdin;
master	2023-04-03 17:06:24.152634
\.


--
-- Data for Name: cll_anomaly_categories; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.cll_anomaly_categories (tenant_id, group_code, code, level, fl_exclude) FROM stdin;
\.


--
-- Data for Name: cll_doc_type_relations; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.cll_doc_type_relations (pkid, tenant_id, title_type_id, definition_code, fl_required, fl_req_on_add, fl_req_on_close, dt_insert, user_id_insert, dt_delete, user_id_delete) FROM stdin;
1	*	1	DEF_1	1	1	0	2023-04-03 17:06:20.022673	system	9999-12-31 00:00:00	\N
2	*	2	DEF_2	0	0	0	2023-04-03 17:06:20.070617	system	9999-12-31 00:00:00	\N
3	*	3	DEF_3	1	1	0	2023-04-03 17:06:20.124091	system	9999-12-31 00:00:00	\N
4	*	1	DEF_3	1	1	0	2023-04-03 17:06:20.162703	system	9999-12-31 00:00:00	\N
5	*	4	DEF_2	1	1	0	2023-04-03 17:06:20.20649	system	9999-12-31 00:00:00	\N
6	*	5	DEF_2	1	1	0	2023-04-03 17:06:20.24377	system	9999-12-31 00:00:00	\N
7	master	6	DEF_2	0	0	0	2023-04-03 17:06:24.184283	system	9999-12-31 00:00:00	\N
8	master	7	DEF_2	1	1	0	2023-04-03 17:06:24.184283	system	9999-12-31 00:00:00	\N
9	master	8	DEF_3	1	1	0	2023-04-03 17:06:24.184283	system	9999-12-31 00:00:00	\N
10	master	9	DEF_1	1	1	0	2023-04-03 17:06:24.184283	system	9999-12-31 00:00:00	\N
11	master	9	DEF_3	1	1	0	2023-04-03 17:06:24.184283	system	9999-12-31 00:00:00	\N
12	master	10	DEF_2	1	1	0	2023-04-03 17:06:24.184283	system	9999-12-31 00:00:00	\N
\.


--
-- Data for Name: cll_group; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.cll_group (id, tenant_id, party_id, title_type_id) FROM stdin;
1	master	32	9
\.


--
-- Data for Name: cll_group_detail; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.cll_group_detail (pkid, group_id, descr, dt_insert, user_id_insert, dt_delete, user_id_delete) FROM stdin;
1	1	fasfsdf	2023-04-03 17:07:08.814466	ADMIN	9999-12-31 00:00:00	\N
\.


--
-- Data for Name: cll_group_documents; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.cll_group_documents (pkid, group_id, definition_code, document_id, dt_insert, user_id_insert, dt_delete, user_id_delete) FROM stdin;
\.


--
-- Data for Name: cll_i18n_values; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.cll_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text) FROM stdin;
*	cll_title_type	code	ALTRA_FORMA	it	ALTRA FORMA
*	cll_title_type	code	MEZZADRIA	it	MEZZADRIA
*	cll_title_type	code	AFFITTO	it	AFFITTO
*	cll_title_type	code	PROPRIETA	en	PROPRIETA
*	cll_title_type	code	PROPRIETA	it	PROPRIETA
*	cll_title_type	code	USO_CIVICO	it	USO CIVICO
*	cll_title_type	code	USO_CIVICO	en	USO CIVICO
*	cll_title_type	code	ALTRA_FORMA	en	ALTRA FORMA
*	cll_title_type	code	MEZZADRIA	en	MEZZADRIA
*	cll_title_type	code	AFFITTO	en	AFFITTO
*	cll_doc_type_relations	definition_code	DEF_1	en	def_one
*	cll_doc_type_relations	definition_code	DEF_1	it	def_uno
*	cll_doc_type_relations	definition_code	DEF_2	en	def_two
*	cll_doc_type_relations	definition_code	DEF_2	it	def_due
*	cll_doc_type_relations	definition_code	DEF_3	it	def_tree
*	cll_doc_type_relations	definition_code	DEF_3	en	def_three
master	cll_doc_type_relations	definition_code	DEF_1	en	def_one
master	cll_doc_type_relations	definition_code	DEF_1	it	def_uno
master	cll_doc_type_relations	definition_code	DEF_2	en	def_two
master	cll_doc_type_relations	definition_code	DEF_2	it	def_due
master	cll_doc_type_relations	definition_code	DEF_3	en	def_three
master	cll_doc_type_relations	definition_code	DEF_3	it	def_tree
master	cll_title_type	code	AFFITTO	en	AFFITTO
master	cll_title_type	code	AFFITTO	it	AFFITTO
master	cll_title_type	code	ALTRA_FORMA	en	ALTRA FORMA
master	cll_title_type	code	ALTRA_FORMA	it	ALTRA FORMA
master	cll_title_type	code	MEZZADRIA	en	MEZZADRIA
master	cll_title_type	code	MEZZADRIA	it	MEZZADRIA
master	cll_title_type	code	PROPRIETA	en	PROPRIETA
master	cll_title_type	code	PROPRIETA	it	PROPRIETA
master	cll_title_type	code	USO_CIVICO	en	USO CIVICO
master	cll_title_type	code	USO_CIVICO	it	USO CIVICO
\.


--
-- Data for Name: cll_land_link_detail; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.cll_land_link_detail (id, pkid, group_id, tenant_id, party_id, title_type_id, title_type_perc, parcel_id, sector_code, block_code, parcel_code, sub_parcel_code, day_from, day_to, dt_insert, user_id_insert, dt_delete, user_id_delete) FROM stdin;
1	1	1	master	32	9	100.00000000	1154286	A061	1	00005	\N	20230403	99991231	2023-04-03 17:07:08.948734	ADMIN	2023-04-04 11:42:17.586729	ADMIN
1	3	1	master	32	9	100.00000000	1154286	A061	1	00005	\N	20230403	20230404	2023-04-04 11:42:18.586729	ADMIN	9999-12-31 00:00:00	\N
2	2	1	master	32	9	100.00000000	1154289	A061	1	00006	\N	20230403	99991231	2023-04-03 17:07:08.948734	ADMIN	2023-04-04 11:42:17.658986	ADMIN
2	4	1	master	32	9	100.00000000	1154289	A061	1	00006	\N	20230403	20230404	2023-04-04 11:42:18.658986	ADMIN	9999-12-31 00:00:00	\N
\.


--
-- Data for Name: cll_settings; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.cll_settings (pkid, tenant_id, lpis_sub_separator, dt_insert, user_id_insert, dt_delete, user_id_delete) FROM stdin;
1	*	/	2023-04-03 17:05:54.117089	system	2023-04-03 17:06:19.396787	system
2	*	/	2023-04-03 17:06:20.396787	system	9999-12-31 00:00:00	\N
3	master	/	2023-04-03 17:06:24.493351	system	9999-12-31 00:00:00	\N
\.


--
-- Data for Name: cll_title_type; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.cll_title_type (id, code, tenant_id, fl_day_to_req, dt_insert, user_id_insert, dt_delete, user_id_delete) FROM stdin;
1	PROPRIETA	*	0	2023-04-03 17:06:19.591827	system	9999-12-31 00:00:00	\N
2	AFFITTO	*	1	2023-04-03 17:06:19.591827	system	9999-12-31 00:00:00	\N
3	MEZZADRIA	*	1	2023-04-03 17:06:19.591827	system	9999-12-31 00:00:00	\N
4	ALTRA_FORMA	*	1	2023-04-03 17:06:19.591827	system	9999-12-31 00:00:00	\N
5	USO_CIVICO	*	1	2023-04-03 17:06:19.591827	system	9999-12-31 00:00:00	\N
6	AFFITTO	master	1	2023-04-03 17:06:24.164578	system	9999-12-31 00:00:00	\N
7	ALTRA_FORMA	master	1	2023-04-03 17:06:24.164578	system	9999-12-31 00:00:00	\N
8	MEZZADRIA	master	1	2023-04-03 17:06:24.164578	system	9999-12-31 00:00:00	\N
9	PROPRIETA	master	0	2023-04-03 17:06:24.164578	system	9999-12-31 00:00:00	\N
10	USO_CIVICO	master	1	2023-04-03 17:06:24.164578	system	9999-12-31 00:00:00	\N
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
1651668515065-1	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.295647	1	EXECUTED	8:0756dbddeb60415cfe9427a6db9039cf	createTable tableName=doc_type		\N	4.19.0	\N	\N	0534337736
1651668515065-2	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.327141	2	EXECUTED	8:d3d53d7d32be2cc9962c4cd906c3761e	createTable tableName=doc_type_spec		\N	4.19.0	\N	\N	0534337736
1651668515065-3	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.356059	3	EXECUTED	8:399aa346cc94fd24ed9140dcdd1f8be4	createTable tableName=doc_document		\N	4.19.0	\N	\N	0534337736
1651668515065-4	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.388984	4	EXECUTED	8:045910503c530dcd064cb54139f187a7	createTable tableName=doc_document_content		\N	4.19.0	\N	\N	0534337736
1651668515065-5	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.408832	5	EXECUTED	8:2afcca233ad6fc82198d34a01e2d6dca	addUniqueConstraint constraintName=doc_type_uk1, tableName=doc_type		\N	4.19.0	\N	\N	0534337736
1651668515065-6	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.426738	6	EXECUTED	8:c8f4f8b492ce6c4e8e8caba4b4ec3f0e	createIndex indexName=doc_type_spec_idx_01, tableName=doc_type_spec		\N	4.19.0	\N	\N	0534337736
1651668515065-7	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.444376	7	EXECUTED	8:ef6d6ed1d6640109825fe2436ab7c559	createIndex indexName=doc_type_spec_idx_02, tableName=doc_type_spec		\N	4.19.0	\N	\N	0534337736
1651668515065-8	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.463075	8	EXECUTED	8:e9177e64ce51c93fa1ec75a600063096	createIndex indexName=doc_document_idx_01, tableName=doc_document		\N	4.19.0	\N	\N	0534337736
1651668515065-9	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.481559	9	EXECUTED	8:4d6d01766faa1171847adbe3f63403ef	createIndex indexName=doc_document_idx_02, tableName=doc_document		\N	4.19.0	\N	\N	0534337736
1651668515065-10	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.5082	10	EXECUTED	8:02ca7cd6e100d3b24e312c0713fb5a4d	createIndex indexName=doc_document_content_idx_01, tableName=doc_document_content		\N	4.19.0	\N	\N	0534337736
1651668515065-11	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.535467	11	EXECUTED	8:d0405294eed6bda52dc0cfaf18b4a8f0	createIndex indexName=doc_document_content_idx_02, tableName=doc_document_content		\N	4.19.0	\N	\N	0534337736
1651668515065-12	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.565173	12	EXECUTED	8:a95c9e75d8f1f80bbbd5b964593177dd	createIndex indexName=doc_document_content_idx_03, tableName=doc_document_content		\N	4.19.0	\N	\N	0534337736
1651668515065-13	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.594126	13	EXECUTED	8:828ace8df9bec6dbbf80efcf9ad977aa	addForeignKeyConstraint baseTableName=doc_document_content, constraintName=doc_document_content_fk_01, referencedTableName=doc_document		\N	4.19.0	\N	\N	0534337736
1651668515065-14	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.617366	14	EXECUTED	8:cc3ecf616fb05697f3fa36a24c7d62b7	addForeignKeyConstraint baseTableName=doc_document_content, constraintName=doc_document_content_fk_02, referencedTableName=doc_type_spec		\N	4.19.0	\N	\N	0534337736
1651668515065-15	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.635837	15	EXECUTED	8:d30e078b394afa899c4266a703e240de	addForeignKeyConstraint baseTableName=doc_document_content, constraintName=doc_document_content_fk_03, referencedTableName=doc_document_content		\N	4.19.0	\N	\N	0534337736
1651668515065-16	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.648943	16	EXECUTED	8:efda57a02d0c25a3beee3b091d762a87	addForeignKeyConstraint baseTableName=doc_document, constraintName=doc_document_fk1, referencedTableName=doc_type		\N	4.19.0	\N	\N	0534337736
1651668515065-17	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.661598	17	EXECUTED	8:b755cf83ed66eb5685be8af5a8cd90e8	addForeignKeyConstraint baseTableName=doc_type_spec, constraintName=doc_revision_fk_01, referencedTableName=doc_type		\N	4.19.0	\N	\N	0534337736
1651668515065-18	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.673476	18	EXECUTED	8:e0507570e62718c1dcc1c3cbb4de8752	addForeignKeyConstraint baseTableName=doc_type_spec, constraintName=doc_revision_fk_02, referencedTableName=doc_type_spec		\N	4.19.0	\N	\N	0534337736
1651668515065-19	n.manzatti (generated)	dynamic-documents-migrations/all-migrations.xml	2023-04-03 17:05:38.693574	19	EXECUTED	8:19931532d649599ee5afa751964196ef	dropUniqueConstraint constraintName=doc_type_uk1, tableName=doc_type; addUniqueConstraint constraintName=doc_type_uk1, tableName=doc_type		\N	4.19.0	\N	\N	0534337736
1866564501508-1	rahma	bundles-migrations/all-migrations.xml	2023-04-03 17:05:38.710886	20	EXECUTED	8:f445ed07a2985d7760d0b065cc345a2a	createTable tableName=bnd_lock		\N	4.19.0	\N	\N	0534337736
1866564501508-2	rahma	bundles-migrations/all-migrations.xml	2023-04-03 17:05:38.743003	21	EXECUTED	8:e5e029c03b858ade46f45edb9306cb1c	createTable tableName=bnd_registry		\N	4.19.0	\N	\N	0534337736
1866564501508-3	abaco	bundles-migrations/all-migrations.xml	2023-04-03 17:05:38.768788	22	EXECUTED	8:0cc57c425ed59db6168a8563b245e180	addPrimaryKey constraintName=locked_pk, tableName=bnd_lock		\N	4.19.0	\N	\N	0534337736
002-1	abaco	bundles-migrations/migration-002-bnd-tenant-table.xml	2023-04-03 17:05:38.798625	23	EXECUTED	8:ff5372f9393ccad1b0ef9963451ba0bb	createTable tableName=bnd_tenant		\N	4.19.0	\N	\N	0534337736
migration-003-bnd_registry-pk-01	abaco	bundles-migrations/migration-003-bnd_registry-pk.xml	2023-04-03 17:05:38.821446	24	EXECUTED	8:2d32c476b5647d99873e0f7f243cd967	dropPrimaryKey constraintName=bnd_registry_pk, tableName=bnd_registry; addPrimaryKey tableName=bnd_registry		\N	4.19.0	\N	\N	0534337736
embedded-queue-00001	ABACO	migrations-embedded-queue/00001_embedded_queue.xml	2023-04-03 17:05:38.877408	25	EXECUTED	8:dbee1fe40ce8aeaa63bc241f44636ee5	createSequence sequenceName=equ_seq; createTable tableName=equ_jobs; createIndex indexName=equ_jobs_ix1, tableName=equ_jobs		\N	4.19.0	\N	\N	0534337736
embedded-queue-00002	ABACO	migrations-embedded-queue/00002_embedded_queue.xml	2023-04-03 17:05:38.903913	26	EXECUTED	8:a79817e0cc94156db3734c592b894297	dropIndex indexName=equ_jobs_ix1, tableName=equ_jobs; createIndex indexName=equ_jobs_ix1, tableName=equ_jobs		\N	4.19.0	\N	\N	0534337736
001-1	abaco	migrations/001_init.xml	2023-04-03 17:05:38.94457	27	EXECUTED	8:4d69665c8e682a38c76a6f1fac782b28	createTable tableName=cll_i18n_values		\N	4.19.0	\N	\N	0534337736
001-2	abaco	migrations/001_init.xml	2023-04-03 17:05:38.985663	28	EXECUTED	8:f0ad329f35d73fbd451b1e50ba253c40	createTable tableName=cll_title_type		\N	4.19.0	\N	\N	0534337736
001-3	abaco	migrations/001_init.xml	2023-04-03 17:05:39.014174	29	EXECUTED	8:a99c7e92efa1533ca590e6668d528b54	addUniqueConstraint constraintName=cll_title_type_uk1, tableName=cll_title_type		\N	4.19.0	\N	\N	0534337736
001-4	abaco	migrations/001_init.xml	2023-04-03 17:05:39.046141	30	EXECUTED	8:16373f5ca2b05551e98a40de32e28d75	sql		\N	4.19.0	\N	\N	0534337736
001-5	abaco	migrations/001_init.xml	2023-04-03 17:05:39.066788	31	EXECUTED	8:e324c587996a79251685e4cb9a32b18a	createTable tableName=cll_doc_type_relations		\N	4.19.0	\N	\N	0534337736
001-7	abaco	migrations/001_init.xml	2023-04-03 17:05:39.080167	32	EXECUTED	8:dc114fb09e810068859dab1b27ec4232	addForeignKeyConstraint baseTableName=cll_doc_type_relations, constraintName=cll_dd_title_type_cfg_fk2, referencedTableName=cll_title_type		\N	4.19.0	\N	\N	0534337736
001-8	abaco	migrations/001_init.xml	2023-04-03 17:05:39.103852	33	EXECUTED	8:b831f9640467e3d9307eaaae8993519b	sql; sql; sql		\N	4.19.0	\N	\N	0534337736
001-9	abaco	migrations/001_init.xml	2023-04-03 17:05:39.134369	34	EXECUTED	8:c2356bd6e7bc9e1b4e845f9ab599a3d3	addUniqueConstraint constraintName=cll_doc_type_relations_uk1, tableName=cll_doc_type_relations		\N	4.19.0	\N	\N	0534337736
001-10	abaco	migrations/001_init.xml	2023-04-03 17:05:39.169518	35	EXECUTED	8:c052ef0b0528a3d766da4a1e0b0d2b92	createSequence sequenceName=cll_group_detail_pkid_seq		\N	4.19.0	\N	\N	0534337736
001-11	abaco	migrations/001_init.xml	2023-04-03 17:05:39.225829	36	EXECUTED	8:ddf168c353e90174380822fbb7c00714	createTable tableName=cll_group		\N	4.19.0	\N	\N	0534337736
001-12	abaco	migrations/001_init.xml	2023-04-03 17:05:39.247912	37	EXECUTED	8:e803fe10b38504718a4d9fc275ce7e90	createTable tableName=cll_group_detail		\N	4.19.0	\N	\N	0534337736
001-13	abaco	migrations/001_init.xml	2023-04-03 17:05:39.275842	38	EXECUTED	8:ac0b5da9a1eba7e64295aff8ee39f1e1	addForeignKeyConstraint baseTableName=cll_group, constraintName=cll_group_fk1, referencedTableName=cll_title_type		\N	4.19.0	\N	\N	0534337736
001-14	abaco	migrations/001_init.xml	2023-04-03 17:05:39.291647	39	EXECUTED	8:d3cc1668b8e6dae71342090139b35b64	addForeignKeyConstraint baseTableName=cll_group_detail, constraintName=cll_group_detail_fk1, referencedTableName=cll_group		\N	4.19.0	\N	\N	0534337736
001-15	abaco	migrations/001_init.xml	2023-04-03 17:05:39.349914	40	EXECUTED	8:757b607200f1fdd7116b4d23370182b5	addUniqueConstraint constraintName=cll_group_detail_uk1, tableName=cll_group_detail		\N	4.19.0	\N	\N	0534337736
001-16	abaco	migrations/001_init.xml	2023-04-03 17:05:39.380232	41	EXECUTED	8:eef7daf048758214d8a48d72349e32a6	createSequence sequenceName=cll_land_link_detail_pkid_seq		\N	4.19.0	\N	\N	0534337736
001-17	abaco	migrations/001_init.xml	2023-04-03 17:05:39.422924	42	EXECUTED	8:f18206cb974e58d1c57e8c35188c23ba	createTable tableName=cll_land_link_detail		\N	4.19.0	\N	\N	0534337736
001-18	abaco	migrations/001_init.xml	2023-04-03 17:05:39.446179	43	EXECUTED	8:09c5c6aaa9830ff4c7a20ee0337cfde7	addForeignKeyConstraint baseTableName=cll_land_link_detail, constraintName=cll_land_link_detail_fk1, referencedTableName=cll_title_type		\N	4.19.0	\N	\N	0534337736
001-19	abaco	migrations/001_init.xml	2023-04-03 17:05:39.463313	44	EXECUTED	8:bc6d50054632c01b4e1b50327400b65e	addForeignKeyConstraint baseTableName=cll_land_link_detail, constraintName=cll_land_link_detail_fk2, referencedTableName=cll_group		\N	4.19.0	\N	\N	0534337736
001-20	abaco	migrations/001_init.xml	2023-04-03 17:05:39.486523	45	EXECUTED	8:4bfd914085b4ae68da0cf081cfaae571	createTable tableName=cll_group_documents		\N	4.19.0	\N	\N	0534337736
001-21	abaco	migrations/001_init.xml	2023-04-03 17:05:39.503209	46	EXECUTED	8:300b74d5a8d04bf033b482571c674280	addUniqueConstraint constraintName=cll_group_documents_uk1, tableName=cll_group_documents		\N	4.19.0	\N	\N	0534337736
001-22	abaco	migrations/001_init.xml	2023-04-03 17:05:39.522575	47	EXECUTED	8:f782d8577b34736057a3a1b4246d3fde	addForeignKeyConstraint baseTableName=cll_group_documents, constraintName=cll_group_documents_fk1, referencedTableName=cll_group		\N	4.19.0	\N	\N	0534337736
001-23	abaco	migrations/001_init.xml	2023-04-03 17:05:39.551405	48	EXECUTED	8:b58851ac575346e1b37508ce7df04046	createTable tableName=cll_settings		\N	4.19.0	\N	\N	0534337736
001-24	abaco	migrations/001_init.xml	2023-04-03 17:05:39.578322	49	EXECUTED	8:bcc54d1a73ea3de0be1aafd6ecc9c85a	addUniqueConstraint constraintName=cll_settings_uk1, tableName=cll_settings		\N	4.19.0	\N	\N	0534337736
002-1	abaco	migrations/002_update_descr_column.xml	2023-04-03 17:05:39.598052	50	EXECUTED	8:6e7a88580a44527e6b8783876dc81dcf	dropNotNullConstraint columnName=descr, tableName=cll_group_detail		\N	4.19.0	\N	\N	0534337736
003-01	ABACO	migrations/003_anomaly_categories.xml	2023-04-03 17:05:39.630023	51	EXECUTED	8:1debea2b8a69f24b14eb66b846c783f2	createTable tableName=cll_anomaly_categories		\N	4.19.0	\N	\N	0534337736
003-02	abaco	migrations/003_anomaly_categories.xml	2023-04-03 17:05:39.644357	52	EXECUTED	8:5017a1ba9774273f8cc2f6416ff67d45	sql		\N	4.19.0	\N	\N	0534337736
003-03	abaco	migrations/003_anomaly_categories.xml	2023-04-03 17:05:39.660271	53	EXECUTED	8:cd084ccd1470a09cf316541a8c278f0f	addPrimaryKey constraintName=cll_anomaly_categories_pk, tableName=cll_anomaly_categories		\N	4.19.0	\N	\N	0534337736
004-01	abaco	migrations/004_add_db_comments.xml	2023-04-03 17:05:39.68873	54	EXECUTED	8:dedae7a75dbe1a5cba49ee3bc5194c8b	setTableRemarks tableName=cll_title_type; setColumnRemarks columnName=id, tableName=cll_title_type; setColumnRemarks columnName=code, tableName=cll_title_type; setColumnRemarks columnName=tenant_id, tableName=cll_title_type; setColumnRemarks colum...		\N	4.19.0	\N	\N	0534337736
004-02	abaco	migrations/004_add_db_comments.xml	2023-04-03 17:05:39.720975	55	EXECUTED	8:aa2ab55686a757dc2630223b0b565740	setTableRemarks tableName=cll_i18n_values; setColumnRemarks columnName=tenant_id, tableName=cll_i18n_values; setColumnRemarks columnName=table_name, tableName=cll_i18n_values; setColumnRemarks columnName=field_name, tableName=cll_i18n_values; setC...		\N	4.19.0	\N	\N	0534337736
004-03	abaco	migrations/004_add_db_comments.xml	2023-04-03 17:05:39.78605	56	EXECUTED	8:0c0c99ed3b2a82a6433eaa00faf9533c	setTableRemarks tableName=cll_doc_type_relations; setColumnRemarks columnName=pkid, tableName=cll_doc_type_relations; setColumnRemarks columnName=title_type_id, tableName=cll_doc_type_relations; setColumnRemarks columnName=tenant_id, tableName=cll...		\N	4.19.0	\N	\N	0534337736
004-04	abaco	migrations/004_add_db_comments.xml	2023-04-03 17:05:39.819614	57	EXECUTED	8:d4f4c70b09b8f144dda2a711614f9e72	setTableRemarks tableName=cll_group; setColumnRemarks columnName=id, tableName=cll_group; setColumnRemarks columnName=tenant_id, tableName=cll_group; setColumnRemarks columnName=party_id, tableName=cll_group; setColumnRemarks columnName=title_type...		\N	4.19.0	\N	\N	0534337736
004-05	abaco	migrations/004_add_db_comments.xml	2023-04-03 17:05:39.848967	58	EXECUTED	8:1d1348a792a53dd62869f87d58d206a5	setTableRemarks tableName=cll_group_detail; setColumnRemarks columnName=pkid, tableName=cll_group_detail; setColumnRemarks columnName=group_id, tableName=cll_group_detail; setColumnRemarks columnName=descr, tableName=cll_group_detail; setColumnRem...		\N	4.19.0	\N	\N	0534337736
004-06	abaco	migrations/004_add_db_comments.xml	2023-04-03 17:05:39.885044	59	EXECUTED	8:3f5715f4d8325953ba923800485c44f7	setTableRemarks tableName=cll_land_link_detail; setColumnRemarks columnName=pkid, tableName=cll_land_link_detail; setColumnRemarks columnName=id, tableName=cll_land_link_detail; setColumnRemarks columnName=group_id, tableName=cll_land_link_detail;...		\N	4.19.0	\N	\N	0534337736
004-07	abaco	migrations/004_add_db_comments.xml	2023-04-03 17:05:39.907791	60	EXECUTED	8:03878f251aedf160d602c9c516d607b1	setTableRemarks tableName=cll_group_documents; setColumnRemarks columnName=pkid, tableName=cll_group_documents; setColumnRemarks columnName=group_id, tableName=cll_group_documents; setColumnRemarks columnName=definition_code, tableName=cll_group_d...		\N	4.19.0	\N	\N	0534337736
004-08	abaco	migrations/004_add_db_comments.xml	2023-04-03 17:05:39.951747	61	EXECUTED	8:dde40ff5e77655e903029ec3d4c91556	setTableRemarks tableName=cll_settings; setColumnRemarks columnName=pkid, tableName=cll_settings; setColumnRemarks columnName=tenant_id, tableName=cll_settings; setColumnRemarks columnName=lpis_sub_separator, tableName=cll_settings; setColumnRemar...		\N	4.19.0	\N	\N	0534337736
005-01	abaco	migrations/005_add_indexes.xml	2023-04-03 17:05:39.984479	62	EXECUTED	8:cc07c9eb6502ba57e36b29cdb28bf60a	createIndex indexName=cll_group_idx1, tableName=cll_group		\N	4.19.0	\N	\N	0534337736
005-02	abaco	migrations/005_add_indexes.xml	2023-04-03 17:05:40.01438	63	EXECUTED	8:6079ce730bfa018cbc5e407500930547	createIndex indexName=cll_group_documents_idx1, tableName=cll_group_documents		\N	4.19.0	\N	\N	0534337736
005-03	abaco	migrations/005_add_indexes.xml	2023-04-03 17:05:40.03745	64	EXECUTED	8:75b02a298e9230ca2c6c93cf459ce91e	createIndex indexName=cll_land_link_detail_idx1, tableName=cll_land_link_detail		\N	4.19.0	\N	\N	0534337736
005-04	abaco	migrations/005_add_indexes.xml	2023-04-03 17:05:40.058833	65	EXECUTED	8:5876b91f088a5d6877b5274d6009f6c8	createIndex indexName=cll_land_link_detail_unique_index1, tableName=cll_land_link_detail		\N	4.19.0	\N	\N	0534337736
005-05	abaco	migrations/005_add_indexes.xml	2023-04-03 17:05:40.07562	66	EXECUTED	8:c3f9470029fd36e41661245a06066b9f	createIndex indexName=cll_land_link_detail_idx2, tableName=cll_land_link_detail		\N	4.19.0	\N	\N	0534337736
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
\.


--
-- Data for Name: doc_document; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.doc_document (id, doc_type_id, tenant_id, business_id, label, user_insert, user_delete, dt_insert, dt_delete) FROM stdin;
\.


--
-- Data for Name: doc_document_content; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.doc_document_content (id, doc_document_id, doc_type_spec_id, parent_id, doc_content, dt_start, dt_end, user_insert, user_delete, dt_insert, dt_delete) FROM stdin;
\.


--
-- Data for Name: doc_type; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.doc_type (id, code, tenant_id, user_insert, user_delete, dt_insert, dt_delete) FROM stdin;
1	DEF_1	*	system	\N	2023-04-03 17:06:19.814712	9999-12-30 23:00:00
2	DEF_2	*	system	\N	2023-04-03 17:06:19.895805	9999-12-30 23:00:00
3	DEF_3	*	system	\N	2023-04-03 17:06:19.935875	9999-12-30 23:00:00
4	DEF_1	master	system	\N	2023-04-03 17:06:24.313276	9999-12-30 23:00:00
5	DEF_2	master	system	\N	2023-04-03 17:06:24.404881	9999-12-30 23:00:00
6	DEF_3	master	system	\N	2023-04-03 17:06:24.461661	9999-12-30 23:00:00
\.


--
-- Data for Name: doc_type_spec; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.doc_type_spec (id, doc_type_id, version, description, definition, parent_id, user_insert, user_delete, dt_insert, dt_delete) FROM stdin;
1	1	1	Dati1	{"code": "DEF_1", "title": {"en": "def_one", "it": "def_uno"}, "lookups": [{"code": "id_type_lookup", "entries": [{"code": "id_occupancy", "label": {"en": "Certificate of Occupancy", "it": "Certificato di occupazione"}}, {"code": "id_plan", "label": {"en": "Survey Plan", "it": "Piano di indagine"}}, {"code": "id_assignment", "label": {"en": "Deed of Assignment", "it": "Atto di assegnazione"}}]}, {"code": "code_lookup", "entries": [{"code": "cp", "label": {"en": "Copy", "it": "Copia"}}, {"code": "cert", "label": {"en": "Certificate", "it": "Certificato"}}]}], "version": "1", "metadata": {"maxOccurs": 1, "timeOverlap": true, "endDateField": "valid_to", "defaultLocale": "it", "summaryFields": ["id_type", "code", "valid_from", "valid_to"], "startDateField": "valid_from"}, "fieldSets": [{"code": "Fieldset 1", "label": {"en": "Data1", "it": "Dati1"}, "fields": [{"code": "id_type", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "string", "label": {"en": "document type", "it": "tipo documento"}, "style": "radio", "required": true, "lookupCode": "id_type_lookup", "validation": null}, {"code": "code", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "string", "label": {"en": "document code", "it": "codice documento"}, "style": "radio", "required": true, "lookupCode": "code_lookup", "validation": null}, {"code": "release_agent", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "string", "label": {"en": "released by", "it": "rilasciato da"}, "style": null, "required": true, "lookupCode": null, "validation": null}, {"code": "valid_from", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "date", "label": {"en": "valid from", "it": "valido da"}, "style": null, "required": true, "lookupCode": null, "validation": null}, {"code": "valid_to", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "date", "label": {"en": "valid to", "it": "valido a"}, "style": null, "required": true, "lookupCode": null, "validation": null}], "maxOccurs": 1, "minOccurs": 1}, {"code": "Files", "label": {"en": "Files", "it": "Allegati"}, "fields": [{"code": "file", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "file", "label": {"en": "file", "it": "allegato"}, "style": "radio", "required": false, "lookupCode": null, "validation": null}], "maxOccurs": 999, "minOccurs": 1}], "description": "Dati1", "restLookups": null}	\N	system	\N	2023-04-03 17:06:19.814712	9999-12-30 23:00:00
2	2	1	Dati2	{"code": "DEF_2", "title": {"en": "def_two", "it": "def_due"}, "lookups": null, "version": "1", "metadata": {"maxOccurs": 1, "timeOverlap": true, "endDateField": null, "defaultLocale": "it", "summaryFields": ["id_type", "release_agent", "release_date"], "startDateField": null}, "fieldSets": [{"code": "Dati anagrafici", "label": {"en": "Personal data", "it": "Dati anagrafici"}, "fields": [{"code": "id_type", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "string", "label": {"en": "document type", "it": "tipo documento"}, "style": "radio", "required": true, "lookupCode": null, "validation": null}, {"code": "release_agent", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "string", "label": {"en": "released by", "it": "rilasciato da"}, "style": null, "required": true, "lookupCode": null, "validation": null}, {"code": "release_date", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "date", "label": {"en": "release date", "it": "data rilascio"}, "style": null, "required": true, "lookupCode": null, "validation": null}], "maxOccurs": 999, "minOccurs": 1}], "description": "Dati2", "restLookups": null}	\N	system	\N	2023-04-03 17:06:19.895805	9999-12-30 23:00:00
3	3	1	Dati3	{"code": "DEF_3", "title": {"en": "def_three", "it": "def_tree"}, "lookups": null, "version": "1", "metadata": {"maxOccurs": 1, "timeOverlap": true, "endDateField": "valid_to", "defaultLocale": "it", "summaryFields": ["id_type", "release_agent", "valid_from", "valid_to"], "startDateField": "valid_from"}, "fieldSets": [{"code": "Fieldset 1", "label": {"en": "Data3", "it": "Dati3"}, "fields": [{"code": "id_type", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "string", "label": {"en": "Type", "it": "Tipo"}, "style": "radio", "required": true, "lookupCode": null, "validation": null}, {"code": "release_agent", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "string", "label": {"en": "released by", "it": "rilasciato da"}, "style": null, "required": true, "lookupCode": null, "validation": null}, {"code": "valid_from", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "date", "label": {"en": "valid from", "it": "valido da"}, "style": null, "required": true, "lookupCode": null, "validation": null}, {"code": "valid_to", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "date", "label": {"en": "valid to", "it": "valido a"}, "style": null, "required": true, "lookupCode": null, "validation": null}], "maxOccurs": 1, "minOccurs": 1}, {"code": "Files", "label": {"en": "Files", "it": "Allegati"}, "fields": [{"code": "file", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "file", "label": {"en": "file", "it": "allegato"}, "style": "radio", "required": false, "lookupCode": null, "validation": null}], "maxOccurs": 999, "minOccurs": 1}], "description": "Dati3", "restLookups": null}	\N	system	\N	2023-04-03 17:06:19.935875	9999-12-30 23:00:00
4	4	1	Dati1	{"code": "DEF_1", "title": {"en": "def_one", "it": "def_uno"}, "lookups": [{"code": "id_type_lookup", "entries": [{"code": "id_occupancy", "label": {"en": "Certificate of Occupancy", "it": "Certificato di occupazione"}}, {"code": "id_plan", "label": {"en": "Survey Plan", "it": "Piano di indagine"}}, {"code": "id_assignment", "label": {"en": "Deed of Assignment", "it": "Atto di assegnazione"}}]}, {"code": "code_lookup", "entries": [{"code": "cp", "label": {"en": "Copy", "it": "Copia"}}, {"code": "cert", "label": {"en": "Certificate", "it": "Certificato"}}]}], "version": "1", "metadata": {"maxOccurs": 1, "timeOverlap": true, "endDateField": "valid_to", "defaultLocale": "it", "summaryFields": ["id_type", "code", "valid_from", "valid_to"], "startDateField": "valid_from"}, "fieldSets": [{"code": "Fieldset 1", "label": {"en": "Data1", "it": "Dati1"}, "fields": [{"code": "id_type", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "string", "label": {"en": "document type", "it": "tipo documento"}, "style": "radio", "required": true, "lookupCode": "id_type_lookup", "validation": null}, {"code": "code", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "string", "label": {"en": "document code", "it": "codice documento"}, "style": "radio", "required": true, "lookupCode": "code_lookup", "validation": null}, {"code": "release_agent", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "string", "label": {"en": "released by", "it": "rilasciato da"}, "style": null, "required": true, "lookupCode": null, "validation": null}, {"code": "valid_from", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "date", "label": {"en": "valid from", "it": "valido da"}, "style": null, "required": true, "lookupCode": null, "validation": null}, {"code": "valid_to", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "date", "label": {"en": "valid to", "it": "valido a"}, "style": null, "required": true, "lookupCode": null, "validation": null}], "maxOccurs": 1, "minOccurs": 1}, {"code": "Files", "label": {"en": "Files", "it": "Allegati"}, "fields": [{"code": "file", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "file", "label": {"en": "file", "it": "allegato"}, "style": "radio", "required": false, "lookupCode": null, "validation": null}], "maxOccurs": 999, "minOccurs": 1}], "description": "Dati1", "restLookups": null}	\N	system	\N	2023-04-03 17:06:24.313276	9999-12-30 23:00:00
5	5	1	Dati2	{"code": "DEF_2", "title": {"en": "def_two", "it": "def_due"}, "lookups": null, "version": "1", "metadata": {"maxOccurs": 1, "timeOverlap": true, "endDateField": null, "defaultLocale": "it", "summaryFields": ["id_type", "release_agent", "release_date"], "startDateField": null}, "fieldSets": [{"code": "Dati anagrafici", "label": {"en": "Personal data", "it": "Dati anagrafici"}, "fields": [{"code": "id_type", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "string", "label": {"en": "document type", "it": "tipo documento"}, "style": "radio", "required": true, "lookupCode": null, "validation": null}, {"code": "release_agent", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "string", "label": {"en": "released by", "it": "rilasciato da"}, "style": null, "required": true, "lookupCode": null, "validation": null}, {"code": "release_date", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "date", "label": {"en": "release date", "it": "data rilascio"}, "style": null, "required": true, "lookupCode": null, "validation": null}], "maxOccurs": 999, "minOccurs": 1}], "description": "Dati2", "restLookups": null}	\N	system	\N	2023-04-03 17:06:24.404881	9999-12-30 23:00:00
6	6	1	Dati3	{"code": "DEF_3", "title": {"en": "def_three", "it": "def_tree"}, "lookups": null, "version": "1", "metadata": {"maxOccurs": 1, "timeOverlap": true, "endDateField": "valid_to", "defaultLocale": "it", "summaryFields": ["id_type", "release_agent", "valid_from", "valid_to"], "startDateField": "valid_from"}, "fieldSets": [{"code": "Fieldset 1", "label": {"en": "Data3", "it": "Dati3"}, "fields": [{"code": "id_type", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "string", "label": {"en": "Type", "it": "Tipo"}, "style": "radio", "required": true, "lookupCode": null, "validation": null}, {"code": "release_agent", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "string", "label": {"en": "released by", "it": "rilasciato da"}, "style": null, "required": true, "lookupCode": null, "validation": null}, {"code": "valid_from", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "date", "label": {"en": "valid from", "it": "valido da"}, "style": null, "required": true, "lookupCode": null, "validation": null}, {"code": "valid_to", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "date", "label": {"en": "valid to", "it": "valido a"}, "style": null, "required": true, "lookupCode": null, "validation": null}], "maxOccurs": 1, "minOccurs": 1}, {"code": "Files", "label": {"en": "Files", "it": "Allegati"}, "fields": [{"code": "file", "help": [{"title": {"en": "", "it": ""}, "content": {"en": "", "it": ""}}], "type": "file", "label": {"en": "file", "it": "allegato"}, "style": "radio", "required": false, "lookupCode": null, "validation": null}], "maxOccurs": 999, "minOccurs": 1}], "description": "Dati3", "restLookups": null}	\N	system	\N	2023-04-03 17:06:24.461661	9999-12-30 23:00:00
\.


--
-- Data for Name: equ_jobs; Type: TABLE DATA; Schema: public; Owner: cll
--

COPY public.equ_jobs (pkid, queue_id, fl_status, priority_order, dt_lock, error_message, payload) FROM stdin;
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: geocode_settings; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM stdin;
\.


--
-- Data for Name: pagc_gaz; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_lex; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_rules; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_rules (id, rule, is_custom) FROM stdin;
\.


--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.topology (id, name, srid, "precision", hasz) FROM stdin;
\.


--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.


--
-- Name: cll_doc_type_relations_pkid_seq; Type: SEQUENCE SET; Schema: public; Owner: cll
--

SELECT pg_catalog.setval('public.cll_doc_type_relations_pkid_seq', 12, true);


--
-- Name: cll_group_detail_pkid_seq; Type: SEQUENCE SET; Schema: public; Owner: cll
--

SELECT pg_catalog.setval('public.cll_group_detail_pkid_seq', 4, true);


--
-- Name: cll_group_documents_pkid_seq; Type: SEQUENCE SET; Schema: public; Owner: cll
--

SELECT pg_catalog.setval('public.cll_group_documents_pkid_seq', 1, false);


--
-- Name: cll_land_link_detail_pkid_seq; Type: SEQUENCE SET; Schema: public; Owner: cll
--

SELECT pg_catalog.setval('public.cll_land_link_detail_pkid_seq', 13, true);


--
-- Name: cll_settings_pkid_seq; Type: SEQUENCE SET; Schema: public; Owner: cll
--

SELECT pg_catalog.setval('public.cll_settings_pkid_seq', 3, true);


--
-- Name: cll_title_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cll
--

SELECT pg_catalog.setval('public.cll_title_type_id_seq', 10, true);


--
-- Name: doc_document_content_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cll
--

SELECT pg_catalog.setval('public.doc_document_content_id_seq', 1, false);


--
-- Name: doc_document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cll
--

SELECT pg_catalog.setval('public.doc_document_id_seq', 1, false);


--
-- Name: doc_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cll
--

SELECT pg_catalog.setval('public.doc_type_id_seq', 6, true);


--
-- Name: doc_type_spec_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cll
--

SELECT pg_catalog.setval('public.doc_type_spec_id_seq', 6, true);


--
-- Name: equ_seq; Type: SEQUENCE SET; Schema: public; Owner: cll
--

SELECT pg_catalog.setval('public.equ_seq', 40, true);


--
-- Name: bnd_registry bnd_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.bnd_registry
    ADD CONSTRAINT bnd_registry_pkey PRIMARY KEY (tenant_id, changeset);


--
-- Name: bnd_tenant bnd_tenant_pk; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.bnd_tenant
    ADD CONSTRAINT bnd_tenant_pk PRIMARY KEY (tenant_id);


--
-- Name: cll_anomaly_categories cll_anomaly_categories_pk; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_anomaly_categories
    ADD CONSTRAINT cll_anomaly_categories_pk PRIMARY KEY (tenant_id, group_code, code);


--
-- Name: cll_doc_type_relations cll_doc_type_relations_pk; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_doc_type_relations
    ADD CONSTRAINT cll_doc_type_relations_pk PRIMARY KEY (pkid);


--
-- Name: cll_doc_type_relations cll_doc_type_relations_uk1; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_doc_type_relations
    ADD CONSTRAINT cll_doc_type_relations_uk1 UNIQUE (tenant_id, title_type_id, definition_code, dt_delete);


--
-- Name: cll_group_detail cll_group_detail_pk; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_group_detail
    ADD CONSTRAINT cll_group_detail_pk PRIMARY KEY (pkid);


--
-- Name: cll_group_detail cll_group_detail_uk1; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_group_detail
    ADD CONSTRAINT cll_group_detail_uk1 UNIQUE (group_id, dt_delete);


--
-- Name: cll_group_documents cll_group_documents_pk; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_group_documents
    ADD CONSTRAINT cll_group_documents_pk PRIMARY KEY (pkid);


--
-- Name: cll_group_documents cll_group_documents_uk1; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_group_documents
    ADD CONSTRAINT cll_group_documents_uk1 UNIQUE (document_id, dt_delete);


--
-- Name: cll_group cll_group_pk; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_group
    ADD CONSTRAINT cll_group_pk PRIMARY KEY (id);


--
-- Name: cll_i18n_values cll_i18n_values_pk; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_i18n_values
    ADD CONSTRAINT cll_i18n_values_pk PRIMARY KEY (tenant_id, table_name, field_name, i18n_value, lang);


--
-- Name: cll_land_link_detail cll_land_link_detail_pk; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_land_link_detail
    ADD CONSTRAINT cll_land_link_detail_pk PRIMARY KEY (pkid);


--
-- Name: cll_settings cll_settings_pk; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_settings
    ADD CONSTRAINT cll_settings_pk PRIMARY KEY (pkid);


--
-- Name: cll_settings cll_settings_uk1; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_settings
    ADD CONSTRAINT cll_settings_uk1 UNIQUE (tenant_id, dt_delete);


--
-- Name: cll_title_type cll_title_type_pk; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_title_type
    ADD CONSTRAINT cll_title_type_pk PRIMARY KEY (id);


--
-- Name: cll_title_type cll_title_type_uk1; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_title_type
    ADD CONSTRAINT cll_title_type_uk1 UNIQUE (tenant_id, code, dt_delete);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: doc_document_content doc_document_content_pkey; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.doc_document_content
    ADD CONSTRAINT doc_document_content_pkey PRIMARY KEY (id);


--
-- Name: doc_document doc_document_pkey; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.doc_document
    ADD CONSTRAINT doc_document_pkey PRIMARY KEY (id);


--
-- Name: doc_type doc_type_pkey; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.doc_type
    ADD CONSTRAINT doc_type_pkey PRIMARY KEY (id);


--
-- Name: doc_type_spec doc_type_spec_pkey; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.doc_type_spec
    ADD CONSTRAINT doc_type_spec_pkey PRIMARY KEY (id);


--
-- Name: doc_type doc_type_uk1; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.doc_type
    ADD CONSTRAINT doc_type_uk1 UNIQUE (tenant_id, code);


--
-- Name: equ_jobs equ_jobs_pk; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.equ_jobs
    ADD CONSTRAINT equ_jobs_pk PRIMARY KEY (pkid);


--
-- Name: bnd_lock locked_pk; Type: CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.bnd_lock
    ADD CONSTRAINT locked_pk PRIMARY KEY (locked);


--
-- Name: cll_group_documents_idx1; Type: INDEX; Schema: public; Owner: cll
--

CREATE INDEX cll_group_documents_idx1 ON public.cll_group_documents USING btree (group_id);


--
-- Name: cll_group_idx1; Type: INDEX; Schema: public; Owner: cll
--

CREATE INDEX cll_group_idx1 ON public.cll_group USING btree (tenant_id, party_id);


--
-- Name: cll_land_link_detail_idx1; Type: INDEX; Schema: public; Owner: cll
--

CREATE INDEX cll_land_link_detail_idx1 ON public.cll_land_link_detail USING btree (group_id);


--
-- Name: cll_land_link_detail_idx2; Type: INDEX; Schema: public; Owner: cll
--

CREATE INDEX cll_land_link_detail_idx2 ON public.cll_land_link_detail USING btree (tenant_id, parcel_id, party_id);


--
-- Name: cll_land_link_detail_unique_index1; Type: INDEX; Schema: public; Owner: cll
--

CREATE UNIQUE INDEX cll_land_link_detail_unique_index1 ON public.cll_land_link_detail USING btree (tenant_id, party_id, parcel_id, title_type_id, dt_delete);


--
-- Name: doc_document_content_idx_01; Type: INDEX; Schema: public; Owner: cll
--

CREATE INDEX doc_document_content_idx_01 ON public.doc_document_content USING btree (doc_document_id);


--
-- Name: doc_document_content_idx_02; Type: INDEX; Schema: public; Owner: cll
--

CREATE INDEX doc_document_content_idx_02 ON public.doc_document_content USING btree (doc_type_spec_id);


--
-- Name: doc_document_content_idx_03; Type: INDEX; Schema: public; Owner: cll
--

CREATE UNIQUE INDEX doc_document_content_idx_03 ON public.doc_document_content USING btree (parent_id);


--
-- Name: doc_document_idx_01; Type: INDEX; Schema: public; Owner: cll
--

CREATE INDEX doc_document_idx_01 ON public.doc_document USING btree (doc_type_id);


--
-- Name: doc_document_idx_02; Type: INDEX; Schema: public; Owner: cll
--

CREATE INDEX doc_document_idx_02 ON public.doc_document USING btree (business_id);


--
-- Name: doc_type_spec_idx_01; Type: INDEX; Schema: public; Owner: cll
--

CREATE INDEX doc_type_spec_idx_01 ON public.doc_type_spec USING btree (doc_type_id);


--
-- Name: doc_type_spec_idx_02; Type: INDEX; Schema: public; Owner: cll
--

CREATE UNIQUE INDEX doc_type_spec_idx_02 ON public.doc_type_spec USING btree (parent_id);


--
-- Name: equ_jobs_ix1; Type: INDEX; Schema: public; Owner: cll
--

CREATE INDEX equ_jobs_ix1 ON public.equ_jobs USING btree (queue_id, priority_order);


--
-- Name: cll_doc_type_relations cll_dd_title_type_cfg_fk2; Type: FK CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_doc_type_relations
    ADD CONSTRAINT cll_dd_title_type_cfg_fk2 FOREIGN KEY (title_type_id) REFERENCES public.cll_title_type(id);


--
-- Name: cll_group_detail cll_group_detail_fk1; Type: FK CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_group_detail
    ADD CONSTRAINT cll_group_detail_fk1 FOREIGN KEY (group_id) REFERENCES public.cll_group(id);


--
-- Name: cll_group_documents cll_group_documents_fk1; Type: FK CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_group_documents
    ADD CONSTRAINT cll_group_documents_fk1 FOREIGN KEY (group_id) REFERENCES public.cll_group(id);


--
-- Name: cll_group cll_group_fk1; Type: FK CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_group
    ADD CONSTRAINT cll_group_fk1 FOREIGN KEY (title_type_id) REFERENCES public.cll_title_type(id);


--
-- Name: cll_land_link_detail cll_land_link_detail_fk1; Type: FK CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_land_link_detail
    ADD CONSTRAINT cll_land_link_detail_fk1 FOREIGN KEY (title_type_id) REFERENCES public.cll_title_type(id);


--
-- Name: cll_land_link_detail cll_land_link_detail_fk2; Type: FK CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.cll_land_link_detail
    ADD CONSTRAINT cll_land_link_detail_fk2 FOREIGN KEY (group_id) REFERENCES public.cll_group(id);


--
-- Name: doc_document_content doc_document_content_fk_01; Type: FK CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.doc_document_content
    ADD CONSTRAINT doc_document_content_fk_01 FOREIGN KEY (doc_document_id) REFERENCES public.doc_document(id);


--
-- Name: doc_document_content doc_document_content_fk_02; Type: FK CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.doc_document_content
    ADD CONSTRAINT doc_document_content_fk_02 FOREIGN KEY (doc_type_spec_id) REFERENCES public.doc_type_spec(id);


--
-- Name: doc_document_content doc_document_content_fk_03; Type: FK CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.doc_document_content
    ADD CONSTRAINT doc_document_content_fk_03 FOREIGN KEY (parent_id) REFERENCES public.doc_document_content(id);


--
-- Name: doc_document doc_document_fk1; Type: FK CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.doc_document
    ADD CONSTRAINT doc_document_fk1 FOREIGN KEY (doc_type_id) REFERENCES public.doc_type(id);


--
-- Name: doc_type_spec doc_revision_fk_01; Type: FK CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.doc_type_spec
    ADD CONSTRAINT doc_revision_fk_01 FOREIGN KEY (doc_type_id) REFERENCES public.doc_type(id);


--
-- Name: doc_type_spec doc_revision_fk_02; Type: FK CONSTRAINT; Schema: public; Owner: cll
--

ALTER TABLE ONLY public.doc_type_spec
    ADD CONSTRAINT doc_revision_fk_02 FOREIGN KEY (parent_id) REFERENCES public.doc_type_spec(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA public TO cll;


--
-- PostgreSQL database dump complete
--

