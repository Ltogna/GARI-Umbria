import java.sql.Connection;
import java.sql.DriverManager;

import liquibase.Liquibase;
import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.resource.ClassLoaderResourceAccessor;

Connection cnn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/cll_test", "postgres", "postgres");
JdbcConnection conn = new JdbcConnection(cnn);
Database database = DatabaseFactory.getInstance().findCorrectDatabaseImplementation(conn);

try (Liquibase liquibase = new Liquibase("migrations.xml", new ClassLoaderResourceAccessor(), database)) {
	String ctx = null;
	liquibase.update(ctx);
}
