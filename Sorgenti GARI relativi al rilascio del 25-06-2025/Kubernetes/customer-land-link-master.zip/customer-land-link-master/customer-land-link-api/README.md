# Customer Land Link Api

[TOC]

## How to start the Customer Land Link Api application

1. Run `mvn clean install` to build your application
1. execute migrations with `java -jar target/customer-land-link-api-{version}.jar db migrate config.yml`
1. Start application with `java -jar target/customer-land-link-api-{version}.jar server config.yml`
1. To check that your application is running enter url `http://localhost:{port}/customer-land-link`


### OpenAPI

[openapi.yaml](doc/openapi.yaml)

[openapi.json from local server](`http://localhost:{port}/customer-land-link/openapi.json`)   
[swagger per testare l'output](https://editor-next.swagger.io/)

## Bundles Infrastructure integration

The application must be connected to a RabbitMQ instance.

The bundles infrastructure will automatically set up to allow automatic configuration.

The application module id is `customer-land-link-api` and the supported changeset domains are:

```
📂 customer-land-link-api
┗━📂 <client-id>-<nnnnn>
  ┣━📂 anomaly-categories
  ┃ ┣━📜 <any file>.jsonl
  ┃ ┗━📜 <.*>delete<.*>.jsonl
  ┣━📂 dynamic_documents
  ┃ ┣━📜 <any file>.json
  ┃ ┣━📜 settings<.*>.json
  ┃ ┗━📜 settings<.*>delete<.*>.json
  ┗━📂 title_types
    ┣━📜 <any file>.json
    ┗━📜 <.*>delete<.*>.json

```

### anomaly-categories

The anomaly categories JSONL file(s) is used for insert/update `cll_anomaly_categories` table and must have the following structure:
```
{"groupCcode": "String (mandatory)", "code": "String (mandatory)" ,"level": "AnomalyLevelEnum (mandatory)", "exclude": "boolean"}
...
```
The anomaly categories JSONL file(s) that contains "delete" in its name is used for delete `cll_anomaly_categories` entries and must have the following structure:
```
{"groupCode": "String (mandatory)", "code": "String (mandatory)"}
...
```

`Anomaly categories values`:

- `groupCode`: code group of anomaly categories
- `code`: code of anomaly categories
- `level`: level of anomaly, allowable values: `DANGER`, `WARN`, `INFO`
- `exclude`: flag for exclude a category, default is false


### dynamic_documents

The `dynamic_documents` file(s) are used to insert/update dynamic document schemas.  
JSON file(s) must have the following structure:

#### dynamic doc definitions

(see dynamic document documentation)

#### settings

The application handles `dynamic documents` (abbr: _DD_)

A sample configuration can be found at `bundles-iacs-italia/standard/customer-land-link-api/cll-0001/dynamic_documents`

The system will assume as definition file **any** `json` in the directory except those whose names begin with `settings` (e.g.: _settings_01.json_)

When loading a `DD` definition the i18n labels of the DD will be automatically created.

The settings file is used to define the usage of the _DD_ on the portal.   
An example of a settings file:

```json
[
  {
    "definitionCode": "DEF_1",
    "required": true,
    "reqOnAdd": true,
    "reqOnClose": true,
    "titleType": "PROPRIETA",
    "scopeCode": "GROUPS"
  },
  {
    "definitionCode": "DEF_2",
    "required": false,
    "reqOnAdd": false,
    "reqOnClose": false,
    "titleType": "AFFITTO",
    "scopeCode": "GROUPS"
  },
  {
    "definitionCode": "DEF_3",
    "required": true,
    "reqOnAdd": true,
    "reqOnClose": false,
    "titleType": "PROPRIETA",
    "scopeCode": "LANDLINKS"
  }
]
```

For each titleType, there is a list of dynamic documents that has to be associated.

The presence of at least one associated dynamic document to a specific titleType
must have a specific configuration that defines their obligatory nature in general (required),
and also their obligatory nature when making these operations (OnAdd / OnClose).

The configuration of a specific dynamic document type (definitionCode) changes throughout the associated titleType.
For each type of DD (definitionCode) you have to specify:

- the `titleType` to be associated to the dynamic document type, can be null (if null the the dynamic document type is associated to all the title types).
- the `required` represents the obligatory nature of defining a DD of this type(definitionCode) when using this particular TitleType.
- the `reqOnAdd` represents the obligatory nature of defining a DD of this type(definitionCode) in order to add a new land link with that titleType.
- the `reqOnClose`represents the obligatory nature of defining a DD of this type(definitionCode) in order to close a land link with that titleType.
- the `scopeCode` rappresents the scope of the DD of this type(definitionCode), allowed values are 'GROUPS'(default) and 'LANDLINKS'.

In the example above, **PROPRIETA** titleType is associated to two types of dynamic documents ( DEF_1 and DEF_3),
**DEF_1** is required on add and close while **DEF_2** is required just on add.

#### delete settings

`dynamic_documents` files starting with `settings` and containing `delete` in the name (ex. 'settings_0001.delete.json') are used to delete settings related to
the specific DDType (definitionCode) and titleType.
The DDs will no longer be visualised by the FE but remain in the db and can be reactivated by a new settings file. JSON file(s) must
have the following structure:

```json
[
  {
    "definitionCode": "DEF_1",
    "titleType": "OWNERSHIP"
    // definitionCode and titleType are mandatory
    //they define the docType relation to remove
  }
  //[...]
]
```

### title types

The `title_types` file(s) are used to insert titleType and their translations.  
JSON file(s) must have the following structure:

```json
[
  {
    "code": "PROPRIETA",
    "dayToRequired": false,
    "dayToEditable": false,
    "allowFutureDayFrom": false,
    "description": {
      "it": "PROPRIETA",
      "en": "PROPRIETA"
    }
  },
  {
    "code": "AFFITTO",
    "dayToRequired": true,
    "dayToEditable": true,
    "allowFutureDayFrom": false,
    "description": {
      "it": "AFFITTO",
      "en": "AFFITTO"
    }
  }
]
```

- `code`: titleType code
- `dayToRequired`:  the obligatory nature of setting an endDate when defining a new linkLand of this titleType.
- `dayToEditable`:  if true the endDate of a new linkLand of this titleType is editable.
- `allowFutureDayFrom`:  if true future day from of a new linkLand of this titleType is allowed.
- `description`: map < iso lang code - translation >
