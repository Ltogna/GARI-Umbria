# MIGRATIONS

## Instructions TODO first changelog

Execute the command

`mvn liquibase:generateChangeLog`

a file named as configured in **outputChangeLogFile** (file _liquibase.properties_) will be generated.  
Use it to configure first changelog.

## Configure liquibase.properties

The file **liquibase/liquibase.properties** must be configured in the following properties:

* url : must contains the url of the current database (generated with the current migrations of Liquibase)
* referenceUrl: must contains the url of the most updated database (generated with the current JPA configuration)
* diffChangeLogFile : the output file of the diff command

## Execute liquibase diff command

The command to make the database comparison is:

`mvn liquibase:diff`

## Extract the changelogs

At the end, the file configured in **diffChangeLogFile** will contain the migration changelogs.  
Use them to populate a new migration file

