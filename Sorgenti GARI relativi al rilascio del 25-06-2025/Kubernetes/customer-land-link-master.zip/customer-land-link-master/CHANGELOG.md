# Changelog

### [v4.4.9](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.4.8...v4.4.9) (2025-03-12)

### Fixes

* :bug: fixed landlink ids issue LandLinkEventProducer, closes [#164057](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/issues/164057) [#140298](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/issues/140298)

### [v4.4.8](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.4.7...v4.4.8) (2025-03-05)

### Features
* :sparkles: added search for titleTypeCode

### Other
* :arrow_up: upgrade dropwizard version to v4.0.12
* :heavy_plus_sign: added tracing-utils dependency

### [v4.4.7](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.4.6...v4.4.7) (2025-02-19)

### Features
* :sparkles: added new public api to get group documents, closes [#162066](https://abacogroup.easyredmine.com/issues/162066)

### Other
* :heavy_plus_sign: added dynamic-documents dependency to cll-cli


### [v4.4.6](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.4.5...v4.4.6) (2024-11-25)

### Fixes
* :bug: fix sso olive variant auto bundle name
* :bug: fix sso fruit variant auto bundle name


### [v4.4.5](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.4.4...v4.4.5) (2024-10-29) Multi Variant

### Other
* :green_heart: reconfigure CI for multi variant, closes [#150730](https://abacogroup.easyredmine.com/issues/150730) [#150732](https://abacogroup.easyredmine.com/issues/150732)


### [v4.4.4](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.4.3...v4.4.4) (2024-08-25) 

### Fixes
* :bug: fix sonar agea issues

### [v4.4.3](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.4.2...v4.4.3) (2024-08-24) 

### Features
* feat (Land Link) add anomalies mapping to response

### Fixes
* :bug: fix little issue in rabbitmq payload load when searching for empty lists

### [v4.4.2](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.4.1...v4.4.2) (2024-08-09) Fix over conduction

### Features
* implement fix LandLink Properties over conductions, closes [#148185](https://abacogroup.easyredmine.com/issues/148185)


### [v4.4.1](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.4.0...v4.4.1) (2024-07-16)
### Fixes
* :bug: fixed NullPointerException in AnomalyHelper


## [v4.4.0](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.3.4...v4.4.0) (2024-07-16) manage same parcel in group
### Features
* :sparkles: implement logic to manage same parcel in group, closes [#143551](https://abacogroup.easyredmine.com/issues/143551)


### [v4.3.4](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.3.3...v4.3.4) (2024-06-21) include geometries

### Features
* **lpis:** :sparkles: implement include geometries for public parcels api, closes [#143139](https://abacogroup.easyredmine.com/issues/143139)

### Other
* **pom:** enable incremental compilation for mapstruct in eclipse


### [v4.3.3](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.3.2...v4.3.3) (2024-06-11) optional holder data in history

### Features
* **history:** :sparkles: add load_holders query param to history api, closes [#142329](https://abacogroup.easyredmine.com/issues/142329) [#142339](https://abacogroup.easyredmine.com/issues/142339)

### Fixes
* :bug: fixed some validation dates logic in GroupService and LandLinkService, closes [#141156](https://abacogroup.easyredmine.com/issues/141156)


### [v4.3.2](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.3.1...v4.3.2) (2024-05-28) Fix Rabbit messages

### Fixes
* :bug: fixed bug in LandLinkEventProducer, closes [#140298](https://abacogroup.easyredmine.com/issues/140298)


### [v4.3.1](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.3.0...v4.3.1 (2024-05-27)

### Fixes
* **titleType:** :bug: fix issue in title type bundle import, closes [#136342](https://abacogroup.easyredmine.com/issues/136342)


## [v4.3.0](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.2.0...v4.3.0) (2024-05-24) Land link dynamic documents and zero conduction

### Features
* :sparkles: implement dynamic documents for land links, closes [#139065](https://abacogroup.easyredmine.com/issues/139065), [#140435](https://abacogroup.easyredmine.com/issues/140435)
* :adhesive_bandage: made group id optional in search DocTypeRelation
* :sparkles: allow zero conduction perc, closes [#138999](https://abacogroup.easyredmine.com/issues/138999)

### Other
* :see_no_evil: update gitignore

### Documentation
* :memo: sample bundle for landlink document config definition, closes [#139065](https://abacogroup.easyredmine.com/issues/139065)


## [v4.2.0](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.20...v4.2.0) (2024-05-17)

### Features
* :sparkles: implement new API for logically delete a landlink or a group, closes [#138997](https://abacogroup.easyredmine.com/issues/138997)
* :sparkles: implement new API for landlinks history with ACL data retrieval, closes [#138998](https://abacogroup.easyredmine.com/issues/138998)
  * :beers: As requested call the partiesACL bypassing user filters for mandates, closes [#138998](https://abacogroup.easyredmine.com/issues/138998)
* :sparkles: implement permit, by configuration, landlink start date in future, closes [#139066](https://abacogroup.easyredmine.com/issues/139066)
* :memo: references on: [#139063](https://abacogroup.easyredmine.com/issues/139063)


### [v4.1.20](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.19...v4.1.20) (2024-05-10) fix bundle load

### Fixes
* **titleType:** :bug: fix issue in title type bundle import, closes [#136342](https://abacogroup.easyredmine.com/issues/136342)


### [v4.1.19](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.18...v4.1.19) (2024-05-07) A new way to end a date

### Features
* **titleType:** :sparkles: implement day to editable flag and logic for titleType, closes [#136342](https://abacogroup.easyredmine.com/issues/136342)

### Fixes
* :bug: fixed some queries
* :bug: fixed some landLink queries, closes [#137417](https://abacogroup.easyredmine.com/issues/137417)

### Other
* :recycle: little refactor


### [v4.1.18](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.17...v4.1.18) (2024-04-11) Parcels anomalies search fix

### Fixes
* **anomalies:** :bug: fix issue in anomalies search, closes [#136501](https://abacogroup.easyredmine.com/issues/136501)


### [v4.1.17](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.16...v4.1.17) (2024-03-26)

### Refactor
* Refactor for appscan agea issues

### [v4.1.16](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.15...v4.1.16) (2024-03-19) not so anomal

### Fixes
* **anomalies:** :bug: fix issue in parcels anomalies search


### [v4.1.15](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.14...v4.1.15) (2024-03-15)

### Fixes
* :bug: get lpis data for outdated parcels too, closes [#132941](https://abacogroup.easyredmine.com/issues/132941)


### [v4.1.14](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.13...v4.1.14) (2024-03-14)

### Fixes
* :bug: fix party mapper

### [v4.1.13](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.12...v4.1.13) (2024-03-13)

### Refactor
* Refactor for sonar agea issues

### [v4.1.12](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.11...v4.1.12) (2024-03-13) no GIS and no mandates

### Features

* **settings:** :sparkles: set ADD_TEMP_PARCELS_IF_NOT_EXISTS deafult search level setting, closes [#132941](https://abacogroup.easyredmine.com/issues/132941)
* :sparkles: added search level filter in parcel search, closes [#132941](https://abacogroup.easyredmine.com/issues/132941)
* :sparkles: new api to get blocks by sector code, closes [#133656](https://abacogroup.easyredmine.com/issues/133656)

### Fixes
* **partyClient:** :bug: fix error in party client response conversion, closes [#133705](https://abacogroup.easyredmine.com/issues/133705)

### Documentation
* :memo: add deafult value in description for parcel search level param


### [v4.1.11](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.10...v4.1.11) (2024-02-29) Update dynamic documents

### Other
* :arrow_up: Updated dynamic documents to 5.1.2

### [v4.1.10](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.9...v4.1.10) (2024-02-29)

### Other
* :arrow_up: Updated dynamic documents to 5.1.1


### [v4.1.9](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.8...v4.1.9) (2024-02-22) public parcels serach

### Features
* :sparkles: added new public api to search parcel by partyId and sector code list
* **public:** :sparkles: implement search business for sector and sector list, closes [#130351](https://abacogroup.easyredmine.com/issues/130351)
* **cli:** :sparkles: add search parties for sector payload in cli, closes [#130351](https://abacogroup.easyredmine.com/issues/130351)

### Documentation
* :memo: update openapi


### [v4.1.8](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.7...v4.1.8) (2024-02-14) vine variant to test

### Other
* :green_heart: add automatic release on tag
* :green_heart: add vine link variant deploy on iacs test environment


### [v4.1.7](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.6...v4.1.7) (2024-01-22)

### Fixes
* changed logic in referenceDate for lpis parcels search, closes [#128747](https://abacogroup.easyredmine.com/issues/128747)



### [v4.1.6](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.5...v4.1.6) (2024-01-17) Service release

### Fixes
* :bug: fix set PARTY_URL on deployment.yaml of customer-vine-link

### [v4.1.5](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.4...v4.1.5) (2024-01-17) Service release

### [v4.1.4](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.3...v4.1.4) (2024-01-17) Service release

### [v4.1.3](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.2...v4.1.3) (2024-01-17) Service release


### [v4.1.2](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.1...v4.1.2) (2023-12-22)

### Features
* :sparkles: added public api to get conductions history by parcel id


### [v4.1.1](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v4.1.0...v4.1.1) (2023-12-20)

### Features
* :sparkles: added public version of getLandLinkAnomalies, closes [#126599](https://abacogroup.easyredmine.com/issues/126599)

### Fixes
* **rabbit:** :bug: fix rabbitmq cll event payload
* **sso:** :bug: fix context name for vine variant

### Other
* :heavy_plus_sign: added anomaly-registry-cli dependency in customer-land-link-cli pom
* :construction_worker: configure lpis url for vine variant
* :wrench: dynamically configure contextPath based on variant



### [v4.1.0](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v0.0.7...v4.1.0) (2023-12-01)

### Features
* :sparkles: added public api Create Groups
* :sparkles: upgrade to DropWizard v4
* :sparkles: Configured "variant" variable to enable the server to run with alias for multiple instance in same namespace

### Fixes
* :recycle: fixed issue in rabbitmq exchange




## [v0.0.7](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v0.0.6...v0.0.7) (2023-09-28)

### Features
* **public-api:** :sparkles: new public leading for parcel api (V1)

## [v0.0.6](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v0.0.5...v0.0.6) (2023-09-13)

### Features
* **public-api:** :wastebasket: deprecate public parcels api
* **public-api:** :sparkles: new public land link api (V1)
* **sdk:** :sparkles: new public land link res (V1)

### Fixes
* **anomalies:** :bug: fix issue with null date in anomalies search
* set timeouts for jersey client in configuration

### Other
* :arrow_up: upgrade pom dependencies
* :recycle: code refactor

### [v0.0.5](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v0.0.4...v0.0.5) (2023-07-18)

### [v0.0.4](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v0.0.3...v0.0.4) (2023-06-12)

### [v0.0.3](https://gitlab.fe.abacogroup.eu/new-agri/customer-land-link/compare/v0.0.2...v0.0.3) (2023-06-12)

### v0.0.2 (2023-05-24)
