package com.abacogroup.cllcli.api.v1;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partyregistry.api.v1.PartyResponseV1;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.jdbi.v3.core.mapper.Nested;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class LandLinkLeadingResV1 {

	private Long id;

	@Nested("group_detail")
	private GroupBaseResponseV1 group;

	private Long partyId;
	@Nested("party_detail")
	private PartyResponseV1 party;

	@Nested("title")
	private TitleTypeReponseV1 titleType;

	@Default
	private BigDecimal titleTypePerc = BigDecimal.valueOf(100);

	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;

}
