package com.abacogroup.cllcli.api.v1;

import org.jdbi.v3.core.mapper.reflect.ColumnName;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class TitleTypeReponseV1 {

	private Long id;

	private String code;

	@JsonIgnore
	private int flDayToReq;
	
	@JsonIgnore
	private int flDayToEditable;
	
	@JsonIgnore
	private int flAllowFutureDayFrom;

	@ColumnName("fl_day_to_req")
	private boolean dayToReq;
	
	@ColumnName("fl_day_to_editable")
	private boolean dayToEditable;
	
	@ColumnName("fl_allow_future_day_from")
	private boolean allowFutureDayFrom;

	private String i18nCode;

}
