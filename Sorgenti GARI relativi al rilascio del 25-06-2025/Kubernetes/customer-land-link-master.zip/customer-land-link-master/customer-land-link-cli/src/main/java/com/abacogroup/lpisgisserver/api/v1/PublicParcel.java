package com.abacogroup.lpisgisserver.api.v1;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.locationtech.jts.geom.Geometry;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class PublicParcel {
	private Long id;

	private String parcel;

	private AbsoluteDate dayFrom;

	private AbsoluteDate dayTo;

	private String srs;

	private Long areaSqm;

	private Geometry geom;

	private Geometry worldGeom;

	private PublicParcelBlock block;

	private PublicParcelSector sector;

	private List<PublicLandCover> landcoversList;
}
