package com.abacogroup.lpisgisserver.api.v1;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.locationtech.jts.geom.Geometry;

@Data
@NoArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class PublicLandCover {
	private Long id;

	private String code;

	private String description;

	private Long parcelId;

	private AbsoluteDate dayFrom;

	private AbsoluteDate dayTo;

	private String srs;

	private Long areaSqm;

	private Geometry geom;

	private Geometry worldGeom;
}
