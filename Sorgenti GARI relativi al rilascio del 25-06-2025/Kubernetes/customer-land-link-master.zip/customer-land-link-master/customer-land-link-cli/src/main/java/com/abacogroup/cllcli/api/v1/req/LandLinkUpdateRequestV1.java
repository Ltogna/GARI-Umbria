package com.abacogroup.cllcli.api.v1.req;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class LandLinkUpdateRequestV1 {

	@NotNull
	@DecimalMax("100.00")
	@DecimalMin("0.00")
	@Schema(multipleOf = 0.00000001)
	private BigDecimal titleTypePerc;

}
