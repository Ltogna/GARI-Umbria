package com.abacogroup.cllcli.api.v1;

import java.util.LinkedHashMap;
import java.util.List;

import com.abacogroup.dynamicdocuments.bean.SummaryFieldDefinition;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
public class DocumentResponseV1 {

	private String definitionCode;
	private Long documentId;

	private String bucketName;

	private List<SummaryFieldDefinition> summaryFieldDefinitions;
	private LinkedHashMap<String, Object> data;

}