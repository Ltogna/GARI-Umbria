package com.abacogroup.cllcli.api.v1;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
public class BlockResV1 {
	private Long id;

	private String description;

	private String shortDescr;

	private String blockCode;
}