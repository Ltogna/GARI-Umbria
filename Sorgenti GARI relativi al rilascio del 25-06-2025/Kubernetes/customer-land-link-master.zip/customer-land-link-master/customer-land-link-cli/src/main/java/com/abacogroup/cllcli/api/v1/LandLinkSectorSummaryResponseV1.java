package com.abacogroup.cllcli.api.v1;

import com.abacogroup.lpisgisserver.api.v1.PublicParcelSector;
import java.util.ArrayList;
import java.util.List;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@Accessors(chain = true)
@NoArgsConstructor
public class LandLinkSectorSummaryResponseV1 {

	private PublicParcelSector sector;

	private Long linkCount;
	private Long totParcelAreaSqm;
	private Long totTitleTypeAreaSqm;

	@Default
	private List<LandLinkTitleSummaryResponseV1> titleSummaryRes = new ArrayList<>();

}
