package com.abacogroup.cllcli.api.v1.req;

import java.util.ArrayList;
import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SectorFilterRequestV1 {

	@NotEmpty
	@Valid
	@Default
	private List<String> sectors = new ArrayList<>();
}
