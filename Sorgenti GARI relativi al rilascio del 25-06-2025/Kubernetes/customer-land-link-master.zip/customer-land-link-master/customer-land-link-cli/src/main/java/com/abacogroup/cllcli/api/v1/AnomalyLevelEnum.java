package com.abacogroup.cllcli.api.v1;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "The level of anomaly")
public enum AnomalyLevelEnum {
	DANGER,
	WARN,
	INFO
}
