package com.abacogroup.cllcli.api.v1.req;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;
import lombok.Builder.Default;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class GroupCreateRequestV1 extends GroupUpdateRequestV1 {

	@NotNull
	private Long titleTypeId;

	@NotEmpty
	@Valid
	@Default
	private List<LandLinkBatchCreateRequestV1> landLinks = new ArrayList<>();

}
