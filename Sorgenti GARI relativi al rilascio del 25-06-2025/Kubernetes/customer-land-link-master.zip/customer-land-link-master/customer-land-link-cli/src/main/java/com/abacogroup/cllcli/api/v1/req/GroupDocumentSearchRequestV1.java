package com.abacogroup.cllcli.api.v1.req;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class GroupDocumentSearchRequestV1 {

	@Parameter(in = ParameterIn.QUERY, description = "DD definition Code")
	@QueryParam("definitionCode")
	private String definitionCode;

}
