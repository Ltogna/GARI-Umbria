package com.abacogroup.cllcli.api.v1;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)

public class ParcelSearchResponseV1 {

	private ParcelResV1 parcel;

	@JsonIgnore
	private Long partyId;

	private List<LandLinkLeadingResV1> leadings;

	protected ParcelSearchResponseV1() {

	}

	//	@Deprecated
	//	public ParcelSearchRes(ParcelRes parcel, Long partyId, List<PartyResponseV1> conduttori) {
	//		this.parcel = parcel;
	//		this.partyId = partyId;
	//		this.conduttori = conduttori;
	//	}

	public ParcelSearchResponseV1(ParcelResV1 parcel, Long partyId, List<LandLinkLeadingResV1> leadings) {
		this.parcel = parcel;
		this.partyId = partyId;
		this.leadings = leadings;
	}

	public boolean isConduzione() {
		if (null == leadings) {
			return false;
		}
		return !leadings.isEmpty();
	}

	public boolean isConduzioneByCurrentParty() {
		if (null == leadings) {
			return false;
		}
		return leadings.stream()
				.map(LandLinkLeadingResV1::getPartyId)
				.anyMatch(x -> partyId.equals(x));
	}

}
