package com.abacogroup.cllcli.api.v1;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper=false)
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class LandLinkLeadingResWithHolderResV1 extends LandLinkLeadingResV1{

	private MandateHolderResV1 mandateHolder;

}
