package com.abacogroup.cllcli.api.v1.req;

import java.util.ArrayList;
import java.util.List;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SearchPartiesForSectorsRequestV1 {


	@NotNull
	@Size(min = 1)
	@Default
	private List<String> sectors = new ArrayList<>();

}
