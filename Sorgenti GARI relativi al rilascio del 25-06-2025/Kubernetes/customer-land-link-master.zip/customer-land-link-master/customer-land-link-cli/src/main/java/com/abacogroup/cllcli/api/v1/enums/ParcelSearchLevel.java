package com.abacogroup.cllcli.api.v1.enums;

public enum ParcelSearchLevel {
	SEARCH_ONLY_VALID, 
	SEARCH_OUTDATED,
	ADD_TEMP_PARCELS_IF_NOT_EXISTS
}
