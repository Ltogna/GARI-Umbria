package com.abacogroup.cllcli.api.v1;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.AllArgsConstructor;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class LandLinkAnomaliesResV1 {

	@Default
	@JsonAnyGetter
	@JsonAnySetter
	@JsonProperty(access = Access.WRITE_ONLY)
	private Map<AnomalyLevelEnum, List<AnomalySearchResponse>> anomaliesGrouped = new HashMap<>();

}
