package com.abacogroup.cllcli.api.v1;

import com.abacogroup.anomalyregistry.api.v1.AnomalySearchResponse;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Optional;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.jdbi.v3.core.mapper.Nested;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class LandLinkResV1 {

	private Long id;
	//	private Long pkid;

	@Nested("group_detail")
	private GroupBaseResponseV1 group;

	//	private String tenantId;
	private Long partyId; // TODO full dto?

	@Nested("title")
	private TitleTypeReponseV1 titleType;

//	@Schema(multipleOf = 0.00000001)
	@Default
	private BigDecimal titleTypePerc = BigDecimal.valueOf(100);

	@Nested("parcel")
	private ParcelResV1 parcel;

	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;

//	private AnomalyLevelEnum maxAnomalyLevel;
	@Default
	private Long anomalyCount = 0L;

	private List<AnomalySearchResponse> anomalies;

	public Long getTitleTypeAreaSqm() {
		return titleTypePerc.multiply(BigDecimal.valueOf(Optional.ofNullable(parcel).map(ParcelResV1::getAreaSqm).orElse(0L)))
				.divide(BigDecimal.valueOf(100), 0, RoundingMode.HALF_UP).longValue();
	}
}
