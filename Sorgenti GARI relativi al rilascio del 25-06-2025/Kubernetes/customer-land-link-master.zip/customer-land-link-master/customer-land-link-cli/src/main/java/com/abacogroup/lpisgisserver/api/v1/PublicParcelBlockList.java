package com.abacogroup.lpisgisserver.api.v1;

import java.util.List;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class PublicParcelBlockList {
	private List<PublicParcelBlock> blocksList;
}
