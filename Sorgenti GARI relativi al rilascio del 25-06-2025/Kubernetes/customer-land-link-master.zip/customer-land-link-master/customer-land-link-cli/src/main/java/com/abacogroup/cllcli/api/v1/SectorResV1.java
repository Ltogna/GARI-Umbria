package com.abacogroup.cllcli.api.v1;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class SectorResV1 {

	private Long id;

	private String description;

	private String shortDescr;

	private String sectorCode;
}