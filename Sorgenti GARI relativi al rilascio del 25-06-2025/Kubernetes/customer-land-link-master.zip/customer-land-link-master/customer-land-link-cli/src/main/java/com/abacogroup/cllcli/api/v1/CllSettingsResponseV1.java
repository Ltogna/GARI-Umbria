package com.abacogroup.cllcli.api.v1;

import com.abacogroup.cllcli.api.v1.enums.ParcelSearchLevel;

import lombok.Builder;
import lombok.Data;
import lombok.experimental.Accessors;

@Builder(setterPrefix = "set")
@Accessors(chain = true)
@Data
public class CllSettingsResponseV1 {

	private String lpisSubSeparator;
	private Boolean allowEditDayToParcelInThePast;
	private ParcelSearchLevel parcelSearchLevel;

}
