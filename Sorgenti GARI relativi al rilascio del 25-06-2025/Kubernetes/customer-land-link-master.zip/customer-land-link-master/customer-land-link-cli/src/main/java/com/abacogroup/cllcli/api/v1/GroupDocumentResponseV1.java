package com.abacogroup.cllcli.api.v1;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
public class GroupDocumentResponseV1 extends DocumentResponseV1{

	private Long groupId;

}
