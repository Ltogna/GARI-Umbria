package com.abacogroup.cllcli.api.v1;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@Accessors(chain = true)
@NoArgsConstructor
public class LandLinkTitleSummaryResponseV1 {

	private TitleTypeReponseV1 titleType;

	private Long linkCount;
	private Long totParcelAreaSqm;
	private Long totTitleTypeAreaSqm;
}
