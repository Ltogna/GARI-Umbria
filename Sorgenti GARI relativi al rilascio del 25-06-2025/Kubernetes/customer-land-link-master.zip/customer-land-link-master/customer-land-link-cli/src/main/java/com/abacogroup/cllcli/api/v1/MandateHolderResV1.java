package com.abacogroup.cllcli.api.v1;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class MandateHolderResV1 {
	
	@Schema(description = "Holder id", type = "integer", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Long id;
	
	@Schema(description = "Code of Holder", type = "string")
	private String code;
	
	@Schema(description = "Holder's name", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String name;
	
	@Schema(description = "Holder's type", implementation = MandateHolderTypeResV1.class, requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private MandateHolderTypeResV1 type;
}
