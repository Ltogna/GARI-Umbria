package com.abacogroup.lpisgisserver.api.v1;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class PublicParcelBlock {
	private Long id;

	private Long sectorId;

	private String description;

	private String shortDescr;

	private String blockCode;
}
