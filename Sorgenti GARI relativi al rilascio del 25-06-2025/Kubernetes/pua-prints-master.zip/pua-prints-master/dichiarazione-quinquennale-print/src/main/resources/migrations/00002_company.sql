CREATE TABLE IF NOT EXISTS COMPANY (
    APPLICATION_ID 		BIGINT 			NOT NULL, 
    CUAA 				VARCHAR(100) 	NOT NULL, 
    VAT_NUMBER          VARCHAR(100),     		  --  PARTITA_IVA
    COMPANY_NAME        VARCHAR(100),             --  RAGIONE_SOCIALE
    STREET_ADDRESS      VARCHAR(200),             --  INDIRIZZO
    POSTAL_CODE         VARCHAR(100),              --  CAP
    PROVINCE            VARCHAR(100),               --  PROV
    ISTAT_CODE          VARCHAR(100),              --  CODICE_ISTAT
    MUNICIPALITY        VARCHAR(100)               --  COMUNE
);