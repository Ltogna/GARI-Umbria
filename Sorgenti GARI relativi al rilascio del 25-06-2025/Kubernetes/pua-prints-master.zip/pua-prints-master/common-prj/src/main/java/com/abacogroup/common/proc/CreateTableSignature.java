package com.abacogroup.common.proc;

import java.time.LocalDate;

import org.jdbi.v3.core.Handle;

import com.abacogroup.common.dto.Company;
import com.abacogroup.common.utils.DbUtils;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import io.dropwizard.auth.AuthenticationException;
import lombok.extern.slf4j.Slf4j;

/**
 * carica da microservzio e persiste su h2
 * <p>
 * h2 è gia stato creato dalla proc precedente
 * 
 * 
 * This procedure fills the table SIGNATURE used by the template signature_dinamic.jrxml
 * 
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class CreateTableSignature extends BasePrintProcedure {

	@Override
	public void customExecute(ProcessData processData, ProcedureEnvironment procedureEnvironment) throws AuthenticationException {

		try (Handle handle = jdbi.open()) {
			
			Company company = DbUtils.getByApplicationId(handle, "COMPANY", applicationId, Company.class);

			handle.createUpdate("insert into signature (id, role, name, date) values (:id, :role, :name, :date)")
			.bind("id", "1")
			.bind("name", String.join(" ", company.getCompanyName()))
			.bind("role", "TITOLARE")
			.bind("date", LocalDate.now().format(DATE_FORMATTER))
			.execute();

		} catch (Exception e) {
			log.error(String.format("An error occurred inserting signature for application id %s", applicationId), e);
		}
	}

}
