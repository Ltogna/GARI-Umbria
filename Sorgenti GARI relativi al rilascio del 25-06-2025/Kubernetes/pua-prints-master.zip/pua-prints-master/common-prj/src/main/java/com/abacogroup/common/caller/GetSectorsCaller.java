package com.abacogroup.common.caller;

import com.abacogroup.common.caller.input.GetSectorsDataInput;
import com.abacogroup.common.dto.SectorsDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetSectorsCaller extends AbacoDtoCaller<GetSectorsDataInput, SectorsDTO> {

	public GetSectorsCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
