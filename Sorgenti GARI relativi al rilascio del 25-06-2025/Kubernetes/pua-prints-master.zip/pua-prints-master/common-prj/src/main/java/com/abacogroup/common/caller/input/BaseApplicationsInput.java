package com.abacogroup.common.caller.input;

import com.abacogroup.applicationworkflowsdk.model.Constants;
import com.abacogroup.jaxrsutils.callerv2.ICallerInput;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * @author Alexandru Paraschiv
 * @author Emanuele Crocilla
 */
@Data
@SuperBuilder
public abstract class BaseApplicationsInput implements ICallerInput {

	@NotNull
	protected String tenant;
	
	protected Long partyId;
	
	@NotNull
	protected String authToken;
	
	@NotNull
	protected Long applicationId;
	
	protected String locale;

	protected BaseApplicationsInput(String tenant, Long partyId, Long applicationId, String authToken, String locale, ProcedureEnvironment procedureEnvironment) {
		this.tenant = tenant;
		this.partyId = partyId;
		this.authToken = Constants.AUTHORIZATION_PREFIX + authToken;
		this.applicationId = applicationId;
		this.locale = "it";
	}

	@Override
	public String locale() {
		return this.locale;
	}
}
