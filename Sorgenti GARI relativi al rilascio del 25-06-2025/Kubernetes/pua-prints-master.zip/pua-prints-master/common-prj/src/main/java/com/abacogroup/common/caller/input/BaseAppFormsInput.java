package com.abacogroup.common.caller.input;

import com.abacogroup.applicationworkflowsdk.environment.MissingObjectFromEnvironmentException;
import com.abacogroup.applicationworkflowsdk.model.Constants;
import com.abacogroup.common.code.Codes;
import com.abacogroup.jaxrsutils.callerv2.ICallerInput;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@SuperBuilder
public abstract class BaseAppFormsInput implements ICallerInput {

	@NotNull
	protected String tenant;
	@NotNull
	protected String authToken;
	@NotNull
	protected String appFormsUrl;
	@NotNull
	protected Long applicationId;
	protected String locale;

	protected BaseAppFormsInput(ProcedureEnvironment procedureEnvironment, String tenant, Long applicationId, String authToken) {
		this.appFormsUrl = procedureEnvironment.getProperty(Codes.APPLICATION_FORMS_URL_KEY).map(Object::toString).orElseThrow(() -> new MissingObjectFromEnvironmentException(Codes.APPLICATION_FORMS_URL_KEY));
		//System.out.printf(this.appFormsUrl);
		this.authToken = Constants.AUTHORIZATION_PREFIX + authToken;
		this.tenant = tenant;
		this.applicationId = applicationId;
		this.locale = "it";
	}

	@Override
	public String locale() {
		return this.locale;
	}


}
