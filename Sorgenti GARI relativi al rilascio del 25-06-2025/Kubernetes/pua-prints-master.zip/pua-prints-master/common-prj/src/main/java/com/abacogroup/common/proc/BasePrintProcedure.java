package com.abacogroup.common.proc;

import static com.abacogroup.common.utils.Utils.getGenericCallerService;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;

import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.common.code.Codes;
import com.abacogroup.common.dto.UnifiedPrintInput;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.printengine.sdk.proc.H2Procedure;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.EnvironmentAwareProcedure;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public abstract class BasePrintProcedure implements EnvironmentAwareProcedure<ProcedureEnvironment> {
	
	public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

	protected GenericCallerService genericCallerService;
	protected Jdbi jdbi;
	protected Long applicationId;
	protected Long partyId;
	protected User user;

	@Override
	public void execute(ProcessData processData, ProcedureEnvironment procedureEnvironment) throws Exception {
		log.info("Entering class {}", this.getClass().getSimpleName());
		this.genericCallerService = getGenericCallerService(procedureEnvironment);
		UnifiedPrintInput dto = (UnifiedPrintInput) processData.getGlobalVars().get(ValidateParamProcedure.PARAM_NAME);
		this.applicationId = dto.getApplicationId();
		this.partyId = dto.getPartyId();
		this.jdbi = (Jdbi) processData.getGlobalVars().get(H2Procedure.JDBI_H2_CONNECTION);
		this.user = (User) processData.getAuthContext().getPrincipal();
		customExecute(processData, procedureEnvironment);
	}

	protected abstract void customExecute(ProcessData processData, ProcedureEnvironment procedureEnvironment) throws Exception;
	
	public DataInputParams getDefaultDataInputParams() {
		return DataInputParams.builder()
				.tenant(this.user.getTenant())
				.applicationId(applicationId)
				.partyId(this.partyId)
				.locale(Codes.DEFAULT_LOCALE)
				.authToken(this.user.getAuthToken())
				.build();
	}
	
	/** this method is a sort of a test method to check inserted into DB 
	 * 
	 *  @param tableName the name of the table to check for
	 * 
	 * */
	protected void logInsertedDataInDB(String tableName) {
		
		try (Handle handle = jdbi.open()) {

			var count =
					handle.createQuery(String.format("select count(*) from %s ", tableName))
//					.bind("CUAA", companyDataDTO.getCode())
					.mapTo(Integer.class).stream().findFirst();
			
			log.info(String.format("Just inserted " + count.orElseGet(() -> 0) + " elements in %s table", tableName));

			List<Map<String, Object>> rows = handle
					.createQuery(String.format("select * from %s ", tableName))
					.mapToMap() 
					.list();


			log.info(String.format("Just inserted data in %s table: ", tableName) + rows.toString());

		} catch (Exception e) {
			log.error(String.format("An error occurred displaying data inserted in %s table for application id %s", 
					tableName, applicationId), e);
		}
	}

}
