package com.abacogroup.common.caller;

import com.abacogroup.common.caller.input.GetCompanyDataInput;
import com.abacogroup.common.dto.CompanyDataDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetCompanyDataCaller extends AbacoDtoCaller<GetCompanyDataInput, CompanyDataDTO> {

	public GetCompanyDataCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
