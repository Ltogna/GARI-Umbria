package com.abacogroup.common.proc;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdbi.v3.core.Handle;

import com.abacogroup.common.caller.GetEffluentsCaller;
import com.abacogroup.common.caller.GetNoSpreadingPeriodsCaller;
import com.abacogroup.common.caller.input.GetEffluentsDataInput;
import com.abacogroup.common.caller.input.GetNoSpreadingPeriodsInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.common.dto.EffluentDTO;
import com.abacogroup.common.dto.NoSpreadingPeriodsDTO;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 *  Carica da microservizio e persiste su h2
 * 	<p>
 *	h2 è gia stato creato dalla proc precedente
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class CreateTableNoSpreadingPeriodsData extends BasePrintProcedure {

	@Override
	public void customExecute(ProcessData processData, ProcedureEnvironment procedureEnvironment) throws Exception {
		
		GetNoSpreadingPeriodsCaller getNoSpreadingPeriodsCaller = new GetNoSpreadingPeriodsCaller(this.genericCallerService);
		
		DataInputParams inputParams = getDefaultDataInputParams();
		
		List<NoSpreadingPeriodsDTO> dtos = getNoSpreadingPeriodsCaller.makeCall(
				new GetNoSpreadingPeriodsInput(procedureEnvironment, inputParams));

		log.debug("NoSpreadingPeriodsDTOs: {}", dtos);
		
		// fetching Effluents
		GetEffluentsCaller getEffluentsCaller = new GetEffluentsCaller(this.genericCallerService);
		List<EffluentDTO> effluents = getEffluentsCaller.makeCall(new GetEffluentsDataInput(procedureEnvironment, inputParams));
		Map<String, EffluentDTO> effluentsMap = new HashMap<>();
		effluents.forEach(effluent -> effluentsMap.put(effluent.getCode(), effluent));
		
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
		
		try (Handle handle = jdbi.open()) {
			
			for (NoSpreadingPeriodsDTO dto : dtos) {
				
				EffluentDTO effluent = effluentsMap.get(dto.getEffluent());
				
				handle.createUpdate(  
						"INSERT INTO NO_SPREADING_PERIODS (APPLICATION_ID, EFFLUENT, DATE_FROM, DATE_TO) "
								+	"VALUES (:APPLICATION_ID, :EFFLUENT, :DATE_FROM, :DATE_TO) "
						)
				.bind("APPLICATION_ID", dto.getApplicationId() ) 
				.bind("EFFLUENT", effluent!=null ? effluent.getDescription() : null ) 
				.bind("DATE_FROM", df.parse(dto.getDayFrom()))
				.bind("DATE_TO", df.parse(dto.getDayTo()))
				.execute();
			}
			
			if (log.isDebugEnabled()) {
				logInsertedDataInDB("NO_SPREADING_PERIODS");
			}

		} catch (Exception e) {
			log.error(String.format("An error occurred inserting application data for application id %s", applicationId), e);
		}
	}
}
