package com.abacogroup.common.proc;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.jdbi.v3.core.Handle;

import com.abacogroup.common.caller.GetDeclarationsOnSectorsCaller;
import com.abacogroup.common.caller.GetLandusesCaller;
import com.abacogroup.common.caller.GetSectorsCaller;
import com.abacogroup.common.caller.input.GetDeclarationsOnSectorsDataInput;
import com.abacogroup.common.caller.input.GetLandusesDataInput;
import com.abacogroup.common.caller.input.GetSectorsDataInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.common.code.Codes;
import com.abacogroup.common.dto.DeclarationsOnSectorsDTO;
import com.abacogroup.common.dto.LandusesDTO;
import com.abacogroup.common.dto.LandusesDTO.LandUse;
import com.abacogroup.common.dto.SectorsDTO;
import com.abacogroup.common.dto.SectorsDTO.Sector;
import com.abacogroup.common.utils.DbUtils;
import com.abacogroup.common.utils.PuaProfile;
import com.abacogroup.common.utils.Utils;
import com.abacogroup.common.utils.Utils.NumberPattern;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 *  Carica da microservizio e persiste su h2
 * 	<p>
 *	h2 è gia stato creato dalla proc precedente
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class CreateTableDeclarationsOnSectorsData extends BasePrintProcedure {

	@Override
	public void customExecute(ProcessData processData, ProcedureEnvironment procedureEnvironment) throws Exception {
		
		
		// we have to check if the profile is a "SEMPLICE" one
		// (with TipologiaDichiarazione.flOrganicFert = false and TipologiaDichiarazione.flLivestocks = false)
		PuaProfile profile = DbUtils.getPuaProfile(jdbi, applicationId);
		
		if (PuaProfile.PUA_SEMPLICE.equals(profile)) {

			GetDeclarationsOnSectorsCaller getDeclarationsOnSectorsDataCaller = new GetDeclarationsOnSectorsCaller(this.genericCallerService);
			
			DataInputParams inputParams = getDefaultDataInputParams();
			
			List<DeclarationsOnSectorsDTO> dtos = null;
			
			try {
				
				dtos = getDeclarationsOnSectorsDataCaller.makeCall(new GetDeclarationsOnSectorsDataInput(
						procedureEnvironment, inputParams));
				
			} catch (Exception e) {
				log.error("Unable to fethch DeclarationsOnSectors elements by service", e);
				return;
			}

			log.debug("DeclarationsOnSectorsDTO's: {}", dtos);
			
			GetSectorsCaller getSectorsCaller = new GetSectorsCaller(this.genericCallerService);
			List<String> sectorCodes = new ArrayList<>(dtos.size());
			dtos.forEach(dto -> sectorCodes.add(dto.getSectorCode()));
			inputParams.setPayload(sectorCodes);
			SectorsDTO sectors = getSectorsCaller.makeCall(new GetSectorsDataInput(procedureEnvironment, inputParams));
			var sectorsMap = sectors.getSectorsAsMap();

			GetLandusesCaller getLandusesCaller = new GetLandusesCaller(this.genericCallerService);
			List<String> landUseCodes = new ArrayList<>(dtos.size());
			dtos.forEach(dto -> landUseCodes.add(dto.getLandUseCode()));
			inputParams.setPayload(landUseCodes);
			LandusesDTO landUses = getLandusesCaller.makeCall(new GetLandusesDataInput(procedureEnvironment, inputParams));
			var landUsesMap = landUses.getLandUsesAsMap();
			
			insertInTable(dtos, sectorsMap, landUsesMap);
			
		}
	}
	
	private void insertInTable(List<DeclarationsOnSectorsDTO> dtos, Map<String, Sector> sectorsMap, Map<String, LandUse> landUsesMap) {

		try (Handle handle = jdbi.open()) {

				Sector sector = null;
				LandUse landUse = null;
				BigDecimal totalNitro = null;
				BigDecimal areaInHectar = null;
				
				for (DeclarationsOnSectorsDTO dto : dtos) {
					
					sector = sectorsMap.getOrDefault(dto.getSectorCode(), null);
					landUse = landUsesMap.getOrDefault(dto.getLandUseCode(), null);
					areaInHectar = BigDecimal.valueOf(dto.getAreaSqm()).divide(BigDecimal.valueOf(10000));
					totalNitro = areaInHectar.multiply(BigDecimal.valueOf(dto.getMas())).setScale(2, RoundingMode.HALF_UP);
					
					handle.createUpdate(
							"INSERT INTO DECLARATIONS_ON_SECTORS (APPLICATION_ID, SECTOR, LAND_USE, FL_ZVN, AREA, MAS, TOTAL_NITRO) "
							+ "VALUES (:APPLICATION_ID, :SECTOR, :LAND_USE, :FL_ZVN, :AREA, :MAS, :TOTAL_NITRO)")
					.bind("APPLICATION_ID", dto.getApplicationId()) 
					.bind("SECTOR", sector!=null?sector.getDescription():"?"+dto.getSectorCode()+"?")
					.bind("LAND_USE", landUse!=null?landUse.getDescription():"?"+dto.getLandUseCode()+"?") 
					.bind("FL_ZVN", Boolean.valueOf(dto.isFlZvn()) ? "si" : "no") 
					.bind("AREA", Utils.formatNumbAndGetAsString(areaInHectar, NumberPattern.PATTERN_DECIMAL))
					.bind("MAS", Utils.formatNumbAndGetAsString(dto.getMas(), NumberPattern.PATTERN_INT))
					.bind("TOTAL_NITRO", Utils.formatNumbAndGetAsString(totalNitro , NumberPattern.PATTERN_DECIMAL_2))
						.execute();
				}
			
		} catch (Exception e) {
			log.error(String.format("An error occurred inserting application data for application id %s", applicationId), e);
		}
	}
}
