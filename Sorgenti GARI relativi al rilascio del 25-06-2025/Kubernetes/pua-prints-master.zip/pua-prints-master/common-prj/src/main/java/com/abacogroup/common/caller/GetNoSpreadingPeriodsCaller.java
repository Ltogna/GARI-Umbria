package com.abacogroup.common.caller;

import java.util.List;

import com.abacogroup.common.caller.input.GetNoSpreadingPeriodsInput;
import com.abacogroup.common.dto.NoSpreadingPeriodsDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetNoSpreadingPeriodsCaller extends AbacoDtoCaller<GetNoSpreadingPeriodsInput, List<NoSpreadingPeriodsDTO>> {

	public GetNoSpreadingPeriodsCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
