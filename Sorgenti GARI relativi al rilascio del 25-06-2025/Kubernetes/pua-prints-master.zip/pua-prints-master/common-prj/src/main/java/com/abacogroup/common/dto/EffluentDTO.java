package com.abacogroup.common.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 * 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EffluentDTO {

    private String code;
    private String description;
    private Double nitrogen;
    private String codeUom;
    private String descriptionUom;
 
}
