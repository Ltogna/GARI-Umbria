package com.abacogroup.common.caller.input;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 * 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnimalHousingRequest {
	
	private List<AnimalHousingRequestElement> elements;
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public class AnimalHousingRequestElement {
		private String specieCode;
		private String genreCode;
		private String categoryCode;
		private String productionCode;
	}
	

	public void addElement(String specieCode, String genreCode, String categoryCode, String productionCode) {
		if (elements == null) {
			elements = new ArrayList<>();
		}
		elements.add(new AnimalHousingRequestElement(specieCode, genreCode, categoryCode, productionCode));
	}
	
	public List<AnimalHousingRequestElement> getElements(){
		return elements;
	}
}
