package com.abacogroup.common.caller;

import java.util.List;

import com.abacogroup.common.caller.input.GetDeclOnCropsDataInput;
import com.abacogroup.common.dto.DeclOnCropsDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetDeclOnCropsCaller extends AbacoDtoCaller<GetDeclOnCropsDataInput, List<DeclOnCropsDTO>> {

	public GetDeclOnCropsCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
