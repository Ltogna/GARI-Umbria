package com.abacogroup.common.dto;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class FinalDeclarationsDTO {
	
	private Document document;
	private DocumentDefinition documentDefinition;
	
	// Document.java
	@Data
	@SuperBuilder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class Document {
		private String validFrom;
		private String validTo;
		private Map<String, Object> fields;
	}

	// DocumentDefinition.java
	@Data
	@SuperBuilder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class DocumentDefinition {
		private String code;
		private String version;
		private String description;
		private LocalizedText title;
		private Metadata metadata;
		private List<FieldSet> fieldSets;
		private Object lookups;
		private Object restLookups;
		private Object onSaveApiCalls;
	}

	// LocalizedText.java
	@Data
	@SuperBuilder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class LocalizedText {
		private String en;
		private String it;
	}

	// Metadata.java
	@Data
	@SuperBuilder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class Metadata {
		private Integer maxOccurs;
		private Boolean timeOverlap;
		private String defaultLocale;
		private String startDateField;
		private String endDateField;
		private Object summaryFields;
	}

	// FieldSet.java
	@Data
	@SuperBuilder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class FieldSet {
		private String code;
		private Integer minOccurs;
		private Integer maxOccurs;
		private LocalizedText label;
		private List<Field> fields;
	}

	// Field.java
	@Data
	@SuperBuilder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class Field {
		private String code;
		private Boolean required;
		private LocalizedText label;
		private String type;
		private Object format;
		private Object style;
		private Boolean readonly;
		private Object help;
		private Object lookupCode;
		private Object validation;
	}
	
}
