package com.abacogroup.common.caller;

import com.abacogroup.common.caller.input.GetCropPlansDeclarationsDataInput;
import com.abacogroup.common.dto.DeclarationInfoDTO;
import com.abacogroup.common.dto.RecordResponse;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetCropPlansDeclarationsCaller extends AbacoDtoCaller<GetCropPlansDeclarationsDataInput, RecordResponse<DeclarationInfoDTO>> {

	public GetCropPlansDeclarationsCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
