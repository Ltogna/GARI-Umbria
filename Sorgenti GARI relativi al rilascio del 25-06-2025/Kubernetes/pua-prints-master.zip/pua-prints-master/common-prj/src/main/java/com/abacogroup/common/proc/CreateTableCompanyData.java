package com.abacogroup.common.proc;

import java.util.Optional;

import org.jdbi.v3.core.Handle;

import com.abacogroup.common.caller.GetCompanyDataCaller;
import com.abacogroup.common.caller.input.GetCompanyDataInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.common.code.Codes;
import com.abacogroup.common.dto.CompanyDataDTO;
import com.abacogroup.common.dto.CompanyDataDTO.Address;
import com.abacogroup.common.dto.CompanyDataDTO.Country;
import com.abacogroup.common.dto.CompanyDataDTO.District;
import com.abacogroup.common.dto.CompanyDataDTO.MunicipalityDetail;
import com.abacogroup.common.dto.CompanyDataDTO.Region;
import com.abacogroup.common.utils.Utils;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 *  Carica da microservizio e persiste su h2
 * 	<p>
 *	h2 è gia stato creato dalla proc precedente
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class CreateTableCompanyData extends BasePrintProcedure {

	@Override
	public void customExecute(ProcessData processData, ProcedureEnvironment procedureEnvironment) throws Exception {
		
		GetCompanyDataCaller getCompanyDataCaller = new GetCompanyDataCaller(this.genericCallerService);
		
		DataInputParams inputParams = getDefaultDataInputParams();
		
		CompanyDataDTO companyDataDTO = getCompanyDataCaller.makeCall(new GetCompanyDataInput(procedureEnvironment, inputParams));

		log.debug("companyDataDTO: {}", companyDataDTO);
		
		Address address = null;
		String firstName = "";
		
		if (null != companyDataDTO) {
			address = companyDataDTO.getAddressBilling() != null ? companyDataDTO.getAddressBilling() 
					: companyDataDTO.getAddressResidential();
			
			address = address == null ? companyDataDTO.getAddressHome() : address;
			firstName = companyDataDTO.getFirstName() != null ? firstName = companyDataDTO.getFirstName() : "";
		}
		
		
		try (Handle handle = jdbi.open()) {
			handle.createUpdate(
					"INSERT INTO COMPANY (APPLICATION_ID, CUAA, VAT_NUMBER, COMPANY_NAME, STREET_ADDRESS, POSTAL_CODE, PROVINCE, ISTAT_CODE, MUNICIPALITY) "
					+	"VALUES (:APPLICATION_ID, :CUAA, :VAT_NUMBER, :COMPANY_NAME, :STREET_ADDRESS, :POSTAL_CODE, :PROVINCE, :ISTAT_CODE, :MUNICIPALITY) "
					)
			.bind("APPLICATION_ID", this.applicationId) 
			.bind("CUAA", companyDataDTO.getCode()) 
			.bind("VAT_NUMBER", companyDataDTO.getVatNumber())
			.bind("COMPANY_NAME", companyDataDTO.getLastName() + " " + firstName) 
			.bind("STREET_ADDRESS", address != null ? address.getStreet() : "-")
			.bind("POSTAL_CODE", address != null ? address.getPostcode() : "-")
			.bind("PROVINCE", tryGetDistrict(address))
			.bind("ISTAT_CODE", tryGetIstatCode(address))
			.bind("MUNICIPALITY", tryGetMunicipality(address))
//			.bind("PHONE", "333222111222")
//			.bind("EMAIL", "test@test.ts")
//			.bind("CERTIFIED_EMAIL", "testpec@test.ts")
				.execute();
			
		} catch (Exception e) {
			log.error(String.format("An error occurred inserting application data for application id %s", applicationId), e);
		}
		 

//		try (Handle handle = jdbi.open()) {
//			
//			var count =
//					handle.createQuery("select count(*) from COMPANY where CUAA = :CUAA ")
//					.bind("CUAA", companyDataDTO.getCode())
//					.mapTo(Integer.class).stream().findFirst();
//			
//			
////			var oo =
////					handle.createQuery("select * from header where application_id = :application_id ")
////					.bind("application_id", 17381).mapTo(com.abacogroup.common.dto.HeaderDTO.class).list();
//			
//			
//			List<Map<String, Object>> rows = handle
//				    .createQuery("select * from COMPANY where CUAA = :CUAA ")
//				    .bind("CUAA", companyDataDTO.getCode())
//				    .mapToMap()   // Restituisce ResultIterable<Map<String, Object>>
//				    .list();
//			
//			
//			log.info(rows.toString());
//			
//		} catch (Exception e) {
//			log.error(String.format("An error occurred inserting application data for application id %s", applicationId), e);
//		}
 
	}

	private String tryGetIstatCode(Address address) {
		try {
			
			return address != null && address.getMunicipalityDetail() != null ? 
					Utils.retrieveIstatCode(address.getMunicipalityDetail().getCode()) : "-";
			
		} catch (Exception e) {
			log.info("Unable to get IstatCode from: {}", address);
			return "-";
		}
	}

	private String tryGetCountry(Address address) {
		try {
			return Optional.ofNullable(address)
					.map(Address::getMunicipalityDetail)
					.map(MunicipalityDetail::getDistrict)
					.map(District::getRegion)
					.map(Region::getCountry)
					.map(Country::getI18nName)
					.orElse("-");
		} catch (Exception e) {
			log.info("Unable to get Country from: {}", address);
			return "-";
		}
	}

	private String tryGetDistrict(Address address) {
		try {
			return Optional.ofNullable(address)
					.map(Address::getMunicipalityDetail)
					.map(MunicipalityDetail::getDistrict)
					.map(District::getI18nName)
					.orElse("-");
		} catch (Exception e) {
			log.info("Unable to get District from: {}", address);
			return "-";
		}
	}

	private String tryGetMunicipality(Address address) {
		try {
			return Optional.ofNullable(address)
					.map(Address::getMunicipalityDetail)
					.map(MunicipalityDetail::getI18nName)
					.orElse("-");
		} catch (Exception e) {
			log.info("Unable to get Municipality from: {}", address);
			return "-";
		}
	}

}
