package com.abacogroup.common.dto;

import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DeclOnCropsDTO {
	
	private Long id;
	private Long applicationId;
	private Long planId;
	private String plotCode;
	private String plotDescription;
	private String declCode;
	private String declarationVersion;
	private String landUseCode;
	private boolean flZvn;
	private Integer areaSqm;
	private String cropDuration;
	private String plantStatus;
	private Integer cycle;
	private String typology;
	private Integer yield;
	private Integer mas;
	private Integer precessionCode;
	private String precessionDescription;
	private BigDecimal totResidualNitrogen;
	private BigDecimal distributableNitrogen;
	private BigDecimal totalNitrogen;
	private String sectorCode;
	
	private List<DeclOnCropsPrevEffluentsDTO> previousEffluents;
}