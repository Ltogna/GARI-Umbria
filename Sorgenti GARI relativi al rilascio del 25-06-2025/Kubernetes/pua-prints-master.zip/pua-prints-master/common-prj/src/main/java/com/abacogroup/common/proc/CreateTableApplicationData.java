package com.abacogroup.common.proc;

import org.jdbi.v3.core.Handle;

import com.abacogroup.common.caller.GetApplicationCaller;
import com.abacogroup.common.caller.input.GetApplicationInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.common.code.Codes;
import com.abacogroup.common.dto.ApplicationDTO;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Emanuele Crocilla
 * 
 * Carica da microservizio e persiste su h2
 * <p>
 * h2 è gia stato creato dalla proc precedente
 */
@Slf4j
public class CreateTableApplicationData extends BasePrintProcedure {

	@Override
	public void customExecute(ProcessData processData, ProcedureEnvironment procedureEnvironment) {
		
		log.debug("The PUA application ID is: {}", applicationId);
		
		DataInputParams inputParams = getDefaultDataInputParams();
		
		GetApplicationCaller getApplicationCaller = new GetApplicationCaller(this.genericCallerService);
		
		ApplicationDTO applicationDTO = 
				getApplicationCaller.makeCall(new GetApplicationInput(procedureEnvironment, inputParams));

		log.debug("applicationDTO: {}", applicationDTO);

		try (Handle handle = jdbi.open()) {
			handle.createUpdate("""
					INSERT INTO header (application_id, party_id, application_year, amended_application_id, process_status, is_closed) 
					VALUES (:applicationId, :party_id, :application_year, :amended_application_id, :process_status, :is_closed)
					""")
				.bind("applicationId", applicationId)
				.bind("party_id", partyId)
				.bind("application_year", applicationDTO.getReferredYear())
				.bind("amended_application_id", applicationDTO.getAmendedApplicationId())
				.bind("process_status", applicationDTO.getProcessStatus())
				.bind("is_closed", applicationDTO.getIsClosed())
				.execute();
			
			// Restituisce ResultIterable<Map<String, Object>>
			// var rows = handle.createQuery("select * from header ").mapToMap().first();
			
			
		} catch (Exception e) {
			log.error(String.format("An error occurred inserting application data for application id %s", applicationId), e);
		}
	}

}
