package com.abacogroup.common.caller;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abacogroup.common.caller.input.AnimalsCategoriesDataInput;
import com.abacogroup.common.dto.AnimalCategoryDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetAnimalsCategoriesCaller extends AbacoDtoCaller<AnimalsCategoriesDataInput, List<AnimalCategoryDTO>> {
	
	public GetAnimalsCategoriesCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

	public AnimalsCategoriesMap makeCallAndGetAsMap(AnimalsCategoriesDataInput i) {
		Map<String, AnimalCategoryDTO> map = new HashMap<>();
		List<AnimalCategoryDTO> productTypeDTOs = this.makeCall(i);
		productTypeDTOs.forEach(c -> map.put(c.getCode() + "_" + c.getGenreCode() + "_" + c.getProductionCode() 
			+ "_" + c.getSpecieCode(), c));
		return new AnimalsCategoriesMap(map);
	}
	
	public class AnimalsCategoriesMap {

		private Map<String, AnimalCategoryDTO> map = new HashMap<>();

		private AnimalsCategoriesMap(Map<String, AnimalCategoryDTO> map) {
			this.map = map;
		}

		public String getAnimalCategoryDescriptionByAnimalCategoryCode(String categoryCode) {
			// uses: genreCode_specieCode_code_productionCode
			if (null != categoryCode) {
				String composedCode = null;
				for (AnimalCategoryDTO animalCategory : this.map.values()) {
					
					composedCode = animalCategory.getGenreCode() + "_" + animalCategory.getSpecieCode() + 
							"_" + animalCategory.getCode() + "_" + animalCategory.getProductionCode();
					
					if (composedCode.equals(categoryCode)) {
						return animalCategory.getDescription();
					}
				}
			}
			return null;
		}
		
		public Collection<AnimalCategoryDTO> getAnimalCategories(){
			return this.map.values();
		}
	}
}
