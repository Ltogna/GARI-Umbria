package com.abacogroup.common.caller.input;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.abacogroup.applicationworkflowsdk.model.Constants;
import com.abacogroup.common.caller.partyregistry.input.BaseDataInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import io.dropwizard.auth.AuthenticationException;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@EqualsAndHashCode(callSuper = true)
public class GetSectorsDataInput extends BaseDataInput {
	
    public GetSectorsDataInput(ProcedureEnvironment procedureEnvironment, DataInputParams inputParams) throws AuthenticationException {
        super(procedureEnvironment, inputParams);
    }

    @Override
    public Map<String, Object> getPathVariablesMap() {
        return Map.of(Constants.TENANT, this.tenant);
    }

    @Override public Map<String, Object> getQueryParamsMap() {
        return Collections.emptyMap();
    }

    @Override public String provideAuthToken() {
        return this.authToken;
    }
    
    @Override
	public SearchSectorsRequest providePayload() {
    	var searchRequest = new SearchSectorsRequest();
    	searchRequest.codes = (List<String>) this.payload;
    	searchRequest.nextKey = 1;
		return searchRequest;
	}

    @Override public String getUrl() {
    	
        return this.lpisServerUrl + "/{TENANT}/public/v1/lpis/sectors";
    }

    @Override public String getHttpMethod() {
        return GenericCallerService.POST_METHOD;
    }

    @Override public String locale() {
        return this.locale;
    }
    
//    public RecordResponse<SectorDTO> getSectors(User user, String tenantId, SectorRequest request) {
//		authToken = user.getAuthToken();
//		var result = new RecordResponse<SectorDTO>();
//		result.setRecords(new ArrayList<>());
//		String nextKey = null;
//
//		do {
//			// /lpis-server-api/master/public/v1/lpis/sectors
//			String url = String.format("%s/%s/public/v1/lpis/sectors", lpisServerUrl, tenantId);
//			var data = sendPostRequestWithAuth(url, request, new TypeReference<RecordResponse<SectorDTO>>() {
//			}, "getSectors", tenantId);
//
//			if (data != null && !data.getRecords().isEmpty()) {
//				result.getRecords().addAll(data.getRecords());
//				nextKey = data.getNextKey();
//			}
//		}
//		while (nextKey != null);
//		return result;
//	}
// 
//	public LandUseCodesDTO getLandusesCodes(User user, String tenantId, LandUseCodesRequest request) {
//		authToken = user.getAuthToken();
//
//		// /lpis-server-api/master/public/v1/lpis/sectors
//		String url = String.format("%s/%s/public/v1/lpis/support/landuses-codes", lpisServerUrl, tenantId);
//		return sendPostRequest(tenantId, url, request, LandUseCodesDTO.class, "getLandusesCodes");
//	}

}
