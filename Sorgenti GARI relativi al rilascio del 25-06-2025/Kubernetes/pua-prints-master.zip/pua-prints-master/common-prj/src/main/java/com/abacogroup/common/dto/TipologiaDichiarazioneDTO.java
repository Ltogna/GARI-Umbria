package com.abacogroup.common.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class TipologiaDichiarazioneDTO {

	private Long applicationId;
	
	private int year;
	
	private boolean flOrganicFert;
	
	private boolean flLivestocks;

}
