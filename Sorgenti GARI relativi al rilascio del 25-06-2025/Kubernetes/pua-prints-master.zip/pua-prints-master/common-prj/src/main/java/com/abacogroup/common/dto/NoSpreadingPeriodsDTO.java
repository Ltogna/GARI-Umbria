package com.abacogroup.common.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
 
/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class NoSpreadingPeriodsDTO {
	
	private Long applicationId;
    private String effluent;
    private String dayFrom;
    private String dayTo;

}
