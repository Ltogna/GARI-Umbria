package com.abacogroup.common.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 * 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnimalCategoryDTO {
    private String genreCode;
    private String specieCode;
    private String code;
    private String productionCode;
    private String description;
    private Double averageWeight;
    private Double nitrogenPV;
}
