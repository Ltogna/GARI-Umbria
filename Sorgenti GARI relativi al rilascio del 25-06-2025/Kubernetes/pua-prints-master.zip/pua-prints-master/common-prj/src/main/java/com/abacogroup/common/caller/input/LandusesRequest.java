package com.abacogroup.common.caller.input;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class LandusesRequest {
	
	@JsonProperty("landuse_codes")
	public List<String> landuseCodes;
}
