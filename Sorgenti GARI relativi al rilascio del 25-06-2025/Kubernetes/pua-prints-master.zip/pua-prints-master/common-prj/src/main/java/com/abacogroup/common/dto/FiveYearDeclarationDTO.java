package com.abacogroup.common.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class FiveYearDeclarationDTO {
    private Long partyId;
    private String cuaa;
    private String company;
    private String sectorCode;
    private String blockCode;
    private String parcelCode;
    private String subParcelCode;
    private Integer cadastralAreaSqm;
    private String dayFrom;
    private String dayTo;
    private Integer usedAreaSqm;
}

