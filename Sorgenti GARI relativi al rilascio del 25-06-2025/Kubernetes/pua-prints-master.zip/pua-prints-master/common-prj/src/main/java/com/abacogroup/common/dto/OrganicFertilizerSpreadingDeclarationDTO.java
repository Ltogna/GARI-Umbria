package com.abacogroup.common.dto;

import java.util.Collection;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class OrganicFertilizerSpreadingDeclarationDTO {
	
	private Long id;

	private String cuaa;

	private String company;

	private Long partyId;

	private String expectedDate;

	private String livestockEffluents;

	private Double livestockEffluentsQty;

	private String cropPlanVersion;

	private String sectorCode;

	private Collection<OrganicFertilizerSpreadingDeclarationLanduseDTO> landuses;
}
