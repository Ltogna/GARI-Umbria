package com.abacogroup.common.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DeclOnCropLiveStocksDTO {
	private String species;
	private String category;
	private String typeStabling;
	private Integer numberHeadsRaised;
	private Double numberField;
	private Double averagePV;
	private Double sewageOutlet;
	private Double manureOrShovelableOutput;
}
