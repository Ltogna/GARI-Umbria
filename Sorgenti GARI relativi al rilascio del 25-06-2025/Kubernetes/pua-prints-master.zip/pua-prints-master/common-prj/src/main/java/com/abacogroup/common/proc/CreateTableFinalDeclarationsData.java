package com.abacogroup.common.proc;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.jdbi.v3.core.Handle;

import com.abacogroup.common.caller.GetFinalDeclarationsCaller;
import com.abacogroup.common.caller.input.GetDeclOnCropsDataInput;
import com.abacogroup.common.caller.input.GetFinalDeclarationsDataInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.common.code.Codes;
import com.abacogroup.common.dto.DeclOnCropsDTO;
import com.abacogroup.common.dto.FinalDeclarationsDTO;
import com.abacogroup.common.dto.FinalDeclarationsDTO.Document;
import com.abacogroup.common.dto.FinalDeclarationsDTO.Field;
import com.abacogroup.common.dto.FinalDeclarationsDTO.FieldSet;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 *  Carica da microservizio e persiste su h2
 * 	<p>
 *	h2 è gia stato creato dalla proc precedente
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class CreateTableFinalDeclarationsData extends BasePrintProcedure {

	@Override
	public void customExecute(ProcessData processData, ProcedureEnvironment procedureEnvironment) throws Exception {
		
		GetFinalDeclarationsCaller getFinalDeclarationsDataCaller = new GetFinalDeclarationsCaller(this.genericCallerService);
		
		DataInputParams inputParams = getDefaultDataInputParams();
		
		FinalDeclarationsDTO dto= null;
		
		try {
			
			dto = getFinalDeclarationsDataCaller.makeCall(new GetFinalDeclarationsDataInput(
					procedureEnvironment, inputParams));
			
		} catch (Exception e) {
			log.debug(e.getCause().getMessage(), e);
			return;
		}

		log.debug("FinalDeclarationsDTO: {}", dto);
		
		Document doc = null;
		String fieldValue = null;
		String  fieldCode = null;
		String  fieldLabel = null;
		Map<String, Object> docFields = null;
		
		try (Handle handle = jdbi.open()) {
			for (FieldSet fieldSet : dto.getDocumentDefinition().getFieldSets()) {
				for (Field field : fieldSet.getFields()) {
					
					doc = dto.getDocument();
					fieldCode = field.getCode();
					fieldLabel = field.getLabel().getIt();
					docFields = doc != null ? doc.getFields() : Collections.emptyMap();
					fieldValue = String.valueOf(docFields.containsKey(fieldCode)? docFields.get(fieldCode) : 0).trim();
					fieldValue = "1".equals(fieldValue) ? "si" : "no"; 
									
					handle.createUpdate(
						"INSERT INTO FINAL_DECLARATIONS (APPLICATION_ID, FIELD_CODE, FIELD_LABEL, FIELD_VALUE) "
						+ "VALUES (:APPLICATION_ID, :FIELD_CODE, :FIELD_LABEL, :FIELD_VALUE)")
				.bind("APPLICATION_ID", this.applicationId) 
				.bind("FIELD_CODE", fieldCode)
				.bind("FIELD_LABEL", fieldLabel) 
				.bind("FIELD_VALUE", fieldValue) 
					.execute();
				}
			}
			
		} catch (Exception e) {
			log.error(String.format("An error occurred inserting application data for application id %s", applicationId), e);
		}
	}
}
