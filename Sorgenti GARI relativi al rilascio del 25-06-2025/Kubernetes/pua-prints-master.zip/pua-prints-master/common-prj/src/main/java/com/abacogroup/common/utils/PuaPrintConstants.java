package com.abacogroup.common.utils;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class PuaPrintConstants {
	
	private PuaPrintConstants() {
	}

}
