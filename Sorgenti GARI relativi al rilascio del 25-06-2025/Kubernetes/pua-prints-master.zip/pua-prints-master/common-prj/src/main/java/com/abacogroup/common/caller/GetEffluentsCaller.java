package com.abacogroup.common.caller;

import java.util.List;

import com.abacogroup.common.caller.input.GetEffluentsDataInput;
import com.abacogroup.common.dto.EffluentDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetEffluentsCaller extends AbacoDtoCaller<GetEffluentsDataInput, List<EffluentDTO>> {

	public GetEffluentsCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
