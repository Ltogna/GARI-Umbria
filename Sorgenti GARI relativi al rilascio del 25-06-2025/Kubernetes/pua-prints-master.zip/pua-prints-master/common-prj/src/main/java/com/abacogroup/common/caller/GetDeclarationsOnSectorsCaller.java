package com.abacogroup.common.caller;

import java.util.List;

import com.abacogroup.common.caller.input.GetDeclarationsOnSectorsDataInput;
import com.abacogroup.common.dto.DeclarationsOnSectorsDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetDeclarationsOnSectorsCaller extends AbacoDtoCaller<GetDeclarationsOnSectorsDataInput, List<DeclarationsOnSectorsDTO>> {

	public GetDeclarationsOnSectorsCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
