package com.abacogroup.common.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Emanuele Crocilla
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class OrganicFertilizerSpreadingDeclarationLanduseDTO {

	private String plotId;
	
    private String declarationCode;
    
    private String plotDescription;
    
    private String landUseCode;
    
	private String landUseDescription;
	
	private Integer plotAreaSqm;
	
	private Double plotAreaPerc;
	
	private BigDecimal plotTotalHectar;
}
