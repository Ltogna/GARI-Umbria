package com.abacogroup.common.caller.input;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.abacogroup.applicationworkflowsdk.model.Constants;
import com.abacogroup.common.caller.input.AnimalHousingRequest.AnimalHousingRequestElement;
import com.abacogroup.common.caller.partyregistry.input.BaseDataInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import io.dropwizard.auth.AuthenticationException;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@EqualsAndHashCode(callSuper = true)
public class AnimalsHousingDataInput extends BaseDataInput {
	
    public AnimalsHousingDataInput(ProcedureEnvironment procedureEnvironment, DataInputParams inputParams) throws AuthenticationException {
        super(procedureEnvironment, inputParams);
    }

    @Override
    public Map<String, Object> getPathVariablesMap() {
        return Map.of(Constants.TENANT, this.tenant);
    }

    @Override public Map<String, Object> getQueryParamsMap() {
        return Collections.emptyMap();
    }

    @Override public String provideAuthToken() {
        return this.authToken;
    }
    
    @Override
	public List<AnimalHousingRequestElement> providePayload() {
    	return (List<AnimalHousingRequestElement>) this.payload;
	}

    @Override public String getUrl() {
    	// https://umbria-dev.fe.abacogroup.eu/banche-dati/master/public/v1/animals/species/housing
        return this.bancheDatiUrl + "/{TENANT}/public/v1/animals/species/housing";
    }

    @Override public String getHttpMethod() {
        return GenericCallerService.POST_METHOD;
    }

    @Override public String locale() {
        return this.locale;
    }

}
