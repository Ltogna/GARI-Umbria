package com.abacogroup.common.proc;

import com.abacogroup.common.dto.UnifiedPrintInput;
import com.abacogroup.printengine.sdk.proc.AbstractInputParamProcedure;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;

public class ValidateParamProcedure extends AbstractInputParamProcedure<UnifiedPrintInput> {

	public static final String PARAM_NAME = "ReportParams";

	@Override
	public UnifiedPrintInput convertDto(ObjectMapper mapper, Map<String, Object> params) {
		return mapper.convertValue(params, UnifiedPrintInput.class);
	}

	@Override
	protected String getParamDto() {
		return PARAM_NAME;
	}
}
