package com.abacogroup.common.proc;

import java.util.ArrayList;
import java.util.List;

import org.jdbi.v3.core.Handle;

import com.abacogroup.common.caller.GetAnimalsCategoriesCaller;
import com.abacogroup.common.caller.GetAnimalsCategoriesCaller.AnimalsCategoriesMap;
import com.abacogroup.common.caller.GetAnimalsHousingCaller;
import com.abacogroup.common.caller.GetAnimalsHousingCaller.AnimalsHousingMap;
import com.abacogroup.common.caller.GetAnimalsSpeciesCaller;
import com.abacogroup.common.caller.GetAnimalsSpeciesCaller.AnimalsSpeciesMap;
import com.abacogroup.common.caller.GetDeclLivestocksConstistCaller;
import com.abacogroup.common.caller.input.AnimalCategoryRequest;
import com.abacogroup.common.caller.input.AnimalHousingRequest;
import com.abacogroup.common.caller.input.AnimalsCategoriesDataInput;
import com.abacogroup.common.caller.input.AnimalsHousingDataInput;
import com.abacogroup.common.caller.input.AnimalsSpeciesDataInput;
import com.abacogroup.common.caller.input.GetDeclLivestocksConstistDataInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.common.code.Codes;
import com.abacogroup.common.dto.DeclOnCropLiveStocksDTO;
import com.abacogroup.common.utils.DbUtils;
import com.abacogroup.common.utils.PuaProfile;
import com.abacogroup.common.utils.Utils;
import com.abacogroup.common.utils.Utils.NumberPattern;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 *  Carica da microservizio e persiste su h2
 * 	<p>
 *	h2 è gia stato creato dalla proc precedente
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class CreateTableDeclLivestocksConsistData extends BasePrintProcedure {

	@Override
	public void customExecute(ProcessData processData, ProcedureEnvironment procedureEnvironment) throws Exception {
		
		// we have to check if the profile is a "PUA_ALLEVAMENTI" one
		// (with TipologiaDichiarazione.flOrganicFert = true and TipologiaDichiarazione.flLivestocks = false)
		PuaProfile profile = DbUtils.getPuaProfile(jdbi, applicationId);

		List<DeclOnCropLiveStocksDTO> result = new ArrayList<>();
		
		if (PuaProfile.PUA_ALLEVAMENTI.equals(profile)) {
			
			GetDeclLivestocksConstistCaller getDeclLivestocksConstistCaller = new GetDeclLivestocksConstistCaller(this.genericCallerService);
			
			DataInputParams inputParams = getDefaultDataInputParams();
			
			try {
				
				String nextKey = null;
				InfiniteListResultsImpl<DeclOnCropLiveStocksDTO> res = null;
				
				do {
					
					res = getDeclLivestocksConstistCaller.makeCall(new GetDeclLivestocksConstistDataInput(
									procedureEnvironment, inputParams, nextKey));
					
					nextKey = res.getNextKey();
					
					result.addAll(res.getRecords());
				} 
				while(nextKey != null);

			} catch (Exception e) {
				log.error("Unable to fethch DeclOnCropLiveStocks elements by service", e);
				return;
			}

			log.debug("DeclOnCropLiveStocksDTO's: {}", result);
			
			GetAnimalsSpeciesCaller animalSpeciesCaller = new GetAnimalsSpeciesCaller(genericCallerService);
			GetAnimalsCategoriesCaller animalsCategoriesCaller = new GetAnimalsCategoriesCaller(genericCallerService);
			GetAnimalsHousingCaller animalsHousingCaller = new GetAnimalsHousingCaller(genericCallerService);
			
			AnimalsSpeciesMap animalsSpeciesMap = 
					animalSpeciesCaller.makeCallAndGetAsMap(new AnimalsSpeciesDataInput(procedureEnvironment, inputParams));
			
			// Animal Category payload creation
			var animalCategoryRequest = new AnimalCategoryRequest();
			animalsSpeciesMap.getAnimalSpecies().forEach(animalsSpecie ->
				animalCategoryRequest.addElement(animalsSpecie.getGenreCode(), animalsSpecie.getCode()));
			 
			inputParams.setPayload(animalCategoryRequest.getElements());
			
			AnimalsCategoriesMap animalsCategoriesMap = 
					animalsCategoriesCaller.makeCallAndGetAsMap(new AnimalsCategoriesDataInput(procedureEnvironment, inputParams));
			
			
			// Animal Housing payload creation
			var animalHousingRequest = new AnimalHousingRequest();
			animalsCategoriesMap.getAnimalCategories().forEach(animalsCategory ->
				animalHousingRequest.addElement(
						animalsCategory.getSpecieCode(), 
						animalsCategory.getGenreCode(), 
						animalsCategory.getCode(), 
						animalsCategory.getProductionCode()));

			inputParams.setPayload(animalHousingRequest.getElements());
			
			AnimalsHousingMap animalsHousingMap = 
					animalsHousingCaller.makeCallAndGetAsMap(new AnimalsHousingDataInput(procedureEnvironment, inputParams));
			
			
			insertInTableDeclLivestocksConsist(result, animalsSpeciesMap, animalsCategoriesMap, animalsHousingMap);
		}
	}

	private void insertInTableDeclLivestocksConsist(List<DeclOnCropLiveStocksDTO> dtos,
									                AnimalsSpeciesMap animalSpeciesMap, 
									                AnimalsCategoriesMap animalCategoriesMap, 
									                AnimalsHousingMap animalHousingMap) {
		
		try (Handle handle = jdbi.open()) {

			for (DeclOnCropLiveStocksDTO dto : dtos) {

				handle.createUpdate("""
								INSERT INTO DECLARATIONS_LIVESTOCKS_CONSISTENCE (
								    APPLICATION_ID,
								    ANIMAL_SPECIES,
								    ANIMAL_CATEGORY,
								    HOUSING_SYSTEM,
								    HEAD_OF_LIVESTOCK_NUMB,
								    NUMBER_IN_THE_FIELD,
								    AVERAGE_LIVE_WEIGHT,
								    LIQUID_EFFL_LEAVING_STABLE,
								    SOLID_EFFLUENT_LEAVING_STABLE
								) VALUES (
								    :APPLICATION_ID,
								    :ANIMAL_SPECIES,
								    :ANIMAL_CATEGORY,
								    :HOUSING_SYSTEM,
								    :HEAD_OF_LIVESTOCK_NUMB,
								    :NUMBER_IN_THE_FIELD,
								    :AVERAGE_LIVE_WEIGHT,
								    :LIQUID_EFFL_LEAVING_STABLE,
								    :SOLID_EFFLUENT_LEAVING_STABLE
								)
						""")
				.bind("APPLICATION_ID", this.applicationId)
				.bind("ANIMAL_SPECIES", animalSpeciesMap.getAnimalSpecieDescriptionByAnimalSpecieCode(dto.getSpecies())) 
				.bind("ANIMAL_CATEGORY", animalCategoriesMap.getAnimalCategoryDescriptionByAnimalCategoryCode(dto.getCategory())) 
//				.bind("HOUSING_SYSTEM", animalHousingMap.getAnimalHousingDescriptionByAnimalSpecie(dto)) 
				.bind("HOUSING_SYSTEM", animalHousingMap.getAnimalHousingDescriptionByAnimalTypeStablingCode(dto.getTypeStabling())) 
				.bind("HEAD_OF_LIVESTOCK_NUMB", dto.getNumberHeadsRaised()) 
				.bind("NUMBER_IN_THE_FIELD", Utils.formatNumbAndGetAsString(dto.getNumberField(), NumberPattern.PATTERN_INT)) 
				.bind("AVERAGE_LIVE_WEIGHT", Utils.formatNumbAndGetAsString(dto.getAveragePV(), NumberPattern.PATTERN_INT)) 
				.bind("LIQUID_EFFL_LEAVING_STABLE", Utils.formatNumbAndGetAsString(dto.getSewageOutlet(), NumberPattern.PATTERN_INT)) 
				.bind("SOLID_EFFLUENT_LEAVING_STABLE", Utils.formatNumbAndGetAsString(dto.getManureOrShovelableOutput(), NumberPattern.PATTERN_INT)) 
				.execute();
			}

		} catch (Exception e) {
			log.error(String.format("An error occurred inserting application data for application id %s", applicationId), e);
		}
	}
}
