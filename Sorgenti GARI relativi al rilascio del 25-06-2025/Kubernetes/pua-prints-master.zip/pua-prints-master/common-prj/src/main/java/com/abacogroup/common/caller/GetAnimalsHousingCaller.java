package com.abacogroup.common.caller;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abacogroup.common.caller.input.AnimalsHousingDataInput;
import com.abacogroup.common.dto.AnimalHousingDTO;
import com.abacogroup.common.dto.DeclOnCropLiveStocksDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetAnimalsHousingCaller extends AbacoDtoCaller<AnimalsHousingDataInput, List<AnimalHousingDTO>> {
	
	public GetAnimalsHousingCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

	public AnimalsHousingMap makeCallAndGetAsMap(AnimalsHousingDataInput i) {
		Map<String, AnimalHousingDTO> map = new HashMap<>();
		List<AnimalHousingDTO> productTypeDTOs = this.makeCall(i);
		productTypeDTOs.forEach(c -> map.put(c.getCode(), c));
		return new AnimalsHousingMap(map);
	}
	
	public class AnimalsHousingMap {

		private Map<String, AnimalHousingDTO> map = new HashMap<>();

		private AnimalsHousingMap(Map<String, AnimalHousingDTO> map) {
			this.map = map;
		}

		public String getAnimalHousingDescriptionByAnimalTypeStablingCode(String typeStablingcode) {
			if (null != typeStablingcode) {
				for (AnimalHousingDTO animalHousing : this.map.values()) {
					if (animalHousing.getCode().equals(typeStablingcode)) {
						return animalHousing.getDescription();
					}
				}
			}
			return null;
		}
		
		public String getAnimalHousingDescriptionByAnimalSpecie(DeclOnCropLiveStocksDTO dto) {
			if (null != dto) {
				for (AnimalHousingDTO animalHousing : this.map.values()) {
					String genre = dto.getSpecies().split("_")[0];
					String specie = dto.getSpecies().split("_")[1];
					boolean hasSameGenre = animalHousing.getGenreCode().equals(genre);
					boolean hasSameSpecie = animalHousing.getSpecieCode().equals(specie);
					boolean hasSameCategory = animalHousing.getCategoryCode().equals(dto.getCategory());
					boolean hasSameAnimalHousingCode = animalHousing.getCode().equals(dto.getTypeStabling());
					if (hasSameAnimalHousingCode || (hasSameCategory && hasSameGenre && hasSameSpecie)) {
						return animalHousing.getDescription();
					}
				}
			}
			return null;
		}
		
		public Collection<AnimalHousingDTO> getAnimalHousing(){
			return this.map.values();
		}
	}
}
