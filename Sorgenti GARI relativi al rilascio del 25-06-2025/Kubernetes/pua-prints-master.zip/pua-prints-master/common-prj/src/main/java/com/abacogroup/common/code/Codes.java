package com.abacogroup.common.code;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class Codes {

	private Codes() {
	}

	public static final String APPLICATIONS_URL_KEY = "applications-url";
	public static final String APPLICATION_FORMS_URL_KEY = "application-forms-url";
	public static final String PARTY_REGISTRY_URL_KEY = "party-registry-url";
	public static final String PUA_APPLICATION_FORMS_URL_KEY = "puaAppFormsUrl";
	public static final String LPIS_SERVER_URL_KEY = "lpisServerUrl";
	public static final String BANCHE_DATI_URL_KEY = "bancheDatiUrl";
	public static final String CROP_PLAN_URL_KEY = "cropPlanUrl";
	public static final String DEFAULT_LOCALE = "it";
	
}
