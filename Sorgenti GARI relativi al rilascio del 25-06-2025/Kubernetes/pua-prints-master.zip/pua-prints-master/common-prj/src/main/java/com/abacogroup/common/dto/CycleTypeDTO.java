package com.abacogroup.common.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CycleTypeDTO {

	@JsonProperty("Ciclo_Des")
	private String description;

	@JsonProperty("Ciclo_Cod")
	private Integer code;
}
