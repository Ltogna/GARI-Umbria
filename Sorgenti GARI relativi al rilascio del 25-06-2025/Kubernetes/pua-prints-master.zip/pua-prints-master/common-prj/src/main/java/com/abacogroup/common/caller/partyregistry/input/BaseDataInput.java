package com.abacogroup.common.caller.partyregistry.input;

import static com.abacogroup.common.code.Codes.APPLICATIONS_URL_KEY;
import static com.abacogroup.common.code.Codes.APPLICATION_FORMS_URL_KEY;
import static com.abacogroup.common.code.Codes.BANCHE_DATI_URL_KEY;
import static com.abacogroup.common.code.Codes.CROP_PLAN_URL_KEY;
import static com.abacogroup.common.code.Codes.LPIS_SERVER_URL_KEY;
import static com.abacogroup.common.code.Codes.PARTY_REGISTRY_URL_KEY;
import static com.abacogroup.common.code.Codes.PUA_APPLICATION_FORMS_URL_KEY;

import com.abacogroup.applicationworkflowsdk.environment.MissingObjectFromEnvironmentException;
import com.abacogroup.applicationworkflowsdk.model.Constants;
import com.abacogroup.common.caller.input.BaseApplicationsInput;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * @author Alexandru Paraschiv
 * @author Emanuele Crocilla
 */
@Data
@SuperBuilder
public abstract class BaseDataInput extends BaseApplicationsInput {
	
	@NotNull
	protected String partyRegistryUrl;

	@NotNull
	protected String puaAppFormsUrl;

	@NotNull
	protected String lpisServerUrl;
	
	@NotNull
	protected String bancheDatiUrl;

	@NotNull
	protected String cropPlanUrl;

	@NotNull
	protected String applicationsUrl;

	protected Object payload;

	protected BaseDataInput(ProcedureEnvironment procedureEnvironment, DataInputParams inputParams){
		
		super(inputParams.tenant, inputParams.partyId, inputParams.applicationId, 
				inputParams.authToken, inputParams.locale, procedureEnvironment);
		
		this.applicationsUrl = procedureEnvironment.getProperty(APPLICATIONS_URL_KEY).map(Object::toString)
				.orElseThrow(() -> new MissingObjectFromEnvironmentException(APPLICATION_FORMS_URL_KEY));
		
		this.partyRegistryUrl = procedureEnvironment.getProperty(PARTY_REGISTRY_URL_KEY).map(Object::toString)
				.orElseThrow(() -> new MissingObjectFromEnvironmentException(PARTY_REGISTRY_URL_KEY));

		this.puaAppFormsUrl = procedureEnvironment.getProperty(PUA_APPLICATION_FORMS_URL_KEY).map(Object::toString)
				.orElseThrow(() -> new MissingObjectFromEnvironmentException(PUA_APPLICATION_FORMS_URL_KEY));

		this.lpisServerUrl = procedureEnvironment.getProperty(LPIS_SERVER_URL_KEY).map(Object::toString)
				.orElseThrow(() -> new MissingObjectFromEnvironmentException(LPIS_SERVER_URL_KEY));

		this.bancheDatiUrl = procedureEnvironment.getProperty(BANCHE_DATI_URL_KEY).map(Object::toString)
				.orElseThrow(() -> new MissingObjectFromEnvironmentException(BANCHE_DATI_URL_KEY));

		this.cropPlanUrl = procedureEnvironment.getProperty(CROP_PLAN_URL_KEY).map(Object::toString)
				.orElseThrow(() -> new MissingObjectFromEnvironmentException(CROP_PLAN_URL_KEY));
		
		this.authToken = Constants.AUTHORIZATION_PREFIX + inputParams.authToken;
		this.tenant = inputParams.tenant;
		this.partyId = inputParams.partyId;
		this.applicationId = inputParams.applicationId;
		this.locale = inputParams.locale;
		this.payload = inputParams.payload;
	}

	@Override
	public String locale() {
		return locale;
	}
}
