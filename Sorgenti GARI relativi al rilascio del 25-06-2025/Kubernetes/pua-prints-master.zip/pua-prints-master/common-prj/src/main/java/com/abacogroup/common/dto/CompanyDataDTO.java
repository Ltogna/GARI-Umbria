package com.abacogroup.common.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
 
/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompanyDataDTO {
	
    private int id;
    private String partyType;
    private String gender;
    private String lastName;
    private String firstName;
    private String taxCode;
    private String vatNumber;
    private String code;
    private String legalStatus;
    private String birthDate;
    private String deathDate;
    private String birthMunicipality;
    private MunicipalityDetail birthMunicipalityDetail;
    private String nationality;
    private Address addressResidential;
    private Address addressHome;
    private Address addressBilling;
    private List<String> tags;
    private boolean archived;
    private ExternalSource externalSource;

    @Builder
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Address {
        private int id;
        private String municipality;
        private String locality;
        private String street;
        private String houseNumber;
        private String postcode;
        private String details;
        private String note;
        private String municipalityI18nCode;
        private MunicipalityDetail municipalityDetail;
    }

    @Builder
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class MunicipalityDetail {
        private String code;
        private String tenantId;
        private String districtCode;
        private String shortDescr;
        private boolean active;
        private String i18nName;
        private District district;
    }

    @Builder
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class District {
        private String code;
        private String tenantId;
        private String regionCode;
        private String shortDescr;
        private boolean active;
        private String i18nName;
        private Region region;
    }

    @Builder
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Region {
        private String code;
        private String tenantId;
        private String countryCode;
        private String shortDescr;
        private boolean active;
        private String i18nName;
        private Country country;
    }

    @Builder
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Country {
        private String code;
        private String tenantId;
        private boolean active;
        private String i18nName;
    }

    @Builder
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ExternalSource {
        private String code;
        private boolean allowManual;
        private String description;
    }
}
