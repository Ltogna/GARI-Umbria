package com.abacogroup.common.caller;

import java.util.List;

import com.abacogroup.common.caller.input.GetFiveYearDeclarationDataInput;
import com.abacogroup.common.dto.FiveYearDeclarationDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetFiveYearDeclarationCaller extends AbacoDtoCaller<GetFiveYearDeclarationDataInput, List<FiveYearDeclarationDTO>> {

	public GetFiveYearDeclarationCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
