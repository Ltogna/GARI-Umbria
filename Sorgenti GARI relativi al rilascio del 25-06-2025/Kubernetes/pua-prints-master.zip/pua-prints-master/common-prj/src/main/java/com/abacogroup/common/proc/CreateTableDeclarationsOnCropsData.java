package com.abacogroup.common.proc;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.jdbi.v3.core.Handle;

import com.abacogroup.common.caller.GetCycleTypesCaller;
import com.abacogroup.common.caller.GetCycleTypesCaller.CycleTypesMap;
import com.abacogroup.common.caller.GetDeclOnCropsCaller;
import com.abacogroup.common.caller.GetLandusesCaller;
import com.abacogroup.common.caller.GetProductTypesCaller;
import com.abacogroup.common.caller.GetProductTypesCaller.ProductTypesMap;
import com.abacogroup.common.caller.GetSectorsCaller;
import com.abacogroup.common.caller.input.GetCycleTypesDataInput;
import com.abacogroup.common.caller.input.GetDeclOnCropsDataInput;
import com.abacogroup.common.caller.input.GetLandusesDataInput;
import com.abacogroup.common.caller.input.GetProductTypesDataInput;
import com.abacogroup.common.caller.input.GetSectorsDataInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.common.code.Codes;
import com.abacogroup.common.dto.DeclOnCropsDTO;
import com.abacogroup.common.dto.LandusesDTO;
import com.abacogroup.common.dto.LandusesDTO.LandUse;
import com.abacogroup.common.dto.SectorsDTO.Sector;
import com.abacogroup.common.dto.SectorsDTO;
import com.abacogroup.common.utils.DbUtils;
import com.abacogroup.common.utils.PuaProfile;
import com.abacogroup.common.utils.Utils;
import com.abacogroup.common.utils.Utils.NumberPattern;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 *  Carica da microservizio e persiste su h2
 * 	<p>
 *	h2 è gia stato creato dalla proc precedente
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class CreateTableDeclarationsOnCropsData extends BasePrintProcedure {

	@Override
	public void customExecute(ProcessData processData, ProcedureEnvironment procedureEnvironment) throws Exception {
		
		// we have to check if the profile is:
		//
		// "FERT_ORGANICI": with TipologiaDichiarazione.flOrganicFert = true 
		//					and 
		//					TipologiaDichiarazione.flLivestocks = false
		// or 
		//
		// "PUA_ALLEVAMENTI": with TipologiaDichiarazione.flOrganicFert = true 
		//					  and 
		//					  TipologiaDichiarazione.flLivestocks = true
		PuaProfile profile = DbUtils.getPuaProfile(jdbi, applicationId);

		List<DeclOnCropsDTO> dtos = null;
		Map<String, LandUse> landUsesMap = null;
		
		if (PuaProfile.PUA_FERTILIZZANTI_ORGANICI.equals(profile) || PuaProfile.PUA_ALLEVAMENTI.equals(profile)) {
			
			GetDeclOnCropsCaller getDeclarationsOnCropsDataCaller = new GetDeclOnCropsCaller(this.genericCallerService);
			
			DataInputParams inputParams = getDefaultDataInputParams();
			
			
			try {
				
				dtos = getDeclarationsOnCropsDataCaller.makeCall(new GetDeclOnCropsDataInput(
						procedureEnvironment, inputParams));
				
			} catch (Exception e) {
				log.error("Unable to fethch DeclOnCrops elements by service", e);
				return;
			}

			log.debug("DeclOnCropsDTO's: {}", dtos);
			
			GetSectorsCaller getSectorsCaller = new GetSectorsCaller(this.genericCallerService);
			List<String> sectorCodes = new ArrayList<>(dtos.size());
			dtos.forEach(dto -> sectorCodes.add(dto.getSectorCode()));
			inputParams.setPayload(sectorCodes);
			SectorsDTO sectors = getSectorsCaller.makeCall(new GetSectorsDataInput(procedureEnvironment, inputParams));
			Map<String, Sector> sectorsMap = sectors.getSectorsAsMap();
			
			GetCycleTypesCaller cycleTypesCaller = new GetCycleTypesCaller(genericCallerService);
			CycleTypesMap cycleTypesMap = 
					cycleTypesCaller.makeCallAndGetAsMap(new GetCycleTypesDataInput(procedureEnvironment, inputParams));

			GetLandusesCaller getLandusesCaller = new GetLandusesCaller(this.genericCallerService);
			List<String> landUseCodes = new ArrayList<>(dtos.size());
			dtos.forEach(dto -> landUseCodes.add(dto.getLandUseCode()));
			inputParams.setPayload(landUseCodes);
			LandusesDTO landUses = getLandusesCaller.makeCall(new GetLandusesDataInput(procedureEnvironment, inputParams));
			landUsesMap = landUses.getLandUsesAsMap();
			
			GetProductTypesCaller productTypesCaller = new GetProductTypesCaller(genericCallerService);
			ProductTypesMap productTypeMap = 
					productTypesCaller.makeCallAndGetAsMap(new GetProductTypesDataInput(procedureEnvironment, inputParams));
			
			insertInTableDeclOnCrops(profile, dtos, landUsesMap, cycleTypesMap, productTypeMap, sectorsMap);
		}
		
		if (PuaProfile.PUA_FERTILIZZANTI_ORGANICI.equals(profile)) {
			insertInTableDeclOnCropsPrevEffluents(dtos, landUsesMap);
		}
		else if (PuaProfile.PUA_ALLEVAMENTI.equals(profile)) {
			insertInTableDeclOnCropsLivestocks(dtos, landUsesMap);
		}
	}
	
	// TODO EC to finish..
	private void insertInTableDeclOnCropsPrevEffluents(List<DeclOnCropsDTO> dtos, Map<String, LandUse> landUsesMap) {
		
	}
	
	// TODO EC to finish..
	private void insertInTableDeclOnCropsLivestocks(List<DeclOnCropsDTO> dtos, Map<String, LandUse> landUsesMap) {

	}

	private void insertInTableDeclOnCrops(PuaProfile profile, List<DeclOnCropsDTO> dtos, 
			Map<String, LandUse> landUsesMap, CycleTypesMap cycleTypesMap, 
				ProductTypesMap productTypeMap, Map<String, Sector> sectorsMap) {
		
		try (Handle handle = jdbi.open()) {

			String cycleDescription = null;
			String typologyDescription = null;
			LandUse landUseCode = null;
			BigDecimal areaInHectar = null;
			BigDecimal totalNitrogen = null;

			for (DeclOnCropsDTO dto : dtos) {

				landUseCode = landUsesMap.getOrDefault(dto.getLandUseCode(), null);
				areaInHectar = BigDecimal.valueOf(dto.getAreaSqm()).divide(BigDecimal.valueOf(10000));
				cycleDescription = cycleTypesMap.getDescriptionByCode(dto.getCycle());
				typologyDescription = productTypeMap.getProductTypeDescrDescriptionByProductTypeCode(dto.getTypology());
				totalNitrogen = dto.getTotalNitrogen().divide(BigDecimal.valueOf(10000));
				 
				handle.createUpdate("""
								INSERT INTO DECL_ON_CROPS (
								    APPLICATION_ID, PLAN_ID, PLOT_CODE, DECL_CODE, "VERSION", LAND_USE, 
								    VEGETAL_SPECIES, PREVIOUS_FERT,
								    FL_ZVN, AREA_SQM, CROP_DURATION, PLANT_STATUS, "CYCLE", TYPOLOGY, 
								    YIELD, MAS, PRECESSION, COMUNE, 
								    DISTRIBUTABLE_NITROGEN, TOTAL_NITROGEN, DECL_PRINT_TYPE
								) VALUES (
								    :APPLICATION_ID, :PLAN_ID, :PLOT_CODE, :DECL_CODE, :VERSION, :LAND_USE, 
								    :VEGETAL_SPECIES, :PREVIOUS_FERT, 
								    :FL_ZVN, :AREA_SQM, :CROP_DURATION, :PLANT_STATUS, :CYCLE, :TYPOLOGY, 
								    :YIELD, :MAS, :PRECESSION, :COMUNE,
								    :DISTRIBUTABLE_NITROGEN, :TOTAL_NITROGEN, :DECL_PRINT_TYPE
								)
						""")
				.bind("APPLICATION_ID", dto.getApplicationId())
				.bind("LAND_USE", dto.getPlotDescription())
				.bind("VEGETAL_SPECIES", landUseCode.getDescription())
				.bind("AREA_SQM", Utils.formatNumbAndGetAsString(areaInHectar, NumberPattern.PATTERN_DECIMAL))
				.bind("PLAN_ID", dto.getPlanId())
				.bind("PLOT_CODE", dto.getPlotCode())
				.bind("DECL_CODE", dto.getDeclCode())
				.bind("VERSION", dto.getDeclarationVersion())
				.bind("FL_ZVN", dto.isFlZvn())
				.bind("CROP_DURATION", dto.getCropDuration())
				.bind("PLANT_STATUS", dto.getPlantStatus())
				.bind("CYCLE", cycleDescription)
				.bind("TYPOLOGY", typologyDescription)
				.bind("YIELD", Utils.formatNumbAndGetAsString(dto.getYield(), NumberPattern.PATTERN_DECIMAL_2))
				.bind("MAS", Utils.formatNumbAndGetAsString(dto.getMas(), NumberPattern.PATTERN_INT))
				.bind("PRECESSION", dto.getPrecessionDescription())
				.bind("COMUNE", sectorsMap.get(dto.getSectorCode()).getDescription())
				.bind("DISTRIBUTABLE_NITROGEN", Utils.formatNumbAndGetAsString(dto.getDistributableNitrogen(), NumberPattern.PATTERN_DECIMAL_2))
				.bind("TOTAL_NITROGEN", Utils.formatNumbAndGetAsString(totalNitrogen, NumberPattern.PATTERN_DECIMAL_2))
				.bind("PREVIOUS_FERT", Utils.formatNumbAndGetAsString(dto.getTotResidualNitrogen(), NumberPattern.PATTERN_DECIMAL_2))
				.bind("DECL_PRINT_TYPE", profile.name())
				.execute();
			}

		} catch (Exception e) {
			log.error(String.format("An error occurred inserting application data for application id %s", applicationId), e);
		}
	}
}
