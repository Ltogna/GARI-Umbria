package com.abacogroup.common.caller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abacogroup.common.caller.input.GetProductTypesDataInput;
import com.abacogroup.common.dto.ProductTypeDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetProductTypesCaller extends AbacoDtoCaller<GetProductTypesDataInput, List<ProductTypeDTO>> {
	
	public GetProductTypesCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

	public ProductTypesMap makeCallAndGetAsMap(GetProductTypesDataInput i) {
		Map<String, ProductTypeDTO> map = new HashMap<>();
		List<ProductTypeDTO> productTypeDTOs = this.makeCall(i);
		productTypeDTOs.forEach(c -> map.put(c.getProductTypeCode(), c));
		return new ProductTypesMap(map);
	}
	
	public class ProductTypesMap {

		private Map<String, ProductTypeDTO> map = new HashMap<>();

		private ProductTypesMap(Map<String, ProductTypeDTO> map) {
			this.map = map;
		}

		public String getProductTypeDescrDescriptionByProductTypeCode(String code) {
			if (null != code) {
				for (ProductTypeDTO productType : this.map.values()) {
					if (productType.getProductTypeCode().equals(code)) {
						return productType.getProductTypeDescr();
					}
				}
			}
			return null;
		}
	}
}
