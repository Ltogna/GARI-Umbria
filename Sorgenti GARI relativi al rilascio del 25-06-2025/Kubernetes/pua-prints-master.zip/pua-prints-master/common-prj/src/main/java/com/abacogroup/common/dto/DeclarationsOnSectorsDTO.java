package com.abacogroup.common.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DeclarationsOnSectorsDTO {
	private Long applicationId;
	private String sectorCode;
	private String landUseCode;
	private Integer areaSqm;
	private Integer mas;
	private boolean flZvn;
}
