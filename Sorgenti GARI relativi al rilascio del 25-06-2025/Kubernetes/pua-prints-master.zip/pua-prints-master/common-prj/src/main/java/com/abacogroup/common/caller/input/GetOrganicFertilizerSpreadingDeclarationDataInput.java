package com.abacogroup.common.caller.input;

import java.util.Collections;
import java.util.Map;

import com.abacogroup.applicationworkflowsdk.model.Constants;
import com.abacogroup.common.caller.partyregistry.input.BaseDataInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import io.dropwizard.auth.AuthenticationException;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@EqualsAndHashCode(callSuper = true)
public class GetOrganicFertilizerSpreadingDeclarationDataInput extends BaseDataInput {

    public GetOrganicFertilizerSpreadingDeclarationDataInput(ProcedureEnvironment procedureEnvironment, DataInputParams inputParams) throws AuthenticationException {
        super(procedureEnvironment, inputParams);
    }

    @Override
    public Map<String, Object> getPathVariablesMap() {
        return Map.of(Constants.TENANT, this.tenant,
                Constants.APPLICATION_ID, this.applicationId);
    }

    @Override public Map<String, Object> getQueryParamsMap() {
        return Collections.emptyMap();
    }

    @Override public String provideAuthToken() {
        return this.authToken;
    }

    @Override public String getUrl() {
    	

//    	example: https://umbria-dev.fe.abacogroup.eu/pua-application-forms/master/v1/applications/1361/fert-spreading-declarations
         
        return this.puaAppFormsUrl + "/{TENANT}/v1/applications/{APPLICATION_ID}/fert-spreading-declarations";
    }

    @Override public String getHttpMethod() {
        return GenericCallerService.GET_METHOD;
    }

    @Override public String locale() {
        return this.locale;
    }

}
