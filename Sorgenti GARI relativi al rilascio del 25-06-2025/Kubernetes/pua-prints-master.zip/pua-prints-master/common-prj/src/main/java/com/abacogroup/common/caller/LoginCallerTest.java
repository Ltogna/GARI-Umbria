package com.abacogroup.common.caller;

import com.abacogroup.common.caller.input.LoginInputTest;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

import java.util.Map;

/**
 * @author Alexandru Paraschiv
 */
// FOR DEV TESTS
public class LoginCallerTest extends AbacoDtoCaller<LoginInputTest, Map<String, Object>> {

	public LoginCallerTest(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}

