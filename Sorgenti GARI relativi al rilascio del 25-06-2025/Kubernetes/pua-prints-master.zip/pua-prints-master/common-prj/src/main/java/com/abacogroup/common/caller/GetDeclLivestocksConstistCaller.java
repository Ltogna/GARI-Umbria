package com.abacogroup.common.caller;

import com.abacogroup.common.caller.input.GetDeclLivestocksConstistDataInput;
import com.abacogroup.common.dto.DeclOnCropLiveStocksDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetDeclLivestocksConstistCaller extends AbacoDtoCaller<GetDeclLivestocksConstistDataInput, InfiniteListResultsImpl<DeclOnCropLiveStocksDTO>> {

	public GetDeclLivestocksConstistCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
