package com.abacogroup.common.proc;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdbi.v3.core.Handle;

import com.abacogroup.common.caller.GetEffluentsCaller;
import com.abacogroup.common.caller.GetOrganicFertilizerSpreadingDeclarationCaller;
import com.abacogroup.common.caller.GetSectorsCaller;
import com.abacogroup.common.caller.input.GetEffluentsDataInput;
import com.abacogroup.common.caller.input.GetOrganicFertilizerSpreadingDeclarationDataInput;
import com.abacogroup.common.caller.input.GetSectorsDataInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.common.code.Codes;
import com.abacogroup.common.dto.EffluentDTO;
import com.abacogroup.common.dto.OrganicFertilizerSpreadingDeclarationDTO;
import com.abacogroup.common.dto.SectorsDTO;
import com.abacogroup.common.dto.SectorsDTO.Sector;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import io.dropwizard.auth.AuthenticationException;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 *  Carica da microservizio e persiste su h2
 * 	<p>
 *	h2 è gia stato creato dalla proc precedente
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class CreateTableOrganicFertilizerSpreadingDeclarationData extends BasePrintProcedure {
	
	private static final DateFormat DATEFROMATTER_YYYYMMDD = new SimpleDateFormat("yyyyMMdd");
	private static final DateFormat DATEFROMATTER_DD_MM_YYYY = new SimpleDateFormat("dd/MM/yyyy");

	@Override
	public void customExecute(ProcessData processData, ProcedureEnvironment procedureEnvironment) throws Exception {
		
		GetOrganicFertilizerSpreadingDeclarationCaller getOrganicFertilizerSpreadingDeclarationDataCaller = new GetOrganicFertilizerSpreadingDeclarationCaller(this.genericCallerService);
		
		DataInputParams inputParams = getDefaultDataInputParams();
		
		List<OrganicFertilizerSpreadingDeclarationDTO> dtos = 
				getOrganicFertilizerSpreadingDeclarationDataCaller.makeCall(
						new GetOrganicFertilizerSpreadingDeclarationDataInput(procedureEnvironment, inputParams));

		log.debug("OrganicFertilizerSpreadingDeclarationDTO's: {}", dtos);
		
		
		GetEffluentsCaller getEffluentsCaller = new GetEffluentsCaller(this.genericCallerService);
		List<EffluentDTO> effluents = getEffluentsCaller.makeCall(new GetEffluentsDataInput(procedureEnvironment, inputParams));
		Map<String, EffluentDTO> effluentsMap = new HashMap<>();
		effluents.forEach(effluent -> effluentsMap.put(effluent.getCode(), effluent));
		dtos.forEach(dto -> {
			var eff = effluentsMap.get(dto.getLivestockEffluents());
			dto.setLivestockEffluents(eff!=null? eff.getDescription() : dto.getLivestockEffluents());
		});
		 
		for (OrganicFertilizerSpreadingDeclarationDTO dto : dtos) {
			
			List<String> declCodesList = new ArrayList<>();
			declCodesList.add(dto.getLanduses().iterator().next().getDeclarationCode());
		}
		
		
		Map<String, Sector> sectorsMap = getSectorsMap(procedureEnvironment, inputParams, dtos);
		
		try (Handle handle = jdbi.open()) {
			
			Date date = null;
			String expectedDate = null;
			  
			for (OrganicFertilizerSpreadingDeclarationDTO dto : dtos) {
				
				date = DATEFROMATTER_YYYYMMDD.parse(dto.getExpectedDate());
				expectedDate = DATEFROMATTER_DD_MM_YYYY.format(date);
				
				Sector sector = sectorsMap.getOrDefault(dto.getSectorCode(), null);
				
				handle.createUpdate("""
				INSERT INTO ORGANIC_FERT_SPREADING_DECLARATION (
				    APPLICATION_ID,
					ID,
				    PARTY_ID,
				    CUAA,
				    COMPANY,
				    EXPECTED_DATE,
				    LIVESTOCK_EFFLUENTS,
				    LIVESTOCK_EFFLUENTS_QTY,
				    CROP_PLAN_VERSION,
				    COMUNE
				) VALUES (
				    :APPLICATION_ID,
				    :ID,
				    :PARTY_ID,
				    :CUAA,
				    :COMPANY,
				    :EXPECTED_DATE,
				    :LIVESTOCK_EFFLUENTS,
				    :LIVESTOCK_EFFLUENTS_QTY,
				    :CROP_PLAN_VERSION,
				    :COMUNE
				)
					""")
				.bind("APPLICATION_ID", this.applicationId) 
				.bind("ID", dto.getId()) 
				.bind("PARTY_ID", dto.getPartyId()) 
				.bind("COMPANY", dto.getCompany()) 
				.bind("CUAA", dto.getCuaa()) 
				.bind("EXPECTED_DATE", expectedDate) 
				.bind("LIVESTOCK_EFFLUENTS", dto.getLivestockEffluents()) 
				.bind("LIVESTOCK_EFFLUENTS_QTY", dto.getLivestockEffluentsQty().intValue()) 
				.bind("CROP_PLAN_VERSION", dto.getCropPlanVersion()) 
				.bind("COMUNE", sector != null ? sector.getDescription() : "N/A") 
				.execute();
				
				for (var landuse : dto.getLanduses()) {
					
					handle.createUpdate("""
							INSERT INTO ORGANIC_FERT_SPREADING_DECLARATION_LANDUSE (
							    PARENT_ID,
							    PLOT_ID,
							    PLOT_DESCRIPTION,
							    LANDUSE_CODE,
								LANDUSE_DESCRIPTION,
								PLOT_AREA_SQM,
								PLOT_AREA_PERC,
								PLOT_TOTAL_HECTAR,
								DECLARATION_CODE
							) VALUES (
							    :PARENT_ID,
							    :PLOT_ID,
							    :PLOT_DESCRIPTION,
							    :LANDUSE_CODE,
								:LANDUSE_DESCRIPTION,
								:PLOT_AREA_SQM,
								:PLOT_AREA_PERC,
								:PLOT_TOTAL_HECTAR,
								:DECLARATION_CODE
							)
								""")
							.bind("PARENT_ID", dto.getId()) 
							.bind("PLOT_ID",  landuse.getPlotId()) 
							.bind("PLOT_DESCRIPTION", landuse.getPlotDescription()) 
							.bind("LANDUSE_CODE", landuse.getLandUseCode()) 
							.bind("LANDUSE_DESCRIPTION", landuse.getLandUseDescription())
							.bind("PLOT_AREA_SQM", landuse.getPlotAreaSqm()) 
							.bind("PLOT_AREA_PERC", landuse.getPlotAreaPerc()) 
							.bind("PLOT_TOTAL_HECTAR", landuse.getPlotTotalHectar()) 
							.bind("DECLARATION_CODE", landuse.getDeclarationCode()) 
							.execute();
				}
			}
			
		} catch (Exception e) {
			log.error(String.format("An error occurred inserting application data for application id %s", applicationId), e);
		}
	}

	private Map<String, Sector> getSectorsMap(ProcedureEnvironment procedureEnvironment, DataInputParams inputParams,
			List<OrganicFertilizerSpreadingDeclarationDTO> dtos) throws AuthenticationException {
		
		GetSectorsCaller getSectorsCaller = new GetSectorsCaller(this.genericCallerService);
		List<String> sectorCodes = new ArrayList<>();
		dtos.forEach(dto -> sectorCodes.add(dto.getSectorCode()));
		inputParams.setPayload(sectorCodes);
		SectorsDTO sectors = getSectorsCaller.makeCall(new GetSectorsDataInput(procedureEnvironment, inputParams));
		return sectors.getSectorsAsMap();
	}
	
}
