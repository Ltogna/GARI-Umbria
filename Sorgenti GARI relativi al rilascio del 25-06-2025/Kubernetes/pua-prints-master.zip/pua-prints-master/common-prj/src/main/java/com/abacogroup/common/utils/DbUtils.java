package com.abacogroup.common.utils;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.mapper.reflect.BeanMapper;

import com.abacogroup.common.dto.TipologiaDichiarazioneDTO;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class DbUtils {

	private DbUtils() {
	}

	public static synchronized PuaProfile getPuaProfile(Jdbi jdbi, Long applicationId) {
		
		try (Handle handle = jdbi.open()) {

			TipologiaDichiarazioneDTO tipologiaDichiarazioneDTO =
					handle.createQuery("select * from "
							+ "tipologia_dichiarazione where application_id = :application_id ")
					.bind("application_id", applicationId)
					//					.mapTo(com.abacogroup.common.dto.TipologiaDichiarazioneDTO.class)
					.map(BeanMapper.of(TipologiaDichiarazioneDTO.class))
					.first();
			
			boolean isFlOrganicFert = tipologiaDichiarazioneDTO.isFlOrganicFert();
			boolean isFlLivestocks = tipologiaDichiarazioneDTO.isFlLivestocks();
			
			boolean isPuaSimpleProfile = !isFlOrganicFert && !isFlLivestocks;
			boolean isPuaFertOrganiciProfile = isFlOrganicFert && !isFlLivestocks;
//			boolean isPuaAllevamentiProfile = isFlOrganicFert && isFlLivestocks;

			return isPuaSimpleProfile ? PuaProfile.PUA_SEMPLICE
					: isPuaFertOrganiciProfile ? PuaProfile.PUA_FERTILIZZANTI_ORGANICI 
							: PuaProfile.PUA_ALLEVAMENTI;

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public static synchronized <T> T getByApplicationId(Jdbi jdbi, String tableName, Long applicationId, Class<T> classOfBeanToMap) {
		
		try (Handle handle = jdbi.open()) {

			return handle.createQuery("select * from "
							+ tableName + " where application_id = :application_id ")
					.bind("application_id", applicationId)
					.map(BeanMapper.of(classOfBeanToMap))
					.first();

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public static synchronized <T> T getByApplicationId(Handle handle, String tableName, Long applicationId, Class<T> classOfBeanToMap) {
		
		try {

			return handle.createQuery("select * from "
							+ tableName + " where application_id = :application_id ")
					.bind("application_id", applicationId)
					.map(BeanMapper.of(classOfBeanToMap))
					.first();

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

}
