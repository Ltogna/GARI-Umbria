package com.abacogroup.common.caller.partyregistry.input;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Emanuele Crocilla
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DataInputParams {

	protected String tenant;
	
	protected Long applicationId;
	
	protected Long partyId;
	
	protected String authToken;
	
	protected String partyRegistryUrl;

	protected String puaAppFormsUrl;
	
	protected String locale;
	
	protected Object payload;
 
}
