package com.abacogroup.common.caller;

import com.abacogroup.common.caller.input.GetTipologiaDichiarazioneDataInput;
import com.abacogroup.common.dto.TipologiaDichiarazioneDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetTipologiaDichiarazioneCaller extends AbacoDtoCaller<GetTipologiaDichiarazioneDataInput, TipologiaDichiarazioneDTO> {

	public GetTipologiaDichiarazioneCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
