package com.abacogroup.common.proc;

import org.jdbi.v3.core.Handle;

import com.abacogroup.common.caller.GetTipologiaDichiarazioneCaller;
import com.abacogroup.common.caller.input.GetTipologiaDichiarazioneDataInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.common.code.Codes;
import com.abacogroup.common.dto.TipologiaDichiarazioneDTO;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 *  Carica da microservizio e persiste su h2
 * 	<p>
 *	h2 è gia stato creato dalla proc precedente
 *
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class CreateTableTipologiaDichiarazioneData extends BasePrintProcedure {



	@Override
	public void customExecute(ProcessData processData, ProcedureEnvironment procedureEnvironment)
			throws Exception {
		
		GetTipologiaDichiarazioneCaller getCompanyDataCaller = new GetTipologiaDichiarazioneCaller(this.genericCallerService);
		
		DataInputParams inputParams = getDefaultDataInputParams();
		
		TipologiaDichiarazioneDTO dto = getCompanyDataCaller.makeCall(new GetTipologiaDichiarazioneDataInput(
				procedureEnvironment, inputParams));

		log.debug("TipologiaDichiarazione DTO: {}", dto);
		
		try (Handle handle = jdbi.open()) {
			handle.createUpdate("INSERT INTO TIPOLOGIA_DICHIARAZIONE (APPLICATION_ID, FL_LIVESTOCKS, FL_ORGANIC_FERT, _YEAR) "
					+ "VALUES (:APPLICATION_ID, :FL_LIVESTOCKS, :FL_ORGANIC_FERT, :_YEAR) ")
			.bind("APPLICATION_ID", dto.getApplicationId()) 
			.bind("FL_LIVESTOCKS", dto.isFlLivestocks()) 
			.bind("FL_ORGANIC_FERT", dto.isFlOrganicFert())
			.bind("_YEAR", dto.getYear()) 
			.execute();
			
		} catch (Exception e) {
			log.error(String.format("An error occurred inserting application data for application id %s", applicationId), e);
		}
 
	}
 
}
