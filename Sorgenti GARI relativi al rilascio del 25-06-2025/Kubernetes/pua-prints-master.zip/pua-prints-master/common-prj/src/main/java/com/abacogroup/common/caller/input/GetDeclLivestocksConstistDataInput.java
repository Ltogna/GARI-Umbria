package com.abacogroup.common.caller.input;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.abacogroup.applicationworkflowsdk.model.Constants;
import com.abacogroup.common.caller.partyregistry.input.BaseDataInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import io.dropwizard.auth.AuthenticationException;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@EqualsAndHashCode(callSuper = true)
public class GetDeclLivestocksConstistDataInput extends BaseDataInput {
	
	private String nextKey;

    public GetDeclLivestocksConstistDataInput(ProcedureEnvironment procedureEnvironment, DataInputParams inputParams, String nextKey) throws AuthenticationException {
        super(procedureEnvironment, inputParams);
        this.nextKey = nextKey;
    }

    @Override
    public Map<String, Object> getPathVariablesMap() {
        return Map.of(Constants.TENANT, this.tenant,
                Constants.APPLICATION_ID, this.applicationId);
    }
    
    @Override
	public Map<String, Object> getQueryParamsMap() {
		Map<String, Object> m = new HashMap<>();
		if(this.nextKey != null) {
			m.put("nextKey", this.nextKey);
		}
		return m;
	}

    @Override public String provideAuthToken() {
        return this.authToken;
    }

    @Override public String getUrl() {
    	

//    	example: https://umbria-dev.fe.abacogroup.eu/pua-application-forms/master/v1/applications/:applicationId/declarations-on-crops-livestock-consist
         
        return this.puaAppFormsUrl + "/{TENANT}/v1/applications/{APPLICATION_ID}/declarations-on-crops-livestock-consist";
    }

    @Override public String getHttpMethod() {
        return GenericCallerService.GET_METHOD;
    }

    @Override public String locale() {
        return this.locale;
    }

}
