package com.abacogroup.common.utils;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public enum PuaProfile {

	PUA_SEMPLICE, PUA_FERTILIZZANTI_ORGANICI, PUA_ALLEVAMENTI;

}
