package com.abacogroup.common.devel;

import com.abacogroup.printengine.sdk.proc.H2Procedure;
import com.google.common.io.Files;
import org.apache.commons.io.IOUtils;

import java.io.*;

public class DebugH2Procedure extends H2Procedure {

	private static String DEST_FOLDER = System.getProperty("java.io.tmpdir")+"/report-db";

	@Override
	protected void onConnectionClosed(File fileName) throws Exception {
		copy(fileName.getAbsolutePath() + ".mv.db");
		copy(fileName.getAbsolutePath() + ".trace.db");
	}

	private void copy(String fileName) throws IOException {
		File input = new File(fileName);
		if (input.exists()) {
			File output = new File(DEST_FOLDER, input.getName());
			Files.createParentDirs(output);
			try (InputStream in = new FileInputStream(input); OutputStream out = new FileOutputStream(output)) {
				IOUtils.copy(in, out);
			}
		}
	}

}
