package com.abacogroup.common.dto;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class CropPlanDTO {
	
	@JsonProperty("cropPlanId")
	private int cropPlanId;

	@JsonProperty("cropPlanTypeCode")
	private String cropPlanTypeCode;

	@JsonProperty("cropPlanTypeDescription")
	private String cropPlanTypeDescription;

	@JsonProperty("description")
	private String description;

	@JsonProperty("changesPending")
	private boolean changesPending;

	@JsonProperty("readOnly")
	private boolean readOnly;

	@JsonProperty("locked")
	private boolean locked;

	@JsonProperty("lockedErrorCode")
	private String lockedErrorCode;

	@JsonProperty("canAddPlots")
	private boolean canAddPlots;

	@JsonProperty("cropPlanPrints")
	private List<CropPlanPrint> cropPlanPrints;
 

	// Inner class representing cropPlanPrints array items
	@JsonIgnoreProperties(ignoreUnknown = true)
	@Data
	public static class CropPlanPrint {

		@JsonProperty("code")
		private String code;

		@JsonProperty("description")
		private String description;
 
	}
}
