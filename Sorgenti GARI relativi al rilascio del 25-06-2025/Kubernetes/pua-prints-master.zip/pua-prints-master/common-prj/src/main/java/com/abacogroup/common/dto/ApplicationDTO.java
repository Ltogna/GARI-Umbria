package com.abacogroup.common.dto;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationDTO {

	@Schema(description = "The application id")
	private Long applicationId;
	@Schema(description = "the party id related to current application")
	private Long partyId;
	@Schema(description = "the application's referred year")
	private Integer referredYear;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Long moduleId;
	@Schema(description = "the application's workflow process id")
	private Long processId;

	@Schema(description = "The application code")
	private String applicationCode;
	@Schema(description = "Current process status")
	private String processStatus;
	@Schema(description = "Process status description")
	private String processStatusDescription;
	@Schema(description = "Presentation date")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private String dtPresentation;
	@Schema(description = "Protocol request date")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private String dtProtocolRequest;
	@Schema(description = "Protocol response date")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private String dtProtocolResponse;
	@Schema(description = "Protocol code")
	private String protocolCode;
	@Schema(description = "Sector code")
	private String sectorCode;
	@Schema(description = "Sector description")
	private String sectorDescription;
	@Schema(description = "Module code")
	private String moduleCode;
	@Schema(description = "Module description")
	private String moduleDescription;
	@Schema(description = "Module year")
	private String moduleYear;
	@Schema(description = "List of forms")
	private List<Form> forms;
	@Schema(description = "List of prints")
	private List<Object> prints;
	@Schema(description = "List of profiles")
	private List<Profile> profileList;
	@Schema(description = "Last movement")
	private String lastMovement;
	@Schema(description = "Last movement executed by")
	private String lastMovementUserIdExecutor;
	@Schema(description = "Flag indicating if application is closed")
	private Boolean isClosed;
	@Schema(description = "Party information")
	private Party party;
	@Schema(description = "Amendment application ID")
	private Integer amendmentApplicationId;
	@Schema(description = "Amended application ID")
	private Integer amendedApplicationId;
	@Schema(description = "Original amended application ID")
	private Integer originalAmendedApplicationId;
	@Schema(description = "Calculations")
	private Object calculations;
	@Schema(description = "Application profiles description")
	private String applicationProfilesDescription;
	
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private String userIdInsert;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private String userIdDelete;
	@Schema(description = "the application's date of creation")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dtInsert;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dtDelete;

	@Data
	@SuperBuilder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class Form {
		@Schema(description = "List of groups")
		private List<Group> groups;
		@Schema(description = "Form details")
		private FormDetails formDetails;

		@Data
		@SuperBuilder
		@NoArgsConstructor
		@AllArgsConstructor
		public static class Group {
			@Schema(description = "Group code")
			private String groupCode;
			@Schema(description = "Group name")
			private String groupName;
		}

		@Data
		@SuperBuilder
		@NoArgsConstructor
		@AllArgsConstructor
		public static class FormDetails {
			@Schema(description = "Form configuration ID")
			private Integer formConfigId;
			@Schema(description = "Form code")
			private String formCode;
			@Schema(description = "Form name")
			private String formName;
			@Schema(description = "Software URL")
			private String softwareUrl;
			@Schema(description = "Router URL")
			private String routerUrl;
			@Schema(description = "Read-only flag")
			private Integer flReadOnly;
			@Schema(description = "Sort order")
			private Integer sortOrder;
			@Schema(description = "Compile status identifier")
			private String compileStatusIdentifier;
			@Schema(description = "Compile status")
			private String compileStatus;
			@Schema(description = "Parameters")
			private Map<String, String> params;
			@Schema(description = "Required profiles")
			private List<Object> requiredProfiles;
		}
	}

	@Data
	@SuperBuilder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class Profile {
		@Schema(description = "Profile code")
		private String profileCode;
		@Schema(description = "Profile code description")
		private String profileCodeDescription;
	}

	@Data
	@SuperBuilder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class Party {
		@Schema(description = "Party ID")
		private Integer partyId;
		@Schema(description = "CUAA identifier")
		private String cuaa;
		@Schema(description = "Party description")
		private String description;
	}
}
