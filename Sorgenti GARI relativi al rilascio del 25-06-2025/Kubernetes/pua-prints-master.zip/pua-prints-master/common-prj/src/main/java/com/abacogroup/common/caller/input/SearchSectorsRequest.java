package com.abacogroup.common.caller.input;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class SearchSectorsRequest {
	
	public List<String> codes;
	public Object filter;
    
    @JsonProperty("include_geometries")
    public boolean includeGeometries;
    
    @JsonProperty("next_key")
    public int nextKey;
}
