package com.abacogroup.common.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DeclOnCropsPrevEffluentsDTO {
    private Long id;
    private Long parentId;
    private String effluent;
    private String measurementUnit;
    private BigDecimal quantity;
    private BigDecimal nitrogenContent;
    private String frequency;
    private BigDecimal reduction;
    private BigDecimal residualNumber;
    private OffsetDateTime dtInsert;
    private OffsetDateTime dtDelete;
    private String userIdInsert;
    private String userIdDelete;
}
