package com.abacogroup.common.caller.input;

import java.util.Collections;
import java.util.Map;

import com.abacogroup.applicationworkflowsdk.model.Constants;
import com.abacogroup.common.caller.partyregistry.input.BaseDataInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import io.dropwizard.auth.AuthenticationException;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@EqualsAndHashCode(callSuper = true)
public class GetFinalDeclarationsDataInput extends BaseDataInput {
	
	public static final String DYNAMIC_DOCUMENT_CODE = "DYNAMIC_DOCUMENT_CODE";
	public static final String DEFAULT_DECLARATIONS_DOC_CODE = "PUA_DICHIARAZIONE_FINALE";

    public GetFinalDeclarationsDataInput(ProcedureEnvironment procedureEnvironment, DataInputParams inputParams) throws AuthenticationException {
        super(procedureEnvironment, inputParams);
    }

    @Override
    public Map<String, Object> getPathVariablesMap() {
        return Map.of(Constants.TENANT, this.tenant,
                Constants.APPLICATION_ID, this.applicationId, 
                DYNAMIC_DOCUMENT_CODE, DEFAULT_DECLARATIONS_DOC_CODE);
    }

    @Override public Map<String, Object> getQueryParamsMap() {
        return Collections.emptyMap();
    }

    @Override public String provideAuthToken() {
        return this.authToken;
    }

    @Override public String getUrl() {

//    	example: 
//    	https://umbria-dev.fe.abacogroup.eu/pua-application-forms/master/v1/applications/1/declarations/PUA_DICHIARAZIONE_FINALE
         
        return this.puaAppFormsUrl + "/{TENANT}/v1/applications/{APPLICATION_ID}/declarations/{DYNAMIC_DOCUMENT_CODE}";
    }

    @Override public String getHttpMethod() {
        return GenericCallerService.GET_METHOD;
    }

    @Override public String locale() {
        return this.locale;
    }

}
