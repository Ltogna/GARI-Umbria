package com.abacogroup.common.caller;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abacogroup.common.caller.input.AnimalsSpeciesDataInput;
import com.abacogroup.common.dto.AnimalSpecieDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetAnimalsSpeciesCaller extends AbacoDtoCaller<AnimalsSpeciesDataInput, List<AnimalSpecieDTO>> {
	
	public GetAnimalsSpeciesCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

	public AnimalsSpeciesMap makeCallAndGetAsMap(AnimalsSpeciesDataInput i) {
		Map<String, AnimalSpecieDTO> map = new HashMap<>();
		List<AnimalSpecieDTO> productTypeDTOs = this.makeCall(i);
		productTypeDTOs.forEach(c -> map.put(c.getGenreCode() + "_" + c.getCode(), c));
		return new AnimalsSpeciesMap(map);
	}
	
	public class AnimalsSpeciesMap {

		private Map<String, AnimalSpecieDTO> map = new HashMap<>();

		private AnimalsSpeciesMap(Map<String, AnimalSpecieDTO> map) {
			this.map = map;
		}

		public String getAnimalSpecieDescriptionByAnimalSpecieCode(String speciesCode) {
			if (null != speciesCode) {
				for (AnimalSpecieDTO animalSpecie : this.map.values()) {
					if ((animalSpecie.getGenreCode() + "_" + animalSpecie.getCode()).equals(speciesCode)) {
						return animalSpecie.getDescription();
					}
				}
			}
			return null;
		}
		
		public Collection<AnimalSpecieDTO> getAnimalSpecies(){
			return this.map.values();
		}
	}
}
