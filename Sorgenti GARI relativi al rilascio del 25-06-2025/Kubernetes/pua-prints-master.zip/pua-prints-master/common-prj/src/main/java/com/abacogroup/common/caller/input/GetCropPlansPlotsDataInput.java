package com.abacogroup.common.caller.input;

import java.util.Collections;
import java.util.Map;

import com.abacogroup.applicationworkflowsdk.model.Constants;
import com.abacogroup.common.caller.partyregistry.input.BaseDataInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import io.dropwizard.auth.AuthenticationException;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@EqualsAndHashCode(callSuper = true)
public class GetCropPlansPlotsDataInput extends BaseDataInput {
	
    public GetCropPlansPlotsDataInput(ProcedureEnvironment procedureEnvironment, DataInputParams inputParams) throws AuthenticationException {
        super(procedureEnvironment, inputParams);
    }

    @Override
    public Map<String, Object> getPathVariablesMap() {
    	return Map.of(Constants.TENANT, this.tenant,
                Constants.APPLICATION_ID, this.applicationId);
    }

    @Override public Map<String, Object> getQueryParamsMap() {
        return Collections.emptyMap();
    }

    @Override public String provideAuthToken() {
        return this.authToken;
    }

    @Override public String getUrl() {
    	
    	Map<String, Object> paramsMap = (Map<String, Object>) this.payload;
    	Integer cropPlanId =  (Integer) paramsMap.get("cropPlanId");
    	String version = (String) paramsMap.get("version");
    	Integer year = (Integer) paramsMap.get("year");
    	String pointInTime = year + "0515";
    	
    	String path = String.format("/{TENANT}/public/v1/crop-plans/%s/plans/%s/plots?cropPlanTypeCode=CROPPLAN&version=%s&pointInTime=%s", 
    			partyId, cropPlanId, version, pointInTime);
    	
        return this.cropPlanUrl + path;
    }

    @Override public String getHttpMethod() {
        return GenericCallerService.GET_METHOD;
    }

    @Override public String locale() {
        return this.locale;
    }

}
