package com.abacogroup.common.caller.input;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.abacogroup.applicationworkflowsdk.model.Constants;
import com.abacogroup.common.caller.partyregistry.input.BaseDataInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import io.dropwizard.auth.AuthenticationException;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@EqualsAndHashCode(callSuper = true)
public class GetProductTypesDataInput extends BaseDataInput {
	
	public static final String CROP_CODES = "CROP_CODES";
	
    public GetProductTypesDataInput(ProcedureEnvironment procedureEnvironment, DataInputParams inputParams) throws AuthenticationException {
        super(procedureEnvironment, inputParams);
    }

    @Override
    public Map<String, Object> getPathVariablesMap() {
        return Map.of(Constants.TENANT, this.tenant);
    }

    @Override public Map<String, Object> getQueryParamsMap() {
        return Collections.emptyMap();
    }

    @Override public String provideAuthToken() {
        return this.authToken;
    }

    @Override public String getUrl() {
    	StringBuilder sb = new StringBuilder();
    	List<String> landuseCodes = (List<String>) this.payload;
    	if (landuseCodes != null) {
    		landuseCodes.forEach(landUseCode -> sb.append("cropCode=").append(landUseCode).append("&"));
		}
        return this.bancheDatiUrl + "/{TENANT}/public/v1/nitrogen/product-types-by-crop?" + sb.toString();
    }

    @Override public String getHttpMethod() {
        return GenericCallerService.GET_METHOD;
    }

    @Override public String locale() {
        return this.locale;
    }

}
