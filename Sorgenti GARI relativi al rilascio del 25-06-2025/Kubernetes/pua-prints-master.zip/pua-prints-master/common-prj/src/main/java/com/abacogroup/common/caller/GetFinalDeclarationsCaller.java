package com.abacogroup.common.caller;

import com.abacogroup.common.caller.input.GetFinalDeclarationsDataInput;
import com.abacogroup.common.dto.FinalDeclarationsDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetFinalDeclarationsCaller extends AbacoDtoCaller<GetFinalDeclarationsDataInput, FinalDeclarationsDTO> {

	public GetFinalDeclarationsCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
