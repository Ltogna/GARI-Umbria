package com.abacogroup.common.caller.input;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 * 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnimalCategoryRequest {
	
	private List<AnimalCategoryRequestElement> elements;
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public class AnimalCategoryRequestElement {
		private String genreCode;
		private String specieCode;
	}
	
	public void addElement(String genreCode, String specieCode) {
		if (elements == null) {
			elements = new ArrayList<>();
		}
		elements.add(new AnimalCategoryRequestElement(genreCode, specieCode));
	}
	
	public List<AnimalCategoryRequestElement> getElements(){
		return elements;
	}
}
