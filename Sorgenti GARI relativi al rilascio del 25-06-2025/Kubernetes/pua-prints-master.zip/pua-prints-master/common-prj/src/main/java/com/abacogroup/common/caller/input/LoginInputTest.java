package com.abacogroup.common.caller.input;

import static com.abacogroup.common.code.Codes.APPLICATION_FORMS_URL_KEY;

import java.util.Map;
import java.util.Optional;

import org.jdbi.v3.core.Jdbi;

import com.abacogroup.applicationworkflowsdk.model.Constants;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import jakarta.ws.rs.client.Client;

/**
 * @author Alexandru Paraschiv
 */
// FOR DEV TESTS
public class LoginInputTest extends BaseAppFormsInput{

	public LoginInputTest(String tenant) {
		super(new ProcedureEnvironmentImpl(), tenant, -1L,"");
	}

	private static class ProcedureEnvironmentImpl implements ProcedureEnvironment{
		private ProcedureEnvironmentImpl(){};
		@Override public Optional<Jdbi> getJdbi(String s) {
			return Optional.empty();
		}

		@Override public Optional<Client> getJerseyClient() {
			return Optional.empty();
		}

		@Override public Optional<String> getProperty(String s) {
			return Optional.of(APPLICATION_FORMS_URL_KEY);
		}

		@Override public String getEnvironmentId() {
			return ProcedureEnvironment.super.getEnvironmentId();
		}
	}

	@Override
	public Map<String, Object> getPathVariablesMap() {
		return Map.of(Constants.TENANT, this.tenant);
	}

	@Override
	public Map<String, String> providePayload() {
		return Map.of("username", "admin", "password", "welcome!");
	}


	@Override
	public String getUrl() {
		return "https://umbria-dev.fe.abacogroup.eu/sso2/{TENANT}/public/v1/login";
	}
	@Override
	public String getHttpMethod() {
		return GenericCallerService.POST_METHOD;
	}
}
