package com.abacogroup.common.caller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abacogroup.common.caller.input.GetCycleTypesDataInput;
import com.abacogroup.common.dto.CycleTypeDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetCycleTypesCaller extends AbacoDtoCaller<GetCycleTypesDataInput, List<CycleTypeDTO>> {
	
	public GetCycleTypesCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

	public CycleTypesMap makeCallAndGetAsMap(GetCycleTypesDataInput i) {
		Map<Integer, CycleTypeDTO> map = new HashMap<>();
		List<CycleTypeDTO> cycleTypeDTOs = this.makeCall(i);
		cycleTypeDTOs.forEach(c -> map.put(c.getCode(), c));
		return new CycleTypesMap(map);
	}
	
	public class CycleTypesMap {

		private Map<Integer, CycleTypeDTO> map = new HashMap<>();

		private CycleTypesMap(Map<Integer, CycleTypeDTO> map) {
			this.map = map;
		}

		public String getDescriptionByCode(Integer code) {
			if (null != code) {
				for (CycleTypeDTO cycle : this.map.values()) {
					if (cycle.getCode().equals(code)) {
						return cycle.getDescription();
					}
				}
			}
			return null;
		}
	}
}
