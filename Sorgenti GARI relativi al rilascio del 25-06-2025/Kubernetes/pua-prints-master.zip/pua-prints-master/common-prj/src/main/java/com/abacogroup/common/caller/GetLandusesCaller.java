package com.abacogroup.common.caller;

import com.abacogroup.common.caller.input.GetLandusesDataInput;
import com.abacogroup.common.dto.LandusesDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetLandusesCaller extends AbacoDtoCaller<GetLandusesDataInput, LandusesDTO> {

	public GetLandusesCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
