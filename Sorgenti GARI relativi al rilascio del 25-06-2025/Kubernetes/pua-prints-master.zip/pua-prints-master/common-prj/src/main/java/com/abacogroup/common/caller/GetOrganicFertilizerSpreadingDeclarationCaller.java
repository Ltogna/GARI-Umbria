package com.abacogroup.common.caller;

import java.util.List;

import com.abacogroup.common.caller.input.GetOrganicFertilizerSpreadingDeclarationDataInput;
import com.abacogroup.common.dto.OrganicFertilizerSpreadingDeclarationDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetOrganicFertilizerSpreadingDeclarationCaller extends AbacoDtoCaller<GetOrganicFertilizerSpreadingDeclarationDataInput, List<OrganicFertilizerSpreadingDeclarationDTO>> {

	public GetOrganicFertilizerSpreadingDeclarationCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
