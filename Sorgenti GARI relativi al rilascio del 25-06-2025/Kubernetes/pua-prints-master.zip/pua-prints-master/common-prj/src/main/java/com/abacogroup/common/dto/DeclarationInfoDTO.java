package com.abacogroup.common.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DeclarationInfoDTO {
	
	private String declCode;
	private Landuse landuse;
	private double areaPerc;
	private Style style;
	private String fromDate;
	private String fromDatePrecision;
	private String toDate;
	private List<Object> permanentCropForms;
	private List<Object> anomalies;
	private List<Object> pesticides;
	private List<FieldCode> fieldsCodes;
	private int plotId;
	private String plotCode;
	private Object plotDescription;
	private Object plotNotes;
	private List<Object> parcelIntersections;
	private int plotAreaSqm;
	private String geom;
	private String srs;
	private String mbrOverview;
	private String plotFromDate;
	private String plotToDate;
	private String editability;
	private String domainZoneCode;
	private String domainZoneDescription;
	private List<Object> plotAnomalies;
	private boolean deleted;
	private String plotCodeDeclCodeKey;

	@Data
	@SuperBuilder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class Landuse {
		private String code;
		private String description;
	}

	@Data
	@SuperBuilder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class Style {
		private String fillColor;
		private String fillStyle;
		private String borderColor;
	}

	@Data
	@SuperBuilder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class FieldCode {
		private String fieldCode;
		private String fieldDescription;
		private String dayFrom;
		private String dayTo;
		private int sortOrder;
		private String value;
		private String valueDescription;
		private boolean flShowInTooltip;
		private String plotCodeDeclCodeKey;
	}
}
