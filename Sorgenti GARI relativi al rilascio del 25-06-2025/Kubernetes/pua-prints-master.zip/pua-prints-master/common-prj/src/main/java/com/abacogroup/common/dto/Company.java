package com.abacogroup.common.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Company {
    
    private static final long serialVersionUID = 1L;
    
    private Long applicationId;
    private String cuaa;
    private String vatNumber;
    private String companyName;
    private String streetAddress;
    private String postalCode;
    private String province;
    private String istatCode;
    private String municipality;
}
