package com.abacogroup.common.proc;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.jdbi.v3.core.Handle;

import com.abacogroup.common.caller.GetFiveYearDeclarationCaller;
import com.abacogroup.common.caller.GetSectorsCaller;
import com.abacogroup.common.caller.input.GetFiveYearDeclarationDataInput;
import com.abacogroup.common.caller.input.GetSectorsDataInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.common.code.Codes;
import com.abacogroup.common.dto.FiveYearDeclarationDTO;
import com.abacogroup.common.dto.SectorsDTO;
import com.abacogroup.common.dto.SectorsDTO.Sector;
import com.abacogroup.common.utils.Utils;
import com.abacogroup.common.utils.Utils.NumberPattern;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 *  Carica da microservizio e persiste su h2
 * 	<p>
 *	h2 è gia stato creato dalla proc precedente
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class CreateTableFiveYearDeclarationData extends BasePrintProcedure {
	
	@Override
	public void customExecute(ProcessData processData, ProcedureEnvironment procedureEnvironment) throws Exception {
		
		GetFiveYearDeclarationCaller getFiveYearDeclarationDataCaller = new GetFiveYearDeclarationCaller(this.genericCallerService);
		
		DataInputParams inputParams = getDefaultDataInputParams();
		
		List<FiveYearDeclarationDTO> dtos = getFiveYearDeclarationDataCaller.makeCall(new GetFiveYearDeclarationDataInput(
				procedureEnvironment, inputParams));

		log.debug("FiveYearDeclarationDTO's: {}", dtos);
		 
		GetSectorsCaller getSectorsCaller = new GetSectorsCaller(this.genericCallerService);
		List<String> sectorCodes = new ArrayList<>(dtos.size());
		dtos.forEach(dto -> sectorCodes.add(dto.getSectorCode()));
		inputParams.setPayload(sectorCodes);
		SectorsDTO sectors = getSectorsCaller.makeCall(new GetSectorsDataInput(procedureEnvironment, inputParams));
		var sectorsMap = sectors.getSectorsAsMap();
		
		try (Handle handle = jdbi.open()) {
			 
			BigDecimal usedAreaHects = null;
			String landRegistrYReferences = null;
			Sector sector = null;
			String refCatast = null;
			
			for (FiveYearDeclarationDTO dto : dtos) {
				
				usedAreaHects = BigDecimal.valueOf(dto.getUsedAreaSqm()).divide(BigDecimal.valueOf(10000));
				sector = sectorsMap.getOrDefault(dto.getSectorCode(), null);
				refCatast = sector!=null?sector.getSectorCode() + " " +  sector.getDescription():null;
				landRegistrYReferences = String.format("%s FG. %s PT. %s/%s", refCatast, dto.getBlockCode(), dto.getParcelCode(), dto.getSubParcelCode());
				
				handle.createUpdate("""
				INSERT INTO FIVE_YEAR_DECLARATION (
					APPLICATION_ID, PARTY_ID, COMPANY, CUAA, LAND_REGISTRY_REFERENCES, USED_AREA_HECTARES) 
				VALUES (
					:APPLICATION_ID, :PARTY_ID, :COMPANY, :CUAA, :LAND_REGISTRY_REFERENCES, :USED_AREA_HECTARES) 
					""")
				.bind("APPLICATION_ID", this.applicationId) 
				.bind("PARTY_ID", dto.getPartyId()) 
				.bind("COMPANY", dto.getCompany()) 
				.bind("CUAA", dto.getCuaa()) 
				.bind("LAND_REGISTRY_REFERENCES", landRegistrYReferences)
				.bind("USED_AREA_HECTARES", Utils.formatNumbAndGetAsString(usedAreaHects , NumberPattern.PATTERN_DECIMAL)) 
				.execute();
			}
			
		} catch (Exception e) {
			log.error(String.format("An error occurred inserting application data for application id %s", applicationId), e);
		}
	}
	
}
