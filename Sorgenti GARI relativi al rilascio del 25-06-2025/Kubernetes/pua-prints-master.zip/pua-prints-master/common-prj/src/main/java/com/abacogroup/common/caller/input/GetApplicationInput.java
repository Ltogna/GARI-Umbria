package com.abacogroup.common.caller.input;

import java.util.Map;

import com.abacogroup.applicationworkflowsdk.model.Constants;
import com.abacogroup.common.caller.partyregistry.input.BaseDataInput;
import com.abacogroup.common.caller.partyregistry.input.DataInputParams;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

import lombok.EqualsAndHashCode;

/**
 * @author Mattia Perini
 */
@EqualsAndHashCode(callSuper = true)
public class GetApplicationInput extends BaseDataInput {

	public GetApplicationInput(ProcedureEnvironment procedureEnvironment, DataInputParams inputParams) {
		super(procedureEnvironment, inputParams);
	}

	@Override
	public Map<String, Object> getPathVariablesMap() {
		return Map.of(Constants.TENANT, this.tenant,
				Constants.APPLICATION_ID, this.applicationId);
	}

	@Override
	public String provideAuthToken() {
		return this.authToken;
	}

	@Override
	public String getUrl() {
		return this.applicationsUrl +
				"/{TENANT}/public/v1/applications/{APPLICATION_ID}";
	}

	@Override public String getHttpMethod() {
		return GenericCallerService.GET_METHOD;
	}
}
