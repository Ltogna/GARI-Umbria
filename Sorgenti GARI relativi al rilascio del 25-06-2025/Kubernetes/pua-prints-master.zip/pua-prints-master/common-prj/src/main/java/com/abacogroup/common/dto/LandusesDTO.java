package com.abacogroup.common.dto;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class LandusesDTO {

	@JsonProperty("land_uses_codes_list")
	private List<LandUse> landUsesCodesList;

	@Data
	@SuperBuilder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class LandUse {
		
		@JsonProperty("land_uses_code")
		private String landUsesCode;

		@JsonProperty("description")
		private String description;
	}

	public Map<String, LandUse> getLandUsesAsMap() {
		return (Map<String, LandUse>) landUsesCodesList.stream()
				.collect(Collectors.toMap(
						LandUse::getLandUsesCode, 
						landUse -> landUse
		));
	}
}
