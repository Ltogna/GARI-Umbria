package com.abacogroup.common.caller;

import com.abacogroup.common.caller.input.GetCropPlansDataInput;
import com.abacogroup.common.dto.CropPlanDTO;
import com.abacogroup.common.dto.RecordResponse;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetCropPlansCaller extends AbacoDtoCaller<GetCropPlansDataInput, RecordResponse<CropPlanDTO>> {

	public GetCropPlansCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
