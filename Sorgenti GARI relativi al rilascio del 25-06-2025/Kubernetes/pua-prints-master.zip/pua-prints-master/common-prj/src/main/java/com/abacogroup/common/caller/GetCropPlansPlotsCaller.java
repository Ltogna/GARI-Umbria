package com.abacogroup.common.caller;

import com.abacogroup.common.caller.input.GetCropPlansPlotsDataInput;
import com.abacogroup.common.dto.PlotRecordDTO;
import com.abacogroup.common.dto.RecordResponse;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public class GetCropPlansPlotsCaller extends AbacoDtoCaller<GetCropPlansPlotsDataInput, RecordResponse<PlotRecordDTO>> {

	public GetCropPlansPlotsCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
