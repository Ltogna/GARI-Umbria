package com.abacogroup.common.utils;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.model.AbacoTechUser;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

/**
 * @author Alexandru Paraschiv
 * @author Emanuele Crocilla
 */
public class Utils {

	private static GenericCallerService genericCallerServiceInstance;
	 
	public enum NumberPattern {
		
		PATTERN_DECIMAL("#,##0.0000"), // Output example: 123.0 -> 123,0000
		PATTERN_DECIMAL_2("#,##0.00"), // Output example: 123.0 -> 123,00
		PATTERN_INT("#,##0"); 	// Output example: 123.0 -> 123
		
		private String pattern;
		
		private NumberPattern(String pattern) {
			this.pattern = pattern;
		}

		public String getPattern() {
			return pattern;
		}
	}

	public static GenericCallerService getGenericCallerService(ProcedureEnvironment procedureEnvironment) {
		if(genericCallerServiceInstance == null) {
			genericCallerServiceInstance = new GenericCallerService(procedureEnvironment.getJerseyClient().get(), new AbacoTechUser());
		}
		return genericCallerServiceInstance;
	}

	public static String retrieveIstatCode(String code) {
		try {
			return code.split("_")[2];
		} catch (Exception e) {
			return " ";
		}
	}
	
	public static String formatNumbAndGetAsString(Number number, NumberPattern numbPattern) {
		DecimalFormat df = new DecimalFormat(numbPattern.getPattern());
		df.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.ITALIAN));
		return number != null ? df.format(number) : "0"; 
	}

}
