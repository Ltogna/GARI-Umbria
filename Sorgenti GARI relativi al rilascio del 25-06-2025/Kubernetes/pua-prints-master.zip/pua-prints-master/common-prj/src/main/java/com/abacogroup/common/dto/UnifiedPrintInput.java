package com.abacogroup.common.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UnifiedPrintInput {

	@NotNull
	@JsonProperty("applicationId")
	private Long applicationId;
	@NotNull
	@JsonProperty("partyId")
	private Long partyId;

}
