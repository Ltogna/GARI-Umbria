package com.abacogroup.common.caller;

import com.abacogroup.common.caller.input.GetApplicationInput;
import com.abacogroup.common.dto.ApplicationDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * @author Mattia Perini
 */
public class GetApplicationCaller extends AbacoDtoCaller<GetApplicationInput, ApplicationDTO> {

	public GetApplicationCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}

