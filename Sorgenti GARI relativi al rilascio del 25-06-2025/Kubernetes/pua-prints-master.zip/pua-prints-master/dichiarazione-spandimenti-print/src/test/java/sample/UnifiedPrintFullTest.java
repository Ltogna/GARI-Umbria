package sample;


import com.abacogroup.common.caller.LoginCallerTest;
import com.abacogroup.common.caller.input.LoginInputTest;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.model.AbacoTechUser;
import com.abacogroup.printengine.sdk.core.testsupport.PrintFlowTestSupport;
import com.abacogroup.printengine.sdk.model.AuthContextImpl;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.jakarta.rs.json.JacksonJsonProvider;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.core.SecurityContext;
import lombok.SneakyThrows;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.client.JerseyClientBuilder;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.Principal;
import java.util.List;
import java.util.Map;

@ExtendWith(DropwizardExtensionsSupport.class)
class UnifiedPrintFullTest {

	private static final String WORKFLOW_CODE = "DICHIARAZIONE_SPANDIMENTI_PRINT";
	private static final String TENANT_ID = "master";
	private static final String ENVID = "local";
	private static final AuthContextImpl AUTH_CONTEXT = new AuthContextImpl(new SecurityContext() {
		@Override
		public Principal getUserPrincipal() {

			User user = new User(
					"admin",
					getAuthToken(),
					TENANT_ID,
					"MASTER/ADMIN");
			return user;
		}

		@Override
		public boolean isUserInRole(String role) {
			return true;
		}

		@Override
		public boolean isSecure() {
			return true;
		}

		@Override
		public String getAuthenticationScheme() {
			return null;
		}
	}, "it");

	// FOR DEV TESTS
	private static String getAuthToken() {
		Client client = new JerseyClientBuilder().build();
		client.property(ClientProperties.CONNECT_TIMEOUT, 300000);
		client.property(ClientProperties.READ_TIMEOUT, 300000);

		GenericCallerService genericCallerService = new GenericCallerService(client, new AbacoTechUser());
		LoginCallerTest loginCallerTest = new LoginCallerTest(genericCallerService);

		Map<String, Object> loginInfo = loginCallerTest.makeCall(new LoginInputTest(TENANT_ID));

		return (String) loginInfo.get("auth_token");
	}

	@SneakyThrows
	@Test
	void full_integration_test_pdf() {
		File expectedPdfFile = new File("target/report.pdf");

		ObjectMapper om = new ObjectMapper();
		om.registerModule(new JavaTimeModule());
		om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		om.configure(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES, false);
		Client client = new JerseyClientBuilder().register(new JacksonJsonProvider(om)).build();

		//replaceH2();

		ProcessTransitionResult transitionResult = PrintFlowTestSupport.buildFlow(WORKFLOW_CODE, TENANT_ID)
				.withDbConnection("jdbc:postgresql://localhost:35435/print_dev_test", "postgres", "postgres")
				.withExpectedFile(expectedPdfFile)
				.withClient(client)
				.withAuthContext(AUTH_CONTEXT)
				.withEnv(ENVID)
				.withObjectMapper(om)
				.putInputParam("applicationId", 5082)
				.putInputParam("partyId", 47)
				.setUp()
				.execute();

		Assertions.assertFalse(transitionResult.getLastTransitionLog().isFailed());
		Assertions.assertTrue(transitionResult.isProcessEnded());
		Assertions.assertTrue(expectedPdfFile.exists());
	}

	private void replaceH2() throws IOException {
		List<String> lines = Files.readAllLines(Path.of("target/classes/abaco-workflow.json"));
		try (FileOutputStream out = new FileOutputStream("target/classes/abaco-workflow.json")) {
			for (String line : lines) {
				out.write(line.replace("\"com.abacogroup.printengine.sdk.proc.H2Procedure\"", "\"com.abacogroup.common.devel.DebugH2Procedure\"")
						.getBytes(StandardCharsets.UTF_8));
				out.write('\n');
			}
		}
	}

}
