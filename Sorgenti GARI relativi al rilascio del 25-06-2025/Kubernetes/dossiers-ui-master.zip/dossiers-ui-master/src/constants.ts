export const BASE = "/ui/dossiers/";
// export const BASE = "/";
