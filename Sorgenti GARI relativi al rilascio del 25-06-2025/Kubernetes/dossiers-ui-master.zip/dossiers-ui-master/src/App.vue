<script setup lang="ts">
import RootAlerts from "@abaco/bootstrap-italia-components/src/components/Alerts/RootAlerts.vue";
import { inject, onMounted } from "vue";
import { RouterView } from "vue-router";
import { login } from "./resources/api/login";
import { useDossierStore } from "./stores/dossierStore";
import { useUserAdminStore } from "./stores/userAdminStore";

const userAdminStore = useUserAdminStore();
const dossierStore = useDossierStore();
const isDev = inject("isDev");

onMounted(async () => {
  try {
    if (isDev) {
      await login({
        tenant: "master",
        username: "admin",
        password: "welcome",
      });
    }
    userAdminStore.fetchMyUsername();
    await dossierStore.loadTenantConfigs();
    await dossierStore.loadUserFunctions();
    userAdminStore.setReady();
  } catch (err) {
    console.error(err);
  }
});
</script>

<template>
  <div class="dossier-module">
    <RootAlerts :dismissOnRouteChange="true"></RootAlerts>
    <RouterView v-if="userAdminStore.getIsReady" />
  </div>
</template>
