<script setup lang="ts">
import { computed, inject, onMounted, watchEffect } from "vue";
import { useI18n } from "vue-i18n";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import { useDossierStore } from "@/stores/dossierStore";
import CreateDossier from "@/components/CreateDossier/CreateDossier.vue";
import { useRoute, useRouter } from "vue-router";
import TopBar from "@/components/TopBar.vue";

const moduleId = inject("moduleId");
const router = useRouter();
const { t } = useI18n({});
const dossierStore = useDossierStore();
const selectedSubject = computed(() => dossierStore.getSelectedSubject);
const route = useRoute();

const partyIdRoute = computed(() => parseInt(route.params.partyId as string));

watchEffect(async () => {
  if (partyIdRoute.value && !dossierStore.getDossierModules) {
    await Promise.all([
      fetchData(),
      dossierStore.loadParty(partyIdRoute.value),
    ]);
  }
});

async function fetchData() {
  await dossierStore.loadDossierModules();
}

onMounted(async () => {
  await fetchData();
});

function backToDossierResult() {
  router.back();
}
</script>

<template>
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded']">
      <template #card-header>
        <TopBar
          :isBackButton="true"
          :backButtonFunction="() => backToDossierResult()"
          :title="
            t(`${moduleId}.cardContainer.header`, {
              cuaa: selectedSubject?.code,
              companyName: selectedSubject?.description,
            })
          "
        />
      </template>
      <template #card-body>
        <div class="container col-12 px-3 mx-0">
          <CreateDossier></CreateDossier>
        </div>
      </template>
    </BiCard>
  </div>
</template>
