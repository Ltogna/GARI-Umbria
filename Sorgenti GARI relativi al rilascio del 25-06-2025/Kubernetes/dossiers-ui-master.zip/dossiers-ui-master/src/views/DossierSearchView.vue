<script setup lang="ts">
import SubjectSearchForm from "@/components/DossierSearch/SubjectSearchForm.vue";
import TopBar from "@/components/TopBar.vue";
import { useDossierStore } from "@/stores/dossierStore";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiCheckbox from "@abaco/bootstrap-italia-components/src/components/form/BiCheckbox.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";

const moduleId = inject("moduleId");
const router = useRouter();
const { getColor } = useColors();
const dossierStore = useDossierStore();
const { t } = useI18n({});
const showNoDossierAlert = ref<boolean>(false);
const searchFormVisible = ref<boolean>(false);

const searchFormRef = ref();

const dossierFilter = computed(() => dossierStore.getDossierListFilter);

const selectedSubject = computed(() => dossierStore.getSelectedSubject);

const applicationList = computed(() => dossierStore.getDossierList);

const dossierTypeList = computed(() => {
  return dossierStore.getDossierTypes?.map((el) => {
    return {
      id: el.moduleCode,
      text: el.moduleShortDescription,
    };
  });
});

onMounted(async () => {
  dossierStore.setSelectedSubject(null);
  dossierStore.clearDossierListFilters();
  await dossierStore.loadDossierTypes();
});

function navigateToCreateNewDossier() {
  dossierStore.clearDossierListFilters();
  router.push({
    name: "newDossier",
  });
}

async function searchDossierList() {
  if (selectedSubject.value) {
    await dossierStore.loadDossierList(selectedSubject.value.partyId, {
      dossierType:
        dossierFilter.value.dossierType !== ""
          ? dossierFilter.value.dossierType
          : undefined,
      includeClosedDossier:
        dossierFilter.value.includeClosedDossier !== null
          ? dossierFilter.value.includeClosedDossier
          : undefined,
    });

    if (applicationList.value && applicationList.value.records.length == 0) {
      showNoDossierAlert.value = true;
    } else {
      router.push({
        name: "dossierListResults",
        params: {
          partyId: selectedSubject.value.partyId,
        },
        query: JSON.parse(JSON.stringify(dossierFilter.value)),
      });
    }
  }
}

function getSearchFormVisibility(value: boolean) {
  searchFormVisible.value = value;
  if (value === false) showNoDossierAlert.value = false;
}

const disableButton = computed(() => {
  return (
    dossierStore.getIsLoading === true ||
    dossierStore.getSelectedSubject === null
  );
});

function clearAllFilters() {
  dossierStore.setSelectedSubject(null);
  dossierStore.clearDossierListFilters();
  showNoDossierAlert.value = false;
}
</script>

<template>
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded']">
      <template #card-header>
        <TopBar
          :title="t(`${moduleId}.searchForm.dossiers`)"
          :buttonList="[
            {
              text: t(`${moduleId}.searchForm.newDossier`),
              classes: `${getColor('button', 'primary', 'outline')} py-2`,
              callback: navigateToCreateNewDossier,
              hideButton: dossierStore.isFunctionReadOnly,
            },
          ]"
        />
      </template>
      <template #card-body>
        <div class="container col-12 px-3 mx-0">
          <form
            id="taskSearchForm"
            class="needs-validation pt-5"
            ref="searchFormRef"
            @submit.prevent="() => {}"
          >
            <div id="searchContainer" class="row">
              <SubjectSearchForm
                @search-form-visible="getSearchFormVisibility"
              ></SubjectSearchForm>
              <div class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-3">
                <BiSelect
                  name="dossierType"
                  :id="'dossierType'"
                  :isMultiple="false"
                  :isAutocomplete="false"
                  :label="t(`${moduleId}.searchForm.dossierType`)"
                  :emptyOption="t(`${moduleId}.general.choseOption`)"
                  :items="dossierTypeList ?? []"
                  v-model="dossierFilter.dossierType"
                  @update:model-value="
                    (val: string) => {
                      dossierFilter.dossierType = val;
                      dossierFilter.dossierTypeDescription =
                        dossierTypeList?.find((x) => x.id === val)?.text || '';
                      showNoDossierAlert = false;
                    }
                  "
                ></BiSelect>
              </div>
              <div
                class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-3 pt-md-5"
              >
                <BiCheckbox
                  id="search-form"
                  :is-disabled="false"
                  :label="t(`${moduleId}.searchForm.includeDossier`)"
                  :model-value="dossierFilter.includeClosedDossier ?? false"
                  @update:model-value="
                    (val: boolean) => {
                      dossierFilter.includeClosedDossier = val;
                      showNoDossierAlert = false;
                    }
                  "
                />
              </div>
            </div>
          </form>

          <div v-if="showNoDossierAlert" class="row">
            <div class="col-3"></div>
            <div class="mt-3 col-6">
              <BiAlert isWarn>
                <template #body>{{
                  !dossierFilter.dossierType &&
                  !dossierFilter.includeClosedDossier
                    ? t(
                        `${moduleId}.searchForm.errors.NO_DOSSIER_FOUND_EXCEPTION`,
                      )
                    : t(
                        `${moduleId}.searchForm.errors.NO_DOSSIER_WITH_NO_FILTERS_FOUND_EXCEPTION`,
                      )
                }}</template>
              </BiAlert>
            </div>
            <div class="col-3"></div>
          </div>

          <div
            class="d-flex justify-content-center"
            v-if="dossierStore.loading && !searchFormVisible"
          >
            <BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
          </div>

          <div class="mt-0 mb-1 d-flex justify-content-center pt-md-5">
            <BiButton
              size="lg"
              class="btn"
              :class="getColor('button', 'secondary', 'outline')"
              @click.stop="clearAllFilters()"
            >
              {{ t(`${moduleId}.general.cancel`) }}
            </BiButton>
            <BiButton
              :is-disabled="disableButton"
              type="submit"
              form="taskSearchForm"
              isPrimary
              size="lg"
              class="ms-3 btn"
              :class="getColor('button', 'success')"
              @click.stop="searchDossierList()"
              >{{ t(`${moduleId}.general.search`) }}</BiButton
            >
          </div>
        </div>
      </template>
    </BiCard>
  </div>
</template>
