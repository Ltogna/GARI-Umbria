<script setup lang="ts">
import { computed, inject, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";
import { useI18n } from "vue-i18n";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { useDossierStore } from "@/stores/dossierStore";
import SubjectSearchForm from "@/components/DossierSearch/SubjectSearchForm.vue";
import TopBar from "@/components/TopBar.vue";

const moduleId = inject("moduleId");
const router = useRouter();
const route = useRoute();
const dossierStore = useDossierStore();
const { t } = useI18n({});
const selectedSubject = computed(() => dossierStore.getSelectedSubject);

onMounted(async () => {
  dossierStore.setSelectedSubject(null);
  dossierStore.clearDossierListFilters();
});

async function goBack() {
  dossierStore.clearDossierListFilters();
  router.push({
    name: "dossierList",
    query: route.query,
  });
}

async function goToCreateDossier() {
  router.push({
    name: "createDossier",
    params: {
      partyId: selectedSubject.value?.partyId,
    },
    query: route.query,
  });
}
</script>

<template>
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded']">
      <template #card-header>
        <TopBar
          :isBackButton="true"
          :backButtonFunction="() => goBack()"
          :title="t(`${moduleId}.searchForm.newDossier`)"
        />
      </template>
      <template #card-body>
        <div
          id="searchContainer"
          class="row col-12 px-3 pt-5 justify-content-center"
        >
          <div class="col-1"></div>
          <div id="searchContainer" class="row col-11 justify-content-center">
            <SubjectSearchForm> </SubjectSearchForm>
          </div>
        </div>
        <div class="d-flex justify-content-center">
          <BiButton
            :is-disabled="selectedSubject == null"
            type="submit"
            color="success"
            @click.stop="goToCreateDossier()"
            >{{ t(`${moduleId}.general.proceed`) }}</BiButton
          >
        </div>
      </template>
    </BiCard>
  </div>
</template>
