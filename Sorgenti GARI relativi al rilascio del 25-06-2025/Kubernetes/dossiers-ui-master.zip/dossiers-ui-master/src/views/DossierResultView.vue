<script setup lang="ts">
// Vue
import { inject, computed, watchEffect, onMounted } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";

//Boootstrap Italia components
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";

//State manager
import { useDossierStore } from "@/stores/dossierStore";
import DossierList from "@/components/DossierList/DossierList.vue";
import TopBar from "@/components/TopBar.vue";

const moduleId = inject("moduleId");
const dossierStore = useDossierStore();
const router = useRouter();
const route = useRoute();
const { t } = useI18n({});
const { getColor } = useColors();

const partyIdRoute = computed(() => parseInt(route.params.partyId as string));

const partyId = computed(() => {
  return dossierStore.getSelectedSubject?.partyId || partyIdRoute.value;
});

const dossierType = computed(() => {
  return dossierStore.getDossierListFilter.dossierType;
});

const dossierTypeDescription = computed(() => {
  return dossierStore.getDossierListFilter.dossierTypeDescription;
});

const includeClosedDossier = computed(() => {
  return dossierStore.getDossierListFilter.includeClosedDossier;
});

onMounted(async () => {
  if (!dossierType.value && !includeClosedDossier.value) {
    dossierStore.setDossierListFilter({
      dossierType: route.query.dossierType
        ? (route.query.dossierType as string)
        : "",
      dossierTypeDescription: route.query.dossierTypeDescription
        ? (route.query.dossierTypeDescription as string)
        : "",
      includeClosedDossier: route.query.includeClosedDossier === "true",
    });
  }

  await dossierStore.loadDossierList(
    partyId.value,
    {
      dossierType: dossierType.value ? dossierType.value : undefined,
      includeClosedDossier:
        includeClosedDossier.value !== undefined
          ? includeClosedDossier.value
          : undefined,
    },
    undefined,
  );
});

watchEffect(async () => {
  if (partyIdRoute.value && !dossierStore.getDossierList) {
    await Promise.allSettled([
      dossierStore.loadParty(partyIdRoute.value),
      dossierStore.loadDossierList(
        partyIdRoute.value,
        {
          dossierType: dossierType.value ? dossierType.value : undefined,
          includeClosedDossier:
            includeClosedDossier.value !== undefined
              ? includeClosedDossier.value
              : undefined,
        },
        undefined,
      ),
    ]);
  }
});

function goBack() {
  router.push({
    name: "dossierList",
  });
}

function goToNewDossier() {
  router.push({
    name: "createDossier",
    params: {
      partyId: partyIdRoute.value,
    },
    query: route.query,
  });
}
</script>
<template>
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded']">
      <template #card-header>
        <TopBar
          :isBackButton="true"
          :backButtonFunction="() => goBack()"
          :title="t(`${moduleId}.list.title`)"
          :buttonList="[
            {
              text: t(`${moduleId}.searchForm.newDossier`),
              classes: `${getColor('button', 'primary', 'outline')} py-2`,
              callback: () => goToNewDossier(),
              hideButton:
                dossierStore.getIsLoading || dossierStore.isFunctionReadOnly,
            },
          ]"
        />
      </template>
      <template #card-body>
        <div class="container col-12 px-3 mx-0">
          <DossierList
            :dossierType="dossierType"
            :dossier-type-description="dossierTypeDescription"
            :includeClosedDossier="includeClosedDossier"
            :partyId="partyId"
          ></DossierList>
        </div>
      </template>
    </BiCard>
  </div>
</template>
