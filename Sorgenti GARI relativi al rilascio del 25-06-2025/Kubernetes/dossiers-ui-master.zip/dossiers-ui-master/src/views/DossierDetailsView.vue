<script setup lang="ts">
import CardCentralBox from "@/components/DossierDetails/CardCentralBox.vue";
import SecondLevelCard from "@/components/DossierDetails/CardMenu/SecondLevelCard.vue";
import SecondLevelCardAccordion from "@/components/DossierDetails/CardMenu/SecondLevelCardAccordion.vue";
import DossierChangeStatusModal from "@/components/DossierDetails/DossierChangeStatusModal.vue";
import MovementHistory from "@/components/DossierDetails/DossierHistory/MovementHistory.vue";
import PrintHistory from "@/components/DossierDetails/DossierHistory/PrintHistory.vue";
import DossierPrintModal from "@/components/DossierDetails/DossierPrintModal.vue";
import GenericDossierInfo from "@/components/DossierDetails/GenericDossierInfo.vue";
import TopBar from "@/components/TopBar.vue";
import {
  CardState,
  fromFormDetailsModelToSelectedCard,
  type CardNode,
  type DossierAnomalyModel,
  type FormDetailsModel,
  type FormGroupModel,
  type FormModel,
  type SelectedCard,
} from "@/models/dossier";
import { cleanBasePath } from "@/models/utils";
import { useDossierStore } from "@/stores/dossierStore";
import { getFormattedDate } from "@/utils/dateUtils";
import { extractModuleId, wait } from "@/utils/formUtils";
import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { computed, inject, onMounted, onUnmounted, ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";
import CentralBoxHeader from "../components/DossierDetails/CentralBoxHeader.vue";
import type { AllowedButtonPurposeType } from "@abaco/bootstrap-italia-components/src/models/colors";

enum AnomalySeverity {
  BLOCKING = "BLOCKING",
  NOT_BLOCKING = "NOT_BLOCKING",
  INFO = "INFO",
}

interface AnomalyCount {
  blocking: number;
  notBlocking: number;
  info: number;
}

interface AnomalyButtonInfo {
  style: string;
  count: number;
}

const router = useRouter();
const route = useRoute();
const { getColor } = useColors();
const { t } = useI18n({});
const moduleId = inject("moduleId");
const basePath = inject("basePath");
const showAnomaliesModal = ref<boolean>(false);
// Summary of anomalies
const anomaliesCount = ref<AnomalyCount>({
  blocking: 0,
  notBlocking: 0,
  info: 0,
});
// Anomalies divided by categories
const blockingAnomalies = ref<DossierAnomalyModel[]>([]);
const notBlockingAnomalies = ref<DossierAnomalyModel[]>([]);
const infoAnomalies = ref<DossierAnomalyModel[]>([]);
const lastAnomaliesRecalcDate = computed(() => {
  if (
    dossierStore.getDossierAnomalies &&
    dossierStore.getDossierAnomalies.length > 0
  ) {
    const tmp = JSON.parse(JSON.stringify(dossierStore.getDossierAnomalies));
    const sorted = tmp.sort(
      (x: DossierAnomalyModel, y: DossierAnomalyModel) =>
        new Date(x.dtInsert).getTime() - new Date(y.dtInsert).getTime(),
    );
    return sorted[0].dtInsert;
  } else return null;
});

const selectedCardInfo = ref<SelectedCard | null>(null);
const showGenericDossierData = ref<boolean>(true);
const showPrintHistory = ref<boolean>(false);
const showMovementHistory = ref<boolean>(false);
const openPrintModal = ref<boolean>(false);
const prints = computed(() => dossierStore.getDossierDetails?.prints || []);
const componentTree = ref<CardNode[]>([]);
const dossierStore = useDossierStore();
const changeStatusComponentVisible = ref<boolean>(false);
const dossierId = ref<number>(parseInt(route.params.dossierId as string));
const isLoadingTransitionData = ref<boolean>(false);
const cuaa = computed(() => {
  return dossierStore.getSelectedSubject?.code ?? "";
});

const utilityAccordionOpened = ref<boolean>(false);

const transitions = computed(() => dossierStore.getDossierTransitions);

const dossierAnomalies = computed(() => dossierStore.getDossierAnomalies);
const formList = computed(() => {
  return dossierStore.getDossierDetails;
});

const anomaliesButtonInfo = computed(() => {
  let colorName = "success";
  let count = 0;
  if (anomaliesCount.value.blocking > 0) {
    colorName = "danger";
    count = anomaliesCount.value.blocking;
  } else if (anomaliesCount.value.notBlocking > 0) {
    colorName = "warning";
    count = anomaliesCount.value.notBlocking;
  } else if (anomaliesCount.value.info > 0) {
    colorName = "info";
    count = anomaliesCount.value.info;
  }
  return {
    style: `${getColor("button", colorName as AllowedButtonPurposeType)}`,
    count: count,
  } as AnomalyButtonInfo;
});

const isInTransitionMessages = computed(() => dossierStore.getTransitionData);

watch(
  () => dossierId.value,
  async () => {
    await initPageLogic();
  },
);

const fixedRouteChunk = computed(() => {
  return `${cleanBasePath(basePath as string)}/dossierList/result/${
    dossierId.value
  }/dossierDetails`;
});
//function that open dossier main data and close other view
function goToMainData(event?: Event, fromOpenCorrectPage?: boolean) {
  if (fromOpenCorrectPage) {
    selectedCardInfo.value = null;
    showPrintHistory.value = false;
    showGenericDossierData.value = true;
    showMovementHistory.value = false;
  } else {
    router
      .push({
        path: `${fixedRouteChunk.value}`,
      })
      .then((value) => {
        if (!value) {
          selectedCardInfo.value = null;
          showPrintHistory.value = false;
          showGenericDossierData.value = true;
          showMovementHistory.value = false;
        }
      });
  }
}

function showPrintHistoryView(event?: Event, fromOpenCorrectPage?: boolean) {
  if (fromOpenCorrectPage) {
    selectedCardInfo.value = null;
    showGenericDossierData.value = false;
    showPrintHistory.value = true;
    showMovementHistory.value = false;
    utilityAccordionOpened.value = true;
  } else {
    router
      .push({
        path: `${fixedRouteChunk.value}/print-history`,
      })
      .then((value) => {
        if (!value) {
          selectedCardInfo.value = null;
          showGenericDossierData.value = false;
          showPrintHistory.value = true;
          showMovementHistory.value = false;
          utilityAccordionOpened.value = true;
        }
      });
  }
}

function showMovementView(event?: Event, fromOpenCorrectPage?: boolean) {
  if (fromOpenCorrectPage) {
    selectedCardInfo.value = null;
    showPrintHistory.value = false;
    showGenericDossierData.value = false;
    showMovementHistory.value = true;
    utilityAccordionOpened.value = true;
  } else {
    router
      .push({
        path: `${fixedRouteChunk.value}/history`,
      })
      .then((value) => {
        if (!value) {
          selectedCardInfo.value = null;
          showPrintHistory.value = false;
          showGenericDossierData.value = false;
          showMovementHistory.value = true;
          utilityAccordionOpened.value = true;
        }
      });
  }
}

function openCard(cardInfo: SelectedCard, fromInit?: boolean) {
  const cardInfoUpdated = Object.assign({}, cardInfo);
  cardInfoUpdated.partyCode = cuaa.value;

  showGenericDossierData.value = false;
  showGenericDossierData.value = false;
  showMovementHistory.value = false;
  showPrintHistory.value = false;
  selectedCardInfo.value = cardInfoUpdated;

  let urlToRoute = selectedCardInfo.value.routerUrl ?? "";
  if (urlToRoute && !urlToRoute.startsWith("/")) {
    urlToRoute = "/" + urlToRoute;
  }
  const pathToRoute = `${cleanBasePath(
    basePath as string,
  )}/dossierList/result/${dossierId.value}/dossierDetails/${extractModuleId(
    cardInfo.softwareUrl,
  )}${urlToRoute}`;

  if (!fromInit && pathToRoute !== route.path) {
    const routeToNavigate = router.currentRoute.value;
    delete routeToNavigate.query["tab"];
    delete routeToNavigate.query["operationCode"];
    router.replace({
      ...routeToNavigate,
      query: route.query,
    });
  }
}

watch(
  () => formList,
  () => {
    if (formList.value) {
      fromFormTotree();
    }
  },
  { deep: true },
);

//TODO: To review
function extractDestination(
  softwareUrl: string | undefined,
  destination: string,
) {
  const splitted = (softwareUrl ?? "").split("/");
  if (splitted.length > 0) {
    const appForms = splitted.indexOf(destination);
    if (appForms > -1) {
      return splitted[appForms + 1];
    }
  }
  return undefined;
}

async function goBack() {
  router.push({
    name: "dossierListResults",
    params: {
      partyId: formList.value.partyId,
    },
    query: route.query,
  });
}

function handleCloseModal(reloadData = true) {
  changeStatusComponentVisible.value = false;
  if (reloadData) {
    executeTransitionPolling(true);
  }
}

async function waitForCloseModalAndReload() {
  changeStatusComponentVisible.value = false;
}

async function initAnomaliesData() {
  await dossierStore.loadDossierAnomalies(dossierId.value);
  notBlockingAnomalies.value = [];
  infoAnomalies.value = [];
  blockingAnomalies.value = [];
  anomaliesCount.value = {
    blocking: 0,
    notBlocking: 0,
    info: 0,
  } as AnomalyCount;
  if (dossierAnomalies.value && dossierAnomalies.value.length > 0) {
    dossierAnomalies.value.forEach((anomaly: DossierAnomalyModel) => {
      switch (anomaly.severity) {
        case AnomalySeverity.NOT_BLOCKING:
          notBlockingAnomalies.value.push(anomaly);
          break;
        case AnomalySeverity.INFO:
          infoAnomalies.value.push(anomaly);
          break;
        case AnomalySeverity.BLOCKING:
        default:
          blockingAnomalies.value.push(anomaly);
          break;
      }
    });
    anomaliesCount.value = {
      blocking: blockingAnomalies.value.length,
      notBlocking: notBlockingAnomalies.value.length,
      info: infoAnomalies.value.length,
    } as AnomalyCount;
  }
}

function isOpenPath(
  destinationModuleId: string | undefined,
  destinationRouteUrl: string | undefined,
  destinationPath: FormDetailsModel,
): boolean {
  let isOpen = false;
  if (
    destinationModuleId &&
    destinationPath.softwareUrl !== null &&
    destinationPath.softwareUrl.startsWith("/ui/" + destinationModuleId) &&
    destinationRouteUrl &&
    destinationPath.routerUrl !== null &&
    destinationPath.routerUrl.startsWith(destinationRouteUrl)
  ) {
    isOpen = true;
  }
  return isOpen;
}
/**
 * Function that allows you to hang a new branch in the right position within the tree
 * @param groupPath Branch to be integrated into the tree
 */
function appendPath(
  groupPath: (FormDetailsModel | FormGroupModel)[],
  destinationModuleId?: string,
  destinationRouteUrl?: string,
) {
  const destinationPath: FormDetailsModel = groupPath[
    groupPath.length - 1
  ] as FormDetailsModel;
  const isOpen = isOpenPath(
    destinationModuleId,
    destinationRouteUrl,
    destinationPath,
  );
  let curTree: CardNode[] | undefined = componentTree.value;
  let groupNode: FormDetailsModel | FormGroupModel | null = null;
  for (let i = 0; i < groupPath.length; i++) {
    groupNode = groupPath[i];
    const foundNode: CardNode | undefined = curTree?.find(
      (treeNode: CardNode) => {
        if (
          groupNode &&
          (groupNode as FormGroupModel).groupCode !== undefined
        ) {
          return (groupNode as FormGroupModel).groupCode == treeNode.id;
        }
      },
    ) as CardNode;
    if (foundNode) {
      curTree = foundNode.children;
    } else {
      let genericNode: CardNode;
      if ((groupNode as FormGroupModel).groupCode !== undefined) {
        const actGroup = groupNode as FormGroupModel;
        genericNode = {
          id: actGroup.groupCode,
          name: actGroup.groupName ? actGroup.groupName : "",
          isOpen: isOpen,
          children: [],
        };
      } else {
        const leafNode = groupNode as FormDetailsModel;
        genericNode = {
          id: leafNode.formCode,
          formConfigId: leafNode.formConfigId
            ? leafNode.formConfigId
            : undefined,
          name: leafNode.formName ? leafNode.formName : "",
          softwareUrl: leafNode.softwareUrl,
          routerUrl: leafNode.routerUrl ? leafNode.routerUrl : undefined,
          compileStatus: leafNode.compileStatus
            ? (leafNode.compileStatus as CardState)
            : undefined,
          compileStatusIdentifier: leafNode.compileStatusIdentifier
            ? leafNode.compileStatusIdentifier
            : undefined,
          formCode: leafNode.formCode ? leafNode.formCode : undefined,
          sortOrder: leafNode.sortOrder,
          params: leafNode.params,
          flReadOnly: leafNode.flReadOnly,
          partyId: formList.value.partyId,
          partyCode: cuaa.value,
        };
      }
      curTree?.push(genericNode);
      if (i < groupPath.length - 1 && curTree) {
        curTree = (curTree[curTree.length - 1] as CardNode).children;
      }
      if (isOpen && curTree) {
        componentTree.value.forEach((x) => {
          if (x.isOpen !== undefined) {
            x.isOpen = true;
          }
          recursiveOpenTree(x.children);
        });
      }
    }
  }
}

function recursiveOpenTree(children?: CardNode[]) {
  if (children && children.length > 0) {
    children.forEach((x) => {
      if (x.isOpen !== undefined) {
        x.isOpen = true;
      }
      recursiveOpenTree(x.children);
    });
  }
}

interface NodeTreePath {
  path: (FormDetailsModel | FormGroupModel)[];
}

function openCorrectPage(): { moduleId: string; routeUrl: string } | undefined {
  const moduleIdBlackList = ["print-history", "history"],
    moduleId = extractDestination(route.path, "dossierDetails");
  // if destination url is not a form
  if (moduleId === undefined || moduleIdBlackList.includes(moduleId)) {
    const destination = extractDestination(route.fullPath, "dossierDetails");
    switch (destination) {
      case "print-history":
        showPrintHistoryView(undefined, true);
        break;
      case "history":
        showMovementView(undefined, true);
        break;
      default:
        goToMainData(undefined, true);
        break;
    }
  } else {
    const routeUrlSegments = route.path
      .split("/")
      .slice(route.path.split("/").indexOf(moduleId) + 1);
    return {
      moduleId: moduleId,
      routeUrl: routeUrlSegments.length ? "/" + routeUrlSegments.join("/") : "",
    };
  }
}

function fromFormTotree() {
  componentTree.value = [];
  const completePath: NodeTreePath[] = [];
  formList.value.forms.forEach((form) => {
    let nodeAndLeaf: (FormDetailsModel | FormGroupModel)[] = [];
    nodeAndLeaf = nodeAndLeaf.concat(form.groups);
    nodeAndLeaf = nodeAndLeaf.concat(form.formDetails);
    completePath.push({ path: nodeAndLeaf });
  });
  const currentPage = openCorrectPage();
  completePath.forEach((branch: NodeTreePath) => {
    appendPath(
      branch.path,
      currentPage?.moduleId || "",
      currentPage?.routeUrl || "",
    );
  });
}
async function refreshData(routePage = true) {
  infoAnomalies.value = [];
  blockingAnomalies.value = [];
  notBlockingAnomalies.value = [];
  infoAnomalies.value = [];
  await dossierStore.loadDossierDetails(dossierId.value, true);
  componentTree.value = [];
  await dossierStore.loadDossierTransitions(dossierId.value);
  fromFormTotree();
  await initAnomaliesData();

  if (showMovementHistory.value)
    dossierStore.loadDossierHistory(dossierId.value, true);

  if (routePage) {
    conditionallyRoutePage();
  }
}

// function that execute polling
async function executeTransitionPolling(forceReload = false) {
  isLoadingTransitionData.value = true;
  const isInTransition = dossierStore.getIsInTransition;
  if (isInTransition && !forceReload) {
    let condition = true;
    while (condition) {
      console.log("start while");
      if (formList.value && formList.value.dossierId) {
        console.log("doing call");
        condition = await doCall(formList);
      }
      console.log("awaiting");
      await wait(5000);
    }
  } else {
    await refreshData();
    goToMainData();
  }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function doCall(formList: any) {
  await dossierStore.loadIsInTransition(formList.value.dossierId);
  if (dossierStore.getIsInTransition === false) {
    isLoadingTransitionData.value = false;
    await refreshData();
    goToMainData();
    return false;
  }
  return true;
}

function openFormPage(
  destinationModuleId: string,
  destinationRouteUrl: string,
  fromInit?: boolean,
) {
  const forms = formList.value.forms;
  const queryParams = destinationRouteUrl.split("?")[1];
  const paramsList = queryParams ? queryParams.split("&") : [];
  const paramsKeys: Record<string, string> = {};
  paramsList.forEach((el: string) => {
    const elKey = el.split("=")[0];
    if (
      ![
        "formConfigId",
        "readOnly",
        "partyId",
        "compileStatusIdentifier",
        "partyCode",
        "formCode",
      ].includes(elKey)
    )
      paramsKeys[elKey] = el.split("=")[1];
  });

  const selectedForm = forms.find((form: FormModel) => {
    if (
      form.formDetails.softwareUrl &&
      form.formDetails.softwareUrl.startsWith("/ui/" + destinationModuleId) &&
      form.formDetails.routerUrl &&
      form.formDetails.routerUrl.startsWith(destinationRouteUrl) &&
      JSON.stringify(form.formDetails.params) === JSON.stringify(paramsKeys)
    ) {
      return true;
    }
  });
  // The form was found
  if (selectedForm?.formDetails) {
    const localCardInfo: SelectedCard = fromFormDetailsModelToSelectedCard(
      selectedForm.formDetails,
      formList.value.partyId,
      cuaa.value,
    );
    openCard(localCardInfo, fromInit);
  }
}

//TODO: To do the if that will contain the verification of the presence or absence of the dossier
//TODO: Enter the correct value in the API call
onMounted(async () => {
  await initPageLogic();
});

async function initPageLogic() {
  if (dossierId?.value != null) {
    await dossierStore.loadDossierTransitions(dossierId.value);
  }
  if (formList.value === null && dossierId?.value) {
    await dossierStore.loadDossierDetails(dossierId.value, true);
  } else {
    if (formList.value && formList.value.partyId) {
      await dossierStore.loadParty(formList.value.partyId);
    }
    fromFormTotree();
  }
  if (cuaa.value == "" && formList.value && formList.value.partyId) {
    await dossierStore.loadParty(formList.value.partyId);
  }
  conditionallyRoutePage(true);
  await initAnomaliesData();
  // Code needed to know if the dossier is transitioning
  await dossierStore.loadIsInTransition(formList.value.dossierId);
  if (dossierStore.getIsInTransition === true) {
    executeTransitionPolling();
  }
}

function conditionallyRoutePage(fromInit?: boolean) {
  const currentPage = openCorrectPage();
  if (currentPage) {
    openFormPage(currentPage.moduleId, currentPage.routeUrl, fromInit);
  }
}

function callRefreshDataWithoutRouting() {
  refreshData(false);
}
// this is needed to update forms compile statuses: application-forms-ui (should) sends "form-compiled" event whenever a form is compiled
window.addEventListener("form-compiled", callRefreshDataWithoutRouting);

onUnmounted(() => {
  window.removeEventListener("form-compiled", callRefreshDataWithoutRouting);
});

watch(openPrintModal, () => {
  if (openPrintModal.value === false) {
    document.body.classList.remove("modal-open");
    document.body.style.removeProperty("overflow");
    document.body.style.removeProperty("padding-right");
  }
});
</script>

<style scoped>
.align-center {
  display: flex;
  flex-direction: column;
  align-items: center;
}
.cursor-pointer {
  cursor: pointer;
}
.underline-hover:hover {
  text-decoration: underline;
}
.text-small {
  font-size: 0.88889rem;
}

.second-level-card {
  font-weight: 600;
}

.no-dot {
  list-style-type: none;
}
.title {
  font-weight: bold;
  font-size: 1.111em;
}
</style>

<template>
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded', 'px-0']">
      <template #card-header>
        <TopBar
          :isBackButton="true"
          :backButtonFunction="() => goBack()"
          :title="
            t(`${moduleId}.dossierDetails.title`) +
            ' ' +
            formList?.moduleDescription
              ? formList?.moduleDescription
              : ''
          "
          :buttonList="[
            {
              hideButton:
                anomaliesCount.blocking +
                  anomaliesCount.notBlocking +
                  anomaliesCount.info <=
                0,
              text: t(`${moduleId}.dossierDetails.actions.anomaly`, {
                count: anomaliesButtonInfo.count,
              }),
              classes: `${anomaliesButtonInfo.style} ms-2 text-nowrap`,
              callback: () => {
                showAnomaliesModal = true;
              },
            },
            {
              hideButton:
                prints.length === 0 || dossierStore.isFunctionReadOnly,
              text: t(`${moduleId}.dossierDetails.actions.print`),
              classes: `${getColor(
                'button',
                'primary',
                'outline',
              )} ms-2 text-nowrap`,
              callback: () => {
                openPrintModal = true;
              },
            },
            {
              text: t(`${moduleId}.dossierDetails.actions.stateTransition`),
              hideButton:
                !transitions ||
                transitions.length === 0 ||
                dossierStore.isFunctionReadOnly,
              classes: `${getColor(
                'button',
                'primary',
                'outline',
              )} text-nowrap ms-2`,
              callback: () => {
                changeStatusComponentVisible = true;
              },
            },
          ]"
        />
      </template>
      <template #card-body>
        <div class="container row m-0 px-0">
          <div class="col-12 pe-0 pe-lg-2 col-lg-3 ps-0 mb-3">
            <!--Main data "group" -->
            <div
              class="w-100 p-2 ps-3 mb-3 dossier-module__group-detail-header text-uppercase"
              :class="getColor('text', 'white')"
            >
              <span class="cursor-pointer underline-hover" @click="goToMainData"
                >{{ t(`${moduleId}.cardMenu.mainData`) }}
              </span>
            </div>

            <!-- Main card group example: scheda domanda, utilities ... -->
            <div class="mb-3" v-for="node in componentTree" :key="node.id">
              <BiAccordion
                :model-value="node.isOpen"
                :title="node.name"
                :body-extra-class="'border pe-0 pt-0 pb-2 ps-0 ps-3'"
                header-extra-class="dossier-module__group-detail-header text-uppercase dossier-module__accordion-header-padding"
                color-bg-header="primary"
                color-header="white"
                headerArrowExtraClass="py-2"
              >
                <!-- Second level - sub group of cards  -->
                <template
                  v-if="node && node.children && node.children.length > 0"
                >
                  <template v-for="(subNode, i) in node.children" :key="i">
                    <!-- Second level accordion - sub card group -->
                    <template
                      v-if="
                        subNode &&
                        subNode.children &&
                        subNode.children.length > 0
                      "
                    >
                      <SecondLevelCardAccordion
                        @openCard="openCard($event)"
                        :node="subNode"
                        :selectedCardId="
                          selectedCardInfo ? selectedCardInfo.id : null
                        "
                      />
                    </template>
                    <!-- Second level card - no sub card group-->
                    <template v-else>
                      <SecondLevelCard
                        :key="i"
                        @openCard="openCard($event)"
                        :node="subNode"
                        :selectedCardId="
                          selectedCardInfo ? selectedCardInfo.id : null
                        "
                      />
                    </template>
                  </template>
                </template>
              </BiAccordion>
            </div>

            <BiAccordion
              :title="t(`${moduleId}.dossierDetails.utilities.title`)"
              :body-extra-class="'border pe-0 pt-0 mb-3 ps-0 pb-0'"
              header-extra-class="dossier-module__group-detail-header text-uppercase dossier-module__accordion-header-padding"
              :model-value="utilityAccordionOpened"
              color-bg-header="primary"
              color-header="white"
              headerArrowExtraClass="py-2"
            >
              <!-- Movement history-->
              <div
                class="second-level-card cursor-pointer pt-2 pb-2 underline-hover ps-3"
                :class="
                  showMovementHistory == true ? 'text-decoration-underline' : ''
                "
                @click="showMovementView"
              >
                {{ t(`${moduleId}.dossierDetails.movementHistory.title`) }}
              </div>
              <!-- Print history -->
              <div
                class="second-level-card cursor-pointer pt-2 pb-2 underline-hover ps-3"
                :class="
                  showPrintHistory == true ? 'text-decoration-underline' : ''
                "
                @click="showPrintHistoryView"
              >
                {{ t(`${moduleId}.dossierDetails.printHistory.title`) }}
              </div>
            </BiAccordion>
          </div>
          <div class="col-12 col-lg-9 pe-0 ps-0 ps-lg-2">
            <CentralBoxHeader
              :dossierProcessStatus="
                formList &&
                formList.processStatusDescription &&
                formList.processStatusDescription
                  ? formList.processStatusDescription
                  : ''
              "
            />
            <CardCentralBox
              v-if="selectedCardInfo !== null"
              :cardInfo="selectedCardInfo"
            ></CardCentralBox>
            <GenericDossierInfo
              v-if="showGenericDossierData && formList"
              :dossier="formList"
            />
            <MovementHistory v-if="showMovementHistory" />
            <PrintHistory v-if="showPrintHistory" />
          </div>
        </div>
      </template>
    </BiCard>
  </div>
  <!-- :title="t(`${moduleId}.dossierDetails.anomalies`)" -->
  <BiModal
    :disabled-teleport="true"
    v-model="showAnomaliesModal"
    ariaLabelledby="noMembers"
    size="xl"
  >
    <template #body>
      <div class="row d-flex mt-3 mb-3">
        <div class="col-12 col-md-6 col-lg-7 col-xl-7">
          <h4 class="title" :class="getColor('text', 'primary')">
            {{ t(`${moduleId}.dossierDetails.anomalies`) }}
          </h4>
        </div>
      </div>
      <div class="mb-3 text-secondary text-small">
        <span
          ><strong
            >{{
              t(`${moduleId}.dossierDetails.anomaliesModal.lastRecalcDate`)
            }}: </strong
          >{{
            lastAnomaliesRecalcDate
              ? getFormattedDate(lastAnomaliesRecalcDate, true)
              : ""
          }}</span
        >
      </div>
      <BiTable
        class="table-responsive pt-3"
        extraTableClasses="table-head-bg"
        isResponsive
      >
        <template v-slot:head>
          <tr
            class="bg-light text-start"
            :class="getColor('text', 'secondary')"
          >
            <th scope="col" class="text-center">
              {{ t(`${moduleId}.dossierDetails.anomaliesModal.severity`) }}
            </th>
            <th scope="col" class="text-center">
              {{ t(`${moduleId}.dossierDetails.anomaliesModal.code`) }}
            </th>
            <th scope="col" class="text-start">
              {{ t(`${moduleId}.dossierDetails.anomaliesModal.description`) }}
            </th>
          </tr>
        </template>
        <template v-slot:body>
          <tr
            v-for="(anomaly, i) in [
              ...blockingAnomalies,
              ...notBlockingAnomalies,
              ...infoAnomalies,
            ]"
            :key="i"
            class="align-middle"
          >
            <td
              :data-label="
                t(`${moduleId}.dossierDetails.anomaliesModal.severity`)
              "
              class="text-center"
            >
              <BiIcon
                :icon="
                  anomaly.severity === AnomalySeverity.BLOCKING
                    ? 'circle-exclamation'
                    : anomaly.severity === AnomalySeverity.NOT_BLOCKING
                      ? 'triangle-exclamation'
                      : 'circle-info'
                "
                :color="
                  anomaly.severity === AnomalySeverity.BLOCKING
                    ? 'danger'
                    : anomaly.severity === AnomalySeverity.NOT_BLOCKING
                      ? 'warning'
                      : 'info'
                "
                size="xl"
                icon-style="solid"
              />
            </td>
            <td
              :data-label="t(`${moduleId}.dossierDetails.anomaliesModal.code`)"
              class="text-center"
            >
              {{ anomaly.anomalyCode }}
            </td>
            <td
              :data-label="
                t(`${moduleId}.dossierDetails.anomaliesModal.description`)
              "
              class="text-start"
            >
              {{ anomaly.anomalyDesc }}
            </td>
          </tr>
        </template>
      </BiTable>
      <div
        v-if="isInTransitionMessages?.lastTransitionLog?.messages.length !== 0"
        class="row d-flex mt-5 mb-1"
      >
        <div class="col-12 col-md-6 col-lg-7 col-xl-7">
          <h4 class="title" :class="getColor('text', 'primary')">
            {{ t(`${moduleId}.dossierDetails.messages`) }}
          </h4>
        </div>
      </div>
      <BiTable
        v-if="isInTransitionMessages?.lastTransitionLog?.messages.length !== 0"
        class="table-responsive pt-3"
        extraTableClasses="table-head-bg"
        isResponsive
      >
        <template v-slot:head>
          <tr
            class="bg-light text-start"
            :class="getColor('text', 'secondary')"
          >
            <th scope="col">
              {{ t(`${moduleId}.dossierDetails.anomaliesModal.message`) }}
            </th>
          </tr>
        </template>
        <template v-slot:body>
          <tr
            v-for="message in isInTransitionMessages?.lastTransitionLog
              ?.messages"
            class="align-middle"
            :key="JSON.stringify(message)"
          >
            <td
              :data-label="
                t(`${moduleId}.dossierDetails.anomaliesModal.message`)
              "
              class="text-start"
            >
              {{ message.code + " - " + message.description }}
            </td>
          </tr>
        </template>
      </BiTable>
    </template>
    <template #footer>
      <div class="col text-center mb-5">
        <BiButton
          color="primary"
          is-outlined
          @click.stop="() => (showAnomaliesModal = false)"
        >
          {{ t(`${moduleId}.general.close`) }}
        </BiButton>
      </div>
    </template>
  </BiModal>
  <!-- Print modal -->
  <BiModal
    v-if="openPrintModal"
    :disabled-teleport="true"
    v-model="openPrintModal"
    :ariaLabelledby="t(`${moduleId}.dossierDetails.printModal.title`)"
    :title="t(`${moduleId}.dossierDetails.printModal.title`)"
    :extra-footer-class="'justify-content-center'"
    size="lg"
  >
    <template #body>
      <DossierPrintModal :dossierId="dossierId" />
    </template>
    <template #footer>
      <BiButton
        color="primary"
        is-outlined
        @click.stop="() => (openPrintModal = false)"
      >
        {{ t(`${moduleId}.general.close`) }}
      </BiButton>
    </template>
  </BiModal>
  <DossierChangeStatusModal
    v-if="changeStatusComponentVisible"
    :open-modal="changeStatusComponentVisible"
    @close-modal="handleCloseModal"
    :transition-list="transitions"
    @hidden-progress-status-done="waitForCloseModalAndReload"
    :dossier-id="dossierId"
    :dossier="formList"
  />
</template>
