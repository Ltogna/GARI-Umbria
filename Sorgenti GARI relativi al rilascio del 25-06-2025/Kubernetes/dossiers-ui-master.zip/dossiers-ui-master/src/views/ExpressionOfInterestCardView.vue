<script setup lang="ts">
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiToggle from "@abaco/bootstrap-italia-components/src/components/form/BiToggle.vue";
import { inject, ref } from "vue";
import { useI18n } from "vue-i18n";

const moduleId = inject("moduleId");
const { t } = useI18n({});

const mockResponse = ref([
  {
    prize: "Grano",
    eligibility: true,
    expressionOfInterest: true,
  },
  {
    prize: "Zucchero",
    eligibility: true,
    expressionOfInterest: false,
  },
  {
    prize: "ZooTecnia",
    eligibility: false,
    expressionOfInterest: false,
  },
  {
    prize: "Giovane Agricoltore",
    eligibility: false,
    expressionOfInterest: false,
  },
]);
</script>
<template>
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded']">
      <template #card-header> </template>
      <template #card-body>
        <div class="container col-12 px-3 mx-0">
          <BiTable
            class="table-responsive"
            extraTableClasses="table-head-bg"
            isResponsive
          >
            <template v-slot:head>
              <tr class="bg-light text-center text-secondary">
                <th scope="col">
                  {{ t(`${moduleId}.expressionOfInterest.table.prize`) }}
                </th>
                <th scope="col">
                  {{ t(`${moduleId}.expressionOfInterest.table.eligibility`) }}
                </th>
                <th scope="col">
                  {{
                    t(
                      `${moduleId}.expressionOfInterest.table.expressionOfInterest`,
                    )
                  }}
                </th>
              </tr>
            </template>
            <template
              v-slot:body
              v-if="mockResponse && mockResponse.length > 0"
            >
              <tr
                class="align-middle text-center"
                v-for="element in mockResponse"
                :key="element.prize"
              >
                <td
                  :data-label="
                    t(`${moduleId}.expressionOfInterest.table.prize`)
                  "
                >
                  {{ element.prize }}
                </td>
                <td
                  :data-label="
                    t(`${moduleId}.expressionOfInterest.table.eligibility`)
                  "
                >
                  <BiIcon
                    v-if="element.eligibility"
                    icon="circle-check"
                    color="success"
                    size="2x"
                  ></BiIcon>
                  <BiIcon
                    v-else
                    icon="circle-xmark"
                    color="danger"
                    size="2x"
                  ></BiIcon>
                </td>
                <td
                  :data-label="
                    t(
                      `${moduleId}.expressionOfInterest.table.expressionOfInterest`,
                    )
                  "
                >
                  <BiToggle
                    :id="element.prize"
                    label=""
                    class="justify-content-center d-flex"
                    :isDisabled="!element.eligibility"
                    :isInForm="false"
                    :isInGroup="false"
                    :modelValue="element.expressionOfInterest"
                  ></BiToggle>
                </td>
              </tr>
            </template>
          </BiTable>
        </div>
      </template>
    </BiCard>
  </div>
</template>
