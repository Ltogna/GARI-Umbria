import type {
  CreateDossierModel,
  CreateDossierResponseModel,
  DossierAnomalyResponseModel,
  DossierDetailsModel,
  DossierFilter,
  DossierHistoryModel,
  DossierIsInTransitionModel,
  DossierListModel,
  DossierModulesResponse,
  DossierTransitionsModel,
  DossierTypesModel,
  PartyListModel,
  PartyModel,
  PartyRegistryListModel,
  PrintHistoryResponseModel,
  TenantConfigModel,
} from "@/models/dossier";
import {
  handleApiErrorAndShowAlert,
  mapSingleElementData,
  mapSubjectsData,
} from "@/models/utils";
import {
  createDossier,
  downloadPrint,
  generatePrint,
  getDossierAnomalies,
  getDossierDetails,
  getDossierHistory,
  getDossierList,
  getDossierModules,
  getDossierPrintHistory,
  getDossierTransitions,
  getIsInTransition,
  getOngoingPrints,
  getParties,
  getParty,
  loadDossierTypes,
  loadTenantConfigsAPI,
  loadUserFunctionsAPI,
  updateDossierStatus,
} from "@/resources/api/dossierApi";
import type { UserFunctionArrayModel } from "@/resources/api/login";
import {
  ErrorType,
  type HttpResponseError,
} from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";

export enum RegistryEnvironment {
  LEGACY = "legacy",
  PARTYREGISTRY = "party-registry",
  PARTY_REGISTRY_DIRECTORY_URL = "party_registry_directory_url",
  PARTY_REGISTRY_DIRECTORY_SEARCH_URL = "party_registry_directory_search_url",
  DISABLE_NEW_DOSSIER_BUTTON_CONTEXT_FUNCTION = "disable_new_dossier_button_context_function",
}

interface DossierInformation {
  transitionData: DossierIsInTransitionModel | null;
  transitionStatus?: string;
  dossierTransitions: DossierTransitionsModel | null;
  dossierHistory: DossierHistoryModel | null;
  dossierDetails: DossierDetailsModel | null;
  dossierModules: DossierModulesResponse | null;
  printHistory: PrintHistoryResponseModel | null;
  ongoingPrints: PrintHistoryResponseModel | null;
  loadingOngoingPrints: boolean;
}

interface State {
  dossierTypes: DossierTypesModel | null;
  dossierList: DossierListModel | null;
  dossierListFilter: DossierFilter;
  subjectList: PartyListModel | null;
  createDossierResponse: CreateDossierResponseModel | null;
  loading: boolean;
  hasError: boolean;
  errorResponse?: HttpResponseError;
  selectedSubject: PartyModel | null;
  dossier: { [key: string]: DossierInformation };
  routeDossierId: string;
  dossierAnomalies: { [key: string]: DossierAnomalyResponseModel };
  registryEnvironment: string;
  tenantConfigs: Record<string, string | number | boolean>;
  userFunctions: UserFunctionArrayModel | null;
  isFunctionReadOnly: boolean;
}
export const NOT_ALLOWED_MULTIPLE_DOSSIERS_ERROR =
  "NOT_ALLOWED_MULTIPLE_DOSSIERS_ERROR";
export const DOSSIER_CREATION_ERROR = "DOSSIER_CREATION_ERROR";

export const useDossierStore = defineStore({
  id: "dossierStore",
  state: () =>
    ({
      dossierTypes: null,
      dossierList: null,
      dossierListFilter: {
        dossierType: "",
        dossierTypeDescription: "",
        includeClosedDossier: false,
      },
      selectedSubject: null,
      subjectList: null,
      createDossierResponse: null,
      loading: false,
      hasError: false,
      errorResponse: undefined,
      dossier: {},
      routeDossierId: "",
      dossierAnomalies: {},
      tenantConfigs: {},
      userFunctions: null,
      isFunctionReadOnly: false,
    }) as State,
  getters: {
    getDossierTypes: (state: State) => {
      return state.dossierTypes;
    },
    getDossierList: (state: State) => {
      return state.dossierList;
    },
    getDossierListFilter: (state: State) => {
      return state.dossierListFilter;
    },
    getDossierModules: (state: State) => {
      return state.dossier[state.routeDossierId]?.dossierModules;
    },
    getSelectedSubject: (state: State) => {
      return state.selectedSubject;
    },
    getSubjectList: (state: State) => {
      return state.subjectList?.records;
    },
    getCreateDossierResponse: (state: State) => {
      return state.createDossierResponse;
    },
    getDossierDetails: (state: State): DossierDetailsModel => {
      return state.dossier[state.routeDossierId]
        .dossierDetails as DossierDetailsModel;
    },
    getDossierHistory: (state: State): DossierHistoryModel => {
      return state.dossier[state.routeDossierId]
        .dossierHistory as DossierHistoryModel;
    },
    getDossierTransitions: (state: State): DossierTransitionsModel => {
      return state.dossier[state.routeDossierId]
        .dossierTransitions as DossierTransitionsModel;
    },
    getDossierAnomalies: (state: State): DossierAnomalyResponseModel => {
      return state.dossierAnomalies[
        state.routeDossierId
      ] as DossierAnomalyResponseModel;
    },
    getErrorResponse: (state: State) => {
      return state.errorResponse;
    },
    getIsInTransition: (state: State) => {
      return state.dossier[state.routeDossierId].transitionData?.inTransition;
    },
    getTransitionStatus: (state: State) => {
      return state.dossier[state.routeDossierId]?.transitionStatus;
    },
    getTransitionData: (state: State) => {
      return state.dossier[state.routeDossierId].transitionData;
    },
    getPrintHistory: (state: State) => {
      return state.dossier[state.routeDossierId].printHistory;
    },
    getOngoingPrints: (state: State) => {
      return state.dossier[state.routeDossierId].ongoingPrints;
    },
    getLoadingOnGoingPrints: (state: State) => {
      return state.dossier[state.routeDossierId].loadingOngoingPrints;
    },
    getIsLoading: (state: State) => {
      return state.loading;
    },
    getUserFunctions: (state: State) => {
      return state.userFunctions;
    },
    getIsFunctionReadOnly: (state: State) => {
      return state.isFunctionReadOnly;
    },
  },
  actions: {
    async searchSubjects(cuaa?: string | null, partyDesc?: string | null) {
      this.loading = true;
      this.hasError = false;
      const useCuaa = cuaa?.trimEnd();
      const usePartyDesc = partyDesc?.trimEnd();
      const actualNextKey = this.subjectList?.nextKey;
      const response = await getParties(
        this.registryEnvironment,
        this.tenantConfigs[
          RegistryEnvironment.PARTY_REGISTRY_DIRECTORY_SEARCH_URL
        ] as string,
        useCuaa,
        usePartyDesc,
        actualNextKey,
      );

      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
      } else {
        if (this.subjectList) {
          this.subjectList.records.push(
            ...mapSubjectsData(response.data.records, this.registryEnvironment),
          );
          this.subjectList.nextKey = response.data.nextKey;
        } else {
          const notMappedData: PartyListModel | PartyRegistryListModel =
            response.data;
          notMappedData.records = mapSubjectsData(
            notMappedData.records,
            this.registryEnvironment,
          );
          const mappedData: PartyListModel = notMappedData as PartyListModel;
          this.subjectList = mappedData;
        }
      }
      this.loading = false;
    },
    async loadDossierTypes(handleError = false) {
      this.loading = true;
      this.hasError = false;
      const response = await loadDossierTypes();
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        if (handleError) {
          handleApiErrorAndShowAlert(response);
        }
      } else {
        this.dossierTypes = response.data;
      }
      this.loading = false;
    },
    async loadDossierList(
      partyId: number,
      filters: { dossierType?: string; includeClosedDossier?: boolean },
      nextKey?: string | null,
    ) {
      this.loading = true;
      this.hasError = false;
      const response = await getDossierList(partyId, filters, nextKey);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        handleApiErrorAndShowAlert(response);
        this.errorResponse = response as HttpResponseError;
      } else {
        if (nextKey === undefined) {
          this.dossierList = response.data;
        } else {
          this.dossierList && (this.dossierList.count = response.data.count);
          this.dossierList &&
            (this.dossierList.nextKey = response.data.nextKey);
          this.dossierList?.records.push(...(response.data?.records ?? []));
        }
      }
      this.loading = false;
    },
    async loadDossierModules(point_in_time?: string, nextKey?: string) {
      this.loading = true;
      this.hasError = false;
      const response = await getDossierModules(point_in_time, nextKey);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        handleApiErrorAndShowAlert(response);
      } else {
        if (
          this.dossier[this.routeDossierId] &&
          this.dossier[this.routeDossierId].dossierModules &&
          nextKey
        ) {
          (
            this.dossier[this.routeDossierId]
              .dossierModules as DossierModulesResponse
          ).records.push(...response.data.records);
          (
            this.dossier[this.routeDossierId]
              .dossierModules as DossierModulesResponse
          ).count = response.data.count;
          (
            this.dossier[this.routeDossierId]
              .dossierModules as DossierModulesResponse
          ).nextKey = response.data.nextKey;
        } else {
          this.dossier[this.routeDossierId].dossierModules = response.data;
        }
      }
      this.loading = false;
    },
    setTransitionData(input: DossierIsInTransitionModel) {
      this.dossier[this.routeDossierId].transitionData = input;
    },
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    setDefaultErrorTransition(defaultErrorMsg: any) {
      this.setTransitionData({
        inTransition: false,
        lastTransitionLog: {
          id: 0,
          startDate: new Date().getTime(),
          endDate: 0,
          userId: "",
          processId: 0,
          transitionId: 0,
          notes: null,
          failed: true,
          description: "",
          fromNode: "",
          fromNodeDescription: null,
          toNode: "",
          toNodeDescription: null,
          messages: [defaultErrorMsg],
        },
      });
    },
    async createDossier(newDossier: CreateDossierModel) {
      this.hasError = false;
      this.createDossierResponse = null;
      const defaultErrorMsg = {
        code: DOSSIER_CREATION_ERROR,
        description: DOSSIER_CREATION_ERROR,
        type: "ERROR",
      };
      const response = await createDossier(newDossier);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.setDefaultErrorTransition(defaultErrorMsg);
        handleApiErrorAndShowAlert(response, false);
      } else {
        if (response.data.anomalies && response.data.anomalies.length > 0) {
          if (
            response.data.anomalies.find(
              (x) => x.code === NOT_ALLOWED_MULTIPLE_DOSSIERS_ERROR,
            )
          ) {
            defaultErrorMsg.code = NOT_ALLOWED_MULTIPLE_DOSSIERS_ERROR;
            defaultErrorMsg.description = NOT_ALLOWED_MULTIPLE_DOSSIERS_ERROR;
          }
          this.setDefaultErrorTransition(defaultErrorMsg);
        } else {
          this.createDossierResponse = response.data;
        }
      }
    },
    async loadDossierDetails(dossierId: number, handleError = false) {
      this.loading = true;
      this.hasError = false;
      const response = await getDossierDetails(dossierId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        if (handleError) {
          handleApiErrorAndShowAlert(response);
        }
      } else {
        this.setRouteDossierId(dossierId.toString());
        this.dossier[this.routeDossierId].dossierDetails = response.data;
      }
      this.loading = false;
    },
    async loadDossierHistory(dossierId: number, handleError = false) {
      this.loading = true;
      this.hasError = false;
      const response = await getDossierHistory(dossierId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        if (handleError) {
          handleApiErrorAndShowAlert(response);
        }
      } else {
        this.dossier[this.routeDossierId].dossierHistory = response.data;
      }
      this.loading = false;
    },
    async loadDossierAnomalies(dossierId: number, handleError = false) {
      this.loading = true;
      this.hasError = false;
      const response = await getDossierAnomalies(dossierId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        if (handleError) {
          handleApiErrorAndShowAlert(response);
        }
      } else {
        this.setRouteDossierId(dossierId.toString());
        this.dossierAnomalies[this.routeDossierId] = response.data;
      }
      this.loading = false;
    },
    async loadParty(partyId: number) {
      this.loading = true;
      if (
        !this.tenantConfigs[RegistryEnvironment.PARTY_REGISTRY_DIRECTORY_URL]
      ) {
        await this.loadTenantConfigs();
      }
      const response = await getParty(
        partyId,
        this.tenantConfigs[
          RegistryEnvironment.PARTY_REGISTRY_DIRECTORY_URL
        ] as string,
      );
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.loading = false;
        handleApiErrorAndShowAlert(response);
        return response;
      } else {
        this.hasError = false;
        this.selectedSubject = mapSingleElementData(
          response.data,
          this.registryEnvironment,
        );
      }
      this.loading = false;
    },
    async loadDossierTransitions(dossierId: number) {
      this.loading = true;
      const response = await getDossierTransitions(dossierId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
      } else {
        this.hasError = false;
        this.dossier[this.routeDossierId].dossierTransitions = response.data;
      }
      this.loading = false;
    },
    async loadIsInTransition(dossierId: number) {
      this.loading = true;
      const response = await getIsInTransition(dossierId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.loading = false;
        handleApiErrorAndShowAlert(response);
        return response;
      } else {
        this.hasError = false;
        this.dossier[this.routeDossierId].transitionData = response.data;
      }
      this.loading = false;
    },
    async loadDossierPrintHistory(dossierId: number, handleError = false) {
      this.loading = true;
      this.hasError = false;
      const response = await getDossierPrintHistory(dossierId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        if (handleError) {
          handleApiErrorAndShowAlert(response);
        }
      } else {
        this.dossier[this.routeDossierId].printHistory = response.data;
      }
      this.loading = false;
    },
    async loadOngoingPrints(handleError = false) {
      this.loading = true;
      this.hasError = false;
      const response = await getOngoingPrints(
        Number.parseInt(this.routeDossierId),
      );
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        if (handleError) {
          handleApiErrorAndShowAlert(response);
        }
      } else {
        this.dossier[this.routeDossierId].ongoingPrints = response.data;
      }
      this.loading = false;
    },
    async loadTenantConfigs() {
      this.loading = true;
      this.hasError = false;
      const response = await loadTenantConfigsAPI();
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        handleApiErrorAndShowAlert(response);
      } else {
        response.data.forEach((config: TenantConfigModel) => {
          this.tenantConfigs[config.key] = config.value;
        });
      }

      if (
        !this.tenantConfigs[
          RegistryEnvironment.PARTY_REGISTRY_DIRECTORY_SEARCH_URL
        ]
      ) {
        this.tenantConfigs[
          RegistryEnvironment.PARTY_REGISTRY_DIRECTORY_SEARCH_URL
        ] = "/party-registry/{tenant}/public/v1/parties";
      }

      if (
        !this.tenantConfigs[RegistryEnvironment.PARTY_REGISTRY_DIRECTORY_URL]
      ) {
        this.tenantConfigs[RegistryEnvironment.PARTY_REGISTRY_DIRECTORY_URL] =
          "/party-registry/{tenant}/public/v1/parties/{partyId}";
      }

      if (
        (
          this.tenantConfigs[
            RegistryEnvironment.PARTY_REGISTRY_DIRECTORY_SEARCH_URL
          ] as string
        ).includes(RegistryEnvironment.PARTYREGISTRY)
      ) {
        this.setRegistryEnvironment(RegistryEnvironment.PARTYREGISTRY);
      } else this.setRegistryEnvironment(RegistryEnvironment.LEGACY);
      this.loading = false;
    },
    setSelectedSubject(subject: PartyModel | null) {
      this.selectedSubject = subject;
    },
    setDossierListFilter(dossierFilter: DossierFilter) {
      this.dossierListFilter = dossierFilter;
    },
    setTransitionStatus(transitionStatus: string) {
      this.dossier[this.routeDossierId].transitionStatus = transitionStatus;
    },
    setRouteDossierId(dossierId: string) {
      this.routeDossierId = dossierId;
      if (!this.dossier[this.routeDossierId] || dossierId === "new") {
        this.dossier[this.routeDossierId] = {
          dossierDetails: null,
          dossierHistory: null,
          dossierModules: null,
          dossierTransitions: null,
          transitionData: null,
          printHistory: null,
          ongoingPrints: null,
          loadingOngoingPrints: false,
        };
      }
    },
    setLoadingOngoingPrints(value: boolean) {
      this.dossier[this.routeDossierId].loadingOngoingPrints = value;
    },
    setRegistryEnvironment(key: string) {
      this.registryEnvironment = key;
    },
    setIsFunctionReadOnly(val: boolean) {
      this.isFunctionReadOnly = val;
    },
    clearDossierList() {
      this.dossierList = null;
    },
    clearSubjectList() {
      this.subjectList = null;
    },
    clearDossierListFilters() {
      this.dossierListFilter = {
        dossierType: "",
        dossierTypeDescription: "",
        includeClosedDossier: false,
      };
    },
    /**
     *  Function needed to change status
     */
    async changeStatus(
      dossierId: number,
      transition_id: string,
      notes?: string,
    ) {
      this.loading = true;
      const response = await updateDossierStatus(
        dossierId,
        transition_id,
        notes,
      );
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
      } else {
        this.hasError = false;
      }
      this.loading = false;
    },
    async doDownloadPrint(fileId: string) {
      this.loading = true;
      this.hasError = false;
      const response = await downloadPrint(
        Number.parseInt(this.routeDossierId),
        fileId,
      );

      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        handleApiErrorAndShowAlert(response);
        this.loading = false;
      } else {
        const _blob = await response.response.blob();
        this.loading = false;
        return {
          url: URL.createObjectURL(_blob),
          header: response.response.headers.get("Content-Disposition") || null,
        };
      }
    },
    async doGeneratePrint(printCode: string) {
      const response = await generatePrint(
        Number.parseInt(this.routeDossierId),
        printCode,
      );
      if (response.errorType !== ErrorType.NONE) {
        throw new Error("print error");
      } else {
        return response.data;
      }
    },
    async loadUserFunctions(handleError = false) {
      this.loading = true;
      this.hasError = false;
      const response = await loadUserFunctionsAPI();
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        if (handleError) {
          handleApiErrorAndShowAlert(response);
        }
      } else {
        const toSplit =
          this.tenantConfigs[
            RegistryEnvironment.DISABLE_NEW_DOSSIER_BUTTON_CONTEXT_FUNCTION
          ];
        if (toSplit !== undefined && toSplit !== null) {
          const ctxFnc = (toSplit as string).split("|");
          if (ctxFnc && ctxFnc.length === 2) {
            const context = ctxFnc[0];
            const func = ctxFnc[1];
            this.userFunctions = response.data;
            if (this.userFunctions) {
              const getuserFunctionReadOnly = this.userFunctions.find(
                (x) => x.context_id === context && x.function_name === func,
              );
              this.setIsFunctionReadOnly(!!getuserFunctionReadOnly);
            }
          }
        }
      }
      this.loading = false;
    },
  },
});
