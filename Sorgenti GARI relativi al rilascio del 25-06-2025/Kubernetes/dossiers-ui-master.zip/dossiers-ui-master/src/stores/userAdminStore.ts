import { getUserData } from "@abaco/safe-rest/src/sso2";
import { defineStore } from "pinia";

// const SSO_CONTEXT = "TASKMANAGER";
// const SUPERADMIN_PERMISSION = "ADMIN";
// const USER_PERMISSION = "USER";

export interface GroupAdmin {
  groupCode: string;
  isAdmin: boolean;
}

interface State {
  myUsername: string;
  userExists: boolean;
  isSuperAdmin: boolean;
  groupAdmin: GroupAdmin[];
  groupCodeAdminList: string[];
  isReady: boolean;
}

export const useUserAdminStore = defineStore({
  id: "userAdminStore",
  state: () =>
    ({
      myUsername: "",
      userExists: false,
      isSuperAdmin: false,
      groupAdmin: [],
      groupCodeAdminList: [],
      isReady: false,
    }) as State,
  getters: {
    getIsReady: (state: State) => {
      return state.isReady;
    },
    getMyUsername: (state: State) => {
      return state.myUsername;
    },
    getUserExists: (state: State) => {
      return state.userExists;
    },
    getIsSuperAdmin: (state: State) => {
      return state.isSuperAdmin;
    },
    getIsGroupAdmin: (state: State) => {
      return (code: string) => {
        return !!state.groupCodeAdminList.find((x: string) => x === code);
      };
    },
    getThereIsAtLeastAGroupIAdmin: (state: State) => {
      return state.groupCodeAdminList.length > 0;
    },
    getGroupCodeAdminList: (state: State) => {
      return state.groupCodeAdminList;
    },
  },
  actions: {
    setMockMyUsername(val: string) {
      this.myUsername = val;
    },
    setMockIsSuperAdmin(val: boolean) {
      this.isSuperAdmin = val;
    },
    setMockIsGroupAdmin(code: string) {
      this.groupCodeAdminList = [];
      if (code !== "") {
        this.groupCodeAdminList.push(code);
      }
    },
    async fetchMyUsername() {
      this.myUsername = getUserData()?.username || "";
    },
    setReady(val = true) {
      this.isReady = val;
    },
  },
});
