import {
  CreateDossierResponseSchema,
  DossierAnomalyResponseSchema,
  DossierDetailsSchema,
  DossierHistorySchema,
  DossierIsInTransitionModelSchema,
  DossierListModelSchema,
  DossierTransitionsSchema,
  DossierTypesSchema,
  DossiersResponseSchema,
  GeneratedPrintSchema,
  PartyListModelSchema,
  PartyModelSchema,
  PartyRegistryDetailsSchema,
  PartyRegistryListSchema,
  PrintHistoryResponseSchema,
  TenantConfigListSchema,
  type CreateDossierModel,
  type CreateDossierResponseModel,
  type DossierAnomalyResponseModel,
  type DossierDetailsModel,
  type DossierHistoryModel,
  type DossierIsInTransitionModel,
  type DossierListModel,
  type DossierModulesResponse,
  type DossierTransitionsModel,
  type DossierTypesModel,
  type GeneratedPrintModel,
  type PartyListModel,
  type PartyModel,
  type PartyRegistryDetailsModel,
  type PartyRegistryListModel,
  type PrintHistoryResponseModel,
  type TenantConfigListModel,
} from "@/models/dossier";
import { removeNullsOrBlanksFromObject } from "@/models/utils";
import {
  ErrorType,
  type HttpJsonResult,
  type HttpResult,
  type RequestConfig,
} from "@abaco/safe-rest/src/HTTPClient";

import { getUserData } from "@abaco/safe-rest/src/sso2";
// import type { AnyMxRecord } from "dns";
import { RegistryEnvironment } from "@/stores/dossierStore";
import { z } from "zod";
import { http } from "./http";
import { UserFunctionArraySchema, type UserFunctionArrayModel } from "./login";

// eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unused-vars
function standardMockResponse(data: any): HttpJsonResult<any> {
  return {
    response: {
      ok: true,
      redirected: false,
      status: 200,
      statusText: "OK",
      type: "default",
      url: "",
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      headers: null as any,
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      clone: null as any,
      body: null,
      bodyUsed: false,
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      arrayBuffer: null as any,
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      blob: null as any,
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      formData: null as any,
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      json: null as any,
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      text: null as any,
    },
    data: data,
    errorType: ErrorType.NONE,
  };
}

const defaultHeader = {
  headers: {
    "Content-Type": "application/json",
  },
};

export const loadDossierTypes = async (): Promise<
  HttpJsonResult<DossierTypesModel>
> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    DossierTypesSchema,
    `/dossiers/${user.tenant}/api-priv/v1/all-modules`,
  );
};

export const getDossierList = async (
  partyId: number,
  filters: { dossierType?: string; includeClosedDossier?: boolean },
  nextKey?: string | null,
): Promise<HttpJsonResult<DossierListModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }
  // TODO use filters
  const requestConfig: RequestConfig = {};
  requestConfig.params = {
    nextKey: nextKey,
    type: filters.dossierType,
    includeClosed: filters.includeClosedDossier,
  };
  removeNullsOrBlanksFromObject(requestConfig.params);

  return http.getJson(
    DossierListModelSchema,
    `/dossiers/${user.tenant}/api-priv/v1/dossiers/parties/${partyId}`,
    requestConfig,
  );
};

export const getParties = async (
  registryEnvironment: string,
  url: string,
  cuaa?: string | null,
  partyDesc?: string | null,
  nextKey?: string | null,
): Promise<HttpJsonResult<PartyListModel | PartyRegistryListModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  const requestConfig: RequestConfig = {};

  requestConfig.params =
    registryEnvironment === RegistryEnvironment.LEGACY
      ? {
          search_code: cuaa && cuaa.replace(/-/g, ""),
          search_description: partyDesc,
          next_key: nextKey,
        }
      : {
          code: cuaa && cuaa.replace(/-/g, ""),
          fullName: partyDesc,
          nextKey,
          hasCode: true,
        };

  removeNullsOrBlanksFromObject(requestConfig.params);

  return http.getJson(
    z.union([PartyListModelSchema, PartyRegistryListSchema]),
    url.replace("{tenant}", user.tenant),
    requestConfig,
  );
};

export const getParty = async (
  partyId: number,
  url: string,
): Promise<HttpJsonResult<PartyModel | PartyRegistryDetailsModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    z.union([PartyModelSchema, PartyRegistryDetailsSchema]),
    url
      .replace("{tenant}", user.tenant)
      .replace("{partyId}", partyId.toString()),
  );
};

export const getDossierModules = async (
  point_in_time?: string,
  nextKey?: string,
): Promise<HttpJsonResult<DossierModulesResponse>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  const requestConfig: RequestConfig = {};
  requestConfig.params = {
    point_in_time: point_in_time,
    nextKey: nextKey,
  };
  removeNullsOrBlanksFromObject(requestConfig.params);

  return http.getJson(
    DossiersResponseSchema,
    `/dossiers/${user.tenant}/api-priv/v1/modules`,
    requestConfig,
  );
};

export const createDossier = async (
  newDossier: CreateDossierModel,
): Promise<HttpJsonResult<CreateDossierResponseModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.postJson(
    CreateDossierResponseSchema,
    `/dossiers/${user.tenant}/api-priv/v1/dossiers-async`,
    newDossier,
  );
};

export const getDossierDetails = async (
  dossierId: number,
): Promise<HttpJsonResult<DossierDetailsModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    DossierDetailsSchema,
    `/dossiers/${user.tenant}/api-priv/v1/dossiers/${dossierId}`,
  );
};

export const getDossierAnomalies = async (
  dossierId: number,
): Promise<HttpJsonResult<DossierAnomalyResponseModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    DossierAnomalyResponseSchema,
    `/dossiers/${user.tenant}/api-priv/v1/dossiers/${dossierId}/anomalies`,
  );
};

export const getDossierHistory = async (
  dossierId: number,
): Promise<HttpJsonResult<DossierHistoryModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    DossierHistorySchema,
    `/dossiers/${user.tenant}/api-priv/v1/dossiers/${dossierId}/history`,
  );
};

export const getDossierPrintHistory = async (
  dossierId: number,
): Promise<HttpJsonResult<PrintHistoryResponseModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    PrintHistoryResponseSchema,
    `/dossiers/${user.tenant}/api-priv/v1/dossiers/${dossierId}/print-history`,
  );
};

export const getOngoingPrints = async (
  dossierId: number,
): Promise<HttpJsonResult<PrintHistoryResponseModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    PrintHistoryResponseSchema,
    `/dossiers/${user.tenant}/api-priv/v1/dossiers/${dossierId}/on-going-prints`,
  );
};

export const downloadPrint = async (
  dossierId: number,
  fileId: string,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
): Promise<any> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }
  return http.get(
    `/dossiers/${user.tenant}/api-priv/v1/dossiers/${dossierId}/prints/${fileId}`,
  );
};

export const generatePrint = async (
  dossierId: number,
  printCode: string,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
): Promise<HttpJsonResult<GeneratedPrintModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }
  return http.postJson(
    GeneratedPrintSchema,
    `/dossiers/${user.tenant}/api-priv/v1/dossiers/${dossierId}/prints/${printCode}`,
  );
};

export const getDossierTransitions = async (
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  dossierId: number,
): Promise<HttpJsonResult<DossierTransitionsModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    DossierTransitionsSchema,
    `/dossiers/${user.tenant}/api-priv/v1/dossiers/${dossierId}/transitions`,
  );
};

export const getIsInTransition = async (
  dossierId: number,
): Promise<HttpJsonResult<DossierIsInTransitionModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }
  return http.getJson(
    DossierIsInTransitionModelSchema,
    `/dossiers/${user.tenant}/api-priv/v1/dossiers/${dossierId}/is-in-transition`,
  );
};

export const updateDossierStatus = async (
  dossierId: number,
  transition_id: string,
  notes?: string,
): Promise<HttpResult> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }
  return http.patch(
    `/dossiers/${user.tenant}/api-priv/v1/dossiers/${dossierId}/progress/${transition_id}`,
    JSON.stringify({ notes }),
    defaultHeader,
  );
};

export const loadTenantConfigsAPI = async (): Promise<
  HttpJsonResult<TenantConfigListModel>
> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }
  return http.getJson(
    TenantConfigListSchema,
    `/dossiers/${user.tenant}/api-priv/v1/dossiers/environments`,
  );
};

export const loadUserFunctionsAPI = async (): Promise<
  HttpJsonResult<UserFunctionArrayModel>
> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }
  return http.getJson(
    UserFunctionArraySchema,
    `/sso2/${user.tenant}/public/v1/user-functions`,
  );
};
