import { z } from "zod";

export const PartyModelSchema = z
  .object({
    partyId: z.number(),
    code: z.string(),
    description: z.nullable(z.string()),
  })
  .passthrough();

const MunicipalityDetailsSchema = z.object({
  code: z.string(),
  tenantId: z.string(),
  districtCode: z.string(),
  shortDescr: z.string(),
  active: z.boolean(),
  i18nName: z.string(),
  district: z.object({
    code: z.string(),
    tenantId: z.string(),
    regionCode: z.string(),
    shortDescr: z.string(),
    active: z.boolean(),
    i18nName: z.string(),
    region: z.object({
      code: z.string(),
      tenantId: z.string(),
      countryCode: z.string(),
      shortDescr: z.string(),
      active: z.boolean(),
      i18nName: z.string(),
      country: z.object({
        code: z.string(),
        tenantId: z.string(),
        active: z.boolean(),
        i18nName: z.string(),
      }),
    }),
  }),
});

const AddressResidentialSchema = z.object({
  id: z.number(),
  municipality: z.string().nullable(),
  locality: z.string().nullable(),
  street: z.string().nullable(),
  houseNumber: z.string().nullable(),
  postcode: z.string().nullable(),
  details: z.string().nullable(),
  note: z.string().nullable(),
  municipalityI18nCode: z.string().nullable(),
  municipalityDetail: MunicipalityDetailsSchema.nullable(),
});

export const PartyRegistrySchema = z.object({
  id: z.number(),
  partyType: z.string().nullable(),
  lastName: z.string().nullable(),
  firstName: z.string().nullable(),
  taxCode: z.string().nullable(),
  vatNumber: z.string().nullable(),
  code: z.string().nullable(),
  birthDate: z.string().nullable(),
  deathDate: z.string().nullable(),
  birthMunicipality: z.string().nullable(),
  birthMunicipalityDetail: MunicipalityDetailsSchema.nullable(),
  nationality: z.string().nullable(),
  addressResidential: AddressResidentialSchema.nullable(),
  archived: z.boolean().nullable(),
});

export const PartyListModelSchema = z.object({
  count: z.number(),
  records: z.array(PartyModelSchema),
  nextKey: z.nullable(z.string()),
});

export const PartyRegistryListSchema = z.object({
  count: z.number(),
  records: z.array(PartyRegistrySchema),
  nextKey: z.nullable(z.string()),
});

export const tagSchema = z.object({
  id: z.number(),
  code: z.string(),
  i18nCode: z.string(),
});

export const PartyRegistryDetailsSchema = z.object({
  id: z.number(),
  partyType: z.string(),
  gender: z.string().nullable(),
  lastName: z.string(),
  firstName: z.string().nullable(),
  taxCode: z.string().nullable(),
  vatNumber: z.string().nullable(),
  code: z.string().nullable(),
  birthDate: z.string().nullable(),
  deathDate: z.string().nullable(),
  birthMunicipality: z.string().nullable(),
  birthMunicipalityDetail: MunicipalityDetailsSchema.nullable(),
  nationality: z.string().nullable(),
  addressResidential: AddressResidentialSchema.nullable(),
  addressHome: AddressResidentialSchema.nullable(),
  addressBilling: AddressResidentialSchema.nullable(),
  tags: z.array(tagSchema),
  archived: z.boolean(),
});

export const DossierSchema = z.object({
  dossierCode: z.nullable(z.string()),
  dossierDescription: z.nullable(z.string()),
});

export const DossierTypeSchema = z.object({
  moduleCode: z.string(),
  moduleShortDescription: z.string(),
  sectorCode: z.string(),
  sectorShortDescription: z.string(),
  year: z.number(),
  flAmendModule: z.number(),
});

export const DossierTypesSchema = z.array(DossierTypeSchema);

export const DossiersResponseSchema = z.object({
  records: DossierTypesSchema,
  nextKey: z.nullable(z.string()),
  count: z.number(),
});

export const DossierModelSchema = z
  .object({
    partyId: z.number(),
    moduleCode: z.string(),
    moduleDescription: z.string(),
    dossierId: z.number(),
    dossierCode: z.string(),
    processStatus: z.string().nullable(),
    processStatusDescription: z.string().nullable(),
    dtClosed: z.string().nullable(),
  })
  .passthrough();

export const DossierListModelSchema = z.object({
  count: z.number(),
  records: z.array(DossierModelSchema),
  nextKey: z.nullable(z.string()),
});

export const CreateDossierModelSchema = z
  .object({
    partyId: z.number(),
    moduleCode: z.string(),
    sectorCode: z.string(),
    year: z.number(),
  })
  .passthrough();

export const CreateDossierResponseSchema = z
  .object({
    dossierId: z.nullable(z.number()),
    dossierCode: z.nullable(z.string()),
    anomalies: z.array(
      z.object({
        code: z.string(),
        message: z.string(),
      }),
    ),
  })
  .passthrough();

export const FormDetailsSchema = z
  .object({
    formConfigId: z.number(),
    formCode: z.string(),
    formName: z.string().nullable(),
    softwareUrl: z.string(),
    routerUrl: z.string().nullable(),
    flReadOnly: z.number(),
    sortOrder: z.number(),
    compileStatusIdentifier: z.string().nullable(),
    compileStatus: z.string().nullable(),
    params: z.record(z.string(), z.string()),
  })
  .passthrough();

export const GroupSchema = z
  .object({
    groupCode: z.string(),
    groupName: z.string().nullable(),
  })
  .passthrough();

export const FormSchema = z
  .object({
    groups: z.array(GroupSchema),
    formDetails: FormDetailsSchema,
  })
  .passthrough();

export const CompileStatusSchema = z
  .object({
    compileStatusIdentifier: z.string(),
    status: z.string(),
    statusDescription: z.string().nullable(),
  })
  .passthrough();

export const ProfileSchema = z
  .object({
    profileCode: z.string(),
    profileCodeDescription: z.string().nullable(),
  })
  .passthrough();

export const PrintSchema = z.object({
  printCode: z.string(),
  printDescription: z.string(),
  sortOrder: z.number(),
  params: z.record(z.string(), z.string()),
  lastPrint: z.nullable(
    z.object({
      printDate: z.number().or(z.string()),
      fileId: z.string(),
    }),
  ),
});

export const DossierDetailsSchema = z
  .object({
    dossierId: z.number(),
    partyId: z.number(),
    referredYear: z.number().nullable(),
    processId: z.number(),
    dtInsert: z.string(),
    dossierCode: z.string(),
    processStatus: z.string(),
    processStatusDescription: z.string().nullable(),
    dtClosed: z.string().nullable(),
    moduleDescription: z.string(),
    forms: z.array(FormSchema),
    prints: z.nullable(z.array(PrintSchema)),
    profileList: z.array(ProfileSchema),
    lastMovement: z.nullable(z.string()),
    dtLastMovement: z.string(),
    dtPresentation: z.nullable(z.string()),
    /* partyId: z.number(),
    referredYear: z.number().nullable(),
    processId: z.number(),
    dtInsert: z.string(),
    dossierCode: z.string(),
    dossierId: z.number(),
    dossierTipology: z.string(),
    dtIncorporation: z.string(),
    dtLastValidation: z.string(),
    dtClosing: z.string(),
    lastMovement: z.nullable(z.string()),
    processStatus: z.string(),
    processStatusDescription: z.string().nullable(),
    forms: z.array(FormSchema),
    prints: z.nullable(z.array(PrintSchema)),
    profileList: z.array(ProfileSchema),
    isClosed: z.nullable(z.boolean()), */
  })
  .passthrough();

export enum MessageType {
  ERROR = "ERROR",
  WARNING = "WARNING",
  INFO = "INFO",
}

export const ErrorMessageSchema = z.object({
  code: z.string(),
  description: z.string(),
  type: z.nativeEnum(MessageType),
});
export type ErrorMessageModel = z.infer<typeof ErrorMessageSchema>;

export const ErrorMessageListSchema = ErrorMessageSchema.array();
export type ErrorMessageListModel = z.infer<typeof ErrorMessageListSchema>;

export const DossierHistorySchema = z.array(
  z
    .object({
      id: z.number(),
      startDate: z.number().or(z.string()),
      endDate: z.number().or(z.string()),
      userId: z.string(),
      processId: z.number(),
      transitionId: z.number(),
      notes: z.string().nullable(),
      failed: z.boolean(),
      description: z.string(),
      fromNode: z.string(),
      fromNodeDescription: z.string().nullable(),
      toNode: z.string(),
      toNodeDescription: z.string().nullable(),
      messages: ErrorMessageListSchema,
    })
    .passthrough(),
);

export const DossierTransitionSchema = z
  .object({
    id: z.number(),
    fromNode: z.string(),
    toNode: z.string(),
    description: z.string(),
    scope: z.null(),
    tags: z.array(z.string()),
    notesRequired: z.boolean(),
  })
  .passthrough();

export const DossierTransitionsSchema = z.array(DossierTransitionSchema);

export const DossierIsInTransitionModelSchema = z.object({
  inTransition: z.boolean(),
  lastTransitionLog: z.nullable(
    z
      .object({
        id: z.number(),
        startDate: z.string().or(z.number()),
        endDate: z.string().or(z.number()),
        userId: z.string(),
        processId: z.number(),
        transitionId: z.number(),
        notes: z.nullable(z.string()),
        failed: z.boolean(),
        description: z.string(),
        fromNode: z.string(),
        fromNodeDescription: z.nullable(z.string()),
        toNode: z.string(),
        toNodeDescription: z.nullable(z.string()),
        messages: ErrorMessageListSchema,
      })
      .passthrough(),
  ),
});

export const GeneratedPrintSchema = z.object({
  processStatus: z.string(),
  printCode: z.string(),
  printDescription: z.nullable(z.string()),
  printDate: z.number().or(z.string()),
  printJobUuid: z.nullable(z.string()),
  fileId: z.nullable(z.string()),
  username: z.string(),
  printStatus: z.nullable(z.string()),
});

export const PrintHistoryResponseSchema = z.array(GeneratedPrintSchema);

export const DossierAnomalySchema = z.object({
  pkid: z.number(),
  anomalyCode: z.string(),
  anomalyDesc: z.string(),
  severity: z.string(),
  dtInsert: z.string().or(z.number()),
});

export const DossierAnomalyResponseSchema = z.array(DossierAnomalySchema);

export const TenantConfigSchema = z.object({
  key: z.string(),
  value: z.union([z.string(), z.boolean(), z.number()]),
});

export interface DossierFilter {
  dossierType: string;
  dossierTypeDescription: string;
  includeClosedDossier: boolean;
}

export const TenantConfigListSchema = z.array(TenantConfigSchema);
export interface SubjectFilter {
  cuaa: string;
  denomination: string;
}

export type DossierTypeModel = z.infer<typeof DossierTypeSchema>;
export type DossierTypesModel = z.infer<typeof DossierTypesSchema>;
export type DossierListModel = z.infer<typeof DossierListModelSchema>;
export type DossierModulesResponse = z.infer<typeof DossiersResponseSchema>;
export type DossierModuleModel = z.infer<typeof DossierSchema>;
export type DossierModel = z.infer<typeof DossierModelSchema>;
export type PartyModel = z.infer<typeof PartyModelSchema>;
export type PartyListModel = z.infer<typeof PartyListModelSchema>;
export type PartyRegistryModel = z.infer<typeof PartyRegistrySchema>;
export type PartyRegistryListModel = z.infer<typeof PartyRegistryListSchema>;
export type PartyRegistryDetailsModel = z.infer<
  typeof PartyRegistryDetailsSchema
>;
export type CreateDossierModel = z.infer<typeof CreateDossierModelSchema>;
export type CreateDossierResponseModel = z.infer<
  typeof CreateDossierResponseSchema
>;
export type FormModel = z.infer<typeof FormSchema>;
export type DossierDetailsModel = z.infer<typeof DossierDetailsSchema>;

export type FormGroupModel = z.infer<typeof GroupSchema>;
export type FormDetailsModel = z.infer<typeof FormDetailsSchema>;
export type DossierHistoryItemModel = z.infer<
  typeof DossierHistorySchema.element
>;
export type DossierHistoryModel = z.infer<typeof DossierHistorySchema>;
export type DossierTransitionModel = z.infer<typeof DossierTransitionSchema>;
export type DossierTransitionsModel = z.infer<typeof DossierTransitionsSchema>;
export type DossierIsInTransitionModel = z.infer<
  typeof DossierIsInTransitionModelSchema
>;
export type PrintModel = z.infer<typeof PrintSchema>;
export type GeneratedPrintModel = z.infer<typeof GeneratedPrintSchema>;
export type PrintHistoryResponseModel = z.infer<
  typeof PrintHistoryResponseSchema
>;
export type DossierAnomalyModel = z.infer<typeof DossierAnomalySchema>;
export type DossierAnomalyResponseModel = z.infer<
  typeof DossierAnomalyResponseSchema
>;
export type TenantConfigModel = z.infer<typeof TenantConfigSchema>;
export type TenantConfigListModel = z.infer<typeof TenantConfigListSchema>;
/**
 * Types needed to represent forms with a tree structure
 */
export enum CardState {
  IN_PROGRESS = "IN_PROGRESS",
  COMPLETED = "COMPLETED",
  TO_BE_COMPILED = "TO_BE_COMPILED",
}

export interface CardNode {
  id: string;
  name: string;
  children?: CardNode[];
  formConfigId?: number;
  softwareUrl?: string;
  routerUrl?: string;
  compileStatus?: CardState;
  compileStatusIdentifier?: string;
  formCode?: string;
  sortOrder?: number;
  flReadOnly?: number;
  params?: Record<string, string>;
  isOpen?: boolean;
  partyId?: number;
  partyCode?: string;
}

export interface Anomalies {
  code: string;
  message: string;
}
export type PickedSelectedCard = Pick<
  CardNode,
  | "id"
  | "formConfigId"
  | "softwareUrl"
  | "routerUrl"
  | "params"
  | "flReadOnly"
  | "compileStatus"
  | "compileStatusIdentifier"
  | "formCode"
  | "partyId"
  | "partyCode"
>;
export type SelectedCard = PickedSelectedCard & {
  clicked?: boolean;
};

export function fromFormDetailsModelToSelectedCard(
  formDetail: FormDetailsModel,
  partyId: number,
  partyCode: string,
): SelectedCard {
  return {
    id: formDetail.formCode,
    name: formDetail.formName ? formDetail.formName : "",
    softwareUrl: formDetail.softwareUrl,
    routerUrl: formDetail.routerUrl ? formDetail.routerUrl : undefined,
    params: formDetail.params,
    flReadOnly: formDetail.flReadOnly,
    compileStatusIdentifier: formDetail.compileStatusIdentifier,
    formConfigId: formDetail.formConfigId,
    formCode: formDetail.formCode,
    compileStatus: formDetail.compileStatus
      ? (formDetail.compileStatus as CardState)
      : undefined,
    partyId: partyId,
    partyCode: partyCode,
  } as SelectedCard;
}
