<!-- eslint-disable @typescript-eslint/no-unused-vars -->
<script setup lang="ts">
// Vue
import { computed, inject, ref } from "vue";
import { useI18n } from "vue-i18n";
//Boootstrap Italia components
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
// Store
import { useDossierStore } from "@/stores/dossierStore";
import { useRoute, useRouter } from "vue-router";
// utils
import BiChip from "@abaco/bootstrap-italia-components/src/components/BiChip/BiChip.vue";

const router = useRouter();
const route = useRoute();
const moduleId = inject("moduleId");
const dossierStore = useDossierStore();
const { getColor } = useColors();
const { t } = useI18n({});

const dossierList = computed(() => dossierStore.getDossierList);

const filtersVisible = ref({
  dossierType: true,
  includeClosedDossier: true,
});

const props = defineProps<{
  partyId: number;
  dossierType?: string;
  dossierTypeDescription?: string;
  includeClosedDossier?: boolean;
}>();

async function fetchData(loadMore?: boolean) {
  dossierStore.loadDossierList(
    props.partyId,
    {
      dossierType: filtersVisible.value.dossierType
        ? props.dossierType
        : undefined,
      includeClosedDossier: filtersVisible.value.includeClosedDossier
        ? props.includeClosedDossier
        : undefined,
    },
    loadMore ? dossierList.value?.nextKey : undefined,
  );
}

async function goToDetailPage(dossierCode: number | null) {
  router.push({
    name: "dossierDetail",
    params: { dossierId: dossierCode ?? 0 },
    query: route.query,
  });
}
</script>

<template>
  <div class="container my-5">
    <div
      v-if="dossierStore.loading"
      class="d-flex row justify-content-center mb-3"
    >
      <div class="d-flex col-2 justify-content-center px-0">
        <BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
      </div>
    </div>
    <div v-else>
      <div class="px-4 pt-3" @click.stop="">
        <div class="pb-2">
          <BiChip
            :label="
              t(`${moduleId}.list.chip.nameOrCompanyName`, {
                placeholder: dossierStore.getSelectedSubject?.description ?? '',
              })
            "
            class="px-3"
          />
          <BiChip
            v-if="props.dossierType"
            :label="
              t(`${moduleId}.list.chip.dossierType`, {
                placeholder: props.dossierTypeDescription,
              })
            "
            class="px-3"
            :svgIcon="filtersVisible.dossierType ? 'eye' : 'eye-slash'"
            :style="
              filtersVisible.dossierType
                ? 'text-decoration: none'
                : 'text-decoration: line-through'
            "
            iconSize="sm"
            role="button"
            @click="
              async () => {
                filtersVisible.dossierType = !filtersVisible.dossierType;
                await fetchData();
              }
            "
          />
          <BiChip
            v-if="props.includeClosedDossier"
            :label="
              t(`${moduleId}.list.chip.includeClosedDossiers`, {
                placeholder: props.includeClosedDossier
                  ? t(`${moduleId}.general.yes`)
                  : t(`${moduleId}.general.no`),
              })
            "
            class="px-3"
            :svgIcon="filtersVisible.includeClosedDossier ? 'eye' : 'eye-slash'"
            :style="
              filtersVisible.includeClosedDossier
                ? 'text-decoration: none'
                : 'text-decoration: line-through'
            "
            iconSize="sm"
            role="button"
            @click="
              async () => {
                filtersVisible.includeClosedDossier =
                  !filtersVisible.includeClosedDossier;
                await fetchData();
              }
            "
          />
        </div>
        <BiTable
          :isRowHover="true"
          class="table-hover table-responsive"
          extraTableClasses="table-head-bg mb-0"
          @click.stop
        >
          <template v-slot:head>
            <tr class="bg-light" :class="getColor('text', 'secondary')">
              <th scope="col">
                {{ t(`${moduleId}.list.table.dossierType`) }}
              </th>
              <th scope="col">
                {{ t(`${moduleId}.list.table.dossierStatus`) }}
              </th>
              <th scope="col"></th>
            </tr>
          </template>
          <template v-slot:body v-if="dossierList && dossierList.count > 0">
            <tr
              class="align-middle"
              v-for="(item, i) in dossierList?.records ?? []"
              :key="i"
            >
              <td :data-label="t(`${moduleId}.list.table.dossierType`)">
                {{ item.moduleDescription }}
              </td>
              <td :data-label="t(`${moduleId}.list.table.dossierStatus`)">
                <!-- {{
                item.processStatusDescription
                  ? item.processStatusDescription
                  : item.processStatus
                  ? item.processStatus
                  : ""
              }} -->
                {{ item.processStatusDescription ?? item.processStatus ?? "" }}
              </td>
              <td
                class="actions"
                :data-label="t(`${moduleId}.list.table.open`)"
              >
                <div class="d-flex justify-content-end">
                  <BiButton
                    @click.stop="
                      () => {
                        goToDetailPage(item.dossierId ?? null);
                      }
                    "
                    :width="48"
                    class="me-2"
                    :isIcon="true"
                  >
                    <BiIcon
                      icon="arrow-right"
                      size="xl"
                      :class="`${getColor('text', 'success')}`"
                    />
                  </BiButton>
                </div>
              </td>
            </tr>
          </template>
          <template v-slot:body v-else>
            <tr class="align-middle">
              <td colspan="3">
                {{ t(`${moduleId}.general.noData`) }}
              </td>
            </tr>
          </template>
        </BiTable>
      </div>
      <div class="w-100 text-center mb-3" @click.stop>
        <BiButton
          v-if="
            dossierList && dossierList.nextKey !== null && !dossierStore.loading
          "
          @click="
            async () => {
              await fetchData(true);
            }
          "
          color="primary"
          is-outlined
        >
          {{ t(`${moduleId}.list.loadMore`) }}
        </BiButton>
      </div>
    </div>
  </div>
</template>
