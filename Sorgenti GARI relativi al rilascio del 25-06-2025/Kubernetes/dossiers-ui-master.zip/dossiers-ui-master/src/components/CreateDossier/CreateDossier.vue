<script setup lang="ts">
import type { CreateDossierModel, DossierTypeModel } from "@/models/dossier";
import { useDossierStore } from "@/stores/dossierStore";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { computed, inject, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";
import RegistryDossierInfo from "../DossierDetails/RegistryDossierInfo.vue";
import DossierServiceModal from "../DossierServiceModal.vue";

const moduleId = inject("moduleId");
const dossierStore = useDossierStore();
const { t } = useI18n({});
const router = useRouter();
const route = useRoute();
const isServiceModalVisible = ref<boolean>(false);
const isCreationModalVisible = ref<boolean>(false);
const selectedModule = ref<DossierTypeModel>();
const selectedSubject = computed(() => dossierStore.getSelectedSubject);
const createDossierResponse = computed(
  () => dossierStore.getCreateDossierResponse,
);

const dossierModules = computed(() => dossierStore.getDossierModules);

async function loadMore() {
  if (!dossierModules.value?.nextKey) return;
  await dossierStore.loadDossierModules(
    undefined,
    dossierModules.value?.nextKey,
  );
}

function onOpenCreationModal(module: DossierTypeModel) {
  selectedModule.value = module;
  isCreationModalVisible.value = true;
}

async function createDossier() {
  if (!selectedSubject.value || !selectedModule.value) return;

  const newDossier: CreateDossierModel = {
    partyId: selectedSubject.value.partyId,
    moduleCode: selectedModule.value.moduleCode,
    sectorCode: selectedModule.value.sectorCode,
    year: selectedModule.value.year,
  };
  dossierStore.setTransitionStatus(t(`${moduleId}.serviceModal.creation`));
  await dossierStore.createDossier(newDossier);

  isCreationModalVisible.value = false;
  isServiceModalVisible.value = true;
}

function onCloseServiceModal(redirect?: boolean) {
  isServiceModalVisible.value = false;
  if (redirect && createDossierResponse.value) {
    router.push({
      name: "dossierDetail",
      params: {
        dossierId: createDossierResponse.value.dossierCode,
      },
      query: route.query,
    });
  }
}
</script>
<style scoped>
.w-fit {
  width: fit-content;
}
</style>
<template>
  <BiTable
    isRowHover
    class="table-hover mb-0 table-responsive"
    extraTableClasses="table-head-bg"
    isResponsive
  >
    <template v-slot:head>
      <tr class="bg-light text-secondary">
        <th scope="col">
          {{ t(`${moduleId}.createDossier.dossierSector`) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.createDossier.dossierTipology`) }}
        </th>
        <th scope="col"></th>
      </tr>
    </template>
    <template v-slot:body>
      <tr v-for="(module, i) in dossierModules?.records" :key="i">
        <td :data-label="t(`${moduleId}.createDossier.dossierTipology`)">
          {{ module.sectorShortDescription }}
        </td>
        <td :data-label="t(`${moduleId}.createDossier.dossierTipology`)">
          {{ module.moduleShortDescription }}
        </td>
        <td
          class="actions"
          :data-label="t(`${moduleId}.createDossier.createDossier`)"
        >
          <div class="d-flex justify-content-end">
            <BiButton
              @click.stop="onOpenCreationModal(module)"
              color="success"
              class="me-2"
              :isIcon="true"
            >
              {{ t(`${moduleId}.createDossier.createDossier`) }}
            </BiButton>
          </div>
        </td>
      </tr>
    </template>
  </BiTable>
  <div class="w-100 text-center" @click.stop>
    <BiButton
      v-if="dossierModules?.nextKey"
      @click="loadMore()"
      color="primary"
      is-outlined
    >
      {{ t(`${moduleId}.list.loadMore`) }}
    </BiButton>
  </div>
  <BiModal
    :disabled-teleport="true"
    :extra-footer-class="'justify-content-center'"
    v-model="isCreationModalVisible"
    :aria-labelledby="t(`${moduleId}.searchForm.createDossier`)"
    :title="t(`${moduleId}.searchForm.createDossier`)"
    :prevent-dismiss="true"
    :size="'lg'"
  >
    <template #body>
      <div class="text-secondary mb-3">
        <strong> {{ t(`${moduleId}.serviceModal.newDossierInfo`) }}: </strong>
      </div>
      <RegistryDossierInfo
        :cuaa="selectedSubject?.code"
        :name="selectedSubject?.description"
        :dossierDescription="selectedModule?.moduleShortDescription"
      />
    </template>
    <template #footer>
      <div class="mt-3 mb-5 d-flex justify-content-center">
        <BiButton
          class="mx-2 w-fit"
          color="secondary"
          is-outlined
          @click.stop="isCreationModalVisible = false"
        >
          {{ t(`${moduleId}.general.cancel`) }}
        </BiButton>
        <BiButton
          class="mx-2 w-fit"
          color="success"
          @click.stop="createDossier()"
          >{{ t(`${moduleId}.general.confirm`) }}</BiButton
        >
      </div>
    </template>
  </BiModal>
  <DossierServiceModal
    :open-modal="isServiceModalVisible"
    :party="selectedSubject"
    :module="selectedModule as DossierTypeModel"
    :is-create-dossier="true"
    @close="onCloseServiceModal"
    :translation-module="'createDossierModal'"
    :dossier-id="createDossierResponse?.dossierId"
  ></DossierServiceModal>
</template>
