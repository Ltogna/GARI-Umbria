<script setup lang="ts">
import type { CardNode, CardState, SelectedCard } from "@/models/dossier";
import { useDossierStore } from "@/stores/dossierStore";
import { matchForm } from "@/utils/formUtils";
import { computed } from "vue";
import { useRoute } from "vue-router";
import CardStateIcon from "./CardStateIcon.vue";

const emit = defineEmits(["openCard"]);

const dossierStore = useDossierStore();
const inTransition = computed(() => dossierStore.getIsInTransition);

const props = defineProps<{
  node: CardNode;
  selectedCardId: string | null;
}>();

const route = useRoute();

const applyUnderline = computed(() => {
  const purgedQuery = Object.fromEntries(
    Object.entries(route.query).filter(
      ([key]) =>
        ![
          "formConfigId",
          "readOnly",
          "partyId",
          "compileStatusIdentifier",
          "partyCode",
          "formCode",
        ].includes(key),
    ),
  );

  const found =
    matchForm(route.fullPath, props.node.routerUrl ?? "") &&
    route.query.formCode === props.node.formCode &&
    JSON.stringify(purgedQuery ?? {}) ===
      JSON.stringify(props.node.params ?? {});
  if (found) {
    console.log(found);
  }
  return !!found;
});

function selectCard(node: CardNode, isClicked = false) {
  const selectedCardInfo: SelectedCard = {
    id: node.id,
    softwareUrl: node.softwareUrl,
    routerUrl: node.routerUrl,
    params: node.params,
    flReadOnly: inTransition.value ? 0 : node.flReadOnly,
    compileStatusIdentifier: node.compileStatusIdentifier,
    compileStatus: node.compileStatus,
    formConfigId: node.formConfigId,
    formCode: node.formCode,
    partyId: node.partyId,
    partyCode: node.partyCode,
    clicked: isClicked,
  };
  emit("openCard", selectedCardInfo);
}
</script>
<style scoped>
.second-level-card {
  font-weight: 600;
}
.cursor-pointer {
  cursor: pointer;
}
.underline-hover:hover {
  text-decoration: underline;
}
</style>

<template>
  <div
    class="second-level-card cursor-pointer pt-2 pb-2 d-flex justify-content-between"
    @click="selectCard(node, true)"
  >
    <div
      class="underline-hover"
      :class="
        selectedCardId !== null && applyUnderline
          ? 'text-decoration-underline'
          : ''
      "
    >
      {{ node.name }}
    </div>
    <div v-if="node.compileStatus" class="pe-2">
      <CardStateIcon :stateType="node.compileStatus as CardState" />
    </div>
  </div>
</template>
