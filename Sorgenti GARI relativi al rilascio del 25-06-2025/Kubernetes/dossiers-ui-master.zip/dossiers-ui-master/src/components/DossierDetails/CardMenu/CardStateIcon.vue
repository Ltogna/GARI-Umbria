<script setup lang="ts">
import { CardState } from "@/models/dossier";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import type { ColorNamesType } from "@abaco/bootstrap-italia-components/src/models";
import { onMounted, ref } from "vue";

const props = defineProps<{
  stateType: CardState;
}>();

const iconType = ref<string | null>(null);
const colorIcon = ref<ColorNamesType>();

onMounted(() => {
  switch (props.stateType) {
    case CardState.COMPLETED:
      iconType.value = "circle-check";
      colorIcon.value = "success";
      break;
    case CardState.IN_PROGRESS:
      iconType.value = "circle-dashed";
      colorIcon.value = "success";
      break;
    case CardState.TO_BE_COMPILED:
      iconType.value = "pen-circle";
      colorIcon.value = "info";
      break;
  }
});
</script>

<template>
  <BiIcon
    v-if="iconType !== null"
    icon-style="regular"
    :icon="iconType"
    :color="colorIcon"
    size="lg"
  />
</template>
