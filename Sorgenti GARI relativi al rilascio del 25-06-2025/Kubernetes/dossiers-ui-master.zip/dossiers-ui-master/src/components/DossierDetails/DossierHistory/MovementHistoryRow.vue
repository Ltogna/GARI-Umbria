<script setup lang="ts">
import { inject, onMounted, ref, defineProps, toRef } from "vue";
import { useI18n } from "vue-i18n";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import BiCollapse from "@abaco/bootstrap-italia-components/src/components/BiCollapse/BiCollapse.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import { MessageType, type DossierHistoryItemModel } from "@/models/dossier";
import { getFormattedDate } from "@/utils/dateUtils";

const props = defineProps<{
  movement: DossierHistoryItemModel;
}>();

const movement = toRef(props, "movement");

const moduleId = inject("moduleId");
const { getColor } = useColors();
const { t } = useI18n({});
const currentTarget = ref<Record<string, boolean>>({});

onMounted(async () => {
  movement.value.messages = movement.value.messages.sort((a, b) => {
    if (
      (a.type === MessageType.ERROR && b.type === MessageType.ERROR) ||
      (a.type === MessageType.ERROR && b.type !== MessageType.ERROR) ||
      (a.type === MessageType.WARNING && b.type === MessageType.INFO)
    ) {
      return -1;
    } else if (
      (a.type === MessageType.WARNING && b.type === MessageType.ERROR) ||
      (a.type === MessageType.INFO && b.type !== MessageType.INFO)
    ) {
      return 1;
    } else {
      return 0;
    }
  });
});

function toggleRow(id: string) {
  if (currentTarget.value[id]) {
    currentTarget.value[id] = !currentTarget.value[id];
  } else {
    currentTarget.value[id] = true;
  }
}
</script>
<style scoped>
.cursor-pointer {
  cursor: pointer;
}
.w-90 {
  width: 90% !important;
}
.content-center-box {
  justify-content: center;
}

.fa-chevron-down {
  transition: transform 0.3s;
  transform: scale();
}

.fa-chevron-down.open {
  transform: scale(-1);
  transition: transform 0.3s;
}
</style>

<template>
  <tr>
    <td
      class="text-uppercase"
      :data-label="t(`${moduleId}.dossierDetails.movementHistory.movementName`)"
    >
      {{ movement.description }}
    </td>
    <td
      :data-label="
        t(`${moduleId}.dossierDetails.movementHistory.executionDate`)
      "
    >
      {{ getFormattedDate(movement.startDate, true, true) }}
    </td>
    <td
      class="text-uppercase"
      :data-label="t(`${moduleId}.dossierDetails.movementHistory.user`)"
    >
      {{ movement.userId }}
    </td>
    <td
      class="text-uppercase fw-bold"
      :class="
        movement.failed
          ? getColor('text', 'danger')
          : getColor('text', 'success')
      "
      :data-label="
        t(`${moduleId}.dossierDetails.movementHistory.movementOutcome`)
      "
    >
      {{
        movement.failed
          ? t(`${moduleId}.dossierDetails.movementHistory.fail`)
          : t(`${moduleId}.dossierDetails.movementHistory.success`)
      }}
    </td>

    <td>
      <BiCollapse
        v-if="
          movement.messages.length > 0 ||
          (movement.notes && movement.notes !== '')
        "
        color="secondary"
        :tag="BiIcon"
        class="cursor-pointer animated-icon"
        :class="
          currentTarget[`collapseDetail-${movement.id}`] == true
            ? 'fa-chevron-down open'
            : 'fa-chevron-down'
        "
        :targetSelector="`#collapseDetail-${movement.id}`"
        @click="toggleRow(`collapseDetail-${movement.id}`)"
      >
      </BiCollapse>
    </td>
  </tr>
  <tr
    v-if="
      movement.messages.length > 0 || (movement.notes && movement.notes !== '')
    "
    class="p-0 collapse-tr"
    :class="
      currentTarget[`collapseDetail-${movement.id}`] == undefined ||
      currentTarget[`collapseDetail-${movement.id}`] == false
        ? 'border-0'
        : ''
    "
  >
    <td
      colspan="12"
      class="p-0 border-0"
      :class="
        !movement.notes || movement.notes == '' ? 'content-center-box' : ''
      "
    >
      <div
        :id="`collapseDetail-${movement.id}`"
        :class="!movement.notes || movement.notes == '' ? 'w-100' : ''"
      >
        <div class="w-90 ms-auto me-auto mt-3 mb-3">
          <div
            v-if="movement.notes && movement.notes !== ''"
            class="pe-3 pt-2 pb-2"
          >
            <span
              >{{ t(`${moduleId}.dossierDetails.movementHistory.note`) }}:</span
            >
            <div
              class="w-100"
              :id="`note-${movement.id}`"
              :aria-describedby="`note-${movement.id}.`"
            >
              {{ movement.notes }}
            </div>
          </div>
          <div
            v-for="(message, index) in movement.messages"
            :key="index"
            class="ps-3 pe-3 pt-3 pb-3 w-100 ms-auto me-auto"
            :class="index != 0 ? 'border-top ' : ''"
          >
            <BiAlert
              class="w-100"
              :isWarn="message.type == MessageType.WARNING"
              :isError="message.type == MessageType.ERROR"
              :isInfo="message.type == MessageType.INFO"
              ><template #body>
                {{ message.description }}
              </template>
            </BiAlert>
          </div>
        </div>
      </div>
    </td>
  </tr>
</template>
