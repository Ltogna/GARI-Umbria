<script setup lang="ts">
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { useDossierStore } from "@/stores/dossierStore";
import { useRoute } from "vue-router";
import MovementHistoryRow from "./MovementHistoryRow.vue";

const moduleId = inject("moduleId");
const { getColor } = useColors();
const { t } = useI18n({});
const route = useRoute();
const dossierStore = useDossierStore();
const dossierId = ref<number>(parseInt(route.params.dossierId as string));

const dossierHistory = computed(() => dossierStore.getDossierHistory ?? []);

onMounted(async () => {
  await dossierStore.loadDossierHistory(dossierId.value, true);
});
</script>
<template>
  <div class="container">
    <div class="w-100 d-flex mb-3 mt-4">
      <h4 class="fw-bold" :class="getColor('text', 'primary')">
        <BiIcon icon="list" size="lg" />
        {{ t(`${moduleId}.dossierDetails.movementHistory.title`) }}
      </h4>
    </div>
    <BiTable
      class="table-hover table-responsive collapsable-table"
      extraTableClasses="table-head-bg mb-0"
      @click.stop
    >
      <template v-slot:head>
        <tr class="bg-light" :class="getColor('text', 'secondary')">
          <th scope="col">
            {{ t(`${moduleId}.dossierDetails.movementHistory.movementName`) }}
          </th>
          <th scope="col">
            {{ t(`${moduleId}.dossierDetails.movementHistory.executionDate`) }}
          </th>
          <th scope="col">
            {{ t(`${moduleId}.dossierDetails.movementHistory.user`) }}
          </th>
          <th scope="col">
            {{
              t(`${moduleId}.dossierDetails.movementHistory.movementOutcome`)
            }}
          </th>
          <th scope="col"></th>
        </tr>
      </template>
      <template v-slot:body>
        <MovementHistoryRow
          v-for="movement in dossierHistory"
          :key="movement.id"
          :movement="movement"
        />
      </template>
    </BiTable>
  </div>
</template>
