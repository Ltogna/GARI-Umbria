<script setup lang="ts">
import { inject } from "vue";
import { useI18n } from "vue-i18n";

const moduleId = inject("moduleId");
const { t } = useI18n({});

defineProps<{
  cuaa?: string | null;
  name?: string | null;
  dossierDescription?: string | null;
}>();
</script>

<template>
  <div>
    <strong class="text-secondary me-1"
      >{{ t(`${moduleId}.genericDetail.name`) }}:</strong
    >
    <span class="text-secondary">{{ name }}</span>
  </div>
  <div>
    <strong class="text-secondary me-1"
      >{{ t(`${moduleId}.genericDetail.cuaa`) }}:</strong
    >
    <span class="text-secondary">{{ cuaa }}</span>
  </div>
  <div>
    <strong class="text-secondary me-1"
      >{{ t(`${moduleId}.genericDetail.dossierTipology`) }}:</strong
    >
    <span class="text-secondary">{{ dossierDescription }}</span>
  </div>
</template>
