<script setup lang="ts">
import { inject, computed } from "vue";
import { useI18n } from "vue-i18n";
import { useDossierStore } from "@/stores/dossierStore";

const moduleId = inject("moduleId");

const dossierStore = useDossierStore();
const { t } = useI18n({});
const cuaa = computed(() => {
  return dossierStore.getSelectedSubject?.code ?? "";
});
const companyName = computed(() => {
  return dossierStore.getSelectedSubject?.description ?? "";
});

defineProps<{
  dossierProcessStatus: string;
}>();
</script>
<style scoped>
@media (min-width: 500px) {
  .status-nowrap {
    white-space: nowrap !important;
  }
}
</style>

<template>
  <div
    class="w-100 d-flex col-12 text-white justify-content-between p-2 dossier-module__group-detail-header"
  >
    <div class="text-left px-2">
      {{
        t(`${moduleId}.cardContainer.headerDetails`, {
          cuaa: cuaa,
          companyName: companyName,
        })
      }}
    </div>
    <div class="justify-content-end pe-sm-2 status-nowrap">
      {{ t(`${moduleId}.cardContainer.state`) }}:
      {{ dossierProcessStatus }}
    </div>
  </div>
</template>
