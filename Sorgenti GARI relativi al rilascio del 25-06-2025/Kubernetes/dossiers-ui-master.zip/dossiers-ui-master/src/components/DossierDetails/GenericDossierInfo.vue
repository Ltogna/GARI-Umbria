<!-- eslint-disable @typescript-eslint/no-unused-vars -->
<script setup lang="ts">
import type { DossierDetailsModel } from "@/models/dossier";
import { useDossierStore } from "@/stores/dossierStore";
import { getFormattedDate } from "@/utils/dateUtils";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { inject } from "vue";
import { useI18n } from "vue-i18n";

/* enum AnomalySeverity {
  BLOCKING = "BLOCKING",
  NOT_BLOCKING = "NOT_BLOCKING",
  INFO = "INFO",
}

interface Anomaly {
  code: string;
  message: string;
  isBlocking: AnomalySeverity;
}

interface AnomaliesByCategory {
  category: string;
  anomalies: Anomaly[];
}

interface Application {
  id: number;
  year: number;
  name: string;
  sector: string;
  module: string;
  creationDate: Date;
  submissionDate: Date;
  lastMovement: string;
  anomalies: AnomaliesByCategory[];
} */

const moduleId = inject("moduleId");
const { getColor } = useColors();
const dossierStore = useDossierStore();
// const cuaa = computed(() => {
//   return dossierStore.getSelectedSubject?.code ?? "";
// });
// const companyName = computed(() => {
//   return dossierStore.getSelectedSubject?.description ?? "";
// });
const { t } = useI18n({});
//const { getColor } = useColors();
defineProps<{
  dossier: DossierDetailsModel;
}>();
</script>

<style scoped>
.sub-title-dim {
  font-size: 1.111em;
}
</style>
<template>
  <div class="container">
    <div class="mb-2 mt-4">
      <h4 class="fw-bold" :class="getColor('text', 'primary')">
        <BiIcon icon="file-lines" size="lg" />
        {{ t(`${moduleId}.genericDetail.dossierForm`) }}
      </h4>
    </div>
    <div>
      <strong class="text-secondary me-1"
        >{{ t(`${moduleId}.genericDetail.dossierId`) }}:</strong
      >
      <span class="text-secondary">{{ dossier.dossierId }}</span>
    </div>
    <div>
      <strong class="text-secondary me-1"
        >{{ t(`${moduleId}.genericDetail.dossierTipology`) }}:</strong
      >
      <span class="text-secondary">{{ dossier.moduleDescription }}</span>
    </div>
    <!-- <RegistryDossierInfo
      :cuaa="cuaa"
      :name="companyName ? companyName : ''"
      :sector="dossier.sectorDescription"
      :module="dossier.moduleDescription"
      :year="dossier.referredYear"
    /> -->
    <!-- Detail information -->
    <div class="mb-2 mt-5">
      <h4 class="fw-bold" :class="getColor('text', 'primary')">
        <BiIcon icon="file-lines" size="lg" />
        {{ t(`${moduleId}.genericDetail.detailedInformation`) }}
      </h4>
    </div>
    <div>
      <strong class="text-secondary me-1"
        >{{ t(`${moduleId}.genericDetail.incorporationDate`) }}:</strong
      >
      <span class="text-secondary">{{
        dossier.dtInsert ? getFormattedDate(dossier.dtInsert, false) : ""
        /* dossier.dtIncorporation
          ? getFormattedDate(dossier.dtIncorporation, false)
          : "" */
      }}</span>
    </div>
    <div>
      <strong class="text-secondary me-1"
        >{{ t(`${moduleId}.genericDetail.lastMovementDate`) }}:</strong
      >
      <span class="text-secondary">{{
        dossier.dtLastMovement
          ? getFormattedDate(dossier.dtLastMovement, false)
          : ""
        /* dossier.dtLastMovement
          ? getFormattedDate(dossier.dtLastMovement, false)
          : "" */
      }}</span>
    </div>
    <div>
      <strong class="text-secondary me-1"
        >{{ t(`${moduleId}.genericDetail.lastMovement`) }}:</strong
      >
      <span class="text-secondary">
        {{ dossier.lastMovement }}
      </span>
    </div>
    <!-- <div>
      <strong class="text-secondary me-1"
        >{{ t(`${moduleId}.genericDetail.lastValidationDate`) }}:</strong
      >
      <span class="text-secondary">
        {{
          dossier.dtPresentation
            ? getFormattedDate(dossier.dtPresentation, false)
            : ""
        }}
      </span>
    </div> -->
    <div>
      <strong class="text-secondary me-1"
        >{{ t(`${moduleId}.genericDetail.closingDate`) }}:</strong
      >
      <span class="text-secondary">
        {{
          // dossier.dtClosing ? getFormattedDate(dossier.dtClosing, false) : ""
          dossier.dtClosed ? getFormattedDate(dossier.dtClosed, false) : ""
        }}
      </span>
    </div>
    <!-- ID domanda rettificata. - da inserire quando verrà richiesto
    <div class="mt-5">
      <strong class="text-secondary me-1"
        >{{ t(`${moduleId}.genericDetail.adjustedApplicationId`) }}:</strong
      >
      <span class="text-secondary">TODO</span>
    </div> -->
  </div>
</template>
