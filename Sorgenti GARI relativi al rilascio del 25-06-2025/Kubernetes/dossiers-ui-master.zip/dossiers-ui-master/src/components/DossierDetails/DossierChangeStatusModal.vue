<script setup lang="ts">
import type {
  DossierDetailsModel,
  DossierTransitionModel,
  DossierTransitionsModel,
} from "@/models/dossier";
import type { ValidatedInput } from "@/models/form";
import { useDossierStore } from "@/stores/dossierStore";
import { checkMaxLength, verifyField } from "@/utils/formUtils";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiTextarea from "@abaco/bootstrap-italia-components/src/components/form/BiTextarea.vue";
import BiRadiobutton from "@abaco/bootstrap-italia-components/src/components/form/BiRadiobutton.vue";
import { inject, onMounted, ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import DossierServiceModal from "../DossierServiceModal.vue";

const dossierStore = useDossierStore();

const props = defineProps<{
  openModal: boolean;
  transitionList: DossierTransitionsModel;
  dossierId?: number;
  dossier?: DossierDetailsModel;
}>();

const emit = defineEmits(["closeModal", "hiddenProgressStatusDone"]);

const { t } = useI18n({});
const moduleId = inject("moduleId");

enum Steps {
  first,
  second,
  third,
}
const mutex = ref<Steps>(Steps.first);

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const changeStatus = ref<any>({
  status: null,
  newStatusName: null,
  notes: null,
  transitionId: null,
  notesRequired: false,
  description: null,
});

const searchFormValidators = ref<Record<string, ValidatedInput<string>>>({
  notes: {
    val: changeStatus.value.notes,
    errors: [],
  },
});

function emitCloseModal(reload = false) {
  changeStatus.value.notes = null;
  searchFormValidators.value.notes.errors = [];
  emit("closeModal", reload);
}

function updateRadioModelValueForStatus(newValue: string) {
  changeStatus.value.status = newValue;
  const transition = props.transitionList.find(
    (x: DossierTransitionModel) => x.id.toString() === newValue,
  );
  changeStatus.value.newStatusName = transition?.toNode;
  changeStatus.value.notesRequired = transition?.notesRequired;
  changeStatus.value.transitionId = transition?.id;
  changeStatus.value.description = transition?.description;
}

const modalViewStatus = ref<boolean>(false);
const modalViewProgressStatus = ref<boolean>(false);

onMounted(async () => {
  if (props.dossierId) {
    await dossierStore.loadIsInTransition(props.dossierId);
    if (!dossierStore.getIsInTransition) modalViewStatus.value = true;
    else modalViewProgressStatus.value = true;
  }
});

const statusHasChanged = ref<boolean>(false);
const statusHasError = ref<boolean>(false);
async function editStatus() {
  searchFormValidators.value.notes.val = changeStatus.value.notes;

  const maxLengthErrorMessage = t(`${moduleId}.general.maxLength`);
  const errors: boolean[] = [];
  errors.push(
    verifyField(
      [
        () =>
          checkMaxLength(
            searchFormValidators.value.notes,
            4000,
            maxLengthErrorMessage,
          ),
      ],
      searchFormValidators.value.notes,
    ),
  );

  if (errors.findIndex((x: boolean) => x) !== -1) return;

  statusHasError.value = false;
  statusHasChanged.value = false;
  if (
    changeStatus.value.status &&
    changeStatus.value.newStatusName &&
    changeStatus.value.transitionId &&
    props.dossierId
  ) {
    mutex.value = Steps.third;
    modalViewStatus.value = false;
    modalViewProgressStatus.value = true;
    try {
      dossierStore.setTransitionStatus(changeStatus.value.description);
      await dossierStore.changeStatus(
        props.dossierId,
        changeStatus.value.transitionId,
        changeStatus.value.notes,
      );
    } catch (err) {
      console.error("progress status error", err);
      statusHasError.value = true;
    }
    statusHasChanged.value = true;
  }
}

function closeComponent(reloadData = false) {
  mutex.value = Steps.second;
  modalViewStatus.value = false;
  modalViewProgressStatus.value = false;
  handleCLoseFirstModal(reloadData);
}

function closeFirstModal() {
  mutex.value = Steps.first;
  modalViewStatus.value = false;
}

function handleCLoseFirstModal(reloadData = false) {
  if (mutex.value === Steps.second) {
    emitCloseModal(reloadData);
  }
  if (mutex.value === Steps.first) {
    closeComponent();
  }
}

watch(
  () => props.openModal,
  () => {
    if (!dossierStore.getIsInTransition && props.openModal)
      modalViewStatus.value = true;
    else if (props.openModal) modalViewProgressStatus.value = true;
  },
);
</script>

<style scoped>
.aligned-in-column {
  display: flex;
  flex-direction: column;
  align-content: center;
  align-items: center;
  gap: 2rem;
}

.aligned-in-row {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}

.text-orange {
  color: orange;
}

.text-green {
  color: green;
}

.padding-top-3 {
  padding-top: 3rem;
}
</style>

<template>
  <BiModal
    :disabled-teleport="true"
    :model-value="modalViewStatus && openModal"
    ariaLabelledby="changeStatus"
    :title="t(`${moduleId}.serviceModal.statusChangeModal.title`)"
    :preventDismiss="true"
    :size="'lg'"
    @hidden-modal="handleCLoseFirstModal"
  >
    <template #body>
      <div class="container pt-2">
        <div class="row">
          <div class="col-6 col-xs-12 col-sm-12 col-md-12 col-lg-6">
            <div class="fw-bold pb-2">
              {{ t(`${moduleId}.serviceModal.movementList`) }}
            </div>
            <BiRadiobutton
              v-for="(transition, i) in props.transitionList"
              :key="i"
              :id="transition.toNode"
              :label="
                transition.description
                  ? transition.description
                  : transition.toNode
              "
              :value="transition.id.toString()"
              :modelValue="''"
              :name="'radioButtonsGroup'"
              @update:model-value="updateRadioModelValueForStatus"
            >
            </BiRadiobutton>
          </div>
          <div class="col-6 col-xs-12 col-sm-12 col-md-12 col-lg-6">
            <div class="fw-bold pb-2">
              {{ t(`${moduleId}.dossierDetails.statusModal.notes`) }}
            </div>
            <BiTextarea
              :rows="5"
              :placeholder="
                t(`${moduleId}.dossierDetails.statusModal.enterNotes`)
              "
              v-model="changeStatus.notes"
              :errors="searchFormValidators.notes.errors"
            />
          </div>
        </div>
      </div>
    </template>
    <template #footer>
      <div class="d-flex justify-content-center w-100 padding-top-3">
        <BiButton
          class="mx-1"
          is-outlined
          color="success"
          @click="closeFirstModal"
        >
          {{ t(`${moduleId}.general.cancel`) }}
        </BiButton>
        <BiButton
          class="mx-1"
          :is-disabled="changeStatus.notesRequired && !changeStatus.notes"
          color="success"
          @click="editStatus()"
        >
          {{ t(`${moduleId}.general.proceed`) }}
        </BiButton>
      </div>
    </template>
  </BiModal>

  <DossierServiceModal
    :open-modal="modalViewProgressStatus && openModal"
    @close="closeComponent(true)"
    :party="dossierStore.getSelectedSubject"
    :module="{
      moduleShortDescription: dossier?.moduleDescription,
      // sectorShortDescription: dossier?.sectorDescription,
      // year: dossier?.referredYear,
    }"
    :is-create-dossier="false"
    :translation-module="'statusChangeModal'"
    :dossier-id="dossierId"
    :dossier="dossier"
  ></DossierServiceModal>
</template>
