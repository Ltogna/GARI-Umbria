<script setup lang="ts">
import { MessageType, type ErrorMessageListModel } from "@/models/dossier";
import {
  DOSSIER_CREATION_ERROR,
  NOT_ALLOWED_MULTIPLE_DOSSIERS_ERROR,
} from "@/stores/dossierStore";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import { inject } from "vue";
import { useI18n } from "vue-i18n";

const moduleId = inject("moduleId");
const { t } = useI18n({});

defineProps<{
  messages: ErrorMessageListModel;
}>();
</script>
<style scoped>
.w-fit {
  width: fit-content;
}
</style>
<template>
  <div v-if="messages.length" class="row">
    <div v-for="message in messages" :key="message.code">
      <BiAlert isSuccess v-if="message.type === MessageType.INFO">
        <template #body>{{ message.description }}</template>
      </BiAlert>
      <BiAlert isWarn v-if="message.type === MessageType.WARNING">
        <template #body>{{ message.description }}</template>
      </BiAlert>
      <BiAlert isError v-if="message.type === MessageType.ERROR">
        <template #body>
          {{
            message.code === DOSSIER_CREATION_ERROR &&
            message.description === DOSSIER_CREATION_ERROR
              ? t(`${moduleId}.errors.createDossierFailed`)
              : message.code === NOT_ALLOWED_MULTIPLE_DOSSIERS_ERROR &&
                  message.description === NOT_ALLOWED_MULTIPLE_DOSSIERS_ERROR
                ? t(`${moduleId}.errors.NOT_ALLOWED_MULTIPLE_DOSSIERS_ERROR`)
                : message.description
          }}
        </template>
      </BiAlert>
    </div>
  </div>
</template>
