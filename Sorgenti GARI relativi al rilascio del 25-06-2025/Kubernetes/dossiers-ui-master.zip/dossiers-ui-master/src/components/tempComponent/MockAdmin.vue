<template>
  <div class="container">
    <div class="row">
      <div class="col-2 my-1">
        <button @click="goToDossierSearch">Go to dossier search view</button>
      </div>
      <div class="col-2 my-1">
        <button @click="goToDossierResult">go to dossier result</button>
      </div>
      <div class="col-2 my-1">
        <button @click="goToNewDossier">go to new dossier</button>
      </div>
      <div class="col-2 my-1">
        <button @click="goToCreateDossier">go to create dossier</button>
      </div>
      <div class="col-2 my-1">
        <button @click="goToDossierDetails">go to dossier details</button>
      </div>
      <div class="col-2 my-1">
        <button @click="goToExpressionOfInterestCard">
          go to expression of interest card
        </button>
      </div>
      <div class="col-2 my-1">
        <button @click="goToAttachmentsCard">go to attachments card</button>
      </div>
    </div>
    <!-- <div class="row">
      <div class="col-12">
        <button @click="logAsSuperAdmin()">log as superadmin</button>
        <button @click="logAsGroupAdmin()">log as groupAdmin</button>
        <button @click="logAsOperator()">log as operator</button>
        <button @click="logAsNoPermission()">
          log as user with no permission
        </button>
      </div>
    </div> -->
    <!-- <div class="row">
      <div class="col-12">
        <button
          @click="
            userAdminStore.setMockIsSuperAdmin(!userAdminStore.getIsSuperAdmin)
          "
        >
          mock super admin {{ userAdminStore.getIsSuperAdmin }}
        </button>
        <input v-model="groupCodeToMock" />
        <button @click="userAdminStore.setMockIsGroupAdmin(groupCodeToMock)">
          mock group admin {{ computedAdminGroup }}
        </button>
        <input v-model="usernameToMock" />
        <button @click="userAdminStore.setMockMyUsername(usernameToMock)">
          mock my user name {{ computedUsername }}
        </button>
      </div>
    </div> -->
  </div>
</template>

<script setup lang="ts">
// import { login, LoginData } from "@/resources/api/login";
// import { useUserAdminStore } from "@/stores/userAdminStore";
// import { getUserData } from "@abaco/safe-rest/src/sso2";
// import { computed, ref } from "vue";
import { useRouter } from "vue-router";
// import { http } from "../../resources/api/http";

const router = useRouter();
// const userAdminStore = useUserAdminStore();
// const groupCodeToMock = ref<string>("");
// const usernameToMock = ref<string>("");

// const computedAdminGroup = computed(() =>
//   userAdminStore.getIsGroupAdmin(groupCodeToMock.value)
// );

// const computedUsername = computed(() => userAdminStore.getMyUsername);

function goToDossierSearch() {
  router.push({
    name: "dossierList",
  });
}
function goToDossierResult() {
  router.push({
    name: "dossierListResults",
  });
}

function goToNewDossier() {
  router.push({
    name: "newDossier",
  });
}

function goToCreateDossier() {
  router.push({
    name: "createDossier",
  });
}

function goToDossierDetails() {
  router.push({
    name: "dossierDetail",
    params: {
      dossierId: "1234",
    },
  });
}

function goToExpressionOfInterestCard() {
  router.push({
    name: "expressionOfInterestCard",
  });
}

function goToAttachmentsCard() {
  router.push({
    name: "attachmentsCard",
  });
}

// async function logAsSuperAdmin() {
//   const u = {
//     tenant: "master",
//     username: "TM_SUPER_ADMIN_DEV",
//     password: "welcome",
//   };
//   await makeLogin(u);
// }

// async function logAsGroupAdmin() {
//   const u = {
//     tenant: "master",
//     username: "TM_GROUP_ADMIN_DEV", //ADMIN
//     password: "welcome",
//   };
//   await makeLogin(u);
// }

// async function logAsOperator() {
//   const u = {
//     tenant: "master",
//     username: "TM_USER_DEV",
//     password: "welcome",
//   };
//   await makeLogin(u);
// }

// async function logAsNoPermission() {
//   const u = {
//     tenant: "master",
//     username: "TM_NONE",
//     password: "welcome",
//   };
//   await makeLogin(u);
// }
//
// async function makeLogin(user: LoginData) {
//   await login(user);
//   userAdminStore.fetchMyUsername();
//   userAdminStore.setReady(false);
//   http.setLanguage(getUserData()?.locale || "it");
//   userAdminStore.setReady();
// }
</script>
