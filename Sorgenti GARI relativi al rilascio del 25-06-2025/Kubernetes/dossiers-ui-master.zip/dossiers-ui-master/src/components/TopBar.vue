<script lang="ts">
interface ButtonInterface {
  text: string;
  classes?: string;
  callback: (() => void) | void;
  hideButton?: boolean;
}
</script>
<script setup lang="ts">
import { useDossierStore } from "@/stores/dossierStore";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { computed } from "vue";

//State manager
const dossierStore = useDossierStore();

const isLoading = computed(() => dossierStore.getIsLoading);

withDefaults(
  defineProps<{
    isBackButton?: boolean;
    backButtonFunction?: (() => void) | void;
    title?: string;
    titleClasses?: string;
    buttonList?: ButtonInterface[];
  }>(),
  {
    backButtonFunction: () => null,
    title: "",
  },
);
</script>

<template>
  <div
    class="row mx-0 d-flex flex-row px-2 card-header py-3 border-bottom-2 border-primary align-items-center justify-content-between"
  >
    <div class="col-md-7 d-flex align-items-center my-1 my-md-0">
      <div v-if="isBackButton">
        <!-- <BiButton
          :isIcon="true"
          @click.stop="
            () => {
              backButtonFunction && backButtonFunction();
            }
          "
          :is-disabled="isLoading"
          :width="40"
          class="me-3 my-0 back-button-card"
          color="primary"
          is-outlined
        >
          <BiIcon
            icon="arrow-left"
            color="primary"
            size="xl"
            icon-style="regular"
          />
        </BiButton> -->
        <BiBackButton
          class="me-3 my-0 back-button-card"
          @click="
            () => {
              !isLoading && backButtonFunction && backButtonFunction();
            }
          "
        />
      </div>
      <div>
        <h3 class="mb-0 text-primary" :class="titleClasses">
          {{ title }}
        </h3>
      </div>
    </div>
    <div
      v-if="buttonList && buttonList.length > 0"
      class="col-md-5 text-center text-md-end my-1 my-md-0"
    >
      <template v-for="button in buttonList" :key="button.text">
        <BiButton
          v-if="!button.hideButton"
          @click="
            () => {
              button.callback && button.callback();
            }
          "
          :class="button.classes || ''"
          class="my-1"
        >
          {{ button.text }}
        </BiButton>
      </template>
    </div>
  </div>
</template>
