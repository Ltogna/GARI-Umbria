<script setup lang="ts">
import {
  MessageType,
  type DossierDetailsModel,
  type DossierTypeModel,
  type PartyModel,
} from "@/models/dossier";
import { useDossierStore } from "@/stores/dossierStore";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { computed, inject, ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import RegistryDossierInfo from "./DossierDetails/RegistryDossierInfo.vue";
import DossierServiceModalErrorsMessages from "./DossierServiceModalErrorsMessages.vue";

const moduleId = inject("moduleId");
const { t } = useI18n({});

const onLoading = ref<boolean>(false);
const dossierStore = useDossierStore();

const props = defineProps<{
  openModal: boolean;
  party: PartyModel | null;
  module?: Partial<DossierTypeModel>;
  isCreateDossier: boolean;
  translationModule: string;
  dossierId?: number | null;
  dossier?: DossierDetailsModel;
}>();

const internalValue = ref<boolean>(props.openModal);
const initialStatus = ref<string>("");

const transitionData = computed(() => {
  const transition = dossierStore.getTransitionData;
  if (transition) {
    transition?.lastTransitionLog?.messages?.sort((a, b) => {
      if (
        (a.type === MessageType.ERROR && b.type === MessageType.ERROR) ||
        (a.type === MessageType.ERROR && b.type !== MessageType.ERROR) ||
        (a.type === MessageType.WARNING && b.type === MessageType.INFO)
      ) {
        return -1;
      } else if (
        (a.type === MessageType.WARNING && b.type === MessageType.ERROR) ||
        (a.type === MessageType.INFO && b.type !== MessageType.INFO)
      ) {
        return 1;
      } else {
        return 0;
      }
    });
  }
  return transition;
});
const emit = defineEmits<{
  (e: "close", value?: boolean): void;
}>();

const goToDetail = ref<boolean>(false);

function closeModal() {
  emit("close", goToDetail.value);
}

watch(
  () => props.openModal,
  () => {
    internalValue.value = props.openModal;
    if (props.openModal) {
      if (props.dossier && props.dossier.processStatusDescription) {
        initialStatus.value = props.dossier.processStatusDescription;
      } else {
        initialStatus.value = "";
      }
      if (props.dossierId) {
        onLoading.value = true;
        loadTransitionData(2000, 2000);
      }
    }
  },
);

function loadTransitionData(previousTime: number, timeToWait: number) {
  setTimeout(async () => {
    if (props.dossierId) {
      await dossierStore.loadIsInTransition(props.dossierId);
      if (dossierStore.getIsInTransition === false) {
        onLoading.value = false;
      } else {
        loadTransitionData(timeToWait, timeToWait + previousTime);
      }
    }
  }, timeToWait);
}

const errorMessages = computed(() => {
  if (
    !onLoading.value &&
    transitionData.value &&
    transitionData.value.lastTransitionLog &&
    transitionData.value.lastTransitionLog.messages &&
    transitionData.value.lastTransitionLog.messages.length > 0
  ) {
    return transitionData.value.lastTransitionLog.messages;
  }
  return [];
});
</script>
<style scoped>
.w-fit {
  width: fit-content;
}
</style>
<template>
  <BiModal
    :modelValue="internalValue"
    :disabled-teleport="true"
    @hidden-modal="closeModal"
    :ariaLabelledby="`${t(
      `${moduleId}.serviceModal.${translationModule}.title`,
    )}`"
    :title="`${t(`${moduleId}.serviceModal.${translationModule}.title`)}`"
    :size="'lg'"
    :prevent-dismiss="true"
    :extra-footer-class="'justify-content-center'"
  >
    <template v-slot:body>
      <template v-if="openModal">
        <RegistryDossierInfo
          :cuaa="party?.code"
          :name="party?.description"
          :dossierDescription="module?.moduleShortDescription"
        />
        <div class="grid mt-4">
          <div class="d-flex row">
            <div v-if="onLoading" class="d-flex justify-content-center mb-2">
              <h4 class="text-secondary">
                <b>
                  {{
                    t(
                      `${moduleId}.serviceModal.${translationModule}.processInProgress`,
                    )
                  }}
                </b>
              </h4>
            </div>
            <div v-if="!onLoading" class="d-flex justify-content-center mb-3">
              <h4 class="text-secondary">
                <b v-if="!transitionData?.lastTransitionLog?.failed">
                  {{
                    t(
                      `${moduleId}.serviceModal.${translationModule}.processSuccess`,
                    )
                  }}
                </b>
                <b
                  v-if="
                    transitionData?.lastTransitionLog?.failed ||
                    dossierStore.hasError
                  "
                >
                  {{
                    t(
                      `${moduleId}.serviceModal.${translationModule}.processFailed`,
                    )
                  }}
                </b>
              </h4>
            </div>
          </div>
          <div v-if="onLoading" class="d-flex row justify-content-center mb-3">
            <div class="d-flex col-2 justify-content-center px-0">
              <BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
            </div>
          </div>
          <div v-if="!onLoading" class="d-flex row justify-content-center mb-3">
            <div class="d-flex col-2 justify-content-center px-0">
              <BiIcon
                :icon="
                  !transitionData?.lastTransitionLog?.failed
                    ? 'circle-check'
                    : 'circle-xmark'
                "
                :icon-style="'light'"
                :class="
                  !transitionData?.lastTransitionLog?.failed
                    ? 'text-success'
                    : 'text-danger'
                "
                size="5x"
              ></BiIcon>
            </div>
          </div>
          <BiTable
            class="table-responsive w-100"
            extraTableClasses="table-head-bg"
            isResponsive
          >
            <template v-slot:head>
              <tr class="bg-light text-secondary">
                <th scope="col">
                  {{ t(`${moduleId}.serviceModal.currentState`) }}
                </th>
                <th v-if="onLoading" scope="col">
                  {{ t(`${moduleId}.serviceModal.movements`) }}
                </th>
                <th v-else-if="!onLoading" scope="col">
                  {{
                    !transitionData?.lastTransitionLog?.failed
                      ? t(`${moduleId}.serviceModal.movementComplete`)
                      : t(`${moduleId}.serviceModal.movementFailed`)
                  }}
                </th>
              </tr>
            </template>
            <template v-slot:body>
              <tr>
                <td :data-label="t(`${moduleId}.serviceModal.currentState`)">
                  {{
                    transitionData?.lastTransitionLog &&
                    !transitionData?.lastTransitionLog?.failed &&
                    !onLoading
                      ? transitionData?.lastTransitionLog.toNodeDescription?.toUpperCase()
                      : initialStatus.toUpperCase()
                  }}
                </td>
                <td :data-label="t(`${moduleId}.serviceModal.movements`)">
                  {{
                    dossierStore.getTransitionStatus
                      ? dossierStore.getTransitionStatus.toUpperCase()
                      : ""
                  }}
                </td>
              </tr>
            </template>
          </BiTable>
          <DossierServiceModalErrorsMessages :messages="errorMessages" />
          <div
            class="row"
            v-if="!onLoading && transitionData?.lastTransitionLog?.notes"
          >
            <strong class="text-secondary me-1"
              >{{ t(`${moduleId}.dossierDetails.statusModal.notes`) }}:</strong
            >
            <span class="text-secondary">{{
              transitionData?.lastTransitionLog?.notes
                ? transitionData.lastTransitionLog.notes
                : ""
            }}</span>
          </div>
        </div>
      </template>
    </template>
    <template v-slot:footer>
      <div class="mt-3 mb-5 d-flex justify-content-center w-100">
        <BiButton
          class="mx-2 w-fit"
          color="secondary"
          is-outlined
          @click.stop="
            goToDetail = false;
            internalValue = false;
          "
        >
          {{ t(`${moduleId}.general.close`) }}
        </BiButton>
        <BiButton
          v-if="
            !onLoading &&
            !transitionData?.lastTransitionLog?.failed &&
            isCreateDossier
          "
          class="mx-2 w-fit"
          color="success"
          is-outlined
          @click.stop="
            goToDetail = true;
            internalValue = false;
          "
        >
          {{ t(`${moduleId}.serviceModal.goToDossier`) }}
        </BiButton>
      </div>
    </template>
  </BiModal>
</template>
