import createBootstrapItaliaPlugin from "@abaco/bootstrap-italia-components/src/components/BootstrapItaliaComponentPlugin";
import { onModuleLoaded } from "@abaco/micro-frontend/src/Application";
import { ROUTE_LEAVE_CONFIRM_COMPONENT_NAME } from "@abaco/micro-frontend/src/model";
import { createAbcRouter } from "@abaco/micro-frontend/src/Utility";
import { getUserData } from "@abaco/safe-rest/src/sso2";
import { createPinia } from "pinia";
import type { App as VueApp } from "vue";
import { createApp } from "vue";
import { createRouter, createWebHistory } from "vue-router";
import App from "./App.vue";
import AskExitConfirmDialoag from "./components/AskExitConfirmDialog.vue";
import { BASE } from "./constants";
import i18n, { loadLocaleMessages } from "./i18n";
import routes from "./routes";
import { useDossierStore } from "./stores/dossierStore";
import { useUserAdminStore } from "./stores/userAdminStore";
import { isStandalone } from "./utils/isStandalone";

export const MODULE_ID = "dossier";
export const IS_DEV = import.meta.env.DEV;

// XXX do this only for test
if (IS_DEV && import.meta.env.VITE_USER_CONFIG) {
  sessionStorage.setItem("sso2data", import.meta.env.VITE_USER_CONFIG);
}
import("@/assets/dossierModule.scss");

async function initApplication(isStandalone: boolean, basePath?: string) {
  const router = isStandalone
    ? createRouter({
        history: createWebHistory(import.meta.env.BASE_URL),
        routes,
      })
    : createAbcRouter(routes, basePath);
  const bootstrapItaliaComponentPlugin = await createBootstrapItaliaPlugin({
    includeGlobalComponent: false,
    includeFontAwesome: isStandalone ? true : false,
  });
  const app = createApp(App);
  await loadLocaleMessages(getUserData()?.locale || "en");
  app.use(i18n);
  app.use(bootstrapItaliaComponentPlugin);
  app.use(createPinia());
  app.use(router);
  app.provide("moduleId", MODULE_ID);
  app.provide("isDev", IS_DEV);
  app.provide("basePath", basePath);
  app.component(ROUTE_LEAVE_CONFIRM_COMPONENT_NAME, AskExitConfirmDialoag);
  const dossierStore = useDossierStore();

  router.beforeEach((to) => {
    const routeDossierId = to.params.dossierId as string;
    if (routeDossierId) {
      dossierStore.setRouteDossierId(routeDossierId);
    } else if (to.name === "createDossier") {
      dossierStore.setRouteDossierId("new");
    }
  });

  return app;
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
let dirtyState = false;
if (isStandalone) {
  window.bootstrap.loadFonts(BASE + "bootstrap-italia/dist/fonts");
  await import("@/assets/index.scss");
  initApplication(isStandalone, "").then((app) => {
    app.mount("#app");
    useUserAdminStore().fetchMyUsername();
  });
} else {
  let appModule: VueApp<Element> | null;

  onModuleLoaded(MODULE_ID, {
    async start(node: string | Element, basePath?: string) {
      const app = await initApplication(isStandalone, basePath);
      app.mount(node);
      appModule = app;
    },

    css() {
      return {
        index: BASE + "assets/index.css.json",
      };
    },
    async canStop() {
      // if (dirtyState) {
      //   return {
      //     title: i18n.global.t(`${MODULE_ID}.micro.askForExitTitle`),
      //     message: i18n.global.t(`${MODULE_ID}.micro.askForExitMessage`),
      //   };
      // } else {
      return true;
      // }
    },
    async stop() {
      appModule?.unmount();
    },
  });
}

window.addEventListener("forms-dirty-state", ((event: CustomEvent) => {
  dirtyState = event.detail.formDirtyState;
}) as EventListener);
