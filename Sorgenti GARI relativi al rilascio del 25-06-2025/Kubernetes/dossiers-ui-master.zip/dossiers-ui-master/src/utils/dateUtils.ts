import { getUserData } from "@abaco/safe-rest/src/sso2";
import { format } from "date-fns";

// interface envModel {
//   authToken: string;
//   authTokenExpiresAt: number;
//   refreshToken: string;
//   user: {
//     user_id: string;
//     username: string;
//     tenant: string;
//     description: string;
//     locale: string;
//     dateFormat: string;
//   };
// }

// /**
//  * @param dateString format YYYYMMDD or ISO string or millis
//  * @param withTime add time to returned string
//  * @returns locale date string
//  */
// export function getLocaleString(
//   dateString: string | number,
//   withTime?: boolean
// ): string {
//   if (typeof dateString === "string") {
//     try {
//       // check if format is YYYYMMDD or iso string
//       if (dateString && dateString.length === 8) {
//         const year = parseInt(dateString.substring(0, 4));
//         const month = parseInt(dateString.substring(4, 6));
//         const day = parseInt(dateString.substring(6, 8));

//         if (withTime) {
//           return new Date(year, month - 1, day).toLocaleString(
//             envObj.user.locale
//           );
//         } else {
//           return new Date(year, month - 1, day).toLocaleDateString(
//             envObj.user.locale
//           );
//         }
//       } else {
//         if (withTime) {
//           return new Date(Date.parse(dateString)).toLocaleString(
//             envObj.user.locale
//           );
//         } else {
//           return new Date(Date.parse(dateString)).toLocaleDateString(
//             envObj.user.locale
//           );
//         }
//       }
//     } catch (e) {
//       console.error("Error in dateUtils>getLocaleString");
//       return "date error";
//     }
//   }
//   if (typeof dateString === "number") {
//     return new Date(dateString).toLocaleString(envObj.user.locale);
//   }
//   return "Invalid Date";
// }

/**
 * @param dateString format: yyyyMMdd || yyyy-MM-dd || yyyy-MM-dd HH:mm:ss || timestamp || yyyy-MM-ddTHH:mm:ss...
 * @param withTime add time to returned string (if provided in dateString)
 */
export function getFormattedDate(
  dateString: string | number,
  withTime?: boolean,
  fromHistory?: boolean,
) {
  const _dateString = dateString.toString();
  try {
    const _user = getUserData();
    if (!_user || !_user.dateFormat) {
      console.error(
        "Error in dateUtils>getFormattedDate, user does not have dateformat info",
      );
      return "error_date";
    }

    // date mask
    const _userDateFormat =
      _user.dateFormat.split("D").join("d").split("Y").join("y") ||
      "dd/MM/yyyy";

    let year: number;
    let month: number;
    let day: number;
    let hour: number;
    let min: number;
    let sec: number;

    if (fromHistory) {
      const _dateObj = new Date(_dateString);

      const _formattedDate = format(_dateObj, _userDateFormat);

      if (withTime) {
        hour = _dateObj.getHours();
        min = _dateObj.getMinutes();
        sec = _dateObj.getSeconds();

        return `${_formattedDate} ${hour < 10 ? "0" + hour : hour}:${
          min < 10 ? "0" + min : min
        }:${sec < 10 ? "0" + sec : sec}`;
      } else {
        return _formattedDate;
      }
    } else if (_dateString && _dateString.length === 8) {
      // dateString has yyyyMMdd format
      year = parseInt(_dateString.substring(0, 4));
      month = parseInt(_dateString.substring(4, 6));
      day = parseInt(_dateString.substring(6, 8));

      return format(new Date(year, month - 1, day), _userDateFormat);
    } else if (
      _dateString.length === 10 &&
      _dateString.charAt(4) === "-" &&
      _dateString.charAt(7) === "-"
    ) {
      // dateString has yyyy-MM-dd format
      year = parseInt(_dateString.substring(0, 4));
      month = parseInt(_dateString.substring(5, 7));
      day = parseInt(_dateString.substring(8, 10));

      return format(new Date(year, month - 1, day), _userDateFormat);
    } else if (
      (_dateString.length === 19 || _dateString.length === 29) &&
      _dateString.charAt(4) === "-" &&
      _dateString.charAt(7) === "-" &&
      (_dateString.charAt(10) === " " || _dateString.charAt(10) === "T") &&
      _dateString.charAt(13) === ":" &&
      _dateString.charAt(16) === ":"
    ) {
      // dateString has yyyy-MM-dd HH:mm:ss or yyyy-MM-ddTHH:mm:ss format
      year = parseInt(_dateString.substring(0, 4));
      month = parseInt(_dateString.substring(5, 7));
      day = parseInt(_dateString.substring(8, 10));
      hour = parseInt(_dateString.substring(11, 13));
      min = parseInt(_dateString.substring(14, 16));
      sec = parseInt(_dateString.substring(17, 19));

      const _formattedDate = format(
        new Date(year, month - 1, day),
        _userDateFormat,
      );

      if (withTime) {
        return `${_formattedDate} ${hour < 10 ? "0" + hour : hour}:${
          min < 10 ? "0" + min : min
        }:${sec < 10 ? "0" + sec : sec}`;
      } else {
        return _formattedDate;
      }
    } else if (_dateString.match(/\d+$/)) {
      // dateString is a timestamp

      const _dateObj = new Date(parseInt(_dateString));
      const _formattedDate = format(_dateObj, _userDateFormat);

      if (withTime) {
        hour = _dateObj.getHours();
        min = _dateObj.getMinutes();
        sec = _dateObj.getSeconds();

        return `${_formattedDate} ${hour < 10 ? "0" + hour : hour}:${
          min < 10 ? "0" + min : min
        }:${sec < 10 ? "0" + sec : sec}`;
      } else {
        return _formattedDate;
      }
    } else {
      console.warn(
        "Warning in dateUtils>getFormattedDate, dateString is not in a valid format",
      );
      return _dateString;
    }
  } catch (e) {
    console.error("Error in dateUtils>getFormattedDate");
    return "date_error";
  }
}
