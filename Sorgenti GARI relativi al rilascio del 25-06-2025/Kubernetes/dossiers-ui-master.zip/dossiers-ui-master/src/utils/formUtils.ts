import type { ValidatedInput } from "@/models/form";
import type { GlobalConfigInterface } from "just-validate/dist/modules/interfaces";

export const justValidateConfig: Partial<GlobalConfigInterface> = {
  errorFieldCssClass: "is-invalid",
  errorLabelCssClass: "form-feedback",
  errorLabelStyle: "",
  focusInvalidField: true,
};

export const elementIdPrefix = import.meta.env.VITE_MODULE_ID;

export function getFieldSelector(formId: string, fieldName: string): string {
  return `#${formId} [name='${fieldName}']`;
}

export function matchForm(
  softwareUrl: string | undefined,
  destination: string,
) {
  const splitted = (softwareUrl ?? "").split("/");
  if (splitted.length > 0) {
    const index = splitted.findIndex((x) =>
      x.includes(destination.replaceAll("/", "")),
    );
    if (index > -1) {
      return splitted[index].split("?")[0];
    }
  }
  return undefined;
}

export const wait = async (millis: number) => {
  return new Promise<void>((resolve) => {
    setTimeout(() => resolve(), millis);
  });
};

export function verifyField(
  validatingFunctions: (() => boolean)[],
  field: ValidatedInput<string | null>,
  flush = true,
): boolean {
  if (flush) {
    field.errors = [];
  }
  for (const valFunc of validatingFunctions) {
    const res = valFunc();
    if (res) {
      return res;
    }
  }
  return false;
}

export function checkMaxLength(
  field: ValidatedInput<string | null>,
  maxLength: number,
  errorMessage: string,
) {
  if (field.val && field.val.length > maxLength) {
    field.errors.push(errorMessage);
    return true;
  }
  return false;
}

export function extractModuleId(softwareUrl: string | undefined) {
  const splitted = (softwareUrl ?? "").split("/");
  if (splitted.length > 0) {
    const uiChunkIndex = splitted.indexOf("ui");
    if (uiChunkIndex > -1) {
      return splitted[uiChunkIndex + 1];
    }
  }
  return undefined;
}
