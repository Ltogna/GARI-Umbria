import type { DynamicModulesState } from "@abaco/micro-frontend/src/model";
import type { RouteRecordRaw } from "vue-router";

export const modulesState: DynamicModulesState = {
  modules: {},
};

const routes: RouteRecordRaw[] = [];

routes.push(
  {
    redirect: { name: "dossierList" },
    path: "/",
  },
  // List of task
  {
    path: "/dossierList",
    name: "dossierList",
    component: () => import("../views/DossierSearchView.vue"),
  },
  {
    path: "/dossierlist/party/:partyId/:dossierType?/:includeClosedDossier?/result",
    name: "dossierListResults",
    component: () => import("../views/DossierResultView.vue"),
  },
  {
    path: "/newDossier",
    name: "newDossier",
    component: () => import("../views/NewDossierView.vue"),
  },
  {
    path: "/createDossier/party/:partyId",
    name: "createDossier",
    component: () => import("../views/CreateDossierView.vue"),
  },
  {
    path: "/dossierlist/result/:dossierId/dossierDetails/:p*",
    name: "dossierDetail",
    component: () => import("../views/DossierDetailsView.vue"),
  },
  // ,
  // {
  //   path: "/dossierlist/result/:dossierId/dossierDetails/:formRoute*",
  //   name: "dossierDetailForm",
  //   component: () => import("../views/DossierDetailsView.vue"),
  // }
);

export default routes;
