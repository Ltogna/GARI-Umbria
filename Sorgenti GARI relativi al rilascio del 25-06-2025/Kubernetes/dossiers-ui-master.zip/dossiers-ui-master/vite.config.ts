import { fileURLToPath, URL } from "url";
import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";
import { BASE } from "./src/constants";
import { viteStaticCopy } from "vite-plugin-static-copy";

// https://vitejs.dev/config/
export default defineConfig({
  base: BASE,
  plugins: [
    vue(),
    viteStaticCopy({
      targets: [
        {
          src: "node_modules/bootstrap-italia/dist/**/*",
          dest: "bootstrap-italia/dist",
        },
      ],
    }),
  ],
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  build: {
    rollupOptions: {
      output: {
        entryFileNames: "[name].[hash].js",
        assetFileNames: "assets/[name].[hash].[ext]",
      },
    },
  },
  server: {
    port: 3000,
    proxy: {
      "/dossiers": {
        target: "https://iacs-dev.fe.abacogroup.eu",
        //target: "http://localhost:29000",
        secure: false,
        changeOrigin: true,
      },
      "/party-registry": {
        target: "https://iacs-dev.fe.abacogroup.eu",
        // target: "http://localhost:29000",
        secure: false,
        changeOrigin: true,
      },
      "/dossier-forms": {
        target: "https://iacs-dev.fe.abacogroup.eu",
        // target: "http://localhost:8080",
        secure: false,
        changeOrigin: true,
      },
      "/ui/dos-forms": {
        target: "https://iacs-dev.fe.abacogroup.eu",
        // target: "http://localhost:8080",
        secure: false,
        changeOrigin: true,
      },
      "/sso2": {
        target: "https://iacs-dev.fe.abacogroup.eu",
        secure: false,
        changeOrigin: true,
      },
    },
  },
});
