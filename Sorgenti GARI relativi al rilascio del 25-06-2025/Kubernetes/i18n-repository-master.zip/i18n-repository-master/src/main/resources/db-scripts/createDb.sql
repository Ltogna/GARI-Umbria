-- 	L'id del software NON può contenere il carattere '.' per evitare problemi con l'url	
create table i18n_software (
	id varchar(50) not null,
	descr varchar(200) not null,
	parent_id varchar(50),
	constraint i18n_software_pk primary key (id),
	constraint i18n_software_fk1 foreign key (parent_id) references i18n_software (id)
);

comment on table i18n_software is 'i18n: Softwares';

--

create table i18n_labels (
	id varchar(100) not null,
	descr varchar(500),
	constraint i18n_labels_pk primary key (id)
);

comment on table i18n_labels is 'i18n: labels catalogue';

--

create table i18n_languages (
	lang varchar(10) not null,
	descr varchar(100) not null,
	constraint i18n_languages_pk primary key (lang)
);

comment on table i18n_languages is 'i18n: Existing languages';

--

create table i18n_label_values (
	label_id varchar(100) not null,
	lang varchar(10) not null,
	val varchar(4000) not null,
	constraint i18n_label_values_pk primary key (label_id, lang),
	constraint i18n_label_values_fk1 foreign key (label_id) REFERENCES i18n_labels(id)
);

comment on table i18n_label_values is 'i18n: Label values in the different languages';

--

create table i18n_software_labels (
	software_id varchar(50) not null,
	label_id varchar(100) not null,
	min_version number(7) default 1 not null,
	max_version number(7) default 9999999 not null,
	constraint i18n_software_labels_pk primary key (software_id, label_id)
);

comment on table i18n_software_labels is 'i18n: Link between softwares and labels';

--

create table i18n_variants (
	software_id varchar(50) not null,
	label_id varchar(100) not null,
	lang varchar(10) not null,
	val varchar(500) not null,
	constraint i18n_i18n_variants_pk primary key (software_id, label_id, lang),
	constraint i18n_i18n_variants_fk1 foreign key (software_id) references i18n_software (id)
);

create index i18n_variants_ix1 on i18n_variants (label_id);

comment on table i18n_variants is 'i18n: Per-software label values variants';