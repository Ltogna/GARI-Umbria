#!/bin/sh
umask 0002 && \
java -XX:MaxRAMPercentage=70 -jar original-${project.build.finalName}.jar server config.yml