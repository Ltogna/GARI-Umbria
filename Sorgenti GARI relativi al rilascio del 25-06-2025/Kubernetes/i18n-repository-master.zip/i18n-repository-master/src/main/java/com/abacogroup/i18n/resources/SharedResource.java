package com.abacogroup.i18n.resources;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.abacogroup.i18n.api.LabelOut;
import com.abacogroup.i18n.db.LabelsDao;
import com.abacogroup.i18n.db.VariantDao;

public class SharedResource {

	public static HashSet<LabelOut> mergeLanguages(String swId, String lang, LabelsDao labelsDao, boolean withType) {
		return mergeLanguages(swId, lang, null, labelsDao, withType);
	}

	public static HashSet<LabelOut> mergeLanguages(String swId, String lang, String fallBackLang, LabelsDao labelsDao, boolean withType) {
		HashSet<LabelOut> res = new HashSet<LabelOut>();
		String curLang;
		String fullLang = lang;
		int fallback = 0;

		if (fallBackLang != null) {
			fullLang = fallBackLang + "/" + lang;
			fallback = fullLang.indexOf("/") + 1;
		}

		int index = fullLang.length();

		do {
			curLang = fullLang.substring(fallback, index);
			if (withType) {
				res.addAll(labelsDao.getLabels(swId, curLang));
			} else {
				res.addAll(labelsDao.getLabelsNoType(swId, curLang));
			}
			index = curLang.lastIndexOf("_") + fallback;
			if (index < fallback) {
				fallback = 0;
			}
		} while (index > 0);

		return res;
	}

	public static Set<LabelOut> mergeVariants(String parentSwId, String swId, LabelsDao labelsDao, VariantDao varDao) {
		Set<LabelOut> parentLabels = labelsDao.getLabelListPerSoftware(parentSwId);
		HashSet<LabelOut> variants = new HashSet<>(varDao.getLabelListVariants(swId));
		return mergeVariants(variants, parentLabels, labelsDao);
	}

	public static HashSet<LabelOut> mergeVariants(String parentSwId, String swId, String lang, LabelsDao labelsDao,
			VariantDao varDao, boolean withType) {
		Set<LabelOut> parentLabels = SharedResource.mergeLanguages(parentSwId, lang, labelsDao, withType);
		HashSet<LabelOut> variants = new HashSet<>(varDao.getLabelsVariants(swId, lang));
		return mergeVariants(variants, parentLabels, labelsDao);
	}

	private static HashSet<LabelOut> mergeVariants(HashSet<LabelOut> variants, Set<LabelOut> parentLabels,
			LabelsDao labelsDao) {
		variants.forEach(var -> {
			String variantType = labelsDao.isLabelPresent(var.getId(), false) ? "editedVariant" : "newVariant";
			var.setType(variantType);
		});
		variants.addAll(parentLabels);
		return variants;
	}

	@SuppressWarnings("unchecked")
	public static Map<String, Object> jsonBuilder(String key, String value, Map<String, Object> json) {

		int splitCharIndex = key.indexOf(".");

		if (splitCharIndex > 0) {

			String subKey = key.substring(0, splitCharIndex);
			Map<String, Object> subJson = new HashMap<String, Object>();

			if (json.containsKey(subKey)) {
				subJson = (Map<String, Object>) json.get(subKey);
			}

			Map<String, Object> res = jsonBuilder(key.substring(splitCharIndex + 1, key.length()), value, subJson);

			json.put(subKey, res);

		} else {
			json.put(key, value);
		}

		return json;
	}

	public static void jsonExtractor(String key, Object value, HashMap<String, String> extractedValues) {

		if (value instanceof String) {
			extractedValues.put(key, (String) value);
		} else if (value == null) {
			extractedValues.put(key, null);
		} else {
			@SuppressWarnings("unchecked")
			HashMap<String, Object> subJson = (HashMap<String, Object>) value;
			subJson.forEach((String subKey, Object subValue) -> {
				jsonExtractor(key + "." + subKey, subValue, extractedValues);
			});
		}
	}

	public static boolean isLabelAlreadyPresent(String labelId, LabelsDao labelsDao) {

		if (labelsDao.isLabelPresent(labelId + ".%", true)) {
			return true;
		}

		int index = labelId.length();
		do {
			labelId = labelId.substring(0, index);
			if (labelsDao.isLabelPresent(labelId, false)) {
				return true;
			}
			index = labelId.lastIndexOf(".");
		} while (index > 0);

		return false;
	}

	public static boolean isVariantAlreadyPresent(String labelId, String swId, VariantDao variantDao) {

		if (variantDao.isLabelPresent(swId, labelId + ".%", true)) {
			return true;
		}

		int index = labelId.length();
		do {
			labelId = labelId.substring(0, index);
			if (variantDao.isLabelPresent(swId, labelId, false)) {
				return true;
			}
			index = labelId.lastIndexOf(".");
		} while (index > 0);

		return false;
	}

	public static boolean isAcceptableLabel(String labelId) {
		Pattern pattern = Pattern.compile("[&?/<>\\[\\]{} \\\\\\|~`=]");
		Matcher matcher = pattern.matcher(labelId);

		return !matcher.find();
	}

}
