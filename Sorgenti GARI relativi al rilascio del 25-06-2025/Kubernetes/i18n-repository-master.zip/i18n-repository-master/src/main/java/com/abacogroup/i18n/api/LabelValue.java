package com.abacogroup.i18n.api;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class LabelValue{
	
	@NotEmpty
	@NotNull
	private String lang;
	
	@NotEmpty
	@NotNull
	private String val;
	
	public LabelValue() {
	}

	public LabelValue(String lang, String val) {
		this.lang = lang;
		this.val = val;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

	public String getVal() {
		return val;
	}

	public void setVal(String val) {
		this.val = val;
	}
	
	@Override
	public int hashCode() {
	      return this.lang.hashCode();
	}
}