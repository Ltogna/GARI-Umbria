package com.abacogroup.i18n.db;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.i18n.api.Language;;

public interface LanguageDao extends Transactional<LanguageDao> {
	
	@SqlQuery("SELECT lang" + 
			  " FROM i18n_languages" + 
			  " ORDER BY lang")
	public List<String> getLanguages();
	
	@SqlQuery("SELECT lang, descr"
			+ " FROM i18n_languages" 
			+ " ORDER BY lang")
	@RegisterBeanMapper(Language.class)
	public List<Language> getLanguagesWithDescr();
	
	@SqlUpdate("INSERT into i18n_languages (lang, descr)" + 
			  " VALUES (:lang, :descr)")
	public int createLanguage(@Bind("lang") String lang, @Bind("descr") String descr);

	@SqlUpdate("DELETE FROM i18n_languages")
	public int deleteAllLanguages();
}
