package com.abacogroup.i18n.resources;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.security.PermitAll;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response.Status;

import com.abacogroup.i18n.api.LabelOut;
import com.abacogroup.i18n.api.Software;
import com.abacogroup.i18n.db.LabelsDao;
import com.abacogroup.i18n.db.SoftwareDao;
import com.abacogroup.i18n.db.VariantDao;
import com.codahale.metrics.annotation.Timed;

@PermitAll
@Path("/admin/software")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class SoftwareResource {

	private final SoftwareDao swDao;
	private final LabelsDao labelsDao;
	private final VariantDao variantDao;
	private final String[] ALLOWED_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_".split("");

	public SoftwareResource(SoftwareDao swDao, LabelsDao labelsDao, VariantDao variantDao) {
		this.swDao = swDao;
		this.labelsDao = labelsDao;
		this.variantDao = variantDao;
	}

	@GET
	@Timed
	public List<Software> getSoftware() {
		return swDao.getSoftware();
	}

	@GET
	@Timed
	@Path("/{swId}/labels")
	public Set<LabelOut> getLabels(@PathParam("swId") String swId, @NotEmpty @NotNull @QueryParam("lang") String lang) {
		String parentSwId = this.swDao.getParentId(swId);
		HashSet<LabelOut> partialRes;
		if (parentSwId != null) {
			partialRes = SharedResource.mergeVariants(parentSwId, swId, lang, labelsDao, variantDao, true);
			partialRes.addAll(SharedResource.mergeVariants(parentSwId, swId, labelsDao, variantDao));
		} else {
			partialRes = SharedResource.mergeLanguages(swId, lang, labelsDao, true);
			partialRes.addAll(labelsDao.getLabelListPerSoftware(swId));
		}
		return partialRes;
	}

	@PUT
	@Timed
	@Path("{id}")
	public Boolean updateSoftware(@PathParam("id") String id, @Valid @NotNull Software updatedSw) {
		return swDao.updateSoftware(id, updatedSw.getDescr(), updatedSw.getParentId()) == 1;
	}

	@POST
	@Timed
	public Boolean createSoftware(@Valid @NotNull Software newSw) {
		String swId = newSw.getId();
		Pattern pattern = Pattern.compile("\\W"); // non word character, only (A-Za-z0-9_) are allowed
		Matcher matcher = pattern.matcher(swId);
		if (matcher.find()) {
			throw new WebApplicationException(swId + " contains not allowed characters, Only alfanumeric character and _ character can be used",
					Status.BAD_REQUEST);
		}
		if (this.swDao.isSwPresent(swId)) {
			final String msg = String.format("Software %s already exits", swId);
			throw new WebApplicationException(msg, Status.CONFLICT);
		}
		return swDao.createSoftware(swId, newSw.getDescr(), newSw.getParentId()) == 1;
	}

	@POST
	@Timed
	@Path("{swId}/labels")
	@Consumes(MediaType.TEXT_PLAIN)
	public Boolean linkLabelToSoftware(@PathParam("swId") String swId, @NotNull @NotEmpty String labelToBeLinked) {
		String parentId = this.swDao.getParentId(swId);
		if (parentId != null) {
			swId = parentId;
		}
		if (swDao.isLabelPresent(swId, labelToBeLinked)) {
			final String msg = String.format("Label %s already present in software %s.", labelToBeLinked, swId);
			throw new WebApplicationException(msg, Status.CONFLICT);
		}
		return swDao.linkLabel(swId, labelToBeLinked) == 1;
	}

	@DELETE
	@Timed
	@Path("{swId}/labels/{labelId}")
	public Boolean unLinkLabelFromSoftware(@PathParam("swId") String swId, @PathParam("labelId") String labelId) {
		String parentId = this.swDao.getParentId(swId);
		if (parentId != null) {
			return variantDao.deleteVariant(swId, labelId) >= 1;
		}
		return swDao.deleteLabelFromSoftware(labelId, swId) == 1;
	}

}
