package com.abacogroup.i18n.resources;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.abacogroup.i18n.api.LabelOut;
import com.abacogroup.i18n.db.LabelsDao;
import com.abacogroup.i18n.db.SoftwareDao;
import com.abacogroup.i18n.db.VariantDao;
import com.codahale.metrics.annotation.Timed;

@Path("")
@Produces(MediaType.APPLICATION_JSON)
public class TranslationResource {

	private SoftwareDao swDao;
	private LabelsDao labelsDao;
	private VariantDao variantDao;

	public TranslationResource(SoftwareDao swDao, LabelsDao labelsDao, VariantDao variantDao) {
		this.swDao = swDao;
		this.labelsDao = labelsDao;
		this.variantDao = variantDao;
	}

	@GET
	@Timed
	@Path("translations.{lang}.json")
	public Map<String, Object> getTranslations(
			@PathParam("lang") String lang,
			@NotNull @NotEmpty @QueryParam("software") List<String> software,
			@QueryParam("fallback") String fallBackLang) {

		HashSet<LabelOut> res = new HashSet<LabelOut>();

		software.forEach(swId -> {
			String parentSwId = this.swDao.getParentId(swId);
			if (parentSwId != null) {
				res.addAll(SharedResource.mergeVariants(parentSwId, swId, lang, labelsDao, variantDao, false));
			} else {
				res.addAll(SharedResource.mergeLanguages(swId, lang, fallBackLang, labelsDao, false));
			}
		});

		Map<String, Object> json = new HashMap<String, Object>();
		res.forEach(el -> {
			SharedResource.jsonBuilder(el.getId(), el.getValue(), json);
		});

		return json;
	}

}
