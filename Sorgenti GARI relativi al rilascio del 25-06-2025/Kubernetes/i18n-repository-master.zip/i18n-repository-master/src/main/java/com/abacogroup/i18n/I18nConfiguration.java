package com.abacogroup.i18n;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.dropwizard.core.Configuration;
import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.db.DataSourceFactory;

public class I18nConfiguration extends Configuration {
	@Valid
	@NotNull
	private DataSourceFactory database = new DataSourceFactory();

	@NotEmpty
	private String workdir;

	@NotEmpty
	private String dbName;

	@NotEmpty
	private String backupsDir;

	@NotEmpty
	private String sso2Url;

	@Valid
	@NotNull
	private JerseyClientConfiguration sso2Client;

	@NotNull
	@JsonProperty("isCors")
	private Boolean isCors;

	@JsonProperty("database")
	public void setDataSourceFactory(DataSourceFactory factory) {
		this.database = factory;
	}

	@JsonProperty("database")
	public DataSourceFactory getDataSourceFactory() {
		return database;
	}

	@JsonProperty
	public String getDbName() {
		return dbName;
	}

	@JsonProperty
	public String getWorkdir() {
		return workdir;
	}

	@JsonProperty
	public String getBackupsDir() {
		return backupsDir;
	}

	public String getSso2Url() {
		return sso2Url;
	}

	public JerseyClientConfiguration getSso2Client() {
		return sso2Client;
	}

	public Boolean getCors() {
		return isCors;
	}
}
