package com.abacogroup.i18n.tasks;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.abacogroup.i18n.api.Label;
import com.abacogroup.i18n.api.LabelOut;
import com.abacogroup.i18n.api.Language;
import com.abacogroup.i18n.api.Software;
import com.abacogroup.i18n.db.LabelsDao;
import com.abacogroup.i18n.db.LanguageDao;
import com.abacogroup.i18n.db.SoftwareDao;
import com.abacogroup.i18n.db.VariantDao;
import com.abacogroup.i18n.resources.SharedResource;
import com.codahale.metrics.annotation.Timed;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.dropwizard.servlets.tasks.Task;

public class BackupDbTask extends Task
{

	private SoftwareDao swDao;
	private LabelsDao labelsDao;
	private LanguageDao langDao;
	private VariantDao variantDao;
	private String workDir;

	public BackupDbTask(SoftwareDao swDao, LabelsDao labelsDao, LanguageDao langDao, VariantDao variantDao, String workDir)
	{
		super("backup.zip");
		this.swDao = swDao;
		this.labelsDao = labelsDao;
		this.langDao = langDao;
		this.variantDao = variantDao;
		this.workDir = workDir;
	}

	@Timed
	@Override
	public void execute(Map<String, List<String>> parameters, PrintWriter output)
	{
		try
		{
			java.nio.file.Path bckFiles = createBackupFiles(output);
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss");
			LocalDateTime now = LocalDateTime.now();

			String fileName = dtf.format(now) + "-backup.zip";

			File directory = new File(this.workDir);
			if (!directory.exists())
			{
				directory.mkdir();
			}

			File backupFile = new File(this.workDir, fileName);

			FileOutputStream fos = new FileOutputStream(backupFile);
			ZipOutputStream zipOut = new ZipOutputStream(fos);

			zipFile(bckFiles.toFile(), "backup", zipOut);

			zipOut.close();
			fos.close();

			output.write("saved backup in " + backupFile.toString() + "\n");
			output.flush();
			return;

		}
		catch (IOException e)
		{
			e.printStackTrace();
		}

		output.write("Something went wrong \n");
		output.flush();
	}

	private void writeToFile(Object content, java.nio.file.Path path, String filename)
			throws IOException
	{
		ObjectMapper mapper = new ObjectMapper();

		java.nio.file.Path file = Paths.get(path.toString(), filename);
		mapper.writeValue(file.toFile(), content);
	}

	private java.nio.file.Path createBackupFiles(PrintWriter output) throws IOException
	{
		List<Language> languages = this.langDao.getLanguagesWithDescr();
		List<Software> software = this.swDao.getSoftware();
		List<Label> labelList = this.labelsDao.getLabelList();
		java.nio.file.Path tempDir = null;

		tempDir = Files.createTempDirectory("backup");

		String swId;
		String parentId;
		String curLang;
		Collection<LabelOut> labels;
		String fileName = null;
		for (Software sw : software)
		{
			try
			{
				swId = sw.getId();
				parentId = this.swDao.getParentId(sw.getId());
				for (Language lang : languages)
				{
					curLang = lang.getLang();
					if (parentId == null)
					{
						labels = this.labelsDao.getLabels(swId, curLang);
						fileName = swId + "." + curLang + ".json";
					}
					else
					{
						labels = this.variantDao.getLabelsVariants(swId, curLang);
						fileName = parentId + "." + swId + "." + curLang + ".json";
					}
					Map<String, Object> json = new HashMap<String, Object>();
					labels.forEach(label -> {
						SharedResource.jsonBuilder(label.getId(), label.getValue(), json);
					});
					this.writeToFile(json, tempDir, fileName);
				}

			}
			catch (Exception e)
			{
				e.printStackTrace();
				output.write("Software " + sw.getId() + " contains error. Skipping it!\n");
			}
		}

		this.writeToFile(languages, tempDir, "languages.json");
		this.writeToFile(software, tempDir, "software.json");

		Map<String, Object> jsonLabel = new HashMap<String, Object>();
		labelList.forEach(label -> {
			SharedResource.jsonBuilder(label.getId(), label.getDescr(), jsonLabel);
		});
		this.writeToFile(jsonLabel, tempDir, "labels.json");

		return tempDir;
	}


	public static void zipFile(File fileToZip, String fileName, ZipOutputStream zipOut)
	{
		FileInputStream fis = null;
		try
		{
			if (fileToZip.isHidden())
			{
				return;
			}
			if (fileToZip.isDirectory())
			{
				if (fileName.endsWith("/"))
				{
					zipOut.putNextEntry(new ZipEntry(fileName));
					zipOut.closeEntry();
				}
				else
				{
					zipOut.putNextEntry(new ZipEntry(fileName + "/"));
					zipOut.closeEntry();
				}
				File[] children = fileToZip.listFiles();
				for (File childFile : children)
				{
					zipFile(childFile, fileName + "/" + childFile.getName(), zipOut);
				}
				return;
			}
			fis = new FileInputStream(fileToZip);
			ZipEntry zipEntry = new ZipEntry(fileName);
			zipOut.putNextEntry(zipEntry);
			byte[] bytes = new byte[1024];
			int length;
			while ((length = fis.read(bytes)) >= 0)
			{
				zipOut.write(bytes, 0, length);
			}

		}
		catch (IOException e)
		{
			throw new RuntimeException(e);
		}
		finally
		{
			if (fis != null)
			{
				try
				{
					fis.close();
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
			}
		}
	}


}
