package com.abacogroup.i18n.resources;

import java.util.List;

import javax.annotation.security.PermitAll;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response.Status;

import com.abacogroup.i18n.api.Language;
import com.abacogroup.i18n.db.LanguageDao;
import com.codahale.metrics.annotation.Timed;

@PermitAll
@Path("/admin/languages")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class LanguagesResource {

	private LanguageDao langDao;
	
	public LanguagesResource(LanguageDao langDao) {
		this.langDao = langDao;
	}

	@GET
	@Timed
	public List<String> getLanguages() {
		return this.langDao.getLanguages();
	}
	
	@POST
	@Timed
	public Boolean createLanguage(@Valid @NotNull Language newLang) {
		String lang = newLang.getLang();
		if(this.langDao.getLanguages().contains(lang)) {
			final String msg = String.format("Language %s already present.", lang);
	        throw new WebApplicationException(msg, Status.CONFLICT);
		}
		return this.langDao.createLanguage(lang, newLang.getDescr()) == 1;
	}
}
