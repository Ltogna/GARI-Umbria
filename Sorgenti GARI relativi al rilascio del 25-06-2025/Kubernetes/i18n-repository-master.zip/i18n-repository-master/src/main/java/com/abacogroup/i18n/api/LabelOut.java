package com.abacogroup.i18n.api;

import java.util.List;

import org.jdbi.v3.core.mapper.reflect.ColumnName;

public class LabelOut {
	
	private String id;
	private String value;
	private String type;
	private List<String> softwareIds;
	
	public LabelOut() {
	}
	
	public LabelOut(String id, String value) {
		this.id = id;
		this.value = value;
	}
	
	public LabelOut(String id, String value, String type) {
		this(id, value);
		this.type = type;
	}

	@ColumnName("label_id")
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	@ColumnName("val")
	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<String> getSoftwareIds()
	{
		return softwareIds;
	}

	public void setSoftwareId(List<String> softwareIds)
	{
		this.softwareIds = softwareIds;
	}

	@Override
	public int hashCode() {
	      return this.id.hashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null || getClass() != obj.getClass()){
			return false;
		}
		LabelOut label = (LabelOut) obj;
		return this.id.equals(label.getId());
	}
	
}
