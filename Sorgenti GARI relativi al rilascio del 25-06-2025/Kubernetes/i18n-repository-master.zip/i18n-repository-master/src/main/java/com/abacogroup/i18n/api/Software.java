package com.abacogroup.i18n.api;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.jdbi.v3.core.mapper.reflect.ColumnName;

public class Software {
	
	@NotEmpty 
	@NotNull
	private String id;
	
	@NotEmpty 
	@NotNull
	private String descr;
	
	private String parentId;
	
	public Software() {
	}

	public Software(String id, String descr, String parentId) {
		this.id = id;
		this.descr = descr;
		this.parentId = parentId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescr() {
		return descr;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}

	@ColumnName("parent_id")
	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	
	@Override
	public String toString() {
		String base = "\"id\": \"" + id.toString() + "\", " + "\"descr\": \"" + descr.toString() + "\"";
		if(parentId != null) {
			return "{" + base + "," + "\"parent_id\": \"" + parentId.toString() + "\"}";
		}
		return "{" + base + "}";
	}
	
}
