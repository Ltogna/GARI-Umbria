package com.abacogroup.i18n.api;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class LabelIn extends Label{
	
	@Valid 
	@NotNull
	@Size(min = 1)
	private List<LabelValue> values;
	
	public LabelIn() {
		super();
	}
	
	public LabelIn(@Valid @NotNull Label label, List<LabelValue> values) {
		super(label);
		this.values = values;
	}
	
	public List<LabelValue> getValues() {
		return values;
	}
	
	public void setValues(List<LabelValue> values) {
		this.values = values;
	} 			
}
