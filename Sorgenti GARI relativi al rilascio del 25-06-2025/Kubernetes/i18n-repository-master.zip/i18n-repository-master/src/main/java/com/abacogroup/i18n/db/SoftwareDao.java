package com.abacogroup.i18n.db;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.i18n.api.Software;

public interface SoftwareDao extends Transactional<SoftwareDao> {
	
	///////// SELECT /////////
	
	@SqlQuery("SELECT * FROM i18n_software")
	@RegisterBeanMapper(Software.class)
	public List<Software> getSoftware();

	@SqlQuery("SELECT software_id from i18n_software_labels where label_id = :label_id")
	public List<String> getSoftwareWithLabel(@Bind("label_id") String labelId);
	
	@SqlQuery("SELECT parent_id FROM i18n_software WHERE id = :swId")
	public String getParentId(@Bind("swId") String swId);
	
	@SqlQuery("SELECT COUNT(id) > 0 FROM i18n_software WHERE id = :swId")
	public boolean isSwPresent(@Bind("swId") String swId);
	
	@SqlQuery("SELECT COUNT(label_id) > 0 FROM i18n_software_labels "
			+ "                WHERE software_id = :swId AND label_id = :labelId")
	public boolean isLabelPresent(@Bind("swId") String swId, @Bind("labelId") String labelId);
	
	@SqlQuery("SELECT software_id FROM i18n_software_labels "
			+ " WHERE label_id = :labelId")
	public List<String> getLinkedSoftware(@Bind("labelId") String labelId);
	
	///////// UPDATE /////////
	
	@SqlUpdate("UPDATE i18n_software" +
			" SET id = :id, descr = :descr, parent_id = :parentId" + 
			" WHERE id = :id")
	public int updateSoftware(
			@Bind("id") String id,
			@Bind("descr") String descr,
			@Bind("parentId") String parentId 
	);

	///////// INSERT /////////
	
	@SqlUpdate("INSERT INTO i18n_software (id, descr, parent_id) "
			+ " VALUES (:id, :descr, :parentId)")
	public int createSoftware(
			@Bind("id") String id, 
			@Bind("descr") String descr,
			@Bind("parentId") String parentId
	);

	@SqlUpdate("INSERT INTO i18n_software_labels (software_id, label_id)"
			+ " VALUES (:swId, :labelId)")
	public int linkLabel(@Bind("swId") String swId, @Bind("labelId") String labelToBeLinked);
	
	///////// DELETE /////////
	
	@SqlUpdate("DELETE FROM i18n_software_labels "
			+ " WHERE label_id = :labelId AND (software_id = :swId OR :swId is null)")
	public int deleteLabelFromSoftware(@Bind("labelId") String labelId, @Bind("swId") String swId);
	
	@SqlUpdate("DELETE FROM i18n_software_labels")
	public int deleteAllSoftwareLabels();
	
	@SqlUpdate("DELETE FROM i18n_software")
	public int deleteAllSoftware();
}
