package com.abacogroup.i18n.api;

import org.jdbi.v3.core.mapper.reflect.ColumnName;

public class Variant {
	
	private String softwareId;
	private String labelId;
	private String lang;
	private String val;
	
	public Variant() {
	}

	public Variant(String softwareId, String labelId, String lang, String val) {
		this.softwareId = softwareId;
		this.labelId = labelId;
		this.lang = lang;
		this.val = val;
	}

	@ColumnName("software_id")
	public String getSoftwareId() {
		return softwareId;
	}

	public void setSoftwareId(String softwareId) {
		this.softwareId = softwareId;
	}

	@ColumnName("label_id")
	public String getLabelId() {
		return labelId;
	}

	public void setLabelId(String labelId) {
		this.labelId = labelId;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

	public String getVal() {
		return val;
	}

	public void setVal(String val) {
		this.val = val;
	}

}
