package com.abacogroup.i18n.db;

import java.util.List;
import java.util.Set;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.i18n.api.Label;
import com.abacogroup.i18n.api.LabelOut;
import com.abacogroup.i18n.api.LabelValue;

public interface LabelsDao extends Transactional<LabelsDao> {

	///////// SELECT /////////

	@SqlQuery("SELECT l.LABEL_ID, l.VAL," +
			" (CASE WHEN (SELECT COUNT(s.ID)" +
			" FROM I18N_SOFTWARE s JOIN I18N_SOFTWARE_LABELS sl ON s.ID = sl.SOFTWARE_ID" +
			" WHERE sl.LABEL_ID = l.LABEL_ID) > 1" +
			" THEN 'shared'" +
			" ELSE NULL" +
			" END) AS type" +
			" FROM I18N_LABEL_VALUES l JOIN I18N_SOFTWARE_LABELS sl ON l.LABEL_ID = sl.LABEL_ID" +
			" WHERE sl.SOFTWARE_ID = :swId AND l.LANG = :lang" +
			" ORDER BY l.LABEL_ID")
	@RegisterBeanMapper(LabelOut.class)
	List<LabelOut> getLabels(@Bind("swId") String swId, @Bind("lang") String lang);

	@SqlQuery("SELECT l.LABEL_ID, l.VAL," +
			" NULL AS type" +
			" FROM I18N_LABEL_VALUES l JOIN I18N_SOFTWARE_LABELS sl ON l.LABEL_ID = sl.LABEL_ID" +
			" WHERE sl.SOFTWARE_ID = :swId AND l.LANG = :lang" +
			" ORDER BY l.LABEL_ID")
	@RegisterBeanMapper(LabelOut.class)
	List<LabelOut> getLabelsNoType(@Bind("swId") String swId, @Bind("lang") String lang);

	@SqlQuery("SELECT id, descr"
			+ " FROM i18n_labels"
			+ " WHERE id = :labelId")
	@RegisterBeanMapper(Label.class)
	public Label getLabel(@Bind("labelId") String labelId);

	@SqlQuery("SELECT id, descr"
			+ " FROM i18n_labels")
	@RegisterBeanMapper(Label.class)
	public List<Label> getLabelList();

	@SqlQuery("SELECT sl.label_id, '' as val"
			+ " FROM i18n_labels l JOIN I18N_SOFTWARE_LABELS sl ON l.id = sl.label_id"
			+ " Where sl.software_id = :swId"
			+ " Order By l.id")
	@RegisterBeanMapper(LabelOut.class)
	public Set<LabelOut> getLabelListPerSoftware(@Bind("swId") String swId);

	@SqlQuery("SELECT lang, val"
			+ " FROM i18n_label_values"
			+ " WHERE label_id = :labelId")
	@RegisterBeanMapper(LabelValue.class)
	List<LabelValue> getLabelValues(@Bind("labelId") String labelId);

	@SqlQuery("SELECT COUNT(id) > 0" +
			" FROM i18n_labels" +
			" WHERE id = :labelId OR (:startsWith AND id like :labelId)")
	boolean isLabelPresent(@Bind("labelId") String labelId, @Bind("startsWith") boolean startsWith);

	@SqlQuery("SELECT COUNT(label_id) > 0" +
			" FROM i18n_label_values" +
			" WHERE label_id = :labelId AND lang = :lang")
	boolean isValuePresent(@Bind("labelId") String labelId, @Bind("lang") String lang);

	@SqlQuery("SELECT l.LABEL_ID, l.VAL" +
			" FROM I18N_LABEL_VALUES l" +
			" WHERE (l.LANG = :lang OR :lang is null) AND (LOWER(l.LABEL_ID) LIKE :filter OR LOWER(l.VAL) LIKE :filter)" +
			" AND l.LABEL_ID NOT IN (SELECT sl.LABEL_ID" +
			"						 FROM I18N_SOFTWARE_LABELS sl" +
			"						 WHERE sl.SOFTWARE_ID = :excludeSw)")
	@RegisterBeanMapper(LabelOut.class)
	Set<LabelOut> searchLabels(
			@Bind("lang") String lang,
			@Bind("filter") String filter,
			@Bind("excludeSw") String excludeSw);

	@SqlQuery("SELECT l.LABEL_ID, '' as val" +
			" FROM I18N_LABEL_VALUES l" +
			" WHERE (LOWER(l.LABEL_ID) LIKE :filter)" +
			" AND l.LABEL_ID NOT IN (SELECT sl1.LABEL_ID" +
			"						 FROM I18N_SOFTWARE_LABELS sl1" +
			"						 WHERE sl1.SOFTWARE_ID = :excludeSw)")
	@RegisterBeanMapper(LabelOut.class)
	Set<LabelOut> searchLabels(
			@Bind("filter") String filter,
			@Bind("excludeSw") String excludeSw);

	@SqlQuery("SELECT l.id, l.descr"
			+ " FROM I18N_LABELS l"
			+ " WHERE l.id NOT IN (SELECT sl.label_id"
			+ "						   FROM I18N_SOFTWARE_LABELS sl)")
	@RegisterBeanMapper(Label.class)
	List<Label> getUnlinkedLabels();

	///////// INSERT /////////

	@SqlUpdate("INSERT INTO i18n_labels (id, descr)"
			+ " VALUES (:id, :descr)")
	int createLabel(@Bind("id") String labelId, @Bind("descr") String descr);

	@SqlUpdate("INSERT INTO i18n_label_values (label_id, lang, val)"
			+ "VALUES (:id, :lang, :val)")
	int insertVal(
			@Bind("id") String labelId,
			@Bind("lang") String lang,
			@Bind("val") String val);

	///////// DELETE /////////

	@SqlUpdate("DELETE FROM i18n_label_values WHERE label_id = :labelId")
	public int deleteLabelValues(@Bind("labelId") String labelId);

	@SqlUpdate("DELETE FROM i18n_labels WHERE id = :labelId")
	public int deleteLabel(@Bind("labelId") String labelId);

	@SqlUpdate("DELETE FROM i18n_labels")
	public int deleteAllLabels();

	@SqlUpdate("DELETE FROM i18n_label_values")
	public int deleteAllLabelValues();

}
