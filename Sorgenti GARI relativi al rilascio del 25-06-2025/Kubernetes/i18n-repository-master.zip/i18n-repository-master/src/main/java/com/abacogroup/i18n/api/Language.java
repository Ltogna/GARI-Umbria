package com.abacogroup.i18n.api;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class Language {
	
	@NotNull 
	@NotEmpty
	private String lang;
	
	@NotNull
	@NotEmpty
	private String descr;
	
	public Language() {
	}
	
	public Language(String lang, String descr) {
		this.lang = lang;
		this.descr = descr;
	}
	
	public String getLang() {
		return lang;
	}
	
	public void setLang(String lang) {
		this.lang = lang;
	}
	
	public String getDescr() {
		return descr;
	}
	
	public void setDescr(String descr) {
		this.descr = descr;
	}
}
