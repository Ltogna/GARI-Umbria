package com.abacogroup.i18n.db;

import java.util.List;
import java.util.Set;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.i18n.api.LabelOut;
import com.abacogroup.i18n.api.LabelValue;
import com.abacogroup.i18n.api.Variant;

public interface VariantDao extends Transactional<VariantDao> {
	
	@SqlQuery("SELECT *"
			+ " FROM i18n_variants")
	@RegisterBeanMapper(Variant.class)
	List<Variant> getVariants();
	
	@SqlQuery("SELECT COUNT(label_id) > 0" + 
			  " FROM i18n_variants" + 
			  " WHERE (software_id = :swId AND label_id = :labelId) OR (:startsWith AND (software_id = :swId AND label_id like :labelId))")
	boolean isLabelPresent(@Bind("swId") String swId, @Bind("labelId") String labelId, @Bind("startsWith") boolean startsWith);
	
	@SqlQuery("SELECT LABEL_ID, VAL" + 
			  " FROM I18N_VARIANTS" + 
			  " WHERE SOFTWARE_ID = :swId AND LANG = :lang" +
			  " ORDER BY LABEL_ID")
	@RegisterBeanMapper(LabelOut.class)
	Set<LabelOut> getLabelsVariants(@Bind("swId") String swId, @Bind("lang") String lang);
	
	@SqlQuery("SELECT LABEL_ID, '' as val" + 
			  " FROM I18N_VARIANTS" + 
			  " WHERE SOFTWARE_ID = :swId" +
			  " ORDER BY LABEL_ID")
	@RegisterBeanMapper(LabelOut.class)
	Set<LabelOut> getLabelListVariants(@Bind("swId") String swId);
	
	@SqlQuery("SELECT lang, val"
			+ " FROM i18n_variants"
			+ " WHERE software_id = :swId AND label_id = :labelId")
	@RegisterBeanMapper(LabelValue.class)
	Set<LabelValue> getVariant(@Bind("swId") String swId, @Bind("labelId") String labelId);
	
	@SqlUpdate("INSERT INTO i18n_variants (software_id, label_id, lang, val)"
			+ "VALUES (:swId, :id, :lang, :val)")
	int insertVariant(
			@Bind("swId") String swId,
			@Bind("id") String labelId, 
			@Bind("lang") String lang, 
			@Bind("val") String val);
	
	@SqlUpdate("DELETE FROM i18n_variants WHERE software_id = :swId AND label_id = :labelId")
	public int deleteVariant(@Bind("swId") String swId,@Bind("labelId") String labelId);

	@SqlUpdate("DELETE FROM i18n_variants")
	public int deleteAllVariants();	
}
