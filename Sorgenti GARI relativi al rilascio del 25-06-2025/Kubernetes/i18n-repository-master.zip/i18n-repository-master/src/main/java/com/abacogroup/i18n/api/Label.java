package com.abacogroup.i18n.api;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class Label {
	@NotNull
	@NotEmpty
	private String id;
	private String descr;

	public Label() {
	}

	public Label(@NotNull @NotEmpty String labelId, String descr) {
		this.id = labelId;
		this.descr = descr;
	}

	public Label(Label label) {
		this.id = label.id;
		this.descr = label.descr;
	}

	public String getId() {
		return id;
	}

	public void setId(String labelId) {
		this.id = labelId;
	}

	public String getDescr() {
		return descr;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}
}
