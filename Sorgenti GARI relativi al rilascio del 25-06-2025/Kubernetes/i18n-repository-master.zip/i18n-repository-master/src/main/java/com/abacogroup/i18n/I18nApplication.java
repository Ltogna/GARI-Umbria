package com.abacogroup.i18n;

import java.io.File;
import java.io.PrintWriter;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;

import javax.servlet.DispatcherType;
import javax.servlet.FilterRegistration;
import javax.ws.rs.client.WebTarget;

import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.jdbi.v3.core.Jdbi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.dropwizard.assets.FallbackAssetsBundle;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.i18n.db.LabelsDao;
import com.abacogroup.i18n.db.LanguageDao;
import com.abacogroup.i18n.db.SoftwareDao;
import com.abacogroup.i18n.db.VariantDao;
import com.abacogroup.i18n.resources.LabelResource;
import com.abacogroup.i18n.resources.LanguagesResource;
import com.abacogroup.i18n.resources.SoftwareResource;
import com.abacogroup.i18n.resources.TranslationResource;
import com.abacogroup.i18n.tasks.BackupDbTask;
import com.abacogroup.i18n.tasks.RestoreDbTask;
import com.abacogroup.tracing.dropwizard.AbacoApplication;
import com.abacogroup.tracing.jaxrs.server.MDCFilter;

import io.dropwizard.core.Application;
import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.jdbi3.JdbiFactory;
import io.dropwizard.jdbi3.bundles.JdbiExceptionsBundle;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;

public class I18nApplication extends AbacoApplication<I18nConfiguration> {

	private static final Logger log = LoggerFactory.getLogger(I18nApplication.class);

	public static void main(final String[] args) {
		try {
			new I18nApplication().run(args);
		} catch (Exception e) {
			log.error("Error during run i18n application: ", e);
		}
	}

	@Override
	public String getName() {
		return "i18n";
	}

	@Override
	public void initialize(final Bootstrap<I18nConfiguration> bootstrap) {
		bootstrap.addBundle(new JdbiExceptionsBundle());
		bootstrap.addBundle(new FallbackAssetsBundle("/assets/", "/client/", "index.html", "/assets/index.html", "frontend"));

		SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
				new EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);
	}

	@Override
	public void doRun(final I18nConfiguration config, final Environment environment) {

		final Jdbi jdbi = this.initDb(config, environment);

		SoftwareDao swDao = jdbi.onDemand(SoftwareDao.class);
		LabelsDao labelsDao = jdbi.onDemand(LabelsDao.class);
		LanguageDao langDao = jdbi.onDemand(LanguageDao.class);
		VariantDao variantDao = jdbi.onDemand(VariantDao.class);

		RestoreDbTask restoreTask = new RestoreDbTask(swDao, labelsDao, langDao, variantDao, config.getWorkdir());
		restoreTask.execute(new HashMap<String, List<String>>(), new PrintWriter(System.out));

		WebTarget sso2Target = new JerseyClientBuilder(environment).using(config.getSso2Client())
				.build(getName()).target(config.getSso2Url());
		
		Sso2Client sso2Client = new Sso2Client(sso2Target);

		AuthUtils.installAuthFilter(environment, sso2Client);

		environment.jersey().register(new SoftwareResource(swDao, labelsDao, variantDao));
		environment.jersey().register(new LanguagesResource(langDao));
		environment.jersey().register(new LabelResource(swDao, labelsDao, variantDao));
		environment.jersey().register(new TranslationResource(swDao, labelsDao, variantDao));
		environment.jersey().register(new MDCFilter());

		environment.admin().addTask(restoreTask);
		environment.admin().addTask(new BackupDbTask(swDao, labelsDao, langDao, variantDao, config.getBackupsDir()));
		setupCORS(config, environment);
	}

	private Jdbi initDb(final I18nConfiguration config, Environment environment) {

		File dbFile = new File(config.getWorkdir(), config.getDbName() + ".mv.db");

		boolean dbFileExtists = dbFile.exists();

		final JdbiFactory factory = new JdbiFactory();
		final Jdbi jdbi = factory.build(environment, config.getDataSourceFactory(), config.getDbName());

		if (!dbFileExtists) {
			try {
				jdbi.useTransaction(h -> {
					String sqlScript = "";
					File sqlFile = new File("db-scripts/createDb.sql");
					if (sqlFile.exists()) {
						sqlScript = new String(Files.readAllBytes(Paths.get("db-scripts/createDb.sql")));
					} else {
						URI uri = I18nApplication.class.getClassLoader().getResource("db-scripts/createDb.sql").toURI();
						sqlScript = new String(Files.readAllBytes(Paths.get(uri)));
					}
					h.createScript(sqlScript).execute();
				});
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}

		return jdbi;
	}

	private void setupCORS(I18nConfiguration config, Environment environment) {
		if (!config.getCors()) {
			return;
		}

		FilterRegistration.Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET");

		// Add URL mapping
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

}
