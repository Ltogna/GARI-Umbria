package com.abacogroup.i18n.resources;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.security.PermitAll;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response.Status;

import com.abacogroup.i18n.api.Label;
import com.abacogroup.i18n.api.LabelIn;
import com.abacogroup.i18n.api.LabelOut;
import com.abacogroup.i18n.api.LabelValue;
import com.abacogroup.i18n.db.LabelsDao;
import com.abacogroup.i18n.db.SoftwareDao;
import com.abacogroup.i18n.db.VariantDao;
import com.codahale.metrics.annotation.Timed;

@PermitAll
@Path("/admin/labels")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class LabelResource {

	private SoftwareDao swDao;
	private LabelsDao labelsDao;
	private VariantDao variantDao;

	public LabelResource(SoftwareDao swDao, LabelsDao labelsDao, VariantDao variantDao) {
		this.swDao = swDao;
		this.labelsDao = labelsDao;
		this.variantDao = variantDao;
	}

	@GET
	@Timed
	@Path("{lang}")
	public Set<LabelOut> searchLabels(
			@PathParam("lang") String lang,
			@NotNull @NotEmpty @QueryParam("filter") String filter,
			@NotNull @NotEmpty @QueryParam("exclude_sw") String excludeSw) {
		String parentSwId = this.swDao.getParentId(excludeSw);
		if (parentSwId != null) {
			excludeSw = parentSwId;
		}
		String search = "%" + filter.toLowerCase() + "%";
		HashSet<LabelOut> partialRes = new HashSet<>(this.labelsDao.searchLabels(lang, search, excludeSw));
		partialRes.addAll(this.labelsDao.searchLabels(search, excludeSw));
		partialRes.stream().forEach(label -> label.setSoftwareId(this.swDao.getSoftwareWithLabel(label.getId())));
		return partialRes;
	}

	@GET
	@Timed
	@Path("values/{id}")
	public LabelIn getLabel(@PathParam("id") String labelId, @QueryParam("swId") @NotEmpty @NotNull String swId) {
		String parentId = this.swDao.getParentId(swId);
		Label label = this.labelsDao.getLabel(labelId);
		List<LabelValue> values = this.labelsDao.getLabelValues(labelId);
		Set<LabelValue> variants = new HashSet<LabelValue>();
		if(parentId != null) {
			variants = this.variantDao.getVariant(swId, labelId);
			variants.addAll(values);
			if(label == null) {
				label = new Label(labelId, "");
			}
			return new LabelIn(label, new ArrayList<LabelValue>(variants));
		}
		return new LabelIn(label, values);
	}

	@POST
	@Timed
	public boolean createLabel(@Valid @NotNull LabelIn newLabel, @QueryParam("swId") @NotEmpty @NotNull String swId) {
		
			String parentId = this.swDao.getParentId(swId);
			String labelId = newLabel.getId().toLowerCase();
			
			if(parentId == null ? SharedResource.isLabelAlreadyPresent(labelId, labelsDao) : SharedResource.isVariantAlreadyPresent(labelId, swId, variantDao)) {
				final String msg = String.format("Label %s already present.", labelId);
				throw new WebApplicationException(msg, Status.CONFLICT);
			}

			String descr = newLabel.getDescr();
			
			if(!SharedResource.isAcceptableLabel(labelId)) {
				final String msg = String.format("Label %s is not a valid label id.", labelId);
				throw new WebApplicationException(msg, Status.BAD_REQUEST);
			}
			if(parentId == null) {				
				this.labelsDao.createLabel(labelId, descr);
			}

			List<LabelValue> labelValues = newLabel.getValues();

			for (LabelValue labelValue : labelValues) {
				if (parentId != null) {
					this.variantDao.insertVariant(swId, labelId, labelValue.getLang(), labelValue.getVal());
				} else {
					this.labelsDao.insertVal(labelId, labelValue.getLang(), labelValue.getVal());
				}
			}

			if (parentId == null) {
				this.swDao.linkLabel(swId, labelId);
			}


		return true;
	}

	@PUT
	@Timed
	@Path("{id}")
	public boolean updateLabel(@PathParam("id") String oldLabelId, @QueryParam("swId") String swId,
			@Valid @NotNull LabelIn updatedLabel) {

		if (!insertIfParentIdExist(oldLabelId, swId, updatedLabel)) {
			String updatedLabelId = updatedLabel.getId();

			List<String> linkedSw = this.swDao.getLinkedSoftware(oldLabelId);

			this.swDao.useTransaction(tnx -> {
				tnx.deleteLabelFromSoftware(oldLabelId, null);
				this.labelsDao.deleteLabelValues(oldLabelId);
				this.labelsDao.deleteLabel(oldLabelId);

				boolean created = this.createLabel(updatedLabel, swId);

				if (!created) {
					final String msg = String.format("Label %s not updated.", updatedLabelId);
					throw new WebApplicationException(msg, Status.EXPECTATION_FAILED);
				}

				int linkedLabels = insertLabelsAndCountLinkedLabel(oldLabelId, swId, updatedLabel, linkedSw);

				if (linkedLabels > 0) {
					final String msg = String.format("Label %s not updated.", updatedLabelId);
					throw new WebApplicationException(msg, Status.EXPECTATION_FAILED);
				}
			});
		}

		return true;
	}

	private int insertLabelsAndCountLinkedLabel(String oldLabelId, String swId, LabelIn updatedLabel, List<String> linkedSw) {
		int linkedLabels = 0;
		if (linkedSw.size() > 1) {
			// recreate the old label if the newly one has a different label_id
			insertLabelAndLabelValue(oldLabelId, updatedLabel);

			// re link the newly created label to the previous linked sw, keeping the old Label id.
			// This way if the label id has been edited too, the label id will be updated only in the current software,
			// while the value will be update in all the linked sw.
			linkedLabels = linkedSw.size() - 1;
			for (String curSwId : linkedSw) {
				if (!swId.equals(curSwId)) {
					linkedLabels -= this.swDao.linkLabel(curSwId, oldLabelId);
				}
			}
		}
		return linkedLabels;
	}

	private boolean insertIfParentIdExist(String oldLabelId, String swId, LabelIn updatedLabel) {
		boolean result = false;

		String parentId = this.swDao.getParentId(swId);
		if (parentId != null) {
			this.variantDao.useTransaction(tnx -> {
				tnx.deleteVariant(swId, oldLabelId);
				this.createLabel(updatedLabel, swId);
			});
			result = true;
		}
		return result;
	}

	private void insertLabelAndLabelValue(String oldLabelId, LabelIn updatedLabel) {
		boolean created;
		if(!oldLabelId.equals(updatedLabel.getId())) {					
			created = this.labelsDao.createLabel(oldLabelId, updatedLabel.getDescr()) == 1;
			List<LabelValue> labelValues = updatedLabel.getValues();
			int labelValuesInserted = labelValues.size();
			for (LabelValue labelValue : labelValues) {
				labelValuesInserted -= this.labelsDao.insertVal(oldLabelId, labelValue.getLang(), labelValue.getVal());
			}
			if (!created || labelValuesInserted > 0) {
				final String msg = String.format("Label %s not updated.", updatedLabel.getId());
				throw new WebApplicationException(msg, Status.EXPECTATION_FAILED);
			}
		}
	}
	
	@GET
	@Timed
	@Path("unlinked")
	public List<Label> getUnlinkedLabels() {
		return this.labelsDao.getUnlinkedLabels();
	}
	
	@DELETE
	@Timed
	@Path("{id}")
	public Boolean deleteLabel(@PathParam("id") String labelId) {
		int[] deleted = {0,0};
		this.labelsDao.useTransaction(tnx -> {
			deleted[0] += tnx.deleteLabelValues(labelId);
			deleted[1] += tnx.deleteLabel(labelId);;
		});
		
		return deleted[0] > 0 && deleted[1] > 0;
	}
}
