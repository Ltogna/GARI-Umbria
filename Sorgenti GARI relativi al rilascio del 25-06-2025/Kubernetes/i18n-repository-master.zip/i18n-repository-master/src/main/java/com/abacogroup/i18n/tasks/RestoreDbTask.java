package com.abacogroup.i18n.tasks;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import com.abacogroup.i18n.api.Language;
import com.abacogroup.i18n.api.Software;
import com.abacogroup.i18n.db.LabelsDao;
import com.abacogroup.i18n.db.LanguageDao;
import com.abacogroup.i18n.db.SoftwareDao;
import com.abacogroup.i18n.db.VariantDao;
import com.abacogroup.i18n.resources.SharedResource;
import com.codahale.metrics.annotation.Timed;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.dropwizard.servlets.tasks.Task;

public class RestoreDbTask extends Task {

	private SoftwareDao swDao;
	private LabelsDao labelsDao;
	private LanguageDao langDao;
	private VariantDao variantDao;
	private String workDir;

	public RestoreDbTask(SoftwareDao swDao, LabelsDao labelsDao, LanguageDao langDao, VariantDao variantDao,
			String workDir) {
		super("restore");
		this.swDao = swDao;
		this.labelsDao = labelsDao;
		this.langDao = langDao;
		this.variantDao = variantDao;
		this.workDir = workDir;
	}

	@Timed
	@Override
	public void execute(Map<String, List<String>> parameters, PrintWriter output) {
		try {
			Boolean incremental = parameters.containsKey("type") && parameters.get("type").contains("incremental");
			File zippedFile = new File(this.workDir, "backup.zip");
			if (!zippedFile.exists()) {
				output.write("No backup file found, continuing without restoring \n");
				output.flush();
				return;
			}
			this.swDao.useTransaction(swDao -> {

				java.nio.file.Path destDir = null;

				destDir = Files.createTempDirectory("backup");

				unzipFile(zippedFile, destDir.toFile());

				if (!incremental) {
					// delete the current db
					this.variantDao.deleteAllVariants();
					this.swDao.deleteAllSoftwareLabels();
					this.labelsDao.deleteAllLabelValues();
					this.langDao.deleteAllLanguages();
					this.swDao.deleteAllSoftware();
					this.labelsDao.deleteAllLabels();
				}

				// restore db from backup files
				File backupDir = Paths.get(destDir.toString(), "backup").toFile();

				File[] bckFiles = backupDir.listFiles();

				restoreFromFiles(bckFiles, incremental);

				zippedFile.renameTo(new File(this.workDir, "backup.done"));
				output.write("Restore done \n");
				output.flush();

			});
		} catch (Exception e) {
			e.printStackTrace();
			output.write(e.getMessage());
			output.write("\n");
			output.flush();
			throw new RuntimeException(e);
		}

	}

	private void restoreFromFiles(File[] bckFiles, Boolean incremental)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		LinkedList<File> sortedFiles = new LinkedList<File>();

		for (File bckFile : bckFiles) {
			String fileName = bckFile.getName();
			String[] args = fileName.split("\\.");
			if (args.length > 2) {
				sortedFiles.add(bckFile);
			} else {
				sortedFiles.addFirst(bckFile);
			}

		}

		for (File bckFile : sortedFiles) {
			String fileName = bckFile.getName();
			System.out.println(fileName);
			switch (fileName) {
			case "languages.json":
				createLanguage(incremental, mapper, bckFile);
				break;

			case "software.json":
				createSoftware(incremental, mapper, bckFile);
				break;

			case "labels.json":
				createLabels(incremental, mapper, bckFile);
				break;

			default:
				createOtherFiles(mapper, bckFile, fileName);
				break;
			}
		}

	}

	private void createOtherFiles(ObjectMapper mapper, File bckFile, String fileName) throws IOException, StreamReadException, DatabindException {
		// ?{parentSw}.{software}.{lang}.json
		String[] args = fileName.split("\\.");
		if (args.length > 4 || (args.length == 4 && !"json".equals(args[3]))
				|| (args.length == 3 && !"json".equals(args[2]))) {
			throw new IllegalArgumentException("Cannot use file " + fileName + " to restore db");
		}

		HashMap<String, Object> json = mapper.readValue(bckFile, new TypeReference<HashMap<String, Object>>() {
		});
		HashMap<String, String> extractedValues = new HashMap<String, String>();

		json.forEach((String key, Object value) -> {
			SharedResource.jsonExtractor(key, value, extractedValues);
		});

		if (args.length != 4) {
			extractedValues.forEach((String key, String value) -> {
				if (!this.labelsDao.isValuePresent(key, args[1])) {
					this.labelsDao.insertVal(key, args[1], value);
				}
				if (!this.swDao.isLabelPresent(args[0], key)) {
					this.swDao.linkLabel(args[0], key);
				}
			});
		} else {
			extractedValues.forEach((String key, String value) -> {
				this.variantDao.insertVariant(args[1], key, args[2], value);
			});
		}
	}

	private void createLabels(Boolean incremental, ObjectMapper mapper, File bckFile) throws IOException, StreamReadException, DatabindException {
		HashMap<String, Object> json = mapper.readValue(bckFile, new TypeReference<HashMap<String, Object>>() {
		});
		HashMap<String, String> extractedValues = new HashMap<String, String>();

		json.forEach((String labelId, Object descr) -> {
			SharedResource.jsonExtractor(labelId, descr, extractedValues);
		});

		extractedValues.forEach((String labelId, String descr) -> {
			Boolean present = SharedResource.isLabelAlreadyPresent(labelId, labelsDao);
			if(!SharedResource.isAcceptableLabel(labelId)){
				throw new RuntimeException(String.format("Malformatted json file labels.json: label %s is not a an acceptable labelId", labelId));
			}
			if (!present) {
				this.labelsDao.createLabel(labelId, descr);
			} else if (!incremental) {
				throw new RuntimeException(String
						.format("Malformatted json file labels.json: label %s is not a json Object", labelId));
			}
		});
	}

	private void createSoftware(Boolean incremental, ObjectMapper mapper, File bckFile) throws IOException, StreamReadException, DatabindException {
		List<Software> software = mapper.readValue(bckFile, new TypeReference<List<Software>>() {
		});
		software.forEach(sw -> {
			if (!incremental || !this.swDao.isSwPresent(sw.getId())) {
				this.swDao.createSoftware(sw.getId(), sw.getDescr(), sw.getParentId());
			}
		});
	}

	private void createLanguage(Boolean incremental, ObjectMapper mapper, File bckFile) throws IOException, StreamReadException, DatabindException {
		List<Language> languages = mapper.readValue(bckFile, new TypeReference<List<Language>>() {
		});
		languages.forEach(lang -> {
			if (!incremental || !this.langDao.getLanguages().contains(lang.getLang())) {
				this.langDao.createLanguage(lang.getLang(), lang.getDescr());
			}
		});
	}

	protected static void unzipFile(File zipFile, File destFile) {

		ZipInputStream zis = null;
		ZipEntry zipEntry = null;

		try {
			zis = new ZipInputStream(new FileInputStream(zipFile));
			zipEntry = zis.getNextEntry();

			while (zipEntry != null) {

				File newFile = newFile(destFile, zipEntry);

				if (zipEntry.isDirectory()) {
					newFile.mkdirs();
				} else {
					newFile.getParentFile().mkdirs();

					try (BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(newFile))) {

						int bufferSize = Math.toIntExact(zipEntry.getSize());
						byte[] buffer = new byte[bufferSize > 0 ? bufferSize : 1];
						int location;

						while ((location = zis.read(buffer)) != -1) {
							bos.write(buffer, 0, location);
						}
					}
				}
				zipEntry = zis.getNextEntry();
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			if (zis != null) {
				try {
					zis.closeEntry();
					zis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
		}

	}

	private static File newFile(File destinationDir, ZipEntry zipEntry) throws IOException {
		File destFile = new File(destinationDir, zipEntry.getName());

		String destDirPath = destinationDir.getCanonicalPath();
		String destFilePath = destFile.getCanonicalPath();

		if (!destFilePath.startsWith(destDirPath + File.separator)) {
			throw new IOException("Entry is outside of the target dir: " + zipEntry.getName());
		}

		return destFile;
	}

}
