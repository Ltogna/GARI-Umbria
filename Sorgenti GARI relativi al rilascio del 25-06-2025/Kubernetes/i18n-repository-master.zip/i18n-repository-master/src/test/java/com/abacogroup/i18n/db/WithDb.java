package com.abacogroup.i18n.db;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.jdbi.v3.core.Jdbi;
import org.junit.AfterClass;
import org.junit.BeforeClass;

import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.jdbi3.JdbiFactory;
import io.dropwizard.core.setup.Environment;

public class WithDb {

	protected static Jdbi jdbi = null;
	
	protected static SoftwareDao swDao = null;
	protected static LabelsDao labelsDao = null;
	protected static LanguageDao langDao = null;
	protected static VariantDao variantDao = null;

	@BeforeClass
	public static void setup() throws URISyntaxException{
		Environment env = new Environment("test-env");
		final JdbiFactory factory = new JdbiFactory();
		jdbi = factory.build(env, getDataSourceFactory(), "test");
		URI uri = WithDb.class.getClassLoader().getResource("./db-scripts/createDb.sql").toURI();
		executeDbScript(Paths.get(uri).toString());
		
		swDao = jdbi.onDemand(SoftwareDao.class);
		labelsDao = jdbi.onDemand(LabelsDao.class);
		langDao = jdbi.onDemand(LanguageDao.class);
		variantDao = jdbi.onDemand(VariantDao.class);
	}

	private static DataSourceFactory getDataSourceFactory() {
		DataSourceFactory dataSourceFactory = new DataSourceFactory();
		dataSourceFactory.setDriverClass("org.h2.Driver");
		dataSourceFactory.setUrl("jdbc:h2:mem:testDb");
		dataSourceFactory.setUser("sa");
		dataSourceFactory.setPassword("sa");
		return dataSourceFactory;
	}
	
	protected void cleanUpDb() {
		swDao.useTransaction(tnx -> {
			tnx.deleteAllSoftwareLabels();
			labelsDao.deleteAllLabelValues();
			langDao.deleteAllLanguages();
			tnx.deleteAllSoftware();
			labelsDao.deleteAllLabels();
		});
	}

	protected static void executeDbScript(String pathToScript) {
		try {
			jdbi.useTransaction(h -> {
				String sqlScript = "";
				sqlScript = new String(Files.readAllBytes(Paths.get(pathToScript)));
				h.createScript(sqlScript).execute();
			});
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	@AfterClass
	public static void cancelDb() {
		jdbi.useTransaction(h -> {
			h.execute("DROP ALL OBJECTS");
		});
	}
	

}
