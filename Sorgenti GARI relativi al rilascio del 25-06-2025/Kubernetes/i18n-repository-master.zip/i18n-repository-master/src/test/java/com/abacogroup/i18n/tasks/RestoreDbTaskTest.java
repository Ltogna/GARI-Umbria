package com.abacogroup.i18n.tasks;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.zip.ZipOutputStream;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.abacogroup.i18n.api.Label;
import com.abacogroup.i18n.api.LabelOut;
import com.abacogroup.i18n.api.Language;
import com.abacogroup.i18n.api.Software;
import com.abacogroup.i18n.db.WithDb;

public class RestoreDbTaskTest extends WithDb {
	
	private static RestoreDbTask restoreTask = null;
	private static Path tempDir = null;
	private static HashMap<String, Language> expectedLanguages = new HashMap<String, Language>();
	private static HashMap<String, Label> expectedLabels = new HashMap<String, Label>();
	private static HashMap<String, Software> expectedSoftware = new HashMap<String, Software>();
	private static HashMap<String, LabelOut> expectedLabelValues = new HashMap<String, LabelOut>();
	
	@BeforeClass
	public static void setUp() throws IOException {
		tempDir = Files.createTempDirectory("zip");
		restoreTask = new RestoreDbTask(swDao, labelsDao, langDao, variantDao, tempDir.toString());	
		
		expectedLanguages.put("en", new Language("en", "english language"));

		expectedLabels.put("name", new Label("name", "test label"));
		expectedLabels.put("person.surname", new Label("person.surname", "test label"));

		expectedSoftware.put("test-1", new Software("test-1", "test software", null));

		expectedLabelValues.put("name", new LabelOut("name", "name"));
		expectedLabelValues.put("person.surname", new LabelOut("person.surname", "surname"));
	}
	
	@Before
	public void cleanUp() {
		cleanUpDb();
	}
	
	@Test
	public void restoreDbTest() throws IOException {
		File tempFile = new File(tempDir.toString(), "backup.zip");
		FileOutputStream fos = new FileOutputStream(tempFile);
		ZipOutputStream zipOut = new ZipOutputStream(fos);

		File bckDir = new File(RestoreDbTaskTest.class.getClassLoader().getResource("./bckFiles").getFile());	
		BackupDbTask.zipFile(bckDir, "backup", zipOut);

		zipOut.close();
		fos.close();

		restoreTask.execute(new HashMap<String, List<String>>(), new PrintWriter(System.out));

		List<Language> languages = langDao.getLanguagesWithDescr();
		assertEquals("Languages size should be restored", expectedLanguages.size(), languages.size());
		languages.forEach(lang -> {
			assertEquals("Language id should be restored", expectedLanguages.get(lang.getLang()).getLang(),
					lang.getLang());
			assertEquals("Language descr should be restored", expectedLanguages.get(lang.getLang()).getDescr(),
					lang.getDescr());
		});

		List<Label> labels = labelsDao.getLabelList();
		assertEquals("Labels size should be restored", expectedLabels.size(), labels.size());
		labels.forEach(label -> {
			assertEquals("Label id should be restored", expectedLabels.get(label.getId()).getId(), label.getId());
			assertEquals("Label descr should be restored", expectedLabels.get(label.getId()).getDescr(),
					label.getDescr());
		});

		List<Software> software = swDao.getSoftware();
		assertEquals("Software size should be restored", expectedSoftware.size(), software.size());
		software.forEach(sw -> {
			assertEquals("Software id should be restored", expectedSoftware.get(sw.getId()).getId(), sw.getId());
			assertEquals("Software descr should be restored", expectedSoftware.get(sw.getId()).getDescr(),
					sw.getDescr());
			assertEquals("Software parentId should be restored", expectedSoftware.get(sw.getId()).getParentId(),
					sw.getParentId());
		});

		List<LabelOut> labelValues = (labelsDao.getLabels(software.get(0).getId(), languages.get(0).getLang()));
		assertEquals("Label Values size should be restored", expectedLabelValues.size(), labelValues.size());
		labelValues.forEach(val -> {
			assertEquals("Label Values id should be restored", expectedLabelValues.get(val.getId()).getId(),
					val.getId());
			assertEquals("Label Values val should be restored", expectedLabelValues.get(val.getId()).getValue(),
					val.getValue());
		});
	}
	
	@Test(expected = RuntimeException.class)
	public void restoreWithErrorsTest() throws IOException {
		File tempFile = new File(tempDir.toString(), "backup.zip");
		FileOutputStream fos = new FileOutputStream(tempFile);
		ZipOutputStream zipOut = new ZipOutputStream(fos);

		File bckDir = new File(RestoreDbTaskTest.class.getClassLoader().getResource("./bckFilesWithError").getFile());	
		BackupDbTask.zipFile(bckDir, "backup", zipOut);

		zipOut.close();
		fos.close();
		
		restoreTask.execute(new HashMap<String, List<String>>(), new PrintWriter(System.out));
	}
	
	@Test
	public void restoreIncrementalDbTest() throws URISyntaxException, IOException {
		URI uri = RestoreDbTaskTest.class.getClassLoader().getResource("initTestDb.sql").toURI();
		executeDbScript(Paths.get(uri).toString());
		
		File bckDir = new File(RestoreDbTaskTest.class.getClassLoader().getResource("./bckFilesIncremental").getFile());
		
		File tempFile = new File(tempDir.toString(), "backup.zip");
		FileOutputStream fos = new FileOutputStream(tempFile);
		ZipOutputStream zipOut = new ZipOutputStream(fos);
		
		BackupDbTask.zipFile(bckDir, "backup", zipOut);

		zipOut.close();
		fos.close();
		
		HashMap<String, List<String>> parameters = new HashMap<String, List<String>>();
		List<String> strings = new ArrayList<String>();
		strings.add("incremental");
		parameters.put("type", strings);
		
		expectedLabels.put("newLabel", new Label("newLabel", "test for new label"));
		expectedLabelValues.put("newLabel", new LabelOut("newLabel", "newLabel"));

		restoreTask.execute(parameters, new PrintWriter(System.out));
		
		List<Language> languages = langDao.getLanguagesWithDescr();
		assertEquals("Languages size should be restored", expectedLanguages.size(), languages.size());
		languages.forEach(lang -> {
			assertEquals("Language id should be restored", expectedLanguages.get(lang.getLang()).getLang(),
					lang.getLang());
			assertEquals("Language descr should be restored", expectedLanguages.get(lang.getLang()).getDescr(),
					lang.getDescr());
		});

		List<Label> labels = labelsDao.getLabelList();
		assertEquals("Labels size should be restored", expectedLabels.size(), labels.size());
		labels.forEach(label -> {
			assertEquals("Label id should be restored", expectedLabels.get(label.getId()).getId(), label.getId());
			assertEquals("Label descr should be restored", expectedLabels.get(label.getId()).getDescr(),
					label.getDescr());
		});

		List<Software> software = swDao.getSoftware();
		assertEquals("Software size should be restored", expectedSoftware.size(), software.size());
		software.forEach(sw -> {
			assertEquals("Software id should be restored", expectedSoftware.get(sw.getId()).getId(), sw.getId());
			assertEquals("Software descr should be restored", expectedSoftware.get(sw.getId()).getDescr(),
					sw.getDescr());
			assertEquals("Software parentId should be restored", expectedSoftware.get(sw.getId()).getParentId(),
					sw.getParentId());
		});

		List<LabelOut> labelValues = (labelsDao.getLabels(software.get(0).getId(), languages.get(0).getLang()));
		assertEquals("Label Values size should be restored", expectedLabelValues.size(), labelValues.size());
		labelValues.forEach(val -> {
			assertEquals("Label Values id should be restored", expectedLabelValues.get(val.getId()).getId(),
					val.getId());
			assertEquals("Label Values val should be restored", expectedLabelValues.get(val.getId()).getValue(),
					val.getValue());
		});
	
		expectedLabelValues.remove("newLabel");
		expectedLabels.remove("newLabel");
	}
	
	// TODO add a malformatted json file --> it should throw a RunTimeException.

}
