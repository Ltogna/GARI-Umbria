package com.abacogroup.i18n.resources;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;

import com.abacogroup.i18n.api.LabelOut;
import com.abacogroup.i18n.api.Language;
import com.abacogroup.i18n.api.Software;
import com.abacogroup.i18n.db.LabelsDao;
import com.abacogroup.i18n.db.SoftwareDao;
import com.abacogroup.i18n.db.VariantDao;

public class SoftwareResourceTest {

	private static final SoftwareDao swDao = mock(SoftwareDao.class);
	private static final LabelsDao labelsDao = mock(LabelsDao.class);
	private static final VariantDao variantDao = mock(VariantDao.class);
	private static final SoftwareResource swResource = new SoftwareResource(swDao, labelsDao, variantDao);

	private final Software testSoftware = new Software("test", "test description", null);
	private final Language enLang = new Language("en", "english language");
	private final Language en_MTLang = new Language("en_MT", "maltese english language");
	private final Set<LabelOut> expectedLabels = new HashSet<LabelOut>();
	private final List<LabelOut> enLabels = new ArrayList<LabelOut>();
	private final List<LabelOut> en_MTLabels = new ArrayList<LabelOut>();

	@Test
	public void getLabelsTest() {
		for (int i = 0; i < 4; i++) {
			enLabels.add(new LabelOut("labelId" + i, "en-value-" + i));
		}
		for (int i = 0; i < 2; i++) {
			en_MTLabels.add(new LabelOut("labelId" + i, "en-mt-value-" + i));
		}
		expectedLabels.add(en_MTLabels.get(0));
		expectedLabels.add(en_MTLabels.get(1));
		expectedLabels.add(enLabels.get(2));
		expectedLabels.add(enLabels.get(3));

		when(labelsDao.getLabels(testSoftware.getId(), enLang.getLang())).thenReturn(enLabels);
		when(labelsDao.getLabels(testSoftware.getId(), en_MTLang.getLang())).thenReturn(en_MTLabels);

		assertEquals("Derived languages should inherit from base language", expectedLabels, swResource.getLabels(testSoftware.getId(), en_MTLang.getLang()));
	}

}
