package com.abacogroup.i18n.tasks;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.abacogroup.i18n.db.WithDb;

public class BackupDbTaskTest extends WithDb {

	private static HashMap<String, String> expectedFiles = new HashMap<String, String>();
	private static BackupDbTask backupTask = null;
	private static File bckDir = null;
	private static Path tempDir = null;

	@BeforeClass
	public static void setUp() throws URISyntaxException {
		URI uri = BackupDbTaskTest.class.getClassLoader().getResource("./bckFiles").toURI();
		bckDir = new File(uri);
		try {
			File[] backupFiles = bckDir.listFiles();
			for (File file : backupFiles) {
				expectedFiles.put(file.getName(), new String(Files.readAllBytes(Paths.get(file.toString()))));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Before
	public void reset() {
		this.cleanUpDb();
	}

	
	@Test
	public void backupDbTest() throws URISyntaxException {
		URI uri = BackupDbTaskTest.class.getClassLoader().getResource("initTestDb.sql").toURI();
		executeDbScript(Paths.get(uri).toString());

		try {
			tempDir = Files.createTempDirectory("zip");
			backupTask = new BackupDbTask(swDao, labelsDao, langDao, variantDao, tempDir.toString());

			backupTask.execute(new HashMap<String, List<String>>(), new PrintWriter(System.out));
			
			File[] tempFiles = tempDir.toFile().listFiles();
			File zippedFile = new File(tempFiles[0].toString());
			RestoreDbTask.unzipFile(zippedFile, tempDir.toFile());

			File backupDir = Paths.get(tempDir.toString(), "backup").toFile();
			File[] resFiles = backupDir.listFiles();
			String content = "";

			assertEquals("Should generate the correct number of files", expectedFiles.size(), resFiles.length);
			for (File file : resFiles) {
				content = new String(Files.readAllBytes(Paths.get(file.toString())));
				assertEquals("Should generate the same files", expectedFiles.get(file.getName()), content);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
