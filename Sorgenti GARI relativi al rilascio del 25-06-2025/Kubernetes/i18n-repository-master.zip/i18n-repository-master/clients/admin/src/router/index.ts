import { RouteConfig } from 'vue-router'

const routes: Array<RouteConfig> = [
    {
        path: '/',
        name: 'Home',
        redirect: "/software"
    },
    {
        path: '/software',
        name: 'Software',
        component: () => import('../views/SoftwareView.vue')
    },
    {
        path: '/:parentSw?/:curSw/labels/',
        name: 'Labels',
        props: true,
        component: () => import('../views/LabelsView.vue')
    },
    {
        path: '/trash',
        name: 'Trash',
        component: () => import('../views/TrashView.vue')
    },
    {
        path: '*',
        component: () => import('../views/ErrorPage.vue')
    }
]

export default routes
