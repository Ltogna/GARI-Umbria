<template>
    <div>
        404 Page not found
    </div>
</template>

<script lang="ts">
import {Prop, Component, Vue} from "vue-property-decorator"

@Component
export default class ErrorPage extends Vue {

}
</script>
