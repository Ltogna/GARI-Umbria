<template>
  <div class="flex flex-col h-full overflow-hidden">
    <abc-header>
      <template #left>
        <abc-tool-button @click="goBack">
          <i class="fas fa-arrow-left" />
        </abc-tool-button>
      </template>
      Unlinked Labels
    </abc-header>

    <abc-table class="pt-2 px-2" :items="unlinkedLabels" item-id="id">
      <template #headers>
        <th class="text-left" v-for="h in headers" :key="h">{{h | upCase}}</th>
        <th></th>
      </template>
      <template #items="props">
        <td>{{props.item.id}}</td>
        <td>{{props.item.descr}}</td>
        <td class="flex justify-end">
          <abc-tool-button @click="deleteLabel(props.item.id)">
            <i class="fas fa-trash-alt" />
          </abc-tool-button>
        </td>
      </template>
      <template #no-data>
        <abc-no-data-found v-if="!loading" />
        <div v-else class="flex justify-center mt-8">
          <i class="text-2xl text-secondary fas fa-spinner fa-spin" />
        </div>
      </template>
    </abc-table>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import AbcHeader from "@/components/Header.vue";
import { Label } from "../models/Label";
import {getUnlinkedLabels, deleteLabel} from "@/api/LabelApi";

@Component({
  filters: {
    upCase(val: string) {
      return val.toUpperCase();
    }
  },
  components: {
    AbcHeader
  }
})
export default class TrashView extends Vue {
  headers = ["Label", "Description"];
  goBack() {
    this.$router.push({ name: "Software" });
  }

  unlinkedLabels: Label[] = [];
  loading = false;

  async mounted(){
      this.loading = true;
      this.unlinkedLabels = await getUnlinkedLabels();
      this.loading = false;
  }

  async deleteLabel(labelId: string) {
    const result = await deleteLabel(labelId);
    if(result){
        this.unlinkedLabels = this.unlinkedLabels.filter(label => labelId !== label.id);
        this.$toasted.show("Succesfully deleted label " + labelId);
    }
  }
}
</script>
