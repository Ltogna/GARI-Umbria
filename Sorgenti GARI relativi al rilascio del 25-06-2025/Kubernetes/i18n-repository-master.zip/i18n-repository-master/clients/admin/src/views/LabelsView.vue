<template>
  <div class="h-screen overflow-hidden flex flex-col">
    <abc-header class="flex-none">
      <template #left>
        <div class="flex">
          <abc-tool-button @click="goBack">
            <i class="fas fa-arrow-left" />
          </abc-tool-button>
          <abc-input class="bg-white ml-2" placeholder="Search" right-tools v-model="search">
            <template #right>
              <span class="flex items-center">
                <i class="fas fa-search text-secondary" />
              </span>
            </template>
          </abc-input>
        </div>
      </template>

      <h1 class="text-center">
        Available Labels in
        <b>{{this.curSw}}</b>
        <br />
        <span v-if="parentSw != null" class="text-xs">
          <i>Variant of</i>
          <b>{{" " + parentSw}}</b>
        </span>
      </h1>

      <template #right>
        <language-select
          class="w-32 ml-2"
          v-model="curLang"
          :languages="languages"
          :loading="loading"
          @addLang="addLang"
        ></language-select>
      </template>
    </abc-header>

    <current-labels
      class="flex-grow mt-2 px-2 overflow-hidden"
      :_labels="labels"
      :_search="searchToLower"
      :curSw="curSw"
      :_languages="languages"
      :_curLang="curLang"
      :parentSw="parentSw"
      :loading="loading"
      @reset="reset"
      @reload="loadLabels(curSw,curLang)"
    ></current-labels>

    <div
      v-if="showOthers"
      class="flex-none h-10 text-white bg-secondary-500 flex items-center justify-center"
    >
      <h1>Labels from other software</h1>
    </div>

    <other-labels
    v-show="showOthers"
      class="h-full flex-grow mt-2 px-2 overflow-hidden"
      :search="searchToLower"
      :curSw="curSw"
      :_curLang="curLang"
      :loading="loading"
      @reload="loadLabels(curSw, curLang)"
      @show="showOthers = arguments[0]"
    ></other-labels>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from "vue-property-decorator";

import { getLabels } from "../api/SoftwareApi";
import { getLanguages, createLanguage } from "../api/LanguagesApi";

import { LabelIn } from "../models/Label";
import { Language } from "../models/Language";

import LanguageSelect from "@/components/LanguageSelect.vue";
import CurrentLabels from "@/components/CurrentLabels.vue";
import OtherLabels from "@/components/OtherLabels.vue";
import AbcHeader from "@/components/Header.vue";

@Component({
  components: {
    LanguageSelect,
    CurrentLabels,
    OtherLabels,
    AbcHeader
  }
})
export default class LabelsView extends Vue {
  @Prop() readonly curSw!: string;
  @Prop() readonly parentSw!: string;
  headers = ["Label", "Value"];

  languages: string[] = [];
  labels: LabelIn[] = [];

  curLang: string | null = null;
  showOthers = false;

  search = "";
  loading = false;

  get searchToLower() {
    return this.search.toLowerCase();
  }

  async created() {
    this.loading = true;
    this.languages = await getLanguages();
    this.curLang = this.languages.find(l => l === "en") || this.languages[0];
    if (this.curLang != null) {
      this.loadLabels(this.curSw, this.curLang);
    } else {
      this.$toasted.show("add at least a language before continuing");
    }
  }

  async loadLabels(swId: string, lang: string | null) {
    this.loading = true;
    if (lang != null) {
      this.labels = await getLabels(swId, lang)
    } else {
      this.$toasted.show("add at least a language before continuing");
    }
    this.loading = false;
  }

  goBack() {
    this.$router.push({ name: "Software" });
  }

  @Watch("curLang")
  async onChangeLang(lang: string) {
    await this.loadLabels(this.curSw, lang);
  }

  async addLang(newLang: Language) {
    const result = await createLanguage(newLang);
    if (result) {
      this.$toasted.show("Succesfully created language " + newLang.lang);
      this.languages.push(newLang.lang);
      this.curLang = newLang.lang;
    }
  }

  reset() {
    this.search = "";
  }
}
</script>
