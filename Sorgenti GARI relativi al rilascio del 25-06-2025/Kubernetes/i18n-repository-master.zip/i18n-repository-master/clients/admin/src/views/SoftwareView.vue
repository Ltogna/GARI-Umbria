<template>
  <div>
    <abc-header>
      <template #left>
        <abc-tool-button @click="goToTrash">
          <i class="fas fa-trash-alt" />
        </abc-tool-button>
      </template>
      <p>Available Software</p>
      <template #right>
        <abc-tool-button class="flex-none mr-2" @click="toggleModal">
          <i class="fas fa-plus"></i>
        </abc-tool-button>
      </template>
    </abc-header>

    <abc-table
      :items="software"
      item-id="id"
      class="pt-2 px-2"
      :selected-item="selectedSoftware"
      @select="onRowSelect"
    >
      <template #headers>
        <th
          class="text-left"
          :class="h === 'Description' ? 'px-2' : ''"
          v-for="h in headers"
          :key="h"
        >
          {{ h | upCase }}
        </th>
      </template>
      <template #items="props">
        <td>{{ props.item.id }}</td>
        <td>
          <div class="h-8 flex items-center">
            <div
              class="flex-1"
              v-if="!showEdit || !(selectedSoftware === props.item)"
            >
              <input
                disabled
                class="px-2 w-full border border-transparent bg-transparent"
                :value="props.item.descr"
              />
            </div>
            <abc-input
              class="flex-1"
              v-else
              v-model="props.item.descr"
              :errors="softwareError(props.item)"
            ></abc-input>
          </div>
        </td>
        <td>{{ props.item.parentId }}</td>
        <td class="flex justify-end" v-if="!showEdit || !(selectedSoftware === props.item)">
          <abc-tool-button class="mr-2" @click="selectRow(props.index)">
            <i class="fas fa-edit"></i>
          </abc-tool-button>
          <abc-tool-button @click="navigate(props.item)">
            <i class="fas fa-folder"></i>
          </abc-tool-button>
        </td>
        <td class="flex justify-end" v-if="showEdit && selectedSoftware === props.item">
          <abc-tool-button class="mr-2" @click="submit(props.item)">
            <i class="fas fa-save"></i>
          </abc-tool-button>
          <abc-tool-button class="ml-2" @click="cancelEdit">
            <i class="fas fa-times"></i>
          </abc-tool-button>
        </td>
      </template>
      <template #no-data>
        <abc-no-data-found v-if="!loading" />
        <div v-else class="flex justify-center mt-8">
          <i class="text-2xl text-secondary fas fa-spinner fa-spin" />
        </div>
      </template>
    </abc-table>

    <abc-modal
      v-if="showModal"
      title="Add new Software"
      @close="reset"
      @submit="add"
    >
      <template #body>
        <abc-form ref="addForm" class="modalWidth">
          <abc-input
            class="mb-2"
            label="Id"
            :rules="idRules"
            v-model="newSoftware.id"
            is-focused
          ></abc-input>
          <abc-input
            class="mb-2"
            label="Description"
            :rules="descrRules"
            v-model="newSoftware.descr"
          ></abc-input>
          <abc-select
            class="mb-2"
            label="Parent Id"
            v-model="newSoftware.parentId"
          >
            <option v-for="sw in software" :key="sw.id">{{ sw.id }}</option>
          </abc-select>
        </abc-form>
      </template>
      <template #footer>
        <abc-button isSecondary class="mx-2" @click="reset">Cancel</abc-button>
        <abc-button class="mx-2" @click="add">Save</abc-button>
      </template>
    </abc-modal>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Ref } from "vue-property-decorator";
import { Software } from "@/models/Software";
import AbcHeader from "@/components/Header.vue";
import { getSoftware, updateSoftware, createSoftware } from "@/api/SoftwareApi";
import { Validable } from "@abaco/web-components/src/components/form/Validable";

@Component({
  filters: {
    upCase(val: string) {
      return val.toUpperCase();
    }
  },
  components:{
      AbcHeader
  }
})
export default class SoftwareView extends Vue {
  @Ref("addForm") private form!: Validable;
  headers = ["Id", "Description", "Parent id", ""];
  software: Software[] = [];

  savedDescr: string | null = null;
  selectedSoftware: Software | null = null;
  newSoftware: Software = {} as Software;

  showModal = false;
  showEdit = false;
  loading = false;

  idRules = [(v: string) => !!v || "Software id cannot be undefined", (v: string) => !v.match(/\W/g) || "Software id must contains only alfanumeric characters or _ character" ];
  descrRules = [
    (v: unknown) => !!v || "Software description cannot be undefined"
  ];

  created() {
    window.addEventListener("keydown", this.handleKey);
  }

  destroy() {
    window.removeEventListener("keydown", this.handleKey);
  }

  softwareError(item: Software) {
    if (item == this.selectedSoftware && !item.descr) {
      return ["Software descr cannot be empty"];
    }
    return [];
  }

  handleKey(k: KeyboardEvent) {
    if (!this.showModal && k.key === "+") {
      this.showModal = true;
    }
  }

  toggleModal() {
    return this.showModal ? (this.showModal = false) : (this.showModal = true);
  }

  private selectRow(row: number) {
    this.cancelEdit();
    const item = this.software[row];
    this.selectedSoftware = item;
    this.savedDescr = item.descr;
    this.showEdit = true;
  }

  reset() {
    this.toggleModal();
    this.newSoftware = {} as Software;
  }

  cancelEdit() {
    if (this.selectedSoftware != null && this.savedDescr != null) {
      this.selectedSoftware.descr = this.savedDescr;
      this.savedDescr = null;
    }
    this.selectedSoftware = null;
    this.showEdit = false;
  }

  navigate(sw: Software) {
    this.$router.push({
      name: "Labels",
      params: {
        curSw: sw.id,
        parentSw: sw.parentId
      }
    });
  }

  goToTrash(){
      this.$router.push({name: "Trash"})
  }

  async mounted() {
    this.loading = true;
    const res = await getSoftware();
    res.sort((a,b) => {
        if(a.id < b.id){
            return -1;
        } else if(a.id > b.id){
            return 1;
        }else {
            return 0;
        }
    })
    this.software = res;
    this.loading = false;
  }

  async submit(sw: Software) {
    const result = await updateSoftware(sw);
    if (result) {
      this.$toasted.show("Software updated succesfully");
    }
    this.showEdit = false;
  }

  async add() {
    const isValid = this.form.validate();
    if (isValid) {
      const result = await createSoftware(this.newSoftware);
      if (result) {
        this.$toasted.show("Software updated succesfully");
        this.software.push(this.newSoftware);
        this.reset();
      }
    }
  }

  private onRowSelect(index: number){
      this.navigate(this.software[index]);
  }
}
</script>


<style scoped>
td{
    cursor: pointer;
}
.modalWidth {
  width: 800px;
}

/* On screens that are 992px or less, set the background color to blue */
@media screen and (max-width: 992px) {
  .modalWidth {
    width: 600px;
  }
}

/* On screens that are 600px or less, set the background color to olive */
@media screen and (max-width: 750px) {
  .modalWidth {
    width: 300px;
  }
}
</style>
