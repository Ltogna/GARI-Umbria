declare module "vue-fragment"
declare module "*.js"