import client, { getAPIBasePath } from "./WebClient"
import {Label, LabelOut, LabelIn} from "@/models/Label";

const BASE = getAPIBasePath();

export async function createLabel(newLabel: LabelOut, swId: string): Promise<boolean>{
    const response = await client.post(`${BASE}/labels`, newLabel, {
        params: {
            swId: swId
        }
    });
    return response.data;
}

export async function searchLabel(lang: string, swToBeExcluded: string, filter: string): Promise<LabelIn[]>{
    const response = await client.get(`${BASE}/labels/${lang}`, {
        params:{
            "exclude_sw": swToBeExcluded,
            filter: filter
        }
    })
    return response.data;
}

export async function updateLabel(swId: string, labelId: string, updatedLabel: LabelOut): Promise<boolean>{
    const response = await client.put(`${BASE}/labels/${labelId}`, updatedLabel, {
        params: {
            swId: swId
        }
    });
    return response.data;
}

export async function getLabel(swId: string, labelId: string): Promise<LabelOut>{
    const response = await client.get(`${BASE}/labels/values/${labelId}`, {
        params: {
            swId: swId
        }
    });
    return response.data;
}

export async function getUnlinkedLabels(): Promise<Label[]>{
    const response = await client.get(`${BASE}/labels/unlinked/`);
    return response.data;
}

export async function deleteLabel(labelId: string): Promise<boolean>{
    const response = await client.delete(`${BASE}/labels/${labelId}/`)
    return response.data;
}
