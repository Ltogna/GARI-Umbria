import Vue from "vue";
import { HTTPClient, AxiosResponse } from "@abaco/web-common/src/HTTP";

const webClient = new HTTPClient({
    errorHandler: {
        onResponseError(err: Error, response?: AxiosResponse): void {
            Vue.toasted.show(err.message)
            if (response && response.data.errors) {
                const errors = response.data.errors as string[];
                errors.forEach(err => {
                    Vue.toasted.show(err)
                });
            }
        }
    }
})

export function getAPIBasePath(): string {
    let base = (process.env.BASE_URL || '/') as string;
    if (!base.endsWith("/")) {
        base = base + "/";
    }

    let ret = "/admin";
    if (base !== '/') {
        ret = `${base}..${ret}`;
    }
    console.warn("returning base=", ret);
    return ret;
}

export default webClient;
