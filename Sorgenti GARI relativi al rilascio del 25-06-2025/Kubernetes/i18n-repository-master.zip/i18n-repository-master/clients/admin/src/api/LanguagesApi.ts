import client, { getAPIBasePath } from "./WebClient";
import { Language } from '@/models/Language';

const BASE = getAPIBasePath()

export async function getLanguages(): Promise<string[]>{
    const response = await client.get(`${BASE}/languages`)
    return response.data;
}

export async function createLanguage(lang: Language): Promise<boolean>{
    const response = await client.post(`${BASE}/languages`, lang)
    return response.data;
}
