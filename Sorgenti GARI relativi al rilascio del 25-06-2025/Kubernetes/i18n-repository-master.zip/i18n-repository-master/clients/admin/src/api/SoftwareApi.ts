import client, { getAPIBasePath } from "./WebClient";
import {Software} from "@/models/Software";
import {LabelIn} from "@/models/Label";

const BASE = getAPIBasePath();

export async function getSoftware(): Promise<Software[]>{
    const response = await client.get(`${BASE}/software`)
    return response.data;
}

export async function updateSoftware(updatedSw: Software): Promise<boolean>{
    const response = await client.put(`${BASE}/software/${updatedSw.id}`, updatedSw);
    return response.data;
}

export async function createSoftware(newSw: Software): Promise<boolean>{
    const response = await client.post(`${BASE}/software`, newSw);
    return response.data;
}

export async function getLabels(swId: string, lang: string): Promise<LabelIn[]>{
    const response = await client.get(`${BASE}/software/${swId}/labels`, {
        params:{
            lang: lang
        }
    })
    return response.data;
}

export async function linkLabel(swId: string, labelId: string): Promise<boolean>{
    const resposne = await client.post(`${BASE}/software/${swId}/labels`, labelId, {
        headers: {
            "Content-Type": "text/plain"
        }
    })
    return resposne.data;
}

export async function unLinkLabel(swId: string, labelId: string): Promise<boolean>{
    const response = await client.delete(`${BASE}/software/${swId}/labels/${labelId}`);
    return response.data;
}

