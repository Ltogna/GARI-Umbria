import Vue from "vue";

export default (text: string) => {
    const textArea = document.createElement("textarea");
    textArea.value = text;

    textArea.style.top = "0";
    textArea.style.left = "0";
    textArea.style.position = "fixed";
  
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    const success = document.execCommand('copy');
    if(success){
        Vue.toasted.show("Copied to clipboard")
    }
    document.body.removeChild(textArea);
}