import Vue from 'vue'
import App from './App.vue'
import "@fortawesome/fontawesome-free/css/all.css";
import "./assets/styles/index.css";
import Toasted from "vue-toasted";

import WebComponents, { setI18N } from "@abaco/web-components/src/components";
import { Application } from "@abaco/web-common/src/app";
import WebClient from "@/api/WebClient";
import {AbacoWebModule} from "@abaco/web-common/src/app";
import SsoWebModule from "@abaco/sso-web-module/src/abaco-module";
import routes from "@/router";

class I18nModule implements AbacoWebModule{
    id = "i18n_web_module";
    routes = routes;
}

Vue.use(Toasted, {
    position: "top-center",
    duration: "4000",
    keepOnHover: true
});

Vue.use(WebComponents);

const abacoApp = new Application({
    http: WebClient,
    i18nAPI: "/i18n"
})

abacoApp.add(new SsoWebModule({environment: 'i18n', hidePasswordRecovery: true, skipPrivacyChecks: true}, (user) => {
    setI18N({ locale: user.locale, dateFormat: user.dateFormat });
    abacoApp.setLanguage(user.locale);
}));

abacoApp.add(new I18nModule());

abacoApp.start(h => h(App))
    .then(vue => vue.$mount('#app'))
    .catch(err => console.error(err));

