<template>
  <div class="mb-16">
    <div class="fixed inset-x-0 top-0 z-20 h-16 bg-brand-yellow-500 flex text-center items-center">
      <div class="flex-none ml-2">
        <slot name="left" />
      </div>
      <div class="flex-grow">
        <slot />
      </div>
      <div class="felx-none mr-2">
        <slot name="right" />
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import {Component, Vue } from "vue-property-decorator";

@Component
export default class Header extends Vue {}
</script>
