<template>
  <div class="h-full">
    <abc-table :items="sortedThisLabels" item-id="id" class="h-full">
      <template #headers>
        <th class="text-left bg-white" v-for="h in headers" :key="h">
          {{ h | upCase }}
        </th>
        <th>
          <div class="flex justify-end">
            <abc-tool-button @click="showModal = true">
              <i class="fas fa-plus" />
            </abc-tool-button>
          </div>
        </th>
      </template>
      <template #items="props">
        <td>
          <div class="flex">
            <span>{{ props.item.id }}</span>
            <span class="mx-2 text-primary-500">
              <i
                title="new variant"
                v-if="props.item.type === 'newVariant'"
                class="fas fa-plus-circle"
              />
              <i
                title="edited variant"
                v-if="props.item.type === 'editedVariant'"
                class="fas fa-pencil-alt"
              />
              <i
                title="shared label"
                v-if="props.item.type === 'shared'"
                class="fas fa-link"
              />
            </span>
          </div>
        </td>
        <td class="break-all" style="max-width: 80vw">
          {{ props.item.value }}
        </td>
        <td>
          <div class="flex justify-end">
            <abc-tool-button @click="copyToClipboard(props.item.id)">
              <i class="fas fa-copy" />
            </abc-tool-button>
            <abc-tool-button @click="startEdit(props.item.id)">
              <i class="fas fa-edit" />
            </abc-tool-button>
            <abc-tool-button
              v-if="
                parentSw === null ||
                props.item.type === 'newVariant' ||
                props.item.type === 'editedVariant'
              "
              @click="unLink(props.item.id)"
            >
              <i class="fas fa-trash-alt" />
            </abc-tool-button>
          </div>
        </td>
      </template>
      <template #no-data>
        <abc-no-data-found v-if="!loading" />
        <div v-else class="flex justify-center mt-8">
          <i class="text-2xl text-secondary fas fa-spinner fa-spin" />
        </div>
      </template>
    </abc-table>

    <abc-modal
      v-if="showModal"
      :title="editing ? 'Edit label' : 'Insert new Label'"
      @close="reset"
      @submit="submit"
    >
      <template #body>
        <abc-form ref="form" class="modalWidth">
          <abc-alert
            v-if="isShared"
            class="mb-2"
            is-warn
            :messages="[
              'Editing a linked label value, will edit the label value in all the software where the label is linked too.',
            ]"
          />
          <abc-input
            is-focused
            class="py-1"
            label="Label id"
            v-model="curLabel.id"
            :rules="labelIdRules"
          ></abc-input>
          <abc-input
            v-if="!parentSw"
            class="py-1"
            label="Description"
            v-model="curLabel.descr"
          ></abc-input>
          <div v-for="(lang, index) in languages" :key="lang" class="py-1">
            <abc-input
              :label="lang"
              :maxlength="4000"
              v-model="curValues[index]"
            ></abc-input>
            <p
              :class="
                curValues[index] && curValues[index].length >= 4000
                  ? 'text-warn'
                  : 'text-secondary'
              "
              class="text-right"
            >
              {{ curValues[index] ? curValues[index].length : 0 }}/4000
            </p>
          </div>
        </abc-form>
      </template>
      <template #footer>
        <abc-button
          is-outlined
          :isDisabled="disableButton"
          class="mx-2"
          @click="reset"
          >Cancel</abc-button
        >
        <abc-button :isDisabled="disableButton" class="mx-2" @click="submit"
          >Save</abc-button
        >
      </template>
    </abc-modal>
  </div>
</template>

<script lang="ts">
import { Prop, Component, Vue, Ref } from "vue-property-decorator";
import { LabelIn, LabelOut } from "../models/Label";
import { unLinkLabel } from "../api/SoftwareApi";
import { createLabel, getLabel, updateLabel } from "../api/LabelApi";

import copyToClipboard from "../utils/copyToClipBoard";
import { Validable } from "@abaco/web-components/src/components/form/Validable";

@Component({
  filters: {
    upCase(val: string) {
      return val.toUpperCase();
    },
  },
})
export default class CurrentLabels extends Vue {
  @Ref("form") private form!: Validable;

  @Prop() readonly _labels!: LabelIn[];
  @Prop() readonly _search!: string;
  @Prop() readonly curSw!: string;
  @Prop() readonly _languages!: string[];
  @Prop() readonly _curLang!: string;
  @Prop() readonly parentSw!: string;
  @Prop() readonly loading!: boolean;

  showModal = false;
  editing = false;
  oldLabelId = "";
  curLabel: LabelOut = {} as LabelOut;
  curValues: string[] = [];
  isShared = false;
  headers = ["Label", "Value"];

  labelIdRules = [
    (v: string) => !!v || "Label id cannnot be undefined",
    (v: string) => {
      const res = v.match(/([&?/<>[\]{} |\\~`=])+/g);
      if (res && res.length) {
        return `Cannot use the following character ${res}`;
      }
      return true;
    },
  ];
  disableButton = false;

  get labels() {
    return this._labels;
  }
  get search() {
    return this._search;
  }
  get languages() {
    return this._languages;
  }
  get curLang() {
    return this._curLang;
  }

  async created() {
    window.addEventListener("keydown", this.handleKey);
  }

  destroy() {
    window.removeEventListener("keydown", this.handleKey);
  }

  handleKey(k: KeyboardEvent) {
    if (!this.showModal && k.key === "+") {
      this.showModal = true;
    }
  }

  get filteredLabels() {
    if (this.search != "") {
      return this.labels.filter(
        (l) =>
          l.id.toLowerCase().search(this.search as string) >= 0 ||
          l.value.toLowerCase().search(this.search as string) >= 0
      );
    }
    return this.labels;
  }

  get sortedThisLabels() {
    return this.filteredLabels.sort((a, b) => {
      return a.id < b.id ? -1 : +1;
    });
  }

  async startEdit(labelId: string) {
    this.oldLabelId = labelId;
    this.curLabel = await getLabel(this.curSw, labelId);

    this.languages.forEach((lang) => {
      const value = this.curLabel.values.find((val) => val.lang === lang);
      if (value && value.val != undefined) {
        this.curValues.push(value.val);
      } else {
        this.curValues.push("");
      }
    });
    this.isShared =
      this.sortedThisLabels.find((l) => l.id === labelId)?.type === "shared";
    this.editing = true;
    this.showModal = true;
  }

  copyToClipboard(text: string) {
    copyToClipboard(text);
  }

  submit() {
    const isValid = this.form.validate();
    let hasError = false;
    this.curLabel.values = [];
    this.languages.forEach((lang, index) => {
      if (!this.curValues.some((el) => el != undefined || el != "")) {
        hasError = true;
      }
      if (this.curValues[index]) {
        this.curLabel.values.push({
          lang: lang,
          val: this.curValues[index],
        });
      }
    });

    if (!isValid || hasError) {
      if (hasError) {
        this.$toasted.show("Set at least one language");
      }
      return;
    }
    this.disableButton = true;
    try {
      if (this.editing) {
        this.editLabel();
      } else {
        this.addLabel();
      }
    } catch (error) {
      this.$toasted.show(error, { type: "error" });
      console.error(error);
    } finally {
      this.disableButton = false;
    }
  }

  async editLabel() {
    const result = await updateLabel(
      this.curSw,
      this.oldLabelId,
      this.curLabel
    );
    if (result) {
      this.$toasted.show("Label " + this.oldLabelId + " updated succesfully");
      this.reset();
      this.$emit("reload");
    }
  }

  async addLabel() {
    const inserted = await createLabel(this.curLabel, this.curSw);
    if (inserted) {
      this.$toasted.show("Succesfully inserted new label " + this.curLabel.id);
      this.reset();
      this.$emit("reload");
    }
  }

  async unLink(labelId: string) {
    const unlinked = await unLinkLabel(this.curSw, labelId);
    if (unlinked) {
      this.$toasted.show("Succesfully unlinked label " + labelId);
      this.reset();
      this.$emit("reload");
    }
  }

  reset() {
    this.showModal = false;
    this.editing = false;
    this.oldLabelId = "";
    this.curLabel = {} as LabelOut;
    this.curValues = [];
    this.$emit("reset");
  }
}
</script>

<style scoped>
.modalWidth {
  width: 800px;
}

/* On screens that are 992px or less, set the background color to blue */
@media screen and (max-width: 992px) {
  .modalWidth {
    width: 600px;
  }
}

/* On screens that are 600px or less, set the background color to olive */
@media screen and (max-width: 750px) {
  .modalWidth {
    width: 300px;
  }
}
</style>