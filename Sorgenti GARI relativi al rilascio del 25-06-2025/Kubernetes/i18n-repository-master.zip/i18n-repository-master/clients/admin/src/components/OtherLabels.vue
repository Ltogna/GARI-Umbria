<template>
  <div>
    <abc-table
      v-if="sortedOtherLabels.length > 0"
      :items="sortedOtherLabels"
      item-id="id"
      class="relative"
    >
      <template #headers>
        <th class="text-left" v-for="h in headers" :key="h">
          {{ h | upCase }}
        </th>
        <th></th>
      </template>

      <template #items="props">
        <td>{{ props.item.id }}</td>
        <td class="break-all" style="max-width: 70vw">
          {{ props.item.value }}
        </td>
        <td>
          <div class="flex">
            <span
              v-for="(sw, index) in props.item.softwareIds"
              :key="sw"
              class="flex mr-2"
            >
              {{ sw }}
              <p v-if="index < props.item.softwareIds.length - 1">{{ `,` }}</p>
            </span>
          </div>
        </td>
        <td>
          <div class="flex justify-end">
            <abc-tool-button
              v-if="!props.item.linked"
              @click="linkLabel(props.item.id, props.index)"
            >
              <i class="fas fa-link" />
            </abc-tool-button>
            <abc-tool-button @click="copyToClipboard(props.item.id)">
              <i class="fas fa-copy" />
            </abc-tool-button>
          </div>
        </td>
      </template>
      <template #no-data>
        <abc-no-data-found v-if="!loading" />
        <div v-else class="flex justify-center mt-8">
          <i class="text-2xl text-secondary fas fa-spinner fa-spin" />
        </div>
      </template>
    </abc-table>
  </div>
</template>

<script lang="ts">
import { Prop, Component, Vue, Watch } from "vue-property-decorator";
import { Debounce } from "vue-debounce-decorator";
import { OtherLabelIn } from "../models/Label";
import { searchLabel } from "../api/LabelApi";
import { linkLabel } from "../api/SoftwareApi";
import copyToClipboard from "../utils/copyToClipBoard";

@Component({
  filters: {
    upCase(val: string) {
      return val.toUpperCase();
    },
  },
})
export default class OtherLabels extends Vue {
  @Prop() readonly search!: string;
  @Prop() readonly curSw!: string;

  @Prop() readonly _curLang!: string;
  @Prop() loading!: boolean;

  otherSwLabels: OtherLabelIn[] = [];
  headers = ["Label", "Value", "Software"];
  curLang: string | null = null;

  @Watch("_curLang")
  onLangChange() {
    this.curLang = this._curLang;
    this.onSearch(this.search);
  }

  get sortedOtherLabels() {
    this.otherSwLabels.length > 0
      ? this.$emit("show", true)
      : this.$emit("show", false);
    return this.otherSwLabels.sort((a, b) => {
      return a.id < b.id ? -1 : +1;
    });
  }

  @Watch("search")
  @Debounce(300)
  async onSearch(newVal: string) {
    if (this.curLang == null) {
      this.$toasted.show("add at least a language before continuing");
      return;
    }
    this.otherSwLabels = [];
    if (newVal != "") {
      const res = await searchLabel(this.curLang, this.curSw, this.search);
      res.forEach((l) => {
        this.otherSwLabels.push({
          id: l.id,
          value: l.value,
          linked: false,
          softwareIds: l.softwareIds,
        });
      });
    }
  }

  async linkLabel(labelId: string, index: number) {
    const linked = await linkLabel(this.curSw, labelId);
    if (linked) {
      this.$toasted.show(
        "Succesfully linked new label " + labelId + " to " + this.curSw
      );

      this.$set(this.otherSwLabels[index], "linked", true);
      this.$emit("reload");
    }
  }

  copyToClipboard(text: string) {
    copyToClipboard(text);
  }
}
</script>
