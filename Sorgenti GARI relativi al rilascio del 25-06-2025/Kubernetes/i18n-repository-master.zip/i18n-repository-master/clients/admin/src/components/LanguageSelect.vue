<template>
  <div>
    <abc-dropdown
      :items="filteredLanguages"
      :additional-items="[1]"
      :selected-item="value"
      @select="setLanguage"
      @additional="showModal = true"
      max-height="180px"
    >
      <input
        class="w-full focus:outline-none"
        autocomplete="off"
        v-model="inputLang"
      />
      <template #items="props">
        <button class="py-2 w-full focus:outline-none focus:bg-primary-200">
          {{ props.item }}
        </button>
      </template>
      <template #additionalItems>
        <div class="cursor-pointer text-center py-2">
          <i class="fas fa-plus"></i>
        </div>
      </template>
      <template #no-data>
        <abc-no-data-found v-if="!loading" />
        <div v-else class="flex justify-center mt-4">
          <i class="text-xl text-secondary fas fa-spinner fa-spin" />
        </div>
      </template>
    </abc-dropdown>

    <abc-modal
      v-if="showModal"
      title="Add new language"
      @close="reset"
      @submit="addLang"
    >
      <template #body>
        <abc-form ref="form">
          <abc-input
            is-focused
            class="mb-2 text-left"
            v-model="newLang.lang"
            label="Name"
            :rules="langRules"
          ></abc-input>
          <abc-input
            class="mb-2 text-left"
            v-model="newLang.descr"
            label="Description"
            :rules="descrRules"
          ></abc-input>
        </abc-form>
      </template>
      <template #footer>
        <abc-button isSecondary class="mx-2" @click="reset">Cancel</abc-button>
        <abc-button class="mx-2" @click="addLang">Save</abc-button>
      </template>
    </abc-modal>
  </div>
</template>

<script lang="ts">
import { Prop, Component, Vue, Ref } from "vue-property-decorator";
import { Language } from "@/models/Language";
import { Validable } from "@abaco/web-components/src/components/form/Validable";

@Component
export default class LanguageSelect extends Vue {
  @Ref("form") private form!: Validable;
  @Prop() readonly value!: string;
  @Prop() readonly languages!: string[];
  @Prop() loading!: boolean;

  showModal = false;

  search: string | null = null;

  newLang: Language = {} as Language;
  langRules = [(v: unknown) => !!v || "Language cannot be undefined"];
  descrRules = [(v: unknown) => !!v || "Description cannot be undefined"];

  get inputLang() {
    return this.search != null ? this.search : this.value;
  }

  set inputLang(val: string) {
    this.search = val;
  }

  get filteredLanguages() {
    if (this.search != null) {
      return this.languages.filter(
        (lang) => lang.search(this.search as string) >= 0
      );
    }
    return this.languages;
  }

  setLanguage(index: number) {
    this.$emit("input", this.filteredLanguages[index]);
    this.search = null;
  }

  reset() {
    this.newLang = {} as Language;
    this.showModal = false;
  }

  async addLang() {
    const isValid = this.form.validate();
    if (isValid) {
      this.$emit("addLang", this.newLang);
      this.reset();
    }
  }
}
</script>
