export interface Language {
    lang: string;
    descr: string;
}