export interface Software {
    id: string;
    descr: string;
    parentId: string;
}

export interface SoftwareError {
    id: string | null;
    descr: string | null;
}
