export interface Label{
    id: string;
    descr: string;
}

export interface LabelIn{
    id: string;
    value: string;
    type?: string;
    softwareIds?: string[];
}

export interface OtherLabelIn extends LabelIn{
    linked: boolean;
}

export interface LabelOut{
    id: string ;
    descr: string ;
    values: LabelValue[]
}

export interface LabelValue{
    lang: string;
    val?: string;
}

export interface LabelError{
    labelId: string;
    descr: string;
    values: string[];
}
