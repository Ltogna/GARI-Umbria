module.exports = {
    publicPath: process.env.NODE_ENV === 'production' ? '/i18n/client/' : '/',
    outputDir: "../../src/main/resources/assets",
    devServer: {
        port: 9091,
        proxy: {
            // "/i18n": {
            //     target: "https://devs4f.fe.abacogroup.eu/",
            //     pathRewrite: { "^/admin": "/i18n/" },
            // },
            // "/admin": {
            //     target: "https://devs4f.fe.abacogroup.eu/",
            //     pathRewrite: { "^/admin": "/i18n/admin" },
            // },
            "/i18n": {
                target: "https://devs4f.fe.abacogroup.eu/",
                pathRewrite: { "^/admin": "/i18n/" },
            },
            "/admin": {
                target: "https://devs4f.fe.abacogroup.eu/",
                pathRewrite: { "^/admin": "/i18n/admin" },
            },
            "/sso2": {
                target: "https://devs4f.fe.abacogroup.eu/",
            },
        }
    }
}
