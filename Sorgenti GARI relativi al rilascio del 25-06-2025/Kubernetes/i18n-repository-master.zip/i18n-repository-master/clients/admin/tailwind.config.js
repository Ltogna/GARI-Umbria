/* eslint-disable @typescript-eslint/no-var-requires */
const cmpTailwindConfig = require("@abaco/web-components/tailwind.config");

module.exports = {
    theme: {
        ...cmpTailwindConfig.theme.theme,
        extend:{
            ...cmpTailwindConfig.theme.extend,
            height:{
                ...cmpTailwindConfig.theme.extend.height,
                'md': '24rem',
                'lg': '40rem',
                'xl': '60rem',
            },
            inset: {
                ...cmpTailwindConfig.theme.extend.inset,
                '1/2': '50%',
                '1/4': '25%',
            },
            width: {
                ...cmpTailwindConfig.theme.extend.width,
                'sm': '24rem'
            }
        }
    },
    variants:{
        ...cmpTailwindConfig.variants
    },
    plugins: [...cmpTailwindConfig.plugins]
}


