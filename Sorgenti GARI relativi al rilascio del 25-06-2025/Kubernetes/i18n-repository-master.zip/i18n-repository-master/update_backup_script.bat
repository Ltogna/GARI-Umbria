@echo off

if "%~1"=="" (
  echo Usage: %0 ^<tag_name^>
  exit /b 1
)

set host=192.168.19.22
set port=8103
set url=http://%host%:%port%/tasks/backup.zip
set repository=origin
set tag_name=%~1

REM Pull the latest changes from the repository
git pull "%repository%" master

REM Make the POST request
curl -X POST "%url%" > response.txt

REM Extract the string after "saved backup in"
for /f "usebackq delims=" %%G in ("response.txt") do (
  set "response=%%G"
)
set backup_path=%response:saved backup in D:\=%

REM Extract the filename from the backup path
for %%F in ("%backup_path%") do set "filename=%%~nxF"

set backup_path=%backup_path:~0,-31%

REM Check if the backup path is extracted successfully
if "%backup_path%"=="" (
  echo Failed to extract backup path from the response.
  exit /b 1
)

REM Retrieve the zip file from the remote machine
C:\Windows\System32\Robocopy.exe "\\%host%\%backup_path%" "." "%filename%"

REM Copy the retrieved backup file to the /release/ path with the filename
move /Y "%filename%" release\backup.zip

REM Create a commit with the description "Updated backups"
git add release\backup.zip
git commit -m "Updated backup"

REM Push the changes and the tag to the repository
git push "%repository%" master

REM Create a tag with the specified name
git tag "%tag_name%"
git push "%repository%" "%tag_name%"

echo Changes and tag pushed to the repository successfully.

REM Clean up the temporary response file
del response.txt

exit /b 0
