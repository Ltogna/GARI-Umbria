package com.abacogroup.lpisgisserver.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.MatrixLandUsesMetadataNTT;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import java.util.List;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface MatrixLandUsesMetadataDAO extends Transactional<MatrixLandUsesMetadataDAO>, EnhancedSqlObject {

	@SqlUpdate(
			"INSERT INTO lpis_matrix_landuses_metadata (tenant_id, matrix_id, class_code, land_use_code, key, value, day_from, day_to, user_id_insert, user_id_delete, dt_insert, dt_delete) "
					+ "VALUES(:tenant_id, :matrix_id, :class_code, :land_use_code, :key, :value, :day_from, :day_to, :user_id_insert, NULL, §current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insert(@BindBean MatrixLandUsesMetadataNTT ntt, @Bind("user_id_insert") String userId);

	@SqlUpdate(
			"INSERT INTO lpis_matrix_landuses_metadata (tenant_id, matrix_id, class_code, land_use_code, key, value, day_from, day_to, user_id_insert, user_id_delete, dt_insert, dt_delete) "
					+ "VALUES(:tenantId, :matrixId, :classCode, :landUseCode, :key, :value, :dayFrom, :dayTo, :userIdInsert, NULL, §current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insertWithParams(@Bind("tenantId") String tenantId, @Bind("matrixId") Long matrixId, @Bind("classCode") String classCode,
			@Bind("landUseCode") String landUseCode, @Bind("key") String key, @Bind("value") String value, @Bind("dayFrom") AbsoluteDate dayFrom,
			@Bind("dayTo") AbsoluteDate dayTo, @Bind("userIdInsert") String userIdInsert);

	@SqlUpdate("update lpis_matrix_landuses_metadata \n"
			+ "   set user_id_delete = :user_id_delete, \n"
			+ "       dt_delete = §current_timestamp§ \n"
			+ " where tenant_id = :tenant_id \n"
			+ "   and matrix_id = :matrix_id \n"
			+ "   and class_code = :class_code \n"
			+ "   and land_use_code = :land_use_code \n"
			+ "   and key = :key \n"
			+ "   and ( \n"
			+ "      :day_from between day_from and day_to or \n"
			+ "      :day_to between day_from and day_to or \n"
			+ "      (day_from > :day_from and day_to < :day_to) \n"
			+ "   ) \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n")
	void logicallyDelete(@BindBean MatrixLandUsesMetadataNTT ntt, @Bind("user_id_delete") String userId);

	@SqlUpdate("update lpis_matrix_landuses_metadata \n"
			+ "   set user_id_delete = :user_id_delete, \n"
			+ "       dt_delete = §current_timestamp§ \n"
			+ " where tenant_id = :tenant_id \n"
			+ "   and matrix_id = :matrix_id \n"
			+ "   and land_use_code = :land_use_code \n"
			+ "   and key = :key \n"
			+ "   and ( \n"
			+ "      :day_from between day_from and day_to or \n"
			+ "      :day_to between day_from and day_to or \n"
			+ "      (day_from > :day_from and day_to < :day_to) \n"
			+ "   ) \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n")
	void logicallyDeleteByMatrixLandUseKey(@BindBean MatrixLandUsesMetadataNTT ntt, @Bind("user_id_delete") String userId);

	@SqlQuery("select tenant_id, \n"
			+ "       matrix_id, \n"
			+ "       class_code, \n"
			+ "       land_use_code, \n"
			+ "       key, \n"
			+ "       value, \n"
			+ "       day_from, \n"
			+ "       day_to \n"
			+ "  from lpis_matrix_landuses_metadata \n"
			+ " where tenant_id = :tenantId \n"
			+ "   and matrix_id = :matrixId \n"
			+ "   and class_code = :classCode \n"
			+ "   and land_use_code = :landUseCode \n"
			+ "   and day_from <= :dayTo \n"
			+ "   and :dayFrom <= day_to \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n"
			+ "   and key = :key")
	@RegisterBeanMapper(MatrixLandUsesMetadataNTT.class)
	List<MatrixLandUsesMetadataNTT> getLandUsesMetadataByTimeInterval(
			@Bind("tenantId") String tenantId,
			@Bind("matrixId") Long matrixId,
			@Bind("classCode") String classCode,
			@Bind("landUseCode") String landUseCode,
			@Bind("dayFrom") AbsoluteDate dayFrom,
			@Bind("dayTo") AbsoluteDate dayTo,
			@Bind("key") String key);

	@SqlQuery("select tenant_id, \n"
			+ "       matrix_id, \n"
			+ "       class_code, \n"
			+ "       land_use_code, \n"
			+ "       key, \n"
			+ "       value, \n"
			+ "       day_from, \n"
			+ "       day_to \n"
			+ "  from lpis_matrix_landuses_metadata \n"
			+ " where tenant_id = :tenant_id \n"
			+ "   and matrix_id = :matrix_id \n"
			+ "   and class_code = :class_code \n"
			+ "   and land_use_code = :land_use_code \n"
			+ "   and (:key is null or key = :key) \n"
			+ "   and :referenceDate between day_from and day_to \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(MatrixLandUsesMetadataNTT.class)
	List<MatrixLandUsesMetadataNTT> getLandUsesMetadataByMatrixIdClassCodeLandUseCodeAndKey(
			@Bind("tenant_id") String tenantId,
			@Bind("matrix_id") Long matrixId,
			@Bind("class_code") String classCode,
			@Bind("land_use_code") String landUseCode,
			@Bind("referenceDate") AbsoluteDate referenceDate,
			@Bind("key") String key);

	@SqlQuery("select tenant_id, \n"
			+ "       matrix_id, \n"
			+ "       class_code, \n"
			+ "       land_use_code, \n"
			+ "       key, \n"
			+ "       value, \n"
			+ "       day_from, \n"
			+ "       day_to \n"
			+ "  from lpis_matrix_landuses_metadata \n"
			+ " where tenant_id = :tenant_id \n"
			+ "   and matrix_id = :matrix_id \n"
			+ "   and land_use_code = :land_use_code \n"
			+ "   and (:key is null or key = :key) \n"
			+ "   and :referenceDate between day_from and day_to \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(MatrixLandUsesMetadataNTT.class)
	List<MatrixLandUsesMetadataNTT> getLandUsesMetadataByMatrixIdLandUseCodeAndKey(
			@Bind("tenant_id") String tenantId,
			@Bind("matrix_id") Long matrixId,
			@Bind("land_use_code") String landUseCode,
			@Bind("referenceDate") AbsoluteDate referenceDate,
			@Bind("key") String key);

	@SqlQuery("select lm.tenant_id, \n"
			+ "       lm.id as matrix_id, \n"
			+ "       lmlm.class_code, \n"
			+ "       lmlm.land_use_code, \n"
			+ "       lmlm.key, \n"
			+ "       lmlm.value, \n"
			+ "       lmlm.day_from, \n"
			+ "       lmlm.day_to \n"
			+ "  from lpis_matrix_landuses_metadata lmlm \n"
			+ " inner join lpis_matrix lm on lmlm.matrix_id = lm.id and lmlm.tenant_id = lm.tenant_id \n"
			+ " where lm.tenant_id = :tenant_id \n"
			+ "   and lm.code = :matrix_code \n"
			+ "   and lmlm.class_code = :class_code \n"
			+ "   and lmlm.land_use_code = :land_use_code \n"
			+ "   and (:key is null or lmlm.key = :key) \n"
			+ "   and :referenceDate between lmlm.day_from and lmlm.day_to \n"
			+ "   and §current_timestamp§ between lmlm.dt_insert and lmlm.dt_delete")
	@RegisterBeanMapper(MatrixLandUsesMetadataNTT.class)
	List<MatrixLandUsesMetadataNTT> getLandUsesMetadataByMatrixCodeClassCodeLandUseCodeAndKey(
			@Bind("tenant_id") String tenantId,
			@Bind("matrix_code") String matrixCode,
			@Bind("class_code") String classCode,
			@Bind("land_use_code") String landUseCode,
			@Bind("referenceDate") AbsoluteDate referenceDate,
			@Bind("key") String key);
}
