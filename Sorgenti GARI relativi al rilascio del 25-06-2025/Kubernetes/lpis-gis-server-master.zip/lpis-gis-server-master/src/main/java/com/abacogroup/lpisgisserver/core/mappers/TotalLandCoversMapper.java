package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.TotalLandCoversNTT;
import com.abacogroup.lpisgisserver.resources.res.farmland.TotalLandCovers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface TotalLandCoversMapper {

	TotalLandCoversMapper INSTANCE = Mappers.getMapper(TotalLandCoversMapper.class);
	
	@Mapping(target = "layer_style", ignore = true)
	TotalLandCovers entityToDto(TotalLandCoversNTT entity);

	TotalLandCoversNTT dtoToEntity(TotalLandCovers dto);
}
