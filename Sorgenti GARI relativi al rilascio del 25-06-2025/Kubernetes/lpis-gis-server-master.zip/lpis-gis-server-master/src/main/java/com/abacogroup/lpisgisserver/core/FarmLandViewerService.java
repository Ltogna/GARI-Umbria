package com.abacogroup.lpisgisserver.core;

import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.farmland.FarmlandParcelsNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.farmland.TotalLandCoversNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.farmland.TotalParcelsNotFoundException;
import com.abacogroup.lpisgisserver.core.mappers.AreasMapper;
import com.abacogroup.lpisgisserver.core.mappers.LandCoversMapper;
import com.abacogroup.lpisgisserver.core.mappers.ParcelDetailsMapper;
import com.abacogroup.lpisgisserver.core.mappers.TotalLandCoversMapper;
import com.abacogroup.lpisgisserver.core.mappers.TotalParcelsSummaryMapper;
import com.abacogroup.lpisgisserver.core.mappers.ViewerBlockDetailsMapper;
import com.abacogroup.lpisgisserver.core.support.MatrixSearchParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.AreasDAO;
import com.abacogroup.lpisgisserver.db.dao.BlockDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.LandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassDetailsDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassLandcoversDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixDAO;
import com.abacogroup.lpisgisserver.db.dao.ParcelDetailsDAO;
import com.abacogroup.lpisgisserver.db.dao.ParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.TotalLandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.TotalParcelsDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassLandcoversNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.TotalParcelsNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.ReqContext;
import com.abacogroup.lpisgisserver.resources.req.TotalParcelsSummaryFilters;
import com.abacogroup.lpisgisserver.resources.res.Area;
import com.abacogroup.lpisgisserver.resources.res.LandCoverWithUnits;
import com.abacogroup.lpisgisserver.resources.res.farmland.LandCoverDetails;
import com.abacogroup.lpisgisserver.resources.res.farmland.ParcelDetails;
import com.abacogroup.lpisgisserver.resources.res.farmland.ParcelsSummary;
import com.abacogroup.lpisgisserver.resources.res.farmland.TotalLandCovers;
import com.abacogroup.lpisgisserver.resources.res.farmland.TotalLandCoversList;
import com.abacogroup.lpisgisserver.resources.res.farmland.TotalParcelsSummary;
import com.abacogroup.lpisgisserver.resources.res.viewer.ViewerBlockDetails;
import com.google.common.collect.Iterators;
import com.google.common.collect.UnmodifiableIterator;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FarmLandViewerService extends BaseService {

	private TotalParcelsDAO totalParcelsDAO;
	private ParcelDetailsDAO parcelDetailsDAO;
	private ParcelsDAO parcelsDAO;
	private TotalLandCoversDAO totalLandCoversDAO;
	private LandCoversDAO landCoversDAO;
	private MatrixDAO matrixDAO;
	private MatrixClassDetailsDAO matrixClassDetailsDAO;
	private MatrixClassLandcoversDAO matrixClassLandcoversDAO;
	private BlockDAO blockDAO;
	private AreasDAO areasDAO;

	private CLLService cllService;
	private ParcelsService parcelsService;
	
	private final Integer DO_NOT_INCLUDE_GEOMETRIES = 0;

	public FarmLandViewerService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, CLLService cllService, 
			ParcelsService parcelsService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.totalParcelsDAO = dc.getTotalParcelsDAO();
		this.parcelDetailsDAO = dc.getParcelDetailsDAO();
		this.parcelsDAO = dc.getParcelsDAO();
		this.totalLandCoversDAO = dc.getTotalLandCoversDAO();
		this.landCoversDAO = dc.getLandCoversDAO();
		this.matrixDAO = dc.getMatrixDAO();
		this.matrixClassDetailsDAO = dc.getMatrixClassDetailsDAO();
		this.matrixClassLandcoversDAO = dc.getMatrixClassLandcoversDAO();
		this.blockDAO = dc.getBlockDAO();
		this.areasDAO = dc.getAreasDAO();

		this.cllService = cllService;
		this.parcelsService = parcelsService;
	}

	public ParcelsSummary getParcelsSummary(ReqContext reqContext, ServiceSupportEnv env) {

		List<Long> parcelIds = cllService.getPartyParcelIds(reqContext, env, null);

		List<TotalParcelsNTT> totalParcels = totalParcelsDAO.findTotalParcelsInParcelListGroupedBySectorCode(env.getTenantId(), env.getSectorCode(),
				parcelIds, env.getReferenceDate());

		if (totalParcels == null || totalParcels.isEmpty()) {
			TotalParcelsNotFoundException ex = new TotalParcelsNotFoundException(Status.NOT_FOUND, Operation.GET_PARCELS_SUMMARY, null,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return ParcelsSummary.builder()
				.total_parcels(totalParcels.stream().mapToLong(TotalParcelsNTT::getTotal_parcels).sum())
				.total_area_sqm(totalParcels.stream().mapToDouble(TotalParcelsNTT::getTotal_area_sqm).sum())
				.build();
	}

	public InfiniteListResults<TotalParcelsSummary> findInfiniteTotalParcelsSummaryGroupedBySectorCode(ReqContext reqContext, 
			ServiceSupportEnv env, TotalParcelsSummaryFilters searchFilters) {

		cllService.updatePartyParcelsCache(reqContext, env);

		return totalParcelsDAO.infinite(
				() -> totalParcelsDAO.findInfiniteTotalParcelsInParcelsListGroupedBySectorCode(env, searchFilters),
				env.getNextKey(),
				env.getPageSize())
				.map(TotalParcelsSummaryMapper.INSTANCE::entityToDto);

	}

	public InfiniteListResults<Area> findInfiniteAreasBySectorCode(ReqContext reqContext, ServiceSupportEnv env, Long filteredAreaId, List<String> areaSearches, String level) {

		List<Long> parcelIds = cllService.getPartyParcelIds(reqContext, env, filteredAreaId);

		final List<Long> areaIds = new ArrayList<>();
		UnmodifiableIterator<List<Long>> partitions = Iterators.partition(parcelIds.iterator(), 800);
		partitions.forEachRemaining(partition -> {
			List<Long> partial = areasDAO.getAreaIdsFromParcelIds(env, partition);
			if (partial != null)
				areaIds.addAll(partial);
		});

		if (areaIds.isEmpty()) {
			areaIds.add(-1L);
		}

		List<Criteria> criterias = new ArrayList<>();

		if (areaSearches != null) {
			areaSearches.stream().filter(s -> s != null && !s.isBlank() && s.split("\\:", 2).length == 2).forEach(s -> {
				String levelFilter = s.split("\\:", 2)[0];
				String descriptionFilter = s.split("\\:", 2)[1];
				criterias.add(CriteriaBuilder.string(levelFilter.toLowerCase() + ".description").caseInsensitiveContains(descriptionFilter));
			});
		}

		Criteria criteriaSearch = criterias.isEmpty() ? CriteriaBuilder.number("1").eq(1) : CriteriaBuilder.and(criterias.toArray(new Criteria[0]));

		// FIXME it should be made dinnamically using areasDAO.loadLevelsOrder
		Criteria criteriaIds = CriteriaBuilder.or(
				CriteriaBuilder.number("naz.area_id").in(areaIds.stream().map(id -> (Number) id).toList()),
				CriteriaBuilder.number("reg.area_id").in(areaIds.stream().map(id -> (Number) id).toList()),
				CriteriaBuilder.number("pro.area_id").in(areaIds.stream().map(id -> (Number) id).toList()),
				CriteriaBuilder.number("com.area_id").in(areaIds.stream().map(id -> (Number) id).toList())
				);
		Criteria criteria = CriteriaBuilder.and(criteriaSearch, criteriaIds);

		return this.areasDAO.infinite(
				() -> areasDAO.infiniteSearchAreasByCriterias(env, criteria, level),
				env.getNextKey(),
				env.getPageSize())
				.map(AreasMapper.INSTANCE::entityToDto);


	}

	public InfiniteListResults<ParcelDetails> findInfiniteParcelsBySectorCode(ReqContext reqContext, ServiceSupportEnv env, String blockFilter, 
			Long blockId, String parcelFilter) {

		List<Long> parcelIds = cllService.getPartyParcelIds(reqContext, env, null);

		InfiniteListResults<ParcelDetailsNTT> parcelNTTs = this.parcelDetailsDAO.infinite(
				() -> parcelDetailsDAO.findInfiniteParcelsInParcelListBySectorCode(env.getTenantId(), parcelIds, env.getReferenceDate(), env.getSectorCode(),
						blockFilter, blockId, parcelFilter),
				env.getNextKey(),
				env.getPageSize());

		if (parcelNTTs.getRecords() == null || parcelNTTs.getRecords().isEmpty()) {
			FarmlandParcelsNotFoundException ex = new FarmlandParcelsNotFoundException(Status.NOT_FOUND, Operation.GET_PARCELS_BY_SECTOR, null,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		List<ParcelDetails> parcelsList = new ArrayList<>();

		parcelNTTs.getRecords().parallelStream().forEach(p -> {
			env.setSrs(p.getSrs());
			ParcelDetails parcelDetails = ParcelDetailsMapper.INSTANCE.entityToDto(p);
			parcelDetails.setParcel_code(parcelsDAO.findByIdTenantId(parcelDetails.getParcel_id(), env.getTenantId()).get(0).getParcel());

			List<LandCoverNTT> landcovers = new ArrayList<>();
			List<LandCoverDetails> landCoversDetails = new ArrayList<>();

			Boolean flHideLandCovers = internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_HIDE_LANDCOVERS_LAYER.getKey());
			if(Boolean.FALSE.equals(flHideLandCovers)) {
				String lcOriginCatalogueCode = internalConf.getStringValue(env.getTenantId(), InternalConfigKeys.LANDCOVER_ORIGIN_CATALOGUE_CODE.getKey());
				if(!StringUtils.isBlank(lcOriginCatalogueCode)) {
					landcovers = parcelsService.getParcelLandCoversFromCatalogue(env, lcOriginCatalogueCode, parcelDetails.getParcel_id(), p.getGeom(), p.getSrs())
							.stream()
							.map(LandCoversMapper.INSTANCE::dtoToEntity)
							.collect(Collectors.toList());
				} else {
					landcovers = landCoversDAO.findByParcelIds(env, Arrays.asList(parcelDetails.getParcel_id()));
				}
			}

			landcovers.forEach(landcover -> landCoversDetails.add(
					LandCoverDetails.builder()
					.description(landcover.getLand_cover_description())
					.land_cover_code(landcover.getLand_cover_code())
					.world_geom(landcover.getWorld_geom())
					.layer_style(this.styleService.getLandCoverLayerStyle(env.getTenantId(), env.getReferenceDate(), landcover.getLand_cover_code()))
					.build()));

			parcelDetails.setLandcover_details_list(landCoversDetails);

			String sauMatrixCode = this.internalConf.getStringValue(env.getTenantId(), InternalConfigKeys.DEFAULT_SAU_MATRIX_CODE_KEY.getKey());
			parcelDetails.setArea_sau(getAreaSau(parcelDetails.getParcel_id(), sauMatrixCode, env));

			parcelsList.add(parcelDetails);
		});
		
		return new InfiniteListResultsImpl<>(parcelsList, parcelNTTs.getNextKey());
	}

	public TotalLandCoversList findTotalLandCoverByParcelIdsAndSectorCode(ReqContext reqContext, ServiceSupportEnv env) {

		List<Long> parcelIds = cllService.getPartyParcelIds(reqContext, env, null);

		List<TotalLandCovers> totalLandCovers = new ArrayList<>();

		Boolean flHideLandCovers = internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_HIDE_LANDCOVERS_LAYER.getKey());
		if(Boolean.FALSE.equals(flHideLandCovers)) {

			String lcOriginCatalogueCode = internalConf.getStringValue(env.getTenantId(), InternalConfigKeys.LANDCOVER_ORIGIN_CATALOGUE_CODE.getKey());
			if(!StringUtils.isBlank(lcOriginCatalogueCode)) {
				totalLandCovers = getTotalLandCoversFromCatalogues(reqContext, env, lcOriginCatalogueCode, parcelIds);
			} else {
				totalLandCovers = totalLandCoversDAO
						.findTotalLandCoversByParcelIdAndSectorCode(env.getTenantId(), parcelIds, env.getReferenceDate(), env.getSectorCode(), env.getLang()).stream()
						.map(TotalLandCoversMapper.INSTANCE::entityToDto).collect(toList());
			}

			if (totalLandCovers == null || totalLandCovers.isEmpty()) {
				TotalLandCoversNotFoundException ex = new TotalLandCoversNotFoundException(Status.NOT_FOUND, Operation.GET_PARCELS_BY_SECTOR, null,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
			totalLandCovers.stream()
			.forEach(lc -> lc.setLayer_style(this.styleService.getLandCoverLayerStyle(env.getTenantId(), env.getReferenceDate(), lc.getLand_cover_code())));
		}

		return TotalLandCoversList.builder().total_land_covers_list(totalLandCovers).build();
	}

	public InfiniteListResults<ViewerBlockDetails> findInfiniteBlocksBySectorCode(ReqContext reqContext, ServiceSupportEnv env, String blockFilter) {

		List<Long> parcelIds = cllService.getPartyParcelIds(reqContext, env, null);

		return this.totalParcelsDAO.infinite(
				() -> blockDAO.findInfiniteBlocksByTenantSectorCodeAndParcelsWithFilter(env.getTenantId(), env.getSectorCode(), env.getReferenceDate(),
						parcelIds, blockFilter),
				env.getNextKey(),
				env.getPageSize())
				.map(ViewerBlockDetailsMapper.INSTANCE::entityToDto);
	}

	private Double getAreaSau(Long parcelId, String matrixCode, ServiceSupportEnv env) {

		Double result = 0.0;

		Set<String> matrixLandCoverCodes = new HashSet<>();

		List<MatrixNTT> matrix = matrixDAO.findByCode(env, matrixCode);
		if (!matrix.isEmpty()) {
			Long matrixId = matrix.get(0).getId();
			MatrixSearchParams matrixParams = MatrixSearchParams.builder().matrixId(matrixId).build();

			List<MatrixClassDetailsNTT> matrixClasses = matrixClassDetailsDAO.searchValidByMatrixIdAndClassCode(env, matrixParams);

			matrixClasses.forEach(matrixClassesDetails -> {
				List<MatrixClassLandcoversNTT> matrixClassLandCovers = matrixClassLandcoversDAO.findByMatrixIdAndClassCode(env, matrixId,
						matrixClassesDetails.getClass_code());

				if (!matrixClassLandCovers.isEmpty()) {
					matrixLandCoverCodes.addAll(matrixClassLandCovers.stream().map(t -> t.getLandcover().getCode()).collect(toList()));
				}
			});

			if (!matrixLandCoverCodes.isEmpty()) {
				List<LandCoverNTT> landCovers = landCoversDAO.findByParcelIds(env, Arrays.asList(parcelId));
				for (LandCoverNTT lc : landCovers) {
					if (matrixLandCoverCodes.contains(lc.getLand_cover_code())) {
						result += lc.getArea_sqm();
					}
				}
			}
		}

		return result;
	}

	private List<TotalLandCovers> getTotalLandCoversFromCatalogues(ReqContext reqContext, ServiceSupportEnv env, String lcOriginCatalogueCode, List<Long> parcelIds) {

		env.setIncludeGeometries(DO_NOT_INCLUDE_GEOMETRIES);
		Map<String, TotalLandCovers> totalLandCoversMap = new HashMap<>();
		
		List<ParcelDetailsNTT> parcelsDetails = parcelDetailsDAO.findParcelsInParcelListBySectorCode(env.getTenantId(), parcelIds, env.getReferenceDate(), env.getSectorCode());
		parcelsDetails.parallelStream().forEach(parcel -> {
			env.setSrs(parcel.getSrs());
			List<LandCoverWithUnits> landCovers = parcelsService.getParcelLandCoversFromCatalogue(env, lcOriginCatalogueCode, parcel.getParcel_id(), parcel.getGeom(), parcel.getSrs());
			landCovers.forEach(lc -> {
				TotalLandCovers totalLandCover = totalLandCoversMap.get(lc.getCode());
				if (totalLandCover == null) {
					totalLandCover = TotalLandCovers.builder()
							.land_cover_code(lc.getCode())
							.description(lc.getDescription())
							.total_area_sqm(Double.valueOf(lc.getArea_sqm()))
							.layer_style(lc.getLayer_style())
							.build();
				} else {
					totalLandCover.setTotal_area_sqm(totalLandCover.getTotal_area_sqm() + lc.getArea_sqm());
				}
				totalLandCoversMap.put(lc.getCode(), totalLandCover);
			});
		});
		
		return totalLandCoversMap.values().stream().collect(Collectors.toList());
	}
}
