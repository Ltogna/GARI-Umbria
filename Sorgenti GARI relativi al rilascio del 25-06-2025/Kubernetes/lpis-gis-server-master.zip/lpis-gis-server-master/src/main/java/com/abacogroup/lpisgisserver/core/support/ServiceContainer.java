package com.abacogroup.lpisgisserver.core.support;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.embeddedqueue.AbstractWorkQueue;
import com.abacogroup.lpisgisserver.LpisGisServerConfiguration;
import com.abacogroup.lpisgisserver.core.AdditionalLayersService;
import com.abacogroup.lpisgisserver.core.AnomaliesService;
import com.abacogroup.lpisgisserver.core.AreasService;
import com.abacogroup.lpisgisserver.core.BlockService;
import com.abacogroup.lpisgisserver.core.CLLService;
import com.abacogroup.lpisgisserver.core.CacheService;
import com.abacogroup.lpisgisserver.core.CataloguesService;
import com.abacogroup.lpisgisserver.core.CropPlanClientService;
import com.abacogroup.lpisgisserver.core.CrossTenantLpisClientService;
import com.abacogroup.lpisgisserver.core.EditFruitUnitsService;
import com.abacogroup.lpisgisserver.core.EditFruitUnitsSupportService;
import com.abacogroup.lpisgisserver.core.EditLandCoversService;
import com.abacogroup.lpisgisserver.core.EditLandCoversSupportService;
import com.abacogroup.lpisgisserver.core.EditOliveUnitsService;
import com.abacogroup.lpisgisserver.core.EditOliveUnitsSupportService;
import com.abacogroup.lpisgisserver.core.EditParcelsService;
import com.abacogroup.lpisgisserver.core.EditParcelsSupportService;
import com.abacogroup.lpisgisserver.core.EditSessionSupportService;
import com.abacogroup.lpisgisserver.core.EditSessionsService;
import com.abacogroup.lpisgisserver.core.EditUnitsService;
import com.abacogroup.lpisgisserver.core.EditUnitsSupportService;
import com.abacogroup.lpisgisserver.core.EditVineUnitsService;
import com.abacogroup.lpisgisserver.core.EditVineUnitsSupportService;
import com.abacogroup.lpisgisserver.core.ErrorDescriptionsService;
import com.abacogroup.lpisgisserver.core.ExternalConfigService;
import com.abacogroup.lpisgisserver.core.ExternalParcelsSourceDataService;
import com.abacogroup.lpisgisserver.core.FarmLandViewerService;
import com.abacogroup.lpisgisserver.core.FruitUnitsService;
import com.abacogroup.lpisgisserver.core.GeorasterClientService;
import com.abacogroup.lpisgisserver.core.InfoGisService;
import com.abacogroup.lpisgisserver.core.InternalConfigService;
import com.abacogroup.lpisgisserver.core.InternalService;
import com.abacogroup.lpisgisserver.core.LocationService;
import com.abacogroup.lpisgisserver.core.OliveUnitsService;
import com.abacogroup.lpisgisserver.core.ParcelsService;
import com.abacogroup.lpisgisserver.core.SectorService;
import com.abacogroup.lpisgisserver.core.StackService;
import com.abacogroup.lpisgisserver.core.StyleService;
import com.abacogroup.lpisgisserver.core.SupportService;
import com.abacogroup.lpisgisserver.core.SupportSessionAnomaliesService;
import com.abacogroup.lpisgisserver.core.TaskManagerService;
import com.abacogroup.lpisgisserver.core.UnitsService;
import com.abacogroup.lpisgisserver.core.UnitsSupportService;
import com.abacogroup.lpisgisserver.core.VectorDataLayersClientService;
import com.abacogroup.lpisgisserver.core.ViewerService;
import com.abacogroup.lpisgisserver.core.VineUnitsService;
import com.abacogroup.lpisgisserver.core.WmsService;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.pub.AdditionalLayersV1Service;
import com.abacogroup.lpisgisserver.core.pub.AreasV1Service;
import com.abacogroup.lpisgisserver.core.pub.BlocksV1Service;
import com.abacogroup.lpisgisserver.core.pub.BulkV1Service;
import com.abacogroup.lpisgisserver.core.pub.CXFV1Service;
import com.abacogroup.lpisgisserver.core.pub.CataloguesV1Service;
import com.abacogroup.lpisgisserver.core.pub.FarmLandViewerV1Service;
import com.abacogroup.lpisgisserver.core.pub.FruitUnitsV1Service;
import com.abacogroup.lpisgisserver.core.pub.MatrixV1Service;
import com.abacogroup.lpisgisserver.core.pub.OliveUnitsV1Service;
import com.abacogroup.lpisgisserver.core.pub.ParcelV1Service;
import com.abacogroup.lpisgisserver.core.pub.PublicSupportService;
import com.abacogroup.lpisgisserver.core.pub.SectorsV1Service;
import com.abacogroup.lpisgisserver.core.pub.StackV1Service;
import com.abacogroup.lpisgisserver.core.pub.UnitsV1Service;
import com.abacogroup.lpisgisserver.core.pub.VineUnitsV1Service;
import com.abacogroup.lpisgisserver.core.ts.TerScoService;
import com.abacogroup.lpisgisserver.core.ts.impl.TerScoServiceImpl;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.ntt.cache.PartyParcelNTT;
import com.abacogroup.lpisgisserver.db.ntt.cache.TempParcelNTT;
import com.abacogroup.lpisgisserver.dispatch.payload.StackPayload;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;

import jakarta.ws.rs.client.Client;
import lombok.Getter;

/**
 * Container Object to point to all LPIS service
 */
@Getter
public class ServiceContainer {
	
	//config services
	private ErrorDescriptionsService errorDescriptionsService;
	private ExternalConfigService externalConfService;
	private InternalConfigService internalConfService;
	
	// remote services
	private CLLService cllService;
	private CropPlanClientService cropPlanClientService;
	private CrossTenantLpisClientService crossTenantLpisClientService;
	private TaskManagerService taskManagerService;
	private TerScoService terScoService;
	private VectorDataLayersClientService vectorDataLayersClientService;

	// edit session services
	private EditFruitUnitsService editFruitUnitsService;
	private EditFruitUnitsSupportService editFruitUnitsSupportService;
	private EditLandCoversService editLandCoversService;
	private EditLandCoversSupportService editLandCoversSupportService;
	private EditOliveUnitsService editOliveUnitsService;
	private EditOliveUnitsSupportService editOliveUnitsSupportService;
	private EditParcelsService editParcelsService;
	private EditParcelsSupportService editParcelsSupportService;
	private EditSessionSupportService editSessionSupportService;
	private EditSessionsService editSessionsService;
	private EditUnitsService editUnitsService;
	private EditUnitsSupportService editUnitsSupportService;
	private EditVineUnitsService editVineUnitsService;
	private EditVineUnitsSupportService editVineUnitsSupportService;
	private SupportSessionAnomaliesService supportSessionAnomalyService;

	// private services
	private AdditionalLayersService additionalLayersService;
	private AnomaliesService anomaliesService;
	private AreasService areasService;
	private BlockService blockService;
	private CataloguesService cataloguesService;
	private ExternalParcelsSourceDataService externalParcelsSourceService;
	private InfoGisService infoGisService;
	private InternalService internalService;
	private LocationService locationService;
	private ParcelsService parcelsService;
	private SectorService sectorService;
	private StackService stackService;
	private StyleService styleService;
	private SupportService supportService;
	private UnitsService unitsService;
	private UnitsSupportService unitsSupportService;
	private ViewerService viewerService;
	private VineUnitsService vineUnitsService;
	private OliveUnitsService oliveUnitsService;
	private FruitUnitsService fruitUnitsService;
	private WmsService wmsService;

	// public services
	private AdditionalLayersV1Service additionalLayersServiceV1;
	private AreasV1Service areaV1Service;
	private BlocksV1Service publicBlocksService;
	private BulkV1Service bulkV1Service;
	private CataloguesV1Service cataloguesV1Service;
	private CXFV1Service cxfV1Service;
	private FarmLandViewerService farmLandViewerService;
	private FarmLandViewerV1Service farmLandViewerV1Service;
	private FruitUnitsV1Service fruitUnitsV1Service;
	private GeorasterClientService geoRasterClientService;
	private MatrixV1Service matrixV1Service;
	private ParcelV1Service publicParcelService;
	private PublicSupportService publicSupportService;
	private SectorsV1Service publicSectorsService;
	private StackV1Service stackV1Service;
	private UnitsV1Service unitsSummaryV1Service;
	private VineUnitsV1Service vineUnitsV1Service;
	private OliveUnitsV1Service oliveUnitsV1Service;

	//cache services
	private CacheService<PartyParcelNTT> cachePartyParcelService;
	private CacheService<TempParcelNTT> cacheTempParcelsService;

	public ServiceContainer(LpisGisServerConfiguration configuration, DAOContainer daoContainer, PluginEnvironment pluginEnv, AbstractWorkQueue<StackPayload, ?> stackMessageQueue, 
			WebTargetContainer webTargetContainer, Sso2Client sso2Client, Client client, String serverApplicationContextPath) {
		
		/* Services with precedence and used in other services*/
		
		initInternalServices(configuration, daoContainer);
		
		initCacheServices(daoContainer);
		
		initTerritorialScopeServices(configuration, daoContainer);
		
		initRemoteServices(configuration, daoContainer, pluginEnv, webTargetContainer, sso2Client, client);
		
		/* Services with dependecies !! must be in correct order */
		
		initAdditionalServices(daoContainer, pluginEnv);
		
		initUnitsServices(daoContainer, pluginEnv);
		
		initEditorServices(daoContainer, pluginEnv, stackMessageQueue, sso2Client, serverApplicationContextPath);
		
		initLPISServices(daoContainer, pluginEnv);
		
		initViewerServices(daoContainer, pluginEnv);
		
		initMatrixServices(daoContainer, pluginEnv);

		initPublicServices(daoContainer, pluginEnv);
		
		initBulkServices(configuration, daoContainer, pluginEnv);
		
		initNotExposedInternalServices(daoContainer, pluginEnv);
		
		initWMSServices(daoContainer, pluginEnv);
	}

	private void initNotExposedInternalServices(DAOContainer daoContainer, PluginEnvironment pluginEnv) {
		internalService = new InternalService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
	}

	private void initInternalServices(LpisGisServerConfiguration configuration, DAOContainer daoContainer) {
		internalConfService = new InternalConfigService(daoContainer, configuration);
		externalConfService = new ExternalConfigService(daoContainer);
		errorDescriptionsService = new ErrorDescriptionsService(daoContainer);
		styleService = new StyleService(daoContainer, internalConfService);
	}
	
	private void initTerritorialScopeServices(LpisGisServerConfiguration configuration, DAOContainer daoContainer) {
		terScoService = new TerScoServiceImpl(daoContainer, configuration);
	}
	
	private void initCacheServices(DAOContainer daoContainer) {
		cachePartyParcelService = new CacheService<>(daoContainer.getCachePartyParcelsDAO(), internalConfService, InternalConfigKeys.CLL_MAX_CLEAR_TIME_MIN);
		cacheTempParcelsService = new CacheService<>(daoContainer.getCacheTempParcelsDAO(), internalConfService, InternalConfigKeys.TEMP_PARCELS_CACHE_MAX_CLEAR_TIME_MIN);
	}
	
	private void initRemoteServices(LpisGisServerConfiguration configuration, DAOContainer daoContainer, PluginEnvironment pluginEnv, WebTargetContainer webTargetContainer, Sso2Client sso2Client, Client client) {
		taskManagerService = new TaskManagerService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, webTargetContainer.getTaskManagerWT(), pluginEnv);
		anomaliesService = new AnomaliesService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv, webTargetContainer.getAnomaliesRegistryWT());
		cllService = new CLLService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv, webTargetContainer.getCllWT(), cachePartyParcelService);
		geoRasterClientService = new GeorasterClientService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv, webTargetContainer.getGeoRasterWT(), configuration.getGeorasterConfig());
		infoGisService = new InfoGisService(daoContainer, geoRasterClientService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		cropPlanClientService = new CropPlanClientService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv, client, configuration.getCropPlan().getUrl());
		vectorDataLayersClientService = new VectorDataLayersClientService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv, client, configuration.getVectorDataLayers().getUrl(), configuration.getVectorDataLayers().getServiceUserName(), sso2Client);
		crossTenantLpisClientService = new CrossTenantLpisClientService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv, client, configuration.getCrossTenantLpis().getApikey());
	}
	
	private void initUnitsServices(DAOContainer daoContainer, PluginEnvironment pluginEnv) {
		unitsSupportService = new UnitsSupportService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		unitsService = new UnitsService(daoContainer, anomaliesService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		
		vineUnitsService = new VineUnitsService(daoContainer, unitsSupportService, internalConfService, externalConfService, anomaliesService, errorDescriptionsService, styleService, pluginEnv);
		oliveUnitsService = new OliveUnitsService(daoContainer, unitsSupportService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		fruitUnitsService = new FruitUnitsService(daoContainer, unitsSupportService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		unitsSummaryV1Service = new UnitsV1Service(daoContainer, unitsService, cllService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv, anomaliesService);
	}
	
	private void initWMSServices(DAOContainer daoContainer, PluginEnvironment pluginEnv) {
		wmsService = new WmsService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, cataloguesService, pluginEnv);
	}
	
	private void initAdditionalServices(DAOContainer daoContainer, PluginEnvironment pluginEnv) {
		additionalLayersService = new AdditionalLayersService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
	}
	
	private void initEditorServices(DAOContainer daoContainer, PluginEnvironment pluginEnv, AbstractWorkQueue<StackPayload, ?> stackMessageQueue, Sso2Client sso2Client, String serverApplicationContextPath) {
		cataloguesService = new CataloguesService(daoContainer, cropPlanClientService, vectorDataLayersClientService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		supportSessionAnomalyService = new SupportSessionAnomaliesService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, unitsSupportService, pluginEnv, serverApplicationContextPath);
		editSessionSupportService = new EditSessionSupportService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, terScoService, supportSessionAnomalyService, cataloguesService, pluginEnv);
		editUnitsSupportService = new EditUnitsSupportService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, editSessionSupportService, unitsSupportService, pluginEnv);
		
		editVineUnitsSupportService = new EditVineUnitsSupportService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, unitsSupportService, editUnitsSupportService,pluginEnv);
		editOliveUnitsSupportService = new EditOliveUnitsSupportService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, editUnitsSupportService,pluginEnv);
		editFruitUnitsSupportService = new EditFruitUnitsSupportService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, editUnitsSupportService, pluginEnv);
		editLandCoversSupportService = new EditLandCoversSupportService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, editSessionSupportService, editVineUnitsSupportService, editOliveUnitsSupportService, editFruitUnitsSupportService, pluginEnv);
		editParcelsSupportService = new EditParcelsSupportService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, editSessionSupportService, pluginEnv);
		
		
		editSessionsService = new EditSessionsService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, taskManagerService, editSessionSupportService, supportSessionAnomalyService, stackMessageQueue, pluginEnv, sso2Client);
		editLandCoversService = new EditLandCoversService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, editSessionSupportService,editLandCoversSupportService, cataloguesService, pluginEnv);
		editParcelsService = new EditParcelsService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, editSessionSupportService, editLandCoversService, editParcelsSupportService, editLandCoversSupportService, cataloguesService, pluginEnv);
		editVineUnitsService = new EditVineUnitsService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, editLandCoversSupportService, editVineUnitsSupportService, editUnitsSupportService, pluginEnv);
		editOliveUnitsService = new EditOliveUnitsService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, editLandCoversSupportService, editOliveUnitsSupportService, editUnitsSupportService, pluginEnv);
		editFruitUnitsService = new EditFruitUnitsService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, editLandCoversSupportService, editFruitUnitsSupportService, editUnitsSupportService, pluginEnv);
		editUnitsService = new EditUnitsService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, editLandCoversSupportService, editVineUnitsSupportService, editOliveUnitsSupportService, editFruitUnitsSupportService, pluginEnv);
	}
	
	private void initLPISServices(DAOContainer daoContainer, PluginEnvironment pluginEnv) {
		externalParcelsSourceService = new ExternalParcelsSourceDataService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		
		sectorService = new SectorService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		blockService = new BlockService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		parcelsService = new ParcelsService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, externalParcelsSourceService, pluginEnv, cacheTempParcelsService, cataloguesService);
		
		areasService = new AreasService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		
		stackService = new StackService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		
		supportService = new SupportService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		locationService = new LocationService(daoContainer, crossTenantLpisClientService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		
		cxfV1Service = new CXFV1Service(daoContainer, externalParcelsSourceService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
	}
	
	private void initViewerServices(DAOContainer daoContainer, PluginEnvironment pluginEnv) {
		farmLandViewerService = new FarmLandViewerService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, cllService, parcelsService, pluginEnv);
		viewerService = new ViewerService(daoContainer, infoGisService, parcelsService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
	}
	
	private void initMatrixServices(DAOContainer daoContainer, PluginEnvironment pluginEnv) {
		matrixV1Service = new MatrixV1Service(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
	}
	
	private void initPublicServices(DAOContainer daoContainer, PluginEnvironment pluginEnv) {
		publicParcelService = new ParcelV1Service(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, parcelsService, cllService, anomaliesService, pluginEnv);
		publicSectorsService = new SectorsV1Service(daoContainer, sectorService, blockService, parcelsService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		publicBlocksService = new BlocksV1Service(daoContainer, blockService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		publicSupportService = new PublicSupportService(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		vineUnitsV1Service = new VineUnitsV1Service(daoContainer, vineUnitsService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv); 
		oliveUnitsV1Service = new OliveUnitsV1Service(daoContainer, oliveUnitsService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		fruitUnitsV1Service = new FruitUnitsV1Service(daoContainer, fruitUnitsService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		farmLandViewerV1Service = new FarmLandViewerV1Service(daoContainer, internalConfService, externalConfService, errorDescriptionsService, styleService, farmLandViewerService, pluginEnv);		
		stackV1Service = new StackV1Service(daoContainer, stackService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		areaV1Service = new AreasV1Service(daoContainer, areasService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		additionalLayersServiceV1 = new AdditionalLayersV1Service(daoContainer, additionalLayersService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
		cataloguesV1Service = new CataloguesV1Service(daoContainer, cataloguesService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
	}
	
	private void initBulkServices(LpisGisServerConfiguration configuration, DAOContainer daoContainer, PluginEnvironment pluginEnv) {
		bulkV1Service = new BulkV1Service(configuration, daoContainer, publicParcelService, unitsSupportService, anomaliesService, internalConfService, externalConfService, errorDescriptionsService, styleService, pluginEnv);
	}
	
}
