package com.abacogroup.lpisgisserver.core.exceptions.matrix;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidMatrixClassException extends AbstractException {

	private static final long serialVersionUID = -4533854240227925747L;

	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_MATRIX_CLASS;

	public InvalidMatrixClassException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new InvalidMatrixClassExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Invalid matrix class")
	public static class InvalidMatrixClassExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -227199887252518465L;

		public InvalidMatrixClassExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
