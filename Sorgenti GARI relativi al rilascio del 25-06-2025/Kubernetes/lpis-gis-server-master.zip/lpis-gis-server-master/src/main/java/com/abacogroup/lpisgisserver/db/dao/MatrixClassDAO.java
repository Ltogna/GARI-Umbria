package com.abacogroup.lpisgisserver.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.jdbi.paging.PagingParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassesNTT;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import java.util.List;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface MatrixClassDAO extends Transactional<MatrixClassDAO>, EnhancedSqlObject {

	@SqlUpdate("INSERT INTO lpis_matrix_classes (matrix_id, code) VALUES(:matrix_id, :code)")
	void insert(@BindBean MatrixClassesNTT rs);

	@SqlQuery("select matrix_id, code from lpis_matrix_classes where matrix_id = :matrixId and code = :classCode")
	@RegisterBeanMapper(MatrixClassesNTT.class)
	MatrixClassesNTT findByIdAndCode(@Bind("matrixId") Long matrixId, @Bind("classCode") String code);

	@SqlQuery("select * from lpis_matrix_classes where matrix_id = :id")
	@RegisterBeanMapper(MatrixClassesNTT.class)
	List<MatrixClassesNTT> findByMatrixId(@Bind("id") Long id);

	@SqlQuery("select * from lpis_matrix_classes where code = :code")
	@RegisterBeanMapper(MatrixClassesNTT.class)
	List<MatrixClassesNTT> findByMatrixCode(@Bind("code") String code);

	@SqlQuery("select * from lpis_matrix_classes")
	@RegisterBeanMapper(MatrixClassesNTT.class)
	List<MatrixClassesNTT> findPagedType(PagingParams pp);

	@SqlUpdate("delete from lpis_matrix_classes where matrix_id = :id")
	void deleteByMatrixId(@Bind("id") Long id);

	@SqlUpdate("delete from lpis_matrix_classes where code = :code")
	void deleteByMatrixCode(@Bind("code") String code);

	@SqlUpdate("delete from lpis_matrix_classes where matrix_id = :id and code = :code")
	void deleteByMatrixIdAndCode(@Bind("id") Long id, @Bind("code") String code);

	@SqlQuery("    select mc.matrix_id, mc.code, null as description "
			+ "      from lpis_matrix m "
			+ "inner join lpis_matrix_classes mc "
			+ "        on m.id = mc.matrix_id "
			+ "inner join lpis_matrix_class_details mcd "
			+ "        on mc.matrix_id = mcd.matrix_id and mc.code = mcd.class_code "
			+ "     where current_timestamp between mcd.dt_insert and mcd.dt_delete "
			+ "       and m.code = :matrixCode")
	@RegisterBeanMapper(MatrixClassesNTT.class)
	List<MatrixClassesNTT> getMatrixCodeClasses(@Bind("matrixCode") String matrixCode);

	/* *********************************************** */

	@SqlQuery("select matrix_id, code, §i18n(:tenantId, 'lpis_matrix_classes', 'code', code, :lang)§ as description from lpis_matrix_classes where matrix_id = :id and code = :code")
	@RegisterBeanMapper(MatrixClassesNTT.class)
	List<MatrixClassesNTT> findByMatrixIdAndCode(@BindBean ServiceSupportEnv env, @Bind("id") Long id, @Bind("code") String code);

	@SqlQuery("\n"
			+ "select matrix_id, code, §i18n(:tenantId, 'lpis_matrix_classes', 'code', code, :lang)§ as description \n"
			+ "  from lpis_matrix_classes \n"
			+ " where matrix_id = :id \n"
			+ "   and (upper(code) like upper('%'||:code||'%') escape '$' or :code is null)\n")
	@RegisterBeanMapper(MatrixClassesNTT.class)
	List<MatrixClassesNTT> searchByMatrixIdAndCode(@BindBean ServiceSupportEnv env, @Bind("id") Long id, @Bind("code") String code);
}
