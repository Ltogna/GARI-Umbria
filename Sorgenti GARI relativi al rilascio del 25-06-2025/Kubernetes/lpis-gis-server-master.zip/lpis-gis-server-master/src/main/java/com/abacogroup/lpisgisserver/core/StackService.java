package com.abacogroup.lpisgisserver.core;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.ParcelNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionParcelIdException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidStackIdException;
import com.abacogroup.lpisgisserver.core.mappers.CampaignMapper;
import com.abacogroup.lpisgisserver.core.mappers.LandCoversMapper;
import com.abacogroup.lpisgisserver.core.mappers.StackMapper;
import com.abacogroup.lpisgisserver.core.mappers.StackParcelsMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.FruitUnitMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.OliveUnitMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.VineUnitMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.StackFruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.StackLandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.StackOliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.StackParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.StackVineUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.StacksDAO;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.ntt.CampaignNTT;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.db.ntt.StacksNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.LandCoverWithUnits;
import com.abacogroup.lpisgisserver.resources.res.LayerStyle;
import com.abacogroup.lpisgisserver.resources.res.Stack;
import com.abacogroup.lpisgisserver.resources.res.StackParcel;
import com.abacogroup.lpisgisserver.resources.res.StackParcelsLandCoversList;
import com.abacogroup.lpisgisserver.resources.res.StacksList;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class StackService extends BaseService {

	private final StacksDAO stacksDAO;
	private final StackParcelsDAO stackParcelsDAO;
	private final StackLandCoversDAO stackLandCoversDAO;
	private final StackVineUnitsDAO stackVineUnitsDAO;
	private final StackOliveUnitsDAO stackOliveUnitsDAO;
	private final StackFruitUnitsDAO stackFruitUnitsDAO;
	private final SupportDAO supportDAO;

	public StackService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService,
			StyleService styleService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.stacksDAO = dc.getStacksDAO();
		this.stackParcelsDAO = dc.getStackParcelsDAO();
		this.stackLandCoversDAO = dc.getStackLandCoversDAO();
		this.stackVineUnitsDAO = dc.getStackVineUnitsDAO();
		this.stackOliveUnitsDAO = dc.getStackOliveUnitsDAO();
		this.stackFruitUnitsDAO = dc.getStackFruitUnitsDAO();
		this.supportDAO = dc.getSupportDAO();
	}

	/**
	 * Get parcel stacks by parcel id. This method is used by client to get the list of stacks associated with a parcel
	 * 
	 * @param env - service support environment for obtaining tenant id
	 * @param parcelId - id of the parcel to get stacks for
	 * @param editStatusFilter 
	 * @param onlyValid - only return valid stacks if true otherwise return all stacks
	 * 
	 * @return list of stacks associated with the parcel or empty list if none are found or error in case of
	 */
	public StacksList getParcelStacks(ServiceSupportEnv env, Long parcelId, Boolean onlyValid) {
		StacksList result = StacksList.builder().stacks_list(new ArrayList<>()).build();

		// If parcelId is null a InvalidSessionParcelIdException is thrown.
		if (parcelId == null) {
			InvalidSessionParcelIdException ex = new InvalidSessionParcelIdException(Status.BAD_REQUEST,
					Operation.GET_PARCEL_HISTORY, ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		List<EditStatus> editStatusToExclude = internalConf.getValuesList(env.getTenantId(), EditStatus.class, InternalConfigKeys.EDIT_STATUS_TO_EXCLUDE_FROM_STACK_SEARCH.getKey());

		if(editStatusToExclude == null) {
			editStatusToExclude = new ArrayList<>();
		}

		List<StacksNTT> parcelStacks = stacksDAO.getParcelStacks(env, parcelId, editStatusToExclude, Boolean.TRUE.equals(onlyValid)? 1 : 0);



		// Adds all the parcel stacks to the result.
		if (parcelStacks != null && !parcelStacks.isEmpty()) {
			final boolean flCampaign = Boolean.TRUE.equals(internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_ENABLE_CAMPAIGN_YEAR.getKey()));
			List<CampaignNTT> campaignList = new ArrayList<>();

			if(flCampaign) {
				campaignList.addAll(supportDAO.findCampaignByCodeAndTenant(null, env));
			}

			parcelStacks.forEach(stackNTT -> {
				Stack stack = StackMapper.INSTANCE.entityToDto(stackNTT);
				if(flCampaign) {
					setNearestCampaign(stack, campaignList);
				}
				result.getStacks_list().add(stack);
			});
		}

		return result;
	}

	private void setNearestCampaign(Stack stack, List<CampaignNTT> campaignList) {		
		CampaignNTT campaignNTT = campaignList.stream() 
				.filter(c -> (c.getReference_date().toLocalDate().isBefore(stack.getReference_date().toLocalDate())
						|| c.getReference_date().toLocalDate().isEqual(stack.getReference_date().toLocalDate())))
				.findFirst()
				.orElse(null);

		if(campaignNTT != null) {
			if (campaignList.get(0).getReference_date().toLocalDate().isEqual(campaignNTT.getReference_date().toLocalDate())
					&& !campaignNTT.getReference_date().toLocalDate().isEqual(stack.getReference_date().toLocalDate())) {
				return;
			}
			stack.setCampaign(CampaignMapper.INSTANCE.entityToDto(campaignNTT));
		}		
	}

	/**
	 * Get parcels land covers from stack. This method is used by ServiceSupport. getParcelsLandCovers ()
	 * 
	 * @param env - service support environment to use
	 * @param stackId - stack id to get data from. If null data will be fetched from system
	 * 
	 * @return list of parcels land
	 */
	public StackParcelsLandCoversList getParcelsLandCoversFromStackId(ServiceSupportEnv env, Long stackId, Boolean viewAllEditStatus) {

		// Returns the initial pseudo data for the given stack id.
		if(stackId != null && stackId < 0)
			return alternativeGetInitialStackPseudoData(env, stackId);

		StackParcelsLandCoversList result = StackParcelsLandCoversList.builder()
				.parcels_list(new ArrayList<>())
				.land_covers_list(new ArrayList<>())
				.build();

		StacksNTT stackNTT = stacksDAO.findStackByIdAndTenant(stackId, env);
		// If the stack is null throw an InvalidStackIdException.
		if (stackNTT == null) {
			InvalidStackIdException ex = new InvalidStackIdException(Status.BAD_REQUEST, Operation.GET_PARCELS_FROM_STACK, ErrorField.STACK_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		env.setReferenceDate(stackNTT.getReference_date());

		Stack stack = StackMapper.INSTANCE.entityToDto(stackNTT);
		
		final boolean flCampaign = Boolean.TRUE.equals(internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_ENABLE_CAMPAIGN_YEAR.getKey()));
		if(flCampaign) {
			List<CampaignNTT> campaignList = new ArrayList<>();
			campaignList.addAll(supportDAO.findCampaignByCodeAndTenant(null, env));
			setNearestCampaign(stack, campaignList);
		}
		
		result.setStack(stack);

		List<EditStatus> editStatusToExclude = null;
		
		if(Boolean.FALSE.equals(viewAllEditStatus)) {
			editStatusToExclude = internalConf.getValuesList(env.getTenantId(), EditStatus.class, InternalConfigKeys.EDIT_STATUS_TO_EXCLUDE_FROM_STACK_SEARCH.getKey());
		}
		
		if(editStatusToExclude == null) {
			editStatusToExclude = new ArrayList<>();
		}

		List<ParcelNTT> parcels = stackParcelsDAO.getParcelsStackHistoryDetails(stackId, env.getTenantId(), editStatusToExclude);
		// Returns a ParcelNotFoundException if the parcels is null or empty.
		if (parcels == null || parcels.isEmpty()) {
			ParcelNotFoundException ex = new ParcelNotFoundException(Status.NOT_FOUND, Operation.GET_PARCELS_FROM_STACK, ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		parcels.forEach(parcel -> {
			StackParcel parcelRes = StackParcelsMapper.INSTANCE.entityToDto(parcel);

			result.getLand_covers_list().addAll(
					readLandCover(env, stackNTT, parcelRes, 
							stackLandCoversDAO.getLandCoversStackHistoryDetails(env, stackId, parcelRes.getDetails_id())
							)
					);

			result.getParcels_list().add(parcelRes);

		});

		checkForDeletedParcels(result.getParcels_list());

		return result;
	}

	private void checkForDeletedParcels(List<StackParcel> parcels) {

		List<StackParcel> parentParcels = parcels.stream().filter(p -> p.getFl_parent() == 1L)
				.collect(Collectors.toList());

		parentParcels.stream().forEach(parcel -> {
			List<StackParcel> childParcel = parcels.stream().filter(p -> p.getFl_parent() == 0L && p.getId().equals(parcel.getId()))
					.collect(Collectors.toList());

			if(childParcel == null || childParcel.isEmpty()) {
				parcels.add(StackParcel.builder()
						.id(parcel.getId())
						.parent_id(parcel.getId())
						.previous_id(parcel.getPrevious_id())
						.parcel(parcel.getParcel())
						.day_from(parcel.getDay_from())
						.day_to(parcel.getDay_to())
						.edit_status(EditStatus.DELETED)
						.area_sqm(0L)
						.last_update(parcel.getLast_update())
						.block(parcel.getBlock())
						.sector(parcel.getSector())
						.source_code(parcel.getSource_code())
						.sde_code(parcel.getSde_code())
						.client_ref(parcel.getClient_ref())
						.sde_found_codes(parcel.getSde_found_codes())
						.fl_parent(0L)
						.build());
			}
		});
	}

	/**
	 * alternative method for stack retrieval
	 * instead to use stack id, it use a parcel details pkid
	 * called when stackId is negative
	 */
	/**
	 * Find and check data for a parcel's principle. This method is an alternative to #alternativeGetInitialStackPrinciple ( ServiceSupportEnv Long ) to avoid having to re - implement this method in one place.
	 * 
	 * @param env - The environment for the request. Cannot be null.
	 * @param parcelPkId - The id of the parcel to get data for. Cannot be null.
	 * 
	 * @return A list of land cover data for the given parcel or null if there is no data for the given
	 */
	private StackParcelsLandCoversList alternativeGetInitialStackPseudoData(ServiceSupportEnv env, Long parcelPkId) {

		// parcelPkId is the negative so:
		parcelPkId = -parcelPkId;

		// initialize result
		StackParcelsLandCoversList result = StackParcelsLandCoversList.builder()
				.parcels_list(new ArrayList<>())
				.land_covers_list(new ArrayList<>())
				.build();

		// find and check pseudo stack data
		StacksNTT stack = stacksDAO.findPseudoStackByIdAndTenant(parcelPkId, env.getTenantId());
		// If the stack is null throw an InvalidStackIdException.
		if (stack == null) {
			InvalidStackIdException ex = new InvalidStackIdException(Status.BAD_REQUEST, Operation.GET_PARCELS_FROM_STACK, ErrorField.STACK_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		result.setStack(StackMapper.INSTANCE.entityToDto(stack));

		ParcelNTT parcel = stackParcelsDAO.findPseudoParcelsStackDetails(parcelPkId, env.getTenantId());
		// Returns a ParcelNotFoundException if the parcel is null.
		if (parcel == null) {
			ParcelNotFoundException ex = new ParcelNotFoundException(Status.NOT_FOUND, Operation.GET_PARCELS_FROM_STACK, ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error("Alternative Pseudo Stack: "+ex.getBody().getLogErrorMessage());

			throw ex;
		}

		StackParcel parcelRes = StackParcelsMapper.INSTANCE.entityToDto(parcel);

		result.getLand_covers_list().addAll(
				readLandCover(env, stack, parcelRes, 
						stackLandCoversDAO.getPseudoLandCoversStackDetails(env, parcelPkId)
						)
				);

		result.getParcels_list().add(parcelRes);


		return result;
	}

	/**
	 * Reads land covers from NTT parcel and returns them. This method is used by get_stack_and_cover_by_code and get_parcel_and_cover_by_code methods
	 * 
	 * @param env - service support environment to get tenant id
	 * @param stack - stack to get layer style from. Can be null
	 * @param parcelRes - parcel to get layer style from. Can be null
	 * @param landCovers - list of laptops to get from stack.
	 * 
	 * @return list of land covers
	 */
	private List<LandCoverWithUnits> readLandCover(ServiceSupportEnv env, StacksNTT stack, StackParcel parcelRes, List<LandCoverNTT> landCovers) {

		Boolean flHideLandCovers = internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_HIDE_LANDCOVERS_LAYER.getKey());
		// Returns an empty list if the land covers are hidden.
		if(Boolean.TRUE.equals(flHideLandCovers)) {
			return new ArrayList<>();
		}

		List<LandCoverWithUnits> landCoversResult = new ArrayList<>();

		// Adds all land covers to the land covers result.
		if (stack != null && parcelRes != null && landCovers != null) {
			landCovers.forEach(landcover -> {
				LandCoverWithUnits landCoverParcel = LandCoversMapper.INSTANCE.entityToDtoWithUnits(landcover);
				
				// add unit types compatibility array
				landCoverParcel.setUnit_types(supportDAO.getCompatibleUnitTypesByLandCoverCode(env.getTenantId(), landCoverParcel.getCode()));

				LayerStyle style = this.styleService.getLandCoverLayerStyle(env.getTenantId(), stack.getReference_date(), landcover.getLand_cover_code());
				landCoverParcel.setLayer_style(style);

				landCoverParcel.setParcel_details_id(parcelRes.getDetails_id());
				landCoverParcel.setParcel_id(parcelRes.getId());
				
				landCoverParcel.setVine_units(
						stackVineUnitsDAO.getVineUnitsStackHistoryDetails(env, stack.getId(), landcover.getLand_cover_details_id())
						.stream()
						.map(VineUnitMapper.INSTANCE::entityToDtoWithAptitudes)
						.collect(Collectors.toList()));
				
				landCoverParcel.setOlive_units(
						stackOliveUnitsDAO.getOliveUnitsStackHistoryDetails(env, stack.getId(), landcover.getLand_cover_details_id())
						.stream()
						.map(OliveUnitMapper.INSTANCE::entityToDto)
						.collect(Collectors.toList()));
				
				landCoverParcel.setFruit_units(
						stackFruitUnitsDAO.getFruitUnitsStackHistoryDetails(env, stack.getId(), landcover.getLand_cover_details_id())
						.stream()
						.map(FruitUnitMapper.INSTANCE::entityToDto)
						.collect(Collectors.toList()));
				
				landCoversResult.add(landCoverParcel);
			});
		}

		return landCoversResult;
	}

	public StackParcelsLandCoversList getParcelsLandCoversFromTaskId(ServiceSupportEnv env, Long taskId, Boolean viewAllEditStatus) {
		
		StacksNTT stack = stacksDAO.findStackByTaskIdAndTenant(taskId, env);
		if (stack == null) {
			InvalidStackIdException ex = new InvalidStackIdException(Status.BAD_REQUEST, Operation.GET_STACK_FROM_TASK_ID, ErrorField.TASK_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		return getParcelsLandCoversFromStackId(env, stack.getId(), viewAllEditStatus);
	}

}
