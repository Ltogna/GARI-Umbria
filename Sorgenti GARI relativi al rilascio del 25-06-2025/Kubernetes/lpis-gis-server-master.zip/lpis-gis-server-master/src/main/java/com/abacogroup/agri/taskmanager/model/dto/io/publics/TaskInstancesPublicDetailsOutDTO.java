package com.abacogroup.agri.taskmanager.model.dto.io.publics;

import java.sql.Timestamp;

import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * XXX TO BE IMPORTED FROM TASKMANAGER CLI WHEN AVAILABLE...
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TaskInstancesPublicDetailsOutDTO {
	@Schema(description = "The Task's id")
	private Long taskId;
	@Schema(description = "The Task's Title")
	private String title;
	@Schema(description = "The Task's Instructions")
	private String instructions;
	@Schema(description = "The Task's Requester")
	private String requester;
	@Schema(description = "Indicates the current state of the process related to the task")
	private String processStatus;
	@Schema(description = "The description of the current status")
	private String processStatusDescription;
	@Schema(description = "The Task's Group code")
	private String groupCode;
	@Schema(description = "The Task's Group name")
	private String groupName;
	@Schema(description = "Indicates the user assigned to this task")
	private String userIdAssignee;
	@Schema(description = "Indicates the caller user is assigned to this task")
	private Boolean assignedToMe;
	@Schema(description = "Indicates if the task is open or closed")
	private Integer flClosed;
	@Schema(description = "The Task's Due day")
	private String dueDay;
	@Schema(description = "The Task's Priority")
	private Integer priority;
	@Schema(description = "The Task's Category code")
	private String categoryCode;
	@Schema(description = "The Task's Category title")
	private String categoryTitle;
	@Schema(description = "The Task's Category description")
	private String categoryDescription;
	@Schema(description = "The Task's Type code")
	private String typeCode;
	@Schema(description = "The Task's Type title")
	private String typeTitle;
	@Schema(description = "The Task's Type description")
	private String typeDescription;
	@Schema(description = "The Type Task's associated dynamic document")
	private Document document;
	
	@Schema(description = "The id of the Task's associated details dynamic document")
	private Long detailDocumentId;
	@Schema(description = "The Task's associated details dynamic document")
	private Document detailDocument;
	@Schema(description = "The Task's associated details dynamic document definition")
	private DocumentDefinition detailDocumentDefinition;
	
	@Schema(description = "The Task's Reference Code")
	private String code;
	
	@Schema(description = "The Task's creation date")
	private Timestamp creationDate;
	
	@Schema(description = "The Task's last movement details")
	private TaskHistoryOutDTO lastMovement;

}
