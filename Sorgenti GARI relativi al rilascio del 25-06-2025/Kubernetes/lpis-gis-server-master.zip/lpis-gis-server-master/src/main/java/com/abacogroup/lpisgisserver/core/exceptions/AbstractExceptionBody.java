package com.abacogroup.lpisgisserver.core.exceptions;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public abstract class AbstractExceptionBody implements Serializable {
	
	private static final long serialVersionUID = 2264826526736408060L;

	@Schema(description = "Http response code", type = "integer")
	private Integer code;

	@Schema(description = "Exception code", implementation = ErrorCode.class)
	private ErrorCode errorCode;

	@Schema(description = "Exception message", type = "string")
	private String message;

	@Schema(description = "Operation api", implementation = Operation.class)
	private Operation operation;

	@Schema(description = "Client error field", implementation = ErrorField.class)
	private ErrorField errorField;
	
	@ArraySchema(schema = @Schema(description = "LandCovers list in session", implementation = ErrorItem.class))
	private List<ErrorItem> errors;

	protected AbstractExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
			Map<String, Map<String, String>> errorDescriptions, String lang) {
		this.code = code;
		this.errorCode = errorCode;
		this.operation = operation;
		this.errorField = errorField;

		if (errorDescriptions == null) {
			errorDescriptions = new HashMap<>();
		}
		setMessage(errorCode, lang, errorDescriptions);
	}
	
	protected AbstractExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
			List<ErrorItem> errors, Map<String, Map<String, String>> errorDescriptions, String lang) {
		this.code = code;
		this.errorCode = errorCode;
		this.operation = operation;
		this.errorField = errorField;
		this.errors = errors;
		
		if (errorDescriptions == null) {
			errorDescriptions = new HashMap<>();
		}
		setMessage(errorCode, lang, errorDescriptions);
	}

	@JsonIgnore
	public String getLogErrorMessage() {
		return new StringBuilder().append(operation).append(" : ").append(errorCode).append(" : ").append(message).toString();
	}

	public void setMessage(ErrorCode errorCode, String lang, Map<String, Map<String, String>> errorDescriptions) {
		this.message = errorDescriptions.containsKey(errorCode.toString()) && errorDescriptions.get(errorCode.toString()).containsKey(lang)
				? errorDescriptions.get(errorCode.toString()).get(lang)
				: errorCode.getDescription();
	}
}
