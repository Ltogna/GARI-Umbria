package com.abacogroup.lpisgisserver.bundles;

import java.io.File;
import java.nio.file.Path;
import java.util.Optional;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.lpisgisserver.bundles.models.LandCoverConfigListMessage;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.LandCoverConfigsDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverConfigNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

public class LandCoverConfigMessageProcessor extends AbstractMessageProcessor {

	protected LandCoverConfigsDAO landCoverConfigsDAO;
	private final ObjectMapper objectMapper;

	private static final Logger log = LoggerFactory.getLogger(CatalogueMessageProcessor.class);

	public LandCoverConfigMessageProcessor(DAOContainer dc) {
		super(dc);
		this.landCoverConfigsDAO = dc.getLandCoverConfigsDAO();
		objectMapper = new ObjectMapper();
	}

	@Override
	public String getDomainName() {
		return "landcover-configs";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> deleteLandCoverConfigMessage(message.getTenantId(), file));

		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
				&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> insertOrUpdateLandCoverConfigMessage(message.getTenantId(), file));
	}

	private void insertOrUpdateLandCoverConfigMessage(String tenantId, File file) {
		try {
			LandCoverConfigListMessage landCoverConfigListMessage = objectMapper.readValue(file, LandCoverConfigListMessage.class);

			if (landCoverConfigListMessage == null || landCoverConfigListMessage.getLand_cover_configs() == null) {
				return;
			}

			landCoverConfigListMessage.getLand_cover_configs().stream()
			.forEach(msg -> {
				LandCoverConfigNTT landCoverConfigNTT = landCoverConfigsDAO.findByLandCoverCodeAndKey(tenantId, msg.getLand_cover_code(), msg.getKey());
				
						LandCoverConfigNTT toInsertOrUpdate = LandCoverConfigNTT.builder()
								.landCoverCode(msg.getLand_cover_code())
								.key(msg.getKey())
								.value(msg.getValue())
								.build();
				
				if(landCoverConfigNTT == null) {
					landCoverConfigsDAO.insert(tenantId, toInsertOrUpdate);
				} else {
					landCoverConfigsDAO.update(tenantId, toInsertOrUpdate);
				}
			});
			
		} catch (Exception e) {
			log.error("Error processing file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}
	}	

	private void deleteLandCoverConfigMessage(String tenantId, File file) {
		try {
			LandCoverConfigListMessage landCoverConfigListMessage = objectMapper.readValue(file, LandCoverConfigListMessage.class);

			if (landCoverConfigListMessage == null || landCoverConfigListMessage.getLand_cover_configs() == null) {
				return;
			}
			
			landCoverConfigListMessage.getLand_cover_configs().stream()
			.forEach(msg -> {
				Optional.ofNullable(landCoverConfigsDAO.findByLandCoverCodeAndKey(tenantId, msg.getLand_cover_code(), msg.getKey()))
				.ifPresentOrElse(
						conf -> landCoverConfigsDAO.delete(tenantId, conf), 
						() -> {
							throw new IllegalArgumentException("Configuration with key " + msg.getKey() + " and land cover code " + msg.getLand_cover_code() + " not found.");
						});
			});
			
		} catch (Exception e) {
			log.error("Error processing file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}
	}	


}
