package com.abacogroup.lpisgisserver.core.exceptions;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ErrorItem {
	
	@Schema(description = "Exception code", implementation = ErrorCode.class)
	private ErrorCode errorCode;

	@Schema(description = "Exception message", type = "string")
	private String message;

	@Schema(description = "Client error field", implementation = ErrorField.class)
	private ErrorField errorField;
	
}
