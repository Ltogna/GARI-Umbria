package com.abacogroup.lpisgisserver.core.exceptions.sector;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class SectorIdsNotFoundException extends AbstractException {

	private static final long serialVersionUID = 9119309576212333739L;

	private static final ErrorCode ERROR_CODE = ErrorCode.SECTOR_IDS_NOT_FOUND;

	public SectorIdsNotFoundException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new SectorIdsNotFoundExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Some sector id not found")
	public static class SectorIdsNotFoundExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 7615082862162717311L;

		public SectorIdsNotFoundExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
