package com.abacogroup.lpisgisserver.core.enums;

public enum OverlayType {
	INTERSECTION,
	DIFFERENCE
}
