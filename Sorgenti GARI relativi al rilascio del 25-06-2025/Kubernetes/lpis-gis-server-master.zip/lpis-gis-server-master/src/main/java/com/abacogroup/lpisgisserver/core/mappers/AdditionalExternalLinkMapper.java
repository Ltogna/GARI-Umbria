package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.AdditionalExternalLinkNTT;
import com.abacogroup.lpisgisserver.resources.res.AdditionalExternalLink;

@Mapper
public interface AdditionalExternalLinkMapper {

	AdditionalExternalLinkMapper INSTANCE = Mappers.getMapper(AdditionalExternalLinkMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	@Mapping(target = "module", source = "softwareModule")
	@Mapping(target = "view", source = "moduleView")
	@Mapping(target = "type", source = "linkType")
	AdditionalExternalLink entityToDto(AdditionalExternalLinkNTT entity);
	
	@Mapping(target = "flVisible", expression = "java(dto.getVisible() ? 1 : 0)")
	@Mapping(target = "softwareModule", source = "module")
	@Mapping(target = "moduleView", source = "view")
	@Mapping(target = "linkType", source = "type")
	AdditionalExternalLinkNTT dtoToEntity(AdditionalExternalLink dto);
}
