package com.abacogroup.lpisgisserver.bundles;

import com.abacogroup.lpisgisserver.db.dao.DAOContainer;

public class LandCoversCodeMessageProcessor extends AbstractCodeMessageProcessor {

	private static final String TABLE_NAME = "lpis_landcovers";
	private static final String FIELD_NAME = "code";

	public LandCoversCodeMessageProcessor(DAOContainer dc) {
		super(dc);
	}

	@Override
	public String getDomainName() {
		return "landcovers-codes";
	}

	@Override
	protected String getFieldName() {
		return FIELD_NAME;
	}

	@Override
	protected String getTableName() {
		return TABLE_NAME;
	}

	@Override
	protected void checkCode(String tenantId, String code) {
		if (supportDAO.getLandCoversCodeByTenantAndCode(tenantId, code) == null) {
			supportDAO.insertLandCoversCode(tenantId, code);
		}
	}

	@Override
	protected void deleteCode(String tenantId, String code) {
		if (supportDAO.getLandCoversCodeByTenantAndCode(tenantId, code) != null) {
			supportDAO.deleteLandCoverCode(tenantId, code);
		}
	}

}
