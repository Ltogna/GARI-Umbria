package com.abacogroup.lpisgisserver.core.mappers.pub.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.UnitCodeNTT;
import com.abacogroup.lpisgisserver.resources.res.pub.units.UnitCodeV1;

@Mapper
public interface UnitCodeV1Mapper {

	UnitCodeV1Mapper INSTANCE = Mappers.getMapper(UnitCodeV1Mapper.class);
	
	@InheritInverseConfiguration
	UnitCodeV1 entityToDto(UnitCodeNTT entity);
	
	@Mapping(target = "typeCode", ignore = true)
	UnitCodeNTT dtoToEntity(UnitCodeV1 dto);
}
