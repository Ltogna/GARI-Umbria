package com.abacogroup.lpisgisserver;

import com.abacogroup.dropwizard.auth.oidc.config.CacheConfig;
import com.abacogroup.lpisgisserver.core.config.AnomaliesRegistryConfig;
import com.abacogroup.lpisgisserver.core.config.CrossTenantLpisConfig;
import com.abacogroup.lpisgisserver.core.config.CropPlanConfig;
import com.abacogroup.lpisgisserver.core.config.CustomerLandLinkConfig;
import com.abacogroup.lpisgisserver.core.config.Sso2Config;
import com.abacogroup.lpisgisserver.core.config.TaskManagerConfig;
import com.abacogroup.lpisgisserver.core.config.VectorDataLayersConfig;
import com.abacogroup.lpisgisserver.core.config.georaster.GeorasterConfig;
import com.abacogroup.lpisgisserver.core.config.rabbitmq.RabbitmqConfig;
import com.abacogroup.territorialscopecache.cache.core.models.TerScoCacheConfig;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.Configuration;
import io.dropwizard.db.DataSourceFactory;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LpisGisServerConfiguration extends Configuration {

	private boolean cors;

	private String variant;

	@Valid
	@NotNull
	@JsonProperty("database")
	private DataSourceFactory database;

	private Sso2Config sso2;

	private TaskManagerConfig taskmanager;

	private AnomaliesRegistryConfig anomaliesRegistry;
	
	private CustomerLandLinkConfig cll;
	
	private CropPlanConfig cropPlan;
	
	private VectorDataLayersConfig vectorDataLayers;

	private boolean activateAuthorizationFilter;

	private CacheConfig authorizationCacheConfig;

	private RabbitmqConfig rabbitmqConfig;
	
	private GeorasterConfig georasterConfig;
	
	private CrossTenantLpisConfig crossTenantLpis;

	private String bundlesConfigLocation;

	private String applicationConfigFile;
	
	@Valid
	@NotNull
	@JsonProperty("jerseyClient")
	private JerseyClientConfiguration jerseyClient = new JerseyClientConfiguration();
	
	private TerScoCacheConfig terScoConfig;

}
