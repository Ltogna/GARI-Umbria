package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class UpdateBufferTooLargeException extends AbstractException {

	private static final long serialVersionUID = 7351522661166581421L;

	private static final ErrorCode ERROR_CODE = ErrorCode.UPDATE_BUFFER_TOO_LARGE;

	public UpdateBufferTooLargeException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new UpdateBufferTooLargeExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Buffer is too large")
	public static class UpdateBufferTooLargeExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 27564052468990212L;

		public UpdateBufferTooLargeExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
