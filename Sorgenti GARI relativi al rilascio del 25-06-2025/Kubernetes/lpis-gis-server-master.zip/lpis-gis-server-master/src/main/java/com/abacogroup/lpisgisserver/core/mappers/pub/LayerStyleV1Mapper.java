package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.resources.res.LayerStyle;
import com.abacogroup.lpisgisserver.resources.res.pub.LayerStyleV1;

@Mapper
public interface LayerStyleV1Mapper {

	LayerStyleV1Mapper INSTANCE = Mappers.getMapper(LayerStyleV1Mapper.class);

	@InheritInverseConfiguration()
	LayerStyleV1 ToResponseV1(LayerStyle entity);

}
