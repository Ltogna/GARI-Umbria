package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineAptitudeNTT;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineAptitude;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineAptitudeWithErrors;

@Mapper(uses = { AbsoluteDateMapper.class, DoigtMapper.class, VineyardMapper.class })
public interface VineAptitudesMapper {

	VineAptitudesMapper INSTANCE = Mappers.getMapper(VineAptitudesMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "preventClaim", expression = "java(entity.getFlPreventClaim() == null ? null : entity.getFlPreventClaim() == 1)")
	@Mapping(target = "preventSuitability", expression = "java(entity.getFlPreventSuitability() == null ? null : entity.getFlPreventSuitability() == 1)")
	@Mapping(target = "preventTypology", expression = "java(entity.getFlPreventTypology() == null ? null : entity.getFlPreventTypology() == 1)")
	@Mapping(source = "aptitudeId", target = "id")
	VineAptitude entityToDto(VineAptitudeNTT entity);
	
	@InheritInverseConfiguration
	@Mapping(target = "preventClaim", expression = "java(entity.getFlPreventClaim() == null ? null : entity.getFlPreventClaim() == 1)")
	@Mapping(target = "preventSuitability", expression = "java(entity.getFlPreventSuitability() == null ? null : entity.getFlPreventSuitability() == 1)")
	@Mapping(target = "preventTypology", expression = "java(entity.getFlPreventTypology() == null ? null : entity.getFlPreventTypology() == 1)")
	@Mapping(source = "aptitudeId", target = "id")
	@Mapping(target = "errorList", ignore = true)
	VineAptitudeWithErrors entityToDtoWithErrors(VineAptitudeNTT entity);

	
	@Mapping(target = "flPreventTypology", expression = "java(dto.getPreventTypology() ? 1 : 0)")
	@Mapping(target = "flPreventClaim", expression = "java(dto.getPreventClaim() ? 1 : 0)")
	@Mapping(target = "flPreventSuitability", expression = "java(dto.getPreventSuitability() ? 1 : 0)")
	@Mapping(target = "editId", ignore = true)
	@Mapping(target = "editUnitId", ignore = true)
	@Mapping(target = "editStatus", ignore = true)
	@Mapping(target = "pkid", ignore = true)
	@Mapping(source = "id", target = "aptitudeId")
	VineAptitudeNTT dtoToEntity(VineAptitude dto);
	
}
