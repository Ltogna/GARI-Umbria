package com.abacogroup.lpisgisserver.core.models.cll.api.v1;

import org.jdbi.v3.core.mapper.reflect.ColumnName;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class TitleTypeV1 {

	private Long id;

	private String code;

	@JsonIgnore
	private int flDayToReq;

	@ColumnName("fl_day_to_req")
	private boolean dayToReq;

	private String i18nCode;

}