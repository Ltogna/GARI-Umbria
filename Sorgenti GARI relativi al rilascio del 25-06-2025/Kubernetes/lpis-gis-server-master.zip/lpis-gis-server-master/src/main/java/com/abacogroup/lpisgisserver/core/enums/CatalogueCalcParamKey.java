package com.abacogroup.lpisgisserver.core.enums;

public enum CatalogueCalcParamKey {
	REFERENCEDATE,
    SECTORCODE,
    LANG,
    OTHER;
	
	public static CatalogueCalcParamKey fromString(String key) {
        try {
            return valueOf(key.toUpperCase().replace("_", ""));
        } catch (IllegalArgumentException e) {
            return OTHER;
        }
    }
}
