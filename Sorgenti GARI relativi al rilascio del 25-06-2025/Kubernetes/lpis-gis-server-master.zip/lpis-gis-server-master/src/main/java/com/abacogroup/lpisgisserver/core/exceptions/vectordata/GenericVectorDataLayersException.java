package com.abacogroup.lpisgisserver.core.exceptions.vectordata;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class GenericVectorDataLayersException extends AbstractException {

	private static final long serialVersionUID = -7252203008674918953L;

	private static final ErrorCode ERROR_CODE = ErrorCode.GENERIC_VECTOR_DATA_LAYERS_ERROR;

	public GenericVectorDataLayersException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new GenericCropPlanExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Generic vector data layers error!")
	public static class GenericCropPlanExceptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = 372367780010931447L;

		public GenericCropPlanExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
