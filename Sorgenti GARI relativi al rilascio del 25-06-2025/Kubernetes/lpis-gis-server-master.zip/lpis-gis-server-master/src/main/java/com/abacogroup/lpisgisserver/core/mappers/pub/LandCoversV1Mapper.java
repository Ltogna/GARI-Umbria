package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.resources.res.LandCoverWithUnits;
import com.abacogroup.lpisgisserver.resources.res.pub.LandCoverV1;

@Mapper(uses = {AbsoluteDateMapper.class, LayerStyleV1Mapper.class, VineUnitV1Mapper.class, OliveUnitV1Mapper.class} )
public interface LandCoversV1Mapper {

	LandCoversV1Mapper INSTANCE = Mappers.getMapper(LandCoversV1Mapper.class);

	@InheritInverseConfiguration()
	@Mapping(target = "class_code", ignore = true)
	@Mapping(source = "details_id", target = "land_cover_details_id")
	LandCoverV1 toResponseV1(LandCoverWithUnits entity);

	@Mapping(source = "land_cover_id", target = "id")
	@Mapping(source = "land_cover_code", target = "code")
	@Mapping(source = "land_cover_description", target = "description")
	@Mapping(source = "layerStyle", target = "layer_style")
	@Mapping(target = "class_code", ignore = true)
	@Mapping(target = "unit_types", ignore = true)
	@Mapping(target = "vine_units", ignore = true)
	@Mapping(target = "olive_units", ignore = true)
	@Mapping(target = "fruit_units", ignore = true)
	@Mapping(target = "total_unit_area_sqm", ignore = true)
	LandCoverV1 entityToDto(LandCoverNTT entity);
}
