
package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface EditLandCoversDAO extends Transactional<EditLandCoversDAO>, EnhancedSqlObject {

	@SqlQuery("§select_nextval(lpis_edit_land_covers_sequence)§")
	Long nextSequenceVal();

	@SqlQuery("select coalesce(min(land_cover_id), 0) - 1 from lpis_edit_land_covers where land_cover_id < 1")
	Long nextNewLandCoverIdVal();

	@SqlUpdate("INSERT INTO lpis_edit_land_covers (pkid, session_uuid, area_sqm, land_cover_code, geom, land_cover_id, edit_parcel_id, edit_status, parent_id) "
			+ "VALUES(:edit_id, :sessionId, :area_sqm, :land_cover_code, :geom, :land_cover_id, :edit_parcel_id, :edit_status, :parent_id)")
	void insert(@BindBean LandCoverNTT rs, @Bind("sessionId") String sessionId);

	@SqlQuery("select elc.pkid as edit_id, \n"
			+ "       elc.land_cover_id, \n"
			+ "       elc.edit_parcel_id, \n"
			+ "       coalesce(dlc.day_from, :referenceDate) as day_from, \n"
			+ "       coalesce(dlc.day_to, '99991231') as day_to, \n"
			+ "       elc.area_sqm, \n"
			+ "       elc.land_cover_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', elc.land_cover_code, :lang)§, elc.land_cover_code) as description, \n"
			+ "       elc.geom, \n"
			+ "       elc.edit_status, \n"
			+ "       elc.parent_id, \n"
			+ "       dlc.dt_insert as last_update"
			+ "  from lpis_edit_land_covers elc \n"
			+ "  left join lpis_parcel_lc_details dlc on elc.land_cover_id = dlc.land_cover_id \n"
			+ "        and §current_timestamp§ between dlc.dt_insert and dlc.dt_delete \n"
			+ "        and :referenceDate between dlc.day_from and dlc.day_to \n"
			+ " where edit_parcel_id = :edit_parcel_id \n")
	@RegisterBeanMapper(LandCoverNTT.class)
	List<LandCoverNTT> findByEditParcelId(
			@BindBean ServiceSupportEnv env,
			@Bind("edit_parcel_id") Long parcelId);

	@SqlUpdate("update lpis_edit_land_covers \n"
			+ "   set edit_parcel_id = :edit_parcel_id, \n"
			+ "       area_sqm = :area_sqm, \n"
			+ "       land_cover_code = :land_cover_code, \n"
			+ "       geom = :geom, \n"
			+ "       land_cover_id = :land_cover_id, \n"
			+ "       edit_status = :edit_status \n"
			+ " where pkid = :edit_id")
	void update(@BindBean LandCoverNTT rs);

	@SqlUpdate("update lpis_edit_land_covers \n"
			+ "   set area_sqm = :area_sqm, \n"
			+ "       geom = :geom, \n"
			+ "       land_cover_code = :land_cover_code, \n"
			+ "       edit_status = :edit_status \n"
			+ " where land_cover_id = :land_cover_id and session_uuid = :sessionId")
	@RegisterBeanMapper(LandCoverNTT.class)
	void updateByLandCoverId(@BindBean LandCoverNTT rs, @Bind("sessionId") String sessionId);

	@SqlUpdate("update lpis_edit_land_covers \n"
			+ "   set area_sqm = :area_sqm, "
			+ "       geom = :geom, \n"
			+ "       edit_parcel_id = :edit_parcel_id, \n"
			+ "       edit_status = :edit_status \n"
			+ " where land_cover_id = :land_cover_id and session_uuid = :sessionId")
	@RegisterBeanMapper(LandCoverNTT.class)
	void updateGeometryAndParcelByLandCoverId(@BindBean LandCoverNTT rs, @Bind("sessionId") String sessionId);

	@SqlUpdate("update lpis_edit_land_covers \n"
			+ "   set land_cover_code = :land_cover_code, \n"
			+ "       edit_status = :edit_status \n"
			+ " where land_cover_id = :land_cover_id and session_uuid = :sessionId")
	@RegisterBeanMapper(LandCoverNTT.class)
	void updateLandCoverCodeByLandCoverId(@BindBean LandCoverNTT rs, @Bind("sessionId") String sessionId);

	@SqlUpdate("delete from lpis_edit_land_covers where session_uuid = :sessionId")
	void deleteBySessionId(@Bind("sessionId") String sessionId);

	@SqlUpdate("delete from lpis_edit_land_covers where session_uuid = :sessionId and land_cover_id = :landCoverId")
	void deleteById(@Bind("sessionId") String sessionId, @Bind("landCoverId") Long landCoverId);

	@SqlQuery("\n"
			+ "select lelc.pkid as edit_id, \n"
			+ "       lelc.land_cover_id, \n"
			+ "       lelc.edit_parcel_id, \n"
			+ "       lelc.area_sqm, \n"
			+ "       lelc.land_cover_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', lelc.land_cover_code, :lang)§, lelc.land_cover_code) as land_cover_description,  "
			+ "       lelc.geom, \n"
			+ "       lelc.parent_id, \n"
			+ "       lelc.edit_status \n"
			+ "  from lpis_edit_land_covers lelc \n"
			+ " inner join lpis_edit_parcels lep on lelc.session_uuid = lep.session_uuid and lelc.edit_parcel_id = lep.id \n"
			+ " where lelc.session_uuid = :sessionId \n"
			+ "   and (:parcelId is null or lep.parcel_id = :parcelId) \n"
			+ "   and §geom_have_interactions(lelc.geom, :touchingGeometry)§ \n"
			+ "")
	@RegisterBeanMapper(LandCoverNTT.class)
	public List<LandCoverNTT> getEditLandCoversWithInteraction(
			@BindBean ServiceSupportEnv env,
			@Bind("touchingGeometry") Geometry touchingGeometry,
			@Bind("parcelId") Long parcelId);

	@SqlQuery("select lpld.pkid as land_cover_details_id, \n"
			+ "       lpld.land_cover_id, \n"
			+ "       lplc.parcel_id, \n"
			+ "       lpld.srs, \n"
			+ "       lpld.geom, \n"
			+ "       lpld.area_sqm, \n"
			+ "       lpld.land_cover_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', lpld.land_cover_code, :lang)§, lpld.land_cover_code) as land_cover_description,  "
			+ "       lpld.world_geom, \n"
			+ "       lpld.day_from, \n"
			+ "       lpld.day_to, \n"
			+ "       null as parent_id, \n"
			+ "       'NOT_IN_EDIT' as edit_status, \n"
			+ "       lpld.dt_insert as last_update"
			+ "  from lpis_lock_parcels lp \n"
			+ " inner join lpis_parcel_land_covers lplc on lp.parcel_id = lplc.parcel_id \n"
			+ " inner join lpis_parcel_lc_details lpld on lplc.id = lpld.land_cover_id \n"
			+ " left join lpis_edit_land_covers lelc on lp.session_uuid = lelc.session_uuid and lelc.land_cover_id = lplc.id \n"
			+ " where §current_timestamp§ between lpld.dt_insert and lpld.dt_delete \n"
			+ "   and lp.session_uuid = :sessionId \n"
			+ "   and lelc.land_cover_id is null \n"
			+ "   and lpld.srs = :srs \n"
			+ "   and (:parcelId is null or lplc.parcel_id = :parcelId) \n"
			+ "   and :referenceDate between lpld.day_from and lpld.day_to \n"
			+ "   and §geom_have_interactions(lpld.geom, :touchingGeometry)§ \n")
	@RegisterBeanMapper(LandCoverNTT.class)
	public List<LandCoverNTT> getNonEditLandCoversWithInteraction(
			@BindBean ServiceSupportEnv env,
			@Bind("touchingGeometry") Geometry touchingGeometry,
			@Bind("parcelId") Long parcelId);

	@SqlQuery("select pkid as edit_id, \n"
			+ "       edit_parcel_id, \n"
			+ "       land_cover_id, \n"
			+ "       land_cover_code, \n"
			+ "       area_sqm, \n"
			+ "       geom, \n"
			+ "       parent_id, \n"
			+ "       edit_status \n"
			+ "  from lpis_edit_land_covers \n"
			+ " where land_cover_id  in (<landCoverIds>) \n")
	@RegisterBeanMapper(LandCoverNTT.class)
	public List<LandCoverNTT> getInEditingPolygons(
			@BindList("landCoverIds") List<Long> landCoverIds);

	@SqlQuery("select lpld.land_cover_id, \n"
			+ "       lpld.pkid as land_cover_details_id, \n"
			+ "       lpld.srs, \n"
			+ "       lpld.geom, \n"
			+ "       lpld.area_sqm, \n"
			+ "       lpld.world_geom, \n"
			+ "       lpld.day_from, \n"
			+ "       lpld.day_to, \n"
			+ "       lpld.land_cover_code, \n"
			+ "       lplc.parcel_id, \n"
			+ "       'NOT_IN_EDIT' as edit_status, \n"
			+ "       null as parent_id, \n"
			+ "       lpld.dt_insert as last_update"
			+ "  from lpis_parcel_land_covers lplc \n"
			+ " inner join lpis_parcel_lc_details lpld on lplc.id = lpld.land_cover_id \n"
			+ " where lpld.land_cover_id in (<landCoverIds>) \n"
			+ "   and not exists (select 1 from lpis_edit_land_covers lelc where lelc.land_cover_id = lpld.land_cover_id) \n"
			+ "   and §current_timestamp§ between lpld.dt_insert and lpld.dt_delete \n"
			+ "   and :referenceDate between lpld.day_from and lpld.day_to ")
	@RegisterBeanMapper(LandCoverNTT.class)
	public List<LandCoverNTT> getNotInEditingPolygons(
			@Bind("referenceDate") AbsoluteDate referenceDate,
			@BindList("landCoverIds") List<Long> landCoverIds);

	@SqlQuery("\n"
			+ "select elc.pkid as edit_id, \n"
			+ "       elc.land_cover_id, \n"
			+ "       ep.parcel_id, \n"
			+ "       null as land_cover_details_id, \n"
			+ "       elc.land_cover_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', elc.land_cover_code, :lang)§, elc.land_cover_code) as land_cover_description, \n"
			+ "       elc.area_sqm, \n"
			+ "       coalesce(pld.day_from, :referenceDate) as day_from, \n"
			+ "       coalesce(pld.day_to, '99991231') as day_to, \n"
			+ "       ep.srs, \n"
			+ "       elc.geom, \n"
			+ "       elc.edit_status, \n"
			+ "       elc.parent_id, \n"
			+ "       coalesce(matrix.fill_rgba, :defaultLCFillRGBA) as style_fill_rgba, \n"
			+ "       coalesce(matrix.line_rgba, :defaultLCLineRGBA) as style_line_rgba, \n"
			+ "       coalesce(matrix.line_thick, :defaultLCLineThick) as style_line_thick \n"
			+ "  from lpis_edit_land_covers elc \n"
			+ " inner join lpis_edit_parcels ep on  elc.session_uuid = ep.session_uuid and elc.edit_parcel_id = ep.id \n"
			+ "  left join ( \n"
			+ "        select m.tenant_id, m.id, m.code, mcd.class_code, fill_rgba, line_rgba, line_thick, land_cover_code \n"
			+ "         from lpis_matrix m \n"
			+ "        inner join lpis_matrix_class_details mcd on m.id = mcd.matrix_id \n"
			+ "        inner join lpis_matrix_class_landcovers mcld on m.id = mcld.matrix_id and mcd.class_code = mcld.class_code \n"
			+ "        where m.code = :landCoverStyleMatrixCode \n"
			+ "          and m.tenant_id = :tenantId \n"
			+ "          and §current_timestamp§ between mcd.dt_insert and mcd.dt_delete \n"
			+ "          and §current_timestamp§ between mcld.dt_insert and mcld.dt_delete \n"
			+ "          and :referenceDate between mcd.day_from and mcd.day_to \n"
			+ "          and :referenceDate between mcld.day_from and mcld.day_to) matrix on elc.land_cover_code = matrix.land_cover_code \n"
			+ "  left join lpis_parcel_lc_details pld on pld.land_cover_id = elc.land_cover_id \n"
			+ "          and :referenceDate between pld.day_from and pld.day_to \n"
			+ "          and §current_timestamp§ between pld.dt_insert and pld.dt_delete \n"
			+ " where ep.session_uuid = :sessionId \n"
			+ "   and (:parcelId is null or ep.parcel_id = :parcelId) \n"
			+ " order by substr('000000000000' || elc.land_cover_code, length(elc.land_cover_code), length(elc.land_cover_code) + 12), elc.area_sqm desc \n")
	@RegisterBeanMapper(LandCoverNTT.class)
	List<LandCoverNTT> findInEditBySessionId(
			@BindBean ServiceSupportEnv env,
			@Bind("parcelId") Long parcelId);

	@SqlQuery("\n"
			+ "select lc.id as land_cover_id, \n"
			+ "       lp.parcel_id, \n"
			+ "       lcd.pkid as land_cover_details_id, \n"
			+ "       lcd.land_cover_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', lcd.land_cover_code, :lang)§, lcd.land_cover_code) as land_cover_description, \n"
			+ "       lcd.area_sqm, \n"
			+ "       lcd.day_from, \n"
			+ "       lcd.day_to, \n"
			+ "       lcd.srs, \n"
			+ "       lcd.geom, \n"
			+ "       lcd.world_geom, \n"
			+ "       'NOT_IN_EDIT' as edit_status, \n"
			+ "       null as parent_id, \n"
			+ "       lcd.dt_insert as last_update, \n"
			+ "       coalesce(matrix.fill_rgba, :defaultLCFillRGBA) as style_fill_rgba, \n"
			+ "       coalesce(matrix.line_rgba, :defaultLCLineRGBA) as style_line_rgba, \n"
			+ "       coalesce(matrix.line_thick, :defaultLCLineThick) as style_line_thick \n"
			+ "  from lpis_parcel_land_covers lc \n"
			+ " inner join lpis_lock_parcels lp on lc.parcel_id = lp.parcel_id \n"
			+ " inner join lpis_parcel_lc_details lcd on lc.id = lcd.land_cover_id \n"
			+ "  left join ( \n"
			+ "        select m.tenant_id, m.id, m.code, mcd.class_code, fill_rgba, line_rgba, line_thick, land_cover_code \n"
			+ "         from lpis_matrix m \n"
			+ "        inner join lpis_matrix_class_details mcd on m.id = mcd.matrix_id \n"
			+ "        inner join lpis_matrix_class_landcovers mcld on m.id = mcld.matrix_id and mcd.class_code = mcld.class_code \n"
			+ "        where m.code = :landCoverStyleMatrixCode \n"
			+ "          and m.tenant_id = :tenantId \n"
			+ "          and §current_timestamp§ between mcd.dt_insert and mcd.dt_delete \n"
			+ "          and §current_timestamp§ between mcld.dt_insert and mcld.dt_delete \n"
			+ "          and :referenceDate between mcd.day_from and mcd.day_to \n"
			+ "          and :referenceDate between mcld.day_from and mcld.day_to) matrix on lcd.land_cover_code = matrix.land_cover_code \n"
			+ " where lp.session_uuid = :sessionId \n"
			+ "   and not exists (select 1 from lpis_edit_land_covers elc where elc.land_cover_id = lc.id or elc.parent_id = lc.id) \n"
			+ "   and §current_timestamp§ between lcd.dt_insert and lcd.dt_delete \n"
			+ "   and :referenceDate between lcd.day_from and lcd.day_to \n"
			+ "   and (:parcelId is null or lp.parcel_id = :parcelId) \n"
			+ " order by substr('000000000000' || lcd.land_cover_code, length(lcd.land_cover_code), length(lcd.land_cover_code) + 12), lcd.area_sqm desc \n")
	@RegisterBeanMapper(LandCoverNTT.class)
	List<LandCoverNTT> findNotInEditBySessionId(
			@BindBean ServiceSupportEnv env,
			@Bind("parcelId") Long parcelId);

	@SqlQuery("\n"
			+ "select lelc.pkid as edit_id, \n"
			+ "       lep.parcel_id, \n"
			+ "       lelc.area_sqm, \n"
			+ "       lelc.land_cover_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', lelc.land_cover_code, :lang)§, lelc.land_cover_code) as land_cover_description, \n"
			+ "       lelc.edit_parcel_id, \n"
			+ "       lelc.land_cover_id, \n"
			+ "       lelc.geom, \n"
			+ "       lelc.parent_id, \n"
			+ "       lelc.edit_status \n"
			+ "  from lpis_edit_land_covers lelc \n"
			+ " inner join lpis_edit_parcels lep on lelc.session_uuid = lep.session_uuid and lelc.edit_parcel_id = lep.id \n"
			+ " where lep.session_uuid = :sessionId \n"
			+ "   and lelc.land_cover_id in (<landCoverIds>) \n")
	@RegisterBeanMapper(LandCoverNTT.class)
	List<LandCoverNTT> getEditLandCoversFromLandCoverIdsBySession(
			@BindBean ServiceSupportEnv env,
			@BindList("landCoverIds") List<Long> landCoverIds);

	@SqlQuery("\n"
			+ "select lpld.pkid as land_cover_details_id, \n"
			+ "       lpld.land_cover_id, \n"
			+ "       lplc.parcel_id, \n"
			+ "       lpld.area_sqm, \n"
			+ "       lpld.land_cover_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', lpld.land_cover_code, :lang)§, lpld.land_cover_code) as land_cover_description, \n"
			+ "       lpld.day_from, \n"
			+ "       lpld.day_to, \n"
			+ "       lpld.geom, \n"
			+ "       lpld.world_geom, \n"
			+ "       null as parent_id, \n"
			+ "       'NOT_IN_EDIT' as edit_status, \n"
			+ "       lpld.dt_insert as last_update"
			+ "  from lpis_parcel_lc_details lpld \n"
			+ " inner join lpis_parcel_land_covers lplc on lpld.land_cover_id = lplc.id \n"
			+ " inner join lpis_parcels lp on lp.id = lplc.parcel_id \n"
			+ " inner join lpis_lock_parcels llp on llp.parcel_id = lp.id \n"
			+ " where lp.tenant_id = :tenantId \n"
			+ "   and llp.session_uuid = :sessionId \n"
			+ "   and llp.parcel_id = :parcelId \n"
			+ "   and §current_timestamp§ between lpld.dt_insert and lpld.dt_delete \n"
			+ "   and :referenceDate between lpld.day_from and lpld.day_to \n"
			+ "   and lpld.land_cover_id in (<landCoverIds>) \n")
	@RegisterBeanMapper(LandCoverNTT.class)
	List<LandCoverNTT> getLandCoversFromLandCoverIdsAndParcelIdBySession(
			@BindBean ServiceSupportEnv env,
			@BindList("landCoverIds") List<Long> landCoverIds,
			@Bind("parcelId") Long parcelId);

	@SqlQuery("\n"
			+ "select elc.land_cover_id as land_cover_id, \n"
			+ "       ep.parcel_id, \n"
			+ "       null as land_cover_details_id, \n"
			+ "       elc.land_cover_code as land_cover_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', elc.land_cover_code, :lang)§, elc.land_cover_code) as land_cover_description, \n"
			+ "       elc.area_sqm as area_sqm, \n"
			+ "       :referenceDate as day_from, \n"
			+ "       '99991231' as day_to, \n"
			+ "       ep.srs, \n"
			+ "       elc.geom as geom, \n"
			+ "       null as world_geom, \n"
			+ "       elc.edit_status, \n"
			+ "       elc.parent_id, \n"
			+ "       null as last_update \n"
			+ "  from lpis_edit_parcels ep \n"
			+ " inner join lpis_edit_land_covers elc on ep.id = elc.edit_parcel_id and elc.geom is not null \n"
			+ " where ep.geom is not null \n"
			+ "   and ep.session_uuid = :sessionId \n"
			+ "   and (:parcelId is null or ep.parcel_id = :parcelId) \n"
			+ "union all \n"
			+ "select lc.id as land_cover_id, \n"
			+ "       ep.parcel_id, \n"
			+ "       lcd.pkid as land_cover_details_id, \n"
			+ "       lcd.land_cover_code as land_cover_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', lcd.land_cover_code, :lang)§, lcd.land_cover_code) as land_cover_description, \n"
			+ "       lcd.area_sqm as area_sqm, \n"
			+ "       lcd.day_from as day_from, \n"
			+ "       lcd.day_to as day_to, \n"
			+ "       ep.srs, \n"
			+ "       lcd.geom as geom, \n"
			+ "       lcd.world_geom as world_geom, \n"
			+ "       'NOT_IN_EDIT' as edit_status, \n"
			+ "       null as parent_id, \n"
			+ "       lcd.dt_insert as last_update \n"
			+ "  from lpis_edit_parcels ep \n"
			+ " inner join lpis_parcel_land_covers lc on ep.parcel_id = lc.parcel_id \n"
			+ " inner join lpis_parcel_lc_details lcd on lc.id = lcd.land_cover_id \n"
			+ " where ep.geom is not null \n"
			+ "   and §current_timestamp§ between lcd.dt_insert and lcd.dt_delete \n"
			+ "   and :referenceDate between lcd.day_from and lcd.day_to \n"
			+ "   and ep.session_uuid = :sessionId \n"
			+ "   and not exists (select 1 from lpis_edit_land_covers elc where elc.land_cover_id = lc.id or elc.parent_id = lc.id) \n"
			+ "   and (:parcelId is null or ep.parcel_id = :parcelId)")
	@RegisterBeanMapper(LandCoverNTT.class)
	List<LandCoverNTT> findSessionLandCoversForSessionParcels(
			@BindBean ServiceSupportEnv env,
			@Bind("parcelId") Long parcelId);

	@SqlQuery("\n"
			+ "select elc.land_cover_id as land_cover_id, \n"
			+ "       ep.parcel_id, \n"
			+ "       null as land_cover_details_id, \n"
			+ "       elc.land_cover_code as land_cover_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', elc.land_cover_code, :lang)§, elc.land_cover_code) as land_cover_description, \n"
			+ "       elc.area_sqm as area_sqm, \n"
			+ "       :referenceDate as day_from, \n"
			+ "       '99991231' as day_to, \n"
			+ "       ep.srs, \n"
			+ "       elc.geom as geom, \n"
			+ "       null as world_geom, \n"
			+ "       elc.edit_status, \n"
			+ "       elc.parent_id, \n"
			+ "       null as last_update \n"
			+ "  from lpis_edit_parcels ep \n"
			+ " inner join lpis_edit_land_covers elc on ep.id = elc.edit_parcel_id \n"
			+ " where ep.session_uuid = :sessionId \n"
			+ "   and ep.parcel_id = :parcelId \n"
			+ "union all \n"
			+ "select lc.id as land_cover_id, \n"
			+ "       ep.parcel_id, \n"
			+ "       lcd.pkid as land_cover_details_id, \n"
			+ "       lcd.land_cover_code as land_cover_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', lcd.land_cover_code, :lang)§, lcd.land_cover_code) as land_cover_description, \n"
			+ "       lcd.area_sqm as area_sqm, \n"
			+ "       lcd.day_from as day_from, \n"
			+ "       lcd.day_to as day_to, \n"
			+ "       ep.srs, \n"
			+ "       lcd.geom as geom, \n"
			+ "       lcd.world_geom as world_geom, \n"
			+ "       coalesce(elc.edit_status, 'NOT_IN_EDIT') as edit_status, \n"
			+ "       null as parent_id, \n"
			+ "       lcd.dt_insert as last_update"
			+ "  from lpis_edit_parcels ep \n"
			+ " inner join lpis_parcel_land_covers lc on ep.parcel_id = lc.parcel_id \n"
			+ " inner join lpis_parcel_lc_details lcd on lc.id = lcd.land_cover_id \n"
			+ "  left join lpis_edit_land_covers elc on ep.id = elc.edit_parcel_id and elc.land_cover_id = lcd.land_cover_id \n"
			+ " where elc.land_cover_id is null \n"
			+ "   and §current_timestamp§ between lcd.dt_insert and lcd.dt_delete \n"
			+ "   and :referenceDate between lcd.day_from and lcd.day_to \n"
			+ "   and ep.session_uuid = :sessionId \n"
			+ "   and ep.parcel_id = :parcelId")
	@RegisterBeanMapper(LandCoverNTT.class)
	List<LandCoverNTT> findAllLandCoversForEditParcels(
			@BindBean ServiceSupportEnv env,
			@Bind("parcelId") Long parcelId);

	@SqlQuery("\n"
			+ "select p.parcel_id, \n"
			+ "       lc.pkid as edit_id, \n"
			+ "       lc.edit_parcel_id, \n"
			+ "       lc.land_cover_id, \n"
			+ "       lc.land_cover_code, \n"
			+ "       lc.area_sqm, \n"
			+ "       lc.geom, \n"
			+ "       lc.parent_id, \n"
			+ "       lc.edit_status \n"
			+ "  from lpis_edit_parcels p \n"
			+ " inner join lpis_edit_land_covers lc on lc.edit_parcel_id = p.id \n"
			+ " where lc.session_uuid = :sessionId \n"
			+ "   and lc.geom is not null \n"
			+ "   and p.edit_status not in (<excludesParcelStatus>) \n"
			+ "   and round(§geom_area(lc.geom)§) < 1 \n"
			+ "   and (:parcelId is null or p.parcel_id = :parcelId) \n"
			+ "   and (:landCoverId is null or lc.land_cover_id = :landCoverId) \n")
	@RegisterBeanMapper(LandCoverNTT.class)
	List<LandCoverNTT> findNotValidAreaLandCoversForSession(
			@Bind("sessionId") String uuid,
			@Bind("parcelId") Long parcelId,
			@Bind("landCoverId") Long landCoverId,
			@Bind("minSize") Integer minSize,
			@BindList("excludesParcelStatus") List<EditStatus> excludesParcelStatus);

}
