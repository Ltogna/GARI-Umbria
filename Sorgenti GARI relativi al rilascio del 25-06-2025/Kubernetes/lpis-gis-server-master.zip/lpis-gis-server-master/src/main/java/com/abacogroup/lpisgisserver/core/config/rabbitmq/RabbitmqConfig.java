package com.abacogroup.lpisgisserver.core.config.rabbitmq;

import lombok.Data;

@Data
public class RabbitmqConfig {
	private String host;
	private String user;
	private String password;
	private String virtualhost;
	private Integer port;	
}
