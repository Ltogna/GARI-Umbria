package com.abacogroup.lpisgisserver.bundles.models;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.CatalogueType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CatalogueMessage {
	private String code;
	private CatalogueType type;
	private Map<String, String> descriptions;
	private String srs;
	private Integer displayOrder;
	
	@Default
	private Boolean visible = true;
	
	private Map<String, String> params;
}
