package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineUnitDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineUnitNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineUnitWithParcelDetailsNTT;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnit;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnitWithAptitudes;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnitWithErrors;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnitWithParcelDetails;

@Mapper(uses = { AbsoluteDateMapper.class, VarietyMapper.class, CultivationStatusMapper.class,
		FarmingFormMapper.class, HeaderAnchoringMapper.class, PolesHeaderMapper.class, PolesWeavingMapper.class,
		ProductDestinationMapper.class, SupportWiresMapper.class, VariationTypeMapper.class,
		TerracingMapper.class, IrrigationMapper.class})
public interface VineUnitMapper {

	VineUnitMapper INSTANCE = Mappers.getMapper(VineUnitMapper.class);

	@InheritInverseConfiguration()
	@Mapping(source = "unitId", target = "id")
	@Mapping(source = "unitCode", target = "code")
	@Mapping(source = "parentUnitCode", target = "parentCode")
	@Mapping(target = "isDeletable", ignore = true)
	@Mapping(target = "isEditable", ignore = true)
	VineUnit entityToDto(VineUnitNTT entity);
	
	@InheritInverseConfiguration()
	@Mapping(source = "unitId", target = "id")
	@Mapping(source = "unitCode", target = "code")
	@Mapping(source = "parentUnitCode", target = "parentCode")
	@Mapping(target = "vineAptitudes", ignore = true)
	@Mapping(target = "isDeletable", ignore = true)
	@Mapping(target = "isEditable", ignore = true)
	@Mapping(target = "anomalies", ignore = true)
	VineUnitWithAptitudes entityToDtoWithAptitudes(VineUnitNTT entity);

	@InheritInverseConfiguration()
	@Mapping(source = "unitId", target = "id")
	@Mapping(source = "unitCode", target = "code")
	@Mapping(source = "parentUnitCode", target = "parentCode")
	@Mapping(target = "vineAptitudes", ignore = true)
	@Mapping(target = "editStatus", ignore = true)
	@Mapping(target = "errorList", ignore = true)
	@Mapping(target = "mandatoryDictionayTable", ignore = true)
	@Mapping(target = "isDeletable", ignore = true)
	@Mapping(target = "isEditable", ignore = true)
	VineUnitWithErrors entityToDtoWithErrors(VineUnitNTT entity);
	
	@InheritInverseConfiguration()
	@Mapping(source = "unitId", target = "id")
	@Mapping(source = "unitCode", target = "code")
	@Mapping(source = "parentUnitCode", target = "parentCode")
	@Mapping(target = "isDeletable", ignore = true)
	@Mapping(target = "isEditable", ignore = true)
	VineUnit entityToDto(VineUnitDetailsNTT entity);
	
	@InheritInverseConfiguration()
	@Mapping(source = "unitId", target = "id")
	@Mapping(source = "unitCode", target = "code")
	@Mapping(source = "parentUnitCode", target = "parentCode")
	@Mapping(target = "vineAptitudes", ignore = true)
	@Mapping(target = "isDeletable", ignore = true)
	@Mapping(target = "isEditable", ignore = true)
	@Mapping(target = "anomalies", ignore = true)
	VineUnitWithAptitudes entityToDtoWithAptitudes(VineUnitDetailsNTT entity);
	
	@InheritInverseConfiguration()
	@Mapping(source = "unitId", target = "id")
	@Mapping(source = "unitCode", target = "code")
	@Mapping(source = "parentUnitCode", target = "parentCode")
	@Mapping(target = "vineAptitudes", ignore = true)
	@Mapping(target = "isDeletable", ignore = true)
	@Mapping(target = "isEditable", ignore = true)
	@Mapping(target = "anomalies", ignore = true)
	VineUnitWithParcelDetails entityToDtoWithParcelDetails(VineUnitWithParcelDetailsNTT entity);

	@InheritInverseConfiguration()
	@Mapping(source = "unitId", target = "id")
	@Mapping(source = "unitCode", target = "code")
	@Mapping(source = "parentUnitCode", target = "parentCode")
	@Mapping(target = "vineAptitudes", ignore = true)
	@Mapping(target = "errorList", ignore = true)
	@Mapping(target = "isDeletable", ignore = true)
	@Mapping(target = "isEditable", ignore = true)
	@Mapping(target = "mandatoryDictionayTable", ignore = true)
	VineUnitWithErrors entityToDtoWithErrors(VineUnitDetailsNTT entity);

	VineUnitDetailsNTT entityToEntityDetail(VineUnitNTT oldVineUnit);

}
