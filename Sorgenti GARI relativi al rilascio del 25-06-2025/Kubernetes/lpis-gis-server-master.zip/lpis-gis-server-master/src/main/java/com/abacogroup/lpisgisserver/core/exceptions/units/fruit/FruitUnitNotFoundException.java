package com.abacogroup.lpisgisserver.core.exceptions.units.fruit;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class FruitUnitNotFoundException extends AbstractException {

	private static final long serialVersionUID = -6467378631448203591L;

	private static final ErrorCode ERROR_CODE = ErrorCode.FRUIT_UNIT_NOT_FOUND;

	public FruitUnitNotFoundException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new FruitUnitNotFoundExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Fruit unit not found")
	public static class FruitUnitNotFoundExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 3853099588145979239L;

		public FruitUnitNotFoundExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
