package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface LandCoversDAO extends Transactional<LandCoversDAO>, EnhancedSqlObject {

	@SqlQuery("§select_nextval(lpis_parcel_land_covers_sequence)§")
	Long nextSequenceVal();

	@SqlUpdate("INSERT INTO lpis_parcel_land_covers (id, parcel_id) VALUES(:land_cover_id, :parcel_id)")
	void insert(@BindBean LandCoverNTT rs);

	@SqlQuery(" \n "
			+ "select lcd.land_cover_id, \n"
			+ "       lc.parcel_id, \n"
			+ "       lcd.pkid as land_cover_details_id, \n"
			+ "       lcd.land_cover_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', lcd.land_cover_code, :lang)§, lcd.land_cover_code) as land_cover_description, \n"
			+ "       lcd.area_sqm, \n"
			+ "       lcd.day_from, \n"
			+ "       lcd.day_to, \n"
			+ "       lcd.srs, \n"
			+ "       case when :includeGeometries = 1 then lcd.geom else null end as geom, \n"
			+ "       case when :includeGeometries = 1 then lcd.world_geom else null end as world_geom, \n"
			+ "       lcd.dt_insert as last_update, \n"
			+ "       'NOT_IN_EDIT' as edit_status \n"
			+ "  from lpis_parcel_land_covers lc \n"
			+ " inner join lpis_parcel_lc_details lcd on lc.id = lcd.land_cover_id \n"
			+ " inner join lpis_parcels lp on lc.parcel_id = lp.id \n"
			+ " where lc.parcel_id in (<parcelIds>) \n"
			+ "   and lp.tenant_id = :tenantId \n"
			+ "   and §current_timestamp§ between lcd.dt_insert and lcd.dt_delete \n"
			+ "   and :referenceDate between lcd.day_from and lcd.day_to \n")
	@RegisterBeanMapper(LandCoverNTT.class)
	ResultIterator<LandCoverNTT> findByParcelIdsInfinite(@BindBean ServiceSupportEnv env, @BindList("parcelIds") List<Long> parcelIds);

	@SqlQuery(" \n "
			+ "select lcd.land_cover_id, \n"
			+ "       lc.parcel_id, \n"
			+ "       lcd.pkid as land_cover_details_id, \n"
			+ "       lcd.land_cover_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', lcd.land_cover_code, :lang)§, lcd.land_cover_code) as land_cover_description, \n"
			+ "       lcd.area_sqm, \n"
			+ "       lcd.day_from, \n"
			+ "       lcd.day_to, \n"
			+ "       lcd.srs, \n"
			+ "       case when :includeGeometries = 1 then lcd.geom else null end as geom, \n"
			+ "       case when :includeGeometries = 1 then lcd.world_geom else null end as world_geom, \n"
			+ "       lcd.dt_insert as last_update, \n"
			+ "       'NOT_IN_EDIT' as edit_status \n"
			+ "  from lpis_parcel_land_covers lc \n"
			+ " inner join lpis_parcel_lc_details lcd on lc.id = lcd.land_cover_id \n"
			+ " inner join lpis_parcels lp on lc.parcel_id = lp.id \n"
			+ " where lc.parcel_id in (<parcelIds>) \n"
			+ "   and lp.tenant_id = :tenantId \n"
			+ "   and §current_timestamp§ between lcd.dt_insert and lcd.dt_delete \n"
			+ "   and :referenceDate between lcd.day_from and lcd.day_to \n"
			+ " order by substr('000000000000' || lcd.land_cover_code, length(lcd.land_cover_code), length(lcd.land_cover_code) + 12), lcd.area_sqm desc \n")
	@RegisterBeanMapper(LandCoverNTT.class)
	List<LandCoverNTT> findByParcelIds(@BindBean ServiceSupportEnv env, @BindList("parcelIds") List<Long> parcelIds);

	@SqlQuery("\n "
			+ "select lplc.id as land_cover_id, \n"
			+ "       lplc.parcel_id, \n"
			+ "       lpld.pkid as land_cover_details_id, \n"
			+ "       lpld.land_cover_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', lpld.land_cover_code, :lang)§, lpld.land_cover_code) as land_cover_description,  "
			+ "       lpld.area_sqm, \n"
			+ "       lpld.day_from, \n"
			+ "       lpld.day_to, \n"
			+ "       lpld.srs, \n"
			+ "       lpld.geom, \n"
			+ "       lpld.world_geom \n"
			+ "  from lpis_parcel_land_covers lplc \n"
			+ " inner join lpis_parcel_lc_details lpld on lplc.id = lpld.land_cover_id \n"
			+ " inner join lpis_parcels lp on lplc.parcel_id = lp.id \n"
			+ " where lplc.id = :landCoverId \n"
			+ "   and lp.tenant_id = :tenantId \n"
			+ "   and §current_timestamp§ between lpld.dt_insert and lpld.dt_delete \n"
			+ "   and :referenceDate between lpld.day_from and lpld.day_to \n")
	@RegisterBeanMapper(LandCoverNTT.class)
	LandCoverNTT getLandCoverDetail(@BindBean ServiceSupportEnv env, @Bind("landCoverId") Long landCoverId);
}
