package com.abacogroup.lpisgisserver.core.pub;

import com.abacogroup.lpisgisserver.core.BaseService;
import com.abacogroup.lpisgisserver.core.ErrorDescriptionsService;
import com.abacogroup.lpisgisserver.core.ExternalConfigService;
import com.abacogroup.lpisgisserver.core.InternalConfigService;
import com.abacogroup.lpisgisserver.core.FruitUnitsService;
import com.abacogroup.lpisgisserver.core.StyleService;
import com.abacogroup.lpisgisserver.core.mappers.pub.FruitUnitV1Mapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.pub.units.fruit.FruitUnitV1;

public class FruitUnitsV1Service extends BaseService {

	private FruitUnitsService fruitUnitsService;

	public FruitUnitsV1Service(DAOContainer dc, FruitUnitsService fruitUnitsService, InternalConfigService conf, ExternalConfigService externalConf, 
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, 
			PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.fruitUnitsService = fruitUnitsService;
		
	}

	public FruitUnitV1 getFruitUnitById(ServiceSupportEnv env, Long fruitUnitId) {
		return FruitUnitV1Mapper.INSTANCE.toResponseV1(fruitUnitsService.getFruitUnitById(env, fruitUnitId));
	}
	
}
