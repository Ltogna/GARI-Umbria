package com.abacogroup.lpisgisserver.bundles.models;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MatrixListMessage {
	private List<MatrixMessage> matrixes;
}
