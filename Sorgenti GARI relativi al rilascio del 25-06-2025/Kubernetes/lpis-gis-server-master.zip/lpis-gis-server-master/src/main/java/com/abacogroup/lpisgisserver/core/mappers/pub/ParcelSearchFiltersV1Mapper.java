package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.resources.req.ParcelSearchFilters;
import com.abacogroup.lpisgisserver.resources.req.pub.ParcelSearchFiltersV1;

@Mapper
public interface ParcelSearchFiltersV1Mapper {

	ParcelSearchFiltersV1Mapper INSTANCE = Mappers.getMapper(ParcelSearchFiltersV1Mapper.class);
	
	@InheritInverseConfiguration
	ParcelSearchFilters toPrivFilters(ParcelSearchFiltersV1 entity);
	
}
