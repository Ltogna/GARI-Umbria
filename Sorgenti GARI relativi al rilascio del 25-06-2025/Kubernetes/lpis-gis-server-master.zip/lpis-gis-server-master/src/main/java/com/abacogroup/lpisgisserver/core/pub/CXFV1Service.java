package com.abacogroup.lpisgisserver.core.pub;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.proj4j.CoordinateReferenceSystem;

import com.abacogroup.cxf.CxfParticelleReader;
import com.abacogroup.lpisgisserver.core.BaseService;
import com.abacogroup.lpisgisserver.core.ErrorDescriptionsService;
import com.abacogroup.lpisgisserver.core.ExternalConfigService;
import com.abacogroup.lpisgisserver.core.ExternalParcelsSourceDataService;
import com.abacogroup.lpisgisserver.core.InternalConfigService;
import com.abacogroup.lpisgisserver.core.StyleService;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.block.BlockNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.cxf.InvalidCXFFileException;
import com.abacogroup.lpisgisserver.core.exceptions.sector.SectorNotFoundException;
import com.abacogroup.lpisgisserver.core.pub.models.CXFFileNameData;
import com.abacogroup.lpisgisserver.core.pub.models.CXFParcelImportResult;
import com.abacogroup.lpisgisserver.core.pub.models.LoadCXFFileResult;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.core.transform.ReprojectCoordinateSequenceFilter;
import com.abacogroup.lpisgisserver.db.dao.BlockDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.SectorDecodesDAO;
import com.abacogroup.lpisgisserver.db.ntt.BlockNTT;
import com.abacogroup.lpisgisserver.db.ntt.SectorNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.ExternalSourceParcel;

import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CXFV1Service extends BaseService {

	private final ExternalParcelsSourceDataService externalParcelsSourceService;
	
	private final SectorDecodesDAO sectorDecodesDAO;
	private final BlockDAO blockDAO;
	
	private static final String NULL_SECTION_FILE_NAME_PLACEHOLDER = "_";
	private static final String TEMP_CXF_FILE_PATH = "/app/tmpCxfFiles";
	
	public CXFV1Service(DAOContainer dc, ExternalParcelsSourceDataService externalParcelsSourceService,
			InternalConfigService conf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService,
			PluginEnvironment pluginEnvironment) {
		
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);
		
		this.externalParcelsSourceService = externalParcelsSourceService;
		
		this.sectorDecodesDAO = dc.getSectorDecodesDAO();
		this.blockDAO = dc.getBlockDAO();
	}

	public Response importCXFFile(ServiceSupportEnv env, InputStream uploadedFileCXFStream, FormDataContentDisposition fileCXFDetail, String sourceSRS) {
        
		if (uploadedFileCXFStream == null || fileCXFDetail == null) {
			InvalidCXFFileException ex = new InvalidCXFFileException(Status.BAD_REQUEST,
					Operation.CXF_FILE_LOAD, ErrorField.CXF_FILE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error("File not valid!!\n"+ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		if (env == null || env.getSdeCode() == null) {
			InvalidCXFFileException ex = new InvalidCXFFileException(Status.INTERNAL_SERVER_ERROR,
					Operation.CXF_FILE_LOAD, ErrorField.SDE_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error("SDE CODE NULL!!\n"+ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		File tempFile = null;
		try {
		    // Create a dedicated sub-folder with controlled permissions
			File secureTempDir = new File(TEMP_CXF_FILE_PATH);
		    if (!secureTempDir.exists()) {
		        secureTempDir.mkdirs();
		    }
		    
			// load the cxf file in a temporary dir
			// no name rewrite to enable name decodification
		    tempFile = Files.createTempFile(secureTempDir.toPath(), "CXF_", fileCXFDetail.getFileName()).toFile();

			try (FileOutputStream outputStream = new FileOutputStream(tempFile)) {
				byte[] buffer = new byte[1024];
				int bytesRead;
				while ((bytesRead = uploadedFileCXFStream.read(buffer)) != -1) {
					outputStream.write(buffer, 0, bytesRead);
				}
			}

			// import the geometries in the file using abaco simple cxf for java
			return loadCXFFile(env, fileCXFDetail.getFileName(), tempFile, sourceSRS);

		} catch (IOException e) {
			InvalidCXFFileException ex = new InvalidCXFFileException(Status.INTERNAL_SERVER_ERROR,
					Operation.CXF_FILE_LOAD, ErrorField.CXF_FILE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(e.getMessage()+"\n"+ex.getBody().getLogErrorMessage());

			throw ex;
		} finally {
	        if (tempFile != null && tempFile.exists()) {
	            try {
	                Files.delete(tempFile.toPath());
	            } catch (IOException e) {
	                log.warn("Failed to delete temporary file: " + tempFile.getAbsolutePath(), e);
	            }
	        }
	    }
		
		
	}
	
	/**
	 * Import a CXF file into the database
	 * 
	 * @param env             The environment
	 * @param uploadedCXFFile The uploaded CXF file
	 * @param sourceSRS       The source SRS
	 * @return The response
	 */
	private Response loadCXFFile(ServiceSupportEnv env, String filename, File uploadedCXFFile, String sourceSRS) {

		List<CXFParcelImportResult> successParcelsImport = new ArrayList<>();
		List<CXFParcelImportResult> failedParcelsImport = new ArrayList<>();

		// After cleaning up the data for sdeCode and filename try to load all the file
		// again, skipping the wrong data

		CXFFileNameData cxfFileNameDecoded = decodeCXFFileName(env, filename);

		// re Set env values
		env.setSectorCode(cxfFileNameDecoded.getSectorCode());
		env.setBlockCode(cxfFileNameDecoded.getBlockCode());
		env.setSrs(cxfFileNameDecoded.getSrs());

		// if the sector srs is different from the source srs, we need to reproject the geometries
		final CoordinateReferenceSystem fromCRS = (sourceSRS != null && !sourceSRS.equals(env.getSrs()))
				? getCRS(sourceSRS)
				: null;
		final CoordinateReferenceSystem toCRS = (sourceSRS != null && !sourceSRS.equals(env.getSrs()))
				? getCRS(env.getSrs())
				: null;

		// clean up the parcel for this block in this sdeCode, using the file name as a filter
		externalParcelsSourceService.cleanUpExternalSourceData(env.getTenantId(), env.getSdeCode(),
				cxfFileNameDecoded.getSectorCode(), cxfFileNameDecoded.getBlockCode(), filename);

		try (CxfParticelleReader reader = new CxfParticelleReader(uploadedCXFFile)) {
			reader.consumeParticelle(p -> {
				Geometry geom = p.getGeometry();
				
				// apply parcel name plugin according to the tenant configuration
				String parcelCode = applyDecodeParcelNamePlugin(env, p.getCodice());

				// try the insert new external parcel and record the result
				try {

					// if the source srs is different from the sector srs, reproject the geometry
					if (fromCRS != null && toCRS != null) {
						geom.apply(new ReprojectCoordinateSequenceFilter(fromCRS, toCRS));
						geom.setSRID(0);
					}

					// We keep the parcel code with zero fill like the one from cxf
					ExternalSourceParcel cxfParcel = ExternalSourceParcel.builder().externalSourceCode(env.getSdeCode())
							.sector(cxfFileNameDecoded.getSectorCode()).srs(cxfFileNameDecoded.getSrs())
							.block(cxfFileNameDecoded.getBlockCode()).parcel(parcelCode).geom(geom).build();

					externalParcelsSourceService.saveNewExternalSourceParcel(env.getTenantId(), env.getSdeCode(),
							filename, cxfParcel);
					successParcelsImport.add(CXFParcelImportResult.builder().sector(cxfFileNameDecoded.getSectorCode())
							.block(cxfFileNameDecoded.getBlockCode()).parcel(parcelCode)
							.srs(cxfFileNameDecoded.getSrs()).build());

				} catch (Exception e) {

					// if we have an exception, we record the error and continue with the next parcel
					failedParcelsImport.add(CXFParcelImportResult.builder().sector(cxfFileNameDecoded.getSectorCode())
							.block(cxfFileNameDecoded.getBlockCode()).parcel(parcelCode)
							.srs(cxfFileNameDecoded.getSrs()).errorMessagge(e.getMessage().split("\n")[0]).build());

					log.error("Error importing CXF Parcel: '" + parcelCode + "', block: '"
							+ cxfFileNameDecoded.getBlockCode() + "', sector '" + cxfFileNameDecoded.getSectorCode()
							+ "' \n" + e.getMessage());
				}

			});
		} catch (Exception e) {

			InvalidCXFFileException ex = new InvalidCXFFileException(Status.BAD_REQUEST, Operation.CXF_FILE_LOAD,
					ErrorField.CXF_FILE, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()),
					env.getLang());

			log.error(e.getMessage() + "\n" + ex.getBody().getLogErrorMessage());

			throw ex;

		} 

		// If I'm here I ended the upload
		return Response
				.ok(LoadCXFFileResult.builder().fileName(filename).sdeCode(env.getSdeCode())
						.successParcelsImport(successParcelsImport).failedParcelsImport(failedParcelsImport).build())
				.type(MediaType.APPLICATION_JSON).build();
	}

	private CXFFileNameData decodeCXFFileName(ServiceSupportEnv env, String name) {
		
		// check file name "CCCCZFFFFAS.cxf" where: 
		//  * CCCC is cod. belfiore, 
		//  * Z sezione, 
		//  * FFFF num. foglio, 
		//  * A cod. allegato, 
		//  * S cod. sviluppo
		
		// check name length
		if(name == null || name.length() != 15) {
			InvalidCXFFileException ex = new InvalidCXFFileException(Status.BAD_REQUEST,
					Operation.CXF_FILE_LOAD, ErrorField.CXF_FILE_NAME,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		// Get name codes
		String cadastralCode = name.substring(0, 4);
		String sectionCode = NULL_SECTION_FILE_NAME_PLACEHOLDER.equals(name.substring(4, 5)) ? null : name.substring(4, 5);
		String blockCode = "" + Integer.parseInt(name.substring(5, 9));
		String attachmentCode = name.substring(9, 10);
		String developmentCode = name.substring(10, 11);
		
		// Get sector from cadastral_code and section_code 
		SectorNTT sector = sectorDecodesDAO.findSectorDetailsByTenantAndCadastralCodeAndSectionCode(env, cadastralCode, sectionCode);
		if(sector == null) {
			SectorNotFoundException ex = new SectorNotFoundException(Status.BAD_REQUEST, Operation.CXF_FILE_LOAD, ErrorField.SECTOR_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
			
			log.warn(ex.getBody().getLogErrorMessage());
			
			throw ex;
		}
		
		// Get block from block_code
		BlockNTT block = blockDAO.findBlockDetailsByTenantBlockCodeSectorCode(env.getTenantId(), blockCode, sector.getSector());
		if(block == null) {
			BlockNotFoundException ex = new BlockNotFoundException(Status.BAD_REQUEST, Operation.CXF_FILE_LOAD, ErrorField.BLOCK_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		// Here I get all the data needed
		return CXFFileNameData.builder()
				.cadastralCode(cadastralCode)
				.sectionCode(sectionCode)
				.sectorCode(sector.getSector())
				.sectorId(sector.getId())
				.blockCode(blockCode)
				.blockId(block.getId())
				.srs(sector.getSrs())
				.attachmentCode(attachmentCode)
				.developmentCode(developmentCode)
				.build();
		
	}

}
