package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.OliveUnitDetailsNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface EditOliveUnitsDAO extends Transactional<EditOliveUnitsDAO>, EnhancedSqlObject {

	@SqlQuery("§select_nextval(lpis_edit_unit_oliveunit_sequence)§")
	Long nextEditOliveUnitDetailPkidVal();
	
	@SqlQuery("select coalesce(min(unit_id), 0) - 1 from lpis_edit_unit_oliveunit where unit_id < 1")
	Long nextNewOliveUnitIdVal();
	
	@SqlUpdate("INSERT INTO lpis_edit_unit_oliveunit (id, session_uuid, edit_land_cover_id, unit_id, "
			+ "    type_code, unit_code, variety_code, area_sqm, planting_day, planting_day_precision, eradicate_day, "
			+ "    planting_type_code, distance_on_the_row_cm, distance_between_rows_cm, plants_number, "
			+ "    farming_form_code, irrigation_code, product_destination_code, altitude_above_sea_level, "
			+ "    quality_system_code, protection_structure_code, external_code, edit_status, fl_deletable, parent_unit_code) "
			+ "values (:editId, :sessionId, :editLandCoverId, :unitId, "
			+ "    :typeCode, :unitCode, :variety.code, :areaSqm, :plantingDay, :plantingDayPrecision, :eradicateDay, "
			+ "    :plantingType.code, :distanceOnTheRowCM, :distanceBetweenRowsCM, :plantsNumber, "
			+ "    :farmingForm.code, :irrigation.code, :productDestination.code, :altitudeAboveSeaLevel, "
			+ "    :qualitySystem.code, :protectionStructure.code, :externalCode, :editStatus, :flDeletable, :parentUnitCode) "
			+ "")
	void insertEditOliveUnitDetail(@BindBean ServiceSupportEnv env, @BindBean OliveUnitDetailsNTT oliveUnitDetailsNTT);
	
	@SqlUpdate("UPDATE lpis_edit_unit_oliveunit \n"
			+ "SET type_code = :typeCode, unit_code = :unitCode, variety_code = :variety.code, "
			+ "area_sqm = :areaSqm, planting_day = :plantingDay, planting_day_precision = :plantingDayPrecision, eradicate_day = :eradicateDay, "
	        + "planting_type_code = :plantingType.code, distance_on_the_row_cm = :distanceOnTheRowCM, distance_between_rows_cm = :distanceBetweenRowsCM, "
	        + "plants_number = :plantsNumber, farming_form_code = :farmingForm.code, irrigation_code = :irrigation.code, "
	        + "product_destination_code = :productDestination.code, altitude_above_sea_level = :altitudeAboveSeaLevel, "
	        + "quality_system_code = :qualitySystem.code, protection_structure_code = :protectionStructure.code, "
	        + "external_code = :externalCode, edit_status = :editStatus, fl_deletable = :flDeletable, parent_unit_code = :parentUnitCode "
	        + "WHERE unit_id = :unitId and session_uuid = :sessionId ")
	void updateEditOliveUnitDetail(@Bind("sessionId") String sessionId, @BindBean OliveUnitDetailsNTT oliveUnitDetailsNTT);
	
	@SqlQuery("select eou.id as edit_id, \n"
			+ "    eou.edit_land_cover_id, \n"
			+ "    lelc.land_cover_id, \n"
			+ "    eou.unit_id, \n"
			+ "    eou.unit_code, \n"
			+ "    eou.parent_unit_code, \n"
			+ "    eou.type_code, \n"
			+ "    eou.variety_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_variety', 'code', luv.type_code||':'||luv.code, :lang)§ as variety_description, \n"
			+ "    luv.fl_visible as variety_fl_visible, \n"
			+ "    eou.area_sqm, \n"
			+ "    eou.planting_day, \n"
			+ "    eou.planting_day_precision, \n"
			+ "    eou.eradicate_day, \n"
			+ "    eou.planting_type_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_planting_type', 'code', lupt.type_code||':'||lupt.code, :lang)§ as planting_type_description, \n"
			+ "    lupt.fl_visible as planting_type_fl_visible, \n"
			+ "    eou.distance_on_the_row_cm, \n"
			+ "    eou.distance_between_rows_cm, \n"
			+ "    eou.plants_number, \n"
			+ "    eou.farming_form_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_farming_form', 'code', luff.type_code||':'||luff.code, :lang)§ as farming_form_description, \n"
			+ "    luff.fl_visible as farming_form_fl_visible, \n"
			+ "    eou.irrigation_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_irrigation', 'code', lui.type_code||':'||lui.code, :lang)§ as irrigation_description, \n"
			+ "    lui.fl_visible as irrigation_fl_visible, \n"
			+ "    eou.product_destination_code , \n"
			+ "    §i18n(:tenantId, 'lpis_unit_product_destination', 'code', lupd.type_code||':'||lupd.code, :lang)§ as product_destination_description, \n"
			+ "    lupd.fl_visible as product_destination_fl_visible, \n"
			+ "    eou.altitude_above_sea_level, \n"
			+ "    eou.quality_system_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_quality_system', 'code', luqs.type_code||':'||luqs.code, :lang)§ as quality_system_description, \n"
			+ "    luqs.fl_visible as quality_system_fl_visible, \n"
			+ "    eou.protection_structure_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_protection_structure', 'code', lups.type_code||':'||lups.code, :lang)§ as protection_structure_description, \n"
			+ "    lups.fl_visible as protection_structure_fl_visible, \n"
			+ "    eou.external_code, \n"
			+ "    eou.edit_status, \n"
			+ "    es.dt_last_lock as lastUpdate,\n"
			+ "    es.user_id as lastUpdateUser, \n"
			+ "    eou.fl_deletable \n"
			+ "from \n"
			+ "    lpis_edit_sessions es \n"
			+ "    inner join lpis_edit_unit_oliveunit eou on es.uuid = eou.session_uuid \n"
			+ "    inner join lpis_edit_land_covers lelc on lelc.session_uuid = eou.session_uuid and lelc.pkid = eou.edit_land_cover_id  \n"
			+ "    left join lpis_unit_variety luv on luv.code = eou.variety_code and luv.tenant_id = :tenantId and luv.type_code = eou.type_code \n"
			+ "    left join lpis_unit_farming_form luff on luff.code = eou.farming_form_code and luff.tenant_id = :tenantId and luff.type_code = eou.type_code \n"
			+ "    left join lpis_unit_irrigation lui on lui.code = eou.irrigation_code and lui.tenant_id = :tenantId and lui.type_code = eou.type_code \n"
			+ "    left join lpis_unit_product_destination lupd on lupd.code = eou.product_destination_code and lupd.tenant_id = :tenantId and lupd.type_code = eou.type_code \n"
			+ "    left join lpis_unit_planting_type lupt on lupt.code = eou.planting_type_code and lupt.tenant_id = :tenantId and lupt.type_code = eou.type_code \n"
			+ "    left join lpis_unit_quality_system luqs on luqs.code = eou.quality_system_code and luqs.tenant_id = :tenantId and luqs.type_code = eou.type_code \n"
			+ "    left join lpis_unit_protection_structure lups on lups.code = eou.protection_structure_code and lups.tenant_id = :tenantId and lups.type_code = eou.type_code \n"
			+ "where \n"
			+ "    es.uuid = :sessionId \n"
			+ "    and eou.type_code = 'OLIVE_UNIT' \n"
			+ "    and (:landCoverId is null or lelc.land_cover_id = :landCoverId) \n"
			+ "    and (:oliveUnitId is null or :oliveUnitId = eou.unit_id) \n"
			+ "    and (:includeEradicate = 1 or :referenceDate < eou.eradicate_day) \n"
			+ "    and (coalesce(<excludes>, null) is null or eou.edit_status not in (<excludes>))"
			+ "    and (coalesce(<excludes>, null) is null or lelc.edit_status not in (<excludes>))"
			+ "order by case when length(eou.unit_code) < 15 then substr(('000000000000000'||eou.unit_code), length('000000000000000'||eou.unit_code) -14, length('000000000000000'||eou.unit_code)) else eou.unit_code end, eou.unit_id asc \n"
			+ "")
	@RegisterBeanMapper(OliveUnitDetailsNTT.class)
	List<OliveUnitDetailsNTT> findInEditOliveUnitsBySessionId(@BindBean ServiceSupportEnv env, @Bind("landCoverId") Long landCoverId,
			@Bind("oliveUnitId") Long oliveUnitId, 
			@BindList(value = "excludes", onEmpty = BindList.EmptyHandling.NULL_STRING) List<EditStatus> excludes,
			@Bind("includeEradicate") Integer includeEradicate);	
	
	default List<OliveUnitDetailsNTT> findInEditOliveUnitsBySessionId(ServiceSupportEnv env, Long landCoverId, Long oliveUnitId, List<EditStatus> excludes){
		return findInEditOliveUnitsBySessionId(env, landCoverId, oliveUnitId, excludes, 0);		
	}
	
	@SqlQuery("SELECT u.land_cover_id, \n"
			+ "    od.unit_code, \n"
			+ "    od.parent_unit_code, \n"
			+ "    od.unit_id, \n"
			+ "    u.type_code, \n"
			+ "    luv.code as variety_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_variety', 'code', luv.type_code||':'||luv.code, :lang)§ as variety_description, \n"
			+ "    luv.fl_visible as variety_fl_visible, \n"
			+ "    od.area_sqm, \n"
			+ "    od.planting_day, \n"
			+ "    od.planting_day_precision, \n"
			+ "    od.eradicate_day, \n"
			+ "    od.planting_type_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_planting_type', 'code', lupt.type_code||':'||lupt.code, :lang)§ as planting_type_description, \n"
			+ "    lupt.fl_visible as planting_type_fl_visible, \n"
			+ "    od.distance_on_the_row_cm, \n"
			+ "    od.distance_between_rows_cm, \n"
			+ "    od.plants_number, \n"
			+ "    luff.code as farming_form_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_farming_form', 'code', luff.type_code||':'||luff.code, :lang)§ as farming_form_description, \n"
			+ "    luff.fl_visible as farming_form_fl_visible, \n"
			+ "    lui.code as irrigation_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_irrigation', 'code', lui.type_code||':'||lui.code, :lang)§ as irrigation_description, \n"
			+ "    lui.fl_visible as irrigation_fl_visible, \n"
			+ "    lupd.code as product_destination_code , \n"
			+ "    §i18n(:tenantId, 'lpis_unit_product_destination', 'code', lupd.type_code||':'||lupd.code, :lang)§ as product_destination_description, \n"
			+ "    lupd.fl_visible as product_destination_fl_visible, \n"
			+ "    od.altitude_above_sea_level, \n"
			+ "    od.quality_system_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_quality_system', 'code', luqs.type_code||':'||luqs.code, :lang)§ as quality_system_description, \n"
			+ "    luqs.fl_visible as quality_system_fl_visible, \n"
			+ "    od.protection_structure_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_protection_structure', 'code', lups.type_code||':'||lups.code, :lang)§ as protection_structure_description, \n"
			+ "    lups.fl_visible as protection_structure_fl_visible, \n"
			+ "    od.external_code, \n"
			+ "    'NOT_IN_EDIT' as edit_status, \n"
			+ "    od.dt_insert as lastUpdate, \n"
			+ "    od.user_id_insert as lastUpdateUser, \n"
			+ "    0 as flDeletable, \n"
			+ "    od.day_from, \n"
			+ "    od.day_to \n"
			+ "from "
			+ "    lpis_lock_parcels lp \n"
			+ "    inner join lpis_parcel_land_covers lc on lc.parcel_id = lp.parcel_id \n"
			+ "    inner join lpis_parcel_lc_details lcd on lc.id = lcd.land_cover_id \n"
			+ "    inner join lpis_parcel_lc_units u on u.land_cover_id = lc.id \n"
			+ "    inner join lpis_unit_oliveunit_details od on u.id = od.unit_id \n"
			+ "    left join lpis_unit_variety luv on luv.code = od.variety_code and luv.tenant_id = :tenantId and luv.type_code = u.type_code \n"
			+ "    left join lpis_unit_farming_form luff on luff.code = od.farming_form_code and luff.tenant_id = :tenantId and luff.type_code = u.type_code \n"
			+ "    left join lpis_unit_irrigation lui on lui.code = od.irrigation_code and lui.tenant_id = :tenantId and lui.type_code = u.type_code \n"
			+ "    left join lpis_unit_product_destination lupd on lupd.code = od.product_destination_code and lupd.tenant_id = :tenantId and lupd.type_code = u.type_code \n"
			+ "    left join lpis_unit_planting_type lupt on lupt.code = od.planting_type_code and lupt.tenant_id = :tenantId and lupt.type_code = u.type_code \n"
			+ "    left join lpis_unit_quality_system luqs on luqs.code = od.quality_system_code and luqs.tenant_id = :tenantId and luqs.type_code = u.type_code \n"
			+ "    left join lpis_unit_protection_structure lups on lups.code = od.protection_structure_code and lups.tenant_id = :tenantId and lups.type_code = u.type_code \n"
			+ "where \n"
			+ "    (:landCoverId is null or u.land_cover_id = :landCoverId) \n"
			+ "    and (:landCoverPkid is null or lcd.pkid = :landCoverPkid) \n"
			+ "    and u.type_code = 'OLIVE_UNIT' \n"
			+ "    and not exists (select 1 from lpis_edit_unit_oliveunit leuo where leuo.session_uuid = :sessionId and leuo.unit_id = u.id) \n"
			+ "    and (:oliveUnitId is null or :oliveUnitId = u.id) \n"
			+ "    and (:landCoverPkid is not null or :referenceDate between lcd.day_from and lcd.day_to) \n"
			+ "    and :referenceDate between od.day_from and od.day_to \n"
			+ "    and od.planting_day <= :referenceDate and :referenceDate < od.eradicate_day \n"
			+ "    and §current_timestamp§ between od.dt_insert and od.dt_delete \n"
			+ "    and (:landCoverPkid is not null or §current_timestamp§ between lcd.dt_insert and lcd.dt_delete) \n" 
			+ "order by case when length(od.unit_code) < 15 then substr(('000000000000000'||od.unit_code), length('000000000000000'||od.unit_code) -14, length('000000000000000'||od.unit_code)) else od.unit_code end, od.unit_id asc \n"
			+ "")
	@RegisterBeanMapper(OliveUnitDetailsNTT.class)
	List<OliveUnitDetailsNTT> findNotInEditOliveUnitsBySessionId(@BindBean ServiceSupportEnv env, @Bind("landCoverId") Long landCoverId,
			@Bind("landCoverPkid") Long landCoverPkId, @Bind("oliveUnitId") Long oliveUnitId);

	default List<OliveUnitDetailsNTT> findNotInEditOliveUnitsBySessionId(@BindBean ServiceSupportEnv env, @Bind("landCoverId") Long landCoverId,
			@Bind("oliveUnitId") Long oliveUnitId){
		return  findNotInEditOliveUnitsBySessionId(env, landCoverId, null, oliveUnitId);
	}
	
	@SqlQuery("select coalesce(evo.fl_deletable, 0) \n"
			+ "from \n"
			+ "    lpis_edit_sessions es \n"
			+ "    inner join lpis_edit_unit_oliveunit evo on es.uuid = evo.session_uuid \n"
			+ "    inner join lpis_edit_land_covers lelc on lelc.session_uuid = evo.session_uuid and lelc.pkid = evo.edit_land_cover_id  \n"
			+ "where \n"
			+ "    es.uuid = :sessionId \n"
			+ "    and lelc.land_cover_id = :landCoverId \n"
			+ "    and (:oliveUnitId is null or :oliveUnitId = evo.unit_id) \n"
			+ "")
	Integer checkOliveUnitDeletable(@BindBean ServiceSupportEnv env, @Bind("landCoverId") Long landCoverId,
			@Bind("oliveUnitId") Long oliveUnitId);
	
	@SqlUpdate("delete from lpis_edit_unit_oliveunit where session_uuid = :sessionId and unit_id = :oliveUnitId")
	void deleteOliveUnitsById(@Bind("sessionId") String sessionId, @Bind("oliveUnitId") Long oliveUnitId);	

	@SqlUpdate("delete from lpis_edit_unit_oliveunit where session_uuid = :sessionId")
	void deleteOliveUnitsBySessionId(@Bind("sessionId") String sessionId);

	@SqlUpdate("delete from lpis_edit_unit_oliveunit where session_uuid = :sessionId and id = :editOliveUnitId")
	void deleteOliveUnitsByEditId(@Bind("sessionId") String sessionId, @Bind("editOliveUnitId") Long editOliveUnitId);	
}
