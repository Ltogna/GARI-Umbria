package com.abacogroup.lpisgisserver.bundles.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InternalConfigMessage {
	private String key;
	private Object value;
	private Boolean fl_client;
	private String name;
}
