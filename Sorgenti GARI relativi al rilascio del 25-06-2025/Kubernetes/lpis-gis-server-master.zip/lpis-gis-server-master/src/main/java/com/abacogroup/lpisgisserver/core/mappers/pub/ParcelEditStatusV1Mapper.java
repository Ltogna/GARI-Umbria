package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.resources.res.ParcelEditStatus;
import com.abacogroup.lpisgisserver.resources.res.pub.ParcelEditStatusV1;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ParcelEditStatusV1Mapper {

	ParcelEditStatusV1Mapper INSTANCE = Mappers.getMapper(ParcelEditStatusV1Mapper.class);

	@InheritInverseConfiguration()
	ParcelEditStatusV1 toResponseV1(ParcelEditStatus entity);

}
