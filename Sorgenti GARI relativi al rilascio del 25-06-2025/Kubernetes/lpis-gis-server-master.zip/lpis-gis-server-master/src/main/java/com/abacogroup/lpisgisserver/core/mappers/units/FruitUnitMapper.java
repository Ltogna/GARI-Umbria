package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.units.fruit.FruitUnitDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.fruit.FruitUnitNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.FruitUnitWithParcelDetailsNTT;
import com.abacogroup.lpisgisserver.resources.res.units.fruit.FruitUnit;
import com.abacogroup.lpisgisserver.resources.res.units.fruit.FruitUnitWithErrors;
import com.abacogroup.lpisgisserver.resources.res.units.fruit.FruitUnitWithParcelDetails;

@Mapper(uses = { AbsoluteDateMapper.class, VarietyMapper.class, FarmingFormMapper.class, IrrigationMapper.class, 
		ProtectionStructureMapper.class, QualitySystemMapper.class, PlantingTypeMapper.class})
public interface FruitUnitMapper {

	FruitUnitMapper INSTANCE = Mappers.getMapper(FruitUnitMapper.class);

	@InheritInverseConfiguration()
	@Mapping(source = "unitId", target = "id")
	@Mapping(source = "unitCode", target = "code")
	@Mapping(source = "parentUnitCode", target = "parentCode")
	@Mapping(target = "isDeletable", ignore = true)
	@Mapping(target = "isEditable", ignore = true)
	FruitUnit entityToDto(FruitUnitNTT entity);
	
	@InheritInverseConfiguration()
	@Mapping(source = "unitId", target = "id")
	@Mapping(source = "unitCode", target = "code")
	@Mapping(source = "parentUnitCode", target = "parentCode")
	@Mapping(target = "isDeletable", ignore = true)
	@Mapping(target = "isEditable", ignore = true)
	FruitUnit entityToDto(FruitUnitDetailsNTT entity);

	@InheritInverseConfiguration()
	@Mapping(source = "unitId", target = "id")
	@Mapping(source = "unitCode", target = "code")
	@Mapping(source = "parentUnitCode", target = "parentCode")
	@Mapping(target = "isDeletable", ignore = true)
	@Mapping(target = "isEditable", ignore = true)
	@Mapping(target = "anomalies", ignore = true)
	FruitUnitWithParcelDetails entityToDtoWithParcelDetails(FruitUnitWithParcelDetailsNTT fruitUnitNTT);
	
	@InheritInverseConfiguration()
	@Mapping(source = "unitId", target = "id")
	@Mapping(source = "unitCode", target = "code")
	@Mapping(source = "parentUnitCode", target = "parentCode")
	@Mapping(target = "editStatus", ignore = true)
	@Mapping(target = "errorList", ignore = true)
	@Mapping(target = "mandatoryDictionayTable", ignore = true)
	@Mapping(target = "isDeletable", ignore = true)
	@Mapping(target = "isEditable", ignore = true)
	FruitUnitWithErrors entityToDtoWithErrors(FruitUnitNTT entity);

	@InheritInverseConfiguration()
	@Mapping(source = "unitId", target = "id")
	@Mapping(source = "unitCode", target = "code")
	@Mapping(source = "parentUnitCode", target = "parentCode")
	@Mapping(target = "errorList", ignore = true)
	@Mapping(target = "isDeletable", ignore = true)
	@Mapping(target = "isEditable", ignore = true)
	@Mapping(target = "mandatoryDictionayTable", ignore = true)
	FruitUnitWithErrors entityToDtoWithErrors(FruitUnitDetailsNTT entity);

	
	FruitUnitDetailsNTT entityToEntityDetail(FruitUnitNTT oldFruitUnit);


}
