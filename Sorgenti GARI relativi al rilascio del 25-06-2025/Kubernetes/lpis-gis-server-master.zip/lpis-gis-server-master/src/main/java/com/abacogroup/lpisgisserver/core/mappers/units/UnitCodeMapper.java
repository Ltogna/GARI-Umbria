package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.UnitCodeNTT;
import com.abacogroup.lpisgisserver.resources.res.units.UnitCode;

@Mapper
public interface UnitCodeMapper {

	UnitCodeMapper INSTANCE = Mappers.getMapper(UnitCodeMapper.class);
	
	@InheritInverseConfiguration
	UnitCode entityToDto(UnitCodeNTT entity);
	
	@Mapping(target = "typeCode", ignore = true)
	UnitCodeNTT dtoToEntity(UnitCode dto);
}
