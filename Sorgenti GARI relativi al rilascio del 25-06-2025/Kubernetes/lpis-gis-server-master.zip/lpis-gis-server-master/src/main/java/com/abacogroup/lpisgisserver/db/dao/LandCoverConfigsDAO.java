package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.enums.LandCoverConfigKeys;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverConfigNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface LandCoverConfigsDAO extends Transactional<LandCoverConfigsDAO>, EnhancedSqlObject {

	@SqlUpdate("INSERT INTO lpis_landcover_configs (tenant_id, land_cover_code, key, value) "
			+ "VALUES (:tenantId, :landCoverCode, :key, :value)")
	void insert(@Bind("tenantId") String tenantId, @BindBean LandCoverConfigNTT landCoverConfig);
	
	@SqlUpdate("UPDATE lpis_landcover_configs " 
			+ "SET value = :value " 
			+ "WHERE tenant_id = :tenantId "
			+ "  AND land_cover_code = :landCoverCode " 
			+ "  AND key = :key")
	void update(@Bind("tenantId") String tenantId, @BindBean LandCoverConfigNTT landCoverConfig);

	@SqlUpdate("DELETE FROM lpis_landcover_configs " 
			+ "WHERE tenant_id = :tenantId "
			+ "  AND land_cover_code = :landCoverCode " 
			+ "  AND key = :key")
	void delete(@Bind("tenantId") String tenantId, @BindBean LandCoverConfigNTT landCoverConfig);

	@SqlQuery("select land_cover_code, \n"
			+ "       key, \n"
            + "       value \n"
            + "from lpis_landcover_configs \n"
            + "where tenant_id = :tenantId \n"
            + "  and (:landCoverCode is null or land_cover_code = :landCoverCode) \n"
            + "  and (:key is null or key = :key) \n")
	@RegisterBeanMapper(LandCoverConfigNTT.class)
	List<LandCoverConfigNTT> findConfigs(@Bind("tenantId") String tenantId, 
			@Bind("landCoverCode") String landCoverCode, @Bind("key") LandCoverConfigKeys key);

	@SqlQuery("select land_cover_code, \n"
			+ "       key, \n"
			+ "       value \n"
			+ "from lpis_landcover_configs \n"
			+ "where tenant_id = :tenantId \n"
			+ "  and land_cover_code = :landCoverCode \n"
			+ "  and key = :key")
	@RegisterBeanMapper(LandCoverConfigNTT.class)
	LandCoverConfigNTT findByLandCoverCodeAndKey(@Bind("tenantId") String tenantId,
			@Bind("landCoverCode") String landCoverCode, @Bind("key") LandCoverConfigKeys key);

	
}
