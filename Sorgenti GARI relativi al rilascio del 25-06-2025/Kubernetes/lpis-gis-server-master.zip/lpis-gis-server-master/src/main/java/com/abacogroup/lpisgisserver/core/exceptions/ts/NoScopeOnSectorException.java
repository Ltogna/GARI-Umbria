package com.abacogroup.lpisgisserver.core.exceptions.ts;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class NoScopeOnSectorException extends AbstractException {
	
	private static final long serialVersionUID = -780745864333255949L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.NO_SCOPE_ON_SECTOR;

	public NoScopeOnSectorException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new NoScopeOnSectorExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "User has no scope on sector")
	public static class NoScopeOnSectorExceptionBody extends AbstractExceptionBody {

		private static final long serialVersionUID = 3594312210647578017L;

		public NoScopeOnSectorExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
