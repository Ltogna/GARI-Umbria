package com.abacogroup.lpisgisserver.core.exceptions.ts;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class NoScopeOnParcelException extends AbstractException {

	private static final long serialVersionUID = 5341555773358009460L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.NO_SCOPE_ON_PARCEL;

	public NoScopeOnParcelException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new NoScopeOnParcelExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "User has no scope on parcel")
	public static class NoScopeOnParcelExceptionBody extends AbstractExceptionBody {

		private static final long serialVersionUID = 2653513409975183537L;

		public NoScopeOnParcelExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
