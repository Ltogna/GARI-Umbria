package com.abacogroup.lpisgisserver.core.models.cll.api.v1;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class GroupBaseResV1 {

	private Long id;

	private String descr;

}
