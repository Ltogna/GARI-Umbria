package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.QualitySystemNTT;
import com.abacogroup.lpisgisserver.resources.res.units.QualitySystem;

@Mapper
public interface QualitySystemMapper {

	QualitySystemMapper INSTANCE = Mappers.getMapper(QualitySystemMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	QualitySystem entityToDto(QualitySystemNTT entity);
	
	@Mapping(target = "flVisible", expression = "java(dto.getVisible() ? 1 : 0)")
	@Mapping(target = "typeCode", ignore = true)
	QualitySystemNTT dtoToEntity(QualitySystem dto);
}
