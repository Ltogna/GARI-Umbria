package com.abacogroup.lpisgisserver.bundles.models.units;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UnitPolesWeavingMessage {
	private String code;
	private Boolean fl_visible;
	private Map<String, String> description;
}
