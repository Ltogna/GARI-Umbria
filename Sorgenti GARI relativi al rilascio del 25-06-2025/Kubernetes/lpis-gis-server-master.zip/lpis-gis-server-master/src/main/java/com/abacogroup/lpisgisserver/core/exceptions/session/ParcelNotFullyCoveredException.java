package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class ParcelNotFullyCoveredException extends AbstractException {

	private static final long serialVersionUID = 786453403822823023L;

	private static final ErrorCode ERROR_CODE = ErrorCode.PARCEL_NOT_FULLY_COVERED;

	public ParcelNotFullyCoveredException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new ParcelNotFullyCoveredExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Some parcels not fully covered of landcovers")
	public static class ParcelNotFullyCoveredExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 1360130425765344019L;

		public ParcelNotFullyCoveredExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
