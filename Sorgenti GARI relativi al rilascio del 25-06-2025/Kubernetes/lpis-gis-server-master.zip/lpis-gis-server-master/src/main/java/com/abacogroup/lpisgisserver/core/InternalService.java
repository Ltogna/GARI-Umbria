package com.abacogroup.lpisgisserver.core;

import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.proj4j.CoordinateReferenceSystem;

import com.abacogroup.lpisgisserver.core.enums.GeomTables;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.core.transform.ReprojectCoordinateSequenceFilter;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.InternalDAO;
import com.abacogroup.lpisgisserver.db.ntt.UpdateGeomNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;

import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class InternalService extends BaseService{

	private InternalDAO internalDAO;
	
	protected static final String SRS_WORLD_GEOM = "EPSG:3857";

	public InternalService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService,
			PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);
		
		this.internalDAO = dc.getInternalDAO();
	}

	public Response updateWorldGeom(ServiceSupportEnv env, GeomTables table) {

		internalDAO.getGeoms(env.getTenantId(), table.getQuery(), upadteGeomNTT -> this.updateWorldGeomInternal(env, table, upadteGeomNTT));

		return Response.ok().build();
	}
	
	private void updateWorldGeomInternal(ServiceSupportEnv env, GeomTables table, UpdateGeomNTT updateGeomNTT) {
		if(updateGeomNTT.getGeom() == null || updateGeomNTT.getGeom().isEmpty() || StringUtils.isBlank(updateGeomNTT.getSrs())) {
			return;
		}
		
		try {
			if(!updateGeomNTT.getGeom().difference(updateGeomNTT.getWorld_geom()).isEmpty()) {
				return;
			}
		} catch(Exception e) {
			log.error("SKIPPING!! Error trying to find difference between geom and worl_geom, table: '{}', pkid: {}, {}", table.name(), updateGeomNTT.getPkid(), e.getMessage());
			return;
		}
		
		CoordinateReferenceSystem fromCRS = getCRS(updateGeomNTT.getSrs());
		CoordinateReferenceSystem toWorldCRS = getCRS(SRS_WORLD_GEOM);
		if (fromCRS.getName().equals(toWorldCRS.getName())) {
			return;
		}

		Geometry destGeom = updateGeomNTT.getGeom().copy();
		destGeom.apply(new ReprojectCoordinateSequenceFilter(fromCRS, toWorldCRS));
		destGeom.setSRID(0);

		updateGeomNTT.setWorld_geom(destGeom);
		internalDAO.updateWorldGeom(env.getTenantId(), table.getTableName(), updateGeomNTT);
	}
	
}
