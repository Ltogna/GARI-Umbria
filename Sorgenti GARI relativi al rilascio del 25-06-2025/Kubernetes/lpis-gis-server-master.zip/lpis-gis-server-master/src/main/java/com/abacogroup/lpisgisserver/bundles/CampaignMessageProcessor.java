package com.abacogroup.lpisgisserver.bundles;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.lpisgisserver.bundles.models.CampaignMessage;
import com.abacogroup.lpisgisserver.bundles.models.CampaignMessageList;
import com.abacogroup.lpisgisserver.bundles.models.I18nMessage;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.ntt.CampaignNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CampaignMessageProcessor extends AbstractMessageProcessor {

	private SupportDAO supportDAO;

	private static final String TABLE_NAME = "lpis_campaign";
	private static final String FIELD_NAME = "code";

	private final ObjectMapper objectMapper;

	private static final Logger log = LoggerFactory.getLogger(CampaignMessageProcessor.class);

	public CampaignMessageProcessor(DAOContainer dc) {
		super(dc);
		this.supportDAO = dc.getSupportDAO();
		objectMapper = new ObjectMapper();
	}

	@Override
	public String getDomainName() {
		return "campaign";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> deleteCampaignMessage(message.getTenantId(), file));

		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
				&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.jsonl"))
		.forEach(file -> insertOrUpdateCampaignMessage(message.getTenantId(), file));
	}

	private void insertOrUpdateCampaignMessage(String tenantId, File file) {
		try {
			CampaignMessageList campaignMessages = objectMapper.readValue(file, CampaignMessageList.class);

			if (campaignMessages == null || campaignMessages.getCampaign_list() == null || campaignMessages.getCampaign_list().isEmpty()) {
				return;
			}

			ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).build();

			checkAndInsertOrUpdateCampaignMessageList(env, campaignMessages.getCampaign_list());
		} catch (Exception e) {
			log.error(String.format(ERROR_PROCESSING_FILE_MESSAGE, file.getName(), tenantId), e);
		}
	}

	private void checkAndInsertOrUpdateCampaignMessageList(ServiceSupportEnv env, List<CampaignMessage> campaignList) {
		campaignList.stream().forEach(message -> {
			try {
				if (StringUtils.isBlank(message.getCode()) || message.getReference_date() == null) {
					throw new IllegalStateException(
							"Campaign data not define, code: " + message.getCode() + " reference date: " + message.getReference_date());
				}

				CampaignNTT toInsertOrUpdate = CampaignNTT.builder()
						.code(message.getCode())
						.reference_date(message.getReference_date())
						.build();

				List<CampaignNTT> ntt = supportDAO.findCampaignByCodeAndTenant(toInsertOrUpdate.getCode(), env);
				if (ntt.isEmpty()) {
					supportDAO.insertCampaign(toInsertOrUpdate, env);
				} else if (!ntt.get(0).getReference_date().equals(toInsertOrUpdate.getReference_date())) {
					supportDAO.updateCampaign(toInsertOrUpdate, env);
				}

				I18nMessage i18nMessage = I18nMessage.builder()
						.table(TABLE_NAME)
						.field(FIELD_NAME)
						.value(message.getCode())
						.translations(message.getDescription())
						.build();
				insertOrUpdateI18nMessages(env.getTenantId(), i18nMessage);
			} catch (Exception e) {
				log.error("Error processing row " + message.toString() + FOR_TENANT + env.getTenantId(), e);
			}
		});
	}

	private void deleteCampaignMessage(String tenantId, File file) {
		try {
			CampaignMessageList campaignMessages = objectMapper.readValue(file, CampaignMessageList.class);

			if (campaignMessages == null || campaignMessages.getCampaign_list() == null || campaignMessages.getCampaign_list().isEmpty()) {
				return;
			}

			ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).build();

			campaignMessages.getCampaign_list().stream().forEach(message -> {
				try {
					if (StringUtils.isBlank(message.getCode())) {
						throw new IllegalStateException("Campaign code not defined");
					}

					List<CampaignNTT> ntt = supportDAO.findCampaignByCodeAndTenant(message.getCode(), env);
					if (!ntt.isEmpty()) {
						supportDAO.deleteCampaign(message.getCode(), env);
					}

				} catch (Exception e) {
					log.error("Error processing row " + message.toString() + FOR_TENANT + tenantId, e);
				}
			});

		} catch (Exception e) {
			log.error(String.format(ERROR_PROCESSING_FILE_MESSAGE, file.getName(), tenantId), e);
		}
	}

}
