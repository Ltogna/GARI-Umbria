package com.abacogroup.lpisgisserver.core.support;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class MatrixSearchParams {
	
	private AbsoluteDate referenceDate;
	private Long matrixId;
	private String matrixCode;
	private String classCode;
	private String classFilter;
	private String landcoverFilter;
	private String landuseFilter;

}
