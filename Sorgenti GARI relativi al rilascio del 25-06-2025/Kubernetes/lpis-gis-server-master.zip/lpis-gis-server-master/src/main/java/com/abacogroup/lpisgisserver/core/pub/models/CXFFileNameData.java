package com.abacogroup.lpisgisserver.core.pub.models;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class CXFFileNameData {
	String cadastralCode;
	String sectionCode;
	String sectorCode;
	String blockCode;
	String attachmentCode;
	String developmentCode;
	
	String srs;
	
	Long sectorId;
	Long blockId;
}
