package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverInfoGisNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelInfoGisNTT;
import com.abacogroup.lpisgisserver.resources.res.viewer.InfoGis;

@Mapper(uses = AbsoluteDateMapper.class)
public interface InfoGisMapper {

	InfoGisMapper INSTANCE = Mappers.getMapper(InfoGisMapper.class);

	@InheritInverseConfiguration()
	@Mapping(source = "elevation", target = "average_altitude")
	@Mapping(source = "slope", target = "average_slope")
	@Mapping(source = "aspect", target = "average_direction")
	InfoGis entityToDto(ParcelInfoGisNTT entity);

	@InheritInverseConfiguration()
	@Mapping(source = "elevation", target = "average_altitude")
	@Mapping(source = "slope", target = "average_slope")
	@Mapping(source = "aspect", target = "average_direction")
	InfoGis entityToDto(LandCoverInfoGisNTT entity);

}
