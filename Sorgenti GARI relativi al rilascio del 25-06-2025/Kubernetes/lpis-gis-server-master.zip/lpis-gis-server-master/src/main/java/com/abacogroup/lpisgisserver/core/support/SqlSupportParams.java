package com.abacogroup.lpisgisserver.core.support;

import java.util.List;
import java.util.Map;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SqlSupportParams {

	private String sql;
	private List<String> subSqlFilters;
	private Map<String, Object> mapFilters;
	private String topQuerySql;
	
	/**
	* Returns the SQL that should be executed. This is an unevaluated version of #sql ( String ) but can be used to filter the SQL for a more detailed explanation of the filter ( s ).
	* 
	* 
	* @return the SQL that should be executed including any sub - SQL filters if any were set on this object. If there are no sub - SQL filters it returns the empty string
	*/
	public String getFilteredSql() {
		String filteredSql = sql != null ? sql : "";
		
		// Add subSqlFilters to the SQL string.
		if(subSqlFilters != null && !subSqlFilters.isEmpty())
			filteredSql += String.join(" ", subSqlFilters);
		
		return filteredSql;
	}
	
	/**
	* Returns the top query SQL with filters applied. This is useful for debugging and to avoid SQL injection attacks.
	* 
	* 
	* @return the top query SQL with filters applied or null if there is no top query SQL or the filter is
	*/
	public String getTopQueryFilteredSql() {
		// Returns the top query sql if any.
		if(sql == null || topQuerySql == null)
			return null;
		
		return topQuerySql.replace("\\{__SQL__\\}", getFilteredSql());
	}
	
}
