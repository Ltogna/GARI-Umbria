package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.VarietyNTT;
import com.abacogroup.lpisgisserver.resources.res.units.Variety;

@Mapper
public interface VarietyMapper {

	VarietyMapper INSTANCE = Mappers.getMapper(VarietyMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	Variety entityToDto(VarietyNTT entity);
	
	@Mapping(target = "flVisible", expression = "java(dto.getVisible() ? 1 : 0)")
	@Mapping(target = "typeCode", ignore = true)
	VarietyNTT dtoToEntity(Variety dto);
}
