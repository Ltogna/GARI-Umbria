package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineDoIgtNTT;
import com.abacogroup.lpisgisserver.resources.res.units.vine.DoIgt;

@Mapper
public interface DoigtMapper {

	DoigtMapper INSTANCE = Mappers.getMapper(DoigtMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	DoIgt entityToDto(VineDoIgtNTT entity);
	
	@Mapping(target = "flVisible", expression = "java(dto.getVisible() ? 1 : 0)")
	VineDoIgtNTT dtoToEntity(DoIgt dto);
}
