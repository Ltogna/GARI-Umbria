package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidSuspendSessionPayloadException extends AbstractException {
	private static final long serialVersionUID = -4478267432782293962L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_SUSPEND_SESSION_PAYLOAD;

	public InvalidSuspendSessionPayloadException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new InvalidSuspendSessionPayloadExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Suspend session payload is not valid")
	public static class InvalidSuspendSessionPayloadExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -4501398806571718838L;

		public InvalidSuspendSessionPayloadExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
