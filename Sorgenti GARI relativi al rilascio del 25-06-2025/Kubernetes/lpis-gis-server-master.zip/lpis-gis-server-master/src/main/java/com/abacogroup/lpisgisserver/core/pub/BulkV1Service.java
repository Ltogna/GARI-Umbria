package com.abacogroup.lpisgisserver.core.pub;


import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.proj4j.CoordinateReferenceSystem;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.LpisGisServerConfiguration;
import com.abacogroup.lpisgisserver.core.AnomaliesService;
import com.abacogroup.lpisgisserver.core.BaseService;
import com.abacogroup.lpisgisserver.core.ErrorDescriptionsService;
import com.abacogroup.lpisgisserver.core.ExternalConfigService;
import com.abacogroup.lpisgisserver.core.InternalConfigService;
import com.abacogroup.lpisgisserver.core.StyleService;
import com.abacogroup.lpisgisserver.core.UnitsSupportService;
import com.abacogroup.lpisgisserver.core.enums.DatePrecision;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.ParcelSearchLevel;
import com.abacogroup.lpisgisserver.core.enums.UnitDictionaryTables;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.anomalies.GenericAnomalyException;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;
import com.abacogroup.lpisgisserver.core.exceptions.units.GenericUnitException;
import com.abacogroup.lpisgisserver.core.mappers.pub.AnomaliesListV1Mapper;
import com.abacogroup.lpisgisserver.core.support.CreateOrUpdateUnitPayload;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.BlockDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.FruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoversDetailsDAO;
import com.abacogroup.lpisgisserver.db.dao.OliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.ParcelDetailsDAO;
import com.abacogroup.lpisgisserver.db.dao.ParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.SectorDAO;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.dao.UnitCodesDAO;
import com.abacogroup.lpisgisserver.db.dao.UnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.VineUnitsDAO;
import com.abacogroup.lpisgisserver.db.ntt.BlockCacheNTT;
import com.abacogroup.lpisgisserver.db.ntt.BlockNTT;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.db.ntt.SectorCacheNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.CultivationStatusNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.FarmingFormNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.HeaderAnchoringNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.IrrigationNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.LandCoverUnitNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.PlantingTypeNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.PolesHeaderNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.PolesWeavingNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.ProductDestinationNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.ProtectionStructureNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.QualitySystemNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.SupportWiresNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.TerracingNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.VariationTypeNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.VarietyNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.fruit.FruitUnitDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.OliveUnitDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineAptitudeNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineDoIgtNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineUnitDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineyardNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.ReqContext;
import com.abacogroup.lpisgisserver.resources.req.pub.AnomalyRequestV1;
import com.abacogroup.lpisgisserver.resources.req.pub.CreateOrUpdateFruitUnitPayloadV1;
import com.abacogroup.lpisgisserver.resources.req.pub.CreateOrUpdateOliveUnitPayloadV1;
import com.abacogroup.lpisgisserver.resources.req.pub.bulk.BulkLandCoverPayloadV1;
import com.abacogroup.lpisgisserver.resources.req.pub.bulk.BulkParcelPayloadV1;
import com.abacogroup.lpisgisserver.resources.req.pub.bulk.BulkParcelsPayloadV1;
import com.abacogroup.lpisgisserver.resources.req.pub.bulk.BulkVineAptitudePayloadV1;
import com.abacogroup.lpisgisserver.resources.req.pub.bulk.BulkVineUnitPayloadV1;
import com.abacogroup.lpisgisserver.resources.res.anomalies.AnomaliesList;
import com.abacogroup.lpisgisserver.resources.res.pub.BulkParcelV1Response;
import com.abacogroup.lpisgisserver.resources.res.pub.ParcelV1;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.google.common.base.Objects;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BulkV1Service extends BaseService {

	private final SectorDAO sectorDAO;
	private final BlockDAO blockDAO;
	private final ParcelsDAO parcelsDAO;
	private final ParcelDetailsDAO parcelDetailsDAO;
	private final LandCoversDAO landCoversDAO;
	private final LandCoversDetailsDAO landCoversDetailsDAO;
	private final UnitCodesDAO unitCodesDAO;
	private final UnitsDAO unitsDAO;
	private final VineUnitsDAO vineUnitsDAO;
	private final OliveUnitsDAO oliveUnitsDAO;
	private final FruitUnitsDAO fruitUnitsDAO;
	private final SupportDAO supportDAO;

	private final UnitsSupportService unitsSupportService;
	private final ParcelV1Service parcelService;
	private final AnomaliesService anomaliesService;

	private Cache<String, SectorCacheNTT> sectorCache; //KEY: tenant|sectorCode
	private Cache<String, BlockCacheNTT> blockCache; //KEY: tenant|sectorCode|blockCode

	private static final String LANDCOVER_CODE_NOT_COMPATIBLE_ERROR_MESSAGE = "LC code: '%s',  unit type: '%s'";
	private static final AbsoluteDate INFINITE = AbsoluteDate.of("99991231");
	private final CoordinateReferenceSystem toWorldCRS = BaseService.getCRS("EPSG:3857");

	private String ANOMALY_GROUP_CODE = "LPIS-EDITOR";

	public BulkV1Service(LpisGisServerConfiguration configuration, DAOContainer dc, ParcelV1Service parcelService, 
			UnitsSupportService unitsSupportService, AnomaliesService anomaliesService, InternalConfigService internalConf,
			ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService, StyleService styleService,
			PluginEnvironment pluginEnvironment) {

		super(dc, internalConf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);
		this.sectorDAO = dc.getSectorDAO();
		this.blockDAO = dc.getBlockDAO();
		this.parcelsDAO = dc.getParcelsDAO();
		this.parcelDetailsDAO = dc.getParcelDetailsDAO();
		this.landCoversDAO = dc.getLandCoversDAO();
		this.landCoversDetailsDAO = dc.getLandCoversDetailsDAO();
		this.unitCodesDAO = dc.getUnitCodesDAO();
		this.unitsDAO = dc.getUnitsDAO();
		this.vineUnitsDAO = dc.getVineUnitsDAO();
		this.oliveUnitsDAO = dc.getOliveUnitsDAO();
		this.fruitUnitsDAO = dc.getFruitUnitsDAO();
		this.supportDAO = dc.getSupportDAO();

		this.unitsSupportService = unitsSupportService;
		this.parcelService = parcelService;
		this.anomaliesService = anomaliesService;

		if(configuration.getVariant() != null) {
			ANOMALY_GROUP_CODE = StringUtils.upperCase(configuration.getVariant());
		}

		sectorCache = Caffeine.newBuilder()
				.maximumSize(1000)
				.expireAfterAccess(Duration.ofHours(3))
				.build();

		blockCache= Caffeine.newBuilder()
				.maximumSize(1000)
				.expireAfterAccess(Duration.ofHours(3))
				.build();
	}

	public Response createBulkParcels(ReqContext reqContext, ServiceSupportEnv env, @NotNull @Valid BulkParcelsPayloadV1 payload) {

		BulkParcelV1Response response = BulkParcelV1Response.builder()
				.bulkParcels(new HashMap<>())
				.errors(new HashMap<>())
				.build();

		payload.getParcels().stream().forEach(parcel -> {
			Map<String, String> errorMap = checkBulkParcelPayload(reqContext, env, parcel);
			if(!errorMap.isEmpty()) {
				String errorKey = parcel.getSectorCode() + "-" + parcel.getBlockCode() + "-" + parcel.getParcel();
				response.getErrors().put(errorKey, errorMap);
			}
		});

		if(!response.getErrors().isEmpty()) {
			return Response.status(Status.BAD_REQUEST)
					.entity(response)
					.build();
		}

		parcelsDAO.useTransaction(parcelsDao -> payload.getParcels().stream()
				.forEach(parcel -> {
					String parcelRef = parcel.getSectorCode() + "-" + parcel.getBlockCode() + "-" + parcel.getParcel();
					response.getBulkParcels().put(parcelRef, insertBulkParcel(reqContext, env, parcel));
					})
				);

		return Response.status(Status.OK)
				.entity(response)
				.build();
	}

	private ParcelV1 insertBulkParcel(ReqContext reqContext, ServiceSupportEnv env, BulkParcelPayloadV1 parcel) {

		env.setIncludeUnits(1);
		
		Long parcelId = parcelsDAO.nextSequenceVal();
		env.setParcelId(parcelId);

		BlockNTT blockNTT = blockDAO.findBlockDetailsByTenantBlockCodeSectorCode(env.getTenantId(), parcel.getBlockCode(), parcel.getSectorCode());

		ParcelNTT parcelNTT = ParcelNTT.builder()
				.parcel_id(parcelId)
				.tenant_id(env.getTenantId())
				.parcel(parcel.getParcel())
				.block(blockNTT)
				.build();

		CoordinateReferenceSystem fromCRS = BaseService.getCRS(parcel.getSrs());
		Geometry worldGeom = reproject(parcel.getGeom(), fromCRS, toWorldCRS);
 
		ParcelDetailsNTT parcelDetailsNTT = ParcelDetailsNTT.builder()
				.pkid(parcelDetailsDAO.nextSequenceVal())
				.parcel_id(parcelId)
				.day_from(parcel.getDayFrom())
				.day_to(parcel.getDayTo())
				.srs(parcel.getSrs())
				.area_sqm((double) Math.round(parcel.getGeom().getArea()))
				.geom(parcel.getGeom())
				.world_geom(worldGeom)
				.source_code(parcel.getSourceCode())
				.external_code(parcel.getExternalCode())
				.build();

		parcelsDAO.insert(parcelNTT);
		parcelDetailsDAO.insert(parcelDetailsNTT, env.getUserId());

		AnomaliesList anomaliesResp = AnomaliesList.builder().anomalies_list(new ArrayList<>()).build();
		if(parcel.getAnomalies() != null && !parcel.getAnomalies().isEmpty()) {
			List<AnomalyRequestV1> anomalies = new ArrayList<>();

			String entityCode = this.internalConf.getStringValue(env.getTenantId(), InternalConfigKeys.ANOMALIES_PARCEL_ENTITY_CODE_KEY.getKey());

			parcel.getAnomalies().stream().forEach(code -> anomalies.add(AnomalyRequestV1.builder()
					.typeGroupCode(ANOMALY_GROUP_CODE)
					.typeCode(code)
					.entityCode(entityCode)
					.entityId(env.getParcelId().toString())
					.build()));

			anomaliesResp = anomaliesService.setParcelAnomalies(reqContext, env.getParcelId(), anomalies);

			if(anomaliesResp.getError() != null) {
				GenericAnomalyException ex = new GenericAnomalyException(Status.BAD_REQUEST, Operation.SET_PARCELS_ANOMALY, ErrorField.REQUEST,
						this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}

		}
		
		if(parcel.getLandcovers() != null) {
			parcel.getLandcovers().stream().forEach(lc -> insertBulkLandCover(env, lc));
		}

		ParcelV1 parcelResp = parcelService.getParcelDetails(env, parcelId, true, ParcelSearchLevel.SEARCH_ONLY_VALID);
		if(anomaliesResp != null) {
			parcelResp.setAnomalies(AnomaliesListV1Mapper.INSTANCE.toResponseV1(anomaliesResp));
		}

		return parcelResp;
	}

	private void insertBulkLandCover(ServiceSupportEnv env, BulkLandCoverPayloadV1 lc) {

		Long landCoverId = landCoversDAO.nextSequenceVal();

		CoordinateReferenceSystem fromCRS = BaseService.getCRS(lc.getSrs());
		Geometry worldGeom = reproject(lc.getGeom(), fromCRS, toWorldCRS);

		LandCoverNTT landCoverNTT = LandCoverNTT.builder()
				.land_cover_id(landCoverId)
				.parcel_id(env.getParcelId())
				.land_cover_details_id(landCoversDetailsDAO.nextSequenceVal())
				.land_cover_code(lc.getCode())
				.day_from(lc.getDayFrom())
				.day_to(lc.getDayTo())
				.srs(lc.getSrs())
				.area_sqm(lc.getGeom().getArea())
				.geom(lc.getGeom())
				.world_geom(worldGeom)
				.build();

		env.setLandCoverId(landCoverId);

		landCoversDAO.insert(landCoverNTT);
		landCoversDetailsDAO.insert(landCoverNTT, env.getUserId());

		if(lc.getVineUnits() != null) {
			lc.getVineUnits().stream().forEach(vineUnit -> insertBulkVineUnit(env, vineUnit));
		}
		
		if(lc.getOliveUnits() != null) {
			lc.getOliveUnits().stream().forEach(oliveUnit -> insertBulkOliveUnit(env, oliveUnit));
		}
		
		if(lc.getFruitUnits() != null) {
			lc.getFruitUnits().stream().forEach(fruitUnit -> insertBulkFruitUnit(env, fruitUnit));
		}
	}

	private void insertBulkVineUnit(ServiceSupportEnv env, BulkVineUnitPayloadV1 vineUnit) {

		UnitType unitType = UnitType.VINE_UNIT;
		Long unitId = unitsDAO.nextUnitIdVal();
		String unitCode = getNewUnitCode(env, unitType);

		LandCoverUnitNTT landCoverUnitNTT = LandCoverUnitNTT.builder()
				.unit_id(unitId)
				.land_cover_id(env.getLandCoverId())
				.type_code(unitType)
				.build();


		VineUnitDetailsNTT vineUnitDetailsNTT = VineUnitDetailsNTT.builder()
				.landCoverId(env.getLandCoverId())
				.unitDetailId(vineUnitsDAO.nextVineUnitDetailPkidVal())
				.unitId(unitId)
				.unitCode(unitCode)
				.typeCode(unitType)
				.variety(VarietyNTT.builder().code(vineUnit.getVarietyCode()).build())
				.areaSqm(vineUnit.getAreaSqm())
				.dayFrom(vineUnit.getDayFrom())
				.dayTo(vineUnit.getDayTo())
				.plantingDay(vineUnit.getPlantingDay())
				.plantingDayPrecision(vineUnit.getPlantingDayPrecision())
				.eradicateDay(vineUnit.getEradicateDay())
				.distanceOnTheRowCM(vineUnit.getDistanceOnTheRowCM())
				.distanceBetweenRowsCM(vineUnit.getDistanceBetweenRowsCM())
				.stumpsNumber(vineUnit.getStumpsNumber().intValue())
				.stumpsDensity100(vineUnit.getStumpsDensity100())
				.farmingForm(FarmingFormNTT.builder().code(vineUnit.getFarmingFormCode()).build())
				.irrigation(IrrigationNTT.builder().code(vineUnit.getIrrigationCode()).build())
				.productDestination(ProductDestinationNTT.builder().code(vineUnit.getProductDestinationCode()).build())
				.variationType(VariationTypeNTT.builder().code(vineUnit.getVariationTypeCode()).build())
				.cultivationStatus(CultivationStatusNTT.builder().code(vineUnit.getCultivationStatusCode()).build())
				.terracing(TerracingNTT.builder().code(vineUnit.getTerracingCode()).build())
				.failuresPerc(vineUnit.getFailuresPerc())
				.soilLayeringPerc(vineUnit.getSoilLayeringPerc())
				.altitudeAboveSeaLevel(vineUnit.getAltitudeAboveSeaLevel())
				.polesWeaving(PolesWeavingNTT.builder().code(vineUnit.getPolesWeavingCode()).build())
				.polesDistanceCM(vineUnit.getPolesDistanceCM())
				.supportWires(SupportWiresNTT.builder().code(vineUnit.getSupportWiresCode()).build())
				.headerAnchoring(HeaderAnchoringNTT.builder().code(vineUnit.getHeaderAnchoringCode()).build())
				.polesHeader(PolesHeaderNTT.builder().code(vineUnit.getPolesHeaderCode()).build())
				.externalCode(vineUnit.getExternalCode())
				.build();

		unitsDAO.insertLandCoverUnit(landCoverUnitNTT);
		vineUnitsDAO.insertVineUnitDetail(env, vineUnitDetailsNTT);

		if(vineUnit.getVineAptitudes() != null) {
			vineUnit.getVineAptitudes().stream().forEach(vineAptitude -> {
				Long vineAptitudePkid = vineUnitsDAO.nextVineUnitAptitudePkidVal();
				VineAptitudeNTT vineAptitudeNTT = VineAptitudeNTT.builder()
						.pkid(vineAptitudePkid)
						.unitId(unitId)
						.aptitudeId(vineAptitudePkid)
						.doigt(VineDoIgtNTT.builder().code(vineAptitude.getDoigtCode()).build())
						.dayFrom(vineAptitude.getDayFrom())
						.dayFromPrecision(vineAptitude.getDayFromPrecision())
						.dayTo(vineAptitude.getDayTo())
						.flPreventTypology(Boolean.TRUE.equals(vineAptitude.getPreventTypology()) ? 1 : 0)
						.flPreventClaim(Boolean.TRUE.equals(vineAptitude.getPreventClaim()) ? 1 : 0)
						.flPreventSuitability(Boolean.TRUE.equals(vineAptitude.getPreventSuitability()) ? 1 : 0)
						.vineyard(VineyardNTT.builder().code(vineAptitude.getVineyardCode()).build())
						.build();

				vineUnitsDAO.insertVineAptitude(env, vineAptitudeNTT);
			});
		}
	}
	
	private void insertBulkOliveUnit(ServiceSupportEnv env, CreateOrUpdateOliveUnitPayloadV1 oliveUnit) {
		
		UnitType unitType = UnitType.OLIVE_UNIT;
		Long unitId = unitsDAO.nextUnitIdVal();
		String unitCode = getNewUnitCode(env, unitType);
		
		LandCoverUnitNTT landCoverUnitNTT = LandCoverUnitNTT.builder()
				.unit_id(unitId)
				.land_cover_id(env.getLandCoverId())
				.type_code(unitType)
				.build();
		
		OliveUnitDetailsNTT oliveUnitDetailsNTT = OliveUnitDetailsNTT.builder()
				.landCoverId(env.getLandCoverId())
				.unitDetailId(oliveUnitsDAO.nextOliveUnitDetailPkidVal())
				.unitId(unitId)
				.unitCode(unitCode)
				.typeCode(unitType)
				.variety(VarietyNTT.builder().code(oliveUnit.getVarietyCode()).build())
				.areaSqm(oliveUnit.getAreaSqm())
				.dayFrom(oliveUnit.getDayFrom())
				.dayTo(oliveUnit.getDayTo())
				.plantingDay(oliveUnit.getPlantingDay())
				.plantingDayPrecision(oliveUnit.getPlantingDayPrecision())
				.eradicateDay(oliveUnit.getEradicateDay())
				.plantingType(PlantingTypeNTT.builder().code(oliveUnit.getPlantingTypeCode()).build())
				.distanceOnTheRowCM(oliveUnit.getDistanceOnTheRowCM())
				.distanceBetweenRowsCM(oliveUnit.getDistanceBetweenRowsCM())
				.plantsNumber(oliveUnit.getPlantsNumber() != null ? oliveUnit.getPlantsNumber().intValue() : null)
				.farmingForm(FarmingFormNTT.builder().code(oliveUnit.getFarmingFormCode()).build())
				.irrigation(IrrigationNTT.builder().code(oliveUnit.getIrrigationCode()).build())
				.productDestination(ProductDestinationNTT.builder().code(oliveUnit.getProductDestinationCode()).build())
				.altitudeAboveSeaLevel(oliveUnit.getAltitudeAboveSeaLevel())
				.qualitySystem(QualitySystemNTT.builder().code(oliveUnit.getQualitySystemCode()).build())
				.protectionStructure(ProtectionStructureNTT.builder().code(oliveUnit.getProtectionStructureCode()).build())
				.externalCode(oliveUnit.getExternalCode())
				.build();
		
		unitsDAO.insertLandCoverUnit(landCoverUnitNTT);
		oliveUnitsDAO.insertOliveUnitDetail(env, oliveUnitDetailsNTT);
	}
	private void insertBulkFruitUnit(ServiceSupportEnv env, CreateOrUpdateFruitUnitPayloadV1 fruitUnit) {
		UnitType unitType = UnitType.FRUIT_UNIT;
		Long unitId = unitsDAO.nextUnitIdVal();
		String unitCode = getNewUnitCode(env, unitType);
		
		LandCoverUnitNTT landCoverUnitNTT = LandCoverUnitNTT.builder()
				.unit_id(unitId)
				.land_cover_id(env.getLandCoverId())
				.type_code(unitType)
				.build();
		
		
		FruitUnitDetailsNTT fruitUnitDetailsNTT = FruitUnitDetailsNTT.builder()
				.landCoverId(env.getLandCoverId())
				.unitDetailId(fruitUnitsDAO.nextFruitUnitDetailPkidVal())
				.unitId(unitId)
				.unitCode(unitCode)
				.typeCode(unitType)
				.variety(VarietyNTT.builder().code(fruitUnit.getVarietyCode()).build())
				.areaSqm(fruitUnit.getAreaSqm())
				.dayFrom(fruitUnit.getDayFrom())
				.dayTo(fruitUnit.getDayTo())
				.plantingDay(fruitUnit.getPlantingDay())
				.plantingDayPrecision(fruitUnit.getPlantingDayPrecision())
				.eradicateDay(fruitUnit.getEradicateDay())
				.plantingType(PlantingTypeNTT.builder().code(fruitUnit.getPlantingTypeCode()).build())
				.distanceOnTheRowCM(fruitUnit.getDistanceOnTheRowCM())
				.distanceBetweenRowsCM(fruitUnit.getDistanceBetweenRowsCM())
				.plantsNumber(fruitUnit.getPlantsNumber() != null ? fruitUnit.getPlantsNumber().intValue() : null)
				.farmingForm(FarmingFormNTT.builder().code(fruitUnit.getFarmingFormCode()).build())
				.irrigation(IrrigationNTT.builder().code(fruitUnit.getIrrigationCode()).build())
				.altitudeAboveSeaLevel(fruitUnit.getAltitudeAboveSeaLevel())
				.qualitySystem(QualitySystemNTT.builder().code(fruitUnit.getQualitySystemCode()).build())
				.protectionStructure(ProtectionStructureNTT.builder().code(fruitUnit.getProtectionStructureCode()).build())
				.externalCode(fruitUnit.getExternalCode())
				.build();
		
		unitsDAO.insertLandCoverUnit(landCoverUnitNTT);
		fruitUnitsDAO.insertFruitUnitDetail(env, fruitUnitDetailsNTT);
	}

	private Map<String, String> checkBulkParcelPayload(ReqContext reqContext, ServiceSupportEnv env, BulkParcelPayloadV1 parcel) {

		Map<String, String> errorMap = new HashMap<>();

		setBulkParcelAnomaliesErrors(reqContext, env, parcel, errorMap);

		setBulkParcelSectorAndBlockErrors(env, parcel, errorMap);

		env.setSrs(parcel.getSrs());

		if(parcel.getDayFrom() == null) {
			parcel.setDayFrom(AbsoluteDate.of(LocalDate.now()));
		}

		if(parcel.getDayTo() == null) {
			parcel.setDayTo(INFINITE);
		}

		setBulkParcelLandCoversErrors(env, parcel, errorMap);

		return errorMap;
	}

	private void setBulkParcelLandCoversErrors(ServiceSupportEnv env, BulkParcelPayloadV1 parcel, Map<String, String> errorMap) {
		Double maxDifferenceArea = internalConf.getDoubleValue(env.getTenantId(), InternalConfigKeys.MAXIMUM_DIFFERENCE_LANDCOVER_AREA_KEY.getKey());
		
		if(parcel.getLandcovers() != null) {
			Double totalLandCoversAreaSqm = parcel.getLandcovers().stream()
					.mapToDouble(lc -> lc.getGeom().getArea())
					.sum();

			if((parcel.getGeom().getArea() - totalLandCoversAreaSqm) < -maxDifferenceArea) {
				ErrorCode errorCode = ErrorCode.TOTAL_LAND_COVERS_AREA_TOO_LARGE;
				errorMap.put(errorCode.toString(), getErrorDescription(env, errorCode, ""+totalLandCoversAreaSqm));
			}
			
			if((parcel.getGeom().getArea() - totalLandCoversAreaSqm) > maxDifferenceArea) {
				ErrorCode errorCode = ErrorCode.TOTAL_LAND_COVERS_AREA_TOO_SMALL;
				errorMap.put(errorCode.toString(), getErrorDescription(env, errorCode, ""+totalLandCoversAreaSqm));
			}

			parcel.getLandcovers().stream().forEach(lc -> checkBulkLandCoverPayload(env, lc, errorMap));
		}
	}

	private void setBulkParcelSectorAndBlockErrors(ServiceSupportEnv env, BulkParcelPayloadV1 parcel, Map<String, String> errorMap) {
		SectorCacheNTT sector = getSectorCacheNTT(env, parcel.getSectorCode());
		if(sector == null) {
			ErrorCode errorCode = ErrorCode.SECTOR_NOT_FOUND;
			errorMap.put(errorCode.toString(), getErrorDescription(env, errorCode, parcel.getSectorCode()));
		}

		BlockCacheNTT block = getBlockCacheNTT(env, parcel.getSectorCode(), parcel.getBlockCode());
		if(block == null) {
			ErrorCode errorCode = ErrorCode.BLOCK_NOT_FOUND;
			errorMap.put(errorCode.toString(), getErrorDescription(env, errorCode, parcel.getBlockCode()));
		}

		//check Parcel code
		if(block != null && parcelsDAO.checkParcelCodeExists(env.getTenantId(), block.getId(), parcel.getParcel()) != 0) {
			ErrorCode errorCode = ErrorCode.PARCEL_CODE_NOT_VALID;
			errorMap.put(errorCode.toString(), getErrorDescription(env, errorCode, parcel.getParcel()));
		}
		
		if(sector != null && !parcel.getSrs().equals(sector.getSrs())) {
			ErrorCode errorCode = ErrorCode.INVALID_SRS;
			errorMap.put(errorCode.toString(), getErrorDescription(env, errorCode, sector.getSrs()));
		}
	}

	private void setBulkParcelAnomaliesErrors(ReqContext reqContext, ServiceSupportEnv env, BulkParcelPayloadV1 parcel, Map<String, String> errorMap) {
		//check anomalies
		if(parcel.getAnomalies() != null && !parcel.getAnomalies().isEmpty()) {
			parcel.getAnomalies().stream().forEach(code -> {
				if(Boolean.FALSE.equals(anomaliesService.checkGroupCodeAndCodeExists(reqContext, ANOMALY_GROUP_CODE, code))) {
					ErrorCode errorCode = ErrorCode.ANOMALY_TYPE_CODE_NOT_VALID;
					errorMap.put(errorCode.toString(), getErrorDescription(env, errorCode, ANOMALY_GROUP_CODE+"|"+code));
				}				
			});
		}
	}

	private void checkBulkLandCoverPayload(ServiceSupportEnv env, BulkLandCoverPayloadV1 lc, Map<String, String> errorMap) {

		if(supportDAO.getLandCoversCodeByTenantAndCode(env.getTenantId(), lc.getCode()) == null) {
			ErrorCode errorCode = ErrorCode.LAND_COVER_CODE_NOT_FOUND;
			errorMap.put(errorCode.toString(), getErrorDescription(env, errorCode, lc.getCode()));
		}

		if(lc.getDayFrom() == null) {
			lc.setDayFrom(AbsoluteDate.of(LocalDate.now()));
		}

		if(lc.getDayTo() == null) {
			lc.setDayTo(INFINITE);
		}

		if(!lc.getSrs().equals(env.getSrs())) {
			ErrorCode errorCode = ErrorCode.INVALID_SRS;
			errorMap.put(errorCode.toString(), getErrorDescription(env, errorCode, env.getSrs()));
		}
		
		
//		List<UnitType> compatibleUnitTypes = unitsDAO.findLandCoverUnitsCompatibility(env, lc.getCode());
//		compatibleUnitTypes.forEach(ut -> checkLandCoverUnitArea(env, lc, ut, errorMap));

		if(lc.getVineUnits() != null) {
			lc.getVineUnits().stream().forEach(unit -> checkBulkVineUnitPayload(env, lc.getCode(), unit, errorMap));		
		}
		
		if(lc.getOliveUnits() != null) {
			lc.getOliveUnits().stream().forEach(unit ->  checkBulkOliveUnitPayload(env, lc.getCode(), unit, errorMap));
		}
		
		if(lc.getFruitUnits() != null) {
			lc.getFruitUnits().stream().forEach(unit ->  checkBulkFruitUnitPayload(env, lc.getCode(), unit, errorMap));
		}
	}
	
	private void checkLandCoverUnitArea(ServiceSupportEnv env, BulkLandCoverPayloadV1 lc, UnitType ut, Map<String, String> errorMap) {

		Double unitsArea;
		ErrorCode tooLargeAreaErrorCode = null;
		ErrorCode tooSmallAreaErrorCode = null;
		if(UnitType.VINE_UNIT.equals(ut)) {
			unitsArea = lc.getVineUnits().stream().mapToDouble(BulkVineUnitPayloadV1::getAreaSqm).sum();
			tooSmallAreaErrorCode = ErrorCode.TOTAL_VINE_UNITS_AREA_TOO_SMALL;
			tooLargeAreaErrorCode = ErrorCode.TOTAL_VINE_UNITS_AREA_TOO_LARGE;
		} else if(UnitType.OLIVE_UNIT.equals(ut)) {
			unitsArea = lc.getOliveUnits().stream().mapToDouble(CreateOrUpdateOliveUnitPayloadV1::getAreaSqm).sum();
			tooSmallAreaErrorCode = ErrorCode.TOTAL_OLIVE_UNITS_AREA_TOO_SMALL;
			tooLargeAreaErrorCode = ErrorCode.TOTAL_OLIVE_UNITS_AREA_TOO_LARGE;
		} else if(UnitType.FRUIT_UNIT.equals(ut)) {
			unitsArea = lc.getFruitUnits().stream().mapToDouble(CreateOrUpdateFruitUnitPayloadV1::getAreaSqm).sum();
			tooSmallAreaErrorCode = ErrorCode.TOTAL_FRUIT_UNITS_AREA_TOO_SMALL;
			tooLargeAreaErrorCode = ErrorCode.TOTAL_FRUIT_UNITS_AREA_TOO_LARGE;
		}
		else {
			ErrorCode errorCode = ErrorCode.LAND_COVER_CODE_NOT_COMPATIBLE;
			errorMap.put(errorCode.toString(), getErrorDescription(env, errorCode, lc.getCode()));
			return;
		}
		
		if(lc.getGeom().getArea() > unitsArea.doubleValue()) {
			errorMap.put(tooSmallAreaErrorCode.toString(), getErrorDescription(env, tooSmallAreaErrorCode, lc.getCode()));
		}
		
		if(lc.getGeom().getArea() < unitsArea.doubleValue()) {
			errorMap.put(tooLargeAreaErrorCode.toString(), getErrorDescription(env, tooLargeAreaErrorCode, lc.getCode()));
		}
		
	}

	private void checkBulkVineUnitPayload(ServiceSupportEnv env, String landCoverCode,
			BulkVineUnitPayloadV1 vineUnit, Map<String, String> errorMap) {

		if(unitsDAO.checkLandCoverCompatibility(env, landCoverCode, vineUnit.getUnitType()) != 1) {
			ErrorCode errorCode = ErrorCode.LAND_COVER_CODE_NOT_COMPATIBLE;
			String msg = String.format(LANDCOVER_CODE_NOT_COMPATIBLE_ERROR_MESSAGE, landCoverCode, UnitType.VINE_UNIT.name());
			errorMap.put(errorCode.toString(), getErrorDescription(env, errorCode, msg));
		}

		vineUnit.validateDate();

		Map<UnitDictionaryTables, ErrorCode> checkMap = new EnumMap<>(UnitDictionaryTables.class);
		checkMap.put(UnitDictionaryTables.CULTIVATION_STATUS, ErrorCode.CULTIVATION_STATUS_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.FARMING_FORM, ErrorCode.FARMING_FORM_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.IRRIGATION, ErrorCode.IRRIGATION_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.HEADER_ANCHORING, ErrorCode.HEADER_ANCHORING_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.POLES_HEADER, ErrorCode.POLES_HEADER_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.POLES_WEAVING, ErrorCode.POLES_WEAVING_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.PRODUCT_DESTINATION, ErrorCode.PRODUCT_DESTINATION_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.SUPPORT_WIRES, ErrorCode.SUPPORT_WIRES_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.TERRACING, ErrorCode.TERRACING_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.VARIATION_TYPE, ErrorCode.VARIATION_TYPE_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.VARIETY, ErrorCode.VARIETY_CODE_NOT_FOUND);

		checkMap.forEach((t, e) -> searchUnitsCodeOrPutError(env, vineUnit, errorMap, t.getCodeValue(vineUnit), t, e));

		checkBulkVineAptitudePayload(env, vineUnit.getVineAptitudes(), errorMap);

	}
	
	private void checkBulkOliveUnitPayload(ServiceSupportEnv env, String landCoverCode,
			CreateOrUpdateOliveUnitPayloadV1 oliveUnit, Map<String, String> errorMap) {
		
		if(unitsDAO.checkLandCoverCompatibility(env, landCoverCode, oliveUnit.getUnitType()) != 1) {
			ErrorCode errorCode = ErrorCode.LAND_COVER_CODE_NOT_COMPATIBLE;
			String msg = String.format(LANDCOVER_CODE_NOT_COMPATIBLE_ERROR_MESSAGE, landCoverCode, UnitType.OLIVE_UNIT.name());
			errorMap.put(errorCode.toString(), getErrorDescription(env, errorCode, msg));
		}
		
		oliveUnit.validateDate();
		
		Map<UnitDictionaryTables, ErrorCode> checkMap = new EnumMap<>(UnitDictionaryTables.class);
		checkMap.put(UnitDictionaryTables.VARIETY, ErrorCode.VARIETY_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.PLANTING_TYPE, ErrorCode.PLANTING_TYPE_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.FARMING_FORM, ErrorCode.FARMING_FORM_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.IRRIGATION, ErrorCode.IRRIGATION_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.PRODUCT_DESTINATION, ErrorCode.PRODUCT_DESTINATION_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.QUALITY_SYSTEM, ErrorCode.QUALITY_SYSTEM_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.PROTECTION_STRUCTURE, ErrorCode.PROTECTION_STRUCTURE_CODE_NOT_FOUND);
		
		checkMap.forEach((t, e) -> searchUnitsCodeOrPutError(env, oliveUnit, errorMap, t.getCodeValue(oliveUnit), t, e));		
	}
	
	private void checkBulkFruitUnitPayload(ServiceSupportEnv env, String landCoverCode,
			CreateOrUpdateFruitUnitPayloadV1 fruitUnit, Map<String, String> errorMap) {
		
		if(unitsDAO.checkLandCoverCompatibility(env, landCoverCode, fruitUnit.getUnitType()) != 1) {
			ErrorCode errorCode = ErrorCode.LAND_COVER_CODE_NOT_COMPATIBLE;
			String msg = String.format(LANDCOVER_CODE_NOT_COMPATIBLE_ERROR_MESSAGE, landCoverCode, UnitType.FRUIT_UNIT.name());
			errorMap.put(errorCode.toString(), getErrorDescription(env, errorCode, msg));
		}
		
		fruitUnit.validateDate();
		
		Map<UnitDictionaryTables, ErrorCode> checkMap = new EnumMap<>(UnitDictionaryTables.class);
		checkMap.put(UnitDictionaryTables.VARIETY, ErrorCode.VARIETY_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.PLANTING_TYPE, ErrorCode.PLANTING_TYPE_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.FARMING_FORM, ErrorCode.FARMING_FORM_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.IRRIGATION, ErrorCode.IRRIGATION_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.QUALITY_SYSTEM, ErrorCode.QUALITY_SYSTEM_CODE_NOT_FOUND);
		checkMap.put(UnitDictionaryTables.PROTECTION_STRUCTURE, ErrorCode.PROTECTION_STRUCTURE_CODE_NOT_FOUND);
		
		checkMap.forEach((t, e) -> searchUnitsCodeOrPutError(env, fruitUnit, errorMap, t.getCodeValue(fruitUnit), t, e));		
	}

	private <T extends CreateOrUpdateUnitPayload> void searchUnitsCodeOrPutError(ServiceSupportEnv env, T unit, Map<String, String> errorMap, 
			String code, UnitDictionaryTables dictionaryTable, ErrorCode errorCode) {
		if((code == null && unit.getMandatoryDictionayTable().contains(dictionaryTable)) ||
				!Objects.equal(unitsSupportService.getBulkUnitCodeIfExist(env, unit, dictionaryTable, code), code)) {
			errorMap.put(errorCode.toString(), getErrorDescription(env, errorCode, code));
		}
	}


	private void checkBulkVineAptitudePayload(ServiceSupportEnv env, List<BulkVineAptitudePayloadV1> list, Map<String, String> errorMap) {
		if (list == null) {
			return;
		}

		list.stream().forEach(aptitude -> {
			
			if (aptitude.getDayFrom() == null) {
				aptitude.setDayFrom(AbsoluteDate.of(LocalDate.now()));
				aptitude.setDayFromPrecision(DatePrecision.YMD);
			}

			if (aptitude.getDayTo() == null) {
				aptitude.setDayTo(INFINITE);
			}
			
			VineDoIgtNTT doIgt = unitCodesDAO.findVineDoigtByCode(env.getTenantId(), aptitude.getDoigtCode());
			if (doIgt == null) {
				ErrorCode errorCode = ErrorCode.DOIGT_CODE_NOT_FOUND;
				errorMap.put(errorCode.toString(), getErrorDescription(env, errorCode, aptitude.getDoigtCode()));
				return;
			}
			
			checkVineyardCode(env, doIgt.getId(), aptitude.getVineyardCode(), errorMap);

		});
	}
	
	private void checkVineyardCode(ServiceSupportEnv env, Long doigtId, String vineyardCode, Map<String, String> errorMap) {
		if(vineyardCode == null) {
			return;
		}
		
		VineyardNTT vineyard = unitCodesDAO.findVineyardByCode(env.getTenantId(), vineyardCode);
		if(vineyard == null) {
			ErrorCode errorCode = ErrorCode.VINEYARD_CODE_NOT_FOUND;
			errorMap.put(errorCode.toString(), getErrorDescription(env, errorCode, vineyardCode));
			return;
		}
		
		if(doigtId != null && unitCodesDAO.checkVineyardDoigtCompatibility(vineyard.getId(), doigtId) != 1) {
			ErrorCode errorCode = ErrorCode.VINEYARD_AND_DOIGT_CODE_NOT_COMPATIBLE;
			errorMap.put(errorCode.toString(), getErrorDescription(env, errorCode, vineyardCode));
		}
	}

	private String getErrorDescription(ServiceSupportEnv env, ErrorCode errorCode, String code) {
		Map<String, Map<String, String>> errorDescriptions = this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId());
		return (errorDescriptions.containsKey(errorCode.toString()) && errorDescriptions.get(errorCode.toString()).containsKey(env.getLang())
				? errorDescriptions.get(errorCode.toString()).get(env.getLang())
						: errorCode.getDescription()
				) + " ("+code+")";
	}

	private SectorCacheNTT getSectorCacheNTT(ServiceSupportEnv env, String sectorCode) {
		if(env == null || env.getTenantId() == null) {
			GenericUnitException ex = new GenericUnitException(Status.BAD_REQUEST, Operation.GET_UNITS_CODE, ErrorField.REQUEST,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if(sectorCode == null) {
			GenericUnitException ex = new GenericUnitException(Status.BAD_REQUEST, Operation.GET_UNITS_CODE, ErrorField.SECTOR_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		String tenantId = env.getTenantId();

		String key = tenantId + "|" + sectorCode;
		SectorCacheNTT sector = sectorCache.getIfPresent(key);

		//load codes
		if(sector == null ) {
			return loadSectorCache(env, sectorCode);
		}

		return sector;
	}

	private SectorCacheNTT loadSectorCache(ServiceSupportEnv env, String sectorCode) {

		SectorCacheNTT sector = sectorDAO.findSectorCacheByTenantAndCode(env.getTenantId(), sectorCode);
		if(sector == null) {
			return null;
		}

		String key = env.getTenantId() + "|" + sectorCode;
		sectorCache.put(key, sector);

		return sector;
	}

	private BlockCacheNTT getBlockCacheNTT(ServiceSupportEnv env, String sectorCode, String blockCode) {
		if(env == null || env.getTenantId() == null) {
			GenericUnitException ex = new GenericUnitException(Status.BAD_REQUEST, Operation.GET_UNITS_CODE, ErrorField.REQUEST,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if(sectorCode == null) {
			GenericUnitException ex = new GenericUnitException(Status.BAD_REQUEST, Operation.GET_UNITS_CODE, ErrorField.SECTOR_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if(blockCode == null) {
			GenericUnitException ex = new GenericUnitException(Status.BAD_REQUEST, Operation.GET_UNITS_CODE, ErrorField.BLOCK_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		String tenantId = env.getTenantId();

		String key = tenantId + "|" + sectorCode + "|" + blockCode;
		BlockCacheNTT block = blockCache.getIfPresent(key);

		//load codes
		if(block == null ) {
			return loadBlockCache(env, sectorCode, blockCode);
		}

		return block;
	}

	private BlockCacheNTT loadBlockCache(ServiceSupportEnv env, String sectorCode, String blockCode) {

		BlockCacheNTT block = blockDAO.findBlockCacheByTenantBlockCodeSectorCode(env.getTenantId(), blockCode, sectorCode);
		if(block == null) {
			return null;
		}

		String key = env.getTenantId() + "|" + sectorCode + "|" + blockCode;
		blockCache.put(key, block);

		return block;
	}
}
