package com.abacogroup.lpisgisserver.core.exceptions.viewer;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class SectorViewerNotFoundException extends AbstractException {

	private static final long serialVersionUID = -3129215421128118821L;

	private static final ErrorCode ERROR_CODE = ErrorCode.SECTOR_VIEWER_NOT_FOUND;

	public SectorViewerNotFoundException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new SectorViewerNotFoundExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Sector viewer not found")
	public static class SectorViewerNotFoundExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 3240724220471461447L;

		public SectorViewerNotFoundExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
