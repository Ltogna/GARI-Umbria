package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.CampaignNTT;
import com.abacogroup.lpisgisserver.resources.res.Campaign;

@Mapper(uses = AbsoluteDateMapper.class)
public interface CampaignMapper {
	CampaignMapper INSTANCE = Mappers.getMapper(CampaignMapper.class);

	@InheritInverseConfiguration()
	Campaign entityToDto(CampaignNTT entity);

	CampaignNTT dtoToEntity(Campaign dto);
}
