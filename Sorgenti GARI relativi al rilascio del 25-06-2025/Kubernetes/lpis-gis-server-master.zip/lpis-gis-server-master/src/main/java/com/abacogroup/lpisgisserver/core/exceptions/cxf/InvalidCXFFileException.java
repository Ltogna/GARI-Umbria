package com.abacogroup.lpisgisserver.core.exceptions.cxf;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidCXFFileException extends AbstractException {

	private static final long serialVersionUID = 2365139305279871451L;
	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_CXF_FILE;

	public InvalidCXFFileException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new InvalidCXFFileExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Invalid CXF input file")
	public static class InvalidCXFFileExceptionBody extends AbstractExceptionBody {

		private static final long serialVersionUID = -6962708985925137216L;

		public InvalidCXFFileExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
