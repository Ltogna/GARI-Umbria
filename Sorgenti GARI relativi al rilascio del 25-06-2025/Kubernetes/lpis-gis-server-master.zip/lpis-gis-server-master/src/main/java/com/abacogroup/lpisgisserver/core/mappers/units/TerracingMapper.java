package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.TerracingNTT;
import com.abacogroup.lpisgisserver.resources.res.units.Terracing;

@Mapper
public interface TerracingMapper {

	TerracingMapper INSTANCE = Mappers.getMapper(TerracingMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	Terracing entityToDto(TerracingNTT entity);
	
	@Mapping(target = "flVisible", expression = "java(dto.getVisible() ? 1 : 0)")
	@Mapping(target = "typeCode", ignore = true)
	TerracingNTT dtoToEntity(Terracing dto);
}
