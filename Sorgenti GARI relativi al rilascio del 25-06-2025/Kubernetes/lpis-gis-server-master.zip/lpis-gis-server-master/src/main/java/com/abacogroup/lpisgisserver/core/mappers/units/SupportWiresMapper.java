package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.SupportWiresNTT;
import com.abacogroup.lpisgisserver.resources.res.units.SupportWires;

@Mapper
public interface SupportWiresMapper {

	SupportWiresMapper INSTANCE = Mappers.getMapper(SupportWiresMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	SupportWires entityToDto(SupportWiresNTT entity);
	
	@Mapping(target = "flVisible", expression = "java(dto.getVisible() ? 1 : 0)")
	@Mapping(target = "typeCode", ignore = true)
	SupportWiresNTT dtoToEntity(SupportWires dto);
}
