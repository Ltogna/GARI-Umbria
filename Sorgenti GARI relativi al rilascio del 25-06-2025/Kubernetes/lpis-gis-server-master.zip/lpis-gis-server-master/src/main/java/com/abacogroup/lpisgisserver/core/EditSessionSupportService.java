package com.abacogroup.lpisgisserver.core;

import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.ParcelNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidEditSessionException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidEditSessionPayloadException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidInitSessionDataException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidLockGeomException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidLockSrsException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionEmptyParcelException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionGeomException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionParcelGeomException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionParcelIdException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionParcelSrsException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidUserEditSessionException;
import com.abacogroup.lpisgisserver.core.exceptions.session.NothingToSaveException;
import com.abacogroup.lpisgisserver.core.exceptions.session.SessionParcelAlreadyLockedException;
import com.abacogroup.lpisgisserver.core.exceptions.session.SessionParcelDataRetrievingProblemException;
import com.abacogroup.lpisgisserver.core.exceptions.ts.NoScopeOnParcelException;
import com.abacogroup.lpisgisserver.core.exceptions.ts.NoScopeOnSectorException;
import com.abacogroup.lpisgisserver.core.mappers.LandCoversMapper;
import com.abacogroup.lpisgisserver.core.mappers.ParcelsMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.FruitUnitMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.OliveUnitMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.VineUnitMapper;
import com.abacogroup.lpisgisserver.core.models.session.BuildSessionPreviewParcelLandCovers;
import com.abacogroup.lpisgisserver.core.support.EditorSupportParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.core.ts.TerScoService;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditFruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.EditOliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.EditParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.EditSessionsDAO;
import com.abacogroup.lpisgisserver.db.dao.EditVineUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.FruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.LockParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.OliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.ParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.StackFruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.StackOliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.StackVineUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.UnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.VineUnitsDAO;
import com.abacogroup.lpisgisserver.db.ntt.EditSessionNTT;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.db.ntt.SectorNTT;
import com.abacogroup.lpisgisserver.db.ntt.StackFruitUnitsNTT;
import com.abacogroup.lpisgisserver.db.ntt.StackOliveUnitsNTT;
import com.abacogroup.lpisgisserver.db.ntt.StackVineAptitudeNTT;
import com.abacogroup.lpisgisserver.db.ntt.StackVineUnitsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.LandCoverUnitNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.fruit.FruitUnitDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.fruit.FruitUnitNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.OliveUnitDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.OliveUnitNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineAptitudeNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineUnitDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineUnitNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.CataloguePayload;
import com.abacogroup.lpisgisserver.resources.req.CreateEditSessionPayload;
import com.abacogroup.lpisgisserver.resources.req.ReqContext;
import com.abacogroup.lpisgisserver.resources.res.CatalogueGeom;
import com.abacogroup.lpisgisserver.resources.res.LandCoverWithUnits;
import com.abacogroup.lpisgisserver.resources.res.LayerStyle;
import com.abacogroup.lpisgisserver.resources.res.Parcel;
import com.abacogroup.lpisgisserver.resources.res.ParcelWithErrors;
import com.abacogroup.lpisgisserver.resources.res.SessionCheckResult;
import com.google.common.collect.Iterators;
import com.google.common.collect.UnmodifiableIterator;

import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EditSessionSupportService extends BaseService {

	private static final int DO_NOT_INCLUDE_OUTDATED_PARCELS = 0;
	private final EditSessionsDAO editSessionsDAO;
	private final EditParcelsDAO editParcelsDAO;
	private final ParcelsDAO parcelsDAO;
	private final LockParcelsDAO lockParcelsDAO;
	private final LandCoversDAO landCoversDAO;
	private final UnitsDAO unitsDAO;
	private final VineUnitsDAO vineUnitsDAO;
	private final EditVineUnitsDAO editVineUnitsDAO;
	private final OliveUnitsDAO oliveUnitsDAO;
	private final FruitUnitsDAO fruitUnitsDAO;
	private final EditOliveUnitsDAO editOliveUnitsDAO;
	private final EditFruitUnitsDAO editFruitUnitsDAO;
	private final StackVineUnitsDAO stackVineUnitsDAO;
	private final StackOliveUnitsDAO stackOliveUnitsDAO;
	private final StackFruitUnitsDAO stackFruitUnitsDAO;
	
	private final TerScoService terScoService;
	private final SupportSessionAnomaliesService supportSessionAnomalyService;
	private final CataloguesService cataloguesService;

	public EditSessionSupportService(DAOContainer dc, 
			InternalConfigService internalConf, ExternalConfigService externalConf, 
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, 
			TerScoService terScoService, SupportSessionAnomaliesService supportSessionAnomalyService, 
			CataloguesService cataloguesService, PluginEnvironment pluginEnvironment) {
		super(dc, internalConf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.editSessionsDAO = dc.getEditSessionsDAO();
		this.editParcelsDAO = dc.getEditParcelsDAO();
		this.parcelsDAO = dc.getParcelsDAO();
		this.lockParcelsDAO = dc.getLockParcelsDAO();
		this.landCoversDAO = dc.getLandCoversDAO();
		this.unitsDAO = dc.getUnitsDAO();
		this.vineUnitsDAO = dc.getVineUnitsDAO();
		this.editVineUnitsDAO = dc.getEditVineUnitsDAO();
		this.oliveUnitsDAO = dc.getOliveUnitsDAO();
		this.fruitUnitsDAO = dc.getFruitUnitsDAO();
		this.editOliveUnitsDAO = dc.getEditOliveUnitsDAO();
		this.editFruitUnitsDAO = dc.getEditFruitUnitsDAO();
		this.stackVineUnitsDAO = dc.getStackVineUnitsDAO();
		this.stackOliveUnitsDAO = dc.getStackOliveUnitsDAO();
		this.stackFruitUnitsDAO = dc.getStackFruitUnitsDAO();
		
		this.terScoService = terScoService;
		this.supportSessionAnomalyService = supportSessionAnomalyService;
		this.cataloguesService = cataloguesService;
	}

	public void checkCanEditParcel(@NotNull ServiceSupportEnv env, Long parcelId) {
		checkCanEditParcel(env, parcelId, false);
	}
	
	// XXX the client should call a different api, for now set skipScopeCheck for hot-fix
	public void checkCanEditParcel(@NotNull ServiceSupportEnv env, Long parcelId, boolean skipScopeCheck) {
		if (    (StringUtils.isEmpty(env.getUserId()) || env.getTenantId() == null) 
			||	(parcelId != null && editSessionsDAO.countUserParcel(env.getTenantId(), parcelId) != 1)) {
			
			InvalidSessionParcelIdException ex = new InvalidSessionParcelIdException(Status.BAD_REQUEST,
					Operation.SESSION_PREVIEW, ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		if(!skipScopeCheck) {
			checkHasScopeOnParcel(env, parcelId);
		}
		
	}
	
	public void checkScopes(ServiceSupportEnv env, List<Long> parcelIds, List<Long> sectorIds) {
		if (parcelIds != null) {
			parcelIds.forEach(p -> {
				if (p < 0) {
					List<SectorNTT> sectorNTTs = editParcelsDAO.findInEditBySessionId(env.getSessionId(), env.getReferenceDate(), p).stream()
							.map(ParcelNTT::getSector)
							.collect(Collectors.toList());

					if (sectorNTTs == null || sectorNTTs.size() != 1) {
						ParcelNotFoundException ex = new ParcelNotFoundException(Status.NOT_FOUND, Operation.SESSION_PREVIEW,
								ErrorField.PARCEL_ID,
								this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

						log.error(ex.getBody().getLogErrorMessage());

						throw ex;
					}

					checkHasScopeOnSector(env, sectorNTTs.get(0).getId());

				} else {
					checkHasScopeOnParcel(env, p);
				}
			});
		}

		if (sectorIds != null) {
			sectorIds.forEach(s -> checkHasScopeOnSector(env, s));
		}

	}

	private void checkHasScopeOnParcel(@NotNull ServiceSupportEnv env, Long parcelId) {
		if(parcelId != null && !terScoService.hasScopeOnParcel(env, parcelId)) {
			NoScopeOnParcelException ex = new NoScopeOnParcelException(Status.UNAUTHORIZED,
					Operation.SESSION_PREVIEW, ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;			
		}
	}
	
	private void checkHasScopeOnSector(@NotNull ServiceSupportEnv env, Long sectorId) {

		if((StringUtils.isEmpty(env.getUserId()) || env.getTenantId() == null) 
				||	sectorId != null && !terScoService.hasScopeOnSector(env, sectorId)) {
			NoScopeOnSectorException ex = new NoScopeOnSectorException(Status.UNAUTHORIZED,
					Operation.SESSION_PREVIEW, ErrorField.SECTOR_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;			
		}
		
	}

	/**
	 * during editing operations, check if session data is valid
	 */
	public void checkEditableSession(EditorSupportParams params, Operation operation) {
		if (params == null) {
			InvalidInitSessionDataException ex = new InvalidInitSessionDataException(Status.BAD_REQUEST,
					operation, ErrorField.EDIT_PARAMS,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), ErrorDescriptionsService.DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if (params.getReqContext() == null) {
			InvalidUserEditSessionException ex = new InvalidUserEditSessionException(Status.BAD_REQUEST,
					params.getOperation(), ErrorField.REQUEST_CONTEXT,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), ErrorDescriptionsService.DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if (params.getSession() == null) {
			InvalidEditSessionException ex = new InvalidEditSessionException(Status.BAD_REQUEST, params.getOperation(), ErrorField.SESSION,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getReqContext().getTenantId()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if (params.getSession().getDt_last_lock() == null ||
				params.getSession().getDt_last_lock().isBefore(this.internalConf.getLastValidSessionTime(params.getReqContext().getTenantId()))) {
			
			params.setSession(this.getValidSession(params.getReqContext(), params.getSession().getUuid()));

		}
	}

	public EditSessionNTT getValidSession(ReqContext reqContext, String sessionId) {		
		EditSessionNTT session = editSessionsDAO.findValidUserSession(sessionId, reqContext.getTenantId(), reqContext.getUser().getName(), this.internalConf.getLastValidSessionTime(reqContext.getTenantId()));
		if (session == null) {
			InvalidEditSessionException ex = new InvalidEditSessionException(Status.BAD_REQUEST,
					Operation.GET_SESSION, ErrorField.SESSION,
					this.errorDescriptionsService.getTenantErrorDescriptions(reqContext.getTenantId()), reqContext.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return session;
	}

	public Long findIntersectedSessionLockGeom(String tenantId, String myUuid, Geometry enlargedMBR) {
		return editSessionsDAO.findOtherLockedGeoms(tenantId, enlargedMBR, myUuid, this.internalConf.getLastValidSessionTime(tenantId));
	}

	public boolean canDelete(EditSessionNTT session) {
		if (session == null) {
			InvalidEditSessionException ex = new InvalidEditSessionException(Status.BAD_REQUEST, Operation.DELETE_SESSION, ErrorField.SESSION,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return editSessionsDAO.findUserSession(session.getUuid(), session.getTenant_id(), session.getUser_id()) != null;
	}

	// TODO REMOVE
//	public boolean checkValidSession(ServiceSupportEnv env, EditSessionNTT session, List<ParcelNTT> inEditParcels, Boolean forceNewParcelVersion) {
//		if (env == null || session == null) {
//			String tenantId = env != null ? env.getTenantId() : StringUtils.EMPTY;
//			String lang = env != null ? env.getLang() : DEFAULT_LANG_CODE;
//
//			InvalidEditSessionException ex = new InvalidEditSessionException(Status.BAD_REQUEST,
//					Operation.SAVE_SESSION, ErrorField.SESSION,
//					this.errorDescriptionsService.getTenantErrorDescriptions(tenantId), lang);
//
//			log.error(ex.getBody().getLogErrorMessage());
//
//			throw ex;
//		}
//
//		if (inEditParcels == null)
//			inEditParcels = new ArrayList<>();
//
//		List<EditStatus> excludesStatus = Arrays.asList(EditStatus.TOPOLOGY_CORRECTED);
//
//		checkWrongParcelsNameAndArea(env, session, excludesStatus);
//
//		checkLandCoverErrors(env, session, inEditParcels, excludesStatus);
//
//		checkNewParcelsDeletedDuringSession(env, session, inEditParcels, forceNewParcelVersion);
//
//		return true;
//	}

	/**
	 * If in session there are no edited parcels excluded some new but deleted during session the user must confirm the 
	 * new version of parcel if possible from configuration.
	 * If confirmed the session parcel is imported in session as if edited.
	 * Obviously the session must have an associated parcelid.
	 */
	public SessionCheckResult checkNewParcelsDeletedDuringSession(ServiceSupportEnv env, EditSessionNTT session, List<ParcelNTT> inEditParcels,
			Boolean forceNewParcelVersion) {
		// remove from check the new parcels deleted during session
		if (inEditParcels.stream().filter(p -> !(p.getParcel_id() < 0 && p.getParent_id() == null && p.getGeom() == null)).count() < 1) {
			// If client confirm "force new version" try to save
			Boolean forceNewParcelVersionConfig = internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_FORCE_NEW_PARCEL_VERSION_KEY);
			if (Boolean.FALSE.equals(forceNewParcelVersionConfig)) {
				throwNothingToSave(env);
			} 

			List<ParcelNTT> parcels = editParcelsDAO.findNotInEditBySessionId(env, session.getParcel_id());
			// if the session has a parcel id and it is locked then copy it in edit otherwise exception
			if (session.getParcel_id() == null || (parcels == null || parcels.isEmpty())) {					
				InvalidSessionEmptyParcelException ex = new InvalidSessionEmptyParcelException(Status.BAD_REQUEST,
						Operation.SAVE_SESSION, ErrorField.PARCEL,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}

			ParcelNTT parcelToInsert = parcels.get(0);
			parcelToInsert.setEdit_id(editParcelsDAO.nextSequenceVal());
			parcelToInsert.setEdit_status(EditStatus.CONFIRMED);
			
			// If forced insert parcel in edit
			if(Boolean.TRUE.equals(forceNewParcelVersion)) {
				editParcelsDAO.insert(session.getUuid(), parcelToInsert);
				inEditParcels.add(parcelToInsert);
			} else {
				throwNothingToSave(env);
			}
			
			// Check the parcel
			ParcelWithErrors parcelToCheck = ParcelsMapper.INSTANCE.entityToDtoWithErrors(parcelToInsert);
			supportSessionAnomalyService.checkParcelErrors(env, parcelToCheck, supportSessionAnomalyService.getExcludesStatus());
			
			if(!parcelToCheck.getErrorList().isEmpty() || !parcelToCheck.getLandCovers().isEmpty()) {
				return SessionCheckResult.builder().parcels(Arrays.asList(parcelToCheck)).build();
			}
		}
		
		return null;
	}


	private void throwNothingToSave(ServiceSupportEnv env) {
		NothingToSaveException ex = new NothingToSaveException(Status.BAD_REQUEST,
				Operation.SAVE_SESSION, ErrorField.SESSION,
				this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

		log.error(ex.getBody().getLogErrorMessage());

		throw ex;
	}

	public void checkSessionParcel(ServiceSupportEnv env, ParcelNTT parcel) {
		// XXX Richiesta da Samuele, se questo risultato e' nullo perche' alla reference date non esiste ancora/piu' 
		//     la parcella ritorna una lock geom sulla prima versione disponibile
		if (parcel == null)
		{
			SessionParcelDataRetrievingProblemException ex = new SessionParcelDataRetrievingProblemException(Status.BAD_REQUEST,
					Operation.SESSION_PREVIEW, ErrorField.PARCEL,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		// XXX nella prossima versione si dovranno accetare anche geometrie nulle per le
		//     parcelle gia' codificate, per la consistenza, ma senza geometria
		if (parcel.getGeom() == null || parcel.getGeom().isEmpty()) 
		{
			InvalidSessionParcelGeomException ex = new InvalidSessionParcelGeomException(Status.BAD_REQUEST,
					Operation.SESSION_PREVIEW, ErrorField.GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if (parcel.getSrs() == null || parcel.getSrs().isBlank()) {
			InvalidSessionParcelSrsException ex = new InvalidSessionParcelSrsException(Status.BAD_REQUEST,
					Operation.SESSION_PREVIEW, ErrorField.PARCEL_SRS,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}

	public void checkReqContextAndCreateSessionPayload(ReqContext reqContext, CreateEditSessionPayload payload, Operation operation) {

		if (reqContext == null || reqContext.getUser() == null || StringUtils.isBlank(reqContext.getTenantId())) {
			InvalidUserEditSessionException ex = new InvalidUserEditSessionException(Status.BAD_REQUEST,
					operation, ErrorField.REQUEST_CONTEXT,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if (payload == null) {
			InvalidEditSessionPayloadException ex = new InvalidEditSessionPayloadException(Status.BAD_REQUEST,
					operation, ErrorField.PAYLOAD,
					this.errorDescriptionsService.getTenantErrorDescriptions(reqContext.getTenantId()), reqContext.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}

	public void checkReqContextAndCreateSessionPayloadInitData(ReqContext reqContext, CreateEditSessionPayload payload, Operation operation) {

		checkReqContextAndCreateSessionPayload(reqContext, payload, operation);

		// Check Init Data
		if (payload.getTask_id() == null && payload.getParcel_id() == null && payload.getLock_geom() == null
				&& (payload.getSketches() == null || payload.getSketches().isEmpty())) {
			InvalidInitSessionDataException ex = new InvalidInitSessionDataException(Status.BAD_REQUEST,
					Operation.SESSION_PREVIEW, ErrorField.REQUEST,
					this.errorDescriptionsService.getTenantErrorDescriptions(reqContext.getTenantId()), reqContext.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}

	public void updateParcelIdByTenantAndSessionId(EditorSupportParams params, Long parcelId) {
		if (params == null || params.getSession() == null || params.getSession().getUuid() == null) {
			InvalidEditSessionException ex = new InvalidEditSessionException(Status.BAD_REQUEST, Operation.INSERT_EDIT_PARCEL, null,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		String tenantId = params.getSession().getTenant_id();
		String sessionId = params.getSession().getUuid();
		AbsoluteDate referenceDate = params.getSession().getReference_date();

		ParcelNTT p = parcelsDAO.getParcelDetail(tenantId, parcelId, referenceDate, sessionId, DO_NOT_INCLUDE_OUTDATED_PARCELS);
		Long inEditParcelCount = editParcelsDAO.countByIdSessionId(params.getSession().getUuid(), List.of(parcelId));

		if (inEditParcelCount == 0 && p == null) {
			InvalidSessionParcelIdException ex = new InvalidSessionParcelIdException(Status.BAD_REQUEST, Operation.EDIT_SESSION, null,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		editSessionsDAO.updateParcelIdByTenantAndSessionId(tenantId, sessionId, parcelId);
	}

	public EditSessionNTT getSession(String sessionId) {
		return editSessionsDAO.findById(sessionId);
	}

	public void refreshSession(String sessionId) {
		editSessionsDAO.refreshDateById(sessionId);
	}

	public boolean checkAndInsertEditParcel(EditorSupportParams params, ParcelNTT parcelToInsert) {

		if (parcelToInsert == null)
			return false;

		if (params == null || params.getSession() == null || params.getSession().getUuid() == null) {
			InvalidEditSessionException ex = new InvalidEditSessionException(Status.BAD_REQUEST, Operation.INSERT_EDIT_PARCEL, null,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if (params.getReqContext() == null) {
			InvalidUserEditSessionException ex = new InvalidUserEditSessionException(Status.BAD_REQUEST,
					Operation.GET_ANOMALIES, ErrorField.REQUEST_CONTEXT,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(params.getReqContext().getUser())
				.lang(params.getReqContext().getLang())
				.tenantId(params.getReqContext().getTenantId())
				.sessionId(params.getSession().getUuid())
				.srs(params.getSession().getLock_geom_srs())
				.referenceDate(params.getSession().getReference_date())
				.build();

		List<Long> lockedParcels = findOtherSessionsLockedParcelIds(env.getSessionId(), Arrays.asList(parcelToInsert.getParcel_id()));
		if (lockedParcels != null && !lockedParcels.isEmpty()) {
			SessionParcelAlreadyLockedException ex = new SessionParcelAlreadyLockedException(Status.CONFLICT,
					params.getOperation(), ErrorField.SESSION_LOCK_GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		importLockParcelsEdit(env, Arrays.asList(parcelToInsert.getParcel_id()));

		// finnally we can insert the parcel in edit
		editParcelsDAO.insert(env.getSessionId(), parcelToInsert);

		return true;
	}

	public List<Long> findOtherSessionsLockedParcelIds(String sessionId, List<Long> parcelIds) {

		final List<Long> foundLockedParcelIds = new ArrayList<>();
		UnmodifiableIterator<List<Long>> partitions = Iterators.partition(parcelIds.iterator(), 1000);
		partitions.forEachRemaining(partition -> {
			List<Long> partial = editSessionsDAO.findOtherSessionsLockedParcelIds(sessionId, partition);
			if (partial != null)
				foundLockedParcelIds.addAll(partial);
		});

		return foundLockedParcelIds;
	}

	public void importLockParcelsEdit(ServiceSupportEnv env, List<Long> parcelIds) {

		UnmodifiableIterator<List<Long>> partitions = Iterators.partition(parcelIds.iterator(), 1000);
		partitions.forEachRemaining(partition -> lockParcelsDAO.importParcelsEdit(env, partition));

	}

	public boolean enlargeSessionLockGeometry(String tenantId, String myUuid, Geometry enlargedMBR) {

		EditSessionNTT session = getSession(myUuid);
		Geometry oldLockGeom = session.getLock_geom().copy();
		session.setLock_geom(enlargedMBR);

		editSessionsDAO.update(session);

		if (editSessionsDAO.findOtherLockedGeoms(tenantId, enlargedMBR, myUuid, this.internalConf.getLastValidSessionTime(tenantId)) > 0) {
			session.setLock_geom(oldLockGeom);
			editSessionsDAO.update(session);
			return false;
		}

		return true;
	}
	
	public BuildSessionPreviewParcelLandCovers buildSessionPreviewParcelLandCovers(Long parcelId, List<Geometry> sketches, ServiceSupportEnv env,
			CreateEditSessionPayload payload) {
		BuildSessionPreviewParcelLandCovers result = null;
		if (parcelId != null) { // I have to find the lock geometry from the geometry of the parcel
			result = buildSessionPreviewParcelLandCoversFromParcelId(parcelId, env, payload);
		} else if (sketches != null && !sketches.isEmpty()) {
			result = buildSessionPreviewParcelLandCoversFromSketches(sketches, env, payload);
		} else {
			result = buildSessionPreviewParcelLandCoversFromLockGeom(env, payload);
		}
		
		String lcOriginCatalogueCode = internalConf.getStringValue(env.getTenantId(), InternalConfigKeys.LANDCOVER_ORIGIN_CATALOGUE_CODE.getKey());
		if(!StringUtils.isBlank(lcOriginCatalogueCode)) {
			List<LandCoverWithUnits> landCovers = new ArrayList<>();
			result.getIntersectedParcels().forEach(p -> landCovers.addAll(getParcelLandCoversFromCatalogue(env, lcOriginCatalogueCode, p.getParcel_id(), p.getGeom())));
			result.getSessionLandCovers().addAll(landCovers);
		}

		return result;
	}

	private BuildSessionPreviewParcelLandCovers buildSessionPreviewParcelLandCoversFromParcelId(Long parcelId, ServiceSupportEnv env,
			CreateEditSessionPayload payload) {

		String tenant = env.getTenantId();

		List<LandCoverWithUnits> sessionLandCovers = new ArrayList<>();
		List<Parcel> sessionParcels = new ArrayList<>();

		ParcelNTT parcel = parcelsDAO.getParcelDetail(tenant, parcelId, payload.getReference_date(), null, DO_NOT_INCLUDE_OUTDATED_PARCELS);

		checkSessionParcel(env, parcel);

		String lockGeometrySrs = parcel.getSrs();
		env.setSrs(lockGeometrySrs);

		// get all the parcel that are connected to the parcel (the red ones in /docs/readme...)
		List<ParcelNTT> connectedParcels = parcelsDAO.getParcelsWithInteractions(
				tenant,
				payload.getReference_date().toString(),
				parcel.getGeom().buffer(2), // fixed buffer to include some geom scrap
				lockGeometrySrs);

		// ConnectedParcels must contain almost the initail selected parcel, it shouldn't be null
		if (connectedParcels == null || connectedParcels.isEmpty()) {
			SessionParcelDataRetrievingProblemException ex = new SessionParcelDataRetrievingProblemException(Status.BAD_REQUEST,
					Operation.SESSION_PREVIEW, ErrorField.PARCEL,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		// get MBR on the connectedParcels
		List<Geometry> connectedParcelsGeoms = connectedParcels.stream().map(ParcelNTT::getGeom).collect(toList());
		Geometry connectedParcelsMBR = Utils.getUnion(connectedParcelsGeoms)
				.buffer(this.internalConf.getDoubleValue(tenant, InternalConfigKeys.BUFFER_SIZE_KEY.getKey()))
				.getEnvelope();

		// get all the parcel that intersect the connected parcels mbr (the orange ones in /docs/readme...)
		// By default it will be used but can be disabled
		Boolean flCalcThirdSessionLevel = internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_CALC_THIRD_SESSION_LEVEL_KEY.getKey());
		if (Boolean.TRUE.equals(flCalcThirdSessionLevel)) {
			connectedParcels = parcelsDAO.getParcelsWithInteractions(tenant,
					payload.getReference_date().toString(), connectedParcelsMBR, lockGeometrySrs);
			// get all details of the intersected parcels
			connectedParcels = connectedParcels.parallelStream()
					.map(p -> p = parcelsDAO.getParcelDetail(p.getTenant_id(), p.getParcel_id(),
							payload.getReference_date(), null, DO_NOT_INCLUDE_OUTDATED_PARCELS))
					.collect(toList());

			// get MBR outside all intersected parcels
			connectedParcelsGeoms = connectedParcels.stream().map(ParcelNTT::getGeom)
					.collect(toList());
			connectedParcelsMBR = Utils.getUnion(connectedParcelsGeoms)
					.buffer(this.internalConf.getDoubleValue(tenant, InternalConfigKeys.BUFFER_SIZE_KEY.getKey()))
					.getEnvelope();

		}

		// Add session parcels and landcovers
		sessionParcels.add(ParcelsMapper.INSTANCE.entityToDto(parcel));

		List<LandCoverNTT> intersectedLandCovers = new ArrayList<>();

		Boolean flHideLandCovers = internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_HIDE_LANDCOVERS_LAYER.getKey());
		if (Boolean.FALSE.equals(flHideLandCovers)) {
			intersectedLandCovers = landCoversDAO.findByParcelIds(env, Arrays.asList(parcel.getParcel_id()));
		}

		if (intersectedLandCovers != null) {
			sessionLandCovers.addAll(intersectedLandCovers.stream().map(LandCoversMapper.INSTANCE::entityToDtoWithUnits).collect(toList()));

			// add layer style
			sessionLandCovers.forEach(landcover -> {
				LayerStyle style = this.styleService.getLandCoverLayerStyle(tenant, env.getReferenceDate(), landcover.getCode());
				landcover.setLayer_style(style);
			});

			sessionParcels.forEach(p -> {
				Double totalLCArea = sessionLandCovers.stream().filter(lc -> lc.getParcel_id().equals(p.getId()))
						.mapToDouble(LandCoverWithUnits::getArea_sqm).sum();

				p.setTotal_land_covers_area_sqm(totalLCArea == null ? 0 : Math.round(totalLCArea));
			});
		}

		BuildSessionPreviewParcelLandCovers result = new BuildSessionPreviewParcelLandCovers();
		result.setIntersectedParcels(connectedParcels);
		result.setLockGeometry(connectedParcelsMBR);
		result.setLockGeometrySrs(lockGeometrySrs);
		result.setSessionLandCovers(sessionLandCovers);
		result.setSessionParcels(sessionParcels);

		return result;
	}

	private BuildSessionPreviewParcelLandCovers buildSessionPreviewParcelLandCoversFromSketches(List<Geometry> sketches, ServiceSupportEnv env,
			CreateEditSessionPayload payload) {

		String tenant = env.getTenantId();

		String lockGeometrySrs = payload.getLock_geom_srs();
		checkLockGeomSrs(lockGeometrySrs, env);

		sketches.forEach(geometry -> {
			if (geometry == null || !geometry.isValid()) {
				InvalidSessionGeomException ex = new InvalidSessionGeomException(Status.BAD_REQUEST,
						Operation.SESSION_PREVIEW, ErrorField.GEOM,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
		});

		env.setSrs(lockGeometrySrs);

		Geometry sketchesMBR = Utils.getUnion(sketches)
				.buffer(this.internalConf.getDoubleValue(tenant, InternalConfigKeys.BUFFER_SIZE_KEY.getKey()))
				.getEnvelope();

		// get all the parcel that intersect the connected parcels mbr (the orange ones in /docs/readme...)
		List<ParcelNTT> intersectedParcels = parcelsDAO.getParcelsWithInteractions(tenant, payload.getReference_date().toString(), sketchesMBR,
				lockGeometrySrs);
		// get all details of the intersected parcels
		intersectedParcels = intersectedParcels.parallelStream()
				.map(p -> p = parcelsDAO.getParcelDetail(p.getTenant_id(), p.getParcel_id(), payload.getReference_date(), null, DO_NOT_INCLUDE_OUTDATED_PARCELS))
				.collect(toList());

		// get MBR outside all intersected parcels
		Geometry intersectedMBR = sketchesMBR;
		if (!intersectedParcels.isEmpty()) {
			List<Geometry> intersectedParcelsGeoms = intersectedParcels.stream().map(ParcelNTT::getGeom).collect(toList());
			intersectedMBR = Utils.getUnion(intersectedParcelsGeoms)
					.buffer(this.internalConf.getDoubleValue(tenant, InternalConfigKeys.BUFFER_SIZE_KEY.getKey()))
					.getEnvelope();
		}
		// the intersection should be valid
		Geometry lockGeometry = intersectedMBR;

		BuildSessionPreviewParcelLandCovers result = new BuildSessionPreviewParcelLandCovers();
		result.setIntersectedParcels(intersectedParcels);
		result.setLockGeometry(lockGeometry);
		result.setLockGeometrySrs(lockGeometrySrs);
		result.setSessionLandCovers(new ArrayList<>());
		result.setSessionParcels(new ArrayList<>());

		return result;
	}

	private BuildSessionPreviewParcelLandCovers buildSessionPreviewParcelLandCoversFromLockGeom(ServiceSupportEnv env, CreateEditSessionPayload payload) {

		String tenant = env.getTenantId();

		// if no parcelId specified we need a lock geometry
		Geometry lockGeometry = payload.getLock_geom();
		String lockGeometrySrs = payload.getLock_geom_srs();
		env.setSrs(lockGeometrySrs);

		checkIfLockGeomIsDefined(lockGeometry, env);

		checkLockGeomSrs(lockGeometrySrs, env);

		// if requested lock area is out of limits then we adjust it
		Double minArea = this.internalConf.getDoubleValue(tenant, InternalConfigKeys.MINIMUM_VALID_LOCK_AREA_KEY.getKey());
		Double maxArea = this.internalConf.getDoubleValue(tenant, InternalConfigKeys.MAXIMUM_VALID_LOCK_AREA_KEY.getKey());
		if (lockGeometry.getArea() < minArea) {
			lockGeometry = lockGeometry.getCentroid().buffer(Math.sqrt(minArea) / 2).getEnvelope();
		}
		if (lockGeometry.getArea() > maxArea) {
			lockGeometry = lockGeometry.getCentroid().buffer(Math.sqrt(maxArea) / 2).getEnvelope();
		}

		// get the parcels with interaction with the lock geometry (the light red ones in /docs/readme...)
		List<ParcelNTT> intersectedParcels = parcelsDAO.getParcelsWithInteractions(tenant, payload.getReference_date().toString(), lockGeometry,
				lockGeometrySrs);
		// get all details of the intersected parcels
		intersectedParcels = intersectedParcels.parallelStream()
				.map(p -> p = parcelsDAO.getParcelDetail(p.getTenant_id(), p.getParcel_id(), payload.getReference_date(), null, DO_NOT_INCLUDE_OUTDATED_PARCELS))
				.collect(toList());

		BuildSessionPreviewParcelLandCovers result = new BuildSessionPreviewParcelLandCovers();
		result.setIntersectedParcels(intersectedParcels);
		result.setLockGeometry(lockGeometry);
		result.setLockGeometrySrs(lockGeometrySrs);
		result.setSessionLandCovers(new ArrayList<>());
		result.setSessionParcels(new ArrayList<>());

		return result;
	}

	public void checkLockGeomSrs(String lockGeometrySrs, ServiceSupportEnv env) {
		if (StringUtils.isBlank(lockGeometrySrs)) {
			InvalidLockSrsException ex = new InvalidLockSrsException(Status.BAD_REQUEST,
					Operation.SESSION_PREVIEW, ErrorField.SESSION_LOCK_GEOM_SRS,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}

	public void checkIfLockGeomIsDefined(Geometry lockGeometry, ServiceSupportEnv env) {
		if (lockGeometry == null) {
			InvalidLockGeomException ex = new InvalidLockGeomException(Status.BAD_REQUEST,
					Operation.SESSION_PREVIEW, ErrorField.SESSION_LOCK_GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}
	
	public List<LandCoverWithUnits> getParcelLandCoversFromCatalogue(ServiceSupportEnv env, String catalogueCode, Long parcelId, Geometry geom) {
		
		List<LandCoverWithUnits> landCoverList = new ArrayList<>();
		
		CataloguePayload cataloguePayload = CataloguePayload.builder()
				.geom(geom)
				.srs(env.getSrs())
				.params(Map.of("referenceDate", env.getReferenceDate().toString())) //XXX TODO remove
				.build();

		List<CatalogueGeom> catalogueGeoms = cataloguesService.getIntersectedGeomsFromCatalogueList(env, catalogueCode, cataloguePayload);

		catalogueGeoms.forEach(cg -> {
			LandCoverWithUnits lc = LandCoverWithUnits.builder()
//					.id(Long.parseLong(cg.getId()))
					.id(generateRandom12DigitId()) // XXX ALTERNATIVE WAY TO AVOID double ids
					.parcel_id(parcelId)
					.code(cg.getLabel())
					.description((String)cg.getFields().getOrDefault("description", null))
					.day_from(AbsoluteDate.of((String)cg.getFields().getOrDefault("day_from", null)))
					.day_to(AbsoluteDate.of((String)cg.getFields().getOrDefault("day_to", null)))
					.edit_status(EditStatus.NOT_IN_EDIT)
					.area_sqm(cg.getAreaSqm() != null ? Math.round(cg.getAreaSqm()) : null)
					.srs(cg.getSrs())
					.geom(cg.getGeom())
					.build();
			
			lc.setLayer_style(this.styleService.getLandCoverLayerStyle(env.getTenantId(), env.getReferenceDate(), lc.getCode()));

			landCoverList.add(lc); 
		});
		
		return landCoverList;
	}
	
	private LandCoverUnitNTT getOrSaveUnit(Long landCoverId, Long unitId, UnitType ut) {
		Long finalUnitId = unitId < 0 ? unitsDAO.nextUnitIdVal() : unitId;

		LandCoverUnitNTT unit = LandCoverUnitNTT.builder()
				.unit_id(finalUnitId)
				.land_cover_id(landCoverId)
				.type_code(ut)
				.build();
		
		if(unitId < 0) {
			unitsDAO.insertLandCoverUnit(unit);
		}
		
		return unit;
	}
	
	public void insertVineUnits(ServiceSupportEnv env, Long stackId, LandCoverNTT lc, boolean isParent) {
		env.setLandCoverId(lc.getLand_cover_id());
		Long landCoverIdToSearch = lc.getIn_edit_former_land_cover_id() != null ? lc.getIn_edit_former_land_cover_id() : lc.getLand_cover_id();
		List<VineUnitDetailsNTT> vineUnits = getAllVineUnitsByLandCoverId(env, landCoverIdToSearch, lc.getFormer_land_cover_details_id(), isParent);

		for(VineUnitDetailsNTT vineUnit: vineUnits) {

			// save current unit_id for inEdit query
			Long sessionUnitId = vineUnit.getUnitId();

			// load or create unit
			LandCoverUnitNTT unit = getOrSaveUnit(lc.getLand_cover_id(), vineUnit.getUnitId(), vineUnit.getTypeCode());

			VineUnitNTT oldVineUnit = vineUnitsDAO.getVineUnitsbyUnitId(env, unit.getUnit_id());

			vineUnitsDAO.outdateAllFutureVersionsByUnitCode(env, vineUnit.getUnitCode(), vineUnit.getEradicateDay());

			//insert new vine unit data
			vineUnit.setUnitId(unit.getUnit_id());
			vineUnit.setTypeCode(unit.getType_code());
			if(vineUnit.getParentUnitCode() != null) {
				vineUnit.setParentUnitCode(unitsDAO.getUnitCodeIfExists(vineUnit.getParentUnitCode(), getUnitDetailTableName(vineUnit.getTypeCode()), getEditUnitTableName(vineUnit.getTypeCode())));
			}

			if(isParent) {
				insertOlderVineUnitVersion(env, stackId, lc.getLand_cover_details_id(), vineUnit, oldVineUnit);
			} else {
				if(oldVineUnit != null) {
					vineUnitsDAO.outdateVineUnitByUnitDetailId(env, oldVineUnit.getUnitDetailId());
				}
				AbsoluteDate dayTo = oldVineUnit != null ? oldVineUnit.getDayTo() : END_OF_WORLD;
				
				// insert new version
				vineUnit.setUnitDetailId(vineUnitsDAO.nextVineUnitDetailPkidVal());
				vineUnit.setDayFrom(env.getReferenceDate());
				vineUnit.setDayTo(dayTo);
				vineUnitsDAO.insertVineUnitDetail(env, vineUnit);

				saveStackLandCoverVineUnit(stackId, lc.getLand_cover_details_id(), vineUnit.getUnitDetailId());
				insertVineAptitudes(env, stackId, sessionUnitId, unit.getUnit_id(), vineUnit);
			}
		}
	}
	
	private void insertOlderVineUnitVersion(ServiceSupportEnv env, Long stackId, Long landCoverDetailsId,
			VineUnitDetailsNTT vineUnit, VineUnitNTT oldVineUnit) {
		if(vineUnit.getEditId() == null) { 	// unit not in edit
			//insert older version
			vineUnit.setDayTo(AbsoluteDate.of(env.getReferenceDate().toLocalDate().minusDays(1)));
			if(vineUnit.getDayFrom().toLocalDate().isBefore(vineUnit.getDayTo().toLocalDate())) {
				vineUnit.setUnitDetailId(vineUnitsDAO.nextVineUnitDetailPkidVal());
				vineUnitsDAO.insertVineUnitDetail(env, vineUnit);
				saveStackLandCoverVineUnit(stackId, landCoverDetailsId, vineUnit.getUnitDetailId());
			}
		} else if(oldVineUnit != null) {
			// insert older version
			VineUnitDetailsNTT oldVineUnitDetail = VineUnitMapper.INSTANCE.entityToEntityDetail(oldVineUnit);
			oldVineUnitDetail.setDayTo(AbsoluteDate.of(env.getReferenceDate().toLocalDate().minusDays(1)));
			if(oldVineUnit.getDayFrom().toLocalDate().isBefore(oldVineUnitDetail.getDayTo().toLocalDate())) {
				oldVineUnitDetail.setUnitDetailId(vineUnitsDAO.nextVineUnitDetailPkidVal());
				vineUnitsDAO.insertVineUnitDetail(env, oldVineUnitDetail);
				saveStackLandCoverVineUnit(stackId, landCoverDetailsId, oldVineUnitDetail.getUnitDetailId());
			}
		} 
	}

	private void insertVineAptitudes(ServiceSupportEnv env, Long stackId, Long sessionUnitId, Long unitId, VineUnitDetailsNTT vineUnit) {
		// load vine aptitude data					
		List<VineAptitudeNTT> vineAptitudes = editVineUnitsDAO.findInEditVineAptitudesBySessionId(env, sessionUnitId, null, 1, null);
		vineAptitudes.addAll(editVineUnitsDAO.findNotInEditVineAptitudesBySessionId(env, unitId, null, 1));
		// outdate current vine aptitude 
		vineUnitsDAO.outdateVineAptitudes(env, unitId, null);
		// insert new aptitude data
		for(VineAptitudeNTT va: vineAptitudes) {
			Long vineAptitudePkid = vineUnitsDAO.nextVineUnitAptitudePkidVal();

			va.setPkid(vineAptitudePkid);
			va.setUnitId(unitId);
			va.setAptitudeId(va.getAptitudeId() < 0 ? vineAptitudePkid : va.getAptitudeId());

			vineUnitsDAO.insertVineAptitude(env, va);

			saveStackVineAptitude(stackId, vineUnit.getUnitDetailId(), va.getPkid());
		}
	}
	
	private List<VineUnitDetailsNTT> getAllVineUnitsByLandCoverId(ServiceSupportEnv env, Long landCoverId, Long landCoverPkid, Boolean isParent) {
		List<VineUnitDetailsNTT> vineUnits = editVineUnitsDAO.findInEditVineUnitsBySessionId(env, landCoverId, null, null, 1);
		
		if (Boolean.TRUE.equals(isParent)) {
			vineUnits.addAll(editVineUnitsDAO.findNotInEditVineUnitsBySessionId(env, null, landCoverPkid, null));
		} else {
			vineUnits.addAll(editVineUnitsDAO.findNotInEditVineUnitsBySessionId(env, landCoverId, null, null));
		}
		
		return vineUnits;
	}
		
	public void insertOliveUnits(ServiceSupportEnv env, Long stackId, LandCoverNTT lc, boolean isParent) {
		env.setLandCoverId(lc.getLand_cover_id());
		Long landCoverIdToSearch = lc.getIn_edit_former_land_cover_id() != null ? lc.getIn_edit_former_land_cover_id() : lc.getLand_cover_id();
		List<OliveUnitDetailsNTT> oliveUnits = getAllOliveUnitsByLandCoverId(env, landCoverIdToSearch, lc.getFormer_land_cover_details_id(), isParent);
		
		for(OliveUnitDetailsNTT oliveUnit: oliveUnits) {
			// load or create unit
			LandCoverUnitNTT unit = getOrSaveUnit(lc.getLand_cover_id(), oliveUnit.getUnitId(), oliveUnit.getTypeCode());
			
			OliveUnitNTT oldOliveUnit = oliveUnitsDAO.getOliveUnitsbyUnitId(env, unit.getUnit_id());

			oliveUnitsDAO.outdateAllFutureVersionsByUnitCode(env, oliveUnit.getUnitCode(), oliveUnit.getEradicateDay());

			oliveUnit.setUnitId(unit.getUnit_id());
			oliveUnit.setTypeCode(unit.getType_code());
			if(oliveUnit.getParentUnitCode() != null) {
				oliveUnit.setParentUnitCode(unitsDAO.getUnitCodeIfExists(oliveUnit.getParentUnitCode(), getUnitDetailTableName(oliveUnit.getTypeCode()), getEditUnitTableName(oliveUnit.getTypeCode())));
			}

			if(isParent) {
				insertOlderOliveUnitVersion(env, stackId, lc.getLand_cover_details_id(), oliveUnit, oldOliveUnit);
			} else {
				// insert new version
				if(oldOliveUnit != null) {
					oliveUnitsDAO.outdateOliveUnitByUnitDetailId(env, oldOliveUnit.getUnitDetailId());
				}
				AbsoluteDate dayTo = oldOliveUnit != null ? oldOliveUnit.getDayTo() : END_OF_WORLD;
				oliveUnit.setUnitDetailId(oliveUnitsDAO.nextOliveUnitDetailPkidVal());
				oliveUnit.setDayFrom(env.getReferenceDate());
				oliveUnit.setDayTo(dayTo);
				oliveUnitsDAO.insertOliveUnitDetail(env, oliveUnit);
				saveStackLandCoverOliveUnit(stackId, lc.getLand_cover_details_id(), oliveUnit.getUnitDetailId());
			}
		}

	}
	
	private void insertOlderOliveUnitVersion(ServiceSupportEnv env, Long stackId, Long landCoverDetailsId,
			OliveUnitDetailsNTT oliveUnit, OliveUnitNTT oldOliveUnit) {
		if(oliveUnit.getEditId() == null) { 	// unit not in edit
			//insert older version
			oliveUnit.setDayTo(AbsoluteDate.of(env.getReferenceDate().toLocalDate().minusDays(1)));
			if(oliveUnit.getDayFrom().toLocalDate().isBefore(oliveUnit.getDayTo().toLocalDate())) {
				oliveUnit.setUnitDetailId(oliveUnitsDAO.nextOliveUnitDetailPkidVal());
				oliveUnitsDAO.insertOliveUnitDetail(env, oliveUnit);
				saveStackLandCoverOliveUnit(stackId, landCoverDetailsId, oliveUnit.getUnitDetailId());
			}
		} else if(oldOliveUnit != null) {
			// insert older version
			OliveUnitDetailsNTT oldOliveUnitDetail = OliveUnitMapper.INSTANCE.entityToEntityDetail(oldOliveUnit);
			oldOliveUnitDetail.setDayTo(AbsoluteDate.of(env.getReferenceDate().toLocalDate().minusDays(1)));
			if(oldOliveUnit.getDayFrom().toLocalDate().isBefore(oldOliveUnitDetail.getDayTo().toLocalDate())) {
				oldOliveUnitDetail.setUnitDetailId(oliveUnitsDAO.nextOliveUnitDetailPkidVal());
				oliveUnitsDAO.insertOliveUnitDetail(env, oldOliveUnitDetail);
				saveStackLandCoverOliveUnit(stackId, landCoverDetailsId, oldOliveUnitDetail.getUnitDetailId());
			}
		} 
	}

	private List<OliveUnitDetailsNTT> getAllOliveUnitsByLandCoverId(ServiceSupportEnv env, Long landCoverId, Long landCoverPkid, Boolean isParent) {
		List<OliveUnitDetailsNTT> oliveUnits = editOliveUnitsDAO.findInEditOliveUnitsBySessionId(env, landCoverId, null, null, 1);
		
		if(Boolean.TRUE.equals(isParent)) {
			oliveUnits.addAll(editOliveUnitsDAO.findNotInEditOliveUnitsBySessionId(env, null, landCoverPkid, null));
		} else {
            oliveUnits.addAll(editOliveUnitsDAO.findNotInEditOliveUnitsBySessionId(env, landCoverId, null, null));
		}
		return oliveUnits;
	}
	
	public void insertFruitUnits(ServiceSupportEnv env, Long stackId, LandCoverNTT lc, boolean isParent) {
		env.setLandCoverId(lc.getLand_cover_id());
		Long landCoverIdToSearch = lc.getIn_edit_former_land_cover_id() != null ? lc.getIn_edit_former_land_cover_id() : lc.getLand_cover_id();
		List<FruitUnitDetailsNTT> fruitUnits = getAllFruitUnitsByLandCoverId(env, landCoverIdToSearch, lc.getFormer_land_cover_details_id(), isParent);

		for(FruitUnitDetailsNTT fruitUnit: fruitUnits) {
			// load or create unit
			LandCoverUnitNTT unit = getOrSaveUnit(lc.getLand_cover_id(), fruitUnit.getUnitId(), fruitUnit.getTypeCode());

			FruitUnitNTT oldFruitUnit = fruitUnitsDAO.getFruitUnitsbyUnitId(env, unit.getUnit_id());

			fruitUnitsDAO.outdateAllFutureVersionsByUnitCode(env, fruitUnit.getUnitCode(), fruitUnit.getEradicateDay());

			fruitUnit.setUnitId(unit.getUnit_id());
			fruitUnit.setTypeCode(unit.getType_code());
			if(fruitUnit.getParentUnitCode() != null) {
				fruitUnit.setParentUnitCode(unitsDAO.getUnitCodeIfExists(fruitUnit.getParentUnitCode(), getUnitDetailTableName(fruitUnit.getTypeCode()), getEditUnitTableName(fruitUnit.getTypeCode())));
			}

			if(isParent) {
				insertOlderFruitUnitVersion(env, stackId, lc.getLand_cover_details_id(), fruitUnit, oldFruitUnit);
			} else {
				// insert new version
				if(oldFruitUnit != null) {
					fruitUnitsDAO.outdateFruitUnitByUnitDetailId(env, oldFruitUnit.getUnitDetailId());
				}
				AbsoluteDate dayTo = oldFruitUnit != null ? oldFruitUnit.getDayTo() : END_OF_WORLD;

				fruitUnit.setUnitDetailId(fruitUnitsDAO.nextFruitUnitDetailPkidVal());
				fruitUnit.setDayFrom(env.getReferenceDate());
				fruitUnit.setDayTo(dayTo);
				fruitUnitsDAO.insertFruitUnitDetail(env, fruitUnit);

				saveStackLandCoverFruitUnit(stackId, lc.getLand_cover_details_id(), fruitUnit.getUnitDetailId());
			}
		}
	}
	
	private void insertOlderFruitUnitVersion(ServiceSupportEnv env, Long stackId, Long landCoverDetailsId,
			FruitUnitDetailsNTT fruitUnit, FruitUnitNTT oldFruitUnit) {

		if(fruitUnit.getEditId() == null) { 	// unit not in edit
			//insert older version
			fruitUnit.setDayTo(AbsoluteDate.of(env.getReferenceDate().toLocalDate().minusDays(1)));
			if(fruitUnit.getDayFrom().toLocalDate().isBefore(fruitUnit.getDayTo().toLocalDate())) {
				fruitUnit.setUnitDetailId(fruitUnitsDAO.nextFruitUnitDetailPkidVal());
				fruitUnitsDAO.insertFruitUnitDetail(env, fruitUnit);
				saveStackLandCoverFruitUnit(stackId, landCoverDetailsId, fruitUnit.getUnitDetailId());
			}
		} else if(oldFruitUnit != null) {
			// insert older version
			FruitUnitDetailsNTT oldFruitUnitDetail = FruitUnitMapper.INSTANCE.entityToEntityDetail(oldFruitUnit);
			oldFruitUnitDetail.setDayTo(AbsoluteDate.of(env.getReferenceDate().toLocalDate().minusDays(1)));
			if(oldFruitUnit.getDayFrom().toLocalDate().isBefore(oldFruitUnitDetail.getDayTo().toLocalDate())) {
				oldFruitUnitDetail.setUnitDetailId(fruitUnitsDAO.nextFruitUnitDetailPkidVal());
				fruitUnitsDAO.insertFruitUnitDetail(env, oldFruitUnitDetail);
				saveStackLandCoverFruitUnit(stackId, landCoverDetailsId, oldFruitUnitDetail.getUnitDetailId());
			}
		} 
	
	}
	
	private List<FruitUnitDetailsNTT> getAllFruitUnitsByLandCoverId(ServiceSupportEnv env, Long landCoverId, Long landCoverPkid, Boolean isParent) {
		List<FruitUnitDetailsNTT> fruitUnits = editFruitUnitsDAO.findInEditFruitUnitsBySessionId(env, landCoverId, null, null, 1);
		
		if (Boolean.TRUE.equals(isParent)) {
			fruitUnits.addAll(editFruitUnitsDAO.findNotInEditFruitUnitsBySessionId(env, null, landCoverPkid, null));
		} else {
			fruitUnits.addAll(editFruitUnitsDAO.findNotInEditFruitUnitsBySessionId(env, landCoverId, null, null));
		}
		return fruitUnits;
	}
	
	private void saveStackVineAptitude(Long stackId, Long vineUnitPkid, Long vineAptitudePkid) {
		
		StackVineAptitudeNTT vAptitude = StackVineAptitudeNTT.builder()
				.pkid(stackVineUnitsDAO.nextSequenceVineAptitudeStackVal())
				.stackId(stackId)
				.vineUnitPkid(vineUnitPkid)
				.vineAptitudePkid(vineAptitudePkid)
				.build();
		
		stackVineUnitsDAO.insertVineAptitudeStack(vAptitude);
		
	}

	
	private void saveStackLandCoverOliveUnit(Long stackId, Long landCoverDetailsPkid, Long oliveUnitPkid) {
		
		StackOliveUnitsNTT sOliveUnit = StackOliveUnitsNTT.builder()
				.pkid(stackOliveUnitsDAO.nextSequenceOliveUnitsStackVal())
				.stackId(stackId)
				.landCoverPkid(landCoverDetailsPkid)
				.oliveUnitPkid(oliveUnitPkid)
				.build();
		
		stackOliveUnitsDAO.insertOliveUnitStack(sOliveUnit);
		
	}
	
	private void saveStackLandCoverFruitUnit(Long stackId, Long landCoverDetailsPkid, Long fruitUnitPkid) {
		
		StackFruitUnitsNTT sFruitUnit = StackFruitUnitsNTT.builder()
				.pkid(stackFruitUnitsDAO.nextSequenceFruitUnitsStackVal())
				.stackId(stackId)
				.landCoverPkid(landCoverDetailsPkid)
				.fruitUnitPkid(fruitUnitPkid)
				.build();
		
		stackFruitUnitsDAO.insertFruitUnitStack(sFruitUnit);
		
	}
	
	private void saveStackLandCoverVineUnit(Long stackId, Long landCoverDetailsPkid, Long vineUnitPkid) {

		StackVineUnitsNTT sVineUnit = StackVineUnitsNTT.builder()
				.pkid(stackVineUnitsDAO.nextSequenceVineUnitsStackVal())
				.stackId(stackId)
				.landCoverPkid(landCoverDetailsPkid)
				.vineUnitPkid(vineUnitPkid)
				.build();

		stackVineUnitsDAO.insertVineUnitStack(sVineUnit);

	}
	
}
