package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.VarietySummaryNTT;
import com.abacogroup.lpisgisserver.resources.res.pub.units.VarietySummaryV1;

@Mapper(uses = { VarietyV1Mapper.class } )
public interface VarietySummaryV1Mapper {

	VarietySummaryV1Mapper INSTANCE = Mappers.getMapper(VarietySummaryV1Mapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "anomaliesList", ignore = true)
	VarietySummaryV1 toResponseV1(VarietySummaryNTT entity);
	
}
