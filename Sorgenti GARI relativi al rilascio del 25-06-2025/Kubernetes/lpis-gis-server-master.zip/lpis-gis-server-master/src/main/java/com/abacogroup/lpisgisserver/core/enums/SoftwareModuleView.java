package com.abacogroup.lpisgisserver.core.enums;

public enum SoftwareModuleView {
	PARCELS,
	LANDCOVERS, 
	UNITS
}
