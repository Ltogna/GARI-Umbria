package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.lpisgisserver.db.ntt.I18nNTT;

public interface I18nDAO extends Transactional<I18nDAO> {

	@SqlQuery("select * from lpis_i18n_values "
			+ " where tenant_id = :tenant_id "
			+ " and table_name = :table_name "
			+ " and field_name = :field_name "
			+ " and i18n_value = :i18n_value "
			+ " and lang = :lang")
	@RegisterBeanMapper(I18nNTT.class)
	I18nNTT findI18nByLpisI18nKeys(@BindBean I18nNTT entity);

	@SqlQuery("select * from lpis_i18n_values "
			+ " where tenant_id = :tenant_id "
			+ " and table_name = :table_name "
			+ " and field_name = :field_name "
			+ " and i18n_value = :i18n_value ")
	@RegisterBeanMapper(I18nNTT.class)
	List<I18nNTT> findAllI18nByLpisI18nKeys(@BindBean I18nNTT entity);
	
	@SqlQuery("select * from lpis_i18n_values "
			+ " where tenant_id = :tenant_id ")
	@RegisterBeanMapper(I18nNTT.class)
	List<I18nNTT> findAllI18nByTenantId(@Bind("tenant_id") String tenantId);

	@SqlQuery("select * from lpis_i18n_values "
			+ " where tenant_id = :tenantId "
			+ " and table_name = :tableName "
			+ " and field_name = :fieldName")
	@RegisterBeanMapper(I18nNTT.class)
	List<I18nNTT> findAllI18nByTenantTableAndField(@Bind("tenantId") String tenantId, @Bind("tableName") String tableName, @Bind("fieldName") String fieldName);

	@SqlQuery("select * from lpis_i18n_values "
			+ " where tenant_id = :tenantId "
			+ " and table_name = :tableName "
			+ " and field_name = :fieldName"
			+ " and lang = :lang")
	@RegisterBeanMapper(I18nNTT.class)
	List<I18nNTT> findAllI18nByTenantTableFieldAandLang(@Bind("tenantId") String tenantId, 
			@Bind("tableName") String tableName, @Bind("fieldName") String fieldName, @Bind("lang") String lang);

	
	@SqlQuery("select i18n_text from §i18n(:tenant_id, :table_name, :field_name, :i18n_value, :lang)§ t")
	String findI18nText(@BindBean I18nNTT entity);

	@SqlUpdate("insert into lpis_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text) "
			+ " values (:tenant_id, :table_name, :field_name, :i18n_value, :lang, :i18n_text) ")
	void insert(@BindBean I18nNTT entity);

	@SqlUpdate("update lpis_i18n_values set "
			+ " i18n_text = :i18n_text "
			+ " where tenant_id = :tenant_id "
			+ " and table_name = :table_name "
			+ " and field_name = :field_name "
			+ " and i18n_value = :i18n_value "
			+ " and lang = :lang")
	void updateI18nText(@BindBean I18nNTT entity);

	@SqlUpdate("delete from lpis_i18n_values where tenant_id = :tenant_id and table_name = :table_name and field_name = :field_name and i18n_value = :i18n_value and lang =:lang")
	void deleteI18nLang(@BindBean I18nNTT entity);

	@SqlUpdate("delete from lpis_i18n_values where tenant_id = :tenant_id and table_name = :table_name and field_name = :field_name and i18n_value = :i18n_value")
	void deleteAllI18n(@BindBean I18nNTT entity);
	
	@SqlQuery("select distinct tenant_id from lpis_i18n_values")
	List<String> getAllTenants();
}
