package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidSessionLandCoverCodeException extends AbstractException {

	private static final long serialVersionUID = -751501588314162484L;

	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_SESSION_LAND_COVER_CODE;

	public InvalidSessionLandCoverCodeException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new InvalidSessionLandCoverCodeExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Land cover code is not valid")
	public static class InvalidSessionLandCoverCodeExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 1L;

		public InvalidSessionLandCoverCodeExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
