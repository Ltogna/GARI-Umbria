package com.abacogroup.lpisgisserver.core;

import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.LineString;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.geom.Polygonal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.geometryeditor.Editor;
import com.abacogroup.geometryeditor.EditorResult;
import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.CutBehaviour;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.OverlayType;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.InvalidPayloadException;
import com.abacogroup.lpisgisserver.core.exceptions.catalogue.CatalogueIdNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.ParcelIdsNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.ParcelIdsNotValidException;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.ParcelNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.TooMuchParcelsToMergeException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionParcelIdException;
import com.abacogroup.lpisgisserver.core.exceptions.session.ParcelBlockNotValidException;
import com.abacogroup.lpisgisserver.core.exceptions.session.ParcelDataAlreadyExistException;
import com.abacogroup.lpisgisserver.core.exceptions.session.UpdateBufferTooLargeException;
import com.abacogroup.lpisgisserver.core.exceptions.session.UpdateBufferTooSmallException;
import com.abacogroup.lpisgisserver.core.mappers.BlockMapper;
import com.abacogroup.lpisgisserver.core.mappers.ExternalSourceMapper;
import com.abacogroup.lpisgisserver.core.mappers.LandCoversMapper;
import com.abacogroup.lpisgisserver.core.mappers.ParcelsMapper;
import com.abacogroup.lpisgisserver.core.mappers.SectorMapper;
import com.abacogroup.lpisgisserver.core.models.EditParcelData;
import com.abacogroup.lpisgisserver.core.support.EditorSupportFactory;
import com.abacogroup.lpisgisserver.core.support.EditorSupportParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.BlockDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.ExternalSourceDataDAO;
import com.abacogroup.lpisgisserver.db.dao.ParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.SectorDAO;
import com.abacogroup.lpisgisserver.db.ntt.BlockNTT;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.db.ntt.SectorNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.CataloguePayload;
import com.abacogroup.lpisgisserver.resources.req.CreateLandCoversPayload;
import com.abacogroup.lpisgisserver.resources.req.CreateParcelsPayload;
import com.abacogroup.lpisgisserver.resources.req.CutParcelsByLinePayload;
import com.abacogroup.lpisgisserver.resources.req.CutParcelsPayload;
import com.abacogroup.lpisgisserver.resources.req.FillParcelsPayload;
import com.abacogroup.lpisgisserver.resources.req.GeometryIntersectionPayload;
import com.abacogroup.lpisgisserver.resources.req.MergeParcelsPayload;
import com.abacogroup.lpisgisserver.resources.req.UpdateParcelsDataPayload;
import com.abacogroup.lpisgisserver.resources.req.UpdateParcelsPayload;
import com.abacogroup.lpisgisserver.resources.res.Catalogue;
import com.abacogroup.lpisgisserver.resources.res.CatalogueGeom;
import com.abacogroup.lpisgisserver.resources.res.EditResult;
import com.abacogroup.lpisgisserver.resources.res.ExternalSource;
import com.abacogroup.lpisgisserver.resources.res.GeometryIntersection;
import com.abacogroup.lpisgisserver.resources.res.LandCoverWithUnits;
import com.abacogroup.lpisgisserver.resources.res.LandCoversEditResult;
import com.abacogroup.lpisgisserver.resources.res.Parcel;
import com.abacogroup.lpisgisserver.resources.res.ParcelsEditResult;
import com.abacogroup.lpisgisserver.resources.res.ParcelsLandCoversList;
import com.abacogroup.lpisgisserver.resources.res.units.fruit.FruitUnit;
import com.abacogroup.lpisgisserver.resources.res.units.olive.OliveUnit;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnitWithAptitudes;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response.Status;

public class EditParcelsService extends BaseService {

	private final EditSessionSupportService editSessionSupportService;
	private final EditParcelsSupportService editParcelsSupportService;
	private final EditLandCoversService editLandCoversService;
	private final EditLandCoversSupportService editLandCoversSupportService;
	private final CataloguesService cataloguesService;

	private final EditParcelsDAO editParcelsDAO;
	private final ParcelsDAO parcelsDAO;
	private final BlockDAO blockDAO;
	private final SectorDAO sectorDAO;
	private final ExternalSourceDataDAO externalSourceDataDAO;

	private EditorSupportFactory<Long> editorSupportFactory;

	private static final Logger log = LoggerFactory.getLogger(EditParcelsService.class);
	
	private static final int DO_NOT_INCLUDE_OUTDATED_PARCELS = 0;
	
	private static final Boolean SHOW_ALL_CATALOGUES = null;

	public EditParcelsService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, EditSessionSupportService editSessionSupportService,
			EditLandCoversService editLandCoversService, EditParcelsSupportService editParcelsSupportService,
			EditLandCoversSupportService editLandCoversSupportService, CataloguesService cataloguesService,
			PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.editSessionSupportService = editSessionSupportService;
		this.editLandCoversService = editLandCoversService;
		this.editParcelsSupportService = editParcelsSupportService;
		this.editLandCoversSupportService = editLandCoversSupportService;
		this.cataloguesService = cataloguesService;

		this.editParcelsDAO = dc.getEditParcelsDAO();
		this.parcelsDAO = dc.getParcelsDAO();
		this.blockDAO = dc.getBlockDAO();
		this.sectorDAO = dc.getSectorDAO();
		this.externalSourceDataDAO = dc.getExternalSourceDataDAO();

		try {
			this.editorSupportFactory = (EditorSupportParams params, CutBehaviour cutBehaviour, EditorResult<Long> parcelEditorResult,
					Map<Long, Polygon> cutPolygons, boolean isForPreview,
					long lastPreviewKey) -> new EditorParcelsSupportImpl(params, cutBehaviour, cutPolygons, isForPreview, lastPreviewKey, dc);

		} catch (AbstractException e) {
			AbstractExceptionBody body = e.getBody();

			body.setOperation(Operation.INIT_EDIT_PARCEL_SERVICE);
			body.setMessage(body.getErrorCode(), ErrorDescriptionsService.DEFAULT_LANG_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY));

			log.error(body.getLogErrorMessage());

			e.setBody(body);

			throw e;
		}
	}

	// ----------------------------------------------------------------------------------------------------------------------

	public ParcelsLandCoversList getEditParcelsLandCovers(EditorSupportParams params) {

		editParcelsSupportService.checkCanEdit(false, params, null, null);

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		// the parcels geometries are all required
		List<ParcelNTT> editParcels = internalGetEditParcels(params);
		
		
//		List<LandCoverWithUnits> editLandCovers = editLandCoversSupportService.internalGetEditLandCovers(params)
//				.stream()
//				.map(LandCoversMapper.INSTANCE::entityToDtoWithUnits)
//				.collect(toList());
		
		
		// on the other hand for the landcovers we need the details (units) only for the ones of in edit parcels
		final List<LandCoverWithUnits> editLandCovers = new ArrayList<>();
		editParcels.stream()
				.filter(p -> p.getGeom() != null)
				.filter(p -> p.getParcel_id() == null
						|| Objects.equals(params.getSession().getParcel_id(), p.getParcel_id())
						|| Objects.equals(params.getParcelId(), p.getParcel_id())
						|| !EditStatus.NOT_IN_EDIT.equals(p.getEdit_status()))
				.forEach(p -> {
					EditorSupportParams pm = params;
					pm.setParcelId(p.getParcel_id()); // p.getGeom()
					
					List<LandCoverWithUnits> landcovers;
					
					String lcOriginCatalogueCode = internalConf.getStringValue(params.getReqContext().getTenantId(), InternalConfigKeys.LANDCOVER_ORIGIN_CATALOGUE_CODE.getKey());
					if(!StringUtils.isBlank(lcOriginCatalogueCode)) {
						landcovers = editSessionSupportService.getParcelLandCoversFromCatalogue(checkAndBuildServiceSupportEnv(params), lcOriginCatalogueCode, p.getParcel_id(), p.getGeom());
					} else {
						landcovers = editLandCoversSupportService.internalGetEditLandCovers(pm)
								.stream()
								.map(ll -> {
									LandCoverWithUnits lc = LandCoversMapper.INSTANCE.entityToDtoWithUnits(ll);
									editLandCoversSupportService.addUnitsToLandCover(params, lc);
									lc.setTotal_unit_area_sqm(
											lc.getVine_units().stream().mapToInt(VineUnitWithAptitudes::getAreaSqm).sum() +
											lc.getOlive_units().stream().mapToInt(OliveUnit::getAreaSqm).sum() +
											lc.getFruit_units().stream().mapToInt(FruitUnit::getAreaSqm).sum()
											);
									return lc;
								})
								.collect(toList());
					}

					editLandCovers
							.addAll(landcovers);
				});
	
		
		List<Parcel> parcelsList = editParcels.stream().map(ParcelsMapper.INSTANCE::entityToDto).collect(toList());
		parcelsList.forEach(parcel -> {
			Double totalLandCoversArea = editLandCovers.stream().filter(landcover -> landcover.getParcel_id().equals(parcel.getId()))
					.mapToDouble(LandCoverWithUnits::getArea_sqm).sum();
			parcel.setTotal_land_covers_area_sqm(totalLandCoversArea == null ? 0 : Math.round(totalLandCoversArea));

			if(EditStatus.DELETED.equals(parcel.getEdit_status())
					&& Boolean.TRUE.equals(internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_SEARCH_EXTERNAL_PARCELS.getKey()))	) {

				List<ExternalSource> sdeFoundCodes = externalSourceDataDAO.findExternalSourceCodeBySectorBlockParcelAndTenant(env, parcel.getSector().getSector_code(), parcel.getBlock().getBlock_code(), parcel.getParcel()).stream()
						.map(ExternalSourceMapper.INSTANCE::entityToDto)
						.collect(Collectors.toList());
				parcel.setSde_found_codes(sdeFoundCodes);
			}
		});

		return ParcelsLandCoversList
				.builder()
				.parcels_list(parcelsList)
				.land_covers_list(editLandCovers)
				.build();
	}

	private List<ParcelNTT> internalGetEditParcels(EditorSupportParams params) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		List<ParcelNTT> editParcels = new ArrayList<>();

		List<ParcelNTT> inEditParcels = editParcelsDAO.findInEditBySessionId(env.getSessionId(), env.getReferenceDate(), null)
				.stream()
				.filter(p -> (p.getGeom() != null || p.getParcel() != null))  // Ref: #112562 vengono ritornate anche le parcelle cancellate (con geom = null) ma non quelle nuove senza nome (con parcel = null)
				.collect(toList());

		// Add all the edit parcels to the edit parcels list.
		if (inEditParcels != null)
			editParcels.addAll(inEditParcels);

		List<ParcelNTT> notInEditParcels = editParcelsDAO.findNotInEditBySessionId(env, null);
		// Add all the notInEditParcels to the editParcels list.
		if (notInEditParcels != null)
			editParcels.addAll(notInEditParcels);

		return editParcels;

	}

	// ----------------------------------------------------------------------------------------------------------------------

	public EditResult createParcel(EditorSupportParams params, @NotNull @Valid CreateParcelsPayload payload, Boolean isForPreview) {

		// Update the parcel with the payload.
		if(payload.getParcel_id() != null) {
			Map<Long, Geometry> parcelMap = new HashMap<>();
			parcelMap.put(payload.getParcel_id(), payload.getGeom());
			UpdateParcelsPayload updatePayload = new UpdateParcelsPayload(parcelMap, payload.getCut_behaviour(), null);
			params.setParcelId(payload.getParcel_id());
			return updateParcel(params, updatePayload, isForPreview, true);
		}

		editParcelsSupportService.checkCanEdit(isForPreview, params, null, payload.getGeom());

		Editor<Long> editor = getEditor(params, payload.getCut_behaviour(), null, isForPreview);

		EditorResult<Long> result = new EditorResult<>();
		try {
			result = editor.insertPolygon((Polygonal) payload.getGeom());
		} catch (AbstractException e) {
			throwExceptionFromEditorOperation(e, params);
		}

		//if session parcelID is null and parcelName is not blank
		// Set the parcel id if the payload is not empty.
		if(!StringUtils.isBlank(payload.getParcel_name())
				&& !result.getCreated().isEmpty()) {
			setUpdatedNamedParcelId(params, payload, result, isForPreview);
		}

		// in preview update landcover is not needed
		LandCoversEditResult lcEditorResult = new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());

		// If isForPreview is true then the landcover is saved and the landcover is updated.
		if (Boolean.FALSE.equals(isForPreview)) {
			persistEditorResult(params, params.getSession().getReference_date(), result);

			// update landcover
			lcEditorResult = editLandCoversService.createParcelsLandCovers(params, payload, result, isForPreview);
		}

		return getEditParcelPreviewResult(params, result, lcEditorResult);
	}

	private void setUpdatedNamedParcelId(EditorSupportParams params, CreateParcelsPayload payload, EditorResult<Long> result, Boolean isForPreview) {
		checkCreateParcelsPayload(params, payload);

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		String reqParcelName = editParcelsSupportService.checkParcelName(env, payload.getParcel_name(), payload.getBlock_id());

		BlockNTT blockNTT = blockDAO.findBlockDetailsByTenantAndId(params.getSession().getTenant_id(), payload.getBlock_id());
		SectorNTT sectorNTT = sectorDAO.findSectorDetailsByTenantAndId(params.getSession().getTenant_id(), payload.getSector_id());

		checkBlockAndSectorOfCreateParcelsPayload(params, blockNTT, sectorNTT);

		checkIfParcelNameAlreadyExists(params, payload, env, reqParcelName);

		params.setBlock_id(payload.getBlock_id());
		params.setSector_id(payload.getSector_id());
		params.setParcelName(reqParcelName);
		params.setSde_code(payload.getSde_code());
		params.setClient_ref(payload.getClient_ref());

		Long parcelId = result.getCreated().entrySet()
				.stream()
				.max(Comparator.comparingLong(entry -> Math.round(entry.getValue().getArea())))
				.map(Map.Entry::getKey)
				.orElse(null);

		Geometry g = result.getCreated().get(parcelId);
		result.getModified().put(parcelId,(Polygon) g);
		result.getCreated().remove(parcelId);

		// If the parcel exists in the past get the parcel id
		ParcelNTT oldParcel = parcelsDAO.getParcelByTenantSectorBlockIdAndParcel(params.getSession().getTenant_id(), payload.getBlock_id(), reqParcelName);
		// This method is used to add a new parcel to the modified list of polygons.
		if(oldParcel != null) {
			result.getModified().remove(parcelId);				
			parcelId = oldParcel.getParcel_id();
			result.getModified().put(parcelId,(Polygon) g);
		}


		Long editId = editParcelsDAO.nextSequenceVal();
		ParcelNTT parcelToInsert = ParcelNTT.builder()
				.edit_id(editId)
				.parcel_id(parcelId)
				.srs(blockNTT.getSrs())
				.area_sqm((double) Math.round(g.getArea()))
				.geom(g)
				.parcel(reqParcelName)
				.block(blockNTT)
				.edit_status(EditStatus.IN_EDIT)
				.external_code(payload.getExternal_code())
				.build();

		if(Boolean.FALSE.equals(isForPreview)) {
			editParcelsDAO.insert(params.getSession().getUuid(), parcelToInsert);
			if(params.getSession().getParcel_id() == null) {
				editSessionSupportService.updateParcelIdByTenantAndSessionId(params, parcelId);
			}
		}
		params.setSession(editSessionSupportService.getSession(params.getSession().getUuid()));
	}

	private void checkIfParcelNameAlreadyExists(EditorSupportParams params, CreateParcelsPayload payload, ServiceSupportEnv env, String reqParcelName) {
		//check if parcel name already exists in edit parcels or parcels
		Long inEditParcelCount = editParcelsDAO.findAllEditParcelsByBlockIdAndSessionId(payload.getBlock_id(), params.getSession().getUuid())
				.stream()
				.filter(p -> p.getParcel() != null && p.getParcel().equals(payload.getParcel_name()))
				.count();

		List<ParcelNTT> alreadyExistParcel = parcelsDAO.findParcelBySectorBlockAndName(env, payload.getSector_id(), payload.getBlock_id(), reqParcelName);
		// If the existing parcel is already present in edit parcel count or if there is no existing parcel.
		if (inEditParcelCount != 0 || (alreadyExistParcel != null && !alreadyExistParcel.isEmpty())) {
			ParcelDataAlreadyExistException ex = new ParcelDataAlreadyExistException(Status.CONFLICT,
					Operation.CREATE_PARCEL, ErrorField.PARCEL_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());
			throw ex;
		}
	}

	private void checkBlockAndSectorOfCreateParcelsPayload(EditorSupportParams params, BlockNTT blockNTT, SectorNTT sectorNTT) {
		// Checks if the blockNTT is null or not equal to the sectorNTT.
		if(blockNTT == null || sectorNTT == null || !sectorNTT.getId().equals(blockNTT.getSector_id())) {
			InvalidPayloadException ex = new InvalidPayloadException(Status.BAD_REQUEST,
					params.getOperation(), ErrorField.PAYLOAD,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getReqContext().getTenantId()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}

	private void checkCreateParcelsPayload(EditorSupportParams params, CreateParcelsPayload payload) {
		// If the block_id and sector_id are null or null then an InvalidPayloadException is thrown.
		if(payload.getBlock_id() == null || payload.getSector_id() == null) {
			InvalidPayloadException ex = new InvalidPayloadException(Status.BAD_REQUEST,
					params.getOperation(), ErrorField.PAYLOAD,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getReqContext().getTenantId()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}

	// ----------------------------------------------------------------------------------------------------------------------

	// Fills parcel with data from payload.
	public EditResult fillParcel(EditorSupportParams params, @NotNull @Valid FillParcelsPayload payload, Boolean isForPreview) {

		editParcelsSupportService.checkCanEdit(isForPreview, params, null, null);

		Map<Long, Polygon> parcelsMap = editLandCoversSupportService.loadParcelPolygons(params, Arrays.asList(params.getParcelId()));
		// If the parcel id is not in the parcelsMap.
		if (!parcelsMap.containsKey(params.getParcelId())) {
			InvalidSessionParcelIdException ex = new InvalidSessionParcelIdException(Status.BAD_REQUEST,
					Operation.FILL_PARCEL, ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Polygon parcelGeom = parcelsMap.get(params.getParcelId());

		EditorResult<Long> editorResult = new EditorResult<>();
		editorResult.getModified().put(params.getParcelId(), parcelGeom);

		CreateLandCoversPayload landCoversPayload = new CreateLandCoversPayload(
				parcelGeom,
				payload.getLand_cover_code(),
				CutBehaviour.CUT_ON_EXISTING);

		LandCoversEditResult lcEditorResult = editLandCoversService.createLandCovers(params, landCoversPayload, isForPreview).getLand_covers_edit_result();

		return getEditParcelPreviewResult(params, editorResult, lcEditorResult);
	}

	// ----------------------------------------------------------------------------------------------------------------------

	public EditResult updateParcel(EditorSupportParams params, @NotNull @Valid UpdateParcelsPayload payload, Boolean isForPreview, Boolean fillParcel) {

		List<Long> parcelIds = payload.getPolygons().keySet().stream().collect(Collectors.toList());
		
		editParcelsSupportService.checkCanEdit(isForPreview, params, parcelIds, Utils.getUnion(payload.getPolygons().values()));

		checkUpdateParcelPayload(params, payload, parcelIds);
		
		if(payload.getBuffer() != null && payload.getBuffer() != 0 ) {
			Geometry updateGeom = payload.getPolygons().get(params.getParcelId()).buffer(payload.getBuffer());
			payload.getPolygons().replace(params.getParcelId(), updateGeom);
		}
		Map<Long, Polygon> updatePolygons = editLandCoversSupportService.loadParcelPolygons(params, parcelIds);

		Editor<Long> editor = getEditor(params, payload.getCut_behaviour(), updatePolygons, isForPreview);


		EditorResult<Long> result = new EditorResult<>();
		try {
			Map<Long, Polygon> polygons = payload.getPolygons().entrySet()
					.stream()
					.collect(Collectors.toMap(Map.Entry::getKey, e -> (Polygon)e.getValue()));

			result = editor.modifyPolygons(polygons);
		} catch (AbstractException e) {
			throwExceptionFromEditorOperation(e, params);
		}

		// in preview update landcover is not needed
		LandCoversEditResult lcEditorResult = new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());

		if (Boolean.FALSE.equals(isForPreview)) {
			persistEditorResult(params, params.getSession().getReference_date(), result);

			// update landcover
			lcEditorResult = editLandCoversService.updateParcelsLandCovers(params, payload, result, isForPreview);

			//fill Parcel
			if(Boolean.TRUE.equals(fillParcel)) {
				for (Map.Entry<Long, Geometry> entry : payload.getPolygons().entrySet()) {
					FillParcelsPayload landCoversPayload = new FillParcelsPayload(internalConf.getStringValue(params.getSession().getTenant_id(), InternalConfigKeys.DEFAULT_LAND_COVER_CODE_KEY.getKey()));
					params.setParcelId(entry.getKey());

					LandCoversEditResult lcFillEditorResult = fillParcel(params, landCoversPayload, isForPreview).getLand_covers_edit_result();
					lcEditorResult.getDeleted().addAll(lcFillEditorResult.getDeleted());
					lcEditorResult.getAdded().addAll(lcFillEditorResult.getAdded());

					Map<Long, LandCoverWithUnits> fillLcMap = lcFillEditorResult.getUpdated().stream().collect(Collectors.toMap(LandCoverWithUnits::getId, Function.identity()));
					lcEditorResult.setUpdated(lcEditorResult.getUpdated().stream()
							.map(lc -> fillLcMap.containsKey(lc.getId()) ? fillLcMap.get(lc.getId()) : lc)
							.collect(Collectors.toList()));

				}
			}

		}
		return getEditParcelPreviewResult(params, result, lcEditorResult);
	}

	private void checkUpdateParcelPayload(EditorSupportParams params, UpdateParcelsPayload payload,
			List<Long> parcelIds) {
		Boolean enabledMoveVertex = internalConf.getBooleanValue(params.getSession().getTenant_id(), InternalConfigKeys.ENABLE_MOVE_VERTEX.getKey());
		if((Boolean.FALSE.equals(enabledMoveVertex) && parcelIds.size() != 1) || !parcelIds.contains(params.getParcelId())) {
			InvalidPayloadException ex = new InvalidPayloadException(Status.BAD_REQUEST, Operation.UPDATE_PARCEL, ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		if (payload.getBuffer() != null && payload.getBuffer() != 0) {
			if(parcelIds.size() != 1) {
				InvalidPayloadException ex = new InvalidPayloadException(Status.BAD_REQUEST, Operation.UPDATE_PARCEL, ErrorField.PARCEL_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
			if (payload.getBuffer() < this.internalConf.getIntegerValue(params.getSession().getTenant_id(),
					InternalConfigKeys.MINIMUM_UPDATE_BUFFER_SIZE_KEY.getKey())) {
				UpdateBufferTooSmallException ex = new UpdateBufferTooSmallException(Status.BAD_REQUEST,
						Operation.UPDATE_PARCEL, ErrorField.BUFFER,
						this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}

			if (payload.getBuffer() > this.internalConf.getIntegerValue(params.getSession().getTenant_id(),
					InternalConfigKeys.MAXIMUM_UPDATE_BUFFER_SIZE_KEY.getKey())) {
				UpdateBufferTooLargeException ex = new UpdateBufferTooLargeException(Status.BAD_REQUEST,
						Operation.UPDATE_PARCEL, ErrorField.BUFFER,
						this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
			
		}
	}

	public EditResult updateParcelData(EditorSupportParams params, @NotNull @Valid UpdateParcelsDataPayload payload) {

		ParcelsEditResult parcelEditRes = new ParcelsEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
		LandCoversEditResult landCoversEditRes = new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
		EditResult result = new EditResult();

		Long parcelId = params.getParcelId();
		Long reqBlockId = payload.getSector_block_id();
		Long inheritParcelId = null;
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		// variuos checks for session and parcel
		editParcelsSupportService.checkCanEdit(false, params, Arrays.asList(parcelId), null);

		// check the values via the configured plugins
		String reqParcelName = editParcelsSupportService.checkParcelName(env, payload.getParcel(), reqBlockId);

		// if active then refresh session validity
		editSessionSupportService.refreshSession(env.getSessionId());

		// check and get the current parcel data
		ParcelNTT parcelToDelete = findParcelToDelete(params, parcelId, env, reqParcelName, reqBlockId);

		// and get data
		String parcelCode = reqParcelName != null ? reqParcelName : parcelToDelete.getParcel();
		Long parcelToDeleteBlockId = parcelToDelete.getBlock() != null ? parcelToDelete.getBlock().getId() : null;
		Long sectorBlockId = reqBlockId != null ? reqBlockId : parcelToDeleteBlockId;

		// if no block has been defined, even in the editing parcel, search for the one that intersects its geometry 
		if (sectorBlockId == null && parcelToDelete.getGeom() != null) {
			// search the block 
			List<BlockNTT> blocksInter = getBlocksByTenantSRSWithInteraction(params, env, parcelToDelete.getGeom(), Operation.UPDATE_PARCEL_DATA);

			// set the block also to the editing one
			parcelToDelete.setBlock(BlockNTT.builder().id(blocksInter.get(0).getId()).build());
			sectorBlockId = parcelToDelete.getBlock().getId();
		}

		inheritParcelId = editParcelsSupportService.getInheritParcelId(params, env, parcelCode, sectorBlockId);

		// parcel is new and in editing, update only parcel code and sector_block_id
		if (parcelToDelete.getParcel_id() < 0 && inheritParcelId == null) {
			updateNewParcel(env, parcelEditRes, parcelToDelete, parcelCode, sectorBlockId);
		}
		// delete old parcel and insert new parcel
		else {
			landCoversEditRes = updateDeletedParcel(params, parcelId, inheritParcelId, env, parcelEditRes,
					parcelToDelete, parcelCode, sectorBlockId);
		}

		Boolean flHideLandCovers = internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_HIDE_LANDCOVERS_LAYER.getKey());
		if(Boolean.TRUE.equals(flHideLandCovers)) {
			result.setLand_covers_edit_result(new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>()));
		} else {
			result.setLand_covers_edit_result(landCoversEditRes);
		}

		result.setParcels_edit_result(parcelEditRes);

		return result;
	}

	private List<BlockNTT> getBlocksByTenantSRSWithInteraction(EditorSupportParams params, ServiceSupportEnv env, Geometry geom,
			Operation operation) {
		List<BlockNTT> blocksInter = blockDAO.findBlocksByTenantSRSWithInteraction(env.getTenantId(), env.getSrs(), geom);
		if (blocksInter.isEmpty()) {
			ParcelBlockNotValidException ex = new ParcelBlockNotValidException(Status.BAD_REQUEST,
					operation, ErrorField.BLOCK,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		return blocksInter;
	}

	private LandCoversEditResult updateDeletedParcel(EditorSupportParams params, Long parcelId, Long inheritParcelId,
			ServiceSupportEnv env, ParcelsEditResult parcelEditRes, ParcelNTT parcelToDelete, String parcelCode, Long sectorBlockId) {

		BlockNTT block = parcelToDelete.getBlock();
		if(sectorBlockId != null) {
			block = blockDAO.findBlockDetailsByTenantAndId(params.getSession().getTenant_id(), sectorBlockId); 
		}

		SectorNTT sector = sectorDAO.findSectorDetailsByTenantAndId(env.getTenantId(), block.getSector_id());

		AbsoluteDate dayTo = parcelToDelete.getDay_to() != null ? parcelToDelete.getDay_to() : END_OF_WORLD;
		AbsoluteDate dayFrom = parcelToDelete.getDay_from() != null ? parcelToDelete.getDay_from() : env.getReferenceDate();

		List<LandCoverNTT> landcoversToDelete = new ArrayList<>();
		LandCoversEditResult landCoversEditRes;
		// if inheritParcelId is not null try to delete the current editinig row
		if (inheritParcelId != null) {
			landcoversToDelete = editLandCoversSupportService.findLandCoversByParcels(params, List.of(inheritParcelId));
			editParcelsDAO.deleteBySessionIdParcelId(env.getSessionId(), inheritParcelId);
		}
		else {
			inheritParcelId = editParcelsDAO.nextNewParcelIdVal();
		}

		Geometry geom = parcelToDelete.getGeom();
		Double area = parcelToDelete.getArea_sqm();

		ParcelNTT newParcelToInsert = ParcelNTT.builder()
				.area_sqm(area)
				.parcel(parcelCode)
				.geom(geom)
				.srs(parcelToDelete.getSrs())
				.parcel_id(inheritParcelId)
				.edit_id(editParcelsDAO.nextSequenceVal())
				.day_to(dayTo)
				.day_from(dayFrom)
				.block(block)
				.sector(sector)
				.edit_status(EditStatus.IN_EDIT)
				.parent_id(parcelToDelete.getParent_id() != null ? parcelToDelete.getParent_id() : parcelToDelete.getParcel_id())
				.build();

		parcelToDelete.setArea_sqm(0.0);
		parcelToDelete.setGeom(null);
		parcelToDelete.setEdit_status(EditStatus.DELETED);

		// update parcels
		if (parcelToDelete.getEdit_id() == null) {
			parcelToDelete.setEdit_id(editParcelsDAO.nextSequenceVal());
			editSessionSupportService.checkAndInsertEditParcel(params, parcelToDelete);
		} else {
			editParcelsDAO.updateGeometryByParcelId(parcelToDelete, env.getSessionId());
		}

		editSessionSupportService.checkAndInsertEditParcel(params, newParcelToInsert);
		landcoversToDelete.forEach(lc -> {
			lc.setEdit_parcel_id(newParcelToInsert.getEdit_id());
			lc.setArea_sqm(0.0);
			lc.setGeom(null);
			lc.setEdit_status(EditStatus.DELETED);
			
			editLandCoversSupportService.insertEditLandcover(params.getSession().getUuid(), lc);
		});

		// update land covers
		landCoversEditRes = editLandCoversService.updateLandCoversFromUpdateParcelData(params, parcelToDelete, newParcelToInsert);

		// set parcel update result
		Parcel parcelEditResToAdd = editParcelsSupportService.buildParcelFromParcelNTT(newParcelToInsert, parcelToDelete.getParcel_id());

		parcelEditRes.getDeleted().add(parcelId);
		parcelEditRes.getAdded().add(parcelEditResToAdd);
		return landCoversEditRes;
	}

	private void updateNewParcel(ServiceSupportEnv env, ParcelsEditResult parcelEditRes, ParcelNTT parcelToDelete,
			String parcelCode, Long sectorBlockId) {

		BlockNTT block = parcelToDelete.getBlock() != null ? parcelToDelete.getBlock() : BlockNTT.builder().id(sectorBlockId).build();
		SectorNTT sector = parcelToDelete.getSector() != null ? parcelToDelete.getSector() : SectorNTT.builder().build();
		AbsoluteDate dayTo = parcelToDelete.getDay_to() != null ? parcelToDelete.getDay_to() : END_OF_WORLD;
		AbsoluteDate dayFrom = parcelToDelete.getDay_from() != null ? parcelToDelete.getDay_from() : env.getReferenceDate();

		ParcelNTT parcelToUpdate = parcelToDelete;
		parcelToUpdate.setParcel(parcelCode);

		parcelToUpdate.setDay_to(dayTo);
		parcelToUpdate.setDay_from(dayFrom);
		parcelToUpdate.setBlock(block);
		parcelToUpdate.setSector(sector);
		parcelToUpdate.setEdit_status(EditStatus.IN_EDIT);

		editParcelsDAO.updateParcelDataByParcelId(parcelToUpdate, env.getSessionId());		

		Parcel parcelEditResToUpdate = editParcelsSupportService.buildParcelFromParcelNTT(parcelToUpdate, null);

		parcelEditRes.getUpdated().add(parcelEditResToUpdate);
	}

	private ParcelNTT findParcelToDelete(EditorSupportParams params, Long parcelId, ServiceSupportEnv env, 
			String reqParcelName, Long reqBlockId) {
		ParcelNTT parcelToDelete = null;

		// check if parcel is in editing
		List<ParcelNTT> inEditParcel = editParcelsDAO.findInEditBySessionId(env.getSessionId(), env.getReferenceDate(), parcelId);
		if (inEditParcel != null && !inEditParcel.isEmpty()) {
			parcelToDelete = inEditParcel.get(0);
		} else {
			// else serch the parcel in the details table
			parcelToDelete = parcelsDAO.getParcelDetail(params.getReqContext().getTenantId(), parcelId, env.getReferenceDate(), null, DO_NOT_INCLUDE_OUTDATED_PARCELS);
			// if parcel does not exists editing nor in details then it does not exits, exception!
			if (parcelToDelete == null) { 
				ParcelNotFoundException ex = new ParcelNotFoundException(Status.NOT_FOUND, Operation.UPDATE_PARCEL_DATA, ErrorField.PARCEL,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
		}

		// check if the parcel has the same data of the ones of the change request 
		// (name == reqName and block == reqBlock) at this point the block could be null
		// if so the request is not valid
		boolean equalsName = StringUtils.equals(parcelToDelete.getParcel(), reqParcelName);
		Long blockId = (parcelToDelete.getBlock() == null || parcelToDelete.getBlock().getId() == null) ? null : parcelToDelete.getBlock().getId();
		boolean equalsBlock = Objects.equals(blockId, reqBlockId);
		if (equalsName && equalsBlock) {
			ParcelDataAlreadyExistException ex = new ParcelDataAlreadyExistException(Status.CONFLICT,
					Operation.UPDATE_PARCEL_DATA, ErrorField.PARCEL_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return parcelToDelete;
	}

	// ----------------------------------------------------------------------------------------------------------------------

	public EditResult deleteParcel(EditorSupportParams params) {

		editParcelsSupportService.checkCanEdit(false, params, Arrays.asList(params.getParcelId()), null);

		editSessionSupportService.refreshSession(params.getSession().getUuid());

		EditorResult<Long> result = new EditorResult<>();
		result.getDeleted().add(params.getParcelId());
		// delete the land covers
		LandCoversEditResult lcEditorResult = editLandCoversService.deleteParcelsLandCovers(params, false); // the delete is never for preview

		persistEditorResult(params, params.getSession().getReference_date(), result);

		return getEditParcelPreviewResult(params, result, lcEditorResult);
	}

	// ----------------------------------------------------------------------------------------------------------------------

	public EditResult cutParcelByLine(EditorSupportParams params, @NotNull @Valid CutParcelsByLinePayload payload, Boolean isForPreview) {

		editParcelsSupportService.checkCanEdit(isForPreview, params, Arrays.asList(params.getParcelId()), null);

		Long parcelId = params.getParcelId();
		if (parcelId == null) {
			ParcelIdsNotValidException ex = new ParcelIdsNotValidException(Status.BAD_REQUEST, Operation.CUT_PARCEL, ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Map<Long, Polygon> cutPolygons = editLandCoversSupportService.loadParcelPolygons(params, Arrays.asList(parcelId));
		if (cutPolygons.keySet().size() != 1) {
			ParcelIdsNotFoundException ex = new ParcelIdsNotFoundException(Status.BAD_REQUEST, Operation.CUT_PARCEL, ErrorField.PARCEL_IDS,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Editor<Long> editor = getEditor(params, CutBehaviour.CUT_ON_EXISTING, cutPolygons, isForPreview);

		EditorResult<Long> result = new EditorResult<>();
		try {
			result = editor.cutPolygonsByLine((LineString) payload.getGeom());
		} catch (AbstractException e) {
			throwExceptionFromEditorOperation(e, params);
		}

		// in preview update landcover is not needed
		LandCoversEditResult lcEditorResult = new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
		if (Boolean.FALSE.equals(isForPreview)) {
			persistEditorResult(params, params.getSession().getReference_date(), result);

			// import the land covers of the cutted parcels
			lcEditorResult = editLandCoversService.cutParcelsLandCoversByLine(params, payload.getGeom(), result, isForPreview);
		}

		return getEditParcelPreviewResult(params, result, lcEditorResult);

	}

	// ----------------------------------------------------------------------------------------------------------------------

	public EditResult cutParcel(EditorSupportParams params, CutParcelsPayload payload, Boolean isForPreview) {

		editParcelsSupportService.checkCanEdit(isForPreview, params, Arrays.asList(params.getParcelId()), null);

		Long parcelId = params.getParcelId();
		if (parcelId == null) {
			ParcelIdsNotValidException ex = new ParcelIdsNotValidException(Status.BAD_REQUEST, Operation.CUT_PARCEL, ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if(payload.getGeom() == null) {
			InvalidPayloadException ex = new InvalidPayloadException(Status.BAD_REQUEST, Operation.CUT_PARCEL, ErrorField.GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Geometry geom = payload.getGeom();

		if(geom.getGeometryType().equals(Geometry.TYPENAME_POLYGON)) {
			return cutParcelInternal(params, isForPreview, parcelId, geom);
		} 

		if(payload.getBuffer() != null 
				&& !payload.getBuffer().equals(0.0)) {
			geom = geom.buffer(payload.getBuffer());
		}

		if(geom.getGeometryType().equals(Geometry.TYPENAME_LINESTRING)) {
			return cutParcelByLine(params, CutParcelsByLinePayload.builder().geom(geom).build(), isForPreview);
		} 

		if(geom.getGeometryType().equals(Geometry.TYPENAME_POINT)) {
			InvalidPayloadException ex = new InvalidPayloadException(Status.BAD_REQUEST, Operation.CUT_PARCEL, ErrorField.GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return cutParcelInternal(params, isForPreview, parcelId, geom);
	}

	private EditResult cutParcelInternal(EditorSupportParams params, Boolean isForPreview, Long parcelId,
			Geometry geom) {
		Map<Long, Polygon> cutPolygons = editLandCoversSupportService.loadParcelPolygons(params, Arrays.asList(parcelId));
		if (cutPolygons.keySet().size() != 1) {
			ParcelIdsNotFoundException ex = new ParcelIdsNotFoundException(Status.BAD_REQUEST, Operation.CUT_PARCEL, ErrorField.PARCEL_IDS,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Editor<Long> editor = getEditor(params, CutBehaviour.CUT_ON_EXISTING, cutPolygons, isForPreview);

		EditorResult<Long> result = editor.insertPolygon((Polygonal) geom, false, true);

		result.getCoveredByInserted().stream().forEach(id -> {
			if (result.getCreated().containsKey(id)) {
				result.getCreated().remove(id);
			} else {
				result.getModified().remove(id);
			}
		});

		// in preview update landcover is not needed
		LandCoversEditResult lcEditorResult = new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
		if (Boolean.FALSE.equals(isForPreview)) {
			persistEditorResult(params, params.getSession().getReference_date(), result);

			// import the land covers of the cutted parcels
			lcEditorResult = editLandCoversService.cutParcelsLandCovers(params, geom, result, isForPreview);
		}

		return getEditParcelPreviewResult(params, result, lcEditorResult);
	}

	// ----------------------------------------------------------------------------------------------------------------------

	public EditResult mergeParcels(EditorSupportParams params, @NotNull @Valid MergeParcelsPayload payload, Boolean isForPreview) {

		editParcelsSupportService.checkCanEdit(isForPreview, params, payload.getParcel_ids(), null);

		if (payload.getParcel_ids().size() > this.internalConf.getIntegerValue(params.getReqContext().getTenantId(),
				InternalConfigKeys.MAXIMUM_PARCELS_TO_MERGE_KEY.getKey())) {
			TooMuchParcelsToMergeException ex = new TooMuchParcelsToMergeException(Status.NOT_FOUND, Operation.MERGE_PARCELS, ErrorField.PARCEL_IDS,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Editor<Long> editor = getEditor(params, CutBehaviour.CUT_EXISTING, null, isForPreview);

		List<Long> parcelIds = payload.getParcel_ids();

		Map<Long, Polygon> editPolygons = editLandCoversSupportService.loadParcelPolygons(params, parcelIds);

		if (editPolygons.keySet().size() != parcelIds.size()) {
			ParcelIdsNotFoundException ex = new ParcelIdsNotFoundException(Status.BAD_REQUEST, Operation.MERGE_PARCELS, ErrorField.PARCEL_IDS,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		EditorResult<Long> result = new EditorResult<>();
		try {
			result = editor.mergePolygons(editPolygons, params.getParcelId());
		} catch (AbstractException e) {
			throwExceptionFromEditorOperation(e, params);
		}

		// in preview update landcover is not needed
		LandCoversEditResult lcEditorResult = new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());

		if (Boolean.FALSE.equals(isForPreview)) {
			persistEditorResult(params, params.getSession().getReference_date(), result);

			// import the land covers of the merged parcels
			lcEditorResult = editLandCoversService.mergeParcelsLandCovers(params, payload.getParcel_ids(), result, isForPreview);

			if (Boolean.TRUE.equals(this.internalConf.getBooleanValue(params.getSession().getTenant_id(), InternalConfigKeys.FLAG_MERGE_LAND_COVERS_WITH_SAME_CODE_KEY.getKey()))) {
				lcEditorResult = editLandCoversService.mergeLandCoversWithSameCode(params, isForPreview);
			}
		}

		return getEditParcelPreviewResult(params, result, lcEditorResult);

	}

	// ----------------------------------------------------------------------------------------------------------------------

	public GeometryIntersection getIntersectGeomsFromCatalogue(EditorSupportParams params, String catalogueCode, OverlayType overlayType, GeometryIntersectionPayload payload) {
		//TODO payload srs?

		editSessionSupportService.checkEditableSession(params, Operation.CHECK_CAN_EDIT_PARCEL);

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		Catalogue catalogue = cataloguesService.getCatalogueByCodeAndSrs(env, catalogueCode, SHOW_ALL_CATALOGUES);
		if(catalogue == null) {
			CatalogueIdNotFoundException ex = new CatalogueIdNotFoundException(Status.BAD_REQUEST,
					params.getOperation(), ErrorField.CATALOGUE,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getReqContext().getTenantId()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Long parcelId = params.getParcelId();
		if (parcelId == null) {
			ParcelIdsNotValidException ex = new ParcelIdsNotValidException(Status.BAD_REQUEST, params.getOperation(), ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Map<Long, Polygon> parcelGeomMap = editLandCoversSupportService.loadParcelPolygons(params, Arrays.asList(parcelId));
		if (parcelGeomMap.keySet().size() != 1) {
			ParcelIdsNotFoundException ex = new ParcelIdsNotFoundException(Status.BAD_REQUEST, params.getOperation(), ErrorField.PARCEL_IDS,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Geometry parcelGeom = Utils.getUnion(parcelGeomMap.values());

		CataloguePayload cataloguePayload = CataloguePayload.builder()
				.geom(payload.getGeom())
				.srs(payload.getSrs())
				.params(payload.getParams())
				.build();

		List<Geometry> catalogueGeoms = cataloguesService.getGeomsFromCatalogueList(env, catalogue.getCode(), params.getSession().getReference_date(), cataloguePayload).stream()
				.map(CatalogueGeom::getGeom)
				.collect(Collectors.toList());
		if(!catalogueGeoms.isEmpty() && parcelGeom != null) {	
			Geometry catalogueGeom = Utils.getUnion(catalogueGeoms);

			if(OverlayType.INTERSECTION.equals(overlayType)) {
				return GeometryIntersection.builder()
						.geom(parcelGeom.intersection(catalogueGeom))
						.srs(payload.getSrs())
						.build();
			} else if(OverlayType.DIFFERENCE.equals(overlayType)) {
				return GeometryIntersection.builder()
						.geom(parcelGeom.difference(catalogueGeom))
						.srs(payload.getSrs())
						.build();
			}
		}

		return GeometryIntersection.builder().geom(null).srs(payload.getSrs()).build();
	}

	// ----------------------------------------------------------------------------------------------------------------------



	private Editor<Long> getEditor(EditorSupportParams params, CutBehaviour cutBehaviour, Map<Long, Polygon> cutPolygons, boolean isForPreview) {

		Long nextNewParcelId = editParcelsDAO.nextNewParcelIdVal();

		Editor<Long> editor = new Editor<>(editorSupportFactory.createEditorSupport(params, cutBehaviour, null, cutPolygons, isForPreview, nextNewParcelId));

		// Resolve overlaps between geometries to avoid errors for dirty geometries 
		editor.setResolveOverlaps(true);
		
		// Fix some issue in reduce geometry linked to very small geometries, avoiding area check after reduction
		editor.setTolerateAreaReduction(true);

		return editor;

	}

	private Map<Long, ParcelNTT> getCurrentParcelsMap(ServiceSupportEnv env) {

		Map<Long, ParcelNTT> currentParcelsMap = new HashMap<>();
		editParcelsDAO.findInEditBySessionId(env.getSessionId(), env.getReferenceDate(), null)
		.stream()
		.forEach(p -> currentParcelsMap.put(p.getParcel_id(), p));
		editParcelsDAO.findNotInEditBySessionId(env, null)
		.stream()
		.forEach(p -> currentParcelsMap.put(p.getParcel_id(), p));

		return currentParcelsMap;
	}

	private EditResult getEditParcelPreviewResult(EditorSupportParams params, EditorResult<Long> parcelEditorResult, LandCoversEditResult lcEditorResult) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		Map<Long, ParcelNTT> currentParcelsMap = getCurrentParcelsMap(env);

		ParcelsEditResult parcelEditRes = new ParcelsEditResult();
		parcelEditRes.setAdded(new ArrayList<>());

		parcelEditorResult.getCreated().entrySet()
		.stream()
		.map(Map.Entry::getKey)
		.forEach(k -> {
			Geometry g = parcelEditorResult.getCreated().get(k);
			EditParcelData parcelData = getEditParcelData(params, parcelEditorResult, currentParcelsMap, k, Operation.GET_CREATED_EDIT_PARCEL_DATA);
			parcelEditRes.getAdded().add(editParcelsSupportService.buildParcelEditRes(params, k, g, parcelData));
		});

		parcelEditRes.setUpdated(new ArrayList<>());
		parcelEditorResult.getModified().keySet()
		.forEach(k -> {
			Geometry g = parcelEditorResult.getModified().get(k);
			EditParcelData parcelData = getEditParcelData(params, parcelEditorResult, currentParcelsMap, k, Operation.GET_MODIFIED_EDIT_PARCEL_DATA);
			parcelEditRes.getUpdated().add(editParcelsSupportService.buildParcelEditRes(params, k, g, parcelData));
		});

		parcelEditorResult.getTopologyCorrected().keySet()
		.forEach(k -> {
			Geometry g = parcelEditorResult.getTopologyCorrected().get(k);
			EditParcelData parcelData = getEditParcelData(params, parcelEditorResult, currentParcelsMap, k, Operation.GET_TOPOLOGY_CORRECTED_EDIT_PARCEL_DATA);
			parcelEditRes.getUpdated().add(editParcelsSupportService.buildParcelEditRes(params, k, g, parcelData));
		});

		parcelEditRes.setDeleted(List.copyOf(parcelEditorResult.getDeleted()));

		Boolean flHideLandCovers = internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_HIDE_LANDCOVERS_LAYER.getKey());
		if(Boolean.TRUE.equals(flHideLandCovers)) {
			return new EditResult(parcelEditRes, new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>()));
		}

		return new EditResult(parcelEditRes, lcEditorResult);
	}

	private EditParcelData getEditParcelData(EditorSupportParams params, EditorResult<Long> parcelEditorResult, 
			Map<Long, ParcelNTT> currentParcelsMap, Long key, Operation operation) {
		EditParcelData parcelData = new EditParcelData();
		parcelData.setEditStatus(EditStatus.IN_EDIT);
		parcelData.setClientRef(getClientRef(params, key, operation));

		if(Operation.GET_CREATED_EDIT_PARCEL_DATA.equals(operation)) {
			Long parentParcelId = parcelEditorResult.getCreatedParent(key);
			parcelData.setParentParcelId(parentParcelId);
			parcelData.setSdeCode(params.getSde_code());
			if (parentParcelId != null && currentParcelsMap.get(parentParcelId) != null) {
				parcelData.setDayTo(currentParcelsMap.get(parentParcelId).getDay_to());
				parcelData.setBlock(editParcelsSupportService.getBlockFromParcelsMap(currentParcelsMap, parentParcelId));
				parcelData.setSector(editParcelsSupportService.getSectorFromParcelsMap(currentParcelsMap, parentParcelId));
			}

			return parcelData;
		} 

		setModifiedEditParcelData(params, parcelData, operation);

		if (currentParcelsMap.get(key) != null) {
			parcelData.setParcel(currentParcelsMap.get(key).getParcel());
			parcelData.setDayTo(currentParcelsMap.get(key).getDay_to());
			parcelData.setLastUpdate(currentParcelsMap.get(key).getLast_update());
			parcelData.setParentParcelId(currentParcelsMap.get(key).getParent_id());
			parcelData.setBlock(editParcelsSupportService.getBlockFromParcelsMap(currentParcelsMap, key));
			parcelData.setSector(editParcelsSupportService.getSectorFromParcelsMap(currentParcelsMap, key));
			if(Operation.GET_TOPOLOGY_CORRECTED_EDIT_PARCEL_DATA.equals(operation)
					&& !currentParcelsMap.get(key).getEdit_status().equals(EditStatus.IN_EDIT)) {
				parcelData.setEditStatus(EditStatus.TOPOLOGY_CORRECTED);
			}
		}

		return parcelData;
	}

	private void setModifiedEditParcelData(EditorSupportParams params, EditParcelData parcelData, Operation operation) {
		if(Operation.GET_MODIFIED_EDIT_PARCEL_DATA.equals(operation)) {
			parcelData.setSdeCode(params.getSde_code());
			if (StringUtils.isNotBlank(params.getParcelName()) && params.getBlock_id() != null && params.getSector_id() != null) {
				parcelData.setBlock(BlockMapper.INSTANCE.entityToDto(blockDAO.findBlockDetailsByTenantAndId(params.getSession().getTenant_id(), params.getBlock_id())));
				parcelData.setSector(SectorMapper.INSTANCE.entityToDto(sectorDAO.findSectorDetailsByTenantAndId(params.getSession().getTenant_id(), params.getSector_id())));
				parcelData.setParcel(params.getParcelName());
			}
		}
	}

	private String getClientRef(EditorSupportParams params, Long key, Operation operation) {
		if((Operation.GET_CREATED_EDIT_PARCEL_DATA.equals(operation) || Operation.GET_MODIFIED_EDIT_PARCEL_DATA.equals(operation))
				&& (params.getSession().getParcel_id() != null && params.getSession().getParcel_id().equals(key))) {
			return params.getClient_ref();

		}
		return null;
	}

	private void persistEditorResult(EditorSupportParams params, AbsoluteDate referenceDate, EditorResult<Long> result) {

		List<ParcelNTT> persistParcels = new ArrayList<>();

		editParcelsSupportService.setDeletedPersistParcels(params, result, persistParcels);

		setCreatedPersistParcels(params, referenceDate, result, persistParcels);

		setModifiedPersistParcels(params, result, persistParcels);

		savePersistParcels(params, result, persistParcels);

	}

	private void setModifiedPersistParcels(EditorSupportParams params, EditorResult<Long> result, List<ParcelNTT> persistParcels) {
		result.getModified().keySet().forEach(pid -> {
			Geometry g = result.getModified().get(pid);

			String parcel = null;
			BlockNTT block = null;
			if(params.getSession().getParcel_id() != null && params.getSession().getParcel_id().equals(pid)) {
				block = blockDAO.findBlockDetailsByTenantAndId(params.getSession().getTenant_id(), params.getBlock_id());
				parcel = params.getParcelName();

			}

			persistParcels.add(ParcelNTT
					.builder()
					.editorResultParcelId(pid)
					.parcel_id(pid)
					.srs(params.getSession().getLock_geom_srs())
					.parcel(parcel)
					.block(block)
					.geom(g)
					.area_sqm(g.getArea())
					.edit_status(EditStatus.IN_EDIT)
					.sde_code(params.getSde_code())
					.build());
		});

		result.getTopologyCorrected().keySet().forEach(pid -> {
			Geometry g = result.getTopologyCorrected().get(pid);

			persistParcels.add(ParcelNTT
					.builder()
					.editorResultParcelId(pid)
					.parcel_id(pid)
					.srs(params.getSession().getLock_geom_srs())
					.geom(g)
					.area_sqm(g.getArea())
					.edit_status(EditStatus.TOPOLOGY_CORRECTED)
					.build());
		});
	}

	private void setCreatedPersistParcels(EditorSupportParams params, AbsoluteDate referenceDate, EditorResult<Long> result, List<ParcelNTT> persistParcels) {
		result.getCreated().keySet().forEach(pid -> {

			Geometry g = result.getCreated().get(pid);

			ParcelNTT parentP = null;
			BlockNTT parentBlock = null;
			String externalCode = null;
			Long parentId = result.getCreatedParent(pid);
			if (parentId != null)
				parentP = parcelsDAO.getParcelDetail(params.getSession().getTenant_id(), parentId, referenceDate, null, DO_NOT_INCLUDE_OUTDATED_PARCELS);
			if (parentP != null) {
				parentBlock = parentP.getBlock();
				externalCode = parentP.getExternal_code();
			}

			String parcel = null;
			if(params.getSession().getParcel_id() != null && params.getSession().getParcel_id().equals(pid)) {
				parentBlock = blockDAO.findBlockDetailsByTenantAndId(params.getSession().getTenant_id(), params.getBlock_id());
				parcel = params.getParcelName();

			}

			persistParcels.add(ParcelNTT
					.builder()
					.editorResultParcelId(pid)
					.parcel_id(null)
					.srs(params.getSession().getLock_geom_srs())
					.parcel(parcel)
					.geom(g)
					.area_sqm(g.getArea())
					.block(parentBlock)
					.edit_status(EditStatus.IN_EDIT)
					.parent_id(parentId)
					.sde_code(params.getSde_code())
					.external_code(externalCode)
					.build());
		});
	}

	private void savePersistParcels(EditorSupportParams params, EditorResult<Long> result, List<ParcelNTT> persistParcels) {
		// get already in edit parcels
		Map<Long, ParcelNTT> alreadyinEditMap = new HashMap<>();
		editParcelsDAO.findInEditBySessionId(params.getSession().getUuid(), params.getSession().getReference_date(), null)
		.stream()
		.forEach(p -> alreadyinEditMap.put(p.getParcel_id(), p));

		// DB Save
		persistParcels.stream().forEach(p -> {
			if (p.getParcel_id() == null) { // is new --> insert
				Long newParcelId = editParcelsSupportService.insertNewParcel(params, p);
				// If the new parcel id is not the one from the geometry editor result, fix the id
				if(p.getEditorResultParcelId() != null && newParcelId != null && !Objects.equals(newParcelId, p.getEditorResultParcelId())) {
					result.getCreated().remove(p.getEditorResultParcelId());
					result.getCreated().put(newParcelId, (Polygon) p.getGeom());
				}

			} else if (!alreadyinEditMap.containsKey(p.getParcel_id())) { // it exist but not in edit
				updateNotInEditParcel(params, p);
			} else { // to be updated
				ParcelNTT alreadyInEditParcel = alreadyinEditMap.get(p.getParcel_id());
				if (alreadyInEditParcel != null && alreadyInEditParcel.getEdit_status().equals(EditStatus.IN_EDIT) && p.getGeom() != null) {
					p.setEdit_status(EditStatus.IN_EDIT);
				}
				editParcelsDAO.updateGeometryByParcelId(p, params.getSession().getUuid());
			}
		});
	}

	private void updateNotInEditParcel(EditorSupportParams params, ParcelNTT p) {
		Long nextEditId = editParcelsDAO.nextSequenceVal();

		// check parcel name, it can not be reset to null by the user
		if (p.getParcel() == null || p.getBlock() == null) {
			// Get information from "official" lpis_parcels_details table
			ParcelNTT offParcel = parcelsDAO.getParcelDetail(params.getReqContext().getTenantId(), p.getParcel_id(),
					params.getSession().getReference_date(), null, DO_NOT_INCLUDE_OUTDATED_PARCELS);
			if (offParcel != null) {
				if (p.getParcel() == null) {
					p.setParcel(offParcel.getParcel());
				}

				if (p.getBlock() == null) {
					p.setBlock(offParcel.getBlock());
				}
			}
		}
		p.setEdit_id(nextEditId);
		p.setSrs(params.getSession().getLock_geom_srs());

		editSessionSupportService.checkAndInsertEditParcel(params, p);
	}
	
}
