package com.abacogroup.lpisgisserver.core;

import java.util.ArrayList;
import java.util.List;

import org.locationtech.jts.geom.Geometry;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.block.BlockIdsNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.block.BlockNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.block.InvalidBlockDataException;
import com.abacogroup.lpisgisserver.core.mappers.BlockMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.BlockDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.ntt.BlockNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.Block;
import com.abacogroup.lpisgisserver.resources.res.BlocksList;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BlockService extends BaseService {

	private BlockDAO blockDAO;

	public BlockService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService,
			StyleService styleService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);
		blockDAO = dc.getBlockDAO();
	}

	/**
	 * Get details of a block. This method is used by client to get details of a block. The details are returned in a Block object
	 * 
	 * @param env - service support environment for obtaining tenant id
	 * @param blockId - id of block to get details of.
	 * 
	 * @return block details of the block or exception if not found in the database ( status NOT_FOUND ) or not
	 */
	public Block getBlockDetails(ServiceSupportEnv env, Long blockId) {

		BlockNTT blockById = blockDAO.findBlockDetailsByTenantAndId(env.getTenantId(), blockId);
		// Returns the block id if it is not found.
		if (blockById == null) {
			BlockIdsNotFoundException ex = new BlockIdsNotFoundException(Status.NOT_FOUND, Operation.GET_BLOCK, ErrorField.BLOCK_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return Block.builder()
				.description(blockById.getDescription())
				.geom(blockById.getGeom())
				.id(blockById.getId())
				.sector_id(blockById.getSector_id())
				.short_descr(blockById.getShort_descr())
				.srs(blockById.getSrs())
				.world_geom(blockById.getWorld_geom())
				.block_code(blockById.getBlock())
				.build();
	}

	/**
	 * Get blocks by sector id with filter. This method is used to get blocks by filter. The filter is applied to the block id and the block type
	 * 
	 * @param env - service support environment for the tenant
	 * @param sectorId - sector id to get blocks for.
	 * @param filter - filter to apply to the block id. For example " block_type = NTT "
	 * 
	 * @return list of blocks that match
	 */
	public BlocksList getBlocksBySectorIdWithFilter(ServiceSupportEnv env, Long sectorId, String filter) {
		BlocksList result = BlocksList.builder().blocks_list(new ArrayList<>()).build();

		// If the sectorId is null throw an InvalidBlockDataException.
		if (sectorId == null) {
			InvalidBlockDataException ex = new InvalidBlockDataException(Status.BAD_REQUEST, Operation.GET_BLOCKS_BY_SECTOR, ErrorField.BLOCK_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		List<BlockNTT> blocksList = blockDAO.findBlocksByTenantAndSectorIdWithFilter(env, sectorId, filter);

		// Returns a list of blocks that are not found.
		if (blocksList == null || blocksList.isEmpty()) {
			BlockNotFoundException ex = new BlockNotFoundException(Status.NOT_FOUND, Operation.GET_BLOCKS_BY_SECTOR, null,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		blocksList.forEach(block -> result.getBlocks_list().add(
				Block.builder()
				.description(block.getDescription())
				.geom(block.getGeom())
				.id(block.getId())
				.sector_id(block.getSector_id())
				.short_descr(block.getShort_descr())
				.srs(block.getSrs())
				.world_geom(block.getWorld_geom())
				.block_code(block.getBlock())
				.build()));

		return result;
	}

	public Block findBlockByGeom(ServiceSupportEnv env, Geometry geom, String srs) {
		List<BlockNTT> blocksInter = blockDAO.findBlocksByTenantSRSWithInteraction(env.getTenantId(), srs, geom);
		if (blocksInter == null || blocksInter.isEmpty()) {
			return null;
		}
		
		blocksInter.sort((b1, b2) -> {
			double area1 = b1.getGeom().intersection(geom).getArea();
			double area2 = b2.getGeom().intersection(geom).getArea();
			return Double.compare(area2, area1);
		});

		return BlockMapper.INSTANCE.entityToDto(blocksInter.get(0));
	}

}
