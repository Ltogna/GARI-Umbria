package com.abacogroup.lpisgisserver.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.viewer.ParcelViewerNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.viewer.SectorViewerNotFoundException;
import com.abacogroup.lpisgisserver.core.mappers.ViewerLandCoverDetailsMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.FruitUnitMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.OliveUnitMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.VineAptitudesMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.VineUnitMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.FruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.OliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.ParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.SectorDAO;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.dao.VineUnitsDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.db.ntt.SectorNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.units.fruit.FruitUnit;
import com.abacogroup.lpisgisserver.resources.res.units.olive.OliveUnit;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineAptitude;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnitWithAptitudes;
import com.abacogroup.lpisgisserver.resources.res.viewer.InfoGis;
import com.abacogroup.lpisgisserver.resources.res.viewer.ViewerBlockDetails;
import com.abacogroup.lpisgisserver.resources.res.viewer.ViewerLandCoverDetails;
import com.abacogroup.lpisgisserver.resources.res.viewer.ViewerParcelDetails;
import com.abacogroup.lpisgisserver.resources.res.viewer.ViewerSectorDetails;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ViewerService extends BaseService {

	private static final int DO_NOT_INCLUDE_OUTDATED_PARCELS = 0;
	
	private final SectorDAO sectorDAO;
	private final ParcelsDAO parcelsDAO;
	private final LandCoversDAO landCoversDAO;
	private final SupportDAO supportDAO;
	private final VineUnitsDAO vineUnitsDAO;
	private final OliveUnitsDAO oliveUnitsDAO;
	private final FruitUnitsDAO fruitUnitsDAO;
	
	private final InfoGisService infoGisService;
	private final ParcelsService parcelsService;
	

	public ViewerService(DAOContainer dc, InfoGisService infoGisService, ParcelsService parcelsService, InternalConfigService conf, ExternalConfigService externalConf, 
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.sectorDAO = dc.getSectorDAO();
		this.parcelsDAO = dc.getParcelsDAO();
		this.landCoversDAO = dc.getLandCoversDAO();
		this.supportDAO = dc.getSupportDAO();
		this.vineUnitsDAO = dc.getVineUnitsDAO();
		this.oliveUnitsDAO = dc.getOliveUnitsDAO();
		this.fruitUnitsDAO = dc.getFruitUnitsDAO();
		
		this.infoGisService = infoGisService;
		this.parcelsService = parcelsService;
	}

	/**
	* Get parcel details for a given parcel. This method is used to retrieve the land cover and / or land cover data for a given parcel
	* 
	* @param tenantId - Id of the tenant that owns the parcel
	* @param parcelId - Id of the parcel to retrieve
	* @param referenceDate - Reference date for the view
	* @param lang - Language of the view. If null the default language will be used
	* 
	* @return An instance of com. opennms. netmgt. viewer. par
	*/
	public ViewerParcelDetails getParcelDetails(ServiceSupportEnv env, Long parcelId, Boolean includeInfogis) {

		ParcelNTT parcel = parcelsDAO.getParcelDetail(env.getTenantId(), parcelId, env.getReferenceDate(), null, DO_NOT_INCLUDE_OUTDATED_PARCELS);
		// Returns the parcel viewer if it is not found.
		if (parcel == null) {
			ParcelViewerNotFoundException ex = new ParcelViewerNotFoundException(Status.NOT_FOUND, Operation.GET_PARCEL_VIEWER, ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Boolean flHideLandCovers = internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_HIDE_LANDCOVERS_LAYER.getKey());
		
		List<ViewerLandCoverDetails> viewerLandCovers = new ArrayList<>();
		
		// Get all land covers that are not hidden.
		if(Boolean.FALSE.equals(flHideLandCovers)) {
			String lcOriginCatalogueCode = internalConf.getStringValue(env.getTenantId(), InternalConfigKeys.LANDCOVER_ORIGIN_CATALOGUE_CODE.getKey());
			if(!StringUtils.isBlank(lcOriginCatalogueCode)) {
				viewerLandCovers = parcelsService.getParcelLandCoversFromCatalogue(env, lcOriginCatalogueCode, parcel.getParcel_id(), parcel.getGeom(), parcel.getSrs()).stream()
						.map(ViewerLandCoverDetailsMapper.INSTANCE::toViewerLandCoverDetails)
						.collect(Collectors.toList());
			} else {
				viewerLandCovers = getViewerLandCoverDetails(env, parcel.getParcel_id(), includeInfogis); 
			}
		}

		InfoGis parcelInfogis = InfoGis.builder().build();
		if(Boolean.TRUE.equals(includeInfogis)) {
			parcelInfogis = infoGisService.getParcelInfoGis(parcel);
		}

		ViewerSectorDetails sector = buildViewerSectorDetails(parcel);

		ViewerBlockDetails block = buildViewerBlockDetails(parcel);

		return ViewerParcelDetails.builder()
				.area_sqm(Math.round(parcel.getArea_sqm()))
				.block(block)
				.day_from(parcel.getDay_from())
				.day_to(parcel.getDay_to())
				.last_update(parcel.getLast_update())
				.id(parcel.getParcel_id())
				.info_gis(parcelInfogis)
				.land_covers(viewerLandCovers)
				.parcel(parcel.getParcel())
				.sector(sector)
				.world_geom(parcel.getWorld_geom())
				.build();
	}
	
	public List<ViewerLandCoverDetails> getViewerLandCoverDetails(ServiceSupportEnv env, Long parcelId, Boolean includeInfogis) {

		List<ViewerLandCoverDetails> viewerLandCovers = new ArrayList<>();

		List<LandCoverNTT> landCoverNTTs = landCoversDAO.findByParcelIds(env, Arrays.asList(parcelId));

		landCoverNTTs.forEach(landCover -> {

			InfoGis landCoverInfogis = InfoGis.builder().build();
			if(Boolean.TRUE.equals(includeInfogis)) {
				landCoverInfogis = infoGisService.getLandCoverInfoGis(landCover);
			}

			env.setLandCoverId(landCover.getLand_cover_id());
			List<VineUnitWithAptitudes> vineUnits = getVineUnits(env);
			List<OliveUnit> oliveUnits = getOliveUnits(env);
			List<FruitUnit> fruitUnits = getFruitUnits(env);

			Long totalUnitArea = vineUnits.stream().mapToLong(VineUnitWithAptitudes::getAreaSqm).sum() + 
					oliveUnits.stream().mapToLong(OliveUnit::getAreaSqm).sum() +
					fruitUnits.stream().mapToLong(FruitUnit::getAreaSqm).sum();

			ViewerLandCoverDetails viewerLandCoverDetails = ViewerLandCoverDetails.builder()
					.area_sqm(Math.round(landCover.getArea_sqm()))
					.code(landCover.getLand_cover_code())
					.day_from(landCover.getDay_from())
					.day_to(landCover.getDay_to())
					.last_update(landCover.getLast_update())
					.description(landCover.getLand_cover_description())
					.id(landCover.getLand_cover_id())
					.info_gis(landCoverInfogis)
					.parcel_id(landCover.getParcel_id())
					.world_geom(landCover.getWorld_geom())
					.layer_style(this.styleService.getLandCoverLayerStyle(env.getTenantId(), env.getReferenceDate(), landCover.getLand_cover_code()))
					.unit_types(supportDAO.getCompatibleUnitTypesByLandCoverCode(env.getTenantId(), landCover.getLand_cover_code()))
					.vine_units(vineUnits)
					.olive_units(oliveUnits)
					.fruit_units(fruitUnits)
					.total_unit_area_sqm(totalUnitArea)
					.build();

			viewerLandCovers.add(viewerLandCoverDetails);

		});

		return viewerLandCovers;
	}

	private ViewerBlockDetails buildViewerBlockDetails(ParcelNTT parcel) {
		ViewerBlockDetails block = null;
		// Returns a viewer block details object.
		if (parcel.getBlock() != null) {
			block = ViewerBlockDetails.builder()
					.block_code(parcel.getBlock().getBlock())
					.description(parcel.getBlock().getDescription())
					.id(parcel.getBlock().getId())
					.sector_id(parcel.getBlock().getSector_id())
					.short_descr(parcel.getBlock().getShort_descr())
					.build();
		}
		return block;
	}

	private ViewerSectorDetails buildViewerSectorDetails(ParcelNTT parcel) {
		ViewerSectorDetails sector = null;
		// Returns the sector details for the sector.
		if (parcel.getSector() != null) {
			sector = ViewerSectorDetails.builder()
					.description(parcel.getSector().getDescription())
					.id(parcel.getSector().getId())
					.sector_code(parcel.getSector().getSector())
					.short_descr(parcel.getSector().getShort_descr())
					.build();
		}
		return sector;
	}

	/**
	* Get details of sector. It's used to get sector details from database. This method is used for viewing sectors.
	* 
	* @param env - service support environment ( tenant and code ).
	* 
	* @return Sector details ( id short_descr and description ) of sector. Exception will be thrown if sector not found
	*/
	public ViewerSectorDetails getSectorDetails(ServiceSupportEnv env) {

		SectorNTT sector = sectorDAO.findSectorDetailsByTenantAndCode(env, env.getSectorCode());
		// If sector is null throw an exception.
		if (sector == null) {
			SectorViewerNotFoundException ex = new SectorViewerNotFoundException(Status.NOT_FOUND, Operation.GET_SECTOR_VIEWER, ErrorField.SECTOR_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return ViewerSectorDetails
				.builder()
				.id(sector.getId())
				.sector_code(sector.getSector())
				.short_descr(sector.getShort_descr())
				.description(sector.getDescription())
				.build();
	}
	
	private List<VineUnitWithAptitudes> getVineUnits(ServiceSupportEnv env) {
		List<VineUnitWithAptitudes> vineUnits = vineUnitsDAO.getVineUnitsbyLandCoverIds(env, List.of(env.getLandCoverId()), 0).stream()
				.map(VineUnitMapper.INSTANCE::entityToDtoWithAptitudes)
				.collect(Collectors.toList());

		vineUnits.stream().forEach(unit -> {
			List<VineAptitude> vineAptitudes = vineUnitsDAO.getVineAptitudes(env, unit.getId(), null, 0).stream()
					.map(VineAptitudesMapper.INSTANCE::entityToDto)
					.collect(Collectors.toList());

			unit.setVineAptitudes(vineAptitudes);
		});

		return vineUnits;
	}
	
	private List<OliveUnit> getOliveUnits(ServiceSupportEnv env) {
		return oliveUnitsDAO.getOliveUnitsbyLandCoverIds(env, List.of(env.getLandCoverId()), 0).stream()
				.map(OliveUnitMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}
	
	private List<FruitUnit> getFruitUnits(ServiceSupportEnv env) {
		return fruitUnitsDAO.getFruitUnitsbyLandCoverIds(env, List.of(env.getLandCoverId()), 0).stream()
				.map(FruitUnitMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}

}
