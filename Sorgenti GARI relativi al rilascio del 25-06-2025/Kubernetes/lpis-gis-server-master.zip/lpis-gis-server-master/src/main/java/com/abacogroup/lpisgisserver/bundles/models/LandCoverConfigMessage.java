package com.abacogroup.lpisgisserver.bundles.models;

import com.abacogroup.lpisgisserver.core.enums.LandCoverConfigKeys;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LandCoverConfigMessage {
	
	@NotBlank
	private String land_cover_code;
	
	@NotBlank
	private LandCoverConfigKeys key;
	
	private String value;
}
