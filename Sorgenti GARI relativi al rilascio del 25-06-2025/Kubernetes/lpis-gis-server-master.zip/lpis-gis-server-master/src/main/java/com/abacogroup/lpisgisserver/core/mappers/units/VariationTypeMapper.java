package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.VariationTypeNTT;
import com.abacogroup.lpisgisserver.resources.res.units.VariationType;

@Mapper
public interface VariationTypeMapper {

	VariationTypeMapper INSTANCE = Mappers.getMapper(VariationTypeMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	VariationType entityToDto(VariationTypeNTT entity);
	
	@Mapping(target = "flVisible", expression = "java(dto.getVisible() ? 1 : 0)")
	@Mapping(target = "typeCode", ignore = true)
	VariationTypeNTT dtoToEntity(VariationType dto);
}
