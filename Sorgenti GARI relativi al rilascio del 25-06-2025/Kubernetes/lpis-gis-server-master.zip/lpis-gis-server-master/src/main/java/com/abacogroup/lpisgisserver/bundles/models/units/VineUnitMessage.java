package com.abacogroup.lpisgisserver.bundles.models.units;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VineUnitMessage {
	
	private List<UnitFarmingFormMessage> farming_forms;
	private List<UnitCultivationStatusMessage> cultivation_status;
	private List<UnitHeaderAnchoringMessage> header_anchoring_codes;
	private List<UnitIrrigationTypeMessage> irrigation_types;
	private List<UnitPolesHeaderMessage> poles_header_codes ;
	private List<UnitPolesWeavingMessage> poles_weaving_codes;
	private List<UnitProductDestinationMessage> product_destination_codes;
	private List<UnitSupportWiresMessage> support_wires_codes;
	private List<UnitTerracingMessage> terracing_codes;
	private List<UnitVariationTypeMessage> variation_types;
	private List<UnitVarietyMessage> variety_codes;
	private List<UnitVineDoigtMessage> vine_doigt_codes;
	private List<UnitVineyardMessage> vineyard_codes;
	
}