package com.abacogroup.lpisgisserver.bundles;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.models.CodeMessage;
import com.abacogroup.lpisgisserver.bundles.models.CodeMessageList;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.I18nDAO;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.ntt.I18nNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

public abstract class AbstractCodeMessageProcessor implements ConfigMessageProcessor {

	protected I18nDAO i18nDAO;
	protected SupportDAO supportDAO;

	private final ObjectMapper objectMapper;
	private static final Logger log = LoggerFactory.getLogger(AbstractCodeMessageProcessor.class);
	
	private static final String FOR_TENANT = " for tenant ";

	protected AbstractCodeMessageProcessor(DAOContainer dc) {
		this.i18nDAO = dc.getI18nDAO();
		this.supportDAO = dc.getSupportDAO();

		objectMapper = new ObjectMapper();
	}

	protected abstract String getFieldName();

	protected abstract String getTableName();

	protected abstract void checkCode(String tenantId, String code);

	protected abstract void deleteCode(String tenantId, String code);

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
				.forEach(file -> processDeleteFile(message.getTenantId(), file));

		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
						&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
				.forEach(file -> processFile(message.getTenantId(), file));
	}

	protected void processDeleteFile(String tenantId, File file) {
		try {
			CodeMessageList codesMessages = objectMapper.readValue(file, CodeMessageList.class);

			if (codesMessages == null || codesMessages.getCodesList() == null || codesMessages.getCodesList().isEmpty()) {
				return;
			}

			doDelete(tenantId, codesMessages.getCodesList());

		} catch (Exception e) {
			log.error("Error processing delete file " + file.getName() + FOR_TENANT + tenantId, e);
		}
	}

	protected void processFile(String tenantId, File file) {
		try {
			CodeMessageList codesMessages = objectMapper.readValue(file, CodeMessageList.class);

			if (codesMessages == null || codesMessages.getCodesList() == null || codesMessages.getCodesList().isEmpty()) {
				return;
			}

			doInsertOrUpdate(tenantId, codesMessages.getCodesList());

		} catch (Exception e) {
			log.error("Error processing file " + file.getName() + FOR_TENANT + tenantId, e);
		}
	}

	protected void doInsertOrUpdate(String tenantId, List<CodeMessage> codesMessages) {
		codesMessages.forEach(codeMsg -> {
			try {

				if (codeMsg.getDescriptions() == null || codeMsg.getDescriptions().isEmpty()) {
					throw new IllegalStateException("Code " + codeMsg.getCode() + " not have descriptions!");
				}

				checkCode(tenantId, codeMsg.getCode());

				codeMsg.getDescriptions().forEach((lang, description) -> {
					try {
						if (StringUtils.isBlank(description)) {
							throw new IllegalStateException("Code " + codeMsg.getCode() + " for lang " + lang + " not have description!");
						}

						I18nNTT i18n = I18nNTT.builder()
								.tenant_id(tenantId)
								.field_name(getFieldName())
								.table_name(getTableName())
								.lang(lang)
								.i18n_value(codeMsg.getCode())
								.i18n_text(description)
								.build();

						I18nNTT toUpdate = i18nDAO.findI18nByLpisI18nKeys(i18n);
						if (toUpdate == null) {
							i18nDAO.insert(i18n);
						} else if (!toUpdate.getI18n_text().equals(description)) {
							i18nDAO.updateI18nText(i18n);
						}
					} catch (Exception e) {
						log.error("Error processing code " + codeMsg.getCode() + " with lang " + lang + FOR_TENANT + tenantId, e);
					}
				});
			} catch (Exception e) {
				log.error("Error processing code " + codeMsg.getCode() + FOR_TENANT + tenantId, e);
			}
		});
	}

	protected void doDelete(String tenantId, List<CodeMessage> codesMessages) {
		codesMessages.forEach(codeMsg -> {
			try {

				deleteCode(tenantId, codeMsg.getCode());

				I18nNTT i18n = I18nNTT.builder()
						.tenant_id(tenantId)
						.field_name(getFieldName())
						.table_name(getTableName())
						.i18n_value(codeMsg.getCode())
						.build();

				i18nDAO.deleteAllI18n(i18n);

			} catch (Exception e) {
				log.error("Error deleting code " + codeMsg.getCode() + FOR_TENANT + tenantId, e);
			}
		});
	}
}
