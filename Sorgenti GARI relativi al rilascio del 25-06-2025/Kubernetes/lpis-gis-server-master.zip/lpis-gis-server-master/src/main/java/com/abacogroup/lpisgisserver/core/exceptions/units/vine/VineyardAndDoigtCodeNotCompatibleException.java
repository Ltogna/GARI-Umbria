package com.abacogroup.lpisgisserver.core.exceptions.units.vine;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class VineyardAndDoigtCodeNotCompatibleException extends AbstractException {

	private static final long serialVersionUID = -6032858346201987623L;
	private static final ErrorCode ERROR_CODE = ErrorCode.VINEYARD_AND_DOIGT_CODE_NOT_COMPATIBLE;

	public VineyardAndDoigtCodeNotCompatibleException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new VineyardAndDoigtCodeNotCompatibleExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "vineyard code not compatile with aptitude doigt")
	public static class VineyardAndDoigtCodeNotCompatibleExceptionBody extends AbstractExceptionBody {

		private static final long serialVersionUID = 7960568596917122534L;

		public VineyardAndDoigtCodeNotCompatibleExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
