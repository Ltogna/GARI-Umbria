package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.ProtectionStructureNTT;
import com.abacogroup.lpisgisserver.resources.res.units.ProtectionStructure;

@Mapper
public interface ProtectionStructureMapper {

	ProtectionStructureMapper INSTANCE = Mappers.getMapper(ProtectionStructureMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	ProtectionStructure entityToDto(ProtectionStructureNTT entity);
	
	@Mapping(target = "flVisible", expression = "java(dto.getVisible() ? 1 : 0)")
	@Mapping(target = "typeCode", ignore = true)
	ProtectionStructureNTT dtoToEntity(ProtectionStructure dto);
}
