package com.abacogroup.lpisgisserver.core.models.session;

import java.util.List;

import org.locationtech.jts.geom.Geometry;

import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.resources.res.LandCoverWithUnits;
import com.abacogroup.lpisgisserver.resources.res.Parcel;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BuildSessionPreviewParcelLandCovers {
	private List<ParcelNTT> intersectedParcels;
	private List<LandCoverWithUnits> sessionLandCovers;
	private List<Parcel> sessionParcels;
	private Geometry lockGeometry;
	private String lockGeometrySrs;
}
