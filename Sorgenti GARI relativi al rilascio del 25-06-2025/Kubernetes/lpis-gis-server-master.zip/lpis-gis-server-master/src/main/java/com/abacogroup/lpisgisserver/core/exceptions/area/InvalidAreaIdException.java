package com.abacogroup.lpisgisserver.core.exceptions.area;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidAreaIdException extends AbstractException {

	private static final long serialVersionUID = 9208811155083134204L;

	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_AREA_ID;

	public InvalidAreaIdException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new InvalidAreaIdExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Area Id not valid")
	public static class InvalidAreaIdExceptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = 7363028912761661296L;

		public InvalidAreaIdExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
