package com.abacogroup.lpisgisserver.core.pub;

import java.util.List;
import java.util.stream.Collectors;

import com.abacogroup.lpisgisserver.core.BaseService;
import com.abacogroup.lpisgisserver.core.ErrorDescriptionsService;
import com.abacogroup.lpisgisserver.core.ExternalConfigService;
import com.abacogroup.lpisgisserver.core.InternalConfigService;
import com.abacogroup.lpisgisserver.core.StyleService;
import com.abacogroup.lpisgisserver.core.VineUnitsService;
import com.abacogroup.lpisgisserver.core.mappers.pub.VineAptitudesV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.VineUnitV1Mapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.pub.units.vine.VineAptitudesV1;
import com.abacogroup.lpisgisserver.resources.res.pub.units.vine.VineUnitWithAptitudesV1;

public class VineUnitsV1Service extends BaseService {

	private VineUnitsService vineUnitsService;

	public VineUnitsV1Service(DAOContainer dc, VineUnitsService vineUnitsService, InternalConfigService conf, ExternalConfigService externalConf, 
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, 
			PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.vineUnitsService = vineUnitsService;
		
	}

	public VineUnitWithAptitudesV1 getVineUnitById(ServiceSupportEnv env, Long vineUnitId) {
		return VineUnitV1Mapper.INSTANCE.toResponseV1(vineUnitsService.getVineUnitById(env, vineUnitId));
	}
	
	public List<VineAptitudesV1> getVineAptitudesByUnitId(ServiceSupportEnv env, Long vineUnitId, Long vineAptitudeId, Boolean showOutdatedUnits) {
		return vineUnitsService.getVineAptitudesByUnitId(env, vineUnitId, vineAptitudeId, showOutdatedUnits).stream()
				.map(VineAptitudesV1Mapper.INSTANCE::toResponseV1)
				.collect(Collectors.toList());
	}
	
}
