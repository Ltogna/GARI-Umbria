package com.abacogroup.lpisgisserver.core.pub;

import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lpisgisserver.core.BaseService;
import com.abacogroup.lpisgisserver.core.ErrorDescriptionsService;
import com.abacogroup.lpisgisserver.core.ExternalConfigService;
import com.abacogroup.lpisgisserver.core.InternalConfigService;
import com.abacogroup.lpisgisserver.core.StyleService;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.UnitDictionaryTables;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.support.InvalidUserFavouriteFieldsException;
import com.abacogroup.lpisgisserver.core.mappers.pub.LandCoversCodeV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.LandUsesCodeV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.units.UnitCodeV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.units.DoigtMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.ntt.UserFavouriteFieldsNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.ResourceConstants;
import com.abacogroup.lpisgisserver.resources.req.GetDoIgtCodesByCodesPayload;
import com.abacogroup.lpisgisserver.resources.req.pub.PublicGetVineUnitsCodeListPayload;
import com.abacogroup.lpisgisserver.resources.req.pub.PublicUserFavouriteFieldPayload;
import com.abacogroup.lpisgisserver.resources.res.pub.LandCoverCodeV1List;
import com.abacogroup.lpisgisserver.resources.res.pub.LandCoversCodeV1;
import com.abacogroup.lpisgisserver.resources.res.pub.LandUsesCodeV1;
import com.abacogroup.lpisgisserver.resources.res.pub.LandUsesCodeV1List;
import com.abacogroup.lpisgisserver.resources.res.pub.units.UnitCodeV1;
import com.abacogroup.lpisgisserver.resources.res.pub.units.UnitCodeV1List;
import com.abacogroup.lpisgisserver.resources.res.units.vine.DoIgtList;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class PublicSupportService extends BaseService {

	private SupportDAO supportDAO;

	private static final int CODE_LIST_DEFAULT_RESULT_NUMBER = 20;

	public PublicSupportService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);
		this.supportDAO = dc.getSupportDAO();
	}



	/**
	 * Returns a list of land covers codes for a given tenant. This method is for use by applications that want to know which ones are available for the given tenancy
	 * 
	 * @param tenantId - the id of the tenant
	 * @param lang - the language of the land covers codes e. g.
	 * @param filter - the filter to apply to the search
	 * @param nextKey - the key to use when paginating results
	 * @param pageSize - the number of results to return in a single page
	 * @param includeEmptyDescr - whether to include empty description in the result
	 * 
	 * @return an InfiniteListResults containing the results of the LandCoversCodesV1 search. If there are no results null is returned
	 */
	public InfiniteListResults<LandCoversCodeV1> getLandCoversCodes(String tenantId, String lang, String filter, String nextKey, Integer pageSize, Integer includeEmptyDescr) {

		// Sets the pageSize to the default result number.
		if(pageSize == null || pageSize < 1)
			pageSize = CODE_LIST_DEFAULT_RESULT_NUMBER;

		InfiniteListResults<LandCoversCodeV1> result = this.supportDAO.infinite(() -> supportDAO.findLandCoversCodes(tenantId, lang, filter, includeEmptyDescr),
				nextKey,
				pageSize)
				.map(LandCoversCodeV1Mapper.INSTANCE::entityToDto);

		result.getRecords().stream().forEach(code -> code.setUnit_types(supportDAO.getCompatibleUnitTypesByLandCoverCode(tenantId, code.getLand_cover_code())));

		return result;
	}

	/**
	 * Get land covers codes by list of land cover codes. This method is used for creating list of LandCoverCodeV1 objects
	 * 
	 * @param tenantId - Tenant identifier for which to search
	 * @param lang - Language of the land covers
	 * @param landCoverCodes - List of land covers codes to search
	 * 
	 * @return List of LandCoverCodeV1 objects
	 */
	public LandCoverCodeV1List getLandCoverCodesByList(String tenantId, String lang, List<String> landCoverCodes) {
		Criteria landCoversCriteria = buildCodesCriteria(tenantId, landCoverCodes);

		List<LandCoversCodeV1> landCovers = supportDAO.getLandCoversCodesByTenantAndCodes(tenantId, lang, landCoversCriteria).stream()
				.map(LandCoversCodeV1Mapper.INSTANCE::entityToDto).collect(toList());

		landCovers.stream().forEach(code -> code.setUnit_types(supportDAO.getCompatibleUnitTypesByLandCoverCode(tenantId, code.getLand_cover_code())));

		return LandCoverCodeV1List.builder().land_covers_codes_list(landCovers).build();
	}

	/**
	 * Get land uses codes. This method is used for search by tenant id and language. The result is paginated
	 * 
	 * @param tenantId - the tenant id to search
	 * @param lang - the language of the search
	 * @param filter - the search filter. See #getFilter ( String ) for more details
	 * @param nextKey - the key of the next page
	 * @param pageSize - the number of results to
	 * @param includeEmptyDescr
	 */
	public InfiniteListResults<LandUsesCodeV1> getLandUsesCodes(String tenantId, String lang, String filter, String nextKey, Integer pageSize, Integer includeEmptyDescr) {

		// Sets the pageSize to the default result number.
		if(pageSize == null || pageSize < 1)
			pageSize = CODE_LIST_DEFAULT_RESULT_NUMBER;

		return this.supportDAO.infinite(() -> supportDAO.findLandUsesCodes(tenantId, lang, filter, includeEmptyDescr),
				nextKey,
				pageSize)
				.map(LandUsesCodeV1Mapper.INSTANCE::entityToDto);
	}

	/**
	 * Get a list of land uses codes by tenant and language. This method is used by LandUseV1.
	 * 
	 * @param tenantId - Tenant id to filter by. Null if not needed.
	 * @param lang - Language to filter by. Null if not needed.
	 * @param landUseCodes - List of land use codes to filter by. Null if not needed.
	 * 
	 * @return List of land uses codes matching the criteria. Null if none found or not found in the database. The list is sorted by decreasing number of entries
	 */
	public LandUsesCodeV1List getLandUsesCodesByList(String tenantId, String lang, List<String> landUseCodes) {
		Criteria landUsesCriteria = buildCodesCriteria(tenantId, landUseCodes);

		List<LandUsesCodeV1> landUses = supportDAO.getLandUsesCodesByTenantAndCodes(tenantId, lang, landUsesCriteria).stream()
				.map(LandUsesCodeV1Mapper.INSTANCE::entityToDto).collect(toList());

		return LandUsesCodeV1List.builder().land_uses_codes_list(landUses).build();
	}

	/**
	 * Builds criteria to filter results by tenant. This is used for filtering results based on codes that are associated with a tenant
	 * 
	 * @param tenantId - tenant id for which we are interested in results
	 * @param codes - list of codes to filter results by if null or empty all results are returned
	 * 
	 * @return a Criteria object that can be used to filter results based on tenant id and / or codes that are associated with a
	 */
	private Criteria buildCodesCriteria(String tenantId, List<String> codes) {
		List<Criteria> criterias = new ArrayList<>();
		criterias.add(CriteriaBuilder.string("tenant_id").eq(tenantId));

		// Add a code to the list of codes.
		if (codes != null && !codes.isEmpty()) {
			criterias.add(CriteriaBuilder.string("code").in(codes));
		}

		return CriteriaBuilder.and(criterias.toArray(new Criteria[0]));
	}

	/**
	 * Inserts a new user favourite field. Note : This method is used to insert a new field in the support table.
	 * 
	 * @param env - The service support environment. Cannot be null.
	 * @param payload - The data that contains the field name and value.
	 * 
	 * @return A 204 No Content response if the operation was successful. A 400 Bad Request if the request is invalid
	 */
	public Response insertUserFavouriteField(ServiceSupportEnv env, PublicUserFavouriteFieldPayload payload) {

		// If the payload is blank or empty throw an InvalidUserFavouriteFieldsException.
		if (StringUtils.isBlank(payload.getField()) || StringUtils.isBlank(payload.getValue())) {
			throw new InvalidUserFavouriteFieldsException(Status.BAD_REQUEST, Operation.INSERT_USER_FAVOURITE_FIELDS, ErrorField.USER_FIELD,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		supportDAO.insert(
				UserFavouriteFieldsNTT.builder()
				.field_name(payload.getField())
				.field_value(payload.getValue())
				.tenant_id(env.getTenantId())
				.user_id(env.getUserId())
				.build());

		return Response.noContent().build();
	}

	/**
	 * Delete a favourite field. This is a soft delete so you don't have to worry about it being in the database.
	 * 
	 * @param env - The environment for the request. It's important to know the tenant and user that this request came from.
	 * @param fieldName - The field name to delete. If this is null or empty the field will be deleted from the database.
	 * @param fieldValue - The field value to delete. If this is null or empty the field will be deleted from the database.
	 * 
	 * @return A 204 No Content response indicating success or failure. The response will contain the ID of the field that was deleted
	 */
	public Response deleteUserFavouriteField(ServiceSupportEnv env, String fieldName, String fieldValue) {

		supportDAO.delete(
				UserFavouriteFieldsNTT.builder()
				.field_name(fieldName)
				.field_value(fieldValue)
				.tenant_id(env.getTenantId())
				.user_id(env.getUserId())
				.build());

		return Response.noContent().build();
	}

	public InfiniteListResults<UnitCodeV1> getVineUnitsCode(ServiceSupportEnv env, UnitType unitType, UnitDictionaryTables unitTable, String filter,
			Integer includeEmptyDescr) {
		return this.supportDAO.infinite(
				() -> supportDAO.getUnitCodeByTenantTableNameTypeCode(env, unitType, unitTable.getTableName(), filter, includeEmptyDescr, 1),
				env.getNextKey(),
				env.getPageSize())
				.map(UnitCodeV1Mapper.INSTANCE::entityToDto);
	}

	public UnitCodeV1List getVineUnitsCodeList(ServiceSupportEnv env, UnitType unitType, UnitDictionaryTables unitTable,
			@NotNull PublicGetVineUnitsCodeListPayload payload) {
		UnitCodeV1List result = UnitCodeV1List
				.builder()
				.unit_code_list(new ArrayList<>())
				.build();

		if (payload.getVine_unite_codes() != null && !payload.getVine_unite_codes().isEmpty()) {
			List<UnitCodeV1> unitCodes = supportDAO
					.getUnitCodeByTenantTableNameTypeCodeAndUnitCodes(env, unitType, unitTable.getTableName(), payload.getVine_unite_codes(), 1).stream()
					.map(UnitCodeV1Mapper.INSTANCE::entityToDto).collect(Collectors.toList());

			result.setUnit_code_list(unitCodes);
		}

		return result;
	}
	
	public DoIgtList getDoigtCodesByCodes(ServiceSupportEnv env, Integer includeEmptyDescr,  Boolean onlyVisible, @Valid GetDoIgtCodesByCodesPayload payload) {
		
		return DoIgtList.builder()
				.doIgt_list(
						supportDAO.getDoigtCodesByCodes(env, includeEmptyDescr, boolToInt(onlyVisible) , payload.getCodes())
						.stream()
						.map(DoigtMapper.INSTANCE::entityToDto)
						.collect(Collectors.toList()))
				.build();
	}
}
