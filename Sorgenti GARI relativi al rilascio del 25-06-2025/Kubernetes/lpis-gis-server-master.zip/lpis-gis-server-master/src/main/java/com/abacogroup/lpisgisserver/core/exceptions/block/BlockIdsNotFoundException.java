package com.abacogroup.lpisgisserver.core.exceptions.block;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class BlockIdsNotFoundException extends AbstractException {

	private static final long serialVersionUID = 8840221609459587609L;

	private static final ErrorCode ERROR_CODE = ErrorCode.BLOCK_IDS_NOT_FOUND;

	public BlockIdsNotFoundException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new BlockIdsNotFoundExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Requested block not found")
	public static class BlockIdsNotFoundExceptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = -3638420946312054856L;

		public BlockIdsNotFoundExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
