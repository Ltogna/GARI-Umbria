package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.BlockNTT;
import com.abacogroup.lpisgisserver.resources.res.Block;

@Mapper
public interface BlockMapper {
	BlockMapper INSTANCE = Mappers.getMapper(BlockMapper.class);
	
	@Mapping(target = "block_code", source = "block")
	Block entityToDto(BlockNTT entity);
	
	@Mapping(target = "block", source = "block_code")
	@Mapping(target = "block_details_id", ignore = true)
	BlockNTT dtoToEntity(Block dto);
}