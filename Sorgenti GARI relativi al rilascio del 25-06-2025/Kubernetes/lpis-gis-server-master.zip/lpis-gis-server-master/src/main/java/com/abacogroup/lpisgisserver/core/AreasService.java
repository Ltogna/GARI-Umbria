package com.abacogroup.lpisgisserver.core;

import java.util.ArrayList;
import java.util.List;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.area.InvalidAreaIdException;
import com.abacogroup.lpisgisserver.core.mappers.AreasMapper;
import com.abacogroup.lpisgisserver.core.mappers.SectorMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.AreasDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.SectorAreasDAO;
import com.abacogroup.lpisgisserver.db.ntt.AreaNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.Area;
import com.abacogroup.lpisgisserver.resources.res.Sector;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AreasService extends BaseService {

	private final AreasDAO areasDAO;
	private final SectorAreasDAO sectorAreasDAO;

	public AreasService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService,
			StyleService styleService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.areasDAO = dc.getAreasDAO();
		this.sectorAreasDAO = dc.getSectorAreasDAO();

	}

	/**
	* Search areas by tenant. This is a convenience method for performing a search by tenant and filtering the results with a list of area filters
	* 
	* @param env - service support environment to search
	* @param areaFilters - list of filters to use when searching for areas
	* @param level - search level. Must be one of " sub " " user " or " user_group "
	* @param nextKey - key to start the search at. If null the first page will be used
	* 
	* @return infinite list of areas
	*/
	public InfiniteListResults<Area> searchAreas(ServiceSupportEnv env, List<String> areaFilters, String level, String areaCode) {

		List<Criteria> criterias = new ArrayList<>();
		
		if(areaCode != null) {
			AreaNTT areaCodeData = areasDAO.findAreasByCriterias(env, CriteriaBuilder.string("code").eq(areaCode)).stream().findFirst().orElse(null);
			if(areaCodeData != null) {
				criterias.add(CriteriaBuilder.string(areaCodeData.getLevel_code().toLowerCase()+".code").eq(areaCode));
			}
		}
		
		if (areaFilters != null) {
			areaFilters.stream().filter(s -> s != null && !s.isBlank() && s.split("\\:", 2).length == 2).forEach(s -> {
				String levelFilter = s.split("\\:", 2)[0];
				String descriptionFilter = s.split("\\:", 2)[1];
				criterias.add(CriteriaBuilder.string(levelFilter.toLowerCase() + ".description").caseInsensitiveContains(descriptionFilter));
			});
		}
		
		Criteria criteria = criterias.isEmpty() ? CriteriaBuilder.number("1").eq(1) : CriteriaBuilder.and(criterias.toArray(new Criteria[0]));
		
		return this.areasDAO.infinite(
				() -> areasDAO.infiniteSearchAreasByCriterias(env, criteria, level),
				env.getNextKey(),
				env.getPageSize())
				.map(AreasMapper.INSTANCE::entityToDto);

	}

	/**
	* Retrieves an area by its id. If the area doesn't exist a Not Found exception is thrown
	* 
	* @param env - service support environment for obtaining tenant id
	* @param areaId - id of the area to retrieve. It's mandatory to be non - null
	* 
	* @return area corresponding to the id or null if not found ( status NOT_FOUND ) in which case an InvalidAreaIdException is
	*/
	public Area getByCode(ServiceSupportEnv env, String areaCode) {
		AreaNTT area = areasDAO.findAreasByCriterias(env, CriteriaBuilder.string("code").eq(areaCode))
				.stream()
				.findFirst()
				.orElse(null);

		// Returns the area id if area is null.
		if (area == null) {
			InvalidAreaIdException ex = new InvalidAreaIdException(Status.NOT_FOUND, Operation.GET_AREA, ErrorField.AREA_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return AreasMapper.INSTANCE.entityToDto(area);
	}

	public InfiniteListResults<Sector> getSectorsByAreaCode(ServiceSupportEnv env, String areaCode) {
		Area area = getByCode(env, areaCode);
		return sectorAreasDAO.infinite(
				() -> sectorAreasDAO.findSectorsByAreaId(env, area.getArea_id()),
				env.getNextKey(),
				env.getPageSize())
				.map(SectorMapper.INSTANCE::entityToDto);
	}

}
