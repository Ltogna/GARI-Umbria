package com.abacogroup.lpisgisserver.core.models.cll.api.v1;

import java.util.ArrayList;
import java.util.List;

import org.jdbi.v3.core.mapper.Nested;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
public class ParcelResV1 {
	private Long id;

	private String parcel;

	private AbsoluteDate dayFrom;

	private AbsoluteDate dayTo;

	private String srs;

	@Default
	private Long areaSqm = 0L;

	@Nested("block")
	private BlockResV1 block;

	@Nested("sector")
	private SectorResV1 sector;
	
	private Geometry geom;

	private Geometry worldGeom;

	@Builder.Default()
	private List<LandCoverResV1> landcoversList = new ArrayList<>();

}