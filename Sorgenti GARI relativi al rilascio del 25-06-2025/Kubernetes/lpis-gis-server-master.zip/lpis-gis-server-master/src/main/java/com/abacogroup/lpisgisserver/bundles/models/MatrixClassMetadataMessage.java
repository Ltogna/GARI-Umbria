package com.abacogroup.lpisgisserver.bundles.models;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class MatrixClassMetadataMessage {
	private String class_code;
	private String key;
	private String value;
	private AbsoluteDate day_from;
	private AbsoluteDate day_to;
}
