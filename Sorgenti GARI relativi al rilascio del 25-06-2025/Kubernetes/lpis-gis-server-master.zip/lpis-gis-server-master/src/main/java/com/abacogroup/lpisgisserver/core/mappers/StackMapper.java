package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.EditCategoryMapper;
import com.abacogroup.lpisgisserver.db.ntt.StacksNTT;
import com.abacogroup.lpisgisserver.resources.res.Stack;

@Mapper(uses = { AbsoluteDateMapper.class, EditCategoryMapper.class })
public interface StackMapper {

	StackMapper INSTANCE = Mappers.getMapper(StackMapper.class);

	@Mapping(source = "edit_category", target = "editCategory")
	@Mapping(target = "campaign", ignore = true)
	Stack entityToDto(StacksNTT entity);

	@Mapping(source = "editCategory", target = "edit_category")
	@Mapping(target = "tenant_id", ignore = true)
	StacksNTT dtoToEntity(Stack dto);
}
