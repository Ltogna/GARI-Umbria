package com.abacogroup.lpisgisserver.core.enums;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "The level of anomaly")
public enum AnomalyLevel {
	DANGER,
	WARN,
	INFO,
	UNCATEGORIZED
}
