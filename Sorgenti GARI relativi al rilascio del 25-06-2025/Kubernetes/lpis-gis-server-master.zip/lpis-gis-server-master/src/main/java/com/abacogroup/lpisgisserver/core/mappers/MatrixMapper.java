package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.MatrixNTT;
import com.abacogroup.lpisgisserver.resources.res.pub.MatrixV1;

@Mapper
public interface MatrixMapper {

	MatrixMapper INSTANCE = Mappers.getMapper(MatrixMapper.class);
	
	@Mapping(target = "matrix_class_list", ignore = true)
	MatrixV1 entityToDto(MatrixNTT entity);
	
	@Mapping(target = "tenant_id", ignore = true)
	MatrixNTT dtoToEntity(MatrixV1 dto);
}
