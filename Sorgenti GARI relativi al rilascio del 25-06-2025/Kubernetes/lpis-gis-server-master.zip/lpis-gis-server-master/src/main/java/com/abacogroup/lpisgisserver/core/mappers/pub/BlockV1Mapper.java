package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.BlockNTT;
import com.abacogroup.lpisgisserver.resources.res.Block;
import com.abacogroup.lpisgisserver.resources.res.pub.BlockV1;

@Mapper
public interface BlockV1Mapper {

	BlockV1Mapper INSTANCE = Mappers.getMapper(BlockV1Mapper.class);

	@InheritInverseConfiguration
	BlockV1 toResponseV1(Block entity);

	@InheritInverseConfiguration
	@Mapping(source = "block", target = "block_code")
	BlockV1 toResponseV1(BlockNTT entity);
	
}
