package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidSessionParcelIdException extends AbstractException {

	private static final long serialVersionUID = 1508621547382490267L;

	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_SESSION_PARCEL_ID;

	public InvalidSessionParcelIdException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new InvalidSessionParcelIdExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Parcel id not defined")
	public static class InvalidSessionParcelIdExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -2552668162758354468L;

		public InvalidSessionParcelIdExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
