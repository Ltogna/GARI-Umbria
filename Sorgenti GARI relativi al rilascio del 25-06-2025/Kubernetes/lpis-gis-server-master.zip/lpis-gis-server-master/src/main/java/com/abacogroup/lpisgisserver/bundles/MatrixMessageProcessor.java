package com.abacogroup.lpisgisserver.bundles;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.bundles.models.MatrixClassMessage;
import com.abacogroup.lpisgisserver.bundles.models.MatrixListMessage;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassDetailsDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassLandUsesDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassLandcoversDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixCompatDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoversCodeNTT;
import com.abacogroup.lpisgisserver.db.ntt.LandUsesCodeNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassLandcoversNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassLandusesNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassesNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixCompatNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MatrixMessageProcessor extends AbstractMessageProcessor {
	private final ObjectMapper objectMapper;

	private MatrixDAO matrixDAO;
	private MatrixClassDAO matrixClassDAO;
	private MatrixClassDetailsDAO matrixClassDetailsDAO;
	private MatrixClassLandcoversDAO matrixClassLandcoversDAO;
	private MatrixClassLandUsesDAO matrixClassLandUsesDAO;
	private MatrixCompatDAO matrixCompatDAO;

	private static final String USER = "importMatrixBundle";
	private static final String TENANT_MASTER = "master";
	private static final String LANG_EN = "en";

	private static final Logger log = LoggerFactory.getLogger(MatrixMessageProcessor.class);

	public MatrixMessageProcessor(DAOContainer daoContainer) {
		super(daoContainer);
		objectMapper = new ObjectMapper();

		matrixDAO = daoContainer.getMatrixDAO();
		matrixClassDAO = daoContainer.getMatrixClassDAO();
		matrixClassDetailsDAO = daoContainer.getMatrixClassDetailsDAO();
		matrixClassLandcoversDAO = daoContainer.getMatrixClassLandcoversDAO();
		matrixClassLandUsesDAO = daoContainer.getMatrixClassLandUsesDAO();
		matrixCompatDAO = daoContainer.getMatrixCompatDAO();
	}

	@Override
	public String getDomainName() {
		return "matrixes";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> deleteMatrixesMessage(message.getTenantId(), file));
		
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
						&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
				.forEach(file -> insertOrUpdateMatrixesMessage(message.getTenantId(), file));
	}

	private void deleteMatrixesMessage(String tenantId, File file) {
		try {
			MatrixListMessage matrixList = objectMapper.readValue(file, MatrixListMessage.class);

			if (matrixList != null && matrixList.getMatrixes() != null) {
				ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).user(new User(USER, tenantId)).build();

				matrixList.getMatrixes().forEach(matrixMsg -> {
					try {

						List<MatrixNTT> matrix = matrixDAO.findByCode(env, matrixMsg.getCode());
						if (!matrix.isEmpty()) {
							matrixDAO.deleteById(matrix.get(0).getId());
						}

					} catch (Exception e) {
						log.error("Error during delete operation of matrix {} with tenant {} : {}", matrixMsg.getCode(), tenantId, e);
					}
				});
			}
		} catch (Exception e) {
			log.error("Error processing delete file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}
	}

	private void insertOrUpdateMatrixesMessage(String tenantId, File file) {
		try {
			MatrixListMessage matrixList = objectMapper.readValue(file, MatrixListMessage.class);

			if (matrixList != null && matrixList.getMatrixes() != null) {
				ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).user(new User(USER, tenantId)).build();

				matrixList.getMatrixes().forEach(matrixMsg -> {
					try {

						List<MatrixNTT> matrix = matrixDAO.findByCode(env, matrixMsg.getCode());
						Long matrixId = null;
						if (matrix.isEmpty()) {
							MatrixNTT matrixToInsert = MatrixNTT.builder()
									.id(matrixDAO.nextSequenceVal())
									.tenant_id(tenantId)
									.code(matrixMsg.getCode())
									.build();

							matrixDAO.insert(matrixToInsert);

							matrixId = matrixToInsert.getId();
						} else {
							matrixId = matrix.get(0).getId();
						}

						insertOrUpdateMatrixClasses(matrixId, matrixMsg.getClasses());

					} catch (Exception e) {
						log.error("Error during insert/update operation of matrix {} with tenant {} : {}", matrixMsg.getCode(), tenantId, e);
					}
				});
			}
		} catch (Exception e) {
			log.error("Error processing file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}
	}

	private void insertOrUpdateMatrixClasses(Long matrixId, List<MatrixClassMessage> classes) {
		if (classes != null) {
			for (MatrixClassMessage classMsg : classes) {
				try {
					MatrixClassesNTT matrixClassMsg = MatrixClassesNTT.builder().code(classMsg.getCode()).matrix_id(matrixId).build();
					if (matrixClassDAO.findByIdAndCode(matrixId, classMsg.getCode()) == null) {
						matrixClassDAO.insert(matrixClassMsg);
					}

					insertOrUpdateMatrixClassDetails(matrixId, classMsg);

					insertOrUpdateMatrixClassLandCovers(matrixId, classMsg);

					insertOrUpdateMatrixClassLandUses(matrixId, classMsg);

					insertOrUpdateMatrixCompat(matrixId, classMsg);

				} catch (Exception e) {
					log.error("Error during insert/update operation of matrix class {} with matrix id {} : {}", classMsg.getCode(), matrixId, e);
				}
			}
		}

	}

	private void insertOrUpdateMatrixClassDetails(Long matrixId, MatrixClassMessage classMsg) {
		try {
			MatrixClassDetailsNTT matrixClassDetailsMessage = MatrixClassDetailsNTT.builder()
					.class_code(classMsg.getCode())
					.day_from(classMsg.getDay_from())
					.day_to(classMsg.getDay_to())
					.default_land_cover_code(classMsg.getDefault_land_cover_code())
					.default_land_use_code(classMsg.getDefault_land_use_code())
					.fill_rgba(classMsg.getFill_rgba())
					.line_rgba(classMsg.getLine_rgba())
					.line_thick(classMsg.getLine_thick().longValue())
					.matrix_id(matrixId)
					.user_id_insert(USER)
					.build();
			
			ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(TENANT_MASTER).user(new User(USER, TENANT_MASTER)).lang(LANG_EN).build();

			List<MatrixClassDetailsNTT> matrixClassDetails = matrixClassDetailsDAO.findByMatrixIdAndClassCode(env, matrixId, classMsg.getCode());

			if (!matrixClassDetails.isEmpty()) {
				matrixClassDetailsDAO.logicallyDeleteByMatrixIdAndClassCode(matrixId, classMsg.getCode(), USER);
			}

			matrixClassDetailsDAO.insert(matrixClassDetailsMessage, USER);

		} catch (Exception e) {
			log.error("Error during insert/update operation of matrix class details with code {} and matrix id {} : {}", classMsg.getCode(), matrixId, e);
		}
	}

	private void insertOrUpdateMatrixClassLandCovers(Long matrixId, MatrixClassMessage classMsg) {
		if (classMsg.getLand_cover_codes() != null) {
			classMsg.getLand_cover_codes().forEach(landCover -> {
				try {
					AbsoluteDate dayFrom = landCover.getDay_from() != null ? landCover.getDay_from() : classMsg.getDay_from();
					AbsoluteDate dayTo = landCover.getDay_to() != null ? landCover.getDay_to() : classMsg.getDay_to();
					
					ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(TENANT_MASTER).user(new User(USER, TENANT_MASTER)).lang(LANG_EN).build();
					
					MatrixClassLandcoversNTT matrixClassLandCoverMsg = MatrixClassLandcoversNTT.builder()
							.class_code(classMsg.getCode())
							.day_from(dayFrom)
							.day_to(dayTo)
							.landcover(LandCoversCodeNTT.builder().code(landCover.getCode()).build())
							.matrix_id(matrixId)
							.user_id_insert(USER)
							.build();

					// A landcover can be in only one class per matrix, so if it is in any other class, or the same one, it must be "deleted"
					MatrixClassLandcoversNTT matrixClassLandCover = matrixClassLandcoversDAO.findByMatrixIdAndLandCoverCode(env, matrixId, landCover.getCode());

					if (matrixClassLandCover != null) {
						matrixClassLandcoversDAO.logicallyDeleteByMatrixIdLandCoverCode(matrixId, landCover.getCode(), USER);
					}

					matrixClassLandcoversDAO.insert(matrixClassLandCoverMsg, USER);

				} catch (Exception e) {
					log.error("Error during insert/update operation of matrix class landcover with code {}, class code {} and matrix id {} : {}",
							landCover.getCode(), classMsg.getCode(), matrixId, e);
				}
			});
		}
	}

	private void insertOrUpdateMatrixClassLandUses(Long matrixId, MatrixClassMessage classMsg) {
		if (classMsg.getLand_use_codes() != null) {
			classMsg.getLand_use_codes().forEach(landUse -> {
				try {
					AbsoluteDate dayFrom = landUse.getDay_from() != null ? landUse.getDay_from() : classMsg.getDay_from();
					AbsoluteDate dayTo = landUse.getDay_to() != null ? landUse.getDay_to() : classMsg.getDay_to();

					MatrixClassLandusesNTT matrixClassLanduseMsg = MatrixClassLandusesNTT.builder()
							.class_code(classMsg.getCode())
							.day_from(dayFrom)
							.day_to(dayTo)
							.landuse(LandUsesCodeNTT.builder().code(landUse.getCode()).build())
							.matrix_id(matrixId)
							.user_id_insert(USER)
							.build();

					ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(TENANT_MASTER).user(new User(USER, TENANT_MASTER)).lang(LANG_EN).build();
					
					// A landuse can be in only one class per matrix, so if it is in any other class, or the same one, it must be "deleted"
					MatrixClassLandusesNTT matrixClassLandUses = matrixClassLandUsesDAO.findByMatrixIdAndLandUseCode(env, matrixId, landUse.getCode());

					if (matrixClassLandUses != null) {
						matrixClassLandUsesDAO.logicallyDeleteByMatrixIdAndLandUseCode(matrixId, landUse.getCode(), USER);
					}

					matrixClassLandUsesDAO.insert(matrixClassLanduseMsg, USER);

				} catch (Exception e) {
					log.error("Error during insert/update operation of matrix class landuses with code {}, class code {} and matrix id {} : {}",
							landUse.getCode(), classMsg.getCode(), matrixId, e);
				}
			});
		}
	}

	private void insertOrUpdateMatrixCompat(Long matrixId, MatrixClassMessage classMsg) {
		if (StringUtils.isNotBlank(classMsg.getExtended_by_class())) {
			try {
				MatrixCompatNTT matrixCompatMsg = MatrixCompatNTT.builder()
						.class_code(classMsg.getCode())
						.extended_by_class_code(classMsg.getExtended_by_class())
						.matrix_id(matrixId)
						.build();

				MatrixCompatNTT matrixCompat = matrixCompatDAO.findByMatrixIdAnClassCode(matrixId, classMsg.getCode());
				if (matrixCompat != null) {
					matrixCompatDAO.update(matrixCompatMsg);
				} else {
					matrixCompatDAO.insert(matrixCompatMsg);
				}
			} catch (Exception e) {
				log.error("Error during insert/update operation of matrix compat with class code {}, matrix id {} and extended_by_class_code {} : {}",
						classMsg.getCode(), matrixId, classMsg.getExtended_by_class(), e);
			}

		}
	}

}
