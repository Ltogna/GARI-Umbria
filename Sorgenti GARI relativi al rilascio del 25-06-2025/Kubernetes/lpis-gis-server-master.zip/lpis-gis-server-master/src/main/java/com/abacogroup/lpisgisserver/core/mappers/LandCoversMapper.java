package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.resources.res.LandCover;
import com.abacogroup.lpisgisserver.resources.res.LandCoverWithErrors;
import com.abacogroup.lpisgisserver.resources.res.LandCoverWithUnits;

@Mapper(uses = AbsoluteDateMapper.class)
public interface LandCoversMapper {

	LandCoversMapper INSTANCE = Mappers.getMapper(LandCoversMapper.class);

	@Mapping(source = "land_cover_id", target = "id")
	@Mapping(source = "land_cover_code", target = "code")
	@Mapping(source = "land_cover_description", target = "description")
	@Mapping(source = "land_cover_details_id", target = "details_id")
	@Mapping(source = "layerStyle", target = "layer_style")
	@Mapping(target = "parcel_details_id", ignore = true)
	LandCover entityToDto(LandCoverNTT entity);
	
	@Mapping(source = "land_cover_id", target = "id")
	@Mapping(source = "land_cover_code", target = "code")
	@Mapping(source = "land_cover_description", target = "description")
	@Mapping(source = "land_cover_details_id", target = "details_id")
	@Mapping(source = "layerStyle", target = "layer_style")
	@Mapping(target = "parcel_details_id", ignore = true)
	@Mapping(target = "unit_types", ignore = true)
	@Mapping(target = "vine_units", ignore = true)
	LandCoverWithUnits entityToDtoWithUnits(LandCoverNTT entity);
	
	@Mapping(source = "land_cover_id", target = "id")
	@Mapping(source = "land_cover_code", target = "code")
	@Mapping(source = "land_cover_description", target = "description")
	@Mapping(source = "land_cover_details_id", target = "details_id")
	@Mapping(source = "layerStyle", target = "layer_style")
	@Mapping(target = "parcel_details_id", ignore = true)
	@Mapping(target = "unitTypes", ignore = true)
	@Mapping(target = "vineUnits", ignore = true)
	@Mapping(target = "errorList", ignore = true)
	LandCoverWithErrors entityToDtoWithErrors(LandCoverNTT entity);

	@Mapping(source = "id", target = "land_cover_id")
	@Mapping(source = "code", target = "land_cover_code")
	@Mapping(source = "description", target = "land_cover_description")
	@Mapping(source = "details_id", target = "land_cover_details_id")
	@Mapping(source = "layer_style", target = "layerStyle")
	@Mapping(target = "edit_id", ignore = true)
	@Mapping(target = "edit_parcel_id", ignore = true)
	LandCoverNTT dtoToEntity(LandCover dto);

}
