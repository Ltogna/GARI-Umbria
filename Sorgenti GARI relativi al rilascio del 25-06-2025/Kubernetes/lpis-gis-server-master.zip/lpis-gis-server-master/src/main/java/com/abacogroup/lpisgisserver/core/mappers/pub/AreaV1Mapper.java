package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.resources.res.Area;
import com.abacogroup.lpisgisserver.resources.res.pub.AreaV1;

@Mapper(uses = {AbsoluteDateMapper.class, AreaLevelV1Mapper.class} )
public interface AreaV1Mapper {

	AreaV1Mapper INSTANCE = Mappers.getMapper(AreaV1Mapper.class);

	@InheritInverseConfiguration
	AreaV1 toResponseV1(Area entity);
}
