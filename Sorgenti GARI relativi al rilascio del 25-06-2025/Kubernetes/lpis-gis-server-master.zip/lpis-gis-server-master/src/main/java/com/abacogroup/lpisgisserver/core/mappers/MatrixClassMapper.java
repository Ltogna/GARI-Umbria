package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.MatrixClassDetailsNTT;
import com.abacogroup.lpisgisserver.resources.res.pub.MatrixClassV1;

@Mapper
public interface MatrixClassMapper {

	MatrixClassMapper INSTANCE = Mappers.getMapper(MatrixClassMapper.class);
	
	@Mapping(source = "class_code", target = "code") 
	@Mapping(source = "class_description", target = "description") 
	@Mapping(target = "landcover_list", ignore = true)
	@Mapping(target = "landuse_list", ignore = true)
	@Mapping(target = "extension_class_code_list", ignore = true)
	MatrixClassV1 entityToDto(MatrixClassDetailsNTT entity);
	
	@Mapping(source = "code", target = "class_code")
	@Mapping(source = "description", target = "class_description") 
	@Mapping(target = "dt_insert", ignore = true)
	@Mapping(target = "dt_delete", ignore = true)
	@Mapping(target = "user_id_insert", ignore = true)
	@Mapping(target = "user_id_delete", ignore = true)
	MatrixClassDetailsNTT dtoToEntity(MatrixClassV1 dto);
	
}
