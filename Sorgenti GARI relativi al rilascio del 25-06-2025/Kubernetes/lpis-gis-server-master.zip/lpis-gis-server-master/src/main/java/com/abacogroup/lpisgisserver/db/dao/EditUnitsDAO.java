package com.abacogroup.lpisgisserver.db.dao;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;

public interface EditUnitsDAO extends Transactional<EditUnitsDAO>, EnhancedSqlObject {

	@SqlUpdate("INSERT INTO lpis_edit_unit_codes (session_uuid, type_code, unit_code) "
			+ "values (:sessionId, :typeCode, :unitCode) "
			+ "")
	void insertEditUnitCode(@Bind("sessionId") String sessionId, @Bind("typeCode") UnitType typeCode, @Bind("unitCode") String unitCode);

	default Integer checkIfUniqueUnitCodeOverall(ServiceSupportEnv env, String unitCode, UnitType typeCode) {

		String editTableSql = "select count(*) \n"
				+ "from " + getEditTableName(typeCode) + " leu \n"
				+ "where leu.unit_code = :unitCode \n"
				;

		String detailTableSql = "select count(*) \n" 
				+ "from " + getDetailTableName(typeCode) + " lu \n"
				+ "where lu.unit_code = :unitCode \n"
				+ "   and :referenceDate between lu.day_from and lu.day_to \n"
				+ "   and not exists (select 1 from " + getEditTableName(typeCode) +" leu where leu.unit_id = lu.unit_id) \n"
				+ "   and §current_timestamp§ between lu.dt_insert and lu.dt_delete \n" 
				;
	
		Integer editCount = withHandle(h -> h.createQuery(editTableSql)
				.bind("unitCode", unitCode)
				.mapTo(Integer.class)
				.findOne()
				.orElse(0));

		Integer detailCount = withHandle(h -> h.createQuery(detailTableSql)
				.bindBean(env)
				.bind("unitCode", unitCode)
				.mapTo(Integer.class)
				.findOne()
				.orElse(0));

		return editCount + detailCount;
	}
	
	default String getDetailTableName(UnitType typeCode) {
		switch (typeCode) {
        case VINE_UNIT:
            return "lpis_unit_vineunit_details";
        case FRUIT_UNIT:
            return "lpis_unit_fruitunit_details";
        case OLIVE_UNIT:
            return "lpis_unit_oliveunit_details";
        default:
            throw new UnsupportedOperationException("Table name not implemented for the given type code: " + typeCode);
        }
	}
	
	default String getEditTableName(UnitType typeCode) {
		switch (typeCode) {
		case VINE_UNIT:
			return "lpis_edit_unit_vineunit";
		case FRUIT_UNIT:
			return "lpis_edit_unit_fruitunit";
		case OLIVE_UNIT:
			return "lpis_edit_unit_oliveunit";
		default:
			throw new UnsupportedOperationException("Table name not implemented for the given type code: " + typeCode);
		}
	}

}
