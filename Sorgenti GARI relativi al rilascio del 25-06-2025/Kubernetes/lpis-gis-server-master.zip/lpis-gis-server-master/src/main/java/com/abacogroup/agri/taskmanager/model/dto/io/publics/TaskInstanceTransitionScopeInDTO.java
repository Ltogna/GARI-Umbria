package com.abacogroup.agri.taskmanager.model.dto.io.publics;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TaskInstanceTransitionScopeInDTO {

	@Schema(description = "The workflow scope")
	private String scope;

	@Schema(description = "Transition notes")
	private String notes;
}
