package com.abacogroup.lpisgisserver.core;

import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryCollection;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.geom.Polygonal;

import com.abacogroup.geometryeditor.EditorSupport;
import com.abacogroup.lpisgisserver.core.enums.CutBehaviour;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.LandCoverConfigKeys;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.ParcelGeometryNotValidPolygonException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidEditSessionException;
import com.abacogroup.lpisgisserver.core.support.EditorSupportParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoverConfigsDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoversDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;

import jakarta.ws.rs.core.Response.Status;

public class EditorParcelsSupportImpl implements EditorSupport<Long> {

	private final EditParcelsDAO editParcelsDAO;
	private final LandCoversDAO landCoversDAO;
	private final LandCoverConfigsDAO landCoverConfigsDAO;
	private final EditorSupportParams params;
	private CutBehaviour cutBehaviour;
	private Map<Long, Polygon> cutPolygons;
	private long lastPreviewKey = 0;

	public EditorParcelsSupportImpl(EditorSupportParams params, CutBehaviour cutBehaviour,
			Map<Long, Polygon> cutPolygons, boolean isForPreview, long lastPreviewKey, DAOContainer dc) {

		// Returns the session that the edit session is currently being edited.
		if (params.getSession() == null) {
			throw new InvalidEditSessionException(Status.BAD_REQUEST, params.getOperation(), ErrorField.SESSION,
					null, params.getReqContext().getLang());
		}

		this.editParcelsDAO = dc.getEditParcelsDAO();
		this.landCoversDAO = dc.getLandCoversDAO();
		this.landCoverConfigsDAO = dc.getLandCoverConfigsDAO();
		this.params = params;
		this.cutBehaviour = cutBehaviour;
		this.cutPolygons = cutPolygons;
		this.lastPreviewKey = lastPreviewKey + 1; // incremented to align in getNewPolygonKey

	}

	/**
	 * Loads polygons for topology correction. It is used to check if there are parcels that are in edit polygons and if so the polygons are returned
	 * 
	* @param touchingGeometry - the geometry of the touching parcel
	 * 
	 * @return a map of polygons with id as key and polygons as value. The polygons are sorted by id and the polygons are in edit
	 */
	@Override
	public Map<Long, Polygon> loadPolygonsForTopologyCorrection(Geometry touchingGeometry) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(params.getReqContext().getUser())
				.lang(params.getReqContext().getLang())
				.tenantId(params.getReqContext().getTenantId())
				.sessionId(params.getSession().getUuid())
				.srs(params.getSession().getLock_geom_srs())
				.referenceDate(params.getSession().getReference_date())
				.build();

		//does not correct topology on non Polygon geometries				
		List<ParcelNTT> inEditpolygons = editParcelsDAO.getEditParcelsWithInteraction(env, touchingGeometry);
		Map<Long, Polygon> map = new HashMap<>();
		inEditpolygons.forEach(p -> {
			if (p.getGeom() instanceof Polygon)
				map.put(p.getParcel_id(), (Polygon) p.getGeom());
		});

		//does not correct topology on non Polygon geometries
		List<ParcelNTT> notInEditPolygons = editParcelsDAO.getNonEditParcelsWithInteraction(env, touchingGeometry);
		notInEditPolygons.forEach(p -> {
			if (p.getGeom() instanceof Polygon)
				map.put(p.getParcel_id(), (Polygon) p.getGeom());
		});
		return map;

	}

	/**
	* Loads polygons that are touching the geometry. This is used to determine which polygons need to be modified in order to make sure they are not in the edit parcels table ( which is the case for now )
	 * 
	* @param touchingGeometry - the geometry that is touching the polygons
	* @param interested - the interest of the polygons to be modified
	 * 
	 * @return the polygons that have been modified in the edit parcels table or null if there are no modifications
	 */
	@Override
	public InvolvedPolygons<Long> loadPolygonsWithInteraction(Geometry touchingGeometry, InvolvedPolygonsInterest interested) {
		final Map<Long, Polygon> modifiablePolygons = new HashMap<>();
		final Map<Long, Polygon> unmodifiablePolygons = new HashMap<>();

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(params.getReqContext().getUser())
				.lang(params.getReqContext().getLang())
				.tenantId(params.getReqContext().getTenantId())
				.sessionId(params.getSession().getUuid())
				.srs(params.getSession().getLock_geom_srs())
				.referenceDate(params.getSession().getReference_date())
				.build();

		List<ParcelNTT> polygons = new ArrayList<>();
		// already in editing parcels
		List<ParcelNTT> editPolygons = editParcelsDAO.getEditParcelsWithInteraction(env, touchingGeometry);
		// Add all polygons to the polygons list.
		if (editPolygons != null)
			polygons.addAll(editPolygons);
		// not yet in editing parcels
		List<ParcelNTT> nonEditPolygons = editParcelsDAO.getNonEditParcelsWithInteraction(env, touchingGeometry);
		// Add all polygons to the list of nonEditPolygons.
		if (nonEditPolygons != null)
			polygons.addAll(nonEditPolygons);

		// Add all polygons to the modifiable polygons.
		if (cutPolygons != null) {
			polygons = polygons.stream().filter(p -> (!cutPolygons.containsKey(p.getParcel_id()))).collect(toList());
			cutPolygons.forEach((id, p) -> {
				// Add a polygon to the modifiablePolygons.
				if (p != null)
					modifiablePolygons.put(id, p);
			});
		}
		
		List<Long> parcelIdsWithNotEditableLandCovers = getParcelsWithNotEditableLandCovers(env, polygons);

		polygons.forEach(p -> {
			// Check if geometry is a polygon or collection, otherwise throw exception
			// Checks if the polygon is a polygon and add in modifiable or unmodifiable, depending on CutBehaviour.
			// If it's a collection then add all polygons in the collection to unmodifiable polygons.
			if (!(p.getGeom() instanceof Polygon)) {
				if (!(p.getGeom() instanceof GeometryCollection))
					throw new ParcelGeometryNotValidPolygonException(Status.INTERNAL_SERVER_ERROR, null, ErrorField.GEOM, null, env.getLang());
				List<Polygon> polys = collectionToPolygons((GeometryCollection) p.getGeom());
				unmodifiablePolygons.putAll(createPolygonKeys(p.getParcel_id(), polys));
			}

			// Add a polygon to the list of polygons.
			else if (cutBehaviour == CutBehaviour.CUT_EXISTING && !parcelIdsWithNotEditableLandCovers.contains(p.getParcel_id()))
				modifiablePolygons.put(p.getParcel_id(), (Polygon) p.getGeom());
			// Add a polygon to the unmodifiablePolygons.
			else if (cutBehaviour == CutBehaviour.CUT_ON_EXISTING || parcelIdsWithNotEditableLandCovers.contains(p.getParcel_id()))
				unmodifiablePolygons.put(p.getParcel_id(), (Polygon) p.getGeom());
		});

		return new InvolvedPolygons<>(modifiablePolygons, unmodifiablePolygons);
	}

	private List<Long> getParcelsWithNotEditableLandCovers(ServiceSupportEnv env, List<ParcelNTT> polygons) {
		List<Long> parcelIds = polygons.stream().map(ParcelNTT::getParcel_id).collect(Collectors.toList());
		if (parcelIds.isEmpty()) {
			return new ArrayList<>(); // No parcels to check, return empty list
		}
		List<LandCoverNTT> landCovers = landCoversDAO.findByParcelIds(env, parcelIds);
		List<String> forbiddenLandCoverCodes = getForbiddenLandCoverCodes(env);
		
		return landCovers.stream()
				.filter(lc -> forbiddenLandCoverCodes.contains(lc.getLand_cover_code()))
				.map(LandCoverNTT::getParcel_id)
				.collect(Collectors.toList());
	}

	private static List<Polygon> collectionToPolygons(GeometryCollection collection) {
		List<Polygon> polygons = new ArrayList<>();

		for (int i = 0; i < collection.getNumGeometries(); ++i) {
			Geometry part = collection.getGeometryN(i);
			if (part instanceof Polygon) {
				polygons.add((Polygon) part);
			} else if (part instanceof GeometryCollection) {
				polygons.addAll(collectionToPolygons((GeometryCollection) part));
			}
		}

		return polygons;
	}

	/**
	 * Loads the geometries that make up the parcel. This is called by the constructor and can be used to populate the geometry for the parcel's canvas
	 * 
	* @param touchingGeometry - the geometry that is touching the parcel
	 * 
	 * @return a collection of polygonal geometries that make up the parcel's canvas or null if there is
	 */
	@Override
	public Collection<Polygonal> loadCanvasGeometries(Geometry touchingGeometry) {
		// for parcels there is no canvas!
		return null;
	}

	/**
	 * Creates a map of polygon keys to their corresponding polygons. The polygons are sorted by their area and the key is used to store the polygon in the map.
	 * 
	* @param key - the key for the polygon to be stored in the map
	* @param polygons - the polygons to be stored in the map
	 * 
	 * @return a map of polygon keys to their corresponding polygons ( if any are present in the collection they will be stored
	 */
	@Override
	public Map<Long, Polygon> createPolygonKeys(Long key, Collection<Polygon> polygons) {

		Map<Long, Polygon> map = new HashMap<>();
		var maxAreaPolygon = polygons.stream().max(Comparator.comparing(Polygon::getArea));
		// Add max area polygon to map.
		if (!maxAreaPolygon.isEmpty()) {
			map.put(key, maxAreaPolygon.get());
		}

		polygons.forEach(p -> {
			// Put the polygon in the map.
			if (p != maxAreaPolygon.get())
				map.put(getNewPolygonKey(), p);
		});
		return map;

	}

	/**
	 * Creates a map of polygon keys. This is used to store polygons that need to be re - used in order to avoid re - creating the same polygon multiple times
	 * 
	* @param polygons - the polygons to be stored
	 * 
	 * @return a map of polygon keys indexed by their position in the collection of polygons passed in as an argument to
	 */
	@Override
	public Map<Long, Polygon> createPolygonKeys(Collection<Polygon> polygons) {

		Map<Long, Polygon> map = new HashMap<>();
		polygons.forEach(p -> map.put(getNewPolygonKey(), p));
		return map;

	}

	/**
	 * Returns a new polygon key. Used to determine which polygon should be previewed and where to put the preview in the map.
	 * 
	 * 
	 * @return The key that should be used for previewing the polygon or null if there is no preview available in the
	 */
	private Long getNewPolygonKey() {
		lastPreviewKey -= 1;
		return lastPreviewKey;
	}
	
	private List<String> getForbiddenLandCoverCodes(ServiceSupportEnv env) {
		return landCoverConfigsDAO.findConfigs(env.getTenantId(), null, LandCoverConfigKeys.EDIT_FORBIDDEN).stream()
				.filter(c -> Boolean.TRUE.equals(Boolean.parseBoolean(c.getValue())))
				.map(config -> config.getLandCoverCode())
				.collect(Collectors.toList());
	}
}
