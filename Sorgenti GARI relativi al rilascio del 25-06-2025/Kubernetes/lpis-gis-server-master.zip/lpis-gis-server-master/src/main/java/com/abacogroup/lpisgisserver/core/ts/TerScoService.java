package com.abacogroup.lpisgisserver.core.ts;

import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;

public interface TerScoService {

	boolean hasScopeOnSector(ServiceSupportEnv env, String sectorCode);
	
	boolean hasScopeOnSector(ServiceSupportEnv env, Long sectorId);
	
	boolean hasScopeOnBlock(ServiceSupportEnv env, Long blockId);
	
	boolean hasScopeOnParcel(ServiceSupportEnv env, Long parcelId);
	
}
