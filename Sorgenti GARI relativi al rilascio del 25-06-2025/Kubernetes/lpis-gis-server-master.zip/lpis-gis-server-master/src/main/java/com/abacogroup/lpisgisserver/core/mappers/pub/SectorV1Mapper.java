package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.SectorNTT;
import com.abacogroup.lpisgisserver.resources.res.Sector;
import com.abacogroup.lpisgisserver.resources.res.pub.SectorV1;

@Mapper
public interface SectorV1Mapper {

	SectorV1Mapper INSTANCE = Mappers.getMapper(SectorV1Mapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "sectorCode", source = "sector_code")
	@Mapping(target = "shortDescr", source = "short_descr")
	@Mapping(target = "worldGeom", source = "world_geom")
	SectorV1 toResponseV1(Sector entity);
	
	@Mapping(target = "sectorCode", source = "sector")
	@Mapping(target = "shortDescr", source = "short_descr")
	@Mapping(target = "worldGeom", source = "world_geom")
	SectorV1 toResponseV1(SectorNTT entity);
	
}
