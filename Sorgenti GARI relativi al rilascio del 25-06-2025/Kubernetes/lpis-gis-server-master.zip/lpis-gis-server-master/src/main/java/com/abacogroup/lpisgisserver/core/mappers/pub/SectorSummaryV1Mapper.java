package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.SectorSummaryNTT;
import com.abacogroup.lpisgisserver.resources.res.pub.units.SectorSummaryV1;

@Mapper(uses = { SectorV1Mapper.class } )
public interface SectorSummaryV1Mapper {

	SectorSummaryV1Mapper INSTANCE = Mappers.getMapper(SectorSummaryV1Mapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "anomaliesList", ignore = true)
	SectorSummaryV1 toResponseV1(SectorSummaryNTT entity);
	
}
