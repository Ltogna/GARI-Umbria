package com.abacogroup.lpisgisserver.bundles;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.lpisgisserver.bundles.models.AnomalyCategoriesMessage;
import com.abacogroup.lpisgisserver.core.enums.AnomalyLevel;
import com.abacogroup.lpisgisserver.db.dao.AnomalyCategoriesDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.ntt.AnomalyCategoriesNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AnomalyCategoriesMessageProcessor extends AbstractMessageProcessor {

	private AnomalyCategoriesDAO anomalyCategoriesDAO;

	private final ObjectMapper objectMapper;

	private static final Logger log = LoggerFactory.getLogger(AnomalyCategoriesMessageProcessor.class);

	public AnomalyCategoriesMessageProcessor(DAOContainer dc) {
		super(dc);
		this.anomalyCategoriesDAO = dc.getAnomalyCategoriesDAO();
		objectMapper = new ObjectMapper();
	}

	@Override
	public String getDomainName() {
		return "anomaly-categories";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.jsonl"))
				.forEach(file -> deleteAnomalyCategoryMessage(message.getTenantId(), file));

		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("jsonl")
						&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.jsonl"))
				.forEach(file -> insertOrUpdateAnomalyCategoryMessage(message.getTenantId(), file));
	}

	private void deleteAnomalyCategoryMessage(String tenantId, File file) {
		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String line = reader.readLine();
			while (line != null) {
				deleteMessage(tenantId, line);
				line = reader.readLine();
			}
		} catch (IOException e) {
			log.error(ERROR_READ_FILE_MESSAGE, file.getAbsolutePath(), e);
		}
	}
	
	private void deleteMessage(String tenantId, String line) {
		try {
			AnomalyCategoriesMessage message = objectMapper.readValue(line, AnomalyCategoriesMessage.class);

			AnomalyCategoriesNTT anomalyCategory = anomalyCategoriesDAO.findByTenantGroupCodeAndCode(tenantId, message.getGroup_code(),
					message.getCode());

			if (anomalyCategory != null) {
				anomalyCategoriesDAO.deleteByTenantGroupCodeAndCode(tenantId, message.getGroup_code(), message.getCode());
			}

		} catch (Exception e) {
			log.error("Error during delete anomaly category with line {} : {}", line, e);
		}
	}

	private void insertOrUpdateAnomalyCategoryMessage(String tenantId, File file) {
		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String line = reader.readLine();
			while (line != null) {
				insertOrUpdateMessage(tenantId, line);
				line = reader.readLine();
				
			}
		} catch (IOException e) {
			log.error(ERROR_READ_FILE_MESSAGE, file.getAbsolutePath(), e);
		}
	}

	private void insertOrUpdateMessage(String tenantId, String line) {
		try {
			AnomalyCategoriesMessage message = objectMapper.readValue(line, AnomalyCategoriesMessage.class);

			AnomalyCategoriesNTT anomalyCategoryMessage = AnomalyCategoriesNTT.builder()
					.code(message.getCode())
					.fl_exclude(message.getFl_exclude() != null && message.getFl_exclude() ? 1 : 0)
					.group_code(message.getGroup_code())
					.level(message.getLevel())
					.build();

			AnomalyCategoriesNTT anomalyCategory = anomalyCategoriesDAO.findByTenantGroupCodeAndCode(tenantId, message.getGroup_code(),
					message.getCode());

			if (anomalyCategory == null) {
				if (anomalyCategoryMessage.getLevel().equals(AnomalyLevel.UNCATEGORIZED)) {
					throw new IllegalStateException("UNCATEGORIZED level must not exist on lpis_anomaly_categories!");
				}

				anomalyCategoriesDAO.insert(tenantId, anomalyCategoryMessage);

			} else if (!anomalyCategoryMessage.equals(anomalyCategory)) {
				if (anomalyCategoryMessage.getLevel().equals(AnomalyLevel.UNCATEGORIZED)) {
					throw new IllegalStateException("UNCATEGORIZED level must not exist on lpis_anomaly_categories!");
				}

				anomalyCategoriesDAO.update(tenantId, anomalyCategoryMessage);
			}

		} catch (Exception e) {
			log.error("Error during insert or update anomaly category with line {} : {}", line, e);
		}
	}
	
}
