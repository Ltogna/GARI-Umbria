package com.abacogroup.lpisgisserver.core.exceptions.landcover;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class LandCoverGeometryNotLineException extends AbstractException {

	private static final long serialVersionUID = 3736186129119668721L;

	private static final ErrorCode ERROR_CODE = ErrorCode.LANDCOVER_GEOM_IS_NOT_A_LINE;

	public LandCoverGeometryNotLineException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new LandCoverGeometryNotLineExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Geometry is not a line")
	public static class LandCoverGeometryNotLineExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -8563646071691316102L;

		public LandCoverGeometryNotLineExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}

	}
}
