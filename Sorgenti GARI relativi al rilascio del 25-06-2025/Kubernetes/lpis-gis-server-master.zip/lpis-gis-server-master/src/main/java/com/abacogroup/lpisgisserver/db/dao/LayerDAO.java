package com.abacogroup.lpisgisserver.db.dao;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.lpisgisserver.db.ntt.WmsLayerModuleNTT;
import com.abacogroup.lpisgisserver.db.ntt.WmsLayerNTT;
import com.abacogroup.lpisgisserver.db.ntt.WmsModuleNTT;
import com.abacogroup.lpisgisserver.db.ntt.WmsServerNTT;

public interface LayerDAO extends Transactional<LayerDAO>, EnhancedSqlObject {

	@SqlQuery("§select_nextval(lpis_wms_layers_sequence)§")
	Long nextWmsLayerSequenceVal();

	@SqlQuery("§select_nextval(lpis_wms_servers_sequence)§")
	Long nextWmsServerSequenceVal();

	@SqlUpdate("insert into lpis_wms_servers(id, tenant_id, display_order, code, url, format, srs, server_type, color, transparent, icon_url, server_config) values "
			+ "(:id, :tenantId, :display_order, :code, :url, :format, :srs, :server_type, :color, :transparent, :icon_url, :server_config)")
	void insertWmsServer(@BindBean WmsServerNTT wmsServer, @Bind("tenantId") String tenant);

	@SqlUpdate("insert into lpis_wms_layers (id, wms_server_id , display_order, code, max_pixel_val, foreground_level, layer_name, layer_options, path, catalogue_code, info_catalogue_code) values (:id, :wms_server_id , :display_order, :code, :max_pixel_val, :foreground_level, :layer_name, :layer_options, :path, :catalogue_code, :info_catalogue_code)")
	void insertWmsLayer(@BindBean WmsLayerNTT wmsLayer, @Bind("tenantId") String tenant);

	@SqlUpdate("insert into lpis_wms_modules (wms_server_id, module, fl_on) values (:wms_server_id, :module, :fl_on)")
	void insertWmsModule(@BindBean WmsModuleNTT wmsModule);

	@SqlUpdate("insert into lpis_wms_layer_modules (wms_server_id, wms_layer_id, module, fl_on) values (:wms_server_id, :wms_layer_id, :module, :fl_on)")
	void insertWmsLayerModule(@BindBean WmsLayerModuleNTT wmsLayerModule);

	@SqlUpdate("insert into lpis_wms_permission (wms_server_id, context_function) values (:wms_server_id, :context_function)")
	void insertWmsPermission(@Bind("wms_server_id") Long wmsServerId, @Bind("context_function") String contextFunction);

	@SqlUpdate("update lpis_wms_servers set display_order = :display_order, url = :url, format = :format, srs = :srs, "
			+ "server_type = :server_type, color = :color, transparent = :transparent , icon_url = :icon_url, server_config = :server_config "
			+ "where id = :id")
	void updateWmsServerById(@BindBean WmsServerNTT wmsServer);

	@SqlUpdate("update lpis_wms_layers set display_order = :display_order, max_pixel_val = :max_pixel_val, foreground_level = :foreground_level, layer_name = :layer_name, layer_options = :layer_options, path = :path, catalogue_code = :catalogue_code, info_catalogue_code = :info_catalogue_code where id = :id")
	void updateWmsLayerById(@BindBean WmsLayerNTT wmsLayer);

	@SqlUpdate("update lpis_wms_modules set fl_on = :fl_on where wms_server_id = :wms_server_id and module = :module")
	void updateWmsModuleFlOn(@BindBean WmsModuleNTT wmsModule);

	@SqlUpdate("update lpis_wms_layer_modules set fl_on = :fl_on where wms_server_id = :wms_server_id and wms_layer_id = :wms_layer_id and module = :module")
	void updateWmsLayerModuleFlOn(@BindBean WmsLayerModuleNTT wmsModule);

	@SqlUpdate("delete from lpis_wms_servers where id = :id")
	void deleteWmsServerById(@Bind("id") Long id);

	@SqlUpdate("delete from lpis_wms_layers where id = :id")
	void deleteWmsLayerById(@Bind("id") Long id);

	@SqlUpdate("delete from lpis_wms_modules where wms_server_id = :wms_server_id and module = :module")
	void deleteWmsModuleByWmsServerIdAndModule(@Bind("wms_server_id") Long wmsServerId, @Bind("module") String module);

	@SqlUpdate("delete from lpis_wms_layer_modules where wms_server_id = :wms_server_id and wms_layer_id = :wms_layer_id and module = :module")
	void deleteWmsLayerModuleByWmsServerIdWmsLayerIdAndModule(@BindBean WmsLayerModuleNTT wmsModule);

	@SqlUpdate("delete from lpis_wms_permission where wms_server_id = :wms_server_id")
	void deleteWmsPermissionByWmsServerId(@Bind("wms_server_id") Long wmsServerId);

	@SqlUpdate("delete from lpis_wms_permission where wms_server_id = :wms_server_id and context_function = :context_function")
	void deleteWmsPermissionByWmsServerIdAndContextFunction(@Bind("wms_server_id") Long wmsServerId, @Bind("context_function") String contextFunction);

	@SqlQuery("select lws.id, \n"
			+ "       lws.display_order, \n"
			+ "       lws.code, \n"
			+ "       lws.url, \n"
			+ "       lws.format, \n"
			+ "       lws.srs, \n"
			+ "       lws.server_type, \n"
			+ "       lws.color, \n"
			+ "       lws.transparent, \n"
			+ "       lws.icon_url, \n"
			+ "       lws.server_config \n"
			+ "from lpis_wms_servers lws \n"
			+ "where lws.code = :code \n"
			+ "  and lws.tenant_id = :tenantId")
	@RegisterBeanMapper(WmsServerNTT.class)
	WmsServerNTT findWmsServerByTenantAndCode(@Bind("tenantId") String tenant, @Bind("code") String code);

	@SqlQuery("select lwl.id, \n"
			+ "       lwl.wms_server_id, \n"
			+ "       lwl.display_order, \n"
			+ "       lwl.code, \n"
			+ "       lwl.max_pixel_val, \n"
			+ "       lwl.foreground_level, \n"
			+ "       lwl.layer_name, \n"
			+ "       lwl.layer_options, \n"
			+ "       lwl.path, \n"
			+ "       lwl.catalogue_code, \n"
			+ "       lwl.info_catalogue_code \n"
			+ "from lpis_wms_servers lws \n"
			+ "inner join lpis_wms_layers lwl on lws.id = lwl.wms_server_id \n"
			+ "where lws.tenant_id = :tenantId \n"
			+ "  and lws.code = :wmsServerCode \n"
			+ "  and lwl.code = :code")
	@RegisterBeanMapper(WmsLayerNTT.class)
	WmsLayerNTT findWmsLayerByTenantWmsServerCodeAndCode(@Bind("tenantId") String tenant, @Bind("wmsServerCode") String wmsServerCode,
			@Bind("code") String code);

	@SqlQuery("select lwm.wms_server_id \n"
			+ "from lpis_wms_servers lws \n"
			+ "inner join lpis_wms_modules lwm on lws.id = lwm.wms_server_id \n"
			+ "where lws.tenant_id = :tenantId \n"
			+ "  and lws.code = :wmsServerCode \n"
			+ "  and lwm.module = :module")
	Long findWmsServerIdFromWmsModulesByTenantWmsServerCodeAndModule(
			@Bind("tenantId") String tenant,
			@Bind("wmsServerCode") String wmsServerCode,
			@Bind("module") String module);

	@SqlQuery("select lwm.wms_server_id, \n"
			+ "       lwm.wms_layer_id, \n"
			+ "       lwm.fl_on, \n"
			+ "       lwm.module \n"
			+ "from lpis_wms_servers lws \n"
			+ "inner join lpis_wms_layer_modules lwm on lws.id = lwm.wms_server_id \n"
			+ "inner join lpis_wms_layers lwl on lwl.id = lwm.wms_layer_id \n"
			+ "where lws.tenant_id = :tenantId \n"
			+ "  and lws.code = :wmsServerCode \n"
			+ "  and lwl.code = :wmsLayerCode \n"
			+ "  and lwm.module = :module")
	@RegisterBeanMapper(WmsLayerModuleNTT.class)
	WmsLayerModuleNTT findWmsLayerModuleFromWmsModulesByTenantWmsServerCodeWmsLayerCodeAndModule(
			@Bind("tenantId") String tenant,
			@Bind("wmsServerCode") String wmsServerCode,
			@Bind("wmsLayerCode") String wmsLayerCode,
			@Bind("module") String module);

	@SqlQuery("select lwp.wms_server_id \n"
			+ "from lpis_wms_servers lws \n"
			+ "inner join lpis_wms_permission lwp on lws.id = lwp.wms_server_id \n"
			+ "where lws.tenant_id = :tenantId \n"
			+ "  and lws.code = :wmsServerCode \n"
			+ "  and lwp.context_function = :contextFunction")
	Long findWmsServerIdFromWmsPermissionByTenantWmsServerCodeAndContextFunction(
			@Bind("tenantId") String tenant,
			@Bind("wmsServerCode") String wmsServerCode,
			@Bind("contextFunction") String contextFunction);

	@SqlQuery("select lwm.wms_server_id, \n"
			+ "       lwm.module, \n"
			+ "       lwm.fl_on \n"
			+ "from lpis_wms_modules lwm \n"
			+ "where lwm.wms_server_id = :wmsServerId \n"
			+ "  and lwm.module = :module")
	@RegisterBeanMapper(WmsModuleNTT.class)
	WmsModuleNTT findWmsModuleByWmsServerIdAndModule(
			@Bind("wmsServerId") Long wmsServerId,
			@Bind("module") String module);

	@SqlQuery("select lwm.wms_server_id, \n"
			+ "       lwm.wms_layer_id, \n"
			+ "       lwm.module, \n"
			+ "       lwm.fl_on \n"
			+ "from lpis_wms_Layer_modules lwm \n"
			+ "where lwm.wms_server_id = :wmsServerId \n"
			+ "  and lwm.wms_layer_id = :wmsLayerId \n"
			+ "  and lwm.module = :module")
	@RegisterBeanMapper(WmsLayerModuleNTT.class)
	WmsLayerModuleNTT findWmsLayerModuleByWmsServerIdWmsLayerIdAndModule(
			@Bind("wmsServerId") Long wmsServerId,
			@Bind("wmsLayerId") Long wmsLayerId,
			@Bind("module") String module);

	@SqlQuery("select count(*) from ( select lwp.wms_server_id, \n"
			+ "       lwp.context_function \n"
			+ "from lpis_wms_permission lwp \n"
			+ "where lwp.wms_server_id = :wmsServerId \n"
			+ "  and lwp.context_function = :contextFunction )t\n")
	Long countWmsPermissionByWmsServerIdAndContextFunction(
			@Bind("wmsServerId") Long wmsServerId,
			@Bind("contextFunction") String contextFunction);
}
