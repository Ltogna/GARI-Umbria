package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.LandUsesCodeNTT;
import com.abacogroup.lpisgisserver.resources.res.pub.LandUsesCodeV1;

@Mapper
public interface LandUsesCodeV1Mapper {

	LandUsesCodeV1Mapper INSTANCE = Mappers.getMapper(LandUsesCodeV1Mapper.class);

	@Mapping(source = "code", target = "land_uses_code")
	LandUsesCodeV1 entityToDto(LandUsesCodeNTT entity);

	@Mapping(source = "land_uses_code", target = "code")
	LandUsesCodeNTT dtoToEntity(LandUsesCodeV1 dto);
}
