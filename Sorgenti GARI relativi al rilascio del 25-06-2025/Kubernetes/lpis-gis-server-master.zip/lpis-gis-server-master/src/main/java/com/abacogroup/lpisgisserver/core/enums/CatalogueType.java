package com.abacogroup.lpisgisserver.core.enums;

public enum CatalogueType {
	INTERNAL, //gestito internamente di default per l'editor
	SDE, //gestito internamente di default per l'editor elencati dalla tabella sde
	CROP_PLAN, //"esterno" viene chiamata l'api di crop plan
	VECTOR_DATA_LAYERS, //"esterno" viene chiamata l'api di vector data layers
}
