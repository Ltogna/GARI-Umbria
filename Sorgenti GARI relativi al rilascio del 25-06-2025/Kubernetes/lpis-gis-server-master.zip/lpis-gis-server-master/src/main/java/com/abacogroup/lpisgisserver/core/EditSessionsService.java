
package com.abacogroup.lpisgisserver.core;

import static java.util.stream.Collectors.toList;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.sqlobject.transaction.Transaction;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.proj4j.CoordinateReferenceSystem;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.dropwizard.auth.sso2.UserFunction;
import com.abacogroup.embeddedqueue.AbstractWorkQueue;
import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.ParcelNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.session.AreaAlreadyLockedException;
import com.abacogroup.lpisgisserver.core.exceptions.session.GenericSessionException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidEditCategoryCodeException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidEditSessionException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidEditSessionPayloadException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidLockAreaTooLargeException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidLockAreaTooSmallException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionDataException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionParcelTaskGeomException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionTaskException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSuspendSessionPayloadException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidUserEditSessionException;
import com.abacogroup.lpisgisserver.core.exceptions.session.ParcelBlockNotValidException;
import com.abacogroup.lpisgisserver.core.mappers.EditSessionMapper;
import com.abacogroup.lpisgisserver.core.mappers.ParcelsMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.FruitUnitMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.OliveUnitMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.VineAptitudesMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.VineUnitMapper;
import com.abacogroup.lpisgisserver.core.models.session.BuildSessionPreviewParcelLandCovers;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.BlockDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditLandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.EditParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.EditSessionsDAO;
import com.abacogroup.lpisgisserver.db.dao.FruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoversDetailsDAO;
import com.abacogroup.lpisgisserver.db.dao.LockParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.OliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.ParcelDetailsDAO;
import com.abacogroup.lpisgisserver.db.dao.ParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.SectorDAO;
import com.abacogroup.lpisgisserver.db.dao.StackLandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.StackParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.StacksDAO;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.dao.VineUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.WMSParcelsFilterDAO;
import com.abacogroup.lpisgisserver.db.ntt.BlockNTT;
import com.abacogroup.lpisgisserver.db.ntt.EditCategoryNTT;
import com.abacogroup.lpisgisserver.db.ntt.EditSessionNTT;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.db.ntt.SectorNTT;
import com.abacogroup.lpisgisserver.db.ntt.StackLandCoversNTT;
import com.abacogroup.lpisgisserver.db.ntt.StackParcelsNTT;
import com.abacogroup.lpisgisserver.db.ntt.StacksNTT;
import com.abacogroup.lpisgisserver.db.ntt.WmsParcelsFilterNTT;
import com.abacogroup.lpisgisserver.dispatch.payload.StackParcelsPayload;
import com.abacogroup.lpisgisserver.dispatch.payload.StackPayload;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.CreateEditSessionPayload;
import com.abacogroup.lpisgisserver.resources.req.ReqContext;
import com.abacogroup.lpisgisserver.resources.req.UpdateEditSessionPayload;
import com.abacogroup.lpisgisserver.resources.res.EditSession;
import com.abacogroup.lpisgisserver.resources.res.Parcel;
import com.abacogroup.lpisgisserver.resources.res.SessionCheckResult;
import com.abacogroup.lpisgisserver.resources.res.SessionPreview;
import com.abacogroup.lpisgisserver.resources.res.SessionStatusEnum;
import com.abacogroup.lpisgisserver.resources.res.tasks.TaskManagerData;
import com.abacogroup.lpisgisserver.resources.res.units.fruit.FruitUnit;
import com.abacogroup.lpisgisserver.resources.res.units.olive.OliveUnit;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineAptitude;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnitWithAptitudes;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EditSessionsService extends BaseService {

	private final CoordinateReferenceSystem toWorldCRS = getCRS("EPSG:3857");

	//according msdn ai: Yes, the HTTP status code 424 Failed Dependency could be suitable for your scenario. It indicates that the method could not be performed on the resource because the requested action depended on another action, and that action failed. This aligns with your situation where the backend program checks for valid conditions, and if something is wrong, it responds with a list of conditions in error, indicating a dependency failure. You can use this status code to convey the specific nature of the error to the client.
	private static final int IN_SESSION_DATA_WITH_ERRORS_STATUS_CODE_RESPONSE = 424;
	
	private static final String TASK_TRANSITION_TO_PROGRESS = "start-work";
	private static final List<String> TASK_TRANSITION_TO_PROGRESS_ACCEPATABLE_ERROR_CODES = Arrays.asList("PROGRESS_WORKFLOW_ERROR");

	private static final String SESSION_DONE = "DONE";
	private static final String TASK_TRANSITION_TO_DONE = "set-completed";
	private static final String SESSION_SUSPEND = "SUSPEND";
	private static final String TASK_TRANSITION_TO_SUSPEND = "set-not-workable";
	
	private static final String CONTEXT_ID_LPIS = "LPIS";
	private static final String ALLOW_MULTIPLE_EDIT_SESSIONS = "ALLOW_MULTIPLE_EDIT_SESSIONS";
	
	private static final int DO_NOT_INCLUDE_OUTDATED_PARCELS = 0;

	private final TaskManagerService taskManagerService;
	private final EditSessionSupportService editSessionSupportService;
	private final SupportSessionAnomaliesService supportSessionAnomalyService;

	private final EditSessionsDAO editSessionsDAO;
	private final ParcelsDAO parcelsDAO;
	private final ParcelDetailsDAO parcelDetailsDAO;
	private final EditParcelsDAO editParcelsDAO;
	private final LandCoversDAO landCoversDAO;
	private final LandCoversDetailsDAO landCoversDetailsDAO;
	private final EditLandCoversDAO editLandCoversDAO;
	private final LockParcelsDAO lockParcelsDAO;
	private final StacksDAO stacksDAO;
	private final StackParcelsDAO stackParcelsDAO;
	private final StackLandCoversDAO stackLandCoversDAO;
	private final BlockDAO blockDAO;
	private final WMSParcelsFilterDAO wmsParcelsFilterDAO;
	private final SectorDAO sectorDAO;
	private final SupportDAO supportDAO;
	private final VineUnitsDAO vineUnitsDAO;
	private final OliveUnitsDAO oliveUnitsDAO;
	private final FruitUnitsDAO fruitUnitsDAO;

	private final Sso2Client sso2Client;

	private final AbstractWorkQueue<StackPayload, ?> stackMessageQueue;

	public EditSessionsService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, TaskManagerService taskManagerService,
			EditSessionSupportService editSessionSupportService, SupportSessionAnomaliesService supportSessionAnomalyService,
			AbstractWorkQueue<StackPayload, ?> stackMessageQueue, PluginEnvironment pluginEnvironment, Sso2Client sso2Client) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.taskManagerService = taskManagerService;
		this.editSessionSupportService = editSessionSupportService;
		this.supportSessionAnomalyService = supportSessionAnomalyService;

		this.editSessionsDAO = dc.getEditSessionsDAO();
		this.parcelsDAO = dc.getParcelsDAO();
		this.parcelDetailsDAO = dc.getParcelDetailsDAO();
		this.editParcelsDAO = dc.getEditParcelsDAO();
		this.landCoversDAO = dc.getLandCoversDAO();
		this.landCoversDetailsDAO = dc.getLandCoversDetailsDAO();
		this.editLandCoversDAO = dc.getEditLandCoversDAO();
		this.lockParcelsDAO = dc.getLockParcelsDAO();

		this.stacksDAO = dc.getStacksDAO();
		this.stackParcelsDAO = dc.getStackParcelsDAO();
		this.stackLandCoversDAO = dc.getStackLandCoversDAO();
		this.blockDAO = dc.getBlockDAO();
		this.sectorDAO = dc.getSectorDAO();
		this.supportDAO = dc.getSupportDAO();
		this.vineUnitsDAO = dc.getVineUnitsDAO();
		this.oliveUnitsDAO = dc.getOliveUnitsDAO();
		this.fruitUnitsDAO = dc.getFruitUnitsDAO();
		
		this.wmsParcelsFilterDAO = dc.getWmsParcelsFilterDAO();

		this.sso2Client = sso2Client;
		
		this.stackMessageQueue = stackMessageQueue;
	}

	
	public SessionPreview previewSession(ReqContext reqContext, CreateEditSessionPayload payload) {
		return previewSession(reqContext, payload, false);
	}
	
	// XXX the client should call a different api, for now set skipScopeCheck for hot-fix
	public SessionPreview previewSession(ReqContext reqContext, CreateEditSessionPayload payload, boolean skipScopeCheck) {

		editSessionSupportService.checkReqContextAndCreateSessionPayloadInitData(reqContext, payload, Operation.SESSION_PREVIEW);

		if (payload.getReference_date() == null)
			payload.setReference_date(AbsoluteDate.of(LocalDate.now()));
		
		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(reqContext.getUser())
				.lang(reqContext.getLang())
				.tenantId(reqContext.getTenantId())
				.sessionId(null)
				.referenceDate(payload.getReference_date())
				.build();

		// ------------------------
		// Scenario 1 : get a valid task with an existing parcel
		// Scenario 2 : get a valid task to create a new parcel get an lock_geometry from the client
		// Scenario 2a: get a valid task to create a new parcel that already have an id but no geometry and get an lock_geometry from the client (future)
		// Scenario 3 : get a valid existing parcelId without a task
		// Scenario 4 : directly get a valid lock_geometry from the client for parcel creation

		Long parcelId = null;

		List<Geometry> sketches = null;
		if (payload.getTask_id() != null) {
			// Get parcelID, and other data, from TaskManager if the task is for create a new parcel, then I need a lock_geometry from the client
			TaskManagerData task = taskManagerService.getTaskData(reqContext, payload.getTask_id());
			if (task == null || !payload.getTask_id().equals(task.getTaskId())) {
				InvalidSessionTaskException ex = new InvalidSessionTaskException(Status.BAD_REQUEST,
						Operation.SESSION_PREVIEW, ErrorField.TASK,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), reqContext.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}

			parcelId = task.getParcelId();
			checkTaskAndPayloadData(env, task, payload);
			sketches = task.getSketches();

		} else {
			parcelId = payload.getParcel_id();
			sketches = payload.getSketches();
		}

		// Check if the parcel is valid for the tenant, if null skip it
		// XXX the client should call a different api, for now set skipScopeCheck for hot-fix
		editSessionSupportService.checkCanEditParcel(env, parcelId, skipScopeCheck);
		
		// ---------------
		// here, in some way, i get a parcelID or a lock_geometry
		BuildSessionPreviewParcelLandCovers sessionPreviewParcelLandCovers = editSessionSupportService.buildSessionPreviewParcelLandCovers(parcelId, sketches,
				env, payload);

		// Here Lock Geometry shouldn't be null
		checkLockGeom(sessionPreviewParcelLandCovers.getLockGeometry(), env);

		// check that intersectedMBR is outside all valid lock_geometry
		Long foundLockedGeomsCount = editSessionsDAO.findOtherLockedGeoms(env.getTenantId(), sessionPreviewParcelLandCovers.getLockGeometry(), null,
				this.internalConf.getLastValidSessionTime(env.getTenantId()));

		// in preview is needed only for information
		String previewId = UUID.randomUUID().toString();

		env.setParcelId(parcelId);
		List<Geometry> searchGeoms = null;
		if (sketches != null && !sketches.isEmpty()) {
			searchGeoms = sketches;
		} else if (payload.getLock_geom() != null) {
			searchGeoms = List.of(payload.getLock_geom());
		}

		Long sectorId = findSectorId(env, searchGeoms);
		
		// Check if the Sector is valid for the user, if null skip it
		if(!skipScopeCheck) {
			editSessionSupportService.checkScopes(env, null, Arrays.asList(sectorId));
		}
		
		sessionPreviewParcelLandCovers.getSessionLandCovers().stream().forEach(lc -> {
			env.setLandCoverId(lc.getId());
			lc.setUnit_types(supportDAO.getCompatibleUnitTypesByLandCoverCode(env.getTenantId(), lc.getCode()));
			lc.setVine_units(getVineUnits(env));
			lc.setOlive_units(getOliveUnits(env));
			lc.setFruit_units(getFruitUnits(env));
			lc.setTotal_unit_area_sqm(
					lc.getVine_units().stream().mapToInt(VineUnitWithAptitudes::getAreaSqm).sum() +
					lc.getOlive_units().stream().mapToInt(OliveUnit::getAreaSqm).sum() +
					lc.getFruit_units().stream().mapToInt(FruitUnit::getAreaSqm).sum()
					);
		});
		
		return SessionPreview.builder()
				.preview_id(previewId)
				.lock_geom(sessionPreviewParcelLandCovers.getLockGeometry())
				.lock_geom_srs(sessionPreviewParcelLandCovers.getLockGeometrySrs())
				.session_parcels(sessionPreviewParcelLandCovers.getSessionParcels())
				.session_land_covers(sessionPreviewParcelLandCovers.getSessionLandCovers())
				.session_with_interaction(foundLockedGeomsCount)
				.locked_parcels(sessionPreviewParcelLandCovers.getIntersectedParcels().stream().map(ParcelsMapper.INSTANCE::entityToDto).collect(toList()))
				.sector_id(sectorId)
				.build();
	}
	
	private List<VineUnitWithAptitudes> getVineUnits(ServiceSupportEnv env) {
		List<VineUnitWithAptitudes> vineUnits = vineUnitsDAO.getVineUnitsbyLandCoverIds(env, List.of(env.getLandCoverId()), 0).stream()
				.map(VineUnitMapper.INSTANCE::entityToDtoWithAptitudes)
				.collect(Collectors.toList());

		vineUnits.stream().forEach(unit -> {
			unit.setIsDeletable(false);
			unit.setIsEditable(!(env.getReferenceDate().toLocalDate().isBefore(unit.getPlantingDay().toLocalDate()) && env.getReferenceDate().toLocalDate().isAfter(unit.getEradicateDay().toLocalDate())));
			List<VineAptitude> vineAptitudes = vineUnitsDAO.getVineAptitudes(env, unit.getId(), null, 0).stream()
					.map(VineAptitudesMapper.INSTANCE::entityToDto)
					.collect(Collectors.toList());

			unit.setVineAptitudes(vineAptitudes);
		});

		return vineUnits;
	}
	
	private List<OliveUnit> getOliveUnits(ServiceSupportEnv env) {
		List<OliveUnit> oliveUnits = oliveUnitsDAO.getOliveUnitsbyLandCoverIds(env, List.of(env.getLandCoverId()), 0).stream()
				.map(OliveUnitMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
		
		oliveUnits.stream().forEach(unit -> {
			unit.setIsDeletable(false);
			unit.setIsEditable(!(env.getReferenceDate().toLocalDate().isBefore(unit.getPlantingDay().toLocalDate()) && env.getReferenceDate().toLocalDate().isAfter(unit.getEradicateDay().toLocalDate())));
		});
		
		return oliveUnits;
	}
	
	private List<FruitUnit> getFruitUnits(ServiceSupportEnv env) {
		List<FruitUnit> fruitUnits = fruitUnitsDAO.getFruitUnitsbyLandCoverIds(env, List.of(env.getLandCoverId()), 0).stream()
				.map(FruitUnitMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
		
		fruitUnits.stream().forEach(unit -> {
			unit.setIsDeletable(false);
			unit.setIsEditable(!(env.getReferenceDate().toLocalDate().isBefore(unit.getPlantingDay().toLocalDate()) && env.getReferenceDate().toLocalDate().isAfter(unit.getEradicateDay().toLocalDate())));
		});
		
		return fruitUnits;
	}
	
	private void checkTaskAndPayloadData(ServiceSupportEnv env, TaskManagerData task, CreateEditSessionPayload payload) {
		
		// If sketches in task is not empty and parcel id in payload is defined the parcel must bu inside the sketches
		if(task.getSketches() != null && !task.getSketches().isEmpty() && task.getParcelId()== null && payload.getParcel_id()!= null) {
			
			Geometry sketchesMBR = Utils.getUnion(task.getSketches())
					.buffer(this.internalConf.getDoubleValue(env.getTenantId(), InternalConfigKeys.BUFFER_SIZE_KEY.getKey()))
					.getEnvelope();
			
			ParcelNTT parcelNTT = parcelsDAO.getParcelDetail(env.getTenantId(), payload.getParcel_id(), env.getReferenceDate(), null, DO_NOT_INCLUDE_OUTDATED_PARCELS);
			if(parcelNTT == null) {
				ParcelNotFoundException ex = new ParcelNotFoundException(Status.NOT_FOUND, Operation.SESSION_PREVIEW,
						ErrorField.PARCEL_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
			
			if(!sketchesMBR.intersects(parcelNTT.getGeom())) {
				InvalidSessionParcelTaskGeomException ex = new InvalidSessionParcelTaskGeomException(Status.BAD_REQUEST, Operation.SESSION_PREVIEW,
						ErrorField.PARCEL_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
		}
	}

	private void checkLockGeom(Geometry lockGeometry, ServiceSupportEnv env) {
		editSessionSupportService.checkIfLockGeomIsDefined(lockGeometry, env);

		if (lockGeometry.getArea() < this.internalConf.getDoubleValue(env.getTenantId(), InternalConfigKeys.MINIMUM_VALID_LOCK_AREA_KEY.getKey())) {
			InvalidLockAreaTooSmallException ex = new InvalidLockAreaTooSmallException(Status.BAD_REQUEST,
					Operation.SESSION_PREVIEW, ErrorField.SESSION_LOCK_GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if (lockGeometry.getArea() > this.internalConf.getDoubleValue(env.getTenantId(), InternalConfigKeys.MAXIMUM_VALID_LOCK_AREA_KEY.getKey())) {
			InvalidLockAreaTooLargeException ex = new InvalidLockAreaTooLargeException(Status.BAD_REQUEST,
					Operation.SESSION_PREVIEW, ErrorField.SESSION_LOCK_GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}


	private Long findSectorId(ServiceSupportEnv env, List<Geometry> searchGeometries) {

		if(env.getParcelId() != null) {
			ParcelNTT p = parcelsDAO.getParcelDetail(env.getTenantId(), env.getParcelId(), env.getReferenceDate(), null, DO_NOT_INCLUDE_OUTDATED_PARCELS);
			if(p != null) {
				return p.getSector().getId();
			}		
		}

		Geometry searchGeom = null;

		if(searchGeometries != null && !searchGeometries.isEmpty()) {
			searchGeom = Utils.getUnion(searchGeometries)
					.buffer(this.internalConf.getDoubleValue(env.getTenantId(), InternalConfigKeys.BUFFER_SIZE_KEY.getKey()))
					.getEnvelope();
		}

		if(searchGeom != null) {
			List<SectorNTT> intersectedSectors = sectorDAO.getSectorsWithInteractions(env.getTenantId(), searchGeom, env.getSrs());
			if(intersectedSectors != null && intersectedSectors.size() == 1) {
				return intersectedSectors.get(0).getId();
			}
		}

		return null;
	}

	/**
	 * create a new session
	 * 
	 * @param reqContext
	 * @param payload
	 * @return
	 */
	public EditSession createSession(ReqContext reqContext, CreateEditSessionPayload payload, Boolean keepOtherSession) {

		editSessionSupportService.checkReqContextAndCreateSessionPayload(reqContext, payload, Operation.CREATE_SESSION);

		// First clear old session data and other session of the current user, cleanup edit sessions table
		internalClearSessionsData(reqContext, payload.getParcel_id(), keepOtherSession);

		// The preview check everything before the creations
		SessionPreview sessionData = previewSession(reqContext, payload);
		String tenant = reqContext.getTenantId();

		if (sessionData == null) {
			GenericSessionException ex = new GenericSessionException(Status.BAD_REQUEST, Operation.CREATE_SESSION, null,
					this.errorDescriptionsService.getTenantErrorDescriptions(reqContext.getTenantId()), reqContext.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		// if there are already locked sessions of other users in the preview, I can exit here
		if (sessionData.getSession_with_interaction() > 0) {
			AreaAlreadyLockedException ex = new AreaAlreadyLockedException(Status.CONFLICT,
					Operation.CREATE_SESSION, ErrorField.SESSION_LOCK_GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(reqContext.getTenantId()), reqContext.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if (payload.getReference_date() == null)
			payload.setReference_date(AbsoluteDate.of(LocalDate.now()));

		EditSessionNTT session = EditSessionNTT.builder()
				.uuid(UUID.randomUUID().toString())
				.tenant_id(tenant)
				.user_id(reqContext.getUsername())
				.dt_last_lock(LocalDateTime.now())
				.lock_geom(sessionData.getLock_geom())
				.lock_geom_srs(sessionData.getLock_geom_srs())
				.reference_date(payload.getReference_date())
				.task_id(payload.getTask_id())
				.parcel_id(payload.getParcel_id())
				.build();

		// Receck interactions with lock_geometries
		if (editSessionsDAO.findOtherLockedGeoms(tenant, session.getLock_geom(), session.getUuid(), this.internalConf.getLastValidSessionTime(tenant)) > 0) {
			AreaAlreadyLockedException ex = new AreaAlreadyLockedException(Status.CONFLICT,
					Operation.CREATE_SESSION, ErrorField.SESSION_LOCK_GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(reqContext.getTenantId()), reqContext.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		// commit session data to re-check lock_geometry intersections
		editSessionsDAO.insert(session);
		SessionStatusEnum status = SessionStatusEnum.VALID;

		// re-check lock_geometry intersections after commit
		if (editSessionsDAO.findOtherLockedGeoms(tenant, session.getLock_geom(), session.getUuid(), this.internalConf.getLastValidSessionTime(tenant)) > 0) {
			editSessionsDAO.deleteById(session.getUuid());

			AreaAlreadyLockedException ex = new AreaAlreadyLockedException(Status.CONFLICT,
					Operation.CREATE_SESSION, ErrorField.SESSION_LOCK_GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(reqContext.getTenantId()), reqContext.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		// The session is OK! I can copy the parcels and land covers data in edit tables (lpis_edit_parcel, lpis_edit_land_cover)

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(reqContext.getUser())
				.lang(reqContext.getLang())
				.tenantId(tenant)
				.sessionId(session.getUuid())
				.srs(session.getLock_geom_srs())
				.referenceDate(session.getReference_date())
				.build();

		List<Long> sessionParcelsIds = sessionData.getLocked_parcels().stream().map(Parcel::getId).collect(toList());
		editSessionSupportService.importLockParcelsEdit(env, sessionParcelsIds);

		// Create the session for response...
		EditSession s = EditSessionMapper.INSTANCE.entityToDto(session);
		s.setStatus(status);

		// if editing a task set it to progress
		if (session.getTask_id() != null)
			taskManagerService.updateTaskData(reqContext, session.getTask_id(), " ", null, TASK_TRANSITION_TO_PROGRESS,
					TASK_TRANSITION_TO_PROGRESS_ACCEPATABLE_ERROR_CODES);

		sessionData.getSession_parcels()
		.parallelStream()
		.forEach(sessionParcel -> wmsParcelsFilterDAO.insert(new WmsParcelsFilterNTT(session.getUuid(), sessionParcel.getId()), tenant));

		s.setSector_id(sessionData.getSector_id());

		return s;
	}

	public EditSession getSession(ReqContext reqContext, String sessionId) {

		EditSession s = EditSessionMapper.INSTANCE.entityToDto(editSessionSupportService.getValidSession(reqContext, sessionId));
		s.setStatus(SessionStatusEnum.VALID);
		return s;
	}

	public Boolean deleteSession(User user, ServiceSupportEnv env) {

		EditSessionNTT session = internalGetUserSession(user, env);

		if (!editSessionSupportService.canDelete(session)) {
			InvalidEditSessionException ex = new InvalidEditSessionException(Status.BAD_REQUEST,
					Operation.DELETE_SESSION, ErrorField.SESSION,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Boolean tryClearSession = internalClearAndDeleteSession(session.getUuid());
		if (Boolean.FALSE.equals(tryClearSession)) {
			InvalidEditSessionException ex = new InvalidEditSessionException(Status.BAD_REQUEST,
					Operation.DELETE_SESSION, ErrorField.SESSION,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return true;
	}

	private EditSessionNTT internalGetUserSession(User user, ServiceSupportEnv env) {
		EditSessionNTT session = getUserSession(user, env.getSessionId());
		if (session == null) {
			InvalidEditSessionException ex = new InvalidEditSessionException(Status.BAD_REQUEST,
					Operation.DELETE_SESSION, ErrorField.SESSION,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return session;
	}

	/**
	 * *** Change the status of a session, "DONE" if completed, or "SUSPEND" if cancelled with motivation
	 * 
	 * TODO next release, check that all geometries are correct
	 * 
	 * @param reqContext
	 * @param sessionId
	 * @param payload
	 * @return ok if good
	 */
	@Transaction
	public Response editSession(ReqContext reqContext, String sessionId, UpdateEditSessionPayload payload, Boolean forceNewParcelVersion, boolean preview) {

		checkValidrequest(reqContext, payload);

		EditSessionNTT session = editSessionSupportService.getValidSession(reqContext, sessionId);
		
		EditSession s = EditSessionMapper.INSTANCE.entityToDto(session);
		s.setStatus(SessionStatusEnum.VALID);

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(reqContext.getUser())
				.lang(reqContext.getLang())
				.tenantId(reqContext.getTenantId())
				.sessionId(session.getUuid())
				.srs(session.getLock_geom_srs())
				.referenceDate(session.getReference_date())
				.build();

		checkInvalidEditSessionException(env, session);
		
		// save session...
		if (SESSION_DONE.equals(payload.getNew_status())) {
			
			// Get all data of in edit parcels, with the deleted too (geom = null)
			List<ParcelNTT> inEditParcels = editParcelsDAO.findInEditBySessionId(session.getUuid(), env.getReferenceDate(), null);
			
			SessionCheckResult sessionCheckResult = checkSessionBeforeSave(env, session, inEditParcels, forceNewParcelVersion);
			
			if(!sessionCheckResult.getParcels().isEmpty()) {
				
				InvalidSessionDataException ex = new InvalidSessionDataException(Status.NOT_FOUND,
						Operation.EDIT_SESSION, ErrorField.SESSION_DATA,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());
				
				session.setSessionCheckResult(sessionCheckResult);
				
				// Return a bad request with session data
				return Response.status(IN_SESSION_DATA_WITH_ERRORS_STATUS_CODE_RESPONSE) // special status code for the client 
						.entity(session)
						.build();
			}
			
			Long stackId = saveSession(env, session, payload.getNotes(), payload.getEdit_category_code(), inEditParcels, preview);
			s.setStack_id(stackId);

			s = EditSessionMapper.INSTANCE.entityToDto(session);
			s.setStatus(SessionStatusEnum.VALID);


			// if not in preview update session
			if (!preview) {
				// delete from db
				deleteSession(reqContext.getUser(), env);

				// update session data
				s.setLock_geom(null);
				s.setLock_geom_srs(null);
				s.setStatus(SessionStatusEnum.DONE);

				// call task manager
				if (session.getTask_id() != null) {
					String taskNotes = buildTaskNotes(env, payload);
					taskManagerService.updateTaskData(reqContext, session.getTask_id(), taskNotes, null, 
							TASK_TRANSITION_TO_DONE, null);
				}
			}

		} else if (SESSION_SUSPEND.equals(payload.getNew_status())) {
			
			checkSessionBeforeSuspend(env, payload);
			
			s = EditSessionMapper.INSTANCE.entityToDto(session);
			s.setStatus(SessionStatusEnum.VALID);

			// if not in preview delete session
			if (!preview) {
				deleteSession(reqContext.getUser(), env);
				// update session data
				s.setLock_geom(null);
				s.setLock_geom_srs(null);
				s.setStatus(SessionStatusEnum.EXPIRED);
			}

			// call task manager
			if (session.getTask_id() != null) {
				String taskNotes = buildTaskNotes(env, payload);
				taskManagerService.updateTaskData(reqContext, session.getTask_id(), taskNotes, payload.getTransitionId(),
						TASK_TRANSITION_TO_SUSPEND, null);
			}

		}
		
		return Response.status(Status.OK)
				.entity(s)
				.build();
		
	}
	
	private void checkValidrequest(ReqContext reqContext, UpdateEditSessionPayload payload) {
		if (reqContext == null) {
			InvalidUserEditSessionException ex = new InvalidUserEditSessionException(Status.BAD_REQUEST,
					Operation.EDIT_SESSION, ErrorField.REQUEST_CONTEXT,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if (payload == null) {
			InvalidEditSessionPayloadException ex = new InvalidEditSessionPayloadException(Status.BAD_REQUEST,
					Operation.EDIT_SESSION, ErrorField.PAYLOAD,
					this.errorDescriptionsService.getTenantErrorDescriptions(reqContext.getTenantId()), reqContext.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}


	private String buildTaskNotes(ServiceSupportEnv env, UpdateEditSessionPayload payload) {
		
		if(payload.getEdit_category_code() == null) {
			return payload.getNotes();
		}
		
		EditCategoryNTT editCategoryNTT = supportDAO.getEditCategoryCodeByTenantAndCode(env, payload.getEdit_category_code());
		if(editCategoryNTT == null) {
			InvalidEditCategoryCodeException ex = new InvalidEditCategoryCodeException(Status.NOT_FOUND,
					Operation.EDIT_SESSION, ErrorField.EDIT_CATEGORY_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
			
			log.error(ex.getBody().getLogErrorMessage());
			
			throw ex;
		}
		
		return ((payload.getNotes() == null || payload.getNotes().isBlank()) ? "" : payload.getNotes() + " \n") 
				+ "(" + editCategoryNTT.getCode() + ") " + editCategoryNTT.getDescription();
	}

	
	private void checkSessionBeforeSuspend(ServiceSupportEnv env, UpdateEditSessionPayload payload) {
		
		// When a session is suspended, it is mandatory to insert a note in the description field, otherwise it cannot be suspended (#140067)
		if(null == payload.getNotes() || payload.getNotes().trim().isEmpty()) {
			InvalidSuspendSessionPayloadException ex = new InvalidSuspendSessionPayloadException(Status.NOT_FOUND,
					Operation.SUSPEND_SESSION, ErrorField.NOTES,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
			
			log.error(ex.getBody().getLogErrorMessage());
			
			throw ex;
		}
					
	}
	
	private SessionCheckResult checkSessionBeforeSave(ServiceSupportEnv env, EditSessionNTT session, List<ParcelNTT> inEditParcels, Boolean forceNewParcelVersion) {
		
		// if a parcel version confirmation session import original percel data in editing
		SessionCheckResult forceVersionResponse = editSessionSupportService.checkNewParcelsDeletedDuringSession(env, session, inEditParcels, forceNewParcelVersion);
		if(forceVersionResponse != null) {
			return forceVersionResponse;
		}
		
		// Check the session state for anomalies in data before try to save the session and return the result
		return supportSessionAnomalyService.getSessionErrors(env, inEditParcels);
	}
	
	private Long saveSession(ServiceSupportEnv env, EditSessionNTT session, String notes, String editCategoryCode, List<ParcelNTT> inEditParcels, Boolean preview) {
		
		// for now, if in preview exit with true, perhaps, in the future, it can "simulate" the save without write on DB
		if (Boolean.TRUE.equals(preview))
			return null;
		
		//check editCategoryCode
		checkEditCategoryCode(env, editCategoryCode);
		
		
		return stacksDAO.inTransaction(transaction -> {

			// Init stack parcels table
			StacksNTT stack = StacksNTT
					.builder()
					.id(stacksDAO.nextSequenceVal())
					.tenant_id(env.getTenantId())
					.user_id(env.getUserName())
					.task_id(session.getTask_id())
					.reference_date(env.getReferenceDate())
					.notes(notes)
					.edit_category(EditCategoryNTT.builder().code(editCategoryCode).build())
					.build();
			stacksDAO.insert(stack);

			AbsoluteDate endChangeDate = getEndChangeDate(env, inEditParcels);

			// range1: day_from - refDate-1
			// range2: refDate - endChange
			// range3: endChange+1 - day_to
			for (ParcelNTT parcel : inEditParcels) {
				saveEditParcelInstack(env, session, stack, endChangeDate, parcel);
			}

			// If session parcel is renamed try to find
			setSessionParcelIfRenamed(session, inEditParcels);

			// ---------------------------------------- END EDIT PARCEL SAVE

			// Send new stack
			sendStackOnRabbitMq(stack);
			
			return stack.getId();
			
		});

	}


	private void saveEditParcelInstack(ServiceSupportEnv env, EditSessionNTT session, StacksNTT stack, AbsoluteDate endChangeDate, ParcelNTT parcel) {
		boolean isNewParcel = false;

		// three dates ranges (Previous:Current:Following)
		ThreeDatesRanges ranges = getThreeDatesRanges(env, parcel, endChangeDate);

		// First find the Land Covers in edit, before set the new parcel ID
		List<LandCoverNTT> inEditLandCovers = editLandCoversDAO.findAllLandCoversForEditParcels(env, parcel.getParcel_id());
		
		// current values
		// Parcels
		ParcelNTT currentParcel = parcelsDAO.getParcelDetail(env.getTenantId(), parcel.getParcel_id(), env.getReferenceDate(), null, DO_NOT_INCLUDE_OUTDATED_PARCELS);
		if (currentParcel == null && parcel.getGeom() != null) { // if currentParcel is null it means that parcel is new
			isNewParcel = true;
			currentParcel = insertNewParcel(env, parcel);
			
			if (parcel.getParcel_id().equals(session.getParcel_id()) && !parcel.getParcel_id().equals(currentParcel.getParcel_id())) {
				session.setParcel_id(currentParcel.getParcel_id());
			} else if (parcel.getIn_edit_former_parcel_id() != null && parcel.getIn_edit_former_parcel_id().equals(session.getParcel_id())) {
				session.setParcel_id(currentParcel.getParcel_id());
			}  
		}
		
		List<LandCoverNTT> currentLandCovers = retrieveCurrentLandCoversAndSaveStackParcelLandcover(env, stack, parcel.getParcel_id(), ranges,
				currentParcel,
				inEditLandCovers);

		// outdate the current details row for parcel
		saveStackParcelsAndStackParcelsLandCovers(env, stack, parcel, isNewParcel, ranges, currentParcel, inEditLandCovers, currentLandCovers);
	}

	private boolean editCategoryCanBeNull(ServiceSupportEnv env, String editCategoryCode) {		
		return editCategoryCode != null || internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_ALLOW_NULL_EDIT_CATEGORY.getKey());
	}
	
	private void checkEditCategoryCode(ServiceSupportEnv env, String editCategoryCode) {
		
		if(!editCategoryCanBeNull(env, editCategoryCode) && supportDAO.getEditCategoryCodeByTenantAndCode(env, editCategoryCode) == null) {
			InvalidEditCategoryCodeException ex = new InvalidEditCategoryCodeException(Status.NOT_FOUND,
					Operation.EDIT_SESSION, ErrorField.EDIT_CATEGORY_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}

	private void setSessionParcelIfRenamed(EditSessionNTT session, List<ParcelNTT> inEditParcels) {
		boolean parcelInSession = inEditParcels.stream()
				.anyMatch(p -> (p.getGeom() != null && p.getParcel_id().equals(session.getParcel_id())));

		if (!parcelInSession) {
			session.setParcel_id(
					inEditParcels.stream()
							.filter(p -> (p.getGeom() != null && p.getParent_id() != null && p.getParent_id().equals(session.getParcel_id())))
							.sorted(Comparator.comparingLong(ParcelNTT::getParcel_id))
							.findFirst()
							.orElse(ParcelNTT.builder().parcel_id(null).build())
							.getParcel_id());
		}
	}

	private void checkInvalidEditSessionException(ServiceSupportEnv env, EditSessionNTT session) {
		if (env == null || session == null) {
			InvalidEditSessionException ex = new InvalidEditSessionException(Status.BAD_REQUEST,
					Operation.SAVE_SESSION, ErrorField.SESSION,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
	}
	
	
	private void saveStackParcelsAndStackParcelsLandCovers(ServiceSupportEnv env, StacksNTT stack, ParcelNTT parcel, boolean isNewParcel,
			ThreeDatesRanges ranges, ParcelNTT currentParcel, List<LandCoverNTT> inEditLandCovers, List<LandCoverNTT> currentLandCovers) {
		if (currentParcel != null && currentParcel.getPkid() != null) {
			parcelDetailsDAO.logicallyDeleteByParcelDetailsId(currentParcel.getPkid(), env.getUserId());
			if(!ranges.preFromIsBeforePreTo() && !ranges.followToIsAfterFollowFrom())
				saveStackParcel(true, stack.getId(), currentParcel.getPkid());
		}


		saveStackParcelsLandCovers(env, stack, parcel, isNewParcel, ranges, currentParcel, inEditLandCovers, currentLandCovers);
	}

	private void saveStackParcelsLandCovers(ServiceSupportEnv env, StacksNTT stack, ParcelNTT parcel, boolean isNewParcel, ThreeDatesRanges ranges,
			ParcelNTT currentParcel, List<LandCoverNTT> inEditLandCovers, List<LandCoverNTT> currentLandCovers) {
		// -------------------------------------------------------------------- PRE

		if (!isNewParcel && currentParcel != null && ranges.preFromIsBeforePreTo()) {

			insertLandCovers(env, currentParcel, currentLandCovers, ranges.getPrevious(), stack.getId(), true, true);

		}

		// -------------------------------------------------------------------- THIS

		if (parcel.getGeom() != null) { // it is not deleted

			insertLandCovers(env, parcel, inEditLandCovers, ranges.getCurrent(), stack.getId(), false, true);
			
		}

		// -------------------------------------------------------------------- POST

		if (!isNewParcel && currentParcel != null && ranges.followToIsAfterFollowFrom()) {
			// rewrite the old parcel state valid until the reference date of the edit
			insertLandCovers(env, currentParcel, currentLandCovers, ranges.getFollowing(), stack.getId(), true, false);

		}
	}

	private List<LandCoverNTT> retrieveCurrentLandCoversAndSaveStackParcelLandcover(ServiceSupportEnv env, StacksNTT stack, Long parcelId,
			ThreeDatesRanges ranges, ParcelNTT currentParcel, List<LandCoverNTT> inEditLandCovers) {
		// Check for landcovers
		List<LandCoverNTT> currentLandCovers = new ArrayList<>();
		for (LandCoverNTT lc : inEditLandCovers) {
			LandCoverNTT currentLandCover = landCoversDAO.getLandCoverDetail(env, lc.getLand_cover_id());
			if(currentLandCover != null) {
				lc.setFormer_land_cover_details_id(currentLandCover.getLand_cover_details_id());
			}

			if (currentLandCover == null && lc.getGeom() != null) { // if currentLandCover is null it means that is a new land cover

				lc.setIn_edit_former_land_cover_id(lc.getLand_cover_id());
				lc.setLand_cover_id(landCoversDAO.nextSequenceVal());

				currentLandCover = LandCoverNTT
						.builder()
						.land_cover_id(lc.getLand_cover_id())
						.parcel_id(parcelId)
						.land_cover_code(lc.getLand_cover_code())
						.day_from(lc.getDay_from())
						.day_to(lc.getDay_to())
						.srs(env.getSrs())
						.geom(lc.getGeom())
						.area_sqm(lc.getGeom().getArea())
						.world_geom(null) // if world_geom is null is a new land cover
						.build();

				landCoversDAO.insert(currentLandCover);

			}

			if (currentLandCover != null) {
				currentLandCovers.add(currentLandCover);

				// outdate the current details row for landcover
				if (currentLandCover.getLand_cover_details_id() != null) {
					outdateCurrentLandCoverDetailRow(env, stack.getId(), currentParcel, currentLandCover.getLand_cover_details_id(), ranges);
				}
			}
		}
		return currentLandCovers;
	}
	
	private void outdateCurrentLandCoverDetailRow(ServiceSupportEnv env, Long stackId, ParcelNTT currentParcel, Long currLcDetailId, 
			ThreeDatesRanges ranges) {
		landCoversDetailsDAO.logicallyDeleteByLandCoverDetailsId(currLcDetailId, env.getUserId());
		if (currentParcel != null && currentParcel.getPkid() != null && !ranges.preFromIsBeforePreTo() && !ranges.followToIsAfterFollowFrom()) {
			saveStackParcelLandCover(stackId, currentParcel.getPkid(), currLcDetailId);
		}
	}

	private ParcelNTT insertNewParcel(ServiceSupportEnv env, ParcelNTT parcel) {
		boolean doInsert = false;

		if (parcel.getParcel_id() < 0) {
			doInsert = true;
			parcel.setIn_edit_former_parcel_id(parcel.getParcel_id());
			parcel.setParcel_id(parcelsDAO.nextSequenceVal());
		}

		if (parcel.getBlock() == null || parcel.getBlock().getId() == null) {
			List<BlockNTT> blocksInter = blockDAO.findBlocksByTenantSRSWithInteraction(env.getTenantId(), env.getSrs(), parcel.getGeom());
			if (blocksInter == null || blocksInter.isEmpty()) {
				ParcelBlockNotValidException ex = new ParcelBlockNotValidException(Status.BAD_REQUEST,
						Operation.SAVE_SESSION, ErrorField.BLOCK,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}

			parcel.setBlock(BlockNTT.builder().id(blocksInter.get(0).getId()).build());
		}

		ParcelNTT currentParcel = ParcelNTT
				.builder()
				.tenant_id(env.getTenantId())
				.parcel_id(parcel.getParcel_id())
				.parcel(parcel.getParcel())
				.block(parcel.getBlock())
				.day_from(parcel.getDay_from())
				.day_to(parcel.getDay_to())
				.srs(env.getSrs())
				.geom(parcel.getGeom())
				.world_geom(reproject(parcel.getGeom(), getCRS(env.getSrs()), toWorldCRS))
				.external_code(parcel.getExternal_code())
				.build();

		if (doInsert)
			parcelsDAO.insert(currentParcel);

		return currentParcel;
	}

	private void insertLandCovers(ServiceSupportEnv env, ParcelNTT parcel, List<LandCoverNTT> landCoverList, 
			DatesFromTo range, Long stackId, boolean isParent, boolean saveUnits) {

		ParcelDetailsNTT p = getSaveParcel(parcel, range, getCRS(env.getSrs()));

		parcelDetailsDAO.insert(p, env.getUserId());

		saveStackParcel(isParent, stackId, p.getPkid());

		// land covers
		for (LandCoverNTT lc : landCoverList) {
			if ((lc.getGeom() != null && (!isParent || lc.getWorld_geom() != null))) {
				
				lc.setFormer_land_cover_details_id(lc.getLand_cover_details_id());
				lc.setLand_cover_details_id(landCoversDetailsDAO.nextSequenceVal());

				landCoversDetailsDAO.insert(
						getSaveLandcover(lc, range, getCRS(env.getSrs())),
						env.getUserId());

				saveStackParcelLandCover(stackId, p.getPkid(), lc.getLand_cover_details_id());
				
				// XXX is it ok? If I do it outside I'll lose the stackid...
				if(saveUnits) {
					editSessionSupportService.insertVineUnits(env, stackId, lc, isParent);
					editSessionSupportService.insertOliveUnits(env, stackId, lc, isParent);
					editSessionSupportService.insertFruitUnits(env, stackId, lc, isParent);
				}
			}
		}

	}

	private LandCoverNTT getSaveLandcover(LandCoverNTT lc, DatesFromTo dateRange, CoordinateReferenceSystem fromCRS) {
		return LandCoverNTT
				.builder()
				.land_cover_details_id(lc.getLand_cover_details_id())
				.land_cover_id(lc.getLand_cover_id())
				.day_from(dateRange.getFrom())
				.day_to(dateRange.getTo())
				.srs(lc.getSrs())
				.land_cover_code(lc.getLand_cover_code())
				.area_sqm(lc.getGeom() != null ? lc.getGeom().getArea() : 0)
				.geom(lc.getGeom())
				.world_geom(reproject(lc.getGeom(), fromCRS, toWorldCRS))
				.edit_status(convertDetailsEditStatus(lc.getEdit_status()))
				.build();
	}

	private ParcelDetailsNTT getSaveParcel(ParcelNTT parcel, DatesFromTo dateRange, CoordinateReferenceSystem fromCRS) {
		return ParcelDetailsNTT
				.builder()
				.pkid(parcelDetailsDAO.nextSequenceVal())
				.parcel_id(parcel.getParcel_id())
				.day_from(dateRange.getFrom())
				.day_to(dateRange.getTo())
				.srs(parcel.getSrs())
				.area_sqm(parcel.getGeom() != null ? parcel.getGeom().getArea() : 0)
				.geom(parcel.getGeom())
				.world_geom(reproject(parcel.getGeom(), fromCRS, toWorldCRS))
				.edit_status(convertDetailsEditStatus(parcel.getEdit_status()))
				.build();
	}
	

	private EditStatus convertDetailsEditStatus(EditStatus toConvert) {
		EditStatus status = toConvert;
		if (toConvert == null) {
			status = EditStatus.INHERITED;
		} else if (toConvert.equals(EditStatus.IN_EDIT)) {
			status = EditStatus.EDITED;
		} else if (toConvert.equals(EditStatus.LOCKED)) {
			status = EditStatus.VERSION_UPDATE;
		}

		return status;
	}

	private ThreeDatesRanges getThreeDatesRanges(ServiceSupportEnv env, ParcelNTT parcel, AbsoluteDate endChangeDate) {
		ThreeDatesRanges ranges = new ThreeDatesRanges();

		ranges.setPrevious(new DatesFromTo(parcel.getDay_from(), AbsoluteDate.of(env.getReferenceDate().toLocalDate().minusDays(1L))));

		ranges.setCurrent(new DatesFromTo(env.getReferenceDate(), endChangeDate));

		ranges.setFollowing(new DatesFromTo(AbsoluteDate.of(endChangeDate.toLocalDate().plusDays(1L)), parcel.getDay_to()));

		return ranges;
	}

	private AbsoluteDate getEndChangeDate(ServiceSupportEnv env, List<ParcelNTT> inEditParcels) {
		// check day_from day_to and reference date for each parcel, and land cover, edited
		AbsoluteDate endChangeDate = inEditParcels
				.stream()
				.min(Comparator.comparing(p -> p.getDay_to().toLocalDate()))
				.map(ParcelNTT::getDay_to)
				.orElse(AbsoluteDate.of("99991231"));

		// SpaceTime intersections search for endChangeDate
		// find future parcels intersect with all geometries
		List<Geometry> allParcelsGeoms = inEditParcels.stream().filter(p -> p.getGeom() != null).map(ParcelNTT::getGeom).collect(toList());
		if (allParcelsGeoms != null && !allParcelsGeoms.isEmpty()) {
			Geometry unitedParcelsGeom = Utils.getUnion(allParcelsGeoms);
			AbsoluteDate firstSpaceTimeIntersect = parcelDetailsDAO.findFirstDayFromParcelsSpaceTimeInterect(env, unitedParcelsGeom, endChangeDate);
			if (firstSpaceTimeIntersect != null && firstSpaceTimeIntersect.toLocalDate().isBefore(endChangeDate.toLocalDate()))
				endChangeDate = AbsoluteDate.of(firstSpaceTimeIntersect.toLocalDate().minusDays(1));
		}
		return endChangeDate;
	}

	private void saveStackParcel(boolean isParent, Long stackId, long parcelDetailsPkid) {

		StackParcelsNTT stp = StackParcelsNTT
				.builder()
				.pkid(stackParcelsDAO.nextSequenceVal())
				.stack_id(stackId)
				.fl_parent(isParent ? 1L : 0L)
				.parcel_pkid(parcelDetailsPkid)
				.build();
		stackParcelsDAO.insert(stp);

	}

	private void saveStackParcelLandCover(Long stackId, Long parcelDetailsPkid, Long landCoverDetailsPkid) {

		StackLandCoversNTT stl = StackLandCoversNTT.builder()
				.parcel_pkid(parcelDetailsPkid)
				.pkid(stackLandCoversDAO.nextSequenceVal())
				.land_cover_pkid(landCoverDetailsPkid)
				.stack_id(stackId)
				.build();

		stackLandCoversDAO.insert(stl);

	}

	private void internalClearSessionsData(ReqContext reqContext, Long parcelId, Boolean keepOtherSessionParam) {

		Boolean keepOtherSession = keepOtherSessionParam && sso2Client.isFunctionEnabled(reqContext.getUser(), new UserFunction(CONTEXT_ID_LPIS, ALLOW_MULTIPLE_EDIT_SESSIONS));
		
		String tenant = reqContext.getTenantId();
		LocalDateTime sessionDeadTime = this.internalConf.getLastValidSessionTime(tenant).minusHours(2);
		String userId = reqContext.getUser().getName();

		List<EditSessionNTT> otherSessions = editSessionsDAO.findByTenantId(tenant);
		otherSessions.stream()
		.filter(s -> (s.getDt_last_lock().isBefore(sessionDeadTime) // filter for old
				|| (!keepOtherSession && s.getUser_id().equals(userId)) // do not keep multiple session for user
				|| (s.getUser_id().equals(userId) && parcelId != null && parcelId.equals(s.getParcel_id()))))  // another session with same parcel id
		.forEach(s -> internalClearAndDeleteSession(s.getUuid()));

	}

	private Boolean internalClearAndDeleteSession(String sessionId) {

		editParcelsDAO.deleteBySessionId(sessionId);
		editLandCoversDAO.deleteBySessionId(sessionId);
		lockParcelsDAO.deleteBySessionUuid(sessionId);
		editSessionsDAO.deleteById(sessionId);

		wmsParcelsFilterDAO.deleteBySessionId(sessionId);

		return editSessionsDAO.findById(sessionId) == null;

	}

	public EditSessionNTT getUserSession(User user, String sessionId) {
		if (user == null) {
			InvalidUserEditSessionException ex = new InvalidUserEditSessionException(Status.BAD_REQUEST,
					Operation.GET_ANOMALIES, ErrorField.REQUEST_CONTEXT,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return editSessionsDAO.findUserSession(sessionId, user.getTenant(), user.getName());
	}

	private void sendStackOnRabbitMq(StacksNTT stack) {
		List<StackParcelsNTT> stackParcels = stackParcelsDAO.findStackParcelsById(stack.getId());

		List<StackParcelsPayload> stackParcelsPayload = new ArrayList<>();
		if (stackParcels != null) {
			stackParcels.forEach(stackParcel -> stackParcelsPayload.add(
					StackParcelsPayload.builder()
					.fl_parent(stackParcel.getFl_parent())
							.parcel_pkid(stackParcel.getParcel_pkid())
					.pkid(stackParcel.getPkid())
					.stack_id(stackParcel.getStack_id())
					.build()));
		}

		StackPayload stackPayload = StackPayload.builder()
				.dt_operation(stack.getDt_operation())
				.id(stack.getId())
				.reference_date(stack.getReference_date())
				.task_id(stack.getTask_id())
				.user_id(stack.getUser_id())
				.stack_parcels(stackParcelsPayload)
				.tenant_id(stack.getTenant_id())
				.notes(stack.getNotes())
				.build();

		if (stackMessageQueue != null) {
			stackMessageQueue.add(stackPayload, System.currentTimeMillis());
		}

	}

	@Data
	@AllArgsConstructor
	class DatesFromTo {
		private AbsoluteDate from;
		private AbsoluteDate to;
	}

	@Data
	class ThreeDatesRanges {
		private DatesFromTo previous;
		private DatesFromTo current;
		private DatesFromTo following;

		public boolean preFromIsBeforePreTo() {
			return this.previous.getFrom().toLocalDate().isBefore(this.previous.getTo().toLocalDate());
		}

		public boolean followToIsAfterFollowFrom() {
			return this.getFollowing().getTo().toLocalDate().isAfter(this.getFollowing().getFrom().toLocalDate());
		}

	}
}
