package com.abacogroup.lpisgisserver.core.exceptions.landcover;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidLandCoverGeometryException extends AbstractException {

	private static final long serialVersionUID = -164873366696701432L;

	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_LANDCOVER_GEOM;

	public InvalidLandCoverGeometryException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new InvalidLandCoverGeometryExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Land cover geometry is not valid")
	public static class InvalidLandCoverGeometryExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 6313495485314748690L;

		public InvalidLandCoverGeometryExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}

	}
}
