package com.abacogroup.lpisgisserver.core.config.georaster;

import lombok.Data;

@Data
public class GeorasterConfig {
	private String url;
	private String env;
	private String auth;
}
