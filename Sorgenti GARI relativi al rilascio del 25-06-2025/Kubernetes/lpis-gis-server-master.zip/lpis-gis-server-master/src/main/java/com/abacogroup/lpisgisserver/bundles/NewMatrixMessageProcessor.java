package com.abacogroup.lpisgisserver.bundles;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.bundles.models.MatrixDeleteMessage;
import com.abacogroup.lpisgisserver.bundles.models.MatrixInsertMessage;
import com.abacogroup.lpisgisserver.bundles.models.NewMatrixMetadataMessage;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassLandUsesDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixLandUsesMetadataDAO;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassLandusesNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassesNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixLandUsesMetadataNTT;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.BadRequestException;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;

public class NewMatrixMessageProcessor extends AbstractMessageProcessor {
	private final ObjectMapper objectMapper = new ObjectMapper();
	private static final Logger log = LoggerFactory.getLogger(NewMatrixMessageProcessor.class);

	private final MatrixClassDAO matrixClassDAO;
	private final MatrixClassLandUsesDAO matrixClassLandUsesDAO;
	private final MatrixLandUsesMetadataDAO matrixLandUsesMetadataDAO;

	private final List<String> metadataKeysToDelete = List.of("defaultFromDate", "defaultHarvestDays");
	private final String processorOperationAuthor = "importMatrixMetadataBundle";

	public NewMatrixMessageProcessor(DAOContainer daoContainer) {
		super(daoContainer);
		this.matrixClassDAO = daoContainer.getMatrixClassDAO();
		this.matrixClassLandUsesDAO = daoContainer.getMatrixClassLandUsesDAO();
		this.matrixLandUsesMetadataDAO = daoContainer.getMatrixLandUsesMetadataDAO();
	}

	@Override
	public String getDomainName() {
		return "matrix-update";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		// Send to deleteMatrixesMessage method file that is not a directory and finish with .delete.jsonl
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.jsonl"))
				.forEach(file -> deleteMatrixesMessage(message.getTenantId(), file));

		// Send to insertOrUpdateMatrixesMessage method file that is not a directory and not finish with .delete.jsonl, but finish with .jsonl
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("jsonl")
						&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.jsonl"))
				.forEach(file -> insertOrUpdateMatrixesMessage(message.getTenantId(), file));
	}

	private void deleteMatrixesMessage(String tenantId, File file) {
		List<MatrixDeleteMessage> matrixDeleteMessages = convertFileToListOfMatrixDeleteMessage(file);

		Map<String, Set<String>> matrixToClassCodes = matrixDeleteMessages.stream()
				.collect(Collectors.groupingBy(
						MatrixDeleteMessage::getMatrixCode,
						Collectors.mapping(MatrixDeleteMessage::getClassCode, Collectors.toSet())
				));

		Map<String, Long> matrixCodeWithId = checkMatrixCodeAndClassesConsistencyAndReturnMatrixCodeWithId(matrixToClassCodes);

		// For each line of delete jsonl matrix file
		for (MatrixDeleteMessage matrixDeleteMessage : matrixDeleteMessages) {
			// Retrive matrixId
			Long matrixId = matrixCodeWithId.get(matrixDeleteMessage.getMatrixCode());

			/*** MATRIX ***/
			// Find all matrix class landuses with validity period that intersect jsonl validity period
			List<MatrixClassLandusesNTT> matrixClassLandusesByTimeInterval = matrixClassLandUsesDAO.getMatrixClassLandusesByTimeInterval(matrixId,
					matrixDeleteMessage.getClassCode(), matrixDeleteMessage.getCode(),
					matrixDeleteMessage.getDayFrom(), matrixDeleteMessage.getDayTo());

			// If found, cycle them
			if (!matrixClassLandusesByTimeInterval.isEmpty()) {
				for (MatrixClassLandusesNTT matrixClassLandusesNTT : matrixClassLandusesByTimeInterval) {
					// Delete current element
					matrixClassLandUsesDAO.logicallyDeleteByMatrixIdClassCodeAndLandUseCode(matrixClassLandusesNTT.getMatrix_id(),
							matrixClassLandusesNTT.getClass_code(), matrixClassLandusesNTT.getLanduse().getCode(), processorOperationAuthor);

					// If the delete validity period start inside current element validity
					// then it means we need to persist the old untouched start validity period
					if (matrixDeleteMessage.getDayFrom().isBetween(matrixClassLandusesNTT.getDay_from(), matrixClassLandusesNTT.getDay_to())) {
						matrixClassLandUsesDAO.insertWithParams(matrixClassLandusesNTT.getMatrix_id(), matrixClassLandusesNTT.getClass_code(),
								matrixClassLandusesNTT.getLanduse().getCode(), matrixClassLandusesNTT.getDay_from(),
								AbsoluteDate.of(matrixDeleteMessage.getDayFrom().toLocalDate().minusDays(1)), processorOperationAuthor);
					}

					// If the delete validity period end inside current element validity
					// then it means we need to persist the old untouched end validity period
					if (matrixDeleteMessage.getDayTo().isBetween(matrixClassLandusesNTT.getDay_from(), matrixClassLandusesNTT.getDay_to())) {
						matrixClassLandUsesDAO.insertWithParams(matrixClassLandusesNTT.getMatrix_id(), matrixClassLandusesNTT.getClass_code(),
								matrixClassLandusesNTT.getLanduse().getCode(), AbsoluteDate.of(matrixDeleteMessage.getDayTo().toLocalDate().plusDays(1)),
								matrixClassLandusesNTT.getDay_to(), processorOperationAuthor);
					}
				}
			}

			/*** MATRIX METADATA ***/
			for (String metadataKeyToDelete : metadataKeysToDelete) {
				// Find all matrix class landuses metadata with validity period that intersect jsonl validity period
				List<MatrixLandUsesMetadataNTT> landUsesMetadataByTimeInterval = matrixLandUsesMetadataDAO.getLandUsesMetadataByTimeInterval(tenantId, matrixId,
						matrixDeleteMessage.getClassCode(), matrixDeleteMessage.getCode(), matrixDeleteMessage.getDayFrom(), matrixDeleteMessage.getDayTo(),
						metadataKeyToDelete);

				if (!landUsesMetadataByTimeInterval.isEmpty()) {
					for (MatrixLandUsesMetadataNTT landUsesMetadataNTT : landUsesMetadataByTimeInterval) {
						// Delete current element
						matrixLandUsesMetadataDAO.logicallyDelete(landUsesMetadataNTT, processorOperationAuthor);

						// If the delete validity period start inside current element validity
						// then it means we need to persist the old untouched start validity period
						if (matrixDeleteMessage.getDayFrom().isBetween(landUsesMetadataNTT.getDay_from(), landUsesMetadataNTT.getDay_to())) {
							matrixLandUsesMetadataDAO.insertWithParams(tenantId, landUsesMetadataNTT.getMatrix_id(), landUsesMetadataNTT.getClass_code(),
									landUsesMetadataNTT.getLand_use_code(), landUsesMetadataNTT.getKey(), landUsesMetadataNTT.getValue(),
									landUsesMetadataNTT.getDay_from(), AbsoluteDate.of(matrixDeleteMessage.getDayFrom().toLocalDate().minusDays(1)),
									processorOperationAuthor);
						}

						// If the delete validity period end inside current element validity
						// then it means we need to persist the old untouched end validity period
						if (matrixDeleteMessage.getDayTo().isBetween(landUsesMetadataNTT.getDay_from(), landUsesMetadataNTT.getDay_to())) {
							matrixLandUsesMetadataDAO.insertWithParams(tenantId, landUsesMetadataNTT.getMatrix_id(), landUsesMetadataNTT.getClass_code(),
									landUsesMetadataNTT.getLand_use_code(), landUsesMetadataNTT.getKey(), landUsesMetadataNTT.getValue(),
									AbsoluteDate.of(matrixDeleteMessage.getDayTo().toLocalDate().plusDays(1)), landUsesMetadataNTT.getDay_to(),
									processorOperationAuthor);
						}
					}
				}
			}
		}
	}

	private void insertOrUpdateMatrixesMessage(String tenantId, File file) {
		List<MatrixInsertMessage> matrixInsertMessages = convertFileToListOfMatrixInsertMessage(file);

		Map<String, Set<String>> matrixToClassCodes = matrixInsertMessages.stream()
				.collect(Collectors.groupingBy(
						MatrixInsertMessage::getMatrixCode,
						Collectors.mapping(MatrixInsertMessage::getClassCode, Collectors.toSet())
				));

		Map<String, Long> matrixCodeWithId = checkMatrixCodeAndClassesConsistencyAndReturnMatrixCodeWithId(matrixToClassCodes);

		for (MatrixInsertMessage matrixInsertMessage : matrixInsertMessages) {
			// Retrive matrixId
			Long matrixId = matrixCodeWithId.get(matrixInsertMessage.getMatrixCode());

			/*** MATRIX ***/
			// Find all matrix class landuses with validity period that intersect jsonl validity period
			List<MatrixClassLandusesNTT> matrixClassLandusesByTimeInterval = matrixClassLandUsesDAO.getMatrixClassLandusesByTimeInterval(matrixId,
					matrixInsertMessage.getClassCode(), matrixInsertMessage.getCode(), matrixInsertMessage.getDayFrom(), matrixInsertMessage.getDayTo());

			if (matrixClassLandusesByTimeInterval.isEmpty()) {
				// We can insert the record as it is
				matrixClassLandUsesDAO.insertWithParams(matrixId, matrixInsertMessage.getClassCode(), matrixInsertMessage.getCode(),
						matrixInsertMessage.getDayFrom(), matrixInsertMessage.getDayTo(), processorOperationAuthor);
			} else {
				// Init smallestDayFrom and higherDayToDate from insert message
				AbsoluteDate smallestDayFromDate = matrixInsertMessage.getDayFrom();
				AbsoluteDate higherDayToDate = matrixInsertMessage.getDayTo();

				// For every record found in interval
				for (MatrixClassLandusesNTT matrixClassLandusesNTT : matrixClassLandusesByTimeInterval) {
					// Delete current record
					matrixClassLandUsesDAO.logicallyDeleteByMatrixIdClassCodeAndLandUseCode(matrixClassLandusesNTT.getMatrix_id(),
							matrixClassLandusesNTT.getClass_code(), matrixClassLandusesNTT.getLanduse().getCode(), processorOperationAuthor);

					// Search if there is a new smallest or higher date
					if (!smallestDayFromDate.isBefore(matrixClassLandusesNTT.getDay_from())) {
						smallestDayFromDate = matrixClassLandusesNTT.getDay_from();
					}

					if (!higherDayToDate.isAfter(matrixClassLandusesNTT.getDay_to())) {
						higherDayToDate = matrixClassLandusesNTT.getDay_to();
					}
				}

				//	Create a new record with the max validity date found
				matrixClassLandUsesDAO.insertWithParams(matrixId, matrixInsertMessage.getClassCode(), matrixInsertMessage.getCode(), smallestDayFromDate,
						higherDayToDate, processorOperationAuthor);
			}

			/*** MATRIX METADATA ***/
			for (NewMatrixMetadataMessage matrixMetadataMessage : matrixInsertMessage.getMetadata()) {
				// Find all matrix class landuses metadata with validity period that intersect jsonl validity period
				List<MatrixLandUsesMetadataNTT> landUsesMetadataByTimeInterval = matrixLandUsesMetadataDAO.getLandUsesMetadataByTimeInterval(tenantId, matrixId,
						matrixInsertMessage.getClassCode(), matrixInsertMessage.getCode(), matrixInsertMessage.getDayFrom(), matrixInsertMessage.getDayTo(),
						matrixMetadataMessage.getKey());

				if (!landUsesMetadataByTimeInterval.isEmpty()) {
					for (MatrixLandUsesMetadataNTT landUsesMetadataNTT : landUsesMetadataByTimeInterval) {
						// Delete current record
						matrixLandUsesMetadataDAO.logicallyDelete(landUsesMetadataNTT, processorOperationAuthor);

						// If the delete validity period start inside current element validity
						// then it means we need to persist the old untouched start validity period
						if (matrixInsertMessage.getDayFrom().isBetween(landUsesMetadataNTT.getDay_from(), landUsesMetadataNTT.getDay_to())) {
							matrixLandUsesMetadataDAO.insertWithParams(tenantId, landUsesMetadataNTT.getMatrix_id(), landUsesMetadataNTT.getClass_code(),
									landUsesMetadataNTT.getLand_use_code(), landUsesMetadataNTT.getKey(), landUsesMetadataNTT.getValue(),
									landUsesMetadataNTT.getDay_from(), AbsoluteDate.of(matrixInsertMessage.getDayFrom().toLocalDate().minusDays(1)),
									processorOperationAuthor);
						}

						// If the delete validity period end inside current element validity
						// then it means we need to persist the old untouched end validity period
						if (matrixInsertMessage.getDayTo().isBetween(landUsesMetadataNTT.getDay_from(), landUsesMetadataNTT.getDay_to())) {
							matrixLandUsesMetadataDAO.insertWithParams(tenantId, landUsesMetadataNTT.getMatrix_id(), landUsesMetadataNTT.getClass_code(),
									landUsesMetadataNTT.getLand_use_code(), landUsesMetadataNTT.getKey(), landUsesMetadataNTT.getValue(),
									AbsoluteDate.of(matrixInsertMessage.getDayTo().toLocalDate().plusDays(1)), landUsesMetadataNTT.getDay_to(),
									processorOperationAuthor);
						}
					}
				}

				// We can insert the record as it is
				matrixLandUsesMetadataDAO.insertWithParams(tenantId, matrixId, matrixInsertMessage.getClassCode(), matrixInsertMessage.getCode(),
						matrixMetadataMessage.getKey(), matrixMetadataMessage.getValue(), matrixInsertMessage.getDayFrom(), matrixInsertMessage.getDayTo(),
						processorOperationAuthor);
			}
		}
	}

	private Map<String, Long> checkMatrixCodeAndClassesConsistencyAndReturnMatrixCodeWithId(Map<String, Set<String>> matrixesToClassCodes) {
		Map<String, Long> matrixCodeWithId = new HashMap<>();

		for (Map.Entry<String, Set<String>> matrixToClassCodes : matrixesToClassCodes.entrySet()) {
			String matrixCode = matrixToClassCodes.getKey();
			Set<String> requestedClassCodes = matrixToClassCodes.getValue();

			List<MatrixClassesNTT> dbMatrixClasses = matrixClassDAO.getMatrixCodeClasses(matrixCode);
			if (dbMatrixClasses.isEmpty()) {
				throw new BadRequestException("No matrix found for code: " + matrixCode);
			}

			Set<String> dbClassCodes = dbMatrixClasses.stream()
					.map(MatrixClassesNTT::getCode)
					.collect(Collectors.toSet());

			if (!dbClassCodes.containsAll(requestedClassCodes)) {
				throw new BadRequestException("Matrix code " + matrixCode + " is missing some of the requested classes");
			}

			// I can assume get on index 0 because all records will have same matrix id
			matrixCodeWithId.put(matrixCode, dbMatrixClasses.get(0).getMatrix_id());
		}

		return matrixCodeWithId;
	}

	private List<MatrixDeleteMessage> convertFileToListOfMatrixDeleteMessage(File file) {
		List<MatrixDeleteMessage> matrixDeleteMessages = new ArrayList<>();

		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String line;
			while ((line = reader.readLine()) != null) {
				MatrixDeleteMessage matrixDeleteMessage = objectMapper.readValue(line, MatrixDeleteMessage.class);
				matrixDeleteMessages.add(matrixDeleteMessage);
			}
		} catch (IOException e) {
			logFileReadError(file, e);
		}

		return matrixDeleteMessages;
	}

	private List<MatrixInsertMessage> convertFileToListOfMatrixInsertMessage(File file) {
		List<MatrixInsertMessage> matrixInsertMessages = new ArrayList<>();

		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String line;
			while ((line = reader.readLine()) != null) {
				MatrixInsertMessage matrixInsertMessage = objectMapper.readValue(line, MatrixInsertMessage.class);
				matrixInsertMessages.add(matrixInsertMessage);
			}
		} catch (IOException e) {
			logFileReadError(file, e);
		}

		return matrixInsertMessages;
	}

	private void logFileReadError(File file, Exception e) {
		log.error("Error during read file {}", file.getAbsolutePath(), e);
	}
}
