package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.LandCoversCodeNTT;
import com.abacogroup.lpisgisserver.resources.res.pub.LandCoversCodeV1;

@Mapper
public interface LandCoversCodeV1Mapper {

	LandCoversCodeV1Mapper INSTANCE = Mappers.getMapper(LandCoversCodeV1Mapper.class);

	@Mapping(source = "code", target = "land_cover_code")
	@Mapping(target = "unit_types", ignore = true)	
	LandCoversCodeV1 entityToDto(LandCoversCodeNTT entity);

	@Mapping(source = "land_cover_code", target = "code")
	LandCoversCodeNTT dtoToEntity(LandCoversCodeV1 dto);
}
