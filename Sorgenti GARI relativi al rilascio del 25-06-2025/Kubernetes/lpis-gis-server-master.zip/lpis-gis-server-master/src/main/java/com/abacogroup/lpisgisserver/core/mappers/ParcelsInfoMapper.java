package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.resources.res.info.ParcelInfo;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ParcelsInfoMapper {

	ParcelsInfoMapper INSTANCE = Mappers.getMapper(ParcelsInfoMapper.class);

	@InheritInverseConfiguration()
	@Mapping(source = "block.block", target = "block.block_code")
	ParcelInfo entityToDto(ParcelNTT entity);

	@Mapping(source = "id", target = "parcel_id")
	@Mapping(target = "edit_id", ignore = true)
	@Mapping(target = "pkid", ignore = true)
	@Mapping(target = "tenant_id", ignore = true)
	@Mapping(target = "sector", ignore = true)
	@Mapping(target = "stack", ignore = true)
	@Mapping(source = "block.block_code", target = "block.block")
	@Mapping(target = "block.block_details_id", ignore = true)
	@Mapping(target = "block.srs", ignore = true)
	@Mapping(target = "block.geom", ignore = true)
	@Mapping(target = "block.world_geom", ignore = true)
	@Mapping(target = "block.id", ignore = true)
	@Mapping(target = "block.sector_id", ignore = true)
	@Mapping(target = "edit_status", ignore = true)
	@Mapping(target = "last_update", ignore = true)
	@Mapping(target = "parent_id", ignore = true)
	@Mapping(target = "editorResultParcelId", ignore = true)
	@Mapping(target = "sde_code", ignore = true)
	ParcelNTT dtoToEntity(ParcelInfo dto);

}
