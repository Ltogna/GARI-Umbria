package com.abacogroup.lpisgisserver.core;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.DatePrecision;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.UnitDictionaryTables;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.ErrorItem;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;
import com.abacogroup.lpisgisserver.core.exceptions.units.vine.VineAptitudeNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.units.vine.VineUnitNotFoundException;
import com.abacogroup.lpisgisserver.core.mappers.units.VineAptitudesMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.VineUnitMapper;
import com.abacogroup.lpisgisserver.core.support.EditorSupportParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditVineUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.CultivationStatusNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.FarmingFormNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.HeaderAnchoringNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.IrrigationNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.PolesHeaderNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.PolesWeavingNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.ProductDestinationNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.SupportWiresNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.TerracingNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.VariationTypeNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.VarietyNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineAptitudeNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineDoIgtNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineUnitDetailsNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.CreateOrUpdateVineAptitudesPayload;
import com.abacogroup.lpisgisserver.resources.req.pub.CreateOrUpdateVineUnitPayloadV1;
import com.abacogroup.lpisgisserver.resources.res.LandCoverWithUnits;
import com.abacogroup.lpisgisserver.resources.res.LandCoversEditResult;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineAptitude;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnitWithAptitudes;

import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EditVineUnitsSupportService extends BaseService {

	private final UnitsSupportService unitsSupportService;
	private final EditUnitsSupportService editUnitsSupportService;

	private static final DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE;
	private static final UnitType UNIT_TYPE = UnitType.VINE_UNIT;
	private static final AbsoluteDate INFINITE = AbsoluteDate.of("99991231");
	
	private static final boolean CAN_NOT_BE_NULL = false;
	private static final boolean CAN_BE_NULL = true;

	private final EditVineUnitsDAO editVineUnitsDAO;
	private final SupportDAO supportDAO;


	public EditVineUnitsSupportService(DAOContainer dc, InternalConfigService internalConf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, UnitsSupportService unitsSupportService, 
			EditUnitsSupportService editUnitsSupportService, PluginEnvironment pluginEnvironment) {
		super(dc, internalConf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.unitsSupportService = unitsSupportService;
		this.editUnitsSupportService = editUnitsSupportService;

		this.editVineUnitsDAO = dc.getEditVineUnitsDAO();
		this.supportDAO = dc.getSupportDAO();
	}

	public void checkCreateOrUpdateVineUnitPayload(EditorSupportParams params, CreateOrUpdateVineUnitPayloadV1 payload, 
			List<ErrorItem> errorList) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.CULTIVATION_STATUS, UNIT_TYPE, ErrorField.CULTIVATION_STATUS_CODE, ErrorCode.CULTIVATION_STATUS_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.FARMING_FORM, UNIT_TYPE, ErrorField.FARMING_FORM_CODE, ErrorCode.FARMING_FORM_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.IRRIGATION, UNIT_TYPE, ErrorField.IRRIGATION_CODE, ErrorCode.IRRIGATION_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.HEADER_ANCHORING, UNIT_TYPE, ErrorField.HEADER_ANCHORING_CODE, ErrorCode.HEADER_ANCHORING_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.POLES_HEADER, UNIT_TYPE, ErrorField.POLES_HEADER_CODE, ErrorCode.POLES_HEADER_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.POLES_WEAVING, UNIT_TYPE, ErrorField.POLES_WEAVING_CODE, ErrorCode.POLES_WEAVING_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.PRODUCT_DESTINATION, UNIT_TYPE, ErrorField.PRODUCT_DESTINATION_CODE, ErrorCode.PRODUCT_DESTINATION_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.SUPPORT_WIRES, UNIT_TYPE, ErrorField.SUPPORT_WIRES_CODE, ErrorCode.SUPPORT_WIRES_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.TERRACING, UNIT_TYPE, ErrorField.TERRACING_CODE, ErrorCode.TERRACING_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.VARIATION_TYPE, UNIT_TYPE, ErrorField.VARIATION_TYPE_CODE, ErrorCode.VARIATION_TYPE_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.VARIETY, UNIT_TYPE, ErrorField.VARIETY_CODE, ErrorCode.VARIETY_CODE_NOT_FOUND);
		
		editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.AREA, payload.getAreaSqm(), 1.0, null, CAN_NOT_BE_NULL, errorList);
		
		editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.DISTANCE_ON_THE_ROW_CM, payload.getDistanceOnTheRowCM(), 50.0, 1000.0, CAN_NOT_BE_NULL, errorList);
		editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.DISTANCE_BETWEEN_ROWS_CM, payload.getDistanceBetweenRowsCM(), 50.0, 1000.0, CAN_NOT_BE_NULL, errorList);
		editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.STUMPS_NUMBER, payload.getStumpsNumber().doubleValue(), 1.0, 1000000.0, CAN_NOT_BE_NULL, errorList);
		editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.STUMPS_DENSITY100, payload.getStumpsDensity100(), 1.0, null, CAN_NOT_BE_NULL, errorList);
		
		editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.FAILURES_PERC, payload.getFailuresPerc(), 0.0, 100.0, CAN_BE_NULL, errorList);
		editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.SOIL_LAYERING_PERC, payload.getSoilLayeringPerc(), 0.0, 100.0, CAN_BE_NULL, errorList);
		editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.ALTITUDE_ABOVE_SEA_LEVEL, payload.getAltitudeAboveSeaLevel(), 0.0, 3000.0, CAN_BE_NULL, errorList);
		
		editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.POLES_DISTANCE_CM, payload.getPolesDistanceCM(), 50.0, 1000.0, CAN_BE_NULL, errorList);

	}

	public VineUnitDetailsNTT buildVineUnitDetailsNTTFromPayload(CreateOrUpdateVineUnitPayloadV1 payload, Long editId, 
			Long editLandCoverId, Long vineUnitId, String unitCode, EditStatus editStatus, Integer flDeletable, String parentUnitCode) {
		return VineUnitDetailsNTT.builder()
				.editId(editId)
				.editLandCoverId(editLandCoverId)
				.unitId(vineUnitId)
				.unitCode(unitCode)
				.parentUnitCode(parentUnitCode)
				.typeCode(UNIT_TYPE)
				.variety(VarietyNTT.builder().code(payload.getVarietyCode()).build())
				.areaSqm(payload.getAreaSqm())
				.plantingDay(payload.getPlantingDay())
				.plantingDayPrecision(payload.getPlantingDayPrecision())
				.eradicateDay(payload.getEradicateDay())
				.distanceOnTheRowCM(payload.getDistanceOnTheRowCM())
				.distanceBetweenRowsCM(payload.getDistanceBetweenRowsCM())
				.stumpsNumber(payload.getStumpsNumber().intValue())
				.stumpsDensity100(payload.getStumpsDensity100())
				.farmingForm(FarmingFormNTT.builder().code(payload.getFarmingFormCode()).build())
				.irrigation(IrrigationNTT.builder().code(payload.getIrrigationCode()).build())
				.productDestination(ProductDestinationNTT.builder().code(payload.getProductDestinationCode()).build())
				.variationType(VariationTypeNTT.builder().code(payload.getVariationTypeCode()).build())
				.cultivationStatus(CultivationStatusNTT.builder().code(payload.getCultivationStatusCode()).build())
				.terracing(TerracingNTT.builder().code(payload.getTerracingCode()).build())
				.failuresPerc(payload.getFailuresPerc())
				.soilLayeringPerc(payload.getSoilLayeringPerc())
				.altitudeAboveSeaLevel(payload.getAltitudeAboveSeaLevel())
				.polesWeaving(PolesWeavingNTT.builder().code(payload.getPolesWeavingCode()).build())
				.polesDistanceCM(payload.getPolesDistanceCM())
				.supportWires(SupportWiresNTT.builder().code(payload.getSupportWiresCode()).build())
				.headerAnchoring(HeaderAnchoringNTT.builder().code(payload.getHeaderAnchoringCode()).build())
				.polesHeader(PolesHeaderNTT.builder().code(payload.getPolesHeaderCode()).build())
				.externalCode(payload.getExternalCode())
				.editStatus(editStatus)
				.flDeletable(flDeletable)
				.build();
	}

	public void checkAndInsertEditParcelLandCoversVineUnitAndAptitudes(EditorSupportParams params, Long vineAptitudeId) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		Long vineUnitId = params.getVineUnitId();
		if(vineUnitId == null) {
			editUnitsSupportService.setInEditLandCoverById(params, params.getLandCoverId(), EditStatus.NOT_IN_EDIT);
			return;
		}

		VineUnitDetailsNTT inEditVineUnit = setInEditVineUnitById(params, vineUnitId, EditStatus.NOT_IN_EDIT);

		if(vineAptitudeId == null) {
			return;
		}

		List<EditStatus> editStatusToExclude = List.of(EditStatus.DELETED);

		VineAptitudeNTT editVineApttitude = editVineUnitsDAO.findInEditVineAptitudesBySessionId(env, vineUnitId, vineAptitudeId, 1, editStatusToExclude).stream()
				.filter(a -> a.getAptitudeId().equals(vineAptitudeId))
				.findFirst()
				.orElse(null);

		VineAptitudeNTT vineAptitudeToInsert = null;
		if(editVineApttitude == null) {
			vineAptitudeToInsert = editVineUnitsDAO.findNotInEditVineAptitudesBySessionId(env, vineUnitId, vineAptitudeId, 1).stream()
					.filter(a -> a.getAptitudeId().equals(vineAptitudeId))
					.findFirst()
					.orElse(null);

			if(vineAptitudeToInsert == null) {
				VineAptitudeNotFoundException ex = new VineAptitudeNotFoundException(Status.NOT_FOUND, params.getOperation(), 
						ErrorField.VINE_APTITUDE_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
			vineAptitudeToInsert.setEditId(editVineUnitsDAO.nextEditVineUnitAptitudePkidVal());
			vineAptitudeToInsert.setEditUnitId(inEditVineUnit.getEditId());
			vineAptitudeToInsert.setEditStatus(EditStatus.IN_EDIT);
		}

		if(vineAptitudeToInsert != null) {
			editVineUnitsDAO.insertEditVineAptitude(env, vineAptitudeToInsert);
		}

	}

	public void checkCreateOrUpdateVineAptitudesPayload(ServiceSupportEnv env, CreateOrUpdateVineAptitudesPayload payload,
			VineUnitDetailsNTT vineUnit, VineAptitudeNTT oldAptitude, Operation operation, List<ErrorItem> errorList) {
		
		try {
			if(payload.getDoigtCode() != null) {
				unitsSupportService.getVineDoIgtNTTByCode(env, payload.getDoigtCode(), operation);
			}
		} catch (AbstractException e) {
			errorList.add(ErrorItem.builder()
					.errorCode(e.getBody().getErrorCode())
					.message(e.getBody().getMessage())
					.errorField(e.getBody().getErrorField())
					.build());
		}

		try {
			if(payload.getVineyardCode() != null) {
				unitsSupportService.checkVineyardDoigtCompatibility(env, payload.getVineyardCode(), payload.getDoigtCode(), operation);
			}
		} catch (AbstractException e) {
			errorList.add(ErrorItem.builder()
					.errorCode(e.getBody().getErrorCode())
					.message(e.getBody().getMessage())
					.errorField(e.getBody().getErrorField())
					.build());
		}
		
		if(payload.getDayFrom() == null) {
			payload.setDayFrom(AbsoluteDate.of(LocalDate.now()));
			payload.setDayFromPrecision(DatePrecision.YMD);
		}

		if(payload.getDayTo() == null) {
			payload.setDayTo(vineUnit.getEradicateDay() == null ? INFINITE : vineUnit.getEradicateDay());
		}
		
		checkVineAptitudeValidationDates(env, payload, vineUnit, oldAptitude, errorList);
	}

	public List<VineUnitWithAptitudes> internalGetVineUnits(EditorSupportParams params, Long landCoverId, Long vineUnitId) {
		List<VineUnitWithAptitudes> vineUnits = getVineUnitsNTT(params, landCoverId, vineUnitId).stream()
				.map(VineUnitMapper.INSTANCE::entityToDtoWithAptitudes)
				.sorted((a, b) -> {
					
					String aCode = a.getCode() == null ? "0" : a.getCode(); 
					String bCode = b.getCode() == null ? "0" : b.getCode();
					
					aCode = aCode.length() < 15 ? StringUtils.substring("000000000000000", aCode.length() - 14) + aCode : aCode;
					bCode = bCode.length() < 15 ? StringUtils.substring("000000000000000", bCode.length() - 14) + bCode : bCode;
					
					int codeCompare = ObjectUtils.compare(aCode, bCode);
					if(codeCompare != 0) {
						return codeCompare;
					}
					return a.getId().compareTo(b.getId());
				})
				.collect(Collectors.toList());

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		vineUnits.stream().forEach(u -> {
			u.setIsDeletable(isDeletable(env, u.getLandCoverId(), u.getId()));
			u.setIsEditable(isEditable(params, u));
		});

		return vineUnits;
	}

	public List<VineUnitDetailsNTT> getVineUnitsNTT(EditorSupportParams params, Long landCoverId, Long vineUnitsId) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		List<VineUnitDetailsNTT> vineUnitNTTs = new ArrayList<>();

		List<EditStatus> editStatusToExclude = List.of(EditStatus.DELETED);
		List<VineUnitDetailsNTT> inEditVineUnits = editVineUnitsDAO.findInEditVineUnitsBySessionId(env, landCoverId, vineUnitsId, editStatusToExclude);
		if(inEditVineUnits != null) {
			vineUnitNTTs.addAll(inEditVineUnits);
		}

		List<VineUnitDetailsNTT> notInEditVineUnits = editVineUnitsDAO.findNotInEditVineUnitsBySessionId(env, landCoverId, vineUnitsId);
		if(notInEditVineUnits != null) {
			vineUnitNTTs.addAll(notInEditVineUnits);
		}

		if(vineUnitsId != null && 
				(vineUnitNTTs== null || vineUnitNTTs.size() != 1 || !vineUnitNTTs.get(0).getUnitId().equals(vineUnitsId))) {
			VineUnitNotFoundException ex = new VineUnitNotFoundException(Status.NOT_FOUND, params.getOperation(), 
					ErrorField.UNIT_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}	 

		return vineUnitNTTs;
	}

	public List<VineAptitude> internalGetVineAptitudes(EditorSupportParams params, Long vineUnitsId, Long vineAptitudeId, 
			Boolean showOutdatedUnits) {
		return getVineAptitudesNTT(params, vineUnitsId, vineAptitudeId, showOutdatedUnits).stream()
				.map(VineAptitudesMapper.INSTANCE::entityToDto)
				.sorted((a, b) -> a.getDoigt().getCode().compareToIgnoreCase(b.getDoigt().getCode()))
				.collect(Collectors.toList());
	}

	public void copyLandCoverVineUnits(EditorSupportParams params, LandCoversEditResult landCoversEditResult, 
			Boolean deleteSourceVineUnit) {
		ServiceSupportEnv env  = checkAndBuildServiceSupportEnv(params);

		// new landCovers
		landCoversEditResult.getAdded().stream().forEach(lc -> {
			if(lc.getParent_id() != null) {
				internalCopyLandCoverVineUnits(params, lc.getParent_id(), lc, deleteSourceVineUnit);
			}
		});

		landCoversEditResult.getUpdated().stream()
		.filter(lc -> !lc.getEdit_status().equals(EditStatus.TOPOLOGY_CORRECTED))
		.forEach(landCover -> {
			LandCoverNTT editLandCover = editUnitsSupportService.setInEditLandCoverById(params, landCover.getId(), EditStatus.NOT_IN_EDIT);

			List<VineUnitDetailsNTT> vineUnits = getVineUnitsNTT(params, editLandCover.getLand_cover_id(), null);

			vineUnits.stream().forEach(u -> {

				u.setEditStatus(EditStatus.IN_EDIT);
				u.setFlDeletable(boolToInt(isDeletable(env, editLandCover.getLand_cover_id(), u.getUnitId())));

				if(u.getEditId() == null) {
					u.setEditId(editVineUnitsDAO.nextEditVineUnitDetailPkidVal());
					u.setEditLandCoverId(editLandCover.getEdit_id());
					editVineUnitsDAO.insertEditVineUnitDetail(env, u);	
				} else {
					editVineUnitsDAO.updateEditVineUnitDetail(env.getSessionId(), u);
				}

				copyLandCoverVineAptitudes(params, u.getUnitId(), u.getEditId(), true, false);

			}); 

			landCover.setUnit_types(supportDAO.getCompatibleUnitTypesByLandCoverCode(env.getTenantId(), landCover.getCode()));
			landCover.setVine_units(internalGetVineUnits(params, landCover.getId(), null));
		});
	}

	public void mergeLandCoverVineUnits(EditorSupportParams params, Long targetLandCoverId, LandCoversEditResult landCoversEditResult) {
		editUnitsSupportService.setInEditLandCoverById(params, targetLandCoverId, EditStatus.NOT_IN_EDIT); 

		landCoversEditResult.getDeleted().stream()
		.forEach(landCover -> internalCopyLandCoverVineUnits(params, 
				landCover, 
				landCoversEditResult.getUpdated().stream()
				.filter(lc -> lc.getId().equals(targetLandCoverId))
				.findFirst()
				.orElse(null),
				true
				));
	}	

	public void mergeParcelLandCoverVineUnits(EditorSupportParams params, LandCoversEditResult landCoversEditResult) {
		landCoversEditResult.getAdded().stream()
		.filter(landCover -> landCover.getParent_id() != null)
		.forEach(landCover -> internalCopyLandCoverVineUnits(params, landCover.getParent_id(), landCover, true));
	}	

	public void cleanUpIncompatibleVineUnits(EditorSupportParams params, Long landCoverId) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		LandCoverNTT editLandCover = editUnitsSupportService.setInEditLandCoverById(params, landCoverId, EditStatus.NOT_IN_EDIT);

		List<VineUnitDetailsNTT> vineUnits = getVineUnitsNTT(params, editLandCover.getLand_cover_id(), null);

		vineUnits.stream().forEach(u -> {
			if(u.getUnitId() < 0) {
				editVineUnitsDAO.deleteVineUnitsByEditId(env.getSessionId(), u.getEditId());
			} else {
				u.setEditStatus(EditStatus.DELETED);
				u.setFlDeletable(1);
				if(u.getEditId() != null) {
					editVineUnitsDAO.updateEditVineUnitDetail(env.getSessionId(), u);
				} else {
					u.setEditId(editVineUnitsDAO.nextEditVineUnitDetailPkidVal());
					u.setEditLandCoverId(editLandCover.getEdit_id());
					editVineUnitsDAO.insertEditVineUnitDetail(env, u);
				}
			}
		}); 

	}


	public void copyLandCoverVineAptitudes(EditorSupportParams params, Long sourceVineUnitId, Long targetEditVineUnitId,
			Boolean deleteSource, Boolean forceNewAptitude) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		List<VineAptitudeNTT> vineAptitudes = getVineAptitudesNTT(params, sourceVineUnitId, null, false);

		VineUnitDetailsNTT targetVineUnitNTT = getVineUnitsNTT(params, null, null).stream()
				.filter(u -> targetEditVineUnitId.equals(u.getEditId()))
				.findFirst()
				.orElse(null);

		if(targetVineUnitNTT == null) {
			VineUnitNotFoundException ex = new VineUnitNotFoundException(Status.NOT_FOUND, params.getOperation(), 
					ErrorField.UNIT_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		vineAptitudes.stream().forEach(aptitude -> {
			aptitude = setInEditVineAptitudeById(params, aptitude.getAptitudeId(), EditStatus.NOT_IN_EDIT);
			VineAptitudeNTT vineAptitudeToInsert = VineAptitudeNTT.builder()
					.editId(Boolean.FALSE.equals(deleteSource) || Boolean.TRUE.equals(forceNewAptitude) ? editVineUnitsDAO.nextEditVineUnitAptitudePkidVal() : aptitude.getEditId())
					.editUnitId(targetEditVineUnitId)
					.unitId(targetVineUnitNTT.getUnitId())
					.aptitudeId(Boolean.TRUE.equals(forceNewAptitude) ? editVineUnitsDAO.nextNewVineAptitudeIdVal() : aptitude.getAptitudeId())
					.doigt(VineDoIgtNTT.builder().code(aptitude.getDoigt().getCode()).build())
					.dayFrom(aptitude.getDayFrom())
					.dayFromPrecision(aptitude.getDayFromPrecision())
					.dayTo(aptitude.getDayTo())
					.flPreventTypology(aptitude.getFlPreventTypology())
					.flPreventClaim(aptitude.getFlPreventClaim())
					.flPreventSuitability(aptitude.getFlPreventSuitability())
					.editStatus(Boolean.FALSE.equals(deleteSource) || Boolean.TRUE.equals(forceNewAptitude) ? EditStatus.IN_EDIT : aptitude.getEditStatus())
					.vineyard(aptitude.getVineyard())
					.build();

			internalSaveAptitude(params, env, aptitude, vineAptitudeToInsert, deleteSource, forceNewAptitude);
		});
	}

	private void internalSaveAptitude(EditorSupportParams params,  ServiceSupportEnv env, VineAptitudeNTT oldAptitude,
			VineAptitudeNTT vineAptitudeToInsert, Boolean deleteSource, Boolean forceNewAptitude) {
		if(oldAptitude.getEditId().equals(vineAptitudeToInsert.getEditId()) 
				&& oldAptitude.getAptitudeId().equals(vineAptitudeToInsert.getAptitudeId())) {
			editVineUnitsDAO.updateEditVineAptitude(env.getSessionId(), vineAptitudeToInsert);
		} else {
//			editVineUnitsDAO.deleteVineAptitudeByEditId(env.getSessionId(), oldAptitude.getEditId());
			editVineUnitsDAO.insertEditVineAptitude(env, vineAptitudeToInsert);
		}

		if(oldAptitude.getAptitudeId() < 0 && Boolean.TRUE.equals(deleteSource) && Boolean.TRUE.equals(forceNewAptitude)) {
			editVineUnitsDAO.deleteVineUnitsByEditId(env.getSessionId(), oldAptitude.getEditId());
		} else if(oldAptitude.getAptitudeId() > 0 && Boolean.TRUE.equals(deleteSource) && Boolean.TRUE.equals(forceNewAptitude)) {
			oldAptitude.setEditStatus(EditStatus.DELETED);
			if(oldAptitude.getEditId() != null) {
				editVineUnitsDAO.updateEditVineAptitude(env.getSessionId(), oldAptitude);
			} else {
				VineUnitDetailsNTT sourceVineUnit = setInEditVineUnitById(params, oldAptitude.getUnitId(), EditStatus.NOT_IN_EDIT);
				oldAptitude.setEditId(editVineUnitsDAO.nextEditVineUnitAptitudePkidVal());
				oldAptitude.setEditUnitId(sourceVineUnit.getEditId());
				editVineUnitsDAO.insertEditVineAptitude(env, oldAptitude);
			}

		}
	}

	private void internalCopyLandCoverVineUnits(EditorSupportParams params, Long sourceLandCoverId, LandCoverWithUnits targetLandCover,
			Boolean deleteSource) {

		if(sourceLandCoverId == null || targetLandCover == null) {
			return;
		}
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		LandCoverNTT targetEditLandCoverNTT = editUnitsSupportService.setInEditLandCoverById(params, targetLandCover.getId(), EditStatus.NOT_IN_EDIT);
		LandCoverNTT sourceEditLandCoverNTT = editUnitsSupportService.setInEditLandCoverById(params, sourceLandCoverId, EditStatus.NOT_IN_EDIT);

		List<VineUnitDetailsNTT> inEditVineUnits = getVineUnitsNTT(params, sourceLandCoverId, null);

		inEditVineUnits.stream().forEach(u -> {
			u = setInEditVineUnitById(params, u.getUnitId(), EditStatus.NOT_IN_EDIT);
			VineUnitDetailsNTT vineUnitToInsert = VineUnitDetailsNTT.builder()
					.editId(editVineUnitsDAO.nextEditVineUnitDetailPkidVal())
					.editLandCoverId(targetEditLandCoverNTT.getEdit_id())
					.unitId(editVineUnitsDAO.nextNewVineUnitIdVal())
					.unitCode(u.getUnitCode())
					.parentUnitCode(u.getParentUnitCode())
					.typeCode(UNIT_TYPE)
					.variety(u.getVariety())
					.areaSqm(u.getAreaSqm())
					.plantingDay(u.getPlantingDay())
					.plantingDayPrecision(u.getPlantingDayPrecision())
					.eradicateDay(u.getEradicateDay())
					.distanceOnTheRowCM(u.getDistanceOnTheRowCM())
					.distanceBetweenRowsCM(u.getDistanceBetweenRowsCM())
					.stumpsNumber(u.getStumpsNumber())
					.stumpsDensity100(u.getStumpsDensity100())
					.farmingForm(u.getFarmingForm())
					.irrigation(u.getIrrigation())
					.productDestination(u.getProductDestination())
					.variationType(u.getVariationType())
					.cultivationStatus(u.getCultivationStatus())
					.terracing(u.getTerracing())
					.failuresPerc(u.getFailuresPerc())
					.soilLayeringPerc(u.getSoilLayeringPerc())
					.altitudeAboveSeaLevel(u.getAltitudeAboveSeaLevel())
					.polesWeaving(u.getPolesWeaving())
					.polesDistanceCM(u.getPolesDistanceCM())
					.supportWires(u.getSupportWires())
					.headerAnchoring(u.getHeaderAnchoring())
					.polesHeader(u.getPolesHeader())
					.externalCode(u.getExternalCode())
					.editStatus(EditStatus.IN_EDIT)
					.flDeletable(1)
					.build();

			editVineUnitsDAO.insertEditVineUnitDetail(env, vineUnitToInsert);
			copyLandCoverVineAptitudes(params, u.getUnitId(), vineUnitToInsert.getEditId(), deleteSource, true);

			if(u.getUnitId() < 0 && Boolean.TRUE.equals(deleteSource)) {
				editVineUnitsDAO.deleteVineUnitsByEditId(env.getSessionId(), u.getEditId());
			} else if(u.getUnitId() > 0 && Boolean.TRUE.equals(deleteSource)) {
				u.setEditStatus(EditStatus.DELETED);
				u.setFlDeletable(1);
				if(u.getEditId() != null) {
					editVineUnitsDAO.updateEditVineUnitDetail(env.getSessionId(), u);
				} else {
					u.setEditId(editVineUnitsDAO.nextEditVineUnitDetailPkidVal());
					u.setEditLandCoverId(sourceEditLandCoverNTT.getEdit_id());
					editVineUnitsDAO.insertEditVineUnitDetail(env, u);
				}
			}
		});

		targetLandCover.setUnit_types(supportDAO.getCompatibleUnitTypesByLandCoverCode(env.getTenantId(), targetLandCover.getCode()));
		targetLandCover.setVine_units(internalGetVineUnits(params, targetLandCover.getId(), null));
	}

	private VineUnitDetailsNTT setInEditVineUnitById(EditorSupportParams params, Long vineUnitId, EditStatus editStatus) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		List<EditStatus> editStatusToExclude = List.of(EditStatus.DELETED);
		VineUnitDetailsNTT editVineUnit = editVineUnitsDAO.findInEditVineUnitsBySessionId(env, null, vineUnitId, editStatusToExclude).stream()
				.filter(u -> u.getUnitId().equals(vineUnitId))
				.findFirst()
				.orElse(null);
		if(editVineUnit == null) {
			editVineUnit = editVineUnitsDAO.findNotInEditVineUnitsBySessionId(env, null, vineUnitId).stream()
					.filter(u -> u.getUnitId().equals(vineUnitId))
					.findFirst()
					.orElse(null);
			if(editVineUnit == null) {
				VineUnitNotFoundException ex = new VineUnitNotFoundException(Status.NOT_FOUND, params.getOperation(), 
						ErrorField.UNIT_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
			LandCoverNTT inEditLandCover = editUnitsSupportService.setInEditLandCoverById(params, editVineUnit.getLandCoverId(), editStatus);
			editVineUnit.setEditId(editVineUnitsDAO.nextEditVineUnitDetailPkidVal());
			editVineUnit.setEditLandCoverId(inEditLandCover.getEdit_id());
			editVineUnit.setEditStatus(editStatus);
			editVineUnitsDAO.insertEditVineUnitDetail(env, editVineUnit);
		} 

		return editVineUnit;
	}

	private VineAptitudeNTT setInEditVineAptitudeById(EditorSupportParams params, Long vineAptitudeId, EditStatus editStatus) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		List<EditStatus> editStatusToExclude = List.of(EditStatus.DELETED);
		VineAptitudeNTT editVineAptitude = editVineUnitsDAO.findInEditVineAptitudesBySessionId(env, null, vineAptitudeId, 1, editStatusToExclude).stream()
				.filter(a -> a.getAptitudeId().equals(vineAptitudeId))
				.findFirst()
				.orElse(null);

		if(editVineAptitude == null) {
			editVineAptitude = editVineUnitsDAO.findNotInEditVineAptitudesBySessionId(env, null, vineAptitudeId, 1).stream()
					.filter(a -> a.getAptitudeId().equals(vineAptitudeId))
					.findFirst()
					.orElse(null);
			if(editVineAptitude == null) {
				VineAptitudeNotFoundException ex = new VineAptitudeNotFoundException(Status.NOT_FOUND, params.getOperation(), 
						ErrorField.VINE_APTITUDE_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
			VineUnitDetailsNTT inEditVineUnit = setInEditVineUnitById(params, editVineAptitude.getUnitId(), editStatus);
			editVineAptitude.setEditId(editVineUnitsDAO.nextEditVineUnitDetailPkidVal());
			editVineAptitude.setEditUnitId(inEditVineUnit.getEditId());
			editVineAptitude.setEditStatus(editStatus);
			editVineUnitsDAO.insertEditVineAptitude(env, editVineAptitude);
		} 

		return editVineAptitude;
	}

	public List<VineAptitudeNTT> getVineAptitudesNTT(EditorSupportParams params, Long vineUnitsId, Long vineAptitudeId, 
			Boolean showOutdatedUnits) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		List<VineAptitudeNTT> vineAptitudes = new ArrayList<>();

		List<EditStatus> editStatusToExclude = List.of(EditStatus.DELETED);
		List<VineAptitudeNTT> inEditVineAptitudes = editVineUnitsDAO.findInEditVineAptitudesBySessionId(env, vineUnitsId, vineAptitudeId, boolToInt(showOutdatedUnits), editStatusToExclude);

		if(inEditVineAptitudes != null) {
			vineAptitudes.addAll(inEditVineAptitudes);
		}

		List<VineAptitudeNTT> notInEditVineAptitudes = editVineUnitsDAO.findNotInEditVineAptitudesBySessionId(env, vineUnitsId, vineAptitudeId, boolToInt(showOutdatedUnits));

		if(notInEditVineAptitudes != null) {
			vineAptitudes.addAll(notInEditVineAptitudes);
		}

		if(vineAptitudeId != null && 
				(vineAptitudes == null || vineAptitudes.size() != 1 || !vineAptitudes.get(0).getAptitudeId().equals(vineAptitudeId))) {
			VineAptitudeNotFoundException ex = new VineAptitudeNotFoundException(Status.NOT_FOUND, params.getOperation(), 
					ErrorField.VINE_APTITUDE_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		return vineAptitudes;
	}
	
	public void checkVineUnitValidationDates(ServiceSupportEnv env, CreateOrUpdateVineUnitPayloadV1 payload,
			 @NotNull LandCoverNTT landCoverNTT, VineUnitDetailsNTT oldUnit, List<ErrorItem> errorList) {
		payload.validateDate();
		
		LocalDate minPlantingDate = editUnitsSupportService.buildMinPlantingDate(payload, landCoverNTT);
	   
	    LocalDate maxPlantingDate = env.getReferenceDate().toLocalDate();    
	    
	    if(payload.getPlantingDay().toLocalDate().isBefore(minPlantingDate)
	    		|| payload.getPlantingDay().toLocalDate().isAfter(maxPlantingDate)) {
	    	ErrorCode errorCode = ErrorCode.PLANTING_DAY_NOT_VALID;
	    	String errMsg = String.format(editUnitsSupportService.getErrorDescription(env, errorCode, null), 
					formatter.format(minPlantingDate), formatter.format(maxPlantingDate));
	    	
	    	if(maxPlantingDate.isEqual(INFINITE.toLocalDate())) {
	    		errorCode = ErrorCode.PLANTING_DAY_NOT_VALID_GREATER_THAN;
	    		errMsg = String.format(editUnitsSupportService.getErrorDescription(env, errorCode, null), 
						formatter.format(minPlantingDate), "");
	    	}
	    	
	    	errorList.add(ErrorItem.builder()
	    			.errorCode(errorCode)
	    			.message(errMsg)
	    			.errorField(ErrorField.PLANTING_DAY)
	    			.build());
	    	return;
	    } 
	    
	    LocalDate maxEradicateDay = oldUnit != null ? env.getReferenceDate().toLocalDate() : maxPlantingDate;
	    
		if((payload.getEradicateDay().toLocalDate().isBefore(payload.getPlantingDay().toLocalDate()))
				|| (oldUnit != null && !oldUnit.getEradicateDay().toLocalDate().isEqual(payload.getEradicateDay().toLocalDate())
						&& !payload.getEradicateDay().toLocalDate().isEqual(env.getReferenceDate().toLocalDate()))) {
			ErrorCode errorCode = ErrorCode.ERADICATE_DAY_NOT_VALID;
	    	String errMsg = String.format(editUnitsSupportService.getErrorDescription(env, errorCode, null), 
					formatter.format(payload.getPlantingDay().toLocalDate()), formatter.format(maxEradicateDay));
	    	
	    	if(maxEradicateDay.equals(INFINITE.toLocalDate())) {
	    		errorCode = ErrorCode.ERADICATE_DAY_NOT_VALID_GREATER_THAN;
		    	errMsg = String.format(editUnitsSupportService.getErrorDescription(env, errorCode, null), 
						formatter.format(payload.getPlantingDay().toLocalDate()), "");
	    	}
	    	
			errorList.add(ErrorItem.builder()
					.errorCode(errorCode)
					.message(errMsg)
					.errorField(ErrorField.ERADICATE_DAY)
					.build());
		}
	}
	
	public void checkVineAptitudeValidationDates(ServiceSupportEnv env, CreateOrUpdateVineAptitudesPayload payload, VineUnitDetailsNTT vineUnit,
			VineAptitudeNTT oldAptitude, List<ErrorItem> errors) {

		LocalDate minPlantingDay = vineUnit.getPlantingDay().toLocalDate();
		LocalDate maxPlantigDay = vineUnit.getEradicateDay().toLocalDate();

		if(payload.getDayFrom().toLocalDate().isBefore(minPlantingDay) || payload.getDayFrom().toLocalDate().isAfter(maxPlantigDay)) {
			ErrorCode errorCode = ErrorCode.VINE_APTITUDE_DAY_FROM_NOT_VALID;
			String errorMsg = String.format(editUnitsSupportService.getErrorDescription(env, errorCode, null), 
					formatter.format(minPlantingDay), formatter.format(maxPlantigDay));

			if(maxPlantigDay.isEqual(INFINITE.toLocalDate())) {
				errorCode = ErrorCode.VINE_APTITUDE_DAY_FROM_NOT_VALID_GREATER_THAN;
				errorMsg = String.format(editUnitsSupportService.getErrorDescription(env, errorCode, null), formatter.format(minPlantingDay), "" );

			}

			errors.add(ErrorItem.builder()
					.errorCode(errorCode)
					.message(errorMsg)
					.errorField(ErrorField.DAY_FROM)
					.build());

			return;
		}

		LocalDate maxRevokeDay =  oldAptitude != null ? env.getReferenceDate().toLocalDate() : maxPlantigDay;
		if((payload.getDayTo().toLocalDate().isBefore(payload.getDayFrom().toLocalDate()))
				|| (oldAptitude != null && !oldAptitude.getDayTo().toLocalDate().isEqual(payload.getDayTo().toLocalDate())
				&& !payload.getDayTo().toLocalDate().isAfter(env.getReferenceDate().toLocalDate()))) {
			ErrorCode errorCode = ErrorCode.REVOKE_DATE_NOT_VALID;
			String errorMsg = String.format(editUnitsSupportService.getErrorDescription(env, errorCode, null), 
					formatter.format(payload.getDayFrom().toLocalDate()), formatter.format(maxRevokeDay));

			errors.add(ErrorItem.builder()
					.errorCode(errorCode)
					.message(errorMsg)
					.errorField(ErrorField.REVOKE_DAY)
					.build());
		}

	}

	public Boolean isDeletable(ServiceSupportEnv env, Long landCoverId, Long vineUnitId) {
		if(env.getSessionId() != null && vineUnitId < 1) {
			return true;
		}

		Integer isDel = editVineUnitsDAO.checkVineUnitDeletable(env, landCoverId, vineUnitId);
		return vineUnitId > 0 && isDel != null && isDel == 1;
	}

	private Boolean isEditable(EditorSupportParams params, VineUnitWithAptitudes vineUnit) {
		LocalDate refDate = params.getSession().getReference_date().toLocalDate();
		return !(refDate.isBefore(vineUnit.getPlantingDay().toLocalDate()) && refDate.isAfter(vineUnit.getEradicateDay().toLocalDate()));
	}
	
}
