package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.AreaNTT;
import com.abacogroup.lpisgisserver.resources.res.Area;

@Mapper(uses = AbsoluteDateMapper.class)
public interface AreasMapper {

	AreasMapper INSTANCE = Mappers.getMapper(AreasMapper.class);

	@InheritInverseConfiguration()
	Area entityToDto(AreaNTT entity);

	@Mapping(target = "pkid", ignore = true)
	@Mapping(target = "geom", ignore = true)
	@Mapping(target = "srs", ignore = true)
	@Mapping(source = "parent.area_id", target = "parent_id")
	@Mapping(source = "level.code", target = "level_code")
	@Mapping(source = "level.description", target = "level_description")
	AreaNTT dtoToEntity(Area dto);

}
