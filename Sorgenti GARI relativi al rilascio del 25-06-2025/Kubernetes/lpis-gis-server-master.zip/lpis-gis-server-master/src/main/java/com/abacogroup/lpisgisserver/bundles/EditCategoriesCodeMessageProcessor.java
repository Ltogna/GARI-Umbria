package com.abacogroup.lpisgisserver.bundles;

import java.io.File;
import java.nio.file.Path;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.lpisgisserver.bundles.models.EditCategoryCodeListMessage;
import com.abacogroup.lpisgisserver.bundles.models.I18nMessage;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.ntt.EditCategoryNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EditCategoriesCodeMessageProcessor extends AbstractMessageProcessor {

	protected SupportDAO supportDAO;
	
	private static final String TABLE_NAME = "lpis_edit_categories";
	private static final String FIELD_NAME = "code";

	private final ObjectMapper objectMapper;

	private static final Logger log = LoggerFactory.getLogger(EditCategoriesCodeMessageProcessor.class);

	public EditCategoriesCodeMessageProcessor(DAOContainer dc) {
		super(dc);
		this.supportDAO = dc.getSupportDAO();
		objectMapper = new ObjectMapper();
	}

	@Override
	public String getDomainName() {
		return "edit-category-codes";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
				&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> insertOrUpdateEditCategoryCodeMessage(message.getTenantId(), file));
	}

	private void insertOrUpdateEditCategoryCodeMessage(String tenantId, File file) {
		try {
			EditCategoryCodeListMessage codeMessages = objectMapper.readValue(file, EditCategoryCodeListMessage.class);

			if (codeMessages == null) {
				return;
			}

			if(codeMessages.getEdit_category_codes() != null) {
				ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).lang("en").build();
				codeMessages.getEdit_category_codes().stream().forEach(message -> {
					try {
						
						EditCategoryNTT toFind = supportDAO.getEditCategoryCodeByTenantAndCode(env, message.getCode());
						
						if(toFind == null) {
							EditCategoryNTT editCategoryNTT = EditCategoryNTT.builder()
									.code(message.getCode())
									.flVisible(boolToInt(message.getFl_visible()))
									.build();
							supportDAO.insertEditCategoryCode(tenantId, editCategoryNTT);
						} else if(!toFind.getFlVisible().equals(boolToInt(message.getFl_visible()))) {
							EditCategoryNTT editCategoryNTT = EditCategoryNTT.builder()
									.code(message.getCode())
									.flVisible(boolToInt(message.getFl_visible()))
									.build();
							supportDAO.updateEditCategory(editCategoryNTT, env);
						}
						
						// insert or update description
						I18nMessage i18nMessage = I18nMessage.builder()
								.table(TABLE_NAME)
								.field(FIELD_NAME)
								.value(message.getCode())
								.translations(message.getDescription())
								.build();

						insertOrUpdateI18nMessages(tenantId, i18nMessage);
						
					} catch (Exception e) {
						log.error("Error during insert/update operation of Edit category code with code {} with tenant {} : {}", message.getCode(), tenantId, e);
					}
				});
			}
		} catch (Exception e) {
			log.error("Error processing file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}
	}
}
