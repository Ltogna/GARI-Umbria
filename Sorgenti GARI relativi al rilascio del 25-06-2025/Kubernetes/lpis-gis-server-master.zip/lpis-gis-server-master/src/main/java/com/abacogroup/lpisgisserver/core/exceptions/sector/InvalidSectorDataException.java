package com.abacogroup.lpisgisserver.core.exceptions.sector;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidSectorDataException extends AbstractException {

	private static final long serialVersionUID = -9148638905600019338L;

	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_SECTOR_DATA;

	public InvalidSectorDataException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new InvalidSectorDataExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Invalid sector data")
	public static class InvalidSectorDataExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 8063426328402047408L;

		public InvalidSectorDataExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
