package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.LandUsesCodeNTT;
import com.abacogroup.lpisgisserver.resources.res.LandUsesCode;

@Mapper
public interface LandUsesCodeMapper {

	LandUsesCodeMapper INSTANCE = Mappers.getMapper(LandUsesCodeMapper.class);

	@Mapping(source = "code", target = "land_uses_code")
	@Mapping(source = "description", target = "description")
	LandUsesCode entityToDto(LandUsesCodeNTT entity);

	@Mapping(source = "land_uses_code", target = "code")
	@Mapping(source = "description", target = "description")
	LandUsesCodeNTT dtoToEntity(LandUsesCode dto);
}
