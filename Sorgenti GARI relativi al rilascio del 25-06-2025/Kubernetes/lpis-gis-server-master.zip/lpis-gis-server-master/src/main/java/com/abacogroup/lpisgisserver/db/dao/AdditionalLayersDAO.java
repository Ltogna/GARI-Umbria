package com.abacogroup.lpisgisserver.db.dao;

import java.sql.DatabaseMetaData;
import java.util.List;
import java.util.stream.Collectors;

import org.jdbi.v3.core.mapper.reflect.BeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.AdditionalLayerNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface AdditionalLayersDAO extends Transactional<AdditionalLayersDAO>, EnhancedSqlObject {

	default List<AdditionalLayerNTT> getAdditionalLayers(ServiceSupportEnv env, String module, Integer foregroundLevel){
		String dbType = withHandle(h -> h.queryMetadata(DatabaseMetaData::getDatabaseProductName));
		Boolean isPostgres = dbType.toLowerCase().contains("postgresql");

		String sql = "select oll.*, "
				+ "          (select server_config from lpis_wms_servers where id = oll.wms_server_id fetch first row only) as server_config, \n"
				+ "          (select layer_options from lpis_wms_layers where id = oll.wms_layer_id fetch first row only) as layerOptions \n"				
				+ "   from ( \n"
				+ "select DISTINCT \n"
				+ "       ws.id as wms_server_id, \n"
				+ "       wl.id as wms_layer_id, \n"
				+ "       ws.server_type as layerType,\n"
				+ "       ws.code, \n"
				+ "       wl.wms_server_id||':'||wl.id as layer_id, \n"
				+ "       ws.code||':'||wl.code as unique_code, \n"
				+ "       coalesce(§i18n(:tenantId, 'lpis_wms_servers', 'code:module', ws.code || ':' || :module, :lang)§, §i18n(:tenantId, 'lpis_wms_servers', 'code', ws.code, :lang)§)"
				+ "         || '->' || coalesce(§i18n(:tenantId, 'lpis_wms_layers', 'code:module', wl.code || ':' || :module, :lang)§, §i18n(:tenantId, 'lpis_wms_layers', 'code', wl.code, :lang)§) as description,\n"
				+ "       url,\n"
				+ "       coalesce(wlm.fl_on, wm.fl_on) as flVisible,\n"
				+ "       wl.layer_name as layer,\n"
				+ "       ws.srs,\n"
				+ "       ws.format,\n"
				+ "       ws.color as bgcolor,\n"
				+ "       ws.transparent as flTransparent,\n"
				+ "       wp.context_function as contextFunction,\n"
				+ "       wl.max_pixel_val as maxPixelVal, \n"
				+ "       ws.display_order as server_display_order, \n"
				+ "       wl.display_order as layer_display_order, \n"
				+ "       wl.foreground_level as foregroundLevel, \n"
				+ "       wl.path, \n"
				+ "       wl.catalogue_code, \n"
				+ "       wl.info_catalogue_code \n"
				+ "  from lpis_wms_servers ws \n"
				+ " inner join lpis_wms_layers wl on ws.id = wl.wms_server_id \n"
				+ " inner join lpis_wms_modules wm on ws.id = wm.wms_server_id \n"
				+ "  left join lpis_wms_layer_modules wlm on wlm.wms_server_id = ws.id and wlm.wms_layer_id = wl.id \n"
				+ "  left join lpis_wms_permission wp on ws.id = wp.wms_server_id \n"
				+ " where ws.tenant_id = :tenantId \n"
				+ "   and wm.module = :module \n"
				+ "   and (:foregroundLevel is null or wl.foreground_level = :foregroundLevel) \n"
				+ "   and case when wl.foreground_level < 1 then coalesce(wlm.fl_on, 1) else 1 end = 1 \n"
				+ "   and ws.srs = :srs \n"
				+ "   and ws.id in ( \n"
				+ "      with " + (Boolean.TRUE.equals(isPostgres) ? "recursive" : "") + " childAreas(area_id, parent_id) as ( \n"
				+ "         select \n"
				+ "            lah.area_id, \n"
				+ "            lah.parent_id \n"
				+ "         from \n"
				+ "            lpis_areas_hierarchies lah \n"
				+ "            inner join lpis_sector_areas lsa on lsa.area_id = lah.area_id  \n"
				+ "         where \n"
				+ "            lsa.sector_id = :sectorId \n"
				+ "            and lsa.tenant_id = :tenantId \n"
				+ "            and lah.tenant_id = :tenantId \n"
				+ "            and :referenceDate between lsa.day_from and lsa.day_to \n"
				+ "            and :referenceDate between lah.day_from and lah.day_to \n"
				+ "            and §current_timestamp§ between lsa.dt_insert and lsa.dt_delete \n"
				+ "            and §current_timestamp§ between lah.dt_insert and lah.dt_delete \n"
				+ "      union all \n"
				+ "         select \n"
				+ "            lah.area_id, \n"
				+ "            lah.parent_id \n"
				+ "         from \n"
				+ "            lpis_areas_hierarchies lah \n"
				+ "            inner join childAreas ca on ca.parent_id = lah.area_id \n"
				+ "         where \n"
				+ "            lah.tenant_id = :tenantId \n"
				+ "            and :referenceDate between lah.day_from and lah.day_to \n"
				+ "            and §current_timestamp§ between lah.dt_insert and lah.dt_delete \n"
				+ "      ) \n"
				+ "      select distinct lwsa.wms_server_id from lpis_wms_server_areas lwsa where lwsa.area_id in (select area_id from childAreas)   \n"
				+ "      union  \n"
				+ "      select lws.id from lpis_wms_servers lws left join lpis_wms_server_areas lwsa on lwsa.wms_server_id = lws.id where lwsa.wms_server_id is null  \n"
				+ "   ) \n"
				+ " order by ws.display_order, wl.display_order, 2 \n"
				+ ") oll \n";

		return withHandle(h -> h.createQuery(sql).bindBean(env).bind("module", module).bind("foregroundLevel", foregroundLevel)
				.registerRowMapper(BeanMapper.factory(AdditionalLayerNTT.class)).mapTo(AdditionalLayerNTT.class).collect(Collectors.toList()));
	}
}
