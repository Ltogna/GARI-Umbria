package com.abacogroup.lpisgisserver.bundles.models;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CodeMessage {
	private String code;
	private Map<String, String> descriptions;
}
