package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.OliveUnitDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.OliveUnitNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.OliveUnitWithParcelDetailsNTT;
import com.abacogroup.lpisgisserver.resources.res.units.olive.OliveUnit;
import com.abacogroup.lpisgisserver.resources.res.units.olive.OliveUnitWithErrors;
import com.abacogroup.lpisgisserver.resources.res.units.olive.OliveUnitWithParcelDetails;

@Mapper(uses = { AbsoluteDateMapper.class, VarietyMapper.class, FarmingFormMapper.class, 
		ProductDestinationMapper.class, IrrigationMapper.class, ProtectionStructureMapper.class,
		QualitySystemMapper.class, PlantingTypeMapper.class})
public interface OliveUnitMapper {

	OliveUnitMapper INSTANCE = Mappers.getMapper(OliveUnitMapper.class);

	@InheritInverseConfiguration()
	@Mapping(source = "unitId", target = "id")
	@Mapping(source = "unitCode", target = "code")
	@Mapping(source = "parentUnitCode", target = "parentCode")
	@Mapping(target = "isDeletable", ignore = true)
	@Mapping(target = "isEditable", ignore = true)
	OliveUnit entityToDto(OliveUnitNTT entity);
	
	@InheritInverseConfiguration()
	@Mapping(source = "unitId", target = "id")
	@Mapping(source = "parentUnitCode", target = "parentCode")
	@Mapping(source = "unitCode", target = "code")
	@Mapping(target = "isDeletable", ignore = true)
	@Mapping(target = "isEditable", ignore = true)
	OliveUnit entityToDto(OliveUnitDetailsNTT entity);

	@InheritInverseConfiguration()
	@Mapping(source = "unitId", target = "id")
	@Mapping(source = "parentUnitCode", target = "parentCode")
	@Mapping(source = "unitCode", target = "code")
	@Mapping(target = "isDeletable", ignore = true)
	@Mapping(target = "isEditable", ignore = true)
	OliveUnitWithParcelDetails entityToDtoWithParcelDetails(OliveUnitWithParcelDetailsNTT oliveUnitNTT);
	
	@InheritInverseConfiguration()
	@Mapping(source = "unitId", target = "id")
	@Mapping(source = "unitCode", target = "code")
	@Mapping(source = "parentUnitCode", target = "parentCode")
	@Mapping(target = "editStatus", ignore = true)
	@Mapping(target = "errorList", ignore = true)
	@Mapping(target = "mandatoryDictionayTable", ignore = true)
	@Mapping(target = "isDeletable", ignore = true)
	@Mapping(target = "isEditable", ignore = true)
	OliveUnitWithErrors entityToDtoWithErrors(OliveUnitNTT entity);

	@InheritInverseConfiguration()
	@Mapping(source = "unitId", target = "id")
	@Mapping(source = "unitCode", target = "code")
	@Mapping(source = "parentUnitCode", target = "parentCode")
	@Mapping(target = "errorList", ignore = true)
	@Mapping(target = "isDeletable", ignore = true)
	@Mapping(target = "isEditable", ignore = true)
	@Mapping(target = "mandatoryDictionayTable", ignore = true)
	OliveUnitWithErrors entityToDtoWithErrors(OliveUnitDetailsNTT entity);

	
	OliveUnitDetailsNTT entityToEntityDetail(OliveUnitNTT entity);

}
