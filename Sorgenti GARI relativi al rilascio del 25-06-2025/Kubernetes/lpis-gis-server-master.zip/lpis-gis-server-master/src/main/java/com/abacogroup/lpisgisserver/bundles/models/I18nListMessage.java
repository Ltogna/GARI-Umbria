package com.abacogroup.lpisgisserver.bundles.models;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class I18nListMessage {
	private List<I18nMessage> i18n_list;
}
