package com.abacogroup.lpisgisserver.core.enums;

public enum EditType {
		CREATE,
		CUT,
		UPDATE,
		MERGE,
		UPDATE_DATA,
		DELETE
}
