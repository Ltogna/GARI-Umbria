package com.abacogroup.lpisgisserver.core;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.UnitDictionaryTables;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.ErrorItem;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;
import com.abacogroup.lpisgisserver.core.exceptions.units.olive.OliveUnitNotFoundException;
import com.abacogroup.lpisgisserver.core.mappers.units.OliveUnitMapper;
import com.abacogroup.lpisgisserver.core.support.EditorSupportParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditOliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.FarmingFormNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.IrrigationNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.PlantingTypeNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.ProductDestinationNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.ProtectionStructureNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.QualitySystemNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.VarietyNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.OliveUnitDetailsNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.pub.CreateOrUpdateOliveUnitPayloadV1;
import com.abacogroup.lpisgisserver.resources.res.LandCoverWithUnits;
import com.abacogroup.lpisgisserver.resources.res.LandCoversEditResult;
import com.abacogroup.lpisgisserver.resources.res.units.olive.OliveUnit;

import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EditOliveUnitsSupportService extends BaseService {

	private final EditUnitsSupportService editUnitsSupportService;

	private static final DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE;
	private static final UnitType UNIT_TYPE = UnitType.OLIVE_UNIT;
	private static final AbsoluteDate INFINITE = AbsoluteDate.of("99991231");
	
	private static final boolean CAN_NOT_BE_NULL = false;
	private static final boolean CAN_BE_NULL = true;

	private final EditOliveUnitsDAO editOliveUnitsDAO;
	private final SupportDAO supportDAO;


	public EditOliveUnitsSupportService(DAOContainer dc, InternalConfigService internalConf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, EditUnitsSupportService editUnitsSupportService, 
			PluginEnvironment pluginEnvironment) {
		super(dc, internalConf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.editOliveUnitsDAO = dc.getEditOliveUnitsDAO();
		this.supportDAO = dc.getSupportDAO();
		
		this.editUnitsSupportService = editUnitsSupportService;
	}
	
	public void checkCreateOrUpdateOliveUnitPayload(EditorSupportParams params, CreateOrUpdateOliveUnitPayloadV1 payload, 
			List<ErrorItem> errorList) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.VARIETY, UNIT_TYPE, ErrorField.VARIETY_CODE, ErrorCode.VARIETY_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.PLANTING_TYPE, UNIT_TYPE, ErrorField.PLANTING_TYPE_CODE, ErrorCode.PLANTING_TYPE_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.FARMING_FORM, UNIT_TYPE, ErrorField.FARMING_FORM_CODE, ErrorCode.FARMING_FORM_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.IRRIGATION, UNIT_TYPE, ErrorField.IRRIGATION_CODE, ErrorCode.IRRIGATION_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.PRODUCT_DESTINATION, UNIT_TYPE, ErrorField.PRODUCT_DESTINATION_CODE, ErrorCode.PRODUCT_DESTINATION_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.QUALITY_SYSTEM, UNIT_TYPE, ErrorField.QUALITY_SYSTEM_CODE, ErrorCode.QUALITY_SYSTEM_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.PROTECTION_STRUCTURE, UNIT_TYPE, ErrorField.PROTECTION_STRUCTURE_CODE, ErrorCode.PROTECTION_STRUCTURE_CODE_NOT_FOUND);
		
		editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.AREA, payload.getAreaSqm(), 1.0, null, CAN_NOT_BE_NULL, errorList);
		
		editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.DISTANCE_ON_THE_ROW_CM, payload.getDistanceOnTheRowCM(), 50.0, 1000.0, CAN_BE_NULL, errorList);
		editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.DISTANCE_BETWEEN_ROWS_CM, payload.getDistanceBetweenRowsCM(), 50.0, 1000.0, CAN_BE_NULL, errorList);

		if(payload.getPlantsNumber() != null) {
			editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.PLANTS_NUMBER, payload.getPlantsNumber().doubleValue(), 1.0, 1000000.0, CAN_BE_NULL, errorList);
		}
		
		editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.ALTITUDE_ABOVE_SEA_LEVEL, payload.getAltitudeAboveSeaLevel(), 0.0, 3000.0, CAN_BE_NULL, errorList);
		
	}

	public OliveUnitDetailsNTT buildOliveUnitDetailsNTTFromPayload(CreateOrUpdateOliveUnitPayloadV1 payload, Long editId, 
			Long editLandCoverId, Long oliveUnitId, String unitCode, EditStatus editStatus, Integer flDeletable, String parentUnitCode) {
		return OliveUnitDetailsNTT.builder()
				.editId(editId)
				.editLandCoverId(editLandCoverId)
				.unitId(oliveUnitId)
				.unitCode(unitCode)
				.parentUnitCode(parentUnitCode)
				.typeCode(UNIT_TYPE)
				.variety(VarietyNTT.builder().code(payload.getVarietyCode()).build())
				.areaSqm(payload.getAreaSqm())
				.plantingDay(payload.getPlantingDay())
				.plantingDayPrecision(payload.getPlantingDayPrecision())
				.eradicateDay(payload.getEradicateDay())
				.plantingType(PlantingTypeNTT.builder().code(payload.getPlantingTypeCode()).build())
				.distanceOnTheRowCM(payload.getDistanceOnTheRowCM())
				.distanceBetweenRowsCM(payload.getDistanceBetweenRowsCM())
				.plantsNumber(payload.getPlantsNumber() != null ? payload.getPlantsNumber().intValue() : null)
				.farmingForm(FarmingFormNTT.builder().code(payload.getFarmingFormCode()).build())
				.irrigation(IrrigationNTT.builder().code(payload.getIrrigationCode()).build())
				.productDestination(ProductDestinationNTT.builder().code(payload.getProductDestinationCode()).build())
				.altitudeAboveSeaLevel(payload.getAltitudeAboveSeaLevel())
				.qualitySystem(QualitySystemNTT.builder().code(payload.getQualitySystemCode()).build())
				.protectionStructure(ProtectionStructureNTT.builder().code(payload.getProtectionStructureCode()).build())
				.externalCode(payload.getExternalCode())
				.editStatus(editStatus)
				.flDeletable(flDeletable)
				.build();
	}

	public void checkAndInsertEditParcelLandCoversOliveUnit(EditorSupportParams params) {
		Long oliveUnitId = params.getOliveUnitId();
		if(oliveUnitId == null) {
			editUnitsSupportService.setInEditLandCoverById(params, params.getLandCoverId(), EditStatus.NOT_IN_EDIT);
			return;
		}
		setInEditOliveUnitById(params, oliveUnitId, EditStatus.NOT_IN_EDIT);
	}

	public List<OliveUnit> internalGetOliveUnits(EditorSupportParams params, Long landCoverId, Long oliveUnitId) {
		List<OliveUnit> oliveUnits = getOliveUnitsNTT(params, landCoverId, oliveUnitId).stream()
				.map(OliveUnitMapper.INSTANCE::entityToDto)
				.sorted((a, b) -> {
					
					String aCode = a.getCode() == null ? "0" : a.getCode(); 
					String bCode = b.getCode() == null ? "0" : b.getCode();
					
					aCode = aCode.length() < 15 ? StringUtils.substring("000000000000000", aCode.length() - 14) + aCode : aCode;
					bCode = bCode.length() < 15 ? StringUtils.substring("000000000000000", bCode.length() - 14) + bCode : bCode;
					
					int codeCompare = ObjectUtils.compare(aCode, bCode);
					if(codeCompare != 0) {
						return codeCompare;
					}
					return a.getId().compareTo(b.getId());
				})
				.collect(Collectors.toList());

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		oliveUnits.stream().forEach(u -> {
			u.setIsDeletable(isDeletable(env, u.getLandCoverId(), u.getId()));
			u.setIsEditable(isEditable(params, u));
		});

		return oliveUnits;
	}

	public List<OliveUnitDetailsNTT> getOliveUnitsNTT(EditorSupportParams params, Long landCoverId, Long oliveUnitsId) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		List<OliveUnitDetailsNTT> oliveUnitNTTs = new ArrayList<>();

		List<EditStatus> editStatusToExclude = List.of(EditStatus.DELETED);
		List<OliveUnitDetailsNTT> inEditOliveUnits = editOliveUnitsDAO.findInEditOliveUnitsBySessionId(env, landCoverId, oliveUnitsId, editStatusToExclude);
		if(inEditOliveUnits != null) {
			oliveUnitNTTs.addAll(inEditOliveUnits);
		}

		List<OliveUnitDetailsNTT> notInEditOliveUnits = editOliveUnitsDAO.findNotInEditOliveUnitsBySessionId(env, landCoverId, oliveUnitsId);
		if(notInEditOliveUnits != null) {
			oliveUnitNTTs.addAll(notInEditOliveUnits);
		}

		if(oliveUnitsId != null && 
				(oliveUnitNTTs== null || oliveUnitNTTs.size() != 1 || !oliveUnitNTTs.get(0).getUnitId().equals(oliveUnitsId))) {
			OliveUnitNotFoundException ex = new OliveUnitNotFoundException(Status.NOT_FOUND, params.getOperation(), 
					ErrorField.UNIT_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}	 

		return oliveUnitNTTs;
	}

	private OliveUnitDetailsNTT setInEditOliveUnitById(EditorSupportParams params, Long oliveUnitId, EditStatus editStatus) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		List<EditStatus> editStatusToExclude = List.of(EditStatus.DELETED);
		OliveUnitDetailsNTT editOliveUnit = editOliveUnitsDAO.findInEditOliveUnitsBySessionId(env, null, oliveUnitId, editStatusToExclude).stream()
				.filter(u -> u.getUnitId().equals(oliveUnitId))
				.findFirst()
				.orElse(null);
		if(editOliveUnit == null) {
			editOliveUnit = editOliveUnitsDAO.findNotInEditOliveUnitsBySessionId(env, null, oliveUnitId).stream()
					.filter(u -> u.getUnitId().equals(oliveUnitId))
					.findFirst()
					.orElse(null);
			if(editOliveUnit == null) {
				OliveUnitNotFoundException ex = new OliveUnitNotFoundException(Status.NOT_FOUND, params.getOperation(), 
						ErrorField.UNIT_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
			LandCoverNTT inEditLandCover = editUnitsSupportService.setInEditLandCoverById(params, editOliveUnit.getLandCoverId(), editStatus);
			editOliveUnit.setEditId(editOliveUnitsDAO.nextEditOliveUnitDetailPkidVal());
			editOliveUnit.setEditLandCoverId(inEditLandCover.getEdit_id());
			editOliveUnit.setEditStatus(editStatus);
			editOliveUnitsDAO.insertEditOliveUnitDetail(env, editOliveUnit);
		} 

		return editOliveUnit;
	}

	public void checkOliveUnitValidationDates(ServiceSupportEnv env, CreateOrUpdateOliveUnitPayloadV1 payload,
			 @NotNull LandCoverNTT landCoverNTT, OliveUnitDetailsNTT oldUnit, List<ErrorItem> errorList) {
		payload.validateDate();
		
		LocalDate minPlantingDate = editUnitsSupportService.buildMinPlantingDate(payload, landCoverNTT);
	   
	    LocalDate maxPlantingDate = env.getReferenceDate().toLocalDate();    
	    
	    if(payload.getPlantingDay().toLocalDate().isBefore(minPlantingDate)
	    		|| payload.getPlantingDay().toLocalDate().isAfter(maxPlantingDate)) {
	    	ErrorCode errorCode = ErrorCode.PLANTING_DAY_NOT_VALID;
	    	String errMsg = String.format(editUnitsSupportService.getErrorDescription(env, errorCode, null), 
					formatter.format(minPlantingDate), formatter.format(maxPlantingDate));
	    	
	    	if(maxPlantingDate.isEqual(INFINITE.toLocalDate())) {
	    		errorCode = ErrorCode.PLANTING_DAY_NOT_VALID_GREATER_THAN;
	    		errMsg = String.format(editUnitsSupportService.getErrorDescription(env, errorCode, null), 
						formatter.format(minPlantingDate), "");
	    	}
	    	
	    	errorList.add(ErrorItem.builder()
	    			.errorCode(errorCode)
	    			.message(errMsg)
	    			.errorField(ErrorField.PLANTING_DAY)
	    			.build());
	    } 
	    
	    LocalDate maxEradicateDay = oldUnit != null ? env.getReferenceDate().toLocalDate() : maxPlantingDate;
	    
		if((payload.getEradicateDay().toLocalDate().isBefore(payload.getPlantingDay().toLocalDate()))
				|| (oldUnit != null && !oldUnit.getEradicateDay().toLocalDate().isEqual(payload.getEradicateDay().toLocalDate())
						&& !payload.getEradicateDay().toLocalDate().isEqual(env.getReferenceDate().toLocalDate()))) {
			ErrorCode errorCode = ErrorCode.ERADICATE_DAY_NOT_VALID;
	    	String errMsg = String.format(editUnitsSupportService.getErrorDescription(env, errorCode, null), 
					formatter.format(payload.getPlantingDay().toLocalDate()), formatter.format(maxEradicateDay));
	    	
	    	if(maxEradicateDay.equals(INFINITE.toLocalDate())) {
	    		errorCode = ErrorCode.ERADICATE_DAY_NOT_VALID_GREATER_THAN;
		    	errMsg = String.format(editUnitsSupportService.getErrorDescription(env, errorCode, null), 
						formatter.format(payload.getPlantingDay().toLocalDate()), "");
	    	}
	    	
			errorList.add(ErrorItem.builder()
					.errorCode(errorCode)
					.message(errMsg)
					.errorField(ErrorField.ERADICATE_DAY)
					.build());
		}
	}

	public Boolean isDeletable(ServiceSupportEnv env, Long landCoverId, Long oliveUnitId) {
		if(env.getSessionId() != null && oliveUnitId < 1) {
			return true;
		}

		Integer isDel = editOliveUnitsDAO.checkOliveUnitDeletable(env, landCoverId, oliveUnitId);
		return oliveUnitId > 0 && isDel != null && isDel == 1;
	}
	
	
	public void cleanUpIncompatibleOliveUnits(EditorSupportParams params, Long landCoverId) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		LandCoverNTT editLandCover = editUnitsSupportService.setInEditLandCoverById(params, landCoverId, EditStatus.NOT_IN_EDIT);
		
		List<OliveUnitDetailsNTT> oliveUnits = getOliveUnitsNTT(params, editLandCover.getLand_cover_id(), null);
		
		oliveUnits.stream().forEach(u -> {
			if(u.getUnitId() < 0) {
				editOliveUnitsDAO.deleteOliveUnitsByEditId(env.getSessionId(), u.getEditId());
			} else {
				u.setEditStatus(EditStatus.DELETED);
				u.setFlDeletable(1);
				if(u.getEditId() != null) {
					editOliveUnitsDAO.updateEditOliveUnitDetail(env.getSessionId(), u);
				} else {
					u.setEditId(editOliveUnitsDAO.nextEditOliveUnitDetailPkidVal());
					u.setEditLandCoverId(editLandCover.getEdit_id());
					editOliveUnitsDAO.insertEditOliveUnitDetail(env, u);
				}
			}
		}); 
		
	}

	public void copyLandCoverOliveUnits(EditorSupportParams params, LandCoversEditResult landCoversEditResult, 
			Boolean deleteSourceOliveUnit) {
		ServiceSupportEnv env  = checkAndBuildServiceSupportEnv(params);

		// new landCovers
		landCoversEditResult.getAdded().stream().forEach(lc -> {
			if(lc.getParent_id() != null) {
				internalCopyLandCoverOliveUnits(params, lc.getParent_id(), lc, deleteSourceOliveUnit);
			}
		});

		landCoversEditResult.getUpdated().stream()
		.filter(lc -> !lc.getEdit_status().equals(EditStatus.TOPOLOGY_CORRECTED))
		.forEach(landCover -> {
			LandCoverNTT editLandCover = editUnitsSupportService.setInEditLandCoverById(params, landCover.getId(), EditStatus.NOT_IN_EDIT);

			List<OliveUnitDetailsNTT> oliveUnits = getOliveUnitsNTT(params, editLandCover.getLand_cover_id(), null);

			oliveUnits.stream().forEach(u -> {

				u.setEditStatus(EditStatus.IN_EDIT);
				u.setFlDeletable(boolToInt(isDeletable(env, editLandCover.getLand_cover_id(), u.getUnitId())));

				if(u.getEditId() == null) {
					u.setEditId(editOliveUnitsDAO.nextEditOliveUnitDetailPkidVal());
					u.setEditLandCoverId(editLandCover.getEdit_id());
					editOliveUnitsDAO.insertEditOliveUnitDetail(env, u);	
				} else {
					editOliveUnitsDAO.updateEditOliveUnitDetail(env.getSessionId(), u);
				}
			}); 

			landCover.setUnit_types(supportDAO.getCompatibleUnitTypesByLandCoverCode(env.getTenantId(), landCover.getCode()));
			landCover.setOlive_units(internalGetOliveUnits(params, landCover.getId(), null));
		});
	}
	
	private void internalCopyLandCoverOliveUnits(EditorSupportParams params, Long sourceLandCoverId, LandCoverWithUnits targetLandCover,
			Boolean deleteSource) {

		if(sourceLandCoverId == null || targetLandCover == null) {
			return;
		}
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		LandCoverNTT targetEditLandCoverNTT = editUnitsSupportService.setInEditLandCoverById(params, targetLandCover.getId(), EditStatus.NOT_IN_EDIT);
		LandCoverNTT sourceEditLandCoverNTT = editUnitsSupportService.setInEditLandCoverById(params, sourceLandCoverId, EditStatus.NOT_IN_EDIT);

		List<OliveUnitDetailsNTT> inEditOliveUnits = getOliveUnitsNTT(params, sourceLandCoverId, null);

		inEditOliveUnits.stream().forEach(u -> {
			u = setInEditOliveUnitById(params, u.getUnitId(), EditStatus.NOT_IN_EDIT);
			OliveUnitDetailsNTT oliveUnitToInsert = OliveUnitDetailsNTT.builder()
					.editId(editOliveUnitsDAO.nextEditOliveUnitDetailPkidVal())
					.editLandCoverId(targetEditLandCoverNTT.getEdit_id())
					.unitId(editOliveUnitsDAO.nextNewOliveUnitIdVal())
					.unitCode(u.getUnitCode())
					.parentUnitCode(u.getParentUnitCode())
					.typeCode(UNIT_TYPE)
					.variety(u.getVariety())
					.areaSqm(u.getAreaSqm())
					.plantingDay(u.getPlantingDay())
					.plantingDayPrecision(u.getPlantingDayPrecision())
					.eradicateDay(u.getEradicateDay())
					.plantingType(u.getPlantingType())
					.distanceOnTheRowCM(u.getDistanceOnTheRowCM())
					.distanceBetweenRowsCM(u.getDistanceBetweenRowsCM())
					.plantsNumber(u.getPlantsNumber())
					.farmingForm(u.getFarmingForm())
					.irrigation(u.getIrrigation())
					.productDestination(u.getProductDestination())
					.altitudeAboveSeaLevel(u.getAltitudeAboveSeaLevel())
					.qualitySystem(u.getQualitySystem())
					.protectionStructure(u.getProtectionStructure())
					.externalCode(u.getExternalCode())
					.editStatus(EditStatus.IN_EDIT)
					.flDeletable(1)
					.build();

			editOliveUnitsDAO.insertEditOliveUnitDetail(env, oliveUnitToInsert);

			if(u.getUnitId() < 0 && Boolean.TRUE.equals(deleteSource)) {
				editOliveUnitsDAO.deleteOliveUnitsByEditId(env.getSessionId(), u.getEditId());
			} else if(u.getUnitId() > 0 && Boolean.TRUE.equals(deleteSource)) {
				u.setEditStatus(EditStatus.DELETED);
				u.setFlDeletable(1);
				if(u.getEditId() != null) {
					editOliveUnitsDAO.updateEditOliveUnitDetail(env.getSessionId(), u);
				} else {
					u.setEditId(editOliveUnitsDAO.nextEditOliveUnitDetailPkidVal());
					u.setEditLandCoverId(sourceEditLandCoverNTT.getEdit_id());
					editOliveUnitsDAO.insertEditOliveUnitDetail(env, u);
				}
			}
		});

		targetLandCover.setUnit_types(supportDAO.getCompatibleUnitTypesByLandCoverCode(env.getTenantId(), targetLandCover.getCode()));
		targetLandCover.setOlive_units(internalGetOliveUnits(params, targetLandCover.getId(), null));
	}

	public void mergeLandCoverOliveUnits(EditorSupportParams params, Long targetLandCoverId, LandCoversEditResult landCoversEditResult) {
		editUnitsSupportService.setInEditLandCoverById(params, targetLandCoverId, EditStatus.NOT_IN_EDIT); 

		landCoversEditResult.getDeleted().stream()
		.forEach(landCover -> internalCopyLandCoverOliveUnits(params, 
				landCover, 
				landCoversEditResult.getUpdated().stream()
				.filter(lc -> lc.getId().equals(targetLandCoverId))
				.findFirst()
				.orElse(null),
				true
				));
	}	
	
	private Boolean isEditable(EditorSupportParams params, OliveUnit oliveUnit) {
		LocalDate refDate = params.getSession().getReference_date().toLocalDate();
		return !(refDate.isBefore(oliveUnit.getPlantingDay().toLocalDate()) && refDate.isAfter(oliveUnit.getEradicateDay().toLocalDate()));
	}
	

	public void mergeParcelLandCoverOliveUnits(EditorSupportParams params, LandCoversEditResult landCoversEditResult) {
		landCoversEditResult.getAdded().stream()
		.filter(landCover -> landCover.getParent_id() != null)
		.forEach(landCover -> internalCopyLandCoverOliveUnits(params, landCover.getParent_id(), landCover, true));
	}	
	
}
