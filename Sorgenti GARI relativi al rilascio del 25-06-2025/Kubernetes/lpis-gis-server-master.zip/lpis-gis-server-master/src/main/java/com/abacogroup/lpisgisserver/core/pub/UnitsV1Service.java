package com.abacogroup.lpisgisserver.core.pub;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lpisgisserver.core.AnomaliesService;
import com.abacogroup.lpisgisserver.core.BaseService;
import com.abacogroup.lpisgisserver.core.CLLService;
import com.abacogroup.lpisgisserver.core.ErrorDescriptionsService;
import com.abacogroup.lpisgisserver.core.ExternalConfigService;
import com.abacogroup.lpisgisserver.core.InternalConfigService;
import com.abacogroup.lpisgisserver.core.StyleService;
import com.abacogroup.lpisgisserver.core.UnitsService;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.mappers.pub.BlockV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.DoIgtV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.FruitUnitV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.OliveUnitV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.SectorV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.VarietyV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.VineUnitV1Mapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.UnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.VineUnitsDAO;
import com.abacogroup.lpisgisserver.db.ntt.SectorSummaryNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.VarietySummaryNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineAptitudeNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.mappings.SectorSummaryMappings;
import com.abacogroup.lpisgisserver.mappings.VarietySummaryMappings;
import com.abacogroup.lpisgisserver.resources.req.ReqContext;
import com.abacogroup.lpisgisserver.resources.res.anomalies.AnomaliesList;
import com.abacogroup.lpisgisserver.resources.res.anomalies.Anomaly;
import com.abacogroup.lpisgisserver.resources.res.pub.units.SectorSummaryV1;
import com.abacogroup.lpisgisserver.resources.res.pub.units.VarietySummaryV1;
import com.abacogroup.lpisgisserver.resources.res.pub.units.fruit.FruitUnitWithParcelDetailsV1;
import com.abacogroup.lpisgisserver.resources.res.pub.units.olive.OliveUnitWithParcelDetailsV1;
import com.abacogroup.lpisgisserver.resources.res.pub.units.vine.DoIgtAptitudeWithAreasV1;
import com.abacogroup.lpisgisserver.resources.res.pub.units.vine.DoIgtVineUnitAptitudeSummaryV1;
import com.abacogroup.lpisgisserver.resources.res.pub.units.vine.VineUnitWithParcelDetailsV1;
import com.google.common.collect.Iterators;
import com.google.common.collect.UnmodifiableIterator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UnitsV1Service extends BaseService {

	private final VineUnitsDAO vineUnitsDAO;
	private final UnitsDAO unitsDAO;
	private final UnitsService unitsService;
	private final CLLService cllService;
	private final AnomaliesService anomaliesService;

	public UnitsV1Service(DAOContainer dc, UnitsService unitsService, CLLService cllService, InternalConfigService conf, ExternalConfigService externalConf,
                          ErrorDescriptionsService errorDescriptionsService, StyleService styleService,
                          PluginEnvironment pluginEnvironment,AnomaliesService anomaliesService) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.vineUnitsDAO = dc.getVineUnitsDAO();
		this.unitsDAO = dc.getUnitsDAO();
		this.unitsService = unitsService;
		this.cllService = cllService;
        this.anomaliesService = anomaliesService;
    }

	/// Vine sector summary
	public List<SectorSummaryV1> getVineUnitSectorSummaryByPartyId(ReqContext reqContext, ServiceSupportEnv env, Boolean showOutdatedUnits) {
		List<Long> parcelIdsList = cllService.getSubjectParcels(reqContext, env);

		Boolean showUncategorizedAnomalyTypes = internalConf.getBooleanValue(reqContext.getTenantId(), InternalConfigKeys.FL_SHOW_UNCATEGORIZED_ANOMALY_TYPES_KEY.getKey());
		
		List<Anomaly> anomaliesList = new ArrayList<>();
		// NB: Anomalies-Registry accept up to 1000 parcel ids. If you want to fetch more you need to change
		// it's validator or else it will return a BadRequest.
		UnmodifiableIterator<List<Long>> parcelAnomaliesPartition = Iterators.partition(parcelIdsList.iterator(), 1000);

		parcelAnomaliesPartition.forEachRemaining(parcelIdPartition -> {
			AnomaliesList parcelAnomaliesInternal = anomaliesService.getParcelAnomaliesInternal(reqContext, parcelIdPartition, showUncategorizedAnomalyTypes);
			anomaliesList.addAll(parcelAnomaliesInternal.getAnomalies_list());
		});

		Map<String, List<Anomaly>> parcelAnomalyMap = anomaliesList
				.stream()
				.collect(Collectors.groupingBy(Anomaly::getEntityId));

		List<SectorSummaryNTT> sectorSummaryNTTs = new ArrayList<>();

		UnmodifiableIterator<List<Long>> partitions = Iterators.partition(parcelIdsList.iterator(), 666);
		partitions.forEachRemaining(partition -> sectorSummaryNTTs.addAll(unitsDAO.getSectorSummaryByParcelIds(env, partition, Boolean.TRUE.equals(showOutdatedUnits) ? 1 : 0)));

		return SectorSummaryMappings.groupSummaryBySectorId(sectorSummaryNTTs, parcelAnomalyMap);
	}

	/// Fruit sector summary
	public List<SectorSummaryV1> getFruitUnitSectorSummaryByPartyId(ReqContext reqContext, ServiceSupportEnv env, Integer showOutdatedUnits) {
		List<Long> parcelIdsList = cllService.getSubjectParcels(reqContext, env);

		Map<String, List<Anomaly>> allParcelsAnomaliesGroupedByEntityId =
				getAllParcelsAnomaliesGroupedByEntityId(reqContext, parcelIdsList);

		List<SectorSummaryNTT> sectorSummaryNTTs = new ArrayList<>();

		UnmodifiableIterator<List<Long>> partitions = Iterators.partition(parcelIdsList.iterator(), 555);
		partitions.forEachRemaining(partition -> sectorSummaryNTTs.addAll(unitsDAO.getFruitSectorSummaryByParcelIds(env, partition, showOutdatedUnits)));

		return SectorSummaryMappings.groupSummaryBySectorId(sectorSummaryNTTs, allParcelsAnomaliesGroupedByEntityId);
	}

	/// Olive sector summary
	public List<SectorSummaryV1> getOliveUnitSectorSummaryByPartyId(ReqContext reqContext, ServiceSupportEnv env, Integer showOutdatedUnits) {
		List<Long> parcelIdsList = cllService.getSubjectParcels(reqContext, env);

		Map<String, List<Anomaly>> allParcelsAnomaliesGroupedByEntityId =
				getAllParcelsAnomaliesGroupedByEntityId(reqContext, parcelIdsList);

		List<SectorSummaryNTT> sectorSummaryNTTs = new ArrayList<>();

		UnmodifiableIterator<List<Long>> partitions = Iterators.partition(parcelIdsList.iterator(), 555);
		partitions.forEachRemaining(partition -> sectorSummaryNTTs.addAll(unitsDAO.getOliveSectorSummaryByParcelIds(env, partition, showOutdatedUnits)));

		return SectorSummaryMappings.groupSummaryBySectorId(sectorSummaryNTTs, allParcelsAnomaliesGroupedByEntityId);
	}

	// Olive variety summary
	public List<VarietySummaryV1> getOliveUnitVarietySummaryByPartyId(ReqContext reqContext, ServiceSupportEnv env, Integer showOutdatedUnits) {
		List<Long> parcelIdsList = cllService.getSubjectParcels(reqContext, env);
		List<VarietySummaryNTT> varietySummaryNTTs = new ArrayList<>();
		Map<String, List<Anomaly>> parcelAnomalyMap = getAllParcelsAnomaliesGroupedByEntityId(reqContext, parcelIdsList);

		UnmodifiableIterator<List<Long>> partitions = Iterators.partition(parcelIdsList.iterator(), 666);
		partitions.forEachRemaining(partition -> varietySummaryNTTs.addAll(unitsDAO.getOliveVarietySummaryByParcelIds(env, partition, showOutdatedUnits)));

		return VarietySummaryMappings.getGroupedVarietyBySectorId(varietySummaryNTTs, parcelAnomalyMap);
	}

	// Fruit variety summary
	public List<VarietySummaryV1> getFruitUnitVarietySummaryByPartyId(ReqContext reqContext, ServiceSupportEnv env, Integer showOutdatedUnits) {
		List<Long> parcelIdsList = cllService.getSubjectParcels(reqContext, env);
		List<VarietySummaryNTT> varietySummaryNTTs = new ArrayList<>();
		Map<String, List<Anomaly>> parcelAnomalyMap = getAllParcelsAnomaliesGroupedByEntityId(reqContext, parcelIdsList);

		UnmodifiableIterator<List<Long>> partitions = Iterators.partition(parcelIdsList.iterator(), 666);
		partitions.forEachRemaining(partition -> varietySummaryNTTs.addAll(unitsDAO.getFruitVarietySummaryByParcelIds(env, partition, showOutdatedUnits)));

		return VarietySummaryMappings.getGroupedVarietyBySectorId(varietySummaryNTTs, parcelAnomalyMap);
	}

	// Vine variety summary
	public List<VarietySummaryV1> getVineUnitVarietySummaryByPartyId(ReqContext reqContext, ServiceSupportEnv env, Boolean showOutdatedUnits) {
		List<Long> parcelIdsList = cllService.getSubjectParcels(reqContext, env);
		List<VarietySummaryNTT> varietySummaryNTTs = new ArrayList<>();
		
		Boolean showUncategorizedAnomalyTypes = internalConf.getBooleanValue(reqContext.getTenantId(), InternalConfigKeys.FL_SHOW_UNCATEGORIZED_ANOMALY_TYPES_KEY.getKey());

		// NB: Anomalies-Registry accept up to 1000 parcel ids. If you want to fetch more you need to change
		// it's validator or else it will return a BadRequest.
		List<Anomaly> anomaliesList = new ArrayList<>();
		// Better not send to many ids as query param since we can
		UnmodifiableIterator<List<Long>> parcelAnomaliesPartition = Iterators.partition(parcelIdsList.iterator(), 1000);

		parcelAnomaliesPartition.forEachRemaining(parcelIdPartition -> {
			AnomaliesList parcelAnomaliesInternal = anomaliesService.getParcelAnomaliesInternal(reqContext, parcelIdPartition, showUncategorizedAnomalyTypes);
			anomaliesList.addAll(parcelAnomaliesInternal.getAnomalies_list());
		});

		Map<String, List<Anomaly>> parcelAnomalyMap = anomaliesList
				.stream()
				.collect(Collectors.groupingBy(Anomaly::getEntityId));

		UnmodifiableIterator<List<Long>> partitions = Iterators.partition(parcelIdsList.iterator(), 666);
		partitions.forEachRemaining(partition -> varietySummaryNTTs.addAll(unitsDAO.getVineVarietySummaryByParcelIds(env, partition, Boolean.TRUE.equals(showOutdatedUnits) ? 1 : 0)));

		return VarietySummaryMappings.getGroupedVarietyBySectorId(varietySummaryNTTs, parcelAnomalyMap);
	}

	public List<DoIgtAptitudeWithAreasV1> getVineAptitudesSummary(ReqContext reqContext, ServiceSupportEnv env) {
		List<String> categoryOrder = Arrays.asList("docg", "doc", "igt");
		List<Long> parcelIdsList = cllService.getSubjectParcels(reqContext, env);

		List<VineAptitudeNTT> aptitudesByParcelIdList = vineUnitsDAO.getAptitudesByParcelIdList(env, parcelIdsList);
		Map<Long, DoIgtAptitudeWithAreasV1> aptitudeWithAreas = aptitudesByParcelIdList.stream()
				.map(vineAptitudeNTT -> DoIgtAptitudeWithAreasV1.builder()
						.doIgt(DoIgtV1Mapper.INSTANCE.toResponseV1(vineAptitudeNTT.getDoigt()))
						.areaSqm(vineAptitudeNTT.getAreaSqm())
						.areaClaims(vineAptitudeNTT.getFlPreventClaim() == 1 ? vineAptitudeNTT.getAreaSqm() : 0.0)
						.areaSuitability(vineAptitudeNTT.getFlPreventSuitability() == 1 ? vineAptitudeNTT.getAreaSqm() : 0.0)
						.areaTypology(vineAptitudeNTT.getFlPreventTypology() == 1 ? vineAptitudeNTT.getAreaSqm() : 0.0)
						.build())
				.collect(Collectors.groupingBy(
						v -> v.getDoIgt().getId(),
						Collectors.reducing(
								new DoIgtAptitudeWithAreasV1(),
								(s1, s2) -> DoIgtAptitudeWithAreasV1.builder()
								.doIgt(Optional.ofNullable(s1.getDoIgt()).orElse(s2.getDoIgt()))
								.areaSqm(Optional.ofNullable(s1.getAreaSqm()).orElse(0.0) + Optional.ofNullable(s2.getAreaSqm()).orElse(0.0))
								.areaTypology(Optional.ofNullable(s1.getAreaTypology()).orElse(0.0) + Optional.ofNullable(s2.getAreaTypology()).orElse(0.0))
								.areaClaims(Optional.ofNullable(s1.getAreaClaims()).orElse(0.0) + Optional.ofNullable(s2.getAreaClaims()).orElse(0.0))
								.areaSuitability(Optional.ofNullable(s1.getAreaSuitability()).orElse(0.0) + Optional.ofNullable(s2.getAreaSuitability()).orElse(0.0))
								.build())
						));

		// Since it's a special ordering it cannot be done by the DB. We must do it by hands
		Comparator<DoIgtAptitudeWithAreasV1> categoryComparator = Comparator
				.comparing(o -> categoryOrder.indexOf(o.getDoIgt().getCategoryDescription().toLowerCase()));
		Comparator<DoIgtAptitudeWithAreasV1> codeComparator = Comparator.comparing(o -> o.getDoIgt().getCode());
		Comparator<DoIgtAptitudeWithAreasV1> categoryThenCodeComparator = categoryComparator.thenComparing(codeComparator);

		return aptitudeWithAreas.values().stream().sorted(categoryThenCodeComparator).collect(Collectors.toList());
	}

	public InfiniteListResults<DoIgtVineUnitAptitudeSummaryV1> getDoIgtVineUnitAptitudes(ReqContext reqContext, ServiceSupportEnv env, String doIgtCode, AbsoluteDate referenceDate) {
		List<Long> subjectParcels = cllService.getSubjectParcels(reqContext, env);

		if (subjectParcels.isEmpty()) {
			return new InfiniteListResultsImpl<>(new ArrayList<>(), null);
		}

		return vineUnitsDAO
				.infinite(() -> vineUnitsDAO.getDoIgtVineUnitAptitudes(reqContext.getTenantId(), reqContext.getLang(), doIgtCode, referenceDate, subjectParcels),
						env.getNextKey(),
						env.getPageSize()
				).map(el -> {
					if (el.getVineAptitude().getFlPreventClaim() == 1 || el.getVineAptitude().getFlPreventSuitability() == 1
							|| el.getVineAptitude().getFlPreventTypology() == 1) {
						el.setRegisteredAreaSmq(el.getAreaSqm());
					} else {
						el.setRegisteredAreaSmq(0.0);
					}

					return DoIgtVineUnitAptitudeSummaryV1
							.builder()
							.parcelId(el.getParcelId())
							.landCoverId(el.getLandCoverId())
							.vineUnitId(el.getVineUnitId())
							.vineUnitCode(el.getVineUnitCode())
							.areaSqm(el.getAreaSqm())
							.registeredAreaSmq(el.getRegisteredAreaSmq())
							.parcelCode(el.getParcelCode())
							.vineAptitudeId(el.getVineAptitude().getAptitudeId())
							.preventTypology(el.getVineAptitude().getFlPreventTypology() == 1)
							.preventClaim(el.getVineAptitude().getFlPreventClaim() == 1)
							.preventSuitability(el.getVineAptitude().getFlPreventSuitability() == 1)
							.variety(VarietyV1Mapper.INSTANCE.toResponseV1(el.getVariety()))
							.block(BlockV1Mapper.INSTANCE.toResponseV1(el.getBlock()))
							.sector(SectorV1Mapper.INSTANCE.toResponseV1(el.getSector()))
							.build();
				});
	}

	private Map<String, List<Anomaly>> getAllParcelsAnomaliesGroupedByEntityId(ReqContext reqContext, List<Long> parcelIds) {
		List<Anomaly> anomaliesList = new ArrayList<>();
		
		Boolean showUncategorizedAnomalyTypes = internalConf.getBooleanValue(reqContext.getTenantId(), InternalConfigKeys.FL_SHOW_UNCATEGORIZED_ANOMALY_TYPES_KEY.getKey());
		
		// NB: Anomalies-Registry accept up to 1000 parcel ids. If you want to fetch more you need to change
		// it's validator or else it will return a BadRequest.
		UnmodifiableIterator<List<Long>> parcelAnomaliesPartition = Iterators.partition(parcelIds.iterator(), 1000);

		parcelAnomaliesPartition.forEachRemaining(parcelIdPartition -> {
			AnomaliesList parcelAnomaliesInternal = anomaliesService.getParcelAnomaliesInternal(reqContext, parcelIdPartition, showUncategorizedAnomalyTypes);
			anomaliesList.addAll(parcelAnomaliesInternal.getAnomalies_list());
		});


		return anomaliesList
				.stream()
				.collect(Collectors.groupingBy(Anomaly::getEntityId));
	}

	public VineUnitWithParcelDetailsV1 getVineUnitByCode(ServiceSupportEnv env, String unitCode) {
		return VineUnitV1Mapper.INSTANCE.toResponseV1(unitsService.getVineUnitByCode(env, unitCode));
	}
	
	public OliveUnitWithParcelDetailsV1 getOliveUnitByCode(ServiceSupportEnv env, String unitCode) {
		return OliveUnitV1Mapper.INSTANCE.toResponseV1(unitsService.getOliveUnitByCode(env, unitCode));
	}
	
	public FruitUnitWithParcelDetailsV1 getFruitUnitByCode(ServiceSupportEnv env, String unitCode) {
		return FruitUnitV1Mapper.INSTANCE.toResponseV1(unitsService.getFruitUnitByCode(env, unitCode));
	}
}
