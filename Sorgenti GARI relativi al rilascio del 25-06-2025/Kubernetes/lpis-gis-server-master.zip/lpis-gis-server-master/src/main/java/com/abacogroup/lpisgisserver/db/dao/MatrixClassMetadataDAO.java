package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassMetadataNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface MatrixClassMetadataDAO extends Transactional<MatrixClassMetadataDAO>, EnhancedSqlObject {

	@SqlUpdate("INSERT INTO lpis_matrix_class_metadata (tenant_id, matrix_id, class_code, key, value, day_from, day_to, user_id_insert, user_id_delete, dt_insert, dt_delete) "
			+ "VALUES(:tenant_id, :matrix_id, :class_code, :key, :value, :day_from, :day_to, :user_id_insert, NULL, §current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insert(@BindBean MatrixClassMetadataNTT ntt, @Bind("user_id_insert") String userId);

	@SqlUpdate("update lpis_matrix_class_metadata \n"
			+ "   set user_id_delete = :user_id_delete, \n"
			+ "       dt_delete = §current_timestamp§ \n"
			+ " where tenant_id = :tenant_id \n"
			+ "   and matrix_id = :matrix_id \n"
			+ "   and class_code = :class_code \n"
			+ "   and key = :key \n"
			+ "   and :referenceDate between day_from and day_to \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n")
	void logicallyDelete(@BindBean MatrixClassMetadataNTT ntt, @Bind("user_id_delete") String userId);

	@SqlQuery("select tenant_id, \n"
			+ "       matrix_id, \n"
			+ "       class_code, \n"
			+ "       key, \n"
			+ "       value, \n"
			+ "       day_from, \n"
			+ "       day_to \n"
			+ "  from lpis_matrix_class_metadata \n"
			+ " where tenant_id = :tenant_id \n"
			+ "   and matrix_id = :matrix_id \n"
			+ "   and class_code = :class_code \n"
			+ "   and (:key is null or key = :key) \n"
			+ "   and :referenceDate between day_from and day_to \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(MatrixClassMetadataNTT.class)
	List<MatrixClassMetadataNTT> getClassMetadataByMatrixIdClassCodeAndKey(
			@Bind("tenant_id") String tenantId,
			@Bind("matrix_id") Long matrixId,
			@Bind("class_code") String classCode,
			@Bind("referenceDate") AbsoluteDate referenceDate,
			@Bind("key") String key);
	
	@SqlQuery("select lm.tenant_id, \n"
			+ "       lm.id as matrix_id, \n"
			+ "       lmcm.class_code, \n"
			+ "       lmcm.key, \n"
			+ "       lmcm.value, \n"
			+ "       lmcm.day_from, \n"
			+ "       lmcm.day_to \n"
			+ "  from lpis_matrix_class_metadata lmcm \n"
			+ " inner join lpis_matrix lm on lmcm.matrix_id = lm.id and lmcm.tenant_id = lm.tenant_id \n"
			+ " where lm.tenant_id = :tenant_id \n"
			+ "   and lm.code = :matrix_code \n"
			+ "   and lmcm.class_code = :class_code \n"
			+ "   and (:key is null or lmcm.key = :key) \n"
			+ "   and :referenceDate between lmcm.day_from and lmcm.day_to \n"
			+ "   and §current_timestamp§ between lmcm.dt_insert and lmcm.dt_delete")
	@RegisterBeanMapper(MatrixClassMetadataNTT.class)
	List<MatrixClassMetadataNTT> getClassMetadataByMatrixCodeClassCodeAndKey(
			@Bind("tenant_id") String tenantId,
			@Bind("matrix_code") String matrixCode,
			@Bind("class_code") String classCode,
			@Bind("referenceDate") AbsoluteDate referenceDate,
			@Bind("key") String key);
}
