package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.resources.res.pub.info.ParcelInfoV1;

import com.abacogroup.lpisgisserver.resources.res.info.ParcelInfo;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ParcelsInfoV1Mapper {

	ParcelsInfoV1Mapper INSTANCE = Mappers.getMapper(ParcelsInfoV1Mapper.class);

	@InheritInverseConfiguration()
	ParcelInfoV1 toResponseV1(ParcelInfo entity);

}
