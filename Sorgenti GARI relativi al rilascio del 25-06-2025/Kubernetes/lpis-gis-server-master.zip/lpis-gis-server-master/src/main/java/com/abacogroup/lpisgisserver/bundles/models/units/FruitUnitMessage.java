package com.abacogroup.lpisgisserver.bundles.models.units;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FruitUnitMessage {
	
	private List<UnitVarietyMessage> variety_codes;
	private List<UnitPlantingTypeMessage> planting_type_codes;
	private List<UnitFarmingFormMessage> farming_forms;
	private List<UnitIrrigationTypeMessage> irrigation_types;
	private List<UnitQualitySystemMessage> quality_system_codes;
	private List<UnitProtectionStructureMessage> protection_structure_codes; 
	
}