package com.abacogroup.lpisgisserver.core;

import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.farmland.GenericFarmlandException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidUserEditSessionException;
import com.abacogroup.lpisgisserver.core.models.cll.CllParcelInfiniteList;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.AreasDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.ParcelsDAO;
import com.abacogroup.lpisgisserver.db.ntt.cache.PartyParcelNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.ReqContext;
import com.abacogroup.lpisgisserver.resources.res.cll.CllParcelsRes;
import com.google.common.collect.Iterators;
import com.google.common.collect.UnmodifiableIterator;

import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CLLService extends BaseService {
	
	private ParcelsDAO parcelsDAO;
	private AreasDAO areasDAO;
	
	private CacheService<PartyParcelNTT> cachePartyParcelService;

	private WebTarget cllWebTarget;

	private static final String DEFAULT_LANG_CODE = "en";
	
	// CLL API PATHs
	private static final String GET_SEARCH_LAND_LINKS_PATH = "/{tenant}/public/v1/parties/{partyId}/land-links/{referenceDate}";

	/**
	 * Customer Land Link service
	 * Manages communications with the Customer Land Link service
	 */
	public CLLService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf, 
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, 
			PluginEnvironment pluginEnvironment, WebTarget cllWebTarget, CacheService<PartyParcelNTT> cachePartyParcelService) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.parcelsDAO = dc.getParcelsDAO();
		this.areasDAO = dc.getAreasDAO();
		
		this.cachePartyParcelService = cachePartyParcelService;
		
		this.cllWebTarget = cllWebTarget;
	}

	public List<Long> getSubjectParcels(ReqContext reqContext, ServiceSupportEnv env) {
		List<Long> subjectParcelIds = new ArrayList<>();

		CllParcelsRes result = getPartyParcels(reqContext, env);
		if(result != null && !StringUtils.isBlank(result.getError())) {
			GenericFarmlandException ex = new GenericFarmlandException(Status.BAD_REQUEST, Operation.GET_CLL_PARTY_PARCELS, ErrorField.REQUEST,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error("{}\n{}", ex.getBody().getLogErrorMessage(), result.getError());

			throw ex;
		}

		if(result != null && result.getParcelsIdList() != null)
			subjectParcelIds.addAll(result.getParcelsIdList());

		if (subjectParcelIds.isEmpty())
			subjectParcelIds.add(-1L);

		return subjectParcelIds;
	}
	
	/**
	* Get list of parcels linked to customer land. This method is called by Farmland to get list of parcels linked to customer land
	* 
	* @param reqContext - request context for obtaining link list
	* @param env - service support environment for obtaining link list.
	* 
	* @return CllParcelsRes object containing list of parcels linked to customer land. Null if not
	*/
	public CllParcelsRes getPartyParcels(ReqContext reqContext, ServiceSupportEnv env){
		
		// If env is null the method will throw an exception.
		if(env == null) {
			GenericFarmlandException ex = new GenericFarmlandException(Status.BAD_REQUEST, Operation.GET_CLL_PARTY_PARCELS, ErrorField.REQUEST,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		String partyId = null;
		if(env.getPartyId() != null) {
			partyId = env.getPartyId().toString();
		}
		
		Criteria criteria = CriteriaBuilder.string("party_id").eq(partyId);
		
		List<Long> parcelIdList = cachePartyParcelService.getData(env, criteria).stream()
				.map(PartyParcelNTT::getParcelId)
				.collect(Collectors.toList());

		// Loads parcel ids from the request context.
		if(parcelIdList == null || parcelIdList.isEmpty()) {
			return loadParcelIdList(reqContext, env);
		}

		return CllParcelsRes.builder().parcelsIdList(parcelIdList).build();
	}
	
	/**
	* Loads the parcel ids. This is used to get the list of parcels that the user has access to
	* 
	* @param reqContext - request context for obtaining auth token and tenant id
	* @param env - service support environment for obtaining language and tenant id
	* 
	* @return CllParcelsRes object with list of parcel ids or null if env is null or
	*/
	private CllParcelsRes loadParcelIdList(ReqContext reqContext, ServiceSupportEnv env) {
		// Returns the environment or null if no environment is set.
		if(env == null)
			return null;
		
		CllParcelsRes result = CllParcelsRes.builder().parcelsIdList(new ArrayList<>()).build();
		
		String lang =  env.getLang();
		String authToken = reqContext.getUser().getAuthToken(); // XXX Does it keep to be valid?
		String tenantId = reqContext.getUser().getTenant();

		checkInvalidUserEditSession(lang, authToken, tenantId);

		buildParcelsIdList(env, result, lang, authToken, tenantId);

		// Cache the customer land links for this request.
		if(!result.getParcelsIdList().isEmpty()) {
			List<PartyParcelNTT> dataList = result.getParcelsIdList().stream()
					.filter(parcelId -> parcelId != null) // ATTENZIONE: questo filtro potrebbe escludere le conduzioni del soggetto
														  // che non hanno un ID di riferimento su LPIS.
														  // Questo comportamento si verifica solo in caso di gestioni esterne a New-Agri.
					.distinct()
					.map(parcelId -> PartyParcelNTT.builder()
							.parcelId(parcelId)
							.partyId(env.getPartyId() != null ? env.getPartyId().toString() : null)
							.build())
					.collect(Collectors.toList());
			
			cachePartyParcelService.loadData(env, dataList);
		}
		
		return result;
	}

	private void buildParcelsIdList(ServiceSupportEnv env, CllParcelsRes result, String lang, String authToken, String tenantId) {
		Response response = null;
		CllParcelInfiniteList cllParcelsResponse = null;
		Long nextKey = null;
		do {
			try {
				response =  cllWebTarget
						.path(GET_SEARCH_LAND_LINKS_PATH)
						.resolveTemplate("tenant", tenantId)
						.resolveTemplate("partyId", env.getPartyId())
						.resolveTemplate("referenceDate", env.getReferenceDate())
						// ---------------------------------- ????
						.queryParam("nextKey", cllParcelsResponse != null ? cllParcelsResponse.getNextKey() : null) 
						// ---------------------------------- ????				
						.queryParam("page_size", 100)
						.request(MediaType.APPLICATION_JSON_TYPE)
						.accept(MediaType.APPLICATION_JSON_TYPE)
						.header(ACCEPT_LANGUAGE, lang)
						.header("Authorization", String.format(JWT_PREFIX, authToken))
						.get();

				nextKey = null;
				// This method is called when the response is 200 and the response is 200 and the response is a list of Parcels.
				if (response.getStatus() == 200) {
					response.bufferEntity();
					cllParcelsResponse = response.readEntity(CllParcelInfiniteList.class);
					// This method will add all the parcels to the result.
					if(cllParcelsResponse != null) {
						result.getParcelsIdList().addAll(cllParcelsResponse.getRecords().stream().map(p -> p.getParcel().getId()).collect(toList()));
						nextKey = cllParcelsResponse.getNextKey();
					}
				} else {
					Map<String, Object> errorResponse = response.readEntity(new GenericType<HashMap<String, Object>>() { });
					String errorCode = (String) errorResponse.get("errorCode");
					errorCode += ", " + (String) errorResponse.get("message");
					result.setError(errorCode);
				}

			} catch (Exception e) {
				result.setError("internal error: "+e.getMessage());
			}
		} while (nextKey != null);
	}

	private void checkInvalidUserEditSession(String lang, String authToken, String tenantId) {
		// If the user has no parameters.
		if (lang == null || authToken == null || tenantId == null) {
			InvalidUserEditSessionException ex = new InvalidUserEditSessionException(Status.BAD_REQUEST,
					Operation.GET_CLL_PARTY_PARCELS, ErrorField.REQUEST_CONTEXT,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}
	

	public List<Long> getPartyParcelIds(ReqContext reqContext, ServiceSupportEnv env, Long filteredParentAreaId) {
		
		if(Boolean.TRUE.equals(internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.MOCK_FARMLAND_VIEWER_PARCEL_LIST.getKey()))) {
			Integer partyMod = 0;
			try {
				partyMod = (int) (env.getPartyId() % 4);
			} catch (Exception e) { // nothing to do
			}
			
			// MOCKED SEARCH
			return parcelsDAO.getMockPartyParcels(env.getTenantId(), partyMod);
		}

		List<Long> subjectParcelIds = new ArrayList<>();

		// -----------------------------------
		CllParcelsRes result = getPartyParcels(reqContext, env);
		if(result != null && !StringUtils.isBlank(result.getError())) {
			GenericFarmlandException ex = new GenericFarmlandException(Status.BAD_REQUEST, Operation.GET_CLL_PARTY_PARCELS, ErrorField.REQUEST,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if(result != null && result.getParcelsIdList() != null) 
			subjectParcelIds.addAll(result.getParcelsIdList());

		// -----------------------------------

		if (filteredParentAreaId != null) {
			final List<Long> filteredIds = new ArrayList<>();
			UnmodifiableIterator<List<Long>> partitions = Iterators.partition(subjectParcelIds.iterator(), 500);
			partitions.forEachRemaining(partition -> {
				List<Long> partial = areasDAO.findFilteredParcelIdsForAreaId(env, filteredParentAreaId, partition);
				if (partial != null)
					filteredIds.addAll(partial);
			});

			subjectParcelIds = filteredIds;

		}

		if (subjectParcelIds.isEmpty())
			subjectParcelIds.add(-1L);

		return subjectParcelIds;
	}
	
	public void updatePartyParcelsCache(ReqContext reqContext, ServiceSupportEnv env) {
		getPartyParcels(reqContext, env);
	}
}
