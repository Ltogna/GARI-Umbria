package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class EditParcelsWithoutParcelCodesException extends AbstractException {

	private static final long serialVersionUID = -4575314691904402988L;

	private static final ErrorCode ERROR_CODE = ErrorCode.EDIT_PARCELS_WITHOUT_PARCEL_CODES;

	public EditParcelsWithoutParcelCodesException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new EditParcelsWithoutParcelCodesExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Some parcel not have code")
	public static class EditParcelsWithoutParcelCodesExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -8592052365501693079L;

		public EditParcelsWithoutParcelCodesExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
