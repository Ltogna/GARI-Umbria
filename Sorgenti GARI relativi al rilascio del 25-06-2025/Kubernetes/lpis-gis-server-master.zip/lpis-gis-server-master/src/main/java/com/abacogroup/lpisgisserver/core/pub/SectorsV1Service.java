package com.abacogroup.lpisgisserver.core.pub;

import java.util.stream.Collectors;

import org.locationtech.jts.geom.Geometry;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lpisgisserver.core.BaseService;
import com.abacogroup.lpisgisserver.core.BlockService;
import com.abacogroup.lpisgisserver.core.ErrorDescriptionsService;
import com.abacogroup.lpisgisserver.core.ExternalConfigService;
import com.abacogroup.lpisgisserver.core.InternalConfigService;
import com.abacogroup.lpisgisserver.core.ParcelsService;
import com.abacogroup.lpisgisserver.core.SectorService;
import com.abacogroup.lpisgisserver.core.StyleService;
import com.abacogroup.lpisgisserver.core.mappers.pub.BlockWithGeomV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.LandCoversV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.ParcelEditStatusV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.ParcelsInfoV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.ParcelsV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.SectorV1Mapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.pub.PublicGetSectorsPayload;
import com.abacogroup.lpisgisserver.resources.res.Sector;
import com.abacogroup.lpisgisserver.resources.res.pub.BlockListV1;
import com.abacogroup.lpisgisserver.resources.res.pub.ParcelEditStatusV1;
import com.abacogroup.lpisgisserver.resources.res.pub.ParcelV1;
import com.abacogroup.lpisgisserver.resources.res.pub.SectorV1;
import com.abacogroup.lpisgisserver.resources.res.pub.info.ParcelInfoV1;

public class SectorsV1Service extends BaseService {
	
	private SectorService sectorService;
	private BlockService blockService;
	private ParcelsService parcelsService;

	public SectorsV1Service(DAOContainer dc, SectorService sectorService, BlockService blockService, ParcelsService parcelsService,
			InternalConfigService conf, ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService, 
			StyleService styleService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);
		
		this.sectorService = sectorService;
		this.blockService = blockService;
		this.parcelsService = parcelsService;
	}


	/**
	 * Get the details of the sector. It is used to create the SectorNTT object which is a reference to the sector in the database
	 * 
	 * @param env - service support environment for obtaining data
	 * 
	 * @return PublicSector object with sector details or null if not found or error in DB ( not logged in
	 */
	public SectorV1 getSectorDetails(ServiceSupportEnv env) {
		return SectorV1Mapper.INSTANCE.toResponseV1(sectorService.getSectorDetailsByTenantAndCode(env, env.getSectorCode()));
	}	

	/**
	 * Returns public sectors matching the filter. This method is useful for filtering public sectors by tenant code and filter
	 * 
	 * @param env - service support environment to use
	 * @param filter - the filter to use for the search. It is case sensitive
	 * 
	 * @return infinite list of public sectors matching the filter or an empty list if none are found ( in which case null is returned
	 */
	public InfiniteListResults<SectorV1> getSectorsWithFilter(ServiceSupportEnv env, String filter) {
		return sectorService.getSectorsWithFilter(env, filter, null)
				.map(SectorV1Mapper.INSTANCE::toResponseV1);
	}

	/**
	 * Returns public sectors matching the given filter. This method is for use by service support providers that do not provide a way to filter public sectors based on their codes.
	 * 
	 * @param env - service support environment for this request. Cannot be null.
	 * @param filter - the filter to use. Cannot be null.
	 * @param payload - the payload that contains the list of codes to search for.
	 * 
	 * @return infinite list of public sectors
	 */
	public InfiniteListResults<SectorV1> getSectorsByCodesWithFilter(ServiceSupportEnv env, String filter, PublicGetSectorsPayload payload) {
		return sectorService.getSectorsWithFilter(env, filter, payload.getCodes())
				.map(SectorV1Mapper.INSTANCE::toResponseV1);
	}

	/**
	 * Get parcels by sector code. This is a query to the service and will return up to pageSize results per page.
	 * 
	 * @param env - service support environment for query. Cannot be null.
	 * @param pageSize - page size. Cannot be null or greater than #MAX_PAGE_SIZE.
	 * 
	 * @return infinite list of public parcels that match the query. If there are no land covers the list will be empty
	 */
	public InfiniteListResults<ParcelV1> getParcelsBySectorCode(ServiceSupportEnv env) {
		InfiniteListResults<ParcelV1> parcels = parcelsService.getParcelsBySectorCode(env)
				.map(ParcelsV1Mapper.INSTANCE::toResponseV1);

		// always exclude units in result
		env.setIncludeUnits(0);
		
		// Set the landcovers list to the list of landcovers.
		if(1 == env.getIncludeLandCovers()) {
			parcels.getRecords().forEach(parcel -> {
				env.setParcelId(parcel.getId());
				env.setSrs(env.getSrs() == null ? parcel.getSrs() : env.getSrs());
				parcel.setLandcovers_list(parcelsService.findLandCoversByParcelId(env, false, false).stream()
						.map(LandCoversV1Mapper.INSTANCE::toResponseV1)
						.collect(Collectors.toList()));
			});
		}
		return parcels;
	}

	/**
	 * Get parcels in interest by sector code. This is a slow operation as it does not require a lot of memory
	 * 
	 * @param env - service support environment for querying
	 * @param geom - geographic geometry to get parcels for
	 * 
	 * @return finite list of public parcels that interact with geom in the secton ( s ) of interest
	 */
	public InfiniteListResults<ParcelInfoV1> getParcelsInInteractionsBySectorCode(ServiceSupportEnv env, Geometry geom) {
		return parcelsService.getParcelsInInteractionsBySectorCode(env, geom)
				.map(ParcelsInfoV1Mapper.INSTANCE::toResponseV1);
	}


	public ParcelEditStatusV1 getParcelsEditStatus(ServiceSupportEnv env, String blockCode, String parcelCode) {
		return ParcelEditStatusV1Mapper.INSTANCE.toResponseV1(parcelsService.getParcelsEditStatus(env, blockCode, parcelCode));
	}


	public BlockListV1 getBlocks(ServiceSupportEnv env, String filter) {
		Sector sector = sectorService.getSectorDetailsByTenantAndCode(env, env.getSectorCode());
		return BlockListV1.builder()
				.blocksList(blockService.getBlocksBySectorIdWithFilter(env, sector.getId(), filter).getBlocks_list().stream()
						.map(BlockWithGeomV1Mapper.INSTANCE::toResponseV1)
						.collect(Collectors.toList()))
				.build();
	}

}
