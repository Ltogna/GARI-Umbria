package com.abacogroup.lpisgisserver.core.exceptions.support;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class CampaignNotFoundException extends AbstractException {

	private static final long serialVersionUID = -1948671272461251909L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.CAMPAIGN_NOT_FOUND;

	public CampaignNotFoundException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new CampaignNotFoundExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Internal config not found")
	public static class CampaignNotFoundExceptionBody extends AbstractExceptionBody {

		private static final long serialVersionUID = 3264462369218528398L;

		public CampaignNotFoundExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
