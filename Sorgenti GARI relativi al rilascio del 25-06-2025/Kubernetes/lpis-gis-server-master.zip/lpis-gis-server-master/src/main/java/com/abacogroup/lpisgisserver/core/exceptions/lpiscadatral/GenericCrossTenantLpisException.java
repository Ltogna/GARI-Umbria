package com.abacogroup.lpisgisserver.core.exceptions.lpiscadatral;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class GenericCrossTenantLpisException extends AbstractException {

	private static final long serialVersionUID = -7252203008674918953L;

	private static final ErrorCode ERROR_CODE = ErrorCode.GENERIC_CROSS_TENANT_LPIS_ERROR;

	public GenericCrossTenantLpisException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, 
			String lang, String message) {
		super(code, new GenericCrossTenantLpisExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
		
		if (StringUtils.isNotBlank(message)) {
			this.getBody().setMessage(message);
		}
	}

	@Schema(description = "Generic cross tenant lpis error!")
	public static class GenericCrossTenantLpisExceptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = 372367780010931447L;

		public GenericCrossTenantLpisExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
