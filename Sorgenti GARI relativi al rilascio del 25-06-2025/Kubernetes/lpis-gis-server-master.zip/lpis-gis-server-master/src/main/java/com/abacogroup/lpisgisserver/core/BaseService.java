package com.abacogroup.lpisgisserver.core;

import java.security.SecureRandom;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.proj4j.CRSFactory;
import org.locationtech.proj4j.CoordinateReferenceSystem;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.LandCoverConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.area.AreaNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.ForbiddenEditLandCoverException;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.GenericLandCoverException;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.InvalidLandCoverCodeException;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.LandCoverNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.ParcelNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidEditSessionException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidUserEditSessionException;
import com.abacogroup.lpisgisserver.core.exceptions.units.MaxTentativesReachedException;
import com.abacogroup.lpisgisserver.core.exceptions.units.UnitCodeNotValidException;
import com.abacogroup.lpisgisserver.core.support.EditorSupportParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.core.transform.ReprojectCoordinateSequenceFilter;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.LandCoverConfigsDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoversDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverConfigNTT;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.plugins.InternalUnitCodePlugin;
import com.abacogroup.lpisgisserver.plugins.PluginConstants;
import com.abacogroup.lpisgisserver.plugins.models.CreateUnitCodePluginModel;
import com.abacogroup.lpisgisserver.sdk.SdkParcel;
import com.abacogroup.lpisgisserver.sdk.SdkUnitCode;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.google.common.collect.Iterators;
import com.google.common.collect.UnmodifiableIterator;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class BaseService {
	
	protected LandCoverConfigsDAO landCoverConfigsDAO;
	protected LandCoversDAO landCoversDAO; 

	protected InternalConfigService internalConf;
	protected ExternalConfigService externalConf;
	protected ErrorDescriptionsService errorDescriptionsService;
	protected StyleService styleService;

	protected final PluginEnvironment pluginEnvironment;

	protected static Map<String, CoordinateReferenceSystem> crsMap = new HashMap<>();

	protected static final String DEFAULT_LANG_CODE = "en";

	protected static final AbsoluteDate END_OF_WORLD = AbsoluteDate.of("99991231");

	protected static final Double GEOM_COMPARE_PRECISION = 0.01;

	protected static final String SRS_WORLD_GEOM = "EPSG:3857";

	protected static final SecureRandom random = new SecureRandom(); 
	
	protected static final String ACCEPT_LANGUAGE = "accept-language";
	protected static final String AUTHORIZATION = "Authorization";
	protected static final String JWT_PREFIX = "JWT %s";
	
	protected Cache<String, List<String>> landCoverConfigCache; //key tenantId|landCoverConfigKey
	
	protected BaseService(DAOContainer dc, InternalConfigService internalConf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService,
			PluginEnvironment pluginEnvironment) {
		
		this.landCoverConfigsDAO = dc.getLandCoverConfigsDAO();
		this.landCoversDAO = dc.getLandCoversDAO();

		this.internalConf = internalConf;
		this.externalConf = externalConf;
		this.errorDescriptionsService = errorDescriptionsService;
		this.styleService = styleService;

		this.pluginEnvironment = pluginEnvironment;
		
		this.landCoverConfigCache = Caffeine.newBuilder()
				.maximumSize(1000)
				.expireAfterWrite(Duration.ofMinutes(60))
				.build();

	}

	/**
	 * Escapes a string for use in an SQL LIKE statement. This is used to escape
	 * special characters that are part of a LIKE expression such as % and _.
	 * 
	 * @param toEscape - the string to escape. May be null.
	 * 
	 * @return the escaped string or null if there was no escaping to do. The result
	 *         is guaranteed to be non - null
	 */
	public String escapeSqlLike(String toEscape) {
		return StringUtils.replaceEach(toEscape, new String[] { "%", "_", "$" }, new String[] { "$%", "$_", "$$" });
	}

	/**
	 * Throws an exception based on information provided by the editor. This method
	 * is used to log error messages in case of an error while editing a resource
	 * 
	 * @param e      - the exception to be thrown
	 * @param params - the parameters that contain the operation and error message
	 */
	public void throwExceptionFromEditorOperation(AbstractException e, EditorSupportParams params) {
		AbstractExceptionBody body = e.getBody();

		body.setOperation(params.getOperation());
		body.setMessage(body.getErrorCode(), params.getReqContext().getLang(),
				errorDescriptionsService.getTenantErrorDescriptions(params.getReqContext().getTenantId()));

		log.error(body.getLogErrorMessage());

		e.setBody(body);

		throw e;
	}

	/**
	 * Returns the CRS associated with the given name. If there is no CRS associated
	 * with the given name a new one is created
	 * 
	 * @param srs - Name of the coordinate reference system
	 * 
	 * @return The CRS associated with the given name or null if none could be found
	 *         or if an error occurred
	 */
	public static CoordinateReferenceSystem getCRS(String srs) {

		CoordinateReferenceSystem crs = crsMap.getOrDefault(srs, null);

		// Adds a CRS to the map.
		if (crs == null) {
			crs = new CRSFactory().createFromName(srs);
			crsMap.put(srs, crs);
		}

		return crs;
	}

	/**
	 * Reprojects the coordinates of a Geometry to another
	 * CoordinateReferenceSystem. This is equivalent to applying
	 * #reprojectCoordinateSequenceFilter ( CoordinateReferenceSystem
	 * CoordinateReferenceSystem ) to the source and then removing SRID 0.
	 * 
	 * @param geom    - the Geometry to reproject. Must not be null.
	 * @param fromCRS - the CoordinateReferenceSystem to reproject from. Must not be
	 *                null.
	 * @param toCRS   - the CoordinateReferenceSystem to reproject to. Must not be
	 *                null.
	 * 
	 * @return a copy of the input Geometry with the coordinates reprojected to the
	 *         specified CRS. Never null
	 */
	public Geometry reproject(Geometry geom, CoordinateReferenceSystem fromCRS, CoordinateReferenceSystem toCRS) {
		// Returns the geometric geometry of the from CRS.
		if (fromCRS.getName().equals(toCRS.getName())) {
			return geom;
		}

		Geometry destGeom = geom.copy();
		destGeom.apply(new ReprojectCoordinateSequenceFilter(fromCRS, toCRS));
		destGeom.setSRID(0);

		return destGeom;
	}

	/**
	 * Load Parcel plugin by tenant id and plugin key. This method is used to load
	 * plugin from internal configuration
	 * 
	 * @param tenantId  - tenant id for which plugin is loaded
	 * @param pluginKey - key of plugin to load. It is case sensitive
	 * 
	 * @return instance of Parcel plugin or null if not loaded or error occurred
	 *         during loading of plugin or plugin is
	 */
	public SdkParcel loadParcelPlugin(String tenantId, String pluginKey) {
		SdkParcel sdkParcel = null;

		try {
			String pluginClassName = this.internalConf.getStringValue(tenantId, pluginKey);
			// Create a new instance of the plugin class.
			if (StringUtils.isNotBlank(pluginClassName)) {
				sdkParcel = (SdkParcel) Class.forName(pluginClassName).getDeclaredConstructors()[0].newInstance();
			}
		} catch (Exception e) {
			log.warn("Error loading plugin, continue with default: ", e);
		}

		// Load the parcel plugin configuration from the configuration file.
		if (sdkParcel != null) { // try to use plugin
			try {
				pluginEnvironment.setInternalConfigurations(this.internalConf.getConfigurationToMap(tenantId));
				pluginEnvironment.setExternalConfigurations(this.externalConf.getConfigurationToMap(tenantId));

				log.info("Parcel plugin {} loaded", sdkParcel.getClass().getCanonicalName());

			} catch (Exception e) {
				log.error("Error loading parcel plugin configuration {} : {}", sdkParcel.getClass().getName(), e);
			}
		}

		return sdkParcel;
	}

	/**
	 * Apply parcel search plugin to filter. This is used to decode the filter to a
	 * format that can be used by the ParcelSearch plugin
	 * 
	 * @param env          - service support environment for tenant
	 * @param parcelFilter - filter to be applied to the parcel
	 * 
	 * @return filter that can be
	 */
	public String applyParcelSearchPlugin(ServiceSupportEnv env, String parcelFilter) {

		SdkParcel sdkParcel = loadParcelPlugin(env.getTenantId(), PluginConstants.DECODE_PARCEL_SEARCH_KEY);
		// Returns the parcel filter to use for the parcel search.
		if (sdkParcel != null) { // try to use plugin
			try {
				// XXX isn't it better to extend the filter to all fields, sectors and blocks as
				// well?
				parcelFilter = sdkParcel.decodeParcelSearch(parcelFilter, pluginEnvironment);

			} catch (Exception e) {
				log.error("Error during decode parcel search with plugin {} : {}", sdkParcel.getClass().getName(), e);
			}
		} else { // Standard behavior
			parcelFilter = parcelFilter != null ? parcelFilter + "%" : null;
		}

		return parcelFilter;
	}

	/**
	 * Apply parcel name decoding plugin to the given parcel name. This is used to
	 * decode the name when it is stored in the service
	 * 
	 * @param env        - ServiceSupportEnv that contains tenant id
	 * @param parcelName - parcel name to be decoded
	 * 
	 * @return the decoded name or null if the parcel name could not be decoded due
	 *         to error in plugin's
	 */
	public String applyDecodeParcelNamePlugin(ServiceSupportEnv env, String parcelName) {

		SdkParcel sdkParcel = loadParcelPlugin(env.getTenantId(), PluginConstants.DECODE_PARCEL_NAME_KEY);
		// Decode parcel name from SDK Parcel.
		if (sdkParcel != null) {
			try {
				parcelName = sdkParcel.decodeParcelName(parcelName, pluginEnvironment);
			} catch (Exception e) {
				log.error("Error during decode parcel name with plugin {} : {}", sdkParcel.getClass().getName(), e);
			}
		}

		return parcelName;
	}

	public SdkUnitCode loadUnitCodePlugin(String tenantId, String pluginKey) {
		SdkUnitCode sdkUnitCode = new InternalUnitCodePlugin();
		
		try {
			String pluginClassName = this.internalConf.getStringValue(tenantId, pluginKey);
			// Create a new instance of the plugin class.
			if (StringUtils.isNotBlank(pluginClassName)) {
				sdkUnitCode = (SdkUnitCode) Class.forName(pluginClassName).getDeclaredConstructors()[0].newInstance();
			}
		} catch (Exception e) {
			log.warn("Error loading plugin, continue with default: ", e);
		}
	
		// Load the parcel plugin configuration from the configuration file.
		if (sdkUnitCode != null) { // try to use plugin
			try {
				pluginEnvironment.setInternalConfigurations(this.internalConf.getConfigurationToMap(tenantId));
				pluginEnvironment.setExternalConfigurations(this.externalConf.getConfigurationToMap(tenantId));
	
				log.info("Unit Code plugin {} loaded", sdkUnitCode.getClass().getCanonicalName());
	
			} catch (Exception e) {
				log.error("Error loading parcel plugin configuration {} : {}", sdkUnitCode.getClass().getName(), e);
			}
		}
	
		return sdkUnitCode;
	}

	/**
	 * Build a ServiceSupportEnv from the given EditorSupportParams. This is used to
	 * create service environments that are specific to the OpenMRS and other tools
	 * such as GemFire.
	 * 
	 * @param params - the params for the editor. Must not be null.
	 * 
	 * @return a newly created instance of ServiceSupportEnv or null if there is no
	 *         service to create for the given params
	 */
	public ServiceSupportEnv checkAndBuildServiceSupportEnv(EditorSupportParams params) {

		// Check reqcontext and user validity
		if (params.getReqContext() == null || params.getReqContext().getUser() == null
				|| params.getReqContext().getUser().getName() == null) {
			InvalidUserEditSessionException ex = new InvalidUserEditSessionException(Status.BAD_REQUEST,
					params.getOperation(), ErrorField.REQUEST_CONTEXT,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY),
					ErrorDescriptionsService.DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		// Check session validity
		if (params.getSession() == null || params.getSession().getUuid() == null) {
			String tenantId = params.getReqContext() != null ? params.getReqContext().getTenantId() : StringUtils.EMPTY;
			String lang = params.getReqContext() != null ? params.getReqContext().getLang()
					: ErrorDescriptionsService.DEFAULT_LANG_CODE;

			InvalidEditSessionException ex = new InvalidEditSessionException(Status.BAD_REQUEST, params.getOperation(),
					ErrorField.SESSION, this.errorDescriptionsService.getTenantErrorDescriptions(tenantId), lang);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return ServiceSupportEnv.builder()
				.user(params.getReqContext().getUser()).lang(params.getReqContext().getLang())
				.tenantId(params.getReqContext().getTenantId()).sessionId(params.getSession().getUuid())
				.srs(params.getSession().getLock_geom_srs()).referenceDate(params.getSession().getReference_date())
				.parcelId(params.getParcelId())
				.operation(params.getOperation()).build();
	}
	
	public Integer boolToInt(Boolean value) {
		return Boolean.TRUE.equals(value) ? 1 : 0;
	}

	// Generate a random 12-digit ID for landcovers ;-P
	public static long generateRandom12DigitId() {
		return 100000000000L + (long) (random.nextDouble() * 900000000000L);
	}
	
	public String getNewUnitCode(ServiceSupportEnv env, UnitType ut) {
		CreateUnitCodePluginModel unitCodePluginModel = null;
		SdkUnitCode sdkUnitCode = loadUnitCodePlugin(env.getTenantId(), PluginConstants.CREATE_UNIT_CODE_KEY);
		if (sdkUnitCode != null) {
			try {
				log.info("Use plugin {} to create unit code", sdkUnitCode.getClass().getCanonicalName());
				 unitCodePluginModel = sdkUnitCode.createNewUnitCode(env, ut, pluginEnvironment);
			} catch (Exception e) {
				log.error("Error during retrieve unit code with plugin {} : {}", sdkUnitCode.getClass().getName(), e);
			}
		}
		
		if (unitCodePluginModel != null && unitCodePluginModel.getErrorCode() == null && unitCodePluginModel.getUnitCode() != null) {
			return unitCodePluginModel.getUnitCode();
		}
		
		if(ErrorCode.MAX_TENTATIVES_REACHED.equals(unitCodePluginModel.getErrorCode())) {
            MaxTentativesReachedException ex = new MaxTentativesReachedException(Status.BAD_REQUEST,
                    env.getOperation(), ErrorField.UNIT_CODE,
                    this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

            log.error(ex.getBody().getLogErrorMessage());

            throw ex;
		} else if(ErrorCode.AREA_NOT_FOUND.equals(unitCodePluginModel.getErrorCode())) {
            AreaNotFoundException ex = new AreaNotFoundException(Status.BAD_REQUEST,
                    env.getOperation(), ErrorField.UNIT_CODE,
                    this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

            log.error(ex.getBody().getLogErrorMessage());

            throw ex;
		} else if(ErrorCode.PARCEL_NOT_FOUND.equals(unitCodePluginModel.getErrorCode())) {
			ParcelNotFoundException ex = new ParcelNotFoundException(Status.BAD_REQUEST,
					env.getOperation(), unitCodePluginModel.getErrorField(),
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		UnitCodeNotValidException ex = new UnitCodeNotValidException(Status.BAD_REQUEST,
				env.getOperation(), ErrorField.UNIT_CODE,
				this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

		log.error(ex.getBody().getLogErrorMessage());

		throw ex;
	}
	
	public String getUnitDetailTableName(UnitType typeCode) {
		switch (typeCode) {
        case VINE_UNIT:
            return "lpis_unit_vineunit_details";
        case FRUIT_UNIT:
            return "lpis_unit_fruitunit_details";
        case OLIVE_UNIT:
            return "lpis_unit_oliveunit_details";
        default:
            throw new UnsupportedOperationException("Table name not implemented for the given type code: " + typeCode);
        }
	}
	
	public String getEditUnitTableName(UnitType typeCode) {
		switch (typeCode) {
		case VINE_UNIT:
			return "lpis_edit_unit_vineunit";
		case FRUIT_UNIT:
			return "lpis_edit_unit_fruitunit";
		case OLIVE_UNIT:
			return "lpis_edit_unit_oliveunit";
		default:
			throw new UnsupportedOperationException("Table name not implemented for the given type code: " + typeCode);
		}
	}
	
	public void checkForbiddenEditLcCode(ServiceSupportEnv env, LandCoverNTT landCover) {
		if (landCover == null) {
			GenericLandCoverException ex = new GenericLandCoverException(Status.NOT_FOUND, env.getOperation(),
					ErrorField.LANDCOVER_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		List<String> forbiddenCodes = getLandCoverConfigByKey(env.getTenantId(), LandCoverConfigKeys.EDIT_FORBIDDEN);
		if (forbiddenCodes != null && forbiddenCodes.contains(landCover.getLand_cover_code())) {
			ForbiddenEditLandCoverException ex = new ForbiddenEditLandCoverException(Status.BAD_REQUEST, env.getOperation(),
					ErrorField.LANDCOVER_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					landCover.getLand_cover_code() + " - " + landCover.getLand_cover_description());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}
	
	public void checkForbiddenEditLcCodeByParcelIds(ServiceSupportEnv env, List<Long> parcelIds) {
		if (parcelIds == null || parcelIds.isEmpty()) {
			return;
		}
		
		UnmodifiableIterator<List<Long>> partitions = Iterators.partition(parcelIds.iterator(), 666);
		partitions.forEachRemaining(partition -> {
			List<LandCoverNTT> parcelLandCovers = landCoversDAO.findByParcelIds(env, partition);
			parcelLandCovers.forEach(lc -> checkForbiddenEditLcCode(env, lc));
		});
	}
	
	public void checkForbiddenEditLcCodeByLandCoverId(ServiceSupportEnv env, Long landCoverId) {
		
		LandCoverNTT landCoverNTT = landCoversDAO.getLandCoverDetail(env, landCoverId);
		if (landCoverNTT == null) {
			LandCoverNotFoundException ex = new LandCoverNotFoundException(Status.NOT_FOUND, env.getOperation(), ErrorField.LANDCOVER_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
	
			log.error(ex.getBody().getLogErrorMessage());
	
			throw ex;
		}
		
		checkForbiddenEditLcCode(env, landCoverNTT);
	}
	
	public void checkForbiddenEditLcCode(ServiceSupportEnv env, String landCoverCode) {
		
		if (StringUtils.isBlank(landCoverCode)) {
			InvalidLandCoverCodeException ex = new InvalidLandCoverCodeException(Status.NOT_FOUND, env.getOperation(), ErrorField.LANDCOVER_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
			
			log.error(ex.getBody().getLogErrorMessage());
			
			throw ex;
		}
		
		List<String> forbiddenCodes = getLandCoverConfigByKey(env.getTenantId(), LandCoverConfigKeys.EDIT_FORBIDDEN);
		if (forbiddenCodes != null && forbiddenCodes.contains(landCoverCode)) {
			ForbiddenEditLandCoverException ex = new ForbiddenEditLandCoverException(Status.BAD_REQUEST, env.getOperation(),
					ErrorField.LANDCOVER_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					landCoverCode);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}
	
	private List<String> getLandCoverConfigByKey(String tenantId, LandCoverConfigKeys key) {
		String cacheKey = tenantId + "|" + key;	
		List<String> lcCodes = landCoverConfigCache.getIfPresent(cacheKey);
		if (lcCodes == null) {
			lcCodes = loadLandCoverConfig(tenantId, key);
			landCoverConfigCache.put(cacheKey, lcCodes);
		}
		
		return lcCodes;
	}
	
	private List<String> loadLandCoverConfig(String tenantId, LandCoverConfigKeys key) {
		return landCoverConfigsDAO.findConfigs(tenantId, null, key).stream()
				.filter(c -> Boolean.TRUE.equals(Boolean.parseBoolean(c.getValue())))
				.map(LandCoverConfigNTT::getLandCoverCode)
				.collect(Collectors.toList());
	}
}
