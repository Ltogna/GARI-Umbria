package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.EditCategoryNTT;
import com.abacogroup.lpisgisserver.resources.res.EditCategory;

@Mapper
public interface EditCategoryMapper {

	EditCategoryMapper INSTANCE = Mappers.getMapper(EditCategoryMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	EditCategory entityToDto(EditCategoryNTT entity);
	
	@Mapping(target = "flVisible", expression = "java(dto.getVisible() ? 1 : 0)")
	EditCategoryNTT dtoToEntity(EditCategory dto);
}
