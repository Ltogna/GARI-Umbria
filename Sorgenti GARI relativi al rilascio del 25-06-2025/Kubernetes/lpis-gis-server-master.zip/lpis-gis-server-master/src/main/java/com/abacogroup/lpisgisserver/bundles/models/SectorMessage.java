package com.abacogroup.lpisgisserver.bundles.models;

import org.locationtech.jts.geom.Geometry;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SectorMessage {
	private String code;
	private String description;
	private Geometry geom;
	private String short_descr;
	private String srs;
}
