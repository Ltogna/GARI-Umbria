package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.EditSessionNTT;
import com.abacogroup.lpisgisserver.resources.res.EditSession;

@Mapper
public interface EditSessionMapper {

	EditSessionMapper INSTANCE = Mappers.getMapper(EditSessionMapper.class);

	@Mapping(source = "uuid", target = "id")
	@Mapping(target = "status", ignore = true)
	@Mapping(target = "sector_id", ignore = true)
	EditSession entityToDto(EditSessionNTT entity);

	@Mapping(source = "id", target = "uuid")
	@Mapping(target = "dt_last_lock", ignore = true)
	@Mapping(target = "tenant_id", ignore = true)
	@Mapping(target = "user_id", ignore = true)
	@Mapping(target = "sessionCheckResult", ignore = true)
	EditSessionNTT dtoToEntity(EditSession dto);

}
