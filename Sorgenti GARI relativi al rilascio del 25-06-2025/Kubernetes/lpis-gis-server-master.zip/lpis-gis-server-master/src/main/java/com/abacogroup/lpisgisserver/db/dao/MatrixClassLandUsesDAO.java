package com.abacogroup.lpisgisserver.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.support.MatrixSearchParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassLandusesNTT;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import java.util.List;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface MatrixClassLandUsesDAO extends Transactional<MatrixClassLandUsesDAO>, EnhancedSqlObject {

	@SqlUpdate("INSERT INTO lpis_matrix_class_landuses (matrix_id, class_code, land_use_code, day_from, "
			+ "day_to, user_id_insert, user_id_delete, dt_insert, "
			+ "dt_delete) "
			+ "VALUES(:matrix_id, :class_code, :landuse.code, :day_from, "
			+ " :day_to, :user_id_insert, NULL, §current_timestamp§, "
			+ " TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insert(@BindBean MatrixClassLandusesNTT rs, @Bind("user_id_insert") String userId);

	@SqlUpdate("INSERT INTO lpis_matrix_class_landuses (matrix_id, class_code, land_use_code, day_from, "
			+ "day_to, user_id_insert, user_id_delete, dt_insert, dt_delete) "
			+ "VALUES(:matrixId, :classCode, :landUseCode, :dayFrom, :dayTo, :userIdInsert, NULL, §current_timestamp§, "
			+ " TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insertWithParams(@Bind("matrixId") Long matrixId, @Bind("classCode") String classCode, @Bind("landUseCode") String landUseCode,
			@Bind("dayFrom") AbsoluteDate dayFrom, @Bind("dayTo") AbsoluteDate dayTo, @Bind("userIdInsert") String userIdInsert);

	@SqlQuery("select matrix_id, \n"
			+ "   class_code, \n"
			+ "   land_use_code as landuse_code, \n"
			+ "   §i18n(:tenantId, 'lpis_landuses', 'code', land_use_code, :lang)§ as landuse_description, \n"
			+ "   day_from, \n"
			+ "   day_to, \n"
			+ "   user_id_insert, \n"
			+ "   user_id_delete, \n"
			+ "   dt_insert, \n"
			+ "   dt_delete \n"
			+ "from lpis_matrix_class_landuses \n"
			+ "where matrix_id = :matrix_id \n"
			+ "  and class_code = :class_code \n"
			+ "  and land_use_code = :landUseCode \n"
			+ "  and §current_timestamp§ between dt_insert and dt_delete \n")
	@RegisterBeanMapper(MatrixClassLandusesNTT.class)
	MatrixClassLandusesNTT findByMatrixIdClassCodeAndLandUseCode(
			@BindBean ServiceSupportEnv env,
			@Bind("matrix_id") Long matrixId,
			@Bind("class_code") String classCode,
			@Bind("landUseCode") String landUseCode);

	@SqlQuery("select matrix_id, \n"
			+ "   class_code, \n"
			+ "   land_use_code as landuse_code, \n"
			+ "   §i18n(:tenantId, 'lpis_landuses', 'code', land_use_code, :lang)§ as landuse_description, \n"
			+ "   day_from, \n"
			+ "   day_to, \n"
			+ "   user_id_insert, \n"
			+ "   user_id_delete, \n"
			+ "   dt_insert, \n"
			+ "   dt_delete \n"
			+ "from lpis_matrix_class_landuses \n"
			+ "where matrix_id = :matrix_id \n"
			+ "  and land_use_code = :landUseCode \n"
			+ "  and §current_timestamp§ between dt_insert and dt_delete \n")
	@RegisterBeanMapper(MatrixClassLandusesNTT.class)
	MatrixClassLandusesNTT findByMatrixIdAndLandUseCode(
			@BindBean ServiceSupportEnv env,
			@Bind("matrix_id") Long matrixId,
			@Bind("landUseCode") String landUseCode);

	@SqlQuery("select matrix_id, \n"
			+ "   class_code, \n"
			+ "   land_use_code as landuse_code, \n"
			+ "   §i18n(:tenantId, 'lpis_landuses', 'code', land_use_code, :lang)§ as landuse_description, \n"
			+ "   day_from, \n"
			+ "   day_to, \n"
			+ "   user_id_insert, \n"
			+ "   user_id_delete, \n"
			+ "   dt_insert, \n"
			+ "   dt_delete \n"
			+ "FROM lpis_matrix_class_landuses \n"
			+ "WHERE matrix_id = :matrix_id \n"
			+ "   and class_code = :class_code \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n")
	@RegisterBeanMapper(MatrixClassLandusesNTT.class)
	List<MatrixClassLandusesNTT> findByMatrixIdAndClassCode(
			@BindBean ServiceSupportEnv env,
			@Bind("matrix_id") Long matrixId,
			@Bind("class_code") String classCode);

	@SqlUpdate("update lpis_matrix_class_landuses set user_id_delete = :user_id_delete, dt_delete = §current_timestamp§ "
			+ "where matrix_id = :matrix_id \n"
			+ "  and class_code = :class_code \n"
			+ "  and land_use_code = :landUseCode \n"
			+ "  and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteByMatrixIdClassCodeAndLandUseCode(
			@Bind("matrix_id") Long matrixId,
			@Bind("class_code") String classCode,
			@Bind("landUseCode") String landUseCode,
			@Bind("user_id_delete") String userDelete);

	@SqlUpdate("update lpis_matrix_class_landuses set user_id_delete = :user_id_delete, dt_delete = §current_timestamp§ "
			+ "where matrix_id = :matrix_id \n"
			+ "  and land_use_code = :landUseCode \n"
			+ "  and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteByMatrixIdAndLandUseCode(
			@Bind("matrix_id") Long matrixId,
			@Bind("landUseCode") String landUseCode,
			@Bind("user_id_delete") String userDelete);

	@SqlUpdate("UPDATE lpis_matrix_class_landuses SET user_id_delete = :user_id_delete, dt_delete = §current_timestamp§ " +
			"WHERE matrix_id = :matrix_id AND class_code = :class_code " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteByMatrixIdAndClassCode(
			@Bind("matrix_id") Long matrixId,
			@Bind("class_code") String classCode,
			@Bind("user_id_delete") String userDelete);

	@SqlQuery("select matrix_id, \n"
			+ "       class_code, \n"
			+ "       land_use_code as landuse_code, \n"
			+ "       null as landuse_description, \n"
			+ "       day_from, \n"
			+ "       day_to, \n"
			+ "       user_id_insert, \n"
			+ "       user_id_delete, \n"
			+ "       dt_insert, \n"
			+ "       dt_delete \n"
			+ "  from lpis_matrix_class_landuses \n"
			+ " where matrix_id = :matrixId \n"
			+ "   and class_code = :classCode \n"
			+ "   and land_use_code = :landUseCode \n"
			+ "   and day_from <= :dayTo \n"
			+ "   and :dayFrom <= day_to \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n")
	@RegisterBeanMapper(MatrixClassLandusesNTT.class)
	List<MatrixClassLandusesNTT> getMatrixClassLandusesByTimeInterval(
			@Bind("matrixId") Long matrixId,
			@Bind("classCode") String classCode,
			@Bind("landUseCode") String landUseCode,
			@Bind("dayFrom") AbsoluteDate dayFrom,
			@Bind("dayTo") AbsoluteDate dayTo
	);
	/* ******************************************* */

	@SqlQuery("\n"
			+ "select matrix_id, \n"
			+ "   class_code, \n"
			+ "   land_use_code as landuse_code, \n"
			+ "   §i18n(:tenantId, 'lpis_landuses', 'code', land_use_code, :lang)§ as landuse_description, \n"
			+ "   day_from, \n"
			+ "   day_to, \n"
			+ "   user_id_insert, \n"
			+ "   user_id_delete, \n"
			+ "   dt_insert, \n"
			+ "   dt_delete \n"
			+ "from lpis_matrix_class_landuses \n"
			+ "where matrix_id = :matrixId \n"
			+ "   and class_code = :classCode \n"
			+ "   and :referenceDate between day_from and day_to \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n"
			+ "   and (land_use_code =  :landuseFilter or :landuseFilter is null) \n")
	@RegisterBeanMapper(MatrixClassLandusesNTT.class)
	List<MatrixClassLandusesNTT> searchValidByMatrixIdAndClassCode(
			@BindBean ServiceSupportEnv env,
			@BindBean MatrixSearchParams search);
}
