package com.abacogroup.lpisgisserver.core;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.support.EditorSupportParams;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.I18nDAO;
import com.abacogroup.lpisgisserver.db.ntt.I18nNTT;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ErrorDescriptionsService {

	private I18nDAO i18nDAO;

	public static final String DEFAULT_LANG_CODE = "en";

	private static final String ERROR_DESCRIPTIONS_TABLE_NAME = "lpis_errors";
	private static final String ERROR_DESCRIPTIONS_FIELD_NAME = "error_code";

	private LoadingCache<String, Map<String, Map<String, String>>> errorDescriptionsCache;

	public ErrorDescriptionsService(DAOContainer dc) {
		this.i18nDAO = dc.getI18nDAO();

		errorDescriptionsCache = Caffeine.newBuilder()
				.maximumSize(1000)
				.expireAfterWrite(Duration.ofMinutes(60))
				.build(this::loadErrorDescriptions);
	}

	/**
	* Get the error descriptions for a tenant. This method is thread safe. Use with caution. If you need to access the cache in a background thread you should cache the result for performance benefits.
	* 
	* @param tenantId - The id of the tenant. This can be null for all tenants.
	* 
	* @return Map<String String > with the error descriptions for the tenant or null if there is no error description
	*/
	public Map<String, Map<String, String>> getTenantErrorDescriptions(String tenantId) {
		return errorDescriptionsCache.get(tenantId);
	}

	/**
	* Loads error descriptions for the given tenant. This method is used to load the error descriptions for the given tenant.
	* 
	* @param tenantId - The tenant for which to load the error descriptions.
	* 
	* @return A map where the key is the language and the value is the error description text for that language. If there are no errors for the given tenant an empty map is returned
	*/
	private Map<String, Map<String, String>> loadErrorDescriptions(String tenantId) {

		List<I18nNTT> errors = i18nDAO.findAllI18nByTenantTableAndField(tenantId, ERROR_DESCRIPTIONS_TABLE_NAME, ERROR_DESCRIPTIONS_FIELD_NAME);

		Map<String, Map<String, String>> result = new HashMap<>();

		errors.stream().forEach(errorDescription -> {
			// Returns the result of the error description.
			if (result.containsKey(errorDescription.getI18n_value())) {
				result.get(errorDescription.getI18n_value()).put(errorDescription.getLang(), errorDescription.getI18n_text());
			} else {
				result.put(errorDescription.getI18n_value(), new HashMap<>(Map.of(errorDescription.getLang(), errorDescription.getI18n_text())));
			}
		});

		return result;
	}

	/**
	* Throws an exception based on information provided by the editor. This method is used to log error messages in case of an error while editing a resource
	* 
	* @param e - the exception to be thrown
	* @param params - the parameters that contain the operation and error message
	*/
	public void throwExceptionFromEditorOperation(AbstractException e, EditorSupportParams params) {
		AbstractExceptionBody body = e.getBody();

		body.setOperation(params.getOperation());
		body.setMessage(body.getErrorCode(), params.getReqContext().getLang(), getTenantErrorDescriptions(params.getReqContext().getTenantId()));

		log.error(body.getLogErrorMessage());

		e.setBody(body);

		throw e;
	}
}
