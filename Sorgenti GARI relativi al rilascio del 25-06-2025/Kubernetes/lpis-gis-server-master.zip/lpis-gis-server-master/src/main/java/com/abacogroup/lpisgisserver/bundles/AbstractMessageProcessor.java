package com.abacogroup.lpisgisserver.bundles;

import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.models.I18nMessage;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.I18nDAO;
import com.abacogroup.lpisgisserver.db.ntt.I18nNTT;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class AbstractMessageProcessor implements ConfigMessageProcessor {

	protected I18nDAO i18nDAO;
	
	protected static final String FOR_TENANT = " for tenant ";
	protected static final String ERROR_PROCESSING_FILE_MESSAGE = "Error processing file %s for tenant %s";
	protected static final String ERROR_READ_FILE_MESSAGE = "Error during read file {} : {}";

	protected AbstractMessageProcessor(DAOContainer dc) {
		this.i18nDAO = dc.getI18nDAO();
	}

	protected void insertOrUpdateI18nMessages(String tenantId, I18nMessage message) {
		try {
			if (message.getTranslations() == null || message.getTranslations().isEmpty()) {
				throw new IllegalStateException("Translations are not define!");
			}

			message.getTranslations().forEach((lang, text) -> {
				try {
					I18nNTT messageNTT = I18nNTT.builder()
							.tenant_id(tenantId)
							.table_name(message.getTable())
							.field_name(message.getField())
							.i18n_value(message.getValue())
							.lang(lang)	
							.i18n_text(text)
							.build();

					I18nNTT toFind = i18nDAO.findI18nByLpisI18nKeys(messageNTT);

					if (toFind == null) {
						i18nDAO.insert(messageNTT);
					} else if (!toFind.getI18n_text().equals(text)) {
						i18nDAO.updateI18nText(messageNTT);
					}
				} catch (Exception e) {
					log.error("Error during insert or update i18n message " + message.toString() + " for tenant " + tenantId, e);
				}
			});
		} catch (Exception e) {
			log.error("Error processing row " + message.toString() + " for tenant " + tenantId, e);
		}
	}
	
	protected Integer boolToInt(Boolean value) {
		return Boolean.TRUE.equals(value) ? 1 : 0;
	}

}
