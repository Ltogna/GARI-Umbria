package com.abacogroup.lpisgisserver.core;

import java.util.ArrayList;
import java.util.List;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.ErrorItem;
import com.abacogroup.lpisgisserver.core.exceptions.InvalidFormException;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.LandCoverNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.units.olive.OliveUnitIdNotValidException;
import com.abacogroup.lpisgisserver.core.exceptions.units.olive.OliveUnitNotEditableException;
import com.abacogroup.lpisgisserver.core.exceptions.units.olive.OliveUnitNotFoundException;
import com.abacogroup.lpisgisserver.core.support.EditorSupportParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditLandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.EditOliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.OliveUnitDetailsNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.pub.CreateOrUpdateOliveUnitPayloadV1;
import com.abacogroup.lpisgisserver.resources.res.units.olive.OliveUnit;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EditOliveUnitsService extends BaseService {
	
	private final EditLandCoversDAO editLandCoversDAO;
	private final EditOliveUnitsDAO editOliveUnitsDAO;

	private final EditLandCoversSupportService editLandCoversSupportService;
	private final EditOliveUnitsSupportService editOliveUnitsSupportService;
	private final EditUnitsSupportService editUnitsSupportService;

	private static final UnitType UNIT_TYPE = UnitType.OLIVE_UNIT;
	private static final boolean SKIP_FORBIDDEN_LC_CHECK = true;

	public EditOliveUnitsService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService,
			EditLandCoversSupportService editLandCoversSupportService, EditOliveUnitsSupportService editOliveUnitsSupportService, 
			EditUnitsSupportService editUnitsSupportService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.editLandCoversDAO = dc.getEditLandCoversDAO();
		this.editOliveUnitsDAO = dc.getEditOliveUnitsDAO();

		this.editLandCoversSupportService = editLandCoversSupportService;
		this.editOliveUnitsSupportService = editOliveUnitsSupportService;
		this.editUnitsSupportService = editUnitsSupportService;
	}

	public OliveUnit createOliveUnits(EditorSupportParams params, @NotNull @Valid CreateOrUpdateOliveUnitPayloadV1 payload) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		
		List<ErrorItem> errorList = new ArrayList<>();
		internalCheckCreateOrUpdateOliveUnitPayload(params, env, payload, errorList);
		
		LandCoverNTT landCoverNTT = getLandCoverNTT(env, params.getParcelId(), params.getLandCoverId(), params.getOperation());
		editOliveUnitsSupportService.checkOliveUnitValidationDates(env, payload, landCoverNTT, null, errorList);
		
		if(!errorList.isEmpty()) {
			InvalidFormException ex = new InvalidFormException(Status.BAD_REQUEST, params.getOperation(), ErrorField.FORM,
					errorList, this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Long editId = editOliveUnitsDAO.nextEditOliveUnitDetailPkidVal();
		Long newUnitId = editOliveUnitsDAO.nextNewOliveUnitIdVal();
		String unitCode = payload.getUnitCode() != null ? payload.getUnitCode() : getNewUnitCode(env, UNIT_TYPE);
		OliveUnitDetailsNTT oliveUnitToInsert = editOliveUnitsSupportService.buildOliveUnitDetailsNTTFromPayload(payload, editId,
				landCoverNTT.getEdit_id(), newUnitId, unitCode, EditStatus.IN_EDIT, 1, null);

		editOliveUnitsDAO.insertEditOliveUnitDetail(env, oliveUnitToInsert);

		params.setOliveUnitId(newUnitId);
		return getOliveUnits(params).get(0);
	}

	public OliveUnit updateOliveUnits(EditorSupportParams params, @NotNull @Valid CreateOrUpdateOliveUnitPayloadV1 payload) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		
		List<ErrorItem> errorList = new ArrayList<>();
		internalCheckCreateOrUpdateOliveUnitPayload(params, env, payload, errorList);
		
		LandCoverNTT landCoverNTT = getLandCoverNTT(env, params.getParcelId(), params.getLandCoverId(), params.getOperation());
		OliveUnitDetailsNTT inEditUnit = editOliveUnitsDAO.findInEditOliveUnitsBySessionId(env, params.getLandCoverId(), params.getOliveUnitId(), null).get(0);
		
		//check if editable
		if(inEditUnit.getPlantingDay().toLocalDate().isAfter(env.getReferenceDate().toLocalDate()) 
				|| inEditUnit.getEradicateDay().toLocalDate().isBefore(env.getReferenceDate().toLocalDate())) {			
			OliveUnitNotEditableException ex = new OliveUnitNotEditableException(Status.BAD_REQUEST, params.getOperation(), 
					ErrorField.PAYLOAD, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		editOliveUnitsSupportService.checkOliveUnitValidationDates(env, payload, landCoverNTT, inEditUnit, errorList);

		if(!errorList.isEmpty()) {
			InvalidFormException ex = new InvalidFormException(Status.BAD_REQUEST, params.getOperation(), ErrorField.FORM,
					errorList, this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		OliveUnitDetailsNTT oliveUnitToUpdate =  editOliveUnitsSupportService.buildOliveUnitDetailsNTTFromPayload(payload, inEditUnit.getEditId(), 
				inEditUnit.getEditLandCoverId(), inEditUnit.getUnitId(), inEditUnit.getUnitCode(), EditStatus.IN_EDIT, inEditUnit.getFlDeletable(), 
				inEditUnit.getParentUnitCode());
		
		editOliveUnitsDAO.updateEditOliveUnitDetail(env.getSessionId(), oliveUnitToUpdate);

		return getOliveUnits(params).get(0);
	}

	public List<OliveUnit> getOliveUnits(EditorSupportParams params) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()), SKIP_FORBIDDEN_LC_CHECK);
		editUnitsSupportService.checkLandCoverCodeCompatibility(env, params.getParcelId(), params.getLandCoverId(), UNIT_TYPE, params.getOperation());

		return editOliveUnitsSupportService.internalGetOliveUnits(params, params.getLandCoverId(), params.getOliveUnitId());
	}

	public Response deleteOliveUnitById(EditorSupportParams params) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()));
		editUnitsSupportService.checkLandCoverCodeCompatibility(env, params.getParcelId(), params.getLandCoverId(), UNIT_TYPE, params.getOperation());
		editOliveUnitsSupportService.checkAndInsertEditParcelLandCoversOliveUnit(params);

		Long oliveUnitId = params.getOliveUnitId();
		if(oliveUnitId == null || !editOliveUnitsSupportService.isDeletable(env, params.getLandCoverId(), oliveUnitId)) {
			OliveUnitIdNotValidException ex = new OliveUnitIdNotValidException(Status.BAD_REQUEST, params.getOperation(), 
					ErrorField.UNIT_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		editOliveUnitsDAO.deleteOliveUnitsById(env.getSessionId(), oliveUnitId);

		return Response.ok().build();
	}
	
	public Response eradicateOliveUnits(EditorSupportParams params) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()));
		editOliveUnitsSupportService.checkAndInsertEditParcelLandCoversOliveUnit(params);
		
		AbsoluteDate newEradicateDay = env.getReferenceDate();
		
		OliveUnitDetailsNTT inEditUnit = editOliveUnitsDAO.findInEditOliveUnitsBySessionId(env, params.getLandCoverId(), params.getOliveUnitId(), null).get(0);

		//check if editable
		if(inEditUnit.getPlantingDay().toLocalDate().isAfter(env.getReferenceDate().toLocalDate()) 
				|| inEditUnit.getEradicateDay().toLocalDate().isBefore(env.getReferenceDate().toLocalDate())) {
			OliveUnitNotFoundException ex = new OliveUnitNotFoundException(Status.BAD_REQUEST, params.getOperation(), 
					ErrorField.PAYLOAD, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		inEditUnit.setEradicateDay(newEradicateDay);
		inEditUnit.setEditStatus(EditStatus.IN_EDIT);

		editOliveUnitsDAO.updateEditOliveUnitDetail(env.getSessionId(), inEditUnit);

		return Response.ok().build(); 
	}

	private void internalCheckCreateOrUpdateOliveUnitPayload(EditorSupportParams params, ServiceSupportEnv env,
			CreateOrUpdateOliveUnitPayloadV1 payload, List<ErrorItem> errorList) {
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()));
		editUnitsSupportService.checkLandCoverCodeCompatibility(env, params.getParcelId(), params.getLandCoverId(), UNIT_TYPE, params.getOperation());
		editOliveUnitsSupportService.checkCreateOrUpdateOliveUnitPayload(params, payload, errorList);
		editOliveUnitsSupportService.checkAndInsertEditParcelLandCoversOliveUnit(params);
	}

	private LandCoverNTT getLandCoverNTT(ServiceSupportEnv env, Long parcelId, Long landCoverId, Operation operation) {
		LandCoverNTT landCoverNTT = editLandCoversDAO.findInEditBySessionId(env, parcelId).stream()
				.filter(lc -> lc.getLand_cover_id().equals(landCoverId))
				.findFirst()
				.orElse(null);
	
		if(landCoverNTT == null) {
			LandCoverNotFoundException ex = new LandCoverNotFoundException(Status.NOT_FOUND, operation, ErrorField.LANDCOVER_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
	
			log.error(ex.getBody().getLogErrorMessage());
	
			throw ex;
		}
		return landCoverNTT;
	}

}
