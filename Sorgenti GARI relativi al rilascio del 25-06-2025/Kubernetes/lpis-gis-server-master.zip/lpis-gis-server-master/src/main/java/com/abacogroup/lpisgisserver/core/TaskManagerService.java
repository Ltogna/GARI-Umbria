package com.abacogroup.lpisgisserver.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;

import com.abacogroup.agri.taskmanager.model.dto.io.publics.TaskInstanceTransitionInDTO;
import com.abacogroup.agri.taskmanager.model.dto.io.publics.TaskInstanceTransitionScopeInDTO;
import com.abacogroup.agri.taskmanager.model.dto.io.publics.TaskInstancesPublicDetailsOutDTO;
import com.abacogroup.agri.taskmanager.model.dto.io.publics.TransitionOutPublicApiDTO;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionGeomException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionTaskException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidUserEditSessionException;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.ReqContext;
import com.abacogroup.lpisgisserver.resources.res.tasks.TaskManagerData;
import com.abacogroup.lpisgisserver.resources.res.tasks.TaskManagerTransitionList;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TaskManagerService extends BaseService {

	private static final String DEFAULT_LANG_CODE = "en";

	private final WebTarget taskManagerWT;
	private WKTReader wktReader = new WKTReader();

	public TaskManagerService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, WebTarget taskManagerWT,
			PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);
		this.taskManagerWT = taskManagerWT;
	}

	public TaskManagerData getTaskData(ReqContext reqContext, String taskId) {

		checkReqContext(reqContext, Operation.GET_TASK_DATA);
		
		// GET /task-manager/{tenant}/public/v1/task-instances/{task-id}
		WebTarget webTarget = taskManagerWT
				.path(reqContext.getTenantId() + "/")
				.path("public/v1" + "/")
				.path("task-instances" + "/")
				.path(taskId);

		TaskInstancesPublicDetailsOutDTO taskResponse = null;
		Response response = null;
		try {
			response = webTarget
						.request(MediaType.APPLICATION_JSON_TYPE)
						.accept(MediaType.APPLICATION_JSON_TYPE)
						.header(ACCEPT_LANGUAGE, reqContext.getLang())
						.header(AUTHORIZATION, String.format(JWT_PREFIX, reqContext.getUser().getAuthToken()))
					.get();

			if (response.getStatus() == 200) {
				response.bufferEntity();
				taskResponse = response.readEntity(TaskInstancesPublicDetailsOutDTO.class);
			} else {
				Map<String, Object> errorResponse = response.readEntity(new GenericType<HashMap<String, Object>>() {
				});
				String errorCode = (String) errorResponse.get("errorCode");
				InvalidSessionTaskException ex = new InvalidSessionTaskException(Status.BAD_REQUEST,
						Operation.GET_TASK_DATA, ErrorField.TASK,
						this.errorDescriptionsService.getTenantErrorDescriptions(reqContext.getTenantId()),
						reqContext.getLang());

				ex.getBody().setMessage(errorCode);
				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}

		} catch (Exception e) {
			InvalidSessionTaskException ex = new InvalidSessionTaskException(Status.BAD_REQUEST,
					Operation.GET_TASK_DATA, ErrorField.TASK,
					this.errorDescriptionsService.getTenantErrorDescriptions(reqContext.getTenantId()),
					reqContext.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		} finally {
			if (response != null)
				response.close();
		}

		return mapTaskResponse(reqContext, taskId, taskResponse);

	}
	

	public TaskManagerData updateTaskData(ReqContext reqContext, String taskId, String motivation, Integer transitionId,
			String transitionTag, List<String> acceptableErrorCodes) {

		checkReqContext(reqContext, Operation.UPDATE_TASK_DATA);

		TaskInstancesPublicDetailsOutDTO taskResponse = callTaskManagerUpdate(reqContext, taskId, motivation, transitionId,
				transitionTag, acceptableErrorCodes);

		return mapTaskResponse(reqContext, taskId, taskResponse);

	}

	private TaskInstancesPublicDetailsOutDTO callTaskManagerUpdate(ReqContext reqContext, String taskId, String motivation,
			Integer transitionId, String transitionTag, List<String> acceptableErrorCodes) {

		TaskInstancesPublicDetailsOutDTO taskResponse = null;
		Response response = null;

		String tenantId = reqContext.getTenantId();
		String lang = reqContext.getLang();
		String authToken = reqContext.getUser().getAuthToken();
		
		try {
			if (transitionId != null) {
				// POST
				// ​/{tenant}​/public​/v1​/task-instances​/{task_id}​/transitions/{transitionId}
				// Request body:
				// {
				// "scope": "string",
				// "notes": "string"
				// }
				WebTarget webTarget = taskManagerWT
						.path(tenantId + "/")
						.path("public/v1" + "/")
						.path("task-instances" + "/")
						.path(taskId + "/")
						.path("transitions" + "/")
						.path(transitionId.toString());

				TaskInstanceTransitionScopeInDTO taskReq = new TaskInstanceTransitionScopeInDTO();
				taskReq.setScope(
						this.internalConf.getStringValue(tenantId, InternalConfigKeys.WORKFLOW_SCOPE_KEY.getKey()));
				taskReq.setNotes(motivation);

				response = webTarget
							.request(MediaType.APPLICATION_JSON_TYPE)
							.accept(MediaType.APPLICATION_JSON_TYPE)
							.header(ACCEPT_LANGUAGE, lang)
							.header(AUTHORIZATION, String.format(JWT_PREFIX, authToken))
						.post(Entity.entity(taskReq, MediaType.APPLICATION_JSON));

			} else {
				// POST ​/{tenant}​/public​/v1​/task-instances​/{task_id}​/transitions
				// Request body:
				// {
				// "scope": "string",
				// "transitionTag": "string",
				// "notes": "string"
				// }
				WebTarget webTarget = taskManagerWT
						.path(tenantId + "/")
						.path("public/v1" + "/")
						.path("task-instances" + "/")
						.path(taskId + "/")
						.path("transitions");

				TaskInstanceTransitionInDTO taskReq = new TaskInstanceTransitionInDTO();
				taskReq.setScope(
						this.internalConf.getStringValue(tenantId, InternalConfigKeys.WORKFLOW_SCOPE_KEY.getKey()));
				taskReq.setTransitionTag(transitionTag);
				taskReq.setNotes(motivation);

				response = webTarget
							.request(MediaType.APPLICATION_JSON_TYPE)
							.accept(MediaType.APPLICATION_JSON_TYPE)
							.header(ACCEPT_LANGUAGE, lang)
							.header(AUTHORIZATION, String.format(JWT_PREFIX, authToken))
						.post(Entity.entity(taskReq, MediaType.APPLICATION_JSON));
			}

			if (response.getStatus() == 200) {
				response.bufferEntity();
				taskResponse = response.readEntity(TaskInstancesPublicDetailsOutDTO.class);
			} else {
				Map<String, Object> errorResponse = response.readEntity(new GenericType<HashMap<String, Object>>() {
				});
				String errorCode = (String) errorResponse.get("errorCode");
				if (acceptableErrorCodes == null || !acceptableErrorCodes.contains(errorCode)) {
					InvalidSessionTaskException ex = new InvalidSessionTaskException(Status.BAD_REQUEST,
							Operation.UPDATE_TASK_DATA, ErrorField.TASK,
							this.errorDescriptionsService.getTenantErrorDescriptions(reqContext.getTenantId()),
							reqContext.getLang());

					ex.getBody().setMessage(errorCode);
					log.error(ex.getBody().getLogErrorMessage());

					throw ex;
				}
			}
		} catch (Exception e) {
			InvalidSessionTaskException ex = new InvalidSessionTaskException(Status.BAD_REQUEST,
					Operation.UPDATE_TASK_DATA, ErrorField.TASK,
					this.errorDescriptionsService.getTenantErrorDescriptions(reqContext.getTenantId()),
					reqContext.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		} finally {
			if (response != null)
				response.close();
		}
		return taskResponse;
	}

	public TaskManagerTransitionList getTransitions(ReqContext reqContext, String taskId, String filterTag) {

		checkReqContext(reqContext, Operation.GET_TRANSITION);

		String lang = reqContext.getLang();
		String authToken = reqContext.getUser().getAuthToken();
		String tenantId = reqContext.getUser().getTenant();

		if (lang == null || authToken == null || tenantId == null) {
			InvalidUserEditSessionException ex = new InvalidUserEditSessionException(Status.BAD_REQUEST,
					Operation.GET_TRANSITION, ErrorField.REQUEST_CONTEXT,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		// GET /task-manager/{tenant}/public/v1/task-instances/{task-id}/transitions
		WebTarget webTarget = taskManagerWT
				.path(tenantId + "/")
				.path("public/v1" + "/")
				.path("task-instances" + "/")
				.path(taskId + "/")
				.path("transitions")
				.queryParam("tag", filterTag);

		List<TransitionOutPublicApiDTO> transitions = webTarget
					.request(MediaType.APPLICATION_JSON_TYPE)
					.accept(MediaType.APPLICATION_JSON_TYPE)
					.header(ACCEPT_LANGUAGE, lang)
					.header(AUTHORIZATION, String.format(JWT_PREFIX, authToken))
				.get(new GenericType<List<TransitionOutPublicApiDTO>>() { });

		return TaskManagerTransitionList.builder().transitions_list(transitions).build();
	}

	private void checkReqContext(ReqContext reqContext, Operation operation) {

		if (reqContext == null || reqContext.getUser() == null || StringUtils.isBlank(reqContext.getTenantId())) {
			InvalidUserEditSessionException ex = new InvalidUserEditSessionException(Status.BAD_REQUEST, operation,
					ErrorField.REQUEST_CONTEXT,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if (reqContext.getLang() == null || reqContext.getUser().getAuthToken() == null || reqContext.getUser().getTenant() == null) {
			InvalidUserEditSessionException ex = new InvalidUserEditSessionException(Status.BAD_REQUEST,
					operation, ErrorField.REQUEST_CONTEXT,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}

	private TaskManagerData mapTaskResponse(ReqContext reqContext, String taskId, TaskInstancesPublicDetailsOutDTO taskResponse) {
		TaskManagerData taskData = TaskManagerData.builder().taskId(taskId).parcelId(null).sketches(null).srs(null)
				.taskGroupCode(null).partyId(null).planId(null).build();

		if (taskResponse != null) {

			taskData.setTaskGroupCode(taskResponse.getGroupCode());

			// XXX Maybe useful in the future...
//			taskData.setDocument(taskResponse.getDocument());

			try {

				taskData.setSketches(getSketches(taskResponse.getDocument(), "sketches"));

			} catch (ParseException e) {
				InvalidSessionGeomException ex = new InvalidSessionGeomException(Status.BAD_REQUEST,
						Operation.GET_TASK_DATA, ErrorField.GEOM,
						this.errorDescriptionsService.getTenantErrorDescriptions(reqContext.getTenantId()), reqContext.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}

			taskData.setSrs((String) getDocumentSingleValue(taskResponse.getDocument(), "srs"));

			String parcelId = (String) getDocumentSingleValue(taskResponse.getDocument(), "parcel_id");
			if(parcelId != null) {
				taskData.setParcelId(Long.parseLong(parcelId));
			}
			
			taskData.setPartyId((String) getDocumentSingleValue(taskResponse.getDocument(), "party_id"));
			taskData.setPlanId((String) getDocumentSingleValue(taskResponse.getDocument(), "plan_id"));

		}

		return taskData;
	}

	private Object getDocumentSingleValue(Document document, String key) {

		if (keyAndDocumentFieldsAreNotDefined(document, key)) {
			return null;
		}

		Object docVal = document.getFields().get(key);
		if (docVal != null) {
			if (docVal.getClass().isArray()) {
				List<Object> list = Arrays.asList((Object[]) docVal);
				if (list != null && !list.isEmpty())
					return list.get(0);
			} else if (docVal instanceof Collection) {
				List<Object> list = new ArrayList<>((Collection<?>) docVal);
				if (!list.isEmpty())
					return list.get(0);
			} else {
				return docVal;
			}
		}
		return null;
	}

	private boolean keyAndDocumentFieldsAreNotDefined(Document document, String key) {
		return key == null || document == null || document.getFields() == null || document.getFields().isEmpty();
	}

	private List<Geometry> getSketches(Document document, String key) throws ParseException {

		if (keyAndDocumentFieldsAreNotDefined(document, key)) {
			return null;
		}

		List<?> list = null;

		Object docSketches = document.getFields().get(key);
		if (docSketches != null) {
			list = buildDockSketches(list, docSketches);

			if (list != null && !list.isEmpty()) {
				List<Geometry> sketches = new ArrayList<>();
				for (Object o : list) {
					Geometry geom = wktReader.read(String.valueOf(o));
					sketches.add(geom);
				}
				return sketches;
			}
		}

		return null;
	}

	private List<?> buildDockSketches(List<?> list, Object docSketches) {
		if (docSketches.getClass().isArray()) {
			list = Arrays.asList((Object[]) docSketches);
		} else if (docSketches instanceof Collection) {
			list = new ArrayList<>((Collection<?>) docSketches);
		} else if (docSketches instanceof String) {
			list = Arrays.asList(docSketches);
		}
		return list;
	}
}
