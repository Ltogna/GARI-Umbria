package com.abacogroup.lpisgisserver.core.pub;

import static java.util.stream.Collectors.toList;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lpisgisserver.core.BaseService;
import com.abacogroup.lpisgisserver.core.ErrorDescriptionsService;
import com.abacogroup.lpisgisserver.core.ExternalConfigService;
import com.abacogroup.lpisgisserver.core.InternalConfigService;
import com.abacogroup.lpisgisserver.core.StyleService;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.matrix.InvalidMatrixClassException;
import com.abacogroup.lpisgisserver.core.exceptions.matrix.InvalidMatrixUserException;
import com.abacogroup.lpisgisserver.core.exceptions.matrix.MatrixClassNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.matrix.MatrixCodeNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.matrix.MatrixCodeNotValidException;
import com.abacogroup.lpisgisserver.core.exceptions.support.LandCoverCodeNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.support.LandUsesCodeNotFoundException;
import com.abacogroup.lpisgisserver.core.mappers.MatrixClassLandcoverMapper;
import com.abacogroup.lpisgisserver.core.mappers.MatrixClassLanduseMapper;
import com.abacogroup.lpisgisserver.core.mappers.MatrixClassMapper;
import com.abacogroup.lpisgisserver.core.mappers.MatrixMapper;
import com.abacogroup.lpisgisserver.core.support.MatrixSearchParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassDetailsDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassLandUsesDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassLandcoversDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassMetadataDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixCompatDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixLandCoverDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixLandCoversMetadataDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixLandUsesDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixLandUsesMetadataDAO;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoversCodeNTT;
import com.abacogroup.lpisgisserver.db.ntt.LandUsesCodeNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassLandcoversNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassLandusesNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassMetadataNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassesNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixCompatNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixLandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixLandCoverWithLandUseNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixLandCoversMetadataNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixLandUsesMetadataNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixLandUsesNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixNTT;
import com.abacogroup.lpisgisserver.db.ntt.UserFavouriteFieldsNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.ResourceConstants;
import com.abacogroup.lpisgisserver.resources.req.ReqContext;
import com.abacogroup.lpisgisserver.resources.req.pub.PublicGetLandCoverDetailsPayload;
import com.abacogroup.lpisgisserver.resources.req.pub.PublicGetLandUseDetailsByClassesPayload;
import com.abacogroup.lpisgisserver.resources.req.pub.PublicGetLandUseDetailsPayload;
import com.abacogroup.lpisgisserver.resources.res.pub.ClassDetailsV1;
import com.abacogroup.lpisgisserver.resources.res.pub.ClassDetailsV1List;
import com.abacogroup.lpisgisserver.resources.res.pub.LandCoverCodeV1List;
import com.abacogroup.lpisgisserver.resources.res.pub.LandCoverDetailsV1;
import com.abacogroup.lpisgisserver.resources.res.pub.LandCoversByLandUsesV1;
import com.abacogroup.lpisgisserver.resources.res.pub.LandCoversCodeV1;
import com.abacogroup.lpisgisserver.resources.res.pub.LandUseDetailsV1;
import com.abacogroup.lpisgisserver.resources.res.pub.LandUseStyleV1;
import com.abacogroup.lpisgisserver.resources.res.pub.LandUseStyleV1List;
import com.abacogroup.lpisgisserver.resources.res.pub.LandUsesCodeV1;
import com.abacogroup.lpisgisserver.resources.res.pub.LandUsesCodeV1List;
import com.abacogroup.lpisgisserver.resources.res.pub.MatrixClassV1;
import com.abacogroup.lpisgisserver.resources.res.pub.MatrixV1;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MatrixV1Service extends BaseService {

	private final MatrixDAO matrixDAO;
	private final MatrixClassDAO matrixClassesDAO;
	private final MatrixClassDetailsDAO matrixClassDetailsDAO;
	private final MatrixClassLandcoversDAO matrixClassLandcoversDAO;
	private final MatrixClassLandUsesDAO matrixClassLandusesDAO;
	private final MatrixCompatDAO matrixCompatDAO;

	private final MatrixLandUsesDAO matrixLandUsesDAO;
	private final MatrixLandCoverDAO matrixLandCoverDAO;

	private final MatrixClassMetadataDAO matrixClassMetadataDAO;
	private final MatrixLandCoversMetadataDAO matrixLandCoversMetadataDAO;
	private final MatrixLandUsesMetadataDAO matrixLandUsesMetadataDAO;

	private final SupportDAO supportDAO;
	
	private final static String LANDUSE_CODE_COLUMN = "land_use_code";
	
	private Cache<String, ClassDetailsV1> classDetailsCache; //KEY: tenant|matrixCode|classCode

	public MatrixV1Service(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);
		matrixClassDetailsDAO = dc.getMatrixClassDetailsDAO();
		matrixClassesDAO = dc.getMatrixClassDAO();
		matrixClassLandcoversDAO = dc.getMatrixClassLandcoversDAO();
		matrixClassLandusesDAO = dc.getMatrixClassLandUsesDAO();
		matrixCompatDAO = dc.getMatrixCompatDAO();
		matrixDAO = dc.getMatrixDAO();

		matrixLandUsesDAO = dc.getMatrixLandUsesDAO();
		matrixLandCoverDAO = dc.getMatrixLandCoverDAO();

		matrixClassMetadataDAO = dc.getMatrixClassMetadataDAO();
		matrixLandCoversMetadataDAO = dc.getMatrixLandCoversMetadataDAO();
		matrixLandUsesMetadataDAO = dc.getMatrixLandUsesMetadataDAO();

		supportDAO = dc.getSupportDAO();
		
		classDetailsCache = Caffeine.newBuilder()
				.maximumSize(1000)
				.expireAfterAccess(Duration.ofHours(12))
				.build();
	}

	public MatrixV1 searchMatrix(ReqContext reqContext, MatrixSearchParams search) {

		if (reqContext == null || StringUtils.isBlank(reqContext.getTenantId())) {

			InvalidMatrixUserException ex = new InvalidMatrixUserException(Status.BAD_REQUEST, Operation.GET_PUBLIC_MATRIX, ErrorField.REQUEST_CONTEXT,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(reqContext.getUser())
				.lang(reqContext.getLang())
				.tenantId(reqContext.getTenantId())
				.referenceDate(search.getReferenceDate())
				.build();

		List<MatrixNTT> matrixes = matrixDAO.findByCode(env, search.getMatrixCode());
		if (matrixes.isEmpty()) {
			MatrixCodeNotFoundException ex = new MatrixCodeNotFoundException(Status.NOT_FOUND, Operation.GET_PUBLIC_MATRIX, ErrorField.MATRIX_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		} else if (matrixes.size() > 1) {
			MatrixCodeNotValidException ex = new MatrixCodeNotValidException(Status.BAD_REQUEST, Operation.GET_PUBLIC_MATRIX, ErrorField.MATRIX_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		MatrixNTT matrix = matrixes.get(0);
		search.setMatrixId(matrix.getId());

		MatrixV1 result = MatrixMapper.INSTANCE.entityToDto(matrix);
		result.setMatrix_class_list(new ArrayList<>());

		List<MatrixClassesNTT> matrixClasses = !StringUtils.isBlank(search.getClassCode())
				? matrixClassesDAO.findByMatrixIdAndCode(env, matrix.getId(), search.getClassCode())
				: matrixClassesDAO.searchByMatrixIdAndCode(env, matrix.getId(), search.getClassFilter());

		if (matrixClasses.isEmpty()) {
			MatrixClassNotFoundException ex = new MatrixClassNotFoundException(Status.NOT_FOUND, Operation.GET_PUBLIC_MATRIX, ErrorField.MATRIX_CLASS,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		List<MatrixClassV1> matrixClassV1List = buildMatrixClassList(matrixClasses, search, env, matrix.getId());
		result.setMatrix_class_list(matrixClassV1List);

		return result;
	}

	private List<MatrixClassV1> buildMatrixClassList(List<MatrixClassesNTT> matrixClasses, MatrixSearchParams search, ServiceSupportEnv env, Long matrixId) {
		List<MatrixClassV1> result = new ArrayList<>();

		for (MatrixClassesNTT matrixClass : matrixClasses) {

			search.setClassCode(matrixClass.getCode());

			List<MatrixClassDetailsNTT> matrixesDetails = matrixClassDetailsDAO.searchValidByMatrixIdAndClassCode(env, search);
			List<MatrixClassLandcoversNTT> landcoverNTTs = matrixClassLandcoversDAO.searchValidByMatrixIdAndClassCode(env, search);
			List<MatrixClassLandusesNTT> landuseNTTs = matrixClassLandusesDAO.searchValidByMatrixIdAndClassCode(env, search);
			List<MatrixCompatNTT> extension = matrixCompatDAO.findByMatrixIdAndClassCode(matrixId, matrixClass.getCode());

			for (MatrixClassDetailsNTT matrixDetails : matrixesDetails) {
				MatrixClassV1 matrixClassDTO = MatrixClassMapper.INSTANCE.entityToDto(matrixDetails);
				matrixClassDTO.setLandcover_list(new ArrayList<>());
				matrixClassDTO.setLanduse_list(new ArrayList<>());
				matrixClassDTO.setExtension_class_code_list(new ArrayList<>());

				if (!landcoverNTTs.isEmpty())
					matrixClassDTO.getLandcover_list()
							.addAll(landcoverNTTs.stream().map(MatrixClassLandcoverMapper.ININSTANCE::entityToDto).collect(toList()));

				if (!landuseNTTs.isEmpty())
					matrixClassDTO.getLanduse_list().addAll(landuseNTTs.stream().map(MatrixClassLanduseMapper.ININSTANCE::entityToDto).collect(toList()));

				if (!extension.isEmpty())
					matrixClassDTO.getExtension_class_code_list()
							.addAll(extension.stream().map(MatrixCompatNTT::getExtended_by_class_code).collect(toList()));

				result.add(matrixClassDTO);
			}
		}

		return result;
	}

	public LandUseStyleV1List getLandUsesStyles(ServiceSupportEnv env, String matrixCode, List<String> landUseCodes) {
		List<LandUseStyleV1> result = new ArrayList<>();

		Criteria criteria = landUseCodes != null && !landUseCodes.isEmpty() ? CriteriaBuilder.string(LANDUSE_CODE_COLUMN).in(landUseCodes)
				: CriteriaBuilder.number("1").eq(1);

		List<MatrixLandUsesNTT> landUsesStyles = matrixLandUsesDAO.getLandUsesStylesByCodes(env, matrixCode, criteria, null);
		landUsesStyles.forEach(landUseStyleNTT -> result.add(
				LandUseStyleV1.builder()
						.class_code(landUseStyleNTT.getClass_code())
						.fill_rgba(landUseStyleNTT.getFill_rgba())
						.land_use_code(landUseStyleNTT.getLanduse().getCode())
						.line_rgba(landUseStyleNTT.getLine_rgba())
						.line_thick(landUseStyleNTT.getLine_thick())
						.build()));

		return LandUseStyleV1List.builder().land_use_style_list(result).build();
	}

	public ClassDetailsV1List getClassDetails(ServiceSupportEnv env, String matrixCode, List<String> classCodes) {
		List<ClassDetailsV1> result = new ArrayList<>();

		List<MatrixNTT> matrix = matrixDAO.findByCode(env, matrixCode);
		if (matrix.isEmpty()) {
			MatrixCodeNotFoundException ex = new MatrixCodeNotFoundException(Status.NOT_FOUND, Operation.GET_CLASS_DETAILS, ErrorField.MATRIX_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		List<MatrixClassDetailsNTT> classDetails = matrixClassDetailsDAO.getClassDetailsByMatrixIdAndClassCodes(env, matrix.get(0).getId(), classCodes);

		classDetails.forEach(classDetailsNTT -> result.add(
				ClassDetailsV1.builder()
						.class_code(classDetailsNTT.getClass_code())
						.class_description(classDetailsNTT.getClass_description())
						.class_metadata(null)
						.fill_rgba(classDetailsNTT.getFill_rgba())
						.line_rgba(classDetailsNTT.getLine_rgba())
						.line_thick(classDetailsNTT.getLine_thick().intValue())
						.build()));

		return ClassDetailsV1List.builder().class_details_list(result).build();
	}

	public LandUsesCodeV1List getLandUsesByClassCode(ServiceSupportEnv env, String matrixCode, String classCode, Boolean ignoreIntercompatibility) {
		List<LandUsesCodeV1> result = new ArrayList<>();

		if (StringUtils.isNotBlank(classCode)) {
			List<String> classCodes = new ArrayList<>();
			classCodes.add(classCode);

			if (ignoreIntercompatibility.equals(Boolean.FALSE)) {
				classCodes.addAll(
						matrixCompatDAO.getExtendedClassCodesByClassCode(env.getTenantId(), matrixCode, classCode)
							.stream()
							.map(lc -> lc.getExtended_by_class_code())
							.collect(toList())
						);
			}

			List<LandUsesCodeNTT> landUses = matrixLandUsesDAO.getLandUsesByClassCodes(env, matrixCode, classCodes);

			landUses.forEach(landUsesNTT -> result.add(
					LandUsesCodeV1.builder()
							.description(landUsesNTT.getDescription())
							.land_uses_code(landUsesNTT.getCode())
							.build()));
		}

		return LandUsesCodeV1List.builder().land_uses_codes_list(result).build();
	}

	public LandCoversByLandUsesV1 getLandCoversByLandUseCodes(List<String> landuseCodes, String matrixCode, ServiceSupportEnv env) {
		LandCoversByLandUsesV1 result = LandCoversByLandUsesV1.builder().land_covers_by_land_uses(new HashMap<>()).build();

		Criteria criteria = landuseCodes != null && !landuseCodes.isEmpty() ? CriteriaBuilder.string(LANDUSE_CODE_COLUMN).in(landuseCodes)
				: CriteriaBuilder.number("1").eq(1);

		List<MatrixLandCoverWithLandUseNTT> landcoversByLandUses = matrixLandCoverDAO.getLandCoversCodesByLandUseCodes(env, matrixCode, criteria);

		List<String> landUses = landcoversByLandUses.stream().map(ntt -> ntt.getLand_use_code()).distinct().collect(toList());

		landUses.forEach(
				landUse -> {
					List<LandCoversCodeV1> list = landcoversByLandUses.stream().map(ntt -> new LandCoversCodeV1(ntt.getCode(), ntt.getDescription(), null))
							.collect(toList());
					result.getLand_covers_by_land_uses().put(landUse, list);
				});

		return result;
	}

	public LandCoverCodeV1List getLandcoversCompatibleWithLandCover(ServiceSupportEnv env, String matrixCode, String landCoverCode) {

		List<LandCoversCodeNTT> extendedLandCovers = matrixLandCoverDAO.getExtendedLandCoverCodesByLandCoverCode(env, matrixCode, landCoverCode);
		if (extendedLandCovers.isEmpty()) {
			throw new LandCoverCodeNotFoundException(Status.NOT_FOUND, Operation.GET_EXTENDED_LANDCOVER_CODES, ErrorField.LANDCOVER_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		List<LandCoversCodeV1> list = extendedLandCovers.stream().map(ntt -> new LandCoversCodeV1(ntt.getCode(), ntt.getDescription(), null))
				.collect(toList());

		return LandCoverCodeV1List.builder().land_covers_codes_list(list).build();
	}

	public ClassDetailsV1List getClassCompatiblesDetails(ServiceSupportEnv env, String matrixCode, String classCode) {
		List<MatrixCompatNTT> extendedClasses = matrixCompatDAO.getExtendedClassCodesByClassCode(env.getTenantId(), matrixCode, classCode);
		if (extendedClasses.isEmpty()) {
			throw new MatrixClassNotFoundException(Status.NOT_FOUND, Operation.GET_EXTENDED_CLASS_CODES, ErrorField.MATRIX_CLASS,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		List<MatrixNTT> matrix = matrixDAO.findByCode(env, matrixCode);
		if (matrix.isEmpty()) {
			MatrixCodeNotFoundException ex = new MatrixCodeNotFoundException(Status.NOT_FOUND, Operation.GET_CLASS_DETAILS, ErrorField.MATRIX_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		List<MatrixClassDetailsNTT> classDetails = matrixClassDetailsDAO.getClassDetailsByMatrixIdAndClassCodes(env, matrix.get(0).getId(),
				extendedClasses.stream().map(MatrixCompatNTT::getClass_code).collect(toList()));

		List<ClassDetailsV1> result = new ArrayList<>();

		classDetails.forEach(classDetailsNTT -> result.add(
				ClassDetailsV1.builder()
						.class_code(classDetailsNTT.getClass_code())
						.class_description(classDetailsNTT.getClass_description())
						.class_metadata(null)
						.fill_rgba(classDetailsNTT.getFill_rgba())
						.line_rgba(classDetailsNTT.getLine_rgba())
						.line_thick(classDetailsNTT.getLine_thick().intValue())
						.build()));

		return ClassDetailsV1List.builder().class_details_list(result).build();
	}

	public LandCoverDetailsV1 getLandcoverDetails(ServiceSupportEnv env, String matrixCode, String landCoverCode) {
		Criteria criteria = CriteriaBuilder.string("land_cover_code").eq(landCoverCode);

		List<MatrixLandCoverNTT> landCoversStyles = matrixLandCoverDAO.getLandCoverStylesByCodes(env, matrixCode, criteria);
		if (landCoversStyles.isEmpty()) {
			throw new LandCoverCodeNotFoundException(Status.NOT_FOUND, Operation.GET_LANDCOVER_DETAILS, ErrorField.LANDCOVER_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		MatrixLandCoverNTT matrixLandCoverNTT = landCoversStyles.get(0);
		
		return buildLandCoverDetails(matrixLandCoverNTT, matrixCode, env);
	}

	public LandUseDetailsV1 getLanduseDetails(ServiceSupportEnv env, String matrixCode, String landUseCode) {
		List<UserFavouriteFieldsNTT> userFavourite = supportDAO.getFavouriteFields(env.getTenantId(), env.getUserId(), LANDUSE_CODE_COLUMN);
		List<String> favouriteLandUseCodes = !userFavourite.isEmpty()
				? userFavourite.stream().map(UserFavouriteFieldsNTT::getField_value).collect(toList())
				: null;
		
		Criteria criteria = CriteriaBuilder.string(LANDUSE_CODE_COLUMN).eq(landUseCode);

		List<MatrixLandUsesNTT> landUsesStyles = matrixLandUsesDAO.getLandUsesStylesByCodes(env, matrixCode, criteria, favouriteLandUseCodes);
		if (landUsesStyles.isEmpty()) {
			throw new LandUsesCodeNotFoundException(Status.NOT_FOUND, Operation.GET_LANDUSE_CODE, ErrorField.LANDUSE_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		MatrixLandUsesNTT matrixLandUseNTT = landUsesStyles.get(0);

		return buildLandUseDetails(matrixLandUseNTT, matrixCode, env);
	}

	public InfiniteListResults<LandCoverDetailsV1> getLandCoverDetailsInfinite(ServiceSupportEnv env, String matrixCode,
			@NotNull PublicGetLandCoverDetailsPayload payload) {

		List<LandCoverDetailsV1> result = new ArrayList<>();

		List<UserFavouriteFieldsNTT> userFavourite = supportDAO.getFavouriteFields(env.getTenantId(), env.getUserId(), "land_cover_code");
		List<String> favouriteLandCoverCodes = !userFavourite.isEmpty()
				? userFavourite.stream().map(UserFavouriteFieldsNTT::getField_value).collect(toList())
				: null;


		List<String> landCoverCodes = payload.getLand_cover_codes() != null && !payload.getLand_cover_codes().isEmpty()
				? payload.getLand_cover_codes()
				: null;

		InfiniteListResults<MatrixLandCoverNTT> landCoverStyles = matrixLandCoverDAO.infinite(
				() -> matrixLandCoverDAO.getLandCoverStylesByCodesInfinite(env, matrixCode, payload.getSearch(), favouriteLandCoverCodes,
						landCoverCodes),
				payload.getNext_key(),
				payload.getPage_size() != null ? payload.getPage_size() : ResourceConstants.DEFAULT_PAGE_SIZE);

		landCoverStyles.getRecords().stream().forEach(landCoverStyle -> result.add(buildLandCoverDetails(landCoverStyle, matrixCode, env)));

		return new InfiniteListResultsImpl<>(result, landCoverStyles.getNextKey());
	}

	public InfiniteListResults<LandUseDetailsV1> getLandUseDetailsInfinite(ServiceSupportEnv env, String matrixCode,
			@NotNull PublicGetLandUseDetailsPayload payload) {

		List<LandUseDetailsV1> result = new ArrayList<>();

		List<String> favouriteLandUseCodes = payload.getFavourite_land_use_codes() != null && !payload.getFavourite_land_use_codes().isEmpty()
				? payload.getFavourite_land_use_codes()
				: supportDAO.getFavouriteFields(env.getTenantId(), env.getUserId(), LANDUSE_CODE_COLUMN).stream()
						.map(UserFavouriteFieldsNTT::getField_value).collect(toList());
		

		List<String> landUseCodes = payload.getLand_use_codes() != null && !payload.getLand_use_codes().isEmpty()
				? payload.getLand_use_codes()
				: null;

		InfiniteListResults<MatrixLandUsesNTT> landUseStyles = matrixLandUsesDAO.infinite(
				() -> matrixLandUsesDAO.getLandUsesStylesByCodesInfinite(env, matrixCode, payload.getSearch(), favouriteLandUseCodes,
						landUseCodes),
				payload.getNext_key(),
				payload.getPage_size() != null ? payload.getPage_size() : ResourceConstants.DEFAULT_PAGE_SIZE);

		landUseStyles.getRecords().stream().forEach(landUseStyle -> result.add(buildLandUseDetails(landUseStyle, matrixCode, env)));

		return new InfiniteListResultsImpl<>(result, landUseStyles.getNextKey());
	}

	public InfiniteListResults<LandUseDetailsV1> getLanduseDetailsByClassesInfinite(ServiceSupportEnv env, String matrixCode,
			@NotNull PublicGetLandUseDetailsByClassesPayload payload) {

		List<LandUseDetailsV1> result = new ArrayList<>();

		List<String> favouriteLandUseCodes = payload.getFavourite_land_use_codes() != null && !payload.getFavourite_land_use_codes().isEmpty()
				? payload.getFavourite_land_use_codes()
				: supportDAO.getFavouriteFields(env.getTenantId(), env.getUserId(), LANDUSE_CODE_COLUMN).stream()
						.map(UserFavouriteFieldsNTT::getField_value).collect(toList());

		if (payload.getClass_codes() == null || payload.getClass_codes().isEmpty()) {
			throw new InvalidMatrixClassException(Status.BAD_REQUEST, Operation.GET_LANDUSE_DETAILS_BY_CLASSES, ErrorField.MATRIX_CLASS,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		Integer useIntercompatibility = payload.getUseIntercompatibility().equals(Boolean.TRUE) ? 1 : 0;

		InfiniteListResults<MatrixLandUsesNTT> landUses = matrixLandUsesDAO.infinite(
				() -> matrixLandUsesDAO.getLandUsesByClassCodesInfinite(env, matrixCode, payload.getSearch(),
						payload.getClass_codes(),
						favouriteLandUseCodes,
						useIntercompatibility),
				payload.getNext_key(),
				payload.getPage_size() != null ? payload.getPage_size() : ResourceConstants.DEFAULT_PAGE_SIZE);

		if (landUses.getCount() == 0) {
			throw new LandUsesCodeNotFoundException(Status.NOT_FOUND, Operation.GET_LANDUSE_DETAILS_BY_CLASSES, ErrorField.MATRIX_CLASS,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		landUses.getRecords().stream().forEach(landUseStyle -> result.add(buildLandUseDetails(landUseStyle, matrixCode, env)));

		return new InfiniteListResultsImpl<>(result, landUses.getNextKey());
	}

	private ClassDetailsV1 getClassDetails(String matrixCode, String classCode, String classDescription, String lineRgba, String fillRgba,
			Integer lineThick, ServiceSupportEnv env) {

		List<MatrixClassMetadataNTT> matrixClassMetadata = matrixClassMetadataDAO.getClassMetadataByMatrixCodeClassCodeAndKey(env.getTenantId(), matrixCode,
				classCode, env.getReferenceDate(), null);

		Map<String, String> classMetadata = new HashMap<>();
		matrixClassMetadata.forEach(metadata -> classMetadata.put(metadata.getKey(), metadata.getValue()));

		return ClassDetailsV1.builder()
				.class_code(classCode)
				.class_description(classDescription)
				.class_metadata(classMetadata)
				.fill_rgba(fillRgba)
				.line_rgba(lineRgba)
				.line_thick(lineThick)
				.build();
	}

	private LandCoverDetailsV1 buildLandCoverDetails(MatrixLandCoverNTT publicMatrixLandCoverNTT, String matrixCode, ServiceSupportEnv env) {
		// Build land cover metadata
		List<MatrixLandCoversMetadataNTT> matrixLandCoversMetadata = matrixLandCoversMetadataDAO.getLandCoversMetadataByKeyMatrixCodeClassCodeLandCoverCode(env.getTenantId(), matrixCode,
				publicMatrixLandCoverNTT.getClass_code(), publicMatrixLandCoverNTT.getLandcover().getCode(), env.getReferenceDate(), null);

		Map<String, String> landCoverMetadata = new HashMap<>();
		matrixLandCoversMetadata.forEach(metadata -> landCoverMetadata.put(metadata.getKey(), metadata.getValue()));

		// Build class details
		String key = env.getTenantId() + "|" + matrixCode + "|" + publicMatrixLandCoverNTT.getClass_code();
		ClassDetailsV1 classDetails = classDetailsCache.getIfPresent(key);
		
		if(classDetails == null) {
			classDetails = loadClassDetailsCache(env, matrixCode, publicMatrixLandCoverNTT.getClass_code(), publicMatrixLandCoverNTT.getClass_description(),
					publicMatrixLandCoverNTT.getLine_rgba(), publicMatrixLandCoverNTT.getFill_rgba(), publicMatrixLandCoverNTT.getLine_thick());
		}
		return LandCoverDetailsV1.builder()
				.description(publicMatrixLandCoverNTT.getLandcover().getDescription())
				.land_cover_class_details(classDetails)
				.land_cover_code(publicMatrixLandCoverNTT.getLandcover().getCode())
				.land_cover_metadata(landCoverMetadata)
				.is_favourite(publicMatrixLandCoverNTT.getIsFavourite() == 0 ? Boolean.FALSE : Boolean.TRUE)
				.build();
	}

	private LandUseDetailsV1 buildLandUseDetails(MatrixLandUsesNTT publicMatrixLandUsesNTT, String matrixCode, ServiceSupportEnv env) {
		// Build land cover metadata
		List<MatrixLandUsesMetadataNTT> matrixLandUsesMetadata = matrixLandUsesMetadataDAO.getLandUsesMetadataByMatrixCodeClassCodeLandUseCodeAndKey(env.getTenantId(), matrixCode,
				publicMatrixLandUsesNTT.getClass_code(), publicMatrixLandUsesNTT.getLanduse().getCode(), env.getReferenceDate(), null);

		Map<String, String> landUseMetadata = new HashMap<>();
		matrixLandUsesMetadata.forEach(metadata -> landUseMetadata.put(metadata.getKey(), metadata.getValue()));

		// Build class details
		String key = env.getTenantId() + "|" + matrixCode + "|" + publicMatrixLandUsesNTT.getClass_code();
		ClassDetailsV1 classDetails = classDetailsCache.getIfPresent(key);
		
		if(classDetails == null) {
			classDetails = loadClassDetailsCache(env, matrixCode, publicMatrixLandUsesNTT.getClass_code(), publicMatrixLandUsesNTT.getClass_description(),
					publicMatrixLandUsesNTT.getLine_rgba(), publicMatrixLandUsesNTT.getFill_rgba(), publicMatrixLandUsesNTT.getLine_thick());
		}	

		return LandUseDetailsV1.builder()
				.description(publicMatrixLandUsesNTT.getLanduse().getDescription())
				.land_use_class_details(classDetails)
				.land_use_code(publicMatrixLandUsesNTT.getLanduse().getCode())
				.land_use_metadata(landUseMetadata)
				.is_favourite(publicMatrixLandUsesNTT.getIsFavourite() == 0 ? Boolean.FALSE : Boolean.TRUE)
				.build();
	}
	
	private ClassDetailsV1 loadClassDetailsCache(ServiceSupportEnv env, String matrixCode, String classCode, String classDescription, String lineRgba,
			String fillRgba, Integer lineThick) {
		
		ClassDetailsV1 classDetails = getClassDetails(matrixCode, classCode, classDescription, lineRgba, fillRgba, lineThick, env);
		
		String key = env.getTenantId() + "|" + matrixCode + "|" + classCode;
		
		classDetailsCache.put(key, classDetails);
		return classDetails;
	}

}
