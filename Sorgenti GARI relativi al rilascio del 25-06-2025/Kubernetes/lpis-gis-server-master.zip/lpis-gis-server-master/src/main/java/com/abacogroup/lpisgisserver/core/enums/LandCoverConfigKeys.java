package com.abacogroup.lpisgisserver.core.enums;

public enum LandCoverConfigKeys {

	SAVE_FORBIDDEN,
	EDIT_FORBIDDEN
	
}
