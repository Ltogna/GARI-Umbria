package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.VarietyNTT;
import com.abacogroup.lpisgisserver.resources.res.pub.units.VarietyV1;
import com.abacogroup.lpisgisserver.resources.res.units.Variety;

@Mapper
public interface VarietyV1Mapper {

	VarietyV1Mapper INSTANCE = Mappers.getMapper(VarietyV1Mapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	VarietyV1 toResponseV1(VarietyNTT entity);
	
	@InheritInverseConfiguration
	VarietyV1 toResponseV1(Variety dto);
}
