package com.abacogroup.lpisgisserver;

import java.io.IOException;
import java.io.InputStream;
import java.sql.DatabaseMetaData;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.jdbi.v3.core.Jdbi;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.bundles.initializer.BundleInitServiceBuilder;
import com.abacogroup.bundles.initializer.InitService;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.listener.ListenerBuilder;
import com.abacogroup.bundles.listener.configdata.builder.ConfigDataConsumerBuilder;
import com.abacogroup.bundles.listener.tenant.builder.NewTenantEventConsumerBuilder;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.SsoAuthorizer;
import com.abacogroup.embeddedqueue.AbstractWorkQueue;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisher;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisherWorkQueue;
import com.abacogroup.jdbi.OraJdbiPlugin;
import com.abacogroup.jdbi.OraJdbiPlugin.OraJdbiPluginParams;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.jdbi.config.AbacoJdbiConfig;
import com.abacogroup.jdbi.config.SpatialVectorAcceleration;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.bundles.AdditionalExternalLinksMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.AnomalyCategoriesMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.CampaignMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.CatalogueMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.CatalogueTenantMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.EditCategoriesCodeMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.ExternalConfigMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.FruitUnitMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.I18nMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.I18nTenantMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.ImportDataMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.InternalConfigMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.InternalConfigTenantMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.LandCoverConfigMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.LandCoversCodeMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.LandUsesCodeMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.LayerMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.MatrixMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.MatrixMetadataMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.NewMatrixMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.OliveUnitMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.UnitsMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.VineUnitMessageProcessor;
import com.abacogroup.lpisgisserver.bundles.VineyardDoigtLinkMessageProcessor;
import com.abacogroup.lpisgisserver.core.WmsService;
import com.abacogroup.lpisgisserver.core.models.InternalConfig;
import com.abacogroup.lpisgisserver.core.support.ServiceContainer;
import com.abacogroup.lpisgisserver.core.support.WebTargetContainer;
import com.abacogroup.lpisgisserver.core.support.rabbitmq.RabbitmqUtils;
import com.abacogroup.lpisgisserver.db.dao.AdditionalLayersDAO;
import com.abacogroup.lpisgisserver.db.dao.AnomalyCategoriesDAO;
import com.abacogroup.lpisgisserver.db.dao.AreasDAO;
import com.abacogroup.lpisgisserver.db.dao.BlockDAO;
import com.abacogroup.lpisgisserver.db.dao.CataloguesDAO;
import com.abacogroup.lpisgisserver.db.dao.ConfigDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditFruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.EditLandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.EditOliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.EditParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.EditSessionsDAO;
import com.abacogroup.lpisgisserver.db.dao.EditUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.EditVineUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.ExternalConfigDAO;
import com.abacogroup.lpisgisserver.db.dao.ExternalSourceDataDAO;
import com.abacogroup.lpisgisserver.db.dao.FruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.I18nDAO;
import com.abacogroup.lpisgisserver.db.dao.InfoGisDAO;
import com.abacogroup.lpisgisserver.db.dao.InternalDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoverConfigsDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoversDetailsDAO;
import com.abacogroup.lpisgisserver.db.dao.LayerDAO;
import com.abacogroup.lpisgisserver.db.dao.LockParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassDetailsDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassLandUsesDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassLandcoversDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassMetadataDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixCompatDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixLandCoverDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixLandCoversMetadataDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixLandUsesDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixLandUsesMetadataDAO;
import com.abacogroup.lpisgisserver.db.dao.OliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.ParcelDetailsDAO;
import com.abacogroup.lpisgisserver.db.dao.ParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.SectorAreasDAO;
import com.abacogroup.lpisgisserver.db.dao.SectorDAO;
import com.abacogroup.lpisgisserver.db.dao.SectorDecodesDAO;
import com.abacogroup.lpisgisserver.db.dao.StackFruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.StackLandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.StackOliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.StackParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.StackVineUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.StacksDAO;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.dao.TotalLandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.TotalParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.UnitCodesDAO;
import com.abacogroup.lpisgisserver.db.dao.UnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.VineUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.WMSLayersDAO;
import com.abacogroup.lpisgisserver.db.dao.WMSParcelsFilterDAO;
import com.abacogroup.lpisgisserver.db.dao.WMSServerAreasDAO;
import com.abacogroup.lpisgisserver.db.dao.cache.CachePartyParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.cache.CacheTempParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.ts.TerritorialScopeDAO;
import com.abacogroup.lpisgisserver.dispatch.payload.StackPayload;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.jackson.AbsoluteDateSerializer;
import com.abacogroup.lpisgisserver.jackson.WKTGeometryDeserializer;
import com.abacogroup.lpisgisserver.jackson.WKTGeometrySerializer;
import com.abacogroup.lpisgisserver.providers.AreaProvider;
import com.abacogroup.lpisgisserver.providers.BlockProvider;
import com.abacogroup.lpisgisserver.providers.ParcelProvider;
import com.abacogroup.lpisgisserver.providers.ProvidersContainer;
import com.abacogroup.lpisgisserver.providers.SectorProvider;
import com.abacogroup.lpisgisserver.providers.UnitProvider;
import com.abacogroup.lpisgisserver.resources.AnomaliesResources;
import com.abacogroup.lpisgisserver.resources.AreasResources;
import com.abacogroup.lpisgisserver.resources.BlockResources;
import com.abacogroup.lpisgisserver.resources.CataloguesResources;
import com.abacogroup.lpisgisserver.resources.EditFruitUnitsResources;
import com.abacogroup.lpisgisserver.resources.EditLandCoversResources;
import com.abacogroup.lpisgisserver.resources.EditOliveUnitsResources;
import com.abacogroup.lpisgisserver.resources.EditParcelsResources;
import com.abacogroup.lpisgisserver.resources.EditSessionsResources;
import com.abacogroup.lpisgisserver.resources.EditUnitsResources;
import com.abacogroup.lpisgisserver.resources.EditVineUnitsResources;
import com.abacogroup.lpisgisserver.resources.ExternalSourceDataResources;
import com.abacogroup.lpisgisserver.resources.FarmLandViewerResources;
import com.abacogroup.lpisgisserver.resources.FruitUnitsResources;
import com.abacogroup.lpisgisserver.resources.InternalResources;
import com.abacogroup.lpisgisserver.resources.LocationResources;
import com.abacogroup.lpisgisserver.resources.OliveUnitsResources;
import com.abacogroup.lpisgisserver.resources.ParcelsResources;
import com.abacogroup.lpisgisserver.resources.SectorResources;
import com.abacogroup.lpisgisserver.resources.StackResources;
import com.abacogroup.lpisgisserver.resources.SupportResources;
import com.abacogroup.lpisgisserver.resources.TaskManagerResources;
import com.abacogroup.lpisgisserver.resources.UnitsResources;
import com.abacogroup.lpisgisserver.resources.UtilityResources;
import com.abacogroup.lpisgisserver.resources.ViewerResources;
import com.abacogroup.lpisgisserver.resources.VineUnitsResources;
import com.abacogroup.lpisgisserver.resources.pub.PublicAreasResources;
import com.abacogroup.lpisgisserver.resources.pub.PublicBlocksResources;
import com.abacogroup.lpisgisserver.resources.pub.PublicBulkResources;
import com.abacogroup.lpisgisserver.resources.pub.PublicCataloguesResources;
import com.abacogroup.lpisgisserver.resources.pub.PublicExternalSourceDataResources;
import com.abacogroup.lpisgisserver.resources.pub.PublicFarmLandViewerResources;
import com.abacogroup.lpisgisserver.resources.pub.PublicFruitUnitsResources;
import com.abacogroup.lpisgisserver.resources.pub.PublicMatrixResources;
import com.abacogroup.lpisgisserver.resources.pub.PublicOliveUnitsResources;
import com.abacogroup.lpisgisserver.resources.pub.PublicParcelsResources;
import com.abacogroup.lpisgisserver.resources.pub.PublicSectorsResources;
import com.abacogroup.lpisgisserver.resources.pub.PublicStackResources;
import com.abacogroup.lpisgisserver.resources.pub.PublicSupportResources;
import com.abacogroup.lpisgisserver.resources.pub.PublicUnitsResources;
import com.abacogroup.lpisgisserver.resources.pub.PublicVineUnitsResources;
import com.abacogroup.territorialscopecache.cache.TerritorialScopesCache;
import com.abacogroup.territorialscopecache.cache.core.models.TerScoCacheConfig;
import com.abacogroup.tracing.dropwizard.AbacoApplication;
import com.abacogroup.tracing.jaxrs.client.AddRequestId;
import com.abacogroup.wms4j.layers.LayerDefinition;
import com.abacogroup.wms4j.resources.WmsResource;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.rabbitmq.client.Connection;

import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.jdbi3.JdbiFactory;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import io.dropwizard.migrations.MigrationsBundle;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import io.swagger.v3.oas.integration.SwaggerConfiguration;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration.Dynamic;
import jakarta.ws.rs.client.Client;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleConnection;

/**
 * For experimental purposes the comments in this project were generated with an artificial intelligence system (docify)
 */
@Slf4j
public class LpisGisServerApplication extends AbacoApplication<LpisGisServerConfiguration> {

	public static final String LPIS_SERVER_NAME = "lpis-gis-server";

	public static void main(final String[] args) {
		try {
			new LpisGisServerApplication().run(args);
		} catch (Exception e) {
			log.error("Error during run lpis-gis-server application: ", e);
			System.exit(1);
		}
	}

	@Override
	public String getName() {
		return LPIS_SERVER_NAME;
	}

	@Override
	public void initialize(final Bootstrap<LpisGisServerConfiguration> bootstrap) {

		bootstrap.addBundle(new MigrationsBundle<>() {
			@Override
			public DataSourceFactory getDataSourceFactory(LpisGisServerConfiguration configuration) {
				return configuration.getDatabase();
			}
		});

		SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
				new EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);
	}

	@Override
	public void doRun(final LpisGisServerConfiguration configuration, final Environment environment) throws Exception {

		if (configuration.getVariant() != null) {
			RabbitmqUtils.applyVariant(configuration.getVariant());
		}

		// If internal application config file is not defined the server will not start
		if (configuration.getApplicationConfigFile() == null) {
			throw new IllegalStateException("Unable to start applicationConfigFile not defined!");
		}

		Jdbi jdbi = jdbi(configuration, environment);

		ObjectMapper objectMapper = environment.getObjectMapper();
		configure(objectMapper);

		// http client
		JerseyClientConfiguration clientConfig = configuration.getJerseyClient();
		final Client client = new JerseyClientBuilder(environment).using(clientConfig).build(getName());
		client.register(new AddRequestId());

		Sso2Client sso2Client = new Sso2Client(configuration.getSso2().getAuthPhrase(), client.target(configuration.getSso2().getUrl()));

		// jdbiDAO
		DAOContainer daoContainer = buildDAOContainer(jdbi);

		PluginEnvironment pluginEnv = buildPluginEnvironment(daoContainer);

		Connection rabbitMqConnection = RabbitmqUtils.createRabbitmqConnection(configuration.getRabbitmqConfig());

		final AbstractWorkQueue<StackPayload, ?> stackMessageQueue = createStackMessageQueue(environment, jdbi, objectMapper, rabbitMqConnection);

		final WebTargetContainer webTargetContainer = new WebTargetContainer(client, configuration);

		final ServiceContainer serviceContainer = new ServiceContainer(configuration, daoContainer, pluginEnv, stackMessageQueue, webTargetContainer,
				sso2Client, client, environment.getApplicationContext().getContextPath());

		List<Object> resources = buildResources(serviceContainer);

		resources.forEach(environment.jersey()::register);

		environment.jersey().register(MultiPartFeature.class);

		createBundleInfrastructure(rabbitMqConnection, jdbi, daoContainer, serviceContainer.getInternalConfService().getInternalConfigurations(),
				configuration);

		// XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX
		TerScoCacheConfig terScoConf = TerScoCacheConfig.builder()
				.terScoBaseURL(configuration.getTerScoConfig().getTerScoBaseURL())
				.routingKEY(configuration.getTerScoConfig().getRoutingKEY())
				.queueId(configuration.getTerScoConfig().getQueueId())
				.ignoreTerSco(configuration.getTerScoConfig().isIgnoreTerSco())
				.build();
		initTerritorialScopesCache(terScoConf, environment, objectMapper, jdbi, rabbitMqConnection, client);
		// XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX

		this.initAuth(environment, configuration, sso2Client);

		this.initWmsServer(environment.jersey(), serviceContainer.getWmsService());

		this.initMultiTenant(environment);
		this.initOpenApi(environment.jersey());
		this.setupCORS(configuration, environment);
	}

	protected void afterServicesUp() {
		log.debug("application started");
	}

	protected void initAuth(Environment environment, LpisGisServerConfiguration configuration, Sso2Client sso2Client) {
		AuthUtils.installAuthFilter(
				environment,
				sso2Client,
				new SsoAuthorizer(sso2Client,
						context -> (context.equals("LPIS") && configuration.getVariant() != null ? configuration.getVariant().toUpperCase() : context)));
	}

	protected Jdbi jdbi(final LpisGisServerConfiguration configuration, final Environment environment) {
		final JdbiFactory factory = new JdbiFactory();
		final Jdbi jdbi = factory.build(environment, configuration.getDatabase(), "LpisGisServerApplication");

		jdbi.configure(AbacoJdbiConfig.class, cfg -> cfg.setTablesPrefix("lpis"));

		boolean isPostgres = jdbi.withHandle(h -> {
			String db = h.queryMetadata(DatabaseMetaData::getDatabaseProductName);
			log.info("Database connection is '{}'", db);
			return db.toLowerCase().contains("postgresql");
		});

		if (isPostgres) {
			jdbi.installPlugin(new PgJdbiPlugin());
		} else {
			OraJdbiPluginParams params = new OraJdbiPluginParams(cnn -> cnn.unwrap(OracleConnection.class), true);

			// XXX temporary remove spatial vector acceleration, probabily not necessary
			jdbi.configure(AbacoJdbiConfig.class, cfg -> cfg.setSpatalVectorAcceleration(SpatialVectorAcceleration.ENABLE_IF_POSSIBLE));

			jdbi.installPlugin(new OraJdbiPlugin(params));
		}

		return jdbi;
	}

	protected <T> T register(T service) {
		return service;
	}

	protected void initOpenApi(JerseyEnvironment jersey) {
		OpenAPI oas = new OpenAPI();
		oas.info(new Info()
				.title("ABACO") // get real data from pom.xml
				// .termsOfService("http://example.com/terms")
				.contact(new Contact().email("info@abacogroup.eu")));

		// If exist try to set swagger openapi infos from pom.xml data
		try {
			Properties prop = new Properties();
			InputStream input = LpisGisServerApplication.class.getResourceAsStream("/lpisGisServer.properties");
			prop.load(input);
			String name = prop.getProperty("api.name");
			String description = prop.getProperty("api.description");
			String version = prop.getProperty("api.version");

			oas.setInfo(new Info()
					.title("ABACO-" + name)
					.description(description)
					.version(version));

		} catch (Exception ex) {
			log.warn("Error during read openapi properties file: ", ex);
		}

		Server openApiServerLPIS = new Server();
		openApiServerLPIS.setUrl("/lpis-server-api");
		openApiServerLPIS.setDescription("Main Variant LPIS GIS Server");
		oas.addServersItem(openApiServerLPIS);
		Server openApiServerFruit = new Server();
		openApiServerFruit.setUrl("/fruit-gis-server");
		openApiServerFruit.setDescription("Fruit Units Variant LPIS GIS Server");
		oas.addServersItem(openApiServerFruit);
		Server openApiServerOlive = new Server();
		openApiServerOlive.setUrl("/olive-gis-server");
		openApiServerOlive.setDescription("Olive Units Variant LPIS GIS Server");
		oas.addServersItem(openApiServerOlive);
		Server openApiServerVine = new Server();
		openApiServerVine.setUrl("/vine-gis-server");
		openApiServerVine.setDescription("Vine Units Variant LPIS GIS Server");
		oas.addServersItem(openApiServerVine);

		SwaggerConfiguration oasConfig = new SwaggerConfiguration()
				.openAPI(oas)
				.prettyPrint(true)
				.resourcePackages(Stream.of("com.abacogroup.lpisgisserver")
						.collect(Collectors.toSet()));

		jersey.register(new OpenApiResource()
				.openApiConfiguration(oasConfig));
	}

	private void setupCORS(LpisGisServerConfiguration configuration, Environment environment) {
		if (!configuration.isCors()) {
			log.info("CORS is disabled");
			return;
		}

		log.info("CORS is enabled");

		Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,DELETE");

		// OPTIONS pre-flight request will be served by the filter ONLY and not
		// passed ahead
		// cors.setInitParameter(CrossOriginFilter.CHAIN_PREFLIGHT_PARAM, "false");

		// Add URL mapping
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

	private void initMultiTenant(Environment environment) {
		environment.jersey().register(new MultitenantFilter("tenant"));
	}

	private void configure(ObjectMapper objectMapper) {
		objectMapper
				.setTimeZone(TimeZone.getDefault())
				.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

		SimpleModule module = new SimpleModule("custom-deserializers", Version.unknownVersion());
		module.addSerializer(Geometry.class, new WKTGeometrySerializer());
		module.addDeserializer(Geometry.class, new WKTGeometryDeserializer());
		objectMapper.registerModule(module);

		SimpleModule absoluteDateModule = new SimpleModule("custom-deserializers", Version.unknownVersion());
		absoluteDateModule.addSerializer(AbsoluteDate.class, new AbsoluteDateSerializer());
		objectMapper.registerModule(absoluteDateModule);
	}

	private void createBundleInfrastructure(Connection rabbitmqConnection, Jdbi jdbi, DAOContainer daoContainer,
			Map<String, InternalConfig> internalConfigurations, LpisGisServerConfiguration configuration) {
		if (rabbitmqConnection == null) {
			log.info("NOT CONNECTED TO RABBITMQ; bundles infrastructure is disabled");
			return;
		}

		final String serviceName = configuration.getVariant() != null ? configuration.getVariant() : LPIS_SERVER_NAME;

		try {
			ListenerBuilder.newBuilder(rabbitmqConnection)
					.withConfigDataConsumer(ConfigDataConsumerBuilder.newBuilder(jdbi, rabbitmqConnection)
							.route(serviceName)
							.processors(
									new InternalConfigMessageProcessor(daoContainer),
									new ExternalConfigMessageProcessor(daoContainer),
									new AdditionalExternalLinksMessageProcessor(daoContainer),
									new LandCoversCodeMessageProcessor(daoContainer),
									new LandCoverConfigMessageProcessor(daoContainer),
									new LandUsesCodeMessageProcessor(daoContainer),
									new EditCategoriesCodeMessageProcessor(daoContainer),
									new ImportDataMessageProcessor(daoContainer),
									new CatalogueMessageProcessor(daoContainer),
									new LayerMessageProcessor(daoContainer),
									new MatrixMessageProcessor(daoContainer),
									new AnomalyCategoriesMessageProcessor(daoContainer),
									new I18nMessageProcessor(daoContainer),
									new MatrixMetadataMessageProcessor(daoContainer),
									new CampaignMessageProcessor(daoContainer),
									new UnitsMessageProcessor(daoContainer),
									new VineUnitMessageProcessor(daoContainer),
									new VineyardDoigtLinkMessageProcessor(daoContainer),
									new OliveUnitMessageProcessor(daoContainer),
									new FruitUnitMessageProcessor(daoContainer),
									new NewMatrixMessageProcessor(daoContainer))
							.build())
					.withNewTenantEventConsumer(NewTenantEventConsumerBuilder.newBuilder(jdbi).route(serviceName)
							.processors(
									new InternalConfigTenantMessageProcessor(daoContainer, internalConfigurations),
									new CatalogueTenantMessageProcessor(daoContainer),
									new I18nTenantMessageProcessor(daoContainer))
							.build())
					.buildListener()
					.start();

			InitService bundleInitService = BundleInitServiceBuilder
					.producer(this.register(new BundleInitServiceProducer(rabbitmqConnection)))
					.configLocation(configuration.getBundlesConfigLocation())
					// .baseTempDir()
					.build();
			bundleInitService.start();
		} catch (Exception e) {
			throw new IllegalStateException("Error starting rabbitmq listener", e);
		}
	}

	/**
	 * Init embdedd WMS server layer
	 *
	 * @param jersey
	 * @param wmsService
	 */
	private void initWmsServer(JerseyEnvironment jersey, WmsService wmsService) {
		WmsResource wms = new WmsResource();

		List<LayerDefinition> layers = wmsService.getInternalWMSLayers();
		layers.forEach(wms::addLayer);

		jersey.register(wms);
	}

	private AbstractWorkQueue<StackPayload, ?> createStackMessageQueue(Environment environment, Jdbi jdbi, ObjectMapper objectMapper,
			Connection rabbitMqConnection) throws IOException {

		if (rabbitMqConnection == null)
			return null;

		var consumer = new RabbitMqPublisher<StackPayload>(rabbitMqConnection) {

			@Override
			public String getRoutingKey(StackPayload arg0) {
				return RabbitmqUtils.ROUTING_KEY;
			}

			@Override
			public String getExchangeName() {
				return getName();
			}
		};

		consumer.setObjectMapper(objectMapper);

		RabbitMqPublisherWorkQueue<StackPayload> queue = RabbitMqPublisherWorkQueue
				.builder(RabbitmqUtils.getQueueId(), new JdbiRepository(jdbi), StackPayload.class)
				.withConsumer(consumer)
				.withMetricsRegistry(environment.metrics())
				.build();

		queue.start();

		return queue;
	}

	private PluginEnvironment buildPluginEnvironment(DAOContainer daoContainer) {
		final AreaProvider areaProvider = new AreaProvider(daoContainer);
		final SectorProvider sectorProvider = new SectorProvider(daoContainer);
		final BlockProvider blockProvider = new BlockProvider(daoContainer);
		final ParcelProvider parcelProvider = new ParcelProvider(daoContainer);
		final UnitProvider unitProvider = new UnitProvider(daoContainer);

		final ProvidersContainer providersContainer = ProvidersContainer.builder()
				.areaProvider(areaProvider)
				.sectorProvider(sectorProvider)
				.blockProvider(blockProvider)
				.parcelProvider(parcelProvider)
				.unitProvider(unitProvider)
				.build();

		return PluginEnvironment
				.builder()
				.connections(null)
				.pluginsContainer(providersContainer)
				.build();
	}

	private DAOContainer buildDAOContainer(Jdbi jdbi) {

		return DAOContainer.builder()
				.additionalLayersDAO(jdbi.onDemand(AdditionalLayersDAO.class))
				.anomalyCategoriesDAO(jdbi.onDemand(AnomalyCategoriesDAO.class))
				.areasDAO(jdbi.onDemand(AreasDAO.class))
				.blockDAO(jdbi.onDemand(BlockDAO.class))
				.cachePartyParcelsDAO(jdbi.onDemand(CachePartyParcelsDAO.class))
				.cacheTempParcelsDAO(jdbi.onDemand(CacheTempParcelsDAO.class))
				.cataloguesDAO(jdbi.onDemand(CataloguesDAO.class))
				.configDAO(jdbi.onDemand(ConfigDAO.class))
				.editFruitUnitsDAO(jdbi.onDemand(EditFruitUnitsDAO.class))
				.editLandCoversDAO(jdbi.onDemand(EditLandCoversDAO.class))
				.editOliveUnitsDAO(jdbi.onDemand(EditOliveUnitsDAO.class))
				.editParcelsDAO(jdbi.onDemand(EditParcelsDAO.class))
				.editSessionsDAO(jdbi.onDemand(EditSessionsDAO.class))
				.editUnitsDAO(jdbi.onDemand(EditUnitsDAO.class))
				.editVineUnitsDAO(jdbi.onDemand(EditVineUnitsDAO.class))
				.externalConfigDAO(jdbi.onDemand(ExternalConfigDAO.class))
				.externalSourceDataDAO(jdbi.onDemand(ExternalSourceDataDAO.class))
				.fruitUnitsDAO(jdbi.onDemand(FruitUnitsDAO.class))
				.i18nDAO(jdbi.onDemand(I18nDAO.class))
				.infoGisDAO(jdbi.onDemand(InfoGisDAO.class))
				.internalDAO(jdbi.onDemand(InternalDAO.class))
				.landCoverConfigsDAO(jdbi.onDemand(LandCoverConfigsDAO.class))
				.landCoversDAO(jdbi.onDemand(LandCoversDAO.class))
				.landCoversDetailsDAO(jdbi.onDemand(LandCoversDetailsDAO.class))
				.lockParcelsDAO(jdbi.onDemand(LockParcelsDAO.class))
				.layerDAO(jdbi.onDemand(LayerDAO.class))
				.matrixClassDAO(jdbi.onDemand(MatrixClassDAO.class))
				.matrixClassDetailsDAO(jdbi.onDemand(MatrixClassDetailsDAO.class))
				.matrixClassLandcoversDAO(jdbi.onDemand(MatrixClassLandcoversDAO.class))
				.matrixClassLandUsesDAO(jdbi.onDemand(MatrixClassLandUsesDAO.class))
				.matrixClassMetadataDAO(jdbi.onDemand(MatrixClassMetadataDAO.class))
				.matrixCompatDAO(jdbi.onDemand(MatrixCompatDAO.class))
				.matrixDAO(jdbi.onDemand(MatrixDAO.class))
				.matrixLandCoverDAO(jdbi.onDemand(MatrixLandCoverDAO.class))
				.matrixLandCoversMetadataDAO(jdbi.onDemand(MatrixLandCoversMetadataDAO.class))
				.matrixLandUsesDAO(jdbi.onDemand(MatrixLandUsesDAO.class))
				.matrixLandUsesMetadataDAO(jdbi.onDemand(MatrixLandUsesMetadataDAO.class))
				.oliveUnitsDAO(jdbi.onDemand(OliveUnitsDAO.class))
				.parcelsDAO(jdbi.onDemand(ParcelsDAO.class))
				.parcelDetailsDAO(jdbi.onDemand(ParcelDetailsDAO.class))
				.sectorAreasDAO(jdbi.onDemand(SectorAreasDAO.class))
				.sectorDAO(jdbi.onDemand(SectorDAO.class))
				.sectorDecodesDAO(jdbi.onDemand(SectorDecodesDAO.class))
				.stackFruitUnitsDAO(jdbi.onDemand(StackFruitUnitsDAO.class))
				.stackLandCoversDAO(jdbi.onDemand(StackLandCoversDAO.class))
				.stackOliveUnitsDAO(jdbi.onDemand(StackOliveUnitsDAO.class))
				.stackParcelsDAO(jdbi.onDemand(StackParcelsDAO.class))
				.stacksDAO(jdbi.onDemand(StacksDAO.class))
				.stackVineUnitsDAO(jdbi.onDemand(StackVineUnitsDAO.class))
				.supportDAO(jdbi.onDemand(SupportDAO.class))
				.territorialScopeDAO(jdbi.onDemand(TerritorialScopeDAO.class))
				.totalLandCoversDAO(jdbi.onDemand(TotalLandCoversDAO.class))
				.totalParcelsDAO(jdbi.onDemand(TotalParcelsDAO.class))
				.unitCodesDAO(jdbi.onDemand(UnitCodesDAO.class))
				.unitsDAO(jdbi.onDemand(UnitsDAO.class))
				.vineUnitsDAO(jdbi.onDemand(VineUnitsDAO.class))
				.wMSLayersDAO(jdbi.onDemand(WMSLayersDAO.class))
				.wmsParcelsFilterDAO(jdbi.onDemand(WMSParcelsFilterDAO.class))
				.wmsServerAreasDAO(jdbi.onDemand(WMSServerAreasDAO.class))
				.build();

	}

	private List<Object> buildResources(ServiceContainer serviceContainer) {

		List<Object> resources = new ArrayList<>();
		resources.add(new UtilityResources());

		resources.add(new SupportResources(serviceContainer.getSupportService(), serviceContainer.getAdditionalLayersService()));
		resources.add(new LocationResources(serviceContainer.getLocationService()));

		resources.add(new EditSessionsResources(serviceContainer.getEditSessionsService()));
		resources.add(new EditParcelsResources(serviceContainer.getEditSessionSupportService(), serviceContainer.getEditParcelsService()));
		resources.add(new EditLandCoversResources(serviceContainer.getEditSessionSupportService(), serviceContainer.getEditLandCoversService()));
		resources.add(new EditVineUnitsResources(serviceContainer.getEditSessionSupportService(), serviceContainer.getEditVineUnitsService()));
		resources.add(new EditOliveUnitsResources(serviceContainer.getEditSessionSupportService(), serviceContainer.getEditOliveUnitsService()));
		resources.add(new EditFruitUnitsResources(serviceContainer.getEditSessionSupportService(), serviceContainer.getEditFruitUnitsService()));
		resources.add(new EditUnitsResources(serviceContainer.getEditSessionSupportService(), serviceContainer.getEditUnitsService()));

		resources.add(new SectorResources(serviceContainer.getSectorService()));
		resources.add(new BlockResources(serviceContainer.getBlockService()));
		resources.add(new ParcelsResources(serviceContainer.getParcelsService()));
		resources.add(new AreasResources(serviceContainer.getAreasService()));
		resources.add(new ExternalSourceDataResources(serviceContainer.getExternalParcelsSourceService()));
		resources.add(new CataloguesResources(serviceContainer.getCataloguesService()));
		resources.add(new StackResources(serviceContainer.getStackService()));

		resources.add(new FarmLandViewerResources(serviceContainer.getFarmLandViewerService(), serviceContainer.getViewerService()));
		resources.add(new ViewerResources(serviceContainer.getViewerService()));

		resources.add(new UnitsResources(serviceContainer.getUnitsService()));
		resources.add(new VineUnitsResources(serviceContainer.getVineUnitsService()));
		resources.add(new OliveUnitsResources(serviceContainer.getOliveUnitsService()));
		resources.add(new FruitUnitsResources(serviceContainer.getFruitUnitsService()));
		resources.add(new PublicUnitsResources(serviceContainer.getUnitsSummaryV1Service(), serviceContainer.getPublicParcelService()));

		resources.add(new AnomaliesResources(serviceContainer.getAnomaliesService()));
		resources.add(new TaskManagerResources(serviceContainer.getTaskManagerService()));

		resources.add(new PublicMatrixResources(serviceContainer.getMatrixV1Service()));
		resources.add(new PublicParcelsResources(serviceContainer.getPublicParcelService()));
		resources.add(new PublicSectorsResources(serviceContainer.getPublicSectorsService()));
		resources.add(new PublicBlocksResources(serviceContainer.getPublicBlocksService()));
		resources.add(new PublicSupportResources(serviceContainer.getPublicSupportService(), serviceContainer.getAdditionalLayersServiceV1()));
		resources.add(new PublicBulkResources(serviceContainer.getBulkV1Service()));
		resources.add(new PublicVineUnitsResources(serviceContainer.getVineUnitsV1Service()));
		resources.add(new PublicOliveUnitsResources(serviceContainer.getOliveUnitsV1Service()));
		resources.add(new PublicFruitUnitsResources(serviceContainer.getFruitUnitsV1Service()));
		resources.add(new PublicFarmLandViewerResources(serviceContainer.getFarmLandViewerV1Service()));
		resources.add(new PublicStackResources(serviceContainer.getStackV1Service()));
		resources.add(new PublicExternalSourceDataResources(serviceContainer.getCxfV1Service()));
		resources.add(new PublicAreasResources(serviceContainer.getAreaV1Service()));
		resources.add(new PublicCataloguesResources(serviceContainer.getCataloguesV1Service()));

		// #######################################################################
		// ### Unauthenticated not exposed Internal API
		resources.add(new InternalResources(serviceContainer.getInternalService()));
		// #######################################################################

		return resources;
	}

	private void initTerritorialScopesCache(TerScoCacheConfig terScoCacheConfig, Environment environment, ObjectMapper objectMapper, Jdbi jdbi,
			Connection rabbitMqConnection, Client client) throws TimeoutException, IOException {

		TerritorialScopesCache terScoCache = this.register(
				new TerritorialScopesCache(terScoCacheConfig, environment, jdbi, client, rabbitMqConnection, objectMapper));
		terScoCache.initDWTask();
	}

}
