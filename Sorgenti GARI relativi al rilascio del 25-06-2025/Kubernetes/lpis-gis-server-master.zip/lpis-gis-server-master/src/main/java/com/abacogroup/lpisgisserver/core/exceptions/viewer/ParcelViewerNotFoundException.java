package com.abacogroup.lpisgisserver.core.exceptions.viewer;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class ParcelViewerNotFoundException extends AbstractException {

	private static final long serialVersionUID = -7103300253805629944L;

	private static final ErrorCode ERROR_CODE = ErrorCode.PARCEL_VIEWER_NOT_FOUND;

	public ParcelViewerNotFoundException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new ParcelViewerNotFoundExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Parcel viewer not found")
	public static class ParcelViewerNotFoundExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -3315256569191930040L;

		public ParcelViewerNotFoundExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
