package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.PolesWeavingNTT;
import com.abacogroup.lpisgisserver.resources.res.units.PolesWeaving;

@Mapper
public interface PolesWeavingMapper {

	PolesWeavingMapper INSTANCE = Mappers.getMapper(PolesWeavingMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	PolesWeaving entityToDto(PolesWeavingNTT entity);
	
	@Mapping(target = "flVisible", expression = "java(dto.getVisible() ? 1 : 0)")
	@Mapping(target = "typeCode", ignore = true)
	PolesWeavingNTT dtoToEntity(PolesWeaving dto);
}
