package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineAptitudeNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineUnitDetailsNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface EditVineUnitsDAO extends Transactional<EditVineUnitsDAO>, EnhancedSqlObject {

	// ###############################################################
	// To get VineAptitudes check vineUnit validity by joining 
	// the lpis_unit_vineunit_details table
	// ###############################################################

	@SqlQuery("§select_nextval(lpis_edit_unit_vineunit_sequence)§")
	Long nextEditVineUnitDetailPkidVal();

	@SqlQuery("§select_nextval(lpis_edit_unit_vine_aptitudes_sequence)§")
	Long nextEditVineUnitAptitudePkidVal();
	
	@SqlQuery("select coalesce(min(unit_id), 0) - 1 from lpis_edit_unit_vineunit where unit_id < 1")
	Long nextNewVineUnitIdVal();	
	
	@SqlQuery("select coalesce(min(aptitude_id), 0) - 1 from lpis_edit_unit_vine_aptitudes where aptitude_id < 1")
	Long nextNewVineAptitudeIdVal();
	
	@SqlUpdate("INSERT INTO lpis_edit_unit_vineunit (id, session_uuid, edit_land_cover_id, unit_id, "
			+ "    type_code, unit_code, variety_code, area_sqm, planting_day, planting_day_precision, eradicate_day, "
			+ "    distance_on_the_row_cm, distance_between_rows_cm, stumps_number, stumps_density_100, "
			+ "    farming_form_code, irrigation_code, product_destination_code, variation_type_code, "
			+ "    cultivation_status_code, terracing_code, failures_perc, soil_layering_perc, altitude_above_sea_level, "
			+ "    poles_weaving_code, poles_distance_cm, support_wires_code, header_anchoring_code, poles_header_code, "
			+ "    external_code, edit_status, fl_deletable, parent_unit_code) "
			+ "values (:editId, :sessionId, :editLandCoverId, :unitId, "
			+ "    :typeCode, :unitCode, :variety.code, :areaSqm, :plantingDay, :plantingDayPrecision, :eradicateDay, "
			+ "    :distanceOnTheRowCM, :distanceBetweenRowsCM, :stumpsNumber, :stumpsDensity100, "
			+ "    :farmingForm.code, :irrigation.code, :productDestination.code, :variationType.code, "
			+ "    :cultivationStatus.code, :terracing.code, :failuresPerc, :soilLayeringPerc, :altitudeAboveSeaLevel, "
			+ "    :polesWeaving.code, :polesDistanceCM, :supportWires.code, :headerAnchoring.code, :polesHeader.code, "
			+ "    :externalCode, :editStatus, :flDeletable, :parentUnitCode) "
			+ "")
	void insertEditVineUnitDetail(@BindBean ServiceSupportEnv env, @BindBean VineUnitDetailsNTT vineUnitDetailsNTT);

	@SqlUpdate("INSERT INTO lpis_edit_unit_vine_aptitudes (id, session_uuid, edit_unit_id, aptitude_id, "
			+ "    doigt_code, day_from, day_from_precision, day_to, fl_prevent_typology, fl_prevent_claim, "			
			+ "   fl_prevent_suitability, edit_status, vineyard_code) "
			+ "values (:editId, :sessionId, :editUnitId, :aptitudeId, "
			+ "   :doigt.code, :dayFrom, :dayFromPrecision, :dayTo, :flPreventTypology, :flPreventClaim, "
			+ "   :flPreventSuitability, :editStatus, :vineyard.code) "
			+ "")
	void insertEditVineAptitude(@BindBean ServiceSupportEnv env, @BindBean VineAptitudeNTT vineAptitudeNTT);

	@SqlUpdate("UPDATE lpis_edit_unit_vineunit \n"
			+ "SET type_code = :typeCode, unit_code = :unitCode, variety_code = :variety.code, "
			+ "area_sqm = :areaSqm, planting_day = :plantingDay, planting_day_precision = :plantingDayPrecision, eradicate_day = :eradicateDay, "
	        + "distance_on_the_row_cm = :distanceOnTheRowCM, distance_between_rows_cm = :distanceBetweenRowsCM, stumps_number = :stumpsNumber, "
	        + "stumps_density_100 = :stumpsDensity100, farming_form_code = :farmingForm.code, irrigation_code = :irrigation.code, "
	        + "product_destination_code = :productDestination.code, variation_type_code = :variationType.code, "
	        + "cultivation_status_code = :cultivationStatus.code, terracing_code = :terracing.code, failures_perc = :failuresPerc, "
	        + "soil_layering_perc = :soilLayeringPerc, altitude_above_sea_level = :altitudeAboveSeaLevel, "
	        + "poles_weaving_code = :polesWeaving.code, poles_distance_cm = :polesDistanceCM, support_wires_code = :supportWires.code, "
	        + "header_anchoring_code = :headerAnchoring.code, poles_header_code = :polesHeader.code, "
	        + "external_code = :externalCode, edit_status = :editStatus, fl_deletable = :flDeletable, parent_unit_code = :parentUnitCode "
	        + "WHERE unit_id = :unitId and session_uuid = :sessionId ")
	void updateEditVineUnitDetail(@Bind("sessionId") String sessionId, @BindBean VineUnitDetailsNTT vineUnitDetailsNTT);
	
	@SqlUpdate("UPDATE lpis_edit_unit_vine_aptitudes \n"
			+ "SET doigt_code = :doigt.code, day_from = :dayFrom, day_from_precision = :dayFromPrecision, "
			+ "day_to = :dayTo, fl_prevent_typology = :flPreventTypology, fl_prevent_claim = :flPreventClaim, "
			+ "fl_prevent_suitability = :flPreventSuitability, edit_status = :editStatus, vineyard_code = :vineyard.code "
			+ "WHERE aptitude_id = :aptitudeId AND session_uuid = :sessionId ")
	void updateEditVineAptitude(@Bind("sessionId") String sessionId, @BindBean VineAptitudeNTT vineAptitudeNTT);
	
	@SqlQuery("select evu.id as edit_id, \n"
			+ "    evu.edit_land_cover_id, \n"
			+ "    lelc.land_cover_id, \n"
			+ "    evu.unit_id, \n"
			+ "    evu.unit_code, \n"
			+ "    evu.parent_unit_code, \n"
			+ "    evu.type_code, \n"
			+ "    evu.variety_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_variety', 'code', luv.type_code||':'||luv.code, :lang)§ as variety_description, \n"
			+ "    luv.fl_visible as variety_fl_visible, \n"
			+ "    evu.area_sqm, \n"
			+ "    evu.planting_day, \n"
			+ "    evu.planting_day_precision, \n"
			+ "    evu.eradicate_day, \n"
			+ "    evu.distance_on_the_row_cm, \n"
			+ "    evu.distance_between_rows_cm, \n"
			+ "    evu.stumps_number, \n"
			+ "    evu.stumps_density_100, \n"
			+ "    evu.farming_form_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_farming_form', 'code', luff.type_code||':'||luff.code, :lang)§ as farming_form_description, \n"
			+ "    luff.fl_visible as farming_form_fl_visible, \n"
			+ "    evu.irrigation_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_irrigation', 'code', lui.type_code||':'||lui.code, :lang)§ as irrigation_description, \n"
			+ "    lui.fl_visible as irrigation_fl_visible, \n"
			+ "    evu.product_destination_code , \n"
			+ "    §i18n(:tenantId, 'lpis_unit_product_destination', 'code', lupd.type_code||':'||lupd.code, :lang)§ as product_destination_description, \n"
			+ "    lupd.fl_visible as product_destination_fl_visible, \n"
			+ "    evu.variation_type_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_variation_type', 'code', luvt.type_code||':'||luvt.code, :lang)§ as variation_type_description, \n"
			+ "    luvt.fl_visible as variation_type_fl_visible, \n"
			+ "    evu.cultivation_status_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_cultivation_status', 'code', lucs.type_code||':'||lucs.code, :lang)§ as cultivation_status_description, \n"
			+ "    lucs.fl_visible as cultivation_status_fl_visible, \n"
			+ "    evu.terracing_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_terracing', 'code', lut.type_code||':'||lut.code, :lang)§ as terracing_description, \n"
			+ "    lut.fl_visible terracing_fl_visible, \n"
			+ "    evu.failures_perc, \n"
			+ "    evu.soil_layering_perc, \n"
			+ "    evu.altitude_above_sea_level, \n"
			+ "    evu.poles_weaving_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_poles_weaving', 'code', lupw.type_code||':'||lupw.code, :lang)§ as poles_weaving_description, \n"
			+ "    lupw.fl_visible as poles_weaving_fl_visible, \n"
			+ "    evu.poles_distance_cm, \n"
			+ "    evu.support_wires_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_support_wires', 'code', lusw.type_code||':'||lusw.code, :lang)§ as support_wires_description, \n"
			+ "    lusw.fl_visible as support_wires_fl_visible, \n"
			+ "    evu.header_anchoring_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_header_anchoring', 'code', luha.type_code||':'||luha.code, :lang)§ as header_anchoring_description, \n"
			+ "    luha.fl_visible as header_anchoring_fl_visible, \n"
			+ "    evu.poles_header_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_poles_header', 'code', luph.type_code||':'||luph.code, :lang)§ as poles_header_description, \n"
			+ "    luph.fl_visible as poles_header_fl_visible, \n"
			+ "    evu.external_code, \n"
			+ "    evu.edit_status, \n"
			+ "    es.dt_last_lock as lastUpdate,\n"
			+ "    es.user_id as lastUpdateUser, \n"
			+ "    evu.fl_deletable \n"
			+ "from \n"
			+ "    lpis_edit_sessions es \n"
			+ "    inner join lpis_edit_unit_vineunit evu on es.uuid = evu.session_uuid \n"
			+ "    inner join lpis_edit_land_covers lelc on lelc.session_uuid = evu.session_uuid and lelc.pkid = evu.edit_land_cover_id  \n"
			+ "    left join lpis_unit_variety luv on luv.code = evu.variety_code and luv.tenant_id = :tenantId and luv.type_code = evu.type_code \n"
			+ "    left join lpis_unit_variation_type luvt on luvt.code = evu.variation_type_code and luvt.tenant_id = :tenantId and luvt.type_code = evu.type_code \n"
			+ "    left join lpis_unit_farming_form luff on luff.code = evu.farming_form_code and luff.tenant_id = :tenantId and luff.type_code = evu.type_code \n"
			+ "    left join lpis_unit_irrigation lui on lui.code = evu.irrigation_code and lui.tenant_id = :tenantId and lui.type_code = evu.type_code \n"
			+ "    left join lpis_unit_product_destination lupd on lupd.code = evu.product_destination_code and lupd.tenant_id = :tenantId and lupd.type_code = evu.type_code \n"
			+ "    left join lpis_unit_cultivation_status lucs on lucs.code = evu.cultivation_status_code and lucs.tenant_id = :tenantId and lucs.type_code = evu.type_code \n"
			+ "    left join lpis_unit_terracing lut on lut.code = evu.terracing_code and lut.tenant_id = :tenantId and lut.type_code = evu.type_code \n"
			+ "    left join lpis_unit_poles_weaving lupw on lupw.code = evu.poles_weaving_code and lupw.tenant_id = :tenantId and lupw.type_code = evu.type_code \n"
			+ "    left join lpis_unit_poles_header luph on luph.code = evu.poles_header_code and luph.tenant_id = :tenantId and luph.type_code = evu.type_code \n"
			+ "    left join lpis_unit_support_wires lusw on lusw.code = evu.support_wires_code and lusw.tenant_id = :tenantId and lusw.type_code = evu.type_code \n"
			+ "    left join lpis_unit_header_anchoring luha on luha.code = evu.header_anchoring_code and luha.tenant_id = :tenantId and luha.type_code = evu.type_code \n"
			+ "where \n"
			+ "    es.uuid = :sessionId \n"
			+ "    and evu.type_code = 'VINE_UNIT' \n"
			+ "    and (:landCoverId is null or lelc.land_cover_id = :landCoverId) \n"
			+ "    and (:vineUnitId is null or :vineUnitId = evu.unit_id) \n"
			+ "    and (:includeEradicate = 1 or :referenceDate < evu.eradicate_day) \n"
			+ "    and (coalesce(<excludes>, null) is null or evu.edit_status not in (<excludes>))"
			+ "    and (coalesce(<excludes>, null) is null or lelc.edit_status not in (<excludes>))"
			+ "order by case when length(evu.unit_code) < 15 then substr(('000000000000000'||evu.unit_code), length('000000000000000'||evu.unit_code) -14, length('000000000000000'||evu.unit_code)) else evu.unit_code end, evu.unit_id asc \n"
			+ "")
	@RegisterBeanMapper(VineUnitDetailsNTT.class)
	List<VineUnitDetailsNTT> findInEditVineUnitsBySessionId(@BindBean ServiceSupportEnv env, @Bind("landCoverId") Long landCoverId,
			@Bind("vineUnitId") Long vineUnitId, 
			@BindList(value = "excludes", onEmpty = BindList.EmptyHandling.NULL_STRING) List<EditStatus> excludes,
			@Bind("includeEradicate") Integer includeEradicate);	
	
	
	default List<VineUnitDetailsNTT> findInEditVineUnitsBySessionId(ServiceSupportEnv env, Long landCoverId, Long vineUnitId, List<EditStatus> excludes){
		return findInEditVineUnitsBySessionId(env, landCoverId, vineUnitId, excludes, 0);
	}
	
	
	@SqlQuery("SELECT u.land_cover_id, \n"
			+ "    vd.unit_code, \n"
			+ "    vd.parent_unit_code, \n"
			+ "    vd.unit_id, \n"
			+ "    vd.pkid as unitDetailId, \n"
			+ "    u.type_code, \n"
			+ "    luv.code as variety_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_variety', 'code', luv.type_code||':'||luv.code, :lang)§ as variety_description, \n"
			+ "    luv.fl_visible as variety_fl_visible, \n"
			+ "    vd.area_sqm, \n"
			+ "    vd.planting_day, \n"
			+ "    vd.planting_day_precision, \n"
			+ "    vd.eradicate_day, \n"
			+ "    vd.distance_on_the_row_cm, \n"
			+ "    vd.distance_between_rows_cm, \n"
			+ "    vd.stumps_number, \n"
			+ "    vd.stumps_density_100, \n"
			+ "    luff.code as farming_form_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_farming_form', 'code', luff.type_code||':'||luff.code, :lang)§ as farming_form_description, \n"
			+ "    luff.fl_visible as farming_form_fl_visible, \n"
			+ "    lui.code as irrigation_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_irrigation', 'code', lui.type_code||':'||lui.code, :lang)§ as irrigation_description, \n"
			+ "    lui.fl_visible as irrigation_fl_visible, \n"
			+ "    lupd.code as product_destination_code , \n"
			+ "    §i18n(:tenantId, 'lpis_unit_product_destination', 'code', lupd.type_code||':'||lupd.code, :lang)§ as product_destination_description, \n"
			+ "    lupd.fl_visible as product_destination_fl_visible, \n"
			+ "    luvt.code as variation_type_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_variation_type', 'code', luvt.type_code||':'||luvt.code, :lang)§ as variation_type_description, \n"
			+ "    luvt.fl_visible as variation_type_fl_visible, \n"
			+ "    lucs.code as cultivation_status_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_cultivation_status', 'code', lucs.type_code||':'||lucs.code, :lang)§ as cultivation_status_description, \n"
			+ "    lucs.fl_visible as cultivation_status_fl_visible, \n"
			+ "    lut.code as terracing_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_terracing', 'code', lut.type_code||':'||lut.code, :lang)§ as terracing_description, \n"
			+ "    lut.fl_visible terracing_fl_visible, \n"
			+ "    vd.failures_perc, \n"
			+ "    vd.soil_layering_perc, \n"
			+ "    vd.altitude_above_sea_level, \n"
			+ "    lupw.code as poles_weaving_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_poles_weaving', 'code', lupw.type_code||':'||lupw.code, :lang)§ as poles_weaving_description, \n"
			+ "    lupw.fl_visible as poles_weaving_fl_visible, \n"
			+ "    vd.poles_distance_cm, \n"
			+ "    lusw.code as support_wires_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_support_wires', 'code', lusw.type_code||':'||lusw.code, :lang)§ as support_wires_description, \n"
			+ "    lusw.fl_visible as support_wires_fl_visible, \n"
			+ "    luha.code as header_anchoring_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_header_anchoring', 'code', luha.type_code||':'||luha.code, :lang)§ as header_anchoring_description, \n"
			+ "    luha.fl_visible as header_anchoring_fl_visible, \n"
			+ "    luph.code as poles_header_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_poles_header', 'code', luph.type_code||':'||luph.code, :lang)§ as poles_header_description, \n"
			+ "    luph.fl_visible as poles_header_fl_visible, \n"
			+ "    vd.external_code, \n"
			+ "    'NOT_IN_EDIT' as edit_status, \n"
			+ "    vd.dt_insert as lastUpdate, \n"
			+ "    vd.user_id_insert as lastUpdateUser, \n"
			+ "    0 as flDeletable, \n"
			+ "    vd.day_from, \n"
			+ "    vd.day_to \n"
			+ "from "
			+ "    lpis_lock_parcels lp \n"
			+ "    inner join lpis_parcel_land_covers lc on lc.parcel_id = lp.parcel_id \n"
			+ "    inner join lpis_parcel_lc_details lcd on lc.id = lcd.land_cover_id \n"
			+ "    inner join lpis_parcel_lc_units u on u.land_cover_id = lc.id \n"
			+ "    inner join lpis_unit_vineunit_details vd on u.id = vd.unit_id \n"
			+ "    left join lpis_unit_variety luv on luv.code = vd.variety_code and luv.tenant_id = :tenantId and luv.type_code = u.type_code \n"
			+ "    left join lpis_unit_variation_type luvt on luvt.code = vd.variation_type_code and luvt.tenant_id = :tenantId and luvt.type_code = u.type_code \n"
			+ "    left join lpis_unit_farming_form luff on luff.code = vd.farming_form_code and luff.tenant_id = :tenantId and luff.type_code = u.type_code \n"
			+ "    left join lpis_unit_irrigation lui on lui.code = vd.irrigation_code and lui.tenant_id = :tenantId and lui.type_code = u.type_code \n"
			+ "    left join lpis_unit_product_destination lupd on lupd.code = vd.product_destination_code and lupd.tenant_id = :tenantId and lupd.type_code = u.type_code \n"
			+ "    left join lpis_unit_cultivation_status lucs on lucs.code = vd.cultivation_status_code and lucs.tenant_id = :tenantId and lucs.type_code = u.type_code \n"
			+ "    left join lpis_unit_terracing lut on lut.code = vd.terracing_code and lut.tenant_id = :tenantId and lut.type_code = u.type_code \n"
			+ "    left join lpis_unit_poles_weaving lupw on lupw.code = vd.poles_weaving_code and lupw.tenant_id = :tenantId and lupw.type_code = u.type_code \n"
			+ "    left join lpis_unit_poles_header luph on luph.code = vd.poles_header_code and luph.tenant_id = :tenantId and luph.type_code = u.type_code \n"
			+ "    left join lpis_unit_support_wires lusw on lusw.code = vd.support_wires_code and lusw.tenant_id = :tenantId and lusw.type_code = u.type_code \n"
			+ "    left join lpis_unit_header_anchoring luha on luha.code = vd.header_anchoring_code and luha.tenant_id = :tenantId and luha.type_code = u.type_code \n"
			+ "where \n"
			+ "    (:landCoverId is null or u.land_cover_id = :landCoverId) \n"
			+ "    and (:landCoverPkid is null or lcd.pkid = :landCoverPkid) \n"   
			+ "    and u.type_code = 'VINE_UNIT' \n"
			+ "    and not exists (select 1 from lpis_edit_unit_vineunit leuv where leuv.session_uuid = :sessionId and leuv.unit_id = u.id) \n"
			+ "    and (:vineUnitId is null or :vineUnitId = u.id) \n"
			+ "    and (:landCoverPkid is not null or :referenceDate between lcd.day_from and lcd.day_to) \n"  
			+ "    and :referenceDate between vd.day_from and vd.day_to \n"
			+ "    and vd.planting_day <= :referenceDate and :referenceDate < vd.eradicate_day \n"
			+ "    and §current_timestamp§ between vd.dt_insert and vd.dt_delete \n"
			+ "    and (:landCoverPkid is not null or §current_timestamp§ between lcd.dt_insert and lcd.dt_delete) \n"
			+ "order by case when length(vd.unit_code) < 15 then substr(('000000000000000'||vd.unit_code), length('000000000000000'||vd.unit_code) -14, length('000000000000000'||vd.unit_code)) else vd.unit_code end, vd.unit_id asc \n"
			+ "")
	@RegisterBeanMapper(VineUnitDetailsNTT.class)
	List<VineUnitDetailsNTT> findNotInEditVineUnitsBySessionId(@BindBean ServiceSupportEnv env, @Bind("landCoverId") Long landCoverId,
			 @Bind("landCoverPkid") Long landCoverPkId, @Bind("vineUnitId") Long vineUnitId);

	default List<VineUnitDetailsNTT> findNotInEditVineUnitsBySessionId(@BindBean ServiceSupportEnv env, @Bind("landCoverId") Long landCoverId,
			@Bind("vineUnitId") Long vineUnitId) {
		return findNotInEditVineUnitsBySessionId(env, landCoverId, null, vineUnitId);
	}
	
	@SqlQuery("select a.id as aptitude_id, \n"
			+ "   a.unit_id, \n"
			+ "   luvd.id as doigt_id, \n"
			+ "   luvd.code as doigt_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_vine_doigt', 'code', luvd.code, :lang)§ as doigt_description, \n"
			+ "   luvd.category_code as doigt_category_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_vine_doigt', 'category_code', luvd.category_code, :lang)§ as doigt_category_description, \n"
			+ "   luvd.name_code as doigt_name_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_vine_doigt', 'name_code', luvd.name_code, :lang)§ as doigt_name_description, \n"
			+ "   luvd.fl_visible as doigt_fl_visible, \n"
			+ "   vy.id as vineyard_id, \n"
			+ "   a.vineyard_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_vineyard', 'code', a.vineyard_code, :lang)§ as vineyard_description, \n"
			+ "   vy.fl_visible as vineyard_fl_visible, \n"
			+ "   a.day_from, \n"
			+ "   a.day_from_precision, \n"
			+ "   a.day_to, \n"
			+ "   a.fl_prevent_typology, \n"
			+ "   a.fl_prevent_claim, \n"
			+ "   a.fl_prevent_suitability, \n"
			+ "   'NOT_IN_EDIT' as edit_status \n"
			+ "from \n"
			+ "   lpis_lock_parcels lp \n"
			+ "   inner join lpis_parcel_land_covers lc on lc.parcel_id = lp.parcel_id \n"
			+ "   inner join lpis_parcel_lc_details lcd on lc.id = lcd.land_cover_id \n"
			+ "   inner join lpis_parcel_lc_units u on u.land_cover_id = lc.id \n"
			+ "   inner join lpis_unit_vineunit_details vd on u.id = vd.unit_id \n"
			+ "   inner join lpis_unit_vine_aptitudes a on a.unit_id = u.id and a.tenant_id = vd.tenant_id \n"
			+ "   inner join lpis_unit_vine_doigt luvd on luvd.code = a.doigt_code and a.tenant_id = luvd.tenant_id \n"
			+ "   left join lpis_unit_vineyard vy on a.vineyard_code = vy.code and vy.tenant_id = a.tenant_id \n"
			+ "where \n"
			+ "   a.tenant_id = :tenantId \n"
			+ "   and not exists (select 1 from lpis_edit_unit_vine_aptitudes lea where lea.session_uuid = :sessionId and lea.aptitude_id = a.id) \n"
			+ "   and (:vineUnitId is null or u.id = :vineUnitId) \n"
			+ "   and a.id = coalesce(:vineAptitudeId, a.id) \n"
			+ "   and u.type_code = 'VINE_UNIT' \n"
			+ "   and vd.planting_day <= :referenceDate and :referenceDate < vd.eradicate_day \n"
			+ "   and :referenceDate between vd.day_from and vd.day_to \n"
			+ "   and (:showOutdatedUnits = 1 or (a.day_from <= :referenceDate and a.day_to > :referenceDate)) \n"
			+ "    and :referenceDate between lcd.day_from and lcd.day_to \n"
			+ "   and §current_timestamp§ between lcd.dt_insert and lcd.dt_delete \n"
			+ "   and §current_timestamp§ between vd.dt_insert and vd.dt_delete \n"
			+ "   and §current_timestamp§ between a.dt_insert and a.dt_delete \n"
			+ "order by luvd.code asc, a.id asc \n"
			+ "")
	@RegisterBeanMapper(VineAptitudeNTT.class)
	List<VineAptitudeNTT> findNotInEditVineAptitudesBySessionId(
			@BindBean ServiceSupportEnv env, 
			@Bind("vineUnitId") Long vineUnitId,
			@Bind("vineAptitudeId") Long vineAptitudeId, 
			@Bind("showOutdatedUnits") Integer showOutdatedUnits);	
	
	@SqlQuery("select ea.id as edit_id, \n"
			+ "   eu.id as edit_unit_id, \n"
			+ "   eu.unit_id, \n"
			+ "   ea.aptitude_id, \n"
			+ "   luvd.id as doigt_id, \n"
			+ "   luvd.code as doigt_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_vine_doigt', 'code', luvd.code, :lang)§ as doigt_description, \n"
			+ "   luvd.category_code as doigt_category_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_vine_doigt', 'category_code', luvd.category_code, :lang)§ as doigt_category_description, \n"
			+ "   luvd.name_code as doigt_name_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_vine_doigt', 'name_code', luvd.name_code, :lang)§ as doigt_name_description, \n"
			+ "   luvd.fl_visible as doigt_fl_visible, \n"
			+ "   vy.id as vineyard_id, \n"
			+ "   ea.vineyard_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_vineyard', 'code', ea.vineyard_code, :lang)§ as vineyard_description, \n"
			+ "   vy.fl_visible as vineyard_fl_visible, \n"
			+ "   ea.day_from, \n"
			+ "   ea.day_from_precision, \n"
			+ "   ea.day_to, \n"
			+ "   ea.fl_prevent_typology, \n"
			+ "   ea.fl_prevent_claim, \n"
			+ "   ea.fl_prevent_suitability, \n"
			+ "   ea.edit_status \n"
			+ "from \n"
			+ "   lpis_edit_sessions les \n"
			+ "   inner join lpis_edit_unit_vine_aptitudes ea on ea.session_uuid = les.uuid \n"
			+ "   inner join lpis_edit_unit_vineunit eu on ea.edit_unit_id = eu.id and ea.session_uuid = eu.session_uuid  \n"
			+ "   inner join lpis_unit_vine_doigt luvd on luvd.code = ea.doigt_code and les.tenant_id = luvd.tenant_id \n"
			+ "   left join lpis_unit_vineyard vy on ea.vineyard_code = vy.code and vy.tenant_id = luvd.tenant_id \n"
			+ "where \n"
			+ "   ea.session_uuid = :sessionId \n"
			+ "   and (:vineUnitId is null or eu.unit_id = :vineUnitId) \n"
			+ "   and (:vineAptitudeId is null or :vineAptitudeId = ea.aptitude_id) \n"
			+ "   and (coalesce(<excludes>, null) is null or ea.edit_status not in (<excludes>))"
			+ "   and (coalesce(<excludes>, null) is null or eu.edit_status not in (<excludes>))"
			+ "   and (:showOutdatedUnits = 1 or (ea.day_from <= :referenceDate and ea.day_to > :referenceDate)) \n"
			+ "")
	@RegisterBeanMapper(VineAptitudeNTT.class)
	List<VineAptitudeNTT> findInEditVineAptitudesBySessionId(
			@BindBean ServiceSupportEnv env, 
			@Bind("vineUnitId") Long vineUnitId,
			@Bind("vineAptitudeId") Long vineAptitudeId, 
			@Bind("showOutdatedUnits") Integer showOutdatedUnits,
			@BindList(value = "excludes", onEmpty = BindList.EmptyHandling.NULL_STRING) List<EditStatus> excludes);	
	
	@SqlUpdate("delete from lpis_edit_unit_vineunit where session_uuid = :sessionId")
	void deleteVineUnitsBySessionId(@Bind("sessionId") String sessionId);

	@SqlUpdate("delete from lpis_edit_unit_vineunit where session_uuid = :sessionId and unit_id = :vineUnitId")
	void deleteVineUnitsById(@Bind("sessionId") String sessionId, @Bind("vineUnitId") Long unitId);	
	
	@SqlUpdate("delete from lpis_edit_unit_vineunit where session_uuid = :sessionId and id = :editVineUnitId")
	void deleteVineUnitsByEditId(@Bind("sessionId") String sessionId, @Bind("editVineUnitId") Long editVineUnitId);	
	
	@SqlUpdate("delete from lpis_edit_unit_vine_aptitudes where session_uuid = :sessionId")
	void deleteVineAptitudeBySessionId(@Bind("sessionId") String sessionId);

	@SqlUpdate("delete from lpis_edit_unit_vine_aptitudes where session_uuid = :sessionId and aptitude_id = :vineAptitudeId")
	void deleteVineAptitudeById(@Bind("sessionId") String sessionId, @Bind("vineAptitudeId") Long vineAptitudeId);	
	
	@SqlUpdate("delete from lpis_edit_unit_vine_aptitudes where session_uuid = :sessionId and id = :aptitudeEditId")
	void deleteVineAptitudeByEditId(@Bind("sessionId") String sessionId, @Bind("aptitudeEditId") Long aptitudeEditId);	
	
	@SqlQuery("select coalesce(evu.fl_deletable, 0) \n"
			+ "from \n"
			+ "    lpis_edit_sessions es \n"
			+ "    inner join lpis_edit_unit_vineunit evu on es.uuid = evu.session_uuid \n"
			+ "    inner join lpis_edit_land_covers lelc on lelc.session_uuid = evu.session_uuid and lelc.pkid = evu.edit_land_cover_id  \n"
			+ "where \n"
			+ "    es.uuid = :sessionId \n"
			+ "    and lelc.land_cover_id = :landCoverId \n"
			+ "    and (:vineUnitId is null or :vineUnitId = evu.unit_id) \n"
			+ "")
	Integer checkVineUnitDeletable(@BindBean ServiceSupportEnv env, @Bind("landCoverId") Long landCoverId,
			@Bind("vineUnitId") Long vineUnitId);
	
}
