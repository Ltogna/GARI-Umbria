package com.abacogroup.lpisgisserver.core.support;

import java.util.List;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.DatePrecision;
import com.abacogroup.lpisgisserver.core.enums.UnitDictionaryTables;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.resources.req.pub.bulk.UnitsWithDictionaryCodesPayloadV1;

public interface CreateOrUpdateUnitPayload {
	
	UnitType getUnitType();
	
	AbsoluteDate getPlantingDay();
	
	DatePrecision getPlantingDayPrecision();
	
	AbsoluteDate getEradicateDay();
	
	UnitsWithDictionaryCodesPayloadV1 toUnitsWithDictionaryCodesPayloadV1();
	
	List<UnitDictionaryTables> getMandatoryDictionayTable();
	
	void validateDate();
}
