package com.abacogroup.lpisgisserver.core.exceptions.matrix;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class MatrixClassNotFoundException extends AbstractException {

	private static final long serialVersionUID = 8738105112628369304L;

	private static final ErrorCode ERROR_CODE = ErrorCode.GENERIC_LAND_COVER_ERROR;

	public MatrixClassNotFoundException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new MatrixClassNotFoundExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Matrix class not found")
	public static class MatrixClassNotFoundExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 6650664988221418982L;

		public MatrixClassNotFoundExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
