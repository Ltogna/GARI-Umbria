package com.abacogroup.lpisgisserver.core;

import java.util.List;
import java.util.stream.Collectors;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.units.olive.OliveUnitNotFoundException;
import com.abacogroup.lpisgisserver.core.mappers.units.OliveUnitMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.OliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.OliveUnitNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.units.olive.OliveUnit;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class OliveUnitsService extends BaseService {

	private final OliveUnitsDAO oliveUnitsDAO;

	private final UnitsSupportService unitsSupportService;


	private static final UnitType UNIT_TYPE = UnitType.OLIVE_UNIT;

	public OliveUnitsService(DAOContainer dc, UnitsSupportService unitsSupportService, InternalConfigService conf,
			ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService, 
			StyleService styleService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.oliveUnitsDAO = dc.getOliveUnitsDAO();
		this.unitsSupportService = unitsSupportService;
	}

	public List<OliveUnit> getOliveUnits(ServiceSupportEnv env, Boolean showOutdatedUnits) {
		unitsSupportService.checkServiceSupportEnv(env, UNIT_TYPE, Operation.GET_OLIVE_UNITS);
		return oliveUnitsDAO.getOliveUnitsbyLandCoverIds(env, List.of(env.getLandCoverId()), boolToInt(showOutdatedUnits)).stream()
				.map(OliveUnitMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}

	public OliveUnit getOliveUnitById(ServiceSupportEnv env, Long oliveUnitId) {
		unitsSupportService.checkServiceSupportEnv(env, UNIT_TYPE, Operation.GET_OLIVE_UNITS);
		return OliveUnitMapper.INSTANCE.entityToDto(getOliveUnitNTTByUnitId(env, oliveUnitId, Operation.GET_OLIVE_UNITS));		
	}

	private OliveUnitNTT getOliveUnitNTTByUnitId(ServiceSupportEnv env, Long oliveUnitId, Operation operation) {
		OliveUnitNTT oliveUnitNTT = oliveUnitsDAO.getOliveUnitsbyUnitId(env, oliveUnitId);
		if(oliveUnitNTT == null) {
			OliveUnitNotFoundException ex = new OliveUnitNotFoundException(Status.NOT_FOUND, operation, 
					ErrorField.UNIT_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		return oliveUnitNTT;
	}
}
