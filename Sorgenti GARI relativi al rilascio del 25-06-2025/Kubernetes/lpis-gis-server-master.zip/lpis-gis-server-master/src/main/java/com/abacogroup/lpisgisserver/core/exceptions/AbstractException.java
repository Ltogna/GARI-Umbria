package com.abacogroup.lpisgisserver.core.exceptions;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public abstract class AbstractException extends WebApplicationException {

	private static final long serialVersionUID = -5782512729349268675L;

	private AbstractExceptionBody body;

	protected AbstractException(Status status, AbstractExceptionBody body){
		super(Response.status(status)
				.entity(body)
				.build());

		this.body = body;
	}
}
