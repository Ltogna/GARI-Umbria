package com.abacogroup.lpisgisserver.bundles.models;

import lombok.Data;

@Data
public class NewMatrixMetadataMessage {
	private String key;
	private String value;
}
