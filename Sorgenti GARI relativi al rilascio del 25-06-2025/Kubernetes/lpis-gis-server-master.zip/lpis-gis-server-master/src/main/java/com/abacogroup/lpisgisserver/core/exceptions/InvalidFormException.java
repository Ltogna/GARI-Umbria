package com.abacogroup.lpisgisserver.core.exceptions;

import java.util.List;
import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidFormException extends AbstractException {

	private static final long serialVersionUID = 362076605071813989L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_FORM;

	public InvalidFormException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new InvalidFormExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	public InvalidFormException(Status code, Operation operation, ErrorField errorField, List<ErrorItem> errors, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new InvalidFormExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errors, errorDescriptions, lang));
	}

	@Schema(description = "Form is not valid")
	public static class InvalidFormExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 2841504567583105653L;

		public InvalidFormExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
		
		public InvalidFormExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				List<ErrorItem> errors, Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errors, errorDescriptions, lang);
		}
	}
}
