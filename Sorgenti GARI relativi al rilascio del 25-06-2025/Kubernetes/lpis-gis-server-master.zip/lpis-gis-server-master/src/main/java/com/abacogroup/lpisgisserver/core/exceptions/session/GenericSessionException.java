package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class GenericSessionException extends AbstractException {

	private static final long serialVersionUID = 1590358037509317955L;

	private static final ErrorCode ERROR_CODE = ErrorCode.GENERIC_SESSION_ERROR;

	public GenericSessionException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new GenericSessionExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Generic session error")
	public static class GenericSessionExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 6354146904303375585L;

		public GenericSessionExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
