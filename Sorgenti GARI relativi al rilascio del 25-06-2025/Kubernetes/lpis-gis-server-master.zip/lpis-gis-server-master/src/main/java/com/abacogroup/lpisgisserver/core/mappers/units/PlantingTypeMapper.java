package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.PlantingTypeNTT;
import com.abacogroup.lpisgisserver.resources.res.units.PlantingType;

@Mapper
public interface PlantingTypeMapper {

	PlantingTypeMapper INSTANCE = Mappers.getMapper(PlantingTypeMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	PlantingType entityToDto(PlantingTypeNTT entity);
	
	@Mapping(target = "flVisible", expression = "java(dto.getVisible() ? 1 : 0)")
	@Mapping(target = "typeCode", ignore = true)
	PlantingTypeNTT dtoToEntity(PlantingType dto);
}
