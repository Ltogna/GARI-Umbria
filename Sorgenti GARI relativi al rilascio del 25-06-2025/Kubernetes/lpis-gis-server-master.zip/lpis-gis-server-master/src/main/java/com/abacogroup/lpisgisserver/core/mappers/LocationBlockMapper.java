package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.resources.res.LocationBlock;
import com.abacogroup.lpisgisserver.resources.res.pub.BlockV1;
import com.abacogroup.lpisgisserver.resources.res.pub.BlockWithGeomV1;

@Mapper(uses = AbsoluteDateMapper.class)
public interface LocationBlockMapper {

	LocationBlockMapper INSTANCE = Mappers.getMapper(LocationBlockMapper.class);

	@InheritInverseConfiguration
	@Mapping(target = "sector_code", ignore = true)
	@Mapping(target = "code", source = "block_code")
	@Mapping(target = "description", source = "short_descr")
	LocationBlock toLocationBlock(BlockWithGeomV1 blockV1);

	@Mapping(target = "sector_code", ignore = true)
	@Mapping(target = "geom", ignore = true)
	@Mapping(target = "srs", ignore = true)
	@Mapping(target = "code", source = "block_code")
	@Mapping(target = "description", source = "short_descr")
	LocationBlock toLocationBlock(BlockV1 blockV1);

}
