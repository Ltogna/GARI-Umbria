package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.LandUsesCodeNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixLandUsesNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface MatrixLandUsesDAO extends Transactional<MatrixLandUsesDAO>, EnhancedSqlObject {

	@SqlQuery("select lmcl.land_use_code, \n"
			+ "       §i18n(:tenantId, 'lpis_landuses', 'code', lmcl.land_use_code, :lang)§ as landuse_description, \n"
			+ "       lmcd.class_code, \n"
			+ "       §i18n(:tenantId, 'lpis_matrix_classes', 'code', lmc.code, :lang)§ as class_description, \n"
			+ "       coalesce "
			+ "       ( "
			+ "         (§select_from_dual(1)§ "
			+ "           where (lmcl.land_use_code = coalesce(<favouriteLandUseCodes>, null) or lmcl.land_use_code in (<favouriteLandUseCodes>)) "
			+ "         ), 0 "
			+ "       ) as isFavourite, \n"
			+ "       lmcd.line_rgba, \n"
			+ "       lmcd.fill_rgba, \n"
			+ "       lmcd.line_thick \n"
			+ "  from lpis_matrix lm \n"
			+ " inner join lpis_matrix_classes lmc on lm.id = lmc.matrix_id \n"
			+ " inner join lpis_matrix_class_details lmcd on lmc.code = lmcd.class_code and lm.id = lmcd.matrix_id \n"
			+ " inner join lpis_matrix_class_landuses lmcl on lmcd.class_code = lmcl.class_code and lm.id = lmcl.matrix_id \n"
			+ " inner join lpis_landuses lu on lm.tenant_id = lu.tenant_id and lmcl.land_use_code = lu.code \n"
			+ " where lm.tenant_id = :tenantId \n"
			+ "   and lm.code = :matrixCode \n"
			+ "   and §current_timestamp§ between lmcd.dt_insert and lmcd.dt_delete \n"
			+ "   and :referenceDate between lmcd.day_from and lmcd.day_to \n"
			+ "   and §current_timestamp§ between lmcl.dt_insert and lmcl.dt_delete \n"
			+ "   and :referenceDate between lmcl.day_from and lmcl.day_to \n"
			+ "   and <criteria> "
			+ "   order by isFavourite desc, landuse_description")
	@RegisterBeanMapper(MatrixLandUsesNTT.class)
	List<MatrixLandUsesNTT> getLandUsesStylesByCodes(
			@BindBean ServiceSupportEnv env,
			@Bind("matrixCode") String matrixCode,
			@BindCriteria("criteria") Criteria criteria,
			@BindList(value = "favouriteLandUseCodes", onEmpty = BindList.EmptyHandling.NULL_STRING) List<String> favouriteLandUseCodes);

	@SqlQuery("select lmcl.land_use_code, \n"
			+ "       §i18n(:tenantId, 'lpis_landuses', 'code', lmcl.land_use_code, :lang)§ as landuse_description, \n"
			+ "       lmcd.class_code, \n"
			+ "       §i18n(:tenantId, 'lpis_matrix_classes', 'code', lmc.code, :lang)§ as class_description, \n"
			+ "       case when coalesce(<favouriteLandUseCodes>, null ) is null or lmcl.land_use_code not in (<favouriteLandUseCodes>) then 0 else 1 end as isFavourite, \n"
			+ "       lmcd.line_rgba, \n"
			+ "       lmcd.fill_rgba, \n"
			+ "       lmcd.line_thick \n"
			+ "  from lpis_matrix lm \n"
			+ " inner join lpis_matrix_classes lmc on lm.id = lmc.matrix_id \n"
			+ " inner join lpis_matrix_class_details lmcd on lmc.code = lmcd.class_code and lm.id = lmcd.matrix_id \n"
			+ " inner join lpis_matrix_class_landuses lmcl on lmcd.class_code = lmcl.class_code and lm.id = lmcl.matrix_id \n"
			+ " inner join lpis_landuses lu on lm.tenant_id = lu.tenant_id and lmcl.land_use_code = lu.code \n"
			+ " where lm.tenant_id = :tenantId \n"
			+ "   and lm.code = :matrixCode \n"
			+ "   and §current_timestamp§ between lmcd.dt_insert and lmcd.dt_delete \n"
			+ "   and :referenceDate between lmcd.day_from and lmcd.day_to \n"
			+ "   and §current_timestamp§ between lmcl.dt_insert and lmcl.dt_delete \n"
			+ "   and :referenceDate between lmcl.day_from and lmcl.day_to \n"
			+ "   and (:search is null "
			+ "         or lmcl.land_use_code like '%'||upper(:search)||'%' "
			+ "         or (upper(lmcl.land_use_code) || ' - ' || upper(§i18n(:tenantId, 'lpis_landuses', 'code', lmcl.land_use_code, :lang)§)) like '%'||upper(:search)||'%')"
			+ "   and (coalesce(<landUseCodes>, null) is null or lmcl.land_use_code in (<landUseCodes>))"
			+ "   order by isFavourite desc, landuse_description")
	@RegisterBeanMapper(MatrixLandUsesNTT.class)
	ResultIterator<MatrixLandUsesNTT> getLandUsesStylesByCodesInfinite(
			@BindBean ServiceSupportEnv env,
			@Bind("matrixCode") String matrixCode,
			@Bind("search") String search,
			@BindList(value = "favouriteLandUseCodes", onEmpty = BindList.EmptyHandling.NULL_STRING) List<String> favouriteLandUseCodes,
			@BindList(value = "landUseCodes", onEmpty = BindList.EmptyHandling.NULL_STRING) List<String> landUseCodes);

	@SqlQuery("select distinct lmcl.land_use_code as landuse_code, \n"
			+ "       §i18n(:tenantId, 'lpis_landuses', 'code', lmcl.land_use_code, :lang)§ as landuse_description, \n"
			+ "       lmcd.class_code, \n"
			+ "       §i18n(:tenantId, 'lpis_matrix_classes', 'code', lmc.code, :lang)§ as class_description, \n"
			+ "       coalesce "
			+ "       ( "
			+ "         (§select_from_dual(1)§ "
			+ "           where (lmcl.land_use_code = coalesce(<favouriteLandUseCodes>, null) or lmcl.land_use_code in (<favouriteLandUseCodes>)) "
			+ "         ), 0 "
			+ "       ) as isFavourite, \n"
			+ "       lmcd.line_rgba, \n"
			+ "       lmcd.fill_rgba, \n"
			+ "       lmcd.line_thick \n"
			+ "  from lpis_matrix lm \n"
			+ " inner join lpis_matrix_classes lmc on lm.id = lmc.matrix_id \n"
			+ " inner join lpis_matrix_class_details lmcd on lmc.code = lmcd.class_code and lm.id = lmcd.matrix_id \n"
			+ " inner join lpis_matrix_class_landuses lmcl on lmcd.class_code = lmcl.class_code and lm.id = lmcl.matrix_id \n"
			+ " inner join lpis_landuses lu on lm.tenant_id = lu.tenant_id and lmcl.land_use_code = lu.code \n"
// FIXME			+ "  left join lpis_matrix_compat lmct on lmcl.class_code = lmct.class_code and lm.id = lmct.matrix_id \n"
			+ " where lm.tenant_id = :tenantId \n"
			+ "   and lm.code = :matrixCode \n"
			+ "   and §current_timestamp§ between lmcd.dt_insert and lmcd.dt_delete \n"
			+ "   and :referenceDate between lmcd.day_from and lmcd.day_to \n"
			+ "   and §current_timestamp§ between lmcl.dt_insert and lmcl.dt_delete \n"
			+ "   and :referenceDate between lmcl.day_from and lmcl.day_to \n"
// FIXME			+ "   and (lmc.code in (<classCodes>) or (:useIntercompatibility = 1 and lmct.extended_by_class_code in (<classCodes>))) \n"
			+ "   and lmc.code in (<classCodes>) \n"
			+ "   and :useIntercompatibility = :useIntercompatibility \n"
			+ "   and (:search is null or lmcl.land_use_code like '%'||upper(:search)||'%' or upper(§i18n(:tenantId, 'lpis_landuses', 'code', lmcl.land_use_code, :lang)§) like '%'||upper(:search)||'%' or (upper(lmcl.land_use_code) || ' - ' || upper(§i18n(:tenantId, 'lpis_landuses', 'code', lmcl.land_use_code, :lang)§)) like '%'||upper(:search)||'%')"
			+ "   order by isFavourite desc, landuse_description")
	@RegisterBeanMapper(MatrixLandUsesNTT.class)
	ResultIterator<MatrixLandUsesNTT> getLandUsesByClassCodesInfinite(
			@BindBean ServiceSupportEnv env,
			@Bind("matrixCode") String matrixCode,
			@Bind("search") String search,
			@BindList("classCodes") List<String> classCodes,
			@BindList(value = "favouriteLandUseCodes", onEmpty = BindList.EmptyHandling.NULL_STRING) List<String> favouriteLandUseCodes,
			@Bind("useIntercompatibility") Integer useIntercompatibility);

	@SqlQuery("select distinct lmcl.land_use_code as code, \n"
			+ " §i18n(:tenantId, 'lpis_landuses', 'code', lmcl.land_use_code, :lang)§ as description \n"
			+ "  from lpis_matrix lm \n"
			+ " inner join lpis_matrix_classes lmc on lm.id = lmc.matrix_id \n"
			+ " inner join lpis_matrix_class_details lmcd on lmc.code = lmcd.class_code and lm.id = lmcd.matrix_id \n"
			+ " inner join lpis_matrix_class_landuses lmcl on lmcd.class_code = lmcl.class_code and lm.id = lmcl.matrix_id \n"
			+ " inner join lpis_landuses lu on lmcl.land_use_code = lu.code and lm.tenant_id = lu.tenant_id \n"
			+ " where lm.tenant_id = :tenantId \n"
			+ "   and lm.code = :matrixCode \n"
			+ "   and §current_timestamp§ between lmcd.dt_insert and lmcd.dt_delete \n"
			+ "   and :referenceDate between lmcd.day_from and lmcd.day_to \n"
			+ "   and §current_timestamp§ between lmcl.dt_insert and lmcl.dt_delete \n"
			+ "   and :referenceDate between lmcl.day_from and lmcl.day_to \n"
			+ "   and lmc.code in (<classCodes>)")
	@RegisterBeanMapper(LandUsesCodeNTT.class)
	List<LandUsesCodeNTT> getLandUsesByClassCodes(
			@BindBean ServiceSupportEnv env,
			@Bind("matrixCode") String matrixCode,
			@BindList("classCodes") List<String> classCodes);

}
