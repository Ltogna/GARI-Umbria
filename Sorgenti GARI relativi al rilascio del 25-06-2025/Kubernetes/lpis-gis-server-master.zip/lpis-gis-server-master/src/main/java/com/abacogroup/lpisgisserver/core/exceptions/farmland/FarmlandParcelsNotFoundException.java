package com.abacogroup.lpisgisserver.core.exceptions.farmland;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class FarmlandParcelsNotFoundException extends AbstractException {

	private static final long serialVersionUID = 9066361809780827920L;

	private static final ErrorCode ERROR_CODE = ErrorCode.FARMLAND_PARCELS_NOT_FOUND;

	public FarmlandParcelsNotFoundException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new FarmlandParcelsNotFoundExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Farmland parcels not found")
	public static class FarmlandParcelsNotFoundExceptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = -4497413636287111965L;

		public FarmlandParcelsNotFoundExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}

	}
}
