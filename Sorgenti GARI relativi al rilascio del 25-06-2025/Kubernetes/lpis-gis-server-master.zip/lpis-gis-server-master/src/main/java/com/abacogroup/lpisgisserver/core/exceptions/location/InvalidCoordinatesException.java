package com.abacogroup.lpisgisserver.core.exceptions.location;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidCoordinatesException extends AbstractException {

	private static final long serialVersionUID = -631288209510780457L;

	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_COORDINATES;

	public InvalidCoordinatesException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new InvalidCoordinatesExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Invalid coordinates")
	public static class InvalidCoordinatesExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -6905246824130062231L;

		public InvalidCoordinatesExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
