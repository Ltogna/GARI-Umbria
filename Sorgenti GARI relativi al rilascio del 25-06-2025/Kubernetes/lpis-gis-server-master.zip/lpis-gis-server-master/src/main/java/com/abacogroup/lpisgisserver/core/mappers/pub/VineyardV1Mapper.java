package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.resources.res.pub.units.vine.VineyardV1;
import com.abacogroup.lpisgisserver.resources.res.units.vine.Vineyard;

@Mapper
public interface VineyardV1Mapper {

	VineyardV1Mapper INSTANCE = Mappers.getMapper(VineyardV1Mapper.class);
	
	VineyardV1 toResponseV1(Vineyard entity);

}
