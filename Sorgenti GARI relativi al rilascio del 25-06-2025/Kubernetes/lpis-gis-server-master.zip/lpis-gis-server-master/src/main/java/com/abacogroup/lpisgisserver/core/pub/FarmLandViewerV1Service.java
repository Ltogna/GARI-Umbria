package com.abacogroup.lpisgisserver.core.pub;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lpisgisserver.core.BaseService;
import com.abacogroup.lpisgisserver.core.ErrorDescriptionsService;
import com.abacogroup.lpisgisserver.core.ExternalConfigService;
import com.abacogroup.lpisgisserver.core.FarmLandViewerService;
import com.abacogroup.lpisgisserver.core.InternalConfigService;
import com.abacogroup.lpisgisserver.core.StyleService;
import com.abacogroup.lpisgisserver.core.mappers.pub.TotalParcelsSummaryFiltersV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.TotalParcelsSummaryV1Mapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.ReqContext;
import com.abacogroup.lpisgisserver.resources.req.TotalParcelsSummaryFilters;
import com.abacogroup.lpisgisserver.resources.req.pub.TotalParcelsSummaryFiltersV1;
import com.abacogroup.lpisgisserver.resources.res.pub.farmland.TotalParcelsSummaryV1;

public class FarmLandViewerV1Service extends BaseService {

	private FarmLandViewerService farmLandViewerService;


	public FarmLandViewerV1Service(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, 
			FarmLandViewerService farmLandViewerService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.farmLandViewerService = farmLandViewerService;

	}


	public InfiniteListResults<TotalParcelsSummaryV1> findInfiniteTotalParcelsSummaryGroupedBySectorCode(
			ReqContext reqContext, ServiceSupportEnv env, TotalParcelsSummaryFiltersV1 searchFilters) {
		
		TotalParcelsSummaryFilters privSearchFilters = TotalParcelsSummaryFiltersV1Mapper.INSTANCE.toPrivFilters(searchFilters);
		
		return farmLandViewerService.findInfiniteTotalParcelsSummaryGroupedBySectorCode(reqContext, env, privSearchFilters)
				.map(TotalParcelsSummaryV1Mapper.INSTANCE::toResponseV1);
	}

	
}
