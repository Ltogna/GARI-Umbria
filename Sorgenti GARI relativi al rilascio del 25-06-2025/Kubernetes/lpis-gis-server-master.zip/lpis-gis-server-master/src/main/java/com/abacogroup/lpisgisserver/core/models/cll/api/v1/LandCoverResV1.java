package com.abacogroup.lpisgisserver.core.models.cll.api.v1;

import org.locationtech.jts.geom.Geometry;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
public class LandCoverResV1 {
	private Long id;

	private String code;

	private String description;

	private Long parcelId;

	private AbsoluteDate dayFrom;

	private AbsoluteDate dayTo;

	private String srs;

	private Long areaSqm;

	private Geometry geom;

	private Geometry worldGeom;

}