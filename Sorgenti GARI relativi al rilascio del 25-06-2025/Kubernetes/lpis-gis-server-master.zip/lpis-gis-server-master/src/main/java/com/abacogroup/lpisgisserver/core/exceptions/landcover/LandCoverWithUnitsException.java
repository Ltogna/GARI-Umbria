package com.abacogroup.lpisgisserver.core.exceptions.landcover;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class LandCoverWithUnitsException extends AbstractException {

	private static final long serialVersionUID = -8464206012584574243L;

	private static final ErrorCode ERROR_CODE = ErrorCode.LAND_COVER_WITH_UNITS;

	public LandCoverWithUnitsException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new LandCoverNotFoundExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Land cover has valid units, can not update or delete landcover")
	public static class LandCoverNotFoundExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -4935769979569102297L;

		public LandCoverNotFoundExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
