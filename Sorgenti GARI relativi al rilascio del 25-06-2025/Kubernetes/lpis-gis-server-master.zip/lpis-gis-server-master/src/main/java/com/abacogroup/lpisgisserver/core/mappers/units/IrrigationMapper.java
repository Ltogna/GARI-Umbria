package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.IrrigationNTT;
import com.abacogroup.lpisgisserver.resources.res.units.Irrigation;

@Mapper
public interface IrrigationMapper {

	IrrigationMapper INSTANCE = Mappers.getMapper(IrrigationMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	Irrigation entityToDto(IrrigationNTT entity);
	
	@Mapping(target = "flVisible", expression = "java(dto.getVisible() ? 1 : 0)")
	@Mapping(target = "typeCode", ignore = true)
	IrrigationNTT dtoToEntity(Irrigation dto);
}
