package com.abacogroup.lpisgisserver.core.config;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
@Valid
public class TaskManagerConfig {

	@NotEmpty
	private String url;
	
}
