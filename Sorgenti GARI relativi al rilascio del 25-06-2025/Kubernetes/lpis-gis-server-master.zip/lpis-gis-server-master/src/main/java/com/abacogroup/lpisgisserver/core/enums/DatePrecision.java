package com.abacogroup.lpisgisserver.core.enums;

public enum DatePrecision {
	Y,
	YM,
	YMD
}
