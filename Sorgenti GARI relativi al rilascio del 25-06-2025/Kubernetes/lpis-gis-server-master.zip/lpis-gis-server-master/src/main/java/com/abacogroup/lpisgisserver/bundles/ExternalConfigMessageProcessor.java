package com.abacogroup.lpisgisserver.bundles;

import java.io.File;
import java.nio.file.Path;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.lpisgisserver.bundles.models.ExternalConfigListMessage;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.ExternalConfigDAO;
import com.abacogroup.lpisgisserver.db.ntt.ExternalConfigNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ExternalConfigMessageProcessor extends AbstractMessageProcessor{

	private ExternalConfigDAO externalConfigDAO;
	private final ObjectMapper objectMapper = new ObjectMapper();

	private static final Logger log = LoggerFactory.getLogger(ExternalConfigMessageProcessor.class);

	public ExternalConfigMessageProcessor(DAOContainer dc) {
		super(dc);
		this.externalConfigDAO = dc.getExternalConfigDAO();
	}

	@Override
	public String getDomainName() {
		return "external-config";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> file.getAbsolutePath().endsWith(".json"))
				.forEach(file -> processFile(message.getTenantId(), file));
	}

	private void processFile(String tenantId, File file) {
		try {
			ExternalConfigListMessage message = objectMapper.readValue(file, ExternalConfigListMessage.class);

			if (message == null) {
				return;
			}

			if (file.getAbsolutePath().endsWith(".delete.json")) {
				doDelete(tenantId, message);
			} else {
				doInsertOrUpdate(tenantId, message);
			}
		} catch (Exception e) {
			log.error(String.format(ERROR_PROCESSING_FILE_MESSAGE, file.getName(), tenantId), e);
		}
	}

	private void doInsertOrUpdate(String tenantId, ExternalConfigListMessage message) {
		message.getExternalConfig().forEach(config -> {
			try {
				ExternalConfigNTT savedConfig = externalConfigDAO.getConfigByTenantAndKey(tenantId, config.getKey());

				ExternalConfigNTT configToInsertOrUpdate = ExternalConfigNTT.builder()
						.tenant_id(tenantId)
						.key(config.getKey())
						.value(config.getValue())
						.build();

				if (savedConfig == null) {
					externalConfigDAO.insert(configToInsertOrUpdate);
				} else if (!savedConfig.equals(configToInsertOrUpdate)) {
					externalConfigDAO.updateValue(configToInsertOrUpdate);
				}
			} catch (Exception e) {
				log.error("Error during insert external config key " + config.getKey() + " with value " + config.getValue()
						+ FOR_TENANT + tenantId + " : " + e);
			}
		});

	}

	private void doDelete(String tenantId, ExternalConfigListMessage message) {
		message.getExternalConfig().forEach(config -> {
			try {
				externalConfigDAO.deleteByTenantAndKey(tenantId, config.getKey());
			} catch (Exception e) {
				log.error("Error during delete external config key " + config.getKey() + FOR_TENANT + tenantId + " : " + e);
			}
		});

	}
}
