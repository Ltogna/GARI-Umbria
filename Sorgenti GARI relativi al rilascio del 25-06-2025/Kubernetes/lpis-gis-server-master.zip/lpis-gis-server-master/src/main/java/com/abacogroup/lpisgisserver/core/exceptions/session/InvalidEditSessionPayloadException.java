package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidEditSessionPayloadException extends AbstractException {

	private static final long serialVersionUID = 104626130101249148L;

	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_EDIT_SESSION_PAYLOAD;

	public InvalidEditSessionPayloadException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new InvalidEditSessionPayloadExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Edit session payload is not valid")
	public static class InvalidEditSessionPayloadExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 2841504567583105653L;

		public InvalidEditSessionPayloadExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
