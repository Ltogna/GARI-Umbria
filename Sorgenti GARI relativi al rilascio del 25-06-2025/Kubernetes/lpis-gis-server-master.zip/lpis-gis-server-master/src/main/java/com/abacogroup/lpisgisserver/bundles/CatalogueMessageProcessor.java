package com.abacogroup.lpisgisserver.bundles;

import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.lpisgisserver.bundles.models.CatalogueMessageList;
import com.abacogroup.lpisgisserver.bundles.models.I18nMessage;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.CataloguesDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.ntt.CatalogueConfigParamNTT;
import com.abacogroup.lpisgisserver.db.ntt.CatalogueNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CatalogueMessageProcessor extends AbstractMessageProcessor {

	protected CataloguesDAO cataloguesDAO;

	private final ObjectMapper objectMapper;
	
	private static final Logger log = LoggerFactory.getLogger(CatalogueMessageProcessor.class);

	public CatalogueMessageProcessor(DAOContainer dc) {
		super(dc);
		this.cataloguesDAO = dc.getCataloguesDAO();

		objectMapper = new ObjectMapper();
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> deleteCatalogueMessage(message.getTenantId(), file));

		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
				&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> insertOrUpdateCatalogueMessage(message.getTenantId(), file));
	}

	@Override
	public String getDomainName() {
		return "catalogues";
	}

	private void insertOrUpdateCatalogueMessage(String tenantId, File file) {
		try {
			CatalogueMessageList catalogueListMessage = objectMapper.readValue(file, CatalogueMessageList.class);

			if (catalogueListMessage == null || catalogueListMessage.getCatalogueList() == null) {
				return;
			}
			
			ServiceSupportEnv env = ServiceSupportEnv.builder()
					.tenantId(tenantId)
					.build();

			catalogueListMessage.getCatalogueList().stream()
			.forEach(msg -> {
				List<Criteria> criterias = new ArrayList<>();
				criterias.add(CriteriaBuilder.string("code").eq(msg.getCode()));
				Criteria criteria = CriteriaBuilder.and(criterias.toArray(new Criteria[0]));
				
				env.setSrs(msg.getSrs());
								
				CatalogueNTT catalogueNTT = cataloguesDAO.getCatalogues(env, criteria).stream().findFirst().orElse(null);
				
				CatalogueNTT toInsertOrUpdate = CatalogueNTT.builder()
						.type(msg.getType())
						.code(msg.getCode())
						.srs(msg.getSrs())
						.displayOrder(msg.getDisplayOrder())
						.flVisible(boolToInt(msg.getVisible()))
						.build();
				
				if(catalogueNTT == null) {
					toInsertOrUpdate.setId(cataloguesDAO.nextSequenceValCatalogueId());
					cataloguesDAO.insertCatalogue(tenantId, toInsertOrUpdate);
				} else {
					toInsertOrUpdate.setId(catalogueNTT.getId());
					cataloguesDAO.updateCatalogueById(tenantId, toInsertOrUpdate);
				}
				
				insertCatalogueConfigParam(tenantId, msg.getCode(), msg.getParams());
				
				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table("lpis_catalogues")
						.field("code")
						.value(toInsertOrUpdate.getCode())
						.translations(msg.getDescriptions())
						.build();
				insertOrUpdateI18nMessages(tenantId, i18nMessage);
			});
			
		} catch (Exception e) {
			log.error("Error processing file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}
	}

	private void insertCatalogueConfigParam(String tenantId, String code, Map<String, String> paramList) {

		if(paramList == null) {
			return;
		}

		cataloguesDAO.deleteCatalogueParamByCode(tenantId, code);

		paramList.entrySet().forEach(param -> {

			if(StringUtils.isBlank(param.getKey()) || StringUtils.isBlank(param.getValue())) {
				throw new IllegalArgumentException("Catalogue param key" + param.getKey() + " not valid!");
			}

			CatalogueConfigParamNTT toInsertOrUpdate = CatalogueConfigParamNTT.builder()
					.catalogueCode(code)
					.paramKey(param.getKey())
					.paramValue(param.getValue())
					.build();

			cataloguesDAO.insertCatalogueParam(tenantId, toInsertOrUpdate);
		});
	}
	

	private void deleteCatalogueMessage(String tenantId, File file) {
		try {
			CatalogueMessageList catalogueListMessage = objectMapper.readValue(file, CatalogueMessageList.class);

			if (catalogueListMessage == null || catalogueListMessage.getCatalogueList() == null) {
				return;
			}
			
			ServiceSupportEnv env = ServiceSupportEnv.builder()
					.tenantId(tenantId)
					.build();

			catalogueListMessage.getCatalogueList().stream()
			.forEach(msg -> {
				List<Criteria> criterias = new ArrayList<>();
				criterias.add(CriteriaBuilder.string("code").eq(msg.getCode()));
				Criteria criteria = CriteriaBuilder.and(criterias.toArray(new Criteria[0]));

				env.setSrs(msg.getSrs());				
				
				cataloguesDAO.getCatalogues(env, criteria).stream().findFirst()
				.ifPresentOrElse(
						c -> cataloguesDAO.deleteCatalogueById(tenantId, c.getId()), 
						() -> {
							throw new IllegalArgumentException("Catalogue with code '" + msg.getCode() + "' and srs '" + msg.getSrs() + "'  not found!");
						});
				
				cataloguesDAO.deleteCatalogueParamByCode(tenantId, msg.getCode());
			});
			
		} catch (Exception e) {
			log.error("Error processing file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}
	}	
}
