package com.abacogroup.lpisgisserver.core.support;

import com.abacogroup.lpisgisserver.resources.req.ReqContext;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class ResourceSupportParams {

	private ReqContext reqContext;
	
}
