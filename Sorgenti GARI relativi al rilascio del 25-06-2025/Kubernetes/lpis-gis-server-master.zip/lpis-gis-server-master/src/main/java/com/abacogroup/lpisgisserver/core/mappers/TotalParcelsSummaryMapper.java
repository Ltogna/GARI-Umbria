package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.TotalParcelsNTT;
import com.abacogroup.lpisgisserver.resources.res.farmland.TotalParcelsSummary;

@Mapper(uses = AbsoluteDateMapper.class)
public interface TotalParcelsSummaryMapper {

	TotalParcelsSummaryMapper INSTANCE = Mappers.getMapper(TotalParcelsSummaryMapper.class);

	TotalParcelsSummary entityToDto(TotalParcelsNTT entity);

	@Mapping(target = "total_area_sau", ignore = true)
	TotalParcelsNTT dtoToEntity(TotalParcelsSummary dto);
}
