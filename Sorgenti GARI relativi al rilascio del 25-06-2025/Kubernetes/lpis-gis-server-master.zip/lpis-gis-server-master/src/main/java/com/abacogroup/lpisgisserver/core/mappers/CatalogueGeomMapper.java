package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.CatalogueGeomNTT;
import com.abacogroup.lpisgisserver.resources.res.CatalogueGeom;
import com.abacogroup.lpisgisserver.resources.res.SnapElements;
import com.abacogroup.lpisgisserver.resources.res.vectordata.VectorDataLayerGeometryResponse;
import com.abacogroup.lpisgisserver.resources.res.vectordata.VectorDataLayerGeometryWithInfoResponse;

@Mapper
public interface CatalogueGeomMapper {

	CatalogueGeomMapper INSTANCE = Mappers.getMapper(CatalogueGeomMapper.class);
	
	@Mapping(target = "srs", ignore = true)
	@Mapping(target = "fields", ignore = true)
	CatalogueGeom entityToDto(CatalogueGeomNTT entity);
	
	CatalogueGeomNTT dtoToEntity(CatalogueGeom dto);
	
	@Mapping(source = "geometry", target = "geom")
	CatalogueGeom fromVectorDataLayerToCatalogueGeom(VectorDataLayerGeometryResponse entity);

	@Mapping(source = "geometry", target = "geom")
	CatalogueGeom fromVectorDataLayerToCatalogueGeom(VectorDataLayerGeometryWithInfoResponse entity);
	
	@Mapping(source = "description", target = "label")
	CatalogueGeom toCatalogueGeom(SnapElements.SnapGeometry entity);
	
}
