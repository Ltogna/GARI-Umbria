package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.resources.res.LocationParcel;
import com.abacogroup.lpisgisserver.resources.res.pub.ParcelV1;

@Mapper(uses = { LocationSectorMapper.class, LocationBlockMapper.class })
public interface LocationParcelMapper {

	LocationParcelMapper INSTANCE = Mappers.getMapper(LocationParcelMapper.class);

	@InheritInverseConfiguration
	@Mapping(target = "code", source = "parcel")
	LocationParcel toLocationParcel(ParcelV1 parcel);

}
