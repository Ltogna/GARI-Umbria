package com.abacogroup.lpisgisserver.bundles.models;

import org.locationtech.jts.geom.Geometry;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AreaMessage {
	private String code;
	private String acronym;
	private String description;
	private String parent_code;
	private String level;
	private AbsoluteDate day_from;
	private AbsoluteDate day_to;
	private String srs;
	private Geometry geom;
	private Geometry world_geom;
}
