package com.abacogroup.lpisgisserver.core;

import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.LineString;
import org.locationtech.jts.geom.MultiPolygon;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.geom.Polygonal;

import com.abacogroup.geometryeditor.Editor;
import com.abacogroup.geometryeditor.EditorResult;
import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.CutBehaviour;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.LineBufferBehaviour;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.OverlayType;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.InvalidPayloadException;
import com.abacogroup.lpisgisserver.core.exceptions.catalogue.CatalogueIdNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.InvalidLandCoverGeometryException;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.LandCoverGeometryNotLineException;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.LandCoverIdsNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.LandCoverNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.InvalidParcelDataException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionParcelIdException;
import com.abacogroup.lpisgisserver.core.exceptions.session.UpdateBufferTooLargeException;
import com.abacogroup.lpisgisserver.core.exceptions.session.UpdateBufferTooSmallException;
import com.abacogroup.lpisgisserver.core.mappers.LandCoversMapper;
import com.abacogroup.lpisgisserver.core.support.EditorSupportFactory;
import com.abacogroup.lpisgisserver.core.support.EditorSupportParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditLandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.EditParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoversDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.CataloguePayload;
import com.abacogroup.lpisgisserver.resources.req.CreateLandCoversPayload;
import com.abacogroup.lpisgisserver.resources.req.CreateLinearLandCoversPayload;
import com.abacogroup.lpisgisserver.resources.req.CreateParcelsPayload;
import com.abacogroup.lpisgisserver.resources.req.CutLandCoversByLinePayload;
import com.abacogroup.lpisgisserver.resources.req.CutLandCoversPayload;
import com.abacogroup.lpisgisserver.resources.req.GeometryIntersectionPayload;
import com.abacogroup.lpisgisserver.resources.req.MergeLandCoversPayload;
import com.abacogroup.lpisgisserver.resources.req.UpdateLandCoversDataPayload;
import com.abacogroup.lpisgisserver.resources.req.UpdateLandCoversPayload;
import com.abacogroup.lpisgisserver.resources.req.UpdateParcelsPayload;
import com.abacogroup.lpisgisserver.resources.res.Catalogue;
import com.abacogroup.lpisgisserver.resources.res.CatalogueGeom;
import com.abacogroup.lpisgisserver.resources.res.EditResult;
import com.abacogroup.lpisgisserver.resources.res.GeometryIntersection;
import com.abacogroup.lpisgisserver.resources.res.LandCoverWithUnits;
import com.abacogroup.lpisgisserver.resources.res.LandCoversEditResult;
import com.abacogroup.lpisgisserver.resources.res.LandCoversList;
import com.abacogroup.lpisgisserver.resources.res.LayerStyle;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EditLandCoversService extends BaseService {

	private final EditSessionSupportService editSessionSupportService;
	private final EditLandCoversSupportService editLandCoversSupportService;
	private final CataloguesService cataloguesService;

	private EditLandCoversDAO editLandCoversDAO;
	private EditParcelsDAO editParcelsDAO;
	private LandCoversDAO landCoverDAO;

	private EditorSupportFactory<Long> editorSupportFactory;
	
	private static final Boolean SHOW_ALL_CATALOGUES = null;
	private static final Boolean SKIP_FORBIDDEN_LC_CHECK = true;

	public EditLandCoversService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService,
			EditSessionSupportService editSessionSupportService, EditLandCoversSupportService editLandCoversSupportService,
		    CataloguesService cataloguesService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.editLandCoversDAO = dc.getEditLandCoversDAO();
		this.editParcelsDAO = dc.getEditParcelsDAO();
		this.landCoverDAO = dc.getLandCoversDAO();
		
		this.editSessionSupportService = editSessionSupportService;
		this.editLandCoversSupportService = editLandCoversSupportService;
		this.cataloguesService = cataloguesService;

		try {
			this.editorSupportFactory = (EditorSupportParams params, CutBehaviour cutBehaviour,
					EditorResult<Long> parcelEditorResult, Map<Long, Polygon> cutPolygons, boolean isForPreview,
					long lastPreviewKey) -> new EditorLandCoversSupportImpl(params, cutBehaviour, parcelEditorResult, cutPolygons, isForPreview, lastPreviewKey,
							dc);

		} catch (AbstractException e) {
			AbstractExceptionBody body = e.getBody();

			body.setOperation(Operation.INIT_EDIT_LANDCOVER_SERVICE);
			body.setMessage(body.getErrorCode(), ErrorDescriptionsService.DEFAULT_LANG_CODE, this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY));

			log.error(body.getLogErrorMessage());

			e.setBody(body);

			throw e;
		}
	}

	// ----------------------------------------------------------------------------------------------------------------------

	public LandCoversList getEditLandCovers(EditorSupportParams params) {

		editLandCoversSupportService.checkCanEditLC(params, null);

		List<LandCoverNTT> editLandCovers = editLandCoversSupportService.internalGetEditLandCovers(params);
		List<LandCoverWithUnits> landCovers = editLandCovers.stream().map(LandCoversMapper.INSTANCE::entityToDtoWithUnits).collect(toList());

		landCovers.forEach(landCover -> {
			LayerStyle style = this.styleService.getLandCoverLayerStyle(params.getReqContext().getTenantId(), params.getSession().getReference_date(),
					landCover.getCode());
			landCover.setLayer_style(style);
			
			editLandCoversSupportService.addUnitsToLandCover(params, landCover);
			editLandCoversSupportService.setTotaleUnitAreaSqm(landCover);
		});

		return LandCoversList
				.builder()
				.land_covers_list(landCovers)
				.build();
	}

	// ----------------------------------------------------------------------------------------------------------------------

	public EditResult createLandCovers(EditorSupportParams params, CreateLandCoversPayload payload, Boolean isForPreview) {

		editLandCoversSupportService.checkCanEditLC(params, null);

		if (Boolean.FALSE.equals(isForPreview))
			editSessionSupportService.refreshSession(params.getSession().getUuid());

		String landCoverCode = payload.getLand_cover_code();

		if (StringUtils.isBlank(landCoverCode)) {
			landCoverCode = this.internalConf.getStringValue(params.getSession().getTenant_id(), InternalConfigKeys.DEFAULT_LAND_COVER_CODE_KEY.getKey());
		}

		params.setLandCoverCode(landCoverCode);

		Editor<Long> editor = editLandCoversSupportService.getEditor(params, payload.getCut_behaviour(), null, null, isForPreview, editorSupportFactory);

		EditorResult<Long> result = new EditorResult<>();
		try {
			result = editor.insertPolygon((Polygonal) payload.getGeom());
		} catch (AbstractException e) {
			throwExceptionFromEditorOperation(e, params);
		}

		LandCoversEditResult landCoversEditResult = getEditLandCoverResult(result, params);
		
		editLandCoversSupportService.setTotaleUnitAreaSqm(landCoversEditResult);

		return new EditResult(null, evaluateLandCoverResult(isForPreview, params, result, landCoversEditResult));

	}

	public LandCoversEditResult createParcelsLandCovers(EditorSupportParams params, CreateParcelsPayload payload, EditorResult<Long> parcelEditorResult,
			Boolean isForPreview) {

		params.setOperation(Operation.CREATE_PARCEL_LANDCOVERS);
		
		String lcOriginCatalogueCode = internalConf.getStringValue(params.getReqContext().getTenantId(), InternalConfigKeys.LANDCOVER_ORIGIN_CATALOGUE_CODE.getKey());
		if(!StringUtils.isBlank(lcOriginCatalogueCode)) {
//			return createOrUpdateParcelLandCoversFromCatalogue(params, lcOriginCatalogueCode, parcelEditorResult, isForPreview);
			return new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
		}

		Editor<Long> editor = editLandCoversSupportService.getEditor(params, payload.getCut_behaviour(), parcelEditorResult, null, isForPreview,
				editorSupportFactory);

		EditorResult<Long> createResult = new EditorResult<>();
		try {
			createResult = editor.insertPolygon((Polygonal) payload.getGeom());
		} catch (AbstractException e) {
			throwExceptionFromEditorOperation(e, params);
		}

		if (payload.getCut_behaviour() == CutBehaviour.CUT_ON_EXISTING) {
			List<Polygon> createdGeometries = new ArrayList<>(parcelEditorResult.getCreated().values());
			if (!createdGeometries.isEmpty()) {
				Geometry allNewParcels = Utils.getUnion(createdGeometries);
				createResult.getCreated().entrySet().removeIf(e -> !allNewParcels.contains(Utils.getSafeInteriorPoint(e.getValue())));
			}

		}

		addNotModifiedLandCoversFromParcelEditorResult(params, parcelEditorResult, createResult);

		LandCoversEditResult res = new LandCoversEditResult();
		res.setAdded(new ArrayList<>());
		res.setUpdated(new ArrayList<>());
		res.setDeleted(new ArrayList<>());

		editLandCoversSupportService.editLandCoversEditResultAndLandCoverEditorResultFromParcel(params, parcelEditorResult, createResult, res);

		editLandCoversSupportService.setTotaleUnitAreaSqm(res);
		return evaluateLandCoverResult(isForPreview, params, createResult, res);
	}

//	private LandCoversEditResult createOrUpdateParcelLandCoversFromCatalogue(EditorSupportParams params, String catalogueCode, EditorResult<Long> parcelEditorResult,
//			Boolean isForPreview) {
//				
//		LandCoversEditResult result = new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
//		
//		parcelEditorResult.getCreated().forEach((id, geom) -> {
//			params.setParcelId(id);
//			CataloguePayload cataloguePayload = CataloguePayload.builder()
//					.geom(geom)
//					.srs(params.getSession().getLock_geom_srs())
//					.params(Map.of("referenceDate", params.getSession().getReference_date().toString())) //XXX TODO remove
//					.build();
//			
//			List<CatalogueGeom> catalogueGeoms = cataloguesService.getGeomsFromCatalogueList(params, catalogueCode, params.getSession().getReference_date(), cataloguePayload);
//			
//			LandCoversEditResult createLandCoverEditResult = createLandCoversFromCatalogueGeoms(params, catalogueGeoms, isForPreview);
//			mergeLandCoversEditResult(createLandCoverEditResult, result);
//		});
//	
//		LandCoversEditResult updatelcEditResult = updateLandCoversFromCatalogueGeoms(params, catalogueCode, parcelEditorResult.getModified(), isForPreview);
//		mergeLandCoversEditResult(updatelcEditResult, result);
//		
//		return result;
//	}
//
//	private LandCoversEditResult createLandCoversFromCatalogueGeoms(EditorSupportParams params, List<CatalogueGeom> catalogueGeoms,
//			Boolean isForPreview) {
//
//		LandCoversEditResult result = new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
//
//		catalogueGeoms.forEach(cg -> {
//			CreateLandCoversPayload createLandCoversPayload = CreateLandCoversPayload.builder()
//					.geom(cg.getGeom())
//					.land_cover_code(cg.getLabel())
//					.build();
//			EditResult createLandCoverEditResult = createLandCovers(params, createLandCoversPayload, isForPreview);
//			
//			mergeLandCoversEditResult(createLandCoverEditResult.getLand_covers_edit_result(), result);
//		});
//		
//		return result;
//	}
//	
//	private void mergeLandCoversEditResult(LandCoversEditResult source, LandCoversEditResult target) {
//		
//		source.getDeleted().stream()
//		.filter(id -> !target.getDeleted().contains(id))
//		.forEach(id -> target.getDeleted().add(id));
//		
//		
//		Map<Long, LandCoverWithUnits> addedMap = target.getAdded().stream()
//		        .collect(Collectors.toMap(LandCoverWithUnits::getId, Function.identity()));
//		
//		// Update 'added' list with 'updated' items
//	    Iterator<LandCoverWithUnits> updatedIterator = source.getUpdated().iterator();
//	    while (updatedIterator.hasNext()) {
//	        LandCoverWithUnits updatedItem = updatedIterator.next();
//	        Long updatedId = updatedItem.getId();
//
//	        if (addedMap.containsKey(updatedId)) {
//	            // Update the added item with the updated information
//	            addedMap.put(updatedId, updatedItem);
//	            updatedIterator.remove(); // Remove from 'updated' 
//	        }
//	    }
//		
//	    // Set the modified 'added' list back to target
//	    target.setAdded(new ArrayList<>(addedMap.values()));
//		
//	    // Add remaining items from source to target
//	    target.getAdded().addAll(source.getAdded().stream()
//	        .filter(item -> !addedMap.containsKey(item.getId()))
//	        .collect(Collectors.toList()));
//		
//		// Add remaining updated items to target
//	    target.getUpdated().addAll(source.getUpdated());
//	
//	}
//	
//	private LandCoversEditResult updateLandCoversFromCatalogueGeoms(EditorSupportParams params, String catalogueCode,
//			Map<Long, Polygon> updatedParcelList, Boolean isForPreview) {
//
//		LandCoversEditResult result = new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
//		updatedParcelList.forEach((id, geom) -> {
//			params.setParcelId(id);
//
//			Map<Long, LandCoverNTT> oldLandcoverMap = editLandCoversSupportService.findLandCoversByParcels(params, List.of(id)).stream()
//					.filter(lc -> lc.getGeom() != null)
//					.collect(Collectors.toMap(LandCoverNTT::getLand_cover_id, Function.identity()));
//			List<CatalogueGeom> catalogueGeoms = getIntersectedCatalogueGeom(params, catalogueCode, geom);
//
//			Map<Long, String> updateLcCode = new HashMap<>();
//			Map<Long, Geometry> updateLcGeoms = new HashMap<>();
//			List<CatalogueGeom> newLcGeoms = new ArrayList<>();
//
//			catalogueGeoms.forEach(cg -> {
//				LandCoverNTT fullyCoveredLandcover = null;
//				for (LandCoverNTT lc : oldLandcoverMap.values()) {
//					if(lc.getGeom().buffer(GEOM_COMPARE_PRECISION).contains(cg.getGeom()) 
//							|| cg.getGeom().buffer(GEOM_COMPARE_PRECISION).contains(lc.getGeom())) {
//						fullyCoveredLandcover = lc;
//					}
//				}
//
//				if(fullyCoveredLandcover != null) {
//					updateLcGeoms.put(fullyCoveredLandcover.getLand_cover_id(), cg.getGeom());
//
//					if(!fullyCoveredLandcover.getLand_cover_code().equals(cg.getLabel())) {
//						updateLcCode.put(fullyCoveredLandcover.getLand_cover_id(), cg.getLabel());
//					}
//
//					oldLandcoverMap.remove(fullyCoveredLandcover.getLand_cover_id());
//				} else {
//					newLcGeoms.add(cg);
//				}
//			});
//
//			oldLandcoverMap.keySet().forEach(lcId -> {
//				params.setLandCoverId(lcId);
//				mergeLandCoversEditResult(result, deleteLandCovers(params).getLand_covers_edit_result());
//			});
//
//			if(!updateLcGeoms.isEmpty()) {
//				UpdateLandCoversPayload updateLandCoversPayload = UpdateLandCoversPayload.builder()
//						.cut_behaviour(CutBehaviour.CUT_EXISTING)
//						.polygons(updateLcGeoms)
//						.build();
//				params.setLandCoverId(updateLcGeoms.keySet().iterator().next());
//
//				EditResult updateLcRes = updateLandCovers(params, updateLandCoversPayload, isForPreview);
//				mergeLandCoversEditResult(updateLcRes.getLand_covers_edit_result(), result);
//			}
//
//			updateLcCode.forEach((lcId, lcCode) -> {
//				params.setLandCoverId(lcId);
//				EditResult updateLcDataRes = updateLandCoverData(params, new UpdateLandCoversDataPayload(lcCode));
//				mergeLandCoversEditResult(updateLcDataRes.getLand_covers_edit_result(), result);
//			});
//
//			LandCoversEditResult createLcRes = createLandCoversFromCatalogueGeoms(params, newLcGeoms, isForPreview);
//			mergeLandCoversEditResult(createLcRes, result);
//		});
//
//		return result;
//	}
//
//	private List<CatalogueGeom> getIntersectedCatalogueGeom(EditorSupportParams params, String catalogueCode, Geometry geom){
//		CataloguePayload cataloguePayload = CataloguePayload.builder()
//				.geom(geom)
//				.srs(params.getSession().getLock_geom_srs())
//				.params(Map.of("referenceDate", params.getSession().getReference_date().toString())) //XXX TODO remove
//				.build();
//		
//		List<CatalogueGeom> catalogueGeoms = cataloguesService.getGeomsFromCatalogueList(params, catalogueCode, params.getSession().getReference_date(), cataloguePayload);
//		
//		List<CatalogueGeom> result = new ArrayList<>();
//		catalogueGeoms.forEach(cg -> {
//			Geometry intersectedGeom = cg.getGeom().intersection(geom);
//			if(!intersectedGeom.isEmpty() && intersectedGeom.isValid()) {
//				cg.setGeom(intersectedGeom);
//				result.add(cg);
//			}
//		});
//		
//		return result;
//	}

	// ----------------------------------------------------------------------------------------------------------------------

	public EditResult createLinearLandCovers(EditorSupportParams params, CreateLinearLandCoversPayload payload, Boolean isForPreview) {

		editLandCoversSupportService.checkCanEditLC(params, payload.getLand_cover_ids());

		if (Boolean.FALSE.equals(isForPreview))
			editSessionSupportService.refreshSession(params.getSession().getUuid());

		if (!(payload.getGeom() instanceof LineString)) {
			LandCoverGeometryNotLineException ex = new LandCoverGeometryNotLineException(Status.BAD_REQUEST, Operation.CREATE_LINEAR_LANDCOVER, ErrorField.GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Double buffer = payload.getBuffer_size();

		if (payload.getLine_buffer_behaviour().equals(LineBufferBehaviour.FREE_DRAW)) {
			buffer /= 2;
		}

		Polygonal linearGeom = Utils.getLinearPolygon((LineString) payload.getGeom(), buffer);
		Geometry reduceLinearGeom = Utils.reducePrecision((Geometry) linearGeom, false, false); // do no fixIfNecessary, do not tolerateAreaReduction

		Geometry reduceLandCoversGeom = null;
		if (payload.getLand_cover_ids() != null && !payload.getLand_cover_ids().isEmpty()) {
			Map<Long, Polygon> polygons = editLandCoversSupportService.loadLandCoverPolygons(params.getSession(), payload.getLand_cover_ids());

			Geometry landCoversGeom = Utils.getUnion(polygons.values());
			reduceLandCoversGeom = Utils.reducePrecision(landCoversGeom, false, false); // do no fixIfNecessary, do not tolerateAreaReduction
		} else {
			ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

			List<Geometry> parcelGeom = editParcelsDAO.getParcelGeomFromParcelId(env, params.getParcelId());
			if (parcelGeom == null || parcelGeom.isEmpty()) {
				InvalidSessionParcelIdException ex = new InvalidSessionParcelIdException(Status.BAD_REQUEST,
						Operation.CREATE_LINEAR_LANDCOVER, ErrorField.PARCEL_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}

			reduceLandCoversGeom = Utils.reducePrecision(parcelGeom.get(0), false, false); // do no fixIfNecessary, do not tolerateAreaReduction
		}

		Geometry createGeom = payload.getLine_buffer_behaviour().equals(LineBufferBehaviour.EXTERNAL)
				? Utils.snappedDifferenceAB(reduceLinearGeom, reduceLandCoversGeom)
						: Utils.snappedIntersectionAB(reduceLandCoversGeom, reduceLinearGeom);

		return createLandCovers(params, new CreateLandCoversPayload(createGeom, null, CutBehaviour.CUT_EXISTING), isForPreview);
	}

	// ----------------------------------------------------------------------------------------------------------------------

	public EditResult updateLandCovers(EditorSupportParams params, UpdateLandCoversPayload payload, Boolean isForPreview) {

		List<Long> landCoverIds = payload.getPolygons().keySet().stream().collect(Collectors.toList());
		editLandCoversSupportService.checkCanEditLC(params, landCoverIds);

		if (Boolean.FALSE.equals(isForPreview)) {
			editSessionSupportService.refreshSession(params.getSession().getUuid());
		}
		
		Editor<Long> editor = editLandCoversSupportService.getEditor(params, payload.getCut_behaviour(), null, null, isForPreview, editorSupportFactory);

		checkUpdateLandCoversPayload(params, payload, landCoverIds);

		EditorResult<Long> result = new EditorResult<>();
		try {
			Map<Long, Polygon> polygons = payload.getPolygons().entrySet()
					.stream()
					.collect(Collectors.toMap(Map.Entry::getKey, e -> (Polygon)e.getValue()));

			result = editor.modifyPolygons(polygons);
		} catch (AbstractException e) {
			throwExceptionFromEditorOperation(e, params);
		}

		LandCoversEditResult landCoversEditResult = getEditLandCoverResult(result, params);

		editLandCoversSupportService.setTotaleUnitAreaSqm(landCoversEditResult);
		return new EditResult(null, evaluateLandCoverResult(isForPreview, params, result, landCoversEditResult));

	}
	
	private void checkUpdateLandCoversPayload(EditorSupportParams params, UpdateLandCoversPayload payload,
			List<Long> landCoverIds) {
		Boolean enabledMoveVertex = internalConf.getBooleanValue(params.getSession().getTenant_id(), InternalConfigKeys.ENABLE_MOVE_VERTEX.getKey());
		if((Boolean.FALSE.equals(enabledMoveVertex) && landCoverIds.size() != 1) || !landCoverIds.contains(params.getLandCoverId())) {
			InvalidPayloadException ex = new InvalidPayloadException(Status.BAD_REQUEST, Operation.UPDATE_LANDCOVER, ErrorField.LANDCOVER_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		if (payload.getBuffer() != null && payload.getBuffer() != 0) {
			if(landCoverIds.size() != 1) {
				InvalidPayloadException ex = new InvalidPayloadException(Status.BAD_REQUEST, Operation.UPDATE_LANDCOVER, ErrorField.LANDCOVER_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
			if (payload.getBuffer() < this.internalConf.getIntegerValue(params.getSession().getTenant_id(),
					InternalConfigKeys.MINIMUM_UPDATE_BUFFER_SIZE_KEY.getKey())) {
				UpdateBufferTooSmallException ex = new UpdateBufferTooSmallException(Status.BAD_REQUEST,
						Operation.UPDATE_LANDCOVER, ErrorField.BUFFER,
						this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}

			if (payload.getBuffer() > this.internalConf.getIntegerValue(params.getSession().getTenant_id(),
					InternalConfigKeys.MAXIMUM_UPDATE_BUFFER_SIZE_KEY.getKey())) {
				UpdateBufferTooLargeException ex = new UpdateBufferTooLargeException(Status.BAD_REQUEST,
						Operation.UPDATE_LANDCOVER, ErrorField.BUFFER,
						this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}

			Geometry updateGeom = payload.getPolygons().get(params.getLandCoverId()).buffer(payload.getBuffer());
			payload.getPolygons().replace(params.getLandCoverId(), updateGeom);
		}
	}

	public LandCoversEditResult updateParcelsLandCovers(EditorSupportParams params, UpdateParcelsPayload payload, EditorResult<Long> parcelEditorResult,
			Boolean isForPreview) {

		params.setOperation(Operation.UPDATE_PARCEL_LANDCOVERS);

		editLandCoversSupportService.checkCanEditLC(params, null);

		LandCoversEditResult res = new LandCoversEditResult();
		res.setAdded(new ArrayList<>());
		res.setUpdated(new ArrayList<>());
		res.setDeleted(new ArrayList<>());
		
		String lcOriginCatalogueCode = internalConf.getStringValue(params.getReqContext().getTenantId(), InternalConfigKeys.LANDCOVER_ORIGIN_CATALOGUE_CODE.getKey());
		if(!StringUtils.isBlank(lcOriginCatalogueCode)) {
//			return createOrUpdateParcelLandCoversFromCatalogue(params, lcOriginCatalogueCode, parcelEditorResult, isForPreview);
			return new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
		}

		Map<Long, Polygon> updatePolygons = getUpdatePolygonsMap(params, parcelEditorResult);

		// remove deleted polygons
		updatePolygons.values().removeAll(Collections.singleton(null));

		if (!updatePolygons.isEmpty()) {

			Editor<Long> editor = editLandCoversSupportService.getEditor(params, payload.getCut_behaviour(), parcelEditorResult, null, isForPreview,
					editorSupportFactory);

			EditorResult<Long> updateResult = new EditorResult<>();
			try {
				updateResult = editor.modifyPolygons(updatePolygons);
			} catch (AbstractException e) {
				throwExceptionFromEditorOperation(e, params);
			}

			addNotModifiedLandCoversFromParcelEditorResult(params, parcelEditorResult, updateResult);

			editLandCoversSupportService.editLandCoversEditResultAndLandCoverEditorResultFromParcel(params, parcelEditorResult, updateResult, res);

			if (Boolean.FALSE.equals(isForPreview))
				editLandCoversSupportService.persistEditorResult(params, updateResult, res);
		}

		editLandCoversSupportService.setTotaleUnitAreaSqm(res);
		return evaluateLandCoverResult(true, params, parcelEditorResult, res);

	}
	
	private Map<Long, Polygon> getUpdatePolygonsMap(EditorSupportParams params, EditorResult<Long> parcelEditorResult){
		List<Long> parcelsEdited = new ArrayList<>();
		parcelEditorResult.getCreated().keySet().stream().forEach(parcelsEdited::add);
		parcelEditorResult.getModified().keySet().stream().forEach(parcelsEdited::add);
		Map<Long, Polygon> updatePolygons = editLandCoversSupportService.findLandCoversPolygonsByParcels(params, parcelsEdited);
		
		List<Long> parcelsTopologyCorrected = new ArrayList<>(); 
		parcelEditorResult.getTopologyCorrected().keySet().stream().forEach(parcelsTopologyCorrected::add);
		updatePolygons.putAll(editLandCoversSupportService.findLandCoversPolygonsByParcels(params, parcelsTopologyCorrected, SKIP_FORBIDDEN_LC_CHECK));

		if(Boolean.TRUE.equals(internalConf.getBooleanValue(params.getReqContext().getTenantId(), InternalConfigKeys.PARCEL_LANDCOVER_ONE_TO_ONE.getKey()))) {
			Map<Long, Long> parcelLcIdsMap = getParcelLandCoverMap(params, parcelsEdited); 
			for (Long parcelId : parcelLcIdsMap.keySet()) {
				if(updatePolygons.containsKey(parcelLcIdsMap.get(parcelId))) {
					if(parcelEditorResult.getCreated().containsKey(parcelId)) {
						updatePolygons.put(parcelLcIdsMap.get(parcelId), parcelEditorResult.getCreated().get(parcelId));
					}
					if(parcelEditorResult.getModified().containsKey(parcelId)) {
						updatePolygons.put(parcelLcIdsMap.get(parcelId), parcelEditorResult.getModified().get(parcelId));
					}
				}
			}
		}

		return updatePolygons;
	}

	private Map<Long, Long> getParcelLandCoverMap(EditorSupportParams params, List<Long> parcelsEdited) {
		return editLandCoversSupportService.findLandCoversByParcels(params, parcelsEdited).stream()
				.collect(Collectors.groupingBy(
						LandCoverNTT::getParcel_id,
						Collectors.collectingAndThen(
								Collectors.maxBy(Comparator.comparingDouble(LandCoverNTT::getArea_sqm)),
								optionalLandCover -> optionalLandCover.map(LandCoverNTT::getLand_cover_id).orElse(null)
								)
						));
	}

	// ----------------------------------------------------------------------------------------------------------------------

	public EditResult deleteLandCovers(EditorSupportParams params) {

		editLandCoversSupportService.checkCanEditLC(params, null);

		editSessionSupportService.refreshSession(params.getSession().getUuid());

		editLandCoversSupportService.checkValidUnitsBeforUpdateOrDeleteLandCover(params, params.getLandCoverId());
		
		EditorResult<Long> result = new EditorResult<>();
		result.getDeleted().add(params.getLandCoverId());

		LandCoversEditResult landCoversEditResult = getEditLandCoverResult(result, params);

		editLandCoversSupportService.setTotaleUnitAreaSqm(landCoversEditResult);
		return new EditResult(null, evaluateLandCoverResult(false, params, result, landCoversEditResult));

	}

	public LandCoversEditResult deleteParcelsLandCovers(EditorSupportParams params, Boolean isForPreview) {

		params.setOperation(Operation.DELETE_PARCEL_LANDCOVERS);

		editLandCoversSupportService.checkCanEditLC(params, null);

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		EditorResult<Long> deleteResult = new EditorResult<>();

		List<LandCoverNTT> inEditLandCoversByParcel = editLandCoversDAO.findInEditBySessionId(env, params.getParcelId());
		if (inEditLandCoversByParcel != null) {
			inEditLandCoversByParcel.stream().forEach(l -> {
				editLandCoversSupportService.checkValidUnitsBeforUpdateOrDeleteLandCover(params, l.getLand_cover_id());
				deleteResult.getDeleted().add(l.getLand_cover_id());
			});
		}

		List<LandCoverNTT> notInEditLandCoversByParcel = editLandCoversDAO.findNotInEditBySessionId(env, params.getParcelId());
		if (notInEditLandCoversByParcel != null) {
			notInEditLandCoversByParcel.stream().forEach(l -> {
				editLandCoversSupportService.checkValidUnitsBeforUpdateOrDeleteLandCover(params, l.getLand_cover_id());
				deleteResult.getDeleted().add(l.getLand_cover_id());
			});
		}

		LandCoversEditResult landCoversEditResult = getEditLandCoverResult(deleteResult, params);

		editLandCoversSupportService.setTotaleUnitAreaSqm(landCoversEditResult);
		return evaluateLandCoverResult(isForPreview, params, deleteResult, landCoversEditResult);

	}

	// ----------------------------------------------------------------------------------------------------------------------

	public EditResult cutLandCoversByLine(EditorSupportParams params, CutLandCoversByLinePayload payload, Boolean isForPreview) {

		editLandCoversSupportService.checkCanEditLC(params, null);
		editSessionSupportService.refreshSession(params.getSession().getUuid());

		Long landCoverId = params.getLandCoverId();

		Map<Long, Polygon> cutPolygons = editLandCoversSupportService.loadLandCoverPolygons(params.getSession(), Arrays.asList(landCoverId));
		if (cutPolygons.keySet().size() != 1) {
			LandCoverIdsNotFoundException ex = new LandCoverIdsNotFoundException(Status.NOT_FOUND, Operation.CUT_LANDCOVERS, ErrorField.LANDCOVER_IDS,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Editor<Long> editor = editLandCoversSupportService.getEditor(params, CutBehaviour.CUT_ON_EXISTING, null, cutPolygons, isForPreview,
				editorSupportFactory);

		EditorResult<Long> result = new EditorResult<>();
		try {
			result = editor.cutPolygonsByLine((LineString) payload.getGeom());
		} catch (AbstractException e) {
			throwExceptionFromEditorOperation(e, params);
		}

		LandCoversEditResult landCoversEditResult = getEditLandCoverResult(result, params);
		evaluateLandCoverResult(isForPreview, params, result, landCoversEditResult);
		
		if(Boolean.FALSE.equals(isForPreview)) {
			editLandCoversSupportService.copyLandCoverUnits(params, landCoversEditResult, false);
		}

		editLandCoversSupportService.setTotaleUnitAreaSqm(landCoversEditResult);
		return new EditResult(null, landCoversEditResult);

	}

	public LandCoversEditResult cutParcelsLandCoversByLine(EditorSupportParams params, Geometry line, EditorResult<Long> parcelEditorResult,
			Boolean isForPreview) {

		params.setOperation(Operation.CUT_PARCELS_LANDCOVERS);

		editLandCoversSupportService.checkCanEditLC(params, null);

		if (line == null) {
			InvalidLandCoverGeometryException ex = new InvalidLandCoverGeometryException(Status.BAD_REQUEST, params.getOperation(), ErrorField.GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		String lcOriginCatalogueCode = internalConf.getStringValue(params.getReqContext().getTenantId(), InternalConfigKeys.LANDCOVER_ORIGIN_CATALOGUE_CODE.getKey());
		if(!StringUtils.isBlank(lcOriginCatalogueCode)) {
//			return createOrUpdateParcelLandCoversFromCatalogue(params, lcOriginCatalogueCode, parcelEditorResult, isForPreview);
			return new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
		}

		LandCoversEditResult res = new LandCoversEditResult();
		res.setAdded(new ArrayList<>());
		res.setUpdated(new ArrayList<>());
		res.setDeleted(new ArrayList<>());

		Map<Long, Polygon> cutPolygons = editLandCoversSupportService.findLandCoversPolygonsByParcels(params, Arrays.asList(params.getParcelId()));

		if (!cutPolygons.isEmpty()) {

			// remove deleted polygons
			cutPolygons.values().removeAll(Collections.singleton(null));

			Editor<Long> editor = editLandCoversSupportService.getEditor(params, CutBehaviour.CUT_ON_EXISTING, parcelEditorResult, cutPolygons, isForPreview,
					editorSupportFactory);

			EditorResult<Long> cutResult = new EditorResult<>();
			try {
				cutResult = editor.cutPolygonsByLine((LineString) line);
			} catch (AbstractException e) {
				throwExceptionFromEditorOperation(e, params);
			}

			addNotModifiedLandCoversFromParcelEditorResult(params, parcelEditorResult, cutResult);

			editLandCoversSupportService.editLandCoversEditResultAndLandCoverEditorResultFromParcel(params, parcelEditorResult, cutResult, res);

			if (Boolean.FALSE.equals(isForPreview))
				editLandCoversSupportService.persistEditorResult(params, cutResult, res);

		}
		
		evaluateLandCoverResult(true, params, parcelEditorResult, res);
		if(Boolean.FALSE.equals(isForPreview)) {
			editLandCoversSupportService.copyLandCoverUnits(params, res, false);
		}
		
		editLandCoversSupportService.setTotaleUnitAreaSqm(res);
		return res;
	}

	public LandCoversEditResult cutParcelsLandCovers(EditorSupportParams params, Geometry geom, EditorResult<Long> parcelEditorResult,
			Boolean isForPreview) {

		params.setOperation(Operation.CUT_PARCELS_LANDCOVERS);

		editLandCoversSupportService.checkCanEditLC(params, null);

		if (geom == null) {
			InvalidLandCoverGeometryException ex = new InvalidLandCoverGeometryException(Status.BAD_REQUEST, params.getOperation(), ErrorField.GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		String lcOriginCatalogueCode = internalConf.getStringValue(params.getReqContext().getTenantId(), InternalConfigKeys.LANDCOVER_ORIGIN_CATALOGUE_CODE.getKey());
		if(!StringUtils.isBlank(lcOriginCatalogueCode)) {
//			return createOrUpdateParcelLandCoversFromCatalogue(params, lcOriginCatalogueCode, parcelEditorResult, isForPreview);
			return new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
		}

		LandCoversEditResult res = new LandCoversEditResult();
		res.setAdded(new ArrayList<>());
		res.setUpdated(new ArrayList<>());
		res.setDeleted(new ArrayList<>());

		Map<Long, Polygon> cutPolygons = editLandCoversSupportService.findLandCoversPolygonsByParcels(params, Arrays.asList(params.getParcelId()));

		if (!cutPolygons.isEmpty()) {

			// remove deleted polygons
			cutPolygons.values().removeAll(Collections.singleton(null));

			Editor<Long> editor = editLandCoversSupportService.getEditor(params, CutBehaviour.CUT_ON_EXISTING, parcelEditorResult, cutPolygons, isForPreview,
					editorSupportFactory);

			EditorResult<Long> cutResult = editor.cutPolygonsByGeometries(List.of(geom));

			addNotModifiedLandCoversFromParcelEditorResult(params, parcelEditorResult, cutResult);

			editLandCoversSupportService.editLandCoversEditResultAndLandCoverEditorResultFromParcel(params, parcelEditorResult, cutResult, res);

			if (Boolean.FALSE.equals(isForPreview))
				editLandCoversSupportService.persistEditorResult(params, cutResult, res);

		}
		
		evaluateLandCoverResult(true, params, parcelEditorResult, res);
		if(Boolean.FALSE.equals(isForPreview)) {
			editLandCoversSupportService.copyLandCoverUnits(params, res, false);
		}
		
		editLandCoversSupportService.setTotaleUnitAreaSqm(res);
		return res;

	}

	public EditResult cutLandCovers(EditorSupportParams params, CutLandCoversPayload payload, Boolean isForPreview) {
		editLandCoversSupportService.checkCanEditLC(params, null);
		editSessionSupportService.refreshSession(params.getSession().getUuid());

		Long landCoverId = params.getLandCoverId();

		if(payload.getGeom() == null) {
			InvalidPayloadException ex = new InvalidPayloadException(Status.BAD_REQUEST, Operation.CUT_LANDCOVERS, ErrorField.GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Geometry geom = payload.getGeom();

		if(geom.getGeometryType().equals(Geometry.TYPENAME_POLYGON)) {
			return cutLandCoversInternal(params, isForPreview, landCoverId, geom);
		} 

		if(payload.getBuffer() != null 
				&& !payload.getBuffer().equals(0.0)) {
			geom = geom.buffer(payload.getBuffer());
		}

		if(geom.getGeometryType().equals(Geometry.TYPENAME_LINESTRING)) {
			return cutLandCoversByLine(params, CutLandCoversByLinePayload.builder().geom(geom).build(), isForPreview);
		} 

		if(geom.getGeometryType().equals(Geometry.TYPENAME_POINT)) {
			InvalidPayloadException ex = new InvalidPayloadException(Status.BAD_REQUEST, Operation.CUT_PARCEL, ErrorField.GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return cutLandCoversInternal(params, isForPreview, landCoverId, geom);
	}

	private EditResult cutLandCoversInternal(EditorSupportParams params, Boolean isForPreview, Long landCoverId,
			Geometry cutGeom) {
		Map<Long, Polygon> cutPolygons = editLandCoversSupportService.loadLandCoverPolygons(params.getSession(), Arrays.asList(landCoverId));
		if (cutPolygons.keySet().size() != 1) {
			LandCoverIdsNotFoundException ex = new LandCoverIdsNotFoundException(Status.NOT_FOUND, Operation.CUT_LANDCOVERS, ErrorField.LANDCOVER_IDS,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Editor<Long> editor = editLandCoversSupportService.getEditor(params, CutBehaviour.CUT_ON_EXISTING, null, cutPolygons, isForPreview,
				editorSupportFactory);

		EditorResult<Long> result = editor.insertPolygon((Polygonal) cutGeom, false, true);

		result.getCoveredByInserted().stream().forEach(id -> {
			if (result.getCreated().containsKey(id)) {
				result.getCreated().remove(id);
			} else {
				result.getModified().remove(id);
			}
		});

		LandCoversEditResult landCoversEditResult = getEditLandCoverResult(result, params);
		evaluateLandCoverResult(isForPreview, params, result, landCoversEditResult);
		if(Boolean.FALSE.equals(isForPreview)) {
			editLandCoversSupportService.copyLandCoverUnits(params, landCoversEditResult, false);
		}
		
		editLandCoversSupportService.setTotaleUnitAreaSqm(landCoversEditResult);
		return new EditResult(null, landCoversEditResult);
	}

	// ----------------------------------------------------------------------------------------------------------------------

	public EditResult mergeLandCovers(EditorSupportParams params, MergeLandCoversPayload payload, Boolean isForPreview, Boolean onlyMergeGeometries) {
		editLandCoversSupportService.checkCanEditLC(params, payload.getLand_cover_ids());

		if (Boolean.FALSE.equals(isForPreview))
			editSessionSupportService.refreshSession(params.getSession().getUuid());

		Editor<Long> editor = editLandCoversSupportService.getEditor(params, CutBehaviour.CUT_EXISTING, null, null, isForPreview, editorSupportFactory);

		List<Long> landCoverIds = payload.getLand_cover_ids();

		Map<Long, Polygon> editPolygons = editLandCoversSupportService.loadLandCoverPolygons(params.getSession(), landCoverIds);
		if (editPolygons.keySet().size() != landCoverIds.size()) {
			LandCoverIdsNotFoundException ex = new LandCoverIdsNotFoundException(Status.NOT_FOUND, Operation.MERGE_LANDCOVERS, ErrorField.LANDCOVER_IDS,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		// To help the client, in linear elements creation, if needed, only in preview, can simple merge the geometries of selected landcovers
		if (isForPreview && onlyMergeGeometries) {
			EditorResult<Long> onlyMergeresult = new EditorResult<>();

			Geometry merged = Utils.getUnion(editPolygons.values());
			if (merged instanceof MultiPolygon) {
				MultiPolygon mp = (MultiPolygon) merged;
				Long fakeIndex = -314159265359L;
				for (int i = 0; i < mp.getNumGeometries(); i++)
					onlyMergeresult.getCreated().put(fakeIndex - i, (Polygon) mp.getGeometryN(i));
			} else {
				onlyMergeresult.getCreated().put(0L, (Polygon) merged);
			}

			LandCoversEditResult landCoversEditResult = getEditLandCoverResult(onlyMergeresult, params);
			
			return new EditResult(null, landCoversEditResult);
		}
		// --

		EditorResult<Long> result = new EditorResult<>();
		try {
			result = editor.mergePolygons(editPolygons, params.getLandCoverId());
		} catch (AbstractException e) {
			throwExceptionFromEditorOperation(e, params);
		}

		LandCoversEditResult landCoversEditResult = getEditLandCoverResult(result, params);
		evaluateLandCoverResult(isForPreview, params, result, landCoversEditResult);
		
		if(Boolean.FALSE.equals(isForPreview)) {
			editLandCoversSupportService.mergeLandCoverUnits(params, landCoversEditResult);
		}

		editLandCoversSupportService.setTotaleUnitAreaSqm(landCoversEditResult);
		return new EditResult(null, landCoversEditResult);

	}

	public LandCoversEditResult mergeParcelsLandCovers(EditorSupportParams params, List<Long> mergedParcelsIds, EditorResult<Long> parcelEditorResult,
			Boolean isForPreview) {

		params.setOperation(Operation.MERGE_PARCEL_LANDCOVERS);

		editLandCoversSupportService.checkCanEditLC(params, null);

		if (mergedParcelsIds == null || mergedParcelsIds.isEmpty() || !mergedParcelsIds.contains(params.getParcelId())) {
			InvalidParcelDataException ex = new InvalidParcelDataException(Status.BAD_REQUEST, Operation.MERGE_PARCEL_LANDCOVERS, ErrorField.PARCEL_IDS,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Map<Long, Polygon> mergePolygons = editLandCoversSupportService.findLandCoversPolygonsByParcels(params, mergedParcelsIds);
		
		if(Boolean.TRUE.equals(internalConf.getBooleanValue(params.getReqContext().getTenantId(), InternalConfigKeys.PARCEL_LANDCOVER_ONE_TO_ONE.getKey()))) {
			return mergeOneToOneParcelsLandCovers(params, mergedParcelsIds, parcelEditorResult, isForPreview);
		}

		LandCoversEditResult res = new LandCoversEditResult();
		res.setAdded(new ArrayList<>());
		res.setUpdated(new ArrayList<>());
		res.setDeleted(new ArrayList<>());

		if (!mergePolygons.isEmpty()) {

			// remove deleted polygons
			mergePolygons.values().removeAll(Collections.singleton(null));

			Editor<Long> editor = editLandCoversSupportService.getEditor(params, CutBehaviour.CUT_EXISTING, parcelEditorResult, null, isForPreview,
					editorSupportFactory);

			EditorResult<Long> mergeResult = new EditorResult<>();
			try {
				mergeResult = editor.modifyPolygons(mergePolygons);
			} catch (AbstractException e) {
				throwExceptionFromEditorOperation(e, params);
			}

			editLandCoversSupportService.editLandCoversEditResultAndLandCoverEditorResultFromParcel(params, parcelEditorResult, mergeResult, res);

			if (Boolean.FALSE.equals(isForPreview))
				editLandCoversSupportService.persistEditorResult(params, mergeResult, res);

		}
		
		evaluateLandCoverResult(true, params, parcelEditorResult, res);

		if(Boolean.FALSE.equals(isForPreview)) {
			editLandCoversSupportService.mergeParcelLandCoverUnits(params, res);
		}
		
		editLandCoversSupportService.setTotaleUnitAreaSqm(res);
		return res;

	}

	private LandCoversEditResult mergeOneToOneParcelsLandCovers(EditorSupportParams params, List<Long> mergedParcelsIds,
			EditorResult<Long> parcelEditorResult, Boolean isForPreview) {
		Long parcelId = params.getParcelId();
		Map<Long, Long> parcelLcIdsMap = getParcelLandCoverMap(params, mergedParcelsIds); 
		mergedParcelsIds.stream()
		.filter(id -> !parcelId.equals(id))
		.forEach(id -> {
			params.setParcelId(id);
			deleteParcelsLandCovers(params, isForPreview);
		});
		
		Map<Long, Geometry> payloadMap = new HashMap<>();
		payloadMap.put(parcelId, parcelEditorResult.getModified().get(parcelId));
		params.setParcelId(parcelId);
		params.setLandCoverId(parcelLcIdsMap.get(parcelId));
		
		UpdateParcelsPayload updateLandCoversPayload = UpdateParcelsPayload.builder()
				.polygons(payloadMap)
				.cut_behaviour(CutBehaviour.CUT_EXISTING)
				.build();
		
		return updateParcelsLandCovers(params, updateLandCoversPayload, parcelEditorResult, isForPreview);
	}

	public LandCoversEditResult mergeLandCoversWithSameCode(EditorSupportParams params, Boolean isForPreview) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		Long parcelId = params.getParcelId();

		Map<Long, LandCoverNTT> currentLandCoversMap = editLandCoversSupportService.getCurrentLandCoversMap(env, parcelId);

		Map<Long, Set<Long>> mergedLandCovers = new HashMap<>();
		Map<Long, Long> deletedLandCovers = new HashMap<>();

		currentLandCoversMap.forEach((id, landCoverToMerge) -> {
			if (!deletedLandCovers.containsKey(id) && !landCoverToMerge.getEdit_status().equals(EditStatus.DELETED)) {

				List<LandCoverNTT> landCoversWithInteractionWithSameCode = editLandCoversSupportService.getLandCoversWithInteractionWithSameCode(env,
						landCoverToMerge, parcelId);

				Set<Long> idsToAdd = getIdsToAdd(id, landCoversWithInteractionWithSameCode, mergedLandCovers, deletedLandCovers);
				idsToAdd.add(id);
				mergedLandCovers.put(id, idsToAdd);

			}
		});

		// EditorResult<Long> result = new EditorResult<>();
		LandCoversEditResult result = LandCoversEditResult.builder().added(new ArrayList<>()).deleted(new ArrayList<>()).updated(new ArrayList<>()).build();

		mergedLandCovers.forEach((idToPreserve, landCoverIds) -> {
			params.setLandCoverId(idToPreserve);
			/*
			 * EditorResult<Long> mergeResult = mergeLandCovers(params, new MergeLandCoversPayload(landCoverIds.stream().collect(toList())), isForPreview,
			 * false);
			 */
			EditResult mergeResult = mergeLandCovers(params, new MergeLandCoversPayload(landCoverIds.stream().collect(toList())),
					isForPreview, false);

			result.getAdded().addAll(mergeResult.getLand_covers_edit_result().getAdded());
			result.getDeleted().addAll(mergeResult.getLand_covers_edit_result().getDeleted());
			result.getUpdated().addAll(mergeResult.getLand_covers_edit_result().getUpdated());
			/*
			 * result.getCreated().putAll(mergeResult.getCreated()); result.getDeleted().addAll(mergeResult.getDeleted());
			 * result.getModified().putAll(mergeResult.getModified()); result.getTopologyCorrected().putAll(mergeResult.getTopologyCorrected());
			 */
		});

		Boolean flHideLandCovers = internalConf.getBooleanValue(params.getSession().getTenant_id(), InternalConfigKeys.FL_HIDE_LANDCOVERS_LAYER.getKey());
		if(Boolean.TRUE.equals(flHideLandCovers)) {
			return new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
		} else {
			editLandCoversSupportService.setTotaleUnitAreaSqm(result);
			return result;
		}
	}

	// ----------------------------------------------------------------------------------------------------------------------

	public EditResult updateLandCoverData(EditorSupportParams params, UpdateLandCoversDataPayload payload) {

		String sessionId = params.getSession().getUuid();

		editLandCoversSupportService.checkCanEditLC(params, null);
		editSessionSupportService.refreshSession(params.getSession().getUuid());
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		checkForbiddenEditLcCode(env, payload.getCode());

		EditorResult<Long> result = new EditorResult<>();

		List<LandCoverNTT> editLandCovers = editLandCoversDAO.getEditLandCoversFromLandCoverIdsBySession(env, Arrays.asList(params.getLandCoverId()));
		
		editLandCoversSupportService.checkValidUnitsBeforUpdateOrDeleteLandCover(params, params.getLandCoverId());
		
		// insert edit parcels and map parcels ids with edit parcels ids
		ParcelNTT editParcel = editParcelsDAO.findInEditBySessionId(sessionId, params.getSession().getReference_date(), params.getParcelId()).stream()
				.findFirst().orElse(null);
		ParcelNTT parcelToInsert = null;
		Long editParcelId = null;
		if (editParcel == null) {
			parcelToInsert = editParcelsDAO.findNotInEditBySessionId(env, params.getParcelId()).get(0);
			editParcelId = editParcelsDAO.nextSequenceVal();
			parcelToInsert.setEdit_id(editParcelId);
			parcelToInsert.setEdit_status(EditStatus.ONLY_LANDCOVERS);
		} else {
			editParcelId = editParcel.getEdit_id();
		}

		if (editLandCovers != null && !editLandCovers.isEmpty()) {
			LandCoverNTT landCover = editLandCovers.get(0);
			landCover.setLand_cover_code(payload.getCode());
			landCover.setEdit_status(EditStatus.IN_EDIT);
			// is a plus
			if (parcelToInsert != null) {
				editSessionSupportService.checkAndInsertEditParcel(params, parcelToInsert);
				landCover.setEdit_parcel_id(editParcelId);
			}

			editLandCoversDAO.updateLandCoverCodeByLandCoverId(landCover, sessionId);

			result.getModified().put(params.getLandCoverId(), (Polygon) landCover.getGeom());
		} else {
			LandCoverNTT landCover = landCoverDAO.getLandCoverDetail(env, params.getLandCoverId());
			if (landCover != null) {
				Long nextEditId = editLandCoversDAO.nextSequenceVal();
				landCover.setEdit_id(nextEditId);
				landCover.setLand_cover_code(payload.getCode());
				landCover.setEdit_parcel_id(editParcelId);
				landCover.setEdit_status(EditStatus.IN_EDIT);

				if (parcelToInsert != null) {
					editSessionSupportService.checkAndInsertEditParcel(params, parcelToInsert);
				}

				editLandCoversDAO.insert(landCover, sessionId);
				result.getModified().put(params.getLandCoverId(), (Polygon) landCover.getGeom());
			}
		}
		Boolean flHideLandCovers = internalConf.getBooleanValue(params.getSession().getTenant_id(), InternalConfigKeys.FL_HIDE_LANDCOVERS_LAYER.getKey());
		if(Boolean.TRUE.equals(flHideLandCovers)) {
			return new EditResult(null, new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>()));
		} else {
			LandCoversEditResult lcEditResult = getEditLandCoverResult(result, params);
			editLandCoversSupportService.addUnitsToLandCoverEditResult(params, lcEditResult);
			lcEditResult.getUpdated().forEach(lc -> editLandCoversSupportService.cleanUpIncompatibleUnits(params, lc));
			
			editLandCoversSupportService.setTotaleUnitAreaSqm(lcEditResult);
			return new EditResult(null, lcEditResult);
		}
	}

	// ----------------------------------------------------------------------------------------------------------------------

	public LandCoversEditResult updateLandCoversFromUpdateParcelData(EditorSupportParams params, ParcelNTT oldParcel, ParcelNTT newParcel) {
		LandCoversEditResult res = new LandCoversEditResult();
		res.setAdded(new ArrayList<>());
		res.setUpdated(new ArrayList<>());
		res.setDeleted(new ArrayList<>());

		params.setOperation(Operation.UPDATE_LANDCOVERS_ON_PARCEL_DATA);

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		List<LandCoverNTT> landCoversToDelete = retrieveLandCoversToDelete(oldParcel, env);

		landCoversToDelete.forEach(landCover -> {
			AbsoluteDate dayTo = landCover.getDay_to() != null ? landCover.getDay_to() : END_OF_WORLD;
			AbsoluteDate dayFrom = landCover.getDay_from() != null ? landCover.getDay_from() : env.getReferenceDate();
			String srs = landCover.getSrs() != null ? landCover.getSrs() : params.getSession().getLock_geom_srs();
			Geometry geom = landCover.getGeom();
			Double area = landCover.getArea_sqm();

			LandCoverNTT landCoverToInsert = LandCoverNTT.builder()
					.area_sqm(area)
					.geom(geom)
					.land_cover_code(landCover.getLand_cover_code())
					.edit_parcel_id(newParcel.getEdit_id())
					.land_cover_id(editLandCoversDAO.nextNewLandCoverIdVal())
					.edit_id(editLandCoversDAO.nextSequenceVal())
					.edit_status(EditStatus.IN_EDIT)
					.parent_id(landCover.getLand_cover_id())
					.build();

			if (landCover.getEdit_id() == null) {
				landCover.setEdit_status(EditStatus.NOT_IN_EDIT);
				landCover.setEdit_id(editLandCoversDAO.nextSequenceVal());
				landCover.setEdit_parcel_id(oldParcel.getEdit_id());
				editLandCoversDAO.insert(landCover, env.getSessionId());
			} 

			editLandCoversDAO.insert(landCoverToInsert, env.getSessionId());

			LayerStyle style = this.styleService.getLandCoverLayerStyle(env.getTenantId(), env.getReferenceDate(), landCoverToInsert.getLand_cover_code());

			// update landCoversEditResult
			LandCoverWithUnits landCoverResToAdd = LandCoverWithUnits.builder()
					.area_sqm(Math.round(landCoverToInsert.getArea_sqm()))
					.code(landCoverToInsert.getLand_cover_code())
					.day_from(dayFrom)
					.day_to(dayTo)
					.geom(landCoverToInsert.getGeom())
					.id(landCoverToInsert.getLand_cover_id())
					.parcel_id(newParcel.getParcel_id())
					.srs(srs)
					.layer_style(style)
					.edit_status(landCoverToInsert.getEdit_status())
					.parent_id(landCover.getLand_cover_id())
					.build();

			res.getDeleted().add(landCover.getLand_cover_id());
			res.getAdded().add(landCoverResToAdd);
		});

		Boolean flHideLandCovers = internalConf.getBooleanValue(params.getSession().getTenant_id(), InternalConfigKeys.FL_HIDE_LANDCOVERS_LAYER.getKey());
		if(Boolean.TRUE.equals(flHideLandCovers)) {
			return new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
		}
		
		editLandCoversSupportService.addUnitsToLandCoverEditResult(params, res);
		editLandCoversSupportService.copyLandCoverUnits(params, res, true);
		editLandCoversSupportService.setTotaleUnitAreaSqm(res);
		
		landCoversToDelete.forEach(landCover -> {
			landCover.setArea_sqm(0.0);
			landCover.setGeom(null);
			landCover.setEdit_status(EditStatus.DELETED);

			if (landCover.getEdit_id() == null) {
				landCover.setEdit_id(editLandCoversDAO.nextSequenceVal());
				landCover.setEdit_parcel_id(oldParcel.getEdit_id());
				editLandCoversDAO.insert(landCover, env.getSessionId());
			} else {
				editLandCoversDAO.updateByLandCoverId(landCover, env.getSessionId());
			}
		});
		
		return res;
	}
	// ----------------------------------------------------------------------------------------------------------------------

	private List<LandCoverNTT> retrieveLandCoversToDelete(ParcelNTT oldParcel, ServiceSupportEnv env) {
		List<LandCoverNTT> landCoversToDelete = new ArrayList<>();

		List<LandCoverNTT> editLandCovers = editLandCoversDAO.findInEditBySessionId(env, oldParcel.getParcel_id());
		if (editLandCovers != null) {
			landCoversToDelete.addAll(editLandCovers);
		}

		List<LandCoverNTT> notEditLandCovers = editLandCoversDAO.findNotInEditBySessionId(env, oldParcel.getParcel_id());
		if (notEditLandCovers != null) {
			landCoversToDelete.addAll(notEditLandCovers);
		}
		return landCoversToDelete;
	}

	public GeometryIntersection getIntersectGeomsFromCatalogue(EditorSupportParams params, String catalogueCode, OverlayType overlayType, GeometryIntersectionPayload payload) {

		editSessionSupportService.checkEditableSession(params, Operation.CHECK_CAN_EDIT_LANDCOVER);
		
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		
		Catalogue catalogue = cataloguesService.getCatalogueByCodeAndSrs(env, catalogueCode, SHOW_ALL_CATALOGUES);
		if(catalogue == null) {
			CatalogueIdNotFoundException ex = new CatalogueIdNotFoundException(Status.BAD_REQUEST,
					params.getOperation(), ErrorField.CATALOGUE,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getReqContext().getTenantId()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Long landCoverId = params.getLandCoverId();

		Map<Long, Polygon> landCoversGeomMap = editLandCoversSupportService.loadLandCoverPolygons(params.getSession(), Arrays.asList(landCoverId));
		if (landCoversGeomMap.keySet().size() != 1) {
			LandCoverIdsNotFoundException ex = new LandCoverIdsNotFoundException(Status.NOT_FOUND, params.getOperation(), ErrorField.LANDCOVER_IDS,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Geometry landCoverGeom = Utils.getUnion(landCoversGeomMap.values());
	
		CataloguePayload cataloguePayload = CataloguePayload.builder()
				.geom(payload.getGeom())
				.srs(payload.getSrs())
				.params(payload.getParams())
				.build();
		List<Geometry> catalogueGeoms = cataloguesService.getGeomsFromCatalogueList(env, catalogue.getCode(), params.getSession().getReference_date(), cataloguePayload).stream()
				.map(CatalogueGeom::getGeom)
				.collect(Collectors.toList());
		if(!catalogueGeoms.isEmpty() && landCoverGeom != null) {	
			Geometry catalogueGeom = Utils.getUnion(catalogueGeoms);
			
			if(OverlayType.INTERSECTION.equals(overlayType)) {
				return GeometryIntersection.builder()
						.geom(landCoverGeom.intersection(catalogueGeom))
						.srs(payload.getSrs())
						.build();
			} else if(OverlayType.DIFFERENCE.equals(overlayType)) {
				return GeometryIntersection.builder()
						.geom(landCoverGeom.difference(catalogueGeom))
						.srs(payload.getSrs())
						.build();
			}
		}

		return GeometryIntersection.builder().geom(null).srs(payload.getSrs()).build();
	}

	// ----------------------------------------------------------------------------------------------------------------------

	public EditResult fillLandCover(EditorSupportParams params, Boolean isForPreview) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()));

		Map<Long, Polygon> parcelsMap = editLandCoversSupportService.loadParcelPolygons(params, Arrays.asList(params.getParcelId()));
		// If the parcel id is not in the parcelsMap.
		if (!parcelsMap.containsKey(params.getParcelId())) {
			InvalidSessionParcelIdException ex = new InvalidSessionParcelIdException(Status.BAD_REQUEST,
					Operation.FILL_LANDCOVER, ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Polygon parcelGeom = parcelsMap.get(params.getParcelId());

		Map<Long, LandCoverNTT> landCoverMap = editLandCoversSupportService.getCurrentLandCoversMap(env, params.getParcelId());
		LandCoverNTT currentLc = landCoverMap.get(params.getLandCoverId());
		if (currentLc == null || currentLc.getGeom() == null) {
			LandCoverNotFoundException ex = new LandCoverNotFoundException(Status.BAD_REQUEST,
					Operation.FILL_LANDCOVER, ErrorField.LANDCOVER_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		CreateLandCoversPayload landCoversPayload = new CreateLandCoversPayload(
				parcelGeom,
				currentLc.getLand_cover_code(),
				CutBehaviour.CUT_ON_EXISTING);

		LandCoversEditResult lcEditorResult = createLandCovers(params, landCoversPayload, true).getLand_covers_edit_result();

		List<Geometry> geomertiesToMerge = new ArrayList<>();
		geomertiesToMerge.add(currentLc.getGeom());
		lcEditorResult.getAdded().stream()
		.forEach(lc -> {
			if(currentLc.getGeom().intersects(lc.getGeom())) {
				geomertiesToMerge.add(lc.getGeom());
			}
		});

		if(geomertiesToMerge.size() > 1) {
			Map<Long, Geometry> landcoverMap = new HashMap<>();
			landcoverMap.put(currentLc.getLand_cover_id(), Utils.getUnion(geomertiesToMerge));
			UpdateLandCoversPayload updatePayload = UpdateLandCoversPayload.builder()
					.polygons(landcoverMap)
					.build();
			return updateLandCovers(params, updatePayload, isForPreview);
		}

		return new EditResult(null, new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>()));
	}

	// ----------------------------------------------------------------------------------------------------------------------

	private void addNotModifiedLandCoversFromParcelEditorResult(EditorSupportParams params, EditorResult<Long> parcelEditorResult,
			EditorResult<Long> landCoverEditorResult) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		parcelEditorResult.getDeleted().forEach(parcelId -> addNotModifiedLandCovers(env, parcelId, landCoverEditorResult));

		parcelEditorResult.getModified().forEach((parcelId, parcelGeom) -> addNotModifiedLandCovers(env, parcelId, landCoverEditorResult));

		parcelEditorResult.getTopologyCorrected().forEach((parcelId, parcelGeom) -> addNotModifiedLandCovers(env, parcelId, landCoverEditorResult));

	}

	private void addNotModifiedLandCovers(ServiceSupportEnv env, Long parcelId, EditorResult<Long> landCoverEditorResult) {
		Map<Long, LandCoverNTT> parcelLandCovers = editLandCoversSupportService.getCurrentLandCoversMap(env, parcelId);
		parcelLandCovers.forEach((landCoverId, landCover) -> {
			if (!landCoverEditorResult.getModified().containsKey(landCoverId) &&
					!landCoverEditorResult.getTopologyCorrected().containsKey(landCoverId) && // search in modified and topology corrected
					!landCoverEditorResult.getDeleted().contains(landCoverId) && // just in case
					landCover.getGeom() != null) {

				landCoverEditorResult.getModified().put(landCoverId, (Polygon) landCover.getGeom());

			}
		});
	}

	private Long getMergedLandCoverId(Long id, Map<Long, Long> deletedLandCovers) {
		if (id == null) {
			return null;
		}

		if (deletedLandCovers.containsKey(id)) {
			return getMergedLandCoverId(deletedLandCovers.get(id), deletedLandCovers);
		}

		return id;
	}

	private LandCoversEditResult getEditLandCoverResult(EditorResult<Long> editorLandCoverResult, EditorSupportParams params) {
		EditorResult<Long> parcelEditorResult = editLandCoversSupportService.createParcelEditorResultWithParamsParcelId(params);
		addParcelsTopologyCorrectedOnParcelEditorResult(params, parcelEditorResult, editorLandCoverResult);

		LandCoversEditResult res = new LandCoversEditResult();
		res.setAdded(new ArrayList<>());
		res.setUpdated(new ArrayList<>());
		res.setDeleted(new ArrayList<>());

		editLandCoversSupportService.editLandCoversEditResultAndLandCoverEditorResultFromParcel(params, parcelEditorResult, editorLandCoverResult, res);

		return res;
	}

	private void addParcelsTopologyCorrectedOnParcelEditorResult(EditorSupportParams params, EditorResult<Long> parcelEditorResult,
			EditorResult<Long> landCoverEditorResult) {

		if (landCoverEditorResult.getTopologyCorrected() != null && !landCoverEditorResult.getTopologyCorrected().isEmpty()) {
			ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

			List<Long> landCoverTopologyCorrectedIds = new ArrayList<>(landCoverEditorResult.getTopologyCorrected().keySet());

			List<LandCoverNTT> landCoversTopologyCorrected = new ArrayList<>();

			List<LandCoverNTT> landCoversInEditTopologyCorrected = editLandCoversDAO.getEditLandCoversFromLandCoverIdsBySession(env,
					landCoverTopologyCorrectedIds);
			landCoversTopologyCorrected.addAll(landCoversInEditTopologyCorrected);

			List<LandCoverNTT> landCoversNotInEditTopologyCorrected = editLandCoversDAO.getNotInEditingPolygons(env.getReferenceDate(),
					landCoverTopologyCorrectedIds);
			landCoversTopologyCorrected.addAll(landCoversNotInEditTopologyCorrected);

			List<Long> parcelIds = landCoversTopologyCorrected.parallelStream().map(LandCoverNTT::getParcel_id).collect(toList());
			parcelIds = parcelIds.parallelStream()
					.filter(id -> !parcelEditorResult.getCreated().containsKey(id)
							&& !parcelEditorResult.getModified().containsKey(id)
							&& !parcelEditorResult.getTopologyCorrected().containsKey(id)
							&& !parcelEditorResult.getDeleted().contains(id))
					.collect(toList());

			if (!parcelIds.isEmpty()) {
				List<ParcelNTT> parcels = new ArrayList<>();
				parcels.addAll(editParcelsDAO.getInEditingPolygons(parcelIds));
				parcels.addAll(editParcelsDAO.getNotInEditingPolygons(env, parcelIds));

				parcels.forEach(parcel -> parcelEditorResult.getTopologyCorrected().put(parcel.getParcel_id(), (Polygon) parcel.getGeom()));
			}

		}
	}

	private Set<Long> getIdsToAdd(Long id, List<LandCoverNTT> landCoversWithInteractionWithSameCode,
			Map<Long, Set<Long>> mergedLandCovers, Map<Long, Long> deletedLandCovers){

		Set<Long> idsToAdd = new HashSet<>();
		if (landCoversWithInteractionWithSameCode != null && landCoversWithInteractionWithSameCode.size() > 1) {
			landCoversWithInteractionWithSameCode.forEach(lc -> {
				Long idToAdd = getMergedLandCoverId(lc.getLand_cover_id(), deletedLandCovers);
				if (mergedLandCovers.containsKey(idToAdd)) {
					idsToAdd.addAll(mergedLandCovers.get(idToAdd));
				}
				idsToAdd.add(idToAdd);
				if (!idToAdd.equals(id)) {
					deletedLandCovers.put(idToAdd, id);
					mergedLandCovers.remove(idToAdd);
				}
			});
		}

		return idsToAdd;
	}

	private LandCoversEditResult evaluateLandCoverResult(Boolean isForPreview, EditorSupportParams params, EditorResult<Long> createResult, LandCoversEditResult res) {
		if (Boolean.FALSE.equals(isForPreview))
			editLandCoversSupportService.persistEditorResult(params, createResult, res);

		Boolean flHideLandCovers = internalConf.getBooleanValue(params.getSession().getTenant_id(), InternalConfigKeys.FL_HIDE_LANDCOVERS_LAYER.getKey());

		if(Boolean.TRUE.equals(flHideLandCovers)) {
			return new LandCoversEditResult(new ArrayList<>(), new ArrayList<>(), new ArrayList<>()); 
		}
		
		editLandCoversSupportService.addUnitsToLandCoverEditResult(params, res);
		
		return res;
	}

}
