package com.abacogroup.lpisgisserver.core.pub;

import com.abacogroup.lpisgisserver.core.BaseService;
import com.abacogroup.lpisgisserver.core.BlockService;
import com.abacogroup.lpisgisserver.core.ErrorDescriptionsService;
import com.abacogroup.lpisgisserver.core.ExternalConfigService;
import com.abacogroup.lpisgisserver.core.InternalConfigService;
import com.abacogroup.lpisgisserver.core.StyleService;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.exceptions.location.OutOfRangeException;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.pub.PublicBlocksSearchPayload;
import com.abacogroup.lpisgisserver.resources.res.Block;
import com.abacogroup.lpisgisserver.resources.res.pub.BlockWithGeomV1;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BlocksV1Service extends BaseService {
	
	private BlockService blockService;

	public BlocksV1Service(DAOContainer dc, BlockService blockService, InternalConfigService conf, ExternalConfigService externalConf, 
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);
		
		this.blockService = blockService;
	}

	public BlockWithGeomV1 findBlockByGeom(ServiceSupportEnv env, @NotNull @Valid PublicBlocksSearchPayload searchFilters) {
		Block block = blockService.findBlockByGeom(env, searchFilters.getGeom(), searchFilters.getSrs());
		
		if(block == null) {
			OutOfRangeException ex = new OutOfRangeException(Status.BAD_REQUEST, env.getOperation(), ErrorField.GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		return BlockWithGeomV1.builder()
				.id(block.getId())
				.sector_id(block.getSector_id())
				.description(block.getDescription())
				.short_descr(block.getShort_descr())
				.block_code(block.getBlock_code())
				.srs(env.getIncludeGeometries() == 1 ? block.getSrs() : null)
				.geom(env.getIncludeGeometries() == 1 ? block.getGeom() : null)
				.worldGeom(env.getIncludeGeometries() == 1 ? block.getWorld_geom() : null)
				.build();
	}

}
