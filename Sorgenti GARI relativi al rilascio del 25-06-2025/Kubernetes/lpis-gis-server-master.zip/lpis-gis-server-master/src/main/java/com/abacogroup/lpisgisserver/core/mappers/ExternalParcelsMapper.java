package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.ExternalSourceParcelNTT;
import com.abacogroup.lpisgisserver.resources.res.ExternalSourceParcel;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ExternalParcelsMapper {
	ExternalParcelsMapper INSTANCE = Mappers.getMapper(ExternalParcelsMapper.class);

	@InheritInverseConfiguration()
	ExternalSourceParcel entityToDto(ExternalSourceParcelNTT entity);

	ExternalSourceParcelNTT dtoToEntity(ExternalSourceParcel dto);
}
