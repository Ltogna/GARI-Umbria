package com.abacogroup.lpisgisserver.core.exceptions.area;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class GenericAreaException extends AbstractException {

	private static final long serialVersionUID = -7051044854813549959L;

	private static final ErrorCode ERROR_CODE = ErrorCode.GENERIC_AREAS_ERROR;

	public GenericAreaException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new GenericAreaExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Generic area error")
	public static class GenericAreaExceptionBody extends AbstractExceptionBody {

		private static final long serialVersionUID = 1152549761827624684L;

		public GenericAreaExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
