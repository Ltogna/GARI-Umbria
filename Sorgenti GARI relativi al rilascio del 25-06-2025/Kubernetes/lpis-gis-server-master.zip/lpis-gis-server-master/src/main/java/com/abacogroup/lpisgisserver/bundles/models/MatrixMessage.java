package com.abacogroup.lpisgisserver.bundles.models;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MatrixMessage {
	private String code;
	private List<MatrixClassMessage> classes;
}
