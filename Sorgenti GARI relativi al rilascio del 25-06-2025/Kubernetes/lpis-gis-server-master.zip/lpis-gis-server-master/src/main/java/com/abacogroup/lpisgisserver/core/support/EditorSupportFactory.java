package com.abacogroup.lpisgisserver.core.support;

import java.util.Map;

import org.locationtech.jts.geom.Polygon;

import com.abacogroup.geometryeditor.EditorResult;
import com.abacogroup.geometryeditor.EditorSupport;
import com.abacogroup.lpisgisserver.core.enums.CutBehaviour;

@FunctionalInterface
public interface EditorSupportFactory<K>
{
	EditorSupport<K> createEditorSupport(
			EditorSupportParams params, 
			CutBehaviour cutBehaviour, 
			EditorResult<Long> parcelEditorResult,
			Map<Long, Polygon> cutPolygons,
			boolean isForPreview,
			long lastPreviewKey
		);
}
