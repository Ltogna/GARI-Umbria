package com.abacogroup.lpisgisserver.core;

import java.sql.Clob;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abacogroup.lpisgisserver.core.models.Config;
import com.abacogroup.lpisgisserver.core.models.ExternalConfig;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.ExternalConfigDAO;
import com.abacogroup.lpisgisserver.db.ntt.ExternalConfigNTT;

public class ExternalConfigService extends AbstractConfigService {

	private ExternalConfigDAO externalConfigDAO;

	public ExternalConfigService(DAOContainer dc) {
		super();

		this.externalConfigDAO = dc.getExternalConfigDAO();
	}

	/**
	* Get the external configuration for the tenant. This will return a map of tenant names to ExternalConfig instances
	* 
	* @param tenantId - tenant id to get the external configuration for
	* 
	* @return map of tenant names to external configuration instances for the tenant or an empty map if there are no external
	*/
	public Map<String, ExternalConfig> getExternalTenantConfiguration(String tenantId) {
		Map<String, ExternalConfig> result = new HashMap<>();

		getTenantConfiguration(tenantId).forEach((key, config) -> {
			// Put the external configuration into the result.
			if (config instanceof ExternalConfig) {
				result.put(key, (ExternalConfig) config);
			}
		});

		return result;
	}

	/**
	* Loads configuration for tenant. This method is called by #loadConfiguration ( String ) to load external configuration from database.
	* 
	* @param tenantId - Tenant for which to load configuration. If null configuration will be loaded for all tenants.
	* 
	* @return Map of configuration key / value pairs. The key is the name of the configuration and the value is the configuration
	*/
	@Override
	protected Map<String, Config> loadConfiguration(String tenantId) {
		Map<String, Config> result = new HashMap<>();

		List<ExternalConfigNTT> configs = externalConfigDAO.getConfigByTenant(tenantId);

		configs.forEach(config -> {
			
			Object val = config.getValue();
			// Returns the value of the Clob object.
			if(val instanceof Clob) {
				Clob cVal = (Clob) config.getValue();
				try {
					val = cVal.getSubString(1, (int) cVal.length());
				} catch (SQLException e) { 
					val = null;
				}
			}
			
			result.put(config.getKey(), ExternalConfig.builder().key(config.getKey()).value(val).build());
		});

		return result;
	}

}
