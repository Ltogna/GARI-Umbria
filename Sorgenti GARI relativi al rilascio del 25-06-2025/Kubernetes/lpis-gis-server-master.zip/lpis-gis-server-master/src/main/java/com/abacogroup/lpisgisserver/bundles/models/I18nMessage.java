package com.abacogroup.lpisgisserver.bundles.models;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class I18nMessage {
	private String table;
	private String field;
	private String value;
	private Map<String, String> translations;
}
