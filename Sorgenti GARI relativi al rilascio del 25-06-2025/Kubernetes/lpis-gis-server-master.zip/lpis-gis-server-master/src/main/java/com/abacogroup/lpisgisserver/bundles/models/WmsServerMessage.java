package com.abacogroup.lpisgisserver.bundles.models;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WmsServerMessage {
	private Long display_order;
	private String code;
	private String url;
	private String format;
	private String srs;
	private String server_type;
	private String color;
	private Integer transparent;
	private String icon_url;
	private Map<String, Boolean> modules;
	private List<String> areas;
	private List<String> permissions;
	private Map<String, String> description;
	private String server_config;
}
