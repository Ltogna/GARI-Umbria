package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class SessionParcelAlreadyLockedException extends AbstractException {

	private static final long serialVersionUID = -7926221626100018764L;

	private static final ErrorCode ERROR_CODE = ErrorCode.SESSION_PARCEL_ALREADY_LOCKED;

	public SessionParcelAlreadyLockedException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new SessionParcelAlreadyLockedExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Parcel already locked")
	public static class SessionParcelAlreadyLockedExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -5119501473103282878L;

		public SessionParcelAlreadyLockedExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
