package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class EditParcelsTooSmallException extends AbstractException {

	private static final long serialVersionUID = -3699642188288644481L;

	private static final ErrorCode ERROR_CODE = ErrorCode.EDIT_PARCELS_TOO_SMALL;

	public EditParcelsTooSmallException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new EditParcelsTooSmallExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Some parcels have the area too small")
	public static class EditParcelsTooSmallExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 6963006484172411277L;

		public EditParcelsTooSmallExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
