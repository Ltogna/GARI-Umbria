package com.abacogroup.lpisgisserver.bundles.models;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LayerMessage {
	private List<WmsServerMessage> wms_servers;
	private List<WmsLayerMessage> wms_layers;
	private List<WmsPermissionMessage> permissions;
	private List<WmsModuleMessage> modules;
	private List<WmsLayerModuleMessage> layer_modules;
}
