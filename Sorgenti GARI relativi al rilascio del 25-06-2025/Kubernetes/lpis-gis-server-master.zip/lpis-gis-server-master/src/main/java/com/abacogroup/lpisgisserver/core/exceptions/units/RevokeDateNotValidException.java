package com.abacogroup.lpisgisserver.core.exceptions.units;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class RevokeDateNotValidException extends AbstractException {

	private static final long serialVersionUID = -6467378631448203591L;

	private static final ErrorCode ERROR_CODE = ErrorCode.REVOKE_DATE_NOT_VALID;

	public RevokeDateNotValidException(Status code, Operation operation, ErrorField errorField, 
			Map<String, Map<String, String>> errorDescriptions, String lang, String minDate, String maxDate) {
		super(code, new RevokeDateNotValidExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
		
		String msg = String.format(this.getBody().getMessage(), minDate, maxDate);
		this.getBody().setMessage(msg);
	}

	@Schema(description = "Revoke date not valid")
	public static class RevokeDateNotValidExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 3853099588145979239L;

		public RevokeDateNotValidExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}

