package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.resources.req.pub.bulk.UnitsWithDictionaryCodesPayloadV1;
import com.abacogroup.lpisgisserver.resources.res.units.fruit.FruitUnit;
import com.abacogroup.lpisgisserver.resources.res.units.olive.OliveUnit;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnit;

@Mapper(uses = {AbsoluteDateMapper.class} )
public interface UnitsWithDictionaryCodesPayloadV1Mapper {

	UnitsWithDictionaryCodesPayloadV1Mapper INSTANCE = Mappers.getMapper(UnitsWithDictionaryCodesPayloadV1Mapper.class);
	
	@Mapping(source = "variety.code", target = "varietyCode")
	@Mapping(source = "cultivationStatus.code", target = "cultivationStatusCode")
	@Mapping(source = "farmingForm.code", target = "farmingFormCode")
	@Mapping(source = "headerAnchoring.code", target = "headerAnchoringCode")
	@Mapping(source = "irrigation.code", target = "irrigationCode")
	@Mapping(source = "polesHeader.code", target = "polesHeaderCode")
	@Mapping(source = "polesWeaving.code", target = "polesWeavingCode")
	@Mapping(source = "productDestination.code", target = "productDestinationCode")
	@Mapping(source = "supportWires.code", target = "supportWiresCode")
	@Mapping(source = "terracing.code", target = "terracingCode")
	@Mapping(source = "variationType.code", target = "variationTypeCode")
	UnitsWithDictionaryCodesPayloadV1 toResponseV1(VineUnit entity);
	
	@Mapping(source = "variety.code", target = "varietyCode")
	@Mapping(source = "farmingForm.code", target = "farmingFormCode")
	@Mapping(source = "irrigation.code", target = "irrigationCode")
	@Mapping(source = "productDestination.code", target = "productDestinationCode")
	@Mapping(source = "plantingType.code", target = "plantingTypeCode")
	@Mapping(source = "protectionStructure.code", target = "protectionStructureCode")
	@Mapping(source = "qualitySystem.code", target = "qualitySystemCode")
	UnitsWithDictionaryCodesPayloadV1 toResponseV1(OliveUnit entity);
	
	
	@Mapping(source = "variety.code", target = "varietyCode")
	@Mapping(source = "farmingForm.code", target = "farmingFormCode")
	@Mapping(source = "irrigation.code", target = "irrigationCode")
	@Mapping(source = "plantingType.code", target = "plantingTypeCode")
	@Mapping(source = "protectionStructure.code", target = "protectionStructureCode")
	@Mapping(source = "qualitySystem.code", target = "qualitySystemCode")
	UnitsWithDictionaryCodesPayloadV1 toResponseV1(FruitUnit entity);
	
}
