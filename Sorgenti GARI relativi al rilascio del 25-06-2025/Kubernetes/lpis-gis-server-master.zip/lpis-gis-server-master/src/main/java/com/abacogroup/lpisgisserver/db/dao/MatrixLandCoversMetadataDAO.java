package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.MatrixLandCoversMetadataNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface MatrixLandCoversMetadataDAO extends Transactional<MatrixLandCoversMetadataDAO>, EnhancedSqlObject {

	@SqlUpdate("INSERT INTO lpis_matrix_landcovers_metadata (tenant_id, matrix_id, class_code, land_cover_code, key, value, day_from, day_to, user_id_insert, user_id_delete, dt_insert, dt_delete) "
			+ "VALUES(:tenant_id, :matrix_id, :class_code, :land_cover_code, :key, :value, :day_from, :day_to, :user_id_insert, NULL, §current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insert(@BindBean MatrixLandCoversMetadataNTT ntt, @Bind("user_id_insert") String userId);

	@SqlUpdate("update lpis_matrix_landcovers_metadata \n"
			+ "   set user_id_delete = :user_id_delete, \n"
			+ "       dt_delete = §current_timestamp§ \n"
			+ " where tenant_id = :tenant_id \n"
			+ "   and matrix_id = :matrix_id \n"
			+ "   and class_code = :class_code \n"
			+ "   and land_cover_code = :land_cover_code \n"
			+ "   and key = :key \n"
			+ "   and ( \n"
			+ "      :day_from between day_from and day_to or \n"
			+ "      :day_to between day_from and day_to or \n"
			+ "      (day_from > :day_from and day_to < :day_to) \n"
			+ "   ) \n" 
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n")
	void logicallyDelete(@BindBean MatrixLandCoversMetadataNTT ntt, @Bind("user_id_delete") String userId);
	
	@SqlUpdate("update lpis_matrix_landcovers_metadata \n"
			+ "   set user_id_delete = :user_id_delete, \n"
			+ "       dt_delete = §current_timestamp§ \n"
			+ " where tenant_id = :tenant_id \n"
			+ "   and matrix_id = :matrix_id \n"
			+ "   and land_cover_code = :land_cover_code \n"
			+ "   and key = :key \n"
			+ "   and ( \n"
			+ "      :day_from between day_from and day_to or \n"
			+ "      :day_to between day_from and day_to or \n"
			+ "      (day_from > :day_from and day_to < :day_to) \n"
			+ "   ) \n" 
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n")
	void logicallyDeleteByMatrixLandCoverKey(@BindBean MatrixLandCoversMetadataNTT ntt, @Bind("user_id_delete") String userId);

	@SqlQuery("select tenant_id, \n"
			+ "       matrix_id, \n"
			+ "       class_code, \n"
			+ "       land_cover_code, \n"
			+ "       key, \n"
			+ "       value, \n"
			+ "       day_from, \n"
			+ "       day_to \n"
			+ "  from lpis_matrix_landcovers_metadata \n"
			+ " where tenant_id = :tenant_id \n"
			+ "   and matrix_id = :matrix_id \n"
			+ "   and class_code = :class_code \n"
			+ "   and land_cover_code = :land_cover_code \n"
			+ "   and (:key is null or key = :key) \n"
			+ "   and :referenceDate between day_from and day_to \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(MatrixLandCoversMetadataNTT.class)
	List<MatrixLandCoversMetadataNTT> getLandCoversMetadataByKeyMatrixIdClassCodeLandCoverCode(
			@Bind("tenant_id") String tenantId,
			@Bind("matrix_id") Long matrixId,
			@Bind("class_code") String classCode,
			@Bind("land_cover_code") String landCoverCode,
			@Bind("referenceDate") AbsoluteDate referenceDate,
			@Bind("key") String key);
	
	@SqlQuery("select tenant_id, \n"
			+ "       matrix_id, \n"
			+ "       class_code, \n"
			+ "       land_cover_code, \n"
			+ "       key, \n"
			+ "       value, \n"
			+ "       day_from, \n"
			+ "       day_to \n"
			+ "  from lpis_matrix_landcovers_metadata \n"
			+ " where tenant_id = :tenant_id \n"
			+ "   and matrix_id = :matrix_id \n"
			+ "   and land_cover_code = :land_cover_code \n"
			+ "   and (:key is null or key = :key) \n"
			+ "   and :referenceDate between day_from and day_to \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(MatrixLandCoversMetadataNTT.class)
	List<MatrixLandCoversMetadataNTT> getLandCoversMetadataByKeyMatrixIdLandCoverCode(
			@Bind("tenant_id") String tenantId,
			@Bind("matrix_id") Long matrixId,
			@Bind("land_cover_code") String landCoverCode,
			@Bind("referenceDate") AbsoluteDate referenceDate,
			@Bind("key") String key);
	
	@SqlQuery("select lm.tenant_id, \n"
			+ "       lm.id as matrix_id, \n"
			+ "       lmlm.class_code, \n"
			+ "       lmlm.land_cover_code, \n"
			+ "       lmlm.key, \n"
			+ "       lmlm.value, \n"
			+ "       lmlm.day_from, \n"
			+ "       lmlm.day_to \n"
			+ "  from lpis_matrix_landcovers_metadata lmlm \n"
			+ " inner join lpis_matrix lm on lmlm.matrix_id = lm.id and lmlm.tenant_id = lm.tenant_id \n"
			+ " where lm.tenant_id = :tenant_id \n"
			+ "   and lm.code = :matrix_code \n"
			+ "   and lmlm.class_code = :class_code \n"
			+ "   and lmlm.land_cover_code = :land_cover_code \n"
			+ "   and (:key is null or lmlm.key = :key) \n"
			+ "   and :referenceDate between lmlm.day_from and lmlm.day_to \n"
			+ "   and §current_timestamp§ between lmlm.dt_insert and lmlm.dt_delete")
	@RegisterBeanMapper(MatrixLandCoversMetadataNTT.class)
	List<MatrixLandCoversMetadataNTT> getLandCoversMetadataByKeyMatrixCodeClassCodeLandCoverCode(
			@Bind("tenant_id") String tenantId,
			@Bind("matrix_code") String matrixCode,
			@Bind("class_code") String classCode,
			@Bind("land_cover_code") String landCoverCode,
			@Bind("referenceDate") AbsoluteDate referenceDate,
			@Bind("key") String key);
}
