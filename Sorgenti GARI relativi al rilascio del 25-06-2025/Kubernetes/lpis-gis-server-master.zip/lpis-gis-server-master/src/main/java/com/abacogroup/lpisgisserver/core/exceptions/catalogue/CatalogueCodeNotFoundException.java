package com.abacogroup.lpisgisserver.core.exceptions.catalogue;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class CatalogueCodeNotFoundException extends AbstractException {

	private static final long serialVersionUID = 6019883567969358859L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.CATALOGUE_CODE_NOT_FOUND;

	public CatalogueCodeNotFoundException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new CatalogueCodeNotFoundExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "catalogue code not found")
	public static class CatalogueCodeNotFoundExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -4502717114803408031L;

		public CatalogueCodeNotFoundExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
