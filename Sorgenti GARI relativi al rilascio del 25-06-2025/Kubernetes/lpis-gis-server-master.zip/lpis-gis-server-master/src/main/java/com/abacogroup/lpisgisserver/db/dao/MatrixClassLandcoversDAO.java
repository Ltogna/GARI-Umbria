package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.support.MatrixSearchParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassLandcoversNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface MatrixClassLandcoversDAO extends Transactional<MatrixClassLandcoversDAO>, EnhancedSqlObject {

	@SqlUpdate("INSERT INTO lpis_matrix_class_landcovers (matrix_id, class_code, land_cover_code, day_from, "
			+ "day_to, user_id_insert, user_id_delete, dt_insert, "
			+ "dt_delete) "
			+ "VALUES(:matrix_id, :class_code, :landcover.code, :day_from, "
			+ "       :day_to, :user_id_insert, NULL, §current_timestamp§, "
			+ "       TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insert(@BindBean MatrixClassLandcoversNTT rs, @Bind("user_id_insert") String userId);

	@SqlQuery("select matrix_id, \n"
			+ "   class_code, \n"
			+ "   land_cover_code as landcover_code, \n"
			+ "   coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', land_cover_code, :lang)§, land_cover_code) as landcover_description, \n"
			+ "   day_from, \n"
			+ "   day_to, \n"
			+ "   user_id_insert, \n"
			+ "   user_id_delete, \n"
			+ "   dt_insert, \n"
			+ "   dt_delete \n"
			+ "from lpis_matrix_class_landcovers \n"
			+ "where matrix_id = :matrix_id \n"
			+ "   and class_code = :class_code \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(MatrixClassLandcoversNTT.class)
	List<MatrixClassLandcoversNTT> findByMatrixIdAndClassCode(
			@BindBean ServiceSupportEnv env,
			@Bind("matrix_id") Long matrixId, 
			@Bind("class_code") String classCode);

	@SqlQuery("select matrix_id, \n"
			+ "   class_code, \n"
			+ "   land_cover_code as landcover_code, \n"
			+ "   coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', land_cover_code, :lang)§, land_cover_code) as landcover_description, \n"
			+ "   day_from, \n"
			+ "   day_to, \n"
			+ "   user_id_insert, \n"
			+ "   user_id_delete, \n"
			+ "   dt_insert, \n"
			+ "   dt_delete \n"
			+ "from lpis_matrix_class_landcovers \n"
			+ "where matrix_id = :matrix_id \n"
			+ "   and class_code = :class_code \n"
			+ "   and land_cover_code = :landCoverCode \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(MatrixClassLandcoversNTT.class)
	MatrixClassLandcoversNTT findByMatrixIdClassCodeAndLandCoverCode(
			@BindBean ServiceSupportEnv env,
			@Bind("matrix_id") Long matrixId,
			@Bind("class_code") String classCode,
			@Bind("landCoverCode") String landCoverCode);
	
	@SqlQuery("select matrix_id, \n"
			+ "   class_code, \n"
			+ "   land_cover_code as landcover_code, \n"
			+ "   coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', land_cover_code, :lang)§, land_cover_code) as landcover_description, \n"
			+ "   day_from, \n"
			+ "   day_to, \n"
			+ "   user_id_insert, \n"
			+ "   user_id_delete, \n"
			+ "   dt_insert, \n"
			+ "   dt_delete \n"
			+ "from lpis_matrix_class_landcovers \n"
			+ "where matrix_id = :matrix_id \n"
			+ "   and land_cover_code = :landCoverCode \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(MatrixClassLandcoversNTT.class)
	MatrixClassLandcoversNTT findByMatrixIdAndLandCoverCode(
			@BindBean ServiceSupportEnv env,
			@Bind("matrix_id") Long matrixId,
			@Bind("landCoverCode") String landCoverCode);

	@SqlUpdate("update lpis_matrix_class_landcovers \n"
			+ "   set user_id_delete = :user_id_delete, \n"
			+ "       dt_delete = §current_timestamp§ \n"
			+ " where matrix_id = :matrix_id \n"
			+ "   and class_code = :class_code \n"
			+ "   and land_cover_code = :landCoverCode \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteByMatrixIdClassCodeLandCoverCode(
			@Bind("matrix_id") Long matrixId,
			@Bind("class_code") String classCode,
			@Bind("landCoverCode") String landCoverCode,
			@Bind("user_id_delete") String userDelete);	
	
	@SqlUpdate("update lpis_matrix_class_landcovers \n"
			+ "   set user_id_delete = :user_id_delete, \n"
			+ "       dt_delete = §current_timestamp§ \n"
			+ " where matrix_id = :matrix_id \n"
			+ "   and land_cover_code = :landCoverCode \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteByMatrixIdLandCoverCode(
			@Bind("matrix_id") Long matrixId,
			@Bind("landCoverCode") String landCoverCode,
			@Bind("user_id_delete") String userDelete);
	
	@SqlUpdate("UPDATE lpis_matrix_class_landcovers \n"
			+ "SET user_id_delete = :user_id_delete, \n"
			+ "    dt_delete = §current_timestamp§ \n" 
			+ "WHERE matrix_id = :matrix_id \n"
			+ "    AND class_code = :class_code " 
			+ "    and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteByMatrixIdAndClassCode(
			@Bind("matrix_id") Long matrixId, 
			@Bind("class_code") String classCode,
			@Bind("user_id_delete") String userDelete);

	/* ******************************************** */

	@SqlQuery("\n"
			+ "select matrix_id, \n"
			+ "   class_code, \n"
			+ "   land_cover_code as landcover_code, \n"
			+ "   coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', land_cover_code, :lang)§, land_cover_code) as landcover_description, \n"
			+ "   day_from, \n"
			+ "   day_to, \n"
			+ "   user_id_insert, \n"
			+ "   user_id_delete, \n"
			+ "   dt_insert, \n"
			+ "   dt_delete \n"
			+ "from lpis_matrix_class_landcovers \n"
			+ "where matrix_id = :matrixId \n"
			+ "   and class_code = :classCode \n"
			+ "   and :referenceDate between day_from and day_to \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n"
			+ "   and (land_cover_code =  :landcoverFilter or :landcoverFilter is null) \n")
	@RegisterBeanMapper(MatrixClassLandcoversNTT.class)
	List<MatrixClassLandcoversNTT> searchValidByMatrixIdAndClassCode(
			@BindBean ServiceSupportEnv env,
			@BindBean MatrixSearchParams search);

}
