package com.abacogroup.lpisgisserver.core.config;

import jakarta.validation.Valid;
import lombok.Data;

@Data
@Valid
public class CrossTenantLpisConfig {

	private String apikey;
	
}
