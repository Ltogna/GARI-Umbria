package com.abacogroup.lpisgisserver.core.exceptions.support;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class LandUsesCodeNotFoundException extends AbstractException {

	private static final long serialVersionUID = -631288209510780457L;

	private static final ErrorCode ERROR_CODE = ErrorCode.LAND_USES_CODE_NOT_FOUND;

	public LandUsesCodeNotFoundException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new LandUsesCodeNotFoundExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Land use code not found")
	public static class LandUsesCodeNotFoundExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -6905246824130062231L;

		public LandUsesCodeNotFoundExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
