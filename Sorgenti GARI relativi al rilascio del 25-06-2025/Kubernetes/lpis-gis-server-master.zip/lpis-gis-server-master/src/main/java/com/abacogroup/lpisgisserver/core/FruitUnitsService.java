package com.abacogroup.lpisgisserver.core;

import java.util.List;
import java.util.stream.Collectors;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.units.fruit.FruitUnitNotFoundException;
import com.abacogroup.lpisgisserver.core.mappers.units.FruitUnitMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.FruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.ntt.units.fruit.FruitUnitNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.units.fruit.FruitUnit;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FruitUnitsService extends BaseService {

	private final FruitUnitsDAO fruitUnitsDAO;

	private final UnitsSupportService unitsSupportService;


	private static final UnitType UNIT_TYPE = UnitType.FRUIT_UNIT;

	public FruitUnitsService(DAOContainer dc, UnitsSupportService unitsSupportService, InternalConfigService conf,
			ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService, 
			StyleService styleService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.fruitUnitsDAO = dc.getFruitUnitsDAO();
		this.unitsSupportService = unitsSupportService;
	}

	public List<FruitUnit> getFruitUnits(ServiceSupportEnv env, Boolean showOutdatedUnits) {
		unitsSupportService.checkServiceSupportEnv(env, UNIT_TYPE, Operation.GET_FRUIT_UNITS);
		return fruitUnitsDAO.getFruitUnitsbyLandCoverIds(env, List.of(env.getLandCoverId()), boolToInt(showOutdatedUnits)).stream()
				.map(FruitUnitMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}

	public FruitUnit getFruitUnitById(ServiceSupportEnv env, Long fruitUnitId) {
		unitsSupportService.checkServiceSupportEnv(env, UNIT_TYPE, Operation.GET_FRUIT_UNITS);
		return FruitUnitMapper.INSTANCE.entityToDto(getFruitUnitNTTByUnitId(env, fruitUnitId, Operation.GET_FRUIT_UNITS));		
	}

	private FruitUnitNTT getFruitUnitNTTByUnitId(ServiceSupportEnv env, Long fruitUnitId, Operation operation) {
		FruitUnitNTT fruitUnitNTT = fruitUnitsDAO.getFruitUnitsbyUnitId(env, fruitUnitId);
		if(fruitUnitNTT == null) {
			FruitUnitNotFoundException ex = new FruitUnitNotFoundException(Status.NOT_FOUND, operation, 
					ErrorField.UNIT_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		return fruitUnitNTT;
	}
}
