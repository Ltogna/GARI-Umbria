package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.jdbi.paging.PagingParams;
import com.abacogroup.lpisgisserver.db.ntt.MatrixCompatNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface MatrixCompatDAO extends Transactional<MatrixCompatDAO>, EnhancedSqlObject {

	@SqlUpdate("INSERT INTO lpis_matrix_compat (matrix_id, class_code, extended_by_class_code) VALUES(:matrix_id, :class_code, :extended_by_class_code)")
	void insert(@BindBean MatrixCompatNTT rs);

	@SqlUpdate("UPDATE lpis_matrix_compat set extended_by_class_code = :extended_by_class_code where matrix_id = :matrix_id and class_code = :class_code")
	void update(@BindBean MatrixCompatNTT rs);
	
	@SqlQuery("select * from lpis_matrix_compat where matrix_id = :id")
	@RegisterBeanMapper(MatrixCompatNTT.class)
	List<MatrixCompatNTT> findByMatrixId(@Bind("id") Long id);

	@SqlQuery("select * from lpis_matrix_compat where class_code = :code")
	@RegisterBeanMapper(MatrixCompatNTT.class)
	List<MatrixCompatNTT> findByMatrixCode(@Bind("code") String code);

	@SqlQuery("select * from lpis_matrix_compat")
	@RegisterBeanMapper(MatrixCompatNTT.class)
	List<MatrixCompatNTT> findPagedType(PagingParams pp);

	@SqlUpdate("delete from lpis_matrix_compat where matrix_id = :id")
	void deleteByMatrixId(@Bind("id") Long id);

	@SqlUpdate("delete from lpis_matrix_compat where class_code = :code")
	void deleteByMatrixCode(@Bind("code") String code);
	
	/* ************************************** */
	
	@SqlQuery("select matrix_id, \n"
			+ "       class_code, \n"
			+ "       extended_by_class_code \n"
			+ "from lpis_matrix_compat \n"
			+ "where matrix_id = :id \n"
			+ "  and class_code = :code")
	@RegisterBeanMapper(MatrixCompatNTT.class)
	MatrixCompatNTT findByMatrixIdAnClassCode(@Bind("id") Long id, @Bind("code") String code);

	//XXX FIX ME da eliminare una delle due
	@SqlQuery("select matrix_id, \n"
			+ "       class_code, \n"
			+ "       extended_by_class_code \n"
			+ "from lpis_matrix_compat \n"
			+ "where matrix_id = :id \n"
			+ "  and class_code = :code")
	@RegisterBeanMapper(MatrixCompatNTT.class)
	List<MatrixCompatNTT> findByMatrixIdAndClassCode(@Bind("id") Long id, @Bind("code") String code);
	
	@SqlQuery("select lmc.matrix_id, \n"
			+ "        lmc.class_code, \n"
			+ "        lmc.extended_by_class_code \n"
			+ "   from lpis_matrix_compat lmc \n"
			+ "  inner join lpis_matrix lm on lmc.matrix_id = lm.id \n"
			+ "  where lm.tenant_id = :tenantId \n"
			+ "    and lm.code = :matrixCode \n"
			+ "    and lmc.class_code = :classCode")
	@RegisterBeanMapper(MatrixCompatNTT.class)
	List<MatrixCompatNTT> getExtendedClassCodesByClassCode(
			@Bind("tenantId") String tenantId,
			@Bind("matrixCode") String matrixCode,
			@Bind("classCode") String classCode);
}
