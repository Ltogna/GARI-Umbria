package com.abacogroup.lpisgisserver.core.pub.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class CXFParcelImportResult {
	String sector;
	String block;
	String parcel;
	String srs;
	String errorMessagge;
}