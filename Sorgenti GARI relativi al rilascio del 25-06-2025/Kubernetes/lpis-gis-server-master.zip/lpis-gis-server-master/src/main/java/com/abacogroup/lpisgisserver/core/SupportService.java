package com.abacogroup.lpisgisserver.core;

import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.SoftwareModule;
import com.abacogroup.lpisgisserver.core.enums.UnitDictionaryTables;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.support.CampaignNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.support.GenericSupportException;
import com.abacogroup.lpisgisserver.core.exceptions.support.InternalConfigNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.support.LandCoverCodeNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.support.LandUsesCodeNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.units.UnitCodeNotFoundException;
import com.abacogroup.lpisgisserver.core.mappers.AdditionalExternalLinkMapper;
import com.abacogroup.lpisgisserver.core.mappers.CampaignMapper;
import com.abacogroup.lpisgisserver.core.mappers.LandCoversCodeMapper;
import com.abacogroup.lpisgisserver.core.mappers.LandUsesCodeMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.DoigtMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.EditCategoryMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.UnitCodeMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.VineyardMapper;
import com.abacogroup.lpisgisserver.core.models.InternalConfig;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.I18nDAO;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.ntt.CampaignNTT;
import com.abacogroup.lpisgisserver.db.ntt.I18nNTT;
import com.abacogroup.lpisgisserver.db.ntt.LandCoversCodeNTT;
import com.abacogroup.lpisgisserver.db.ntt.LandUsesCodeNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.GetDoIgtCodesByCodesPayload;
import com.abacogroup.lpisgisserver.resources.req.GetUnitCodeListPayload;
import com.abacogroup.lpisgisserver.resources.res.AdditionalExternalLink;
import com.abacogroup.lpisgisserver.resources.res.Campaign;
import com.abacogroup.lpisgisserver.resources.res.CampaignList;
import com.abacogroup.lpisgisserver.resources.res.ClientConfiguration;
import com.abacogroup.lpisgisserver.resources.res.ClientConfigurationList;
import com.abacogroup.lpisgisserver.resources.res.EditCategory;
import com.abacogroup.lpisgisserver.resources.res.LandCoversCode;
import com.abacogroup.lpisgisserver.resources.res.LandUsesCode;
import com.abacogroup.lpisgisserver.resources.res.units.UnitCode;
import com.abacogroup.lpisgisserver.resources.res.units.UnitCodeList;
import com.abacogroup.lpisgisserver.resources.res.units.vine.DoIgt;
import com.abacogroup.lpisgisserver.resources.res.units.vine.DoIgtList;
import com.abacogroup.lpisgisserver.resources.res.units.vine.Vineyard;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response.Status;

public class SupportService extends BaseService {

	private SupportDAO supportDAO;
	private I18nDAO i18nDAO;
	private static final int CODE_LIST_DEFAULT_RESULT_NUMBER = 20;

	private static final Logger log = LoggerFactory.getLogger(SupportService.class);

	public SupportService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService,
			StyleService styleService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);
		this.supportDAO = dc.getSupportDAO();
		this.i18nDAO = dc.getI18nDAO();
	}

	/**
	* Find land covers codes by tenant id. This method is for use by applications that want to get a list of land covers codes.
	* 
	* @param tenantId - the tenant id for whom to search
	* @param lang - the language of the search
	* @param filter - the search filter to use when doing the search
	* @param nextKey - the key to use for next page of results
	* @param includeEmptyDescr - whether to include empty description or not
	* 
	* @return infinite list of LandCoversCode DTOs matching the search filter null if none found
	*/
	public InfiniteListResults<LandCoversCode> getLandCoversCodes(String tenantId, String lang, String filter, String nextKey, Integer includeEmptyDescr) {
		return this.supportDAO.infinite(() -> supportDAO.findLandCoversCodes(tenantId, lang, filter, includeEmptyDescr),
				nextKey,
				CODE_LIST_DEFAULT_RESULT_NUMBER)
				.map(LandCoversCodeMapper.INSTANCE::entityToDto);
	}

	/**
	* Get land uses codes. This method is used for listing land uses codes with optional next key. If you don't want to get the next key pass null as nextKey
	* 
	* @param tenantId - Tenant ID to search in
	* @param lang - Language of search ( ISO 639 - 1 )
	* @param filter - Filter to use ( SQL92 or SQL92 )
	* @param nextKey - Next key to use ( SQL92 or SQL92 )
	* @param includeEmptyDescr - Include empty description in result ( null = no description )
	* 
	* @return InfiniteListResults of LandUsesCode objects or null if none found ( never null ). Note : If there are no results an infinite list will be returned
	*/
	public InfiniteListResults<LandUsesCode> getLandUsesCodes(String tenantId, String lang, String filter, String nextKey, Integer includeEmptyDescr) {
		return this.supportDAO.infinite(() -> supportDAO.findLandUsesCodes(tenantId, lang, filter, includeEmptyDescr),
				nextKey,
				CODE_LIST_DEFAULT_RESULT_NUMBER)
				.map(LandUsesCodeMapper.INSTANCE::entityToDto);
	}

	/**
	* Gets LandCoverCodeNTT by code. This method is used to get land cover code by code
	* 
	* @param tenantId - Id of the tenant for whom we want to get the land cover code
	* @param lang - Language of the land cover code. It must be ISO 639 - 1
	* @param code - Code of the land cover code
	* 
	* @return LandCoversCodeNTT that corresponds to the code or null if not found or error during get
	*/
	public LandCoversCode getLandCoversCodeByCode(String tenantId, String lang, String code) {
		LandCoversCodeNTT landCoversCode = supportDAO.getLandCoverCode(tenantId, lang, code);
		// If landCoversCode is null throw an exception.
		if (landCoversCode == null) {
			LandCoverCodeNotFoundException ex = new LandCoverCodeNotFoundException(Status.NOT_FOUND, Operation.GET_LANDCOVER_CODE, ErrorField.LANDCOVER_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(tenantId), lang);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return LandCoversCodeMapper.INSTANCE.entityToDto(landCoversCode);
	}

	/**
	* Get land uses code by code. This method is used for getting the data from database. If data is not found an exception is thrown
	* 
	* @param tenantId - Id of the tenant that owns the data
	* @param lang - Language of the data. It is required to be in ISO 639 - 1 format
	* @param code - Land uses code to be retrieved. It is required to be in ISO 639 - 1 format
	* 
	* @return LandUsesCode DTO with data from database or null if data is not found or error is logged
	*/
	public LandUsesCode getLandUsesCodeByCode(String tenantId, String lang, String code) {
		LandUsesCodeNTT landUsesCode = supportDAO.getLandUsesCode(tenantId, lang, code);
		// If landUsesCode is null throw an exception.
		if (landUsesCode == null) {
			LandUsesCodeNotFoundException ex = new LandUsesCodeNotFoundException(Status.NOT_FOUND, Operation.GET_LANDUSE_CODE, ErrorField.LANDCOVER_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(tenantId), lang);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return LandUsesCodeMapper.INSTANCE.entityToDto(landUsesCode);
	}

	/**
	* Get client configuration for a given tenant. It is possible to specify a key which will be used as key in the result.
	* 
	* @param tenantId - tenant id to look for config in.
	* @param lang - language to look for config in. null means no language is used
	* @param configKey - key of config to look for.
	* 
	* @return list of client configuration
	*/
	public ClientConfigurationList getClientConfig(String tenantId, String lang, String configKey) {
		ClientConfigurationList result = ClientConfigurationList.builder().client_configuration(new ArrayList<>()).build();

		Map<String, InternalConfig> configuration = this.internalConf.getInternalTenantConfiguration(tenantId);
		
		configuration.forEach((key, config) -> {
			// Add a new client configuration to the result.
			if (Boolean.TRUE.equals(config.getFl_client()) || config.getKey().equals(configKey)) {
				String name = StringUtils.isNotBlank(config.getName()) ? config.getName() : config.getKey();

				result.getClient_configuration().add(
						ClientConfiguration.builder()
								.name(name)
								.value(config.getValue())
								.build());
			}
		});

		// Set the client configuration to the result of the operation.
		if(configKey != null) {
			result.setClient_configuration(
					result.getClient_configuration()
						.stream()
						.filter(c -> configKey.equals(c.getName()))
						.collect(toList())
			);
		}
		
		// Returns the client configuration if the result is null or empty.
		if(result == null || result.getClient_configuration() == null || result.getClient_configuration().isEmpty()) {
			InternalConfigNotFoundException ex = new InternalConfigNotFoundException(Status.NOT_FOUND, Operation.GET_INTERNAL_CONFIG, ErrorField.CONFIG,
					this.errorDescriptionsService.getTenantErrorDescriptions(tenantId), lang);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		return result;
	}

	/**
	* Returns the campaign with the given code. If no campaign is found null is returned. This method is useful for obtaining campaigns that are in an unhealthy state or have a reason to fail to be found.
	* 
	* @param code - The code of the campaign to retrieve. Must be non - null.
	* @param env - The environment in which to search for campaigns.
	* 
	* @return The campaign with the given code or null if no campaign is found with the given code or if no campaign has been found
	*/
	public Campaign getCampaignByCode(String code, ServiceSupportEnv env) {
		return getAllValidCampaign(code, env).get(0);
	}

	/**
	* Returns a CampaignList containing all campaigns. Note that this does not include the campaign_id which is used to determine which campaign to retrieve.
	* 
	* @param env - service support environment for this request. Cannot be null.
	* 
	* @return a CampaignList containing all campaigns. Cannot be null but can be empty if there are no campaigns
	*/
	public CampaignList getCampaignList(ServiceSupportEnv env) {
		return CampaignList.builder().campaign_list(getAllValidCampaign(null, env)).build();
	}

	/**
	* Get all campaigns by code. This method is used to get all campaigns in one query.
	* 
	* @param code - code of the campaign to get. It is case sensitive
	* @param env - service support environment. It is case sensitive
	* 
	* @return list of campaigns sorted by description in descending order of descrition ( most recent first ). If no campaign is found an empty list is returned
	*/
	private List<Campaign> getAllValidCampaign(String code, ServiceSupportEnv env) {
		List<CampaignNTT> campaign = supportDAO.findValidCampaignByCodeAndTenant(code, env);

		// If campaign is empty throw an exception.
		if (campaign.isEmpty()) {
			CampaignNotFoundException ex = new CampaignNotFoundException(Status.NOT_FOUND,
					Operation.GET_CAMPAIGN, ErrorField.CAMPAIGN_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		campaign.sort(Collections.reverseOrder(
				(o1, o2) -> o1.getDescription() == null ? -1 : o2.getDescription() == null ? 1 : o1.getDescription().compareTo(o2.getDescription())));

		return campaign.stream().map(CampaignMapper.INSTANCE::entityToDto).collect(toList());
	}

	public List<EditCategory> getEditCategoryCodes(ServiceSupportEnv env, String filter) {
		List<EditCategory> codeList = supportDAO.getAllEditCategoriesByTenant(env).stream()
				.map(EditCategoryMapper.INSTANCE::entityToDto)
				.collect(toList());
		
		if(filter != null && !filter.isBlank()) {
			return codeList.stream()
					.filter(code -> code.getDescription() != null 
					&& (code.getDescription().toLowerCase().contains(filter.toLowerCase()) 
							|| code.getCode().toLowerCase().contains(filter.toLowerCase())))
					.collect(toList());
		} 
		return codeList;
	}

	public List<AdditionalExternalLink> getAdditionalExternalLinks(ServiceSupportEnv env, SoftwareModule module) {
		return supportDAO.findAdditionlExternalLinksByModuleViewTypeCodeAndTenant(env, module, null, null, null, 1).stream()
				.map(AdditionalExternalLinkMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}

	public InfiniteListResults<UnitCode> getUnitsCode(ServiceSupportEnv env, UnitType unitType, UnitDictionaryTables unitTable,
			String filter, Integer includeEmptyDescr) {
		
		return this.supportDAO.infinite(
				() -> supportDAO.getUnitCodeByTenantTableNameTypeCode(env, unitType, unitTable.getTableName(), filter, includeEmptyDescr, 1),
				env.getNextKey(),
				env.getPageSize())
				.map(UnitCodeMapper.INSTANCE::entityToDto);
	}

	public UnitCodeList getUnitCodeList(ServiceSupportEnv env, UnitType unitType, UnitDictionaryTables unitTable,
			@NotNull GetUnitCodeListPayload payload) {

		UnitCodeList result = UnitCodeList
				.builder()
				.unit_code_list(new ArrayList<>())
				.build();

		if (payload.getUnitCodes() != null && !payload.getUnitCodes().isEmpty()) {
			List<UnitCode> unitList = supportDAO
					.getUnitCodeByTenantTableNameTypeCodeAndUnitCodes(env, unitType, unitTable.getTableName(), payload.getUnitCodes(), 1).stream()
					.map(UnitCodeMapper.INSTANCE::entityToDto).collect(Collectors.toList());

			result.setUnit_code_list(unitList);
		}

		return result;
	}

	public InfiniteListResults<DoIgt> getDoigtCodes(ServiceSupportEnv env, String filter,
			Integer includeEmptyDescr, Boolean onlyVisible) {
		return this.supportDAO.infinite(
				() -> supportDAO.getDoigtCodes(env, filter, includeEmptyDescr, boolToInt(onlyVisible)),
				env.getNextKey(),
				env.getPageSize())
				.map(DoigtMapper.INSTANCE::entityToDto);
	}

	public InfiniteListResults<Vineyard> getVineyardCodes(ServiceSupportEnv env, String doigtCode, String filter,
			Integer includeEmptyDescr) {
		
		final Long doigtId;
		if(doigtCode == null || doigtCode.isBlank()) {
			doigtId = null;
		} else {
			doigtId = getDoigtCodes(env, doigtCode, 0, false).getRecords().stream()
					.filter(d -> d.getCode().equals(doigtCode))
					.findFirst()
					.map(DoIgt::getId)
					.orElse(null);

			if(doigtId == null) {
				UnitCodeNotFoundException ex = new UnitCodeNotFoundException(Status.NOT_FOUND, Operation.GET_VINEYARD_CODES, ErrorField.VINE_DOIGT_CODE,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;

			}
		}
		
		return  this.supportDAO.infinite(
				() -> supportDAO.getVineyardCodes(env, doigtId, filter, includeEmptyDescr, 1),
				env.getNextKey(),
				env.getPageSize())
				.map(VineyardMapper.INSTANCE::entityToDto);
	}

	public String getAdditionalTranslations(ServiceSupportEnv env, @NotNull String module) {
		List<I18nNTT> additionalTranslations = i18nDAO.findAllI18nByTenantTableFieldAandLang(env.getTenantId(), "lpis_additional_translations", module, env.getLang());

		Map<String, String> responseMap = additionalTranslations.stream()
				.collect(Collectors.toMap(I18nNTT::getI18n_value, I18nNTT::getI18n_text));

		ObjectMapper mapper = new ObjectMapper(new JsonFactory());

		try {
			return mapper.writeValueAsString(responseMap);
		} catch (JsonProcessingException e) {
			GenericSupportException ex = new GenericSupportException(Status.INTERNAL_SERVER_ERROR, Operation.GET_ADDITIONAL_TRANSLATIONS, ErrorField.ADDITIONAL_TRANSLATIONS,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
			log.error(ex.getBody().getLogErrorMessage());
			throw ex;
		}
	}

	public DoIgtList getDoigtCodesByCodes(ServiceSupportEnv env, Integer includeEmptyDescr,  Boolean onlyVisible, @Valid GetDoIgtCodesByCodesPayload payload) {
				
		return DoIgtList.builder()
				.doIgt_list(
						supportDAO.getDoigtCodesByCodes(env, includeEmptyDescr, boolToInt(onlyVisible) , payload.getCodes())
						.stream()
						.map(DoigtMapper.INSTANCE::entityToDto)
						.collect(Collectors.toList()))
				.build();
	}

}
