package com.abacogroup.lpisgisserver.core.support;

import com.abacogroup.lpisgisserver.LpisGisServerConfiguration;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import lombok.Getter;

/**
 * Container Object to point to all external webTarget
 */
@Getter
public class WebTargetContainer {
	// TaskManager webtarget
	private WebTarget taskManagerWT;

	// Anomalies webtarget
	private WebTarget anomaliesRegistryWT;

	// Consistenza (CLL) webtarget
	private WebTarget cllWT;

	//Georaster webtarget
	private WebTarget geoRasterWT;
	
	public WebTargetContainer(Client client, LpisGisServerConfiguration configuration) {
		initTaskManagerWT(client, configuration);
		initAnomaliesRegistryWT(client, configuration);
		initCllWT(client, configuration);
		initGeorasterWT(client, configuration);
	}

	private void initTaskManagerWT(Client client, LpisGisServerConfiguration configuration) {
		taskManagerWT = client.target(configuration.getTaskmanager().getUrl());
	}

	private void initAnomaliesRegistryWT(Client client, LpisGisServerConfiguration configuration) {
		anomaliesRegistryWT = client.target(configuration.getAnomaliesRegistry().getUrl());
	}

	private void initCllWT(Client client, LpisGisServerConfiguration configuration) {
		cllWT = client.target(configuration.getCll().getUrl());
	}

	private void initGeorasterWT(Client client, LpisGisServerConfiguration configuration) {
		if(configuration.getGeorasterConfig() != null && configuration.getGeorasterConfig().getUrl() != null) {
			geoRasterWT = client.target(configuration.getGeorasterConfig().getUrl());
		} else {
			geoRasterWT = null;
		}
	}
	
}
