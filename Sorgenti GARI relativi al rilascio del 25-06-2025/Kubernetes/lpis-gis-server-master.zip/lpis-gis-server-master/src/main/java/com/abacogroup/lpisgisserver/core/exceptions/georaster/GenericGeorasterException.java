package com.abacogroup.lpisgisserver.core.exceptions.georaster;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class GenericGeorasterException extends AbstractException {

	private static final long serialVersionUID = -7252203008674918953L;

	private static final ErrorCode ERROR_CODE = ErrorCode.GENERIC_GEORASTER_ERROR;

	public GenericGeorasterException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new GenericGeorasterExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Generic georaster error")
	public static class GenericGeorasterExceptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = 372367780010931447L;

		public GenericGeorasterExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
