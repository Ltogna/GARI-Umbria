package com.abacogroup.lpisgisserver.core.enums;

public enum GeomTables {
	AREAS("lpis_areas_hierarchies",
		  "select \n"
			+ "    lah.pkid, \n"
			+ "    lah.srs, \n"
			+ "    lah.geom, \n"
			+ "    lah.world_geom \n"
			+ "from \n"
			+ "    lpis_areas_hierarchies lah \n"
			+ "where "
			+ "    lah.tenant_id = :tenantId  \n"
			+ "    and §current_timestamp§ between lah.dt_insert and lah.dt_delete \n"),

	SECTORS("lpis_sector_details",
		   "select \n"
		    + "    lsd.pkid, \n"
		    + "    lsd.srs, \n"
		    + "    lsd.geom, \n"
		    + "    lsd.world_geom \n"
		    + "from \n"
		    + "    lpis_sector_details lsd \n"
		    + "    inner join lpis_sectors ls on lsd.sector_id = ls.id \n"
		    + "where "
		    + "    ls.tenant_id = :tenantId  \n"
		    + "    and §current_timestamp§ between lsd.dt_insert and lsd.dt_delete \n"),

	BLOCKS("lpis_sector_block_details",
		   "select \n"
			+ "    lbd.pkid, \n"
			+ "    lbd.srs, \n"
			+ "    lbd.geom, \n"
			+ "    lbd.world_geom \n"
			+ "from \n"
			+ "    lpis_sector_block_details lbd \n"
			+ "    inner join lpis_sector_blocks lb on lbd.sector_block_id = lb.id \n"
			+ "where "
			+ "    lb.tenant_id = :tenantId  \n"
			+ "    and §current_timestamp§ between lbd.dt_insert and lbd.dt_delete \n"),
	
	PARCELS("lpis_parcel_details",
			"select \n"
			+ "    lpd.pkid, \n"
			+ "    lpd.srs, \n"
			+ "    lpd.geom, \n"
			+ "    lpd.world_geom \n"
			+ "from \n"
			+ "    lpis_parcel_details lpd \n"
			+ "    inner join lpis_parcels lp on lpd.parcel_id = lp.id \n"
			+ "where "
			+ "    lp.tenant_id = :tenantId  \n"
			+ "    and §current_timestamp§ between lpd.dt_insert and lpd.dt_delete \n"), 
	
	LANDCOVERS("lpis_parcel_lc_details",
			"select \n"
			+ "    lcd.pkid, \n"
			+ "    lcd.srs, \n"
			+ "    lcd.geom, \n"
			+ "    lcd.world_geom \n"
			+ "from \n"
			+ "    lpis_parcel_lc_details lcd \n"
			+ "    inner join lpis_parcel_land_covers lc on lcd.land_cover_id = lc.id \n"
			+ "    inner join lpis_parcels lp on lc.parcel_id = lp.id \n"
			+ "    inner join lpis_parcel_details lpd on lp.id = lpd.parcel_id \n"
			+ "where "
			+ "    lp.tenant_id = :tenantId  \n"
			+ "    and §current_timestamp§ between lpd.dt_insert and lpd.dt_delete \n"
			+ "    and §current_timestamp§ between lcd.dt_insert and lcd.dt_delete \n");
	
	private final String tableName;
	private final String query;

	private GeomTables(String tableName, String query) {
		this.tableName = tableName;
		this.query = query;
	}

	public String getTableName() {
		return tableName;
	}
	
	public String getQuery() {
		return query;
	}
}
