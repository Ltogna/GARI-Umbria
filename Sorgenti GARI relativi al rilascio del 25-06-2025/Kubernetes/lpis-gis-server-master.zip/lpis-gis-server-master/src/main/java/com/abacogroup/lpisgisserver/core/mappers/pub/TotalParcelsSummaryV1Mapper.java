package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.resources.res.farmland.TotalParcelsSummary;
import com.abacogroup.lpisgisserver.resources.res.pub.farmland.TotalParcelsSummaryV1;

@Mapper
public interface TotalParcelsSummaryV1Mapper {

	TotalParcelsSummaryV1Mapper INSTANCE = Mappers.getMapper(TotalParcelsSummaryV1Mapper.class);
	
	@InheritInverseConfiguration
	TotalParcelsSummaryV1 toResponseV1(TotalParcelsSummary entity);
	
}
