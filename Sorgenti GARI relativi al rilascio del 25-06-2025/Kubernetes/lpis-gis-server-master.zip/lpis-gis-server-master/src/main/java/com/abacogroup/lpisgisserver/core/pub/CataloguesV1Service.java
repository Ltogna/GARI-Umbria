package com.abacogroup.lpisgisserver.core.pub;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lpisgisserver.core.BaseService;
import com.abacogroup.lpisgisserver.core.CataloguesService;
import com.abacogroup.lpisgisserver.core.ErrorDescriptionsService;
import com.abacogroup.lpisgisserver.core.ExternalConfigService;
import com.abacogroup.lpisgisserver.core.InternalConfigService;
import com.abacogroup.lpisgisserver.core.StyleService;
import com.abacogroup.lpisgisserver.core.mappers.pub.CatalogueGeomV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.CataloguePayloadV1Mapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.pub.CataloguePayloadV1;
import com.abacogroup.lpisgisserver.resources.res.pub.CatalogueGeomV1;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

public class CataloguesV1Service extends BaseService {
	
	private CataloguesService cataloguesService;

	public CataloguesV1Service(DAOContainer dc, CataloguesService cataloguesService,
			InternalConfigService conf, ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService, 
			StyleService styleService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);
		
		this.cataloguesService = cataloguesService;
	}

	public InfiniteListResults<CatalogueGeomV1> getGeomsFromCatalogueInfinite(ServiceSupportEnv env, String catalogueCode,
			AbsoluteDate referenceDate, @NotNull @Valid CataloguePayloadV1 payload, Boolean flVisible) {
				return cataloguesService.getGeomsFromCatalogueInfinite(env, catalogueCode, referenceDate,
						CataloguePayloadV1Mapper.INSTANCE.toPrivPayload(payload), flVisible)
					.map(CatalogueGeomV1Mapper.INSTANCE::toResponseV1);	
	}	
}
