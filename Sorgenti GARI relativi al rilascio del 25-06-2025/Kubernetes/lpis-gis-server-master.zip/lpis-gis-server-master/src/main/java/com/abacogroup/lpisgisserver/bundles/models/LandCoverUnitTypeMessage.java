package com.abacogroup.lpisgisserver.bundles.models;

import com.abacogroup.lpisgisserver.core.enums.UnitType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LandCoverUnitTypeMessage {
	
	private String land_cover_code;
	private UnitType type_code;
	
}
