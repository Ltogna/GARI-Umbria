package com.abacogroup.lpisgisserver.core.mappers.pub;

import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineDoIgtNTT;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.resources.res.pub.units.vine.DoIgtV1;
import com.abacogroup.lpisgisserver.resources.res.units.vine.DoIgt;

@Mapper(uses = {AbsoluteDateMapper.class} )
public interface DoIgtV1Mapper {

	DoIgtV1Mapper INSTANCE = Mappers.getMapper(DoIgtV1Mapper.class);
	
	DoIgtV1 toResponseV1(DoIgt entity);

	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	DoIgtV1 toResponseV1(VineDoIgtNTT entity);
}
