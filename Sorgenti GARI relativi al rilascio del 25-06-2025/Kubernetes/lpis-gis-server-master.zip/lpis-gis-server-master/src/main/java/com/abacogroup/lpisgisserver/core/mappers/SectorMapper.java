package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.SectorNTT;
import com.abacogroup.lpisgisserver.resources.res.Sector;

@Mapper
public interface SectorMapper {

	SectorMapper INSTANCE = Mappers.getMapper(SectorMapper.class);
	
	@Mapping(target = "sector_code", source = "sector")
	Sector entityToDto(SectorNTT entity);
	
	@Mapping(target = "sector", source = "sector_code")
	@Mapping(target = "sector_details_id", ignore = true)
	SectorNTT dtoToEntity(Sector dto);
}
