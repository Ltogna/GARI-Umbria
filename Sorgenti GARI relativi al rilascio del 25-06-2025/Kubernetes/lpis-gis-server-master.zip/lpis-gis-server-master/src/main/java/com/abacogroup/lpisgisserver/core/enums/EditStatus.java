package com.abacogroup.lpisgisserver.core.enums;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "The edit status of parcel or landcover")
public enum EditStatus {
	IN_EDIT,
	TOPOLOGY_CORRECTED,
	DELETED,
	ONLY_LANDCOVERS,
	ONLY_UNITS,
	NOT_IN_EDIT,
	LOCKED,
	EDITED,
	CONFIRMED,
	INHERITED, 
	VERSION_UPDATE
}
