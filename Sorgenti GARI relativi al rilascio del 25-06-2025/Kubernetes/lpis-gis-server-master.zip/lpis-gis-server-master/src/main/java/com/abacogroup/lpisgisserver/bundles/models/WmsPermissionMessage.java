package com.abacogroup.lpisgisserver.bundles.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WmsPermissionMessage {
	private String wms_server_code;
	private String context_function;
}
