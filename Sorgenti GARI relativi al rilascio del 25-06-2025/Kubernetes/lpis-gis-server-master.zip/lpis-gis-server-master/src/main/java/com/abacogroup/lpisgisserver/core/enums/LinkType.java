package com.abacogroup.lpisgisserver.core.enums;

public enum LinkType {
	BUTTON,
	OUTLINED_BUTTON
}
