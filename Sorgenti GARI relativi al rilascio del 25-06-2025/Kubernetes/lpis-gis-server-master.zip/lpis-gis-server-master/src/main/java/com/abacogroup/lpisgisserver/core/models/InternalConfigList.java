package com.abacogroup.lpisgisserver.core.models;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class InternalConfigList {
	private List<InternalConfig> internalConfig;
}
