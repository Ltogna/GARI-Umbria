package com.abacogroup.lpisgisserver.core.transform;

import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.CoordinateSequence;
import org.locationtech.jts.geom.CoordinateSequenceFilter;
import org.locationtech.proj4j.CoordinateReferenceSystem;
import org.locationtech.proj4j.CoordinateTransform;
import org.locationtech.proj4j.CoordinateTransformFactory;
import org.locationtech.proj4j.ProjCoordinate;

public class ReprojectCoordinateSequenceFilter implements CoordinateSequenceFilter {
	private static final CoordinateTransformFactory ctFactory = new CoordinateTransformFactory();

	private CoordinateTransform transformer;

	public ReprojectCoordinateSequenceFilter(CoordinateReferenceSystem fromCRS, CoordinateReferenceSystem toCRS) {
		this.transformer = ctFactory.createTransform(fromCRS, toCRS);
	}

	/**
	* Filters the ith coordinate of the sequence. This is done by transforming the coordinates to Proj coordinates and then re - ordinating the sequence to the new ordinate.
	* 
	* @param seq - the sequence to be filtered. This is modified in - place.
	* @param i - the index of the coordinate to be filtered. This is zero - based
	*/
	@Override
	public void filter(CoordinateSequence seq, int i) {
		Coordinate coord = seq.getCoordinate(i);

		ProjCoordinate result = new ProjCoordinate();
		transformer.transform(new ProjCoordinate(coord.x, coord.y), result);

		seq.setOrdinate(i, CoordinateSequence.X, result.x);
		seq.setOrdinate(i, CoordinateSequence.Y, result.y);
	}

	/**
	* Returns true if the task is done. This is a no - op for TaskExecutor#isDone ().
	* 
	* 
	* @return true if the task is done false otherwise ( in which case a RuntimeException is thrown ). Note that isDone () will return false even if the task has already been completed
	*/
	@Override
	public boolean isDone() {
		return false;
	}

	/**
	* Returns true if the geometry has changed. This is used to determine if the user has clicked on the button or not.
	* 
	* 
	* @return true if the geometry has changed false otherwise. Note that it is possible for the user to scroll to a different position
	*/
	@Override
	public boolean isGeometryChanged() {
		return true;
	}

}
