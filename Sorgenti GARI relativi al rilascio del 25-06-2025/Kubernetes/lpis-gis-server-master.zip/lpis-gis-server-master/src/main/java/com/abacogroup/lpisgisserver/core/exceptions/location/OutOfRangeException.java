package com.abacogroup.lpisgisserver.core.exceptions.location;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class OutOfRangeException extends AbstractException {

	private static final long serialVersionUID = -631288209510780457L;

	private static final ErrorCode ERROR_CODE = ErrorCode.OUT_OF_RANGE;

	public OutOfRangeException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new OutOfRangeExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Given geometry is out of range")
	public static class OutOfRangeExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -6905246824130062231L;

		public OutOfRangeExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
