package com.abacogroup.lpisgisserver.db.dao;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverInfoGisNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelInfoGisNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface InfoGisDAO extends Transactional<InfoGisDAO>, EnhancedSqlObject {
	
	@SqlQuery("§select_nextval(lpis_parcels_details_3d_sequence)§")
	Long parcelDetails3DNextSequenceVal();
	
	@SqlQuery("§select_nextval(lpis_parcels_lc_details_3d_sequence)§")
	Long landCoverDetails3DNextSequenceVal();

	@SqlUpdate("INSERT INTO lpis_parcels_details_3d (pkid, parcel_details_pkid, elevation, slope, aspect, dt_insert, dt_delete) " +
			"VALUES(:pkid, :parcelDetailsPkid, :elevation, :slope, :aspect, §current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insertParcelInfoGis(@BindBean ParcelInfoGisNTT parcelInfoGisNTT);
	
	@SqlUpdate("INSERT INTO lpis_parcels_lc_details_3d (pkid, landcover_details_pkid, elevation, slope, aspect, dt_insert, dt_delete) " +
			"VALUES(:pkid, :landcoverDetailsPkid, :elevation, :slope, :aspect, §current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insertLandCoverInfoGis(@BindBean LandCoverInfoGisNTT landCoverInfoGisNTT);
	
	@SqlQuery("select \n"
			+ "   lpdd.pkid, \n"
			+ "   lpdd.parcel_details_pkid, \n"
			+ "   lpdd.elevation, \n"
			+ "   lpdd.slope, \n"
			+ "   lpdd.aspect \n"
			+ "from \n"
			+ "   lpis_parcels_details_3d lpdd \n"
			+ "where \n"
			+ "   lpdd.parcel_details_pkid = :parcelDetailsPkid \n"
			+ "   and §current_timestamp§ between lpdd.dt_insert and lpdd.dt_delete \n")
	@RegisterBeanMapper(ParcelInfoGisNTT.class)
	ParcelInfoGisNTT getParcelInfoGis(@Bind("parcelDetailsPkid") Long parcelDetailsPkid);
	
	@SqlQuery("select \n"
			+ "   lpldd.pkid, \n"
			+ "   lpldd.landcover_details_pkid, \n"
			+ "   lpldd.elevation, \n"
			+ "   lpldd.slope, \n"
			+ "   lpldd.aspect \n"
			+ "from \n"
			+ "   lpis_parcels_lc_details_3d lpldd \n"
			+ "where \n"
			+ "   lpldd.landcover_details_pkid = :landcoverDetailsPkid \n"
			+ "   and §current_timestamp§ between lpldd.dt_insert and lpldd.dt_delete \n")
	@RegisterBeanMapper(LandCoverInfoGisNTT.class)
	LandCoverInfoGisNTT getLandCoverInfoGis(@Bind("landcoverDetailsPkid") Long landcoverDetailsPkid);
	
}
