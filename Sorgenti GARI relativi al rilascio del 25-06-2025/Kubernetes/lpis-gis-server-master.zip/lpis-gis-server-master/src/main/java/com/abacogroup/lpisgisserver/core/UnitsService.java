package com.abacogroup.lpisgisserver.core;

import java.util.List;
import java.util.stream.Collectors;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.exceptions.units.fruit.FruitUnitNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.units.olive.OliveUnitNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.units.vine.VineUnitNotFoundException;
import com.abacogroup.lpisgisserver.core.mappers.units.FruitUnitMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.OliveUnitMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.VineAptitudesMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.VineUnitMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.FruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.OliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.VineUnitsDAO;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.FruitUnitWithParcelDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.OliveUnitWithParcelDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineAptitudeNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineUnitWithParcelDetailsNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.ReqContext;
import com.abacogroup.lpisgisserver.resources.res.anomalies.AnomaliesList;
import com.abacogroup.lpisgisserver.resources.res.units.fruit.FruitUnitWithParcelDetails;
import com.abacogroup.lpisgisserver.resources.res.units.olive.OliveUnitWithParcelDetails;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnitWithParcelDetails;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UnitsService extends BaseService {

	private final VineUnitsDAO vineUnitsDAO;
	private final OliveUnitsDAO oliveUnitsDAO;
	private final FruitUnitsDAO fruitUnitsDAO;
	
	private final AnomaliesService anomaliesService;

	public UnitsService(DAOContainer dc, AnomaliesService anomaliesService, InternalConfigService conf, 
			ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService, StyleService styleService, 
			PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.vineUnitsDAO = dc.getVineUnitsDAO();
		this.oliveUnitsDAO = dc.getOliveUnitsDAO();
		this.fruitUnitsDAO = dc.getFruitUnitsDAO();
		
		this.anomaliesService = anomaliesService;
	}

	public VineUnitWithParcelDetails getVineUnitByCode(ServiceSupportEnv env, String unitCode) {
		VineUnitWithParcelDetailsNTT vineUnitNTT = vineUnitsDAO.getVineUnitWithParcelDetailsByUnitCode(env, unitCode);
		
		if (vineUnitNTT == null) {
			VineUnitNotFoundException ex = new VineUnitNotFoundException(Status.NOT_FOUND, env.getOperation(), 
					ErrorField.UNIT_CODE, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		VineUnitWithParcelDetails vineUnit = VineUnitMapper.INSTANCE.entityToDtoWithParcelDetails(vineUnitNTT);
		
		env.setLandCoverId(vineUnit.getLandCoverId());
		List<VineAptitudeNTT> vineAptitudeNTT = vineUnitsDAO.getVineAptitudes(env, vineUnit.getId(), null, 0);
		vineUnit.setVineAptitudes(vineAptitudeNTT.stream()
				.map(VineAptitudesMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList()));
		
//		ReqContext reqContext = new ReqContext(env.getTenantId(), env.getUserName(), env.getLang());
//		AnomaliesList parcelAnomalies = anomaliesService.getParcelAnomalies(reqContext, env.getParcelId());
//		vineUnit.setAnomalies(parcelAnomalies.getAnomalies_list() != null ? parcelAnomalies.getAnomalies_list() : null);
		
		return vineUnit;
	}
	
	public OliveUnitWithParcelDetails getOliveUnitByCode(ServiceSupportEnv env, String unitCode) {
		OliveUnitWithParcelDetailsNTT oliveUnitNTT = oliveUnitsDAO.getOliveUnitWithParcelDetailsByUnitCode(env, unitCode);
		
		if (oliveUnitNTT == null) {
			OliveUnitNotFoundException ex = new OliveUnitNotFoundException(Status.NOT_FOUND, env.getOperation(), 
					ErrorField.UNIT_CODE, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
			
			log.error(ex.getBody().getLogErrorMessage());
			
			throw ex;
		}
		
		OliveUnitWithParcelDetails oliveUnit = OliveUnitMapper.INSTANCE.entityToDtoWithParcelDetails(oliveUnitNTT);
		
		ReqContext reqContext = new ReqContext(env.getTenantId(), env.getUserName(), env.getLang());
		AnomaliesList parcelAnomalies = anomaliesService.getParcelAnomalies(reqContext, env.getParcelId());
		oliveUnit.setAnomalies(parcelAnomalies.getAnomalies_list() != null ? parcelAnomalies.getAnomalies_list() : null);
		
		return oliveUnit;
	}
	
	public FruitUnitWithParcelDetails getFruitUnitByCode(ServiceSupportEnv env, String unitCode) {
		FruitUnitWithParcelDetailsNTT fruitUnitNTT = fruitUnitsDAO.getFruitUnitWithParcelDetailsByUnitCode(env, unitCode);
		
		if (fruitUnitNTT == null) {
			FruitUnitNotFoundException ex = new FruitUnitNotFoundException(Status.NOT_FOUND, env.getOperation(), 
					ErrorField.UNIT_CODE, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
			
			log.error(ex.getBody().getLogErrorMessage());
			
			throw ex;
		}
		
		FruitUnitWithParcelDetails fruitUnit = FruitUnitMapper.INSTANCE.entityToDtoWithParcelDetails(fruitUnitNTT);
		
		ReqContext reqContext = new ReqContext(env.getTenantId(), env.getUserName(), env.getLang());
		AnomaliesList parcelAnomalies = anomaliesService.getParcelAnomalies(reqContext, env.getParcelId());
		fruitUnit.setAnomalies(parcelAnomalies.getAnomalies_list() != null ? parcelAnomalies.getAnomalies_list() : null);
		
		return fruitUnit;
	}

}
