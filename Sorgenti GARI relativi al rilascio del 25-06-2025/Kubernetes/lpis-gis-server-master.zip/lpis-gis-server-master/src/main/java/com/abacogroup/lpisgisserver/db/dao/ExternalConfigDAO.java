package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.ExternalConfigNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface ExternalConfigDAO extends Transactional<ExternalConfigDAO>, EnhancedSqlObject {
	@SqlUpdate("insert into lpis_external_config (tenant_id, key, value) values(:tenant_id, :key, :value)")
	void insert(@BindBean ExternalConfigNTT config);

	@SqlUpdate("update lpis_external_config set value = :value where tenant_id = :tenant_id and key = :key")
	void updateValue(@BindBean ExternalConfigNTT config);

	@SqlUpdate("delete from lpis_external_config where tenant_id = :tenantId and key = :key")
	void deleteByTenantAndKey(@Bind("tenantId") String tenantId, @Bind("key") String key);

	@SqlQuery("\n"
			+ "select tenant_id, \n"
			+ "       key, \n"
			+ "       value \n"
			+ "  from lpis_external_config \n"
			+ " where tenant_id = :tenantId \n"
			+ " and key = :key \n")
	@RegisterBeanMapper(ExternalConfigNTT.class)
	ExternalConfigNTT getConfigByTenantAndKey(@Bind("tenantId") String tenantId, @Bind("key") String key);

	@SqlQuery("\n"
			+ "select tenant_id, \n"
			+ "       key, \n"
			+ "       value \n"
			+ "  from lpis_external_config \n"
			+ " where tenant_id = :tenantId \n")
	@RegisterBeanMapper(ExternalConfigNTT.class)
	List<ExternalConfigNTT> getConfigByTenant(@Bind("tenantId") String tenantId);

}
