package com.abacogroup.lpisgisserver.core;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.ErrorItem;
import com.abacogroup.lpisgisserver.core.exceptions.InvalidFormException;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.LandCoverNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.units.RevokeDateNotValidException;
import com.abacogroup.lpisgisserver.core.exceptions.units.vine.VineAptitudeIdNotValidException;
import com.abacogroup.lpisgisserver.core.exceptions.units.vine.VineUnitIdNotValidException;
import com.abacogroup.lpisgisserver.core.exceptions.units.vine.VineUnitNotEditableException;
import com.abacogroup.lpisgisserver.core.support.EditorSupportParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditLandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.EditVineUnitsDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineAptitudeNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineDoIgtNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineUnitDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineyardNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.CreateOrUpdateVineAptitudesPayload;
import com.abacogroup.lpisgisserver.resources.req.RevokeVineAptitudePayload;
import com.abacogroup.lpisgisserver.resources.req.pub.CreateOrUpdateVineUnitPayloadV1;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineAptitude;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnitWithAptitudes;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EditVineUnitsService extends BaseService {

	private final EditLandCoversSupportService editLandCoversSupportService;
	private final EditVineUnitsSupportService editVineUnitsSupportService;
	private final EditUnitsSupportService editUnitsSupportService;

	private static final DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE;
	private static final UnitType UNIT_TYPE = UnitType.VINE_UNIT;
	private static final boolean SKIP_FORBIDDEN_LC_CHECK = true;
	
	private final EditLandCoversDAO editLandCoversDAO;
	private final EditVineUnitsDAO editVineUnitsDAO;


	public EditVineUnitsService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService,
			EditLandCoversSupportService editLandCoversSupportService, EditVineUnitsSupportService editVineUnitsSupportService, 
			EditUnitsSupportService editUnitsSupportService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.editLandCoversDAO = dc.getEditLandCoversDAO();
		this.editVineUnitsDAO = dc.getEditVineUnitsDAO();

		this.editLandCoversSupportService = editLandCoversSupportService;
		this.editVineUnitsSupportService = editVineUnitsSupportService;
		this.editUnitsSupportService = editUnitsSupportService;
	}

	public VineUnitWithAptitudes createVineUnits(EditorSupportParams params, @NotNull @Valid CreateOrUpdateVineUnitPayloadV1 payload) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		
		List<ErrorItem> errorList = new ArrayList<>();
		internalCheckCreateOrUpdateVineUnitPayload(params, env, payload, errorList);
		
		LandCoverNTT landCoverNTT = getLandCoverNTT(env, params.getParcelId(), params.getLandCoverId(), params.getOperation());
		editVineUnitsSupportService.checkVineUnitValidationDates(env, payload, landCoverNTT, null, errorList);
		
		if(!errorList.isEmpty()) {
			InvalidFormException ex = new InvalidFormException(Status.BAD_REQUEST, params.getOperation(), ErrorField.FORM,
					errorList, this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Long editId = editVineUnitsDAO.nextEditVineUnitDetailPkidVal();
		Long newUnitId = editVineUnitsDAO.nextNewVineUnitIdVal();
		String unitCode = payload.getUnitCode() != null ? payload.getUnitCode() : getNewUnitCode(env, UNIT_TYPE);
		VineUnitDetailsNTT vineUnitToInsert = editVineUnitsSupportService.buildVineUnitDetailsNTTFromPayload(payload, editId,
				landCoverNTT.getEdit_id(), newUnitId, unitCode, EditStatus.IN_EDIT, 1, null);

		editVineUnitsDAO.insertEditVineUnitDetail(env, vineUnitToInsert);

		params.setVineUnitId(newUnitId);
		return getVineUnits(params).get(0);
	}

	public VineUnitWithAptitudes updateVineUnits(EditorSupportParams params, @NotNull @Valid CreateOrUpdateVineUnitPayloadV1 payload) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		
		List<ErrorItem> errorList = new ArrayList<>();
		internalCheckCreateOrUpdateVineUnitPayload(params, env, payload, errorList);
		
		LandCoverNTT landCoverNTT = getLandCoverNTT(env, params.getParcelId(), params.getLandCoverId(), params.getOperation());
		VineUnitDetailsNTT inEditUnit = editVineUnitsDAO.findInEditVineUnitsBySessionId(env, params.getLandCoverId(), params.getVineUnitId(), null).get(0);
		
		//check if editable
		if(inEditUnit.getPlantingDay().toLocalDate().isAfter(env.getReferenceDate().toLocalDate()) 
				|| inEditUnit.getEradicateDay().toLocalDate().isBefore(env.getReferenceDate().toLocalDate())) {			
			VineUnitNotEditableException ex = new VineUnitNotEditableException(Status.BAD_REQUEST, params.getOperation(), 
					ErrorField.PAYLOAD, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		editVineUnitsSupportService.checkVineUnitValidationDates(env, payload, landCoverNTT, inEditUnit, errorList);

		if(!errorList.isEmpty()) {
			InvalidFormException ex = new InvalidFormException(Status.BAD_REQUEST, params.getOperation(), ErrorField.FORM,
					errorList, this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		VineUnitDetailsNTT vineUnitToUpdate =  editVineUnitsSupportService.buildVineUnitDetailsNTTFromPayload(payload, inEditUnit.getEditId(), 
				inEditUnit.getEditLandCoverId(), inEditUnit.getUnitId(), inEditUnit.getUnitCode(), EditStatus.IN_EDIT, inEditUnit.getFlDeletable(),
				inEditUnit.getParentUnitCode());
		
		editVineUnitsDAO.updateEditVineUnitDetail(env.getSessionId(), vineUnitToUpdate);

		return getVineUnits(params).get(0); 
	}

	public List<VineUnitWithAptitudes> getVineUnits(EditorSupportParams params) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()), SKIP_FORBIDDEN_LC_CHECK);
		editUnitsSupportService.checkLandCoverCodeCompatibility(env, params.getParcelId(), params.getLandCoverId(), UNIT_TYPE, params.getOperation());

		List<VineUnitWithAptitudes> vineUnits = editVineUnitsSupportService.internalGetVineUnits(params, params.getLandCoverId(), params.getVineUnitId());

		vineUnits.stream().forEach(u -> {
			List<VineAptitude> vineAptitudes = editVineUnitsSupportService.internalGetVineAptitudes(params, u.getId(), null, false);
			u.setVineAptitudes(vineAptitudes);
		});

		return vineUnits;
	}

	public Response deleteVineUnitById(EditorSupportParams params) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()));
		editUnitsSupportService.checkLandCoverCodeCompatibility(env, params.getParcelId(), params.getLandCoverId(), UNIT_TYPE, params.getOperation());
		editVineUnitsSupportService.checkAndInsertEditParcelLandCoversVineUnitAndAptitudes(params, null);

		Long vineUnitId = params.getVineUnitId();
		if(vineUnitId == null || !editVineUnitsSupportService.isDeletable(env, params.getLandCoverId(), vineUnitId)) {
			VineUnitIdNotValidException ex = new VineUnitIdNotValidException(Status.BAD_REQUEST, params.getOperation(), 
					ErrorField.UNIT_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		editVineUnitsDAO.deleteVineUnitsById(env.getSessionId(), vineUnitId);

		return Response.ok().build();
	}
	
	public Response eradicateVineUnits(EditorSupportParams params) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()));
		editVineUnitsSupportService.checkAndInsertEditParcelLandCoversVineUnitAndAptitudes(params, null);
		
		AbsoluteDate newEradicateDay = env.getReferenceDate();
		
		VineUnitDetailsNTT inEditUnit = editVineUnitsDAO.findInEditVineUnitsBySessionId(env, params.getLandCoverId(), params.getVineUnitId(), null).get(0);

		//check if editable
		if(inEditUnit.getPlantingDay().toLocalDate().isAfter(env.getReferenceDate().toLocalDate()) 
				|| inEditUnit.getEradicateDay().toLocalDate().isBefore(env.getReferenceDate().toLocalDate())) {
			VineUnitNotEditableException ex = new VineUnitNotEditableException(Status.BAD_REQUEST, params.getOperation(), 
					ErrorField.PAYLOAD, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		inEditUnit.setEradicateDay(newEradicateDay);
		inEditUnit.setEditStatus(EditStatus.IN_EDIT);

		editVineUnitsDAO.updateEditVineUnitDetail(env.getSessionId(), inEditUnit);

		return Response.ok().build(); 
	}

	public VineAptitude createVineAptitude(EditorSupportParams params, @NotNull @Valid CreateOrUpdateVineAptitudesPayload payload) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		List<ErrorItem> errorList = new ArrayList<>();
		internalCheckCreateOrUpdateVineAptitudesPayload(params, env, payload, null, errorList);

		VineUnitDetailsNTT editVineUnit = editVineUnitsDAO.findInEditVineUnitsBySessionId(env, params.getLandCoverId(), params.getVineUnitId(), null).get(0);

		if(!errorList.isEmpty()) {
			InvalidFormException ex = new InvalidFormException(Status.BAD_REQUEST, params.getOperation(), ErrorField.FORM,
					errorList, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		Long aptitudeId = editVineUnitsDAO.nextNewVineAptitudeIdVal();
		VineAptitudeNTT vineAptitudeToInsert = VineAptitudeNTT.builder()
				.editId(editVineUnitsDAO.nextEditVineUnitAptitudePkidVal())
				.editUnitId(editVineUnit.getEditId())
				.aptitudeId(aptitudeId)
				.doigt(VineDoIgtNTT.builder().code(payload.getDoigtCode()).build())
				.dayFrom(payload.getDayFrom())
				.dayFromPrecision(payload.getDayFromPrecision())
				.dayTo(payload.getDayTo())
				.flPreventTypology(boolToInt(payload.getPreventTypology()))
				.flPreventClaim(boolToInt(payload.getPreventClaim()))
				.flPreventSuitability(boolToInt(payload.getPreventSuitability()))
				.editStatus(EditStatus.IN_EDIT)
				.vineyard(VineyardNTT.builder().code(payload.getVineyardCode()).build())
				.build();

		editVineUnitsDAO.insertEditVineAptitude(env, vineAptitudeToInsert);

		return getVineAptitudes(params, aptitudeId, false).get(0);
	}

	public VineAptitude updateVineAptitudes(EditorSupportParams params, Long vineAptitudeId,
			@NotNull @Valid CreateOrUpdateVineAptitudesPayload payload) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		List<ErrorItem> errorList = new ArrayList<>();
		internalCheckCreateOrUpdateVineAptitudesPayload(params, env, payload, vineAptitudeId, errorList);

		VineAptitudeNTT inEditAptitude = editVineUnitsDAO.findInEditVineAptitudesBySessionId(env, params.getVineUnitId(), vineAptitudeId, 1, null).get(0);
		
		if(!errorList.isEmpty()) {
			InvalidFormException ex = new InvalidFormException(Status.BAD_REQUEST, params.getOperation(), ErrorField.FORM,
					errorList, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		VineAptitudeNTT vineAptitudeToInsert = VineAptitudeNTT.builder()
				.editId(inEditAptitude.getEditId())
				.editUnitId(inEditAptitude.getEditUnitId())
				.aptitudeId(inEditAptitude.getAptitudeId())
				.doigt(VineDoIgtNTT.builder().code(payload.getDoigtCode()).build())
				.dayFrom(payload.getDayFrom())
				.dayFromPrecision(payload.getDayFromPrecision())
				.dayTo(payload.getDayTo())
				.flPreventTypology(boolToInt(payload.getPreventTypology()))
				.flPreventClaim(boolToInt(payload.getPreventClaim()))
				.flPreventSuitability(boolToInt(payload.getPreventSuitability()))
				.editStatus(EditStatus.IN_EDIT)
				.vineyard(VineyardNTT.builder().code(payload.getVineyardCode()).build())
				.build();

		editVineUnitsDAO.updateEditVineAptitude(env.getSessionId(), vineAptitudeToInsert);
		return getVineAptitudes(params, vineAptitudeId, true).get(0);
	}

	public List<VineAptitude> getVineAptitudes(EditorSupportParams params, Long vineAptitudeId, Boolean showOutdatedUnits) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()), SKIP_FORBIDDEN_LC_CHECK);
		editUnitsSupportService.checkLandCoverCodeCompatibility(env, params.getParcelId(), params.getLandCoverId(), UNIT_TYPE, params.getOperation());

		editVineUnitsSupportService.internalGetVineUnits(params, params.getLandCoverId(), params.getVineUnitId());

		return editVineUnitsSupportService.internalGetVineAptitudes(params, params.getVineUnitId(), vineAptitudeId, showOutdatedUnits);

	}

	public Response deleteVineAptitudes(EditorSupportParams params, Long vineAptitudeId) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()));
		editUnitsSupportService.checkLandCoverCodeCompatibility(env, params.getParcelId(), params.getLandCoverId(), UNIT_TYPE, params.getOperation());

		if(vineAptitudeId == null || vineAptitudeId > 0) {
			VineAptitudeIdNotValidException ex = new VineAptitudeIdNotValidException(Status.BAD_REQUEST, params.getOperation(), 
					ErrorField.VINE_APTITUDE_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		editVineUnitsSupportService.checkAndInsertEditParcelLandCoversVineUnitAndAptitudes(params, vineAptitudeId);

		editVineUnitsDAO.deleteVineAptitudeById(env.getSessionId(), vineAptitudeId);

		return Response.ok().build();
	}

	public Response revokeVineAptitude(EditorSupportParams params, @NotNull Long vineAptitudeId, @NotNull @Valid RevokeVineAptitudePayload payload) {
	
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()));
		editUnitsSupportService.checkLandCoverCodeCompatibility(env, params.getParcelId(), params.getLandCoverId(), UNIT_TYPE, params.getOperation());
		editVineUnitsSupportService.checkAndInsertEditParcelLandCoversVineUnitAndAptitudes(params, vineAptitudeId);

		VineAptitudeNTT inEditAptitude = editVineUnitsDAO.findInEditVineAptitudesBySessionId(env, params.getVineUnitId(), vineAptitudeId, 1, null).get(0);
		if((!inEditAptitude.getDayTo().toLocalDate().isEqual(payload.getDayTo().toLocalDate()) 
				&& payload.getDayTo().toLocalDate().isAfter(editVineUnitsDAO.getCurrentTimestamp().toLocalDate()))
				|| inEditAptitude.getDayFrom().toLocalDate().isAfter(payload.getDayTo().toLocalDate())) {

			RevokeDateNotValidException ex = new RevokeDateNotValidException(Status.BAD_REQUEST, params.getOperation(), 
					ErrorField.PAYLOAD, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					formatter.format(inEditAptitude.getDayFrom().toLocalDate()) , formatter.format(editVineUnitsDAO.getCurrentTimestamp().toLocalDate()));

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		inEditAptitude.setDayTo(payload.getDayTo());
		inEditAptitude.setEditStatus(EditStatus.IN_EDIT);
	
		editVineUnitsDAO.updateEditVineAptitude(env.getSessionId(), inEditAptitude);
	
		return Response.ok().build();
	}

	private void internalCheckCreateOrUpdateVineUnitPayload(EditorSupportParams params, ServiceSupportEnv env,
			CreateOrUpdateVineUnitPayloadV1 payload, List<ErrorItem> errorList) {
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()));
		editUnitsSupportService.checkLandCoverCodeCompatibility(env, params.getParcelId(), params.getLandCoverId(), UNIT_TYPE, params.getOperation());
		editVineUnitsSupportService.checkCreateOrUpdateVineUnitPayload(params, payload, errorList);
		editVineUnitsSupportService.checkAndInsertEditParcelLandCoversVineUnitAndAptitudes(params, null);
	}
	

	private void internalCheckCreateOrUpdateVineAptitudesPayload(EditorSupportParams params, ServiceSupportEnv env, 
			CreateOrUpdateVineAptitudesPayload payload, Long vineAptitudeId, List<ErrorItem> errorList) {
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()));
		editUnitsSupportService.checkLandCoverCodeCompatibility(env, params.getParcelId(), params.getLandCoverId(), UNIT_TYPE, params.getOperation());

		VineUnitDetailsNTT vineUnit = editVineUnitsSupportService.getVineUnitsNTT(params, params.getLandCoverId(), params.getVineUnitId()).get(0);
		
		VineAptitudeNTT oldVineAptitude = null;
		if(vineAptitudeId != null) {
			oldVineAptitude = editVineUnitsSupportService.getVineAptitudesNTT(params, params.getVineUnitId(), vineAptitudeId, false).get(0);
		}
		
		editVineUnitsSupportService.checkCreateOrUpdateVineAptitudesPayload(env, payload, vineUnit, oldVineAptitude, params.getOperation(), errorList);

		editVineUnitsSupportService.checkAndInsertEditParcelLandCoversVineUnitAndAptitudes(params, vineAptitudeId);
	}

	private LandCoverNTT getLandCoverNTT(ServiceSupportEnv env, Long parcelId, Long landCoverId, Operation operation) {
		LandCoverNTT landCoverNTT = editLandCoversDAO.findInEditBySessionId(env, parcelId).stream()
				.filter(lc -> lc.getLand_cover_id().equals(landCoverId))
				.findFirst()
				.orElse(null);
	
		if(landCoverNTT == null) {
			LandCoverNotFoundException ex = new LandCoverNotFoundException(Status.NOT_FOUND, operation, ErrorField.LANDCOVER_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
	
			log.error(ex.getBody().getLogErrorMessage());
	
			throw ex;
		}
		return landCoverNTT;
	}
}
