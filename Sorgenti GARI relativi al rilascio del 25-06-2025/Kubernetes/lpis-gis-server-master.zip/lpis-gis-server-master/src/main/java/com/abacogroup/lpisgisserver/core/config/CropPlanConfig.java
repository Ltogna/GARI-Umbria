package com.abacogroup.lpisgisserver.core.config;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
@Valid
public class CropPlanConfig {

	@NotEmpty
	private String url;
	
}
