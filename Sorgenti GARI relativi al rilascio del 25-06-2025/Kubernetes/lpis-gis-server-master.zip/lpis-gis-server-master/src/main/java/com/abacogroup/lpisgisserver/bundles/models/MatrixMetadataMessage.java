package com.abacogroup.lpisgisserver.bundles.models;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MatrixMetadataMessage {
	private String matrix_code;
	private List<MatrixClassMetadataMessage> class_metadata_list;
	private List<MatrixLandCoverMetadataMessage> land_cover_metadata_list;
	private List<MatrixLandUseMetadataMessage> land_use_metadata_list;
}
