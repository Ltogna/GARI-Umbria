package com.abacogroup.lpisgisserver.bundles;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.lpisgisserver.bundles.models.I18nMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitCultivationStatusMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitFarmingFormMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitHeaderAnchoringMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitIrrigationTypeMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitPolesHeaderMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitPolesWeavingMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitProductDestinationMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitSupportWiresMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitTerracingMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitVariationTypeMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitVarietyMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitVineDoigtMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitVineyardMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.VineUnitMessage;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.UnitCodesDAO;
import com.abacogroup.lpisgisserver.db.ntt.units.CultivationStatusNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.FarmingFormNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.HeaderAnchoringNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.IrrigationNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.PolesHeaderNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.PolesWeavingNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.ProductDestinationNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.SupportWiresNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.TerracingNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.VariationTypeNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.VarietyNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineDoIgtNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineyardNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

public class VineUnitMessageProcessor extends AbstractMessageProcessor {

	protected UnitCodesDAO unitCodesDAO;

	private final ObjectMapper objectMapper;

	private static final String FARMING_FORM_TABLE_NAME = "lpis_unit_farming_form";
	private static final String CULTIVATION_STATUS_TABLE_NAME = "lpis_unit_cultivation_status";
	private static final String HEADER_ANCHORING_TABLE_NAME = "lpis_unit_header_anchoring";
	private static final String IRRIGATION_TABLE_NAME = "lpis_unit_irrigation";
	private static final String POLES_HEADER_TABLE_NAME = "lpis_unit_poles_header";
	private static final String POLES_WEAVING_TABLE_NAME = "lpis_unit_poles_weaving";
	private static final String PRODUCT_DESTINATION_TABLE_NAME = "lpis_unit_product_destination";
	private static final String SUPPORT_WIRES_TABLE_NAME = "lpis_unit_support_wires";
	private static final String TERRACING_TABLE_NAME = "lpis_unit_terracing";
	private static final String VARIATION_TYPE_TABLE_NAME = "lpis_unit_variation_type";
	private static final String VARIETY_TABLE_NAME = "lpis_unit_variety";
	private static final String VINE_DOIGT_TABLE_NAME = "lpis_unit_vine_doigt";
	private static final String VINEYARD_TABLE_NAME = "lpis_unit_vineyard";

	private static final UnitType UNIT_TYPE = UnitType.VINE_UNIT;

	private static final String VINE_UNIT_FIELD_NAME = "code";

	private static final Logger log = LoggerFactory.getLogger(VineUnitMessageProcessor.class);

	public VineUnitMessageProcessor(DAOContainer dc) {
		super(dc);
		this.unitCodesDAO = dc.getUnitCodesDAO();

		objectMapper = new ObjectMapper();
	}

	@Override
	public void onMessage(ConfigDataMessage message) {

		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
						&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
				.forEach(file -> insertOrUpdateVineUnitMessage(message.getTenantId(), file));
	}

	@Override
	public String getDomainName() {
		return "vine-units";
	}

	private void insertOrUpdateVineUnitMessage(String tenantId, File file) {
		try {
			VineUnitMessage vineUnitMessage = objectMapper.readValue(file, VineUnitMessage.class);

			if (vineUnitMessage == null) {
				return;
			}

			insertOrUpdateFarmingForms(vineUnitMessage.getFarming_forms(), tenantId);

			insertOrUpdateCultivationStatus(vineUnitMessage.getCultivation_status(), tenantId);

			insertOrUpdateHeaderAnchoringCodes(vineUnitMessage.getHeader_anchoring_codes(), tenantId);

			insertOrUpdateIrrigationTypes(vineUnitMessage.getIrrigation_types(), tenantId);

			insertOrUpdatePolesHeaderCode(vineUnitMessage.getPoles_header_codes(), tenantId);

			insertOrUpdatePolesWeavingCode(vineUnitMessage.getPoles_weaving_codes(), tenantId);

			insertOrUpdateProductDestinationCode(vineUnitMessage.getProduct_destination_codes(), tenantId);

			insertOrUpdateSupportWiresCode(vineUnitMessage.getSupport_wires_codes(), tenantId);

			insertOrUpdateTerracingCode(vineUnitMessage.getTerracing_codes(), tenantId);

			insertOrUpdateVariationType(vineUnitMessage.getVariation_types(), tenantId);

			insertOrUpdateVarietyCode(vineUnitMessage.getVariety_codes(), tenantId);

			insertOrUpdateVineDoigtCode(vineUnitMessage.getVine_doigt_codes(), tenantId);
			
			insertOrUpdateVineyardCode(vineUnitMessage.getVineyard_codes(), tenantId);

		} catch (Exception e) {
			log.error("Error processing file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}
	}

	private void insertOrUpdateFarmingForms(List<UnitFarmingFormMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				FarmingFormNTT farmingForm = FarmingFormNTT.builder()
						.typeCode(UNIT_TYPE)
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				FarmingFormNTT farmingFormToFind = unitCodesDAO.findFarmingForm(tenantId, UNIT_TYPE, farmingForm.getCode());
				if (farmingFormToFind == null) {
					unitCodesDAO.insertFarmingForm(tenantId, farmingForm);
				} else {
					if (!farmingFormToFind.getFlVisible().equals(farmingForm.getFlVisible())) {
						unitCodesDAO.updateFarmingForm(tenantId, farmingForm);
					}
				}

				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(FARMING_FORM_TABLE_NAME)
						.field(VINE_UNIT_FIELD_NAME)
						.value(UNIT_TYPE + ":" + farmingForm.getCode())
						.translations(message.getDescription())
						.build();

				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of farming form code {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}

	private void insertOrUpdateCultivationStatus(List<UnitCultivationStatusMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				CultivationStatusNTT status = CultivationStatusNTT.builder()
						.typeCode(UNIT_TYPE)
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				CultivationStatusNTT cultivationStatusToFind = unitCodesDAO.findCultivationStatus(tenantId, UNIT_TYPE, status.getCode());
				if (cultivationStatusToFind == null) {
					unitCodesDAO.insertCultivationStatus(tenantId, status);
				} else {
					if (!cultivationStatusToFind.getFlVisible().equals(status.getFlVisible())) {
						unitCodesDAO.updateCultivationStatus(tenantId, status);
					}
				}

				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(CULTIVATION_STATUS_TABLE_NAME)
						.field(VINE_UNIT_FIELD_NAME)
						.value(UNIT_TYPE + ":" + status.getCode())
						.translations(message.getDescription())
						.build();

				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of cultivation status code {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}

	private void insertOrUpdateHeaderAnchoringCodes(List<UnitHeaderAnchoringMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				HeaderAnchoringNTT headerAnchoring = HeaderAnchoringNTT.builder()
						.typeCode(UNIT_TYPE)
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				HeaderAnchoringNTT headerAnchoringToFind = unitCodesDAO.findHeaderAnchoringCode(tenantId, UNIT_TYPE, headerAnchoring.getCode());
				if (headerAnchoringToFind == null) {
					unitCodesDAO.insertHeaderAnchoringCode(tenantId, headerAnchoring);
				} else {
					if (!headerAnchoringToFind.getFlVisible().equals(headerAnchoring.getFlVisible())) {
						unitCodesDAO.updateHeaderAnchoringCode(tenantId, headerAnchoring);
					}
				}

				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(HEADER_ANCHORING_TABLE_NAME)
						.field(VINE_UNIT_FIELD_NAME)
						.value(UNIT_TYPE + ":" + headerAnchoring.getCode())
						.translations(message.getDescription())
						.build();

				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of header anchoring code {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}

	private void insertOrUpdateIrrigationTypes(List<UnitIrrigationTypeMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				IrrigationNTT type = IrrigationNTT.builder()
						.typeCode(UNIT_TYPE)
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				IrrigationNTT irrigationTypeToFind = unitCodesDAO.findIrrigationType(tenantId, UNIT_TYPE, type.getCode());
				if (irrigationTypeToFind == null) {
					unitCodesDAO.insertIrrigationType(tenantId, type);
				} else {
					if (!irrigationTypeToFind.getFlVisible().equals(type.getFlVisible())) {
						unitCodesDAO.updateIrrigationType(tenantId, type);
					}
				}

				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(IRRIGATION_TABLE_NAME)
						.field(VINE_UNIT_FIELD_NAME)
						.value(UNIT_TYPE + ":" + type.getCode())
						.translations(message.getDescription())
						.build();

				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of irrigation type {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}

	private void insertOrUpdatePolesHeaderCode(List<UnitPolesHeaderMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				PolesHeaderNTT polesHeaderNTT = PolesHeaderNTT.builder()
						.typeCode(UNIT_TYPE)
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				PolesHeaderNTT polesHeaderCodeToFind = unitCodesDAO.findPolesHeaderCode(tenantId, UNIT_TYPE, polesHeaderNTT.getCode());
				if (polesHeaderCodeToFind == null) {
					unitCodesDAO.insertPolesHeaderCode(tenantId, polesHeaderNTT);
				} else {
					if (!polesHeaderCodeToFind.getFlVisible().equals(polesHeaderNTT.getFlVisible())) {
						unitCodesDAO.updatePolesHeaderCode(tenantId, polesHeaderNTT);
					}
				}

				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(POLES_HEADER_TABLE_NAME)
						.field(VINE_UNIT_FIELD_NAME)
						.value(UNIT_TYPE + ":" + polesHeaderNTT.getCode())
						.translations(message.getDescription())
						.build();

				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of poles header code {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}

	private void insertOrUpdatePolesWeavingCode(List<UnitPolesWeavingMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				PolesWeavingNTT polesWeavingNTT = PolesWeavingNTT.builder()
						.typeCode(UNIT_TYPE)
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				PolesWeavingNTT polesWeavingCodeToFind = unitCodesDAO.findPolesWeavingCode(tenantId, UNIT_TYPE, polesWeavingNTT.getCode());
				if (polesWeavingCodeToFind == null) {
					unitCodesDAO.insertPolesWeavingCode(tenantId, polesWeavingNTT);
				} else {
					if (!polesWeavingCodeToFind.getFlVisible().equals(polesWeavingNTT.getFlVisible())) {
						unitCodesDAO.updatePolesWeavingCode(tenantId, polesWeavingNTT);
					}
				}

				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(POLES_WEAVING_TABLE_NAME)
						.field(VINE_UNIT_FIELD_NAME)
						.value(UNIT_TYPE + ":" + polesWeavingNTT.getCode())
						.translations(message.getDescription())
						.build();

				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of poles weaving code {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}

	private void insertOrUpdateProductDestinationCode(List<UnitProductDestinationMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				ProductDestinationNTT productDestinationNTT = ProductDestinationNTT.builder()
						.typeCode(UNIT_TYPE)
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				ProductDestinationNTT productDestinationCodeToFind = unitCodesDAO.findProductDestinationCode(tenantId, UNIT_TYPE,
						productDestinationNTT.getCode());
				if (productDestinationCodeToFind == null) {
					unitCodesDAO.insertProductDestinationCode(tenantId, productDestinationNTT);
				} else {
					if (!productDestinationCodeToFind.getFlVisible().equals(productDestinationNTT.getFlVisible())) {
						unitCodesDAO.updateProductDestinationCode(tenantId, productDestinationNTT);
					}
				}

				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(PRODUCT_DESTINATION_TABLE_NAME)
						.field(VINE_UNIT_FIELD_NAME)
						.value(UNIT_TYPE + ":" + productDestinationNTT.getCode())
						.translations(message.getDescription())
						.build();

				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of product destination code {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}

	private void insertOrUpdateSupportWiresCode(List<UnitSupportWiresMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				SupportWiresNTT supportWiresNTT = SupportWiresNTT.builder()
						.typeCode(UNIT_TYPE)
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				SupportWiresNTT supportWiresCodeToFind = unitCodesDAO.findSupportWireCode(tenantId, UNIT_TYPE, supportWiresNTT.getCode());
				if (supportWiresCodeToFind == null) {
					unitCodesDAO.insertSupportWireCode(tenantId, supportWiresNTT);
				} else {
					if (!supportWiresCodeToFind.getFlVisible().equals(supportWiresNTT.getFlVisible())) {
						unitCodesDAO.updateSupportWireCode(tenantId, supportWiresNTT);
					}
				}

				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(SUPPORT_WIRES_TABLE_NAME)
						.field(VINE_UNIT_FIELD_NAME)
						.value(UNIT_TYPE + ":" + supportWiresNTT.getCode())
						.translations(message.getDescription())
						.build();

				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of support wire code {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}

	private void insertOrUpdateTerracingCode(List<UnitTerracingMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				TerracingNTT terracingNTT = TerracingNTT.builder()
						.typeCode(UNIT_TYPE)
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				TerracingNTT terracingCodeToFind = unitCodesDAO.findTerracingCode(tenantId, UNIT_TYPE, terracingNTT.getCode());
				if (terracingCodeToFind == null) {
					unitCodesDAO.insertTerracingCode(tenantId, terracingNTT);
				} else {
					if (!terracingCodeToFind.getFlVisible().equals(terracingNTT.getFlVisible())) {
						unitCodesDAO.updateTerracingCode(tenantId, terracingNTT);
					}
				}

				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(TERRACING_TABLE_NAME)
						.field(VINE_UNIT_FIELD_NAME)
						.value(UNIT_TYPE + ":" + terracingNTT.getCode())
						.translations(message.getDescription())
						.build();

				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of terracing code {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}

	private void insertOrUpdateVariationType(List<UnitVariationTypeMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				VariationTypeNTT type = VariationTypeNTT.builder()
						.typeCode(UNIT_TYPE)
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				VariationTypeNTT variationTypeToFind = unitCodesDAO.findVariationType(tenantId, UNIT_TYPE, type.getCode());
				if (variationTypeToFind == null) {
					unitCodesDAO.insertVariationType(tenantId, type);
				} else {
					if (!variationTypeToFind.getFlVisible().equals(type.getFlVisible())) {
						unitCodesDAO.updateVariationType(tenantId, type);
					}
				}

				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(VARIATION_TYPE_TABLE_NAME)
						.field(VINE_UNIT_FIELD_NAME)
						.value(UNIT_TYPE + ":" + type.getCode())
						.translations(message.getDescription())
						.build();

				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of variation type code {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}

	private void insertOrUpdateVarietyCode(List<UnitVarietyMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				VarietyNTT varietyNTT = VarietyNTT.builder()
						.typeCode(UNIT_TYPE)
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				VarietyNTT varietyToFind = unitCodesDAO.findVarietyCode(tenantId, UNIT_TYPE, varietyNTT.getCode());
				if (varietyToFind == null) {
					unitCodesDAO.insertVarietyCode(tenantId, varietyNTT);
				} else {
					if (!varietyToFind.getFlVisible().equals(varietyNTT.getFlVisible())) {
						unitCodesDAO.updateVarietyCode(tenantId, varietyNTT);
					}
				}

				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(VARIETY_TABLE_NAME)
						.field(VINE_UNIT_FIELD_NAME)
						.value(UNIT_TYPE + ":" + varietyNTT.getCode())
						.translations(message.getDescription())
						.build();

				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of variety code {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}

	private void insertOrUpdateVineDoigtCode(List<UnitVineDoigtMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				VineDoIgtNTT vineDoigtNTT = VineDoIgtNTT.builder()
						.code(message.getCode())
						.categoryCode(message.getCategory_code())
						.nameCode(message.getName_code())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				VineDoIgtNTT toFind = unitCodesDAO.findVineDoigtByCode(tenantId, vineDoigtNTT.getCode());
				if (toFind == null) {
					vineDoigtNTT.setId(unitCodesDAO.nextVineDoigtIdVal());
					unitCodesDAO.insertVineDoigt(tenantId, vineDoigtNTT);
				} else {
					if (!toFind.getFlVisible().equals(vineDoigtNTT.getFlVisible())
							|| !toFind.getCategoryCode().equals(vineDoigtNTT.getCategoryCode())
							|| !toFind.getNameCode().equals(vineDoigtNTT.getNameCode())) {

						vineDoigtNTT.setId(toFind.getId());
						unitCodesDAO.updateVineDoigt(tenantId, vineDoigtNTT);
					}
				}

				// insert or update code description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(VINE_DOIGT_TABLE_NAME)
						.field(VINE_UNIT_FIELD_NAME)
						.value(vineDoigtNTT.getCode())
						.translations(message.getCode_description())
						.build();
				insertOrUpdateI18nMessages(tenantId, i18nMessage);

				// insert or update category_code description
				i18nMessage = I18nMessage.builder()
						.table(VINE_DOIGT_TABLE_NAME)
						.field("category_code")
						.value(vineDoigtNTT.getCategoryCode())
						.translations(message.getCategory_code_description())
						.build();
				insertOrUpdateI18nMessages(tenantId, i18nMessage);

				// insert or update name description
				i18nMessage = I18nMessage.builder()
						.table(VINE_DOIGT_TABLE_NAME)
						.field("name_code")
						.value(vineDoigtNTT.getNameCode())
						.translations(message.getName_code_description())
						.build();
				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of vine doigt code {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}

	private void insertOrUpdateVineyardCode(List<UnitVineyardMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				VineyardNTT vineyardNTT = VineyardNTT.builder()
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				VineyardNTT toFind = unitCodesDAO.findVineyardByCode(tenantId, vineyardNTT.getCode());
				if (toFind == null) {
					vineyardNTT.setId(unitCodesDAO.nextVineyardIdVal());
					unitCodesDAO.insertVineyard(tenantId, vineyardNTT);
				} else {
					if (!toFind.getFlVisible().equals(vineyardNTT.getFlVisible())) {
						vineyardNTT.setId(toFind.getId());
						unitCodesDAO.updateVineyardByCode(tenantId, vineyardNTT);
					}
				}

				// insert or update code description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(VINEYARD_TABLE_NAME)
						.field(VINE_UNIT_FIELD_NAME)
						.value(vineyardNTT.getCode())
						.translations(message.getDescription())
						.build();
				insertOrUpdateI18nMessages(tenantId, i18nMessage);
				
			} catch (Exception e) {
				log.error("Error during insert/update operation of vineyard code {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}
}
