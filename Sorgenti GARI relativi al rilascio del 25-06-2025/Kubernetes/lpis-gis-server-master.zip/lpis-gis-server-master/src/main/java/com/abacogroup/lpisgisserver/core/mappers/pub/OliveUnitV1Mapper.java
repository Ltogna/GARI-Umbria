package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.resources.res.pub.units.olive.OliveUnitV1;
import com.abacogroup.lpisgisserver.resources.res.pub.units.olive.OliveUnitWithParcelDetailsV1;
import com.abacogroup.lpisgisserver.resources.res.units.olive.OliveUnit;
import com.abacogroup.lpisgisserver.resources.res.units.olive.OliveUnitWithParcelDetails;

@Mapper(uses = {AbsoluteDateMapper.class, VineAptitudesV1Mapper.class} )
public interface OliveUnitV1Mapper {

	OliveUnitV1Mapper INSTANCE = Mappers.getMapper(OliveUnitV1Mapper.class);
	
	@Mapping(target = "anomalies", ignore = true)
	OliveUnitV1 toResponseV1(OliveUnit entity);
	
	OliveUnitWithParcelDetailsV1 toResponseV1(OliveUnitWithParcelDetails entity);

}
