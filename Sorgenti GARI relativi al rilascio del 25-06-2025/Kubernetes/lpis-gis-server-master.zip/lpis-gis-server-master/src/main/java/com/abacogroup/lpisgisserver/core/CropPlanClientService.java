package com.abacogroup.lpisgisserver.core;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.abacogroup.cropplan.sdk.model.domain.SnapElements;
import com.abacogroup.cropplan.sdk.model.layers.GISInfo;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.exceptions.cropplan.GenericCropPlanException;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CropPlanClientService extends BaseService {

	private final Client client;
	private final String cropPlanBaseUrl;
	
	
	private static final String DEFAULT_LANG_CODE = "en";
	private static final String GET_GIS_INFO_URL = "/{tenant}/public/v1/domains/{businessId}/plans/{cropPlanId}/domains/{domainZoneId}/gis-info";
	private static final String GET_SNAP_GEOMETRIES_URL = "/{tenant}/public/v1/domains/{businessId}/plans/{cropPlanId}/domains/{domainZoneId}/snap-geometries";

	public CropPlanClientService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf, 
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, PluginEnvironment pluginEnvironment, 
			Client client, String cropPlanBaseUrl) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.client = client;
		this.cropPlanBaseUrl = cropPlanBaseUrl;
			
	}

	public List<GISInfo> getGisInfo(ServiceSupportEnv env, Map<String, Object> paramMap) {
		
		WebTarget webTarget = client.target(cropPlanBaseUrl + GET_GIS_INFO_URL)
				.resolveTemplate("tenant", env.getTenantId());
		
		// ?pointInTime={pointInTime}&x={x}&y={y}&layerCodes={layerCodes}
		for (Entry<String, Object> p : paramMap.entrySet()) {
			webTarget = webTarget.resolveTemplate(p.getKey(), p.getValue());
			webTarget = webTarget.queryParam(p.getKey(), p.getValue());
		}

		Response response = null;

		try {
//			"/{tenant}/public/v1/domains/{businessId}/plans/{cropPlanId}/domains/{domainZoneId}/gis-info?pointInTime={pointInTime}&x={x}&y={y}&layerCodes={layerCodes}"
				response = webTarget
						.request(MediaType.APPLICATION_JSON_TYPE)
						.accept(MediaType.APPLICATION_JSON_TYPE)
						.header(ACCEPT_LANGUAGE, env.getLang())
						.header(AUTHORIZATION, String.format(JWT_PREFIX, env.getUser().getAuthToken()))
						.get();
			

			if (response.getStatus() == 200) {
				response.bufferEntity();
				return response.readEntity(new GenericType<List<GISInfo>>() {});
			} else {
				Map<String, Object> errorResponse = response.readEntity(new GenericType<HashMap<String, Object>>() {
				});
				String errorCode = (String) errorResponse.get("errorCode");
				GenericCropPlanException ex = new GenericCropPlanException(Status.INTERNAL_SERVER_ERROR,
						env.getOperation(), ErrorField.CROP_PLAN_RESPONSE,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), DEFAULT_LANG_CODE);

				ex.getBody().setMessage(errorCode);
				log.error(ex.getBody().getLogErrorMessage());
				log.error("Crop plan response not valid!!!, {}", errorResponse.toString());
				throw ex;
			}

		} catch (Exception e) {
			GenericCropPlanException ex = new GenericCropPlanException(Status.INTERNAL_SERVER_ERROR,
					env.getOperation(), ErrorField.CROP_PLAN_RESPONSE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());
			log.error(e.getMessage());
			
			throw ex;
			
		}
	}
	
	public SnapElements getSnapGeomteries(ServiceSupportEnv env, Map<String, Object> paramMap) {
		
		WebTarget webTarget = client.target(cropPlanBaseUrl + GET_SNAP_GEOMETRIES_URL)
				.resolveTemplate("tenant", env.getTenantId());
		
		// ?pointInTime={pointInTime}
		for (Entry<String, Object> p : paramMap.entrySet()) {
			webTarget = webTarget.resolveTemplate(p.getKey(), p.getValue());
			webTarget = webTarget.queryParam(p.getKey(), p.getValue());
		}
		
		if(env.getNextKey() != null) {
			webTarget = webTarget.queryParam("nextKey", env.getNextKey());
		}
		
		Response response = null;
		
		try {
//			/{tenant}/public/v1/crop-plans/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/snap-geometries
			response = webTarget
					.request(MediaType.APPLICATION_JSON_TYPE)
					.accept(MediaType.APPLICATION_JSON_TYPE)
					.header(ACCEPT_LANGUAGE, env.getLang())
					.header(AUTHORIZATION, String.format(JWT_PREFIX, env.getUser().getAuthToken()))
					.get();
			
			if (response.getStatus() == 200) {
				response.bufferEntity();
				return response.readEntity(new GenericType<SnapElements>() {});
			} else {
				Map<String, Object> errorResponse = response.readEntity(new GenericType<HashMap<String, Object>>() {
				});
				String errorCode = (String) errorResponse.get("errorCode");
				GenericCropPlanException ex = new GenericCropPlanException(Status.INTERNAL_SERVER_ERROR,
						env.getOperation(), ErrorField.CROP_PLAN_PLOTS_RESPONSE,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), DEFAULT_LANG_CODE);
				
				ex.getBody().setMessage(errorCode);
				log.error(ex.getBody().getLogErrorMessage());
				log.debug("Crop plan response not valid!!!, {}", errorResponse.toString());
				throw ex;
			}
			
		} catch (Exception e) {
			GenericCropPlanException ex = new GenericCropPlanException(Status.INTERNAL_SERVER_ERROR,
					env.getOperation(), ErrorField.CROP_PLAN_PLOTS_RESPONSE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), DEFAULT_LANG_CODE);
			
			log.error(ex.getBody().getLogErrorMessage());
			log.debug(e.getMessage());
			
			throw ex;
			
		}
	}
}
