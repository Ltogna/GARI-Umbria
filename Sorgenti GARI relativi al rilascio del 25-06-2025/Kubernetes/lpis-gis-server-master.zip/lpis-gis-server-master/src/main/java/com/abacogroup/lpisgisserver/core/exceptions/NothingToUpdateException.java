package com.abacogroup.lpisgisserver.core.exceptions;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class NothingToUpdateException extends AbstractException {

	private static final long serialVersionUID = 362076605071813989L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.NOTHING_TO_UPDATE;

	public NothingToUpdateException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new NothingToUpdateExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "No new value to update")
	public static class NothingToUpdateExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 2841504567583105653L;

		public NothingToUpdateExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
