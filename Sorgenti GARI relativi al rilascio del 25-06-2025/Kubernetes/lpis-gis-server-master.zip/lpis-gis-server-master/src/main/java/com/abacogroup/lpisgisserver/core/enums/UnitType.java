package com.abacogroup.lpisgisserver.core.enums;

public enum UnitType {
	FRUIT_UNIT(true, true, "FU", "lpis_unit_fruitunit_details"),
	OLIVE_UNIT(true, true, "OU", "lpis_unit_oliveunit_details"),
	VINE_UNIT(true, true, "VU", "lpis_unit_vineunit_details");

	private final boolean mandatory;
	private final boolean fullCoverMandatory;
	private final String acronym;
	private final String deatailTabelName;

	private UnitType(boolean mandatory, boolean fullCoverMandatory, String acronym, String deatailTabelName) {
		this.mandatory = mandatory;
		this.fullCoverMandatory = fullCoverMandatory;
		this.acronym = acronym;
		this.deatailTabelName = deatailTabelName;
	}

	public boolean isMandatory() {
		return mandatory;
	}

	public boolean isFullCoverMandatory() {
		return fullCoverMandatory;
	}

	public String getAcronym() {
		return acronym;
	}
	
	public String getDeatailTabelName() {
		return deatailTabelName;
	}

}
