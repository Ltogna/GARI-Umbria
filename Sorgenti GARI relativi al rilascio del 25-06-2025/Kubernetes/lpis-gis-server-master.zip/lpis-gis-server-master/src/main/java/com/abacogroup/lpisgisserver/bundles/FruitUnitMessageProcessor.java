package com.abacogroup.lpisgisserver.bundles;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.lpisgisserver.bundles.models.I18nMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.FruitUnitMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitFarmingFormMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitIrrigationTypeMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitPlantingTypeMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitProtectionStructureMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitQualitySystemMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.UnitVarietyMessage;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.UnitCodesDAO;
import com.abacogroup.lpisgisserver.db.ntt.units.FarmingFormNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.IrrigationNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.PlantingTypeNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.ProtectionStructureNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.QualitySystemNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.VarietyNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

public class FruitUnitMessageProcessor extends AbstractMessageProcessor {

	protected UnitCodesDAO unitCodesDAO;

	private final ObjectMapper objectMapper;

	private static final String VARIETY_TABLE_NAME = "lpis_unit_variety";
	private static final String PLANTING_TYPE_TABLE_NAME = "lpis_unit_planting_type";
	private static final String FARMING_FORM_TABLE_NAME = "lpis_unit_farming_form";
	private static final String IRRIGATION_TABLE_NAME = "lpis_unit_irrigation";
	private static final String QUALITY_SYSTEM_TABLE_NAME = "lpis_unit_quality_system";
	private static final String PROTECTION_STRUCTURE_TABLE_NAME = "lpis_unit_protection_structure";

	private static final UnitType UNIT_TYPE = UnitType.FRUIT_UNIT;

	private static final String FRUIT_UNIT_FIELD_NAME = "code";

	private static final Logger log = LoggerFactory.getLogger(FruitUnitMessageProcessor.class);

	public FruitUnitMessageProcessor(DAOContainer dc) {
		super(dc);
		this.unitCodesDAO = dc.getUnitCodesDAO();

		objectMapper = new ObjectMapper();
	}

	@Override
	public void onMessage(ConfigDataMessage message) {

		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
				&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> insertOrUpdateFruitUnitMessage(message.getTenantId(), file));
	}

	@Override
	public String getDomainName() {
		return "fruit-units";
	}

	private void insertOrUpdateFruitUnitMessage(String tenantId, File file) {
		try {
			FruitUnitMessage vineUnitMessage = objectMapper.readValue(file, FruitUnitMessage.class);

			if (vineUnitMessage == null) {
				return;
			}

			insertOrUpdateVarietyCode(vineUnitMessage.getVariety_codes(), tenantId);

			insertOrUpdatePlantingType(vineUnitMessage.getPlanting_type_codes(), tenantId);

			insertOrUpdateFarmingForms(vineUnitMessage.getFarming_forms(), tenantId);

			insertOrUpdateIrrigationTypes(vineUnitMessage.getIrrigation_types(), tenantId);

			insertOrUpdateQualitySystemCode(vineUnitMessage.getQuality_system_codes(), tenantId);

			insertOrUpdateProtectionStructureCodes(vineUnitMessage.getProtection_structure_codes(), tenantId);

		} catch (Exception e) {
			log.error("Error processing file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}
	}

	private void insertOrUpdateFarmingForms(List<UnitFarmingFormMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				FarmingFormNTT farmingForm = FarmingFormNTT.builder()
						.typeCode(UNIT_TYPE)
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				FarmingFormNTT farmingFormToFind = unitCodesDAO.findFarmingForm(tenantId, UNIT_TYPE, farmingForm.getCode());
				if (farmingFormToFind == null) {
					unitCodesDAO.insertFarmingForm(tenantId, farmingForm);
				} else {
					if (!farmingFormToFind.getFlVisible().equals(farmingForm.getFlVisible())) {
						unitCodesDAO.updateFarmingForm(tenantId, farmingForm);
					}
				}

				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(FARMING_FORM_TABLE_NAME)
						.field(FRUIT_UNIT_FIELD_NAME)
						.value(UNIT_TYPE + ":" + farmingForm.getCode())
						.translations(message.getDescription())
						.build();

				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of farming form code {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}

	private void insertOrUpdateQualitySystemCode(List<UnitQualitySystemMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				QualitySystemNTT qualitySystem = QualitySystemNTT.builder()
						.typeCode(UNIT_TYPE)
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				QualitySystemNTT qualitySystemToFind = unitCodesDAO.findQualitySystem(tenantId, UNIT_TYPE, qualitySystem.getCode());
				if (qualitySystemToFind == null) {
					unitCodesDAO.insertQualitySystem(tenantId, qualitySystem);
				} else {
					if (!qualitySystemToFind.getFlVisible().equals(qualitySystem.getFlVisible())) {
						unitCodesDAO.updateQualitySystem(tenantId, qualitySystem);
					}
				}

				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(QUALITY_SYSTEM_TABLE_NAME)
						.field(FRUIT_UNIT_FIELD_NAME)
						.value(UNIT_TYPE + ":" + qualitySystem.getCode())
						.translations(message.getDescription())
						.build();

				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of quality system code {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}

	private void insertOrUpdateProtectionStructureCodes(List<UnitProtectionStructureMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				ProtectionStructureNTT protectionStructure = ProtectionStructureNTT.builder()
						.typeCode(UNIT_TYPE)
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				ProtectionStructureNTT protectionStructureToFind = unitCodesDAO.findProtectionStructure(tenantId, UNIT_TYPE, protectionStructure.getCode());
				if (protectionStructureToFind == null) {
					unitCodesDAO.insertProtectionStructure(tenantId, protectionStructure);
				} else {
					if (!protectionStructureToFind.getFlVisible().equals(protectionStructure.getFlVisible())) {
						unitCodesDAO.updateProtectionStructure(tenantId, protectionStructure);
					}
				}

				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(PROTECTION_STRUCTURE_TABLE_NAME)
						.field(FRUIT_UNIT_FIELD_NAME)
						.value(UNIT_TYPE + ":" + protectionStructure.getCode())
						.translations(message.getDescription())
						.build();

				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of protection structure code {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}

	private void insertOrUpdateIrrigationTypes(List<UnitIrrigationTypeMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				IrrigationNTT type = IrrigationNTT.builder()
						.typeCode(UNIT_TYPE)
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				IrrigationNTT irrigationTypeToFind = unitCodesDAO.findIrrigationType(tenantId, UNIT_TYPE, type.getCode());
				if (irrigationTypeToFind == null) {
					unitCodesDAO.insertIrrigationType(tenantId, type);
				} else {
					if (!irrigationTypeToFind.getFlVisible().equals(type.getFlVisible())) {
						unitCodesDAO.updateIrrigationType(tenantId, type);
					}
				}

				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(IRRIGATION_TABLE_NAME)
						.field(FRUIT_UNIT_FIELD_NAME)
						.value(UNIT_TYPE + ":" + type.getCode())
						.translations(message.getDescription())
						.build();

				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of irrigation type {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}

	private void insertOrUpdatePlantingType(List<UnitPlantingTypeMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				PlantingTypeNTT type = PlantingTypeNTT.builder()
						.typeCode(UNIT_TYPE)
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				PlantingTypeNTT plantingTypeToFind = unitCodesDAO.findPlantingType(tenantId, UNIT_TYPE, type.getCode());
				if (plantingTypeToFind == null) {
					unitCodesDAO.insertPlantingType(tenantId, type);
				} else {
					if (!plantingTypeToFind.getFlVisible().equals(type.getFlVisible())) {
						unitCodesDAO.updatePlantingType(tenantId, type);
					}
				}

				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(PLANTING_TYPE_TABLE_NAME)
						.field(FRUIT_UNIT_FIELD_NAME)
						.value(UNIT_TYPE + ":" + type.getCode())
						.translations(message.getDescription())
						.build();

				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of planting type code {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}

	private void insertOrUpdateVarietyCode(List<UnitVarietyMessage> list, String tenantId) {
		if (list == null) {
			return;
		}

		list.forEach(message -> {
			try {
				VarietyNTT varietyNTT = VarietyNTT.builder()
						.typeCode(UNIT_TYPE)
						.code(message.getCode())
						.flVisible(boolToInt(message.getFl_visible()))
						.build();

				VarietyNTT varietyToFind = unitCodesDAO.findVarietyCode(tenantId, UNIT_TYPE, varietyNTT.getCode());
				if (varietyToFind == null) {
					unitCodesDAO.insertVarietyCode(tenantId, varietyNTT);
				} else {
					if (!varietyToFind.getFlVisible().equals(varietyNTT.getFlVisible())) {
						unitCodesDAO.updateVarietyCode(tenantId, varietyNTT);
					}
				}

				// insert or update description
				I18nMessage i18nMessage = I18nMessage.builder()
						.table(VARIETY_TABLE_NAME)
						.field(FRUIT_UNIT_FIELD_NAME)
						.value(UNIT_TYPE + ":" + varietyNTT.getCode())
						.translations(message.getDescription())
						.build();

				insertOrUpdateI18nMessages(tenantId, i18nMessage);

			} catch (Exception e) {
				log.error("Error during insert/update operation of variety code {} with tenant {} : {}", message.getCode(), tenantId, e);
			}
		});
	}
}
