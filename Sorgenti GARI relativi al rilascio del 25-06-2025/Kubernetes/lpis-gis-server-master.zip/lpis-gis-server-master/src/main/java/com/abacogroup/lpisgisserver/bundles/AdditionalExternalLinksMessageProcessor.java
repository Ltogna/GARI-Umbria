package com.abacogroup.lpisgisserver.bundles;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.lpisgisserver.bundles.models.AdditionalExternalLinkListMessage;
import com.abacogroup.lpisgisserver.bundles.models.AdditionalExternalLinkMessage;
import com.abacogroup.lpisgisserver.bundles.models.I18nMessage;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.ntt.AdditionalExternalLinkNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AdditionalExternalLinksMessageProcessor extends AbstractMessageProcessor {

	protected SupportDAO supportDAO;

	private static final String TABLE_NAME = "lpis_additional_external_links";
	private static final String FIELD_NAME = "code:name";
	private static final String FIELD_TITLE = "code:title";

	private final ObjectMapper objectMapper;

	private static final Logger log = LoggerFactory.getLogger(AdditionalExternalLinksMessageProcessor.class);

	public AdditionalExternalLinksMessageProcessor(DAOContainer dc) {
		super(dc);
		this.supportDAO = dc.getSupportDAO();
		objectMapper = new ObjectMapper();
	}

	@Override
	public String getDomainName() {
		return "additional-external-links";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
				&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> insertOrUpdateAdditionalExternalLinkMessage(message.getTenantId(), file));
	}

	private void insertOrUpdateAdditionalExternalLinkMessage(String tenantId, File file) {
		try {
			AdditionalExternalLinkListMessage linkList = objectMapper.readValue(file, AdditionalExternalLinkListMessage.class);

			if (linkList == null || linkList.getAdditional_external_links() == null) {
				return;
			}

			ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).lang("en").build();
			linkList.getAdditional_external_links().stream().forEach(message -> {
				try {
					List<AdditionalExternalLinkNTT> toFind = supportDAO.findAdditionlExternalLinksByModuleViewTypeCodeAndTenant(env, message.getModule(), message.getView(), message.getType(), message.getCode(), 0);

					if(toFind == null || toFind.isEmpty()) {
						AdditionalExternalLinkNTT additionalExternalLinkNTT = AdditionalExternalLinkNTT.builder()
								.id(supportDAO.nextAdditionalExternalLinksSequenceVal())
								.softwareModule(message.getModule())
								.moduleView(message.getView())
								.linkType(message.getType())
								.code(message.getCode())
								.url(message.getUrl())
								.flVisible(boolToInt(message.getFl_visible()))
								.displayOrder(buildDisplayOrder(message))
								.httpVerb(message.getHttp_verb() != null ? message.getHttp_verb().toUpperCase() : "GET")
								.build();

						supportDAO.insertAdditionalExternalLink(tenantId, additionalExternalLinkNTT);
					} else if(checkForNewValues(message, toFind.get(0))) {
						AdditionalExternalLinkNTT additionalExternalLinkNTT = AdditionalExternalLinkNTT.builder()
								.id(toFind.get(0).getId())
								.url(message.getUrl())
								.flVisible(boolToInt(message.getFl_visible()))
								.displayOrder(buildDisplayOrder(message))
								.build();
						supportDAO.updateAdditionalExternalLink(env, additionalExternalLinkNTT);
					}

					// insert or update name description
					I18nMessage i18nMessage = I18nMessage.builder()
							.table(TABLE_NAME)
							.field(FIELD_NAME)
							.value(message.getCode())
							.translations(message.getName_description())
							.build();
					insertOrUpdateI18nMessages(tenantId, i18nMessage);

					// insert or update name description
					i18nMessage = I18nMessage.builder()
							.table(TABLE_NAME)
							.field(FIELD_TITLE)
							.value(message.getCode())
							.translations(message.getTitle_description())
							.build();
					insertOrUpdateI18nMessages(tenantId, i18nMessage);

				} catch (Exception e) {
					log.error("Error during insert/update operation of additional external links '{}' with tenant {} : {}", message, tenantId, e);
				}
			});
		} catch (Exception e) {
			log.error("Error processing file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}
	}

	private int buildDisplayOrder(AdditionalExternalLinkMessage message) {
		return message.getDisplay_order() != null ? message.getDisplay_order() : 0;
	}

	private boolean checkForNewValues(AdditionalExternalLinkMessage message, AdditionalExternalLinkNTT externalLink) {
		return !externalLink.getUrl().equals(message.getUrl()) 
				|| !externalLink.getFlVisible().equals(boolToInt(message.getFl_visible()))
				|| !externalLink.getDisplayOrder().equals(message.getDisplay_order());
	}	
}
