package com.abacogroup.lpisgisserver.core.exceptions.landcover;

import static org.apache.commons.text.StringEscapeUtils.escapeHtml4;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class ForbiddenEditLandCoverException extends AbstractException {

	private static final long serialVersionUID = 2963007837252129697L;

	private static final ErrorCode ERROR_CODE = ErrorCode.LANDCOVER_EDIT_FORBIDDEN;

	public ForbiddenEditLandCoverException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, 
			String lang, String landCoverCode) {
		super(code, new ForbiddenEditLandCoverExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
		
		String msg = String.format(this.getBody().getMessage(), escapeHtml4(landCoverCode));
		this.getBody().setMessage(msg);
	}

	@Schema(description = "Forbidden to edit land cover code")
	public static class ForbiddenEditLandCoverExceptionBody extends AbstractExceptionBody {
	
		private static final long serialVersionUID = 7792961923555251613L;

		public ForbiddenEditLandCoverExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
