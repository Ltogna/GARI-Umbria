package com.abacogroup.lpisgisserver.core;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.abacogroup.lpisgisserver.core.enums.DatePrecision;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.UnitDictionaryTables;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.ErrorItem;
import com.abacogroup.lpisgisserver.core.exceptions.InvalidPayloadException;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.LandCoverNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.ParcelNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.units.LandCoverCodeNotCompatibleException;
import com.abacogroup.lpisgisserver.core.support.CreateOrUpdateUnitPayload;
import com.abacogroup.lpisgisserver.core.support.EditorSupportParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditLandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.EditParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.UnitsDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.pub.bulk.UnitsWithDictionaryCodesPayloadV1;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EditUnitsSupportService extends BaseService {

	private final EditSessionSupportService editSessionSupportService;
	private final UnitsSupportService unitsSupportService;

	private final EditParcelsDAO editParcelsDAO;
	private final EditLandCoversDAO editLandCoversDAO;
	private final UnitsDAO unitsDAO;
	
	public EditUnitsSupportService(DAOContainer dc, InternalConfigService internalConf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, EditSessionSupportService editSessionSupportService, 
			UnitsSupportService unitsSupportService, PluginEnvironment pluginEnvironment) {
		super(dc, internalConf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.editSessionSupportService = editSessionSupportService;
		this.unitsSupportService = unitsSupportService;

		this.editLandCoversDAO = dc.getEditLandCoversDAO();
		this.editParcelsDAO = dc.getEditParcelsDAO();
		this.unitsDAO = dc.getUnitsDAO();
	}

	public void checkLandCoverCodeCompatibility(ServiceSupportEnv env, Long parcelId, Long landCoverId, UnitType unitType, Operation operation) {

		LandCoverNTT landCoverNTT = editLandCoversDAO.findInEditBySessionId(env, parcelId).stream()
				.filter(lc -> lc.getLand_cover_id().equals(landCoverId))
				.findFirst()
				.orElse(null);
		if(landCoverNTT == null) {
			landCoverNTT = editLandCoversDAO.findNotInEditBySessionId(env, parcelId).stream()
					.filter(lc -> lc.getLand_cover_id().equals(landCoverId))
					.findFirst()
					.orElse(null);	
		}

		if(landCoverNTT == null) {
			LandCoverNotFoundException ex = new LandCoverNotFoundException(Status.NOT_FOUND, operation, ErrorField.LANDCOVER_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
			
			log.error(ex.getBody().getLogErrorMessage());
			
			throw ex;
		}

		if(unitsDAO.checkLandCoverCompatibility(env, landCoverNTT.getLand_cover_code(), unitType) != 1) {
			LandCoverCodeNotCompatibleException ex = new LandCoverCodeNotCompatibleException(Status.BAD_REQUEST, operation, ErrorField.LANDCOVER_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}

	public <T extends CreateOrUpdateUnitPayload> void searchUnitsCodeOrPutError(ServiceSupportEnv env, T payload, List<ErrorItem> errorList, 
			UnitDictionaryTables dictionaryTable, UnitType unitType, ErrorField errorField, ErrorCode errorCode) {

		UnitsWithDictionaryCodesPayloadV1 dictionaryCodes = payload.toUnitsWithDictionaryCodesPayloadV1();

		String code = dictionaryTable.getCodeValue(dictionaryCodes);

		if((code == null && payload.getMandatoryDictionayTable().contains(dictionaryTable)) ||
				!Objects.equals(unitsSupportService.getVineUnitCodeIfExist(env, dictionaryCodes, dictionaryTable, unitType), code)) {
			errorList.add(ErrorItem.builder()
					.errorCode(errorCode)
					.message(getErrorDescription(env, errorCode, code))
					.errorField(errorField)
					.build());
		}

	}
	
	public String getErrorDescription(ServiceSupportEnv env, ErrorCode errorCode, String code) {
		Map<String, Map<String, String>> errorDescriptions = this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId());
		return (errorDescriptions.containsKey(errorCode.toString()) && errorDescriptions.get(errorCode.toString()).containsKey(env.getLang())
				? errorDescriptions.get(errorCode.toString()).get(env.getLang())
						: errorCode.getDescription()
				) + (code != null ? " ("+code+")" : "");
	}
	
	public void checkValueRangeValidity(ServiceSupportEnv env, Operation operation, ErrorField errorField, 
			Double value, Double minValue, Double maxValue, boolean canBeNull, List<ErrorItem> errors) {
		if (!canBeNull && value == null) {
			InvalidPayloadException ex = new InvalidPayloadException(Status.BAD_REQUEST, operation,
					errorField, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		if(value == null) {
			return;
		}
		
		ErrorCode errorCode = ErrorCode.VALUE_OUT_OF_RANGE;
		String minValueMsg = "";
		String maxValueMsg = "";
		boolean outOfRange = false;
		
		if(Math.floor(value) != value) {
			outOfRange = true;
		}
		
		if(minValue == null) {
			errorCode = ErrorCode.VALUE_OUT_OF_RANGE_LESS_THAN;
		} else {
			outOfRange = outOfRange || value.compareTo(minValue) < 0;
			minValueMsg = ""+minValue.intValue();
		}
		
		if(maxValue == null) {
			errorCode = ErrorCode.VALUE_OUT_OF_RANGE_GREATER_THAN;
		} else {
			outOfRange = outOfRange || value.compareTo(maxValue) > 0;
			maxValueMsg = ""+maxValue.intValue();
		}
		
		if (!outOfRange) {
			return;
		}
		
		String errorMsg = String.format(getErrorDescription(env, errorCode, null), minValueMsg, maxValueMsg);
		
		errors.add(ErrorItem.builder()
				.errorCode(errorCode)
				.message(errorMsg)
				.errorField(errorField)
				.build());
	}

	public <T extends CreateOrUpdateUnitPayload> LocalDate buildMinPlantingDate(T payload, LandCoverNTT landCoverNTT) {
		LocalDate minPlantingDate = landCoverNTT.getCreation_day().toLocalDate();
	    if (payload.getPlantingDayPrecision().equals(DatePrecision.Y)) {
	    	minPlantingDate = LocalDate.of(minPlantingDate.getYear(), 1, 1);
	    } else if (payload.getPlantingDayPrecision().equals(DatePrecision.YM)) {
	    	minPlantingDate = LocalDate.of(minPlantingDate.getYear(), minPlantingDate.getMonth(), 1);
	    }
		return minPlantingDate;
	}

	public LandCoverNTT setInEditLandCoverById(EditorSupportParams params, Long landCoverId, EditStatus editStatus) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		LandCoverNTT editLandCover = editLandCoversDAO.findInEditBySessionId(env, null).stream()
				.filter(lc -> lc.getLand_cover_id().equals(landCoverId))
				.findFirst()
				.orElse(null);
		if(editLandCover == null) {
			editLandCover = editLandCoversDAO.findNotInEditBySessionId(env, null).stream()
					.filter(lc -> lc.getLand_cover_id().equals(landCoverId))
					.findFirst()
					.orElse(null);	
			if(editLandCover == null) {
				LandCoverNotFoundException ex = new LandCoverNotFoundException(Status.NOT_FOUND, params.getOperation(), ErrorField.LANDCOVER_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
			ParcelNTT inEditParcel = setInEditParcelById(params, editLandCover.getParcel_id(), editStatus);
			editLandCover.setEdit_parcel_id(inEditParcel.getEdit_id());
			editLandCover.setEdit_id(editLandCoversDAO.nextSequenceVal());
			editLandCover.setEdit_status(editStatus);
			editLandCoversDAO.insert(editLandCover, env.getSessionId());
		}

		return editLandCover;
	}
	
	private ParcelNTT setInEditParcelById(EditorSupportParams params, Long parcelId, EditStatus editStatus) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		ParcelNTT editParcel = editParcelsDAO.findInEditBySessionId(env.getSessionId(), env.getReferenceDate(), parcelId).stream()
				.filter(p -> p.getParcel_id().equals(parcelId))
				.findFirst()
				.orElse(null);
		if (editParcel == null) {
			editParcel = editParcelsDAO.findNotInEditBySessionId(env, parcelId).stream()
					.filter(p -> p.getParcel_id().equals(parcelId))
					.findFirst()
					.orElse(null);
			if(editParcel == null) {
				ParcelNotFoundException ex = new ParcelNotFoundException(Status.NOT_FOUND, params.getOperation(), ErrorField.PARCEL_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
			editParcel.setEdit_id(editParcelsDAO.nextSequenceVal());
			editParcel.setEdit_status(editStatus);
			editSessionSupportService.checkAndInsertEditParcel(params, editParcel);
		}

		return editParcel;
	}
	
	public LandCoverNTT getLandCoverNTT(ServiceSupportEnv env, Long parcelId, Long landCoverId, Operation operation) {
		LandCoverNTT landCoverNTT = editLandCoversDAO.findInEditBySessionId(env, parcelId).stream()
				.filter(lc -> lc.getLand_cover_id().equals(landCoverId))
				.findFirst()
				.orElse(null);
	
		if(landCoverNTT == null) {
			LandCoverNotFoundException ex = new LandCoverNotFoundException(Status.NOT_FOUND, operation, ErrorField.LANDCOVER_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
	
			log.error(ex.getBody().getLogErrorMessage());
	
			throw ex;
		}
		return landCoverNTT;
	}
}
