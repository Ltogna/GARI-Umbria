package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.resources.res.Parcel;
import com.abacogroup.lpisgisserver.resources.res.pub.ParcelV1;

@Mapper(uses = {AbsoluteDateMapper.class, LandCoversV1Mapper.class, SectorV1Mapper.class, BlockV1Mapper.class} )
public interface ParcelsV1Mapper {

	ParcelsV1Mapper INSTANCE = Mappers.getMapper(ParcelsV1Mapper.class);

	@InheritInverseConfiguration()
	@Mapping(target = "landcovers_list", ignore = true)
	@Mapping(target = "anomalies", ignore = true)
	ParcelV1 toResponseV1(Parcel entity);
	
	@InheritInverseConfiguration()
	@Mapping(source = "parcel_id", target = "id")
	@Mapping(source = "pkid", target = "details_id")
	@Mapping(target = "landcovers_list", ignore = true)
	@Mapping(target = "anomalies", ignore = true)
	@Mapping(source = "sector.sector", target = "sector.sectorCode")
	@Mapping(source = "sector.short_descr", target = "sector.shortDescr")
	@Mapping(source = "sector.world_geom", target = "sector.worldGeom")
	@Mapping(source = "block.block", target = "block.block_code")
	ParcelV1 entityToDto(ParcelNTT entity);
}
