package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidLockAreaTooSmallException extends AbstractException {

	private static final long serialVersionUID = 2015946319598893468L;

	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_LOCK_AREA_TOO_SMALL;

	public InvalidLockAreaTooSmallException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new InvalidLockAreaTooSmallExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Invalid lock area too small")
	public static class InvalidLockAreaTooSmallExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -1301395276207854184L;

		public InvalidLockAreaTooSmallExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
