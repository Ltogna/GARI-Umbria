package com.abacogroup.lpisgisserver.core.support;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.EditType;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.db.ntt.EditSessionNTT;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.resources.req.ReqContext;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EditorSupportParams {

	private ReqContext reqContext;
	private EditSessionNTT session;

	private Long parcelId;
	private Long landCoverId;
	private Long vineUnitId;
	private Long oliveUnitId;
	private Long fruitUnitId;

	private String landCoverCode;
	
	private Long sector_id;
	private Long block_id;
	private String parcelName;
	private String sde_code;
	private String client_ref;

	private Map<Long, LandCoverNTT> currentLandCoversMap;

	private EditType editType;

	private Operation operation;
}
