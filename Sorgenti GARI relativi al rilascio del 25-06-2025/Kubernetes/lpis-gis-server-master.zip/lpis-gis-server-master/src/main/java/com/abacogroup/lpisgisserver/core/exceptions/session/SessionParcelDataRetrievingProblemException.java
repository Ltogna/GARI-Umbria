package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class SessionParcelDataRetrievingProblemException extends AbstractException {

	private static final long serialVersionUID = -4013860913736552685L;

	private static final ErrorCode ERROR_CODE = ErrorCode.SESSION_PARCEL_DATA_RETRIEVING_PROBLEM;

	public SessionParcelDataRetrievingProblemException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new SessionParcelDataRetrievingProblemExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Session parcel data retrieving problem")
	public static class SessionParcelDataRetrievingProblemExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -6378202123071180696L;

		public SessionParcelDataRetrievingProblemExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
