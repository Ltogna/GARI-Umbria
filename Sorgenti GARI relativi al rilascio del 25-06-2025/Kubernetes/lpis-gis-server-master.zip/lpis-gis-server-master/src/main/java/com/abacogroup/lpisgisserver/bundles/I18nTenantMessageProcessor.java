package com.abacogroup.lpisgisserver.bundles;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.I18nDAO;
import com.abacogroup.lpisgisserver.db.ntt.I18nNTT;

public class I18nTenantMessageProcessor implements TenantMessageProcessor {

	private static final String TEMPLATE_TENANT_ID = "*";

	private I18nDAO i18nDAO;

	private static final Logger log = LoggerFactory.getLogger(I18nTenantMessageProcessor.class);

	public I18nTenantMessageProcessor(DAOContainer dc) {
		this.i18nDAO = dc.getI18nDAO();
	}

	@Override
	public void onMessage(TenantMessage message) {
		String tenantId = message.getTenantId();

		if (tenantId.equals(TEMPLATE_TENANT_ID)) {
			return;
		}

		if (i18nDAO.getAllTenants().contains(tenantId)) {
			return;
		}
		
		List<I18nNTT> generalI18nValues = i18nDAO.findAllI18nByTenantId(TEMPLATE_TENANT_ID);

		if(generalI18nValues != null) {
			generalI18nValues.stream().forEach(row -> {
				try {
					I18nNTT messageNTT = I18nNTT.builder()
							.field_name(row.getField_name())
							.i18n_text(row.getI18n_text())
							.i18n_value(row.getI18n_value())
							.lang(row.getLang())
							.table_name(row.getTable_name())
							.tenant_id(tenantId)
							.build();

					I18nNTT toFind = i18nDAO.findI18nByLpisI18nKeys(messageNTT);

					if (toFind == null) {
						i18nDAO.insert(messageNTT);
					} else if (!toFind.getI18n_text().equals(row.getI18n_text())) {
						i18nDAO.updateI18nText(messageNTT);
					}
				} catch (Exception e) {
					log.error("Error during insert or update i18n message " + row.toString() + " for tenant " + tenantId, e);
				}
			});
		}

	}
}
