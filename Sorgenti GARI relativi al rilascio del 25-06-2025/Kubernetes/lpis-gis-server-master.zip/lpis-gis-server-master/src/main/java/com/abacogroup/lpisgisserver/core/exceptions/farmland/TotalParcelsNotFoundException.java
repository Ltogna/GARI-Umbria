package com.abacogroup.lpisgisserver.core.exceptions.farmland;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class TotalParcelsNotFoundException extends AbstractException {

	private static final long serialVersionUID = -3051244791512088031L;

	private static final ErrorCode ERROR_CODE = ErrorCode.TOTAL_PARCELS_NOT_FOUND;

	public TotalParcelsNotFoundException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new TotalParcelsNotFoundExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Total parcels not found")
	public static class TotalParcelsNotFoundExceptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = -1163562342609595882L;

		public TotalParcelsNotFoundExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
