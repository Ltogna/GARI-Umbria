package com.abacogroup.lpisgisserver.core.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApiVersion {
	private String name;
	private String description;
	private String version;
	private String buildtime;
	private String commitId;
}
