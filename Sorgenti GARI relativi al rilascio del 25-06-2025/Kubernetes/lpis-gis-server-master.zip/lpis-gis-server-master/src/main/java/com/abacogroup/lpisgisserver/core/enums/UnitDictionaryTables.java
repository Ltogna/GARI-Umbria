package com.abacogroup.lpisgisserver.core.enums;

import com.abacogroup.lpisgisserver.core.support.UnitWithDictionary;

public enum UnitDictionaryTables {
	
	/* Vine Units */
	CULTIVATION_STATUS("lpis_unit_cultivation_status") {
		@Override
		public String getCodeValue(UnitWithDictionary p) {
			return p.getCultivationStatusCode();
		}
	},
	FARMING_FORM("lpis_unit_farming_form"){
		@Override
		public String getCodeValue(UnitWithDictionary p) {
			return p.getFarmingFormCode();
		}
	},
	IRRIGATION("lpis_unit_irrigation"){
		@Override
		public String getCodeValue(UnitWithDictionary p) {
			return p.getIrrigationCode();
		}
	},
	HEADER_ANCHORING("lpis_unit_header_anchoring"){
		@Override
		public String getCodeValue(UnitWithDictionary p) {
			return p.getHeaderAnchoringCode();
		}
	},
	POLES_HEADER("lpis_unit_poles_header"){
		@Override
		public String getCodeValue(UnitWithDictionary p) {
			return p.getPolesHeaderCode();
		}
	},
	POLES_WEAVING("lpis_unit_poles_weaving"){
		@Override
		public String getCodeValue(UnitWithDictionary p) {
			return p.getPolesWeavingCode();
		}
	},
	PRODUCT_DESTINATION("lpis_unit_product_destination"){
		@Override
		public String getCodeValue(UnitWithDictionary p) {
			return p.getProductDestinationCode();
		}
	},
	SUPPORT_WIRES("lpis_unit_support_wires"){
		@Override
		public String getCodeValue(UnitWithDictionary p) {
			return p.getSupportWiresCode();
		}
	},
	TERRACING("lpis_unit_terracing"){
		@Override
		public String getCodeValue(UnitWithDictionary p) {
			return p.getTerracingCode();
		}
	},
	VARIATION_TYPE("lpis_unit_variation_type"){
		@Override
		public String getCodeValue(UnitWithDictionary p) {
			return p.getVariationTypeCode();
		}
	},
	VARIETY("lpis_unit_variety"){
		@Override
		public String getCodeValue(UnitWithDictionary p) {
			return p.getVarietyCode();
		}
	},
	PLANTING_TYPE("lpis_unit_planting_type"){
		@Override
		public String getCodeValue(UnitWithDictionary p) {
			return p.getPlantingTypeCode();
		}
	},
	QUALITY_SYSTEM("lpis_unit_quality_system"){
		@Override
		public String getCodeValue(UnitWithDictionary p) {
			return p.getQualitySystemCode();
		}
	},
	PROTECTION_STRUCTURE("lpis_unit_protection_structure"){
		@Override
		public String getCodeValue(UnitWithDictionary p) {
			return p.getProtectionStructureCode();
		}
	};
	
	private final String tableName;
	
	private UnitDictionaryTables(String tableName) {
		this.tableName = tableName;
	}
	
	public String getTableName() {
		return tableName;
	}
	
	public abstract String getCodeValue(UnitWithDictionary p); 
}
