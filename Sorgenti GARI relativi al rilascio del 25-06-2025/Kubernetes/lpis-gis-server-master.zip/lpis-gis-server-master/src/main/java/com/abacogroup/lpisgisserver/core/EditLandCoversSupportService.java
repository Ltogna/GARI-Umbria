package com.abacogroup.lpisgisserver.core;

import static java.util.stream.Collectors.toList;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Polygon;

import com.abacogroup.geometryeditor.Editor;
import com.abacogroup.geometryeditor.EditorResult;
import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.CutBehaviour;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.InvalidLandCoverEditIdException;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.LandCoverNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.LandCoverWithUnitsException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidEditSessionException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionLandCoverIdException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionParcelIdException;
import com.abacogroup.lpisgisserver.core.support.EditorSupportFactory;
import com.abacogroup.lpisgisserver.core.support.EditorSupportParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditLandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.EditParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.I18nDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.ntt.EditSessionNTT;
import com.abacogroup.lpisgisserver.db.ntt.I18nNTT;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.fruit.FruitUnitDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.OliveUnitDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineUnitDetailsNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.LandCoverWithUnits;
import com.abacogroup.lpisgisserver.resources.res.LandCoversCode;
import com.abacogroup.lpisgisserver.resources.res.LandCoversEditResult;
import com.abacogroup.lpisgisserver.resources.res.LayerStyle;
import com.abacogroup.lpisgisserver.resources.res.units.fruit.FruitUnit;
import com.abacogroup.lpisgisserver.resources.res.units.olive.OliveUnit;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnitWithAptitudes;
import com.google.common.collect.Iterators;
import com.google.common.collect.UnmodifiableIterator;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EditLandCoversSupportService extends BaseService {

	private final EditSessionSupportService editSessionSupportService;
	private final EditVineUnitsSupportService editVineUnitsSupportService;
	private final EditOliveUnitsSupportService editOliveUnitsSupportService;
	private final EditFruitUnitsSupportService editFruitUnitsSupportService;

	private final EditLandCoversDAO editLandCoversDAO;
	private final LandCoversDAO landCoverDAO;
	private final EditParcelsDAO editParcelsDAO;
	private final SupportDAO supportDAO;
	private final I18nDAO i18nDAO;

	private static final String LAND_COVER_TABLE_NAME = "lpis_landcovers";
	private static final String LAND_COVER_CODE_FIELD_NAME = "code";

	public EditLandCoversSupportService(DAOContainer dc, InternalConfigService internalConf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, EditSessionSupportService editSessionSupportService, 
			EditVineUnitsSupportService editVineUnitsSupportService, EditOliveUnitsSupportService editOliveUnitsSupportService, 
			EditFruitUnitsSupportService editFruitUnitsSupportService, PluginEnvironment pluginEnvironment) {
		super(dc, internalConf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.editSessionSupportService = editSessionSupportService;
		this.editVineUnitsSupportService = editVineUnitsSupportService;
		this.editOliveUnitsSupportService = editOliveUnitsSupportService;
		this.editFruitUnitsSupportService = editFruitUnitsSupportService;

		this.editLandCoversDAO = dc.getEditLandCoversDAO();
		this.landCoverDAO = dc.getLandCoversDAO();
		this.editParcelsDAO = dc.getEditParcelsDAO();
		this.supportDAO = dc.getSupportDAO();
		this.i18nDAO = dc.getI18nDAO();
	}
	
	public void checkCanEditLC(EditorSupportParams params, List<Long> landCoverIds) {
		checkCanEditLC(params, landCoverIds, Boolean.FALSE);
	}

	public void checkCanEditLC(EditorSupportParams params, List<Long> landCoverIds, boolean skipForbiddenCheck) {

		editSessionSupportService.checkEditableSession(params, Operation.CHECK_CAN_EDIT_LANDCOVER);

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		// check if parcel exist
		checkParcelExist(env, params);

		Long paramParcelId = params.getParcelId();
		editSessionSupportService.checkScopes(env, Arrays.asList(params.getParcelId()), null);

		// check land cover id
		Long paramLandCoverId = params.getLandCoverId();

		if (paramLandCoverId != null) {
			List<Long> idsToParse = Arrays.asList(paramLandCoverId);
			if (landCoverIds != null) {

				if (!landCoverIds.contains(paramLandCoverId)) {
					InvalidLandCoverEditIdException ex = new InvalidLandCoverEditIdException(Status.BAD_REQUEST, params.getOperation(), ErrorField.LANDCOVER_ID,
							this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

					log.error(ex.getBody().getLogErrorMessage());

					throw ex;
				}

				idsToParse = landCoverIds.stream().distinct().collect(toList());
			}

			checkParcelIdOnLandCoverIds(paramParcelId, idsToParse, env, params.getOperation(), skipForbiddenCheck);

		} else if (landCoverIds != null) {
			checkParcelIdOnLandCoverIds(paramParcelId, landCoverIds, env, params.getOperation(), skipForbiddenCheck);
		}

	}

	private void checkParcelIdOnLandCoverIds(Long parcelId, List<Long> landCoverIds, ServiceSupportEnv env, Operation operation, Boolean skipForbiddenCheck) {
		if(landCoverIds == null) {
			landCoverIds = new ArrayList<>(); 
		}

		List<LandCoverNTT> editLandCovers = !landCoverIds.isEmpty()
				? editLandCoversDAO.getEditLandCoversFromLandCoverIdsBySession(env, landCoverIds)
						: new ArrayList<>();

		List<Long> landCoversIdsNotInEdit = new ArrayList<>();
		List<LandCoverNTT> landCoversNotInEdit = null;

		// check parcel id on land cover
		if (!editLandCovers.isEmpty()) {
			for (LandCoverNTT landCover : editLandCovers) {
				if (!landCover.getParcel_id().equals(parcelId)) {
					InvalidSessionLandCoverIdException ex = new InvalidSessionLandCoverIdException(Status.BAD_REQUEST,
							operation, ErrorField.LANDCOVER_ID,
							this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

					log.error(ex.getBody().getLogErrorMessage());

					throw ex;
				}
				
				if (!skipForbiddenCheck) {
					checkForbiddenEditLcCode(env, landCover);
				}

				// add id to recover from land cover details
				Long id = landCover.getLand_cover_id();
				if (!landCoverIds.contains(id)) {
					landCoversIdsNotInEdit.add(id);
				}
			}

		} else {
			landCoversIdsNotInEdit.addAll(landCoverIds);
		}

		// recover land covers from details
		if (!landCoversIdsNotInEdit.isEmpty()) {
			landCoversNotInEdit = editLandCoversDAO.getLandCoversFromLandCoverIdsAndParcelIdBySession(
					env,
					landCoversIdsNotInEdit,
					parcelId);
			if (landCoversNotInEdit.size() != landCoversIdsNotInEdit.size()) {
				InvalidSessionLandCoverIdException ex = new InvalidSessionLandCoverIdException(Status.BAD_REQUEST,
						operation, ErrorField.LANDCOVER_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}

			if (!skipForbiddenCheck) {
				landCoversNotInEdit.forEach(landCover -> checkForbiddenEditLcCode(env, landCover));
			}
		}
	}

	public void checkParcelExist(ServiceSupportEnv env, EditorSupportParams params) {
		if (params.getParcelId() == null) {
			InvalidSessionParcelIdException ex = new InvalidSessionParcelIdException(Status.BAD_REQUEST,
					params.getOperation(), ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		List<ParcelNTT> editParcels = editParcelsDAO.findInEditBySessionId(env.getSessionId(), env.getReferenceDate(), params.getParcelId());
		List<ParcelNTT> notEditParcels = editParcelsDAO.findNotInEditBySessionId(env, params.getParcelId());
		if ((editParcels == null || editParcels.isEmpty()) && (notEditParcels == null || notEditParcels.isEmpty())) {
			InvalidSessionParcelIdException ex = new InvalidSessionParcelIdException(Status.BAD_REQUEST,
					params.getOperation(), ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}

	public String getLandCoverDescription(String landCoverCode, EditorSupportParams params) {

		String description = null;
		if (StringUtils.isNotBlank(landCoverCode)) {
			I18nNTT entity = I18nNTT.builder()
					.table_name(LAND_COVER_TABLE_NAME)
					.field_name(LAND_COVER_CODE_FIELD_NAME)
					.i18n_value(landCoverCode)
					.lang(params.getReqContext().getLang())
					.tenant_id(params.getReqContext().getTenantId())
					.build();

			description = i18nDAO.findI18nText(entity);
		}

		return description;
	}

	public List<LandCoverNTT> internalGetEditLandCovers(EditorSupportParams params) {

		String tenantId = params.getReqContext().getTenantId();

		Boolean flHideLandCovers = internalConf.getBooleanValue(tenantId, InternalConfigKeys.FL_HIDE_LANDCOVERS_LAYER.getKey());
		if (Boolean.TRUE.equals(flHideLandCovers)) {
			return new ArrayList<>();
		}
		
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		env.setLandCoverStyleMatrixCode(this.internalConf.getStringValue(tenantId, InternalConfigKeys.DEFAULT_LANDCOVERS_STYLE_MATRIX_CODE_KEY.getKey()));
		env.setDefaultLCFillRGBA(this.internalConf.getStringValue(tenantId, InternalConfigKeys.DEFAULT_LANDCOVERS_FILL_RGBA_KEY.getKey()));
		env.setDefaultLCLineRGBA(this.internalConf.getStringValue(tenantId, InternalConfigKeys.DEFAULT_LANDCOVERS_LINE_RGBA_KEY.getKey()));
		env.setDefaultLCLineThick(this.internalConf.getIntegerValue(tenantId, InternalConfigKeys.DEFAULT_LANDCOVERS_LINE_THICK_KEY.getKey()));

		List<LandCoverNTT> editLandCovers = new ArrayList<>();

		List<LandCoverNTT> inEditLandcovers = editLandCoversDAO.findInEditBySessionId(env, params.getParcelId())
				.stream()
				.filter(l -> l.getGeom() != null)
				.collect(toList());

		if (inEditLandcovers != null)
			editLandCovers.addAll(inEditLandcovers);

		List<LandCoverNTT> notInEditLandCovers = editLandCoversDAO.findNotInEditBySessionId(env, params.getParcelId());
		if (notInEditLandCovers != null)
			editLandCovers.addAll(notInEditLandCovers);

		return editLandCovers;
	}
	
	public void addUnitsToLandCoverEditResult(EditorSupportParams params, LandCoversEditResult landCoversEditResult) {
		landCoversEditResult.getAdded().stream().forEach(lc -> addUnitsToLandCover(params, lc));
		landCoversEditResult.getUpdated().stream().forEach(lc -> {
			lc.setUnit_types(supportDAO.getCompatibleUnitTypesByLandCoverCode(params.getReqContext().getTenantId(), lc.getCode()));
			addUnitsToLandCover(params, lc);
		});
	}

	public void addUnitsToLandCover(EditorSupportParams params, LandCoverWithUnits landCover) {
		if(landCover.getUnit_types() == null || landCover.getUnit_types().isEmpty()) {
			landCover.setUnit_types(supportDAO.getCompatibleUnitTypesByLandCoverCode(params.getReqContext().getTenantId(), landCover.getCode()));
		}
		
		List<VineUnitWithAptitudes> vineUnits = editVineUnitsSupportService.internalGetVineUnits(params, landCover.getId(), null);
		vineUnits.stream().forEach(u -> u.setVineAptitudes(editVineUnitsSupportService.internalGetVineAptitudes(params, u.getId(), null, false)));
		landCover.setVine_units(vineUnits);
		
		List<OliveUnit> oliveUnits = editOliveUnitsSupportService.internalGetOliveUnits(params, landCover.getId(), null);
		landCover.setOlive_units(oliveUnits);
		
		List<FruitUnit> fruitUnits = editFruitUnitsSupportService.internalGetFruitUnits(params, landCover.getId(), null);
		landCover.setFruit_units(fruitUnits);
	}
	
	public Map<Long, Polygon> findLandCoversPolygonsByParcels(EditorSupportParams params, List<Long> parcelIds) {
		return findLandCoversPolygonsByParcels(params, parcelIds, false);
	}

	public Map<Long, Polygon> findLandCoversPolygonsByParcels(EditorSupportParams params, List<Long> parcelIds, boolean skipForbiddenLcCheck) {

		Map<Long, Polygon> landCoversPolygons = new HashMap<>();
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		List<LandCoverNTT> landCoversParcels = findLandCoversByParcels(params, parcelIds);
		landCoversParcels
		.forEach(l -> {
			if(!skipForbiddenLcCheck) {
				checkForbiddenEditLcCode(env, l);
			}
			landCoversPolygons.put(l.getLand_cover_id(), (Polygon) l.getGeom());
		});

		return landCoversPolygons;
	}
	
	public List<LandCoverNTT> findLandCoversByParcels(EditorSupportParams params, List<Long> parcelIds){
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		List<LandCoverNTT> landCoversParcels = new ArrayList<>();
		for (Long parcelId : parcelIds) {
			List<LandCoverNTT> inEditLandCovers = editLandCoversDAO.findInEditBySessionId(env, parcelId);
			if (inEditLandCovers != null)
				landCoversParcels.addAll(inEditLandCovers);

			List<LandCoverNTT> notInEditLandCovers = editLandCoversDAO.findNotInEditBySessionId(env, parcelId);
			if (notInEditLandCovers != null)
				landCoversParcels.addAll(notInEditLandCovers);
		}
		
		return landCoversParcels;

	}

	public Editor<Long> getEditor(EditorSupportParams params, CutBehaviour cutBehaviour, EditorResult<Long> parcelEditorResult, Map<Long, Polygon> cutPolygons,
			boolean isForPreview, EditorSupportFactory<Long> editorSupportFactory) {

		if (params.getSession() == null) {
			String tenantId = params.getReqContext() != null ? params.getReqContext().getTenantId() : StringUtils.EMPTY;
			String lang = params.getReqContext() != null ? params.getReqContext().getLang() : ErrorDescriptionsService.DEFAULT_LANG_CODE;

			InvalidEditSessionException ex = new InvalidEditSessionException(Status.BAD_REQUEST, params.getOperation(), ErrorField.SESSION,
					this.errorDescriptionsService.getTenantErrorDescriptions(tenantId), lang);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Long nextNewLandCoverId = editLandCoversDAO.nextNewLandCoverIdVal();

		Editor<Long> editor = new Editor<>(
				editorSupportFactory.createEditorSupport(params, cutBehaviour, parcelEditorResult, cutPolygons, isForPreview, nextNewLandCoverId));

		// Resolve overlaps between geometries to avoid errors for dirty geometries 
		editor.setResolveOverlaps(true);
				
		// Fix some issue in reduce geometry linked to very small geometries, avoiding area check after reduction
		editor.setTolerateAreaReduction(true);

		return editor;
	}

	public Map<Long, LandCoverNTT> getCurrentLandCoversMap(ServiceSupportEnv env, Long parcelId) {

		Map<Long, LandCoverNTT> currentLandCoversMap = new HashMap<>();
		editLandCoversDAO.findInEditBySessionId(env, parcelId)
		.stream()
		.forEach(l -> currentLandCoversMap.put(l.getLand_cover_id(), l));
		editLandCoversDAO.findNotInEditBySessionId(env, parcelId)
		.stream()
		.forEach(l -> currentLandCoversMap.put(l.getLand_cover_id(), l));

		return currentLandCoversMap;
	}

	public LandCoversCode retrieveLandCoversCode(EditorSupportParams params, ServiceSupportEnv env, Long parentPid) {

		String landCoverCode = this.internalConf.getStringValue(params.getReqContext().getTenantId(),
				InternalConfigKeys.DEFAULT_LAND_COVER_CODE_KEY.getKey());
		String description = null;

		List<LandCoverNTT> editLandCovers = editLandCoversDAO.getEditLandCoversFromLandCoverIdsBySession(env,
				Arrays.asList(parentPid != null ? parentPid : 0));
		if (editLandCovers.isEmpty()) {
			LandCoverNTT parentLandCoverDetail = landCoverDAO.getLandCoverDetail(env, parentPid);
			if (parentLandCoverDetail != null) {
				landCoverCode = parentLandCoverDetail.getLand_cover_code();
				description = parentLandCoverDetail.getLand_cover_description();
			}
		} else {
			if (editLandCovers.size() > 1) {
				InvalidSessionLandCoverIdException ex = new InvalidSessionLandCoverIdException(Status.BAD_REQUEST,
						params.getOperation(), ErrorField.LANDCOVER_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}

			landCoverCode = editLandCovers.get(0).getLand_cover_code();
			description = editLandCovers.get(0).getLand_cover_description();
		}

		return LandCoversCode.builder().description(description).land_cover_code(landCoverCode).build();
	}

	public Map<Long, Polygon> loadLandCoverPolygons(EditSessionNTT session, List<Long> editLandCoverIds) {
		Map<Long, Polygon> map = new HashMap<>();
		UnmodifiableIterator<List<Long>> partitions = Iterators.partition(editLandCoverIds.iterator(), 1000);

		partitions.forEachRemaining(partition -> {
			List<LandCoverNTT> inEditPolygons = editLandCoversDAO.getInEditingPolygons(partition);
			inEditPolygons.forEach(p -> map.put(p.getLand_cover_id(), (Polygon) p.getGeom()));

			List<LandCoverNTT> notInEditPolygons = editLandCoversDAO.getNotInEditingPolygons(session.getReference_date(), partition);
			notInEditPolygons.forEach(p -> map.put(p.getLand_cover_id(), (Polygon) p.getGeom()));
		});

		return map;
	}
	
	public Map<Long, Polygon> loadParcelPolygons(EditorSupportParams params, List<Long> parcelIds) {

		EditSessionNTT session = params.getSession();

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(params.getReqContext().getUser())
				.lang(ErrorDescriptionsService.DEFAULT_LANG_CODE)
				.tenantId(session.getTenant_id())
				.sessionId(session.getUuid())
				.srs(session.getLock_geom_srs())
				.referenceDate(session.getReference_date())
				.build();

		Map<Long, Polygon> map = new HashMap<>();
		UnmodifiableIterator<List<Long>> partitions = Iterators.partition(parcelIds.iterator(), 1000);
		partitions.forEachRemaining(partition -> {
			checkForbiddenEditLcCodeByParcelIds(env, partition);
			
			List<ParcelNTT> inEditPolygons = editParcelsDAO.getInEditingPolygons(partition);
			inEditPolygons.forEach(p -> map.put(p.getParcel_id(), (Polygon) p.getGeom()));

			List<ParcelNTT> notInEditPolygons = editParcelsDAO.getNotInEditingPolygons(env, partition);
			notInEditPolygons.forEach(p -> map.put(p.getParcel_id(), (Polygon) p.getGeom()));
		});
		return map;

	}

	public EditorResult<Long> createParcelEditorResultWithParamsParcelId(EditorSupportParams params) {
		EditorResult<Long> result = new EditorResult<>();

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		List<ParcelNTT> parcel = editParcelsDAO.findInEditBySessionId(params.getSession().getUuid(), params.getSession().getReference_date(),
				params.getParcelId());
		if (parcel.isEmpty()) {
			parcel = editParcelsDAO.findNotInEditBySessionId(env, params.getParcelId());
		}
		
		// If parcel is eventually not found, or is something like null or, more likely, is deleted then return
		if (parcel.isEmpty() || parcel.get(0) == null || parcel.get(0).getGeom() == null) {
			return result;
		}

		result.getModified().put(parcel.get(0).getParcel_id(), (Polygon) parcel.get(0).getGeom());

		return result;
	}

	public List<LandCoverNTT> getLandCoversWithInteractionWithSameCode(ServiceSupportEnv env, LandCoverNTT landCoverToMerge, Long parcelId) {
		List<LandCoverNTT> landCoversWithInteraction = new ArrayList<>();

		List<LandCoverNTT> getEditLandCoversWithInteraction = editLandCoversDAO.getEditLandCoversWithInteraction(env, landCoverToMerge.getGeom(),
				parcelId);
		if (getEditLandCoversWithInteraction != null && !getEditLandCoversWithInteraction.isEmpty()) {
			landCoversWithInteraction.addAll(getEditLandCoversWithInteraction);
		}

		List<LandCoverNTT> getNonEditLandCoversWithInteraction = editLandCoversDAO.getNonEditLandCoversWithInteraction(env, landCoverToMerge.getGeom(),
				parcelId);
		if (getNonEditLandCoversWithInteraction != null && !getNonEditLandCoversWithInteraction.isEmpty()) {
			landCoversWithInteraction.addAll(getNonEditLandCoversWithInteraction);
		}

		return landCoversWithInteraction.stream()
				.filter(landCoverWithInteraction -> landCoverWithInteraction.getLand_cover_code().equals(landCoverToMerge.getLand_cover_code()))
				.collect(toList());
	}

	// ---------------------------------------- START PERSIST EDITOR ------------------------------------------------ //

	public void persistEditorResult(EditorSupportParams params, EditorResult<Long> result, LandCoversEditResult landCoverEditResult) {

		Map<Long, Long> landCoverIdsOnParcelIds = new HashMap<>();
		Set<Long> parcelsIds = new HashSet<>();

		List<Long> deletedIds = new ArrayList<>();
		if (landCoverEditResult != null) {
			landCoverEditResult.getAdded().forEach(landCover -> landCoverIdsOnParcelIds.put(landCover.getId(), landCover.getParcel_id()));
			landCoverEditResult.getUpdated().forEach(landCover -> landCoverIdsOnParcelIds.put(landCover.getId(), landCover.getParcel_id()));
			deletedIds.addAll(landCoverEditResult.getDeleted());
		} else if (params.getParcelId() != null) {
			parcelsIds.add(params.getParcelId());
			result.getCreated().keySet().forEach(landCoverId -> landCoverIdsOnParcelIds.put(landCoverId, params.getParcelId()));
			result.getModified().keySet().forEach(landCoverId -> landCoverIdsOnParcelIds.put(landCoverId, params.getParcelId()));
			result.getTopologyCorrected().keySet().forEach(landCoverId -> landCoverIdsOnParcelIds.put(landCoverId, params.getParcelId()));
			deletedIds.addAll(result.getDeleted());
		} else {
			InvalidSessionParcelIdException ex = new InvalidSessionParcelIdException(Status.BAD_REQUEST,
					params.getOperation(), ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		addDeletedLandCoverIds(params, landCoverIdsOnParcelIds, deletedIds, env);

		List<LandCoverNTT> persistLandCovers = buildPersistLandCovers(params, result, landCoverIdsOnParcelIds, env);

		// DB Save
		Map<Long, LandCoverNTT> alreadyinEditMap = new HashMap<>();
		Map<Long, Long> parcelIdsOnEditParcelIds = new HashMap<>();
		parcelsIds.addAll(landCoverIdsOnParcelIds.values());

		parcelsIds.stream().distinct().forEach(parcelId -> {
			// put land cover in alreadyInEditMap
			editLandCoversDAO.findInEditBySessionId(env, parcelId)
			.stream()
			.forEach(p -> alreadyinEditMap.put(p.getLand_cover_id(), p));

			// insert edit parcels and map parcels ids with edit parcels ids
			ParcelNTT editParcel = editParcelsDAO.findInEditBySessionId(env.getSessionId(), env.getReferenceDate(), parcelId).stream().findFirst().orElse(null);
			if (editParcel == null) {
				ParcelNTT parcelToInsert = editParcelsDAO.findNotInEditBySessionId(env, parcelId).get(0);
				Long editParcelId = editParcelsDAO.nextSequenceVal();
				parcelToInsert.setEdit_id(editParcelId);
				parcelToInsert.setEdit_status(EditStatus.ONLY_LANDCOVERS);
				editSessionSupportService.checkAndInsertEditParcel(params, parcelToInsert);

				parcelIdsOnEditParcelIds.put(parcelId, editParcelId);
			} else {
				parcelIdsOnEditParcelIds.put(parcelId, editParcel.getEdit_id());
			}

		});

		// insert edit land covers
		persistLandCovers(params, landCoverEditResult, env, persistLandCovers, alreadyinEditMap, parcelIdsOnEditParcelIds);
	}

	private void persistLandCovers(EditorSupportParams params, LandCoversEditResult landCoverEditResult, ServiceSupportEnv env,
			List<LandCoverNTT> persistLandCovers, Map<Long, LandCoverNTT> alreadyinEditMap, Map<Long, Long> parcelIdsOnEditParcelIds) {

		persistLandCovers.stream().forEach(plc -> {
			if (plc.getLand_cover_id() == null) { // is new --> insert
				persistLandCoversToInsert(env, parcelIdsOnEditParcelIds, plc);
			} else if (!alreadyinEditMap.containsKey(plc.getLand_cover_id())) { // it exist but not in edit
				persistLandCoversNotInEdit(params, env, parcelIdsOnEditParcelIds, plc);
			} else { // to be updated
				persistLandCoversToBeUpdated(landCoverEditResult, env, alreadyinEditMap, parcelIdsOnEditParcelIds, plc);
			}
		});
	}

	private void persistLandCoversNotInEdit(EditorSupportParams params, ServiceSupportEnv env, Map<Long, Long> parcelIdsOnEditParcelIds, LandCoverNTT plc) {
		Long nextEditId = editLandCoversDAO.nextSequenceVal();

		// Get information from "official" lpis_parcels_lc_details table
		String code = this.internalConf.getStringValue(params.getReqContext().getTenantId(), InternalConfigKeys.DEFAULT_LAND_COVER_CODE_KEY.getKey());
		LandCoverNTT offLandCover = landCoverDAO.getLandCoverDetail(env, plc.getLand_cover_id());
		if (offLandCover != null) {
			code = offLandCover.getLand_cover_code();
		}

		plc.setEdit_id(nextEditId);
		plc.setEdit_parcel_id(parcelIdsOnEditParcelIds.get(plc.getParcel_id()));
		plc.setLand_cover_code(code);

		editLandCoversDAO.deleteById(params.getSession().getUuid(), plc.getLand_cover_id());

		editLandCoversDAO.insert(plc, env.getSessionId());
	}

	private void persistLandCoversToInsert(ServiceSupportEnv env, Map<Long, Long> parcelIdsOnEditParcelIds, LandCoverNTT plc) {
		Long nextEditId = editLandCoversDAO.nextSequenceVal();
		Long nextNewLandCoverId = editLandCoversDAO.nextNewLandCoverIdVal(); // for internal use new land cover id are negative sequence

		plc.setEdit_id(nextEditId);
		plc.setIn_edit_former_land_cover_id(plc.getLand_cover_id());
		plc.setLand_cover_id(nextNewLandCoverId);
		plc.setEdit_parcel_id(parcelIdsOnEditParcelIds.get(plc.getParcel_id()));
		editLandCoversDAO.insert(plc, env.getSessionId());
	}

	private void persistLandCoversToBeUpdated(LandCoversEditResult landCoverEditResult, ServiceSupportEnv env, Map<Long, LandCoverNTT> alreadyinEditMap,
			Map<Long, Long> parcelIdsOnEditParcelIds, LandCoverNTT plc) {
		plc.setEdit_parcel_id(parcelIdsOnEditParcelIds.get(plc.getParcel_id()));

		if (landCoverEditResult != null && landCoverEditResult.getUpdated() != null) {
			LandCoverWithUnits updatedLandCover = landCoverEditResult.getUpdated().stream().filter(landcover -> plc.getLand_cover_id().equals(landcover.getId()))
					.findFirst().orElse(null);
			if (updatedLandCover != null && updatedLandCover.getParcel_id().equals(plc.getParcel_id())) {
				plc.setEdit_parcel_id(parcelIdsOnEditParcelIds.get(updatedLandCover.getParcel_id()));
			}
		}

		LandCoverNTT alreadyInEditLandCover = alreadyinEditMap.get(plc.getLand_cover_id());
		if (alreadyInEditLandCover != null && alreadyInEditLandCover.getEdit_status().equals(EditStatus.IN_EDIT)) {
			plc.setEdit_status(EditStatus.IN_EDIT);
		}

		editLandCoversDAO.updateGeometryAndParcelByLandCoverId(plc, env.getSessionId());
	}

	private void addDeletedLandCoverIds(EditorSupportParams params, Map<Long, Long> landCoverIdsOnParcelIds, List<Long> deletedIds, ServiceSupportEnv env) {
		deletedIds.forEach(landCoverId -> {
			LandCoverNTT deletedLandCover = null;
			List<LandCoverNTT> editLandCovers = editLandCoversDAO.getEditLandCoversFromLandCoverIdsBySession(env, Arrays.asList(landCoverId));
			if (!editLandCovers.isEmpty()) {
				deletedLandCover = editLandCovers.get(0);
			} else {
				deletedLandCover = landCoverDAO.getLandCoverDetail(env, landCoverId);
				if (deletedLandCover == null) {
					LandCoverNotFoundException ex = new LandCoverNotFoundException(Status.NOT_FOUND, params.getOperation(), ErrorField.LANDCOVER_ID,
							this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

					log.error(ex.getBody().getLogErrorMessage());

					throw ex;
				}
			}

			landCoverIdsOnParcelIds.put(landCoverId, deletedLandCover.getParcel_id());
		});
	}

	private List<LandCoverNTT> buildPersistLandCovers(EditorSupportParams params, EditorResult<Long> result, Map<Long, Long> landCoverIdsOnParcelIds,
			ServiceSupportEnv env) {
		List<LandCoverNTT> persistLandCovers = new ArrayList<>();

		addDeletedLandCoversFromEditorResult(result, landCoverIdsOnParcelIds, env, persistLandCovers);

		addCreatedLandCoversFromEditorResult(params, result, landCoverIdsOnParcelIds, env, persistLandCovers);

		addModifiedLandCoversFromEditorResult(result, landCoverIdsOnParcelIds, env, persistLandCovers);

		addTopologyCorrectedLandCoversFromEditorResult(result, landCoverIdsOnParcelIds, env, persistLandCovers);

		return persistLandCovers;
	}

	private void addTopologyCorrectedLandCoversFromEditorResult(EditorResult<Long> result, Map<Long, Long> landCoverIdsOnParcelIds, ServiceSupportEnv env,
			List<LandCoverNTT> persistLandCovers) {
		result.getTopologyCorrected().keySet().forEach(pid -> {
			Geometry g = result.getTopologyCorrected().get(pid);

			Long parcelId = landCoverIdsOnParcelIds.get(pid);
			persistLandCovers.add(LandCoverNTT
					.builder()
					.land_cover_id(pid)
					.parcel_id(parcelId)
					.srs(env.getSrs())
					.geom(g)
					.area_sqm(g.getArea())
					.edit_status(EditStatus.TOPOLOGY_CORRECTED)
					.build());
		});
	}

	private void addModifiedLandCoversFromEditorResult(EditorResult<Long> result, Map<Long, Long> landCoverIdsOnParcelIds, ServiceSupportEnv env,
			List<LandCoverNTT> persistLandCovers) {
		result.getModified().keySet().forEach(pid -> {
			Geometry g = result.getModified().get(pid);

			Long parcelId = landCoverIdsOnParcelIds.get(pid);
			persistLandCovers.add(LandCoverNTT
					.builder()
					.land_cover_id(pid)
					.parcel_id(parcelId)
					.srs(env.getSrs())
					.geom(g)
					.area_sqm(g.getArea())
					.edit_status(EditStatus.IN_EDIT)
					.build());
		});
	}

	private void addCreatedLandCoversFromEditorResult(EditorSupportParams params, EditorResult<Long> result, Map<Long, Long> landCoverIdsOnParcelIds,
			ServiceSupportEnv env, List<LandCoverNTT> persistLandCovers) {
		result.getCreated().keySet().forEach(pid -> {
			Geometry g = result.getCreated().get(pid);

			// if land cover has a parent, set code with parent code
			Long parentPid = result.getCreatedParent(pid);
			String landCoverCode = this.internalConf.getStringValue(params.getReqContext().getTenantId(),
					InternalConfigKeys.DEFAULT_LAND_COVER_CODE_KEY.getKey());

			if (parentPid == null && StringUtils.isNotBlank(params.getLandCoverCode())) {
				landCoverCode = params.getLandCoverCode();
			} else {
				landCoverCode = retrieveLandCoversCode(params, env, parentPid).getLand_cover_code();
			}

			Long parcelId = landCoverIdsOnParcelIds.get(pid);
			persistLandCovers.add(LandCoverNTT
					.builder()
					.land_cover_id(null)
					.parent_id(parentPid)
					.parcel_id(parcelId)
					.srs(env.getSrs())
					.geom(g)
					.area_sqm(g.getArea())
					.land_cover_code(landCoverCode)
					.edit_status(EditStatus.IN_EDIT)
					.build());
		});
	}

	private void addDeletedLandCoversFromEditorResult(EditorResult<Long> result, Map<Long, Long> landCoverIdsOnParcelIds, ServiceSupportEnv env,
			List<LandCoverNTT> persistLandCovers) {
		// XXX per ogni deleted ne creo un con geometria nulla
		result.getDeleted().stream().forEach(pid -> {
			Long parcelId = landCoverIdsOnParcelIds.get(pid);
			persistLandCovers.add(LandCoverNTT
					.builder()
					.land_cover_id(pid)
					.parcel_id(parcelId)
					.srs(env.getSrs())
					.geom(null)
					.area_sqm(0.0)
					.edit_status(EditStatus.DELETED)
					.build());
		});
	}

	// ----------------------------------- END PERSIST EDITOR ----------------------------------------------------- //

	public void cleanUpIncompatibleUnits(EditorSupportParams params, LandCoverWithUnits landcover) {
		List<UnitType> compatibleUnits = supportDAO.getCompatibleUnitTypesByLandCoverCode(params.getReqContext().getTenantId(), landcover.getCode());

		Arrays.asList(UnitType.values()).stream()
				.filter(type -> !compatibleUnits.contains(type))
				.forEach(type -> {
					if (type.equals(UnitType.VINE_UNIT)) {
						editVineUnitsSupportService.cleanUpIncompatibleVineUnits(params, landcover.getId());
					} else if (type.equals(UnitType.OLIVE_UNIT)) {
						editOliveUnitsSupportService.cleanUpIncompatibleOliveUnits(params, landcover.getId());
					} else if (type.equals(UnitType.FRUIT_UNIT)) {
						editFruitUnitsSupportService.cleanUpIncompatibleFruitUnits(params, landcover.getId());
					} else {
						ErrorCode errorCode = ErrorCode.UNSUPPORTED_OPERATION;
						Map<String, Map<String, String>> errorDescriptions = this.errorDescriptionsService
								.getTenantErrorDescriptions(params.getReqContext().getTenantId());
						String message = errorDescriptions.containsKey(errorCode.toString())
								&& errorDescriptions.get(errorCode.toString()).containsKey(params.getReqContext().getLang())
										? errorDescriptions.get(errorCode.toString()).get(params.getReqContext().getLang())
										: errorCode.getDescription();

						throw new UnsupportedOperationException(message);
					}
				});
	}

	public void removeOrphanLandCovers(EditorResult<Long> result, EditorResult<Long> parcelEditorResult) {
		if (result == null || parcelEditorResult == null) {
			return;
		}

		List<Geometry> geoms = new ArrayList<>();
		geoms.addAll(parcelEditorResult.getCreated().values());
		geoms.addAll(parcelEditorResult.getModified().values());
		geoms.addAll(parcelEditorResult.getTopologyCorrected().values());

		if (geoms.isEmpty()) {
			return;
		}

		Geometry unitedGeoms = Utils.getUnion(geoms);

		if (result.getCreated() != null && !result.getCreated().isEmpty()) {
			result.getCreated()
					.entrySet()
					.removeIf(e -> e.getValue() == null || !unitedGeoms.contains(Utils.getSafeInteriorPoint(e.getValue())));
		}

		if (result.getModified() != null && !result.getModified().isEmpty()) {
			result.getModified()
					.entrySet()
					.forEach(e -> {
						if (e.getValue() == null || !unitedGeoms.contains(Utils.getSafeInteriorPoint(e.getValue()))) {
							result.getDeleted().add(e.getKey());
						}
					});
		}

		result.getDeleted().forEach(e -> result.getModified().remove(e));
	}

	public void editLandCoversEditResultAndLandCoverEditorResultFromParcel(EditorSupportParams params, EditorResult<Long> parcelEditorResult,
			EditorResult<Long> landCoverEditorResultToEdit, LandCoversEditResult toEdit) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		removeOrphanLandCovers(landCoverEditorResultToEdit, parcelEditorResult);

		Map<Long, LandCoverNTT> currentLandCoversMap = new HashMap<>();

		if (parcelEditorResult.getCreated() != null) {
			parcelEditorResult.getCreated().keySet().forEach(p -> {
				currentLandCoversMap.putAll(getCurrentLandCoversMap(env, p));
				currentLandCoversMap.putAll(getCurrentLandCoversMap(env, parcelEditorResult.getCreatedParent(p)));
			});
		}

		if (parcelEditorResult.getModified() != null) {
			parcelEditorResult.getModified().keySet().forEach(p -> currentLandCoversMap.putAll(getCurrentLandCoversMap(env, p)));
		}

		if (parcelEditorResult.getTopologyCorrected() != null) {
			parcelEditorResult.getTopologyCorrected().keySet()
					.forEach(p -> currentLandCoversMap.putAll(getCurrentLandCoversMap(env, p)));
		}

		if (parcelEditorResult.getDeleted() != null) {
			parcelEditorResult.getDeleted().forEach(p -> currentLandCoversMap.putAll(getCurrentLandCoversMap(env, p)));
		}

		params.setCurrentLandCoversMap(currentLandCoversMap);

		toEdit.getDeleted().addAll(List.copyOf(landCoverEditorResultToEdit.getDeleted()));

		addLandCoversFromParcelsPolygons(params, parcelEditorResult.getCreated(), landCoverEditorResultToEdit, toEdit);
		addLandCoversFromParcelsPolygons(params, parcelEditorResult.getModified(), landCoverEditorResultToEdit, toEdit);
		addLandCoversFromParcelsPolygons(params, parcelEditorResult.getTopologyCorrected(), landCoverEditorResultToEdit, toEdit);
	}

	private void addLandCoversFromParcelsPolygons(EditorSupportParams params, Map<Long, Polygon> parcelPolygons, EditorResult<Long> landCoversPolygonsToEdit,
			LandCoversEditResult toEdit) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		// Calculate the edit id for the new landcovers
		Long nextLandCoverId = toEdit.getAdded().stream().mapToLong(l -> l.getId() - 1).min()
				.orElse(editLandCoversDAO.nextNewLandCoverIdVal());

		if (landCoversPolygonsToEdit.getCreated() != null) {
			Long minIdCreated = landCoversPolygonsToEdit.getCreated().keySet().stream().mapToLong(Long::longValue).min().orElse(0);
			if (minIdCreated <= nextLandCoverId)
				nextLandCoverId = minIdCreated - 1;
		}

		Map<Long, LandCoverNTT> currentLandCoversMap = params.getCurrentLandCoversMap();

		for (Entry<Long, Polygon> entry : parcelPolygons.entrySet()) {

			Long editorParcelId = entry.getKey();
			Polygon editorParcelGeom = entry.getValue();

			buildAddedLandCoverEditResult(params, landCoversPolygonsToEdit, toEdit, env, currentLandCoversMap, editorParcelId, editorParcelGeom);

			nextLandCoverId = buildModifiedLandCoverEditResult(params, landCoversPolygonsToEdit, toEdit, env, currentLandCoversMap, editorParcelId,
					editorParcelGeom, nextLandCoverId);

			buildTopologyCorrectedLandCoverEditResult(params, landCoversPolygonsToEdit, toEdit, env, currentLandCoversMap, editorParcelId,
					editorParcelGeom, nextLandCoverId);
		}
	}

	private Long buildModifiedLandCoverEditResult(EditorSupportParams params, EditorResult<Long> landCoversPolygonsToEdit, LandCoversEditResult toEdit,
			ServiceSupportEnv env, Map<Long, LandCoverNTT> currentLandCoversMap, Long editorParcelId, Polygon editorParcelGeom, Long nextLandCoverId) {

		List<Long> landCoverIdsModifiedToRemove = new ArrayList<>();

		for (Long landCoverId : landCoversPolygonsToEdit.getModified().keySet()) {
			Polygon landCoverGeom = landCoversPolygonsToEdit.getModified().get(landCoverId);
			Long landCoverArea = Math.round(landCoverGeom.getArea());

			if (editorParcelGeom.contains(Utils.getSafeInteriorPoint(landCoverGeom))) {
				String landCoverCode = this.internalConf.getStringValue(params.getReqContext().getTenantId(),
						InternalConfigKeys.DEFAULT_LAND_COVER_CODE_KEY.getKey());
				AbsoluteDate dayTo = null;
				String description = null;
				LocalDateTime lastUpdate = null;
				if (currentLandCoversMap.get(landCoverId) != null) {
					landCoverCode = currentLandCoversMap.get(landCoverId).getLand_cover_code();
					dayTo = currentLandCoversMap.get(landCoverId).getDay_to();
					description = currentLandCoversMap.get(landCoverId).getLand_cover_description();
					lastUpdate = currentLandCoversMap.get(landCoverId).getLast_update();
				} else {
					description = getLandCoverDescription(landCoverCode, params);
				}

				LayerStyle style = this.styleService.getLandCoverLayerStyle(env.getTenantId(), env.getReferenceDate(), landCoverCode);

				// if landCover is in another parcel from original, delete this landcover and create a new landcover
				// if a landcoverId is < 0 , land cover is new yet
				if (isNewLandCoverFromLandCoverEditorResult(currentLandCoversMap, editorParcelId, landCoverId)) {

					toEdit.getDeleted().add(landCoverId);

					toEdit.getAdded().add(LandCoverWithUnits.builder()
							.id(nextLandCoverId)
							.parcel_id(editorParcelId)
							.geom(landCoverGeom)
							.code(landCoverCode)
							.day_from(env.getReferenceDate())
							.srs(params.getSession().getLock_geom_srs())
							.day_to(buildLandCoverDayTo(dayTo))
							.area_sqm(landCoverArea)
							.description(description)
							.layer_style(style)
							.edit_status(EditStatus.IN_EDIT)
							.last_update(null)
							.parent_id(landCoverId)
							.build());

					landCoversPolygonsToEdit.getDeleted().add(landCoverId);
					landCoversPolygonsToEdit.getCreated().put(nextLandCoverId, landCoverGeom);
					landCoversPolygonsToEdit.setCreatedParent(nextLandCoverId, landCoverId);

					landCoverIdsModifiedToRemove.add(landCoverId);
					nextLandCoverId--;
				}
				// update only properties
				else {
					toEdit.getUpdated().add(LandCoverWithUnits.builder()
							.id(landCoverId)
							.parcel_id(editorParcelId)
							.geom(landCoverGeom)
							.area_sqm(landCoverArea)
							.srs(params.getSession().getLock_geom_srs())
							.day_from(env.getReferenceDate())
							.day_to(buildLandCoverDayTo(dayTo))
							.code(landCoverCode)
							.description(description)
							.layer_style(style)
							.edit_status(EditStatus.IN_EDIT)
							.last_update(lastUpdate)
							.build());
				}
			}
		}

		landCoverIdsModifiedToRemove.forEach(id -> landCoversPolygonsToEdit.getModified().remove(id));

		return nextLandCoverId;
	}

	private boolean isNewLandCoverFromLandCoverEditorResult(Map<Long, LandCoverNTT> currentLandCoversMap, Long editorParcelId, Long landCoverId) {
		return (currentLandCoversMap.get(landCoverId) == null
				|| editorParcelId.compareTo(Long.valueOf(0L)) < 0
				|| (currentLandCoversMap.get(landCoverId).getParcel_id() != null
						&& !currentLandCoversMap.get(landCoverId).getParcel_id().equals(editorParcelId)))
				&& landCoverId.compareTo(Long.valueOf(0L)) > 0;
	}

	private Long buildTopologyCorrectedLandCoverEditResult(EditorSupportParams params, EditorResult<Long> landCoversPolygonsToEdit, LandCoversEditResult toEdit,
			ServiceSupportEnv env, Map<Long, LandCoverNTT> currentLandCoversMap, Long editorParcelId, Polygon editorParcelGeom, Long nextLandCoverId) {

		List<Long> landCoverIdsTopologyCorrectedToRemove = new ArrayList<>();

		for (Long landCoverId : landCoversPolygonsToEdit.getTopologyCorrected().keySet()) {
			Polygon landCoverGeom = landCoversPolygonsToEdit.getTopologyCorrected().get(landCoverId);
			Long landCoverArea = Math.round(landCoverGeom.getArea());

			if (editorParcelGeom.contains(Utils.getSafeInteriorPoint(landCoverGeom))) {
				String landCoverCode = this.internalConf.getStringValue(params.getReqContext().getTenantId(),
						InternalConfigKeys.DEFAULT_LAND_COVER_CODE_KEY.getKey());
				AbsoluteDate dayTo = null;
				String description = null;
				LocalDateTime lastUpdate = null;
				EditStatus editStatus = EditStatus.TOPOLOGY_CORRECTED;
				if (currentLandCoversMap.get(landCoverId) != null) {
					landCoverCode = currentLandCoversMap.get(landCoverId).getLand_cover_code();
					dayTo = currentLandCoversMap.get(landCoverId).getDay_to();
					description = currentLandCoversMap.get(landCoverId).getLand_cover_description();
					lastUpdate = currentLandCoversMap.get(landCoverId).getLast_update();

					if (currentLandCoversMap.get(landCoverId).getEdit_status().equals(EditStatus.IN_EDIT)) {
						editStatus = EditStatus.IN_EDIT;
					}
				} else {
					description = getLandCoverDescription(landCoverCode, params);
				}

				LayerStyle style = this.styleService.getLandCoverLayerStyle(env.getTenantId(), env.getReferenceDate(), landCoverCode);

				// if landCover is in another parcel from original, delete this landcover and create a new landcover
				// if a landcoverId is < 0 , land cover is new yet
				if (isNewLandCoverFromLandCoverEditorResult(currentLandCoversMap, editorParcelId, landCoverId)) {

					toEdit.getDeleted().add(landCoverId);

					toEdit.getAdded().add(LandCoverWithUnits.builder()
							.id(nextLandCoverId)
							.parcel_id(editorParcelId)
							.geom(landCoverGeom)
							.code(landCoverCode)
							.day_from(env.getReferenceDate())
							.srs(params.getSession().getLock_geom_srs())
							.day_to(buildLandCoverDayTo(dayTo))
							.area_sqm(landCoverArea)
							.description(description)
							.layer_style(style)
							.edit_status(EditStatus.TOPOLOGY_CORRECTED)
							.last_update(null)
							.parent_id(landCoverId)
							.build());

					landCoversPolygonsToEdit.getDeleted().add(landCoverId);
					landCoversPolygonsToEdit.getCreated().put(nextLandCoverId, landCoverGeom);
					landCoversPolygonsToEdit.setCreatedParent(nextLandCoverId, landCoverId);

					landCoverIdsTopologyCorrectedToRemove.add(landCoverId);
					nextLandCoverId--;
				}
				// update only properties
				else {
					toEdit.getUpdated().add(LandCoverWithUnits.builder()
							.id(landCoverId)
							.parcel_id(editorParcelId)
							.geom(landCoverGeom)
							.area_sqm(landCoverArea)
							.srs(params.getSession().getLock_geom_srs())
							.day_from(env.getReferenceDate())
							.day_to(buildLandCoverDayTo(dayTo))
							.code(landCoverCode)
							.description(description)
							.layer_style(style)
							.edit_status(editStatus)
							.last_update(lastUpdate)
							.build());
				}
			}
		}

		landCoverIdsTopologyCorrectedToRemove.forEach(id -> landCoversPolygonsToEdit.getTopologyCorrected().remove(id));

		return nextLandCoverId;
	}

	private AbsoluteDate buildLandCoverDayTo(AbsoluteDate dayTo) {
		return dayTo != null ? dayTo : END_OF_WORLD;
	}

	private void buildAddedLandCoverEditResult(EditorSupportParams params, EditorResult<Long> landCoversPolygonsToEdit, LandCoversEditResult toEdit,
			ServiceSupportEnv env, Map<Long, LandCoverNTT> currentLandCoversMap, Long editorParcelId, Polygon editorParcelGeom) {

		landCoversPolygonsToEdit.getCreated().forEach((landCoverId, landCoverGeom) -> {
			if (editorParcelGeom.contains(Utils.getSafeInteriorPoint(landCoverGeom))) {
				Long parentPid = landCoversPolygonsToEdit.getCreatedParent(landCoverId);

				LandCoversCode landCoversCodeObj = retrieveLandCoversCode(params, env, parentPid);
				String landCoverCode = landCoversCodeObj.getLand_cover_code();
				String description = landCoversCodeObj.getDescription();

				if (StringUtils.isEmpty(description)) {
					description = getLandCoverDescription(landCoverCode, params);
				}

				AbsoluteDate dayTo = null;
				if (parentPid != null && currentLandCoversMap.get(parentPid) != null)
					dayTo = currentLandCoversMap.get(parentPid).getDay_to();

				Long landCoverArea = Math.round(landCoverGeom.getArea());

				LayerStyle style = this.styleService.getLandCoverLayerStyle(env.getTenantId(), env.getReferenceDate(), landCoverCode);

				toEdit.getAdded().add(LandCoverWithUnits.builder()
						.id(landCoverId)
						.parcel_id(editorParcelId)
						.geom(landCoverGeom)
						.code(landCoverCode)
						.day_from(env.getReferenceDate())
						.srs(params.getSession().getLock_geom_srs())
						.day_to(buildLandCoverDayTo(dayTo))
						.area_sqm(landCoverArea)
						.description(description)
						.layer_style(style)
						.last_update(null)
						.edit_status(EditStatus.IN_EDIT)
						.parent_id(parentPid)
						.build());
			}
		});
	}
	
	public void insertEditLandcover(String sessionId, LandCoverNTT landcoverToInsert) {
		editLandCoversDAO.insert(landcoverToInsert, sessionId);
	}
	
	public void checkValidUnitsBeforUpdateOrDeleteLandCover(EditorSupportParams params, Long landCoverId) {
		List<VineUnitDetailsNTT> vineUnits = editVineUnitsSupportService.getVineUnitsNTT(params, landCoverId, null);
		if(!vineUnits.isEmpty()) {
			LandCoverWithUnitsException ex = new LandCoverWithUnitsException(Status.BAD_REQUEST, params.getOperation(), ErrorField.LANDCOVER_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getReqContext().getTenantId()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		List<OliveUnitDetailsNTT> oliveUnits = editOliveUnitsSupportService.getOliveUnitsNTT(params, landCoverId, null);
		if(!oliveUnits.isEmpty()) {
			LandCoverWithUnitsException ex = new LandCoverWithUnitsException(Status.BAD_REQUEST, params.getOperation(), ErrorField.LANDCOVER_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getReqContext().getTenantId()), params.getReqContext().getLang());
			
			log.error(ex.getBody().getLogErrorMessage());
			
			throw ex;
		}
		
		List<FruitUnitDetailsNTT> fruitUnits = editFruitUnitsSupportService.getFruitUnitsNTT(params, landCoverId, null);
		if(!fruitUnits.isEmpty()) {
			LandCoverWithUnitsException ex = new LandCoverWithUnitsException(Status.BAD_REQUEST, params.getOperation(), ErrorField.LANDCOVER_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getReqContext().getTenantId()), params.getReqContext().getLang());
			
			log.error(ex.getBody().getLogErrorMessage());
			
			throw ex;
		}
	}
	
	public void copyLandCoverUnits(EditorSupportParams params, LandCoversEditResult res, Boolean deleteSourceUnit) {
		editVineUnitsSupportService.copyLandCoverVineUnits(params, res, deleteSourceUnit);
		editOliveUnitsSupportService.copyLandCoverOliveUnits(params, res, deleteSourceUnit);
		editFruitUnitsSupportService.copyLandCoverFruitUnits(params, res, deleteSourceUnit);
	}
	
	
	public void mergeLandCoverUnits(EditorSupportParams params, LandCoversEditResult landCoversEditResult) {
		editVineUnitsSupportService.mergeLandCoverVineUnits(params, params.getLandCoverId(), landCoversEditResult);
		editOliveUnitsSupportService.mergeLandCoverOliveUnits(params, params.getLandCoverId(), landCoversEditResult);
		editFruitUnitsSupportService.mergeLandCoverFruitUnits(params, params.getLandCoverId(), landCoversEditResult);
	}

	public void mergeParcelLandCoverUnits(EditorSupportParams params, LandCoversEditResult res) {
		editVineUnitsSupportService.mergeParcelLandCoverVineUnits(params, res);
		editOliveUnitsSupportService.mergeParcelLandCoverOliveUnits(params, res);
		editFruitUnitsSupportService.mergeParcelLandCoverFruitUnits(params, res);
	}

	public void setTotaleUnitAreaSqm(LandCoversEditResult res) {
		res.getAdded().stream().forEach(this::setTotaleUnitAreaSqm);
		res.getUpdated().stream().forEach(this::setTotaleUnitAreaSqm);
	}
	
	public void setTotaleUnitAreaSqm(LandCoverWithUnits lc) {
		if(lc.getVine_units() == null && lc.getOlive_units() == null && lc.getFruit_units() == null) {
			return;
		}

		Integer vineUnitArea = 0;
		if(lc.getVine_units() != null) {
			vineUnitArea = lc.getVine_units()
					.stream()
					.mapToInt(VineUnitWithAptitudes::getAreaSqm)
					.sum();
		}

		Integer oliveUnitArea = 0;
		if(lc.getOlive_units() != null) {
			oliveUnitArea = lc.getOlive_units()
					.stream()
					.mapToInt(OliveUnit::getAreaSqm)
					.sum();
		}
		
		Integer fruitUnitArea = 0;
		if(lc.getFruit_units() != null) {
			fruitUnitArea = lc.getFruit_units()
					.stream()
					.mapToInt(FruitUnit::getAreaSqm)
					.sum();
		}

		lc.setTotal_unit_area_sqm(vineUnitArea + oliveUnitArea + fruitUnitArea);
	}
}
