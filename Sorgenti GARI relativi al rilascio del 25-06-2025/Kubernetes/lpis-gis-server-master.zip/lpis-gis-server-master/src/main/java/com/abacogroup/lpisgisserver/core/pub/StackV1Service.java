package com.abacogroup.lpisgisserver.core.pub;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.abacogroup.lpisgisserver.core.BaseService;
import com.abacogroup.lpisgisserver.core.ErrorDescriptionsService;
import com.abacogroup.lpisgisserver.core.ExternalConfigService;
import com.abacogroup.lpisgisserver.core.InternalConfigService;
import com.abacogroup.lpisgisserver.core.StackService;
import com.abacogroup.lpisgisserver.core.StyleService;
import com.abacogroup.lpisgisserver.core.mappers.pub.LandCoversV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.OliveUnitV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.StackParcelV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.StackV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.VineUnitV1Mapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.StackParcelsLandCoversList;
import com.abacogroup.lpisgisserver.resources.res.pub.LandCoverV1;
import com.abacogroup.lpisgisserver.resources.res.pub.StackParcelV1;
import com.abacogroup.lpisgisserver.resources.res.pub.StackParcelsListV1;
import com.abacogroup.lpisgisserver.resources.res.pub.StacksListV1;
import com.abacogroup.lpisgisserver.resources.res.pub.units.olive.OliveUnitV1;
import com.abacogroup.lpisgisserver.resources.res.pub.units.vine.VineUnitWithAptitudesV1;

public class StackV1Service  extends BaseService {

	private StackService stackService;

	public StackV1Service(DAOContainer dc, StackService stackService, InternalConfigService internalConf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService,
			PluginEnvironment pluginEnvironment) {
		super(dc, internalConf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.stackService = stackService;
	}

	public StacksListV1 getParcelStacks(ServiceSupportEnv env, Long parcelId, Boolean onlyValid) {
		return StacksListV1.builder()
				.stacks_list(
						stackService.getParcelStacks(env, parcelId, onlyValid)
						.getStacks_list()
						.stream()
						.map(StackV1Mapper.INSTANCE::toResponseV1)
						.collect(Collectors.toList()))
				.build();
	}

	public StackParcelsListV1 getParcelsLandCoversFromStackId(ServiceSupportEnv env, Long stackId, Boolean viewAllEditStatus) {
		return mapStackParcelsLandCoversListToStackParcelsListV1(stackService.getParcelsLandCoversFromStackId(env, stackId, viewAllEditStatus));
	}

	public StackParcelsListV1 getParcelsLandCoversFromTaskId(ServiceSupportEnv env, Long taskId, Boolean viewAllEditStatus) {
		return mapStackParcelsLandCoversListToStackParcelsListV1(stackService.getParcelsLandCoversFromTaskId(env, taskId, viewAllEditStatus));
	}

	private StackParcelsListV1 mapStackParcelsLandCoversListToStackParcelsListV1(StackParcelsLandCoversList list) {

		List<StackParcelV1> parcels = list.getParcels_list().stream()
				.map(p -> {
					StackParcelV1 parcel = StackParcelV1Mapper.INSTANCE.toResponseV1(p);

					list.getLand_covers_list()
					.stream()
					.filter(landcover -> landcover.getParcel_id().equals(p.getId()) && landcover.getParcel_details_id().equals(p.getDetails_id()))
					.forEach(landCover -> {
						LandCoverV1 parcelLandCover = LandCoversV1Mapper.INSTANCE.toResponseV1(landCover);

						List<VineUnitWithAptitudesV1> vineUnits = landCover.getVine_units() != null ? landCover.getVine_units().stream().map(VineUnitV1Mapper.INSTANCE::toResponseV1).collect(Collectors.toList()) : new ArrayList<>();
						parcelLandCover.setVine_units(vineUnits);
						
						List<OliveUnitV1> oliveUnits = landCover.getOlive_units() != null ? landCover.getOlive_units().stream().map(OliveUnitV1Mapper.INSTANCE::toResponseV1).collect(Collectors.toList()) : new ArrayList<>();
						parcelLandCover.setOlive_units(oliveUnits);

						parcel.getLandcovers_list().add(parcelLandCover);
					});

					return parcel;
				})
				.collect(Collectors.toList());

		return StackParcelsListV1.builder()
				.parcels_list(parcels)
				.stack(StackV1Mapper.INSTANCE.toResponseV1(list.getStack()))
				.build();
	}

}
