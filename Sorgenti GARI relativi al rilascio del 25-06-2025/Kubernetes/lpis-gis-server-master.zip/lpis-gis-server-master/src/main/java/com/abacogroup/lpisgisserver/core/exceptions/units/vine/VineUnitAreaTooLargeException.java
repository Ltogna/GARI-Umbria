package com.abacogroup.lpisgisserver.core.exceptions.units.vine;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class VineUnitAreaTooLargeException extends AbstractException {

	private static final long serialVersionUID = -6467378631448203591L;

	private static final ErrorCode ERROR_CODE = ErrorCode.VINE_UNIT_AREA_TOO_LARGE;

	public VineUnitAreaTooLargeException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new VineUnitAreaTooLargeExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "vine unit area too large")
	public static class VineUnitAreaTooLargeExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 3853099588145979239L;

		public VineUnitAreaTooLargeExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
