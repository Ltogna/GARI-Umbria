package com.abacogroup.lpisgisserver.core.models.cll;

import java.util.List;

import com.abacogroup.lpisgisserver.core.models.cll.api.v1.LandLinkResV1;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CllParcelInfiniteList {
	private Long nextKey;
	private List<LandLinkResV1> records;
	private Long count;
}
