package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface LockParcelsDAO extends Transactional<LockParcelsDAO>, EnhancedSqlObject {

	@SqlUpdate("delete from lpis_lock_parcels where session_uuid = :session_uuid")
	void deleteBySessionUuid(@Bind("session_uuid") String sessionUuid);

	@SqlUpdate("\n "
			+ "insert into lpis_lock_parcels(session_uuid, parcel_id) \n"
			+ "select :sessionId as sessionId, id \n"
			+ "  from lpis_parcels \n"
			+ " where tenant_id = :tenantId \n"
			+ "   and id in (<parcelsIds>) \n"
			+ "   and id not in (select parcel_id from lpis_lock_parcels where session_uuid = :sessionId)\n")
	void importParcelsEdit(@BindBean ServiceSupportEnv env, @BindList("parcelsIds") List<Long> parcelIds);

	@SqlQuery("select llp.parcel_id from lpis_lock_parcels llp where llp.session_uuid = :sessionId")
	List<Long> getParcelsIdsFromSessionId(@Bind("sessionId") String sessionId);
}
