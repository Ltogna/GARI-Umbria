package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.MatrixClassLandusesNTT;
import com.abacogroup.lpisgisserver.resources.res.pub.MatrixClassLanduseV1;

@Mapper
public interface MatrixClassLanduseMapper {

	MatrixClassLanduseMapper ININSTANCE = Mappers.getMapper(MatrixClassLanduseMapper.class);
	
	@Mapping(target = "landuse.land_uses_code", source = "landuse.code")
	MatrixClassLanduseV1 entityToDto(MatrixClassLandusesNTT entity);
	
	@Mapping(target = "landuse.code", source = "landuse.land_uses_code")
	@Mapping(target = "dt_insert", ignore = true)
	@Mapping(target = "dt_delete", ignore = true)
	@Mapping(target = "user_id_insert", ignore = true)
	@Mapping(target = "user_id_delete", ignore = true)
	MatrixClassLandusesNTT dtoToEntity(MatrixClassLanduseV1 dto);
	
}
