package com.abacogroup.lpisgisserver.core.exceptions.parcel;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class TooMuchParcelsToMergeException extends AbstractException {

	private static final long serialVersionUID = 2630927875229169013L;

	private static final ErrorCode ERROR_CODE = ErrorCode.TOO_MUCH_PARCELS_TO_MERGE;

	public TooMuchParcelsToMergeException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new TooMuchParcelsToMergeExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Too much parcels to merge")
	public static class TooMuchParcelsToMergeExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -1785464380985510524L;

		public TooMuchParcelsToMergeExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
