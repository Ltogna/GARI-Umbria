package com.abacogroup.lpisgisserver.core;

import java.util.List;
import java.util.stream.Collectors;

import org.locationtech.jts.geom.Geometry;
import org.locationtech.proj4j.CoordinateReferenceSystem;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.location.InvalidCoordinatesException;
import com.abacogroup.lpisgisserver.core.exceptions.location.OutOfRangeException;
import com.abacogroup.lpisgisserver.core.mappers.LocationBlockMapper;
import com.abacogroup.lpisgisserver.core.mappers.LocationParcelMapper;
import com.abacogroup.lpisgisserver.core.mappers.LocationSectorMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.SectorDAO;
import com.abacogroup.lpisgisserver.db.ntt.SectorNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.LocationGpsPayload;
import com.abacogroup.lpisgisserver.resources.res.LocationBlock;
import com.abacogroup.lpisgisserver.resources.res.LocationBlockList;
import com.abacogroup.lpisgisserver.resources.res.LocationGeom;
import com.abacogroup.lpisgisserver.resources.res.LocationParcel;
import com.abacogroup.lpisgisserver.resources.res.LocationSector;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LocationService extends BaseService {

	private final SectorDAO sectorDAO;
	
	private final CrossTenantLpisClientService crossTenantLpisClientService;
	
	private final CoordinateReferenceSystem worldCRS = BaseService.getCRS("EPSG:3857");
	private final CoordinateReferenceSystem gpsCRS = BaseService.getCRS("EPSG:4326");

	public LocationService(DAOContainer dc, CrossTenantLpisClientService crossTenantLpisClientService,
			InternalConfigService conf, ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService,
			StyleService styleService, PluginEnvironment pluginEnvironment) {

		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);
		this.sectorDAO = dc.getSectorDAO();
		this.crossTenantLpisClientService = crossTenantLpisClientService;
	}

	public LocationGeom getLocationByGpsGeom(ServiceSupportEnv env, @NotNull @Valid LocationGpsPayload payload) {
		
		CoordinateReferenceSystem payloadCRS = gpsCRS;
		if(payload.getSrs() != null) {
			payloadCRS = BaseService.getCRS(payload.getSrs());
		}
		
		Geometry worldGeomToSearch = reproject(payload.getGeom(), payloadCRS, worldCRS);
		
		if(!worldGeomToSearch.isValid()) {
			InvalidCoordinatesException ex = new InvalidCoordinatesException(Status.BAD_REQUEST, Operation.GET_LOCATION, ErrorField.GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		List<SectorNTT> sectorNTTs = sectorDAO.getSectorsWithInteractionsWithoutSrs(env.getTenantId(), worldGeomToSearch);
		
		if(sectorNTTs.isEmpty()) {
			OutOfRangeException ex = new OutOfRangeException(Status.BAD_REQUEST, Operation.GET_LOCATION, ErrorField.GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		CoordinateReferenceSystem sectorCRS = BaseService.getCRS(sectorNTTs.get(0).getSrs());
		Geometry newGeom = reproject(payload.getGeom(), payloadCRS, sectorCRS);
		
		return LocationGeom.builder()
				.srs(sectorNTTs.get(0).getSrs())
				.geom(newGeom)
				.build();
	}

	public InfiniteListResults<LocationSector> getLocationByLpisSector(ServiceSupportEnv env, String sectorFilter) {
		return crossTenantLpisClientService.getLpisSectors(env, sectorFilter)
				.map(LocationSectorMapper.INSTANCE::toLocationSector);
	}

	public LocationBlockList getLocationByLpisBlock(ServiceSupportEnv env, String blockFilter) {
		return LocationBlockList.builder()
				.blocks_list(crossTenantLpisClientService.getLpisBlocks(env, blockFilter).getBlocksList().stream()
						.map(block -> {
							LocationBlock locationBlock = LocationBlockMapper.INSTANCE.toLocationBlock(block);
							locationBlock.setSector_code(env.getSectorCode());
							return locationBlock;
						})
						.collect(Collectors.toList()))
				.build();
	}
	
	public InfiniteListResults<LocationParcel> getLocationByLpisParcel(ServiceSupportEnv env, String parcelFilter) {
		return crossTenantLpisClientService.getLpisParcels(env, parcelFilter)
				.map(LocationParcelMapper.INSTANCE::toLocationParcel);
	}
}
