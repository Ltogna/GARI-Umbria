package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.resources.req.TotalParcelsSummaryFilters;
import com.abacogroup.lpisgisserver.resources.req.pub.TotalParcelsSummaryFiltersV1;

@Mapper
public interface TotalParcelsSummaryFiltersV1Mapper {

	TotalParcelsSummaryFiltersV1Mapper INSTANCE = Mappers.getMapper(TotalParcelsSummaryFiltersV1Mapper.class);
	
	@InheritInverseConfiguration
	TotalParcelsSummaryFilters toPrivFilters(TotalParcelsSummaryFiltersV1 entity);
	
}
