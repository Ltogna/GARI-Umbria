package com.abacogroup.lpisgisserver.core;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.lpisgisserver.core.config.georaster.GeorasterConfig;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.georaster.GenericGeorasterException;
import com.abacogroup.lpisgisserver.core.models.georaster.Georaster3dData;
import com.abacogroup.lpisgisserver.core.models.georaster.GeorasterAuthToken;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.viewer.InfoGis;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class GeorasterClientService extends BaseService {

	private WebTarget geoRasterWT;
	private String env;
	private String auth;
	
	private static final String DEFAULT_LANG_CODE = "en";
	private static final String GET_AUTH_TOKEN_URL = "/api/v1/auth/login";
	private static final String GET_GEORASTER_DATA_URL = "/api/v1/layers/agrea3d/average";

	private Cache<String, String> authTokenCache; //KEY: env|auth

	public GeorasterClientService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService,
			StyleService styleService, PluginEnvironment pluginEnvironment, WebTarget geoRasterWT, GeorasterConfig geoRasterConfig) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.geoRasterWT = geoRasterWT;

		if(geoRasterConfig != null) {
			this.env = geoRasterConfig.getEnv();
			this.auth = geoRasterConfig.getAuth();
		}
		authTokenCache = Caffeine.newBuilder()
				.maximumSize(10)
				.expireAfterWrite(Duration.ofHours(23))
				.build();		
	}

	public InfoGis getGeorasterData(Geometry geom, String srs) {
		
		if(geoRasterWT == null) {
			return null;
		}
		
		GeorasterPayload payload = new GeorasterPayload(geom, srs);

		InfoGis infoGis = InfoGis.builder().build();
		Georaster3dData data = null;
		Response response = null;

		String authtoken = getAuthToken();

		try {
			// POST /georaster/api/v1/layers/agrea3d/average
			if(authtoken == null) {
				response = geoRasterWT
						.path(GET_GEORASTER_DATA_URL)
						.request(MediaType.APPLICATION_JSON_TYPE)
						.accept(MediaType.APPLICATION_JSON_TYPE)
						.header(ACCEPT_LANGUAGE, DEFAULT_LANG_CODE)
						.post(Entity.entity(payload, MediaType.APPLICATION_JSON));
			} else {
				response = geoRasterWT
						.path(GET_GEORASTER_DATA_URL)
						.request(MediaType.APPLICATION_JSON_TYPE)
						.accept(MediaType.APPLICATION_JSON_TYPE)
						.header(ACCEPT_LANGUAGE, DEFAULT_LANG_CODE)
						.header(AUTHORIZATION, String.format("Bearer %s", authtoken))
						.post(Entity.entity(payload, MediaType.APPLICATION_JSON));
			}

			if (response.getStatus() == 200) {
				response.bufferEntity();
				data = response.readEntity(new GenericType<Georaster3dData>() {
				});

				if(data.getValues().size() != 3) {
					GenericGeorasterException ex = new GenericGeorasterException(Status.INTERNAL_SERVER_ERROR,
							Operation.GET_GEORASTER_DATA, ErrorField.GEORASTER_RESPONSE,
							this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

					log.error(ex.getBody().getLogErrorMessage());
					log.debug("Georaster response not valid!!!, {}", data);

					// Prevent exception in wrong response
					infoGis = null;
				} else {
					infoGis.setAverage_altitude(data.getValues().get(0));
					infoGis.setAverage_slope(data.getValues().get(1));
					infoGis.setAverage_direction(data.getValues().get(2));
				}
				
			} else if(response.getStatusInfo().getFamily().equals(Status.Family.CLIENT_ERROR)) {
				infoGis = null;
			} else {
				Map<String, Object> errorResponse = response.readEntity(new GenericType<HashMap<String, Object>>() {
				});
				String errorCode = (String) errorResponse.get("errorCode");
				GenericGeorasterException ex = new GenericGeorasterException(Status.INTERNAL_SERVER_ERROR,
						Operation.GET_GEORASTER_DATA, ErrorField.GEORASTER_RESPONSE,
						this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

				ex.getBody().setMessage(errorCode);
				log.error(ex.getBody().getLogErrorMessage());
				log.debug("Georaster response not valid!!!, {}", errorResponse.toString());
				
				// Prevent exception in wrong response
				infoGis= null;
			}

		} catch (Exception e) {
			GenericGeorasterException ex = new GenericGeorasterException(Status.INTERNAL_SERVER_ERROR,
					Operation.GET_GEORASTER_DATA, ErrorField.GEORASTER_RESPONSE,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());
			log.debug(e.getMessage());
			// Prevent exception in wrong response
			infoGis= null;
			
		} finally {
			if (response != null)
				response.close();
		}

		return infoGis;
	}

	private String getAuthToken() {

		if(env == null || auth == null) {
			return null;
		}

		String key = env + "|" + auth;

		String authToken = authTokenCache.getIfPresent(key);

		if(authToken == null) {
			authToken = loadAuthToken(key);
			if(authToken == null) {
				GenericGeorasterException ex = new GenericGeorasterException(Status.INTERNAL_SERVER_ERROR, Operation.GET_GEORASTER_DATA, ErrorField.AUTHTOKEN,
						this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

				log.error(ex.getBody().getLogErrorMessage());

				// throw ex;
				return null;
			}
		}

		return authToken;
	}

	private String loadAuthToken(String key) {

		if(key == null) {
			return null;
		}

		AuthTokenPayload payload = new AuthTokenPayload(env, auth);

		Response response = null;
		GeorasterAuthToken georasterAuthToken = null;

		// POST /georaster/api/v1/auth/login
		try {
			response =  geoRasterWT
					.path(GET_AUTH_TOKEN_URL)				
					.request(MediaType.APPLICATION_JSON_TYPE)
					.accept(MediaType.APPLICATION_JSON_TYPE)
					.header(ACCEPT_LANGUAGE, DEFAULT_LANG_CODE)
					.post(Entity.entity(payload, MediaType.APPLICATION_JSON));

			if (response.getStatus() == 200) {
				response.bufferEntity();
				georasterAuthToken = response.readEntity(GeorasterAuthToken.class);
				// This method will add all the parcels to the result.
				if(georasterAuthToken != null) {
					authTokenCache.put(key, georasterAuthToken.getToken());
				}
			} else {
				Map<String, Object> errorResponse = response.readEntity(new GenericType<HashMap<String, Object>>() {
				});
				String errorCode = (String) errorResponse.get("errorCode");
				GenericGeorasterException ex = new GenericGeorasterException(Status.INTERNAL_SERVER_ERROR,
						Operation.GET_GEORASTER_DATA, ErrorField.AUTHTOKEN,
						this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

				ex.getBody().setMessage(errorCode);
				log.error(ex.getBody().getLogErrorMessage());

				// throw ex;
				return null;
			}

		} catch (Exception e) {
			GenericGeorasterException ex = new GenericGeorasterException(Status.INTERNAL_SERVER_ERROR,
					Operation.GET_GEORASTER_DATA, ErrorField.AUTHTOKEN,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			// throw ex;
			return null;
		} finally {
			if (response != null)
				response.close();
		}


		return authTokenCache.getIfPresent(key);
	}

	@Data
	@AllArgsConstructor
	private class AuthTokenPayload {
		private String env;
		private String password;
	}

	@Data
	@AllArgsConstructor
	private class GeorasterPayload {
		private Geometry wkt;
		private String srs;
	}
}
