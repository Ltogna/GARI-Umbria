package com.abacogroup.agri.taskmanager.model.dto.io.publics;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TaskInstanceTransitionInDTO {

	@Schema(description = "The workflow scope")
	private String scope;

	@NotEmpty
	@Schema(description = "The tag of the workflow transition to execute")
	private String transitionTag;
	
	@Schema(description = "Transition notes")
	private String notes;
}
