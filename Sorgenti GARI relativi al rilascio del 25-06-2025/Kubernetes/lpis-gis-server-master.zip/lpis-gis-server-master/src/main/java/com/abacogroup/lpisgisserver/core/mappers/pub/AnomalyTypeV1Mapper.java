package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.resources.res.anomalies.AnomalyType;

@Mapper
public interface AnomalyTypeV1Mapper {

	AnomalyTypeV1Mapper INSTANCE = Mappers.getMapper(AnomalyTypeV1Mapper.class);
	
	AnomalyType toResponseV1(AnomalyType entity);

}
