package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.LayerStyleNTT;
import com.abacogroup.lpisgisserver.resources.res.LayerStyle;

public interface LayerStyleMapper {

	LayerStyleMapper INSTANCE = Mappers.getMapper(LayerStyleMapper.class);

	LayerStyle entityToDto(LayerStyleNTT entity);

	LayerStyleNTT dtoToEntity(LayerStyle dto);

}
