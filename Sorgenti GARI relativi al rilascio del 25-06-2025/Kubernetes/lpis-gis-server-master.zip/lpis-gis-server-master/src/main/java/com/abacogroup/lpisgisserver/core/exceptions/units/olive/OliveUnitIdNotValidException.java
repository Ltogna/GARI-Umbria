package com.abacogroup.lpisgisserver.core.exceptions.units.olive;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class OliveUnitIdNotValidException extends AbstractException {

	private static final long serialVersionUID = -6467378631448203591L;

	private static final ErrorCode ERROR_CODE = ErrorCode.OLIVE_UNIT_ID_NOT_VALID;

	public OliveUnitIdNotValidException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new OliveUnitIdNotValidExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Olive unit id not valid")
	public static class OliveUnitIdNotValidExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 3853099588145979239L;

		public OliveUnitIdNotValidExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
