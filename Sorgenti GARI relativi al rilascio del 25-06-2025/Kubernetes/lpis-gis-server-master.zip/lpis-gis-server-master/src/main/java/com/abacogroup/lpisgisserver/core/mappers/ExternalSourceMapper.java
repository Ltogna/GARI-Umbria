package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.ExternalSourceNTT;
import com.abacogroup.lpisgisserver.resources.res.ExternalSource;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ExternalSourceMapper {
	ExternalSourceMapper INSTANCE = Mappers.getMapper(ExternalSourceMapper.class);

	@InheritInverseConfiguration()
	ExternalSource entityToDto(ExternalSourceNTT entity);

	ExternalSourceNTT dtoToEntity(ExternalSource dto);
}
