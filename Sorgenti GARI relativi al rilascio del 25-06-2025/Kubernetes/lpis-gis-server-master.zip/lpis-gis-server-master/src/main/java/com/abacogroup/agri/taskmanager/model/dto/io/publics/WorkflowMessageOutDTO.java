package com.abacogroup.agri.taskmanager.model.dto.io.publics;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * XXX TO BE IMPORTED FROM TASKMANAGER CLI WHEN AVAILABLE...
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class WorkflowMessageOutDTO {

	@Schema(description = "Code")
	private String code;
	@Schema(description = "Description")
	private String description;
	@Schema(description = "Indicates if the operation is successful or not")
	private boolean success;
}
