package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.ProductDestinationNTT;
import com.abacogroup.lpisgisserver.resources.res.units.ProductDestination;

@Mapper
public interface ProductDestinationMapper {

	ProductDestinationMapper INSTANCE = Mappers.getMapper(ProductDestinationMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	ProductDestination entityToDto(ProductDestinationNTT entity);
	
	@Mapping(target = "flVisible", expression = "java(dto.getVisible() ? 1 : 0)")
	@Mapping(target = "typeCode", ignore = true)
	ProductDestinationNTT dtoToEntity(ProductDestination dto);
}
