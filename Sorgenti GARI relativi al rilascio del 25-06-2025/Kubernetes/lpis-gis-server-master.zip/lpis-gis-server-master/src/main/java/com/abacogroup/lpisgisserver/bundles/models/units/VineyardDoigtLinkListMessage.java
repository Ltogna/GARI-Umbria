package com.abacogroup.lpisgisserver.bundles.models.units;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VineyardDoigtLinkListMessage {
	List<VineyardDoigtLinkMessage> vineyard_doigt_links;
}
