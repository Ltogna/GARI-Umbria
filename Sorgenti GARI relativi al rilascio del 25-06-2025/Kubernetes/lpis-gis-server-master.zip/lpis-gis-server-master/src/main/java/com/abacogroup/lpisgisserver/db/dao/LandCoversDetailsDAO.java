package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface LandCoversDetailsDAO extends Transactional<LandCoversDetailsDAO>, EnhancedSqlObject {

	@SqlQuery("§select_nextval(lpis_parcel_lc_details_sequence)§")
	Long nextSequenceVal();

	@SqlUpdate("INSERT INTO lpis_parcel_lc_details (pkid, land_cover_id, day_from, day_to, srs, area_sqm, land_cover_code, user_id_insert, user_id_delete, dt_insert, dt_delete, geom, world_geom, edit_status) "
			 + "VALUES(:land_cover_details_id, :land_cover_id, :day_from, :day_to, " 
			 + "       :srs, :area_sqm, :land_cover_code, " 
			 + "       :user_id_insert, NULL, "
			 + "       §current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), "
			+ "       :geom, :world_geom, :edit_status)")
	void insert(@BindBean LandCoverNTT rs, @Bind("user_id_insert") String userId);

	@SqlQuery("SELECT pkid as land_cover_details_id,"
			+ "       land_cover_id,"
			+ "       day_from,"
			+ "       day_to,"
			+ "       srs,"
			+ "       area_sqm,"
			+ "       land_cover_code,"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', land_cover_code, :lang)§, land_cover_code) as land_cover_description,  "
			+ "       geom,"
			+ "       world_geom,"
			+ "       edit_status"
			+ "  FROM lpis_parcel_lc_details"
			+ " WHERE pkid = :land_cover_details_id"
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(LandCoverNTT.class)
	List<LandCoverNTT> findById(@BindBean ServiceSupportEnv env, @Bind("pkid") Long pkid);

	@SqlQuery("SELECT pkid as land_cover_details_id,"
			+ "       land_cover_id,"
			+ "       day_from,"
			+ "       day_to,"
			+ "       srs,"
			+ "       area_sqm,"
			+ "       land_cover_code,"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', land_cover_code, :lang)§, land_cover_code as land_cover_description,  "
			+ "       geom,"
			+ "       world_geom, "
			+ "       edit_status"
			+ "  FROM lpis_parcel_lc_details "
			+ " WHERE land_cover_id = :land_cover_id "
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(LandCoverNTT.class)
	List<LandCoverNTT> findByLandCoverId(@BindBean ServiceSupportEnv env, @Bind("land_cover_id") Long pkid);

	@SqlUpdate("update lpis_parcel_lc_details \n"
			+ "    set user_id_delete = :user_id_delete, \n"
			+ "        dt_delete = §current_timestamp§ \n" 
			 + " where pkid = :land_cover_details_pkid \n" 
			 + "   and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteByLandCoverDetailsId(@Bind("land_cover_details_pkid") Long landCoverDetailsId, @Bind("user_id_delete") String userDelete);

}
