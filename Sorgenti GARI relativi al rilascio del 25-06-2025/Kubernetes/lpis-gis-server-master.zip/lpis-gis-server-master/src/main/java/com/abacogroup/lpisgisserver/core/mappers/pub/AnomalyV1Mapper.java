package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.resources.res.anomalies.Anomaly;
import com.abacogroup.lpisgisserver.resources.res.pub.anomalies.AnomalyV1;

@Mapper(uses = {AnomalyTypeV1Mapper.class} )
public interface AnomalyV1Mapper {

	AnomalyV1Mapper INSTANCE = Mappers.getMapper(AnomalyV1Mapper.class);
	
	AnomalyV1 toResponseV1(Anomaly entity);

}
