package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidSessionEmptyParcelException extends AbstractException {

	private static final long serialVersionUID = -6397389533741617907L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_SESSION_EMPTY_PARCEL;

	public InvalidSessionEmptyParcelException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new InvalidSessionEmptyParcelExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Invalid session, Draw a parcel or exit")
	public static class InvalidSessionEmptyParcelExceptionBody extends AbstractExceptionBody {

		private static final long serialVersionUID = 2290831333471237748L;

		public InvalidSessionEmptyParcelExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
