package com.abacogroup.lpisgisserver.core.exceptions.matrix;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class MatrixCodeNotValidException extends AbstractException {

	private static final long serialVersionUID = 7956476251850424722L;

	private static final ErrorCode ERROR_CODE = ErrorCode.MATRIX_CODE_NOT_VALID;

	public MatrixCodeNotValidException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new MatrixCodeNotValidExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Matrix code not valid")
	public static class MatrixCodeNotValidExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -1383894192001781047L;

		public MatrixCodeNotValidExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
