package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.lpisgisserver.db.ntt.ConfigNTT;

public interface ConfigDAO extends Transactional<ConfigDAO>, EnhancedSqlObject {

	@SqlUpdate("insert into lpis_config (tenant_id, key, value, fl_client, name) values(:tenantId, :key, :value, :fl_client, :name)")
	void insert(@BindBean ConfigNTT config);

	@SqlUpdate("update lpis_config set value = :value, fl_client = :fl_client, name = :name where tenant_id = :tenantId and key = :key")
	void updateValue(@BindBean ConfigNTT config);

	@SqlUpdate("delete from lpis_config where tenant_id = :tenantId and key = :key")
	void deleteByTenantAndKey(@Bind("tenantId") String tenantId, @Bind("key") String key);

	@SqlQuery("\n"
			+ "select tenant_id as tenantId, \n"
			+ "       key, \n"
			+ "       value, \n"
			+ "       fl_client, \n"
			+ "       name \n"
			+ "  from lpis_config \n"
			+ " where tenant_id = :tenantId \n"
			+ " and key = :key \n")
	@RegisterBeanMapper(ConfigNTT.class)
	ConfigNTT getConfigByTenantAndKey(@Bind("tenantId") String tenantId, @Bind("key") String key);

	@SqlQuery("\n"
			+ "select tenant_id as tenantId, \n"
			+ "       key, \n"
			+ "       value, \n"
			+ "       fl_client, \n"
			+ "       name \n"
			+ "  from lpis_config \n"
			+ " where tenant_id = :tenantId \n")
	@RegisterBeanMapper(ConfigNTT.class)
	List<ConfigNTT> getConfigByTenant(@Bind("tenantId") String tenantId);

	@SqlQuery("\n"
			+ "select tenant_id as tenantId, \n"
			+ "       key, \n"
			+ "       value, \n"
			+ "       fl_client, \n"
			+ "       name \n"
			+ "  from lpis_config \n"
			+ " where tenant_id = :tenantId \n"
			+ "   and key like 'plugin$_%' escape '$' \n")
	@RegisterBeanMapper(ConfigNTT.class)
	List<ConfigNTT> getPluginConfigsByTenant(@Bind("tenantId") String tenantId);
	
	@SqlQuery("\n"
			+ "select tenant_id as tenantId, \n"
			+ "       key, \n"
			+ "       value, \n"
			+ "       fl_client, \n"
			+ "       name \n"
			+ "  from lpis_config \n"
			+ " where tenant_id = :tenantId \n"
			+ "   and key like 'ui$_%' escape '$' \n")
	@RegisterBeanMapper(ConfigNTT.class)
	List<ConfigNTT> getUIConfigsByTenant(@Bind("tenantId") String tenantId);

	@SqlQuery("select distinct tenant_id from lpis_config")
	List<String> getAllTenants();
}
