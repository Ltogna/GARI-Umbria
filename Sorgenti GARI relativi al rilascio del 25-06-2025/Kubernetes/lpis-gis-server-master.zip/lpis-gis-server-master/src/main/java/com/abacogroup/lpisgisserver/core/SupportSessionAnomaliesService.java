package com.abacogroup.lpisgisserver.core;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.DatePrecision;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.LandCoverConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.SessionCheck;
import com.abacogroup.lpisgisserver.core.enums.SessionErrorLevel;
import com.abacogroup.lpisgisserver.core.enums.SoftwareModule;
import com.abacogroup.lpisgisserver.core.enums.SoftwareModuleView;
import com.abacogroup.lpisgisserver.core.enums.UnitDictionaryTables;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidEditSessionException;
import com.abacogroup.lpisgisserver.core.exceptions.units.UnitCodeNotValidException;
import com.abacogroup.lpisgisserver.core.mappers.LandCoversMapper;
import com.abacogroup.lpisgisserver.core.mappers.ParcelsMapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.UnitsWithDictionaryCodesPayloadV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.units.FruitUnitMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.OliveUnitMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.VineAptitudesMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.VineUnitMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditFruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.EditLandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.EditOliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.EditParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.EditVineUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoverConfigsDAO;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.dao.UnitCodesDAO;
import com.abacogroup.lpisgisserver.db.dao.UnitsDAO;
import com.abacogroup.lpisgisserver.db.ntt.AdditionalExternalLinkNTT;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.fruit.FruitUnitDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.OliveUnitDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineAptitudeNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineUnitDetailsNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.plugins.PluginConstants;
import com.abacogroup.lpisgisserver.plugins.models.CheckUniqueUnitCodePluginModel;
import com.abacogroup.lpisgisserver.resources.req.pub.bulk.UnitsWithDictionaryCodesPayloadV1;
import com.abacogroup.lpisgisserver.resources.res.EditError;
import com.abacogroup.lpisgisserver.resources.res.ErrorRelatedLink;
import com.abacogroup.lpisgisserver.resources.res.LandCoverWithErrors;
import com.abacogroup.lpisgisserver.resources.res.ParcelWithErrors;
import com.abacogroup.lpisgisserver.resources.res.SessionCheckResult;
import com.abacogroup.lpisgisserver.resources.res.units.fruit.FruitUnitWithErrors;
import com.abacogroup.lpisgisserver.resources.res.units.olive.OliveUnitWithErrors;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineAptitudeWithErrors;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnitWithErrors;
import com.abacogroup.lpisgisserver.sdk.SdkUnitCode;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;
import com.google.common.base.Objects;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SupportSessionAnomaliesService extends BaseService {

	private final EditParcelsDAO editParcelsDAO;
	private final EditLandCoversDAO editLandCoversDAO;
	private final EditVineUnitsDAO editVineUnitsDAO;
	private final EditOliveUnitsDAO editOliveUnitsDAO;
	private final EditFruitUnitsDAO editFruitUnitsDAO;
	private final LandCoverConfigsDAO landCoverConfigsDAO;
	private final UnitsDAO unitsDAO;
	private final UnitCodesDAO unitCodesDAO;
	private final SupportDAO supportDAO;

	private final List<SessionCheck> parcelErrorChecks;
	private final List<SessionCheck> landCoverErrorChecks;
	private final List<SessionCheck> vineUnitsErrorChecks;
	private final List<SessionCheck> vineAptitudesErrorChecks;
	private final List<SessionCheck> oliveUnitsErrorChecks;
	private final List<SessionCheck> fruitUnitsErrorChecks;

	private final UnitsSupportService unitsSupportService;
	
	private static final DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE;
	private static final AbsoluteDate INFINITE = AbsoluteDate.of("99991231");
	private static final SoftwareModule MODULE = SoftwareModule.LPIS_EDITOR;
	private static final SoftwareModuleView VIEW = SoftwareModuleView.UNITS;
	private static final String UNIT_TYPE_NOT_IMPLEMENTED_MESSAGE = "check '%s' unit type not implemented";
	
	// excluded edit status in parcel checks
	private List<EditStatus> excludesStatus;
	
	private LoadingCache<String, Map<String, List<AdditionalExternalLinkNTT>>> additionalExternalLinkCache; //key: tenant|lang

	private final String serverApplicationContextPath;

	public SupportSessionAnomaliesService(DAOContainer dc, InternalConfigService internalConf, ExternalConfigService externalConf, 
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, UnitsSupportService unitsSupportService,
			PluginEnvironment pluginEnvironment, String serverApplicationContextPath) {
		super(dc, internalConf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.editParcelsDAO = dc.getEditParcelsDAO();
		this.editLandCoversDAO = dc.getEditLandCoversDAO();
		this.editVineUnitsDAO = dc.getEditVineUnitsDAO();
		this.editOliveUnitsDAO = dc.getEditOliveUnitsDAO();
		this.editFruitUnitsDAO = dc.getEditFruitUnitsDAO();
		this.landCoverConfigsDAO = dc.getLandCoverConfigsDAO();
		this.unitsDAO = dc.getUnitsDAO();
		this.unitCodesDAO = dc.getUnitCodesDAO();
		this.supportDAO = dc.getSupportDAO();

		this.unitsSupportService = unitsSupportService;
		
		parcelErrorChecks = new ArrayList<>();
		landCoverErrorChecks = new ArrayList<>();
		vineUnitsErrorChecks = new ArrayList<>();
		vineAptitudesErrorChecks = new ArrayList<>();
		oliveUnitsErrorChecks = new ArrayList<>();
		fruitUnitsErrorChecks = new ArrayList<>();
		
		// Default excluded edit status in parcel checks, to be moved in configuration
		excludesStatus = Arrays.asList(EditStatus.TOPOLOGY_CORRECTED);
		
		loadErrorChecksConfiguration();
		
		additionalExternalLinkCache = Caffeine.newBuilder()
				.maximumSize(1000)
				.expireAfterWrite(Duration.ofMinutes(60))
				.build(this::loadAdditionalExternalLink);
		
		this.serverApplicationContextPath = serverApplicationContextPath;
	}


	private void loadErrorChecksConfiguration() {
		loadParcelErrorChecksConfiguration();
		loadLandCoverErrorChecksConfiguration();
		loadVineUnitsErrorChecksConfiguration();
		loadVineAptitudeErrorChecksConfiguration();
		loadOliveUnitsErrorChecksConfiguration();
		loadFruitUnitsErrorChecksConfiguration();
	}

	private void loadParcelErrorChecksConfiguration() {
		// XXX In the future release should loaded from configuration
		parcelErrorChecks.add(SessionCheck.PARCEL_NAME);
		parcelErrorChecks.add(SessionCheck.PARCEL_EXTERNAL_CODE);
		parcelErrorChecks.add(SessionCheck.PARCEL_AREA);
		parcelErrorChecks.add(SessionCheck.TOTAL_LANDCOVER_AREA);
		parcelErrorChecks.add(SessionCheck.PARCEL_LANDCOVER_ONE_TO_ONE_CHECK);
		
		// conditional on tenant configuration
		parcelErrorChecks.add(SessionCheck.PARCEL_FULL_LANDCOVERS_COVERED);
		
	}

	private void loadLandCoverErrorChecksConfiguration() {
		// XXX In the future release should loaded from configuration
		landCoverErrorChecks.add(SessionCheck.LANDCOVER_AREA);  
		landCoverErrorChecks.add(SessionCheck.LANDCOVER_CONFIG_SAVE_FORBIDDEN);
		landCoverErrorChecks.add(SessionCheck.LANDCOVER_CONFIG_EDIT_FORBIDDEN);
	}
	
	private void loadVineUnitsErrorChecksConfiguration() {
		// XXX In the future release should loaded from configuration 
		vineUnitsErrorChecks.add(SessionCheck.MANDATORY_UNIT); 
		vineUnitsErrorChecks.add(SessionCheck.UNIT_MANDATORY_FIELDS); 
		vineUnitsErrorChecks.add(SessionCheck.UNIT_FULL_COVER_AREA); 
		vineUnitsErrorChecks.add(SessionCheck.UNIT_AREA_CAN_OVERSIZE_LANDCOVER); 
		vineUnitsErrorChecks.add(SessionCheck.UNIT_DATES);
		vineUnitsErrorChecks.add(SessionCheck.UNIQUE_UNIT_CODE);
		vineUnitsErrorChecks.add(SessionCheck.VINE_APTITUDES);		
	}
	
	private void loadVineAptitudeErrorChecksConfiguration() {
		vineAptitudesErrorChecks.add(SessionCheck.CODE);
		vineAptitudesErrorChecks.add(SessionCheck.VINE_APTITUDE_DATES);
	}
	
	private void loadOliveUnitsErrorChecksConfiguration() {
		// XXX In the future release should loaded from configuration 
		oliveUnitsErrorChecks.add(SessionCheck.MANDATORY_UNIT); 
		oliveUnitsErrorChecks.add(SessionCheck.UNIT_MANDATORY_FIELDS); 
		oliveUnitsErrorChecks.add(SessionCheck.UNIT_FULL_COVER_AREA); 
		oliveUnitsErrorChecks.add(SessionCheck.UNIT_AREA_CAN_OVERSIZE_LANDCOVER); 
		oliveUnitsErrorChecks.add(SessionCheck.UNIQUE_UNIT_CODE);
		oliveUnitsErrorChecks.add(SessionCheck.UNIT_DATES);		
	}
	
	private void loadFruitUnitsErrorChecksConfiguration() {
		// XXX In the future release should loaded from configuration 
		fruitUnitsErrorChecks.add(SessionCheck.MANDATORY_UNIT); 
		fruitUnitsErrorChecks.add(SessionCheck.UNIT_MANDATORY_FIELDS); 
		fruitUnitsErrorChecks.add(SessionCheck.UNIT_FULL_COVER_AREA); 
		fruitUnitsErrorChecks.add(SessionCheck.UNIT_AREA_CAN_OVERSIZE_LANDCOVER); 
		fruitUnitsErrorChecks.add(SessionCheck.UNIQUE_UNIT_CODE);
		fruitUnitsErrorChecks.add(SessionCheck.UNIT_DATES);		
	}

	public SessionCheckResult getSessionErrors(ServiceSupportEnv env, List<ParcelNTT> inEditParcels) {
		if (env == null || env.getSessionId() == null) {
			String tenantId = env != null ? env.getTenantId() : StringUtils.EMPTY;
			String lang = env != null ? env.getLang() : DEFAULT_LANG_CODE;

			InvalidEditSessionException ex = new InvalidEditSessionException(Status.BAD_REQUEST,
					Operation.SAVE_SESSION, ErrorField.SESSION,
					this.errorDescriptionsService.getTenantErrorDescriptions(tenantId), lang);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		// XXX? add here session checks?

		if (inEditParcels == null)
			inEditParcels = new ArrayList<>();
		
		SessionCheckResult result = SessionCheckResult.builder().build();

		inEditParcels.stream()
		.filter(p -> !excludesStatus.contains(p.getEdit_status()))
		.forEach(p -> {
			ParcelWithErrors parcel = ParcelsMapper.INSTANCE.entityToDtoWithErrors(p);
			checkParcelErrors(env, parcel, excludesStatus);

			if(!parcel.getErrorList().isEmpty() || !parcel.getLandCovers().isEmpty()) {
				result.getParcels().add(parcel);
			}

		});

		return result;
	}

	public void checkParcelErrors(ServiceSupportEnv env, ParcelWithErrors parcel, List<EditStatus> excludesStatus) {

		// It should never exists!
		if(parcelErrorChecks == null) {
			return;
		}
		
		boolean haveMustCoverFlag = internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FLAG_MUST_COVER_ALL_LANDCOVER_KEY);
		boolean hideLandCoverLayer = internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_HIDE_LANDCOVERS_LAYER);

		parcelErrorChecks.forEach(check -> {
			if (SessionCheck.PARCEL_NAME.equals(check)) {
				checkWrongParcelName(env, parcel.getId(), parcel.getErrorList());
			} else if (SessionCheck.PARCEL_EXTERNAL_CODE.equals(check) && parcel.getExternal_code() != null) {
				checkWrongParcelExternalCode(env, parcel.getId(), parcel.getExternal_code(), parcel.getErrorList());
			} else if (SessionCheck.PARCEL_AREA.equals(check)) {
				checkWrongAreaParcel(env, parcel.getId(), excludesStatus, parcel.getErrorList());
			} else if (haveMustCoverFlag && !hideLandCoverLayer && SessionCheck.TOTAL_LANDCOVER_AREA.equals(check)) {
				checkTotalLandCoverArea(env, parcel);
			} else if (haveMustCoverFlag && SessionCheck.PARCEL_FULL_LANDCOVERS_COVERED.equals(check)) {
				checkParcellFullLandcoverCovered(env, parcel);
			} else if (SessionCheck.PARCEL_LANDCOVER_ONE_TO_ONE_CHECK.equals(check)) {
				checkOneToOneConfig(env, parcel);
			}
		});

		List<LandCoverNTT> inEditLandCovers = editLandCoversDAO.findInEditBySessionId(env, parcel.getId());
		inEditLandCovers.addAll(editLandCoversDAO.findNotInEditBySessionId(env, parcel.getId()));
		
		inEditLandCovers.stream()
			.filter(l -> l.getGeom() != null) // deleted landcover should not be checked...
			.forEach(lc -> {
				LandCoverWithErrors landCover = LandCoversMapper.INSTANCE.entityToDtoWithErrors(lc);
				checkLandCoverErrors(env, landCover, excludesStatus);
	
				if(!landCover.getErrorList().isEmpty() || !landCover.getVineUnits().isEmpty() || 
						!landCover.getOliveUnits().isEmpty() || !landCover.getFruitUnits().isEmpty()) {
					parcel.getLandCovers().add(landCover);
				}
			});

	}


	private void checkLandCoverErrors(ServiceSupportEnv env, LandCoverWithErrors landCover, List<EditStatus> excludesStatus) {
		// It should never exists!
		if(landCoverErrorChecks == null) {
			return;
		}

		landCoverErrorChecks.forEach(check -> {
			if (SessionCheck.LANDCOVER_AREA.equals(check)) {
				checkWrongLandCoverArea(env, landCover.getParcel_id(), landCover.getId(), excludesStatus, landCover.getErrorList());
			} else if (SessionCheck.LANDCOVER_CONFIG_SAVE_FORBIDDEN.equals(check)) {
				checkLandCoverConfigCanSave(env, landCover);
			} else if (SessionCheck.LANDCOVER_CONFIG_EDIT_FORBIDDEN.equals(check)) {
				checkLandCoverConfigCanEdit(env, landCover);
			}
		});
		
		List<UnitType> compatibleUnitTypes = unitsDAO.findLandCoverUnitsCompatibility(env, landCover.getCode());
		
		checkIncompatibleUnits(env, compatibleUnitTypes, landCover);
		
		compatibleUnitTypes.stream().forEach(ut -> {
			if(ut == UnitType.VINE_UNIT) {
				checkVineUnits(env, ut, landCover);
			} else if(ut == UnitType.OLIVE_UNIT) {
				checkOliveUnits(env, ut, landCover);
			} else if(ut == UnitType.FRUIT_UNIT) {
				checkFruitUnits(env, ut, landCover);
			} else {
				throw new UnsupportedOperationException(String.format(UNIT_TYPE_NOT_IMPLEMENTED_MESSAGE, ut.name()));
			}
		});		
	}

	private void checkIncompatibleUnits(ServiceSupportEnv env, List<UnitType> compatibleUnitTypes, LandCoverWithErrors landCover) {
		Arrays.asList(UnitType.values()).stream()
		.filter(type -> !compatibleUnitTypes.contains(type))
		.forEach(t -> {
			if(t == UnitType.VINE_UNIT) {
				if(!getValidVineUnits(env, landCover).isEmpty()) {
					landCover.getErrorList().add(getEditError(env, ErrorCode.UNIT_TYPE_NOT_COMPATIBLE, t.name(), SessionErrorLevel.DANGER));
				}
			} else if(t == UnitType.OLIVE_UNIT) {
				if(!getValidOliveUnits(env, landCover).isEmpty()) {
					landCover.getErrorList().add(getEditError(env, ErrorCode.UNIT_TYPE_NOT_COMPATIBLE, t.name(), SessionErrorLevel.DANGER));
				}
			} else if(t == UnitType.FRUIT_UNIT) {
				if(!getValidFruitUnits(env, landCover).isEmpty()) {
					landCover.getErrorList().add(getEditError(env, ErrorCode.UNIT_TYPE_NOT_COMPATIBLE, t.name(), SessionErrorLevel.DANGER));
				}
			} else {
				throw new UnsupportedOperationException(String.format(UNIT_TYPE_NOT_IMPLEMENTED_MESSAGE, t.name()));
			}
		});
	}

	private void checkVineUnits(ServiceSupportEnv env, UnitType ut, LandCoverWithErrors landCover) {
		
		// It should never exists!
		if(vineUnitsErrorChecks == null) {
			return;
		}
		
		List<VineUnitDetailsNTT> vineUnits = getAllVineUnits(env, landCover);
		
		// If vine unit is set as manadato on landcover check if present
		if(vineUnitsErrorChecks.contains(SessionCheck.MANDATORY_UNIT) &&  ut.isMandatory() && getValidVineUnits(env, landCover).isEmpty()) { // XXX ma un landcover è valido anche se ha solo unità vitate scadute?
			landCover.getErrorList().add(getEditError(env, ErrorCode.MANDATORY_UNIT_TYPE_NOT_FOUND, ut.name(), SessionErrorLevel.DANGER));
		}
		
		// if the landcover must be full covered
		if(vineUnitsErrorChecks.contains(SessionCheck.UNIT_FULL_COVER_AREA) &&  ut.isFullCoverMandatory()) {
			checkTotalUnitsAreaTooSmall(env, ut, landCover);
		}
		
		// if vine units area can oversize landcover
		if(vineUnitsErrorChecks.contains(SessionCheck.UNIT_AREA_CAN_OVERSIZE_LANDCOVER)) { // ?? unittype can oversize landcover
			checkTotalUnitsAreaTooLarge(env, ut, landCover);
		}
				
		vineUnits.stream().forEach(unit -> checkVineUnit(env, landCover, unit));
	}

	private void checkVineUnit(ServiceSupportEnv env, LandCoverWithErrors landCover, VineUnitDetailsNTT unit) {
		VineUnitWithErrors vineUnit = VineUnitMapper.INSTANCE.entityToDtoWithErrors(unit);

		vineUnitsErrorChecks.forEach(check -> {
			if (SessionCheck.UNIT_DATES.equals(check)) {
				checkUnitDates(env, landCover, vineUnit.getPlantingDay(), vineUnit.getPlantingDayPrecision(), vineUnit.getEradicateDay(), vineUnit.getErrorList());
			} else if (SessionCheck.UNIT_MANDATORY_FIELDS.equals(check)) {
				Map<UnitDictionaryTables, ErrorCode> checkMap = getVineUnitCodesCheckMap();
				UnitsWithDictionaryCodesPayloadV1 dictionaryCodes = UnitsWithDictionaryCodesPayloadV1Mapper.INSTANCE.toResponseV1(vineUnit);
				checkMap.forEach((t, e) -> searchUnitsCodeOrPutError(env, UnitType.VINE_UNIT, vineUnit.getMandatoryDictionayTable(), dictionaryCodes, t, e, vineUnit.getErrorList()));
			} else if (SessionCheck.VINE_APTITUDES.equals(check)) {
				//For each vine aptitude check for error
					List<VineAptitudeNTT> inEditVineAptitudes = editVineUnitsDAO.findInEditVineAptitudesBySessionId(env, vineUnit.getId(), null, 1, null);
					inEditVineAptitudes.stream().forEach(aptitudes -> {
						VineAptitudeWithErrors vineAptitude = VineAptitudesMapper.INSTANCE.entityToDtoWithErrors(aptitudes);
						checkVineAptitudesErrors(env, unit, vineAptitude);

						if(!vineAptitude.getErrorList().isEmpty()) {
							vineUnit.getVineAptitudes().add(vineAptitude);
						}
					}); 
			 } else if (SessionCheck.UNIQUE_UNIT_CODE.equals(check) ) {
				 checkIfUniqueVineUnitCode(env, landCover, vineUnit);
			 }
		});
		
		// if vine unit has some error add it to the list
		if (!vineUnit.getErrorList().isEmpty() || !vineUnit.getVineAptitudes().isEmpty()) {
			landCover.getVineUnits().add(vineUnit);
		}
	}
	
	private void checkIfUniqueVineUnitCode(ServiceSupportEnv env, LandCoverWithErrors landCover, VineUnitWithErrors vineUnit) {
		EditError editError = checkIfUniqueUnitCode(env, landCover.getParcel_id(), landCover.getId(), vineUnit.getId(), vineUnit.getCode(), UnitType.VINE_UNIT);
		if (editError != null) {
			vineUnit.getErrorList().add(editError);
		}
	}
	
	private void checkOliveUnits(ServiceSupportEnv env, UnitType ut, LandCoverWithErrors landCover) {
		
		// It should never exists!
		if(oliveUnitsErrorChecks == null) {
			return;
		}
		
		// If olive unit is set as manadato on landcover check if present
		if(oliveUnitsErrorChecks.contains(SessionCheck.MANDATORY_UNIT) &&  ut.isMandatory() && getValidOliveUnits(env, landCover).isEmpty()) { // XXX ma un landcover è valido anche se ha solo unità vitate scadute?
			landCover.getErrorList().add(getEditError(env, ErrorCode.MANDATORY_UNIT_TYPE_NOT_FOUND, ut.name(), SessionErrorLevel.DANGER));
		}
		
		// if the landcover must be full covered
		if(oliveUnitsErrorChecks.contains(SessionCheck.UNIT_FULL_COVER_AREA) &&  ut.isFullCoverMandatory()) {
			checkTotalUnitsAreaTooSmall(env, ut, landCover);
		}
		
		// if olive units area can oversize landcover
		if(oliveUnitsErrorChecks.contains(SessionCheck.UNIT_AREA_CAN_OVERSIZE_LANDCOVER)) { // ?? unittype can oversize landcover
			checkTotalUnitsAreaTooLarge(env, ut, landCover);
		}
				
		List<OliveUnitDetailsNTT> oliveUnits = getAllOliveUnits(env, landCover);
		oliveUnits.stream().forEach(unit -> checkOliveUnit(env, landCover, unit));
	}
	
	private void checkOliveUnit(ServiceSupportEnv env, LandCoverWithErrors landCover, OliveUnitDetailsNTT unit) {
		OliveUnitWithErrors oliveUnit = OliveUnitMapper.INSTANCE.entityToDtoWithErrors(unit);

		oliveUnitsErrorChecks.forEach(check -> {
			if (SessionCheck.UNIT_DATES.equals(check)) {
				checkUnitDates(env, landCover, oliveUnit.getPlantingDay(), oliveUnit.getPlantingDayPrecision(), oliveUnit.getEradicateDay(), oliveUnit.getErrorList());
			} else if (SessionCheck.UNIT_MANDATORY_FIELDS.equals(check)) {
				Map<UnitDictionaryTables, ErrorCode> checkMap = getVineUnitCodesCheckMap();
				UnitsWithDictionaryCodesPayloadV1 dictionaryCodes = UnitsWithDictionaryCodesPayloadV1Mapper.INSTANCE.toResponseV1(oliveUnit);
				checkMap.forEach((t, e) -> searchUnitsCodeOrPutError(env, UnitType.OLIVE_UNIT, oliveUnit.getMandatoryDictionayTable(), dictionaryCodes, t, e, oliveUnit.getErrorList()));
			} else if (SessionCheck.UNIQUE_UNIT_CODE.equals(check)) {
				 checkIfUniqueOliveUnitCode(env, landCover, oliveUnit);
			 }
		});
		
		// if vine unit has some error add it to the list
		if (!oliveUnit.getErrorList().isEmpty()) {
			landCover.getOliveUnits().add(oliveUnit);
		}
	}
	
	private void checkIfUniqueOliveUnitCode(ServiceSupportEnv env, LandCoverWithErrors landCover, OliveUnitWithErrors oliveUnit) {
		EditError editError = checkIfUniqueUnitCode(env, landCover.getParcel_id(), landCover.getId(), oliveUnit.getId(), oliveUnit.getCode(), UnitType.OLIVE_UNIT);
		if (editError != null) {
			oliveUnit.getErrorList().add(editError);
		}
	}
	
	private void checkFruitUnits(ServiceSupportEnv env, UnitType ut, LandCoverWithErrors landCover) {
		
		// It should never exists!
		if(fruitUnitsErrorChecks == null) {
			return;
		}
		
		// If fruit unit is set as manadato on landcover check if present
		if(fruitUnitsErrorChecks.contains(SessionCheck.MANDATORY_UNIT) &&  ut.isMandatory() && getValidFruitUnits(env, landCover).isEmpty()) { // XXX ma un landcover è valido anche se ha solo unità vitate scadute?
			landCover.getErrorList().add(getEditError(env, ErrorCode.MANDATORY_UNIT_TYPE_NOT_FOUND, ut.name(), SessionErrorLevel.DANGER));
		}
		
		// if the landcover must be full covered
		if(fruitUnitsErrorChecks.contains(SessionCheck.UNIT_FULL_COVER_AREA) &&  ut.isFullCoverMandatory()) {
			checkTotalUnitsAreaTooSmall(env, ut, landCover);
		}
		
		// if fruit units area can oversize landcover
		if(fruitUnitsErrorChecks.contains(SessionCheck.UNIT_AREA_CAN_OVERSIZE_LANDCOVER)) { // ?? unittype can oversize landcover
			checkTotalUnitsAreaTooLarge(env, ut, landCover);
		}
		
		List<FruitUnitDetailsNTT> fruitUnits = getAllFruitUnits(env, landCover);
		fruitUnits.stream().forEach(unit -> checkFruitUnit(env, landCover, unit));
	}
	
	private void checkFruitUnit(ServiceSupportEnv env, LandCoverWithErrors landCover, FruitUnitDetailsNTT unit) {
		FruitUnitWithErrors fruitUnit = FruitUnitMapper.INSTANCE.entityToDtoWithErrors(unit);
		
		fruitUnitsErrorChecks.forEach(check -> {
			if (SessionCheck.UNIT_DATES.equals(check)) {
				checkUnitDates(env, landCover, fruitUnit.getPlantingDay(), fruitUnit.getPlantingDayPrecision(), fruitUnit.getEradicateDay(), fruitUnit.getErrorList());
			} else if (SessionCheck.UNIT_MANDATORY_FIELDS.equals(check)) {
				Map<UnitDictionaryTables, ErrorCode> checkMap = getVineUnitCodesCheckMap();
				UnitsWithDictionaryCodesPayloadV1 dictionaryCodes = UnitsWithDictionaryCodesPayloadV1Mapper.INSTANCE.toResponseV1(fruitUnit);
				checkMap.forEach((t, e) -> searchUnitsCodeOrPutError(env, UnitType.FRUIT_UNIT, fruitUnit.getMandatoryDictionayTable(), dictionaryCodes, t, e, fruitUnit.getErrorList()));
			} else if (SessionCheck.UNIQUE_UNIT_CODE.equals(check)) {
				 checkIfUniqueFruitUnitCode(env, landCover, fruitUnit);
			 }
		});
		
		// if vine unit has some error add it to the list
		if (!fruitUnit.getErrorList().isEmpty()) {
			landCover.getFruitUnits().add(fruitUnit);
		}
	}
	
	private void checkIfUniqueFruitUnitCode(ServiceSupportEnv env, LandCoverWithErrors landCover, FruitUnitWithErrors fruitUnit) {
		EditError editError = checkIfUniqueUnitCode(env, landCover.getParcel_id(), landCover.getId(), fruitUnit.getId(), fruitUnit.getCode(), UnitType.FRUIT_UNIT);
		if (editError != null) {
			fruitUnit.getErrorList().add(editError);
		}
	}
	
	private void checkUnitDates(ServiceSupportEnv env, LandCoverWithErrors landcover, AbsoluteDate plantingDay, String plantingDayPrecision, 
			AbsoluteDate eradicateDay, List<EditError> errorList) {
		
		LocalDate unitPlantingDay = plantingDay.toLocalDate();
		LocalDate unitFlattenEradicateDay = eradicateDay == null ? INFINITE.toLocalDate() : getFlatDateToPrecision(eradicateDay, DatePrecision.valueOf(plantingDayPrecision)).toLocalDate();
		LocalDate landCoverFlattenCreationDay = getFlatDateToPrecision(landcover.getCreation_day(), DatePrecision.valueOf(plantingDayPrecision)).toLocalDate();
		
		if(unitPlantingDay.isBefore(landCoverFlattenCreationDay)) {	
			EditError editError = getEditError(env, ErrorCode.PLANTING_DAY_NOT_VALID_GREATER_THAN, null, SessionErrorLevel.DANGER,
					formatter.format(landCoverFlattenCreationDay),
					"");
			
			errorList.add(editError);
		}
		
		if (unitFlattenEradicateDay.isBefore(unitPlantingDay)) {
			EditError editError = getEditError(env, ErrorCode.ERADICATE_DAY_NOT_VALID_GREATER_THAN, null, SessionErrorLevel.DANGER,
					formatter.format(unitPlantingDay),
					"");
			errorList.add(editError);
		}
		
	}

	private Map<UnitDictionaryTables, ErrorCode> getVineUnitCodesCheckMap() {
		Map<UnitDictionaryTables, ErrorCode> vineUnitCheckMap = new EnumMap<>(UnitDictionaryTables.class);
		
		vineUnitCheckMap.put(UnitDictionaryTables.CULTIVATION_STATUS, ErrorCode.CULTIVATION_STATUS_CODE_NOT_FOUND);
		vineUnitCheckMap.put(UnitDictionaryTables.FARMING_FORM, ErrorCode.FARMING_FORM_CODE_NOT_FOUND);
		vineUnitCheckMap.put(UnitDictionaryTables.IRRIGATION, ErrorCode.IRRIGATION_CODE_NOT_FOUND);
		vineUnitCheckMap.put(UnitDictionaryTables.HEADER_ANCHORING, ErrorCode.HEADER_ANCHORING_CODE_NOT_FOUND);
		vineUnitCheckMap.put(UnitDictionaryTables.POLES_HEADER, ErrorCode.POLES_HEADER_CODE_NOT_FOUND);
		vineUnitCheckMap.put(UnitDictionaryTables.POLES_WEAVING, ErrorCode.POLES_WEAVING_CODE_NOT_FOUND);
		vineUnitCheckMap.put(UnitDictionaryTables.PRODUCT_DESTINATION, ErrorCode.PRODUCT_DESTINATION_CODE_NOT_FOUND);
		vineUnitCheckMap.put(UnitDictionaryTables.SUPPORT_WIRES, ErrorCode.SUPPORT_WIRES_CODE_NOT_FOUND);
		vineUnitCheckMap.put(UnitDictionaryTables.TERRACING, ErrorCode.TERRACING_CODE_NOT_FOUND);
		vineUnitCheckMap.put(UnitDictionaryTables.VARIATION_TYPE, ErrorCode.VARIATION_TYPE_CODE_NOT_FOUND);
		vineUnitCheckMap.put(UnitDictionaryTables.VARIETY, ErrorCode.VARIETY_CODE_NOT_FOUND);
		
		return vineUnitCheckMap;
	}


	private List<VineUnitDetailsNTT> getAllVineUnits(ServiceSupportEnv env, LandCoverWithErrors landCover) {
		List<VineUnitDetailsNTT> vineUnits = editVineUnitsDAO.findInEditVineUnitsBySessionId(env, landCover.getId(), null, null, 1);
		vineUnits.addAll(editVineUnitsDAO.findNotInEditVineUnitsBySessionId(env, landCover.getId(), null));
		return vineUnits;
	}
	
	private List<VineUnitDetailsNTT> getValidVineUnits(ServiceSupportEnv env, LandCoverWithErrors landCover) {
		LocalDate refDate = env.getReferenceDate().toLocalDate();
		return getAllVineUnits(env, landCover).stream()
				.filter(vu -> vu.getEradicateDay() == null || refDate.isBefore(vu.getEradicateDay().toLocalDate()))
				.collect(Collectors.toList());
	}
	
	private List<OliveUnitDetailsNTT> getValidOliveUnits(ServiceSupportEnv env, LandCoverWithErrors landCover) {
		LocalDate refDate = env.getReferenceDate().toLocalDate();
		return getAllOliveUnits(env, landCover).stream()
				.filter(vu -> vu.getEradicateDay() == null || refDate.isBefore(vu.getEradicateDay().toLocalDate()))
				.collect(Collectors.toList());
	}

	private List<OliveUnitDetailsNTT> getAllOliveUnits(ServiceSupportEnv env, LandCoverWithErrors landCover) {
		List<OliveUnitDetailsNTT> oliveUnits = editOliveUnitsDAO.findInEditOliveUnitsBySessionId(env, landCover.getId(), null, null, 1);
		oliveUnits.addAll(editOliveUnitsDAO.findNotInEditOliveUnitsBySessionId(env, landCover.getId(), null));
		return oliveUnits;
	}
	
	private List<FruitUnitDetailsNTT> getValidFruitUnits(ServiceSupportEnv env, LandCoverWithErrors landCover) {
		LocalDate refDate = env.getReferenceDate().toLocalDate();
		return getAllFruitUnits(env, landCover).stream()
				.filter(vu -> vu.getEradicateDay() == null || refDate.isBefore(vu.getEradicateDay().toLocalDate()))
				.collect(Collectors.toList());
	}
	
	private List<FruitUnitDetailsNTT> getAllFruitUnits(ServiceSupportEnv env, LandCoverWithErrors landCover) {
		List<FruitUnitDetailsNTT> fruitUnits = editFruitUnitsDAO.findInEditFruitUnitsBySessionId(env, landCover.getId(), null, null, 1);
		fruitUnits.addAll(editFruitUnitsDAO.findNotInEditFruitUnitsBySessionId(env, landCover.getId(), null));
		return fruitUnits;
	}
	
	private void checkOneToOneConfig(ServiceSupportEnv env, ParcelWithErrors parcel) {
		
		if(EditStatus.DELETED.equals(parcel.getEdit_status())) {
			return;
		}
		
		if(Boolean.FALSE.equals(internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.PARCEL_LANDCOVER_ONE_TO_ONE.getKey()))) {
			return;
		}
		
		List<LandCoverNTT> landcovers = new ArrayList<>();
		landcovers.addAll(editLandCoversDAO.findInEditBySessionId(env, parcel.getId()));
		landcovers.addAll(editLandCoversDAO.findNotInEditBySessionId(env, parcel.getId()));
		
		Long filteredLandCoverCount = landcovers.stream()
				.filter(lc -> !(EditStatus.DELETED.equals(lc.getEdit_status())
									|| lc.getGeom() == null))
				.count();
		
		if(filteredLandCoverCount != 1L) {
			parcel.getErrorList().add(getEditError(env, ErrorCode.ONLY_ONE_LANDCOVER_ALLOWED, null, SessionErrorLevel.DANGER));
		}

	}
	
	// XXX possible issue if catalogue landcover configuration, here are loaded only DB landcover....
	private void checkTotalLandCoverArea(ServiceSupportEnv env, ParcelWithErrors parcel) {
		Double maxDifferenceArea = internalConf.getDoubleValue(env.getTenantId(), InternalConfigKeys.MAXIMUM_DIFFERENCE_LANDCOVER_AREA_KEY.getKey());
		
		Double inEditArea = editLandCoversDAO.findInEditBySessionId(env, parcel.getId()).stream()
				.mapToDouble(LandCoverNTT::getArea_sqm)
				.sum();
		Double notInEditArea = editLandCoversDAO.findNotInEditBySessionId(env, parcel.getId()).stream()
				.mapToDouble(LandCoverNTT::getArea_sqm)
				.sum();

		Long pArea = parcel.getArea_sqm();
		Long lcsTotArea = Math.round(notInEditArea) + Math.round(inEditArea);
		if((pArea - lcsTotArea) < -maxDifferenceArea) {
			parcel.getErrorList().add(getEditError(env, ErrorCode.TOTAL_LAND_COVERS_AREA_TOO_LARGE, "P: ("+pArea+"), LC:("+lcsTotArea+")", SessionErrorLevel.DANGER));
		}
		if((pArea - lcsTotArea) > maxDifferenceArea) {
			parcel.getErrorList().add(getEditError(env, ErrorCode.TOTAL_LAND_COVERS_AREA_TOO_SMALL, "P: ("+pArea+"), LC:("+lcsTotArea+")", SessionErrorLevel.DANGER));
		}
	}

	private void checkWrongParcelName(ServiceSupportEnv env, Long parcelId, List<EditError> errorList) {
		List<ParcelNTT> wrongNameParcel = editParcelsDAO.findNotValidNameParcelsForSession(env.getSessionId(), parcelId);
		if(!wrongNameParcel.isEmpty()) {
			errorList.add(getEditError(env, ErrorCode.EDIT_PARCELS_WITHOUT_PARCEL_CODES, null, SessionErrorLevel.DANGER));
		}
	}

	private void checkWrongParcelExternalCode(ServiceSupportEnv env, Long parcelId, String externalCode, List<EditError> errorList) {
		if(editParcelsDAO.countParcelWithExternalCode(env, parcelId, externalCode) != 0) {
			errorList.add(getEditError(env, ErrorCode.INVALID_PARCEL_EXTERNAL_CODE, externalCode, SessionErrorLevel.DANGER));
		}
	}

	private void checkWrongAreaParcel(ServiceSupportEnv env, Long parcelId, List<EditStatus> excludesStatus,
			List<EditError> errorList) {
		List<ParcelNTT> wrongAreaParcels = editParcelsDAO.findNotValidAreaParcelsForSession(
				env.getSessionId(),
				parcelId,
				this.internalConf.getIntegerValue(env.getTenantId(), InternalConfigKeys.MINIMUM_PARCELS_AREA_KEY.getKey()),
				excludesStatus);
		if (!wrongAreaParcels.isEmpty()) {
			errorList.add(getEditError(env, ErrorCode.EDIT_PARCELS_TOO_SMALL, null, SessionErrorLevel.DANGER));	
		}
	}
	
	private void checkParcellFullLandcoverCovered(ServiceSupportEnv env, ParcelWithErrors parcel) {

		if(parcel.getGeom() == null && !parcel.getEdit_status().equals(EditStatus.TOPOLOGY_CORRECTED)) { // XXX set in a parameter or in configuration wich status excludes?
			return;
		}
		
		Double parcelArea = parcel.getGeom().getArea();
		Double landCoversArea = editLandCoversDAO.findSessionLandCoversForSessionParcels(env, parcel.getId())
				.stream()
				.filter(l -> (l.getGeom() != null))
				.map(LandCoverNTT::getGeom)
				.mapToDouble(Geometry::getArea)
				.sum();

		parcelArea = parcelArea == null ? 0 : parcelArea;
		landCoversArea = landCoversArea == null ? 0 : landCoversArea;
		if (Math.abs(parcelArea - landCoversArea) > 1) {
			parcel.getErrorList().add(getEditError(env, ErrorCode.PARCEL_NOT_FULLY_COVERED, null, SessionErrorLevel.DANGER));
		}
			
	}

	private void checkWrongLandCoverArea(ServiceSupportEnv env, Long parcelId, 
			Long landCoverId, List<EditStatus> excludesStatus, List<EditError> errorList) {
		List<LandCoverNTT> wrongAreaLc = editLandCoversDAO.findNotValidAreaLandCoversForSession(
				env.getSessionId(),
				parcelId,
				landCoverId,
				this.internalConf.getIntegerValue(env.getTenantId(), InternalConfigKeys.MINIMUM_LAND_COVERS_AREA_KEY.getKey()),
				excludesStatus);
		if (!wrongAreaLc.isEmpty()) {
			errorList.add(getEditError(env, ErrorCode.EDIT_LANDCOVERS_TOO_SMALL, null, SessionErrorLevel.DANGER));	
		}
	}

	private void checkLandCoverConfigCanSave(ServiceSupportEnv env, LandCoverWithErrors landCover) {
		
		Boolean saveForbidden = Optional.ofNullable(landCoverConfigsDAO.findByLandCoverCodeAndKey(env.getTenantId(), landCover.getCode(), LandCoverConfigKeys.SAVE_FORBIDDEN))
				.map(conf -> Boolean.parseBoolean(conf.getValue()))
			    .orElse(Boolean.FALSE);
		
		if (Boolean.TRUE.equals(saveForbidden)) {
			String landCoverDetailMsg = ""+landCover.getCode() + " " + landCover.getDescription();
			landCover.getErrorList().add(getEditError(env, ErrorCode.LANDCOVER_SAVE_FORBIDDEN, landCoverDetailMsg, SessionErrorLevel.DANGER));
		}
		
	}
	
	private void checkLandCoverConfigCanEdit(ServiceSupportEnv env, LandCoverWithErrors landCover) {
		
		Boolean editForbidden = Optional.ofNullable(landCoverConfigsDAO.findByLandCoverCodeAndKey(env.getTenantId(), landCover.getCode(), LandCoverConfigKeys.EDIT_FORBIDDEN))
				.map(conf -> Boolean.parseBoolean(conf.getValue()))
				.orElse(Boolean.FALSE);
		
		if (Boolean.TRUE.equals(editForbidden) && !(EditStatus.TOPOLOGY_CORRECTED.equals(landCover.getEdit_status()))) {
			String landCoverDetailMsg = ""+landCover.getCode() + " " + landCover.getDescription();
			landCover.getErrorList().add(getEditError(env, ErrorCode.LANDCOVER_EDIT_FORBIDDEN, landCoverDetailMsg, SessionErrorLevel.DANGER));
		}
		
	}

	private void checkVineAptitudesErrors(ServiceSupportEnv env, VineUnitDetailsNTT unit, VineAptitudeWithErrors aptitude) {
		
		if(vineAptitudesErrorChecks == null) {
			return;
		}
		
		vineAptitudesErrorChecks.stream().forEach(check -> {
			if(SessionCheck.CODE.equals(check)) {
				checkDoigtCodeForAptitude(env, aptitude);
			} else if(SessionCheck.VINE_APTITUDE_DATES.equals(check)) {
				checkVineAptitudeDates(env, unit, aptitude);
			} 
			
		});
		
	}

	private void checkVineAptitudeDates(ServiceSupportEnv env, VineUnitDetailsNTT unit, VineAptitudeWithErrors aptitude) {
		
		LocalDate aptitudeDayFrom = aptitude.getDayFrom().toLocalDate();
		LocalDate aptitudeFlattenDayRevocation = getFlatDateToPrecision(aptitude.getDayTo(), aptitude.getDayFromPrecision()).toLocalDate();
		LocalDate unitFlattenPlantingDay = getFlatDateToPrecision(unit.getPlantingDay(), aptitude.getDayFromPrecision()).toLocalDate();
		LocalDate unitFlattenEradicateDay = getFlatDateToPrecision(unit.getEradicateDay(), aptitude.getDayFromPrecision()).toLocalDate();
		
		if(aptitudeDayFrom.isBefore(unitFlattenPlantingDay) || (aptitudeDayFrom.isAfter(unitFlattenEradicateDay))) {

			EditError editError = getEditError(env, ErrorCode.VINE_APTITUDE_DAY_FROM_NOT_VALID, null, SessionErrorLevel.DANGER,
					formatter.format(unitFlattenPlantingDay),
					formatter.format(unitFlattenEradicateDay));
			
			if(unitFlattenEradicateDay.equals(INFINITE.toLocalDate())) {
				editError = getEditError(env, ErrorCode.VINE_APTITUDE_DAY_FROM_NOT_VALID_GREATER_THAN, null, SessionErrorLevel.DANGER,
						formatter.format(unitFlattenPlantingDay),
						"");
			}
			
			aptitude.getErrorList().add(editError);
		}
		
		if (aptitudeFlattenDayRevocation.isBefore(aptitudeDayFrom)) {
			EditError editError = getEditError(env, ErrorCode.REVOKE_DATE_NOT_VALID, null, SessionErrorLevel.DANGER,
					formatter.format(aptitudeDayFrom),
					formatter.format(unitFlattenEradicateDay));
			
			aptitude.getErrorList().add(editError);
		}
		
	}


	/**
	 * Flat down an absolute date to the relative precision to the first day of month if YM or the first day of the first month if Y
	 */
	private AbsoluteDate getFlatDateToPrecision(AbsoluteDate partialAbsDate, DatePrecision precision) {
		
		if(precision == null || precision == DatePrecision.YMD) {
			return partialAbsDate;
		} else if(precision == DatePrecision.YM) {
			return AbsoluteDate.of(partialAbsDate.toLocalDate().withDayOfMonth(1));
		} else if(precision == DatePrecision.Y) {
			return AbsoluteDate.of(partialAbsDate.toLocalDate().withMonth(1).withDayOfMonth(1));
		}
		
		return partialAbsDate;
	}


	private void checkDoigtCodeForAptitude(ServiceSupportEnv env, VineAptitudeWithErrors aptitude) {
		if (unitCodesDAO.findVineDoigtByCode(env.getTenantId(), aptitude.getDoigt().getCode()) == null) {
			aptitude.getErrorList().add(getEditError(env, ErrorCode.DOIGT_CODE_NOT_FOUND, aptitude.getDoigt().getCode(), SessionErrorLevel.DANGER));
		}
	}


	private void searchUnitsCodeOrPutError(ServiceSupportEnv env, UnitType ut, List<UnitDictionaryTables> mandatoryDictionayTables,
			UnitsWithDictionaryCodesPayloadV1 dictionaryCodes, UnitDictionaryTables dictionaryTable, ErrorCode errorCode, List<EditError> errorList) {

		String code = dictionaryTable.getCodeValue(dictionaryCodes);

		if((code == null && mandatoryDictionayTables.contains(dictionaryTable)) ||
				!Objects.equal(unitsSupportService.getVineUnitCodeIfExist(env, dictionaryCodes, dictionaryTable, ut), code)) {
			errorList.add(getEditError(env, errorCode, code, SessionErrorLevel.DANGER));
		}
	}

	private void checkTotalUnitsAreaTooLarge(ServiceSupportEnv env, UnitType unitType, LandCoverWithErrors landCover) {
		
		Double unitsArea;
		ErrorCode errorCode = null;
		if(unitType == UnitType.VINE_UNIT) {
			unitsArea = getValidVineUnits(env, landCover).stream().mapToDouble(VineUnitDetailsNTT::getAreaSqm).sum();
			errorCode = ErrorCode.TOTAL_VINE_UNITS_AREA_TOO_LARGE;
		} else if(unitType == UnitType.OLIVE_UNIT) {
			unitsArea = getValidOliveUnits(env, landCover).stream().mapToDouble(OliveUnitDetailsNTT::getAreaSqm).sum();
			errorCode = ErrorCode.TOTAL_OLIVE_UNITS_AREA_TOO_LARGE;
		} else if(unitType == UnitType.FRUIT_UNIT) {
			unitsArea = getValidFruitUnits(env, landCover).stream().mapToDouble(FruitUnitDetailsNTT::getAreaSqm).sum();
			errorCode = ErrorCode.TOTAL_FRUIT_UNITS_AREA_TOO_LARGE;
		}
		else {
			throw new UnsupportedOperationException(String.format(UNIT_TYPE_NOT_IMPLEMENTED_MESSAGE, unitType.name()));
		}
		
		if(landCover.getArea_sqm().compareTo(Math.round(unitsArea)) < 0) {
			landCover.getErrorList().add(getEditError(env, errorCode, "LC: ("+landCover.getArea_sqm()+"), " + unitType.getAcronym() + ":("+Math.round(unitsArea)+")", SessionErrorLevel.DANGER));
		}		
	}
	
	private void checkTotalUnitsAreaTooSmall(ServiceSupportEnv env, UnitType unitType, LandCoverWithErrors landCover) {
		
		Double unitsArea;
		ErrorCode errorCode = null;
		if(unitType == UnitType.VINE_UNIT) {
			unitsArea = getValidVineUnits(env, landCover).stream().mapToDouble(VineUnitDetailsNTT::getAreaSqm).sum();
			errorCode = ErrorCode.TOTAL_VINE_UNITS_AREA_TOO_SMALL;
		} else if(unitType == UnitType.OLIVE_UNIT) {
			unitsArea = getValidOliveUnits(env, landCover).stream().mapToDouble(OliveUnitDetailsNTT::getAreaSqm).sum();
			errorCode = ErrorCode.TOTAL_OLIVE_UNITS_AREA_TOO_SMALL;
		} else if(unitType == UnitType.FRUIT_UNIT) {
			unitsArea = getValidFruitUnits(env, landCover).stream().mapToDouble(FruitUnitDetailsNTT::getAreaSqm).sum();
			errorCode = ErrorCode.TOTAL_FRUIT_UNITS_AREA_TOO_SMALL;
		}
		else {
			throw new UnsupportedOperationException(String.format(UNIT_TYPE_NOT_IMPLEMENTED_MESSAGE, unitType.name()));
		}
		
		if(unitsArea != null && landCover.getArea_sqm().compareTo(Math.round(unitsArea)) > 0) {
			landCover.getErrorList().add(getEditError(env, errorCode, "LC: ("+landCover.getArea_sqm()+"), " + unitType.getAcronym() + ":("+Math.round(unitsArea)+")", SessionErrorLevel.DANGER));
		}		
	}


	private EditError checkIfUniqueUnitCode(ServiceSupportEnv env, Long parcelId, Long landCoverId, Long unitId, String unitCode, UnitType ut) {
		CheckUniqueUnitCodePluginModel pluginResp = null;
		SdkUnitCode sdkUnitCode = loadUnitCodePlugin(env.getTenantId(), PluginConstants.CREATE_UNIT_CODE_KEY);
		if (sdkUnitCode != null) {
			try {
				log.info("Use plugin {} to check unit code", sdkUnitCode.getClass().getCanonicalName());
				pluginResp = sdkUnitCode.checkIfUniqueUnitCode(env, unitCode, ut, pluginEnvironment);			
			} catch (Exception e) {
				log.error("Error during check unit code with plugin {} : {}", sdkUnitCode.getClass().getName(), e);
				throw e;
			}
			
			if (pluginResp != null && pluginResp.getIsUnique() != null && Boolean.FALSE.equals(pluginResp.getIsUnique())) {
				EditError editError = getEditError(env, ErrorCode.UNIT_CODE_NOT_UNIQUE, ut.getAcronym() + ": "+ unitCode, SessionErrorLevel.DANGER);
				editError.setErrorLinks(getErrorLinks(env, parcelId, landCoverId, unitId, ErrorCode.UNIT_CODE_NOT_UNIQUE));
				return editError;
			}

			if(pluginResp != null && ErrorCode.UNIT_CODE_NOT_VALID.equals(pluginResp.getErrorCode())) {
				UnitCodeNotValidException ex = new UnitCodeNotValidException(Status.BAD_REQUEST,
						env.getOperation(), ErrorField.UNIT_CODE,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}	
		}
		return null;		
	}

	private List<ErrorRelatedLink> getErrorLinks(ServiceSupportEnv env, Long parcelId, Long landCoverId, Long unitId, ErrorCode errorCode) {

		String key = env.getTenantId() + "|" + env.getLang();
		Map<String, List<AdditionalExternalLinkNTT>> additionalExternalLinks = additionalExternalLinkCache.get(key);
		List<AdditionalExternalLinkNTT> externalLinkNTTs = additionalExternalLinks.get(errorCode.toString());
		
		List<ErrorRelatedLink> errorRelatedLinks = new ArrayList<>();
		
		if (externalLinkNTTs == null) {
			return errorRelatedLinks;
		}
		
		externalLinkNTTs.stream()
		.forEach(link -> errorRelatedLinks.add(ErrorRelatedLink.builder()
				.type(link.getLinkType())
				.name(link.getName())
				.title(link.getTitle())
				.url(remapUrl(env, parcelId, landCoverId, unitId, link.getUrl()))
				.httpVerb(link.getHttpVerb())
				.build()));

		return errorRelatedLinks;
	}

	private String remapUrl(ServiceSupportEnv env, Long parcelId, Long landCoverId, Long unitId, String url) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("{tenant}", env.getTenantId());
		paramMap.put("{sessionId}", env.getSessionId());
		paramMap.put("{parcelId}", parcelId);
		paramMap.put("{landCoversId}", landCoverId);
		paramMap.put("{unitId}", unitId);
		
		for (Map.Entry<String, Object> entry : paramMap.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			if (key.matches("\\{.*?\\}")) { 
				url = StringUtils.replace(url, key, value.toString());
			}
		}

		return serverApplicationContextPath + url;
	}
	
	private EditError getEditError(ServiceSupportEnv env, ErrorCode errorCode, String code, SessionErrorLevel errorLevel) {
		return EditError.builder()
				.code(errorCode.toString())
				.description(getErrorDescription(env, errorCode, code))
				.level(errorLevel)
				.build();
	}
	
	private EditError getEditError(ServiceSupportEnv env, ErrorCode errorCode, String code, SessionErrorLevel errorLevel,
			String minDate, String maxDate) {
		return EditError.builder()
				.code(errorCode.toString())
				.description(String.format(getErrorDescription(env, errorCode, code), minDate, maxDate))
				.level(errorLevel)
				.build();
	}

	private String getErrorDescription(ServiceSupportEnv env, ErrorCode errorCode, String code) {
		Map<String, Map<String, String>> errorDescriptions = this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId());
		return (errorDescriptions.containsKey(errorCode.toString()) && errorDescriptions.get(errorCode.toString()).containsKey(env.getLang())
				? errorDescriptions.get(errorCode.toString()).get(env.getLang())
						: errorCode.getDescription()
				) + (code != null ? " ("+code+")" : "");
	}
	
	
	public List<EditStatus> getExcludesStatus() {
		return excludesStatus;
	}


	private Map<String, List<AdditionalExternalLinkNTT>> loadAdditionalExternalLink(String key) {
		if(key == null || key.split("\\|").length < 2)
			return new HashMap<>();
		
		String splitKey[] = key.split("\\|");

		ServiceSupportEnv env = 
				ServiceSupportEnv.builder()
				.tenantId(splitKey[0])
				.lang(splitKey[1])
				.build();

		return supportDAO.findAdditionlExternalLinksByModuleViewTypeCodeAndTenant(env, MODULE, VIEW, null, null, 1)
				.stream()
				.collect(Collectors.groupingBy(AdditionalExternalLinkNTT::getCode));
	}
	
}
