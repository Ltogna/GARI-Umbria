package com.abacogroup.lpisgisserver.core;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.proj4j.CoordinateReferenceSystem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.ParcelSearchLevel;
import com.abacogroup.lpisgisserver.core.exceptions.block.BlockIdsNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.block.BlockNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.LandCoverNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.GenericParcelException;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.InvalidParcelGeometryException;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.ParcelNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.TemporaryParcelNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.sector.InvalidSectorDataException;
import com.abacogroup.lpisgisserver.core.exceptions.sector.SectorIdsNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.sector.SectorNotFoundException;
import com.abacogroup.lpisgisserver.core.mappers.BlockMapper;
import com.abacogroup.lpisgisserver.core.mappers.LandCoversMapper;
import com.abacogroup.lpisgisserver.core.mappers.ParcelsInfoMapper;
import com.abacogroup.lpisgisserver.core.mappers.ParcelsMapper;
import com.abacogroup.lpisgisserver.core.mappers.SectorMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.FruitUnitMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.OliveUnitMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.VineAptitudesMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.VineUnitMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.BlockDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.FruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.OliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.ParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.SectorDAO;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.dao.VineUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.cache.CacheTempParcelsDAO;
import com.abacogroup.lpisgisserver.db.ntt.BlockNTT;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.db.ntt.SectorNTT;
import com.abacogroup.lpisgisserver.db.ntt.cache.TempParcelNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.plugins.PluginConstants;
import com.abacogroup.lpisgisserver.plugins.models.CheckParcelNamePluginModel;
import com.abacogroup.lpisgisserver.resources.req.CataloguePayload;
import com.abacogroup.lpisgisserver.resources.req.GetParcelsInGeomPayload;
import com.abacogroup.lpisgisserver.resources.req.ParcelSearchFilters;
import com.abacogroup.lpisgisserver.resources.res.CatalogueGeom;
import com.abacogroup.lpisgisserver.resources.res.ExternalSourceParcel;
import com.abacogroup.lpisgisserver.resources.res.FindNewParcelRes;
import com.abacogroup.lpisgisserver.resources.res.LandCoverWithUnits;
import com.abacogroup.lpisgisserver.resources.res.LayerStyle;
import com.abacogroup.lpisgisserver.resources.res.Parcel;
import com.abacogroup.lpisgisserver.resources.res.ParcelEditStatus;
import com.abacogroup.lpisgisserver.resources.res.ParcelHistory;
import com.abacogroup.lpisgisserver.resources.res.ParcelsHistoryList;
import com.abacogroup.lpisgisserver.resources.res.ParcelsLandCoversList;
import com.abacogroup.lpisgisserver.resources.res.info.ParcelInfo;
import com.abacogroup.lpisgisserver.resources.res.units.fruit.FruitUnit;
import com.abacogroup.lpisgisserver.resources.res.units.olive.OliveUnit;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineAptitude;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnitWithAptitudes;
import com.abacogroup.lpisgisserver.sdk.SdkParcel;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response.Status;

public class ParcelsService extends BaseService {

	private final ParcelsDAO parcelsDAO;
	private final SectorDAO sectorDAO;
	private final BlockDAO blockDAO;
	private final LandCoversDAO landCoversDAO;
	private final SupportDAO supportDAO;
	private final VineUnitsDAO vineUnitsDAO;
	private final OliveUnitsDAO oliveUnitsDAO;
	private final FruitUnitsDAO fruitUnitsDAO;
	private final CacheTempParcelsDAO cacheTempParcelsDAO;

	private final ExternalParcelsSourceDataService externalParcelsSourceService;
	private final CacheService<TempParcelNTT> cacheTempParcelsService;
	private final CataloguesService cataloguesService;

	private static final Logger log = LoggerFactory.getLogger(ParcelsService.class);
	private static final DateTimeFormatter DB_DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	private static final String DEFAULT_INITIAL_DATE = "1970-01-01 03:14:15";

	public ParcelsService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf, 
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, 
			ExternalParcelsSourceDataService externalParcelsSourceService, PluginEnvironment pluginEnvironment, 
			CacheService<TempParcelNTT> cacheTempParcelsService, CataloguesService cataloguesService) {

		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.parcelsDAO = dc.getParcelsDAO();
		this.landCoversDAO = dc.getLandCoversDAO();
		this.sectorDAO = dc.getSectorDAO();
		this.blockDAO = dc.getBlockDAO();
		this.supportDAO = dc.getSupportDAO();
		this.vineUnitsDAO = dc.getVineUnitsDAO();
		this.oliveUnitsDAO = dc.getOliveUnitsDAO();
		this.fruitUnitsDAO = dc.getFruitUnitsDAO();
		this.cacheTempParcelsDAO = dc.getCacheTempParcelsDAO();

		this.externalParcelsSourceService = externalParcelsSourceService;
		this.cacheTempParcelsService = cacheTempParcelsService;
		this.cataloguesService = cataloguesService;
	}

	public InfiniteListResults<Parcel> getParcels(ServiceSupportEnv env, ParcelSearchFilters searchFilters, List<Long> parcelIds, 
			Geometry touchingGeom, List<String> externalCodeList) {

		final String sectorsearch = escapeSqlLike(searchFilters.getSectorDescrFilter());
		final String blocksearch = escapeSqlLike(searchFilters.getBlockDescrFilter());

		String parcelFilter = escapeSqlLike(searchFilters.getParcelFilter());
		parcelFilter = applyParcelSearchPlugin(env, parcelFilter);
		final String parcelSearch = parcelFilter;
		
		if(searchFilters.getUnitType() != null) {
			return this.parcelsDAO.infinite(() -> parcelsDAO.getParcelsByUnitTypeAndVarietyCode(env, touchingGeom, parcelIds, externalCodeList,
					sectorsearch, blocksearch, parcelSearch, searchFilters.getUnitType(), searchFilters.getVarietyCode(), 
					Boolean.TRUE.equals(searchFilters.getShowOutdatedUnits()) ? 1 : 0),
					env.getNextKey(),
					env.getPageSize())
					.map(ParcelsMapper.INSTANCE::entityToDto);
		}
		
		
		 InfiniteListResults<Parcel> parcelsResponse = this.parcelsDAO.infinite(() -> parcelsDAO.getParcels(env, touchingGeom, null, parcelIds, 
				externalCodeList, sectorsearch, blocksearch, parcelSearch, boolToInt(searchFilters.getIncludeOutdated())),
				env.getNextKey(),
				env.getPageSize())
				.map(ParcelsMapper.INSTANCE::entityToDto);
			
			
		
		String parcelName = applyDecodeParcelNamePlugin(env, searchFilters.getParcelFilter());
		Parcel found = parcelsResponse.getRecords().stream().filter(p -> p.getParcel().equals(parcelName)).findFirst().orElse(null);
		
		if(searchFilters.getAddTempIfNotExists() && StringUtils.isNoneBlank(searchFilters.getParcelFilter()) && found == null) {
			if(parcelsResponse.getCount() < env.getPageSize()) {
				List<Parcel> parcelList = new ArrayList<>(parcelsResponse.getRecords());
				addNonExsistingParcels(env, searchFilters.getSectorDescrFilter(), searchFilters.getBlockDescrFilter(),
						searchFilters.getParcelFilter(), parcelList);
				return new InfiniteListResultsImpl<>(parcelList, parcelsResponse.getNextKey());
			} else {
				Integer newNextKey = Integer.parseInt(parcelsResponse.getNextKey()) + parcelsResponse.getCount();
				return new InfiniteListResultsImpl<>(parcelsResponse.getRecords(), newNextKey.toString());
			}
		}
		
		return parcelsResponse;
	}
	
	private void addNonExsistingParcels(ServiceSupportEnv env, String sectorCode, String blockCode, String parcelCode, List<Parcel> parcelsResponse) {
		if(sectorCode == null || blockCode == null || parcelCode == null) {
			GenericParcelException ex = new GenericParcelException(Status.BAD_REQUEST, Operation.GET_PARCELS, ErrorField.REQUEST,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		SectorNTT sectorNTT = sectorDAO.findSectorDetailsByTenantAndCode(env, sectorCode);
		if(sectorNTT == null) {
			return;
		}
		
		BlockNTT blockNTT = blockDAO.findBlockDetailsByTenantBlockCodeSectorCode(env.getTenantId(), blockCode, sectorCode);
		if(blockNTT == null) {
			return;
		}
		
		String parcelFilter = escapeSqlLike(parcelCode);
		parcelFilter = applyParcelSearchPlugin(env, parcelFilter);
		final String parcelSearch = parcelFilter;
		final String parcelName = applyDecodeParcelNamePlugin(env, parcelCode);
		
		ParcelNTT parcelNTT = parcelsDAO.getParcelByTenantSectorBlockIdAndParcel(env.getTenantId(), blockNTT.getId(), parcelSearch);

		if(parcelNTT == null) {
			TempParcelNTT tempParcelNTT = TempParcelNTT.builder()
					.id(Math.negateExact(cacheTempParcelsDAO.nextSequenceVal()))
					.parcel(parcelName)
					.blockId(blockNTT.getId())
					.build();
			cacheTempParcelsService.loadData(env, List.of(tempParcelNTT));

			parcelNTT = ParcelNTT.builder()
					.parcel_id(tempParcelNTT.getId())
					.parcel(tempParcelNTT.getParcel())
					.build();
		}

		if(parcelNTT != null) {
			parcelNTT.setArea_sqm(0.0);
			parcelNTT.setBlock(blockNTT);
			parcelNTT.setSector(sectorNTT);
			parcelsResponse.add(ParcelsMapper.INSTANCE.entityToDto(parcelNTT));
		}
	}

	public ParcelsLandCoversList getParcelDetails(ServiceSupportEnv env, Long parcelId, 
			Boolean includeLayerStyle, ParcelSearchLevel searchLevel) {
		ParcelsLandCoversList result = ParcelsLandCoversList.builder()
				.parcels_list(new ArrayList<>())
				.land_covers_list(new ArrayList<>())
				.build();
		
		if(searchLevel == null) {
			searchLevel = ParcelSearchLevel.SEARCH_ONLY_VALID;
		}


        //if LANDCOVER_ORIGIN_CATALOGUE_CODE is not null I need the geometries so in getParcelDetailsInternal are returned				
		Parcel parcel = getParcelDetailsInternal(env, parcelId, searchLevel, Operation.GET_PARCEL_DETAILS);
		parcel.setTotal_land_covers_area_sqm(0L);
		
		// if parcel has no GIS (no details like dayfrom) or is outdated then there should be no other details....
		if(parcel.getDay_from() != null) {
			List<LandCoverWithUnits> landCoversResult;
			
			String lcOriginCatalogueCode = internalConf.getStringValue(env.getTenantId(), InternalConfigKeys.LANDCOVER_ORIGIN_CATALOGUE_CODE.getKey());
			if(!StringUtils.isBlank(lcOriginCatalogueCode)) {
				landCoversResult = getParcelLandCoversFromCatalogue(env, lcOriginCatalogueCode, parcel.getId(), parcel.getGeom(), parcel.getSrs());
			} else {
				landCoversResult = getLandCoversList(env, parcel, null, includeLayerStyle, false);
			}
			
			result.getLand_covers_list().addAll(landCoversResult);
	
			Double totalLandCoversArea = landCoversResult.stream().mapToDouble(LandCoverWithUnits::getArea_sqm).sum();
			parcel.setTotal_land_covers_area_sqm(Math.round(totalLandCoversArea));
		}
		result.getParcels_list().add(parcel);

		return result;
	}

	public ParcelsLandCoversList getParcelsInGeom(ServiceSupportEnv env, @NotNull @Valid GetParcelsInGeomPayload payload, Boolean noContent) {
		ParcelsLandCoversList result = ParcelsLandCoversList
				.builder()
				.parcels_list(new ArrayList<>())
				.land_covers_list(new ArrayList<>())
				.build();

		Geometry geom = payload.getGeom();
		String srs = payload.getSrs();

		if (geom.getArea() > this.internalConf.getDoubleValue(env.getTenantId(), InternalConfigKeys.MAXIMUM_VALID_SEARCH_PARCELS_GEOM_AREA_KEY.getKey())) {
			InvalidParcelGeometryException ex = new InvalidParcelGeometryException(Status.BAD_REQUEST, Operation.GET_PARCELS_IN_GEOM, ErrorField.GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		List<Long> notLockParcelsIdsWithInteraction = parcelsDAO.getNonLockParcelsIdsWithInteraction(env.getTenantId(), env.getSessionId(), geom, srs,
				env.getReferenceDate());

		if (notLockParcelsIdsWithInteraction == null || notLockParcelsIdsWithInteraction.isEmpty()) {
			ParcelNotFoundException ex = new ParcelNotFoundException(Boolean.TRUE.equals(noContent) ? Status.NO_CONTENT : Status.NOT_FOUND, Operation.GET_PARCELS_IN_GEOM,
					ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			if (Boolean.FALSE.equals(noContent))
				log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		notLockParcelsIdsWithInteraction.forEach(id -> {
			ParcelsLandCoversList det = getParcelDetails(env, id, true, ParcelSearchLevel.SEARCH_ONLY_VALID);
			result.getParcels_list().addAll(det.getParcels_list());
			result.getLand_covers_list().addAll(det.getLand_covers_list());
		});
		
		return result;
	}

	public ParcelsHistoryList getParcelHistory(ServiceSupportEnv env, Long parcelId) {
		ParcelsHistoryList result = ParcelsHistoryList.builder().parcels_history_list(new ArrayList<>()).build();

		List<ParcelNTT> parcels = parcelsDAO.findByIdTenantId(parcelId, env.getTenantId());
		if (parcels == null || parcels.size() != 1) {
			ParcelNotFoundException ex = new ParcelNotFoundException(Status.NOT_FOUND, Operation.GET_PARCEL_HISTORY, ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		List<ParcelNTT> parcelHistory = parcelsDAO.getParcelHistory(env.getTenantId(), parcelId);

		if (parcelHistory != null && !parcelHistory.isEmpty()) {

			parcelHistory.sort((p1, p2) -> p1.getDay_from().toLocalDate().compareTo(p2.getDay_from().toLocalDate()) >= 0 ? -1 : 1);

			parcelHistory.forEach(parcel -> result.getParcels_history_list()
					.add(ParcelHistory.builder()
							.id(parcel.getParcel_id())
							.parcel(parcel.getParcel())
							.day_from(parcel.getDay_from())
							.day_to(parcel.getDay_to())
							.srs(parcel.getSrs())
							.geom(parcel.getGeom())
							.world_geom(parcel.getWorld_geom())
							.area_sqm(Math.round(parcel.getArea_sqm()))
							.task_id(parcel.getStack().getTask_id())
							.user_id(parcel.getStack().getUser_id())
							.reference_date(parcel.getStack().getReference_date())
							.dt_operation(parcel.getStack().getDt_operation())
							.fl_parent(parcel.getStack().getFl_parent())
							.notes(parcel.getStack().getNotes())
							.build()));

		}

		return result;
	}

	public FindNewParcelRes findNewParcel(ServiceSupportEnv env, Long sectorId, Long blockId, String parcelName) {

		Parcel parcel = findParcelBySectorBlockAndName(env, sectorId, blockId, parcelName);
		if(parcel == null)
			return null;  // null respond http:204

		env.setSrs(parcel.getSector().getSrs());

		List<ExternalSourceParcel> externalParcels = externalParcelsSourceService.searchExternalParcelsInfiniteList(null, parcel.getSector().getSector_code(), parcel.getBlock().getBlock_code(), parcel.getParcel(), env).getRecords();

		return FindNewParcelRes.builder()
				.newParcel(parcel)
				.externalParcels(externalParcels != null ? externalParcels : new LinkedList<>())
				.build();
	}
	
	private Parcel findParcelBySectorBlockAndName(ServiceSupportEnv env, Long sectorId, Long blockId, String parcelName) {
		parcelName = escapeSqlLike(parcelName);

		SdkParcel sdkParcel = loadParcelPlugin(env.getTenantId(), PluginConstants.DECODE_PARCEL_SEARCH_KEY);
		if (sdkParcel != null) { // try to use plugin
			try {
				parcelName = sdkParcel.decodeParcelName(parcelName, pluginEnvironment);

				CheckParcelNamePluginModel checkParcel = sdkParcel.checkParcelName(parcelName, env.getLang(), pluginEnvironment);
				if(!checkParcel.isValid()) {
					return null;
				}

			} catch (Exception e) {
				log.error("Error during decode parcel search with plugin {} : {}", sdkParcel.getClass().getName(), e);
			}
		}

		List<Parcel> parcelList = parcelsDAO.findParcelBySectorBlockAndName(env, sectorId, blockId, parcelName)
				.stream()
				.map(ParcelsMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());

		if(parcelList == null || parcelList.isEmpty()){

			BlockNTT blockById = blockDAO.findBlockDetailsByTenantAndId(env.getTenantId(), blockId);
			if (blockById == null) {
				BlockIdsNotFoundException ex = new BlockIdsNotFoundException(Status.NOT_FOUND, Operation.GET_BLOCK, ErrorField.BLOCK_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}

			if(!sectorId.equals(blockById.getSector_id())) {
				InvalidSectorDataException ex = new InvalidSectorDataException(Status.BAD_REQUEST, Operation.GET_SECTOR, ErrorField.SECTOR_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
				log.error(ex.getBody().getLogErrorMessage());
				throw ex;
			}

			SectorNTT sector = sectorDAO.findSectorDetailsByTenantAndId(env.getTenantId(), blockById.getSector_id());
			if (sector == null) {
				SectorIdsNotFoundException ex = new SectorIdsNotFoundException(Status.NOT_FOUND, Operation.GET_SECTOR, ErrorField.SECTOR_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
				log.error(ex.getBody().getLogErrorMessage());
				throw ex;
			}			

			return Parcel.builder()
					.parcel(parcelName)
					.srs(sector.getSrs())
					.sector(SectorMapper.INSTANCE.entityToDto(sector))
					.block(BlockMapper.INSTANCE.entityToDto(blockById))
					.build();
		}

		return null;
	}

	public List<LandCoverWithUnits> findLandCoversByParcelId(ServiceSupportEnv env, Boolean includeLayerStyle,
			Boolean showOutdatedUnits) {
		Parcel parcel = getParcelDetailsInternal(env, env.getParcelId(), ParcelSearchLevel.SEARCH_ONLY_VALID, Operation.GET_LANDCOVERS);
		return getLandCoversList(env, parcel, null, includeLayerStyle, showOutdatedUnits);
	}

	public LandCoverWithUnits getLandCoversById(ServiceSupportEnv env) {
		Parcel parcel = getParcelDetailsInternal(env, env.getParcelId(), ParcelSearchLevel.SEARCH_ONLY_VALID, Operation.GET_LANDCOVERS);
		List<LandCoverWithUnits> landCovers = getLandCoversList(env, parcel, env.getLandCoverId(), true, false);

		if(landCovers.isEmpty() || landCovers.size() != 1) {
			LandCoverNotFoundException ex = new LandCoverNotFoundException(Status.NOT_FOUND, Operation.GET_LANDCOVER_DETAILS, ErrorField.LANDCOVER_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return landCovers.get(0);
	}

	private Parcel getParcelDetailsInternal(ServiceSupportEnv env, Long parcelId, ParcelSearchLevel searchLevel, Operation operation) {
		
		if(searchLevel == null) {
			searchLevel = ParcelSearchLevel.SEARCH_ONLY_VALID;
		}
		
		String lcOriginCatalogueCode = internalConf.getStringValue(env.getTenantId(), InternalConfigKeys.LANDCOVER_ORIGIN_CATALOGUE_CODE.getKey());
		
		ParcelNTT parcel = parcelsDAO.getParcelDetail(env.getTenantId(), parcelId, env.getReferenceDate(), null, searchLevel != ParcelSearchLevel.SEARCH_ONLY_VALID ?  1 : 0);
		if (parcel == null) {
			ParcelNotFoundException ex = new ParcelNotFoundException(Status.NOT_FOUND, operation, ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		// if env srs in unset, set it to parcel srs
		if(env.getSrs() == null) {
			env.setSrs(parcel.getSrs());
		}
		
		if(env.getIncludeGeometries() == 0 && lcOriginCatalogueCode == null) {
			parcel.setGeom(null);
			parcel.setWorld_geom(null);
			parcel.setSrs(null);
		}

		return ParcelsMapper.INSTANCE.entityToDto(parcel);
	}

	private List<LandCoverWithUnits> getLandCoversList(ServiceSupportEnv env, Parcel parcel, Long landCoversId,
			Boolean includeLayerStyle, Boolean showOutdatedUnits) {

		List<LandCoverWithUnits> landCovers = new ArrayList<>();
		Boolean flHideLandCovers = internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_HIDE_LANDCOVERS_LAYER.getKey());
		if(Boolean.FALSE.equals(flHideLandCovers)) {
			
			String lcOriginCatalogueCode = internalConf.getStringValue(env.getTenantId(), InternalConfigKeys.LANDCOVER_ORIGIN_CATALOGUE_CODE.getKey());
			if(!StringUtils.isBlank(lcOriginCatalogueCode)) {
				landCovers.addAll(getParcelLandCoversFromCatalogue(env, lcOriginCatalogueCode, parcel.getId(), parcel.getGeom(), parcel.getSrs()));
			} else {
				landCovers = retrieveLandCovers(env, parcel, landCoversId, includeLayerStyle, showOutdatedUnits);
			}
		}
		return landCovers;
	}

	private List<LandCoverWithUnits> retrieveLandCovers(ServiceSupportEnv env, Parcel parcel, Long landCoversId, Boolean includeLayerStyle,
		 Boolean showOutdatedUnits) {
		
		List<LandCoverWithUnits> landCovers = new ArrayList<>();
		
		List<LandCoverNTT> landCoverNtts;
		landCoverNtts = landCoversDAO.findByParcelIds(env, Arrays.asList(parcel.getId()));
		
		if (landCoverNtts != null) {
			landCoverNtts.forEach(landcover -> {
				if(landCoversId == null || landcover.getLand_cover_id().equals(landCoversId)) {
					LandCoverWithUnits lc = LandCoversMapper.INSTANCE.entityToDtoWithUnits(landcover);
					if(Boolean.TRUE.equals(includeLayerStyle)) {
						LayerStyle style = this.styleService.getLandCoverLayerStyle(env.getTenantId(), env.getReferenceDate(), lc.getCode());
						lc.setLayer_style(style);
					}
					
					lc.setUnit_types(supportDAO.getCompatibleUnitTypesByLandCoverCode(env.getTenantId(), lc.getCode()));
					
					if(env.getIncludeUnits() == 1) {
						env.setLandCoverId(lc.getId());
						lc.setVine_units(getVineUnits(env, showOutdatedUnits));
						lc.setOlive_units(getOliveUnits(env, showOutdatedUnits));
						lc.setFruit_units(getFruitUnits(env, showOutdatedUnits));
						
						lc.setTotal_unit_area_sqm(
								lc.getVine_units().stream().mapToInt(VineUnitWithAptitudes::getAreaSqm).sum() +
								lc.getOlive_units().stream().mapToInt(OliveUnit::getAreaSqm).sum() +
								lc.getFruit_units().stream().mapToInt(FruitUnit::getAreaSqm).sum()
								);
					}
					
					landCovers.add(lc);
				}
			});
		}
		
		return landCovers;
	}

	/**
	 * Its a functional workaround for the public method infinitList, the landcover list is never too long and can be from 
	 * the catalogue, so we convert the "normal" list to infinite list
	 * I think is ok but if when you read this comment the company size is different from 2025 and there is enough time to fix the
	 * technical debt, please do it
	 */
	public InfiniteListResults<LandCoverWithUnits> getLandCoversInfiniteList(ServiceSupportEnv env, Long parcelId, Long landCoversId, 
			Boolean includeLayerStyle) {

		// pageSize is not used because the list is not infinite
		Parcel parcel = getParcelDetailsInternal(env, parcelId, ParcelSearchLevel.SEARCH_ONLY_VALID, Operation.GET_PARCEL_DETAILS);
		Boolean showOutdatedUnits = false;
		
		return new InfiniteListResultsImpl<>(getLandCoversList(env, parcel, landCoversId, includeLayerStyle, showOutdatedUnits), null);

	}

	private List<VineUnitWithAptitudes> getVineUnits(ServiceSupportEnv env, Boolean showOutdatedUnits) {
		List<VineUnitWithAptitudes> vineUnits = vineUnitsDAO.getVineUnitsbyLandCoverIds(env, List.of(env.getLandCoverId()), Boolean.TRUE.equals(showOutdatedUnits) ? 1 : 0).stream()
				.map(VineUnitMapper.INSTANCE::entityToDtoWithAptitudes)
				.collect(Collectors.toList());

		vineUnits.stream().forEach(unit -> {
			unit.setIsEditable(false); // by default outside edit session everything is not editable...
			List<VineAptitude> vineAptitudes = vineUnitsDAO.getVineAptitudes(env, unit.getId(), null, 0).stream()
					.map(VineAptitudesMapper.INSTANCE::entityToDto)
					.collect(Collectors.toList());

			unit.setVineAptitudes(vineAptitudes);
		});

		return vineUnits;
	}
	
	private List<OliveUnit> getOliveUnits(ServiceSupportEnv env, Boolean showOutdatedUnits) {
		return oliveUnitsDAO.getOliveUnitsbyLandCoverIds(env, List.of(env.getLandCoverId()), Boolean.TRUE.equals(showOutdatedUnits) ? 1 : 0).stream()
				.map(OliveUnitMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}
	
	private List<FruitUnit> getFruitUnits(ServiceSupportEnv env, Boolean showOutdatedUnits) {
		return fruitUnitsDAO.getFruitUnitsbyLandCoverIds(env, List.of(env.getLandCoverId()), Boolean.TRUE.equals(showOutdatedUnits) ? 1 : 0).stream()
				.map(FruitUnitMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}

	public Parcel persistTemporaryParcel(ServiceSupportEnv env, Long tempParcelId) {
	
		Criteria criteria = CriteriaBuilder.number("id").eq(tempParcelId);
		
		TempParcelNTT tempParcelNTT = cacheTempParcelsService.getData(env, criteria).stream().filter(t -> t.getId().equals(tempParcelId)).findFirst().orElse(null);
		if(tempParcelNTT == null) {
			TemporaryParcelNotFoundException ex = new TemporaryParcelNotFoundException(Status.NOT_FOUND, 
					Operation.PERSIST_TEMPORARY_PARCEL, ErrorField.TEMPORARY_PARCEL_ID, 
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		BlockNTT blockNTT = blockDAO.findBlockDetailsByTenantAndId(env.getTenantId(), tempParcelNTT.getBlockId());
		if(blockNTT == null) {
			BlockNotFoundException ex = new BlockNotFoundException(Status.NOT_FOUND, Operation.GET_PARCELS, ErrorField.BLOCK_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
			
			log.warn(ex.getBody().getLogErrorMessage());
			
			throw ex;
		}
		
		SectorNTT sectorNTT = sectorDAO.findSectorDetailsByTenantAndId(env.getTenantId(), blockNTT.getSector_id());
		if(sectorNTT == null) {
			SectorNotFoundException ex = new SectorNotFoundException(Status.NOT_FOUND, Operation.GET_PARCELS, ErrorField.SECTOR_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
			
			log.warn(ex.getBody().getLogErrorMessage());
			
			throw ex;
		}
		
		ParcelNTT parcelNTT = parcelsDAO.getParcelByTenantSectorBlockIdAndParcel(env.getTenantId(), blockNTT.getId(), tempParcelNTT.getParcel());
		if(parcelNTT == null) {
			parcelNTT = ParcelNTT.builder()
					.parcel_id(parcelsDAO.nextSequenceVal())
					.tenant_id(env.getTenantId())
					.parcel(tempParcelNTT.getParcel())
					.block(blockNTT)
					.sector(sectorNTT)
					.build();

			parcelsDAO.insert(parcelNTT);
		} else {
			parcelNTT.setSector(sectorNTT);
			parcelNTT.setBlock(blockNTT);
		}
		
		return ParcelsMapper.INSTANCE.entityToDto(parcelNTT);
	}
	
	public InfiniteListResults<ParcelInfo> getParcelsInInteractionsBySectorCode(ServiceSupportEnv env, Geometry geom) {
		return parcelsDAO.infinite(
				() -> parcelsDAO.getParcelsInInteractionsBySectorCode(env, geom),
				env.getNextKey(),
				env.getPageSize())
				.map(ParcelsInfoMapper.INSTANCE::entityToDto);
	}	
	
	public InfiniteListResults<Parcel> getParcelsBySectorCode(ServiceSupportEnv env) {
		return this.parcelsDAO
				.infinite(() -> parcelsDAO.getParcelsBySectorCode(env), env.getNextKey(), env.getPageSize())
				.map(ParcelsMapper.INSTANCE::entityToDto);
	}
	
	public ParcelEditStatus getParcelsEditStatus(ServiceSupportEnv env, String blockCode, String parcelCode) {

		SectorNTT sector = sectorDAO.findSectorDetailsByTenantAndCode(env, env.getSectorCode());
		if (sector == null) {
			SectorNotFoundException ex = new SectorNotFoundException(Status.NOT_FOUND, Operation.GET_PARCEL_EDIT_STATUS, ErrorField.SECTOR_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		BlockNTT block = blockDAO.findBlockDetailsByTenantBlockCodeSectorCode(env.getTenantId(), blockCode, env.getSectorCode());
		if(block == null) {
			BlockNotFoundException ex = new BlockNotFoundException(Status.NOT_FOUND, Operation.GET_PARCEL_EDIT_STATUS, ErrorField.BLOCK_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		//check Parcel code
		ParcelNTT parcel = parcelsDAO.getParcelByTenantSectorBlockIdAndParcel(env.getTenantId(), block.getId(), parcelCode);
		if(parcel == null) {
			ParcelNotFoundException ex = new ParcelNotFoundException(Status.NOT_FOUND, Operation.GET_PARCEL_EDIT_STATUS, ErrorField.PARCEL_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		return ParcelEditStatus.builder()
				.id(parcel.getParcel_id())
				.creationDate(parcelsDAO.getParcelCreationDate(env.getTenantId(), parcel.getParcel_id()))
				.lastUpdate(parcelsDAO.getParcelLastUpdateDate(env.getTenantId(), env.getReferenceDate(), parcel.getParcel_id()))
				.editStatus(parcelsDAO.getParcelLastEditStatus(env.getTenantId(), env.getReferenceDate(), parcel.getParcel_id()))
				.inEdit(parcelsDAO.checkParcelInEdit(env.getTenantId(), parcel.getParcel_id()) != 0)
				.build();
	}
	
	public List<LandCoverWithUnits> getParcelLandCoversFromCatalogue(ServiceSupportEnv env, String catalogueCode, Long parcelId, Geometry geom, String srs) {
		List<LandCoverWithUnits> landCoverList = new ArrayList<>();
		env.setSrs(srs);
		
		CataloguePayload cataloguePayload = CataloguePayload.builder()
				.geom(geom)
				.srs(srs)
				.params(Map.of("referenceDate", env.getReferenceDate().toString())) 
				.build();

		List<CatalogueGeom> catalogueGeoms = cataloguesService.getIntersectedGeomsFromCatalogueList(env, catalogueCode, cataloguePayload);

		CoordinateReferenceSystem toWorldCRS = getCRS(SRS_WORLD_GEOM);
		catalogueGeoms.forEach(cg -> {
			CoordinateReferenceSystem fromCRS = getCRS(cg.getSrs());
			LocalDateTime lastUpdate = LocalDateTime.of(1970, 1, 1, 1, 1);
			try { lastUpdate = LocalDateTime.parse((String)cg.getFields().getOrDefault("last_update", DEFAULT_INITIAL_DATE), DB_DATE_FORMATTER);} 
			catch (Exception e ) {
				log.error(e.getMessage());
			}
			
			Long landcoverpkid = null;
			if(cg.getFields().getOrDefault("land_cover_detail_id", null) != null) {
				landcoverpkid = Long.parseLong((String) cg.getFields().get("land_cover_detail_id"));
			}
			
			LandCoverWithUnits lc = LandCoverWithUnits.builder()
//					.id(Long.parseLong(cg.getId())) // XXX when more parcels are over the same soil polygon the landcover id is the same
					.id(generateRandom12DigitId()) // XXX alternative way to avoid duplicate ids FIXME in viewer can be a problem
					.details_id(landcoverpkid)
					.parcel_id(parcelId)
					.code(cg.getLabel())
					.description((String)cg.getFields().getOrDefault("description", null))
					.last_update(lastUpdate)
					.day_from(AbsoluteDate.of((String)cg.getFields().getOrDefault("day_from", null)))
					.day_to(AbsoluteDate.of((String)cg.getFields().getOrDefault("day_to", null)))
					.edit_status(EditStatus.NOT_IN_EDIT)
					.area_sqm(cg.getAreaSqm() != null ? Math.round(cg.getAreaSqm()) : null)
					.srs(env.getIncludeGeometries() == 0 ? null : cg.getSrs())
					.geom(env.getIncludeGeometries() == 0 ? null : cg.getGeom())
					.world_geom(reproject(cg.getGeom(), fromCRS, toWorldCRS))
					.layer_style(this.styleService.getLandCoverLayerStyle(env.getTenantId(), env.getReferenceDate(), cg.getLabel()))
//					.parent_id(null)
//					.parcel_details_id(null)
//					.creation_day(null)
					.unit_types(new ArrayList<>())
					.vine_units(new ArrayList<>())
					.olive_units(new ArrayList<>())
					.fruit_units(new ArrayList<>())
					.build();

			landCoverList.add(lc);
		});
		
		return landCoverList;
	}

}
