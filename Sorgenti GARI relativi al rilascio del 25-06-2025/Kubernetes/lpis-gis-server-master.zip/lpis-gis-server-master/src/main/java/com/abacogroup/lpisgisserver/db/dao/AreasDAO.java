package com.abacogroup.lpisgisserver.db.dao;

import java.sql.DatabaseMetaData;
import java.util.List;
import java.util.Map;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.annotations.CacheDefinition;
import com.abacogroup.jdbi.annotations.Cached;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.AreaNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface AreasDAO extends Transactional<AreasDAO>, EnhancedSqlObject {

	@SqlUpdate("insert into lpis_areas_hierarchies(tenant_id, pkid, area_id, parent_id, \"level\", code, acronym, description, "
			+ "day_from, day_to, srs, geom, world_geom, user_id_insert, user_id_delete, dt_insert, dt_delete ) "
			+ "values (:env.tenantId, :area.pkid, :area.area_id, :area.parent_id, :area.level_code, :area.code, :area.acronym, :area.description, "
			+ ":area.day_from, :area.day_to, :area.srs, :area.geom, :area.world_geom, :env.userId, NULL, §current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insert(@BindBean("env") ServiceSupportEnv env, @BindBean("area") AreaNTT area);

	@SqlUpdate("update lpis_areas_hierarchies set user_id_delete = :userId, dt_delete = §current_timestamp§ where pkid = :pkid ")
	void logicallyDeleteByPkid(@Bind("pkid") Long pkid, @Bind("userId") String userId);

	@SqlQuery("§select_nextval(lpis_areas_hierarchies_area_id_sequence)§")
	Long nextSequenceAreaIdVal();

	@SqlQuery("§select_nextval(lpis_areas_hierarchies_pkey_sequence)§")
	Long nextSequencePkidVal();

	@SqlQuery("select distinct lsa.area_id \n"
			+ "  from lpis_sector_areas lsa \n"
			+ " inner join lpis_sectors ls on ls.id = lsa.sector_id \n"
			+ " inner join lpis_sector_details lsd on ls.id = lsd.sector_id \n"
			+ " inner join lpis_sector_blocks lsb on ls.id = lsb.sector_id \n"
			+ " inner join lpis_sector_block_details lsbd on lsb.id = lsbd.sector_block_id \n"
			+ " inner join lpis_parcels lp on lsb.id = lp.sector_block_id \n"
			+ " where lp.id in (<parcelIds>) \n"
			+ "   and ls.tenant_id = :tenantId \n"
			+ "   and §current_timestamp§ between lsd.dt_insert and lsd.dt_delete \n"
			+ "   and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete \n"
			+ "   and §current_timestamp§ between lsa.dt_insert and lsa.dt_delete \n"
			+ "   and :referenceDate between lsa.day_from and lsa.day_to \n")
	List<Long> getAreaIdsFromParcelIds(@BindBean ServiceSupportEnv env, @BindList("parcelIds") List<Long> parcelIds);

	default List<Long> findFilteredParcelIdsForAreaId(ServiceSupportEnv env, Long filteredAreaId, List<Long> parcelIds) {
		
		String dbType = withHandle(h -> h.queryMetadata(DatabaseMetaData::getDatabaseProductName));
		
		boolean isPostgres = dbType.toLowerCase().contains("postgresql");
		
		String sql = "select distinct lp.id \n"
				+ "  from lpis_sector_areas lsa \n"
				+ " inner join lpis_sectors ls on ls.id = lsa.sector_id \n"
				+ " inner join lpis_sector_details lsd on ls.id = lsd.sector_id \n"
				+ " inner join lpis_sector_blocks lsb on ls.id = lsb.sector_id \n"
				+ " inner join lpis_sector_block_details lsbd on lsb.id = lsbd.sector_block_id \n"
				+ " inner join lpis_parcels lp on lsb.id = lp.sector_block_id \n"
				+ " inner join ( \n"
				+ "   with "+(isPostgres ? "recursive" : "")+" tree_view(area_id, parent_id, search_id) as ( \n"
				+ "   select area_id, parent_id, \n"
				+ "          cast(area_id as varchar(50)) as search_id \n"
				+ "     from lpis_areas_hierarchies \n"
				+ "    where §current_timestamp§ between dt_insert and dt_delete \n"
				+ "      and :referenceDate between day_from and day_to \n"
				+ "      and :filteredAreaParentId is null or parent_id = :filteredAreaParentId \n"
				+ "   union all \n"
				+ "   select child.area_id, child.parent_id, \n"
				+ "          cast(search_id || '|' || cast(child.area_id as varchar(50)) as varchar(50)) as search_id \n"
				+ "     from lpis_areas_hierarchies child \n"
				+ "     join tree_view tv on child.parent_id = tv.area_id \n"
				+ "    where §current_timestamp§ between dt_insert and dt_delete \n"
				+ "      and :referenceDate between day_from and day_to \n"
				+ "   ) \n"
				+ "   select t.area_id \n"
				+ "     from tree_view t"
				+ " ) ftv on ftv.area_id = lsa.area_id"
				+ " where lp.id in (<parcelIds>) \n"
				+ "   and ls.tenant_id = :tenantId \n"
				+ "   and §current_timestamp§ between lsd.dt_insert and lsd.dt_delete \n"
				+ "   and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete \n"
				+ "   and §current_timestamp§ between lsa.dt_insert and lsa.dt_delete \n"
				+ "   and :referenceDate between lsa.day_from and lsa.day_to \n";
		
		return withHandle(h -> 
				   h.createQuery(sql)
					.bindBean(env)
					.bind("filteredAreaParentId", filteredAreaId)
					.bindList("parcelIds", parcelIds)
					.mapTo(Long.class)
					.list()
		);
		
	}
	
	@Cached
	@CacheDefinition(maxWeight = 5, expireAfterWriteMinutes = 14400) // 10 days cache retention
	@SqlQuery("""
              select ah."level", count(*) 
                from lpis_areas_hierarchies ah 
               where ah.tenant_id = :tenantId 
                 and §current_timestamp§ between ah.dt_insert and ah.dt_delete 
                 and :referenceDate between ah.day_from and ah.day_to  
               group by ah."level" 
               order by count(*)
              """)
	Map<String, Integer> loadLevelsOrder(ServiceSupportEnv env);
	
	static final String AREA_NTT_SQL_SELECT = """
            select pkid,
            area_id,
            parent_id,
            code,
            "level" as level_code, 
            coalesce(§i18n(:tenantId, 'lpis_areas_hierarchies', 'level', "level", :lang)§, "level") as level_description, 
            acronym,
            description,
            day_from,
            day_to,
            srs,
            case when :includeGeometries = 1 then geom else null end as geom,
            case when :includeGeometries = 1 then world_geom else null end as world_geom
       from lpis_areas_hierarchies  
      where tenant_id = :tenantId
        and §current_timestamp§ between dt_insert and dt_delete
        and :referenceDate between day_from and day_to
    """;
	
	@SqlQuery(AREA_NTT_SQL_SELECT + "\n and <criteria> \n")
	@RegisterBeanMapper(AreaNTT.class)
	List<AreaNTT> findAreasByCriterias(@BindBean ServiceSupportEnv env, @BindCriteria Criteria criteria);	
	
	// FIXME use loadLevelsOrder to dinamically create the sort and the query
	static final String AREA_PKIDS_BY_LEVEL_AND_CRITERIA_SQL =
            """
            select pkid from (
               with horizarea as (
                  select naz.pkid as naz_pkid,
                         reg.pkid as reg_pkid,
                         pro.pkid as pro_pkid,
                         com.pkid as com_pkid
                    from lpis_areas_hierarchies naz
                   inner join lpis_areas_hierarchies reg on reg.parent_id = naz.area_id and reg.tenant_id = naz.tenant_id and reg."level" = 'REG'
                   inner join lpis_areas_hierarchies pro on pro.parent_id = reg.area_id and pro.tenant_id = reg.tenant_id and pro."level" = 'PRO'
                   inner join lpis_areas_hierarchies com on com.parent_id = pro.area_id and com.tenant_id = pro.tenant_id and com."level" = 'COM'
                   where naz.tenant_id = :tenantId
                     and naz."level" = 'NAZ'
                     and §current_timestamp§ between naz.dt_insert and naz.dt_delete
                     and §current_timestamp§ between reg.dt_insert and reg.dt_delete
                     and §current_timestamp§ between pro.dt_insert and pro.dt_delete
                     and §current_timestamp§ between com.dt_insert and com.dt_delete
                     and :referenceDate between naz.day_from and naz.day_to
                     and :referenceDate between reg.day_from and reg.day_to
                     and :referenceDate between pro.day_from and pro.day_to
                     and :referenceDate between com.day_from and com.day_to
                     and <criteria>
                   order by naz.pkid, reg.pkid, pro.pkid, com.pkid
               )
                select distinct naz_pkid as pkid,'NAZ' as level_code from horizarea
               union all             
                select distinct reg_pkid as pkid,'REG' as level_code from horizarea
               union all             
                select distinct pro_pkid as pkid,'PRO' as level_code from horizarea
               union all             
                select distinct com_pkid as pkid,'COM' as level_code from horizarea
            ) t
             where (:level is null or level_code = :level)
            """;
	
	@SqlQuery(AREA_NTT_SQL_SELECT
			+ "\n and pkid in ( \n "
			+ AREA_PKIDS_BY_LEVEL_AND_CRITERIA_SQL
			+ " ) \n"
			+ " order by case when \"level\" = 'NAZ' then 1 when \"level\" = 'REG' then 2 when \"level\" = 'PRO' then 3 when \"level\" = 'COM' then 4 else 9999 end, code" 
			)
	@RegisterBeanMapper(AreaNTT.class)
	List<AreaNTT> searchAreasHierarchiesByCriteria(@BindBean ServiceSupportEnv env, @BindCriteria Criteria criteria, @Bind("level") String level);

	@SqlQuery(AREA_NTT_SQL_SELECT
			+ "\n and pkid in ( \n "
			+ AREA_PKIDS_BY_LEVEL_AND_CRITERIA_SQL
			+ " ) \n"
			+ " order by case when \"level\" = 'NAZ' then 1 when \"level\" = 'REG' then 2 when \"level\" = 'PRO' then 3 when \"level\" = 'COM' then 4 else 9999 end, code" 
			)
	@RegisterBeanMapper(AreaNTT.class)
	ResultIterator<AreaNTT> infiniteSearchAreasByCriterias(@BindBean ServiceSupportEnv env, @BindCriteria Criteria criteria, @Bind("level") String level);

}
