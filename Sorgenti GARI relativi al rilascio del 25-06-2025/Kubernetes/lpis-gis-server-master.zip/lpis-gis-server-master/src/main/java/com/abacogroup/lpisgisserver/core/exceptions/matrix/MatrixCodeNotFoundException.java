package com.abacogroup.lpisgisserver.core.exceptions.matrix;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class MatrixCodeNotFoundException extends AbstractException {

	private static final long serialVersionUID = -7383320203938964114L;

	private static final ErrorCode ERROR_CODE = ErrorCode.MATRIX_CODE_NOT_FOUND;

	public MatrixCodeNotFoundException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new MatrixCodeNotFoundExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Matrix code not found")
	public static class MatrixCodeNotFoundExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -4537914832145325185L;

		public MatrixCodeNotFoundExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
