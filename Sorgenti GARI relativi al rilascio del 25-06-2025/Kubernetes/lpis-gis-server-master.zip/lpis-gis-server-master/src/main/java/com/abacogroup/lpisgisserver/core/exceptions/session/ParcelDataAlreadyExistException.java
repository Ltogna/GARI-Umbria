package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class ParcelDataAlreadyExistException extends AbstractException {

	private static final long serialVersionUID = -5677124394818612355L;

	private static final ErrorCode ERROR_CODE = ErrorCode.PARCEL_DATA_ALREADY_EXIST;

	public ParcelDataAlreadyExistException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new ParcelDataAlreadyExistExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Parcel data already exist")
	public static class ParcelDataAlreadyExistExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 1399633973983136956L;

		public ParcelDataAlreadyExistExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
