package com.abacogroup.lpisgisserver.core.exceptions.block;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidBlockDataException extends AbstractException {

	private static final long serialVersionUID = 4976928233685679919L;

	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_BLOCK_DATA;

	public InvalidBlockDataException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new InvalidBlockDataExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Invalid block data")
	public static class InvalidBlockDataExceptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = 188154009440505024L;

		public InvalidBlockDataExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
