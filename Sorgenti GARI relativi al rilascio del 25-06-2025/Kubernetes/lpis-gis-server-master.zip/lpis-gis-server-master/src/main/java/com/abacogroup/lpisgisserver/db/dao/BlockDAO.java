package com.abacogroup.lpisgisserver.db.dao;

import java.sql.DatabaseMetaData;
import java.util.List;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.BlockCacheNTT;
import com.abacogroup.lpisgisserver.db.ntt.BlockNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface BlockDAO extends Transactional<BlockDAO>, EnhancedSqlObject {

	@SqlQuery("§select_nextval(lpis_sector_blocks_sequence)§")
	Long nextSequenceBlockVal();

	@SqlQuery("§select_nextval(lpis_sector_block_details_sequence)§")
	Long nextSequenceBlockDetailsVal();

	@SqlUpdate("insert into lpis_sector_blocks (id, tenant_id, sector_id, block) values (:id, :tenantId, :sectorId, :block)")
	void insertBlock(@Bind("id") Long id, @Bind("tenantId") String tenantId, @Bind("sectorId") Long sectorId, @Bind("block") String block);

	@SqlUpdate("insert into lpis_sector_block_details (pkid, sector_block_id, dt_insert, dt_delete, user_id_insert, user_id_delete, short_descr, description, srs, geom, world_geom)"
			+ " values (:block_details_id, :id, §current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :userId, NULL, :short_descr, :description, :srs, :geom, :world_geom)")
	void insertBlockDetail(@BindBean BlockNTT blockDetail, @Bind("userId") String userId);

	@SqlUpdate("update lpis_sector_block_details set user_id_delete = :userId, dt_delete = §current_timestamp§ where pkid = :blockDetailsId ")
	void logicallyDeleteByBlockDetailId(@Bind("blockDetailsId") Long blockDetailsId, @Bind("userId") String userId);

	@SqlQuery("select lsb.id, \n"
			+ "       lsb.sector_id, \n"
			+ "       lsb.block, \n"
			+ "       lsbd.pkid as block_details_id, \n"
			+ "       lsbd.short_descr, \n"
			+ "       lsbd.description, \n"
			+ "       lsbd.srs, \n"
			+ "       lsbd.geom, \n"
			+ "       lsbd.world_geom \n"
			+ "from lpis_sector_blocks lsb \n"
			+ "inner join lpis_sector_block_details lsbd on lsb.id = lsbd.sector_block_id \n"
			+ "where lsb.id = :blockId \n"
			+ "and lsb.tenant_id = :tenantId \n"
			+ "and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete")
	@RegisterBeanMapper(BlockNTT.class)
	BlockNTT findBlockDetailsByTenantAndId(@Bind("tenantId") String tenant, @Bind("blockId") Long blockId);

	@SqlQuery("select lsb.id, \n"
			+ "       lsb.sector_id, \n"
			+ "       lsb.block, \n"
			+ "       lsbd.pkid as block_details_id, \n"
			+ "       lsbd.short_descr, \n"
			+ "       lsbd.description, \n"
			+ "       case when :includeGeometries = 1 then lsbd.srs else null end as srs, \n"
			+ "       case when :includeGeometries = 1 then lsbd.geom else null end as geom, \n"
			+ "       case when :includeGeometries = 1 then lsbd.world_geom else null end as world_geom \n"
			+ "  from lpis_sector_blocks lsb \n"
			+ " inner join lpis_sector_block_details lsbd on lsb.id = lsbd.sector_block_id \n"
			+ " inner join lpis_sectors ls on lsb.sector_id = ls.id and lsb.tenant_id = ls.tenant_id \n"
			+ " where ls.id = :sectorId \n"
			+ "   and ls.tenant_id = :tenantId \n"
			+ "   and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete \n"
			+ "   and (:filter is null "
			+ "          or upper(lsbd.description) like upper('%'||:filter||'%') escape '$' "
			+ "          or upper(lsbd.short_descr) like upper('%'||:filter||'%')  escape '$' "
			+ "          or upper(lsb.block) like upper('%'||:filter||'%') escape '$') \n"
			+ " order by case when length(lsb.block) < 15 then substr(('000000000000000'||lsb.block), length('000000000000000'||lsb.block) -14, length('000000000000000'||lsb.block)) else lsb.block end ")
	@RegisterBeanMapper(BlockNTT.class)
	List<BlockNTT> findBlocksByTenantAndSectorIdWithFilter(@BindBean ServiceSupportEnv env, @Bind("sectorId") Long sectorId, @Bind("filter") String filter);

	@SqlQuery("select lsb.id, \n"
			+ "       lsb.sector_id, \n"
			+ "       lsb.block, \n"
			+ "       lsbd.pkid as block_details_id, \n"
			+ "       lsbd.short_descr, \n"
			+ "       lsbd.description, \n"
			+ "       lsbd.srs, \n"
			+ "       lsbd.geom, \n"
			+ "       lsbd.world_geom \n"
			+ "  from lpis_sector_blocks lsb \n"
			+ " inner join lpis_sector_block_details lsbd on lsb.id = lsbd.sector_block_id \n"
			+ " inner join lpis_sectors ls on lsb.sector_id = ls.id and lsb.tenant_id = ls.tenant_id \n"
			+ " where ls.tenant_id = :tenantId \n"
			+ "   and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete \n"
			+ "   and lsbd.srs = :srs \n"
			+ "   and §geom_have_interactions(lsbd.geom, :touchingGeometry)§ \n"
			+ " order by ls.sector, case when length(lsb.block) < 15 then substr(('000000000000000'||lsb.block), length('000000000000000'||lsb.block) -14, length('000000000000000'||lsb.block)) else lsb.block end"
			+ "")
	@RegisterBeanMapper(BlockNTT.class)
	List<BlockNTT> findBlocksByTenantSRSWithInteraction(
			@Bind("tenantId") String tenant,
			@Bind("srs") String srs,
			@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("select lsbd.pkid as block_details_id, \n"
			+ "       lsb.id as id, \n"
			+ "       lsb.block, \n"
			+ "       ls.id as sector_id, \n"
			+ "       lsbd.short_descr, \n"
			+ "       lsbd.description, \n"
			+ "       lsbd.srs, \n"
			+ "       lsbd.geom, \n"
			+ "       lsbd.world_geom \n"
			+ "from lpis_sector_blocks lsb \n"
			+ "inner join lpis_sector_block_details lsbd on lsb.id = lsbd.sector_block_id \n"
			+ "inner join lpis_sectors ls on lsb.sector_id = ls.id and lsb.tenant_id = ls.tenant_id \n"
			+ "inner join lpis_sector_details lsd on ls.id = lsd.sector_id \n"
			+ "where lsb.block = :blockCode \n"
			+ "  and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete \n"
			+ "  and §current_timestamp§ between lsd.dt_insert and lsd.dt_delete \n"
			+ "  and ls.sector = :sectorCode \n"
			+ "  and lsb.tenant_id = :tenantId")
	@RegisterBeanMapper(BlockNTT.class)
	BlockNTT findBlockDetailsByTenantBlockCodeSectorCode(
			@Bind("tenantId") String tenantId,
			@Bind("blockCode") String blockCode,
			@Bind("sectorCode") String sectorCode);

	@SqlQuery("select lsbd.sector_block_id as id, \n"
			+ "       lsbd.short_descr, \n"
			+ "       lsb.sector_id, \n"
			+ "       lsbd.description, \n"
			+ "       lsbd.srs, \n"
			+ "       lsbd.geom, \n"
			+ "       lsbd.world_geom, \n"
			+ "       geom <-> :geometry as dist \n"
			+ "from lpis_sector_blocks lsb \n"
			+ "inner join lpis_sector_block_details lsbd on lsb.id = lsbd.sector_block_id \n"
			+ "where lsb.tenant_id = :tenantId \n"
			+ "  and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete \n"
			+ "  and lsbd.srs = :srs \n"
			+ "order by dist \n"
			+ "limit 1")
	@RegisterBeanMapper(BlockNTT.class)
	BlockNTT findBlockByTenantSrsAndNearestGeomPostgres(
			@Bind("tenantId") String tenantId,
			@Bind("srs") String srs,
			@Bind("geometry") Geometry geom);

	@SqlQuery("select lsbd.sector_block_id as id, \n"
			+ "       lsb.sector_id, \n"
			+ "       lsbd.short_descr, \n"
			+ "       lsbd.description, \n"
			+ "       lsbd.srs, \n"
			+ "       lsbd.geom, \n"
			+ "       lsbd.world_geom, \n"
			+ "       sdo_nn_distance (1) as distance \n"
			+ "from lpis_sector_blocks lsb \n"
			+ "inner join lpis_sector_block_details lsbd on lsb.id = lsbd.sector_block_id \n"
			+ "where lsb.tenant_id = :tenantId \n"
			+ "  and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete \n"
			+ "  and lsbd.srs = :srs \n"
			+ "  and sdo_nn(lsbd.geom, :geometry, '', 1) = 'TRUE' \n"
			+ "order by distance \n"
			+ "fetch first row only")
	@RegisterBeanMapper(BlockNTT.class)
	BlockNTT findBlockByTenantSrsAndNearestGeomOracle(
			@Bind("tenantId") String tenantId,
			@Bind("srs") String srs,
			@Bind("geometry") Geometry geom);

	default BlockNTT findBlockByTenantSrsAndNearestGeom(String tenantId, String srs, Geometry geom) {
		String dbType = this.getHandle().queryMetadata(DatabaseMetaData::getDatabaseProductName);

		return dbType.toLowerCase().contains("postgresql")
				? findBlockByTenantSrsAndNearestGeomPostgres(tenantId, srs, geom)
				: findBlockByTenantSrsAndNearestGeomOracle(tenantId, srs, geom);
	}

	@SqlQuery("select t.*, \n"
			+ "       (select geom from lpis_sector_block_details where pkid = t.block_details_id fetch first row only) as geom, \n"
			+ "       (select world_geom from lpis_sector_block_details where pkid = t.block_details_id fetch first row only) as world_geom \n"
			+ "  from ( \n"
			+ "       select distinct lsb.id, \n"
			+ "              lsb.block, \n"
			+ "              lsb.sector_id, \n"
			+ "              lsbd.pkid as block_details_id, \n"
			+ "              lsbd.short_descr, \n"
			+ "              lsbd.description, \n"
			+ "              lsbd.srs, \n"
			+ "              case when length(lsb.block) < 15 then substr(('000000000000000'||lsb.block), length('000000000000000'||lsb.block) -14, length('000000000000000'||lsb.block)) else lsb.block end as block_for_order \n"
			+ "       from lpis_parcels lp \n"
			+ "       inner join lpis_parcel_details lpd on lp.id = lpd.parcel_id \n"
			+ "       inner join lpis_sector_blocks lsb on lp.sector_block_id = lsb.id and lp.tenant_id = lsb.tenant_id \n"
			+ "       inner join lpis_sector_block_details lsbd on lsb.id = lsbd.sector_block_id \n"
			+ "       inner join lpis_sectors ls on lsb.sector_id = ls.id and lsb.tenant_id = ls.tenant_id \n"
			+ "       inner join lpis_sector_details lsd on ls.id = lsd.sector_id \n"
			+ "       where lp.tenant_id = :tenantId \n"
			+ "         and :referenceDate between lpd.day_from and lpd.day_to \n"
			+ "         and §current_timestamp§ between lpd.dt_insert and lpd.dt_delete \n"
			+ "         and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete \n"
			+ "         and §current_timestamp§ between lsd.dt_insert and lsd.dt_delete \n"
			+ "         and ls.sector = :sectorCode \n"
			+ "         and lp.id in (<parcelIds>) \n"
			+ "         and (:blockFilter is null or upper(lsb.block) like upper('%'||:blockFilter||'%') escape '$') \n"
			+ "       order by case when length(lsb.block) < 15 then substr(('000000000000000'||lsb.block), length('000000000000000'||lsb.block) -14, length('000000000000000'||lsb.block)) else lsb.block end \n"
			+ ") t")
	@RegisterBeanMapper(BlockNTT.class)
	ResultIterator<BlockNTT> findInfiniteBlocksByTenantSectorCodeAndParcelsWithFilter(
			@Bind("tenantId") String tenantId,
			@Bind("sectorCode") String sectorCode,
			@Bind("referenceDate") AbsoluteDate referenceDate,
			@BindList("parcelIds") List<Long> parcelIds,
			@Bind("blockFilter") String blockFilter);
	
	@SqlQuery("select lsb.id as id, \n"
			+ "       ls.id as sector_id, \n"
			+ "       lsb.block, \n"
			+ "       lsbd.srs \n"
			+ "from lpis_sector_blocks lsb \n"
			+ "inner join lpis_sector_block_details lsbd on lsb.id = lsbd.sector_block_id \n"
			+ "inner join lpis_sectors ls on lsb.sector_id = ls.id and lsb.tenant_id = ls.tenant_id \n"
			+ "inner join lpis_sector_details lsd on ls.id = lsd.sector_id \n"
			+ "where lsb.block = :blockCode \n"
			+ "  and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete \n"
			+ "  and §current_timestamp§ between lsd.dt_insert and lsd.dt_delete \n"
			+ "  and ls.sector = :sectorCode \n"
			+ "  and lsb.tenant_id = :tenantId")
	@RegisterBeanMapper(BlockCacheNTT.class)
	BlockCacheNTT findBlockCacheByTenantBlockCodeSectorCode(
			@Bind("tenantId") String tenantId,
			@Bind("blockCode") String blockCode,
			@Bind("sectorCode") String sectorCode);
}
