package com.abacogroup.lpisgisserver.core.models.georaster;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Georaster3dData {
	
	private List<Double> values;

}
