package com.abacogroup.lpisgisserver.core;

import java.time.Duration;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.UnitDictionaryTables;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.LandCoverNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.ParcelNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.units.GenericUnitException;
import com.abacogroup.lpisgisserver.core.exceptions.units.LandCoverCodeNotCompatibleException;
import com.abacogroup.lpisgisserver.core.exceptions.units.UnitCodeNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.units.vine.VineyardAndDoigtCodeNotCompatibleException;
import com.abacogroup.lpisgisserver.core.support.CreateOrUpdateUnitPayload;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.LandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.ParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.UnitCodesDAO;
import com.abacogroup.lpisgisserver.db.dao.UnitsDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineDoIgtNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineyardNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.pub.CreateOrUpdateVineUnitPayloadV1;
import com.abacogroup.lpisgisserver.resources.req.pub.bulk.UnitsWithDictionaryCodesPayloadV1;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UnitsSupportService extends BaseService {

	private ParcelsDAO parcelsDAO;
	private LandCoversDAO landCoversDAO;
	private UnitsDAO unitsDAO;
	private UnitCodesDAO unitCodesDAO;

	private Cache<String, List<String>> unitsCache; //KEY: tenant|tableName|type_code

	public UnitsSupportService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf, 
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, 
			PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.parcelsDAO = dc.getParcelsDAO();
		this.landCoversDAO = dc.getLandCoversDAO();
		this.unitsDAO = dc.getUnitsDAO();
		this.unitCodesDAO = dc.getUnitCodesDAO();

		unitsCache = Caffeine.newBuilder()
				.maximumSize(20)
				.expireAfterAccess(Duration.ofHours(3))
				.build();

	}

	public void checkServiceSupportEnv(ServiceSupportEnv env, UnitType unitType, Operation operation) {

		List<ParcelNTT> parcels = parcelsDAO.findByIdTenantId(env.getParcelId(), env.getTenantId());
		if (parcels == null || parcels.size() != 1) {
			ParcelNotFoundException ex = new ParcelNotFoundException(Status.NOT_FOUND, operation, ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		List <LandCoverNTT> landCovers = landCoversDAO.findByParcelIds(env, List.of(env.getParcelId()));
		LandCoverNTT lc = landCovers.stream()
				.filter(l -> l.getLand_cover_id().equals(env.getLandCoverId()))
				.findFirst().orElse(null);

		if(lc == null) {
			LandCoverNotFoundException ex = new LandCoverNotFoundException(Status.NOT_FOUND, operation, ErrorField.LANDCOVER_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		//check landcover code compatibility with vine-unit
		if(unitsDAO.checkLandCoverCompatibility(env, lc.getLand_cover_code(), unitType) != 1){
			LandCoverCodeNotCompatibleException ex = new LandCoverCodeNotCompatibleException(Status.NOT_FOUND, operation, ErrorField.LANDCOVER_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

	}
	
	public VineDoIgtNTT getVineDoIgtNTTByCode(ServiceSupportEnv env, String doIgtCode, Operation operation) {
		VineDoIgtNTT vineDoIgtNTT = unitCodesDAO.findVineDoigtByCode(env.getTenantId(), doIgtCode);
		if(vineDoIgtNTT == null) {
			UnitCodeNotFoundException ex = new UnitCodeNotFoundException(Status.NOT_FOUND, operation, ErrorField.VINE_DOIGT_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());
			
			throw ex;
		}
		
		return vineDoIgtNTT;
	}

	public VineyardNTT getVineyardByCode(ServiceSupportEnv env, String vineyardCode, Operation operation) {
		VineyardNTT vineyardNTT = unitCodesDAO.findVineyardByCode(env.getTenantId(), vineyardCode);
		if(vineyardNTT == null) {
			UnitCodeNotFoundException ex = new UnitCodeNotFoundException(Status.NOT_FOUND, operation, ErrorField.VINEYARD_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());
			
			throw ex;
		}
		
		return vineyardNTT;
		
	}
	
	public void checkVineyardDoigtCompatibility(ServiceSupportEnv env, String vineyardCode, String doigtCode, Operation operation) {

		VineyardNTT vineyardNTT = getVineyardByCode(env, vineyardCode, operation);
		VineDoIgtNTT doIgtNTT = getVineDoIgtNTTByCode(env, doigtCode, operation);
		
		if(unitCodesDAO.checkVineyardDoigtCompatibility(vineyardNTT.getId(), doIgtNTT.getId()) != 1) {
			VineyardAndDoigtCodeNotCompatibleException ex = new VineyardAndDoigtCodeNotCompatibleException(Status.BAD_REQUEST,
					operation, ErrorField.VINEYARD_CODE, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()),
					env.getLang());

			log.error(ex.getBody().getLogErrorMessage());
			
			throw ex;
		}
		
	}
	
	private void internalExceptionIfNull(ServiceSupportEnv env, Operation operation, ErrorField errorField) {
			UnitCodeNotFoundException ex = new UnitCodeNotFoundException(Status.NOT_FOUND, operation,
					errorField, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
	}

	public String getCreateOrUpdateVineUnitCodeIfExist(ServiceSupportEnv env, CreateOrUpdateVineUnitPayloadV1 payload, 
			UnitDictionaryTables dictionaryTable, Operation operation, ErrorField errorField){
		
		String payloadCode = dictionaryTable.getCodeValue(payload);
		UnitType typeCode = payload.getUnitType();
		
		String code = internalGetUnitsCodeIfExists(env, dictionaryTable, typeCode, payloadCode);
		
		if(payloadCode != null && code == null) {
			internalExceptionIfNull(env, operation, errorField);
		}
		
		return code;
	}
	
	public <T extends CreateOrUpdateUnitPayload> String getBulkUnitCodeIfExist(ServiceSupportEnv env, T payload, UnitDictionaryTables dictionaryTable, String code){
		UnitType typeCode = payload.getUnitType();
		return internalGetUnitsCodeIfExists(env, dictionaryTable, typeCode, code);
	}
	
	public String getVineUnitCodeIfExist(ServiceSupportEnv env, UnitsWithDictionaryCodesPayloadV1 payload, UnitDictionaryTables dictionaryTable, UnitType unitType){

		String code = dictionaryTable.getCodeValue(payload);
		
		return internalGetUnitsCodeIfExists(env, dictionaryTable, unitType, code);
	}

	private String internalGetUnitsCodeIfExists(ServiceSupportEnv env, UnitDictionaryTables dictionaryTable, UnitType typeCode, String code) {
		
		if(env == null || env.getTenantId() == null) {
			GenericUnitException ex = new GenericUnitException(Status.BAD_REQUEST, Operation.GET_UNITS_CODE, ErrorField.REQUEST,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		if(dictionaryTable == null) {
			GenericUnitException ex = new GenericUnitException(Status.BAD_REQUEST, Operation.GET_UNITS_CODE, ErrorField.DICTIONARY_TABLE,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");
			
			log.error(ex.getBody().getLogErrorMessage());
			
			throw ex;
		}
		
		String tenantId = env.getTenantId();

		String key = tenantId + "|" + dictionaryTable.getTableName() + "|" + typeCode;
		List<String> codes = unitsCache.getIfPresent(key);

		//load codes
		if(codes == null ) {
			return loadCode(env, dictionaryTable.getTableName(), typeCode, code);
		}

		String foundCode = codes.stream().filter(c -> c.equals(code)).findFirst().orElse(null);

		return foundCode != null ? foundCode : loadCode(env, dictionaryTable.getTableName(), typeCode, code);
	}

	private String loadCode(ServiceSupportEnv env, String tableName, UnitType typeCode, String code) {

		List<String> codeList = unitCodesDAO.getCodeByTenantTableNameTypeCode(env.getTenantId(), tableName, typeCode);
		if(codeList == null || codeList.isEmpty()) {
			return null;
		}
		String key = env.getTenantId() + "|" + tableName + "|" + typeCode;
		unitsCache.put(key, codeList);
		
		return codeList.stream().filter(c -> c.equals(code)).findFirst().orElse(null);
		
		
	}	
}
