package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.BlockNTT;
import com.abacogroup.lpisgisserver.resources.res.viewer.ViewerBlockDetails;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ViewerBlockDetailsMapper {

	ViewerBlockDetailsMapper INSTANCE = Mappers.getMapper(ViewerBlockDetailsMapper.class);

	@Mapping(source = "block", target = "block_code")
	ViewerBlockDetails entityToDto(BlockNTT entity);

	@Mapping(source = "block_code", target = "block")
	@Mapping(target = "block_details_id", ignore = true)
	@Mapping(target = "srs", ignore = true)
	@Mapping(target = "geom", ignore = true)
	@Mapping(target = "world_geom", ignore = true)
	BlockNTT dtoToEntity(ViewerBlockDetails dto);
}
