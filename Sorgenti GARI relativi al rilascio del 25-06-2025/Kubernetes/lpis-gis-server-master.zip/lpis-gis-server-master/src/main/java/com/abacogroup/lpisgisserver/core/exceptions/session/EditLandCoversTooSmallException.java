package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class EditLandCoversTooSmallException extends AbstractException {

	private static final long serialVersionUID = 3439005461570822996L;

	private static final ErrorCode ERROR_CODE = ErrorCode.EDIT_LANDCOVERS_TOO_SMALL;

	public EditLandCoversTooSmallException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new EditLandCoversTooSmallExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Some land covers have the area too small")
	public static class EditLandCoversTooSmallExceptionBody extends AbstractExceptionBody {
	
		private static final long serialVersionUID = 8018462042674848513L;

		public EditLandCoversTooSmallExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
