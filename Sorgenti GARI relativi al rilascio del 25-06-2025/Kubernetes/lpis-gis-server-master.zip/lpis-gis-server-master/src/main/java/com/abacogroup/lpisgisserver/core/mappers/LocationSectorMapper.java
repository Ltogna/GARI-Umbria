package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.resources.res.LocationSector;
import com.abacogroup.lpisgisserver.resources.res.pub.SectorV1;

@Mapper(uses = AbsoluteDateMapper.class)
public interface LocationSectorMapper {

	LocationSectorMapper INSTANCE = Mappers.getMapper(LocationSectorMapper.class);

	@InheritInverseConfiguration
	@Mapping(target = "code", source = "sectorCode")
	@Mapping(target = "description", source = "shortDescr")
	LocationSector toLocationSector(SectorV1 sectorV1);

}
