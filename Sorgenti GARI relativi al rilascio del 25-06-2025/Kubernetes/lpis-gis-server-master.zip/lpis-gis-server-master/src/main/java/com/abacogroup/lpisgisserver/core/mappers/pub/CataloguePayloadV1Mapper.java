package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.resources.req.CataloguePayload;
import com.abacogroup.lpisgisserver.resources.req.pub.CataloguePayloadV1;

@Mapper
public interface CataloguePayloadV1Mapper {

	CataloguePayloadV1Mapper INSTANCE = Mappers.getMapper(CataloguePayloadV1Mapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "geom", source = "touchingGeometry")
	CataloguePayload toPrivPayload(CataloguePayloadV1 entity);
	
}
