package com.abacogroup.lpisgisserver.core.models;

import java.time.LocalDateTime;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.resources.res.Block;
import com.abacogroup.lpisgisserver.resources.res.Sector;

import lombok.Data;

@Data
public class EditParcelData {
	private Long parentParcelId;
	private AbsoluteDate dayTo;
	private Block block;
	private Sector sector;
	private String clientRef;
	private String parcel;
	private LocalDateTime lastUpdate;
	private EditStatus editStatus;
	private String sdeCode;
	private String externalCode;
}
