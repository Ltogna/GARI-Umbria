package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.resources.res.layers.WmsLayer;
import com.abacogroup.lpisgisserver.resources.res.pub.WmsLayerV1;

@Mapper(uses = AbsoluteDateMapper.class)
public interface WmsLayerMapper {

	WmsLayerMapper INSTANCE = Mappers.getMapper(WmsLayerMapper.class);

	@Mapping(target = "snapElementType", ignore = true)
	@Mapping(target = "layerType", source = "publicLayerType")
	WmsLayer mapToWmsLayer(WmsLayerV1 layer);

	@Mapping(target = "code", ignore = true)
	@Mapping(target = "publicLayerType", source = "layerType")
	WmsLayerV1 mapToWmsLayerV1(WmsLayer layer);
}
