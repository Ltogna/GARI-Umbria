package com.abacogroup.lpisgisserver.db.dao;

import java.sql.DatabaseMetaData;
import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.BlockNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.db.ntt.SectorNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface EditParcelsDAO extends Transactional<EditParcelsDAO>, EnhancedSqlObject {

	@SqlQuery("§select_nextval(lpis_edit_parcels_sequence)§")
	Long nextSequenceVal();

	@SqlQuery("select coalesce(min(parcel_id), 0) - 1 from lpis_edit_parcels where parcel_id < 1")
	Long nextNewParcelIdVal();

	@SqlUpdate("INSERT INTO lpis_edit_parcels (id, session_uuid, parcel_id, srs, area_sqm, geom, parcel_code, sector_block_id, edit_status, parent_id, external_code) "
			+ "VALUES(:edit_id, :sessionId, :parcel_id, :srs, :area_sqm, :geom, :parcel, :block.id, :edit_status, :parent_id, :external_code)")
	void insert(@Bind("sessionId") String sessionId, @BindBean ParcelNTT rs);

	@SqlQuery("\n"
			+ "select count(*) from ( \n"
			+ "  select session_uuid, parcel_id \n"
			+ "    from lpis_lock_parcels \n"
			+ "   where parcel_id in (<parcelids>) \n"
			+ "     and session_uuid = :sessionId \n"
			+ "  union \n"
			+ "  select session_uuid, parcel_id \n"
			+ "    from lpis_edit_parcels \n"
			+ "   where parcel_id in (<parcelids>) \n"
			+ "     and session_uuid = :sessionId \n"
			+ ") t\n")
	Long countByIdSessionId(@Bind("sessionId") String sessionId, @BindList("parcelids") List<Long> parcelids);

	@SqlUpdate("update lpis_edit_parcels \n"
			+ "   set parcel_id = :parcel_id, \n"
			+ "       srs = :srs, \n"
			+ "       area_sqm = :area_sqm, \n"
			+ "       geom = :geom, \n"
			+ "       parcel_code = :parcel, \n"
			+ "       sector_block_id = :block.id, \n"
			+ "       edit_status = :edit_status \n"
			+ " where id = :edit_id and session_uuid = :sessionId \n")
	@RegisterBeanMapper(ParcelNTT.class)
	void update(@BindBean ParcelNTT rs, @Bind("sessionId") String sessionId);

	@SqlUpdate("update lpis_edit_parcels \n"
			+ "   set srs = :srs, \n"
			+ "       area_sqm = :area_sqm, \n"
			+ "       geom = :geom, \n"
			+ "       edit_status = :edit_status \n"
			+ " where parcel_id = :parcel_id and session_uuid = :sessionId \n")
	@RegisterBeanMapper(ParcelNTT.class)
	void updateGeometryByParcelId(@BindBean ParcelNTT rs, @Bind("sessionId") String sessionId);

	@SqlUpdate("update lpis_edit_parcels \n"
			+ "   set parcel_code = :parcel, \n"
			+ "       sector_block_id = :block.id, \n"
			+ "       edit_status = :edit_status, \n"
			+ "       external_code = :external_code \n"
			+ " where parcel_id = :parcel_id and session_uuid = :sessionId")
	@RegisterBeanMapper(ParcelNTT.class)
	@RegisterBeanMapper(BlockNTT.class)
	void updateParcelDataByParcelId(@BindBean ParcelNTT rs, @Bind("sessionId") String sessionId);

	@SqlUpdate("delete from lpis_edit_parcels where session_uuid = :sessionId")
	void deleteBySessionId(@Bind("sessionId") String sessionId);

	@SqlUpdate("delete from lpis_edit_parcels where session_uuid = :sessionId and parcel_id = :parcelId")
	void deleteBySessionIdParcelId(@Bind("sessionId") String sessionId, @Bind("parcelId") Long parcelId);

	@SqlQuery("\n"
			+ "select ep.id as edit_id, \n"
			+ "       ep.parcel_id, \n"
			+ "       ep.parcel_code as parcel, \n"
			+ "       ep.external_code, \n"
			+ "       coalesce(dp.day_from, :referenceDate) as day_from, \n"
			+ "       coalesce(dp.day_to, '99991231') as day_to, \n"
			+ "       ep.sector_block_id as block_id, \n"
			+ "       sb.sector_id as block_sector_id, \n"
			+ "       sb.block as block_block, \n"
			+ "       lsbd.short_descr as block_short_descr, \n"
			+ "       lsbd.description as block_description, \n"
			+ "       lsd.sector_id as sector_id, \n"
			+ "       ls.sector as sector_sector, \n"
			+ "       lsd.short_descr as sector_short_descr, \n"
			+ "       lsd.description as sector_description, \n"
			+ "       ep.area_sqm, \n"
			+ "       case when ep.geom is null then null else ep.srs end as srs, \n"
			+ "       ep.geom, \n"
			+ "       ep.parent_id, \n"
			+ "       ep.edit_status, \n"
			+ "       dp.dt_insert as last_update \n"
			+ "  from lpis_edit_parcels ep \n"
			+ "  left join lpis_parcel_details dp on ep.parcel_id = dp.parcel_id \n"
			+ "        and §current_timestamp§ between dp.dt_insert and dp.dt_delete \n"
			+ "        and :referenceDate between dp.day_from and dp.day_to \n"
			+ "  left join lpis_sector_blocks sb on ep.sector_block_id = sb.id \n"
			+ "  left join lpis_sector_block_details lsbd on sb.id  = lsbd.sector_block_id \n"
			+ "       and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete \n"
			+ "  left join lpis_sectors ls on sb.sector_id = ls.id \n"
			+ "  left join lpis_sector_details lsd on ls.id = lsd.sector_id \n"
			+ "       and §current_timestamp§ between lsd.dt_insert and lsd.dt_delete \n"
			+ " where ep.session_uuid = :sessionId \n"
			+ "   and (:parcelId is null or ep.parcel_id = :parcelId) \n"
			+ " order by ep.parcel_id "
			+ "")
	@RegisterBeanMapper(ParcelNTT.class)
	@RegisterBeanMapper(BlockNTT.class)
	@RegisterBeanMapper(SectorNTT.class)
	List<ParcelNTT> findInEditBySessionId(
			@Bind("sessionId") String sessionId,
			@Bind("referenceDate") AbsoluteDate referenceDate,
			@Bind("parcelId") Long parcelId);

	@SqlQuery("\n"
			+ "select null as edit_id, \n"
			+ "       p.id as parcel_id, \n"
			+ "       p.parcel as parcel, \n"
			+ "       p.external_code, "
			+ "       d.pkid, \n"
			+ "       d.day_from, \n"
			+ "       d.day_to, \n"
			+ "       d.srs, \n"
			+ "       p.sector_block_id as block_id, \n"
			+ "       sb.sector_id as block_sector_id, \n"
			+ "       sb.block as block_block, \n"
			+ "       lsbd.short_descr as block_short_descr, \n"
			+ "       lsbd.description as block_description, \n"
			+ "       lsd.sector_id as sector_id, \n"
			+ "       ls.sector as sector_sector, \n"
			+ "       lsd.short_descr as sector_short_descr, \n"
			+ "       lsd.description as sector_description, \n"
			+ "       d.area_sqm, \n"
			+ "       d.geom, \n"
			+ "       null as parent_id, \n"
			+ "       'NOT_IN_EDIT' as edit_status, \n"
			+ "       d.dt_insert as last_update \n"
			+ "  from lpis_parcels p \n"
			+ " inner join lpis_parcel_details d on p.id = d.parcel_id \n"
			+ " inner join lpis_sector_blocks sb on p.sector_block_id = sb.id \n"
			+ " inner join lpis_sector_block_details lsbd on sb.id  = lsbd.sector_block_id \n"
			+ " inner join lpis_sectors ls on sb.sector_id = ls.id \n"
			+ " inner join lpis_sector_details lsd on ls.id = lsd.sector_id \n"
			+ " where p.tenant_id = :tenantId \n"
			+ "   and not exists (select 1 from lpis_edit_parcels ep where ep.session_uuid = :sessionId and ep.parcel_id = d.parcel_id) \n"
			+ "   and §current_timestamp§ between d.dt_insert and d.dt_delete \n"
			+ "   and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete \n"
			+ "   and §current_timestamp§ between lsd.dt_insert and lsd.dt_delete \n"
			+ "   and :referenceDate between d.day_from and d.day_to \n"
			+ "   and ((p.id in "
			+ "            (select lp.parcel_id "
			+ "               from lpis_lock_parcels lp "
			+ "              where lp.session_uuid = :sessionId "
			+ "                and (:parcelId is null or lp.parcel_id = :parcelId)) "
			+ "         ) or p.id = :parcelId "
			+ "       )"
			+ "")
	@RegisterBeanMapper(ParcelNTT.class)
	@RegisterBeanMapper(BlockNTT.class)
	@RegisterBeanMapper(SectorNTT.class)
	List<ParcelNTT> findNotInEditBySessionId( 
			@BindBean ServiceSupportEnv env,
			@Bind("parcelId") Long parcelId);

	@SqlQuery("\n"
			+ "select ep.parcel_id, ep.parcel_code as parcel, ep.srs, ep.geom, ep.area_sqm, ep.parent_id, ep.sector_block_id as block_id, ep.edit_status \n"
			+ "  from lpis_edit_parcels ep \n"
			+ " where ep.parcel_id in (<parcelIds>)\n")
	@RegisterBeanMapper(ParcelNTT.class)
	@RegisterBeanMapper(BlockNTT.class)
	public List<ParcelNTT> getInEditingPolygons(
			@BindList("parcelIds") List<Long> parcelIds);

	@SqlQuery("\n"
			+ "select d.parcel_id, \n"
			+ "       p.parcel, \n"
			+ "       d.srs, \n"
			+ "       d.geom, \n"
			+ "       d.area_sqm, \n"
			+ "       null as parent_id, \n"
			+ "       p.sector_block_id as block_id, \n"
			+ "       'NOT_IN_EDIT' as edit_status, \n"
			+ "       d.dt_insert as last_update"
			+ "  from lpis_parcels p \n"
			+ " inner join lpis_parcel_details d on p.id = d.parcel_id \n"
			+ " where p.tenant_id = :tenantId \n"
			+ "   and d.parcel_id in (<parcelIds>) \n"
			+ "   and not exists (select 1 from lpis_edit_parcels ep where ep.parcel_id = d.parcel_id) \n"
			+ "   and §current_timestamp§ between d.dt_insert and d.dt_delete \n"
			+ "   and :referenceDate between d.day_from and d.day_to \n")
	@RegisterBeanMapper(ParcelNTT.class)
	@RegisterBeanMapper(BlockNTT.class)
	public List<ParcelNTT> getNotInEditingPolygons(
			@BindBean ServiceSupportEnv env,
			@BindList("parcelIds") List<Long> parcelIds);

	@SqlQuery("\n"
			+ "select id as edit_id, \n"
			+ "       parcel_id, \n"
			+ "       parcel_code as parcel, \n"
			+ "       srs, \n"
			+ "       geom, \n"
			+ "       area_sqm, \n"
			+ "       parent_id, \n"
			+ "       sector_block_id as block_id, \n"
			+ "       edit_status, \n"
			+ "       external_code \n"
			+ "  from lpis_edit_parcels \n"
			+ " where session_uuid = :sessionId \n"
			+ "   and §geom_have_interactions(geom, :touchingGeometry)§ \n"
			+ "")
	@RegisterBeanMapper(ParcelNTT.class)
	@RegisterBeanMapper(BlockNTT.class)
	public List<ParcelNTT> getEditParcelsWithInteraction(
			@BindBean ServiceSupportEnv env,
			@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("\n"
			+ "select p.id as parcel_id, \n"
			+ "       p.parcel, \n"
			+ "       d.srs, \n"
			+ "       d.geom, \n"
			+ "       d.area_sqm, \n"
			+ "       null as parent_id, \n"
			+ "       p.sector_block_id as block_id, \n"
			+ "       'NOT_IN_EDIT' as edit_status, \n"
			+ "       d.dt_insert as last_update, \n"
			+ "       p.external_code \n"
			+ "  from lpis_lock_parcels lp \n"
			+ " inner join lpis_parcels p on lp.parcel_id = p.id \n"
			+ " inner join lpis_parcel_details d on p.id = d.parcel_id \n"
			+ " left join lpis_edit_parcels ep on lp.session_uuid = ep.session_uuid and lp.parcel_id = ep.parcel_id \n"
			+ " where p.tenant_id = :tenantId \n"
			+ "   and §current_timestamp§ between d.dt_insert and d.dt_delete \n"
			+ "   and :referenceDate between d.day_from and d.day_to \n"
			+ "   and d.srs = :srs \n"
			+ "   and lp.session_uuid = :sessionId \n"
			+ "   and ep.parcel_id is null \n"
			+ "   and §geom_have_interactions(d.geom, :touchingGeometry)§ \n"
			+ " \n"
			+ "union all \n"
			+ " \n"
			+ "select p.id as parcel_id, \n"
			+ "       p.parcel, \n"
			+ "       d.srs, \n"
			+ "       d.geom, \n"
			+ "       d.area_sqm, \n"
			+ "       null as parent_id, \n"
			+ "       p.sector_block_id as block_id, \n"
			+ "       'NOT_IN_EDIT' as edit_status, \n"
			+ "       d.dt_insert as last_update, \n"
			+ "       p.external_code \n"
			+ "  from lpis_parcels p \n"
			+ " inner join lpis_parcel_details d on p.id = d.parcel_id \n"
			+ " left join lpis_lock_parcels lp on lp.parcel_id = p.id and lp.session_uuid = :sessionId \n"
			+ " where p.tenant_id = :tenantId \n"
			+ "   and §current_timestamp§ between d.dt_insert and d.dt_delete \n"
			+ "   and :referenceDate between d.day_from and d.day_to \n"
			+ "   and d.srs = :srs \n"
			+ "   and lp.parcel_id is null \n"
			+ "   and §geom_have_interactions(d.geom, :touchingGeometry)§"
			+ "")
	@RegisterBeanMapper(ParcelNTT.class)
	@RegisterBeanMapper(BlockNTT.class)
	public List<ParcelNTT> getNonEditParcelsWithInteraction(
			@BindBean ServiceSupportEnv env,
			@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("\n"
			+ "select id as edit_id, \n"
			+ "       parcel_id, \n"
			+ "       parcel_code as parcel, \n"
			+ "       srs, \n"
			+ "       geom, \n"
			+ "       area_sqm, \n"
			+ "       parent_id, \n"
			+ "       sector_block_id as block_id, \n"
			+ "       edit_status \n"
			+ " from lpis_edit_parcels \n "
			+ " where session_uuid = :sessionId\n "
			+ "   and geom is not null \n "
			+ "   and parcel_code is null \n"
			+ "   and (:parcelId is null or parcel_id = :parcelId) \n")
	@RegisterBeanMapper(ParcelNTT.class)
	List<ParcelNTT> findNotValidNameParcelsForSession(@Bind("sessionId") String uuid, @Bind("parcelId") Long parcelId);
	
	@SqlQuery("\n"
			+ "select id as edit_id, \n"
			+ "       parcel_id, \n"
			+ "       parcel_code as parcel, \n"
			+ "       srs, \n"
			+ "       geom, \n"
			+ "       area_sqm, \n"
			+ "       parent_id, \n"
			+ "       sector_block_id as block_id, \n"
			+ "       edit_status \n"
			+ " from lpis_edit_parcels \n "
			+ " where session_uuid = :sessionId\n "
			+ "   and geom is not null \n "
			+ "   and edit_status not in (<excludes>) \n"
			+ "   and round(§geom_area(geom)§) < :minSize \n"
			+ "   and (:parcelId is null or parcel_id = :parcelId) \n ")
	@RegisterBeanMapper(ParcelNTT.class)
	List<ParcelNTT> findNotValidAreaParcelsForSession(
			@Bind("sessionId") String uuid,
			@Bind("parcelId") Long parcelId,
			@Bind("minSize") Integer minSize,
			@BindList("excludes") List<EditStatus> excludes);

	@SqlQuery("\n"
			+ "select ep.geom \n"
			+ "  from lpis_edit_parcels ep \n"
			+ " where ep.geom is not null \n"
			+ "   and ep.session_uuid = :sessionId \n"
			+ "   and ep.parcel_id = :parcelId \n"
			+ "union all \n"
			+ "select d.geom \n"
			+ "  from lpis_lock_parcels lp \n"
			+ " inner join lpis_parcels p on lp.parcel_id = p.id \n"
			+ " inner join lpis_parcel_details d on p.id = d.parcel_id \n"
			+ "where p.tenant_id = :tenantId \n"
			+ "   and §current_timestamp§ between d.dt_insert and d.dt_delete \n"
			+ "   and lp.session_uuid = :sessionId \n"
			+ "   and :referenceDate between d.day_from and d.day_to \n"
			+ "   and p.id = :parcelId \n"
			+ "   and p.id not in (select ep.parcel_id from lpis_edit_parcels ep where ep.geom is not null and ep.session_uuid = :sessionId) \n")
	public List<Geometry> getParcelGeomFromParcelId(
			@BindBean ServiceSupportEnv env,
			@Bind("parcelId") Long parcelId);

	@SqlQuery("select lp.id as parcel_id, \n"
			+ "       lp.parcel, \n"
			+ "       lp.sector_block_id as block_id \n"
			+ "from lpis_parcels lp \n"
			+ "inner join lpis_sector_block_details lsbd on lp.sector_block_id = lsbd.sector_block_id \n"
			+ "where lp.tenant_id = :tenantId \n"
			+ "  and lp.sector_block_id = :blockId \n"
			+ "  and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete \n"
			+ "  and lp.id not in ( select lep.parcel_id from lpis_edit_parcels lep where lep.session_uuid = :sessionId)")
	@RegisterBeanMapper(ParcelNTT.class)
	List<ParcelNTT> findAllNotEditParcelsByBlockIdAndSessionId(
			@Bind("blockId") Long blockId,
			@Bind("sessionId") String sessionId,
			@Bind("tenantId") String tenantId);

	@SqlQuery("select lep.id as edit_id, \n"
			+ "       lep.parcel_id, \n"
			+ "       lep.srs, \n"
			+ "       lep.area_sqm, \n"
			+ "       lep.geom, \n"
			+ "       lep.parent_id, \n"
			+ "       lep.parcel_code as parcel, \n"
			+ "       lep.sector_block_id as block_id, \n"
			+ "       lep.edit_status \n"
			+ "from lpis_edit_parcels lep \n"
			+ "inner join lpis_sector_block_details lsbd on lep.sector_block_id = lsbd.sector_block_id \n"
			+ "where lep.sector_block_id = :blockId \n"
			+ "  and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete \n"
			+ "  and lep.session_uuid = :sessionId")
	@RegisterBeanMapper(ParcelNTT.class)
	List<ParcelNTT> findAllEditParcelsByBlockIdAndSessionId(
			@Bind("blockId") Long blockId,
			@Bind("sessionId") String sessionId);

	@SqlQuery("select count(*) from ( \n"
			+ "   select \n"
			+ "      p.id as id \n"
			+ "   from \n"
			+ "      lpis_parcels p  \n"
			+ "   where \n"
			+ "      p.tenant_id = :tenantId \n"
			+ "      and p.id <> :parcelId \n"
			+ "      and p.external_code = :externalCode \n"
			+ "      and not exists (select 1 from lpis_edit_parcels ep where ep.session_uuid = :sessionId and ep.parcel_id = p.id)  \n"
			+ " \n"
			+ "union all \n"
			+ " \n"
			+ "   select \n"
			+ "      ep.parcel_id as id \n"
			+ "   from \n"
			+ "      lpis_edit_parcels ep \n"
			+ "   where \n"
			+ "      ep.session_uuid  = :sessionId  \n"
			+ "      and ep.parcel_id <> :parcelId \n"
			+ "      and ep.external_code = :externalCode \n"
			+ ") t \n"
			+ "")
	Integer countParcelWithExternalCode(@BindBean ServiceSupportEnv env, @Bind("parcelId") Long parcelId,
			@Bind("externalCode") String externalCode);

	
	
	
	default String findAlsoInEditMaxParcelByBlockId(String tenantId, String subSeparator, Long blockId, String sessionId) {
		String dbType = this.getHandle().queryMetadata(DatabaseMetaData::getDatabaseProductName);

		return dbType.toLowerCase().contains("postgresql")
				? findAlsoInEditMaxParcelByBlockIdPostgres(tenantId, subSeparator, blockId, sessionId)
				: findAlsoInEditMaxParcelByBlockIdOracle(tenantId, subSeparator, blockId, sessionId);
	}
	

	@SqlQuery("""
                WITH ExtractedParts AS (
                  SELECT
                    CASE
                      WHEN POSITION(:subSeparator IN parcel) > 0 
                      THEN SUBSTR(parcel, 1, POSITION(:subSeparator IN parcel) - 1)
                      ELSE parcel
                    END AS extracted_value
                  FROM (
                      select lp.parcel from lpis_parcels lp 
                       inner join lpis_sector_block_details lsbd on lp.sector_block_id = lsbd.sector_block_id 
                       where lp.tenant_id = :tenantId 
                         and lp.sector_block_id = :blockId 
                         and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete
                         and lp.id not in ( select lep.parcel_id from lpis_edit_parcels lep where lep.session_uuid = :sessionId)
                         and lp.parcel IS NOT NULL 
                       union
                       select lep.parcel_code as parcel
                       from lpis_edit_parcels lep 
                       inner join lpis_sector_block_details lsbd on lep.sector_block_id = lsbd.sector_block_id 
                       where lep.sector_block_id = :blockId 
                         and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete 
                         and (:sessionId is not null and lep.session_uuid = :sessionId)
                  ) tt
                )
                SELECT
                  MAX(CAST(extracted_value AS NUMERIC))
                FROM
                  ExtractedParts
                WHERE
                  extracted_value <> ''
                  AND COALESCE(TRANSLATE(extracted_value, '0123456789', ''), '') = ''
              """)
	String findAlsoInEditMaxParcelByBlockIdPostgres(
			@Bind("tenantId") String tenantId,
			@Bind("subSeparator") String subSeparator,
			@Bind("blockId") Long blockId,
			@Bind("sessionId") String sessionId);
		
	
	@SqlQuery("""
                SELECT max(cast(case
                                    when regexp_like(parcel, '^[0-9]+$') then  parcel
                                    when regexp_like(parcel, '^[0-9]+'||:subSeparator||'.*') then substr(parcel, 1, instr(parcel, :subSeparator) - 1)
                                    else null
                                end as integer))
                from (
                select parcel from lpis_parcels lp 
                inner join lpis_sector_block_details lsbd on lp.sector_block_id = lsbd.sector_block_id 
                where lp.tenant_id = :tenantId 
                  and lp.sector_block_id = :blockId 
                  and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete
                  and lp.id not in ( select lep.parcel_id from lpis_edit_parcels lep where lep.session_uuid = :sessionId)
                  and lp.parcel is not null
                union
                select lep.parcel_code as parcel
                from lpis_edit_parcels lep 
                inner join lpis_sector_block_details lsbd on lep.sector_block_id = lsbd.sector_block_id 
                where lep.sector_block_id = :blockId 
                  and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete 
                  and (:sessionId is not null and lep.session_uuid = :sessionId)
                ) tt
              """)
	String findAlsoInEditMaxParcelByBlockIdOracle(
			@Bind("tenantId") String tenantId,
			@Bind("subSeparator") String subSeparator,
			@Bind("blockId") Long blockId,
			@Bind("sessionId") String sessionId);
	
	
}
