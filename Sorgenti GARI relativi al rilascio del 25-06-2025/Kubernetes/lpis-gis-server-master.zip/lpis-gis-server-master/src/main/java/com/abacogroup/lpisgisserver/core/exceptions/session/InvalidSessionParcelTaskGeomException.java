package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidSessionParcelTaskGeomException extends AbstractException {

	private static final long serialVersionUID = -7096919051708833576L;
	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_SESSION_PARCEL_GOEM_TASK_GEOM;

	public InvalidSessionParcelTaskGeomException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new InvalidSessionParcelTaskGeomExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Parcel geom is not in proposed task geom")
	public static class InvalidSessionParcelTaskGeomExceptionBody extends AbstractExceptionBody {

		private static final long serialVersionUID = 4734267372243671418L;

		public InvalidSessionParcelTaskGeomExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
