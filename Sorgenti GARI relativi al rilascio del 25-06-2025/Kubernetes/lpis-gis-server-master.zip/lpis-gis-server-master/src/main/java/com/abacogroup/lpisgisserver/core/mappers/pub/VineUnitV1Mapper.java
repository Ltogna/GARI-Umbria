package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.resources.res.pub.units.vine.VineUnitWithAptitudesV1;
import com.abacogroup.lpisgisserver.resources.res.pub.units.vine.VineUnitWithParcelDetailsV1;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnitWithAptitudes;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnitWithParcelDetails;

@Mapper(uses = {AbsoluteDateMapper.class, VineAptitudesV1Mapper.class, AnomalyV1Mapper.class } )
public interface VineUnitV1Mapper {

	VineUnitV1Mapper INSTANCE = Mappers.getMapper(VineUnitV1Mapper.class);
	
	VineUnitWithAptitudesV1 toResponseV1(VineUnitWithAptitudes entity);

	VineUnitWithParcelDetailsV1 toResponseV1(VineUnitWithParcelDetails entity);

}
