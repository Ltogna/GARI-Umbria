package com.abacogroup.lpisgisserver.bundles;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.proj4j.CoordinateReferenceSystem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.bundles.models.AreaMessage;
import com.abacogroup.lpisgisserver.bundles.models.BlockMessage;
import com.abacogroup.lpisgisserver.bundles.models.SectorAreaMessage;
import com.abacogroup.lpisgisserver.bundles.models.SectorDecodeMessage;
import com.abacogroup.lpisgisserver.bundles.models.SectorMessage;
import com.abacogroup.lpisgisserver.core.BaseService;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.core.transform.ReprojectCoordinateSequenceFilter;
import com.abacogroup.lpisgisserver.db.dao.AreasDAO;
import com.abacogroup.lpisgisserver.db.dao.BlockDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.SectorAreasDAO;
import com.abacogroup.lpisgisserver.db.dao.SectorDAO;
import com.abacogroup.lpisgisserver.db.dao.SectorDecodesDAO;
import com.abacogroup.lpisgisserver.db.ntt.AreaNTT;
import com.abacogroup.lpisgisserver.db.ntt.BlockNTT;
import com.abacogroup.lpisgisserver.db.ntt.SectorAreaNTT;
import com.abacogroup.lpisgisserver.db.ntt.SectorNTT;
import com.abacogroup.lpisgisserver.jackson.WKTGeometryDeserializer;
import com.abacogroup.lpisgisserver.jackson.WKTGeometrySerializer;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;

public class ImportDataMessageProcessor extends AbstractMessageProcessor {

	private SectorDAO sectorsDAO;
	private SectorDecodesDAO sectorDecodesDAO;
	private BlockDAO blockDAO;
	private AreasDAO areasDAO;
	private SectorAreasDAO sectorAreasDAO;
	

	private final CoordinateReferenceSystem toWorldCRS = BaseService.getCRS("EPSG:3857");
	private static final String USER = "importDataBundle";

	private static final Logger log = LoggerFactory.getLogger(ImportDataMessageProcessor.class);

	private final ObjectMapper objectMapper;

	public ImportDataMessageProcessor(DAOContainer dc) {
		super(dc);
		this.sectorsDAO = dc.getSectorDAO();
		this.sectorDecodesDAO = dc.getSectorDecodesDAO();
		this.blockDAO = dc.getBlockDAO();
		this.areasDAO = dc.getAreasDAO();
		this.sectorAreasDAO = dc.getSectorAreasDAO();

		objectMapper = new ObjectMapper();
		SimpleModule module = new SimpleModule("custom-deserializers", Version.unknownVersion());
		module.addSerializer(Geometry.class, new WKTGeometrySerializer());
		module.addDeserializer(Geometry.class, new WKTGeometryDeserializer());
		objectMapper.registerModule(module);
	}

	@Override
	public String getDomainName() {
		return "data";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		
		String tenantId = message.getTenantId();
		
		ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).user(new User(USER, tenantId)).referenceDate(AbsoluteDate.of(LocalDate.now())).build();
		
	    Map<String, BiConsumer<File, ServiceSupportEnv>> fileProcessors = new HashMap<>();
	    fileProcessors.put("areas_", this::processAreas);
	    fileProcessors.put("sectors.jsonl", this::processSectors);
	    fileProcessors.put("sector_blocks.jsonl", this::processBlocks);
	    fileProcessors.put("sector_areas.jsonl", this::processSectorAreas);
	    fileProcessors.put("sector_decodes.jsonl", this::processSectorDecodes);

	    // load all the bundle files and process them
	    message.getConfigFiles().stream()
	        .map(Path::toFile)
	        .forEach(file -> {
	            String fileName = file.getName();
	            String extension = FilenameUtils.getExtension(file.getAbsolutePath()).toLowerCase();
	            fileProcessors.forEach((key, processor) -> {
	                if (fileName.startsWith(key) && ("jsonl".equals(extension) || key.endsWith(".jsonl"))) { // the areas file use a "all" filter
	                    processor.accept(file, env);
	                }
	            });
	        });
		
		// ?? XXX Aggiungere i delete ??
				
	}

	private void processAreas(File areasToImport, ServiceSupportEnv env) {
		try (BufferedReader reader = new BufferedReader(new FileReader(areasToImport))) {
			String line = reader.readLine();
			while (line != null) {
				insertArea(env, line);
				line = reader.readLine();
			}
		} catch (Exception e) {
			log.error(ERROR_READ_FILE_MESSAGE, areasToImport.getAbsolutePath(), e);
		}
	}

	private void processBlocks(File blocksToImport, ServiceSupportEnv env) {
		try (BufferedReader reader = new BufferedReader(new FileReader(blocksToImport))) {
			String line = reader.readLine();
			while (line != null) {
				insertBlock(env.getTenantId(), line);
				line = reader.readLine();
			}
		} catch (IOException e) {
			log.error(ERROR_READ_FILE_MESSAGE, blocksToImport.getAbsolutePath(), e);
		}
	}
	
	private void insertBlock(String tenantId, String line) {
		try {
			BlockMessage blockMsg = objectMapper.readValue(line, BlockMessage.class);

			BlockNTT blockToUpdate = blockDAO.findBlockDetailsByTenantBlockCodeSectorCode(tenantId, blockMsg.getBlock_code(),
					blockMsg.getSector_code());

			CoordinateReferenceSystem fromCRS = BaseService.getCRS(blockMsg.getSrs());
			Geometry worldGeom = reproject(blockMsg.getGeom(), fromCRS, toWorldCRS);

			Long blockDetailId = blockDAO.nextSequenceBlockDetailsVal();

			BlockNTT newBlock = BlockNTT.builder()
					.block_details_id(blockDetailId)
					.description(blockMsg.getDescription())
					.short_descr(blockMsg.getShort_descr())
					.srs(blockMsg.getSrs())
					.geom(blockMsg.getGeom())
					.world_geom(worldGeom)
					.block(blockMsg.getBlock_code())
					.build();

			if (blockToUpdate == null) {
				Long blockId = blockDAO.nextSequenceBlockVal();

				ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).build();
				SectorNTT sectorFromMessage = sectorsDAO.findSectorDetailsByTenantAndCode(env, blockMsg.getSector_code());
				if (sectorFromMessage == null) {
					throw new IllegalStateException("Sector with code " + blockMsg.getSector_code() + " does not exist, continue with next block...");
				}

				newBlock.setSector_id(sectorFromMessage.getId());
				newBlock.setId(blockId);

				blockDAO.insertBlock(blockId, tenantId, sectorFromMessage.getId(), blockMsg.getBlock_code());
				blockDAO.insertBlockDetail(newBlock, USER);
			} else if (!equalsBlocksMessageInfo(newBlock, blockToUpdate)) {
				newBlock.setId(blockToUpdate.getId());
				blockDAO.logicallyDeleteByBlockDetailId(blockToUpdate.getBlock_details_id(), USER);
				blockDAO.insertBlockDetail(newBlock, USER);
			}

		} catch (Exception e) {
			log.error("Error during insert block with line {} : {}", line, e);
		}
	}

	private void processSectors(File sectorsToImport, ServiceSupportEnv env) {
		try (BufferedReader reader = new BufferedReader(new FileReader(sectorsToImport))) {
			String line = reader.readLine();
			while (line != null) {
				insertSector(env.getTenantId(), line);
				line = reader.readLine();
			}
		} catch (IOException e) {
			log.error(ERROR_READ_FILE_MESSAGE, sectorsToImport.getAbsolutePath(), e);
		}
	}
	
	private void insertSector(String tenantId, String line) {
		try {
			ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).build();
			SectorMessage sectorMsg = objectMapper.readValue(line, SectorMessage.class);
			SectorNTT sectorToUpdate = sectorsDAO.findSectorDetailsByTenantAndCode(env, sectorMsg.getCode());

			CoordinateReferenceSystem fromCRS = BaseService.getCRS(sectorMsg.getSrs());
			Geometry worldGeom = reproject(sectorMsg.getGeom(), fromCRS, toWorldCRS);

			Long sectorDetailId = sectorsDAO.nextSequenceSectorDetailsVal();

			SectorNTT newSector = SectorNTT.builder()
					.sector_details_id(sectorDetailId)
					.description(sectorMsg.getDescription())
					.short_descr(sectorMsg.getShort_descr())
					.sector(sectorMsg.getCode())
					.srs(sectorMsg.getSrs())
					.geom(sectorMsg.getGeom())
					.world_geom(worldGeom)
					.build();

			if (sectorToUpdate == null) {
				Long sectorId = sectorsDAO.nextSequenceSectorVal();
				newSector.setId(sectorId);

				sectorsDAO.insertSector(sectorId, tenantId, sectorMsg.getCode());
				sectorsDAO.insertSectorDetail(newSector, USER);
			} else if (!equalsSectorsMessageInfo(newSector, sectorToUpdate)) {
				newSector.setId(sectorToUpdate.getId());

				sectorsDAO.logicallyDeleteBySectorDetailId(sectorToUpdate.getSector_details_id(), USER);
				sectorsDAO.insertSectorDetail(newSector, USER);
			}

		} catch (Exception e) {
			log.error("Error during insert sector with line {} : {}", line, e);
		}
	}
	
	private void insertArea(ServiceSupportEnv env, String line) {
		try {
			AreaMessage areaMsg = objectMapper.readValue(line, AreaMessage.class);

			Long pkid = areasDAO.nextSequencePkidVal();

			AreaNTT parent = areasDAO.findAreasByCriterias(env, CriteriaBuilder.string("code").eq(areaMsg.getParent_code()))
					.stream()
					.findFirst()
					.orElse(null);
			
			Long parentId = parent == null ? null : parent.getArea_id();

			Geometry worldGeom = areaMsg.getWorld_geom();

			if (areaMsg.getSrs() != null && areaMsg.getGeom() != null && worldGeom == null) {
				CoordinateReferenceSystem fromCRS = BaseService.getCRS(areaMsg.getSrs());
				worldGeom = reproject(areaMsg.getGeom(), fromCRS, toWorldCRS);
			}

			AbsoluteDate dayFrom = areaMsg.getDay_from() == null ? AbsoluteDate.of(LocalDate.now()) : areaMsg.getDay_from();
			AbsoluteDate dayTo = areaMsg.getDay_to() == null ? AbsoluteDate.of("99991231") : areaMsg.getDay_to();

			Long areaId = areasDAO.nextSequenceAreaIdVal();
			AreaNTT areaToUpdate = areasDAO.findAreasByCriterias(env, CriteriaBuilder.string("code").eq(areaMsg.getCode()))
					.stream()
					.findFirst()
					.orElse(null);
			
			if (areaToUpdate != null) {
				areaId = areaToUpdate.getArea_id();
				areasDAO.logicallyDeleteByPkid(areaToUpdate.getPkid(), env.getUserId());
			}

			AreaNTT toInsert = AreaNTT.builder()
					.acronym(areaMsg.getAcronym())
					.area_id(areaId)
					.code(areaMsg.getCode())
					.day_from(dayFrom)
					.day_to(dayTo)
					.description(areaMsg.getDescription())
					.geom(areaMsg.getGeom())
					.level_code(areaMsg.getLevel())
					.parent_id(parentId)
					.pkid(pkid)
					.srs(areaMsg.getSrs())
					.world_geom(worldGeom)
					.build();

			areasDAO.insert(env, toInsert);

		} catch (Exception e) {
			log.error("Error during insert area with line {} : {}", line, e);
		}
	}

	private void processSectorAreas(File sectorAreasToImport, ServiceSupportEnv env) {
		
		try (BufferedReader reader = new BufferedReader(new FileReader(sectorAreasToImport))) {
			String line = reader.readLine();
			while (line != null) {
				insertSectorArea(env, line);
				line = reader.readLine();
			}
		} catch (IOException e) {
			log.error(ERROR_READ_FILE_MESSAGE, sectorAreasToImport.getAbsolutePath(), e);
		}
	}
	
	private void insertSectorArea(ServiceSupportEnv env, String line) {
		try {
			SectorAreaMessage sectorAreaMsg = objectMapper.readValue(line, SectorAreaMessage.class);

			Long pkid = sectorAreasDAO.nextSequencePkidVal();

			AbsoluteDate dayFrom = sectorAreaMsg.getDay_from() == null ? AbsoluteDate.of(LocalDate.now()) : sectorAreaMsg.getDay_from();
			AbsoluteDate dayTo = sectorAreaMsg.getDay_to() == null ? AbsoluteDate.of("99991231") : sectorAreaMsg.getDay_to();

			Long sectorId = null;
			if (sectorAreaMsg.getSector_code() != null) {
				SectorNTT sector = sectorsDAO.findSectorDetailsByTenantAndCode(env, sectorAreaMsg.getSector_code());
				if (sector == null) {
					throw new IllegalStateException("Sector code " + sectorAreaMsg.getSector_code() + " is not define");
				}
				sectorId = sector.getId();
			}

			AreaNTT area = areasDAO.findAreasByCriterias(env, CriteriaBuilder.string("code").eq(sectorAreaMsg.getArea_code()))
					.stream()
					.findFirst()
					.orElse(null);
			
			if (area == null) {
				throw new IllegalStateException("Area " + sectorAreaMsg.getArea_code() + " is not define!");
			}
			Long areaId = area.getArea_id();

			SectorAreaNTT toUpdate = sectorAreasDAO.findByAreaIdAndSectorId(env, sectorId, areaId);
			if (toUpdate != null) {
				sectorAreasDAO.logicallyDeleteByPkid(toUpdate.getPkid(), USER);
			}

			SectorAreaNTT toInsert = SectorAreaNTT.builder()
					.area_id(areaId)
					.day_from(dayFrom)
					.day_to(dayTo)
					.pkid(pkid)
					.sector_id(sectorId)
					.build();

			sectorAreasDAO.insert(env, toInsert);

		} catch (Exception e) {
			log.error("Error during insert sector area with line {} : {}", line, e);
		}
	}

	private void processSectorDecodes(File sectorDecodesToImport, ServiceSupportEnv env) {
		
		try (BufferedReader reader = new BufferedReader(new FileReader(sectorDecodesToImport))) {
			String line = reader.readLine();
			while (line != null) {
				insertSectorDecode(env, line);
				line = reader.readLine();
			}
		} catch (IOException e) {
			log.error(ERROR_READ_FILE_MESSAGE, sectorDecodesToImport.getAbsolutePath(), e);
		}
		
	}
	
	private void insertSectorDecode(ServiceSupportEnv env, String line) {
		try {
			SectorDecodeMessage sectorDecodeMsg = objectMapper.readValue(line, SectorDecodeMessage.class);
	
			Long pkid = sectorDecodesDAO.nextSequenceSectorDecodesVal();
			
			SectorNTT sector = sectorsDAO.findSectorDetailsByTenantAndCode(env, sectorDecodeMsg.getSectorCode());
			if (sector == null) {
				throw new IllegalStateException("Sector code " + sectorDecodeMsg.getSectorCode() + " is not define for sector decodes import");
			}

			// try to logically delete the current sector decode
			sectorDecodesDAO.logicallyDelete(sector.getId(), sectorDecodeMsg.getCadastralCode(), sectorDecodeMsg.getSectionCode(), USER);
			
			// insert the new sector decode
			sectorDecodesDAO.insert(env, pkid, sector.getId(), sectorDecodeMsg);
			
		} catch (Exception e) {
			log.error("Error during insert sector decodes with line {} : {}", line, e);
		}
	}

	private Geometry reproject(Geometry geom, CoordinateReferenceSystem fromCRS, CoordinateReferenceSystem toCRS) {
		if (fromCRS.getName().equals(toCRS.getName())) {
			return geom;
		}

		Geometry destGeom = geom.copy();
		destGeom.apply(new ReprojectCoordinateSequenceFilter(fromCRS, toCRS));
		destGeom.setSRID(0);

		return destGeom;
	}

	private boolean equalsSectorsMessageInfo(SectorNTT s1, SectorNTT s2) {
		return StringUtils.equals(s1.getDescription(), s2.getDescription())
				&& StringUtils.equals(s1.getShort_descr(), s2.getShort_descr())
				&& StringUtils.equals(s1.getSector(), s2.getSector())
				&& StringUtils.equals(s1.getSrs(), s2.getSrs())
				&& s1.getGeom().equals(s2.getGeom());
	}

	private boolean equalsBlocksMessageInfo(BlockNTT b1, BlockNTT b2) {
		return StringUtils.equals(b1.getDescription(), b2.getDescription())
				&& StringUtils.equals(b1.getShort_descr(), b2.getShort_descr())
				&& StringUtils.equals(b1.getBlock(), b2.getBlock())
				&& StringUtils.equals(b1.getSrs(), b2.getSrs())
				&& b1.getGeom().equals(b2.getGeom());
	}
}
