package com.abacogroup.lpisgisserver.core;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.UnitDictionaryTables;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.ErrorItem;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;
import com.abacogroup.lpisgisserver.core.exceptions.units.fruit.FruitUnitNotFoundException;
import com.abacogroup.lpisgisserver.core.mappers.units.FruitUnitMapper;
import com.abacogroup.lpisgisserver.core.support.EditorSupportParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditFruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.FarmingFormNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.IrrigationNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.PlantingTypeNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.ProtectionStructureNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.QualitySystemNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.VarietyNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.fruit.FruitUnitDetailsNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.pub.CreateOrUpdateFruitUnitPayloadV1;
import com.abacogroup.lpisgisserver.resources.res.LandCoverWithUnits;
import com.abacogroup.lpisgisserver.resources.res.LandCoversEditResult;
import com.abacogroup.lpisgisserver.resources.res.units.fruit.FruitUnit;

import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EditFruitUnitsSupportService extends BaseService {

	private final EditUnitsSupportService editUnitsSupportService;

	private static final DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE;
	private static final UnitType UNIT_TYPE = UnitType.FRUIT_UNIT;
	private static final AbsoluteDate INFINITE = AbsoluteDate.of("99991231");
	
	private static final boolean CAN_NOT_BE_NULL = false;
	private static final boolean CAN_BE_NULL = true;

	private final EditFruitUnitsDAO editFruitUnitsDAO;
	private final SupportDAO supportDAO;


	public EditFruitUnitsSupportService(DAOContainer dc, InternalConfigService internalConf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, EditUnitsSupportService editUnitsSupportService, 
			PluginEnvironment pluginEnvironment) {
		super(dc, internalConf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.editFruitUnitsDAO = dc.getEditFruitUnitsDAO();
		this.supportDAO = dc.getSupportDAO();
		
		this.editUnitsSupportService = editUnitsSupportService;
	}
	
	public void checkCreateOrUpdateFruitUnitPayload(EditorSupportParams params, CreateOrUpdateFruitUnitPayloadV1 payload, 
			List<ErrorItem> errorList) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.VARIETY, UNIT_TYPE, ErrorField.VARIETY_CODE, ErrorCode.VARIETY_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.PLANTING_TYPE, UNIT_TYPE, ErrorField.PLANTING_TYPE_CODE, ErrorCode.PLANTING_TYPE_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.FARMING_FORM, UNIT_TYPE, ErrorField.FARMING_FORM_CODE, ErrorCode.FARMING_FORM_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.IRRIGATION, UNIT_TYPE, ErrorField.IRRIGATION_CODE, ErrorCode.IRRIGATION_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.QUALITY_SYSTEM, UNIT_TYPE, ErrorField.QUALITY_SYSTEM_CODE, ErrorCode.QUALITY_SYSTEM_CODE_NOT_FOUND);
		editUnitsSupportService.searchUnitsCodeOrPutError(env, payload, errorList, UnitDictionaryTables.PROTECTION_STRUCTURE, UNIT_TYPE, ErrorField.PROTECTION_STRUCTURE_CODE, ErrorCode.PROTECTION_STRUCTURE_CODE_NOT_FOUND);
		
		editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.AREA, payload.getAreaSqm(), 1.0, null, CAN_NOT_BE_NULL, errorList);
		
		editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.DISTANCE_ON_THE_ROW_CM, payload.getDistanceOnTheRowCM(), 50.0, 1000.0, CAN_BE_NULL, errorList);
		editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.DISTANCE_BETWEEN_ROWS_CM, payload.getDistanceBetweenRowsCM(), 50.0, 1000.0, CAN_BE_NULL, errorList);

		if(payload.getPlantsNumber() != null) {
			editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.PLANTS_NUMBER, payload.getPlantsNumber().doubleValue(), 1.0, 1000000.0, CAN_BE_NULL, errorList);
		}
		
		editUnitsSupportService.checkValueRangeValidity(env, params.getOperation(), ErrorField.ALTITUDE_ABOVE_SEA_LEVEL, payload.getAltitudeAboveSeaLevel(), 0.0, 3000.0, CAN_BE_NULL, errorList);
		
	}

	public FruitUnitDetailsNTT buildFruitUnitDetailsNTTFromPayload(CreateOrUpdateFruitUnitPayloadV1 payload, Long editId, 
			Long editLandCoverId, Long fruitUnitId, String unitCode, EditStatus editStatus, Integer flDeletable, String parentUnitCode) {
		return FruitUnitDetailsNTT.builder()
				.editId(editId)
				.editLandCoverId(editLandCoverId)
				.unitId(fruitUnitId)
				.parentUnitCode(parentUnitCode)
				.unitCode(unitCode)
				.typeCode(UNIT_TYPE)
				.variety(VarietyNTT.builder().code(payload.getVarietyCode()).build())
				.areaSqm(payload.getAreaSqm())
				.plantingDay(payload.getPlantingDay())
				.plantingDayPrecision(payload.getPlantingDayPrecision())
				.eradicateDay(payload.getEradicateDay())
				.plantingType(PlantingTypeNTT.builder().code(payload.getPlantingTypeCode()).build())
				.distanceOnTheRowCM(payload.getDistanceOnTheRowCM())
				.distanceBetweenRowsCM(payload.getDistanceBetweenRowsCM())
				.plantsNumber(payload.getPlantsNumber() != null ? payload.getPlantsNumber().intValue() : null)
				.farmingForm(FarmingFormNTT.builder().code(payload.getFarmingFormCode()).build())
				.irrigation(IrrigationNTT.builder().code(payload.getIrrigationCode()).build())
				.altitudeAboveSeaLevel(payload.getAltitudeAboveSeaLevel())
				.qualitySystem(QualitySystemNTT.builder().code(payload.getQualitySystemCode()).build())
				.protectionStructure(ProtectionStructureNTT.builder().code(payload.getProtectionStructureCode()).build())
				.externalCode(payload.getExternalCode())
				.editStatus(editStatus)
				.flDeletable(flDeletable)
				.build();
	}

	public void checkAndInsertEditParcelLandCoversFruitUnit(EditorSupportParams params) {
		Long fruitUnitId = params.getFruitUnitId();
		if(fruitUnitId == null) {
			editUnitsSupportService.setInEditLandCoverById(params, params.getLandCoverId(), EditStatus.NOT_IN_EDIT);
			return;
		}
		setInEditFruitUnitById(params, fruitUnitId, EditStatus.NOT_IN_EDIT);
	}

	public List<FruitUnit> internalGetFruitUnits(EditorSupportParams params, Long landCoverId, Long fruitUnitId) {
		List<FruitUnit> fruitUnits = getFruitUnitsNTT(params, landCoverId, fruitUnitId).stream()
				.map(FruitUnitMapper.INSTANCE::entityToDto)
				.sorted((a, b) -> {
					
					String aCode = a.getCode() == null ? "0" : a.getCode(); 
					String bCode = b.getCode() == null ? "0" : b.getCode();
					
					aCode = aCode.length() < 15 ? StringUtils.substring("000000000000000", aCode.length() - 14) + aCode : aCode;
					bCode = bCode.length() < 15 ? StringUtils.substring("000000000000000", bCode.length() - 14) + bCode : bCode;
					
					int codeCompare = ObjectUtils.compare(aCode, bCode);
					if(codeCompare != 0) {
						return codeCompare;
					}
					return a.getId().compareTo(b.getId());
				})
				.collect(Collectors.toList());

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		fruitUnits.stream().forEach(u -> {
			u.setIsDeletable(isDeletable(env, u.getLandCoverId(), u.getId()));
			u.setIsEditable(isEditable(params, u));
		});

		return fruitUnits;
	}

	public List<FruitUnitDetailsNTT> getFruitUnitsNTT(EditorSupportParams params, Long landCoverId, Long fruitUnitsId) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		List<FruitUnitDetailsNTT> fruitUnitNTTs = new ArrayList<>();

		List<EditStatus> editStatusToExclude = List.of(EditStatus.DELETED);
		List<FruitUnitDetailsNTT> inEditFruitUnits = editFruitUnitsDAO.findInEditFruitUnitsBySessionId(env, landCoverId, fruitUnitsId, editStatusToExclude);
		if(inEditFruitUnits != null) {
			fruitUnitNTTs.addAll(inEditFruitUnits);
		}

		List<FruitUnitDetailsNTT> notInEditFruitUnits = editFruitUnitsDAO.findNotInEditFruitUnitsBySessionId(env, landCoverId, fruitUnitsId);
		if(notInEditFruitUnits != null) {
			fruitUnitNTTs.addAll(notInEditFruitUnits);
		}

		if(fruitUnitsId != null && 
				(fruitUnitNTTs== null || fruitUnitNTTs.size() != 1 || !fruitUnitNTTs.get(0).getUnitId().equals(fruitUnitsId))) {
			FruitUnitNotFoundException ex = new FruitUnitNotFoundException(Status.NOT_FOUND, params.getOperation(), 
					ErrorField.UNIT_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}	 

		return fruitUnitNTTs;
	}

	private FruitUnitDetailsNTT setInEditFruitUnitById(EditorSupportParams params, Long fruitUnitId, EditStatus editStatus) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		List<EditStatus> editStatusToExclude = List.of(EditStatus.DELETED);
		FruitUnitDetailsNTT editFruitUnit = editFruitUnitsDAO.findInEditFruitUnitsBySessionId(env, null, fruitUnitId, editStatusToExclude).stream()
				.filter(u -> u.getUnitId().equals(fruitUnitId))
				.findFirst()
				.orElse(null);
		if(editFruitUnit == null) {
			editFruitUnit = editFruitUnitsDAO.findNotInEditFruitUnitsBySessionId(env, null, fruitUnitId).stream()
					.filter(u -> u.getUnitId().equals(fruitUnitId))
					.findFirst()
					.orElse(null);
			if(editFruitUnit == null) {
				FruitUnitNotFoundException ex = new FruitUnitNotFoundException(Status.NOT_FOUND, params.getOperation(), 
						ErrorField.UNIT_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
			LandCoverNTT inEditLandCover = editUnitsSupportService.setInEditLandCoverById(params, editFruitUnit.getLandCoverId(), editStatus);
			editFruitUnit.setEditId(editFruitUnitsDAO.nextEditFruitUnitDetailPkidVal());
			editFruitUnit.setEditLandCoverId(inEditLandCover.getEdit_id());
			editFruitUnit.setEditStatus(editStatus);
			editFruitUnitsDAO.insertEditFruitUnitDetail(env, editFruitUnit);
		} 

		return editFruitUnit;
	}

	public void checkFruitUnitValidationDates(ServiceSupportEnv env, CreateOrUpdateFruitUnitPayloadV1 payload,
			 @NotNull LandCoverNTT landCoverNTT, FruitUnitDetailsNTT oldUnit, List<ErrorItem> errorList) {
		payload.validateDate();
		
		LocalDate minPlantingDate = editUnitsSupportService.buildMinPlantingDate(payload, landCoverNTT);
	   
	    LocalDate maxPlantingDate = env.getReferenceDate().toLocalDate();    
	    
	    if(payload.getPlantingDay().toLocalDate().isBefore(minPlantingDate)
	    		|| payload.getPlantingDay().toLocalDate().isAfter(maxPlantingDate)) {
	    	ErrorCode errorCode = ErrorCode.PLANTING_DAY_NOT_VALID;
	    	String errMsg = String.format(editUnitsSupportService.getErrorDescription(env, errorCode, null), 
					formatter.format(minPlantingDate), formatter.format(maxPlantingDate));
	    	
	    	if(maxPlantingDate.isEqual(INFINITE.toLocalDate())) {
	    		errorCode = ErrorCode.PLANTING_DAY_NOT_VALID_GREATER_THAN;
	    		errMsg = String.format(editUnitsSupportService.getErrorDescription(env, errorCode, null), 
						formatter.format(minPlantingDate), "");
	    	}
	    	
	    	errorList.add(ErrorItem.builder()
	    			.errorCode(errorCode)
	    			.message(errMsg)
	    			.errorField(ErrorField.PLANTING_DAY)
	    			.build());
	    } 
	    
	    LocalDate maxEradicateDay = oldUnit != null ? env.getReferenceDate().toLocalDate() : maxPlantingDate;
	    
		if((payload.getEradicateDay().toLocalDate().isBefore(payload.getPlantingDay().toLocalDate()))
				|| (oldUnit != null && !oldUnit.getEradicateDay().toLocalDate().isEqual(payload.getEradicateDay().toLocalDate())
						&& !payload.getEradicateDay().toLocalDate().isEqual(env.getReferenceDate().toLocalDate()))) {
			ErrorCode errorCode = ErrorCode.ERADICATE_DAY_NOT_VALID;
	    	String errMsg = String.format(editUnitsSupportService.getErrorDescription(env, errorCode, null), 
					formatter.format(payload.getPlantingDay().toLocalDate()), formatter.format(maxEradicateDay));
	    	
	    	if(maxEradicateDay.equals(INFINITE.toLocalDate())) {
	    		errorCode = ErrorCode.ERADICATE_DAY_NOT_VALID_GREATER_THAN;
		    	errMsg = String.format(editUnitsSupportService.getErrorDescription(env, errorCode, null), 
						formatter.format(payload.getPlantingDay().toLocalDate()), "");
	    	}
	    	
			errorList.add(ErrorItem.builder()
					.errorCode(errorCode)
					.message(errMsg)
					.errorField(ErrorField.ERADICATE_DAY)
					.build());
		}
	}

	public Boolean isDeletable(ServiceSupportEnv env, Long landCoverId, Long fruitUnitId) {
		if(env.getSessionId() != null && fruitUnitId < 1) {
			return true;
		}

		Integer isDel = editFruitUnitsDAO.checkFruitUnitDeletable(env, landCoverId, fruitUnitId);
		return fruitUnitId > 0 && isDel != null && isDel == 1;
	}
	
	
	public void cleanUpIncompatibleFruitUnits(EditorSupportParams params, Long landCoverId) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		LandCoverNTT editLandCover = editUnitsSupportService.setInEditLandCoverById(params, landCoverId, EditStatus.NOT_IN_EDIT);
		
		List<FruitUnitDetailsNTT> fruitUnits = getFruitUnitsNTT(params, editLandCover.getLand_cover_id(), null);
		
		fruitUnits.stream().forEach(u -> {
			if(u.getUnitId() < 0) {
				editFruitUnitsDAO.deleteFruitUnitsByEditId(env.getSessionId(), u.getEditId());
			} else {
				u.setEditStatus(EditStatus.DELETED);
				u.setFlDeletable(1);
				if(u.getEditId() != null) {
					editFruitUnitsDAO.updateEditFruitUnitDetail(env.getSessionId(), u);
				} else {
					u.setEditId(editFruitUnitsDAO.nextEditFruitUnitDetailPkidVal());
					u.setEditLandCoverId(editLandCover.getEdit_id());
					editFruitUnitsDAO.insertEditFruitUnitDetail(env, u);
				}
			}
		}); 
		
	}

	public void copyLandCoverFruitUnits(EditorSupportParams params, LandCoversEditResult landCoversEditResult, 
			Boolean deleteSourceFruitUnit) {
		ServiceSupportEnv env  = checkAndBuildServiceSupportEnv(params);

		// new landCovers
		landCoversEditResult.getAdded().stream().forEach(lc -> {
			if(lc.getParent_id() != null) {
				internalCopyLandCoverFruitUnits(params, lc.getParent_id(), lc, deleteSourceFruitUnit);
			}
		});

		landCoversEditResult.getUpdated().stream()
		.filter(lc -> !lc.getEdit_status().equals(EditStatus.TOPOLOGY_CORRECTED))
		.forEach(landCover -> {
			LandCoverNTT editLandCover = editUnitsSupportService.setInEditLandCoverById(params, landCover.getId(), EditStatus.NOT_IN_EDIT);

			List<FruitUnitDetailsNTT> fruitUnits = getFruitUnitsNTT(params, editLandCover.getLand_cover_id(), null);

			fruitUnits.stream().forEach(u -> {

				u.setEditStatus(EditStatus.IN_EDIT);
				u.setFlDeletable(boolToInt(isDeletable(env, editLandCover.getLand_cover_id(), u.getUnitId())));

				if(u.getEditId() == null) {
					u.setEditId(editFruitUnitsDAO.nextEditFruitUnitDetailPkidVal());
					u.setEditLandCoverId(editLandCover.getEdit_id());
					editFruitUnitsDAO.insertEditFruitUnitDetail(env, u);	
				} else {
					editFruitUnitsDAO.updateEditFruitUnitDetail(env.getSessionId(), u);
				}
			}); 

			landCover.setUnit_types(supportDAO.getCompatibleUnitTypesByLandCoverCode(env.getTenantId(), landCover.getCode()));
			landCover.setFruit_units(internalGetFruitUnits(params, landCover.getId(), null));
		});
	}
	
	private void internalCopyLandCoverFruitUnits(EditorSupportParams params, Long sourceLandCoverId, LandCoverWithUnits targetLandCover,
			Boolean deleteSource) {

		if(sourceLandCoverId == null || targetLandCover == null) {
			return;
		}
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		LandCoverNTT targetEditLandCoverNTT = editUnitsSupportService.setInEditLandCoverById(params, targetLandCover.getId(), EditStatus.NOT_IN_EDIT);
		LandCoverNTT sourceEditLandCoverNTT = editUnitsSupportService.setInEditLandCoverById(params, sourceLandCoverId, EditStatus.NOT_IN_EDIT);

		List<FruitUnitDetailsNTT> inEditFruitUnits = getFruitUnitsNTT(params, sourceLandCoverId, null);

		inEditFruitUnits.stream().forEach(u -> {
			u = setInEditFruitUnitById(params, u.getUnitId(), EditStatus.NOT_IN_EDIT);
			FruitUnitDetailsNTT fruitUnitToInsert = FruitUnitDetailsNTT.builder()
					.editId(editFruitUnitsDAO.nextEditFruitUnitDetailPkidVal())
					.editLandCoverId(targetEditLandCoverNTT.getEdit_id())
					.unitId(editFruitUnitsDAO.nextNewFruitUnitIdVal())
					.unitCode(u.getUnitCode())
					.parentUnitCode(u.getParentUnitCode())
					.typeCode(UNIT_TYPE)
					.variety(u.getVariety())
					.areaSqm(u.getAreaSqm())
					.plantingDay(u.getPlantingDay())
					.plantingDayPrecision(u.getPlantingDayPrecision())
					.eradicateDay(u.getEradicateDay())
					.plantingType(u.getPlantingType())
					.distanceOnTheRowCM(u.getDistanceOnTheRowCM())
					.distanceBetweenRowsCM(u.getDistanceBetweenRowsCM())
					.plantsNumber(u.getPlantsNumber())
					.farmingForm(u.getFarmingForm())
					.irrigation(u.getIrrigation())
					.altitudeAboveSeaLevel(u.getAltitudeAboveSeaLevel())
					.qualitySystem(u.getQualitySystem())
					.protectionStructure(u.getProtectionStructure())
					.externalCode(u.getExternalCode())
					.editStatus(EditStatus.IN_EDIT)
					.flDeletable(1)
					.build();

			editFruitUnitsDAO.insertEditFruitUnitDetail(env, fruitUnitToInsert);

			if(u.getUnitId() < 0 && Boolean.TRUE.equals(deleteSource)) {
				editFruitUnitsDAO.deleteFruitUnitsByEditId(env.getSessionId(), u.getEditId());
			} else if(u.getUnitId() > 0 && Boolean.TRUE.equals(deleteSource)) {
				u.setEditStatus(EditStatus.DELETED);
				u.setFlDeletable(1);
				if(u.getEditId() != null) {
					editFruitUnitsDAO.updateEditFruitUnitDetail(env.getSessionId(), u);
				} else {
					u.setEditId(editFruitUnitsDAO.nextEditFruitUnitDetailPkidVal());
					u.setEditLandCoverId(sourceEditLandCoverNTT.getEdit_id());
					editFruitUnitsDAO.insertEditFruitUnitDetail(env, u);
				}
			}
		});

		targetLandCover.setUnit_types(supportDAO.getCompatibleUnitTypesByLandCoverCode(env.getTenantId(), targetLandCover.getCode()));
		targetLandCover.setFruit_units(internalGetFruitUnits(params, targetLandCover.getId(), null));
	}

	public void mergeLandCoverFruitUnits(EditorSupportParams params, Long targetLandCoverId, LandCoversEditResult landCoversEditResult) {
		editUnitsSupportService.setInEditLandCoverById(params, targetLandCoverId, EditStatus.NOT_IN_EDIT); 

		landCoversEditResult.getDeleted().stream()
		.forEach(landCover -> internalCopyLandCoverFruitUnits(params, 
				landCover, 
				landCoversEditResult.getUpdated().stream()
				.filter(lc -> lc.getId().equals(targetLandCoverId))
				.findFirst()
				.orElse(null),
				true
				));
	}	
	
	private Boolean isEditable(EditorSupportParams params, FruitUnit fruitUnit) {
		LocalDate refDate = params.getSession().getReference_date().toLocalDate();
		return !(refDate.isBefore(fruitUnit.getPlantingDay().toLocalDate()) && refDate.isAfter(fruitUnit.getEradicateDay().toLocalDate()));
	}
	

	public void mergeParcelLandCoverFruitUnits(EditorSupportParams params, LandCoversEditResult landCoversEditResult) {
		landCoversEditResult.getAdded().stream()
		.filter(landCover -> landCover.getParent_id() != null)
		.forEach(landCover -> internalCopyLandCoverFruitUnits(params, landCover.getParent_id(), landCover, true));
	}	
	
}
