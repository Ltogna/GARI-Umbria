package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.resources.res.pub.units.vine.VineAptitudesV1;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineAptitude;

@Mapper(uses = {AbsoluteDateMapper.class, DoIgtV1Mapper.class, VineyardV1Mapper.class } )
public interface VineAptitudesV1Mapper {

	VineAptitudesV1Mapper INSTANCE = Mappers.getMapper(VineAptitudesV1Mapper.class);
	
	VineAptitudesV1 toResponseV1(VineAptitude entity);

}
