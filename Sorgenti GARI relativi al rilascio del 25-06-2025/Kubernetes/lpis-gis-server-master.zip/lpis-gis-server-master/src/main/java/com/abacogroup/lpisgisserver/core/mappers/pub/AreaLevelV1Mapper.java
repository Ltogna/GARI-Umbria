package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.resources.res.AreaLevel;
import com.abacogroup.lpisgisserver.resources.res.pub.AreaLevelV1;

@Mapper
public interface AreaLevelV1Mapper {

	AreaLevelV1Mapper INSTANCE = Mappers.getMapper(AreaLevelV1Mapper.class);

	@InheritInverseConfiguration
	AreaLevelV1 toResponseV1(AreaLevel entity);
}
