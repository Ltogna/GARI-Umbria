package com.abacogroup.lpisgisserver.db.dao;

import com.abacogroup.lpisgisserver.db.dao.cache.CachePartyParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.cache.CacheTempParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.ts.TerritorialScopeDAO;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DAOContainer {
	private AdditionalLayersDAO additionalLayersDAO;
	private AnomalyCategoriesDAO anomalyCategoriesDAO;
	private AreasDAO areasDAO;
	private BlockDAO blockDAO;
	private CataloguesDAO cataloguesDAO;
	private ConfigDAO configDAO;
	private EditFruitUnitsDAO editFruitUnitsDAO;
	private EditLandCoversDAO editLandCoversDAO;
	private EditOliveUnitsDAO editOliveUnitsDAO;
	private EditParcelsDAO editParcelsDAO;
	private EditSessionsDAO editSessionsDAO;
	private EditUnitsDAO editUnitsDAO;
	private EditVineUnitsDAO editVineUnitsDAO;
	private ExternalConfigDAO externalConfigDAO;
	private ExternalSourceDataDAO externalSourceDataDAO;
	private FruitUnitsDAO fruitUnitsDAO;
	private I18nDAO i18nDAO;
	private InfoGisDAO infoGisDAO;
	private InternalDAO internalDAO;
	private LandCoverConfigsDAO landCoverConfigsDAO;
	private LandCoversDAO landCoversDAO;
	private LandCoversDetailsDAO landCoversDetailsDAO;
	private LayerDAO layerDAO;
	private LockParcelsDAO lockParcelsDAO;
	private MatrixClassDAO matrixClassDAO;
	private MatrixClassDetailsDAO matrixClassDetailsDAO;
	private MatrixClassLandcoversDAO matrixClassLandcoversDAO;
	private MatrixClassLandUsesDAO matrixClassLandUsesDAO;
	private MatrixClassMetadataDAO matrixClassMetadataDAO;
	private MatrixCompatDAO matrixCompatDAO;
	private MatrixDAO matrixDAO;
	private MatrixLandCoverDAO matrixLandCoverDAO;
	private MatrixLandCoversMetadataDAO matrixLandCoversMetadataDAO;
	private MatrixLandUsesDAO matrixLandUsesDAO;
	private MatrixLandUsesMetadataDAO matrixLandUsesMetadataDAO;
	private OliveUnitsDAO oliveUnitsDAO;
	private ParcelDetailsDAO parcelDetailsDAO;
	private ParcelsDAO parcelsDAO;
	private SectorAreasDAO sectorAreasDAO;
	private SectorDAO sectorDAO;
	private SectorDecodesDAO sectorDecodesDAO;
	private StackFruitUnitsDAO stackFruitUnitsDAO;
	private StackLandCoversDAO stackLandCoversDAO;
	private StackOliveUnitsDAO stackOliveUnitsDAO;
	private StackParcelsDAO stackParcelsDAO;
	private StacksDAO stacksDAO;
	private StackVineUnitsDAO stackVineUnitsDAO;
	private SupportDAO supportDAO;
	private TerritorialScopeDAO territorialScopeDAO;
	private TotalLandCoversDAO totalLandCoversDAO;
	private TotalParcelsDAO totalParcelsDAO;
	private UnitCodesDAO unitCodesDAO;
	private UnitsDAO unitsDAO;
	private VineUnitsDAO vineUnitsDAO;
	private WMSLayersDAO wMSLayersDAO;
	private WMSParcelsFilterDAO wmsParcelsFilterDAO;
	private WMSServerAreasDAO wmsServerAreasDAO;
	
	private CachePartyParcelsDAO cachePartyParcelsDAO;
	private CacheTempParcelsDAO cacheTempParcelsDAO;

}
