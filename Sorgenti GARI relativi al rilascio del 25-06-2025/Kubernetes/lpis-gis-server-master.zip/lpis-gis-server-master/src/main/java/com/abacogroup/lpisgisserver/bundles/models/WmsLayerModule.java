package com.abacogroup.lpisgisserver.bundles.models;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class WmsLayerModule {
	private String module;
	private Boolean fl_on;
	private Map<String, String> description;
}
