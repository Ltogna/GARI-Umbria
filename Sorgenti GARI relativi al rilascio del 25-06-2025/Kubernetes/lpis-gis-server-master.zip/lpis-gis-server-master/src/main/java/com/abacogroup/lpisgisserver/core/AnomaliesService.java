package com.abacogroup.lpisgisserver.core;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.lpisgisserver.core.enums.AnomalyLevel;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.anomalies.GenericAnomalyException;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.InvalidParcelDataException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionParcelIdException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidUserEditSessionException;
import com.abacogroup.lpisgisserver.db.dao.AnomalyCategoriesDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.ntt.AnomalyCategoriesNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.ReqContext;
import com.abacogroup.lpisgisserver.resources.req.pub.AnomalyRequestV1;
import com.abacogroup.lpisgisserver.resources.res.anomalies.AnomaliesList;
import com.abacogroup.lpisgisserver.resources.res.anomalies.Anomaly;
import com.abacogroup.lpisgisserver.resources.res.anomalies.AnomalyType;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.Invocation;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AnomaliesService extends BaseService {

	private final WebTarget anomaliesWebTarget;

	private final AnomalyCategoriesDAO anomalyCategoriesDAO;

	private static final String DEFAULT_LANG_CODE = "en";

	private final Cache<String, List<String>> anomaliesCache; //KEY: tenant|groupCode

	public AnomaliesService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService,
			StyleService styleService, PluginEnvironment pluginEnvironment, WebTarget anomaliesWebTarget) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.anomaliesWebTarget = anomaliesWebTarget;

		this.anomalyCategoriesDAO = dc.getAnomalyCategoriesDAO();

		anomaliesCache = Caffeine.newBuilder()
				.maximumSize(1000)
				.expireAfterAccess(Duration.ofHours(3))
				.build();
	}

	/**
	 * Get anomalies for a parcel. This method is used by an admin to get a list of anomalies for a parcel
	 * 
	 * @param reqContext - request context for obtaining lang authToken tenant
	 * @param parcelId - id of the parcel to get anomalies for
	 * 
	 * @return a list of anomalies for the parcel or null if none found ( error in case of invalid parameters
	 */
	public AnomaliesList getParcelAnomalies(ReqContext reqContext, Long parcelId) {
		checkReqContext(reqContext, Operation.GET_ANOMALIES);

		// If parcelId is null throw InvalidSessionParcelIdException.
		if (parcelId == null) {
			InvalidParcelDataException ex = new InvalidParcelDataException(Status.BAD_REQUEST,
					Operation.GET_ANOMALIES, ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(reqContext.getTenantId()), reqContext.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		Boolean showUncategorizedAnomalyTypes = internalConf.getBooleanValue(reqContext.getTenantId(), InternalConfigKeys.FL_SHOW_UNCATEGORIZED_ANOMALY_TYPES_KEY.getKey());

		return getParcelAnomaliesInternal(reqContext, Collections.singletonList(parcelId), showUncategorizedAnomalyTypes);
	}
	
	public AnomaliesList getAllParcelAnomalies(ReqContext reqContext, Long parcelId) {
		checkReqContext(reqContext, Operation.GET_ANOMALIES);

		// If parcelId is null throw InvalidSessionParcelIdException.
		if (parcelId == null) {
			InvalidSessionParcelIdException ex = new InvalidSessionParcelIdException(Status.BAD_REQUEST,
					Operation.GET_ANOMALIES, ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(reqContext.getTenantId()), reqContext.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		return getParcelAnomaliesInternal(reqContext, Collections.singletonList(parcelId), true);
	}

	/**
	 * Get parcel anomalies internal. It's used to check if there are anomalies in the parcel
	 * 
	 * @param reqContext - request context for obtaining tenant id
	 * @param parcelIds - ids list of the parcels to get anomalies for
	 * 
	 * @return list of anomalies in the parcel or null if not found or error in http response
	 */
	public AnomaliesList getParcelAnomaliesInternal(ReqContext reqContext, List<Long> parcelIds, Boolean showUncategorizedAnomalyTypes) {
		AnomaliesList result = AnomaliesList.builder().anomalies_list(new ArrayList<>()).build();

		String tenantId = reqContext.getUser().getTenant();
		
		// Avoid spamming requests
		if (parcelIds.isEmpty()) {
			return result;
		}

		Map<String, Object> payload = new HashMap<>();
		payload.put("parcelIds", parcelIds);
		
		// POST /anomaly-registry/{tenant}/public/v1/anomalies/by-parcel-ids
		Invocation.Builder requestBuilder = anomaliesWebTarget
				.path(reqContext.getUser().getTenant())
				.path("public/v1/anomalies/by-parcel-ids")
				.request(MediaType.APPLICATION_JSON_TYPE)
				.accept(MediaType.APPLICATION_JSON_TYPE)
				.header(ACCEPT_LANGUAGE, reqContext.getLang())
				.header(AUTHORIZATION, String.format(JWT_PREFIX, reqContext.getUser().getAuthToken()));
		
		Response response = null;

		try {
			response = requestBuilder.post(Entity.entity(payload, MediaType.APPLICATION_JSON));

			if (response.getStatus() == 200) {
				response.bufferEntity();
				List<Anomaly> anomaliesResponse = response.readEntity(new GenericType<List<Anomaly>>() {
				});

				List<Anomaly> anomaliesFiltered = new ArrayList<>();
				anomaliesResponse.forEach(anomaly -> {
					AnomalyCategoriesNTT anomalyCategory = anomalyCategoriesDAO.findByTenantGroupCodeAndCode(tenantId, anomaly.getType().getGroupCode(),
							anomaly.getType().getCode());

					AnomalyLevel level = anomalyCategory != null ? anomalyCategory.getLevel() : AnomalyLevel.UNCATEGORIZED;

					// Add an anomaly to the list of anomalies filtered by level.
					if ((anomalyCategory != null && anomalyCategory.getFl_exclude() != 1) ||
							(anomalyCategory == null && showUncategorizedAnomalyTypes)) {

						anomaly.getType().setLevel(level);
						anomaliesFiltered.add(anomaly);
					}
				});

				result.setAnomalies_list(anomaliesFiltered);
			}

			else {
				logErrorResponse(result, response);
			}

		} catch (Exception e) {
			result.setError(e.getMessage());
			log.error("Error message '{}', {} ", e.getMessage(), e);
		} finally {
			// Closes the response and closes the underlying response.
			if (response != null)
				response.close();
		}

		return result;
	}

	private void logErrorResponse(AnomaliesList result, Response response) {
		Map<String, Object> errorResponse = response.readEntity(new GenericType<HashMap<String, Object>>() { });
		String errorMsg = (String) errorResponse.get("message");
		log.error("Error : {} ", errorMsg);
		
		if(result != null) {
			result.setError(errorMsg);
		}
	}

	public AnomaliesList setParcelAnomalies(ReqContext reqContext, Long parcelId, @NotNull @NotEmpty List<AnomalyRequestV1> anomalies) {
		checkReqContext(reqContext, Operation.SET_ANOMALIES);
		return setParcelAnomaliesInternal(reqContext, parcelId, anomalies);
	}

	private AnomaliesList setParcelAnomaliesInternal(ReqContext reqContext, Long parcelId, @NotNull @NotEmpty List<AnomalyRequestV1> anomalies) {
		AnomaliesList result = AnomaliesList.builder().anomalies_list(new ArrayList<>()).build();
		String tenantId = reqContext.getUser().getTenant();

		// POST /anomaly-registry/{tenant}/public/v1/anomalies
		WebTarget webTarget = anomaliesWebTarget
				.path(tenantId + "/")
				.path("public/v1/")
				.path("anomalies");

		Response response = null;

		try {
			response = webTarget
					.request(MediaType.APPLICATION_JSON_TYPE)
					.accept(MediaType.APPLICATION_JSON_TYPE)
					.header(ACCEPT_LANGUAGE, reqContext.getLang())
					.header(AUTHORIZATION, String.format(JWT_PREFIX, reqContext.getUser().getAuthToken()))
					.post(Entity.entity(anomalies, MediaType.APPLICATION_JSON));

			if (response.getStatusInfo().getFamily().equals(Status.Family.SUCCESSFUL)){
				return getAllParcelAnomalies(reqContext, parcelId);
			} else {
				logErrorResponse(result, response);
			}

		} catch (Exception e) {
			result.setError(e.getMessage());
			log.error("Error message '{}', {}", e.getMessage(), e);
		} finally {
			// Closes the response and closes the underlying response.
			if (response != null)
				response.close();
		}
		
		return result;
	}	

	private void checkReqContext(ReqContext reqContext, Operation operation) {
		// If the request context is null the request context is not a valid request.
		if (reqContext == null) {
			GenericAnomalyException ex = new GenericAnomalyException(Status.BAD_REQUEST,
					operation, ErrorField.REQUEST_CONTEXT,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		String lang = reqContext.getLang();
		String authToken = reqContext.getUser().getAuthToken();
		String tenantId = reqContext.getUser().getTenant();

		// If the user has no language authentication token and tenantId are null or the lang is null or the user has no language.
		if (lang == null || authToken == null || tenantId == null) {
			InvalidUserEditSessionException ex = new InvalidUserEditSessionException(Status.BAD_REQUEST,
					operation, ErrorField.REQUEST_CONTEXT,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

	}

	public Boolean checkGroupCodeAndCodeExists(ReqContext reqContext, String groupCode, String code) {
		if(reqContext == null || reqContext.getTenantId() == null) {
			GenericAnomalyException ex = new GenericAnomalyException(Status.BAD_REQUEST, Operation.CHECK_ANOMALY_CODE, ErrorField.REQUEST,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if(groupCode == null) {
			GenericAnomalyException ex = new GenericAnomalyException(Status.BAD_REQUEST, Operation.CHECK_ANOMALY_CODE, ErrorField.ANOMALY_GROUP_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if(code == null) {
			GenericAnomalyException ex = new GenericAnomalyException(Status.BAD_REQUEST, Operation.CHECK_ANOMALY_CODE, ErrorField.ANOMALY_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		String tenantId = reqContext.getTenantId();

		String key = tenantId + "|" + groupCode;

		List<String> codes = anomaliesCache.getIfPresent(key);

		//load codes
		if(codes == null ) {
			return loadAnomalyCode(reqContext, groupCode, code);
		}

		String foundCode = codes.stream().filter(c -> c.equals(code)).findFirst().orElse(null);

		return foundCode != null || loadAnomalyCode(reqContext, groupCode, code);

	}

	private Boolean loadAnomalyCode(ReqContext reqContext, String groupCode, String code) {
		checkReqContext(reqContext, Operation.GET_ANOMALY_TYPE);

		String tenantId = reqContext.getUser().getTenant();

		// GET /anomaly-registry/{tenant}/public/v1/anomaly-type?groupCode={groupCode}&code={code}
		WebTarget webTarget = anomaliesWebTarget
				.path(tenantId + "/")
				.path("public/v1/")
				.path("anomaly-types")
				.queryParam("groupCode", groupCode)
				.queryParam("code", code);

		Response response = null;

		try {
			response = webTarget
					.request(MediaType.APPLICATION_JSON_TYPE)
					.accept(MediaType.APPLICATION_JSON_TYPE)
					.header(ACCEPT_LANGUAGE, reqContext.getLang())
					.header(AUTHORIZATION, String.format(JWT_PREFIX, reqContext.getUser().getAuthToken()))
					.get();

			if (response.getStatus() == 200) {
				response.bufferEntity();
				List<AnomalyType> anomaliesResponse = response.readEntity(new GenericType<List<AnomalyType>>() {
				});
				
				anomaliesResponse.forEach(anomaly -> {
					String key = tenantId + "|" + anomaly.getGroupCode();
					
					List<String> codes = anomaliesCache.getIfPresent(key);
					if(codes == null ) {
						codes = new ArrayList<>();
					}
					
					codes.add(anomaly.getCode());
					anomaliesCache.put(key, codes);
				});

			}

			else {
				logErrorResponse(null, response);
			}

		} catch (Exception e) {
			log.error("Error message '{}', {} ", e.getMessage(), e);
		} finally {
			// Closes the response and closes the underlying response.
			if (response != null)
				response.close();
		}
		
		String key = tenantId + "|" + groupCode;
		
		List<String> codes = anomaliesCache.getIfPresent(key);

		//load codes
		if(codes == null ) {
			return false;
		}

		String foundCode = codes.stream().filter(c -> c.equals(code)).findFirst().orElse(null);

		return foundCode != null;
	}

}
