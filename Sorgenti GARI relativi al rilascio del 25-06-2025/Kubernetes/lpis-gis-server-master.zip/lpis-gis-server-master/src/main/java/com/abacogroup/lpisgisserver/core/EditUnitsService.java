package com.abacogroup.lpisgisserver.core;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.LandCoverNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.units.UnitNotFoundException;
import com.abacogroup.lpisgisserver.core.support.EditorSupportParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditFruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.EditLandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.EditOliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.EditVineUnitsDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.fruit.FruitUnitDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.OliveUnitDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineUnitDetailsNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.Unit;
import com.abacogroup.lpisgisserver.resources.res.UnitsList;
import com.abacogroup.lpisgisserver.resources.res.units.fruit.FruitUnit;
import com.abacogroup.lpisgisserver.resources.res.units.olive.OliveUnit;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineAptitude;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnitWithAptitudes;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EditUnitsService extends BaseService {

	private final EditLandCoversSupportService editLandCoversSupportService;
	private final EditVineUnitsSupportService editVineUnitsSupportService;
	private final EditOliveUnitsSupportService editOliveUnitsSupportService;
	private final EditFruitUnitsSupportService editFruitUnitsSupportService;

	private final EditLandCoversDAO editLandCoversDAO;
	private final EditVineUnitsDAO editVineUnitsDAO;
	private final EditOliveUnitsDAO editOliveUnitsDAO;
	private final EditFruitUnitsDAO editFruitUnitsDAO;


	public EditUnitsService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService,
			EditLandCoversSupportService editLandCoversSupportService, EditVineUnitsSupportService editVineUnitsSupportService,
			EditOliveUnitsSupportService editOliveUnitsSupportService, EditFruitUnitsSupportService editFruitUnitsSupportService,
			PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.editLandCoversDAO = dc.getEditLandCoversDAO();
		this.editVineUnitsDAO = dc.getEditVineUnitsDAO();
		this.editOliveUnitsDAO = dc.getEditOliveUnitsDAO();
		this.editFruitUnitsDAO = dc.getEditFruitUnitsDAO();

		this.editLandCoversSupportService = editLandCoversSupportService;
		this.editVineUnitsSupportService = editVineUnitsSupportService;
		this.editOliveUnitsSupportService = editOliveUnitsSupportService;
		this.editFruitUnitsSupportService = editFruitUnitsSupportService;
	}


	public UnitsList reproportionUnitArea(EditorSupportParams params) {
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()));
		checkAndInsertEditParcelLandCoversUnit(params);
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		LandCoverNTT landCoverNTT = getLandCoverNTT(env, params.getParcelId(), params.getLandCoverId(), params.getOperation());

		internalReproportionArea(params, env, landCoverNTT);

		List<VineUnitWithAptitudes> vineUnits = editVineUnitsSupportService.internalGetVineUnits(params, params.getLandCoverId(), null);
		vineUnits.stream().forEach(u -> {
			List<VineAptitude> vineAptitudes = editVineUnitsSupportService.internalGetVineAptitudes(params, u.getId(), null, false);
			u.setVineAptitudes(vineAptitudes);
		});

		List<OliveUnit> oliveUnits = editOliveUnitsSupportService.internalGetOliveUnits(params, params.getLandCoverId(), null);
		List<FruitUnit> fruitUnits = editFruitUnitsSupportService.internalGetFruitUnits(params, params.getLandCoverId(), null);

		return UnitsList.builder()
				.vineUnits(vineUnits)
				.oliveUnits(oliveUnits)
				.fruitUnits(fruitUnits)
				.build();
	}

	private void internalReproportionArea(EditorSupportParams params, ServiceSupportEnv env, LandCoverNTT landCoverNTT) {

		Double landCoverArea = landCoverNTT.getArea_sqm();

		List<VineUnitDetailsNTT> vineUnits = editVineUnitsSupportService.getVineUnitsNTT(params, params.getLandCoverId(), null);
		List<OliveUnitDetailsNTT> oliveUnits = editOliveUnitsSupportService.getOliveUnitsNTT(params, params.getLandCoverId(), null);
		List<FruitUnitDetailsNTT> fruitUnits = editFruitUnitsSupportService.getFruitUnitsNTT(params, params.getLandCoverId(), null);
		if(vineUnits.isEmpty() && oliveUnits.isEmpty() && fruitUnits.isEmpty()) {
			return;
		}

		Double oldTotalVineUnitArea = vineUnits.stream().mapToDouble(VineUnitDetailsNTT::getAreaSqm).sum(); 
		Double oldTotalOliveUnitArea = oliveUnits.stream().mapToDouble(OliveUnitDetailsNTT::getAreaSqm).sum(); 
		Double oldTotaleFruitUnitArea = fruitUnits.stream().mapToDouble(FruitUnitDetailsNTT::getAreaSqm).sum(); 

		Double oldTotalArea = oldTotalVineUnitArea + oldTotalOliveUnitArea + oldTotaleFruitUnitArea;  

		Map<Long, Double> newUnitAreas = new HashMap<>();
		vineUnits.stream().forEach(u -> {
			Double newUnitArea = BigDecimal.valueOf(landCoverArea).multiply(BigDecimal.valueOf(u.getAreaSqm()))
					.divide(BigDecimal.valueOf(oldTotalArea), 0, RoundingMode.HALF_UP)
					.doubleValue();

			newUnitAreas.put(u.getUnitId(), newUnitArea);
		});
		oliveUnits.stream().forEach(u -> {
			Double newUnitArea = BigDecimal.valueOf(landCoverArea).multiply(BigDecimal.valueOf(u.getAreaSqm()))
					.divide(BigDecimal.valueOf(oldTotalArea), 0, RoundingMode.HALF_UP)
					.doubleValue();

			newUnitAreas.put(u.getUnitId(), newUnitArea);
		});
		fruitUnits.stream().forEach(u -> {
			Double newUnitArea = BigDecimal.valueOf(landCoverArea).multiply(BigDecimal.valueOf(u.getAreaSqm()))
					.divide(BigDecimal.valueOf(oldTotalArea), 0, RoundingMode.HALF_UP)
					.doubleValue();

			newUnitAreas.put(u.getUnitId(), newUnitArea);
		});

		Double newTotalArea = newUnitAreas.values().stream().mapToDouble(Number::doubleValue).sum();
		if(!landCoverArea.equals(newTotalArea)) {
			Long idWithLargestArea = getIdWithLargestArea(newUnitAreas, vineUnits, oliveUnits, fruitUnits);
			newUnitAreas.put(idWithLargestArea, newUnitAreas.get(idWithLargestArea) + landCoverArea - newTotalArea);
		}

		vineUnits.stream().forEach(u -> {
			u.setAreaSqm(newUnitAreas.get(u.getUnitId()));
			insertOrUpdateVineUnitDetail(env, landCoverNTT.getEdit_id(), u);
		});

		oliveUnits.stream().forEach(u -> {
			u.setAreaSqm(newUnitAreas.get(u.getUnitId()));
			insertOrUpdateOliveUnitDetail(env, landCoverNTT.getEdit_id(), u);
		});

		fruitUnits.stream().forEach(u -> {
			u.setAreaSqm(newUnitAreas.get(u.getUnitId()));
			insertOrUpdateFruitUnitDetail(env, landCoverNTT.getEdit_id(), u);
		});
	}

	private Long getIdWithLargestArea(Map<Long, Double> newUnitAreas, List<VineUnitDetailsNTT> vineUnits, 
			List<OliveUnitDetailsNTT> oliveUnits, List<FruitUnitDetailsNTT> fruitUnits) {
		Long idWithLargestArea = newUnitAreas.entrySet()
				.stream()
				.max(Map.Entry.comparingByValue())
				.map(Entry::getKey)
				.orElse(null);

		if(idWithLargestArea == null) {
			if(!vineUnits.isEmpty()) {
				idWithLargestArea = vineUnits.get(0).getUnitId();
			} else if(!oliveUnits.isEmpty()) {
				idWithLargestArea = oliveUnits.get(0).getUnitId();
			} else if(!fruitUnits.isEmpty()) {
				idWithLargestArea = fruitUnits.get(0).getUnitId();
			}
		}

		return idWithLargestArea;
	}

	private void checkAndInsertEditParcelLandCoversUnit(EditorSupportParams params) {
		editVineUnitsSupportService.checkAndInsertEditParcelLandCoversVineUnitAndAptitudes(params, null);
		editOliveUnitsSupportService.checkAndInsertEditParcelLandCoversOliveUnit(params);
		editFruitUnitsSupportService.checkAndInsertEditParcelLandCoversFruitUnit(params);		
	}


	public Unit updateUnitCode(EditorSupportParams params, Long unitId) {
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()));
		checkAndInsertEditParcelLandCoversUnit(params);
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		LandCoverNTT landCoverNTT = getLandCoverNTT(env, params.getParcelId(), params.getLandCoverId(), params.getOperation());

		VineUnitDetailsNTT vineUnit = editVineUnitsSupportService.getVineUnitsNTT(params, params.getLandCoverId(), null).stream()
				.filter(u -> u.getUnitId().equals(unitId))
				.findFirst()
				.orElse(null);

		OliveUnitDetailsNTT oliveUnit = editOliveUnitsSupportService.getOliveUnitsNTT(params, params.getLandCoverId(), null).stream()
				.filter(u -> u.getUnitId().equals(unitId))
				.findFirst()
				.orElse(null);

		FruitUnitDetailsNTT fruitUnit = editFruitUnitsSupportService.getFruitUnitsNTT(params, params.getLandCoverId(), null).stream()
				.filter(u -> u.getUnitId().equals(unitId))
				.findFirst()
				.orElse(null);

		if(vineUnit == null && oliveUnit == null && fruitUnit == null) {
			UnitNotFoundException ex = new UnitNotFoundException(Status.NOT_FOUND, params.getOperation(), ErrorField.UNIT_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		String newUnitCode = null;
		UnitType unitType = null;
		if(vineUnit != null) {
			unitType = UnitType.VINE_UNIT;
			newUnitCode = getNewUnitCode(env, unitType);
			vineUnit.setParentUnitCode(vineUnit.getUnitCode());
			vineUnit.setUnitCode(newUnitCode);
			insertOrUpdateVineUnitDetail(env, landCoverNTT.getEdit_id(), vineUnit);
		} else if (oliveUnit != null) {
			unitType = UnitType.OLIVE_UNIT;
			newUnitCode = getNewUnitCode(env, unitType);
			oliveUnit.setParentUnitCode(oliveUnit.getUnitCode());
			oliveUnit.setUnitCode(newUnitCode);
			insertOrUpdateOliveUnitDetail(env, landCoverNTT.getEdit_id(), oliveUnit);
		} else {
			unitType = UnitType.FRUIT_UNIT;
			newUnitCode = getNewUnitCode(env, unitType);
			fruitUnit.setParentUnitCode(fruitUnit.getUnitCode());
			fruitUnit.setUnitCode(newUnitCode);
			insertOrUpdateFruitUnitDetail(env, landCoverNTT.getEdit_id(), fruitUnit);
		}

		return buildResponse(unitId, newUnitCode, unitType);
	}

	private Unit buildResponse(Long unitId, String unitCode, UnitType unitType) {
		return Unit.builder()
				.id(unitId)
				.code(unitCode)
				.type(unitType)
				.build();
	}

	private void insertOrUpdateVineUnitDetail(ServiceSupportEnv env, Long lcEditId, VineUnitDetailsNTT vineUnit) {
		vineUnit.setEditStatus(EditStatus.IN_EDIT);

		if(vineUnit.getEditId() != null) {
			editVineUnitsDAO.updateEditVineUnitDetail(env.getSessionId(), vineUnit);
		} else {
			vineUnit.setEditId(editVineUnitsDAO.nextEditVineUnitDetailPkidVal());
			vineUnit.setEditLandCoverId(lcEditId);
			editVineUnitsDAO.insertEditVineUnitDetail(env, vineUnit);
		}
	}

	private void insertOrUpdateOliveUnitDetail(ServiceSupportEnv env, Long lcEditId, OliveUnitDetailsNTT oliveUnit) {
		oliveUnit.setEditStatus(EditStatus.IN_EDIT);

		if(oliveUnit.getEditId() != null) {
			editOliveUnitsDAO.updateEditOliveUnitDetail(env.getSessionId(), oliveUnit);
		} else {
			oliveUnit.setEditId(editOliveUnitsDAO.nextEditOliveUnitDetailPkidVal());
			oliveUnit.setEditLandCoverId(lcEditId);
			editOliveUnitsDAO.insertEditOliveUnitDetail(env, oliveUnit);
		}
	}

	private void insertOrUpdateFruitUnitDetail(ServiceSupportEnv env, Long lcEditId, FruitUnitDetailsNTT fruitUnit) {
		fruitUnit.setEditStatus(EditStatus.IN_EDIT);

		if(fruitUnit.getEditId() != null) {
			editFruitUnitsDAO.updateEditFruitUnitDetail(env.getSessionId(), fruitUnit);
		} else {
			fruitUnit.setEditId(editFruitUnitsDAO.nextEditFruitUnitDetailPkidVal());
			fruitUnit.setEditLandCoverId(lcEditId);
			editFruitUnitsDAO.insertEditFruitUnitDetail(env, fruitUnit);
		}
	}

	private LandCoverNTT getLandCoverNTT(ServiceSupportEnv env, Long parcelId, Long landCoverId, Operation operation) {
		LandCoverNTT landCoverNTT = editLandCoversDAO.findInEditBySessionId(env, parcelId).stream()
				.filter(lc -> lc.getLand_cover_id().equals(landCoverId))
				.findFirst()
				.orElse(null);

		if(landCoverNTT == null) {
			LandCoverNotFoundException ex = new LandCoverNotFoundException(Status.NOT_FOUND, operation, ErrorField.LANDCOVER_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return landCoverNTT;
	}
}
