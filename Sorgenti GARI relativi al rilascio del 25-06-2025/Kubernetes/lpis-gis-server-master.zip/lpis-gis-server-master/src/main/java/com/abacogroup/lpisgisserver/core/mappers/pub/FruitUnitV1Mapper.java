package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.resources.res.pub.units.fruit.FruitUnitV1;
import com.abacogroup.lpisgisserver.resources.res.pub.units.fruit.FruitUnitWithParcelDetailsV1;
import com.abacogroup.lpisgisserver.resources.res.units.fruit.FruitUnit;
import com.abacogroup.lpisgisserver.resources.res.units.fruit.FruitUnitWithParcelDetails;

@Mapper(uses = {AbsoluteDateMapper.class, VineAptitudesV1Mapper.class} )
public interface FruitUnitV1Mapper {

	FruitUnitV1Mapper INSTANCE = Mappers.getMapper(FruitUnitV1Mapper.class);
	
	@Mapping(target = "anomalies", ignore = true)
	FruitUnitV1 toResponseV1(FruitUnit entity);

	FruitUnitWithParcelDetailsV1 toResponseV1(FruitUnitWithParcelDetails entity);
}
