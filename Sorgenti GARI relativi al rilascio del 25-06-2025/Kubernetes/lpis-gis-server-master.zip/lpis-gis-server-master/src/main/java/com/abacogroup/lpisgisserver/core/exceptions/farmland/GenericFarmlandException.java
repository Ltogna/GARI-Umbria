package com.abacogroup.lpisgisserver.core.exceptions.farmland;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class GenericFarmlandException extends AbstractException {

	private static final long serialVersionUID = -5387657690610961721L;

	private static final ErrorCode ERROR_CODE = ErrorCode.GENERIC_FARMLAND_VIEWER_ERROR;

	public GenericFarmlandException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new GenericFarmlandExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Generic farmland error")
	public static class GenericFarmlandExceptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = 5926307518005596221L;

		public GenericFarmlandExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}

	}
}
