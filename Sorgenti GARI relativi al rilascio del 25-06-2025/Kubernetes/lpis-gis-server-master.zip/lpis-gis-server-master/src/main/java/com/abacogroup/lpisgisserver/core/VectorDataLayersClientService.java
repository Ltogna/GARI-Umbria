package com.abacogroup.lpisgisserver.core;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.exceptions.vectordata.GenericVectorDataLayersException;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.VectorDataLayerGeometriesSearchReq;
import com.abacogroup.lpisgisserver.resources.res.vectordata.VectorDataLayerGeometryResponse;
import com.abacogroup.lpisgisserver.resources.res.vectordata.VectorDataLayerGeometryWithInfoResponse;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import jakarta.ws.rs.core.SecurityContext;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class VectorDataLayersClientService extends BaseService {

	private final Client client;
	private final String vectorDataLayersBaseUrl;

	private final String serviceUserName;
	private final Sso2Client sso2Client;


	private static final String DEFAULT_LANG_CODE = "en";
	private static final String GET_LAYER_GEOMS = "/{tenant}/public/v1/layers/{layerCode}/geometries";
	private static final String GET_INTERSECTED_LAYER_GEOMS = "/{tenant}/public/v1/layers/{layerCode}/geometries/intersection";

	private LoadingCache<String, User> serviceUsersCache; // key: tenant
	
	public VectorDataLayersClientService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf, 
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, PluginEnvironment pluginEnvironment, 
			Client client, String vectorDataLayersBaseUrl, String serviceUserName, Sso2Client sso2Client) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.client = client;
		this.vectorDataLayersBaseUrl = vectorDataLayersBaseUrl;

		this.sso2Client = sso2Client;
		this.serviceUserName = serviceUserName;
		
		serviceUsersCache = Caffeine.newBuilder()
                .maximumSize(500)
                .expireAfterWrite(Duration.ofMinutes(120))
                .build(this::loadServiceUser);
	}

	public InfiniteListResults<VectorDataLayerGeometryResponse> getLayerGeometries(ServiceSupportEnv env, Map<String, Object> paramMap,
			Geometry touchingGeometry, String srs, Boolean useServiceUser) {

		//XXX vanno convertite le geometrie se si con quale srs?
		
		WebTarget webTarget = client.target(vectorDataLayersBaseUrl + GET_LAYER_GEOMS)
				.resolveTemplate("tenant", env.getTenantId());

		for (Entry<String, Object> p : paramMap.entrySet()) {
			webTarget = webTarget.resolveTemplate(p.getKey(), p.getValue());
			webTarget = webTarget.queryParam(p.getKey(), p.getValue());
		}
		
		if(env.getNextKey() != null) {
			webTarget = webTarget.queryParam("nextKey", env.getNextKey());
		}

		VectorDataLayerGeometriesSearchReq payload = VectorDataLayerGeometriesSearchReq.builder()
				.touchingGeometry(touchingGeometry)
				.srs(srs)
				.build();

		Response response = null;
		try {
//			"/{tenant}/public/v1/layers/{layerCode}/geometries"
			response = webTarget
					.request(MediaType.APPLICATION_JSON_TYPE)
					.accept(MediaType.APPLICATION_JSON_TYPE)
					.header(ACCEPT_LANGUAGE, env.getLang())
					.header(AUTHORIZATION, String.format(JWT_PREFIX, resolveAuthToken(env, useServiceUser)))
					.post(Entity.entity(payload, MediaType.APPLICATION_JSON));

			if (response.getStatus() == 200) {
				response.bufferEntity();
				return response.readEntity(new GenericType<InfiniteListResultsImpl<VectorDataLayerGeometryResponse>>() {});
			} else {
				Map<String, Object> errorResponse = response.readEntity(new GenericType<HashMap<String, Object>>() {
				});
				String errorCode = (String) errorResponse.get("errorCode");
				GenericVectorDataLayersException ex = new GenericVectorDataLayersException(Status.INTERNAL_SERVER_ERROR,
						env.getOperation(), ErrorField.VECTOR_DATA_LAYERS_RESPONSE,
						this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

				ex.getBody().setMessage(errorCode);
				log.error(ex.getBody().getLogErrorMessage());
				log.error("Vector data layer response not valid!!!, {}", errorResponse.toString());
				throw ex;
			}

		} catch (Exception e) {
			GenericVectorDataLayersException ex = new GenericVectorDataLayersException(Status.INTERNAL_SERVER_ERROR,
					env.getOperation(), ErrorField.VECTOR_DATA_LAYERS_RESPONSE,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());
			log.error(e.getMessage());

			throw ex;

		}
	}
	
	public InfiniteListResults<VectorDataLayerGeometryWithInfoResponse> getIntersectedLayerGeometries(ServiceSupportEnv env, Map<String, Object> paramMap,
			Geometry touchingGeometry, String srs, Boolean useServiceUser) {
		
		//XXX vanno convertite le geometrie se si con quale srs?
		
		WebTarget webTarget = client.target(vectorDataLayersBaseUrl + GET_INTERSECTED_LAYER_GEOMS)
				.resolveTemplate("tenant", env.getTenantId());
		
		for (Entry<String, Object> p : paramMap.entrySet()) {
			webTarget = webTarget.resolveTemplate(p.getKey(), p.getValue());
			webTarget = webTarget.queryParam(p.getKey(), p.getValue());
		}
		
		if(env.getNextKey() != null) {
			webTarget = webTarget.queryParam("nextKey", env.getNextKey());
		}
		
		VectorDataLayerGeometriesSearchReq payload = VectorDataLayerGeometriesSearchReq.builder()
				.touchingGeometry(touchingGeometry)
				.srs(srs)
				.build();
		
		Response response = null;
		try {
//			"/{tenant}/public/v1/layers/{layerCode}/geometries"
			response = webTarget
					.queryParam("pageSize", 100)
					.request(MediaType.APPLICATION_JSON_TYPE)
					.accept(MediaType.APPLICATION_JSON_TYPE)
					.header(ACCEPT_LANGUAGE, env.getLang())
					.header(AUTHORIZATION, String.format(JWT_PREFIX, resolveAuthToken(env, useServiceUser)))
					.post(Entity.entity(payload, MediaType.APPLICATION_JSON));
			
			if (response.getStatus() == 200) {
				response.bufferEntity();
				return response.readEntity(new GenericType<InfiniteListResultsImpl<VectorDataLayerGeometryWithInfoResponse>>() {});
			} else {
				Map<String, Object> errorResponse = response.readEntity(new GenericType<HashMap<String, Object>>() {
				});
				String errorCode = (String) errorResponse.get("errorCode");
				GenericVectorDataLayersException ex = new GenericVectorDataLayersException(Status.INTERNAL_SERVER_ERROR,
						env.getOperation(), ErrorField.VECTOR_DATA_LAYERS_RESPONSE,
						this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);
				
				ex.getBody().setMessage(errorCode);
				log.error(ex.getBody().getLogErrorMessage());
				log.error("Vector data layer response not valid!!!, {}", errorResponse.toString());
				throw ex;
			}
			
		} catch (Exception e) {
			GenericVectorDataLayersException ex = new GenericVectorDataLayersException(Status.INTERNAL_SERVER_ERROR,
					env.getOperation(), ErrorField.VECTOR_DATA_LAYERS_RESPONSE,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);
			
			log.error(ex.getBody().getLogErrorMessage());
			log.error(e.getMessage());
			
			throw ex;
			
		}
	}
	
	private String resolveAuthToken(ServiceSupportEnv env, Boolean useServiceUser) {
		if (Boolean.TRUE.equals(useServiceUser) && serviceUserName != null && env.getUser() == null) {
			User serviceUser = serviceUsersCache.get(env.getTenantId());
			return serviceUser != null ? serviceUser.getAuthToken() : null;
		}
		
		return env.getUser() != null ? env.getUser().getAuthToken() : null;
        
	}
	
	private User loadServiceUser(String tenantId) {
		try {
			SecurityContext securityContext = sso2Client.createSecurityContextFromUserName(tenantId, serviceUserName);
			return (User) securityContext.getUserPrincipal();
		} catch (Exception ex) {
			throw new RuntimeException(String.format("error in authentication for user %s", serviceUserName), ex);
		}
	}
}
