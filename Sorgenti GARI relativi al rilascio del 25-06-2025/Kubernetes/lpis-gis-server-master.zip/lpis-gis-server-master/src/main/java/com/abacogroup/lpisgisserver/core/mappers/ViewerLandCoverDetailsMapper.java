package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.resources.res.LandCoverWithUnits;
import com.abacogroup.lpisgisserver.resources.res.viewer.ViewerLandCoverDetails;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ViewerLandCoverDetailsMapper {

	ViewerLandCoverDetailsMapper INSTANCE = Mappers.getMapper(ViewerLandCoverDetailsMapper.class);

	@InheritInverseConfiguration
	@Mapping(target = "info_gis", ignore = true)
	ViewerLandCoverDetails toViewerLandCoverDetails(LandCoverWithUnits landCoverWithUnits);

}
