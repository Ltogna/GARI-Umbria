package com.abacogroup.lpisgisserver.core;

import com.abacogroup.lpisgisserver.core.mappers.InfoGisMapper;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.InfoGisDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverInfoGisNTT;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelInfoGisNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.viewer.InfoGis;

public class InfoGisService extends BaseService {

	private InfoGisDAO infoGisDAO;

	private GeorasterClientService geoRasterClientService;

	public InfoGisService(DAOContainer dc, GeorasterClientService geoRasterClientService, InternalConfigService conf, 
			ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService, 
			StyleService styleService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.infoGisDAO = dc.getInfoGisDAO();

		this.geoRasterClientService = geoRasterClientService;
	}

	public InfoGis getParcelInfoGis(ParcelNTT ntt) {
		ParcelInfoGisNTT parcelInfoGisNTT = infoGisDAO.getParcelInfoGis(ntt.getPkid());

		if(parcelInfoGisNTT == null || parcelInfoGisNTT.getParcelDetailsPkid() == null) {
			return getAndSaveParcelInfoGisFromGeoraster(ntt);
		}

		return InfoGisMapper.INSTANCE.entityToDto(parcelInfoGisNTT);
	}

	public InfoGis getLandCoverInfoGis(LandCoverNTT ntt) {
		LandCoverInfoGisNTT landCoverInfoGisNTT = infoGisDAO.getLandCoverInfoGis(ntt.getLand_cover_details_id());

		if(landCoverInfoGisNTT == null || landCoverInfoGisNTT.getLandcoverDetailsPkid() == null) {
			return getAndSaveLandCoverInfoGisFromGeoraster(ntt);
		}

		return InfoGisMapper.INSTANCE.entityToDto(landCoverInfoGisNTT);
	}

	private InfoGis getAndSaveLandCoverInfoGisFromGeoraster(LandCoverNTT ntt) {

		InfoGis infoGis = geoRasterClientService.getGeorasterData(ntt.getGeom(), ntt.getSrs());

		if(infoGis != null)  {
			LandCoverInfoGisNTT landCoverInfoGisNTT = LandCoverInfoGisNTT.builder()
					.pkid(infoGisDAO.landCoverDetails3DNextSequenceVal())
					.landcoverDetailsPkid(ntt.getLand_cover_details_id())
					.elevation(infoGis.getAverage_altitude())
					.slope(infoGis.getAverage_slope())
					.aspect(infoGis.getAverage_direction())
					.build();

			infoGisDAO.insertLandCoverInfoGis(landCoverInfoGisNTT);
		}

		return infoGis;
	}

	private InfoGis getAndSaveParcelInfoGisFromGeoraster(ParcelNTT ntt) {

		InfoGis infoGis = geoRasterClientService.getGeorasterData(ntt.getGeom(), ntt.getSrs());

		if(infoGis != null)  {
			ParcelInfoGisNTT parcelInfoGisNTT = ParcelInfoGisNTT.builder()
					.pkid(infoGisDAO.parcelDetails3DNextSequenceVal())
					.parcelDetailsPkid(ntt.getPkid())
					.elevation(infoGis.getAverage_altitude())
					.slope(infoGis.getAverage_slope())
					.aspect(infoGis.getAverage_direction())
					.build();

			infoGisDAO.insertParcelInfoGis(parcelInfoGisNTT);
		}

		return infoGis;
	}


}
