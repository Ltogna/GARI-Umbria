package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.FarmingFormNTT;
import com.abacogroup.lpisgisserver.resources.res.units.FarmingForm;

@Mapper
public interface FarmingFormMapper {

	FarmingFormMapper INSTANCE = Mappers.getMapper(FarmingFormMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	FarmingForm entityToDto(FarmingFormNTT entity);
	
	@Mapping(target = "flVisible", expression = "java(dto.getVisible() ? 1 : 0)")
	@Mapping(target = "typeCode", ignore = true)
	FarmingFormNTT dtoToEntity(FarmingForm dto);
}
