package com.abacogroup.lpisgisserver.core.pub;

import com.abacogroup.lpisgisserver.core.BaseService;
import com.abacogroup.lpisgisserver.core.ErrorDescriptionsService;
import com.abacogroup.lpisgisserver.core.ExternalConfigService;
import com.abacogroup.lpisgisserver.core.InternalConfigService;
import com.abacogroup.lpisgisserver.core.OliveUnitsService;
import com.abacogroup.lpisgisserver.core.StyleService;
import com.abacogroup.lpisgisserver.core.mappers.pub.OliveUnitV1Mapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.pub.units.olive.OliveUnitV1;

public class OliveUnitsV1Service extends BaseService {

	private OliveUnitsService oliveUnitsService;

	public OliveUnitsV1Service(DAOContainer dc, OliveUnitsService oliveUnitsService, InternalConfigService conf, ExternalConfigService externalConf, 
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, 
			PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.oliveUnitsService = oliveUnitsService;
		
	}

	public OliveUnitV1 getOliveUnitById(ServiceSupportEnv env, Long oliveUnitId) {
		return OliveUnitV1Mapper.INSTANCE.toResponseV1(oliveUnitsService.getOliveUnitById(env, oliveUnitId));
	}
	
}
