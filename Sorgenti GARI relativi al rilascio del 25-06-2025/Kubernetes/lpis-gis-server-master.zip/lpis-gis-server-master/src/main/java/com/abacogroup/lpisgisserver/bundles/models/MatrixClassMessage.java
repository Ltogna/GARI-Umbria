package com.abacogroup.lpisgisserver.bundles.models;

import java.util.List;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MatrixClassMessage {
	private String code;
	private AbsoluteDate day_from;
	private AbsoluteDate day_to;
	private String default_land_cover_code;
	private String default_land_use_code;
	private String fill_rgba;
	private String line_rgba;
	private Integer line_thick;
	private List<CodeForClassMessage> land_cover_codes;
	private List<CodeForClassMessage> land_use_codes;
	private String extended_by_class;
}
