package com.abacogroup.lpisgisserver.core;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.exceptions.lpiscadatral.GenericCrossTenantLpisException;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.CrossTenantLpisInternalConfig;
import com.abacogroup.lpisgisserver.resources.res.pub.BlockListV1;
import com.abacogroup.lpisgisserver.resources.res.pub.ParcelV1;
import com.abacogroup.lpisgisserver.resources.res.pub.SectorV1;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CrossTenantLpisClientService extends BaseService {

	private final Client client;
	private final String apikey;
	
	private static final String SECTOR_CODE_PARAM = "sector_code";
	private static final String FILTER_PARAM = "filter";
	private static final String NEXT_KEY_PARAM = "next_key";
	private static final String PAGE_SIZE_PARAM = "page_size";
	private static final String ACCEPT_LANGUAGE = "accept-language";
	private static final String INCLUDE_GEOMETRIES_PARAM = "include_geometries";
	private static final String AUTHORIZATION = "Authorization";
	private static final String APIKEY_PREFIX = "APIKEY ";

	private static final String GET_SECTORS_PATH = "/public/v1/lpis/sectors";
	private static final String GET_BLOCKS_PATH = "/public/v1/lpis/sectors/{sector_code}/blocks";
	private static final String GET_PARCELS_PATH = "/public/v1/lpis/parcels/{referenceDate}";

	public CrossTenantLpisClientService(DAOContainer dc, InternalConfigService internalConf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, PluginEnvironment pluginEnvironment, 
			Client client, String apikey) {
		super(dc, internalConf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);
		
		this.client = client;
		this.apikey = apikey;
	}

	public InfiniteListResults<SectorV1> getLpisSectors(ServiceSupportEnv env, String filter) {

		Response response = buildWebTarget(env).path(GET_SECTORS_PATH)
				.queryParam(INCLUDE_GEOMETRIES_PARAM, env.getIncludeGeometries() == 1)
				.queryParam("filter", filter)
				.queryParam(NEXT_KEY_PARAM, env.getNextKey())
				.queryParam(PAGE_SIZE_PARAM, env.getPageSize())
				.request(MediaType.APPLICATION_JSON_TYPE)
				.accept(MediaType.APPLICATION_JSON_TYPE)
				.header(ACCEPT_LANGUAGE, env.getLang())
				.header(AUTHORIZATION, APIKEY_PREFIX + this.apikey)
				.get();

		if (response.getStatus() == 200) {
			response.bufferEntity();
			return response.readEntity(new GenericType<InfiniteListResultsImpl<SectorV1>>() { });
		} else {
			Map<String, Object> errorResponse = response.readEntity(new GenericType<HashMap<String, Object>>() { });
			String errorCode = (String) errorResponse.get("errorCode");
			errorCode += ", " + (String) errorResponse.get("message");

			GenericCrossTenantLpisException ex = new GenericCrossTenantLpisException(Status.BAD_REQUEST,
					env.getOperation(), ErrorField.CROSS_TENANT_LPIS_RESPONSE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), errorCode);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}

	public BlockListV1 getLpisBlocks(ServiceSupportEnv env, String filter) {

		Response response = buildWebTarget(env).path(GET_BLOCKS_PATH)
				.resolveTemplate(SECTOR_CODE_PARAM, env.getSectorCode())
				.queryParam(FILTER_PARAM, filter)
				.queryParam(INCLUDE_GEOMETRIES_PARAM, env.getIncludeGeometries() == 1)
				.queryParam(NEXT_KEY_PARAM, env.getNextKey())
				.queryParam(PAGE_SIZE_PARAM, env.getPageSize())
				.request(MediaType.APPLICATION_JSON_TYPE)
				.accept(MediaType.APPLICATION_JSON_TYPE)
				.header(ACCEPT_LANGUAGE, env.getLang())
				.header(AUTHORIZATION, APIKEY_PREFIX + this.apikey)
				.get();

		if (response.getStatus() == 200) {
			response.bufferEntity();
			return response.readEntity(BlockListV1.class);
		} else {
			Map<String, Object> errorResponse = response.readEntity(new GenericType<HashMap<String, Object>>() { });
			String errorCode = (String) errorResponse.get("errorCode");
			errorCode += ", " + (String) errorResponse.get("message");

			GenericCrossTenantLpisException ex = new GenericCrossTenantLpisException(Status.BAD_REQUEST,
					env.getOperation(), ErrorField.CROSS_TENANT_LPIS_RESPONSE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), errorCode);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}

	public InfiniteListResults<ParcelV1> getLpisParcels(ServiceSupportEnv env, String filter) {

		Response response = buildWebTarget(env).path(GET_PARCELS_PATH)
				.resolveTemplate("referenceDate", env.getReferenceDate())
				.queryParam("sector_descr_filter", env.getSectorCode())
				.queryParam("block_descr_filter", env.getBlockCode())
				.queryParam("parcel_filter", filter)
				.queryParam(INCLUDE_GEOMETRIES_PARAM, env.getIncludeGeometries() == 1)
				.queryParam(NEXT_KEY_PARAM, env.getNextKey())
				.queryParam(PAGE_SIZE_PARAM, env.getPageSize())
				.request(MediaType.APPLICATION_JSON_TYPE)
				.accept(MediaType.APPLICATION_JSON_TYPE)
				.header(ACCEPT_LANGUAGE, env.getLang())
				.header(AUTHORIZATION, APIKEY_PREFIX + this.apikey)
				.get();

		if (response.getStatus() == 200) {
			response.bufferEntity();
			return response.readEntity(new GenericType<InfiniteListResultsImpl<ParcelV1>>() { });
		} else {
			Map<String, Object> errorResponse = response.readEntity(new GenericType<HashMap<String, Object>>() { });
			String errorCode = (String) errorResponse.get("errorCode");
			errorCode += ", " + (String) errorResponse.get("message");

			GenericCrossTenantLpisException ex = new GenericCrossTenantLpisException(Status.BAD_REQUEST,
					env.getOperation(), ErrorField.CROSS_TENANT_LPIS_RESPONSE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), errorCode);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}
	
	
	private WebTarget buildWebTarget(ServiceSupportEnv env) {
		CrossTenantLpisInternalConfig conf = (CrossTenantLpisInternalConfig) internalConf.getValue(env.getTenantId(), InternalConfigKeys.CROSS_TENANT_LPIS_CONFIG.getKey());
		String confUrl = internalConf.getStringValue(env.getTenantId(), InternalConfigKeys.CROSS_TENANT_LPIS_URL.getKey());
		if (conf == null || !conf.getEnabled() || confUrl == null || StringUtils.isBlank(this.apikey)) {
			GenericCrossTenantLpisException ex = new GenericCrossTenantLpisException(Status.BAD_REQUEST,
					env.getOperation(), ErrorField.CONFIG,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), null);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		return client.target(confUrl);
		
	}
	
}
