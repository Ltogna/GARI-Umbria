package com.abacogroup.lpisgisserver.bundles;

import java.io.File;
import java.nio.file.Path;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.lpisgisserver.bundles.models.InternalConfigListMessage;
import com.abacogroup.lpisgisserver.db.dao.ConfigDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.ntt.ConfigNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

public class InternalConfigMessageProcessor extends AbstractMessageProcessor {

	private ConfigDAO configDAO;
	private final ObjectMapper objectMapper = new ObjectMapper();

	private static final Logger log = LoggerFactory.getLogger(InternalConfigMessageProcessor.class);

	public InternalConfigMessageProcessor(DAOContainer dc) {
		super(dc);
		this.configDAO = dc.getConfigDAO();
	}

	@Override
	public String getDomainName() {
		return "internal-config";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> file.getAbsolutePath().endsWith(".json"))
				.forEach(file -> processFile(message.getTenantId(), file));
	}

	private void processFile(String tenantId, File file) {
		try {
			InternalConfigListMessage message = objectMapper.readValue(file, InternalConfigListMessage.class);

			if (message == null) {
				return;
			}

			if (file.getAbsolutePath().endsWith(".delete.json")) {
				doDelete(tenantId, message);
			} else {
				doInsertOrUpdate(tenantId, message);
			}
		} catch (Exception e) {
			log.error(String.format(ERROR_PROCESSING_FILE_MESSAGE, file.getName(), tenantId), e);
		}
	}

	private void doInsertOrUpdate(String tenantId, InternalConfigListMessage message) {

		// Always insert given keys, if not configured they will not be used but, in this way, ui_ can be written...
		message.getInternalConfig().forEach(config -> {
			try {

				ConfigNTT savedConfig = configDAO.getConfigByTenantAndKey(tenantId, config.getKey());

				Integer configFlClient = config.getFl_client() != null && config.getFl_client() ? 1 : 0;

				ConfigNTT configToInsertOrUpdate = ConfigNTT.builder()
						.tenantId(tenantId)
						.key(config.getKey())
						.value(objectMapper.writeValueAsString(config.getValue()).replace("\\\"", "\"").replaceAll("^\"(.+)\"$", "$1")) // load json instead of a simple string and fix the the doublequotes for old bundles
						.fl_client(configFlClient)
						.name(config.getName())
						.build();

				if (savedConfig == null) {
					configDAO.insert(configToInsertOrUpdate);
				} else if (!savedConfig.equals(configToInsertOrUpdate)) {
					configDAO.updateValue(configToInsertOrUpdate);
				}

			} catch (Exception e) {
				log.error("Error during insert internal config key {} with value {} for tenant {}, {}", config.getKey(), config.getValue(), tenantId, e);
			}
		});

	}

	private void doDelete(String tenantId, InternalConfigListMessage message) {
		message.getInternalConfig().forEach(config -> {
			try {
				configDAO.deleteByTenantAndKey(tenantId, config.getKey());
			} catch (Exception e) {
				log.error("Error during delete internal config key {} for tenant {}: {}", config.getKey(), tenantId, e);
			}
		});

	}

}
