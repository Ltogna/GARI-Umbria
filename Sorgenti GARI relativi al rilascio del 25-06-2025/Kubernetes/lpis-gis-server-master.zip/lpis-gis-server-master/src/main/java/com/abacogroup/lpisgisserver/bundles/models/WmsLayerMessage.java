package com.abacogroup.lpisgisserver.bundles.models;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WmsLayerMessage {
	private String wms_server_code;
	private Long display_order;
	private String code;
	private String layer_name;
	private Double max_pixel_val;
	private Integer foreground_level;
	private List<WmsLayerModule> modules;
	private Map<String, String> description;
	private String layer_options;
	private String path;
	private String catalogue_code;
	private String info_catalogue_code;
}
