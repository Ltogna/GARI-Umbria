package com.abacogroup.lpisgisserver.core.exceptions.parcel;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidParcelDataException extends AbstractException {

	private static final long serialVersionUID = -2116356891113212619L;

	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_PARCEL_DATA;

	public InvalidParcelDataException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new InvalidParcelDataExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Parcel data is not valid")
	public static class InvalidParcelDataExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 2398182927627939699L;

		public InvalidParcelDataExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
