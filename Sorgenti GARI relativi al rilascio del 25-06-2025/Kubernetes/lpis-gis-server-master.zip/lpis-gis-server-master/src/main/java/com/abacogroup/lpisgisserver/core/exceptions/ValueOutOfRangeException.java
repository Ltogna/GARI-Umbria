package com.abacogroup.lpisgisserver.core.exceptions;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class ValueOutOfRangeException extends AbstractException {

	private static final long serialVersionUID = -3134256538923526976L;

	public ValueOutOfRangeException(Status code, ErrorCode errorCode, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang, String minValue, String maxValue) {
		super(code, new ValueOutOfRangeExceptionBody(code.getStatusCode(), errorCode, operation, errorField, errorDescriptions, lang));
		
		String msg = String.format(this.getBody().getMessage(), minValue, maxValue);
		this.getBody().setMessage(msg);
	}

	@Schema(description = "The value of the field must be between a defined range")
	public static class ValueOutOfRangeExceptionBody extends AbstractExceptionBody {

		private static final long serialVersionUID = -5103191433789374803L;

		public ValueOutOfRangeExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
