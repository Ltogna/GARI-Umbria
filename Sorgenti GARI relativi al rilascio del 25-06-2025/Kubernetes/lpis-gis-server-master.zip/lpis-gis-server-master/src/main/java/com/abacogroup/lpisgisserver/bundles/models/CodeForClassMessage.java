package com.abacogroup.lpisgisserver.bundles.models;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CodeForClassMessage {
	private String code;
	private AbsoluteDate day_from;
	private AbsoluteDate day_to;
}
