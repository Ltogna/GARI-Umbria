package com.abacogroup.lpisgisserver.core.exceptions.externalsource;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class GenericExternalSourceException extends AbstractException {

	private static final long serialVersionUID = 3916917486945234067L;

	private static final ErrorCode ERROR_CODE = ErrorCode.GENERIC_EXTERNAL_SOURCE_ERROR;

	public GenericExternalSourceException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new GenericExternalSourceExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Generic area error")
	public static class GenericExternalSourceExceptionBody extends AbstractExceptionBody {

		private static final long serialVersionUID = 1152549761827624684L;

		public GenericExternalSourceExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
