package com.abacogroup.lpisgisserver.bundles;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.lpisgisserver.bundles.models.I18nListMessage;
import com.abacogroup.lpisgisserver.bundles.models.I18nMessage;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.ntt.I18nNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

public class I18nMessageProcessor extends AbstractMessageProcessor {

	private final ObjectMapper objectMapper;


	private static final Logger log = LoggerFactory.getLogger(I18nMessageProcessor.class);

	public I18nMessageProcessor(DAOContainer dc) {
		super(dc);
		objectMapper = new ObjectMapper();
	}

	@Override
	public String getDomainName() {
		return "i18n";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
				.forEach(file -> deleteMessage(message.getTenantId(), file));

		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
						&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
				.forEach(file -> insertOrUpdateMessage(message.getTenantId(), file));
	}

	private void insertOrUpdateMessage(String tenantId, File file) {
		try {
			I18nListMessage i18nMessages = objectMapper.readValue(file, I18nListMessage.class);

			if (i18nMessages == null || i18nMessages.getI18n_list() == null || i18nMessages.getI18n_list().isEmpty()) {
				return;
			}

			i18nMessages.getI18n_list().stream().forEach(message -> insertOrUpdateI18nMessages(tenantId, message));

		} catch (Exception e) {
			log.error(String.format(ERROR_PROCESSING_FILE_MESSAGE, file.getName(), tenantId), e);
		}
	}

	private void deleteMessage(String tenantId, File file) {
		try {
			I18nListMessage i18nMessages = objectMapper.readValue(file, I18nListMessage.class);

			if (i18nMessages == null || i18nMessages.getI18n_list() == null || i18nMessages.getI18n_list().isEmpty()) {
				return;
			}

			i18nMessages.getI18n_list().stream().forEach(message -> deleteI18nMessage(message, tenantId));

		} catch (Exception e) {
			log.error(String.format(ERROR_PROCESSING_FILE_MESSAGE, file.getName(), tenantId), e);
		}
	}

	private void deleteI18nMessage(I18nMessage message, String tenantId) {
		try {
			if (message.getTranslations() == null || message.getTranslations().isEmpty()) {
				I18nNTT messageNTT = I18nNTT.builder()
						.field_name(message.getField())
						.i18n_value(message.getValue())
						.table_name(message.getTable())
						.tenant_id(tenantId)
						.build();

				List<I18nNTT> toDelete = i18nDAO.findAllI18nByLpisI18nKeys(messageNTT);
				if (!toDelete.isEmpty()) {
					i18nDAO.deleteAllI18n(messageNTT);
				}
			} else {
				message.getTranslations().forEach((lang, text) -> {
					try {
						I18nNTT messageNTT = I18nNTT.builder()
								.field_name(message.getField())
								.i18n_text(text)
								.i18n_value(message.getValue())
								.lang(lang)
								.table_name(message.getTable())
								.tenant_id(tenantId)
								.build();

						if (i18nDAO.findI18nByLpisI18nKeys(messageNTT) != null) {
							i18nDAO.deleteI18nLang(messageNTT);
						}
					} catch (Exception e) {
						log.error("Error during delete i18n message " + message.toString() + " with lang " + lang + FOR_TENANT + tenantId, e);
					}
				});
			}
		} catch (Exception e) {
			log.error("Error during delete i18n message " + message.toString() + FOR_TENANT + tenantId, e);
		}
	}
}
