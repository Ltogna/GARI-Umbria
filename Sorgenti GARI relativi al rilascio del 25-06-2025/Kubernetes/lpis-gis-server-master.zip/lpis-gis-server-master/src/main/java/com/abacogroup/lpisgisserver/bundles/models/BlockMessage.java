package com.abacogroup.lpisgisserver.bundles.models;

import org.locationtech.jts.geom.Geometry;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BlockMessage {
	private String description;
	private Geometry geom;
	private String short_descr;
	private String srs;
	private String sector_code;
	private String block_code;
}
