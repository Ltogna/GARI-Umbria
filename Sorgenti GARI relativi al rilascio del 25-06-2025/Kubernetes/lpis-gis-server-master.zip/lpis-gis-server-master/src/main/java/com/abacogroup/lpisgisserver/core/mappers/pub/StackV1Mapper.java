package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.resources.res.Stack;
import com.abacogroup.lpisgisserver.resources.res.pub.StackV1;

@Mapper
public interface StackV1Mapper {

	StackV1Mapper INSTANCE = Mappers.getMapper(StackV1Mapper.class);
	
	@InheritInverseConfiguration
	StackV1 toResponseV1(Stack entity);
	
}
