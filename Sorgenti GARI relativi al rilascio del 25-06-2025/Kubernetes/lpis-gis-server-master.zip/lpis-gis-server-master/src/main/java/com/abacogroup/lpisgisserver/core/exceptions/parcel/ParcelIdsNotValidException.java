package com.abacogroup.lpisgisserver.core.exceptions.parcel;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class ParcelIdsNotValidException extends AbstractException {

	private static final long serialVersionUID = -6811571790425954335L;

	private static final ErrorCode ERROR_CODE = ErrorCode.PARCEL_IDS_NOT_VALID;

	public ParcelIdsNotValidException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new ParcelIdsNotValidExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Some parcel ids is not valid")
	public static class ParcelIdsNotValidExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 6935251354113122687L;

		public ParcelIdsNotValidExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
