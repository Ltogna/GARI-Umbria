package com.abacogroup.lpisgisserver.core;

import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.geometryeditor.EditorResult;
import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.ParcelCodeNotValidException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidEditParcelDataException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionGeomException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionParcelIdException;
import com.abacogroup.lpisgisserver.core.exceptions.session.ParcelBlockNotValidException;
import com.abacogroup.lpisgisserver.core.exceptions.session.ParcelDataAlreadyExistException;
import com.abacogroup.lpisgisserver.core.models.EditParcelData;
import com.abacogroup.lpisgisserver.core.support.EditorSupportParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.BlockDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.ParcelsDAO;
import com.abacogroup.lpisgisserver.db.ntt.BlockNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.db.ntt.SectorNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.plugins.PluginConstants;
import com.abacogroup.lpisgisserver.plugins.models.BlockPluginModel;
import com.abacogroup.lpisgisserver.plugins.models.CheckParcelNamePluginModel;
import com.abacogroup.lpisgisserver.plugins.models.ParcelPluginModel;
import com.abacogroup.lpisgisserver.resources.res.Block;
import com.abacogroup.lpisgisserver.resources.res.Parcel;
import com.abacogroup.lpisgisserver.resources.res.Sector;
import com.abacogroup.lpisgisserver.sdk.SdkParcel;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EditParcelsSupportService extends BaseService {

	private static final int DO_NOT_INCLUDE_OUTDATED_PARCELS = 0;

	private final EditSessionSupportService editSessionSupportService;

	private final EditParcelsDAO editParcelsDAO;
	private final ParcelsDAO parcelsDAO;
	private final BlockDAO blockDAO;

	public EditParcelsSupportService(DAOContainer dc, InternalConfigService internalConf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, EditSessionSupportService editSessionSupportService,
			PluginEnvironment pluginEnvironment) {

		super(dc, internalConf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.editSessionSupportService = editSessionSupportService;

		this.editParcelsDAO = dc.getEditParcelsDAO();
		this.parcelsDAO = dc.getParcelsDAO();
		this.blockDAO = dc.getBlockDAO();
	}

	/**
	* Check if it is possible to edit a parcel. This method is called by edit_actions.
	* 
	* @param isForPreview - true if preview is needed false if preview is needed
	* @param params - EditorSupportParams with the session uuid and the parameters
	* @param parcelIds - List of parcel ids to check
	* @param geom - Geometry to check if it is locked for preview
	*/
	public void checkCanEdit(boolean isForPreview, EditorSupportParams params, List<Long> parcelIds, Geometry geom) {

		editSessionSupportService.checkEditableSession(params, Operation.CHECK_CAN_EDIT_PARCEL);

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		
		// CHECK parcelIds TODO partition on list
		// If the parcel ids are not equal to the number of parcels in the database.
		if (parcelIds != null && editParcelsDAO.countByIdSessionId(params.getSession().getUuid(), parcelIds) != parcelIds.size()) {
			InvalidSessionParcelIdException ex = new InvalidSessionParcelIdException(Status.BAD_REQUEST,
					params.getOperation(), ErrorField.PARCEL_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		// for each parcelId check Territorial Scopes if is enabled
		editSessionSupportService.checkScopes(env, parcelIds, null);

		// Refreshes the session if the preview is for preview.
		if (Boolean.FALSE.equals(isForPreview)) {
			editSessionSupportService.refreshSession(params.getSession().getUuid());
		}

		// Check if the current session has a valid geometry.
		if (!isForPreview && geom != null && !params.getSession().getLock_geom().contains(geom)) {
			checkSessionGeom(params, geom);
		}
		
		// Check for frobidden edit landcovers
		checkForbiddenEditLcCodeByParcelIds(env, parcelIds);
	}	

	/**
	* Check if the geometry is enlarged in the session. This is done by enlarging the geometry with parcels touched by the geometry
	* 
	* @param params - The parameters used to build the service
	* @param geom - The geometry to check for enlarging in
	*/
	public void checkSessionGeom(EditorSupportParams params, Geometry geom) throws InvalidSessionGeomException {
		// try to enlarge your geometry
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);

		Double bufferSize = this.internalConf.getDoubleValue(env.getTenantId(), InternalConfigKeys.BUFFER_SIZE_KEY.getKey());

		// import in session the parcels touched by the geometry
		List<ParcelNTT> newInterParc = parcelsDAO.getParcelsWithInteractions(env.getTenantId(), env.getReferenceDate().toString(),
				geom.buffer(bufferSize), env.getSrs());

		List<Geometry> myGeoms = new ArrayList<>();
		myGeoms.add(geom);
		myGeoms.add(params.getSession().getLock_geom());
		// Add new inter parcels to the list of geometries.
		if (newInterParc != null && !newInterParc.isEmpty())
			myGeoms.addAll(newInterParc.stream().map(ParcelNTT::getGeom).collect(toList()));

		Geometry enlargedMBR = Utils.getUnion(myGeoms).buffer(bufferSize).getEnvelope();

		Long foundLockedGeomsCount = editSessionSupportService.findIntersectedSessionLockGeom(env.getTenantId(), env.getSessionId(), enlargedMBR);

		// If there are no locked geometries in the session.
		if (foundLockedGeomsCount > 0) {
			InvalidSessionGeomException ex = new InvalidSessionGeomException(Status.BAD_REQUEST,
					params.getOperation(), ErrorField.GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getReqContext().getTenantId()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		// Import new InterParcels from the existing parcels.
		if (newInterParc != null && !newInterParc.isEmpty()) {
			List<Long> newInterParcIds = newInterParc.stream().map(ParcelNTT::getParcel_id).collect(toList());
			List<Long> lockedParcels = editSessionSupportService.findOtherSessionsLockedParcelIds(env.getSessionId(), newInterParcIds);
			// If the locked parcels is null or empty throw InvalidSessionGeomException.
			if (lockedParcels != null && !lockedParcels.isEmpty()) {
				InvalidSessionGeomException ex = new InvalidSessionGeomException(Status.BAD_REQUEST,
						params.getOperation(), ErrorField.GEOM,
						this.errorDescriptionsService.getTenantErrorDescriptions(params.getReqContext().getTenantId()), params.getReqContext().getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}

			editSessionSupportService.importLockParcelsEdit(env, newInterParcIds);
		}

		// Checks if the session lock is enabled for the current session.
		if (!editSessionSupportService.enlargeSessionLockGeometry(env.getTenantId(), env.getSessionId(), enlargedMBR)) {
			InvalidSessionGeomException ex = new InvalidSessionGeomException(Status.BAD_REQUEST,
					params.getOperation(), ErrorField.GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(params.getReqContext().getTenantId()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}

	/**
	* Check the parcel name. This is a helper method to call the checkParcelName plugin.
	* 
	* @param env - service support environment for the request. Cannot be null.
	* @param reqParcelName - request parcel name. Cannot be null or empty.
	* @param reqBlockId - request block id. Cannot be null or empty.
	* 
	* @return error message if there is an error null otherwise. Note : the return value is a string in the format : " "
	*/
	public String checkParcelName(ServiceSupportEnv env, String reqParcelName, Long reqBlockId) {

		// If the reqParcelName is blank or if the reqBlockId is null then an InvalidEditParcelDataException is thrown.
		if (StringUtils.isBlank(reqParcelName) && reqBlockId == null) {
			InvalidEditParcelDataException ex = new InvalidEditParcelDataException(Status.BAD_REQUEST,
					Operation.UPDATE_PARCEL_DATA, ErrorField.PARCEL_DATA,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		reqParcelName = applyDecodeParcelNamePlugin(env, reqParcelName);

		SdkParcel sdkParcel = loadParcelPlugin(env.getTenantId(), PluginConstants.CHECK_PARCEL_NAME_KEY);
		// Check parcel name and check if it is valid.
		if (sdkParcel != null) {
			CheckParcelNamePluginModel checkParcel = null;
			try {
				checkParcel = sdkParcel.checkParcelName(reqParcelName, env.getLang(), pluginEnvironment);
			} catch (Exception e) {
				ParcelCodeNotValidException ex = new ParcelCodeNotValidException(Status.BAD_REQUEST, Operation.UPDATE_PARCEL_DATA, ErrorField.PARCEL_CODE,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error("Error during check parcel name with plugin {} : {}", sdkParcel.getClass().getName(), e);
				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}

			// Checks if the parcel is valid.
			if (!checkParcel.isValid()) {
				ParcelCodeNotValidException ex = new ParcelCodeNotValidException(Status.BAD_REQUEST, Operation.UPDATE_PARCEL_DATA, ErrorField.PARCEL_CODE,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				ex.getBody().setMessage(checkParcel.getMessage());
				// Set the error field of the check parameter.
				if (checkParcel.getErrorField() != null)
					ex.getBody().setErrorField(checkParcel.getErrorField());

				log.error(checkParcel.getMessage());

				throw ex;
			}
		}

		return reqParcelName;
	}

	public Parcel buildParcelFromParcelNTT(ParcelNTT parcel, Long previousId) {
		BlockNTT block = parcel.getBlock();
		SectorNTT sector = parcel.getSector();
		return Parcel.builder()
				.id(parcel.getParcel_id())
				.parent_id(parcel.getParent_id())
				.parcel(parcel.getParcel())
				.day_from(parcel.getDay_from())
				.day_to(parcel.getDay_to()) // it shouldn't be null
				.srs(parcel.getSrs())
				.area_sqm(Math.round(parcel.getArea_sqm()))
				.geom(parcel.getGeom())
				.edit_status(parcel.getEdit_status())
				.previous_id(previousId)
				.block(Block.builder()
						.description(block.getDescription())
						.geom(block.getGeom())
						.id(block.getId())
						.sector_id(block.getSector_id())
						.short_descr(block.getShort_descr())
						.srs(block.getSrs())
						.world_geom(block.getWorld_geom())
						.block_code(block.getBlock())
						.build())
				.sector(Sector.builder()
						.description(sector.getDescription())
						.geom(sector.getGeom())
						.id(sector.getId())
						.sector_code(sector.getSector())
						.short_descr(sector.getShort_descr())
						.srs(sector.getSrs())
						.world_geom(sector.getWorld_geom())
						.build())
				.external_code(parcel.getExternal_code())
				.build();
	}

	public Long insertNewParcel(EditorSupportParams params, ParcelNTT p) {
		Long nextEditId = editParcelsDAO.nextSequenceVal();
		Long nextNewParcelId = editParcelsDAO.nextNewParcelIdVal(); // for internal use new parcel id are negative sequence

		p.setEdit_id(nextEditId);
		p.setParcel_id(nextNewParcelId);
		p.setSrs(params.getSession().getLock_geom_srs());

		if (p.getBlock() == null || p.getBlock().getId() == null) {
			setNewParcelBlock(params, p);
		}

		// default parcel code, or else empty
		SdkParcel sdkParcel = loadParcelPlugin(params.getSession().getTenant_id(), PluginConstants.CREATE_PARCEL_NAME_KEY);
		if (sdkParcel != null) {
			try {
				log.info("Use plugin {} to create parcel name", sdkParcel.getClass().getCanonicalName());
				if (p.getParcel() == null) {
					BlockPluginModel blockModel = BlockPluginModel.builder().id(p.getBlock().getId()).build();

					ParcelPluginModel parcelModel = ParcelPluginModel.builder()
							.area_sqm(p.getArea_sqm())
							.day_from(p.getDay_from())
							.day_to(p.getDay_to())
							.geom(p.getGeom())
							.parcel(p.getParcel())
							.parcel_id(p.getParcel_id())
							.srs(p.getSrs())
							.block(blockModel)
							.build();

					String parcelCode = sdkParcel.createParcelName(
							params.getSession().getTenant_id(),
							params.getSession().getUuid(),
							parcelModel,
							params.getEditType(),
							pluginEnvironment);

					p.setParcel(parcelCode);
				}

			} catch (Exception e) {
				log.error("Error during retrieve parcel name with plugin {} : {}", sdkParcel.getClass().getName(), e);

				ParcelBlockNotValidException ex = new ParcelBlockNotValidException(Status.BAD_REQUEST,
						params.getOperation(), ErrorField.BLOCK,
						this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
		}

		editSessionSupportService.checkAndInsertEditParcel(params, p);

		return p.getParcel_id();

	}

	private void setNewParcelBlock(EditorSupportParams params, ParcelNTT p) {

		BlockPluginModel blockModel = null;
		boolean findBlock = false;

		SdkParcel sdkParcel = loadParcelPlugin(params.getSession().getTenant_id(), PluginConstants.PARCEL_BLOCK_KEY);
		if (sdkParcel != null) {
			try {
				log.info("Use plugin {} to find block", sdkParcel.getClass().getCanonicalName());

				ParcelPluginModel parcelModel = ParcelPluginModel.builder()
						.area_sqm(p.getArea_sqm())
						.day_from(p.getDay_from())
						.day_to(p.getDay_to())
						.geom(p.getGeom())
						.parcel(p.getParcel())
						.parcel_id(p.getParcel_id())
						.srs(p.getSrs())
						.build();

				blockModel = sdkParcel.findParcelBlock(params.getSession().getTenant_id(), parcelModel, pluginEnvironment);

				if (blockModel != null) {
					p.setBlock(BlockNTT.builder().id(blockModel.getId()).build());
					findBlock = true;
				}

			} catch (Exception e) {
				log.error("Error during retrieve block with plugin {} : {}", sdkParcel.getClass().getName(), e);

				ParcelBlockNotValidException ex = new ParcelBlockNotValidException(Status.BAD_REQUEST,
						params.getOperation(), ErrorField.BLOCK,
						this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()),
						params.getReqContext().getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
		}

		if (sdkParcel == null || !findBlock) {
			List<BlockNTT> blocksInter = blockDAO.findBlocksByTenantSRSWithInteraction(params.getSession().getTenant_id(),
					params.getSession().getLock_geom_srs(), p.getGeom());
			if (blocksInter == null || blocksInter.isEmpty()) {
				ParcelBlockNotValidException ex = new ParcelBlockNotValidException(Status.BAD_REQUEST,
						params.getOperation(), ErrorField.BLOCK,
						this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()),
						params.getReqContext().getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}

			p.setBlock(BlockNTT.builder().id(blocksInter.get(0).getId()).build());
		}

	}

	/**
	 * Find the inherit parcel id from parcelcode and blockid
	 */
	public Long getInheritParcelId(EditorSupportParams params, ServiceSupportEnv env,
			String parcelCode, Long blockId) {

		if (StringUtils.isBlank(parcelCode) || blockId == null) {
			return null;
		}

		// If a parcel with the same the code and block is already in editing, and not deleted (geom == null), exception!
		List<ParcelNTT> inEditParcels = editParcelsDAO.findInEditBySessionId(env.getSessionId(), env.getReferenceDate(), null);
		inEditParcels.stream()
				.filter(editParcel -> editParcel.getGeom() != null && editParcel.getBlock().getId().equals(blockId)
						&& editParcel.getParcel() != null && editParcel.getParcel().equalsIgnoreCase(parcelCode))
				.findFirst().ifPresent(t -> {
					ParcelDataAlreadyExistException ex = new ParcelDataAlreadyExistException(Status.CONFLICT,
							Operation.UPDATE_PARCEL_DATA, ErrorField.PARCEL_CODE,
							this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

					log.error(ex.getBody().getLogErrorMessage());

					throw ex;
				});

		// also if a parcel with the same cadastral details exists and is not deleted
		ParcelNTT alreadyExistParcel = parcelsDAO.getParcelByTenantSectorBlockIdAndParcel(params.getSession().getTenant_id(), blockId, parcelCode);
		if (alreadyExistParcel != null) {

			ParcelNTT currentParcel = parcelsDAO.getParcelDetail(params.getReqContext().getTenantId(), alreadyExistParcel.getParcel_id(),
					env.getReferenceDate(), null, DO_NOT_INCLUDE_OUTDATED_PARCELS);

			Boolean isDeleted = inEditParcels.stream().anyMatch(editParcel -> editParcel.getParcel_id().equals(alreadyExistParcel.getParcel_id()));
			if (currentParcel != null && !isDeleted) {
				ParcelDataAlreadyExistException ex = new ParcelDataAlreadyExistException(Status.CONFLICT,
						Operation.UPDATE_PARCEL_DATA, ErrorField.PARCEL_CODE,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}

			return alreadyExistParcel.getParcel_id();
		}

		return null;
	}
	
	
	public void setDeletedPersistParcels(EditorSupportParams params, EditorResult<Long> result, List<ParcelNTT> persistParcels) {
		result.getDeleted().stream().forEach(pid -> persistParcels.add(ParcelNTT
				.builder()
				.editorResultParcelId(pid)
				.parcel_id(pid)
				.srs(params.getSession().getLock_geom_srs())
				.geom(null)
				.area_sqm(0.0)
				.edit_status(EditStatus.DELETED)
				.build()));
	}
	
	public Sector getSectorFromParcelsMap(Map<Long, ParcelNTT> parcelsMap, Long key) {
		if (parcelsMap.get(key).getSector() != null) {
			SectorNTT sectorNTT = parcelsMap.get(key).getSector();
			return Sector.builder()
					.description(sectorNTT.getDescription())
					.geom(sectorNTT.getGeom())
					.id(sectorNTT.getId())
					.sector_code(sectorNTT.getSector())
					.short_descr(sectorNTT.getShort_descr())
					.srs(sectorNTT.getSrs())
					.world_geom(sectorNTT.getWorld_geom())
					.build();
		}
		return null;
	}
	
	public Parcel buildParcelEditRes(EditorSupportParams params, Long k, Geometry g, EditParcelData parcelData) {
		return Parcel.builder()
				.id(k)
				.parcel(parcelData.getParcel()) // could be null
				.day_from(params.getSession().getReference_date())
				.day_to(parcelData.getDayTo() != null ? parcelData.getDayTo() : END_OF_WORLD) // it shouldn't be null
				.srs(params.getSession().getLock_geom_srs())
				.area_sqm(Math.round(g.getArea()))
				.geom(g)
				.world_geom(null)
				.block(parcelData.getBlock())
				.sector(parcelData.getSector())
				.last_update(parcelData.getLastUpdate())
				.edit_status(parcelData.getEditStatus())
				.client_ref(parcelData.getClientRef())
				.parent_id(parcelData.getParentParcelId())
				.sde_code(parcelData.getSdeCode())
				.external_code(parcelData.getExternalCode())
				.build();
	}

	public Block getBlockFromParcelsMap(Map<Long, ParcelNTT> parcelsMap, Long key) {
		if (parcelsMap.get(key).getBlock() != null) {
			BlockNTT blockNTT = parcelsMap.get(key).getBlock();
			return Block.builder()
					.description(blockNTT.getDescription())
					.geom(blockNTT.getGeom())
					.id(blockNTT.getId())
					.sector_id(blockNTT.getSector_id())
					.short_descr(blockNTT.getShort_descr())
					.srs(blockNTT.getSrs())
					.world_geom(blockNTT.getWorld_geom())
					.block_code(blockNTT.getBlock())
					.build();
		}
		return null;
	}
}
