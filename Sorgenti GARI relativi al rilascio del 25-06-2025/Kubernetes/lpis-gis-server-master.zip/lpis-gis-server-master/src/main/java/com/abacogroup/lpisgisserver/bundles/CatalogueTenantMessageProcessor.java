package com.abacogroup.lpisgisserver.bundles;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.lpisgisserver.db.dao.CataloguesDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.ntt.CatalogueConfigParamNTT;
import com.abacogroup.lpisgisserver.db.ntt.CatalogueNTT;

public class CatalogueTenantMessageProcessor implements TenantMessageProcessor {

	private static final String TEMPLATE_TENANT_ID = "*";

	private final CataloguesDAO cataloguesDAO;

	private static final Logger log = LoggerFactory.getLogger(CatalogueTenantMessageProcessor.class);

	public CatalogueTenantMessageProcessor(DAOContainer dc) {
		this.cataloguesDAO = dc.getCataloguesDAO();
	}

	@Override
	public void onMessage(TenantMessage message) {
		String tenantId = message.getTenantId();

		if (tenantId.equals(TEMPLATE_TENANT_ID)) {
			return;
		}

		if (cataloguesDAO.getAllTenants().contains(tenantId)) {
			return;
		}

		List<CatalogueNTT> allCatalogues = cataloguesDAO.getCataloguesByTenantId(TEMPLATE_TENANT_ID);

		if (allCatalogues != null) {
			allCatalogues.forEach(catalogue -> {
				try {
					catalogue.setId(cataloguesDAO.nextSequenceValCatalogueId());
					cataloguesDAO.insertCatalogue(tenantId, catalogue);

					List<CatalogueConfigParamNTT> configParams = cataloguesDAO.getCatalogueParamsByCode(TEMPLATE_TENANT_ID, catalogue.getCode());
					cataloguesDAO.deleteCatalogueParamByCode(tenantId, catalogue.getCode());
					if (configParams != null) {
						configParams.forEach(param -> {
							cataloguesDAO.insertCatalogueParam(tenantId, param);
						});
					}
				} catch (Exception e) {
					log.error("Error during insert catalogue with code {} : {}", catalogue.getCode(), e);
				}
			});
		}
	}

}
