package com.abacogroup.lpisgisserver.core.support;

public interface UnitWithDictionary {

	String getFarmingFormCode();
	
	String getCultivationStatusCode();
	
	String getHeaderAnchoringCode();
	
	String getIrrigationCode();
	
	String getPolesHeaderCode();
	
	String getPolesWeavingCode();
	
	String getProductDestinationCode();
	
	String getSupportWiresCode();
	
	String getTerracingCode();
	
	String getVariationTypeCode();
	
	String getVarietyCode();

	String getPlantingTypeCode();
	
	String getQualitySystemCode();
	
	String getProtectionStructureCode();
	
}
