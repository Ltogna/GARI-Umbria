package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.ExternalSourceNTT;
import com.abacogroup.lpisgisserver.db.ntt.ExternalSourceParcelNTT;
import com.abacogroup.lpisgisserver.resources.res.ExternalSourceParcel;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface ExternalSourceDataDAO extends Transactional<ExternalSourceDataDAO>, EnhancedSqlObject {
	
	@SqlQuery("select distinct lesd.external_source_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_external_source_data', 'external_source_code', lesd.external_source_code, :lang)§, lesd.external_source_code) as external_source_description, \n"
			+ "       'SDE:' || lesd.external_source_code as layerUniqueCode, \n"
			+ "       lesd.srs \n"
			+ "  from lpis_external_source_data lesd \n"
			+ " where lesd.tenant_id = :tenantId \n"
			+ "   and lesd.srs = :srs \n"
			+ "")
	@RegisterBeanMapper(ExternalSourceParcelNTT.class)
	public List<ExternalSourceParcelNTT> getAllCodeBySrs(
			@BindBean ServiceSupportEnv env);

	@SqlQuery("select lesd.external_source_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_external_source_data', 'external_source_code', lesd.external_source_code, :lang)§, lesd.external_source_code) as external_source_description, \n"
			+ "       'SDE:' || lesd.external_source_code as layerUniqueCode, \n"
			+ "       lesd.sector, \n"
			+ "       lesd.block, \n"
			+ "       lesd.parcel, \n"
			+ "       lesd.geom, \n"
			+ "       lesd.srs \n"
			+ "  from lpis_external_source_data lesd \n"
			+ " where lesd.tenant_id = :tenantId \n"
			+ "   and (:code is null or lesd.external_source_code = :code) \n"
			+ "   and lesd.sector = :sector \n"
			+ "   and lesd.block = :block \n"
			+ "   and lesd.parcel = :parcel \n"
			+ "")
	@RegisterBeanMapper(ExternalSourceParcelNTT.class)
	public ResultIterator<ExternalSourceParcelNTT> findParcelsBySectorBlockParcelAndTenant(
			@BindBean ServiceSupportEnv env,
			@Bind("code") String sdeCode,
			@Bind("sector") String sectorCode,
			@Bind("block") String blockCode,
			@Bind("parcel") String parcelCode);
	
	@SqlQuery("select distinct lesd.external_source_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_external_source_data', 'external_source_code', lesd.external_source_code, :lang)§, lesd.external_source_code) as external_source_description, \n"
			+ "       'SDE:' || lesd.external_source_code as layerUniqueCode \n"
			+ "  from lpis_external_source_data lesd \n"
			+ " where lesd.tenant_id = :tenantId \n"
			+ "   and (:srs is null or lesd.srs = :srs)"
			+ "")
	@RegisterBeanMapper(ExternalSourceNTT.class)
	public List<ExternalSourceNTT> findExternalSourceCodeByTenantAndSrs(@BindBean ServiceSupportEnv env, @Bind("srs") String srs);
	
	@SqlQuery("select distinct lesd.external_source_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_external_source_data', 'external_source_code', lesd.external_source_code, :lang)§, lesd.external_source_code) as external_source_description, \n"
			+ "       'SDE:' || lesd.external_source_code as layerUniqueCode \n"
			+ "  from lpis_external_source_data lesd \n"
			+ " where lesd.tenant_id = :tenantId \n"
			+ "   and lesd.sector = :sector \n"
			+ "   and lesd.block = :block \n"
			+ "   and lesd.parcel = :parcel \n"
			+ "")
	@RegisterBeanMapper(ExternalSourceNTT.class)
	public List<ExternalSourceNTT> findExternalSourceCodeBySectorBlockParcelAndTenant(
			@BindBean ServiceSupportEnv env,
			@Bind("sector") String sectorCode,
			@Bind("block") String blockCode,
			@Bind("parcel") String parcelCode);

	@SqlUpdate("""
            delete
              from lpis_external_source_data 
             where <criteria>
              """)
	public void deleteByCriteria(@BindCriteria Criteria criteria);

	@SqlUpdate("""
			insert into lpis_external_source_data (tenant_id, external_source_code, sector, block, parcel, geom, srs, filename)
			values (:tenantId, :externalSourceCode, :sector, :block, :parcel, :geom, :srs, :filename)
			""")
	public void insert(
			@Bind("tenantId") String tenantId, 
			@Bind("externalSourceCode") String externalSourceCode,
			@Bind("filename") String filename,
			@BindBean ExternalSourceParcel externalParcel);

}
