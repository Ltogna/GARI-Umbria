package com.abacogroup.lpisgisserver.bundles.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class MatrixLandCoverMetadataMessage extends MatrixClassMetadataMessage {
	private String land_cover_code;
}
