package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.units.fruit.FruitUnitDetailsNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.fruit.FruitUnitNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.FruitUnitWithParcelDetailsNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface FruitUnitsDAO extends Transactional<FruitUnitsDAO>, EnhancedSqlObject {

	@SqlQuery("§select_nextval(lpis_unit_fruitunit_details_sequence)§")
	Long nextFruitUnitDetailPkidVal();

	@SqlUpdate("INSERT INTO lpis_unit_fruitunit_details (pkid, unit_id, tenant_id, type_code, variety_code, "
			+ "    area_sqm, planting_day, planting_day_precision, eradicate_day, planting_type_code, distance_on_the_row_cm, "
			+ "    distance_between_rows_cm, plants_number, farming_form_code, "
			+ "    irrigation_code, altitude_above_sea_level, quality_system_code, protection_structure_code,"
			+ "    external_code, user_id_insert, user_id_delete, dt_insert, dt_delete, day_from, day_to, unit_code, parent_unit_code) "
			+ "values (:unitDetailId, :unitId, :tenantId, :typeCode, :variety.code, "
			+ "    :areaSqm, :plantingDay, :plantingDayPrecision, :eradicateDay, :plantingType.code, :distanceOnTheRowCM, "
			+ "    :distanceBetweenRowsCM, :plantsNumber, :farmingForm.code, "
			+ "    :irrigation.code, :altitudeAboveSeaLevel, :qualitySystem.code, :protectionStructure.code, "
			+ "    :externalCode, :userId, null, §current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :dayFrom, :dayTo, :unitCode, :parentUnitCode) "
			+ "")
	void insertFruitUnitDetail(@BindBean ServiceSupportEnv env, @BindBean FruitUnitDetailsNTT fruitUnitDetailsNTT);

	@SqlQuery("select fd.pkid as unit_detail_id, \n"
			+ "   u.id as unit_id, \n"
			+ "   u.land_cover_id, \n"
			+ "   u.type_code, \n"
			+ "   fd.unit_code, \n"
			+ "   fd.parent_unit_code, \n"
			+ "   luv.code as variety_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_variety', 'code', luv.type_code||':'||luv.code, :lang)§ as variety_description, \n"
			+ "   luv.fl_visible as variety_fl_visible, \n"
			+ "   fd.area_sqm, \n"
			+ "   fd.planting_day, \n"
			+ "   fd.planting_day_precision, \n"
			+ "   fd.eradicate_day, \n"
			+ "   lupt.code as planting_type_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_planting_type', 'code', lupt.type_code||':'||lupt.code, :lang)§ as planting_type_description, \n"
			+ "   lupt.fl_visible as planting_type_fl_visible, \n"
			+ "   fd.distance_on_the_row_cm, \n"
			+ "   fd.distance_between_rows_cm, \n"
			+ "   fd.plants_number, \n"
			+ "   luff.code as farming_form_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_farming_form', 'code', luff.type_code||':'||luff.code, :lang)§ as farming_form_description, \n"
			+ "   luff.fl_visible as farming_form_fl_visible, \n"
			+ "   lui.code as irrigation_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_irrigation', 'code', lui.type_code||':'||lui.code, :lang)§ as irrigation_description, \n"
			+ "   lui.fl_visible as irrigation_fl_visible, \n"
			+ "   fd.altitude_above_sea_level, \n"
			+ "   luqs.code as quality_system_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_quality_system', 'code', luqs.type_code||':'||luqs.code, :lang)§ as quality_system_description, \n"
			+ "   luqs.fl_visible as quality_system_fl_visible, \n"
			+ "   lups.code as protection_structure_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_protection_structure', 'code', lups.type_code||':'||lups.code, :lang)§ as protection_structure_description, \n"
			+ "   lups.fl_visible as protection_structure_fl_visible, \n"
			+ "   fd.external_code, \n"
			+ "   fd.dt_insert as lastUpdate, \n"
			+ "   fd.user_id_insert as lastUpdateUser, \n"
			+ "   fd.day_from, \n"
			+ "   fd.day_to \n"
			+ "from \n"
			+ "   lpis_parcel_lc_units u \n"
			+ "   inner join lpis_unit_fruitunit_details fd on u.id = fd.unit_id  \n"
			+ "    left join lpis_unit_variety luv on luv.code = fd.variety_code and luv.tenant_id = :tenantId and luv.type_code = u.type_code \n"
			+ "    left join lpis_unit_farming_form luff on luff.code = fd.farming_form_code and luff.tenant_id = :tenantId and luff.type_code = u.type_code \n"
			+ "    left join lpis_unit_irrigation lui on lui.code = fd.irrigation_code and lui.tenant_id = :tenantId and lui.type_code = u.type_code \n"
			+ "    left join lpis_unit_planting_type lupt on lupt.code = fd.planting_type_code and lupt.tenant_id = :tenantId and lupt.type_code = u.type_code \n"
			+ "    left join lpis_unit_quality_system luqs on luqs.code = fd.quality_system_code and luqs.tenant_id = :tenantId and luqs.type_code = u.type_code \n"
			+ "    left join lpis_unit_protection_structure lups on lups.code = fd.protection_structure_code and lups.tenant_id = :tenantId and lups.type_code = u.type_code \n"
			+ "where \n"
			+ "   fd.tenant_id = :tenantId \n"
			+ "   and u.land_cover_id in (<landCoverIdList>)  \n"
			+ "   and u.type_code = 'FRUIT_UNIT'  \n"
			+ "   and (:showOutdatedUnits = 1 \n"
			+ "      or (:referenceDate >= fd.planting_day and :referenceDate < fd.eradicate_day)) \n"
			+ "   and :referenceDate between fd.day_from and fd.day_to \n"
			+ "   and §current_timestamp§ between fd.dt_insert and fd.dt_delete \n"
			+ "order by case when length(fd.unit_code) < 15 then substr(('000000000000000'||fd.unit_code), length('000000000000000'||fd.unit_code) -14, length('000000000000000'||fd.unit_code)) else fd.unit_code end, u.id asc \n"
			+ "")
	@RegisterBeanMapper(FruitUnitNTT.class)
	List<FruitUnitNTT> getFruitUnitsbyLandCoverIds(@BindBean ServiceSupportEnv env, 
			@BindList("landCoverIdList") List<Long> landCoverIdList, 
			@Bind("showOutdatedUnits") Integer showOutdatedUnits);

	@SqlQuery("select fd.pkid as unit_detail_id, \n"
			+ "   u.id as unit_id, \n"
			+ "   u.land_cover_id, \n"
			+ "   u.type_code, \n"
			+ "   fd.unit_code, \n"
			+ "   fd.parent_unit_code, \n"
			+ "   luv.code as variety_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_variety', 'code', luv.type_code||':'||luv.code, :lang)§ as variety_description, \n"
			+ "   luv.fl_visible as variety_fl_visible, \n"
			+ "   fd.area_sqm, \n"
			+ "   fd.planting_day, \n"
			+ "   fd.planting_day_precision, \n"
			+ "   fd.eradicate_day, \n"
			+ "   lupt.code as planting_type_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_planting_type', 'code', lupt.type_code||':'||lupt.code, :lang)§ as planting_type_description, \n"
			+ "   lupt.fl_visible as planting_type_fl_visible, \n"
			+ "   fd.distance_on_the_row_cm, \n"
			+ "   fd.distance_between_rows_cm, \n"
			+ "   fd.plants_number, \n"
			+ "   luff.code as farming_form_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_farming_form', 'code', luff.type_code||':'||luff.code, :lang)§ as farming_form_description, \n"
			+ "   luff.fl_visible as farming_form_fl_visible, \n"
			+ "   lui.code as irrigation_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_irrigation', 'code', lui.type_code||':'||lui.code, :lang)§ as irrigation_description, \n"
			+ "   lui.fl_visible as irrigation_fl_visible, \n"
			+ "   fd.altitude_above_sea_level, \n"
			+ "   luqs.code as quality_system_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_quality_system', 'code', luqs.type_code||':'||luqs.code, :lang)§ as quality_system_description, \n"
			+ "   luqs.fl_visible as quality_system_fl_visible, \n"
			+ "   lups.code as protection_structure_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_protection_structure', 'code', lups.type_code||':'||lups.code, :lang)§ as protection_structure_description, \n"
			+ "   lups.fl_visible as protection_structure_fl_visible, \n"
			+ "   fd.external_code, \n"
			+ "   fd.dt_insert as lastUpdate, \n"
			+ "   fd.user_id_insert as lastUpdateUser, \n"
			+ "   fd.day_from, \n"
			+ "   fd.day_to \n"
			+ "from \n"
			+ "   lpis_parcel_lc_units u \n"
			+ "   inner join lpis_unit_fruitunit_details fd on u.id = fd.unit_id  \n"
			+ "    left join lpis_unit_variety luv on luv.code = fd.variety_code and luv.tenant_id = :tenantId and luv.type_code = u.type_code \n"
			+ "    left join lpis_unit_farming_form luff on luff.code = fd.farming_form_code and luff.tenant_id = :tenantId and luff.type_code = u.type_code \n"
			+ "    left join lpis_unit_irrigation lui on lui.code = fd.irrigation_code and lui.tenant_id = :tenantId and lui.type_code = u.type_code \n"
			+ "    left join lpis_unit_planting_type lupt on lupt.code = fd.planting_type_code and lupt.tenant_id = :tenantId and lupt.type_code = u.type_code \n"
			+ "    left join lpis_unit_quality_system luqs on luqs.code = fd.quality_system_code and luqs.tenant_id = :tenantId and luqs.type_code = u.type_code \n"
			+ "    left join lpis_unit_protection_structure lups on lups.code = fd.protection_structure_code and lups.tenant_id = :tenantId and lups.type_code = u.type_code \n"
			+ "where \n"
			+ "   fd.tenant_id = :tenantId \n"
			+ "   and u.id = :unitId  \n"
			+ "   and u.land_cover_id = :landCoverId \n"
			+ "   and u.type_code = 'FRUIT_UNIT' \n"
			+ "   and :referenceDate between fd.day_from and fd.day_to \n"
			+ "   and §current_timestamp§ between fd.dt_insert and fd.dt_delete \n"
			+ "")
	@RegisterBeanMapper(FruitUnitNTT.class)
	FruitUnitNTT getFruitUnitsbyUnitId(@BindBean ServiceSupportEnv env, @Bind("unitId") Long unitId);
	
	@SqlQuery("select fd.pkid as unit_detail_id, \n"
			+ "   u.id as unit_id, \n"
			+ "   u.land_cover_id, \n"
			+ "   u.type_code, \n"
			+ "   fd.unit_code, \n"
			+ "   fd.parent_unit_code, \n"
			+ "   luv.code as variety_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_variety', 'code', luv.type_code||':'||luv.code, :lang)§ as variety_description, \n"
			+ "   luv.fl_visible as variety_fl_visible, \n"
			+ "   fd.area_sqm, \n"
			+ "   fd.planting_day, \n"
			+ "   fd.planting_day_precision, \n"
			+ "   fd.eradicate_day, \n"
			+ "   lupt.code as planting_type_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_planting_type', 'code', lupt.type_code||':'||lupt.code, :lang)§ as planting_type_description, \n"
			+ "   lupt.fl_visible as planting_type_fl_visible, \n"
			+ "   fd.distance_on_the_row_cm, \n"
			+ "   fd.distance_between_rows_cm, \n"
			+ "   fd.plants_number, \n"
			+ "   luff.code as farming_form_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_farming_form', 'code', luff.type_code||':'||luff.code, :lang)§ as farming_form_description, \n"
			+ "   luff.fl_visible as farming_form_fl_visible, \n"
			+ "   lui.code as irrigation_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_irrigation', 'code', lui.type_code||':'||lui.code, :lang)§ as irrigation_description, \n"
			+ "   lui.fl_visible as irrigation_fl_visible, \n"
			+ "   fd.altitude_above_sea_level, \n"
			+ "   luqs.code as quality_system_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_quality_system', 'code', luqs.type_code||':'||luqs.code, :lang)§ as quality_system_description, \n"
			+ "   luqs.fl_visible as quality_system_fl_visible, \n"
			+ "   lups.code as protection_structure_code, \n"
			+ "   §i18n(:tenantId, 'lpis_unit_protection_structure', 'code', lups.type_code||':'||lups.code, :lang)§ as protection_structure_description, \n"
			+ "   lups.fl_visible as protection_structure_fl_visible, \n"
			+ "   fd.external_code, \n"
			+ "   fd.dt_insert as lastUpdate, \n"
			+ "   fd.user_id_insert as lastUpdateUser, \n"
			+ "   fd.day_from, \n"
			+ "   fd.day_to, \n"
			+ "   ls.id as sector_id, \n"
			+ "   ls.sector as sector_code, \n"
			+ "   lsb.id as block_id, \n"
			+ "   lsb.block as block_code, \n"
			+ "   lp.id as parcel_id, \n"
			+ "   lp.parcel as parcel_code, \n"
			+ "   lpld.land_cover_code \n"
			+ "from \n"
			+ "   lpis_sectors ls \n"
			+ "   inner join lpis_sector_details lsd on ls.id = lsd.sector_id \n"
			+ "   inner join lpis_sector_blocks lsb on ls.id = lsb.sector_id and ls.tenant_id = lsb.tenant_id \n"
			+ "   inner join lpis_sector_block_details lsbd on lsb.id = lsbd.sector_block_id \n"
			+ "   inner join lpis_parcels lp on lp.sector_block_id = lsb.id and lp.tenant_id = lsb.tenant_id \n"
			+ "   inner join lpis_parcel_details lpd on lp.id = lpd.parcel_id \n"
			+ "   inner join lpis_parcel_land_covers lplc on lplc.parcel_id = lp.id \n"
			+ "   inner join lpis_parcel_lc_details lpld on lplc.id = lpld.land_cover_id"
			+ "   inner join lpis_parcel_lc_units u on u.land_cover_id = lplc.id \n"
			+ "   inner join lpis_unit_fruitunit_details fd on u.id = fd.unit_id  \n"
			+ "   left join lpis_unit_variety luv on luv.code = fd.variety_code and luv.tenant_id = :tenantId and luv.type_code = u.type_code \n"
			+ "   left join lpis_unit_farming_form luff on luff.code = fd.farming_form_code and luff.tenant_id = :tenantId and luff.type_code = u.type_code \n"
			+ "   left join lpis_unit_irrigation lui on lui.code = fd.irrigation_code and lui.tenant_id = :tenantId and lui.type_code = u.type_code \n"
			+ "   left join lpis_unit_planting_type lupt on lupt.code = fd.planting_type_code and lupt.tenant_id = :tenantId and lupt.type_code = u.type_code \n"
			+ "   left join lpis_unit_quality_system luqs on luqs.code = fd.quality_system_code and luqs.tenant_id = :tenantId and luqs.type_code = u.type_code \n"
			+ "   left join lpis_unit_protection_structure lups on lups.code = fd.protection_structure_code and lups.tenant_id = :tenantId and lups.type_code = u.type_code \n"
			+ "where \n"
			+ "   fd.tenant_id = :tenantId \n"
			+ "   and ls.tenant_id = :tenantId \n"
			+ "   and fd.unit_code = :unitCode \n"
			+ "   and u.type_code = 'FRUIT_UNIT' \n"
			+ "   and :referenceDate between fd.day_from and fd.day_to \n"
			+ "   and :referenceDate between lpld.day_from and lpld.day_to \n"
			+ "   and :referenceDate between lpd.day_from and lpd.day_to \n"
			+ "   and §current_timestamp§ between lsd.dt_insert and lsd.dt_delete \n"
			+ "   and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete \n"
			+ "   and §current_timestamp§ between lpd.dt_insert and lpd.dt_delete \n"
			+ "   and §current_timestamp§ between lpld.dt_insert and lpld.dt_delete \n"
			+ "   and §current_timestamp§ between fd.dt_insert and fd.dt_delete \n"
			+ "")
	@RegisterBeanMapper(FruitUnitWithParcelDetailsNTT.class)
	FruitUnitWithParcelDetailsNTT getFruitUnitWithParcelDetailsByUnitCode(@BindBean ServiceSupportEnv env, @Bind("unitCode") String unitCode);
	
	@SqlUpdate("UPDATE \n"
			+ "   lpis_unit_fruitunit_details \n"
			+ "SET \n"
			+ "   dt_delete = §current_timestamp§, \n"
			+ "   user_id_delete = :userId \n"
			+ "where \n"
			+ "   tenant_id = :tenantId \n"
			+ "   and pkid = :unitDetailId \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n"
			+ "")
	void outdateFruitUnitByUnitDetailId(@BindBean ServiceSupportEnv env, @Bind("unitDetailId")Long unitDetailId);
	
	@SqlUpdate("UPDATE \n"
			+ "   lpis_unit_fruitunit_details \n"
			+ "SET \n"
			+ "   dt_delete = §current_timestamp§, \n"
			+ "   user_id_delete = :userId \n"
			+ "where \n"
			+ "   tenant_id = :tenantId \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n"
			+ "   and pkid in ( \n"
			+ "         select pkid \n"
			+ "         from lpis_unit_fruitunit_details \n"
			+ "         where tenant_id = :tenantId \n"
			+ "         and unit_code = :unitCode \n"
			+ "         and day_from > :eradicateDay \n"
			+ "         and §current_timestamp§ between dt_insert and dt_delete \n"
			+ ")"
			+ "")
	void outdateAllFutureVersionsByUnitCode(@BindBean ServiceSupportEnv env, @Bind("unitCode")String unitCode, @Bind("eradicateDay")AbsoluteDate eradicateDay);

	
}