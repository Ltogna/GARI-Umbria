package com.abacogroup.lpisgisserver.core.enums;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "The line buffer behaviour: INTERNAL is internal border of landcovers, EXTERNAL is external border of landcovers, FREE_DRAW is inside of landcovers")
public enum LineBufferBehaviour {
	INTERNAL,
	EXTERNAL,
	FREE_DRAW
}
