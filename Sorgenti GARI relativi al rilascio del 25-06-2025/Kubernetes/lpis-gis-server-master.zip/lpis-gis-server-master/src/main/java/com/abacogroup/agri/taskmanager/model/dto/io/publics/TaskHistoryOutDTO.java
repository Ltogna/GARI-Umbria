package com.abacogroup.agri.taskmanager.model.dto.io.publics;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.util.List;

/**
 * XXX TO BE IMPORTED FROM TASKMANAGER CLI WHEN AVAILABLE...
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TaskHistoryOutDTO {

	@Schema(description = "Id")
	private Long id;
	@Schema(description = "Start date")
	private Timestamp startDate;
	@Schema(description = "End date")
	private Timestamp endDate;
	@Schema(description = "User id")
	private String userId;
	@Schema(description = "Indicates if transition is failed")
	private boolean failed;
	@Schema(description = "Indicates the transition's notes")
	private String notes;
	@Schema(description = "Description")
	private String description;
	@Schema(description = "Indicates the transition's source status")
	private String fromNode;
	@Schema(description = "Indicates the transition's source status description")
	private String fromNodeDescription;
	@Schema(description = "Indicates the transition's destination status")
	private String toNode;
	@Schema(description = "Indicates the transition's destination status description ")
	private String toNodeDescription;
	@Schema(description = "List of messages related to the workflow")
	private List<WorkflowMessageOutDTO> messages;
}
