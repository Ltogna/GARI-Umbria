package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.resources.res.StackParcel;
import com.abacogroup.lpisgisserver.resources.res.pub.StackParcelV1;

@Mapper(uses = { ParcelsV1Mapper.class, SectorV1Mapper.class, BlockV1Mapper.class})
public interface StackParcelV1Mapper {

	StackParcelV1Mapper INSTANCE = Mappers.getMapper(StackParcelV1Mapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "landcovers_list", ignore = true)
	@Mapping(target = "anomalies", ignore = true)
	StackParcelV1 toResponseV1(StackParcel entity);
	
}
