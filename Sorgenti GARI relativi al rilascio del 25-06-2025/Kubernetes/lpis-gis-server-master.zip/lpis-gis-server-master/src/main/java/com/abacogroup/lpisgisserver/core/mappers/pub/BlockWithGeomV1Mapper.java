package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.resources.res.Block;
import com.abacogroup.lpisgisserver.resources.res.pub.BlockWithGeomV1;

@Mapper
public interface BlockWithGeomV1Mapper {

	BlockWithGeomV1Mapper INSTANCE = Mappers.getMapper(BlockWithGeomV1Mapper.class);
	
	@InheritInverseConfiguration
	@Mapping(source = "world_geom", target = "worldGeom")
	BlockWithGeomV1 toResponseV1(Block entity);
	
}
