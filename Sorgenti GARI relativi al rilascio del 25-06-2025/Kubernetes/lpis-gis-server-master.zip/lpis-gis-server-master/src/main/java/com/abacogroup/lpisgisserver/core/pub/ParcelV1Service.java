package com.abacogroup.lpisgisserver.core.pub;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lpisgisserver.core.AnomaliesService;
import com.abacogroup.lpisgisserver.core.BaseService;
import com.abacogroup.lpisgisserver.core.CLLService;
import com.abacogroup.lpisgisserver.core.ErrorDescriptionsService;
import com.abacogroup.lpisgisserver.core.ExternalConfigService;
import com.abacogroup.lpisgisserver.core.InternalConfigService;
import com.abacogroup.lpisgisserver.core.ParcelsService;
import com.abacogroup.lpisgisserver.core.StyleService;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.ParcelSearchLevel;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.GenericParcelException;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.InvalidParcelDataException;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.InvalidParcelGeometryException;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.TooMuchParcelsRequestedException;
import com.abacogroup.lpisgisserver.core.mappers.pub.AnomalyV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.LandCoversV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.ParcelSearchFiltersV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.ParcelsV1Mapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.MatrixLandCoverDAO;
import com.abacogroup.lpisgisserver.db.ntt.MatrixLandCoverNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.ParcelSearchFilters;
import com.abacogroup.lpisgisserver.resources.req.ReqContext;
import com.abacogroup.lpisgisserver.resources.req.pub.ParcelSearchFiltersV1;
import com.abacogroup.lpisgisserver.resources.req.pub.PublicParcelSearchPayload;
import com.abacogroup.lpisgisserver.resources.res.LandCoverWithUnits;
import com.abacogroup.lpisgisserver.resources.res.Parcel;
import com.abacogroup.lpisgisserver.resources.res.ParcelsLandCoversList;
import com.abacogroup.lpisgisserver.resources.res.anomalies.AnomaliesList;
import com.abacogroup.lpisgisserver.resources.res.anomalies.Anomaly;
import com.abacogroup.lpisgisserver.resources.res.pub.LandCoverV1;
import com.abacogroup.lpisgisserver.resources.res.pub.ParcelV1;
import com.abacogroup.lpisgisserver.resources.res.pub.anomalies.AnomaliesListV1;
import com.abacogroup.lpisgisserver.resources.res.pub.anomalies.AnomalyV1;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ParcelV1Service extends BaseService {

	private final MatrixLandCoverDAO matrixLandCoverDAO;

	private final AnomaliesService anomaliesService;
	private final ParcelsService parcelsService;
	private final CLLService cllService;

	public ParcelV1Service(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, 
			ParcelsService parcelsService, CLLService cllService, AnomaliesService anomaliesService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.anomaliesService = anomaliesService;
		this.parcelsService = parcelsService;
		this.cllService = cllService;
		
		this.matrixLandCoverDAO = dc.getMatrixLandCoverDAO();
    }

	public InfiniteListResults<ParcelV1> getParcels(ServiceSupportEnv env, ParcelSearchFiltersV1 searchFilters,
			List<Long> parcelsIds) {

		if(env == null) {
			GenericParcelException ex = new GenericParcelException(Status.BAD_REQUEST, Operation.GET_PARCELS, ErrorField.REQUEST,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		// Only for retro compatibility
		env.setIncludeUnits(boolToInt(searchFilters.getIncludeUnits()));
		
		ParcelSearchFilters privSearchFilters = ParcelSearchFiltersV1Mapper.INSTANCE.toPrivFilters(searchFilters);

		InfiniteListResults<ParcelV1> parcelsResponse = parcelsService.getParcels(env, privSearchFilters, parcelsIds, null, null)
				.map(ParcelsV1Mapper.INSTANCE::toResponseV1);

		// Fix srs if not set
		if(env.getSrs() == null && !parcelsResponse.getRecords().isEmpty()) {
			env.setSrs(parcelsResponse.getRecords().get(0).getSrs());
		}
		
		if(1 == env.getIncludeLandCovers()) {
			parcelsResponse.getRecords()
				.stream()
				.filter(p -> p.getDay_from() != null) // exclude the parcels outdated or with no gis
				.forEach(parcel -> {
						env.setParcelId(parcel.getId());
					List<LandCoverV1> landCoverList = parcelsService.findLandCoversByParcelId(env, searchFilters.getIncludeLayerStyle(), 
							searchFilters.getShowOutdatedUnits()).stream()
							.map(LandCoversV1Mapper.INSTANCE::toResponseV1)
							.collect(Collectors.toList());
					parcel.setLandcovers_list(landCoverList);
				});
		}

		if (env.getIncludeAnomalies() == 1) {

			List<Long> parcelIds = parcelsResponse.getRecords().stream().map(ParcelV1::getId).collect(Collectors.toList());

			boolean alwaysShowUncategorizedAnomalyTypes = true;
			Map<String, List<Anomaly>> parcelAnomalyMap = getParcelsAnomaliesMap(env, parcelIds, alwaysShowUncategorizedAnomalyTypes);
			
			parcelsResponse.getRecords()
					.stream()
					.forEach(parcel -> {
						List<AnomalyV1> anomalyV1s = Optional
								.ofNullable(parcelAnomalyMap.get(String.valueOf(parcel.getId())))
								.orElse(new ArrayList<>()).stream()
								.map(AnomalyV1Mapper.INSTANCE::toResponseV1).collect(Collectors.toList());

						parcel.setAnomalies(AnomaliesListV1.builder().anomalies_list(anomalyV1s).build());
					});
		}

		return parcelsResponse;
	}

	public List<ParcelV1> searchParcels(ServiceSupportEnv env, PublicParcelSearchPayload payload, 
			ParcelSearchLevel searchLevel, Double minIntersectionAreaSqm) {

		checkSearchParcels(env, payload);

		env.setSrs(payload.getSrs());
		
		ParcelSearchFilters privSearchFilters = ParcelSearchFilters.builder()
				.sectorDescrFilter(payload.getSectorDescrFilter())
				.blockDescrFilter(payload.getBlockDescrFilter())
				.parcelFilter(payload.getParcelFilter())
				.searchLevel(searchLevel)
				.build();
		
		if(payload.getParcelIdList() != null) {
			env.setPageSize(payload.getParcelIdList().size());
		} else if(payload.getExternalCodeList() != null) {
			env.setPageSize(payload.getExternalCodeList().size());
		}
		
		InfiniteListResults<Parcel> parcelList = null;
		List<ParcelV1> parcelsResponse = new ArrayList<>();
		
		do {
			env.setNextKey(parcelList != null ? parcelList.getNextKey() : null);
			parcelList = parcelsService.getParcels(env, privSearchFilters, payload.getParcelIdList(), payload.getGeom(),
					payload.getExternalCodeList());
			parcelsResponse.addAll(parcelList.getRecords().stream()
					.map(ParcelsV1Mapper.INSTANCE::toResponseV1)
					.filter(p -> {
						if(null == payload.getGeom()) {
							return true;
						} else if(null == minIntersectionAreaSqm || 0 >= minIntersectionAreaSqm) {
							return true;
						} else {
							Geometry intersection = Utils.snappedIntersectionAB(payload.getGeom(), p.getGeom());
							return intersection != null && intersection.getArea() >= minIntersectionAreaSqm;
						}
					})
					.collect(Collectors.toList()));
		} while (parcelList.getNextKey() != null);
		

		// load landcovers
		if(1 == env.getIncludeLandCovers()) {
			includeLandCoverData(env, payload.getMatrixCode(), parcelsResponse);
		}
		
		return parcelsResponse;
	}
	
	private void includeLandCoverData(ServiceSupportEnv env, String matrixCode, List<ParcelV1> parcelsResponse) {
		parcelsResponse
		.stream()
		.filter(p -> p.getDay_from() != null) // exclude the parcels outdated or with no gis
		.forEach(parcel -> {
			env.setParcelId(parcel.getId());
			List<LandCoverV1> landCoverList = parcelsService.findLandCoversByParcelId(env, false, false).stream()
					.map(LandCoversV1Mapper.INSTANCE::toResponseV1)
					.collect(Collectors.toList());

			if (StringUtils.isNotBlank(matrixCode)) {
				landCoverList.stream().forEach(publicLandCover -> {
					Criteria criteria = CriteriaBuilder.string("land_cover_code").eq(publicLandCover.getCode());

					List<MatrixLandCoverNTT> ntt = matrixLandCoverDAO.getLandCoverStylesByCodes(env, matrixCode, criteria);
					if (!ntt.isEmpty()) {
						publicLandCover.setClass_code(ntt.get(0).getClass_code());
					}
				});
			}
			parcel.setLandcovers_list(landCoverList);
		});
	}


	private void checkSearchParcels(ServiceSupportEnv env, PublicParcelSearchPayload payload) {
		if (env == null || payload == null) {
			GenericParcelException ex = new GenericParcelException(Status.BAD_REQUEST, Operation.GET_PARCELS, ErrorField.REQUEST,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		Double maxParcelIdListSize = this.internalConf.getDoubleValue(env.getTenantId(),
				InternalConfigKeys.PUBLIC_MAXIMUM_PARCELS_IDS_LIST_REQ_SIZE_KEY.getKey());

		if ((payload.getParcelIdList() != null && payload.getParcelIdList().size() > maxParcelIdListSize)
				|| (payload.getExternalCodeList() != null && payload.getExternalCodeList().size() > maxParcelIdListSize)) {
			TooMuchParcelsRequestedException ex = new TooMuchParcelsRequestedException(Status.BAD_REQUEST, Operation.GET_PARCELS, ErrorField.PARCEL_IDS,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		checkSearchParcelsGeomAndSrs(env, payload);
	}

	private void checkSearchParcelsGeomAndSrs(ServiceSupportEnv env, PublicParcelSearchPayload payload) {
		if ((payload.getGeom() == null && payload.getSrs() != null) || (payload.getGeom() != null && payload.getSrs() == null)) {
			InvalidParcelDataException ex = new InvalidParcelDataException(Status.BAD_REQUEST, Operation.GET_PARCELS_IN_GEOM, ErrorField.GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if (payload.getGeom() != null && payload.getSrs() != null && payload.getGeom().getArea() > this.internalConf.getDoubleValue(env.getTenantId(),
				InternalConfigKeys.PUBLIC_MAXIMUM_VALID_SEARCH_PARCELS_GEOM_AREA_KEY.getKey())) {
			InvalidParcelGeometryException ex = new InvalidParcelGeometryException(Status.BAD_REQUEST, Operation.GET_PARCELS_IN_GEOM, ErrorField.GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}

	public ParcelV1 getParcelDetails(ServiceSupportEnv env, Long parcelId, Boolean includeLayerStyle, ParcelSearchLevel searchLevel) {
		if(env == null) {
			GenericParcelException ex = new GenericParcelException(Status.BAD_REQUEST, Operation.GET_PARCELS, ErrorField.REQUEST,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		if(searchLevel == null) {
			searchLevel = ParcelSearchLevel.SEARCH_ONLY_VALID;
		}
		
		ParcelsLandCoversList parcelsLandCoversList = parcelsService.getParcelDetails(env, parcelId, includeLayerStyle, searchLevel);
		ParcelV1 parcel = ParcelsV1Mapper.INSTANCE.toResponseV1(parcelsLandCoversList.getParcels_list().get(0));
		
		// Fix srs if not set
		if(env.getSrs() == null) {
			env.setSrs(parcel.getSrs());
		}
		
		// if include anomalies add them to the parcel
		if (env.getIncludeAnomalies() == 1) {

			Boolean showUncategorizedAnomalyTypes = internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_SHOW_UNCATEGORIZED_ANOMALY_TYPES_KEY.getKey());
			Map<String, List<Anomaly>> parcelAnomalyMap = getParcelsAnomaliesMap(env, List.of(parcelId), showUncategorizedAnomalyTypes);

			List<AnomalyV1> anomalyV1s = Optional.ofNullable(parcelAnomalyMap.get(String.valueOf(parcelId)))
					.orElse(new ArrayList<>()).stream().map(AnomalyV1Mapper.INSTANCE::toResponseV1)
					.collect(Collectors.toList());

			parcel.setAnomalies(AnomaliesListV1.builder().anomalies_list(anomalyV1s).build());

		}

		// if have to get landcover data and the parcel has GIS (or details like dayfrom) or is not outdated then I can load landcovers data....
		if(1 == env.getIncludeLandCovers() && parcel.getDay_from() != null) {
			List<LandCoverV1> landCoversList = parcelsLandCoversList.getLand_covers_list().stream()
					.map(LandCoversV1Mapper.INSTANCE::toResponseV1)
					.collect(Collectors.toList());
			parcel.setLandcovers_list(landCoversList);
		}

		return parcel;
	}

	public InfiniteListResults<LandCoverV1> getLandCovers(ServiceSupportEnv env, Boolean includeLayerStyle) {
		if(env == null) {
			GenericParcelException ex = new GenericParcelException(Status.BAD_REQUEST, Operation.GET_PARCELS, ErrorField.REQUEST,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		InfiniteListResults<LandCoverWithUnits> landCoversList = parcelsService.getLandCoversInfiniteList(env, env.getParcelId(), null, includeLayerStyle);
				
		return new InfiniteListResultsImpl<>(landCoversList.getRecords().stream().map(LandCoversV1Mapper.INSTANCE::toResponseV1).collect(Collectors.toList()),
				landCoversList.getNextKey());
	}

	public InfiniteListResults<ParcelV1> getParcelsByPartyId(ReqContext reqContext, ServiceSupportEnv env,
			ParcelSearchFiltersV1 searchFilters) {
		List<Long> parcelsIds = cllService.getPartyParcelIds(reqContext, env, null);
		return getParcels(env, searchFilters, parcelsIds);
	}

	public ParcelV1 persistTemporaryParcel(ServiceSupportEnv env, Long tempParcelId) {
		return ParcelsV1Mapper.INSTANCE.toResponseV1(parcelsService.persistTemporaryParcel(env, tempParcelId));
	}

	
	public Map<String, List<Anomaly>> getParcelsAnomaliesMap(ServiceSupportEnv env, List<Long> parcelIds, Boolean showUncategorizedAnomalyTypes) {
		ReqContext reqContext = new ReqContext(env.getUser(), env.getLang());
		
		AnomaliesList parcelAnomalies = anomaliesService.getParcelAnomaliesInternal(reqContext, parcelIds, showUncategorizedAnomalyTypes);

		return parcelAnomalies.getAnomalies_list()
				.stream()
				.collect(Collectors.groupingBy(Anomaly::getEntityId));
	}
}
