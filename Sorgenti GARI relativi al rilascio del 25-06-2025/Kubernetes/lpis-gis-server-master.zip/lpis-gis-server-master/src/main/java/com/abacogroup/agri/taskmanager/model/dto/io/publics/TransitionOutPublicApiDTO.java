package com.abacogroup.agri.taskmanager.model.dto.io.publics;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * XXX TO BE IMPORTED FROM TASKMANAGER CLI WHEN AVAILABLE...
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TransitionOutPublicApiDTO {

	@Schema(description = "Id")
	private Integer id;
	@Schema(description = "Indicates the transition's source node")
	private String fromNode;
	@Schema(description = "Indicates the transition's destination node")
	private String toNode;
	@Schema(description = "Description")
	private String description;
	@Schema(description = "Tag list")
	private List<String> tagList;
}
