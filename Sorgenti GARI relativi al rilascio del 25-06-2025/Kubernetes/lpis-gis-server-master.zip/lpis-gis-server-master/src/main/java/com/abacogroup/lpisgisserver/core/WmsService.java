package com.abacogroup.lpisgisserver.core;


import java.awt.Color;
import java.awt.Font;
import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.proj4j.CoordinateReferenceSystem;

import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidSessionLandCoverIdException;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.core.transform.ReprojectCoordinateSequenceFilter;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.WMSLayersDAO;
import com.abacogroup.lpisgisserver.db.ntt.WmsDefinitionNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.CataloguePayload;
import com.abacogroup.lpisgisserver.resources.res.DrawStyle;
import com.abacogroup.wms4j.layers.LayerDefinition;
import com.abacogroup.wms4j.layers.LayerDefinition.Range;
import com.abacogroup.wms4j.layers.LayerRequest;
import com.abacogroup.wms4j.renderer.DrawFeature;
import com.abacogroup.wms4j.renderer.GeometryDrawerStyle;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;

import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class WmsService extends BaseService {

	protected static final String LAYER_NAME_PARCELS = "PARCELS";
	protected static final String LAYER_NAME_LANDCOVERS = "LANDCOVERS";
	protected static final String LAYER_NAME_SDE = "SDE";
	protected static final String LAYER_NAME_SECTORS = "SECTORS";
	protected static final String LAYER_NAME_BLOCKS = "BLOCKS";
	protected static final String LAYER_NAME_AREAS = "AREAS";

	protected static final String PARAM_REFERENCE_DATE = "reference_date";
	protected static final String PARAM_TENANT = "tenant";
	protected static final String PARAM_SESSION_ID = "session_id";
	protected static final String PARAM_SRS = "srs";
	protected static final String PARAM_SECTOR_CODE = "sector_code";
	protected static final String PARAM_MATRIX_CODE = "matrix_code";
	protected static final String PARAM_PARCEL_ID = "parcel_id";
	protected static final String PARAM_LABELS = "labels";
	protected static final String PARAM_OUTLINE = "outline";
	protected static final String PARAM_FILL = "fill";

	protected static final String PARAM_SDE_CODE = "sde_code";

	protected static final String PARAM_PARENT_AREA_ID = "parent_area_id";
	protected static final String PARAM_AREA_LEVEL = "area_level";

	protected static final String SRS_WORLD_GEOM = "EPSG:3857";

	protected static final String DEFAULT_FONT_NAME = "Arial";
	protected static final int DEFAULT_FONT_STYLE = Font.PLAIN;

	protected static final String TRANSPARENT = "#FFFFFF00";
	
	private static final boolean USE_SERVICE_USER = true;

	private final WMSLayersDAO wmsLayersDAO;
	
	private final InternalConfigService internalConfigService;
	private final CataloguesService cataloguesService;
	
	private LoadingCache<String, Map<String, WmsDefinitionNTT>> matrixCache; // key: tenant|referenceDate|matrixCode 

	public WmsService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, CataloguesService cataloguesService,
			PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.wmsLayersDAO = dc.getWMSLayersDAO();
		
		this.internalConfigService = conf;
		this.cataloguesService = cataloguesService;
		
		matrixCache = Caffeine.newBuilder()
				.maximumSize(500)
				.expireAfterWrite(Duration.ofMinutes(120))
				.build(this::loadMatrixData);
		
	}

	public List<LayerDefinition> getInternalWMSLayers() {

		List<LayerDefinition> layers = new ArrayList<>();

		layers.add(getParcelLayer());
		layers.add(getLandCoverLayer());
		layers.add(getSDELayer());
		layers.add(getSectorLayer());
		layers.add(getBlockLayer());
		layers.add(getAreaLayer());

		return layers;

	}

	/* *** *** *** *** *** *** Get Parcels geometries *** *** *** *** *** *** */
	private LayerDefinition getParcelLayer() {

		return new LayerDefinition(
				LAYER_NAME_PARCELS,
				new Range(null, null),
				new GeometryDrawerStyle(new Color(0.7f, 0.7f, 0.7f), new Color(0.7f, 0.7f, 0.7f, 0.4f), 2),
				this::provideParcelsData);

	}

	private void provideParcelsData(LayerRequest req, Consumer<DrawFeature> consumer) {
		ServiceSupportEnv env = readUrlQueryParams(req.getUriInfo().getQueryParameters());

		DrawStyle style = (DrawStyle) internalConfigService.getValue(env.getTenantId(), InternalConfigKeys.DEFAULT_WMS_PARCELS_STYLE.getKey());
		DrawStyle notPolygonStyle = (DrawStyle) internalConfigService.getValue(env.getTenantId(), InternalConfigKeys.DEFAULT_WMS_PARCELS_NOTPOLYGON_STYLE.getKey());
		
		if(notInRange(style, req.getMetersForPixel())) {
			return;
		}

		if (env.getSectorCode() != null && !env.getSectorCode().isBlank())
			wmsLayersDAO.getNonLockParcelGeomsForSectorWithInteraction(env, req.getAreaOfInterest(), ntt -> consumer.accept(toDrawFeature(env, style, notPolygonStyle, ntt, null)));
		else
			wmsLayersDAO.getNonLockParcelGeomsWithInteraction(env, req.getAreaOfInterest(), ntt -> consumer.accept(toDrawFeature(env, style, notPolygonStyle, ntt, null)));
	}

	/* *** *** *** *** *** *** Get LandCovers geometries and styles *** *** *** *** *** *** */
	private LayerDefinition getLandCoverLayer() {
		return new LayerDefinition(
				LAYER_NAME_LANDCOVERS,
				new Range(null, null),
				new GeometryDrawerStyle(new Color(0.7f, 0.7f, 0.7f), new Color(0.7f, 0.7f, 0.7f, 0.4f), 2),
				this::provideLandCoversData);
	}

	private void provideLandCoversData(LayerRequest req, Consumer<DrawFeature> consumer) {

		ServiceSupportEnv env = readUrlQueryParams(req.getUriInfo().getQueryParameters());
		if(env.getTenantId() == null || env.getReferenceDate() == null || env.getLandCoverStyleMatrixCode() == null)
			return;

		DrawStyle style = (DrawStyle) internalConfigService.getValue(env.getTenantId(), InternalConfigKeys.DEFAULT_WMS_LANDCOVERS_STYLE.getKey());
		
		if(notInRange(style, req.getMetersForPixel())) {
			return;
		}
		
		Map<String, WmsDefinitionNTT> matrixLandCoverStyle = retrieveMatrixLandCoverStyleForProvideLandCoversData(env);
		
		String lcOriginCatalogueCode = internalConfigService.getStringValue(env.getTenantId(), InternalConfigKeys.LANDCOVER_ORIGIN_CATALOGUE_CODE.getKey());
		
		if (lcOriginCatalogueCode != null && !lcOriginCatalogueCode.isBlank()) {
			List<WmsDefinitionNTT> parcelList = retrieveParcelsForProvideLandCoverData(req, env);
			if (parcelList.isEmpty()) {
				return;
			}
			
			Geometry mergedGeom = Utils.getUnion(parcelList.stream().map(WmsDefinitionNTT::getGeom).collect(Collectors.toList()));
			
			CataloguePayload payload = CataloguePayload.builder()
					.geom(mergedGeom)
					.srs(env.getSrs())
					.build();
			
			cataloguesService
					.getIntersectedGeomsFromCatalogueList(env, lcOriginCatalogueCode, payload, USE_SERVICE_USER)
					.stream()
					.forEach(cataDto -> consumer.accept(toDrawFeature(env, style, 
							WmsDefinitionNTT.builder()
							.code((String)cataDto.getFields().get("style_ref_code"))
							.label(cataDto.getLabel())
							.srs(cataDto.getSrs())
							.geom(cataDto.getGeom())
							.hide_geom(false).build(), 
							matrixLandCoverStyle)))
					;
			
		} else {
			if (env.getSectorCode() != null && !env.getSectorCode().isBlank())
				wmsLayersDAO.getNonLockLandCoverGeomsForSectorWithInteraction(env, req.getAreaOfInterest(), ntt -> consumer.accept(toDrawFeature(env, style, ntt, matrixLandCoverStyle)));
			else
				wmsLayersDAO.getNonLockLandCoverGeomsWithInteraction(env, req.getAreaOfInterest(), ntt -> consumer.accept(toDrawFeature(env, style, ntt, matrixLandCoverStyle)));
		}
		

	}

	private Map<String, WmsDefinitionNTT> retrieveMatrixLandCoverStyleForProvideLandCoversData(ServiceSupportEnv env) {
		Map<String, WmsDefinitionNTT> matrixLandCoverStyle; 
		if(env.getTenantId().contains("|") || env.getLandCoverStyleMatrixCode().contains("|")) {	
			matrixLandCoverStyle = wmsLayersDAO.getLandCoverLayerStylesFromMatrixCodeAndLandCoverCode(env, null)
					.stream()
					.collect(Collectors.toMap(WmsDefinitionNTT::getCode, Function.identity()));
		}
		else {
			matrixLandCoverStyle = matrixCache.get(env.getTenantId()+"|"+env.getReferenceDate()+"|"+env.getLandCoverStyleMatrixCode());
		}
		return matrixLandCoverStyle;
	}

	private List<WmsDefinitionNTT> retrieveParcelsForProvideLandCoverData(LayerRequest req, ServiceSupportEnv env) {
		List<WmsDefinitionNTT> parcelList = new ArrayList<>();
		if (env.getSectorCode() != null && !env.getSectorCode().isBlank())
			wmsLayersDAO.getNonLockParcelGeomsForSectorWithInteraction(env, req.getAreaOfInterest(), parcelList::add);
		else
			wmsLayersDAO.getNonLockParcelGeomsWithInteraction(env, req.getAreaOfInterest(), parcelList::add);
		return parcelList;
	}

	/* *** *** *** *** *** *** Get SDE geometries *** *** *** *** *** *** */
	private LayerDefinition getSDELayer() {

		return new LayerDefinition(
				LAYER_NAME_SDE,
				new Range(null, null),
				new GeometryDrawerStyle(new Color(0.7f, 0.7f, 0.7f), new Color(0.7f, 0.7f, 0.7f, 0.4f), 2),
				this::provideSDEData);

	}

	private void provideSDEData(LayerRequest req, Consumer<DrawFeature> consumer) {
		ServiceSupportEnv env = readUrlQueryParams(req.getUriInfo().getQueryParameters());

		DrawStyle style = (DrawStyle) internalConfigService.getValue(env.getTenantId(), InternalConfigKeys.DEFAULT_WMS_SDE_PARCELS_STYLE.getKey());
		
		if(notInRange(style, req.getMetersForPixel())) {
			return;
		}
		if (env.getSectorCode() != null && !env.getSectorCode().isBlank())
			wmsLayersDAO.getExternalParcelGeomsForSectorWithInteraction(env, req.getAreaOfInterest(), ntt -> consumer.accept(toDrawFeature(env, style, ntt, null)));
		else
			wmsLayersDAO.getExternalParcelGeomsWithInteraction(env, req.getAreaOfInterest(), ntt -> consumer.accept(toDrawFeature(env, style, ntt, null)));

	}

	/* *** *** *** *** *** *** Get Sector geometries *** *** *** *** *** *** */
	private LayerDefinition getSectorLayer() {

		return new LayerDefinition(
				LAYER_NAME_SECTORS,
				new Range(null, null),
				new GeometryDrawerStyle(new Color(0.7f, 0.7f, 0.7f), new Color(0.7f, 0.7f, 0.7f, 0.4f), 2),
				this::provideSectorsData);

	}

	private void provideSectorsData(LayerRequest req, Consumer<DrawFeature> consumer) {
		ServiceSupportEnv env = readUrlQueryParams(req.getUriInfo().getQueryParameters());
		
		Geometry touchingGeom = getTouchingGeom(env, req.getAreaOfInterest());

		DrawStyle style = (DrawStyle) internalConfigService.getValue(env.getTenantId(), InternalConfigKeys.DEFAULT_WMS_SECTORS_STYLE.getKey());
		
		if(notInRange(style, req.getMetersForPixel())) {
			return;
		}
		
		wmsLayersDAO.getSectorsGeomsWithInteraction(env, touchingGeom, ntt -> consumer.accept(toDrawFeature(env, style, ntt, null)));

	}

	/* *** *** *** *** *** *** Get Block geometries *** *** *** *** *** *** */
	private LayerDefinition getBlockLayer() {

		return new LayerDefinition(
				LAYER_NAME_BLOCKS,
				new Range(null, null),
				new GeometryDrawerStyle(new Color(0.7f, 0.7f, 0.7f), new Color(0.7f, 0.7f, 0.7f, 0.4f), 2),
				this::provideBlocksData);

	}

	private void provideBlocksData(LayerRequest req, Consumer<DrawFeature> consumer) {
		ServiceSupportEnv env = readUrlQueryParams(req.getUriInfo().getQueryParameters());
		
		Geometry touchingGeom = getTouchingGeom(env, req.getAreaOfInterest());

		DrawStyle style = (DrawStyle) internalConfigService.getValue(env.getTenantId(), InternalConfigKeys.DEFAULT_WMS_BLOCKS_STYLE.getKey());
		
		if(notInRange(style, req.getMetersForPixel())) {
			return;
		}
		
		if (env.getSectorCode() != null && !env.getSectorCode().isBlank())
			wmsLayersDAO.getBlockGeomsForSectorWithInteraction(env, touchingGeom, ntt -> consumer.accept(toDrawFeature(env, style, ntt, null)));
		else
			wmsLayersDAO.getBlockGeomsWithInteraction(env, touchingGeom, ntt -> consumer.accept(toDrawFeature(env, style, ntt, null)));

	}

	/* *** *** *** *** *** *** Get Areas geometries *** *** *** *** *** *** */
	private LayerDefinition getAreaLayer() {

		return new LayerDefinition(
				LAYER_NAME_AREAS,
				new Range(null, null),
				new GeometryDrawerStyle(new Color(0.7f, 0.7f, 0.7f), new Color(0.7f, 0.7f, 0.7f, 0.4f), 2),
				this::provideAreasData);

	}

	private void provideAreasData(LayerRequest req, Consumer<DrawFeature> consumer) {
		ServiceSupportEnv env = readUrlQueryParams(req.getUriInfo().getQueryParameters());

		Geometry touchingGeom = getTouchingGeom(env, req.getAreaOfInterest());

		DrawStyle style;
		
		Map<String, DrawStyle> areasStyle =
				internalConfigService.getValuesList(env.getTenantId(), DrawStyle.class, InternalConfigKeys.DEFAULT_WMS_AREAS_STYLES.getKey())
				.stream()
			      .collect(Collectors.toMap(DrawStyle::getReferenceName, Function.identity()));
		
		if(notInRange(areasStyle.get(env.getAreaLevel().toUpperCase()), req.getMetersForPixel())) {
			return;
		}
		
		if(env.getAreaLevel() != null && areasStyle.get(env.getAreaLevel().toUpperCase()) != null) {
			style = DrawStyle.builder()
					.fillRgba(areasStyle.get(env.getAreaLevel().toUpperCase()).getFillRgba())
					.lineRgba(areasStyle.get(env.getAreaLevel().toUpperCase()).getLineRgba())
					.lineThick(areasStyle.get(env.getAreaLevel().toUpperCase()).getLineThick())
					.textColor(areasStyle.get(env.getAreaLevel().toUpperCase()).getTextColor())
					.textSize(areasStyle.get(env.getAreaLevel().toUpperCase()).getTextSize())
					.build();
		} else {
			style = getDefaultStyle();
		}
		
		String labelSelectSql = "lah.acronym";
		if(env.getAreaLevel() != null && Arrays.asList("NAZ", "REG").contains(env.getAreaLevel().toUpperCase())) {
			labelSelectSql = "lah.description";
		}

		wmsLayersDAO.getAreaGeomsWithInteraction(env, labelSelectSql, touchingGeom, ntt -> consumer.accept(toDrawFeature(env, style, ntt, null)));

	} 

	private Geometry getTouchingGeom(ServiceSupportEnv env, Geometry geom) {
		CoordinateReferenceSystem fromCRS = getCRS(env.getSrs());
		CoordinateReferenceSystem toWorldCRS = getCRS(SRS_WORLD_GEOM);
		if (fromCRS.getName().equals(toWorldCRS.getName())) {
			return geom;
		}

		Geometry destGeom = geom.copy();
		destGeom.apply(new ReprojectCoordinateSequenceFilter(fromCRS, toWorldCRS));
		destGeom.setSRID(0);

		return destGeom;
	}

	private DrawFeature toDrawFeature(ServiceSupportEnv env, DrawStyle defaultStyle, WmsDefinitionNTT ntt, Map<String, WmsDefinitionNTT> styleMap) {
		return toDrawFeature(env, defaultStyle, null, ntt, styleMap);
	}

	private DrawFeature toDrawFeature(ServiceSupportEnv env, DrawStyle defaultStyle, DrawStyle notPolygonStyle, WmsDefinitionNTT ntt, Map<String, WmsDefinitionNTT> styleMap) {
		if(ntt == null) 
			return null;
		
		if(!(ntt.getGeom() instanceof Polygon) && notPolygonStyle != null) {
			defaultStyle = notPolygonStyle;
		}

		if(defaultStyle == null) 
			defaultStyle = getDefaultStyle();

		defaultStyle.checkAndFix();



		if(ntt.getFillRGBA() != null) {
			defaultStyle.setFillRgba(ntt.getFillRGBA());
		}

		DrawFeature result = new DrawFeature(ntt.getGeom());

		setWmsDefinitionNTTStyleAndTextProperties(env, defaultStyle, ntt, styleMap);

		if(Boolean.TRUE.equals(env.getLabels())) {
			result.setText(ntt.getLabel());
		}

		Font textFont = new Font(DEFAULT_FONT_NAME, DEFAULT_FONT_STYLE, ntt.getTextSize());
		result.setSpecificStyle(new GeometryDrawerStyle(
				createColor(ntt.getLineRGBA()), 
				createColor(ntt.getFillRGBA()), 
				ntt.getLineThick(), 
				textFont, 
				createColor(ntt.getTextColor())
			));

		return result;
	}

	private void setWmsDefinitionNTTStyleAndTextProperties(ServiceSupportEnv env, DrawStyle defaultStyle, WmsDefinitionNTT ntt,
			Map<String, WmsDefinitionNTT> styleMap) {

		ntt.setFillRGBA(TRANSPARENT);
		ntt.setLineRGBA(TRANSPARENT);
		ntt.setLineThick(defaultStyle.getLineThick());
		
		// find textColor from matrix styleMap if present
		ntt.setTextColor(
				styleMap != null && 
				ntt.getCode() != null && 
				styleMap.get(ntt.getCode()) != null && 
				styleMap.get(ntt.getCode()).getTextColor() != null 
				? (styleMap.get(ntt.getCode()).getTextColor() + "          ").substring(0, 8) 
				: defaultStyle.getTextColor()
			);
		
		ntt.setTextSize(defaultStyle.getTextSize());

		if (Boolean.FALSE.equals(ntt.getHide_geom())) {
			boolean fillEnabled = Boolean.TRUE.equals(env.getFill());
			boolean outlineEnabled = Boolean.TRUE.equals(env.getOutline());
			WmsDefinitionNTT style = styleMap != null && ntt.getCode() != null ? styleMap.get(ntt.getCode()) : null;

			ntt.setFillRGBA(buildFillRGBA(fillEnabled, style, defaultStyle));
			ntt.setLineRGBA(buildLineRGBA(outlineEnabled, style, defaultStyle));

			if (style != null) {
				ntt.setLineThick(style.getLineThick());
			}
		}
	}

	private String buildFillRGBA(boolean fillEnabled, WmsDefinitionNTT style, DrawStyle defaultStyle) {
		String fillColor = style == null ? defaultStyle.getFillRgba() : style.getFillRGBA();
		return fillEnabled ? fillColor : TRANSPARENT;
	}

	private String buildLineRGBA(boolean outlineEnabled, WmsDefinitionNTT style, DrawStyle defaultStyle) {
		String lineColor = style == null ? defaultStyle.getLineRgba() : style.getLineRGBA();
		return outlineEnabled ? lineColor : TRANSPARENT;
	}

	private Color createColor(String rgbaCode) {
		Integer r = Integer.valueOf(rgbaCode.substring(1, 3), 16);
		Integer g = Integer.valueOf(rgbaCode.substring(3, 5), 16);
		Integer b = Integer.valueOf(rgbaCode.substring(5, 7), 16);
		Integer a = rgbaCode.length() != 9 ? Integer.valueOf("FF", 16) : Integer.valueOf(rgbaCode.substring(7, 9), 16);

		return new Color(r, g, b, a);
	}

	private ServiceSupportEnv readUrlQueryParams(MultivaluedMap<String, String> urlQParams) {

		// tenant must be defined!!
		if(urlQParams == null || StringUtils.isBlank(urlQParams.getFirst(PARAM_TENANT))) {
			InvalidSessionLandCoverIdException ex = new InvalidSessionLandCoverIdException(Status.BAD_REQUEST,
					Operation.WMS_SERVER, ErrorField.LANDCOVER_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		// Query Param data reading 
		AbsoluteDate refDate = urlQParams.getFirst(PARAM_REFERENCE_DATE) != null ? AbsoluteDate.of(urlQParams.getFirst(PARAM_REFERENCE_DATE))
					: AbsoluteDate.of(LocalDate.now());
		Long parcelId = urlQParams.getFirst(PARAM_PARCEL_ID) != null ? Long.parseLong(urlQParams.getFirst(PARAM_PARCEL_ID)) : -1L;
		String tenantId = urlQParams.getFirst(PARAM_TENANT);
		String matrixCode = urlQParams.getFirst(PARAM_MATRIX_CODE);
		String sessionId = urlQParams.getFirst(PARAM_SESSION_ID);
		String srs = urlQParams.getFirst(PARAM_SRS);
		String sectorCode = urlQParams.getFirst(PARAM_SECTOR_CODE);
		Boolean labels = buildBooleanUrlQueryParam(urlQParams, PARAM_LABELS);
		Boolean outline = buildBooleanUrlQueryParam(urlQParams, PARAM_OUTLINE);
		Boolean fill = buildBooleanUrlQueryParam(urlQParams, PARAM_FILL);
		Long parentAreaId = urlQParams.getFirst(PARAM_PARENT_AREA_ID) != null ? Long.parseLong(urlQParams.getFirst(PARAM_PARENT_AREA_ID)) : null;
		String areaLevel = urlQParams.getFirst(PARAM_AREA_LEVEL);
		String sdeCode = urlQParams.getFirst(PARAM_SDE_CODE);		

		// Default data loading
		if (matrixCode == null || matrixCode.isEmpty())
			matrixCode = internalConfigService.getStringValue(tenantId, InternalConfigKeys.DEFAULT_LANDCOVERS_STYLE_MATRIX_CODE_KEY.getKey());
		
		DrawStyle style = (DrawStyle) internalConfigService.getValue(tenantId, InternalConfigKeys.DEFAULT_WMS_LANDCOVERS_STYLE.getKey());
		if(style == null)
			style = getDefaultStyle();
		
		return ServiceSupportEnv
				.builder()
				.user(null)
				.lang(null)
				.tenantId(tenantId)
				.sessionId(sessionId)
				.parcelId(parcelId)
				.srs(srs)
				.referenceDate(refDate)
				.landCoverStyleMatrixCode(matrixCode)
				.defaultLCFillRGBA(style.getFillRgba())
				.defaultLCLineRGBA(style.getLineRgba())
				.defaultLCLineThick(style.getLineThick())
				.sectorCode(sectorCode)
				.sdeCode(sdeCode)
				.labels(labels)
				.outline(outline)
				.fill(fill)
				.parentAreaId(parentAreaId)
				.areaLevel(areaLevel)
				.build();

	}

	private Boolean buildBooleanUrlQueryParam(MultivaluedMap<String, String> urlQParams, String paramKey) {
		return urlQParams.getFirst(paramKey) == null ? Boolean.TRUE : Boolean.TRUE.toString().equalsIgnoreCase(urlQParams.getFirst(paramKey));
	}
	
	private DrawStyle getDefaultStyle() {
		return DrawStyle.builder()
				.referenceName("DEFAULT_STYLE")
				.fillRgba("#B3B3B355")
				.lineRgba("#B3B3B3")
				.lineThick(1)
				.textColor("#B3B3B3")
				.textSize(15)
				.fromMetersForPixel(null)
				.toMetersForPixel(null)
				.build();
	}

	private Map<String, WmsDefinitionNTT> loadMatrixData(String key) {
		if(key == null || key.split("\\|").length < 3)
			return new HashMap<>(0);

		ServiceSupportEnv env = 
				ServiceSupportEnv.builder()
				.tenantId(key.split("\\|")[0])
				.referenceDate(AbsoluteDate.of(key.split("\\|")[1]))
				.landCoverStyleMatrixCode(key.split("\\|")[2])
				.build();

		return wmsLayersDAO.getLandCoverLayerStylesFromMatrixCodeAndLandCoverCode(env, null)
				.stream()
				.collect(Collectors.toMap(WmsDefinitionNTT::getCode, Function.identity()));

	}
	
	private boolean notInRange(DrawStyle style, double metersForPixel) {
		return (style.getFromMetersForPixel() != null && metersForPixel < style.getFromMetersForPixel())
				|| (style.getToMetersForPixel() != null && metersForPixel > style.getToMetersForPixel());
	}
	
}
