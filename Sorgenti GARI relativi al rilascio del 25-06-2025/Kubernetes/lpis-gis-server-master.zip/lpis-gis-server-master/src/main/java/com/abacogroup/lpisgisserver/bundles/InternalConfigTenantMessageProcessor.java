package com.abacogroup.lpisgisserver.bundles;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.models.InternalConfig;
import com.abacogroup.lpisgisserver.db.dao.ConfigDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.ntt.ConfigNTT;

public class InternalConfigTenantMessageProcessor implements TenantMessageProcessor {

	private static final String TEMPLATE_TENANT_ID = "*";

	private ConfigDAO configDAO;
	private SupportDAO supportDAO;
	private Map<String, InternalConfig> internalConfigurations;

	private static final Logger log = LoggerFactory.getLogger(InternalConfigTenantMessageProcessor.class);

	public InternalConfigTenantMessageProcessor(DAOContainer dc, Map<String, InternalConfig> internalConfigurations) {
		this.configDAO = dc.getConfigDAO();
		this.supportDAO = dc.getSupportDAO();
		this.internalConfigurations = internalConfigurations;
	}

	@Override
	public void onMessage(TenantMessage message) {
		String tenantId = message.getTenantId();

		if (tenantId.equals(TEMPLATE_TENANT_ID)) {
			return;
		}

		if (configDAO.getAllTenants().contains(tenantId)) {
			return;
		}

		List<ConfigNTT> generalConfig = configDAO.getConfigByTenant(TEMPLATE_TENANT_ID);

		if (generalConfig != null) {
			generalConfig.forEach(config -> {
				try {
					configDAO.insert(
							ConfigNTT.builder()
									.tenantId(tenantId)
									.key(config.getKey())
									.value(config.getValue())
									.fl_client(config.getFl_client())
									.name(config.getName())
									.build());
				} catch (Exception e) {
					log.error("Error during insert internal config key {} with value {} : {}", config.getKey(), config.getValue(), e);
				}
			});
		}

		try {
			ConfigNTT defaultLandCoverCodeConfig = configDAO.getConfigByTenantAndKey(tenantId, InternalConfigKeys.DEFAULT_LAND_COVER_CODE_KEY.getKey());

			String defaultLandCoverCode = defaultLandCoverCodeConfig == null
					? String.valueOf(internalConfigurations.get(InternalConfigKeys.DEFAULT_LAND_COVER_CODE_KEY.getKey()).getValue())
					: defaultLandCoverCodeConfig.getValue();

			if (StringUtils.isBlank(supportDAO.getLandCoversCodeByTenantAndCode(tenantId, defaultLandCoverCode))) {
				supportDAO.insertLandCoversCode(tenantId, defaultLandCoverCode);
			}
		} catch (Exception e) {
			log.error("Error during insert default land cover code : ", e);
		}
	}

}
