package com.abacogroup.lpisgisserver.bundles.models.units;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UnitVineDoigtMessage {
	private String code;
	private String category_code;
	private String name_code;
	private Boolean fl_visible;
	private Map<String, String> code_description;
	private Map<String, String> category_code_description;
	private Map<String, String> name_code_description;
}
