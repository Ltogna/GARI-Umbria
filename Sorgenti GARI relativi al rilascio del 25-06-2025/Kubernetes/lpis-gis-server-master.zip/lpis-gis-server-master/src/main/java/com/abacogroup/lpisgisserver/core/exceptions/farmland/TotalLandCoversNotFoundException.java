package com.abacogroup.lpisgisserver.core.exceptions.farmland;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class TotalLandCoversNotFoundException extends AbstractException {

	private static final long serialVersionUID = -8596620583922400098L;

	private static final ErrorCode ERROR_CODE = ErrorCode.TOTAL_LAND_COVERS_NOT_FOUND;

	public TotalLandCoversNotFoundException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new TotalLandCoversNotFoundExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Total land covers not found")
	public static class TotalLandCoversNotFoundExceptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = -66642413868522993L;

		public TotalLandCoversNotFoundExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}

	}
}
