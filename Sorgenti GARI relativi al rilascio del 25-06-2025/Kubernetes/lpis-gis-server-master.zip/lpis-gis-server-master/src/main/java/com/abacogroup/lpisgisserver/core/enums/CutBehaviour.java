package com.abacogroup.lpisgisserver.core.enums;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "The cut behaviour: CUT_EXISTING if the new polygon overrides already present polygons")
public enum CutBehaviour
{
	CUT_EXISTING,
	CUT_ON_EXISTING
}
