package com.abacogroup.lpisgisserver.core.exceptions.sector;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class GenericSectorException extends AbstractException {

	private static final long serialVersionUID = -1673070574702954624L;

	private static final ErrorCode ERROR_CODE = ErrorCode.GENERIC_SECTOR_ERROR;

	public GenericSectorException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new GenericSectorExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Generic sector error")
	public static class GenericSectorExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -3938439373516571339L;

		public GenericSectorExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
