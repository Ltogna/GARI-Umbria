package com.abacogroup.lpisgisserver.core.enums;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "The level of error in session check")
public enum SessionErrorLevel {
	DANGER,
	WARN,
	INFO
}
