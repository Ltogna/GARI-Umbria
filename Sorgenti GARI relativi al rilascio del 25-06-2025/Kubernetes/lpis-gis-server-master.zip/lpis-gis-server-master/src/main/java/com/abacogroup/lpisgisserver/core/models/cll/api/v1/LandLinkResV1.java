package com.abacogroup.lpisgisserver.core.models.cll.api.v1;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Optional;

import org.jdbi.v3.core.mapper.Nested;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set", toBuilder = true)
@NoArgsConstructor
public class LandLinkResV1 {

	private Long id;

	@Nested("group_detail")
	private GroupBaseResV1 group;

	private Long partyId; 

	@Nested("title")
	private TitleTypeV1 titleType;

	@Default
	private BigDecimal titleTypePerc = BigDecimal.valueOf(100);

	@Nested("parcel")
	private ParcelResV1 parcel;

	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;

	@Default
	private Long anomalyCount = 0L;

	public Long getTitleTypeAreaSqm() {
		return titleTypePerc.multiply(BigDecimal.valueOf(Optional.ofNullable(parcel).map(ParcelResV1::getAreaSqm).orElse(0L)))
				.divide(BigDecimal.valueOf(100), 0, RoundingMode.HALF_UP).longValue();
	}
}
