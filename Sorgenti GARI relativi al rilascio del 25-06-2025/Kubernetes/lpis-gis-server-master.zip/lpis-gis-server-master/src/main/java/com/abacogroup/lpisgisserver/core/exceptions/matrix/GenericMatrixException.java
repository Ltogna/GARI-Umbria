package com.abacogroup.lpisgisserver.core.exceptions.matrix;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class GenericMatrixException extends AbstractException {

	private static final long serialVersionUID = 5537587949273368660L;

	private static final ErrorCode ERROR_CODE = ErrorCode.GENERIC_MATRIX_ERROR;

	public GenericMatrixException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new GenericMatrixExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Generic matrix error")
	public static class GenericMatrixExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 5888054464582301647L;

		public GenericMatrixExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
