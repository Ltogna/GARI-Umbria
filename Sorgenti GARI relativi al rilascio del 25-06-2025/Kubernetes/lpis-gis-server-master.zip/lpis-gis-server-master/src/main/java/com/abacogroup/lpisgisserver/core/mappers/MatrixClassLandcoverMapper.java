package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.MatrixClassLandcoversNTT;
import com.abacogroup.lpisgisserver.resources.res.pub.MatrixClassLandcoverV1;

@Mapper
public interface MatrixClassLandcoverMapper {

	MatrixClassLandcoverMapper ININSTANCE = Mappers.getMapper(MatrixClassLandcoverMapper.class);
	
	@Mapping(target = "landcover.land_cover_code", source = "landcover.code")
	@Mapping(target = "landcover.unit_types", ignore = true)
	MatrixClassLandcoverV1 entityToDto(MatrixClassLandcoversNTT entity);
	
	@Mapping(target = "landcover.code", source = "landcover.land_cover_code")
	@Mapping(target = "dt_insert", ignore = true)
	@Mapping(target = "dt_delete", ignore = true)
	@Mapping(target = "user_id_insert", ignore = true)
	@Mapping(target = "user_id_delete", ignore = true)
	MatrixClassLandcoversNTT dtoToEntity(MatrixClassLandcoverV1 dto);
	
}
