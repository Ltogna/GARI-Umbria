package com.abacogroup.lpisgisserver.bundles.models;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class MatrixInsertMessage {
	@JsonProperty("matrix_code")
	private String matrixCode;

	@JsonProperty("class_code")
	private String classCode;

	@JsonProperty("code")
	private String code;

	@JsonProperty("day_from")
	private AbsoluteDate dayFrom;

	@JsonProperty("day_to")
	private AbsoluteDate dayTo;

	@JsonProperty("metadata")
	private List<NewMatrixMetadataMessage> metadata;
}
