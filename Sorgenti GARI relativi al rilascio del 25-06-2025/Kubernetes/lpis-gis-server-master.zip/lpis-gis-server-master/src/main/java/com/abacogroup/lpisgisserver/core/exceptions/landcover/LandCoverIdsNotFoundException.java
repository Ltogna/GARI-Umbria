package com.abacogroup.lpisgisserver.core.exceptions.landcover;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class LandCoverIdsNotFoundException extends AbstractException {

	private static final long serialVersionUID = 3758346455532494708L;

	private static final ErrorCode ERROR_CODE = ErrorCode.LAND_COVER_IDS_NOT_FOUND;

	public LandCoverIdsNotFoundException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new LandCoverIdsNotFoundExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Some land cover ids not found")
	public static class LandCoverIdsNotFoundExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -1279599756517520987L;

		public LandCoverIdsNotFoundExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}

	}
}
