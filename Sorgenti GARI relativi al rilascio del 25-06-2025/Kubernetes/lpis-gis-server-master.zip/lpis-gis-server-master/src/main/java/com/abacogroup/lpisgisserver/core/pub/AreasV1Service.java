package com.abacogroup.lpisgisserver.core.pub;

import java.util.List;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lpisgisserver.core.AreasService;
import com.abacogroup.lpisgisserver.core.BaseService;
import com.abacogroup.lpisgisserver.core.ErrorDescriptionsService;
import com.abacogroup.lpisgisserver.core.ExternalConfigService;
import com.abacogroup.lpisgisserver.core.InternalConfigService;
import com.abacogroup.lpisgisserver.core.StyleService;
import com.abacogroup.lpisgisserver.core.mappers.pub.AreaV1Mapper;
import com.abacogroup.lpisgisserver.core.mappers.pub.SectorV1Mapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.pub.AreaV1;
import com.abacogroup.lpisgisserver.resources.res.pub.SectorV1;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AreasV1Service extends BaseService {

	private final AreasService areasService;

	public AreasV1Service(DAOContainer dc, AreasService areasService, InternalConfigService conf, ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService,
			StyleService styleService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.areasService = areasService;
	}

	/**
	* Search areas by tenant. This is a convenience method for performing a search by tenant and filtering the results with a list of area filters
	* 
	* @param env - service support environment to search
	* @param areaFilters - list of filters to use when searching for areas
	* @param level - search level. Must be one of " sub " " user " or " user_group "
	* @param nextKey - key to start the search at. If null the first page will be used
	* 
	* @return infinite list of areas
	*/
	public InfiniteListResults<AreaV1> searchAreas(ServiceSupportEnv env, List<String> areaFilters, String level, String areaCode) {

		return areasService.searchAreas(env, areaFilters, level, areaCode)
				.map(AreaV1Mapper.INSTANCE::toResponseV1);
	}

	/**
	* Retrieves an area by its code. If the area doesn't exist a Not Found exception is thrown
	* 
	* @param env - service support environment for obtaining tenant id
	* @param areaId - id of the area to retrieve. It's mandatory to be non - null
	* 
	* @return area corresponding to the id or null if not found ( status NOT_FOUND ) in which case an InvalidAreaIdException is
	*/
	public AreaV1 getByCode(ServiceSupportEnv env, String areaCode) {
		return AreaV1Mapper.INSTANCE.toResponseV1(areasService.getByCode(env, areaCode));
	}

	public InfiniteListResults<SectorV1> getSectorsByAreaCode(ServiceSupportEnv env, String areaCode) {
		return areasService.getSectorsByAreaCode(env, areaCode)
				.map(SectorV1Mapper.INSTANCE::toResponseV1);
	}

}
