package com.abacogroup.lpisgisserver.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.locationtech.jts.geom.Geometry;
import org.locationtech.proj4j.CoordinateReferenceSystem;

import com.abacogroup.cropplan.sdk.model.layers.GISInfo;
import com.abacogroup.cropplan.sdk.model.layers.GISInfo.GISInfoCard;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lpisgisserver.core.enums.CatalogueCalcParamKey;
import com.abacogroup.lpisgisserver.core.enums.CatalogueType;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.exceptions.InvalidPayloadException;
import com.abacogroup.lpisgisserver.core.exceptions.catalogue.CatalogueCodeNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.location.InvalidCoordinatesException;
import com.abacogroup.lpisgisserver.core.exceptions.location.OutOfRangeException;
import com.abacogroup.lpisgisserver.core.mappers.CatalogueGeomMapper;
import com.abacogroup.lpisgisserver.core.mappers.CatalogueMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.CataloguesDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.ExternalSourceDataDAO;
import com.abacogroup.lpisgisserver.db.dao.FruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.I18nDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.OliveUnitsDAO;
import com.abacogroup.lpisgisserver.db.dao.ParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.SectorDAO;
import com.abacogroup.lpisgisserver.db.dao.VineUnitsDAO;
import com.abacogroup.lpisgisserver.db.ntt.CatalogueGeomNTT;
import com.abacogroup.lpisgisserver.db.ntt.CatalogueNTT;
import com.abacogroup.lpisgisserver.db.ntt.ExternalSourceParcelNTT;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.db.ntt.SectorNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.fruit.FruitUnitNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.olive.OliveUnitNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineUnitNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.mappings.CatalogueGeomMappings;
import com.abacogroup.lpisgisserver.resources.req.CataloguePayload;
import com.abacogroup.lpisgisserver.resources.res.Catalogue;
import com.abacogroup.lpisgisserver.resources.res.CatalogueGeom;
import com.abacogroup.lpisgisserver.resources.res.CatalogueList;
import com.google.common.collect.Iterators;
import com.google.common.collect.UnmodifiableIterator;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CataloguesService extends BaseService {

	private final SectorDAO sectorDAO;
	private final CataloguesDAO cataloguesDAO;
	private final ExternalSourceDataDAO externalSourceDataDAO;
	private final I18nDAO i18nDAO;
	
	private final ParcelsDAO parcelsDAO;
	private final LandCoversDAO landCoversDAO;
	private final VineUnitsDAO vineUnitsDAO;
	private final OliveUnitsDAO oliveUnitsDAO;
	private final FruitUnitsDAO fruitUnitsDAO;

	private CropPlanClientService cropPlanClientService;
	private VectorDataLayersClientService vectorDataLayersClientService;

	private final CoordinateReferenceSystem worldCRS = BaseService.getCRS(SRS_WORLD_GEOM);
	private static final String SDE_PREFIX = "SDE:";

	private static final Boolean SHOW_ALL_CATALOGUES = null;

	public CataloguesService(DAOContainer dc, CropPlanClientService cropPlanClientService,
			VectorDataLayersClientService vectorDataLayersClientService, InternalConfigService conf,
			ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService,
			StyleService styleService, PluginEnvironment pluginEnvironment) {

		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);
		this.sectorDAO = dc.getSectorDAO();
		this.cataloguesDAO = dc.getCataloguesDAO();
		this.externalSourceDataDAO = dc.getExternalSourceDataDAO();
		this.i18nDAO = dc.getI18nDAO();
		this.parcelsDAO = dc.getParcelsDAO();
		this.landCoversDAO = dc.getLandCoversDAO();
		this.vineUnitsDAO = dc.getVineUnitsDAO();
		this.oliveUnitsDAO = dc.getOliveUnitsDAO();
		this.fruitUnitsDAO = dc.getFruitUnitsDAO();

		this.cropPlanClientService = cropPlanClientService;
		this.vectorDataLayersClientService = vectorDataLayersClientService;

	}

	public CatalogueList getCatalogueList(ServiceSupportEnv env, Boolean flVisible) {
		List<CatalogueNTT> catalogues = getCatalogueNTTList(env, flVisible);

		return CatalogueList.builder()
				.catalogueList(
						catalogues.stream().map(CatalogueMapper.INSTANCE::entityToDto).collect(Collectors.toList()))
				.build();
	}

	public List<CatalogueNTT> getCatalogueNTTList(ServiceSupportEnv env, Boolean flVisible) {
		List<CatalogueNTT> catalogueList = new ArrayList<>();

		catalogueList.addAll(getSDECatalogues(env));

		Criteria criteria = getCatalogueCriteria(null, flVisible);
		catalogueList.addAll(cataloguesDAO.getCatalogues(env, criteria));

		return catalogueList.stream()
				.filter(c -> (flVisible == null || c.getFlVisible().equals(boolToInt(flVisible))))
				.collect(Collectors.toList());
	}

	private Criteria getCatalogueCriteria(Long catalogueId, Boolean flVisible) {
		List<Criteria> criterias = new ArrayList<>();

		if (catalogueId != null) {
			criterias.add(CriteriaBuilder.number("id").eq(catalogueId));
		}

		if (flVisible != null) {
			criterias.add(CriteriaBuilder.number("fl_visible").eq(boolToInt(flVisible)));
		}

		return criterias.isEmpty() ? CriteriaBuilder.number("1").eq(1)
				: CriteriaBuilder.and(criterias.toArray(new Criteria[0]));
	}

	public Catalogue getCatalogueByCodeAndSrs(ServiceSupportEnv env, String catalogueCode, Boolean flVisible) {
		return CatalogueMapper.INSTANCE.entityToDto(getCatalogueNTTByCodeAndSrs(env, catalogueCode, flVisible));
	}

	private CatalogueNTT getCatalogueNTTByCodeAndSrs(ServiceSupportEnv env, String catalogueCode, Boolean flVisible) {
		return getCatalogueNTTList(env, flVisible).stream().filter(c -> c.getCode().equals(catalogueCode)).findFirst()
				.orElse(null);
	}

	public InfiniteListResults<CatalogueGeom> getGeomsFromCatalogueInfinite(ServiceSupportEnv env, String catalogueCode,
			AbsoluteDate referenceDate, @NotNull @Valid CataloguePayload payload, Boolean flVisible) {
		return getGeomsFromCatalogueInfinite(env, false, catalogueCode, referenceDate, payload, flVisible);
	}

	public InfiniteListResults<CatalogueGeom> getGeomsFromCatalogueInfinite(ServiceSupportEnv env,
			Boolean useServiceUser, String catalogueCode, AbsoluteDate referenceDate,
			@NotNull @Valid CataloguePayload payload, Boolean flVisible) {

		// Check reqcontext and user validity
		env.setSrs(payload.getSrs());
		env.setReferenceDate(referenceDate);
		CatalogueNTT catalogue = getCatalogueNTTByCodeAndSrs(env, catalogueCode, flVisible);
		if (catalogue == null) {
			CatalogueCodeNotFoundException ex = new CatalogueCodeNotFoundException(Status.BAD_REQUEST,
					env.getOperation(), ErrorField.CATALOGUE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if (CatalogueType.INTERNAL.equals(catalogue.getType())) {
			return getInternalCatalogueGeoms(env, catalogue, payload);
		} else if (CatalogueType.SDE.equals(catalogue.getType())) {
			return getSDECatalogueGeoms(env, catalogue, payload);
		} else if (CatalogueType.CROP_PLAN.equals(catalogue.getType())) {
			return getCropPlanCatalogueGeoms(env, catalogue, payload);
		} else if (CatalogueType.VECTOR_DATA_LAYERS.equals(catalogue.getType())) {
			return getVectorDataLayersCatalogueGeoms(env, useServiceUser, catalogue, payload);
		} else {
			throw new UnsupportedOperationException(
					"Method not implemented for catalogue type: " + catalogue.getType());
		}

	}

	public List<CatalogueGeom> getGeomsFromCatalogueList(ServiceSupportEnv env, String catalogueCode,
			AbsoluteDate referenceDate, @NotNull @Valid CataloguePayload payload) {

		List<CatalogueGeom> catalogueGeoms = new ArrayList<>();
		do {
			InfiniteListResults<CatalogueGeom> resp = getGeomsFromCatalogueInfinite(env, catalogueCode, referenceDate,
					payload, SHOW_ALL_CATALOGUES);
			catalogueGeoms.addAll(resp.getRecords());
			env.setNextKey(resp.getNextKey());
		} while (env.getNextKey() != null);

		return catalogueGeoms;
	}

	public InfiniteListResults<CatalogueGeom> getIntersectedGeomsFromCatalogueInfinite(ServiceSupportEnv env,
			String catalogueCode, @NotNull @Valid CataloguePayload payload, Boolean flVisible, Boolean useServiceUser) {

		CatalogueNTT catalogue = getCatalogueNTTByCodeAndSrs(env, catalogueCode, flVisible);
		if (catalogue == null) {
			CatalogueCodeNotFoundException ex = new CatalogueCodeNotFoundException(Status.BAD_REQUEST,
					env.getOperation(), ErrorField.CATALOGUE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if (CatalogueType.VECTOR_DATA_LAYERS.equals(catalogue.getType())) {
			return getIntersectedVectorDataLayersCatalogueGeoms(env, useServiceUser, catalogue, payload);
		} else {
			throw new UnsupportedOperationException(
					"Method not implemented for catalogue type: " + catalogue.getType());
		}

	}

	public List<CatalogueGeom> getIntersectedGeomsFromCatalogueList(ServiceSupportEnv env, String catalogueCode,
			@NotNull @Valid CataloguePayload payload) {
		return getIntersectedGeomsFromCatalogueList(env, catalogueCode, payload, false);
	}

	public List<CatalogueGeom> getIntersectedGeomsFromCatalogueList(ServiceSupportEnv env, String catalogueCode,
			@NotNull @Valid CataloguePayload payload, Boolean useServiceUser) {

		List<CatalogueGeom> catalogueGeoms = new ArrayList<>();
		do {
			InfiniteListResults<CatalogueGeom> resp = getIntersectedGeomsFromCatalogueInfinite(env,
					catalogueCode, payload, SHOW_ALL_CATALOGUES, useServiceUser);
			catalogueGeoms.addAll(resp.getRecords());
			env.setNextKey(resp.getNextKey());
		} while (env.getNextKey() != null);

		return catalogueGeoms.stream().filter(cg -> cg.getAreaSqm() >= 1.0) // XXX To be improved
				.collect(Collectors.toList());
	}

	public List<GISInfo> getGeomInfoFromCatalogue(ServiceSupportEnv env, String catalogueCode,
			AbsoluteDate referenceDate, @NotNull @Valid CataloguePayload payload) {

		// Check reqcontext and user validity
		env.setReferenceDate(referenceDate);
		env.setSrs(payload.getSrs());

		String tenantId = env.getTenantId();

		if (!Geometry.TYPENAME_POINT.equals(payload.getGeom().getGeometryType())) {
			InvalidCoordinatesException ex = new InvalidCoordinatesException(Status.BAD_REQUEST, env.getOperation(),
					ErrorField.GEOM, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()),
					env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		CatalogueNTT catalogue = getCatalogueNTTByCodeAndSrs(env, catalogueCode, SHOW_ALL_CATALOGUES);
		if (catalogue == null) {
			CatalogueCodeNotFoundException ex = new CatalogueCodeNotFoundException(Status.BAD_REQUEST,
					env.getOperation(), ErrorField.CATALOGUE,
					this.errorDescriptionsService.getTenantErrorDescriptions(tenantId), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		if (CatalogueType.INTERNAL.equals(catalogue.getType())) {
			return getInternalCatalogueGisInfo(env, catalogue, payload);
		} else if (CatalogueType.CROP_PLAN.equals(catalogue.getType())) {
			Map<String, Object> paramMap = remapParamMap(env, catalogue, payload);
			return cropPlanClientService.getGisInfo(env, paramMap);
		}

		return new ArrayList<>();
	}

	private List<GISInfo> getInternalCatalogueGisInfo(ServiceSupportEnv env, CatalogueNTT catalogue,
			@NotNull @Valid CataloguePayload payload) {

		List<CatalogueGeomNTT> catalogueGeomNTTs = new ArrayList<>();
		if (InternalCatalogues.LANDCOVERS.getCode().equals(catalogue.getCode())) {
			// XXX non si mostra il resto delle info dei landcover perchè mancano le
			// traduzioni dei vari campi
			catalogueGeomNTTs = cataloguesDAO.getLandCoversGeomsList(env, env.getReferenceDate(), payload.getSrs(),
					payload.getGeom());
		}

		if (catalogueGeomNTTs.isEmpty()) {
			return new ArrayList<>();
		}

		GISInfo gisInfo = new GISInfo();
		gisInfo.setLayerCode(catalogue.getCode());
		gisInfo.setTitle(catalogue.getDescription());
		gisInfo.setCards(new ArrayList<>());

		catalogueGeomNTTs.stream().forEach(cataGeom -> {
			GISInfoCard card = new GISInfoCard();
			card.setMbr(cataGeom.getGeom());
			card.setAreaSqm((int) Math.round(cataGeom.getGeom().getArea()));
			card.setTitle(cataGeom.getLabel());

			gisInfo.getCards().add(card);
		});

		return List.of(gisInfo);
	}

	private Map<String, Object> remapParamMap(ServiceSupportEnv env, CatalogueNTT catalogue, CataloguePayload payload) {

		Map<String, Object> paramMap = cataloguesDAO.getCatalogueParamsByCode(env.getTenantId(), catalogue.getCode())
				.stream().collect(Collectors.toMap(p -> p.getParamKey(), p -> p.getParamValue()));

		if (payload.getGeom() == null) {
			InvalidPayloadException ex = new InvalidPayloadException(Status.BAD_REQUEST, env.getOperation(),
					ErrorField.PAYLOAD, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()),
					env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		processParamMap(paramMap, env, payload);

		paramMap.put("x", payload.getGeom().getCoordinates()[0].x);
		paramMap.put("y", payload.getGeom().getCoordinates()[0].y);

		return paramMap;
	}

	private InfiniteListResults<CatalogueGeom> getInternalCatalogueGeoms(ServiceSupportEnv env, CatalogueNTT catalogue,
			CataloguePayload payload) {

		// XXX aggiugnere anche il layer interno PARCELLE!!
		if (InternalCatalogues.BLOCKS.getCode().equals(catalogue.getCode())) {
			return cataloguesDAO
					.infinite(() -> cataloguesDAO.getBlockGeoms(env.getTenantId(), payload.getSrs(), payload.getGeom()),
							env.getNextKey(), env.getPageSize())
					.map(CatalogueGeomMapper.INSTANCE::entityToDto);
		} else if (InternalCatalogues.LANDCOVERS.getCode().equals(catalogue.getCode())) {
			return cataloguesDAO
					.infinite(() -> cataloguesDAO.getLandCoversGeoms(env.getTenantId(), env.getReferenceDate(),
							payload.getSrs(), payload.getGeom()), env.getNextKey(), env.getPageSize())
					.map(CatalogueGeomMapper.INSTANCE::entityToDto);
		} if (InternalCatalogues.MOBILE_PARCELS.getCode().equals(catalogue.getCode())) {
			return getMobileParcelGeoms(env, InternalCatalogues.MOBILE_PARCELS.getCode(), payload);
		} else {
			CatalogueCodeNotFoundException ex = new CatalogueCodeNotFoundException(Status.BAD_REQUEST,
					env.getOperation(), ErrorField.CATALOGUE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
	}

	private InfiniteListResults<CatalogueGeom> getSDECatalogueGeoms(ServiceSupportEnv env, CatalogueNTT catalogue,
			CataloguePayload payload) {

		String[] codes = catalogue.getCode().split(":");
		if (codes.length < 2) {
			CatalogueCodeNotFoundException ex = new CatalogueCodeNotFoundException(Status.BAD_REQUEST,
					env.getOperation(), ErrorField.CATALOGUE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return cataloguesDAO.infinite(
				() -> cataloguesDAO.getSdeGeoms(env.getTenantId(), payload.getSrs(), payload.getGeom(), codes[1]),
				env.getNextKey(), env.getPageSize())
				.map(CatalogueGeomMapper.INSTANCE::entityToDto);
	}

	private InfiniteListResults<CatalogueGeom> getCropPlanCatalogueGeoms(ServiceSupportEnv env, CatalogueNTT catalogue,
			CataloguePayload payload) {

		Map<String, Object> paramMap = remapParamMap(env, catalogue, payload);

		// Al moment non interseca con la geom del payload. ritorna tutte le geom del
		// business id
		List<CatalogueGeom> catalogueGeoms = cropPlanClientService.getSnapGeomteries(env, paramMap)
				.getGeometries().stream()
				.map(g -> CatalogueGeom.builder().id(g.getId()).geom(g.getGeom()).label(g.getDescription()).build())
				.collect(Collectors.toList());

		return new InfiniteListResultsImpl<>(catalogueGeoms, null);
	}

	private InfiniteListResults<CatalogueGeom> getVectorDataLayersCatalogueGeoms(ServiceSupportEnv env,
			Boolean useServiceUser, CatalogueNTT catalogue, CataloguePayload payload) {

		Map<String, Object> paramMap = remapParamMap(env, catalogue, payload);

		return vectorDataLayersClientService
				.getLayerGeometries(env, paramMap, payload.getGeom(), payload.getSrs(), useServiceUser)
				.map(CatalogueGeomMapper.INSTANCE::fromVectorDataLayerToCatalogueGeom);
	}

	private InfiniteListResults<CatalogueGeom> getIntersectedVectorDataLayersCatalogueGeoms(
			ServiceSupportEnv env, Boolean useServiceUser, CatalogueNTT catalogue, CataloguePayload payload) {

		Map<String, Object> paramMap = remapParamMap(env, catalogue, payload);

		return vectorDataLayersClientService.getIntersectedLayerGeometries(env, paramMap, payload.getGeom(),
				payload.getSrs(), useServiceUser)
				.map(CatalogueGeomMapper.INSTANCE::fromVectorDataLayerToCatalogueGeom);
	}
	
	private InfiniteListResults<CatalogueGeom> getMobileParcelGeoms(ServiceSupportEnv env, String catalogueCode,
			CataloguePayload payload){
		if (payload.getGeom() == null) {
			InvalidPayloadException ex = new InvalidPayloadException(Status.BAD_REQUEST, env.getOperation(),
					ErrorField.PAYLOAD, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()),
					env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		CoordinateReferenceSystem payloadCRS = BaseService.getCRS(payload.getSrs());
		Geometry geom = reproject(payload.getGeom(), payloadCRS, worldCRS);
		
		InfiniteListResults<ParcelNTT> parcelMap = parcelsDAO
				.infinite(() -> parcelsDAO.getParcels(env, null, geom, null, null, null, null, null, 0), env.getNextKey(), env.getPageSize());
		
		List<Long> parcelIds = parcelMap.getRecords().stream().map(ParcelNTT::getParcel_id).collect(Collectors.toList());
		
		//Key: parcelId
		Map<Long, List<LandCoverNTT>> landCoversMap = getLandCoversMap(env, parcelIds);
		List<Long> landCoverIds = landCoversMap.values().stream().flatMap(List::stream).map(LandCoverNTT::getLand_cover_id).collect(Collectors.toList());
		
		Map<Long, List<VineUnitNTT>> vineUnitMap = getVineUnitMap(env, landCoverIds);
		Map<Long, List<OliveUnitNTT>> oliveUnitMap = getOliveUnitMap(env, landCoverIds);
		Map<Long, List<FruitUnitNTT>> fruitUnitMap = getFruitUnitMap(env, landCoverIds);

		List<CatalogueGeom> catalogueGeoms = CatalogueGeomMappings.mapCatalogueGeomWithInfoList(env, catalogueCode, parcelMap, 
				landCoversMap, vineUnitMap, oliveUnitMap, fruitUnitMap, SRS_WORLD_GEOM, i18nDAO);

		return new InfiniteListResultsImpl<>(catalogueGeoms, parcelMap.getNextKey());
		
	}

	private List<CatalogueNTT> getSDECatalogues(ServiceSupportEnv env) {
		List<CatalogueNTT> catalogues = new ArrayList<>();

		List<ExternalSourceParcelNTT> sdeList = externalSourceDataDAO.getAllCodeBySrs(env);
		sdeList.stream()
				.forEach(sde -> catalogues.add(CatalogueNTT.builder().code(SDE_PREFIX + sde.getExternalSourceCode())
						.description(sde.getExternalSourceDescription()).type(CatalogueType.SDE).displayOrder(0)
						.flVisible(1)
						.build()));

		return catalogues;
	}

	private SectorNTT findSector(ServiceSupportEnv env, Geometry geom, String srs) {
		CoordinateReferenceSystem payloadCRS = BaseService.getCRS(srs);

		Geometry worldGeomToSearch = reproject(geom, payloadCRS, worldCRS);

		if (!worldGeomToSearch.isValid()) {
			InvalidCoordinatesException ex = new InvalidCoordinatesException(Status.BAD_REQUEST, env.getOperation(),
					ErrorField.GEOM, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()),
					env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		List<SectorNTT> sectorNTTs = sectorDAO.getSectorsWithInteractionsWithoutSrs(env.getTenantId(),
				worldGeomToSearch);

		if (sectorNTTs.isEmpty()) {
			OutOfRangeException ex = new OutOfRangeException(Status.BAD_REQUEST, env.getOperation(), ErrorField.GEOM,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return sectorNTTs.get(0);
	}

	private void processParamMap(Map<String, Object> paramMap, ServiceSupportEnv env, CataloguePayload payload) {
		for (Map.Entry<String, Object> entry : paramMap.entrySet()) {
			Object value = entry.getValue();
			if (value instanceof String) {
				String stringValue = (String) value;
				if (stringValue.matches("\\{.*?\\}")) {
					String extKey = stringValue.substring(1, stringValue.length() - 1);
					Object newValue = getNewValue(extKey, env, payload);
					entry.setValue(newValue);
				}
			}
		}
	}

	private Object getNewValue(String key, ServiceSupportEnv env, CataloguePayload payload) {

		// payload param must be at least empty...
		if (payload.getParams() == null) {
			payload.setParams(new HashMap<>());
		}

		CatalogueCalcParamKey paramKey = CatalogueCalcParamKey.fromString(key);
		switch (paramKey) {
		case REFERENCEDATE:
			return env.getReferenceDate();
		case SECTORCODE:
			return getSectorCode(env, payload);
		case LANG:
			return env.getLang() != null ? env.getLang() : "en";
		case OTHER:
		default:
			return payload.getParams().getOrDefault(key, null);
		}
	}

	private String getSectorCode(ServiceSupportEnv env, CataloguePayload payload) {
		SectorNTT sectorNTT = findSector(env, payload.getGeom(), payload.getSrs());
		return sectorNTT.getSector();
	}

	private enum InternalCatalogues {
		BLOCKS("INTERNAL:BLOCKS"), 
		LANDCOVERS("INTERNAL:LANDCOVERS"),
		MOBILE_PARCELS("INTERNAL:MOBILE_PARCELS");

		private final String code;

		private InternalCatalogues(String code) {
			this.code = code;
		}

		public String getCode() {
			return code;
		}
	}
	
	private Map<Long, List<LandCoverNTT>> getLandCoversMap(ServiceSupportEnv env, List<Long> parcelIds) {
		//Key: parcelId
		Map<Long, List<LandCoverNTT>> landCoverMap = new HashMap<>();
		UnmodifiableIterator<List<Long>> partitions = Iterators.partition(parcelIds.iterator(), 666);
		partitions.forEachRemaining(partition -> landCoverMap.putAll(landCoversDAO.findByParcelIds(env, partition).stream()
				.collect(Collectors.groupingBy(LandCoverNTT::getParcel_id))));

		return landCoverMap;
	}
	
	private Map<Long, List<VineUnitNTT>> getVineUnitMap(ServiceSupportEnv env, List<Long> landCoverIds) {
		//Key: landCoverId
		Map<Long, List<VineUnitNTT>> vineUnitMap = new HashMap<>();
		
		UnmodifiableIterator<List<Long>> partitions = Iterators.partition(landCoverIds.iterator(), 666);
		partitions.forEachRemaining(partition -> vineUnitMap.putAll(vineUnitsDAO.getVineUnitsbyLandCoverIds(env, partition, 0).stream()
				.collect(Collectors.groupingBy(VineUnitNTT::getLandCoverId))));
		
		return vineUnitMap;
	}
	
	private Map<Long, List<OliveUnitNTT>> getOliveUnitMap(ServiceSupportEnv env, List<Long> landCoverIds) {
		//Key: landCoverId
		Map<Long, List<OliveUnitNTT>> oliveUnitMap = new HashMap<>();
		
		UnmodifiableIterator<List<Long>> partitions = Iterators.partition(landCoverIds.iterator(), 666);
		partitions.forEachRemaining(partition -> oliveUnitMap.putAll(oliveUnitsDAO.getOliveUnitsbyLandCoverIds(env, partition, 0).stream()
				.collect(Collectors.groupingBy(OliveUnitNTT::getLandCoverId))));
		
		return oliveUnitMap;
	}
	
	private Map<Long, List<FruitUnitNTT>> getFruitUnitMap(ServiceSupportEnv env, List<Long> landCoverIds) {
		//Key: landCoverId
		Map<Long, List<FruitUnitNTT>> fruitUnitMap = new HashMap<>();
		
		UnmodifiableIterator<List<Long>> partitions = Iterators.partition(landCoverIds.iterator(), 666);
		partitions.forEachRemaining(partition -> fruitUnitMap.putAll(fruitUnitsDAO.getFruitUnitsbyLandCoverIds(env, partition, 0).stream()
				.collect(Collectors.groupingBy(FruitUnitNTT::getLandCoverId))));
		
		return fruitUnitMap;
	}
}
