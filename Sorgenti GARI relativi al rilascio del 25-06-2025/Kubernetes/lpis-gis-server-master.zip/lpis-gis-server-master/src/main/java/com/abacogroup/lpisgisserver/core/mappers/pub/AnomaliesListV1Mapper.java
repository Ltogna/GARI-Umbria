package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.resources.res.anomalies.AnomaliesList;
import com.abacogroup.lpisgisserver.resources.res.pub.anomalies.AnomaliesListV1;

@Mapper(uses = {AnomalyV1Mapper.class} )
public interface AnomaliesListV1Mapper {

	AnomaliesListV1Mapper INSTANCE = Mappers.getMapper(AnomaliesListV1Mapper.class);
	
	AnomaliesListV1 toResponseV1(AnomaliesList entity);

}
