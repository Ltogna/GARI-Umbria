package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.support.MatrixSearchParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassDetailsNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface MatrixClassDetailsDAO extends Transactional<MatrixClassDetailsDAO>, EnhancedSqlObject {

	@SqlUpdate("INSERT INTO lpis_matrix_class_details (matrix_id, class_code, default_land_cover_code, default_land_use_code, "
			+ "day_from, day_to, fill_rgba, line_rgba, line_thick, "
			+ "user_id_insert, user_id_delete, "
			+ "dt_insert, dt_delete) "
			+ "VALUES(:matrix_id, :class_code, :default_land_cover_code, :default_land_use_code, "
			+ "       :day_from, :day_to, :fill_rgba, :line_rgba, :line_thick, "
			+ "       :user_id_insert, NULL, "
			+ "       §current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insert(@BindBean MatrixClassDetailsNTT rs, @Bind("user_id_insert") String userId);

	@SqlQuery("select matrix_id, \n"
			+ "   class_code, \n"
			+ "   §i18n(:tenantId, 'lpis_matrix_classes', 'code', class_code, :lang)§ as class_description, \n"
			+ "   default_land_cover_code, \n"
			+ "   default_land_use_code, \n"
			+ "   day_from, \n"
			+ "   day_to, \n"
			+ "   fill_rgba, \n"
			+ "   line_rgba, \n"
			+ "   line_thick, \n"
			+ "   user_id_insert, \n"
			+ "   user_id_delete, \n"
			+ "   dt_insert, \n" 
			+ "   dt_delete \n"
			+ "from lpis_matrix_class_details \n"
			+ "where matrix_id = :matrix_id \n"
			+ "   and class_code = :class_code \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(MatrixClassDetailsNTT.class)
	List<MatrixClassDetailsNTT> findByMatrixIdAndClassCode(
			@BindBean ServiceSupportEnv env,
			@Bind("matrix_id") Long matrixId, 
			@Bind("class_code") String classCode);

	@SqlUpdate("update lpis_matrix_class_details \n"
			+ "   set user_id_delete = :user_id_delete, \n"
			+ "       dt_delete = §current_timestamp§ \n"
			+ " where matrix_id = :matrix_id \n"
			+ "   and class_code = :class_code \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteByMatrixIdAndClassCode(@Bind("matrix_id") Long matrixId, @Bind("class_code") String classCode,
			@Bind("user_id_delete") String userDelete);

	/* ************************************************ */

	@SqlQuery("\n"
			+ "select matrix_id, \n"
			+ "   class_code, \n"
			+ "   default_land_cover_code, \n"
			+ "   default_land_use_code, \n"
			+ "   day_from, \n"
			+ "   day_to, \n"
			+ "   fill_rgba, \n"
			+ "   line_rgba, \n"
			+ "   line_thick, \n"
			+ "   §i18n(:tenantId, 'lpis_matrix_classes', 'code', class_code, :lang)§ as class_description \n"
			+ "from lpis_matrix_class_details \n"
			+ "where matrix_id = :matrixId \n"
			+ "   and (class_code = :classCode or :classCode is null) \n"
			+ "   and :referenceDate between day_from and day_to \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n"
			+ "   and (upper(class_code) like upper('%'||:classFilter||'%') escape '$' or :classFilter is null) \n")
	@RegisterBeanMapper(MatrixClassDetailsNTT.class)
	List<MatrixClassDetailsNTT> searchValidByMatrixIdAndClassCode(
			@BindBean ServiceSupportEnv env,
			@BindBean MatrixSearchParams search);
	

	@SqlQuery("\n"
			+ "select matrix_id, \n"
			+ "   class_code, \n"
			+ "   default_land_cover_code, \n"
			+ "   default_land_use_code, \n"
			+ "   day_from, \n"
			+ "   day_to, \n"
			+ "   fill_rgba, \n"
			+ "   line_rgba, \n"
			+ "   line_thick, \n"
			+ "   §i18n(:tenantId, 'lpis_matrix_classes', 'code', class_code, :lang)§ as class_description \n"
			+ "from lpis_matrix_class_details lmcl \n"
			+ "where matrix_id = :matrixId \n"
			+ "   and :referenceDate between day_from and day_to \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n"
			+ "   and (coalesce(<classCodes>, null) is null or class_code in (<classCodes>)) \n")
	@RegisterBeanMapper(MatrixClassDetailsNTT.class)
	List<MatrixClassDetailsNTT> getClassDetailsByMatrixIdAndClassCodes(
			@BindBean ServiceSupportEnv env,
			@Bind("matrixId") Long matrixId,
			@BindList(value = "classCodes", onEmpty = BindList.EmptyHandling.NULL_STRING) List<String> classCodes);
}
