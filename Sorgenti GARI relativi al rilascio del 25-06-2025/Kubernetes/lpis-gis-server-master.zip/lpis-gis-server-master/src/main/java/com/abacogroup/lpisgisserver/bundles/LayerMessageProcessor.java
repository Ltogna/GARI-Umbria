package com.abacogroup.lpisgisserver.bundles;

import java.io.File;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.bundles.models.I18nMessage;
import com.abacogroup.lpisgisserver.bundles.models.LayerMessage;
import com.abacogroup.lpisgisserver.bundles.models.WmsLayerMessage;
import com.abacogroup.lpisgisserver.bundles.models.WmsLayerModule;
import com.abacogroup.lpisgisserver.bundles.models.WmsLayerModuleMessage;
import com.abacogroup.lpisgisserver.bundles.models.WmsModuleMessage;
import com.abacogroup.lpisgisserver.bundles.models.WmsPermissionMessage;
import com.abacogroup.lpisgisserver.bundles.models.WmsServerMessage;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.AreasDAO;
import com.abacogroup.lpisgisserver.db.dao.CataloguesDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.LayerDAO;
import com.abacogroup.lpisgisserver.db.dao.WMSServerAreasDAO;
import com.abacogroup.lpisgisserver.db.ntt.AreaNTT;
import com.abacogroup.lpisgisserver.db.ntt.CatalogueNTT;
import com.abacogroup.lpisgisserver.db.ntt.I18nNTT;
import com.abacogroup.lpisgisserver.db.ntt.WmsLayerModuleNTT;
import com.abacogroup.lpisgisserver.db.ntt.WmsLayerNTT;
import com.abacogroup.lpisgisserver.db.ntt.WmsModuleNTT;
import com.abacogroup.lpisgisserver.db.ntt.WmsServerNTT;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Objects;

public class LayerMessageProcessor extends AbstractMessageProcessor {

	protected LayerDAO layerDAO;
	protected AreasDAO areasDAO;
	protected WMSServerAreasDAO wmsServerAreasDAO;
	protected CataloguesDAO cataloguesDAO;

	private final ObjectMapper objectMapper;

	private static final String WMS_SERVER_TABLE_NAME = "lpis_wms_servers";
	private static final String WMS_LAYER_TABLE_NAME = "lpis_wms_layers";

	private static final String WMS_FIELD_NAME = "code";

	private static final String WMS_MODULE_DESCRIPTION_FIELD_NAME = "code:module";

	private static final String DEFAULT_LANG = "en";
	
	private static final Logger log = LoggerFactory.getLogger(LayerMessageProcessor.class);

	public LayerMessageProcessor(DAOContainer dc) {
		super(dc);
		this.layerDAO = dc.getLayerDAO();
		this.areasDAO = dc.getAreasDAO();
		this.wmsServerAreasDAO = dc.getWmsServerAreasDAO();
		this.cataloguesDAO = dc.getCataloguesDAO();

		objectMapper = new ObjectMapper();
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
				.forEach(file -> deleteWmsMessage(message.getTenantId(), file));

		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
						&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
				.forEach(file -> insertOrUpdateWmsMessage(message.getTenantId(), file));
	}

	@Override
	public String getDomainName() {
		return "layers";
	}

	private void insertOrUpdateWmsMessage(String tenantId, File file) {
		try {
			LayerMessage wmsMessages = objectMapper.readValue(file, LayerMessage.class);

			if (wmsMessages == null) {
				return;
			}

			if (wmsMessages.getWms_servers() != null) {
				wmsMessages.getWms_servers().forEach(wmsServerMsg -> insertOrUpdateWmsServers(wmsServerMsg, tenantId));
			}

			if (wmsMessages.getWms_layers() != null) {
				wmsMessages.getWms_layers().forEach(wmsLayerMessage -> insertOrUpdateWmsLayers(wmsLayerMessage, tenantId));
			}
		} catch (Exception e) {
			log.error("Error processing file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}
	}
	
	private void insertOrUpdateWmsServers(WmsServerMessage wmsServerMsg, String tenantId) {
		try {
			WmsServerNTT wmsServer = WmsServerNTT.builder()
					.code(wmsServerMsg.getCode())
					.color(wmsServerMsg.getColor())
					.display_order(wmsServerMsg.getDisplay_order())
					.format(wmsServerMsg.getFormat())
					.icon_url(wmsServerMsg.getIcon_url())
					.server_type(wmsServerMsg.getServer_type())
					.srs(wmsServerMsg.getSrs())
					.transparent(wmsServerMsg.getTransparent())
					.url(wmsServerMsg.getUrl())
					.server_config(wmsServerMsg.getServer_config())
					.build();

			WmsServerNTT wmsServerToFind = layerDAO.findWmsServerByTenantAndCode(tenantId, wmsServer.getCode());
			if (wmsServerToFind == null) {
				wmsServer.setId(layerDAO.nextWmsServerSequenceVal());
				layerDAO.insertWmsServer(wmsServer, tenantId);
			} else {
				wmsServer.setId(wmsServerToFind.getId());
				if (!equalsWmsServersInfo(wmsServerToFind, wmsServer)) {
					layerDAO.updateWmsServerById(wmsServer);
				}
			}

			// Insert of permission are inside wms server
			insertWmsServerMessagePermissions(wmsServerMsg, wmsServer);

			insertOrUpdateWmsServerMessageDescription(wmsServerMsg, tenantId);

			// Insert / update of modules are inside wms server
			insertOrUpdateWmsServerMessageModules(wmsServerMsg, wmsServer);
			
			//insert of areas 
			insertWmsServerMessageAreas(wmsServerMsg, tenantId, wmsServer);
			

		} catch (Exception e) {
			log.error("Error during insert/update operation of WMS Server {} with tenant {} : {}", wmsServerMsg.getCode(), tenantId, e);
		}
	}

	private void insertWmsServerMessagePermissions(WmsServerMessage wmsServerMsg, WmsServerNTT wmsServer) {
		layerDAO.deleteWmsPermissionByWmsServerId(wmsServer.getId());

		if (wmsServerMsg.getPermissions() == null || wmsServerMsg.getPermissions().isEmpty()) {
			layerDAO.insertWmsPermission(wmsServer.getId(), null);
		} else {
			wmsServerMsg.getPermissions().forEach(contextFunction -> {
				if (layerDAO.countWmsPermissionByWmsServerIdAndContextFunction(wmsServer.getId(), contextFunction) == 0) {
					layerDAO.insertWmsPermission(wmsServer.getId(), contextFunction);
				}
			});
		}
	}

	private void insertWmsServerMessageAreas(WmsServerMessage wmsServerMsg, String tenantId, WmsServerNTT wmsServer) {
		if(wmsServerMsg.getAreas() != null) {
			wmsServerMsg.getAreas().forEach(areaCode -> {
				try {
					ServiceSupportEnv env = ServiceSupportEnv.builder()
							.tenantId(tenantId)
							.lang(DEFAULT_LANG)
							.referenceDate(AbsoluteDate.of(LocalDate.now()))
							.build();
					
					AreaNTT areaNTT = areasDAO.findAreasByCriterias(env, CriteriaBuilder.string("code").eq(areaCode))
							.stream()
							.findFirst()
							.orElse(null);
					
					if(areaNTT == null) {
						throw new IllegalArgumentException("Area code" + areaCode + " not found!");
					}

					if(wmsServerAreasDAO.findByWmsServerIdAndAreaId(wmsServer.getId(), areaNTT.getArea_id()).isEmpty()) {
						wmsServerAreasDAO.insert(wmsServer.getId(), areaNTT.getArea_id());
					}
				} catch (Exception e) {
					log.error("Error during insert operation of wms server area with wms server code {} and area code {} for tenant {} : {}"
							+ wmsServer.getCode(), areaCode, tenantId, e);
				}
			});
		}
	}

	private void insertOrUpdateWmsServerMessageModules(WmsServerMessage wmsServerMsg, WmsServerNTT wmsServer) {
		if (wmsServerMsg.getModules() != null) {
			wmsServerMsg.getModules().forEach((module, flOn) -> {
				Integer flOnNTT = Boolean.TRUE.equals(flOn) ? 1 : 0;
				WmsModuleNTT moduleMessageNTT = WmsModuleNTT.builder()
						.module(module)
						.wms_server_id(wmsServer.getId())
						.fl_on(flOnNTT)
						.build();

				WmsModuleNTT moduleNTT = layerDAO.findWmsModuleByWmsServerIdAndModule(wmsServer.getId(), module);
				if (moduleNTT == null) {
					layerDAO.insertWmsModule(moduleMessageNTT);
				} else if (!moduleNTT.getFl_on().equals(flOnNTT)) {
					layerDAO.updateWmsModuleFlOn(moduleMessageNTT);
				}
			});
		}
	}

	private void insertOrUpdateWmsServerMessageDescription(WmsServerMessage wmsServerMsg, String tenantId) {		
		if (wmsServerMsg.getDescription() != null) {
			I18nMessage i18nMessage = I18nMessage.builder()
					.table(WMS_SERVER_TABLE_NAME)
					.field(WMS_FIELD_NAME)
					.value(wmsServerMsg.getCode())
					.translations(wmsServerMsg.getDescription())
					.build();
			insertOrUpdateI18nMessages(tenantId, i18nMessage);
		}
	}

	private void insertOrUpdateWmsLayers(WmsLayerMessage wmsLayerMessage, String tenantId) {
		try {
			WmsServerNTT wmsServer = layerDAO.findWmsServerByTenantAndCode(tenantId, wmsLayerMessage.getWms_server_code());
			if (wmsServer == null) {
				log.error("WMS layer {} have a WMS Server with not existing code {}", wmsLayerMessage.getCode(),
						wmsLayerMessage.getWms_server_code());
			} else {
				String layerName = StringUtils.isNotBlank(wmsLayerMessage.getLayer_name()) ? wmsLayerMessage.getLayer_name()
						: wmsLayerMessage.getCode();
				
				ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).srs(wmsServer.getSrs()).build();
				
				checkCatalogueCode(env, wmsLayerMessage.getCatalogue_code());
				checkCatalogueCode(env, wmsLayerMessage.getInfo_catalogue_code());
				
				WmsLayerNTT wmsLayer = WmsLayerNTT.builder()
						.code(wmsLayerMessage.getCode())
						.display_order(wmsLayerMessage.getDisplay_order())
						.max_pixel_val(wmsLayerMessage.getMax_pixel_val())
						.foreground_level(wmsLayerMessage.getForeground_level() != null ? wmsLayerMessage.getForeground_level() : 0)
						.wms_server_id(wmsServer.getId())
						.layer_name(layerName)
						.layer_options(wmsLayerMessage.getLayer_options())
						.path(wmsLayerMessage.getPath())
						.catalogue_code(wmsLayerMessage.getCatalogue_code())
						.info_catalogue_code(wmsLayerMessage.getInfo_catalogue_code())
						.build();

				WmsLayerNTT wmsLayerToFind = layerDAO.findWmsLayerByTenantWmsServerCodeAndCode(tenantId, wmsLayerMessage.getWms_server_code(),
						wmsLayerMessage.getCode());
				if (wmsLayerToFind == null) {
					wmsLayer.setId(layerDAO.nextWmsLayerSequenceVal());
					layerDAO.insertWmsLayer(wmsLayer, tenantId);
				} else {
					wmsLayer.setId(wmsLayerToFind.getId());
					if (!equalsWmsLayersInfo(wmsLayerToFind, wmsLayer)) {
						layerDAO.updateWmsLayerById(wmsLayer);
					}
				}

				insertOrUpdateWmsLayerMessageDescriptions(wmsLayerMessage, tenantId);

				insertOrUpdateWmsLayerMessageModules(wmsLayerMessage, tenantId, wmsServer, wmsLayer);

			}

		} catch (Exception e) {
			log.error("Error during insert/update operation of WMS Layer {} with tenant {} : {}", wmsLayerMessage.getCode(), tenantId, e);
		}
	}

	private void checkCatalogueCode(ServiceSupportEnv env, String catalogueCode) {
		
		if(StringUtils.isBlank(catalogueCode)) {
			return;
		}
		
		List<Criteria> criterias = new ArrayList<>();
		criterias.add(CriteriaBuilder.string("code").eq(catalogueCode));


		Criteria criteria = CriteriaBuilder.and(criterias.toArray(new Criteria[0]));
	
		List<CatalogueNTT> catalogues = cataloguesDAO.getCatalogues(env, criteria);
		
		if(catalogues.isEmpty()) {
			throw new IllegalArgumentException("Catalogue code" + catalogueCode + " not found!");
		}
	}

	private void insertOrUpdateWmsLayerMessageModules(WmsLayerMessage wmsLayerMessage, String tenantId, WmsServerNTT wmsServer, WmsLayerNTT wmsLayer) {
		if (wmsLayerMessage.getModules() != null) {
			wmsLayerMessage.getModules().forEach(layerModule -> {
				Boolean flOn = layerModule.getFl_on();
				if (flOn == null) {
					WmsModuleNTT wmsModuleNTT = getWmsModuleByIdAndModule(wmsServer.getId(), layerModule.getModule());

					flOn = wmsModuleNTT.getFl_on() == 1 ? Boolean.TRUE : Boolean.FALSE;
				}

				WmsLayerModuleNTT wmsLayerModuleNTT = layerDAO.findWmsLayerModuleByWmsServerIdWmsLayerIdAndModule(wmsServer.getId(), wmsLayer.getId(),
						layerModule.getModule());

				WmsLayerModuleNTT toInsertOrUpdate = WmsLayerModuleNTT.builder()
						.fl_on(flOn.equals(Boolean.TRUE) ? 1 : 0)
						.module(layerModule.getModule())
						.wms_layer_id(wmsLayer.getId())
						.wms_server_id(wmsServer.getId())
						.build();

				if (wmsLayerModuleNTT == null) {
					layerDAO.insertWmsLayerModule(toInsertOrUpdate);
				} else {
					layerDAO.updateWmsLayerModuleFlOn(toInsertOrUpdate);
				}

				insertOrUpdateWmsLayerMessageModuleDescriptions(wmsLayerMessage, tenantId, layerModule);
			});
		}
	}

	private WmsModuleNTT getWmsModuleByIdAndModule(Long id, String module) {
		WmsModuleNTT wmsModuleNTT = layerDAO.findWmsModuleByWmsServerIdAndModule(id, module);
		if (wmsModuleNTT == null) {
			throw new IllegalStateException("WMS Server Module and layer module not define for module: " + module);
		}

		return wmsModuleNTT;
	}

	private void insertOrUpdateWmsLayerMessageModuleDescriptions(WmsLayerMessage wmsLayerMessage, String tenantId, WmsLayerModule layerModule) {
		if (layerModule.getDescription() != null) {
			I18nMessage i18nMessage = I18nMessage.builder()
					.table(WMS_LAYER_TABLE_NAME)
					.field(WMS_MODULE_DESCRIPTION_FIELD_NAME)
					.value(wmsLayerMessage.getCode() + ":" + layerModule.getModule())
					.translations(layerModule.getDescription())
					.build();
			insertOrUpdateI18nMessages(tenantId, i18nMessage);
		}
	}

	private void insertOrUpdateWmsLayerMessageDescriptions(WmsLayerMessage wmsLayerMessage, String tenantId) {
		if (wmsLayerMessage.getDescription() != null) {
			wmsLayerMessage.getDescription().forEach((lang, text) -> {
				I18nNTT wmsLayerMessageDescription = I18nNTT.builder()
						.tenant_id(tenantId)
						.table_name(WMS_LAYER_TABLE_NAME)
						.field_name(WMS_FIELD_NAME)
						.lang(lang)
						.i18n_value(wmsLayerMessage.getCode())
						.i18n_text(text)
						.build();

				I18nNTT i18nDescription = i18nDAO.findI18nByLpisI18nKeys(wmsLayerMessageDescription);
				if (i18nDescription == null) {
					i18nDAO.insert(wmsLayerMessageDescription);
				} else if (!StringUtils.equals(i18nDescription.getI18n_text(), text)) {
					i18nDAO.updateI18nText(wmsLayerMessageDescription);
				}
			});
		}
	}
	
	private void deleteWmsMessage(String tenantId, File file) {
		try {
			LayerMessage wmsMessages = objectMapper.readValue(file, LayerMessage.class);

			if (wmsMessages == null) {
				return;
			}

			if (wmsMessages.getWms_servers() != null) {
				wmsMessages.getWms_servers().forEach(wmsServerMessage -> deleteWmsServerById(wmsServerMessage, tenantId));
			}

			if (wmsMessages.getWms_layers() != null) {
				wmsMessages.getWms_layers().forEach(wmsLayerMessage -> deleteWmsLayerById(wmsLayerMessage, tenantId));
			}

			if (wmsMessages.getModules() != null) {
				wmsMessages.getModules().forEach(wmsModuleMessage -> deleteWmsModuleByWmsServerIdAndModule(wmsModuleMessage, tenantId));
			}

			if (wmsMessages.getLayer_modules() != null) {
				wmsMessages.getLayer_modules().forEach(wmsLayerModuleMessage -> deleteWmsLayerModuleByWmsServerIdAndModule(wmsLayerModuleMessage, tenantId));
			}

			if (wmsMessages.getPermissions() != null) {
				wmsMessages.getPermissions().forEach(wmsPermissionMessage -> deleteWmsPermissionByWmsServerIdAndContextFunction(wmsPermissionMessage, tenantId));
			}
		} catch (Exception e) {
			log.error("Error processing file {}  for tenant {} : {}", file.getName(), tenantId, e);
		}
	}
	
	private void deleteWmsServerById(WmsServerMessage wmsServerMessage, String tenantId) {
		try {
			WmsServerNTT wmsServer = layerDAO.findWmsServerByTenantAndCode(tenantId, wmsServerMessage.getCode());

			if (wmsServer != null) {
				layerDAO.deleteWmsServerById(wmsServer.getId());
			}
		} catch (Exception e) {
			log.error("Error during delete operation of WMS Server {} with tenant {} : {}", wmsServerMessage.getCode(), tenantId, e);
		}
	}
	
	private void deleteWmsLayerById(WmsLayerMessage wmsLayerMessage, String tenantId) {
		try {
			WmsLayerNTT wmsLayer = layerDAO.findWmsLayerByTenantWmsServerCodeAndCode(tenantId, wmsLayerMessage.getWms_server_code(),
					wmsLayerMessage.getCode());

			if (wmsLayer != null) {
				layerDAO.deleteWmsLayerById(wmsLayer.getId());
			}
		} catch (Exception e) {
			log.error("Error during delete operation of WMS Layer {} with tenant {} : {}", wmsLayerMessage.getCode(), tenantId, e);
		}
	}
	
	private void deleteWmsModuleByWmsServerIdAndModule(WmsModuleMessage wmsModuleMessage, String tenantId) {
		try {
			Long wmwServerId = layerDAO.findWmsServerIdFromWmsModulesByTenantWmsServerCodeAndModule(tenantId, wmsModuleMessage.getWms_server_code(),
					wmsModuleMessage.getModule());

			if (wmwServerId != null) {
				layerDAO.deleteWmsModuleByWmsServerIdAndModule(wmwServerId, wmsModuleMessage.getModule());
			}
		} catch (Exception e) {
			log.error(
					"Error during delete operation of WMS Module {} of server {} with tenant {} : {}", wmsModuleMessage.getModule(),
					wmsModuleMessage.getWms_server_code(), tenantId, e);
		}
	}
	
	private void deleteWmsLayerModuleByWmsServerIdAndModule(WmsLayerModuleMessage wmsLayerModuleMessage, String tenantId) {
		try {
			WmsLayerModuleNTT wmsLayerModuleNTT = layerDAO.findWmsLayerModuleFromWmsModulesByTenantWmsServerCodeWmsLayerCodeAndModule(tenantId,
					wmsLayerModuleMessage.getWms_server_code(),
					wmsLayerModuleMessage.getWms_layer_code(), wmsLayerModuleMessage.getModule());

			if (wmsLayerModuleNTT != null) {
				layerDAO.deleteWmsLayerModuleByWmsServerIdWmsLayerIdAndModule(wmsLayerModuleNTT);
			}
		} catch (Exception e) {
			log.error(
					"Error during delete operation of WMS Module {} of server {} of layer {} with tenant {} : {}", wmsLayerModuleMessage.getModule(),
					wmsLayerModuleMessage.getWms_server_code(), wmsLayerModuleMessage.getWms_layer_code(), tenantId, e);
		}
	}

	private void deleteWmsPermissionByWmsServerIdAndContextFunction(WmsPermissionMessage wmsPermissionMessage, String tenantId) {
		try {
			Long wmwServerId = layerDAO.findWmsServerIdFromWmsPermissionByTenantWmsServerCodeAndContextFunction(tenantId,
					wmsPermissionMessage.getWms_server_code(), wmsPermissionMessage.getContext_function());

			if (wmwServerId != null) {
				layerDAO.deleteWmsPermissionByWmsServerIdAndContextFunction(wmwServerId, wmsPermissionMessage.getContext_function());
			}
		} catch (Exception e) {
			log.error("Error during delete operation of WMS Permission {} of server {} with tenant {} : {} ",
					wmsPermissionMessage.getContext_function(), wmsPermissionMessage.getWms_server_code(), tenantId, e);
		}
	}
	
	private boolean equalsWmsServersInfo(WmsServerNTT wmsServer, WmsServerNTT fromWmsServerMessage) {
		return StringUtils.equals(wmsServer.getColor(), fromWmsServerMessage.getColor())
				&& wmsServer.getDisplay_order().equals(fromWmsServerMessage.getDisplay_order())
				&& StringUtils.equals(wmsServer.getFormat(), fromWmsServerMessage.getFormat())
				&& StringUtils.equals(wmsServer.getIcon_url(), fromWmsServerMessage.getIcon_url())
				&& StringUtils.equals(wmsServer.getServer_type(), fromWmsServerMessage.getServer_type())
				&& StringUtils.equals(wmsServer.getSrs(), fromWmsServerMessage.getSrs())
				&& wmsServer.getTransparent().equals(fromWmsServerMessage.getTransparent())
				&& StringUtils.equals(wmsServer.getUrl(), fromWmsServerMessage.getUrl())
				&& StringUtils.equals(wmsServer.getServer_config(), fromWmsServerMessage.getServer_config());
	}

	private boolean equalsWmsLayersInfo(WmsLayerNTT wmsLayer, WmsLayerNTT fromWmsLayerMessage) {
		return wmsLayer.getDisplay_order().equals(fromWmsLayerMessage.getDisplay_order())
				&& wmsLayer.getForeground_level().equals(fromWmsLayerMessage.getForeground_level())
				&& wmsLayer.getLayer_name().equals(fromWmsLayerMessage.getLayer_name())
				&& equalsMaxPixelVal(wmsLayer, fromWmsLayerMessage)
				&& Objects.equal(wmsLayer.getPath(), fromWmsLayerMessage.getPath())
				&& Objects.equal(wmsLayer.getCatalogue_code(), fromWmsLayerMessage.getCatalogue_code())
				&& Objects.equal(wmsLayer.getInfo_catalogue_code(), fromWmsLayerMessage.getInfo_catalogue_code());
	}

	private boolean equalsMaxPixelVal(WmsLayerNTT wmsLayer, WmsLayerNTT fromWmsLayerMessage) {
		return (wmsLayer.getMax_pixel_val() == null && fromWmsLayerMessage.getMax_pixel_val() == null) ||
				(wmsLayer.getMax_pixel_val() != null && fromWmsLayerMessage.getMax_pixel_val() != null
						&& wmsLayer.getMax_pixel_val().equals(fromWmsLayerMessage.getMax_pixel_val()));
	}

}
