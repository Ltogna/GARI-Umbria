package com.abacogroup.lpisgisserver.core.exceptions.parcel;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class TooMuchParcelsRequestedException extends AbstractException {

	private static final long serialVersionUID = -1121620016031386996L;
	private static final ErrorCode ERROR_CODE = ErrorCode.TOO_MUCH_PARCELS_REQUESTED;

	public TooMuchParcelsRequestedException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new TooMuchParcelsRequestedExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Too much parcels in request")
	public static class TooMuchParcelsRequestedExceptionBody extends AbstractExceptionBody {

		private static final long serialVersionUID = -8210501030944576284L;

		public TooMuchParcelsRequestedExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
