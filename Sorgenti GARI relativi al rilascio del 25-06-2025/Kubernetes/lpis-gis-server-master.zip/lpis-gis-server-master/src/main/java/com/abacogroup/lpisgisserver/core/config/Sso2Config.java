package com.abacogroup.lpisgisserver.core.config;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
@Valid
public class Sso2Config {

	@NotEmpty
	private String url;
	
	@NotEmpty
	private String authPhrase;
	
}
