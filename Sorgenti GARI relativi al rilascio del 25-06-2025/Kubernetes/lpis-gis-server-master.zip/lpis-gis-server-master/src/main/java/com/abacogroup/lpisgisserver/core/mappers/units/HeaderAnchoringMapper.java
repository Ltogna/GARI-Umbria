package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.HeaderAnchoringNTT;
import com.abacogroup.lpisgisserver.resources.res.units.HeaderAnchoring;

@Mapper
public interface HeaderAnchoringMapper {

	HeaderAnchoringMapper INSTANCE = Mappers.getMapper(HeaderAnchoringMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	HeaderAnchoring entityToDto(HeaderAnchoringNTT entity);
	
	@Mapping(target = "flVisible", expression = "java(dto.getVisible() ? 1 : 0)")
	@Mapping(target = "typeCode", ignore = true)
	HeaderAnchoringNTT dtoToEntity(HeaderAnchoring dto);
}
