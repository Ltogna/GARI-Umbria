package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.PolesHeaderNTT;
import com.abacogroup.lpisgisserver.resources.res.units.PolesHeader;

@Mapper
public interface PolesHeaderMapper {

	PolesHeaderMapper INSTANCE = Mappers.getMapper(PolesHeaderMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	PolesHeader entityToDto(PolesHeaderNTT entity);
	
	@Mapping(target = "flVisible", expression = "java(dto.getVisible() ? 1 : 0)")
	@Mapping(target = "typeCode", ignore = true)
	PolesHeaderNTT dtoToEntity(PolesHeader dto);
}
