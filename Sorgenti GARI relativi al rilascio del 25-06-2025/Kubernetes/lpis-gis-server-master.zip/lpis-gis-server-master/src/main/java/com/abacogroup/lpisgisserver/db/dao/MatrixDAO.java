package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.jdbi.paging.PagingParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.MatrixNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface MatrixDAO extends Transactional<MatrixDAO>, EnhancedSqlObject {

	@SqlQuery("§select_nextval(lpis_matrix_sequence)§")
	Long nextSequenceVal();

	@SqlUpdate("INSERT INTO lpis_matrix (id, tenant_id, code) VALUES(:id, :tenant_id, :code)")
	void insert(@BindBean MatrixNTT rs);

	@SqlQuery("select * from lpis_matrix where id = :id")
	@RegisterBeanMapper(MatrixNTT.class)
	List<MatrixNTT> findById(@Bind("id") Long id);

	@SqlQuery("select * from lpis_matrix")
	@RegisterBeanMapper(MatrixNTT.class)
	List<MatrixNTT> findPagedType(PagingParams pp);

	@SqlUpdate("update lpis_matrix \n"
			 + "   set tenant_id = :tenant_id, \n"
			 + "       code = :code \n" 
			 + " where id = :id")
	void update(@BindBean MatrixNTT rs);

	@SqlUpdate("delete from lpis_matrix where id = :id")
	void deleteById(@Bind("id") Long id);

	
	/* ************************************ */
	
	@SqlQuery("select id, tenant_id, code from lpis_matrix where tenant_id = :tenantId and code = :matrixCode")
	@RegisterBeanMapper(MatrixNTT.class)
	List<MatrixNTT> findByCode(@BindBean ServiceSupportEnv env, @Bind("matrixCode") String code);
	
	
}
