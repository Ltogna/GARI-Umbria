package com.abacogroup.lpisgisserver.core.models.georaster;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GeorasterAuthToken {
	
	private String token;

}
