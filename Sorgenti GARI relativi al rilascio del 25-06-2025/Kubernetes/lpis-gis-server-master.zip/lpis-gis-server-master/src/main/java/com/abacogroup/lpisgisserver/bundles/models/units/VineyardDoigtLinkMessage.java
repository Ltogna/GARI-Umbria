package com.abacogroup.lpisgisserver.bundles.models.units;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class VineyardDoigtLinkMessage {
	private String doigt_code;
	private String vineyard_code;
}
