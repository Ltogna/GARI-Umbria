package com.abacogroup.lpisgisserver.core.exceptions.wms;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidWmsRequestException extends AbstractException {

	private static final long serialVersionUID = 7370585738638133178L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_WMS_SERVER_REQUEST;

	public InvalidWmsRequestException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new InvalidWmsRequestExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Invalid wms server request")
	public static class InvalidWmsRequestExceptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = 1029427751443114978L;

		public InvalidWmsRequestExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
