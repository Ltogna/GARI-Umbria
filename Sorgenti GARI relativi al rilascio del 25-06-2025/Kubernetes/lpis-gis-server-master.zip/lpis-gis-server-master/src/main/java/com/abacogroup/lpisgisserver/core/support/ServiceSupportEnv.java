package com.abacogroup.lpisgisserver.core.support;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.resources.ResourceConstants;

import lombok.Builder;
import lombok.Data;

/**
 * Support object for services, it contain all informations usually useful for service elaborations
 */
@Data
@Builder
public class ServiceSupportEnv {

	private User user;
	private String lang;
	private String tenantId;
	private String sessionId;
	
	private String sdeCode;

	private String sectorCode;
	private String blockCode;
	private String parcelCode;
	
	private Long sectorId;
	private Long blockId;
	private Long parcelId;
	private Long landCoverId;
	
	private String srs;
	
	private AbsoluteDate referenceDate;
	
	private Operation operation;
	
	private Boolean labels;
	private Boolean outline;
	private Boolean fill;
	private String areaLevel;
	@Builder.Default
	private String landCoverStyleMatrixCode = "";
	private String defaultLCFillRGBA;
	private String defaultLCLineRGBA;
	private Integer defaultLCLineThick;
	private Long parentAreaId;
	
	private Long partyId;

	@Builder.Default
	private Integer includeLandCovers = 1;
	@Builder.Default
	private Integer includeGeometries = 1;	
	@Builder.Default
	private Integer includeLayerStyle = 1;
	@Builder.Default
	private Integer includeUnits = 1;
	@Builder.Default
	private Integer includeAnomalies = 1;

	
	private String nextKey;
	private Integer pageSize;
	
	public String getNextKey() {
		return (nextKey == null || nextKey.isBlank()) ? null : nextKey;
	}

	public Integer getPageSize() {
		return (pageSize == null || pageSize < 1 || pageSize > ResourceConstants.MAX_PAGE_SIZE) ? ResourceConstants.DEFAULT_PAGE_SIZE : pageSize;
	}
	
	public String getUserName() {
		return this.getUser() != null ? this.getUser().getName() : null;
	}
	
	public String getUserId() {
		return this.getUser() != null ? this.getUser().getUserId() : null;
	}
	
}
