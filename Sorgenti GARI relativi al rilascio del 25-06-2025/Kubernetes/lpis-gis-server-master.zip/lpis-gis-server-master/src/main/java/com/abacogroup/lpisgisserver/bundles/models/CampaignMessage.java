package com.abacogroup.lpisgisserver.bundles.models;

import java.util.Map;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CampaignMessage {
	private String code;
	private AbsoluteDate reference_date;
	private Map<String, String> description;
}
