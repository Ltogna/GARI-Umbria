package com.abacogroup.lpisgisserver.db.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.EditSessionNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface EditSessionsDAO extends Transactional<EditSessionsDAO>, EnhancedSqlObject {

	@SqlUpdate("INSERT INTO lpis_edit_sessions (uuid, tenant_id, user_id, dt_last_lock, lock_geom, lock_geom_srs, reference_date, task_id, parcel_id) " +
			"VALUES(:uuid, :tenant_id, :user_id, §current_timestamp§, :lock_geom, :lock_geom_srs, :reference_date, :task_id, :parcel_id)")
	void insert(@BindBean EditSessionNTT rs);

	@SqlQuery("\nselect uuid, tenant_id, user_id, dt_last_lock, lock_geom, lock_geom_srs, reference_date, task_id, parcel_id from lpis_edit_sessions where uuid = :id fetch first row only\n")
	@RegisterBeanMapper(EditSessionNTT.class)
	EditSessionNTT findById(@Bind("id") String id);

	@SqlQuery("select uuid, tenant_id, user_id, dt_last_lock, lock_geom, lock_geom_srs, reference_date, task_id, parcel_id from lpis_edit_sessions where tenant_id = :tenantId")
	@RegisterBeanMapper(EditSessionNTT.class)
	List<EditSessionNTT> findByTenantId(@Bind("tenantId") String tenant);

	@SqlUpdate("update lpis_edit_sessions "
			+ "    set tenant_id = :tenant_id, user_id = :user_id,"
			+ "        dt_last_lock = §current_timestamp§, lock_geom = :lock_geom, "
			+ "        lock_geom_srs = :lock_geom_srs, reference_date = :reference_date, "
			+ "        task_id = :task_id "
			+ "  where uuid = :uuid")
	void update(@BindBean EditSessionNTT rs);
	
	@SqlUpdate("update lpis_edit_sessions "
			+ "    set parcel_id = :parcelId "
			+ "  where uuid = :uuid and tenant_id = :tenantId ")
	void updateParcelIdByTenantAndSessionId(@Bind("tenantId") String tenantId, @Bind("uuid") String uuid, 
			@Bind("parcelId") Long parcelId);

	@SqlUpdate("delete from lpis_edit_sessions where uuid = :id")
	void deleteById(@Bind("id") String id);

	@SqlUpdate("update lpis_edit_sessions set dt_last_lock = §current_timestamp§ where uuid = :id")
	void refreshDateById(@Bind("id") String id);

	@SqlQuery("\n"
			+ "select uuid, tenant_id, user_id, dt_last_lock, lock_geom, lock_geom_srs, reference_date, task_id, parcel_id \n"
			+ "  from lpis_edit_sessions "
			+ " where uuid = :sessionId \n"
			+ "   and tenant_id = :tenantId \n"
			+ "   and user_id = :username \n"
			+ "   and dt_last_lock > :lastValidSessionTime \n"
			+ " fetch first row only \n"
			+ "")
	@RegisterBeanMapper(EditSessionNTT.class)
	EditSessionNTT findValidUserSession(
			@Bind("sessionId") String sessionid,
			@Bind("tenantId") String tenantId,
			@Bind("username") String username,
			@Bind("lastValidSessionTime") LocalDateTime lastValidSessionTime);

	@SqlQuery("\n"
			+ "select uuid, tenant_id, user_id, dt_last_lock, lock_geom, lock_geom_srs, reference_date, task_id, parcel_id \n"
			+ "  from lpis_edit_sessions "
			+ " where uuid = :sessionId \n"
			+ "   and tenant_id = :tenantId \n"
			+ "   and user_id = :username \n"
			+ " fetch first row only \n"
			+ "")
	@RegisterBeanMapper(EditSessionNTT.class)
	EditSessionNTT findUserSession(
			@Bind("sessionId") String sessionid,
			@Bind("tenantId") String tenantId,
			@Bind("username") String username);

	@SqlQuery("\n"
			+ "select count(*) \n"
			+ "  from lpis_parcels \n"
			+ " where tenant_id = :tenantId \n"
			+ "   and id = :parcelId \n")
	Long countUserParcel(@Bind("tenantId") String tenantId, @Bind("parcelId") Long parcelId);

	@SqlQuery("\n"
			+ "select parcel_id \n"
			+ "  from lpis_lock_parcels \n"
			+ " where (session_uuid <> :sessionId or :sessionId is null)\n"
			+ "   and parcel_id in (<parcelIds>) \n")
	List<Long> findOtherSessionsLockedParcelIds(@Bind("sessionId") String sessionId, @BindList("parcelIds") List<Long> connectedIds);

	@SqlQuery("""
              select count(*) 
                from lpis_edit_sessions 
               where tenant_id = :tenantId 
                 and §geom_have_interactions(lock_geom, :geom)§ 
                 and dt_last_lock > :lastValidSessionTime 
                 and (uuid <> :myUuid or :myUuid is null) 
              """)
	Long findOtherLockedGeoms(@Bind("tenantId") String tenantId, @Bind("geom") Geometry geom, @Bind("myUuid") String myUuid,
			@Bind("lastValidSessionTime") LocalDateTime lastValidSessionTime);

}
