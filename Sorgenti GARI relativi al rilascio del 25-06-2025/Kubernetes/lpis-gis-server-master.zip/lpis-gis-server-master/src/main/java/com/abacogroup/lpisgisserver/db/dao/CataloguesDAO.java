package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.CatalogueConfigParamNTT;
import com.abacogroup.lpisgisserver.db.ntt.CatalogueGeomNTT;
import com.abacogroup.lpisgisserver.db.ntt.CatalogueNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface CataloguesDAO extends Transactional<CataloguesDAO>, EnhancedSqlObject {

	@SqlQuery("§select_nextval(lpis_catalogues_sequence)§")
	Long nextSequenceValCatalogueId();

	@SqlUpdate("insert into lpis_catalogues (id, tenant_id, type, code, srs, display_order, fl_visible) \n"
			+ "values (:id, :tenantId, :type, :code, :srs, :displayOrder, :flVisible) \n")
	void insertCatalogue(@Bind("tenantId") String tenantId, @BindBean CatalogueNTT catalogueNTT);
	
	@SqlUpdate("insert into lpis_catalogue_config_params (tenant_id, catalogue_code, param_key, param_value) \n"
			+ "values (:tenantId, :catalogueCode, :paramKey, :paramValue) \n")
	void insertCatalogueParam(@Bind("tenantId") String tenantId, @BindBean CatalogueConfigParamNTT catalogueConfigParamNTT);

	@SqlQuery("SELECT cp.catalogue_code, \n"
			+ "       cp.param_key, \n"
			+ "       cp.param_value \n"
			+ "  FROM lpis_catalogue_config_params cp \n"
			+ " WHERE cp.tenant_id = :tenantId \n"
			+ "   AND cp.catalogue_code = :code \n"
			+ "")
	@RegisterBeanMapper(CatalogueConfigParamNTT.class)
	List<CatalogueConfigParamNTT> getCatalogueParamsByCode(@Bind("tenantId") String tenantId, @Bind("code") String catalogueCode);
	
	@SqlQuery("SELECT c.id, \n"
		    + "       c.type, \n"
		    + "       c.code, \n"
		    + "       §i18n(:tenantId, 'lpis_catalogues', 'code', c.code, :lang)§ as description, \n"
		    + "       c.srs, \n"
		    + "       c.display_order, \n"
		    + "       c.fl_visible \n"
		    + "  FROM lpis_catalogues c \n"
		    + " WHERE c.tenant_id = :tenantId \n"
		    + " ")
	@RegisterBeanMapper(CatalogueNTT.class)
	List<CatalogueNTT> getCataloguesByTenantId(@Bind("tenantId") String tenantId);
	
	@SqlQuery("SELECT c.id, \n"
			+ "       c.type, \n"
			+ "       c.code, \n"
			+ "       §i18n(:tenantId, 'lpis_catalogues', 'code', c.code, :lang)§ as description, \n"
			+ "       case when c.srs = '*' then null else c.srs end as srs, \n"
			+ "       c.display_order, \n"
			+ "       c.fl_visible \n"
			+ "  FROM lpis_catalogues c \n"
			+ " WHERE c.tenant_id = :tenantId \n"
			+ "   AND (c.srs = :srs or c.srs = '*') \n"
			+ "   AND <criteria> \n"
			+ " ")
	@RegisterBeanMapper(CatalogueNTT.class)
	List<CatalogueNTT> getCatalogues(@BindBean ServiceSupportEnv env, @BindCriteria Criteria criteria);
	
	@SqlUpdate("update lpis_catalogues set type = :type, display_order = :displayOrder, fl_visible = :flVisible where tenant_id = :tenantId and id = :id")
	void updateCatalogueById(@Bind("tenantId") String tenantId, @BindBean CatalogueNTT catalogueNTT);
	
	@SqlUpdate("delete from lpis_catalogues where tenant_id = :tenantId and id = :id")
	void deleteCatalogueById(@Bind("tenantId") String tenantId, @Bind("id") Long catalogueId);
	
	@SqlUpdate("delete from lpis_catalogue_config_params where tenant_id = :tenantId and catalogue_code = :catalogueCode and key = :key")
	void deleteCatalogueParamByCodeAndKey(@Bind("tenantId") String tenantId, @Bind("catalogueCode") String catalogueCode, @Bind("key") String key);
	
	@SqlUpdate("delete from lpis_catalogue_config_params where tenant_id = :tenantId and catalogue_code = :catalogueCode")
	void deleteCatalogueParamByCode(@Bind("tenantId") String tenantId, @Bind("catalogueCode") String catalogueCode);

	@SqlQuery("\n "
			+ "select lpld.land_cover_id as id, \n"
			+ "    lpld.geom, \n"
			+ "    lpld.land_cover_code as label \n"
			+ "  from lpis_parcels lp \n"
			+ " inner join lpis_parcel_land_covers lplc on lp.id = lplc.parcel_id \n"
			+ " inner join lpis_parcel_lc_details lpld on lplc.id = lpld.land_cover_id \n"
			+ " where lp.tenant_id = :tenantId \n"
			+ "   and §current_timestamp§ between lpld.dt_insert and lpld.dt_delete \n"
			+ "   and :referenceDate between lpld.day_from and lpld.day_to \n"
			+ "   and :srs = lpld.srs \n"
			+ "   and §geom_have_interactions(lpld.geom, :touchingGeometry)§ \n")
	@RegisterBeanMapper(CatalogueGeomNTT.class)
	ResultIterator<CatalogueGeomNTT> getLandCoversGeoms(@Bind("tenantId") String tenantId, 
			@Bind("referenceDate") AbsoluteDate referenceDate, 
			@Bind("srs") String srs,
			@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("\n "
			+ "select lpld.land_cover_id as id, \n"
			+ "    lpld.geom, \n"
			+ "    lpld.land_cover_code || ' - ' || coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', lpld.land_cover_code, :lang)§, lpld.land_cover_code) as label \n"
			+ "  from lpis_parcels lp \n"
			+ " inner join lpis_parcel_land_covers lplc on lp.id = lplc.parcel_id \n"
			+ " inner join lpis_parcel_lc_details lpld on lplc.id = lpld.land_cover_id \n"
			+ " where lp.tenant_id = :tenantId \n"
			+ "   and §current_timestamp§ between lpld.dt_insert and lpld.dt_delete \n"
			+ "   and :referenceDate between lpld.day_from and lpld.day_to \n"
			+ "   and :srs = lpld.srs \n"
			+ "   and §geom_have_interactions(lpld.geom, :touchingGeometry)§ \n")
	@RegisterBeanMapper(CatalogueGeomNTT.class)
	List<CatalogueGeomNTT> getLandCoversGeomsList(@BindBean ServiceSupportEnv env,
			@Bind("referenceDate") AbsoluteDate referenceDate, 
			@Bind("srs") String srs,
			@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("select lesd.geom, \n"
			+ "    lesd.parcel as label \n"
			+ "  from lpis_external_source_data lesd \n"
			+ " where lesd.tenant_id = :tenantId \n"
			+ "   and (:code is null or upper(lesd.external_source_code) = upper(:code)) \n"
			+ "   and :srs = lesd.srs \n"
			+ "   and §geom_have_interactions(lesd.geom, :touchingGeometry)§ \n")
	@RegisterBeanMapper(CatalogueGeomNTT.class)
	ResultIterator<CatalogueGeomNTT> getSdeGeoms(
			@Bind("tenantId") String tenantId, 
			@Bind("srs") String srs,
			@Bind("touchingGeometry") Geometry touchingGeometry,
			@Bind("code") String sdeCode);

	@SqlQuery("select lsb.id, \n"
			+ "   lsbd.geom, \n"
			+ "   lsb.block as label \n"
			+ "from lpis_sector_blocks lsb \n"
			+ "inner join lpis_sector_block_details lsbd on lsb.id = lsbd.sector_block_id \n"
			+ "where lsb.tenant_id = :tenantId \n"
			+ "and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete \n"
			+ "and :srs = lsbd.srs \n"
			+ "and §geom_have_interactions(lsbd.geom, :touchingGeometry)§ \n")
	@RegisterBeanMapper(CatalogueGeomNTT.class)
	ResultIterator<CatalogueGeomNTT> getBlockGeoms(@Bind("tenantId") String tenantId, 
			@Bind("srs") String srs,
			@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select lsb.id, \n"
			+ "   lsbd.geom, \n"
			+ "   lsb.block as label \n"
			+ "from lpis_sector_blocks lsb \n"
			+ "inner join lpis_sector_block_details lsbd on lsb.id = lsbd.sector_block_id \n"
			+ "where lsb.tenant_id = :tenantId \n"
			+ "and §current_timestamp§ between lsbd.dt_insert and lsbd.dt_delete \n"
			+ "and :srs = lsbd.srs \n"
			+ "and §geom_have_interactions(lsbd.geom, :touchingGeometry)§ \n")
	@RegisterBeanMapper(CatalogueGeomNTT.class)
	List<CatalogueGeomNTT> getBlockGeomsList(@Bind("tenantId") String tenantId, 
			@Bind("srs") String srs,
			@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("select distinct tenant_id from lpis_catalogues")
	List<String> getAllTenants();
}