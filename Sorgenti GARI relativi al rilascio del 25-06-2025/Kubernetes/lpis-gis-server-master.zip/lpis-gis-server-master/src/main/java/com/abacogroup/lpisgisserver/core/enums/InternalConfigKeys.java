package com.abacogroup.lpisgisserver.core.enums;

public enum InternalConfigKeys {

	BUFFER_SIZE_KEY("buffer_size"),
	MINIMUM_VALID_LOCK_AREA_KEY("minimum_valid_lock_area"),
	MAXIMUM_VALID_LOCK_AREA_KEY("maximum_valid_lock_area"),
	MAXIMUM_VALID_SESSION_H_DURATION_KEY("maximum_valid_session_h_duration"),
	MAXIMUM_PARCELS_TO_MERGE_KEY("maximum_parcels_to_merge"),
	DEFAULT_LAND_COVER_CODE_KEY("default_land_cover_code"),
	MAXIMUM_VALID_SEARCH_PARCELS_GEOM_AREA_KEY("maximum_valid_search_parcels_geom_area"),
	WORKFLOW_SCOPE_KEY("workflow_scope"),
	FLAG_MUST_COVER_ALL_LANDCOVER_KEY("flag_must_cover_all_landcover"),
	FLAG_MERGE_LAND_COVERS_WITH_SAME_CODE_KEY("flag_merge_land_covers_with_same_code"),
	DEFAULT_SAU_MATRIX_CODE_KEY("default_sau_matrix_code"),
	DEFAULT_LANDCOVERS_STYLE_MATRIX_CODE_KEY("default_landcovers_style_matrix_code"),
	MAXIMUM_DIFFERENCE_LANDCOVER_AREA_KEY("maximum_difference_landcover_area_tol"),
	LINEAR_LANDCOVER_THICKNESSES_KEY("linear_landcover_thicknesses"),
	FLAG_SET_SECTOR_PARCEL_KEY("fl_set_sector_parcel"),
	FLAG_SET_BLOCK_PARCEL_KEY("fl_set_block_parcel"),
	FLAG_SET_PARCEL_CODE_KEY("fl_set_parcel_code"),
	PARCEL_CODE_SEPARATOR_KEY("parcel_code_separator"),
	MINIMUM_UPDATE_BUFFER_SIZE_KEY( "minimum_update_buffer_size"),
	MAXIMUM_UPDATE_BUFFER_SIZE_KEY("maximum_update_buffer_size"),
	MINIMUM_PARCELS_AREA_KEY("minimum_parcels_area"),
	MINIMUM_LAND_COVERS_AREA_KEY("minimum_land_covers_area"),
	ANOMALIES_PARCEL_ENTITY_CODE_KEY("anomalies_parcel_entity_code"),
	FL_SHOW_UNCATEGORIZED_ANOMALY_TYPES_KEY("fl_show_uncategorized_anomaly_types"),
	FL_FORCE_NEW_PARCEL_VERSION_KEY("fl_force_new_parcel_version"),
	PUBLIC_MAXIMUM_VALID_SEARCH_PARCELS_GEOM_AREA_KEY("public_maximum_valid_search_parcels_geom_area"),
	PUBLIC_MAXIMUM_PARCELS_IDS_LIST_REQ_SIZE_KEY("public_maximum_parcels_ids_list_req_size"),
	PARTY_REGISTRY_DIRECTORY_URL_KEY("party_registry_directory_url"),
	FL_COORDINATES_FORMAT_HDMS("fl_coordinates_format_hdms"),
	FL_HIDE_COORDINATES_ON_MAP("fl_hide_coordinates_on_map"),
	FL_SEARCH_EXTERNAL_PARCELS("fl_search_external_parcels"),
	FL_ENABLE_CAMPAIGN_YEAR("fl_enable_campaign_year"),
	FL_HIDE_LANDCOVERS_LAYER("fl_hide_landcovers_layer"),
	
	DEFAULT_WMS_PARCELS_STYLE("default_wms_parcels_style"),	
	DEFAULT_WMS_PARCELS_NOTPOLYGON_STYLE("default_wms_parcels_notpolygon_style"),
	DEFAULT_WMS_LANDCOVERS_STYLE("default_wms_landcovers_style"),	
	DEFAULT_WMS_SDE_PARCELS_STYLE("default_wms_sde_parcels_style"),
	DEFAULT_WMS_SECTORS_STYLE("default_wms_sectors_style"),
	DEFAULT_WMS_BLOCKS_STYLE("default_wms_blocks_style"),
	DEFAULT_WMS_AREAS_STYLES("default_wms_areas_styles"),
	
	MOCK_FARMLAND_VIEWER_PARCEL_LIST("mock_farmland_viewer_parcel_list"),
	ENABLE_MOVE_VERTEX("enable_move_vertex"),
	EDIT_STATUS_TO_EXCLUDE_FROM_STACK_SEARCH("edit_status_to_exclude_from_stack_search"),

	CLL_MAX_CLEAR_TIME_MIN("cll_max_clear_time_min"),
	TEMP_PARCELS_CACHE_MAX_CLEAR_TIME_MIN("temp_parcels_cache_max_clear_time_min"),
	EDITOR_COMMANDS("editor_commands"),
	PARCEL_LANDCOVER_ONE_TO_ONE("parcel_landcover_one_to_one"),
	LANDCOVER_ORIGIN_CATALOGUE_CODE("landcover_origin_catalogue_code"),
	CROSS_TENANT_LPIS_CONFIG("cross_tenant_lpis_config"),
	CROSS_TENANT_LPIS_URL("cross_tenant_lpis_url"),

// DEPRECATED!!!
	DEFAULT_PARCELS_LINE_THICK_KEY("default_parcels_line_thick"),
	DEFAULT_PARCELS_LINE_RGBA_KEY("default_parcels_line_rgba"),
	DEFAULT_PARCELS_FILL_RGBA_KEY("default_parcels_fill_rgba"),
	DEFAULT_PARCELS_LABEL_COLOR("default_parcels_label_color"),
	DEFAULT_PARCELS_LABEL_SIZE("default_parcels_label_size"),	
	
	DEFAULT_LANDCOVERS_LINE_THICK_KEY("default_landcovers_line_thick"),
	DEFAULT_LANDCOVERS_LINE_RGBA_KEY("default_landcovers_line_rgba"),
	DEFAULT_LANDCOVERS_FILL_RGBA_KEY("default_landcovers_fill_rgba"),
	DEFAULT_LANDCOVERS_LABEL_COLOR("default_landcovers_label_color"),
	DEFAULT_LANDCOVERS_LABEL_SIZE("default_landcovers_label_size"),
	
	DEFAULT_SECTORS_LINE_THICK_KEY("default_sectors_line_thick"),
	DEFAULT_SECTORS_LINE_RGBA_KEY("default_sectors_line_rgba"),
	DEFAULT_SECTORS_FILL_RGBA_KEY("default_sectors_fill_rgba"),
	DEFAULT_SECTORS_LABEL_COLOR("default_sectors_label_color"),
	DEFAULT_SECTORS_LABEL_SIZE("default_sectors_label_size"),
	
	DEFAULT_SECTOR_BLOCKS_LINE_THICK_KEY("default_sector_blocks_line_thick"),
	DEFAULT_SECTOR_BLOCKS_LINE_RGBA_KEY("default_sector_blocks_line_rgba"),
	DEFAULT_SECTOR_BLOCKS_FILL_RGBA_KEY("default_sector_blocks_fill_rgba"),
	DEFAULT_SECTOR_BLOCKS_LABEL_COLOR("default_sector_blocks_label_color"),
	DEFAULT_SECTOR_BLOCKS_LABEL_SIZE("default_sector_blocks_label_size"),	
	
	DEFAULT_SDE_PARCELS_LINE_THICK_KEY("default_sde_parcels_line_thick"),
	DEFAULT_SDE_PARCELS_LINE_RGBA_KEY("default_sde_parcels_line_rgba"),
	DEFAULT_SDE_PARCELS_FILL_RGBA_KEY("default_sde_parcels_fill_rgba"),
	DEFAULT_SDE_PARCELS_LABEL_COLOR("default_sde_parcels_label_color"),
	DEFAULT_SDE_PARCELS_LABEL_SIZE("default_sde_parcels_label_size"),
	
	DEFAULT_AREAS_LINE_THICK_KEY("default_areas_line_thick"),
	DEFAULT_AREAS_LINE_RGBA_KEY("default_areas_line_rgba"),
	DEFAULT_AREAS_FILL_RGBA_KEY("default_areas_fill_rgba"),
	DEFAULT_AREAS_LABEL_COLOR("default_areas_label_color"),
	DEFAULT_AREAS_LABEL_SIZE("default_areas_label_size"), 
	FL_CALC_THIRD_SESSION_LEVEL_KEY("fl_calc_third_session_level"), 
	FL_ALLOW_NULL_EDIT_CATEGORY("fl_allow_null_edit_category");
	
	private final String key;
	
	private InternalConfigKeys(String key) {
		this.key = key;
	}
	
	public String getKey() {
		return key;
	}
}
