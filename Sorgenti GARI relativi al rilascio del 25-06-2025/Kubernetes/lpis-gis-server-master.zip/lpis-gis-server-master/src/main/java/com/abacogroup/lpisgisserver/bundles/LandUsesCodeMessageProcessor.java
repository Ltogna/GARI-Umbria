package com.abacogroup.lpisgisserver.bundles;

import com.abacogroup.lpisgisserver.db.dao.DAOContainer;

public class LandUsesCodeMessageProcessor extends AbstractCodeMessageProcessor {

	private static final String TABLE_NAME = "lpis_landuses";
	private static final String FIELD_NAME = "code";

	public LandUsesCodeMessageProcessor(DAOContainer dc) {
		super(dc);
	}

	@Override
	public String getDomainName() {
		return "landuses-codes";
	}

	@Override
	public String getFieldName() {
		return FIELD_NAME;
	}

	@Override
	public String getTableName() {
		return TABLE_NAME;
	}

	@Override
	protected void checkCode(String tenantId, String code) {
		if (supportDAO.getLandUsesCodeByTenantAndCode(tenantId, code) == null) {
			supportDAO.insertLandUsesCode(tenantId, code);
		}
	}

	@Override
	protected void deleteCode(String tenantId, String code) {
		if (supportDAO.getLandUsesCodeByTenantAndCode(tenantId, code) != null) {
			supportDAO.deleteLandUseCode(tenantId, code);
		}
	}

}
