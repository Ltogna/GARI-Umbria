package com.abacogroup.lpisgisserver.core.exceptions.landcover;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class LandCoverGeometryNotValidPolygonException extends AbstractException {

	private static final long serialVersionUID = 4307870019092216846L;

	private static final ErrorCode ERROR_CODE = ErrorCode.LAND_COVER_GEOMETRY_NOT_A_VALID_POLYGON;

	public LandCoverGeometryNotValidPolygonException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new LandCoverGeometryNotValidPolygonExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Land cover geometry is not a polygon")
	public static class LandCoverGeometryNotValidPolygonExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 7128898526823284664L;

		public LandCoverGeometryNotValidPolygonExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}

	}
}
