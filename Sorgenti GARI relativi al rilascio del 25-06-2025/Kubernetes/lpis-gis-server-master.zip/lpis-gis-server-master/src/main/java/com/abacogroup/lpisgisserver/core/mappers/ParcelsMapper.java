package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.ParcelNTT;
import com.abacogroup.lpisgisserver.resources.res.Parcel;
import com.abacogroup.lpisgisserver.resources.res.ParcelWithErrors;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ParcelsMapper {

	ParcelsMapper INSTANCE = Mappers.getMapper(ParcelsMapper.class);

	@InheritInverseConfiguration()
	@Mapping(target = "total_land_covers_area_sqm", ignore = true)
	@Mapping(target = "sde_found_codes", ignore = true)
	@Mapping(target = "client_ref", ignore = true)
	@Mapping(target = "previous_id", ignore = true)
	Parcel entityToDto(ParcelNTT entity);
	
	@InheritInverseConfiguration()
	@Mapping(target = "total_land_covers_area_sqm", ignore = true)
	@Mapping(target = "sde_found_codes", ignore = true)
	@Mapping(target = "client_ref", ignore = true)
	@Mapping(target = "previous_id", ignore = true)
	@Mapping(target = "errorList", ignore = true)
	@Mapping(target = "landCovers", ignore = true)
	ParcelWithErrors entityToDtoWithErrors(ParcelNTT entity);

	@Mapping(source = "id", target = "parcel_id")
	@Mapping(source = "details_id", target = "pkid")
	@Mapping(target = "edit_id", ignore = true)
	@Mapping(target = "tenant_id", ignore = true)
	@Mapping(source = "sector.sector_code", target = "sector.sector")
	@Mapping(target = "sector.sector_details_id", ignore = true)
	@Mapping(source = "block.block_code", target = "block.block")
	@Mapping(target = "block.block_details_id", ignore = true)
	@Mapping(target = "stack.id", ignore = true)
	@Mapping(target = "stack.tenant_id", ignore = true)
	@Mapping(target = "editorResultParcelId", ignore = true)
	ParcelNTT dtoToEntity(Parcel dto);

}
