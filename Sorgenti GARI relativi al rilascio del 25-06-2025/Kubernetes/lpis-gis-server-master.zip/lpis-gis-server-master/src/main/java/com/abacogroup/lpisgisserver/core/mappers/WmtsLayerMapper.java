package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.resources.res.layers.WmtsLayer;
import com.abacogroup.lpisgisserver.resources.res.pub.WmtsLayerV1;

@Mapper
public interface WmtsLayerMapper {

	WmtsLayerMapper INSTANCE = Mappers.getMapper(WmtsLayerMapper.class);

	@Mapping(target = "snapElementType", ignore = true)
	@Mapping(target = "layerType", source = "publicLayerType")
	WmtsLayer mapToWmtsLayer(WmtsLayerV1 layer);

	@Mapping(target = "code", ignore = true)
	@Mapping(target = "publicLayerType", source = "layerType")
	WmtsLayerV1 mapToWmtsLayerV1(WmtsLayer layer);
}
