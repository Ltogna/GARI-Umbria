package com.abacogroup.lpisgisserver.core.mappers.units;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.units.CultivationStatusNTT;
import com.abacogroup.lpisgisserver.resources.res.units.CultivationStatus;

@Mapper
public interface CultivationStatusMapper {

	CultivationStatusMapper INSTANCE = Mappers.getMapper(CultivationStatusMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "visible", expression = "java(entity.getFlVisible() == null ? null : entity.getFlVisible() == 1)")
	CultivationStatus entityToDto(CultivationStatusNTT entity);
	
	@Mapping(target = "flVisible", expression = "java(dto.getVisible() ? 1 : 0)")
	@Mapping(target = "typeCode", ignore = true)
	CultivationStatusNTT dtoToEntity(CultivationStatus dto);
}
