package com.abacogroup.lpisgisserver.core;

import java.util.List;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.sector.SectorIdsNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.sector.SectorNotFoundException;
import com.abacogroup.lpisgisserver.core.mappers.SectorMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.SectorDAO;
import com.abacogroup.lpisgisserver.db.ntt.SectorNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.Sector;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SectorService extends BaseService {

	private SectorDAO sectorDAO;

	public SectorService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService,
			StyleService styleService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);
		sectorDAO = dc.getSectorDAO();
	}

	/**
	* Get Sector details by sector id. This method is used to get details of a sector. The details are returned as a Sector object
	* 
	* @param env - service support environment for obtaining tenant id
	* @param sectorId - sector id to be retrieved. It is required that the Tenant is set in the environment
	* 
	* @return Sector object with details
	*/
	public Sector getSectorDetailsBySectorId(ServiceSupportEnv env, Long sectorId) {

		SectorNTT sector = sectorDAO.findSectorDetailsByTenantAndId(env.getTenantId(), sectorId);
		// If sector is null throw an exception.
		if (sector == null) {
			SectorIdsNotFoundException ex = new SectorIdsNotFoundException(Status.NOT_FOUND, Operation.GET_SECTOR, ErrorField.SECTOR_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		return Sector.builder()
				.description(sector.getDescription())
				.geom(sector.getGeom())
				.id(sector.getId())
				.sector_code(sector.getSector())
				.short_descr(sector.getShort_descr())
				.srs(sector.getSrs())
				.world_geom(sector.getGeom())
				.build();
	}

	/**
	* Get Sectors with filter. This method is used for listing sectors that belong to a tenant.
	* 
	* @param tenantId - Tenant to search sectors for. Can be null if you don't want to filter by tenant
	* @param filter - Filter to use for finding sectors
	* @param nextKey - Next key to use for pagination. If null or empty will use default key.
	* 
	* @return InfiniteListResults of Sector objects. Never null but may be empty if there are no results
	*/
	public InfiniteListResults<Sector> getSectorsWithFilter(ServiceSupportEnv env, String filter, List<String> sectorCodes) {

		return this.sectorDAO.infinite(
				() -> sectorDAO.findSectorsByTenantWithFilter(env, filter, sectorCodes),
				env.getNextKey(),
				env.getPageSize())
				.map(SectorMapper.INSTANCE::entityToDto);
	}
	
	public Sector getSectorDetailsByTenantAndCode(ServiceSupportEnv env, String code) {
		SectorNTT sectorNTT = sectorDAO.findSectorDetailsByTenantAndCode(env, code);
		if(sectorNTT == null) {
			SectorNotFoundException ex = new SectorNotFoundException(Status.NOT_FOUND, Operation.GET_SECTOR, ErrorField.SECTOR_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.warn(ex.getBody().getLogErrorMessage());
			
			throw ex;
		}
		return SectorMapper.INSTANCE.entityToDto(sectorNTT);
	}
}
