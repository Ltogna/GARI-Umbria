package com.abacogroup.lpisgisserver.bundles.models;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SectorAreaMessage {
	private String area_code;
	private String sector_code;
	private AbsoluteDate day_from;
	private AbsoluteDate day_to;
}
