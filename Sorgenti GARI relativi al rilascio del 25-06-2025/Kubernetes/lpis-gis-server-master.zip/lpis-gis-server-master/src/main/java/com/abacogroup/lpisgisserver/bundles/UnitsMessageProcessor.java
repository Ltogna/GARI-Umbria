package com.abacogroup.lpisgisserver.bundles;

import java.io.File;
import java.nio.file.Path;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.lpisgisserver.bundles.models.LandCoverUnitTypeListMessage;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.SupportDAO;
import com.abacogroup.lpisgisserver.db.dao.UnitsDAO;
import com.abacogroup.lpisgisserver.db.ntt.units.LandCoverUnitTypeNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UnitsMessageProcessor extends AbstractMessageProcessor {

	protected UnitsDAO unitsDAO;
	protected SupportDAO supportDAO;

	private final ObjectMapper objectMapper;

	private static final Logger log = LoggerFactory.getLogger(UnitsMessageProcessor.class);

	public UnitsMessageProcessor(DAOContainer dc) {
		super(dc);
		this.unitsDAO = dc.getUnitsDAO();
		this.supportDAO = dc.getSupportDAO();

		objectMapper = new ObjectMapper();
	}

	@Override
	public String getDomainName() {
		return "units";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> deleteLandCoverUnitTypeMessage(message.getTenantId(), file));

		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
				&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> insertOrUpdateLandCoverUnitTypeMessage(message.getTenantId(), file));
	}

	private void insertOrUpdateLandCoverUnitTypeMessage(String tenantId, File file) {
		try {
			LandCoverUnitTypeListMessage typeMessages = objectMapper.readValue(file, LandCoverUnitTypeListMessage.class);

			if (typeMessages == null) {
				return;
			}

			if(typeMessages.getLand_cover_unit_types() != null) {
				typeMessages.getLand_cover_unit_types().stream().forEach(message -> {
					try {

						if(supportDAO.getLandCoversCodeByTenantAndCode(tenantId, message.getLand_cover_code()) == null) {
							throw new IllegalStateException("Land cover code " + message.getLand_cover_code() + " not found");
						}

						ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).build();

						if(unitsDAO.checkLandCoverCompatibility(env, message.getLand_cover_code(), message.getType_code()) != 1) {
							LandCoverUnitTypeNTT typeNTT = LandCoverUnitTypeNTT.builder()
									.id(unitsDAO.nextLandCoverUnitTypeIdVal())
									.typeCode(message.getType_code())
									.landCoverCode(message.getLand_cover_code())
									.build();

							unitsDAO.insertLandCoverUnitType(env, typeNTT);
						}
					} catch (Exception e) {
						log.error("Error during insert/update operation of land cover unit type with land_cover_code {} and type_code {} with tenant {} : {}", message.getLand_cover_code(), message.getType_code(), tenantId, e);
					}
				});
			}
		} catch (Exception e) {
			log.error("Error processing file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}
	}
	
	private void deleteLandCoverUnitTypeMessage(String tenantId, File file) {
		try {
			LandCoverUnitTypeListMessage typeMessages = objectMapper.readValue(file, LandCoverUnitTypeListMessage.class);

			if (typeMessages == null) {
				return;
			}

			if(typeMessages.getLand_cover_unit_types() != null) {
				typeMessages.getLand_cover_unit_types().stream().forEach(message -> {
					try {
						if(supportDAO.getLandCoversCodeByTenantAndCode(tenantId, message.getLand_cover_code()) == null) {
							throw new IllegalStateException("Land cover code " + message.getLand_cover_code() + " not found");
						}

						ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).build();
						
						if(unitsDAO.checkLandCoverCompatibility(env, message.getLand_cover_code(), message.getType_code()) == 1) {
							LandCoverUnitTypeNTT typeToDelete = LandCoverUnitTypeNTT.builder()
									.typeCode(message.getType_code())
									.landCoverCode(message.getLand_cover_code())
									.build();

							unitsDAO.deleteLandCoverUnitTypeByLandCoverCodeAndTypeCode(env, typeToDelete);
						}
					} catch (Exception e) {
						log.error("Error during delete operation of land cover unit type with land_cover_code {} and type_code {} with tenant {} : {}", message.getLand_cover_code(), message.getType_code(), tenantId, e);
					}
				});
			}
		} catch (Exception e) {
			log.error("Error processing file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}
	}

}
