package com.abacogroup.lpisgisserver.core.pub;

import com.abacogroup.lpisgisserver.core.AdditionalLayersService;
import com.abacogroup.lpisgisserver.core.BaseService;
import com.abacogroup.lpisgisserver.core.ErrorDescriptionsService;
import com.abacogroup.lpisgisserver.core.ExternalConfigService;
import com.abacogroup.lpisgisserver.core.InternalConfigService;
import com.abacogroup.lpisgisserver.core.StyleService;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.pub.AdditionalLayersListV1;

public class AdditionalLayersV1Service extends BaseService {
	
	private AdditionalLayersService additionalLayersService;
	
	public AdditionalLayersV1Service(DAOContainer dc, AdditionalLayersService additionalLayersService, InternalConfigService internalConf,
			ExternalConfigService externalConf, ErrorDescriptionsService errorDescriptionsService,
			StyleService styleService, PluginEnvironment pluginEnvironment) {
		
		super(dc, internalConf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);
		this.additionalLayersService = additionalLayersService;
	}
	
	public AdditionalLayersListV1 getAdditionalLayers(ServiceSupportEnv env, String module, Integer foregroundLevel) {
		
		return additionalLayersService.getAdditionalLayersInternal(env, module, foregroundLevel);
	}

}
