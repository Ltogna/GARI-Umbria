package com.abacogroup.lpisgisserver.db.dao;

import java.util.function.Consumer;

import org.jdbi.v3.core.mapper.reflect.BeanMapper;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.lpisgisserver.db.ntt.UpdateGeomNTT;

public interface InternalDAO extends Transactional<InternalDAO>, EnhancedSqlObject {

	default void updateWorldGeom(String tenantId, String tableName, UpdateGeomNTT updateGeomNTT){
		String sql = "update " + tableName + " set world_geom = :world_geom where pkid = :pkid";
		
		withHandle(h -> 
		h.createUpdate(sql)
		.bind("tenantId", tenantId)
		.bindBean(updateGeomNTT)
		.execute());
	}
	
	default void getGeoms(String tenantId, String query, Consumer<UpdateGeomNTT> consumer) {
		withHandle(h -> 
		h.createQuery(query)
		.bind("tenantId", tenantId)
		.registerRowMapper(BeanMapper.factory(UpdateGeomNTT.class))
		.mapTo(UpdateGeomNTT.class)
		.forEachWithCount(consumer::accept));
	}
}
