package com.abacogroup.lpisgisserver.bundles.models;

import com.abacogroup.lpisgisserver.core.enums.AnomalyLevel;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnomalyCategoriesMessage {
	private String group_code;
	private String code;
	private AnomalyLevel level;
	private Boolean fl_exclude;
}
