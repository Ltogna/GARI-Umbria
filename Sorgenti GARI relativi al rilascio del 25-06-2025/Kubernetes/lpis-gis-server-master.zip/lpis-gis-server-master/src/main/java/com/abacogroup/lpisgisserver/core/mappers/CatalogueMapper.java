package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.CatalogueNTT;
import com.abacogroup.lpisgisserver.resources.res.Catalogue;

@Mapper
public interface CatalogueMapper {
	CatalogueMapper INSTANCE = Mappers.getMapper(CatalogueMapper.class);
	
	@InheritInverseConfiguration
	Catalogue entityToDto(CatalogueNTT entity);

	@Mapping(target = "flVisible", ignore = true)
	@Mapping(target = "type", ignore = true)
	@Mapping(target = "params", ignore = true)
	CatalogueNTT dtoToEntity(Catalogue dto);
}