package com.abacogroup.lpisgisserver.core;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.WMSLayersDAO;
import com.abacogroup.lpisgisserver.db.ntt.WmsDefinitionNTT;
import com.abacogroup.lpisgisserver.resources.res.LayerStyle;

public class StyleService {

	private WMSLayersDAO wmsLayersDAO;
	private InternalConfigService internalConf;

	public StyleService(DAOContainer dc, InternalConfigService internalConf) {

		this.wmsLayersDAO = dc.getWMSLayersDAO();

		this.internalConf = internalConf;
	}

	/**
	* Returns layer style for land cover. It is possible to specify matrix code and fill / line / thick values from configuration or default values
	* 
	* @param tenantId - Tenant ID for which to get configuration
	* @param referenceDate - Reference date for which to get configuration
	* @param landCoverCode - Land cover style code. If null or empty will return default values
	* 
	* @return LayerStyle for given land cover or default values from configuration or default values from tenantId and referenceDate
	*/
	public LayerStyle getLandCoverLayerStyle(String tenantId, AbsoluteDate referenceDate, String landCoverCode) {
		String fillRgba = internalConf.getStringValue(tenantId, InternalConfigKeys.DEFAULT_LANDCOVERS_FILL_RGBA_KEY.getKey());
		String lineRgba = internalConf.getStringValue(tenantId, InternalConfigKeys.DEFAULT_LANDCOVERS_LINE_RGBA_KEY.getKey());
		Integer lineThick = internalConf.getIntegerValue(tenantId, InternalConfigKeys.DEFAULT_LANDCOVERS_LINE_THICK_KEY.getKey());

		String matrixCode = internalConf.getStringValue(tenantId, InternalConfigKeys.DEFAULT_LANDCOVERS_STYLE_MATRIX_CODE_KEY.getKey());
		
		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.landCoverStyleMatrixCode(matrixCode)
				.defaultLCFillRGBA(fillRgba)
				.defaultLCLineRGBA(lineRgba)
				.defaultLCLineThick(lineThick)
				.build();
		
		// Returns the fill color and line color values for the landCover code.
		if (StringUtils.isNotBlank(matrixCode) && StringUtils.isNotBlank(landCoverCode)) {
			List<WmsDefinitionNTT> matrixLandCoverStyle = 
					wmsLayersDAO.getLandCoverLayerStylesFromMatrixCodeAndLandCoverCode(env, landCoverCode);

			// Set the fill and line color values for the land cover.
			if (matrixLandCoverStyle != null && !matrixLandCoverStyle.isEmpty()) {
				fillRgba = matrixLandCoverStyle.get(0).getFillRGBA();
				lineRgba = matrixLandCoverStyle.get(0).getLineRGBA();
				lineThick = matrixLandCoverStyle.get(0).getLineThick();
			}
		}

		return LayerStyle.builder().fill_rgba(fillRgba).line_rgba(lineRgba).line_thick(lineThick).build();
	}
}
