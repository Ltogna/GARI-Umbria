package com.abacogroup.lpisgisserver.core;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.parcel.GenericParcelException;
import com.abacogroup.lpisgisserver.core.exceptions.sector.SectorNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.support.InvalidSrsException;
import com.abacogroup.lpisgisserver.core.mappers.WmsLayerMapper;
import com.abacogroup.lpisgisserver.core.mappers.WmtsLayerMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.AdditionalLayersDAO;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.ExternalSourceDataDAO;
import com.abacogroup.lpisgisserver.db.dao.SectorDAO;
import com.abacogroup.lpisgisserver.db.ntt.AdditionalLayerNTT;
import com.abacogroup.lpisgisserver.db.ntt.ExternalSourceNTT;
import com.abacogroup.lpisgisserver.db.ntt.SectorNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.AdditionalLayersList;
import com.abacogroup.lpisgisserver.resources.res.layers.AdditionalLayer;
import com.abacogroup.lpisgisserver.resources.res.layers.LayerType;
import com.abacogroup.lpisgisserver.resources.res.layers.WmsLayer;
import com.abacogroup.lpisgisserver.resources.res.pub.AdditionalLayersListV1;
import com.abacogroup.lpisgisserver.resources.res.pub.WmsLayerV1;
import com.abacogroup.lpisgisserver.resources.res.pub.WmtsLayerV1;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AdditionalLayersService extends BaseService {

	private SectorDAO sectorDAO;
	private AdditionalLayersDAO additionalLayersDAO;
	private ExternalSourceDataDAO externalSourceDataDAO;
	
	private static final String SDE_PREFIX = "SDE:";

	public AdditionalLayersService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);
		this.sectorDAO = dc.getSectorDAO();
		this.additionalLayersDAO = dc.getAdditionalLayersDAO();
		this.externalSourceDataDAO = dc.getExternalSourceDataDAO();
	}

	/**
	* for private api Get additional layers for a module. This method is used by WMS and WMTS to get additional layers for a module
	* Now manage only WMTS, WMS and TILEDWMS server types
	* 
	* @param env - ServiceSupportEnv in which we are querying
	* @param module - Module to get additional layers for. Can be any string
	* @param foregroundLevel - Fourth level of foreground.
	 * @param includeSdeLayers 
	* 
	* @return List of additional layers for the module. Empty if there are no additional layers for the module or foreground
	*/
	public AdditionalLayersList getAdditionalLayers(ServiceSupportEnv env, String module, Integer foregroundLevel, Boolean includeSdeLayers) {
		
		AdditionalLayersListV1 layersFromTenantAndLang = getAdditionalLayersInternal(env, module, foregroundLevel);
		List<AdditionalLayer> layers = new ArrayList<>();

		layers.addAll(layersFromTenantAndLang.getWmsLayers().stream()
		.map(WmsLayerMapper.INSTANCE::mapToWmsLayer)
		.collect(Collectors.toList()));
		
		layers.addAll(layersFromTenantAndLang.getWmtsLayers().stream()
				.map(WmtsLayerMapper.INSTANCE::mapToWmtsLayer)
				.collect(Collectors.toList()));
		
		if(Boolean.TRUE.equals(includeSdeLayers)) {
			layers.addAll(getSdeLayers(env));
		}

		// Re-Sort layers 
		layers.sort((l1, l2) -> l1.getLegendOrder() > l2.getLegendOrder() ? 1 : -1);
		
		return AdditionalLayersList.builder()
				.additional_layers(layers)
				.build();
	}

	/**
	* Get additional layers for a module. This is the method that is called by the ParcelService.
	* 
	* @param env - The environment to get the additional layers for.
	* @param module - The module to get the additional layers for.
	* @param foregroundLevel - The foreground level to set. If null the foreground level will be set to default.
	* 
	* @return The additional layers or null if none found in the database. Note that the foreground level is only set if there is at least one layer
	*/
	public AdditionalLayersListV1 getAdditionalLayersInternal(ServiceSupportEnv env, String module, Integer foregroundLevel){
		// If env is null the request is not a valid request.
		if(env == null) {
			GenericParcelException ex = new GenericParcelException(Status.BAD_REQUEST, Operation.GET_ADDITIONAL_LAYERS, ErrorField.REQUEST,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), "en");

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		SectorNTT sectorNTT = env.getSectorId() == null ? sectorDAO.findSectorDetailsByTenantAndCode(env, env.getSectorCode())
				: sectorDAO.findSectorDetailsByTenantAndId(env.getTenantId(), env.getSectorId());

		// if sectorNTT is null then set sectorId to the sectorNTT.
		if (sectorNTT == null) {
			SectorNotFoundException ex = new SectorNotFoundException(Status.NOT_FOUND, Operation.GET_ADDITIONAL_LAYERS, ErrorField.SECTOR_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.warn(ex.getBody().getLogErrorMessage());

			// if sector does not exist, continue anyway
		} else {
			env.setSectorId(sectorNTT.getId());
		}

		// Set the SRS to the given SRS.
		if (StringUtils.isBlank(env.getSrs())) {

			// If the sectorNTT is null the request is not allowed to be processed.
			if (sectorNTT == null) {
				InvalidSrsException ex = new InvalidSrsException(Status.BAD_REQUEST, Operation.GET_ADDITIONAL_LAYERS, ErrorField.SRS,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

				log.error(ex.getBody().getLogErrorMessage());

				throw ex;
			}
			
			env.setSrs(sectorNTT.getSrs());
		}
		
		List<AdditionalLayerNTT> layersFromTenantAndLang = additionalLayersDAO.getAdditionalLayers(env, module, foregroundLevel);
		
		return buildAdditionalLayersListV1FromList(layersFromTenantAndLang);
	}

	/**
	* Builds additional wms layer list from DB data. This method is used for converting the list of NTTs into list of WmsLayerV1 objects
	* Now manage only WMTS, WMS and TILEDWMS server types
	* 
	* @param additionalLayers - list of additional layers to convert
	* 
	* @return additional layers converted to WMTS layer list for use in V1 API or null if there is
	*/
	private AdditionalLayersListV1 buildAdditionalLayersListV1FromList(List<AdditionalLayerNTT> additionalLayers) {
		List<WmsLayerV1> wmsLayers = new ArrayList<>();
		List<WmtsLayerV1> wmtsLayers = new ArrayList<>();

		int orderIndex = 0;

		for (AdditionalLayerNTT c : additionalLayers) {
			// Returns the layer type of the layer.
			switch (c.getLayerType() != null ? c.getLayerType() : LayerType.ERROR) {
			case WMS, TILEDWMS:
				wmsLayers.add(buildWmsLayer(orderIndex, c));
				break;

			case WMTS:
				wmtsLayers.add(buildWmtsLayer(orderIndex, c));
				break;

			case ERROR:
			default:
				log.warn("Found additional layer type not WMS or WMTS or TILEDWMS: id:{}, name: '{}', type: '{}'", c.getLayer_id(), c.getLayer_name(),
						c.getLayerType());
			}

			orderIndex++;
		}

		return AdditionalLayersListV1.builder()
				.wmsLayers(wmsLayers)
				.wmtsLayers(wmtsLayers)
				.build();
	}

	private WmtsLayerV1 buildWmtsLayer(int orderIndex, AdditionalLayerNTT c) {
		String[] url = c.getUrl().split(";");
		return WmtsLayerV1.builder()
				.code(c.getCode())
				.legendOrder(orderIndex)
				.url(url[0])
				.tileMatrixSet(url.length > 1 ? url[1] : null)
				.tileMatrix(c.getSrs())
				.layer(c.getLayer())
				.srs(c.getSrs())
				.format(c.getFormat())
				.style(null)
				.foregroundLevel(c.getForegroundLevel())
				.description(c.getDescription())
				.minResolution(null)
				.maxResolution(c.getMaxPixelVal())
				.on(c.getFlVisible())
				.enabledInOverview(c.getFlVisible())
				.layer_id(c.getLayer_id())
				.layerOptions(c.getLayerOptions())
				.serverConfig(c.getServer_config())
				.publicLayerType(c.getLayerType())
				.path(c.getPath())
				.catalogueCode(c.getCatalogueCode())
				.infoCatalogueCode(c.getInfoCatalogueCode())
				.uniqueCode(c.getUniqueCode())
				.build();
	}

	private WmsLayerV1 buildWmsLayer(int orderIndex, AdditionalLayerNTT c) {
		return WmsLayerV1.builder()
				.code(c.getCode())
				.legendOrder(orderIndex)
				.url(c.getUrl())
				.layers(c.getLayer())
				.srs(c.getSrs())
				.format(c.getFormat())
				.bgcolor(c.getBgcolor())
				.styles(null)
				.transparent(c.getFlTransparent())
				.foregroundLevel(c.getForegroundLevel())
				.description(c.getDescription())
				.minResolution(null)
				.maxResolution(c.getMaxPixelVal())
				.on(c.getFlVisible())
				.enabledInOverview(c.getFlVisible())
				.layer_id(c.getLayer_id())
				.layerOptions(c.getLayerOptions())
				.serverConfig(c.getServer_config())
				.publicLayerType(c.getLayerType())
				.path(c.getPath())
				.catalogueCode(c.getCatalogueCode())
				.infoCatalogueCode(c.getInfoCatalogueCode())
				.uniqueCode(c.getUniqueCode())
				.build();
	}

	
	private List<AdditionalLayer> getSdeLayers(ServiceSupportEnv env) {
		
		List<ExternalSourceNTT> sdeList = externalSourceDataDAO.findExternalSourceCodeByTenantAndSrs(env, env.getSrs());
		
		List<AdditionalLayer> sdeLayers = new ArrayList<>();
		sdeList.stream().forEach(sde -> {
		
		WmsLayer layer = WmsLayer.builder()
				.layer_id(sde.getExternalSourceCode())
				.description(sde.getExternalSourceDescription())
				.maxResolution(null)
				.minResolution(null)
				.on(false)
				.enabledInOverview(false)
				.foregroundLevel(1)
				.srs(env.getSrs())
				.legendOrder(0)
				.layerOptions(null)
				.serverConfig(null)
				.layerType(LayerType.WMS)
				.catalogueCode(SDE_PREFIX + sde.getExternalSourceCode())
				.uniqueCode(sde.getLayerUniqueCode())
				.url("/lpis-server-api/wms?tenant=" + env.getTenantId() + "&sde_code=" + sde.getExternalSourceCode() + "&srs=" + env.getSrs())
				.layers("SDE")
				.styles(null)
				.bgcolor(null)
				.version("1.3.0")
				.transparent(true)
				.format("image/png")
				.build();
		
		sdeLayers.add(layer);
		});
		
		return sdeLayers;
	}

}
