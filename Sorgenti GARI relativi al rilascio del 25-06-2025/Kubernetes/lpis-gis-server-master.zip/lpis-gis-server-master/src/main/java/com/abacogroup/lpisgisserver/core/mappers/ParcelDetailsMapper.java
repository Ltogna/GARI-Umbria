package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.db.ntt.ParcelDetailsNTT;
import com.abacogroup.lpisgisserver.resources.res.farmland.ParcelDetails;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ParcelDetailsMapper {

	ParcelDetailsMapper INSTANCE = Mappers.getMapper(ParcelDetailsMapper.class);

	@InheritInverseConfiguration()
	@Mapping(target = "parcel_code", ignore = true)
	@Mapping(target = "landcover_details_list", ignore = true)
	ParcelDetails entityToDto(ParcelDetailsNTT entity);

	@Mapping(target = "srs", ignore = true)
	@Mapping(target = "geom", ignore = true)
	@Mapping(target = "pkid", ignore = true)
	@Mapping(target = "edit_status", ignore = true) // Could be interesting for client side?
	ParcelDetailsNTT dtoToEntity(ParcelDetails dto);
}
