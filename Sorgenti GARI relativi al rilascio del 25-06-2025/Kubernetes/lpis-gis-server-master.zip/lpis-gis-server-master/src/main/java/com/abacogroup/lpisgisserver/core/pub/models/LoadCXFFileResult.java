package com.abacogroup.lpisgisserver.core.pub.models;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class LoadCXFFileResult {
	String fileName;
	String sdeCode;
	List<CXFParcelImportResult> successParcelsImport;
	List<CXFParcelImportResult> failedParcelsImport;
}
