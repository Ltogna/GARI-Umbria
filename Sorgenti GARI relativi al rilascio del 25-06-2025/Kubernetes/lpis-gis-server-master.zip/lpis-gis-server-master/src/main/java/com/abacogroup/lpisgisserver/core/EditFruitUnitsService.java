package com.abacogroup.lpisgisserver.core;

import java.util.ArrayList;
import java.util.List;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.ErrorItem;
import com.abacogroup.lpisgisserver.core.exceptions.InvalidFormException;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.LandCoverNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.units.fruit.FruitUnitIdNotValidException;
import com.abacogroup.lpisgisserver.core.exceptions.units.fruit.FruitUnitNotEditableException;
import com.abacogroup.lpisgisserver.core.exceptions.units.fruit.FruitUnitNotFoundException;
import com.abacogroup.lpisgisserver.core.support.EditorSupportParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditLandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.EditFruitUnitsDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.fruit.FruitUnitDetailsNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.pub.CreateOrUpdateFruitUnitPayloadV1;
import com.abacogroup.lpisgisserver.resources.res.units.fruit.FruitUnit;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EditFruitUnitsService extends BaseService {
	
	private final EditLandCoversDAO editLandCoversDAO;
	private final EditFruitUnitsDAO editFruitUnitsDAO;

	private final EditLandCoversSupportService editLandCoversSupportService;
	private final EditFruitUnitsSupportService editFruitUnitsSupportService;
	private final EditUnitsSupportService editUnitsSupportService;

	private static final UnitType UNIT_TYPE = UnitType.FRUIT_UNIT;
	private static final boolean SKIP_FORBIDDEN_LC_CHECK = true;

	public EditFruitUnitsService(DAOContainer dc, InternalConfigService conf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService,
			EditLandCoversSupportService editLandCoversSupportService, EditFruitUnitsSupportService editFruitUnitsSupportService, 
			EditUnitsSupportService editUnitsSupportService, PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.editLandCoversDAO = dc.getEditLandCoversDAO();
		this.editFruitUnitsDAO = dc.getEditFruitUnitsDAO();

		this.editLandCoversSupportService = editLandCoversSupportService;
		this.editFruitUnitsSupportService = editFruitUnitsSupportService;
		this.editUnitsSupportService = editUnitsSupportService;
	}

	public FruitUnit createFruitUnits(EditorSupportParams params, @NotNull @Valid CreateOrUpdateFruitUnitPayloadV1 payload) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		
		List<ErrorItem> errorList = new ArrayList<>();
		internalCheckCreateOrUpdateFruitUnitPayload(params, env, payload, errorList);
		
		LandCoverNTT landCoverNTT = getLandCoverNTT(env, params.getParcelId(), params.getLandCoverId(), params.getOperation());
		editFruitUnitsSupportService.checkFruitUnitValidationDates(env, payload, landCoverNTT, null, errorList);
		
		if(!errorList.isEmpty()) {
			InvalidFormException ex = new InvalidFormException(Status.BAD_REQUEST, params.getOperation(), ErrorField.FORM,
					errorList, this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		Long editId = editFruitUnitsDAO.nextEditFruitUnitDetailPkidVal();
		Long newUnitId = editFruitUnitsDAO.nextNewFruitUnitIdVal();
		String unitCode = payload.getUnitCode() != null ? payload.getUnitCode() : getNewUnitCode(env, UNIT_TYPE);
		FruitUnitDetailsNTT fruitUnitToInsert = editFruitUnitsSupportService.buildFruitUnitDetailsNTTFromPayload(payload, editId,
				landCoverNTT.getEdit_id(), newUnitId, unitCode, EditStatus.IN_EDIT, 1, null);

		editFruitUnitsDAO.insertEditFruitUnitDetail(env, fruitUnitToInsert);

		params.setFruitUnitId(newUnitId);
		return getFruitUnits(params).get(0);
	}

	public FruitUnit updateFruitUnits(EditorSupportParams params, @NotNull @Valid CreateOrUpdateFruitUnitPayloadV1 payload) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		
		List<ErrorItem> errorList = new ArrayList<>();
		internalCheckCreateOrUpdateFruitUnitPayload(params, env, payload, errorList);
		
		LandCoverNTT landCoverNTT = getLandCoverNTT(env, params.getParcelId(), params.getLandCoverId(), params.getOperation());
		FruitUnitDetailsNTT inEditUnit = editFruitUnitsDAO.findInEditFruitUnitsBySessionId(env, params.getLandCoverId(), params.getFruitUnitId(), null).get(0);
		
		//check if editable
		if(inEditUnit.getPlantingDay().toLocalDate().isAfter(env.getReferenceDate().toLocalDate()) 
				|| inEditUnit.getEradicateDay().toLocalDate().isBefore(env.getReferenceDate().toLocalDate())) {			
			FruitUnitNotEditableException ex = new FruitUnitNotEditableException(Status.BAD_REQUEST, params.getOperation(), 
					ErrorField.PAYLOAD, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		editFruitUnitsSupportService.checkFruitUnitValidationDates(env, payload, landCoverNTT, inEditUnit, errorList);

		if(!errorList.isEmpty()) {
			InvalidFormException ex = new InvalidFormException(Status.BAD_REQUEST, params.getOperation(), ErrorField.FORM,
					errorList, this.errorDescriptionsService.getTenantErrorDescriptions(params.getSession().getTenant_id()), params.getReqContext().getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		FruitUnitDetailsNTT fruitUnitToUpdate =  editFruitUnitsSupportService.buildFruitUnitDetailsNTTFromPayload(payload, inEditUnit.getEditId(), 
				inEditUnit.getEditLandCoverId(), inEditUnit.getUnitId(), inEditUnit.getUnitCode(), EditStatus.IN_EDIT, inEditUnit.getFlDeletable(),
				inEditUnit.getParentUnitCode());
		
		editFruitUnitsDAO.updateEditFruitUnitDetail(env.getSessionId(), fruitUnitToUpdate);

		return getFruitUnits(params).get(0);
	}

	public List<FruitUnit> getFruitUnits(EditorSupportParams params) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()), SKIP_FORBIDDEN_LC_CHECK);
		editUnitsSupportService.checkLandCoverCodeCompatibility(env, params.getParcelId(), params.getLandCoverId(), UNIT_TYPE, params.getOperation());

		return editFruitUnitsSupportService.internalGetFruitUnits(params, params.getLandCoverId(), params.getFruitUnitId());
	}

	public Response deleteFruitUnitById(EditorSupportParams params) {
		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()));
		editUnitsSupportService.checkLandCoverCodeCompatibility(env, params.getParcelId(), params.getLandCoverId(), UNIT_TYPE, params.getOperation());
		editFruitUnitsSupportService.checkAndInsertEditParcelLandCoversFruitUnit(params);

		Long fruitUnitId = params.getFruitUnitId();
		if(fruitUnitId == null || !editFruitUnitsSupportService.isDeletable(env, params.getLandCoverId(), fruitUnitId)) {
			FruitUnitIdNotValidException ex = new FruitUnitIdNotValidException(Status.BAD_REQUEST, params.getOperation(), 
					ErrorField.UNIT_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}

		editFruitUnitsDAO.deleteFruitUnitsById(env.getSessionId(), fruitUnitId);

		return Response.ok().build();
	}
	
	public Response eradicateFruitUnits(EditorSupportParams params) {

		ServiceSupportEnv env = checkAndBuildServiceSupportEnv(params);
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()));
		editFruitUnitsSupportService.checkAndInsertEditParcelLandCoversFruitUnit(params);
		
		AbsoluteDate newEradicateDay = env.getReferenceDate();
		
		FruitUnitDetailsNTT inEditUnit = editFruitUnitsDAO.findInEditFruitUnitsBySessionId(env, params.getLandCoverId(), params.getFruitUnitId(), null).get(0);

		//check if editable
		if(inEditUnit.getPlantingDay().toLocalDate().isAfter(env.getReferenceDate().toLocalDate()) 
				|| inEditUnit.getEradicateDay().toLocalDate().isBefore(env.getReferenceDate().toLocalDate())) {
			FruitUnitNotFoundException ex = new FruitUnitNotFoundException(Status.BAD_REQUEST, params.getOperation(), 
					ErrorField.PAYLOAD, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		inEditUnit.setEradicateDay(newEradicateDay);
		inEditUnit.setEditStatus(EditStatus.IN_EDIT);

		editFruitUnitsDAO.updateEditFruitUnitDetail(env.getSessionId(), inEditUnit);

		return Response.ok().build(); 
	}

	private void internalCheckCreateOrUpdateFruitUnitPayload(EditorSupportParams params, ServiceSupportEnv env,
			CreateOrUpdateFruitUnitPayloadV1 payload, List<ErrorItem> errorList) {
		editLandCoversSupportService.checkCanEditLC(params, List.of(params.getLandCoverId()));
		editUnitsSupportService.checkLandCoverCodeCompatibility(env, params.getParcelId(), params.getLandCoverId(), UNIT_TYPE, params.getOperation());
		editFruitUnitsSupportService.checkCreateOrUpdateFruitUnitPayload(params, payload, errorList);
		editFruitUnitsSupportService.checkAndInsertEditParcelLandCoversFruitUnit(params);
	}

	private LandCoverNTT getLandCoverNTT(ServiceSupportEnv env, Long parcelId, Long landCoverId, Operation operation) {
		LandCoverNTT landCoverNTT = editLandCoversDAO.findInEditBySessionId(env, parcelId).stream()
				.filter(lc -> lc.getLand_cover_id().equals(landCoverId))
				.findFirst()
				.orElse(null);
	
		if(landCoverNTT == null) {
			LandCoverNotFoundException ex = new LandCoverNotFoundException(Status.NOT_FOUND, operation, ErrorField.LANDCOVER_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
	
			log.error(ex.getBody().getLogErrorMessage());
	
			throw ex;
		}
		return landCoverNTT;
	}

}
