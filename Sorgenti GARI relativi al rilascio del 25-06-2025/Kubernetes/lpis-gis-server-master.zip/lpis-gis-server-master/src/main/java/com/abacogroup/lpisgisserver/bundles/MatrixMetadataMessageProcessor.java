package com.abacogroup.lpisgisserver.bundles;

import java.io.File;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.lpisgisserver.bundles.models.MatrixClassMetadataMessage;
import com.abacogroup.lpisgisserver.bundles.models.MatrixLandCoverMetadataMessage;
import com.abacogroup.lpisgisserver.bundles.models.MatrixLandUseMetadataMessage;
import com.abacogroup.lpisgisserver.bundles.models.MatrixMetadataListMessage;
import com.abacogroup.lpisgisserver.bundles.models.MatrixMetadataMessage;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.MatrixClassMetadataDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixLandCoversMetadataDAO;
import com.abacogroup.lpisgisserver.db.dao.MatrixLandUsesMetadataDAO;
import com.abacogroup.lpisgisserver.db.ntt.MatrixClassMetadataNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixLandCoversMetadataNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixLandUsesMetadataNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MatrixMetadataMessageProcessor extends AbstractMessageProcessor {

	private final ObjectMapper objectMapper;

	private MatrixDAO matrixDAO;
	private MatrixClassMetadataDAO matrixClassMetadataDAO;
	private MatrixLandCoversMetadataDAO matrixLandCoversMetadataDAO;
	private MatrixLandUsesMetadataDAO matrixLandUsesMetadataDAO;

	private static final String USER = "importMatrixMetadataBundle";

	private static final Logger log = LoggerFactory.getLogger(MatrixMetadataMessageProcessor.class);

	public MatrixMetadataMessageProcessor(DAOContainer daoContainer) {
		super(daoContainer);
		objectMapper = new ObjectMapper();

		this.matrixDAO = daoContainer.getMatrixDAO();
		this.matrixClassMetadataDAO = daoContainer.getMatrixClassMetadataDAO();
		this.matrixLandCoversMetadataDAO = daoContainer.getMatrixLandCoversMetadataDAO();
		this.matrixLandUsesMetadataDAO = daoContainer.getMatrixLandUsesMetadataDAO();
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
				.forEach(file -> deleteMatrixMetadataMessage(message.getTenantId(), file));

		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
						&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
				.forEach(file -> insertOrUpdateMatrixMetadataMessage(message.getTenantId(), file));
	}

	@Override
	public String getDomainName() {
		return "matrix-metadata";
	}

	private void insertOrUpdateMatrixMetadataMessage(String tenantId, File file) {

		try {
			MatrixMetadataListMessage matrixMetadataListMessage = objectMapper.readValue(file, MatrixMetadataListMessage.class);

			if (matrixMetadataListMessage.getMatrix_metadata_list() != null) {
				matrixMetadataListMessage.getMatrix_metadata_list().forEach(matrixMetadataMessage -> {
					try {
						ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).user(new User(USER, tenantId)).build();
						List<MatrixNTT> matrixNTT = matrixDAO.findByCode(env, matrixMetadataMessage.getMatrix_code());
						if (matrixNTT.isEmpty()) {
							throw new IllegalArgumentException("Matrix code " + matrixMetadataMessage.getMatrix_code() + " not found!");
						}
						Long matrixId = matrixNTT.get(0).getId();

						insertOrUpdateMatrixMetadataMessageClassMetadata(tenantId, matrixMetadataMessage, matrixId);

						insertOrUpdateMatrixMetadataMessageLandcoverMetadata(tenantId, matrixMetadataMessage, matrixId);

						insertOrUpdateMatrixMetadataMessageLandUseMetadata(tenantId, matrixMetadataMessage, matrixId);

					} catch (Exception e) {
						log.error("Error during insert/update operation of metadata with matrix code {} for tenant {} : {}"
								+ matrixMetadataMessage.getMatrix_code(), tenantId, e);
					}

				});
			}

		} catch (Exception e) {
			log.error("Error processing file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}

	}

	private void insertOrUpdateMatrixMetadataMessageLandUseMetadata(String tenantId, MatrixMetadataMessage matrixMetadataMessage, Long matrixId) {
		if (matrixMetadataMessage.getLand_use_metadata_list() != null) {
			for (MatrixLandUseMetadataMessage message : matrixMetadataMessage.getLand_use_metadata_list()) {
				try {
					MatrixLandUsesMetadataNTT toInsert = MatrixLandUsesMetadataNTT.builder()
							.class_code(message.getClass_code())
							.day_from(message.getDay_from())
							.day_to(message.getDay_to())
							.key(message.getKey())
							.matrix_id(matrixId)
							.tenant_id(tenantId)
							.value(message.getValue())
							.land_use_code(message.getLand_use_code())
							.build();

					// A landuse metadata key can be in only one class per matrix, so if it is in any other class, or the same one, it must be "deleted"
					List<MatrixLandUsesMetadataNTT> landUsesMetadata = matrixLandUsesMetadataDAO.getLandUsesMetadataByMatrixIdLandUseCodeAndKey(tenantId, matrixId,
							message.getLand_use_code(), AbsoluteDate.of(LocalDate.now()), message.getKey());

					if (!landUsesMetadata.isEmpty()) {
						matrixLandUsesMetadataDAO.logicallyDeleteByMatrixLandUseKey(landUsesMetadata.get(0), USER);
					}

					matrixLandUsesMetadataDAO.insert(toInsert, USER);
				} catch (Exception e) {
					log.error(
							"Error during insert/update operation of land use metadata with matrix code {}, class code {}, land use code {}, tenant {} : {}"
							+ matrixMetadataMessage.getMatrix_code(), message.getClass_code(), message.getLand_use_code(), tenantId, e);
				}
			}
		}
	}

	private void insertOrUpdateMatrixMetadataMessageLandcoverMetadata(String tenantId, MatrixMetadataMessage matrixMetadataMessage, Long matrixId) {
		if (matrixMetadataMessage.getLand_cover_metadata_list() != null) {
			for (MatrixLandCoverMetadataMessage message : matrixMetadataMessage.getLand_cover_metadata_list()) {
				try {
					MatrixLandCoversMetadataNTT toInsert = MatrixLandCoversMetadataNTT.builder()
							.class_code(message.getClass_code())
							.day_from(message.getDay_from())
							.day_to(message.getDay_to())
							.key(message.getKey())
							.matrix_id(matrixId)
							.tenant_id(tenantId)
							.value(message.getValue())
							.land_cover_code(message.getLand_cover_code())
							.build();

					// A landcover metadata key can be in only one class per matrix, so if it is in any other class, or the same one, it must be "deleted"
					List<MatrixLandCoversMetadataNTT> landCoverMetadata = matrixLandCoversMetadataDAO.getLandCoversMetadataByKeyMatrixIdLandCoverCode(tenantId, matrixId,
							message.getLand_cover_code(), AbsoluteDate.of(LocalDate.now()), message.getKey());

					if (!landCoverMetadata.isEmpty()) {
						matrixLandCoversMetadataDAO.logicallyDeleteByMatrixLandCoverKey(landCoverMetadata.get(0), USER);
					}

					matrixLandCoversMetadataDAO.insert(toInsert, USER);
				} catch (Exception e) {
					log.error(
							"Error during insert/update operation of land cover metadata with matrix code {}, class code {}, land cover code {}, tenant {} : {}"
							+ matrixMetadataMessage.getMatrix_code(), message.getClass_code(), message.getLand_cover_code(), tenantId, e);
				}
			}
		}
	}

	private void insertOrUpdateMatrixMetadataMessageClassMetadata(String tenantId, MatrixMetadataMessage matrixMetadataMessage, Long matrixId) {
		if (matrixMetadataMessage.getClass_metadata_list() != null) {
			for (MatrixClassMetadataMessage message : matrixMetadataMessage.getClass_metadata_list()) {
				try {
					MatrixClassMetadataNTT toInsert = MatrixClassMetadataNTT.builder()
							.class_code(message.getClass_code())
							.day_from(message.getDay_from())
							.day_to(message.getDay_to())
							.key(message.getKey())
							.matrix_id(matrixId)
							.tenant_id(tenantId)
							.value(message.getValue())
							.build();

					List<MatrixClassMetadataNTT> classMetadata = matrixClassMetadataDAO.getClassMetadataByMatrixIdClassCodeAndKey(tenantId, matrixId,
							message.getClass_code(), AbsoluteDate.of(LocalDate.now()), message.getKey());

					if (!classMetadata.isEmpty()) {
						matrixClassMetadataDAO.logicallyDelete(classMetadata.get(0), USER);
					}

					matrixClassMetadataDAO.insert(toInsert, USER);
				} catch (Exception e) {
					log.error("Error during insert/update operation of class metadata with matrix code {}, class code {} tenant {} : {}"
							+ matrixMetadataMessage.getMatrix_code(), message.getClass_code(), tenantId, e);
				}
			}
		}
	}
	
	private void deleteMatrixMetadataMessage(String tenantId, File file) {

		try {
			MatrixMetadataListMessage matrixMetadataListMessage = objectMapper.readValue(file, MatrixMetadataListMessage.class);

			if (matrixMetadataListMessage.getMatrix_metadata_list() != null) {
				matrixMetadataListMessage.getMatrix_metadata_list().forEach(matrixMetadataMessage -> {
					try {
						ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).user(new User(USER, tenantId)).build();
						List<MatrixNTT> matrixNTT = matrixDAO.findByCode(env, matrixMetadataMessage.getMatrix_code());
						if (matrixNTT.isEmpty()) {
							throw new IllegalArgumentException("Matrix code " + matrixMetadataMessage.getMatrix_code() + " not found!");
						}
						Long matrixId = matrixNTT.get(0).getId();

						deleteMatrixMetadataMessageClassMetadata(tenantId, matrixMetadataMessage, matrixId);

						deleteMatrixMetadataMessageLandCoverMetadata(tenantId, matrixMetadataMessage, matrixId);

						deleteMatrixMetadataMessageLandUseMetadata(tenantId, matrixMetadataMessage, matrixId);

					} catch (Exception e) {
						log.error("Error processing metadata with matrix code {} for tenant {} : {}" + matrixMetadataMessage.getMatrix_code(), tenantId, e);
					}

				});
			}

		} catch (Exception e) {
			log.error("Error processing file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}
	}

	private void deleteMatrixMetadataMessageLandUseMetadata(String tenantId, MatrixMetadataMessage matrixMetadataMessage, Long matrixId) {
		if (matrixMetadataMessage.getLand_use_metadata_list() != null) {
			for (MatrixLandUseMetadataMessage message : matrixMetadataMessage.getLand_use_metadata_list()) {
				try {
					List<MatrixLandUsesMetadataNTT> landUsesMetadata = matrixLandUsesMetadataDAO.getLandUsesMetadataByMatrixIdClassCodeLandUseCodeAndKey(tenantId, matrixId,
							message.getClass_code(), message.getLand_use_code(), AbsoluteDate.of(LocalDate.now()), message.getKey());

					if (!landUsesMetadata.isEmpty()) {
						matrixLandUsesMetadataDAO.logicallyDelete(landUsesMetadata.get(0), USER);
					}
				} catch (Exception e) {
					log.error(
							"Error during delete operation of land use metadata with matrix code {}, class code {}, land use code {}, tenant {} : {}"
							+ matrixMetadataMessage.getMatrix_code(), message.getClass_code(), message.getLand_use_code(), tenantId, e);
				}
			}
		}
	}

	private void deleteMatrixMetadataMessageLandCoverMetadata(String tenantId, MatrixMetadataMessage matrixMetadataMessage, Long matrixId) {
		if (matrixMetadataMessage.getLand_cover_metadata_list() != null) {
			for (MatrixLandCoverMetadataMessage message : matrixMetadataMessage.getLand_cover_metadata_list()) {
				try {
					List<MatrixLandCoversMetadataNTT> landCoverMetadata = matrixLandCoversMetadataDAO.getLandCoversMetadataByKeyMatrixIdClassCodeLandCoverCode(tenantId, matrixId,
							message.getClass_code(), message.getLand_cover_code(), AbsoluteDate.of(LocalDate.now()), message.getKey());

					if (!landCoverMetadata.isEmpty()) {
						matrixLandCoversMetadataDAO.logicallyDelete(landCoverMetadata.get(0), USER);
					}
				} catch (Exception e) {
					log.error(
							"Error during delete operation of land cover metadata with matrix code {}, class code {}, land cover code {}, tenant {} : {}"
							+ matrixMetadataMessage.getMatrix_code(), message.getClass_code(), message.getLand_cover_code(), tenantId, e);
				}
			}
		}
	}

	private void deleteMatrixMetadataMessageClassMetadata(String tenantId, MatrixMetadataMessage matrixMetadataMessage, Long matrixId) {
		if (matrixMetadataMessage.getClass_metadata_list() != null) {
			for (MatrixClassMetadataMessage message : matrixMetadataMessage.getClass_metadata_list()) {
				try {
					List<MatrixClassMetadataNTT> classMetadata = matrixClassMetadataDAO.getClassMetadataByMatrixIdClassCodeAndKey(tenantId, matrixId,
							message.getClass_code(), AbsoluteDate.of(LocalDate.now()), message.getKey());

					if (!classMetadata.isEmpty()) {
						matrixClassMetadataDAO.logicallyDelete(classMetadata.get(0), USER);
					}
				} catch (Exception e) {
					log.error("Error during delete operation of class metadata with matrix code {}, class code {} tenant {} : {}"
							+ matrixMetadataMessage.getMatrix_code(), message.getClass_code(), tenantId, e);
				}
			}
		}
	}

}
