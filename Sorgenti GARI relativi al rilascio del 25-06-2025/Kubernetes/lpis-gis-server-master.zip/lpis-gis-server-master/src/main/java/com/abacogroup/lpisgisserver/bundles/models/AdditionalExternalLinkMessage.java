package com.abacogroup.lpisgisserver.bundles.models;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.LinkType;
import com.abacogroup.lpisgisserver.core.enums.SoftwareModule;
import com.abacogroup.lpisgisserver.core.enums.SoftwareModuleView;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AdditionalExternalLinkMessage {
	private SoftwareModule module;
	private SoftwareModuleView view;
	private LinkType type;
	private String code;
	private String url;
	private Map<String, String> name_description;
	private Map<String, String> title_description;
	private Boolean fl_visible;
	private Integer display_order;
	private String http_verb;
}
