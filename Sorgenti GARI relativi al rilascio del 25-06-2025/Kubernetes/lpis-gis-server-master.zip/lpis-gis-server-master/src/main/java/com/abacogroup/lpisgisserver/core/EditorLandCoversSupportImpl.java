package com.abacogroup.lpisgisserver.core;

import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.geom.Polygonal;

import com.abacogroup.geometryeditor.EditorResult;
import com.abacogroup.geometryeditor.EditorSupport;
import com.abacogroup.lpisgisserver.core.enums.CutBehaviour;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.LandCoverConfigKeys;
import com.abacogroup.lpisgisserver.core.exceptions.landcover.LandCoverGeometryNotValidPolygonException;
import com.abacogroup.lpisgisserver.core.exceptions.session.InvalidEditSessionException;
import com.abacogroup.lpisgisserver.core.support.EditorSupportParams;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.EditLandCoversDAO;
import com.abacogroup.lpisgisserver.db.dao.EditParcelsDAO;
import com.abacogroup.lpisgisserver.db.dao.LandCoverConfigsDAO;
import com.abacogroup.lpisgisserver.db.ntt.LandCoverNTT;

import jakarta.ws.rs.core.Response.Status;

public class EditorLandCoversSupportImpl implements EditorSupport<Long> {

	private final EditorSupportParams params;
	private final EditLandCoversDAO editLandConverDao;
	private final EditParcelsDAO editParcelsDAO;
	private final LandCoverConfigsDAO landCoverConfigsDAO;
	private CutBehaviour cutBehaviour;
	private EditorResult<Long> parcelEditorResult;
	private Map<Long, Polygon> cutPolygons;
	private long lastPreviewKey = 0;

	public EditorLandCoversSupportImpl(EditorSupportParams params, CutBehaviour cutBehaviour, EditorResult<Long> parcelEditorResult,
			Map<Long, Polygon> cutPolygons, boolean isForPreview, long lastPreviewKey, DAOContainer dc) {

		// Returns the session that the edit session is currently being edited.
		if (params.getSession() == null) {
			throw new InvalidEditSessionException(Status.BAD_REQUEST, params.getOperation(), ErrorField.SESSION,
					null, params.getReqContext().getLang());
		}

		this.editLandConverDao = dc.getEditLandCoversDAO();
		this.editParcelsDAO = dc.getEditParcelsDAO();
		this.landCoverConfigsDAO = dc.getLandCoverConfigsDAO();
		this.params = params;
		this.cutBehaviour = cutBehaviour;
		this.parcelEditorResult = parcelEditorResult;
		this.cutPolygons = cutPolygons;
		this.lastPreviewKey = lastPreviewKey + 1; // incremented to align in getNewPolygonKey
	}

	/**
	* Loads polygons for topology correction. This is used to determine which polygons are affected by the geometry being modified
	* 
	* @param touchingGeometry - Geometry which is to be checked
	* 
	* @return Map of land cover polygons
	*/
	@Override
	public Map<Long, Polygon> loadPolygonsForTopologyCorrection(Geometry touchingGeometry) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(params.getReqContext().getUser())
				.lang(params.getReqContext().getLang())
				.tenantId(params.getReqContext().getTenantId())
				.sessionId(params.getSession().getUuid())
				.srs(params.getSession().getLock_geom_srs())
				.referenceDate(params.getSession().getReference_date())
				.build();

		List<String> forbiddenLandCoverCodes = getForbiddenLandCoverCodes(env);
		Map<Long, Polygon> map = new HashMap<>();

		// This method will return all the land cover polygons that are not in edit polygons with interaction.
		if (parcelEditorResult != null) {
			parcelEditorResult.getModified().forEach((parcelId, parcelGeom) -> {
				List<LandCoverNTT> inEditpolygons = editLandConverDao.getEditLandCoversWithInteraction(env, touchingGeometry, parcelId);
				putInMapIfEditable(map, inEditpolygons, forbiddenLandCoverCodes);

				List<LandCoverNTT> notInEditPolygons = editLandConverDao.getNonEditLandCoversWithInteraction(env, touchingGeometry, parcelId);
				putInMapIfEditable(map, notInEditPolygons, forbiddenLandCoverCodes);
			});

			parcelEditorResult.getTopologyCorrected().forEach((parcelId, parcelGeom) -> {
				List<LandCoverNTT> inEditpolygons = editLandConverDao.getEditLandCoversWithInteraction(env, touchingGeometry, parcelId);
				putInMapIfEditable(map, inEditpolygons, forbiddenLandCoverCodes);

				List<LandCoverNTT> notInEditPolygons = editLandConverDao.getNonEditLandCoversWithInteraction(env, touchingGeometry, parcelId);
				putInMapIfEditable(map, notInEditPolygons, forbiddenLandCoverCodes);
			});

		} else {
			List<LandCoverNTT> inEditpolygons = editLandConverDao.getEditLandCoversWithInteraction(env, touchingGeometry, params.getParcelId());
			putInMapIfEditable(map, inEditpolygons, forbiddenLandCoverCodes);

			List<LandCoverNTT> notInEditPolygons = editLandConverDao.getNonEditLandCoversWithInteraction(env, touchingGeometry, params.getParcelId());
			putInMapIfEditable(map, notInEditPolygons, forbiddenLandCoverCodes);
		}

		return map;

	}
	
	private void putInMapIfEditable(Map<Long, Polygon> map, List<LandCoverNTT> landCover,
			List<String> forbiddenLandCoverCodes) {
		landCover.stream()
		.filter(lc -> forbiddenLandCoverCodes != null && !forbiddenLandCoverCodes.contains(lc.getLand_cover_code()))
		.forEach(p -> map.put(p.getLand_cover_id(), (Polygon) p.getGeom()));
	}

	/**
	* Loads polygons that the parcel can interact with. This is used to determine which land covers are affected by the interaction and to create a list of polygons that will be used to create the edit land cover
	* 
	* @param touchingGeometry - the geometry of the touching land
	* @param interested - the interest to check for
	* 
	* @return the list of polygons that the parcel can interact with or null if there are no polygon in the
	*/
	@Override
	public InvolvedPolygons<Long> loadPolygonsWithInteraction(Geometry touchingGeometry, InvolvedPolygonsInterest interested) {
		final Map<Long, Polygon> modifiablePolygons = new HashMap<>();
		final Map<Long, Polygon> unmodifiablePolygons = new HashMap<>();

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(params.getReqContext().getUser())
				.lang(params.getReqContext().getLang())
				.tenantId(params.getReqContext().getTenantId())
				.sessionId(params.getSession().getUuid())
				.srs(params.getSession().getLock_geom_srs())
				.referenceDate(params.getSession().getReference_date())
				.build();

		List<LandCoverNTT> polygons = new ArrayList<>();
		
		List<String> forbiddenLandCoverCodes = getForbiddenLandCoverCodes(env);

		List<LandCoverNTT> editPolygons = editLandConverDao.getEditLandCoversWithInteraction(env, touchingGeometry, params.getParcelId());
		// Add all polygons to the polygons list.
		if (editPolygons != null)
			polygons.addAll(editPolygons);

		List<LandCoverNTT> nonEditPolygons = editLandConverDao.getNonEditLandCoversWithInteraction(env, touchingGeometry, params.getParcelId());
		// Add all polygons to the list of nonEditPolygons.
		if (nonEditPolygons != null)
			polygons.addAll(nonEditPolygons);

		// Add all polygons to modifiablePolygons.
		if (cutPolygons != null) {
			polygons = polygons.stream()
					.filter(p -> (!cutPolygons.containsKey(p.getLand_cover_id())))
					.collect(toList());
			cutPolygons.forEach((id, p) -> {
				// Add a polygon to the modifiablePolygons.
				if (p != null)
					modifiablePolygons.put(id, p);
			});
		}

		polygons.forEach(p -> {
			// Checks if the polygon is a valid polygon.
			if (!(p.getGeom() instanceof Polygon)) {
				throw new LandCoverGeometryNotValidPolygonException(Status.INTERNAL_SERVER_ERROR, null,
						ErrorField.GEOM, null, env.getLang());
			}
			
			Boolean isEditable = !forbiddenLandCoverCodes.contains(p.getLand_cover_code());

			// Add the polygon to the list of polygons.
			if (cutBehaviour == CutBehaviour.CUT_EXISTING && isEditable)
				modifiablePolygons.put(p.getLand_cover_id(), (Polygon) p.getGeom());
			// Add a polygon to the unmodifiablePolygons.
			else if (cutBehaviour == CutBehaviour.CUT_ON_EXISTING || !isEditable)
				unmodifiablePolygons.put(p.getLand_cover_id(), (Polygon) p.getGeom());

		});

		return new InvolvedPolygons<>(modifiablePolygons, unmodifiablePolygons);
	}

	/**
	* Loads the geometries associated with the parcel. This is called when the user clicks on the touching geometry in the edit - popup.
	* 
	* @param touchingGeometry - the geometry that is touching the parcel
	* 
	* @return a collection of polygons that are touching the parcel or an empty collection if there are no geometries
	*/
	@Override
	public Collection<Polygonal> loadCanvasGeometries(Geometry touchingGeometry) {
		List<Polygonal> result = new ArrayList<>();

		// Returns the list of polygons that were edited by the parcel editor.
		if (parcelEditorResult == null) {

			ServiceSupportEnv env = ServiceSupportEnv
					.builder()
					.user(params.getReqContext().getUser())
					.lang(params.getReqContext().getLang())
					.tenantId(params.getReqContext().getTenantId())
					.sessionId(params.getSession().getUuid())
					.srs(params.getSession().getLock_geom_srs())
					.referenceDate(params.getSession().getReference_date())
					.build();

			Long parcelId = params.getParcelId();

			List<Geometry> parcelGeom = editParcelsDAO.getParcelGeomFromParcelId(env, parcelId);

			parcelGeom.stream().filter(Objects::nonNull).forEach(p -> result.add((Polygonal) p));
		} else {

			parcelEditorResult.getCreated().forEach((parcelId, parcelGeom) -> {
				// Add the parcel geometry to the result.
				if (parcelGeom != null)
					result.add(parcelGeom);
			});

			parcelEditorResult.getModified().forEach((parcelId, parcelGeom) -> {
				// Add the parcel geometry to the result.
				if (parcelGeom != null)
					result.add(parcelGeom);
			});

			parcelEditorResult.getTopologyCorrected().forEach((parcelId, parcelGeom) -> {
				// Add the parcel geometry to the result.
				if (parcelGeom != null)
					result.add(parcelGeom);
			});
		}

		return result;
	}

	/**
	* Creates a map of polygon keys to their corresponding polygons. The polygons are sorted by their area and the key is used to store the polygon in the map.
	* 
	* @param key - the key for the polygon to be stored in the map
	* @param polygons - the polygons to be stored in the map
	* 
	* @return a map of polygon keys to their corresponding polygons ( if any are present in the collection they will be stored
	*/
	@Override
	public Map<Long, Polygon> createPolygonKeys(Long key, Collection<Polygon> polygons) {
		Map<Long, Polygon> map = new HashMap<>();
		var maxAreaPolygon = polygons.stream().max(Comparator.comparing(Polygon::getArea));
		// Add max area polygon to map.
		if (!maxAreaPolygon.isEmpty()) {
			map.put(key, maxAreaPolygon.get());
		}

		polygons.forEach(p -> {
			// Put the polygon in the map.
			if (p != maxAreaPolygon.get())
				map.put(getNewPolygonKey(), p);
		});
		return map;
	}

	/**
	* Creates a map of polygon keys. This is used to store polygons that need to be re - used in order to avoid re - creating the same polygon multiple times
	* 
	* @param polygons - the polygons to be stored
	* 
	* @return a map of polygon keys indexed by their position in the collection of polygons passed in as an argument to
	*/
	@Override
	public Map<Long, Polygon> createPolygonKeys(Collection<Polygon> polygons) {
		Map<Long, Polygon> map = new HashMap<>();
		polygons.forEach(p -> map.put(getNewPolygonKey(), p));
		return map;
	}

	/**
	* Returns a new polygon key. Used to determine which polygon should be previewed and where to put the preview in the map.
	* 
	* 
	* @return The key that should be used for previewing the polygon or null if there is no preview available in the
	*/
	private Long getNewPolygonKey() {
		lastPreviewKey -= 1;
		return lastPreviewKey;
	}

	private List<String> getForbiddenLandCoverCodes(ServiceSupportEnv env) {
		return landCoverConfigsDAO.findConfigs(env.getTenantId(), null, LandCoverConfigKeys.EDIT_FORBIDDEN).stream()
				.filter(c -> Boolean.TRUE.equals(Boolean.parseBoolean(c.getValue())))
				.map(config -> config.getLandCoverCode())
				.collect(Collectors.toList());
	}
}
