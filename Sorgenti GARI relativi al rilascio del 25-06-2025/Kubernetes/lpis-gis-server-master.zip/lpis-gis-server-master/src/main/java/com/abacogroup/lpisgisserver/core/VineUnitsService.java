package com.abacogroup.lpisgisserver.core;

import java.util.List;
import java.util.stream.Collectors;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.enums.UnitType;
import com.abacogroup.lpisgisserver.core.exceptions.units.vine.VineAptitudeNotFoundException;
import com.abacogroup.lpisgisserver.core.exceptions.units.vine.VineUnitNotFoundException;
import com.abacogroup.lpisgisserver.core.mappers.units.VineAptitudesMapper;
import com.abacogroup.lpisgisserver.core.mappers.units.VineUnitMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.VineUnitsDAO;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineAptitudeNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineUnitNTT;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.req.ReqContext;
import com.abacogroup.lpisgisserver.resources.res.anomalies.AnomaliesList;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineAptitude;
import com.abacogroup.lpisgisserver.resources.res.units.vine.VineUnitWithAptitudes;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class VineUnitsService extends BaseService {

	private final VineUnitsDAO vineUnitsDAO;

	private final UnitsSupportService unitsSupportService;

	private final AnomaliesService anomaliesService;

	private static final UnitType UNIT_TYPE = UnitType.VINE_UNIT;

	public VineUnitsService(DAOContainer dc, UnitsSupportService unitsSupportService, InternalConfigService conf,
							ExternalConfigService externalConf, AnomaliesService anomaliesService,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, 
			PluginEnvironment pluginEnvironment) {
		super(dc, conf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.vineUnitsDAO = dc.getVineUnitsDAO();
		this.unitsSupportService = unitsSupportService;
		this.anomaliesService = anomaliesService;
	}

	public List<VineUnitWithAptitudes> getVineUnits(ServiceSupportEnv env, Boolean showOutdatedUnits) {
		unitsSupportService.checkServiceSupportEnv(env, UNIT_TYPE, Operation.GET_VINE_UNITS);
		List<VineUnitWithAptitudes> vineUnits = vineUnitsDAO.getVineUnitsbyLandCoverIds(env, List.of(env.getLandCoverId()), boolToInt(showOutdatedUnits)).stream()
				.map(VineUnitMapper.INSTANCE::entityToDtoWithAptitudes)
				.collect(Collectors.toList());

		vineUnits.stream().forEach(unit -> unit.setVineAptitudes(getVineAptitudesByUnitId(env, unit.getId(), null, false)));

		return vineUnits;
	}

	public VineUnitWithAptitudes getVineUnitById(ServiceSupportEnv env, Long vineUnitId) {
		unitsSupportService.checkServiceSupportEnv(env, UNIT_TYPE, Operation.GET_VINE_UNIT);

		VineUnitWithAptitudes vineUnit = VineUnitMapper.INSTANCE.entityToDtoWithAptitudes(getVineUnitNTTByUnitId(env, vineUnitId, Operation.GET_VINE_UNIT));		
		vineUnit.setVineAptitudes(getVineAptitudesByUnitId(env, vineUnit.getId(), null, false));

		// Fetch Anomalies from Anomaly-Registry
		ReqContext reqContext = new ReqContext(env.getTenantId(), env.getUserName(), env.getLang());
		AnomaliesList parcelAnomalies = anomaliesService.getParcelAnomalies(reqContext, env.getParcelId());
		vineUnit.setAnomalies(parcelAnomalies.getAnomalies_list() != null ? parcelAnomalies.getAnomalies_list() : null);
		
		return vineUnit;
	}

	public List<VineAptitude> getVineAptitudesByUnitId(ServiceSupportEnv env, Long vineUnitId, Long vineAptitudeId, Boolean showOutdatedUnits) {
		unitsSupportService.checkServiceSupportEnv(env, UNIT_TYPE, Operation.GET_VINE_APTITUDES);

		VineUnitNTT vineUnit = getVineUnitNTTByUnitId(env, vineUnitId, Operation.GET_VINE_APTITUDES);

		return getVineAptitudeNTT(env, vineUnit.getUnitId(), vineAptitudeId, showOutdatedUnits, Operation.GET_VINE_APTITUDES).stream()
				.map(VineAptitudesMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}

	private VineUnitNTT getVineUnitNTTByUnitId(ServiceSupportEnv env, Long vineUnitId, Operation operation) {
		VineUnitNTT vineUnitNTT = vineUnitsDAO.getVineUnitsbyUnitId(env, vineUnitId);
		if(vineUnitNTT == null) {
			VineUnitNotFoundException ex = new VineUnitNotFoundException(Status.NOT_FOUND, operation, 
					ErrorField.UNIT_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		return vineUnitNTT;
	}

	private List<VineAptitudeNTT> getVineAptitudeNTT(ServiceSupportEnv env, Long vineUnitId, Long vineAptitudeId,
			Boolean showOutdatedUnits, Operation operation) {
		List<VineAptitudeNTT> vineAptitudeNTT = vineUnitsDAO.getVineAptitudes(env, vineUnitId, vineAptitudeId, boolToInt(showOutdatedUnits));
		if(vineAptitudeNTT == null || (vineAptitudeId != null && vineAptitudeNTT.size() != 1)) {
			VineAptitudeNotFoundException ex = new VineAptitudeNotFoundException(Status.NOT_FOUND, operation, 
					ErrorField.VINE_APTITUDE_ID, this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		return vineAptitudeNTT;
	}
}
