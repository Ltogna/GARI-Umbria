package com.abacogroup.lpisgisserver.core;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.proj4j.CoordinateReferenceSystem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.cxf.InvalidCXFFileException;
import com.abacogroup.lpisgisserver.core.exceptions.externalsource.ExternalParcelNotFoundException;
import com.abacogroup.lpisgisserver.core.mappers.ExternalParcelsMapper;
import com.abacogroup.lpisgisserver.core.mappers.ExternalSourceMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.ExternalSourceDataDAO;
import com.abacogroup.lpisgisserver.environments.PluginEnvironment;
import com.abacogroup.lpisgisserver.resources.res.ExternalSource;
import com.abacogroup.lpisgisserver.resources.res.ExternalSourceParcel;

import jakarta.ws.rs.core.Response.Status;

public class ExternalParcelsSourceDataService extends BaseService {

	private ExternalSourceDataDAO externalSourceDataDAO;

	private static final Logger log = LoggerFactory.getLogger(ExternalParcelsSourceDataService.class);

	public ExternalParcelsSourceDataService(DAOContainer dc, InternalConfigService internalConf, ExternalConfigService externalConf,
			ErrorDescriptionsService errorDescriptionsService, StyleService styleService, PluginEnvironment pluginEnvironment) {
		super(dc, internalConf, externalConf, errorDescriptionsService, styleService, pluginEnvironment);

		this.externalSourceDataDAO = dc.getExternalSourceDataDAO();

	}
	
	/**
	* Returns a list of ExternalSource DTOs that belong to the tenant. This is used to determine if a user has access to an external source or not
	* 
	* @param env - environment for which to search
	* 
	* @return list of ExternalSource DTO
	*/
	public List<ExternalSource> getExternalSourceCodeList(ServiceSupportEnv env) {
		if(Boolean.FALSE.equals(this.internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_SEARCH_EXTERNAL_PARCELS.getKey()))) {
			return new ArrayList<>();
		}
		
		// TODO in futuro Usare una tabella di configurazione per associare le informazioni aggiuntive, tipo il layer_path.
		return externalSourceDataDAO.findExternalSourceCodeByTenantAndSrs(env, null)
				.stream()
				.map(ExternalSourceMapper.INSTANCE::entityToDto) 
				.collect(Collectors.toList());
	}
	
	/**
	* Search for external parcels. This is a wrapper for searchExternalParcelsInfiniteList ( String sdeCode String sector String block String parcelCode ServiceSupportEnv env )
	* 
	* @param sdeCode - The SDE code of the parcel to search.
	* @param sector - The sector of the parcel to search.
	* @param block - The block of the parcel to search.
	* @param parcelCode - The parcel code of the parcel to search.
	* @param env - The environment to use. If null the environment from the service support will be used.
	* 
	* @return An InfiniteListResults object containing the search results or null if nothing was found in the service for the specified parameters
	*/
	public InfiniteListResults<ExternalSourceParcel> getExternalParcelsInfiniteList(String sdeCode, String sector, String block, String parcelCode, ServiceSupportEnv env) {
		InfiniteListResults<ExternalSourceParcel> infiniteParcels = searchExternalParcelsInfiniteList(sdeCode, sector, block, parcelCode, env);
		
		// Returns a list of all the records in infinite parcels.
		if(infiniteParcels.getRecords() == null || infiniteParcels.getRecords().isEmpty()){
			ExternalParcelNotFoundException ex = new ExternalParcelNotFoundException(Status.NOT_FOUND, Operation.GET_EXTERNAL_PARCELS, ErrorField.REQUEST,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
			
		return infiniteParcels;
	}

	/**
	* Search for external parcels that match the search criteria. This is a convenience method that calls #searchExternalParcelsBySectorBlockParcelAndTenant ( ServiceSupportEnv String String ) with the environment passed in to the search method.
	* 
	* @param sdeCode - The SILENT code for the sector to search.
	* @param sectorCode - The SILENT code for the block to search.
	* @param blockCode - The BLOCK code for the parcel to search.
	* @param parcelCode - The PARCEL code for the search.
	* @param env - The environment to use for the search. This is used to determine the CRS of the external parcels so that they can be reprojected
	*/
	public InfiniteListResults<ExternalSourceParcel> searchExternalParcelsInfiniteList(String sdeCode, String sectorCode, String blockCode, String parcelCode, ServiceSupportEnv env) {
		
		if(Boolean.FALSE.equals(this.internalConf.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_SEARCH_EXTERNAL_PARCELS.getKey()))) {
			return new InfiniteListResultsImpl<>();
		}
		
		CoordinateReferenceSystem toCRS = getCRS(env.getSrs());

		String parcelNameDecoded = applyDecodeParcelNamePlugin(env, parcelCode);

		InfiniteListResults<ExternalSourceParcel> parcels = externalSourceDataDAO
				.infinite(() -> externalSourceDataDAO.findParcelsBySectorBlockParcelAndTenant(env, sdeCode, sectorCode, blockCode, parcelNameDecoded),
				env.getNextKey(),
				env.getPageSize())
				.map(ExternalParcelsMapper.INSTANCE::entityToDto);
		
		parcels.getRecords().forEach(externalParcel -> {
			// Reproject the external parcel to the given SRS.
			if(!externalParcel.getSrs().equals(env.getSrs())) {
				CoordinateReferenceSystem fromCRS = getCRS(externalParcel.getSrs());
				Geometry newGeom = reproject(externalParcel.getGeom(), fromCRS, toCRS);
				externalParcel.setGeom(newGeom);
			}
		});

		return parcels;
	}
	
	public Boolean cleanUpExternalSourceData(String tenantId, String sdeCode, String sectorCode, String blockCode, String filename) {
		
		if(tenantId == null || sdeCode == null || sectorCode == null || blockCode == null || filename == null) {
			return false;
		}
		
		// Clean up all external source datas where tenant, sourcecode and blockcode and filename match
		
		List<Criteria> criterias = new ArrayList<>();
		criterias.add(CriteriaBuilder.string("tenant_id").eq(tenantId));
		criterias.add(CriteriaBuilder.string("external_source_code").eq(sdeCode));
		criterias.add(CriteriaBuilder.string("sector").eq(sectorCode));
		criterias.add(CriteriaBuilder.string("block").eq(blockCode));
		criterias.add(CriteriaBuilder.string("filename").eq(filename));
		Criteria criteria = CriteriaBuilder.and(criterias.toArray(new Criteria[0]));
		
		externalSourceDataDAO.deleteByCriteria(criteria);
		
		return true;
	}
	
	public void saveNewExternalSourceParcel(String tenantId, String sdeCode, String filename, ExternalSourceParcel externalParcel) {
		
		if(tenantId == null || externalParcel == null) {
			InvalidCXFFileException ex = new InvalidCXFFileException(Status.INTERNAL_SERVER_ERROR,
					Operation.CXF_FILE_LOAD, ErrorField.PARCEL,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);

			log.error(ex.getBody().getLogErrorMessage());

			throw ex;
		}
		
		// Insert the external parcel
		externalSourceDataDAO.insert(tenantId, sdeCode, filename, externalParcel);

	}

}
