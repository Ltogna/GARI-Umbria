package com.abacogroup.lpisgisserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.db.ntt.LandCoversCodeNTT;
import com.abacogroup.lpisgisserver.resources.res.LandCoversCode;

@Mapper
public interface LandCoversCodeMapper {

	LandCoversCodeMapper INSTANCE = Mappers.getMapper(LandCoversCodeMapper.class);

	@Mapping(source = "code", target = "land_cover_code")
	@Mapping(source = "description", target = "description")
	LandCoversCode entityToDto(LandCoversCodeNTT entity);

	@Mapping(source = "land_cover_code", target = "code")
	@Mapping(source = "description", target = "description")
	LandCoversCodeNTT dtoToEntity(LandCoversCode dto);

}
