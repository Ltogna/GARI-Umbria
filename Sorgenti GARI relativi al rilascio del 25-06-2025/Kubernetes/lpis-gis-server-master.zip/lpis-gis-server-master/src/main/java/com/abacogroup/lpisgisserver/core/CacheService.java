package com.abacogroup.lpisgisserver.core;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lpisgisserver.core.enums.InternalConfigKeys;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.dao.cache.CacheDAO;

public class CacheService<T> {
	
	protected final CacheDAO<T> cacheDAO;

	protected final InternalConfigService internalConf;
	
	protected final String maxClearTimeConfigKey;
	
	public CacheService(CacheDAO<T> dao, InternalConfigService internalConf, InternalConfigKeys maxClearTimeConfigKey) {
		this.cacheDAO = dao;
		this.internalConf = internalConf;
		this.maxClearTimeConfigKey = maxClearTimeConfigKey.getKey();
		
		clearAll();
	}
	
	public void loadData(ServiceSupportEnv env, List<T> dataList) {
		final LocalDateTime dtInsert = cacheDAO.getCurrentTimestamp().minus(Duration.ofMillis(1));
		clear(env);
		dataList.stream().forEach(d -> cacheDAO.insert(env, d, dtInsert));
	}

	public List<T> getData(ServiceSupportEnv env, Criteria criteria){
		clear(env);
		return cacheDAO.getDataList(env, criteria);
	}
	
	public InfiniteListResults<T> getDataInfinite(ServiceSupportEnv env, Criteria criteria){
		if(env.getNextKey() == null) {
			clear(env);
		}
		return cacheDAO.infinite(() -> cacheDAO.getDataInfiniteList(env, criteria),
				env.getNextKey(),
				env.getPageSize());
	}

	public void clear(ServiceSupportEnv env) {
		cacheDAO.clear(env, getBeforTime(env, maxClearTimeConfigKey));
	}
	
	public void clearAll() {
		cacheDAO.clearAll();
	}
	
	private LocalDateTime getBeforTime(ServiceSupportEnv env, String key) {
		Integer maxTime = internalConf.getIntegerValue(env.getTenantId(), key);
		return cacheDAO.getCurrentTimestamp().minus(Duration.ofMinutes(maxTime));
	}
}
