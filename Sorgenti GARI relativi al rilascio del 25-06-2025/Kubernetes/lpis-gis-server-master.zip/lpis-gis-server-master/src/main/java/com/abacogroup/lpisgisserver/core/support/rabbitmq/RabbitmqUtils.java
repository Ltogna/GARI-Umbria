package com.abacogroup.lpisgisserver.core.support.rabbitmq;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeoutException;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.lpisgisserver.core.config.rabbitmq.RabbitmqConfig;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class RabbitmqUtils {
	
	// public static final String EXCHANGE_NAME = "lpis-gis-server";
	// public static final String QUEUE_ID = "lpis-stack-queue";
	public static final String ROUTING_KEY = "save-stack";

	private static String exchangeName = "lpis-gis-server";
	private static String queueId = "lpis-stack-queue";

	private RabbitmqUtils() {
	}

	public static void applyVariant(String variant) {
		if (variant != null) {
			exchangeName = variant;
			queueId = variant + "-stkq";
		}
	}

	public static Connection createRabbitmqConnection(RabbitmqConfig rabbitmqConfig) {
		if (rabbitmqConfig == null) {
			return null;
		}

		if (StringUtils.isBlank(rabbitmqConfig.getHost())) {
			return null;
		}

		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(rabbitmqConfig.getHost());

		if (!StringUtils.isBlank(rabbitmqConfig.getUser())) {
			factory.setUsername(rabbitmqConfig.getUser());
		}
		if (!StringUtils.isBlank(rabbitmqConfig.getPassword())) {
			factory.setPassword(rabbitmqConfig.getPassword());
		}
		if (!StringUtils.isBlank(rabbitmqConfig.getVirtualhost())) {
			factory.setVirtualHost(rabbitmqConfig.getVirtualhost());
		}
		if (rabbitmqConfig.getPort() != null) {
			factory.setPort(rabbitmqConfig.getPort());
		}
		factory.setAutomaticRecoveryEnabled(true);

		try {
			return factory.newConnection();
		} catch (IOException | TimeoutException e) {
			throw new IllegalStateException("Cannot connect to rabbit mq", e);
		}
	}

	public static Channel createChannel(Connection connection, String exchangeName, boolean durable) throws IOException {
		Channel channel = connection.createChannel();
		channel.exchangeDeclare(exchangeName, BuiltinExchangeType.TOPIC, durable);
		return channel;
	}

	public static void sendMessage(String tenant, Channel channel, String topicName, String routingKey, byte[] body) throws IOException {
		channel.basicPublish(topicName, routingKey, new AMQP.BasicProperties.Builder()
				.deliveryMode(2) // persistent
				.contentType("application/json")
				.headers(Map.of("tenant", tenant))
				.build(), body);
	}

	public static String getExchangeName() {
		return exchangeName;
	}

	public static String getQueueId() {
		return queueId;
	}


}
