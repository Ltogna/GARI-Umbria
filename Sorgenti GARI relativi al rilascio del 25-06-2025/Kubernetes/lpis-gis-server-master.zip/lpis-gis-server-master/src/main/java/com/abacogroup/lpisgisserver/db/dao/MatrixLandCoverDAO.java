package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.LandCoversCodeNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixLandCoverNTT;
import com.abacogroup.lpisgisserver.db.ntt.MatrixLandCoverWithLandUseNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface MatrixLandCoverDAO extends Transactional<MatrixLandCoverDAO>, EnhancedSqlObject {

	@SqlQuery("select lmcl.land_cover_code as landcover_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', lmcl.land_cover_code, :lang)§, lmcl.land_cover_code) as landcover_description, \n"
			+ "       lmcd.class_code, \n"
			+ "       §i18n(:tenantId, 'lpis_matrix_classes', 'code', lmc.code, :lang)§ as class_description, \n"
			+ "       lmcd.line_rgba, \n"
			+ "       lmcd.fill_rgba, \n"
			+ "       lmcd.line_thick \n"
			+ "  from lpis_matrix lm \n"
			+ " inner join lpis_matrix_classes lmc on lm.id = lmc.matrix_id \n"
			+ " inner join lpis_matrix_class_details lmcd on lmc.code = lmcd.class_code and lm.id = lmcd.matrix_id \n"
			+ " inner join lpis_matrix_class_landcovers lmcl on lmcd.class_code = lmcl.class_code and lm.id = lmcl.matrix_id \n"
			+ " where lm.tenant_id = :tenantId \n"
			+ "   and lm.code = :matrixCode \n"
			+ "   and §current_timestamp§ between lmcd.dt_insert and lmcd.dt_delete \n"
			+ "   and :referenceDate between lmcd.day_from and lmcd.day_to \n"
			+ "   and §current_timestamp§ between lmcl.dt_insert and lmcl.dt_delete \n"
			+ "   and :referenceDate between lmcl.day_from and lmcl.day_to \n"
			+ "   and <criteria>")
	@RegisterBeanMapper(MatrixLandCoverNTT.class)
	List<MatrixLandCoverNTT> getLandCoverStylesByCodes(
			@BindBean ServiceSupportEnv env,
			@Bind("matrixCode") String matrixCode,
			@BindCriteria("criteria") Criteria criteria);

	@SqlQuery("select lmcl.land_cover_code as landcover_code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', lmcl.land_cover_code, :lang)§, lmcl.land_cover_code) as landcover_description, \n"
			+ "       lmcd.class_code, \n"
			+ "       §i18n(:tenantId, 'lpis_matrix_classes', 'code', lmc.code, :lang)§ as class_description, \n"
			+ "       coalesce "
			+ "       ( "
			+ "         (§select_from_dual(1)§ "
			+ "           where (lmcl.land_cover_code = coalesce(<favouriteLandCoverCodes>, null) or lmcl.land_cover_code in (<favouriteLandCoverCodes>)) "
			+ "         ), 0 "
			+ "       ) as isFavourite, \n"
			+ "       lmcd.line_rgba, \n"
			+ "       lmcd.fill_rgba, \n"
			+ "       lmcd.line_thick \n"
			+ "  from lpis_matrix lm \n"
			+ " inner join lpis_matrix_classes lmc on lm.id = lmc.matrix_id \n"
			+ " inner join lpis_matrix_class_details lmcd on lmc.code = lmcd.class_code and lm.id = lmcd.matrix_id \n"
			+ " inner join lpis_matrix_class_landcovers lmcl on lmcd.class_code = lmcl.class_code and lm.id = lmcl.matrix_id \n"
			+ " where lm.tenant_id = :tenantId \n"
			+ "   and lm.code = :matrixCode \n"
			+ "   and §current_timestamp§ between lmcd.dt_insert and lmcd.dt_delete \n"
			+ "   and :referenceDate between lmcd.day_from and lmcd.day_to \n"
			+ "   and §current_timestamp§ between lmcl.dt_insert and lmcl.dt_delete \n"
			+ "   and :referenceDate between lmcl.day_from and lmcl.day_to \n"
			+ "   and (:search is null or lmcl.land_cover_code like '%'||upper(:search)||'%' or upper(§i18n(:tenantId, 'lpis_landcovers', 'code', lmcl.land_cover_code, :lang)§) like '%'||upper(:search)||'%' or (upper(lmcl.land_cover_code) || ' - ' || upper(§i18n(:tenantId, 'lpis_landcovers', 'code', lmcl.land_cover_code, :lang)§)) like '%'||upper(:search)||'%')"
			+ "   and (coalesce(<landCoverCodes>, null) is null or lmcl.land_cover_code in (<landCoverCodes>))"
			+ "   order by isFavourite desc, coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', lmcl.land_cover_code, :lang)§, lmcl.land_cover_code)")
	@RegisterBeanMapper(MatrixLandCoverNTT.class)
	ResultIterator<MatrixLandCoverNTT> getLandCoverStylesByCodesInfinite(
			@BindBean ServiceSupportEnv env,
			@Bind("matrixCode") String matrixCode,
			@Bind("search") String search,
			@BindList(value = "favouriteLandCoverCodes", onEmpty = BindList.EmptyHandling.NULL_STRING) List<String> favouriteLandCoverCodes,
			@BindList(value = "landCoverCodes", onEmpty = BindList.EmptyHandling.NULL_STRING) List<String> landCoverCodes);

	// XXX To be checked
	@SqlQuery("select distinct lmcl2.land_cover_code as code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', lmcl2.land_cover_code, :lang)§, lmcl2.land_cover_code) as description \n"
			+ "  from lpis_matrix lm \n"
			+ " inner join lpis_matrix_classes lmc on lm.id = lmc.matrix_id \n"
			+ " inner join lpis_matrix_class_details lmcd on lmc.code = lmcd.class_code \n"
			+ " inner join lpis_matrix_class_landcovers lmcl on lmcd.class_code = lmcl.class_code \n"
			+ " inner join lpis_matrix_compat lmct on lmcl.class_code = lmct.class_code \n"
			+ " inner join lpis_matrix_class_landcovers lmcl2 on lmcl2.class_code = lmct.extended_by_class_code and lm.id = lmcl2.matrix_id \n"
			+ " where lm.tenant_id = :tenantId \n"
			+ "   and lm.code = :matrixCode \n"
			+ "   and §current_timestamp§ between lmcd.dt_insert and lmcd.dt_delete \n"
			+ "   and :referenceDate between lmcd.day_from and lmcd.day_to \n"
			+ "   and §current_timestamp§ between lmcl.dt_insert and lmcl.dt_delete \n"
			+ "   and :referenceDate between lmcl.day_from and lmcl.day_to \n"
			+ "   and §current_timestamp§ between lmcl2.dt_insert and lmcl2.dt_delete \n"
			+ "   and :referenceDate between lmcl2.day_from and lmcl2.day_to \n"
			+ "   and lmcl.land_cover_code = :landCoverCode")
	@RegisterBeanMapper(LandCoversCodeNTT.class)
	List<LandCoversCodeNTT> getExtendedLandCoverCodesByLandCoverCode(
			@BindBean ServiceSupportEnv env,
			@Bind("matrixCode") String matrixCode,
			@Bind("landCoverCode") String landCoverCode);

	@SqlQuery("select distinct lmcl2.land_cover_code as code, \n"
			+ "       coalesce(§i18n(:tenantId, 'lpis_landcovers', 'code', lmcl2.land_cover_code, :lang)§, lmcl2.land_cover_code) as description, \n"
			+ "       lmcl.land_use_code \n"
			+ "  from lpis_matrix lm \n"
			+ " inner join lpis_matrix_classes lmc on lm.id = lmc.matrix_id \n"
			+ " inner join lpis_matrix_class_details lmcd on lmc.code = lmcd.class_code and lm.id = lmcd.matrix_id \n"
			+ " inner join lpis_matrix_class_landuses lmcl on lmcd.class_code = lmcl.class_code and lm.id = lmcl.matrix_id \n"
			+ " inner join lpis_matrix_class_landcovers lmcl2 on lmcd.class_code = lmcl2.class_code and lm.id = lmcl2.matrix_id \n"
			+ " where lm.tenant_id = :tenantId \n"
			+ "   and lm.code = :matrixCode \n"
			+ "   and §current_timestamp§ between lmcd.dt_insert and lmcd.dt_delete \n"
			+ "   and :referenceDate between lmcd.day_from and lmcd.day_to \n"
			+ "   and §current_timestamp§ between lmcl.dt_insert and lmcl.dt_delete \n"
			+ "   and :referenceDate between lmcl.day_from and lmcl.day_to \n"
			+ "   and §current_timestamp§ between lmcl2.dt_insert and lmcl2.dt_delete \n"
			+ "   and :referenceDate between lmcl2.day_from and lmcl2.day_to \n"
			+ "   and <criteria>")
	@RegisterBeanMapper(MatrixLandCoverWithLandUseNTT.class)
	List<MatrixLandCoverWithLandUseNTT> getLandCoversCodesByLandUseCodes(
			@BindBean ServiceSupportEnv env,
			@Bind("matrixCode") String matrixCode,
			@BindCriteria("criteria") Criteria criteria);
}
