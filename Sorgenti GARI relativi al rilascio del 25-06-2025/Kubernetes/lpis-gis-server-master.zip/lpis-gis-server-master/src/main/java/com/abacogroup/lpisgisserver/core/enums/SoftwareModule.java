package com.abacogroup.lpisgisserver.core.enums;

public enum SoftwareModule {
	LPIS_EDITOR, 
	LPIS_VIEWER,
	FARMLAND_VIEWER
}
