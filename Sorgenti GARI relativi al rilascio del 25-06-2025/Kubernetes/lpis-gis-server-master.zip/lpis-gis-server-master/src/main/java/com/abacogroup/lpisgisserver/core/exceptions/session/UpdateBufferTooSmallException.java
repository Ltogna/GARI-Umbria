package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class UpdateBufferTooSmallException extends AbstractException {

	private static final long serialVersionUID = -1740491085997168767L;

	private static final ErrorCode ERROR_CODE = ErrorCode.UPDATE_BUFFER_TOO_SMALL;

	public UpdateBufferTooSmallException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new UpdateBufferTooSmallExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Buffer is too small")
	public static class UpdateBufferTooSmallExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = -3652981716542577786L;

		public UpdateBufferTooSmallExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
