package com.abacogroup.lpisgisserver.core.exceptions.session;

import java.util.Map;

import com.abacogroup.lpisgisserver.core.enums.ErrorField;
import com.abacogroup.lpisgisserver.core.enums.Operation;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractException;
import com.abacogroup.lpisgisserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.lpisgisserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class InvalidEditCategoryCodeException extends AbstractException {

	private static final long serialVersionUID = -1247059691035807460L;

	private static final ErrorCode ERROR_CODE = ErrorCode.EDIT_CATEGORY_CODE_NOT_VALID;

	public InvalidEditCategoryCodeException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions,
			String lang) {
		super(code, new InvalidEditCategoryCodeExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
	}

	@Schema(description = "Edit category code not valid")
	public static class InvalidEditCategoryCodeExceptionBody extends AbstractExceptionBody {
		private static final long serialVersionUID = 970796012470859319L;

		public InvalidEditCategoryCodeExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
