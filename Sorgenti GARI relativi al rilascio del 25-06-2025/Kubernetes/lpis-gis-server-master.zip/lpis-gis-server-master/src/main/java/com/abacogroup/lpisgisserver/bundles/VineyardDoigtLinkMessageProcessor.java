package com.abacogroup.lpisgisserver.bundles;

import java.io.File;
import java.nio.file.Path;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.lpisgisserver.bundles.models.units.VineyardDoigtLinkListMessage;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.UnitCodesDAO;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineDoIgtNTT;
import com.abacogroup.lpisgisserver.db.ntt.units.vine.VineyardNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

public class VineyardDoigtLinkMessageProcessor extends AbstractMessageProcessor {

	protected UnitCodesDAO unitCodesDAO;

	private final ObjectMapper objectMapper;

	private static final Logger log = LoggerFactory.getLogger(VineyardDoigtLinkMessageProcessor.class);
	
	private static final String INSERT_ERROR_MESSAGE = "Error during insert operation of vineyard doigt link with vineyard_code {} and doigt_code {} with tenant {} : {}";
	private static final String DELETE_ERROR_MESSAGE = "Error during delete operation of vineyard doigt link with vineyard_code {} and doigt_code {} with tenant {} : {}";

	public VineyardDoigtLinkMessageProcessor(DAOContainer dc) {
		super(dc);
		this.unitCodesDAO = dc.getUnitCodesDAO();

		objectMapper = new ObjectMapper();
	}

	@Override
	public String getDomainName() {
		return "vineyard-doigt";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> insertOrDeleteVineyardDoigtLinksMessage(message.getTenantId(), file, true, DELETE_ERROR_MESSAGE));

		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
				&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> insertOrDeleteVineyardDoigtLinksMessage(message.getTenantId(), file, false, INSERT_ERROR_MESSAGE));
	}

	private void insertOrDeleteVineyardDoigtLinksMessage(String tenantId, File file, Boolean toDelete, String errorMessage) {
		try {
			VineyardDoigtLinkListMessage linkMessages = objectMapper.readValue(file, VineyardDoigtLinkListMessage.class);

			if (linkMessages == null) {
				return;
			}

			if(linkMessages.getVineyard_doigt_links() != null) {
				linkMessages.getVineyard_doigt_links().stream().forEach(message -> {
					try {
						
						VineDoIgtNTT doigt = unitCodesDAO.findVineDoigtByCode(tenantId, message.getDoigt_code());
						if (doigt == null) {
							throw new IllegalStateException("Doigt code " + message.getDoigt_code() + " not found");
						}

						VineyardNTT vineyard = unitCodesDAO.findVineyardByCode(tenantId, message.getVineyard_code());
						if(vineyard == null) {
							throw new IllegalStateException("Vineyard code " + message.getVineyard_code() + " not found");
						}
						
						internalInsertOrDeleteVineyardDoigtLink(vineyard.getId(), doigt.getId(), toDelete);
						
					} catch (Exception e) {
						log.error(errorMessage, message.getVineyard_code(), message.getDoigt_code(), tenantId, e);
					}
				});
			}
		} catch (Exception e) {
			log.error("Error processing file {} for tenant {} : {}" + file.getName(), tenantId, e);
		}
	}

	private void internalInsertOrDeleteVineyardDoigtLink(Long vineyardId, Long doigtId, Boolean toDelete) {
		Boolean linkExists = unitCodesDAO.checkVineyardDoigtCompatibility(vineyardId, doigtId) == 1;
		
		if(Boolean.TRUE.equals(linkExists) && Boolean.TRUE.equals(toDelete)) {
			unitCodesDAO.deleteVineyardDoigtLinkByVineyardIdAndDoigtId(vineyardId, doigtId);
		} else if(Boolean.FALSE.equals(linkExists) && Boolean.FALSE.equals(toDelete)) {
			unitCodesDAO.insertVineyardDoigtLink(vineyardId, doigtId);
		}
	}
}
