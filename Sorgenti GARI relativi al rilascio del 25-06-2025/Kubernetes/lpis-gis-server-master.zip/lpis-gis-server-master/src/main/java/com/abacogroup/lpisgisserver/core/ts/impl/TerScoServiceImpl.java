package com.abacogroup.lpisgisserver.core.ts.impl;

import com.abacogroup.lpisgisserver.LpisGisServerConfiguration;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.core.ts.TerScoService;
import com.abacogroup.lpisgisserver.db.dao.DAOContainer;
import com.abacogroup.lpisgisserver.db.dao.ts.TerritorialScopeDAO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TerScoServiceImpl implements TerScoService {

	private final TerritorialScopeDAO territorialScopeDAO;
	
	private final boolean ignoreTerSco;
	private final String routingKEY;
	
	public TerScoServiceImpl(DAOContainer daoContainer, LpisGisServerConfiguration configuration) {
		
		this.territorialScopeDAO = daoContainer.getTerritorialScopeDAO();
		
		this.ignoreTerSco = configuration.getTerScoConfig().isIgnoreTerSco();
		
		this.routingKEY = configuration.getTerScoConfig().getRoutingKEY();
		
		log.info("Territorial Scopes enabled: {}", !ignoreTerSco);
	}
	
	@Override
	public boolean hasScopeOnSector(ServiceSupportEnv env, String sectorCode) {
		if (ignoreTerSco) {
			return true;
		}
		
		return territorialScopeDAO.hasScopeOnSectorCode(env, routingKEY, sectorCode);
	}
	
	@Override
	public boolean hasScopeOnSector(ServiceSupportEnv env, Long sectorId) {
		if (ignoreTerSco) {
			return true;
		}
		
		return territorialScopeDAO.hasScopeOnSectorId(env, routingKEY, sectorId);
	}

	@Override
	public boolean hasScopeOnBlock(ServiceSupportEnv env, Long blockId) {
		if (ignoreTerSco) {
			return true;
		}
		
		return territorialScopeDAO.hasScopeOnBlockId(env, routingKEY, blockId);
	}

	@Override
	public boolean hasScopeOnParcel(ServiceSupportEnv env, Long parcelId) {
		if (ignoreTerSco) {
			return true;
		}
		
		return territorialScopeDAO.hasScopeOnParcelId(env, routingKEY, parcelId);
		
	}

	
}
