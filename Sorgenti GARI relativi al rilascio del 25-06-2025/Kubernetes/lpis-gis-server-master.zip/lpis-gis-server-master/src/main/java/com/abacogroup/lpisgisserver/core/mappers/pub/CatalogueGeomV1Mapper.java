package com.abacogroup.lpisgisserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.lpisgisserver.resources.res.CatalogueGeom;
import com.abacogroup.lpisgisserver.resources.res.pub.CatalogueGeomV1;

@Mapper
public interface CatalogueGeomV1Mapper {

	CatalogueGeomV1Mapper INSTANCE = Mappers.getMapper(CatalogueGeomV1Mapper.class);
	
	@InheritInverseConfiguration
	CatalogueGeomV1 toResponseV1(CatalogueGeom entity);
	
}
