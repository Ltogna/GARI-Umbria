package com.abacogroup.lpisgisserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.lpisgisserver.core.enums.EditStatus;
import com.abacogroup.lpisgisserver.core.support.ServiceSupportEnv;
import com.abacogroup.lpisgisserver.db.ntt.units.fruit.FruitUnitDetailsNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface EditFruitUnitsDAO extends Transactional<EditFruitUnitsDAO>, EnhancedSqlObject {

	@SqlQuery("§select_nextval(lpis_edit_unit_fruitunit_sequence)§")
	Long nextEditFruitUnitDetailPkidVal();
	
	@SqlQuery("select coalesce(min(unit_id), 0) - 1 from lpis_edit_unit_fruitunit where unit_id < 1")
	Long nextNewFruitUnitIdVal();
	
	@SqlUpdate("INSERT INTO lpis_edit_unit_fruitunit (id, session_uuid, edit_land_cover_id, unit_id, "
			+ "    type_code, unit_code, variety_code, area_sqm, planting_day, planting_day_precision, eradicate_day, "
			+ "    planting_type_code, distance_on_the_row_cm, distance_between_rows_cm, plants_number, "
			+ "    farming_form_code, irrigation_code, altitude_above_sea_level, "
			+ "    quality_system_code, protection_structure_code, external_code, edit_status, fl_deletable, parent_unit_code) "
			+ "values (:editId, :sessionId, :editLandCoverId, :unitId, "
			+ "    :typeCode, :unitCode, :variety.code, :areaSqm, :plantingDay, :plantingDayPrecision, :eradicateDay, "
			+ "    :plantingType.code, :distanceOnTheRowCM, :distanceBetweenRowsCM, :plantsNumber, "
			+ "    :farmingForm.code, :irrigation.code, :altitudeAboveSeaLevel, "
			+ "    :qualitySystem.code, :protectionStructure.code, :externalCode, :editStatus, :flDeletable, :parentUnitCode) "
			+ "")
	void insertEditFruitUnitDetail(@BindBean ServiceSupportEnv env, @BindBean FruitUnitDetailsNTT fruitUnitDetailsNTT);
	
	@SqlUpdate("UPDATE lpis_edit_unit_fruitunit \n"
			+ "SET type_code = :typeCode, unit_code = :unitCode, variety_code = :variety.code, "
			+ "area_sqm = :areaSqm, planting_day = :plantingDay, planting_day_precision = :plantingDayPrecision, eradicate_day = :eradicateDay, "
	        + "planting_type_code = :plantingType.code, distance_on_the_row_cm = :distanceOnTheRowCM, distance_between_rows_cm = :distanceBetweenRowsCM, "
	        + "plants_number = :plantsNumber, farming_form_code = :farmingForm.code, irrigation_code = :irrigation.code, "
	        + "altitude_above_sea_level = :altitudeAboveSeaLevel, quality_system_code = :qualitySystem.code, "
	        + "protection_structure_code = :protectionStructure.code, external_code = :externalCode, edit_status = :editStatus, "
	        + "fl_deletable = :flDeletable, parent_unit_code = :parentUnitCode "
	        + "WHERE unit_id = :unitId and session_uuid = :sessionId ")
	void updateEditFruitUnitDetail(@Bind("sessionId") String sessionId, @BindBean FruitUnitDetailsNTT fruitUnitDetailsNTT);
	
	@SqlQuery("select efu.id as edit_id, \n"
			+ "    efu.edit_land_cover_id, \n"
			+ "    lelc.land_cover_id, \n"
			+ "    efu.unit_id, \n"
			+ "    efu.unit_code, \n"
			+ "    efu.parent_unit_code, \n"
			+ "    efu.type_code, \n"
			+ "    efu.variety_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_variety', 'code', luv.type_code||':'||luv.code, :lang)§ as variety_description, \n"
			+ "    luv.fl_visible as variety_fl_visible, \n"
			+ "    efu.area_sqm, \n"
			+ "    efu.planting_day, \n"
			+ "    efu.planting_day_precision, \n"
			+ "    efu.eradicate_day, \n"
			+ "    efu.planting_type_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_planting_type', 'code', lupt.type_code||':'||lupt.code, :lang)§ as planting_type_description, \n"
			+ "    lupt.fl_visible as planting_type_fl_visible, \n"
			+ "    efu.distance_on_the_row_cm, \n"
			+ "    efu.distance_between_rows_cm, \n"
			+ "    efu.plants_number, \n"
			+ "    efu.farming_form_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_farming_form', 'code', luff.type_code||':'||luff.code, :lang)§ as farming_form_description, \n"
			+ "    luff.fl_visible as farming_form_fl_visible, \n"
			+ "    efu.irrigation_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_irrigation', 'code', lui.type_code||':'||lui.code, :lang)§ as irrigation_description, \n"
			+ "    lui.fl_visible as irrigation_fl_visible, \n"
			+ "    efu.altitude_above_sea_level, \n"
			+ "    efu.quality_system_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_quality_system', 'code', luqs.type_code||':'||luqs.code, :lang)§ as quality_system_description, \n"
			+ "    luqs.fl_visible as quality_system_fl_visible, \n"
			+ "    efu.protection_structure_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_protection_structure', 'code', lups.type_code||':'||lups.code, :lang)§ as protection_structure_description, \n"
			+ "    lups.fl_visible as protection_structure_fl_visible, \n"
			+ "    efu.external_code, \n"
			+ "    efu.edit_status, \n"
			+ "    es.dt_last_lock as lastUpdate,\n"
			+ "    es.user_id as lastUpdateUser, \n"
			+ "    efu.fl_deletable \n"
			+ "from \n"
			+ "    lpis_edit_sessions es \n"
			+ "    inner join lpis_edit_unit_fruitunit efu on es.uuid = efu.session_uuid \n"
			+ "    inner join lpis_edit_land_covers lelc on lelc.session_uuid = efu.session_uuid and lelc.pkid = efu.edit_land_cover_id  \n"
			+ "    left join lpis_unit_variety luv on luv.code = efu.variety_code and luv.tenant_id = :tenantId and luv.type_code = efu.type_code \n"
			+ "    left join lpis_unit_farming_form luff on luff.code = efu.farming_form_code and luff.tenant_id = :tenantId and luff.type_code = efu.type_code \n"
			+ "    left join lpis_unit_irrigation lui on lui.code = efu.irrigation_code and lui.tenant_id = :tenantId and lui.type_code = efu.type_code \n"
			+ "    left join lpis_unit_planting_type lupt on lupt.code = efu.planting_type_code and lupt.tenant_id = :tenantId and lupt.type_code = efu.type_code \n"
			+ "    left join lpis_unit_quality_system luqs on luqs.code = efu.quality_system_code and luqs.tenant_id = :tenantId and luqs.type_code = efu.type_code \n"
			+ "    left join lpis_unit_protection_structure lups on lups.code = efu.protection_structure_code and lups.tenant_id = :tenantId and lups.type_code = efu.type_code \n"
			+ "where \n"
			+ "    es.uuid = :sessionId \n"
			+ "    and efu.type_code = 'FRUIT_UNIT' \n"
			+ "    and (:landCoverId is null or lelc.land_cover_id = :landCoverId) \n"
			+ "    and (:fruitUnitId is null or :fruitUnitId = efu.unit_id) \n"
			+ "    and (:includeEradicate = 1 or :referenceDate < efu.eradicate_day) \n"
			+ "    and (coalesce(<excludes>, null) is null or efu.edit_status not in (<excludes>))"
			+ "    and (coalesce(<excludes>, null) is null or lelc.edit_status not in (<excludes>))"
			+ "order by case when length(efu.unit_code) < 15 then substr(('000000000000000'||efu.unit_code), length('000000000000000'||efu.unit_code) -14, length('000000000000000'||efu.unit_code)) else efu.unit_code end, efu.unit_id asc \n"
			+ "")
	@RegisterBeanMapper(FruitUnitDetailsNTT.class)
	List<FruitUnitDetailsNTT> findInEditFruitUnitsBySessionId(@BindBean ServiceSupportEnv env, @Bind("landCoverId") Long landCoverId,
			@Bind("fruitUnitId") Long fruitUnitId, 
			@BindList(value = "excludes", onEmpty = BindList.EmptyHandling.NULL_STRING) List<EditStatus> excludes,
			@Bind("includeEradicate") Integer includeEradicate);	
	
	default List<FruitUnitDetailsNTT> findInEditFruitUnitsBySessionId(ServiceSupportEnv env, Long landCoverId, Long fruitUnitId, List<EditStatus> excludes){
		return findInEditFruitUnitsBySessionId(env, landCoverId, fruitUnitId, excludes, 0);		
	}
	
	@SqlQuery("SELECT u.land_cover_id, \n"
			+ "    fd.unit_code, \n"
			+ "    fd.parent_unit_code, \n"
			+ "    fd.unit_id, \n"
			+ "    u.type_code, \n"
			+ "    luv.code as variety_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_variety', 'code', luv.type_code||':'||luv.code, :lang)§ as variety_description, \n"
			+ "    luv.fl_visible as variety_fl_visible, \n"
			+ "    fd.area_sqm, \n"
			+ "    fd.planting_day, \n"
			+ "    fd.planting_day_precision, \n"
			+ "    fd.eradicate_day, \n"
			+ "    fd.planting_type_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_planting_type', 'code', lupt.type_code||':'||lupt.code, :lang)§ as planting_type_description, \n"
			+ "    lupt.fl_visible as planting_type_fl_visible, \n"
			+ "    fd.distance_on_the_row_cm, \n"
			+ "    fd.distance_between_rows_cm, \n"
			+ "    fd.plants_number, \n"
			+ "    luff.code as farming_form_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_farming_form', 'code', luff.type_code||':'||luff.code, :lang)§ as farming_form_description, \n"
			+ "    luff.fl_visible as farming_form_fl_visible, \n"
			+ "    lui.code as irrigation_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_irrigation', 'code', lui.type_code||':'||lui.code, :lang)§ as irrigation_description, \n"
			+ "    lui.fl_visible as irrigation_fl_visible, \n"
			+ "    fd.altitude_above_sea_level, \n"
			+ "    fd.quality_system_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_quality_system', 'code', luqs.type_code||':'||luqs.code, :lang)§ as quality_system_description, \n"
			+ "    luqs.fl_visible as quality_system_fl_visible, \n"
			+ "    fd.protection_structure_code, \n"
			+ "    §i18n(:tenantId, 'lpis_unit_protection_structure', 'code', lups.type_code||':'||lups.code, :lang)§ as protection_structure_description, \n"
			+ "    lups.fl_visible as protection_structure_fl_visible, \n"
			+ "    fd.external_code, \n"
			+ "    'NOT_IN_EDIT' as edit_status, \n"
			+ "    fd.dt_insert as lastUpdate, \n"
			+ "    fd.user_id_insert as lastUpdateUser, \n"
			+ "    0 as flDeletable, \n"
			+ "    fd.day_from, \n"
			+ "    fd.day_to \n"
			+ "from "
			+ "    lpis_lock_parcels lp \n"
			+ "    inner join lpis_parcel_land_covers lc on lc.parcel_id = lp.parcel_id \n"
			+ "    inner join lpis_parcel_lc_details lcd on lc.id = lcd.land_cover_id \n"
			+ "    inner join lpis_parcel_lc_units u on u.land_cover_id = lc.id \n"
			+ "    inner join lpis_unit_fruitunit_details fd on u.id = fd.unit_id \n"
			+ "    left join lpis_unit_variety luv on luv.code = fd.variety_code and luv.tenant_id = :tenantId and luv.type_code = u.type_code \n"
			+ "    left join lpis_unit_farming_form luff on luff.code = fd.farming_form_code and luff.tenant_id = :tenantId and luff.type_code = u.type_code \n"
			+ "    left join lpis_unit_irrigation lui on lui.code = fd.irrigation_code and lui.tenant_id = :tenantId and lui.type_code = u.type_code \n"
			+ "    left join lpis_unit_planting_type lupt on lupt.code = fd.planting_type_code and lupt.tenant_id = :tenantId and lupt.type_code = u.type_code \n"
			+ "    left join lpis_unit_quality_system luqs on luqs.code = fd.quality_system_code and luqs.tenant_id = :tenantId and luqs.type_code = u.type_code \n"
			+ "    left join lpis_unit_protection_structure lups on lups.code = fd.protection_structure_code and lups.tenant_id = :tenantId and lups.type_code = u.type_code \n"
			+ "where \n"
			+ "    (:landCoverId is null or u.land_cover_id = :landCoverId) \n"
			+ "    and (:landCoverPkid is null or lcd.pkid = :landCoverPkid) \n"
			+ "    and u.type_code = 'FRUIT_UNIT' \n"
			+ "    and not exists (select 1 from lpis_edit_unit_fruitunit leuf where leuf.session_uuid = :sessionId and leuf.unit_id = u.id) \n"
			+ "    and (:fruitUnitId is null or :fruitUnitId = u.id) \n"
			+ "    and (:landCoverPkid is not null or :referenceDate between lcd.day_from and lcd.day_to) \n"
			+ "    and :referenceDate between fd.day_from and fd.day_to \n"
			+ "    and fd.planting_day <= :referenceDate and :referenceDate < fd.eradicate_day \n"
			+ "    and §current_timestamp§ between fd.dt_insert and fd.dt_delete \n"
			+ "    and (:landCoverPkid is not null or §current_timestamp§ between lcd.dt_insert and lcd.dt_delete) \n"
			+ "order by case when length(fd.unit_code) < 15 then substr(('000000000000000'||fd.unit_code), length('000000000000000'||fd.unit_code) -14, length('000000000000000'||fd.unit_code)) else fd.unit_code end, fd.unit_id asc \n"
			+ "")
	@RegisterBeanMapper(FruitUnitDetailsNTT.class)
	List<FruitUnitDetailsNTT> findNotInEditFruitUnitsBySessionId(@BindBean ServiceSupportEnv env, @Bind("landCoverId") Long landCoverId,
			@Bind("landCoverPkid") Long landCoverPkId, @Bind("fruitUnitId") Long fruitUnitId);

	default List<FruitUnitDetailsNTT> findNotInEditFruitUnitsBySessionId(@BindBean ServiceSupportEnv env, @Bind("landCoverId") Long landCoverId,
			@Bind("fruitUnitId") Long fruitUnitId) {
		return findNotInEditFruitUnitsBySessionId(env, landCoverId, null, fruitUnitId);
	}
	
	@SqlQuery("select coalesce(efu.fl_deletable, 0) \n"
			+ "from \n"
			+ "    lpis_edit_sessions es \n"
			+ "    inner join lpis_edit_unit_fruitunit efu on es.uuid = efu.session_uuid \n"
			+ "    inner join lpis_edit_land_covers lelc on lelc.session_uuid = efu.session_uuid and lelc.pkid = efu.edit_land_cover_id  \n"
			+ "where \n"
			+ "    es.uuid = :sessionId \n"
			+ "    and lelc.land_cover_id = :landCoverId \n"
			+ "    and (:fruitUnitId is null or :fruitUnitId = efu.unit_id) \n"
			+ "")
	Integer checkFruitUnitDeletable(@BindBean ServiceSupportEnv env, @Bind("landCoverId") Long landCoverId,
			@Bind("fruitUnitId") Long fruitUnitId);
	
	@SqlUpdate("delete from lpis_edit_unit_fruitunit where session_uuid = :sessionId and unit_id = :fruitUnitId")
	void deleteFruitUnitsById(@Bind("sessionId") String sessionId, @Bind("fruitUnitId") Long fruitUnitId);	

	@SqlUpdate("delete from lpis_edit_unit_fruitunit where session_uuid = :sessionId")
	void deleteFruitUnitsBySessionId(@Bind("sessionId") String sessionId);

	@SqlUpdate("delete from lpis_edit_unit_fruitunit where session_uuid = :sessionId and id = :editFruitUnitId")
	void deleteFruitUnitsByEditId(@Bind("sessionId") String sessionId, @Bind("editFruitUnitId") Long editFruitUnitId);	
}
