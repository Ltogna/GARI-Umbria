# LPIS GIS SERVER (v1.16.4)

[TOC]

Backend software based on Dropwizard for LPIS GIS Server project

[CHANGELOG](CHANGELOG.md)

[DOCS](docs/README.md)

API: [OpenAPI.yaml](openapi.yaml)


### :warning: Update informations

Freom versione 1.15.0 is mandatory to configure sector areas associations to use the new unique arboreal unit name plugin with "targa" system, the new unit code 
contains the province acronym loaded from the area table

### Compile: `mvn clean compile package`

### Execution: `java -jar lpis-gis-server.jar server config.yml`

dev url: http://localhost:8080/lpis-server-api



### To exec database upgrade: `java -jar lpis-gis-server.jar db migrate config.yml`


## Security Context and functions used

The SSO context|functions used in the software are for standard variant:
- LPIS|EDITOR
   - it enable the user to edit parcels and landcovers
- LPIS|VIEWER
   - it enable the user to view all the data in LPIS
- LPIS|ALLOW_MULTIPLE_EDIT_SESSIONS
   - it allow the user to start multiple active sessions in the editor, used for iteroperability api (sian)

The SSO context|functions used in the software are for 'VINE' variant:
- VINE-GIS-SERVER|EDITOR
   - it enable the user to edit parcels and landcovers
- VINE-GIS-SERVER|VIEWER
   - it enable the user to view all the data in LPIS
- VINE-GIS-SERVER|ALLOW_MULTIPLE_EDIT_SESSIONS
   - it allow the user to start multiple active sessions in the editor, used for iteroperability api (sian)

The "special" SSO context|functions used in the software for additional layer requests
- WMSLAYERS|EDITOR
   - for future use to enable the user to edit the list of additional wms layers
- WMSLAYERS|VIEWER
   - it enable the user to view the list of additional wms layers

## Internal Utility APIs
### update world geom by tenant and table name
`PUT	/internal-api/world_geom?tenant={tenant_id}&table={table_name}`.

where table_name should be one of [AREAS, SECTOR, BLOCKS, PARCELS, LANDCOVERS].


## Cross tenant parcel search APIs
### example, cadastrial parcel location search from continuos soil editor
There is a way to configure a cross tenant parcel search, there are 3 apis:
* GET /{tenant}/api-priv/v1/lpis/location/lpis/sectors?filter={sectorFilter}&include_geometries={true|false}&page_size={pageSize}&next_key={nextKey}
* GET /{tenant}/api-priv/v1/lpis/location/lpis/sectors/{sectorCode}/blocks?filter={blockFilter}&include_geometries={true|false}
* GET /{tenant}/api-priv/v1/lpis/location/lpis/sectors/{sectorCode}/blocks/{blockCode}/parcels/{referenceDate}?filter={parcelFilter}&include_geometries={true|false}&page_size={pageSize}&next_key={nextKey}

if application variable `cross_tenant_lpis_config` is configure with enbled=true amd `cross_tenant_lpis_url` is defined with the url of the lpis server where the cross tenant search must be done, for example: "http://lpis-gis-server:8080/lpis-server-api/master" to search parcel with the public api of "master" tenant on "lpis-gis-server" server for details check redmine ticket: [#177292](https://abacogroup.easyredmine.com/issues/177292)t

## Additional UI Translations
The software has an API for additional ui translation used in Editor and Viewer
`GET /{tenant}/api-priv/v1/lpis/support/additional-translations`
The data is read from the "lpis_i18n_values" with theese data:
* TENANT_ID: "the tenant for the translation
* TABLE_NAME: fix to: 'lpis_additional_translations'
* FIELD_NAME: the client "module" name, like "lpis-editor", "lpis-viewer", "lpis-vine-viewer" or "vine-editor"
* I18N_VALUE: the key for the client for example "title" or "parcel"
* LANG: the lang of the translation
* I18N_TEXT: the text to show, for example "Particella | Particelle" *the client use a pipe for singular multiple name*

see ["i18n"](#i18n) bundle description for details.
Refer to [lpis-editor-ui](/new-agri/lpis-editor-ui) and [farm-land-viewer-ui](/new-agri/farm-land-viewer-ui).

## Configure application-config
The application-config.yml contains the internal configuration of project, the file name is setted in yaml config file with `applicationConfigFile` key.
A property is compose with:

- `key`: (mandatory) name of property to configure
- `type`: type of property value ( java.lang.Double, java.lang.String, ...). Default is java.lang.String if is not set
- `is_array`: flag if property value is an array
- `default_value`: (mandatory) Value of property
- `fl_client`: (mandatory) flag if property is visible for client
- `name`: name of property for client

## Bundles Infrastructure integration
The application must be connected to a RabbitMQ instance.

The bundles infrastructure will automatically set up to allow automatic configuration.

The application module id is `lpis-gis-server` and the supported changeset domains are:


```
📂 lpis-gis-server
┣ 📂 <client-id>-<nnnnn>
┣ ┣ 📂 internal-config
    ┣ 📜 <any file>.json
    ┣ 📜 <any file>.delete.json
┣ ┣ 📂 additional-external-links
    ┣ 📜 <any file>.json
┣ ┣ 📂 landcovers-codes
    ┣ 📜 <any file>.json
┣ ┣ 📂 landuses-codes
    ┣ 📜 <any file>.json
┣ ┣ 📂 landcover-configs
    ┣ 📜 <any file>.json
    ┣ 📜 <any file>.delete.json
┣ ┣ 📂 catalogues
    ┣ 📜 <any file>.json
	┣ 📜 <any file>.delete.json
┣ ┣ 📂 layers
    ┣ 📜 <any file>.json
    ┣ 📜 <any file>.delete.json
┣ ┣ 📂 data
    ┣ 📜 <any file starts with 'areas_'>.jsonl
    ┣ 📜 sectors.jsonl
    ┣ 📜 sector_blocks.jsonl
    ┣ 📜 sector_areas.jsonl
┣ ┣ 📂 external-config
    ┣ 📜 <any file>.json
    ┣ 📜 <any file>.delete.json
┣ ┣ 📂 anomaly-categories
    ┣ 📜 <any file>.jsonl
    ┣ 📜 <any file>.delete.jsonl
┣ ┣ 📂 matrixes
    ┣ 📜 <any file>.json
┣ ┣ 📂 matrix-metadata
    ┣ 📜 <any file>.jsonl
    ┣ 📜 <any file>.delete.jsonl
┣ ┣ 📂 i18n
    ┣ 📜 <any file>.json
    ┣ 📜 <any file>.delete.json
┣ ┣ 📂 campaign
    ┣ 📜 <any file>.json
    ┣ 📜 <any file>.delete.json
┣ ┣ 📂 edit-category-codes
    ┣ 📜 <any file>.json
┣ ┣ 📂 units
    ┣ 📜 <any file>.json
    ┣ 📜 <any file>.delete.json
┣ ┣ 📂 vine-units
    ┣ 📜 <any file>.json
┣ ┣ 📂 vineyard-doigt
    ┣ 📜 <any file>.json
    ┣ 📜 <any file>.delete.json
┣ ┣ 📂 olive-units
    ┣ 📜 <any file>.json
┣ ┣ 📂 fruit-units
    ┣ 📜 <any file>.json
```
### Internal configuration

The internal-config JSON file(s) must have the following structure:
```
{
  "internalConfig":[
	    {
	      "key": "String (mandatory)",          // Name of configuration
	      "value": "Object (mandatory)",        // Value of configuration
	      "fl_client": "Boolean (mandatory)",   // Flag set to true if the configuration is for client
	      "name": "String"                      // Optional name of configuration for client
	    },
	    ...
    ]
}
```

Internal-config file(s) end with ".delete.json" is used for delete lpis_config table table entries and must have the following structure:
```
{
  "internalConfig":[
	    {
	      "key": "String (mandatory)"          // Name of configuration
	    },
	    ...
    ]
}
```

#### Internal config variables
| Key | Description | Type | is array | Default Value | fl_client |
|:---|:---|:---|:---|:---|:---|
| buffer_size | set buffer for geometry | Double | false | 10.0 | false |
| minimum_valid_lock_area | minimum lock area when a parcel is in editing | Double | false | 1.0 | true |
| maximum_valid_lock_area | maximum lock area when a parcel is in editing | Double | false | 100000000.0 | true |
| maximum_valid_session_h_duration | maximum hours of duration of session | Integer | false | 10 | true |
| maximum_parcels_to_merge | maximum number of parcels in a merge operation | Integer | false | 10 | true |
| maximum_landcovers_to_merge | maximum number of landcovers in a merge operation | Integer | false | 10 | true |
| default_land_cover_code | default land cover code when a land cover is created from modify land covers operation | String | false | 0 | true |
| workflow_scope | the scope for taskmanager workflow transitions request | String | false | lpis-editor | false |
| maximum_valid_search_parcels_geom_area | the maximum area when search for parcels on geometry | Double | false | 100000000.0 | true |
| default_sau_matrix_code | matrix code for recover land cover layer style | String | false | sau | false |
| flag_must_cover_all_landcover | flag to define if, in save, all parcels must be covered of landcovers | Boolean | false | true | true |
| fl_hide_landcovers_layer | flag to hide landcovers layer, flag_must_cover_all_landcover must be true | Boolean | false | false | true |
| fl_hide_landcovers_wms | flag to hide landcovers wms from wms list, ref [#159444](https://abacogroup.easyredmine.com/issues/159444) | Boolean | false | false | true |
| default_landcovers_style_matrix_code | matrix code for landcover styles definition | String | false | landcover_style | true |
| maximum_difference_landcover_area_tol | tollerance of land cover area difference with parcel area in mq | Double | false | 3.0 | true |
| flag_merge_land_covers_with_same_code | flag to define if land covers with same code automatically merged on merge parcels operation | Boolean | false | false | false |
| linear_landcover_thicknesses | thicknesses in meters availables on create linear land cover operation | Integer | true | 1,2,3,4,5 | true |
| fl_set_sector_parcel | flag to define if user can set sector of parcel | Boolean | false | true | true |
| fl_set_block_parcel | flag to define if user can set block of parcel | Boolean | false | true | true |
| fl_set_parcel_code | flag to define if user can set code of parcel | Boolean | false | true | true |
| parcel_code_separator | parcel code separator between name and subname | String | false | / | true |
| minimum_update_buffer_size | min buffer during update geometry request | Integer | false | -20 | true |
| maximum_update_buffer_size | max buffer during update geometry request | Integer | false | 20 | true |
| minimum_parcels_area | min parcels area for save session | Integer | false | 1 | true |
| minimum_land_covers_area | min land covers area for save session | Integer | false | 1 | true |
| anomalies_parcel_entity_code | entity code for search anomalies parcels | String | false | REFERENCE_PARCEL | false |
| fl_show_uncategorized_anomaly_types | flag for show anomalies with level UNCATEGORIZED | Boolean | false | false | false |
| fl_force_new_parcel_version | flag for force save session on new parcel version | Boolean | false | false | true |
| public_maximum_valid_search_parcels_geom_area | max area for public apis parcels search | Double | false | 100000000.0 | false |
| public_maximum_parcels_ids_list_req_size | max size for parcels id list in public parcels details api payload request | Integer | false | 100 | false |
| party_registry_directory_url | url for external party registry detail api call | String | false | /party-registry/{tenant}/public/v1/parties/{party_id} | true |
| external_cll_context_path | context path for the customer land link service calls | String | false | /customer-land-link | true |
| fl_coordinates_format_hdms | flag to set coordinates format to "hemisphere degree minute second" instead of latitude/longitude | Boolean | false | false | true |
| fl_hide_coordinates_on_map | flag to hide coordinates on map | Boolean | false | false | true |
| fl_search_external_parcels | flag to search parcels from external source | Boolean | false | false | true |
| fl_enable_campaign_year | flag to enable campaign year | Boolean | false | false | true |
| fl_hide_cll | Flag to hide customer land link panel | Boolean | false | false | true |
| on_create_parcel_wms_to_show | wms layer path to show in the ui when starting a session to create new parcels | String | true | /lpis/sectors/blocks | true |
| cross_tenant_lpis_config | cross tenant lpis configuration | CrossTenantLpisInternalConfig | false | enabled: false<br /> parcelCodeSeparator: / | true |
| cross_tenant_lpis_url | cross tenant lpis server url | String | false | - | false |
| default_wms_parcels_style | wms parcel layer style of type | DrawStyle | false | referenceName: PARCELS<br /> fillRgba: '#B2B2B200'<br /> lineRgba: '#B2B2B2'<br /> lineThick: 2<br /> textColor: '#000000'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: 2.5 | true |
| default_wms_parcels_notpolygon_style | wms parcel layer style when not polygon of type | DrawStyle | false | referenceName: PARCELS<br /> fillRgba: '#FF0000'<br /> lineRgba: '#B2B2B2'<br /> lineThick: 2<br /> textColor: '#000000'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: 2.5 | true |
| default_wms_landcovers_style | wms landcover layer style of type | DrawStyle | false | referenceName: LANDCOVERS<br /> fillRgba: '#CACACA44'<br /> lineRgba: '#CACACA55'<br /> lineThick: 1<br /> textColor: '#CACACA'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: 1.8 | true |
| default_wms_sde_parcels_style | wms external source parcels layer style of type | DrawStyle | false | referenceName: SDE_PARCELS<br /> fillRgba: '#B2B2B200'<br /> lineRgba: '#C70404'<br /> lineThick: 2<br /> textColor: '#C70404'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: 2.5 | true |
| default_wms_sectors_style | wms sectors layer style of type | DrawStyle | false | referenceName: SECTORS<br /> fillRgba: '#FFC0CB00'<br /> lineRgba: '#FFC0CB'<br /> lineThick: 2<br /> textColor: '#FFC0CB'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: null | true |
| default_wms_blocks_style | wms blocks layer style of type | DrawStyle | false | referenceName: BLOCKS<br /> fillRgba: '#FEDE0000'<br /> lineRgba: '#FEDE00'<br /> lineThick: 2<br /> textColor: '#FEDE00'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: null | true |
| default_wms_areas_styles | wms areas layer style of type | DrawStyle | true | referenceName: COM<br /> fillRgba: '#D85E0000'<br /> lineRgba: '#D85E00'<br /> lineThick: 2<br /> textColor: '#D85E00'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: 2.5,referenceName: PRO<br /> fillRgba: '#00B4D400'<br /> lineRgba: '#00B4D4'<br /> lineThick: 2<br /> textColor: '#00B4D4'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: null,referenceName: REG<br /> fillRgba: '#CADE5900'<br /> lineRgba: '#CADE59'<br /> lineThick: 2<br /> textColor: '#CADE59'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: null,referenceName: NAZ<br /> fillRgba: '#9F2B0000'<br /> lineRgba: '#9F2B00'<br /> lineThick: 2<br /> textColor: '#9F2B00'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: null | true |
| enable_move_vertex | enable the possibility to "move vertex" in ui | Boolean | false | true | true |
| edit_status_to_exclude_from_stack_search | list of the "edit status" to exclude from stack search | EditStatus | true | null | true |
| cll_max_clear_time_min | maximum clear time (in mins) for party-parcels cache | Integer | false | 5 | true |
| temp_parcels_cache_max_clear_time_min | maximum clear time (in mins) for temporary parcels cache | Integer | false | 300 | true |
| fl_cll_history_load_holders | flag to enable holders column and query param in cll conductions history | Boolean | false | false | true |
| fl_disable_landcover_details_link | flag to disable landcover details link in farmaland viewer | Boolean | false | false | true |
| mock_farmland_viewer_parcel_list | flag to enable a mocked response in parcel conductors list read from lpis_mock_party_parcels table | Boolean | false | false | false |
| mocked_conductors_list_json | temporary key as json in a string to force a different conductors list for mocked consistency response | String | false | [] | false |
| editor_commands | Editor Commands configuration, if not defined the command will be visible | EditorConfiguration | false | full_page: true<br /> full_screen: true<br /> info_gis: true<br /> measure: true<br /> parcels:<br />   create: true<br />   edit: true<br />   cut: true<br />   cut_out: true<br />   merge: true<br />   delete: true<br />   linear_elements: true<br />   buffer: true<br />   use_available: true<br />   edit_data: true<br /> land_covers:<br />   create: true<br />   edit: true<br />   cut: true<br />   cut_out: true<br />   merge: true<br />   delete: true<br />   linear_elements: true<br />   buffer: true<br />   use_available: true<br />   edit_data: true<br /> units:<br />   create: true<br />   edit: true<br />   delete: true | true |
| parcel_landcover_one_to_one | Each parcel is always fully covered by only one landcover | Boolean | false | false | true |
| landcover_origin_catalogue_code | Catalogue code to use for landcovers data and geoms, if not null enables reading of data from the catalog and disables direct editing of landcovers | String | false | - | true |
| fl_calc_third_session_level | Flag to enable/disable the third level of interactions for parcel session calc (the orange one in docs/readme...) | Boolean | false | true | false |
| fl_allow_null_edit_category | If true, in save session, the fielad edit category is not mandatory | Boolean | false | true | true |
| :wastebasket: | - | - | - | - | - |
| default_parcels_line_thick | :wastebasket: (deprecated) parcels line thick for layer | Integer | false | 2 | true |
| default_parcels_line_rgba | :wastebasket: (deprecated) parcels line rgba color for layer | String | false | #B2B2B2 | true |
| default_parcels_fill_rgba | :wastebasket: (deprecated) parcels fill rgba color for layer | String | false | #B2B2B200 | true |
| default_parcels_label_color | :wastebasket: (deprecated) parcels label rgba color for layer | String | false | #000000 | true |
| default_parcels_label_size | :wastebasket: (deprecated) parcels label size in pixels for layer | Integer | false | 15 | true |
| default_landcovers_label_color | :wastebasket: (deprecated) land covers label color for layer | String | false | #CACACA | true |
| default_landcovers_label_size | :wastebasket: (deprecated) land covers label size for layer | Integer | false | 15 | true |
| default_landcovers_line_thick | :wastebasket: (deprecated) land covers line thick in pixels for layer | Integer | false | 1 | true |
| default_landcovers_line_rgba | :wastebasket: (deprecated) land covers line rgba color for layer | String | false | #CACACA55 | true |
| default_landcovers_fill_rgba | :wastebasket: (deprecated) land covers fill rgba color for layer | String | false | #CACACA44 | true |
| default_sde_parcels_line_thick | :wastebasket: (deprecated) external source parcels line thick for layer | Integer | false | 2 | true |
| default_sde_parcels_line_rgba | :wastebasket: (deprecated) external source parcels line rgba color for layer | String | false | #C70404 | true |
| default_sde_parcels_fill_rgba | :wastebasket: (deprecated) external source parcels fill rgba color for layer | String | false | #B2B2B200 | true |
| default_sde_parcels_label_color | :wastebasket: (deprecated) external source parcels label color for layer | String | false | #C70404 | true |
| default_sde_parcels_label_size | :wastebasket: (deprecated) external source parcels label size for layer | Integer | false | 15 | true |
| default_sectors_line_thick | :wastebasket: (deprecated) sectors line thick for layer | Integer | false | 2 | true |
| default_sectors_line_rgba | :wastebasket: (deprecated) sectors line rgba color for layer | String | false | #FFC0CB | true |
| default_sectors_fill_rgba | :wastebasket: (deprecated) sectors fill rgba color for layer | String | false | #FFC0CB00 | true |
| default_sectors_label_color | :wastebasket: (deprecated) sectors label color for layer | String | false | #FFC0CB | true |
| default_sectors_label_size | :wastebasket: (deprecated) sectors label size for layer | Integer | false | 15 | true |
| default_sector_blocks_line_thick | :wastebasket: (deprecated) blocks line thick for layer | Integer | false | 2 | true |
| default_sector_blocks_line_rgba | :wastebasket: (deprecated) blocks line rgba color for layer | String | false | #FEDE00 | true |
| default_sector_blocks_fill_rgba | :wastebasket: (deprecated) blocks fill rgba color for layer | String | false | #FEDE0000 | true |
| default_sector_blocks_label_color | :wastebasket: (deprecated) blocks label color for layer | String | false | #FEDE00 | true |
| default_sector_blocks_label_size | :wastebasket: (deprecated) blocks label size for layer | Integer | false | 15 | true |
| default_areas_line_thick | :wastebasket: (deprecated) areas line thick for layer | Integer | false | 2 | true |
| default_areas_line_rgba | :wastebasket: (deprecated) areas line rgba color for layer | String | false | #C70404 | true |
| default_areas_fill_rgba | :wastebasket: (deprecated) areas fill rgba color for layer | String | false | #B2B2B200 | true |
| default_areas_label_color | :wastebasket: (deprecated) areas label color for layer | String | false | #C70404 | true |
| default_areas_label_size | :wastebasket: (deprecated) areas label size for layer | Integer | false | 15 | true |




### Additional external links
The additional-external-links JSON file(s) is used for insert/update external links and i18n tables and must have the following structure:
```
{
  "additional_external_links":
    [
    	{
	      "module": "String" (mandatory)",
		  "view": "String" (mandatory)",
		  "type": "String" (mandatory)",
		  "code": "String" (mandatory)",
		  "url": "String" (mandatory)",
	      "name_description" (mandatory) : {
				"String" : "String",
				...
			},
		  "title_description" (mandatory) : {
				"String" : "String",
				...
		    },
		  "fl_visible" : Boolean (mandatory),
		  "display_order" : Integer (mandatory)
    	}
    ]
}
```

`Additional external links`:

- `module`: the module name where the external link is visible (values: LPIS_EDITOR | LPIS_VIEWER | FARMLAND_VIEWER)
- `view`: the frontend view code where the link is to be displayed (values: PARCELS | LANDCOVERS)
- `type`: the external link view type (values: BUTTON | OUTLINED_BUTTON)
- `code`: the external link code for i18n values
- `url`: the external link url
- `name_description`: map of language/descriptions in i18n format to use for insert/update code in i18n table for the external link name\
- `title_description`: map of language/descriptions in i18n format to use for insert/update code in i18n table for the external link title
- `fl_visible`: if true the external link is visible, default is true
- `display_order`: the display order position of external links

### Land covers and land uses codes

The landcovers-codes and landuses-codes JSON file(s) is used for insert/ update codes in landcover, landuses and i18n tables and must have the following structure:
```
{
  "codesList":
    [
    	{
	      "code": "String (mandatory)",
	      "descriptions" (mandatory) : {
				"String" : "String",
				...
			}
    	}
    ]
}
```

`Landcovers and Landuses values`:

- `code`: code of landcover or landuses to insert/update in landcover, landuses and i18n tables
- `descriptions`: map of language/descriptions in i18n format to use for insert/update code in i18n table

### Landcover configs
### Landcover Configs

The landcover configuration JSON files are used to insert, update, or delete records in the `lpis_landcover_configs` table.

#### Insert/Update

Files used for insert/update operations must follow the structure below:

```json
{
  "land_cover_configs": [
    {
      "land_cover_code": "String (mandatory)",
      "key": "String (mandatory)",
      "value": "String"
    }
  ]
}
```

#### Delete
Files ending with ".delete.json" are used to delete landcover configurations. Their structure must be:
```json
{
  "land_cover_configs": [
    {
      "land_cover_code": "String (mandatory)",
      "key": "String (mandatory)"
    }
  ]
}
```
`Landcover config values`:
- `land_cover_code`: the code of landcover
- `key`: The configuration key to insert/update/delete in the lpis_landcover_configs table.
Currently supported values: `SAVE_FORBIDDEN`, `EDIT_FORBIDDEN`
- `value`: The value of the configuration

### Catalogues

The catalogues JSON file(s) is used for insert/ update catalogues and i18n tables and must have the following structure:
```
{
  "catalogueList":
    [
    	{
	      "code": "String (mandatory)",
	      "type": "String (mandatory)",
	      "srs": "String (mandatory)",
	      "displayOrder": "Integer (mandatory)",
	      "visible": "Boolean",
	      "description": {
	      	"String" : "String",
	      	...
	      },
		  "params": {
	      	"String" : "String",
	      	...
	      }
		}
	]
}
```
catalogues file(s) end with ".delete.json" is used for delete catalogues tables entries and must have the following structure:
```
{
  "catalogueList":
    [
    	{
	      "code": "String (mandatory)",
	      "srs": "String (mandatory)"
		}
	]
}
```

`Catalogues values`:

- `code`: code of catalogue to insert/update in lpis_catalogues table
- `type`: The type of catalogue (one of: INTERNAL, SDE, CROP_PLAN, VECTOR_DATA_LAYERS)
- `srs`: the spatial reference system of the catalogue (if '*' valid for all srs)
- `display_order`: the display order position of catalogue
- `visible`: if true the catalogue is visible (default: true)
- `description`: map of lang and description for wms_server to insert/update in i18n table
- `params`: map of default query params for catalogue

#### **_Notes for catalogues_**

For certain internal catalogues, translations for additional fields are available. Currently, translations are only provided for the internal catalogue `INTERNAL:MOBILE_PARCELS`. These translations are stored in the `lpis_i18n_values` table via auto-bundles.

They follow this structure:
- **Table name**: `lpis_catalogues`
- **Field**: `code`
- **Values**: `"parcel_code"`, `"area_sqm"`, `"land_covers"`

Each value is prefixed with the catalogue code using the following format:  
`<catalogueCode>:<value>`  
For example:  
`INTERNAL:MOBILE_PARCELS:parcel_code`,  
`INTERNAL:MOBILE_PARCELS:area_sqm`,  
`INTERNAL:MOBILE_PARCELS:land_covers`.


### Layers

The layers JSON file(s) is used for insert/ update wms_servers, wms_layers, wms_modules, wms_permission and i18n tables and must have the following structure:
```
{
  "wms_servers":
    [
    	{
	      "code": "String (mandatory)",
	      "display_order": "Long (mandatory)",
	      "url": "String (mandatory)",
	      "format": "String (mandatory)",
	      "srs": "String (mandatory)",
	      "server_type": "String (mandatory)",
	      "color": "String (mandatory)",
	      "transparent": "Integer (mandatory)",
	      "icon_url": "String (mandatory)",
	      "modules": [
	      	{
	      		"module" : String (mandatory),
	      		"fl_on" : Boolean,
	      		"description": {
			      "String" : "String",
			      ...
			    }
	      	},
	      	...
	      ],
		  "areas": ["String"],
	      "permissions": ["String"],
	      "description": {
	      	"String" : "String",
	      	...
	      }
    	}
    ],
    "wms_layers":
    [
    	{
	      "wms_server_code": "String (mandatory)",
	      "display_order": "Long (mandatory)",
	      "code": "String (mandatory)",
	      "max_pixel_val": "Double (mandatory)",
	      "foreground_level": "Integer (mandatory)",
	      "layer_name": String,
	      "modules": [
	      	{
	      		"module" : String (mandatory),
	      		"fl_on" : Boolean,
	      		"description": {
			      "String" : "String",
			      ...
			    }
	      	},
	      	...
	      ],
	      "description": {
	      	"String" : "String",
	      	...
	      }
    	}
    ]
}
```
Layers file(s) end with ".delete.json" is used for delete wms_servers, wms_layers, wms_modules and wms_permission tables entries and must have the following structure:
```
{
  "wms_servers":
    [
    	{
	      "code": "String (mandatory)"
    	}
    ],
    "wms_layers":
    [
    	{
	      "wms_server_code": "String (mandatory)",
	      "code": "String (mandatory)"
    	}
    ],
   "permissions":
    [
    	{
	      "wms_server_code": "String (mandatory)",
	      "context_function": "String (mandatory)"
    	}
    ],
    "modules":
    [
    	{
	      "wms_server_code": "String (mandatory)",
	      "module": "String (mandatory)"
    	}
    ],
    "layer_modules":
    [
    	{
	      "wms_server_code": "String (mandatory)",
	      "wms_layer_code": "String (mandatory)",
	      "module": "String (mandatory)"
    	}
    ]
}
```

`Wms Server values`:

- `code`: code of wms_server to insert/update in wms_server table
- `display_order`: the display order position of wms_server
- `url`: the base url for wms requests
- `format`: the format of image type response of the wms server
- `srs`: the spatial reference system of the image
- `server_type`: the type of server response (WMS/WMTS/DBMAPWMSC...)
- `color`: the color parameter for the server request
- `transparent`: the transparent flag for the server request
- `icon_url`: the base url for wms requests
- `modules`: modules for wms server to insert in wms_layer_modules table, with flag to define if is enable or not and map of lang and description for wms_server to insert/update in i18n table
- `permissions`: permissions for wms server to insert in wms_permissions table
- `description`: map of lang and description for wms_server to insert/update in i18n table

`Wms Layer values`:

- `code`: code of wms_layer to insert/update in wms_layer table
- `wms_server_code`: the reference to the wms servers table
- `display_order`: the display order position of wms_layers
- `max_pixel_val`: max resolution for pixel
- `foreground_level`: the foreground flag for the layer, 0:background, 1:foreground, higher or lower(negative) numbers are possible for levels in different positions
- `layer_name`: name of layer, if is not define it is set with code value
- `modules`: modules for wms layers to insert in wms_layer_modules table, with flag to define if is enable or not and map of lang and description for wms_layer to insert/update in i18n table
- `description`: map of lang and description for wms_layers to insert/update in i18n table

`Wms Modules values`:

- `wms_server_code`: the reference to the wms servers table
- `module`: the module name where the wms server is visible

`Wms Layer Modules values`:

- `wms_server_code`: the reference to the wms servers table
- `wms_layer_code`: the reference to the wms layers table
- `module`: the module name where the wms layer is visible

`Wms Permissions values`:

- `wms_server_code`: the reference to the wms servers table
- `context_function`: sso context|function required to see this WMS server; if null every user can see this WMS server

### Data

The areas JSONL file is used for insert/update lpis_areas_hierarchies table and must have the following structure:
```
{"code": "String (mandatory)", "acronym" : "String (mandatory)", "description": "String (mandatory)", "parent_code": "String", "level": "String (mandatory)", "day_from": "AbsoluteDate", "day_to": "AbsoluteDate", "srs": "String", "geom": "Geometry", , "world_geom": "Geometry"}
...
```

`Areas values`:

- `code`: unique code of area to insert/ update
- `acronym`: acronym of area
- `description`: description of area
- `parent_code`: code of parent area, if exist
- `level`: level of area
- `day_from`: start date where area is enable, default is current date
- `day_to`: end date where area is enable, default is 99991231
- `srs`: The original shape's spatial reference system
- `geom`: The area original shape
- `world_geom`: The world area original shape, if is not define and srs and geom are defined, it will be calculate

The sector JSONL file is used for insert/update lpis_sectors and lpis_sector_details tables and must have the following structure:
```
{"code": "String (mandatory)", "description": "String (mandatory)", "short_descr": "String (mandatory)", "srs": "String (mandatory)", "geom": "Geometry (mandatory)"}
...
```

`Sector values`:

- `code`: code of sector to insert/update in lpis_sectors table
- `description`: description of sector
- `short_descr`: short description of sector
- `srs`: The original shape's spatial reference system
- `geom`: The sector detail's original shape

The sector_block JSONL file is used for insert/update lpis_sector_blocks and lpis_sector_block_details tables and must have the following structure:
```
{"block_code": "String (mandatory)", "sector_code": "String (mandatory)", "description": "String (mandatory)", "short_descr": "String (mandatory)", "srs": "String (mandatory)", "geom": "Geometry (mandatory)"}
...
```

`Block values`:

- `block_code`: code of block to insert/update in lpis_sector_blocks table
- `sector_code`: reference of sector code of block
- `description`: description of block
- `short_descr`: short description of block
- `srs`: The original shape's spatial reference system
- `geom`: The block detail's original shape

The sector_areas JSONL file is used for insert/update lpis_sector_areas table and must have the following structure:
```
{"area_code": "String (mandatory)", "sector_code": "String", "day_from": "AbsoluteDate", "day_to": "AbsoluteDate"}
...
```

`Sector area values`:

- `area_code`: reference of area
- `sector_code`: reference of sector
- `day_from`: start date where sector area is enable, default is current date
- `day_to`: end date where sector area is enable, default is 99991231

### External config

The external config JSON file(s) is used for insert/update lpis_external_config table and must have the following structure:
```
{
  "externalConfig":[
	    {
	      "key": "String (mandatory)",
          "value": "Object (mandatory)"
	    },
	    ...
    ]
}
```
External config file(s) end with ".delete.json" is used for delete lpis_external_config table entries and must have the following structure:
```
{
  "externalConfig":[
	    {
	      "key": "String (mandatory)"
	    },
	    ...
    ]
}
```

`External config values`:

- `key`: key of config to insert/update in lpis_external_config table
- `value`: value of config

### Anomaly categories

The anomaly categories JSONL file(s) is used for insert/update lpis_anomaly_categories table and must have the following structure:
```
{"group_code": "String (mandatory)", "code": "String (mandatory)" ,"level": "AnomalyLevel (mandatory)", "fl_exclude": "boolean"}
...
```
The anomaly categories end with ".delete.jsonl" file(s) is used for delete lpis_anomaly_categories entries and must have the following structure:
```
{"group_code": "String (mandatory)", "code": "String (mandatory)"}
...
```

`Anomaly categories values`:

- `group_code`: code group of anomaly categories
- `code`: code of anomaly categories
- `level`: level of anomaly, allowable values: DANGER, WARN, INFO
- `fl_exclude`: flag for exclude a category, default is false

### Matrixes

The matrixes JSON file(s) is used for insert/update lpis_matrix, lpis_matrix_classes, lpis_matrix_class_details, lpis_matrix_class_landcovers, lpis_matrix_class_landuses and lpis_matrix_compat tables and must have the following structure:
```
{
  "matrixes":[
	    {
	      "code": "String (mandatory)",
	      "classes": [
	      	{
	      		"code": "String (mandatory)",
	      		"day_from": "AbsoluteDate (mandatory)",
	      		"day_to": "AbsoluteDate (mandatory)",
	      		"default_land_cover_code": "String",
	      		"default_land_use_code": "String",
	      		"fill_rgba": "String (mandatory)",
	      		"line_rgba": "String (mandatory)",
	      		"line_thick": "Integer (mandatory)",
	      		"land_cover_codes": [
	      			{
	      				"code": "String (mandatory)",
			      		"day_from": "AbsoluteDate (mandatory)",
			      		"day_to": "AbsoluteDate (mandatory)"
	      			},
	      			...
	      		],
	      		"land_use_codes": [
	      			{
	      				"code": "String (mandatory)",
			      		"day_from": "AbsoluteDate (mandatory)",
			      		"day_to": "AbsoluteDate (mandatory)"
	      			},
	      			...
	      		],
	      		"extended_by_class": "String"
	      	}
	      ]
	    },
	    ...
    ]
}
```

`Matrixes values`:

- `code`: code of matrix
- `classes`: array of classes to insert
  - `code`: code of class
  - `day_from`: start date where class is enable
  - `day_to`: end date where class is disable
  - `default_land_cover_code`: default land cover code
  - `default_land_use_code`: default land use code
  - `fill_rgba`: rgba code of fill color
  - `line_rgba`: rgba code of line color
  - `line_thick`: line thick
  - `land_cover_codes`: array of land covers
  	- `code`: code of land cover
   	- `day_from`: start date where land cover class is enable
   	- `day_to`: end date where land cover class is enable
  - `land_use_codes`: level of anomaly, allowable values: DANGER, WARN, INFO
    - `code`: code of land cover
   	- `day_from`: start date where land use class is enable
   	- `day_to`: end date where land use class is enable
  - `extended_by_class`: class code who extend this class

### Matrix metadata

The matrix-metadata JSON file(s) is used for insert/update/delete lpis_matrix, lpis_matrix_class_metadata, lpis_matrix_landcovers_metadata and lpis_matrix_landuses_metadata and must have the following structure:
```
{
  "matrix_metadata_list":[
	    {
	      "matrix_code": "String (mandatory)",
	      "class_metadata_list": [
	      	{
	      		"class_code": "String (mandatory)",
				"key": "String (mandatory)",
	      		"value": "String",
	      		"day_from": "AbsoluteDate",
	      		"day_to": "AbsoluteDate"
	      	},
			...
	      ],
		  "land_cover_metadata_list": [
			{
				"land_cover_code" : "String (mandatory)",
				"class_code": "String (mandatory)",
				"key": "String (mandatory)",
	      		"value": "String",
	      		"day_from": "AbsoluteDate",
	      		"day_to": "AbsoluteDate"
			},
			...
		  ],
		  "land_use_metadata_list": [
			{
				"land_use_code" : "String (mandatory)",
				"class_code": "String (mandatory)",
				"key": "String (mandatory)",
	      		"value": "String",
	      		"day_from": "AbsoluteDate",
	      		"day_to": "AbsoluteDate"
			},
			...
		  ]
	    },
	    ...
    ]
}
```

`Matrix metadata values`:

- `matrix_code`: code of matrix
- `class_metadata_list`: array of class metadata to insert
  - `class_code`: code of class
  - `key`: Name of metadata entry
  - `value`: Value of metadata entry
  - `day_from`: start date where metadata entry is enable
  - `day_to`: end date where metadata entry is disable
- `land_cover_metadata_list`: array of land cover metadata to insert
  - `land_cover_code`: code of land cover
  - `class_code`: code of class
  - `key`: Name of metadata entry
  - `value`: Value of metadata entry
  - `day_from`: start date where metadata entry is enable
  - `day_to`: end date where metadata entry is disable
- `land_use_metadata_list`: array of land use metadata to insert
  - `land_use_code`: code of land use
  - `class_code`: code of class
  - `key`: Name of metadata entry
  - `value`: Value of metadata entry
  - `day_from`: start date where metadata entry is enable
  - `day_to`: end date where metadata entry is disable


### I18n

The i18n JSON file(s) is used for insert/ update i18n table and must have the following structure:
```
{
  "i18n_list": [
        {
            "table": "String (mandatory)",
            "field": "String (mandatory)",
            "value": "String (mandatory)",
            "translations": {
            	"String" : "String",  (mandatory)
            	...
            }
        },
        ...
    ]
}
```
I18n JSON file(s) end with ".delete.json" is used for delete i18n table entries.
If translations is set, delete only row for translation keys, all rows of table field otherwise. It must have the following structure:
```
{
  "i18n_list": [
        {
            "table": "String (mandatory)",
            "field": "String (mandatory)",
            "value": "String (mandatory)",
            "translations": {
            	"String" : "String",
            	...
            }
        },
        ...
    ]
}
```

`I18n values`:

- `table`: Table name of field
- `field`: Field name
- `value`: Value of field to translate
- `translations`: Map of lang and text for the field value

### Campaign

The campaign JSON file(s) is used for insert/update lpis_campaign table and must have the following structure:
```
{
  "campaign_list":[
	    {
	      "code": "String (mandatory)",
          "reference_date": "AbsoluteDate (mandatory)",
          "description": {
            	"String" : "String",
            	...
            }
	    },
	    ...
    ]
}
```
Campaign file(s) end with ".delete.json" is used for delete lpis_campaign table entries and must have the following structure:
```
{
  "campaign_list":[
	    {
	      "code": "String (mandatory)"
	    },
	    ...
    ]
}
```

`Campaign values`:

- `code`: code of campaign to insert/update in lpis_campaign table
- `reference_date`: reference date for code of campaign
- `description`: map of lang and description for lpis_campaign to insert/update in i18n table

### Edit category codes

The edit-category-codes JSON file(s) is used for insert/update lpis_edit_categories table and must have the following structure:
```
{
  "edit_category_codes":[
	    {
	      "code": "String (mandatory)",
          "fl_visible": "Boolean (mandatory)",
          "description": {
            	"String" : "String",
            	...
            }
	    },
	    ...
    ]
}
```
`edit-category-codes values`:

- `code`: code of edit category to insert/update in lpis_edit_categories table
- `fl_visible`: if true the edit category is visible in the search, default is true
- `description`: map of lang and description for lpis_edit_categories to insert/update in i18n table

### Units

The units JSON file(s) is used for insert/update/delete lpis_landcover_unit_types table and must have the following structure:
```
{
  "land_cover_unit_types":[
	    {
	      "land_cover_code": "String (mandatory)",
          "type_code": "String (mandatory)"
	    },
	    ...
    ]
}
```
`unit values`:

- `land_cover_code`: code of land cover
- `type_code`: compatible unit type code (values: VINE_UNIT)

### Vine units

The units JSON file(s) is used for insert/update various vine units codes table and must have the following structure:
```
{
  "farming_forms":[
	    {
	      "code": "String (mandatory)",
          "fl_visible": "Boolean",
          "description": {
            	"String" : "String",
            	...
            }
	    },
	    ...
    ],
	"cultivation_status":[ (same as farming_forms)   ],
	"header_anchoring_codes":[ (same as farming_forms)   ],
	"irrigation_types":[ (same as farming_forms)   ],
	"poles_header_codes":[ (same as farming_forms)   ],
	"poles_weaving_codes":[ (same as farming_forms)   ],
	"product_destination_codes":[ (same as farming_forms)   ],
	"support_wires_codes":[ (same as farming_forms)   ],
	"terracing_codes":[ (same as farming_forms)   ],
	"variation_types":[ (same as farming_forms)   ],
	"variety_codes":[ (same as farming_forms)   ],
	"vineyard_codes":[ (same as farming_forms)   ],
	"vine_doigt_codes": [
		{
			"code": "String (mandatory)",
			"category_code": "String (mandatory)",
			"name_code": "String (mandatory)",
			"fl_visible": "Boolean,
			"code_description": {
				"String": "String",
				...
			},
			"category_code_description": {
				"String": "String",
				...
			},
			"name_code_description": {
				"String": "String",
				...
			}
		}
	]
}
```
`Vine unit values`:

- `code`: code of land cover
- `fl_visible`: if true the code is visible in the search, default is true
- `description`: map of lang and description for vine unit codes to insert/update in i18n table

`vine_doigt_codes`:
- `code`: code of vine doigt
- `category_code`: the code category of vine aptitude
- `name_code`: The code for the vine aptitude name
- `fl_visible`: if true the code is visible in the search, default is true
- `code_description`: map of lang and description for doigt codes to insert/update in i18n table
- `category_code_description`: map of lang and description for doigt category codes to insert/update in i18n table
- `name_code_description`: map of lang and description for doigt name codes to insert/update in i18n table

### Vineyard doigt

The vinyard-doigt JSON file(s) is used for insert/update/delete lpis_unit_vineyard_doigt_links table and must have the following structure:
```
{
  "vineyard_doigt_links":[
	    {
	      "doigt_code": "String (mandatory)",
          "vineyard_code": "String (mandatory)"
	    },
	    ...
    ]
}
```
`Vineyard doigt values`:

- `doigt_code`: code of doigt
- `vineyard_code`: code of vineyard

### Olive units

The units JSON file(s) is used for insert/update various olive units codes table and must have the following structure:
```
{
  "farming_forms":[
	    {
	      "code": "String (mandatory)",
          "fl_visible": "Boolean",
          "description": {
            	"String" : "String",
            	...
            }
	    },
	    ...
    ],
	"irrigation_types":[ (same as farming_forms)   ],
	"product_destination_codes":[ (same as farming_forms)   ],
	"variety_codes":[ (same as farming_forms)   ],
	"planting_type_codes":[ (same as farming_forms)   ],
	"quality_system_codes":[ (same as farming_forms)   ],
	"protection_structure_codes":[ (same as farming_forms)   ]
}
```
`Olive unit values`:

- `code`: code of land cover
- `fl_visible`: if true the code is visible in the search, default is true
- `description`: map of lang and description for vine unit codes to insert/update in i18n table

### Fruit units

The units JSON file(s) is used for insert/update various fruit units codes table and must have the following structure:
```
{
  "farming_forms":[
	    {
	      "code": "String (mandatory)",
          "fl_visible": "Boolean",
          "description": {
            	"String" : "String",
            	...
            }
	    },
	    ...
    ],
	"irrigation_types":[ (same as farming_forms)   ],
	"variety_codes":[ (same as farming_forms)   ],
	"planting_type_codes":[ (same as farming_forms)   ],
	"quality_system_codes":[ (same as farming_forms)   ],
	"protection_structure_codes":[ (same as farming_forms)   ]
}
```
`Fruit unit values`:

- `code`: code of land cover
- `fl_visible`: if true the code is visible in the search, default is true
- `description`: map of lang and description for vine unit codes to insert/update in i18n table


## EMBEDDED WMS SERVER

The embedded wms server respond on '/wms'

### PARCEL LAYER

Layer name: 'PARCELS' parameters:
- `tenant`: (String) the tenant
- `reference_date`: (AbsoluteDate) the reference date for parcels search
- `session_id`: (String) the session id to filter out on parcels search, when not null
- `srs`: (String) the srs to use in parcels search
- `sector_code`: (String) the sector_code to use in parcels search if setted the srs is ignored

example call:
with srs:
https://iacs-dev.fe.abacogroup.eu/lpis-server-api/wms?SERVICE=WMS&REQUEST=GetMap&FORMAT=image/png&LAYERS=PARCELS&BBOX=1761887.8360069303,5154507.205460707,1765800,5157200&WIDTH=1453&HEIGHT=1000&tenant=master&srs=EPSG%3A3003&reference_date=20221007

or with sector_code:
https://iacs-dev.fe.abacogroup.eu/lpis-server-api/wms?SERVICE=WMS&REQUEST=GetMap&FORMAT=image/png&LAYERS=PARCELS&BBOX=1761887.8360069303,5154507.205460707,1765800,5157200&WIDTH=1453&HEIGHT=1000&tenant=master&reference_date=20221007&sector_code=E141
