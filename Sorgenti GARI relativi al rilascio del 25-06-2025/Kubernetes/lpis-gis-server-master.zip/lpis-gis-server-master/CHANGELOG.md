# LPIS GIS SERVER

# Changelog

[README](README.md)

## [v1.16.4](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.16.3...v1.16.4) (2025-06-26)

### Features

* :sparkles: add stack_id in save session api response, closes [#181290](https://abacogroup.easyredmine.com/issues/181290)

### Fixes

* :bug: added a try catch in insert query in CachePartyParcelsDAO
* :bug: fixed insert query in CachePartyParcelsDAO
* :bug: fixed bug in party parcels cache
* :bug: fixed getParcelLandCoversFromCatalogue in ParcelsService and ViewerService
* :bug: fixed a bug in FarmLandViewerService, closes [#181060](https://abacogroup.easyredmine.com/issues/181060)

### Other

* :recycle: some refactor in FarmLandViewerService
* :fire: removed duplicate method in FarmLandViewerService

## [v1.16.3](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.16.2...v1.16.3) (2025-06-18)

### Features
* :card_file_box: added spatial indexes for lpis_external_source_data and lpis_areas_hierarchies tables, closes [#178350](https://abacogroup.easyredmine.com/issues/178350)


## [v1.16.2](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.16.1...v1.16.2) (2025-06-13) wait if it's slow

### Features
* **helm:** :zap: increase proxy timeout while performance optimization is pending

### Fixes
* :bug: better error message for forbidden operations, closes [#170917](https://abacogroup.easyredmine.com/issues/170917)
* :bug: fix long-standing permission issue in parcel stack APIs, closes [#154445](https://abacogroup.easyredmine.com/issues/154445)


### [v1.16.1](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.16.0...v1.16.1) (2025-06-12)

### Features
* :sparkles: added new check for forbidden edit landcover codes, closes [#178832](https://abacogroup.easyredmine.com/issues/178832)
* :sparkles: added new check for forbiden save landcovers in save session, closes [#170917](https://abacogroup.easyredmine.com/issues/170917)
* :sparkles: added LandCoverConfigMessageProcessor

### Fixes
* :bug: fixed name in auto bundles

### Documentation
* :memo: update README.md


## [v1.16.0](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.15.7...v1.16.0) (2025-06-10) Cross Tenant Search


### Fixes
* :bug: fix a little issue in catalogue landcover id parse


### [v1.15.8](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.15.7...v1.15.8) (2025-06-09)

:technologist: actually this is a prerelease for 1.16.0, use that version

### Features
* **catalogues:** :sparkles: move internal catalogues from enum to catalogues table loaded as autobundle, closes [#178471](https://abacogroup.easyredmine.com/issues/178471)
* :sparkles: implement cross tenant parcel search apis, closes [#178798](https://abacogroup.easyredmine.com/issues/178798)
* :sparkles: added NewMatrixBundleProcessor, closes [#173647](https://abacogroup.easyredmine.com/issues/173647)
* :sparkles: added new internal catalogue (MOBILE_PARCELS)

### Fixes
* :bug: fixed CatalogueGeomMappings
* :bug: fixed sort order in CatalogueGeomMappings
* :bug: fixed catalogue payload for public api
* :recycle: fixed a sonar issue
* **matrix:** :card_file_box: update matrix landuse and landcover index for multi dates ranges validity, closes [#173647](https://abacogroup.easyredmine.com/issues/173647)

### Other
* use conditional helm variable definition for CROSSTENANT_LPIS_APIKEY
* **ci:** :green_heart: implement "build" tag for test and sonar jobs
* **ci:** :green_heart: implement "build" tag for build jobs

### Documentation
* :memo: update cross tenant search info in readme, closes [#177292](https://abacogroup.easyredmine.com/issues/177292)
* :memo: update README.md


### [v1.15.7](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.15.6...v1.15.7) (2025-05-16) over the top

### Features
* :sparkles: implement a new param in stack apis view_all_edit_status to avoid the filter in the result

### Fixes
* :bug: fix public get parcel landcover list API, closes [#143174](https://abacogroup.easyredmine.com/issues/143174)
* :bug: fix CXF file temporary directory permissions

### Documentation
* :memo: fix case in some sample bundles, closes [#164597](https://abacogroup.easyredmine.com/issues/164597)


### [v1.15.6](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.15.5...v1.15.6) (2025-05-02) FIX Sonar AGEA

### Fixes
* :bug: fix sonar agea issues

## [v1.15.5](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.15.4...v1.15.5) (2025-04-18) FIX Regression

### Fixes
* :bug: fix regression in not in edit parcels search query, closes [#172855](https://abacogroup.easyredmine.com/issues/172855) [#171084](https://abacogroup.easyredmine.com/issues/171084)

### [v1.15.4](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.15.3...v1.15.4) (2025-04-11) fix the fixes

### Fixes
* :bug: fix units details search
* **bulk:** :bug: fix, or really implement, bulk upload for units validations dates, closes [#171084](https://abacogroup.easyredmine.com/issues/171084)
* :bug: fix issue in not in edit parcels search, closes [#171084](https://abacogroup.easyredmine.com/issues/171084)

### Other
* :loud_sound: better log description for unitcode plugin
* :arrow_up: upgrade lombok dep
* :arrow_up: upgrade abaco jdbi dep
* :arrow_up: upgrade geometry editor dep



### [v1.15.3](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.15.2...v1.15.3) (2025-04-07) fix performance

### Fixes
* **plugins:** :bug: fix plugin name decode for searches, closes [#169990](https://abacogroup.easyredmine.com/issues/169990)
* **plugins:** :zap: improve create parcel name plugin performance, closes [#170073](https://abacogroup.easyredmine.com/issues/170073)
* **units:** :bug: set a default button configuration for not unique unit code renew func for all variants, closes [#162305](https://abacogroup.easyredmine.com/issues/162305)

### Other
* **units:** :memo: better description for fix unique unit name button


### [v1.15.2](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.15.1...v1.15.2) (2025-04-03) apocalypse

### Features
* **config:** :sparkles: add fl_disable_landcover_details_link config variable, closes [#170295](https://abacogroup.easyredmine.com/issues/170295)

### Fixes
* **units:** :bug: set a default button configuration for not unique unit code renew func, closes [#162305](https://abacogroup.easyredmine.com/issues/162305)
* **plugins:** :bug: fix little issue in parcel auto numeration plugin, closes [#170296](https://abacogroup.easyredmine.com/issues/170296)
* **catalogues:** :bug: fix roundig area value loaded from catalogue service, closes [#169985](https://abacogroup.easyredmine.com/issues/169985)
* **sessionCheck:** :bug: fis issue in not skipped check in session anomalies check, closes [#169971](https://abacogroup.easyredmine.com/issues/169971)
* **dao:** :bug: fix typo in stack olive units dao
* :bug: fixed internl unit code plugin, closes [#169949](https://abacogroup.easyredmine.com/issues/169949)
* :bug: fix issue in additional external link mapper

### Other
* :memo: update readme
* :memo: update readme config variables descriptions



### [v1.15.1](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.15.0...v1.15.1) (2025-03-28)

### Fixes
* :bug: in unit search in parcelsDAO
* :bug: fix srs value in env when null



## [v1.15.0](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.15.0...v1.14.29) (2025-03-25) Validation dates and unit code update

### Features

* :sparkles: added new public and private apis to get Unit by Unit code
* :construction: added query to remove all future versions of a unit by code
* :construction: work in progress
* :sparkles: added http_verb column to lpis_additional_external_links table
* :construction: implemeted new unitCode provider
* :construction: moved unit code to unit detail tables and added new plugin configuration for generating unit codes (work in progress)
* :construction: added validation dates to olive and fruit units
* :construction: fixed some stack issues
* :construction: added validation dates to vine units

### Fixes

* :recycle: fix a little reference in area provider search by sector
* :bug: fixed parentUnitCode bug
* :bug: fixed bug in AreaProvider
* **Areas:** :bug: fix query for areaprovider plugin
* :bug: fixed bug in update units
* :bug: fixed bug in save session units
* :bug: fix possible null srs in catalogue landcover search
* :bug: fix area search in areaProvider
* :bug: fixed landcover pkid in unit stacks
* :bug: fixed parent unit code issue
* :bug: fixed some queries

### Other

* :recycle: import cleanup
* :arrow_up: upgrade to jre 21 in Dockerfile


### [v1.14.29](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.28...v1.14.29) (2025-03-14) LPIS pi edition

### Features
* :sparkles: implement min_intersection_area_sqm query param for public parcels search api, closes [#167822](https://abacogroup.easyredmine.com/issues/167822)

### Documentation
* **openapi:** :recycle: refactor on openapi tags definitions



## [v1.14.28](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.27...v1.14.28) (2025-02-24) search your areas

### ⚠ BREAKING CHANGE

* in areas API endpoint with "area_id" have been replaced by "area_code"


### Features
* :boom: :sparkles: use area code in api searches instead of id
* :sparkles: added new public apis for areas searches and details, closes [#164406](https://abacogroup.easyredmine.com/issues/164406)
* **wms:** add support for non-polygon parcel styles in WMS configuration
* :sparkles: add include_geomatries query param in public, and private, areas search api, closes [#164406](https://abacogroup.easyredmine.com/issues/164406)

### Fixes
* :bug: a lot better areas search performance, closes [#164406](https://abacogroup.easyredmine.com/issues/164406)
* :bug: add include_anomalies in public parcel detail api, closes [#162793](https://abacogroup.easyredmine.com/issues/162793)
* :bug: added tenant filter in search area query
* **editor:** ensure only Polygon geometries are processed in parcel topology collection
* **editor:** GeometryCollection considered unmodifiable

### Other
* :arrow_up: upgrade ababo jdbi to v2.18.0
* :recycle: refactor double definited variable also in supportenv



## [v1.14.27](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.26...v1.14.27) (2025-02-06) is there any cover?

### Fixes
* **sessions:** :bug: fix error session check for total lancover area calc, closes [#163412](https://abacogroup.easyredmine.com/issues/163412)


### [v1.14.26](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.25...v1.14.26) (2025-01-31) anomalies everywhere

### Fixes
* **anomalies:** :bug: fix error in some anomalies retrival in units summaries, closes [#162793](https://abacogroup.easyredmine.com/issues/162793)


### [v1.14.25](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.24...v1.14.25) (2025-01-29)

#### Other
* :recycle: a good refactor for our friend agea sonar


### [v1.14.24](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.23...v1.14.24) (2025-01-24)

#### Fixes
* **session:** :bug: fix issue in landcover area check
* :bug: fix srs on getGeomInfoFromCatalogue

#### Other
* :recycle: a good refactor for our friend agea sonar


### [v1.14.23](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.22...v1.14.23) (2025-01-13)

### Features

* **wms:** :sparkles: new config param fl_hide_landcovers_wms to hide landcovers wms, closes [#159444](https://abacogroup.easyredmine.com/issues/159444)
* **wms:** :sparkles: implement landcovers wms intersection with catalogue, closes [#159444](https://abacogroup.easyredmine.com/issues/159444)

### Other

* :recycle: update matric classes for matrix generator utility
* :recycle: some minor refactor

### Documentation

* :memo: update README.md

### [v1.14.22](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.21...v1.14.22) (2024-12-23)

### Features

* :sparkles: initial support to not null edit category in save session, closes [#160284](https://abacogroup.easyredmine.com/issues/160284), [#160283](https://abacogroup.easyredmine.com/issues/160283)

### Other

* :recycle: refactor imports

### Documentation

* :memo: update README.md and added some error bundles


### [v1.14.21](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.20...v1.14.21) (2024-12-23) Typo Fix

### Fixes
* :pencil2: fix typo in getparcels dao

### [v1.14.20](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.19...v1.14.20) (2024-12-23)

### Features
* :sparkles: implement sector decodes bundle import, closes [#158574](https://abacogroup.easyredmine.com/issues/158574)

### Other
*  :arrow_up: upgrade dropwizard with protocolUpgradeEnabled false


### [v1.14.19](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.18...v1.14.19) (2024-12-19)

### Fixes
* :bug: fix error in catalogue geomteries intersections with null geom

### [v1.14.18](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.17...v1.14.18) (2024-12-18)

### Fixes
* **config:** :bug: :pencil2: fix error in fl_hide_cll default value


### [v1.14.17](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.16...v1.14.17) (2024-12-18)

### Fixes
* :bug: fixed getParcelsByUnitTypeAndVarietyCode query in ParcelsDAO

### [v1.14.16](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.15...v1.14.16) (2024-12-16)

### Features
* **config:** :sparkles: implement fl_hide_cll configuration, closes [#159405](https://abacogroup.easyredmine.com/issues/159405)

### Fixes
* :bug: fixed olive unit summary queries

### Other
* :recycle: refactor on internal classes

### [v1.14.15](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.14...v1.14.14) (2024-12-16)

### Fixes
* :bug: fixed bug in getParcelsByUnitTypeAndVarietyCode query, closes [#155520](https://abacogroup.easyredmine.com/issues/155520) [#147992](https://abacogroup.easyredmine.com/issues/147992)
* :bug: fixed bug in SectorSummaryMappings and VarietySummaryMappings

### [v1.14.14](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.13...v1.14.14) (2024-12-13) Load cxf

### Features
* **cxf:** :sparkles: implement cxf file import API, closes [#158574](https://abacogroup.easyredmine.com/issues/158574)


### [v1.14.13](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.12...v1.14.13) (2024-12-09) Fix the fruits basket

### Fixes
* :bug: fix issue in fruit gis server definition values
* **staks:** :bug: fix null in parcels stakid rabbit message
* **internalService:** :bug: avoid exception when reproiect world geom is invalid
* :bug: fix issue in random generation (sonar)

### Other
* :recycle: refactor ExternalParcelsSourceDataService class name
* :recycle: fix imports
* :recycle: clean up unusued code
* :bug: fix issue in external source description i18n


### [v1.14.12](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.11...v1.14.12) (2024-11-25)

#### Features

* :sparkles: added new public api to find block by geom
* :sparkles: added new apis for sector and variety summary for fruit and olive units, [#147992](https://abacogroup.easyredmine.com/issues/147992)

#### Fixes

* :bug: fixed typo in UnitsDAO
* :bug: fix performance query in get parcels with interactions
* :bug: fix issue in geometries reset when catalogue landcover is set
* :bug: fix issue with date conversion in parcels from catalogue
* :bug: fix issue with date conversion in viewer parcels

#### Other

* :bug: set default lastupdate date from landcovers catalogue data to 1970-1-1

### [v1.14.11](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.10...v1.14.11) (2024-11-22)

#### Fixes

* :bug: fixed StackParcelV1Mapper
* :bug: fixed error in getVineAptitudesSummary, closes [#157296](https://abacogroup.easyredmine.com/issues/157296)
* :recycle: fix some join in i18n
* :bug: add missing lancovers data for public parcels api

#### Other

* :recycle: refactor query in EditSessionDao
* :arrow_up: upgrade abaco tracing utils to v4.3.0
* :arrow_up: upgrade abaco jdbi to v2.17.2

### [v1.14.10](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.9...v1.14.10) (2024-11-15)

#### Fixes

* :bug: fix issue on user id

### [v1.14.9](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.8...v1.14.9) (2024-11-14)

#### Other

* :arrow_up: upgrade simple wms 4j to v6.0.0

### [v1.14.8](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.7...v1.14.8) (2024-11-12) Go Forrest Go

### Features
* **sessions:** :sparkles: implement new config key fl_calc_third_session_level for simplified lock session calc

### [v1.14.7](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.6...v1.14.7) (2024-11-12)

### Fixes
* **units:** :bug: fix error in units reorder


### [v1.14.6](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.5...v1.14.6) (2024-11-12) pull me under

### Other
* :green_heart: fix issue in doc ci stage
* :arrow_down: downgrade tracing utils version to 4.1.0
* :arrow_down: downgrade abaco-jdbi version to 2.15.0
* :arrow_down: downgrade dropwizard to 4.0.8
* reconfigure pom source and target version to java 17


### [v1.14.5](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.4...v1.14.5) (2024-11-12) no more sso upgrade!!

### Features
* :sparkles: alternative numeration for catalogue landcover ids

### Other
* :green_heart: fix issue in doc ci stage
* **pom:** :arrow_down: downgrade abaco sso dependecy


### [v1.14.4](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.3...v1.14.4) (2024-11-11)

### Fixes
* Aptitudes summary: search only parcels under management (in conduzione), closes [#156154](https://abacogroup.easyredmine.com/issues/156154)
* :bug: add index on area_id for Area hierarchies table

### Other
* :arrow_up: upgrade java version for sona compatibility

### Documentation
* :arrow_up: upgrade schemaspy


### [v1.14.3](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.2...b8ca78e657948879c0e111901836919fa5a3ebaa) (2024-11-07)

### Fixes
* **landcovers:** :bug: fix date formatter


### [v1.14.2](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.1...v1.14.2) (2024-11-07) embedded long queue

### Features
* :sparkles: add last update info in public units response

### Fixes
* :bug: some minor fixes
* :bug: fix sort order of units, closes [#156148](https://abacogroup.easyredmine.com/issues/156148)
* :bug: fix aptitudes special sorting

### Other
* :arrow_up: upgrade embeded-db-queue to v1.16.0


### [v1.14.1](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.14.0...v1.14.1) (2024-11-06)

### Fixes
* :bug: added continuos landCover response from catalogue in viewer parcel details


## [v1.14.0](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.13.4...v1.14.0) (2024-10-30) don't touch me

### Features
* :sparkles: implement continuous landcover configuration, closes [#143071](https://abacogroup.easyredmine.com/issues/143071)
* :sparkles: implement parcel landcover one to one configuration, closes [#143071](https://abacogroup.easyredmine.com/issues/143071)

### Fixes
* :bug: fixed a bug in updateParcelDatad

### Other
* **utils:** :rocket: simple java program to create matrixes files
* **pom:** :arrow_up: upgrade swagger-jaxrs2 to v2.2.25
* **pom:** :arrow_up: upgrade org.mapstruct to v1.6.2
* **pom:** :arrow_up: upgrade lombok to v1.18.34
* **pom:** :arrow_up: upgrade crop-plan-sdk to v4.4.20
* **pom:** :arrow_up: upgrade embeded-db-queue to v1.15.1
* **pom:** :arrow_up: upgrade abaco-sso2 to v4.3.0
* **pom:** :arrow_up: upgrade bundles-infrastructure to v1.5.3
* **pom:** :arrow_up: upgrade abaco-tracing-utils to v4.3.0
* **pom:** :arrow_up: upgrade abaco-jdbi to v2.17.2
* **pom:** :arrow_up: upgrade dropwizard to v4.0.10
* **pom:** :arrow_up: upgrade geometry-editor to v2.4.14
* **pom:** :arrow_up: upgrade geometry-editor to v2.4.14
* **conf:** :recycle: refactor configs keys

### Documentation
* **bundles:** :memo: sample bundles for contiunuos soil conf
* :memo: improved editor command conf key description
* :memo: todo document for "suolo in continuo"
* :memo: add analisys documentation file



### [v1.13.4](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.13.2...v1.13.4) (2024-10-23) my real name

### Fixes
* **migration:** :bug: fix issue in migration name sorting

#### [v1.13.3] error in migrations do not use


### [v1.13.2](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.13.1...v1.13.2) (2024-10-17)

### Fixes
* :bug: fixed a bug in updateParcelData in editor which caused the re-import of landcovers when renaming a parcel in editing


### [v1.13.1](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.13.0...v1.13.1) (2024-10-11) my parcel campaign

### Features
* **config:** :sparkles: add new configuration for editor buttons disable flags, for future implementation in #143071

### Fixes
* **stacks:** :bug: add campaign in stack for parcels history
* **bundles:** :bug: fix internal config bundle value load for correct json valutation

### Other
* **utils:** :rocket: improve get config keys description utility usability
* fix changelog

### Documentation
* :memo: sample bundle


## [v1.13.0](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.12.6...v1.13.0) (2024-10-07) olives and fruits

### Features
* :sparkles: implement olive and fruit units data type, closes [#150732](https://abacogroup.easyredmine.com/issues/150732) [#150730](https://abacogroup.easyredmine.com/issues/150730)

### Other
* :arrow_up: upgrade bundles infrastructure to version 1.5.2
* :arrow_up: upgrade dropwizard version to 4.0.8
* :fire: removed unused code
* :green_heart: reconfigure CI for multi variant, closes [#150730](https://abacogroup.easyredmine.com/issues/150730) [#150732](https://abacogroup.easyredmine.com/issues/150732)


### [v1.12.6](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.12.5...v1.12.6) (2024-10-01) fix fix

### Fixes
* :bug: fix issue in handling flag include anomalies, closes [#153201](https://abacogroup.easyredmine.com/issues/153201)


### [v1.12.5](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.12.4...v1.12.5) (2024-09-27) re-catlogues srs

### Fixes
* **catalogues:** :bug: fix filter srs in catalogues search

### [v1.12.4](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.12.3...v1.12.4) (2024-09-27)

### Fixes
* **catalogues:** :bug: fix checkCatalogeCode on layers processor

### [v1.12.3](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.12.2...v1.12.3) (2024-09-26) catlogues srs

### Fixes
* **catalogues:** :bug: fix filter srs in catalogues search

### [v1.12.2](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.12.1...v1.12.2) (2024-09-25) vector catalogs

### Fixes
* :bug: fix catalogues param in caller services


## [v1.12.1](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.12.0...v1.12.1) (2024-09-25)

### Fixes
* :bug: fix sonar agea issues

## [v1.12.0](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.11.13...v1.12.0) (2024-09-19) Postalmarket

### Prerequisites:
* anomaly-registry minimum version v4.0.4

### Features
* :sparkles: implement catagues service for snap and info gis for different types, closes [#145524](https://abacogroup.easyredmine.com/issues/145524)
   * catalogues data from internal layers
   * catalogues data from crop plan layers
   * catalogues data from vector data layers
* :sparkles: add anomalies for the vine unit
* :sparkles: add public stack resources and new api for get task
* :sparkles: added infoGis for internal catalogues
* :sparkles: added sde layers in additional layers priv response with include_sde_layers query param
* :sparkles: added uniqueCode in additionalLayer response
* :sparkles: added info catalogue code to additional layer response

### Fixes
* :bug: fixed query
* :bug: fixed timeout issue in getLandUseDetailsInfinite, closes [#147842](https://abacogroup.easyredmine.com/issues/147842)
* :bug: fixed LayerMessageProcessor

### Other

* :recycle: some refactor
* :heavy_plus_sign: added crop plan sdk dependency

### [v1.11.13](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.11.12...v1.11.13) (2024-08-07) add get doigt by codes

### Features
* :sparkles: add private and public resources for get doigt by codes

### [v1.11.12](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.11.11...v1.11.12) (2024-07-31) little block fix

### Fixes
* **blocks:** :bug: fix issue in block order query for viewer blocks search api


### [v1.11.11](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.11.10...v1.11.11) (2024-07-30) removed direct response pt2.

### Fixes
* :wrench: update apigateway.yaml


### [v1.11.10](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.11.9...v1.11.10) (2024-07-30) removed direct response

### Fixes
* :wrench: update apigateway.yaml


### [v1.11.9](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.11.8...v1.11.9) (2024-07-29)

### Features
* :wrench: update apigateway.yaml
* :sparkles: added hidden api to update world_geom
* :sparkles: added new apis to get summary by vine aptitudes, closes [#138165](https://abacogroup.easyredmine.com/issues/138165)

### Fixes
* **internal:** :bug: fix little issue in update world geom internal api


### [v1.11.8](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.11.7...v1.11.8) (2024-07-04) some fixes

### Features
* :sparkles: i18n error descriptions for new error codes

### Fixes
* :bug: fixed parcel error check issue in checkNewParcelsDeletedDuringSession
* :bug: added geom check to getLocationByGpsGeom in Location service, closes [#142400](https://abacogroup.easyredmine.com/issues/142400)
* **jdbi:** :pencil2: fix some current_timestamp with abaco-jdbi function name
* **landcover:** :bug: fix landcover description when null return the code


## [v1.11.7](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.11.6...v1.11.7) (2024-06-20) Task Notes

### Features
* **tasks:** :sparkles: implement document data read in task services, closes [#137392](https://abacogroup.easyredmine.com/issues/137392)

### Fixes
* **tasks:** :bug: fix notes save in task movements
* **oracle:** :bug: re-enable Oracle Spatial Vector Acceleration


### [v1.11.6](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.11.5...v1.11.6) (2024-06-17) new task fields

### Features
* **dd-task:** :sparkle: add new task dd version that implement patyId and planId in task dd auto-bundle, closes [#137315](https://abacogroup.easyredmine.com/issues/137315)
* **sessions:** :sparkles: implement mandatory notes for session suspend, closes [#140067](https://abacogroup.easyredmine.com/issues/140067)


### [v1.11.5](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.11.4...v1.11.5) (2024-06-13) fix landcovers session data

### Fixes
* **parcels:** :zap: improve performance in get edit parcels api


### ~~[v1.11.4](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.11.3...v1.11.4) (2024-06-13) session land covers issue~~

### Fixes
* **matrix:** :bug: fix issue in matrix bundle import, only one landuse, or landcover, for matrix, closes [#142140](https://abacogroup.easyredmine.com/issues/142140)

### Other
* :hammer: little utility program to export all application config keys with description
* :recycle: reorder application config yaml file

### Documentation
* :package: :memo: sample bundle with all areas data with geometries
* :memo: update readme with all the config key descriptions and default values


### ~~[v1.11.3](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.11.2...v1.11.3) (2024-06-12) session land covers issue~~

### Features
* **config:** :wrench: add new application config key fl_cll_history_load_holders, closes [#142339](https://abacogroup.easyredmine.com/issues/142339)
* **config:** :wrench: add new application config key maximum_landcovers_to_merge, closes [#141557](https://abacogroup.easyredmine.com/issues/141557)

### Fixes
* **matrix:** :bug: fix issue in matrix bundle import, only one landuse for matrix, closes [#142140](https://abacogroup.easyredmine.com/issues/142140)
* **oracle:** :construction: try to remove spatial vector acceleration for oracle performance issue, closes [#141327](https://abacogroup.easyredmine.com/issues/141327)
* **parcels:** :zap: improve performance in get edit parcels api, closes [#141327](https://abacogroup.easyredmine.com/issues/141327)
* :bug: fix valid check on getVineUnitCodeList resources

### Other
* **pom:** :arrow_up: upgrade postgresql driver to v42.6.1
* **pom:** :arrow_down: downgrade oracle driver version to 21.3.0.0

### Documentation
* :memo: add descriptions to application config yaml file



### [v1.11.2](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.11.1...v1.11.2) (2024-06-04) :zap:

### Features
* **unit_codes** :sparkles: add get unit codes public api, closes [#141410](https://abacogroup.easyredmine.com/issues/141410)
* **parcels:** :zap: improve search parcels performance, closes [#141528](https://abacogroup.easyredmine.com/issues/141528) [#141344](https://abacogroup.easyredmine.com/issues/141344)
* **parcels:** :sparkles: add optional include_geometries default true in private parcels search api
* **config:** :zap: improve internal config loading performance

### Fixes
* **blocks:** :bug: set block response order, closes [#140511](https://abacogroup.easyredmine.com/issues/140511)

### Other
* **config:** :wrench: enable client visibility for maximum_parcels_to_merge key, closes [#141557](https://abacogroup.easyredmine.com/issues/141557)
* :recycle: fix long size for stumpsNumber property


### [v1.11.1](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.11.0...v1.11.1) (2024-05-22) meta fix

### Fixes
* **matrix:** :bug: fix an issue in matrix metadata bundle import


## [v1.11.0](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.18...v1.11.0) (2024-05-08) lost in translation

### Features
* **translations:** :sparkles: implement translation api with old ui extra translation import for additional translations via liquibase, closes [#138445](https://abacogroup.easyredmine.com/issues/138445)
* **errors:** :sparkles: implement new errors handling and response with multi-checking list

### Fixes
* :bug: fixed check createOrUpdateVineAptitudes payload in EditVineUnitsService
* :bug: add minimum area error message
* :bug: fix issue in total units area calculation
* :bug: fixed validation error messages of vine units dates
* :bug: added InvalidFormException
* :bug: various fixes, closes [#136931](https://abacogroup.easyredmine.com/issues/136931) [#136174](https://abacogroup.easyredmine.com/issues/136174) [#136177](https://abacogroup.easyredmine.com/issues/136177) [#136183](https://abacogroup.easyredmine.com/issues/136183) [#136932](https://abacogroup.easyredmine.com/issues/136932)

### Other
* :recycle: some fix for sonar compliance

### Documentation
* :memo: update README.md
* :memo: update readme for additional UI Translations, closes [#138445](https://abacogroup.easyredmine.com/issues/138445)


### [v1.10.18](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.17...v1.10.18) (2024-04-22)

### Features
feat: :sparkles: added total_unit_area_sqm to landcover response

### Fixes
* **helm:** :bug: fix helm TERRITORIAL_SCOPES_IGNORE

### [v1.10.17](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.16...v1.10.17) (2024-04-19)

### Features
* **helm:** :sparkles: add all territorial-scopes variables to values

### [v1.10.16](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.15...v1.10.16) (2024-04-19)

### Fixes
* **matrix:** :bug: fix territorial-scopes url in config-docker
* **matrix:** :bug: add TERRITORIAL_SCOPES_ROUTINGKEY and TERRITORIAL_SCOPES_QUEUEID on helm-vine

### Features
* **matrix:** :sparkles: add delete on bindles message processor
* **matrix:** :sparkles: add delete on landcover and landuses message processor

### [v1.10.15](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.14...v1.10.15) (2024-04-15) matrix reloaded

### Fixes
* **matrix:** :bug: fix issue in matrix landuse search
* **matrix:** :bug: fix issue in matrix compatibility import

### Other
* :pencil2: fix a typo in matrix query


### [v1.10.14](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.13...v1.10.14) (2024-04-05)

### Features
* **matrix:** :sparkles: add favourite landuse list in matrix api payload

### Other
* :recycle: refactor


### [v1.10.13](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.12...v1.10.13) (2024-04-04)

### Fixes
* **matrix:** :construction: temporary fix for matrix landcover and landuses search
* :bug: minor fixes on deleteVineUnitById method
* :big: fixed vine unit eradicate/delete issue, closes [#135759](https://abacogroup.easyredmine.com/issues/135759)
* :bug: fixed query in MatrixLandUsesMetadataDAO
* **stacks:** :bug: fix unit type compatibility in landcover stack information



### [v1.10.12](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.11...v1.10.12) (2024-03-28)

### Fixes
* **parcels:** :bug: fix issue in get parcel detail for outdated or no gis parcels

### Other
* **sso:** :package: new function for sso to enable multiple edit sessions for one user


### [v1.10.11](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.10...v1.10.11) (2024-03-22) multiple creation

### Features
* :sparkles: updated EditParcelsService.setUpdatedNamedParcelId to allow to create multiple parcels with name

### Fixes
* :bug: fixed some vine aptitude queries, closes [#134307](https://abacogroup.easyredmine.com/issues/134307)
* :bug: fix wms layer toMetersForPixel values

### Documentation
* :memo: update README.md


### [v1.10.10](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.9...v1.10.10) (2024-03-15) get no gis parcel details

### Features
* **parcels:** :sparkles: permit get outdated parcel details, closes [#132941](https://abacogroup.easyredmine.com/issues/132941)


### [v1.10.9](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.8...v1.10.9) (2024-03-14)

### Refactor
* Refactor for sonar agea issues

### [v1.10.8](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.7...v1.10.8) (2024-03-14) omar to be fixed

### Fixes
* **parcels:** :bug: fix a query from omar that shouldn't have worked but oracle remained silent


### [v1.10.7](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.6...v1.10.7) (2024-03-13) A large release for all other party

### Features
* :sparkles: added query params for geometries in public get block api
* :sparkles: added new public api to get block list by sector code
* :sparkles: added includeOutdated flag in get parcels query
* :sparkles: added new api to persist temporary parcel
* :sparkles: added search level filter in public get parcels api
* :sparkles: added temp parcels cache
* :sparkles: added vineyard code in BulkVineAptitudePayloadV1
* :sparkles: added vineyard-doigt link checks
* :sparkles: implemented new api to get vineyard codes filtered by doigt
* :sparkles: implememted VineyardDoigtLinkMessageProcessor
* :sparkles: added sector id in TotalParcelsSummaryV1 response
* :sparkles: added public version of getSectors api of farmland resources, closes [#132621](https://abacogroup.easyredmine.com/issues/132621)
* :sparkles: implemented party parcel cache, closes [#132621](https://abacogroup.easyredmine.com/issues/132621)

### Fixes
* :bug: fixed some error messages
* :bug: fixed some vine aptitude queries
* :bug: minor fix
* :bug: fixed pageSize issue in ParcelV1Service

### Other
* :recycle: refactor SectorsV1Service
* **pom:** :arrow_up: upgrade swagger-jaxrs2 to v2.2.20
* **pom:** :arrow_up: upgrade geometry editor to v2.4.5
* **pom:** :arrow_up: upgrade embeded db queue to v1.11.0
* **pom:** :arrow_up: upgrade dropwizard to v4.0.7
* :memo: docs
* :recycle: happy sonar fix
* :pencil2: fixed typos

### Documentation
* :memo: update README.md
* :memo: updated vine unit sample bundles
* :memo: added sample bundle for vineyard-doigt links



### [v1.10.6](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.5...v1.10.6) (2024-03-01) fix all my vineyard

### Fixes
* **bulk:** :bug: fix issue with vineyard null in bulk upload


### [v1.10.5](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.4...v1.10.5) (2024-02-29) interoperability

### Features
* :sparkles: added vineyard code in vine aptitudes
* :sparkles: added bundle message processor for vineyard codes and descriptions
* :sparkles: added check for external code in save session
* :sparkles: added external_code in parcel
* :sparkles: added filter for ExternalCodeList in PublicParcelSearchPayload
* :sparkles: added unit code in CreateOrUpdateVineUnitPayloadV1
* :sparkles: added include_geometries flag in getBlocks api

### Fixes
* :bug: minor fixes
* :bug: fixed save parcel in preview issue in setUpdatedNamedParcelId

### Documentation
* **bundles:** :memo: fix data for landcovers sample bundle
* **bundles:** :memo: added sample bundles for vineyard codes


### [v1.10.4](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.3...v1.10.4) (2024-02-22) keep your pieces

### Features
* :sparkles: added external code filter in public get parcels api
* :sparkles: added query param keepOtherSession to create new session api

### Fixes
* **areas:** :bug: fix areas searches in areasdao


### [v1.10.3](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.2...v1.10.3) (2024-02-20) areas & sectors & srs

### Features
* :sparkles: added new api to get sector list by area id

### Fixes
* **wmsserver:** :bug: fix issue in srs search for sector filter in wms service, closes [#131189](https://abacogroup.easyredmine.com/issues/131189)

### Other
* :card_file_box: docker composer with local volume



### [v1.10.2](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.1...v1.10.2) (2024-02-14) Bulk References

### Fixes
* **bulk:** :bug: fix parcel reference in bulk response to avoid replacements



### [v1.10.1](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.10.0...v1.10.1) (2024-02-14) Release party

### Fixes
* **vineunits:** :bug: fix range for stumps number

### Other
* :green_heart: add automatic release on tag
* :green_heart: add vine gis server variant deploy in iacs test environment



## [v1.10.0](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.9.7...v1.10.1) (2024-02-13) Edit Vine Units

### Features
* :sparkles: implement range check for vine units values
* :sparkles: save outdated units and aptitude
* :sparkles: implement find eradicate vine units in dao
* **sessions:** :sparkles: check parcel before force to save new parcel version
* **session:** :sparkles: implement better session data check validity with error list response
* **session:** set error special http status code for client
* :sparkles: implement Edit Vine Units

### Fixes
* **session:** :bug: fix issue in parcel id retrivial for create parcel sessions
* :bug: fix tests

### Other
* :arrow_up: upgrade dropwizard dependency version to 4.0.6
* :recycle: fixed some sonar issue
* :memo: better error translations
* add areas values to error messages
* :coffin: remove unused code
* :recycle: some refactor
* :recycle: renamed openapi server variables

### Documentation
* :memo: error description auto-bundle
* :memo: auto bundle for new error descriptions


### [v1.9.7](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.9.6...v1.9.7) (2024-02-05) message in a bottle

### Fixes
* **session:** :pencil2: fix error description for task parcels geom, closes [#123700](https://abacogroup.easyredmine.com/issues/123700)
* :bug: fix error translations bundle


### [v1.9.6](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.9.5...v1.9.6) (2024-01-25) parcel code check

### Fixes
* :bug: fix bulck upload check unique parcel code for block


### [v1.9.5](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.9.4...v1.9.5) (2024-01-24) Bulk response

### Fixes
* :bug:  fixed errorMap key in bulk parcel response

### Other
* **ci:** :memo:  sample for cll url configuration in values file


### [v1.9.4](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.9.3...v1.9.4) (2024-01-23) custmer land link

### Other
* :green_heart: add CUSTOMER_LAND_LINK_URL configurable via values


### [v1.9.3](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.9.2...v1.9.3) (2024-01-23) fixes

### Fixes
* **bulk:** :bug: add round on get area sqm of BulkV1Service


### [v1.9.2](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.9.1...v1.9.2) (2024-01-16) fixes

### Fixes
* **bundles:** :bug: fix issue in landcover unit types bundle import queries


### [v1.9.1](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.9.0...v1.9.1) (2024-01-12) fixes and deactivated scopes

### Features
* :sparkles: added vine unit data to session preview response
* :sparkles: made georasterConfig in LpisGisServerConfiguration nullable
* **sessions:** because of client behaviour in preview session api avoid scope check *to be re-imagined*
* **terScopes:** :sparkles: add territorial scopes configuration in config yaml
* **terScopes:** :sparkles: chack scopes on parcel in edit apis
* **terscopes:** :sparkles: implement check territorial scopes in session creation

### Fixes
* :bug: when edit session from task if no parcel selected and nothing done in session disable save session, closes [#123714](https://abacogroup.easyredmine.com/issues/123714)
* :bug: fixed session parcel id issue for session opened by task, closes [#123700](https://abacogroup.easyredmine.com/issues/123700)
* :bug: fixed a NullPointerException
* :bug: fixed georaster data save issue
* :bug: fixed public parcel search

### Other
* :recycle: refactor for sonar
* :arrow_up: update dependeciy territorial scope cache lib version to 1
* **ci:** :recycle: changed name of deploy stage to avoid misunderstandings
* **pom:** :arrow_up: upgrade swagger-jaxrs2 to version 2.2.19

### Documentation
* :memo: updated error descriptions in auto bundles


## [v1.9.0](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.8.3...v1.9.0) (2024-01-05) Vine Units and Viewers

### Features
* **conf:** :wrench: add new configuration key for cll context path
* :sparkles: added new public api for vine units
* :sparkles: added new services to read infoGis data from Georaster server
* :sparkles: added parcel anomalies to bulk upload
* **addtButtons:** :sparkles: add OUTLINED_BUTTON to linktype enum
* :sparkles: added display_order to Additional external links
* :sparkles: added new api to get additional external links
* :sparkles: added AdditionalExternalLinksMessageProcessor

### Fixes
* :bug: minor fixes

### Other
* :refactor: refactor anomalies service for sonar happy Christmas
* :sparkles: implement georaster configuration for ci
* :recycle: refactor on anomalies service comments
* :recycle: renamed some enums

### Documentation
* :memo: added Agrea external button links sample bundle
* **bundles:** :memo: sample bundle avepa change editor title translation
* **bundles:** :memo: sample bundle avepa disable landcovers views
* :memo: added sample bundle for additional external links


### [v1.8.3](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.8.2...v1.8.3) (2023-12-18) let the category be

### Fixes
* **stacks:** :bug: fix issue in staks models for null values
* :bug: fixed get vine unit query

### Documentation
* :memo: updated sample bundles for vine units



### [v1.8.2](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.8.1...v1.8.2) (2023-12-14) bugs fixing

### Fixes
* **parcels:** :bug: fix abbandoned typo in get parcel service
* :bug: fixed blank nextKey issue
* :bug: fixed getSectorSummaryByParcelIds query
* :bug: minor fixes

### Other
* :recycle: refactor mappers



### [v1.8.1](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.7.0...v1.8.0) (2023-12-13) fixed regression

### Fixes
* **parcels:** :bug: fix regression in parcel search


## [v1.8.0](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.7.0...v1.8.0) (2023-12-13) All-In

### Features
* :sparkles: implemented api to get parcel edit status, closes [#124360](https://abacogroup.easyredmine.com/issues/124360)
* :sparkles: added source_code insert parcel details query
* **vineunits:** :sparkles: implemented api for vine units manage, closes [#119647](https://abacogroup.easyredmine.com/issues/119647)
* **vineunits:** :sparkles: implemented api for vine units dossier viewer and summary, closes [#124043](https://abacogroup.easyredmine.com/issues/124043)
* **vineunits:** :sparkles: implemented api for bulk parcel upload, for vinealign syncronization
* **bundles:** :sparkles: added variuos bundles processor for vine units data
* **vineunits:** :card_file_box: liquibase script for vine units data
* :sparkles: added nearest campaign to stack response
* :sparkles: added new internal config key to filter stack with edit status, closes [#125416](https://abacogroup.easyredmine.com/issues/125416)
* :sparkles: added edit category in session save imported via bundle, closes [#125418](https://abacogroup.easyredmine.com/issues/125418)
* :sparkles: added LocationResources, closes [#125417](https://abacogroup.easyredmine.com/issues/125417)
* :sparkles: implemented api to get parcel edit status, closes [#124360](https://abacogroup.easyredmine.com/issues/124360)


### Fixes
* **cutGeom:** :bug: fix issue in cut geometry from difference with catalogue
* **addLayer:** :bug::boom: fix regression error in public additional layer type name
* **catalogues:** :clown_face: better mocked names in catalogues table
* :bug: fix default servicesupportEnv include geometries and landcover values to true
* **config:** :wrench: set move vertex on by default, closes [#124411](https://abacogroup.easyredmine.com/issues/124411)
* **mappers:** :bug: fix mappers
* :bug: fixed LayerMessageProcessor to update layer path
* **MatrxLandCover:** :bug: fix getLandCoverStylesByCodesInfinite
* **landcover:** :bug: fix issue in sql order function
* :recycle: fix user roles in new apis
* :bug: fix default servicesupportEnv include geometries and landcover values to true
* **addLayer:** :bug::boom: fix regression error in publi additional layer type name

### Others
* :sparkles: implement serviceContainer for sonar happiness
* :recycle: swagger comments fix
* :recycle: class renamed
* :recycle: minor swagger clean-up
* :recycle: refactor with abaco jdbi AbsoluteDate
* **pom:** :arrow_up: upgrade abaco-jdbi to version 2.15.0
* :memo: removed wrong openapi tag
* :construction_worker: configure cll url for vine variant
* :recycle: little refactor for agea sonar in vine unit message processor
* :recycle: refactor buffer application in parcel edit

### Documentation
* :package: added sample bundles for vine unit codes
* **vine:** :memo: added new error description autobundle for new error for vine gis server config, closes [#121737](https://abacogroup.easyredmine.com/issues/121737)
* :package: add vine doigt codes sample bundle


## [v1.7.0](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.6.5...v1.7.0) (2023-11-20) Catalogues and Cut Geometries

### Features
* **config:** :wrench: add on_create_parcel_wms_to_show config variable, closes [#121728](https://abacogroup.easyredmine.com/issues/121728)
* **catalogues:** :sparkles: implement catalogue geoms search in catalogues service
* **catalogue:** :clown_face: temporary mocked data for catalogues
* :sparkles: add layer path info in external sources apis
* :sparkles: added path variable into additional layer response
* :sparkles: added new path variable into Bundles LayerMessageProcessor
* :sparkles: implemented move vertex, closes [#120568](https://abacogroup.easyredmine.com/issues/120568)
* **landcover:** :sparkles: search landcovers for code and description concatenation, closes [#120699](https://abacogroup.easyredmine.com/issues/120699)
* :sparkles: implemented I18nTenantMessageProcessor to import i18n values on new tenant event, closes [#121737](https://abacogroup.easyredmine.com/issues/121737)
* **config:** :sparkles: implement new complex internal configuration object reading
* **wms:** :sparkles: implemented fill landCover, closes [#98618](https://abacogroup.easyredmine.com/issues/98618)
* :sparkles: added api to get intersect geometry from catalogue
* :sparkles: implemented cut out LandCovers in EditLandCoversService
* :sparkles: implemented cut out Parcel in EditParcelsService

### Fixes
* :bug: excluded background layers from additional layers response with default 0
* **liquibase:** :bug: fix issue in new liquibase checksum calculation for sql changelog
* **wms:** :art: set default landcover label color as the default fill color, closes [#120297](https://abacogroup.easyredmine.com/issues/120297)
* **landcover:** :bug: fix possible nullpointer in persist landcover func.
* **internalConfig:** :bug: fix issue in regex for string extraction in internal config
* :bug: fixed parcel stack's sorting, closes [#121376](https://abacogroup.easyredmine.com/issues/121376)
* **additLayers:** :bug: fix issue in private additional layers api sort in response
* **sde:** :bug: if flag search_sde is false disable searches

### Other
* :recycle: some code cleanup and refactor
* **pom:** :arrow_up: upgrade swagger-jaxrs2 to version 2.2.18
* **pom:** :arrow_up: upgrade abaco-jdbi to version 2.14.0
* **pom:** :arrow_up: upgrade oracle-driver to version 23.3.0.23.09
* **pom:** :arrow_up: upgrade dropwizard to version 4.0.4

### Documentation
* :memo: update layer sample bundles
* :memo: update README.md
* :memo: added new error description autobundle for new error, closes [#121737](https://abacogroup.easyredmine.com/issues/121737)



### [v1.6.5](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.6.4...v1.6.5) (2023-11-06) External data info

### Fixes
* :bug: added external source code in Parcel response, closes [#121105](https://abacogroup.easyredmine.com/issues/121105)


### [v1.6.4](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.6.3...v1.6.4) (2023-11-06) a few fixes

### Fixes
* :bug: fixed WMSLayersDAO queries, closes [#121377](https://abacogroup.easyredmine.com/issues/121377)
* **sessions:** :bug: fix unchecked null in edit session evalution
* :bug: fixed wms layer of Blocks and sectors, closes [#121046](https://abacogroup.easyredmine.com/issues/121046)


### [v1.6.3](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.6.2...v1.6.3) (2023-11-03) configurable mocked viewer

### Features
* **viewer:** :clown_face: new option for mocked parcel subject summary
* **build:** :sparkles: configuration to build variant for vineregistry

### Fixes
* **parcels:** :bug: fix error in parcel rename

### Other
* :coffin: removed unused code


### [v1.6.2](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.6.1...v1.6.2) (2023-10-30) fixes and colors

### Fixes
* **landcovers:** :bug: fix issue when saving orphan landcovers
* **wms:** :bug: fix issue with landcovers label, closes [#120680](https://abacogroup.easyredmine.com/issues/120680)
* **campaign:** :bug: fix issue with campaign setted in future
* **wms:** :bug: fix issue on landocover wms draw for session parcels
* **wms:** :art: set default landcover label color as the default fill color, closes [#120300](https://abacogroup.easyredmine.com/issues/120300)


### [v1.6.1](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.6.0...v1.6.1) (2023-10-26) little bug fix

### Fixes
* **session:** :bug: fix regression in session save, closes [#120678](https://abacogroup.easyredmine.com/issues/120678)
* **plugins:** :bug: fix internal plugin in check subcode length, closes [#120295](https://abacogroup.easyredmine.com/issues/120295)


## [v1.6.0](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.5.5...v1.6.0) (2023-10-25) Put and Patch

### Features
* :sparkles: changed PATCH resources into PUT resources, closes [#120484](https://abacogroup.easyredmine.com/issues/120484)
* **wms:** :lipstick: change default internal wms colors, closes [#120297](https://abacogroup.easyredmine.com/issues/120297)
* **wms:** :lipstick: change default wms colors, closes [#120300](https://abacogroup.easyredmine.com/issues/120300)
* **wms:** :sparkles: implement wms landcover labels outline and text color, closes [#120300](https://abacogroup.easyredmine.com/issues/120300)
### Fixes
* **areas:** :bug: fix error in areas bundle import, closes [#120247](https://abacogroup.easyredmine.com/issues/120247)
* **wms:** :bug: fix possible issue in area wms server
* **parcels:** :bug: fix issue in parcel update data for renamed or moved parcels, closes [#120293](https://abacogroup.easyredmine.com/issues/120293)

### Other
* :construction: temporary internal areas wms label dynamic definition
* :recycle: some refactor
* **pom:** :arrow_up: upgrade simple-wms-4j to v4.2.1


### [v1.5.5](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.5.4...v1.5.5) (2023-10-19) Huge Refactor
### Other
* :recycle: huge refactor for sonar issues
* :bug: fix possible issue with null pointers

### Documentation
* :memo: some AI generated comments


### [v1.5.4](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.5.3...v1.5.5) (2023-10-18) Styles for summaries

### Features
* :sparkles: add layer style in FarmLand TotalLandCoversList response

### Fixes
* **dao:** :bug: fix missing env param in some matrix dao

### Documentation
* **bundles:** :memo: sample bundle for internal wms additional layer configuration on different srs


## [v1.5.3](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.5.2...v1.5.3) (2023-10-10) little fixes

### Fixes
* **wmsServer:** :bug: fix issue with transparents in wms
* **additLayers:** :bug: fix issue with oracle query in additional layers


## [v1.5.2](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.5.1...v1.5.2) (2023-10-10) :arrow_down: Bundles Infrastructure Downgrade

### Other
* **pom:** :arrow_down: downgrade bundles-infrastructure to v1.4.0 *to avoid issue of aknowledge waiting in the version v1.5.0*


## [v1.5.1](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.5.0...v1.5.1) (2023-10-10) fix bundles files

### Fixes
* :bug: fix issue with bundles files


## [v1.5.0](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.4.4...v1.5.0) (2023-10-10) Create parcel with reference

### Features
* :sparkles: added layer options in additional layer response and bundles
* :sparkles: added new query params for wms layers
* :sparkles: added parcel update on parcel creation, closes [#112562](https://abacogroup.easyredmine.com/issues/112562)
* removed filter to return deleted parcels in getEditParcelsLandCovers

### Fixes
* :bug: fixed findByMatrixIdAndCode and searchByMatrixIdAndCode queries in PublicMatrixClassesDAO
* :bug: changed default value of lables param from false to true
* :bug: fixed some queries
* :bug: fix issue with creating landcovers when creating a new parcel with parcelId
* :bug: now when return parcels in getEditParcelsLandCovers list the deleted named parcels not the new one, closes [#112562](https://abacogroup.easyredmine.com/issues/112562)
* :bug: fixed WMSLayersDAO queries to add labels and in edit parcels

### Other
* **pom:** :arrow_up: upgrade swagger-jaxrs2 to v2.2.16
* **pom:** :arrow_up: upgrade lombok to v1.18.30
* **pom:** :arrow_up: upgrade geometry-editor to v2.4.4
* **pom:** :arrow_up: upgrade embeded-db-queue to v1.10.0
* **pom:** :arrow_up: upgrade bundles-infrastructure to v1.5.0
* **pom:** :arrow_up: upgrade abaco-tracing-utils to v4.1.0
* **pom:** :arrow_up: upgrade dropwizard to v4.0.2
* :recycle: refactor PublicMatrixService
* **pom:** :arrow_up: upgrade of simple-wms-4j to v4.2.0 for no overlapping labels
* **pom:** :recycle: refactor url param reading in wms service
* :recycle: refactor getAdditionalLayers public and private method


## [v1.4.4](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.4.3...v1.4.4) (2023-10-06) fix additional layers oracle stubbornness

### Fixes
* **additLayers:** :bug: fix problem with additional layer query and oracle stubbornness
* **additLayers:** :bug: fix equals check for wms layer server configuration bundle


## [v1.4.3](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.4.2...v1.4.3) (2023-10-06) TiledWMS additional layer server type

### Features
* **additLayers:** :sparkles: implement new additional layer TiledWMS and wms server config field


## [v1.4.2](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.4.1...v1.4.2) (2023-10-05) fix recursive areas layers

### Fixes
* **additLayer:** :bug: fix error in recursive query for areas filtered layer

### Other
* **bundles:** :rocket: italian sectors areas link data bundle


## [v1.4.1](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.4.0...v1.4.1) (2023-10-04) fix issues

### Fixes

* **publicApi:** :bug: fix issue in search srs for sector
* **parcels:** :bug: fixed issue in edit parcel when landcovers are outside new geom


## [v1.4.0](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.20...v1.4.0) (2023-10-02) new wms and fixes [#112562](https://abacogroup.easyredmine.com/issues/112562)

### Features

* **edit_status:** :sparkles: add edit status on parcel and landcover
* :sparkles: added sector id in edit session response
* :sparkles: added new configuration keys for wms layer labels size and colors
* :sparkles: added labels to wms layers
* :sparkles: added new wms layer for areas
* :sparkles: added new wms layer for blocks
* :sparkles: added new wms layer for sectors

### Fixes

* **additLayer:** :bug: remove search for null srs in additional layer configuration
* :bug: fixed srs issue for wms layer areas

### Other

* **pom:** upgrade embeded-db-queue to v1.9.0
* **pom:** upgrade bundles-infrastructure to v1.4.0
* some minor fixing

### Documentation

* :memo: update README.md


### [v1.3.20](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.19...v1.3.20) (2023-09-25) new season release

### Features
* **application:** :card_file_box: enabled SpatialVectorAcceleration for oracle db connection
* **additLayer:** :sparkles: implement public additional layer for area filtered over sectorId o code api, closes [#114391](https://abacogroup.easyredmine.com/issues/114391)
* :sparkles: added sector filter in getAdditionalLayers api
* **bundles:** :sparkles: added areas list to wms server bundle message
* **farmlandviewer:** :sparkles: implement customer land link call for farmland viewer apis
* :wrench: added new configuration key "fl_hide_landcovers_layer" to hide landcovers layer
* :sparkles: added new wms layer for SDE parcels
* :recycle: added static crsMap in base service to save Coordinate Reference System
* :sparkles: implementation of external source parcel search for find-new parcel api
* :construction: partially implemented new wms layer "SDE"
* :sparkles: added api to get sde code list by tenant
* :sparkles: added config keys for default sde parcels style
* :sparkles: implemented api to find new parcels

### Fixes
* :bug: fixed createParcel
* **public-parcels:** :bug: fix possible issue in public parcels search api
* :bug: fix typo in external source codes list

### Other
* :recycle: some duplicated code semplification and general code refactor
* **plugins:** :recycle: moved parcel plugin loading in baseservice
* **pom:** :arrow_up: update abaco-jdbi dependency to v2.13.0
* **public-martix:** :pencil2: fix check list null in sql query for public matrix dao


### [v1.3.19](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.18...v1.3.19) (2023-09-15) crop plan matrixes

#### Features
* **matrixes:** :sparkles: new implementations of matrix public apis
* **matrixes:** :sparkles: new parameter useIntercompatibility for matrix public apis

### [v1.3.18](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.17...v1.3.18) (2023-09-14) service release

### Other
* service release


### [v1.3.17](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.16...v1.3.17) (2023-09-14) service release

### Other
* service release


### [v1.3.16](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.15...v1.3.16) (2023-09-14) service release

### Other
* service release


### [v1.3.15](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.14...v1.3.15) (2023-09-14) service release

### Other
* service release


### [v1.3.14](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.13...v1.3.14) (2023-09-14) service release

### Other
* service release

## [1.3.13](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.12...v1.3.13) (2023-09-14) revert layer bundle processor

### Fixes
* **bundles:** revert layer bundle processor
* **Parcel:** :bug: removed not empty in sector and block search
* **public-parcels:** :bug: fix issue in geometry search public parcels api

### Other
* align max public area search size in default configuration



## [1.3.12](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.11...v1.3.12) (2023-09-14) fix for touching

### Fixes
* **Parcel:** :bug: removed not empty in sector and block search
* **public-parcels:** :bug: fix issue in geometry search public parcels api



## [1.3.11](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.10...v1.3.11) partial new

### Features
* **public:** :sparkles: add sector with codes and modify parcels
* **external-source:** :sparkles: get external parcel ([#112562], closes [#112562](https://abacogroup.easyredmine.com/issues/112562)
* **campaign:** :sparkles: add campaign config ([#112562], closes [#112562](https://abacogroup.easyredmine.com/issues/112562)
* **external-parcels:** :sparkles: add decode parcel search (#112562), closes [#112562](https://abacogroup.easyredmine.com/issues/112562)
* **parcels:** :sparkles: add not empty constraint on sector and block, closes [#112562](https://abacogroup.easyredmine.com/issues/112562)
* **config:** :sparkles: add fl_search_external_parcels on config, closes [#112562](https://abacogroup.easyredmine.com/issues/112562)
* **external-source:** :sparkles: add external source data (#112562), closes [#112562](https://abacogroup.easyredmine.com/issues/112562)
* **matrix metadata:** :sparkles: add bundles for matrix metadata
* implement landcovers and landuses search public apis
* **public:** :sparkles: added public api to get landcovers by parcelId
* **public:** :sparkles: added layerStyle  in publicLandCover
* **public:** :sparkles: added page_size query param to getParcels
* **public:** :sparkles: added page_size query param to getParcels

### Fixes
* **public:** :bug: removed default value of page_size

### Other
* set max age for db migrate job



## [1.3.10](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.9...v1.3.10) fix liquibase
### Features

* :arrow_up: upgrade to dropwizard 4.0.1

### Fixes

* :bug: fix issue with oracle migrate script, create constraints with addUniqueConstraint


## [1.3.9](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.8...v1.3.9) tracing a matrix layer
### Features

* :arrow_up: upgrade to dropwizard 4.0.0
* :sparkles: implement tracing lib
* **config:** :sparkles: added two new keys for coordinates on map
* **matrix:** :sparkles: add is_favourite on land cover and land use
* **matrix:** :sparkles: add public matrix resources and new tables for
* **layers:** :sparkles: add modules for layers #[#108281](https://abacogroup.easyredmine.com/issues/108281)


## [1.3.8](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.7...v1.3.8) extended land
### Features

* **internalConfig:** :sparkles: return all specific ui configuration ui_
* **extended_landcovers:** :sparkles: new api for get extended land covers from land cover code
* **landcover-codes:** :sparkles: new api for get land covers from land uses


## [1.3.7](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.6...v1.3.7) only one

### Features
* **stacks:** :sparkles: for the viewer in stack parcel show only last edit for all the edits on the same ref date, closes [#101141](https://abacogroup.easyredmine.com/issues/101141)
* **landuses:** :sparkles: new API to retrieve landuses by land cover code, closes [#98294](https://abacogroup.easyredmine.com/issues/98294)
* **matrix:** :sparkles: new public api to retrieve land use styles by codes, closes [#98294](https://abacogroup.easyredmine.com/issues/98294)

### Other
* **pom:** :arrow_up: update lombok dependency to 1.18.26


## [1.3.6](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.5...v1.3.6) wms stuff

### Features
* **wmslayers:** :sparkles: add WMSLAYERS|VIEWER to additional layers api permission, closes [#101624](https://abacogroup.easyredmine.com/issues/101624)
* **wmslayers:** :wrench: bundle data for new WMSLAYERS sso context, closes [#101624](https://abacogroup.easyredmine.com/issues/101624)

### Other
* **wmsserver:** :construction: increase zoom limits for parcels layer and landcover, closes [#101531](https://abacogroup.easyredmine.com/issues/101531)
* **pom:** :arrow_up: update dropwizard dependency to v2.1.6


## [1.3.5](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.4...v1.3.5) unstacked stacks

### Features
* **config:** :sparkles: implement new api for single config key request, closes [#100196](https://abacogroup.easyredmine.com/issues/100196)
* **stacks:** :sparkles: implement unstacked import parcel event in stacks apis, closes [#99676](https://abacogroup.easyredmine.com/issues/99676)

### Fixes
* **bundles:** :sparkles: import all internal config keys withous filter on internal list

### Other
* **bundles:** :rocket: some fvg data bundle sample
* **bundles:** :rocket: italian areas data bundle

## [1.3.4](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.3...v1.3.4) improvement and fixes

### Features
* **public-support:** :sparkles: public api for get land uses and land
* **config:** :sparkles: add client configuration key for party registry service url, closes [#99861](https://abacogroup.easyredmine.com/issues/99861)
* **parcels:** add possibility for parcel plugin to define the error field, closes [#98652](https://abacogroup.easyredmine.com/issues/98652)
* **defaults:** :sparkles: standard errors descriptions and translations auto bundle

### Fixes
* **parcels:** :bug: fix issue in parcels inheritance over data editing, closes [#98738](https://abacogroup.easyredmine.com/issues/98738)

### Other
* **landcovers:** :rocket: fix edit status enum in swagger apidoc

## [1.3.3](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.2...v1.3.3) $\pi$ day version
*(2023-03-14)*
### Features

* **wms:** :zap: improve wms server performance
* **additlayers:** :sparkles: add srs code in both wms and wmts additional layers api response
* **parcels:** :sparkles: implement public multiple parcels search and parcel details api with limits configuration
* **sectors:** :sparkles: public sector detail api use sectore code
* **sectors:** :sparkles: implement public api for sectors search
* **Areas:** :sparkles: add result order in area search [#96976](https://abacogroup.easyredmine.com/issues/96976)
* **code:** :recycle: fix a lot of sonar issues and code semplification

### Fixes

* **stacks:** :card_file_box: add foreign key ofr landcovers stack table
* **sectors:** :recycle: move sectors functions in public sectors class

### Other

* **pom:** :arrow_up: update geometry-editor dependency to v2.3.5
* **swagger:** :pencil2: fix wrongly listed openapi mocked resources from tests
* **openapi:** :pencil2: remove incorrect tags in some openapi definition


## [1.3.2](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.1...v1.3.2) simple wms update
*(2023-03-03)*

### Fixes
* **wmsservice:** :recycle: fix wms server for new simple-wms-4j version and restore query

### Other
* **pom:** :arrow_up: update simple-wms-4j dependency to v3.0.0

## [1.3.1](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.3.0...v1.3.1) public search and upgrade
### Features
* **wmsserver:** :zap: performance improvement for wms server landcovers layer
* **parcels:** :sparkles: implement public resource for parcels search
* **sessions:** :rocket: as last thing call the taskmanager to avoid missing operations in case of errors

### Fixes
* **wmsserver:** :arrow_up: refactor wmsservice for new dropwizard version
* **parcels:** :necktie: reconfigure query params in new public search parcels
* **sessions:** :bug: fix issue in stack parcels save avoid double write #89652
* **matrix:** :card_file_box: remove wrong old index on matrix code

### Other
* **sonar:** :recycle: some sonar cleanup
* **tests:** :recycle: fix tests imports
* **pom:** :arrow_up: update dropwizard dependency
* **pom:** :arrow_up: update geometry editor dependency
* **pom:** :arrow_up: update embeded-db-queue dependency
* **pom:** :arrow_up: update dropwizard-auth-sso2 dependency
* **pom:** :arrow_up: update abaco-jdbi dependency
* **pom:** :arrow_up: update oracle dependency
* **pom:** :arrow_up: update postgresql dependency

## [1.3.0](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.30...v1.3.0) topology over landcover
### Features
* **landcovers:** :sparkles: edit operations on landcovers layer now is full topology correct
* **errors:** :goal_net: new errors managing and errors response informations

## [1.2.31](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.30...v1.2.31) apiGateway Conf
### Features
* **helm:** configure test environment for apiGateway authorization

## [1.2.30](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.29...v1.2.30) upgrade dependency
### Fixes
* **viewer:** :bug: fix viewer search
* **parcels:** :bug: fix an error in parcels search
* **upgrade:** :arrow_up: upgrade embedded-db-queue dependecy

## [1.2.29](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.28...v1.2.29) preview of the save
### Features
* **sessions:** :sparkles: implement preview for edit session (PATCH) API
* **plugins:** :necktie: refactor internal plugins to adapt avepa functionality ([#91054](https://abacogroup.easyredmine.com/issues/91054))

### Fixes
* **parcels:** :pencil2: fix error in copy paste openapi definition for parcels landcovers list

### Docs
* **sessions:** :bug: fix error in edit session  openapi definition
* **bundles:** :memo: add some bundle examples for lpis configurations
* **plugins:** :memo: update plugin documentation
* **errors:** :pencil2: fix some errors descriptions

## [1.2.28](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.27...v1.2.28) session saved
### Features
* **viewer:** :sparkles: implement block id filter in farmland viewer blocks api
* **viewer:** :sparkles: add filter on sector code for farmland viewer sectors summary
* **session:** :sparkles: save session now respond new session data
* **plugins:** :sparkles: plugin for validate parcel name ([#92361](https://abacogroup.easyredmine.com/issues/92361))
* **support:** :sparkles: implement search for "code - description" in landcovers list api ([#92198](https://abacogroup.easyredmine.com/issues/92198))

### Fixes
* **stacks:** :pencil2: fix typo in stackparcelslandcoverlist openapi schema definition
* **viewer:** :pencil2: implement last_update in parcels viewer API
* **viewer:** :bug: fix the search of block id filter in parcels instead of blocks
* **plugins:** :bug: fix issue in read clob from oracle for plugins external config
* **sessions:** :bug: fix problem in session save
* **sessions:** :bug: fix issue in stack save in some conditions ([#89652](https://abacogroup.easyredmine.com/issues/89652))
* **blocks:** :bug: fix little issue in blocks search dao with oracle
* **workflow:** fix workflow transition's label
* **jdbi:** :pencil2: fix some current_timestamp with abaco-jdbi function name

### Builds
* **pom:** :arrow_up: upgrade geometry editor and embeded db queue library version

### Tests
* **areas:** :white_check_mark: test for area resources and services

### Other
* **readme:** :memo: add plugin readme and update readme

## [1.2.27](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.26...v1.2.27) area searches
### Features
* **bundles:** :sparkles: integration of data bundles with areas and sector areas
* **bundles:** :sparkles: bundle for i18n table
* **areas:** :sparkles: implement areas search and filter
  ([#90440](https://abacogroup.easyredmine.com/issues/90440))
* **parcels:** :sparkles: remove default trasparency for parcels style and wms
  ([#91870](https://abacogroup.easyredmine.com/issues/91870))
* **rabbitmq:** upgrade rabbitmq stack messaging with embedded-queue

### Build
* **pom:** :arrow_up: update pom dependencies
* **pom:** :arrow_up: upgrade embedde-dqueue dependency version
* **pom:** :heavy_minus_sign: removed jaxrs-util dependency

## [1.2.26](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.25...v1.2.26) new parcels history
### Features
* **anomalies:** :sparkles: remove mock on anomalies

### Fixes
* **stack:** :bug: fix on parcel history, return only list of stack
  ([#91878](https://abacogroup.easyredmine.com/issues/91878))
* **sessions:** :bug: fix problem with parent flag in stack save
  ([#91879](https://abacogroup.easyredmine.com/issues/91879))
* **parcels:** :bug: fixing rename with old parcel code and refactor decodeParcelSearch
* **sessions:** :bug: fix possible nullpointer

#### build
* **docker:** :arrow_up: Updated base java image to eclipse-temurin:17-jre-alpine

## [1.2.25](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.24...v1.2.25) fix mocked data
### Fixes
* fix mocked anomlies response

## [1.2.24](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.23...v1.2.24) parcel versions
### Features
* **viewer:** :sparkles: add block code in viewer parcel list api
* **blocks:** :sparkles: api get blocks by sector code in farmland
* **config:** :memo: add commit id to api version informations
* **farmland:** :sparkles: search mock party parcels via DB lpis_mock_party_parcels
* **session:** :sparkles: save new parcel version

### Fixes
* **wmsLayers:** :bug: rename liquibase script for additional wms layers
* **anomalies:** :bug: temporary comment on error call
* **parcels:** :bug: fix error in parcels search query


## [1.2.23](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.22...v1.2.23) typos fixes
### Fixes
* **blocks:** :bug: fix typos in parcels and blocks query
* **sessions:** :bug: fix a problem in save session

## [1.2.22](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.21...v1.2.22) I'm your father
### Features
* **parcels:** :sparkles: set equals to like in getParcels and add escape for like
* **parcels/landcovers:** :sparkles: add parent_id on edit parcels and land covers ([#91488](https://abacogroup.easyredmine.com/issues/91488))

### Fixes
* **anomalies:** :bug: fix error in anomalies level query

### build
* **helm:** Configured memory settings

## [1.2.21](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.20...v1.2.21) anomaly categories
### Features
* **parcels:** :sparkles: add no_content query param on getParcelsInGeom to avoid not found errors in browser console
* **layers:** :sparkles: add layer_name and layer_id on additional layers
* **anomalies:** :bento: adds dt_insert in the parcel anomalies api response ([#90598](https://abacogroup.easyredmine.com/issues/90598))
* **bundles:** :sparkles: add anomaly categories bundle
* **anomalies:** :sparkles: implement categories level for anomalies ([#90598](https://abacogroup.easyredmine.com/issues/90598))

### Fixes
* **landcovers:** :bug: fix problem on search landcover parcel container
* **bundle:** :bug: import plugin configurations

### other
:arrow_up: upgraded geometry editor version

## [1.2.20](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.19...v1.2.20) external plugin conf
### Features
* **parcels:** :sparkles: implement parcel search with plugin in getParcels API ([#91054](https://abacogroup.easyredmine.com/issues/91054))
* **config:** :sparkles: add external configuration ([#91054](https://abacogroup.easyredmine.com/issues/91054))
* **bundle:** :sparkles: create external config bundle and limit ([#91054](https://abacogroup.easyredmine.com/issues/91054))

### Fixes
* **viewer:** :bug: add last_update date in landcover viewer api
* **parcels:** :bug: fix check parcel code already exist for edit parcels
* **parcels:** :memo: update error descriptions ([#89517](https://abacogroup.easyredmine.com/issues/89517))

## [1.2.19](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.18...v1.2.19) feel the parcel
### Features
* **parcels:** :sparkles: implement parcels anomalies api ([#90598](https://abacogroup.easyredmine.com/issues/90598))
* **parcels:** :sparkles: implement fill parcel with landcovers ([#89519](https://abacogroup.easyredmine.com/issues/89519))

### Fixes
* **bundles:** :bug: fix bundles import of foreground level for additional wms layers ([#88512](https://abacogroup.easyredmine.com/issues/88512))
* **config:** implement data conversion of internal config from db ([#90440](https://abacogroup.easyredmine.com/issues/90440))
* **stack:** :bug: add flag fl_parent in stack detail api ([#89652](https://abacogroup.easyredmine.com/issues/89652))
* **config:** :wrench: cleaned up config file

## [1.2.18](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.17...v1.2.18) what is matrix?
### Features
* **matrixes:** :sparkles: import matrix configuration with bundles

### Fixes
* **landcovers:** :bug: fix issue on merge landcovers #88507

## [1.2.17](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.16...v1.2.17) fix me up
### Fixes
* **parcels:** :bug: fix some issue in sql query for parcels

## [1.2.16](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.15...v1.2.16) stack me up
### Features
* **landcovers:** :necktie: free draw linear elements work only on selected polygons ([#88507](https://abacogroup.easyredmine.com/issues/88507))
* **stacks:** :sparkles: implemented api for stack resources with all parcels and landcover details ([#89652](https://abacogroup.easyredmine.com/issues/89652))
* **parcels:** :necktie: remove block with code 0 and return nearest block ([#88586](https://abacogroup.easyredmine.com/issues/88586))
* **viewer:** :sparkles: add filters on farmland getParcelsBySectorCode and getParcels ([#90440](https://abacogroup.easyredmine.com/issues/90440))
* **config:** :wrench: set min area for parcels and land covers in configuration

### Fixes
* **parcels:** :bug: fix create parcel name and sonar bug
* **landcovers:** :bug: fix issue land cover code on new landocovers in original parcels
* **code:** :wrench: resolve some major issues on sonarqube

## [1.2.15](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.14...v1.2.15) initial plugins
### Features
* **parcels:** initial implementation for name and block parcel plugin ([#88586](https://abacogroup.easyredmine.com/issues/88586))

### Fixes
* **landcovers:** fix some problem in landcover editing

## [1.2.14](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.13...v1.2.14) style your land
### Features
* **wms:** implement default landcover style matrix ([#88505](https://abacogroup.easyredmine.com/issues/88505))
* **landcovers:** implement style in edit parcel landcovers list ([#88934](https://abacogroup.easyredmine.com/issues/88934))

## [1.2.13](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.12...v1.2.13) typo fix
### Fixes
* **dao:** :recycle: little landcover query typo fix and large query refactor

## [1.2.12](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.11...v1.2.12) more configurable ways
### Features

* **sessions:** :sparkles: add notes in session save ([#89520](https://abacogroup.easyredmine.com/issues/89520))
* **parcels:** :sparkles: new function configurable for automatically merge landcovers with same code in parcels merge ([#88940](https://abacogroup.easyredmine.com/issues/88940))
* **parcels:** :sparkles: add new keys for client edit cadastral references configuration, can_edit_{sector/block/parcel} and separator ([#89517](https://abacogroup.easyredmine.com/issues/89517))
* **landcovers:** :sparkles: add configuration data for client linear element creation ([#88507](https://abacogroup.easyredmine.com/issues/88507))

### Fixes

* **parcels:** :bug: when update parcel data if set the same name return SESSION_ERROR_PARCEL_DATA_ALREADY_EXIST
* **parcels:** :bug: add total landcover area in session preview parcels list ([#88942](https://abacogroup.easyredmine.com/issues/88942))
* **sessions:** fix typo in edit_land_covers_dao query

## [1.2.11](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.10...v1.2.11) no blues for parcels
### Features
- [X] **parcels:** :sparkles: implement parcels and landcovers details for get parcels in geom ([#88935](https://abacogroup.easyredmine.com/issues/88935))
- [X] **parcels:** :sparkles: add edit_status for parcels and landcovers ([#88934](https://abacogroup.easyredmine.com/issues/88934))
- [X] **parcels:** :sparkles: add last_update for parcels and landcovers ([#88930](https://abacogroup.easyredmine.com/issues/88930))
- [X] **wmsserver:** :sparkles: wms now filter hard edited parcels only ([#88934](https://abacogroup.easyredmine.com/issues/88934))
- [X] **sectors:** :sparkles: new search sectors api ([#89517](https://abacogroup.easyredmine.com/issues/89517))
- [X] **config:** :sparkles: new api for client configs ([#88942](https://abacogroup.easyredmine.com/issues/88942))
- [X] **landcovers:** :sparkles: new api for create linear land covers with preview ([#88507](https://abacogroup.easyredmine.com/issues/88507))
- [X] **sessions:** :sparkles: reduce session_parcels and session_landcovers to the one selected in session preview
- [X] **sessions:** :sparkles: remove already_locked_parcel_ids field in session preview

### Fixes
- [X] **internalConfig:** :bug: if application config file is not defined the server throw an exception
- [X] **landcovers:** :bug: fix union queries on edit land covers
- [X] **landcovers:** :lipstick: change default landcover line style

### CI
- [X] **config:** :green_heart: fix copy of application config file in docker

## [1.2.10](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.9...v1.2.10) better WMS and more parcels in viewer
### Features
- [X] **landcovers:** :sparkles: implement style in landcovers response and default styles configuration
[#88505](https://abacogroup.easyredmine.com/issues/88505)
- [X] **farmland-viewer:** :clown_face: imlement more mock data for party parcels

### Fixes
- [X] **wmsserver:** :bug: fix incompatibility with oracle sql in wms landcover query
- [X] **wmsserver:** :lipstick: fix wms server transparency
- [X] **wmsserver:** :bug: fix default parcel wms server style

## [1.2.9](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.8...v1.2.9) nightly fix
- [X] LandCover WMS Layer server
- [X] fix landcover save
- [X] fix bug on updated edit table after only land cover operations
- [X] add module and foreground_level query params in additional layers api
- [X] total land covers area on parcel
- [X] update geometry-editor for empty reduce polygons

## [1.2.8](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.7...v1.2.8) fix, tests and WMS
- [X] fix bug on landcovers search in new parcels and new landcover already in edit
- [X] [#88213](https://abacogroup.easyredmine.com/issues/88213) parcels WMS filterd on session preview
- [X] on session save parcels check for landcover coverage now is on sigle parcel
- [X] updated errors message and tranlsations (bug id: 94)
- [X] updated italian error description (bug id:79)
- [X] matrix search is more permissive and show classes with no landcover codes
- [X] implemented unit and integration tests
- [X] dependencies upgrade for geometry-editor and abaco-jdbi
- [X] replace current_timestamp with abaco-jdbi §current_timestamp§
- [X] docs(opeapi): update openapi documentation for new parameters in wms server
- [X] fixed typo in slope field name

## [1.2.7](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.6...v1.2.7) Viewer link in task-manager
- [X] update task-categories to enable link to viewer in in task manager

## [1.2.6](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.5...v1.2.6) Minimum area in save session
- [X] renamed vewer cuaa field in party in all resources apis
- [X] improved error description for parcel out of block (bug id: 79)
- [X] if there are parcels with area < 1sqm it prevent session save
- [X] if there are land covers with area < 1sqm it prevent session save

## [1.2.5](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.4...v1.2.5) typo fix
- [X] added farmland sector detail api resource
- [X] fixed error introduced for debug purpose (bug id: 91)

## [1.2.4](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.3...v1.2.4) the viewer way
- [X] implemented viewer resources api
- [X] sources cleanup
- [X] implemented transaction in session save

## [1.2.3](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.2...v1.2.3) what is Matrix
- [X] implemented public matrix apis with search
- [X] implemented rabbitMQ message dispatcher for stack in session save
- [X] fixed problem in maxlength for parcel name (bug id: 86)
- [X] fixed query for compatibility in farmland viewer with postgres

## [1.2.2](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.1...v1.2.2) openapi docs
- [X] fixed land covers search in merge parcel (bug id: 84)
- [X] openapi documentation, remove unused req/ res and fix some req/res

## [1.2.1](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.2.0...v1.2.1) spacetime journey
- [X] add openapi documentation
- [X] implemented spacetime search for parcel interaction in session save
- [X] set status of task by id
- [X] add filterTag on getTransitions
- [X] fixed error in landcover retrieving in save session (bug id: 80)

## [1.2.0](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.1.3...v1.2.0) new save by parcel name and new taskdata field
- [X] now can be saved a new version of a parcel already outdated with parcel name
- [X] fix getCodeList and tab on doc
- [X] update doc and CodeMessageList name
- [X] added groupCode to task data api response
- [X] add try-catch for every bundle operation
- [X] great package rename refactor
- [X] insert default landCoverCode in TenantMaessageProcessor
- [X] index on sector, block and wms tables

## [1.1.3](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.1.2...v1.1.3) New Config for allow not covered parcels
- [X] fixed some problem in landocvers editing
- [X] fixed problem in inherit landcover code in editing (bug id: 78)
- [X] fixed problem with landcover creation on new parcel intersections
- [X] added config for check all parcel are covered with landcover in save default true
- [X] convert codeMessageProcessor from csv to json, create bundle layer and parse line to line ImportDataMessageProcessor
- [X] fixed problem in retrieving landcover after parcel cut (bug id: 76)

## [1.1.2](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.1.1...v1.1.2) new info on public parcels api
- [X] add info on PublicParcelInfo
- [X] added legendOrder in public additional wms layer api response
- [X] italian errors description localization
- [X] if requested lock area is out of limits then ita adapetd to min, or max, area
- [X] fix for oracle query with list of null

## [1.1.1](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.1.0...v1.1.1) new wms additional layers public api
- [X] implemented new additional layers public resource
- [X] new implementation of errors description translations
- [X] upgraded to new embedded wms server version
- [X] get parcels for point

## [1.1.0](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.0.7...v1.1.0) new wms server parcels layer
- [X] implemented new parcels embedded wms layer
- [X] implemented sector_code search for embedded wms parcels layer
- [X] implemented task manager response error manage and workflow move on create task session
- [X] implemented srs field read for task proposal sketch document
- [X] fix retrieve landcovers of another parcels
- [X] fix unmodifiablePolygons on EditorParcelSupportImpl
- [X] fixed missed tenant filter in some query
- [X] fixed problem with session creation in parcel proposal
- [X] fix landcovers from parcels operations
- [X] fixed landocver search in editor result on cut parcel
- [X] fix bug ref 66 in cut landcovers on parcel
- [X] updated workflow tag for todo to progress transition (v 002)
- [X] add sector info on parcels result
- [X] fix refId 60 delete old parcel in update parcel data

## [1.0.7](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.0.6...v1.0.7) Fixed release
- [X] fixed error in geometry valutation

## [1.0.6](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.0.5...v1.0.6) Fixing session parcels managing
- [X] implemented lock parcel insert in editing
- [X] fix landcover code of new landcover in new parcel and add parcel_code
- [X] fix oracle check trim description and order by description
- [X] fix wrong round in area calculation
- [X] fix null descriptions on landcovers and landuses
- [X] fixed issue in session save api
- [X] fixed issue in parcel alfanumeric data update api
- [X] Fix notEditLandCoversWithInteractions
- [X] fix parcel already exist in block and add filter on getBlocks
- [X] fixed bug in description search in error list api
- [X] liquibase script for sector and block code creation in headers
- [X] fixed i18n tanslations searching in base service

## [1.0.5](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.0.4...v1.0.5) fix bug landcover id
- [X] fix landcover ids error on checkCanEditLC
- [X] add default landcover value on create landcover

## [1.0.4](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.0.2...v1.0.4) many modifies
- [X] add info on edit parcels with blocks and sectors
- [X] add sector_code on sector details and modifies queries
- [X] api for get transitions of task
- [X] public api for get all parcels in interactions with geometry by sector_code
- [X] bundle for insert/update data in sectors and blocks

## [1.0.2](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.0.1...v1.0.2) save landcovers operations
- [X] fixed issue in landcovers modifies on save session

## [1.0.1](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v1.0.0...v1.0.1) parcel forward
- [X] fixed issue in forwarding parcels edit to landcovers

## [1.0.0](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v0.9.10...v1.0.0) first release
- [X] New API for error code list with internationalized description
- [X] fixed problem with editor and session save

## [0.9.10](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v0.9.9...v0.9.10) pre release
- [X] many bug fixed in editing and save session

## [0.9.9](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v0.9.8...v0.9.9) public resources
- [X] insert description in land_cover_result
- [X] fixed problems in session save api
- [X] public resource for get parcels from sector_code
- [X] changed geometry editor configuration to avoid errors on dirty geometries

## [0.9.8](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v0.9.7...v0.9.8) bug fixing
- [X] fixed problem with landcover query
- [X] unique key on landcovers and landuses
- [X] get land cover code and land uses code by code
- [X] other parcels on session preview and getEditParcels
- [X] fixed problem in get taskmanager response
- [X] removed geometry check in session validity for land covers
- [X] added description for parcel_land_covers api
- [X] feature/sector_description_viewer
- [X] manage of change taskmanager status motivation
- [X] increased number of codes descriptions in response in support api to 20
- [X] Added liquibase script for dropping geo-units and references
- [X] refactor removed unused fixgeom function

## [0.9.7](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v0.9.6...v0.9.7) viewer update
- [X] updated viewer for sectors information
- [X] changed initial parcel buffer for session creation

## [0.9.6](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v0.9.5...v0.9.6) sectors and refactors
- [X] managing sectors in editing
- [X] correctly create spatial indexes
- [X] cleanup refactor of unused query
- [X] fixed problem in parcel history search
- [X] session geometry adaption in "over" editing
- [X] fixed landocver id search in editing
- [X] fixed problem with oracle null geometries
- [X] skipped land cover editing in parcel preview edit

## [0.9.5](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v0.9.4...v0.9.5) get parcels history
- [X] get parcel history
- [X] checked taskId before call update taskmanager
- [X] reconfigured reasonable max area in conf value

## [0.9.4](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v0.9.3...v0.9.4) clear sessions
- [X] implemented clear other sessions of the current user in creation api
- [X] upgraded abaco bundles dependencies
- [X] little tasks code refactor

## [0.9.3](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v0.9.2...v0.9.3) skipped fix geom
- [X] really fixed performance issue with geometries in session create "fixLockParcelsAndLandCovers"

## [0.9.2](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v0.9.1...v0.9.2) skipped fix geom
- [X] skipped fixLandCoverGeomAndPutInEdit for performances issues

## [0.9.1](https://gitlab.fe.abacogroup.eu/new-agri/lpis-gis-server/compare/v0.9.0...v0.9.1) fix geom
- [X] fix: added functions for sso2 configuration bundle
- [X] feat: fix lock geoms during create sessions
- [X] changed unique key in parcels table liquibase script for sectors blocks

## [0.9.0] Initial version
- [X] Session Resource
   - [X] Simulate edit session preview
   - [X] Create edit session
   - [X] Get edit session data (state, mbr)
   - [X] Update session data
      - [X] dt_last_lock
   - [X] Close edit session
      - [X] save edit session data
      - [X] send to task manager the result
   - [X] Delete edit session
- [X] Check and update session on every edit request...
- [X] Get parcels for the session
- [X] Get Land Covers for the session
- [X] Edit Parcels Edit APIs
   - [X] Preview Create parcel
   - [X] Create Parcel
   - [X] Preview Parcel cut
      - [X] forward cut changes preview to land covers
   - [X] Parcel Cut
      - [X] forward cut changes to land covers
         - [X] sync new parcel land cover assignment
   - [X] Preview Parcel edit
      - [ ] forward changes preview to land covers
         - [X] sync new parcel land cover assignment
   - [X] Parcel edit
      - [X] forward changes to land covers
   - [X] Preview Parcels Merge
      - [X] forward merge preview to land covers
         - [X] sync new parcel land cover assignment
   - [X] Parcels merge
      - [X] forward merge to land covers
         - [X] sync new parcel land cover assignment
   - [X] Delete parcel
      - [X] delete land covers too
- [X] Land Covers Edit APIs
   - [X] Preview Create land cover
   - [X] Create land cover
   - [X] Preview land cover cut
   - [X] land cover Cut
   - [X] Preview land cover edit
   - [X] land cover edit
   - [X] Preview land covers Merge
   - [X] land covers merge
   - [X] Delete land cover
- [X] Get Additional Layers list
- [X] Get Task Manager data
- [X] ~~Mock Data~~
