# Le cose da fare per il suolo in continuo
## Ticket: #143071

Tutte le oprazioni sono a campagne, quindi le date di validità sono una all'anno

### 1. Configurazione 1 a 1 (*suolo in continuo una parcella è un landcover*)

* [ ] **!!** tutte le operazioni geometriche sul landcover sono disabilitate perché la geometria del landcover sarà sempre uguale a quella della particella e non potranno esistere due landcover in una particella
* [X] (crea) particella, non cambia perché già adesso crea una particella "piena" di landcover unico, bene
* [X] (modifica) geometria particella, deve ripetere la stessa modifica al landocver che contienee non devono crearsi più landcover
* [X] (taglia) particella partendo dal presupposto che una particella ha sempre e solo un landcover, di conseguenza il taglia ha già il comportamento corretto anche nella configurazione "1 a 1"
* [X] (ritaglia) come per il taglia è già corretto, perché, sempre partendo dallo stesso presupposto, insieme alla particella viene tagliato anche il suo landcover
* [ ] (unisci) in questo caso Omar deve verificare se questo è specificato nell'analisi, perché in teoria non dovrebbe essere concesso perché si dovrebbero unire anche i landcover che se avessere codice diverso, chi vince? Forse come adesso che il primo selezionato sostituisce tutti i codici landcover di quelli che si vuol unire, nel senso che se seleziono un `seminativo`, faccio merge e poi selezioni un `edifici` ed un `bosco`, diventa tutto `seminativo`
* [X] (elimina) particella questo ovviamente elimina tutto, quindi anche il landcover, perfetto
* [~] (elementi lineari) questo non lo si potrà usare, perché non ha senso, **nascondere**
* [~] (riempi particella) questo non dovrebbe mai servire ma al massimo dovrebbe creare un landcover dello stesso codice dell'unico che esiste ed unirli facendo sì che sia solo uno, in teoria questo dovrebbe essere disabilitato perché anche bagnando lo schermo non dovrebbe mai cancellarsi un pezzo di landcover
* [X] (buffer) questo va corretto perché ad oggi crea un "buco" di landcover o, peggio, ingloba il landcover della particella a cui va a sovrapporsi, così avresti 5 landcover finali, **INVECE** deve far si che la stessa operazione di modifica geometria si deve replicare sul landcover


### 2. Configurazione Particelle con suolo in continuo (*landcover da catalogo*)
#### praticamente i landcover vengono ritagliati sul catalogo configurato che non è niente popò che meno il layer sopra descritto del suolo in continuo
* **!!** tutte le operazioni, perfino anche il cambia codice landocver, sul landcover sono disabilitate perché i dati dei landcover verranno sempre "presi" dal catalogo configurato (suolo in continuo) e l'unica operazione di editing sarà la gestione delle unità arboree
* **!!** ad ogni operazione geometrica sulla particella deve essere eseguito un ritaglio sul catalogo del suolo in continuo ed usare le geometrie, con anche i suoi codici, come landcovers
* [ ] (crea) particella, usare la geometria della creazione come taglio del catalogo usando le geometrie ritagliate, ed i suoi codici, come landcover
* [ ] (modifica) geometria particella, usare la geometria come taglio del catalogo usando le geometrie ritagliate, ed i suoi codici, come landcover
* [ ] (ritaglia) particella, per tutte le particelle create, si ne dovrà usare la geometria per ritagliare il catalogo e fare sempre come detto prima
* [ ] (unisci) particelle, sepmre la stessa logica, la nuova geometria della nuova particella unita servirà per ritagliare il catalogo
* [X] (elimina) particella questo ovviamente elimina tutto, quindi anche il landcover, perfetto
* [~] (elementi lineari) questo non lo si potrà usare, perché non ha senso, **nascondere**
* [~] (riempi particella) questo non lo si potrà usare, perché non ha senso, **nascondere**
* [ ] (buffer) sempre la nuova geometria ritaglia il catalogo ed aggiorna tutti i landcover di conseguenza
* [ ] !!!!!!!!!!!!!!!!
* **N.B.** le unità arboree non devono perdersi, quindi serve capire come mantenerle anche se tutto sotto si aggiorna

### 3. sincronizzazione particelle e suolo continuo
* se viene modificato qualcosa 


## Risposte dell'analista:
* (2) è vero quello che ho scritto per le unità arboree, devono essere mantenute su tutti gli aggiornamenti?
  * cosa succede se un suolo a vite diventasse pascolo?
    * -> *!!!* ATTENZIONE *!!!* qui aggiorneranno l'analisi, ci sarà una nuova configurazione che elencherà uno o più codici landcover che non possono essere modificati :fire: :ambulance: :poop: non possono essere modificati e se un utente li copre con un altro poligono deve funzionare come il "taglia sugli altri poligoni" (CUT_ON_EXISTING)
* (1) se faccio il merge di due particelle con landcover di codici diversi, cosa succede?
  * -> deve funzionare come funziona adesso, quindi nel merge, il primo selezionato viene usato per cambiare il codice di tutti gli altri, come fa adesso praticamente
* capitolo 3.4.5.2 dell'analisi, in che senso corretto landcover?
  * per adesso non conta, e non viene considerato, l'unico dettaglio è che la categoria di lavorazione potrebbe arrivare da task e in quel caso sarà scelta obbligata non modificabile

## Domande per l'analista:
...
  

#### Last:

* sistemare il problema dell'editing dei multi poligoni