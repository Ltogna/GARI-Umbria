# Documentazione LPIS

[[_TOC_]]


## Gestione sessioni

### Creazione nuova sessione

![esempio sessione](img/sessione_lpis.png "Sessione LPIS editor")

la sessione parte dalla parcella azzurra centrale, viene fatto un buffer della sua geometria e prese tutte le parcelle con interazioni, da queste viene calcolato l'MBR, in azzurro, e quindi prese tutte le parcelle con interazioni su questo.   

Questo è l'elenco delle parcelle in lavorazione, se la chiave di configurazione `fl_calc_third_session_level` è lasciato a true, in arancio, su queste viene calcolato, nuovamente, l'MBR, in grigio, che diverrà la geometria di lock della sessione (lpis_edit_sessions.lock_geom).  

Gli id di tutte le particelle in editing vengono salvati nella tabella `lpis_lock_parcels` mentre le geometrie modificate, e solo quelle modificate, vengono salvate nelle tabelle di editing, `lpis_edit_parcels` `lpis_edit_land_covers`.

Al client vengono passate tutte le parcelle in edit, quelle arancio, e tutte quelle con interazioni con la geometria di lock, in rosso chiaro.  

Al motore geometrico di editing (editor) vengono passate tutte le geometrie e se viene modificata una parcella non in lock, viene allargata la geometria di lock, se possibile.
  
Il client fa sempre riferimento al parcel_id, o land_cover_id, le geometrie nuove vengono create con id negativo _(select coalesce(min(parcel_id), 0) -1 from lpis_edit_parcels where parcel_id < 1)_
  
```mermaid
flowchart  LR
    A[TaskID] -->|Ask TaskManager| B(Get ParcelID)
    B --> C
    subgraph lock_geom, srs
    C(SessionID)
    end
    C --> D[lock_parcels]
    D o--o E
    subgraph parcels
    E[Parcels] -->|when edited| F[Edit_Parcels]
    end 
    D o--o G
    subgraph landcovers
    G[LandCovers] -->|when edited| H[Edit_LandCovers]
    end 
    F x-.-x H 
```

... ...

