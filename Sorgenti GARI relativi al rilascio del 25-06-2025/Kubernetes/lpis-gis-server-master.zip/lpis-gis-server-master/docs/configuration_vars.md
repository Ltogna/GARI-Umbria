#### Internal config variables
| Key | Description | Type | is array | Default Value | fl_client |
|:---|:---|:---|:---|:---|:---|
| buffer_size | set buffer for geometry | Double | false | 10.0 | false |
| minimum_valid_lock_area | minimum lock area when a parcel is in editing | Double | false | 1.0 | true |
| maximum_valid_lock_area | maximum lock area when a parcel is in editing | Double | false | 100000000.0 | true |
| maximum_valid_session_h_duration | maximum hours of duration of session | Integer | false | 10 | true |
| maximum_parcels_to_merge | maximum number of parcels in a merge operation | Integer | false | 10 | true |
| maximum_landcovers_to_merge | maximum number of landcovers in a merge operation | Integer | false | 10 | true |
| default_land_cover_code | default land cover code when a land cover is created from modify land covers operation | String | false | 0 | true |
| workflow_scope | the scope for taskmanager workflow transitions request | String | false | lpis-editor | false |
| maximum_valid_search_parcels_geom_area | the maximum area when search for parcels on geometry | Double | false | 100000000.0 | true |
| default_sau_matrix_code | matrix code for recover land cover layer style | String | false | sau | false |
| flag_must_cover_all_landcover | flag to define if, in save, all parcels must be covered of landcovers | Boolean | false | true | true |
| fl_hide_landcovers_layer | flag to hide landcovers layer, flag_must_cover_all_landcover must be true | Boolean | false | false | true |
| default_landcovers_style_matrix_code | matrix code for landcover styles definition | String | false | landcover_style | true |
| maximum_difference_landcover_area_tol | tollerance of land cover area difference with parcel area in mq | Double | false | 3.0 | true |
| flag_merge_land_covers_with_same_code | flag to define if land covers with same code automatically merged on merge parcels operation | Boolean | false | false | false |
| linear_landcover_thicknesses | thicknesses in meters availables on create linear land cover operation | Integer | true | 1,2,3,4,5 | true |
| fl_set_sector_parcel | flag to define if user can set sector of parcel | Boolean | false | true | true |
| fl_set_block_parcel | flag to define if user can set block of parcel | Boolean | false | true | true |
| fl_set_parcel_code | flag to define if user can set code of parcel | Boolean | false | true | true |
| parcel_code_separator | parcel code separator between name and subname | String | false | / | true |
| minimum_update_buffer_size | min buffer during update geometry request | Integer | false | -20 | true |
| maximum_update_buffer_size | max buffer during update geometry request | Integer | false | 20 | true |
| minimum_parcels_area | min parcels area for save session | Integer | false | 1 | true |
| minimum_land_covers_area | min land covers area for save session | Integer | false | 1 | true |
| anomalies_parcel_entity_code | entity code for search anomalies parcels | String | false | REFERENCE_PARCEL | false |
| fl_show_uncategorized_anomaly_types | flag for show anomalies with level UNCATEGORIZED | Boolean | false | false | false |
| fl_force_new_parcel_version | flag for force save session on new parcel version | Boolean | false | false | true |
| public_maximum_valid_search_parcels_geom_area | max area for public apis parcels search | Double | false | 100000000.0 | false |
| public_maximum_parcels_ids_list_req_size | max size for parcels id list in public parcels details api payload request | Integer | false | 100 | false |
| party_registry_directory_url | url for external party registry detail api call | String | false | /party-registry/{tenant}/public/v1/parties/{party_id} | true |
| external_cll_context_path | context path for the customer land link service calls | String | false | /customer-land-link | true |
| fl_coordinates_format_hdms | flag to set coordinates format to "hemisphere degree minute second" instead of latitude/longitude | Boolean | false | false | true |
| fl_hide_coordinates_on_map | flag to hide coordinates on map | Boolean | false | false | true |
| fl_search_external_parcels | flag to search parcels from external source | Boolean | false | false | true |
| fl_enable_campaign_year | flag to enable campaign year | Boolean | false | false | true |
| on_create_parcel_wms_to_show | wms layer path to show in the ui when starting a session to create new parcels | String | true | /lpis/sectors/blocks | true |
| default_wms_parcels_style | wms parcel layer style of type | DrawStyle | false | referenceName: PARCELS<br /> fillRgba: '#B2B2B200'<br /> lineRgba: '#B2B2B2'<br /> lineThick: 2<br /> textColor: '#000000'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: 2.5 | true |
| default_wms_landcovers_style | wms landcover layer style of type | DrawStyle | false | referenceName: LANDCOVERS<br /> fillRgba: '#CACACA44'<br /> lineRgba: '#CACACA55'<br /> lineThick: 1<br /> textColor: '#CACACA'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: 1.8 | true |
| default_wms_sde_parcels_style | wms external source parcels layer style of type | DrawStyle | false | referenceName: SDE_PARCELS<br /> fillRgba: '#B2B2B200'<br /> lineRgba: '#C70404'<br /> lineThick: 2<br /> textColor: '#C70404'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: 2.5 | true |
| default_wms_sectors_style | wms sectors layer style of type | DrawStyle | false | referenceName: SECTORS<br /> fillRgba: '#FFC0CB00'<br /> lineRgba: '#FFC0CB'<br /> lineThick: 2<br /> textColor: '#FFC0CB'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: null | true |
| default_wms_blocks_style | wms blocks layer style of type | DrawStyle | false | referenceName: BLOCKS<br /> fillRgba: '#FEDE0000'<br /> lineRgba: '#FEDE00'<br /> lineThick: 2<br /> textColor: '#FEDE00'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: null | true |
| default_wms_areas_styles | wms areas layer style of type | DrawStyle | true | referenceName: COM<br /> fillRgba: '#D85E0000'<br /> lineRgba: '#D85E00'<br /> lineThick: 2<br /> textColor: '#D85E00'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: 2.5,referenceName: PRO<br /> fillRgba: '#00B4D400'<br /> lineRgba: '#00B4D4'<br /> lineThick: 2<br /> textColor: '#00B4D4'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: null,referenceName: REG<br /> fillRgba: '#CADE5900'<br /> lineRgba: '#CADE59'<br /> lineThick: 2<br /> textColor: '#CADE59'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: null,referenceName: NAZ<br /> fillRgba: '#9F2B0000'<br /> lineRgba: '#9F2B00'<br /> lineThick: 2<br /> textColor: '#9F2B00'<br /> textSize: 15<br /> fromMetersForPixel: null<br /> toMetersForPixel: null | true |
| enable_move_vertex | enable the possibility to "move vertex" in ui | Boolean | false | true | true |
| edit_status_to_exclude_from_stack_search | list of the "edit status" to exclude from stack search | EditStatus | true | null | true |
| cll_max_clear_time_min | maximum clear time (in mins) for party-parcels cache | Integer | false | 5 | true |
| temp_parcels_cache_max_clear_time_min | maximum clear time (in mins) for temporary parcels cache | Integer | false | 300 | true |
| fl_cll_history_load_holders | flag to enable holders column and query param in cll conductions history | Boolean | false | false | true |
| mock_farmland_viewer_parcel_list | flag to enable a mocked response in parcel conductors list read from lpis_mock_party_parcels table | Boolean | false | false | false |
| mocked_conductors_list_json | temporary key as json in a string to force a different conductors list for mocked consistency response | String | false | [] | false |
| default_parcels_line_thick | (deprecated) parcels line thick for layer | Integer | false | 2 | true |
| default_parcels_line_rgba | (deprecated) parcels line rgba color for layer | String | false | #B2B2B2 | true |
| default_parcels_fill_rgba | (deprecated) parcels fill rgba color for layer | String | false | #B2B2B200 | true |
| default_parcels_label_color | (deprecated) parcels label rgba color for layer | String | false | #000000 | true |
| default_parcels_label_size | (deprecated) parcels label size in pixels for layer | Integer | false | 15 | true |
| default_landcovers_label_color | (deprecated) land covers label color for layer | String | false | #CACACA | true |
| default_landcovers_label_size | (deprecated) land covers label size for layer | Integer | false | 15 | true |
| default_landcovers_line_thick | (deprecated) land covers line thick in pixels for layer | Integer | false | 1 | true |
| default_landcovers_line_rgba | (deprecated) land covers line rgba color for layer | String | false | #CACACA55 | true |
| default_landcovers_fill_rgba | (deprecated) land covers fill rgba color for layer | String | false | #CACACA44 | true |
| default_sde_parcels_line_thick | (deprecated) external source parcels line thick for layer | Integer | false | 2 | true |
| default_sde_parcels_line_rgba | (deprecated) external source parcels line rgba color for layer | String | false | #C70404 | true |
| default_sde_parcels_fill_rgba | (deprecated) external source parcels fill rgba color for layer | String | false | #B2B2B200 | true |
| default_sde_parcels_label_color | (deprecated) external source parcels label color for layer | String | false | #C70404 | true |
| default_sde_parcels_label_size | (deprecated) external source parcels label size for layer | Integer | false | 15 | true |
| default_sectors_line_thick | (deprecated) sectors line thick for layer | Integer | false | 2 | true |
| default_sectors_line_rgba | (deprecated) sectors line rgba color for layer | String | false | #FFC0CB | true |
| default_sectors_fill_rgba | (deprecated) sectors fill rgba color for layer | String | false | #FFC0CB00 | true |
| default_sectors_label_color | (deprecated) sectors label color for layer | String | false | #FFC0CB | true |
| default_sectors_label_size | (deprecated) sectors label size for layer | Integer | false | 15 | true |
| default_sector_blocks_line_thick | (deprecated) blocks line thick for layer | Integer | false | 2 | true |
| default_sector_blocks_line_rgba | (deprecated) blocks line rgba color for layer | String | false | #FEDE00 | true |
| default_sector_blocks_fill_rgba | (deprecated) blocks fill rgba color for layer | String | false | #FEDE0000 | true |
| default_sector_blocks_label_color | (deprecated) blocks label color for layer | String | false | #FEDE00 | true |
| default_sector_blocks_label_size | (deprecated) blocks label size for layer | Integer | false | 15 | true |
| default_areas_line_thick | (deprecated) areas line thick for layer | Integer | false | 2 | true |
| default_areas_line_rgba | (deprecated) areas line rgba color for layer | String | false | #C70404 | true |
| default_areas_fill_rgba | (deprecated) areas fill rgba color for layer | String | false | #B2B2B200 | true |
| default_areas_label_color | (deprecated) areas label color for layer | String | false | #C70404 | true |
| default_areas_label_size | (deprecated) areas label size for layer | Integer | false | 15 | true |
