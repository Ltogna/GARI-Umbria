# Internal Plugins

Documentation for implement and use plugin on lpis-gis-server

[TOC]

## Parcel plugin

Plugin for parcel operations, a parcel plugin is an implementation of SdkParcel interface and every method on plugin must be enable on lpis_config table.
Available methods are findParcelBlock, createParcelName, decodeParcelName, decodeParcelSearch, checkParcelName.

The available keys for plugins to set in lpis_config are:
- `plugin_parcel_block`: used to find the block for the parcel,  
- `plugin_create_parcel_name`: used to automatically create the name for the parcel,  
- `plugin_decode_parcel_name`: used to normalize the name for the parcel in update parcel data,  
- `plugin_decode_parcel_search`: used to normalize the name for the parcel in search parcel,  
- `plugin_check_parcel_name`: used to check the name written, and eventually normalized, in update parcel data. 

The value is the name of plugin class to use for method.

### Available plugins

#### InternalParcelPlugin

The internal implementation of plugin is com.abacogroup.lpisgisserver.plugins.InternalParcelPlugin class

##### External config properties

InternalParcelPlugin use the following external properties:

- `create_parcel_code_format`: define format to search for create automatically parcel code
- `initial_parcel_code`: define initial parcel code for create automatically parcel code, if a block not contains parcels with specific format
- `fill_parcel_code`: define characters to fill parcel code when its length is lower than max
- `maximum_parcel_code_length`: define maximum parcel code length (when the separator is defined the code part is the one on the left)
- `minimum_parcel_code_length`: define minimum parcel code length (when the separator is defined the code part is the one on the left)
- `parcel_code_format`: define regEx for parcel code matches control, ex: "^[[0-9][A-Z]]{5}$"
- `maximum_parcel_subcode_length`: define maximum parcel subcode length (subcode is the part to the right of the separator)
- `minimum_parcel_subcode_length`: define minimum parcel subcode length (subcode is the part to the right of the separator)
- `parcel_subcode_format`: define the regEx for parcel subcode matches control, ex: "^[[0-9][A-Z]]{0,3}$" 
- `parcel_code_errors_description`: define a map of json with error name with a map of description for language error codes used are: {length, format, sublength, subformat}

##### Available methods

- `createParcelName`: create automatically a parcel code, it search the max of parcel code, added one and fill code with fill characters if its length is lower than max. The external properties used are create_parcel_code_format, maximum_parcel_code_length, fill_parcel_code and initial_parcel_code
- `findParcelBlock`: retrieve block of parcel that intersect higher area of parcel, or the nearest block if parcel is not in a block area
- `decodeParcelSearch`: transform parcel code to upper case and fill parcel code with fill characters if its length is lower than max. The external properties used are  maximum_parcel_code_length and fill_parcel_code
- `checkParcelName`: validate a parcel code and, if is not valid, return the correct message error for lang. The external properties used are maximum_parcel_code_length, minimum_parcel_code_length, maximum_parcel_subcode_length, minimum_parcel_subcode_length, parcel_code_format and parcel_code_errors_description




