# Changelog

### [v2.0.3](https://gitlab.fe.abacogroup.eu/patri-renew/lau-service/compare/v2.0.2...v2.0.3) (2024-03-21)

### Fixes
* **municipality:** :bug: fix issue in query for search all municipality, closes [#134620](https://abacogroup.easyredmine.com/issues/134620)


### [v2.0.2](https://gitlab.fe.abacogroup.eu/patri-renew/lau-service/compare/v2.0.1...v2.0.2) (2023-12-19)

#### Fixes
* **tests:** fix test yaml config files
* **auth:** :bug: fix broken application authentication

#### Other
* **docs:** :bug: fix issue in db docs creation with schemaspy
* **docs:** :bug: fix issue in db docs creation with schemaspy


## v1.1.0 (2023-02-02)

### Fixes
* using correct variable
* added rabbitmq as a ci service and added test configs for pg and ora
* added wait for oracle jshell script
