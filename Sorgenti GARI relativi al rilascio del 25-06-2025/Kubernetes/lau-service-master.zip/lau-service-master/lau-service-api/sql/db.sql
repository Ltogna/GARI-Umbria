-- TODO COMMENTI


create table lau_i18n_values
(
    tenant_id  varchar(100)  not null,
    table_name varchar(100)  not null,
    field_name varchar(100)  not null,
    i18n_value varchar(4000) not null,
    lang       varchar(20)   not null,
    i18n_text  varchar(4000) not null,
    constraint lau_i18n_values_pk primary key (tenant_id, table_name, field_name, i18n_value, lang)
);

create table lau_country
(
    code      varchar(100) not null,
    tenant_id varchar(100) not null,
    fl_active int          not null default 1,
    constraint lau_country_pk primary key (tenant_id, code),
    constraint lau_country_ck1 check (fl_active in (0, 1))
);

create table lau_region
(
    code         varchar(100) not null,
    tenant_id    varchar(100) not null,
    country_code varchar(100) not null,
    short_descr  varchar(100) not null,
    fl_active    int          not null default 1,
    constraint lau_region_pk primary key (tenant_id, code),
    constraint lau_region_uk1 unique (tenant_id, country_code, short_descr),
    constraint lau_region_fk1 foreign key (tenant_id, country_code) references lau_country (tenant_id, code),
    constraint lau_region_ck1 check (fl_active in (0, 1))
);

create table lau_district
(
    code        varchar(100) not null,
    tenant_id   varchar(100) not null,
    region_code varchar(100) not null,
    short_descr varchar(100) not null,
    fl_active   int          not null default 1,
    constraint lau_district_pk primary key (tenant_id, code),
    constraint lau_district_uk1 unique (tenant_id, region_code, short_descr),
    constraint lau_district_fk1 foreign key (tenant_id, region_code) references lau_region (tenant_id, code),
    constraint lau_district_ck1 check (fl_active in (0, 1))
);

create table lau_municipality
(
    code          varchar(100) not null,
    tenant_id     varchar(100) not null,
    district_code varchar(100) not null,
    short_descr   varchar(100) not null,
    fl_active     int          not null default 1,
    constraint lau_municipality_pk primary key (tenant_id, code),
    constraint lau_municipality_uk1 unique (tenant_id, district_code, short_descr),
    constraint lau_municipality_fk1 foreign key (tenant_id, district_code) references lau_district (tenant_id, code),
    constraint lau_municipality_ck1 check (fl_active in (0, 1))
);
