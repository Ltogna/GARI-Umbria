insert into lau_country
    (code, tenant_id)
values ('ITA', 'master'),
       ('USA', 'master'),
       ('GBR', 'master')
;

insert into lau_country
    (code, tenant_id, fl_active)
values ('YUG', 'master', 0);

--

insert into lau_region
    (code, tenant_id, country_code, short_descr)
values ('ITA_20', 'master', 'ITA', '20'), -- Sardegna
       ('USA_FL', 'master', 'USA', 'FL'), -- Florida
       ('YUG_00', 'master', 'YUG', '00'), -- generica provincia
       ('ITA_10', 'master', 'ITA', '10'), -- Lombardia
       ('ITA_12', 'master', 'ITA', '12') -- Lazio
;

insert into lau_region
    (code, tenant_id, country_code, short_descr, fl_active)
values ('USA_ZZ', 'master', 'USA', 'ZZ', 0)
;
--

insert into lau_district
    (code, tenant_id, region_code, short_descr)
values ('ITA_20_292', 'master', 'ITA_20', '292'),     -- CM Cagliari
       ('ITA_20_111', 'master', 'ITA_20', '111'),     -- Oristano
       ('USA_FL_DUVAL', 'master', 'USA_FL', 'DUVAL'), -- Duval
       ('USA_ZZ_XXX', 'master', 'USA_ZZ', 'XXX'),
       ('YUG_00_000', 'master', 'YUG_00', '000'),
       ('ITA_10_019', 'master', 'ITA_10', '019'),     -- Cremona
       ('ITA_10_020', 'master', 'ITA_10', '020'),     -- Mantova
       ('ITA_12_258', 'master', 'ITA_12', '258') -- CM Roma
;

insert into lau_district
    (code, tenant_id, region_code, short_descr, fl_active)
values ('ITA_12_058', 'master', 'ITA_12', '058', 0), -- Prov. Roma
       ('USA_ZZ_ZZZ', 'master', 'USA_ZZ', 'ZZZ', 0)
;

--

insert into lau_municipality
    (code, tenant_id, district_code, short_descr)
values ('ITA_20_292_074', 'master', 'ITA_20_292', '074'),             -- 092074 Sestu
       ('USA_FL_DUVAL_1235000', 'master', 'USA_FL_DUVAL', '1235000'), -- Jacksonville
       ('YUG_00_000_000', 'master', 'YUG_00_000', '000'),
       ('ITA_12_058_091', 'master', 'ITA_12_058', '091'),             -- 058091 Roma
       ('ITA_12_258_091', 'master', 'ITA_12_258', '091'),             -- 058091 Roma
       ('ITA_20_292_003', 'master', 'ITA_20_292', '003'),             -- 092003 Assemini
       ('ITA_20_292_015', 'master', 'ITA_20_292', '015'),             -- 092015 Decimomannu
       ('ITA_20_292_009', 'master', 'ITA_20_292', '009'),             -- 092009 Cagliari
       ('ITA_10_019_036', 'master', 'ITA_10_019', '036'),             -- 019036 Cremona
       ('ITA_10_019_035', 'master', 'ITA_10_019', '035'),             -- 019035 Crema
       ('ITA_10_020_030', 'master', 'ITA_10_020', '030'),             -- 020030 Mantova
       ('ITA_10_020_010', 'master', 'ITA_10_020', '010') -- 020010 Suzzara
;

insert into lau_municipality
    (code, tenant_id, district_code, short_descr, fl_active)
values ('ITA_10_020_069', 'master', 'ITA_10_020', '069', 0) -- 020069 Virgilio
;

-------------------------------------------------------------------------------------------------------

INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
    (select tenant_id, 'lau_country', 'code', code, 'en', '-'
     from lau_country
     where tenant_id = 'master'
     union
     select tenant_id, 'lau_country', 'code', code, 'it', '-'
     from lau_country
     where tenant_id = 'master');

INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
    (select tenant_id, 'lau_region', 'code', code, 'en', '-'
     from lau_region
     where tenant_id = 'master'
     union
     select tenant_id, 'lau_region', 'code', code, 'it', '-'
     from lau_region
     where tenant_id = 'master');

INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
    (select tenant_id, 'lau_district', 'code', code, 'en', '-'
     from lau_district
     where tenant_id = 'master'
     union
     select tenant_id, 'lau_district', 'code', code, 'it', '-'
     from lau_district
     where tenant_id = 'master');

INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
    (select tenant_id, 'lau_municipality', 'code', code, 'en', '-'
     from lau_municipality
     where tenant_id = 'master'
     union
     select tenant_id, 'lau_municipality', 'code', code, 'it', '-'
     from lau_municipality
     where tenant_id = 'master');


update lau_i18n_values
set i18n_text = lower(i18n_value) || '_' || lang
WHERE table_name in ('lau_municipality', 'lau_district', 'lau_region', 'lau_country')
  and tenant_id = 'master';

update lau_i18n_values
set i18n_text = 'Italia'
where i18n_value = 'ITA'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Italy'
where i18n_value = 'ITA'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'United States'
where i18n_value = 'USA'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Stati Uniti'
where i18n_value = 'USA'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Regno Unito'
where i18n_value = 'GBR'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'United Kingdom'
where i18n_value = 'GBR'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Yugoslavia'
where i18n_value = 'YUG'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Jugoslavia'
where i18n_value = 'YUG'
  and lang = 'it';

update lau_i18n_values
set i18n_text = 'Lombardia it'
where i18n_value = 'ITA_10'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Lombardia en'
where i18n_value = 'ITA_10'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Sardegna en'
where i18n_value = 'ITA_20'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Sardegna it'
where i18n_value = 'ITA_20'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Florida'
where i18n_value = 'USA_FL'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Florida'
where i18n_value = 'USA_FL'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Lazio it'
where i18n_value = 'ITA_12'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Lazio en'
where i18n_value = 'ITA_12'
  and lang = 'en';

update lau_i18n_values
set i18n_text = 'Città metropolitana di Cagliari en'
where i18n_value = 'ITA_20_292'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Città metropolitana di Cagliari it'
where i18n_value = 'ITA_20_292'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Provincia di Oristano it'
where i18n_value = 'ITA_20_111'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Provincia di Oristano en'
where i18n_value = 'ITA_20_111'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Provincia di Cremona en'
where i18n_value = 'ITA_10_019'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Provincia di Cremona it'
where i18n_value = 'ITA_10_019'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Provincia di Mantova it'
where i18n_value = 'ITA_10_020'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Provincia di Mantova en'
where i18n_value = 'ITA_10_020'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Città metropolitana di Roma en'
where i18n_value = 'ITA_12_258'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Città metropolitana di Roma it'
where i18n_value = 'ITA_12_258'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Provincia di Roma it'
where i18n_value = 'ITA_12_058'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Provincia di Roma en'
where i18n_value = 'ITA_12_058'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Duval it'
where i18n_value = 'USA_FL_DUVAL'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Duval en'
where i18n_value = 'USA_FL_DUVAL'
  and lang = 'en';

update lau_i18n_values
set i18n_text = 'Sestu en'
where i18n_value = 'ITA_20_292_074'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Sestu it'
where i18n_value = 'ITA_20_292_074'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Cagliari it'
where i18n_value = 'ITA_20_292_009'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Cagliari en'
where i18n_value = 'ITA_20_292_009'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Cremona en'
where i18n_value = 'ITA_10_019_036'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Cremona it'
where i18n_value = 'ITA_10_019_036'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Crema it'
where i18n_value = 'ITA_10_019_035'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Crema en'
where i18n_value = 'ITA_10_019_035'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Suzzara en'
where i18n_value = 'ITA_10_020_010'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Suzzara it'
where i18n_value = 'ITA_10_020_010'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Jacksonville en'
where i18n_value = 'USA_FL_DUVAL_1235000'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Jacksonville it'
where i18n_value = 'USA_FL_DUVAL_1235000'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Roma en'
where i18n_value = 'ITA_12_058_091'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Roma it'
where i18n_value = 'ITA_12_058_091'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Roma en'
where i18n_value = 'ITA_12_258_091'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Roma it'
where i18n_value = 'ITA_12_258_091'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Assemini en'
where i18n_value = 'ITA_20_292_003'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Assemini it'
where i18n_value = 'ITA_20_292_003'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Decimomannu en'
where i18n_value = 'ITA_20_292_015'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Decimomannu it'
where i18n_value = 'ITA_20_292_015'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Mantova en'
where i18n_value = 'ITA_10_020_030'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Mantova it'
where i18n_value = 'ITA_10_020_030'
  and lang = 'it';
update lau_i18n_values
set i18n_text = 'Virgilio en'
where i18n_value = 'ITA_10_020_069'
  and lang = 'en';
update lau_i18n_values
set i18n_text = 'Virgilio it'
where i18n_value = 'ITA_10_020_069'
  and lang = 'it';


