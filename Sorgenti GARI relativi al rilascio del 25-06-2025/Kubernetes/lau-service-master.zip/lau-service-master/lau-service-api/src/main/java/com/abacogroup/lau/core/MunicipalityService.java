package com.abacogroup.lau.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.MunicipalityDataRes;
import com.abacogroup.lau.api.MunicipalityRes;
import com.abacogroup.lau.db.ntt.MunicipalityEntity;
import com.abacogroup.lau.resources.req.MunicipalitySearchReq;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;

public interface MunicipalityService {

	Optional<MunicipalityEntity> loadMunicipalityByCode(String tenantId, String code);

	InfiniteListResults<MunicipalityRes> searchMunicipalities(ReqContext reqContext, MunicipalitySearchReq searchRequest,
			String nextKey);

	List<MunicipalityDataRes> searchByI18nName(ReqContext reqContext, MunicipalitySearchReq searchRequest);

	Optional<MunicipalityRes> getMunicipalityByCode(ReqContext reqContext, String code);

	MunicipalityRes save(ReqContext reqContext, MunicipalityRes municipality);
}
