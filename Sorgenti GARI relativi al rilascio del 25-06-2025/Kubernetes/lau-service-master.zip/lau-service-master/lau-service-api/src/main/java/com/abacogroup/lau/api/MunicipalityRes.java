package com.abacogroup.lau.api;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;
import org.jdbi.v3.core.mapper.Nested;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class MunicipalityRes extends MunicipalityDataRes {

	@Nested("di")
	private DistrictRes district;

}
