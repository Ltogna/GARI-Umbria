package com.abacogroup.lau.resources.publicapis;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.v1.DistrictDataResponseV1;
import com.abacogroup.lau.api.v1.DistrictResponseV1;
import com.abacogroup.lau.api.v1.req.DistrictSearchRequestV1;
import com.abacogroup.lau.core.DistrictV1Service;
import com.abacogroup.lau.resources.PublicResourceConstants;
import com.abacogroup.lau.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.dropwizard.jersey.validation.ValidationErrorMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import java.util.List;
import jakarta.annotation.security.PermitAll;
import jakarta.validation.Valid;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(PublicResourceConstants.API_V1_PUB + "/districts")
@PermitAll
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@io.swagger.v3.oas.annotations.tags.Tag(name = "Districts", description = "Operations on districts")
public class DistrictPublicResource {

	private final DistrictV1Service districtService;

	public DistrictPublicResource(DistrictV1Service districtService) {
		this.districtService = districtService;
	}

	@Operation(summary = "InfiniteListResults of districts", description = "Get list of districts filtered with criteria", responses = {
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of districts (sorted/filtered)",
					content = @Content(mediaType = "application/json",
							schema = @Schema(ref = "#/components/schemas/InfiniteListResultsDistrictResponseV1")))
	})
	@GET
	//@RolesAllowed()
	public InfiniteListResults<DistrictResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@QueryParam("nextKey") String nextKey,
			@BeanParam DistrictSearchRequestV1 searchRequest) {
		ReqContext reqContext = new ReqContext(user, lang);
		return districtService.searchDistricts(reqContext, searchRequest, nextKey);
	}

	@Operation(summary = "List of districts by name", description = "Get list of districts filtered by name starting with given `i18nName`", responses = {
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of *first 10* districts (sorted/filtered)",
					content = @Content(mediaType = "application/json",
							array = @ArraySchema(schema = @Schema(implementation = DistrictDataResponseV1.class)))),
			@ApiResponse(responseCode = "400", description = "not valid query param `regionCode`",
					content = @Content(schema = @Schema(implementation = ValidationErrorMessage.class)))
	})
	@GET()
	@Path("/names")
	//@RolesAllowed()
	public List<DistrictDataResponseV1> searchByI18nName(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Valid @BeanParam DistrictSearchRequestV1 searchRequest) {
		ReqContext reqContext = new ReqContext(user, lang);
		return districtService.searchByI18nName(reqContext, searchRequest);
	}

	@Operation(summary = "Find district by code", description = "Get district info based on its code", responses = {
			@ApiResponse(responseCode = "200", description = "Successfully, district is found",
					content = @Content(mediaType = "application/json",
							schema = @Schema(implementation = DistrictResponseV1.class, nullable = true))),
			@ApiResponse(responseCode = "204", description = "District is not found")
	})
	@GET
	@Path("/{code}")
	//@RolesAllowed()
	public DistrictResponseV1 getByCode(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("code") String code) {
		ReqContext reqContext = new ReqContext(user, lang);
		return this.districtService.getDistrictByCode(reqContext, code)
				.orElse(null);
	}

}
