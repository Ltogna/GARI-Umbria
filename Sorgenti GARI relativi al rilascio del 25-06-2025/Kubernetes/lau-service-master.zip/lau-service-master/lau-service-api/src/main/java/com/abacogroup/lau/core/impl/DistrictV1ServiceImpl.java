package com.abacogroup.lau.core.impl;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.v1.DistrictDataResponseV1;
import com.abacogroup.lau.api.v1.DistrictResponseV1;
import com.abacogroup.lau.api.v1.req.DistrictSearchRequestV1;
import com.abacogroup.lau.core.DistrictService;
import com.abacogroup.lau.core.DistrictV1Service;
import com.abacogroup.lau.resources.publicapis.mapper.DistrictMapper;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DistrictV1ServiceImpl implements DistrictV1Service {

	private final DistrictService districtService;
	private final DistrictMapper mapper;

	public DistrictV1ServiceImpl(DistrictService districtService) {
		this.districtService = districtService;
		this.mapper = DistrictMapper.INSTANCE;
	}

	@Override
	public InfiniteListResults<DistrictResponseV1> searchDistricts(ReqContext reqContext, DistrictSearchRequestV1 searchRequest, String nextKey) {
		return districtService.searchDistricts(reqContext, mapper.fromV1(searchRequest), nextKey)
				.map(mapper::toV1);
	}

	@Override
	public List<DistrictDataResponseV1> searchByI18nName(ReqContext reqContext, DistrictSearchRequestV1 searchRequest) {
		return districtService.searchByI18nName(reqContext, mapper.fromV1(searchRequest)).stream()
				.map(mapper::toV1)
				.collect(Collectors.toList());
	}

	@Override
	public Optional<DistrictResponseV1> getDistrictByCode(ReqContext reqContext, String code) {
		return districtService.getDistrictByCode(reqContext, code)
				.map(mapper::toV1);
	}

}
