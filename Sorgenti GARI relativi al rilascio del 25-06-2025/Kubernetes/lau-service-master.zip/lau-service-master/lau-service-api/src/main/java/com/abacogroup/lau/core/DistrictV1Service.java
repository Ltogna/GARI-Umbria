package com.abacogroup.lau.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.v1.DistrictDataResponseV1;
import com.abacogroup.lau.api.v1.DistrictResponseV1;
import com.abacogroup.lau.api.v1.req.DistrictSearchRequestV1;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;

public interface DistrictV1Service {
	InfiniteListResults<DistrictResponseV1> searchDistricts(ReqContext reqContext, DistrictSearchRequestV1 searchRequest, String nextKey);

	List<DistrictDataResponseV1> searchByI18nName(ReqContext reqContext, DistrictSearchRequestV1 searchRequest);

	Optional<DistrictResponseV1> getDistrictByCode(ReqContext reqContext, String code);
}
