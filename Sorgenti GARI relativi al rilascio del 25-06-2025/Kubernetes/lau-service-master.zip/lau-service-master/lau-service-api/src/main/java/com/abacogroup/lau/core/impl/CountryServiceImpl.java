package com.abacogroup.lau.core.impl;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.CountryRes;
import com.abacogroup.lau.core.CountryService;
import com.abacogroup.lau.db.dao.CountryDAO;
import com.abacogroup.lau.db.ntt.CountryEntity;
import com.abacogroup.lau.resources.mappers.CountryMapper;
import com.abacogroup.lau.resources.req.CountrySearchReq;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CountryServiceImpl implements CountryService {

	private final CountryDAO countryDAO;

	public CountryServiceImpl(CountryDAO countryDAO) {
		this.countryDAO = countryDAO;
	}

	@Override
	public Optional<CountryEntity> loadCountryByCode(String tenantId, String code) {
		return countryDAO.findByCode(code, tenantId);
	}

	@Override
	public InfiniteListResults<CountryRes> searchCountries(ReqContext reqContext, CountrySearchReq searchRequest,
			String nextKey) {
		Criteria innerCriteria = searchRequest.getInnerCriteria();
		Criteria outerCriteria = searchRequest.getOuterCriteria();
		OrderBy sort = searchRequest.getSort();

		InfiniteListResults<CountryRes> countries = countryDAO.infinite(() ->
						countryDAO.searchAll(innerCriteria, outerCriteria, sort, reqContext),
				nextKey, searchRequest.getPageSize());
		return countries;
	}

	@Override
	public List<CountryRes> searchByI18nName(ReqContext reqContext, CountrySearchReq searchRequest) {
		// limit to first 10 elements
		return this.searchCountries(reqContext, searchRequest, null).getRecords();
	}

	@Override
	public Optional<CountryRes> getCountryByCode(ReqContext reqContext, String code) {
		return countryDAO.searchByCode(code, reqContext);
	}

	@Override
	public CountryRes save(ReqContext reqContext, CountryRes country) {
		CountryEntity entity = CountryMapper.INSTANCE.dtoToEntity(country);
		entity.setTenantId(reqContext.getTenantId());
		countryDAO.insert(entity);
		return countryDAO.searchByCode(country.getCode(), reqContext).orElse(null);
	}
}
