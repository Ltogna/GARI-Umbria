package com.abacogroup.lau.core.impl;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.RegionDataRes;
import com.abacogroup.lau.api.RegionRes;
import com.abacogroup.lau.core.RegionService;
import com.abacogroup.lau.db.dao.RegionDAO;
import com.abacogroup.lau.db.ntt.RegionEntity;
import com.abacogroup.lau.resources.mappers.RegionMapper;
import com.abacogroup.lau.resources.req.RegionSearchReq;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RegionServiceImpl implements RegionService {

	private final RegionDAO regionDAO;

	public RegionServiceImpl(RegionDAO regionDAO) {
		this.regionDAO = regionDAO;
	}

	@Override
	public Optional<RegionEntity> loadRegionByCode(String tenantId, String code) {
		return regionDAO.findByCode(code, tenantId);
	}

	@Override
	public InfiniteListResults<RegionRes> searchRegions(ReqContext reqContext, RegionSearchReq searchRequest, String nextKey) {
		Criteria innerCriteria = searchRequest.getInnerCriteria();
		Criteria outerCriteria = searchRequest.getOuterCriteria();
		OrderBy sort = searchRequest.getSort();

		InfiniteListResults<RegionRes> regions = regionDAO.infinite(() ->
						regionDAO.searchAll(innerCriteria, outerCriteria, sort, reqContext),
				nextKey, searchRequest.getPageSize());
		return regions;
	}

	@Override
	public List<RegionDataRes> searchByI18nName(ReqContext reqContext, RegionSearchReq searchRequest) {
		// limit to first 10 elements
		return this.searchRegions(reqContext, searchRequest, null)
				.map(region -> {
					region.setCountry(null);
					return ((RegionDataRes) region);
				}).getRecords();
	}

	@Override
	public Optional<RegionRes> getRegionByCode(ReqContext reqContext, String code) {
		return regionDAO.searchByCode(code, reqContext);
	}

	@Override
	public RegionRes save(ReqContext reqContext, RegionRes region) {
		RegionEntity entity = RegionMapper.INSTANCE.dtoToEntity(region);
		entity.setTenantId(reqContext.getTenantId());
		regionDAO.insert(entity);
		return regionDAO.searchByCode(region.getCode(), reqContext).orElse(null);
	}

}
