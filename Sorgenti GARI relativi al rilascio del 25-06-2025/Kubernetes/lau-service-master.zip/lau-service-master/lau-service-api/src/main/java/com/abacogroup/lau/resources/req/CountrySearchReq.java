package com.abacogroup.lau.resources.req;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.abacogroup.jdbi.orderby.SortDirection;
import com.abacogroup.lau.resources.ResourceConstants;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class CountrySearchReq implements BaseSearchReq {

	@Parameter(in = ParameterIn.QUERY, description = "Name starting with")
	@QueryParam("i18nName")
	private String i18nName;

	@QueryParam("code")
	private String code;

	@DefaultValue("only_active")
	@QueryParam("active")
	private ActiveEnum active;

	@Override
	public int getPageSize() {
		return ResourceConstants.PAGE_SIZE;
	}

	@Override
	public Criteria getCriteria(ReqContext ctx) {
		return getInnerCriteria();
	}

	@JsonIgnore
	@Schema(hidden = true)
	public Criteria getInnerCriteria() {
		List<Criteria> specs = new ArrayList<>();

		Optional.ofNullable(getCode())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("co.code").eq(v.toUpperCase())));

		String activeFieldName = "co.fl_active";
		Optional.ofNullable(getActive())
				.ifPresentOrElse(v -> {
							switch (v) {
							case all:
								break;
							case not_active:
								specs.add(CriteriaBuilder.number(activeFieldName).eq(0));
								break;
							case only_active:
								specs.add(CriteriaBuilder.number(activeFieldName).eq(1));
								break;
							}
						},
						() -> specs.add(CriteriaBuilder.number(activeFieldName).eq(1))
				);

		return CriteriaBuilder.and(specs.toArray(new Criteria[0]));
	}

	@JsonIgnore
	@Schema(hidden = true)
	public Criteria getOuterCriteria() {
		List<Criteria> specs = new ArrayList<>();

		Optional.ofNullable(getI18nName())
				.filter(StringUtils::isNotBlank)
				.ifPresent(v -> specs.add(CriteriaBuilder.string("co_.i18n_name").caseInsensitiveStartsWith(v)));

		return CriteriaBuilder.and(specs.toArray(new Criteria[0]));
	}

	@Override
	public OrderByElement getSort() {
		return OrderByBuilder.field("co_.i18n_name").direction(SortDirection.ASC);
	}
}
