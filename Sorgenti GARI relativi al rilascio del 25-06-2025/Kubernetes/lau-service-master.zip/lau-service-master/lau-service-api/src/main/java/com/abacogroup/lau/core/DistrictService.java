package com.abacogroup.lau.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.DistrictDataRes;
import com.abacogroup.lau.api.DistrictRes;
import com.abacogroup.lau.db.ntt.DistrictEntity;
import com.abacogroup.lau.resources.req.DistrictSearchReq;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;

public interface DistrictService {

	Optional<DistrictEntity> loadDistrictByCode(String tenantId, String code);

	InfiniteListResults<DistrictRes> searchDistricts(ReqContext reqContext, DistrictSearchReq searchRequest,
			String nextKey);

	List<DistrictDataRes> searchByI18nName(ReqContext reqContext, DistrictSearchReq searchRequest);

	Optional<DistrictRes> getDistrictByCode(ReqContext reqContext, String code);

	DistrictRes save(ReqContext reqContext, DistrictRes district);
}
