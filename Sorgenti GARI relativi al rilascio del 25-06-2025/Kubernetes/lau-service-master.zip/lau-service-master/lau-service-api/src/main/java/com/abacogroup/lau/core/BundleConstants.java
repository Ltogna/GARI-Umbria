package com.abacogroup.lau.core;

public interface BundleConstants {

	String SYSTEM_USER = "system";
	String DOMAIN_LAU = "lau";
	String DOMAIN_I18N = "i18n";
	String JSONL_COMMENT = "--";

}
