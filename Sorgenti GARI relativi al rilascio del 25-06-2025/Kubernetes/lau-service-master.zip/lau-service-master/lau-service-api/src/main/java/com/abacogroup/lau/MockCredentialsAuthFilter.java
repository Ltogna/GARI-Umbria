package com.abacogroup.lau;

import io.dropwizard.auth.AuthFilter;
import io.dropwizard.auth.basic.BasicCredentials;
import java.io.IOException;
import java.security.Principal;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.SecurityContext;

public class MockCredentialsAuthFilter<P extends Principal> extends AuthFilter<BasicCredentials, P> {

	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException {
		final BasicCredentials credentials =
				getCredentials(requestContext.getHeaders().getFirst(HttpHeaders.AUTHORIZATION));
		if (!authenticate(requestContext, credentials, SecurityContext.BASIC_AUTH)) {
			throw new WebApplicationException(unauthorizedHandler.buildResponse(prefix, realm));
		}
	}

	private BasicCredentials getCredentials(String first) {
		return new BasicCredentials("mockuser@example.com", "password");
	}

	public static class Builder<P extends Principal> extends
			AuthFilterBuilder<BasicCredentials, P, MockCredentialsAuthFilter<P>> {

		@Override
		protected MockCredentialsAuthFilter<P> newInstance() {
			return new MockCredentialsAuthFilter<>();
		}
	}
}
