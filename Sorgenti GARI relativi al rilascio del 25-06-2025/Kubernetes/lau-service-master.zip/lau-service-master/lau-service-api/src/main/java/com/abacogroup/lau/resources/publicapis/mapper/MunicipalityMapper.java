package com.abacogroup.lau.resources.publicapis.mapper;

import com.abacogroup.lau.api.MunicipalityDataRes;
import com.abacogroup.lau.api.MunicipalityRes;
import com.abacogroup.lau.api.v1.MunicipalityDataResponseV1;
import com.abacogroup.lau.api.v1.MunicipalityResponseV1;
import com.abacogroup.lau.api.v1.req.MunicipalitySearchRequestV1;
import com.abacogroup.lau.resources.req.MunicipalitySearchReq;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface MunicipalityMapper {
	MunicipalityMapper INSTANCE = Mappers.getMapper(MunicipalityMapper.class);

	MunicipalityResponseV1 toV1(MunicipalityRes res);

	MunicipalityDataResponseV1 toV1(MunicipalityDataRes res);

	MunicipalitySearchReq fromV1(MunicipalitySearchRequestV1 requestV1);

}
