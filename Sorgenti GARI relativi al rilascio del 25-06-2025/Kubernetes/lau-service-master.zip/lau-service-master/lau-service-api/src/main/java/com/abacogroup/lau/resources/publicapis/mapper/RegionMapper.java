package com.abacogroup.lau.resources.publicapis.mapper;

import com.abacogroup.lau.api.RegionDataRes;
import com.abacogroup.lau.api.RegionRes;
import com.abacogroup.lau.api.v1.RegionDataResponseV1;
import com.abacogroup.lau.api.v1.RegionResponseV1;
import com.abacogroup.lau.api.v1.req.RegionSearchRequestV1;
import com.abacogroup.lau.resources.req.RegionSearchReq;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface RegionMapper {
	RegionMapper INSTANCE = Mappers.getMapper(RegionMapper.class);

	RegionResponseV1 toV1(RegionRes res);

	RegionDataResponseV1 toV1(RegionDataRes res);

	List<RegionDataResponseV1> toV1List(List<RegionDataRes> res);

	RegionSearchReq fromV1(RegionSearchRequestV1 requestV1);

}
