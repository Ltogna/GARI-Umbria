package com.abacogroup.lau.resources.req;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.OrderByElement;
import com.abacogroup.jdbi.orderby.SortDirection;
import com.abacogroup.lau.resources.ResourceConstants;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class MunicipalitySearchReq implements BaseSearchReq {

	@Parameter(in = ParameterIn.QUERY, description = "Name starting with")
	@QueryParam("i18nName")
	private String i18nName;

	@QueryParam("code")
	private String code;

	@DefaultValue("only_active")
	@QueryParam("active")
	private ActiveEnum active;

	@QueryParam("countryCode")
	private String countryCode;

	@QueryParam("regionCode")
	private String regionCode;

	@QueryParam("districtCode")
	private String districtCode;

	@QueryParam("countryI18n")
	private String countryI18n;

	@QueryParam("regionI18n")
	private String regionI18n;

	@QueryParam("districtI18n")
	private String districtI18n;

	@QueryParam("pageSize")
	@DefaultValue("10")
	@Min(10)
	@Max(200)
	private Integer pageSize;

	@Override
	public int getPageSize() {
		return pageSize == null ? ResourceConstants.PAGE_SIZE : pageSize;
	}

	@Override
	public Criteria getCriteria(ReqContext ctx) {
		return this.getInnerCriteria();
	}

	@JsonIgnore
	@Schema(hidden = true)
	private Criteria getInnerCriteria() {
		List<Criteria> specs = new ArrayList<>();

		Optional.ofNullable(getCode())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("mu.code").eq(v.toUpperCase())));

		String activeFieldName = "mu.fl_active";
		String activeCountryFieldName = "co.fl_active";
		String activeRegionFieldName = "re.fl_active";
		String activeDistrictFieldName = "di.fl_active";
		Optional.ofNullable(getActive())
				.ifPresentOrElse(v -> {
					switch (v) {
						case all:
							break;
						case not_active:
							specs.add(CriteriaBuilder.or(
									CriteriaBuilder.number(activeFieldName).eq(0),
									CriteriaBuilder.number(activeCountryFieldName).eq(0),
									CriteriaBuilder.number(activeRegionFieldName).eq(0),
									CriteriaBuilder.number(activeDistrictFieldName).eq(0)));
							break;
						case only_active:
							specs.add(CriteriaBuilder.number(activeFieldName).eq(1));
							specs.add(CriteriaBuilder.number(activeCountryFieldName).eq(1));
							specs.add(CriteriaBuilder.number(activeRegionFieldName).eq(1));
							specs.add(CriteriaBuilder.number(activeDistrictFieldName).eq(1));
							break;
					}
				}, () -> {
					specs.add(CriteriaBuilder.number(activeFieldName).eq(1));
					specs.add(CriteriaBuilder.number(activeCountryFieldName).eq(1));
					specs.add(CriteriaBuilder.number(activeRegionFieldName).eq(1));
					specs.add(CriteriaBuilder.number(activeDistrictFieldName).eq(1));
				});

		Optional.ofNullable(getCountryCode())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("co.code").eq(v.toUpperCase())));

		Optional.ofNullable(getRegionCode())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("re.code").eq(v.toUpperCase())));

		Optional.ofNullable(getDistrictCode())
				.ifPresent(v -> specs.add(CriteriaBuilder.string("di.code").eq(v.toUpperCase())));

		return CriteriaBuilder.and(specs.toArray(new Criteria[0]));
	}

	@Override
	public OrderByElement getSort() {
		return OrderByBuilder.field("mu_.i18n_name").direction(SortDirection.ASC);
	}
}
