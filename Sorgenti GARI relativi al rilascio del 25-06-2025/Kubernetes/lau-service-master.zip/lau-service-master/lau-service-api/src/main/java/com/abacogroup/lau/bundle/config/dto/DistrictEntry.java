package com.abacogroup.lau.bundle.config.dto;

import com.abacogroup.lau.bundle.config.i18n.I18nMap;
import com.abacogroup.lau.core.utils.Bool2IntDeserializer;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Data;

@Data
public class DistrictEntry implements LauEntry {

	private String code;

	private I18nMap description;

	@JsonProperty("short_descr")
	private String shortDescr;

	@JsonProperty("region_code")
	private String regionCode;

	@JsonProperty("active")
	@JsonDeserialize(using = Bool2IntDeserializer.class)
	private Integer active = 1;
}
