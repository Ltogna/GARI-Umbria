package com.abacogroup.lau.resources.mappers;

import com.abacogroup.lau.api.RegionRes;
import com.abacogroup.lau.db.ntt.RegionEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface RegionMapper {

	RegionMapper INSTANCE = Mappers.getMapper(RegionMapper.class);

	@Mapping(target = "active", expression = "java(dto.isActive() ? 1 : 0)")
	RegionEntity dtoToEntity(RegionRes dto);

}
