package com.abacogroup.lau.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.CountryRes;
import com.abacogroup.lau.db.ntt.CountryEntity;
import com.abacogroup.lau.resources.req.CountrySearchReq;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;

public interface CountryService {

	Optional<CountryEntity> loadCountryByCode(String tenantId, String code);

	InfiniteListResults<CountryRes> searchCountries(ReqContext reqContext, CountrySearchReq searchRequest, String nextKey);

	List<CountryRes> searchByI18nName(ReqContext reqContext, CountrySearchReq searchRequest);

	Optional<CountryRes> getCountryByCode(ReqContext reqContext, String code);

	CountryRes save(ReqContext reqContext, CountryRes country);
}
