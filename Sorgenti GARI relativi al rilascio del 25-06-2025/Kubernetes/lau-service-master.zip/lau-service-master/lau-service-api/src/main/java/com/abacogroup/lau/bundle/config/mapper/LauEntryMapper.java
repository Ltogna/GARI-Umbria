package com.abacogroup.lau.bundle.config.mapper;

import com.abacogroup.lau.bundle.config.dto.CountryEntry;
import com.abacogroup.lau.bundle.config.dto.DistrictEntry;
import com.abacogroup.lau.bundle.config.dto.LauEntry;
import com.abacogroup.lau.bundle.config.dto.MunicipalityEntry;
import com.abacogroup.lau.bundle.config.dto.RegionEntry;
import com.abacogroup.lau.db.ntt.CountryEntity;
import com.abacogroup.lau.db.ntt.DistrictEntity;
import com.abacogroup.lau.db.ntt.MultiTenantEntity;
import com.abacogroup.lau.db.ntt.MunicipalityEntity;
import com.abacogroup.lau.db.ntt.RegionEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface LauEntryMapper {

	LauEntryMapper INSTANCE = Mappers.getMapper(LauEntryMapper.class);

	default MultiTenantEntity<String> dtoToEntity(LauEntry dto) {
		if (dto == null) {
			return null;
		} else if (dto instanceof MunicipalityEntry) {
			return dtoToEntity((MunicipalityEntry) dto);
		} else if (dto instanceof DistrictEntry) {
			return dtoToEntity((DistrictEntry) dto);
		} else if (dto instanceof RegionEntry) {
			return dtoToEntity((RegionEntry) dto);
		} else if (dto instanceof CountryEntry) {
			return dtoToEntity((CountryEntry) dto);
		} else {
			return null;
		}
	}

	CountryEntity dtoToEntity(CountryEntry dto);

	RegionEntity dtoToEntity(RegionEntry dto);

	DistrictEntity dtoToEntity(DistrictEntry dto);

	MunicipalityEntity dtoToEntity(MunicipalityEntry dto);

}
