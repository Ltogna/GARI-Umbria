package com.abacogroup.lau.core.impl;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.v1.RegionDataResponseV1;
import com.abacogroup.lau.api.v1.RegionResponseV1;
import com.abacogroup.lau.api.v1.req.RegionSearchRequestV1;
import com.abacogroup.lau.core.RegionService;
import com.abacogroup.lau.core.RegionV1Service;
import com.abacogroup.lau.resources.publicapis.mapper.RegionMapper;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RegionV1ServiceImpl implements RegionV1Service {

	private final RegionService regionService;
	private final RegionMapper mapper;

	public RegionV1ServiceImpl(RegionService regionService) {
		this.regionService = regionService;
		this.mapper = RegionMapper.INSTANCE;
	}

	@Override
	public InfiniteListResults<RegionResponseV1> searchRegions(ReqContext reqContext, RegionSearchRequestV1 searchRequest, String nextKey) {
		return regionService.searchRegions(reqContext, mapper.fromV1(searchRequest), nextKey)
				.map(mapper::toV1);
	}

	@Override
	public List<RegionDataResponseV1> searchByI18nName(ReqContext reqContext, RegionSearchRequestV1 searchRequest) {
		return regionService.searchByI18nName(reqContext, mapper.fromV1(searchRequest)).stream()
				.map(mapper::toV1)
				.collect(Collectors.toList());
	}

	@Override
	public Optional<RegionResponseV1> getRegionByCode(ReqContext reqContext, String code) {
		return regionService.getRegionByCode(reqContext, code)
				.map(mapper::toV1);
	}

}
