package com.abacogroup.lau.resources.mappers;

import com.abacogroup.lau.api.CountryRes;
import com.abacogroup.lau.db.ntt.CountryEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface CountryMapper {

	CountryMapper INSTANCE = Mappers.getMapper(CountryMapper.class);

	@Mapping(target = "active", expression = "java(dto.isActive() ? 1 : 0)")
	CountryEntity dtoToEntity(CountryRes dto);

}
