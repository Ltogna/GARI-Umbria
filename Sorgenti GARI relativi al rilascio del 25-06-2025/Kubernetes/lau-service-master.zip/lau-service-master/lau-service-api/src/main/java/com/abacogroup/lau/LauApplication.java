package com.abacogroup.lau;

import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.jdbi.v3.core.Jdbi;

import com.abacogroup.bundles.Constants;
import com.abacogroup.bundles.initializer.InitService;
import com.abacogroup.bundles.listener.ListenerBuilder;
import com.abacogroup.bundles.listener.RabbitListener;
import com.abacogroup.bundles.listener.configdata.ConfigDataLogProducer;
import com.abacogroup.bundles.listener.configdata.builder.ConfigDataConsumerBuilder;
import com.abacogroup.bundles.listener.tenant.builder.NewTenantEventConsumerBuilder;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.SsoAuthorizer;
import com.abacogroup.jdbi.OraJdbiPlugin;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.jdbi.config.AbacoJdbiConfig;
import com.abacogroup.lau.LauConfiguration.RabbitmqConfig;
import com.abacogroup.lau.bundle.config.LauWithI18nConfigMessageProcessor;
import com.abacogroup.lau.bundle.tenant.I18nTenantMessageProcessor;
import com.abacogroup.lau.bundle.tenant.LauTenantMessageProcessor;
import com.abacogroup.lau.core.CountryService;
import com.abacogroup.lau.core.CountryV1Service;
import com.abacogroup.lau.core.DistrictService;
import com.abacogroup.lau.core.DistrictV1Service;
import com.abacogroup.lau.core.MunicipalityService;
import com.abacogroup.lau.core.MunicipalityV1Service;
import com.abacogroup.lau.core.RegionService;
import com.abacogroup.lau.core.RegionV1Service;
import com.abacogroup.lau.core.impl.CountryServiceImpl;
import com.abacogroup.lau.core.impl.CountryV1ServiceImpl;
import com.abacogroup.lau.core.impl.DistrictServiceImpl;
import com.abacogroup.lau.core.impl.DistrictV1ServiceImpl;
import com.abacogroup.lau.core.impl.MunicipalityServiceImpl;
import com.abacogroup.lau.core.impl.MunicipalityV1ServiceImpl;
import com.abacogroup.lau.core.impl.RegionServiceImpl;
import com.abacogroup.lau.core.impl.RegionV1ServiceImpl;
import com.abacogroup.lau.db.dao.CountryDAO;
import com.abacogroup.lau.db.dao.DistrictDAO;
import com.abacogroup.lau.db.dao.I18nDAO;
import com.abacogroup.lau.db.dao.MunicipalityDAO;
import com.abacogroup.lau.db.dao.RegionDAO;
import com.abacogroup.lau.resources.publicapis.CountryPublicResource;
import com.abacogroup.lau.resources.publicapis.DistrictPublicResource;
import com.abacogroup.lau.resources.publicapis.MunicipalityPublicResource;
import com.abacogroup.lau.resources.publicapis.RegionPublicResource;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.core.Application;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.jdbi3.JdbiFactory;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import io.dropwizard.migrations.MigrationsBundle;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import io.swagger.v3.oas.integration.SwaggerConfiguration;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration.Dynamic;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LauApplication extends Application<LauConfiguration> {

	public static void main(final String[] args) throws Exception {
		new LauApplication().run(args);
	}

	@Override
	public String getName() {
		return "lau-service";
	}

	@Override
	public void initialize(final Bootstrap<LauConfiguration> bootstrap) {
		bootstrap.addBundle(
				new MigrationsBundle<>() {
					@Override
					public DataSourceFactory getDataSourceFactory(LauConfiguration configuration) {
						return configuration.getDatabase();
					}
				});

		SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
				new EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);
	}

	@Override
	public void run(final LauConfiguration configuration, final Environment environment) throws Exception {
		ObjectMapper objectMapper = environment.getObjectMapper();
		configureObjectMapper(objectMapper);

		Jdbi jdbi = jdbi(configuration, environment);
		Connection rabbitmqConnection = this.createRabbitmqConnection(configuration);

		final I18nDAO i18nDAO = jdbi.onDemand(I18nDAO.class);
		final CountryDAO countryDAO = jdbi.onDemand(CountryDAO.class);
		final RegionDAO regionDAO = jdbi.onDemand(RegionDAO.class);
		final DistrictDAO districtDAO = jdbi.onDemand(DistrictDAO.class);
		final MunicipalityDAO municipalityDAO = jdbi.onDemand(MunicipalityDAO.class);

		final CountryService countryService = this.register(new CountryServiceImpl(countryDAO));
		final CountryV1Service countryV1Service = this.register(new CountryV1ServiceImpl(countryService));
		final RegionService regionService = this.register(new RegionServiceImpl(regionDAO));
		final RegionV1Service regionV1Service = this.register(new RegionV1ServiceImpl(regionService));
		final DistrictService districtService = this.register(new DistrictServiceImpl(districtDAO));
		final DistrictV1Service districtV1Service = this.register(new DistrictV1ServiceImpl(districtService));
		final MunicipalityService municipalityService = this.register(new MunicipalityServiceImpl(municipalityDAO));
		final MunicipalityV1Service municipalityV1Service = this.register(new MunicipalityV1ServiceImpl(municipalityService));

		List<Object> resources = new ArrayList<>();
		resources.add(new CountryPublicResource(countryV1Service));
		resources.add(new RegionPublicResource(regionV1Service));
		resources.add(new DistrictPublicResource(districtV1Service));
		resources.add(new MunicipalityPublicResource(municipalityV1Service));

		resources.forEach(environment.jersey()::register);

		final Sso2Client sso2Client = this.initSso2Client(configuration, environment);
		this.initAuth(environment, sso2Client);
		
		this.initMultiTenant(environment);
		this.initOpenApi(environment.jersey());
		this.setupCORS(configuration, environment);

		log.info("creating CONSUMERS rabbitConsumerManager");

		RabbitListener rabbitListener = ListenerBuilder
				.newBuilder(rabbitmqConnection)
				.withConfigDataConsumer(this.register(ConfigDataConsumerBuilder.newBuilder(jdbi, rabbitmqConnection)
						.route("lau-registry")
						.processors(
								this.register(new LauWithI18nConfigMessageProcessor(countryDAO, regionDAO, districtDAO, municipalityDAO, i18nDAO))
						)
						.configLogProducer(configDataLogProducerBean(objectMapper, rabbitmqConnection))
						.build()))

				.withNewTenantEventConsumer(NewTenantEventConsumerBuilder.newBuilder(jdbi)
						.route("lau-registry")
						.processors(
								this.register(new I18nTenantMessageProcessor(i18nDAO)),
								this.register(new LauTenantMessageProcessor(countryDAO, regionDAO, districtDAO, municipalityDAO))
						)
						.build())
				.buildListener();

		log.info("creating INITIALIZERS");
		

		// commentato perchè si da per scontato che siano gli altri servizi a richiedere l'installazione del bundle
		// BundleConfig bundleConfig = configuration.getBundleConfig() 
		//    InitService bundleInitService = BundleInitServiceBuilder
		//            .producer(this.register(new BundleInitServiceProducer(rabbitmqConnection)))
		//            .configLocation(bundleConfig.getConfigLocation())
		//            .build()
		InitService bundleInitService = null;
		this.startRabbitConsumerAndProducers(bundleInitService, rabbitListener);
		this.afterServicesUp();
	}

	protected ConfigDataLogProducer configDataLogProducerBean(ObjectMapper objectMapper, Connection rabbitmqConnection) {
		return this.register(new ConfigDataLogProducer(objectMapper, rabbitmqConnection, Constants.DEFAULT_EXCHANGE_NAME));
	}

	protected void afterServicesUp() {
		log.debug("application started");
	}

	protected void startRabbitConsumerAndProducers(InitService initService, RabbitListener rabbitListener) throws Exception {
		rabbitListener.start();
		Optional.ofNullable(initService).ifPresent(InitService::start);
	}

	protected Connection createRabbitmqConnection(LauConfiguration configuration)
			throws IOException, TimeoutException {
		RabbitmqConfig rabbitmqConfig = configuration.getRabbitmqConfig();

		ConnectionFactory factory = new ConnectionFactory();

		if (rabbitmqConfig.getHost() != null) {
			factory.setHost(rabbitmqConfig.getHost());
		}
		if (rabbitmqConfig.getUser() != null) {
			factory.setUsername(rabbitmqConfig.getUser());
		}
		if (rabbitmqConfig.getPassword() != null) {
			factory.setPassword(rabbitmqConfig.getPassword());
		}
		if (rabbitmqConfig.getVirtualhost() != null) {
			factory.setVirtualHost(rabbitmqConfig.getVirtualhost());
		}
		if (rabbitmqConfig.getPort() != null) {
			factory.setPort(rabbitmqConfig.getPort());
		}
		factory.setAutomaticRecoveryEnabled(true);

		Connection connection = factory.newConnection();
		return connection;
	}

	protected void configureObjectMapper(ObjectMapper objectMapper) {
		objectMapper.registerModule(new JavaTimeModule());
		objectMapper
				.setTimeZone(TimeZone.getDefault())
				.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
				.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
		;
	}

	protected void initAuth(Environment environment, Sso2Client sso2Cli) {
		AuthUtils.installAuthFilter(environment, sso2Cli, new SsoAuthorizer(sso2Cli));
	}
	
	private Sso2Client initSso2Client(LauConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("sso2-client");

		WebTarget webTarget = client.target(configuration.getSso2Config().getUrl());
		return new Sso2Client(configuration.getSso2Config().getTasksAuthPhrase(), webTarget);
	}

	protected Jdbi jdbi(final LauConfiguration configuration, final Environment environment) {
		final JdbiFactory factory = new JdbiFactory();
		final Jdbi jdbi = factory.build(environment, configuration.getDatabase(), "LauApplication");

		jdbi.configure(AbacoJdbiConfig.class, cfg -> cfg.setTablesPrefix("lau"));

		String driverClassName = Optional.ofNullable(configuration.getDatabase()
						.getDriverClass())
				.orElse("");

		if (driverClassName.equalsIgnoreCase("org.postgresql.Driver")) {
			jdbi.installPlugin(new PgJdbiPlugin());
		} else {
			jdbi.installPlugin(new OraJdbiPlugin());
		}

		return jdbi;
	}

	protected <T> T register(T service) {
		return service;
	}

	protected void initOpenApi(JerseyEnvironment jersey) {
		OpenAPI oas = new OpenAPI();
		oas.info(
				new Info()
						.title("ABACO Lau service")
						.description("Lau service APIs")
						.version("1.0")
						// .termsOfService("http://example.com/terms")
						.contact(new Contact().email("info@abacogroup.eu")));

		SwaggerConfiguration oasConfig =
				new SwaggerConfiguration()
						.openAPI(oas)
						.prettyPrint(true)
						.resourcePackages(Stream.of("com.abacogroup.lau").collect(Collectors.toSet()));

		jersey.register(new OpenApiResource().openApiConfiguration(oasConfig));
	}

	private void setupCORS(LauConfiguration configuration, Environment environment) {
		if (!configuration.isCors()) {
			log.info("CORS is disabled");
			return;
		}

		log.info("CORS is enabled");

		Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,DELETE");

		// OPTIONS pre-flight request will be served by the filter ONLY and not
		// passed ahead
		// cors.setInitParameter(CrossOriginFilter.CHAIN_PREFLIGHT_PARAM, "false")

		// Add URL mapping
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

	private void initMultiTenant(Environment environment) {
		environment.jersey().register(new MultitenantFilter("tenant"));
	}
}
