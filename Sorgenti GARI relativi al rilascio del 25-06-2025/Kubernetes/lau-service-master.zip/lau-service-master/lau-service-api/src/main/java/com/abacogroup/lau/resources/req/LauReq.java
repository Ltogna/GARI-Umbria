package com.abacogroup.lau.resources.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class LauReq {
	@NotNull
	@JsonProperty("country_code")
	private String countryCode;
	@NotNull
	@JsonProperty("country_fl_active")
	private int countryFlActive;
	@NotNull
	@JsonProperty("region_code")
	private String regionCode;
	@NotNull
	@JsonProperty("region_short_descr")
	private String regionShortDescr;
	@NotNull
	@JsonProperty("region_fl_active")
	private int regionFlActive;
	@NotNull
	@JsonProperty("district_code")
	private String districtCode;
	@NotNull
	@JsonProperty("district_short_descr")
	private String districtShortDescr;
	@NotNull
	@JsonProperty("district_fl_active")
	private int districtFlActive;
	@NotNull
	@JsonProperty("municipality_code")
	private String municipalityCode;
	@NotNull
	@JsonProperty("municipality_short_descr")
	private String municipalityShortDescr;
	@NotNull
	@JsonProperty("municipality_fl_active")
	private int municipalityFlActive;
}
