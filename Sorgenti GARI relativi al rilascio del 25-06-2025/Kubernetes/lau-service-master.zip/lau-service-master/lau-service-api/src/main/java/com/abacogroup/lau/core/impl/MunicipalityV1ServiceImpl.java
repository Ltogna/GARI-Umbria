package com.abacogroup.lau.core.impl;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.v1.MunicipalityDataResponseV1;
import com.abacogroup.lau.api.v1.MunicipalityResponseV1;
import com.abacogroup.lau.api.v1.req.MunicipalitySearchRequestV1;
import com.abacogroup.lau.core.MunicipalityService;
import com.abacogroup.lau.core.MunicipalityV1Service;
import com.abacogroup.lau.resources.publicapis.mapper.MunicipalityMapper;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MunicipalityV1ServiceImpl implements MunicipalityV1Service {

	private final MunicipalityService municipalityService;
	private final MunicipalityMapper mapper;

	public MunicipalityV1ServiceImpl(MunicipalityService municipalityService) {
		this.municipalityService = municipalityService;
		this.mapper = MunicipalityMapper.INSTANCE;
	}

	@Override
	public InfiniteListResults<MunicipalityResponseV1> searchMunicipalities(ReqContext reqContext, MunicipalitySearchRequestV1 searchRequest, String nextKey) {
		return municipalityService.searchMunicipalities(reqContext, mapper.fromV1(searchRequest), nextKey)
				.map(mapper::toV1);
	}

	@Override
	public List<MunicipalityDataResponseV1> searchByI18nName(ReqContext reqContext, MunicipalitySearchRequestV1 searchRequest) {
		return municipalityService.searchByI18nName(reqContext, mapper.fromV1(searchRequest)).stream()
				.map(mapper::toV1)
				.collect(Collectors.toList());
	}

	@Override
	public Optional<MunicipalityResponseV1> getMunicipalityByCode(ReqContext reqContext, String code) {
		return municipalityService.getMunicipalityByCode(reqContext, code)
				.map(mapper::toV1);
	}

}
