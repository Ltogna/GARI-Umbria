package com.abacogroup.lau.core.impl;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.v1.CountryResponseV1;
import com.abacogroup.lau.api.v1.req.CountrySearchRequestV1;
import com.abacogroup.lau.core.CountryService;
import com.abacogroup.lau.core.CountryV1Service;
import com.abacogroup.lau.resources.publicapis.mapper.CountryMapper;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CountryV1ServiceImpl implements CountryV1Service {

	private final CountryService countryService;
	private final CountryMapper mapper;

	public CountryV1ServiceImpl(CountryService countryService) {
		this.countryService = countryService;
		this.mapper = CountryMapper.INSTANCE;
	}

	@Override
	public InfiniteListResults<CountryResponseV1> searchCountries(ReqContext reqContext, CountrySearchRequestV1 searchRequest, String nextKey) {
		return countryService.searchCountries(reqContext, mapper.fromV1(searchRequest), nextKey)
				.map(mapper::toV1);
	}

	@Override
	public List<CountryResponseV1> searchByI18nName(ReqContext reqContext, CountrySearchRequestV1 searchRequest) {
		// limit to first 10 elements
		return this.searchCountries(reqContext, searchRequest, null).getRecords();
	}

	@Override
	public Optional<CountryResponseV1> getCountryByCode(ReqContext reqContext, String code) {
		return countryService.getCountryByCode(reqContext, code).map(mapper::toV1);
	}

}
