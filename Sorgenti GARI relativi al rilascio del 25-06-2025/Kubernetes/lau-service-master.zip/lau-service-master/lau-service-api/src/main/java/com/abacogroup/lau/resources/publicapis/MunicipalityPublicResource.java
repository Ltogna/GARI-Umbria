package com.abacogroup.lau.resources.publicapis;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.v1.MunicipalityDataResponseV1;
import com.abacogroup.lau.api.v1.MunicipalityResponseV1;
import com.abacogroup.lau.api.v1.req.MunicipalitySearchRequestV1;
import com.abacogroup.lau.core.MunicipalityV1Service;
import com.abacogroup.lau.resources.PublicResourceConstants;
import com.abacogroup.lau.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.dropwizard.jersey.validation.ValidationErrorMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import java.util.List;
import jakarta.annotation.security.PermitAll;
import jakarta.validation.Valid;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(PublicResourceConstants.API_V1_PUB + "/municipalities")
@PermitAll
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@io.swagger.v3.oas.annotations.tags.Tag(name = "Municipalities", description = "Operations on municipalities")
public class MunicipalityPublicResource {

	private final MunicipalityV1Service municipalityService;

	public MunicipalityPublicResource(MunicipalityV1Service municipalityService) {
		this.municipalityService = municipalityService;
	}

	@Operation(summary = "InfiniteListResults of municipalities", description = "Get list of municipalities filtered with criteria", responses = {
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of municipalities (sorted/filtered)", content = @Content(mediaType = "application/json", schema = @Schema(ref = "#/components/schemas/InfiniteListResultsMunicipalityResponseV1")))
	})
	@GET
	// @RolesAllowed()
	public InfiniteListResults<MunicipalityResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@QueryParam("nextKey") String nextKey,
			@BeanParam @Valid MunicipalitySearchRequestV1 searchRequest) {
		ReqContext reqContext = new ReqContext(user, lang);
		return municipalityService.searchMunicipalities(reqContext, searchRequest, nextKey);
	}

	@Operation(summary = "List of municipalities by name", description = "Get list of municipalities filtered by name starting with given `i18nName`", responses = {
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of *first 10* municipalities (sorted/filtered)", content = @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = MunicipalityDataResponseV1.class)))),
			@ApiResponse(responseCode = "400", description = "not valid query param `districtCode`", content = @Content(schema = @Schema(implementation = ValidationErrorMessage.class)))
	})
	@GET()
	@Path("/names")
	// @RolesAllowed()
	public List<MunicipalityDataResponseV1> searchByI18nName(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Valid @BeanParam MunicipalitySearchRequestV1 searchRequest) {
		ReqContext reqContext = new ReqContext(user, lang);
		return municipalityService.searchByI18nName(reqContext, searchRequest);
	}

	@Operation(summary = "Find municipality by code", description = "Get municipality info based on its code", responses = {
			@ApiResponse(responseCode = "200", description = "Successfully, municipality is found", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MunicipalityResponseV1.class, nullable = true))),
			@ApiResponse(responseCode = "204", description = "Municipality is not found")
	})
	@GET
	@Path("/{code}")
	// @RolesAllowed()
	public MunicipalityResponseV1 getByCode(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("code") String code) {
		ReqContext reqContext = new ReqContext(user, lang);
		return this.municipalityService.getMunicipalityByCode(reqContext, code)
				.orElse(null);
	}

}
