package com.abacogroup.lau.resources.publicapis;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.v1.CountryResponseV1;
import com.abacogroup.lau.api.v1.req.CountrySearchRequestV1;
import com.abacogroup.lau.core.CountryV1Service;
import com.abacogroup.lau.resources.PublicResourceConstants;
import com.abacogroup.lau.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import java.util.List;
import jakarta.annotation.security.PermitAll;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(PublicResourceConstants.API_V1_PUB + "/countries")
@PermitAll
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@io.swagger.v3.oas.annotations.tags.Tag(name = "Countries", description = "Operations on countries")
public class CountryPublicResource {

	private final CountryV1Service countryV1Service;

	public CountryPublicResource(CountryV1Service countryV1Service) {
		this.countryV1Service = countryV1Service;
	}

	@Operation(summary = "InfiniteListResults of countries", description = "Get list of countries filtered with criteria", responses = {
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of countries (sorted/filtered)",
					content = @Content(mediaType = "application/json",
							schema = @Schema(ref = "#/components/schemas/InfiniteListResultsCountryResponseV1")))
	})
	@GET
	//@RolesAllowed()
	public InfiniteListResults<CountryResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@QueryParam("nextKey") String nextKey,
			@BeanParam CountrySearchRequestV1 searchRequest) {
		ReqContext reqContext = new ReqContext(user, lang);
		return countryV1Service.searchCountries(reqContext, searchRequest, nextKey);
	}

	@Operation(summary = "List of countries by name", description = "Get list of countries filtered by name starting with given `i18nName`", responses = {
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of *first 10* countries (sorted/filtered)",
					content = @Content(mediaType = "application/json",
							array = @ArraySchema(schema = @Schema(implementation = CountryResponseV1.class))))
	})
	@GET()
	@Path("/names")
	//@RolesAllowed()
	public List<CountryResponseV1> searchByI18nName(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@BeanParam CountrySearchRequestV1 searchRequest) {
		ReqContext reqContext = new ReqContext(user, lang);
		return countryV1Service.searchByI18nName(reqContext, searchRequest);
	}

	@Operation(summary = "Find country by code", description = "Get country info based on its code", responses = {
			@ApiResponse(responseCode = "200", description = "Successfully, country is found",
					content = @Content(mediaType = "application/json",
							schema = @Schema(implementation = CountryResponseV1.class, nullable = true))),
			@ApiResponse(responseCode = "204", description = "Country is not found")
	})
	@GET
	@Path("/{code}")
	//@RolesAllowed()
	public CountryResponseV1 getByCode(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("code") String code) {
		ReqContext reqContext = new ReqContext(user, lang);
		return this.countryV1Service.getCountryByCode(reqContext, code)
				.orElse(null);
	}

}
