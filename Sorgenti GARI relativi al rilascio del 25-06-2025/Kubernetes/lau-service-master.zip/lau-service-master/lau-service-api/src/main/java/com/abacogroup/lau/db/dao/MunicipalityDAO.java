package com.abacogroup.lau.db.dao;

import java.util.Optional;

import org.jdbi.v3.core.mapper.reflect.BeanMapper;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.BatchChunkSize;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.lau.api.MunicipalityRes;
import com.abacogroup.lau.db.ntt.MunicipalityEntity;
import com.abacogroup.lau.resources.req.MunicipalitySearchReq;
import com.abacogroup.lau.resources.req.ReqContext;

public interface MunicipalityDAO extends Transactional<MunicipalityDAO>, EnhancedSqlObject {

	String FIELDS_WITH_PREFIX = " mu.code, mu.tenant_id, mu.district_code, mu.short_descr, mu.fl_active ";
	String DISTRICT_FIELDS_WITH_PREFIX = ", di.code as di_code, di.tenant_id as di_tenant_id, "
			+ "di.region_code as di_region_code, di.short_descr as di_short_descr, di.fl_active as di_fl_active ";
	String REGION_FIELDS_WITH_PREFIX = ", re.code as di_re_code, re.tenant_id as di_re_tenant_id, "
			+ "re.country_code as di_re_country_code, re.short_descr as di_re_short_descr, re.fl_active as di_re_fl_active ";
	String COUNTRY_FIELDS_WITH_PREFIX = ", co.code as di_re_co_code, co.tenant_id as di_re_co_tenant_id, co.fl_active as di_re_co_fl_active ";
	String FIELDS = " code, tenant_id, district_code, short_descr, fl_active ";
	String TABLE = "lau_municipality";
	String I18N = " \n, coalesce (§i18n(:tenantId, '" + TABLE + "', 'code', mu.code, :lang)§, mu.code) as i18n_name\n ";
	String DISTRICT_I18N = " \n, coalesce (§i18n(:tenantId, '" + DistrictDAO.TABLE + "', 'code', di.code, :lang)§, di.code) as di_i18n_name\n ";
	String REGION_I18N = " \n, coalesce (§i18n(:tenantId, '" + RegionDAO.TABLE + "', 'code', re.code, :lang)§, re.code) as di_re_i18n_name\n ";
	String COUNTRY_I18N = " \n, coalesce (§i18n(:tenantId, '" + CountryDAO.TABLE + "', 'code', co.code, :lang)§, co.code) as di_re_co_i18n_name\n ";

	@SqlQuery("select " + FIELDS_WITH_PREFIX
			+ " from " + TABLE + " mu "
			+ " inner join " + DistrictDAO.TABLE + " di on mu.district_code = di.code and mu.tenant_id = di.tenant_id "
			+ " inner join " + RegionDAO.TABLE + " re on di.region_code = re.code and di.tenant_id = re.tenant_id "
			+ " inner join " + CountryDAO.TABLE + " co on re.country_code = co.code and re.tenant_id = co.tenant_id "
			+ " where mu.code = :code and mu.tenant_id = :tenantId")
	@RegisterBeanMapper(MunicipalityEntity.class)
	Optional<MunicipalityEntity> findByCode(
			@Bind("code") String code,
			@Bind("tenantId") String tenantId);

	@SqlQuery("select count(mu.code) "
			+ " from " + TABLE + " mu "
			+ " where mu.code = :code and mu.tenant_id = :tenantId ")
	Long countByCode(@BindBean MunicipalityEntity entity);

	@SqlUpdate("insert into " + TABLE + " (" + FIELDS + ") "
			+ " values (:code, :tenantId, :districtCode, :shortDescr, :active)")
	void insert(@BindBean MunicipalityEntity entity);

	@SqlBatch("insert into " + TABLE + " (" + FIELDS + ") "
			+ " values (:code, :tenantId, :districtCode, :shortDescr, :active)")
	void insertBatch(@BindBean MunicipalityEntity... entity);

	@BatchChunkSize(1000)
	@SqlBatch("insert into " + TABLE + " (" + FIELDS + ") "
			+ " §select_from_dual (:code, :tenantId, :districtCode, :shortDescr, :active)§ "
			+ " where not exists("
			+ " select code "
			+ " from  " + TABLE
			+ " where tenant_id = :tenantId and code = :code )")
	void insertBatchIdempotent(@BindBean MunicipalityEntity... entity);

	@BatchChunkSize(1000)
	@SqlBatch("update " + TABLE +
			" set code = :code, tenant_id = :tenantId, district_code = :districtCode, short_descr = :shortDescr, fl_active = :active " +
			" where tenant_id = :tenantId and code = :code ")
	void updateBatch(@BindBean MunicipalityEntity... entity);
	
	default ResultIterator<MunicipalityRes> searchAll(MunicipalitySearchReq searchReq, OrderBy orderBy, ReqContext ctx) {
		
		int intAllStatus = 0;
		int intActive = 1;
		
		if (searchReq.getActive() != null) {
			switch (searchReq.getActive()) {
			case all:
				intAllStatus = 1;
				break;
			case not_active:
				intActive = 0;
				break;
			case only_active:
				intActive = 1;
				break;
			}
		}
		
		int allStatus = intAllStatus;
		int active = intActive;
		
		
		String sql = "select * from ( \n"
				+ " select \n"
				+ "        mu.code, \n"
				+ "        mu.tenant_id, \n"
				+ "        mu.district_code, \n"
				+ "        mu.short_descr, \n"
				+ "        mu.fl_active, \n"  
				+ "        coalesce (§i18n(:tenantId, 'lau_municipality', 'code', mu.code, :lang)§, mu.code) as i18n_name, \n" 
				+ "        di.code as di_code, \n"
				+ "        di.tenant_id as di_tenant_id, \n"
				+ "        di.region_code as di_region_code, \n"
				+ "        di.short_descr as di_short_descr, \n"
				+ "        di.fl_active as di_fl_active,\n "
				+ "        coalesce (§i18n(:tenantId, 'lau_district', 'code', di.code, :lang)§, di.code) as di_i18n_name, \n"
				+ "        re.code as di_re_code, \n"
				+ "        re.tenant_id as di_re_tenant_id, \n"
				+ "        re.country_code as di_re_country_code, \n"
				+ "        re.short_descr as di_re_short_descr, \n"
				+ "        re.fl_active as di_re_fl_active, \n" 
				+ "        coalesce (§i18n(:tenantId, 'lau_region', 'code', re.code, :lang)§, re.code) as di_re_i18n_name, \n"
				+ "        co.code as di_re_co_code, \n"
				+ "        co.tenant_id as di_re_co_tenant_id, \n"
				+ "        co.fl_active as di_re_co_fl_active, \n" 
				+ "        coalesce (§i18n(:tenantId, 'lau_country', 'code', co.code, :lang)§, co.code) as di_re_co_i18n_name \n "				
				+ "   from lau_municipality mu \n"
				+ "  inner join lau_district di on mu.district_code = di.code and mu.tenant_id = di.tenant_id \n"
				+ "  inner join lau_region re on di.region_code = re.code and di.tenant_id = re.tenant_id \n"
				+ "  inner join lau_country co on re.country_code = co.code and re.tenant_id = co.tenant_id \n"
				
				+ "  where \n "
							// <innercriteria>	
				+ "        (:allStatus = 1 or :active = (mu.fl_active * di.fl_active * re.fl_active * co.fl_active)) \n" // if search for inactive is in OR (0 = 1*0*1*1), if active is in AND (1 = 1*1*1*1)  
				
				+ "    and (:code is null or mu.code = :code) \n"
				+ "    and (:districtCode is null or di.code = :districtCode) \n"
				+ "    and (:regionCode is null or re.code = :regionCode) \n"
				+ "    and (:countryCode is null or co.code = :countryCode) \n"
				           // </innercriteria>
				
				+ "    and mu.tenant_id = :tenantId \n"
				+ ") mu_ \n"
				
				+ " where (:i18nName is null or mu_.code in ("+prepareSubQuerySearchI18n(ctx.getLang(), "lau_municipality", "code", ":i18nName")+"))  \n"				
				+ "   and (:districtI18n is null or mu_.di_code in ("+prepareSubQuerySearchI18n(ctx.getLang(), "lau_district", "code", ":districtI18n")+")) \n"
				+ "   and (:regionI18n is null or mu_.di_re_code in ("+prepareSubQuerySearchI18n(ctx.getLang(), "lau_region", "code", ":regionI18n")+")) \n"
				+ "   and (:countryI18n is null or mu_.di_re_co_code in ("+prepareSubQuerySearchI18n(ctx.getLang(), "lau_country", "code", ":countryI18n")+")) \n"
				
				+ " ORDER BY <orderBy> ";
		
		return withHandle(h -> 
			h.createQuery(sql)
			    .bind("allStatus", allStatus)
			    .bind("active", active)
			    .bindBean(searchReq)
				.bindBean(ctx)
				.define("orderBy", orderBy.toSqlFragment())
				.registerRowMapper(BeanMapper.factory(MunicipalityRes.class))
				.mapTo(MunicipalityRes.class)
				.iterator()
		);
		
		
	}

	@SqlQuery("select " + FIELDS_WITH_PREFIX + I18N + DISTRICT_FIELDS_WITH_PREFIX + DISTRICT_I18N
			+ REGION_FIELDS_WITH_PREFIX + REGION_I18N
			+ COUNTRY_FIELDS_WITH_PREFIX + COUNTRY_I18N
			+ " from " + TABLE + " mu "
			+ " inner join " + DistrictDAO.TABLE + " di on mu.district_code = di.code and mu.tenant_id = di.tenant_id "
			+ " inner join " + RegionDAO.TABLE + " re on di.region_code = re.code and di.tenant_id = re.tenant_id "
			+ " inner join " + CountryDAO.TABLE + " co on re.country_code = co.code and re.tenant_id = co.tenant_id "
			+ " where mu.code = :code and mu.tenant_id = :tenantId")
	@RegisterBeanMapper(MunicipalityRes.class)
	Optional<MunicipalityRes> searchByCode(
			@Bind("code") String code,
			@BindBean ReqContext ctx);

	@SqlQuery("select count(*) from " + TABLE + " where tenant_id = :tenantId ")
	Long countAll(@Bind("tenantId") String tenantId);

	@SqlUpdate("insert into " + TABLE + " (" + FIELDS + ") "
			+ "select m.code, :newTenantId as tenant_id, m.district_code, m.short_descr, m.fl_active "
			+ "from lau_municipality m where m.tenant_id = :sourceTenant")
	void insertNewTenant(
			@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId);
	
	
	/* ************************************************** */
	
	/**
	 * 
	 * Prepares a search query for finding the appropriate language code based on
	 * the provided language, table name, and field name and tenant.
	 * This method constructs a SQL query that searches for the language code in the
	 * following order:
	 *   1. Exact match for the provided language code. 
	 *   2. Base language code (in case the provided language uses a hyphen separated format). 
	 *      This is achieved by splitting the language code on underscores and searching for the first part.
	 *   3. English language code ('en'). 
	 * For each language, the query selects the language code, a sorting order based on the search priority 
	 * (0 for exact match, 1 for base language, 2 for English), and a count of matching entries
	 * in the lau_i18n_values table. 
	 * The final query uses a UNION ALL operation to combine the results from each search and applies 
	 * an ORDER BY clause based on the sorting order to prioritize the most relevant language code. 
	 * Finally, it uses FETCH FIRST ROW ONLY to retrieve only the first row
	 * (which should contain the most relevant language code).
	 * 
	 * @param lang      The language code to search for (e.g., "en_US").
	 * @param tableName The name of the table containing the localized values.
	 * @param fieldName The name of the field containing the localized values.
	 * @return A SQL query string that can be used to search for the appropriate
	 *         language code.
	 */
	default String prepareSearchLangForI18nTableAndField(String lang, String tableName, String fieldName) {
		String langSearch = "";
		
		langSearch = "select lang from ( ";
				
		if(lang != null ) {
			lang  = lang.replace('-', '_');
			// First search for lang code
			langSearch += "  select lang, 0 as l_a_n_g_o_r_d, count(*) "
					+ "  from lau_i18n_values "
					+ " where tenant_id = :tenantId "
					+ "   and lang = '"+lang+"' "
					+ "   and table_name = '"+tableName+"' "
					+ "   and field_name = '"+fieldName+"' "
					+ " group by lang "
					+ " union all \n";
			
			// Search for the base lang too
			String[] backLang = lang.split("\\_");
			
			if(backLang != null && backLang.length > 1) {
				langSearch += "  select lang, 1 as l_a_n_g_o_r_d, count(*) "
						+ "  from lau_i18n_values "
						+ " where tenant_id = :tenantId "
						+ "   and lang = '"+backLang+"' "
						+ "   and table_name = '"+tableName+"' "
						+ "   and field_name = '"+fieldName+"' "
						+ " group by lang "
						+ " union all \n";
			}
		}
		
		// Last search for English
		langSearch += " select lang, 2 as l_a_n_g_o_r_d, count(*) "
				+ "  from lau_i18n_values "
				+ " where tenant_id = :tenantId "
				+ "   and lang = 'en' "
				+ "   and table_name = '"+tableName+"' "
				+ "   and field_name = '"+fieldName+"' "
				+ " group by lang \n";
		
		langSearch += ") i_1_8_n_l_a_n_g_s order by l_a_n_g_o_r_d fetch first row only \n";
		
		return langSearch;
	}
	
	/**
	 * Prepares a subquery to search for a localized value based on the provided
	 * language, table name, field name, and a search string.
	 * 
	 * This method leverages the prepareSearchLangForI18nTableAndField method to
	 * construct a subquery that retrieves the appropriate language code based on
	 * the given parameters. It then uses this language code to filter the
	 * lau_i18n_values table.
	 * 
	 * The query searches for the i18n_value for the specified table and field,
	 * ensuring the following conditions are met:
	 * 
	 *    The tenant_id matches the provided bind variable (:tenantId).
	 *    The lang code matches the language retrieved from the subquery generated by
	 *     prepareSearchLangForI18nTableAndField.
	 *    The table_name and field_name match the provided values.
	 * 
	 * The i18n_text field (converted to uppercase) is like the provided searchBind
	 * string appended with a wildcard ("%"). This performs a case-insensitive LIKE
	 * search with a trailing wildcard match.
	 * 
	 * @param lang       The language code to search for (e.g., "en_US").
	 * @param tableName  The name of the table containing the localized values.
	 * @param fieldName  The name of the field containing the localized values.
	 * @param searchBind A bind variable representing the search string to match
	 *                   against the localized value (case-insensitively with a
	 *                   trailing wildcard).
	 * @return A SQL subquery string that can be used to search for the localized
	 *         value based on the provided parameters.
	 */
	default String prepareSubQuerySearchI18n(String lang, String tableName, String fieldName, String searchBind) {
		return " select i18n_value from lau_i18n_values "
				+ "where tenant_id = :tenantId "
				+ "  and lang = ("+prepareSearchLangForI18nTableAndField(lang, tableName, fieldName)+") "
				+ "  and table_name = '"+tableName+"' "
				+ "  and field_name = '"+fieldName+"' "
				+ "  and upper(i18n_text) like upper("+searchBind+"||'%')  ";
	}
}
