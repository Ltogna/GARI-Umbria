package com.abacogroup.lau.resources;

public interface ResourceConstants {

	String API_PRIV = "/{tenant}/api-priv/v1";

	int PAGE_SIZE = 10;
}
