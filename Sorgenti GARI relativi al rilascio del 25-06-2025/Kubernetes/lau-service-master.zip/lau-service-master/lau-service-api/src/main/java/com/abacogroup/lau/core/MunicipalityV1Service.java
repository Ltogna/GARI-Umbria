package com.abacogroup.lau.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.v1.MunicipalityDataResponseV1;
import com.abacogroup.lau.api.v1.MunicipalityResponseV1;
import com.abacogroup.lau.api.v1.req.MunicipalitySearchRequestV1;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;

public interface MunicipalityV1Service {
	InfiniteListResults<MunicipalityResponseV1> searchMunicipalities(ReqContext reqContext, MunicipalitySearchRequestV1 searchRequest, String nextKey);

	List<MunicipalityDataResponseV1> searchByI18nName(ReqContext reqContext, MunicipalitySearchRequestV1 searchRequest);

	Optional<MunicipalityResponseV1> getMunicipalityByCode(ReqContext reqContext, String code);
}
