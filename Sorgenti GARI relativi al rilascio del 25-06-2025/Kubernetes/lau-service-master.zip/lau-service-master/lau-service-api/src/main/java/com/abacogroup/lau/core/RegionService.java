package com.abacogroup.lau.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.RegionDataRes;
import com.abacogroup.lau.api.RegionRes;
import com.abacogroup.lau.db.ntt.RegionEntity;
import com.abacogroup.lau.resources.req.RegionSearchReq;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;

public interface RegionService {

	Optional<RegionEntity> loadRegionByCode(String tenantId, String code);

	InfiniteListResults<RegionRes> searchRegions(ReqContext reqContext, RegionSearchReq searchRequest,
			String nextKey);

	List<RegionDataRes> searchByI18nName(ReqContext reqContext, RegionSearchReq searchRequest);

	Optional<RegionRes> getRegionByCode(ReqContext reqContext, String code);

	RegionRes save(ReqContext reqContext, RegionRes region);
}
