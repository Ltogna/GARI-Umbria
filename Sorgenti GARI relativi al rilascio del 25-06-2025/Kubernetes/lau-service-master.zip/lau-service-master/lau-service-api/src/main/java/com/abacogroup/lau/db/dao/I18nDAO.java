package com.abacogroup.lau.db.dao;

import com.abacogroup.lau.db.ntt.I18nEntity;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.BatchChunkSize;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface I18nDAO extends Transactional<I18nDAO> {

	@BatchChunkSize(1000)
	@SqlBatch("insert into lau_i18n_values(tenant_id, table_name, field_name, i18n_value, lang, i18n_text) "
			+ " values(:tenantId, :tableName, :fieldName, :i18nValue, :lang, :i18nText) ")
	void insert(@BindBean I18nEntity... entity);

	@BatchChunkSize(1000)
	@SqlBatch("delete from lau_i18n_values "
			+ " where tenant_id = :tenantId "
			+ "and table_name = :tableName "
			+ "and field_name = :fieldName "
			+ "and i18n_value = :i18nValue "
			+ "and lang = :lang ")
	void deleteBatch(@BindBean I18nEntity... entity);

	@SqlQuery("select i18n_text "
			+ "from lau_i18n_values "
			+ "where tenant_id= :tenantId and table_name= :tableName and field_name= :fieldName and i18n_value= :i18nValue and lang= :lang ")
	String searchLabel(
			@Bind("tenantId") String tenantId,
			@Bind("tableName") String tableName,
			@Bind("fieldName") String fieldName,
			@Bind("i18nValue") String i18nValue,
			@Bind("lang") String lang
	);

	@SqlQuery("select count(*) FROM lau_i18n_values where tenant_id = :tenantId ")
	Long countAll(@Bind("tenantId") String tenantId);

	@SqlUpdate("insert into lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text) "
			+ "select :newTenantId as tenant_id, iv.table_name, iv.field_name, iv.i18n_value, iv.lang, iv.i18n_text "
			+ "from lau_i18n_values iv where iv.tenant_id = :sourceTenant ")
	void insertNewTenant(@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId);
}
