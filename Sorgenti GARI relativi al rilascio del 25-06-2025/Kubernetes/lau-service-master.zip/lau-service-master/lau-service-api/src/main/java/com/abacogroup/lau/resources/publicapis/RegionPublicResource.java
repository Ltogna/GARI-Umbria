package com.abacogroup.lau.resources.publicapis;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.v1.RegionDataResponseV1;
import com.abacogroup.lau.api.v1.RegionResponseV1;
import com.abacogroup.lau.api.v1.req.RegionSearchRequestV1;
import com.abacogroup.lau.core.RegionV1Service;
import com.abacogroup.lau.resources.PublicResourceConstants;
import com.abacogroup.lau.resources.req.ReqContext;
import io.dropwizard.auth.Auth;
import io.dropwizard.jersey.validation.ValidationErrorMessage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import java.util.List;
import jakarta.annotation.security.PermitAll;
import jakarta.validation.Valid;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(PublicResourceConstants.API_V1_PUB + "/regions")
@PermitAll
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@io.swagger.v3.oas.annotations.tags.Tag(name = "Regions", description = "Operations on regions")
public class RegionPublicResource {

	private final RegionV1Service regionService;

	public RegionPublicResource(RegionV1Service regionService) {
		this.regionService = regionService;
	}

	@Operation(summary = "InfiniteListResults of regions", description = "Get list of regions filtered with criteria", responses = {
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of regions (sorted/filtered)",
					content = @Content(mediaType = "application/json",
							schema = @Schema(ref = "#/components/schemas/InfiniteListResultsRegionResponseV1")))
	})
	@GET
	//@RolesAllowed()
	public InfiniteListResults<RegionResponseV1> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@QueryParam("nextKey") String nextKey,
			@BeanParam RegionSearchRequestV1 searchRequest) {
		ReqContext reqContext = new ReqContext(user, lang);
		return regionService.searchRegions(reqContext, searchRequest, nextKey);
	}

	@Operation(summary = "List of regions by name", description = "Get list of regions filtered by name starting with given `i18nName`", responses = {
			@ApiResponse(responseCode = "200", description = "Successfully, returns a list of *first 10* regions (sorted/filtered)",
					content = @Content(mediaType = "application/json",
							array = @ArraySchema(schema = @Schema(implementation = RegionDataResponseV1.class)))),
			@ApiResponse(responseCode = "400", description = "not valid query param `countryCode`",
					content = @Content(schema = @Schema(implementation = ValidationErrorMessage.class)))
	})
	@GET()
	@Path("/names")
	//@RolesAllowed()
	public List<RegionDataResponseV1> searchByI18nName(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Valid @BeanParam RegionSearchRequestV1 searchRequest) {
		ReqContext reqContext = new ReqContext(user, lang);
		return regionService.searchByI18nName(reqContext, searchRequest);
	}

	@Operation(summary = "Find region by code", description = "Get region info based on its code", responses = {
			@ApiResponse(responseCode = "200", description = "Successfully, region is found",
					content = @Content(mediaType = "application/json",
							schema = @Schema(implementation = RegionResponseV1.class, nullable = true))),
			@ApiResponse(responseCode = "204", description = "Region is not found")
	})
	@GET
	@Path("/{code}")
	//@RolesAllowed()
	public RegionResponseV1 getByCode(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("code") String code) {
		ReqContext reqContext = new ReqContext(user, lang);
		return this.regionService.getRegionByCode(reqContext, code)
				.orElse(null);
	}

}
