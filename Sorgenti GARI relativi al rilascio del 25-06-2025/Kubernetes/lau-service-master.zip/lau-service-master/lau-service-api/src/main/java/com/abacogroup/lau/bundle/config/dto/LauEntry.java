package com.abacogroup.lau.bundle.config.dto;

import com.abacogroup.lau.bundle.config.i18n.I18nAware;
import com.abacogroup.lau.bundle.config.i18n.I18nEntry;
import com.abacogroup.lau.bundle.config.i18n.I18nMap;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.Set;

public interface LauEntry extends I18nAware {
	String getCode();

	I18nMap getDescription();

	@JsonIgnore
	@Override
	default String getI18nCode() {
		return getCode();
	}

	@JsonIgnore
	@Override
	default Set<I18nEntry> getI18n() {
		return getDescription().getI18n();
	}
}
