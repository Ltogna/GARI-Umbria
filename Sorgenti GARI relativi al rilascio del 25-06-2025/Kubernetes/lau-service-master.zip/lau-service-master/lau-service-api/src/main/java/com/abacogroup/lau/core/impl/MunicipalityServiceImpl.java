package com.abacogroup.lau.core.impl;

import java.util.List;
import java.util.Optional;

import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.MunicipalityDataRes;
import com.abacogroup.lau.api.MunicipalityRes;
import com.abacogroup.lau.core.MunicipalityService;
import com.abacogroup.lau.db.dao.MunicipalityDAO;
import com.abacogroup.lau.db.ntt.MunicipalityEntity;
import com.abacogroup.lau.resources.mappers.MunicipalityMapper;
import com.abacogroup.lau.resources.req.MunicipalitySearchReq;
import com.abacogroup.lau.resources.req.ReqContext;

public class MunicipalityServiceImpl implements MunicipalityService {

	private final MunicipalityDAO municipalityDAO;

	public MunicipalityServiceImpl(MunicipalityDAO municipalityDAO) {
		this.municipalityDAO = municipalityDAO;
	}

	@Override
	public Optional<MunicipalityEntity> loadMunicipalityByCode(String tenantId, String code) {
		return municipalityDAO.findByCode(code, tenantId);
	}

	@Override
	public InfiniteListResults<MunicipalityRes> searchMunicipalities(ReqContext reqContext, MunicipalitySearchReq searchRequest, String nextKey) {
		OrderBy sort = searchRequest.getSort();

		return municipalityDAO.infinite(() ->
						municipalityDAO.searchAll(searchRequest, sort, reqContext),
				nextKey, searchRequest.getPageSize());
	}

	@Override
	public List<MunicipalityDataRes> searchByI18nName(ReqContext reqContext, MunicipalitySearchReq searchRequest) {
		// limit to first 10 elements
		return this.searchMunicipalities(reqContext, searchRequest, null)
				.map(municipality -> {
					municipality.setDistrict(null);
					return ((MunicipalityDataRes) municipality);
				}).getRecords();
	}

	@Override
	public Optional<MunicipalityRes> getMunicipalityByCode(ReqContext reqContext, String code) {
		return municipalityDAO.searchByCode(code, reqContext);
	}

	@Override
	public MunicipalityRes save(ReqContext reqContext, MunicipalityRes municipality) {
		MunicipalityEntity entity = MunicipalityMapper.INSTANCE.dtoToEntity(municipality);
		entity.setTenantId(reqContext.getTenantId());
		municipalityDAO.insert(entity);
		return municipalityDAO.searchByCode(municipality.getCode(), reqContext).orElse(null);
	}

}
