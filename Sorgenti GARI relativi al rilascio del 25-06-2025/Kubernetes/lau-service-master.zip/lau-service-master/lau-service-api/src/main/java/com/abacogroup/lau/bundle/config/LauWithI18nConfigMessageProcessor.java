package com.abacogroup.lau.bundle.config;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.lau.bundle.config.dto.CountryEntry;
import com.abacogroup.lau.bundle.config.dto.DistrictEntry;
import com.abacogroup.lau.bundle.config.dto.LauEntry;
import com.abacogroup.lau.bundle.config.dto.MunicipalityEntry;
import com.abacogroup.lau.bundle.config.dto.RegionEntry;
import com.abacogroup.lau.bundle.config.i18n.I18nHelper;
import com.abacogroup.lau.bundle.config.mapper.LauEntryMapper;
import com.abacogroup.lau.core.BundleConstants;
import com.abacogroup.lau.db.dao.CountryDAO;
import com.abacogroup.lau.db.dao.DistrictDAO;
import com.abacogroup.lau.db.dao.I18nDAO;
import com.abacogroup.lau.db.dao.MunicipalityDAO;
import com.abacogroup.lau.db.dao.RegionDAO;
import com.abacogroup.lau.db.ntt.CountryEntity;
import com.abacogroup.lau.db.ntt.DistrictEntity;
import com.abacogroup.lau.db.ntt.MultiTenantEntity;
import com.abacogroup.lau.db.ntt.MunicipalityEntity;
import com.abacogroup.lau.db.ntt.RegionEntity;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class LauWithI18nConfigMessageProcessor implements ConfigMessageProcessor {

	private final CountryDAO countryDAO;
	private final RegionDAO regionDAO;
	private final DistrictDAO districtDAO;
	private final MunicipalityDAO municipalityDAO;

	private final ObjectMapper mapper;

	private final I18nHelper i18nHelper;

	public LauWithI18nConfigMessageProcessor(CountryDAO countryDAO, RegionDAO regionDAO, DistrictDAO districtDAO, MunicipalityDAO municipalityDAO,
			I18nDAO i18nDAO) {
		this.countryDAO = countryDAO;
		this.regionDAO = regionDAO;
		this.districtDAO = districtDAO;
		this.municipalityDAO = municipalityDAO;

		this.mapper = new ObjectMapper().disable(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES);

		this.i18nHelper = new I18nHelper(i18nDAO);
	}

	@Override
	public String getDomainName() {
		return BundleConstants.DOMAIN_LAU;
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();
		message.getConfigFiles().forEach(path -> {
			log.info("START handle lau content from '{}'", path);
			addContent(tenantId, path);
			log.info("FINISH handle lau content from '{}'", path);
		});
	}

	private void addContent(String tenantId, Path path) {
		try {
			Map<Class<? extends LauEntry>, List<LauEntry>> entities = readJsonLineFile(path);

			this.persistLauItems(tenantId, entities.get(CountryEntry.class), countryDAO.TABLE,
					countries -> {
						CountryEntity[] array = countries.toArray(CountryEntity[]::new);
						countryDAO.insertBatchIdempotent(array);
						countryDAO.updateBatch(array);
					});

			this.persistLauItems(tenantId, entities.get(RegionEntry.class), regionDAO.TABLE,
					regions -> {
						RegionEntity[] array = regions.toArray(RegionEntity[]::new);
						regionDAO.insertBatchIdempotent(array);
						regionDAO.updateBatch(array);
					});

			this.persistLauItems(tenantId, entities.get(DistrictEntry.class), districtDAO.TABLE,
					districts -> {
						DistrictEntity[] array = districts.toArray(DistrictEntity[]::new);
						districtDAO.insertBatchIdempotent(array);
						districtDAO.updateBatch(array);
					});

			this.persistLauItems(tenantId, entities.get(MunicipalityEntry.class), municipalityDAO.TABLE,
					municipalities -> {
						MunicipalityEntity[] array = municipalities.toArray(MunicipalityEntity[]::new);
						municipalityDAO.insertBatchIdempotent(array);
						municipalityDAO.updateBatch(array);
					});

		} catch (Exception e) {
			throw new BundleException(String.format("error saving file %s", path), e);
		}
	}

	private <NTT extends MultiTenantEntity, E extends LauEntry> void persistLauItems(String tenantId, List<E> entries,
			String tableName, Consumer<Collection<NTT>> batch) {
		if (entries != null) {
			List<NTT> entities = entries.stream()
					.map(LauEntryMapper.INSTANCE::dtoToEntity)
					.map(ntt -> {
						ntt.setTenantId(tenantId);
						return (NTT) ntt;
					})
					.collect(Collectors.toList());

			log.info("upsert {} records in table {} for tenant {}", entities.size(), tableName, tenantId);
			batch.accept(entities);

			i18nHelper.upsert(tenantId, tableName, "code", entries);
		}
	}

	private Map<Class<? extends LauEntry>, List<LauEntry>> readJsonLineFile(Path path) throws IOException {
		try (Stream<String> input = Files.lines(path, StandardCharsets.UTF_8)) {
			return input
					.map(String::strip)
					.filter(StringUtils::isNotBlank)
					.filter(s -> !s.startsWith(BundleConstants.JSONL_COMMENT))
					.map(jsonLine -> mapEntity(jsonLine))
					.collect(Collectors.groupingBy(LauEntry::getClass, Collectors.toList()));
		}
	}

	protected LauEntry mapEntity(String jsonLine) {
		try {
			LauEntry entity;
			if (StringUtils.contains(jsonLine, "\"district_code\"")) {
				entity = mapper.readValue(jsonLine, MunicipalityEntry.class);
			} else if (StringUtils.contains(jsonLine, "\"region_code\"")) {
				entity = mapper.readValue(jsonLine, DistrictEntry.class);
			} else if (StringUtils.contains(jsonLine, "\"country_code\"")) {
				entity = mapper.readValue(jsonLine, RegionEntry.class);
			} else {
				entity = mapper.readValue(jsonLine, CountryEntry.class);
			}
			return entity;
		} catch (Exception e) {
			throw new BundleException("error in deserialization json " + jsonLine, e);
		}
	}

}
