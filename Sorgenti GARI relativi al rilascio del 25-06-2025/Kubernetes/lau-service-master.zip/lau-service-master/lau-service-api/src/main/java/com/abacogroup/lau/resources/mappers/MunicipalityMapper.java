package com.abacogroup.lau.resources.mappers;

import com.abacogroup.lau.api.MunicipalityRes;
import com.abacogroup.lau.db.ntt.MunicipalityEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface MunicipalityMapper {

	MunicipalityMapper INSTANCE = Mappers.getMapper(MunicipalityMapper.class);

	@Mapping(target = "active", expression = "java(dto.isActive() ? 1 : 0)")
	MunicipalityEntity dtoToEntity(MunicipalityRes dto);

}
