package com.abacogroup.lau.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.v1.CountryResponseV1;
import com.abacogroup.lau.api.v1.req.CountrySearchRequestV1;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;

public interface CountryV1Service {
	InfiniteListResults<CountryResponseV1> searchCountries(ReqContext reqContext, CountrySearchRequestV1 searchRequest, String nextKey);

	List<CountryResponseV1> searchByI18nName(ReqContext reqContext, CountrySearchRequestV1 searchRequest);

	Optional<CountryResponseV1> getCountryByCode(ReqContext reqContext, String code);
}
