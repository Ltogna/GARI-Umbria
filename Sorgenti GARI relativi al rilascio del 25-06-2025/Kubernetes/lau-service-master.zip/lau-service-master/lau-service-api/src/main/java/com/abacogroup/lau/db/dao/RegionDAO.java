package com.abacogroup.lau.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.lau.api.RegionRes;
import com.abacogroup.lau.db.ntt.RegionEntity;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.Optional;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.BatchChunkSize;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface RegionDAO extends Transactional<RegionDAO>, EnhancedSqlObject {

	String FIELDS_WITH_PREFIX = " re.code, re.tenant_id, re.country_code, re.short_descr, re.fl_active ";
	String COUNTRY_FIELDS_WITH_PREFIX = ", co.code as co_code, co.tenant_id as co_tenant_id, co.fl_active as co_fl_active ";
	String FIELDS = " code, tenant_id, country_code, short_descr, fl_active ";
	String TABLE = "lau_region";
	String I18N = " \n, coalesce (§i18n(:tenantId, '" + TABLE + "', 'code', re.code, :lang)§, re.code) as i18n_name\n ";
	String COUNTRY_I18N = " \n, coalesce (§i18n(:tenantId, '" + CountryDAO.TABLE + "', 'code', co.code, :lang)§, co.code) as co_i18n_name\n ";

	@SqlQuery("select " + FIELDS_WITH_PREFIX
			+ " from " + TABLE + " re "
			+ " inner join " + CountryDAO.TABLE + " co on re.country_code = co.code and re.tenant_id = co.tenant_id "
			+ " where re.code = :code and re.tenant_id = :tenantId")
	@RegisterBeanMapper(RegionEntity.class)
	Optional<RegionEntity> findByCode(
			@Bind("code") String code,
			@Bind("tenantId") String tenantId);

	@SqlUpdate("insert into " + TABLE + " (" + FIELDS + ") "
			+ " values (:code, :tenantId, :countryCode, :shortDescr, :active)")
	void insert(@BindBean RegionEntity entity);

	@SqlBatch("insert into " + TABLE + " (" + FIELDS + ") "
			+ " values (:code, :tenantId, :countryCode, :shortDescr, :active)")
	void insertBatch(@BindBean RegionEntity... entity);

	@BatchChunkSize(1000)
	@SqlBatch("insert into " + TABLE + " (" + FIELDS + ") "
			+ " §select_from_dual (:code, :tenantId, :countryCode, :shortDescr, :active)§ "
			+ " where not exists("
			+ " select code "
			+ " from  " + TABLE
			+ " where tenant_id = :tenantId and code = :code )")
	void insertBatchIdempotent(@BindBean RegionEntity... entity);

	@BatchChunkSize(1000)
	@SqlBatch("update " + TABLE +
			" set code = :code, tenant_id = :tenantId, country_code = :countryCode, short_descr = :shortDescr, fl_active = :active " +
			" where tenant_id = :tenantId and code = :code ")
	void updateBatch(@BindBean RegionEntity... entity);

	@SqlQuery("select * from ( "
			+ " select " + FIELDS_WITH_PREFIX + I18N + COUNTRY_FIELDS_WITH_PREFIX + COUNTRY_I18N
			+ " from " + TABLE + " re "
			+ " inner join " + CountryDAO.TABLE + " co on re.country_code = co.code and re.tenant_id = co.tenant_id "
			+ " where <innerCriteria> and re.tenant_id = :tenantId "
			+ " ) re_ "
			+ " where <criteria> ORDER BY <orderBy> ")
	@RegisterBeanMapper(RegionRes.class)
	ResultIterator<RegionRes> searchAll(
			@BindCriteria("innerCriteria") Criteria innerCriteria,
			@BindCriteria Criteria outerCriteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx);

	@SqlQuery("select " + FIELDS_WITH_PREFIX + I18N + COUNTRY_FIELDS_WITH_PREFIX + COUNTRY_I18N
			+ " from " + TABLE + " re "
			+ " inner join " + CountryDAO.TABLE + " co on re.country_code = co.code and re.tenant_id = co.tenant_id "
			+ " where re.code = :code and re.tenant_id = :tenantId")
	@RegisterBeanMapper(RegionRes.class)
	Optional<RegionRes> searchByCode(
			@Bind("code") String code,
			@BindBean ReqContext ctx);

	@SqlQuery("select count(*) from " + TABLE + " where tenant_id = :tenantId ")
	Long countAll(@Bind("tenantId") String tenantId);

	@SqlUpdate("insert into " + TABLE + " (" + FIELDS + ") "
			+ "select r.code, :newTenantId as tenant_id, r.country_code, r.short_descr, r.fl_active "
			+ "from lau_region r where r.tenant_id = :sourceTenant")
	void insertNewTenant(
			@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId);
}
