package com.abacogroup.lau;

import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.Configuration;
import io.dropwizard.db.DataSourceFactory;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LauConfiguration extends Configuration {

	private boolean cors = true;
	
	@Valid
	@NotNull
	@Getter
	@Setter
	private JerseyClientConfiguration jerseyClient = new JerseyClientConfiguration();
	
	@Valid
	@NotNull
	private DataSourceFactory database;

	private RabbitmqConfig rabbitmqConfig;

	@Valid
	private Sso2Config sso2Config;
	
	@Valid
	private BundleConfig bundleConfig;

	
	@Data
	public class RabbitmqConfig {

		private String host;
		private String user;
		private String password;
		private String virtualhost;
		private Integer port;
	}

	
	@Data
	public class Sso2Config {
		private String url;
		private String tasksAuthPhrase;
	}
	
	
}
