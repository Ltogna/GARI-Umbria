package com.abacogroup.lau.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.lau.api.CountryRes;
import com.abacogroup.lau.db.ntt.CountryEntity;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.Optional;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.BatchChunkSize;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface CountryDAO extends Transactional<CountryDAO>, EnhancedSqlObject {

	String FIELDS_WITH_PREFIX = " co.code, co.tenant_id, co.fl_active ";
	String FIELDS = " code, tenant_id, fl_active ";
	String TABLE = "lau_country";
	String I18N = " \n, coalesce (§i18n(:tenantId, '" + TABLE + "', 'code', co.code, :lang)§, co.code) as i18n_name\n ";

	@SqlQuery("select " + FIELDS_WITH_PREFIX + " from " + TABLE + " co where co.code = :code and co.tenant_id = :tenantId")
	@RegisterBeanMapper(CountryEntity.class)
	Optional<CountryEntity> findByCode(
			@Bind("code") String code,
			@Bind("tenantId") String tenantId);

	@SqlUpdate("insert into " + TABLE + " (" + FIELDS + ") values (:code, :tenantId, :active)")
	void insert(@BindBean CountryEntity entity);

	@SqlBatch("insert into " + TABLE + " (" + FIELDS + ") values (:code, :tenantId, :active)")
	void insertBatch(@BindBean CountryEntity... entity);

	@BatchChunkSize(1000)
	@SqlBatch("insert into " + TABLE + " (" + FIELDS + ") "
			+ " §select_from_dual (:code, :tenantId, :active)§ "
			+ " where not exists("
			+ " select code "
			+ " from  " + TABLE
			+ " where tenant_id = :tenantId and code = :code )")
	void insertBatchIdempotent(@BindBean CountryEntity... entity);

	@BatchChunkSize(1000)
	@SqlBatch("update " + TABLE +
			" set code = :code, tenant_id = :tenantId, fl_active = :active" +
			" where tenant_id = :tenantId and code = :code ")
	void updateBatch(@BindBean CountryEntity... entity);

	@SqlQuery("select * from ( "
			+ " select " + FIELDS_WITH_PREFIX + I18N
			+ " from " + TABLE + " co "
			+ " where <innerCriteria> and co.tenant_id = :tenantId "
			+ " ) co_ "
			+ " where <criteria> ORDER BY <orderBy> ")
	@RegisterBeanMapper(CountryRes.class)
	ResultIterator<CountryRes> searchAll(
			@BindCriteria("innerCriteria") Criteria innerCriteria,
			@BindCriteria Criteria outerCriteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx);

	@SqlQuery(
			"select " + FIELDS_WITH_PREFIX + I18N + " from " + TABLE + " co where co.code = :code and co.tenant_id = :tenantId")
	@RegisterBeanMapper(CountryRes.class)
	Optional<CountryRes> searchByCode(
			@Bind("code") String code,
			@BindBean ReqContext ctx);

	@SqlQuery("select count(*) from " + TABLE + " where tenant_id = :tenantId ")
	Long countAll(@Bind("tenantId") String tenantId);

	@SqlUpdate("insert into " + TABLE + " (" + FIELDS + ") "
			+ "select c.code, :newTenantId as tenant_id, c.fl_active "
			+ "from lau_country c where c.tenant_id = :sourceTenant ")
	void insertNewTenant(
			@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId);
}
