package com.abacogroup.lau.bundle.tenant;

import com.abacogroup.bundles.Constants;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.lau.db.dao.CountryDAO;
import com.abacogroup.lau.db.dao.DistrictDAO;
import com.abacogroup.lau.db.dao.MunicipalityDAO;
import com.abacogroup.lau.db.dao.RegionDAO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LauTenantMessageProcessor implements TenantMessageProcessor {

	private final CountryDAO countryDAO;
	private final RegionDAO regionDAO;
	private final DistrictDAO districtDAO;
	private final MunicipalityDAO municipalityDAO;

	public LauTenantMessageProcessor(CountryDAO countryDAO, RegionDAO regionDAO, DistrictDAO districtDAO, MunicipalityDAO municipalityDAO) {
		this.countryDAO = countryDAO;
		this.regionDAO = regionDAO;
		this.districtDAO = districtDAO;
		this.municipalityDAO = municipalityDAO;
	}

	@Override
	public void onMessage(TenantMessage tenantMessage) {
		String tenantId = tenantMessage.getTenantId();
		if (countryDAO.countAll(tenantId) > 0L) {
			log.warn("countries already present for tenant {}", tenantId);
			return;
		}
		countryDAO.insertNewTenant(Constants.ALL_TENANTS, tenantId);
		regionDAO.insertNewTenant(Constants.ALL_TENANTS, tenantId);
		districtDAO.insertNewTenant(Constants.ALL_TENANTS, tenantId);
		municipalityDAO.insertNewTenant(Constants.ALL_TENANTS, tenantId);
	}
}
