package com.abacogroup.lau.resources.mappers;

import com.abacogroup.lau.api.DistrictRes;
import com.abacogroup.lau.db.ntt.DistrictEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DistrictMapper {

	DistrictMapper INSTANCE = Mappers.getMapper(DistrictMapper.class);

	@Mapping(target = "active", expression = "java(dto.isActive() ? 1 : 0)")
	DistrictEntity dtoToEntity(DistrictRes dto);

}
