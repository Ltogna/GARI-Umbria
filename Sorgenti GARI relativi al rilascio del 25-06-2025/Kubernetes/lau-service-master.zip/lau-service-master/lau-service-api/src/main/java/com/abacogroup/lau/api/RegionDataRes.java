package com.abacogroup.lau.api;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.jdbi.v3.core.mapper.reflect.ColumnName;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class RegionDataRes {

	private static final String CODE_REGEXP_1_100 = "^[A-Z\\d_]{1,100}$"; // TODO length

	@NotBlank
	@Pattern(regexp = CODE_REGEXP_1_100)
	@ColumnName("code")
	private String code;
	@NotBlank
	@ColumnName("tenant_id")
	private String tenantId;
	@NotBlank
	@ColumnName("country_code")
	private String countryCode;
	@NotBlank
	@ColumnName("short_descr")
	private String shortDescr;
	@Builder.Default
	@ColumnName("fl_active")
	private boolean active = true;

	@ColumnName("i18n_name")
	private String i18nName;

}
