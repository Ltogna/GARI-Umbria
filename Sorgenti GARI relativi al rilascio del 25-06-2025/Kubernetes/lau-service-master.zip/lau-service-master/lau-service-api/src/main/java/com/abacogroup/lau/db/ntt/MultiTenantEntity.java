package com.abacogroup.lau.db.ntt;

public interface MultiTenantEntity<T> {

	T getTenantId();

	void setTenantId(T tenant);
}
