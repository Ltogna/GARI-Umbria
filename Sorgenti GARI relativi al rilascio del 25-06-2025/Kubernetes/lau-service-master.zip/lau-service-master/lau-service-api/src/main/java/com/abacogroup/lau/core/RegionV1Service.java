package com.abacogroup.lau.core;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.v1.RegionDataResponseV1;
import com.abacogroup.lau.api.v1.RegionResponseV1;
import com.abacogroup.lau.api.v1.req.RegionSearchRequestV1;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;

public interface RegionV1Service {
	InfiniteListResults<RegionResponseV1> searchRegions(ReqContext reqContext, RegionSearchRequestV1 searchRequest, String nextKey);

	List<RegionDataResponseV1> searchByI18nName(ReqContext reqContext, RegionSearchRequestV1 searchRequest);

	Optional<RegionResponseV1> getRegionByCode(ReqContext reqContext, String code);
}
