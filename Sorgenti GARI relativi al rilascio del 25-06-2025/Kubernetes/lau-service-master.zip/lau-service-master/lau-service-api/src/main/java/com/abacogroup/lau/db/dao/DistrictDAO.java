package com.abacogroup.lau.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.DefineOrder;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.lau.api.DistrictRes;
import com.abacogroup.lau.db.ntt.DistrictEntity;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.Optional;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.BatchChunkSize;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface DistrictDAO extends Transactional<DistrictDAO>, EnhancedSqlObject {

	String FIELDS_WITH_PREFIX = " di.code, di.tenant_id, di.region_code, di.short_descr, di.fl_active ";
	String REGION_FIELDS_WITH_PREFIX = ", re.code as re_code, re.tenant_id as re_tenant_id, "
			+ "re.country_code as re_country_code, re.short_descr as re_short_descr, re.fl_active as re_fl_active ";
	String COUNTRY_FIELDS_WITH_PREFIX = ", co.code as re_co_code, co.tenant_id as re_co_tenant_id, co.fl_active as re_co_fl_active ";
	String FIELDS = " code, tenant_id, region_code, short_descr, fl_active ";
	String TABLE = "lau_district";
	String I18N = " \n, coalesce (§i18n(:tenantId, '" + TABLE + "', 'code', di.code, :lang)§, di.code) as i18n_name\n ";
	String REGION_I18N = " \n, coalesce (§i18n(:tenantId, '" + RegionDAO.TABLE + "', 'code', re.code, :lang)§, re.code) as re_i18n_name\n ";
	String COUNTRY_I18N = " \n, coalesce (§i18n(:tenantId, '" + CountryDAO.TABLE + "', 'code', co.code, :lang)§, co.code) as re_co_i18n_name\n ";

	@SqlQuery("select " + FIELDS_WITH_PREFIX
			+ " from " + TABLE + " di "
			+ " inner join " + RegionDAO.TABLE + " re on di.region_code = re.code and di.tenant_id = re.tenant_id "
			+ " inner join " + CountryDAO.TABLE + " co on re.country_code = co.code and re.tenant_id = co.tenant_id "
			+ " where di.code = :code and di.tenant_id = :tenantId")
	@RegisterBeanMapper(DistrictEntity.class)
	Optional<DistrictEntity> findByCode(
			@Bind("code") String code,
			@Bind("tenantId") String tenantId);

	@SqlUpdate("insert into " + TABLE + " (" + FIELDS + ") "
			+ " values (:code, :tenantId, :regionCode, :shortDescr, :active)")
	void insert(@BindBean DistrictEntity entity);

	@SqlBatch("insert into " + TABLE + " (" + FIELDS + ") "
			+ " values (:code, :tenantId, :regionCode, :shortDescr, :active)")
	void insertBatch(@BindBean DistrictEntity... entity);

	@BatchChunkSize(1000)
	@SqlBatch("insert into " + TABLE + " (" + FIELDS + ") "
			+ " §select_from_dual (:code, :tenantId, :regionCode, :shortDescr, :active)§ "
			+ " where not exists("
			+ " select code "
			+ " from  " + TABLE
			+ " where tenant_id = :tenantId and code = :code )")
	void insertBatchIdempotent(@BindBean DistrictEntity... entity);

	@BatchChunkSize(1000)
	@SqlBatch("update " + TABLE +
			" set code = :code, tenant_id = :tenantId, region_code = :regionCode, short_descr = :shortDescr, fl_active = :active " +
			" where tenant_id = :tenantId and code = :code ")
	void updateBatch(@BindBean DistrictEntity... entity);

	@SqlQuery("select * from (select " + FIELDS_WITH_PREFIX + I18N + REGION_FIELDS_WITH_PREFIX + REGION_I18N
			+ COUNTRY_FIELDS_WITH_PREFIX + COUNTRY_I18N
			+ " from " + TABLE + " di "
			+ " inner join " + RegionDAO.TABLE + " re on di.region_code = re.code and di.tenant_id = re.tenant_id "
			+ " inner join " + CountryDAO.TABLE + " co on re.country_code = co.code and re.tenant_id = co.tenant_id "
			+ "where <inner_criteria> and di.tenant_id = :tenantId "
			+ ") di_ "
			+ " where <criteria> ORDER BY <orderBy>")
	@RegisterBeanMapper(DistrictRes.class)
	ResultIterator<DistrictRes> searchAll(
			@BindCriteria("inner_criteria") Criteria innerCriteria,
			@BindCriteria Criteria outerCriteria,
			@DefineOrder OrderBy orderBy,
			@BindBean ReqContext ctx);

	@SqlQuery("select " + FIELDS_WITH_PREFIX + I18N + REGION_FIELDS_WITH_PREFIX + REGION_I18N
			+ COUNTRY_FIELDS_WITH_PREFIX + COUNTRY_I18N
			+ " from " + TABLE + " di "
			+ " inner join " + RegionDAO.TABLE + " re on di.region_code = re.code and di.tenant_id = re.tenant_id "
			+ " inner join " + CountryDAO.TABLE + " co on re.country_code = co.code and re.tenant_id = co.tenant_id "
			+ " where di.code = :code and di.tenant_id = :tenantId")
	@RegisterBeanMapper(DistrictRes.class)
	Optional<DistrictRes> searchByCode(
			@Bind("code") String code,
			@BindBean ReqContext ctx);

	@SqlQuery("select count(*) from " + TABLE + " where tenant_id = :tenantId ")
	Long countAll(@Bind("tenantId") String tenantId);

	@SqlUpdate("insert into " + TABLE + " (" + FIELDS + ") "
			+ "select d.code, :newTenantId as tenant_id, d.region_code, d.short_descr, d.fl_active "
			+ "from lau_district d where d.tenant_id = :sourceTenant ")
	void insertNewTenant(
			@Bind("sourceTenant") String sourceTenant,
			@Bind("newTenantId") String newTenantId);
}
