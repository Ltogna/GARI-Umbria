package com.abacogroup.lau.bundle.config.i18n;

import com.abacogroup.lau.db.dao.I18nDAO;
import com.abacogroup.lau.db.ntt.I18nEntity;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class I18nHelper {

	private final I18nDAO i18nDAO;

	public I18nHelper(I18nDAO i18nDAO) {
		this.i18nDAO = i18nDAO;
	}

	public void upsert(String tenantId, String tableName, String fieldName, I18nAware holder) {
		I18nEntity[] records = holder.getI18n()
				.stream()
				.map(i18NEntry -> I18nEntity.builder()
						.setTenantId(tenantId)
						.setFieldName(fieldName)
						.setTableName(tableName)
						.setI18nValue(holder.getI18nCode())
						.setLang(i18NEntry.getLang())
						.setI18nText(i18NEntry.getCode())
						.build()).collect(Collectors.toSet())
				.toArray(I18nEntity[]::new);

		if (records.length > 0) {
			log.info("updating {} labels for tenant {} and table {}", records.length, tenantId, tableName);
			i18nDAO.deleteBatch(records);
			i18nDAO.insert(records);
		} else {
			//	log.info("no labels found for tenant {} and table {}", tenantId, tableName);
		}
	}

	public void upsert(String tenantId, String tableName, String fieldName, List<? extends I18nAware> list) {

		List<I18nEntity> entities = new ArrayList<>();
		list.forEach(holder -> entities.addAll(holder.getI18n()
				.stream()
				.map(i18NEntry -> I18nEntity.builder()
						.setTenantId(tenantId)
						.setFieldName(fieldName)
						.setTableName(tableName)
						.setI18nValue(holder.getI18nCode())
						.setLang(i18NEntry.getLang())
						.setI18nText(i18NEntry.getCode())
						.build())
				.collect(Collectors.toSet())));

		I18nEntity[] records = entities.toArray(I18nEntity[]::new);
		if (records.length > 0) {
			log.info("updating {} labels for tenant {} and table {}", records.length, tenantId, tableName);
			i18nDAO.deleteBatch(records);
			i18nDAO.insert(records);
		} else {
			//	log.info("no labels found for tenant {} and table {}", tenantId, tableName);
		}
	}

}
