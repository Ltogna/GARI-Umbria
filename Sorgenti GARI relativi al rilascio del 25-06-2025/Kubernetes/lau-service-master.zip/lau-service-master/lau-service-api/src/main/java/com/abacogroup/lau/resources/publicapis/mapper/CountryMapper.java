package com.abacogroup.lau.resources.publicapis.mapper;

import com.abacogroup.lau.api.CountryRes;
import com.abacogroup.lau.api.v1.CountryResponseV1;
import com.abacogroup.lau.api.v1.req.CountrySearchRequestV1;
import com.abacogroup.lau.resources.req.CountrySearchReq;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface CountryMapper {
	CountryMapper INSTANCE = Mappers.getMapper(CountryMapper.class);

	CountryResponseV1 toV1(CountryRes res);

	CountrySearchReq fromV1(CountrySearchRequestV1 requestV1);

}
