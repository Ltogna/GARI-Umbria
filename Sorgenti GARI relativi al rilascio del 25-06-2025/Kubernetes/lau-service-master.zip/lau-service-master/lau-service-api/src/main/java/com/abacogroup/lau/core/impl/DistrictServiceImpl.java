package com.abacogroup.lau.core.impl;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.DistrictDataRes;
import com.abacogroup.lau.api.DistrictRes;
import com.abacogroup.lau.core.DistrictService;
import com.abacogroup.lau.db.dao.DistrictDAO;
import com.abacogroup.lau.db.ntt.DistrictEntity;
import com.abacogroup.lau.resources.mappers.DistrictMapper;
import com.abacogroup.lau.resources.req.DistrictSearchReq;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DistrictServiceImpl implements DistrictService {

	private final DistrictDAO districtDAO;

	public DistrictServiceImpl(DistrictDAO districtDAO) {
		this.districtDAO = districtDAO;
	}

	@Override
	public Optional<DistrictEntity> loadDistrictByCode(String tenantId, String code) {
		return districtDAO.findByCode(code, tenantId);
	}

	@Override
	public InfiniteListResults<DistrictRes> searchDistricts(ReqContext reqContext, DistrictSearchReq searchRequest,
			String nextKey) {
		Criteria innerCriteria = searchRequest.getInnerCriteria();
		Criteria outerCriteria = searchRequest.getOuterCriteria();
		OrderBy sort = searchRequest.getSort();

		InfiniteListResults<DistrictRes> districts = districtDAO.infinite(() ->
						districtDAO.searchAll(innerCriteria, outerCriteria, sort, reqContext),
				nextKey, searchRequest.getPageSize());
		return districts;
	}

	@Override
	public List<DistrictDataRes> searchByI18nName(ReqContext reqContext, DistrictSearchReq searchRequest) {
		// limit to first 10 elements
		List<DistrictDataRes> districts = this.searchDistricts(reqContext, searchRequest, null)
				.map(district -> {
					district.setRegion(null);
					return ((DistrictDataRes) district);
				})
				.getRecords();

		return districts;
	}

	@Override
	public Optional<DistrictRes> getDistrictByCode(ReqContext reqContext, String code) {
		return districtDAO.searchByCode(code, reqContext);
	}

	@Override
	public DistrictRes save(ReqContext reqContext, DistrictRes district) {
		DistrictEntity entity = DistrictMapper.INSTANCE.dtoToEntity(district);
		entity.setTenantId(reqContext.getTenantId());
		districtDAO.insert(entity);
		return districtDAO.searchByCode(district.getCode(), reqContext).orElse(null);
	}

}
