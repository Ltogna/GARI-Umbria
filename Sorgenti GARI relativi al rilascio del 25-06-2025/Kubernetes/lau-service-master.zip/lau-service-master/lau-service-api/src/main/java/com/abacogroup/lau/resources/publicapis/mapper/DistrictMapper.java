package com.abacogroup.lau.resources.publicapis.mapper;

import com.abacogroup.lau.api.DistrictDataRes;
import com.abacogroup.lau.api.DistrictRes;
import com.abacogroup.lau.api.v1.DistrictDataResponseV1;
import com.abacogroup.lau.api.v1.DistrictResponseV1;
import com.abacogroup.lau.api.v1.req.DistrictSearchRequestV1;
import com.abacogroup.lau.resources.req.DistrictSearchReq;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DistrictMapper {
	DistrictMapper INSTANCE = Mappers.getMapper(DistrictMapper.class);

	DistrictResponseV1 toV1(DistrictRes res);

	DistrictDataResponseV1 toV1(DistrictDataRes res);

	DistrictSearchReq fromV1(DistrictSearchRequestV1 requestV1);

}
