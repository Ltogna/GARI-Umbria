package com.abacogroup.lau.db.ntt;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.jdbi.v3.core.mapper.reflect.ColumnName;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class DistrictEntity implements MultiTenantEntity<String> {

	@ColumnName("code")
	private String code;
	@ColumnName("tenant_id")
	private String tenantId;
	@ColumnName("region_code")
	private String regionCode;
	@ColumnName("short_descr")
	private String shortDescr;
	@Builder.Default
	@ColumnName("fl_active")
	private int active = 1;

}
