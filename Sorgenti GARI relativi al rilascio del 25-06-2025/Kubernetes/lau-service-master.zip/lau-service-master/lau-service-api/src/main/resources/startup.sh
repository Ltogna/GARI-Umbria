#!/bin/sh

umask 0002 && \
java -jar ${project.build.finalName}.jar server config.yml
