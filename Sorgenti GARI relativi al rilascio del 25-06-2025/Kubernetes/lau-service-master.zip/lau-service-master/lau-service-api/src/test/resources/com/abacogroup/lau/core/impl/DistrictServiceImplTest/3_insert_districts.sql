--liquibase formatted sql
--changeset realt:3
insert into lau_district (code, tenant_id, region_code, short_descr)
values ('ITA_20_001', :test_tenant, 'ITA_20', '001');
insert into lau_district (code, tenant_id, region_code, short_descr)
values ('USA_FL_AAA', :test_tenant, 'USA_FL', 'AAA');
insert into lau_district (code, tenant_id, region_code, short_descr)
values ('USA_ZZ_XXX', :test_tenant, 'USA_ZZ', 'XXX');
insert into lau_district (code, tenant_id, region_code, short_descr)
values ('YUG_00_000', :test_tenant, 'YUG_00', '000');
insert into lau_district (code, tenant_id, region_code, short_descr)
values ('ITA_10_003', :test_tenant, 'ITA_10', '003');
insert into lau_district (code, tenant_id, region_code, short_descr)
values ('ITA_10_004', :test_tenant, 'ITA_10', '004');
insert into lau_district (code, tenant_id, region_code, short_descr, fl_active)
values ('ITA_10_999', :test_tenant, 'ITA_10', '999', 0);
insert into lau_district (code, tenant_id, region_code, short_descr, fl_active)
values ('USA_ZZ_ZZZ', :test_tenant, 'USA_ZZ', 'ZZZ', 0);

insert into lau_district (code, tenant_id, region_code, short_descr)
values ('ITA_20_001', 'not_' || :test_tenant, 'ITA_20', '001');
insert into lau_district (code, tenant_id, region_code, short_descr)
values ('ITA_20_002', 'not_' || :test_tenant, 'ITA_20', '002');
