insert into lau_country (code, tenant_id)
values ('TEST_D_A1', :test_tenant);

insert into lau_region (code, tenant_id, country_code, short_descr)
values ('TEST_D_B1', :test_tenant, 'TEST_D_A1', '01');

insert into lau_district (code, tenant_id, region_code, short_descr)
values ('TEST_D_C1', :test_tenant, 'TEST_D_B1', '01');
insert into lau_district (code, tenant_id, region_code, short_descr)
values ('TEST_D_C2', :test_tenant, 'TEST_D_B1', '02');

insert into lau_municipality (code, tenant_id, district_code, short_descr)
values ('TEST_D1', :test_tenant, 'TEST_D_C1', '01');
insert into lau_municipality (code, tenant_id, district_code, short_descr)
values ('TEST_D2', :test_tenant, 'TEST_D_C1', '02');
insert into lau_municipality (code, tenant_id, district_code, short_descr)
values ('TEST_D3', :test_tenant, 'TEST_D_C1', '03');
insert into lau_municipality (code, tenant_id, district_code, short_descr)
values ('TEST_D5', :test_tenant, 'TEST_D_C1', '05');
insert into lau_municipality (code, tenant_id, district_code, short_descr)
values ('TEST_D6', :test_tenant, 'TEST_D_C2', '06');
insert into lau_municipality (code, tenant_id, district_code, short_descr)
values ('TEST_D7', :test_tenant, 'TEST_D_C2', '07');

insert into lau_municipality (code, tenant_id, district_code, short_descr, fl_active)
values ('TEST_D4', :test_tenant, 'TEST_D_C1', '04', 0);

INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_municipality', 'code', 'TEST_D1', 'en', 'Test D1');
INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_municipality', 'code', 'TEST_D2', 'en', 'test d2');
INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_municipality', 'code', 'TEST_D3', 'en', 'd tre');
INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_municipality', 'code', 'TEST_D5', 'en', 'TESTd5');
INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_municipality', 'code', 'TEST_D6', 'en', 'di 6');
INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_municipality', 'code', 'TEST_D7', 'en', 'test d7');
INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_municipality', 'code', 'TEST_D4', 'en', 'test d4');
