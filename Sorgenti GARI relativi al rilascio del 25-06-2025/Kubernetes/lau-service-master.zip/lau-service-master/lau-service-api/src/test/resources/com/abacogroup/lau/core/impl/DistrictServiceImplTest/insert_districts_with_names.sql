insert into lau_country (code, tenant_id)
values ('TEST_C_A1', :test_tenant);

insert into lau_region (code, tenant_id, country_code, short_descr)
values ('TEST_C_B1', :test_tenant, 'TEST_C_A1', '01');

insert into lau_region (code, tenant_id, country_code, short_descr)
values ('TEST_C_B2', :test_tenant, 'TEST_C_A1', '02');

insert into lau_district (code, tenant_id, region_code, short_descr)
values ('TEST_C1', :test_tenant, 'TEST_C_B1', '01');

insert into lau_district (code, tenant_id, region_code, short_descr)
values ('TEST_C2', :test_tenant, 'TEST_C_B1', '02');

insert into lau_district (code, tenant_id, region_code, short_descr)
values ('TEST_C3', :test_tenant, 'TEST_C_B1', '03');

insert into lau_district (code, tenant_id, region_code, short_descr)
values ('TEST_C5', :test_tenant, 'TEST_C_B1', '05');

insert into lau_district (code, tenant_id, region_code, short_descr)
values ('TEST_C6', :test_tenant, 'TEST_C_B2', '06');

insert into lau_district (code, tenant_id, region_code, short_descr)
values ('TEST_C7', :test_tenant, 'TEST_C_B2', '07');

insert into lau_district (code, tenant_id, region_code, short_descr, fl_active)
values ('TEST_C4', :test_tenant, 'TEST_C_B1', '04', 0);

INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_district', 'code', 'TEST_C1', 'en', 'Test C1');

INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_district', 'code', 'TEST_C2', 'en', 'test c2');

INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_district', 'code', 'TEST_C3', 'en', 'c tre');

INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_district', 'code', 'TEST_C5', 'en', 'TESTc5');

INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_district', 'code', 'TEST_C6', 'en', 'ci 6');

INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_district', 'code', 'TEST_C7', 'en', 'test c7');

INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_district', 'code', 'TEST_C4', 'en', 'test c4');


