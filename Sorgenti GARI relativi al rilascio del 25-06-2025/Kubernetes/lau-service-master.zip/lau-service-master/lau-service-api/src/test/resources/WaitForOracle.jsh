import java.sql.Connection;
import java.sql.DriverManager;

Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();

long start = System.currentTimeMillis();
Connection cnn = null;
while (true)
{
  try
  {
    Thread.sleep(1000);
    cnn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/ORCLPDB1", "test", "test");
    cnn.close();
    System.exit(0);
  }
  catch (Exception e)
  {
    cnn = null;
    if (System.currentTimeMillis() - start > 240_000)
    {
      System.err.println("Cannot connect to oracle");
      System.exit(1);
    }
  }
}
