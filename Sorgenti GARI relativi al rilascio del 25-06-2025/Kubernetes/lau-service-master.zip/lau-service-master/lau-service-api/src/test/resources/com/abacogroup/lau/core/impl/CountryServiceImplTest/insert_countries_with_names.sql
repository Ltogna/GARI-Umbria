insert into lau_country (code, tenant_id)
values ('TEST_A1', :test_tenant);
insert into lau_country (code, tenant_id)
values ('TEST_A2', :test_tenant);
insert into lau_country (code, tenant_id)
values ('TEST_A3', :test_tenant);
insert into lau_country (code, tenant_id)
values ('TEST_A5', :test_tenant);

insert into lau_country (code, tenant_id, fl_active)
values ('TEST_A4', :test_tenant, 0);

INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_country', 'code', 'TEST_A1', 'en', 'Test A1');
INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_country', 'code', 'TEST_A2', 'en', 'test a2');
INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_country', 'code', 'TEST_A3', 'en', 'a tre');
INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_country', 'code', 'TEST_A5', 'en', 'TESTa5');
INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_country', 'code', 'TEST_A4', 'en', 'test a4');
