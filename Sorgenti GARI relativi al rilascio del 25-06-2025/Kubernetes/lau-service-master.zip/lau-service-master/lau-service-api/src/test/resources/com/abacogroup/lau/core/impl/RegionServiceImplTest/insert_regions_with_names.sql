insert into lau_country (code, tenant_id)
values ('TEST_B_A1', :test_tenant);
insert into lau_country (code, tenant_id)
values ('TEST_B_A2', :test_tenant);

insert into lau_region (code, tenant_id, country_code, short_descr)
values ('TEST_B1', :test_tenant, 'TEST_B_A1', '01');
insert into lau_region (code, tenant_id, country_code, short_descr)
values ('TEST_B2', :test_tenant, 'TEST_B_A1', '02');
insert into lau_region (code, tenant_id, country_code, short_descr)
values ('TEST_B3', :test_tenant, 'TEST_B_A1', '03');
insert into lau_region (code, tenant_id, country_code, short_descr)
values ('TEST_B5', :test_tenant, 'TEST_B_A1', '05');
insert into lau_region (code, tenant_id, country_code, short_descr)
values ('TEST_B6', :test_tenant, 'TEST_B_A2', '06');
insert into lau_region (code, tenant_id, country_code, short_descr)
values ('TEST_B7', :test_tenant, 'TEST_B_A2', '07');

insert into lau_region (code, tenant_id, country_code, short_descr, fl_active)
values ('TEST_B4', :test_tenant, 'TEST_B_A1', '04', 0);

INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_region', 'code', 'TEST_B1', 'en', 'Test B1');
INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_region', 'code', 'TEST_B2', 'en', 'test b2');
INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_region', 'code', 'TEST_B3', 'en', 'b tre');
INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_region', 'code', 'TEST_B5', 'en', 'TESTb5');
INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_region', 'code', 'TEST_B6', 'en', 'bi 6');
INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_region', 'code', 'TEST_B7', 'en', 'test b7');
INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
VALUES (:test_tenant, 'lau_region', 'code', 'TEST_B4', 'en', 'test b4');
