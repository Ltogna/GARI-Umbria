--liquibase formatted sql
--changeset realt:2
insert into lau_region (code, tenant_id, country_code, short_descr)
values ('ITA_20', :test_tenant, 'ITA', '20');
insert into lau_region (code, tenant_id, country_code, short_descr)
values ('USA_FL', :test_tenant, 'USA', 'FL');
insert into lau_region (code, tenant_id, country_code, short_descr)
values ('YUG_00', :test_tenant, 'YUG', '00');
insert into lau_region (code, tenant_id, country_code, short_descr)
values ('ITA_10', :test_tenant, 'ITA', '10');
insert into lau_region (code, tenant_id, country_code, short_descr, fl_active)
values ('USA_ZZ', :test_tenant, 'USA', 'ZZ', 0);

insert into lau_region (code, tenant_id, country_code, short_descr)
values ('ITA_20', 'not_' || :test_tenant, 'ITA', '20');
insert into lau_region (code, tenant_id, country_code, short_descr)
values ('ITA_01', 'not_' || :test_tenant, 'ITA', '01');
