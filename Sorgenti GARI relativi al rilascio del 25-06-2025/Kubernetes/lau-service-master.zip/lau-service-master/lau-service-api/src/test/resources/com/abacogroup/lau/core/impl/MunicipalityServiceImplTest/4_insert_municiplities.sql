--liquibase formatted sql
--changeset realt:4
insert into lau_municipality (code, tenant_id, district_code, short_descr)
values ('ITA_20_001_101', :test_tenant, 'ITA_20_001', '101');
insert into lau_municipality (code, tenant_id, district_code, short_descr)
values ('USA_FL_AAA_BBB', :test_tenant, 'USA_FL_AAA', 'BBB');
insert into lau_municipality (code, tenant_id, district_code, short_descr)
values ('USA_ZZ_XXX_XXX', :test_tenant, 'USA_ZZ_XXX', 'XXX');
insert into lau_municipality (code, tenant_id, district_code, short_descr)
values ('USA_ZZ_ZZZ_XXX', :test_tenant, 'USA_ZZ_ZZZ', 'XXX');
insert into lau_municipality (code, tenant_id, district_code, short_descr)
values ('YUG_00_000_000', :test_tenant, 'YUG_00_000', '000');
insert into lau_municipality (code, tenant_id, district_code, short_descr)
values ('ITA_10_999_111', :test_tenant, 'ITA_10_999', '111');
insert into lau_municipality (code, tenant_id, district_code, short_descr)
values ('ITA_10_003_103', :test_tenant, 'ITA_10_003', '103');
insert into lau_municipality (code, tenant_id, district_code, short_descr)
values ('ITA_10_003_104', :test_tenant, 'ITA_10_003', '104');
insert into lau_municipality (code, tenant_id, district_code, short_descr, fl_active)
values ('ITA_10_003_999', :test_tenant, 'ITA_10_003', '999', 0);
insert into lau_municipality (code, tenant_id, district_code, short_descr, fl_active)
values ('ITA_10_999_999', :test_tenant, 'ITA_10_999', '999', 0);
insert into lau_municipality (code, tenant_id, district_code, short_descr, fl_active)
values ('USA_ZZ_ZZZ_ZZZ', :test_tenant, 'USA_ZZ_ZZZ', 'ZZZ', 0);

insert into lau_municipality (code, tenant_id, district_code, short_descr)
values ('ITA_20_001_101', 'not_' || :test_tenant, 'ITA_20_001', '101');
insert into lau_municipality (code, tenant_id, district_code, short_descr)
values ('ITA_20_001_102', 'not_' || :test_tenant, 'ITA_20_001', '102');
