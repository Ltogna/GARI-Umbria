INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
select :test_tenant, 'lau_country', 'code', code, 'en', lower(code) || '_' || 'en'
from lau_country
where tenant_id = :test_tenant;

INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
select :test_tenant, 'lau_country', 'code', code, 'it', lower(code) || '_' || 'it'
from lau_country
where tenant_id = :test_tenant;

INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
select :test_tenant, 'lau_region', 'code', code, 'en', lower(code) || '_' || 'en'
from lau_region
where tenant_id = :test_tenant;

INSERT INTO lau_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
select :test_tenant, 'lau_region', 'code', code, 'it', lower(code) || '_' || 'it'
from lau_region
where tenant_id = :test_tenant;
