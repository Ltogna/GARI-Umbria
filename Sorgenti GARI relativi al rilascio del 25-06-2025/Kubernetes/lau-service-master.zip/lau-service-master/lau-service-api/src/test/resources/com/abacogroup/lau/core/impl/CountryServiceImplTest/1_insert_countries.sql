--liquibase formatted sql
--changeset realt:1
insert into lau_country (code, tenant_id)
values ('ITA', :test_tenant);
insert into lau_country (code, tenant_id)
values ('USA', :test_tenant);
insert into lau_country (code, tenant_id)
values ('GBR', :test_tenant);
insert into lau_country (code, tenant_id, fl_active)
values ('YUG', :test_tenant, 0);

insert into lau_country (code, tenant_id)
values ('ITA', 'not_' || :test_tenant);
insert into lau_country (code, tenant_id)
values ('BRA', 'not_' || :test_tenant);
