package com.abacogroup.lau.core.impl;

import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.lau.api.CountryRes;
import com.abacogroup.lau.db.JdbiTest;
import com.abacogroup.lau.db.ntt.CountryEntity;
import com.abacogroup.lau.resources.req.CountrySearchReq;
import com.abacogroup.lau.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.assertj.core.groups.Tuple;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

@ExtendWith(DropwizardExtensionsSupport.class)
class CountryServiceImplTest extends JdbiTest {

	private static final String TENANT = String.format("%s_t", CountryServiceImplTest.class.getSimpleName());

	private static final ReqContext reqContext = new ReqContext(TENANT, "delete_me", "en");
	private final CountryServiceImpl service = getService(CountryServiceImpl.class);

	@ParameterizedTest(name = "[{0}] {1}")
	@MethodSource("com.abacogroup.lau.core.impl.CountryServiceTestSources#test_search_dto")
	void test_search_dto(String ignoredTitle, CountrySearchReq request, List<Tuple> results) {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "i18n");
			execSqlFiles(CountryServiceImplTest.class, initScripts, Map.of("test_tenant", TENANT));

			List<CountryRes> list = this.service.searchCountries(reqContext, request, null)
					.getRecords();

			assertThat(list).extracting(CountryRes::getCode, CountryRes::getI18nName)
					.containsExactlyInAnyOrderElementsOf(results);

			h.rollback();
		});
	}

	@Test
	void test_loadCountryByCode() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "i18n");
			execSqlFiles(CountryServiceImplTest.class, initScripts, Map.of("test_tenant", TENANT));

			Optional<CountryEntity> country = this.service.loadCountryByCode(TENANT, "GBR");

			assertThat(country).isPresent().get()
					.satisfies(c -> {
						assertThat(c.getCode()).isEqualTo("GBR");
					});

			h.rollback();
		});
	}

	@Test
	void test_loadCountryByCode_notFound() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "i18n");
			execSqlFiles(CountryServiceImplTest.class, initScripts, Map.of("test_tenant", TENANT));

			Optional<CountryEntity> country = this.service.loadCountryByCode("not_" + TENANT, "GBR");

			assertThat(country).isEmpty();

			h.rollback();
		});
	}

	@Test
	void test_getCountryByCode() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "i18n");
			execSqlFiles(CountryServiceImplTest.class, initScripts, Map.of("test_tenant", TENANT));

			Optional<CountryRes> country = this.service.getCountryByCode(reqContext, "GBR");

			assertThat(country).isPresent().get()
					.satisfies(c -> {
						assertThat(c.getCode()).isEqualTo("GBR");
						assertThat(c.isActive()).isTrue();
						assertThat(c.getI18nName()).isEqualTo("gbr_en");
					});

			h.rollback();
		});
	}

	@Test
	void test_getCountryByCode_notFound() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "i18n");
			execSqlFiles(CountryServiceImplTest.class, initScripts, Map.of("test_tenant", TENANT));

			Optional<CountryRes> country = this.service.getCountryByCode(reqContext, "NOT_EXISTING");

			assertThat(country).isEmpty();

			h.rollback();
		});
	}

	@Test
	void test_save_noI18n() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "i18n");
			execSqlFiles(CountryServiceImplTest.class, initScripts, Map.of("test_tenant", TENANT));

			String code = "delete_me";
			CountryRes country = service.save(reqContext, CountryRes.builder()
					.setCode(code)
					.build());

			assertThat(country).isNotNull();
			assertThat(country.getCode()).isEqualTo("delete_me");
			assertThat(country.getI18nName()).isEqualTo("delete_me");
			assertThat(country.isActive()).isTrue();
			assertThat(country.getTenantId()).isEqualTo(reqContext.getTenantId());

			h.rollback();
		});
	}

	@Test
	void test_save_noActive() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "i18n");
			execSqlFiles(CountryServiceImplTest.class, initScripts, Map.of("test_tenant", TENANT));

			String code = "delete_me";
			CountryRes country = service.save(reqContext, CountryRes.builder()
					.setCode(code)
					.setActive(false)
					.build());

			assertThat(country).isNotNull();
			assertThat(country.getCode()).isEqualTo("delete_me");
			assertThat(country.getI18nName()).isEqualTo("delete_me");
			assertThat(country.isActive()).isFalse();
			assertThat(country.getTenantId()).isEqualTo(reqContext.getTenantId());

			h.rollback();
		});
	}

	@ParameterizedTest(name = "[{0}] {1}")
	@MethodSource("com.abacogroup.lau.core.impl.CountryServiceTestSources#test_searchByI18nName")
	void test_searchByI18nName(String ignoredTitle, CountrySearchReq request, List<Tuple> results) {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("insert_countries_with_names");
			execSqlFiles(CountryServiceImplTest.class, initScripts, Map.of("test_tenant", TENANT));

			List<CountryRes> list = this.service.searchByI18nName(reqContext, request);

			assertThat(list).extracting(CountryRes::getCode, CountryRes::getI18nName)
					.containsExactlyInAnyOrderElementsOf(results);

			h.rollback();
		});
	}

}
