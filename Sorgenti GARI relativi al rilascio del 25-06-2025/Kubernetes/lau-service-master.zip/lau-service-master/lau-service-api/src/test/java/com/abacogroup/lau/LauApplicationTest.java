package com.abacogroup.lau;

import static org.junit.jupiter.api.Assertions.fail;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.TimeoutException;

import org.apache.commons.io.FileUtils;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.generic.GenericType;
import org.jdbi.v3.core.statement.Slf4JSqlLogger;
import org.mockito.Mockito;

import com.abacogroup.bundles.initializer.InitService;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.listener.RabbitListener;
import com.abacogroup.bundles.listener.configdata.ConfigDataConsumer;
import com.abacogroup.bundles.listener.configdata.ConfigDataLogProducer;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;

import io.dropwizard.auth.AuthFilter;
import io.dropwizard.auth.PolymorphicAuthDynamicFeature;
import io.dropwizard.auth.PolymorphicAuthValueFactoryProvider;
import io.dropwizard.auth.basic.BasicCredentialAuthFilter;
import io.dropwizard.auth.chained.ChainedAuthFilter;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.ManagedDataSource;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import liquibase.Liquibase;
import liquibase.database.jvm.JdbcConnection;
import liquibase.resource.ClassLoaderResourceAccessor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LauApplicationTest extends LauApplication {

	/**
	 * props arbitrarie da usare qui in conf
	 */
	private static Properties testProperties;
	private Jdbi jdbi;

	private Map<Class, Object> services = new HashMap<>();

	public static ObjectMapper getObjectMapper() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		//brutto, ma consente di accentrare la configurazione senza snaturare application
		new LauApplication().configureObjectMapper(mapper);
		return mapper;
	}

	/**
	 * le migrazioni devono essere eseguite DOPO JDBI e prima dell'init dei servizi
	 */
	public static void execMigrations(
			LauConfiguration configuration, Environment environment) {

		boolean exeMigrations = Boolean.parseBoolean(
				Optional.ofNullable(testProperties)
						.map(p -> p.getProperty("execMigrations", "true"))
						.orElse("true"));

		if (!exeMigrations) {
			log.info("AUTOMATIC MIGRATION TURNED OFF... check loadTestProperties() for details");
			return;
		}
		System.out.println("-------- EXEC_MIGRATIONS -----------");
		ManagedDataSource managedDataSource = configuration.getDatabase()
				.build(environment.metrics(), "migrations-cp-test");

		try (Connection connection = managedDataSource.getConnection()) {
			Liquibase migrator = new Liquibase("migrations-test.xml", new ClassLoaderResourceAccessor(),
					new JdbcConnection(connection));
			migrator.update("");
		} catch (Throwable t) {
			t.printStackTrace();
			fail();
		}
		System.out.println("-------- EXEC_MIGRATIONS_END -----------");
	}

	private static boolean isExecMigrations() {
		return Boolean.parseBoolean(Optional.ofNullable(testProperties)
				.map(p -> p.getProperty("execMigrations", "true"))
				.orElse("true"));
	}

	public Map<Class, Object> getServices() {
		return services;
	}

	public Jdbi getJdbi() {
		return jdbi;
	}

	@Override
	public void run(LauConfiguration configuration, Environment environment) throws Exception {
		this.loadTestProperties();
		super.run(configuration, environment);
	}

	/**
	 * Sono properties che non ha senso esistano su PartyRegistryConfiguration
	 */
	private void loadTestProperties() {
		String filename = "src/test/resources/test.properties";
		log.debug("loading extra test properties from {}", filename);
		try (InputStream input = new FileInputStream(filename)) {
			Properties prop = new Properties();
			prop.load(input);
			testProperties = prop;
		} catch (IOException ex) {
			log.warn("{} not found", filename);
		}
	}

	@Override
	protected Jdbi jdbi(LauConfiguration configuration, Environment environment) {
		Jdbi jdbi = super.jdbi(configuration, environment);
		jdbi.setSqlLogger(new Slf4JSqlLogger());
		this.jdbi = jdbi;
		execMigrations(configuration, environment);
		return jdbi;
	}

	@Override
	protected <T> T register(T service) {
		if (isBetterToMock(service)) {
			service = (T) Mockito.mock(service.getClass());
		}

		services.put(service.getClass(), service);
		return super.register(service);
	}

	private <T> boolean isBetterToMock(T service) {
		return (
				service instanceof ConfigDataLogProducer
						|| service instanceof BundleInitServiceProducer
		) && !isInitRabbit();
	}

	@Override
	protected void initOpenApi(JerseyEnvironment jersey) {
		log.info("OPEN-API DISABELD");
	}

	@Override
	protected void initAuth(Environment environment, Sso2Client sso2Cli) {
		List<AuthFilter<?, ? extends User>> filters = new ArrayList<>();
		filters.add(new BasicCredentialAuthFilter.Builder<User>()
				.setAuthenticator(credentials -> Optional.of(new User(credentials.getUsername(), "master")))
				.setAuthorizer((principal, role, x) -> {
					return true;
				})
				.setRealm("GUEST authenticator")
				.buildAuthFilter());

		ChainedAuthFilter usersFilter = new ChainedAuthFilter(filters);

		final PolymorphicAuthDynamicFeature<? extends User> feature = new PolymorphicAuthDynamicFeature<>(
				ImmutableMap.of(User.class, usersFilter));

		PolymorphicAuthValueFactoryProvider.Binder<? extends User> binder = new PolymorphicAuthValueFactoryProvider.Binder<>(
				ImmutableSet.of(User.class));

		environment.jersey().register(feature);
		environment.jersey().register(binder);
		//*/
	}

	@Override
	protected ConfigDataLogProducer configDataLogProducerBean(ObjectMapper objectMapper, com.rabbitmq.client.Connection rabbitmqConnection) {
		if (!isInitRabbit()) {
			return Mockito.mock(ConfigDataLogProducer.class);
		}
		return super.configDataLogProducerBean(objectMapper, rabbitmqConnection);
	}

	@Override
	protected void startRabbitConsumerAndProducers(InitService initService, RabbitListener rabbitListener) throws Exception {
		if (!isInitRabbit()) {
			System.out.println("startup producers and consumers OFF");
		} else {
			super.startRabbitConsumerAndProducers(initService, rabbitListener);
		}
	}

	@Override
	@SneakyThrows
	@SuppressWarnings("all")
	protected void afterServicesUp() {
		if (!isExecMigrations()) {
			return;
		}
		Long start = System.currentTimeMillis();
		Map<String, String> checksums = jdbi.withHandle(handle -> handle.createQuery("select changeset, md5 from bnd_registry")
				.setMapKeyColumn("changeset")
				.setMapValueColumn("md5")
				.collectInto(new GenericType<>() {
				}));

		String json = Files.readString(Path.of("src/test/resources/lau-registry-bundle.zip.json"));
		Map<String, String> expectedChecksums = new ObjectMapper().readValue(json, Map.class);

		if (!checksums.isEmpty() && !expectedChecksums.equals(checksums)) {

			throw new IllegalArgumentException("ci sono divergenze tra i checksum presenti sul db e quelli expected!");
		}
		Path zipPath = Path.of("src/test/resources/lau-registry-bundle.zip");
		if (checksums.isEmpty()) {
			try {
				byte[] payload = FileUtils.readFileToByteArray(zipPath.toFile());
				ConfigDataConsumer configDataManager = (ConfigDataConsumer) services.get(ConfigDataConsumer.class);
				configDataManager.process(payload, UUID.randomUUID().toString(), Map.of("tenant", "*"));
			} catch (Throwable t) {
				t.printStackTrace();
				fail();
			}
		} else {
			log.info("the test bundle install was skipped");
		}

		log.info(String.format("checkSum check in %s millis", System.currentTimeMillis() - start));
	}

	@Override
	protected com.rabbitmq.client.Connection createRabbitmqConnection(LauConfiguration configuration) throws IOException, TimeoutException {
		if (isInitRabbit()) {
			return super.createRabbitmqConnection(configuration);
		} else {
			log.info("RABBIT CONNECTION DISABLED");
			return null;
		}
	}

	private boolean isInitRabbit() {
		return Boolean.parseBoolean(
				Optional.ofNullable(testProperties)
						.map(p -> p.getProperty("initRabbit", "false"))
						.orElse("false"));
	}
}
