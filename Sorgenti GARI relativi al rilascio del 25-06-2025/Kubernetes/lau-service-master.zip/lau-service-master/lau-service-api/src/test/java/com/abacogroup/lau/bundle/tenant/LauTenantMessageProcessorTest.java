package com.abacogroup.lau.bundle.tenant;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThan;

import com.abacogroup.bundles.Constants;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.lau.db.JdbiTest;
import com.abacogroup.lau.db.dao.CountryDAO;
import com.abacogroup.lau.db.dao.DistrictDAO;
import com.abacogroup.lau.db.dao.MunicipalityDAO;
import com.abacogroup.lau.db.dao.RegionDAO;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import org.hamcrest.CoreMatchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class LauTenantMessageProcessorTest extends JdbiTest {

	private final LauTenantMessageProcessor processor = getService(LauTenantMessageProcessor.class);

	@Test
	public void testOnMessage() {
		CountryDAO countryDAO = getDAO(CountryDAO.class);
		RegionDAO regionDAO = getDAO(RegionDAO.class);
		DistrictDAO districtDAO = getDAO(DistrictDAO.class);
		MunicipalityDAO municipalityDAO = getDAO(MunicipalityDAO.class);

		long countryCount = countryDAO.countAll(Constants.ALL_TENANTS);
		long regionCount = regionDAO.countAll(Constants.ALL_TENANTS);
		long districtCount = districtDAO.countAll(Constants.ALL_TENANTS);
		long municipalityCount = municipalityDAO.countAll(Constants.ALL_TENANTS);
		assertThat(countryCount, greaterThan(0L));
		assertThat(regionCount, greaterThan(0L));
		assertThat(districtCount, greaterThan(0L));
		assertThat(municipalityCount, greaterThan(0L));

		getJdbi().useHandle(handle -> {
			handle.begin();
			String newTenant = "tnt";

			processor.onMessage(new TenantMessage()
					.setTenantId(newTenant));

			assertThat(countryDAO.countAll(newTenant), CoreMatchers.is(countryCount));
			assertThat(regionDAO.countAll(newTenant), CoreMatchers.is(regionCount));
			assertThat(districtDAO.countAll(newTenant), CoreMatchers.is(districtCount));
			assertThat(municipalityDAO.countAll(newTenant), CoreMatchers.is(municipalityCount));
			handle.rollback();
		});
	}
}
