package com.abacogroup.lau.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lau.api.CountryRes;
import com.abacogroup.lau.api.DistrictDataRes;
import com.abacogroup.lau.api.DistrictRes;
import com.abacogroup.lau.api.RegionRes;
import com.abacogroup.lau.api.v1.DistrictDataResponseV1;
import com.abacogroup.lau.api.v1.DistrictResponseV1;
import com.abacogroup.lau.api.v1.req.DistrictSearchRequestV1;
import com.abacogroup.lau.core.DistrictService;
import com.abacogroup.lau.core.DistrictV1Service;
import com.abacogroup.lau.resources.req.ActiveEnum;
import com.abacogroup.lau.resources.req.DistrictSearchReq;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class DistrictV1ServiceImplTest {

	private DistrictService districtService = mock(DistrictService.class);

	private DistrictV1Service districtV1Service = new DistrictV1ServiceImpl(districtService);

	// ----- searchCountries -----
	@Test
	void test_searchCountries_ok() {
		String tenant = "test_tenant";
		String username = "user1";
		CountryRes ita = CountryRes.builder().setActive(true).setCode("ITA").setI18nName("Italia").setTenantId(tenant).build();
		RegionRes sar = RegionRes.builder().setActive(true).setCode("ITA_02").setShortDescr("sar").setI18nName("Sardegna")
				.setTenantId(tenant).setCountryCode(ita.getCode()).setCountry(ita).build();
		DistrictRes cag = DistrictRes.builder().setActive(true).setCode("ITA_02_001").setShortDescr("CA").setI18nName("Cagliari")
				.setTenantId(tenant).setRegionCode(sar.getCode()).setRegion(sar).build();
		DistrictRes sus = DistrictRes.builder().setActive(true).setCode("ITA_02_002").setShortDescr("SU").setI18nName("Sud Sardegna")
				.setTenantId(tenant).setRegionCode(sar.getCode()).setRegion(sar).build();
		ReqContext reqContext = new ReqContext(tenant, username);
		DistrictSearchRequestV1 searchRequest = new DistrictSearchRequestV1()
				.setActive(ActiveEnum.all)
				.setCode("III_11_111")
				.setI18nName("Iii")
				.setRegionCode("III_11")
				.setCountryCode("III");
		given(districtService.searchDistricts(any(), any(), any()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(cag, sus), "11"));

		InfiniteListResults<DistrictResponseV1> results = districtV1Service.searchDistricts(reqContext,
				searchRequest, null);

		assertThat(results).isNotNull()
				.extracting(InfiniteListResults::getRecords)
				.asList().hasSize(2)
				.usingRecursiveFieldByFieldElementComparator()
				.containsExactlyInAnyOrder(cag, sus);
		ArgumentCaptor<DistrictSearchReq> searchReqCaptor = ArgumentCaptor.forClass(DistrictSearchReq.class);
		verify(districtService).searchDistricts(same(reqContext), searchReqCaptor.capture(), isNull());
		assertThat(searchReqCaptor.getValue())
				.usingRecursiveComparison()
				.isEqualTo(searchRequest);

	}

	// ----- searchByI18nName -----
	@Test
	void test_searchByI18nName_ok() {
		String tenant = "test_tenant";
		String username = "user1";
		DistrictDataRes cag = DistrictDataRes.builder().setActive(true).setCode("ITA_02_001").setShortDescr("CA").setI18nName("Cagliari")
				.setTenantId(tenant).setRegionCode("ITA_02").build();
		DistrictDataRes sus = DistrictDataRes.builder().setActive(true).setCode("ITA_02_002").setShortDescr("SU").setI18nName("Sud Sardegna")
				.setTenantId(tenant).setRegionCode("ITA_02").build();
		ReqContext reqContext = new ReqContext(tenant, username);
		DistrictSearchRequestV1 searchRequest = new DistrictSearchRequestV1()
				.setActive(ActiveEnum.all)
				.setCode("III_11_111")
				.setI18nName("Iii")
				.setRegionCode("III_11")
				.setCountryCode("III");
		given(districtService.searchByI18nName(any(), any()))
				.willReturn(List.of(cag, sus));

		List<DistrictDataResponseV1> results = districtV1Service.searchByI18nName(reqContext, searchRequest);

		assertThat(results).isNotNull()
				.asList().hasSize(2)
				.usingRecursiveFieldByFieldElementComparator()
				.containsExactlyInAnyOrder(cag, sus);
		ArgumentCaptor<DistrictSearchReq> searchReqCaptor = ArgumentCaptor.forClass(DistrictSearchReq.class);
		verify(districtService).searchByI18nName(same(reqContext), searchReqCaptor.capture());
		assertThat(searchReqCaptor.getValue())
				.usingRecursiveComparison()
				.isEqualTo(searchRequest);
	}

	// ----- getDistrictByCode -----
	@Test
	void test_getDistrictByCode_ok() {
		String tenant = "test_tenant";
		String username = "user1";
		CountryRes ita = CountryRes.builder().setActive(true).setCode("ITA").setI18nName("Italia").setTenantId(tenant).build();
		RegionRes sar = RegionRes.builder().setActive(true).setCode("ITA_02").setShortDescr("sar").setI18nName("Sardegna")
				.setTenantId(tenant).setCountryCode(ita.getCode()).setCountry(ita).build();
		DistrictRes cag = DistrictRes.builder().setActive(true).setCode("ITA_02_001").setShortDescr("CA").setI18nName("Cagliari")
				.setTenantId(tenant).setRegionCode(sar.getCode()).setRegion(sar).build();
		ReqContext reqContext = new ReqContext(tenant, username);
		given(districtService.getDistrictByCode(any(), any())).willReturn(Optional.of(cag));

		Optional<DistrictResponseV1> result = districtV1Service.getDistrictByCode(reqContext, "ITA_02_001");

		assertThat(result).isPresent().get()
				.usingRecursiveComparison()
				.isEqualTo(cag);
		verify(districtService).getDistrictByCode(same(reqContext), eq("ITA_02_001"));
	}

}
