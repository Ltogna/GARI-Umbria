package com.abacogroup.lau.resources.publicapis;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lau.LauTestConstants;
import com.abacogroup.lau.api.v1.DistrictDataResponseV1;
import com.abacogroup.lau.api.v1.DistrictResponseV1;
import com.abacogroup.lau.api.v1.req.DistrictSearchRequestV1;
import com.abacogroup.lau.core.impl.DistrictV1ServiceImpl;
import com.abacogroup.lau.resources.WebCliHelper;
import com.abacogroup.lau.resources.req.ActiveEnum;
import com.abacogroup.lau.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class DistrictPublicResourceTest {

	public static final String BASE_PATH = LauTestConstants.MASTER_PUB_PATH + "/districts";
	private final DistrictV1ServiceImpl districtService = Mockito.mock(DistrictV1ServiceImpl.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new DistrictPublicResource(districtService));

	private final ObjectMapper mapper = new ObjectMapper();

	@Test
	@SuppressWarnings("unchecked")
	void test_search_byCode() {
		String code = "ITA_20_001";
		DistrictSearchRequestV1 searchParams = new DistrictSearchRequestV1()
				.setCode(code)
				.setActive(ActiveEnum.all)
				.setI18nName("IIIII")
				.setRegionCode("ITA_20")
				.setCountryCode("ITA");
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);
		InfiniteListResults<DistrictResponseV1> expectedResults = new InfiniteListResultsImpl<>(List.of(DistrictResponseV1.builder().setCode(code).build()),
				"");
		given(districtService.searchDistricts(any(), any(), any())).willReturn(expectedResults);

		InfiniteListResults<?> response = WebCliHelper.executeGet(
				EXT, BASE_PATH, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		assertThat(response).isNotNull();
		assertThat(response.getCount()).isEqualTo(1);
		assertThat(response.map(c -> mapper.convertValue(c, DistrictResponseV1.class)))
				.extracting(InfiniteListResults::getRecords)
				.isEqualTo(expectedResults.getRecords());
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<DistrictSearchRequestV1> searchReqArgumentCaptor = ArgumentCaptor.forClass(DistrictSearchRequestV1.class);
		verify(districtService, times(1))
				.searchDistricts(reqCtxCaptor.capture(), searchReqArgumentCaptor.capture(), eq(null));
		verifyNoMoreInteractions(districtService);
		DistrictSearchRequestV1 searchRequest = searchReqArgumentCaptor.getValue();
		assertThat(searchRequest).hasNoNullFieldsOrProperties().usingRecursiveComparison().isEqualTo(searchParams);
		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId()).isEqualTo("master");
		assertThat(reqContext.getLang()).isEqualTo("en");
		assertThat(reqContext.getUsername()).isEqualTo(WebCliHelper.BASIC_USERNAME);
	}

	@Test
	@SuppressWarnings("unchecked")
	void test_search_byCountry() {
		String code = "ITA_20_001";
		DistrictSearchRequestV1 searchParams = new DistrictSearchRequestV1()
				.setActive(ActiveEnum.all)
				.setCountryCode("ITA");
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);
		InfiniteListResults<DistrictResponseV1> expectedResults = new InfiniteListResultsImpl<>(List.of(DistrictResponseV1.builder().setCode(code).build()),
				"");
		given(districtService.searchDistricts(any(), any(), any())).willReturn(expectedResults);

		List response = WebCliHelper.executeGet(
				EXT, BASE_PATH + "/names", beanMap, WebCliHelper.BASIC_CREDENTIALS, List.class);
		assertThat(response).isNotNull();
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<DistrictSearchRequestV1> searchReqArgumentCaptor = ArgumentCaptor.forClass(DistrictSearchRequestV1.class);
		verify(districtService, times(1))
				.searchByI18nName(reqCtxCaptor.capture(), searchReqArgumentCaptor.capture());
		verifyNoMoreInteractions(districtService);
		DistrictSearchRequestV1 searchRequest = searchReqArgumentCaptor.getValue();

		assertThat(searchRequest.getActive()).isEqualTo(ActiveEnum.all);
		assertThat(searchRequest.getCountryCode()).isEqualTo("ITA");
		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId()).isEqualTo("master");
		assertThat(reqContext.getLang()).isEqualTo("en");
		assertThat(reqContext.getUsername()).isEqualTo(WebCliHelper.BASIC_USERNAME);
	}

	@Test
	@SuppressWarnings("unchecked")
	void test_searchByI18nName_byCode() {
		String path = String.format("%s/%s", BASE_PATH, "names");
		String name = "Provincia di";
		String regionCode = "ITA_10";
		DistrictSearchRequestV1 searchParams = new DistrictSearchRequestV1()
				.setI18nName(name)
				.setActive(ActiveEnum.all)
				.setRegionCode(regionCode);
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);
		List<DistrictDataResponseV1> expectedResults = List.of(DistrictDataResponseV1.builder().setCode("ITA_10_001").build());
		given(districtService.searchByI18nName(any(), any())).willReturn(expectedResults);

		List response = WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, List.class);

		assertThat(response).isNotNull().hasSize(1);
		assertThat(
				response.stream()
						.map(c -> mapper.convertValue(c, DistrictDataResponseV1.class))
						.collect(Collectors.toList()))
								.isEqualTo(expectedResults);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<DistrictSearchRequestV1> searchReqArgumentCaptor = ArgumentCaptor.forClass(DistrictSearchRequestV1.class);
		verify(districtService, times(1))
				.searchByI18nName(reqCtxCaptor.capture(), searchReqArgumentCaptor.capture());
		verifyNoMoreInteractions(districtService);
		DistrictSearchRequestV1 searchRequest = searchReqArgumentCaptor.getValue();
		assertThat(searchRequest.getI18nName()).isEqualTo(name);
		assertThat(searchRequest.getRegionCode()).isEqualTo(regionCode);
		assertThat(searchRequest.getActive()).isEqualTo(ActiveEnum.all);
		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId()).isEqualTo("master");
		assertThat(reqContext.getLang()).isEqualTo("en");
		assertThat(reqContext.getUsername()).isEqualTo(WebCliHelper.BASIC_USERNAME);
	}

	@Test
	void test_getByCode() {
		String code = "ITA_20_001";
		String path = String.format("%s/%s", BASE_PATH, code);
		DistrictResponseV1 expectedDistrict = DistrictResponseV1.builder().setCode(code).build();
		given(districtService.getDistrictByCode(any(), anyString()))
				.willReturn(Optional.of(expectedDistrict));

		DistrictResponseV1 district = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, DistrictResponseV1.class);

		assertThat(district).isNotNull().isEqualTo(expectedDistrict);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(districtService, times(1)).getDistrictByCode(reqCtxCaptor.capture(), eq(code));
		verifyNoMoreInteractions(districtService);
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is("master"));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}
	
}
