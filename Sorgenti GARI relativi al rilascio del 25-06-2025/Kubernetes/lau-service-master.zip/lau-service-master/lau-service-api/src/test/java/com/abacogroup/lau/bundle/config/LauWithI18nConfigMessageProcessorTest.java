package com.abacogroup.lau.bundle.config;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.lau.api.CountryRes;
import com.abacogroup.lau.api.DistrictRes;
import com.abacogroup.lau.api.MunicipalityRes;
import com.abacogroup.lau.api.RegionRes;
import com.abacogroup.lau.core.impl.CountryServiceImpl;
import com.abacogroup.lau.core.impl.DistrictServiceImpl;
import com.abacogroup.lau.core.impl.MunicipalityServiceImpl;
import com.abacogroup.lau.core.impl.RegionServiceImpl;
import com.abacogroup.lau.db.JdbiTest;
import com.abacogroup.lau.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class LauWithI18nConfigMessageProcessorTest extends JdbiTest {

	private static String TENANT = "some_tenant";
	private static String currentUser = "some_user";

	private static final ReqContext reqContext =
			new ReqContext(TENANT, currentUser, "en");

	private final LauWithI18nConfigMessageProcessor service = getService(LauWithI18nConfigMessageProcessor.class);
	private final CountryServiceImpl countryService = getService(CountryServiceImpl.class);
	private final RegionServiceImpl regionService = getService(RegionServiceImpl.class);
	private final DistrictServiceImpl districtService = getService(DistrictServiceImpl.class);
	private final MunicipalityServiceImpl municipalityService = getService(MunicipalityServiceImpl.class);

	@Test
	void onMessage() {

		getJdbi().useTransaction(h -> {
			List<Path> paths = FileSupport.listFilesRecursive(
					Path.of("src/test/resources/com/abacogroup/lau/bundle/config/LauWithI18nConfigMessageProcessorTest"));
			ConfigDataMessage msg = new ConfigDataMessage();
			msg.setConfigFiles(paths);
			msg.setTenantId(TENANT);

			service.onMessage(msg);

			Optional<CountryRes> actualCountry = countryService.getCountryByCode(reqContext, "000");
			assertTrue(actualCountry.isPresent());
			assertThat(actualCountry.get().getTenantId(), is(TENANT));
			assertThat(actualCountry.get().getCode(), is("000"));
			assertThat(actualCountry.get().isActive(), is(true));
			assertThat(actualCountry.get().getI18nName(), is("Other"));

			actualCountry = countryService.getCountryByCode(reqContext, "ITA");
			assertTrue(actualCountry.isPresent());
			assertThat(actualCountry.get().getTenantId(), is(TENANT));
			assertThat(actualCountry.get().getCode(), is("ITA"));
			assertThat(actualCountry.get().isActive(), is(true));
			assertThat(actualCountry.get().getI18nName(), is("Italy"));

			Optional<RegionRes> actualRegion = regionService.getRegionByCode(reqContext, "ITA_05");
			assertTrue(actualRegion.isPresent());
			assertThat(actualRegion.get().getTenantId(), is(TENANT));
			assertThat(actualRegion.get().getCode(), is("ITA_05"));
			assertThat(actualRegion.get().getShortDescr(), is("05"));
			assertThat(actualRegion.get().isActive(), is(true));
			assertThat(actualRegion.get().getI18nName(), is("Veneto"));

			Optional<DistrictRes> actualDistrict = districtService.getDistrictByCode(reqContext, "ITA_05_023");
			assertTrue(actualDistrict.isPresent());
			assertThat(actualDistrict.get().getTenantId(), is(TENANT));
			assertThat(actualDistrict.get().getCode(), is("ITA_05_023"));
			assertThat(actualDistrict.get().getShortDescr(), is("VR"));
			assertThat(actualDistrict.get().isActive(), is(true));
			assertThat(actualDistrict.get().getI18nName(), is("Verona"));

			Optional<MunicipalityRes> actualMun = municipalityService.getMunicipalityByCode(reqContext, "ITA_05_023091");
			assertTrue(actualMun.isPresent());
			assertThat(actualMun.get().getTenantId(), is(TENANT));
			assertThat(actualMun.get().getCode(), is("ITA_05_023091"));
			assertThat(actualMun.get().getShortDescr(), is("L781"));
			assertThat(actualMun.get().isActive(), is(true));
			assertThat(actualMun.get().getI18nName(), is("Verona"));

			h.rollback();
		});
	}

	@Test
	void onMessageDuplicates() {

		getJdbi().useTransaction(h -> {
			List<Path> paths = FileSupport.listFilesRecursive(
					Path.of("src/test/resources/com/abacogroup/lau/bundle/config/LauWithI18nConfigMessageProcessorTest"));
			ConfigDataMessage msg = new ConfigDataMessage();
			msg.setConfigFiles(paths);
			msg.setTenantId(TENANT);

			System.out.println("###############################################################");
			System.out.println("###############################################################");
			service.onMessage(msg);
			System.out.println("###############################################################");
			System.out.println("###############################################################");
			System.out.println("###############################################################");
			System.out.println("###############################################################");
			service.onMessage(msg);
			System.out.println("###############################################################");
			System.out.println("###############################################################");

			h.rollback();
		});
	}

	private void clearBundles() {

		Jdbi jdbi = getJdbi();
		jdbi.useTransaction(handle -> {
			handle.execute("delete from lau_municipality where tenant_id = ? ", TENANT);
			handle.execute("delete from lau_district where tenant_id = ? ", TENANT);
			handle.execute("delete from lau_region where tenant_id = ? ", TENANT);
			handle.execute("delete from lau_country where tenant_id = ? ", TENANT);
			handle.execute("delete from lau_i18n_values where tenant_id = ? ", TENANT);
		});
	}
}
