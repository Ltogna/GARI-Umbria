package com.abacogroup.lau.core.impl;

import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.lau.api.RegionDataRes;
import com.abacogroup.lau.api.RegionRes;
import com.abacogroup.lau.db.JdbiTest;
import com.abacogroup.lau.db.ntt.RegionEntity;
import com.abacogroup.lau.resources.req.RegionSearchReq;
import com.abacogroup.lau.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.assertj.core.groups.Tuple;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

@ExtendWith(DropwizardExtensionsSupport.class)
class RegionServiceImplTest extends JdbiTest {

	private static final String TENANT = String.format("%s_t", RegionServiceImplTest.class.getSimpleName());

	private static final ReqContext reqContext = new ReqContext(TENANT, "delete_me", "en");
	private final RegionServiceImpl service = getService(RegionServiceImpl.class);

	@ParameterizedTest(name = "[{0}] {1}")
	@MethodSource("com.abacogroup.lau.core.impl.RegionServiceTestSources#test_search_dto")
	void test_search_dto(String ignoredTitle, RegionSearchReq request, List<Tuple> results) {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			List<RegionRes> list = this.service.searchRegions(reqContext, request, null)
					.getRecords();

			assertThat(list).extracting(RegionRes::getCode, RegionRes::getI18nName,
							r -> r.getCountry().getCode(), r -> r.getCountry().getI18nName())
					.containsExactlyInAnyOrderElementsOf(results);

			h.rollback();
		});
	}

	@Test
	void test_loadRegionByCode() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			Optional<RegionEntity> region = this.service.loadRegionByCode(TENANT, "ITA_10");

			assertThat(region).isPresent().get()
					.satisfies(c -> {
						assertThat(c.getCode()).isEqualTo("ITA_10");
					});

			h.rollback();
		});
	}

	@Test
	void test_loadRegionByCode_notFound() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			Optional<RegionEntity> region = this.service.loadRegionByCode("not_" + TENANT, "ITA_10");

			assertThat(region).isEmpty();

			h.rollback();
		});
	}

	@Test
	void test_getRegionByCode() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			Optional<RegionRes> region = this.service.getRegionByCode(reqContext, "ITA_10");

			assertThat(region).isPresent().get()
					.satisfies(r -> {
						assertThat(r.getCode()).isEqualTo("ITA_10");
						assertThat(r.isActive()).isTrue();
						assertThat(r.getI18nName()).isEqualTo("ITA_10".toLowerCase() + "_en");
						assertThat(r.getCountry()).isNotNull();
						assertThat(r.getCountry().getCode()).isEqualTo("ITA");
						assertThat(r.getCountry().isActive()).isTrue();
					});

			h.rollback();
		});
	}

	@Test
	void test_getRegionByCode_noActiveCountry() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			Optional<RegionRes> region = this.service.getRegionByCode(reqContext, "YUG_00");

			assertThat(region).isPresent().get()
					.satisfies(r -> {
						assertThat(r.getCode()).isEqualTo("YUG_00");
						assertThat(r.isActive()).isTrue();
						assertThat(r.getI18nName()).isEqualTo("YUG_00".toLowerCase() + "_en");
						assertThat(r.getCountry()).isNotNull();
						assertThat(r.getCountry().getCode()).isEqualTo("YUG");
						assertThat(r.getCountry().isActive()).isFalse();
					});

			h.rollback();
		});
	}

	@Test
	void test_getRegionByCode_notFound() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			Optional<RegionRes> region = this.service.getRegionByCode(reqContext, "NOT_EXISTING");

			assertThat(region).isEmpty();

			h.rollback();
		});
	}

	@Test
	void test_save_noI18n() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			String code = "delete_me";
			RegionRes region = service.save(reqContext, RegionRes.builder()
					.setCode(code)
					.setCountryCode("ITA")
					.setShortDescr("TT")
					.build());

			assertThat(region).isNotNull();
			assertThat(region.getCode()).isEqualTo("delete_me");
			assertThat(region.getI18nName()).isEqualTo("delete_me");
			assertThat(region.isActive()).isTrue();
			assertThat(region.getTenantId()).isEqualTo(reqContext.getTenantId());
			assertThat(region.getShortDescr()).isEqualTo("TT");
			assertThat(region.getCountry()).isNotNull();
			assertThat(region.getCountry().getCode()).isEqualTo("ITA");
			assertThat(region.getCountry().getTenantId()).isEqualTo(reqContext.getTenantId());

			h.rollback();
		});
	}

	@Test
	void test_save_noActive() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			String code = "delete_me";
			RegionRes region = service.save(reqContext, RegionRes.builder()
					.setCode(code)
					.setCountryCode("ITA")
					.setShortDescr("TT")
					.setActive(false)
					.build());

			assertThat(region).isNotNull();
			assertThat(region.getCode()).isEqualTo("delete_me");
			assertThat(region.getI18nName()).isEqualTo("delete_me");
			assertThat(region.isActive()).isFalse();
			assertThat(region.getTenantId()).isEqualTo(reqContext.getTenantId());
			assertThat(region.getShortDescr()).isEqualTo("TT");
			assertThat(region.getCountry()).isNotNull();
			assertThat(region.getCountry().getCode()).isEqualTo("ITA");
			assertThat(region.getCountry().getTenantId()).isEqualTo(reqContext.getTenantId());

			h.rollback();
		});
	}

	@ParameterizedTest(name = "[{0}] {1}")
	@MethodSource("com.abacogroup.lau.core.impl.RegionServiceTestSources#test_searchByI18nName")
	void test_searchByI18nName(String ignoredTitle, RegionSearchReq request, List<Tuple> results) {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("insert_regions_with_names");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			List<RegionDataRes> list = this.service.searchByI18nName(reqContext, request);

			assertThat(list).extracting(RegionDataRes::getCode, RegionDataRes::getI18nName, RegionDataRes::getCountryCode)
					.containsExactlyInAnyOrderElementsOf(results);

			h.rollback();
		});
	}
}
