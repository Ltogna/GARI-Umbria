package com.abacogroup.lau.core.impl;

import static org.assertj.core.api.Assertions.tuple;

import com.abacogroup.lau.resources.req.ActiveEnum;
import com.abacogroup.lau.resources.req.MunicipalitySearchReq;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.params.provider.Arguments;

class MunicipalityServiceTestSources {
	static Stream<Arguments> test_search_dto() {
		return Stream.of(
				Arguments.of("with_code", new MunicipalitySearchReq().setCode("ITA_10_003_103"), List.of(
						tuple("ITA_10_003_103", "ITA_10_003", "ITA_10", "ITA")
				)),
				Arguments.of("empty", new MunicipalitySearchReq(), List.of(
						tuple("ITA_10_003_103", "ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_10_003_104", "ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_20_001_101", "ITA_20_001", "ITA_20", "ITA"),
						tuple("USA_FL_AAA_BBB", "USA_FL_AAA", "USA_FL", "USA")
				)),
				Arguments.of("with_not_existing", new MunicipalitySearchReq().setCode("NOT_EXISTING"), List.of()),
				Arguments.of("active_all", new MunicipalitySearchReq().setActive(ActiveEnum.all), List.of(
						tuple("ITA_10_003_103", "ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_10_003_104", "ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_10_003_999", "ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_10_999_111", "ITA_10_999", "ITA_10", "ITA"),
						tuple("ITA_10_999_999", "ITA_10_999", "ITA_10", "ITA"),
						tuple("ITA_20_001_101", "ITA_20_001", "ITA_20", "ITA"),
						tuple("USA_FL_AAA_BBB", "USA_FL_AAA", "USA_FL", "USA"),
						tuple("USA_ZZ_XXX_XXX", "USA_ZZ_XXX", "USA_ZZ", "USA"),
						tuple("USA_ZZ_ZZZ_XXX", "USA_ZZ_ZZZ", "USA_ZZ", "USA"),
						tuple("USA_ZZ_ZZZ_ZZZ", "USA_ZZ_ZZZ", "USA_ZZ", "USA")
						//            tuple("YUG_00_000_000", "YUG_00_000", "YUG_00", "YUG") page 2
				)),
				Arguments.of("active_only", new MunicipalitySearchReq().setActive(ActiveEnum.only_active), List.of(
						tuple("ITA_10_003_103", "ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_10_003_104", "ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_20_001_101", "ITA_20_001", "ITA_20", "ITA"),
						tuple("USA_FL_AAA_BBB", "USA_FL_AAA", "USA_FL", "USA")
				)),
				Arguments.of("active_not", new MunicipalitySearchReq().setActive(ActiveEnum.not_active), List.of(
						tuple("ITA_10_003_999", "ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_10_999_111", "ITA_10_999", "ITA_10", "ITA"),
						tuple("ITA_10_999_999", "ITA_10_999", "ITA_10", "ITA"),
						tuple("USA_ZZ_XXX_XXX", "USA_ZZ_XXX", "USA_ZZ", "USA"),
						tuple("USA_ZZ_ZZZ_XXX", "USA_ZZ_ZZZ", "USA_ZZ", "USA"),
						tuple("USA_ZZ_ZZZ_ZZZ", "USA_ZZ_ZZZ", "USA_ZZ", "USA"),
						tuple("YUG_00_000_000", "YUG_00_000", "YUG_00", "YUG")
				)),
				Arguments.of("with_code_and_active_not",
						new MunicipalitySearchReq().setCode("ITA_10_003_103").setActive(ActiveEnum.not_active), List.of()),
				Arguments.of("with_districtCode", new MunicipalitySearchReq().setDistrictCode("ITA_10_003"), List.of(
						tuple("ITA_10_003_103", "ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_10_003_104", "ITA_10_003", "ITA_10", "ITA")
				)),
				Arguments.of("with_districtCode_and_active_all",
						new MunicipalitySearchReq().setDistrictCode("ITA_10_003").setActive(ActiveEnum.all), List.of(
								tuple("ITA_10_003_103", "ITA_10_003", "ITA_10", "ITA"),
								tuple("ITA_10_003_104", "ITA_10_003", "ITA_10", "ITA"),
								tuple("ITA_10_003_999", "ITA_10_003", "ITA_10", "ITA")
						)),
				Arguments.of("with_regionCode", new MunicipalitySearchReq().setRegionCode("USA_FL"), List.of(
						tuple("USA_FL_AAA_BBB", "USA_FL_AAA", "USA_FL", "USA")
				)),
				Arguments.of("with_regionCode_and_active_all",
						new MunicipalitySearchReq().setRegionCode("ITA_10").setActive(ActiveEnum.all), List.of(
								tuple("ITA_10_003_103", "ITA_10_003", "ITA_10", "ITA"),
								tuple("ITA_10_003_104", "ITA_10_003", "ITA_10", "ITA"),
								tuple("ITA_10_003_999", "ITA_10_003", "ITA_10", "ITA"),
								tuple("ITA_10_999_111", "ITA_10_999", "ITA_10", "ITA"),
								tuple("ITA_10_999_999", "ITA_10_999", "ITA_10", "ITA")
						)),
				Arguments.of("with_countryCode", new MunicipalitySearchReq().setCountryCode("ITA"), List.of(
						tuple("ITA_10_003_103", "ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_10_003_104", "ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_20_001_101", "ITA_20_001", "ITA_20", "ITA")
				)),
				Arguments.of("with_countryCode_and_active_all",
						new MunicipalitySearchReq().setCountryCode("USA").setActive(ActiveEnum.all), List.of(
								tuple("USA_FL_AAA_BBB", "USA_FL_AAA", "USA_FL", "USA"),
								tuple("USA_ZZ_XXX_XXX", "USA_ZZ_XXX", "USA_ZZ", "USA"),
								tuple("USA_ZZ_ZZZ_XXX", "USA_ZZ_ZZZ", "USA_ZZ", "USA"),
								tuple("USA_ZZ_ZZZ_ZZZ", "USA_ZZ_ZZZ", "USA_ZZ", "USA")
						)),
				Arguments.of("with_regionCode_and_districtCode_and_countryCode",
						new MunicipalitySearchReq().setCountryCode("USA").setRegionCode("USA_ZZ")
								.setDistrictCode("USA_ZZ_ZZZ").setActive(ActiveEnum.all), List.of(
								tuple("USA_ZZ_ZZZ_XXX", "USA_ZZ_ZZZ", "USA_ZZ", "USA"),
								tuple("USA_ZZ_ZZZ_ZZZ", "USA_ZZ_ZZZ", "USA_ZZ", "USA")
						)),
				Arguments.of("free text country - active_all", new MunicipalitySearchReq().setActive(ActiveEnum.all).setCountryI18n("us"), List.of(
						tuple("USA_FL_AAA_BBB", "USA_FL_AAA", "USA_FL", "USA"),
						tuple("USA_ZZ_XXX_XXX", "USA_ZZ_XXX", "USA_ZZ", "USA"),
						tuple("USA_ZZ_ZZZ_XXX", "USA_ZZ_ZZZ", "USA_ZZ", "USA"),
						tuple("USA_ZZ_ZZZ_ZZZ", "USA_ZZ_ZZZ", "USA_ZZ", "USA")
				)),
				Arguments.of("free text region - active_all", new MunicipalitySearchReq().setActive(ActiveEnum.all).setRegionI18n("ita_1"), List.of(
						tuple("ITA_10_003_103", "ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_10_003_104", "ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_10_003_999", "ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_10_999_111", "ITA_10_999", "ITA_10", "ITA"),
						tuple("ITA_10_999_999", "ITA_10_999", "ITA_10", "ITA")
				)),
				Arguments.of("free text district - active_all", new MunicipalitySearchReq().setActive(ActiveEnum.all).setDistrictI18n("ita_10_9"), List.of(
						tuple("ITA_10_999_111", "ITA_10_999", "ITA_10", "ITA"),
						tuple("ITA_10_999_999", "ITA_10_999", "ITA_10", "ITA")
				))
				
		);
	}

	static Stream<Arguments> test_searchByI18nName() {
		return Stream.of(
				Arguments.of("empty", new MunicipalitySearchReq(), List.of(
						tuple("TEST_D6", "di 6", "TEST_D_C2"),
						tuple("TEST_D3", "d tre", "TEST_D_C1"),
						tuple("TEST_D1", "Test D1", "TEST_D_C1"),
						tuple("TEST_D2", "test d2", "TEST_D_C1"),
						tuple("TEST_D5", "TESTd5", "TEST_D_C1"),
						tuple("TEST_D7", "test d7", "TEST_D_C2")
				)),
				Arguments.of("active_all", new MunicipalitySearchReq().setActive(ActiveEnum.all), List.of(
						tuple("TEST_D6", "di 6", "TEST_D_C2"),
						tuple("TEST_D3", "d tre", "TEST_D_C1"),
						tuple("TEST_D1", "Test D1", "TEST_D_C1"),
						tuple("TEST_D2", "test d2", "TEST_D_C1"),
						tuple("TEST_D4", "test d4", "TEST_D_C1"),
						tuple("TEST_D5", "TESTd5", "TEST_D_C1"),
						tuple("TEST_D7", "test d7", "TEST_D_C2")
				)),
				Arguments.of("with_name tESt*", new MunicipalitySearchReq().setI18nName("tESt"), List.of(
						tuple("TEST_D1", "Test D1", "TEST_D_C1"),
						tuple("TEST_D2", "test d2", "TEST_D_C1"),
						tuple("TEST_D5", "TESTd5", "TEST_D_C1"),
						tuple("TEST_D7", "test d7", "TEST_D_C2")
				)),
				Arguments.of("with_full_name 'test d2'", new MunicipalitySearchReq().setI18nName("test d2"),
						List.of(
								tuple("TEST_D2", "test d2", "TEST_D_C1")
						)),
				Arguments.of("with_district_code", new MunicipalitySearchReq().setDistrictCode("TEST_D_C1"),
						List.of(
								tuple("TEST_D3", "d tre", "TEST_D_C1"),
								tuple("TEST_D1", "Test D1", "TEST_D_C1"),
								tuple("TEST_D2", "test d2", "TEST_D_C1"),
								tuple("TEST_D5", "TESTd5", "TEST_D_C1")
						))
		);
	}

}
