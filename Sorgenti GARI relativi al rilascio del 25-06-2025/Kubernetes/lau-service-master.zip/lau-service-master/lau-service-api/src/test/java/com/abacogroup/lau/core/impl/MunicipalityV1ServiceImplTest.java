package com.abacogroup.lau.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lau.api.CountryRes;
import com.abacogroup.lau.api.DistrictRes;
import com.abacogroup.lau.api.MunicipalityDataRes;
import com.abacogroup.lau.api.MunicipalityRes;
import com.abacogroup.lau.api.RegionRes;
import com.abacogroup.lau.api.v1.MunicipalityDataResponseV1;
import com.abacogroup.lau.api.v1.MunicipalityResponseV1;
import com.abacogroup.lau.api.v1.req.MunicipalitySearchRequestV1;
import com.abacogroup.lau.core.MunicipalityService;
import com.abacogroup.lau.core.MunicipalityV1Service;
import com.abacogroup.lau.resources.req.ActiveEnum;
import com.abacogroup.lau.resources.req.MunicipalitySearchReq;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class MunicipalityV1ServiceImplTest {

	private MunicipalityService municipalityService = mock(MunicipalityService.class);

	private MunicipalityV1Service municipalityV1Service = new MunicipalityV1ServiceImpl(municipalityService);

	// ----- searchCountries -----
	@Test
	void test_searchCountries_ok() {
		String tenant = "test_tenant";
		String username = "user1";
		CountryRes ita = CountryRes.builder().setActive(true).setCode("ITA").setI18nName("Italia").setTenantId(tenant).build();
		RegionRes sar = RegionRes.builder().setActive(true).setCode("ITA_02").setShortDescr("sar").setI18nName("Sardegna")
				.setTenantId(tenant).setCountryCode(ita.getCode()).setCountry(ita).build();
		DistrictRes cap = DistrictRes.builder().setActive(true).setCode("ITA_02_001").setShortDescr("CA").setI18nName("Cagliari")
				.setTenantId(tenant).setRegionCode(sar.getCode()).setRegion(sar).build();
		MunicipalityRes cag = MunicipalityRes.builder().setActive(true).setCode("ITA_02_001001").setShortDescr("01").setI18nName("Cagliari")
				.setTenantId(tenant).setDistrictCode(cap.getCode()).setDistrict(cap).build();
		MunicipalityRes ses = MunicipalityRes.builder().setActive(true).setCode("ITA_02_001002").setShortDescr("02").setI18nName("Sestu")
				.setTenantId(tenant).setDistrictCode(cap.getCode()).setDistrict(cap).build();
		ReqContext reqContext = new ReqContext(tenant, username);
		MunicipalitySearchRequestV1 searchRequest = new MunicipalitySearchRequestV1()
				.setActive(ActiveEnum.all)
				.setCode("III_11_111111")
				.setI18nName("Iii")
				.setDistrictCode("III_11_111")
				.setRegionCode("III_11")
				.setCountryCode("III");
		given(municipalityService.searchMunicipalities(any(), any(), any()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(cag, ses), "11"));

		InfiniteListResults<MunicipalityResponseV1> results = municipalityV1Service.searchMunicipalities(reqContext,
				searchRequest, null);

		assertThat(results).isNotNull()
				.extracting(InfiniteListResults::getRecords)
				.asList().hasSize(2)
				.usingRecursiveFieldByFieldElementComparator()
				.containsExactlyInAnyOrder(cag, ses);
		ArgumentCaptor<MunicipalitySearchReq> searchReqCaptor = ArgumentCaptor.forClass(MunicipalitySearchReq.class);
		verify(municipalityService).searchMunicipalities(same(reqContext), searchReqCaptor.capture(), isNull());
		assertThat(searchReqCaptor.getValue())
				.usingRecursiveComparison()
				.isEqualTo(searchRequest);

	}

	// ----- searchByI18nName -----
	@Test
	void test_searchByI18nName_ok() {
		String tenant = "test_tenant";
		String username = "user1";
		MunicipalityDataRes cag = MunicipalityDataRes.builder().setActive(true).setCode("ITA_02_001001").setShortDescr("01").setI18nName("Cagliari")
				.setTenantId(tenant).setDistrictCode("ITA_02_001").build();
		MunicipalityDataRes ses = MunicipalityDataRes.builder().setActive(true).setCode("ITA_02_001002").setShortDescr("02").setI18nName("Sestu")
				.setTenantId(tenant).setDistrictCode("ITA_02_001").build();
		ReqContext reqContext = new ReqContext(tenant, username);
		MunicipalitySearchRequestV1 searchRequest = new MunicipalitySearchRequestV1()
				.setActive(ActiveEnum.all)
				.setCode("III_11_111111")
				.setI18nName("Iii")
				.setDistrictCode("III_11_111")
				.setRegionCode("III_11")
				.setCountryCode("III");
		given(municipalityService.searchByI18nName(any(), any()))
				.willReturn(List.of(cag, ses));

		List<MunicipalityDataResponseV1> results = municipalityV1Service.searchByI18nName(reqContext, searchRequest);

		assertThat(results).isNotNull()
				.asList().hasSize(2)
				.usingRecursiveFieldByFieldElementComparator()
				.containsExactlyInAnyOrder(cag, ses);
		ArgumentCaptor<MunicipalitySearchReq> searchReqCaptor = ArgumentCaptor.forClass(MunicipalitySearchReq.class);
		verify(municipalityService).searchByI18nName(same(reqContext), searchReqCaptor.capture());
		assertThat(searchReqCaptor.getValue())
				.usingRecursiveComparison()
				.isEqualTo(searchRequest);
	}

	// ----- getMunicipalityByCode -----
	@Test
	void test_getMunicipalityByCode_ok() {
		String tenant = "test_tenant";
		String username = "user1";
		CountryRes ita = CountryRes.builder().setActive(true).setCode("ITA").setI18nName("Italia").setTenantId(tenant).build();
		RegionRes sar = RegionRes.builder().setActive(true).setCode("ITA_02").setShortDescr("sar").setI18nName("Sardegna")
				.setTenantId(tenant).setCountryCode(ita.getCode()).setCountry(ita).build();
		DistrictRes cap = DistrictRes.builder().setActive(true).setCode("ITA_02_001").setShortDescr("CA").setI18nName("Cagliari")
				.setTenantId(tenant).setRegionCode(sar.getCode()).setRegion(sar).build();
		MunicipalityRes cag = MunicipalityRes.builder().setActive(true).setCode("ITA_02_001001").setShortDescr("CA").setI18nName("Cagliari")
				.setTenantId(tenant).setDistrictCode(cap.getCode()).setDistrict(cap).build();
		ReqContext reqContext = new ReqContext(tenant, username);
		given(municipalityService.getMunicipalityByCode(any(), any())).willReturn(Optional.of(cag));

		Optional<MunicipalityResponseV1> result = municipalityV1Service.getMunicipalityByCode(reqContext, "ITA_02_001001");

		assertThat(result).isPresent().get()
				.usingRecursiveComparison()
				.isEqualTo(cag);
		verify(municipalityService).getMunicipalityByCode(same(reqContext), eq("ITA_02_001001"));
	}

}
