package com.abacogroup.lau.core.impl;

import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.lau.api.DistrictDataRes;
import com.abacogroup.lau.api.DistrictRes;
import com.abacogroup.lau.db.JdbiTest;
import com.abacogroup.lau.db.ntt.DistrictEntity;
import com.abacogroup.lau.resources.req.DistrictSearchReq;
import com.abacogroup.lau.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.assertj.core.groups.Tuple;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

@ExtendWith(DropwizardExtensionsSupport.class)
class DistrictServiceImplTest extends JdbiTest {

	private static final String TENANT = String.format("%s_t", DistrictServiceImplTest.class.getSimpleName());

	private static final ReqContext reqContext = new ReqContext(TENANT, "delete_me", "en");
	private final DistrictServiceImpl service = getService(DistrictServiceImpl.class);

	@ParameterizedTest(name = "[{0}] {1}")
	@MethodSource("com.abacogroup.lau.core.impl.DistrictServiceTestSources#test_search_dto")
	void test_search_dto(String ignoredTitle, DistrictSearchReq request, List<Tuple> results) {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "3_insert_districts", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			List<DistrictRes> list = this.service.searchDistricts(reqContext, request, null)
					.getRecords();

			assertThat(list).extracting(DistrictRes::getCode, d -> d.getRegion().getCode(), d -> d.getRegion().getCountry().getCode())
					.containsExactlyInAnyOrderElementsOf(results);

			h.rollback();
		});
	}

	@Test
	void test_loadDistrictByCode() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "3_insert_districts", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			Optional<DistrictEntity> district = this.service.loadDistrictByCode(TENANT, "ITA_10_003");

			assertThat(district).isPresent().get()
					.satisfies(districtEntity -> {
						assertThat(districtEntity.getCode()).isEqualTo("ITA_10_003");
						assertThat(districtEntity.getRegionCode()).isEqualTo("ITA_10");
					});

			h.rollback();
		});
	}

	@Test
	void test_loadDistrictByCode_notFound() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "3_insert_districts", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			Optional<DistrictEntity> district = this.service.loadDistrictByCode("not_" + TENANT, "ITA_10_003");

			assertThat(district).isEmpty();

			h.rollback();
		});
	}

	@Test
	void test_getDistrictByCode() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "3_insert_districts", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			Optional<DistrictRes> district = this.service.getDistrictByCode(reqContext, "ITA_10_003");

			assertThat(district).isPresent().get()
					.satisfies(d -> {
						assertThat(d.getCode()).isEqualTo("ITA_10_003");
						assertThat(d.isActive()).isTrue();
						assertThat(d.getI18nName()).isEqualTo("ITA_10_003".toLowerCase() + "_en");
						assertThat(d.getRegion()).isNotNull();
						assertThat(d.getRegion().getCode()).isEqualTo("ITA_10");
						assertThat(d.getRegion().getI18nName()).isEqualTo("ITA_10".toLowerCase() + "_en");
						assertThat(d.getRegion().isActive()).isTrue();
						assertThat(d.getRegion().getCountry()).isNotNull();
						assertThat(d.getRegion().getCountry().getCode()).isEqualTo("ITA");
						assertThat(d.getRegion().getCountry().getI18nName()).isEqualTo("ITA".toLowerCase() + "_en");
						assertThat(d.getRegion().getCountry().isActive()).isTrue();
					});

			h.rollback();
		});
	}

	@Test
	void test_getDistrictByCode_noActiveRegion() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "3_insert_districts", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			Optional<DistrictRes> district = this.service.getDistrictByCode(reqContext, "USA_ZZ_XXX");

			assertThat(district).isPresent().get()
					.satisfies(d -> {
						assertThat(d.getCode()).isEqualTo("USA_ZZ_XXX");
						assertThat(d.isActive()).isTrue();
						assertThat(d.getI18nName()).isEqualTo("USA_ZZ_XXX".toLowerCase() + "_en");
						assertThat(d.getRegion()).isNotNull();
						assertThat(d.getRegion().getCode()).isEqualTo("USA_ZZ");
						assertThat(d.getRegion().isActive()).isFalse();
						assertThat(d.getRegion().getCountry()).isNotNull();
						assertThat(d.getRegion().getCountry().getCode()).isEqualTo("USA");
						assertThat(d.getRegion().getCountry().isActive()).isTrue();
					});

			h.rollback();
		});
	}

	@Test
	void test_getDistrictByCode_notFound() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "3_insert_districts", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			Optional<DistrictRes> district = this.service.getDistrictByCode(reqContext, "NOT_EXISTING");

			assertThat(district).isEmpty();

			h.rollback();
		});
	}

	@Test
	void test_save_noI18n() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "3_insert_districts", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			String code = "delete_me";
			DistrictRes district = service.save(reqContext, DistrictRes.builder()
					.setCode(code)
					.setRegionCode("ITA_20")
					.setShortDescr("888")
					.build());

			assertThat(district).isNotNull();
			assertThat(district.getCode()).isEqualTo("delete_me");
			assertThat(district.getI18nName()).isEqualTo("delete_me");
			assertThat(district.isActive()).isTrue();
			assertThat(district.getTenantId()).isEqualTo(reqContext.getTenantId());
			assertThat(district.getShortDescr()).isEqualTo("888");
			assertThat(district.getRegion()).isNotNull();
			assertThat(district.getRegion().getCode()).isEqualTo("ITA_20");
			assertThat(district.getRegion().getTenantId()).isEqualTo(reqContext.getTenantId());
			assertThat(district.getRegion().getCountry()).isNotNull();
			assertThat(district.getRegion().getCountry().getCode()).isEqualTo("ITA");
			assertThat(district.getRegion().getCountry().getTenantId()).isEqualTo(reqContext.getTenantId());

			h.rollback();
		});
	}

	@Test
	void test_save_noActive() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "3_insert_districts", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			String code = "delete_me";
			DistrictRes district = service.save(reqContext, DistrictRes.builder()
					.setCode(code)
					.setRegionCode("ITA_20")
					.setShortDescr("777")
					.setActive(false)
					.build());

			assertThat(district).isNotNull();
			assertThat(district.getCode()).isEqualTo("delete_me");
			assertThat(district.getI18nName()).isEqualTo("delete_me");
			assertThat(district.isActive()).isFalse();
			assertThat(district.getTenantId()).isEqualTo(reqContext.getTenantId());
			assertThat(district.getShortDescr()).isEqualTo("777");
			assertThat(district.getRegion()).isNotNull();
			assertThat(district.getRegion().getCode()).isEqualTo("ITA_20");
			assertThat(district.getRegion().getTenantId()).isEqualTo(reqContext.getTenantId());
			assertThat(district.getRegion().getCountry()).isNotNull();
			assertThat(district.getRegion().getCountry().getCode()).isEqualTo("ITA");
			assertThat(district.getRegion().getCountry().getTenantId()).isEqualTo(reqContext.getTenantId());

			h.rollback();
		});
	}

	@ParameterizedTest(name = "[{0}] {1}")
	@MethodSource("com.abacogroup.lau.core.impl.DistrictServiceTestSources#test_searchByI18nName")
	void test_searchByI18nName(String ignoredTitle, DistrictSearchReq request, List<Tuple> results) {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("insert_districts_with_names");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			List<DistrictDataRes> list = this.service.searchByI18nName(reqContext, request);

			assertThat(list).extracting(DistrictDataRes::getCode, DistrictDataRes::getI18nName, DistrictDataRes::getRegionCode)
					.containsExactlyInAnyOrderElementsOf(results);

			h.rollback();
		});
	}
}
