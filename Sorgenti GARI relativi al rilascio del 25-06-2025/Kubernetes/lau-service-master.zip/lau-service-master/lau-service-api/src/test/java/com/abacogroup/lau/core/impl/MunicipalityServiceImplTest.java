package com.abacogroup.lau.core.impl;

import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.lau.api.MunicipalityDataRes;
import com.abacogroup.lau.api.MunicipalityRes;
import com.abacogroup.lau.db.JdbiTest;
import com.abacogroup.lau.db.ntt.MunicipalityEntity;
import com.abacogroup.lau.resources.req.MunicipalitySearchReq;
import com.abacogroup.lau.resources.req.ReqContext;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.assertj.core.groups.Tuple;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

@ExtendWith(DropwizardExtensionsSupport.class)
class MunicipalityServiceImplTest extends JdbiTest {

	private static final String TENANT = String.format("%s_t", MunicipalityServiceImplTest.class.getSimpleName());

	private static final ReqContext reqContext = new ReqContext(TENANT, "delete_me", "en");
	private final MunicipalityServiceImpl service = getService(MunicipalityServiceImpl.class);

	@ParameterizedTest(name = "[{0}] {1}")
	@MethodSource("com.abacogroup.lau.core.impl.MunicipalityServiceTestSources#test_search_dto")
	void test_search_dto(String ignoredTitle, MunicipalitySearchReq request, List<Tuple> results) {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "3_insert_districts", "4_insert_municiplities", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			List<MunicipalityRes> list = this.service.searchMunicipalities(reqContext, request, null)
					.getRecords();

			assertThat(list).extracting(MunicipalityRes::getCode, m -> m.getDistrict().getCode(),
							m -> m.getDistrict().getRegion().getCode(), m -> m.getDistrict().getRegion().getCountry().getCode())
					.containsExactlyInAnyOrderElementsOf(results);

			h.rollback();
		});
	}

	@Test
	void test_loadMunicipalityByCode() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "3_insert_districts", "4_insert_municiplities", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			Optional<MunicipalityEntity> municipality = this.service.loadMunicipalityByCode(TENANT, "ITA_10_003_103");

			assertThat(municipality).isPresent().get()
					.satisfies(municipalityEntity -> {
						assertThat(municipalityEntity.getCode()).isEqualTo("ITA_10_003_103");
						assertThat(municipalityEntity.getDistrictCode()).isEqualTo("ITA_10_003");
					});

			h.rollback();
		});
	}

	@Test
	void test_loadMunicipalityByCode_notFound() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "3_insert_districts", "4_insert_municiplities", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			Optional<MunicipalityEntity> municipality = this.service.loadMunicipalityByCode("not_" + TENANT, "ITA_10_003_103");

			assertThat(municipality).isEmpty();

			h.rollback();
		});
	}

	@Test
	void test_getMunicipalityByCode() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "3_insert_districts", "4_insert_municiplities", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			Optional<MunicipalityRes> municipality = this.service.getMunicipalityByCode(reqContext, "ITA_10_003_103");

			assertThat(municipality).isPresent().get()
					.satisfies(m -> {
						assertThat(m.getCode()).isEqualTo("ITA_10_003_103");
						assertThat(m.isActive()).isTrue();
						assertThat(m.getI18nName()).isEqualTo("ITA_10_003_103".toLowerCase() + "_en");
						assertThat(m.getDistrict()).isNotNull();
						assertThat(m.getDistrict().getCode()).isEqualTo("ITA_10_003");
						assertThat(m.getDistrict().getI18nName()).isEqualTo("ITA_10_003".toLowerCase() + "_en");
						assertThat(m.getDistrict().isActive()).isTrue();
						assertThat(m.getDistrict().getRegion()).isNotNull();
						assertThat(m.getDistrict().getRegion().getCode()).isEqualTo("ITA_10");
						assertThat(m.getDistrict().getRegion().getI18nName()).isEqualTo("ITA_10".toLowerCase() + "_en");
						assertThat(m.getDistrict().getRegion().isActive()).isTrue();
						assertThat(m.getDistrict().getRegion().getCountry()).isNotNull();
						assertThat(m.getDistrict().getRegion().getCountry().getCode()).isEqualTo("ITA");
						assertThat(m.getDistrict().getRegion().getCountry().getI18nName()).isEqualTo("ITA".toLowerCase() + "_en");
						assertThat(m.getDistrict().getRegion().getCountry().isActive()).isTrue();
					});

			h.rollback();
		});
	}

	@Test
	void test_getMunicipalityByCode_noActiveDistrict() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "3_insert_districts", "4_insert_municiplities", "i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			Optional<MunicipalityRes> municipality = this.service.getMunicipalityByCode(reqContext, "ITA_10_999_111");

			assertThat(municipality).isPresent().get()
					.satisfies(m -> {
						assertThat(m.getCode()).isEqualTo("ITA_10_999_111");
						assertThat(m.isActive()).isTrue();
						assertThat(m.getI18nName()).isEqualTo("ITA_10_999_111".toLowerCase() + "_en");
						assertThat(m.getDistrict()).isNotNull();
						assertThat(m.getDistrict().getCode()).isEqualTo("ITA_10_999");
						assertThat(m.getDistrict().isActive()).isFalse();
						assertThat(m.getDistrict().getRegion()).isNotNull();
						assertThat(m.getDistrict().getRegion().getCode()).isEqualTo("ITA_10");
						assertThat(m.getDistrict().getRegion().isActive()).isTrue();
						assertThat(m.getDistrict().getRegion().getCountry()).isNotNull();
						assertThat(m.getDistrict().getRegion().getCountry().getCode()).isEqualTo("ITA");
						assertThat(m.getDistrict().getRegion().getCountry().isActive()).isTrue();
					});

			h.rollback();
		});
	}

	@Test
	void test_getMunicipalityByCode_notFound() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "3_insert_districts", "4_insert_municiplities",
					"i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			Optional<MunicipalityRes> municipality = this.service.getMunicipalityByCode(reqContext, "NOT_EXISTING");

			assertThat(municipality).isEmpty();

			h.rollback();
		});
	}

	@Test
	void test_save_noI18n() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "3_insert_districts", "4_insert_municiplities",
					"i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			String code = "delete_me";
			MunicipalityRes municipality = service.save(reqContext, MunicipalityRes.builder()
					.setCode(code)
					.setDistrictCode("ITA_20_001")
					.setShortDescr("888")
					.build());

			assertThat(municipality).isNotNull();
			assertThat(municipality.getCode()).isEqualTo("delete_me");
			assertThat(municipality.getI18nName()).isEqualTo("delete_me");
			assertThat(municipality.isActive()).isTrue();
			assertThat(municipality.getTenantId()).isEqualTo(reqContext.getTenantId());
			assertThat(municipality.getShortDescr()).isEqualTo("888");
			assertThat(municipality.getDistrict()).isNotNull();
			assertThat(municipality.getDistrict().getCode()).isEqualTo("ITA_20_001");
			assertThat(municipality.getDistrict().getTenantId()).isEqualTo(reqContext.getTenantId());
			assertThat(municipality.getDistrict().getRegion()).isNotNull();
			assertThat(municipality.getDistrict().getRegion().getCode()).isEqualTo("ITA_20");
			assertThat(municipality.getDistrict().getRegion().getTenantId()).isEqualTo(reqContext.getTenantId());
			assertThat(municipality.getDistrict().getRegion().getCountry()).isNotNull();
			assertThat(municipality.getDistrict().getRegion().getCountry().getCode()).isEqualTo("ITA");
			assertThat(municipality.getDistrict().getRegion().getCountry().getTenantId()).isEqualTo(reqContext.getTenantId());

			h.rollback();
		});
	}

	@Test
	void test_save_noActive() {
		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("1_insert_countries", "2_insert_regions", "3_insert_districts", "4_insert_municiplities",
					"i18n");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			String code = "delete_me";
			MunicipalityRes municipality = service.save(reqContext, MunicipalityRes.builder()
					.setCode(code)
					.setDistrictCode("ITA_20_001")
					.setShortDescr("777")
					.setActive(false)
					.build());

			assertThat(municipality).isNotNull();
			assertThat(municipality.getCode()).isEqualTo("delete_me");
			assertThat(municipality.getI18nName()).isEqualTo("delete_me");
			assertThat(municipality.isActive()).isFalse();
			assertThat(municipality.getTenantId()).isEqualTo(reqContext.getTenantId());
			assertThat(municipality.getShortDescr()).isEqualTo("777");
			assertThat(municipality.getDistrict()).isNotNull();
			assertThat(municipality.getDistrict().getCode()).isEqualTo("ITA_20_001");
			assertThat(municipality.getDistrict().getTenantId()).isEqualTo(reqContext.getTenantId());
			assertThat(municipality.getDistrict().getRegion()).isNotNull();
			assertThat(municipality.getDistrict().getRegion().getCode()).isEqualTo("ITA_20");
			assertThat(municipality.getDistrict().getRegion().getTenantId()).isEqualTo(reqContext.getTenantId());
			assertThat(municipality.getDistrict().getRegion().getCountry()).isNotNull();
			assertThat(municipality.getDistrict().getRegion().getCountry().getCode()).isEqualTo("ITA");
			assertThat(municipality.getDistrict().getRegion().getCountry().getTenantId()).isEqualTo(reqContext.getTenantId());

			h.rollback();
		});
	}

	@ParameterizedTest(name = "[{0}] {1}")
	@MethodSource("com.abacogroup.lau.core.impl.MunicipalityServiceTestSources#test_searchByI18nName")
	void test_searchByI18nName(String ignoredTitle, MunicipalitySearchReq request, List<Tuple> results) {

		getJdbi().useTransaction(h -> {
			List<String> initScripts = List.of("insert_municipalities_with_names");
			execSqlFiles(this.getClass(), initScripts, Map.of("test_tenant", TENANT));

			List<MunicipalityDataRes> list = this.service.searchByI18nName(reqContext, request);

			assertThat(list).extracting(MunicipalityDataRes::getCode, MunicipalityDataRes::getI18nName,
							MunicipalityDataRes::getDistrictCode)
					.containsExactlyInAnyOrderElementsOf(results);

			h.rollback();
		});
	}
}
