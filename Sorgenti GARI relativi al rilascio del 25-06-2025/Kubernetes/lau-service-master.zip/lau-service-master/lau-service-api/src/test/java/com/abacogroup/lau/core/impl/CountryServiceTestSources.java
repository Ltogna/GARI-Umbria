package com.abacogroup.lau.core.impl;

import static org.assertj.core.api.Assertions.tuple;

import com.abacogroup.lau.resources.req.ActiveEnum;
import com.abacogroup.lau.resources.req.CountrySearchReq;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.params.provider.Arguments;

class CountryServiceTestSources {

	static Stream<Arguments> test_search_dto() {
		return Stream.of(
				Arguments.of("with_code", new CountrySearchReq().setCode("ITA"), List.of(
						tuple("ITA", "ita_en")
				)),
				Arguments.of("empty", new CountrySearchReq(), List.of(
						tuple("GBR", "gbr_en"),
						tuple("ITA", "ita_en"),
						tuple("USA", "usa_en")
				)),
				Arguments.of("with_not_existing", new CountrySearchReq().setCode("NOT_EXISTING"), List.of()),
				Arguments.of("active_all", new CountrySearchReq().setActive(ActiveEnum.all), List.of(
						tuple("GBR", "gbr_en"),
						tuple("ITA", "ita_en"),
						tuple("USA", "usa_en"),
						tuple("YUG", "yug_en")
				)),
				Arguments.of("active_only", new CountrySearchReq().setActive(ActiveEnum.only_active), List.of(
						tuple("GBR", "gbr_en"),
						tuple("ITA", "ita_en"),
						tuple("USA", "usa_en")
				)),
				Arguments.of("active_not", new CountrySearchReq().setActive(ActiveEnum.not_active), List.of(
						tuple("YUG", "yug_en")
				)),
				Arguments.of("with_code_and_active_not", new CountrySearchReq().setCode("ITA").setActive(ActiveEnum.not_active), List.of())
		);
	}

	static Stream<Arguments> test_searchByI18nName() {
		return Stream.of(
				Arguments.of("empty", new CountrySearchReq(), List.of(
						tuple("TEST_A3", "a tre"),
						tuple("TEST_A1", "Test A1"),
						tuple("TEST_A2", "test a2"),
						tuple("TEST_A5", "TESTa5")
				)),
				Arguments.of("active_all", new CountrySearchReq().setActive(ActiveEnum.all), List.of(
						tuple("TEST_A3", "a tre"),
						tuple("TEST_A1", "Test A1"),
						tuple("TEST_A2", "test a2"),
						tuple("TEST_A4", "test a4"),
						tuple("TEST_A5", "TESTa5")
				)),
				Arguments.of("with_name tESt*", new CountrySearchReq().setI18nName("tESt"), List.of(
						tuple("TEST_A1", "Test A1"),
						tuple("TEST_A2", "test a2"),
						tuple("TEST_A5", "TESTa5")
				)),
				Arguments.of("with_full_name 'test a2'", new CountrySearchReq().setI18nName("test a2"), List.of(
						tuple("TEST_A2", "test a2")
				))
		);
	}

}
