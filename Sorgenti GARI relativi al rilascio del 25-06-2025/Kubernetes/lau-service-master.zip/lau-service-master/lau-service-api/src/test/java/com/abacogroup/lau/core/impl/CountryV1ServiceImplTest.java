package com.abacogroup.lau.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lau.api.CountryRes;
import com.abacogroup.lau.api.v1.CountryResponseV1;
import com.abacogroup.lau.api.v1.req.CountrySearchRequestV1;
import com.abacogroup.lau.core.CountryService;
import com.abacogroup.lau.core.CountryV1Service;
import com.abacogroup.lau.resources.req.ActiveEnum;
import com.abacogroup.lau.resources.req.CountrySearchReq;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class CountryV1ServiceImplTest {

	private CountryService countryService = mock(CountryService.class);

	private CountryV1Service countryV1Service = new CountryV1ServiceImpl(countryService);

	// ----- searchCountries -----
	@Test
	void test_searchCountries_ok() {
		String tenant = "test_tenant";
		String username = "user1";
		CountryRes ita = CountryRes.builder().setActive(true).setCode("ITA").setI18nName("Italia").setTenantId(tenant).build();
		CountryRes fra = CountryRes.builder().setActive(true).setCode("FRA").setI18nName("Francia").setTenantId(tenant).build();
		ReqContext reqContext = new ReqContext(tenant, username);
		CountrySearchRequestV1 searchRequest = new CountrySearchRequestV1()
				.setActive(ActiveEnum.all)
				.setCode("III")
				.setI18nName("Iii");
		given(countryService.searchCountries(any(), any(), any()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(ita, fra), "11"));

		InfiniteListResults<CountryResponseV1> results = countryV1Service.searchCountries(reqContext,
				searchRequest, null);

		assertThat(results).isNotNull()
				.extracting(InfiniteListResults::getRecords)
				.asList().hasSize(2)
				.usingRecursiveFieldByFieldElementComparator()
				.containsExactlyInAnyOrder(fra, ita);
		ArgumentCaptor<CountrySearchReq> searchReqCaptor = ArgumentCaptor.forClass(CountrySearchReq.class);
		verify(countryService).searchCountries(same(reqContext), searchReqCaptor.capture(), isNull());
		assertThat(searchReqCaptor.getValue())
				.usingRecursiveComparison()
				.isEqualTo(searchRequest);

	}

	// ----- getCountryByCode -----
	@Test
	void test_getCountryByCode_ok() {
		String tenant = "test_tenant";
		String username = "user1";
		CountryRes ita = CountryRes.builder().setActive(true).setCode("ITA").setI18nName("Italia").setTenantId(tenant).build();
		ReqContext reqContext = new ReqContext(tenant, username);
		given(countryService.getCountryByCode(any(), any())).willReturn(Optional.of(ita));

		Optional<CountryResponseV1> result = countryV1Service.getCountryByCode(reqContext, "ITA");

		assertThat(result).isPresent().get()
				.usingRecursiveComparison()
				.isEqualTo(ita);
		verify(countryService).getCountryByCode(same(reqContext), eq("ITA"));
	}
}
