package com.abacogroup.lau.db;

import com.abacogroup.lau.LauApplicationTest;
import com.abacogroup.lau.LauConfiguration;
import io.dropwizard.testing.ResourceHelpers;
import io.dropwizard.testing.junit5.DropwizardAppExtension;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.locator.ClasspathSqlLocator;

/**
 * Abstract class per  integration test di Service e DAO layer
 * <p>
 * - applica le migrazioni in automatico (se configurato)
 * <p>
 * - espone jdbi e getDAO
 */
public class JdbiTest {

	protected static DropwizardAppExtension<LauConfiguration> EXT = new DropwizardAppExtension<>(
			LauApplicationTest.class,
			ResourceHelpers.resourceFilePath(System.getProperty("test_config_file", "test_config.yml"))
	);
	protected final LauApplicationTest app = (LauApplicationTest) EXT.getApplication();

	public static Jdbi getJdbi() {
		return ((LauApplicationTest) EXT.getApplication()).getJdbi();
	}

	/**
	 * metodo di utilità da usare in BeforeAll e AfterAll per popolare il db per un integration test
	 * <p>
	 * Esegue una lista arbitraria di file sql.
	 * <p>
	 * Per quanto non sia obbligatorio, l'implementazione impone che i file sql siano resources sotto il package corrispondente
	 * alla classe che lo sta eseguendo.
	 * <code>
	 * <pre>
	 *
	 *  {@literal @}BeforeAll
	 *   private static void beforeAll() {
	 *     List<String> initScripts = List.of("add_stuff", "add_more_stuff");
	 *     execSqlFiles(AwesomeServiceImplTest.class, initScripts);
	 *   }
	 *
	 *
	 *   </pre>
	 * </code>
	 *
	 * @param clazz
	 * @param scripts
	 */
	protected static void execSqlFiles(Class clazz, List<String> scripts) {
		execSqlFiles(clazz, scripts, new HashMap<>());
	}

	/**
	 * metodo di utilità da usare in BeforeAll e AfterAll per popolare il db per un integration test
	 * <p>
	 * Esegue una lista arbitraria di file sql.
	 * <p>
	 * Per quanto non sia obbligatorio, l'implementazione impone che i file sql siano resources sotto il package corrispondente
	 * alla classe che lo sta eseguendo.
	 * <code>
	 * <pre>
	 *
	 *  {@literal @}BeforeAll
	 *   private static void beforeAll() {
	 *     List<String> initScripts = List.of("add_stuff", "add_more_stuff");
	 *     execSqlFiles(AwesomeServiceImplTest.class, initScripts);
	 *   }
	 *
	 *
	 *   </pre>
	 * </code>
	 *
	 * @param clazz
	 * @param scripts
	 * @param args
	 */
	protected static void execSqlFiles(Class clazz, List<String> scripts, Map<String, Object> args) {
		Map<String, Object> params = new HashMap<>(Optional.ofNullable(args).orElse(new HashMap<>()));
		if (!scripts.isEmpty()) {
			String name = String.format("%s.", clazz.getName());
			getJdbi().useTransaction(handle -> {
				scripts.stream().forEach(s -> {
					String sqlFileAsString = ClasspathSqlLocator.removingComments().locate(name + s);
					Arrays.stream(sqlFileAsString.split(";"))
							.filter(StringUtils::isNotBlank)
							.forEach(str -> handle.createUpdate(str).bindMap(params).execute());
				});
			});
		}

	}

	protected <T> T getDAO(Class classDAO) {
		return (T) app.getJdbi().onDemand(classDAO);
	}

	@SuppressWarnings("unchecked")
	protected <T> T getService(Class clazz) {
		return (T) Optional
				.ofNullable(app.getServices().get(clazz))
				.orElseThrow(() -> new RuntimeException(
						String.format("Error loading %s! Did you call by interface? Implementation required", clazz.getSimpleName())));
	}

	/**
	 * Reflection util: sostituisce un field con quello passato come parametro
	 *
	 * <p>
	 * il nome del field da sostituire è dedotto in base al tipo M
	 * </p>
	 *
	 * <p>
	 * Es in un test:
	 * <code><pre>
	 * private final PartyRelationTypeService service =
	 *    getService(PartyRelationTypeServiceImpl.class); //realmente popolato
	 *
	 *  {@literal @}Test
	 *   void given_partyNotPresent_when_SaveRelation_thenError() {
	 *     PartyServiceImpl mockPartyService = Mockito.mock(PartyServiceImpl.class);
	 *     injectMock(service, mockPartyService); // sostituzione del servizio con quello mockato
	 *
	 *     given(mockPartyService.loadEntity(anyString(), anyLong()))
	 *         .willReturn(Optional.empty());
	 *    ...
	 *
	 *   </pre>
	 * </code>
	 */
	protected <T, M> void injectMock(T target, M mock) {
		try {
			Class<T> targetClazz = (Class<T>) target.getClass();
			Field field = Arrays.stream(FieldUtils.getAllFields(targetClazz))
					.filter(f -> f.getType().isAssignableFrom(mock.getClass()))
					.findFirst()
					.orElseThrow();
			FieldUtils.writeField(target, field.getName(), mock, true);
		} catch (IllegalAccessException ex) {
			throw new RuntimeException("errore in inject", ex);
		}
	}

}
