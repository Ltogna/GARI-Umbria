package com.abacogroup.lau.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

@Disabled
public class i18nJsonlWriter {

	public final String COMMA_DELIMITER = ",";
	public final Path I18N_PATH = Paths.get("src/test/resources/jsonls/i18n.jsonl");

	@Test
	void writei18n() throws IOException {
		boolean wr = true;
		boolean wd = true;
		boolean wm = true;

		Files.write(
				I18N_PATH,
				"".getBytes(),
				StandardOpenOption.TRUNCATE_EXISTING);

		List<List<String>> regions = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new FileReader("src/test/resources/csvs/Regioni.csv"))) {
			String line;
			while ((line = br.readLine()) != null) {
				String[] values = line.split(COMMA_DELIMITER);
				regions.add(Arrays.asList(values));
			}
		}
		if (wr) {
			regions.forEach(r -> {
				String l_it = "{ \"table_name\": \"lau_region\", "
						+ "\"field_name\": \"code\", "
						+ "\"i18n_value\": \"ITA_" + r.get(0) + "\", "
						+ "\"lang\": \"it\", "
						+ "\"i18n_text\": \"" + r.get(1) + "\" } \n";
				String l_en = "{ \"table_name\": \"lau_region\", "
						+ "\"field_name\": \"code\", "
						+ "\"i18n_value\": \"ITA_" + r.get(0) + "\", "
						+ "\"lang\": \"en\", "
						+ "\"i18n_text\": \"" + r.get(1) + "\" } \n";
				System.out.println(r);
				try {
					Files.write(
							I18N_PATH,
							l_it.getBytes(),
							StandardOpenOption.APPEND);
					Files.write(
							I18N_PATH,
							l_en.getBytes(),
							StandardOpenOption.APPEND);
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			});
		}

		List<List<String>> districts = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new FileReader("src/test/resources/csvs/Province.csv"))) {
			String line;
			while ((line = br.readLine()) != null) {
				String[] values = line.split(COMMA_DELIMITER);
				districts.add(Arrays.asList(values));
			}
		}
		if (wd) {
			districts.forEach(d -> {
				String l_it = "{ \"table_name\": \"lau_district\", "
						+ "\"field_name\": \"code\", "
						+ "\"i18n_value\": \"ITA_" + d.get(0) + "_" + d.get(1) + "\", "
						+ "\"lang\": \"it\", "
						+ "\"i18n_text\": \"" + d.get(2) + "\" } \n";
				String l_en = "{ \"table_name\": \"lau_district\", "
						+ "\"field_name\": \"code\", "
						+ "\"i18n_value\": \"ITA_" + d.get(0) + "_" + d.get(1) + "\", "
						+ "\"lang\": \"en\", "
						+ "\"i18n_text\": \"" + d.get(2) + "\" } \n";
				System.out.println(d);
				try {
					Files.write(
							I18N_PATH,
							l_it.getBytes(),
							StandardOpenOption.APPEND);
					Files.write(
							I18N_PATH,
							l_en.getBytes(),
							StandardOpenOption.APPEND);
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			});
		}

		List<List<String>> municipalities = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new FileReader("src/test/resources/csvs/Comuni.csv"))) {
			String line;
			while ((line = br.readLine()) != null) {
				String[] values = line.split(COMMA_DELIMITER);
				municipalities.add(Arrays.asList(values));
			}
		}
		if (wm) {
			municipalities.forEach(m -> {
				String l_it = "{ \"table_name\": \"lau_municipality\", "
						+ "\"field_name\": \"code\", "
						+ "\"i18n_value\": \"ITA_" + m.get(0) + "_" + m.get(2) + "\", "
						+ "\"lang\": \"it\", "
						+ "\"i18n_text\": \"" + m.get(3) + "\" } \n";
				String l_en = "{ \"table_name\": \"lau_municipality\", "
						+ "\"field_name\": \"code\", "
						+ "\"i18n_value\": \"ITA_" + m.get(0) + "_" + m.get(2) + "\", "
						+ "\"lang\": \"en\", "
						+ "\"i18n_text\": \"" + m.get(3) + "\" } \n";
				System.out.println(m);
				try {
					Files.write(
							I18N_PATH,
							l_it.getBytes(),
							StandardOpenOption.APPEND);
					Files.write(
							I18N_PATH,
							l_en.getBytes(),
							StandardOpenOption.APPEND);
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			});
		}
	}
}
