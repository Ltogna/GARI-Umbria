package com.abacogroup.lau.resources.publicapis;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lau.LauTestConstants;
import com.abacogroup.lau.api.v1.CountryResponseV1;
import com.abacogroup.lau.api.v1.req.CountrySearchRequestV1;
import com.abacogroup.lau.core.impl.CountryV1ServiceImpl;
import com.abacogroup.lau.resources.WebCliHelper;
import com.abacogroup.lau.resources.req.ActiveEnum;
import com.abacogroup.lau.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;

@ExtendWith(DropwizardExtensionsSupport.class)
class CountryPublicResourceTest {

	public static final String BASE_PATH = LauTestConstants.MASTER_PUB_PATH + "/countries";
	private final CountryV1ServiceImpl countryService = Mockito.mock(CountryV1ServiceImpl.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new CountryPublicResource(countryService));

	private final ObjectMapper mapper = new ObjectMapper();

	@Test
	@SuppressWarnings("unchecked")
	void test_search_byCode() {
		String code = "ITA";
		CountrySearchRequestV1 searchParams = new CountrySearchRequestV1()
				.setCode(code)
				.setActive(ActiveEnum.all)
				.setI18nName("IIIII");
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);
		InfiniteListResults<CountryResponseV1> expectedResults = new InfiniteListResultsImpl<>(List.of(CountryResponseV1.builder().setCode(code).build()), "");
		given(countryService.searchCountries(any(), any(), any())).willReturn(expectedResults);

		var response = WebCliHelper.executeGet(
				EXT, BASE_PATH, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		assertThat(response).isNotNull();
		assertThat(response.getCount()).isEqualTo(1);
		assertThat(response.map(c -> mapper.convertValue(c, CountryResponseV1.class)).getRecords())
				.isEqualTo(expectedResults.getRecords());
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<CountrySearchRequestV1> searchReqArgumentCaptor = ArgumentCaptor.forClass(CountrySearchRequestV1.class);
		verify(countryService, times(1))
				.searchCountries(reqCtxCaptor.capture(), searchReqArgumentCaptor.capture(), eq(null));
		CountrySearchRequestV1 searchRequest = searchReqArgumentCaptor.getValue();
		assertThat(searchRequest).hasNoNullFieldsOrProperties().usingRecursiveComparison().isEqualTo(searchParams);
		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId()).isEqualTo("master");
		assertThat(reqContext.getLang()).isEqualTo("en");
		assertThat(reqContext.getUsername()).isEqualTo(WebCliHelper.BASIC_USERNAME);
	}

	@Test
	@SuppressWarnings("unchecked")
	void test_searchByI18nName_byCode() {
		String code = "ITA";
		String path = String.format("%s/%s", BASE_PATH, "names");
		CountrySearchRequestV1 searchParams = new CountrySearchRequestV1().setI18nName(code).setActive(ActiveEnum.all);
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);
		List<CountryResponseV1> expectedResults = List.of(CountryResponseV1.builder().setCode(code).build());
		given(countryService.searchByI18nName(any(), any())).willReturn(expectedResults);

		List response = WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, List.class);

		assertThat(response).isNotNull().hasSize(1);
		assertThat(
				response.stream()
						.map(c -> mapper.convertValue(c, CountryResponseV1.class))
						.collect(Collectors.toList()))
								.isEqualTo(expectedResults);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<CountrySearchRequestV1> searchReqArgumentCaptor = ArgumentCaptor.forClass(CountrySearchRequestV1.class);
		verify(countryService, times(1))
				.searchByI18nName(reqCtxCaptor.capture(), searchReqArgumentCaptor.capture());
		CountrySearchRequestV1 searchRequest = searchReqArgumentCaptor.getValue();
		assertThat(searchRequest.getI18nName()).isEqualTo(code);
		assertThat(searchRequest.getActive()).isEqualTo(ActiveEnum.all);
		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId()).isEqualTo("master");
		assertThat(reqContext.getLang()).isEqualTo("en");
		assertThat(reqContext.getUsername()).isEqualTo(WebCliHelper.BASIC_USERNAME);
	}

	@Test
	void test_getByCode() {
		String code = "ITA";
		String path = String.format("%s/%s", BASE_PATH, code);
		CountryResponseV1 expectedCountry = CountryResponseV1.builder().setCode(code).build();
		given(countryService.getCountryByCode(any(), anyString()))
				.willReturn(Optional.of(expectedCountry));

		CountryResponseV1 country = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, CountryResponseV1.class);

		assertThat(country).isNotNull().isEqualTo(expectedCountry);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(countryService, times(1)).getCountryByCode(reqCtxCaptor.capture(), eq(code));
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is("master"));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}
}
