package com.abacogroup.lau;

public class Run {
    public static void main(String[] args) throws Exception {
        LauApplication.main(new String[] { "server", "lau-service-api/config.yml" });
    }
}
