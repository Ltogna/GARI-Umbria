package com.abacogroup.lau.core.impl;

import static org.assertj.core.api.Assertions.tuple;

import com.abacogroup.lau.db.JdbiTest;
import com.abacogroup.lau.resources.req.ActiveEnum;
import com.abacogroup.lau.resources.req.DistrictSearchReq;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.provider.Arguments;

@ExtendWith(DropwizardExtensionsSupport.class)
class DistrictServiceTestSources extends JdbiTest {

	static Stream<Arguments> test_search_dto() {
		return Stream.of(
				Arguments.of("with_code", new DistrictSearchReq().setCode("ITA_10_003"), List.of(
						tuple("ITA_10_003", "ITA_10", "ITA")
				)),
				Arguments.of("empty", new DistrictSearchReq(), List.of(
						tuple("ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_10_004", "ITA_10", "ITA"),
						tuple("ITA_20_001", "ITA_20", "ITA"),
						tuple("USA_FL_AAA", "USA_FL", "USA")
				)),
				Arguments.of("with_not_existing", new DistrictSearchReq().setCode("NOT_EXISTING"), List.of()),
				Arguments.of("active_all", new DistrictSearchReq().setActive(ActiveEnum.all), List.of(
						tuple("ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_10_004", "ITA_10", "ITA"),
						tuple("ITA_10_999", "ITA_10", "ITA"),
						tuple("ITA_20_001", "ITA_20", "ITA"),
						tuple("USA_FL_AAA", "USA_FL", "USA"),
						tuple("USA_ZZ_XXX", "USA_ZZ", "USA"),
						tuple("USA_ZZ_ZZZ", "USA_ZZ", "USA"),
						tuple("YUG_00_000", "YUG_00", "YUG")
				)),
				Arguments.of("active_only", new DistrictSearchReq().setActive(ActiveEnum.only_active), List.of(
						tuple("ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_10_004", "ITA_10", "ITA"),
						tuple("ITA_20_001", "ITA_20", "ITA"),
						tuple("USA_FL_AAA", "USA_FL", "USA")
				)),
				Arguments.of("active_not", new DistrictSearchReq().setActive(ActiveEnum.not_active), List.of(
						tuple("ITA_10_999", "ITA_10", "ITA"),
						tuple("USA_ZZ_XXX", "USA_ZZ", "USA"),
						tuple("USA_ZZ_ZZZ", "USA_ZZ", "USA"),
						tuple("YUG_00_000", "YUG_00", "YUG")
				)),
				Arguments.of("with_code_and_active_not", new DistrictSearchReq().setCode("ITA_10_003").setActive(ActiveEnum.not_active), List.of()),
				Arguments.of("with_regionCode", new DistrictSearchReq().setRegionCode("ITA_10"), List.of(
						tuple("ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_10_004", "ITA_10", "ITA")
				)),
				Arguments.of("with_regionCode_and_active_all", new DistrictSearchReq().setRegionCode("ITA_10").setActive(ActiveEnum.all), List.of(
						tuple("ITA_10_003", "ITA_10", "ITA"),
						tuple("ITA_10_004", "ITA_10", "ITA"),
						tuple("ITA_10_999", "ITA_10", "ITA")
				)),
				Arguments.of("with_countryCode", new DistrictSearchReq().setCountryCode("USA"), List.of(
						tuple("USA_FL_AAA", "USA_FL", "USA")
				)),
				Arguments.of("with_countryCode_and_active_all",
						new DistrictSearchReq().setCountryCode("USA").setActive(ActiveEnum.all), List.of(
								tuple("USA_FL_AAA", "USA_FL", "USA"),
								tuple("USA_ZZ_XXX", "USA_ZZ", "USA"),
								tuple("USA_ZZ_ZZZ", "USA_ZZ", "USA")
						)),
				Arguments.of("with_countryCode_and_regionCode",
						new DistrictSearchReq().setCountryCode("USA").setRegionCode("USA_ZZ").setActive(ActiveEnum.all), List.of(
								tuple("USA_ZZ_XXX", "USA_ZZ", "USA"),
								tuple("USA_ZZ_ZZZ", "USA_ZZ", "USA")
						)),
				Arguments.of("with_countryCode_and_notRelatedRegionCode",
						new DistrictSearchReq().setCountryCode("USA").setRegionCode("ITA_10").setActive(ActiveEnum.all), List.of())
		);
	}

	static Stream<Arguments> test_searchByI18nName() {
		return Stream.of(
				Arguments.of("empty", new DistrictSearchReq(), List.of(
						tuple("TEST_C6", "ci 6", "TEST_C_B2"),
						tuple("TEST_C3", "c tre", "TEST_C_B1"),
						tuple("TEST_C1", "Test C1", "TEST_C_B1"),
						tuple("TEST_C2", "test c2", "TEST_C_B1"),
						tuple("TEST_C5", "TESTc5", "TEST_C_B1"),
						tuple("TEST_C7", "test c7", "TEST_C_B2")
				)),
				Arguments.of("active_all", new DistrictSearchReq().setActive(ActiveEnum.all), List.of(
						tuple("TEST_C6", "ci 6", "TEST_C_B2"),
						tuple("TEST_C3", "c tre", "TEST_C_B1"),
						tuple("TEST_C1", "Test C1", "TEST_C_B1"),
						tuple("TEST_C2", "test c2", "TEST_C_B1"),
						tuple("TEST_C4", "test c4", "TEST_C_B1"),
						tuple("TEST_C5", "TESTc5", "TEST_C_B1"),
						tuple("TEST_C7", "test c7", "TEST_C_B2")
				)),
				Arguments.of("with_name tESt*", new DistrictSearchReq().setI18nName("tESt"), List.of(
						tuple("TEST_C1", "Test C1", "TEST_C_B1"),
						tuple("TEST_C2", "test c2", "TEST_C_B1"),
						tuple("TEST_C5", "TESTc5", "TEST_C_B1"),
						tuple("TEST_C7", "test c7", "TEST_C_B2")
				)),
				Arguments.of("with_full_name 'test c2'", new DistrictSearchReq().setI18nName("test c2"), List.of(
						tuple("TEST_C2", "test c2", "TEST_C_B1")
				)),
				Arguments.of("with_region_code", new DistrictSearchReq().setRegionCode("TEST_C_B1"), List.of(
						tuple("TEST_C3", "c tre", "TEST_C_B1"),
						tuple("TEST_C1", "Test C1", "TEST_C_B1"),
						tuple("TEST_C2", "test c2", "TEST_C_B1"),
						tuple("TEST_C5", "TESTc5", "TEST_C_B1")
				)),
				Arguments.of("with_country_code", new DistrictSearchReq()
						.setCountryCode("TEST_C_A1"), List.of(
						tuple("TEST_C6", "ci 6", "TEST_C_B2"),
						tuple("TEST_C3", "c tre", "TEST_C_B1"),
						tuple("TEST_C1", "Test C1", "TEST_C_B1"),
						tuple("TEST_C2", "test c2", "TEST_C_B1"),
						tuple("TEST_C5", "TESTc5", "TEST_C_B1"),
						tuple("TEST_C7", "test c7", "TEST_C_B2")
				))
		);
	}

}
