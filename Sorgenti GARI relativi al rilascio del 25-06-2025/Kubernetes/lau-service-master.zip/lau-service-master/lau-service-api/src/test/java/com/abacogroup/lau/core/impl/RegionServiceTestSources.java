package com.abacogroup.lau.core.impl;

import static org.assertj.core.api.Assertions.tuple;

import com.abacogroup.lau.resources.req.ActiveEnum;
import com.abacogroup.lau.resources.req.RegionSearchReq;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.params.provider.Arguments;

class RegionServiceTestSources {
	static Stream<Arguments> test_search_dto() {
		return Stream.of(
				Arguments.of("with_code", new RegionSearchReq().setCode("ITA_20"), List.of(
						tuple("ITA_20", "ITA_20".toLowerCase() + "_en", "ITA", "ITA".toLowerCase() + "_en")
				)),
				Arguments.of("empty", new RegionSearchReq(), List.of(
						tuple("ITA_10", "ITA_10".toLowerCase() + "_en", "ITA", "ITA".toLowerCase() + "_en"),
						tuple("ITA_20", "ITA_20".toLowerCase() + "_en", "ITA", "ITA".toLowerCase() + "_en"),
						tuple("USA_FL", "USA_FL".toLowerCase() + "_en", "USA", "USA".toLowerCase() + "_en")
				)),
				Arguments.of("with_not_existing", new RegionSearchReq().setCode("NOT_EXISTING"), List.of()),
				Arguments.of("active_all", new RegionSearchReq().setActive(ActiveEnum.all), List.of(
						tuple("ITA_10", "ITA_10".toLowerCase() + "_en", "ITA", "ITA".toLowerCase() + "_en"),
						tuple("ITA_20", "ITA_20".toLowerCase() + "_en", "ITA", "ITA".toLowerCase() + "_en"),
						tuple("USA_FL", "USA_FL".toLowerCase() + "_en", "USA", "USA".toLowerCase() + "_en"),
						tuple("USA_ZZ", "USA_ZZ".toLowerCase() + "_en", "USA", "USA".toLowerCase() + "_en"),
						tuple("YUG_00", "YUG_00".toLowerCase() + "_en", "YUG", "YUG".toLowerCase() + "_en")
				)),
				Arguments.of("active_only", new RegionSearchReq().setActive(ActiveEnum.only_active), List.of(
						tuple("ITA_10", "ITA_10".toLowerCase() + "_en", "ITA", "ITA".toLowerCase() + "_en"),
						tuple("ITA_20", "ITA_20".toLowerCase() + "_en", "ITA", "ITA".toLowerCase() + "_en"),
						tuple("USA_FL", "USA_FL".toLowerCase() + "_en", "USA", "USA".toLowerCase() + "_en")
				)),
				Arguments.of("active_not", new RegionSearchReq().setActive(ActiveEnum.not_active), List.of(
						tuple("USA_ZZ", "USA_ZZ".toLowerCase() + "_en", "USA", "USA".toLowerCase() + "_en"),
						tuple("YUG_00", "YUG_00".toLowerCase() + "_en", "YUG", "YUG".toLowerCase() + "_en")
				)),
				Arguments.of("with_code_and_active_not",
						new RegionSearchReq().setCode("ITA_20").setActive(ActiveEnum.not_active), List.of()),
				Arguments.of("with_countryCode", new RegionSearchReq().setCountryCode("USA"), List.of(
						tuple("USA_FL", "USA_FL".toLowerCase() + "_en", "USA", "USA".toLowerCase() + "_en")
				)),
				Arguments.of("with_countryCode_and_active_all",
						new RegionSearchReq().setCountryCode("USA").setActive(ActiveEnum.all), List.of(
								tuple("USA_FL", "USA_FL".toLowerCase() + "_en", "USA", "USA".toLowerCase() + "_en"),
								tuple("USA_ZZ", "USA_ZZ".toLowerCase() + "_en", "USA", "USA".toLowerCase() + "_en")
						))
		);
	}

	static Stream<Arguments> test_searchByI18nName() {
		return Stream.of(
				Arguments.of("empty", new RegionSearchReq(), List.of(
						tuple("TEST_B6", "bi 6", "TEST_B_A2"),
						tuple("TEST_B3", "b tre", "TEST_B_A1"),
						tuple("TEST_B1", "Test B1", "TEST_B_A1"),
						tuple("TEST_B2", "test b2", "TEST_B_A1"),
						tuple("TEST_B5", "TESTb5", "TEST_B_A1"),
						tuple("TEST_B7", "test b7", "TEST_B_A2")
				)),
				Arguments.of("active_all", new RegionSearchReq().setActive(ActiveEnum.all), List.of(
						tuple("TEST_B6", "bi 6", "TEST_B_A2"),
						tuple("TEST_B3", "b tre", "TEST_B_A1"),
						tuple("TEST_B1", "Test B1", "TEST_B_A1"),
						tuple("TEST_B2", "test b2", "TEST_B_A1"),
						tuple("TEST_B4", "test b4", "TEST_B_A1"),
						tuple("TEST_B5", "TESTb5", "TEST_B_A1"),
						tuple("TEST_B7", "test b7", "TEST_B_A2")
				)),
				Arguments.of("with_name tESt*", new RegionSearchReq().setI18nName("tESt"), List.of(
						tuple("TEST_B1", "Test B1", "TEST_B_A1"),
						tuple("TEST_B2", "test b2", "TEST_B_A1"),
						tuple("TEST_B5", "TESTb5", "TEST_B_A1"),
						tuple("TEST_B7", "test b7", "TEST_B_A2")
				)),
				Arguments.of("with_full_name 'test b2'", new RegionSearchReq().setI18nName("test b2"), List.of(
						tuple("TEST_B2", "test b2", "TEST_B_A1")
				)),
				Arguments.of("with_country_code", new RegionSearchReq().setCountryCode("TEST_B_A1"), List.of(
						tuple("TEST_B3", "b tre", "TEST_B_A1"),
						tuple("TEST_B1", "Test B1", "TEST_B_A1"),
						tuple("TEST_B2", "test b2", "TEST_B_A1"),
						tuple("TEST_B5", "TESTb5", "TEST_B_A1")
				))
		);
	}

}
