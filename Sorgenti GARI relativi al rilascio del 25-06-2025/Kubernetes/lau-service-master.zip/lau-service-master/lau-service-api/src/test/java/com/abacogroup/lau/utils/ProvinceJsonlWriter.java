package com.abacogroup.lau.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

@Disabled
public class ProvinceJsonlWriter {

	public final String COMMA_DELIMITER = ",";

	@Test
	void readRegions() throws IOException {
		List<List<String>> records = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new FileReader("src/test/resources/csvs/Province.csv"))) {
			String line;
			while ((line = br.readLine()) != null) {
				String[] values = line.split(COMMA_DELIMITER);
				records.add(Arrays.asList(values));
			}
		}
		Files.write(
				Paths.get("src/test/resources/jsonls/districts.jsonl"),
				"".getBytes(),
				StandardOpenOption.TRUNCATE_EXISTING);
		records.forEach(r -> {
			String l = "{ \"code\": \"ITA_" + r.get(0) + "_" + r.get(1) + "\", "
					+ "\"short_descr\": \"" + r.get(3) + "\", "
					+ "\"region_code\": \"ITA_" + r.get(0) + "\", "
					+ "\"active\": true } \n";
			System.out.println(r);
			try {
				Files.write(
						Paths.get("src/test/resources/jsonls/districts.jsonl"),
						l.getBytes(),
						StandardOpenOption.APPEND);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		});
	}
}
