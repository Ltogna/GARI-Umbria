package com.abacogroup.lau.core.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lau.api.CountryRes;
import com.abacogroup.lau.api.RegionDataRes;
import com.abacogroup.lau.api.RegionRes;
import com.abacogroup.lau.api.v1.RegionDataResponseV1;
import com.abacogroup.lau.api.v1.RegionResponseV1;
import com.abacogroup.lau.api.v1.req.RegionSearchRequestV1;
import com.abacogroup.lau.core.RegionService;
import com.abacogroup.lau.core.RegionV1Service;
import com.abacogroup.lau.resources.req.ActiveEnum;
import com.abacogroup.lau.resources.req.RegionSearchReq;
import com.abacogroup.lau.resources.req.ReqContext;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class RegionV1ServiceImplTest {

	private RegionService regionService = mock(RegionService.class);

	private RegionV1Service regionV1Service = new RegionV1ServiceImpl(regionService);

	// ----- searchCountries -----
	@Test
	void test_searchCountries_ok() {
		String tenant = "test_tenant";
		String username = "user1";
		CountryRes ita = CountryRes.builder().setActive(true).setCode("ITA").setI18nName("Italia").setTenantId(tenant).build();
		RegionRes sar = RegionRes.builder().setActive(true).setCode("ITA_02").setShortDescr("sar").setI18nName("Sardegna")
				.setTenantId(tenant).setCountryCode(ita.getCode()).setCountry(ita).build();
		RegionRes lom = RegionRes.builder().setActive(true).setCode("ITA_01").setShortDescr("lom").setI18nName("Lombardia")
				.setTenantId(tenant).setCountryCode(ita.getCode()).setCountry(ita).build();
		ReqContext reqContext = new ReqContext(tenant, username);
		RegionSearchRequestV1 searchRequest = new RegionSearchRequestV1()
				.setActive(ActiveEnum.all)
				.setCode("III_11")
				.setI18nName("Iii")
				.setCountryCode("III");
		given(regionService.searchRegions(any(), any(), any()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(sar, lom), "11"));

		InfiniteListResults<RegionResponseV1> results = regionV1Service.searchRegions(reqContext,
				searchRequest, null);

		assertThat(results).isNotNull()
				.extracting(InfiniteListResults::getRecords)
				.asList().hasSize(2)
				.usingRecursiveFieldByFieldElementComparator()
				.containsExactlyInAnyOrder(sar, lom);
		ArgumentCaptor<RegionSearchReq> searchReqCaptor = ArgumentCaptor.forClass(RegionSearchReq.class);
		verify(regionService).searchRegions(same(reqContext), searchReqCaptor.capture(), isNull());
		assertThat(searchReqCaptor.getValue())
				.usingRecursiveComparison()
				.isEqualTo(searchRequest);

	}

	// ----- searchByI18nName -----
	@Test
	void test_searchByI18nName_ok() {
		String tenant = "test_tenant";
		String username = "user1";
		RegionDataRes sar = RegionDataRes.builder().setActive(true).setCode("ITA_02").setShortDescr("sar").setI18nName("Sardegna")
				.setTenantId(tenant).setCountryCode("ITA").build();
		RegionDataRes lom = RegionDataRes.builder().setActive(true).setCode("ITA_01").setShortDescr("lom").setI18nName("Lombardia")
				.setTenantId(tenant).setCountryCode("ITA").build();
		ReqContext reqContext = new ReqContext(tenant, username);
		RegionSearchRequestV1 searchRequest = new RegionSearchRequestV1()
				.setActive(ActiveEnum.all)
				.setCode("III_11")
				.setI18nName("Iii")
				.setCountryCode("III");
		given(regionService.searchByI18nName(any(), any()))
				.willReturn(List.of(sar, lom));

		List<RegionDataResponseV1> results = regionV1Service.searchByI18nName(reqContext, searchRequest);

		assertThat(results).isNotNull()
				.asList().hasSize(2)
				.usingRecursiveFieldByFieldElementComparator()
				.containsExactlyInAnyOrder(sar, lom);
		ArgumentCaptor<RegionSearchReq> searchReqCaptor = ArgumentCaptor.forClass(RegionSearchReq.class);
		verify(regionService).searchByI18nName(same(reqContext), searchReqCaptor.capture());
		assertThat(searchReqCaptor.getValue())
				.usingRecursiveComparison()
				.isEqualTo(searchRequest);
	}

	// ----- getRegionByCode -----
	@Test
	void test_getRegionByCode_ok() {
		String tenant = "test_tenant";
		String username = "user1";
		CountryRes ita = CountryRes.builder().setActive(true).setCode("ITA").setI18nName("Italia").setTenantId(tenant).build();
		RegionRes sar = RegionRes.builder().setActive(true).setCode("ITA_02").setShortDescr("sar").setI18nName("Sardegna")
				.setTenantId(tenant).setCountryCode(ita.getCode()).setCountry(ita).build();
		ReqContext reqContext = new ReqContext(tenant, username);
		given(regionService.getRegionByCode(any(), any())).willReturn(Optional.of(sar));

		Optional<RegionResponseV1> result = regionV1Service.getRegionByCode(reqContext, "ITA_01");

		assertThat(result).isPresent().get()
				.usingRecursiveComparison()
				.isEqualTo(sar);
		verify(regionService).getRegionByCode(same(reqContext), eq("ITA_01"));
	}

}
