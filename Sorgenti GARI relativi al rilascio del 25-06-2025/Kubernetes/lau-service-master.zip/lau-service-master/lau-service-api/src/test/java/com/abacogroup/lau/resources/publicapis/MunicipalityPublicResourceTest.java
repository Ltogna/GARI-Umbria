package com.abacogroup.lau.resources.publicapis;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lau.LauTestConstants;
import com.abacogroup.lau.api.v1.MunicipalityDataResponseV1;
import com.abacogroup.lau.api.v1.MunicipalityResponseV1;
import com.abacogroup.lau.api.v1.req.MunicipalitySearchRequestV1;
import com.abacogroup.lau.core.impl.MunicipalityV1ServiceImpl;
import com.abacogroup.lau.resources.WebCliHelper;
import com.abacogroup.lau.resources.req.ActiveEnum;
import com.abacogroup.lau.resources.req.ReqContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class MunicipalityPublicResourceTest {

	public static final String BASE_PATH = LauTestConstants.MASTER_PUB_PATH + "/municipalities";
	private final MunicipalityV1ServiceImpl municipalityService = Mockito.mock(MunicipalityV1ServiceImpl.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new MunicipalityPublicResource(municipalityService));

	private final ObjectMapper mapper = new ObjectMapper();

	@Test
	@SuppressWarnings("unchecked")
	void test_search_byCode() {
		String code = "ITA_20_001_101";
		MunicipalitySearchRequestV1 searchParams = new MunicipalitySearchRequestV1()
				.setCode(code)
				.setActive(ActiveEnum.all)
				.setI18nName("IIIII")
				.setDistrictCode("ITA_20_001")
				.setRegionCode("ITA_20")
				.setCountryCode("ITA")
				.setCountryI18n("CCC")
				.setRegionI18n("RRR")
				.setDistrictI18n("DDD");
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);
		InfiniteListResults<MunicipalityResponseV1> expectedResults = new InfiniteListResultsImpl<>(
				List.of(MunicipalityResponseV1.builder().setCode(code).build()), "");
		given(municipalityService.searchMunicipalities(any(), any(), any()))
				.willReturn(expectedResults);

		InfiniteListResults<?> response = WebCliHelper.executeGet(
				EXT, BASE_PATH, beanMap, WebCliHelper.BASIC_CREDENTIALS, InfiniteListResultsImpl.class);

		assertThat(response).isNotNull();
		assertThat(response.getCount()).isEqualTo(1);
		assertThat(response.map(c -> mapper.convertValue(c, MunicipalityResponseV1.class)))
				.extracting(InfiniteListResults::getRecords)
				.isEqualTo(expectedResults.getRecords());
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<MunicipalitySearchRequestV1> searchReqArgumentCaptor = ArgumentCaptor.forClass(MunicipalitySearchRequestV1.class);
		verify(municipalityService, times(1))
				.searchMunicipalities(reqCtxCaptor.capture(), searchReqArgumentCaptor.capture(), eq(null));
		verifyNoMoreInteractions(municipalityService);
		MunicipalitySearchRequestV1 searchRequest = searchReqArgumentCaptor.getValue();
		assertThat(searchRequest).hasNoNullFieldsOrProperties().usingRecursiveComparison().isEqualTo(searchParams);
		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId()).isEqualTo("master");
		assertThat(reqContext.getLang()).isEqualTo("en");
		assertThat(reqContext.getUsername()).isEqualTo(WebCliHelper.BASIC_USERNAME);
	}

	@Test
	@SuppressWarnings("unchecked")
	void test_searchByI18nName_byCode() {
		String path = String.format("%s/%s", BASE_PATH, "names");
		String name = "Segnap";
		String districtCode = "ITA_10_001";
		MunicipalitySearchRequestV1 searchParams = new MunicipalitySearchRequestV1()
				.setI18nName(name)
				.setActive(ActiveEnum.all)
				.setDistrictCode(districtCode);
		Map<String, Object> beanMap = mapper.convertValue(searchParams, Map.class);
		List<MunicipalityDataResponseV1> expectedResults = List.of(MunicipalityDataResponseV1.builder().setCode("ITA_10_001_101").build());
		given(municipalityService.searchByI18nName(any(), any())).willReturn(expectedResults);

		List response = WebCliHelper.executeGet(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, List.class);

		assertThat(response).isNotNull().hasSize(1);
		assertThat(
				response.stream()
						.map(c -> mapper.convertValue(c, MunicipalityDataResponseV1.class))
						.collect(Collectors.toList()))
								.isEqualTo(expectedResults);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		ArgumentCaptor<MunicipalitySearchRequestV1> searchReqArgumentCaptor = ArgumentCaptor.forClass(MunicipalitySearchRequestV1.class);
		verify(municipalityService, times(1))
				.searchByI18nName(reqCtxCaptor.capture(), searchReqArgumentCaptor.capture());
		verifyNoMoreInteractions(municipalityService);
		MunicipalitySearchRequestV1 searchRequest = searchReqArgumentCaptor.getValue();
		assertThat(searchRequest.getI18nName()).isEqualTo(name);
		assertThat(searchRequest.getDistrictCode()).isEqualTo(districtCode);
		assertThat(searchRequest.getActive()).isEqualTo(ActiveEnum.all);
		ReqContext reqContext = reqCtxCaptor.getValue();
		assertThat(reqContext.getTenantId()).isEqualTo("master");
		assertThat(reqContext.getLang()).isEqualTo("en");
		assertThat(reqContext.getUsername()).isEqualTo(WebCliHelper.BASIC_USERNAME);
	}

	@Test
	void test_getByCode() {
		String code = "ITA_20_001_101";
		String path = String.format("%s/%s", BASE_PATH, code);
		MunicipalityResponseV1 expectedMunicipality = MunicipalityResponseV1.builder().setCode(code).build();
		given(municipalityService.getMunicipalityByCode(any(), anyString()))
				.willReturn(Optional.of(expectedMunicipality));

		MunicipalityResponseV1 municipality = WebCliHelper.executeGet(
				EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, MunicipalityResponseV1.class);

		assertThat(municipality).isNotNull().isEqualTo(expectedMunicipality);
		ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);
		verify(municipalityService, times(1)).getMunicipalityByCode(reqCtxCaptor.capture(), eq(code));
		verifyNoMoreInteractions(municipalityService);
		ReqContext reqContext = reqCtxCaptor.getValue();
		MatcherAssert.assertThat(reqContext.getTenantId(), is("master"));
		MatcherAssert.assertThat(reqContext.getLang(), is("en"));
		MatcherAssert.assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
	}
	
}
