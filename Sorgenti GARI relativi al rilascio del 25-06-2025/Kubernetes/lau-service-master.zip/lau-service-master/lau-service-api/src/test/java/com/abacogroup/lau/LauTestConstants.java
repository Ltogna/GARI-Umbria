package com.abacogroup.lau;

public class LauTestConstants {

	public static final String TENANT_DEFAULT_CODE = "master";

	public static final String MASTER_PATH = "/master/api-priv/v1";
	public static final String MASTER_PUB_PATH = "/master/public/v1";
}
