package com.abacogroup.lau.core.cli.v1;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lau.api.v1.CountryResponseV1;
import com.abacogroup.lau.api.v1.req.CountrySearchRequestV1;
import com.abacogroup.lau.core.cli.AuthorizationStrategy;
import com.abacogroup.lau.core.cli.impl.WebCliHelper;
import com.abacogroup.lau.core.exceptions.TestException;
import com.abacogroup.lau.resources.req.ActiveEnum;
import io.dropwizard.auth.Auth;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.List;
import jakarta.validation.Valid;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.client.WebTarget;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith({ DropwizardExtensionsSupport.class })
class CountryClientV1ImplTest {

	private static final User USER = new User("test_user", "master");
	public static final String URL = "/{tenant}/public/v1/countries";

	@Path(URL)
	public static class PingResource {

		@GET
		public InfiniteListResults<CountryResponseV1> search(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@QueryParam("nextKey") String nextKey,
				@BeanParam @Valid CountrySearchRequestV1 searchReq
		) {
			if (searchReq.getCode().equals("GIVE_ME_400")) {
				throw new TestException("as requested");
			} else if (searchReq.getCode().equals("GIVE_ME_500")) {
				throw new RuntimeException("as requested");
			}
			System.out.println(searchReq);
			return new InfiniteListResultsImpl<>(List.of(
					CountryResponseV1.builder().setCode("AAA").build(),
					CountryResponseV1.builder().setCode("BBB").build(),
					CountryResponseV1.builder().setCode("CCC").build()
			), null);
		}

		@GET
		@Path("/names")
		public List<CountryResponseV1> searchByI18nName(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@QueryParam("nextKey") String nextKey,
				@BeanParam @Valid CountrySearchRequestV1 searchByNameReq
		) {
			return List.of(
					CountryResponseV1.builder().setCode("AAA").build(),
					CountryResponseV1.builder().setCode("BBB").build(),
					CountryResponseV1.builder().setCode("CCC").build()
			);
		}

		@GET
		@Path("/{code}")
		public CountryResponseV1 getByCode(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@PathParam("code") String code
		) {
			if (code.equals("ITA")) {
				return new CountryResponseV1().setCode("ITA");
			} else {
				return null;
			}
		}
	}

	private static final PingResource mockResource = spy(new PingResource());

	private static final ResourceExtension EXT = WebCliHelper.createEXT(mockResource);

	private final WebTarget reiBaseTarget = (WebTarget) EXT.target("");

	private AuthorizationStrategy authorizationStrategy;
	private CountryClientV1Impl client;

	@BeforeEach
	void setUp() {
		reset(mockResource);
		authorizationStrategy = mock(AuthorizationStrategy.class);
		client = new CountryClientV1Impl(reiBaseTarget, authorizationStrategy);
	}

	// ----- search -----
	@Test
	void test_search_ok() {
		CountrySearchRequestV1 searchRequest = new CountrySearchRequestV1()
				.setActive(ActiveEnum.all)
				.setI18nName("IIIII")
				.setCode("ITA");
		String nextKey = "next";

		InfiniteListResults<CountryResponseV1> results = client.search("it", USER, nextKey, searchRequest);

		assertThat(results).isNotNull();
		assertThat(results.getRecords()).hasSize(3)
				.containsExactly(
						CountryResponseV1.builder().setCode("AAA").build(),
						CountryResponseV1.builder().setCode("BBB").build(),
						CountryResponseV1.builder().setCode("CCC").build()
				);
		// TODO test jwt
		verify(mockResource).search(eq("it"), any(User.class), eq(USER.getTenant()), eq(nextKey), eq(searchRequest));
		verify(authorizationStrategy).getAuthorization(USER);
	}

	@Test
	void test_search_400() {
		CountrySearchRequestV1 searchRequest = new CountrySearchRequestV1()
				.setCode("GIVE_ME_400");
		String nextKey = "next";

		assertThrows(BadRequestException.class, () -> client.search("it", USER, nextKey, searchRequest));

		// TODO test jwt
		verify(mockResource).search(eq("it"), any(User.class), eq(USER.getTenant()), eq(nextKey), eq(searchRequest));
		verify(authorizationStrategy).getAuthorization(USER);
	}

	@Test
	void test_search_500() {
		CountrySearchRequestV1 searchRequest = new CountrySearchRequestV1()
				.setCode("GIVE_ME_500");
		String nextKey = "next";

		assertThrows(InternalServerErrorException.class, () -> client.search("it", USER, nextKey, searchRequest));

		// TODO test jwt
		verify(mockResource, times(2)).search(eq("it"), any(User.class), eq(USER.getTenant()),
				eq(nextKey), eq(searchRequest));
		verify(authorizationStrategy, times(2)).getAuthorization(USER);
	}

	// ----- searchByI18nName -----
	@Test
	void test_searchByI18nName_ok() {
		CountrySearchRequestV1 searchRequest = new CountrySearchRequestV1()
				.setActive(ActiveEnum.all)
				.setI18nName("Ita");
		String nextKey = "next";

		List<CountryResponseV1> results = client.searchByI18nName("it", USER, nextKey, searchRequest);

		assertThat(results).isNotNull().hasSize(3)
				.containsExactly(
						CountryResponseV1.builder().setCode("AAA").build(),
						CountryResponseV1.builder().setCode("BBB").build(),
						CountryResponseV1.builder().setCode("CCC").build()
				);
		// TODO test jwt
		verify(mockResource).searchByI18nName(eq("it"), any(User.class), eq(USER.getTenant()), eq(nextKey), eq(searchRequest));
		verify(authorizationStrategy).getAuthorization(USER);
	}

	// ----- getByCode -----
	@Test
	void test_getByCode_ok() {
		String code = "ITA";

		CountryResponseV1 country = client.getByCode("it", USER, code);

		assertThat(country).isNotNull().isEqualTo(new CountryResponseV1().setCode(code));
		// TODO test jwt
		verify(mockResource).getByCode(eq("it"), any(User.class), eq(USER.getTenant()), eq(code));
		verify(authorizationStrategy).getAuthorization(USER);
	}

	@Test
	void test_givenNotExistingCode_getByCode_null() {
		String code = "ZZZ";

		CountryResponseV1 country = client.getByCode("it", USER, code);

		assertThat(country).isNull();
		// TODO test jwt
		verify(mockResource).getByCode(eq("it"), any(User.class), eq(USER.getTenant()), eq(code));
		verify(authorizationStrategy).getAuthorization(USER);
	}
}
