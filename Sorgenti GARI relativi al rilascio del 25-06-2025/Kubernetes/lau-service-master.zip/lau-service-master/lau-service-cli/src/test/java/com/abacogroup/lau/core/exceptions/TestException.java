package com.abacogroup.lau.core.exceptions;

public class TestException extends AbstractAppException {

	public TestException(ErrEnum code, String message) {
		super(new ErrorBody(code.name(), message));
	}

	public TestException(String msg) {
		this(ErrEnum.GENERIC, msg);
	}
	
	public enum ErrEnum {
		GENERIC
	}

	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		public String getErrorCode() {
			return code;
		}

		@Override
		public String getMessage() {
			return message;
		}
	}

}
