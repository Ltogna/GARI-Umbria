package com.abacogroup.lau.core.cli.v1;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lau.api.v1.DistrictDataResponseV1;
import com.abacogroup.lau.api.v1.DistrictResponseV1;
import com.abacogroup.lau.api.v1.req.DistrictSearchRequestV1;
import com.abacogroup.lau.core.cli.AuthorizationStrategy;
import com.abacogroup.lau.core.cli.impl.WebCliHelper;
import com.abacogroup.lau.core.exceptions.TestException;
import com.abacogroup.lau.resources.req.ActiveEnum;
import io.dropwizard.auth.Auth;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.List;
import jakarta.validation.Valid;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.client.WebTarget;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith({ DropwizardExtensionsSupport.class })
class DistrictClientV1ImplTest {

	private static final User USER = new User("test_user", "master");
	public static final String URL = "/{tenant}/public/v1/districts";

	@Path(URL)
	public static class PingResource {

		@GET
		public InfiniteListResults<DistrictResponseV1> search(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@QueryParam("nextKey") String nextKey,
				@BeanParam @Valid DistrictSearchRequestV1 searchReq
		) {
			if (searchReq.getCode().equals("GIVE_ME_400")) {
				throw new TestException("as requested");
			} else if (searchReq.getCode().equals("GIVE_ME_500")) {
				throw new RuntimeException("as requested");
			}
			return new InfiniteListResultsImpl<>(List.of(
					DistrictResponseV1.builder().setCode("AAA").build(),
					DistrictResponseV1.builder().setCode("BBB").build(),
					DistrictResponseV1.builder().setCode("CCC").build()
			), null);
		}

		@GET
		@Path("/names")
		public List<DistrictDataResponseV1> searchByI18nName(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@QueryParam("nextKey") String nextKey,
				@BeanParam @Valid DistrictSearchRequestV1 searchByNameReq
		) {
			return List.of(
					DistrictDataResponseV1.builder().setCode("AAA").build(),
					DistrictDataResponseV1.builder().setCode("BBB").build(),
					DistrictDataResponseV1.builder().setCode("CCC").build()
			);
		}

		@GET
		@Path("/{code}")
		public DistrictResponseV1 getByCode(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@PathParam("code") String code
		) {
			if (code.equals("ITA_01_001")) {
				return (DistrictResponseV1) new DistrictResponseV1().setCode(code);
			} else {
				return null;
			}
		}
	}

	private static final PingResource mockResource = spy(new PingResource());

	private static final ResourceExtension EXT = WebCliHelper.createEXT(mockResource);

	private final WebTarget reiBaseTarget = EXT.target("");

	private AuthorizationStrategy authorizationStrategy;
	private DistrictClientV1Impl client;

	@BeforeEach
	void setUp() {
		reset(mockResource);
		authorizationStrategy = mock(AuthorizationStrategy.class);
		client = new DistrictClientV1Impl(reiBaseTarget, authorizationStrategy);
	}

	// ----- search -----
	@Test
	void test_search_ok() {
		DistrictSearchRequestV1 searchRequest = new DistrictSearchRequestV1()
				.setActive(ActiveEnum.all)
				.setI18nName("IIIII")
				.setCode("ITA_01_001");
		String nextKey = "next";

		InfiniteListResults<DistrictResponseV1> results = client.search("it", USER, nextKey, searchRequest);

		assertThat(results).isNotNull();
		assertThat(results.getRecords()).hasSize(3)
				.containsExactly(
						DistrictResponseV1.builder().setCode("AAA").build(),
						DistrictResponseV1.builder().setCode("BBB").build(),
						DistrictResponseV1.builder().setCode("CCC").build()
				);
		// TODO test jwt
		verify(mockResource).search(eq("it"), any(User.class), eq(USER.getTenant()), eq(nextKey), eq(searchRequest));
		verify(authorizationStrategy).getAuthorization(USER);
	}

	@Test
	void test_search_400() {
		DistrictSearchRequestV1 searchRequest = new DistrictSearchRequestV1()
				.setActive(ActiveEnum.all)
				.setCode("GIVE_ME_400");
		String nextKey = "next";

		assertThrows(BadRequestException.class, () -> client.search("it", USER, nextKey, searchRequest));

		// TODO test jwt
		verify(mockResource).search(eq("it"), any(User.class), eq(USER.getTenant()), eq(nextKey), eq(searchRequest));
		verify(authorizationStrategy).getAuthorization(USER);
	}

	@Test
	void test_search_500() {
		DistrictSearchRequestV1 searchRequest = new DistrictSearchRequestV1()
				.setActive(ActiveEnum.all)
				.setCode("GIVE_ME_500");
		String nextKey = "next";

		assertThrows(InternalServerErrorException.class, () -> client.search("it", USER, nextKey, searchRequest));

		// TODO test jwt
		verify(mockResource, times(2)).search(eq("it"), any(User.class), eq(USER.getTenant()),
				eq(nextKey), eq(searchRequest));
		verify(authorizationStrategy, times(2)).getAuthorization(USER);
	}

	// ----- searchByI18nName -----
	@Test
	void test_searchByI18nName_ok() {
		DistrictSearchRequestV1 searchRequest = new DistrictSearchRequestV1()
				.setActive(ActiveEnum.all)
				.setRegionCode("ITA_01")
				.setI18nName("Mil");
		String nextKey = "next";

		List<DistrictDataResponseV1> results = client.searchByI18nName("it", USER, nextKey, searchRequest);

		assertThat(results).isNotNull().hasSize(3)
				.containsExactly(
						DistrictDataResponseV1.builder().setCode("AAA").build(),
						DistrictDataResponseV1.builder().setCode("BBB").build(),
						DistrictDataResponseV1.builder().setCode("CCC").build()
				);
		// TODO test jwt
		verify(mockResource).searchByI18nName(eq("it"), any(User.class), eq(USER.getTenant()), eq(nextKey), eq(searchRequest));
		verify(authorizationStrategy).getAuthorization(USER);
	}

	// ----- getByCode -----
	@Test
	void test_getByCode_ok() {
		String code = "ITA_01_001";

		DistrictResponseV1 district = client.getByCode("it", USER, code);

		assertThat(district).isNotNull().isEqualTo(new DistrictResponseV1().setCode(code));
		// TODO test jwt
		verify(mockResource).getByCode(eq("it"), any(User.class), eq(USER.getTenant()), eq(code));
		verify(authorizationStrategy).getAuthorization(USER);
	}

	@Test
	void test_givenNotExistingCode_getByCode_null() {
		String code = "ZZZ_00_000";

		DistrictResponseV1 district = client.getByCode("it", USER, code);

		assertThat(district).isNull();
		// TODO test jwt
		verify(mockResource).getByCode(eq("it"), any(User.class), eq(USER.getTenant()), eq(code));
		verify(authorizationStrategy).getAuthorization(USER);
	}
}
