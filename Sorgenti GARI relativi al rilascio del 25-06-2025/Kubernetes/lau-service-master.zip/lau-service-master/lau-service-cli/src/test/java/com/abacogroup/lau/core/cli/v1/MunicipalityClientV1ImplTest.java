package com.abacogroup.lau.core.cli.v1;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lau.api.v1.MunicipalityDataResponseV1;
import com.abacogroup.lau.api.v1.MunicipalityResponseV1;
import com.abacogroup.lau.api.v1.req.MunicipalitySearchRequestV1;
import com.abacogroup.lau.core.cli.AuthorizationStrategy;
import com.abacogroup.lau.core.cli.impl.WebCliHelper;
import com.abacogroup.lau.core.exceptions.TestException;
import com.abacogroup.lau.resources.req.ActiveEnum;
import io.dropwizard.auth.Auth;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.List;
import jakarta.validation.Valid;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.client.WebTarget;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith({ DropwizardExtensionsSupport.class })
class MunicipalityClientV1ImplTest {

	private static final User USER = new User("test_user", "master");
	public static final String URL = "/{tenant}/public/v1/municipalities";

	@Path(URL)
	public static class PingResource {

		@GET
		public InfiniteListResults<MunicipalityResponseV1> search(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@QueryParam("nextKey") String nextKey,
				@BeanParam @Valid MunicipalitySearchRequestV1 searchReq
		) {
			if (searchReq.getCode().equals("GIVE_ME_400")) {
				throw new TestException("as requested");
			} else if (searchReq.getCode().equals("GIVE_ME_500")) {
				throw new RuntimeException("as requested");
			}
			return new InfiniteListResultsImpl<>(List.of(
					MunicipalityResponseV1.builder().setCode("AAA").build(),
					MunicipalityResponseV1.builder().setCode("BBB").build(),
					MunicipalityResponseV1.builder().setCode("CCC").build()
			), null);
		}

		@GET
		@Path("/names")
		public List<MunicipalityDataResponseV1> searchByI18nName(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@QueryParam("nextKey") String nextKey,
				@BeanParam @Valid MunicipalitySearchRequestV1 searchByNameReq
		) {
			return List.of(
					MunicipalityDataResponseV1.builder().setCode("AAA").build(),
					MunicipalityDataResponseV1.builder().setCode("BBB").build(),
					MunicipalityDataResponseV1.builder().setCode("CCC").build()
			);
		}

		@GET
		@Path("/{code}")
		public MunicipalityResponseV1 getByCode(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Auth User user,
				@PathParam("tenant") String tenantId,
				@PathParam("code") String code
		) {
			if (code.equals("ITA_01_001001")) {
				return (MunicipalityResponseV1) new MunicipalityResponseV1().setCode(code);
			} else {
				return null;
			}
		}
	}

	private static final PingResource mockResource = spy(new PingResource());

	private static final ResourceExtension EXT = WebCliHelper.createEXT(mockResource);

	private final WebTarget reiBaseTarget = EXT.target("");

	private AuthorizationStrategy authorizationStrategy;
	private MunicipalityClientV1Impl client;

	@BeforeEach
	void setUp() {
		reset(mockResource);
		authorizationStrategy = mock(AuthorizationStrategy.class);
		client = new MunicipalityClientV1Impl(reiBaseTarget, authorizationStrategy);
	}

	// ----- search -----
	@Test
	void test_search_ok() {
		MunicipalitySearchRequestV1 searchRequest = new MunicipalitySearchRequestV1()
				.setCode("ITA_01_001001")
				.setActive(ActiveEnum.all)
				.setI18nName("IIIII")
				.setDistrictCode("ITA_20_001")
				.setRegionCode("ITA_20")
				.setCountryCode("ITA")
				.setCountryI18n("CCC")
				.setRegionI18n("RRR")
				.setDistrictI18n("DDD");
		String nextKey = "next";

		InfiniteListResults<MunicipalityResponseV1> results = client.search("it", USER, nextKey, searchRequest);

		assertThat(results).isNotNull();
		assertThat(results.getRecords()).hasSize(3)
				.containsExactly(
						MunicipalityResponseV1.builder().setCode("AAA").build(),
						MunicipalityResponseV1.builder().setCode("BBB").build(),
						MunicipalityResponseV1.builder().setCode("CCC").build()
				);
		// TODO test jwt
		verify(mockResource).search(eq("it"), any(User.class), eq(USER.getTenant()), eq(nextKey), eq(searchRequest));
		verify(authorizationStrategy).getAuthorization(USER);
	}

	@Test
	void test_search_400() {
		MunicipalitySearchRequestV1 searchRequest = new MunicipalitySearchRequestV1()
				.setActive(ActiveEnum.all)
				.setCode("GIVE_ME_400");
		String nextKey = "next";

		assertThrows(BadRequestException.class, () -> client.search("it", USER, nextKey, searchRequest));

		// TODO test jwt
		verify(mockResource).search(eq("it"), any(User.class), eq(USER.getTenant()), eq(nextKey), eq(searchRequest));
		verify(authorizationStrategy).getAuthorization(USER);
	}

	@Test
	void test_search_500() {
		MunicipalitySearchRequestV1 searchRequest = new MunicipalitySearchRequestV1()
				.setActive(ActiveEnum.all)
				.setCode("GIVE_ME_500");
		String nextKey = "next";

		assertThrows(InternalServerErrorException.class, () -> client.search("it", USER, nextKey, searchRequest));

		// TODO test jwt
		verify(mockResource, times(2)).search(eq("it"), any(User.class), eq(USER.getTenant()),
				eq(nextKey), eq(searchRequest));
		verify(authorizationStrategy, times(2)).getAuthorization(USER);
	}

	// ----- searchByI18nName -----
	@Test
	void test_searchByI18nName_ok() {
		MunicipalitySearchRequestV1 searchRequest = new MunicipalitySearchRequestV1()
				.setActive(ActiveEnum.all)
				.setDistrictCode("ITA_01_001")
				.setI18nName("Mil");
		String nextKey = "next";

		List<MunicipalityDataResponseV1> results = client.searchByI18nName("it", USER, nextKey, searchRequest);

		assertThat(results).isNotNull().hasSize(3)
				.containsExactly(
						MunicipalityDataResponseV1.builder().setCode("AAA").build(),
						MunicipalityDataResponseV1.builder().setCode("BBB").build(),
						MunicipalityDataResponseV1.builder().setCode("CCC").build()
				);
		// TODO test jwt
		verify(mockResource).searchByI18nName(eq("it"), any(User.class), eq(USER.getTenant()), eq(nextKey), eq(searchRequest));
		verify(authorizationStrategy).getAuthorization(USER);
	}

	// ----- getByCode -----
	@Test
	void test_getByCode_ok() {
		String code = "ITA_01_001001";

		MunicipalityResponseV1 municipality = client.getByCode("it", USER, code);

		assertThat(municipality).isNotNull().isEqualTo(new MunicipalityResponseV1().setCode(code));
		// TODO test jwt
		verify(mockResource).getByCode(eq("it"), any(User.class), eq(USER.getTenant()), eq(code));
		verify(authorizationStrategy).getAuthorization(USER);
	}

	@Test
	void test_givenNotExistingCode_getByCode_null() {
		String code = "ZZZ_00_000000";

		MunicipalityResponseV1 municipality = client.getByCode("it", USER, code);

		assertThat(municipality).isNull();
		// TODO test jwt
		verify(mockResource).getByCode(eq("it"), any(User.class), eq(USER.getTenant()), eq(code));
		verify(authorizationStrategy).getAuthorization(USER);
	}
}
