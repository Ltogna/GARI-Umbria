package com.abacogroup.lau;

import io.dropwizard.core.Configuration;


import io.dropwizard.client.JerseyClientConfiguration;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LauCliConfiguration extends Configuration {

	private boolean cors = true;

    @Valid
    @NotNull
    private JerseyClientConfiguration jerseyClient = new JerseyClientConfiguration();
	
}
