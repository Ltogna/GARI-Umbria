package com.abacogroup.lau.core.cli.v1;

import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.LauCliConfiguration;
import com.abacogroup.lau.LauCliTestApplication;
import com.abacogroup.lau.api.v1.CountryResponseV1;
import com.abacogroup.lau.api.v1.req.CountrySearchRequestV1;
import com.abacogroup.lau.resources.req.ActiveEnum;
import io.dropwizard.testing.ResourceHelpers;
import io.dropwizard.testing.junit5.DropwizardAppExtension;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import org.assertj.core.groups.Tuple;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Disabled("needs lau-service up")
@ExtendWith(DropwizardExtensionsSupport.class)
class CountryClientV1ImplIT {

	protected static DropwizardAppExtension<LauCliConfiguration> EXT = new DropwizardAppExtension<>(
			LauCliTestApplication.class,
			ResourceHelpers.resourceFilePath("test_config.yml")
	);

	private final LauCliTestApplication app = EXT.getApplication();
	private final CountryClientV1Impl countryClient = app.getService(CountryClientV1Impl.class);

	// ----- search -----
	@Test
	void test_search_ok() {
		InfiniteListResults<CountryResponseV1> results = countryClient.search("it", new User("test", "master"), null,
				new CountrySearchRequestV1());

		assertThat(results).isNotNull();
		assertThat(results.getRecords()).hasSize(3)
				.extracting(CountryResponseV1::getCode, CountryResponseV1::getI18nName)
				.containsExactlyInAnyOrder(
						Tuple.tuple("GBR", "Regno Unito"),
						Tuple.tuple("ITA", "Italia"),
						Tuple.tuple("USA", "Stati Uniti")
				);

		// javax.ws.rs.ProcessingException: org.apache.http.conn.HttpHostConnectException: Connect to localhost:10300 [localhost/127.0.0.1] failed: Connessione rifiutata (Connection refused)

		// javax.ws.rs.client.ResponseProcessingException: com.fasterxml.jackson.databind.exc.InvalidDefinitionException: Cannot construct instance of `com.abacogroup.jdbi.paging.InfiniteListResults` (no Creators, like default construct, exist): abstract types either need to be mapped to concrete types, have custom deserializer, or contain additional type information
		// at [Source: (org.glassfish.jersey.message.internal.ReaderInterceptorExecutor$UnCloseableInputStream); line: 1, column: 1]

		// javax.ws.rs.NotFoundException: HTTP 404 Not Found
	}

	@Test
	void test_givenParams_search_ok() {
		InfiniteListResults<CountryResponseV1> results = countryClient.search("en", new User("test", "master"), null,
				new CountrySearchRequestV1().setActive(ActiveEnum.all));

		assertThat(results).isNotNull();
		assertThat(results.getRecords()).hasSize(4)
				.extracting(CountryResponseV1::getCode, CountryResponseV1::getI18nName)
				.containsExactlyInAnyOrder(
						Tuple.tuple("GBR", "United Kingdom"),
						Tuple.tuple("ITA", "Italy"),
						Tuple.tuple("USA", "United States"),
						Tuple.tuple("YUG", "Yugoslavia")
				);

		// javax.ws.rs.ProcessingException: org.apache.http.conn.HttpHostConnectException: Connect to localhost:10300 [localhost/127.0.0.1] failed: Connessione rifiutata (Connection refused)

		// javax.ws.rs.client.ResponseProcessingException: com.fasterxml.jackson.databind.exc.InvalidDefinitionException: Cannot construct instance of `com.abacogroup.jdbi.paging.InfiniteListResults` (no Creators, like default construct, exist): abstract types either need to be mapped to concrete types, have custom deserializer, or contain additional type information
		// at [Source: (org.glassfish.jersey.message.internal.ReaderInterceptorExecutor$UnCloseableInputStream); line: 1, column: 1]

		// javax.ws.rs.NotFoundException: HTTP 404 Not Found

		// javax.ws.rs.BadRequestException: HTTP 400 Bad Request

		// org.glassfish.jersey.client.JerseyInvocation.convertToException
	}

	// ----- searchByI18nName -----
	@Test
	void test_searchByI18nName_ok() {
		List<CountryResponseV1> results = countryClient.searchByI18nName("it", new User("test", "master"), null,
				new CountrySearchRequestV1());

		assertThat(results).isNotNull().hasSize(3)
				.extracting(CountryResponseV1::getCode, CountryResponseV1::getI18nName)
				.containsExactlyInAnyOrder(
						Tuple.tuple("GBR", "Regno Unito"),
						Tuple.tuple("ITA", "Italia"),
						Tuple.tuple("USA", "Stati Uniti")
				);
	}

	@Test
	void test_givenParams_searchByI18nName_ok() {
		List<CountryResponseV1> results = countryClient.searchByI18nName("it", new User("test", "master"), null,
				new CountrySearchRequestV1().setI18nName("it").setActive(ActiveEnum.all));

		assertThat(results).isNotNull().hasSize(1)
				.extracting(CountryResponseV1::getCode, CountryResponseV1::getI18nName)
				.containsExactlyInAnyOrder(
						Tuple.tuple("ITA", "Italia")
				);
	}

	// ----- getByCode -----
	@Test
	void test_getByCode_ok() {
		CountryResponseV1 result = countryClient.getByCode("it", new User("test", "master"), "ITA");

		assertThat(result).isNotNull()
				.extracting(CountryResponseV1::getCode, CountryResponseV1::getI18nName)
				.containsExactly("ITA", "Italia");
	}

	@Test
	void test_getByCode_204() {
		CountryResponseV1 result = countryClient.getByCode("it", new User("test", "master"), "CCC");

		assertThat(result).isNull();
	}
}
