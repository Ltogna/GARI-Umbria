package com.abacogroup.lau;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.eclipse.jetty.servlets.CrossOriginFilter;

import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.lau.core.cli.v1.CountryClientV1;
import com.abacogroup.lau.core.cli.v1.CountryClientV1Impl;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;

import io.dropwizard.auth.AuthFilter;
import io.dropwizard.auth.PolymorphicAuthDynamicFeature;
import io.dropwizard.auth.PolymorphicAuthValueFactoryProvider;
import io.dropwizard.auth.basic.BasicCredentialAuthFilter;
import io.dropwizard.auth.chained.ChainedAuthFilter;
import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.core.Application;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration.Dynamic;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LauCliTestApplication extends Application<LauCliConfiguration> {

	private Map<Class<?>, Object> services = new HashMap<>();

	public Map<Class<?>, Object> getServices() {
		return services;
	}

	public <T> T getService(Class<T> clazz) {
		return Optional
				.ofNullable(this.getServices().get(clazz))
				.map(clazz::cast)
				.orElseThrow(() -> new RuntimeException(
						String.format("Error loading %s! Did you call by interface? Implementation required", clazz.getSimpleName())));
	}

	//  public static void main(final String[] args) throws Exception {
	//    new LauCliApplicationTest().run(args);
	//  }

	@Override
	public String getName() {
		return "lau-cli-test";
	}

	@Override
	public void initialize(final Bootstrap<LauCliConfiguration> bootstrap) {
		// TODO: application initialization
	}

	@Override
	public void run(final LauCliConfiguration configuration, final Environment environment) {
		// /api/tentant/{}/
		// environment.jersey().
		// TODO: implement application

		WebTarget webTarget = this.initLauTarget(configuration, environment);

		CountryClientV1 countryClient = this.register(new CountryClientV1Impl(webTarget));

		this.initAuth(environment);
		this.initMultiTenant(environment);
		this.setupCORS(configuration, environment);
	}

	protected WebTarget initLauTarget(LauCliConfiguration configuration, Environment environment) {
		
		final Client client = new JerseyClientBuilder(environment).using(configuration.getJerseyClient()).build("lau-client");
		WebTarget lau = client.target("http://localhost:10300/lau-service");
		return lau;
	}

	protected void initAuth(Environment environment) {
		List<AuthFilter<?, ? extends User>> filters = new ArrayList();
		filters.add(new BasicCredentialAuthFilter.Builder<User>()
				.setAuthenticator(credentials -> Optional.of(new User(credentials.getUsername(), "master")))
				.setAuthorizer((principal, role, reqCtx) -> {
					return true;
				})
				.setRealm("GUEST authenticator")
				.buildAuthFilter());

		ChainedAuthFilter usersFilter = new ChainedAuthFilter(filters);

		final PolymorphicAuthDynamicFeature<? extends User> feature = new PolymorphicAuthDynamicFeature<>(
				ImmutableMap.of(User.class, usersFilter /*
				 * , ApiKeyUser.class,
				 * apiKeyFilter
				 */));

		PolymorphicAuthValueFactoryProvider.Binder<? extends User> binder = new PolymorphicAuthValueFactoryProvider.Binder<>(
				ImmutableSet.of(User.class /* , ApiKeyUser.class */));

		environment.jersey().register(feature);
		environment.jersey().register(binder);
		//
	}

	protected <T> T register(T service) {
		services.put(service.getClass(), service);
		return service;
	}

	private void setupCORS(LauCliConfiguration configuration, Environment environment) {
		if (!configuration.isCors()) {
			log.info("CORS is disabled");
			return;
		}

		log.info("CORS is enabled");

		Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,DELETE");

		// OPTIONS pre-flight request will be served by the filter ONLY and not
		// passed ahead
		// cors.setInitParameter(CrossOriginFilter.CHAIN_PREFLIGHT_PARAM,
		// "false");

		// Add URL mapping
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

	private void initMultiTenant(Environment environment) {
		environment.jersey().register(new MultitenantFilter("tenant"));
	}

}
