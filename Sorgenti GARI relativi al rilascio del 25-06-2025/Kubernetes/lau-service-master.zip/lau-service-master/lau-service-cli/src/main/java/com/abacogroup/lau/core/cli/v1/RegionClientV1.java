package com.abacogroup.lau.core.cli.v1;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.v1.RegionDataResponseV1;
import com.abacogroup.lau.api.v1.RegionResponseV1;
import com.abacogroup.lau.api.v1.req.RegionSearchRequestV1;
import java.util.List;

public interface RegionClientV1 {

	InfiniteListResults<RegionResponseV1> search(String lang, User user, String nextKey, RegionSearchRequestV1 searchRequest);

	List<RegionDataResponseV1> searchByI18nName(String lang, User user, String nextKey, RegionSearchRequestV1 searchRequest);

	RegionResponseV1 getByCode(String lang, User user, String code);
}
