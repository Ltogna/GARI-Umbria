package com.abacogroup.lau.api.v1.req;

import com.abacogroup.lau.resources.req.ActiveEnum;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class MunicipalitySearchRequestV1 {

	@QueryParam("i18nName")
	private String i18nName;

	@QueryParam("code")
	private String code;

	@DefaultValue("only_active")
	@QueryParam("active")
	private ActiveEnum active;

	@QueryParam("countryCode")
	private String countryCode;

	@QueryParam("regionCode")
	private String regionCode;

	@QueryParam("districtCode")
	private String districtCode;

	@QueryParam("countryI18n")
	private String countryI18n;

	@QueryParam("regionI18n")
	private String regionI18n;

	@QueryParam("districtI18n")
	private String districtI18n;

	@QueryParam("pageSize")
	@Min(10)
	@Max(200)
	private Integer pageSize;

	public Integer getPageSize() {
		return pageSize == null ? 10 : pageSize;
	}
}
