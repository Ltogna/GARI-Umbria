package com.abacogroup.lau.api.v1;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@Accessors(chain = true)
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class RegionDataResponseV1 {

	private String code;
	private String tenantId;
	private String countryCode;
	private String shortDescr;
	private boolean active = true;

	private String i18nName;

}
