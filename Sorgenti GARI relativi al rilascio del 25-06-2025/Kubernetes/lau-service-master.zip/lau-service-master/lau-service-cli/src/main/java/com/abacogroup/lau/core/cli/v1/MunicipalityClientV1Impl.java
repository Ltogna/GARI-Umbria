package com.abacogroup.lau.core.cli.v1;

import static com.abacogroup.lau.resources.PublicResourceConstants.API_V1_PUB;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lau.api.v1.MunicipalityDataResponseV1;
import com.abacogroup.lau.api.v1.MunicipalityResponseV1;
import com.abacogroup.lau.api.v1.req.MunicipalitySearchRequestV1;
import com.abacogroup.lau.core.cli.AuthorizationStrategy;
import com.abacogroup.lau.core.cli.impl.NoopAuthorizationStrategy;
import com.abacogroup.lau.util.ClientUtils;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;
import java.time.Duration;
import java.util.List;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.ServerErrorException;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;

public class MunicipalityClientV1Impl implements MunicipalityClientV1 {

	private final WebTarget municipalityTarget;
	private final AuthorizationStrategy authorizationStrategy;
	private RetryRegistry retryRegistry;

	public MunicipalityClientV1Impl(WebTarget lauTarget) {
		this(lauTarget, new NoopAuthorizationStrategy());
	}

	public MunicipalityClientV1Impl(WebTarget lauTarget, AuthorizationStrategy authorizationStrategy) {
		this.municipalityTarget = lauTarget.path(String.format("%s/%s", API_V1_PUB, "municipalities"));
		this.authorizationStrategy = authorizationStrategy;

		this.retryRegistry = RetryRegistry.of(RetryConfig.custom()
				.maxAttempts(2)
				.waitDuration(Duration.ofMillis(500))
				.failAfterMaxAttempts(true)
				.retryExceptions(ProcessingException.class, ServerErrorException.class)
				.build());
	}

	@Override
	public InfiniteListResults<MunicipalityResponseV1> search(String lang, User user, String nextKey, MunicipalitySearchRequestV1 searchRequest) {

		String tenantId = user.getTenant();

		WebTarget webTarget = municipalityTarget.resolveTemplate("tenant", tenantId);

		WebTarget finalWebTarget = ClientUtils.addQueryParams(nextKey, searchRequest, webTarget);

		InfiniteListResultsImpl<MunicipalityResponseV1> results = retryRegistry.retry(finalWebTarget.getUri().toString())
				.executeSupplier(() -> finalWebTarget
						.request(MediaType.APPLICATION_JSON_TYPE)
						.accept(MediaType.APPLICATION_JSON_TYPE)
						.header("accept-language", lang)
						.header("Authorization", authorizationStrategy.getAuthorization(user)) // TODO non null
						.get(new GenericType<>() {
						}));

		return results;
	}

	@Override
	public List<MunicipalityDataResponseV1> searchByI18nName(String lang, User user, String nextKey, MunicipalitySearchRequestV1 searchRequest) {

		String tenantId = user.getTenant();

		WebTarget webTarget = municipalityTarget.path("names").resolveTemplate("tenant", tenantId);

		WebTarget finalWebTarget = ClientUtils.addQueryParams(nextKey, searchRequest, webTarget);

		List<MunicipalityDataResponseV1> results = retryRegistry.retry(finalWebTarget.getUri().toString())
				.executeSupplier(() -> finalWebTarget
						.request(MediaType.APPLICATION_JSON_TYPE)
						.accept(MediaType.APPLICATION_JSON_TYPE)
						.header("accept-language", lang)
						.header("Authorization", authorizationStrategy.getAuthorization(user)) // TODO non null
						.get(new GenericType<>() {
						}));

		return results;
	}

	@Override
	public MunicipalityResponseV1 getByCode(String lang, User user, String code) {

		String tenantId = user.getTenant();

		WebTarget webTarget = municipalityTarget.path("/{code}")
				.resolveTemplate("tenant", tenantId)
				.resolveTemplate("code", code);

		MunicipalityResponseV1 municipality = retryRegistry.retry(webTarget.getUri().toString())
				.executeSupplier(() -> webTarget
						.request(MediaType.APPLICATION_JSON_TYPE)
						.accept(MediaType.APPLICATION_JSON_TYPE)
						.header("accept-language", lang)
						.header("Authorization", authorizationStrategy.getAuthorization(user)) // TODO non null
						.get(new GenericType<>() {
						}));

		return municipality;
	}

}
