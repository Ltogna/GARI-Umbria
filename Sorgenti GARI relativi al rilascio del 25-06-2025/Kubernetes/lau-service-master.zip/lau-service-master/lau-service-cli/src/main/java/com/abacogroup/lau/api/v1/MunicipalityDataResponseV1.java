package com.abacogroup.lau.api.v1;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@Accessors(chain = true)
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class MunicipalityDataResponseV1 {

	private String code;
	private String tenantId;
	private String districtCode;
	private String shortDescr;
	private boolean active = true;

	private String i18nName;

}
