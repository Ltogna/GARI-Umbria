package com.abacogroup.lau.core.cli.v1;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.v1.CountryResponseV1;
import com.abacogroup.lau.api.v1.req.CountrySearchRequestV1;
import java.util.List;

public interface CountryClientV1 {

	InfiniteListResults<CountryResponseV1> search(String lang, User user, String nextKey, CountrySearchRequestV1 searchRequest);

	List<CountryResponseV1> searchByI18nName(String lang, User user, String nextKey, CountrySearchRequestV1 searchRequest);

	CountryResponseV1 getByCode(String lang, User user, String code);
}
