package com.abacogroup.lau.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map.Entry;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;

public class ClientUtils {

	public static WebTarget addQueryParams(String nextKey, Object searchRequest, WebTarget webTarget) {

		if (nextKey != null) {
			webTarget = webTarget.queryParam("nextKey", nextKey);
		}

		for (Entry<String, List<Object>> entry : extractQueryParams(searchRequest).entrySet()) {
			String key = entry.getKey();
			List<Object> values = entry.getValue();

			webTarget = webTarget.queryParam(key, values.toArray(new Object[0]));
		}

		return webTarget;
	}

	private static MultivaluedMap<String, Object> extractQueryParams(Object req) {
		MultivaluedMap<String, Object> paramsMap = new MultivaluedHashMap<>();

		for (Field field : req.getClass().getDeclaredFields()) {
			field.setAccessible(true);

			if (field.isAnnotationPresent(QueryParam.class)) {
				Class<?> fieldType = field.getType();
				QueryParam queryParam = field.getAnnotation(QueryParam.class);
				Object value;
				try {
					value = field.get(req);
				} catch (IllegalAccessException e) {
					// TODO manage error
					throw new RuntimeException(e);
				}

				if (value != null) {
					if (fieldType.isArray()) { // TODO test
						paramsMap.addAll(queryParam.value(), ((Object[]) value));
					} else if (Collection.class.isAssignableFrom(fieldType)) {
						paramsMap.addAll(queryParam.value(), new ArrayList<>((Collection<?>) value));
					} else {
						paramsMap.add(queryParam.value(), value);
					}
				}
			}
		}

		return paramsMap;
	}

}
