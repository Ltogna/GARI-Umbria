package com.abacogroup.lau.core.cli.v1;

import static com.abacogroup.lau.resources.PublicResourceConstants.API_V1_PUB;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.lau.api.v1.CountryResponseV1;
import com.abacogroup.lau.api.v1.req.CountrySearchRequestV1;
import com.abacogroup.lau.core.cli.AuthorizationStrategy;
import com.abacogroup.lau.core.cli.impl.NoopAuthorizationStrategy;
import com.abacogroup.lau.util.ClientUtils;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;
import java.time.Duration;
import java.util.List;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.ServerErrorException;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;

public class CountryClientV1Impl implements CountryClientV1 {

	private final WebTarget countyTarget;
	private final AuthorizationStrategy authorizationStrategy;
	private RetryRegistry retryRegistry;

	public CountryClientV1Impl(WebTarget lauTarget) {
		this(lauTarget, new NoopAuthorizationStrategy());
	}

	public CountryClientV1Impl(WebTarget lauTarget, AuthorizationStrategy authorizationStrategy) {
		this.countyTarget = lauTarget.path(String.format("%s/%s", API_V1_PUB, "countries"));
		this.authorizationStrategy = authorizationStrategy;

		this.retryRegistry = RetryRegistry.of(RetryConfig.custom()
				.maxAttempts(2)
				.waitDuration(Duration.ofMillis(500))
				.failAfterMaxAttempts(true)
				.retryExceptions(ProcessingException.class, ServerErrorException.class)
				.build());
	}

	@Override
	public InfiniteListResults<CountryResponseV1> search(String lang, User user, String nextKey, CountrySearchRequestV1 searchRequest) {

		String tenantId = user.getTenant();

		WebTarget webTarget = countyTarget.resolveTemplate("tenant", tenantId);

		WebTarget finalWebTarget = ClientUtils.addQueryParams(nextKey, searchRequest, webTarget);

		InfiniteListResultsImpl<CountryResponseV1> countries = retryRegistry.retry(finalWebTarget.getUri().toString())
				.executeSupplier(() -> finalWebTarget
						.request(MediaType.APPLICATION_JSON_TYPE)
						.accept(MediaType.APPLICATION_JSON_TYPE)
						.header("accept-language", lang)
						.header("Authorization", authorizationStrategy.getAuthorization(user)) // TODO non null
						.get(new GenericType<>() {
						}));

		return countries;
	}

	@Override
	public List<CountryResponseV1> searchByI18nName(String lang, User user, String nextKey, CountrySearchRequestV1 searchRequest) {

		String tenantId = user.getTenant();

		WebTarget webTarget = countyTarget.path("names").resolveTemplate("tenant", tenantId);

		WebTarget finalWebTarget = ClientUtils.addQueryParams(nextKey, searchRequest, webTarget);

		List<CountryResponseV1> countries = retryRegistry.retry(finalWebTarget.getUri().toString())
				.executeSupplier(() -> finalWebTarget
						.request(MediaType.APPLICATION_JSON_TYPE)
						.accept(MediaType.APPLICATION_JSON_TYPE)
						.header("accept-language", lang)
						.header("Authorization", authorizationStrategy.getAuthorization(user)) // TODO non null
						.get(new GenericType<>() {
						}));

		return countries;
	}

	@Override
	public CountryResponseV1 getByCode(String lang, User user, String code) {

		String tenantId = user.getTenant();

		WebTarget webTarget = countyTarget.path("/{code}")
				.resolveTemplate("tenant", tenantId)
				.resolveTemplate("code", code);

		CountryResponseV1 country = retryRegistry.retry(webTarget.getUri().toString())
				.executeSupplier(() -> webTarget
						.request(MediaType.APPLICATION_JSON_TYPE)
						.accept(MediaType.APPLICATION_JSON_TYPE)
						.header("accept-language", lang)
						.header("Authorization", authorizationStrategy.getAuthorization(user)) // TODO non null
						.get(new GenericType<>() {
						}));

		return country;
	}

}

