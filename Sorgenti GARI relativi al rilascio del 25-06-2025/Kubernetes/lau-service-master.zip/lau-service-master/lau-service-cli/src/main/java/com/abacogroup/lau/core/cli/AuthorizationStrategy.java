package com.abacogroup.lau.core.cli;

import com.abacogroup.dropwizard.auth.sso2.User;

// TODO common
public interface AuthorizationStrategy {

	String getAuthorization(User user);
}
