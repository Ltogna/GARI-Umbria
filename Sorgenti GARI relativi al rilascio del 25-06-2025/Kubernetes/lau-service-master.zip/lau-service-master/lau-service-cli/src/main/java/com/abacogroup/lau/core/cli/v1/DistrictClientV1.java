package com.abacogroup.lau.core.cli.v1;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.v1.DistrictDataResponseV1;
import com.abacogroup.lau.api.v1.DistrictResponseV1;
import com.abacogroup.lau.api.v1.req.DistrictSearchRequestV1;
import java.util.List;

public interface DistrictClientV1 {

	InfiniteListResults<DistrictResponseV1> search(String lang, User user, String nextKey, DistrictSearchRequestV1 searchRequest);

	List<DistrictDataResponseV1> searchByI18nName(String lang, User user, String nextKey, DistrictSearchRequestV1 searchRequest);

	DistrictResponseV1 getByCode(String lang, User user, String code);
}
