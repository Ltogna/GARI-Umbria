package com.abacogroup.lau.api.v1.req;

import com.abacogroup.lau.resources.req.ActiveEnum;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class CountrySearchRequestV1 {

	@QueryParam("i18nName")
	private String i18nName;

	@QueryParam("code")
	private String code;

	@QueryParam("active")
	private ActiveEnum active;

}
