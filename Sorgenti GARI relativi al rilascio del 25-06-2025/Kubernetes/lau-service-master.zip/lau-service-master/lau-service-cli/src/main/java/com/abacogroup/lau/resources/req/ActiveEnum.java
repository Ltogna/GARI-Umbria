package com.abacogroup.lau.resources.req;

public enum ActiveEnum {
	all,
	only_active,
	not_active
}
