package com.abacogroup.lau.core.cli.impl;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.lau.core.cli.AuthorizationStrategy;

// TODO common
public class NoopAuthorizationStrategy implements AuthorizationStrategy {

	@Override
	public String getAuthorization(User user) {
		return null;
	}

}
