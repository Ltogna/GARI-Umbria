package com.abacogroup.lau.core.cli.v1;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.lau.api.v1.MunicipalityDataResponseV1;
import com.abacogroup.lau.api.v1.MunicipalityResponseV1;
import com.abacogroup.lau.api.v1.req.MunicipalitySearchRequestV1;
import java.util.List;

public interface MunicipalityClientV1 {

	InfiniteListResults<MunicipalityResponseV1> search(String lang, User user, String nextKey, MunicipalitySearchRequestV1 searchRequest);

	List<MunicipalityDataResponseV1> searchByI18nName(String lang, User user, String nextKey, MunicipalitySearchRequestV1 searchRequest);

	MunicipalityResponseV1 getByCode(String lang, User user, String code);
}
