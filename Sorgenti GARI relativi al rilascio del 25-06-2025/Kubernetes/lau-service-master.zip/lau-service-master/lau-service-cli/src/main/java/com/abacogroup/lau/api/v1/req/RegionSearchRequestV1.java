package com.abacogroup.lau.api.v1.req;

import com.abacogroup.lau.resources.req.ActiveEnum;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@Accessors(chain = true)
public class RegionSearchRequestV1 {

	@QueryParam("i18nName")
	private String i18nName;

	@QueryParam("code")
	private String code;

	@DefaultValue("only_active")
	@QueryParam("active")
	private ActiveEnum active;

	@QueryParam("countryCode")
	private String countryCode;

}
