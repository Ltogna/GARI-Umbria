package com.abacogroup.lau.api.v1;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;
import lombok.experimental.SuperBuilder;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class DistrictResponseV1 extends DistrictDataResponseV1 {

	private RegionResponseV1 region;

}
