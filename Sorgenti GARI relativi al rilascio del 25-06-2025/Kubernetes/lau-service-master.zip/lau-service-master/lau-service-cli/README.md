# lau-service-cli

## Usage

define client in configuration

```java
import io.dropwizard.core.Configuration;

public class MyServiceConfiguration extends Configuration {

	@Valid
	@NotNull
	@Getter
	@Setter
	private JerseyClientConfiguration jerseyClient = new JerseyClientConfiguration();

}
```

create lau client in Application

```java

@Slf4j
public class MyServiceApplication extends Application<MyServiceConfiguration> {

	// [...]

	@Override
	public void run(final MyServiceConfiguration configuration, final Environment environment) {

		// [...]

		WebTarget lauTarget = this.initLauTarget(configuration, environment);

		CountryClient countryClient = this.register(new CountryClientImpl(lauTarget));

		// [...]
	}

	protected WebTarget initLauTarget(MyServiceConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment).using(configuration.getJerseyClient()).build("lau-client");

		WebTarget lau = client.target("http://localhost:10300/lau-service");
		return lau;
	}

	// [...]
}
```
