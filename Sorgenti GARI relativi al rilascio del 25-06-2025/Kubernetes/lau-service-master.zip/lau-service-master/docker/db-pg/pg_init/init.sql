create database lau;
create database lau_test;

