package com.abacogroup.calculatorengine.sdk.proc;

import static com.abacogroup.calculatorengine.sdk.CalculatorEngineUtils.WFCONFIG_PAYLOAD;
import static com.abacogroup.calculatorengine.sdk.model.CalculatorEngineInput.PARAM_NAME;
import static com.abacogroup.calculatorengine.sdk.model.CalculatorEngineInput.UUID_PARAM_NAME;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import java.io.File;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.Test;

import com.abacogroup.calculatorengine.sdk.ProcEnvConstants;
import com.abacogroup.calculatorengine.sdk.model.CalculationResult;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.testsupport.ProcedureEnvironmentTestSupport;
import com.abacogroup.workflow.sdk.beans.testsupport.ProcessDataTestSupport;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import com.fasterxml.jackson.databind.ObjectMapper;

class SafeAbstractProcedureTest {

	// ----- execute -----
	@Test
	void test_execute_ok() throws Exception {

		String tenantId = "tenant_t";
		String WF_CODE = "wk_t";

		File sourceDir = new File(this.getClass().getResource(this.getClass().getSimpleName()).getFile());

		ProcessDataTestSupport processData = ProcessDataTestSupport.builder()
				.tenantId(tenantId)
				.processId(1L)
				.globalVars(new HashMap<>(Map.of(
						PARAM_NAME, new HashMap<>(Map.of(WFCONFIG_PAYLOAD, FileUtils.readFileToString(
								new File(sourceDir, "uuidrandom_wfConfig.json"),
								Charset.defaultCharset()))))))
				.workflowCode(WF_CODE)
				.build();

		ProcedureEnvironmentTestSupport env = new ProcedureEnvironmentTestSupport(
				Map.of(),
				null,
				Map.of(
						ProcEnvConstants.PROPERTY_OBJECT_MAPPER, new ObjectMapper(),
						ProcEnvConstants.PROPERTY_SOURCE_DIR, sourceDir.getAbsolutePath()));
		new SafeAbstractImportConfigProcedure<ImportConfigProcedureTestParam>() {
			@Override
			protected Class<ImportConfigProcedureTestParam> getConfigClass() {
				return ImportConfigProcedureTestParam.class;
			}
		}.execute(processData, env);

		assertThat(processData.getGlobalVar(SafeAbstractProcedure.GLOBAL_VAR_CALC_PARAMS_NAME))
				.isNotEmpty().get()
				.isInstanceOf(ImportConfigProcedureTestParam.class)
				.isEqualTo(new ImportConfigProcedureTestParam(
						"bar2", List.of("all", "values", "in", "the", "array"), 55.));

	}

	@Test
	void test_canReadUuid() throws Exception {

		ProcedureEnvironmentTestSupport env = new ProcedureEnvironmentTestSupport(
				Map.of(),
				null,
				Map.of());

		File sourceDir = new File(this.getClass().getResource(this.getClass().getSimpleName()).getFile());

		String uuid = System.currentTimeMillis() + "";
		var params = new HashMap<>(Map.of(WFCONFIG_PAYLOAD, FileUtils.readFileToString(
				new File(sourceDir, "uuidrandom_wfConfig.json"),
				Charset.defaultCharset())));
		params.put(UUID_PARAM_NAME, uuid);

		ProcessDataTestSupport processData = ProcessDataTestSupport.builder()
				.tenantId("test")
				.processId(1L)
				.globalVars(new HashMap<>(Map.of(PARAM_NAME, params)))
				.workflowCode("test-uuid")
				.build();

		AtomicReference<String> ref = new AtomicReference<>();

		new SafeAbstractProcedure<ImportConfigProcedureTestParam>() {
			@Override
			protected void doExecute(ProcessData processData, ProcedureEnvironment env) throws Exception {
				String uuid = getCalculationUuid(processData);
				ref.set(uuid);
			}

			@Override
			protected Class<ImportConfigProcedureTestParam> getConfigClass() {
				return ImportConfigProcedureTestParam.class;
			};
		}.execute(processData, env);

		assertThat(ref.get()).isEqualTo(uuid);

	}

	@Test
	void test_canExtend() throws Exception {
		ProcedureEnvironmentTestSupport env = new ProcedureEnvironmentTestSupport(
				Map.of(),
				null,
				Map.of());

		File sourceDir = new File(this.getClass().getResource(this.getClass().getSimpleName()).getFile());

		String uuid = System.currentTimeMillis() + "";
		ProcessDataTestSupport processData = ProcessDataTestSupport.builder()
				.tenantId("test")
				.processId(1L)
				.globalVars(new HashMap<>(Map.of(
						UUID_PARAM_NAME, uuid,
						PARAM_NAME, new HashMap<>(Map.of(WFCONFIG_PAYLOAD, FileUtils.readFileToString(
								new File(sourceDir, "uuidrandom_wfConfig.json"),
								Charset.defaultCharset()))))))
				.workflowCode("test-uuid")
				.build();

		assertDoesNotThrow(() -> new ExtendedProcedure().execute(processData, env));
		assertDoesNotThrow(() -> new ExtendedExtendedProcedure().execute(processData, env));
	}

	static class ExtendedProcedure extends SafeCalculationProcedure<String, ImportConfigProcedureTestParam> {
		@Override
		protected CalculationResult<String> buildEmptyResult() {
			return new CalculationResult<>("");
		}

		@Override
		protected CalculationResult<String> calculate(ProcessData processData, ProcedureEnvironment env, CalculationResult<String> currentResult)
				throws Exception {
			return new CalculationResult<>("DONE");
		}

		@Override
		protected Class<ImportConfigProcedureTestParam> getConfigClass() {
			return ImportConfigProcedureTestParam.class;
		}
	}

	static class ExtendedExtendedProcedure extends ExtendedProcedure {
		@Override
		protected CalculationResult<String> calculate(ProcessData processData, ProcedureEnvironment env, CalculationResult<String> currentResult)
				throws Exception {
			return new CalculationResult<>("DONE-2");
		}
	}

}
