package com.abacogroup.calculatorengine.sdk.proc;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ImportConfigProcedureTestParam {

	private String foo;
	private List<String> anArray;
	private Double theDouble;

}
