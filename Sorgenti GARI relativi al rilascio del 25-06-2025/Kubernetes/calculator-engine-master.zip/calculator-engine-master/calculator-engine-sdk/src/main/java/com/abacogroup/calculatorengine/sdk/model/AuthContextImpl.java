package com.abacogroup.calculatorengine.sdk.model;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.workflow.sdk.auth.AuthContext;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientRequestFilter;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.SecurityContext;
import java.security.Principal;

public class AuthContextImpl implements AuthContext {

	private User user;
	private String localeCode;
	private SecurityContext securityContext;

	public AuthContextImpl(SecurityContext securityContext, String localeCode) {
		this.user = (User) securityContext.getUserPrincipal();
		this.localeCode = localeCode;
		this.securityContext = securityContext;
	}

	@Override
	public String getUserId() {
		return user.getUserId();
	}

	@Override
	public String getLocaleCode() {
		return localeCode;
	}

	@Override
	public boolean isFunctionEnabled(String context, String function) {
		return securityContext.isUserInRole(context + "|" + function);
	}

	@Override
	public WebTarget getAuthenticatedWebTarget(Client client, String url) {
		return client.target(url).register(
				(ClientRequestFilter) requestContext -> requestContext.getHeaders().add("Authorization", String.format("JWT %s", user.getAuthToken())));
	}

	// @Override TODO wf sdk next major
	@Override
	public Principal getPrincipal() {
		return user;
	}

}
