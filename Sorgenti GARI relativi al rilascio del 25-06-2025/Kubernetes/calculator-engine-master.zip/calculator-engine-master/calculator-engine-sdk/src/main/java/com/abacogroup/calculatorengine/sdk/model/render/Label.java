package com.abacogroup.calculatorengine.sdk.model.render;

import java.util.HashMap;
import java.util.Map;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class Label {

	private String label;
	private Map<String, String> i18nLabels;

	private Label(String label) {
		this.label = label;
	}

	private Label(Map<String, String> i18nLabels) {
		this.i18nLabels = new HashMap<>(i18nLabels);
	}

	public static Label of(String label) {
		return new Label(label);
	}

	public static Label of(Map<String, String> i18nLabels) {
		return new Label(Map.copyOf(i18nLabels));
	}

	public String toString(String locale) {
		return label; // TODO: i18n
	}
}
