package com.abacogroup.calculatorengine.sdk;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringSubstitutor;

@Slf4j
public class CalculatorEngineUtils {

	public static final String CONFIG_FILE_NAME = "wfConfig.json";
	public static final String WFCONFIG_PAYLOAD = "_WFCONFIG_PAYLOAD";

	/**
	 * path/to/work/dir/tenantId/wfCode
	 *
	 * @param workDir     calculatorConfig.initBaseTempDir
	 * @param tenantId    tenant Id
	 * @param wfCode      workflow code
	 * @param versionHash workflow version hash
	 * @return path
	 */
	public static Path getSourceDir(String workDir, String tenantId, String wfCode, String versionHash) {
		return Path.of(workDir, tenantId, wfCode, versionHash);
	}

	public static Properties retrieveProperties(String sourceDir, String basePropertyFileName, String... profiles) {
		return retrieveProperties(new Properties(), sourceDir, basePropertyFileName, profiles);
	}

	public static Properties retrieveProperties(Properties accumulator, String sourceDir, String basePropertyFileName, String... profiles) {

		String baseProperties = String.format("%s.properties", basePropertyFileName);
		Properties reducedProperties = Stream.concat(
						Stream.of(baseProperties),
						Stream.of(profiles).filter(StringUtils::isNotBlank).map(p -> String.format("%s-%s.properties", basePropertyFileName, p)))
				.map(a -> String.format("%s/%s", sourceDir, StringUtils.trim(a)))
				.filter(path -> {
					boolean exists = new File(path).exists();
					if (!exists) {
						log.debug("{} not found", path);
					}
					return exists;
				})
				.reduce(
						accumulator,
						(properties, filename) -> {
							log.debug("loading properties from {}", filename);
							try (InputStream input = new FileInputStream(filename)) {
								properties.load(input);
							} catch (IOException ex) {
								log.error("error loading properties from {}", filename, ex);
							}
							return properties;
						},
						(p1, p2) -> {
							p1.putAll(p2);
							return p1;
						});

		return reducedProperties;
	}

	@SuppressWarnings("all")
	public static Properties resolveProperties(Properties orig, Properties vars) {
		Properties result = new Properties();
		StringSubstitutor sub = new StringSubstitutor((Map) vars);
		orig.forEach((key, value) -> result.put(key, sub.replace(value)));
		return result;
	}
}
