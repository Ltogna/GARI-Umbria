package com.abacogroup.calculatorengine.sdk.proc;

import com.abacogroup.calculatorengine.sdk.model.CalculationResult;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;

/**
 * Classe astratta che deve essere implementata dai workflow
 *
 * @param <T>
 * @param <Config>
 */
public abstract class SafeCalculationProcedure<T, Config> extends SafeAbstractProcedure<Config> {

	@Override
	protected final void doExecute(ProcessData processData, ProcedureEnvironment env) throws Exception {
		CalculationResult<T> result = processData.<CalculationResult<T>>getGlobalVar(GLOBAL_VAR_RESULT_NAME)
				.orElseGet(this::buildEmptyResult);

		result = calculate(processData, env, result);
		processData.getGlobalVars().put(GLOBAL_VAR_RESULT_NAME, result);
	}

	protected abstract CalculationResult<T> buildEmptyResult();

	protected abstract CalculationResult<T> calculate(ProcessData processData, ProcedureEnvironment env, CalculationResult<T> currentResult)
			throws Exception;

}
