package com.abacogroup.calculatorengine.sdk.client;

import com.abacogroup.calculatorengine.sdk.exceptions.CalculatorEngineException;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.workflow.sdk.auth.AuthContext;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.ServerErrorException;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.Invocation.Builder;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Consumer;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ClientSupport {

	private final WebTarget target;

	private final RetryRegistry retryRegistry;

	public ClientSupport(ProcessData processData, ProcedureEnvironment env, String serverAddress) {
		Client client = env.getJerseyClient().orElseThrow(() -> new CalculatorEngineException("missing client"));

		AuthContext authContext = processData.getAuthContext();

		this.target = authContext.getAuthenticatedWebTarget(client, serverAddress);
		this.retryRegistry = RetryRegistry.of(RetryConfig.custom()
				.maxAttempts(3)
				.waitDuration(Duration.ofMillis(500))
				.failAfterMaxAttempts(true)
				.retryExceptions(ProcessingException.class, ServerErrorException.class, NotFoundException.class)
				.build());
	}

	public <T> T get(String path, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams, GenericType<? extends T> type) {
		return retryRegistry.retry(String.format("GET %s/%s", target.getUri().toString(), path))
				.executeSupplier(() -> doGet(path, pathVariables, queryParams, type));
	}

	private <T> T doGet(String path, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams, GenericType<? extends T> type) {
		return this.getRequestBuilder(path, null, pathVariables, queryParams)
				.accept(MediaType.APPLICATION_JSON_TYPE)
				.get(type);
	}

	public <T> T getElementFromInfiniteResult(String path, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams,
			GenericType<InfiniteListResultsImpl<T>> type, int pos) {
		InfiniteListResultsImpl<T> infiniteListResults = this.get(path, pathVariables, queryParams, type);

		if (infiniteListResults.getCount() <= pos) {
			return null;
		} else {
			T t = infiniteListResults.getRecords().get(pos);
			return t;
		}
	}

	public <T> List<T> getAllFromInfiniteResult(String path, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams,
			GenericType<InfiniteListResultsImpl<T>> type) {

		List<T> all = new ArrayList<>();

		this.consumeAllFromInfiniteResult(path, pathVariables, queryParams, type, all::add);

		return all;
	}

	public <T> void consumeAllFromInfiniteResult(String path, Map<String, Object> pathVariables, MultivaluedMap<String, Object> queryParams,
			GenericType<InfiniteListResultsImpl<T>> type, Consumer<T> consumer) {
		if (queryParams == null) {
			queryParams = new MultivaluedHashMap<>();
		}

		String nextKey = null;
		do {
			queryParams.putSingle("nextKey", nextKey);
			InfiniteListResultsImpl<T> infiniteListResults = this.get(path, pathVariables, queryParams, type);

			for (T record : infiniteListResults.getRecords()) {
				consumer.accept(record);
			}
			nextKey = infiniteListResults.getNextKey();
		} while (nextKey != null);
	}

	private Builder getRequestBuilder(String path, MultivaluedMap<String, Object> headers, Map<String, Object> pathVariables,
			MultivaluedMap<String, Object> queryParams) {
		WebTarget webTarget = target.path(path)
				.resolveTemplates(pathVariables == null ? new HashMap<>() : pathVariables);

		if (queryParams != null) {
			for (Entry<String, List<Object>> entry : queryParams.entrySet()) {
				webTarget = webTarget.queryParam(entry.getKey(), entry.getValue().toArray());
			}
		}

		Builder builder = webTarget.request();

		if (headers != null) {
			for (Entry<String, List<Object>> entry : headers.entrySet()) {
				if (entry.getValue() != null) {
					for (Object v : entry.getValue()) {
						builder = builder.header(entry.getKey(), v);
					}
				} else {
					builder = builder.header(entry.getKey(), null);
				}
			}
		}

		log.debug("calling {}", webTarget);
		return builder;
	}

}


