package com.abacogroup.calculatorengine.sdk.proc;

import static com.abacogroup.calculatorengine.sdk.model.CalculatorEngineInput.UUID_PARAM_NAME;

import java.util.Map;
import java.util.Optional;

import com.abacogroup.workflow.sdk.beans.ProcessData;

/**
 * @param <Config>
 * @deprecated Use {@link SafeAbstractProcedure} instead
 */
@Deprecated(forRemoval = true)
public abstract class AbstractProcedure<Config> extends AbstractImportConfigProcedure<Config> {
	public static final String PARAMETERS_NAME = "parameters";
	public static final String GLOBAL_VAR_RESULT_NAME = SafeAbstractProcedure.GLOBAL_VAR_RESULT_NAME;
	public static final String GLOBAL_VAR_CALC_PARAMS_NAME = SafeAbstractProcedure.GLOBAL_VAR_CALC_PARAMS_NAME;

	protected Optional<Config> getCalculationConfiguration(ProcessData processData) {
		return processData.getGlobalVar(GLOBAL_VAR_CALC_PARAMS_NAME);
	}

	protected Map<String, Object> getWorkflowParameters(ProcessData processData) {
		return processData.<Map<String, Object>>getGlobalVar(PARAMETERS_NAME).orElseThrow();
	}

	protected final String getCalculationUuid(ProcessData processData) {
		var vars = getWorkflowParameters(processData);
		String uuid = (String) vars.get(UUID_PARAM_NAME);
		if (uuid == null) {
			throw new IllegalStateException("Calculation UUID not present");
		}

		return uuid;
	}

}
