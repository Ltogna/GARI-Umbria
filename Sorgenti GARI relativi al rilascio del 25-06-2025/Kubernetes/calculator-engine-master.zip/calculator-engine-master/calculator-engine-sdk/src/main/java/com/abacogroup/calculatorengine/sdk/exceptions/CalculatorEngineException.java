package com.abacogroup.calculatorengine.sdk.exceptions;

public class CalculatorEngineException extends RuntimeException {

	private static final long serialVersionUID = -628498800347427877L;

	public CalculatorEngineException() {
		super();
	}

	public CalculatorEngineException(String message) {
		super(message);
	}

	public CalculatorEngineException(String message, Throwable cause) {
		super(message, cause);
	}

	public CalculatorEngineException(Throwable cause) {
		super(cause);
	}
}
