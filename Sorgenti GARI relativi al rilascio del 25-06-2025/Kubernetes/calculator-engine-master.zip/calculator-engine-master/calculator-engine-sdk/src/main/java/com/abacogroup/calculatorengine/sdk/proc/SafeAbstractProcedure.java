package com.abacogroup.calculatorengine.sdk.proc;

import static com.abacogroup.calculatorengine.sdk.model.CalculatorEngineInput.UUID_PARAM_NAME;

import java.util.Map;
import java.util.Optional;

import com.abacogroup.workflow.sdk.beans.ProcessData;

public abstract class SafeAbstractProcedure<Config> extends SafeAbstractImportConfigProcedure<Config> {
	public static final String PARAMETERS_NAME = "parameters";
	public static final String GLOBAL_VAR_RESULT_NAME = "com.abacogroup.calculatorengine.sdk.proc.AbstractProcedure"; // Backwards compat.
	public static final String GLOBAL_VAR_CALC_PARAMS_NAME = "PARM_" + GLOBAL_VAR_RESULT_NAME;

	protected Optional<Config> getCalculationConfiguration(ProcessData processData) {
		return processData.getGlobalVar(GLOBAL_VAR_CALC_PARAMS_NAME);
	}

	protected Map<String, Object> getWorkflowParameters(ProcessData processData) {
		return processData.<Map<String, Object>>getGlobalVar(PARAMETERS_NAME).orElseThrow();
	}

	protected final String getCalculationUuid(ProcessData processData) {
		var vars = getWorkflowParameters(processData);
		String uuid = (String) vars.get(UUID_PARAM_NAME);
		if (uuid == null) {
			throw new IllegalStateException("Calculation UUID not present");
		}

		return uuid;
	}

}
