package com.abacogroup.calculatorengine.sdk.model;

import com.abacogroup.calculatorengine.sdk.model.render.Label;
import com.abacogroup.calculatorengine.sdk.model.render.Section;
import com.abacogroup.calculatorengine.sdk.model.variable.Variable;
import lombok.Getter;
import lombok.ToString;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * oggetto che contiene i risultati renderizzati.
 *
 * <b>Solitamente</b> è creato automaticamente da {@link CalculationResult}.
 */
@ToString
@Getter
public class CalculationResultRenderData {

    private List<Section> sections = new ArrayList<>();

    private Map<String, Label> tagLabels = new HashMap<>(); //GET by tag

    public static void main(String[] args) {
        Variable v = Variable.withDocumentation("")
                .withLabel("")
                .ofAreaSqm(10);
    }

    public Section getSection(String code) {
        return sections.stream()
                .filter(section -> code.equals(section.getCode()))
                .findFirst()
                .orElseThrow();
    }


}
