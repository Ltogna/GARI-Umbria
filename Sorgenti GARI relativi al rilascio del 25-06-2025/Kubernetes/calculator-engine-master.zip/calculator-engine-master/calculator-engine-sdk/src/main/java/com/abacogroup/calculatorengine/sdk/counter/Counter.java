package com.abacogroup.calculatorengine.sdk.counter;

public interface Counter {

	long next(String tenant, String counterName);

}
