package com.abacogroup.calculatorengine.sdk.model.render;

import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class Section {
	private String code;
	private Label label;
	private Label documentation;
	private List<Group> groups;

	public Section(String code, Label label, Label documentation) {
		this.code = code;
		this.label = label;
		this.documentation = documentation;
		this.groups = new ArrayList<>();
	}

	public Section(String code, Label label) {
		this(code, label, null);
	}

	public Group getGroup(String code) {
		return groups.stream()
				.filter(group -> code.equals(group.getCode()))
				.findFirst()
				.orElseThrow();
	}

	public Section addGroup(Group group) {
		this.groups.add(group);
		return this;
	}
}
