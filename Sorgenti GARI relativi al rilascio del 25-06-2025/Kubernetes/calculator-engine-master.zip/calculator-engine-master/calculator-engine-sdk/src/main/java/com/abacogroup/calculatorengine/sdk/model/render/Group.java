package com.abacogroup.calculatorengine.sdk.model.render;

import com.abacogroup.calculatorengine.sdk.model.variable.Variable;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class Group {

	private String code;
	private Label label;
	private Label documentation;
	private List<Variable> variables;

	public Group(String code, Label label, Label documentation) {
		this.code = code;
		this.label = label;
		this.documentation = documentation;
		this.variables = new ArrayList<>();
	}

	public Group(String code, Label label) {
		this(code, label, null);
	}

	public Group addVariable(Variable variable) {
		this.variables.add(variable);
		return this;
	}

}
