package com.abacogroup.calculatorengine.sdk;

public interface ProcEnvConstants {

	/**
	 * folder temporanea che coincide con con calculatorConfig.initBaseTempDir
	 */
	String PROPERTY_WORK_DIR = "workDir";

	/**
	 * folder dove viene scompattato il jar del workflow e compilati i jasper
	 */
	String PROPERTY_SOURCE_DIR = "sourceDir";

	String PROPERTY_OBJECT_MAPPER = "objectMapper";
	String PROPERTY_PROFILE = "profile";

	String PROPERTY_COUNTER = "_counters";

}
