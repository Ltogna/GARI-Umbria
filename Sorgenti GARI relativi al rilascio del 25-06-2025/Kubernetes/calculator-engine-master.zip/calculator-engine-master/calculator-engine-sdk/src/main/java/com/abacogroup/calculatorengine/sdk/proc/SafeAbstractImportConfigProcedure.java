package com.abacogroup.calculatorengine.sdk.proc;

import static com.abacogroup.calculatorengine.sdk.CalculatorEngineUtils.WFCONFIG_PAYLOAD;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.calculatorengine.sdk.ProcEnvConstants;
import com.abacogroup.calculatorengine.sdk.exceptions.CalculatorEngineException;
import com.abacogroup.calculatorengine.sdk.model.CalculatorEngineInput;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.EnvironmentAwareProcedure;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class SafeAbstractImportConfigProcedure<Config>
		implements EnvironmentAwareProcedure<ProcedureEnvironment> {

	@Override
	public final void execute(ProcessData processData, ProcedureEnvironment env) throws Exception {

		String configPayload = processData.<Map<String, Object>>getGlobalVar(CalculatorEngineInput.PARAM_NAME)
				.map(m -> m.get(WFCONFIG_PAYLOAD))
				.map(String.class::cast)
				.orElse(null);

		if (Void.class.equals(getConfigClass())) {
			// If the config is void, we can proceed without it
			log.debug("no config provided, proceeding with void config");
			doExecute(processData, env);
		} else if (StringUtils.isNotBlank(configPayload)) {
			ObjectMapper objectMapper = env.<ObjectMapper>getProperty(ProcEnvConstants.PROPERTY_OBJECT_MAPPER)
					.orElseGet(ObjectMapper::new);

			Config config = null;
			Class<Config> configClass = getConfigClass();
			if (configClass != null) {
				config = objectMapper.readValue(configPayload, configClass);
				processData.getGlobalVars().put(SafeAbstractProcedure.GLOBAL_VAR_CALC_PARAMS_NAME, config);
				log.debug("config loaded: {}", config);
			}

			doExecute(processData, env);
		} else {
			throw new CalculatorEngineException("no such config");
		}
	}

	protected void doExecute(ProcessData processData, ProcedureEnvironment env) throws Exception {
		// NoOp
	}

	protected abstract Class<Config> getConfigClass();

}
