package com.abacogroup.calculatorengine.sdk.model.variable;

import com.abacogroup.calculatorengine.sdk.model.render.Label;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Variable {
    private String code;
    private Label label;
    private Label documentation;
    private VariableKind kind;
    private Object value;
    private List<String> tags;

    private Variable(String code, Label documentation, Label label, List<String> tags, Object value, VariableKind kind) {
        this.code = code;
        this.label = label;
        this.documentation = documentation;
        this.value = value;
        this.kind = kind;
        this.tags = new ArrayList<>(tags);
    }

    public static VariableBuilderDoc withCode(String code) {
        return new VariableBuilder().withCode(code);
    }

    @Deprecated
    public static VariableBuilderDoc withDocumentation(String documentation) {
        return new VariableBuilder(Label.of(documentation));
    }

    public Variable withTags(String... tags) {
        this.tags.clear();
        Arrays.stream(tags).distinct().forEach(this.tags::add);
        return this;
    }

    public interface VariableBuilderValue {
        Variable ofLong(Long value);

        Variable ofDouble(Double value);

        Variable ofMoney(Number value);

        Variable ofAreaSqm(Number value);

        Variable ofLengthMt(Number value);

        Variable ofLocalDate(LocalDate value);

        Variable ofLocalDateTime(LocalDateTime value);

        Variable ofOffsetDateTime(OffsetDateTime value);

        Variable ofPercentage(BigDecimal value);

        Variable ofString(String value);

    }

    public interface VariableBuilderDoc {
        VariableBuilderDoc withCode(String code);

        VariableBuilderDoc withDocumentation(String documentation);

        VariableBuilderDoc withDocumentation(Map<String, String> langDocumentations);

        VariableBuilderValue withLabel(String label);

        VariableBuilderValue withLabel(Map<String, String> langLabels);

        VariableBuilderDoc withTags(String... tags);
    }


    public static class VariableBuilder implements VariableBuilderDoc, VariableBuilderValue {
        private String code;
        private Label documentation;
        private Label label;
        private List<String> tags;

        private VariableBuilder() {
			this.tags = new ArrayList<>();
        }

        @Deprecated
        private VariableBuilder(Label documentation) {
            this();
            this.documentation = documentation;
		}

        @Override
        public VariableBuilderDoc withCode(String code) {
            this.code = code;
            return this;
        }

        @Override
        public VariableBuilderDoc withDocumentation(String documentation) {
            this.documentation = Label.of(documentation);
            return this;
        }

        @Override
        public VariableBuilderDoc withDocumentation(Map<String, String> langDocumentations) {
            this.documentation = Label.of(langDocumentations);
            return this;
        }

        @Override
        public VariableBuilderValue withLabel(String label) {
            this.label = Label.of(label);
            return this;
        }

        @Override
        public VariableBuilderValue withLabel(Map<String, String> langLabels) {
            this.label = Label.of(langLabels);
            return this;
        }

        @Override
        public VariableBuilderDoc withTags(String... tags) {
            this.tags.clear();
            Arrays.stream(tags).distinct().forEach(this.tags::add);
            return this;
        }

        @Override
        public Variable ofLong(Long value) {
            return new Variable(code, documentation, label, tags, value, VariableKind.NUMBER_LONG);
        }

        @Override
        public Variable ofDouble(Double value) {
            return new Variable(code, documentation, label, tags, value, VariableKind.NUMBER_DOUBLE);
        }

        @Override
        public Variable ofMoney(Number value) {
            return new Variable(code, documentation, label, tags, value, VariableKind.MONEY);
        }

        @Override
        public Variable ofAreaSqm(Number value) {
            return new Variable(code, documentation, label, tags, value, VariableKind.AREA_SQM);
        }

        @Override
        public Variable ofLengthMt(Number value) {
            return new Variable(code, documentation, label, tags, value, VariableKind.LENGTH_MT);
        }

        @Override
        public Variable ofLocalDate(LocalDate value) {
            return new Variable(code, documentation, label, tags, value, VariableKind.DATE);
        }

        @Override
        public Variable ofLocalDateTime(LocalDateTime value) {
            return new Variable(code, documentation, label, tags, value, VariableKind.DATE_TIME);
        }

        @Override
        public Variable ofOffsetDateTime(OffsetDateTime value) {
            return new Variable(code, documentation, label, tags, value, VariableKind.DATE_TIME);
        }

        @Override
        public Variable ofString(String value) {
            return new Variable(code, documentation, label, tags, value, VariableKind.STRING);
        }

        @Override
        public Variable ofPercentage(BigDecimal value) {
            return new Variable(code, documentation, label, tags, value, VariableKind.PERCENTAGE);
        }
    }
}
