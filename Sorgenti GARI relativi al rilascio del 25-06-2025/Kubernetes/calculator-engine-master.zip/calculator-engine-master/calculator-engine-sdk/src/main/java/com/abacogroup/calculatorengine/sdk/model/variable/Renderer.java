package com.abacogroup.calculatorengine.sdk.model.variable;

import java.util.Optional;

public interface Renderer {

	String getValueAsString(Variable variable);

	Optional<String> getUnitOfMeasure(Variable variable);

}
