package com.abacogroup.calculatorengine.sdk.model;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(setterPrefix = "set")
public class CalculatorEngineInput implements Map<String, Object> {

	public static final String PARAM_NAME = "parameters";
	public static final String UUID_PARAM_NAME = "CALC_UUID";

	@JsonProperty("_params")
	@JsonAnyGetter
	@JsonAnySetter
	@Default
	private Map<String, Object> params = new HashMap<>();

	@Override
	public int size() {
		return params.size();
	}

	@Override
	public boolean isEmpty() {
		return params.isEmpty();
	}

	@Override
	public boolean containsKey(Object key) {
		return params.containsKey(key);
	}

	@Override
	public boolean containsValue(Object value) {
		return params.containsValue(value);
	}

	@Override
	public Object get(Object key) {
		return params.get(key);
	}

	@Override
	public Object put(String key, Object value) {
		return params.put(key, value);
	}

	@Override
	public Object remove(Object key) {
		return params.remove(key);
	}

	@Override
	public void putAll(Map<? extends String, ? extends Object> m) {
		params.putAll(m);
	}

	@Override
	public void clear() {
		params.clear();
	}

	@Override
	public Set<String> keySet() {
		return params.keySet();
	}

	@Override
	public Collection<Object> values() {
		return params.values();
	}

	@Override
	public Set<Entry<String, Object>> entrySet() {
		return params.entrySet();
	}

	@Override
	public Object getOrDefault(Object key, Object defaultValue) {
		return params.getOrDefault(key, defaultValue);
	}

	@Override
	public void forEach(BiConsumer<? super String, ? super Object> action) {
		params.forEach(action);
	}

	@Override
	public void replaceAll(BiFunction<? super String, ? super Object, ? extends Object> function) {
		params.replaceAll(function);
	}

	@Override
	public Object putIfAbsent(String key, Object value) {
		return params.putIfAbsent(key, value);
	}

	@Override
	public boolean remove(Object key, Object value) {
		return params.remove(key, value);
	}

	@Override
	public boolean replace(String key, Object oldValue, Object newValue) {
		return params.replace(key, oldValue, newValue);
	}

	@Override
	public Object replace(String key, Object value) {
		return params.replace(key, value);
	}

	@Override
	public Object computeIfAbsent(String key, Function<? super String, ? extends Object> mappingFunction) {
		return params.computeIfAbsent(key, mappingFunction);
	}

	@Override
	public Object computeIfPresent(String key, BiFunction<? super String, ? super Object, ? extends Object> remappingFunction) {
		return params.computeIfPresent(key, remappingFunction);
	}

	@Override
	public Object compute(String key, BiFunction<? super String, ? super Object, ? extends Object> remappingFunction) {
		return params.compute(key, remappingFunction);
	}

	@Override
	public Object merge(String key, Object value, BiFunction<? super Object, ? super Object, ? extends Object> remappingFunction) {
		return params.merge(key, value, remappingFunction);
	}

}
