package com.abacogroup.calculatorengine.sdk.model;

import com.abacogroup.calculatorengine.sdk.proc.CalculationProcedure;
import java.util.Objects;

/**
 * Oggetto contenente i calcoli e la renderizzazione
 * <p>
 * Ogni workflow deve inizializzarlo. vedi {@link CalculationProcedure)}
 *
 * @param <T>
 */
public class CalculationResult<T> {

    private T result;
    private CalculationResultRenderData renderData;

    public CalculationResult(T result) {
        this.result = Objects.requireNonNull(result);
        this.renderData = new CalculationResultRenderData();
    }

    public T getResult() {
        return result;
    }

    public void setResult(T result) {
        this.result = result;
    }

    public CalculationResultRenderData getRenderData() {
        return renderData;
    }

    public void setRenderData(CalculationResultRenderData renderData) {
        this.renderData = renderData;
    }

}
