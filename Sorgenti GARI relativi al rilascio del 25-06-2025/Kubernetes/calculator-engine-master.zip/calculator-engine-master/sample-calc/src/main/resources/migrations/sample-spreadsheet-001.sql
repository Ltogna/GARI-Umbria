drop table if exists clc_cp_result;


create table clc_cp_result
(
    id          bigserial    not null,
    tenant_id   varchar(100) not null,
    party_id    bigint       not null,
    cp_id       bigint       not null,
    description varchar(255) not null,
    dt_insert   timestamp    NOT NULL,

    constraint clc_cp_result_pk primary key (id),
    constraint clc_cp_result_uk1 unique (tenant_id, party_id, cp_id)
);
