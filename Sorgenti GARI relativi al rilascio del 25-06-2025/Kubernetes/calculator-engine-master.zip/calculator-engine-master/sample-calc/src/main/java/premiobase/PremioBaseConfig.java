package premiobase;

import java.time.LocalDate;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(setterPrefix = "set")
@AllArgsConstructor
@NoArgsConstructor
public class PremioBaseConfig {
	private Double tassoRiduzione;
	private List<Ritardo> ritardo;
	private Double pctRiduzioneTitoli;
	private Integer limiteDiscFin;
	private Double tassoDiscFin;
	private Integer supeMinSqm;
	private Double pctPagamentoTitoli;

	@Data
	@Builder(setterPrefix = "set")
	@AllArgsConstructor
	@NoArgsConstructor
	public static class Ritardo {
		private LocalDate from;
		private LocalDate to;
		private Integer giorniRitardo;
		private Double pct;
	}

}

