package premiobase.load;

import com.abacogroup.calculatorengine.sdk.proc.AbstractImportConfigProcedure;
import premiobase.PremioBaseConfig;


public class SampleImportConfigProc extends AbstractImportConfigProcedure<PremioBaseConfig> {


}
