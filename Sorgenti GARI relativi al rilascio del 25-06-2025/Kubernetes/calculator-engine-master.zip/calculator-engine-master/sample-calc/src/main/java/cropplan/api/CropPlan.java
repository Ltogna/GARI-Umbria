package cropplan.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CropPlan {
    @NotNull
    private Long cropPlanId;

    @NotEmpty
    private String cropPlanTypeCode;

    @NotEmpty
    private String cropPlanTypeDescription;

    @NotEmpty
    private String description;

    @NotNull
    private Boolean changesPending;

    @NotNull
    private Boolean readOnly;

    @NotNull
    private Boolean canAddPlots;

    @NotNull
    private List<CropPlanPrint> cropPlanPrints;
}
