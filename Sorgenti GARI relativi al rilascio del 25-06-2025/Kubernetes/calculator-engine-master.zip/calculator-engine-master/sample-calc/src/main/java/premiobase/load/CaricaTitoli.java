package premiobase.load;

import com.abacogroup.calculatorengine.sdk.model.CalculationResult;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import jakarta.ws.rs.client.Client;
import premiobase.AbstractCalculationProcedure;
import premiobase.PremioBase;
import premiobase.load.model.Titolo;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class CaricaTitoli extends AbstractCalculationProcedure {
    public static final String VARIABLE_NAME = "titoli";

    @SuppressWarnings("unchecked")
    public static List<Titolo> getTitoliFromGlobalVars(ProcessData processData) {
        return (List<Titolo>) processData.getGlobalVar(VARIABLE_NAME).orElseThrow();
    }

    @Override
    public CalculationResult<PremioBase> calculate(ProcessData processData, ProcedureEnvironment env, CalculationResult<PremioBase> result) {

        Long applicationId = getApplicationId(processData);

        Client client = env.getJerseyClient().orElseThrow();
        // .. chiamo l'api

        List<Titolo> titoli = new ArrayList<>(100);
        for (int i = 0; i < 100; i++) {
            titoli.add(new Titolo("titolo" + i, new BigDecimal(i * 10), new BigDecimal(i * 200)));
        }

        processData.getGlobalVars().put(VARIABLE_NAME, titoli);
        return result;
    }

}
