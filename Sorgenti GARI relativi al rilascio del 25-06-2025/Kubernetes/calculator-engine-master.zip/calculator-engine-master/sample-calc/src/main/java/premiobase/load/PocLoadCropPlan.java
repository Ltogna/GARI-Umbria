package premiobase.load;

import com.abacogroup.calculatorengine.sdk.client.ClientSupport;
import com.abacogroup.calculatorengine.sdk.exceptions.CalculatorEngineException;
import com.abacogroup.calculatorengine.sdk.model.CalculationResult;
import com.abacogroup.calculatorengine.sdk.proc.H2Procedure;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import cropplan.api.CropPlan;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;
import premiobase.AbstractCalculationProcedure;
import premiobase.PremioBase;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Slf4j
public class PocLoadCropPlan extends AbstractCalculationProcedure {

    public static final String VARIABLE_NAME = "cropPlan";
    final static String CROP_PLAN_API_URL = "crop-plan-api-url";
    final static String CROP_PLAN_TYPECODE_PARAM_NAME = "cropPlanTypeCode";
    final static String CROP_PLAN_TYPECODE_PARAM_VALUE = "CROPPLAN";
    final static long PARTY_ID = 554678L;

    public static CropPlan getCropPlanFromGlobalVars(ProcessData processData) {
        return (CropPlan) processData.getGlobalVar(VARIABLE_NAME).orElseThrow();
    }

    @Override
    public CalculationResult<PremioBase> calculate(ProcessData processData, ProcedureEnvironment env, CalculationResult<PremioBase> result) {
        log.info("start PocLoadCropPlan procedure");
        String serverAddress = env.<String>getProperty(CROP_PLAN_API_URL)
                .orElseThrow(() -> new CalculatorEngineException(String.format("missing property '%s'", CROP_PLAN_API_URL)));

        ClientSupport clientSupport = new ClientSupport(processData, env, serverAddress);

        String api = "{tenant}/public/v1/crop-plans/{businessId}/plans";
        Map<String, Object> pathVariables = Map.of(
                "tenant", processData.getTenantId(),
                "businessId", PARTY_ID
        );

        MultivaluedMap<String, Object> params = new MultivaluedHashMap<>();
        params.put(CROP_PLAN_TYPECODE_PARAM_NAME, List.of(CROP_PLAN_TYPECODE_PARAM_VALUE));

        log.info("Call : " + api);

        CropPlan cropPlan = clientSupport.getElementFromInfiniteResult(api, pathVariables, params,
                new GenericType<>() {
                }, 0);

        log.info("CROP PLAN ID FETCHED : " + cropPlan.getCropPlanId());

        Jdbi jdbi = (Jdbi) processData.getGlobalVars().get(H2Procedure.JDBI_H2_CONNECTION);
        jdbi.useHandle(handleHelper -> {
            String sql = "INSERT INTO clc_cp_result (tenant_id, party_id, cp_id, description, dt_insert)"
                    + " values (?, ?, ?, ?, ?)";

            handleHelper.execute(sql, processData.getTenantId(),
                    PARTY_ID, cropPlan.getCropPlanId(), cropPlan.getDescription(), LocalDateTime.now());
        });

        processData.getGlobalVars().put(VARIABLE_NAME, cropPlan);

        PremioBase premioBase = result.getResult();
        premioBase.setCropPlanId(cropPlan.getCropPlanId());
        premioBase.setDescription(cropPlan.getDescription());

        return result;
    }
}
