package premiobase;

import com.abacogroup.calculatorengine.sdk.model.CalculationResult;
import com.abacogroup.calculatorengine.sdk.proc.CalculationProcedure;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import java.util.Map;

/**
 * entry point per le procedure del workflow
 * <p>
 * Ci si deve preoccupare solamente di implementare <code>buildEmptyResult</code>
 * che restituisce un {@link CalculationResult}. Questo oggetto
 */
public abstract class AbstractCalculationProcedure extends CalculationProcedure<PremioBase, PremioBaseConfig> {

    @Override
    protected CalculationResult<PremioBase> buildEmptyResult() {
        var result = new CalculationResult<>(new PremioBase());

//        Section biss = new Section("BISS", Label.of("Basinc Income Support Scheme"));
//        biss.getGroups().add(new Group("superficieDeterminata", Label.of("Superficie determinata")));
//
//        result.getRenderData().getSections().add(biss);
//        // result.renderData.sections.add(eco);

        return result;
    }

//    protected CalculationResult<PremioBase> getCalculationResult(ProcessData processData) {
//        return processData.<CalculationResult<PremioBase>>getGlobalVar(GLOBAL_VAR_RESULT_NAME).orElseThrow();
//    }

    public Long getApplicationId(ProcessData processData) {
        Map<String, Object> parameters = getWorkflowParameters(processData);
        return ((Number) parameters.get("applicationId")).longValue();
    }


}
