package premiobase;

import lombok.Data;

@Data
public class OptionCodeParam {
	private String optionCode;
}
