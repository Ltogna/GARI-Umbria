package premiobase.load.model;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Titolo {
	private String code;
	private BigDecimal areaSqm;
	private BigDecimal value;
}
