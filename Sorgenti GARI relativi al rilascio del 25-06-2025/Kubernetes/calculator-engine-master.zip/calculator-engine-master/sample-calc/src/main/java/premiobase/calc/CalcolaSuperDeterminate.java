package premiobase.calc;

import com.abacogroup.calculatorengine.sdk.model.CalculationResult;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import premiobase.AbstractCalculationProcedure;
import premiobase.PremioBase;
import premiobase.load.CaricaSuperficiImpegnate;
import premiobase.load.CaricaSuperficieEleggibile;
import premiobase.load.CaricaTitoli;
import java.math.BigDecimal;

public class CalcolaSuperDeterminate extends AbstractCalculationProcedure {
    @Override
    protected CalculationResult<PremioBase> calculate(ProcessData processData, ProcedureEnvironment env, CalculationResult<PremioBase> result)
            throws Exception {

        double supeEleleggibile = CaricaSuperficieEleggibile.getSuperficieEleggibileSqm(processData, "BISS").doubleValue();
        double supeImpegnata = CaricaSuperficiImpegnate.getSuperficieImpegnataSqm(processData, "BISS").doubleValue();

        double supeTitoli = CaricaTitoli.getTitoliFromGlobalVars(processData)
                .stream()
                .map(titolo -> titolo.getAreaSqm())
                .reduce(BigDecimal.ZERO, BigDecimal::add).doubleValue();


        double supeRich = supeTitoli < supeImpegnata ? supeTitoli : supeImpegnata;

        double scostamento = supeEleleggibile - supeRich;
        if (scostamento < 0) {
            scostamento = -scostamento;
        }

        double percScostamento = supeEleleggibile == 0 ? 1.0 : scostamento / supeEleleggibile;

        double supeDeterminata = 0.0;
        if (scostamento <= 1000 && percScostamento <= 0.2) {
            supeDeterminata = supeRich;
        } else {
            supeDeterminata = supeEleleggibile;
        }

        result.getResult().setSupeEleleggibile(supeEleleggibile);
        result.getResult().setSupeImpegnata(supeImpegnata);
        result.getResult().setSupeTitoli(supeTitoli);
        result.getResult().setSupeRich(supeRich);
        result.getResult().setScostamento(scostamento);
        result.getResult().setPercScostamento(percScostamento);
        result.getResult().setSupeDeterminata(supeDeterminata);


        return result;
    }
}
