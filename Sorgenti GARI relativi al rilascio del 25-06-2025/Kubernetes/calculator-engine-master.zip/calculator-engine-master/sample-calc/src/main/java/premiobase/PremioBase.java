package premiobase;

import lombok.Data;

@Data
public class PremioBase {

    private Long cropPlanId;
    private String description;


    //
    private double supeEleleggibile = 0d;
    private double supeImpegnata = 0d;
    private double supeTitoli = 0d;
    private double supeRich = 0d;
    private double scostamento = 0d;
    private double percScostamento = 0d;
    private double supeDeterminata = 0d;
}
