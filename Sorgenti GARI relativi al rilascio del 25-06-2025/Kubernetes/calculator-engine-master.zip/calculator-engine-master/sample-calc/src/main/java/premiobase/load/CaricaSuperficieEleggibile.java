package premiobase.load;

import com.abacogroup.calculatorengine.sdk.model.CalculationResult;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import jakarta.ws.rs.client.Client;
import premiobase.AbstractCalculationProcedure;
import premiobase.OptionCodeParam;
import premiobase.PremioBase;
import java.math.BigDecimal;

public class CaricaSuperficieEleggibile extends AbstractCalculationProcedure {
    public static final String VARIABLE_NAME = "superficieEleggibileSqm";

    public static BigDecimal getSuperficieEleggibileSqm(ProcessData processData, String optionCode) {
        return (BigDecimal) processData.getGlobalVar(VARIABLE_NAME + optionCode).orElseThrow();
    }

    @Override
    public CalculationResult<PremioBase> calculate(ProcessData processData, ProcedureEnvironment env, CalculationResult<PremioBase> result) {
        Long applicationId = getApplicationId(processData);
        OptionCodeParam param = processData.getProcedureParameter(OptionCodeParam.class);

        Client client = env.getJerseyClient().orElseThrow();
        // .. chiamo l'api

        processData.getGlobalVars().put(VARIABLE_NAME + param.getOptionCode(), new BigDecimal(130_000));

        return result;
    }

}
