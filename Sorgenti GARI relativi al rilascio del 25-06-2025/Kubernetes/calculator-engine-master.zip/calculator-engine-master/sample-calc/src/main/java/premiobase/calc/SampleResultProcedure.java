package premiobase.calc;

import com.abacogroup.calculatorengine.sdk.model.CalculationResult;
import com.abacogroup.calculatorengine.sdk.model.CalculationResultRenderData;
import com.abacogroup.calculatorengine.sdk.model.render.Group;
import com.abacogroup.calculatorengine.sdk.model.render.Label;
import com.abacogroup.calculatorengine.sdk.model.render.Section;
import com.abacogroup.calculatorengine.sdk.model.variable.Variable;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import premiobase.AbstractCalculationProcedure;
import premiobase.PremioBase;

@Slf4j
public class SampleResultProcedure extends AbstractCalculationProcedure {
    @Override
    protected CalculationResult<PremioBase> calculate(ProcessData processData, ProcedureEnvironment env, CalculationResult<PremioBase> currentResult)
            throws Exception {
        log.info("start RenderResultProcedure procedure");

        PremioBase result = currentResult.getResult();
        CalculationResultRenderData renderData = currentResult.getRenderData();
        buildSampleRenderData(renderData, result);

        return currentResult;

    }

    private void buildSampleRenderData(CalculationResultRenderData renderData, PremioBase result) {

        String tagText = "TEXT";
        String tagNumber = "NUMBER";
        String tagDate = "DATE";

        //nella parte iniziale dei tag mettiamo solo TEXT,NUMBER,DATE con label fissa in italiano
        renderData.getTagLabels().put(tagText, Label.of(Map.of("it", "Text")));
        renderData.getTagLabels().put(tagNumber, Label.of(Map.of("it", "Number")));
        renderData.getTagLabels().put(tagDate, Label.of(Map.of("it", "Data")));

        //Sezione1 (con titolo non internazionalizzato, cioè stringa fissa) senza documentazione
        Section sezione1 = new Section("Sezione_1", Label.of("Sezione 1"));

        //Gruppo1-1 (con titolo non internazionalizzato, cioè stringa fissa) senza documentazione
        Group group11 = new Group("Gruppo1-1", Label.of("Gruppo1-1 con titolo non internazionalizzato"));
        sezione1.getGroups().add(group11);

        //una variabile per ogni tipo, titolo non internazionalizzato che indica il tipo di variabile.
        // Ogni variabile avra sia il tag GRUPPO1.1 che un tag tra TEXT, NUMBER, DATE in base alla macroclasse del tipo.
        // tutte con documentazione che indica il tipo non internazionalizzata
        String tag11 = "GRUPPO1.1";

        group11.addVariable(Variable
                .withCode("AREA_SQM_VAR")
                .withTags(tag11, tagNumber)
                .withDocumentation("documentazione per var di tipo AreaSqm")
                .withLabel("questa var è di tipo AreaSqm")
                .ofAreaSqm(10)
        );

        group11.addVariable(Variable
                .withCode("DOUBLE_VAR")
                .withTags(tag11, tagNumber)
                .withDocumentation("documentazione per var di tipo Double")
                .withLabel("questa var è di tipo Double")
                .ofDouble(11d)
        );

        group11.addVariable(Variable
                .withCode("LONG_VAR")
                .withTags(tag11, tagNumber)
                .withDocumentation("documentazione per var di tipo Long")
                .withLabel("questa var è di tipo Long")
                .ofLong(12L)
        );

        group11.addVariable(Variable
                .withCode("LENGTH_VAR")
                .withTags(tag11, tagNumber)
                .withDocumentation("documentazione per var di tipo LengthMt")
                .withLabel("questa var è di tipo LengthMt")
                .ofLengthMt(12_000)
        );


        group11.addVariable(Variable
                .withCode("MONEY_VAR")
                .withTags(tag11, tagNumber)
                .withDocumentation("documentazione per var di tipo Money")
                .withLabel("questa var è di tipo Money")
                .ofMoney(1750.23)
        );

        group11.addVariable(Variable
                .withCode("DATE_VAR")
                .withTags(tag11, tagDate)
                .withDocumentation("documentazione per var di tipo LocalDate")
                .withLabel("questa var è di tipo LocalDate")
                .ofLocalDate(LocalDate.of(2023, 3, 21))
        );

        group11.addVariable(Variable
                .withCode("DATETIME_VAR")
                .withTags(tag11, tagDate)
                .withDocumentation("documentazione per var di tipo LocalDateTime")
                .withLabel("questa var è di tipo LocalDateTime")
                .ofLocalDateTime(LocalDateTime.of(2023, 3, 21, 18, 15, 59))
        );


        group11.addVariable(Variable
                .withCode("PERC_VAR")
                .withTags(tag11, tagNumber)
                .withDocumentation("documentazione per var di tipo Percentage")
                .withLabel("questa var è di tipo Percentage")
                .ofPercentage(BigDecimal.valueOf(90))
        );

        group11.addVariable(Variable
                .withCode("STRING_VAR")
                .withTags(tag11, tagText)
                .withDocumentation("documentazione per var di tipo String")
                .withLabel("questa var è di tipo String")
                .ofString("lorem ipsum")
        );

        group11.addVariable(Variable
                .withCode("OFFSETDATETIME_VAR")
                .withTags(tag11, tagDate)
                .withDocumentation("documentazione per var di tipo OffsetDateTime")
                .withLabel("questa var è di tipo OffsetDateTime")
                .ofOffsetDateTime(OffsetDateTime.of(2024, 12, 31, 23, 59, 59, 0, ZoneOffset.UTC))
        );

        //Gruppo1-2 (con titolo in italiano ed in inglese) con documentazione non internazionalizzata
        Group group12 = new Group("Gruppo1-2", Label.of(Map.of("it", "Gruppo 1-2", "en", "Group 1-2")), Label.of(""));
        group12.getDocumentation().setLabel("documentazione non internazionalizzata per Gruppo1-2");
        sezione1.getGroups().add(group12);

        //3 variabili con tag GRUPPO1.2 (tipi quello che vuoi, tutte con titolo internazionalizzato in inglese e italiano, titoli diversi, quelli che vuoi) senza documentazione

        group12.addVariable(Variable
                .withCode("AREA")
                .withTags("GRUPPO1.2")
                .withLabel(Map.of("it", "Label it AreaSqm", "en", "Label en AreaSqm"))
                .ofAreaSqm(120)
        );

        group12.addVariable(Variable
                .withCode("EURO")
                .withTags("GRUPPO1.2")
                .withLabel(Map.of("it", "valore in euro", "en", "euro value"))
                .ofMoney(2042.88)
        );


        group12.addVariable(Variable
                .withCode("LENGTH")
                .withTags("GRUPPO1.2")
                .withLabel(Map.of("it", "lunghezza", "en", "length"))
                .ofLengthMt(1000)
        );

        //------------------

        // Sezione2 (con titolo in italiano ed in inglese) con documentazione a caso non internazionalizzata
        Section sezione2 = new Section("Sezione_2", Label.of(Map.of("it", "Sezione 2", "en", "Section 2")), Label.of(""));
        sezione2.getDocumentation().setLabel("documentazione sezione 2 non internazionalizzata");

        //Gruppo2-1 (con titolo non internazionalizzato, cioè stringa fissa) con documentazione a caso in italiano ed inglese
        Group group21 = new Group("Gruppo2-1", Label.of("Gruppo2-1 con titolo non internazionalizzato"));


        //4 variabili con tag GRUPPO2.1 (tutte con titolo non internazionalizzato, titoli diversi, quelli che vuoi sia come titoli che come tipo) senza documentazione
        group21.addVariable(Variable
                .withCode("DIST")
                .withTags("GRUPPO2.1")
                .withLabel("distanza")
                .ofLengthMt(1000)
        );


        group21.addVariable(Variable
                .withCode("NOTE")
                .withTags("GRUPPO2.1")
                .withLabel("note")
                .ofString("nota 1")
        );

        //1 variabile senza tag (tutte con titolo non internazionalizzato, titoli diversi, quelli che vuoi sia come titoli che come tipo).
        // questa non metterla come ultima variabile del gruppo ma mettila in mezzo a quelle con il tag con documentazione internazionalizzata in italiano e inglese
        group21.addVariable(Variable
                .withCode("CODE")
                .withLabel("codice fiscale o cuaa")
                .ofString("codice fiscale"));

        group21.addVariable(Variable
                .withCode("PERC")
                .withTags("GRUPPO2.1")
                .withLabel("percentuale")
                .ofPercentage(BigDecimal.valueOf(100))
        );

        group21.addVariable(Variable
                .withCode("EXP")
                .withTags("GRUPPO2.1")
                .withLabel("scadenza")
                .ofLocalDate(LocalDate.of(2023, 12, 31))
        );


        sezione2.addGroup(group21);
        renderData.getSections().add(sezione1);
        renderData.getSections().add(sezione2);

    }

}
