package premiobase.calc;

import com.abacogroup.calculatorengine.sdk.model.CalculationResult;
import com.abacogroup.calculatorengine.sdk.model.CalculationResultRenderData;
import com.abacogroup.calculatorengine.sdk.model.render.Group;
import com.abacogroup.calculatorengine.sdk.model.render.Label;
import com.abacogroup.calculatorengine.sdk.model.render.Section;
import com.abacogroup.calculatorengine.sdk.model.variable.Variable;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import java.math.BigDecimal;
import lombok.extern.slf4j.Slf4j;
import premiobase.AbstractCalculationProcedure;
import premiobase.PremioBase;

@Slf4j
public class RenderResultProcedure extends AbstractCalculationProcedure {
    @Override
    protected CalculationResult<PremioBase> calculate(ProcessData processData, ProcedureEnvironment env, CalculationResult<PremioBase> currentResult)
            throws Exception {
        log.info("start RenderResultProcedure procedure");

        PremioBase result = currentResult.getResult();
        CalculationResultRenderData renderData = currentResult.getRenderData();
        buildRenderData(renderData, result);
        //buildSampleRenderData(renderData, result);

        return currentResult;

    }


    private void buildRenderData(CalculationResultRenderData renderData, PremioBase result) {
        Section biss = new Section("BISS", Label.of("Basinc Income Support Scheme"));
        biss.getGroups().add(new Group("superficieDeterminata", Label.of("Superficie determinata")));
        renderData.getSections().add(biss);


        //
        Variable variable = Variable
                .withCode("SUPERFICIE_IMEGNATA")
                .withDocumentation("Superficie impegnata in domanda a premio base")
                .withLabel("Superficie imegnata")
                .ofAreaSqm(result.getSupeImpegnata());

        renderData
                .getSection("BISS")
                .getGroup("superficieDeterminata")
                .addVariable(variable);

        //
        variable = Variable
                .withCode("SUPERFICIE_TITOLI")
                .withDocumentation("Superficie titoli")
                .withLabel("Superficie titoli")
                .ofAreaSqm(result.getSupeTitoli());

        renderData
                .getSection("BISS")
                .getGroup("superficieDeterminata")
                .addVariable(variable);

        //
        variable = Variable
                .withCode("SUPERFICIE_RICHIESTA")
                .withDocumentation("Superficie richiesta a premio base")
                .withLabel("Superficie richiesta")
                .ofAreaSqm(result.getSupeRich());

        renderData
                .getSection("BISS")
                .getGroup("superficieDeterminata")
                .addVariable(variable);

        //
        variable = Variable
                .withCode("SUPERFICIE_ELEGGIBILE")
                .withDocumentation("Superficie eleggibile a premio base")
                .withLabel("Superficie eleggibile")
                .ofAreaSqm(result.getSupeEleleggibile());

        renderData
                .getSection("BISS")
                .getGroup("superficieDeterminata")
                .addVariable(variable);

        //
        variable = Variable
                .withCode("SUPERFICIE_SCOSTAMENTO")
                .withDocumentation("Superficie scostamento")
                .withLabel("Superficie scostamento")
                .ofAreaSqm(result.getScostamento());

        renderData
                .getSection("BISS")
                .getGroup("superficieDeterminata")
                .addVariable(variable);

        //
        variable = Variable
                .withCode("PERCENTUALE_SCOSTAMENTO")
                .withDocumentation("Percentuale di scostamento")
                .withLabel("Percentuale di scostamento")
                .ofPercentage(BigDecimal.valueOf(result.getPercScostamento() * 100));

        renderData
                .getSection("BISS")
                .getGroup("superficieDeterminata")
                .addVariable(variable);

        //
        variable = Variable
                .withCode("SUPERFICIE_DETERMINATA")
                .withDocumentation("Superficie determinata")
                .withLabel("Superficie determinata")
                .ofAreaSqm(result.getSupeDeterminata());

        renderData
                .getSection("BISS")
                .getGroup("superficieDeterminata")
                .addVariable(variable);
    }
}
