package premiobase;

import com.abacogroup.calculatorengine.sdk.core.testsupport.CalculatorWorkflowTestSupport;
import com.abacogroup.calculatorengine.sdk.model.CalculationResult;
import com.abacogroup.calculatorengine.sdk.proc.AbstractProcedure;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import jakarta.ws.rs.client.Client;
import java.util.TimeZone;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@Disabled
@ExtendWith(DropwizardExtensionsSupport.class)
class FullTest {

    private static final String WORKFLOW_CODE = "SAMPLE-CALC";
    private static final String TENANT_ID = "master";
    private static final String ENVID = "test";

    @SneakyThrows
    @Test
    void full_integration_test() {

        Environment environment = new Environment(ENVID);
        Client client = new JerseyClientBuilder(environment).build("cli");

        ProcessTransitionResult transitionResult = CalculatorWorkflowTestSupport.buildFlow(WORKFLOW_CODE, TENANT_ID)
                .withDbConnection("jdbc:postgresql://localhost:35442/calculator_engine_test", "postgres", "postgres")
                .withObjectMapper(environment.getObjectMapper())
                .withClient(client)
                .withRealAuthContext("https://iacs-dev.fe.abacogroup.eu/sso2", "f3831a034cfd85301170f6395d7c3386",
                        TENANT_ID, "admin")
                .withEnv(ENVID)
                .withConfigJson("{\"tassoRiduzione\":0.01,\"ritardo\":[{\"from\":\"2023-05-16\",\"to\":\"2023-05-16\",\"giorniRitardo\":1,\"pct\":0.01},{\"from\":\"2023-05-17\",\"to\":\"2023-05-20\",\"giorniRitardo\":1,\"pct\":0.02}],\"pctRiduzioneTitoli\":0.7,\"limiteDiscFin\":2000,\"tassoDiscFin\":0.03,\"supeMinSqm\":5000,\"pctPagamentoTitoli\":1}")
                .putInputParam("applicationId", 112233)

                .setUp()
                .execute();

        Assertions.assertFalse(transitionResult.getLastTransitionLog().isFailed());
        Assertions.assertTrue(transitionResult.isProcessEnded());


        CalculationResult<PremioBase> calculationResult = (CalculationResult<PremioBase>) transitionResult
                .getGlobalVars().get(AbstractProcedure.GLOBAL_VAR_RESULT_NAME);

        ObjectMapper mapper = objectMapper();
        System.out.println(calculationResult.getResult());
        String dataJson = mapper.writeValueAsString(calculationResult.getResult());
        String renderDataJson = mapper.writeValueAsString(calculationResult.getRenderData());


        String expectedRenderData = "{\"sections\":[{\"code\":\"BISS\",\"label\":{\"label\":\"Basinc Income Support Scheme\",\"i18nLabels\":null},\"documentation\":null,\"groups\":[{\"code\":\"superficieDeterminata\",\"label\":{\"label\":\"Superficie determinata\",\"i18nLabels\":null},\"documentation\":null,\"variables\":[{\"code\":\"SUPERFICIE_IMEGNATA\",\"label\":{\"label\":\"Superficie imegnata\",\"i18nLabels\":null},\"documentation\":{\"label\":\"Superficie impegnata in domanda a premio base\",\"i18nLabels\":null},\"kind\":\"AREA_SQM\",\"value\":150000.0,\"tags\":[]},{\"code\":\"SUPERFICIE_TITOLI\",\"label\":{\"label\":\"Superficie titoli\",\"i18nLabels\":null},\"documentation\":{\"label\":\"Superficie titoli\",\"i18nLabels\":null},\"kind\":\"AREA_SQM\",\"value\":49500.0,\"tags\":[]},{\"code\":\"SUPERFICIE_RICHIESTA\",\"label\":{\"label\":\"Superficie richiesta\",\"i18nLabels\":null},\"documentation\":{\"label\":\"Superficie richiesta a premio base\",\"i18nLabels\":null},\"kind\":\"AREA_SQM\",\"value\":49500.0,\"tags\":[]},{\"code\":\"SUPERFICIE_ELEGGIBILE\",\"label\":{\"label\":\"Superficie eleggibile\",\"i18nLabels\":null},\"documentation\":{\"label\":\"Superficie eleggibile a premio base\",\"i18nLabels\":null},\"kind\":\"AREA_SQM\",\"value\":130000.0,\"tags\":[]},{\"code\":\"SUPERFICIE_SCOSTAMENTO\",\"label\":{\"label\":\"Superficie scostamento\",\"i18nLabels\":null},\"documentation\":{\"label\":\"Superficie scostamento\",\"i18nLabels\":null},\"kind\":\"AREA_SQM\",\"value\":80500.0,\"tags\":[]},{\"code\":\"PERCENTUALE_SCOSTAMENTO\",\"label\":{\"label\":\"Percentuale di scostamento\",\"i18nLabels\":null},\"documentation\":{\"label\":\"Percentuale di scostamento\",\"i18nLabels\":null},\"kind\":\"PERCENTAGE\",\"value\":61.92307692307693,\"tags\":[]},{\"code\":\"SUPERFICIE_DETERMINATA\",\"label\":{\"label\":\"Superficie determinata\",\"i18nLabels\":null},\"documentation\":{\"label\":\"Superficie determinata\",\"i18nLabels\":null},\"kind\":\"AREA_SQM\",\"value\":130000.0,\"tags\":[]}]}]}],\"tagLabels\":{}}";
        Assertions.assertEquals(expectedRenderData, renderDataJson);

        String expData = "{\"cropPlanId\":574,\"description\":\"\\\"Piano colturale\\\" inserito dal sistema\",\"supeEleleggibile\":130000.0,\"supeImpegnata\":150000.0,\"supeTitoli\":49500.0,\"supeRich\":49500.0,\"scostamento\":80500.0,\"percScostamento\":0.6192307692307693,\"supeDeterminata\":130000.0}";
        Assertions.assertEquals(expData, dataJson);

        //System.out.println(dataJson);
    }




    protected ObjectMapper objectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper
                .setTimeZone(TimeZone.getDefault())
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        return objectMapper;
    }
}
