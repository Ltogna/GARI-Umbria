package premiobase.calc;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.calculatorengine.sdk.model.CalculationResult;
import com.abacogroup.calculatorengine.sdk.model.CalculationResultRenderData;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import premiobase.PremioBase;

@ExtendWith(DropwizardExtensionsSupport.class)
class SampleResultProcedureTest {


    @Test
    void testRender() throws Exception {
        SampleResultProcedure sampleResultProcedure = new SampleResultProcedure();
        CalculationResult<PremioBase> currentResult = new CalculationResult<>(new PremioBase());
        sampleResultProcedure.calculate(null, null, currentResult);
        CalculationResultRenderData renderData = currentResult.getRenderData();

        String offsetDateTimeVarExpected = objectMapper().writeValueAsString(OffsetDateTime.of(2024, 12, 31, 23, 59, 59, 0, ZoneOffset.UTC));
        String expected = "{\"sections\":[{\"code\":\"Sezione_1\",\"label\":{\"label\":\"Sezione 1\",\"i18nLabels\":null},\"documentation\":null,\"groups\":[{\"code\":\"Gruppo1-1\",\"label\":{\"label\":\"Gruppo1-1 con titolo non internazionalizzato\",\"i18nLabels\":null},\"documentation\":null,\"variables\":[{\"code\":\"AREA_SQM_VAR\",\"label\":{\"label\":\"questa var è di tipo AreaSqm\",\"i18nLabels\":null},\"documentation\":{\"label\":\"documentazione per var di tipo AreaSqm\",\"i18nLabels\":null},\"kind\":\"AREA_SQM\",\"value\":10,\"tags\":[\"GRUPPO1.1\",\"NUMBER\"]},{\"code\":\"DOUBLE_VAR\",\"label\":{\"label\":\"questa var è di tipo Double\",\"i18nLabels\":null},\"documentation\":{\"label\":\"documentazione per var di tipo Double\",\"i18nLabels\":null},\"kind\":\"NUMBER_DOUBLE\",\"value\":11.0,\"tags\":[\"GRUPPO1.1\",\"NUMBER\"]},{\"code\":\"LONG_VAR\",\"label\":{\"label\":\"questa var è di tipo Long\",\"i18nLabels\":null},\"documentation\":{\"label\":\"documentazione per var di tipo Long\",\"i18nLabels\":null},\"kind\":\"NUMBER_LONG\",\"value\":12,\"tags\":[\"GRUPPO1.1\",\"NUMBER\"]},{\"code\":\"LENGTH_VAR\",\"label\":{\"label\":\"questa var è di tipo LengthMt\",\"i18nLabels\":null},\"documentation\":{\"label\":\"documentazione per var di tipo LengthMt\",\"i18nLabels\":null},\"kind\":\"LENGTH_MT\",\"value\":12000,\"tags\":[\"GRUPPO1.1\",\"NUMBER\"]},{\"code\":\"MONEY_VAR\",\"label\":{\"label\":\"questa var è di tipo Money\",\"i18nLabels\":null},\"documentation\":{\"label\":\"documentazione per var di tipo Money\",\"i18nLabels\":null},\"kind\":\"MONEY\",\"value\":1750.23,\"tags\":[\"GRUPPO1.1\",\"NUMBER\"]},{\"code\":\"DATE_VAR\",\"label\":{\"label\":\"questa var è di tipo LocalDate\",\"i18nLabels\":null},\"documentation\":{\"label\":\"documentazione per var di tipo LocalDate\",\"i18nLabels\":null},\"kind\":\"DATE\",\"value\":\"2023-03-21\",\"tags\":[\"GRUPPO1.1\",\"DATE\"]},{\"code\":\"DATETIME_VAR\",\"label\":{\"label\":\"questa var è di tipo LocalDateTime\",\"i18nLabels\":null},\"documentation\":{\"label\":\"documentazione per var di tipo LocalDateTime\",\"i18nLabels\":null},\"kind\":\"DATE_TIME\",\"value\":\"2023-03-21T18:15:59\",\"tags\":[\"GRUPPO1.1\",\"DATE\"]},{\"code\":\"PERC_VAR\",\"label\":{\"label\":\"questa var è di tipo Percentage\",\"i18nLabels\":null},\"documentation\":{\"label\":\"documentazione per var di tipo Percentage\",\"i18nLabels\":null},\"kind\":\"PERCENTAGE\",\"value\":90,\"tags\":[\"GRUPPO1.1\",\"NUMBER\"]},{\"code\":\"STRING_VAR\",\"label\":{\"label\":\"questa var è di tipo String\",\"i18nLabels\":null},\"documentation\":{\"label\":\"documentazione per var di tipo String\",\"i18nLabels\":null},\"kind\":\"STRING\",\"value\":\"lorem ipsum\",\"tags\":[\"GRUPPO1.1\",\"TEXT\"]},{\"code\":\"OFFSETDATETIME_VAR\",\"label\":{\"label\":\"questa var è di tipo OffsetDateTime\",\"i18nLabels\":null},\"documentation\":{\"label\":\"documentazione per var di tipo OffsetDateTime\",\"i18nLabels\":null},\"kind\":\"DATE_TIME\",\"value\":"+offsetDateTimeVarExpected+",\"tags\":[\"GRUPPO1.1\",\"DATE\"]}]},{\"code\":\"Gruppo1-2\",\"label\":{\"label\":null,\"i18nLabels\":{\"en\":\"Group 1-2\",\"it\":\"Gruppo 1-2\"}},\"documentation\":{\"label\":\"documentazione non internazionalizzata per Gruppo1-2\",\"i18nLabels\":null},\"variables\":[{\"code\":\"AREA\",\"label\":{\"label\":null,\"i18nLabels\":{\"en\":\"Label en AreaSqm\",\"it\":\"Label it AreaSqm\"}},\"documentation\":null,\"kind\":\"AREA_SQM\",\"value\":120,\"tags\":[\"GRUPPO1.2\"]},{\"code\":\"EURO\",\"label\":{\"label\":null,\"i18nLabels\":{\"en\":\"euro value\",\"it\":\"valore in euro\"}},\"documentation\":null,\"kind\":\"MONEY\",\"value\":2042.88,\"tags\":[\"GRUPPO1.2\"]},{\"code\":\"LENGTH\",\"label\":{\"label\":null,\"i18nLabels\":{\"en\":\"length\",\"it\":\"lunghezza\"}},\"documentation\":null,\"kind\":\"LENGTH_MT\",\"value\":1000,\"tags\":[\"GRUPPO1.2\"]}]}]},{\"code\":\"Sezione_2\",\"label\":{\"label\":null,\"i18nLabels\":{\"en\":\"Section 2\",\"it\":\"Sezione 2\"}},\"documentation\":{\"label\":\"documentazione sezione 2 non internazionalizzata\",\"i18nLabels\":null},\"groups\":[{\"code\":\"Gruppo2-1\",\"label\":{\"label\":\"Gruppo2-1 con titolo non internazionalizzato\",\"i18nLabels\":null},\"documentation\":null,\"variables\":[{\"code\":\"DIST\",\"label\":{\"label\":\"distanza\",\"i18nLabels\":null},\"documentation\":null,\"kind\":\"LENGTH_MT\",\"value\":1000,\"tags\":[\"GRUPPO2.1\"]},{\"code\":\"NOTE\",\"label\":{\"label\":\"note\",\"i18nLabels\":null},\"documentation\":null,\"kind\":\"STRING\",\"value\":\"nota 1\",\"tags\":[\"GRUPPO2.1\"]},{\"code\":\"CODE\",\"label\":{\"label\":\"codice fiscale o cuaa\",\"i18nLabels\":null},\"documentation\":null,\"kind\":\"STRING\",\"value\":\"codice fiscale\",\"tags\":[]},{\"code\":\"PERC\",\"label\":{\"label\":\"percentuale\",\"i18nLabels\":null},\"documentation\":null,\"kind\":\"PERCENTAGE\",\"value\":100,\"tags\":[\"GRUPPO2.1\"]},{\"code\":\"EXP\",\"label\":{\"label\":\"scadenza\",\"i18nLabels\":null},\"documentation\":null,\"kind\":\"DATE\",\"value\":\"2023-12-31\",\"tags\":[\"GRUPPO2.1\"]}]}]}],\"tagLabels\":{\"DATE\":{\"label\":null,\"i18nLabels\":{\"it\":\"Data\"}},\"NUMBER\":{\"label\":null,\"i18nLabels\":{\"it\":\"Number\"}},\"TEXT\":{\"label\":null,\"i18nLabels\":{\"it\":\"Text\"}}}}";
        String actual = objectMapper().writeValueAsString(renderData);


        System.out.println(objectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(renderData));


        assertEquals(expected, actual);

    }


    protected ObjectMapper objectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper
                .setTimeZone(TimeZone.getDefault())
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        return objectMapper;
    }
}
