package premiobase.calc;

import com.abacogroup.workflow.sdk.beans.testsupport.ProcedureEnvironmentTestSupport;
import com.abacogroup.workflow.sdk.beans.testsupport.ProcessDataTestSupport;
import premiobase.load.CaricaSuperficiImpegnate;
import premiobase.load.CaricaSuperficieEleggibile;
import premiobase.load.CaricaTitoli;
import premiobase.load.model.Titolo;

import java.math.BigDecimal;
import java.util.List;

public class ByHand {

    public static void main(String[] args) throws Exception {

        ProcessDataTestSupport processData = new ProcessDataTestSupport();
        processData.getGlobalVars().put(CaricaTitoli.VARIABLE_NAME, List.of(new Titolo("a", new BigDecimal(10_000), new BigDecimal(234))));
        processData.getGlobalVars().put(CaricaSuperficiImpegnate.VARIABLE_NAME + "BISS", new BigDecimal(150_000));
        processData.getGlobalVars().put(CaricaSuperficieEleggibile.VARIABLE_NAME + "BISS", new BigDecimal(130_000));

        CalcolaSuperDeterminate proc = new CalcolaSuperDeterminate();
        proc.execute(processData, new ProcedureEnvironmentTestSupport());

        System.out.println(processData.getGlobalVars());
    }

}
