import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Disabled;

import java.nio.charset.StandardCharsets;

import static com.abacogroup.calculatorengine.core.service.impl.PublishToRabbitMq.EXCHANGE;

@Slf4j
@Disabled
public class ListenerDevTest {

    // ----- startLister -----
    public static void main(String[] args) {
        ListenerDevTest listenerDevTest = new ListenerDevTest();
        listenerDevTest.listenPrintEvents(listenerDevTest.createConnection());
    }


    @SneakyThrows
    private Connection createConnection() {
        ConnectionFactory factory = new ConnectionFactory();

        //factory.setHost(...);
        //factory.setUsername(...);
        //factory.setPassword(...);
        //factory.setVirtualHost(...);
        factory.setPort(5678);

        factory.setAutomaticRecoveryEnabled(true);

        Connection connection = factory.newConnection();

        return connection;
    }

    @SneakyThrows
    private void listenPrintEvents(Connection rabbitmqConnection) {
        Channel channel = rabbitmqConnection.createChannel();

        channel.exchangeDeclare(EXCHANGE, "topic", true);
        String queueName = channel.queueDeclare().getQueue();

        channel.queueBind(queueName, EXCHANGE, "calculator-engine-job.#");

        DeliverCallback deliverCallback = (consumerTag, delivery) -> {
            String message = new String(delivery.getBody(), StandardCharsets.UTF_8);
            String routingKey = delivery.getEnvelope().getRoutingKey();
            log.info(" [\uD83D\uDC07 \uD83D\uDDA8 \uD83D\uDC3D {}] Received '{}':'{}'",
                    routingKey.endsWith(".error") ? "❌" : "\uD83D\uDC4C", routingKey, message);
        };
        channel.basicConsume(queueName, true, deliverCallback, consumerTag -> {
        });
    }


}
