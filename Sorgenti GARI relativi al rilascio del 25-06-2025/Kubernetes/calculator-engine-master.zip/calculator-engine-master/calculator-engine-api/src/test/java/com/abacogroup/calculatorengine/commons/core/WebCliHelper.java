package com.abacogroup.calculatorengine.commons.core;

import com.abacogroup.calculatorengine.CalculatorEngineConfiguration;
import com.abacogroup.calculatorengine.TestCalculatorEngineApplication;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.AuthDynamicFeature;
import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.auth.basic.BasicCredentialAuthFilter;
import io.dropwizard.testing.junit5.DropwizardAppExtension;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import java.util.Base64;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import org.glassfish.jersey.server.filter.RolesAllowedDynamicFeature;

public class WebCliHelper {

	public static final String TENANT_DEFAULT_CODE = "master";

	public static final String BASIC_USERNAME = "test-user@example";
	public static final String BASIC_CREDENTIALS = "Basic " + Base64.getEncoder().encodeToString(String.format("%s:secret", BASIC_USERNAME).getBytes());

	public static ResourceExtension createEXT(Object resource) {

		return ResourceExtension.builder()
				.setMapper(TestCalculatorEngineApplication.getObjectMapper())
				.addProvider(new AuthDynamicFeature(new BasicCredentialAuthFilter.Builder<User>()
						.setAuthenticator(credentials -> Optional.of(new User(credentials.getUsername(), TENANT_DEFAULT_CODE)))
						.setAuthorizer((principal, role, requestContext) -> true)
						.buildAuthFilter()))
				.addProvider(RolesAllowedDynamicFeature.class)
				.addProvider(new AuthValueFactoryProvider.Binder<>(User.class))
				.addProvider(new MultitenantFilter("tenant"))
				.addResource(resource)
				.build();
	}

	public static <T> T executeGet(DropwizardAppExtension<CalculatorEngineConfiguration> EXT, String uri,
			Map<String, Object> params, String credentials,
			Class<T> response) {

		uri = String.format("http://localhost:%d%s", EXT.getLocalPort(), uri);
		WebTarget wt = EXT.client().target(uri);

		wt = addQueryParamsFromMap(params, wt);
		return wt
				.request(MediaType.APPLICATION_JSON)
				.header(HttpHeaders.AUTHORIZATION, credentials)
				.get(response);
	}

	public static <T> T executeGet(ResourceExtension EXT, String uri, Map<String, Object> params, String credentials,
			Class<T> response) {
		WebTarget wt = EXT.target(uri);

		wt = addQueryParamsFromMap(params, wt);
		return wt
				.request(MediaType.APPLICATION_JSON)
				.header(HttpHeaders.AUTHORIZATION, credentials)
				.get(response);
	}

	public static <T> T executePost(DropwizardAppExtension<CalculatorEngineConfiguration> EXT, String uri, T entity,
			String credentials,
			Class<T> response) {
		uri = String.format("http://localhost:%d%s", EXT.getLocalPort(), uri);
		WebTarget wt = EXT.client().target(uri);
		return post(entity, credentials, response, wt);
	}

	public static <R, E> R executePost(ResourceExtension EXT, String url, E entity, String credentials,
			Class<R> response) {
		WebTarget wt = EXT.target(url);
		return post(entity, credentials, response, wt);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static <T> T executePostNoBody(ResourceExtension EXT, String url, T entity, Map params, String credentials,
			Class<T> response) {
		WebTarget wt = EXT.target(url);
		wt = addQueryParamsFromMap(params, wt);
		return post(entity, credentials, response, wt);
	}

	public static <T> T executePut(DropwizardAppExtension<CalculatorEngineConfiguration> EXT, String uri, T entity,
			String credentials,
			Class<T> response) {
		uri = String.format("http://localhost:%d%s", EXT.getLocalPort(), uri);
		WebTarget wt = EXT.client().target(uri);
		return put(entity, credentials, response, wt);
	}

	public static <R, E> R executePut(ResourceExtension EXT, String URI, E entity, String credentials, Class<R> response) {
		WebTarget wt = EXT.target(URI);
		return put(entity, credentials, response, wt);
	}

	public static <T> T executeDelete(DropwizardAppExtension<CalculatorEngineConfiguration> EXT, String uri, String credentials,
			Class<T> response) {
		uri = String.format("http://localhost:%d%s", EXT.getLocalPort(), uri);
		WebTarget wt = EXT.client().target(uri);
		return delete(credentials, response, wt);
	}

	public static <T> T executeDelete(ResourceExtension EXT, String url, String credentials,
			Class<T> response) {
		WebTarget wt = EXT.target(url);
		return delete(credentials, response, wt);
	}

	public static <T> T executeDelete(ResourceExtension EXT, String url, Map<String, Object> params, String credentials,
			Class<T> response) {
		WebTarget wt = EXT.target(url);
		wt = addQueryParamsFromMap(params, wt);
		return delete(credentials, response, wt);
	}

	// -------

	private static <R, E> R post(E entity, String credentials, Class<R> response, WebTarget wt) {
		return wt
				.request(MediaType.APPLICATION_JSON)
				.header(HttpHeaders.AUTHORIZATION, credentials)
				.post(Entity.json(entity), response);
	}

	private static <R, E> R put(E entity, String credentials, Class<R> response, WebTarget wt) {
		return wt
				.request(MediaType.APPLICATION_JSON)
				.header(HttpHeaders.AUTHORIZATION, credentials)
				.put(Entity.json(entity), response);
	}

	private static <T> T delete(String credentials, Class<T> response, WebTarget wt) {
		return wt
				.request(MediaType.APPLICATION_JSON)
				.header(HttpHeaders.AUTHORIZATION, credentials)
				.delete(response);
	}

	// --
	@SuppressWarnings("rawtypes")
	private static WebTarget addQueryParamsFromMap(Map<String, Object> params, WebTarget wt) {
		if (null == params) {
			return wt;
		}
		for (Map.Entry<String, Object> entry : params.entrySet()) {
			String key = entry.getKey();
			Object v = entry.getValue();
			if (v instanceof Collection) {
				for (Object x : (Collection) v) {
					wt = wt.queryParam(key, x);
				}
			} else {
				wt = wt.queryParam(key, entry.getValue());
			}
		}
		return wt;
	}
}
