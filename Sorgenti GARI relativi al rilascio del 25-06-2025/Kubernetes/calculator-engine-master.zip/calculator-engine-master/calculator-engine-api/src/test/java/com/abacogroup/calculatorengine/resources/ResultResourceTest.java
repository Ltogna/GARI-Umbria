package com.abacogroup.calculatorengine.resources;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

import com.abacogroup.calculatorengine.common.core.ReqContext;
import com.abacogroup.calculatorengine.commons.core.WebCliHelper;
import com.abacogroup.calculatorengine.core.service.ResultService;
import com.abacogroup.calculatorengine.db.ntt.ResultEntity;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.Response;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class ResultResourceTest {

    private static final String PATH = String.format("/%s/public/v1", WebCliHelper.TENANT_DEFAULT_CODE);
    private ResultService resultService = Mockito.mock(ResultService.class);
    private final ResourceExtension EXT = WebCliHelper.createEXT(new ResultResource(resultService));

    @Test
    void getRawResult() {
        String uuid = "bf1e8033-a109-4e9b-a54c";
        String path = String.format("%s/jobs/%s/results/raw", PATH, uuid);

        var result = ResultEntity.builder().setUuid(uuid).setCalcResult("calc result").setCalcRenderResult("render result").build();
        ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);

        given(resultService.getResult(reqCtxCaptor.capture(), anyString())).willReturn(result);

        var response = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, Response.class);

        Assertions.assertThat(response.getStatus()).isEqualTo(200);
        Assertions.assertThat(response.readEntity(String.class)).isNotNull().isEqualTo(result.getCalcResult());

        verify(resultService, times(1)).getResult(reqCtxCaptor.capture(), eq(uuid));
        verifyNoMoreInteractions(resultService);

        ReqContext reqContext = reqCtxCaptor.getValue();
        assertThat(reqContext.getTenantId(), is("master"));
        assertThat(reqContext.getLang(), is("en"));
        assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
    }

    @Test
    void getRenderResult() {
        String uuid = "bf1e8033-a109-4e9b-a54c";
        String path = String.format("%s/jobs/%s/results/render", PATH, uuid);

        var result = ResultEntity.builder().setUuid(uuid).setCalcResult("calc result").setCalcRenderResult("render result").build();
        ArgumentCaptor<ReqContext> reqCtxCaptor = ArgumentCaptor.forClass(ReqContext.class);

        given(resultService.getResult(reqCtxCaptor.capture(), anyString())).willReturn(result);

        var response = WebCliHelper.executeGet(EXT, path, null, WebCliHelper.BASIC_CREDENTIALS, Response.class);

        Assertions.assertThat(response.getStatus()).isEqualTo(200);
        Assertions.assertThat(response.readEntity(String.class)).isNotNull().isEqualTo(result.getCalcRenderResult());

        verify(resultService, times(1)).getResult(reqCtxCaptor.capture(), eq(uuid));
        verifyNoMoreInteractions(resultService);

        ReqContext reqContext = reqCtxCaptor.getValue();
        assertThat(reqContext.getTenantId(), is("master"));
        assertThat(reqContext.getLang(), is("en"));
        assertThat(reqContext.getUsername(), is(WebCliHelper.BASIC_USERNAME));
    }

}
