package com.abacogroup.calculatorengine.commons.core;

import com.abacogroup.calculatorengine.CalculatorEngineConfiguration;
import com.abacogroup.calculatorengine.TestCalculatorEngineApplication;
import com.abacogroup.testcommon.IntegrationTestSupport;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.testing.ResourceHelpers;
import io.dropwizard.testing.junit5.DropwizardAppExtension;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import org.jdbi.v3.core.Jdbi;

/**
 * Abstract class per integration test di Service e DAO layer
 * <p>
 * - applica le migrazioni in automatico (se configurato)
 * <p>
 * - espone jdbi e getDAO
 */
public class JdbiTest {

	protected static DropwizardAppExtension<CalculatorEngineConfiguration> EXT = new DropwizardAppExtension<>(
			TestCalculatorEngineApplication.class,
			ResourceHelpers.resourceFilePath(System.getProperty("test_config_file", "test_config.yml")));
	protected final IntegrationTestSupport testSupport = new IntegrationTestSupport(EXT);
	protected Function<String, Path> file2Path = filename -> Optional.of(Path.of(
			"src/test/resources",
			this.getClass().getName().replaceAll("\\.", "/"),
			filename)).orElseThrow();

	public static void execSqlFiles(Class clazz, List<String> scripts, Map<String, Object> args) {
		Jdbi jdbi = ((TestCalculatorEngineApplication) EXT.getApplication()).getJdbi();
		IntegrationTestSupport.execSqlFiles(jdbi, clazz, scripts, args);
	}

	public static CalculatorEngineConfiguration getMonitoringConfiguration() {
		return EXT.getConfiguration();
	}

	// -------- per comodità ----
	public <T> T getService(Class<T> clazz) {
		return testSupport.getService(clazz);
	}

	public <T> T getDAO(Class<T> classDAO) {
		return testSupport.getDAO(classDAO);
	}

	public void setUnusedBindingAllowed(boolean allowed) {
		testSupport.setUnusedBindingAllowed(allowed);
	}

	public Jdbi getJdbi() {
		return testSupport.getJdbi();
	}

	public <T, M> void injectMock(T target, M mock) {
		IntegrationTestSupport.injectMock(target, mock);
	}

	protected ObjectMapper getMapper() {
		return EXT.getObjectMapper();
	}

}
