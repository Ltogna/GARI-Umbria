package com.abacogroup.calculatorengine.resources;

import static org.hamcrest.Matchers.is;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.hamcrest.CoreMatchers;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import com.abacogroup.calculatorengine.common.core.ReqContext;
import com.abacogroup.calculatorengine.commons.core.WebCliHelper;
import com.abacogroup.calculatorengine.core.embededqueue.CalcJob;
import com.abacogroup.calculatorengine.core.embededqueue.CalcQueue;
import com.abacogroup.calculatorengine.core.service.CalculatorTypeService;
import com.abacogroup.calculatorengine.core.service.ResultService;
import com.abacogroup.calculatorengine.db.ntt.ResultEntity;
import com.abacogroup.calculatorengine.resources.req.CalculatorReq;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import com.abacogroup.workflow.server.model.ProcessTransitionResult.TransitionLog;
import com.abacogroup.workflow.server.services.ProcessService;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;

@ExtendWith(DropwizardExtensionsSupport.class)
class CalculatorResourceTest {

	private static final String PATH = String.format("/%s/public/v1", WebCliHelper.TENANT_DEFAULT_CODE);
	private final ProcessService processService = Mockito.mock(ProcessService.class);
	private final CalcQueue calcQueue = Mockito.mock(CalcQueue.class);
	private CalculatorTypeService calculatorTypeService = Mockito.mock(CalculatorTypeService.class);
	private ResultService resultService = Mockito.mock(ResultService.class);
	private final ResourceExtension EXT = WebCliHelper.createEXT(new CalculatorResource(calculatorTypeService, resultService, calcQueue));

	@Test
	void test_execute_calc() throws IOException {
		String calcType = "sample-wf";
		given(processService.createProcess(Mockito.any())).willReturn(ProcessTransitionResult.builder()
				.processId(1L)
				.currentNode("a-node")
				.lastTransitionLog(Mockito.mock(TransitionLog.class))
				.messages(new ArrayList<>())
				.build());

		String path = String.format("%s/%s", PATH, calcType);
		Map<String, Object> beanMap = new HashMap<>();
		beanMap.put("foo", "bar");

		when(calculatorTypeService.insertCalcJob(Mockito.anyString(), Mockito.any(CalculatorReq.class), Mockito.any(ReqContext.class)))
				.thenReturn(ResultEntity.builder().setUuid(UUID.randomUUID().toString()).build());

		WebCliHelper.executePost(EXT, path, beanMap, WebCliHelper.BASIC_CREDENTIALS, String.class);

		ArgumentCaptor<CalcJob> argumentCaptor = ArgumentCaptor.forClass(CalcJob.class);
		verify(calcQueue, times(1)).add(argumentCaptor.capture(), Mockito.anyLong());

		CalcJob calcJob = argumentCaptor.getValue();
		MatcherAssert.assertThat(calcJob.getTenantId(), CoreMatchers.is("master"));
		MatcherAssert.assertThat(calcJob.getLocale(), CoreMatchers.is("en"));
		MatcherAssert.assertThat(calcJob.getWorkflowCode(), CoreMatchers.is(calcType));
		MatcherAssert.assertThat(calcJob.getUserName(), CoreMatchers.is("test-user@example"));
		System.out.println(calcJob.getInput().getParams());
		MatcherAssert.assertThat(calcJob.getInput().getParams().get("foo"),
				is("bar"));

		MatcherAssert.assertThat(calcJob.getCalculatorReq().getDest(), CoreMatchers.is(calcType));
	}
}
