package com.abacogroup.calculatorengine.bundle.config;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.calculatorengine.commons.core.JdbiTest;
import com.abacogroup.calculatorengine.db.dao.WfConfigurationDAO;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(DropwizardExtensionsSupport.class)
class WfConfigurationConfigMessageProcessorTest extends JdbiTest {

	private static final String TENANT_ID = String.format("%s_t", WfConfigurationConfigMessageProcessorTest.class.getSimpleName());
	private final WfConfigurationConfigMessageProcessor processor = getService(WfConfigurationConfigMessageProcessor.class);
	private final WfConfigurationDAO dao = getDAO(WfConfigurationDAO.class);

	@Test
	void test_OnMessage() {
		String wfCode = "my_test_code";

		var message = new ConfigDataMessage()
				.setTenantId(TENANT_ID)
				.setConfigFiles(List.of(
						file2Path.apply("wf_configs_01.json")
				));

		getJdbi().useHandle(handle -> {
			handle.begin();
			Assertions.assertThat(dao.findByWfCodeAndTenant(wfCode, TENANT_ID).isEmpty());
			processor.onMessage(message);
			Assertions.assertThat(dao.findByWfCodeAndTenant(wfCode, TENANT_ID)).isPresent();
			Assertions.assertThat(dao.findByWfCodeAndTenant(wfCode, TENANT_ID).get().getWfCode().equals(wfCode));
			Assertions.assertThat(dao.findByWfCodeAndTenant(wfCode, TENANT_ID).get().getJsonConfigs()).isNotNull();

			handle.rollback();
		});
	}

	@Test
	void given_two_wfConfigs_for_same_wfCode() {
		String wfCode = "my_test_code";
		var message = new ConfigDataMessage()
				.setTenantId(TENANT_ID)
				.setConfigFiles(List.of(
						file2Path.apply("wf_configs_01.json"),
						file2Path.apply("wf_configs_02.json")
				));

		getJdbi().useHandle(handle -> {
			handle.begin();
			Assertions.assertThat(dao.findByWfCodeAndTenant(wfCode, TENANT_ID).isEmpty());
			processor.onMessage(message);
			Assertions.assertThat(dao.findByWfCodeAndTenant(wfCode, TENANT_ID)).isPresent();
			Assertions.assertThat(dao.findByWfCodeAndTenant(wfCode, TENANT_ID).get().getWfCode().equals(wfCode));
			Assertions.assertThat(dao.findByWfCodeAndTenant(wfCode, TENANT_ID).get().getJsonConfigs()).isNotNull();
			Assertions.assertThat(dao.findByWfCodeAndTenant(wfCode, TENANT_ID).get().getJsonConfigs()).isEqualTo("{\"tassoRiduzione\":0.01}");

			handle.rollback();
		});
	}

	@Test
	void given_two_to_be_merged() {
		String wfCode = "merge_test";
		var message = new ConfigDataMessage()
				.setTenantId(TENANT_ID)
				.setConfigFiles(List.of(
						file2Path.apply("01_merge_initial.json"),
						file2Path.apply("02_merge_increment.merge.json")
				));

		getJdbi().useHandle(handle -> {
			handle.begin();
			Assertions.assertThat(dao.findByWfCodeAndTenant(wfCode, TENANT_ID).isEmpty());
			processor.onMessage(message);
			Assertions.assertThat(dao.findByWfCodeAndTenant(wfCode, TENANT_ID)).isPresent();
			Assertions.assertThat(dao.findByWfCodeAndTenant(wfCode, TENANT_ID).get().getWfCode().equals(wfCode));
			Assertions.assertThat(dao.findByWfCodeAndTenant(wfCode, TENANT_ID).get().getJsonConfigs()).isNotNull();
			Assertions.assertThat(dao.findByWfCodeAndTenant(wfCode, TENANT_ID).get().getJsonConfigs()).isEqualTo("{\"do_not_touch\":{\"description\":\"OK\"},\"scrap\":{\"count\":1},\"plank\":{\"count\":4,\"properties\":{\"type\":\"oak\",\"dimensions\":[5.0,12.5,25]}}}");

			handle.rollback();
		});
	}

	@Test
	void given_a_merge_of_inexistent() {
		String wfCode = "merge_error";
		var message = new ConfigDataMessage()
				.setTenantId(TENANT_ID)
				.setConfigFiles(List.of(
						file2Path.apply("01_merge_error.merge.json")
				));

		getJdbi().useHandle(handle -> {
			handle.begin();
			Assertions.assertThat(dao.findByWfCodeAndTenant(wfCode, TENANT_ID).isEmpty());
			assertThrows(BundleException.class, () -> processor.onMessage(message));

			handle.rollback();
		});
	}

}
