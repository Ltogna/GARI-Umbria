package com.abacogroup.calculatorengine;

import com.abacogroup.bundles.initializer.InitService;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.listener.RabbitListener;
import com.abacogroup.bundles.listener.configdata.ConfigDataLogProducer;
import com.abacogroup.calculatorengine.api.CalculatorJobResponse;
import com.abacogroup.calculatorengine.core.service.CalculatorJobEventProducer;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.testcommon.ApplicationTestSupport;
import com.abacogroup.testcommon.TestApplication;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import io.dropwizard.auth.AuthFilter;
import io.dropwizard.auth.PolymorphicAuthDynamicFeature;
import io.dropwizard.auth.PolymorphicAuthValueFactoryProvider;
import io.dropwizard.auth.basic.BasicCredentialAuthFilter;
import io.dropwizard.auth.chained.ChainedAuthFilter;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeoutException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.Slf4JSqlLogger;
import org.mockito.Mockito;

@Slf4j
public class TestCalculatorEngineApplication extends CalculatorEngineApplication implements TestApplication {

	public static Jdbi jdbi;
	private ApplicationTestSupport applicationTestSupport = new ApplicationTestSupport(this.getName());

	public static ObjectMapper getObjectMapper() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		// brutto, ma consente di accentrare la configurazione senza snaturare application
		new CalculatorEngineApplication().configureObjectMapper(mapper);
		return mapper;
	}

	@Override
	public ApplicationTestSupport getAppTestSupport() {
		return applicationTestSupport;
	}

	//	@Override
	//	public void doRun(CalculatorEngineConfig configuration, Environment environment) throws Exception {
	//		super.doRun(configuration, environment);
	//	}

	@Override
	protected Jdbi jdbi(CalculatorEngineConfiguration configuration, Environment environment) {
		Jdbi jdbi = super.jdbi(configuration, environment);
		jdbi.setSqlLogger(new Slf4JSqlLogger());
		TestCalculatorEngineApplication.jdbi = jdbi;
		applicationTestSupport.execMigrations(environment, configuration.getDatabase());
		return jdbi;
	}

	@Override
	protected <T> T register(T service) {
		if (isBetterToMock(service)) {
			service = (T) Mockito.mock(service.getClass());
		}

		applicationTestSupport.register(service);
		return super.register(service);
	}

	@Override
	protected ConfigDataLogProducer configDataLogProducerBean(ObjectMapper objectMapper, com.rabbitmq.client.Connection rabbitmqConnection) {
		if (!applicationTestSupport.isInitRabbit()) {
			return Mockito.mock(ConfigDataLogProducer.class);
		}
		return super.configDataLogProducerBean(objectMapper, rabbitmqConnection);
	}

	@Override
	protected void initOpenApi(JerseyEnvironment jersey) {
		log.info("OPEN-API DISABELD");
	}

	@Override
	protected void initAuth(Environment environment, Sso2Client sso2Cli) {
		List<AuthFilter<?, ? extends User>> filters = new ArrayList<>();
		filters.add(new BasicCredentialAuthFilter.Builder<User>()
				.setAuthenticator(credentials -> Optional.of(new User(credentials.getUsername(), "master")))
				.setAuthorizer((principal, role, requestContext) -> true)
				.setRealm("GUEST authenticator")
				.buildAuthFilter());

		@SuppressWarnings({ "rawtypes", "unchecked" })
		ChainedAuthFilter usersFilter = new ChainedAuthFilter(filters);

		final PolymorphicAuthDynamicFeature<? extends User> feature = new PolymorphicAuthDynamicFeature<>(
				ImmutableMap.of(User.class, usersFilter));

		PolymorphicAuthValueFactoryProvider.Binder<? extends User> binder = new PolymorphicAuthValueFactoryProvider.Binder<>(
				ImmutableSet.of(User.class));

		environment.jersey().register(feature);
		environment.jersey().register(binder);
		// */
	}

	@Override
	protected void startRabbitConsumerAndProducers(InitService initService, RabbitListener rabbitListener) throws Exception {
		if (!applicationTestSupport.isInitRabbit()) {
			System.out.println("startup producers and consumers OFF");
		} else {
			super.startRabbitConsumerAndProducers(initService, rabbitListener);
		}
	}

	@Override
	protected void afterServicesUp() {
		if (!applicationTestSupport.isExecMigrations()) {
			return;
		}
		try {
			applicationTestSupport.installBundle(jdbi, String.format("%s.%s", getName(), "zip"));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	protected static <T, M> void injectMockByField(T target, String filedName) {
		try {
			Class<T> targetClazz = (Class<T>) target.getClass();
			Field field = Arrays.stream(FieldUtils.getAllFields(targetClazz))
					.filter(f -> f.getName().equals(filedName))
					.findFirst()
					.orElseThrow();

			FieldUtils.writeField(target, field.getName(), Mockito.mock(field.getType()), true);
		} catch (IllegalAccessException ex) {
			throw new RuntimeException("errore in inject", ex);
		}
	}

	@Override
	protected com.rabbitmq.client.Connection createRabbitmqConnection(CalculatorEngineConfiguration configuration) throws IOException, TimeoutException {
		if (applicationTestSupport.isInitRabbit()) {
			return super.createRabbitmqConnection(configuration);
		} else {
			log.info("RABBIT CONNECTION DISABLED");
			return null;
		}
	}

	@Override
	protected CalculatorJobEventProducer createCalcJobEventProducer(Environment environment, Jdbi jdbi, ObjectMapper objectMapper,
			com.rabbitmq.client.Connection rabbitmqConnection)
			throws IOException {
		return new CalculatorJobEventProducer() {
			@Override
			public void pushEvent(CalculatorJobResponse message, String tenant, JobEventType eventType) throws IOException {
				log.info("RABBIT CONNECTION DISABLED");
			}
		};
	}

	private void initMultiTenant(Environment environment) {
		environment.jersey().register(new MultitenantFilter("tenant"));
	}

	private <T> boolean isBetterToMock(T service) {
		return (service instanceof ConfigDataLogProducer
				|| (service instanceof BundleInitServiceProducer) && !applicationTestSupport.isInitRabbit());
	}

	@Override
	public Jdbi getJdbi() {
		return jdbi;
	}
}
