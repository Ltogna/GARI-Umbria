package com.abacogroup.calculatorengine.core.service.impl;

import static com.abacogroup.calculatorengine.core.service.CalculatorTypeService.SCOPE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import java.nio.file.Path;
import java.time.Instant;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;

import com.abacogroup.calculatorengine.api.CalculatorJobStatus;
import com.abacogroup.calculatorengine.bundle.config.CalculatorTypeConfigMessageProcessor;
import com.abacogroup.calculatorengine.common.core.ReqContext;
import com.abacogroup.calculatorengine.commons.core.JdbiTest;
import com.abacogroup.calculatorengine.core.exceptions.ReportException;
import com.abacogroup.calculatorengine.core.exceptions.ReportException.ErrEnum;
import com.abacogroup.calculatorengine.core.service.CalculatorTypeService;
import com.abacogroup.calculatorengine.db.dao.CalculatorTypeDAO;
import com.abacogroup.calculatorengine.db.dao.WfConfigurationDAO;
import com.abacogroup.calculatorengine.db.ntt.CalculatorTypeEntity;
import com.abacogroup.calculatorengine.db.ntt.ResultEntity;
import com.abacogroup.calculatorengine.db.ntt.WfConfigurationEntity;
import com.abacogroup.calculatorengine.resources.req.CalculatorReq;
import com.abacogroup.calculatorengine.sdk.CalculatorEngineUtils;
import com.abacogroup.calculatorengine.sdk.model.CalculatorEngineInput;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.workflow.server.db.ntt.WorLogTransitionEntity;
import com.abacogroup.workflow.server.model.CreateProcessParams;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import com.abacogroup.workflow.server.model.ProcessTransitionResult.TransitionLog;
import com.abacogroup.workflow.server.model.WorkflowVersion;
import com.abacogroup.workflow.server.services.ProcessService;
import com.abacogroup.workflow.server.services.WorkflowService;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import jakarta.ws.rs.core.SecurityContext;
import lombok.SneakyThrows;

@ExtendWith(DropwizardExtensionsSupport.class)
class CalculatorTypeServiceImplTest extends JdbiTest {

	private static final String TENANT_ID = String.format("%s_t", CalculatorTypeServiceImplTest.class.getSimpleName());
	private static final String CURRENT_USER = String.format("%s_u", CalculatorTypeServiceImplTest.class.getSimpleName());
	private static final ReqContext reqContext = new ReqContext(TENANT_ID, CURRENT_USER, "en");

	private static final String CODE = "sample-wf";

	private final CalculatorTypeService service = getService(CalculatorTypeServiceImpl.class);
	private final CalculatorTypeDAO dao = getDAO(CalculatorTypeDAO.class);

	private final CalculatorTypeConfigMessageProcessor processor = getService(CalculatorTypeConfigMessageProcessor.class);
	private ProcessService processService;
	private WorkflowService workflowService;

	private static TransitionLog buildLastTransitionLog(boolean fail) {
		WorLogTransitionEntity ntt = new WorLogTransitionEntity();
		ntt.setId(999L);
		ntt.setWor_workflow_transition_id(888L);
		ntt.setIs_failed(fail ? 1 : 0);
		ntt.setNotes("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.");
		ntt.setStart_date(OffsetDateTime.ofInstant(Instant.now().minus(1, ChronoUnit.MINUTES), ZoneId.systemDefault()));
		ntt.setEnd_date(OffsetDateTime.ofInstant(Instant.now(), ZoneId.systemDefault()));
		ntt.setUser_id("user1");

		return new TransitionLog(ntt);
	}

	@BeforeEach
	void setUp() {
		processService = mock(ProcessService.class);
		workflowService = mock(WorkflowService.class);
		this.injectMock(service, processService);
		this.injectMock(service, workflowService);
	}

	@Test
	void test_add_CalculatorType() {
		getJdbi().useHandle(handle -> {
			handle.begin();
			CalculatorTypeEntity entity = CalculatorTypeEntity.builder()
					.setTenantId(TENANT_ID)
					.setWorkflowCode(CODE)
					.build();

			service.addType(entity);
			assertTrue(dao.findByTenantAndCode(TENANT_ID, CODE).isPresent());
			handle.rollback();

		});
	}

	@Test
	void test_add_CalcJob() {
		given(workflowService.getWorkflowVersion(any(), any()))
				.willReturn(new WorkflowVersion("1", "111111111111111111"));
		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			CalculatorTypeEntity entity = CalculatorTypeEntity.builder()
					.setTenantId(TENANT_ID)
					.setWorkflowCode(CODE)
					.build();
			service.addType(entity);
			assertTrue(dao.findByTenantAndCode(TENANT_ID, CODE).isPresent());
			// insert
			CalculatorReq req = new CalculatorReq();
			req.setDest("dest");
			ResultEntity result = service.insertCalcJob(CODE, req, reqContext);

			// asserts
			assertThat(result).isNotNull();
			assertThat(result.getDest()).isEqualTo("dest");
			assertThat(result.getStatus()).isEqualTo(CalculatorJobStatus.ACKNOWLEDGE);

			handle.rollback();
		});
	}

	@Test
	void test_add_CalcJob_updateJobStatus_ok() {
		given(workflowService.getWorkflowVersion(any(), any()))
				.willReturn(new WorkflowVersion("1", "111111111111111111"));
		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			CalculatorTypeEntity entity = CalculatorTypeEntity.builder()
					.setTenantId(TENANT_ID)
					.setWorkflowCode(CODE)
					.build();
			service.addType(entity);
			assertTrue(dao.findByTenantAndCode(TENANT_ID, CODE).isPresent());
			// insert
			CalculatorReq req = new CalculatorReq();
			req.setDest("dest");
			ResultEntity result = service.insertCalcJob(CODE, req, reqContext);

			// asserts
			assertThat(result).isNotNull();
			assertThat(result.getDest()).isEqualTo("dest");
			assertThat(result.getStatus()).isEqualTo(CalculatorJobStatus.ACKNOWLEDGE);

			// update status
			service.updateJobStatus(result.getUuid(), CalculatorJobStatus.READY);
			// asserts
			assertThat(service.getJobStatus(TENANT_ID, result.getUuid()).getStatus()).isEqualTo(CalculatorJobStatus.READY);
			handle.rollback();
		});
	}

	@Test
	void test_startCalculatorWorkflow() {
		given(workflowService.getWorkflowVersion(any(), any()))
				.willReturn(new WorkflowVersion("1", "111111111111111111"));
		getJdbi().useHandle(handle -> {
			handle.begin();
			// setup
			CalculatorTypeEntity entity = CalculatorTypeEntity.builder()
					.setTenantId(TENANT_ID)
					.setWorkflowCode(CODE)
					.build();
			service.addType(entity);
			assertTrue(dao.findByTenantAndCode(TENANT_ID, CODE).isPresent());
			// insert
			CalculatorReq req = new CalculatorReq();
			req.setDest("dest");
			ResultEntity result = service.insertCalcJob(CODE, req, reqContext);

			// asserts
			assertThat(result).isNotNull();
			assertThat(result.getStatus()).isEqualTo(CalculatorJobStatus.ACKNOWLEDGE);

			handle.rollback();
		});
	}

	@Test
	@SneakyThrows
	void test_startCalculatorWorkflow_ok() {
		SecurityContext securityContext = mock(SecurityContext.class);
		CalculatorEngineInput calculatorEngineInput = CalculatorEngineInput.builder()
				.setParams(new HashMap<>(Map.of("key", "value")))
				.build();
		String workflowCode = "the_code";
		String lang = "en";
		ProcessTransitionResult processTransitionResult = ProcessTransitionResult.builder()
				.processId(123L)
				.lastTransitionLog(buildLastTransitionLog(false))
				.currentNode("end")
				.messages(List.of())
				.build();
		given(processService.createProcess(any())).willReturn(processTransitionResult);
		String hash = "111111111111111111";
		given(workflowService.getWorkflowVersion(any(), any()))
				.willReturn(new WorkflowVersion("1", hash));

		getJdbi().useHandle(handle -> {
			handle.begin();

			String jsonConfigs = "{\"foo\": \"bar\"}";
			handle.attach(WfConfigurationDAO.class).insert(WfConfigurationEntity.builder()
					.setDtDelete(AuditEntity.dateActive)
					.setDtInsert(LocalDate.of(1970, 01, 01).atStartOfDay())
					.setUserIdInsert("test")
					.setWfCode(workflowCode)
					.setTenantId(TENANT_ID)
					.setJsonConfigs(jsonConfigs)
					.build());

			String calcId = "" + System.currentTimeMillis();

			ProcessTransitionResult result = service.startCalculatorWorkflow(
					workflowCode,
					calcId,
					calculatorEngineInput,
					securityContext,
					lang,
					TENANT_ID);

			calculatorEngineInput.getParams().put(CalculatorEngineInput.UUID_PARAM_NAME, calcId);

			assertThat(result).isNotNull().isSameAs(processTransitionResult);
			ArgumentCaptor<CreateProcessParams> processParamsCaptor = ArgumentCaptor.forClass(CreateProcessParams.class);
			verify(processService).createProcess(processParamsCaptor.capture());
			CreateProcessParams CreateProcessParams = processParamsCaptor.getValue();
			assertThat(CreateProcessParams).isNotNull();
			assertThat(CreateProcessParams.getTenantId()).isEqualTo(TENANT_ID);
			assertThat(CreateProcessParams.getScope()).isEqualTo(SCOPE);
			assertThat(CreateProcessParams.getWorkflowCode()).isEqualTo(workflowCode);
			assertThat(CreateProcessParams.getGlobalVars()).isEqualTo(Map.of(CalculatorEngineInput.PARAM_NAME, calculatorEngineInput));
			assertThat(CreateProcessParams.getAuthContext()).isNotNull();

			Path sourceDir = CalculatorEngineUtils.getSourceDir(EXT.getConfiguration().getCalculatorConfig().getInitBaseTempDir(),
					TENANT_ID, workflowCode, hash);
			assertThat(sourceDir.toFile()).exists();

			handle.rollback();
		});
	}

	@Test
	@SneakyThrows
	void test_givenProcessFailed_startCalculatorFlow_ko() {
		SecurityContext securityContext = mock(SecurityContext.class);
		CalculatorEngineInput calculatorEngineInput = CalculatorEngineInput.builder()
				.setParams(new HashMap<>(Map.of("key", "value")))
				.build();
		String workflowCode = "the_code";
		String lang = "en";
		ProcessTransitionResult processTransitionResult = ProcessTransitionResult.builder()
				.processId(123L)
				.lastTransitionLog(buildLastTransitionLog(true))
				.currentNode("end")
				.messages(List.of())
				.build();
		given(processService.createProcess(any())).willReturn(processTransitionResult);
		given(workflowService.getWorkflowVersion(any(), any()))
				.willReturn(new WorkflowVersion("1", "111111111111111111"));

		String calcId = "" + System.currentTimeMillis();

		ReportException reportException = assertThrows(ReportException.class, () -> service.startCalculatorWorkflow(
				workflowCode,
				calcId,
				calculatorEngineInput,
				securityContext,
				lang,
				TENANT_ID));

		calculatorEngineInput.getParams().put(CalculatorEngineInput.UUID_PARAM_NAME, calcId);

		assertThat(reportException).isNotNull()
				.extracting(ReportException::getCode).isEqualTo(ErrEnum.CALC_ERROR.toString());
		ArgumentCaptor<CreateProcessParams> processParamsCaptor = ArgumentCaptor.forClass(CreateProcessParams.class);
		verify(processService).createProcess(processParamsCaptor.capture());
		CreateProcessParams CreateProcessParams = processParamsCaptor.getValue();
		assertThat(CreateProcessParams).isNotNull();
		assertThat(CreateProcessParams.getTenantId()).isEqualTo(TENANT_ID);
		assertThat(CreateProcessParams.getScope()).isEqualTo(SCOPE);
		assertThat(CreateProcessParams.getWorkflowCode()).isEqualTo(workflowCode);
		assertThat(CreateProcessParams.getGlobalVars()).isEqualTo(Map.of(CalculatorEngineInput.PARAM_NAME, calculatorEngineInput));
		assertThat(CreateProcessParams.getAuthContext()).isNotNull();

	}

}
