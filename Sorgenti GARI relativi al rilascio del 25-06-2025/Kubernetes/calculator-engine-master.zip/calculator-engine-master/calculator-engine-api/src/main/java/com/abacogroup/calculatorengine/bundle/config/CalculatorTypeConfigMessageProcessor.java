package com.abacogroup.calculatorengine.bundle.config;

import static java.util.stream.Collectors.toList;

import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.calculatorengine.CalculatorEngineConfiguration;
import com.abacogroup.calculatorengine.bundle.BundleConstants;
import com.abacogroup.calculatorengine.core.service.CalculatorTypeService;
import com.abacogroup.calculatorengine.db.ntt.CalculatorTypeEntity;
import com.abacogroup.calculatorengine.sdk.CalculatorEngineUtils;
import com.abacogroup.workflow.server.model.NodeType;
import com.abacogroup.workflow.server.services.WorkflowDefinition;
import com.abacogroup.workflow.server.services.WorkflowDefinition.Node;
import com.abacogroup.workflow.server.services.WorkflowService;
import com.codahale.metrics.MetricRegistry;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

public class CalculatorTypeConfigMessageProcessor implements ConfigMessageProcessor {

	private final CalculatorTypeService calculatorTypeService;

	//private final DataSourceFactory dataSourceFactory;
	private final MetricRegistry metrics;

	private final WorkflowService workflowService;

	private final CalculatorEngineConfiguration configuration;

	public CalculatorTypeConfigMessageProcessor(CalculatorTypeService calculatorTypeService, MetricRegistry metrics,
			WorkflowService workflowService, CalculatorEngineConfiguration configuration) {
		this.calculatorTypeService = calculatorTypeService;
		//this.dataSourceFactory = dataSourceFactory;
		this.metrics = metrics;
		this.workflowService = workflowService;

		this.configuration = configuration;
	}

	@Override
	public String getDomainName() {
		return BundleConstants.CALC_TYPE_BUNDLE_NS;
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();

		List<Path> jarPaths = message.getConfigFiles()
				.stream()
				.filter(p -> FilenameUtils.isExtension(p.getFileName().toString(), "jar"))
				.collect(toList());

		jarPaths.forEach(p -> this.processJar(tenantId, p));

	}

	private void processJar(String tenantId, Path jarPath) {
		try {
			File jar = jarPath.toFile();
			WorkflowDefinition workflowDefinition = workflowService.addOrUpdateWorkflow(tenantId, jar);

			this.validateWkNodeTypes(workflowDefinition);

			String wfCode = workflowDefinition.getCode();
			String hash = workflowDefinition.getMd5();

			Path sourceDir = CalculatorEngineUtils.getSourceDir(configuration.getCalculatorConfig().getInitBaseTempDir(), tenantId, wfCode, hash);
			FileUtils.deleteQuietly(sourceDir.toFile());

			FileSupport.unzip(new FileInputStream(jarPath.toFile()), sourceDir);

			//TODO ?? custom bundle config

			var calculatorTypeEntity = CalculatorTypeEntity.builder()
					.setTenantId(tenantId)
					.setWorkflowCode(wfCode)
					.build();
			calculatorTypeService.addType(calculatorTypeEntity);

		} catch (IOException e) {
			throw new BundleException(String.format("error creating calculation workflow from file %s", jarPath), e);
		}

	}

	protected void validateWkNodeTypes(WorkflowDefinition workflowDefinition) {
		List<String> statusNodes = workflowDefinition.getNodes()
				.stream()
				.filter(i -> NodeType.status.equals(i.getType()))
				.map(Node::getName)
				.collect(toList());

		if (!statusNodes.isEmpty()) {
			throw new BundleException(String.format("invalid nods %s of type %s in workflow %s",
					statusNodes, NodeType.status, workflowDefinition.getCode()));
		}

	}

}
