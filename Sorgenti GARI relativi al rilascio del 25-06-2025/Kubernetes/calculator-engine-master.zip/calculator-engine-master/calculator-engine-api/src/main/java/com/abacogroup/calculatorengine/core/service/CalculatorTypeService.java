package com.abacogroup.calculatorengine.core.service;

import com.abacogroup.calculatorengine.api.CalculatorJobResponse;
import com.abacogroup.calculatorengine.api.CalculatorJobStatus;
import com.abacogroup.calculatorengine.common.core.ReqContext;
import com.abacogroup.calculatorengine.db.ntt.CalculatorTypeEntity;
import com.abacogroup.calculatorengine.db.ntt.ResultEntity;
import com.abacogroup.calculatorengine.resources.req.CalculatorReq;
import com.abacogroup.calculatorengine.sdk.model.CalculationResult;
import com.abacogroup.calculatorengine.sdk.model.CalculatorEngineInput;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;

import jakarta.ws.rs.core.SecurityContext;

public interface CalculatorTypeService {

	String SCOPE = "calculator-engine";

	ResultEntity insertCalcJob(String calcTypeCode, CalculatorReq calculatorReq, ReqContext reqContext);

	CalculatorJobResponse getJobStatus(String tenantId, String uuid);

	void addType(CalculatorTypeEntity calculatorTypeEntity);

	ProcessTransitionResult startCalculatorWorkflow(String workflowCode, String calcUuid, CalculatorEngineInput input, SecurityContext securityContext,
			String locale, String tenantId);

	void updateJobStatus(String jobUuid, CalculatorJobStatus calculatorJobStatus);

	void markAsReady(String jobUuid, CalculationResult<?> calculationResult);

}
