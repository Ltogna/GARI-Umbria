package com.abacogroup.calculatorengine.common.core;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.workflow.sdk.auth.AuthContext;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientRequestContext;
import jakarta.ws.rs.client.ClientRequestFilter;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.SecurityContext;

import java.io.IOException;
import java.security.Principal;

public class AuthContextImpl implements AuthContext {

    private User user;
    private String localeCode;
    private SecurityContext securityContext;

    public AuthContextImpl(SecurityContext securityContext, String localeCode) {
        this.user = (User) securityContext.getUserPrincipal();
        this.localeCode = localeCode;
        this.securityContext = securityContext;
    }

    @Override
    public String getUserId() {
        return user.getUserId();
    }

    @Override
    public Principal getPrincipal() {
        return user;
    }

    @Override
    public String getLocaleCode() {
        return localeCode;
    }

    @Override
    public boolean isFunctionEnabled(String context, String function) {
        return securityContext.isUserInRole(context + "|" + function);
    }

    @Override
    public WebTarget getAuthenticatedWebTarget(Client client, String url) {
        return client.target(url).register(new JwtClientRequestFilter());
    }

    private class JwtClientRequestFilter implements ClientRequestFilter {
        @Override
        public void filter(ClientRequestContext requestContext) throws IOException {
            requestContext.getHeaders().add("Authorization", "JWT " + user.getAuthToken());
        }
    }

}
