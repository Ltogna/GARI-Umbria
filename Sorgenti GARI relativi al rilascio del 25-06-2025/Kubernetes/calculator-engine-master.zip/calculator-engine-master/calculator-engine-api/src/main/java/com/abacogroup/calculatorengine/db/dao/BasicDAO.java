package com.abacogroup.calculatorengine.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import java.time.LocalDateTime;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

public interface BasicDAO extends EnhancedSqlObject {

	@SqlQuery("§select_from_dual(CURRENT_TIMESTAMP)§")
	LocalDateTime getCurrentTimestamp();

}
