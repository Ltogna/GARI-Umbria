package com.abacogroup.calculatorengine.bundle.config;

import static com.abacogroup.calculatorengine.bundle.BundleConstants.SYSTEM_USER;
import static com.abacogroup.calculatorengine.bundle.BundleConstants.WF_CONFIG_BUNDLE_NS;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Consumer;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.calculatorengine.bundle.BundleConstants;
import com.abacogroup.calculatorengine.common.core.AuditHelper;
import com.abacogroup.calculatorengine.db.dao.WfConfigurationDAO;
import com.abacogroup.calculatorengine.db.ntt.WfConfigurationEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Data;
import net.minidev.json.JSONObject;
import net.obvj.jsonmerge.JsonMerger;

public class WfConfigurationConfigMessageProcessor implements ConfigMessageProcessor {
	private final WfConfigurationDAO wfConfigurationDAO;
	private final ObjectMapper mapper = new ObjectMapper();

	public WfConfigurationConfigMessageProcessor(WfConfigurationDAO wfConfigurationDAO) {
		this.wfConfigurationDAO = wfConfigurationDAO;
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();
		message.getConfigFiles().forEach(path -> {
			if(path.toString().endsWith(".merge.json"))
				mergeContent(tenantId, path);
			else
				addContent(tenantId, path);
		});
	}

	private void addContent(String tenantId, Path path) {
		try {
			String jsonContent = Files.readString(path);
			WfConfigurationEntity wfConfigurationEntity = mapEntity(tenantId, jsonContent);

			wfConfigurationDAO.findByWfCodeAndTenant(wfConfigurationEntity.getWfCode(), tenantId).ifPresent((e) -> {
				Consumer<WfConfigurationEntity> expireFun = wfConfigurationDAO::expireRow;
				AuditHelper.expire(e, BundleConstants.SYSTEM_USER, expireFun, wfConfigurationDAO.getCurrentTimestamp());
			});

			AuditHelper.setAuditForInsert(SYSTEM_USER, wfConfigurationDAO, wfConfigurationEntity);
			wfConfigurationDAO.insert(wfConfigurationEntity);

		} catch (IOException e) {
			throw new BundleException(String.format("error reading %s", path), e);
		}
	}

	private void mergeContent(String tenantId, Path path) {
		try {
			String jsonContent = Files.readString(path);
			WfConfigurationEntity wfConfigurationEntity = mapEntity(tenantId, jsonContent);
			
			String oldConfig = wfConfigurationDAO.getJsonConfig(tenantId, wfConfigurationEntity.getWfCode());
			
			if(oldConfig==null)
				throw new BundleException(String.format("error: trying to apply a config merge on a missing configuration (tenant [%s] code [%s])", tenantId, wfConfigurationEntity.getWfCode()));
			
			JSONObject result = new JsonMerger<>(JSONObject.class).merge(wfConfigurationEntity.getJsonConfigs(), oldConfig);
			wfConfigurationEntity.setJsonConfigs(result.toJSONString());
			
			wfConfigurationDAO.findByWfCodeAndTenant(wfConfigurationEntity.getWfCode(), tenantId).ifPresent((e) -> {
				Consumer<WfConfigurationEntity> expireFun = wfConfigurationDAO::expireRow;
				AuditHelper.expire(e, BundleConstants.SYSTEM_USER, expireFun, wfConfigurationDAO.getCurrentTimestamp());
			});

			AuditHelper.setAuditForInsert(SYSTEM_USER, wfConfigurationDAO, wfConfigurationEntity);
			wfConfigurationDAO.insert(wfConfigurationEntity);

		} catch (IOException e) {
			throw new BundleException(String.format("error reading %s", path), e);
		}
	}

	private WfConfigurationEntity mapEntity(String tenant, String jsonContent) {
		try {
			WfConfig wfConfig = mapper.readValue(jsonContent, new TypeReference<WfConfig>() {
			});

			return WfConfigurationEntity.builder()
					.setTenantId(tenant)
					.setWfCode(wfConfig.getWfCode())
					.setJsonConfigs(wfConfig.getConfig()).build();

		} catch (Exception e) {
			throw new BundleException("error in deserialization json ", e);
		}
	}

	@Override
	public String getDomainName() {
		return WF_CONFIG_BUNDLE_NS;
	}

	@Data
	protected static class WfConfig {
		@JsonProperty("wfCode")
		private String wfCode;

		@JsonProperty("config")
		private JsonNode config;

		String getConfig() {
			if (config.isEmpty() || config.isNull()) {
				return null;
			}
			return config.toString();
		}
	}
}
