package com.abacogroup.calculatorengine.resources.req;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class CalculatorReq {

	@Parameter(in = ParameterIn.QUERY, description = "custom word in calculator job event topic: `calculator-engine-job.<dest>.<ready|error>`. default dest value is {calcTypeCode}")
	@QueryParam("dest")
	private String dest;

}
