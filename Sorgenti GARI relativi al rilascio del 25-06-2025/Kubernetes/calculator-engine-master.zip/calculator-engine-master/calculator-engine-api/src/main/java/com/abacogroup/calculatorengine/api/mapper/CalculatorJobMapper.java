package com.abacogroup.calculatorengine.api.mapper;

import com.abacogroup.calculatorengine.api.CalculatorJobResponse;
import com.abacogroup.calculatorengine.db.ntt.ResultEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface CalculatorJobMapper {

	CalculatorJobMapper INSTANCE = Mappers.getMapper(CalculatorJobMapper.class);

	CalculatorJobResponse entityToResponse(ResultEntity entity);

}
