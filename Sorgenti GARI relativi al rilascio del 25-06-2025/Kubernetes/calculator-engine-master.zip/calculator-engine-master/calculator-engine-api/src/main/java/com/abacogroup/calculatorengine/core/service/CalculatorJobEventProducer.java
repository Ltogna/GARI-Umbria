package com.abacogroup.calculatorengine.core.service;

import com.abacogroup.calculatorengine.api.CalculatorJobResponse;
import java.io.IOException;

public interface CalculatorJobEventProducer {

	void pushEvent(CalculatorJobResponse message, String tenant, JobEventType eventType) throws IOException;

	enum JobEventType {

		READY("ready"),
		ERROR("error");

		private final String topic;

		JobEventType(String topicName) {
			this.topic = topicName;
		}

		public String getTopic(String dest) {
			return String.format("calculator-engine-job.%s.%s", dest, topic);
		}
	}
}
