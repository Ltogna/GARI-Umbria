package com.abacogroup.calculatorengine.core.service.impl;

import static com.abacogroup.calculatorengine.api.CalculatorJobStatus.ACKNOWLEDGE;
import static com.abacogroup.calculatorengine.api.CalculatorJobStatus.READY;
import static com.abacogroup.calculatorengine.sdk.CalculatorEngineUtils.WFCONFIG_PAYLOAD;
import static com.abacogroup.calculatorengine.sdk.model.CalculatorEngineInput.PARAM_NAME;
import static com.abacogroup.calculatorengine.sdk.model.CalculatorEngineInput.UUID_PARAM_NAME;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import com.abacogroup.bundles.initializer.impl.FileSupport;
import com.abacogroup.calculatorengine.CalculatorEngineConfiguration;
import com.abacogroup.calculatorengine.api.CalculatorJobResponse;
import com.abacogroup.calculatorengine.api.CalculatorJobStatus;
import com.abacogroup.calculatorengine.api.mapper.CalculatorJobMapper;
import com.abacogroup.calculatorengine.common.core.AuditHelper;
import com.abacogroup.calculatorengine.common.core.ReqContext;
import com.abacogroup.calculatorengine.core.exceptions.CalculatorJobException;
import com.abacogroup.calculatorengine.core.exceptions.ReportException;
import com.abacogroup.calculatorengine.core.exceptions.ReportException.ErrEnum;
import com.abacogroup.calculatorengine.core.service.CalculatorTypeService;
import com.abacogroup.calculatorengine.db.dao.CalculatorTypeDAO;
import com.abacogroup.calculatorengine.db.dao.ResultDAO;
import com.abacogroup.calculatorengine.db.dao.WfConfigurationDAO;
import com.abacogroup.calculatorengine.db.ntt.CalculatorTypeEntity;
import com.abacogroup.calculatorengine.db.ntt.ResultEntity;
import com.abacogroup.calculatorengine.resources.req.CalculatorReq;
import com.abacogroup.calculatorengine.sdk.CalculatorEngineUtils;
import com.abacogroup.calculatorengine.sdk.model.AuthContextImpl;
import com.abacogroup.calculatorengine.sdk.model.CalculationResult;
import com.abacogroup.calculatorengine.sdk.model.CalculatorEngineInput;
import com.abacogroup.workflow.sdk.auth.AuthContext;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import com.abacogroup.workflow.server.model.CreateProcessParams;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import com.abacogroup.workflow.server.model.WorkflowVersion;
import com.abacogroup.workflow.server.services.ProcessService;
import com.abacogroup.workflow.server.services.WorkflowService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.azam.ulidj.ULID;
import jakarta.ws.rs.core.SecurityContext;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CalculatorTypeServiceImpl implements CalculatorTypeService {

	private static final Object INIT_MUTEX = new Object();
	private static final String READY_MARKER_FILE_NAME = String.format(".calculator-engine-%s", UUID.randomUUID());

	private final CalculatorTypeDAO calculatorTypeDAO;
	private final ResultDAO resultDAO;
	private final WfConfigurationDAO wfConfigurationDAO;

	private final WorkflowService workflowService;
	private final ProcessService<ProcedureEnvironment> processService;

	private final CalculatorEngineConfiguration.CalculatorConfig calculatorConfig;

	private final ObjectMapper objectMapper;

	public CalculatorTypeServiceImpl(CalculatorTypeDAO calculatorTypeDAO, ResultDAO resultDAO, WfConfigurationDAO wfConfigurationDAO,
			WorkflowService workflowService, ProcessService<ProcedureEnvironment> processService,
			CalculatorEngineConfiguration.CalculatorConfig calculatorConfig,
			ObjectMapper objectMapper) {
		this.calculatorTypeDAO = calculatorTypeDAO;
		this.resultDAO = resultDAO;
		this.wfConfigurationDAO = wfConfigurationDAO;
		this.workflowService = workflowService;
		this.processService = processService;
		this.calculatorConfig = calculatorConfig;
		this.objectMapper = objectMapper;
	}

	@Override
	public ResultEntity insertCalcJob(String calcTypeCode, CalculatorReq calculatorReq, ReqContext reqContext) {
		CalculatorTypeEntity calculatorTypeEntity = this.getCalculatorType(reqContext.getTenantId(), calcTypeCode);

		ResultEntity entity = ResultEntity.builder()
				.setUuid(ULID.random(ThreadLocalRandom.current()))
				.setCalcTypeId(calculatorTypeEntity.getId())
				.setStatus(ACKNOWLEDGE)
				.setJsonConfigs(wfConfigurationDAO.getJsonConfig(reqContext.getTenantId(), calcTypeCode))
				.setDest(calculatorReq.getDest())
				.build();

		AuditHelper.setAuditForInsert(entity, reqContext.getUsername(), resultDAO);

		resultDAO.insert(entity);
		return entity;
	}

	@Override
	public void addType(CalculatorTypeEntity entity) {
		calculatorTypeDAO.findByTenantAndCode(entity.getTenantId(), entity.getWorkflowCode())
				.ifPresentOrElse(
						reportEntity -> log.debug("calculator type present"),
						() -> calculatorTypeDAO.insert(entity));
	}

	@Override
	public CalculatorJobResponse getJobStatus(String tenantId, String uuid) {
		ResultEntity entity = resultDAO.findByTenantAndUUID(tenantId, uuid)
				.orElseThrow(() -> new CalculatorJobException(CalculatorJobException.ErrEnum.CALC_JOB_NOT_FOUND,
						String.format("no job found for this UUID : %s ", uuid)));

		return CalculatorJobMapper.INSTANCE.entityToResponse(entity);
	}

	@Override
	public void updateJobStatus(String jobUuid, CalculatorJobStatus status) {
		resultDAO.updateStatus(jobUuid, status, resultDAO.getCurrentTimestamp());
	}

	@Override
	public void markAsReady(String jobUuid, CalculationResult<?> calculationResult) {
		try {
			String result = objectMapper.writeValueAsString(calculationResult.getResult());
			String renderResult = objectMapper.writeValueAsString(calculationResult.getRenderData());

			resultDAO.updateStatus(jobUuid, READY, result, renderResult, resultDAO.getCurrentTimestamp());
		} catch (JsonProcessingException e) {

			// TODO proper exception
			throw new RuntimeException(e);
		}

	}

	@Override
	public ProcessTransitionResult startCalculatorWorkflow(String workflowCode, String calcUuid, CalculatorEngineInput input, SecurityContext securityContext,
			String locale, String tenantId) {
		try {
			AuthContext authContext = new AuthContextImpl(securityContext, locale);
			String prefix = String.format("%s_", calcUuid);
			this.setupSourceDir(tenantId, workflowCode, prefix);

			String configJson = wfConfigurationDAO.getJsonConfig(tenantId, workflowCode);
			if (StringUtils.isNotBlank(configJson)) {
				// add config payload as wf param
				input.getParams().put(WFCONFIG_PAYLOAD, configJson);
			}

			// Always add the calculation UUID
			input.getParams().put(UUID_PARAM_NAME, calcUuid);

			log.info("starting calculator workflow {}", workflowCode);
			ProcessTransitionResult result = processService.createProcess(CreateProcessParams.builder()
					.authContext(authContext)
					.scope(SCOPE)
					.tenantId(tenantId)
					.workflowCode(workflowCode)
					.globalVars(
							new HashMap<>(Map.of(PARAM_NAME, input)))
					.returnGlobalVars(true)
					.build());

			if (result.getLastTransitionLog().isFailed()) {
				log.error("calculator workflow {} failed. process id: {}", workflowCode, result.getProcessId());
				throw new ReportException(ErrEnum.CALC_ERROR, String.format("calculation failed. process id: %s, notes: %s",
						result.getProcessId(), result.getLastTransitionLog().getNotes()));
			}

			log.info("calculator workflow {} completed! process id: {}", workflowCode, result.getProcessId());

			return result;

		} catch (IOException e) {
			log.error("calculator workflow {} failed: {}", workflowCode, e.getMessage(), e);
			throw new ReportException(ErrEnum.CALC_ERROR, String.format("calculation failed. %s",
					e.getLocalizedMessage())); // TODO exception with my uuid
		}
	}

	private CalculatorTypeEntity getCalculatorType(String tenantId, String calcTypeCode) {
		return calculatorTypeDAO.findByTenantAndCode(tenantId, calcTypeCode)
				.orElseThrow(() -> new ReportException(ReportException.ErrEnum.TYPE_NOT_FOUND,
						String.format("calculation flow %s does not exist", calcTypeCode)));
	}

	private void setupSourceDir(String tenantId, String workflowCode, String prefix) {
		try {
			WorkflowVersion workflowVersion = workflowService.getWorkflowVersion(tenantId, workflowCode);
			// check if exists and not empty
			Path sourceDir = CalculatorEngineUtils.getSourceDir(calculatorConfig.getInitBaseTempDir(),
					tenantId, workflowCode, workflowVersion.getHash());

			synchronized (INIT_MUTEX) {
				File sourceDirFile = sourceDir.toFile();
				boolean exists = sourceDirFile.exists() && sourceDirFile.isDirectory();
				if (exists) {
					File file = new File(sourceDirFile, READY_MARKER_FILE_NAME);
					exists = file.exists();
				}
				if (!exists) {
					// pick the jar
					Path jarPath = Path.of(String.format("%s.jar", sourceDir));
					FileOutputStream out = FileUtils.openOutputStream(jarPath.toFile());
					workflowService.getWorkflowPackage(tenantId, workflowCode, out);

					FileSupport.unzip(new FileInputStream(jarPath.toFile()), sourceDir);

					FileUtils.touch(new File(sourceDirFile, READY_MARKER_FILE_NAME));
				}

			}

		} catch (IOException ex) {
			String msg = String.format("error creating workdir for tenant %s and workflow %s", tenantId, workflowCode);
			log.error(msg, ex);
			throw new ReportException(ErrEnum.GENERIC, msg);
		}
	}
}
