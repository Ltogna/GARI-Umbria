package com.abacogroup.calculatorengine.common.core;

import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.PrincipalImpl;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NonNull;
import java.util.Optional;

@Data
@AllArgsConstructor
public class ReqContext {

    private static final String LANG_DEFAULT = "en";

    private User user;
    private String lang;

    public ReqContext(@NonNull String tenantId, @NonNull String username, String lang) {
        this.setUser(new User(username, tenantId));
        this.lang = lang;
    }

    public ReqContext(@NonNull String tenantId, @NonNull String username) {
        this(tenantId, username, LANG_DEFAULT);
    }

    public String getUsername() {
        return Optional.of(user)
                .map(PrincipalImpl::getName)
                .orElseThrow();
    }

    public String getTenantId() {
        return Optional.of(user)
                .map(User::getTenant)
                .orElseThrow();
    }

    public String getLang() {
        return Optional.ofNullable(lang).orElse(LANG_DEFAULT);
    }

}

