package com.abacogroup.calculatorengine.core.embededqueue;

import com.abacogroup.calculatorengine.resources.req.CalculatorReq;
import com.abacogroup.calculatorengine.sdk.model.CalculatorEngineInput;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(setterPrefix = "set")
@AllArgsConstructor
@NoArgsConstructor
public class CalcJob {

	private String jobUuid;
	private String userName;
	private String locale;
	private String tenantId;
	private String workflowCode;
	private CalculatorEngineInput input;
	@Default
	private CalculatorReq calculatorReq = new CalculatorReq();

}
