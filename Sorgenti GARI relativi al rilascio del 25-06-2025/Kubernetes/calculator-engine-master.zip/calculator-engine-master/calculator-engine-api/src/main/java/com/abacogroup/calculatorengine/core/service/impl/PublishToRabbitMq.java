package com.abacogroup.calculatorengine.core.service.impl;

import com.abacogroup.calculatorengine.api.CalculatorJobResponse;
import com.abacogroup.calculatorengine.core.service.CalculatorJobEventProducer;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisher;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisherWorkQueue;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Connection;
import io.dropwizard.core.setup.Environment;
import java.io.IOException;
import java.util.Map;
import java.util.Objects;
import org.jdbi.v3.core.Jdbi;

public class PublishToRabbitMq extends RabbitMqPublisherWorkQueue<CalculatorJobMessage> implements CalculatorJobEventProducer {

	public static final String EXCHANGE = "clc-engine-exchange";

	public PublishToRabbitMq(Environment environment, Jdbi jdbi, Connection connection, ObjectMapper mapper) throws IOException {
		super("publish-to-rabbitmq", new JdbiRepository(jdbi));

		var publisher = new RabbitMqPublisher<CalculatorJobMessage>(Objects.requireNonNull(connection)) {
			@Override
			protected String getExchangeName() {
				return EXCHANGE;
			}

			@Override
			protected String getRoutingKey(CalculatorJobMessage element) {
				return element.getRoutingKey();
			}

			@Override
			protected Map<String, Object> getMessageHeaders(CalculatorJobMessage element) {
				return Map.of("tenant", element.getTenant());
			}

			@Override
			protected byte[] getPayload(CalculatorJobMessage element) throws Exception {
				return getObjectMapper().writeValueAsBytes(element.getMessage());
			}
		};

		setConsumer(publisher);
		setMetricRegistry(environment.metrics());
		setObjectMapper(mapper);

		start();
	}

	@Override
	public void pushEvent(CalculatorJobResponse message, String tenant, JobEventType eventType) throws IOException {
		add(new CalculatorJobMessage(tenant, message, eventType), System.currentTimeMillis());
	}

	@Override
	protected Class<CalculatorJobMessage> getJobClass() {
		return CalculatorJobMessage.class;
	}

}
