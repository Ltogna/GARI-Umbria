package com.abacogroup.calculatorengine.db.ntt;

import com.abacogroup.calculatorengine.api.CalculatorJobStatus;
import com.abacogroup.jdbi.model.AuditEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class ResultEntity implements AuditEntity {

	private String uuid;
	private Long calcTypeId;
	private CalculatorJobStatus status;
	private String calcResult;
	private String calcRenderResult;
	private String dest;
	private String jsonConfigs;
	private LocalDateTime dtInsert;
	private String userIdInsert;
	private LocalDateTime dtDelete;
	private String userIdDelete;

}
