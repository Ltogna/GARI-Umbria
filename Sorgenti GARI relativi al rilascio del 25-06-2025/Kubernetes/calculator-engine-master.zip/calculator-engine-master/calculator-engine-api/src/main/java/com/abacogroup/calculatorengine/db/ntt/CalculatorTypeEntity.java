package com.abacogroup.calculatorengine.db.ntt;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class CalculatorTypeEntity {

	private Long id;

	private String tenantId;

	private String workflowCode;

}
