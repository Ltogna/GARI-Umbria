package com.abacogroup.calculatorengine.counter;

import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.jdbi.v3.core.Jdbi;

import com.abacogroup.calculatorengine.sdk.counter.Counter;

import io.dropwizard.lifecycle.setup.ExecutorServiceBuilder;
import io.dropwizard.lifecycle.setup.LifecycleEnvironment;

public class JdbiCounter implements Counter {

	private final Jdbi jdbi;
	private final ExecutorService executor;

	public JdbiCounter(LifecycleEnvironment lifecycle, Jdbi jdbi) {
		this.jdbi = jdbi;

		this.executor = new ExecutorServiceBuilder(lifecycle, "jdbi-counters")
				.minThreads(1)
				.maxThreads(1)
				.workQueue(new SynchronousQueue<>())
				.build();
	}

	@Override
	public long next(String tenant, String counterName) {
		// We need to execute this in a dedicated thread to be sure that we are in a different transaction.
		Future<Long> fut = executor.submit(() -> doNext(tenant, counterName));

		Long ret;
		try {
			ret = fut.get(10, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			throw new IllegalStateException(e);
		} catch (ExecutionException | TimeoutException e) {
			throw new RuntimeException("Error obtaining next value for counter " + counterName, e);
		}

		return ret;
	}

	private long doNext(String tenant, String counterName) {
		return jdbi.inTransaction(h -> {
			// select counter
			// insert counter or update counter

			// Lock the counter
			h.createUpdate("insert into clc_counters_lock (tenant_id, counter_name) values (:tenant_id, :counter_name)")
					.bind("tenant_id", tenant)
					.bind("counter_name", counterName)
					.execute();

			Optional<Long> lastValue = h.createQuery("select last_val from clc_counters where tenant_id=:tenant_id and counter_name=:counter_name")
					.bind("tenant_id", tenant)
					.bind("counter_name", counterName)
					.mapTo(Long.class)
					.findOne();

			long ret = 1;
			if (lastValue.isEmpty()) {
				h.createUpdate("insert into clc_counters (tenant_id, counter_name, last_val) values (:tenant_id, :counter_name, 1)")
						.bind("tenant_id", tenant)
						.bind("counter_name", counterName)
						.execute();
			} else {
				ret = lastValue.get() + 1;
				h.createUpdate("update clc_counters set last_val=:last_val where tenant_id=:tenant_id and counter_name=:counter_name")
						.bind("tenant_id", tenant)
						.bind("counter_name", counterName)
						.bind("last_val", ret)
						.execute();
			}

			// Unlock the counter
			h.createUpdate("delete from clc_counters_lock where tenant_id=:tenant_id and counter_name=:counter_name")
					.bind("tenant_id", tenant)
					.bind("counter_name", counterName)
					.execute();

			return ret;
		});
	}

}
