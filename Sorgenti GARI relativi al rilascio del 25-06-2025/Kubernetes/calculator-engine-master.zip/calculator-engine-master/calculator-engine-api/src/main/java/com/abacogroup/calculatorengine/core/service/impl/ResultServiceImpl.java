package com.abacogroup.calculatorengine.core.service.impl;

import com.abacogroup.calculatorengine.api.CalculatorJobStatus;
import com.abacogroup.calculatorengine.common.core.ReqContext;
import com.abacogroup.calculatorengine.core.exceptions.CalculatorJobException;
import com.abacogroup.calculatorengine.core.exceptions.CalculatorJobException.ErrEnum;
import com.abacogroup.calculatorengine.core.service.ResultService;
import com.abacogroup.calculatorengine.db.dao.ResultDAO;
import com.abacogroup.calculatorengine.db.ntt.ResultEntity;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ResultServiceImpl implements ResultService {

	private final ResultDAO resultDAO;

	public ResultServiceImpl(ResultDAO resultDAO) {
		this.resultDAO = resultDAO;
	}

	@Override
	public ResultEntity getResult(ReqContext context, String uuid) {
		ResultEntity result = resultDAO.findByTenantAndUUID(context.getTenantId(), uuid)
				.orElseThrow(() -> new CalculatorJobException(ErrEnum.CALC_JOB_NOT_FOUND,
						String.format("no job found for this UUID : %s ", uuid)));
		if (!result.getStatus().equals(CalculatorJobStatus.READY)) {
			throw new CalculatorJobException(ErrEnum.CALC_JOB_ERROR,
					String.format("The status of job %s is still %s", uuid, result.getStatus()));
		}
		return result;
	}

}
