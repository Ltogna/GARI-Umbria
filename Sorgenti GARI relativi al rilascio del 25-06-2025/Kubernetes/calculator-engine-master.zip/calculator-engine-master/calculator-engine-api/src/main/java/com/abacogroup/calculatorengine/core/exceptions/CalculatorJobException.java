package com.abacogroup.calculatorengine.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

public class CalculatorJobException extends AbstractAppException {

	private static final long serialVersionUID = 8576761590901517085L;

	public CalculatorJobException(ErrEnum code, String message) {
		super(new ErrorBody(code.name(), message));
	}

	public enum ErrEnum {
		GENERIC,
		CALC_JOB_ERROR,
		CALC_JOB_NOT_FOUND
	}

	@Schema(name = "CalculatorJobExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { "GENERIC", "CALC_JOB_ERROR", "CALC_JOB_NOT_FOUND" })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}
}
