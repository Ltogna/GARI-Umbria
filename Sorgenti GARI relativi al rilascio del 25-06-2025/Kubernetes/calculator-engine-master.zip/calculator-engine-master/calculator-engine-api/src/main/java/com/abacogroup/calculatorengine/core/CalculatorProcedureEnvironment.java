package com.abacogroup.calculatorengine.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.core.Jdbi;

import com.abacogroup.calculatorengine.CalculatorEngineConfiguration.CalculatorConfig;
import com.abacogroup.calculatorengine.sdk.CalculatorEngineUtils;
import com.abacogroup.calculatorengine.sdk.ProcEnvConstants;
import com.abacogroup.calculatorengine.sdk.counter.Counter;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.client.Client;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CalculatorProcedureEnvironment implements ProcedureEnvironment, AutoCloseable {
	public static final String BASE_PROPERTIES_FILE_NAME = "application";
	private final Client client;

	private final ObjectMapper objectMapper;
	private final CalculatorConfig calculatorConfig;
	private final Counter counter;

	private final String workDir;
	private final String sourceDir;

	private final Properties propertiesMap;

	private final List<AutoCloseable> closeables;

	public CalculatorProcedureEnvironment(ProcessData processData, Client client, ObjectMapper objectMapper, CalculatorConfig calculatorConfig,
			Counter counter) {
		this.client = client;

		this.objectMapper = objectMapper;
		this.calculatorConfig = Optional.ofNullable(calculatorConfig).orElse(new CalculatorConfig());

		// paths
		String tenantId = processData.getTenantId();
		String workflowCode = processData.getWorkflowCode();
		String workflowHash = processData.getWorkflowHash();
		// Long processId = processData.getProcessId();

		this.counter = counter;
		this.workDir = this.calculatorConfig.getInitBaseTempDir();
		this.sourceDir = CalculatorEngineUtils.getSourceDir(this.workDir, tenantId, workflowCode, workflowHash)
				.toFile().getAbsolutePath();
		this.propertiesMap = this.retrieveProperties(sourceDir, this.calculatorConfig, processData);
		this.closeables = new ArrayList<>();
	}

	@Override
	@SuppressWarnings("unchecked")
	public <T> Optional<T> getProperty(String name) {

		Object ret = null;
		switch (name) {
		case ProcEnvConstants.PROPERTY_WORK_DIR:
			ret = workDir;
			break;
		case ProcEnvConstants.PROPERTY_SOURCE_DIR:
			ret = sourceDir;
			break;
		case ProcEnvConstants.PROPERTY_OBJECT_MAPPER:
			ret = objectMapper;
			break;
		case ProcEnvConstants.PROPERTY_PROFILE:
			ret = calculatorConfig.getWorkFlowEnvironmentId();
			break;
		case ProcEnvConstants.PROPERTY_COUNTER:
			ret = counter;
			break;
		default:
			ret = propertiesMap.get(name);
			break;
		}

		return Optional.ofNullable((T) ret);
	}

	@Override
	public Optional<Client> getJerseyClient() {
		return Optional.ofNullable(client);
	}

	@Override
	public Optional<Jdbi> getJdbi(String datasourceName) {
		return Optional.empty();
	}

	// TODO ENABLE
	// @Override
	// public String getEnvironmentId() {
	// return calculatorEngineConfiguration.getProfile();
	// }

	@Override
	public void close() throws Exception {
		Exception ex = null;
		for (AutoCloseable c : closeables) {
			try {
				c.close();
			} catch (Exception e) {
				log.error(e.getMessage(), e);
				ex = e;
			}
		}

		if (ex != null) {
			throw ex;
		}
	}

	private Properties retrieveProperties(String sourceDir, CalculatorConfig calculatorConfig, ProcessData processData) {
		String envId = calculatorConfig.getWorkFlowEnvironmentId();
		String workflowCode = processData.getWorkflowCode();
		String tenantId = processData.getTenantId();

		log.info("active envId: {}", envId);
		List<String> propertySources;
		String externalPropertiesDir = calculatorConfig.getExternalPropertiesDir();
		if (StringUtils.isNotBlank(externalPropertiesDir)) {
			externalPropertiesDir = StringUtils.removeEnd(externalPropertiesDir, "/");
			propertySources = List.of(
					sourceDir,
					externalPropertiesDir,
					String.format("%s/%s", externalPropertiesDir, tenantId),
					String.format("%s/%s/%s", externalPropertiesDir, tenantId, workflowCode));
		} else {
			propertySources = List.of(sourceDir);
		}

		Properties properties = new Properties();
		for (String propertySource : propertySources) {
			log.debug("scan {} properties in {}", workflowCode, propertySource);
			properties = CalculatorEngineUtils.retrieveProperties(properties, propertySource, BASE_PROPERTIES_FILE_NAME, envId);
		}

		var props = CalculatorEngineUtils.resolveProperties(properties, properties);
		log.debug("current properties: {}", props);
		return props;
	}
}
