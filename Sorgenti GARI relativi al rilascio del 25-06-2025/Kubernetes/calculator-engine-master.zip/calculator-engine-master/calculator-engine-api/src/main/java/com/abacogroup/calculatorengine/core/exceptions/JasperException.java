package com.abacogroup.calculatorengine.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

public class JasperException extends AbstractAppException {

	private static final long serialVersionUID = -6619776912483608787L;

	public JasperException(ErrEnum code, String message) {
		super(new ErrorBody(code.name(), message));
	}

	public enum ErrEnum {
		COMPILE_ERR
	}

	@Schema(name = "JasperExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = { "COMPILE_ERR" })
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}
}
