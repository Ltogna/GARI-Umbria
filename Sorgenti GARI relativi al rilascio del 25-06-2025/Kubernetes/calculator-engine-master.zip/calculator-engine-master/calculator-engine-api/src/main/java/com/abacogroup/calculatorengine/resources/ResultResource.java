package com.abacogroup.calculatorengine.resources;

import static com.abacogroup.calculatorengine.resources.ResourceConstants.API_PUB;

import java.util.Locale;

import com.abacogroup.calculatorengine.common.core.ReqContext;
import com.abacogroup.calculatorengine.core.exceptions.CalculatorJobException;
import com.abacogroup.calculatorengine.core.service.ResultService;
import com.abacogroup.calculatorengine.db.ntt.ResultEntity;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.PermitAll;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.SecurityContext;

@Path(API_PUB)
@PermitAll
@Timed
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Calculation Results", description = "Operations on calculation results")
public class ResultResource {

	private final ResultService resultService;

	public ResultResource(ResultService resultService) {
		this.resultService = resultService;
	}

	@GET
	@Path("/jobs/{uuid}/results/raw")
	@Operation(summary = "Get calculation result", description = "Retrieve the raw calculation result")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Raw calculation result found", content = @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = String.class)))),
			@ApiResponse(responseCode = "404", description = "Calculation job not found", content = @Content(schema = @Schema(implementation = CalculatorJobException.ErrorBody.class)))
	})
	public Response getRawResult(
			@Parameter(description = "Calculation job ID") @PathParam("uuid") String uuid,
			@Parameter(description = "Tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(hidden = true) @Context SecurityContext security,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(in = ParameterIn.HEADER, schema = @Schema(implementation = String.class)) @HeaderParam("Accept-Language") @DefaultValue("en") Locale locale) {
		ReqContext reqContext = new ReqContext(user, locale.getLanguage());
		ResultEntity result = resultService.getResult(reqContext, uuid);
		return Response.ok(result.getCalcResult()).build();
	}

	@GET
	@Path("/jobs/{uuid}/results/render")
	@Operation(summary = "Get calculation internal result", description = "Retrieve the render result")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Render result found", content = @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = String.class)))),
			@ApiResponse(responseCode = "404", description = "Calculation job not found", content = @Content(schema = @Schema(implementation = CalculatorJobException.ErrorBody.class)))
	})
	public Response getInternalResult(
			@Parameter(description = "Calculation job ID") @PathParam("uuid") String uuid,
			@Parameter(description = "Tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(hidden = true) @Context SecurityContext security,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(in = ParameterIn.HEADER, schema = @Schema(implementation = String.class)) @HeaderParam("Accept-Language") @DefaultValue("en") Locale locale) {
		ReqContext reqContext = new ReqContext(user, locale.getLanguage());
		ResultEntity result = resultService.getResult(reqContext, uuid);
		return Response.ok(result.getCalcRenderResult()).build();
	}
}
