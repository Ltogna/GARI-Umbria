package com.abacogroup.calculatorengine;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;
import java.util.concurrent.TimeoutException;

import javax.sql.DataSource;

import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.jdbi.v3.core.Jdbi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.Constants;
import com.abacogroup.bundles.initializer.BundleInitServiceBuilder;
import com.abacogroup.bundles.initializer.InitService;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.listener.ListenerBuilder;
import com.abacogroup.bundles.listener.RabbitListener;
import com.abacogroup.bundles.listener.configdata.ConfigDataLogProducer;
import com.abacogroup.bundles.listener.configdata.ProcessorOrderPolicyEnum;
import com.abacogroup.bundles.listener.configdata.builder.ConfigDataConsumerBuilder;
import com.abacogroup.calculatorengine.CalculatorEngineConfiguration.BundleConfig;
import com.abacogroup.calculatorengine.CalculatorEngineConfiguration.RabbitmqConfig;
import com.abacogroup.calculatorengine.bundle.config.CalculatorTypeConfigMessageProcessor;
import com.abacogroup.calculatorengine.bundle.config.WfConfigurationConfigMessageProcessor;
import com.abacogroup.calculatorengine.core.CalculatorProcedureEnvironment;
import com.abacogroup.calculatorengine.core.embededqueue.CalcQueue;
import com.abacogroup.calculatorengine.core.service.CalculatorJobEventProducer;
import com.abacogroup.calculatorengine.core.service.CalculatorTypeService;
import com.abacogroup.calculatorengine.core.service.ResultService;
import com.abacogroup.calculatorengine.core.service.impl.CalculatorTypeServiceImpl;
import com.abacogroup.calculatorengine.core.service.impl.PublishToRabbitMq;
import com.abacogroup.calculatorengine.core.service.impl.ResultServiceImpl;
import com.abacogroup.calculatorengine.counter.JdbiCounter;
import com.abacogroup.calculatorengine.db.dao.CalculatorTypeDAO;
import com.abacogroup.calculatorengine.db.dao.ResultDAO;
import com.abacogroup.calculatorengine.db.dao.WfConfigurationDAO;
import com.abacogroup.calculatorengine.resources.CalculatorResource;
import com.abacogroup.calculatorengine.resources.JobResource;
import com.abacogroup.calculatorengine.resources.ResultResource;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.jdbi.OraJdbiPlugin;
import com.abacogroup.jdbi.OraJdbiPlugin.OraJdbiPluginParams;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.jdbi.config.AbacoJdbiConfig;
import com.abacogroup.tracing.dropwizard.AbacoApplication;
import com.abacogroup.tracing.jaxrs.client.AddRequestId;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import com.abacogroup.workflow.server.services.ProcessService;
import com.abacogroup.workflow.server.services.WorkflowService;
import com.codahale.metrics.MetricRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.jdbi3.JdbiFactory;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import io.dropwizard.migrations.MigrationsBundle;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import io.swagger.v3.oas.integration.ClasspathOpenApiConfigurationLoader;
import io.swagger.v3.oas.integration.api.OpenAPIConfiguration;
import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration.Dynamic;
import jakarta.ws.rs.client.Client;

public class CalculatorEngineApplication extends AbacoApplication<CalculatorEngineConfiguration> {
	private static final Logger log = LoggerFactory.getLogger(CalculatorEngineApplication.class);

	public static void main(String[] args) throws Exception {
		new CalculatorEngineApplication().run(args);
	}

	@Override
	public String getName() {
		return "calculator-engine";
	}

	@Override
	public void initialize(Bootstrap<CalculatorEngineConfiguration> bootstrap) {
		bootstrap.addBundle(new MigrationsBundle<>() {
			@Override
			public DataSourceFactory getDataSourceFactory(CalculatorEngineConfiguration configuration) {
				return configuration.getDatabase();
			}
		});

		SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
				new EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);
	}

	@Override
	public void doRun(CalculatorEngineConfiguration configuration, Environment environment) throws Exception {
		ObjectMapper objectMapper = environment.getObjectMapper();
		configureObjectMapper(objectMapper);

		try {
			new org.h2.Driver();
		} catch (Exception e) {
			log.warn("Error initializing h2", e);
		}

		Jdbi jdbi = jdbi(configuration, environment);

		Client client = createJaxRsClient(configuration, environment);

		Connection rabbitmqConnection = this.createRabbitmqConnection(configuration);

		final Sso2Client sso2Client = this.initSso2Client(configuration, environment);
		this.initAuth(environment, sso2Client);

		this.initMultiTenant(environment);
		this.initOpenApi(environment.jersey());
		this.setupCORS(configuration, environment);

		JdbiCounter jdbiCounter = new JdbiCounter(environment.lifecycle(), jdbi);

		WorkflowService workflowService = this.register(new WorkflowService(jdbi));
		ProcessService<ProcedureEnvironment> processService = register(new ProcessService<>(jdbi, ProcedureEnvironment.class,
				processData -> new CalculatorProcedureEnvironment(processData, client, objectMapper, configuration.getCalculatorConfig(), jdbiCounter)));

		final CalculatorJobEventProducer calculatorJobEventProducer = this.register(
				createCalcJobEventProducer(environment, jdbi, objectMapper, rabbitmqConnection));

		final CalculatorTypeDAO calculatorTypeDAO = jdbi.onDemand(CalculatorTypeDAO.class);
		final ResultDAO resultDAO = jdbi.onDemand(ResultDAO.class);
		final WfConfigurationDAO wfConfigurationDAO = jdbi.onDemand(WfConfigurationDAO.class);

		final CalculatorTypeService calculatorTypeService = this.register(
				new CalculatorTypeServiceImpl(calculatorTypeDAO, resultDAO, wfConfigurationDAO, workflowService, processService,
						configuration.getCalculatorConfig(), objectMapper));

		final ResultService resultService = this.register(new ResultServiceImpl(resultDAO));

		CalcQueue calcQueue = this.register(new CalcQueue(new JdbiRepository(jdbi), environment.metrics(),
				calculatorTypeService,
				sso2Client, calculatorJobEventProducer, configuration.getCalculatorConfig()));

		List<Object> resources = new ArrayList<>();

		// // public
		resources.add(new CalculatorResource(calculatorTypeService, resultService, calcQueue));
		resources.add(new JobResource(calculatorTypeService));
		resources.add(new ResultResource(resultService));

		resources.forEach(environment.jersey()::register);

		// ---------------------------------------------------------------------------

		RabbitListener rabbitListener = ListenerBuilder
				.newBuilder(rabbitmqConnection)
				.withConfigDataConsumer(this.register(ConfigDataConsumerBuilder.newBuilder(jdbi, rabbitmqConnection)
						.route(this.getName())
						.processor(
								this.register(new CalculatorTypeConfigMessageProcessor(
										calculatorTypeService,
										environment.metrics(), workflowService, configuration)))
						.processor(
								this.register(new WfConfigurationConfigMessageProcessor(
										wfConfigurationDAO)))
						.configLogProducer(configDataLogProducerBean(objectMapper, rabbitmqConnection))
						.withOrderPolicy(ProcessorOrderPolicyEnum.PROCESSOR)
						.build()))
				.buildListener();

		BundleConfig bundleConfig = Optional.ofNullable(configuration.getBundleConfig()).orElseGet(BundleConfig::new);
		InitService bundleInitService = BundleInitServiceBuilder
				.producer(this.register(new BundleInitServiceProducer(rabbitmqConnection)))
				.configLocation(bundleConfig.getConfigLocation())
				// .baseTempDir()
				.build();
		//
		this.startRabbitConsumerAndProducers(bundleInitService, rabbitListener);

		// ---------------------------------------------------------------------------

		this.afterServicesUp();
	}

	protected CalculatorJobEventProducer createCalcJobEventProducer(Environment environment, Jdbi jdbi, ObjectMapper objectMapper,
			Connection rabbitmqConnection)
			throws IOException {
		return new PublishToRabbitMq(environment, jdbi, rabbitmqConnection, objectMapper);
	}

	protected DataSource createDatasource(DataSourceFactory database, MetricRegistry metrics, String name) throws SQLException {
		return database.build(metrics, name);
	}

	protected void startRabbitConsumerAndProducers(InitService initService, RabbitListener rabbitListener) throws Exception {
		rabbitListener.start();
		if (initService != null) {
			initService.start();
		}
	}

	protected void afterServicesUp() {
		log.debug("application started");
	}

	protected <T> T register(T service) {
		return service;
	}

	protected ConfigDataLogProducer configDataLogProducerBean(ObjectMapper objectMapper, Connection rabbitmqConnection) {
		return this.register(new ConfigDataLogProducer(objectMapper, rabbitmqConnection, Constants.DEFAULT_EXCHANGE_NAME));
	}

	protected void initAuth(Environment environment, Sso2Client sso2Cli) {
		AuthUtils.installAuthFilter(environment, sso2Cli);
	}

	private Sso2Client initSso2Client(CalculatorEngineConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build("sso2-client");
		client.register(new AddRequestId());
		return new Sso2Client(configuration.getSso2Config().getTasksAuthPhrase(), client.target(configuration.getSso2Config().getUrl()));
	}

	private Client createJaxRsClient(CalculatorEngineConfiguration configuration, Environment environment) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClient())
				.build(this.getName());
		client.register(new AddRequestId());
		return client;
	}

	protected Jdbi jdbi(final CalculatorEngineConfiguration configuration, final Environment environment) {
		final JdbiFactory factory = new JdbiFactory();
		final Jdbi jdbi = factory.build(environment, configuration.getDatabase(), "CalculatorEngineApp");

		jdbi.configure(AbacoJdbiConfig.class, cfg -> cfg.setTablesPrefix("mor"));

		String driverClassName = Optional.ofNullable(configuration.getDatabase()
				.getDriverClass())
				.orElse("");

		if (driverClassName.equalsIgnoreCase("org.postgresql.Driver")) {
			jdbi.installPlugin(new PgJdbiPlugin());
		} else {
			OraJdbiPluginParams params = new OraJdbiPluginParams(cnn -> cnn.unwrap(oracle.jdbc.OracleConnection.class), true);
			jdbi.installPlugin(new OraJdbiPlugin(params));
		}
		return jdbi;
	}

	protected Connection createRabbitmqConnection(CalculatorEngineConfiguration configuration)
			throws IOException, TimeoutException {
		RabbitmqConfig rabbitmqConfig = configuration.getRabbitmqConfig();

		ConnectionFactory factory = new ConnectionFactory();

		if (rabbitmqConfig.getHost() != null) {
			factory.setHost(rabbitmqConfig.getHost());
		}
		if (rabbitmqConfig.getUser() != null) {
			factory.setUsername(rabbitmqConfig.getUser());
		}
		if (rabbitmqConfig.getPassword() != null) {
			factory.setPassword(rabbitmqConfig.getPassword());
		}
		if (rabbitmqConfig.getVirtualhost() != null) {
			factory.setVirtualHost(rabbitmqConfig.getVirtualhost());
		}
		if (rabbitmqConfig.getPort() != null) {
			factory.setPort(rabbitmqConfig.getPort());
		}
		factory.setAutomaticRecoveryEnabled(true);

		return factory.newConnection();
	}

	protected void configureObjectMapper(ObjectMapper objectMapper) {
		objectMapper.registerModule(new JavaTimeModule());
		objectMapper
				.setTimeZone(TimeZone.getDefault())
				.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
	}

	protected void initOpenApi(JerseyEnvironment jersey) throws IOException {
		OpenAPIConfiguration oasConfig = new ClasspathOpenApiConfigurationLoader()
				.load("openapi-configuration.yaml");

		jersey.register(new OpenApiResource()
				.openApiConfiguration(oasConfig));
	}

	private void setupCORS(CalculatorEngineConfiguration configuration, Environment environment) {
		if (!configuration.isCors()) {
			log.info("CORS is disabled");
			return;
		}

		log.info("CORS is enabled");

		Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,DELETE");

		// OPTIONS pre-flight request will be served by the filter ONLY and not
		// passed ahead
		// cors.setInitParameter(CrossOriginFilter.CHAIN_PREFLIGHT_PARAM,
		// "false");

		// Add URL mapping
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

	private void initMultiTenant(Environment environment) {
		environment.jersey().register(new MultitenantFilter("tenant"));
	}

}
