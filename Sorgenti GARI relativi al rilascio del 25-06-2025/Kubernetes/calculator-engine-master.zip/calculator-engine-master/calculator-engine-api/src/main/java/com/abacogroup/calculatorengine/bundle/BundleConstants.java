package com.abacogroup.calculatorengine.bundle;

public class BundleConstants {
	public static final String CALC_TYPE_BUNDLE_NS = "calculator-type";
	public static final String WF_CONFIG_BUNDLE_NS = "calculator-config";

	public static final String SYSTEM_USER = "system";

}
