package com.abacogroup.calculatorengine.core.embededqueue;

import static com.abacogroup.embeddedqueue.QueueErrorListener.ErrorAction.MARK_AS_ERRORED;

import java.io.IOException;

import com.abacogroup.calculatorengine.CalculatorEngineConfiguration.CalculatorConfig;
import com.abacogroup.calculatorengine.api.CalculatorJobResponse;
import com.abacogroup.calculatorengine.api.CalculatorJobStatus;
import com.abacogroup.calculatorengine.core.service.CalculatorJobEventProducer;
import com.abacogroup.calculatorengine.core.service.CalculatorTypeService;
import com.abacogroup.calculatorengine.sdk.model.CalculationResult;
import com.abacogroup.calculatorengine.sdk.proc.SafeAbstractProcedure;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import com.codahale.metrics.MetricRegistry;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CalcQueue extends WorkQueue<CalcJob> {
	private static final String Q_ID = "calc-engine-process";
	private final Sso2Client sso2Client;
	private final CalculatorJobEventProducer eventProducer;
	private final CalculatorTypeService calculatorTypeService;

	public CalcQueue(JdbiRepository repo, MetricRegistry registry,
			CalculatorTypeService calculatorTypeService, Sso2Client sso2Client,
			CalculatorJobEventProducer eventProducer, CalculatorConfig config) {
		super(Q_ID, repo, config.getQueueThreads(), config.getQueueTimeoutMs());

		this.calculatorTypeService = calculatorTypeService;
		this.sso2Client = sso2Client;

		this.eventProducer = eventProducer;

		this.setMetricRegistry(registry);

		ThrowingConsumer<CalcJob> consumer = createConsumer();
		this.setConsumer(consumer);
		QueueErrorListener<CalcJob> errorListener = createErrorListener();
		this.setErrorListener(errorListener);

		this.start();
	}

	@Override
	protected Class<CalcJob> getJobClass() {
		return CalcJob.class;
	}

	private ThrowingConsumer<CalcJob> createConsumer() {
		return calcJob -> {
			calculatorTypeService.updateJobStatus(calcJob.getJobUuid(), CalculatorJobStatus.PROGRESS);
			var securityContext = sso2Client.createSecurityContextFromUserName(calcJob.getTenantId(), calcJob.getUserName());

			ProcessTransitionResult processTransitionResult = calculatorTypeService.startCalculatorWorkflow(
					calcJob.getWorkflowCode(),
					calcJob.getJobUuid(),
					calcJob.getInput(),
					securityContext,
					calcJob.getLocale(),
					calcJob.getTenantId());

			CalculationResult<?> calculationResult = null;
			if (!processTransitionResult.getLastTransitionLog().isFailed()) {
				// AddFileResponse fileResponse = storeFile(calcJob, securityContext, processTransitionResult);
				calculationResult = (CalculationResult<?>) processTransitionResult.getGlobalVars()
						.get(SafeAbstractProcedure.GLOBAL_VAR_RESULT_NAME);
				calculatorTypeService.markAsReady(calcJob.getJobUuid(), calculationResult);
			}
			this.sendEvent(calcJob, calculationResult);
		};
	}

	private QueueErrorListener<CalcJob> createErrorListener() {
		return (calcJob, exp) -> {
			calculatorTypeService.updateJobStatus(calcJob.getJobUuid(), CalculatorJobStatus.ERROR);
			this.sendEvent(calcJob, null);
			return MARK_AS_ERRORED;
		};
	}

	private void sendEvent(CalcJob calcJob, CalculationResult<?> calculationResult) {
		CalculatorJobResponse jobStatus = calculatorTypeService.getJobStatus(calcJob.getTenantId(), calcJob.getJobUuid());
		CalculatorJobEventProducer.JobEventType eventType = jobStatus.getStatus().equals(CalculatorJobStatus.READY)
				? CalculatorJobEventProducer.JobEventType.READY
				: CalculatorJobEventProducer.JobEventType.ERROR;
		try {
			eventProducer.pushEvent(jobStatus, calcJob.getTenantId(), eventType);
		} catch (IOException e) {
			log.error("cannot send calc {} event: {}", eventType, e.getMessage(), e);
		}
	}

}
