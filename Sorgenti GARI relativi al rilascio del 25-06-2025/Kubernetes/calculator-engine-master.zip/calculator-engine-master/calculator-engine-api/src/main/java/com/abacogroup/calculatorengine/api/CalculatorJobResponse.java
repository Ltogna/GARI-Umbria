package com.abacogroup.calculatorengine.api;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class CalculatorJobResponse {

	private String uuid;
	private CalculatorJobStatus status;
	private String dest;
}
