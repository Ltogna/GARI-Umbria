package com.abacogroup.calculatorengine.resources;

import static com.abacogroup.calculatorengine.resources.ResourceConstants.API_PUB;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Locale;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.calculatorengine.api.CreateCalculatorJobResponse;
import com.abacogroup.calculatorengine.common.core.ReqContext;
import com.abacogroup.calculatorengine.core.embededqueue.CalcJob;
import com.abacogroup.calculatorengine.core.embededqueue.CalcQueue;
import com.abacogroup.calculatorengine.core.exceptions.ReportException;
import com.abacogroup.calculatorengine.core.service.CalculatorTypeService;
import com.abacogroup.calculatorengine.core.service.ResultService;
import com.abacogroup.calculatorengine.db.ntt.ResultEntity;
import com.abacogroup.calculatorengine.resources.req.CalculatorReq;
import com.abacogroup.calculatorengine.sdk.model.CalculatorEngineInput;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.PermitAll;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.container.AsyncResponse;
import jakarta.ws.rs.container.Suspended;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.SecurityContext;

@Path(API_PUB)
@PermitAll
@Timed
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "calculator", description = "Operations on calcs")
public class CalculatorResource {

	private static final Duration MAX_EXECUTION_TIME = Duration.ofSeconds(30);

	private final CalculatorTypeService calculatorTypeService;
	private final ResultService resultService;
	private final CalcQueue calcQueue;

	private final ExecutorService executor;

	@Inject
	public CalculatorResource(CalculatorTypeService calculatorTypeService, ResultService resultService, CalcQueue calcQueue) {
		this.calculatorTypeService = calculatorTypeService;
		this.resultService = resultService;
		this.calcQueue = calcQueue;

		this.executor = Executors.newFixedThreadPool(5);
	}

	@Operation(summary = "calculate ", description = "calculate something by code")
	@RequestBody(description = "map that contains calc job parameters", content = @Content(schema = @Schema(type = "object"), additionalPropertiesSchema = @Schema(type = "object"), mediaType = MediaType.APPLICATION_JSON))
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the calculation job is done and ready", useReturnTypeSchema = true),
			@ApiResponse(responseCode = "404", description = "calculation flow not found ", content = @Content(schema = @Schema(implementation = ReportException.ErrorBody.class)))
	})
	@POST
	@Path("/{calcTypeCode}")
	public CreateCalculatorJobResponse executeCalc(
			@Parameter(description = "calc type CODE") @PathParam("calcTypeCode") String calcTypeCode,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(hidden = true) @Context SecurityContext security,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(in = ParameterIn.HEADER, schema = @Schema(implementation = String.class)) @HeaderParam("Accept-Language") @DefaultValue("en") Locale locale,
			@Valid CalculatorEngineInput inputPayload,
			@BeanParam CalculatorReq calculatorReq) {

		ReqContext reqContext = new ReqContext(user, locale.getLanguage());
		return doExecute(calcTypeCode, tenantId, security, reqContext, inputPayload, calculatorReq);
	}

	@Operation(summary = "calculate ", description = "calculate something by code and directly return the raw result")
	@RequestBody(description = "map that contains calc job parameters", content = @Content(schema = @Schema(type = "object"), additionalPropertiesSchema = @Schema(type = "object"), mediaType = MediaType.APPLICATION_JSON))
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Successfully, the calculation result", content = @Content(schema = @Schema(implementation = String.class))),
			@ApiResponse(responseCode = "404", description = "calculation flow not found ", content = @Content(schema = @Schema(implementation = ReportException.ErrorBody.class)))
	})
	@POST
	@Path("/raw/{calcTypeCode}")
	public void executeAndReturnCalc(
			@Parameter(description = "calc type CODE") @PathParam("calcTypeCode") String calcTypeCode,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(hidden = true) @Context SecurityContext security,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(in = ParameterIn.HEADER, schema = @Schema(implementation = String.class)) @HeaderParam("Accept-Language") @DefaultValue("en") Locale locale,
			@Valid CalculatorEngineInput inputPayload,
			@BeanParam CalculatorReq calculatorReq,
			@Parameter(hidden = true) @Suspended AsyncResponse response) {

		ReqContext reqContext = new ReqContext(user, locale.getLanguage());
		CreateCalculatorJobResponse jobResponse = doExecute(calcTypeCode, tenantId, security, reqContext, inputPayload, calculatorReq);
		executor.submit(() -> respondWithRawResult(reqContext, jobResponse.getUuid(), response));
	}

	private void respondWithRawResult(ReqContext reqContext, String uuid, AsyncResponse response) {
		LocalDateTime deadline = LocalDateTime.now().plus(MAX_EXECUTION_TIME);
		try {
			ResultEntity result;
			while (true) {
				Thread.sleep(100);
				result = resultService.getResult(reqContext, uuid);
				switch (result.getStatus()) {
				case READY:
					response.resume(Response.ok(result.getCalcResult()).build());
					break;
				case ERROR:
					throw new InternalServerErrorException(String.format("Calculation %s errored", uuid));
				default:
					if (LocalDateTime.now().isAfter(deadline)) {
						throw new InternalServerErrorException(String.format("Calculation %s is taking too much time", uuid));
					}
				}
			}
		} catch (InterruptedException e) {
			response.resume(e);
			Thread.currentThread().interrupt();
		} catch (Exception e) {
			response.resume(e);
		}
	}

	private CreateCalculatorJobResponse doExecute(String calcTypeCode, String tenantId, SecurityContext security, ReqContext reqContext,
			CalculatorEngineInput inputPayload, CalculatorReq calculatorReq) {

		validateCalculatorReq(calculatorReq, calcTypeCode);

		ResultEntity job = calculatorTypeService.insertCalcJob(calcTypeCode, calculatorReq, reqContext);

		CalcJob calcJob = CalcJob.builder()
				.setCalculatorReq(calculatorReq)
				.setJobUuid(job.getUuid())
				.setLocale(reqContext.getLang())
				.setTenantId(tenantId)
				.setWorkflowCode(calcTypeCode)
				.setInput(Optional.ofNullable(inputPayload).orElse(new CalculatorEngineInput()))
				.setUserName(reqContext.getUsername())
				.build();

		calcQueue.add(calcJob, System.currentTimeMillis());

		return CreateCalculatorJobResponse.builder()
				.setUuid(job.getUuid())
				.build();
	}

	private void validateCalculatorReq(CalculatorReq calculatorReq, String defaultDest) {
		calculatorReq.setDest(Optional.of(calculatorReq)
				.map(CalculatorReq::getDest)
				.filter(StringUtils::isNotBlank)
				.map(StringUtils::trim)
				.orElse(defaultDest));
	}
}
