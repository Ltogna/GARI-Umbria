package com.abacogroup.calculatorengine.core.exceptions;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public abstract class AbstractAppException extends WebApplicationException {

	private static final long serialVersionUID = 1178955577097541375L;

	private ExceptionErrorBody errorBody;

	protected AbstractAppException() {
	}

	AbstractAppException(ExceptionErrorBody body) {
		super(body.getMessage(),
				Response.status(Status.BAD_REQUEST)
						.entity(body)
						.build());
		this.errorBody = body;
	}

	public String getCode() {
		return getErrorBody().getErrorCode();
	}

	public interface ExceptionErrorBody {
		String getErrorCode();

		default String getMessage() {
			return "TODO";
		}
	}

}
