package com.abacogroup.calculatorengine.db.dao;

import com.abacogroup.calculatorengine.api.CalculatorJobStatus;
import com.abacogroup.calculatorengine.db.ntt.ResultEntity;
import com.abacogroup.jdbi.model.AuditEntity;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface ResultDAO extends Transactional<ResultDAO>, BasicDAO {

	@SqlUpdate(
			"insert into clc_results (uuid, calc_type_id, status, calc_result, calc_render_result, dest, json_configs, dt_insert, user_id_insert, dt_delete, user_id_delete) "
					+ "values (:uuid, :calcTypeId, :status, :calcResult, :calcRenderResult, :dest, :jsonConfigs, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	@GetGeneratedKeys("pkid")
	Long insert(@BindBean ResultEntity entity);

	@SqlUpdate("update clc_results "
			+ "set status = :status ,dt_insert = :dtInsert "
			+ "where uuid = :uuid and (§current_timestamp§ between dt_insert and dt_delete) ")
	void updateStatus(
			@Bind("uuid") String uuid,
			@Bind("status") CalculatorJobStatus status,
			@Bind("dtInsert") LocalDateTime dtInsert);

	@SqlUpdate("update clc_results "
			+ " set status = :status ,dt_insert = :dtInsert, calc_result = :calcResult, calc_render_result = :calcRenderResult "
			+ " where uuid = :uuid and (§current_timestamp§ between dt_insert and dt_delete) ")
	void updateStatus(@Bind("uuid") String uuid,
			@Bind("status") CalculatorJobStatus status,
			@Bind("calcResult") String calcResult,
			@Bind("calcRenderResult") String calcRenderResult,
			@Bind("dtInsert") LocalDateTime dtInsert);

	@SqlQuery(
			"select r.uuid, r.calc_type_id, r.status, r.calc_result, r.calc_render_result, r.dest, r.json_configs, r.dt_insert, r.user_id_insert, r.dt_delete, r.user_id_delete"
					+ " from clc_results r where r.uuid = :uuid")
	@RegisterBeanMapper(ResultEntity.class)
	Optional<ResultEntity> findByUUID(@Bind("uuid") String uuid);

	@SqlQuery("select j.uuid, j.report_id, j.status, j.file_store_id ,j.dt_insert ,j.bucket ,j.dest from clc_results j "
			+ " inner join pre_jasper_reports r on r.id = j.report_id "
			+ " where r.workflow_code = :workflowCode and r.tenant_id = :tenantId and j.uuid = :uuid")
	@RegisterBeanMapper(ResultEntity.class)
	Optional<ResultEntity> findByTenantAndWorkFlowCodeAndUUID(
			@Bind("tenantId") String tenantId,
			@Bind("workflowCode") String workflowCode,
			@Bind("uuid") String uuid);

	@SqlQuery(
			"select r.uuid, r.calc_type_id, r.status, r.calc_result, r.calc_render_result, r.dest, r.json_configs, r.dt_insert, r.user_id_insert, r.dt_delete, r.user_id_delete"
					+ " from clc_results r "
					+ " inner join clc_calc_type t on t.id = r.calc_type_id "
					+ " where  t.tenant_id = :tenantId and r.uuid = :uuid"
					+ " and (§current_timestamp§ between r.dt_insert and r.dt_delete) ")
	@RegisterBeanMapper(ResultEntity.class)
	Optional<ResultEntity> findByTenantAndUUID(
			@Bind("tenantId") String tenantId,
			@Bind("uuid") String uuid);

	@SqlQuery("select j.uuid, j.report_id, j.status, j.file_store_id , j.dt_insert , j.bucket , j.dest from clc_results j "
			+ " inner join pre_jasper_reports r on r.id = j.report_id "
			+ " where r.workflow_code = :workflowCode and r.tenant_id = :tenantId")
	@RegisterBeanMapper(ResultEntity.class)
	List<ResultEntity> findAllByTenantAndWorkFlowCode(
			@Bind("tenantId") String tenantId,
			@Bind("workflowCode") String workflowCode);

	@SqlUpdate("update clc_results set dt_delete =:dtDelete, user_id_delete=:userIdDelete where pkid = :pkid " +
			" and (§current_timestamp§ between dt_insert and dt_delete) ")
	void expireRow(@BindBean AuditEntity entity);

}
