package com.abacogroup.calculatorengine.core.service;

import com.abacogroup.calculatorengine.common.core.ReqContext;
import com.abacogroup.calculatorengine.db.ntt.ResultEntity;

public interface ResultService {

	ResultEntity getResult(ReqContext context, String uuid);

}
