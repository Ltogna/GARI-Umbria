package com.abacogroup.calculatorengine.core.service.impl;

import com.abacogroup.calculatorengine.api.CalculatorJobResponse;
import com.abacogroup.calculatorengine.core.service.CalculatorJobEventProducer;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Value;

@Value
public class CalculatorJobMessage {
	private final String tenant;
	private final CalculatorJobResponse message;
	private final CalculatorJobEventProducer.JobEventType eventType;

	@JsonCreator
	public CalculatorJobMessage(@JsonProperty("tenant") String tenant,
			@JsonProperty("message") CalculatorJobResponse message,
			@JsonProperty("eventType") CalculatorJobEventProducer.JobEventType eventType) {
		super();
		this.tenant = tenant;
		this.message = message;
		this.eventType = eventType;
	}

	public String getRoutingKey() {
		return eventType.getTopic(message.getDest());
	}
}
