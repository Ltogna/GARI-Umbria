package com.abacogroup.calculatorengine.db.dao;

import com.abacogroup.calculatorengine.db.ntt.WfConfigurationEntity;
import java.util.Optional;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface WfConfigurationDAO extends Transactional<WfConfigurationDAO>, BasicDAO {

	@SqlUpdate("insert into clc_wf_configs (wf_code,tenant_id, json_configs, dt_insert, user_id_insert, dt_delete, user_id_delete) "
			+ "values (:wfCode,:tenantId, :jsonConfigs, :dtInsert, :userIdInsert, :dtDelete, :userIdDelete)")
	@GetGeneratedKeys("pkid")
	Long insert(@BindBean WfConfigurationEntity entity);

	@SqlQuery("select pkid,tenant_id, wf_code, json_configs, dt_insert, user_id_insert, dt_delete, user_id_delete"
			+ " from clc_wf_configs "
			+ " where wf_code = :wfCode "
			+ " and tenant_id = :tenantId "
			+ " and (§current_timestamp§ between dt_insert and dt_delete) ")
	@RegisterBeanMapper(WfConfigurationEntity.class)
	Optional<WfConfigurationEntity> findByWfCodeAndTenant(
			@Bind("wfCode") String wfCode, @Bind("tenantId") String tenantId);

	@SqlQuery("select json_configs "
			+ " from clc_wf_configs "
			+ " where wf_code = :wfCode "
			+ " and tenant_id = :tenantId "
			+ " and (§current_timestamp§ between dt_insert and dt_delete) ")
	String getJsonConfig(@Bind("tenantId") String tenantId, @Bind("wfCode") String wfCode);

	@SqlUpdate("update clc_wf_configs set dt_delete =:dtDelete, user_id_delete=:userIdDelete where pkid = :pkid")
	void expireRow(@BindBean WfConfigurationEntity entity);

}
