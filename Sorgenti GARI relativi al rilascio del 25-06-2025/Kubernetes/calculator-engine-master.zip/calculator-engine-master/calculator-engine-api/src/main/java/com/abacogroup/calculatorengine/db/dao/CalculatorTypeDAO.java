package com.abacogroup.calculatorengine.db.dao;

import com.abacogroup.calculatorengine.db.ntt.CalculatorTypeEntity;
import com.abacogroup.jdbi.EnhancedSqlObject;
import java.util.List;
import java.util.Optional;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface CalculatorTypeDAO extends Transactional<CalculatorTypeDAO>, EnhancedSqlObject {

	@SqlUpdate("INSERT INTO clc_calc_type (tenant_id, workflow_code) "
			+ " values (:tenantId, :workflowCode)")
	@GetGeneratedKeys("id")
	Long insert(@BindBean CalculatorTypeEntity entity);

	@SqlQuery("SELECT id, tenant_id, workflow_code "
			+ "FROM clc_calc_type "
			+ " WHERE tenant_id = :tenantId "
			+ " AND workflow_code = :code ")
	@RegisterBeanMapper(CalculatorTypeEntity.class)
	Optional<CalculatorTypeEntity> findByTenantAndCode(
			@Bind("tenantId") String tenantId,
			@Bind("code") String code);

	@SqlQuery("SELECT id, tenant_id, workflow_code "
			+ "FROM clc_calc_type "
			+ " WHERE tenant_id = :tenantId ")
	@RegisterBeanMapper(CalculatorTypeEntity.class)
	List<CalculatorTypeEntity> findByTenant(@Bind("tenantId") String tenantId);
}
