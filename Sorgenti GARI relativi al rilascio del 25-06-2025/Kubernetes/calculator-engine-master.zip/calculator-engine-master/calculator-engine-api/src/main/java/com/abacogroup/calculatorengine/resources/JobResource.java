package com.abacogroup.calculatorengine.resources;

import static com.abacogroup.calculatorengine.resources.ResourceConstants.API_PUB;

import java.util.Locale;

import com.abacogroup.calculatorengine.api.CalculatorJobResponse;
import com.abacogroup.calculatorengine.core.exceptions.CalculatorJobException;
import com.abacogroup.calculatorengine.core.service.CalculatorTypeService;
import com.codahale.metrics.annotation.Timed;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.PermitAll;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.SecurityContext;

@Path(API_PUB)
@PermitAll
@Timed
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "calculator job", description = "Operations related to the calculator job")
public class JobResource {

	private final CalculatorTypeService calculatorTypeService;

	@Inject
	public JobResource(CalculatorTypeService calculatorTypeService) {
		this.calculatorTypeService = calculatorTypeService;
	}

	@Operation(summary = "get calc job status", description = " returns the current status of a calc job")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "successfully, the status of job is returned", useReturnTypeSchema = true),
			@ApiResponse(responseCode = "404", description = "invalid calc job uuid ", content = @Content(schema = @Schema(implementation = CalculatorJobException.ErrorBody.class)))
	})
	@GET
	@Path("/jobs/{uuid}")
	public CalculatorJobResponse getJobStatus(
			@Parameter(in = ParameterIn.HEADER, schema = @Schema(implementation = String.class)) @HeaderParam("Accept-Language") @DefaultValue("en") Locale locale,
			@Parameter(description = "tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "calc job ID") @PathParam("uuid") String uuid,
			@Parameter(hidden = true) @Context SecurityContext security) {
		return calculatorTypeService.getJobStatus(tenantId, uuid);
	}

}
