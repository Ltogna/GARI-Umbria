package com.abacogroup.calculatorengine.api;

public enum CalculatorJobStatus {

	ACKNOWLEDGE,
	PROGRESS,
	ERROR,
	READY
}
