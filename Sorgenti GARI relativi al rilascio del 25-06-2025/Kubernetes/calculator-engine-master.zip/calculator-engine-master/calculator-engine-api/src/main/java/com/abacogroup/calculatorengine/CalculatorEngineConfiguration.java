package com.abacogroup.calculatorengine;

import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.Configuration;
import io.dropwizard.db.DataSourceFactory;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.util.Optional;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.StringUtils;

@Data
@EqualsAndHashCode(callSuper = true)
public class CalculatorEngineConfiguration extends Configuration {

	private boolean cors = true;

	@Valid
	@NotNull
	private DataSourceFactory database;

	private RabbitmqConfig rabbitmqConfig;

	@Valid
	@NotNull
	private JerseyClientConfiguration jerseyClient = new JerseyClientConfiguration();

	@Valid
	private BundleConfig bundleConfig = new BundleConfig();

	@Valid
	private Sso2Config sso2Config;

	@Valid
	private FileStoreConfig fileStoreConfig;

	private CalculatorConfig calculatorConfig = new CalculatorConfig();

	@Data
	public static class RabbitmqConfig {

		private String host;
		private String user;
		private String password;
		private String virtualhost;
		private Integer port;
	}

	@Data
	public static class CalculatorConfig {

		private String initBaseTempDir;
		private String externalPropertiesDir;
		private boolean keepTempFile = false;
		private long queueTimeoutMs = 1000L * 60 * (6 * 10 * 10); // increase to 10 hours
		private int queueThreads = 10;
		private String workFlowEnvironmentId;

		public String getInitBaseTempDir() {
			return Optional.ofNullable(initBaseTempDir)
					.map(workDir -> StringUtils.removeEnd(workDir, "/"))
					.orElse(System.getProperty("java.io.tmpdir"));
		}
	}

	@Data
	public static class BundleConfig {

		private String configLocation;

		private String initBaseTempDir;

	}

	@Data
	public static class Sso2Config {
		private String url;
		private String tasksAuthPhrase;
	}

	@Data
	public static class FileStoreConfig {
		private String url;
	}

}
