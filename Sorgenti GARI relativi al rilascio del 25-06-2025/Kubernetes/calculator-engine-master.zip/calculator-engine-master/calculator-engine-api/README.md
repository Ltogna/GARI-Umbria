# calculator-engine

[TOC]

---

il modulo API fornisce (come print-engine) una infrastruttura per l'esecuzione
di workflow che eseguono calcoli.

L'output di ogni WF deve essere formato da 2 json

Uno interno al WF, con tutti i calcoli "esplosi" ...
Uno (strutturato) da esporre all'esterno, che dovrà poi essere renderizzato.

----
Come PE, un wf accetta una Map arbitraria di parametri.

Ogni esecuzione è persistita, sia nel risultato che nelle configurazioni utilizzate

i wf, come per print-engine, si basano esclusivamente su rest api e su H2.

### 2. bundles

The application must be connected to a RabbitMQ instance.

The bundles infrastructure will automatically set up to allow automatic configuration.

The application module id is `calculator-engine` and the supported changeset domains are:

```
📂 calculator-engine
┗━📂 <client-id>-<nnnnn>
  ┣━📂 calculator-config
  ┃ ┗━📜 <any file>.json
  ┃ ┗━📜 <any file>.merge.json
  ┗━📂 calculator-type
    ┗━📜 <any file>.jar
```

* calculator-config : represents a configuration object for a workflow (by code).
* calculator-type :  represents a bundle for a specific calculation type . ( next section :
  #3-how-to-create-a-monitoring-type-bundle)

The structure for the calculator-config .json file and .merge.json is as follows:

``` json
{
  "wfCode": "MY_WF_CODE",
  "config": {
    "any_custom_prop_1": 0.01
    "any_custom_prop_2": "foo"
  }
}

```

The difference between .json and .merge.json is:

- a .json file is stored in the database as-is
- a .merge.json file is merged with the config currently set in the database before to be stored

### 2.3 Rabbit Topic

To publish **report completed** events, we are using an embedded queue for messaging.
So, when the calc job is done the `CalculatorJobEventProducer` will send a message through an exchange
named `clc-engine-exchange`  to the corresponding topic of this print job in Rabbit MQ
. </br>

The topic name is composed of : **calculator-engine-job.[destination].[job-status]**

- **destination** is passed as query param (else it uses the default value)
- **job status** : could be [ error / ready ] relative to the response of the print job.
