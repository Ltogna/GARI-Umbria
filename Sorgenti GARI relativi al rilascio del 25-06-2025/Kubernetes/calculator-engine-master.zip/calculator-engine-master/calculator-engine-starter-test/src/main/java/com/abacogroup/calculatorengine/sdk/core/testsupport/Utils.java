package com.abacogroup.calculatorengine.sdk.core.testsupport;

import com.abacogroup.calculatorengine.sdk.CalculatorEngineUtils;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;

public class Utils {

    public static File createSourceDir(File workDir, String tenantId, String wfCode) throws IOException {
        FileUtils.deleteQuietly(workDir);
        File reportDir = CalculatorEngineUtils.getSourceDir(workDir.getAbsolutePath(), tenantId, wfCode, "xxxxxxxxxxxxx_hash_xxxxxxxxxxxxx").toFile();
        // new File("src/main/resources")
        FileUtils.copyDirectory(new File("target/classes").getAbsoluteFile(), reportDir);

        return reportDir;
    }
}
