package com.abacogroup.calculatorengine.sdk.core.testsupport;

import com.abacogroup.workflow.sdk.auth.AuthContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.auth.AuthenticationException;
import jakarta.ws.rs.client.Client;
import java.io.File;
import java.util.Map;

public interface CalculatorWorkflowTestStepA {
    CalculatorWorkflowTestStepA withAuthContext(AuthContext authContext);

	CalculatorWorkflowTestStepA withRealAuthContext(String sso2Url, String tasksAuthPhrase, String tenant, String username)
			throws AuthenticationException;

	CalculatorWorkflowTestStepA withScope(String scope);

    @Deprecated(forRemoval = true)
    default CalculatorWorkflowTestStepA withProfile(String profile) {
        return withEnv(profile);
    }

    CalculatorWorkflowTestStepA withEnv(String env);

    CalculatorWorkflowTestStepA withClient(Client client);

    CalculatorWorkflowTestStepA withObjectMapper(ObjectMapper objectMapper);

    CalculatorWorkflowTestStepA withWorkDir(File workDir);

    CalculatorWorkflowTestStepA withDbConnection(String url, String user, String password);

	CalculatorWorkflowTestStepA withConfigJson(String jsonRaw);

	CalculatorWorkflowTestStepA putInputParam(String key, Object value);

    CalculatorWorkflowTestStepA putAllInputParams(Map<String, Object> inputParams);

    CalculatorWorkflowTestStepB setUp();
}
