package com.abacogroup.calculatorengine.sdk.core.testsupport;

import com.abacogroup.workflow.server.model.CreateProcessParams;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import com.abacogroup.workflow.server.services.testsupport.ProcessServiceTestSupport;

public interface CalculatorWorkflowTestStepB {
    CreateProcessParams getProcessParams();

    ProcessServiceTestSupport getProcessService();

    ProcessTransitionResult execute();
}
