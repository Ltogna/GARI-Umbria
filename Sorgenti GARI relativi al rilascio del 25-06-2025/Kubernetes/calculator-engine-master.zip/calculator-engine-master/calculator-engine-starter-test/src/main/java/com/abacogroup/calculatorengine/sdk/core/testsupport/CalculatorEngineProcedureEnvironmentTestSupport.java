package com.abacogroup.calculatorengine.sdk.core.testsupport;

import com.abacogroup.calculatorengine.sdk.ProcEnvConstants;
import com.abacogroup.workflow.sdk.beans.testsupport.ProcedureEnvironmentTestSupport;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.client.Client;

import java.util.HashMap;
import java.util.Map;

public class CalculatorEngineProcedureEnvironmentTestSupport extends ProcedureEnvironmentTestSupport {

    @Deprecated(forRemoval = true)
    public CalculatorEngineProcedureEnvironmentTestSupport() {
        this(null, new ObjectMapper(),
                "target/test", "target/test/sources", null);
    }

    public CalculatorEngineProcedureEnvironmentTestSupport(String workDir, String sourceDir) {
        this(null, new ObjectMapper(),
                workDir, sourceDir, null);
    }

    public CalculatorEngineProcedureEnvironmentTestSupport(Client client,
                                                           ObjectMapper objectMapper, String workDir, String sourceDir) {
        this(client, objectMapper, workDir, sourceDir, null);
    }

    public CalculatorEngineProcedureEnvironmentTestSupport(Client client,
                                                           ObjectMapper objectMapper, String workDir, String sourceDir, String envId) {
        super(
                new HashMap<>(),
                client,
                buildProperties(objectMapper, workDir, sourceDir), envId);
    }

    //	private static Map<String, Jdbi> buildJdbiMap(Jdbi jdbiHelper, Jdbi jdbi) {
    //		Map<String, Jdbi> props = new HashMap<>();
    //
    //		return props;
    //
    //	}

    private static Map<String, Object> buildProperties(ObjectMapper objectMapper, String workDir, String sourceDir) {
        Map<String, Object> props = new HashMap<>();

        props.put(ProcEnvConstants.PROPERTY_WORK_DIR, workDir);
        props.put(ProcEnvConstants.PROPERTY_SOURCE_DIR, sourceDir);

        props.put(ProcEnvConstants.PROPERTY_OBJECT_MAPPER, objectMapper);

        return props;
    }
}
