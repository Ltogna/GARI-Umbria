package com.abacogroup.calculatorengine.sdk.core.testsupport;

import static com.abacogroup.calculatorengine.sdk.CalculatorEngineUtils.CONFIG_FILE_NAME;

import com.abacogroup.calculatorengine.sdk.model.AuthContextImpl;
import com.abacogroup.calculatorengine.sdk.model.CalculatorEngineInput;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.workflow.sdk.auth.AuthContext;
import com.abacogroup.workflow.sdk.beans.testsupport.AuthContextTestSupport;
import com.abacogroup.workflow.server.model.CreateProcessParams;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import com.abacogroup.workflow.server.services.WorkflowService;
import com.abacogroup.workflow.server.services.testsupport.ProcessServiceTestSupport;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.dropwizard.auth.AuthenticationException;
import jakarta.ws.rs.client.Client;
import liquibase.Liquibase;
import liquibase.database.jvm.JdbcConnection;
import liquibase.exception.LiquibaseException;
import liquibase.resource.ClassLoaderResourceAccessor;
import liquibase.resource.DirectoryResourceAccessor;
import lombok.SneakyThrows;
import org.apache.commons.io.FileUtils;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.sqlobject.SqlObjectPlugin;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class CalculatorWorkflowTestSupport implements CalculatorWorkflowTestStepA, CalculatorWorkflowTestStepB {

    private static final String DB_MIGRATIONS_PATH = "migrations-workflow.xml";
    private final String wfCode;
    private final String tenantId;
    private final Map<String, Object> inputParams;
    private ProcessServiceTestSupport processService;
    private AuthContext authContext;
    private String scope;
    private File workDir;
    private File sourceDir;
    private String connectionUrl;
    private String connectionUsr;
    private String connectionPsw;
    private Jdbi jdbi;
    private Client client;
    private ObjectMapper objectMapper;
    private CreateProcessParams params;
    private String envId;
    private String configJsonRaw;

    @SneakyThrows()
    private CalculatorWorkflowTestSupport(String wfCode, String tenantId) {
        this.wfCode = wfCode;
        this.tenantId = tenantId;

        this.authContext = new AuthContextTestSupport();
        this.scope = null;

        this.workDir = new File("target/test").getAbsoluteFile();
        this.sourceDir = null;

        this.connectionUrl = "jdbc:postgresql://localhost:5432/test";
        this.connectionUsr = "test";
        this.connectionPsw = "password";

        this.jdbi = null;
        this.client = null;
        this.objectMapper = new ObjectMapper();

        this.inputParams = new HashMap<>();
    }

    public static CalculatorWorkflowTestStepA buildFlow(String wfCode, String tenantId) {
        return new CalculatorWorkflowTestSupport(wfCode, tenantId);
    }

    @Override
    public CalculatorWorkflowTestStepA withAuthContext(AuthContext authContext) {
        this.authContext = authContext;
        return this;
    }

    @Override
    public CalculatorWorkflowTestStepA withRealAuthContext(String sso2Url, String tasksAuthPhrase, String tenant, String username)
            throws AuthenticationException {

        if (null == client) {
            throw new IllegalStateException("define client first! `CalculatorWorkflowTestSupport.withClient(Client client)`");
        }

        Sso2Client sso2Client = new Sso2Client(tasksAuthPhrase, client.target(sso2Url));
        var securityContext = sso2Client.createSecurityContextFromUserName(tenant, username);
        this.authContext = new AuthContextImpl(securityContext, "en");

        return this;
    }

    @Override
    public CalculatorWorkflowTestStepA withScope(String scope) {
        this.scope = scope;
        return this;
    }

    @Override
    public CalculatorWorkflowTestStepA withEnv(String envId) {
        this.envId = envId;
        return this;
    }

    @Override
    public CalculatorWorkflowTestStepA withClient(Client client) {
        this.client = client;
        return this;
    }

    @Override
    public CalculatorWorkflowTestStepA withObjectMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
        return this;
    }

    @Override
    public CalculatorWorkflowTestStepA withWorkDir(File workDir) {
        this.workDir = workDir;
        return this;
    }

    @Override
    public CalculatorWorkflowTestStepA withDbConnection(String url, String user, String password) {
        this.connectionUrl = url;
        this.connectionUsr = user;
        this.connectionPsw = password;
        return this;
    }

    @Override
    public CalculatorWorkflowTestStepA withConfigJson(String jsonRaw) {
        this.configJsonRaw = jsonRaw;
        return this;
    }

    @Override
    public CalculatorWorkflowTestStepA putInputParam(String key, Object value) {
        this.inputParams.put(key, value);
        return this;
    }

    @Override
    public CalculatorWorkflowTestStepA putAllInputParams(Map<String, Object> inputParams) {
        this.inputParams.putAll(inputParams);
        return this;
    }

    @SneakyThrows
    @Override
    public CalculatorWorkflowTestStepB setUp() {
        migrateWorkflow(getConnection());
        Connection connection = getConnection();
        jdbi = Jdbi.create(connection);
        jdbi.installPlugin(new PgJdbiPlugin());
        jdbi.installPlugin(new SqlObjectPlugin());

        sourceDir = Utils.createSourceDir(workDir, tenantId, wfCode);

        WorkflowService workflowService = new WorkflowService(jdbi);
        workflowService.addOrUpdateWorkflow(tenantId, Path.of(sourceDir.getAbsolutePath(), "abaco-workflow.json").toFile());

        FileUtils.writeStringToFile(new File(sourceDir, CONFIG_FILE_NAME), configJsonRaw, StandardCharsets.UTF_8);

        processService = new ProcessServiceTestSupport(jdbi, processData -> new CalculatorEngineProcedureEnvironmentTestSupport(
                client, objectMapper,
                workDir.getAbsolutePath(),
                sourceDir.getAbsolutePath(),
                envId));

        CalculatorEngineInput input = CalculatorEngineInput.builder()
                .setParams(inputParams)
                .build();

        Map<String, Object> globalVars = new HashMap<>();
        globalVars.put(CalculatorEngineInput.PARAM_NAME, input);

        params = CreateProcessParams.builder()
                .scope(scope)
                .authContext(authContext)
                .globalVars(globalVars)
                .tenantId(tenantId)
                .workflowCode(wfCode)
                .returnGlobalVars(true)
                .build();

        return this;
    }

    @Override
    public CreateProcessParams getProcessParams() {
        return params;
    }

    @Override
    public ProcessServiceTestSupport getProcessService() {
        return processService;
    }

    @SneakyThrows
    @Override
    public ProcessTransitionResult execute() {
        return processService.createProcess(params);
    }

    private void migrateWorkflow(Connection connection) throws LiquibaseException, SQLException {
        try (Liquibase migrator = new Liquibase(DB_MIGRATIONS_PATH, new ClassLoaderResourceAccessor(), new JdbcConnection(connection))) {
            migrator.update("");
        }
    }

    private void migrateHelper(Connection connection) throws Exception {
        try (var accessor = new DirectoryResourceAccessor(new File("src/main/resources").getAbsoluteFile())) {
            File changelogFile = new File("src/main/resources/migrations.xml");
            if (changelogFile.exists()) {
                try (Liquibase migrator = new Liquibase(changelogFile.getName(), accessor, new JdbcConnection(connection))) {
                    migrator.update("");
                }
            }
        } catch (Exception e) {
            throw e;
        }
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(connectionUrl, connectionUsr, connectionPsw);
    }

}
