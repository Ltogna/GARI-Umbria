# TAG A NEW CALCULATOR-ENGINE VERSION

mvn versions:set -DnewVersion=X.X.X

mvn versions:commit