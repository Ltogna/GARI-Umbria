# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- Added bufferSize parameter to updatePlot API to apply a buffer to the geometry to update
- Added new getPlotBuffer API to return the buffer value calculated on distance between rows of the plot declarations





## [5.1.8] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.1.7...v5.1.6) - 2025-06-05

### Added

- Added bufferSize parameter to updatePlot API to apply a buffer to the geometry to update
- Added new getPlotBuffer API to return the buffer value calculated on distance between rows of the plot declarations

### Fixed

- Fixed LATEST_OTHER_PLANS_VERSION_EMPTY_DOMAIN_PLOTS layer not working when current crop plan has no versions ([#170305](https://abacogroup.easyredmine.com/issues/170305))

## [5.1.7] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.1.7...v5.1.6) - 2025-06-05

### Fixed

- Fixed fvg validator plugin to consider every plot of the same ISOLA (even if is not shared) for calculating anomalies ([#178867](https://abacogroup.easyredmine.com/issues/178867))

## [5.1.6] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.1.6...v5.1.5) - 2025-06-03

### Fixed

- Fixed getPlanHasDeclarationsForLandUse public API do not consider expired plots ([#174809](https://abacogroup.easyredmine.com/issues/174809))

## [5.1.5] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.1.5...v5.1.4) - 2025-06-03

### Fixed

- Fixed fvg validator plugin to consider the area of every plot of the same ISOLA in calculateAnomalies ([#176701](https://abacogroup.easyredmine.com/issues/176701))

## [5.1.4] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.1.4...v5.1.3) - 2025-05-28

### Fixed

- Fixed copy campaign raising an exception in some cases with 0 area polygons (update geometry-editor to v2.5.2) ([#175411](https://abacogroup.easyredmine.com/issues/175411))

## [5.1.3] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.1.3...v5.1.2) - 2025-05-27

### Changed

- Changed DECLARATIONS_2024 layer removing filter on party on avepa2025 layers plugin ([#172860](https://abacogroup.easyredmine.com/issues/172860))

## [5.1.2] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.1.2...v5.1.1) - 2025-05-27

### Changed

- Changed how data are managed in cache db tables to improve performances and create indexes on tables

### Fixed

- Fixed cuttableLayers adding NPR and DECLARATIONS_2024 on avepa2025 layers plugin ([#177702](https://abacogroup.easyredmine.com/issues/177702))


## [5.1.1] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.1.1...v5.1.0) - 2025-05-21

### Fixed

- Fixed domain parcels touchingGeometry used by getSnapGeometries on avepa2025 domain plugin ([#174667](https://abacogroup.easyredmine.com/issues/174667))

## [5.1.0] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.1.0...v5.0.10) - 2025-05-20

### Changed

- **BREAKING CHANGE**: reworked cache decodes update using lock manager to avoid locks on db (**VALKEY MUST BE INSTALLED ON CLUSTER**) ([#176045](https://abacogroup.easyredmine.com/issues/176045))

## [5.0.10] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.0.10...v5.0.9) - 2025-05-16

### Fixed

- Fixed plots not synched correcly when parcels were removed before sync start date on avepa2025 sync plugin ([#173863](https://abacogroup.easyredmine.com/issues/173863))

## [5.0.9] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.0.9...v5.0.8) - 2025-05-16

### Added

- Added snap element types filter on getSnapGeometries API ([#174667](https://abacogroup.easyredmine.com/issues/174667))

### Fixed

- Fixed check on blocking anomalies do not consider object_code validity dates on createVersion API ([#176011](https://abacogroup.easyredmine.com/issues/176011))

## [5.0.8] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.0.8...v5.0.7) - 2025-05-14

### Changed

- Changed getSnapGeometries API evaluating DISABLE_SNAP_GEOMETRIES config parameter only on avepa2025 domain plugin

## [5.0.7] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.0.7...v5.0.6) - 2025-05-13

### Added

- Added new getCuttableLayers, cutPlotsByLayerPreview and cutPlotsByLayer APIs to avoid usage of snappable geometries on cut on layers behaviour

### Removed

- Removed from getSnapGeometries API data about cut on layers operation to disambiguate snappable geometries from cut on layers
- Removed some snappable layers to reduce memory usage by the client on avepa2025 domain plugin ([#174667](https://abacogroup.easyredmine.com/issues/174667))

## [5.0.6] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.0.6...v5.0.5) - 2025-05-12

### Fixed

- Fixed getAllPlots public API not returning additional fields data for declarations if the dt_insert of the plan is greater than the dt_insert of the declarations ([#175083](https://abacogroup.easyredmine.com/issues/175083))

## [5.0.5] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.0.5...v5.0.4) - 2025-05-09

### Fixed 

- Fixed exception raised by massive update APIs while updating more than 1000 plots simultaneously ([#174960](https://abacogroup.easyredmine.com/issues/174960))

## [5.0.4] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.0.4...v5.0.3) - 2025-05-09

### Added

- Added new DISABLE_PLOT_DATA_SPATIAL_INDEX config parameter to allow avoiding the use of spatial index on some crpl_plot_data queries ([#174497](https://abacogroup.easyredmine.com/issues/174497))

### Changed

- Updated abaco-jdbi to v2.19.2 (added support for isBeforeOrEqual and isAfterOrEqual on AbsoluteDate)
- Changed layers RPPG2023 and SHP_COMUNI_CONTERMINI to not snappable on avepa2025 layers plugin ([#174946](https://abacogroup.easyredmine.com/issues/174946))

### Fixed 

- Fixed exception raised by get versions APIs adding logger and handling exceptions in getCropPlanInfo on avepa crop plan plugin ([#173736](https://abacogroup.easyredmine.com/issues/173736))
- Fixed exception raised by massive update APIs while updating more than 1000 plots simultaneously ([#174960](https://abacogroup.easyredmine.com/issues/174960))

## [5.0.3] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.0.3...v5.0.2) - 2025-05-07

### Fixed

- Fixed copy campaign raising an exception when a land use code is not found ([#173736](https://abacogroup.easyredmine.com/issues/173736))
- Fixed AbsoluteDate not comparable updating abaco-jdbi to v2.19.1

## [5.0.2] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.0.2...v5.0.1) - 2025-05-07

### Fixed

- Fixed DECLARATIONS_2024 layer queries on avepa2025 domain plugin ([#173910](https://abacogroup.easyredmine.com/issues/173910))

## [5.0.1] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.0.1...v5.0.0) - 2025-05-07

### Added

- Added index on crpl_sync db table

### Changed

- Changed delete plots APIs from @DELETE to @POST to support payload on all environments

## [5.0.0] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v5.0.0...v4.12.32) - 2025-05-06

### Changed

- Updated java version from 11 to 17
- Updated dropwizard to v4.0.11
- Changed AbsoluteDate import from 'com.abacogroup.cropplan.sdk.model.AbsoluteDate' to 'import com.abacogroup.jdbi.datatype.AbsoluteDate'

### Fixed

- Fixed sonar agea issues

## [4.12.32] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.32...v4.12.31) - 2025-05-02

### Fixed

- Fixed BaseCropPlanService.fillChangedPlot causing an exception if getPreviousVersionChangedPlotsByDescription do not find plots ([#172129](https://abacogroup.easyredmine.com/issues/172129))

## [4.12.31] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.31...v4.12.30) - 2025-04-29

### Fixed

- Fixed copy campaign procedure ignoring land use editability while inserting plots

## [4.12.30] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.30...v4.12.29) - 2025-04-29

### Changed

- Changed ValidatorPlugin for fvg to get PLOT_WITH_UNDECLARED_AREA anomaly to every landCoverCode (and not only 666 and 651)

## [4.12.29] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.29...v4.12.28) - 2025-04-25

### Fixed

- Fixed copy campaign can cause a nullpointer exception with preserveSourceDeclDates = true 

## [4.12.28] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.28...v4.12.27) - 2025-04-24

### Fixed

- Fixed support to declPointInTimeTo payload parameter in copy campaign API to specify a different declarations end date

## [4.12.27] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.27...v4.12.26) - 2025-04-24

### Added

- Added support to declPointInTimeTo payload parameter in copy campaign API to specify a different declarations end date

## [4.12.26] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.26...v4.12.25) - 2025-04-24

### Fixed

- Fixed get land uses API do not return permanent crop forms configured on land use code


## [4.12.25] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.25...v4.12.24) - 2025-04-23

### Changed

- Changed copy campaign API copying all the declarations with preserveSourceDeclDates = true ([#172913](https://abacogroup.easyredmine.com/issues/172913))

### Fixed

- Fixed copy campaign API evaluating plot full range from and to dates to verify its existence ([#172913](https://abacogroup.easyredmine.com/issues/172913))

## [4.12.24] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.24...v4.12.23) - 2025-04-23

### Added

- Added support to copy campaign API on malta env for tmp_scp_2025_rm172913 businesses and parcels ([#172913](https://abacogroup.easyredmine.com/issues/172913))

## [4.12.23] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.23...v4.12.22) - 2025-04-17

### Fixed

- Fixed ValidatorCropPlanDAO supporting absolute dates ([#172190](https://abacogroup.easyredmine.com/issues/172190))

## [4.12.22] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.22...v4.12.21) - 2025-04-17

### Changed

- Changed copy campaign API adding preserveSourceDeclDates payload parameter ([#171999](https://abacogroup.easyredmine.com/issues/171999))

### Fixed

- Fixed ValidatorCropPlanDAO supporting absolute dates ([#172190](https://abacogroup.easyredmine.com/issues/172190))

## [4.12.21] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.21...v4.12.20) - 2025-04-16

### Changed 

- Changed ValidatorAnomaliesResult to have anomalies as an empty ArrayList by default ([#171310](https://abacogroup.easyredmine.com/issues/171310))

## [4.12.20] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.20...v4.12.19) - 2025-04-14

### Changed

- Changed copy campaign process adding log info
- Changed massive update APIs using now sync queue (SyncType = MASSIVE_FIELDS_UPDATE) ([#170677](https://abacogroup.easyredmine.com/issues/170677))

### Fixed

- Fixed get common permanent crop form API ([#171355](https://abacogroup.easyredmine.com/issues/171355))
- Fixed getSnapGeometries to exclude null geoms (invalid) in sitisuolo on avepa2025 domain plugin ([#171463](https://abacogroup.easyredmine.com/issues/171463))

## [4.12.19] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.19...v4.12.18) - 2025-04-10

### Added

- Added new public getDeclarationsByDomainZone API to get declarations by domain zone code ([#171113](https://abacogroup.easyredmine.com/issues/171113))
- Added support to additional declaration fields nullability by land use code filter ([#169315](https://abacogroup.easyredmine.com/issues/169315))
- Added support to day from and day to for permanent crop forms fields ([#169315](https://abacogroup.easyredmine.com/issues/169315))

### Changed

- Changed edit/insert plots APIs to receive toPointInTime date to set plot's end date ([#171324](https://abacogroup.easyredmine.com/issues/171324))

### Fixed

- Fixed max resolution for NPR_PCG_2025 and SITISUOLO layers on avepa2025 layers plugin
- Fixed copy campaign assigning to date < from date for declarations in some cases ([#171489](https://abacogroup.easyredmine.com/issues/171489))

## [4.12.18] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.18...v4.12.17) - 2025-04-09

### Changed

- Restored checkBusinessLocked check in getCropPlanTypeAccessLevel on avepa2025 auth plugin ([#171261](https://abacogroup.easyredmine.com/issues/171261))

## [4.12.17] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.17...v4.12.16) - 2025-04-08

### Fixed

- Fixed edit operations do not generating zero area results (updated geometry-editor to v2.5.1) ([#170434](https://abacogroup.easyredmine.com/issues/170434))

## [4.12.16] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.16...v4.12.15) - 2025-04-07

### Fixed

- Fixed copy campaign raising an exception while intersecting geoms in some cases ([#170918](https://abacogroup.easyredmine.com/issues/170918))

## [4.12.15] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.15...v4.12.14) - 2025-04-03

### Fixed

- Fixed layer_conferme layers on avepa2025 plugins ([#170679](https://abacogroup.easyredmine.com/issues/170679))

## [4.12.14] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.14...v4.12.13) - 2025-04-03

### Fixed

- Fixed layer_conferme layers on avepa2025 plugins ([#170679](https://abacogroup.easyredmine.com/issues/170679))

## [4.12.13] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.13...v4.12.12) - 2025-04-03

### Added

- Added new layer_conferme layers on avepa2025 plugins ([#170679](https://abacogroup.easyredmine.com/issues/170679))

## [4.12.12] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.12...v4.12.11) - 2025-04-03

### Fixed

- Fixed sync do not consider changed soil parcels in some cases on malta sync plugin ([#168755](https://abacogroup.easyredmine.com/issues/168755))

## [4.12.11] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.11...v4.12.10) - 2025-04-03

### Changed

- Changed anomaly PLOT_WITH_UNDECLARED_AREA restored to blocking on fvg validator plugin ([#170482](https://abacogroup.easyredmine.com/issues/170482))

### Fixed

- Fixed SITISUOLO layer on avepa2025 layers plugin ([#170324](https://abacogroup.easyredmine.com/issues/170324))

## [4.12.10] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.10...v4.12.9) - 2025-04-03

### Added

- Added new SITISUOLO layer on avepa2025 layers plugin ([#170324](https://abacogroup.easyredmine.com/issues/170324))

## [4.12.9] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.9...v4.12.8) - 2025-04-02

### Fixed

- Fixed copyCampaign API copying plots from other farmers only if destination reference date is at the campaign reference date

## [4.12.8] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.8...v4.12.7) - 2025-04-01

### Changed

- Changed copyCampaign API copying plots from other farmers improving performances

### Fixed

- Fixed copyCampaign API copying plots from other farmers only if source reference date is the open fixed date

## [4.12.7] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.7...v4.12.6) - 2025-04-01

### Fixed

- Fixed anomalies not be recalculated after copy campaign ([#170243](https://abacogroup.easyredmine.com/issues/170243))

## [4.12.6] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.6...v4.12.5) - 2025-04-01

### Changed

- Changed getSnapGeometries clipping NPR and SHP_CORPIIDRICI_2022 geometries if necessary on domain avepa2025 plugin 

### Fixed

- Fixed anomalies codes and labels ("isola" instead of "NPR/isola") on avepa2025 validator plugin ([#170257](https://abacogroup.easyredmine.com/issues/170257))

## [4.12.5] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.5...v4.12.4) - 2025-03-31

### Changed

- Changed copyCampaign API adding flCopyFromOtherBusinesses in CopyCampaignPayload to copy or not plots from other farmers ([#170038](https://abacogroup.easyredmine.com/issues/170038))

## [4.12.4] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.4...v4.12.3) - 2025-03-29

### Fixed

- Fixed copyCampaign API to copy also plots from other farmers if the farmer didn't have them in the source campaign ([#164436](https://abacogroup.easyredmine.com/issues/164436))

## [4.12.3] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.3...v4.12.2) - 2025-03-27

### Changed

- Changed copyCampaign API to copy also plots from other farmers if the farmer didn't have them in the source campaign ([#164436](https://abacogroup.easyredmine.com/issues/164436))

### Fixed

- Fixed sync can be performed also if it is queued more than 1 day ago and if exist a newer sync

## [4.12.2] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.2...v4.12.1) - 2025-03-24

### Fixed

- Fixed "SIGRIAN - DISTRETTI IRRIGUI VENETO PER POA" layer catalog to calculate related anomalies on avepa layers plugin ([#166859](https://abacogroup.easyredmine.com/issues/166859))

## [4.12.1] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.1...v4.12.0) - 2025-03-24

### Fixed

- Fixed getSnapGeometries raising an exception on domains with many plots on avepa2025 domain plugin

## [4.12.0] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.12.0...v4.11.2) - 2025-03-24

### Added

- Added new "SIGRIAN - DISTRETTI IRRIGUI VENETO PER POA" layer catalog on avepa layers plugin ([#166859](https://abacogroup.easyredmine.com/issues/166859))
 
### Fixed

- Fixed plot edit operations do not generates 0 area results (updated geometry-editor to v2.5.0) ([#168145](https://abacogroup.easyredmine.com/issues/168145))

## [4.11.2] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.11.2...v4.11.1) - 2025-03-17

### Fixed

- Fixed createVersion with no reference date specified
- Fixed getVersionsMessagesExt on avepa crop plan plugin ([#168012](https://abacogroup.easyredmine.com/issues/168012))

## [4.11.1] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.11.1...v4.11.0) - 2025-03-14

### Added

- Added new SHARED_PARCEL_OVERFLOW_DECL_AREA anomaly to not blocking on fvg validator plugin ([#167953](https://abacogroup.easyredmine.com/issues/167953))

### Changed

- Changed infoGis for SHP_CORPIIDRICI_2022 layer on avepa and avepa2025 layers plugin ([#167884](https://abacogroup.easyredmine.com/issues/167884))
- Changed sync start dato to 20241101 on avepa2025 sync plugin
- Changed SHARED_PARCEL_INVALID_PLOT_DECL_AREA anomaly to not blocking on fvg validator plugin ([#167953](https://abacogroup.easyredmine.com/issues/167953))

## [4.11.0] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.11.0...v4.10.5) - 2025-03-13

### Added

- Added new copyCampaign and getSourceLandUseCodesForCopyCampaign APIs ([#164434](https://abacogroup.easyredmine.com/issues/164434))
- Added anomalies on getPlotWithDeclarationsAndRotation API ([#167438](https://abacogroup.easyredmine.com/issues/167438))
- Added new DISABLE_CHECK_ON_MANDATORY_DECL_FIELDS config parameter to allow saving declarations without mandatory fields ([#167438](https://abacogroup.easyredmine.com/issues/167438))

## [4.10.5] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.10.5...v4.10.4) - 2025-03-06

### Added

- Added new messages sent on rabbit when a crop plan is published succesfully ([#166759](https://abacogroup.easyredmine.com/issues/166759))

## [4.10.4] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.10.4...v4.10.3) - 2025-03-04

### Changed

- Changed getAllVersions private API adding the new ignoreCropPlanId query parameter to return all the businessId crop plans versions (also versions of other crop plan types) ([#164434](https://abacogroup.easyredmine.com/issues/164434))

### Fixed

- Fixed infoGis and tooltipData for "Dichiarazioni 2024" layer on avepa2025 layers plugin

## [4.10.3] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.10.3...v4.10.2) - 2025-03-04

### Changed

- Changed anomaly PLOT_WITH_UNDECLARED_AREA to not blocking on fvg validator plugin ([#165945](https://abacogroup.easyredmine.com/issues/165945))

## [4.10.2] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.10.2...v4.10.1) - 2025-03-04

### Added

- Added new tooltipData map on SnapElements to be shown as tooltip on the map
- Added new "Dichiarazioni 2024" layer on avepa2025 layers plugin

### Fixed

- Fixed getPlaces on domain avepa vine plugin

## [4.10.1] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.10.1...v4.10.0) - 2025-02-27

### Fixed

- Fixed getParcelsData on domain avepa2025 plugin

## [4.10.0] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.10.0...v4.9.6) - 2025-02-26

### Added

- Added support to new cropPlanType CROPPLAN_2025 for avepa (new avepa2025 plugins) ([#164432](https://abacogroup.easyredmine.com/issues/164432))
- Added ortophoto 2024 on avepa and avepa2025 layers plugin ([#162083](https://abacogroup.easyredmine.com/issues/162083))

## [4.9.6] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.9.6...v4.9.5) - 2025-02-21

### Fixed

- Fixed exception on anomalies calculation on agea validator plugin ([#164391](https://abacogroup.easyredmine.com/issues/164391))

## [4.9.5] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.9.5...v4.9.4) - 2025-02-19

### Added

- Added support to day from and day to crop plan types ([#164498](https://abacogroup.easyredmine.com/issues/164498))

### Fixed

- Fixed getBreakingPoints during sync process causing error with oracle when day_to = 99991231 ([#164927](https://abacogroup.easyredmine.com/issues/164927))

## [4.9.4] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.9.4...v4.9.3) - 2025-02-18

### Fixed

- Fixed getNextChangesDateFromLpisDate not working with no lastSyncDt on fvg sync plugin ([#161288](https://abacogroup.easyredmine.com/issues/161288))

## [4.9.3] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.9.3...v4.9.2) - 2025-02-18

### Fixed

- Fixed getNextChangesDateFromLpisDate not working with no lastSyncDt on fvg sync plugin ([#161288](https://abacogroup.easyredmine.com/issues/161288))

## [4.9.2] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.9.2...v4.9.1) - 2025-02-17

### Fixed

- Fixed getParcelsByParcelCodes parcel dates on fvg domain plugin

## [4.9.1] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.9.1...v4.9.0) - 2025-02-14

### Fixed

- Fixed fvg plugins supporting pointInTime ([#161288](https://abacogroup.easyredmine.com/issues/161288))

## [4.9.0] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.9.0...v4.8.6) - 2025-02-13

### Changed

- Changed fvg plugins supporting pointInTime ([#161288](https://abacogroup.easyredmine.com/issues/161288))

## [4.8.6] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.8.6...v4.8.5) - 2025-02-12

### Changed

- Changed jersey config increasing timeout to 1 minute

## [4.8.5] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.8.5...v4.8.4) - 2025-02-12

### Added

- Added new deletePlot and deletePlots public APIs

## [4.8.4] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.8.4...v4.8.3) - 2025-02-12

### Fixed

- Fixed anomalies recalculation on deleting plots do not consider declaration on deleted plots on avepa vine, agea vine, fruit and olive plugin

## [4.8.3] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.8.3...v4.8.2) - 2025-01-31

### Changed

- Changed anomaly "SV10" not calculated from PROTOCOLLING status on avepa vine plugin ([#162771](https://abacogroup.easyredmine.com/issues/162771))

## [4.8.2] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.8.2...v4.8.1) - 2025-01-31

### Fixed

- Fixed ortophoto layers (only recent is on) on avepa vine plugin ([#129498](https://abacogroup.easyredmine.com/issues/129498))

## [4.8.1] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.8.1...v4.8.0) - 2025-01-30

### Changed

- Changed anomaly "SV09" to blocking on avepa vine validator plugin ([#162675](https://abacogroup.easyredmine.com/issues/162675))

## [4.8.0] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.8.0...v4.7.14) - 2025-01-29

### Changed

- Updated embeded-db-queue to v1.16.2 supporting auto restart for dead hosts

## [4.7.14] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.7.14...v4.7.13) - 2025-01-29

### Changed

- Changed removing plantingType from wizard plots on agea vine sync plugin
- Optimized avepa crop codes plugin removing deco_srv.get_decode from some queries

### Fixed

- Fixed queries related to anomalies 09 on agea vine validator plugin

### Removed

- Removed covcodcrpl_cache from avepa crop codes plugin

## [4.7.13] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.7.13...v4.7.12) - 2025-01-28

### Changed

- Changed avepa crop codes plugin adding covcodcrpl_cache

## [4.7.12] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.7.12...v4.7.11) - 2025-01-24

### Added

- Added check anomaly SV09, SO09 and SF09 when calculating anomalies on agea validator plugin for vine, olive and fruit ([#162137](https://abacogroup.easyredmine.com/issues/162137))

## [4.7.11] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.7.11...v4.7.10) - 2025-01-24

### Changed

- Changed getAnomaliesValidatorResult public API now supporting empty plots array in payload
- Changed DOMAIN_PLOTS and LATEST_OTHER_PLANS_VERSION_EMPTY_DOMAIN_PLOTS layers supporting no domainZoneId specified using instead requested srs

## [4.7.10] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.7.10...v4.7.9) - 2025-01-23

### Fixed

- Fix sonar agea issues

## [4.7.9] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.7.9...v4.7.8) - 2025-01-22

### Changed

- Changed LATEST_VERSION_DOMAIN_PLOTS layer supporting no domainZoneId specified using instead requested srs

## [4.7.8] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.7.8...v4.7.7) - 2025-01-22

### Changed

- Changed LATEST_VERSION_DOMAIN_PLOTS layer improving performances filtering by area of interest and supporting reprojection to requested srs

## [4.7.7] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.7.7...v4.7.6) - 2025-01-21

### Changed

- Changed LATEST_VERSION_DOMAIN_PLOTS layer removing support to no domainZoneId specified and added support to sectorCode instead of domainZoneId

## [4.7.6] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.7.6...v4.7.5) - 2025-01-20

### Changed

- Changed LATEST_VERSION_DOMAIN_PLOTS layer supporting no domainZoneId specified

## [4.7.5] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.7.5...v4.7.4) - 2025-01-15

### Fixed

- Fixed anomalies calculation on avepa vine validator plugin ([#161385](https://abacogroup.easyredmine.com/issues/161385))

## [4.7.4] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.7.4...v4.7.3) - 2025-01-14

### Fixed

- Fixed anomalies calculation on avepa vine validator plugin ([#160465](https://abacogroup.easyredmine.com/issues/160465))

## [4.7.3] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.7.3...v4.7.2) - 2025-01-13

### Fixed

- Fixed anomalies calculation on avepa vine validator plugin ([#160465](https://abacogroup.easyredmine.com/issues/160465))

## [4.7.2] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.7.2...v4.7.1) - 2025-01-10

### Changed

- Changed removing plantingType from wizard plots on avepa vine sync plugin
- Optimized SV04 anomalies calculation on avepa vine validator plugin

## [4.7.1] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.7.1...v4.7.0) - 2025-01-10

### Added

- Added anomaly "SV09" (not blocking) on avepa vine validator plugin

## [4.7.0] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.7.0...v4.6.1) - 2024-12-19

### Added

- Added new STRING additional field type and extended field value maximum size to 4000 characters

### Fixed

- Fixed anomaly "04" (check on permanent crop form data) adding planting type validation ([#160415](https://abacogroup.easyredmine.com/issues/160415))

## [4.6.1] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.6.1...v4.6.0) - 2024-12-19

### Changed

- Implemented other caches on queries

### Fixed

- Fixed massive update APIs to validate data only one time for all declarations ([#159722](https://abacogroup.easyredmine.com/issues/159722))

## [4.6.0] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.6.0...v4.5.14) - 2024-12-16

### Changed

- Changed defined list of common permanent crop form config to exclude from get common configs endpoint
- Changed massive update now calculate stumps number and density if distances are not null
- Reworked overall codes to implement various caches

### Fixed

- Fixed removing parallelStream from parcel intersections

## [4.5.14] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.5.14...v4.5.13) - 2024-12-05

### Fixed

- Fixed error caused by anomalies calculated on declarations on shared parcels on fvg validator plugin ([#157847](https://abacogroup.easyredmine.com/issues/157847))

## [4.5.13] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.5.13...v4.5.12) - 2024-12-03

### Added

- Added new massive update APIs for declarations fields

## [4.5.12] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.5.12...v4.5.11) - 2024-11-26

### Removed

- Removed logs for debug purposes from getAnomaliesValidatorResult public API

## [4.5.11] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.5.11...v4.5.10) - 2024-11-26

### Added

- Added support to "cropplan" value for cllUrl configuration on external standard domain plugin to skip parcels loading using domains of plots in the crop plan

### Changed

- Updated plugins-support to v4.0.1 to fix accept-language issue in server-server api call

## [4.5.10] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.5.10...v4.5.9) - 2024-11-25

### Added

- Added logs for debug purposes to getAnomaliesValidatorResult public API

## [4.5.9] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.5.9...v4.5.8) - 2024-11-22

### Added

- Added get all plot with declarations and rotation endpoint
- Added get all common land use and permanent crop form configs by land use codes endpoint
- Added massive fields update endpoint ([#141081](https://abacogroup.easyredmine.com/issues/141081))
- Added logs for debug purposes to getAnomaliesValidatorResult public API

## [4.5.8] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.5.8...v4.5.7) - 2024-11-19

### Changed

- Changed DeclarationAdditionalFieldNotAllowedException detailing the raised exception

## [4.5.7] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.5.7...v4.5.6) - 2024-11-18

### Added

- Added new public getDeclarationsLandUsesWithArea API
- Added new public cleanupCropPlan API

### Fixed

- Fixed getAnomaliesValidatorResult public API raising an error if a specified declaration does not exist ([#155662](https://abacogroup.easyredmine.com/issues/155662))

## [4.5.6] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.5.6...v4.5.5) - 2024-10-29

### Fixed

- Fixed getAnomaliesValidatorResult public API to get anomalies calculated on specified plots and declarations ([#154949](https://abacogroup.easyredmine.com/issues/154949))

## [4.5.5] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.5.5...v4.5.4) - 2024-10-28

### Added

- Added ignoreAllDeclValidationMessages flag on createDeclaration, createDeclarations, updateDeclaration, deleteDeclaration public crop plan declarations APIs ([#119141](https://abacogroup.easyredmine.com/issues/119141))

## [4.5.4] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.5.4...v4.5.3) - 2024-10-28

### Changed

- Changed aria crop plan plugin adding DISABLE_ADD_DECLARATIONS in getCropPlanConfig

## [4.5.3] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.5.3...v4.5.2) - 2024-10-25

### Added

- Added isCalculateAtPreviousVersion value check on calculateAnomalies for all validator plugin implementations

## [4.5.2] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.5.2...v4.5.1) - 2024-10-24

### Added

- Added new getAnomaliesValidatorResult public API to get anomalies calculated on specified plots and declarations (version query parameter supported only on fvg validator plugin) ([#154949](https://abacogroup.easyredmine.com/issues/154949))

## [4.5.1] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.5.1...v4.5.0) - 2024-10-24

### Fixed

- Fixed profile external on new newagri variant

## [4.5.0] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.5.0...v4.4.20) - 2024-10-21

### Added

- Added new newagri variant

## [4.4.20] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.20...v4.4.19) - 2024-10-16

### Fixed

- Fixed get crop plan timeline raw sql query, needed escape to date alias (removed during sonarqube's refactor)

## [4.4.19] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.19...v4.4.18) - 2024-10-09

### Fixed

- Fixed land use code not found raising an exception in getLandUseCode on standard crop codes plugin

## [4.4.18] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.18...v4.4.17) - 2024-10-02

### Fixed

- Fixed business query on agea plugin

## [4.4.17] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.17...v4.4.16) - 2024-10-02

### Added

- Added distinct on business query agea plugin

## [4.4.16] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.16...v4.4.15) - 2024-09-30

### Fixed

- Fixed null payload params on DomainPluginImpl

## [4.4.15] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.15...v4.4.14) - 2024-09-30

### Added

- Added sync in progress exception on lock check

### Fixed

- Fixed bad Lpis DTO, query and ResultSet closed on businnesId

## [4.4.14] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.14...v4.4.13) - 2024-09-27

### Fixed

- Fixed sonar issues on agea

## [4.4.13] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.13...v4.4.12) - 2024-09-26

### Changed

- Changed date precision check on anomaly 04 on agea and avepa vine validator plugin evaluating new MANDATORY_PLANTING_DATE_PRECISION
- Changed anomaly 04 not more blocking on avepa vine validator plugin

### Fixed

- Fixed issue on restorePlotsDefault when receiving more than 1000 plot codes to be restored
- Fixed getGISInfo for DOMAIN_PLOTS layer on agea layers plugins for fruit, olive and vine tenant
- Fixed sonar issues on agea

## [4.4.12] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.12...v4.4.11) - 2024-09-25

### Fixed

- Fixed getGISInfo for DOMAIN_PLOTS layer on agea layers plugins for fruit, olive and vine tenant

## [4.4.11] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.11...v4.4.10) - 2024-09-24

### Fixed

- Fixed getGISInfo for DOMAIN_PLOTS layer on agea layers plugins for fruit, olive and vine tenant

## [4.4.10] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.10...v4.4.9) - 2024-09-24

### Changed

- Changed layers snap geometries on agea domain and layers plugins for fruit, olive and vine tenant ([#152588](https://abacogroup.easyredmine.com/issues/152588))

## [4.4.9] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.9...v4.4.8) - 2024-09-24

### Fixed

- Fixed anomalies check 04 and 05 on agea validator plugin for fruit, olive and vine tenant

## [4.4.8] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.8...v4.4.7) - 2024-09-24

### Fixed

- Fixed anomalies check 04 on agea validator plugin for fruit, olive and vine tenant ([#152606](https://abacogroup.easyredmine.com/issues/152606))

## [4.4.7] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.7...v4.4.6) - 2024-09-23

### Added

- Add public API for getting declaration base info (used by monitoring)

## [4.4.6] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.6...v4.4.5) - 2024-09-23

### Fixed

- Fixed declarations area percentage calculation in sync wizard plots

## [4.4.5] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.5...v4.4.4) - 2024-09-23

### Changed

- Changed anomalies check 04 are now blocking and land use code 000 value raise the 04 anomaly on agea validator plugin for fruit, olive and vine tenant

### Fixed

- Fixed anomalies check 01 and 02 on agea validator plugin for fruit, olive and vine tenant

## [4.4.4] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.4...v4.4.3) - 2024-09-20

### Fixed

- Fixed domain and layers agea plugins for fruit and olive tenant
- Fixed external description on agea crop plan plugin for fruit and olive tenant

## [4.4.3] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.3...v4.4.2) - 2024-09-20

### Fixed

- Fixed auth and business agea plugins for fruit and olive tenant

## [4.4.2] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.2...v4.4.1) - 2024-09-19

### Fixed

- Fixed permanent crop form field values queries on avepa vine and agea plugins

## [4.4.1] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.1...v4.4.0) - 2024-09-19

### Fixed

- Fixed quality_system and protection_structures columns saving in crpl_perm_crop_forms table

## [4.4.0] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.4.0...v4.3.34) - 2024-09-18

### Added

- Added quality_system and protection_structures columns to crpl_perm_crop_forms table
- Added new fruitalign and olivealign crop plan types for agea plugins ([#148182](https://abacogroup.easyredmine.com/issues/148182)) ([#146889](https://abacogroup.easyredmine.com/issues/146889))

## [4.3.34] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.34...v4.3.33) - 2024-09-17

### Added

- Added new aria crop plan plugin

## [4.3.33] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.33...v4.3.32) - 2024-09-11

### Fixed

- Fixed getChangedPlots check on geomChanged flag and added new checkByPlotDescriptionIfPlotCodeNotFound query param ([#148333](https://abacogroup.easyredmine.com/issues/148333))

## [4.3.32] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.32...v4.3.31) - 2024-09-09

### Fixed

- Fixed getGroupedCropPlanAnomalies API adding groupDeclAnomaliesOnPlots query parameter ([#150576](https://abacogroup.easyredmine.com/issues/150576))

## [4.3.31] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.31...v4.3.30) - 2024-09-03

### Added

- Added new variable for timeout setups for Jersey on aria (optional parameter for others)

## [4.3.30] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.30...v4.3.29) - 2024-08-30

### Changed

- Changed getGroupedCropPlanAnomalies API adding groupDeclAnomaliesOnPlots query parameter ([#150576](https://abacogroup.easyredmine.com/issues/150576))

## [4.3.29] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.29...v4.3.28) - 2024-08-30

### Changed

- Changed SV03 as blocking anomaly on agea validator plugin

## [4.3.28] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.28...v4.3.27) - 2024-08-30

### Fixed

- Fixed parallel cache_decodes updates creating fake insert for locking updates ([#148835](https://abacogroup.easyredmine.com/issues/148835))

## [4.3.27] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.27...v4.3.26) - 2024-08-28

### Added

- Added SV03 on aria validator plugin

## [4.3.26] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.26...v4.3.25) - 2024-08-28

### Fixed

- Fixed getGroupedCropPlanAnomalies API raising an error with parcels with different domainZoneId in time

## [4.3.25] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.25...v4.3.24) - 2024-08-28

### Fixed

- Fixed getGroupedCropPlanAnomalies API raising an error with parcels with different domainZoneId in time

## [4.3.24] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.24...v4.3.23) - 2024-08-27

### Added

- Fixed parallel cache_decodes updates making update operations transational ([#148835](https://abacogroup.easyredmine.com/issues/148835))

## [4.3.23] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.23...v4.3.22) - 2024-08-22

### Added

- Added new DISABLE_ADD_DECLARATIONS config parameter ([#137385](https://abacogroup.easyredmine.com/issues/137385))

## [4.3.22] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.22...v4.3.21) - 2024-08-20

### Changed

- Changed resumePlotFromCropPlanFirstVersion API trying to load plot by description if plot code is not found in the first crop plan version ([#147964](https://abacogroup.easyredmine.com/issues/147964))

## [4.3.21] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.21...v4.3.20) - 2024-08-14

### Added

- Added excludes query param to getDeclarablePlots public API ([#146108](https://abacogroup.easyredmine.com/issues/146108))

## [4.3.20] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.20...v4.3.19) - 2024-08-13

### Fixed

- Fixed sync loading wrong changeIds format while performing a full sync on malta sync plugin ([#142447](https://abacogroup.easyredmine.com/issues/142447))

## [4.3.19] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.19...v4.3.18) - 2024-08-08

### Added

- Added geomChanged flag to getChangedPlots API ([#148333](https://abacogroup.easyredmine.com/issues/148333))

### Changed

- Optimized getLandCoverEditability check on avepa vine crop codes plugin

### Fixed

- Fixed issue on checkSV10 method, now check by plot description if available ([#145054](https://abacogroup.easyredmine.com/issues/145054))

## [4.3.18] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.18...v4.3.17) - 2024-08-07

### Added

- Added support to ignorePreviousSyncs query param in the syncCropPlan public API to perform a forced sync [#142447](https://abacogroup.easyredmine.com/issues/142447)
- Added domain zone id as a query parameter for the lpis additional layer API on fvg layers plugin [#140242](https://abacogroup.easyredmine.com/issues/140242)

## [4.3.17] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.17...v4.3.16) - 2024-07-30

### Removed

- Removed SV03 from ARIA

## [4.3.16] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.16...v4.3.15) - 2024-07-29

### Added

- Added layer vivai_viticoli for FVG [#147438](https://abacogroup.easyredmine.com/issues/147438)

## [4.3.15] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.15...v4.3.14) - 2024-07-29

### Fixed

- Fixed error with the query that retrieves geometries for RPPG2024_DEFINITIVI [#147047](https://abacogroup.easyredmine.com/issues/147047)

## [4.3.14] (https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.14...v4.3.13) - 2024-07-29

### Fixed

- Fixed transfer of Geometry data to Validator in crop-plan-aria-plugins

## [4.3.13](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.13...v4.3.12) - 2024-07-29

### Fixed

- Fixed error with getting snap goemetries for the layer RPPG2024_DEFINITIVI [#147047](https://abacogroup.easyredmine.com/issues/147047)

## [4.3.12](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.12...v4.3.11) - 2024-07-24

### Added

- Added layer RPPG2024_DEFINITIVI and RPPG2024_POTENZIALI for avepa [#147147](https://abacogroup.easyredmine.com/issues/147147)

### Removed

- Removed layer RPPG2024_DEFINITIVI from avepa in favor of RPPG2024_DEFINITIVI and RPPG2024_POTENZIALI [#147147](https://abacogroup.easyredmine.com/issues/147147)

## [4.3.11](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.11...v4.3.10) - 2024-07-19

### Changed

- Changed plot returned by APIs adding srs

## [4.3.10](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.10...v4.3.9) - 2024-07-19

### Added

- Added doNotAdjustDeclDates query parameter to getAllPlots public API

### Fixed

- Fixed sync loading wrong changeIds format while performing a full sync on malta sync plugin [#142447](https://abacogroup.easyredmine.com/issues/142447)
- Fixed SV10 anomaly calculation on avepa vine validator plugin [#145054](https://abacogroup.easyredmine.com/issues/145054)

## [4.3.9](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.9...v4.3.8) - 2024-07-18

### Fixed

- Fixed cut on LATEST_OTHER_PLANS_VERSION_EMPTY_DOMAIN_PLOTS layer on fvg layers plugin [#143800](https://abacogroup.easyredmine.com/issues/143800)

## [4.3.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.8...v4.3.7) - 2024-07-18

### Changed

- Changed apigateway timeout from 180s to 300s [#143774](https://abacogroup.easyredmine.com/issues/143774)

## [4.3.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.7...v4.3.6) - 2024-07-18

### Fixed

- Fixed layer LATEST_OTHER_PLANS_VERSION_EMPTY_DOMAIN_PLOTS [#143800](https://abacogroup.easyredmine.com/issues/143800)

## [4.3.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.6...v4.3.5) - 2024-07-18

### Added

- Added not blocking anomaly SV10 based on rejected tasks on avepa vine validator plugin [#145054](https://abacogroup.easyredmine.com/issues/145054)

### Fixed

- Fixed abaco-jdbi updating to v2.17.2

## [4.3.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.5...v4.3.4) - 2024-07-17

### Changed

- fllMergeGeomsOnCutOnLayer has been set to false for CADPARCEL layer on avepa layers plugin [#143805](https://abacogroup.easyredmine.com/issues/143805)

### Fixed

- Fixed layer LATEST_OTHER_PLANS_VERSION_EMPTY_DOMAIN_PLOTS [#143800](https://abacogroup.easyredmine.com/issues/143800)
- Fixed external sync plugin

## [4.3.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.4...v4.3.3) - 2024-07-17

### Added

- Added layer LATEST_OTHER_PLANS_VERSION_EMPTY_DOMAIN_PLOTS on fvg layers plugin [#143800](https://abacogroup.easyredmine.com/issues/143800)
- Added configuration parameter LATEST_OTHER_PLANS_VERSION_EMPTY_DOMAIN_PLOTS_LAYER_AREA_TOLERANCE [#143800](https://abacogroup.easyredmine.com/issues/143800)

## [4.3.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.3...v4.3.2) - 2024-07-16

### Fixed

- Fixed aria plugins

## [4.3.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.2...v4.3.1) - 2024-07-15

### Fixed

- Fixed aria plugins

## [4.3.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.1...v4.3.0) - 2024-07-12

### Added

- Added new aria plugins

### Changed

- Refactored external domain and sync plugins

### Fixed

- Fixed SHARED_PARCEL_INVALID_PLOT_DECL_AREA anomalies calculation on fvg validator plugin [#143800](https://abacogroup.easyredmine.com/issues/143800)

## [4.3.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.1...v4.3.0) - 2024-07-12

### Added

- Added new aria plugins

### Changed

- Refactored external domain and sync plugins

### Fixed

- Fixed SHARED_PARCEL_INVALID_PLOT_DECL_AREA anomalies calculation on fvg validator plugin [#143800](https://abacogroup.easyredmine.com/issues/143800)

## [4.3.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.3.0...v4.2.7) - 2024-07-09

### Added

- Added SHARED_PARCEL_INVALID_PLOT_DECL_AREA anomalies calculation on fvg validator plugin [#143800](https://abacogroup.easyredmine.com/issues/143800)
- Added ISOLE layer on fvg layers plugin [#143800](https://abacogroup.easyredmine.com/issues/143800)

### Changed

- BREAKING CHANGE: reworked anomalies calculation

## [4.2.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.2.7...v4.2.6) - 2024-07-05

### Added

- Added pointInTime query parameter for declaration resources APIs to check assignable additional fields and permanent crop forms [#145117](https://abacogroup.easyredmine.com/issues/145117) [#143922](https://abacogroup.easyredmine.com/issues/143922)

## [4.2.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.2.6...v4.2.5) - 2024-07-04

### Fixed

- Fixed copyDeclarations API [#142114](https://abacogroup.easyredmine.com/issues/142114)

## [4.2.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.2.5...v4.2.4) - 2024-07-03

### Changed

- Changed copyDeclarations API returning source declarations already existing [#142114](https://abacogroup.easyredmine.com/issues/142114)

### Fixed

- Fixed isReadOnly while vine align is in PROTOCOLLING status on avepa vine plugin
- Fixed copyDeclarations API [#137645](https://abacogroup.easyredmine.com/issues/137645)

## [4.2.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.2.4...v4.2.3) - 2024-07-02

### Fixed

- Fixed copyDeclarations API [#142114](https://abacogroup.easyredmine.com/issues/142114)

## [4.2.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.2.3...v4.2.2) - 2024-07-01

### Added

- Added "Suoli schedario viticolo" and "PLT" layers on fvg [#144463](https://abacogroup.easyredmine.com/issues/144463) [#143374](https://abacogroup.easyredmine.com/issues/143374)

## [4.2.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.2.2...v4.2.1) - 2024-06-27

### Fixed

- Fixed getLandCoverEditability on avepa vine crop codes plugin [#144173](https://abacogroup.easyredmine.com/issues/144173)

## [4.2.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.2.1...v4.2.0) - 2024-06-27

### Added

- Added new copyDeclarations API [#137645](https://abacogroup.easyredmine.com/issues/137645)
- Added support to DISABLE_COPY_DUPLICATED_EXTERNAL_DECLARATIONS config parameter in copyDeclarations API [#142114] (https://abacogroup.easyredmine.com/issues/142114)

### Fixed

- Fixed preserving plot notes in syncPlotAlign [#137387](https://abacogroup.easyredmine.com/issues/137387)

## [4.2.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.2.0...v4.1.8) - 2024-06-26

### Fixed

- Updated bundles-infrastructure version to 1.5.2 resolving starting issue [#139596](https://abacogroup.easyredmine.com/issues/139596)

## [4.1.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.1.8...v4.1.7) - 2024-06-25

### Fixed

- Fixed getGroupedCropPlanAnomalies raising an error when a parcel is moved to another domain zone [#143597](https://abacogroup.easyredmine.com/issues/143597)

## [4.1.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.1.7...v4.1.6) - 2024-06-21

### Added

- Added layer RPPG2024 on avepa layers plugin [#36001](https://abacogroup.easyredmine.com/issues/36001)

## [4.1.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.1.6...v4.1.5) - 2024-06-19

### Fixed

- Fixed new status on avepa vine plugins

## [4.1.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.1.5...v4.1.4) - 2024-06-18

### Added

- Added gis info to DOMAIN_PLOTS wms service on avepa vine and agea layers plugin [#137315](https://abacogroup.easyredmine.com/issues/137315)

### Fixed

- Fixed LATEST_VERSION_DOMAIN_PLOTS layer label on avepa vine layers plugin [#139252](https://abacogroup.easyredmine.com/issues/139252)
- Fixed SV01, SV02 and SV03 evaluation on avepa vine validator plugin [#141932](https://abacogroup.easyredmine.com/issues/141932)
- Fixed resumePlotFromCropPlanFirstVersion API [#143354](https://abacogroup.easyredmine.com/issues/143354)

## [4.1.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.1.4...v4.1.3) - 2024-06-17

### Changed

- Changed land cover editability in the new REVISION_REJECTED status on avepa vine crop codes plugin [#137544](https://abacogroup.easyredmine.com/issues/137544)
- Changed getGISInfo public API accepting domainZoneCode instead of domainZoneId [#137315](https://abacogroup.easyredmine.com/issues/137315)
- Changed NPR layer from old wmsProject to new vector-data-layers on avepa vine layers plugin [#125796](https://abacogroup.easyredmine.com/issues/125796)

## [4.1.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.1.3...v4.1.2) - 2024-06-16

### Added

- Added new getGISInfo public API [#137315](https://abacogroup.easyredmine.com/issues/137315)

### Changed

- Changed read only and can add plots behaviour with the new REVISION_REJECTED status on avepa vine crop plan plugin [#137544](https://abacogroup.easyredmine.com/issues/137544)
- Changed DOMAIN_PLOTS wms service adding businessId and cropPlanTypeCode parameter as an alternative to cropPlanId [#137315](https://abacogroup.easyredmine.com/issues/137315)
- Improved getSnapGeometries performances downloading only geometries touching business parcels on avepa domain plugin

## [4.1.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.1.2...v4.1.1) - 2024-06-14

### Fixed

- Fixed getBusinessDomainZonesFilteredBySearchAndDomainZoneIds not returning no more existing old domain zone ids on fvg domain plugin

## [4.1.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.1.1...v4.1.0) - 2024-06-14

### Fixed

- Fixed duplicated permanent crop forms linked to a declaration created using reproportionDecls API [#141258](https://abacogroup.easyredmine.com/issues/141258)

## [4.1.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.1.0...v4.0.34) - 2024-06-13

### Added

- Added notes field to plot (crpl_plot_names) and managed in renamePlot API [#137387](https://abacogroup.easyredmine.com/issues/137387)
- Added automatic merge of adjacent plots on sync if ENABLE_AUTOMERGE_FOR_LPIS_SYNC config param is set to TRUE [#97493](https://abacogroup.easyredmine.com/issues/97493)

### Fixed

- Fixed removeExistingDeclarations on InsertDeclarationPayload and EditDeclarationsPayload for insert single declaration or multiple declarations [#142184](https://abacogroup.easyredmine.com/issues/142184)

## [4.0.34](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.34...v4.0.33) - 2024-06-12

### Fixed

- Fixed LATEST_VERSION_DOMAIN_PLOTS wms service [#139252](https://abacogroup.easyredmine.com/issues/139252)

## [4.0.33](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.33...v4.0.32) - 2024-06-12

### Added

- Added new flCalcCoveredByInsertedOnCutOnLayer flag behaviour on SnapElementType [#142184](https://abacogroup.easyredmine.com/issues/142184)
- Added new removeExistingDeclarations on InsertDeclarationPayload and EditDeclarationsPayload for insert single declaration or multiple declarations [#142184](https://abacogroup.easyredmine.com/issues/142184)
- Added LATEST_VERSION_DOMAIN_PLOTS wms service [#139252](https://abacogroup.easyredmine.com/issues/139252)
- Added check on publish result on fvg crop plan plugin [#141187](https://abacogroup.easyredmine.com/issues/141187)

### Changed

- Changed cut plots by geometries computeCoveredByInteserd behaviour supporting new ComputeCoveredByInserted.ALL_INTERACTIONS [#142184](https://abacogroup.easyredmine.com/issues/142184)

### Fixed

- Fixed default stroke land cover class style on standard crop codes plugin
- Fixed land use compatibility always false when no land cover code defined on standard crop codes plugin [#142216](https://abacogroup.easyredmine.com/issues/142216)

## [4.0.32](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.32...v4.0.31) - 2024-06-06

### Fixed

- Fixed AdditionalDeclarationFieldsConfigProcessor using wrong sequence to generate id for CRPL_LANDUSE_ADDIT_FIELDS_VAL

## [4.0.31](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.31...v4.0.30) - 2024-06-06

### Added

- Added new flMergeGeomsOnCutOnLayer flag behaviour on SnapElementType and added in cut plots by geometries payload

## [4.0.30](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.30...v4.0.29) - 2024-06-05

### Changed

- Changed catalogs spatial query using mask=ANYINTERACT instead of §geom_have_interactions§ on avepa layers plugin

## [4.0.29](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.29...v4.0.28) - 2024-06-05

### Fixed

- Fixed cache used to store land cover and land use codes used when fetching declarations in DeclarationsService [#140567](https://abacogroup.easyredmine.com/issues/140567)
- Fixed declaration area perc calculated on plots edits in DeclarationService [#141932](https://abacogroup.easyredmine.com/issues/141932)

## [4.0.28](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.28...v4.0.27) - 2024-06-04

### Fixed

- Fixed SHP_CONFINE_OLIO_DOP_VENETO info gis on catalog on avepa layers plugin [#140955](https://abacogroup.easyredmine.com/issues/140955)

## [4.0.27](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.27...v4.0.26) - 2024-06-04

### Added

- Added SHP_COMUNI_CONTERMINI catalogs on avepa layers plugin [#140953](https://abacogroup.easyredmine.com/issues/140953)
- Added SHP_CONFINE_OLIO_DOP_VENETO catalogs on avepa layers plugin [#140955](https://abacogroup.easyredmine.com/issues/140955)

### Changed

- Changed ECOSCHEMI layers on avepa layers plugin
- Changed snap geometries on fvg layers plugin [#140850](https://abacogroup.easyredmine.com/issues/140850)

### Fixed

- Fixed cut plots by geometries (updated geometry-editor to v2.4.11)

## [4.0.26](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.26...v4.0.25) - 2024-06-03

### Fixed

- Fixed CONFERME_2014_2020 and CONFERME_2023_2027 catalogs splitting on all option codes on avepa layers plugin

## [4.0.25](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.25...v4.0.24) - 2024-06-03

### Added

- Added covered by inserted computing on cut by geometries API [#141542](https://abacogroup.easyredmine.com/issues/141542)

### Changed

- Changed CONFERME_2014_2020 and CONFERME_2023_2027 catalogs splitting on all option codes on avepa layers plugin

## [4.0.24](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.24...v4.0.23) - 2024-06-03

### Added

- Added snap element type for vector data layers on fvg layers plugin [#140850](https://abacogroup.easyredmine.com/issues/140850)

## [4.0.23](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.23...v4.0.22) - 2024-06-03

### Added

- Added snap geometries to CATASTO layer on fvg domain plugin [#140850](https://abacogroup.easyredmine.com/issues/140850)

### Fixed

- Fixed getTotalDeclaredArea with new optional domainZoneId queryParam [#140071](https://abacogroup.easyredmine.com/issues/140071)

## [4.0.22](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.22...v4.0.21) - 2024-05-31

### Changed

- Changed getTotalDeclaredArea adding new optional domainZoneId queryParam to return also domainAreaSqm and domainDeclaredAreaPercentage [#140071](https://abacogroup.easyredmine.com/issues/140071)

## [4.0.21](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.21...v4.0.20) - 2024-05-31

### Fixed

- Fixed restore last version API [#141482](https://abacogroup.easyredmine.com/issues/141482)

## [4.0.20](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.20...v4.0.19) - 2024-05-30

### Fixed

- Fixed snap geometries loading reducing domain zone geometry on avepa domain plugin
- Fixed `subdomainZoneId` query param on plot edit APIs [#140071](https://abacogroup.easyredmine.com/issues/140071)

## [4.0.19](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.19...v4.0.18) - 2024-05-29

# Added

- Added `subdomainZoneId` query param on plot edit APIs [#140071](https://abacogroup.easyredmine.com/issues/140071) `<br/>`
  POST `/{{tenant}}/api-priv/v1/crop-plans/{{businessId}}/plans/{{cropPlanId}}/{{domainZoneId}}/plots/cut-lines/preview?subdomainZoneId={{$random.integer(100)}}` `<br/>`
  POST `/{{tenant}}/api-priv/v1/crop-plans/{{businessId}}/plans/{{cropPlanId}}/{{domainZoneId}}/plots/cut-lines?subdomainZoneId={{$random.integer(100)}}&ignoreDeclValidationWarnings=false` `<br/>`
  POST `/{{tenant}}/api-priv/v1/crop-plans/{{businessId}}/plans/{{cropPlanId}}/{{domainZoneId}}/plots/cut-geometries/preview?subdomainZoneId={{$random.integer(100)}}` `<br/>`
  POST `/{{tenant}}/api-priv/v1/crop-plans/{{businessId}}/plans/{{cropPlanId}}/{{domainZoneId}}/plots/cut-geometries?subdomainZoneId={{$random.integer(100)}}&ignoreDeclValidationWarnings=false` `<br/>`
  POST `/{{tenant}}/api-priv/v1/crop-plans/{{businessId}}/plans/{{cropPlanId}}/{{domainZoneId}}/plots/preview?subdomainZoneId={{$random.integer(100)}}` `<br/>`
  POST `/{{tenant}}/api-priv/v1/crop-plans/{{businessId}}/plans/{{cropPlanId}}/{{domainZoneId}}/plots?ignorePreviousSyncs=false&subdomainZoneId={{$random.integer(100)}}&ignoreDeclValidationWarnings=false&fromPointInTime={{$placeholder}}` `<br/>`
  PUT `/{{tenant}}/api-priv/v1/crop-plans/{{businessId}}/plans/{{cropPlanId}}/{{domainZoneId}}/plots/{{plotCode}}/preview?subdomainZoneId={{$random.integer(100)}}` `<br/>`
  PUT `/{{tenant}}/api-priv/v1/crop-plans/{{businessId}}/plans/{{cropPlanId}}/{{domainZoneId}}/plots/{{plotCode}}?version={{$placeholder}}&pointInTimeFrom={{$placeholder}}&pointInTimeTo={{$placeholder}}&ignoreDeclValidationWarnings=false&pointInTime={{$placeholder}}&subdomainZoneId={{$random.integer(100)}}&nextKey={{$random.alphanumeric(8)}}` `<br/>`
  PUT `/{{tenant}}/api-priv/v1/crop-plans/{{businessId}}/plans/{{cropPlanId}}/{{domainZoneId}}/plots/preview?subdomainZoneId={{$random.integer(100)}}` `<br/>`
  PUT `/{{tenant}}/api-priv/v1/crop-plans/{{businessId}}/plans/{{cropPlanId}}/{{domainZoneId}}/plots?ignorePreviousSyncs=false&subdomainZoneId={{$random.integer(100)}}&ignoreDeclValidationWarnings=false&fromPointInTime={{$placeholder}}` `<br/>`
  POST `/{{tenant}}/api-priv/v1/crop-plans/{{businessId}}/plans/{{cropPlanId}}/{{domainZoneId}}/plots/line-buffer/preview?subdomainZoneId={{$random.integer(100)}}` `<br/>`
  POST `/{{tenant}}/api-priv/v1/crop-plans/{{businessId}}/plans/{{cropPlanId}}/{{domainZoneId}}/plots/line-buffer?subdomainZoneId={{$random.integer(100)}}&ignoreDeclValidationWarnings=false`

### Fixed

- Fixed domain zones filter on agea domain plugin

## [4.0.18](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.18...v4.0.17) - 2024-05-28

### Fixed

- Restored snap geometries on avepa domain plugin removing self union

## [4.0.17](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.17...v4.0.16) - 2024-05-28

### Fixed

- Fixed cut by geometries reducing and fixing input cut geometries to avoid unexpected result in load polygons (plots) with interaction

## [4.0.16](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.16...v4.0.15) - 2024-05-28

### Fixed

- Fixed snap geometries on avepa domain plugin

### Removed

- Removed parcels and some catalogs from snappable geometries on avepa domain plugin

## [4.0.15](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.15...v4.0.14) - 2024-05-27

### Added

- Added new ECOSCHEMI 2023 catalogs on avepa layers plugin [#138120](https://abacogroup.easyredmine.com/issues/138120)

### Changed

- Changed dayFromPrecision behaviour on avepa vine and agea sync plugins [#140478](https://abacogroup.easyredmine.com/issues/140478)

### Fixed

- Fetch parcels descriptions with partitions to avoid in where condition with more than 1000 expressions on avepa domain plugin
- Fixed cache used to store land cover and land use codes used when fetching declarations in DeclarationsService adding a new dedicated cache table [#140567](https://abacogroup.easyredmine.com/issues/140567)

## [4.0.14](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.14...v4.0.13) - 2024-05-24

### Added

- Added new CONFERME_2014_2020 and CONFERME_2023_2027 catalogs on avepa layers plugin [#140408](https://abacogroup.easyredmine.com/issues/140408)

### Removed

- Removed DOMANDE_CONFERMA_14_20 catalog on avepa layers plugin [#140408](https://abacogroup.easyredmine.com/issues/140408)

## [4.0.13](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.13...v4.0.12) - 2024-05-24

### Fixed

- Fixed avepa sync plugin now evaluating also wrong tisole_npr.isola_npr_geom_id with a fallback to tisole_npr.isola_npr_id [#139138](https://abacogroup.easyredmine.com/issues/139138)
- Fixed restore parcel default (parent plot not found in created with parent)

## [4.0.12](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.12...v4.0.11) - 2024-05-24

### Fixed

- Fixed avepa validator plugin check on parcel exists at reference date for no parcel data anomalies [#139138](https://abacogroup.easyredmine.com/issues/139138)

## [4.0.11](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.11...v4.0.10) - 2024-05-24

### Fixed

- Fixed additional declaration fields config editability default to TRUE [#140351](https://abacogroup.easyredmine.com/issues/140351)

## [4.0.10](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.10...v4.0.9) - 2024-05-23

### Added

- Added check on version reference date when CONSTRAINTS_VERSION_TO_SYNC_REF_DATE config parameter is set to TRUE [#140071](https://abacogroup.easyredmine.com/issues/140071)

### Fixed

- Fixed mbr error returning null when it exists in db in public getDeclarations API [#139596](https://abacogroup.easyredmine.com/issues/139596)

## [4.0.9](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.9...v4.0.8) - 2024-05-22

### Fixed

- Fixed copy current year declarations from version issue [#135170](https://abacogroup.easyredmine.com/issues/135170)

## [4.0.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.8...v4.0.7) - 2024-05-21

### Fixed

- Fixed sync failing to load domain zone while not necessary [#139270](https://abacogroup.easyredmine.com/issues/139270)

## [4.0.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.7...v4.0.6) - 2024-05-20

### Added

- Added lastSyncReferenceDate in getCropPlanDates API [#140071](https://abacogroup.easyredmine.com/issues/140071)

### Fixed

- Fixed avepa sync plugin do not consider changed parcels with npr start year or holding start date before sync start date [#139588](https://abacogroup.easyredmine.com/issues/139588)

## [4.0.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.6...v4.0.5) - 2024-05-16

### Changed

- Changed fvg validator plugin calculating different anomalies for land covers [#139611](https://abacogroup.easyredmine.com/issues/139611)
- Changed avepa validator plugin checking if parcel exists at reference date for no parcel data anomalies [#139138](https://abacogroup.easyredmine.com/issues/139138)

## [4.0.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.5...v4.0.4) - 2024-05-15

### Fixed

- Fixed getCuuaAreaAndAnomaliesPlots API plot area evaluation ([#139354](https://abacogroup.easyredmine.com/issues/139354))

## [4.0.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.4...v4.0.3) - 2024-05-15

### Fixed

- Fixed getCuuaAreaAndAnomaliesPlots API old and new areas evaluation ([#139354](https://abacogroup.easyredmine.com/issues/139354))

## [4.0.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.3...v4.0.2) - 2024-05-14

### Fixed

- Fixed new CRPL_LANDUSE_ADDIT_FIELDS fields type removed FORMULA and supported NUMBER from bundle ([#138650](https://abacogroup.easyredmine.com/issues/138650))
- Fixed avepa validator plugin raising an error while trying to calculate anomalies on a plot not existing at reference date
- Fixed PropagationService.buildFutureIntersections not considering changed parcels (different codes but same geometries) on created results ([#138489](https://abacogroup.easyredmine.com/issues/138489))

## [4.0.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.2...v4.0.1) - 2024-05-09

### Fixed

- Fixed new CRPL_LANDUSE_ADDIT_FIELDS fields type (INTEGER and FORMULA) not processing correctly from bundle ([#138650](https://abacogroup.easyredmine.com/issues/138650))

## [4.0.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.1...v4.0.0) - 2024-05-08

### Added

- Added FL_EDITABLE, FORMULA columns to CRPL_LANDUSE_ADDIT_FIELDS table ([#138650](https://abacogroup.easyredmine.com/issues/138650))

### Fixed

- Fixed DOMAIN_PLOTS wms service not working after dropwizard 4 migration
- Fixed resumePlotFromCropPlanFirstVersion API do not recalc anomalies ([#138989](https://abacogroup.easyredmine.com/issues/138989))

## [4.0.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v4.0.0...v3.3.7) - 2024-05-07

### Added

- Added HEADER_TITLE_CODE column to CRPL_LANDUSE_ADDIT_FIELDS table ([#135005](https://abacogroup.easyredmine.com/issues/135005))

### Changed

- Updated to dropwizard 4
- Changed getAdditionalLayers APIs adding optional campaignYear and module query parameters ([#138780](https://abacogroup.easyredmine.com/issues/138780))
- Added logic for deleting records from crpl_landuse_addit_fields, from a specific date and inserting records without deleting previous one's in additional fields configuration ([#137663](https://abacogroup.easyredmine.com/issues/137663))

### Removed

- Removed filter CAA COP Trento for office id = 1181 on AuthSchedarioDAO and BusinessSchedarioDAO on agea plugin ([#138635] (https://abacogroup.easyredmine.com/issues/138635?project=false))

## [3.3.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.3.7...v3.3.6) - 2024-04-26

### Fixed

- Fixed land use compatibility on malta crop codes plugin ([#137060](https://abacogroup.easyredmine.com/issues/137060))

## [3.3.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.3.6...v3.3.5) - 2024-04-24

### Fixed

- Fixed sync process

## [3.3.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.3.5...v3.3.4) - 2024-04-24

### Fixed

- Fixed fvg domain plugin

## [3.3.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.3.4...v3.3.3) - 2024-04-24

### Fixed

- Fixed sync process

## [3.3.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.3.3...v3.3.2) - 2024-04-23

### Fixed

- Fixed fvg validator plugin ([#137083](https://abacogroup.easyredmine.com/issues/137083))

## [3.3.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.3.2...v3.3.1) - 2024-04-22

### Added

- Added new blocking anomaly PLOT_WITHOUT_PARCEL on avepa validator plugin ([#137083](https://abacogroup.easyredmine.com/issues/137083))

### Changed

- Updated dropwizard-auth-sso2 from v2.3.0 to v2.3.3
- Updated embeded-db-queue from v1.8.0 to v1.11.0

### Fixed

- Fixed avepa plugins using sso2client from env instead creating a new one every time

## [3.3.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.3.1...v3.3.0) - 2024-04-19

### Changed

- Optimized sync process on avepa plugins

## [3.3.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.3.0...v3.2.10) - 2024-04-19

### Changed

- Optimized sync process

### Removed

- Removed log info for debug purposes

## [3.2.10](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.2.10...v3.2.9) - 2024-04-18

### Added

- Added log info for debug purposes

### Changed

- Optimized sync process

## [3.2.9](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.2.9...v3.2.8) - 2024-04-18

### Added

- Added log info for debug purposes

### Changed

- Optimized sync process

## [3.2.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.2.8...v3.2.7) - 2024-04-17

### Added

- Added getCropPlanConfig in CropPlanPlugin to manage configurations on plugins ([#135787](https://abacogroup.easyredmine.com/issues/135787))
- Added DISABLE_VALID_VALUED_DECL_FIELDS_EDIT config parameter when vine align status is in progress on avepa vine plugin ([#135787](https://abacogroup.easyredmine.com/issues/135787))
- Added plot fullRangeFromDate and fullRangeToDate in get plots APIs ([#133688](https://abacogroup.easyredmine.com/issues/133688))

### Fixed

- Fixed fvg domain plugin ([#137210](https://abacogroup.easyredmine.com/issues/137210))

## [3.2.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.2.7...v3.2.6) - 2024-04-16

### Changed

- Changed crop plan declarations editability in graphic validation status on avepa vine crop plan and crop codes plugins ([#135787](https://abacogroup.easyredmine.com/issues/135787))

### Fixed

- Fixed validator plugin on avepa ([#137088](https://abacogroup.easyredmine.com/issues/137088))

## [3.2.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.2.6...v3.2.5) - 2024-04-12

### Changed

- Changed public create declaration API adding skipCheckCanDeclare query parameter

## [3.2.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.2.5...v3.2.4) - 2024-04-11

### Fixed

- Fixed sync optimization ([#136372](https://abacogroup.easyredmine.com/issues/136372))

## [3.2.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.2.4...v3.2.3) - 2024-04-11

### Fixed

- Fixed getSyncProgressInternal returning inProgress=false if sync is started from 5 days instead of 1 day

## [3.2.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.2.3...v3.2.2) - 2024-04-10

### Changed

- Changed anomalies SV03 and SV04 to blocking on avepa validator plugin ([#135787](https://abacogroup.easyredmine.com/issues/135787))
- Changed public create declaration API adding allowPartialAdditionalFields query parameter

### Fixed

- Fixed land uses description on standard crop codes plugin

## [3.2.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.2.2...v3.2.1) - 2024-04-10

### Fixed

- Fixed avepa sync plugin

## [3.2.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.2.1...v3.2.0) - 2024-04-09

### Fixed

- Fixed malta sync plugin to manage cancel lease

## [3.2.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.2.0...v3.1.19) - 2024-04-09

### Added

- Added new complete with tare date API

### Changed

- Optimized sync process

### Fixed

- Fixed complete with tare API
- Fixed fvg domain plugin

## [3.1.19](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.19...v3.1.18) - 2024-04-08

### Fixed

- Fixed prints parameters API

## [3.1.18](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.18...v3.1.17) - 2024-04-08

### Added

- Added prints parameters API

### Changed

- Optimized sync process

## [3.1.17](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.17...v3.1.16) - 2024-04-05

### Fixed

- Fixed fill land uses with permanent crop forms config

## [3.1.16](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.16...v3.1.15) - 2024-04-05

### Fixed

- Fixed fill land uses with permanent crop forms config
- Fixed land uses description on standard crop codes plugin

## [3.1.15](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.15...v3.1.14) - 2024-04-05

### Fixed

- Fixed standard crop codes plugin adding support to ignoreLandUseCompatibility

## [3.1.14](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.14...v3.1.13) - 2024-04-04

### Fixed

- Fixed fvg layers plugin

## [3.1.13](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.13...v3.1.12) - 2024-04-04

### Changed

- Optimized sync process

### Fixed

- Fixed fvg domain plugin
- Fixed standard crop codes plugin

## [3.1.12](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.12...v3.1.11) - 2024-04-04

### Added

- Added fvg validator plugin

### Fixed

- Fixed fvg layers plugin
- Fixed fvg domain plugin

## [3.1.11](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.11...v3.1.10) - 2024-04-03

### Fixed

- Fixed fvg layers plugin
- Fixed fvg domain plugin

## [3.1.10](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.10...v3.1.9) - 2024-04-03

### Fixed

- Fixed fvg layers plugin

## [3.1.9](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.9...v3.1.8) - 2024-04-03

### Fixed

- Fixed fvg sync plugin

### Added

- Added fvg layers plugin
- Added parcels snap geometries on fvg domain plugin

## [3.1.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.8...v3.1.7) - 2024-04-03

### Fixed

- Fixed fvg domain plugin

## [3.1.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.7...v3.1.6) - 2024-04-03

### Changed

- Removed PARCELS and LANDCOVERS (lpis-server-api/wms) layers on standard layers plugin

### Fixed

- Fixed land cover class description on fvg domain plugin
- Fixed land use compatibility on avepa crop codes plugin ([#135483](https://abacogroup.easyredmine.com/issues/135483))

## [3.1.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.6...v3.1.5) - 2024-04-02

### Added

- Added land cover class description cache on standard crop codes plugin

## [3.1.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.5...v3.1.4) - 2024-04-02

### Added

- Added get parcels data on fvg domain plugin

## [3.1.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.4...v3.1.3) - 2024-04-02

### Fixed

- Fixed fvg sync plugin

## [3.1.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.3...v3.1.2) - 2024-03-29

### Fixed

- Fixed fvg sync plugin

## [3.1.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.2...v3.1.1) - 2024-03-29

### Fixed

- Fixed config-docker-fvg.yml

## [3.1.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.1...v3.1.0) - 2024-03-29

### Added

- Added new IGNORE_LAND_USE_COMPATIBILITY configuration parameter
- Implemented domains and sync fvg plugins ([#134114](https://abacogroup.easyredmine.com/issues/134114))

### Changed

- Reworked anomalies calculation on avepa validator plugin ([#134676](https://abacogroup.easyredmine.com/issues/134676))

## [3.1.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.1.0...v3.0.20) - 2024-03-27

### Added

- Added group code in land use additional fields configuration (crpl_landuse_addit_fields) ([#134871](https://abacogroup.easyredmine.com/issues/134871))
- Added new crop-plan-fvg-plugins ([#134114](https://abacogroup.easyredmine.com/issues/134114))

### Changed

- Refactored external plugins

### Fixed

- Fixed getPlotsBetweenDates with doNotAdjustDeclDates=false returning wrong declarations dates ([#134871](https://abacogroup.easyredmine.com/issues/134871))

## [3.0.20](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.20...v3.0.19) - 2024-03-26

### Fixed

- Fixed sonar agea issues

## [3.0.19](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.19...v3.0.18) - 2024-03-25

### Fixed

- Fixed version extended message on avepa crop plan plugin ([#134716](https://abacogroup.easyredmine.com/issues/134716))

## [3.0.18](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.18...v3.0.17) - 2024-03-22

### Added

- Added new delete plots API ([#133688] (https://abacogroup.easyredmine.com/issues/133688))

## [3.0.17](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.17...v3.0.16) - 2024-03-20

### Fixed

- Fixed valid caa mand on agea BusinessSchedarioDAO and AuthSchedarioDAO ([#133162] (https://abacogroup.easyredmine.com/issues/133162))

## [3.0.16](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.16...v3.0.15) - 2024-03-14

### Added

- Added new copy previous year declarations from version API ([#132674](https://abacogroup.easyredmine.com/issues/132674))
- Added version used for application in version extended message on avepa crop plan plugin ([#132674](https://abacogroup.easyredmine.com/issues/132674))

### Fixed

- Fixed version extended message on avepa crop plan plugin ([#133924](https://abacogroup.easyredmine.com/issues/133924))

## [3.0.15](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.15...v3.0.14) - 2024-03-13

### Fixed

- Fixed valid data_scad_mand, codi_prov_caa and unresolved districts on agea BusinessSchedarioDAO and AuthSchedarioDAO (#133217, #133643)

## [3.0.14](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.14...v3.0.13) - 2024-03-13

### Changed

- Changed layer name in parcelle viticole on agea plugin

### Fixed

- Fixed set snap element type for suolo vitato on agea plugin

## [3.0.13](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.13...v3.0.12) - 2024-03-13

### Added

- Added PARCEL snap element type on agea plugin

### Fixed

- Fixed set snap element type for all srs on agea plugin

## [3.0.12](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.12...v3.0.11) - 2024-03-13

### Fixed

- Fixed parcel descriptions supporting old parcel code retrieved by isola_npr_id (instead of isola_npr_geom_id) on avepa plugin ([#132438](https://abacogroup.easyredmine.com/issues/132438))

## [3.0.11](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.11...v3.0.10) - 2024-03-12

### Fixed

- Fixed plot edit services propagating editing with a configured tolerance (parent plot not found in created with parent) ([#133631](https://abacogroup.easyredmine.com/issues/133631))

## [3.0.10](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.10...v3.0.9) - 2024-03-12

### Added

- Added soil and Poligoni GPS snap geometries on agea and avepa vine domain plugin ([#133387](https://abacogroup.easyredmine.com/issues/133387))

## [3.0.9](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.9...v3.0.8) - 2024-03-11

### Fixed

- Fixed restore parcel at point in time error while creating areas < 1sqm ([#133185](https://abacogroup.easyredmine.com/issues/133185))

## [3.0.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.8...v3.0.7) - 2024-03-07

### Fixed

- Fixed sonar agea issues on crop plan api

## [3.0.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.7...v3.0.6) - 2024-03-06

### Added

- Added crop plan version extended message by plugin and implemented on avepa crop plan plugin retrieving htu_id from publishing ([#131548](https://abacogroup.easyredmine.com/issues/131548))

### Fixed

- Fixed sonar agea issues on agea plugin

## [3.0.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.6...v3.0.5) - 2024-03-04

### Added

- Added new updateDeclarationsFields API to update declaration fields massively ([#131548](https://abacogroup.easyredmine.com/issues/131548))

### Changed

- Changed layers sort order on avepa vine layers plugin ([#132274](https://abacogroup.easyredmine.com/issues/132274))

## [3.0.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.5...v3.0.4) - 2024-03-01

### Fixed

- Fixed parcel descriptions supporting old parcel code retrieved by isola_npr_id (instead of isola_npr_geom_id) on avepa plugin ([#132438](https://abacogroup.easyredmine.com/issues/132438))

## [3.0.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.4...v3.0.3) - 2024-03-01

### Added

- Added new doNotAdjustDeclDates queryParam to getPlots public API to not crop declaration dates returned with a pointInTimeTo specified ([#131577](https://abacogroup.easyredmine.com/issues/131577))

### Fixed

- Fixed plot edit services propagating editing with a configured tolerance (wrong dayTo in modified with parent plot) ([#131506](https://abacogroup.easyredmine.com/issues/131506))

## [3.0.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.3...v3.0.2) - 2024-02-29

### Changed

- Reworked plot edit services propagating editing also with a configured tolerance ([#131506](https://abacogroup.easyredmine.com/issues/131506))

### Fixed

- Fixed reproportion declarations raising an error when all declarations area is 0 ([#132381](https://abacogroup.easyredmine.com/issues/132381))
- Fixed avepa and avepa vine check user proxy in business plugin ([#132005](https://abacogroup.easyredmine.com/issues/132005))

## [3.0.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.2...v3.0.1) - 2024-02-22

### Added

- Added ignorePreviousSyncs query parameter to CropPlanResources.syncCropPlan private API (CRPL|CAN_FORCE_SYNC context|function is required) ([#131502](https://abacogroup.easyredmine.com/issues/131502))

## [3.0.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.1...v3.0.0) - 2024-02-20

### Changed

- Changed getLandCoverEditability to ONLY_DECLARATIONS in status IN_VALIDATION (vinealign) on avepa vine and agea crop codes plugins

## [3.0.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v3.0.0...v2.3.7) - 2024-02-19

### Changed

- Removed AsyncResponse from all APIs

## [2.3.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.3.7...v2.3.6) - 2024-02-15

### Added

- Added reproportion declarations availability also when plot is not editable (if parameter ENABLE_DECLARATIONS_REPROPORTION_WHEN_NOT_EDITABLE = TRUE) ([#125804](https://abacogroup.easyredmine.com/issues/125804))

## [2.3.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.3.6...v2.3.5) - 2024-02-13

### Fixed

- Fixed SV03 anomalies check on agea validator plugins

## [2.3.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.3.5...v2.3.4) - 2024-02-12

### Fixed

- Removed check on declaration area > 0 (SV04) on avepa vine and agea validator plugins

## [2.3.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.3.4...v2.3.3) - 2024-02-08

### Fixed

- Fixed latitude and longitude coordinate of the point selected on the map in gis info in avepa vine layers plugin (removed from avepa layers plugin) ([#124720](https://abacogroup.easyredmine.com/issues/124720))
- Fixed gis info raising an error while no parcel selected in avepa layers plugin

## [2.3.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.3.3...v2.3.2) - 2024-02-07

### Added

- Implemented getHoldingArea and getHoldingAreaByDomainZone on avepa vine and agea plugin

### Changed

- Changed getDomainZones APIs returning the holding area of the domain zones if includeHoldingArea query parameter is true

### Fixed

- Fixed external code description including sub if present on avepa vine and agea plugin ([#130073](https://abacogroup.easyredmine.com/issues/130073))

## [2.3.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.3.2...v2.3.1) - 2024-02-02

### Fixed

- Fixed SV04 anomalies ignoring declaration with area percentage = 0 on avepa vine and agea plugin ([#129724](https://abacogroup.easyredmine.com/issues/129724))
- Fixed SV07 check edit status on LPIS on avepa vine and agea plugin ([#129835](https://abacogroup.easyredmine.com/issues/129835))

## [2.3.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.3.1...v2.3.0) - 2024-02-01

### Fixed

- Fixed restore plots propagating behaviour does not recalculating anomalies (cleared crpl_sync.reference_dt to force anomalies recalculation) ([#127376](https://abacogroup.easyredmine.com/issues/127376))

## [2.3.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.3.0...v2.2.25) - 2024-01-31

### Added

- Reworked restore plots behaviour, the new algorithm is available with parameter RESTORE_PLOTS_PROPAGATING_BEHAVIOUR = TRUE ([#127376](https://abacogroup.easyredmine.com/issues/127376))

### Fixed

- Fixed ortophoto layers order on avepa vine plugin ([#129498](https://abacogroup.easyredmine.com/issues/129498))

## [2.2.25](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.25...v2.2.24) - 2024-01-29

### Fixed

- Fixed getCropPlanTypeLockedErrorCode in external AuthPluginImpl

## [2.2.24](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.24...v2.2.23) - 2024-01-26

### Fixed

- Fixed parcels intersection does not found correct intersection updating geometry-editor to v2.4.5 ([#127543] (https://abacogroup.easyredmine.com/issues/127543))

## [2.2.23](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.23...v2.2.22) - 2024-01-26

### Added

- Added new context function CRPL|IGNORE_PARTIES_ACL and canIgnoreProxies on BusinessSchedarioDAO and AuthSchedarioDAO on agea plugin ([#128249](https://abacogroup.easyredmine.com/issues/128249))

### Changed

- Changed parcel descriptions supporting different descriptions for the same parcel code depending on pointInTime

### Fixed

- Fixed parcel descriptions (replacing old labels.parcel) on avepa plugin ([#128906](https://abacogroup.easyredmine.com/issues/128906))
- Fixed search businesses for reg users ([#129193] (https://abacogroup.easyredmine.com/issues/129193))

## [2.2.22](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.22...v2.2.21) - 2024-01-22

### Added

- Added create version after PLOT_ALIGN sync ([#127632](https://abacogroup.easyredmine.com/issues/127632))

### Fixed

- Fixed prints language ([#115578](https://abacogroup.easyredmine.com/issues/115578))

## [2.2.21](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.21...v2.2.20) - 2024-01-22

### Changed

- Changed mergePlots API removing preserveDeclarations parameter from payload, now the parameter is evaluated only server side and configured in crpl_config ([#128218](https://abacogroup.easyredmine.com/issues/128218)) ([#128489](https://abacogroup.easyredmine.com/issues/128489))

## [2.2.20](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.20...v2.2.19) - 2024-01-19

### Added

- Added Poligoni GPS and Linee GPS wms servers on avepa vine layers plugin ([#125615](https://abacogroup.easyredmine.com/issues/125615)) ([#125616](https://abacogroup.easyredmine.com/issues/125616))

### Fixed

- Added schema on AuthSchedarioDAO

## [2.2.19](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.19...v2.2.18) - 2024-01-18

### Fixed

- Fixed BusinessSchedarioDAO queries

## [2.2.18](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.18...v2.2.17) - 2024-01-18

### Fixed

- Added CAA Nazionali for agea plugin

## [2.2.17](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.17...v2.2.16) - 2024-01-17

### Fixed

- Fixed datarevoca on BusinessSchedarioDAO and AuthSchedarioDAO and add upper on username on agea plugin ([#125506](https://abacogroup.easyredmine.com/issues/125506))

## [2.2.16](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.16...v2.2.15) - 2024-01-16

### Added

- Added latitude and longitude coordinate of the point selected on the map in gis info in avepa layers plugin ([#124720](https://abacogroup.easyredmine.com/issues/124720))

### Fixed

- Fixed draw line buffer, create plot and update plot with other plots selected propagation error in PlotEditService ([#127532](https://abacogroup.easyredmine.com/issues/127532))
- Fixed recalculate anomalies does not trigger with LPIS sync in some cases ([#127595](https://abacogroup.easyredmine.com/issues/127595))
- Fixed Reproportion declaration percentage area algorithm ([#125375](https://abacogroup.easyredmine.com/issues/125375))
- Fixed SV04 anomaly on avepa vine and agea validator plugins ([#126942](https://abacogroup.easyredmine.com/issues/126942))

## [2.2.15](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.15...v2.2.14) - 2024-01-11

### Added

- Added COOP_TRENTO mandates checks on agea plugins ([#125506](https://abacogroup.easyredmine.com/issues/125506))

## [2.2.14](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.14...v2.2.13) - 2024-01-10

### Fixed

- Fixed SV08 anomaly on avepa vine and agea validator plugins

## [2.2.13](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.13...v2.2.12) - 2024-01-08

### Fixed

- Fixed get parcel land covers on avepa plugin ([#127085](https://abacogroup.easyredmine.com/issues/127085))

## [2.2.12](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.12...v2.2.11) - 2023-12-22

### Changed

- Changed date checks in avepa SyncSitiDAO using tisole_npr.data_aggiornamento_geom instead of tisole_npr.data_aggiornamento

### Fixed

- Fixed declarations editable in status IN_VALIDATION on agea and avepa vine crop codes plugin
- Fixed resume plot from crop plan first version API in PlotEditResources ([#123946](https://abacogroup.easyredmine.com/issues/123946))

## [2.2.11](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.11...v2.2.10) - 2023-12-21

### Fixed

- Fixed get parcels by parcel codes on avepa domain plugin ([#126444](https://abacogroup.easyredmine.com/issues/126444))

## [2.2.10](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.10...v2.2.9) - 2023-12-20

### Added

- Added SV08 anomaly on avepa vine and agea validator plugins ([#126581](https://abacogroup.easyredmine.com/issues/126581))

## [2.2.9](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.9...v2.2.8) - 2023-12-19

### Fixed

- Fixed parcel descriptions on avepa domain plugin

## [2.2.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.8...v2.2.7) - 2023-12-19

### Fixed

- Fixed parcel descriptions on avepa domain plugin

## [2.2.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.7...v2.2.6) - 2023-12-19

### Fixed

- Fixed parcel descriptions on avepa domain plugin

### Removed

- Removed check SV04 on stumps density % on agea and avepa vine plugins

## [2.2.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.6...v2.2.5) - 2023-12-18

### Changed

- Changed response from lpis layers and remapping crop plan response ([#126289] (https://abacogroup.easyredmine.com/issues/126289))

### Fixed

- Fixed reference date null in validator ([#126265] (https://abacogroup.easyredmine.com/issues/126265))

## [2.2.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.5...v2.2.4) - 2023-12-18

### Added

- New resume plot from crop plan first version API in PlotEditResources ([#123946](https://abacogroup.easyredmine.com/issues/123946))

### Fixed

- Fixed layerType variable name ([#126289] (https://abacogroup.easyredmine.com/issues/126289))

## [2.2.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.4...v2.2.3) - 2023-12-14

### Fixed

- Fix query as string on 410 for agea and avepa

## [2.2.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.3...v2.2.2) - 2023-12-13

### Added

- Added business cadastral parcel layer snap geometries on avepa vine and agea domain plugins ([#123942](https://abacogroup.easyredmine.com/issues/123942))

### Changed

- Changed plot declarations sorting by PermanentCropFormExternalCodeDecode.sorting ([#123943](https://abacogroup.easyredmine.com/issues/123943))
- Revised SV04 anomaly on avepa vine and agea validator plugins ([#124925](https://abacogroup.easyredmine.com/issues/124925))

## [2.2.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.2...v2.2.1) - 2023-12-11

### Changed

- Raised exception during sync updatePlot while unable to update a plot

## [2.2.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.1...v2.2.0) - 2023-12-11

### Changed

- Optimized processIntersectedParcelCodes not loading useless plot informations

## [2.2.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.2.0...v2.1.18) - 2023-12-11

### Changed

- Changed avepa plugin DAOs using tisole_npr and tisole_cond tables instead of old lpis_parcels_holding and gis_parcels
- Changed avepa plugin DAOs using tisole_npr.isola_npr_id to tisole_npr.isola_npr_geom_id

### Added

- Added metrics on DAOs

## [2.1.18](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.18...v2.1.17) - 2023-12-09

### Changed

- Improved sync process reducing loading canvas geometries

## [2.1.17](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.17...v2.1.16) - 2023-12-07

### Fixed

- Fixed getParcelsDescription not returning all parcels on avepa plugin

## [2.1.16](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.16...v2.1.15) - 2023-12-07

### Added

- Added editable configuration to crpl_perm_crop_forms_fields_cfg

### Fixed

- Fixed getParcelsDescription causing duplicateKeyException on avepa plugin

## [2.1.15](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.15...v2.1.14) - 2023-12-04

### Fixed

- Fixed ValidatorCropPlanDAO.getPlotDescription on avepa vine and agea validator plugins

## [2.1.14](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.14...v2.1.13) - 2023-12-04

### Security

- Removed VINEUSER and VINEBO (test users) from avepa plugin crpl service users

## [2.1.13](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.13...v2.1.12) - 2023-12-04

### Added

- Added SV07 anomalies calculation on avepa vine and agea validator plugins

### Changed

- Changed queries that use sv_unar_parcelle on avepa
- Changed get read only status on avepa vine and agea crop plan plugins
- Changed SitiUnar.getDayFrom on avepa vine and agea plugins with new default dates

## [2.1.12](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.12...v2.1.11) - 2023-11-21

### Fixed

- Fixed getSitiUnar on agea with cuaa param

## [2.1.11](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.11...v2.1.10) - 2023-11-21

### Changed

- Changed queries that use sv_unar_parcelle on agea

## [2.1.10](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.10...v2.1.9) - 2023-11-20

### Added

- Added parcel notes to parcel intersection data (new crpl_parcel_data database table with parcels notes and updateParcelData API) ([#119857](https://abacogroup.easyredmine.com/issues/119857))

### Fixed

- Fixed some sonar issues on CropPlanService and SyncService

## [2.1.9](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.9...v2.1.8) - 2023-11-15

### Changed

- Changed config-docker-agea.yml (updated default vinealignURL to vinealign-server)

## [2.1.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.8...v2.1.7) - 2023-11-15

### Changed

- Changed private and public resource getSubscriptions to POST ([#123678](https://abacogroup.easyredmine.com/issues/123678))

## [2.1.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.7...v2.1.6) - 2023-11-13

### Fixed

- Fixed sync anomalies recalculation considers only plots at specified sync reference date

## [2.1.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.6...v2.1.5) - 2023-11-09

### Fixed

- Fixed getDeclarationsLastModificationDate query

### Changed

- Changed AVEPA and AGEA crop codes plugin to get land uses from crop plan tables

## [2.1.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.5...v2.1.4) - 2023-11-08

### Changed

- Changed AVEPA and AGEA sync plugin date for plot align reverted to sysdate from default date (01/01/2023) and fixed get plot declarations loading all declarations instead of only declarations at a specific point in time ([#121128](https://abacogroup.easyredmine.com/issues/121128))

## [2.1.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.4...v2.1.3) - 2023-11-02

### Changed

- Changed AVEPA and AGEA sync plugin date for plot align from default date (01/01/2023) to sysdate ([#121128](https://abacogroup.easyredmine.com/issues/121128))

## [2.1.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.3...v2.1.2) - 2023-10-31

### Changed

- Changed default crop plan open date returning last sync reference date when the crop plan is read only if the DISABLE_CHANGE_DATE_WHEN_READ_ONLY config parameter is set to TRUE

## [2.1.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.2...v2.1.1) - 2023-10-31

### Added

- Added new getCropPlanDefaultOpenDate API and deprecated fixedOpenDate in getCropPlanDates APIs

### Changed

- Changed default crop plan open date calculated on server sysdate instead of pointInTime specified to the APIs

## [2.1.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.1...v2.1.0) - 2023-10-30

### Fixed

- Fixed recalcAnomalies error with no reference date

## [2.1.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.1.0...v2.0.3) - 2023-10-30

### Added

- Added version reference date to crop plan versions ([#113573](https://abacogroup.easyredmine.com/issues/113573))
- Added sync in progress type detail to crpl_plans database table and to SyncStatus API response ([#113573](https://abacogroup.easyredmine.com/issues/113573))

### Changed

- Changed AVEPA sync plugin from snap dates to continuous sync ([#113573](https://abacogroup.easyredmine.com/issues/113573))
- Changed commit message to rabbitmq adding version reference date ([#113573](https://abacogroup.easyredmine.com/issues/113573))
- Changed sync process to recalculate anomalies if necessary after every sync saving the sync reference date ([#113573](https://abacogroup.easyredmine.com/issues/113573))

## [2.0.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.0.3...v2.0.2) - 2023-10-24

### Changed

- Changed mergePlots API adding preserveDeclarations parameter (default true) to payload ([#115588](https://abacogroup.easyredmine.com/issues/115588))

## [2.0.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.0.2...v2.0.1) - 2023-10-24

### Added

- Added new cleanupCropPlan internal public API ([#119177](https://abacogroup.easyredmine.com/issues/119177))

## [2.0.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.0.1...v2.0.0) - 2023-10-23

### Added

- Added dummy parcels layer on AVEPA vinealign layers plugin ([#115647](https://abacogroup.easyredmine.com/issues/115647))

## [2.0.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v2.0.0...v1.8.1) - 2023-10-13

### Security

- Refactored code for sonarqube checks

## [1.8.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.8.1...v1.8.0) - 2023-10-10

### Fixed

- Fixed anomalies scenario bundle processor update and delete ([#114127](https://abacogroup.easyredmine.com/issues/114127))

## [1.8.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.8.0...v1.7.2) - 2023-10-09

### Fixed

- Fixed land covers compatibility in cache decodes with intercompatibility ([#97206](https://abacogroup.easyredmine.com/issues/97206))

## [1.7.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.7.2...v1.7.1) - 2023-10-06

### Added

- Add layer server config ([#113997](https://abacogroup.easyredmine.com/issues/113997))

## [1.7.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.7.1...v1.7.0) - 2023-10-06

### Added

- Add layer types ([#113997] https://abacogroup.easyredmine.com/issues/113997)
- Added Param "isCopyFromDecl" To Private Create Declaration ([#114872](https://abacogroup.easyredmine.com/issues/114872))

## [1.7.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.28...v1.7.0) - 2023-09-29

### Changed

- Changed getAdditionalLayers private API, the domainZoneId is now mandatory and it is specified always while calling lpis additional layers resources ([#113805](https://abacogroup.easyredmine.com/issues/113805))

## [1.6.28](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.27...v1.6.28) - 2023-09-29

### Fixed

- Fixed agea getSitiUnar for oracle 11

## [1.6.27](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.26...v1.6.27) - 2023-09-27

### Changed

- Supported flag to set enable spatial vector acceleration on malta domain plugin

## [1.6.26](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.25...v1.6.26) - 2023-09-22

### Removed

- Removed unnecessary CRPL_DECL_ADDIT_FIELDS.display_order column (used CRPL_LANDUSE_ADDIT_FIELDS.display_order)

## [1.6.25](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.24...v1.6.25) - 2023-09-21

### Fixed

- Fixed on CropPlanConfigDAO the method insertDeclAdditFieldConf, set the right name of column: fl_show_in_tooltip

## [1.6.24](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.23...v1.6.24) - 2023-09-20

### Fixed

- Fixed missing bind userName in getBusiness agea plugin

## [1.6.23](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.22...v1.6.23) - 2023-09-20

### Added

- Added ZVN and ZONA_MONTANA AVEPA layers cataloghi ([#113805](https://abacogroup.easyredmine.com/issues/113805))

### Changed

- Changed query for business and auth plugins agea ([#114125](https://abacogroup.easyredmine.com/issues/114125))

## [1.6.22](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.21...v1.6.22) - 2023-09-19

### Changed

- Decode su_codVarieta to '000' if code not exist in sitiunar_deco for avepa and agea vinealign ([#112606](https://abacogroup.easyredmine.com/issues/112606))

### Added

- Added fl_show_in_tooltip to the table CRPL_LANDUSE_ADDIT_FIELDS. Adapted Processor to handle it.

## [1.6.21](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.20...v1.6.21) - 2023-09-18

### Changed

- Improved standard domain plugin performances

## [1.6.20](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.19...v1.6.20) - 2023-09-15

### Fixed

- Fixed getLandUseCodesByLandCoverCode removing obsolete ignoreIntercompatibility parameter ([#113332](https://abacogroup.easyredmine.com/issues/113332))

## [1.6.19](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.18...v1.6.19) - 2023-09-15

### Changed

- Aumented to 30 minutes the CLL cache duration in standard domain plugin

## [1.6.18](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.17...v1.6.18) - 2023-09-15

### Changed

- Implemented land use and land cover class cache in standard crop codes plugin

## [1.6.17](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.16...v1.6.17) - 2023-09-15

### Changed

- Implemented CLL cache in standard domain plugin

## [1.6.16](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.15...v1.6.16) - 2023-09-15

### Fixed

- Fixed PlotEditDAO.savePlotDatas with string plot code

## [1.6.15](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.14...v1.6.15) - 2023-09-14

### Fixed

- Fixed standard crop codes and validator plugin

## [1.6.14](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.13...v1.6.14) - 2023-09-14

### Fixed

- Fixed standard crop codes plugin

## [1.6.13](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.12...v1.6.13) - 2023-09-14

### Fixed

- Fixed standard domain and crop codes plugin

## [1.6.12](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.11...v1.6.12) - 2023-09-14

### Fixed

- Fixed standard domain plugin

## [1.6.11](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.10...v1.6.11) - 2023-09-14

### Fixed

- Fixed standard domain plugin

## [1.6.10](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.9...v1.6.10) - 2023-09-14

### Changed

- Changed standard layers plugin adding lpis-server-api/wms parcels and landcovers

## [1.6.9](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.8...v1.6.9) - 2023-09-14

### Fixed

- Fixed standard domain plugin

## [1.6.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.7...v1.6.8) - 2023-09-14

### Fixed

- Fixed config-docker-external.yml

## [1.6.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.6...v1.6.7) - 2023-09-14

### Added

- Added standard domain plugin

## [1.6.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.5...v1.6.6) - 2023-09-13

### Added

- Added standard sync plugin

## [1.6.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.4...v1.6.5) - 2023-09-13

### Fixed

- Fixed standard business and auth plugin

## [1.6.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.3...v1.6.4) - 2023-09-12

### Fixed

- Fixed config-docker-external.yml

## [1.6.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.2...v1.6.3) - 2023-09-08

### Fixed

- Fixed sync PLOT_ALIGN declaration area percentage reproportion

## [1.6.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.1...v1.6.2) - 2023-09-07

### Changed

- Modified on Validator Plugin of Avepa methods for check ANOMALY: checkSV01 and checkSV02. Aligned to AGEA impl.

## [1.6.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.6.0...v1.6.1) - 2023-09-06

### Changed

- Modified Sync PLOT_ALIGN recalc Decl Area Perc (changed type of data on recalc function Area Perc)([#113092](https://abacogroup.easyredmine.com/issues/113092))

## [1.6.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.32...v1.6.0) - 2023-09-06

### Changed

- Updated plugins-support to version 1.1.2

## [1.5.32](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.31...v1.5.32) - 2023-09-06

### Changed

- Modified Sync PLOT_ALIGN recalc Decl Area Perc (changed type of data on recalc function Area Perc)([#113214](https://abacogroup.easyredmine.com/issues/113214))

## [1.5.31](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.30...v1.5.31) - 2023-09-05

### Changed

- Modified Sync PLOT_ALIGN recalc Decl Area Perc ([#113092](https://abacogroup.easyredmine.com/issues/113092))

## [1.5.30](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.29...v1.5.30) - 2023-09-05

### Deleted

- Delete flag to set enable spatial vector acceleration on db-update.yaml and fix deployment.yaml

## [1.5.29](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.28...v1.5.29) - 2023-09-05

### Added

- Added flag to set enable spatial vector acceleration on db-update.yaml and fix deployment.yaml

## [1.5.28](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.27...v1.5.28) - 2023-09-05

### Added

- Added flag to set enable spatial vector acceleration

## [1.5.27](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.26...v1.5.27) - 2023-08-22

### Changed

- Modified external description query for avepa ([#111947](https://abacogroup.easyredmine.com/issues/111947))

### Added

- Added a new Flag Mandatory to LandUseAdditionalDataField ([#111678](https://abacogroup.easyredmine.com/issues/111678))

## [1.5.26](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.25...v1.5.26) - 2023-08-07

### Fixed

- Fixed check anomaly SV01 and SV02 on AGEA ([#111065](https://abacogroup.easyredmine.com/issues/111065))

## [1.5.25](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.24...v1.5.25) - 2023-08-04

### Fixed

- Fixed Reproportion declaration percentage area algorithm ([#111065](https://abacogroup.easyredmine.com/issues/111065))

## [1.5.24](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.23...v1.5.24) - 2023-08-03

### Fixed

- Fixed check anomaly SV02 on AGEA ([#111062](https://abacogroup.easyredmine.com/issues/111062))

## [1.5.23](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.22...v1.5.23) - 2023-08-02

### Fixed

- Fixed query on countMandati for AGEA

## [1.5.22](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.21...v1.5.22) - 2023-08-02

### Fixed

- Fixed Reproportion Decl Perc Area algorithm ([#110969](https://abacogroup.easyredmine.com/issues/110969))

## [1.5.21](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.20...v1.5.21) - 2023-08-02

### Fixed

- Fixed query countMandati for office admin in agea plugin ([#110955](https://abacogroup.easyredmine.com/issues/110955))

## [1.5.20](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.19...v1.5.20) - 2023-08-01

### Changed

- Implemented AuthPluginImpl and modify business queries on agea vinealign ([#110359](https://abacogroup.easyredmine.com/issues/110359))
- Changed public getAllVersions API to return in publishing versions only if new query param includeInPublishing is set to true (default false)

## [1.5.19](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.18...v1.5.19) - 2023-08-01

### Added

- Added check before the check for functionBlockForAnomaly ([#108125](https://abacogroup.easyredmine.com/issues/108125))

## [1.5.18](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.17...v1.5.18) - 2023-07-31

### Added

- Added Lock On Public Api Pesticide ([#93062](https://abacogroup.easyredmine.com/issues/93062))
- Added new Way to calc Decl Area on Sync By reproportion it based on the new value for Sync Type PLOT_ALIGN ([#108864](https://abacogroup.easyredmine.com/issues/108864))
- Added a new CropPlan parameter: REPROPORTION_DECL_AREA_ON_SYNC_PLOT_ALIGN (Boolean, default FALSE)
- Added a new CropPlan parameter: ALLOW_DECLS_PERC_TO_ZERO (Boolean, default FALSE)

## [1.5.17](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.16...v1.5.17) - 2023-07-26

### Added

- Added Private API getFunctionsdDisabledConfig that return Config Scenario of Disabled Functions For Anomaly ([#108125](https://abacogroup.easyredmine.com/issues/108125))

## [1.5.16](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.15...v1.5.16) - 2023-07-26

### Added

- Added Public API getFunctionsdDisabledConfig that return Config Scenario of Disabled Functions For Anomaly ([#108125](https://abacogroup.easyredmine.com/issues/108125))

## [1.5.15](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.14...v1.5.15) - 2023-07-25

### Fixed

- Fixed cadastral parcels holdingPercentage for AVEPA plugin

## [1.5.14](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.13...v1.5.14) - 2023-07-25

### Fixed

- Fixed query get business on AGEA plugin

## [1.5.13](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.12...v1.5.13) - 2023-07-25

### Fixed

- Fixed get business on AGEA plugin ([#107837](https://abacogroup.easyredmine.com/issues/107837))

## [1.5.12](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.11...v1.5.12) - 2023-07-25

### Fixed

- Fixed cadastral parcels queries for AVEPA plugin reading data from siticond_all to tparticelle_cond

## [1.5.11](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.10...v1.5.11) - 2023-07-25

### Fixed

- Fixed search businesses on AGEA plugin ([#107837](https://abacogroup.easyredmine.com/issues/107837))

## [1.5.10](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.9...v1.5.10) - 2023-07-24

### Fixed

- Fixed on function checkPlotDisabledFunctionsForAnomaly

## [1.5.9](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.8...v1.5.9) - 2023-07-21

### Fixed

- Fixed import for bundle AnomScenarioDisableFuncConfig

## [1.5.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.7...v1.5.8) - 2023-07-21

### Added

- Added to the application processors the class to decode the bundle AnomScenarioDisableFuncConfigProcessor

## [1.5.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.6...v1.5.7) - 2023-07-21

### Changed

- Set abaco-jdbi version to 2.13.0 and configure SpatialVectorAcceleration on AGEA ValidatorPlugin
- Changed import for bundle AnomScenarioDisableFuncConfig to handle when anomaly presence are not specify

## [1.5.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.5...v1.5.6) - 2023-07-19

### Added

- Added a new parameter to the Object ParcelIntersection: holdingPercentage
- Added property LOCK_DECLARATIONS_FIELDS_IF_EXTERNAL ([#109663](https://abacogroup.easyredmine.com/issues/109663))
- Added property DISABLE_DELETE_DECLARATIONS_IF_EXTERNAL ([#109870](https://abacogroup.easyredmine.com/issues/109870))

### Fixed

- Fix query and set SPATIAL_VECTOR_ACCELERATION to true for check anomaly SV03 ([#109659](https://abacogroup.easyredmine.com/issues/109659))

## [1.5.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.4...v1.5.5) - 2023-07-17

### Added

- Add new Inibition function check to block a function if a specific configuration of anomalies match a configuration saved on DB ([#108125](https://abacogroup.easyredmine.com/issues/108125))
- Fix reproportion-decls: fix when reproportion goes over 100% with decimals ([#107543](https://abacogroup.easyredmine.com/issues/107543))
- Fix calc of anomaly SV03 for agea([#109659](https://abacogroup.easyredmine.com/issues/109659))

## [1.5.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.3...v1.5.4) - 2023-07-14

### Changed

- Changed new API private reproportion-decls: fix cast problem ([#107543](https://abacogroup.easyredmine.com/issues/107543))
- Changed the way check for anomaly SV01 and SV02 are done for agea plugin ([#108921](https://abacogroup.easyredmine.com/issues/108921))

## [1.5.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.2...v1.5.3) - 2023-07-07

### Changed

- Changed new API private reproportion-decls: removed round ([#107543](https://abacogroup.easyredmine.com/issues/107543))

### Added

- Add new public API for get total areas and anomalies of plots ([#92043](https://abacogroup.easyredmine.com/issues/92043))

## [1.5.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.1...v1.5.2) - 2023-07-04

### Added

- Added new library for logs tracing (tracing-utils) ([#107926](https://abacogroup.easyredmine.com/issues/107926))
- Added new API private reproportion-decls ([#107543](https://abacogroup.easyredmine.com/issues/107543))

## [1.5.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.5.0...v1.5.1) - 2023-06-27

### Changed

- Changed external code description in AGEA and AVEPA ([#107854](https://abacogroup.easyredmine.com/issues/107854))

### Fixed

- Fixed update plot operations not deleting source plot when empty after reduce updating geometry-editor to v2.4.3

## [1.5.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.4.8...v1.5.0) - 2023-06-26

### Fixed

- Fixed LPIS sync raising a plot not found exception while processing plots

## [1.4.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.4.7...v1.4.8) - 2023-06-23

### Fixed

- Fixed new createVersion internal public API setting plan as published

## [1.4.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.4.6...v1.4.7) - 2023-06-23

### Added

- Added domainZoneId to plots returned by APIs

## [1.4.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.4.5...v1.4.6) - 2023-06-22

### Fixed

- Fixed clean 0 areas during sync process ignoring changed parcels for plots with area < 0 after update

## [1.4.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.4.4...v1.4.5) - 2023-06-22

### Added

- Implemented external plugins ([#98294](https://abacogroup.easyredmine.com/issues/98294))

### Fixed

- Fixed locking SyncCropPlanDAO.updatePlotDataInternal adding QueryTimeOut(10)
- Improved nullPointerException logging in PlotEditService.processIntersectedParcelCodes

## [1.4.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.4.3...v1.4.4) - 2023-06-21

### Fixed

- Fixed query DeclarationsDAO.getDeclarations
- Fixed empty list on getPermanentCropFormExternalCodeDescription for AGEA and AVEPA vinealign plugins

## [1.4.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.4.2...v1.4.3) - 2023-06-20

### Changed

- Changed AGEA setting null if zero in permanent crop forms for DISTANZA PALI and ALTITUDINE ([#106203](https://abacogroup.easyredmine.com/issues/106203))

### Fixed

- Fixed queries (DeclarationsDAO.getDeclarations, DeclarationsDAO.getDeclarationPlotData, PesticidesDAO.getProductCodesNotInCache, PesticidesDAO.getUomCodesNotInCache, PesticidesDAO.getPesticideEntries) table access full due to missing plan id in where statements

## [1.4.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.4.1...v1.4.2) - 2023-06-20

### Fixed

- Fixed on MALTA plugin shape reading from database ([#101529](https://abacogroup.easyredmine.com/issues/101529))

## [1.4.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.4.0...v1.4.1) - 2023-06-20

### Added

- Added index on crpl_plans table to improve queries performances

### Changed

- Changed internal public API to insert plots accepting external declaration codes and returning the inserted declaration code associated to the external code
- Updated AVEPA layers cataloghi label ([#103172](https://abacogroup.easyredmine.com/issues/103172))

## [1.4.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.3.10...v1.4.0) - 2023-06-20

### Fixed

- Fixed parcel intersections assignment aligning algorithm with geometry editor canvas applying ([#105417](https://abacogroup.easyredmine.com/issues/105417))

## [1.3.10](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.3.9...v1.3.10) - 2023-06-16

### Added

- Added standard CropCodePlugin ([#98294](https://abacogroup.easyredmine.com/issues/98294))
- Added new createVersion internal public API

### Fixed

- Fixed getDeclarations in DeclarationService raising an exception while no declaration found

## [1.3.9](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.3.8...v1.3.9) - 2023-06-14

### Fixed

- Fixed plot data loading

## [1.3.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.3.7...v1.3.8) - 2023-06-14

### Fixed

- Fixed plot data loading

## [1.3.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.3.6...v1.3.7) - 2023-06-13

### Changed

- Improved performances of plot data loading ([#106113](https://abacogroup.easyredmine.com/issues/106113))

## [1.3.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.3.5...v1.3.6) - 2023-06-12

### Added

- Added excludes queryParam for getPlots and getAllPlots public APIs to exclude unnecessary data from the response ([#106113](https://abacogroup.easyredmine.com/issues/106113))

### Changed

- Updated embedded-db-queue to v1.8.0

### Fixed

- Fixed "SHP_PIANO_ASSESTAMENTO_TN" and "SHP_UPAS_TN" AVEPA layers cataloghi supporting in_campaign parameter ([#104753](https://abacogroup.easyredmine.com/issues/104753))

## [1.3.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.3.4...v1.3.5) - 2023-06-09

### Added

- Re-added layer "DOMANDE DI CONFERMA" on AVEPA layers cataloghi ([#104980](https://abacogroup.easyredmine.com/issues/104980))

## [1.3.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.3.3...v1.3.4) - 2023-06-08

### Removed

- Removed layer "DOMANDE DI CONFERMA" on AVEPA layers cataloghi ([#104980](https://abacogroup.easyredmine.com/issues/104980))

## [1.3.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.3.2...v1.3.3) - 2023-06-08

### Fixed

- Fixed locking PlotEditDAO.updatePlotDataInternal adding QueryTimeOut(10)

## [1.3.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.3.1...v1.3.2) - 2023-06-08

### Changed

- Changed PlotEditService adding retry with resolve overlaps to all edit operations

## [1.3.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.3.0...v1.3.1) - 2023-06-08

### Added

- Added layer "DOMANDE DI CONFERMA" on AVEPA layers cataloghi ([#104980](https://abacogroup.easyredmine.com/issues/104980))

## [1.3.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.2.9...v1.3.0) - 2023-06-07

### Changed

- Changed pagination of public getAllPlots API from 10 to 50

### Fixed

- Fixed blocking anomalies for plots with multiple decl with perm fields not valorized ([#105286](https://abacogroup.easyredmine.com/issues/105286))
- Fixed sso token expiration while calling external APIs (updated plugins-support to v1.1.1)

## [1.2.9](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.2.8...v1.2.9) - 2023-06-07

### Changed

- Do not start embedded queues while starting crop plan api in dev mode

### Fixed

- Fix getSumOfIslandsAreas for chek anomaly SV03 in agea

## [1.2.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.2.7...v1.2.8) - 2023-06-06

### Changed

- Changed sync queue timeout from 12 hours to 3 days
- Updated embedded-db-queue to v1.7.0 to log all stack trace

## [1.2.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.2.6...v1.2.7) - 2023-06-06

### Fixed

- Fixed getDomainZonesMaxRows and getDomainZonesInfinite with version specified and no plots found ([#105316](https://abacogroup.easyredmine.com/issues/105316))
- Fixed config-docker-iacs.yml

## [1.2.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.2.5...v1.2.6) - 2023-06-06

### Changed

- Changed AVEPA sync process using optimized algorithm only for a list of configured businesses

## [1.2.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.2.4...v1.2.5) - 2023-06-01

### Added

- Added srs filter on get lpis layers for AGEA ([#104731](https://abacogroup.easyredmine.com/issues/104731))

## [1.2.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.2.3...v1.2.4) - 2023-06-01

### Changed

- Optimized AVEPA sync process checking equals NPR with different parcel code

## [1.2.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.2.2...v1.2.3) - 2023-06-01

### Fixed

- Fixed config-docker-avepa.yml

## [1.2.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.2.1...v1.2.2) - 2023-06-01

### Changed

- Optimized AVEPA sync process checking equals NPR with different parcel code

## [1.2.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.2.0...v1.2.1) - 2023-06-01

### Changed

- Optimized AVEPA sync process checking equals NPR with different parcel code

## [1.2.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.1.12...v1.2.0) - 2023-06-01

### Changed

- Changed on MALTA plugin shape reading from database and added test  ([#101529](https://abacogroup.easyredmine.com/issues/101529))
- Reworked AVEPA sync process: now it works only for 2023 year if NPR are modified

## [1.1.12](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.1.11...v1.1.12) - 2023-05-31

### Changed

- Changed Handler of Exception on Crop Plan Sync: now the records of the failed sync on equ_jobs remain with the flag 9 and the exception
- Changed AVEPA validator rules for NPR areas ([#103855](https://abacogroup.easyredmine.com/issues/103855))

### Fixed

- Fixed foregroundLevel to AVEPA additional layers

## [1.1.11](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.1.10...v1.1.11) - 2023-05-30

### Fixed

- Fixed permanent crop form equals check for merge declarations excluding externalDescription
- Fixed foregroundLevel to AVEPA additional layers for AGEA wmts

### Removed

- Removed log info for debug purposes ([#104621](https://abacogroup.easyredmine.com/issues/104621))

## [1.1.10](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.1.9...v1.1.10) - 2023-05-30

### Added

- Added log info for debug purposes ([#104621](https://abacogroup.easyredmine.com/issues/104621))

## [1.1.9](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.1.8...v1.1.9) - 2023-05-29

### Fixed

- Fixed domain zones APIs returning correct domain zones for versioned plans ([#104547](https://abacogroup.easyredmine.com/issues/104547))

## [1.1.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.1.7...v1.1.8) - 2023-05-26

### Fixed

- Fixed AVEPA errorCode for locked and managed by other op businesses

## [1.1.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.1.6...v1.1.7) - 2023-05-26

### Added

- Added foregroundLevel to additional layers
- Added locked and lockedErrorCode attribute to crop plan ([#104479](https://abacogroup.easyredmine.com/issues/104479))

### Changed

- Changed AVEPA getCropPlanTypeAccessLevel treating locked and managed by other op businesses as read only ([#104479](https://abacogroup.easyredmine.com/issues/104479))

## [1.1.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.1.5...v1.1.6) - 2023-05-26

### Fixed

- Fixed getGroupedCropPlanAnomalies API not working on postgreSQL

## [1.1.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.1.4...v1.1.5) - 2023-05-25

### Fixed

- Fixed not used cropPlanPayload during insert crop plan

## [1.1.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.1.3...v1.1.4) - 2023-05-25

### Fixed

- Fixed flNotManaged during insert crop plan

## [1.1.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.1.2...v1.1.3) - 2023-05-25

### Fixed

- Fixed AVEPA get domain zones MBR exception raised in some cases ([#103231](https://abacogroup.easyredmine.com/issues/103231))
- Fixed snap geometries on AVEPA layer cataloghi not loaded for some councils

## [1.1.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.1.1...v1.1.2) - 2023-05-24

### Fixed

- Fixed snap geometries on AVEPA layer cataloghi ALTITUDINE1200RECT ([#101154](https://abacogroup.easyredmine.com/issues/101154))

## [1.1.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.1.0...v1.1.1) - 2023-05-24

### Added

- Added new AVEPA layer cataloghi ALTITUDINE1200RECT ([#101154](https://abacogroup.easyredmine.com/issues/101154))

## [1.1.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.17...v1.1.0) - 2023-05-24

### Added

- Added anomaliesErrorCode filter to public getDeclarations API

### Changed

- Changed AVEPA urls for AGEA wmts ([#100854](https://abacogroup.easyredmine.com/issues/100854))
- Improved AVEPA sync do not consider some no more holded npr

## [1.0.17](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.16...v1.0.17) - 2023-05-22

### Fixed

- Fixed sync creating plots with area < 1sqm while updating plots

## [1.0.16](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.15...v1.0.16) - 2023-05-22

### Fixed

- Fixed AVEPA get domain zones MBR exception raised in some cases retrying without sdo_aggr_mbr function

## [1.0.15](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.14...v1.0.15) - 2023-05-22

### Added

- Added new AVEPA layer cataloghi RPPG2023 ([#102925](https://abacogroup.easyredmine.com/issues/102925))

### Changed

- Updated abaco-jdbi library to v2.12.1

## [1.0.14](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.13...v1.0.14) - 2023-05-18

### Fixed

- Fixed AVEPA sync do not consider some no more holded npr

## [1.0.13](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.12...v1.0.13) - 2023-05-18

### Fixed

- Fixed AVEPA sync do not consider some no more holded npr

## [1.0.12](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.11...v1.0.12) - 2023-05-18

### Fixed

- Fixed sync error while updating plots

## [1.0.11](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.10...v1.0.11) - 2023-05-18

### Fixed

- Fixed AVEPA sync do not consider some no more holded npr

## [1.0.10](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.9...v1.0.10) - 2023-05-18

- Fixed restorePlotsDefault API ([#102844](https://abacogroup.easyredmine.com/issues/102844))

## [1.0.9](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.8...v1.0.9) - 2023-05-17

### Fixed

- Fixed getGroupedCropPlanAnomalies API ([#103532](https://abacogroup.easyredmine.com/issues/103532))

## [1.0.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.7...v1.0.8) - 2023-05-17

### Fixed

- Fixed AVEPA sync do not consider some no more existing npr

## [1.0.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.6...v1.0.7) - 2023-05-16

### Added

- Added new restorePlotsDefault API ([#102844](https://abacogroup.easyredmine.com/issues/102844))

### Fixed

- Fixed copyDeclarationsFromPreviousYear adding correct try catch for LandUseCodeNotFoundException ([#103197](https://abacogroup.easyredmine.com/issues/103197))

## [1.0.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.5...v1.0.6) - 2023-05-10

### Added

- Added new getPlanHasDeclarationsForLandUse public API ([#101673](https://abacogroup.easyredmine.com/issues/101673))

### Fixed

- Fixed AVEPA externalDescription for PermanentCropForm ([#101454](https://abacogroup.easyredmine.com/issues/101454))

### Changed

- Moved lpis additional layers response to crop-plan-sdk
- Resolved params url placeholders on AGEA vinealign layer plugin
- Changed getGroupedCropPlanAnomalies API adding domain zones list to anomalies

## [1.0.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.4...v1.0.5) - 2023-05-08

### Changed

- Changed internal handling thread pool management for Malta validator

## [1.0.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.3...v1.0.4) - 2023-05-08

### Changed

- Changed internal handling thread pool management for Avepa validator

## [1.0.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.2...v1.0.3) - 2023-05-05

### Changed

- Changed internal public APIs accepting domainZoneId instead of domainZoneCode

### Fixed

- Fixed AVEPA npr description for no more existing npr

## [1.0.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.1...v1.0.2) - 2023-05-04

### Fixed

- Fixed AVEPA sync do not consider some no more existing npr

## [1.0.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v1.0.0...v1.0.1) - 2023-05-04

### Changed

- Improved AVEPA validation check API calls

## [1.0.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.9.3...v1.0.0) - 2023-05-03

### Changed

- Changed EditPlotPreviewResult returning coveredByInserted codes list for insert operations and changed added list from geometries list to PlotPreview list
- Changed EditPlotResult returning coveredByInserted codes list for insert operations ([#100792](https://abacogroup.easyredmine.com/issues/100792))
- Updated geometry-editor to v2.3.8

### Fixed

- Fixed AVEPA validation check anomalies fail for exception without rollback transactions

## [0.9.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.9.2...v0.9.3) - 2023-05-03

### Added

- Added externalDescription to PermanentCropForm ([#101454](https://abacogroup.easyredmine.com/issues/101454))

### Fixed

- Fixed path of internal public API to insert plots on crop plans marked as not managed ([#101044](https://abacogroup.easyredmine.com/issues/101044))

## [0.9.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.9.1...v0.9.2) - 2023-04-27

### Added

- Added new query parameter autoLock to public update declaration API
- Added flNotManaged on crop plans; crop plans marked as not managed are always read only
- Added new internal public API to insert plots on crop plans marked as not managed ([#101044](https://abacogroup.easyredmine.com/issues/101044))
- Added line buffer position parameter (CENTER|RIGHT|LEFT) to draw line buffer API for FREE_DRAW behaviour ([#100792](https://abacogroup.easyredmine.com/issues/100792))
- Added AVEPA anomalies check on declarations madatory fields ([#100135](https://abacogroup.easyredmine.com/issues/100135))

### Changed

- Refactored shared models moved to crop-plan-sdk

## [0.9.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.9.0...v0.9.1) - 2023-04-21

### Added

- Added new query parameter ignoreAdditionalFieldsCheck to public update declaration API

## [0.9.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.8.10...v0.9.0) - 2023-04-20

### Changed

- Changed swap land uses API supporting now source point in time for land uses to be changed ([#99935](https://abacogroup.easyredmine.com/issues/99935))
- Improved check read/write/delete performances
- Changed MALTA parcels description adding csp in addition to the previous description  ([#100165](https://abacogroup.easyredmine.com/issues/100165))
- Changed AVEPA parcelCode replacing section code with council code ([#101111](https://abacogroup.easyredmine.com/issues/101111))

### Fixed

- Fixed version management for all tables with FL_VERSIONED
- Fixed transaction handling for pesticides, pests and declaration additional fields
- Fixed sync procedure do not create some plots due to overlaps issues ([#99613](https://abacogroup.easyredmine.com/issues/99613))

## [0.8.10](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.8.9...v0.8.10) - 2023-04-18

### Fixed

- Fixed AVEPA sync do not consider some no more existing npr ([#100213](https://abacogroup.easyredmine.com/issues/100213))

## [0.8.9](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.8.8...v0.8.9) - 2023-04-17

### Added

- Added new deleteDeclarations API ([#93463](https://abacogroup.easyredmine.com/issues/93463))

### Fixed

- Fixed sync procedure to evaluate first bigger or smaller parcels according to canvas preprocess configuration ([#97463](https://abacogroup.easyredmine.com/issues/97463))

## [0.8.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.8.7...v0.8.8) - 2023-04-14

### Fixed

- Fixed sync procedure do not create some plots due to overlaps issues ([#99613](https://abacogroup.easyredmine.com/issues/99613))

## [0.8.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.8.6...v0.8.7) - 2023-04-14

### Fixed

- Fixed AVEPA sync do not consider some no more holded npr ([#100631](https://abacogroup.easyredmine.com/issues/100631))

## [0.8.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.8.5...v0.8.6) - 2023-04-14

### Fixed

- Fixed AlignmentStatus for AGEA VINEALIGN and AVEPA VINEALIGN

## [0.8.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.8.4...v0.8.5) - 2023-04-13

### Fixed

- Fixed AlignmentStatus of AGEA VINEALIGN

## [0.8.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.8.3...v0.8.4) - 2023-04-13

### Fixed

- Fixed extraction query of permanent crop forms of crop plan api

## [0.8.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.8.2...v0.8.3) - 2023-04-13

### Fixed

- Fixed land use class code check on fillLandUseClasses

## [0.8.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.8.1...v0.8.2) - 2023-04-12

### Fixed

- Fixed fillLandUseClasses ([#100003](https://abacogroup.easyredmine.com/issues/100003)

## [0.8.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.8.0...v0.8.1) - 2023-04-12

### Changed

- Added filterDeclareablePesticidesPlots query parameter to public getDeclaredPlots API, if it is set to false (default true) then plots returned are not filtered by can declare pesticide condition
- Renamed SSO2_TOKENS_AUTH_SECRET to SSO2_TKNS_AUTH_SECRET to avoid conflict on environments

### Fixed

- Fixed MALTA sync do not consider ended holding parcel if previous sync date is the day before ([#100232](https://abacogroup.easyredmine.com/issues/100232))

## [0.8.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.7.9...v0.8.0) - 2023-04-06

### Changed

- Updated embeded-db-queue to version 1.4.6 (fixed jobs stucked in execution after a deploy)

## [0.7.9](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.7.8...v0.7.9) - 2023-04-05

### Changed

- Added handling lock on crop-plan for API of delete and put of Pest and Pesticide
- Added standard behavior on external plugins and implement standard BusinessPlugin with party-registry api ([#98294](https://abacogroup.easyredmine.com/issues/98294))
- Added standard PesticidesPlugin and PestsPlugin ([#98294](https://abacogroup.easyredmine.com/issues/98294))

### Fixed

- Fixed ignorePreviousSyncs parameters for RECALC_ANOMALIES sync operation

## [0.7.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.7.7...v0.7.8) - 2023-04-03

### Fixed

- Fixed slow db select from crpl_plot_data (plotEditDAO.getPlotDatas) not using index correctly

## [0.7.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.7.6...v0.7.7) - 2023-03-31

### Fixed

- Fixed AVEPA sync do not consider changes date with year >= 9999 ([#97646](https://abacogroup.easyredmine.com/issues/97646))

## [0.7.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.7.5...v0.7.6) - 2023-03-31

### Fixed

- Fixed broken sync

## [0.7.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.7.4...v0.7.5) - 2023-03-31

### Changed

- Added index on crpl_anomalies table to improve queries performances

### Fixed

- Fixed AVEPA sync do not consider changes date with year >= 9999 ([#97646](https://abacogroup.easyredmine.com/issues/97646))

## [0.7.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.7.3...v0.7.4) - 2023-03-30

### Changed

- Changed min area after cut in cut operations to 1 sqm (updated geometry-editor to v2.3.6) ([#98594](https://abacogroup.easyredmine.com/issues/98594))

### Fixed

- Fixed AVEPA sync do not consider changes date >= 01-11-9999 ([#97646](https://abacogroup.easyredmine.com/issues/97646))

## [0.7.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.7.2...v0.7.3) - 2023-03-24

### Added

- Added new getSnapGeometries public API

### Fixed

- Fixed AlignmentStatus adding ANOMALIES_CORRECTIVE for AVEPA VINEALIGN

## Changed

- Changed for get land uses on AVEPA the class: fillLandUseClasses (Optimizaztion API timing), optimized DAO

## [0.7.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.7.1...v0.7.2) - 2023-03-24

### Fixed

- Fixed AVEPA crop plan is always creatable for user CRPL_SERVICE_USER
- Fixed internal server auth for sync

## [0.7.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.7.0...v0.7.1) - 2023-03-23

### Fixed

- Added sso2AuthSecret to sso2Client for internal server auth

## [0.7.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.17...v0.7.0) - 2023-03-23

### Changed

- Create version API now use the embedded queues (removed suspended, now it returns always a version with flag published = false and a polling is mandatory)

## [0.6.17](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.16...v0.6.17) - 2023-03-22

### Changed

- Changed error code of crop plan readable/writeable/createable exception ([#97819](https://abacogroup.easyredmine.com/issues/97819))

### Fixed

- Fixed get land uses on AVEPA (wrong land use class) ([#98581](https://abacogroup.easyredmine.com/issues/98581))

## [0.6.16](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.15...v0.6.16) - 2023-03-21

### Added

- Added auth check of scope_op of tfascicolo on AVEPA ([#98276](https://abacogroup.easyredmine.com/issues/98276))
- Added optional ignorePreviousSyncs query parameter on public sync API to force full sync ([#91732](https://abacogroup.easyredmine.com/issues/91732))

## [0.6.15](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.14...v0.6.15) - 2023-03-21

### Fixed

- Fixed PLOT_NOT_FULLY_DECLARED anomaly on AVEPA ([#98399](https://abacogroup.easyredmine.com/issues/98399))

## [0.6.14](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.13...v0.6.14) - 2023-03-21

### Fixed

- Fixed get land uses on AVEPA

## [0.6.13](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.12...v0.6.13) - 2023-03-21

### Added

- Added management of crop plan read only exception ([#97147](https://abacogroup.easyredmine.com/issues/97147))
- Added management of crop plan readable/writeable/createable exception ([#97819](https://abacogroup.easyredmine.com/issues/97819))

### Changed

- Improved get land uses performance on AVEPA ([#98201](https://abacogroup.easyredmine.com/issues/98201))

### Fixed

- Fixed PLOT_NOT_FULLY_DECLARED anomaly on AVEPA ([#98399](https://abacogroup.easyredmine.com/issues/98399))

## [0.6.12](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.11...v0.6.12) - 2023-03-17

### Added

- Added plot not fully declared blocking anomaly on AVEPA ([#98157](https://abacogroup.easyredmine.com/issues/98157))

### Fixed

- Fixed sync plot not found exception caused by wrong dates calculation for topology correction with fixed edit date ([#97563](https://abacogroup.easyredmine.com/issues/97563))

## [0.6.11](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.10...v0.6.11) - 2023-03-17

### Fixed

- Fixed anomalies calculations after sync process (removed parallel streams causing missing anomalies on plots and parcels) ([#97817](https://abacogroup.easyredmine.com/issues/97817))

## [0.6.10](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.9...v0.6.10) - 2023-03-17

### Changed

- Added missing fields on pests and pesticides

## [0.6.9](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.8...v0.6.9) - 2023-03-16

### Added

- Added AGEA additional layers from siti-farmer on AVEPA layers ([#97277](https://abacogroup.easyredmine.com/issues/97277))

### Changed

- Changed get sso2Url from config in AuthPluginImpl and BusinessPluginImpl on AVEPA

## [0.6.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.7...v0.6.8) - 2023-03-15

### Changed

- Changed sync service reading date for sync plugin data from plugin ([#97722](https://abacogroup.easyredmine.com/issues/97722))

## [0.6.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.6...v0.6.7) - 2023-03-14

### Added

- Added new pests plugin ([#96431](https://abacogroup.easyredmine.com/issues/96434)) ([#96431](https://abacogroup.easyredmine.com/issues/96434))

### Fixed

- Fixed WorkQueue sync processes

## [0.6.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.5...v0.6.6) - 2023-03-14

### Changed

- Changed AVEPA crop plan is never read only for user CRPL_SERVICE_USER

## [0.6.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.4...v0.6.5) - 2023-03-14

### Fixed

- Fixed WorkQueue sync processes

## [0.6.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.3...v0.6.4) - 2023-03-14

### Changed

- Changed sync processes from ExecutorService to WorkQueue

### Fixed

- Fixed null pointer on land cover description loading when land cover is null

## [0.6.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.2...v0.6.3) - 2023-03-13

### Changed

- Changed land use code to query param on BasePesticideResources

## [0.6.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.1...v0.6.2) - 2023-03-13

### Fixed

- Fixed read entity jackson errors on pesticides models

## [0.6.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.6.0...v0.6.1) - 2023-03-13

### Changed

- Changed publishVersion jax-rs resource in PublishVersionResult for crop-plan-external-plugin

## [0.6.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.5.12...v0.6.0) - 2023-03-13

### Fixed

- Fixed sync can loop endlessly with snap dates configured

### Changed

- Changed validation jax-rs resource in ValidatorResult for crop-plan-external-plugin

## [0.5.12](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.5.11...v0.5.12) - 2023-03-10

### Fixed

- Fixed paths on BaseCropCodesResources in crop-plan-sdk

## [0.5.11](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.5.10...v0.5.11) - 2023-03-10

### Changed

- Changed land cover code to query params in crop-plan-external-plugins

## [0.5.10](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.5.9...v0.5.10) - 2023-03-10

### Fixed

- Fixed query params lists in crop-plan-external-plugins

## [0.5.9](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.5.8...v0.5.9) - 2023-03-10

### Changed

- Renamed PublicTenantCropPlanResources.getLandUseCodesNoBusiness (removed deprecated status) and used "-1" as no business ID

## [0.5.8](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.5.7...v0.5.8) - 2023-03-10

### Fixed

- Remove ValidationDataSupport on payload

## [0.5.7](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.5.6...v0.5.7) - 2023-03-10

### Fixed

- Fixed responses with status 204 in plugins impl of crop-plan-external-plugins

### Changed

- Changed BaseLayersResources.getAdditionalLayers path (changed domainZoneId from pathParam to optional queryParam)

## [0.5.6](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.5.5...v0.5.6) - 2023-03-09

### Fixed

- Fixed Polygonal to Geometry in DomainPluginImpl of crop-plan-external-plugins

## [0.5.5](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.5.4...v0.5.5) - 2023-03-09

### Changed

- Changed config-docker-external.yml for external_url_plugin properties

## [0.5.4](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.5.3...v0.5.4) - 2023-03-09

### Fixed

- Fixed catch throwable during sync operations to remove sync in progress status

## [0.5.3](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.5.2...v0.5.3) - 2023-03-09

### Fixed

- Fixed copy declarations from previous year to manage multi-years declarations

## [0.5.2](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.5.1...v0.5.2) - 2023-03-07

### Changed

- Changed copy declarations from previous year to delete also current year permanent crops ([#96750](https://abacogroup.easyredmine.com/issues/96750))

## [0.5.1](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.5.0...v0.5.1) - 2023-03-06

### Added

- Added new forcePublish query parameter to createVersion public API to create a new version also if the crop plan does not have changes pending ([#91732](https://abacogroup.easyredmine.com/issues/91732))

## [0.5.0](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.4.37...v0.5.0) - 2023-03-03

### Changed

- Added EXTERNAL plugins and refactored plugins management

## [0.4.37](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.4.36...v0.4.37) - 2023-03-02

### Changed

- Updated geometry-editor from version 2.3.4 to version 2.3.5

### Fixed

- Fixed MALTA reading of sitisuolo.shape to tolerate wrong geometries (geometry collections) ([#95595](https://abacogroup.easyredmine.com/issues/95595))

## [0.4.36](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.4.35...v0.4.36) - 2023-03-02

### Added

- Added AVEPA anomaly for non homogeneous declarations ([#96488](https://abacogroup.easyredmine.com/issues/96488))

### Fixed

- Fixed AVEPA wrong anomaly calculation for multiple declarations
- Fixed MALTA reading of sitisuolo.shape to tolerate wrong geometries (holes in wrong polygons) ([#95595](https://abacogroup.easyredmine.com/issues/95595))

## [0.4.35](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.4.34...v0.4.35) - 2023-02-28

### Fixed

- Fixed MALTA getFutureParcelsIntersections (DomainSitiDAO): missing right parenthesis for holding end date ([#95595](https://abacogroup.easyredmine.com/issues/95595))

## [0.4.34](https://gitlab.fe.abacogroup.eu/crop-plan/crop-plan-server/-/compare/v0.4.33...v0.4.34) - 2023-02-28

### Fixed

- Fixed MALTA getFutureParcelsIntersections (DomainSitiDAO): holding end date + 1 day went wrong if year was 9999 ([#95595](https://abacogroup.easyredmine.com/issues/95595))
