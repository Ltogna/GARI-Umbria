package com.abacogroup.cropplan.plugins.aria.vinealign.dao.ntt;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Iscrizione {
	String code;
	String categoria;
	String alboElenco;
	String tipologia;
	String bloccoTipologia;
	String bloccoRivendica;
	String bloccoIdoneita;
	String attingimento;
}
