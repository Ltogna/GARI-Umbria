package com.abacogroup.cropplan.plugins.aria.vinealign.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ValidatorSumIslandsPayload {

	String geometry;
	String cuaa;

}
