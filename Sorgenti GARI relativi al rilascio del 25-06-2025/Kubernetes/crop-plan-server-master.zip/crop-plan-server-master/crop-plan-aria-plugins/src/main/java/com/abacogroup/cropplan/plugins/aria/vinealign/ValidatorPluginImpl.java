package com.abacogroup.cropplan.plugins.aria.vinealign;

import static java.util.stream.Collectors.toList;

import com.abacogroup.cropplan.plugins.aria.vinealign.dao.ValidatorCropPlanDAO;
import com.abacogroup.cropplan.plugins.aria.vinealign.models.ParcelEditStatusV1;
import com.abacogroup.cropplan.plugins.aria.vinealign.payload.ValidatorFontePayload;
import com.abacogroup.cropplan.plugins.aria.vinealign.payload.ValidatorSumIslandsPayload;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.PermanentCropForm;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormData;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormData.Fields;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormFieldValue;
import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormFieldConfig;
import com.abacogroup.cropplan.sdk.model.validation.AnomalyObjectType;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomaly;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomalyObject;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedDeclaration;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedPlot;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorData;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorOperation;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorResult;
import com.abacogroup.cropplan.sdk.spi.ValidatorPlugin;
import com.abacogroup.cropplan.sdk.spi.constants.PluginProperties;
import com.abacogroup.cropplan.sdk.support.PermanentCropFormDataFieldToCodeMapper;
import com.abacogroup.cropplan.sdk.support.ValidatorDataSupport;
import com.abacogroup.cropplan.sdk.support.ValidatorDataSupport.VDSPlot;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.stream.Collectors;
import org.apache.commons.lang3.NotImplementedException;
import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.io.WKTWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ValidatorPluginImpl implements ValidatorPlugin, InitializablePlugin {

	private static final Logger log = LoggerFactory.getLogger(ValidatorPluginImpl.class);

	private static final String JDBI_CROP_PLAN = "mainDB";
	private static final String URL_LPIS = "lpisURL";
	private static final String URL_EXTERNAL = "cropPlanPluginsBaseUrl";

	private ValidatorCropPlanDAO validatorCropPlanDAO;

	private static final String URL_ERROR_MESSAGE = "External base url is not define";

	private String lpisURL;
	private String externalURL;

	private static final String DEFAULT_DATE = "9999-01-01";
	private static final String FONTE_PARCELLA_FITTIZIA = "2";

	@Override
	public void initialize(PluginsEnvironment env) {

		var jdbiCropPlan = env.getJdbi(JDBI_CROP_PLAN);
		if (jdbiCropPlan == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_CROP_PLAN);

		validatorCropPlanDAO = jdbiCropPlan.onDemand(ValidatorCropPlanDAO.class);

		lpisURL = Optional.ofNullable(env.getProperty(URL_LPIS))
				.map(Object::toString)
				.orElseThrow(() -> new IllegalStateException("Cannot get lpisURL"));

		externalURL = String.valueOf(getExternalProperty(env, URL_EXTERNAL, URL_ERROR_MESSAGE));

	}

	@Override
	public CompletionStage<ValidatorResult> validate(RuntimeEnvironment env, ValidatorData data,
			ValidatorDataSupport support) {
		return CompletableFuture.supplyAsync(() -> {
			var result = new ValidatorResult();
			result.setMessages(new ArrayList<>());

			result.setAnomalies(calculateAnomalies(env, data, support));

			return result;
		});
	}

	@Override
	public Map<ValidationAnomalyObject, List<ValidationAnomaly>> calculateAnomalies(RuntimeEnvironment env, ValidatorData data, ValidatorDataSupport support) {
		if (support.isCalculateAtPreviousVersion()) {
			throw new NotImplementedException("Calculate anomalies with version is not supported yet.");
		}

		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();
		data.getDeclarations().forEach(decl -> {
			anomalies.put(new ValidationAnomalyObject(decl.getDeclCode(), AnomalyObjectType.DECLARATION), new ArrayList<>());
			anomalies.put(new ValidationAnomalyObject(decl.getPlotCode(), AnomalyObjectType.PLOT), new ArrayList<>());
		});
		
		data.getPlots().forEach(plot -> {
			anomalies.put(new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT), new ArrayList<>());
		});

		var plotCodes = data.getPlots()
				.stream()
				.filter(plot -> plot.getOperation() == ValidatorOperation.INSERT
						|| plot.getOperation() == ValidatorOperation.UPDATE)
				.map(ValidatorBoundedPlot::getPlotCode)
				.collect(toList());
		plotCodes.addAll(data.getDeclarations()
				.stream()
				.filter(decl -> data.getPlots().stream()
						.filter(plot -> decl.getPlotCode().equals(plot.getPlotCode()) && plot.getOperation() == ValidatorOperation.DELETE).count() == 0)
				.map(ValidatorBoundedDeclaration::getPlotCode)
				.collect(toList()));
		plotCodes = plotCodes.stream().distinct().collect(toList());

		var decls = data.getDeclarations()
				.stream()
				.filter(declaration -> declaration.getOperation() == ValidatorOperation.INSERT
						|| declaration.getOperation() == ValidatorOperation.UPDATE)
				.collect(toList());

		List<VDSPlot> plots = new ArrayList<>();
		for (var p : plotCodes) {
			var plot = support.getPlot(p, LocalDate.parse(DEFAULT_DATE), LocalDate.parse(DEFAULT_DATE));
			if (plot == null) {
				log.error("*** ERROR PLOT NOT FOUND: " + p);
				throw new IllegalStateException("The plot " + p + " was not found");
			}
			plots.add(plot);
		}

		if (!plots.isEmpty()) {
			var tol = support.getPerimeterMultiplierAreaTolerance();
			checkSV01(anomalies, plots, tol);
			checkSV02(anomalies, plots, tol);
			checkSV03(anomalies, env, plots, data.getBusinessId());
			checkSV05(anomalies, plots, support);
			checkSV07(anomalies, env, plots, data.getCropPlanId());
			checkSV08(anomalies, env, plots, data.getCropPlanId());
		}

		if (!decls.isEmpty()) {
			checkSV04(anomalies, env, decls, support, data.getReferenceDt());
		}

		return anomalies;
	}

	protected void checkSV01(Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, List<VDSPlot> plots, Double tol) {
		plots.forEach(plot -> {
			ValidationAnomalyObject vao = new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT);
			ValidationAnomaly validationAnomaly = new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, "SV01", null, true);
			if(checkOnPerc(tol)) {
				Double limitMax = getDeclarationAreaPercLimitMax();
				Double declarationAreaPercTotal = extractDeclarationAreaPercTotal(plot);
				if (declarationAreaPercTotal > limitMax)
					anomalies.get(vao).add(validationAnomaly);
			} else {
				Double limitMax = getDeclarationAreaSqmLimitMax(tol, plot);
				Double declarationAreaSqmTotal = extractDeclarationAreaSqmTotal(plot);
				if (declarationAreaSqmTotal > limitMax)
					anomalies.get(vao).add(validationAnomaly);
			}
		});
	}
	
	protected void checkSV02(Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, List<VDSPlot> plots, Double tol) {
		plots.forEach(plot -> {
			ValidationAnomalyObject vao = new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT);
			ValidationAnomaly validationAnomaly = new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, "SV02", null, true);
			if(checkOnPerc(tol)) {
				Double limitMin = getDeclarationAreaPercLimitMin();
				Double declarationAreaPercTotal = extractDeclarationAreaPercTotal(plot);
				if (declarationAreaPercTotal < limitMin)
					anomalies.get(vao).add(validationAnomaly);
			}else {
				Double convertedMin = getDeclarationAreaSqmLimitMin(tol, plot);
				Double declarationAreaSqmTotal = extractDeclarationAreaSqmTotal(plot);
				if (declarationAreaSqmTotal < convertedMin)
					anomalies.get(vao).add(validationAnomaly);
			}
		});
	}
	
	/**
	 * @param tol
	 * @return
	 */
	private boolean checkOnPerc(Double tol) {
		return tol==0.0;
	}

	/**
	 * @param tol
	 * @param plot
	 * @return
	 */
	private double getDeclarationAreaSqmLimitMin(Double tol, VDSPlot plot) {
		return plot.getAreaSqm() - plot.getGeom().getLength() * tol;
	}

	/**
	 * @return
	 */
	private double getDeclarationAreaPercLimitMin() {
		return getDeclarationAreaPercLimit();
	}

	/**
	 * @param plot
	 * @return
	 */
	private Double extractDeclarationAreaPercTotal(VDSPlot plot) {
		BigDecimal declarationAreaPercTotal = new BigDecimal(0).setScale(8, RoundingMode.HALF_UP);
		for (var declaration : plot.getDecls())
			declarationAreaPercTotal = declarationAreaPercTotal.add(BigDecimal.valueOf(declaration.getAreaPerc()).setScale(8, RoundingMode.HALF_UP));
		return declarationAreaPercTotal.setScale(2, RoundingMode.HALF_UP).doubleValue();
	}

	/**
	 * @return
	 */
	private double getDeclarationAreaPercLimitMax() {
		return getDeclarationAreaPercLimit();
	}

	/**
	 * @return
	 */
	private double getDeclarationAreaPercLimit() {
		return 100.0;
	}

	/**
	 * @param tol
	 * @param plot
	 * @return
	 */
	private double getDeclarationAreaSqmLimitMax(Double tol, VDSPlot plot) {
		return plot.getAreaSqm() + plot.getGeom().getLength() * tol;
	}

	/**
	 * @param plot
	 * @return
	 */
	private Double extractDeclarationAreaSqmTotal(VDSPlot plot) {
		Double declarationAreaSqmTotal = 0.0;
		for (var declaration : plot.getDecls())
			declarationAreaSqmTotal += declaration.getAreaPerc() * plot.getAreaSqm() * 0.01;
		return declarationAreaSqmTotal;
	}
	
	private void checkSV03(Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, RuntimeEnvironment env, List<VDSPlot> plots, String businessId) {

		//Preparing common parameters for REST API on external connector for sumOfIslandsArea
		Map<String, Object> pathVariables = Map.of(
				"tenant", env.getTenantId()
		);
		String api = "{tenant}/api-priv/v1/validator/external/sumIslands";
		plots.forEach(plot -> {
			Long sumOfIslandsAreas = null;

			WKTWriter wktWriter = new WKTWriter();
			String wktString = wktWriter.write(plot.getGeom());

			ValidatorSumIslandsPayload payload = new ValidatorSumIslandsPayload(wktString, businessId);

			var target = env.getAuthenticatedWebTarget(externalURL)
					.path(api)
					.resolveTemplates(pathVariables);
			Entity<?> entity = Entity.json(payload);
			try (var response = target.request(MediaType.APPLICATION_JSON).method("POST", entity)) {
				if (response.getStatus() != 200) {
					throw new IllegalStateException("Unexpected response status: " + response.getStatus());
				}
				sumOfIslandsAreas = response.readEntity(new GenericType<Long>() {});
			}

			if (sumOfIslandsAreas == null || sumOfIslandsAreas < (plot.getAreaSqm() * 0.95)) {
				ValidationAnomalyObject vao = new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT);
				ValidationAnomaly validationAnomaly = new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, "SV03", null, true);
				anomalies.get(vao).add(validationAnomaly);
			}
		});
	}

	protected void checkSV04(Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, RuntimeEnvironment env, List<ValidatorBoundedDeclaration> declarations,
			ValidatorDataSupport support, LocalDate referenceDt) {
		for (ValidatorBoundedDeclaration declaration : declarations) {
			if (declaration.getAreaPerc() > 0) {
				Boolean permanentCropFormsValidity = this.checkPermanentCropFormsValidity(env, declaration, support, referenceDt);
				if (!permanentCropFormsValidity) {
					ValidationAnomalyObject vao = new ValidationAnomalyObject(declaration.getDeclCode(), AnomalyObjectType.DECLARATION);
					ValidationAnomaly validationAnomaly = new ValidationAnomaly(declaration.getDeclCode(), AnomalyObjectType.DECLARATION, "SV04", null, true);
					anomalies.get(vao).add(validationAnomaly);
				}
			}
		}
	}

	private Boolean checkPermanentCropFormsValidity(RuntimeEnvironment env, ValidatorBoundedDeclaration declaration,
			ValidatorDataSupport support, LocalDate referenceDt) {

		List<PermanentCropFormFieldValue> permanentCropFormFieldsValues = support.getPermanentCropFormFieldsValues("VINEYARD_FORM");
		Map<String, List<String>> permanentCropFormFieldsLookupsMap = permanentCropFormFieldsValues.stream()
				.collect(Collectors.groupingBy(PermanentCropFormFieldValue::getFieldCode,
						Collectors.mapping(PermanentCropFormFieldValue::getFieldValue, toList())));

		List<PermanentCropFormFieldConfig> permanentCropFormsFieldsConfig = validatorCropPlanDAO.getPermanentCropFormsFieldsConfig(
				env.getTenantId(), "VINEYARD_FORM", AbsoluteDate.of(referenceDt));// TODO move in support?
		Map<String, Boolean> permanentCropFormsFieldsMandatoryMap = permanentCropFormsFieldsConfig.stream()
				.collect(Collectors.groupingBy(PermanentCropFormFieldConfig::getFieldCode,
						Collectors.mapping(PermanentCropFormFieldConfig::isFlMandatory, Collectors.reducing(false, (b1, b2) -> b1 || b2))));

		// decl validation
		if (null == declaration.getFromDate()
				|| valueNotBetweenInclusive(declaration.getFromDate().getYear(), 1900, validatorCropPlanDAO.getCurrentTimestamp().getYear())) {
			log.debug("'declaration.fromDate' has not valid value {}", declaration.getFromDate());
			return false;
		}
		if (null == declaration.getFromDatePrecision()
				|| !List.of("YM", "YMD").contains(StringUtils.upperCase(declaration.getFromDatePrecision()))) {
			log.debug("'declaration.fromDatePrecision' has not valid value {}", declaration.getFromDatePrecision());
			return false;
		}
		if(StringUtils.isBlank(declaration.getLanduseCode())
				|| !permanentCropFormFieldsLookupsMap.get("VARIETY_CODE").contains(declaration.getLanduseCode())) {
			log.debug("'declaration.landuseCode' has not valid value {}", declaration.getLanduseCode());
			return false;
		}

		List<PermanentCropForm> permanentCropFormsLinkedToDeclaration = support
				.getPermanentCropForms(declaration.getDeclCode(), declaration.getPlotCode());

		PermanentCropFormDataFieldToCodeMapper fieldToCodeMapper = new PermanentCropFormDataFieldToCodeMapper();
		for (PermanentCropForm cpf : permanentCropFormsLinkedToDeclaration) {
			var cpfd = cpf.getPermanentCropFormData();

			if (!checkFieldMandatoryAndLookupValues(cpfd, fieldToCodeMapper,
					permanentCropFormsFieldsMandatoryMap, permanentCropFormFieldsLookupsMap, Set.of("VARIETY_CODE", "AREA_SQM"))) {
				return false;
			}

			if (hasDecimals(cpfd.getDistanceBetweenRowsCm())
					|| valueNotBetweenInclusive(cpfd.getDistanceBetweenRowsCm(), 50, 1000)) {
				log.debug("'{}' has not valid value {}", Fields.distanceBetweenRowsCm, cpfd.getDistanceBetweenRowsCm());
				return false;
			}
			if (hasDecimals(cpfd.getDistanceOnTheRowCm())
					|| valueNotBetweenInclusive(cpfd.getDistanceOnTheRowCm(), 50, 1000)) {
				log.debug("'{}' has not valid value {}", Fields.distanceOnTheRowCm, cpfd.getDistanceOnTheRowCm());
				return false;
			}
			if (hasDecimals(cpfd.getStumpsNumber())
					|| valueNotGreaterThan(cpfd.getStumpsNumber(), 0)) {
				log.debug("'{}' has not valid value {}", Fields.stumpsNumber, cpfd.getStumpsNumber());
				return false;
			}
			if (hasDecimals(cpfd.getFailuresPerc())
					|| valueNotBetweenInclusive(cpfd.getFailuresPerc(), 0, 100)) {
				log.debug("'{}' has not valid value {}", Fields.failuresPerc, cpfd.getFailuresPerc());
				return false;
			}
			if (hasDecimals(cpfd.getSoilLayeringPerc())
					|| valueNotBetweenInclusive(cpfd.getSoilLayeringPerc(), 0, 100)) {
				log.debug("'{}' has not valid value {}", Fields.soilLayeringPerc, cpfd.getSoilLayeringPerc());
				return false;
			}
			if (hasDecimals(cpfd.getAltitudeAboveSeaLevel())
					|| valueNotBetweenInclusive(cpfd.getAltitudeAboveSeaLevel(), 0, 3000)) {
				log.debug("'{}' has not valid value {}", Fields.altitudeAboveSeaLevel, cpfd.getAltitudeAboveSeaLevel());
				return false;
			}
			if (valueNotBetweenInclusive(cpfd.getPolesDistanceCm(), 50, 1000)) {
				log.debug("'{}' has not valid value {}", Fields.polesDistanceCm, cpfd.getPolesDistanceCm());
				return false;
			}

		}
		return true;
	}

	private boolean hasDecimals(Number number) {
		if (null == number) {
			return false;
		}

		double doubleValue = number.doubleValue();
		long intValue = number.longValue();
		return doubleValue != intValue;
	}

	private boolean valueNotBetweenInclusive(Number value, Number min, Number max) {
		return null != value &&
				(value.doubleValue() < min.doubleValue() || value.doubleValue() > max.doubleValue());
	}

	private boolean valueNotGreaterThan(Number value, Number min) {
		return null != value && value.doubleValue() <= min.doubleValue();
	}

	private boolean checkFieldMandatoryAndLookupValues(PermanentCropFormData cpfd, PermanentCropFormDataFieldToCodeMapper fieldToCodeMapper,
			Map<String, Boolean> permanentCropFormsFieldsMandatoryMap, Map<String, List<String>> permanentCropFormFieldsLookupsMap, Set<String> excludeFields) {
		for (Field field : cpfd.getClass().getDeclaredFields()) {
			String fieldCode = fieldToCodeMapper.getCode(field.getName());
			if (null != fieldCode && !excludeFields.contains(fieldCode)) {
				field.setAccessible(true);
				try {
					Object value = field.get(cpfd);
					if ((null == value || StringUtils.isBlank(value.toString()))
							&& Boolean.TRUE.equals(permanentCropFormsFieldsMandatoryMap.get(fieldCode))) {
						log.debug("'{}' failed mandatory check", field.getName());
						return false;
					}
					if (null != value) {
						List<String> expectedValues = permanentCropFormFieldsLookupsMap.get(fieldCode);
						if (null != expectedValues && !expectedValues.contains(value.toString())) {
							log.debug("'{}' failed lookup check. found value: '{}', expected one of: {}", field.getName(), value, expectedValues);
							return false;
						}
					}
				} catch (IllegalAccessException e) {
					throw new IllegalStateException("checkFieldMandatoryAndLookupValues failed");
				}
			}
		}
		return true;
	}
	
	private void checkSV05(Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, List<VDSPlot> plots, ValidatorDataSupport support) {
		plots.forEach(plot -> {
			ValidationAnomalyObject vao = new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT);
			ValidationAnomaly validationAnomaly = checkSV05Atomically(plot, support);
			if (validationAnomaly != null)
				anomalies.get(vao).add(validationAnomaly);
		});
	}

	private ValidationAnomaly checkSV05Atomically(VDSPlot plot, ValidatorDataSupport support) {
		if (plot.getDecls().isEmpty())
			return new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, "SV05", null, false);
		for (var decl : plot.getDecls())
			if (!support.getPermanentCropForms(decl.getDeclCode(), decl.getPlotCode()).isEmpty())
				return null;
		return new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, "SV05", null, false);
	}
	
	// check SV07 - parcelle fittizie
	protected void checkSV07(Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, RuntimeEnvironment env, List<VDSPlot> plots, Long planId) {
		plots.forEach(plot -> {
			ValidationAnomalyObject vao = new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT);
			ValidationAnomaly validationAnomaly = checkSV07Atomically(env, plot, planId);
			if (validationAnomaly != null)
				anomalies.get(vao).add(validationAnomaly);
		});
	}

	private ValidationAnomaly checkSV07Atomically(RuntimeEnvironment env, VDSPlot plot, Long planId) {
		String description = validatorCropPlanDAO.getPlotDescription(plot.getPlotCode(), planId);
		if (description != null) {
			String[] pn = description.split("-");
			if (pn.length == 4 && "SV".equals(pn[0])) {

				//Preparing common parameters for REST API on external connector for fonte
				Map<String, Object> pathVariables = Map.of(
						"tenant", env.getTenantId()
				);
				String api = "{tenant}/api-priv/v1/validator/external/getFonte";
				ValidatorFontePayload payload = new ValidatorFontePayload(pn[1], pn[2], pn[3]);
				String fonte = null;

				var target = env.getAuthenticatedWebTarget(externalURL)
						.path(api)
						.resolveTemplates(pathVariables);
				Entity<?> entity = Entity.json(payload);
				try (var response = target.request(MediaType.APPLICATION_JSON).method("POST", entity)) {
					if (response.getStatus() != 200) {
						throw new IllegalStateException("Unexpected response status: " + response.getStatus());
					}
					fonte = response.readEntity(new GenericType<String>() {});
				}

				if (FONTE_PARCELLA_FITTIZIA.equals(fonte)) {
					ParcelEditStatusV1 parcelEditStatus = getParcelEditStatus(env, pn);
					if (null == parcelEditStatus || !parcelEditStatus.getLastUpdate().isAfter(parcelEditStatus.getCreationDate())) {
						return new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, "SV07", null, false);
					}
				}
			}
		}
		return null;
	}
	
	// check SV08 - parcelle condivise
	protected void checkSV08(Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, RuntimeEnvironment env, List<VDSPlot> plots, Long planId) {
		plots.forEach(plot -> {
			ValidationAnomalyObject vao = new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT);
			ValidationAnomaly validationAnomaly = checkSV08Atomically(env, plot, planId);
			if (validationAnomaly != null)
				anomalies.get(vao).add(validationAnomaly);
		});
	}

	private ValidationAnomaly checkSV08Atomically(RuntimeEnvironment env, VDSPlot plot, Long planId) {
		String description = validatorCropPlanDAO.getPlotDescription(plot.getPlotCode(), planId);
		if (description != null) {
			String[] pn = description.split("-");
			if (pn.length == 4 && "SV".equals(pn[0]) && validatorCropPlanDAO.getParcelInOtherCropPlansCount(planId, description, env.getTenantId()) > 0)
				return new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, "SV08", null, true);
		}
		return null;
	}

	private ParcelEditStatusV1 getParcelEditStatus(RuntimeEnvironment env, String[] pn) {
		String api = "{tenant}/public/v1/lpis/sectors/{sector_code}/blocks/{blockCode}/parcels/{parcelCode}/edit-status";
		Map<String, Object> pathVariables = Map.of(
				"tenant", env.getTenantId(),
				"sector_code", pn[1],
				"blockCode", pn[2],
				"parcelCode", pn[3]
		);

		ParcelEditStatusV1 parcelEditStatus;
		try {
			parcelEditStatus = env.getAuthenticatedWebTarget(lpisURL)
					.path(api)
					.resolveTemplates(pathVariables)
					.request(MediaType.APPLICATION_JSON_TYPE)
					.get(new GenericType<>(){});
		} catch (NotFoundException nfe) {
			parcelEditStatus = null;
		}
		return parcelEditStatus;
	}

	@Override
	public boolean ignoreBlockingAnomalies(RuntimeEnvironment env) {
		return true;
	}

	@Override
	public String getCropPlanType() {
		return "VINEALIGN";
	}

	private Object getExternalProperty(PluginsEnvironment env, String propertyToSearch, String errorMessage) {
		return getExternalProperty(getExternalProperties(env), propertyToSearch, errorMessage);
	}

	private Object getExternalProperty(Map<String, Object> externalProperties, String propertyToSearch, String errorMessage) {
		if (externalProperties == null || !externalProperties.containsKey(propertyToSearch)) {
			throw new IllegalStateException(errorMessage);
		}

		return externalProperties.get(propertyToSearch);
	}

	private Map<String, Object> getExternalProperties(PluginsEnvironment env) {
		Map<String, Object> externalProperties = null;
		if (env.getProperty(PluginProperties.EXTERNAL_PLUGINS_PROPERTIES_PROPERTY_NAME) != null) {
			ObjectMapper mapper = new ObjectMapper();
			externalProperties = mapper.convertValue(env.getProperty(PluginProperties.EXTERNAL_PLUGINS_PROPERTIES_PROPERTY_NAME),
					new TypeReference<Map<String, Object>>() {
					});
		}

		return externalProperties;
	}

}
