package com.abacogroup.cropplan.plugins.aria.vinealign.models;

public enum AlignmentStatus 
{
	TO_DO,
	IN_PROGRESS,
	GRAPHIC_VALIDATION,
	GRAPHIC_VALIDATION_COMPLETED,
	REVISION_REJECTED,
	ANOMALIES_CORRECTIVE,
	IN_VALIDATION,
	PROTOCOLLING,
	COMPLETED
}
