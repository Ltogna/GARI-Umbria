package com.abacogroup.cropplan.plugins.aria.vinealign;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.cropplan.plugins.aria.vinealign.models.AlignmentStatus;
import com.abacogroup.cropplan.plugins.aria.vinealign.models.VinealignStatusResult;
import com.abacogroup.cropplan.sdk.model.CropPlanConfigData;
import com.abacogroup.cropplan.sdk.model.CropPlanVersion;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormExternalCodeDecode;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormSubscription;
import com.abacogroup.cropplan.sdk.model.PublishVersionResult;
import com.abacogroup.cropplan.sdk.payload.cropplan.GetPermanentCropFormExternalCodeDescriptionPayload;
import com.abacogroup.cropplan.sdk.spi.CropPlanPlugin;
import com.abacogroup.cropplan.sdk.spi.constants.PluginProperties;
import com.abacogroup.dropwizard.auth.sso2.UserFunction;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;

public class CropPlanPluginImpl implements CropPlanPlugin, InitializablePlugin {
	private static final Logger log = LoggerFactory.getLogger(CropPlanPluginImpl.class);
	
	private static final String VINEALIGN_URL = "vinealignURL";
	public static final String VINEALIGN_CONTEXT = "VINEALIGN";
	public static final String VINEALIGN_EDITOR_FUNCTION = "EDITOR";
	public static final String VINEALIGN_BACKOFFICE_FUNCTION = "BACKOFFICE";
	private static final String URL_EXTERNAL = "cropPlanPluginsBaseUrl";

	private String externalUrl;

	private static final String URL_ERROR_MESSAGE = "External base url is not define";
	
	@Override
	public void initialize(PluginsEnvironment env) {
		externalUrl = String.valueOf(getExternalProperty(env, URL_EXTERNAL, URL_ERROR_MESSAGE));
	}

	@Override
	public boolean isReadOnly(RuntimeEnvironment env, String businessId, Long cropPlanId)
	{
		var vinealignUrl = env.getProperty(VINEALIGN_URL);
		if (vinealignUrl == null)
		{
			return true;
		}

		try (var response = env.getAuthenticatedWebTarget(vinealignUrl.toString())
			.path("public")
			.path("v1")
			.path("vine-align")
			.path(businessId)
			.path("alignment-status")
			.request(MediaType.APPLICATION_JSON)
			.get()) {

			if (response.getStatus() != 200)
				throw new IllegalStateException("Unexpected response status: " + response.getStatus());
	
			var resData = response.readEntity(VinealignStatusResult.class);
	
			if (resData.getFlInProgress() || 
				resData.getCurrentStatus() == AlignmentStatus.TO_DO ||
				(
					resData.getCurrentStatus() == AlignmentStatus.GRAPHIC_VALIDATION &&	
					!env.getSso2Client().isFunctionEnabled(env.getUser(), new UserFunction(VINEALIGN_CONTEXT, VINEALIGN_BACKOFFICE_FUNCTION))
				) ||
				resData.getCurrentStatus() == AlignmentStatus.GRAPHIC_VALIDATION_COMPLETED ||
				resData.getCurrentStatus() == AlignmentStatus.PROTOCOLLING ||
				resData.getCurrentStatus() == AlignmentStatus.COMPLETED ||
				(
					(resData.getCurrentStatus() == AlignmentStatus.IN_PROGRESS || resData.getCurrentStatus() == AlignmentStatus.ANOMALIES_CORRECTIVE || resData.getCurrentStatus() == AlignmentStatus.REVISION_REJECTED) &&
					!env.getSso2Client().isFunctionEnabled(env.getUser(), new UserFunction(VINEALIGN_CONTEXT, VINEALIGN_EDITOR_FUNCTION))
				) ||
				(
					resData.getCurrentStatus() == AlignmentStatus.IN_VALIDATION &&	
					!env.getSso2Client().isFunctionEnabled(env.getUser(), new UserFunction(VINEALIGN_CONTEXT, VINEALIGN_BACKOFFICE_FUNCTION))
				))
				return true;
	
			return false;
		}
	}

	@Override
	public boolean canAddPlots(RuntimeEnvironment env, String businessId, Long cropPlanId)
	{
		var vinealignUrl = env.getProperty(VINEALIGN_URL);
		if (vinealignUrl == null)
		{
			return false;
		}

		try (var response = env.getAuthenticatedWebTarget(vinealignUrl.toString())
			.path("public")
			.path("v1")
			.path("vine-align")
			.path(businessId)
			.path("alignment-status")
			.request(MediaType.APPLICATION_JSON)
			.get()) {

			if (response.getStatus() != 200)
				throw new IllegalStateException("Unexpected response status: " + response.getStatus());
	
			var resData = response.readEntity(VinealignStatusResult.class);

			/* IN_PROGRESS and REVISION_REJECTED should be statuses used by CAA user, removed canAddPlots possibility as requested
			if (!resData.getFlInProgress() &&
				(resData.getCurrentStatus() == AlignmentStatus.IN_PROGRESS || resData.getCurrentStatus() == AlignmentStatus.REVISION_REJECTED))
				return true;
			*/

			return false;
		}
	}
	
	@Override
	public boolean isExternalChangesPending(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime latestVersionDt) {
		return false;
	}
	
	@Override
	public CompletionStage<PublishVersionResult> publishVersion(RuntimeEnvironment env, String businessId, Long cropPlanId, String version) {
		return CompletableFuture.completedFuture(new PublishVersionResult(true));
	}
	
	@Override
	public List<PermanentCropFormSubscription> getPermanentCropFormSubscriptions(RuntimeEnvironment env, String externalCode, List<String> subscriptionCodes) {

		List<PermanentCropFormSubscription> subscriptionsList = null;
		Map<String, Object> pathVariables = Map.of(
				"tenant", env.getTenantId()
		);
		String api = "{tenant}/api-priv/v1/crop-plan/crop-form-subscriptions";

		var target = env.getAuthenticatedWebTarget(externalUrl)
				.path(api)
				.resolveTemplates(pathVariables)
				.queryParam("external_code", externalCode)
				.queryParam("subscription_codes", subscriptionCodes);

		try (var response = target.request(MediaType.APPLICATION_JSON).get()) {
			if (response.getStatus() != 200) {
				throw new IllegalStateException("Unexpected response status: " + response.getStatus());
			}
			subscriptionsList = response.readEntity(new GenericType<List<PermanentCropFormSubscription>>() {
			});
		}

		return subscriptionsList;

	}
	
	@Override
	public List<PermanentCropFormExternalCodeDecode> getPermanentCropFormExternalCodeDescription(RuntimeEnvironment env, List<String> externalCodeList) {
		List<PermanentCropFormExternalCodeDecode> ret = new ArrayList<>();

		Map<String, Object> pathVariables = Map.of(
				"tenant", env.getTenantId()
		);
		String api = "{tenant}/api-priv/v1/crop-plan/external-permanent-crop-forms";
		GetPermanentCropFormExternalCodeDescriptionPayload payload = new GetPermanentCropFormExternalCodeDescriptionPayload(externalCodeList);

		var target = env.getAuthenticatedWebTarget(externalUrl)
				.path(api)
				.resolveTemplates(pathVariables);
		Entity<?> entity = Entity.json(payload);
		try (var response = target.request(MediaType.APPLICATION_JSON).method("POST", entity)) {
			if (response.getStatus() != 200) {
				throw new IllegalStateException("Unexpected response status: " + response.getStatus());
			}
			ret = response.readEntity(new GenericType<List<PermanentCropFormExternalCodeDecode>>() {});
		}
		
		return ret;
	}
	
	@Override
	public Map<String, String> getVersionsMessagesExt(RuntimeEnvironment env, String businessId, Long cropPlanId, List<CropPlanVersion> versions) {
		return new HashMap<>();
	}

	@Override
	public List<CropPlanConfigData> getCropPlanConfig(RuntimeEnvironment env, String businessId, Long cropPlanId, List<CropPlanConfigData> cropPlanConfigs) {

		var vinealignUrl = env.getProperty(VINEALIGN_URL);
		if (vinealignUrl == null)
		{
			return cropPlanConfigs;
		}

		try (var response = env.getAuthenticatedWebTarget(vinealignUrl.toString())
			.path("public")
			.path("v1")
			.path("vine-align")
			.path(businessId)
			.path("alignment-status")
			.request(MediaType.APPLICATION_JSON)
			.get()) {

			if (response.getStatus() != 200)
				throw new IllegalStateException("Unexpected response status: " + response.getStatus());

			var resData = response.readEntity(VinealignStatusResult.class);
			if (!resData.getFlInProgress() && resData.getCurrentStatus() == AlignmentStatus.IN_PROGRESS) {
				cropPlanConfigs = new ArrayList<>(cropPlanConfigs);
				cropPlanConfigs.add(CropPlanConfigData.builder()
						.paramName("DISABLE_VALID_VALUED_DECL_FIELDS_EDIT")
						.paramValue("TRUE")
						.build());
				cropPlanConfigs.add(CropPlanConfigData.builder()
						.paramName("DISABLE_ADD_DECLARATIONS")
						.paramValue("TRUE")
						.build());
			}
		}

		return cropPlanConfigs;
	}

	@Override
	public String getCropPlanType() {
		return "VINEALIGN";
	}

	private Object getExternalProperty(PluginsEnvironment env, String propertyToSearch, String errorMessage) {
		return getExternalProperty(getExternalProperties(env), propertyToSearch, errorMessage);
	}

	private Object getExternalProperty(Map<String, Object> externalProperties, String propertyToSearch, String errorMessage) {
		if (externalProperties == null || !externalProperties.containsKey(propertyToSearch)) {
			throw new IllegalStateException(errorMessage);
		}

		return externalProperties.get(propertyToSearch);
	}

	private Map<String, Object> getExternalProperties(PluginsEnvironment env) {
		Map<String, Object> externalProperties = null;
		if (env.getProperty(PluginProperties.EXTERNAL_PLUGINS_PROPERTIES_PROPERTY_NAME) != null) {
			ObjectMapper mapper = new ObjectMapper();
			externalProperties = mapper.convertValue(env.getProperty(PluginProperties.EXTERNAL_PLUGINS_PROPERTIES_PROPERTY_NAME),
					new TypeReference<Map<String, Object>>() {
					});
		}

		return externalProperties;
	}

}
