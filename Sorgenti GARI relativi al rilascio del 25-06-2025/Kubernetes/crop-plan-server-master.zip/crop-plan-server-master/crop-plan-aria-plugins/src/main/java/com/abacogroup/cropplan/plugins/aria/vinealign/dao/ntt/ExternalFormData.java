package com.abacogroup.cropplan.plugins.aria.vinealign.dao.ntt;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExternalFormData {
	String externalCode;
	String externalDescription;
	Integer foglio;
	String particella;
	Integer unar;
}
