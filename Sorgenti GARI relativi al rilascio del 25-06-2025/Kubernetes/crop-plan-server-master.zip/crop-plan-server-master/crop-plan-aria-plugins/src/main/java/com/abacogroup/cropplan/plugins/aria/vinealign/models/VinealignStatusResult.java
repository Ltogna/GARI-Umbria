package com.abacogroup.cropplan.plugins.aria.vinealign.models;

import lombok.Data;

@Data
public class VinealignStatusResult {
    private AlignmentStatus currentStatus;
    private Boolean flInProgress;
}
