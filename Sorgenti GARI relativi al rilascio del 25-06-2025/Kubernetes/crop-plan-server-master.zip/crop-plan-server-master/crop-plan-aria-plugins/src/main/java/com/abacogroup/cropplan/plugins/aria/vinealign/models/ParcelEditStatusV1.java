package com.abacogroup.cropplan.plugins.aria.vinealign.models;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class ParcelEditStatusV1 {
	@Schema(description = "Parcel Id", type = "integer", format = "int64")
	private Long id;

	@Schema(description = "creation date of parcel", type = "string", format = "date-time")
	private LocalDateTime creationDate;

	@Schema(description = "last update date of parcel", type = "string", format = "date-time")
	private LocalDateTime lastUpdate;

//	@Schema(description = "Edit status of parcel", type = "string", implementation = EditStatus.class)
	private String editStatus; // com.abacogroup.lpisgisserver.core.enums.EditStatus
	
	@Schema(description = "", type = "Boolean")
	private Boolean inEdit;

}
