# Crop Plan Server

[toc]

## SSO context|function

The allowed SSO context|function are:

- CRPL|USER
  - it enables the user to the crop plans
- CRPL|EDITOR
  - it enables the user to create and edit crop plans
- CRPL|CAN_EDIT_CROPPLAN_DESC
  - it enables the user to edit crop plans descriptions
- CRPL|CAN_DELETE_CROPPLAN
  - it enables the user to delete crop plans
- CRPL|CAN_DELETE_PLOTS
  - it enables the user to delete multiple plots
- CRPL|CAN_FORCE_SYNC
  - it enables the user to perform a forced sync operation
- CRPL|IGNORE_PARTIES_ACL
  - it grants visibility to all businesses
- CRPL|CAN_IGNORE_VALIDATION_MSGS
  - it grants user to skip all validation messages

## Environment config special values

### Standard Domain Plugin

- cllUrl can be set to "cropplan" value to skip parcels loading using domains of plots in the crop plan when domainPluginsBaseUrl is set to default

## Send messages on queues

### Send message on publishing request

Everytime a crop plan publish is requested a message (JSON) through RabbitMQ is sent. Message body is:

```json
{
 "tenant": String,
 "businessId": String,
 "cropPlanId": Number,
 "cropPlanTypeCode": String,
 "version": {
   "value": String,
   "date": LocalDateTime
 },
 "versionDate": LocalDateTime
}
```

The message is sent on:

```
EXCHANGE: crop-plan-commit
ROUTING KEY: <cropPlanTypeCode>
ex: CROPPLAN
```

### Send message on published succesfully

Everytime a crop plan is published succesfully a message (JSON) through RabbitMQ is sent. Message body is:

```json
{
 "tenant": String,
 "businessId": String,
 "cropPlanId": Number,
 "cropPlanTypeCode": String,
 "version": {
   "value": String,
   "date": LocalDateTime
 },
 "versionDate": LocalDateTime
}
```

The message is sent on:

```
EXCHANGE: crop-plan-commit
ROUTING KEY: <cropPlanTypeCode>.published
ex: CROPPLAN.published
```

## Bundles format

The application can be conencted to a RabbitMQ instance usign this configuration snippet:

```yaml
    rabbitmqConfig:
      host: ${RMQ_HOST}
      user: ${RMQ_USER}
      password: ${RMQ_PASSWORD}
      virtualhost: ${RMQ_VHOST}
      port: ${RMQ_PORT}
```

If the connection is configured, the bundles infrastructure will be automatically setup to allow automatic configuration.

The application module id is `crop-plan` and the supported changeset domains are:

```
📂configurations
 ┣ 📜 <any file>.json
 ┗ 📜 <any file>.delete.json
📂crplTypes
 ┣ 📜 <any file>.json
📂permCropFormFieldValues 
 ┣ 📜 <any file>.json
 ┗ 📜 <any file>.delete.json
📂anomalies
 ┣ 📜 <any file>.json
 ┗ 📜 <any file>.delete.json
📂crplLandUseClassOptions
 ┣ 📜 <any file>.json
 ┗ 📜 <any file>.delete.json
📂prints
 ┣ 📜 <any file>.json
 ┗ 📜 <any file>.delete.json
 📂printsParams
 ┣ 📜 <any file>.json
 ┗ 📜 <any file>.delete.json
 📂additionalDeclarationFieldsCodes
 ┣ 📜 fieldsConf.jsonl
 ┣ 📜 fieldsConf.delete.jsonl
 ┣ 📜 fieldsAllowedValues.jsonl
 ┗ 📜 fieldsAllowedValues.delete.jsonl
 anomScenarioDisableFuncConfig
 ┣ 📜 anomScenarioDisableFuncConfig.jsonl
 ┣ 📜 anomScenarioDisableFuncConfig.delete.jsonl
```

The `configurations` domain allows to load, update and delete configuration parameters.

The `crplTypes` domain allows to load and update crop plan types.

The `permCropFormsConfig` domain allows to load, update and delete permanent crop forms configuration.

The `permCropFormFieldValues` domain allows to load, update and delete permanent crop form field values.

The `anomalies` domain allows to load, update and delete anomalies decodes.

The `crplLandUseClassOptions` domain allows to set specific options for land use classes.

The `prints` domain allows to load, update and delete crop plan prints.

The `printsParams` domain allows to load, update and delete crop plan prints params.

The `additionalDeclarationFieldsCodes` domain allows to load, update and delete the additional declarations fields configurazion.

The `anomScenarioDisableFuncConfig` domain allows to load, update and delete Configuration for Scenario of Anomalies that Disable Functions.

The insert and update files extension is `.json`, the delete files extension is: `.delete.json`

### configurations .json files

.json files must follow this structure:

```json
{
    "cropPlanType": "",
    "cropPlanConfig": []
}
```

allowed configuration parameters are:

- ALLOW_DECLS_PERC_TO_ZERO = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the zero percentage declarations are allowed
- BULK_DECLARATIONS_ANOMALIES_FILTER = {anomaly_code1 anomaly_code2 anomaly_code3 ...} (default null)
  - if it is set then the declarations anomalies returned are listed in this parameter separated by an empty space (i.e. DECLARATION_MISSING_MANDATORY_FIELDS DECLARATION_WITH_OBSOLETE_LAND_USE) (also the ENABLE_BULK_DECLARATIONS_FIELDS_EDIT must be set to TRUE)
- CAMPAIGN_REF_DATE = MMdd (default null)
  - if it is set then also the CAMPAIGN_START_DATE must be set and it defines the campaign reference date calculated from the campaign start date by the current point in time
- CAMPAIGN_START_DATE = MMdd (default null)
  - if it is set then it defines the campaign start date, the year is calculated by the current point in time
- CANVAS_PREPROCESS_BEHAVIOUR = NONE|ASSIGN_OVERLAPS_TO_BIGGER|ASSIGN_OVERLAPS_TO_SMALLER (default NONE)
  - if it is set to a value different from NONE then the canvas are preprocessed to avoid overlaps with the specified behaviour (assign to bigger or assign to smaller)
- CLEAR_DECL_END_DATE_WHEN_START_DATE_IS_CHANGED (default FALSE)
  - if it is set to TRUE then the declaration end date is cleared when start date is changed
- CONSTRAINTS_DECLS_TO_PLOTS = TRUE|FALSE (default TRUE)
  - if it is set to TRUE then the declaration start dates can be set before the plot start date and the declaration end dates can be set after the plot end date
- CONSTRAINTS_DECLS_PERC_TO_100 = TRUE|FALSE (default TRUE)
  - if it is set to TRUE then the sum of the declarations percentage of a plot must not exceed 100
- CONSTRAINTS_VERSION_TO_SYNC_REF_DATE = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then create version is available only if latest sync is executed at the same reference date
- COPY_DECLARATIONS_AT_DATE = MMdd (default null)
  - if it is set then copy declarations at date from previous to current year is enabled (also the CAMPAIGN_START_DATE must be set)
- COPY_PREVIOUS_YEAR_DECLS_FROM_VERSION_TOLERANCE_PERC = {tolerance} (default 70)
  - it specify the intersection area tolerance percentage for copy previous year declarations from version (ENABLE_COPY_DECLARATIONS_FROM_VERSION must be set to TRUE)
- DISABLE_ADD_DECLARATIONS = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the declarations can't be added
- DISABLE_CHANGE_DATE = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the date can't be changed
- DISABLE_CHANGE_DATE_ON_TIMELINE = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the date can't be changed in timeline
- DISABLE_CHANGE_DATE_WHEN_READ_ONLY = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the date can't be changed when the crop plan is read only
- DISABLE_CHECK_ON_MANDATORY_DECL_FIELDS = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then declarations can be saved without mandatory fields (additional fields and permanent crop forms fields); this parameter does not affect bulk declarations fields edit
- DISABLE_COPY_DUPLICATED_EXTERNAL_DECLARATIONS = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the copy of external declarations is disabled for duplicated
- DISABLE_DELETE_DECLARATIONS_IF_EXTERNAL = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the delete operation of declaration is disable if the external code is not null
- DISABLE_PERMANENT_CROP_EXTIRPATION = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the permanent crop extirpation is disabled
- DISABLE_PLOT_DATA_SPATIAL_INDEX = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the spatial index on some crpl_plot_data queries is not used (switching param order in geom_have_interactions)
- DISABLE_PUBLISH_CROP_PLAN = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the crop plan publish is disabled
- DISABLE_VALID_VALUED_DECL_FIELDS_EDIT = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the valid valued declaration fields are not editable
- DISABLE_VALUED_DECL_FIELDS_EDIT = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the valued declaration fields are not editable
- DO_NOT_REPROPORTION_DECLS_AREAS = TRUE|FALSE (defauls FALSE)
  - if it is set to TRUE then declarations areas are not reproportioned while editing
- EDIT_AT_FIXED_DATE = MMdd|yyyyMMdd (default null)
  - if it is set then the crop plan can be edited only at fixed date; if no year specified then also the CAMPAIGN_START_DATE must be set and the crop plan can be edited only at the date calculated from the campaign start date by the current point in time
- EDIT_PROPAGATION_TOLERANCE = {tolerance} (default null)
  - if it is set then all the edit operations are propagated considering the tolerance
- ENABLE_ALL_COUNCILS_SELECTION = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the selection of all councils is enabled
- ENABLE_AUTOMERGE_FOR_LPIS_SYNC = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then plots that are synchronized can be merged
- ENABLE_BULK_DECLARATIONS_FIELDS_EDIT = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then bulk declarations fields edit is enabled
- ENABLE_CADPARCELS_LIST = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the cadastral parcels list is enabled
- ENABLE_CHANGE_DATE_CONFIRM = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then a confirm dialog is shown before date change
- ENABLE_COPY_CAMPAIGN = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the copy campaign is enabled
- ENABLE_COPY_DECLARATIONS_FROM_VERSION = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the copy previous year declarations from version is enabled
- ENABLE_COUNCILS_MINIMAP_PREVIEW = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the councils minimap preview is enabled
- ENABLE_DECLARATIONS_COPY_ON_MULTIPLE_PLOTS = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the declarations copy on multiple plots is enabled
- ENABLE_DECLARATIONS_MERGE = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the declarations merge is enabled
- ENABLE_DECLARATIONS_REPROPORTION = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the declarations reproportion is enabled
- ENABLE_DECLARATIONS_REPROPORTION_WHEN_NOT_EDITABLE = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the declarations reproportion is enabled also if the plot is not editable (also the ENABLE_DECLARATIONS_REPROPORTION must be set to TRUE)
- ENABLE_DECLARATIONS_SWAP = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the declarations swap is enabled
- ENABLE_DEFAULT_NOT_PRESERVE_DECLS_ON_PLOTS_MERGE = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the remove declarations on plots merge is enabled by default
- ENABLE_PLOT_EDIT_BUFFER = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the plot buffer is enabled while editing a plot
- ENABLE_FAVOURITES_LAND_USES = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the favourites land uses are enabled
- ENABLE_FORCED_SYNC = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the forced sync is enabled (the user must also have the CRPL|CAN_FORCE_SYNC context|function)
- ENABLE_INFO_GIS = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the Info GIS on active layers is enabled
- ENABLE_PARCELS_LIST = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the parcels list is enabled
- ENABLE_PARCELS_NOTES = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the parcels notes is enabled
- ENABLE_PESTICIDES = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the pesticides module is enabled
- ENABLE_PESTS = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the pests module is enabled
- ENABLE_PLACES_SEARCH = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the places search is enabled
- ENABLE_PLOT_EDIT_DATE_WARNING = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then warnings before plot edit are shown when date is different from campaign start date (or plot start date if greater than campaign start date or if campaign start date is not set)
- ENABLE_PUBLICATIONS_LIST = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the publications list is enabled
- ENABLE_PUBLISH_WHEN_NO_CHANGES_PENDING = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the publish is enabled also when no changes pending
- ENABLE_RESTORE_LAST_VERSION = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the restore last crop plan version is enabled
- ENABLE_RESTORE_PLOT_DEFAULT = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the restore plot default is enabled
- ENABLE_RESUME_PLOT_FROM_FIRST_CROP_PLAN_VERSION = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the resume plot from first crop plan version is enabled
- FIELDS_LAYER_DESCRIPTION = {layerDescription} (default null)
  - if it is set then the fields layer description is overridden by this parameter
- FORCE_DEFAULT_HARVEST_DATE_FOR_PERMANENT_DECL = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the permanent declaration harvest date is set to the default value (never empty)
- FORCE_EDIT_AT_FIXED_DATE = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then also the EDIT_AT_FIXED_DATE must be set and the crop plan is automatically edited at the fixed edit date
- HIDE_LAND_USE_DEFAULT_HARVEST_DATE = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the land use default harvest date is hidden
- HIDE_PARCELS = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the parcels information is hidden
- HIDE_PLOTS_NAMES = TRUE|FALSE (default fallback to crop plan client general config)
  - if it is set to TRUE then the plots names are hidden
- HIDE_PLOTS_NOTES = TRUE|FALSE (default TRUE)
  - if it is set to TRUE then the plots notes are hidden
- IGNORE_LAND_USE_COMPATIBILITY = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the land use compatibility check is ignored
- INVALID_LAND_USE_CODES = {land_use_code1 land_use_code2 land_use_code3 ...} (default null)
  - if it is set then the land use codes listed in this parameter separated by an empty space (i.e. 000-000-000-000-001 000-000-000-000-002 000-000-000-000-003) are invalid (marked as invalid in the declaration edit form)
- LATEST_OTHER_PLANS_VERSION_EMPTY_DOMAIN_PLOTS_LAYER_AREA_TOLERANCE = {tolerance} (default 1)
  - if the value is configured, it will be used to extract intersecting geometries for the LATEST_OTHER_PLANS_VERSION_EMPTY_DOMAIN_PLOTS layer. Otherwise, the default value of 1 will be used for this purpose.
- LINEAR_ELEMENTS = {size1 size2 size3 ...} (default null)
  - if it is set then the linear elements is enabled and the available size is listed in this parameter separated by an empty space (i.e. 1 2 3 4 5)
- LOCK_DECLARATIONS_FIELDS_IF_EXTERNAL = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the additional fields and permanent crop forms are not editable if the external code is not null
- MANDATORY_PLANTING_DATE_PRECISION = Y|YM|YMD (default YM)
  - if it is set then the precision of the planting date must satisfy this precision
- MAX_PLOTS_ON_DOMAIN_ZONE = {max_plots} (default null)
- if it is set then max number on plots on domain zone is evaluated for big domain zone behaviour
- MAX_ZOOM = {max_zoom} (default fallback to crop plan client default max zoom value)
  - if it is set then max available zoom used in iacsMapComponent will be assigned to MAX ZOOM otherwise to default value
- OPEN_AT_FIXED_DATE = MMdd|yyyyMMdd (default null)
  - if it is set then the crop plan opens at fixed date; if no year specified then also the CAMPAIGN_START_DATE must be set and the crop plan is opened at the date calculated from the campaign start date by the current point in time
- PERIMETER_MULTIPLIER_AREA_TOLERANCE = {tolerance} (default null)
  - if it is set then while declaring plot areas can be considered with tolerance (CONSTRAINTS_DECLS_PERC_TO_100 must be set to FALSE)
- PLOTS_OUT_OF_FILTER_BACKGROUND_STYLE = CROSSED|NONE (default CROSSED)
  - if it is set then it defines the background style of the plots out of filter
- REPROPORTION_DECL_AREA_ON_SYNC_PLOT_ALIGN = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then Sync for the type PLOT_ALIGN, when set Perc Area Decl on Plot, calculate it by reproportioning it with the old plot value and the old perc Value on the new Plot Area instead of using the old Perc Area of the old Decl.
- RESTORE_PLOTS_AT_CAMPAIGN_START_DATE = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then also the CAMPAIGN_START_DATE must be set and the plots are restored at the campaign start date (or at the plots from date if plots were created after the campaign start date)
- RESTORE_PLOTS_PROPAGATING_BEHAVIOUR = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the plots restoring behaviour propagates modifies cut existing ignoring breaking point
- SHOW_DECLS_AREA_IN_PLOTS_LIST = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then the declarations detailed areas and the remaining area are shown in the plots list
- SNAP_FROM_CAMPAIGN_REF_DATE = TRUE|FALSE (default FALSE)
  - if it is set to TRUE then also the CAMPAIGN_REF_DATE must be set and data are taken at the reference date of the campaign identified by the current point in time
- SYNC_TYPE_ON_OPEN = {SYNC_TYPE} (default null)
  - if it is set then a sync of the specified type is executed when a crop plan is opened
- TARE_LAND_USE_CODE = {tareLandUseCode} (default null)
  - if it is set then the complete with tare is enabled

an example file is:

```json
{
    "cropPlanType": "THE-CROP-PLAN-TYPE",
    "cropPlanConfig": [
        {
            "paramName": "THE-PARAM-NAME-1",
            "paramValue": "THE-PARAM-VALUE"
        },
        {
            "paramName": "THE-PARAM-NAME-2",
            "paramValue": "THE-PARAM-VALUE"
        }
    ]
}
```

### configurations .delete.json files

.delete.json files must have the same structure as .json file but the content is only composed by the "keys" of the elements to delete; an example file is:

```json
{
    "cropPlanType": "THE-CROP-PLAN-TYPE",
    "cropPlanConfig": [
        {
            "paramName": "THE-PARAM-NAME-1"
        },
        {
            "paramName": "THE-PARAM-NAME-2"
        }
    ]
}
```

### crplTypes .json files

.json files must follow this structure:

```json
{
    "cropPlanTypes": []
}
```

an example file is:

```json
{
    "cropPlanTypes": [
        {
        "code": "THE-CROP-PLAN-TYPE-1",
        "flMultiple": false,
        "flLimitToCanvas": true,
        "flSplitOnCanvas": true,
        "dayFrom": "YYYYMMDD",
        "dayTo": "YYYYMMDD",
        "i18nValues": [
                {
                "language": "it",
                "text": "THE-INTERNAZIONALIZED-TEXT"
                }
            ]
        },
        {
        "code": "THE-CROP-PLAN-TYPE-2",
        "flMultiple": true,
        "flLimitToCanvas": true,
        "flSplitOnCanvas": true,
        "dayFrom": "YYYYMMDD",
        "dayTo": "YYYYMMDD",
        "i18nValues": [
                {
                "language": "it",
                "text": "THE-INTERNAZIONALIZED-TEXT"
                }
            ]
        }
    ]
}
```

### crplTypes .delete.json files

.delete.json files must have the same structure as .json file but the content is only composed by the "keys" of the elements to delete; an example file is:

```json
{
    "cropPlanTypes": [
        {
        "code": "THE-CROP-PLAN-TYPE-1"
        }
    ]
}
```

### permCropFormsConfig .json files

.json files must follow this structure:

```json
{
    "cropPlanType": "",
    "formType": "",
    "landUseCodes": [],
    "landUseClassCodes": [],
    "validFrom": "YYYYMMDD",
    "validTo": "YYYYMMDD",
    "fields": []
}
```

- `validFrom`: _string, optional, format `YYYYMMDD`, default `19700101`_. start validity of configuration
- `validTo`: _string, optional, format `YYYYMMDD`, default `99991231`_. end validity of configuration

**N.B.**: If there is one or more configurations in a time interval intersecting the one entered in the json, these configurations will be **overwritten**.

an example file is:

```json
{
    "cropPlanType": "THE-CROP-PLAN-TYPE",
    "formType": "THE-FORM-TYPE",
    "landUseCodes": [ "CODE-1", "CODE-2" ],
    "landUseClassCodes": [ "CLASS-CODE-1", "CLASS-CODE-2" ],
    "validFrom": "19700101",
    "validTo": "99991231",
    "fields": [
    	{
	    "fieldCode": "THE-FIELD-CODE-1",
	    "mandatory": true,
	    "editable": true
	    },
	    {
	    "fieldCode": "THE-FIELD-CODE-2",
	    "mandatory": false,
	    "editable": true
	    }
    ]
}
```


### permCropFormsConfig .delete.json files

.delete.json files must have the same structure as .json file but the content is only composed by the "keys" of the elements to delete; an example file is:

```json
{
    "cropPlanType": "THE-CROP-PLAN-TYPE",
    "formType": "THE-FORM-TYPE",
    "landUseCodes": [ "CODE-1", "CODE-2" ],
    "landUseClassCodes": [ "CLASS-CODE-1", "CLASS-CODE-2" ],
    "deleteFrom": "YYYYMMDD"
}
```

- `deleteFrom`: _AbsoluteDate, format `YYYYMMDD`._ if not null, update configuration and set new `validTo` a day before `deleteFrom`.
  only applies if there is a validity interval that includes `deleteFrom -1`.
- `landUseCodes`, `landUseClassCodes`: _array of string_. if both null/empty, delete all by `formType` and `cropPlanType`

### permCropFormFieldValues .json files

.json files must follow this structure:

```json
{
    "cropPlanType": "",
    "fieldValues": []
}
```

an example file is:

```json
{
    "cropPlanType": "THE-CROP-PLAN-TYPE",
    "fieldValues": [
        {
        "formType": "THE-FORM-TYPE",
        "fieldCode": "THE-FIELD-CODE-1",
        "fieldValue": "THE-FIELD-VALUE",
        "i18nValues": [
                {
                "language": "it",
                "text": "THE-INTERNAZIONALIZED-TEXT"
                }
            ]
        },
        {
        "formType": "THE-FORM-TYPE",
        "fieldCode": "THE-FIELD-CODE-2",
        "fieldValue": "THE-FIELD-VALUE",
        "i18nValues": [
                {
                "language": "it",
                "text": "THE-INTERNAZIONALIZED-TEXT"
                }
            ]
        }
    ]
}
```

### permCropFormFieldValues .delete.json files

.delete.json files must have the same structure as .json file but the content is only composed by the "keys" of the elements to delete; an example file is:

```json
{
    "cropPlanType": "THE-CROP-PLAN-TYPE",
    "fieldValues": [
        {
        "formType": "THE-FORM-TYPE",
        "fieldCode": "THE-FIELD-CODE-1",
        "fieldValue": "THE-FIELD-VALUE"
        },
        {
        "formType": "THE-FORM-TYPE",
        "fieldCode": "THE-FIELD-CODE-2",
        "fieldValue": "THE-FIELD-VALUE"
        }
    ]
}
```

### anomalies .json files

.json files must follow this structure:

```json
{
    "anomalies": []
}
```

an example file is:

```json
{
    "anomalies": [
        {
        "errorCode": "ANOM-01",
        "i18nValues": [
                {
                "language": "it",
                "text": "THE-ERROR-DESCRIPTION"
                }
            ],
        "genericI18nValues": [
                {
                "language": "it",
                "text": "THE-GENERIC-ERROR-DESCRIPTION"
                }
            ]
        },
        {
        "errorCode": "ANOM-02",
        "i18nValues": [
                {
                "language": "it",
                "text": "THE-ERROR-DESCRIPTION"
                }
            ],
        "genericI18nValues": [
                {
                "language": "it",
                "text": "THE-GENERIC-ERROR-DESCRIPTION"
                }
            ]
        }
    ]
}
```

### anomalies .delete.json files

.delete.json files must have the same structure as .json file but the content is only composed by the "keys" of the elements to delete; an example file is:

```json
{
    "anomalies": [
        {
        "errorCode": "ANOM-01"
        }
    ]
}
```

### crplLandUseClassOptions .json files

.json files must follow this structure:

```json
{
    "cropPlanType": "",
    "crplLandUseClassOptions": []
}
```

an example file is:

```json
{
    "cropPlanType": "THE-CROP-PLAN-TYPE",
    "crplLandUseClassOptions": [
        {
            "landUseClassCode": "THE_LAND_USE_CLASS_CODE_1",
            "percFixedTo100": true
        },
        {
            "landUseClassCode": "THE_LAND_USE_CLASS_CODE_2",
            "percFixedTo100": false
        }
    ]
}
```

### crplLandUseClassOptions .delete.json files

.delete.json files must have the same structure as .json file but the content is only composed by the "keys" of the elements to delete; an example file is:

```json
{
    "cropPlanType": "THE-CROP-PLAN-TYPE",
    "crplLandUseClassOptions": [
        {
            "landUseClassCode": "THE_LAND_USE_CLASS_CODE_1"
        }
    ]
}
```

### prints .json files

.json files must follow this structure:

```json
{
    "cropPlanType": "",
    "cropPlanPrints": []
}
```

an example file is:

```json
{
    "cropPlanType": "THE-CROP-PLAN-TYPE",
    "cropPlanPrints": [
        {
            "code": "THE_PRINT_CODE_1",
            "i18nValues": [
                {
                "language": "it",
                "text": "THE-PRINT-DESCRIPTION"
                }
            ]
        },
        {
            "code": "THE_PRINT_CODE_2",
            "i18nValues": [
                {
                "language": "it",
                "text": "THE-PRINT-DESCRIPTION"
                }
            ]
        }
    ]
}
```

### prints .delete.json files

.delete.json files must have the same structure as .json file but the content is only composed by the "keys" of the elements to delete; an example file is:

```json
{
    "cropPlanType": "THE-CROP-PLAN-TYPE",
    "cropPlanPrints": [
        {
            "code": "THE_PRINT_CODE_1"
        }
    ]
}
```

### prints params .json files

.json files must follow this structure:

```json
{
    "cropPlanType": 1,
    "printCode": "",
    "printParams": []
}
```

an example file is:

```json
{
    "cropPlanType": 1,
    "printCode": "PRINT_CODE",
    "printParams": [
        {
          "name": "PARAM_NAME_1",
          "value": "PARAM_VALUE_1"
        },
        {
          "name": "PARAM_NAME_2",
          "value": "PARAM_VALUE_2"
        }
    ]
}
```

### prints .delete.json files

.delete.json files must have the same structure as .json file but the content is only composed by the "keys" of the elements to delete; an example file is:

```json
{
  "cropPlanType": 1,
  "printCode": "PRINT_CODE"
}
```


### additionalDeclarationFieldsCodes fieldsConf.jsonl

__is a "**JSON Lines**" file format, one line at time is read__

The fields Configuration JSONL file is used for insert/update "crpl_landuse_addit_fields" table and must have the following structure:

```json lines
{"code":"String (mandatory)", "description":[{"language":"String (mandatory)", "text":"String (mandatory)"}],  "type":"String (mandatory)", "validFrom":"AbsoluteDate", "validTo":"AbsoluteDate", "displayOrder":"Integer (mandatory)", "nullable":"Boolean (mandatory)", "flShowInTooltip": "Boolean (mandatory)", "group": "String", "headerTitle": {"headerTitleCode" : "String (mandatory)", "i18nValues":[{"language":"String (mandatory)", "text":"String (mandatory)"}]}, "flEditable" : "Boolean (mandatory)", "formula": "String", "landUseConfigurations": [{"landUseCode": "String (mandatory)", "nullable": "Boolean (mandatory)"}]}
```

#### Additional fields configuration:

- `code`: unique code of of the additional declaration field to insert/update
- `description`: an array of translated description of the code[
  - `language`: the language code
  - `"text`: the tranlsated description of the additional declaration field code
    ]
- `type`: A value of the enum "LandUseAdditionalFieldType" (for now only: "COMBO", "PERCENTAGE", "INTEGER", "NUMBER", "STRING")
- `validFrom`: start date for the validity of the additional declaration field code in the "AbsoluteDate" YYYYMMDD, example: 19700101
- `validTo`: end date for the validity of the additional declaration field code in the "AbsoluteDate" YYYYMMDD, example: 99991231
- `displayOrder`: the display order position of the additional declaration field code
- `nullable`: flag to set the possibility to set the value of the additional declaration field code to null, practically if nullable the field became not mandatory
- `flShowInTooltip`: indicates whether the field should be displayed in the tooltip of the timeline declaration.
- `group`: is used to indicate a category in which the attributes within are mutually exclusive (radio button)
- `headerTitle`: is used to indicate the header where the attributes within are going to be grouped into a box.
- `flEditable`: is used to indicate if the field is editable or not.
- `formula`: formula usd for fields.
- `landUseConfigurations`: _array_. specific configuration for land use code
  - `landUseCode`: _string, mandatory_. the land use code
  - `nullable`: _boolean, mandatory_. flag to set the possibility to set the value of the additional declaration field code to null, practically if nullable the field became not mandatory. overrides `nullable` from root

example:

```json lines
{"code":"CROP_PROTECTION_SYSTEMS", "description":[{"language":"it", "text":"Sistema di protezione"}, {"language":"en", "text":"Crop protection systems"}], "type":"COMBO", "validFrom":"19700101", "validTo":"99991231", "displayOrder":"314", "nullable":"false", "flShowInTooltip":  "false", "group": "FLC_GRASSED", "headerTitle": {"headerTitleCode": "FLAGGED_RUGGED", "i18nValues": [{ "language": "it", "text": "Testo in italiano"}, {"language": "en", "text": "Text in english"}]}, "flEditable": "true", "formula": "formula for the fields", "landUseConfigurations": [{"landUseCode": "000-000-000-000-000", "nullable": true}]}
```


### additionalDeclarationFieldsCodes fieldsConf.delete.jsonl

__is a "**JSON Lines**" file format, one line at time is read__

The delete fields Configuration JSONL file is used for outdate the rows in "crpl_landuse_addit_fields" table and must have the following structure:

```json lines
{"code":"String (mandatory)"}
```

#### Additional fields configuration for delete:

- `code`: unique code of of the additional declaration field to outdate

example:

```json lines
{"code":"CROP_PROTECTION_SYSTEMS"}
```


### additionalDeclarationFieldsCodes fieldsLandUseConf.jsonl

__is a "**JSON Lines**" file format, one line at time is read__

The fields land use configuration JSONL file is used for insert/update "crpl_landuse_addit_fields_cfg" table and must have the following structure:

```json lines
{"landUseCode":"String (mandatory)", "code":"String (mandatory)", "validDateFilter": "AbsoluteDate (mandatory)", "nullable": "Boolean (mandatory)"}
```

#### Additional fields land use configuration:

- `landUseCode`: _string, mandatory_. filter like for the land code to use where enable the value configuration, ex: % for all, or START% or CODE
- `code`: _string, mandatory_. code of the additional declaration field referred to the field configuration file
- `validDateFilter`: _string, mandatory, format `YYYYMMDD`_. any date in the date range of the configuration to be updated
- `nullable`: _boolean, mandatory_. flag to set the possibility to set the value of the additional declaration field code to null, practically if nullable the field became not mandatory.

example:

```json lines
{"landUseCode":"A03-010-000-000-000", "code":"CROP_PROTECTION_SYSTEMS", "validDateFilter": "20200202", "nullable": true}
```


### additionalDeclarationFieldsCodes fieldsLandUseConf.delete.jsonl

__is a "**JSON Lines**" file format, one line at time is read__

The delete fields land use configuration JSONL file is used outdate the rows in "crpl_landuse_addit_fields_cfg" table and must have the following structure:

```json lines
{"landUseCode":"String (mandatory)", "code":"String (mandatory)", "validDateFilter": "AbsoluteDate (mandatory)"}
```

#### Additional fields land use configuration for delete:

- `landUseCode`: _string, mandatory_. code of the land use filter to outdate in key with the field code
- `code`: _string, mandatory_. code of of the additional declaration field to outdate in key with land use
- `validDateFilter`: _string, mandatory, format `YYYYMMDD`_. any date in the date range of the configuration to be updated

example:

```json lines
{"landUseCode":"A03-010-000-000-000", "code":"CROP_PROTECTION_SYSTEMS", "validDateFilter": "20100102"}
```


### additionalDeclarationFieldsCodes fieldsAllowedValues.jsonl

__is a "**JSON Lines**" file format, one line at time is read__

The fields allowed values JSONL file is used for insert/update "crpl_landuse_addit_fields_val" table and must have the following structure:

```json lines
{"landUseCode":"String (mandatory)", "code":"String (mandatory)", "allowedValues":[{"value":"String (mandatory)", "description":[{"language":"String (mandatory)", "text":"String (mandatory)"}], "validFrom":"AbsoluteDate", "validTo":"AbsoluteDate", "displayOrder":"Integer (mandatory)", "isDefault":"Boolean (mandatory)"}], "insertKeepExisting":  "Boolean"}
```

#### Additional fields allowed values:

- `landUseCode`: filter like for the land code to use where enable the value configuration, ex: % for all, or START% or CODE
- `code`: code of of the additional declaration field referred to the field configuration file
- `allowedValues`: an array of allowed values configuration for the filter key landUseCode and code
  [
  - `value`: one of the possible value, if in "COMBO" conf, or type of data to accept, for "PERCENTAGE", "INTEGER", "NUMBER" and "STRING" type is used as regex to validate the value ex:"^(100?|[1-9]?\\\\d?)$"
  - `description`: an array of translated description of the value, in "COMBO" conf, or the description of the data type if possible
    [
    - `language`: the language code
    - `"text`: the tranlsated description of the additional declaration value
      ]
  - `validFrom`: start date for the validity of the additional declaration field code in the "AbsoluteDate" YYYYMMDD, example: 19700101
  - `validTo`: end date for the validity of the additional declaration field code in the "AbsoluteDate" YYYYMMDD, example: 99991231
  - `displayOrder`: the display order position of the additional declaration field value, in "COMBO" conf
  - `isDefault`: flag to set the value as the default for the field code
    ]
- **N.B.**`insertKeepExisting`: _boolean, default `false`_. if true: do no override existing data, if false: overrides existing configuration by `landUseCode`, `code`, `allowedValues.value` in all date ranges intersecting the given one  

**Please Note:** for PERCENTAGE field type if value is null there will be no check for value validity; if not null the text is used as regex to match the value, the text to write in json must be escaped for Java read, for example a backslash must be written as a double backslash

example:

```json lines
{"landUseCode":"A03-010-000-000-000", "code":"CROP_PROTECTION_SYSTEMS", "allowedValues":[{"value":"ANTI_FROST_SYSTEMS", "description":[{"language":"it", "text":"Impianti Antibrina"}, {"language":"en", "text":"Anti-frost systems"}], "validFrom":"19700101", "validTo":"99991231", "displayOrder":"100", "isDefault":"false"},{"value":"SHADOWS", "description":[{"language":"it", "text":"Ombrai"}, {"language":"en", "text":"Shadows"}], "validFrom":"19700101", "validTo":"99991231", "displayOrder":"200", "isDefault":"false"},{"value":"ANTI_HAIL_NETS", "description":[{"language":"it", "text":"Reti Antigrandine"}, {"language":"en", "text":"Anti-hail nets"}], "validFrom":"19700101", "validTo":"99991231", "displayOrder":"314", "isDefault":"false"},{"value":"ANTI_WATER_NETS", "description":[{"language":"it", "text":"Reti Antiacqua"}, {"language":"en", "text":"Anti-water nets"}], "validFrom":"19700101", "validTo":"99991231", "displayOrder":"400", "isDefault":"false"},{"value":"GREENHOUSES_AND_FIXED_TUNNELS", "description":[{"language":"it", "text":"Serre e Tunnel Fissi"}, {"language":"en", "text":"Greenhouses and fixed tunnels"}], "validFrom":"19700101", "validTo":"99991231", "displayOrder":"500", "isDefault":"false"}]}
```

```json lines
{"landUseCode":"420-005-000-000-001", "code":"PERCENTAGE_BIENNIAL_OLIVE_PRUNING", "allowedValues":[{"value":"^(100?|[1-9]?\\d?)$", "description":[], "validFrom":"19700101", "validTo":"99991231", "displayOrder":"0", "isDefault":"false"}]}
```

```json lines
{"landUseCode":"123-000-000-000-001", "code":"TEST_STRING_FIELD", "allowedValues":[{"value":"^.{1,4000}$", "description":[], "validFrom":"19700101", "validTo":"99991231", "displayOrder":"0", "isDefault":"false"}]}
```

### additionalDeclarationFieldsCodes fieldsAllowedValues.delete.jsonl

__is a "**JSON Lines**" file format, one line at time is read__

The delete fields allowed values JSONL file is used outdate the rows in "crpl_landuse_addit_fields_val" table and must have the following structure:

```json lines
{"landUseCode":"String (mandatory)", "code":"String (mandatory)"}
```

#### Additional fields allowed values for delete:

- `landUseCode`: code of the land use filter to outdate in key with the field code
- `code`: code of of the additional declaration field to outdate in key with land use

example:

```json lines
{"landUseCode":"A03-010-000-000-000", "code":"CROP_PROTECTION_SYSTEMS"}
```


### anomScenarioDisableFuncConfig .json files

.json files must follow this structure:

```json
{
    "cropPlanType": "",
    "anomScenarioConfig": []
}
```

an example file is:

```json
{
    "cropPlanType": "THE-CROP-PLAN-TYPE",
    "anomScenarioConfig": [
        {
            "scenario": "SCENARIO_1",
            "functionsDisabledConfig": [
	            {
	                "functionCode": "FUNCTION_CODE_1"
	            },
	            {
	                "functionCode": "FUNCTION_CODE_2"
	            }
            ],
            "scenarioAnomaliesConfig": [
            	{
                    "anomaliyCode": "ANOM_1",
                    "fl_present": true
                },
                {
                    "anomaliyCode": "ANOM_2",
                    "fl_present": false
                },
                {
                    "anomaliyCode": "ANOM_3",
                    "fl_present": null
                }
            ]
        }
    ]
}
```

### anomScenarioDisableFuncConfig .delete.json files

.delete.json files must have the same structure as .json file but the content is only composed by the "keys" of the elements to delete; an example file is:

```json
{
    "cropPlanType": "THE-CROP-PLAN-TYPE",
    "anomScenarioConfig": [
        {
            "scenario": "SCENARIO_1"
        }
    ]
}
```

### anomScenarioDisableFuncConfig Functions that can be disabled

Enum of functions:

```
{
	ADD_DECLARATIONS,
	CUT_PLOTS,
	DELETE_DECLARATIONS,
	DELETE_PLOTS,
	EDIT_DECLARATIONS,
	EDIT_PLOTS,
	MERGE_DECLARATIONS,
	REPROPORTION_DECLARATIONS
}
```

On Private Api:
value: ADD_DECLARATIONS -> createDeclaration, createDeclarations
value: CUT_PLOTS -> cutPlotsByLine, cutPlotsByGeometries
value: DELETE_DECLARATIONS -> deleteDeclaration, deleteDeclarations
value: DELETE_PLOTS -> deletePlot
value: EDIT_DECLARATIONS -> updateDeclaration
value: EDIT_PLOTS -> updatePlots, updatePlot
value: MERGE_DECLARATIONS -> mergeDeclarations
value: REPROPORTION_DECLARATIONS -> reproportionDecls

On Public Api:
value: ADD_DECLARATIONS -> createDeclaration, createDeclarations
value: EDIT_DECLARATIONS -> updateDeclaration
value: DELETE_DECLARATIONS -> deleteDeclaration
