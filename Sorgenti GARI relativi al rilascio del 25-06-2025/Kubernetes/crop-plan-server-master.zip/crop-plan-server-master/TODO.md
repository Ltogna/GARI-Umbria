# SDK

## Plugins


- Anagrafica
    - Business list (ma serve davvero)
    - Business details
- Autorizzazioni
    - utente/soggetto (mandato)
    - Permessi (can create/can read/can write piano)
    - Autenticazione
- Domini
    - Snap polygons
    - Snap polygon types
    - Elenco domini
    - Parcelle di riferimento
    - Dato una List di parcelCode, tornare una mappa di parcel code, description (vedi parcelName)
    - Layer e server WMS/WMTS/...
- Codici (CropCodes)
    - Land uses
    - Land cover
    - Matrici (esup)

# API

- Decidere se: Can delete declaration: torna si/no e eventuali motivi del no


# Documentazione

- api: Declaration da fare 

https://github.com/OpenAPITools/openapi-generator
```
java -jar openapi-generator-cli.jar generate -i http://localhost:8080/openapi.json -g html
```