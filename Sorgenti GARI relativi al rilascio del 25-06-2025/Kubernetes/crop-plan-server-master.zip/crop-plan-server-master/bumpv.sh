#!/bin/bash

usage="Utilizzo: bumpv.sh major|minor|patch|-v {version} [-s {settings_file}] [-p|--package]"

# Funzione per dividere la versione
function split_version() {
  version=$1
  major=$(echo "$version" | cut -d. -f1)
  minor=$(echo "$version" | cut -d. -f2)
  patch=$(echo "$version" | cut -d. -f3)
}

# Funzione per incrementare la versione di una major
function increase_major() {
  major=$((major + 1))
  minor=0
  patch=0
}

# Funzione per incrementare la versione di una minor
function increase_minor() {
  minor=$((minor + 1))
  patch=0
}

# Funzione per incrementare la versione di una patch
function increase_patch() {
  patch=$((patch + 1))
}

# Inizializza variabili
increment_option=""
settings_file=""
make_jar=false
unset forced_new_version

# Leggi i flag dalla riga di comando
while test $# -gt 0; do
  case "$1" in
    major|minor|patch)
      # Leggi l'opzione di incremento dalla riga di comando (major, minor o patch)
      increment_option=$1
      shift
      ;;
    -s)
      shift
      if test $# -gt 0; then
        export settings_file=$1
      else
        echo "no settings file specified"
        exit 1
      fi
      shift
      ;;
    -p|--package)
      export make_jar=true
      shift
      ;;
    -v|--new_version)
      shift
      if test $# -gt 0; then
        export forced_new_version=$1
      else
        echo "no version specified"
        exit 1
      fi
      shift
      ;;
    *)
      break
      ;;
  esac
done

if [ -z "$increment_option" ] && [ -z "$forced_new_version" ]; then
  echo "Opzione di incremento non valida. $usage"
  exit 1
fi

# Costruisci il comando Maven per ottenere la versione corrente
mvn_evaluate_command="mvn help:evaluate -Dexpression=project.version -q -DforceStdout"
if [ -n "$settings_file" ]; then
  mvn_evaluate_command="$mvn_evaluate_command -s $settings_file"
fi

# Esegui il comando Maven e cattura l'output
current_version=$(eval "$mvn_evaluate_command")

# Verifica se la versione corrente è stata ottenuta correttamente
if [ -z "$current_version" ]; then
  echo "Errore: impossibile ottenere la versione corrente dal file pom.xml"
  exit 1
fi

echo "current version: $current_version"

if [ -z "$forced_new_version" ];
then
  # Dividi la versione in major, minor e patch
  split_version "$current_version"

  # Incrementa la versione corrispondente all'opzione specificata
  case $increment_option in
    major)
      increase_major
      ;;
    minor)
      increase_minor
      ;;
    patch)
      increase_patch
      ;;
    *)
      echo "Opzione di incremento non valida. $usage"
      exit 1
      ;;
  esac

  # Componi la nuova versione
  new_version="$major.$minor.$patch"
else
  new_version=$forced_new_version
fi

echo "new version: $new_version"

# Costruisci i comandi Maven con il file di settings opzionale
mvn_set_command="mvn versions:set -DnewVersion=$new_version"
mvn_commit_command="mvn versions:commit"

if [ -n "$settings_file" ]; then
  mvn_set_command="$mvn_set_command -s $settings_file"
  mvn_commit_command="$mvn_commit_command -s $settings_file"
fi

# Esegui i comandi Maven
eval "$mvn_set_command"
eval "$mvn_commit_command"

echo "Versione aggiornata: $new_version"

readmeFile="README.md"
line=$(grep -m 1 -n "_version: v" $readmeFile | cut -d : -f 1)

# Sovrascrivere la linea con la versione solo se la grep ha trovato una corrispondenza e la variabile line non è vuota
if [ $? -eq 0 ] && [ -n "$line" ]; then
  sed -i "${line}s/.*/_version: v${new_version}_/" $readmeFile
  echo "aggiornato $readmeFile"
fi

# Esegui mvn clean package -DskipTests se il flag -p o --package è presente
if [ "$make_jar" == "true" ]; then
  mvn_package_command="mvn clean package -DskipTests"
  if [ -n "$settings_file" ]; then
    mvn_package_command="$mvn_package_command -s $settings_file"
  fi
  eval "$mvn_package_command"
fi
