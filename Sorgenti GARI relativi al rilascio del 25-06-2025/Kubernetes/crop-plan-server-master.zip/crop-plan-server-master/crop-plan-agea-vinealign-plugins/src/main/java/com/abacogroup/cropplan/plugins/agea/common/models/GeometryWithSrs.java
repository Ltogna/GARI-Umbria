package com.abacogroup.cropplan.plugins.agea.common.models;

import lombok.Data;
import org.locationtech.jts.geom.Geometry;

@Data
public class GeometryWithSrs {
	private Geometry geometry;
	private String srs;
}
