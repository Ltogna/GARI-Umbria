package com.abacogroup.cropplan.plugins.agea.olivealign.dao;

import com.abacogroup.cropplan.plugins.agea.common.models.ntt.ExternalFormData;
import com.abacogroup.jdbi.EnhancedSqlObject;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import java.util.List;

public interface CropCodesSchedarioDAO extends EnhancedSqlObject {
	@SqlQuery("SELECT uv.PKID_UNAR as externalCode, "
			+ "       uv.foglio || ' - ' || uv.particella || decode(uv.sub,' ','','/'||uv.sub) as externalDescription, "
			+ "       uv.foglio as foglio, "
			+ "       uv.particella || decode(uv.sub,' ','','/'||uv.sub) as particella, "
			+ "       null as unar "
			+ "  FROM schedbae.so_unita_arboree uv "
			+ " WHERE uv.PKID_UNAR in (<externalCodeList>) ")
	@RegisterBeanMapper(ExternalFormData.class)
	List<ExternalFormData> getExternalCodeDescription(@BindList("externalCodeList") List<String> externalCodeList);
}
