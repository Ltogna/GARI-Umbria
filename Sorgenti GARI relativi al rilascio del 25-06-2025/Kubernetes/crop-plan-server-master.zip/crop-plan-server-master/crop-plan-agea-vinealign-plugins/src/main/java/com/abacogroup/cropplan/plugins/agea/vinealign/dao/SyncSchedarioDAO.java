package com.abacogroup.cropplan.plugins.agea.vinealign.dao;

import com.abacogroup.cropplan.plugins.agea.common.models.ntt.SitiUnar;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormData;
import com.abacogroup.jdbi.EnhancedSqlObject;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import java.util.List;

public interface SyncSchedarioDAO extends EnhancedSqlObject {
	@SqlQuery("SELECT sp.ID_PARCELLA AS sp_idParcella, \n"
			+ "       sp.COD_NAZIONALE AS sp_codNazionale, \n"
			+ "       su.foglio AS sup_foglio, \n"
			+ "       sp.cod_parcella AS sp_codParcella, \n"
			+ "       sp.SHAPE_LAYER_B AS sp_shape, \n"
			+ "       DECODE (su.GIORNO_IMPI, 0, NULL, su.GIORNO_IMPI) AS su_giornoImpi, \n"
			+ "       DECODE (su.MESE_IMPI, 0, NULL, su.MESE_IMPI) AS su_meseImpi, \n"
			+ "       DECODE (su.ANNO_IMPI, 0, NULL, su.ANNO_IMPI) AS su_annoImpi, \n"
			+ "       COALESCE ( \n"
			+ "           (SELECT codice AS code \n"
			+ "              FROM sitiunar_deco \n"
			+ "             WHERE nome_campo = 'COD_VARIETA' \n"
			+ "               AND tipo_unar = 1 \n"
			+ "               AND flag = 11 \n"
			+ "               AND codice = su.COD_VARIETA \n"
			+ "               AND ROWNUM = 1), \n"
			+ "       '000') AS su_codVarieta, \n"
			+ "       su.AREA_SQM AS su_areaSqm, \n"
			+ "       su.SESTO_SU_FILA AS pcfd_distanceOnTheRowCm, \n"
			+ "       su.SESTO_TRA_FILE AS pcfd_distanceBetweenRowsCm, \n"
			+ "       su.NUM_CEPPI AS pcfd_stumpsNumber, \n"
			+ "       su.FORMA_ALL AS pcfd_farmingForm, \n"
			+ "       su.FLAG_IRRI AS pcfd_irrigation, \n"
			+ "       su.COD_DEST_PROD AS pcfd_productDestinationCode, \n"
			+ "       su.COD_TIPO_COLT AS pcfd_cultivationTypeCode, \n"
			+ "       su.COD_TIPO_VARI AS pcfd_variationTypeCode, \n"
			+ "       su.COD_TIPO_VIGN AS pcfd_vineyardTypeCode, \n"
//			+ "       su.TIPO_IMPI AS pcfd_plantingType, \n"
			+ "       su.GIACITURA AS pcfd_layering, \n"
			+ "       su.ROCCIA AS pcfd_rock, \n"
			+ "       su.SCHELETRO AS pcfd_skeleton, \n"
			+ "       su.STATO_VEGETATIVO AS pcfd_vegetativeState, \n"
			+ "       su.POTATURA AS pcfd_pruning, \n"
			+ "       su.GIUDIZIO AS pcfd_judgement, \n"
			+ "       su.DENS_CEPPI AS pcfd_stumpsDensity100, \n"
			+ "       su.FALLANZE_PERC AS pcfd_failuresPerc, \n"
			+ "       su.GIACITURA_TERRENO AS pcfd_soilLayeringPerc, \n"
			+ "       CASE WHEN su.ALTITUDINE_SLM = '0' THEN NULL ELSE su.ALTITUDINE_SLM END AS pcfd_altitudeAboveSeaLevel, \n"
			+ "       su.TERRAZZAMENTI AS pcfd_terracing, \n"
			+ "       su.ANCORAGGI_TESTATA AS pcfd_headerAnchoring, \n"
			+ "       su.PALI_TESTATA AS pcfd_polesHeader, \n"
			+ "       su.PALI_TESSITURA AS pcfd_polesWeaving, \n"
			+ "       CASE WHEN su.DISTANZA_PALI = '0' THEN NULL ELSE su.DISTANZA_PALI END AS pcfd_polesDistanceCm, \n"
			+ "       su.FILI_SOSTEGNO AS pcfd_supportWires, \n"
			+ "       su.COD_STATO_COLT AS pcfd_cultivationState, \n"
			+ "       su.FLAG_PROVENIENZA AS pcfd_origin, \n"
			+ "       su.DATA_SOVRAINNESTO AS pcfd_graftDate, \n"
			+ "       su.PORTA_INNESTO AS pcfd_graftHolder, \n"
			+ "       su.COPERTURA AS pcfd_covering, \n"
			+ "       su.FL_BIO AS pcfd_bio, \n"
			+ "       (SELECT LISTAGG (sui.codice_iscrizione, ',') WITHIN GROUP (ORDER BY sui.codice_iscrizione) \n"
			+ "          FROM SV_UNAR_ISCRIZIONI sui \n"
			+ "         WHERE sui.pkid_unar = su.PKID_UNAR) AS pcfd_subscriptionCodes, \n"
			+ "       su.PKID_UNAR AS pcfd_externalCode, \n"
			+ "       su.foglio || ' - ' || sp.cod_parcella AS pcfd_externalDescription \n"
			+ "  FROM sv_unar_link_parcelle UP, sv_unar_link_cuaa t3, unita_vitate su, SV_PARCELLE_IMPORT sp \n"
			+ " WHERE t3.CUAA = :cuaa \n"
			+ "   AND UP.PKID_UNAR = su.PKID_UNAR \n"
			+ "   AND su.AREA_SQM IS NOT NULL \n"
			+ "   AND su.AREA_SQM > 0 \n"
			+ "   AND sp.ID_PARCELLA = UP.ID_PARCELLA \n"
			+ "   AND UP.PKID_UNAR = t3.PKID_UNAR \n"
			+ "   AND sp.COD_NAZIONALE IS NOT NULL \n"
			+ "   AND sp.FOGLIO IS NOT NULL \n"
			+ "   AND sp.ISTATR NOT IN ('01','03', '05','09') \n"
			+ "   AND istatp NOT IN ('021')") // escludo il VENETO
	@RegisterBeanMapper(SitiUnar.class)
	@RegisterBeanMapper(PermanentCropFormData.class)
	List<SitiUnar> getSitiUnar(
			@Bind("cuaa") String cuaa);
}
