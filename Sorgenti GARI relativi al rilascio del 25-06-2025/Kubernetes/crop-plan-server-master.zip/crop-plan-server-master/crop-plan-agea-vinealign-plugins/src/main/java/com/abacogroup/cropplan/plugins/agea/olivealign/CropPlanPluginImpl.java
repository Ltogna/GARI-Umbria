package com.abacogroup.cropplan.plugins.agea.olivealign;

import static java.util.stream.Collectors.toList;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

import com.abacogroup.cropplan.plugins.agea.common.enums.AlignmentStatus;
import com.abacogroup.cropplan.plugins.agea.common.models.VinealignStatusResult;
import com.abacogroup.cropplan.plugins.agea.olivealign.dao.CropCodesSchedarioDAO;
import com.abacogroup.cropplan.sdk.model.CropPlanConfigData;
import com.abacogroup.cropplan.sdk.model.CropPlanVersion;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormExternalCodeDecode;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormSubscription;
import com.abacogroup.cropplan.sdk.model.PublishVersionResult;
import com.abacogroup.cropplan.sdk.spi.CropPlanPlugin;
import com.abacogroup.dropwizard.auth.sso2.UserFunction;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import jakarta.ws.rs.core.MediaType;

public class CropPlanPluginImpl implements CropPlanPlugin, InitializablePlugin {
	private static final String VINEALIGN_URL = "vinealignURL";
	private static final String VINEALIGN_CONTEXT = "VINEALIGN";
	private static final String VINEALIGN_EDITOR_FUNCTION = "EDITOR";
	private static final String VINEALIGN_BACKOFFICE_FUNCTION = "BACKOFFICE";

	private static final String JDBI_NAME_SCHEDARIO = "dbSchedario";
	private CropCodesSchedarioDAO cropCodesSchedarioDAO;

	@Override
	public void initialize(PluginsEnvironment env) {
		var jdbiSchedario = env.getJdbi(JDBI_NAME_SCHEDARIO);
		if (jdbiSchedario == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SCHEDARIO);

		cropCodesSchedarioDAO = jdbiSchedario.onDemand(CropCodesSchedarioDAO.class);
	}

	@Override
	public boolean isReadOnly(RuntimeEnvironment env, String businessId, Long cropPlanId) {
		var vinealignUrl = env.getProperty(VINEALIGN_URL);
		if (vinealignUrl == null) {
			return true;
		}

		try (var response = env.getAuthenticatedWebTarget(vinealignUrl.toString())
				.path("public")
				.path("v1")
				.path("vine-align")
				.path(businessId)
				.path("alignment-status")
				.request(MediaType.APPLICATION_JSON)
				.get()) {

			if (response.getStatus() != 200)
				throw new IllegalStateException("Unexpected response status: " + response.getStatus());

			var resData = response.readEntity(VinealignStatusResult.class);

			return resData.getFlInProgress() ||
					resData.getCurrentStatus() == AlignmentStatus.TO_DO ||
					resData.getCurrentStatus() == AlignmentStatus.GRAPHIC_VALIDATION ||
					resData.getCurrentStatus() == AlignmentStatus.GRAPHIC_VALIDATION_COMPLETED ||
					resData.getCurrentStatus() == AlignmentStatus.COMPLETED ||
					checkIfInProgressOrAnmCorrectiveAndUserIsVinealignEditor(env, resData) ||
					checkIfInValidationAndUserIsVinealignBackoffice(env, resData);
		}
	}

	private boolean checkIfInValidationAndUserIsVinealignBackoffice(RuntimeEnvironment env, VinealignStatusResult resData) {
		return resData.getCurrentStatus() == AlignmentStatus.IN_VALIDATION &&
				!env.getSso2Client().isFunctionEnabled(env.getUser(), new UserFunction(VINEALIGN_CONTEXT, VINEALIGN_BACKOFFICE_FUNCTION));
	}

	private boolean checkIfInProgressOrAnmCorrectiveAndUserIsVinealignEditor(RuntimeEnvironment env, VinealignStatusResult resData) {
		return (resData.getCurrentStatus() == AlignmentStatus.IN_PROGRESS || resData.getCurrentStatus() == AlignmentStatus.ANOMALIES_CORRECTIVE) &&
				!env.getSso2Client().isFunctionEnabled(env.getUser(), new UserFunction(VINEALIGN_CONTEXT, VINEALIGN_EDITOR_FUNCTION));
	}

	@Override
	public boolean canAddPlots(RuntimeEnvironment env, String businessId, Long cropPlanId) {
		var vinealignUrl = env.getProperty(VINEALIGN_URL);
		if (vinealignUrl == null) {
			return false;
		}

		try (var response = env.getAuthenticatedWebTarget(vinealignUrl.toString())
				.path("public")
				.path("v1")
				.path("vine-align")
				.path(businessId)
				.path("alignment-status")
				.request(MediaType.APPLICATION_JSON)
				.get()) {

			if (response.getStatus() != 200)
				throw new IllegalStateException("Unexpected response status: " + response.getStatus());

			var resData = response.readEntity(VinealignStatusResult.class);

			return !resData.getFlInProgress() &&
					resData.getCurrentStatus() == AlignmentStatus.IN_PROGRESS;
		}
	}

	@Override
	public boolean isExternalChangesPending(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime latestVersionDt) {
		return false;
	}

	@Override
	public CompletionStage<PublishVersionResult> publishVersion(RuntimeEnvironment env, String businessId, Long cropPlanId, String version) {
		return CompletableFuture.completedFuture(new PublishVersionResult(true));
	}

	@Override
	public List<PermanentCropFormSubscription> getPermanentCropFormSubscriptions(RuntimeEnvironment env, String externalCode, List<String> subscriptionCodes) {
		return new ArrayList<>();
	}

	@Override
	public List<PermanentCropFormExternalCodeDecode> getPermanentCropFormExternalCodeDescription(RuntimeEnvironment env, List<String> externalCodeList) {
		List<PermanentCropFormExternalCodeDecode> ret = new ArrayList<>();

		if (externalCodeList != null && !externalCodeList.isEmpty()) {
			var externalFormDataList = cropCodesSchedarioDAO.getExternalCodeDescription(externalCodeList);
			ret = externalFormDataList.stream().map(externalFormData -> {
				String sorting = String.format("%05d", externalFormData.getFoglio()) + externalFormData.getParticella();
				return new PermanentCropFormExternalCodeDecode(externalFormData.getExternalCode(), externalFormData.getExternalDescription(), sorting);
			}).collect(toList());
		}

		return ret;
	}

	@Override
	public Map<String, String> getVersionsMessagesExt(RuntimeEnvironment env, String businessId, Long cropPlanId, List<CropPlanVersion> versions) {
		return new HashMap<>();
	}

	@Override
	public List<CropPlanConfigData> getCropPlanConfig(RuntimeEnvironment env, String businessId, Long cropPlanId, List<CropPlanConfigData> cropPlanConfigs) {
		return cropPlanConfigs;
	}

	@Override
	public String getCropPlanType() {
		return "OLIVEALIGN";
	}

}
