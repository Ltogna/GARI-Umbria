package com.abacogroup.cropplan.plugins.agea.common.models;

import com.abacogroup.cropplan.sdk.model.layers.CuttableLayer;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.locationtech.jts.geom.Geometry;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CuttableLayerWithGeoms {

	private CuttableLayer cuttableLayer;
	private List<Geometry> geometries;

}
