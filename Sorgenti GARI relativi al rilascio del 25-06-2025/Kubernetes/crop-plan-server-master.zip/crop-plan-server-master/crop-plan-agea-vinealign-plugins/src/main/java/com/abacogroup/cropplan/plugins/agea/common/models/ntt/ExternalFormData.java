package com.abacogroup.cropplan.plugins.agea.common.models.ntt;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExternalFormData {
	private String externalCode;
	private String externalDescription;
	private Integer foglio;
	private String particella;
	private Integer unar;
}
