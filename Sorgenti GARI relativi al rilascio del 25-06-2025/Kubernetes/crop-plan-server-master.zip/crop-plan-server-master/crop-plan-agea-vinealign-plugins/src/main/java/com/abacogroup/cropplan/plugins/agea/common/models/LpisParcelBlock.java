package com.abacogroup.cropplan.plugins.agea.common.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LpisParcelBlock {
	private String short_descr;
}
