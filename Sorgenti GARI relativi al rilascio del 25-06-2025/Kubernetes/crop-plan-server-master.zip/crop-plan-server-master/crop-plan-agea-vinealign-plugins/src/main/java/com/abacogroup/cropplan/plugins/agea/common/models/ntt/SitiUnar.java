package com.abacogroup.cropplan.plugins.agea.common.models.ntt;

import java.time.LocalDate;

import org.jdbi.v3.core.mapper.Nested;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.cropplan.sdk.model.PermanentCropFormData;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SitiUnar
{
	private String sp_idParcella;
	private String sp_codNazionale; 
	private String sup_foglio;
	private String sp_codParcella;
	private Geometry sp_shape;
	
	private Integer su_giornoImpi;
	private Integer su_meseImpi;
	private Integer su_annoImpi;
	private String su_codVarieta;
	private Integer su_areaSqm;

	private PermanentCropFormData permanentCropFormData;

	@Nested("pcfd")
	public PermanentCropFormData getPermanentCropFormData()
	{
		return permanentCropFormData;
	}

	public LocalDate getDayFrom()
	{
		if (getSu_annoImpi() == null)
			return LocalDate.of(1970, 3, 1);
		if (getSu_meseImpi() == null)
			return LocalDate.of(getSu_annoImpi(), 3, 1);
		if (getSu_giornoImpi() == null)
			return LocalDate.of(getSu_annoImpi(), getSu_meseImpi(), 1);
		return LocalDate.of(getSu_annoImpi(), getSu_meseImpi(), getSu_giornoImpi());
	}
	
	public String getLandUseCode()
	{
		return getSu_codVarieta();
	}
	
	public Integer getAreaSqm()
	{
		return getSu_areaSqm();
	}
	
	public String getDayFromPrecision()
	{
		if (getSu_annoImpi() == null)
			return "-";
		if (getSu_meseImpi() == null)
			return "YM";
		if (getSu_giornoImpi() == null)
			return "YM";
		return "YMD";
	}	
}
