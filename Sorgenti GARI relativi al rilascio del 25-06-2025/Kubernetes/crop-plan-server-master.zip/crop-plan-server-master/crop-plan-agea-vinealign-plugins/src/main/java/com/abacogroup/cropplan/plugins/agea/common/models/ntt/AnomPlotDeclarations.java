package com.abacogroup.cropplan.plugins.agea.common.models.ntt;

import lombok.Data;

@Data
public class AnomPlotDeclarations {
    private String plotCode;
    private String declCode;
}
