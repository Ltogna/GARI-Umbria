package com.abacogroup.cropplan.plugins.agea.common;

import com.abacogroup.cropplan.plugins.agea.common.dao.BusinessSchedarioDAO;
import com.abacogroup.cropplan.sdk.model.business.Business;
import com.abacogroup.cropplan.sdk.spi.BusinessPlugin;
import com.abacogroup.dropwizard.auth.sso2.UserFunction;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.MaxRowsResults;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import java.util.List;

public class BusinessPluginImpl implements BusinessPlugin, InitializablePlugin {

	private static final String JDBI_NAME_SCHEDARIO = "dbSchedario";

	private static final String LDAP_DEFAULT_GROUP = "GEST_SCHEDARIO_FO";

	private static final List<String> LDAP_REG_GROUPS = List.of("GEST_SCHEDARIO_BO_REGI", "SCHEDARIO_BO_REGI_CONS");

	private static final int PAGE_SIZE = 50;

	private BusinessSchedarioDAO businessSchedarioDAO;

	@Override
	public void initialize(PluginsEnvironment env) {
		var jdbiSitiknow = env.getJdbi(JDBI_NAME_SCHEDARIO);
		if (jdbiSitiknow == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SCHEDARIO);

		businessSchedarioDAO = jdbiSitiknow.onDemand(BusinessSchedarioDAO.class);
	}

	@Override
	public Business getBusinessDetails(RuntimeEnvironment env, String businessId) {
		final boolean onlyEmpowered = !canIgnoreProxies(env);

		String upperCaseTenant = env.getTenantId().toUpperCase();

		switch (upperCaseTenant) {
		case "VINE":
			return businessSchedarioDAO.getBusiness(businessId, LDAP_DEFAULT_GROUP, LDAP_REG_GROUPS, env.getUserName(), onlyEmpowered);
		case "FRUIT":
			return businessSchedarioDAO.getFruitBusiness(businessId, LDAP_DEFAULT_GROUP, LDAP_REG_GROUPS, env.getUserName(), onlyEmpowered);
		case "OLIVE":
			return businessSchedarioDAO.getOliveBusiness(businessId, LDAP_DEFAULT_GROUP, LDAP_REG_GROUPS, env.getUserName(), onlyEmpowered);
		default:
			throw new IllegalStateException("Unexpected tenant detected.");
		}
	}

	@Override
	public MaxRowsResults<Business> searchBusinesses(RuntimeEnvironment env, String search) {
		final boolean onlyEmpowered = !canIgnoreProxies(env);

		String upperCaseTenant = env.getTenantId().toUpperCase();

		switch (upperCaseTenant) {
		case "VINE":
			return businessSchedarioDAO.maxRows(
					() -> businessSchedarioDAO.getBusinesses(env.getUserName(), search, LDAP_DEFAULT_GROUP, LDAP_REG_GROUPS, onlyEmpowered), PAGE_SIZE);
		case "FRUIT":
			return businessSchedarioDAO.maxRows(
					() -> businessSchedarioDAO.getFruitBusinesses(env.getUserName(), search, LDAP_DEFAULT_GROUP, LDAP_REG_GROUPS, onlyEmpowered), PAGE_SIZE);
		case "OLIVE":
			return businessSchedarioDAO.maxRows(
					() -> businessSchedarioDAO.getOliveBusinesses(env.getUserName(), search, LDAP_DEFAULT_GROUP, LDAP_REG_GROUPS, onlyEmpowered), PAGE_SIZE);
		default:
			throw new IllegalStateException("Unexpected tenant detected.");
		}
	}

	@Override
	public InfiniteListResults<Business> searchBusinessesInfinite(RuntimeEnvironment env, String search, String nextKey) {
		final boolean onlyEmpowered = !canIgnoreProxies(env);

		String upperCaseTenant = env.getTenantId().toUpperCase();

		switch (upperCaseTenant) {
		case "VINE":
			return businessSchedarioDAO.infinite(
					() -> businessSchedarioDAO.getBusinesses(env.getUserName(), search, LDAP_DEFAULT_GROUP, LDAP_REG_GROUPS, onlyEmpowered), nextKey,
					PAGE_SIZE);
		case "FRUIT":
			return businessSchedarioDAO.infinite(
					() -> businessSchedarioDAO.getFruitBusinesses(env.getUserName(), search, LDAP_DEFAULT_GROUP, LDAP_REG_GROUPS, onlyEmpowered), nextKey,
					PAGE_SIZE);
		case "OLIVE":
			return businessSchedarioDAO.infinite(
					() -> businessSchedarioDAO.getOliveBusinesses(env.getUserName(), search, LDAP_DEFAULT_GROUP, LDAP_REG_GROUPS, onlyEmpowered), nextKey,
					PAGE_SIZE);
		default:
			throw new IllegalStateException("Unexpected tenant detected.");
		}
	}

	private boolean canIgnoreProxies(RuntimeEnvironment env) {
		return env.getSso2Client().isFunctionEnabled(env.getUser(), UserFunction.fromPipeSeparatedString("CRPL|IGNORE_PARTIES_ACL"));
	}
}
