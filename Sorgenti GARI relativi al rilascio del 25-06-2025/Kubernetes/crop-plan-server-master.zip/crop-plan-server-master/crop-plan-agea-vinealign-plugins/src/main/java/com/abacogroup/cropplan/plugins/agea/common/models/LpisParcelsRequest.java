package com.abacogroup.cropplan.plugins.agea.common.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.locationtech.jts.geom.Geometry;

@AllArgsConstructor
@Data
public class LpisParcelsRequest {
	private Geometry geom;
	private String srs;
}
