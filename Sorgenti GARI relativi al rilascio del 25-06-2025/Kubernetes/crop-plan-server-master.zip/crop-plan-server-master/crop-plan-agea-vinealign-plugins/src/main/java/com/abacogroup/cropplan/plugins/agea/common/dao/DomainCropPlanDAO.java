package com.abacogroup.cropplan.plugins.agea.common.dao;

import com.abacogroup.cropplan.plugins.agea.common.models.GeometryWithSrs;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import com.abacogroup.cropplan.sdk.model.domain.HoldingArea;
import com.abacogroup.jdbi.EnhancedSqlObject;

public interface DomainCropPlanDAO extends EnhancedSqlObject {
	@SqlQuery("SELECT sum(cpd.AREA_SQM) as areaSqm \n"
			+ "  FROM CRPL_PLANS cp, CRPL_PLOT_DATA cpd \n"
			+ " WHERE cp.BUSINESS_ID = :businessId \n"
			+ "   AND cp.TYPE_ID = (SELECT ct.id FROM CRPL_TYPES ct WHERE §current_timestamp§ BETWEEN ct.DT_INSERT AND ct.DT_DELETE AND ct.TENANT_ID = :tenantId) \n"
			+ "   AND §current_timestamp§ BETWEEN cp.DT_INSERT AND cp.DT_DELETE  \n"
			+ "   AND cpd.PLAN_ID = cp.id \n"
			+ "   AND §current_timestamp§ BETWEEN cpd.DT_INSERT AND cpd.DT_DELETE  \n"
			+ "   AND :pointInTime BETWEEN cpd.DAY_FROM AND cpd.DAY_TO")
	@RegisterBeanMapper(HoldingArea.class)
	HoldingArea getHoldingArea(@Bind("businessId") String businessId,
			@Bind("pointInTime") String pointInTime,
			@Bind("tenantId") String tenantId);

	@SqlQuery("SELECT sum(cpd.AREA_SQM) as areaSqm \n"
			+ "  FROM CRPL_PLANS cp, CRPL_PLOTS cpl, CRPL_PLOT_DATA cpd \n"
			+ " WHERE cp.BUSINESS_ID = :businessId \n"
			+ "   AND cp.TYPE_ID = (SELECT ct.id FROM CRPL_TYPES ct WHERE §current_timestamp§ BETWEEN ct.DT_INSERT AND ct.DT_DELETE AND ct.TENANT_ID = :tenantId) \n"
			+ "   AND §current_timestamp§ BETWEEN cp.DT_INSERT AND cp.DT_DELETE  \n"
			+ "   AND cpl.PLAN_ID = cp.ID \n"
			+ "   AND cpl.DOMAIN_ZONE_ID = :domainZoneId \n"
			+ "   AND cpd.PLAN_ID = cp.id \n"
			+ "   AND cpd.PLOT_CODE = cpl.PLOT_CODE  \n"
			+ "   AND §current_timestamp§ BETWEEN cpd.DT_INSERT AND cpd.DT_DELETE  \n"
			+ "   AND :pointInTime BETWEEN cpd.DAY_FROM AND cpd.DAY_TO")
	@RegisterBeanMapper(HoldingArea.class)
	HoldingArea getHoldingAreaByDomainZones(@Bind("businessId") String businessId,
			@Bind("domainZoneId") String domainZoneId, @Bind("pointInTime") String pointInTime,
			@Bind("tenantId") String tenantId);

	@SqlQuery("select st_buffer(st_union(cpd.geom),5,'endcap=round join=round') as geometry, cpd.srs as srs \n"
			+ "  from crpl_plans c, crpl_plots cp, crpl_plot_data cpd \n"
			+ " where c.business_id = :businessId \n"
			+ "   and §current_timestamp§ between c.dt_insert and c.dt_delete \n"
			+ "   and c.type_id = (SELECT ct.id FROM CRPL_TYPES ct WHERE §current_timestamp§ BETWEEN ct.DT_INSERT AND ct.DT_DELETE AND ct.TENANT_ID = :tenantId) \n"
			+ "   and cp.plan_id = c.id \n"
			+ "   and cp.domain_zone_id = :domainZoneId \n"
			+ "   and cpd.plan_id = cp.plan_id  \n"
			+ "   and cpd.plot_code = cp.plot_code  \n"
			+ "   and §current_timestamp§ between cpd.dt_insert and cpd.dt_delete  \n"
			+ "   and :pointInTime between cpd.day_from and cpd.day_to \n"
			+ " group by cpd.srs")
	@RegisterBeanMapper(GeometryWithSrs.class)
	GeometryWithSrs getDomainPlotsGeom(@Bind("businessId") String businessId, @Bind("pointInTime") String pointInTime, @Bind("domainZoneId") String domainZoneId,
			@Bind("tenantId") String tenantId);
}
