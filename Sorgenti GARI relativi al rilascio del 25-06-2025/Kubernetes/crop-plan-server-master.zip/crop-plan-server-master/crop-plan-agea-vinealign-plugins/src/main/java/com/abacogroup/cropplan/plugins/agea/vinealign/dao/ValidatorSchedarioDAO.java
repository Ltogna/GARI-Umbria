package com.abacogroup.cropplan.plugins.agea.vinealign.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

public interface ValidatorSchedarioDAO extends EnhancedSqlObject {
	@SqlQuery("SELECT fonte"
			+ "  FROM SV_PARCELLE_IMPORT"
			+ " WHERE COD_NAZIONALE = :codNazionale"
			+ "   AND foglio = :foglio"
			+ "   AND COD_PARCELLA = :codParcella")
	String getFonte(@Bind("codNazionale") String codNazionale,
			@Bind("foglio") String foglio,
			@Bind("codParcella") String codParcella);
}
