package com.abacogroup.cropplan.plugins.agea.common.models.ntt;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.locationtech.jts.geom.Geometry;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DomainDeclData {
	private Geometry mbr;

	private AbsoluteDate fromDate;
	private String fromDatePrecision;
	private AbsoluteDate toDate;

	private String landUseCode;
	private String landUseDescription;

	private Integer areaSqm;
	private Double areaPerc;

	private String farmingForm;
	private String farmingFormDescription;
	private Double distanceBetweenRowsCm;
	private Double distanceOnTheRowCm;
}
