package com.abacogroup.cropplan.plugins.agea.fruitalign;

import static java.util.stream.Collectors.toList;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.locationtech.jts.geom.Geometry;

import com.abacogroup.cropplan.plugins.agea.common.models.LpisParcels;
import com.abacogroup.cropplan.plugins.agea.common.models.LpisParcelsRequest;
import com.abacogroup.cropplan.plugins.agea.common.models.ntt.SitiUnar;
import com.abacogroup.cropplan.plugins.agea.fruitalign.dao.SyncSchedarioDAO;
import com.abacogroup.cropplan.sdk.model.sync.LatestSync;
import com.abacogroup.cropplan.sdk.model.sync.SyncParcel;
import com.abacogroup.cropplan.sdk.model.sync.WizardDeclarations;
import com.abacogroup.cropplan.sdk.model.sync.WizardPermanentCropForm;
import com.abacogroup.cropplan.sdk.model.sync.WizardPlot;
import com.abacogroup.cropplan.sdk.spi.SyncPlugin;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.MediaType;

public class SyncPluginImpl implements SyncPlugin, InitializablePlugin {
	private static final String JDBI_NAME_SCHEDARIO = "dbSchedario";
	private static final String URL_LPIS = "lpisURL";

	private static final LocalDate DEFAULT_DAY_FROM = LocalDate.of(2023, 1, 1);

	private SyncSchedarioDAO syncSchedarioDAO;

	@Override
	public void initialize(PluginsEnvironment env) {
		var jdbiSchedario = env.getJdbi(JDBI_NAME_SCHEDARIO);
		if (jdbiSchedario == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SCHEDARIO);

		syncSchedarioDAO = jdbiSchedario.onDemand(SyncSchedarioDAO.class);
	}

	@Override
	public LocalDate getOldestChangesDateFromLpisDate(RuntimeEnvironment env, String businessId,
			Long cropPlanId, LocalDateTime lastSyncDt, LocalDateTime currentDt, boolean lite) {
		return DEFAULT_DAY_FROM;
	}

	@Override
	public LocalDate getNextChangesDateFromLpisDate(RuntimeEnvironment env, String businessId,
			Long cropPlanId, LocalDate pointInTime, LocalDateTime lastSyncDt, LocalDateTime currentDt, boolean lite) {
		return null;
	}

	@Override
	public List<String> getChangesFromLpis(RuntimeEnvironment env, String businessId, Long cropPlanId,
			LocalDate pointInTime, LocalDateTime lastSyncDt, LocalDateTime currentDt, boolean firstSync, boolean lite) {
		return new ArrayList<>();
	}

	@Override
	public String getChangeId(RuntimeEnvironment env, String parcelCode) {
		return parcelCode;
	}

	@Override
	public List<SyncParcel> getLpisParcelsForWizard(RuntimeEnvironment env, String businessId, Long cropPlanId,
			LocalDate pointInTime, LocalDateTime currentDt, List<String> changeIds) {
		return new ArrayList<>();
	}

	@Override
	public String getDefaultLandUseCode(RuntimeEnvironment env, LocalDate pointInTime, String parcelCode) {
		return null;
	}

	@Override
	public List<WizardPlot> getWizardPlots(RuntimeEnvironment env, String businessId, Long cropPlanId,
			LocalDateTime currentDt, boolean beforePublish) {
		if (beforePublish) {
			// var sitiUnar = syncSchedarioDAO.getSitiUnar(cuaa, beforePublish ? "1" : "2");
			var sitiUnar = syncSchedarioDAO.getSitiUnar(businessId);

			Map<String, List<SitiUnar>> plots = sitiUnar.stream()
					.collect(Collectors.groupingBy(SitiUnar::getSp_idParcella));

			List<WizardPlot> wizardPlots = new ArrayList<>();
			plots.forEach((id_parcella, plotParcels) -> wizardPlots.add(buildWizardPlot(plotParcels)));

			return wizardPlots;
		}
		return new ArrayList<>();
	}

	private WizardPlot buildWizardPlot(List<SitiUnar> plotParcels) {
		var wizardPlot = new WizardPlot();
		wizardPlot.setDomainZoneId(plotParcels.get(0).getSp_codNazionale());
		wizardPlot.setDayFrom(DEFAULT_DAY_FROM);
		wizardPlot.setGeom(plotParcels.get(0).getSp_shape());
		wizardPlot.setPlotName(
				"SF-" + plotParcels.get(0).getSp_codNazionale() + "-" + plotParcels.get(0).getSup_foglio() + "-" + plotParcels.get(0).getSp_codParcella());

		wizardPlot.setDecls(new ArrayList<>());
		plotParcels.forEach(plotParcel -> {
			WizardDeclarations wizardDeclarations = new WizardDeclarations();
			wizardDeclarations.setDayFrom(plotParcel.getDayFrom());
			wizardDeclarations.setDayTo(LocalDate.of(9999, 12, 31));
			wizardDeclarations.setLandUseCode(plotParcel.getLandUseCode());
			wizardDeclarations.setAreaSqm(plotParcel.getAreaSqm());
			wizardDeclarations.setFromDatePrecision(plotParcel.getDayFromPrecision());

			wizardDeclarations.setPcfs(new ArrayList<>());
			var wizardPermanentCropForm = new WizardPermanentCropForm();
			wizardPermanentCropForm.setFormType("VINEYARD_FORM");
			wizardDeclarations.getPcfs().add(wizardPermanentCropForm);
			wizardPermanentCropForm.setPermanentCropFormData(plotParcel.getPermanentCropFormData());

			wizardPlot.getDecls().add(wizardDeclarations);
		});

		return wizardPlot;
	}

	@Override
	public List<SyncParcel> getLpisParcelsForPlotAlign(RuntimeEnvironment env, String domainZoneId, LocalDate pointInTime, Geometry geom, String srs) {
		List<SyncParcel> syncParcels = new ArrayList<>();

		Object url = env.getProperty(URL_LPIS);
		if (url == null) {
			return syncParcels;
		}

		LpisParcels lpisParcels;
		String nextKey = null;
		do {
			var target = env.getAuthenticatedWebTarget(url.toString())
					.path(env.getTenantId())
					.path("public")
					.path("v1")
					.path("lpis")
					.path("sectors")
					.path(domainZoneId)
					.path("parcels")
					.path(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")));
			if (nextKey != null)
				target = target.queryParam("next_key", nextKey);
			try (var response = target.request(MediaType.APPLICATION_JSON)
					.post(Entity.json(new LpisParcelsRequest(geom, srs)))) {

				if (response.getStatus() != 200)
					throw new IllegalStateException("Unexpected response status: " + response.getStatus());

				lpisParcels = response.readEntity(LpisParcels.class);
				syncParcels.addAll(lpisParcels.getRecords().stream()
						.map(lp -> new SyncParcel(String.valueOf(lp.getId()), domainZoneId, lp.getGeom(), null,
								"SF-" + domainZoneId + "-" + lp.getBlock().getShort_descr() + "-" + lp.getParcel()))
						.collect(toList()));

				nextKey = lpisParcels.getNextKey();
			}

		} while (nextKey != null);

		return syncParcels;
	}

	@Override
	public boolean isRecalcAnomaliesNeeded(RuntimeEnvironment env, String businessId, Long cropPlanId,
			LocalDateTime lastSyncDt, LocalDate currentReferenceDt, LatestSync latestSync, LocalDate currentCampaignStartDt) {
		return true;
	}

	@Override
	public LocalDateTime getSyncPluginDate(RuntimeEnvironment env) {
		return null;
	}

	@Override
	public String getCropPlanType() {
		return "FRUITALIGN";
	}

}
