package com.abacogroup.cropplan.plugins.agea.common.dao;

import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseDetails;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import java.util.List;
import java.util.Optional;

public interface CrplPermCropFieldValuesDAO extends EnhancedSqlObject {
	@SqlQuery("select cpcfv.field_value as code," +
			"         coalesce(§i18n(:tenantId, 'CRPL_PERM_CROP_FIELD_VALUES', 'I18N_VALUE', cpcfv.i18n_value, :language)§, cpcfv.i18n_value) as description, " +
			"         null as defaultHarvestDays" +
			"    from crpl_perm_crop_field_values cpcfv" +
			"   where cpcfv.form_type = :formType" +
			"     and cpcfv.field_code = :fieldCode" +
			"     and cpcfv.field_value = :fieldValue" +
			"     and cpcfv.type_id = (select ct.id from crpl_types ct where ct.code = :cropPlanType and ct.tenant_id = :tenantId and §current_timestamp§ between ct.dt_insert and ct.dt_delete)")
	@RegisterBeanMapper(LandUseDetails.class)
	Optional<LandUseDetails> getLandUseCode(@Bind("tenantId") String tenantId,
			@Bind("language") String language, 
			@Bind("formType") String formType, 
			@Bind("fieldCode") String fieldCode, 
			@Bind("fieldValue") String fieldValue,
			@Bind("cropPlanType") String cropPlanType);

	@SqlQuery("select cpcfv.field_value as code," +
			"         coalesce(§i18n(:tenantId, 'CRPL_PERM_CROP_FIELD_VALUES', 'I18N_VALUE', cpcfv.i18n_value, :language)§, cpcfv.i18n_value) as description" +
			"    from crpl_perm_crop_field_values cpcfv" +
			"   where cpcfv.form_type = :formType" +
			"     and cpcfv.field_code = :fieldCode" +
			"     and cpcfv.type_id = (select ct.id from crpl_types ct where ct.code = :cropPlanType and ct.tenant_id = :tenantId and §current_timestamp§ between ct.dt_insert and ct.dt_delete)" + 
			"     and <criteria>")
	@RegisterBeanMapper(LandUse.class)
	List<LandUse> getLandUses(@Bind("tenantId") String tenantId,
			@Bind("language") String language, @Bind("formType") String formType, @Bind("fieldCode") String fieldCode, @BindCriteria Criteria criteria,
			@Bind("cropPlanType") String cropPlanType);

	@SqlQuery("select cpcfv.field_value as code," +
			"         coalesce(§i18n(:tenantId, 'CRPL_PERM_CROP_FIELD_VALUES', 'I18N_VALUE', cpcfv.i18n_value, :language)§, cpcfv.i18n_value) as description," +
			"         null as defaultHarvestDays, " +
			"         coalesce " +
			"           ( " +
			"              (§select_from_dual(1)§" +
			"                 where (cpcfv.field_value = coalesce(<favouriteLandUseCodes>, null) or cpcfv.field_value in (<favouriteLandUseCodes>)) " +
			"               ), 0 " +
			"           ) as isFavourite" +
			"    from crpl_perm_crop_field_values cpcfv" +
			"   where cpcfv.form_type = :formType" +
			"     and cpcfv.field_code = :fieldCode" +
			"     and (:search is null or (upper(cpcfv.field_value) || ' - ' || upper(§i18n(:tenantId, 'CRPL_PERM_CROP_FIELD_VALUES', 'I18N_VALUE', cpcfv.i18n_value, :language)§)) like '%'||upper(:search)||'%')" +
			"     and cpcfv.type_id = (select ct.id from crpl_types ct where ct.code = :cropPlanType and ct.tenant_id = :tenantId and §current_timestamp§ between ct.dt_insert and ct.dt_delete)" +
			"  order by isFavourite desc, description, code")
	@RegisterBeanMapper(LandUseDetails.class)
	ResultIterator<LandUseDetails> getLandUsesDetails(@Bind("tenantId") String tenantId,
			@Bind("language") String language, @Bind("formType") String formType, @Bind("fieldCode") String fieldCode, @Bind("search") String search,
			@BindList(value = "favouriteLandUseCodes", onEmpty = BindList.EmptyHandling.NULL_STRING) List<String> favouriteLandUseCodes,
			@Bind("cropPlanType") String cropPlanType);
}
