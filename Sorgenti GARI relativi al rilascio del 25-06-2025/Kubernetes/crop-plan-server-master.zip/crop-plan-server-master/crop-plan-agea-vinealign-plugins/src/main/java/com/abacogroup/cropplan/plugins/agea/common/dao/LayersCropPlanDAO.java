package com.abacogroup.cropplan.plugins.agea.common.dao;

import com.abacogroup.cropplan.plugins.agea.common.models.ntt.DomainDeclData;
import com.abacogroup.jdbi.EnhancedSqlObject;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.locationtech.jts.geom.Geometry;

import java.time.LocalDateTime;
import java.util.List;

public interface LayersCropPlanDAO extends EnhancedSqlObject {
	@SqlQuery(
			"select cp.id from crpl_plans cp where cp.business_id = :businessId and §current_timestamp§ between cp.dt_insert and cp.dt_delete and cp.type_id = "
					+ "   (select ct.id from crpl_types ct where ct.code = :cropPlanType and ct.tenant_id = :tenantId and §current_timestamp§ between ct.dt_insert and ct.dt_delete)")
	Long getCropPlanId(@Bind("tenantId") String tenantId, @Bind("businessId") String businessId, @Bind("cropPlanType") String cropPlanType);

	@SqlQuery("select §geom_mbr(cpd.geom)§ as mbr, "
			+ "       cpd.AREA_SQM as areaSqm, "
			+ "       cd.land_use_code as landUseCode, "
			+ "       cd.area_perc as areaPerc, "
			+ "       cd.day_from as fromDate, "
			+ "       cd.day_from_precision as fromDatePrecision, "
			+ "       cd.day_to as toDate,"
			+ "       CPCF.FARMING_FORM as farmingForm, "
			+ "       CPCF.DISTANCE_ON_THE_ROW_CM as distanceOnTheRowCm, "
			+ "       CPCF.DISTANCE_BETWEEN_ROWS_CM as distanceBetweenRowsCm, "
			+ "       (select coalesce(§i18n(:tenantId, 'CRPL_PERM_CROP_FIELD_VALUES', 'I18N_VALUE', cpcfv1.i18n_value, :language)§, cpcfv1.i18n_value)"
			+ "          from crpl_perm_crop_field_values cpcfv1"
			+ "         where cpcfv1.form_type = 'VINEYARD_FORM' "
			+ "           and cpcfv1.field_code = 'VARIETY_CODE' "
			+ "           and cpcfv1.field_value = cd.land_use_code "
			+ "           and cpcfv1.type_id = (select ct.id from crpl_types ct where ct.code = :cropPlanType and ct.tenant_id = :tenantId and §current_timestamp§ between ct.dt_insert and ct.dt_delete) "
			+ "       ) as landUseDescription, "
			+ "       (select coalesce(§i18n(:tenantId, 'CRPL_PERM_CROP_FIELD_VALUES', 'I18N_VALUE', cpcfv2.i18n_value, :language)§, cpcfv2.i18n_value)"
			+ "          from crpl_perm_crop_field_values cpcfv2"
			+ "         where cpcfv2.form_type = 'VINEYARD_FORM' "
			+ "           and cpcfv2.field_code = 'FARMING_FORM' "
			+ "           and cpcfv2.field_value = CPCF.FARMING_FORM "
			+ "           and cpcfv2.type_id = (select ct.id from crpl_types ct where ct.code = :cropPlanType and ct.tenant_id = :tenantId and §current_timestamp§ between ct.dt_insert and ct.dt_delete) "
			+ "       ) as farmingFormDescription "
			+ "  from crpl_plots cp, crpl_plot_data cpd, crpl_declarations cd, CRPL_PERM_CROP_FORMS CPCF"
			+ " where cp.plan_id = :cropPlanId"
			+ "   and cp.domain_zone_id = :domainZoneId"
			+ "   and cpd.plan_id = cp.plan_id"
			+ "   and cpd.plot_code = cp.plot_code"
			+ "   and :versionDt between cpd.dt_insert and cpd.dt_delete"
			+ "   and :pointInTime between cpd.day_from and cpd.day_to"
			+ "   and cd.plan_id = cpd.plan_id"
			+ "   and cd.plot_code = cpd.plot_code"
			+ "   and :versionDt between cd.dt_insert and cd.dt_delete"
			+ "   and :pointInTime between cd.day_from and cd.day_to"
			+ "   and CPCF.DECL_CODE = cd.decl_code "
			+ "   AND CPCF.PLOT_CODE = cp.plot_code "
			+ "   AND CPCF.PLAN_ID = cp.plan_id "
			+ "   AND :versionDt between CPCF.dt_insert and CPCF.dt_delete"
			+ "   and §geom_have_interactions(cpd.geom, :touchingGeometry)§")
	@RegisterBeanMapper(DomainDeclData.class)
	List<DomainDeclData> getDomainDeclsGisInfoData(
			@Bind("tenantId") String tenantId,
			@Bind("language") String language,
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTime") String pointInTime,
			@Bind("touchingGeometry") Geometry touchingGeometry,
			@Bind("cropPlanType") String cropPlanType
	);
}
