package com.abacogroup.cropplan.plugins.agea.olivealign;

import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

import com.abacogroup.cropplan.plugins.agea.common.dao.CropCodesSchedarioCommonDAO;
import com.abacogroup.cropplan.plugins.agea.common.dao.CrplPermCropFieldValuesDAO;
import com.abacogroup.cropplan.plugins.agea.common.enums.AlignmentStatus;
import com.abacogroup.cropplan.plugins.agea.common.models.VinealignStatusResult;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandCoverClassEditability;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandCoverFilter;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseClass;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseDetails;
import com.abacogroup.cropplan.sdk.model.cropcodes.Style;
import com.abacogroup.cropplan.sdk.model.domain.LandCover;
import com.abacogroup.cropplan.sdk.spi.CropCodesPlugin;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.MaxRowsResults;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

public class CropCodesPluginImpl implements CropCodesPlugin, InitializablePlugin {
	private static final String JDBI_NAME_SCHEDARIO = "dbSchedario";
	private static final String JDBI_CROP_PLAN = "mainDB";

	private static final int MAX_ROWS = 50;
	private static final int PAGE_SIZE = 50;

	private static final String LAND_COVER_CODE_VINE = "420";

	private CropCodesSchedarioCommonDAO cropCodesSchedarioCommonDAO;
	private CrplPermCropFieldValuesDAO crplPermCropFieldValuesDAO;

	private static final String VINEALIGN_URL = "vinealignURL";

	private static final String FORM_TYPE = "VINEYARD_FORM";
	private static final String FIELD_CODE = "VARIETY_CODE";

	@Override
	public void initialize(PluginsEnvironment env) {
		var jdbiSchedario = env.getJdbi(JDBI_NAME_SCHEDARIO);
		if (jdbiSchedario == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SCHEDARIO);

		cropCodesSchedarioCommonDAO = jdbiSchedario.onDemand(CropCodesSchedarioCommonDAO.class);

		var jdbiCropPlan = env.getJdbi(JDBI_CROP_PLAN);
		if (jdbiCropPlan == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_CROP_PLAN);

		crplPermCropFieldValuesDAO = jdbiCropPlan.onDemand(CrplPermCropFieldValuesDAO.class);
	}

	@Override
	public List<LandUse> getLandUses(RuntimeEnvironment env, List<String> codes) {
		Criteria criteria = CriteriaBuilder.string("field_value").in(codes);
		return crplPermCropFieldValuesDAO.getLandUses(env.getTenantId(), env.getLocale().getLanguage(), FORM_TYPE, FIELD_CODE, criteria, getCropPlanType());
	}

	@Override
	public Map<String, Style> getLandUseStyles(RuntimeEnvironment env, List<String> codes) {
		return codes.stream().collect(toMap(c -> c, c -> getDefaultStyle(env)));
	}

	@Override
	public MaxRowsResults<LandUseDetails> getLandUseCodesMaxRows(RuntimeEnvironment env, String businessId, List<String> landCoverCodes, String search,
			List<String> favouriteLandUseCodes, LocalDate pointInTime, boolean ignoreLandUseCompatibility) {

		var ret = crplPermCropFieldValuesDAO.maxRows(() -> crplPermCropFieldValuesDAO.getLandUsesDetails(env.getTenantId(),
				env.getLocale().getLanguage(), FORM_TYPE, FIELD_CODE, search, !favouriteLandUseCodes.isEmpty() ? favouriteLandUseCodes : null, getCropPlanType()), MAX_ROWS);

		ret.getRecords().forEach(landUse -> {
			var landCoverCode = getLandCoverCode(env, landUse.getCode());
			var landCover = cropCodesSchedarioCommonDAO.getLandCoverDescriptions(List.of(landCoverCode)).get(0);
			landUse.setLandUseClass(new LandUseClass(landCover.getLandCoverCode(), landCover.getLandCoverDescription(), false, false));
			landUse.setIsEditable(
					getLandCoverEditability(env, businessId, landUse.getLandUseClass().getLandUseClassCode()) != LandCoverClassEditability.NOT_EDITABLE);
		});

		return ret;
	}

	@Override
	public InfiniteListResults<LandUseDetails> getLandUseCodesInfinite(RuntimeEnvironment env, String businessId,
			List<String> landCoverCodes, String search, List<String> favouriteLandUseCodes, LocalDate pointInTime, 
			boolean ignoreLandUseCompatibility, String nextKey) {
		var ret = crplPermCropFieldValuesDAO.infinite(() -> crplPermCropFieldValuesDAO.getLandUsesDetails(env.getTenantId(),
				env.getLocale().getLanguage(), FORM_TYPE, FIELD_CODE, search, !favouriteLandUseCodes.isEmpty() ? favouriteLandUseCodes : null, getCropPlanType()), nextKey,
				PAGE_SIZE);

		ret.getRecords().forEach(landUse -> {
			var landCoverCode = getLandCoverCode(env, landUse.getCode());
			var landCover = cropCodesSchedarioCommonDAO.getLandCoverDescriptions(List.of(landCoverCode)).get(0);
			landUse.setLandUseClass(new LandUseClass(landCover.getLandCoverCode(), landCover.getLandCoverDescription(), false, false));
			if (businessId == null) // support for old public API's
				landUse.setIsEditable(true);
			else
				landUse.setIsEditable(
						getLandCoverEditability(env, businessId, landUse.getLandUseClass().getLandUseClassCode()) != LandCoverClassEditability.NOT_EDITABLE);
		});

		return ret;
	}

	@Override
	public List<String> getLandUseCodesByLandCoverCode(RuntimeEnvironment env, String landCoverCode) {
		Criteria criteria = CriteriaBuilder.number("1").eq(1);
		return crplPermCropFieldValuesDAO.getLandUses(env.getTenantId(), env.getLocale().getLanguage(), FORM_TYPE, FIELD_CODE, criteria, getCropPlanType()).stream()
				.map(LandUse::getCode).collect(toList());
	}

	@Override
	public Optional<LandUseDetails> getLandUseCode(RuntimeEnvironment env, String code, String businessId, LocalDate campaignRefDate) {
		var landUse = crplPermCropFieldValuesDAO.getLandUseCode(env.getTenantId(), env.getLocale().getLanguage(), FORM_TYPE, FIELD_CODE, code, getCropPlanType());
		if (landUse.isPresent()) {
			var landCoverCode = getLandCoverCode(env, code);
			var landCover = cropCodesSchedarioCommonDAO.getLandCoverDescriptions(List.of(landCoverCode)).get(0);
			landUse.get().setLandUseClass(new LandUseClass(landCover.getLandCoverCode(), landCover.getLandCoverDescription(), false, false));
			landUse.get().setIsEditable(
					getLandCoverEditability(env, businessId, landUse.get().getLandUseClass().getLandUseClassCode()) != LandCoverClassEditability.NOT_EDITABLE);
		}
		return landUse;
	}

	@Override
	public Map<String, String> getLandCoverDescriptions(RuntimeEnvironment env, List<String> codes) {
		List<LandCover> landCovers = cropCodesSchedarioCommonDAO.getLandCoverDescriptions(codes);
		return landCovers.stream()
				.collect(toMap(LandCover::getLandCoverCode, LandCover::getLandCoverDescription));
	}

	@Override
	public Map<String, Style> getLandCoverStyles(RuntimeEnvironment env, List<String> codes) {
		return codes.stream().collect(toMap(c -> c, c -> getDefaultStyle(env)));
	}

	@Override
	public Style getDefaultStyle(RuntimeEnvironment env) {
		return new Style("#ff00ff00", null, "#ff00ff");
	}

	@Override
	public boolean isLandUseCompatible(RuntimeEnvironment env, String code, String landCoverCode) {
		return true;
	}

	@Override
	public LandCoverClassEditability getLandCoverEditability(RuntimeEnvironment env, String businessId, String landCoverCode) {
		var vinealignUrl = env.getProperty(VINEALIGN_URL);
		if (vinealignUrl == null) {
			return LandCoverClassEditability.NOT_EDITABLE;
		}

		Response request = env.getAuthenticatedWebTarget(vinealignUrl.toString())
				.path("public")
				.path("v1")
				.path("vine-align")
				.path(businessId)
				.path("alignment-status")
				.request(MediaType.APPLICATION_JSON)
				.get();

		if (request.getStatus() != 200)
			throw new IllegalStateException("Unexpected response status: " + request.getStatus());

		var resData = request.readEntity(VinealignStatusResult.class);

		if (resData.getFlInProgress())
			return LandCoverClassEditability.NOT_EDITABLE;

		if (resData.getCurrentStatus() == AlignmentStatus.IN_PROGRESS)
			return LandCoverClassEditability.EDITABLE;

		if (resData.getCurrentStatus() == AlignmentStatus.IN_VALIDATION)
			return LandCoverClassEditability.ONLY_DECLARATIONS;
		
		/*if (resData.getCurrentStatus() == AlignmentStatus.ANOMALIES_CORRECTIVE || resData.getCurrentStatus() == AlignmentStatus.IN_VALIDATION)
			return LandCoverClassEditability.ONLY_DECLARATIONS;*/

		return LandCoverClassEditability.NOT_EDITABLE;
	}

	@Override
	public List<LandCoverFilter> getLandCoverFilters(RuntimeEnvironment env) {
		return new ArrayList<>();
	}

	@Override
	public String getLandCoverCode(RuntimeEnvironment env, String landUseCode) {
		return LAND_COVER_CODE_VINE;
	}

	@Override
	public List<String> getLandCoversOnWhichTheLandCoverIsCompatible(RuntimeEnvironment env, String landUseCode) {
		return new ArrayList<>();
	}

	@Override
	public boolean canAggregate(RuntimeEnvironment env, AbsoluteDate pointInTime, Collection<Declaration> plot1, Collection<Declaration> plot2) {
		return false;
	}

	@Override
	public String getCropPlanType() {
		return "OLIVEALIGN";
	}

	@Override
	public Optional<String> transcodeLandUseCode(RuntimeEnvironment env, String code, String landCoverCode, String businessId, LocalDate pointInTime) {
		return Optional.ofNullable(code);
	}

	@Override
	public Set<String> getDefaultLandUseCodesExcludedFromAggregation(RuntimeEnvironment env) {
		return new HashSet<>();
	}
}
