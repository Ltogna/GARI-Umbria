package com.abacogroup.cropplan.plugins.agea.common.enums;

public enum AlignmentStatus {
	TO_DO,
	IN_PROGRESS,
	GRAPHIC_VALIDATION,
	GRAPHIC_VALIDATION_COMPLETED,
	ANOMALIES_CORRECTIVE,
	IN_VALIDATION,
	COMPLETED
}
