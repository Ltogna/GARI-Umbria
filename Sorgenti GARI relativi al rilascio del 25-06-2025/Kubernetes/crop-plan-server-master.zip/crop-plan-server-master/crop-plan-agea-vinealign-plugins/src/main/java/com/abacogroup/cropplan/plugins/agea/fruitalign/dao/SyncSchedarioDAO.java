package com.abacogroup.cropplan.plugins.agea.fruitalign.dao;

import com.abacogroup.cropplan.plugins.agea.common.models.ntt.SitiUnar;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormData;
import com.abacogroup.jdbi.EnhancedSqlObject;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import java.util.List;

public interface SyncSchedarioDAO extends EnhancedSqlObject {
	@SqlQuery("SELECT sp.ID_PARCELLA AS sp_idParcella, "
			+ "       sp.COD_NAZIONALE AS sp_codNazionale, "
			+ "       su.foglio AS sup_foglio, "
			+ "       sp.cod_parcella AS sp_codParcella, "
			+ "       sp.SHAPE_LAYER_B AS sp_shape, "
			+ "       DECODE (su.ANNO_IMPI, 0, NULL, su.ANNO_IMPI) AS su_annoImpi, "
			+ "       COALESCE(su.cod_varieta, '000') AS su_codVarieta, "
			+ "       su.AREA_SQM AS su_areaSqm, "
			+ "       su.SESTO_SU_FILA AS pcfd_distanceOnTheRowCm, "
			+ "       su.SESTO_TRA_FILE AS pcfd_distanceBetweenRowsCm, "
			+ "       su.NUM_CEPPI AS pcfd_stumpsNumber, "
			+ "       su.FORMA_ALL AS pcfd_farmingForm, "
			+ "       su.FLAG_IRRI AS pcfd_irrigation, "
			+ "       su.COD_TIPO_COLT AS pcfd_cultivationTypeCode, "
			+ "       su.TIPO_IMPI AS pcfd_plantingType, "
			+ "       CASE WHEN su.ALTITUDINE_SLM = '0' THEN NULL ELSE su.ALTITUDINE_SLM END AS pcfd_altitudeAboveSeaLevel, "
			+ "       su.PKID_UNAR AS pcfd_externalCode, "
			+ "       su.foglio || ' - ' || sp.cod_parcella AS pcfd_externalDescription, "
			+ "       su.id_menzione as pcfd_qualitySystem "
			+ "FROM sf_unar_link_parcelle UP, sf_unar_link_cuaa t3, schedbae.sf_unita_arboree su, sf_PARCELLE_IMPORT sp "
			+ "WHERE t3.CUAA = :cuaa "
			+ "  AND UP.PKID_UNAR = su.PKID_UNAR "
			+ "  AND su.AREA_SQM IS NOT NULL "
			+ "  AND su.AREA_SQM > 0 "
			+ "  AND sp.ID_PARCELLA = UP.ID_PARCELLA "
			+ "  AND UP.PKID_UNAR = t3.PKID_UNAR "
			+ "  AND sp.COD_NAZIONALE IS NOT NULL "
			+ "  AND sp.FOGLIO IS NOT NULL "
			+ "  AND sp.ISTATR NOT IN ('01','03', '05','09') "
			+ "  AND istatp NOT IN ('021')") // escludo il VENETO
	@RegisterBeanMapper(SitiUnar.class)
	@RegisterBeanMapper(PermanentCropFormData.class)
	List<SitiUnar> getSitiUnar(
			@Bind("cuaa") String cuaa);
}
