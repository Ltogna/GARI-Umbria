package com.abacogroup.cropplan.plugins.agea.common.models;

import com.abacogroup.cropplan.plugins.agea.common.enums.AlignmentStatus;
import lombok.Data;

@Data
public class VinealignStatusResult {
	private AlignmentStatus currentStatus;
	private Boolean flInProgress;
}
