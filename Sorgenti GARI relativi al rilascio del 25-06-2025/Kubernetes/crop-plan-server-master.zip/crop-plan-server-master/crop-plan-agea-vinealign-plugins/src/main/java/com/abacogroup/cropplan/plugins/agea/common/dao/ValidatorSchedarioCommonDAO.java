package com.abacogroup.cropplan.plugins.agea.common.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.locationtech.jts.geom.Geometry;

import java.time.LocalDateTime;

public interface ValidatorSchedarioCommonDAO extends EnhancedSqlObject {
	@Override
	@SqlQuery("§select_from_dual(§current_timestamp§)§")
	LocalDateTime getCurrentTimestamp();

	@SqlQuery("SELECT SUM ( \n"
			+ "           ROUND ( \n"
			+ "               SDO_GEOM.SDO_AREA ( \n"
			+ "                   SDO_GEOM.sdo_intersection (:plotGeometry, p.shape, 0.005), \n"
			+ "                   0.005), \n"
			+ "               0)) as intersection_area \n"
			+ "  FROM (SELECT DISTINCT codi_nazi, \n"
			+ "                        nume_fogl, \n"
			+ "                        nume_part, \n"
			+ "                        codi_suba \n"
			+ "          FROM siticond c, aabafasc_tab fas \n"
			+ "         WHERE §current_timestamp§ BETWEEN c.DATA_INIZ_VALI \n"
			+ "               AND c.DATA_FINE_VALI \n"
			+ "               AND §current_timestamp§ BETWEEN c.data_iniz_cond \n"
			+ "               AND c.data_fine_cond \n"
			+ "               AND c.deco_stato = 1320 \n"
			+ "               AND fas.id_fasc = c.id_fasc \n"
			+ "               AND §current_timestamp§ BETWEEN fas.data_iniz_vali AND fas.data_fine_vali \n"
			+ "               AND fas.cuaa = :businessId) d, \n"
			+ "       sitipart  p \n"
			+ " WHERE d.CODI_NAZI = p.cod_nazionale \n"
			+ "   AND d.NUME_FOGL = p.foglio \n"
			+ "   AND d.nume_part = p.particella \n"
			+ "   AND NVL (TO_CHAR (d.CODI_SUBA), ' ') = p.sub \n"
			+ "   AND §current_timestamp§ BETWEEN p.data_inizio_val AND p.data_fine_val \n"
			+ "   AND sdo_relate (p.shape, :plotGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	Long getSumOfIslandsAreas(@Bind("plotGeometry") Geometry plotGeometry, @Bind("businessId") String businessId);
}
