package com.abacogroup.cropplan.plugins.agea.external_microservices.request_builders;

import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import jakarta.ws.rs.client.Invocation;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;

public class LpisGisServerRequestBuilder {
	public static Invocation.Builder buildGetListOfParcelsInSectorCodeWithTouchingGeometry(RuntimeEnvironment env, String lpisGisServerUrl, String tenantId,
			String sectorCode, String referenceDate, String nextKey) {
		WebTarget target = env.getAuthenticatedWebTarget(lpisGisServerUrl)
				.path(tenantId)
				.path("public")
				.path("v1")
				.path("lpis")
				.path("sectors")
				.path(sectorCode)
				.path("parcels")
				.path(referenceDate);

		if (nextKey != null) {
			target = target.queryParam("nextKey", nextKey);
		}

		return target.request(MediaType.APPLICATION_JSON);
	}
}
