package com.abacogroup.cropplan.plugins.agea.common.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.locationtech.jts.geom.Geometry;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LpisParcel {
	private Long id;
	private String parcel;
	private Geometry geom;
	private LpisParcelBlock block;
}
