package com.abacogroup.cropplan.plugins.agea.common.dao;

import com.abacogroup.cropplan.plugins.agea.common.models.ntt.AnomPlotDeclarations;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.cropplan.sdk.model.CropPlanConfigData;
import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormFieldConfig;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedDeclaration;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface ValidatorCropPlanDAO extends EnhancedSqlObject
{
	@Override
	@SqlQuery("§select_from_dual(§current_timestamp§)§")
	public LocalDateTime getCurrentTimestamp();

	@SqlQuery("select param_name as paramName, param_value as paramValue"
			+ "      from crpl_config cc, crpl_plans cp"
			+ "     where cp.id = :cropPlanId"
			+ "       and cc.type_id = cp.type_id"
			+ "       and (:paramName is null or param_name = :paramName)"
			+ "       and (:paramValue is null or param_value = :paramValue)")
	@RegisterBeanMapper(CropPlanConfigData.class)
	List<CropPlanConfigData> getCropPlanConfig(
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("paramName") String paramName,
			@Bind("paramValue") String paramValue);

	@SqlQuery("select description"
			+ "  from crpl_plot_names"
			+ " where plot_code = :plotCode"
			+ "   and plan_id = :planId"
			+ "   and §current_timestamp§ between dt_insert and dt_delete")
	public String getPlotDescription(@Bind("plotCode") String plotCode,
			@Bind("planId") Long planId);

	@SqlQuery("SELECT fields.FIELD_CODE as fieldCode, fields.FL_MANDATORY as flMandatory, fields.fl_editable as flEditable "
			+ "FROM CRPL_PERM_CROP_FORMS_FIELDS_CFG fields, CRPL_PERM_CROP_FORMS_CFG cfg "
			+ "WHERE cfg.LAND_USE_CLASS_CODE = :landUseClassCode "
			+ "AND cfg.FORM_TYPE = :formType "
			+ "AND cfg.TYPE_ID = (SELECT t.id FROM crpl_types t WHERE §current_timestamp§ BETWEEN t.DT_INSERT AND t.DT_DELETE AND t.TENANT_ID = :tenant) "
			+ "AND fields.PERM_CROP_FORMS_CFG_ID = cfg.ID "
			  + " and cfg.valid_from <= :pointInTime and cfg.valid_to >= :pointInTime ")
	@RegisterBeanMapper(PermanentCropFormFieldConfig.class)
	public List<PermanentCropFormFieldConfig> getPermanentCropFormsFieldsConfig(@Bind("tenant") String tenant,
			@Bind("formType") String formType, @Bind("landUseClassCode") String landUseClassCode, @Bind("pointInTime") AbsoluteDate pointInTime);

	@SqlQuery("select count(*)"
			+ "  from crpl_plot_names cpn, crpl_plot_data cpd, crpl_plans cp"
			+ " where cpn.plan_id <> :planId"
			+ "   and cpn.description = :description"
			+ "   and §current_timestamp§ between cpn.dt_insert and cpn.dt_delete"
			+ "   and cpd.plot_code = cpn.plot_code"
			+ "   and cpd.plan_id = cpn.plan_id"
			+ "   and §current_timestamp§ between cpd.dt_insert and cpd.dt_delete"
			+ "   and cp.id = cpd.plan_id"
			+ "   and §current_timestamp§ between cp.dt_insert and cp.dt_delete"
			+ "   and cp.type_id = (select ct.id from crpl_types ct where §current_timestamp§ between ct.dt_insert and ct.dt_delete and ct.tenant_id = :tenant)")
	public Integer getParcelInOtherCropPlansCount(@Bind("planId") Long planId, @Bind("description") String description, @Bind("tenant") String tenant);

	@SqlQuery("select count(*) \n"
			+ "  from CRPL_PLOT_DATA cpd, CRPL_DECLARATIONS cd, CRPL_PERM_CROP_FORMS cpcf \n"
			+ " WHERE cpd.PLAN_ID = :planId \n"
			+ "   AND §current_timestamp§ BETWEEN cpd.DT_INSERT AND cpd.DT_DELETE \n"
			+ "   AND cd.PLAN_ID = cpd.PLAN_ID \n"
			+ "   AND cd.PLOT_CODE = cpd.PLOT_CODE \n"
			+ "   AND §current_timestamp§ BETWEEN cd.DT_INSERT AND cd.DT_DELETE \n"
			+ "   AND cd.decl_code <> :declCode \n"
			+ "   AND cpcf.PLAN_ID = cd.PLAN_ID \n"
			+ "   AND cpcf.PLOT_CODE = cd.PLOT_CODE \n"
			+ "   AND cpcf.DECL_CODE = cd.DECL_CODE \n"
			+ "   AND §current_timestamp§ BETWEEN cpcf.DT_INSERT AND cpcf.DT_DELETE \n"
			+ "   AND cpcf.FORM_TYPE = 'VINEYARD_FORM' \n"
			+ "   AND cpcf.EXTERNAL_CODE IS NOT NULL \n"
			+ "   AND cpcf.EXTERNAL_CODE = :externalCode")
	public Integer getDeclWithSameExternalCodeCount(@Bind("planId") Long planId, @Bind("declCode") String declCode, @Bind("externalCode") String externalCode);

	@SqlQuery("SELECT cpcf.external_code \n"
			+ "  FROM CRPL_PLOT_DATA cpd, CRPL_DECLARATIONS cd, CRPL_PERM_CROP_FORMS cpcf \n"
			+ " WHERE cpd.plan_id = :planId \n"
			+ "   AND §current_timestamp§ BETWEEN cpd.DT_INSERT AND cpd.DT_DELETE \n"
			+ "   AND to_char(:pointInTime::DATE,'yyyymmdd') BETWEEN cpd.day_from AND cpd.day_to \n"
			+ "   AND cd.plan_id = cpd.plan_id \n"
			+ "   AND cd.plot_code = cpd.plot_code \n"
			+ "   AND §current_timestamp§ BETWEEN cd.dt_insert AND cd.dt_delete \n"
			+ "   AND to_char(:pointInTime::DATE,'yyyymmdd') BETWEEN cd.day_from AND cd.day_to \n"
			+ "   AND cpcf.plan_id = cd.plan_id \n"
			+ "   AND cpcf.plot_code = cd.plot_code \n"
			+ "   AND cpcf.decl_code = cd.decl_code \n"
			+ "   AND §current_timestamp§ BETWEEN cpcf.dt_insert AND cpcf.dt_delete \n"
			+ " GROUP BY cpcf.external_code \n"
			+ " HAVING count(*) > 1")
    List<String> getExternalCodes(@Bind("planId") Long planId, @Bind("pointInTime") LocalDate pointInTime);

	@SqlQuery("SELECT cd.plot_code as plotCode, cd.decl_code as declCode \n"
			+ "  FROM CRPL_PLOT_DATA cpd, CRPL_DECLARATIONS cd, CRPL_PERM_CROP_FORMS cpcf \n"
			+ " WHERE cpd.plan_id = :planId \n"
			+ "   AND §current_timestamp§ BETWEEN cpd.DT_INSERT AND cpd.DT_DELETE \n"
			+ "   AND to_char(:pointInTime::DATE,'yyyymmdd') BETWEEN cpd.day_from AND cpd.day_to \n"
			+ "   AND cd.plan_id = cpd.plan_id \n"
			+ "   AND cd.plot_code = cpd.plot_code \n"
			+ "   AND §current_timestamp§ BETWEEN cd.dt_insert AND cd.dt_delete \n"
			+ "   AND to_char(:pointInTime::DATE,'yyyymmdd') BETWEEN cd.day_from AND cd.day_to \n"
			+ "   AND cpcf.plan_id = cd.plan_id \n"
			+ "   AND cpcf.plot_code = cd.plot_code \n"
			+ "   AND cpcf.decl_code = cd.decl_code \n"
			+ "   AND §current_timestamp§ BETWEEN cpcf.dt_insert AND cpcf.dt_delete \n"
			+ "   AND cpcf.external_code in (<extCodes>) \n"
			+ " UNION \n"
			+ "SELECT cd.plot_code as plotCode, cd.decl_code as declCode \n"
			+ "  FROM CRPL_PLOT_DATA cpd, CRPL_DECLARATIONS cd, CRPL_ANOMALIES ca \n"
			+ " WHERE cpd.plan_id = :planId \n"
			+ "   AND §current_timestamp§ BETWEEN cpd.DT_INSERT AND cpd.DT_DELETE \n"
			+ "   AND to_char(:pointInTime::DATE,'yyyymmdd') BETWEEN cpd.day_from AND cpd.day_to \n"
			+ "   AND cd.plan_id = cpd.plan_id \n"
			+ "   AND cd.plot_code = cpd.plot_code \n"
			+ "   AND §current_timestamp§ BETWEEN cd.dt_insert AND cd.dt_delete \n"
			+ "   AND to_char(:pointInTime::DATE,'yyyymmdd') BETWEEN cd.day_from AND cd.day_to \n"
			+ "   AND ca.plan_id = cd.plan_id \n"
			+ "   AND ca.object_code = cd.decl_code \n"
			+ "   AND §current_timestamp§ BETWEEN ca.dt_insert AND ca.dt_delete \n"
			+ "   AND ca.object_type = 'DECLARATION' \n"
			+ "   AND ca.error_code = :errorCode")
	@RegisterBeanMapper(AnomPlotDeclarations.class)
    List<AnomPlotDeclarations> getAnomPlotDeclarations(
			@Bind("planId") Long planId, 
			@Bind("pointInTime") LocalDate pointInTime, 
			@BindList(value = "extCodes", onEmpty = BindList.EmptyHandling.NULL_STRING) List<String> extCodes,
			@Bind("errorCode") String errorCode);

	@SqlQuery("SELECT cd.plot_code as plotCode, \n"
			+ "       cd.id as declId, \n"
			+ "       cd.decl_code as declCode, \n"
			+ "       cd.land_use_code as landuseCode, \n"
			+ "       cd.area_perc as areaPerc, \n"
			+ "       to_date(cd.day_from,'yyyymmdd') as fromDate, \n"
			+ "       to_date(cd.day_to,'yyyymmdd') as toDate, \n"
			+ "       cd.day_from_precision as fromDatePrecision, \n"
			+ "       'UPDATE' as operation \n"
			+ "  FROM CRPL_DECLARATIONS cd \n"
			+ " WHERE cd.plan_id = :planId \n"
			+ "   AND cd.plot_code = :plotCode \n"
			+ "   AND cd.decl_code = :declCode \n"
			+ "   AND §current_timestamp§ BETWEEN cd.dt_insert AND cd.dt_delete \n"
			+ "   AND to_char(:pointInTime::DATE,'yyyymmdd') BETWEEN cd.day_from AND cd.day_to")
	@RegisterBeanMapper(ValidatorBoundedDeclaration.class)
    ValidatorBoundedDeclaration getAnomDeclaration(
			@Bind("planId") Long planId, 
			@Bind("plotCode") String plotCode, 
			@Bind("declCode") String declCode,
			@Bind("pointInTime") LocalDate pointInTime);

	@SqlQuery("SELECT cd.decl_code \n"
			+ "  FROM CRPL_DECLARATIONS cd \n"
			+ " WHERE cd.plan_id = :planId \n"
			+ "   AND cd.plot_code = :plotCode \n"
			+ "   AND §current_timestamp§ BETWEEN cd.dt_insert AND cd.dt_delete \n"
			+ "   AND to_char(:pointInTime::DATE,'yyyymmdd') BETWEEN cd.day_from AND cd.day_to")
	List<String> getDeletedPlotDeclCodes(
			@Bind("planId") Long planId, 
			@Bind("plotCode") String plotCode, 
			@Bind("pointInTime") LocalDate pointInTime);
}
