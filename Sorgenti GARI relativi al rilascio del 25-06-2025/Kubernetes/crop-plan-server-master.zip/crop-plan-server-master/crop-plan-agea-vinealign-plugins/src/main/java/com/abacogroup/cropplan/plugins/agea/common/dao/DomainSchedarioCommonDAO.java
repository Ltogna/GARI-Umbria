package com.abacogroup.cropplan.plugins.agea.common.dao;

import com.abacogroup.cropplan.sdk.model.domain.Place;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements;
import com.abacogroup.jdbi.EnhancedSqlObject;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.locationtech.jts.geom.Geometry;

public interface DomainSchedarioCommonDAO extends EnhancedSqlObject {
	@SqlQuery("select cod_nazionale || ' - ' || nome || ' (' || sigla_prov || ')' from siticomu where COD_NAZIONALE = :domainZoneId")
	String getDomainZoneDescription(@Bind("domainZoneId") String domainZoneId);

	@RegisterBeanMapper(Place.class)
	@SqlQuery("select t.description, t.srs, t.geom"
			+ "      from ("
			+ "              select sp.foglio||'-'||sp.particella||decode(trim(sp.sub), '', '', '/'||sp.sub) as description,"
			+ "                     (SELECT CASE WHEN a.x > 2000000 THEN '3004' ELSE '3003' END epsg FROM TABLE (SDO_UTIL.getvertices (sp.shape)) a WHERE ROWNUM = 1) as srs,"
			+ "                     sp.shape as geom"
			+ "                from sitipart sp"
			+ "               where sp.cod_nazionale = :domainZoneId"
			+ "                 and §current_timestamp§ between sp.data_inizio_val and sp.data_fine_val"
			+ "           ) t"
			+ "     where (:search is null or t.description like '%'||:search||'%')")
	ResultIterator<Place> getPlaces(@Bind("domainZoneId") String domainZoneId, @Bind("search") String search);

	@SqlQuery("SELECT p.se_row_id AS id,"
			+ "       'CAD_PARCEL' as type,"
			+ "       p.foglio||'-'||p.particella||decode(trim(p.sub), '', '', '/'||p.sub) as description,"
			+ "       p.shape AS geom"
			+ "  FROM (SELECT DISTINCT codi_nazi,"
			+ "                        nume_fogl,"
			+ "                        nume_part,"
			+ "                        codi_suba"
			+ "                   FROM siticond c, aabafasc_tab fas"
			+ "                  WHERE §current_timestamp§ BETWEEN c.data_iniz_vali AND c.data_fine_vali"
			+ "                    AND §current_timestamp§ BETWEEN c.data_iniz_cond AND c.data_fine_cond"
			+ "                    AND c.deco_stato = 1320"
			+ "                    AND fas.id_fasc = c.id_fasc"
			+ "                    AND §current_timestamp§ BETWEEN fas.data_iniz_vali AND fas.data_fine_vali"
			+ "                    AND fas.cuaa = :cuaa) d,"
			+ "       sitipart p"
			+ " WHERE d.codi_nazi = :domainZoneId"
			+ "   AND d.CODI_NAZI = p.cod_nazionale"
			+ "   AND d.NUME_FOGL = p.foglio"
			+ "   AND d.nume_part = p.particella"
			+ "   AND NVL(TO_CHAR (d.codi_suba), ' ') = p.sub"
			+ "   AND §current_timestamp§ BETWEEN p.data_inizio_val AND p.data_fine_val"
			+ " order by p.se_row_id")
	@RegisterBeanMapper(SnapElements.SnapGeometry.class)
	ResultIterator<SnapElements.SnapGeometry> getBusinessCadParcels(@Bind("cuaa") String cuaa, @Bind("domainZoneId") String domainZoneId);

	@SqlQuery("select a.se_row_id AS id,"
			+ "       'SUOLI' as type,"
			+ "       a.foglio||'-'||a.particella||decode(trim(a.sub), '', '', '/'||a.sub) as description,"
			+ "       a.shape as geom"
			+ "  FROM (SELECT DISTINCT codi_nazi,"
			+ "                        nume_fogl,"
			+ "                        nume_part,"
			+ "                        codi_suba"
			+ "                   FROM siticond c, aabafasc_tab fas"
			+ "                  WHERE §current_timestamp§ BETWEEN c.DATA_INIZ_VALI AND c.DATA_FINE_VALI"
			+ "                    AND §current_timestamp§ BETWEEN c.data_iniz_cond AND c.data_fine_cond"
			+ "                    AND c.deco_stato = 1320"
			+ "                    AND fas.id_fasc = c.id_fasc"
			+ "                    AND §current_timestamp§ BETWEEN fas.data_iniz_vali AND fas.data_fine_vali"
			+ "                    AND fas.cuaa = :cuaa) d,"
			+ "       sitisuolo a"
			+ " where d.codi_nazi = :domainZoneId"
			+ "   and a.cod_varieta = :varietyCode"
			+ "   AND d.CODI_NAZI = a.cod_nazionale"
			+ "   AND d.NUME_FOGL = a.foglio"
			+ "   AND d.nume_part = a.particella"
			+ "   AND NVL(TO_CHAR (d.CODI_SUBA), ' ') = a.sub"
			+ "   AND §current_timestamp§ BETWEEN a.data_inizio_val AND a.data_fine_val"
			+ "   and §geom_have_interactions(a.shape, :touchingGeometry)§"
			+ " order by a.se_row_id")
	@RegisterBeanMapper(SnapElements.SnapGeometry.class)
	ResultIterator<SnapElements.SnapGeometry> getSoil(@Bind("domainZoneId") String domainZoneId, @Bind("cuaa") String cuaa, @Bind("varietyCode") String varietyCode,
			@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("select a.POLYGON_ID AS id,"
			+ "       'POLIGONI_GPS' as type,"
			+ "       TO_CHAR (a.data_lav, 'dd/mm/yyyy') as description,"
			+ "       b.shape as geom"
			+ "  from sitiprod.POCKET_GPSPOLYGONS a, sitiprod.POCKET_GPSPOLYGONS_SHAPE_2D b"
			+ " where a.POLYGON_ID = b.POLYGON_ID"
			+ "   and §geom_have_interactions(b.shape, :touchingGeometry)§"
			+ " order by a.POLYGON_ID")
	@RegisterBeanMapper(SnapElements.SnapGeometry.class)
	ResultIterator<SnapElements.SnapGeometry> getPoligoniGPS(@Bind("touchingGeometry") Geometry touchingGeometry);
}
