package com.abacogroup.cropplan.plugins.agea.fruitalign.dao;

import com.abacogroup.cropplan.sdk.model.domain.DomainZoneGeometry;
import com.abacogroup.jdbi.EnhancedSqlObject;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import java.util.List;

public interface DomainSchedarioDAO extends EnhancedSqlObject {
	@SqlQuery("select sp.cod_nazionale as domainzoneid, \n"
			+ "       sp.cod_nazionale as code, \n"
			+ "       'EPSG:' || sp.epsg as srs, \n"
			+ "       sdo_aggr_mbr(sp.shape_layer_b) as mbr \n"
			+ "  from sf_unar_link_parcelle up, sf_unar_link_cuaa t3, sf_parcelle_import sp \n"
			+ " where t3.cuaa = :cuaa \n"
			+ "   and sp.id_parcella = up.id_parcella \n"
			+ "   and up.pkid_unar = t3.pkid_unar \n"
			+ "   and sp.cod_nazionale is not null \n"
			+ "   and sp.foglio is not null \n"
			+ "   AND sp.ISTATR NOT IN ('01','03', '05','09') \n"
			+ "   AND sp.istatp NOT IN ('021') \n"
			+ " group by sp.cod_nazionale, sp.epsg")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	List<DomainZoneGeometry> getDomainZonesByCuaa(@Bind("cuaa") String cuaa);

	@SqlQuery("select sp.cod_nazionale as domainzoneid, \n"
			+ "       sp.cod_nazionale as code, \n"
			+ "       'EPSG:' || sp.epsg as srs, \n"
			+ "       sdo_geom.sdo_mbr(sdo_aggr_union(SDOAGGRTYPE(sp.shape_layer_b,0.005))) as mbr \n"
			+ "  from sf_unar_link_parcelle up, sf_unar_link_cuaa t3, sf_parcelle_import sp \n"
			+ " where t3.cuaa = :cuaa \n"
			+ "   and sp.id_parcella = up.id_parcella \n"
			+ "   and up.pkid_unar = t3.pkid_unar \n"
			+ "   and sp.cod_nazionale is not null \n"
			+ "   and sp.foglio is not null \n"
			+ "   AND sp.ISTATR NOT IN ('01','03', '05','09') \n"
			+ "   AND sp.istatp NOT IN ('021') \n"
			+ " group by sp.cod_nazionale, sp.epsg")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	List<DomainZoneGeometry> getDomainZonesByCuaaNoSdoAggrMbr(@Bind("cuaa") String cuaa);

	@SqlQuery("select sp.cod_nazionale as domainzoneid, \n"
			+ "       sp.cod_nazionale as code, \n"
			+ "       'EPSG:' || sp.epsg as srs, \n"
			+ "       sdo_aggr_mbr(sp.shape_layer_b) as mbr \n"
			+ "  from sf_unar_link_parcelle up, sf_unar_link_cuaa t3, sf_parcelle_import sp \n"
			+ " where t3.cuaa = :cuaa \n"
			+ "   and sp.id_parcella = up.id_parcella \n"
			+ "   and up.pkid_unar = t3.pkid_unar \n"
			+ "   and sp.cod_nazionale = :domainZoneId \n"
			+ "   and sp.foglio is not null \n"
			+ "   AND sp.ISTATR NOT IN ('01','03', '05','09') \n"
			+ "   AND sp.istatp NOT IN ('021') \n"
			+ " group by sp.cod_nazionale, sp.epsg")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	DomainZoneGeometry getDomainZone(@Bind("cuaa") String cuaa, @Bind("domainZoneId") String domainZoneId);

	@SqlQuery("select sp.cod_nazionale as domainzoneid, \n"
			+ "       sp.cod_nazionale as code, \n"
			+ "       'EPSG:' || sp.epsg as srs, \n"
			+ "       sdo_geom.sdo_mbr(sdo_aggr_union(SDOAGGRTYPE(sp.shape_layer_b,0.005))) as mbr \n"
			+ "  from sf_unar_link_parcelle up, sf_unar_link_cuaa t3, sf_parcelle_import sp \n"
			+ " where t3.cuaa = :cuaa \n"
			+ "   and sp.id_parcella = up.id_parcella \n"
			+ "   and up.pkid_unar = t3.pkid_unar \n"
			+ "   and sp.cod_nazionale = :domainZoneId \n"
			+ "   and sp.foglio is not null \n"
			+ "   AND sp.ISTATR NOT IN ('01','03', '05','09') \n"
			+ "   AND sp.istatp NOT IN ('021') \n"
			+ " group by sp.cod_nazionale, sp.epsg")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	DomainZoneGeometry getDomainZoneNoSdoAggrMbr(@Bind("cuaa") String cuaa, @Bind("domainZoneId") String domainZoneId);
}
