package com.abacogroup.cropplan.plugins.agea.common.dao;

import com.abacogroup.cropplan.plugins.agea.common.dao.sql.BusinessSchedarioFruitRawQueries;
import com.abacogroup.cropplan.plugins.agea.common.dao.sql.BusinessSchedarioOliveRawQueries;
import com.abacogroup.cropplan.plugins.agea.common.dao.sql.BusinessSchedarioVineRawQueries;
import com.abacogroup.cropplan.sdk.model.business.Business;
import com.abacogroup.jdbi.EnhancedSqlObject;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import java.util.List;

public interface BusinessSchedarioDAO extends EnhancedSqlObject {
	/*------------------VINE------------------*/
	@SqlQuery(BusinessSchedarioVineRawQueries.GET_BUSINESS)
	@RegisterBeanMapper(Business.class)
	Business getBusiness(
			@Bind("businessId") String businessId,
			@Bind("ldapGroup") String ldapGroup,
			@BindList("ldapGroupsReg") List<String> ldapGroupsReg,
			@Bind("userName") String userName,
			@Bind("onlyEmpowered") Boolean onlyEmpowered);

	@SqlQuery(BusinessSchedarioVineRawQueries.GET_BUSINESSES)
	@RegisterBeanMapper(Business.class)
	ResultIterator<Business> getBusinesses(
			@Bind("userName") String userName,
			@Bind("search") String search,
			@Bind("ldapGroup") String ldapGroup,
			@BindList("ldapGroupsReg") List<String> ldapGroupsReg,
			@Bind("onlyEmpowered") Boolean onlyEmpowered);

	/*------------------FRUIT------------------*/
	@SqlQuery(BusinessSchedarioFruitRawQueries.GET_FRUIT_BUSINESS)
	@RegisterBeanMapper(Business.class)
	Business getFruitBusiness(
			@Bind("businessId") String businessId,
			@Bind("ldapGroup") String ldapGroup,
			@BindList("ldapGroupsReg") List<String> ldapGroupsReg,
			@Bind("userName") String userName,
			@Bind("onlyEmpowered") Boolean onlyEmpowered);

	@SqlQuery(BusinessSchedarioFruitRawQueries.GET_FRUIT_BUSINESSES)
	@RegisterBeanMapper(Business.class)
	ResultIterator<Business> getFruitBusinesses(
			@Bind("userName") String userName,
			@Bind("search") String search,
			@Bind("ldapGroup") String ldapGroup,
			@BindList("ldapGroupsReg") List<String> ldapGroupsReg,
			@Bind("onlyEmpowered") Boolean onlyEmpowered);

	/*------------------OLIVE------------------*/
	@SqlQuery(BusinessSchedarioOliveRawQueries.GET_OLIVE_BUSINESS)
	@RegisterBeanMapper(Business.class)
	Business getOliveBusiness(
			@Bind("businessId") String businessId,
			@Bind("ldapGroup") String ldapGroup,
			@BindList("ldapGroupsReg") List<String> ldapGroupsReg,
			@Bind("userName") String userName,
			@Bind("onlyEmpowered") Boolean onlyEmpowered);

	@SqlQuery(BusinessSchedarioOliveRawQueries.GET_OLIVE_BUSINESSES)
	@RegisterBeanMapper(Business.class)
	ResultIterator<Business> getOliveBusinesses(
			@Bind("userName") String userName,
			@Bind("search") String search,
			@Bind("ldapGroup") String ldapGroup,
			@BindList("ldapGroupsReg") List<String> ldapGroupsReg,
			@Bind("onlyEmpowered") Boolean onlyEmpowered);
}
