package com.abacogroup.cropplan.plugins.agea.common.models.ntt;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Iscrizione {
	private String code;
	private String categoria;
	private String alboElenco;
	private String tipologia;
	private String bloccoTipologia;
	private String bloccoRivendica;
	private String bloccoIdoneita;
	private String attingimento;
}
