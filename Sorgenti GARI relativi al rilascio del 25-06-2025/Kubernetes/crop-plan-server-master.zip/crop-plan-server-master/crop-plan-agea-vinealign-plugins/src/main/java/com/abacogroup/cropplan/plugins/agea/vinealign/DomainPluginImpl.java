package com.abacogroup.cropplan.plugins.agea.vinealign;

import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

import com.abacogroup.cropplan.plugins.agea.common.dao.DomainCropPlanDAO;
import com.abacogroup.cropplan.plugins.agea.common.dao.DomainSchedarioCommonDAO;
import com.abacogroup.cropplan.plugins.agea.common.models.GeometryWithSrs;
import com.abacogroup.cropplan.plugins.agea.common.models.LpisParcel;
import com.abacogroup.cropplan.plugins.agea.external_microservices.repositories.LpisGisServerRepository;
import com.abacogroup.cropplan.plugins.agea.external_microservices.request.ParcelsBySectorCodeWithTouchingGeometryDto;
import com.abacogroup.cropplan.plugins.agea.vinealign.dao.DomainSchedarioDAO;
import com.abacogroup.cropplan.sdk.model.domain.CadastralParcelData;
import com.abacogroup.cropplan.sdk.model.domain.CadastralParcelOverlapData;
import com.abacogroup.cropplan.sdk.model.domain.DomainZoneGeometry;
import com.abacogroup.cropplan.sdk.model.domain.HoldingArea;
import com.abacogroup.cropplan.sdk.model.domain.Parcel;
import com.abacogroup.cropplan.sdk.model.domain.ParcelData;
import com.abacogroup.cropplan.sdk.model.domain.ParcelDescription;
import com.abacogroup.cropplan.sdk.model.domain.Place;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements.SnapElementType;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements.SnapGeometry;
import com.abacogroup.cropplan.sdk.spi.DomainPlugin;
import com.abacogroup.cropplan.sdk.support.DomainDataSupport;
import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.MaxRowsResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.jdbi.paging.impl.MaxRowsResultsImpl;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Polygonal;

public class DomainPluginImpl implements DomainPlugin, InitializablePlugin {
	private static final String JDBI_NAME_SCHEDARIO = "dbSchedario";
	private static final String JDBI_CROP_PLAN = "mainDB";
	private static final String URL_LPIS = "lpisURL";
	private static final int MAX_ROWS = 50;
	public static final String SNAP_EL_TYPE_PARCEL = "PARCEL";
	public static final String SNAP_EL_DESCR_PARCEL = "Parcelle Viticole";
	public static final String SNAP_EL_TYPE_POLIGONI_GPS = "POLIGONI_GPS";
	public static final String SNAP_EL_DESCR_POLIGONI_GPS = "Poligoni GPS";
	public static final String SNAP_EL_TYPE_SUOLI = "SUOLI";
	public static final String SNAP_EL_DESCR_SUOLI = "Uso suolo vitato aziendale";
	private final Double holdingPercentage = 100.0;

	private DomainSchedarioCommonDAO domainSchedarioCommonDAO;
	private DomainSchedarioDAO domainSchedarioDAO;
	private DomainCropPlanDAO domainCropPlanDAO;

	@Override
	public void initialize(PluginsEnvironment env) {
		var jdbiSchedario = env.getJdbi(JDBI_NAME_SCHEDARIO);
		if (jdbiSchedario == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SCHEDARIO);

		domainSchedarioDAO = jdbiSchedario.onDemand(DomainSchedarioDAO.class);
		domainSchedarioCommonDAO = jdbiSchedario.onDemand(DomainSchedarioCommonDAO.class);

		var jdbiCropPlan = env.getJdbi(JDBI_CROP_PLAN);
		if (jdbiCropPlan == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_CROP_PLAN);

		domainCropPlanDAO = jdbiCropPlan.onDemand(DomainCropPlanDAO.class);
	}

	@Override
	public HoldingArea getHoldingArea(RuntimeEnvironment env, String businessId, LocalDate pointInTime) {
		return domainCropPlanDAO.getHoldingArea(businessId, AbsoluteDate.of(pointInTime).toString(), env.getTenantId());
	}

	@Override
	public MaxRowsResults<DomainZoneGeometry> getDomainZonesMaxRows(RuntimeEnvironment env, String businessId,
			LocalDate pointInTime, String search, boolean filterByBusiness) {
		List<DomainZoneGeometry> domains = getDomainZones(businessId, search, null);
		return new MaxRowsResultsImpl<>(domains, false);
	}

	@Override
	public InfiniteListResults<DomainZoneGeometry> getDomainZonesInfinite(RuntimeEnvironment env, String businessId,
			LocalDate pointInTime, String search, boolean filterByBusiness, String nextKey) {
		List<DomainZoneGeometry> domains = getDomainZones(businessId, search, null);
		return new InfiniteListResultsImpl<>(domains, null);
	}

	@Override
	public MaxRowsResults<DomainZoneGeometry> getDomainZonesByIdsMaxRows(RuntimeEnvironment env, String businessId, String search, List<String> domainZoneIds) {
		List<DomainZoneGeometry> domains = getDomainZones(businessId, search, domainZoneIds);
		return new MaxRowsResultsImpl<>(domains, false);
	}

	@Override
	public InfiniteListResults<DomainZoneGeometry> getDomainZonesByIdsInfinite(RuntimeEnvironment env, String businessId, String search,
			List<String> domainZoneIds, String nextKey) {
		List<DomainZoneGeometry> domains = getDomainZones(businessId, search, domainZoneIds);
		return new InfiniteListResultsImpl<>(domains, null);
	}

	private List<DomainZoneGeometry> getDomainZones(String businessId, String search, List<String> domainZoneIds) {
		List<DomainZoneGeometry> domains;
		try {
			domains = domainSchedarioDAO.getDomainZonesByCuaa(businessId);
		} catch (RuntimeException e) {
			domains = domainSchedarioDAO.getDomainZonesByCuaaNoSdoAggrMbr(businessId);
		}

		domains.forEach(d -> d.setDescription(domainSchedarioCommonDAO.getDomainZoneDescription(d.getDomainZoneId())));

		domains = domains.stream()
				.filter(d -> domainZoneIds == null || domainZoneIds.contains(d.getDomainZoneId()))
				.filter(d -> search == null || d.getDescription().toUpperCase().contains(search.toUpperCase()))
				.sorted(Comparator.comparing(DomainZoneGeometry::getDescription))
				.collect(toList());
		return domains;
	}

	@Override
	public DomainZoneGeometry getDomainZone(RuntimeEnvironment env, String businessId,
			LocalDate pointInTime, String domainZoneId) {

		DomainZoneGeometry domain;
		try {
			domain = domainSchedarioDAO.getDomainZone(businessId, domainZoneId);
		} catch (RuntimeException e) {
			domain = domainSchedarioDAO.getDomainZoneNoSdoAggrMbr(businessId, domainZoneId);
		}
		domain.setDescription(getDomainZoneDescription(env, pointInTime, domainZoneId));
		return domain;
	}

	@Override
	public DomainZoneGeometry getDomainZoneByCode(RuntimeEnvironment env, String businessId,
			LocalDate pointInTime, String domainZoneCode) {
		return getDomainZone(env, businessId, pointInTime, domainZoneCode);
	}

	@Override
	public String getDomainZoneDescription(RuntimeEnvironment env, LocalDate pointInTime, String domainZoneId) {
		//var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));

		return domainSchedarioCommonDAO.getDomainZoneDescription(domainZoneId);
	}

	@Override
	public HoldingArea getHoldingAreaByDomainZone(RuntimeEnvironment env, String businessId,
			String domainZoneId, LocalDate pointInTime) {
		return domainCropPlanDAO.getHoldingAreaByDomainZones(businessId, domainZoneId, AbsoluteDate.of(pointInTime).toString(), env.getTenantId());
	}

	@Override
	public SnapElements getSnapGeometries(RuntimeEnvironment env, String businessId, String domainZoneId, List<String> snapElementTypes, LocalDate pointInTime) {
		var ret = initSnapElements();

		GeometryWithSrs geometryWithSrs = domainCropPlanDAO.getDomainPlotsGeom(businessId, AbsoluteDate.of(pointInTime).toString(), domainZoneId,
				env.getTenantId());
		Geometry touchingGeometry = Utils.reducePrecision(geometryWithSrs.getGeometry(), true, true);

		Object url = env.getProperty(URL_LPIS);
		if (url == null) {
			return ret;
		}

		if (null == snapElementTypes || snapElementTypes.contains(SNAP_EL_TYPE_PARCEL)) {
			ret.getTypes().add(new SnapElementType(SNAP_EL_TYPE_PARCEL, SNAP_EL_DESCR_PARCEL));

			// load parcels
			ParcelsBySectorCodeWithTouchingGeometryDto parcelsBySectorCodeWithTouchingGeometryDto = new ParcelsBySectorCodeWithTouchingGeometryDto();
			parcelsBySectorCodeWithTouchingGeometryDto.setGeom(touchingGeometry);
			parcelsBySectorCodeWithTouchingGeometryDto.setSrs(geometryWithSrs.getSrs());

			List<LpisParcel> parcels = LpisGisServerRepository.getListOfParcelsInSectorCodeWithTouchingGeometry(
					env, url.toString(), env.getTenantId(), domainZoneId,
					LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")), parcelsBySectorCodeWithTouchingGeometryDto);

			ret.getGeometries().addAll(parcels.stream()
					.map(parcel -> new SnapGeometry(String.valueOf(parcel.getId()), SNAP_EL_TYPE_PARCEL, parcel.getParcel(), parcel.getGeom(), null))
					.collect(toList()));
		}

		if (null == snapElementTypes || snapElementTypes.contains(SNAP_EL_TYPE_POLIGONI_GPS)) {
			ret.getTypes().add(new SnapElementType(SNAP_EL_TYPE_POLIGONI_GPS, SNAP_EL_DESCR_POLIGONI_GPS));

			// load poligoni gps
			DomainZoneGeometry domainZone = getDomainZone(env, businessId, pointInTime, domainZoneId);
			String gpsNextKey = null;
			do {
				InfiniteListResults<SnapGeometry> result = domainSchedarioDAO.infinite(() -> domainSchedarioCommonDAO.getPoligoniGPS(domainZone.getMbr()),
						gpsNextKey,
						666);
				ret.getGeometries().addAll(result.getRecords());
				gpsNextKey = result.getNextKey();
			} while (gpsNextKey != null);
		}

		if (null == snapElementTypes || snapElementTypes.contains(SNAP_EL_TYPE_SUOLI)) {
			ret.getTypes().add(new SnapElementType(SNAP_EL_TYPE_SUOLI, SNAP_EL_DESCR_SUOLI));

			// load soil
			String nextKeySoil = null;
			do {
				InfiniteListResults<SnapGeometry> result = domainSchedarioDAO.infinite(
						() -> domainSchedarioCommonDAO.getSoil(domainZoneId, businessId, "410", touchingGeometry),
						nextKeySoil, 666);
				ret.getGeometries().addAll(result.getRecords());
				nextKeySoil = result.getNextKey();
			} while (nextKeySoil != null);
		}

		return ret;
	}

	private static SnapElements initSnapElements() {
		var ret = new SnapElements();

		var types = new ArrayList<SnapElementType>();

		ret.setTypes(types);
		ret.setGeometries(new ArrayList<>());
		return ret;
	}

	@Override
	public Map<String, ParcelDescription> getParcelsDescription(RuntimeEnvironment env, String businessId,
			LocalDate pointInTime, List<String> parcelCodes) {
		return parcelCodes.stream()
				.collect(toMap(pc -> pc, pc -> new ParcelDescription(pc, pc, pc, holdingPercentage)));
	}

	@Override
	public Map<String, Polygonal> getParcels(RuntimeEnvironment env, String businessId, String domainZoneId,
			LocalDate pointInTime, Geometry touchingGeometry) {
		return new HashMap<>();
	}

	@Override
	public List<Parcel> getAllParcels(RuntimeEnvironment env, String businessId, String domainZoneId, LocalDate pointInTime, Geometry touchingGeometry) {
		return new ArrayList<>();
	}

	@Override
	public List<Parcel> getCopyCampaignParcels(RuntimeEnvironment env, String businessId, String domainZoneId, LocalDate pointInTime) {
		return new ArrayList<>();
	}

	@Override
	public List<Parcel> getParcelsByParcelCodes(RuntimeEnvironment env, String businessId, String domainZoneId, List<String> parcelCodes,
			LocalDate pointInTime) {
		return new ArrayList<>();
	}

	@Override
	public List<LocalDate> getFutureParcelsIntersections(RuntimeEnvironment env, String businessId,
			String domainZoneId, LocalDate pointInTime, Geometry touchingGeometry) {
		return new ArrayList<>();
	}

	@Override
	public String getParcelLandCoverCode(RuntimeEnvironment env, String businessId, String parcelCode,
			LocalDate pointInTime) {
		return "410"; // VITE
	}

	@Override
	public Geometry getMBROverview(RuntimeEnvironment env, String businessId, List<String> parcelCodes,
			LocalDate pointInTime) {
		return null;
	}

	@Override
	public MaxRowsResults<Place> getPlaces(RuntimeEnvironment env, String businessId, String domainZoneId, String search) {
		return domainSchedarioDAO.maxRows(() -> domainSchedarioCommonDAO.getPlaces(domainZoneId, search),
				MAX_ROWS);
	}

	@Override
	public InfiniteListResults<ParcelData> getParcelsData(RuntimeEnvironment env, String businessId, String domainZoneId,
			LocalDate pointInTime, String nextKey, DomainDataSupport support) {
		return new InfiniteListResultsImpl<>(new ArrayList<>(), null);
	}

	@Override
	public InfiniteListResults<CadastralParcelData> getCadastralParcelsData(RuntimeEnvironment env, String businessId, String domainZoneId,
			LocalDate pointInTime, String nextKey) {
		return new InfiniteListResultsImpl<>(new ArrayList<>(), null);
	}

	@Override
	public InfiniteListResults<CadastralParcelOverlapData> getCadastralParcelsOverlapsData(RuntimeEnvironment env, String businessId, String domainZoneId,
			LocalDate pointInTime, String nextKey) {
		return new InfiniteListResultsImpl<>(new ArrayList<>(), null);
	}

	@Override
	public boolean intersectedParcelCodesChanged(RuntimeEnvironment env, String businessId, LocalDate pointInTime,
			List<String> oldIntersectedParcelCodes, List<String> newIntersectedParcelCodes) {
		boolean haveSameSize = oldIntersectedParcelCodes.size() == newIntersectedParcelCodes.size();
		boolean haveSameElements = oldIntersectedParcelCodes.stream()
				.filter(pi -> !newIntersectedParcelCodes.contains(pi))
				.collect(toList())
				.size() == 0;
		return !haveSameSize || !haveSameElements;
	}

	@Override
	public String getCropPlanType() {
		return "VINEALIGN";
	}

}
