package com.abacogroup.cropplan.plugins.agea.vinealign;

import static java.util.stream.Collectors.toList;

import com.abacogroup.cropplan.plugins.agea.common.dao.ValidatorCropPlanDAO;
import com.abacogroup.cropplan.plugins.agea.common.dao.ValidatorSchedarioCommonDAO;
import com.abacogroup.cropplan.plugins.agea.common.models.ParcelEditStatusV1;
import com.abacogroup.cropplan.plugins.agea.common.models.ntt.AnomPlotDeclarations;
import com.abacogroup.cropplan.plugins.agea.vinealign.dao.ValidatorSchedarioDAO;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.CropPlanConfigData;
import com.abacogroup.cropplan.sdk.model.PermanentCropForm;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormData;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormData.Fields;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormFieldValue;
import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormFieldConfig;
import com.abacogroup.cropplan.sdk.model.validation.AnomalyObjectType;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomaly;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomalyObject;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedDeclaration;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedPlot;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorData;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorOperation;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorResult;
import com.abacogroup.cropplan.sdk.spi.ValidatorPlugin;
import com.abacogroup.cropplan.sdk.support.PermanentCropFormDataFieldToCodeMapper;
import com.abacogroup.cropplan.sdk.support.ValidatorDataSupport;
import com.abacogroup.cropplan.sdk.support.ValidatorDataSupport.VDSPlot;
import com.abacogroup.jdbi.config.AbacoJdbiConfig;
import com.abacogroup.jdbi.config.SpatialVectorAcceleration;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.stream.Collectors;
import org.apache.commons.lang3.NotImplementedException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ValidatorPluginImpl implements ValidatorPlugin, InitializablePlugin {

	private static final Logger log = LoggerFactory.getLogger(ValidatorPluginImpl.class);

	private static final String JDBI_NAME_SCHEDARIO = "dbSchedario";
	private static final String JDBI_CROP_PLAN = "mainDB";
	private static final String URL_LPIS = "lpisURL";

	private ValidatorSchedarioCommonDAO validatorSchedarioCommonDAO;
	private ValidatorSchedarioDAO validatorSchedarioDAO;
	private ValidatorCropPlanDAO validatorCropPlanDAO;

	private String lpisURL;

	private static final String DEFAULT_DATE = "9999-01-01";
	private static final String FONTE_PARCELLA_FITTIZIA = "2";

	@Override
	public void initialize(PluginsEnvironment env) {
		var jdbiSchedario = env.getJdbi(JDBI_NAME_SCHEDARIO);
		if (jdbiSchedario == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SCHEDARIO);

		if (env.getProperty("enableSpatialVectorAcceleration") != null && Boolean.parseBoolean(env.getProperty("enableSpatialVectorAcceleration").toString())) {
			jdbiSchedario.configure(AbacoJdbiConfig.class, config -> config.setSpatalVectorAcceleration(SpatialVectorAcceleration.ENABLE_IF_POSSIBLE));
		}

		validatorSchedarioDAO = jdbiSchedario.onDemand(ValidatorSchedarioDAO.class);
		validatorSchedarioCommonDAO = jdbiSchedario.onDemand(ValidatorSchedarioCommonDAO.class);

		var jdbiCropPlan = env.getJdbi(JDBI_CROP_PLAN);
		if (jdbiCropPlan == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_CROP_PLAN);

		validatorCropPlanDAO = jdbiCropPlan.onDemand(ValidatorCropPlanDAO.class);

		lpisURL = Optional.ofNullable(env.getProperty(URL_LPIS))
				.map(Object::toString)
				.orElseThrow(() -> new IllegalStateException("Cannot get lpisURL"));
	}

	@Override
	public CompletionStage<ValidatorResult> validate(RuntimeEnvironment env, ValidatorData data,
			ValidatorDataSupport support) {
		return CompletableFuture.supplyAsync(() -> {
			var result = new ValidatorResult();
			result.setMessages(new ArrayList<>());

			result.setAnomalies(calculateAnomalies(env, data, support));

			return result;
		});
	}

	@Override
	public Map<ValidationAnomalyObject, List<ValidationAnomaly>> calculateAnomalies(RuntimeEnvironment env, ValidatorData data, ValidatorDataSupport support) {
		if (support.isCalculateAtPreviousVersion()) {
			throw new NotImplementedException("Calculate anomalies with version is not supported yet.");
		}

		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();
		data.getDeclarations().forEach(decl -> {
			anomalies.put(new ValidationAnomalyObject(decl.getDeclCode(), AnomalyObjectType.DECLARATION), new ArrayList<>());
			anomalies.put(new ValidationAnomalyObject(decl.getPlotCode(), AnomalyObjectType.PLOT), new ArrayList<>());
		});

		data.getPlots().forEach(plot -> {
			anomalies.put(new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT), new ArrayList<>());
			if (plot.getOperation() == ValidatorOperation.DELETE) {
				List<String> deletedPlotDeclCodes = validatorCropPlanDAO.getDeletedPlotDeclCodes(data.getCropPlanId(), plot.getPlotCode(), LocalDate.parse(DEFAULT_DATE));
				deletedPlotDeclCodes.forEach(declCode -> {
					anomalies.put(new ValidationAnomalyObject(declCode, AnomalyObjectType.DECLARATION), new ArrayList<>());
				});
			}
		});

		var plotCodes = data.getPlots()
				.stream()
				.filter(plot -> plot.getOperation() == ValidatorOperation.INSERT
						|| plot.getOperation() == ValidatorOperation.UPDATE)
				.map(ValidatorBoundedPlot::getPlotCode)
				.collect(toList());
		plotCodes.addAll(data.getDeclarations()
				.stream()
				.map(ValidatorBoundedDeclaration::getPlotCode)
				.filter(plotCode -> data.getPlots().stream()
						.noneMatch(plot -> plotCode.equals(plot.getPlotCode()) && plot.getOperation() == ValidatorOperation.DELETE))
				.collect(toList()));
		plotCodes = plotCodes.stream().distinct().collect(toList());

		var decls = data.getDeclarations()
				.stream()
				.filter(declaration -> declaration.getOperation() == ValidatorOperation.INSERT
						|| declaration.getOperation() == ValidatorOperation.UPDATE)
				.collect(toList());

		List<String> sv09ExternalCodes = validatorCropPlanDAO.getExternalCodes(data.getCropPlanId(), LocalDate.parse(DEFAULT_DATE));
		List<AnomPlotDeclarations> sv09PlotDeclarations = validatorCropPlanDAO.getAnomPlotDeclarations(
				data.getCropPlanId(), LocalDate.parse(DEFAULT_DATE), sv09ExternalCodes, "SV09");
		List<String> sv09PlotCodes = sv09PlotDeclarations.stream()
				.map(AnomPlotDeclarations::getPlotCode)
				.distinct()
				.collect(toList());

		this.checkSV09(sv09PlotCodes, sv09PlotDeclarations, plotCodes, data, anomalies, decls);

		List<VDSPlot> plots = getPlotsFromPlotCodes(plotCodes, support, data);

		this.checkPlotsAnomalies(plots, anomalies, support, data, env);
		this.checkDeclsAnomalies(anomalies, env, decls, data, support);

		
		return anomalies;
	}

	protected List<VDSPlot> getPlotsFromPlotCodes(List<String> plotCodes, ValidatorDataSupport support, ValidatorData data) {
		List<VDSPlot> plots = new ArrayList<>();
		for (var p : plotCodes) {
			var plot = support.getPlot(p, LocalDate.parse(DEFAULT_DATE), LocalDate.parse(DEFAULT_DATE));
			if (plot == null) {
				log.error("*** ERROR PLOT NOT FOUND: " + p);
				throw new IllegalStateException("The plot " + p + " was not found");
			}
			plots.add(plot);
		}

		return plots;
	}

	protected void checkPlotsAnomalies(List<VDSPlot> plots, Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, 
										ValidatorDataSupport support, ValidatorData data, RuntimeEnvironment env) {
		if (!plots.isEmpty()) {
			var tol = support.getPerimeterMultiplierAreaTolerance();
			checkSV01(anomalies, plots, tol);
			checkSV02(anomalies, plots, tol);
			checkSV03(anomalies, plots, data.getBusinessId());
			checkSV05(anomalies, plots, support);
			checkSV07(anomalies, env, plots, data.getCropPlanId());
			checkSV08(anomalies, env, plots, data.getCropPlanId());
		}
}

	protected void checkDeclsAnomalies(Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, RuntimeEnvironment env, List<ValidatorBoundedDeclaration> decls,
										ValidatorData data, ValidatorDataSupport support){
		if (!decls.isEmpty()) {
			checkSV04(anomalies, env, decls, data, support);
			checkSV09(anomalies, decls, data.getCropPlanId(), support);
		}
	}

	protected void checkSV09(List<String> sv09PlotCodes, List<AnomPlotDeclarations> so09PlotDeclarations, List<String> plotCodes, ValidatorData data, Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, List<ValidatorBoundedDeclaration> decls){
		for (String sv09PlotCode : sv09PlotCodes) {
			if (!plotCodes.contains(sv09PlotCode) && data.getPlots().stream().noneMatch(plot -> plot.getPlotCode().equals(sv09PlotCode) && plot.getOperation() == ValidatorOperation.DELETE)) {
				plotCodes.add(sv09PlotCode);
				anomalies.put(new ValidationAnomalyObject(sv09PlotCode, AnomalyObjectType.PLOT), new ArrayList<>());
			}
		}

		for (AnomPlotDeclarations so09PlotDeclaration : so09PlotDeclarations) {
			if (decls.stream().noneMatch(declaration -> declaration.getDeclCode().equals(so09PlotDeclaration.getDeclCode())) && data.getDeclarations().stream().noneMatch(decl -> decl.getDeclCode().equals(so09PlotDeclaration.getDeclCode()) && decl.getOperation() == ValidatorOperation.DELETE)) {
				decls.add(validatorCropPlanDAO.getAnomDeclaration(data.getCropPlanId(), so09PlotDeclaration.getPlotCode(), so09PlotDeclaration.getDeclCode(), LocalDate.parse(DEFAULT_DATE)));
				anomalies.put(new ValidationAnomalyObject(so09PlotDeclaration.getDeclCode(), AnomalyObjectType.DECLARATION), new ArrayList<>());
			}
		}

	}

	protected void checkSV01(Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, List<VDSPlot> plots, Double tol) {
		plots.forEach(plot -> {
			ValidationAnomalyObject vao = new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT);
			ValidationAnomaly validationAnomaly = new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, "SV01", null, true);
			if (checkOnPerc(tol)) {
				Double limitMax = getDeclarationAreaPercLimitMax();
				Double declarationAreaPercTotal = extractDeclarationAreaPercTotal(plot);
				if (declarationAreaPercTotal > limitMax)
					anomalies.get(vao).add(validationAnomaly);
			} else {
				Double limitMax = getDeclarationAreaSqmLimitMax(tol, plot);
				Double declarationAreaSqmTotal = extractDeclarationAreaSqmTotal(plot);
				if (declarationAreaSqmTotal > limitMax)
					anomalies.get(vao).add(validationAnomaly);
			}
		});
	}

	protected void checkSV02(Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, List<VDSPlot> plots, Double tol) {
		plots.forEach(plot -> {
			ValidationAnomalyObject vao = new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT);
			ValidationAnomaly validationAnomaly = new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, "SV02", null, true);
			if (checkOnPerc(tol)) {
				Double limitMin = getDeclarationAreaPercLimitMin();
				Double declarationAreaPercTotal = extractDeclarationAreaPercTotal(plot);
				if (declarationAreaPercTotal < limitMin)
					anomalies.get(vao).add(validationAnomaly);
			} else {
				Double convertedMin = getDeclarationAreaSqmLimitMin(tol, plot);
				Double declarationAreaSqmTotal = extractDeclarationAreaSqmTotal(plot);
				if (declarationAreaSqmTotal < convertedMin)
					anomalies.get(vao).add(validationAnomaly);
			}
		});
	}

	/**
	 * @param tol
	 * @return
	 */
	private boolean checkOnPerc(Double tol) {
		return tol == 0.0;
	}

	/**
	 * @param tol
	 * @param plot
	 * @return
	 */
	private double getDeclarationAreaSqmLimitMin(Double tol, VDSPlot plot) {
		return plot.getAreaSqm() - plot.getGeom().getLength() * tol;
	}

	/**
	 * @return
	 */
	private double getDeclarationAreaPercLimitMin() {
		return getDeclarationAreaPercLimit();
	}

	/**
	 * @param plot
	 * @return
	 */
	private Double extractDeclarationAreaPercTotal(VDSPlot plot) {
		BigDecimal declarationAreaPercTotal = new BigDecimal(0).setScale(8, RoundingMode.HALF_UP);
		for (var declaration : plot.getDecls())
			declarationAreaPercTotal = declarationAreaPercTotal.add(BigDecimal.valueOf(declaration.getAreaPerc()).setScale(8, RoundingMode.HALF_UP));
		return declarationAreaPercTotal.setScale(2, RoundingMode.HALF_UP).doubleValue();
	}

	/**
	 * @return
	 */
	private double getDeclarationAreaPercLimitMax() {
		return getDeclarationAreaPercLimit();
	}

	/**
	 * @return
	 */
	private double getDeclarationAreaPercLimit() {
		return 100.0;
	}

	/**
	 * @param tol
	 * @param plot
	 * @return
	 */
	private double getDeclarationAreaSqmLimitMax(Double tol, VDSPlot plot) {
		return plot.getAreaSqm() + plot.getGeom().getLength() * tol;
	}

	/**
	 * @param plot
	 * @return
	 */
	private Double extractDeclarationAreaSqmTotal(VDSPlot plot) {
		Double declarationAreaSqmTotal = 0.0;
		for (var declaration : plot.getDecls())
			declarationAreaSqmTotal += declaration.getAreaPerc() * plot.getAreaSqm() * 0.01;
		return declarationAreaSqmTotal;
	}

	private void checkSV03(Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, List<VDSPlot> plots, String businessId) {
		plots.forEach(plot -> {
			var sumOfIslandsAreas = validatorSchedarioCommonDAO.getSumOfIslandsAreas(plot.getGeom(), businessId);
			if (sumOfIslandsAreas == null || sumOfIslandsAreas < (plot.getAreaSqm() * 0.95)) {
				ValidationAnomalyObject vao = new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT);
				ValidationAnomaly validationAnomaly = new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, "SV03", null, true);
				anomalies.get(vao).add(validationAnomaly);
			}
		});
	}

	protected void checkSV04(Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, RuntimeEnvironment env,
			List<ValidatorBoundedDeclaration> declarations, ValidatorData data, ValidatorDataSupport support) {
		Long cropPlanId = data.getCropPlanId();
		List<CropPlanConfigData> cropPlanInvalidLandUseCodesConfigs = validatorCropPlanDAO.getCropPlanConfig(cropPlanId, "INVALID_LAND_USE_CODES", null);

		boolean shouldCheckForInvalidLandUseCode = !cropPlanInvalidLandUseCodesConfigs.isEmpty()
				&& cropPlanInvalidLandUseCodesConfigs.get(0).getParamValue() != null;

		List<String> invalidLandUseCodes = shouldCheckForInvalidLandUseCode
				? Arrays.asList(cropPlanInvalidLandUseCodesConfigs.get(0).getParamValue().split(" "))
				: Collections.emptyList();

		for (ValidatorBoundedDeclaration declaration : declarations) {

			if (declaration.getAreaPerc() <= 0) {
				continue;
			}

			boolean permanentCropFormsValidity;

			if (shouldCheckForInvalidLandUseCode && invalidLandUseCodes.contains(declaration.getLanduseCode())) {
				permanentCropFormsValidity = false;
			} else {
				permanentCropFormsValidity = this.checkPermanentCropFormsValidity(env, data, declaration, support);
			}

			if (!permanentCropFormsValidity) {
				ValidationAnomalyObject vao = new ValidationAnomalyObject(declaration.getDeclCode(), AnomalyObjectType.DECLARATION);
				ValidationAnomaly validationAnomaly = new ValidationAnomaly(declaration.getDeclCode(), AnomalyObjectType.DECLARATION, "SV04", null, true);
				anomalies.get(vao).add(validationAnomaly);
			}
		}
	}

	private Boolean checkPermanentCropFormsValidity(RuntimeEnvironment env, ValidatorData data, ValidatorBoundedDeclaration declaration,
			ValidatorDataSupport support) {
		List<PermanentCropFormFieldValue> permanentCropFormFieldsValues = support.getPermanentCropFormFieldsValues("VINEYARD_FORM");
		Map<String, List<String>> permanentCropFormFieldsLookupsMap = permanentCropFormFieldsValues.stream()
				.collect(Collectors.groupingBy(PermanentCropFormFieldValue::getFieldCode,
						Collectors.mapping(PermanentCropFormFieldValue::getFieldValue, toList())));

		List<PermanentCropFormFieldConfig> permanentCropFormsFieldsConfig = validatorCropPlanDAO.getPermanentCropFormsFieldsConfig(
				env.getTenantId(), "VINEYARD_FORM", "410", AbsoluteDate.of(data.getReferenceDt()));// TODO move in support?
		Map<String, Boolean> permanentCropFormsFieldsMandatoryMap = permanentCropFormsFieldsConfig.stream()
				.collect(Collectors.groupingBy(PermanentCropFormFieldConfig::getFieldCode,
						Collectors.mapping(PermanentCropFormFieldConfig::isFlMandatory, Collectors.reducing(false, (b1, b2) -> b1 || b2))));

		// decl validation
		if (!checkValidatorBoundedDeclarationData(data.getCropPlanId(), declaration, permanentCropFormFieldsLookupsMap)) {
			return false;
		}

		List<PermanentCropForm> permanentCropFormsLinkedToDeclaration = support
				.getPermanentCropForms(declaration.getDeclCode(), declaration.getPlotCode());

		PermanentCropFormDataFieldToCodeMapper fieldToCodeMapper = new PermanentCropFormDataFieldToCodeMapper();
		for (PermanentCropForm cpf : permanentCropFormsLinkedToDeclaration) {
			var cpfd = cpf.getPermanentCropFormData();
			if (!checkPermanentCropFormData(cpfd, fieldToCodeMapper, permanentCropFormsFieldsMandatoryMap, permanentCropFormFieldsLookupsMap)) {
				return false;
			}

		}
		return true;
	}

	private boolean checkPermanentCropFormData(PermanentCropFormData cpfd, PermanentCropFormDataFieldToCodeMapper fieldToCodeMapper,
			Map<String, Boolean> permanentCropFormsFieldsMandatoryMap, Map<String, List<String>> permanentCropFormFieldsLookupsMap) {

		if (!checkFieldMandatoryAndLookupValues(cpfd, fieldToCodeMapper,
				permanentCropFormsFieldsMandatoryMap, permanentCropFormFieldsLookupsMap, Set.of("VARIETY_CODE", "AREA_SQM"))) {
			return false;
		}

		if (checkDistanceBetweenRowsCm(cpfd)) {
			log.debug("'{}' has not valid value {}", Fields.distanceBetweenRowsCm, cpfd.getDistanceBetweenRowsCm());
			return false;
		}
		if (checkDistanceOnTheRowCm(cpfd)) {
			log.debug("'{}' has not valid value {}", Fields.distanceOnTheRowCm, cpfd.getDistanceOnTheRowCm());
			return false;
		}
		if (checkStumpsNumber(cpfd)) {
			log.debug("'{}' has not valid value {}", Fields.stumpsNumber, cpfd.getStumpsNumber());
			return false;
		}
		/*
		 * if (hasDecimals(cpfd.getStumpsDensity100()) || valueNotGreaterThan(cpfd.getStumpsDensity100(), 0) ||
		 * !hasExpectedStumpsDensity100(cpfd.getStumpsDensity100(), cpfd.getStumpsNumber(), plot.getAreaSqm(), declaration.getAreaPerc())) {
		 * log.debug("'{}' has not valid value {}", Fields.stumpsDensity100, cpfd.getStumpsDensity100()); return false; }
		 */
		if (checkFailuresPerc(cpfd)) {
			log.debug("'{}' has not valid value {}", Fields.failuresPerc, cpfd.getFailuresPerc());
			return false;
		}
		if (checkSoilLayeringPerc(cpfd)) {
			log.debug("'{}' has not valid value {}", Fields.soilLayeringPerc, cpfd.getSoilLayeringPerc());
			return false;
		}
		if (checkAltitudeAboveSeaLevel(cpfd)) {
			log.debug("'{}' has not valid value {}", Fields.altitudeAboveSeaLevel, cpfd.getAltitudeAboveSeaLevel());
			return false;
		}
		if (valueNotBetweenInclusive(cpfd.getPolesDistanceCm(), 50, 1000)) {
			log.debug("'{}' has not valid value {}", Fields.polesDistanceCm, cpfd.getPolesDistanceCm());
			return false;
		}

		return true;
	}

	private boolean checkAltitudeAboveSeaLevel(PermanentCropFormData cpfd) {
		return hasDecimals(cpfd.getAltitudeAboveSeaLevel())
				|| valueNotBetweenInclusive(cpfd.getAltitudeAboveSeaLevel(), 0, 3000);
	}

	private boolean checkSoilLayeringPerc(PermanentCropFormData cpfd) {
		return hasDecimals(cpfd.getSoilLayeringPerc())
				|| valueNotBetweenInclusive(cpfd.getSoilLayeringPerc(), 0, 100);
	}

	private boolean checkFailuresPerc(PermanentCropFormData cpfd) {
		return hasDecimals(cpfd.getFailuresPerc())
				|| valueNotBetweenInclusive(cpfd.getFailuresPerc(), 0, 100);
	}

	private boolean checkStumpsNumber(PermanentCropFormData cpfd) {
		return hasDecimals(cpfd.getStumpsNumber())
				|| valueNotGreaterThan(cpfd.getStumpsNumber(), 0);
	}

	private boolean checkDistanceOnTheRowCm(PermanentCropFormData cpfd) {
		return hasDecimals(cpfd.getDistanceOnTheRowCm())
				|| valueNotBetweenInclusive(cpfd.getDistanceOnTheRowCm(), 50, 1000);
	}

	private boolean checkDistanceBetweenRowsCm(PermanentCropFormData cpfd) {
		return hasDecimals(cpfd.getDistanceBetweenRowsCm())
				|| valueNotBetweenInclusive(cpfd.getDistanceBetweenRowsCm(), 50, 1000);
	}

	private boolean checkValidatorBoundedDeclarationData(Long cropPlanId, ValidatorBoundedDeclaration declaration, Map<String, List<String>> permanentCropFormFieldsLookupsMap) {
		if (null == declaration.getFromDate()
				|| valueNotBetweenInclusive(declaration.getFromDate().getYear(), 1900, validatorSchedarioDAO.getCurrentTimestamp().getYear())) {
			log.debug("'declaration.fromDate' has not valid value {}", declaration.getFromDate());
			return false;
		}
		List<String> possibleFromDatePrecision = List.of("Y", "YM", "YMD");

		String cropPlanConfigDatePrecision = validatorCropPlanDAO.getCropPlanConfig(cropPlanId, "MANDATORY_PLANTING_DATE_PRECISION", null)
				.stream()
				.findFirst()
				.map(CropPlanConfigData::getParamValue)
				.orElse("YM");

		List<String> currentValidDatePrecisionStrings = possibleFromDatePrecision.stream().filter(fromDateString -> fromDateString.contains(cropPlanConfigDatePrecision)).collect(Collectors.toList());

		if (null == declaration.getFromDatePrecision()
				|| !currentValidDatePrecisionStrings.contains(StringUtils.upperCase(declaration.getFromDatePrecision()))) {
			log.debug("'declaration.fromDatePrecision' has not valid value {}", declaration.getFromDatePrecision());
			return false;
		}

		/*
		 * if(null == declaration.getAreaPerc() || valueNotGreaterThan(declaration.getAreaPerc(), 0)) {
		 * log.debug("'declaration.areaPerc' has not valid value {}", declaration.getAreaPerc()); return false; }
		 */
		if (StringUtils.isBlank(declaration.getLanduseCode())
				|| !permanentCropFormFieldsLookupsMap.get("VARIETY_CODE").contains(declaration.getLanduseCode())) {
			log.debug("'declaration.landuseCode' has not valid value {}", declaration.getLanduseCode());
			return false;
		}

		return true;
	}
	/*private boolean hasExpectedStumpsDensity100(Double stumpsDensity100, Integer stumpsNumber, Integer plotAreaSqm, Double areaPerc) {
		if (null == stumpsDensity100 || null == stumpsNumber) {
			return true;
		}

		if (null == plotAreaSqm || plotAreaSqm.equals(0) || null == areaPerc || areaPerc.equals(0.)) {
			throw new IllegalStateException(String.format("cannot calculate stumpsDensity100 with `plotAreaSqm` = %s and `areaPerc` = %s", plotAreaSqm, areaPerc));
		}

		int calculatedDensity = BigDecimal.valueOf(stumpsNumber).multiply(BigDecimal.valueOf(10_000 * 100))
				.divide(BigDecimal.valueOf(areaPerc).multiply(BigDecimal.valueOf(plotAreaSqm)), 4, RoundingMode.HALF_UP)
				.setScale(0, RoundingMode.HALF_UP).intValue();
		return stumpsDensity100.intValue() == calculatedDensity;
	}*/

	private boolean hasDecimals(Number number) {
		if (null == number) {
			return false;
		}

		double doubleValue = number.doubleValue();
		long intValue = number.longValue();
		return doubleValue != intValue;
	}

	private boolean valueNotBetweenInclusive(Number value, Number min, Number max) {
		return null != value &&
				(value.doubleValue() < min.doubleValue() || value.doubleValue() > max.doubleValue());
	}

	private boolean valueNotGreaterThan(Number value, Number min) {
		return null != value && value.doubleValue() <= min.doubleValue();
	}

	private boolean checkFieldMandatoryAndLookupValues(PermanentCropFormData cpfd, PermanentCropFormDataFieldToCodeMapper fieldToCodeMapper,
			Map<String, Boolean> permanentCropFormsFieldsMandatoryMap, Map<String, List<String>> permanentCropFormFieldsLookupsMap, Set<String> excludeFields) {
		for (Field field : cpfd.getClass().getDeclaredFields()) {
			String fieldCode = fieldToCodeMapper.getCode(field.getName());
			if (null != fieldCode && !excludeFields.contains(fieldCode)) {
				field.setAccessible(true);
				try {
					Object value = field.get(cpfd);
					if (!checkPermanentCropFormDataValue(value, permanentCropFormsFieldsMandatoryMap, permanentCropFormFieldsLookupsMap, fieldCode,
							field.getName())) {
						return false;
					}
				} catch (IllegalAccessException e) {
					throw new IllegalStateException("checkFieldMandatoryAndLookupValues failed");
				}
			}
		}
		return true;
	}

	private boolean checkPermanentCropFormDataValue(Object value, Map<String, Boolean> permanentCropFormsFieldsMandatoryMap,
			Map<String, List<String>> permanentCropFormFieldsLookupsMap, String fieldCode, String fieldName) {

		boolean result = true;
		if (null != value && StringUtils.isNotBlank(value.toString())) {
			List<String> expectedValues = permanentCropFormFieldsLookupsMap.get(fieldCode);
			if (null != expectedValues && !expectedValues.contains(value.toString())) {
				log.debug("'{}' failed lookup check. found value: '{}', expected one of: {}", fieldName, value, expectedValues);
				result = false;
			}
		} else if (Boolean.TRUE.equals(permanentCropFormsFieldsMandatoryMap.get(fieldCode))) {
			log.debug("'{}' failed mandatory check", fieldName);
			result = false;
		}

		return result;
	}

	/*private boolean checkFarmingForm(PermanentCropFormData cpfd, List<PermanentCropFormFieldValue> permanentCropFormFieldsValues) {
		if (cpfd.getFarmingForm() != null) {
			var existsDecodingForFarmingForm = permanentCropFormFieldsValues.stream()
					.filter((pcffv) -> pcffv.getFieldCode().equals("FARMING_FORM")
							&& pcffv.getFieldValue().equals(cpfd.getFarmingForm()))
					.count() > 0;
			if (!existsDecodingForFarmingForm)
				return false;
		}
		return true;
	}
	
	private boolean checkIrrigation(PermanentCropFormData cpfd, List<PermanentCropFormFieldValue> permanentCropFormFieldsValues) {
		if (cpfd.getIrrigation() != null) {
			var existsDecodingForIrrigationFlag = permanentCropFormFieldsValues.stream()
					.filter((pcffv) -> pcffv.getFieldCode().equals("IRRIGATION")
							&& pcffv.getFieldValue().equals(cpfd.getIrrigation()))
					.count() > 0;
			if (!existsDecodingForIrrigationFlag)
				return false;
		}
		return true;
	}*/

	private void checkSV05(Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, List<VDSPlot> plots, ValidatorDataSupport support) {
		plots.forEach(plot -> {
			ValidationAnomalyObject vao = new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT);
			ValidationAnomaly validationAnomaly = checkSV05Atomically(plot, support);
			if (validationAnomaly != null) {
				anomalies.get(vao).add(validationAnomaly);
			}
		});
	}

	private ValidationAnomaly checkSV05Atomically(VDSPlot plot, ValidatorDataSupport support) {
		if (plot.getDecls().isEmpty())
			return new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, "SV05", null, false);
		/*for (var decl : plot.getDecls())
			if (!support.getPermanentCropForms(decl.getDeclCode(), decl.getPlotCode()).isEmpty())
				return null;
		return new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, "SV05", null, false);*/
		return null;
	}

	// check SV07 - parcelle fittizie
	protected void checkSV07(Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, RuntimeEnvironment env, List<VDSPlot> plots, Long planId) {
		plots.forEach(plot -> {
			ValidationAnomalyObject vao = new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT);
			ValidationAnomaly validationAnomaly = checkSV07Atomically(env, plot, planId);
			if (validationAnomaly != null)
				anomalies.get(vao).add(validationAnomaly);
		});
	}

	private ValidationAnomaly checkSV07Atomically(RuntimeEnvironment env, VDSPlot plot, Long planId) {
		String description = validatorCropPlanDAO.getPlotDescription(plot.getPlotCode(), planId);
		if (description != null) {
			String[] pn = description.split("-");
			if (pn.length == 4 && "SV".equals(pn[0])) {
				String fonte = validatorSchedarioDAO.getFonte(pn[1], pn[2], pn[3]);
				if (FONTE_PARCELLA_FITTIZIA.equals(fonte)) {
					ParcelEditStatusV1 parcelEditStatus = getParcelEditStatus(env, pn);
					if (null == parcelEditStatus || !parcelEditStatus.getLastUpdate().isAfter(parcelEditStatus.getCreationDate())) {
						return new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, "SV07", null, false);
					}
				}
			}
		}
		return null;
	}

	// check SV08 - parcelle condivise
	protected void checkSV08(Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, RuntimeEnvironment env, List<VDSPlot> plots, Long planId) {
		plots.forEach(plot -> {
			ValidationAnomalyObject vao = new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT);
			ValidationAnomaly validationAnomaly = checkSV08Atomically(env, plot, planId);
			if (validationAnomaly != null)
				anomalies.get(vao).add(validationAnomaly);
		});
	}

	private ValidationAnomaly checkSV08Atomically(RuntimeEnvironment env, VDSPlot plot, Long planId) {
		String description = validatorCropPlanDAO.getPlotDescription(plot.getPlotCode(), planId);
		if (description != null) {
			String[] pn = description.split("-");
			if (pn.length == 4 && "SV".equals(pn[0]) && validatorCropPlanDAO.getParcelInOtherCropPlansCount(planId, description, env.getTenantId()) > 0)
				return new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, "SV08", null, true);
		}
		return null;
	}

	private ParcelEditStatusV1 getParcelEditStatus(RuntimeEnvironment env, String[] pn) {
		String api = "{tenant}/public/v1/lpis/sectors/{sector_code}/blocks/{blockCode}/parcels/{parcelCode}/edit-status";
		Map<String, Object> pathVariables = Map.of(
				"tenant", env.getTenantId(),
				"sector_code", pn[1],
				"blockCode", pn[2],
				"parcelCode", pn[3]
		);

		ParcelEditStatusV1 parcelEditStatus;
		try {
			parcelEditStatus = env.getAuthenticatedWebTarget(lpisURL)
					.path(api)
					.resolveTemplates(pathVariables)
					.request(MediaType.APPLICATION_JSON_TYPE)
					.get(new GenericType<>() {
					});
		} catch (NotFoundException nfe) {
			parcelEditStatus = null;
		}
		return parcelEditStatus;
	}

	// check SV09 - external code su piu' parcelle
	private void checkSV09(Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies, List<ValidatorBoundedDeclaration> declarations, Long planId, ValidatorDataSupport support) {
		for (ValidatorBoundedDeclaration declaration : declarations) {
			List<PermanentCropForm> pcfs = support.getPermanentCropForms(declaration.getDeclCode(), declaration.getPlotCode());
			for (PermanentCropForm pcf : pcfs) {
				if ("VINEYARD_FORM".equals(pcf.getFormType()) && pcf.getPermanentCropFormData().getExternalCode() != null &&
						validatorCropPlanDAO.getDeclWithSameExternalCodeCount(planId, declaration.getDeclCode(), pcf.getPermanentCropFormData().getExternalCode()) > 0) {
							ValidationAnomalyObject vao = new ValidationAnomalyObject(declaration.getDeclCode(), AnomalyObjectType.DECLARATION);
							ValidationAnomaly validationAnomaly = new ValidationAnomaly(declaration.getDeclCode(), AnomalyObjectType.DECLARATION, "SV09", null, false);
							anomalies.get(vao).add(validationAnomaly);
					break;
				}
			}
		}
	}

	@Override
	public boolean ignoreBlockingAnomalies(RuntimeEnvironment env) {
		return true;
	}

	@Override
	public String getCropPlanType() {
		return "VINEALIGN";
	}

}
