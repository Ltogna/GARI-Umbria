package com.abacogroup.cropplan.plugins.agea.common.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LpisParcels {
	private String nextKey;
	private List<LpisParcel> records;
}
