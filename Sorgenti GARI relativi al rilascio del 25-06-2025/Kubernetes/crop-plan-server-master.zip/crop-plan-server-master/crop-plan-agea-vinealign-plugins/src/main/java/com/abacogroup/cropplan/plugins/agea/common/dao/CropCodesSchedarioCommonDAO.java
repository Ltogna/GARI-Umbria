package com.abacogroup.cropplan.plugins.agea.common.dao;

import com.abacogroup.cropplan.sdk.model.domain.LandCover;
import com.abacogroup.jdbi.EnhancedSqlObject;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import java.util.List;

public interface CropCodesSchedarioCommonDAO extends EnhancedSqlObject {
	@SqlQuery("select distinct cod_vari as landCoverCode,"
			+ "           descrizione as landCoverDescription"
			+ "      from SITIPROD.SITICODS_VARI"
			+ "     where cod_vari in (<landCoverCodes>)")
	@RegisterBeanMapper(LandCover.class)
	List<LandCover> getLandCoverDescriptions(@BindList("landCoverCodes") List<String> landCoverCodes);
}
