package com.abacogroup.cropplan.plugins.agea.external_microservices.request;

import lombok.Data;
import org.locationtech.jts.geom.Geometry;

@Data
public class ParcelsBySectorCodeWithTouchingGeometryDto {
	private Geometry geom;
	private String srs;
}
