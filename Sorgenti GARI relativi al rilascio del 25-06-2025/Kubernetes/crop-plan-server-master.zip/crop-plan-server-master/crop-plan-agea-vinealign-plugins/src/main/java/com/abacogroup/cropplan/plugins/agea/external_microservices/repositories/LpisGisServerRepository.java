package com.abacogroup.cropplan.plugins.agea.external_microservices.repositories;

import com.abacogroup.cropplan.plugins.agea.common.models.LpisParcel;
import com.abacogroup.cropplan.plugins.agea.common.models.LpisParcels;
import com.abacogroup.cropplan.plugins.agea.external_microservices.request.ParcelsBySectorCodeWithTouchingGeometryDto;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.Invocation;
import jakarta.ws.rs.core.Response;

import java.util.ArrayList;
import java.util.List;

import static com.abacogroup.cropplan.plugins.agea.external_microservices.request_builders.LpisGisServerRequestBuilder.buildGetListOfParcelsInSectorCodeWithTouchingGeometry;

public class LpisGisServerRepository {
	public static List<LpisParcel> getListOfParcelsInSectorCodeWithTouchingGeometry(RuntimeEnvironment env, String taskManagerServerUrl, String tenantId,
			String sectorCode, String referenceDate, ParcelsBySectorCodeWithTouchingGeometryDto parcelsBySectorCodeWithTouchingGeometryDto) {
		List<LpisParcel> parcels = new ArrayList<>();

		String nextKey = null;

		do {
			Invocation.Builder builder = buildGetListOfParcelsInSectorCodeWithTouchingGeometry(env, taskManagerServerUrl, tenantId, sectorCode, referenceDate,
					nextKey);

			try (var response = builder.post(Entity.json(parcelsBySectorCodeWithTouchingGeometryDto))) {
				checkResponse(response);

				LpisParcels parcelsInfiniteListResultsReadDto = response.readEntity(LpisParcels.class);

				parcels.addAll(parcelsInfiniteListResultsReadDto.getRecords());
				nextKey = parcelsInfiniteListResultsReadDto.getNextKey();
			}
		} while (nextKey != null);

		return parcels;
	}

	private static void checkResponse(Response response) {
		if (response.getStatus() != 200)
			throw new IllegalStateException("Unexpected response status: " + response.getStatus());
	}
}
