package com.abacogroup.cropplan.plugins.agea.common;

import com.abacogroup.cropplan.plugins.agea.common.dao.AuthSchedarioDAO;
import com.abacogroup.cropplan.sdk.model.auth.BusinessAccessLevel;
import com.abacogroup.cropplan.sdk.model.auth.CropPlanTypeAccessLevel;
import com.abacogroup.cropplan.sdk.spi.AuthPlugin;
import com.abacogroup.dropwizard.auth.sso2.UserFunction;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import java.util.List;

public class AuthPluginImpl implements AuthPlugin, InitializablePlugin {

	private static final String JDBI_NAME_SCHEDARIO = "dbSchedario";

	private static final String LDAP_DEFAULT_GROUP = "GEST_SCHEDARIO_FO";

	private static final List<String> LDAP_REG_GROUPS = List.of("GEST_SCHEDARIO_BO_REGI", "SCHEDARIO_BO_REGI_CONS");

	private AuthSchedarioDAO authSchedarioDAO;

	@Override
	public void initialize(PluginsEnvironment env) {
		var jdbiSchedario = env.getJdbi(JDBI_NAME_SCHEDARIO);
		if (jdbiSchedario == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SCHEDARIO);

		authSchedarioDAO = jdbiSchedario.onDemand(AuthSchedarioDAO.class);
	}

	@Override
	public BusinessAccessLevel getBusinessAccessLevel(RuntimeEnvironment env, String businessId) {

		final boolean onlyEmpowered = !canIgnoreProxies(env);

		Integer countMandati = getCountMandatiBasedOnTenantAlignType(env, businessId, onlyEmpowered);

		if (countMandati > 0) {
			return BusinessAccessLevel.WRITE;
		}

		return BusinessAccessLevel.NO_ACCESS;
	}

	@Override
	public CropPlanTypeAccessLevel getCropPlanTypeAccessLevel(RuntimeEnvironment env, String businessId,
			String cropPlanTypeCode) {

		final boolean onlyEmpowered = !canIgnoreProxies(env);

		Integer countMandati = getCountMandatiBasedOnTenantAlignType(env, businessId, onlyEmpowered);

		if (countMandati > 0) {
			return CropPlanTypeAccessLevel.CREATE;
		}

		return CropPlanTypeAccessLevel.NO_ACCESS;
	}

	@Override
	public String getCropPlanTypeLockedErrorCode(RuntimeEnvironment env, String businessId, String cropPlanTypeCode) {
		return null;
	}

	private boolean canIgnoreProxies(RuntimeEnvironment env) {
		return env.getSso2Client().isFunctionEnabled(env.getUser(), UserFunction.fromPipeSeparatedString("CRPL|IGNORE_PARTIES_ACL"));
	}

	private Integer getCountMandatiBasedOnTenantAlignType(RuntimeEnvironment env, String businessId, boolean onlyEmpowered) {
		String upperCaseTenant = env.getTenantId().toUpperCase();

		Integer countMandati;

		switch (upperCaseTenant) {
		case "VINE":
			countMandati = authSchedarioDAO.countMandati(businessId, env.getUserName(), LDAP_DEFAULT_GROUP, LDAP_REG_GROUPS, onlyEmpowered);
			break;
		case "FRUIT":
			countMandati = authSchedarioDAO.countFruitMandati(businessId, env.getUserName(), LDAP_DEFAULT_GROUP, LDAP_REG_GROUPS, onlyEmpowered);
			break;
		case "OLIVE":
			countMandati = authSchedarioDAO.countOliveMandati(businessId, env.getUserName(), LDAP_DEFAULT_GROUP, LDAP_REG_GROUPS, onlyEmpowered);
			break;
		default:
			throw new IllegalStateException("Unexpected tenant detected.");
		}

		return countMandati;
	}
}
