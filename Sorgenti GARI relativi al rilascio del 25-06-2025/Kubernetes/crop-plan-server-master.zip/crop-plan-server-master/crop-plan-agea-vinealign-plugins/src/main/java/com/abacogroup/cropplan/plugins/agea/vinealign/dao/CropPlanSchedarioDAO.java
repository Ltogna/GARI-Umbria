package com.abacogroup.cropplan.plugins.agea.vinealign.dao;

import com.abacogroup.cropplan.plugins.agea.common.models.ntt.Iscrizione;
import com.abacogroup.jdbi.EnhancedSqlObject;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import java.util.List;

public interface CropPlanSchedarioDAO extends EnhancedSqlObject {
	@SqlQuery("select codice_iscrizione as code,"
			+ "       categoria as categoria, "
			+ "       albo_elenco as alboElenco, "
			+ "       tipologia as tipologia, "
			+ "       decode(fg_blocco_tipologia,'S','S',null) as bloccoTipologia, "
			+ "       decode(fg_blocco_rivendica,'S','S',null) as bloccoRivendica, "
			+ "       decode(fg_blocco_idoneita,'S','S',null) as bloccoIdoneita, "
			+ "       decode(fg_attingimento,'S','S',null) as attingimento"
			+ "  from SV_UNAR_ISCRIZIONI"
			+ " where pkid_unar = :externalCode"
			+ "   and codice_iscrizione in (<subscritionCodes>)")
	@RegisterBeanMapper(Iscrizione.class)
	List<Iscrizione> getSubscriptions(@Bind("externalCode") Long externalCode, @BindList("subscritionCodes") List<String> subscritionCodes);
}
