package com.abacogroup.cropplan.plugins.agea.olivealign;

import static java.util.stream.Collectors.toList;

import com.abacogroup.cropplan.plugins.agea.common.dao.DomainCropPlanDAO;
import com.abacogroup.cropplan.plugins.agea.common.dao.DomainSchedarioCommonDAO;
import com.abacogroup.cropplan.plugins.agea.common.dao.LayersCropPlanDAO;
import com.abacogroup.cropplan.plugins.agea.common.models.CuttableLayerWithGeoms;
import com.abacogroup.cropplan.plugins.agea.common.models.GeometryWithSrs;
import com.abacogroup.cropplan.plugins.agea.common.models.LpisParcel;
import com.abacogroup.cropplan.plugins.agea.common.models.ntt.DomainDeclData;
import com.abacogroup.cropplan.plugins.agea.external_microservices.repositories.LpisGisServerRepository;
import com.abacogroup.cropplan.plugins.agea.external_microservices.request.ParcelsBySectorCodeWithTouchingGeometryDto;
import com.abacogroup.cropplan.sdk.model.layers.AdditionalLayer;
import com.abacogroup.cropplan.sdk.model.layers.CuttableLayer;
import com.abacogroup.cropplan.sdk.model.layers.GISInfo;
import com.abacogroup.cropplan.sdk.model.layers.WmsLayer;
import com.abacogroup.cropplan.sdk.model.layers.WmtsLayer;
import com.abacogroup.cropplan.sdk.model.layers.lpis.LpisAdditionalLayersResponse;
import com.abacogroup.cropplan.sdk.model.layers.lpis.LpisWmsLayer;
import com.abacogroup.cropplan.sdk.model.layers.lpis.LpisWmtsLayer;
import com.abacogroup.cropplan.sdk.spi.LayersPlugin;
import com.abacogroup.cropplan.sdk.support.InfiniteListResultsSupport;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import jakarta.ws.rs.core.MediaType;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryFactory;

public class LayersPluginImpl implements LayersPlugin, InitializablePlugin {
	private static final String JDBI_CROP_PLAN = "mainDB";
	private static final String JDBI_NAME_SCHEDARIO = "dbSchedario";
	private static final String URL_LPIS = "lpisURL";
	public static final String LAYER_CODE_DOMAIN_PLOTS = "DOMAIN_PLOTS";
	public static final String LAYER_TITLE_DOMAIN_PLOTS = "UNAR parcelle olivicole aziendali";
	public static final String SNAP_EL_TYPE_PARCEL = "PARCEL";
	public static final String SNAP_EL_TYPE_SUOLI = "SUOLI";

	private LayersCropPlanDAO layersCropPlanDAO;
	private DomainCropPlanDAO domainCropPlanDAO;
	private DomainSchedarioCommonDAO domainSchedarioCommonDAO;

	@Override
	public void initialize(PluginsEnvironment env) {
		var jdbiCropPlan = env.getJdbi(JDBI_CROP_PLAN);
		if (jdbiCropPlan == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_CROP_PLAN);
		
		layersCropPlanDAO = jdbiCropPlan.onDemand(LayersCropPlanDAO.class);
		domainCropPlanDAO = jdbiCropPlan.onDemand(DomainCropPlanDAO.class);

		var jdbiSchedario = env.getJdbi(JDBI_NAME_SCHEDARIO);
		if (jdbiSchedario == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SCHEDARIO);

		domainSchedarioCommonDAO = jdbiSchedario.onDemand(DomainSchedarioCommonDAO.class);

	}

	@Override
	public List<AdditionalLayer> getAdditionalLayers(RuntimeEnvironment env, String businessId, String domainZoneId, Integer campaignYear, String module) {
		return getLPISAdditionalLayers(env, businessId, domainZoneId);
	}

	private List<AdditionalLayer> getLPISAdditionalLayers(RuntimeEnvironment env, String businessId, String domainZoneId) {
		List<AdditionalLayer> additionalLayers = new ArrayList<>();

		Object url = env.getProperty(URL_LPIS);
		if (url == null || domainZoneId == null || domainZoneId.isEmpty()) {
			return additionalLayers;
		}

		var request = env.getAuthenticatedWebTarget(url.toString())
				.path(env.getTenantId())
				.path("public")
				.path("v1")
				.path("lpis")
				.path("support")
				.path("additional-layers")
				.queryParam("module", "cropplan")
				.queryParam("sector_code", domainZoneId)
				.request(MediaType.APPLICATION_JSON)
				.get();
		if (request.getStatus() != 200)
			throw new IllegalStateException("Unexpected response status: " + request.getStatus());
		var layers = request.readEntity(LpisAdditionalLayersResponse.class);

		for (var layer : layers.getWmsLayers()) {
			String layerUrl = layer.getUrl();
			String resolvedUrl = env.getJerseyClient().target(layerUrl)
					.resolveTemplate("cuaa", businessId)
					.resolveTemplate("tenant", env.getTenantId())
					.resolveTemplate("srs", layer.getSrs())
					.resolveTemplate("reference_date", LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")))
					.resolveTemplate("sector_code", domainZoneId)
					.getUri()
					.toString();

			layer.setSnapElementType(buildSnapElementType(layer.getCode(), layer.getSnapElementType()));

			WmsLayer wmsLayer = buildWmsLayer(layer, resolvedUrl);
			
			additionalLayers.add(wmsLayer);
		}

		for (var layer : layers.getWmtsLayers()) {
			String layerUrl = layer.getUrl();
			String resolvedUrl = env.getJerseyClient().target(layerUrl)
					.resolveTemplate("cuaa", businessId)
					.resolveTemplate("tenant", env.getTenantId())
					.resolveTemplate("srs", layer.getSrs())
					.resolveTemplate("reference_date", LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")))
					.resolveTemplate("sector_code", domainZoneId)
					.getUri()
					.toString();

			WmtsLayer wmtsLayer = buildWmtsLayer(domainZoneId, layer, resolvedUrl);

			additionalLayers.add(wmtsLayer);
		}

		additionalLayers = additionalLayers.stream()
				.sorted(Comparator.comparing(AdditionalLayer::getLegendOrder))
				.collect(toList());

		return additionalLayers;
	}
	
	private String buildSnapElementType(String layerCode, String defaultType) {

		String result = defaultType;

		/*if (layerCode.startsWith("particelle-catastali-aziendali-")) {
			result = "CAD_PARCEL";
		} else if (layerCode.startsWith("poligoni-gps-")) {
			result = "POLIGONI_GPS";
		} else*/ if (layerCode.startsWith("suolo-olivicolo-")) {
			result = SNAP_EL_TYPE_SUOLI;
		} else if (layerCode.startsWith("parcelle-olivicole-")) {
			result = SNAP_EL_TYPE_PARCEL;
		}

		return result;
	}

	private WmtsLayer buildWmtsLayer(String domainZoneId, LpisWmtsLayer layer, String resolvedUrl) {
		WmtsLayer wmtsLayer = new WmtsLayer();
		wmtsLayer.setCode(layer.getCode());
		wmtsLayer.setDescription(layer.getDescription());
		wmtsLayer.setEnabledInOverview(layer.isEnabledInOverview());
		wmtsLayer.setForegroundLevel(layer.getForegroundLevel());
		wmtsLayer.setFormat(layer.getFormat());
		wmtsLayer.setLayer(layer.getLayer());
		wmtsLayer.setLayerParameters(layer.getLayerParameters());
		wmtsLayer.setLayerType(layer.getPublicLayerType());
		wmtsLayer.setLegendOrder(layer.getLegendOrder());
		wmtsLayer.setMaxResolution(layer.getMaxResolution());
		wmtsLayer.setMinResolution(layer.getMinResolution());
		wmtsLayer.setOn(layer.isOn());
		wmtsLayer.setServerConfig(layer.getServerConfig());
		wmtsLayer.setSnapElementType(layer.getSnapElementType());
		wmtsLayer.setSrs(layer.getSrs());
		wmtsLayer.setStyle(layer.getStyle());
		wmtsLayer.setTileMatrix(layer.getTileMatrix());
		wmtsLayer.setTileMatrixSet(domainZoneId);
		wmtsLayer.setUrl(resolvedUrl);
		wmtsLayer.setVersion(layer.getVersion());
		return wmtsLayer;
	}

	private WmsLayer buildWmsLayer(LpisWmsLayer layer, String resolvedUrl) {
		WmsLayer wmsLayer = new WmsLayer();
		wmsLayer.setBgcolor(layer.getBgcolor());
		wmsLayer.setCode(layer.getCode());
		wmsLayer.setDescription(layer.getDescription());
		wmsLayer.setEnabledInOverview(layer.isEnabledInOverview());
		wmsLayer.setForegroundLevel(layer.getForegroundLevel());
		wmsLayer.setFormat(layer.getFormat());
		wmsLayer.setLayerParameters(layer.getLayerParameters());
		wmsLayer.setLayers(layer.getLayers());
		wmsLayer.setLayerType(layer.getPublicLayerType());
		wmsLayer.setLegendOrder(layer.getLegendOrder());
		wmsLayer.setMaxResolution(layer.getMaxResolution());
		wmsLayer.setMinResolution(layer.getMinResolution());
		wmsLayer.setOn(layer.isOn());
		wmsLayer.setServerConfig(layer.getServerConfig());
		wmsLayer.setSnapElementType(layer.getSnapElementType());
		wmsLayer.setSrs(layer.getSrs());
		wmsLayer.setStyles(layer.getStyles());
		wmsLayer.setTransparent(layer.getTransparent());
		wmsLayer.setUrl(resolvedUrl);
		wmsLayer.setVersion(layer.getVersion());
		return wmsLayer;
	}

	@Override
	public List<GISInfo> getGISInfo(RuntimeEnvironment env, String businessId, String domainZoneId,
			LocalDate pointInTime, Double x, Double y, List<String> layerCodes) {
		var touchingGeometry = new GeometryFactory().createPoint(new Coordinate(x, y));
		ArrayList<GISInfo> gisInfos = new ArrayList<>();

		if (layerCodes.contains(LAYER_CODE_DOMAIN_PLOTS)) {
			Long cropPlanId = layersCropPlanDAO.getCropPlanId(env.getTenantId(), businessId, getCropPlanType());
			if (cropPlanId != null) {
				GISInfo gisInfo = new GISInfo();
				gisInfo.setLayerCode(LAYER_CODE_DOMAIN_PLOTS);
				gisInfo.setTitle(LAYER_TITLE_DOMAIN_PLOTS);
				gisInfo.setCards(new LinkedList<>());

				List<DomainDeclData> gisInfoData = layersCropPlanDAO.getDomainDeclsGisInfoData(env.getTenantId(), env.getLocale().getLanguage(),
						cropPlanId, domainZoneId, layersCropPlanDAO.getCurrentTimestamp(), AbsoluteDate.of(pointInTime).getValue(),
						touchingGeometry, getCropPlanType());
				gisInfoData.forEach(gis -> gisInfo.getCards().add(new GISInfo.GISInfoCard(
						gis.getLandUseDescription(),
						Math.toIntExact(Math.round(gis.getAreaSqm() * (gis.getAreaPerc() / 100.))),
						gis.getMbr(),
						List.of(
								new GISInfo.GISInfoCardField("Anno di impianto", String.valueOf(gis.getFromDate().toLocalDate().getYear())),
								new GISInfo.GISInfoCardField("Mese di impianto", String.valueOf(gis.getFromDate().toLocalDate().getMonthValue())),
								new GISInfo.GISInfoCardField("Giorno di impianto", String.valueOf(gis.getFromDate().toLocalDate().getDayOfMonth())),
								new GISInfo.GISInfoCardField("Sesto su fila", String.valueOf(gis.getDistanceOnTheRowCm())),
								new GISInfo.GISInfoCardField("Sesto tra file", String.valueOf(gis.getDistanceBetweenRowsCm())),
								new GISInfo.GISInfoCardField("Forma di allevamento", gis.getFarmingFormDescription())
						))));
				if (!gisInfo.getCards().isEmpty()) {
					gisInfos.add(gisInfo);
				}
			}
		}

		return gisInfos;
	}

	@Override
	public List<CuttableLayer> getCuttableLayers(RuntimeEnvironment env, String businessId, String domainZoneId, LocalDate pointInTime,
			List<String> layerCodes, Geometry touchingGeometry) {

		List<CuttableLayerWithGeoms> cuttableLayersWithGeoms = this.getCuttableLayersInternal(env, businessId, domainZoneId, pointInTime,
				layerCodes, touchingGeometry);

		return cuttableLayersWithGeoms.stream().map(CuttableLayerWithGeoms::getCuttableLayer).toList();
	}

	@Override
	public List<Geometry> getLayerGeometries(RuntimeEnvironment env, String businessId, String domainZoneId, LocalDate pointInTime,
			String layerCode, Geometry touchingGeometry) {

		List<CuttableLayerWithGeoms> cuttableLayersWithGeoms = this.getCuttableLayersInternal(env, businessId, domainZoneId, pointInTime,
				List.of(layerCode), touchingGeometry);

		return cuttableLayersWithGeoms.stream().map(CuttableLayerWithGeoms::getGeometries).flatMap(Collection::stream).toList();

	}

	private List<CuttableLayerWithGeoms> getCuttableLayersInternal(RuntimeEnvironment env, String businessId, String domainZoneId, LocalDate pointInTime, List<String> layerCodes, Geometry touchingGeometry) {

		List<CuttableLayerWithGeoms> res = new ArrayList<>();

		if (null == layerCodes || layerCodes.isEmpty()) {
			return res;
		}

		for (String layerCode : layerCodes) {
			CuttableLayerWithGeoms cuttableLayerWithGeoms = new CuttableLayerWithGeoms(
					CuttableLayer.builder().layerCode(layerCode).build(),
					new ArrayList<>()
			);

			switch (this.buildSnapElementType(layerCode, "")) {
			case SNAP_EL_TYPE_PARCEL -> {
				GeometryWithSrs geometryWithSrs = domainCropPlanDAO.getDomainPlotsGeom(businessId, AbsoluteDate.of(pointInTime).toString(),
						domainZoneId, env.getTenantId());

				ParcelsBySectorCodeWithTouchingGeometryDto parcelsBySectorCodeWithTouchingGeometryDto = new ParcelsBySectorCodeWithTouchingGeometryDto();
				parcelsBySectorCodeWithTouchingGeometryDto.setGeom(touchingGeometry);
				parcelsBySectorCodeWithTouchingGeometryDto.setSrs(geometryWithSrs.getSrs());

				Object url = env.getProperty(URL_LPIS);
				if (url != null) {
					List<LpisParcel> parcels = LpisGisServerRepository.getListOfParcelsInSectorCodeWithTouchingGeometry(
							env, url.toString(), env.getTenantId(), domainZoneId,
							LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")), parcelsBySectorCodeWithTouchingGeometryDto);

					cuttableLayerWithGeoms.getGeometries().addAll(parcels.stream().map(LpisParcel::getGeom).toList());
				}

			}
			case SNAP_EL_TYPE_SUOLI -> new InfiniteListResultsSupport<>(nextKeySoil -> domainSchedarioCommonDAO.infinite(
					() -> domainSchedarioCommonDAO.getSoil(domainZoneId, businessId, "420", touchingGeometry),
					nextKeySoil, 666))
					.forEach(sg -> cuttableLayerWithGeoms.getGeometries().add(sg.getGeom()));
			default -> {}
			}

			if (!cuttableLayerWithGeoms.getGeometries().isEmpty()) {
				res.add(cuttableLayerWithGeoms);
			}
		}

		return res;
	}

	@Override
	public String getCropPlanType() {
		return "OLIVEALIGN";
	}
}
