package com.abacogroup.cropplan.plugins.agea.vinealign.dao;

import com.abacogroup.cropplan.plugins.agea.common.models.ntt.ExternalFormData;
import com.abacogroup.jdbi.EnhancedSqlObject;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import java.util.List;

public interface CropCodesSchedarioDAO extends EnhancedSqlObject {
	@SqlQuery("SELECT uv.PKID_UNAR as externalCode,"
			+ "       uv.foglio || ' - ' || uv.particella || decode(uv.sub,' ','','/'||uv.sub) || ' - ' || s.UNAR as externalDescription,"
			+ "       uv.foglio as foglio,"
			+ "       uv.particella || decode(uv.sub,' ','','/'||uv.sub) as particella,"
			+ "       s.unar as unar"
			+ "  FROM unita_vitate uv, sitiunar s"
			+ " WHERE uv.PKID_UNAR in (<externalCodeList>) "
			+ "   and s.PKID_UNAR = uv.PKID_UNAR")
	@RegisterBeanMapper(ExternalFormData.class)
	List<ExternalFormData> getExternalCodeDescription(@BindList("externalCodeList") List<String> externalCodeList);
}
