package com.abacogroup.cropplan.plugins.agea.vinealign.utils;

import com.abacogroup.cropplan.sdk.jackson.WKTGeometryDeserializer;
import com.abacogroup.cropplan.sdk.jackson.WKTGeometrySerializer;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.JwtAuthenticationFilter;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.auth0.jwt.JWT;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import io.dropwizard.auth.AuthDynamicFeature;
import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.client.WebTarget;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.TimeZone;
import org.glassfish.jersey.server.filter.RolesAllowedDynamicFeature;
import org.locationtech.jts.geom.Geometry;

public abstract class WebCliHelper {

	public static final String BASIC_USERNAME = "test-user@example";
	public static final String FAKE_JWT = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoidGVzdC11c2VyQGV4YW1wbGUifQ.gaT_yiyjQ3uzXWZ9Fj5zB4iSrzhHJ7PvXbx77GCFYvo";
	public static final String JWT_MOCK_CREDENTIALS = "JWT " + FAKE_JWT;
	public static final String TENANT = "master";

	public static ResourceExtension createEXT(Object resource) {

		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper
				.setTimeZone(TimeZone.getDefault())
				.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
				.findAndRegisterModules();

		SimpleModule module = new SimpleModule("custom-deserializers", Version.unknownVersion());
		module.addSerializer(Geometry.class, new WKTGeometrySerializer());
		module.addDeserializer(Geometry.class, new WKTGeometryDeserializer());
		objectMapper.registerModule(module);
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		return ResourceExtension.builder()
				.setMapper(objectMapper)
				.addProvider(new AuthDynamicFeature(new JwtAuthenticationFilter.Builder()
						.setAuthenticator(credentials -> Optional.of(new User(JWT.decode(FAKE_JWT).getClaim("name").asString(), TENANT)))
						.setAuthorizer((principal, role, ctx) -> true)
						.buildAuthFilter()))
				.addProvider(RolesAllowedDynamicFeature.class)
				.addProvider(new AuthValueFactoryProvider.Binder<>(User.class))
				.addProvider(new MultitenantFilter("tenant"))
				.addResource(resource)
				.build();
	}

	public static WebTarget addQueryParamsFromMap(Map<String, Object> params, WebTarget wt) {
		if (null == params) {
			return wt;
		}
		for (Map.Entry<String, Object> entry : params.entrySet()) {
			String key = entry.getKey();
			Object v = entry.getValue();
			if (v instanceof Collection) {
				for (Object x : (Collection) v) {
					wt = wt.queryParam(key, x);
				}
			} else {
				wt = wt.queryParam(key, entry.getValue());
			}
		}
		return wt;
	}

}
