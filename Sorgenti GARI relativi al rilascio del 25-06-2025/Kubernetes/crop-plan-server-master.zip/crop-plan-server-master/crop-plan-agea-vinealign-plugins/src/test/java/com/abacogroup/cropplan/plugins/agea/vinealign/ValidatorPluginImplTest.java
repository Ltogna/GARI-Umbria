package com.abacogroup.cropplan.plugins.agea.vinealign;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

import com.abacogroup.cropplan.plugins.agea.common.dao.ValidatorCropPlanDAO;
import com.abacogroup.cropplan.plugins.agea.common.models.ParcelEditStatusV1;
import com.abacogroup.cropplan.plugins.agea.vinealign.dao.ValidatorSchedarioDAO;
import com.abacogroup.cropplan.plugins.agea.vinealign.utils.WebCliHelper;
import com.abacogroup.cropplan.sdk.model.CropPlanConfigData;
import com.abacogroup.cropplan.sdk.model.PermanentCropForm;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormFieldValue;
import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormFieldConfig;
import com.abacogroup.cropplan.sdk.model.validation.AnomalyObjectType;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomaly;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomalyObject;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedDeclaration;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorData;
import com.abacogroup.cropplan.sdk.support.ValidatorDataSupport;
import com.abacogroup.cropplan.sdk.support.ValidatorDataSupport.VDSDeclaration;
import com.abacogroup.cropplan.sdk.support.ValidatorDataSupport.VDSPlot;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import io.dropwizard.auth.Auth;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientRequestFilter;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import javax.sql.DataSource;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;

@Slf4j
@ExtendWith({ DropwizardExtensionsSupport.class })
public class ValidatorPluginImplTest {

	private static final String BASEPATH = ValidatorPluginImplTest.class.getName().replace('.', '/') + '/';

	private static final User USER = new User(WebCliHelper.BASIC_USERNAME, WebCliHelper.FAKE_JWT, WebCliHelper.TENANT, WebCliHelper.BASIC_USERNAME);
	private static final PingResource mockResource = spy(new PingResource());
	private static final ResourceExtension EXT = WebCliHelper.createEXT(mockResource);

	private final WKTReader wktReader = new WKTReader();
	private final String polygon = "POLYGON ((2293613.54 4723417.48, 2293613.3 4723417.5, 2293613.06 4723417.57, 2293612.84 4723417.67, 2293612.74 4723417.74, 2293612.57 4723417.85, 2293613.54 4723418.89, 2293582.94 4723440.24, 2293578.36 4723443.43, 2293574.38 4723446.21, 2293547.6 4723464.88, 2293411.1 4723560.07, 2293410.83 4723560.26, 2293409.95 4723560.88, 2293410.02 4723560.98, 2293410.2 4723561.16, 2293411.24 4723562, 2293411.42 4723562.12, 2293411.64 4723562.22, 2293411.88 4723562.29, 2293412.12 4723562.31, 2293412.25 4723562.3, 2293412.36 4723562.29, 2293417.43 4723561.84, 2293423.66 4723561.28, 2293428.62 4723560.83, 2293434.4 4723560.31, 2293438.13 4723559.97, 2293439.27 4723559.9, 2293445.22 4723559.54, 2293449.95 4723559.24, 2293456.69 4723558.83, 2293461.43 4723558.54, 2293467.38 4723558.17, 2293468.79 4723558.08, 2293472.11 4723557.88, 2293477.63 4723557.54, 2293480.67 4723557.35, 2293482.37 4723557.25, 2293488.32 4723556.88, 2293493.05 4723556.59, 2293500.28 4723556.14, 2293502.5 4723556.01, 2293502.58 4723556, 2293505.33 4723555.68, 2293511.86 4723554.91, 2293517.05 4723554.31, 2293523.1 4723553.6, 2293528.29 4723552.99, 2293534.81 4723552.23, 2293540 4723551.62, 2293547.38 4723550.75, 2293552.57 4723550.15, 2293559.1 4723549.38, 2293564.29 4723548.77, 2293570.34 4723548.07, 2293575.53 4723547.46, 2293576.3 4723547.37, 2293576.35 4723547.36, 2293582.51 4723546.4, 2293588.07 4723545.54, 2293596.93 4723544.16, 2293602.48 4723543.3, 2293609.47 4723542.22, 2293615.03 4723541.35, 2293621.51 4723540.35, 2293627.07 4723539.48, 2293634.05 4723538.4, 2293639.61 4723537.53, 2293647.52 4723536.31, 2293653.08 4723535.44, 2293660.06 4723534.36, 2293665.62 4723533.49, 2293672.1 4723532.49, 2293672.49 4723532.43, 2293672.7 4723532.38, 2293680.28 4723529.91, 2293687.14 4723527.67, 2293689.88 4723525.29, 2293706.6 4723510.78, 2293706.86 4723510.56, 2293707.93 4723509.64, 2293707.83 4723509.53, 2293707.36 4723509.09, 2293705.53 4723507.37, 2293703.39 4723505.36, 2293701.56 4723503.63, 2293699.6 4723501.79, 2293699.29 4723501.48, 2293697.5 4723499.72, 2293694.97 4723497.22, 2293693.18 4723495.46, 2293690.94 4723493.25, 2293689.16 4723491.49, 2293687.08 4723489.44, 2293685.3 4723487.68, 2293683.05 4723485.47, 2293681.27 4723483.71, 2293678.43 4723480.91, 2293676.65 4723479.15, 2293674.4 4723476.94, 2293672.62 4723475.18, 2293670.54 4723473.13, 2293668.76 4723471.37, 2293666.52 4723469.16, 2293664.73 4723467.4, 2293662.2 4723464.9, 2293660.41 4723463.14, 2293658.17 4723460.93, 2293656.39 4723459.17, 2293654.31 4723457.12, 2293652.53 4723455.36, 2293650.28 4723453.15, 2293648.5 4723451.39, 2293645.78 4723448.71, 2293644 4723446.95, 2293641.76 4723444.74, 2293639.97 4723442.98, 2293637.89 4723440.93, 2293636.11 4723439.17, 2293633.87 4723436.96, 2293632.09 4723435.2, 2293629.55 4723432.7, 2293627.76 4723430.94, 2293625.52 4723428.73, 2293623.74 4723426.97, 2293621.66 4723424.92, 2293619.88 4723423.16, 2293617.64 4723420.95, 2293615.94 4723419.29, 2293615.85 4723419.19, 2293615.77 4723419.11, 2293614.53 4723417.89, 2293614.37 4723417.75, 2293614.19 4723417.64, 2293613.99 4723417.56, 2293613.79 4723417.5, 2293613.54 4723417.48))";

	private final ValidatorCropPlanDAO validatorCropPlanDAO = mock(ValidatorCropPlanDAO.class);
	private final ValidatorSchedarioDAO validatorSchedarioDAO = mock(ValidatorSchedarioDAO.class);

	private RuntimeEnvironment env;
	private ValidatorPluginImpl validatorPluginImpl;

	@BeforeEach
	public void init() throws Exception {
		env = new RuntimeEnvironment() {
			@Override
			public String getTenantId() {
				return WebCliHelper.TENANT;
			}

			@Override
			public String getUserId() {
				return WebCliHelper.BASIC_USERNAME;
			}

			@Override
			public String getUserName() {
				return WebCliHelper.BASIC_USERNAME;
			}

			@Override
			public User getUser() {
				return USER;
			}

			@Override
			public Locale getLocale() {
				return Locale.ITALIAN;
			}

			@Override
			public WebTarget getAuthenticatedWebTarget(String s) {
				return EXT.getJerseyTest().client().target(s)
						.register((ClientRequestFilter) requestContext -> {
							requestContext.getHeaders().add("Authorization", "JWT " + WebCliHelper.FAKE_JWT);
							requestContext.getHeaders().add("Accept-Language", "it");
						});
			}

			@Override
			public Jdbi getJdbi(String s) {
				return null;
			}

			@Override
			public DataSource getDatasource(String s) {
				return null;
			}

			@Override
			public Object getProperty(String s) {
				return null;
			}

			@Override
			public Client getJerseyClient() {
				return EXT.getJerseyTest().client();
			}

			@Override
			public Sso2Client getSso2Client() {
				return null;
			}
		};

		validatorPluginImpl = new ValidatorPluginImpl();

		Field lpisURLField = validatorPluginImpl.getClass().getDeclaredField("lpisURL");
		lpisURLField.setAccessible(true);
		lpisURLField.set(validatorPluginImpl, "http://localhost:0");

		Field validatorCropPlanDAOField = validatorPluginImpl.getClass().getDeclaredField("validatorCropPlanDAO");
		validatorCropPlanDAOField.setAccessible(true);
		validatorCropPlanDAOField.set(validatorPluginImpl, validatorCropPlanDAO);

		Field validatorSchedarioDAOField = validatorPluginImpl.getClass().getDeclaredField("validatorSchedarioDAO");
		validatorSchedarioDAOField.setAccessible(true);
		validatorSchedarioDAOField.set(validatorPluginImpl, validatorSchedarioDAO);
	}

	@Test
	public void whenCheckSF01With0TolleranceFoundNoAnomaly_thenReturnListValidationAnomaly() throws ParseException {
		ValidatorPluginImpl validatorPluginImpl = new ValidatorPluginImpl();
		Double tol = 0.0;
		List<VDSPlot> plots = new ArrayList<>();
		String plotCode = "1448";
		String domainZoneId = "C780";
		Integer areaSqm = 1448;
		Geometry geom = wktReader.read(polygon);
		List<String> landCoverCodes = new ArrayList<>();
		List<VDSDeclaration> decls = new ArrayList<>();
		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();

		String declCodeA = "declTest-0001";
		Double areaPercA = 10.0;
		String landUseCodeA = "060";
		VDSDeclaration declA = new VDSDeclaration(declCodeA, plotCode, areaPercA, landUseCodeA);
		decls.add(declA);
		String declCodeB = "declTest-0001";
		Double areaPercB = 50.0;
		String landUseCodeB = "146";
		VDSDeclaration declB = new VDSDeclaration(declCodeB, plotCode, areaPercB, landUseCodeB);
		decls.add(declB);
		String declCodeC = "declTest-0001";
		Double areaPercC = 40.0;
		String landUseCodeC = "218";
		VDSDeclaration declC = new VDSDeclaration(declCodeC, plotCode, areaPercC, landUseCodeC);
		decls.add(declC);
		VDSPlot plot = new VDSPlot(plotCode, domainZoneId, areaSqm, geom, landCoverCodes, decls);
		plots.add(plot);
		ValidationAnomalyObject vao = new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT);
		anomalies.put(vao, new ArrayList<>());
		validatorPluginImpl.checkSV01(anomalies, plots, tol);

		assertEquals(0, anomalies.get(vao).size());
	}

	@Test
	public void whenCheckSF01OnDeclWithPercWithNoDecimalAndOverPerAndWith0TolleranceFoundAnomaly_thenReturnListValidationAnomaly() throws ParseException {
		ValidatorPluginImpl validatorPluginImpl = new ValidatorPluginImpl();
		Double tol = 0.0;
		List<VDSPlot> plots = new ArrayList<>();
		String plotCode = "1448";
		String domainZoneId = "C780";
		Integer areaSqm = 1448;
		Geometry geom = wktReader.read(polygon);
		List<String> landCoverCodes = new ArrayList<>();
		List<VDSDeclaration> decls = new ArrayList<>();
		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();

		String declCodeA = "declTest-0001";
		Double areaPercA = 20.0;
		String landUseCodeA = "060";
		VDSDeclaration declA = new VDSDeclaration(declCodeA, plotCode, areaPercA, landUseCodeA);
		decls.add(declA);
		String declCodeB = "declTest-0001";
		Double areaPercB = 50.0;
		String landUseCodeB = "146";
		VDSDeclaration declB = new VDSDeclaration(declCodeB, plotCode, areaPercB, landUseCodeB);
		decls.add(declB);
		String declCodeC = "declTest-0001";
		Double areaPercC = 40.0;
		String landUseCodeC = "218";
		VDSDeclaration declC = new VDSDeclaration(declCodeC, plotCode, areaPercC, landUseCodeC);
		decls.add(declC);
		VDSPlot plot = new VDSPlot(plotCode, domainZoneId, areaSqm, geom, landCoverCodes, decls);
		plots.add(plot);
		ValidationAnomalyObject vao = new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT);
		anomalies.put(vao, new ArrayList<>());
		validatorPluginImpl.checkSV01(anomalies, plots, tol);

		assertNotEquals(0, anomalies.get(vao).size());
	}

	@Test
	public void whenCheckSF01OnDeclWithPercWithNoDecimalAndUnderPerAndWith0TolleranceFoundAnomaly_thenReturnListValidationAnomaly() throws ParseException {
		ValidatorPluginImpl validatorPluginImpl = new ValidatorPluginImpl();
		Double tol = 0.0;
		List<VDSPlot> plots = new ArrayList<>();
		String plotCode = "1448";
		String domainZoneId = "C780";
		Integer areaSqm = 1448;
		Geometry geom = wktReader.read(polygon);
		List<String> landCoverCodes = new ArrayList<>();
		List<VDSDeclaration> decls = new ArrayList<>();
		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();

		String declCodeA = "declTest-0001";
		Double areaPercA = 20.0;
		String landUseCodeA = "060";
		VDSDeclaration declA = new VDSDeclaration(declCodeA, plotCode, areaPercA, landUseCodeA);
		decls.add(declA);
		String declCodeB = "declTest-0001";
		Double areaPercB = 20.0;
		String landUseCodeB = "146";
		VDSDeclaration declB = new VDSDeclaration(declCodeB, plotCode, areaPercB, landUseCodeB);
		decls.add(declB);
		String declCodeC = "declTest-0001";
		Double areaPercC = 40.0;
		String landUseCodeC = "218";
		VDSDeclaration declC = new VDSDeclaration(declCodeC, plotCode, areaPercC, landUseCodeC);
		decls.add(declC);
		VDSPlot plot = new VDSPlot(plotCode, domainZoneId, areaSqm, geom, landCoverCodes, decls);
		plots.add(plot);
		ValidationAnomalyObject vao = new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT);
		anomalies.put(vao, new ArrayList<>());
		validatorPluginImpl.checkSV01(anomalies, plots, tol);

		assertEquals(0, anomalies.get(vao).size());
	}

	@Test
	public void whenCheckSF01OnDeclWithPercWithDecimalAndWith0TolleranceFoundAnomaly_thenReturnListValidationAnomaly() throws ParseException {
		ValidatorPluginImpl validatorPluginImpl = new ValidatorPluginImpl();
		Double tol = 0.0;
		List<VDSPlot> plots = new ArrayList<>();
		String plotCode = "1448";
		String domainZoneId = "C780";
		Integer areaSqm = 1448;
		Geometry geom = wktReader.read(polygon);
		List<String> landCoverCodes = new ArrayList<>();
		List<VDSDeclaration> decls = new ArrayList<>();
		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();

		String declCodeA = "declTest-0001";
		Double areaPercA = 20.3;
		String landUseCodeA = "060";
		VDSDeclaration declA = new VDSDeclaration(declCodeA, plotCode, areaPercA, landUseCodeA);
		decls.add(declA);
		String declCodeB = "declTest-0001";
		Double areaPercB = 40.9;
		String landUseCodeB = "146";
		VDSDeclaration declB = new VDSDeclaration(declCodeB, plotCode, areaPercB, landUseCodeB);
		decls.add(declB);
		String declCodeC = "declTest-0001";
		Double areaPercC = 40.2;
		String landUseCodeC = "218";
		VDSDeclaration declC = new VDSDeclaration(declCodeC, plotCode, areaPercC, landUseCodeC);
		decls.add(declC);
		VDSPlot plot = new VDSPlot(plotCode, domainZoneId, areaSqm, geom, landCoverCodes, decls);
		plots.add(plot);
		ValidationAnomalyObject vao = new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT);
		anomalies.put(vao, new ArrayList<>());
		validatorPluginImpl.checkSV01(anomalies, plots, tol);

		assertNotEquals(0, anomalies.get(vao).size());
	}

	@Test
	public void whenCheckSF01WithTolleranceFoundNoAnomaly_thenReturnListValidationAnomaly() throws ParseException {
		ValidatorPluginImpl validatorPluginImpl = new ValidatorPluginImpl();
		Double tol = 0.01;
		List<VDSPlot> plots = new ArrayList<>();
		String plotCode = "1448";
		String domainZoneId = "C780";
		Integer areaSqm = 1448;
		Geometry geom = wktReader.read(polygon);
		List<String> landCoverCodes = new ArrayList<>();
		List<VDSDeclaration> decls = new ArrayList<>();
		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();

		String declCodeA = "declTest-0001";
		Double areaPercA = 10.0;
		String landUseCodeA = "060";
		VDSDeclaration declA = new VDSDeclaration(declCodeA, plotCode, areaPercA, landUseCodeA);
		decls.add(declA);
		String declCodeB = "declTest-0001";
		Double areaPercB = 50.0;
		String landUseCodeB = "146";
		VDSDeclaration declB = new VDSDeclaration(declCodeB, plotCode, areaPercB, landUseCodeB);
		decls.add(declB);
		String declCodeC = "declTest-0001";
		Double areaPercC = 40.0;
		String landUseCodeC = "218";
		VDSDeclaration declC = new VDSDeclaration(declCodeC, plotCode, areaPercC, landUseCodeC);
		decls.add(declC);
		VDSPlot plot = new VDSPlot(plotCode, domainZoneId, areaSqm, geom, landCoverCodes, decls);
		plots.add(plot);
		ValidationAnomalyObject vao = new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT);
		anomalies.put(vao, new ArrayList<>());
		validatorPluginImpl.checkSV01(anomalies, plots, tol);

		assertEquals(0, anomalies.get(vao).size());
	}

	@Test
	public void whenCheckSF01OnDeclWithPercWithNoDecimalAndOverPerAndWithTolleranceFoundAnomaly_thenReturnListValidationAnomaly() throws ParseException {
		ValidatorPluginImpl validatorPluginImpl = new ValidatorPluginImpl();
		Double tol = 0.01;
		List<VDSPlot> plots = new ArrayList<>();
		String plotCode = "1448";
		String domainZoneId = "C780";
		Integer areaSqm = 1448;
		Geometry geom = wktReader.read(polygon);
		List<String> landCoverCodes = new ArrayList<>();
		List<VDSDeclaration> decls = new ArrayList<>();
		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();

		String declCodeA = "declTest-0001";
		Double areaPercA = 20.0;
		String landUseCodeA = "060";
		VDSDeclaration declA = new VDSDeclaration(declCodeA, plotCode, areaPercA, landUseCodeA);
		decls.add(declA);
		String declCodeB = "declTest-0001";
		Double areaPercB = 50.0;
		String landUseCodeB = "146";
		VDSDeclaration declB = new VDSDeclaration(declCodeB, plotCode, areaPercB, landUseCodeB);
		decls.add(declB);
		String declCodeC = "declTest-0001";
		Double areaPercC = 40.0;
		String landUseCodeC = "218";
		VDSDeclaration declC = new VDSDeclaration(declCodeC, plotCode, areaPercC, landUseCodeC);
		decls.add(declC);
		VDSPlot plot = new VDSPlot(plotCode, domainZoneId, areaSqm, geom, landCoverCodes, decls);
		plots.add(plot);
		ValidationAnomalyObject vao = new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT);
		anomalies.put(vao, new ArrayList<>());
		validatorPluginImpl.checkSV01(anomalies, plots, tol);

		assertNotEquals(0, anomalies.get(vao).size());
	}

	@Test
	public void whenCheckSF01OnDeclWithPercWithNoDecimalAndUnderPerAndWithTolleranceFoundNoAnomaly_thenReturnListValidationAnomaly() throws ParseException {
		ValidatorPluginImpl validatorPluginImpl = new ValidatorPluginImpl();
		Double tol = 0.01;
		List<VDSPlot> plots = new ArrayList<>();
		String plotCode = "1448";
		String domainZoneId = "C780";
		Integer areaSqm = 1448;
		Geometry geom = wktReader.read(polygon);
		List<String> landCoverCodes = new ArrayList<>();
		List<VDSDeclaration> decls = new ArrayList<>();
		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();

		String declCodeA = "declTest-0001";
		Double areaPercA = 20.0;
		String landUseCodeA = "060";
		VDSDeclaration declA = new VDSDeclaration(declCodeA, plotCode, areaPercA, landUseCodeA);
		decls.add(declA);
		String declCodeB = "declTest-0001";
		Double areaPercB = 30.0;
		String landUseCodeB = "146";
		VDSDeclaration declB = new VDSDeclaration(declCodeB, plotCode, areaPercB, landUseCodeB);
		decls.add(declB);
		String declCodeC = "declTest-0001";
		Double areaPercC = 40.0;
		String landUseCodeC = "218";
		VDSDeclaration declC = new VDSDeclaration(declCodeC, plotCode, areaPercC, landUseCodeC);
		decls.add(declC);
		VDSPlot plot = new VDSPlot(plotCode, domainZoneId, areaSqm, geom, landCoverCodes, decls);
		plots.add(plot);
		ValidationAnomalyObject vao = new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT);
		anomalies.put(vao, new ArrayList<>());
		validatorPluginImpl.checkSV01(anomalies, plots, tol);

		assertEquals(0, anomalies.get(vao).size());
	}

	@Test
	public void whenCheckSF01OnDeclWithPercWithDecimalAndWithTolleranceFoundAnomaly_thenReturnListValidationAnomaly() throws ParseException {
		ValidatorPluginImpl validatorPluginImpl = new ValidatorPluginImpl();
		Double tol = 0.01;
		List<VDSPlot> plots = new ArrayList<>();
		String plotCode = "1448";
		String domainZoneId = "C780";
		Integer areaSqm = 1448;
		Geometry geom = wktReader.read(polygon);
		List<String> landCoverCodes = new ArrayList<>();
		List<VDSDeclaration> decls = new ArrayList<>();
		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();

		String declCodeA = "declTest-0001";
		Double areaPercA = 20.3;
		String landUseCodeA = "060";
		VDSDeclaration declA = new VDSDeclaration(declCodeA, plotCode, areaPercA, landUseCodeA);
		decls.add(declA);
		String declCodeB = "declTest-0001";
		Double areaPercB = 40.9;
		String landUseCodeB = "146";
		VDSDeclaration declB = new VDSDeclaration(declCodeB, plotCode, areaPercB, landUseCodeB);
		decls.add(declB);
		String declCodeC = "declTest-0001";
		Double areaPercC = 40.2;
		String landUseCodeC = "218";
		VDSDeclaration declC = new VDSDeclaration(declCodeC, plotCode, areaPercC, landUseCodeC);
		decls.add(declC);
		VDSPlot plot = new VDSPlot(plotCode, domainZoneId, areaSqm, geom, landCoverCodes, decls);
		plots.add(plot);
		ValidationAnomalyObject vao = new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT);
		anomalies.put(vao, new ArrayList<>());
		validatorPluginImpl.checkSV01(anomalies, plots, tol);

		assertNotEquals(0, anomalies.get(vao).size());
	}

	//------------------------------------------------------------------------------------------------------------------------------------

	@Test
	public void whenCheckSF02With0TolleranceFoundNoAnomaly_thenReturnListValidationAnomaly() throws ParseException {
		ValidatorPluginImpl validatorPluginImpl = new ValidatorPluginImpl();
		Double tol = 0.0;
		List<VDSPlot> plots = new ArrayList<>();
		String plotCode = "1448";
		String domainZoneId = "C780";
		Integer areaSqm = 1448;
		Geometry geom = wktReader.read(polygon);
		List<String> landCoverCodes = new ArrayList<>();
		List<VDSDeclaration> decls = new ArrayList<>();
		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();

		String declCodeA = "declTest-0001";
		Double areaPercA = 10.0;
		String landUseCodeA = "060";
		VDSDeclaration declA = new VDSDeclaration(declCodeA, plotCode, areaPercA, landUseCodeA);
		decls.add(declA);
		String declCodeB = "declTest-0001";
		Double areaPercB = 50.0;
		String landUseCodeB = "146";
		VDSDeclaration declB = new VDSDeclaration(declCodeB, plotCode, areaPercB, landUseCodeB);
		decls.add(declB);
		String declCodeC = "declTest-0001";
		Double areaPercC = 40.0;
		String landUseCodeC = "218";
		VDSDeclaration declC = new VDSDeclaration(declCodeC, plotCode, areaPercC, landUseCodeC);
		decls.add(declC);
		VDSPlot plot = new VDSPlot(plotCode, domainZoneId, areaSqm, geom, landCoverCodes, decls);
		plots.add(plot);
		ValidationAnomalyObject vao = new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT);
		anomalies.put(vao, new ArrayList<>());
		validatorPluginImpl.checkSV02(anomalies, plots, tol);

		assertEquals(0, anomalies.get(vao).size());
	}

	@Test
	public void whenCheckSF02OnDeclWithPercWithNoDecimalAndOverPerAndWith0TolleranceNotFoundAnomaly_thenReturnListValidationAnomaly() throws ParseException {
		ValidatorPluginImpl validatorPluginImpl = new ValidatorPluginImpl();
		Double tol = 0.0;
		List<VDSPlot> plots = new ArrayList<>();
		String plotCode = "1448";
		String domainZoneId = "C780";
		Integer areaSqm = 1448;
		Geometry geom = wktReader.read(polygon);
		List<String> landCoverCodes = new ArrayList<>();
		List<VDSDeclaration> decls = new ArrayList<>();
		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();

		String declCodeA = "declTest-0001";
		Double areaPercA = 20.0;
		String landUseCodeA = "060";
		VDSDeclaration declA = new VDSDeclaration(declCodeA, plotCode, areaPercA, landUseCodeA);
		decls.add(declA);
		String declCodeB = "declTest-0001";
		Double areaPercB = 50.0;
		String landUseCodeB = "146";
		VDSDeclaration declB = new VDSDeclaration(declCodeB, plotCode, areaPercB, landUseCodeB);
		decls.add(declB);
		String declCodeC = "declTest-0001";
		Double areaPercC = 40.0;
		String landUseCodeC = "218";
		VDSDeclaration declC = new VDSDeclaration(declCodeC, plotCode, areaPercC, landUseCodeC);
		decls.add(declC);
		VDSPlot plot = new VDSPlot(plotCode, domainZoneId, areaSqm, geom, landCoverCodes, decls);
		plots.add(plot);
		ValidationAnomalyObject vao = new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT);
		anomalies.put(vao, new ArrayList<>());
		validatorPluginImpl.checkSV02(anomalies, plots, tol);

		assertEquals(0, anomalies.get(vao).size());
	}

	@Test
	public void whenCheckSF02OnDeclWithPercWithNoDecimalAndUnderPerAndWith0TolleranceFoundAnomaly_thenReturnListValidationAnomaly() throws ParseException {
		ValidatorPluginImpl validatorPluginImpl = new ValidatorPluginImpl();
		Double tol = 0.0;
		List<VDSPlot> plots = new ArrayList<>();
		String plotCode = "1448";
		String domainZoneId = "C780";
		Integer areaSqm = 1448;
		Geometry geom = wktReader.read(polygon);
		List<String> landCoverCodes = new ArrayList<>();
		List<VDSDeclaration> decls = new ArrayList<>();
		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();

		String declCodeA = "declTest-0001";
		Double areaPercA = 20.0;
		String landUseCodeA = "060";
		VDSDeclaration declA = new VDSDeclaration(declCodeA, plotCode, areaPercA, landUseCodeA);
		decls.add(declA);
		String declCodeB = "declTest-0001";
		Double areaPercB = 20.0;
		String landUseCodeB = "146";
		VDSDeclaration declB = new VDSDeclaration(declCodeB, plotCode, areaPercB, landUseCodeB);
		decls.add(declB);
		String declCodeC = "declTest-0001";
		Double areaPercC = 40.0;
		String landUseCodeC = "218";
		VDSDeclaration declC = new VDSDeclaration(declCodeC, plotCode, areaPercC, landUseCodeC);
		decls.add(declC);
		VDSPlot plot = new VDSPlot(plotCode, domainZoneId, areaSqm, geom, landCoverCodes, decls);
		plots.add(plot);
		ValidationAnomalyObject vao = new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT);
		anomalies.put(vao, new ArrayList<>());
		validatorPluginImpl.checkSV02(anomalies, plots, tol);

		assertNotEquals(0, anomalies.get(vao).size());
	}

	@Test
	public void whenCheckSF02OnDeclWithPercWithDecimalAndWith0TolleranceFoundAnomaly_thenReturnListValidationAnomaly() throws ParseException {
		ValidatorPluginImpl validatorPluginImpl = new ValidatorPluginImpl();
		Double tol = 0.0;
		List<VDSPlot> plots = new ArrayList<>();
		String plotCode = "1448";
		String domainZoneId = "C780";
		Integer areaSqm = 1448;
		Geometry geom = wktReader.read(polygon);
		List<String> landCoverCodes = new ArrayList<>();
		List<VDSDeclaration> decls = new ArrayList<>();
		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();

		String declCodeA = "declTest-0001";
		Double areaPercA = 20.3;
		String landUseCodeA = "060";
		VDSDeclaration declA = new VDSDeclaration(declCodeA, plotCode, areaPercA, landUseCodeA);
		decls.add(declA);
		String declCodeB = "declTest-0001";
		Double areaPercB = 30.9;
		String landUseCodeB = "146";
		VDSDeclaration declB = new VDSDeclaration(declCodeB, plotCode, areaPercB, landUseCodeB);
		decls.add(declB);
		String declCodeC = "declTest-0001";
		Double areaPercC = 40.2;
		String landUseCodeC = "218";
		VDSDeclaration declC = new VDSDeclaration(declCodeC, plotCode, areaPercC, landUseCodeC);
		decls.add(declC);
		VDSPlot plot = new VDSPlot(plotCode, domainZoneId, areaSqm, geom, landCoverCodes, decls);
		plots.add(plot);
		ValidationAnomalyObject vao = new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT);
		anomalies.put(vao, new ArrayList<>());
		validatorPluginImpl.checkSV02(anomalies, plots, tol);

		assertNotEquals(0, anomalies.get(vao).size());
	}

	@Test
	public void whenCheckSF02WithTolleranceFoundNoAnomaly_thenReturnListValidationAnomaly() throws ParseException {
		ValidatorPluginImpl validatorPluginImpl = new ValidatorPluginImpl();
		Double tol = 0.01;
		List<VDSPlot> plots = new ArrayList<>();
		String plotCode = "1448";
		String domainZoneId = "C780";
		Integer areaSqm = 1448;
		Geometry geom = wktReader.read(polygon);
		List<String> landCoverCodes = new ArrayList<>();
		List<VDSDeclaration> decls = new ArrayList<>();
		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();

		String declCodeA = "declTest-0001";
		Double areaPercA = 10.0;
		String landUseCodeA = "060";
		VDSDeclaration declA = new VDSDeclaration(declCodeA, plotCode, areaPercA, landUseCodeA);
		decls.add(declA);
		String declCodeB = "declTest-0001";
		Double areaPercB = 50.0;
		String landUseCodeB = "146";
		VDSDeclaration declB = new VDSDeclaration(declCodeB, plotCode, areaPercB, landUseCodeB);
		decls.add(declB);
		String declCodeC = "declTest-0001";
		Double areaPercC = 40.0;
		String landUseCodeC = "218";
		VDSDeclaration declC = new VDSDeclaration(declCodeC, plotCode, areaPercC, landUseCodeC);
		decls.add(declC);
		VDSPlot plot = new VDSPlot(plotCode, domainZoneId, areaSqm, geom, landCoverCodes, decls);
		plots.add(plot);
		ValidationAnomalyObject vao = new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT);
		anomalies.put(vao, new ArrayList<>());
		validatorPluginImpl.checkSV02(anomalies, plots, tol);

		assertEquals(0, anomalies.get(vao).size());
	}

	@Test
	public void whenCheckSF02OnDeclWithPercWithNoDecimalAndOverPerAndWithTolleranceFoundAnomaly_thenReturnListValidationAnomaly() throws ParseException {
		ValidatorPluginImpl validatorPluginImpl = new ValidatorPluginImpl();
		Double tol = 0.01;
		List<VDSPlot> plots = new ArrayList<>();
		String plotCode = "1448";
		String domainZoneId = "C780";
		Integer areaSqm = 1448;
		Geometry geom = wktReader.read(polygon);
		List<String> landCoverCodes = new ArrayList<>();
		List<VDSDeclaration> decls = new ArrayList<>();
		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();

		String declCodeA = "declTest-0001";
		Double areaPercA = 20.0;
		String landUseCodeA = "060";
		VDSDeclaration declA = new VDSDeclaration(declCodeA, plotCode, areaPercA, landUseCodeA);
		decls.add(declA);
		String declCodeB = "declTest-0001";
		Double areaPercB = 20.0;
		String landUseCodeB = "146";
		VDSDeclaration declB = new VDSDeclaration(declCodeB, plotCode, areaPercB, landUseCodeB);
		decls.add(declB);
		String declCodeC = "declTest-0001";
		Double areaPercC = 40.0;
		String landUseCodeC = "218";
		VDSDeclaration declC = new VDSDeclaration(declCodeC, plotCode, areaPercC, landUseCodeC);
		decls.add(declC);
		VDSPlot plot = new VDSPlot(plotCode, domainZoneId, areaSqm, geom, landCoverCodes, decls);
		plots.add(plot);
		ValidationAnomalyObject vao = new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT);
		anomalies.put(vao, new ArrayList<>());
		validatorPluginImpl.checkSV02(anomalies, plots, tol);

		assertNotEquals(0, anomalies.get(vao).size());
	}

	@Test
	public void whenCheckSF02OnDeclWithPercWithNoDecimalAndUnderPerAndWithTolleranceFoundAnomaly_thenReturnListValidationAnomaly() throws ParseException {
		ValidatorPluginImpl validatorPluginImpl = new ValidatorPluginImpl();
		Double tol = 0.01;
		List<VDSPlot> plots = new ArrayList<>();
		String plotCode = "1448";
		String domainZoneId = "C780";
		Integer areaSqm = 1448;
		Geometry geom = wktReader.read(polygon);
		List<String> landCoverCodes = new ArrayList<>();
		List<VDSDeclaration> decls = new ArrayList<>();
		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();

		String declCodeA = "declTest-0001";
		Double areaPercA = 19.00;
		String landUseCodeA = "060";
		VDSDeclaration declA = new VDSDeclaration(declCodeA, plotCode, areaPercA, landUseCodeA);
		decls.add(declA);
		String declCodeB = "declTest-0001";
		Double areaPercB = 40.0;
		String landUseCodeB = "146";
		VDSDeclaration declB = new VDSDeclaration(declCodeB, plotCode, areaPercB, landUseCodeB);
		decls.add(declB);
		String declCodeC = "declTest-0001";
		Double areaPercC = 40.0;
		String landUseCodeC = "218";
		VDSDeclaration declC = new VDSDeclaration(declCodeC, plotCode, areaPercC, landUseCodeC);
		decls.add(declC);
		VDSPlot plot = new VDSPlot(plotCode, domainZoneId, areaSqm, geom, landCoverCodes, decls);
		plots.add(plot);
		ValidationAnomalyObject vao = new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT);
		anomalies.put(vao, new ArrayList<>());
		validatorPluginImpl.checkSV02(anomalies, plots, tol);

		assertNotEquals(0, anomalies.get(vao).size());
	}

	@Test
	public void whenCheckSF02OnDeclWithPercWithDecimalAndWithTolleranceFoundAnomaly_thenReturnListValidationAnomaly() throws ParseException {
		ValidatorPluginImpl validatorPluginImpl = new ValidatorPluginImpl();
		Double tol = 0.01;
		List<VDSPlot> plots = new ArrayList<>();
		String plotCode = "1448";
		String domainZoneId = "C780";
		Integer areaSqm = 1448;
		Geometry geom = wktReader.read(polygon);
		List<String> landCoverCodes = new ArrayList<>();
		List<VDSDeclaration> decls = new ArrayList<>();
		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();

		String declCodeA = "declTest-0001";
		Double areaPercA = 19.03;
		String landUseCodeA = "060";
		VDSDeclaration declA = new VDSDeclaration(declCodeA, plotCode, areaPercA, landUseCodeA);
		decls.add(declA);
		String declCodeB = "declTest-0001";
		Double areaPercB = 40.1;
		String landUseCodeB = "146";
		VDSDeclaration declB = new VDSDeclaration(declCodeB, plotCode, areaPercB, landUseCodeB);
		decls.add(declB);
		String declCodeC = "declTest-0001";
		Double areaPercC = 40.02;
		String landUseCodeC = "218";
		VDSDeclaration declC = new VDSDeclaration(declCodeC, plotCode, areaPercC, landUseCodeC);
		decls.add(declC);
		VDSPlot plot = new VDSPlot(plotCode, domainZoneId, areaSqm, geom, landCoverCodes, decls);
		plots.add(plot);
		ValidationAnomalyObject vao = new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT);
		anomalies.put(vao, new ArrayList<>());
		validatorPluginImpl.checkSV02(anomalies, plots, tol);

		assertNotEquals(0, anomalies.get(vao).size());
	}

	// ----- checkSV07 -----
	@Test
	void test_checkSV07_ko() throws Exception {

		String errorCode = "SV07";
		Long planId = 123L;

		List<VDSPlot> plots = new ArrayList<>();

		String plotCode01 = "12301"; // ok
		plots.add(new VDSPlot(plotCode01, null, null, null, null, null));
		String plotCode02 = "12302"; // anomaly
		plots.add(new VDSPlot(plotCode02, null, null, null, null, null));
		String plotCode03 = "12303"; // ok
		plots.add(new VDSPlot(plotCode03, null, null, null, null, null));
		String plotCode04 = "12304"; // ok
		plots.add(new VDSPlot(plotCode04, null, null, null, null, null));
		String plotCode05 = "12305"; // anomaly
		plots.add(new VDSPlot(plotCode05, null, null, null, null, null));

		given(validatorCropPlanDAO.getPlotDescription(eq(plotCode01), any())).willReturn("SV-AA01-1-999901");
		given(validatorCropPlanDAO.getPlotDescription(eq(plotCode02), any())).willReturn("SV-AA01-1-999902");
		given(validatorCropPlanDAO.getPlotDescription(eq(plotCode03), any())).willReturn("SV-AA01-1-999903");
		given(validatorCropPlanDAO.getPlotDescription(eq(plotCode04), any())).willReturn("XX-AA01-1-999904");
		given(validatorCropPlanDAO.getPlotDescription(eq(plotCode05), any())).willReturn("SV-AA01-1-999905");

		given(validatorSchedarioDAO.getFonte(any(), any(), eq("999901"))).willReturn("OTHER");
		given(validatorSchedarioDAO.getFonte(any(), any(), eq("999902"))).willReturn("2");
		given(validatorSchedarioDAO.getFonte(any(), any(), eq("999903"))).willReturn("2");
		given(validatorSchedarioDAO.getFonte(any(), any(), eq("999905"))).willReturn("2");

		given(mockResource.getParcelsEditStatus(any(), any(), any(), any(), any(), eq("999902"), any()))
				.willReturn(Response.ok(
						ParcelEditStatusV1.builder().creationDate(LocalDateTime.MIN).lastUpdate(LocalDateTime.MIN).build()
				).build());
		given(mockResource.getParcelsEditStatus(any(), any(), any(), any(), any(), eq("999903"), any()))
				.willReturn(Response.ok(
						ParcelEditStatusV1.builder().creationDate(LocalDateTime.MIN).lastUpdate(LocalDateTime.MIN.plusDays(5)).build()
				).build());
		given(mockResource.getParcelsEditStatus(any(), any(), any(), any(), any(), eq("999905"), any()))
				.willReturn(Response.status(Status.NOT_FOUND).build());

		// tested
		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();

		ValidationAnomalyObject vao1 = new ValidationAnomalyObject(plotCode01, AnomalyObjectType.PLOT);
		ValidationAnomalyObject vao2 = new ValidationAnomalyObject(plotCode02, AnomalyObjectType.PLOT);
		ValidationAnomalyObject vao3 = new ValidationAnomalyObject(plotCode03, AnomalyObjectType.PLOT);
		ValidationAnomalyObject vao4 = new ValidationAnomalyObject(plotCode04, AnomalyObjectType.PLOT);
		ValidationAnomalyObject vao5 = new ValidationAnomalyObject(plotCode05, AnomalyObjectType.PLOT);

		anomalies.put(vao1, new ArrayList<>());
		anomalies.put(vao2, new ArrayList<>());
		anomalies.put(vao3, new ArrayList<>());
		anomalies.put(vao4, new ArrayList<>());
		anomalies.put(vao5, new ArrayList<>());

		validatorPluginImpl.checkSV07(anomalies, env, plots, planId);

		List<ValidationAnomaly> anomalyList = new ArrayList<>();

		anomalies.forEach((key, value) -> {
			anomalyList.addAll(value);
		});

		Assertions.assertThat(anomalyList).hasSize(2);

		Assertions.assertThat(anomalies.get(vao1)).isEmpty();
		Assertions.assertThat(anomalies.get(vao2)).extracting(ValidationAnomaly::getErrorCode).contains(errorCode);
		Assertions.assertThat(anomalies.get(vao3)).isEmpty();
		Assertions.assertThat(anomalies.get(vao4)).isEmpty();
		Assertions.assertThat(anomalies.get(vao5)).extracting(ValidationAnomaly::getErrorCode).contains(errorCode);

		verify(validatorCropPlanDAO).getPlotDescription(plotCode01, planId);
		verify(validatorSchedarioDAO).getFonte("AA01", "1", "999901");
		verify(mockResource, never()).getParcelsEditStatus(any(), any(), any(), eq("AA01"), eq("1"), eq("999901"), any());

		verify(validatorCropPlanDAO).getPlotDescription(plotCode02, planId);
		verify(validatorSchedarioDAO).getFonte("AA01", "1", "999902");
		verify(mockResource).getParcelsEditStatus(eq("it"), eq(USER), eq(WebCliHelper.TENANT), eq("AA01"), eq("1"), eq("999902"), isNull());

		verify(validatorCropPlanDAO).getPlotDescription(plotCode03, planId);
		verify(validatorSchedarioDAO).getFonte("AA01", "1", "999903");
		verify(mockResource).getParcelsEditStatus(eq("it"), eq(USER), eq(WebCliHelper.TENANT), eq("AA01"), eq("1"), eq("999903"), isNull());

		verify(validatorCropPlanDAO).getPlotDescription(plotCode04, planId);
		verify(validatorSchedarioDAO, never()).getFonte("AA01", "1", "999904");
		verify(mockResource, never()).getParcelsEditStatus(any(), any(), any(), eq("AA01"), eq("1"), eq("999904"), any());

		verify(validatorCropPlanDAO).getPlotDescription(plotCode05, planId);
		verify(validatorSchedarioDAO).getFonte("AA01", "1", "999905");
		verify(mockResource, atLeastOnce()).getParcelsEditStatus(eq("it"), eq(USER), eq(WebCliHelper.TENANT), eq("AA01"), eq("1"), eq("999905"), isNull());

	}

	// ----- checkSV04 -----
	@Test
	void test_checkSO04_ko() {
		String errorCode = "SV04";
		LocalDate referenceDt = LocalDate.of(2023, Month.DECEMBER, 7);

		ValidatorDataSupport support = mock(ValidatorDataSupport.class);

		ValidatorData data = new ValidatorData();
		data.setCropPlanId(1L);
		data.setReferenceDt(referenceDt);

		List<ValidatorBoundedDeclaration> declarations = List.of(
				givenDecl("12300", "d00001", "VARIETY_CODE_1", 050., referenceDt.plusYears(-3), "YMD"), // ok
				givenDecl("12300", "d00002", "VARIETY_CODE_1", 050., referenceDt.plusYears(-3), "YM"), // ok
				//givenDecl("12301", "d01002", "VARIETY_CODE_1", 080., referenceDt.plusYears(-3)), // anomaly STUMPS_DENSITY_100 value
				givenDecl("12301", "d01003", "VARIETY_CODE_1", 050., referenceDt.plusYears(-3), "YMD"), // anomaly mandatory field distanceBetweenRowsCm
				givenDecl("12301", "d01004", "VARIETY_CODE_1", 050., referenceDt.plusYears(-3), "YMD"), // anomaly mandatory field blank farmingForm
				givenDecl("12301", "d01005", "VARIETY_CODE_1", 050., referenceDt.plusYears(-3), "YMD"), // anomaly lookup irrigation
				givenDecl("12301", "d01006", "VARIETY_CODE_1", 050., referenceDt.plusYears(-3), "YMD"), // anomaly lookup not mandatory cultivationTypeCode
				givenDecl("12301", "d01007", "VARIETY_CODE_1", 050., referenceDt.plusYears(-3), "YMD"), // anomaly DistanceBetweenRowsCm range
				givenDecl("12301", "d01008", "VARIETY_CODE_1", 050., referenceDt.plusYears(-3), "YMD"), // anomaly DistanceOnTheRowCm decimal
				givenDecl("12301", "d01009", "VARIETY_CODE_1", 050., referenceDt.plusYears(-3), "YMD"), // anomaly StumpsNumber lte 0
				givenDecl("12302", "d02001", "VARIETY_CODE_1", 100., referenceDt.plusYears(+1), "YMD"), // anomaly decl year future
				givenDecl("12302", "d02002", "VARIETY_CODE_1", 100., referenceDt.withYear(1899), "YMD"), // anomaly decl year
				givenDecl("12302", "d02003", "              ", 100., referenceDt.plusYears(-3), "YMD"), // anomaly variety null
				givenDecl("12302", "d02004", "VARIETY_CODE_X", 100., referenceDt.plusYears(-3), "YMD"), // anomaly variety
				givenDecl("12302", "d02005", "VARIETY_CODE_1", 000., referenceDt.plusYears(-3), "YMD"), // anomaly perc
				givenDecl("12302", "d02006", "VARIETY_CODE_1", 050., referenceDt.plusYears(-3), "Y") // anomaly from date precision
		);

		List<ValidationAnomalyObject> vaoList = new ArrayList<>();
		for (ValidatorBoundedDeclaration declaration : declarations)
			vaoList.add(new ValidationAnomalyObject(declaration.getDeclCode(), AnomalyObjectType.DECLARATION));

		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();
		for (ValidationAnomalyObject validationAnomalyObject : vaoList)
			anomalies.put(validationAnomalyObject, new ArrayList<>());

		given(validatorSchedarioDAO.getCurrentTimestamp()).willReturn(LocalDateTime.of(referenceDt, LocalTime.of(16, 49, 0)));

		given(support.getPlot(any(), any(), any()))
				.willReturn(new VDSPlot(null, null, 10_000, null, null, null));

		given(support.getPermanentCropForms(anyString(), anyString()))
				.willAnswer(i -> {
					String declCode = i.getArgument(0);
					try (InputStream is = this.getClass().getClassLoader()
							.getResourceAsStream(BASEPATH + "permanentCropForms/" + "pcf." + declCode + ".json")) {
						return List.of(EXT.getObjectMapper().readValue(is, PermanentCropForm.class));
					} catch (IOException e) {
						throw new RuntimeException(e);
					}
				});

		given(support.getPermanentCropFormFieldsValues(anyString())).willReturn(
				Stream.of("FARMING_FORM", "IRRIGATION", "PRODUCT_DESTINATION_CODE", "VARIATION_TYPE_CODE",
								"CULTIVATION_TYPE_CODE", "TERRACING", "POLES_WEAVING", "SUPPORT_WIRES", "HEADER_ANCHORING", "POLES_HEADER",
								"VARIETY_CODE")
						.flatMap(c -> IntStream.range(1, 4)
								.mapToObj(i -> new PermanentCropFormFieldValue(c, c + "_" + i, c + i)))
						.collect(Collectors.toList()));

		given(validatorCropPlanDAO.getPermanentCropFormsFieldsConfig(anyString(), anyString(), anyString(), any())).willReturn(
				Stream.concat(
						Stream.of("DISTANCE_BETWEEN_ROWS_CM", "DISTANCE_ON_THE_ROW_CM", "STUMPS_NUMBER", "STUMPS_DENSITY_100",
										"FARMING_FORM", "IRRIGATION", "PRODUCT_DESTINATION_CODE", "VARIATION_TYPE_CODE")
								.map(c -> new PermanentCropFormFieldConfig(c, true, true)),
						Stream.of("CULTIVATION_TYPE_CODE", "TERRACING", "FAILURES_PERC", "SOIL_LAYERING_PERC",
										"ALTITUDE_ABOVE_SEA_LEVEL", "POLES_WEAVING", "POLES_DISTANCE_CM",
										"SUPPORT_WIRES", "HEADER_ANCHORING", "POLES_HEADER")
								.map(c -> new PermanentCropFormFieldConfig(c, false, true))
				).collect(Collectors.toList()));

		given(validatorCropPlanDAO.getCropPlanConfig(1L, "INVALID_LAND_USE_CODES", null)).willReturn(
			       Collections.singletonList(new CropPlanConfigData("INVALID_LAND_USE_CODES", "000 111")));

		given(validatorCropPlanDAO.getCropPlanConfig(1L, "MANDATORY_PLANTING_DATE_PRECISION", null)).willReturn(
		       Collections.singletonList(new CropPlanConfigData("MANDATORY_PLANTING_DATE_PRECISION", "YM")));


		// test
		validatorPluginImpl.checkSV04(anomalies, env, declarations, data, support);


		List<ValidationAnomaly> anomalyList = new ArrayList<>();
		for (ValidationAnomalyObject validationAnomalyObject : vaoList)
			anomalyList.addAll(anomalies.get(validationAnomalyObject));

		Assertions.assertThat(anomalyList).hasSize(12);

		for (ValidationAnomalyObject validationAnomalyObject : vaoList) {
			if (validationAnomalyObject.getObjectCode().equals("d00001") ||
					validationAnomalyObject.getObjectCode().equals("d00002") ||
					validationAnomalyObject.getObjectCode().equals("d02005")) {
				Assertions.assertThat(anomalies.get(validationAnomalyObject)).isEmpty();
			} else {
				Assertions.assertThat(anomalies.get(validationAnomalyObject)).extracting(ValidationAnomaly::getErrorCode).contains(errorCode);
			}
		}
	}

	private ValidatorBoundedDeclaration givenDecl(String plotCode, String declCode, String varietyCode, double areaPerc, LocalDate fromDate,
			String fromDatePrecision) {
		return new ValidatorBoundedDeclaration(plotCode, null, null, declCode, varietyCode, areaPerc, fromDate, null, fromDatePrecision, null);
	}

	@Path("/")
	public static class PingResource {

		@GET
		@Path("{tenant}/public/v1/lpis/sectors/{sector_code}/blocks/{block_code}/parcels/{parcel_code}/edit-status")
		@Operation(description = "Get edit status parcel in specific sector code and block code")
		public Response getParcelsEditStatus(
				@HeaderParam("accept-language") @DefaultValue("en") String lang,
				@Parameter(hidden = true) @Auth User user,
				@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
				@Parameter(description = "Sector code") @PathParam("sector_code") String sectorCode,
				@Parameter(description = "Block code") @PathParam("block_code") String blockCode,
				@Parameter(description = "Parcel code") @PathParam("parcel_code") String parcelCode,
				@Parameter(description = "Reference date") @QueryParam("reference_date") String referenceDate) {
			//				@Parameter(description = "Reference date") @QueryParam("reference_date") com.abacogroup.jdbi.datatype.AbsoluteDate referenceDate) {

			return Response.accepted().build();
		}

		private Response responseFromFile(String resourcePath) {
			try (InputStream is = this.getClass().getClassLoader()
					.getResourceAsStream(resourcePath)) {
				if (null == is) {
					log.error("test response file {} null", resourcePath);
					return Response.status(404).build();
				}
				byte[] targetArray = new byte[is.available()];

				is.read(targetArray);

				return Response.ok(targetArray, MediaType.APPLICATION_JSON_TYPE).build();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
	}
}
