package com.abacogroup.cropplan.plugins.avepa.dao.ntt;

import java.util.List;

import com.abacogroup.cropplan.sdk.model.domain.SnapElements.SnapGeometry;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public abstract class CataloghiLayerDef {
    private String layerCode;
    private String layerDescription;
    private boolean fromVectorDataLayers;
    private boolean snappable;
    private boolean calcCoveredByInsertedOnCutOnLayer;

    public abstract List<SnapGeometry> getSnapGeometry();
}
