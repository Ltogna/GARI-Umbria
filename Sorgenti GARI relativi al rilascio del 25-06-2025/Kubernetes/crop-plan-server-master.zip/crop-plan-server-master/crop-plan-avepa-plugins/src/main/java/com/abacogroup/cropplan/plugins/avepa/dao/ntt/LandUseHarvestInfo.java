package com.abacogroup.cropplan.plugins.avepa.dao.ntt;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Land use harvest info")
public class LandUseHarvestInfo {

	@Schema(description = "Land use default harvest days")
	private Integer defaultHarvestDays;

	@Schema(description = "Default from date", format = "yyyyMMdd", example = "20211231")
	private String defaultFromDate;

}
