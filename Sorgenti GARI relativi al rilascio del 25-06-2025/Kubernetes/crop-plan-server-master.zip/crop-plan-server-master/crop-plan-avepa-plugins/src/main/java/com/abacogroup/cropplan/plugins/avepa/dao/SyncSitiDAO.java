package com.abacogroup.cropplan.plugins.avepa.dao;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.function.Consumer;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import com.abacogroup.cropplan.sdk.model.sync.SyncParcel;
import com.abacogroup.jdbi.EnhancedSqlObject;

public interface SyncSitiDAO extends EnhancedSqlObject
{
	
	@SqlQuery("select (case when oldestDt < to_date('99991231','yyyymmdd') then oldestDt else null end) as oldestDt"
			+ "  from ("
			+ "   select greatest(least("
			+ "             min(to_date((npr.anno_inizio-1)||'1101','yyyymmdd')),"
			+ "             min(case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231','yyyymmdd') end),"
			+ "             min(cond.data_inizio_conduzione),"
			+ "             min(case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then (cond.data_fine_conduzione+1) else to_date('99991231','yyyymmdd') end)"
			+ "          ), :syncStartDt) as oldestDt"
			+ "     from tisole_npr npr, tisole_cond cond"
			+ "    where npr.data_aggiornamento_geom <= :currentDt"
			+ "      and cond.cod_isola = npr.cod_isola"
			+ "      and cond.data_aggiornamento <= :currentDt"
			+ "      and cond.id_soggetto = :businessId"
			+ "      and (:lastSyncDt < npr.data_aggiornamento_geom or :lastSyncDt < cond.data_aggiornamento)"
			+ "  )")
	public LocalDateTime getOldestChangesDate(@Bind("businessId") String businessId,
		@Bind("lastSyncDt") LocalDateTime lastSyncDt, @Bind("currentDt") LocalDateTime currentDt,
		@Bind("syncStartDt") LocalDate syncStartDt);
	
	@SqlQuery("select (case when nextDt < to_date('99991231','yyyymmdd') then nextDt else null end) as nextDt"
			+ "  from ("
			+ "   select least("
			+ "             min(case when to_date((npr.anno_inizio-1)||'1101','yyyymmdd') > :pointInTime then to_date((npr.anno_inizio-1)||'1101','yyyymmdd') else to_date('99991231','yyyymmdd') end),"
			+ "             min(case when npr.anno_fine < 9999 and (to_date(npr.anno_fine||'1031','yyyymmdd')+1) > :pointInTime then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231','yyyymmdd') end),"
			+ "             min(case when trunc(cond.data_inizio_conduzione) > :pointInTime then cond.data_inizio_conduzione else to_date('99991231','yyyymmdd') end),"
			+ "             min(case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') and trunc(cond.data_fine_conduzione+1) > :pointInTime then (cond.data_fine_conduzione+1) else to_date('99991231','yyyymmdd') end)"
			+ "          ) as nextDt"
			+ "     from tisole_npr npr, tisole_cond cond"
			+ "    where npr.data_aggiornamento_geom <= :currentDt"
			+ "      and cond.cod_isola = npr.cod_isola"
			+ "      and cond.data_aggiornamento <= :currentDt"
			+ "      and cond.id_soggetto = :businessId"
			+ "      and (:lastSyncDt is null or :lastSyncDt < npr.data_aggiornamento_geom or :lastSyncDt < cond.data_aggiornamento)"
			+ "      and ("
			+ "         to_date((npr.anno_inizio-1)||'1101','yyyymmdd') > :pointInTime or"
			+ "         (npr.anno_fine < 9999 and (to_date(npr.anno_fine||'1031','yyyymmdd')+1) > :pointInTime) or npr.anno_fine >= 9999 or"
			+ "         trunc(cond.data_inizio_conduzione) > :pointInTime or"
			+ "         (cond.data_fine_conduzione < to_date('99990101','yyyymmdd') and trunc(cond.data_fine_conduzione+1) > :pointInTime) or cond.data_fine_conduzione >= to_date('99990101','yyyymmdd')"
			+ "      )"
			+ "  )")
	public LocalDateTime getNextChangesDate(@Bind("businessId") String businessId,
		@Bind("lastSyncDt") LocalDateTime lastSyncDt, @Bind("currentDt") LocalDateTime currentDt,
		@Bind("pointInTime") LocalDateTime pointInTime);
	
	/*@SqlQuery("select distinct npr.isola_npr_geom_id"
			+ "  from tisole_npr npr, tisole_cond cond"
			+ " where npr.data_aggiornamento_geom <= :currentDt"
			+ "   and :currentDt between npr.dt_insert and npr.dt_delete"
			+ "   and :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
			+ "   and cond.cod_isola = npr.cod_isola"
			+ "   and cond.data_aggiornamento <= :currentDt"
			+ "   and :currentDt between cond.dt_insert and cond.dt_delete"
			+ "   and :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
			+ "   and cond.id_soggetto = :businessId")
	public List<String> getAllParcelIds(@Bind("businessId") String businessId,
		@Bind("currentDt") LocalDateTime currentDt, @Bind("pointInTime") LocalDateTime pointInTime);*/
	
	@SqlQuery("select distinct npr.isola_npr_geom_id"
			+ "  from tisole_npr npr, tisole_cond cond"
			+ " where npr.data_aggiornamento_geom <= :currentDt"
			+ "   and :currentDt between npr.dt_insert and npr.dt_delete"
			+ "   and :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
			+ "   and cond.cod_isola = npr.cod_isola"
			+ "   and cond.data_aggiornamento <= :currentDt"
			+ "   and :currentDt between cond.dt_insert and cond.dt_delete"
			+ "   and :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
			+ "   and cond.id_soggetto = :businessId")
	public void consumeAllParcelIds(@Bind("businessId") String businessId,
		@Bind("currentDt") LocalDateTime currentDt, @Bind("pointInTime") LocalDateTime pointInTime, Consumer<String> consumer);
	
	@SqlQuery("select npr.isola_npr_geom_id"
			+ "  from tisole_npr npr, tisole_cond cond"
			+ " where npr.data_aggiornamento_geom <= :currentDt"
			+ "   and :currentDt between npr.dt_insert and npr.dt_delete"
			+ "   and cond.cod_isola = npr.cod_isola"
			+ "   and cond.data_aggiornamento <= :currentDt"
			+ "   and :currentDt between cond.dt_insert and cond.dt_delete"
			+ "   and cond.id_soggetto = :businessId"
			+ "   and (:lastSyncDt is null or :lastSyncDt < npr.data_aggiornamento_geom or :lastSyncDt < cond.data_aggiornamento)"
			+ "   and ("
			+ "      trunc(:pointInTime) = to_date((npr.anno_inizio-1)||'1101','yyyymmdd') or "
			+ "      trunc(:pointInTime) = (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231','yyyymmdd') end) or"
			+ "      trunc(:pointInTime) = trunc(cond.data_inizio_conduzione) or"
			+ "      trunc(:pointInTime) = (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231','yyyymmdd') end) or"
			+ "      ("
			+ "         trunc(:pointInTime) = :syncStartDt AND"
			+ "         :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231','yyyymmdd') end) AND"
			+ "         :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231','yyyymmdd') end)"
			+ "      )"
			+ "   )")
	public List<String> getChangedParcelIds(@Bind("businessId") String businessId, @Bind("lastSyncDt") LocalDateTime lastSyncDt,
		@Bind("currentDt") LocalDateTime currentDt, @Bind("syncStartDt") LocalDate syncStartDt, @Bind("pointInTime") LocalDateTime pointInTime);
	
	@SqlQuery("select npr.isola_npr_geom_id"
			+ "  from tisole_npr npr, tisole_cond cond"
			+ " where npr.data_aggiornamento_geom <= :currentDt"
			+ "   and cond.cod_isola = npr.cod_isola"
			+ "   and cond.data_aggiornamento <= :currentDt"
			+ "   and cond.id_soggetto = :businessId"
			+ "   and (not :currentDt between npr.dt_insert and npr.dt_delete or not :currentDt between cond.dt_insert and cond.dt_delete)"
			+ "   and (:lastSyncDt < npr.data_aggiornamento_geom or :lastSyncDt < cond.data_aggiornamento)"
			+ "   and ("
			+ "      trunc(:pointInTime) = least(to_date((npr.anno_inizio-1)||'1101','yyyymmdd'), :syncStartDt) or "
			+ "      trunc(:pointInTime) = (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231','yyyymmdd') end) or"
			+ "      trunc(:pointInTime) = least(trunc(cond.data_inizio_conduzione), :syncStartDt) or"
			+ "      trunc(:pointInTime) = (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231','yyyymmdd') end)"
			+ "   )")
	public List<String> getDeletedParcelIds(@Bind("businessId") String businessId, @Bind("lastSyncDt") LocalDateTime lastSyncDt,
		@Bind("currentDt") LocalDateTime currentDt, @Bind("syncStartDt") LocalDate syncStartDt,
		@Bind("pointInTime") LocalDateTime pointInTime);
	
	@SqlQuery("select npr.isola_npr_geom_id as code,"
			+ "       cs.cod_sezione as domainZoneId,"
			+ "       npr.shape_inte as geom,"
			+ "       null as defaultLandUse"
			+ "  from tisole_npr npr, tisole_cond cond, cata_fogl cf, cata_sezioni cs"
			+ " where npr.isola_npr_geom_id in (<changeIds>)"
			+ "   and npr.data_aggiornamento_geom <= :currentDt"
			+ "   and :currentDt between npr.dt_insert and npr.dt_delete"
			+ "   and :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
			+ "   and cond.cod_isola = npr.cod_isola"
			+ "   and cond.data_aggiornamento <= :currentDt"
			+ "   and :currentDt between cond.dt_insert and cond.dt_delete"
			+ "   and :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
			+ "   and cond.id_soggetto = :businessId"
			+ "   and cf.id_foglio = npr.id_foglio"
			+ "   and cs.id_sezione = cf.id_sezione")
	@RegisterBeanMapper(SyncParcel.class)
	List<SyncParcel> getParcelsForWizard(@Bind("businessId") String businessId, @Bind("currentDt") LocalDateTime currentDt,
			@Bind("pointInTime") LocalDateTime pointInTime, @BindList("changeIds") List<String> changeIds);

	@SqlQuery("select distinct cs.cod_sezione as domainZoneId,"
			+ " npr.isola_npr_geom_id as code,"
			+ " null as geom,"
			+ " null as defaultLandUse,"
			+ " null as plotNameToBeAssigned"
			+ "  from tisole_npr npr, cata_fogl cf, cata_sezioni cs"
			+ " where npr.isola_npr_geom_id in (<changeIds>)"
			+ "   and cf.id_foglio = npr.id_foglio"
			+ "   and cs.id_sezione = cf.id_sezione")
	@RegisterBeanMapper(SyncParcel.class)
	List<SyncParcel> getParcelDomainZoneIds(@BindList("changeIds") List<String> changeIds);
	
	@SqlQuery("select distinct cs.cod_sezione as domainZoneId,"
			+ " npr.isola_npr_id as code,"
			+ " null as geom,"
			+ " null as defaultLandUse,"
			+ " null as plotNameToBeAssigned"
			+ "  from tisole_npr npr, cata_fogl cf, cata_sezioni cs"
			+ " where npr.isola_npr_id in (<changeIds>)"
			+ "   and cf.id_foglio = npr.id_foglio"
			+ "   and cs.id_sezione = cf.id_sezione")
	@RegisterBeanMapper(SyncParcel.class)
	List<SyncParcel> getParcelDomainZoneIdsByIsolaNprId(@BindList("changeIds") List<String> changeIds);

}
