package com.abacogroup.cropplan.plugins.avepa.dao;

import java.time.LocalDateTime;
import java.util.function.Consumer;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.transaction.Transactional;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.jdbi.EnhancedSqlObject;

public interface SyncCropPlanDAO extends EnhancedSqlObject, Transactional<SyncCropPlanDAO> {

	@SqlQuery("select distinct cpdp.parcel_code as parcelId"
			+ "  from crpl_plot_data cpd, crpl_plot_data_parcels cpdp"
			+ " where cpd.plan_id = :cropPlanId"
			+ "   and :currentDt between cpd.dt_insert and cpd.dt_delete"
			+ "   and cpdp.plot_data_id = cpd.id")
	public void consumeAllCropPlanParcelIds(@Bind("cropPlanId") Long cropPlanId, @Bind("currentDt") LocalDateTime currentDt, Consumer<String> consumer);

	@SqlQuery("select sdo_aggr_union(SDOAGGRTYPE(§geom_mbr(cpd.geom)§,0.005))"
			+ "  from crpl_plot_data cpd"
			+ " where cpd.plan_id = :cropPlanId"
			+ "   and §current_timestamp§ between cpd.dt_insert and cpd.dt_delete"
			+ "   and :pointInTime between cpd.day_from and cpd.day_to")
	public Geometry getPlotsMbr(@Bind("cropPlanId") Long cropPlanId, @Bind("pointInTime") String pointInTime);

	/*@SqlQuery("SELECT p.PARCEL_CODE AS parcelId, p.area_sqm AS area, p.land_cover_code AS landCoverCode"
			+ "  FROM CRPL_PLOT_DATA_PARCELS p, CRPL_PLOT_DATA cpd"
			+ " WHERE cpd.PLAN_ID = :cropPlanId"
			+ "   AND to_char(:pointInTime, 'yyyymmdd') BETWEEN cpd.day_from AND cpd.day_to"
			+ "   AND :currentDt BETWEEN cpd.dt_insert AND cpd.DT_DELETE"
			+ "   AND p.plot_data_id = cpd.id"
			+ " GROUP BY p.PARCEL_CODE, p.area_sqm, p.land_cover_code")
	@RegisterBeanMapper(CropPlanNPR.class)
	public List<CropPlanNPR> getCropPlanNPR(@Bind("cropPlanId") Long cropPlanId, @Bind("currentDt") LocalDateTime currentDt,
			@Bind("pointInTime") LocalDateTime pointInTime);

	@Transaction
	default public void updateNPRCode(Long cropPlanId, LocalDateTime currentDt, LocalDateTime pointInTime,
			CropPlanNPR cropPlanNPR, MatchingNPR matchingNPR,
			String userId, LocalDateTime deleteDt) {
		List<PlotToBeUpdated> plotIds = getPlotsToBeUpdated(cropPlanId, currentDt, pointInTime, cropPlanNPR.getParcelId());
		plotIds.forEach(plot -> {
			updatePlotDataInternal(plot.getPlotId(), userId, deleteDt);
			Long newPlotId = getCropPlotDataSeq();
			insertPlotDataInternal(newPlotId, plot.getPlotId(), userId, currentDt);
			insertPlotDataParcelInternal(newPlotId, matchingNPR.getParcelId(), cropPlanNPR.getArea(), cropPlanNPR.getLandCoverCode(), plot.getParcelGeom());
		});
	}
	
	@SqlQuery("§select_nextval(crpl_plot_data_seq)§")
	public Long getCropPlotDataSeq();
	
	@SqlQuery("SELECT cpd.id as plotId, p.geom as parcelGeom"
			+ "  FROM CRPL_PLOT_DATA cpd, CRPL_PLOT_DATA_PARCELS p"
			+ " WHERE cpd.PLAN_ID = :cropPlanId"
			+ "   AND to_char(:pointInTime, 'yyyymmdd') BETWEEN cpd.day_from AND cpd.day_to"
			+ "   AND :currentDt BETWEEN cpd.dt_insert AND cpd.DT_DELETE"
			+ "   AND p.plot_data_id = cpd.id"
			+ "   AND p.parcel_code = :parcelId")
	@RegisterBeanMapper(PlotToBeUpdated.class)
	public List<PlotToBeUpdated> getPlotsToBeUpdated(@Bind("cropPlanId") Long cropPlanId, @Bind("currentDt") LocalDateTime currentDt,
			@Bind("pointInTime") LocalDateTime pointInTime, @Bind("parcelId") String parcelId);

	@SqlUpdate("update crpl_plot_data"
			+ "    set user_id_delete = :deleteUserId, dt_delete = :deleteDt"
			+ "  where id = :plotId")
	@QueryTimeOut(10)
	public void updatePlotDataInternal(@Bind("plotId") Long plotId, 
			@Bind("deleteUserId") String deleteUserId, 
			@Bind("deleteDt") LocalDateTime deleteDt);

	@SqlUpdate("insert into crpl_plot_data (id, plot_code, plan_id, day_from, day_to, srs, area_sqm, fl_soft_modified, fl_versioned, user_id_insert, user_id_delete, dt_insert, dt_delete, geom, transaction_id)"
			+ " select :newPlotId, plot_code, plan_id, day_from, day_to, srs, area_sqm, fl_soft_modified, 0, :insertUserId, null, :insertDt, to_date('99991231','yyyymmdd'), geom, null"
			+ "   from crpl_plot_data"
			+ "  where id = :plotId")
	public void insertPlotDataInternal(@Bind("newPlotId") Long newPlotId, @Bind("plotId") Long plotId, 
			@Bind("insertUserId") String insertUserId, @Bind("insertDt") LocalDateTime insertDt);

	@SqlUpdate("insert into crpl_plot_data_parcels (id, plot_data_id, parcel_code, area_sqm, land_cover_code, fl_outside, geom)"
			+ " values (§nextval(crpl_plot_data_parcels_seq)§, :plotId, :parcelCode, :areaSqm, :landCoverCode, 0, :geom)")
	public void insertPlotDataParcelInternal(@Bind("plotId") Long plotId, @Bind("parcelCode") String parcelCode,
			@Bind("areaSqm") Integer areaSqm, @Bind("landCoverCode") String landCoverCode, @Bind("geom") Geometry geom);*/

}
