package com.abacogroup.cropplan.plugins.avepa.dao;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import com.abacogroup.jdbi.EnhancedSqlObject;

public interface LayersFascicoloDAO extends EnhancedSqlObject
{

	@SqlQuery("select count(*)"
		+ "		 from vsso_users_functions vsuf"
		+ "		where vsuf.userid = :userId"
		+ "		  and vsuf.context_id = :context"
		+ "		  and vsuf.function_id = :function")
	public Boolean isContextFunctionEnabledInternal(@Bind("userId") String userId, @Bind("context") String context,
		@Bind("function") String function);

	default public Boolean isContextFunctionEnabled(String userId, String contextFunction)
	{
		var tokens = contextFunction.split("\\|");
		if (tokens.length == 2)
		{
			return isContextFunctionEnabledInternal(userId, tokens[0], tokens[1]);
		}

		return false;
	}

}
