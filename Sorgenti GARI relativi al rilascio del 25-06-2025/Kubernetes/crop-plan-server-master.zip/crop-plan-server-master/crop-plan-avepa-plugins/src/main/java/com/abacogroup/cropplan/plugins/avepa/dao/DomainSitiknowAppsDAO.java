package com.abacogroup.cropplan.plugins.avepa.dao;

import java.time.LocalDateTime;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import com.abacogroup.cropplan.sdk.model.domain.CadastralParcelOverlapData;
import com.abacogroup.jdbi.EnhancedSqlObject;

public interface DomainSitiknowAppsDAO extends EnhancedSqlObject
{
	@SqlQuery("select council_sector_id from lau_councils_sectors where council_sector_code = :domainZoneId and :pointInTime between dt_start and dt_end")
	public Long getCouncilSectorId(@Bind("domainZoneId") String domainZoneId, @Bind("pointInTime") LocalDateTime pointInTime);
	
	@SqlQuery("select t.parcel_number_1 as parcel1,"
			+ "       labels.sheet(t.sheet_id_1) as sectorBlock1,"
			+ "       labels.council_sector(t.council_sector_id_1,5) as domainZoneCode1,"
			+ "       labels.council_sector(t.council_sector_id_1,3) as domainZoneDescription1,"
			+ "       t.parcel_number_2 as parcel2,"
			+ "       labels.sheet(t.sheet_id_2) as sectorBlock2,"
			+ "       labels.council_sector(t.council_sector_id_2,5) as domainZoneCode2,"
			+ "       labels.council_sector(t.council_sector_id_2,3) as domainZoneDescription2,"
			+ "       (select po.shape from sitifarmer_parcel_overlaps po where po.subj_entity_id = t.subj_entity_id and :pointInTime between po.dt_start and po.dt_end and po.parcel_id_1 = t.parcel_id_1 and po.parcel_id_2 = t.parcel_id_2 and rownum = 1) as geom,"
			+ "       t.area_overlap as overlapAreaSqm"
			+ "  from (select distinct po.subj_entity_id as subj_entity_id,"
			+ "               s1.council_sector_id as council_sector_id_1,"
			+ "               s1.sheet_id as sheet_id_1,"
			+ "               po.parcel_id_1, TRIM(LEADING 0 FROM p1.parcel_number) as parcel_number_1,"
			+ "               s2.council_sector_id as council_sector_id_2,"
			+ "               s2.sheet_id as sheet_id_2,"
			+ "               po.parcel_id_2, TRIM(LEADING 0 FROM p2.parcel_number) as parcel_number_2,"
			+ "               SDO_GEOM.SDO_AREA(po.shape, 0.0005) as area_overlap"
			+ "          from sitifarmer_parcel_overlaps po, lpis_parcels_cat p1, lau_sheets s1, lpis_parcels_cat p2, lau_sheets s2"
			+ "         where po.subj_entity_id = :businessId"
			+ "           and :pointInTime between po.dt_start and po.dt_end"
			+ "           and p1.parcel_id = po.parcel_id_1"
			+ "           and s1.sheet_id = p1.sheet_id"
			+ "           and p2.parcel_id = po.parcel_id_2"
			+ "           and s2.sheet_id = p2.sheet_id"
			+ "           and (s1.council_sector_id = :councilSectorId or s2.council_sector_id = :councilSectorId)) t")
	@RegisterBeanMapper(CadastralParcelOverlapData.class)
	public ResultIterator<CadastralParcelOverlapData> getCadastralParcelsOverlapsData(@Bind("businessId") String businessId, 
			@Bind("councilSectorId") Long councilSectorId, @Bind("pointInTime") LocalDateTime pointInTime);

}
