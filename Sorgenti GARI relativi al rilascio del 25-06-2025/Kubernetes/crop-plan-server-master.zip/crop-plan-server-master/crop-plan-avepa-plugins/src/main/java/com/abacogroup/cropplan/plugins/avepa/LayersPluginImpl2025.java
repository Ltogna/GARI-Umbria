package com.abacogroup.cropplan.plugins.avepa;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryFactory;

import com.abacogroup.cropplan.plugins.avepa.dao.BusinessSitiknowDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.DomainSitiDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.DomainSitiknow2025DAO;
import com.abacogroup.cropplan.plugins.avepa.dao.LayersFascicoloDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.LayersSitiDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.LayersSitiknowAppsDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.CataloghiLayers2025;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.Declarations2024GisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.Declarations2024SnapGeometry;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.GisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.NPRGisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.SitiSuoloGisInfoData;
import com.abacogroup.cropplan.plugins.avepa.model.CuttableLayerWithGeoms;
import com.abacogroup.cropplan.sdk.model.business.Business;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements.SnapGeometry;
import com.abacogroup.cropplan.sdk.model.layers.AdditionalLayer;
import com.abacogroup.cropplan.sdk.model.layers.CuttableLayer;
import com.abacogroup.cropplan.sdk.model.layers.GISInfo;
import com.abacogroup.cropplan.sdk.model.layers.LayerParameter;
import com.abacogroup.cropplan.sdk.model.layers.LayerParameterType;
import com.abacogroup.cropplan.sdk.model.layers.LayerType;
import com.abacogroup.cropplan.sdk.model.layers.WmsLayer;
import com.abacogroup.cropplan.sdk.model.layers.WmtsLayer;
import com.abacogroup.cropplan.sdk.spi.LayersPlugin;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

public class LayersPluginImpl2025 implements LayersPlugin, InitializablePlugin {
	private static final String JDBI_NAME_SITIKNOW_APPS = "dbSitiknowApps";
	private static final String JDBI_NAME_SITI = "dbSiti";
	private static final String JDBI_NAME_SITIKNOW = "dbSitiknow";
	private static final String JDBI_NAME_FASCICOLO = "dbFascicolo";

	private static final String P_CODE_WMSLAY = "WMSLAY";
	private static final String S_CODE_WMSLAY_COUNCILS = "COUNCILS";
	private static final String S_CODE_WMSLAY_SHEETS = "SHEETS";
	private static final String S_CODE_WMSLAY_CADPARCELS = "CADPARCELS";
	private static final String S_CODE_WMSLAY_CADPARCELS_INT = "CADPARCELS_INT";

	private static final String P_CODE_GISINFO = "GISINFO";
	private static final String S_CODE_GISINFO_CADPARCEL = "CADPARCEL";
	private static final String S_CODE_GISINFO_SHEET = "SHEET";
	private static final String S_CODE_GISINFO_COUNCIL = "COUNCIL";

	private static final String LAYER_CODE_CADPARCELS = "CADPARCELS";
	private static final String LAYER_CODE_PARCELS = "PARCELS";
	private static final String LAYER_CODE_NPR = "NPR";
	private static final String LAYER_CODE_SITISUOLO = "SITISUOLO";
	private static final String LAYER_CODE_SHEETS = "SHEETS";
	private static final String LAYER_CODE_COUNCILS = "COUNCILS";
	private static final String LAYER_CODE_CADPARCELS_INT = "CADPARCELS_INT";
	private static final String LAYER_CODE_DECLARATIONS_2024 = "DECLARATIONS_2024";

	private LayersSitiknowAppsDAO layersSitiknowAppsDAO;
	private LayersSitiDAO layersSitiDAO;
	private LayersFascicoloDAO layersFascicoloDAO;
	private DomainSitiDAO domainSitiDAO;
	private DomainSitiknow2025DAO domainSitiknowDAO;
	private BusinessSitiknowDAO businessSitiknowDAO;

	private static final Integer FOREGROUND_LEVEL_ORTOPHOTO = 0;
	private static final Integer FOREGROUND_LEVEL_ORTOPHOTO_AGEA = 1;
	private static final Integer FOREGROUND_LEVEL_ADDITIONAL_LAYERS = 2;

	@Override
	public void initialize(PluginsEnvironment env) {
		var jdbiSitiknowApps = env.getJdbi(JDBI_NAME_SITIKNOW_APPS);
		if (jdbiSitiknowApps == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITIKNOW_APPS);

		layersSitiknowAppsDAO = jdbiSitiknowApps.onDemand(LayersSitiknowAppsDAO.class);

		var jdbiSiti = env.getJdbi(JDBI_NAME_SITI);
		if (jdbiSiti == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITI);

		layersSitiDAO = jdbiSiti.onDemand(LayersSitiDAO.class);
		domainSitiDAO = jdbiSiti.onDemand(DomainSitiDAO.class);

		var jdbiSitiknow = env.getJdbi(JDBI_NAME_SITIKNOW);
		if (jdbiSitiknow == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITIKNOW);

		domainSitiknowDAO = jdbiSitiknow.onDemand(DomainSitiknow2025DAO.class);
		businessSitiknowDAO = jdbiSitiknow.onDemand(BusinessSitiknowDAO.class);

		var jdbiFascicolo = env.getJdbi(JDBI_NAME_FASCICOLO);
		if (jdbiFascicolo == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_FASCICOLO);

		layersFascicoloDAO = jdbiFascicolo.onDemand(LayersFascicoloDAO.class);
	}

	@Override
	public List<AdditionalLayer> getAdditionalLayers(RuntimeEnvironment env, String businessId, String domainZoneId, Integer campaignYear, String module) {
		var additionalLayers = new ArrayList<AdditionalLayer>();

		var wmtsLayerAvepaOrtofoto2021 = new WmtsLayer("avepa.ortofoto.2021", "Ortofoto->Ortofoto 2021", null, null, null, false, false, 999, FOREGROUND_LEVEL_ORTOPHOTO, LayerType.WMTS,
				null);
		wmtsLayerAvepaOrtofoto2021.setUrl("/dev-proxy/login2-coll-avepa-it/wms-proxy-avepa/wms/wmts");
		wmtsLayerAvepaOrtofoto2021.setLayer("avepa:ortofoto_2021");
		wmtsLayerAvepaOrtofoto2021.setTileMatrixSet("EPSG:3003");
		wmtsLayerAvepaOrtofoto2021.setTileMatrix("EPSG:3003");
		wmtsLayerAvepaOrtofoto2021.setSrs("EPSG:3003");
		wmtsLayerAvepaOrtofoto2021.setFormat("image/jpeg");
		wmtsLayerAvepaOrtofoto2021.setLayerParameters(null);

		additionalLayers.add(wmtsLayerAvepaOrtofoto2021);

		var wmtsLayerAvepaOrtofoto2024 = new WmtsLayer("avepa.ortofoto.2024", "Ortofoto->Ortofoto 2024", null, null, null, true, true, 998, FOREGROUND_LEVEL_ORTOPHOTO, LayerType.WMTS,
				null);
		wmtsLayerAvepaOrtofoto2024.setUrl("/dev-proxy/login2-coll-avepa-it/wms-proxy-avepa/wms/wmts");
		wmtsLayerAvepaOrtofoto2024.setLayer("avepa:ortofoto_2024");
		wmtsLayerAvepaOrtofoto2024.setTileMatrixSet("EPSG:3003");
		wmtsLayerAvepaOrtofoto2024.setTileMatrix("EPSG:3003");
		wmtsLayerAvepaOrtofoto2024.setSrs("EPSG:3003");
		wmtsLayerAvepaOrtofoto2024.setFormat("image/jpeg");
		wmtsLayerAvepaOrtofoto2024.setLayerParameters(null);

		additionalLayers.add(wmtsLayerAvepaOrtofoto2024);

		additionalLayers.addAll(getAgeaAdditionalLayers(env.getUserName(), businessId, domainZoneId));

		var layerParameters = new ArrayList<LayerParameter>();
		layerParameters.add(new LayerParameter(LayerParameterType.POINT_IN_TIME_WITH_TIME, "dt_ref"));
		layerParameters.add(new LayerParameter(LayerParameterType.POINT_IN_TIME_WITH_TIME, "in_dt_rif"));
		layerParameters.add(new LayerParameter(LayerParameterType.POINT_IN_TIME, "point_in_time"));
		layerParameters.add(new LayerParameter(LayerParameterType.CAMPAIGN, "in_campaign"));

		if (domainZoneId != null && !domainZoneId.isEmpty()) {
			var mainWmsServer = layersSitiknowAppsDAO.getAppParam("CROPPLAN_PLUGIN_WMS_SERVER");
			if (mainWmsServer == null)
				mainWmsServer = layersSitiknowAppsDAO.getAppParam("MAIN_WMS_SERVER");
			if (mainWmsServer != null) {
				/* SOVRAPPOSIZIONI PARTICELLE CATASTALI */
				var wmsProject = "sitifarmer_azienda_int";
				var url = mainWmsServer + "?project=" + wmsProject + "&subj_entity_id=" + businessId + "&in_council_sector_id="
						  + layersSitiknowAppsDAO.getCouncilSectorId(domainZoneId);
				String intlnCadParcelsInt = layersSitiknowAppsDAO.getDecodedIntlnDescription(P_CODE_WMSLAY, S_CODE_WMSLAY_CADPARCELS_INT, env.getLocale().getLanguage());
				additionalLayers.add(getWmsLayer(LAYER_CODE_CADPARCELS_INT, intlnCadParcelsInt != null ? intlnCadParcelsInt : S_CODE_WMSLAY_CADPARCELS_INT, null, null, null, url,
						"sovrapposte", false, false, 500, FOREGROUND_LEVEL_ADDITIONAL_LAYERS, layerParameters));

				/* CATALOGHI */
				wmsProject = "cataloghi";
				url = mainWmsServer + "?project=" + wmsProject + "&subj_entity_id=" + businessId;

				var legendOrder = 499;
				for (var cl : CataloghiLayers2025.getCataloghiLayers(domainSitiDAO, null)) {
					String layerUrl = cl.isFromVectorDataLayers() ? "/vector-data-layers/" + env.getTenantId() + "/wms" : url;
					additionalLayers.add(getWmsLayer(cl.getLayerCode(), cl.getLayerDescription(), cl.getLayerCode(), null, null, layerUrl,
							cl.getLayerCode(), false, false, legendOrder, FOREGROUND_LEVEL_ADDITIONAL_LAYERS, layerParameters));
					legendOrder -= 1;
				}

				/* AZIENDA */
				wmsProject = "sitifarmer_azienda_2021";
				url = mainWmsServer + "?project=" + wmsProject + "&subj_entity_id=" + businessId + "&in_council_sector_id="
					  + layersSitiknowAppsDAO.getCouncilSectorId(domainZoneId);

				String intlnCouncil = layersSitiknowAppsDAO.getDecodedIntlnDescription(P_CODE_WMSLAY, S_CODE_WMSLAY_COUNCILS, env.getLocale().getLanguage());
				String intlnSheets = layersSitiknowAppsDAO.getDecodedIntlnDescription(P_CODE_WMSLAY, S_CODE_WMSLAY_SHEETS, env.getLocale().getLanguage());
				String intlnCadParcels = layersSitiknowAppsDAO.getDecodedIntlnDescription(P_CODE_WMSLAY, S_CODE_WMSLAY_CADPARCELS, env.getLocale().getLanguage());

				additionalLayers.add(getWmsLayer(LAYER_CODE_COUNCILS, intlnCouncil != null ? intlnCouncil : S_CODE_WMSLAY_COUNCILS, null, null, null, url,
						"Limiti Comunali", false, false, 50, FOREGROUND_LEVEL_ADDITIONAL_LAYERS, layerParameters));
				additionalLayers.add(getWmsLayer(LAYER_CODE_SHEETS, intlnSheets != null ? intlnSheets : S_CODE_WMSLAY_SHEETS, null, null, null, url,
						"Fogli", false, false, 40, FOREGROUND_LEVEL_ADDITIONAL_LAYERS, layerParameters));
				additionalLayers.add(getWmsLayer(LAYER_CODE_CADPARCELS, intlnCadParcels != null ? intlnCadParcels : S_CODE_WMSLAY_CADPARCELS, "CADPARCEL", null, null, url,
						"Business Cadastral Parcels", false, false, 10, FOREGROUND_LEVEL_ADDITIONAL_LAYERS, layerParameters));

				url = "/vector-data-layers/" + env.getTenantId() + "/wms?party_id=" + businessId + "&sector_code=" + domainZoneId;
				additionalLayers.add(getWmsLayer(LAYER_CODE_PARCELS, "Isole", "PARCEL", null, null, url,
						"PARCELS_ISOLE", true, false, 20, FOREGROUND_LEVEL_ADDITIONAL_LAYERS, layerParameters));

				additionalLayers.add(getWmsLayer(LAYER_CODE_NPR, "NPR", "NPR", null, 3.5, url,
						"NPR_PCG_2025", false, false, 30, FOREGROUND_LEVEL_ADDITIONAL_LAYERS, layerParameters));

				additionalLayers.add(getWmsLayer(LAYER_CODE_SITISUOLO, "Uso suolo GIS", "SITISUOLO", null, 3.5, url,
						"SITISUOLO", false, false, 35, FOREGROUND_LEVEL_ADDITIONAL_LAYERS, layerParameters));

				Business business = businessSitiknowDAO.getBusiness(businessId);
				String businessCode = business != null ? business.getCode() : null;
				url += "&cuaa=" + businessCode;
				additionalLayers.add(getWmsLayer(LAYER_CODE_DECLARATIONS_2024, "Dichiarazioni 2024", "DECLARATIONS_2024", null, null, url,
						"DECLARATIONS_2024", false, false, 35, FOREGROUND_LEVEL_ADDITIONAL_LAYERS, layerParameters));
			}
		}

		return additionalLayers;
	}

	private WmsLayer getWmsLayer(String code, String description, String snapElementType, Double minResolution, Double maxResolution, String url, String layer,
			boolean on, boolean enabledInOverview, Integer legendOrder, Integer foregroundLevel, List<LayerParameter> layerParameters) {
		var wmsLayer = new WmsLayer(code, description, snapElementType, minResolution, maxResolution, on, enabledInOverview, legendOrder, foregroundLevel,
				LayerType.WMS, null);
		wmsLayer.setUrl(url);
		wmsLayer.setLayers(layer);
		wmsLayer.setSrs("none");
		wmsLayer.setFormat("image/png");
		wmsLayer.setBgcolor("#ffffff");
		wmsLayer.setTransparent(true);
		wmsLayer.setLayerParameters(layerParameters);
		return wmsLayer;
	}

	private List<AdditionalLayer> getAgeaAdditionalLayers(String userName, String businessId, String domainZoneId) {

		List<AdditionalLayer> additionalLayers = new ArrayList<>();

		// TODO configurare gli AGEA additional layers nella getAdditionalLayers di LPIS
		var farmerWmsLayers = layersSitiknowAppsDAO.getAgeaAdditionalLayers(businessId, domainZoneId, userName);

		var layerParameters = new ArrayList<LayerParameter>();
		layerParameters.add(new LayerParameter(LayerParameterType.POINT_IN_TIME, "point_in_time"));
		layerParameters.add(new LayerParameter(LayerParameterType.DOMAIN_ZONE_ID, "domain_zone_id"));

		farmerWmsLayers.forEach(c -> {
			if (c.getContextFunction() != null
				&& !layersFascicoloDAO.isContextFunctionEnabled(businessId, c.getContextFunction()))
				return;

			switch (c.getLayerType()) {
			/*case "WMS":
				var wmsLayer = new WmsLayer(c.getCode(), c.getDescription(), null, null, c.getMaxPixelVal(), c.getFlVisible(), c.getFlVisible(), null);
				wmsLayer.setUrl(c.getUrl());
				wmsLayer.setLayers(c.getLayer());
				wmsLayer.setSrs(c.getSrs());
				wmsLayer.setFormat(c.getFormat());
				wmsLayer.setBgcolor(c.getBgcolor());
				wmsLayer.setTransparent(c.getFlTransparent());
				wmsLayer.setLayerParameters(layerParameters);
				additionalLayers.add(wmsLayer);
				break;*/

			case "WMTS":
				var wmtsLayer = new WmtsLayer(c.getCode(), c.getDescription(), null, null, c.getMaxPixelVal(), c.getFlVisible(), c.getFlVisible(), null,
						FOREGROUND_LEVEL_ORTOPHOTO_AGEA, LayerType.WMTS, null);
				var url = c.getUrl().split(";");
				//wmtsLayer.setUrl(url[0]);
				wmtsLayer.setUrl("/geoserver/gwc/service/wmts");
				if (url.length > 1)
					wmtsLayer.setTileMatrixSet(url[1]);
				wmtsLayer.setTileMatrix(c.getSrs());
				wmtsLayer.setLayer(c.getLayer());
				wmtsLayer.setSrs(c.getSrs());
				wmtsLayer.setFormat(c.getFormat());
				wmtsLayer.setLayerParameters(layerParameters);
				additionalLayers.add(wmtsLayer);
				break;
			}
		});

		for (var i = 0; i < additionalLayers.size(); i++)
			additionalLayers.get(i).setLegendOrder(998 - i);

		return additionalLayers;
	}

	@Override
	public List<GISInfo> getGISInfo(RuntimeEnvironment env, String businessId, String domainZoneId,
			LocalDate pointInTime, Double x, Double y, List<String> layerCodes) {
		final var touchingGeometry = new GeometryFactory().createPoint(new Coordinate(x, y));
		ArrayList<GISInfo> gisInfos = new ArrayList<>();

		final String councilDescription = domainSitiknowDAO.getDomainZoneDescription(pointInTime, domainZoneId);
		final Long councilSectorId = layersSitiknowAppsDAO.getCouncilSectorId(domainZoneId);

		final String S_CODE_CADPARCELS = layersSitiknowAppsDAO.getDecodedIntlnDescription(P_CODE_WMSLAY, S_CODE_WMSLAY_CADPARCELS, env.getLocale().getLanguage());
		final String S_CODE_COUNCILS = layersSitiknowAppsDAO.getDecodedIntlnDescription(P_CODE_WMSLAY, S_CODE_WMSLAY_COUNCILS, env.getLocale().getLanguage());
		final String S_CODE_SHEETS = layersSitiknowAppsDAO.getDecodedIntlnDescription(P_CODE_WMSLAY, S_CODE_WMSLAY_SHEETS, env.getLocale().getLanguage());

		final String S_CODE_COUNCIL = layersSitiknowAppsDAO.getDecodedIntlnDescription(P_CODE_GISINFO, S_CODE_GISINFO_COUNCIL, env.getLocale().getLanguage());
		final String S_CODE_SHEET = layersSitiknowAppsDAO.getDecodedIntlnDescription(P_CODE_GISINFO, S_CODE_GISINFO_SHEET, env.getLocale().getLanguage());
		final String S_CODE_CADPARCEL = layersSitiknowAppsDAO.getDecodedIntlnDescription(P_CODE_GISINFO, S_CODE_GISINFO_CADPARCEL, env.getLocale().getLanguage());

		if (layerCodes.contains(LAYER_CODE_PARCELS)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_CODE_PARCELS);
			gisInfo.setTitle("Isole");
			gisInfo.setCards(new LinkedList<>());

			List<GisInfoData> gisInfoData = domainSitiknowDAO.getParcelsGisInfoData(businessId, domainZoneId, touchingGeometry, pointInTime);

			if (!gisInfoData.isEmpty()) {
				gisInfoData.forEach(gis -> gisInfo.getCards().add(new GISInfo.GISInfoCard(
						gis.getTitle(),
						gis.getArea(),
						gis.getMbr(),
						Arrays.asList(
								new GISInfo.GISInfoCardField(S_CODE_COUNCIL != null ? S_CODE_COUNCIL : S_CODE_GISINFO_COUNCIL, councilDescription),
								new GISInfo.GISInfoCardField(S_CODE_SHEET != null ? S_CODE_SHEET : S_CODE_GISINFO_SHEET, gis.getSheet()),
								new GISInfo.GISInfoCardField("Isola", gis.getParcel())))));
				if (!gisInfo.getCards().isEmpty())
					gisInfos.add(gisInfo);
			}
		}

		if (layerCodes.contains(LAYER_CODE_NPR)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_CODE_NPR);
			gisInfo.setTitle("NPR");
			gisInfo.setCards(new LinkedList<>());

			List<NPRGisInfoData> gisInfoData = domainSitiknowDAO.getNPRGisInfoData(touchingGeometry, pointInTime);

			if (!gisInfoData.isEmpty()) {
				gisInfoData.forEach(gis -> gisInfo.getCards().add(new GISInfo.GISInfoCard(
						gis.getTitle(),
						gis.getArea(),
						gis.getMbr(),
						Arrays.asList(
								new GISInfo.GISInfoCardField("NPR", gis.getNpr()),
								new GISInfo.GISInfoCardField("Suolo", gis.getLandCoverCode() + " - " + gis.getLandCoverDescription())))));
				if (!gisInfo.getCards().isEmpty())
					gisInfos.add(gisInfo);
			}
		}

		if (layerCodes.contains(LAYER_CODE_SITISUOLO)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_CODE_SITISUOLO);
			gisInfo.setTitle("Uso suolo GIS");
			gisInfo.setCards(new LinkedList<>());

			List<SitiSuoloGisInfoData> gisInfoData = domainSitiDAO.getSitisuoloGisInfoData(touchingGeometry);

			if (!gisInfoData.isEmpty()) {
				gisInfoData.forEach(gis -> gisInfo.getCards().add(new GISInfo.GISInfoCard(
						gis.getTitle(),
						gis.getArea(),
						gis.getMbr(),
						Arrays.asList())));
				if (!gisInfo.getCards().isEmpty())
					gisInfos.add(gisInfo);
			}
		}

		if (layerCodes.contains(LAYER_CODE_DECLARATIONS_2024)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_CODE_DECLARATIONS_2024);
			gisInfo.setTitle("Dichiarazioni 2024");
			gisInfo.setCards(new LinkedList<>());

			List<Declarations2024GisInfoData> gisInfoData = domainSitiDAO.getDeclarations2024GisInfoData(touchingGeometry, domainZoneId);

			if (!gisInfoData.isEmpty()) {
				gisInfoData.forEach(gis -> gisInfo.getCards().add(new GISInfo.GISInfoCard(
						gis.getTitle(),
						gis.getArea(),
						gis.getMbr(),
						Arrays.asList(
								new GISInfo.GISInfoCardField("Codice coltura", gis.getLandUseCode()),
								new GISInfo.GISInfoCardField("Descrizione", gis.getLandUseDescription()),
								new GISInfo.GISInfoCardField("Superficie colturale", String.format("%,.4f", gis.getDeclaredArea() / 10000.0) + " ha")))));
				if (!gisInfo.getCards().isEmpty())
					gisInfos.add(gisInfo);
			}
		}

		if (layerCodes.contains(LAYER_CODE_CADPARCELS)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_CODE_CADPARCELS);
			gisInfo.setTitle(S_CODE_CADPARCELS != null ? S_CODE_CADPARCELS : S_CODE_WMSLAY_CADPARCELS);
			gisInfo.setCards(new LinkedList<>());

			var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));
			List<GisInfoData> gisInfoData = layersSitiDAO.getParcelsGisInfoData(domainZoneId, businessId, touchingGeometry, whereDateAtEndOfDay);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(new GISInfo.GISInfoCard(
					gis.getTitle(),
					gis.getArea(),
					gis.getMbr(),
					Arrays.asList(
							new GISInfo.GISInfoCardField(S_CODE_COUNCIL != null ? S_CODE_COUNCIL : S_CODE_GISINFO_COUNCIL, councilDescription),
							new GISInfo.GISInfoCardField(S_CODE_SHEET != null ? S_CODE_SHEET : S_CODE_GISINFO_SHEET, gis.getSheet()),
							new GISInfo.GISInfoCardField(S_CODE_CADPARCEL != null ? S_CODE_CADPARCEL : S_CODE_GISINFO_CADPARCEL, gis.getParcel())))));
			if (!gisInfo.getCards().isEmpty())
				gisInfos.add(gisInfo);
		}

		if (layerCodes.contains(LAYER_CODE_SHEETS)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_CODE_SHEETS);
			gisInfo.setTitle(S_CODE_SHEETS != null ? S_CODE_SHEETS : S_CODE_WMSLAY_SHEETS);
			gisInfo.setCards(new LinkedList<>());

			List<GisInfoData> gisInfoData = domainSitiknowDAO.getSheetGisInfoData(councilSectorId, touchingGeometry, pointInTime);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(new GISInfo.GISInfoCard(
					gis.getTitle(),
					gis.getArea(),
					gis.getMbr(),
					Arrays.asList(
							new GISInfo.GISInfoCardField(S_CODE_COUNCIL != null ? S_CODE_COUNCIL : S_CODE_GISINFO_COUNCIL,
									councilDescription),
							new GISInfo.GISInfoCardField(S_CODE_SHEET != null ? S_CODE_SHEET : S_CODE_GISINFO_SHEET,
									gis.getSheet())))));
			if (!gisInfo.getCards().isEmpty())
				gisInfos.add(gisInfo);
		}

		if (layerCodes.contains(LAYER_CODE_COUNCILS)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_CODE_COUNCILS);
			gisInfo.setTitle(S_CODE_COUNCILS != null ? S_CODE_COUNCILS : S_CODE_WMSLAY_COUNCILS);
			gisInfo.setCards(new LinkedList<>());

			List<GisInfoData> gisInfoData = domainSitiknowDAO.getCouncilGisInfoData(councilSectorId, touchingGeometry, pointInTime);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(new GISInfo.GISInfoCard(
					councilDescription,
					gis.getArea(),
					gis.getMbr(),
					List.of(
							new GISInfo.GISInfoCardField(S_CODE_COUNCIL != null ? S_CODE_COUNCIL : S_CODE_GISINFO_COUNCIL,
									councilDescription)))));
			if (!gisInfo.getCards().isEmpty())
				gisInfos.add(gisInfo);
		}

		/* CATALOGHI */
		gisInfos.addAll(CataloghiLayers2025.getCataloghiLayersGISInfos(domainSitiDAO, layerCodes, touchingGeometry));

		return gisInfos;
	}

	@Override
	public List<CuttableLayer> getCuttableLayers(RuntimeEnvironment env, String businessId, String domainZoneId, LocalDate pointInTime,
			List<String> layerCodes, Geometry touchingGeometry) {

		List<CuttableLayerWithGeoms> cuttableLayersWithGeoms = this.getCuttableLayersInternal(businessId, domainZoneId, pointInTime,
				layerCodes, touchingGeometry);

		return cuttableLayersWithGeoms.stream().map(CuttableLayerWithGeoms::getCuttableLayer).toList();
	}

	@Override
	public List<Geometry> getLayerGeometries(RuntimeEnvironment env, String businessId, String domainZoneId, LocalDate pointInTime,
			String layerCode, Geometry touchingGeometry) {

		List<CuttableLayerWithGeoms> cuttableLayersWithGeoms = this.getCuttableLayersInternal(businessId, domainZoneId, pointInTime,
				List.of(layerCode), touchingGeometry);

		return cuttableLayersWithGeoms.stream().map(CuttableLayerWithGeoms::getGeometries).flatMap(Collection::stream).toList();

	}

	private List<CuttableLayerWithGeoms> getCuttableLayersInternal(String businessId, String domainZoneId, LocalDate pointInTime, List<String> layerCodes, Geometry touchingGeometry) {

		List<CuttableLayerWithGeoms> res = new ArrayList<>();

		if (null == layerCodes || layerCodes.isEmpty()) {
			return res;
		}

		// NPR
		if (layerCodes.contains(LAYER_CODE_NPR)) {
			CuttableLayerWithGeoms cuttableLayerWithGeoms = new CuttableLayerWithGeoms(
					CuttableLayer.builder().layerCode(LAYER_CODE_NPR).build(),
					new ArrayList<>()
			);

			domainSitiknowDAO.getNPRSnapGeometries(touchingGeometry, pointInTime, sg -> {
				cuttableLayerWithGeoms.getGeometries().add(sg.getGeom());
			});

			if (!cuttableLayerWithGeoms.getGeometries().isEmpty()) {
				res.add(cuttableLayerWithGeoms);
			}
		}
		
		// SITISUOLO
		if (layerCodes.contains(LAYER_CODE_SITISUOLO)) {
			CuttableLayerWithGeoms cuttableLayerWithGeoms = new CuttableLayerWithGeoms(
					CuttableLayer.builder().layerCode(LAYER_CODE_SITISUOLO).build(),
					new ArrayList<>()
			);

			domainSitiDAO.getSitiSuoloSnapGeometries(touchingGeometry, sg -> {
				if(sg.getGeom() != null) {
					cuttableLayerWithGeoms.getGeometries().add(sg.getGeom());
				}
			});

			if (!cuttableLayerWithGeoms.getGeometries().isEmpty()) {
				res.add(cuttableLayerWithGeoms);
			}
		}

		// DECLARATIONS_2024
		if (layerCodes.contains(LAYER_CODE_DECLARATIONS_2024)) {
			CuttableLayerWithGeoms cuttableLayerWithGeoms = new CuttableLayerWithGeoms(
					CuttableLayer.builder().layerCode(LAYER_CODE_DECLARATIONS_2024).build(),
					new ArrayList<>()
			);

			for (Declarations2024SnapGeometry snapGeometry : domainSitiDAO.getDeclarations2024SnapGeometries(touchingGeometry, domainZoneId)) {
				cuttableLayerWithGeoms.getGeometries().add(snapGeometry.getGeom());
			}

			if (!cuttableLayerWithGeoms.getGeometries().isEmpty()) {
				res.add(cuttableLayerWithGeoms);
			}
		}

		// CADPARCEL
		if (layerCodes.contains(LAYER_CODE_CADPARCELS)) {
			CuttableLayerWithGeoms cuttableLayerWithGeoms = new CuttableLayerWithGeoms(
					CuttableLayer.builder().layerCode(LAYER_CODE_CADPARCELS).build(),
					new ArrayList<>()
			);

			var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));

			for (SnapGeometry snapGeometry : domainSitiDAO.getCadastralParcelsSnapGeometries(businessId, whereDateAtEndOfDay, domainZoneId, touchingGeometry.getEnvelope())) {
				cuttableLayerWithGeoms.getGeometries().add(snapGeometry.getGeom());
			}

			if (!cuttableLayerWithGeoms.getGeometries().isEmpty()) {
				res.add(cuttableLayerWithGeoms);
			}
		}

		/* CATALOGHI */
		for (var cl : CataloghiLayers2025.getCataloghiLayers(domainSitiDAO, touchingGeometry)) {
			if (layerCodes.contains(cl.getLayerCode()) && cl.isSnappable()) {
				CuttableLayerWithGeoms cuttableLayerWithGeoms = new CuttableLayerWithGeoms(
						CuttableLayer.builder()
								.layerCode(cl.getLayerCode())
								.flMergeGeomsOnCutOnLayer(true)
								.flCalcCoveredByInsertedOnCutOnLayer(cl.isCalcCoveredByInsertedOnCutOnLayer())
								.build(),
						new ArrayList<>()
				);

				for (SnapGeometry snapGeometry : cl.getSnapGeometry()) {
					cuttableLayerWithGeoms.getGeometries().add(snapGeometry.getGeom());
				}

				if (!cuttableLayerWithGeoms.getGeometries().isEmpty()) {
					res.add(cuttableLayerWithGeoms);
				}
			}
		}

		return res;
	}

	@Override
	public String getCropPlanType() {
		return "CROPPLAN_2025";
	}
}
