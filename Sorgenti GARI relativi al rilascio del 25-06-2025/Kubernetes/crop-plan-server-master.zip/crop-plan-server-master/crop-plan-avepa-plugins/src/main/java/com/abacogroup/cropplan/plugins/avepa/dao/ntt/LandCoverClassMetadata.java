package com.abacogroup.cropplan.plugins.avepa.dao.ntt;

import com.abacogroup.cropplan.sdk.model.cropcodes.LandCoverClassEditability;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class LandCoverClassMetadata
{
	@NotNull
	@Schema(description = "The land cover class code")
	private String landCoverClassCode;

	@NotNull
	private LandCoverClassEditability flEditable;

	@NotNull
	@Schema(description = "If true then the compatibility between land cover class and land use declared will not be checked")
	private Boolean flIgnoreLuCompatibility;
}
