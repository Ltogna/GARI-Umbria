package com.abacogroup.cropplan.plugins.avepa.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.function.Consumer;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.cropplan.plugins.avepa.dao.ntt.GisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.NPRGisInfoData;
import com.abacogroup.cropplan.sdk.model.domain.DomainZoneGeometry;
import com.abacogroup.cropplan.sdk.model.domain.HoldingArea;
import com.abacogroup.cropplan.sdk.model.domain.LandCover;
import com.abacogroup.cropplan.sdk.model.domain.Parcel;
import com.abacogroup.cropplan.sdk.model.domain.ParcelData;
import com.abacogroup.cropplan.sdk.model.domain.ParcelDescription;
import com.abacogroup.cropplan.sdk.model.domain.ParcelGeometry;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements.SnapGeometry;
import com.abacogroup.jdbi.EnhancedSqlObject;

import lombok.Data;

public interface DomainSitiknow2025DAO extends EnhancedSqlObject
{

	@SqlQuery("SELECT DISTINCT codi_refr AS landUseClassCode "
			+ "  FROM npr.aablprif_2024_tab npr "
			+ " WHERE sysdate between npr.data_inse_prif and npr.data_scad_prif "
			+ "   AND :pointInTime between to_date((npr.anno_iniz_prif-1)||'1101','yyyymmdd') and to_date((npr.anno_fine_prif-1)||'1031','yyyymmdd') "
			+ "   AND §geom_have_interactions(npr.shape, :touchingGeometry)§ "
			+ "   AND SDO_GEOM.SDO_AREA(SDO_GEOM.SDO_INTERSECTION(npr.shape, :touchingGeometry, 0.005), 0.005) > 1 ")
	List<String> getLandUseClassCodes(
			@Bind("touchingGeometry") Geometry touchingGeometry,
			@Bind("pointInTime") LocalDate pointInTime
	);

	@SqlQuery("SELECT DISTINCT dcg.s_code_parent AS landCoverCode, "
			+ "       sitiknow_2021.deco_srv.get_decode('COVCOD_CROP_PLAN', dcg.s_code_parent) as landCoverDescription "
			+ "  FROM npr.aablprif_2024_tab npr "
			+ "       join sitiknow_2021.deco_codes_groups dcg on dcg.s_code_child = npr.codi_refr "
			+ " WHERE sysdate between npr.data_inse_prif and npr.data_scad_prif "
			+ "   AND :pointInTime between to_date((npr.anno_iniz_prif-1)||'1101','yyyymmdd') and to_date((npr.anno_fine_prif-1)||'1031','yyyymmdd') "
			+ "   AND §geom_have_interactions(npr.shape, :touchingGeometry)§ "
			+ "   AND SDO_GEOM.SDO_AREA(SDO_GEOM.SDO_INTERSECTION(npr.shape, :touchingGeometry, 0.005), 0.005) > 1 "
			+ "   and dcg.p_code_child='COVCOD' "
			+ "   and dcg.p_code_parent='COVCOD_CROP_PLAN' ")
	@RegisterBeanMapper(LandCover.class)
	List<LandCover> getLandCovers(
			@Bind("touchingGeometry") Geometry touchingGeometry,
			@Bind("pointInTime") LocalDate pointInTime
	);

	@SqlQuery("SELECT sum(round(cond.supe_isola)) as areaSqm \n"
			+ "  FROM siti.tisole_cond cond \n"
			+ " WHERE cond.id_soggetto = :businessId \n"
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete \n"
			+ "   AND :pointInTime between trunc(cond.data_inizio_conduzione) and trunc(cond.data_fine_conduzione-1+1/24/60/60)")
	@RegisterBeanMapper(HoldingArea.class)
	public HoldingArea getHoldingArea(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDate pointInTime);

	@SqlQuery("SELECT sum(round(cond.supe_isola)) as areaSqm \n"
			+ "  FROM siti.tisole_cond cond \n"
			+ " WHERE cond.id_soggetto = :businessId \n"
			+ "   AND cond.cod_nazionale = :domainZoneId \n"
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete \n"
			+ "   AND :pointInTime between trunc(cond.data_inizio_conduzione) and trunc(cond.data_fine_conduzione-1+1/24/60/60)")
	@RegisterBeanMapper(HoldingArea.class)
	public HoldingArea getHoldingAreaByDomainZones(@Bind("businessId") String businessId,
		@Bind("domainZoneId") String domainZoneId, @Bind("pointInTime") LocalDate pointInTime);

	@SqlQuery("select lcs.council_sector_code as domainZoneId,"
			+ "       lcs.council_sector_code as code,"
			+ "       (lcs.council_sector_code || ' - ' || sitiknow_2021.labels.council_sector(lcs.council_sector_code,1)) as description,"
			+ "       (select p.epsg_code from sitiknow_2021.cata_sezioni s, sitiknow_2021.dbmap_proj p where s.cod_sezione = lcs.council_sector_code and p.projection_id = s.projection_id) as srs,"
			+ "       nvl((select sdo_aggr_mbr(sdo_geom.sdo_mbr(cond.shape))"
			+ "              from siti.tisole_cond cond"
			+ "             where cond.id_soggetto = :businessId"
			+ "               AND sysdate between cond.dt_insert and cond.dt_delete"
			+ "               AND :pointInTime between trunc(cond.data_inizio_conduzione) and trunc(cond.data_fine_conduzione-1+1/24/60/60)),"
			+ "           (select sdo_aggr_mbr(sdo_geom.sdo_mbr(g.shape)) from sitiknow_2021.gis_councils g, sitiknow_2021.lau_councils_sectors_viw l where g.council_id = l.council_id and l.council_sector_id = lcs.council_sector_id)) as mbr"
			+ "  from sitiknow_2021.lau_councils_sectors lcs"
			+ " where :pointInTime between trunc(lcs.dt_start) and trunc(lcs.dt_end-1+1/24/60/60)"
			+ "   and (:search is null or upper(lcs.name) like '%'||upper(:search)||'%' or lcs.council_sector_code like '%'||upper(:search)||'%')"
			+ " order by lcs.name, lcs.council_sector_code")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	public ResultIterator<DomainZoneGeometry> getDomainZones(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDate pointInTime, @Bind("search") String search);
	
	@SqlQuery("select lcs.council_sector_code as domainZoneId,"
			+ "       lcs.council_sector_code as code,"
			+ "       (lcs.council_sector_code || ' - ' || sitiknow_2021.labels.council_sector(lcs.council_sector_code,1)) as description,"
			+ "       (select p.epsg_code from sitiknow_2021.cata_sezioni s, sitiknow_2021.dbmap_proj p where s.cod_sezione = lcs.council_sector_code and p.projection_id = s.projection_id) as srs,"
			+ "       nvl((select sdo_geom.sdo_mbr(sdo_aggr_union(SDOAGGRTYPE(cond.shape,0.005)))"
			+ "              from siti.tisole_cond cond"
			+ "             where cond.id_soggetto = :businessId"
			+ "               AND sysdate between cond.dt_insert and cond.dt_delete"
			+ "               AND :pointInTime between trunc(cond.data_inizio_conduzione) and trunc(cond.data_fine_conduzione-1+1/24/60/60)),"
			+ "           (select sdo_geom.sdo_mbr(sdo_aggr_union(SDOAGGRTYPE(g.shape,0.005))) from sitiknow_2021.gis_councils g, sitiknow_2021.lau_councils_sectors_viw l where g.council_id = l.council_id and l.council_sector_id = lcs.council_sector_id)) as mbr"
			+ "  from sitiknow_2021.lau_councils_sectors lcs"
			+ " where :pointInTime between trunc(lcs.dt_start) and trunc(lcs.dt_end-1+1/24/60/60)"
			+ "   and (:search is null or upper(lcs.name) like '%'||upper(:search)||'%' or lcs.council_sector_code like '%'||upper(:search)||'%')"
			+ " order by lcs.name, lcs.council_sector_code")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	public ResultIterator<DomainZoneGeometry> getDomainZonesNoSdoAggrMbr(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDate pointInTime, @Bind("search") String search);

	@SqlQuery("select lcs.council_sector_code as domainZoneId,"
			+ "       lcs.council_sector_code as code,"
			+ "       (lcs.council_sector_code || ' - ' || sitiknow_2021.labels.council_sector(lcs.council_sector_code,1)) as description,"
			+ "       (select p.epsg_code from sitiknow_2021.cata_sezioni s, sitiknow_2021.dbmap_proj p where s.cod_sezione = lcs.council_sector_code and p.projection_id = s.projection_id) as srs,"
			+ "       nvl(sdo_aggr_mbr(sdo_geom.sdo_mbr(cond.shape)),(select sdo_aggr_mbr(sdo_geom.sdo_mbr(g.shape)) from sitiknow_2021.gis_councils g, sitiknow_2021.lau_councils_sectors_viw l where g.council_id = l.council_id and l.council_sector_id = lcs.council_sector_id)) as mbr"
			+ "  from siti.tisole_cond cond, sitiknow_2021.lau_councils_sectors lcs"
			+ " where cond.id_soggetto = :businessId"
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete"
			+ "   AND :pointInTime between trunc(cond.data_inizio_conduzione) and trunc(cond.data_fine_conduzione-1+1/24/60/60)"
			+ "   and cond.cod_nazionale = lcs.council_sector_code"
			+ "   and :pointInTime between trunc(lcs.dt_start) and trunc(lcs.dt_end-1+1/24/60/60)"
			+ "   and (:search is null or upper(lcs.name) like '%'||upper(:search)||'%' or lcs.council_sector_code like '%'||upper(:search)||'%')"
			+ " group by lcs.council_sector_id, lcs.council_sector_code, lcs.name"
			+ " order by lcs.name, lcs.council_sector_code")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	public ResultIterator<DomainZoneGeometry> getDomainZonesByBusinessId(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDate pointInTime, @Bind("search") String search);
	
	@SqlQuery("select lcs.council_sector_code as domainZoneId,"
			+ "       lcs.council_sector_code as code,"
			+ "       (lcs.council_sector_code || ' - ' || sitiknow_2021.labels.council_sector(lcs.council_sector_code,1)) as description,"
			+ "       (select p.epsg_code from sitiknow_2021.cata_sezioni s, sitiknow_2021.dbmap_proj p where s.cod_sezione = lcs.council_sector_code and p.projection_id = s.projection_id) as srs,"
			+ "       nvl(sdo_geom.sdo_mbr(sdo_aggr_union(SDOAGGRTYPE(cond.shape,0.005))),(select sdo_geom.sdo_mbr(sdo_aggr_union(SDOAGGRTYPE(g.shape,0.005))) from sitiknow_2021.gis_councils g, sitiknow_2021.lau_councils_sectors_viw l where g.council_id = l.council_id and l.council_sector_id = lcs.council_sector_id)) as mbr"
			+ "  from siti.tisole_cond cond, sitiknow_2021.lau_councils_sectors lcs"
			+ " where cond.id_soggetto = :businessId"
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete"
			+ "   AND :pointInTime between trunc(cond.data_inizio_conduzione) and trunc(cond.data_fine_conduzione-1+1/24/60/60)"
			+ "   and cond.cod_nazionale = lcs.council_sector_code"
			+ "   and :pointInTime between trunc(lcs.dt_start) and trunc(lcs.dt_end-1+1/24/60/60)"
			+ "   and (:search is null or upper(lcs.name) like '%'||upper(:search)||'%' or lcs.council_sector_code like '%'||upper(:search)||'%')"
			+ " group by lcs.council_sector_id, lcs.council_sector_code, lcs.name"
			+ " order by lcs.name, lcs.council_sector_code")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	public ResultIterator<DomainZoneGeometry> getDomainZonesByBusinessIdNoSdoAggrMbr(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDate pointInTime, @Bind("search") String search);

	@SqlQuery("select lcs.council_sector_code as domainZoneId,"
			+ "       lcs.council_sector_code as code,"
			+ "       (lcs.council_sector_code || ' - ' || sitiknow_2021.labels.council_sector(lcs.council_sector_code,1)) as description,"
			+ "       (select p.epsg_code from sitiknow_2021.cata_sezioni s, sitiknow_2021.dbmap_proj p where s.cod_sezione = lcs.council_sector_code and p.projection_id = s.projection_id) as srs,"
			+ "       (select sdo_aggr_mbr(sdo_geom.sdo_mbr(g.shape)) from sitiknow_2021.gis_councils g, sitiknow_2021.lau_councils_sectors_viw l where g.council_id = l.council_id and l.council_sector_id = lcs.council_sector_id) as mbr"
			+ "  from sitiknow_2021.lau_councils_sectors lcs"
			+ " where lcs.council_sector_code in (<domainZoneIds>)"
			+ "   and (:search is null or upper(lcs.name) like '%'||upper(:search)||'%' or lcs.council_sector_code like '%'||upper(:search)||'%')"
			+ " group by lcs.council_sector_id, lcs.council_sector_code, lcs.name"
			+ " order by lcs.name, lcs.council_sector_code")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	public ResultIterator<DomainZoneGeometry> getDomainZonesByIds(@Bind("search") String search, @BindList("domainZoneIds") List<String> domainZoneIds);
	
	@SqlQuery("select lcs.council_sector_code as domainZoneId,"
			+ "       lcs.council_sector_code as code,"
			+ "       (lcs.council_sector_code || ' - ' || sitiknow_2021.labels.council_sector(lcs.council_sector_code,1)) as description,"
			+ "       (select p.epsg_code from sitiknow_2021.cata_sezioni s, sitiknow_2021.dbmap_proj p where s.cod_sezione = lcs.council_sector_code and p.projection_id = s.projection_id) as srs,"
			+ "       nvl((select sdo_aggr_mbr(sdo_geom.sdo_mbr(cond.shape))"
			+ "              from siti.tisole_cond cond"
			+ "             where cond.id_soggetto = :businessId"
			+ "               AND sysdate between cond.dt_insert and cond.dt_delete"
			+ "               AND :pointInTime between trunc(cond.data_inizio_conduzione) and trunc(cond.data_fine_conduzione-1+1/24/60/60)),"
			+ "           (select sdo_aggr_mbr(sdo_geom.sdo_mbr(g.shape)) from sitiknow_2021.gis_councils g, sitiknow_2021.lau_councils_sectors_viw l where g.council_id = l.council_id and l.council_sector_id = lcs.council_sector_id)) as mbr"
			+ "  from sitiknow_2021.lau_councils_sectors lcs"
			+ " where :pointInTime between trunc(lcs.dt_start) and trunc(lcs.dt_end-1+1/24/60/60)"
			+ "   and lcs.council_sector_code = :domainZoneId")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	public DomainZoneGeometry getDomainZone(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDate pointInTime, @Bind("domainZoneId") String domainZoneId);
	
	@SqlQuery("select lcs.council_sector_code as domainZoneId,"
			+ "       lcs.council_sector_code as code,"
			+ "       (lcs.council_sector_code || ' - ' || sitiknow_2021.labels.council_sector(lcs.council_sector_code,1)) as description,"
			+ "       (select p.epsg_code from sitiknow_2021.cata_sezioni s, sitiknow_2021.dbmap_proj p where s.cod_sezione = lcs.council_sector_code and p.projection_id = s.projection_id) as srs,"
			+ "       nvl((select sdo_geom.sdo_mbr(sdo_aggr_union(SDOAGGRTYPE(cond.shape,0.005)))"
			+ "              from siti.tisole_cond cond"
			+ "             where cond.id_soggetto = :businessId"
			+ "               AND sysdate between cond.dt_insert and cond.dt_delete"
			+ "               AND :pointInTime between trunc(cond.data_inizio_conduzione) and trunc(cond.data_fine_conduzione-1+1/24/60/60)),"
			+ "           (select sdo_aggr_mbr(sdo_geom.sdo_mbr(g.shape)) from sitiknow_2021.gis_councils g, sitiknow_2021.lau_councils_sectors_viw l where g.council_id = l.council_id and l.council_sector_id = lcs.council_sector_id)) as mbr"
			+ "  from sitiknow_2021.lau_councils_sectors lcs"
			+ " where :pointInTime between trunc(lcs.dt_start) and trunc(lcs.dt_end-1+1/24/60/60)"
			+ "   and lcs.council_sector_code = :domainZoneId")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	public DomainZoneGeometry getDomainZoneNoSdoAggrMbr(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDate pointInTime, @Bind("domainZoneId") String domainZoneId);

	@SqlQuery("§select_from_dual("
			+ "   (select council_sector_code from sitiknow_2021.lau_councils_sectors where :pointInTime between trunc(dt_start) and trunc(dt_end-1+1/24/60/60) and council_sector_code = :domainZoneId)"
			+ "           || ' - ' || sitiknow_2021.labels.council_sector(:domainZoneId,1))§")
	public String getDomainZoneDescription(@Bind("pointInTime") LocalDate pointInTime, @Bind("domainZoneId") String domainZoneId);

	@SqlQuery("select sdo_aggr_union(SDOAGGRTYPE(sdo_geom.sdo_mbr(cond.shape), 0.005))"
			+ "  from siti.tisole_cond cond"
			+ " where cond.id_soggetto = :businessId"
			+ "   AND cond.cod_nazionale = :domainZoneId"
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete"
			+ "   AND :pointInTime between trunc(cond.data_inizio_conduzione) and trunc(cond.data_fine_conduzione-1+1/24/60/60)")
	public Geometry getDomainParcelsGeom(@Bind("businessId") String businessId,
			@Bind("pointInTime") LocalDate pointInTime, @Bind("domainZoneId") String domainZoneId);

	@SqlQuery("select cond.isola_id as id,"
			+ "       'PARCEL' as type,"
			+ "       cond.shape as geom"
			+ "  from siti.tisole_cond cond"
			+ " where cond.id_soggetto = :businessId"
			+ "   AND cond.cod_nazionale = :domainZoneId"
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete"
			+ "   AND :pointInTime between trunc(cond.data_inizio_conduzione) and trunc(cond.data_fine_conduzione-1+1/24/60/60)")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getParcelsSnapGeometries(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDate pointInTime, @Bind("domainZoneId") String domainZoneId);
		
	@SqlQuery("select cond.isola_id as code,"
			+ "       cond.shape as geom,"
			+ "       to_char(trunc(cond.data_inizio_conduzione),'yyyymmdd') AS fromDate,"
			+ "       to_char(trunc(cond.data_fine_conduzione-1+1/24/60/60),'yyyymmdd') AS toDate"
			+ "  from siti.tisole_cond cond"
			+ " where cond.isola_id in (<parcelCodes>)"
			+ "   and cond.id_soggetto = :businessId"
			+ "   AND cond.cod_nazionale = :domainZoneId")
	@RegisterBeanMapper(Parcel.class)
	public List<Parcel> getParcelsByParcelCodes(@Bind("businessId") String businessId,
			@Bind("domainZoneId") String domainZoneId, @BindList("parcelCodes") List<String> parcelCodes);

	@SqlQuery("select sdo_geom.sdo_mbr(cond.shape)"
			+ "  from siti.tisole_cond cond"
			+ " where cond.isola_id in (<parcelCodes>)"
			+ "   and cond.id_soggetto = :businessId"
			+ "   and sysdate between cond.dt_insert and cond.dt_delete")
	@RegisterBeanMapper(ParcelGeometry.class)
	public List<Geometry> getParcelsMbr(@Bind("businessId") String businessId,
			@BindList("parcelCodes") List<String> parcelCodes);

	@SqlQuery("select cond.isola_id as code,"
       		+ "       cond.cod_isola as description,"
       		+ "       '[' || sitiknow_2021.labels.council_sector(c.council_sector_id, 4) || ' - ' || sitiknow_2021.labels.council_sector(c.council_sector_id, 5) || '] ' || cond.foglio || ' ' || cond.cod_isola as parcelCode,"
       		+ "       cond.PERC_CONDUZIONE as holdingPercentage"
  			+ "  FROM siti.tisole_cond cond, sitiknow_2021.lau_councils_sectors_viw c"
 			+ " WHERE c.council_sector_code = cond.cod_nazionale"
   			+ "   AND SYSDATE BETWEEN c.dt_start AND c.dt_end"
   			+ "   AND SYSDATE BETWEEN cond.dt_insert AND cond.dt_delete"
   			+ "   AND cond.id_soggetto = :businessId"
			+ "   and cond.isola_id in (<parcelCodes>)")
	@RegisterBeanMapper(ParcelDescription.class)
	List<ParcelDescription> getParcelsDescription(@Bind("businessId") String businessId,
			@BindList("parcelCodes") List<String> parcelCodes);
	
	@SqlQuery("select cond.isola_id as code,"
       		+ "       cond.cod_isola as description,"
       		+ "       '[' || sitiknow_2021.labels.council_sector(c.council_sector_id, 4) || ' - ' || sitiknow_2021.labels.council_sector(c.council_sector_id, 5) || '] ' || cond.foglio || ' ' || cond.cod_isola as parcelCode,"
       		+ "       cond.PERC_CONDUZIONE as holdingPercentage"
  			+ "  FROM siti.tisole_cond cond, sitiknow_2021.lau_councils_sectors_viw c"
 			+ " WHERE c.council_sector_code = cond.cod_nazionale"
   			+ "   AND SYSDATE BETWEEN c.dt_start AND c.dt_end"
   			+ "   AND SYSDATE BETWEEN cond.dt_insert AND cond.dt_delete"
   			+ "   AND cond.id_soggetto = :businessId"
			+ "   and cond.isola_id in (<parcelCodes>)")
	@RegisterBeanMapper(ParcelDescription.class)
	List<ParcelDescription> getParcelsDescriptionFromIsolaNprId(@Bind("businessId") String businessId,
		@BindList("parcelCodes") List<String> parcelCodes);

	@SqlQuery("select cond.isola_id as code, "
			+ "       cond.shape as geom "
			+ "  from siti.tisole_cond cond "
			+ " where cond.id_soggetto = :businessId "
			+ "   AND cond.cod_nazionale = :domainZoneId "
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete "
			+ "   AND :pointInTime between trunc(cond.data_inizio_conduzione) and trunc(cond.data_fine_conduzione-1+1/24/60/60) "
			+ "   and §geom_have_interactions(cond.shape, :touchingGeometry)§")
	@RegisterBeanMapper(ParcelGeometry.class)
	public List<ParcelGeometry> getParcels(@Bind("businessId") String businessId,
			@Bind("pointInTime") LocalDate pointInTime, @Bind("domainZoneId") String domainZoneId,
			@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("select cond.isola_id as code, "
			+ "       cond.shape as geom, "
			+ "       to_char(trunc(cond.data_inizio_conduzione),'yyyymmdd') AS fromDate,"
			+ "       to_char(trunc(cond.data_fine_conduzione-1+1/24/60/60),'yyyymmdd') AS toDate"
			+ "  from siti.tisole_cond cond "
			+ " where cond.id_soggetto = :businessId "
			+ "   AND cond.cod_nazionale = :domainZoneId "
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete "
			+ "   AND (:pointInTime is null or :pointInTime between trunc(cond.data_inizio_conduzione) and trunc(cond.data_fine_conduzione-1+1/24/60/60))"
			+ "   AND §geom_have_interactions(cond.shape, :touchingGeometry)§")
	@RegisterBeanMapper(Parcel.class)
	public List<Parcel> getAllParcelsByGeometry(@Bind("businessId") String businessId,
			@Bind("domainZoneId") String domainZoneId, @Bind("pointInTime") LocalDate pointInTime, 
			@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("select cond.isola_id as code, "
			+ "       cond.shape as geom, "
			+ "       to_char(trunc(cond.data_inizio_conduzione),'yyyymmdd') AS fromDate,"
			+ "       to_char(trunc(cond.data_fine_conduzione-1+1/24/60/60),'yyyymmdd') AS toDate"
			+ "  from siti.tisole_cond cond "
			+ " where cond.id_soggetto = :businessId "
			+ "   AND cond.cod_nazionale = :domainZoneId "
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete "
			+ "   AND (:pointInTime is null or :pointInTime between trunc(cond.data_inizio_conduzione) and trunc(cond.data_fine_conduzione-1+1/24/60/60))")
	@RegisterBeanMapper(Parcel.class)
	public List<Parcel> getAllParcels(@Bind("businessId") String businessId,
			@Bind("domainZoneId") String domainZoneId, @Bind("pointInTime") LocalDate pointInTime);

	@SqlQuery("select trunc(cond.data_inizio_conduzione) as d1,"
			+ "       (case when trunc(cond.data_fine_conduzione-1+1/24/60/60) < to_date('99991231','yyyymmdd') then trunc(cond.data_fine_conduzione-1+1/24/60/60)+1 else to_date('99991231','yyyymmdd') end) as d2"
			+ "  from siti.tisole_cond cond "
			+ " where cond.id_soggetto = :businessId"
			+ "   AND cond.cod_nazionale = :domainZoneId"
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete"
			+ "   AND (trunc(cond.data_inizio_conduzione) > :pointInTime or (case when trunc(cond.data_fine_conduzione-1+1/24/60/60) < to_date('99991231','yyyymmdd') then trunc(cond.data_fine_conduzione-1+1/24/60/60)+1 else to_date('99991231','yyyymmdd') end) > :pointInTime)"
			+ "   AND §geom_have_interactions(cond.shape, :touchingGeometry)§")
	@RegisterBeanMapper(FutureParcelIntersectionDates.class)
	public List<FutureParcelIntersectionDates> getFutureParcelsIntersections(@Bind("businessId") String businessId,
			@Bind("pointInTime") LocalDate pointInTime, @Bind("domainZoneId") String domainZoneId,
			@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("select sitiknow_2021.deco_srv.get_decode(:pCode, :sCode, :lang) as description from dual")
	public String getDecodedIntlnDescription(
			@Bind("pCode") String pCode,
			@Bind("sCode") String sCode,
			@Bind("lang") String lang);

	@SqlQuery("SELECT lc.COUNCIL_CODE AS title,"
			+ "       SDO_GEOM.SDO_MBR(gc.SHAPE) AS mbr,"
			+ "       SDO_GEOM.SDO_AREA(gc.SHAPE, 0.005) AS area"
			+ "  FROM sitiknow_2021.LAU_COUNCILS lc, sitiknow_2021.GIS_COUNCILS gc"
			+ " WHERE gc.COUNCIL_ID = lc.COUNCIL_ID"
			+ "   AND (lc.COUNCIL_ID IN ("
			+ "          SELECT MIN(lcsl.COUNCIL_ID)"
			+ "            FROM sitiknow_2021.LAU_COUNCILS_SECTORS_LINKS lcsl"
			+ "           WHERE lcsl.COUNCIL_SECTOR_ID = :councilSectorId"
			+ "             AND :pointInTime between trunc(lcsl.DT_START) and trunc(lcsl.DT_END-1+1/24/60/60)))"
			+ "   AND §geom_have_interactions(gc.shape, :touchingGeometry)§"
			+ "   AND :pointInTime between trunc(gc.DT_START) and trunc(gc.dt_end-1+1/24/60/60)" 
			+ "   AND :pointInTime between trunc(lc.DT_START) and trunc(lc.dt_end-1+1/24/60/60)")
	@RegisterBeanMapper(GisInfoData.class)
	public List<GisInfoData> getCouncilGisInfoData(
			@Bind("councilSectorId") Long councilSectorId,
			@Bind("touchingGeometry") Geometry touchingGeometry,
			@Bind("pointInTime") LocalDate pointInTime);

	@SqlQuery("SELECT sitiknow_2021.labels.sheet(ls.SHEET_ID) AS title,"
			+ "       SDO_GEOM.SDO_MBR(gm.SHAPE) AS mbr,"
			+ "       SDO_GEOM.SDO_AREA(gm.SHAPE, 0.005) AS area,"
			+ "       sitiknow_2021.labels.sheet(ls.SHEET_ID) AS sheet"
			+ "  FROM sitiknow_2021.LAU_SHEETS ls, sitiknow_2021.GIS_MAPS gm"
			+ " WHERE ls.SHEET_ID = gm.SHEET_ID"
			+ "   AND ls.COUNCIL_SECTOR_ID = :councilSectorId"
			+ "   AND §geom_have_interactions(gm.shape, :touchingGeometry)§"
			+ "   AND :pointInTime between trunc(ls.DT_START) and trunc(ls.DT_END-1+1/24/60/60)"
			+ "   AND sysdate between gm.DT_INSERT and gm.DT_DELETE")
	@RegisterBeanMapper(GisInfoData.class)
	public List<GisInfoData> getSheetGisInfoData(
			@Bind("councilSectorId") Long councilSectorId,
			@Bind("touchingGeometry") Geometry touchingGeometry,
			@Bind("pointInTime") LocalDate pointInTime);

	@SqlQuery("SELECT cond.foglio AS sectorBlock,"
			+ "       cond.isola_id AS parcelCode,"
			+ "       (SELECT p.epsg_code"
			+ "          FROM sitiknow_2021.cata_sezioni cs, sitiknow_2021.dbmap_proj p"
			+ "         WHERE cs.cod_sezione = cond.cod_nazionale"
			+ "           AND p.projection_id = cs.projection_id) as srs,"
			+ "       cond.shape AS geom,"
			+ "       SDO_GEOM.SDO_MBR(cond.shape) AS mbrOverview,"
			+ "       cond.supe_isola AS areaSqm,"
			//+ "       decode(sitiknow_2021.template_farm_viewer_pck.has_unimm(cond.cod_isola, :pointInTime),0,0,1) as hasUnimm,"
			//+ "       decode(sitiknow_2021.template_farm_viewer_pck.has_unar(cond.cod_isola, :pointInTime),0,0,1) as hasUnar,"
			+ "       cond.perc_conduzione as holdingPercentage"
			//+ "       sitiknow_2021.template_farm_viewer_pck.has_single_holding(cond.cod_isola, :pointInTime) as holdingCount,"
			//+ "       decode(2,1,'PROPERTY',2,'RENT',3,'SHARECROPPPING',4,'OTHER',null) as holdingType,"
			//+ "       nvl(sitiknow_2021.template_farm_viewer_pck.get_holding_type_decode(cond.cod_isola, :pointInTime, cond.id_soggetto), 2) as holdingTypeDescription,"
			//+ "       decode(1,1,'URBAN',2,'AGRICULTURAL',3,'ROADS',4,'WATERS',null) as parcelType"
			//+ "       nvl(sitiknow_2021.template_farm_viewer_pck.get_parcel_type_decode(cond.cod_isola, :pointInTime), 1) as parcelTypeDescription"
			+ "  from siti.tisole_cond cond"
			+ " where cond.id_soggetto = :businessId"
			+ "   AND (:domainZoneId is null or cond.cod_nazionale = :domainZoneId)"
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete"
			+ "   AND :pointInTime between trunc(cond.data_inizio_conduzione) and trunc(cond.data_fine_conduzione-1+1/24/60/60)"
			+ "   AND (:parcelId is null or cond.isola_id = :parcelId)")
	@RegisterBeanMapper(ParcelData.class)
	public ResultIterator<ParcelData> getParcelsData(
			@Bind("businessId") String businessId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("parcelId") String parcelId,
			@Bind("pointInTime") LocalDate pointInTime);

	@SqlQuery("SELECT cond.cod_isola AS title,"
			+ "       cond.cod_isola as parcel,"
			+ "       SDO_GEOM.SDO_MBR(cond.shape) AS mbr,"
			+ "       cond.supe_isola AS area,"
			+ "       cond.foglio AS sheet"
			+ "  from siti.tisole_cond cond"
			+ " where cond.id_soggetto = :businessId"
			+ "   AND cond.cod_nazionale = :domainZoneId"
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete"
			+ "   AND :pointInTime between trunc(cond.data_inizio_conduzione) and trunc(cond.data_fine_conduzione-1+1/24/60/60)"
			+ "   AND §geom_have_interactions(cond.shape, :touchingGeometry)§")
	@RegisterBeanMapper(GisInfoData.class)
	public List<GisInfoData> getParcelsGisInfoData(@Bind("businessId") String businessId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("touchingGeometry") Geometry touchingGeometry,
			@Bind("pointInTime") LocalDate pointInTime);

	@SqlQuery("SELECT npr.codi_prif AS title,"
			+ "       npr.codi_prif as npr,"
			+ "       SDO_GEOM.SDO_MBR(npr.shape) AS mbr,"
			+ "       npr.supe_prif AS area,"
			+ "       dcg.s_code_parent AS landCoverCode,"
			+ "       sitiknow_2021.deco_srv.get_decode('COVCOD_CROP_PLAN', dcg.s_code_parent) as landCoverDescription"
			+ "  from npr.aablprif_2024_tab npr, sitiknow_2021.deco_codes_groups dcg"
			+ " where sysdate between npr.data_inse_prif and npr.data_scad_prif"
			+ "   AND :pointInTime between to_date((npr.anno_iniz_prif-1)||'1101','yyyymmdd') and to_date((npr.anno_fine_prif-1)||'1031','yyyymmdd')"
			+ "   AND §geom_have_interactions(npr.shape, :touchingGeometry)§"
			+ "   AND dcg.s_code_child = npr.codi_refr"
			+ "   AND dcg.p_code_child='COVCOD'"
			+ "   AND dcg.p_code_parent='COVCOD_CROP_PLAN'")
	@RegisterBeanMapper(NPRGisInfoData.class)
	public List<NPRGisInfoData> getNPRGisInfoData(@Bind("touchingGeometry") Geometry touchingGeometry, @Bind("pointInTime") LocalDate pointInTime);

	@SqlQuery("select npr.id_prif as id,"
			+ "       'NPR' as type,"
			+ "       npr.shape as geom"
			+ "  from npr.aablprif_2024_tab npr"
			+ " where sysdate between npr.data_inse_prif and npr.data_scad_prif"
			+ "   AND :pointInTime between to_date((npr.anno_iniz_prif-1)||'1101','yyyymmdd') and to_date((npr.anno_fine_prif-1)||'1031','yyyymmdd')"
			+ "   AND §geom_have_interactions(npr.shape, :touchingGeometry)§")
	@RegisterBeanMapper(SnapGeometry.class)
	public void getNPRSnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry, @Bind("pointInTime") LocalDate pointInTime,
			Consumer<SnapGeometry> consumer);
	@Data
	class FutureParcelIntersectionDates
	{
		private LocalDate d1;
		private LocalDate d2;
	}

}
