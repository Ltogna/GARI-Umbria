package com.abacogroup.cropplan.plugins.avepa.dao.ntt;

import org.locationtech.jts.geom.Geometry;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MatchingNPR
{
	private String parcelId;
	private Geometry newGeom;
	private Geometry oldGeom;
}