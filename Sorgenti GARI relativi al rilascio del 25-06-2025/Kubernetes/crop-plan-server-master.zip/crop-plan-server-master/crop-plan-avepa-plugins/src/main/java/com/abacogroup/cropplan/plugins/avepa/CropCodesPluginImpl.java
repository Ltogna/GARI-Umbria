package com.abacogroup.cropplan.plugins.avepa;

import static java.util.stream.Collectors.toMap;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.cropplan.plugins.avepa.dao.CropCodesSitiknowAppsDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.LandUseDetailsExt;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.StyleWithCode;
import com.abacogroup.cropplan.plugins.avepa.model.DeclAggregationKey;
import com.abacogroup.cropplan.plugins.avepa.utils.LandCoverUtils;
import com.abacogroup.cropplan.plugins.avepa.utils.StyleColorUtils;
import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandCoverClassEditability;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandCoverFilter;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseClass;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseDetails;
import com.abacogroup.cropplan.sdk.model.cropcodes.Style;
import com.abacogroup.cropplan.sdk.model.domain.LandCover;
import com.abacogroup.cropplan.sdk.spi.CropCodesPlugin;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.MaxRowsResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.jdbi.paging.impl.MaxRowsResultsImpl;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CropCodesPluginImpl implements CropCodesPlugin, InitializablePlugin {
	private static final String JDBI_NAME_SITIKNOW_APPS = "dbSitiknowApps";

	private static int MAX_ROWS = 50;
	private static int PAGE_SIZE = 50;
	// private static final Logger log = LoggerFactory.getLogger(CropCodesPluginImpl.class);
	private CropCodesSitiknowAppsDAO cropCodesSitiknowAppsDAO;
	// private ScheduledExecutorService executor;

	@Getter(AccessLevel.PACKAGE)
	private LoadingCache<String, Set<String>> aggregationExcludedLandUseCodesCache;

	@Override
	public void initialize(PluginsEnvironment env) {
		var jdbiSitiknowApps = env.getJdbi(JDBI_NAME_SITIKNOW_APPS);
		if (jdbiSitiknowApps == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITIKNOW_APPS);

		cropCodesSitiknowAppsDAO = jdbiSitiknowApps.onDemand(CropCodesSitiknowAppsDAO.class);

		/*try {
			cropCodesSitiknowAppsDAO.createCrplCovCodCache();
		} catch (Exception e) {
			log.debug("Cache already exists?", e);
		}

		executor = Executors.newScheduledThreadPool(1);
		executor.scheduleAtFixedRate(this::updateCache, 0, 15, TimeUnit.MINUTES);*/

		this.aggregationExcludedLandUseCodesCache = Caffeine.newBuilder()
				.expireAfterWrite(1, TimeUnit.DAYS)
				.build(this::readLines);
	}

	/*private void updateCache() {
		try {
			cropCodesSitiknowAppsDAO.updateCrplCovCodCache();
		} catch (Exception e) {
			log.error("Error refreshing the crplcovcod cache", e);
		}
	}*/

	@Override
	public List<LandUse> getLandUses(RuntimeEnvironment env, List<String> codes) {
		return cropCodesSitiknowAppsDAO.getLandUses(codes, env.getLocale().getLanguage());
	}

	@Override
	public Map<String, Style> getLandUseStyles(RuntimeEnvironment env, List<String> codes) {
		var styles = cropCodesSitiknowAppsDAO.getLandUseStyles(codes);
		styles.forEach(r -> {
			r.setFillColor(StyleColorUtils.getColorRGBFromDefaultPalette(r.getFillColor()));
			r.setBorderColor(StyleColorUtils.getColorRGBFromDefaultPalette(r.getBorderColor()));
		});

		Map<String, Style> stylesMap = styles.stream().collect(toMap(StyleWithCode::getCode, Function.identity()));
		codes.forEach(c -> {
			if (stylesMap.get(c) == null) {
				stylesMap.put(c, new Style("#ffffff", null, "#ffffff"));
			}
		});

		return stylesMap;
	}

	private List<LandUseDetails> convertTolandUseCode(RuntimeEnvironment env, String businessId,
			List<LandUseDetailsExt> landUseCodesExt) {
		return landUseCodesExt.stream().map(record -> {
			var landUseDetails = new LandUseDetails();
			landUseDetails.setCode(record.getCode());
			landUseDetails.setDescription(record.getDescription());
			landUseDetails.setLandUseClass(
					new LandUseClass(
							record.getLandUseClassCode(),
							record.getLandUseClassDescription() != null ? record.getLandUseClassDescription() : record.getLandUseClassCode(),
							false,
							false));
			boolean isEditable = true;
			if (businessId != null) // support for old public API's
				isEditable = getLandCoverEditability(env, businessId,
						landUseDetails.getLandUseClass().getLandUseClassCode()) != LandCoverClassEditability.NOT_EDITABLE;
			landUseDetails.setIsEditable(isEditable);
			landUseDetails.setIsFavourite(record.getIsFavourite());
			landUseDetails.setDefaultHarvestDays(record.getDefaultHarvestDays());
			landUseDetails.setDefaultFromDate(record.getDefaultFromDate());
			return landUseDetails;
		}).collect(Collectors.toList());
	}

	// @Override
	// public MaxRowsResults<LandUseDetails> getLandUseCodesMaxRows(RuntimeEnvironment env, String businessId, List<String> landCoverCodes, String search,
	// List<String> favouriteLandUseCodes, LocalDate pointInTime) {
	// var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));
	// var ret = cropCodesSitiknowAppsDAO.maxRows(() -> cropCodesSitiknowAppsDAO.getLandUseCodes(/*lcc,*/ whereDateAtEndOfDay, search,
	// favouriteLandUseCodes.size() > 0 ? favouriteLandUseCodes : null,
	// env.getLocale().getLanguage()), MAX_ROWS);
	// ret.getRecords().forEach(landUse -> {
	// var landCoverCode = getLandCoverCode(env, landUse.getCode());
	// var landCovers = cropCodesSitiknowAppsDAO.getLandCoverDescriptions(List.of(landCoverCode));
	// var landCover = landCovers.size() > 0 ? landCovers.get(0) : new LandCover(landCoverCode, landCoverCode);
	// landUse.setLandUseClass(new LandUseClass(landCover.getLandCoverCode(), landCover.getLandCoverDescription(), false, false));
	// landUse.setIsEditable(
	// getLandCoverEditability(env, businessId, landUse.getLandUseClass().getLandUseClassCode()) != LandCoverClassEditability.NOT_EDITABLE);
	//
	// var harvestInfo = cropCodesSitiknowAppsDAO.getLandUseHarvestInfo(landUse.getCode(), whereDateAtEndOfDay.getYear());
	// if(harvestInfo != null) {
	// landUse.setDefaultHarvestDays(harvestInfo.getDefaultHarvestDays());
	// landUse.setDefaultFromDate(harvestInfo.getDefaultFromDate());
	// }
	// });
	// return ret;
	// }

	@Override
	public MaxRowsResults<LandUseDetails> getLandUseCodesMaxRows(RuntimeEnvironment env, String businessId, List<String> landCoverCodes, String search,
			List<String> favouriteLandUseCodes, LocalDate pointInTime, boolean ignoreLandUseCompatibility) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));
		MaxRowsResults<LandUseDetailsExt> retMaxRowsResults = cropCodesSitiknowAppsDAO
				.maxRows(() -> cropCodesSitiknowAppsDAO.getLandUseCodesExt(whereDateAtEndOfDay, search,
						favouriteLandUseCodes.size() > 0 ? favouriteLandUseCodes : null,
						env.getLocale().getLanguage(), null), MAX_ROWS);
		var ret = new MaxRowsResultsImpl<>(convertTolandUseCode(env, businessId, retMaxRowsResults.getRecords()), retMaxRowsResults.getHaveMore());
		return ret;
	}

	// @Override
	// public InfiniteListResults<LandUseDetails> getLandUseCodesInfinite(RuntimeEnvironment env, String businessId,
	// List<String> landCoverCodes, String search, List<String> favouriteLandUseCodes, LocalDate pointInTime, String nextKey) {
	// var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));
	// var ret = cropCodesSitiknowAppsDAO.infinite(() -> cropCodesSitiknowAppsDAO.getLandUseCodes(/*lcc,*/ whereDateAtEndOfDay, search,
	// favouriteLandUseCodes.size() > 0 ? favouriteLandUseCodes : null, env.getLocale().getLanguage()), nextKey, PAGE_SIZE);
	// ret.getRecords().forEach(landUse -> {
	// var landCoverCode = getLandCoverCode(env, landUse.getCode());
	// var landCovers = cropCodesSitiknowAppsDAO.getLandCoverDescriptions(List.of(landCoverCode));
	// var landCover = landCovers.size() > 0 ? landCovers.get(0) : new LandCover(landCoverCode, landCoverCode);
	// landUse.setLandUseClass(new LandUseClass(landCover.getLandCoverCode(), landCover.getLandCoverDescription(), false, false));
	// if (businessId == null) // support for old public API's
	// landUse.setIsEditable(true);
	// else
	// landUse.setIsEditable(
	// getLandCoverEditability(env, businessId, landUse.getLandUseClass().getLandUseClassCode()) != LandCoverClassEditability.NOT_EDITABLE);
	//
	// var harvestInfo = cropCodesSitiknowAppsDAO.getLandUseHarvestInfo(landUse.getCode(), whereDateAtEndOfDay.getYear());
	// if(harvestInfo != null) {
	// landUse.setDefaultHarvestDays(harvestInfo.getDefaultHarvestDays());
	// landUse.setDefaultFromDate(harvestInfo.getDefaultFromDate());
	// }
	// });
	// return ret;
	// }

	@Override
	public InfiniteListResults<LandUseDetails> getLandUseCodesInfinite(RuntimeEnvironment env, String businessId,
			List<String> landCoverCodes, String search, List<String> favouriteLandUseCodes, LocalDate pointInTime,
			boolean ignoreLandUseCompatibility, String nextKey) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));
		InfiniteListResults<LandUseDetailsExt> retInfiniteListResults = cropCodesSitiknowAppsDAO
				.infinite(() -> cropCodesSitiknowAppsDAO.getLandUseCodesExt(whereDateAtEndOfDay, search,
						favouriteLandUseCodes.size() > 0 ? favouriteLandUseCodes : null,
						env.getLocale().getLanguage(), null), nextKey, PAGE_SIZE);
		var ret = new InfiniteListResultsImpl<>(convertTolandUseCode(env, businessId, retInfiniteListResults.getRecords()),
				retInfiniteListResults.getNextKey());
		return ret;
	}

	@Override
	public List<String> getLandUseCodesByLandCoverCode(RuntimeEnvironment env, String landCoverCode) {
		return cropCodesSitiknowAppsDAO.getLandUseCodesList(landCoverCode);
	}

	@Override
	/**
	 * For AVEPA plugin the transcodification is over the campaign change. It use the table <b>cropplan_trans_land_uses</b> to get the eventually new code for
	 * the new campaign Table structure: <br/>
	 * 
	 * <pre>
	 * -- create the table 
	 * create table cropplan_trans_land_uses(
	 *   start_campaign number(4,0) not null, 
	 *   previous_code varchar2(100) not null, 
	 *   current_code varchar2(100) not null, 
	 *   dt_insert timestamp not null, 
	 *   dt_delete timestamp not null, 
	 *   user_insert varchar2(100) not null, 
	 *   user_delete varchar2(100)
	 * );
	 * -- index 
	 * create unique index cropplan_trans_land_uses_idx on cropplan_trans_land_uses(start_campaign, previous_code);
	 * 
	 * -- title on table and column
	 * comment on table cropplan_trans_land_uses is 'CropPlan transcoding table for landuse code changes in changing campaigns';
	 * comment on column cropplan_trans_land_uses.start_campaign is 'Campaign year for the transcode';
	 * comment on column cropplan_trans_land_uses.previous_code  is 'old landuse code reference';
	 * comment on column cropplan_trans_land_uses.current_code   is 'new landuse code to use';
	 * comment on column cropplan_trans_land_uses.dt_insert      is 'The database''s timestamp when this record was created';
	 * comment on column cropplan_trans_land_uses.dt_delete      is 'The database''s timestamp when this record was logically deleted';
	 * comment on column cropplan_trans_land_uses.user_insert    is 'The user id which inserted this record';
	 * comment on column cropplan_trans_land_uses.user_delete    is 'The user id which logically deleted this record';
	 * </pre>
	 */
	public Optional<String> transcodeLandUseCode(RuntimeEnvironment env, String code, String landCoverCode, String businessId, LocalDate pointInTime) {

		String landUseCode = cropCodesSitiknowAppsDAO.transcodeLandUseCode(code, pointInTime.getYear());

		return Optional.ofNullable(landUseCode);

	}

	// @Override
	// public Optional<LandUseDetails> getLandUseCode(RuntimeEnvironment env, String code, String businessId, LocalDate pointInTime) {
	// var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));
	// var landUse = cropCodesSitiknowAppsDAO.getLandUseCode(code, whereDateAtEndOfDay, env.getLocale().getLanguage());
	// if (!landUse.isEmpty()) {
	// var landCoverCode = getLandCoverCode(env, code);
	// var landCovers = cropCodesSitiknowAppsDAO.getLandCoverDescriptions(List.of(landCoverCode));
	// var landCover = landCovers.size() > 0 ? landCovers.get(0) : new LandCover(landCoverCode, landCoverCode);
	// landUse.get().setLandUseClass(new LandUseClass(landCover.getLandCoverCode(), landCover.getLandCoverDescription(), false, false));
	// landUse.get().setIsEditable(
	// getLandCoverEditability(env, businessId, landUse.get().getLandUseClass().getLandUseClassCode()) != LandCoverClassEditability.NOT_EDITABLE);
	//
	// var harvestInfo = cropCodesSitiknowAppsDAO.getLandUseHarvestInfo(code, whereDateAtEndOfDay.getYear());
	// if(harvestInfo != null) {
	// landUse.get().setDefaultHarvestDays(harvestInfo.getDefaultHarvestDays());
	// landUse.get().setDefaultFromDate(harvestInfo.getDefaultFromDate());
	// }
	// }
	// return landUse;
	// }

	@Override
	public Optional<LandUseDetails> getLandUseCode(RuntimeEnvironment env, String code, String businessId, LocalDate pointInTime) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));
		MaxRowsResults<LandUseDetailsExt> landUseCodesExt = cropCodesSitiknowAppsDAO
				.maxRows(() -> cropCodesSitiknowAppsDAO.getLandUseCodesExt(whereDateAtEndOfDay, null, null, env.getLocale().getLanguage(), code), 1);
		List<LandUseDetails> landUseDetails = convertTolandUseCode(env, businessId, landUseCodesExt.getRecords());
		return Optional.ofNullable(!landUseDetails.isEmpty() ? landUseDetails.get(0) : null);
	}

	@Override
	public Map<String, String> getLandCoverDescriptions(RuntimeEnvironment env, List<String> codes) {
		List<LandCover> landCovers = cropCodesSitiknowAppsDAO.getLandCoverDescriptions(codes);
		return landCovers.stream()
				.collect(toMap(LandCover::getLandCoverCode, LandCover::getLandCoverDescription));
	}

	@Override
	public Map<String, Style> getLandCoverStyles(RuntimeEnvironment env, List<String> codes) {
		var styles = cropCodesSitiknowAppsDAO.getLandCoverStyles(codes);
		styles.forEach(r -> {
			r.setFillColor(StyleColorUtils.getColorRGBFromDefaultPalette(r.getFillColor()));
			r.setBorderColor(StyleColorUtils.getColorRGBFromDefaultPalette(r.getBorderColor()));
		});

		Map<String, Style> stylesMap = styles.stream().collect(toMap(StyleWithCode::getCode, Function.identity()));
		codes.forEach(c -> {
			if (stylesMap.get(c) == null)
				stylesMap.put(c, getDefaultStyle(env));
		});

		return stylesMap;
	}

	@Override
	public Style getDefaultStyle(RuntimeEnvironment env) {
		return new Style("#ffffff00", "stroke", "#ffffff");
	}

	@Override
	public boolean isLandUseCompatible(RuntimeEnvironment env, String landUseCode, String landCoverCode) {
		return LandCoverUtils.isLandUseCompatible(env, cropCodesSitiknowAppsDAO, landUseCode, landCoverCode);
	}

	@Override
	public LandCoverClassEditability getLandCoverEditability(RuntimeEnvironment env, String businessId, String landCoverCode) {
		return LandCoverClassEditability.EDITABLE;
	}

	@Override
	public List<LandCoverFilter> getLandCoverFilters(RuntimeEnvironment env) {
		return new ArrayList<>();
	}

	@Override
	public String getLandCoverCode(RuntimeEnvironment env, String landUseCode) {
		return cropCodesSitiknowAppsDAO.getLandCoverCode(landUseCode);
	}

	@Override
	public List<String> getLandCoversOnWhichTheLandCoverIsCompatible(RuntimeEnvironment env, String landCoverCode) {
		return cropCodesSitiknowAppsDAO.getLandCoversOnWhichTheLandCoverIsCompatible(landCoverCode);
	}

	@Override
	public boolean canAggregate(RuntimeEnvironment env, AbsoluteDate pointInTime, Collection<Declaration> plot1, Collection<Declaration> plot2) {

		List<Set<DeclAggregationKey>> groupedDeclarationKeys1 = getGroupedDeclarationKeys(pointInTime, plot1);
		List<Set<DeclAggregationKey>> groupedDeclarationKeys2 = getGroupedDeclarationKeys(pointInTime, plot2);

		return groupedDeclarationKeys1.equals(groupedDeclarationKeys2);
	}

	private List<Set<DeclAggregationKey>> getGroupedDeclarationKeys(AbsoluteDate pointInTime, Collection<Declaration> plotDeclarations) {
		List<Declaration> sortedDeclarations = new ArrayList<>(plotDeclarations);
		
		sortedDeclarations.sort(Comparator.comparing((Declaration d) -> d.getFromDate().toLocalDate()).thenComparing(d -> d.getToDate().toLocalDate()));

		List<Set<DeclAggregationKey>> groupedDeclarations = new ArrayList<>();

		Set<DeclAggregationKey> group1 = new HashSet<>();
		Set<DeclAggregationKey> group2 = new HashSet<>();

		for (Declaration declaration : sortedDeclarations) {
			if(!pointInTime.toLocalDate().isBefore(declaration.getFromDate().toLocalDate())) {
				group1.add(DeclAggregationKey.fromDeclaration(declaration));
			} else if (group2.isEmpty()) {
				group2.add(DeclAggregationKey.fromDeclaration(declaration));
			} else {
				break;
			}
		}

		groupedDeclarations.add(group1);
		groupedDeclarations.add(group2);

		return groupedDeclarations;
	}

	@Override
	public Set<String> getDefaultLandUseCodesExcludedFromAggregation(RuntimeEnvironment env) {
		return aggregationExcludedLandUseCodesCache.get("aggregation_excluded_landusecodes.txt");
	}

	private Set<String> readLines(String path) throws IOException {
		try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(path);
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
			return reader.lines().filter(StringUtils::isNotBlank).collect(Collectors.toSet());
		}
	}

	@Override
	public String getCropPlanType() {
		return "*";
	}



}
