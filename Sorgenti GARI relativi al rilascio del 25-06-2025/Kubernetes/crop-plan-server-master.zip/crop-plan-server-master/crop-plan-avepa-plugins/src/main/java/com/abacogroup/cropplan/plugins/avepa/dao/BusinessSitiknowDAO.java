package com.abacogroup.cropplan.plugins.avepa.dao;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import com.abacogroup.cropplan.sdk.model.business.Business;
import com.abacogroup.jdbi.EnhancedSqlObject;

public interface BusinessSitiknowDAO extends EnhancedSqlObject
{

	@SqlQuery("select subject_id as businessId,"
		+ "           fiscal_code as code,"
		+ "      	  full_name as description"
		+ " 	 from subj_details"
		+ "     where subject_id = :businessId"
		+ "       and §current_timestamp§ between dt_insert and dt_delete")
	@RegisterBeanMapper(Business.class)
	public Business getBusiness(@Bind("businessId") String businessId);

	@SqlQuery("select user_custom.get_single_pk_cuaa(:userId) from dual")
	public Long getSinglePkCuaa(@Bind("userId") String userId);

	@SqlQuery("select sd.subject_id as businessId,"
		+ "           sd.fiscal_code as code,"
		+ "      	  sd.full_name as description"
		+ " 	 from subj_details sd"
		+ "     where §current_timestamp§ between sd.dt_insert and sd.dt_delete"
		+ "       and :onlyEmpowered <> 0"
		+ "       and exists (select 1 "
		+ "                     from prox_proxies_subj ps, prox_proxies_users pu"
		+ "                    where ps.subj_entity_id = sd.subject_id"
		+ "                      and ps.proxy_id = pu.proxy_id"
		+ "                      and §current_timestamp§ between ps.dt_start and ps.dt_end"
		+ "                      and pu.user_id = :userId)"
		+ "       and (upper(sd.full_name) like '%'||:search||'%' or upper(sd.fiscal_code) like '%'||:search||'%')"
		+ " union all"
		+ "    select sd.subject_id as businessId,"
		+ "           sd.fiscal_code as code,"
		+ "           sd.full_name as description"
		+ "      from subj_details sd"
		+ "     where §current_timestamp§ between sd.dt_insert and sd.dt_delete"
		+ "       and :onlyEmpowered = 0"
		+ "       and (:search is null or upper(sd.full_name) like '%'||upper(:search)||'%' or upper(sd.fiscal_code) like '%'||upper(:search)||'%')"
		+ "  order by description, code, businessId")
	@RegisterBeanMapper(Business.class)
	public ResultIterator<Business> getBusinesses(@Bind("userId") String userId,
		@Bind("onlyEmpowered") Boolean onlyEmpowered, @Bind("search") String search);

}
