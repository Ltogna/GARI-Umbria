package com.abacogroup.cropplan.plugins.avepa.dao;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.Define;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import com.abacogroup.jdbi.EnhancedSqlObject;

public interface AuthSitiknowAppsDAO extends EnhancedSqlObject
{
	@SqlQuery("select <businessLockedFunction>(:userId, :businessId) from dual")
	public String checkBusinessLocked(@Define("businessLockedFunction") String businessLockedFunction,
		@Bind("userId") String userId, @Bind("businessId") String businessId);

	@SqlQuery("select param_val from app_params where param_name = 'FARMER_CANWORK_PLSQL_FUNCTION'")
	public String getBusinessLockedFunction();
}
