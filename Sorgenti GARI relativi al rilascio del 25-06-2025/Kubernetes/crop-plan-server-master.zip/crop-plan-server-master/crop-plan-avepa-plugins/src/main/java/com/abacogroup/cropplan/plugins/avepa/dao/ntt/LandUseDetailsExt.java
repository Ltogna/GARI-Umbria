package com.abacogroup.cropplan.plugins.avepa.dao.ntt;

import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Land use data with details")
public class LandUseDetailsExt extends LandUse {
	
	@Schema(description = "Land use default harvest days")
	private Integer defaultHarvestDays;
	
	@Schema(description = "The land use class code")
	private String landUseClassCode;
	
	@Schema(description = "Land use class description")
	private String landUseClassDescription;

	@Schema(description = "True if the land cover class is editable")
	public Boolean isEditable;
	
	@Schema(description = "True if the land use is favourite")
	public Boolean isFavourite;

	@Schema(description = "Default from date", format = "yyyyMMdd", example = "20211231")
	private String defaultFromDate;

}
