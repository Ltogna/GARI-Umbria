package com.abacogroup.cropplan.plugins.avepa.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.cropplan.plugins.avepa.dao.ntt.GisInfoData;
import com.abacogroup.jdbi.EnhancedSqlObject;

public interface LayersSitiDAO extends EnhancedSqlObject
{
	
	@SqlQuery("SELECT (sp.foglio||'-'||sp.particella||decode(trim(sp.sub), '', '', '/'||sp.sub)) AS title, " +
			"         sp.AREA_PART AS area, " +
			"         (sp.particella||decode(trim(sp.sub), '', '', '/'||sp.sub)) AS parcel, " +
			"         sp.foglio AS sheet, " +
			"         SDO_GEOM.SDO_MBR(sp.shape) AS mbr " +
			"    FROM SITIPART sp, TPARTICELLE_COND pc " +
			"   WHERE sp.cod_nazionale = :domainZoneId " +
			"     AND §geom_have_interactions(sp.shape, :touchingGeometry)§" +
			"     AND pc.se_row_id = sp.SE_ROW_ID " +
			"     AND pc.id_soggetto = :businessId" + 
			"     AND §current_timestamp§ BETWEEN pc.DT_INSERT AND pc.DT_DELETE " +
			"     AND :pointInTime between pc.data_inizio_conduzione and pc.data_fine_conduzione")
	@RegisterBeanMapper(GisInfoData.class)
	public List<GisInfoData> getParcelsGisInfoData(
			@Bind("domainZoneId") String domainZoneId,
			@Bind("businessId") String businessId,
			@Bind("touchingGeometry") Geometry touchingGeometry,
			@Bind("pointInTime") LocalDateTime pointInTime);

	@SqlQuery("select p.epsg_code from cata_sezioni s, dbmap_proj p where s.cod_sezione = :domainZoneId and p.projection_id = s.projection_id")
	public String getDomainZoneSRS(@Bind("domainZoneId") String domainZoneId);

}
