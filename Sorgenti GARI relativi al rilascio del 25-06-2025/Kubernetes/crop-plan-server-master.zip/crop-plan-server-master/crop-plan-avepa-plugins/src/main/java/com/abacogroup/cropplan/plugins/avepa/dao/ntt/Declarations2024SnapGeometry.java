package com.abacogroup.cropplan.plugins.avepa.dao.ntt;

import com.abacogroup.cropplan.sdk.model.domain.SnapElements.SnapGeometry;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor	
@EqualsAndHashCode(callSuper = true)
public class Declarations2024SnapGeometry extends SnapGeometry {
    private String landUseCode;
	private String landUseDescription;
	private Integer declaredArea;
}
