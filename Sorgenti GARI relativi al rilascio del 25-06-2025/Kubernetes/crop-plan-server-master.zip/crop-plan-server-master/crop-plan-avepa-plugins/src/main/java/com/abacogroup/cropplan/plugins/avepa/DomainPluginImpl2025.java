package com.abacogroup.cropplan.plugins.avepa;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Polygonal;

import com.abacogroup.cropplan.plugins.avepa.dao.CropPlanDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.DomainSitiDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.DomainSitiknow2025DAO;
import com.abacogroup.cropplan.plugins.avepa.dao.DomainSitiknow2025DAO.FutureParcelIntersectionDates;
import com.abacogroup.cropplan.plugins.avepa.dao.DomainSitiknowAppsDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.CataloghiLayers2025;
import com.abacogroup.cropplan.plugins.avepa.utils.CataloghiLayersUtils;
import com.abacogroup.cropplan.sdk.model.domain.CadastralParcelData;
import com.abacogroup.cropplan.sdk.model.domain.CadastralParcelOverlapData;
import com.abacogroup.cropplan.sdk.model.domain.DomainZoneGeometry;
import com.abacogroup.cropplan.sdk.model.domain.HoldingArea;
import com.abacogroup.cropplan.sdk.model.domain.Parcel;
import com.abacogroup.cropplan.sdk.model.domain.ParcelData;
import com.abacogroup.cropplan.sdk.model.domain.ParcelDescription;
import com.abacogroup.cropplan.sdk.model.domain.ParcelGeometry;
import com.abacogroup.cropplan.sdk.model.domain.Place;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements.SnapElementType;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements.SnapGeometry;
import com.abacogroup.cropplan.sdk.spi.DomainPlugin;
import com.abacogroup.cropplan.sdk.support.DomainDataSupport;
import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.MaxRowsResults;
import com.abacogroup.jdbi.paging.impl.MaxRowsResultsImpl;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.google.common.collect.Iterators;
import com.google.common.collect.UnmodifiableIterator;

public class DomainPluginImpl2025 implements DomainPlugin, InitializablePlugin {
	private static final String JDBI_CROP_PLAN = "mainDB";
	private static final String JDBI_NAME_SITI = "dbSiti";
	private static final String JDBI_NAME_SITIKNOW = "dbSitiknow";
	private static final String JDBI_NAME_SITIKNOW_APPS = "dbSitiknowApps";

	private static final int MAX_ROWS = 50;
	private static final int PAGE_SIZE = 50;

	private static final String P_CODE_WMSLAY = "WMSLAY";
	private static final String S_CODE_WMSLAY_CADPARCELS = "CADPARCELS";
	public static final String SNAP_EL_TYPE_SITISUOLO = "SITISUOLO";
	public static final String SNAP_EL_TYPE_CADPARCEL = "CADPARCEL";

	private DomainSitiDAO domainSitiDAO;
	private DomainSitiknow2025DAO domainSitiknowDAO;
	private DomainSitiknowAppsDAO domainSitiknowAppsDAO;
	// private BusinessSitiknowDAO businessSitiknowDAO;
	private CropPlanDAO cropPlanDAO;

	@Override
	public void initialize(PluginsEnvironment env) {
		var jdbiCropPlan = env.getJdbi(JDBI_CROP_PLAN);
		if (jdbiCropPlan == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_CROP_PLAN);

		cropPlanDAO = jdbiCropPlan.onDemand(CropPlanDAO.class);

		var jdbiSiti = env.getJdbi(JDBI_NAME_SITI);
		if (jdbiSiti == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITI);

		domainSitiDAO = jdbiSiti.onDemand(DomainSitiDAO.class);

		var jdbiSitiknow = env.getJdbi(JDBI_NAME_SITIKNOW);
		if (jdbiSitiknow == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITIKNOW);

		domainSitiknowDAO = jdbiSitiknow.onDemand(DomainSitiknow2025DAO.class);
		// businessSitiknowDAO = jdbiSitiknow.onDemand(BusinessSitiknowDAO.class);

		var jdbiSitiknowApps = env.getJdbi(JDBI_NAME_SITIKNOW_APPS);
		if (jdbiSitiknowApps == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITIKNOW_APPS);

		domainSitiknowAppsDAO = jdbiSitiknowApps.onDemand(DomainSitiknowAppsDAO.class);
	}

	@Override
	public HoldingArea getHoldingArea(RuntimeEnvironment env, String businessId, LocalDate pointInTime) {
		return domainSitiknowDAO.getHoldingArea(businessId, pointInTime);
	}

	@Override
	public MaxRowsResults<DomainZoneGeometry> getDomainZonesMaxRows(RuntimeEnvironment env, String businessId,
			LocalDate pointInTime, String search, boolean filterByBusiness) {

		if (filterByBusiness) {
			try {
				return domainSitiknowDAO.maxRows(
						() -> domainSitiknowDAO.getDomainZonesByBusinessId(businessId, pointInTime, search),
						MAX_ROWS);
			} catch (RuntimeException e) {
				return domainSitiknowDAO.maxRows(
						() -> domainSitiknowDAO.getDomainZonesByBusinessIdNoSdoAggrMbr(businessId, pointInTime, search),
						MAX_ROWS);
			}
		} else {
			try {
				return domainSitiknowDAO.maxRows(() -> domainSitiknowDAO.getDomainZones(businessId, pointInTime, search),
						MAX_ROWS);
			} catch (RuntimeException e) {
				return domainSitiknowDAO.maxRows(() -> domainSitiknowDAO.getDomainZonesNoSdoAggrMbr(businessId, pointInTime, search),
						MAX_ROWS);
			}
		}
	}

	@Override
	public InfiniteListResults<DomainZoneGeometry> getDomainZonesInfinite(RuntimeEnvironment env, String businessId,
			LocalDate pointInTime, String search, boolean filterByBusiness, String nextKey) {

		if (filterByBusiness) {
			try {
				return domainSitiknowDAO.infinite(
						() -> domainSitiknowDAO.getDomainZonesByBusinessId(businessId, pointInTime, search),
						nextKey,
						PAGE_SIZE);
			} catch (RuntimeException e) {
				return domainSitiknowDAO.infinite(
						() -> domainSitiknowDAO.getDomainZonesByBusinessIdNoSdoAggrMbr(businessId, pointInTime, search),
						nextKey,
						PAGE_SIZE);
			}
		} else {
			try {
				return domainSitiknowDAO.infinite(() -> domainSitiknowDAO.getDomainZones(businessId, pointInTime, search),
						nextKey,
						PAGE_SIZE);
			} catch (RuntimeException e) {
				return domainSitiknowDAO.infinite(() -> domainSitiknowDAO.getDomainZonesNoSdoAggrMbr(businessId, pointInTime, search),
						nextKey,
						PAGE_SIZE);
			}
		}
	}
	
	@Override
	public MaxRowsResults<DomainZoneGeometry> getDomainZonesByIdsMaxRows(RuntimeEnvironment env, String businessId, String search, List<String> domainZoneIds) {
		return domainSitiknowDAO.maxRows(
				() -> domainSitiknowDAO.getDomainZonesByIds(search, domainZoneIds),
				MAX_ROWS);
	}
	
	@Override
	public InfiniteListResults<DomainZoneGeometry> getDomainZonesByIdsInfinite(RuntimeEnvironment env, String businessId, String search,
			List<String> domainZoneIds, String nextKey) {
		return domainSitiknowDAO.infinite(() -> domainSitiknowDAO.getDomainZonesByIds(search, domainZoneIds),
				nextKey,
				PAGE_SIZE);
	}

	@Override
	public DomainZoneGeometry getDomainZone(RuntimeEnvironment env, String businessId,
			LocalDate pointInTime, String domainZoneId) {
		try {
			return domainSitiknowDAO.getDomainZone(businessId, pointInTime, domainZoneId);
		} catch (RuntimeException e) {
			return domainSitiknowDAO.getDomainZoneNoSdoAggrMbr(businessId, pointInTime, domainZoneId);
		}
	}
	
	@Override
	public DomainZoneGeometry getDomainZoneByCode(RuntimeEnvironment env, String businessId,
			LocalDate pointInTime, String domainZoneCode) {
		return getDomainZone(env, businessId, pointInTime, domainZoneCode);
	}

	@Override
	public String getDomainZoneDescription(RuntimeEnvironment env, LocalDate pointInTime, String domainZoneId) {
		return domainSitiknowDAO.getDomainZoneDescription(pointInTime, domainZoneId);
	}

	@Override
	public HoldingArea getHoldingAreaByDomainZone(RuntimeEnvironment env, String businessId,
			String domainZoneId, LocalDate pointInTime) {
		return domainSitiknowDAO.getHoldingAreaByDomainZones(businessId, domainZoneId, pointInTime);
	}

	@Override
	public SnapElements getSnapGeometries(RuntimeEnvironment env, String businessId, String domainZoneId,
			List<String> snapElementTypes, LocalDate pointInTime) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));

		var types = new ArrayList<SnapElementType>();
		var geoms = new ArrayList<SnapGeometry>();
		var ret = new SnapElements();
		ret.setTypes(types);
		ret.setGeometries(geoms);

		if (cropPlanDAO.disableSnapGeometries("CROPPLAN_2025", env.getTenantId()) > 0) {
			return ret;
		}

		SnapElementType type;

		final Geometry touchingGeometry = domainSitiknowDAO.getDomainParcelsGeom(businessId, pointInTime, domainZoneId);

		// SITISUOLO
		if (null == snapElementTypes || snapElementTypes.contains(SNAP_EL_TYPE_SITISUOLO)) {
			type = new SnapElementType();
			type.setType(SNAP_EL_TYPE_SITISUOLO);
			type.setDescription("Uso suolo GIS");
			types.add(type);
			domainSitiDAO.getSitiSuoloSnapGeometries(touchingGeometry, sg -> {
				if (sg.getGeom() != null) {
					geoms.add(CataloghiLayersUtils.clipIfNecessary(sg, touchingGeometry));
				}
			});
		}
		
		// CADPARCEL
		if (null == snapElementTypes || snapElementTypes.contains(SNAP_EL_TYPE_CADPARCEL)) {
			type = new SnapElementType();
			type.setType(SNAP_EL_TYPE_CADPARCEL);
			String intlnCadParcels = domainSitiknowDAO.getDecodedIntlnDescription(P_CODE_WMSLAY, S_CODE_WMSLAY_CADPARCELS, env.getLocale().getLanguage());
			type.setDescription(intlnCadParcels != null ? intlnCadParcels : S_CODE_WMSLAY_CADPARCELS);
			types.add(type);
			geoms.addAll(domainSitiDAO.getCadastralParcelsSnapGeometries(businessId, whereDateAtEndOfDay, domainZoneId, touchingGeometry.getEnvelope()));
		}
		
		/* CATALOGHI */
		for (var cl : CataloghiLayers2025.getCataloghiLayers(domainSitiDAO, touchingGeometry)) {
			if (cl.isSnappable() && (null == snapElementTypes || snapElementTypes.contains(cl.getLayerCode()))) {
				type = new SnapElementType();
				type.setType(cl.getLayerCode());
				type.setDescription(cl.getLayerDescription());
				types.add(type);
				geoms.addAll(cl.getSnapGeometry());
			}
		}
		
		return ret;
	}

	@Override
	public Map<String, ParcelDescription> getParcelsDescription(RuntimeEnvironment env, String businessId,
			LocalDate pointInTime, List<String> parcelCodes) {
		List<ParcelDescription> parcelsDescription = new ArrayList<>();
		
		UnmodifiableIterator<List<String>> partitions = Iterators.partition(parcelCodes.iterator(), 666);
		partitions.forEachRemaining(partition -> parcelsDescription.addAll(domainSitiknowDAO.getParcelsDescription(businessId, partition)));
		
		Map<String, ParcelDescription> pds = parcelsDescription.stream()
				.collect(toMap(ParcelDescription::getCode, pd -> pd));
		
		if (pds.keySet().size() != parcelCodes.size()) {
			List<String> parcelCodesNotFound = parcelCodes.stream()
				.filter(pc -> pds.get(pc) == null)
				.collect(toList());
			
			partitions = Iterators.partition(parcelCodesNotFound.iterator(), 666);
			partitions.forEachRemaining(partition -> {
				List<ParcelDescription> parcelsDescriptionNotFound = domainSitiknowDAO.getParcelsDescriptionFromIsolaNprId(businessId, partition);
				Map<String, List<ParcelDescription>> mapParcelsDescriptionNotFound = parcelsDescriptionNotFound.stream()
					.collect(groupingBy(ParcelDescription::getCode));
				parcelsDescriptionNotFound = mapParcelsDescriptionNotFound.entrySet().stream()
					.map(e -> e.getValue().get(0))
					.collect(toList());
				parcelsDescription.addAll(parcelsDescriptionNotFound);
			});
			
			return parcelsDescription.stream()
					.collect(toMap(ParcelDescription::getCode, pd -> pd));
		} else  
			return pds;
	}

	@Override
	public Map<String, Polygonal> getParcels(RuntimeEnvironment env, String businessId, String domainZoneId,
			LocalDate pointInTime, Geometry touchingGeometry) {
		List<ParcelGeometry> parcelsGeometry = domainSitiknowDAO.getParcels(businessId, pointInTime, domainZoneId, touchingGeometry);
		
		return parcelsGeometry.stream()
				.collect(toMap(ParcelGeometry::getCode, pg -> (Polygonal) pg.getGeom()));
	}
	
	@Override
	public List<Parcel> getAllParcels(RuntimeEnvironment env, String businessId, String domainZoneId, LocalDate pointInTime, Geometry touchingGeometry) {
		return domainSitiknowDAO.getAllParcelsByGeometry(businessId, domainZoneId, pointInTime, touchingGeometry);
	}

	@Override
	public List<Parcel> getCopyCampaignParcels(RuntimeEnvironment env, String businessId, String domainZoneId, LocalDate pointInTime) {
		return domainSitiknowDAO.getAllParcels(businessId, domainZoneId, pointInTime);
	}

	@Override
	public List<Parcel> getParcelsByParcelCodes(RuntimeEnvironment env, String businessId, String domainZoneId, List<String> parcelCodes,
			LocalDate pointInTime) {
		List<Parcel> parcels = new ArrayList<>();

		UnmodifiableIterator<List<String>> partitions = Iterators.partition(parcelCodes.iterator(), 500);
		partitions.forEachRemaining(
				partition -> parcels.addAll(domainSitiknowDAO.getParcelsByParcelCodes(businessId, domainZoneId, partition)));

		return parcels.stream()
				.filter(p -> p.getGeom() != null)
				.collect(toList());
	}

	@Override
	public List<LocalDate> getFutureParcelsIntersections(RuntimeEnvironment env, String businessId,
			String domainZoneId, LocalDate pointInTime, Geometry touchingGeometry) {

		List<FutureParcelIntersectionDates> intersections = domainSitiknowDAO.getFutureParcelsIntersections(businessId,
				pointInTime, domainZoneId, touchingGeometry);

		return intersections.stream()
				.flatMap(i -> Stream.of(i.getD1(), i.getD2()))
				.distinct()
				.filter(i -> i.isAfter(pointInTime)).filter(i -> i.isBefore(LocalDate.of(9999, 12, 31)))
				.collect(toList());
	}

	@Override
	public String getParcelLandCoverCode(RuntimeEnvironment env, String businessId, String parcelCode,
			LocalDate pointInTime) {
		return null;
	}

	@Override
	public Geometry getMBROverview(RuntimeEnvironment env, String businessId, List<String> parcelCodes, LocalDate pointInTime) {
		if (!parcelCodes.isEmpty()) {
			var geoms = domainSitiknowDAO.getParcelsMbr(businessId, parcelCodes);
			if (!geoms.isEmpty())
				return Utils.getUnion(geoms).getEnvelope();
		}
		return null;
	}

	@Override
	public MaxRowsResults<Place> getPlaces(RuntimeEnvironment env, String businessId, String domainZoneId, String search) {
		return new MaxRowsResultsImpl<>(new ArrayList<>(), false);
	}

	@Override
	public InfiniteListResults<ParcelData> getParcelsData(RuntimeEnvironment env, String businessId, String domainZoneId, 
			LocalDate pointInTime, String nextKey, DomainDataSupport support) {
		
		InfiniteListResults<ParcelData> parcelsDataInfiniteList = domainSitiknowDAO.infinite(
				() -> domainSitiknowDAO.getParcelsData(businessId, domainZoneId, null, pointInTime), 
				nextKey, 
				PAGE_SIZE);
		
		Map<String, List<ParcelData>> parcelsDataByParcelCode = parcelsDataInfiniteList.getRecords().stream()
				.collect(groupingBy(ParcelData::getParcelCode));
		domainSitiknowDAO.getParcelsDescription(businessId, new ArrayList<>(parcelsDataByParcelCode.keySet())).forEach(pd ->
			parcelsDataByParcelCode.get(pd.getCode()).forEach(p -> 
				p.setDescription(pd.getDescription())
			)
		);	
		
		parcelsDataInfiniteList.getRecords().forEach(element ->
			element.setLandCovers(domainSitiknowDAO.getLandCovers(element.getGeom(), pointInTime))
		);
		
		return parcelsDataInfiniteList;
	}

	@Override
	public InfiniteListResults<CadastralParcelData> getCadastralParcelsData(RuntimeEnvironment env, String businessId, String domainZoneId,
			LocalDate pointInTime, String nextKey) {
		
		final LocalDateTime whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));
		return domainSitiDAO.infinite(
				() -> domainSitiDAO.getCadastralParcelData(businessId, domainZoneId, whereDateAtEndOfDay),
				nextKey,
				PAGE_SIZE);
	}
	
	@Override
	public InfiniteListResults<CadastralParcelOverlapData> getCadastralParcelsOverlapsData(RuntimeEnvironment env, String businessId, String domainZoneId,
			LocalDate pointInTime, String nextKey) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));
		var srs = domainSitiknowDAO.getDomainZone(businessId, pointInTime, domainZoneId).getSrs();
		
		var councilSectorId = domainSitiknowAppsDAO.getCouncilSectorId(domainZoneId, whereDateAtEndOfDay);
		InfiniteListResults<CadastralParcelOverlapData> parcelsOverlapsDataInfiniteList = domainSitiknowAppsDAO.infinite(
				() -> domainSitiknowAppsDAO.getCadastralParcelsOverlapsData(businessId, councilSectorId, whereDateAtEndOfDay), 
				nextKey, 
				PAGE_SIZE);
		parcelsOverlapsDataInfiniteList.getRecords().forEach(p -> {
			p.setSrs(srs);
		});
		return parcelsOverlapsDataInfiniteList;
	}

	@Override
	public boolean intersectedParcelCodesChanged(RuntimeEnvironment env, String businessId, LocalDate pointInTime,
			List<String> oldIntersectedParcelCodes, List<String> newIntersectedParcelCodes) {
		boolean haveSameSize = oldIntersectedParcelCodes.size() == newIntersectedParcelCodes.size();
		boolean haveSameElements = oldIntersectedParcelCodes.stream()
				.filter(pi -> !newIntersectedParcelCodes.contains(pi))
				.collect(toList())
				.isEmpty();
		return !haveSameSize || !haveSameElements;
	}
	
	@Override
	public String getCropPlanType() {
		return "CROPPLAN_2025";
	}

}
