package com.abacogroup.cropplan.plugins.avepa.dao.ntt;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FarmerAdditionalLayer
{
	@NotEmpty
	private String code;

	@NotEmpty
	private String layerType;

	@NotEmpty
	private String description;

	@NotEmpty
	private String url;

	@NotEmpty
	private Boolean flVisible;

	@NotEmpty
	private String layer;

	@NotEmpty
	private String srs;

	@NotEmpty
	private String format;

	@NotEmpty
	private String bgcolor;

	@NotEmpty
	private Boolean flTransparent;

	private String contextFunction;

	private Double maxPixelVal;
}
