package com.abacogroup.cropplan.plugins.avepa.dao;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.function.Consumer;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.cropplan.plugins.avepa.dao.ntt.GisInfoData;
import com.abacogroup.cropplan.sdk.model.domain.DomainZoneGeometry;
import com.abacogroup.cropplan.sdk.model.domain.HoldingArea;
import com.abacogroup.cropplan.sdk.model.domain.LandCover;
import com.abacogroup.cropplan.sdk.model.domain.Parcel;
import com.abacogroup.cropplan.sdk.model.domain.ParcelData;
import com.abacogroup.cropplan.sdk.model.domain.ParcelDescription;
import com.abacogroup.cropplan.sdk.model.domain.ParcelGeometry;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements.SnapGeometry;
import com.abacogroup.jdbi.EnhancedSqlObject;

import lombok.Data;

public interface DomainSitiknowDAO extends EnhancedSqlObject
{
	@SqlQuery("SELECT sum(round(npr.area_intersezione)) as areaSqm\n"
			+ "  FROM siti.tisole_npr npr, siti.tisole_cond cond\n"
			+ " WHERE sysdate between npr.dt_insert and npr.dt_delete\n"
			+ "   AND :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)\n"
			+ "   AND cond.cod_isola = npr.cod_isola\n"
			+ "   AND cond.id_soggetto = :businessId\n"
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete\n"
			+ "   AND :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)")
	@RegisterBeanMapper(HoldingArea.class)
	public HoldingArea getHoldingArea(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDateTime pointInTime);

	@SqlQuery("SELECT sum(round(npr.area_intersezione)) as areaSqm\n"
			+ "  FROM siti.tisole_npr npr, siti.tisole_cond cond\n"
			+ " WHERE sysdate between npr.dt_insert and npr.dt_delete\n"
			+ "   AND :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)\n"
			+ "   AND cond.cod_isola = npr.cod_isola\n"
			+ "   AND cond.id_soggetto = :businessId\n"
			+ "   AND cond.cod_nazionale = :domainZoneId\n"
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete\n"
			+ "   AND :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)")
	@RegisterBeanMapper(HoldingArea.class)
	public HoldingArea getHoldingAreaByDomainZones(@Bind("businessId") String businessId,
		@Bind("domainZoneId") String domainZoneId, @Bind("pointInTime") LocalDateTime pointInTime);

	@SqlQuery("select lcs.council_sector_code as domainZoneId,"
		+ "           lcs.council_sector_code as code,"
		+ "           (lcs.council_sector_code || ' - ' || labels.council_sector(lcs.council_sector_code,1)) as description,"
		+ "           (select p.epsg_code from cata_sezioni s, dbmap_proj p where s.cod_sezione = lcs.council_sector_code and p.projection_id = s.projection_id) as srs,"
		+ "           nvl((select sdo_aggr_mbr(sdo_geom.sdo_mbr(npr.shape_inte))"
		+ "                  from siti.tisole_npr npr, siti.tisole_cond cond"
		+ "                 where sysdate between npr.dt_insert and npr.dt_delete"
		+ "                   AND :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
		+ "                   AND cond.cod_isola = npr.cod_isola"
		+ "                   AND cond.id_soggetto = :businessId"
		+ "                   AND sysdate between cond.dt_insert and cond.dt_delete"
		+ "                   AND :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)),"
		+ "               (select sdo_aggr_mbr(sdo_geom.sdo_mbr(g.shape)) from gis_councils g, lau_councils_sectors_viw l where g.council_id = l.council_id and l.council_sector_id = lcs.council_sector_id)) as mbr"
		+ "      from lau_councils_sectors lcs"
		+ "     where :pointInTime between lcs.dt_start and lcs.dt_end"
		+ "       and (:search is null or upper(lcs.name) like '%'||upper(:search)||'%' or lcs.council_sector_code like '%'||upper(:search)||'%')"
		+ "  order by lcs.name, lcs.council_sector_code")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	public ResultIterator<DomainZoneGeometry> getDomainZones(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDateTime pointInTime, @Bind("search") String search);
	
	@SqlQuery("select lcs.council_sector_code as domainZoneId,"
		+ "           lcs.council_sector_code as code,"
		+ "           (lcs.council_sector_code || ' - ' || labels.council_sector(lcs.council_sector_code,1)) as description,"
		+ "           (select p.epsg_code from cata_sezioni s, dbmap_proj p where s.cod_sezione = lcs.council_sector_code and p.projection_id = s.projection_id) as srs,"
		+ "           nvl((select sdo_geom.sdo_mbr(sdo_aggr_union(SDOAGGRTYPE(npr.shape_inte,0.005)))"
		+ "                  from siti.tisole_npr npr, siti.tisole_cond cond"
		+ "                 where sysdate between npr.dt_insert and npr.dt_delete"
		+ "                   AND :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
		+ "                   AND cond.cod_isola = npr.cod_isola"
		+ "                   AND cond.id_soggetto = :businessId"
		+ "                   AND sysdate between cond.dt_insert and cond.dt_delete"
		+ "                   AND :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)),"
		+ "               (select sdo_geom.sdo_mbr(sdo_aggr_union(SDOAGGRTYPE(g.shape,0.005))) from gis_councils g, lau_councils_sectors_viw l where g.council_id = l.council_id and l.council_sector_id = lcs.council_sector_id)) as mbr"
		+ "      from lau_councils_sectors lcs"
		+ "     where :pointInTime between lcs.dt_start and lcs.dt_end"
		+ "       and (:search is null or upper(lcs.name) like '%'||upper(:search)||'%' or lcs.council_sector_code like '%'||upper(:search)||'%')"
		+ "  order by lcs.name, lcs.council_sector_code")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	public ResultIterator<DomainZoneGeometry> getDomainZonesNoSdoAggrMbr(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDateTime pointInTime, @Bind("search") String search);

	@SqlQuery("select lcs.council_sector_code as domainZoneId,"
			+ "           lcs.council_sector_code as code,"
			+ "           (lcs.council_sector_code || ' - ' || labels.council_sector(lcs.council_sector_code,1)) as description,"
			+ "           (select p.epsg_code from cata_sezioni s, dbmap_proj p where s.cod_sezione = lcs.council_sector_code and p.projection_id = s.projection_id) as srs,"
			+ "           nvl(sdo_aggr_mbr(sdo_geom.sdo_mbr(npr.shape_inte)),(select sdo_aggr_mbr(sdo_geom.sdo_mbr(g.shape)) from gis_councils g, lau_councils_sectors_viw l where g.council_id = l.council_id and l.council_sector_id = lcs.council_sector_id)) as mbr"
			+ "      from siti.tisole_npr npr, siti.tisole_cond cond, lau_councils_sectors lcs"
			+ "     where sysdate between npr.dt_insert and npr.dt_delete"
			+ "       AND :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
			+ "       AND cond.cod_isola = npr.cod_isola"
			+ "       AND cond.id_soggetto = :businessId"
			+ "       AND sysdate between cond.dt_insert and cond.dt_delete"
			+ "       AND :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
			+ "       and cond.cod_nazionale = lcs.council_sector_code"
			+ "       and :pointInTime between lcs.dt_start and lcs.dt_end"
			+ "       and (:search is null or upper(lcs.name) like '%'||upper(:search)||'%' or lcs.council_sector_code like '%'||upper(:search)||'%')"
			+ "  group by lcs.council_sector_id, lcs.council_sector_code, lcs.name"
			+ "  order by lcs.name, lcs.council_sector_code")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	public ResultIterator<DomainZoneGeometry> getDomainZonesByBusinessId(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDateTime pointInTime, @Bind("search") String search);
	
	@SqlQuery("select lcs.council_sector_code as domainZoneId,"
			+ "           lcs.council_sector_code as code,"
			+ "           (lcs.council_sector_code || ' - ' || labels.council_sector(lcs.council_sector_code,1)) as description,"
			+ "           (select p.epsg_code from cata_sezioni s, dbmap_proj p where s.cod_sezione = lcs.council_sector_code and p.projection_id = s.projection_id) as srs,"
			+ "           nvl(sdo_geom.sdo_mbr(sdo_aggr_union(SDOAGGRTYPE(npr.shape_inte,0.005))),(select sdo_geom.sdo_mbr(sdo_aggr_union(SDOAGGRTYPE(g.shape,0.005))) from gis_councils g, lau_councils_sectors_viw l where g.council_id = l.council_id and l.council_sector_id = lcs.council_sector_id)) as mbr"
			+ "      from siti.tisole_npr npr, siti.tisole_cond cond, lau_councils_sectors lcs"
			+ "     where sysdate between npr.dt_insert and npr.dt_delete"
			+ "       AND :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
			+ "       AND cond.cod_isola = npr.cod_isola"
			+ "       AND cond.id_soggetto = :businessId"
			+ "       AND sysdate between cond.dt_insert and cond.dt_delete"
			+ "       AND :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
			+ "       and cond.cod_nazionale = lcs.council_sector_code"
			+ "       and :pointInTime between lcs.dt_start and lcs.dt_end"
			+ "       and (:search is null or upper(lcs.name) like '%'||upper(:search)||'%' or lcs.council_sector_code like '%'||upper(:search)||'%')"
			+ "  group by lcs.council_sector_id, lcs.council_sector_code, lcs.name"
			+ "  order by lcs.name, lcs.council_sector_code")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	public ResultIterator<DomainZoneGeometry> getDomainZonesByBusinessIdNoSdoAggrMbr(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDateTime pointInTime, @Bind("search") String search);

	@SqlQuery("select lcs.council_sector_code as domainZoneId,"
			+ "           lcs.council_sector_code as code,"
			+ "           (lcs.council_sector_code || ' - ' || labels.council_sector(lcs.council_sector_code,1)) as description,"
			+ "           (select p.epsg_code from cata_sezioni s, dbmap_proj p where s.cod_sezione = lcs.council_sector_code and p.projection_id = s.projection_id) as srs,"
			+ "           (select sdo_aggr_mbr(sdo_geom.sdo_mbr(g.shape)) from gis_councils g, lau_councils_sectors_viw l where g.council_id = l.council_id and l.council_sector_id = lcs.council_sector_id) as mbr"
			+ "      from lau_councils_sectors lcs"
			+ "     where lcs.council_sector_code in (<domainZoneIds>)"
			+ "       and (:search is null or upper(lcs.name) like '%'||upper(:search)||'%' or lcs.council_sector_code like '%'||upper(:search)||'%')"
			+ "  group by lcs.council_sector_id, lcs.council_sector_code, lcs.name"
			+ "  order by lcs.name, lcs.council_sector_code")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	public ResultIterator<DomainZoneGeometry> getDomainZonesByIds(@Bind("search") String search, @BindList("domainZoneIds") List<String> domainZoneIds);
	
	@SqlQuery("select lcs.council_sector_code as domainZoneId,"
		+ "           lcs.council_sector_code as code,"
		+ "           (lcs.council_sector_code || ' - ' || labels.council_sector(lcs.council_sector_code,1)) as description,"
		+ "           (select p.epsg_code from cata_sezioni s, dbmap_proj p where s.cod_sezione = lcs.council_sector_code and p.projection_id = s.projection_id) as srs,"
		+ "           nvl((select sdo_aggr_mbr(sdo_geom.sdo_mbr(npr.shape_inte))"
		+ "                  from siti.tisole_npr npr, siti.tisole_cond cond"
		+ "                 where sysdate between npr.dt_insert and npr.dt_delete"
		+ "                   AND :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
		+ "                   AND cond.cod_isola = npr.cod_isola"
		+ "                   AND cond.id_soggetto = :businessId"
		+ "                   AND sysdate between cond.dt_insert and cond.dt_delete"
		+ "                   AND :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)),"
		+ "               (select sdo_aggr_mbr(sdo_geom.sdo_mbr(g.shape)) from gis_councils g, lau_councils_sectors_viw l where g.council_id = l.council_id and l.council_sector_id = lcs.council_sector_id)) as mbr"
		+ "      from lau_councils_sectors lcs"
		+ "     where :pointInTime between lcs.dt_start and lcs.dt_end"
		+ "       and lcs.council_sector_code = :domainZoneId")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	public DomainZoneGeometry getDomainZone(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDateTime pointInTime, @Bind("domainZoneId") String domainZoneId);
	
	@SqlQuery("select lcs.council_sector_code as domainZoneId,"
			+ "           lcs.council_sector_code as code,"
			+ "           (lcs.council_sector_code || ' - ' || labels.council_sector(lcs.council_sector_code,1)) as description,"
			+ "           (select p.epsg_code from cata_sezioni s, dbmap_proj p where s.cod_sezione = lcs.council_sector_code and p.projection_id = s.projection_id) as srs,"
			+ "           nvl((select sdo_geom.sdo_mbr(sdo_aggr_union(SDOAGGRTYPE(npr.shape_inte,0.005)))"
			+ "                  from siti.tisole_npr npr, siti.tisole_cond cond"
			+ "                 where sysdate between npr.dt_insert and npr.dt_delete"
			+ "                   AND :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
			+ "                   AND cond.cod_isola = npr.cod_isola"
			+ "                   AND cond.id_soggetto = :businessId"
			+ "                   AND sysdate between cond.dt_insert and cond.dt_delete"
			+ "                   AND :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)),"
			+ "               (select sdo_aggr_mbr(sdo_geom.sdo_mbr(g.shape)) from gis_councils g, lau_councils_sectors_viw l where g.council_id = l.council_id and l.council_sector_id = lcs.council_sector_id)) as mbr"
			+ "      from lau_councils_sectors lcs"
			+ "     where :pointInTime between lcs.dt_start and lcs.dt_end"
			+ "       and lcs.council_sector_code = :domainZoneId")
	@RegisterBeanMapper(DomainZoneGeometry.class)
	public DomainZoneGeometry getDomainZoneNoSdoAggrMbr(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDateTime pointInTime, @Bind("domainZoneId") String domainZoneId);

	@SqlQuery("§select_from_dual("
		+ " (select council_sector_code from lau_councils_sectors where :pointInTime between dt_start and dt_end and council_sector_code = :domainZoneId)"
		+ " || ' - '"
		+ " || labels.council_sector(:domainZoneId,1))§")
	public String getDomainZoneDescription(@Bind("pointInTime") LocalDateTime pointInTime, @Bind("domainZoneId") String domainZoneId);

	@SqlQuery("select npr.isola_npr_geom_id as id,"
		+ "           'PARCEL' as type,"
		+ "           npr.shape_inte as geom"
		+ "      from siti.tisole_npr npr, siti.tisole_cond cond"
		+ "     where sysdate between npr.dt_insert and npr.dt_delete"
		+ "       AND :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
		+ "       AND cond.cod_isola = npr.cod_isola"
		+ "       AND cond.id_soggetto = :businessId"
		+ "       AND cond.cod_nazionale = :domainZoneId"
		+ "       AND sysdate between cond.dt_insert and cond.dt_delete"
		+ "       AND :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getParcelsSnapGeometries(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDateTime pointInTime, @Bind("domainZoneId") String domainZoneId);

	
	/*@SqlQuery("select npr.isola_npr_geom_id as code,"
		+ "           npr.shape_inte as geom"
		//+ "      from (select * from siti.tisole_npr npr1 where §geom_have_interactions(npr1.shape_inte, :touchingGeometry)§) npr, "
		+ "      from (select * from siti.tisole_npr npr1 where sdo_relate(npr1.shape_inte, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE') npr, "
		//+ "      from (select * from siti.tisole_npr npr1 where sdo_filter(npr1.shape_inte, :touchingGeometry, 'querytype = WINDOW') = 'TRUE') npr, "
		+ "           siti.tisole_cond cond"
		+ "     where sysdate between npr.dt_insert and npr.dt_delete"
		+ "       AND :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
		+ "       AND cond.cod_isola = npr.cod_isola"
		+ "       AND cond.id_soggetto = :businessId"
		+ "       AND cond.cod_nazionale = :domainZoneId"
		+ "       AND sysdate between cond.dt_insert and cond.dt_delete"
		+ "       AND :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)")
	@RegisterBeanMapper(ParcelGeometry.class)
	public List<ParcelGeometry> getParcels(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDateTime pointInTime, @Bind("domainZoneId") String domainZoneId,
		@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("SELECT code, geom, to_char(trunc(dt_start),'yyyymmdd') AS fromDate, to_char(trunc(dt_end+1/24/60/60-1),'yyyymmdd') AS toDate FROM ("
			+ "   select npr.isola_npr_geom_id as code,"
			+ "          npr.shape_inte as geom,"
			+ "          greatest(to_date((npr.anno_inizio-1)||'1101','yyyymmdd'),trunc(cond.data_inizio_conduzione)) AS dt_start,"
			+ "          least((case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231','yyyymmdd') end),(case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231','yyyymmdd') end)) AS dt_end"
			+ "     from (select * from siti.tisole_npr npr1 where sdo_relate(npr1.shape_inte, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE') npr, "
			+ "          siti.tisole_cond cond "
			+ "    where sysdate between npr.dt_insert and npr.dt_delete"
			+ "      AND cond.cod_isola = npr.cod_isola"
			+ "      AND cond.id_soggetto = :businessId"
			+ "      AND cond.cod_nazionale = :domainZoneId"
			+ "      AND sysdate between cond.dt_insert and cond.dt_delete)")
	@RegisterBeanMapper(Parcel.class)
	public List<Parcel> getAllParcels(@Bind("businessId") String businessId,
			@Bind("domainZoneId") String domainZoneId, @Bind("touchingGeometry") Geometry touchingGeometry);*/
		
	@SqlQuery("SELECT code, geom, to_char(trunc(dt_start),'yyyymmdd') AS fromDate, to_char(trunc(dt_end+1/24/60/60-1),'yyyymmdd') AS toDate FROM ("
	    +"     select npr.isola_npr_geom_id as code,"
		+ "           npr.shape_inte as geom,"
		+ "           greatest(to_date((npr.anno_inizio-1)||'1101','yyyymmdd'),trunc(cond.data_inizio_conduzione)) AS dt_start,"
		+ "           least((case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231','yyyymmdd') end),(case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231','yyyymmdd') end)) AS dt_end"
		+ "      from siti.tisole_npr npr, siti.tisole_cond cond"
		+ "     where sysdate between npr.dt_insert and npr.dt_delete"
		+ "       AND :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
		+ "       and npr.isola_npr_geom_id in (<parcelCodes>)"
		+ "       and cond.cod_isola = npr.cod_isola"
		+ "       and cond.id_soggetto = :businessId"
		+ "       AND cond.cod_nazionale = :domainZoneId"
		+ "       AND sysdate between cond.dt_insert and cond.dt_delete"
		+ "       AND (trunc(cond.data_inizio_conduzione) > :pointInTime or (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end) > :pointInTime))")
	@RegisterBeanMapper(Parcel.class)
	public List<Parcel> getParcelsByParcelCodes(@Bind("businessId") String businessId,
			@Bind("domainZoneId") String domainZoneId, @Bind("pointInTime") LocalDateTime pointInTime, 
			@BindList("parcelCodes") List<String> parcelCodes);

	/*@SqlQuery("select to_date((npr.anno_inizio-1)||'1101','yyyymmdd') as d1,"
		+ "           (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231','yyyymmdd') end) as d2,"
		+ "           trunc(cond.data_inizio_conduzione) as d3,"
		+ "           (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231','yyyymmdd') end) as d4"
		+ "      from (select * from siti.tisole_npr npr1 where sdo_relate(npr1.shape_inte, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE') npr, "
		+ "           siti.tisole_cond cond "
		+ "     where sysdate between npr.dt_insert and npr.dt_delete"
		+ "       AND (to_date((npr.anno_inizio-1)||'1101','yyyymmdd') > :pointInTime or (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end) > :pointInTime)"
		+ "       AND cond.cod_isola = npr.cod_isola"
		+ "       AND cond.id_soggetto = :businessId"
		+ "       AND cond.cod_nazionale = :domainZoneId"
		+ "       AND sysdate between cond.dt_insert and cond.dt_delete"
		+ "       AND (trunc(cond.data_inizio_conduzione) > :pointInTime or (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end) > :pointInTime)")
	@RegisterBeanMapper(FutureParcelIntersectionDates.class)
	public List<FutureParcelIntersectionDates> getFutureParcelsIntersections(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDateTime pointInTime, @Bind("domainZoneId") String domainZoneId,
		@Bind("touchingGeometry") Geometry touchingGeometry);*/

	@SqlQuery("select dg.s_code_parent as landCoverCode"
		+ "      from siti_cond.tisole_npr_geoms npr, deco_codes_groups dg"
		+ "     where npr.ISOLA_NPR_ID = :parcelCode"
		+ "       and dg.s_code_child = npr.cod_refresh"
		+ "       and dg.p_code_parent = 'COVCOD_CROP_PLAN'")
	List<String> getParcelsLandCoverCodes(@Bind("pointInTime") LocalDateTime pointInTime, @Bind("parcelCode") String parcelCode);

	@SqlQuery("select distinct s_code_parent as landCoverCode,"
		+ "           deco_srv.get_decode('COVCOD_CROP_PLAN', s_code_parent) as landCoverDescription"
		+ "      from (select s_code_parent from deco_codes_groups where p_code_child='COVCOD' and s_code_child in"
		+ "			(select dg.s_code_parent as landCoverCode"
		+ "      	 from siti_cond.tisole_npr_geoms npr, deco_codes_groups dg"
		+ "     	 where npr.ISOLA_NPR_ID = :parcelCode"
		+ "       	 and dg.s_code_child = npr.cod_refresh"
		+ "       	 and dg.p_code_parent = 'COVCOD_CROP_PLAN')"
		+ "		and p_code_parent='COVCOD_CROP_PLAN')")
	@RegisterBeanMapper(LandCover.class)
	List<LandCover> getLandCovers(@Bind("pointInTime") LocalDateTime pointInTime, @Bind("parcelCode") String parcelCode);

	@SqlQuery("select sdo_geom.sdo_mbr(npr.shape_inte)"
		+ "      from siti.tisole_npr npr, siti.tisole_cond cond"
		+ "     where sysdate between npr.dt_insert and npr.dt_delete"
		+ "       and :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
		+ "       and npr.isola_npr_geom_id in (<parcelCodes>)"
		+ "       and cond.cod_isola = npr.cod_isola"
		+ "       and cond.id_soggetto = :businessId"
		+ "       and sysdate between cond.dt_insert and cond.dt_delete"
		+ "       and :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)")
	@RegisterBeanMapper(ParcelGeometry.class)
	public List<Geometry> getParcelsMbr(@Bind("businessId") String businessId, 
			@Bind("pointInTime") LocalDateTime pointInTime,
			@BindList("parcelCodes") List<String> parcelCodes);

	@SqlQuery("select p.isola_npr_geom_id as code,"
			+ "       p.codi_prif||'/'||p.prog_isola as description,"
			+ "       '[' || labels.council_sector(c.council_sector_id, 4) || ' - ' || labels.council_sector(c.council_sector_id, 5) || '] ' || labels.sheet(p.id_foglio) || ' ' || p.codi_prif||'/'||p.prog_isola as parcelCode, "
			+ "       cond.PERC_CONDUZIONE as holdingPercentage "
			+ "  FROM siti.tisole_npr p, siti_cond.tisole_cond cond, lau_sheets s, lau_councils_sectors_viw c"
			+ " WHERE s.sheet_id = p.id_foglio"
			+ "   AND SYSDATE BETWEEN s.dt_start AND s.dt_end"
			+ "   AND c.council_sector_id = s.council_sector_id"
			+ "   AND SYSDATE BETWEEN c.dt_start AND c.dt_end"
			+ "   AND p.isola_npr_geom_id in (<parcelCodes>)"
			+ "   AND SYSDATE BETWEEN p.dt_insert AND p.dt_delete"
			+ "   and :pointInTime between to_date((p.anno_inizio-1)||'1101','yyyymmdd') and (case when p.anno_fine < 9999 then (to_date(p.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
			//+ "   AND p.anno_fine = (SELECT max(p2.anno_fine) FROM siti.tisole_npr p2 WHERE p2.isola_npr_geom_id = p.isola_npr_geom_id AND p2.dt_delete = p.dt_delete)"
			+ "   AND cond.cod_isola = p.cod_isola"
			+ "   AND SYSDATE BETWEEN cond.dt_insert AND cond.dt_delete"
			+ "   AND :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
			//+ "   AND cond.data_fine_conduzione = (SELECT max(cond1.data_fine_conduzione) FROM siti.tisole_npr p1, siti.tisole_cond cond1 WHERE p1.isola_npr_geom_id = p.isola_npr_geom_id AND p1.anno_fine = p.anno_fine AND cond1.cod_isola = p1.cod_isola AND cond1.dt_delete = cond.dt_delete)"
			+ "   AND cond.id_soggetto = :businessId")
	@RegisterBeanMapper(ParcelDescription.class)
	List<ParcelDescription> getParcelsDescription(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDateTime pointInTime,
		@BindList("parcelCodes") List<String> parcelCodes);
	
	@SqlQuery("select p.isola_npr_id as code,"
			+ "       p.codi_prif||'/'||p.prog_isola as description,"
			+ "       '[' || labels.council_sector(c.council_sector_id, 4) || ' - ' || labels.council_sector(c.council_sector_id, 5) || '] ' || labels.sheet(p.id_foglio) || ' ' || p.codi_prif||'/'||p.prog_isola as parcelCode, "
			+ "       cond.PERC_CONDUZIONE as holdingPercentage "
			+ "  FROM siti.tisole_npr p, siti_cond.tisole_cond cond, lau_sheets s, lau_councils_sectors_viw c"
			+ " WHERE s.sheet_id = p.id_foglio"
			+ "   AND SYSDATE BETWEEN s.dt_start AND s.dt_end"
			+ "   AND c.council_sector_id = s.council_sector_id"
			+ "   AND SYSDATE BETWEEN c.dt_start AND c.dt_end"
			+ "   AND p.isola_npr_id in (<parcelCodes>)"
			+ "   and :pointInTime between to_date((p.anno_inizio-1)||'1101','yyyymmdd') and (case when p.anno_fine < 9999 then (to_date(p.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
			+ "   AND cond.cod_isola = p.cod_isola"
			+ "   AND :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
			+ "   AND cond.id_soggetto = :businessId")
	@RegisterBeanMapper(ParcelDescription.class)
	List<ParcelDescription> getParcelsDescriptionFromIsolaNprId(@Bind("businessId") String businessId,
		@Bind("pointInTime") LocalDateTime pointInTime,
		@BindList("parcelCodes") List<String> parcelCodes);

	@SqlQuery("select deco_srv.get_decode(:pCode, :sCode, :lang) as description from dual")
	public String getDecodedIntlnDescription(
			@Bind("pCode") String pCode,
			@Bind("sCode") String sCode,
			@Bind("lang") String lang);

	@RegisterBeanMapper(GisInfoData.class)
	@SqlQuery("SELECT lc.COUNCIL_CODE AS title, " +
		"             SDO_GEOM.SDO_MBR(gc.SHAPE) AS mbr, " +
		"             SDO_GEOM.SDO_AREA(gc.SHAPE, 0.005) AS area " +
		"        FROM LAU_COUNCILS lc, GIS_COUNCILS gc " +
		"       WHERE gc.COUNCIL_ID = lc.COUNCIL_ID " +
		"         AND (lc.COUNCIL_ID IN ( " +
		"              SELECT MIN(lcsl.COUNCIL_ID) " +
		"                FROM LAU_COUNCILS_SECTORS_LINKS lcsl " +
		"               WHERE lcsl.COUNCIL_SECTOR_ID = :councilSectorId "+
	"					 AND :pointInTime between lcsl.DT_START and DT_END)) "+
		"         AND §geom_have_interactions(gc.shape, :touchingGeometry)§ " +
		"         AND :pointInTime between gc.DT_START and gc.DT_END " +
		"         AND :pointInTime between lc.DT_START and lc.DT_END ")
	public List<GisInfoData> getCouncilGisInfoData(
		@Bind("councilSectorId") Long councilSectorId,
		@Bind("touchingGeometry") Geometry touchingGeometry,
		@Bind("pointInTime") LocalDateTime pointInTime);

	@RegisterBeanMapper(GisInfoData.class)
	@SqlQuery("SELECT labels.sheet(ls.SHEET_ID) AS title, " +
		"             SDO_GEOM.SDO_MBR(gm.SHAPE) AS mbr, " +
		"             SDO_GEOM.SDO_AREA(gm.SHAPE, 0.005) AS area, " +
		"             labels.sheet(ls.SHEET_ID) AS sheet " +
		"        FROM LAU_SHEETS ls, GIS_MAPS gm " +
		"       WHERE ls.SHEET_ID = gm.SHEET_ID " +
		"         AND ls.COUNCIL_SECTOR_ID = :councilSectorId " +
		"         AND §geom_have_interactions(gm.shape, :touchingGeometry)§ " +
		"         AND :pointInTime between ls.DT_START and ls.DT_END " +
		"         AND §current_timestamp§ between gm.DT_INSERT and gm.DT_DELETE ")
	public List<GisInfoData> getSheetGisInfoData(
		@Bind("councilSectorId") Long councilSectorId,
		@Bind("touchingGeometry") Geometry touchingGeometry,
		@Bind("pointInTime") LocalDateTime pointInTime);

	@RegisterBeanMapper(ParcelData.class)
	@SqlQuery("SELECT labels.sheet(npr.id_foglio) AS sectorBlock,"
		+ "           npr.isola_npr_geom_id AS parcelCode,"
		+ "           (SELECT p.epsg_code"
		+ "              FROM cata_sezioni cs, dbmap_proj p"
		+ "             WHERE cs.cod_sezione = cond.cod_nazionale"
		+ "               AND p.projection_id = cs.projection_id) as srs,"
		+ "           npr.shape_inte AS geom,"
		+ "           SDO_GEOM.SDO_MBR(npr.shape_inte) AS mbrOverview,"
		+ "           npr.area_intersezione AS areaSqm,"
		+ "           decode(template_farm_viewer_pck.has_unimm(npr.isola_npr_geom_id, :pointInTime),0,0,1) as hasUnimm,"
		+ "           decode(template_farm_viewer_pck.has_unar(npr.isola_npr_geom_id, :pointInTime),0,0,1) as hasUnar,"
		+ "           cond.perc_conduzione as holdingPercentage,"
		+ "           template_farm_viewer_pck.has_single_holding(npr.isola_npr_geom_id, :pointInTime) as holdingCount,"
		+ "           decode(2,1,'PROPERTY',2,'RENT',3,'SHARECROPPPING',4,'OTHER',null) as holdingType,"
		+ "           nvl(template_farm_viewer_pck.get_holding_type_decode(npr.isola_npr_geom_id, :pointInTime, cond.id_soggetto), 2) as holdingTypeDescription,"
		+ "           decode(1,1,'URBAN',2,'AGRICULTURAL',3,'ROADS',4,'WATERS',null) as parcelType,"
		+ "           nvl(template_farm_viewer_pck.get_parcel_type_decode(npr.isola_npr_geom_id, :pointInTime), 1) as parcelTypeDescription"
		+ "      from siti.tisole_npr npr, siti.tisole_cond cond"
		+ "     where sysdate between npr.dt_insert and npr.dt_delete"
		+ "       AND :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
		+ "       AND cond.cod_isola = npr.cod_isola"
		+ "       AND cond.id_soggetto = :businessId"
		+ "       AND (:domainZoneId is null or cond.cod_nazionale = :domainZoneId)"
		+ "       AND sysdate between cond.dt_insert and cond.dt_delete"
		+ "       AND :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
		+ "       AND (:parcelId is null or npr.isola_npr_geom_id = :parcelId)")
	public ResultIterator<ParcelData> getParcelsData(
			@Bind("businessId") String businessId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("parcelId") String parcelId,
			@Bind("pointInTime") LocalDateTime pointInTime);

	@SqlQuery("\n"
			+ "select cs.council_sector_code \n"
			+ "  from lpis_parcels p \n"
			+ " inner join lau_sheets s on p.sheet_id = s.sheet_id \n"
			+ " inner join lau_councils_sectors cs on s.council_sector_id = cs.council_sector_id \n"
			+ " where :pointInTime between s.dt_start and s.dt_end \n"
			+ "   and :pointInTime between cs.dt_start and cs.dt_end \n"
			+ "   and parcel_id = :parcelId \n"
			+ " fetch first row only \n")
	@Deprecated
	public String getDomainZoneIdForParcel(
			@Bind("parcelId") String parcelId,
			@Bind("pointInTime") LocalDateTime pointInTime);
	
	@SqlQuery("SELECT g.shape"
			+ "  from gis_councils g, lau_councils_sectors_viw l, lau_councils_sectors lcs"
			+ " where g.council_id = l.council_id"
			+ "   and l.council_sector_id = lcs.council_sector_id"
			+ "   AND lcs.council_sector_code = :domainZoneId"
			+ "   AND :pointInTime between lcs.dt_start and lcs.dt_end")			
	public Geometry getCouncilGeometry(@Bind("domainZoneId") String domainZoneId,
			@Bind("pointInTime") LocalDateTime pointInTime);

	@Deprecated
	@SqlQuery("select npr.cod_isola "
			+ "  from siti.tisole_npr npr "
			+ " where sdo_relate(npr.shape_inte, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	public void getParcelsCodes(@Bind("touchingGeometry") Geometry touchingGeometry, Consumer<String> consumer);

	@Deprecated
	@SqlQuery("select npr.isola_npr_geom_id as code, "
			+ "       npr.shape_inte as geom "
			+ "  from siti.tisole_npr npr, siti.tisole_cond cond "
			+ " where sysdate between npr.dt_insert and npr.dt_delete "
			+ "   AND :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end) "
			+ "   AND npr.cod_isola in (<parcelsCodes>) "
			+ "   AND cond.cod_isola = npr.cod_isola "
			+ "   AND cond.id_soggetto = :businessId "
			+ "   AND cond.cod_nazionale = :domainZoneId "
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete "
			+ "   AND :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end) "
			+ "   AND sdo_relate(npr.shape_inte, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(ParcelGeometry.class)
	public List<ParcelGeometry> getParcels(@Bind("businessId") String businessId,
			@Bind("pointInTime") LocalDateTime pointInTime, @Bind("domainZoneId") String domainZoneId,
			@BindList("parcelsCodes") List<String> parcelsCodes, @Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("SELECT /*+ INDEX(NPR TISOLE_NPR_GEOMS_SPIDX) */ npr.isola_npr_id AS code, npr.shape AS geom \n"
			+ "  FROM siti_cond.tisole_npr_geoms npr \n"
			+ " WHERE EXISTS \n"
			+ "       (SELECT 1 \n"
			+ "          FROM siti.tisole_npr_dett d, siti.tisole_cond cond \n"
			+ "         WHERE d.isola_npr_id = npr.isola_npr_id \n"
			+ "           AND SYSDATE BETWEEN d.dt_insert AND d.dt_delete \n"
			+ "           AND :pointInTime BETWEEN \n"
			+ "               to_date((d.anno_inizio - 1) || '1101', 'yyyymmdd') AND (CASE \n"
			+ "                 WHEN d.anno_fine < 9999 THEN \n"
			+ "                  (to_date(d.anno_fine || '1031', 'yyyymmdd') + 1) \n"
			+ "                 ELSE \n"
			+ "                  to_date('99991231 23:59:59', 'yyyymmdd hh24:mi:ss') \n"
			+ "               END) \n"
			+ "           AND cond.cod_nazionale = :domainZoneId \n"
			+ "           AND SYSDATE BETWEEN cond.dt_insert AND cond.dt_delete \n"
			+ "           AND cond.cod_isola = d.cod_isola \n"
			+ "           AND :pointInTime BETWEEN trunc(cond.data_inizio_conduzione) AND \n"
			+ "               (CASE \n"
			+ "                 WHEN cond.data_fine_conduzione < \n"
			+ "                      to_date('99990101', 'yyyymmdd') THEN \n"
			+ "                  trunc(cond.data_fine_conduzione + 1) \n"
			+ "                 ELSE \n"
			+ "                  to_date('99991231 23:59:59', 'yyyymmdd hh24:mi:ss') \n"
			+ "               END)) \n"
			+ "   AND npr.id_soggetto = :businessId \n"
			+ "   and §geom_have_interactions(npr.shape, :touchingGeometry)§")
	@RegisterBeanMapper(ParcelGeometry.class)
	public List<ParcelGeometry> getParcels(@Bind("businessId") String businessId,
			@Bind("pointInTime") LocalDateTime pointInTime, @Bind("domainZoneId") String domainZoneId,
			@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@Deprecated
	@SqlQuery("SELECT code, geom, to_char(trunc(dt_start),'yyyymmdd') AS fromDate, to_char(trunc(dt_end+1/24/60/60-1),'yyyymmdd') AS toDate FROM ( "
			+ "   select npr.isola_npr_geom_id as code, "
			+ "          npr.shape_inte as geom, "
			+ "          greatest(to_date((npr.anno_inizio-1)||'1101','yyyymmdd'),trunc(cond.data_inizio_conduzione)) AS dt_start, "
			+ "          least((case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231','yyyymmdd') end),(case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231','yyyymmdd') end)) AS dt_end "
			+ "     from siti.tisole_npr npr, siti.tisole_cond cond "
			+ "    where sysdate between npr.dt_insert and npr.dt_delete "
			+ "      AND npr.cod_isola in (<parcelsCodes>) "
			+ "      AND cond.cod_isola = npr.cod_isola "
			+ "      AND cond.id_soggetto = :businessId "
			+ "      AND cond.cod_nazionale = :domainZoneId "
			+ "      AND sysdate between cond.dt_insert and cond.dt_delete "
			+ "      AND sdo_relate(npr.shape_inte, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE')")
	@RegisterBeanMapper(Parcel.class)
	public List<Parcel> getAllParcels(@Bind("businessId") String businessId,
			@Bind("domainZoneId") String domainZoneId, @BindList("parcelsCodes") List<String> parcelsCodes, @Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("SELECT code, \n"
			+ "       geom, \n"
			+ "       to_char(trunc(dt_start), 'yyyymmdd') AS fromdate, \n"
			+ "       to_char(trunc(dt_end + 1 / 24 / 60 / 60 - 1), 'yyyymmdd') AS todate \n"
			+ "  FROM (SELECT npr.isola_npr_id AS code, \n"
			+ "               npr.shape AS geom, \n"
			+ "               greatest(to_date((d.anno_inizio - 1) || '1101', 'yyyymmdd'), \n"
			+ "                        trunc(cond.data_inizio_conduzione)) AS dt_start, \n"
			+ "               least((CASE \n"
			+ "                        WHEN d.anno_fine < 9999 THEN \n"
			+ "                         (to_date(d.anno_fine || '1031', 'yyyymmdd') + 1) \n"
			+ "                        ELSE \n"
			+ "                         to_date('99991231', 'yyyymmdd') \n"
			+ "                      END), \n"
			+ "                      (CASE \n"
			+ "                        WHEN cond.data_fine_conduzione < \n"
			+ "                             to_date('99990101', 'yyyymmdd') THEN \n"
			+ "                         trunc(cond.data_fine_conduzione + 1) \n"
			+ "                        ELSE \n"
			+ "                         to_date('99991231', 'yyyymmdd') \n"
			+ "                      END)) AS dt_end \n"
			+ "          FROM siti.tisole_npr_geoms npr, \n"
			+ "               siti.tisole_npr_dett  d, \n"
			+ "               siti.tisole_cond      cond \n"
			+ "         WHERE d.isola_npr_id = npr.isola_npr_id \n"
			+ "           AND SYSDATE BETWEEN d.dt_insert AND d.dt_delete \n"
			+ "           AND cond.cod_isola = d.cod_isola \n"
			+ "           AND npr.id_soggetto = :businessId \n"
			+ "           AND cond.cod_nazionale = :domainZoneId \n"
			+ "           AND SYSDATE BETWEEN cond.dt_insert AND cond.dt_delete \n"
			+ "           and §geom_have_interactions(npr.shape, :touchingGeometry)§)")
	@RegisterBeanMapper(Parcel.class)
	public List<Parcel> getAllParcels(@Bind("businessId") String businessId,
			@Bind("domainZoneId") String domainZoneId, @Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select to_date((npr.anno_inizio-1)||'1101','yyyymmdd') as d1,"
			+ "       (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231','yyyymmdd') end) as d2,"
			+ "       trunc(cond.data_inizio_conduzione) as d3,"
			+ "       (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231','yyyymmdd') end) as d4"
			+ "  from siti.tisole_npr npr, "
			+ "       siti.tisole_cond cond "
			+ " where sysdate between npr.dt_insert and npr.dt_delete"
			+ "   AND (to_date((npr.anno_inizio-1)||'1101','yyyymmdd') > :pointInTime or (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end) > :pointInTime)"
			+ "   AND cond.cod_isola = npr.cod_isola"
			+ "   AND cond.id_soggetto = :businessId"
			+ "   AND cond.cod_nazionale = :domainZoneId"
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete"
			+ "   AND (trunc(cond.data_inizio_conduzione) > :pointInTime or (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end) > :pointInTime)"
			+ "   AND §geom_have_interactions(npr.shape_inte, :touchingGeometry)§")
	@RegisterBeanMapper(FutureParcelIntersectionDates.class)
	public List<FutureParcelIntersectionDates> getFutureParcelsIntersections(@Bind("businessId") String businessId,
			@Bind("pointInTime") LocalDateTime pointInTime, @Bind("domainZoneId") String domainZoneId,
			@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("select sdo_aggr_union(SDOAGGRTYPE(npr.shape_inte,0.005))\n"
			+ "  from siti.tisole_npr npr,\n"
			+ "       siti.tisole_cond cond\n"
			+ " where sysdate between npr.dt_insert and npr.dt_delete\n"
			+ "   AND :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)\n"
			+ "   AND cond.cod_isola = npr.cod_isola\n"
			+ "   AND cond.id_soggetto = :businessId\n"
			+ "   AND cond.cod_nazionale = :domainZoneId\n"
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete\n"
			+ "   AND :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)")
	public Geometry getDomainParcelsGeom(@Bind("businessId") String businessId,
			@Bind("pointInTime") LocalDateTime pointInTime, @Bind("domainZoneId") String domainZoneId);

	@SqlQuery("SELECT npr.isola_npr_geom_id AS title,"
			+ "       SDO_GEOM.SDO_MBR(npr.shape_inte) AS mbr,"
			+ "       npr.area_intersezione AS area,"
			+ "       labels.sheet(npr.id_foglio) AS sheet"
			+ "  from (select * from siti.tisole_npr npr1 where sdo_relate(npr1.shape_inte, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE') npr, "
			+ "       siti.tisole_cond cond"
			+ " where sysdate between npr.dt_insert and npr.dt_delete"
			+ "   AND :pointInTime between to_date((npr.anno_inizio-1)||'1101','yyyymmdd') and (case when npr.anno_fine < 9999 then (to_date(npr.anno_fine||'1031','yyyymmdd')+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)"
			+ "   AND cond.cod_isola = npr.cod_isola"
			+ "   AND cond.id_soggetto = :businessId"
			+ "   AND cond.cod_nazionale = :domainZoneId"
			+ "   AND sysdate between cond.dt_insert and cond.dt_delete"
			+ "   AND :pointInTime between trunc(cond.data_inizio_conduzione) and (case when cond.data_fine_conduzione < to_date('99990101','yyyymmdd') then trunc(cond.data_fine_conduzione+1) else to_date('99991231 23:59:59','yyyymmdd hh24:mi:ss') end)")
	@RegisterBeanMapper(GisInfoData.class)
	public List<GisInfoData> getParcelsGisInfoData(@Bind("businessId") String businessId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("touchingGeometry") Geometry touchingGeometry,
			@Bind("pointInTime") LocalDateTime pointInTime);
	
	@Data
	class FutureParcelIntersectionDates
	{
		private LocalDate d1;
		private LocalDate d2;
		private LocalDate d3;
		private LocalDate d4;
	}

}
