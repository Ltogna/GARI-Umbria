package com.abacogroup.cropplan.plugins.avepa.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import com.abacogroup.cropplan.plugins.avepa.model.PermanentCropFormWithDeclCode;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormData;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface CropPlanDAO extends EnhancedSqlObject {

	@SqlQuery("SELECT DECL_CODE as declCode, FORM_CODE as formCode, FORM_TYPE as formType, "
			+ "       AREA_SQM as pcfd_areaSqm, DISTANCE_ON_THE_ROW_CM as pcfd_distanceOnTheRowCm, "
			+ "       DISTANCE_BETWEEN_ROWS_CM as pcfd_distanceBetweenRowsCm, STUMPS_NUMBER as pcfd_stumpsNumber, FARMING_FORM as pcfd_farmingForm, IRRIGATION as pcfd_irrigation, PRODUCT_DESTINATION_CODE as pcfd_productDestinationCode,"
			+ "       CULTIVATION_TYPE_CODE as pcfd_cultivationTypeCode, VARIETY_CODE as pcfd_varietyCode, VARIATION_TYPE_CODE as pcfd_variationTypeCode, VINEYARD_TYPE_CODE as pcfd_vineyardTypeCode,"
			+ "       PLANTING_TYPE as pcfd_plantingType, LAYERING as pcfd_layering, ROCK as pcfd_rock, SKELETON as pcfd_skeleton, VEGETATIVE_STATE as pcfd_vegetativeState, PRUNING as pcfd_pruning, JUDGEMENT as pcfd_judgement,"
			+ "       STUMPS_DENSITY_100 as pcfd_stumpsDensity100, FAILURES_PERC as pcfd_failuresPerc, SOIL_LAYERING_PERC as pcfd_soilLayeringPerc, ALTITUDE_ABOVE_SEA_LEVEL as pcfd_altitudeAboveSeaLevel, "
			+ "       TERRACING as pcfd_terracing, HEADER_ANCHORING as pcfd_headerAnchoring, POLES_HEADER as pcfd_polesHeader, POLES_WEAVING as pcfd_polesWeaving, POLES_DISTANCE_CM as pcfd_polesDistanceCm, SUPPORT_WIRES as pcfd_supportWires,"
			+ "       CULTIVATION_STATE as pcfd_cultivationState, ORIGIN as pcfd_origin, GRAFT_DATE as pcfd_graftDate, GRAFT_HOLDER as pcfd_graftHolder, COVERING as pcfd_covering, BIO as pcfd_bio,"
			+ "       subscription_codes as pcfd_subscriptionCodes, external_code as pcfd_externalCode, quality_system as pcfd_qualitySystem, protection_structures as pcfd_protectionStructures, "
			+ "       planting_year as pcfd_plantingYear, shift_in_years as pcfd_shiftInYears, expected_cutting_date as pcfd_expectedCuttingDate"
			+ "  FROM CRPL_PERM_CROP_FORMS "
			+ " WHERE DECL_CODE in (<declCodes>) "
			+ " AND (:plotCode is null or PLOT_CODE = :plotCode) "
			+ " AND PLAN_ID = :cropPlanId "
			+ " AND :versionDt between dt_insert and dt_delete")
	@RegisterBeanMapper(PermanentCropFormWithDeclCode.class)
	@RegisterBeanMapper(PermanentCropFormData.class)
	List<PermanentCropFormWithDeclCode> getPermanentCropForms(@BindList("declCodes") List<String> declCodes,
			@Bind("plotCode") String plotCode,
			@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlQuery(""
			+ "select af.decl_code as declCode, \n"
			+ "       laf.field_type AS fieldType, \n"
			+ "       af.field_code as fieldCode, \n"
			//+ "       coalesce(§i18n(:tenantId, 'CRPL_LANDUSE_ADDIT_FIELDS', 'FIELD_CODE', af.field_code, :language)§, af.field_code) as fieldDescription, \n"
			+ "       af.field_value as value, \n"
			//+ "       coalesce(§i18n(:tenantId, 'CRPL_LANDUSE_ADDIT_FIELDS', 'FIELD_VALUE', af.field_value, :language)§, af.field_value) as valueDescription, \n"
			+ "       af.day_from as dayFrom, \n"
			+ "       af.day_to as dayTo, \n"
			+ "       laf.display_order as sortOrder, \n"
			+ "       laf.fl_show_in_tooltip as flShowInTooltip \n"
			+ "  from crpl_decl_addit_fields af \n"
			+ " inner join crpl_landuse_addit_fields laf on af.field_code = laf.field_code \n"
			+ " inner join crpl_declarations pdec on af.decl_code = pdec.decl_code and af.plot_code = pdec.plot_code and af.plan_id = pdec.plan_id \n"
			+ " inner join crpl_plots pc on pc.plot_code = pdec.plot_code and pc.plan_id = pdec.plan_id \n"
			+ " inner join crpl_plans pl on pl.id = af.plan_id \n"
			+ " where pl.id = :cropPlanId \n"
			+ "   and (:plotCode is null or pc.plot_code = :plotCode) \n"
			+ "   and pdec.decl_code in (<declCodes>) \n"
			+ "   and :versionDt between af.dt_insert and af.dt_delete \n"
			+ "   and :versionDt between laf.dt_insert and laf.dt_delete \n"
			+ "   and :versionDt between pdec.dt_insert and pdec.dt_delete \n"
			+ "   and :versionDt between pl.dt_insert and pl.dt_delete \n"
			+ " order by laf.display_order"
			+ "")
	@RegisterBeanMapper(LandUseAdditionalDataField.class)
	List<LandUseAdditionalDataField> getLandUseAdditionalDeclarationFields(
			@Bind("tenantId") String tenantId,
			//@Bind("language") String language,
			@Bind("plotCode") String plotCode,
			@Bind("cropPlanId") Long cropPlanId,
			@BindList("declCodes") List<String> declCodes,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlQuery("SELECT count(*) from crpl_config where type_id = (select id from crpl_types where code = :typeCode and §current_timestamp§ BETWEEN DT_INSERT AND DT_DELETE and tenant_id = :tenantId) and param_name = 'DISABLE_SNAP_GEOMETRIES' AND param_value = 'TRUE'")
	Integer disableSnapGeometries(
			@Bind("typeCode") String typeCode,
			@Bind("tenantId") String tenantId
	);

}
