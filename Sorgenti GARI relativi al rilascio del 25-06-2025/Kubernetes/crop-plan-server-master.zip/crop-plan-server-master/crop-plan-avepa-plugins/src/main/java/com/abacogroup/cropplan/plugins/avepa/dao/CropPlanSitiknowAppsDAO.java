package com.abacogroup.cropplan.plugins.avepa.dao;

import com.abacogroup.cropplan.plugins.avepa.dao.ntt.VersionWithHtuId;
import java.time.LocalDateTime;
import java.util.List;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

public interface CropPlanSitiknowAppsDAO {

	@SqlQuery("select count(*) from cropplan_to_iacs_link_header where subj_entity_id = :businessId and crop_id = :cropPlanId and version = :version")
	public Integer getVersionPublishedSuccesfully(@Bind("businessId") String businessId, @Bind("cropPlanId") Long cropPlanId, @Bind("version") String version);

	@SqlQuery("select count(*) from cropplan_to_iacs_link_failures where subj_entity_id = :businessId and crop_id = :cropPlanId and version = :version")
	public Integer getVersionPublishedWithErrors(@Bind("businessId") String businessId, @Bind("cropPlanId") Long cropPlanId, @Bind("version") String version);

	@SqlQuery("select count(*) from cropplan_external_changes where subj_entity_id = :businessId and crop_id = :cropPlanId and dt_changes_pending > :latestVersionDt")
	public Integer getCropPlanExternalChanges(@Bind("businessId") String businessId, @Bind("cropPlanId") Long cropPlanId, @Bind("latestVersionDt") LocalDateTime latestVersionDt);
	
	@SqlQuery("select count(*) from fascicolo.tfascicolo where id_soggetto = :businessId and sco_stato = 'AGGIOR' and sysdate between dt_inizio and dt_fine")
	public Integer getStatoFascicoloInLavorazione(@Bind("businessId") String businessId);
	
	@SqlQuery("SELECT m.version, m.htu_id \n"
			+ "  FROM CROPPLAN_TO_IACS_LINK_HEADER m\n"
			+ "  JOIN (\n"
			+ "    SELECT VERSION, MAX(dt_insert) AS max_dt_insert\n"
			+ "    FROM CROPPLAN_TO_IACS_LINK_HEADER\n"
			+ "    GROUP BY VERSION\n"
			+ ") s ON m.VERSION = s.VERSION AND m.DT_INSERT = s.max_dt_insert\n"
			+ " WHERE m.subj_entity_id = :businessId \n"
			+ "   AND m.crop_id = :cropPlanId \n"
			+ "   AND m.version in (<versions>)")
	@RegisterBeanMapper(VersionWithHtuId.class)
	public List<VersionWithHtuId> getVersionWithHtuId(
			@Bind("businessId") String businessId, 
			@Bind("cropPlanId") Long cropPlanId,
			@BindList("versions") List<String> versions); 
}
