package com.abacogroup.cropplan.plugins.avepa;

import static java.util.stream.Collectors.toList;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.locationtech.jts.geom.Geometry;

import com.abacogroup.cropplan.plugins.avepa.dao.SyncCropPlanDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.SyncSiti2025DAO;
import com.abacogroup.cropplan.sdk.model.sync.LatestSync;
import com.abacogroup.cropplan.sdk.model.sync.SyncParcel;
import com.abacogroup.cropplan.sdk.model.sync.WizardPlot;
import com.abacogroup.cropplan.sdk.spi.SyncPlugin;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

public class SyncPluginImpl2025 implements SyncPlugin, InitializablePlugin {

	private static final String JDBI_NAME_SITI = "dbSiti";
	private static final String JDBI_CROP_PLAN = "mainDB";

	private static final String SYNC_START_DATE = "20241101";

	private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");

	private SyncSiti2025DAO syncSitiDAO;
	private SyncCropPlanDAO syncCropPlanDAO;

	@Override
	public void initialize(PluginsEnvironment env) {
		var jdbiSiti = env.getJdbi(JDBI_NAME_SITI);
		if (jdbiSiti == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITI);
		
		var jdbiCropPlan = env.getJdbi(JDBI_CROP_PLAN);
		if (jdbiCropPlan == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_CROP_PLAN);

		syncSitiDAO = jdbiSiti.onDemand(SyncSiti2025DAO.class);
		syncCropPlanDAO = jdbiCropPlan.onDemand(SyncCropPlanDAO.class);
	}

	@Override
	public LocalDate getOldestChangesDateFromLpisDate(RuntimeEnvironment env, String businessId,
			Long cropPlanId, LocalDateTime lastSyncDt, LocalDateTime currentDt, boolean lite) {
		
		LocalDate ssd = LocalDate.parse(SYNC_START_DATE, FORMATTER);
		
		if (lastSyncDt == null)
			return ssd;
		
		LocalDate ret = syncSitiDAO.getOldestChangesDate(businessId, lastSyncDt, currentDt);
		if (ret == null)
			return null;
		else 
			return ret.isBefore(ssd) ? ssd : ret;
	}

	@Override
	public LocalDate getNextChangesDateFromLpisDate(RuntimeEnvironment env, String businessId,
			Long cropPlanId, LocalDate pointInTime, LocalDateTime lastSyncDt, LocalDateTime currentDt, boolean lite) {
		return syncSitiDAO.getNextChangesDate(businessId, lastSyncDt, currentDt, pointInTime);
	}

	@Override
	public List<String> getChangesFromLpis(RuntimeEnvironment env, String businessId, Long cropPlanId,
			LocalDate pointInTime, LocalDateTime lastSyncDt, LocalDateTime currentDt, boolean firstSync, boolean lite) {
		
		LocalDate ssd = LocalDate.parse(SYNC_START_DATE, FORMATTER);
		
		List<String> changeIds;
		if (lastSyncDt == null && firstSync) {
			changeIds = new ArrayList<>();
			syncSitiDAO.consumeAllParcelIds(businessId, currentDt, pointInTime, changeIds::add);
			syncCropPlanDAO.consumeAllCropPlanParcelIds(cropPlanId, currentDt, changeIds::add);
			return changeIds.stream().distinct().collect(toList());
		} else {
			return syncSitiDAO.getChangedParcelIds(businessId, lastSyncDt, currentDt, ssd, pointInTime);
		}
	}

	@Override
	public String getChangeId(RuntimeEnvironment env, String parcelCode) {
		return parcelCode;
	}

    @Override
    public List<SyncParcel> getLpisParcelsForWizard(RuntimeEnvironment env, String businessId, Long cropPlanId,
                                                    LocalDate pointInTime, LocalDateTime currentDt, List<String> changeIds) {
        return syncSitiDAO.getParcelsForWizard(businessId, changeIds);
    }

	@Override
	public String getDefaultLandUseCode(RuntimeEnvironment env, LocalDate pointInTime, String parcelCode) {
		return null;
	}

	@Override
	public List<WizardPlot> getWizardPlots(RuntimeEnvironment env, String businessId, Long cropPlanId,
			LocalDateTime currentDt, boolean beforePublish) {
		return new ArrayList<>();
	}

	@Override
	public List<SyncParcel> getLpisParcelsForPlotAlign(RuntimeEnvironment env, String domainZoneId,
			LocalDate pointInTime, Geometry geom, String srs) {
		return new ArrayList<>();
	}

	@Override
	public boolean isRecalcAnomaliesNeeded(RuntimeEnvironment env, String businessId, Long cropPlanId,
			LocalDateTime lastSyncDt, LocalDate currentReferenceDt, LatestSync latestSync, LocalDate currentCampaignStartDt) {		
		if (latestSync == null || latestSync.getReferenceDate() == null)
			return true;
		else if (currentReferenceDt == null)
			return true;
		else if (!latestSync.getReferenceDate().toLocalDate().equals(currentReferenceDt))
			return true;
		else {
			Geometry plotsMbr = syncCropPlanDAO.getPlotsMbr(cropPlanId, latestSync.getReferenceDate().toString());
			return syncSitiDAO.getNprChanges(plotsMbr, latestSync.getSyncDate(), latestSync.getReferenceDate().toLocalDate()) > 0;
		}
	}
	
	@Override
	public LocalDateTime getSyncPluginDate(RuntimeEnvironment env) {
		return null;
	}

	@Override
	public String getCropPlanType() {
		return "CROPPLAN_2025";
	}

}
