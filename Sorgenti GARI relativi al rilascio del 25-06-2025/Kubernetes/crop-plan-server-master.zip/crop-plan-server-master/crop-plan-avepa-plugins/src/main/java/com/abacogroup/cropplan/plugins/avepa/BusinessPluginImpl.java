package com.abacogroup.cropplan.plugins.avepa;

import java.util.Arrays;

import com.abacogroup.cropplan.plugins.avepa.auth.UserProxyPairProvider;
import com.abacogroup.cropplan.plugins.avepa.dao.AuthSitiknowDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.BusinessSitiknowDAO;
import com.abacogroup.cropplan.plugins.avepa.utils.AuthUtils;
import com.abacogroup.cropplan.sdk.model.business.Business;
import com.abacogroup.cropplan.sdk.spi.BusinessPlugin;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.MaxRowsResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.jdbi.paging.impl.MaxRowsResultsImpl;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

public class BusinessPluginImpl implements BusinessPlugin, InitializablePlugin
{
	private static final String JDBI_NAME_SITIKNOW = "dbSitiknow";
	//private static final String SSO2_URL_PROPERTY_NAME = "sso2url";
	private static int PAGE_SIZE = 50;

	private BusinessSitiknowDAO businessSitiknowDAO;
	private AuthSitiknowDAO authSitiknowDAO;

	@Override
	public void initialize(PluginsEnvironment env)
	{
		var jdbiSitiknow = env.getJdbi(JDBI_NAME_SITIKNOW);
		if (jdbiSitiknow == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITIKNOW);

		businessSitiknowDAO = jdbiSitiknow.onDemand(BusinessSitiknowDAO.class);
		authSitiknowDAO = jdbiSitiknow.onDemand(AuthSitiknowDAO.class);
	}

	@Override
	public Business getBusinessDetails(RuntimeEnvironment env, String businessId)
	{
		return businessSitiknowDAO.getBusiness(businessId);
	}

	@Override
	public MaxRowsResults<Business> searchBusinesses(RuntimeEnvironment env, String search)
	{
		var uppp = new UserProxyPairProvider(env.getSso2Client());
		var userName = uppp.getUserProxyPair(env.getUser()).getUserName();
		var onlyEmpowered = true;

		var canIngoreProxies = AuthUtils.canIgnoreProxies(userName, authSitiknowDAO);
		if (canIngoreProxies)
			onlyEmpowered = false;

		if (onlyEmpowered)
		{
			var singleBusiness = businessSitiknowDAO.getSinglePkCuaa(userName);
			if (singleBusiness > 0)
			{
				return new MaxRowsResultsImpl<>(
					Arrays.asList(businessSitiknowDAO.getBusiness(String.valueOf(singleBusiness))), false);
			}
		}

		final var fOnlyEmpowered = onlyEmpowered;
		return businessSitiknowDAO.maxRows(
				() -> businessSitiknowDAO.getBusinesses(userName, fOnlyEmpowered, search), PAGE_SIZE);
	}
	
	@Override
	public InfiniteListResults<Business> searchBusinessesInfinite(RuntimeEnvironment env, String search, String nextKey) 
	{
		var uppp = new UserProxyPairProvider(env.getSso2Client());
		var userName = uppp.getUserProxyPair(env.getUser()).getUserName();
		var onlyEmpowered = true;

		var canIngoreProxies = AuthUtils.canIgnoreProxies(userName, authSitiknowDAO);
		if (canIngoreProxies)
			onlyEmpowered = false;

		if (onlyEmpowered)
		{
			var singleBusiness = businessSitiknowDAO.getSinglePkCuaa(userName);
			if (singleBusiness > 0)
			{
				return new InfiniteListResultsImpl<>(
					Arrays.asList(businessSitiknowDAO.getBusiness(String.valueOf(singleBusiness))), null);
			}
		}

		final var fOnlyEmpowered = onlyEmpowered;
		return businessSitiknowDAO.infinite(
				() -> businessSitiknowDAO.getBusinesses(userName, fOnlyEmpowered, search), nextKey, PAGE_SIZE);
	}

	/*private String getSSo2Url(RuntimeEnvironment env) {
		if (env.getProperty(SSO2_URL_PROPERTY_NAME) == null || StringUtils.isBlank(String.valueOf(env.getProperty(SSO2_URL_PROPERTY_NAME))))
			throw new IllegalStateException("SSO url not define in config!");
		
		return String.valueOf(env.getProperty(SSO2_URL_PROPERTY_NAME));
	}*/
}
