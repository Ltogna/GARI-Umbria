package com.abacogroup.cropplan.plugins.avepa.dao.ntt;

import org.locationtech.jts.geom.Geometry;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Declarations2024GisInfoData
{
	private String title;
	private Integer area;
	private Geometry mbr;
	private String landUseCode;
	private String landUseDescription;
	private Integer declaredArea;
}
