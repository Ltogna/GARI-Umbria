package com.abacogroup.cropplan.plugins.avepa.dao;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import com.abacogroup.jdbi.EnhancedSqlObject;

public interface AuthSitiknowDAO extends EnhancedSqlObject
{
	@SqlQuery("select user_custom.can_ignore_proxies(:userId) from dual")
	public Long getCanIgnoreProxies(@Bind("userId") String userId);
	
	@SqlQuery("select user_custom.check_user_proxy(:businessId, §current_timestamp§, :userId, :canManage, 1) from dual")
	public Boolean checkUserProxy(@Bind("businessId") Long businessId, @Bind("userId") String userId, @Bind("canManage") Boolean canManage);
}
