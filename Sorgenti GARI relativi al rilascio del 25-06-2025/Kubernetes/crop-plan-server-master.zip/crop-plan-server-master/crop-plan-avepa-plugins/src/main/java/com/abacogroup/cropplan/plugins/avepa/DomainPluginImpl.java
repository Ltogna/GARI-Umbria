package com.abacogroup.cropplan.plugins.avepa;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

import com.abacogroup.cropplan.plugins.avepa.dao.DomainSitiDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.DomainSitiknowAppsDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.DomainSitiknowDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.DomainSitiknowDAO.FutureParcelIntersectionDates;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.CataloghiLayers;
import com.abacogroup.cropplan.sdk.model.domain.CadastralParcelData;
import com.abacogroup.cropplan.sdk.model.domain.CadastralParcelOverlapData;
import com.abacogroup.cropplan.sdk.model.domain.DomainZoneGeometry;
import com.abacogroup.cropplan.sdk.model.domain.HoldingArea;
import com.abacogroup.cropplan.sdk.model.domain.Parcel;
import com.abacogroup.cropplan.sdk.model.domain.ParcelData;
import com.abacogroup.cropplan.sdk.model.domain.ParcelDescription;
import com.abacogroup.cropplan.sdk.model.domain.ParcelGeometry;
import com.abacogroup.cropplan.sdk.model.domain.Place;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements.SnapElementType;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements.SnapGeometry;
import com.abacogroup.cropplan.sdk.spi.DomainPlugin;
import com.abacogroup.cropplan.sdk.support.DomainDataSupport;
import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.MaxRowsResults;
import com.abacogroup.jdbi.paging.impl.MaxRowsResultsImpl;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.google.common.collect.Iterators;
import com.google.common.collect.UnmodifiableIterator;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Polygonal;

public class DomainPluginImpl implements DomainPlugin, InitializablePlugin {
	private static final String JDBI_NAME_SITI = "dbSiti";
	private static final String JDBI_NAME_SITIKNOW = "dbSitiknow";
	private static final String JDBI_NAME_SITIKNOW_APPS = "dbSitiknowApps";

	private static final int MAX_ROWS = 50;
	private static final int PAGE_SIZE = 50;

	private static final String _P_CODE_WMSLAY = "WMSLAY";
	//private static final String _S_CODE_WMSLAY_PARCELS = "PARCELS_NPR";
	private static final String _S_CODE_WMSLAY_CADPARCELS = "CADPARCELS";
	public static final String SNAP_EL_TYPE_CADPARCEL = "CADPARCEL";

	private DomainSitiDAO domainSitiDAO;
	private DomainSitiknowDAO domainSitiknowDAO;
	private DomainSitiknowAppsDAO domainSitiknowAppsDAO;

	@Override
	public void initialize(PluginsEnvironment env) {
		var jdbiSiti = env.getJdbi(JDBI_NAME_SITI);
		if (jdbiSiti == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITI);

		domainSitiDAO = jdbiSiti.onDemand(DomainSitiDAO.class);

		var jdbiSitiknow = env.getJdbi(JDBI_NAME_SITIKNOW);
		if (jdbiSitiknow == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITIKNOW);

		domainSitiknowDAO = jdbiSitiknow.onDemand(DomainSitiknowDAO.class);
		
		var jdbiSitiknowApps = env.getJdbi(JDBI_NAME_SITIKNOW_APPS);
		if (jdbiSitiknowApps == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITIKNOW_APPS);

		domainSitiknowAppsDAO = jdbiSitiknowApps.onDemand(DomainSitiknowAppsDAO.class);
	}

	@Override
	public HoldingArea getHoldingArea(RuntimeEnvironment env, String businessId, LocalDate pointInTime) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));

		return domainSitiknowDAO.getHoldingArea(businessId, whereDateAtEndOfDay);
	}

	@Override
	public MaxRowsResults<DomainZoneGeometry> getDomainZonesMaxRows(RuntimeEnvironment env, String businessId,
			LocalDate pointInTime, String search, boolean filterByBusiness) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));

		if (filterByBusiness) {
			try {
				return domainSitiknowDAO.maxRows(
						() -> domainSitiknowDAO.getDomainZonesByBusinessId(businessId, whereDateAtEndOfDay, search),
						MAX_ROWS);
			} catch (RuntimeException e) {
				return domainSitiknowDAO.maxRows(
						() -> domainSitiknowDAO.getDomainZonesByBusinessIdNoSdoAggrMbr(businessId, whereDateAtEndOfDay, search),
						MAX_ROWS);
			}
		} else {
			try {
				return domainSitiknowDAO.maxRows(() -> domainSitiknowDAO.getDomainZones(businessId, whereDateAtEndOfDay, search),
						MAX_ROWS);
			} catch (RuntimeException e) {
				return domainSitiknowDAO.maxRows(() -> domainSitiknowDAO.getDomainZonesNoSdoAggrMbr(businessId, whereDateAtEndOfDay, search),
						MAX_ROWS);
			}
		}
	}

	@Override
	public InfiniteListResults<DomainZoneGeometry> getDomainZonesInfinite(RuntimeEnvironment env, String businessId,
			LocalDate pointInTime, String search, boolean filterByBusiness, String nextKey) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));

		if (filterByBusiness) {
			try {
				return domainSitiknowDAO.infinite(
						() -> domainSitiknowDAO.getDomainZonesByBusinessId(businessId, whereDateAtEndOfDay, search),
						nextKey,
						PAGE_SIZE);
			} catch (RuntimeException e) {
				return domainSitiknowDAO.infinite(
						() -> domainSitiknowDAO.getDomainZonesByBusinessIdNoSdoAggrMbr(businessId, whereDateAtEndOfDay, search),
						nextKey,
						PAGE_SIZE);
			}
		} else {
			try {
				return domainSitiknowDAO.infinite(() -> domainSitiknowDAO.getDomainZones(businessId, whereDateAtEndOfDay, search),
						nextKey,
						PAGE_SIZE);
			} catch (RuntimeException e) {
				return domainSitiknowDAO.infinite(() -> domainSitiknowDAO.getDomainZonesNoSdoAggrMbr(businessId, whereDateAtEndOfDay, search),
						nextKey,
						PAGE_SIZE);
			}
		}
	}
	
	@Override
	public MaxRowsResults<DomainZoneGeometry> getDomainZonesByIdsMaxRows(RuntimeEnvironment env, String businessId, String search, List<String> domainZoneIds) {
		return domainSitiknowDAO.maxRows(
				() -> domainSitiknowDAO.getDomainZonesByIds(search, domainZoneIds),
				MAX_ROWS);
	}
	
	@Override
	public InfiniteListResults<DomainZoneGeometry> getDomainZonesByIdsInfinite(RuntimeEnvironment env, String businessId, String search,
			List<String> domainZoneIds, String nextKey) {
		return domainSitiknowDAO.infinite(() -> domainSitiknowDAO.getDomainZonesByIds(search, domainZoneIds),
				nextKey,
				PAGE_SIZE);
	}

	@Override
	public DomainZoneGeometry getDomainZone(RuntimeEnvironment env, String businessId,
			LocalDate pointInTime, String domainZoneId) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));

		try {
			return domainSitiknowDAO.getDomainZone(businessId, whereDateAtEndOfDay, domainZoneId);
		} catch (RuntimeException e) {
			return domainSitiknowDAO.getDomainZoneNoSdoAggrMbr(businessId, whereDateAtEndOfDay, domainZoneId);
		}
	}
	
	@Override
	public DomainZoneGeometry getDomainZoneByCode(RuntimeEnvironment env, String businessId,
			LocalDate pointInTime, String domainZoneCode) {
		return getDomainZone(env, businessId, pointInTime, domainZoneCode);
	}

	@Override
	public String getDomainZoneDescription(RuntimeEnvironment env, LocalDate pointInTime, String domainZoneId) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));

		return domainSitiknowDAO.getDomainZoneDescription(whereDateAtEndOfDay, domainZoneId);
	}

	@Override
	public HoldingArea getHoldingAreaByDomainZone(RuntimeEnvironment env, String businessId,
			String domainZoneId, LocalDate pointInTime) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));

		return domainSitiknowDAO.getHoldingAreaByDomainZones(businessId, domainZoneId, whereDateAtEndOfDay);
	}

	@Override
	public SnapElements getSnapGeometries(RuntimeEnvironment env, String businessId, String domainZoneId,
			List<String> snapElementTypes, LocalDate pointInTime) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));

		var types = new ArrayList<SnapElementType>();
		var geoms = new ArrayList<SnapGeometry>();
		SnapElementType type;

		Geometry touchingGeometry = Utils.reducePrecision(domainSitiknowDAO.getDomainParcelsGeom(businessId, whereDateAtEndOfDay, domainZoneId), true, true);

		// CADPARCEL
		if (null == snapElementTypes || snapElementTypes.contains(SNAP_EL_TYPE_CADPARCEL)) {
			type = new SnapElementType();
			type.setType(SNAP_EL_TYPE_CADPARCEL);
			String intlnCadParcels = domainSitiknowDAO.getDecodedIntlnDescription(_P_CODE_WMSLAY, _S_CODE_WMSLAY_CADPARCELS, env.getLocale().getLanguage());
			type.setDescription(intlnCadParcels != null ? intlnCadParcels : _S_CODE_WMSLAY_CADPARCELS);
			types.add(type);
			geoms.addAll(domainSitiDAO.getCadastralParcelsSnapGeometries(businessId, whereDateAtEndOfDay, domainZoneId, touchingGeometry));
		}
		
		/* CATALOGHI */
		for (var cl : CataloghiLayers.getCataloghiLayers(domainSitiDAO, touchingGeometry)) {
			if (cl.isSnappable() && (null == snapElementTypes || snapElementTypes.contains(cl.getLayerCode()))) {
				type = new SnapElementType();
				type.setType(cl.getLayerCode());
				type.setDescription(cl.getLayerDescription());
				types.add(type);
				geoms.addAll(cl.getSnapGeometry());
			}
		}
		
		var ret = new SnapElements();
		ret.setTypes(types);
		ret.setGeometries(geoms);
		return ret;
	}

	@Override
	public Map<String, ParcelDescription> getParcelsDescription(RuntimeEnvironment env, String businessId,
			LocalDate pointInTime, List<String> parcelCodes) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));
		List<ParcelDescription> parcelsDescription = new ArrayList<>();
		
		UnmodifiableIterator<List<String>> partitions = Iterators.partition(parcelCodes.iterator(), 666);
		partitions.forEachRemaining(partition -> parcelsDescription.addAll(domainSitiknowDAO.getParcelsDescription(businessId, whereDateAtEndOfDay, partition)));
		
		Map<String, ParcelDescription> pds = parcelsDescription.stream()
				.collect(toMap(ParcelDescription::getCode, pd -> pd));
		
		if (pds.keySet().size() != parcelCodes.size()) {
			List<String> parcelCodesNotFound = parcelCodes.stream()
				.filter(pc -> pds.get(pc) == null)
				.collect(toList());
			
			partitions = Iterators.partition(parcelCodesNotFound.iterator(), 666);
			partitions.forEachRemaining(partition -> {
				List<ParcelDescription> parcelsDescriptionNotFound = domainSitiknowDAO.getParcelsDescriptionFromIsolaNprId(businessId, whereDateAtEndOfDay, partition);
				Map<String, List<ParcelDescription>> mapParcelsDescriptionNotFound = parcelsDescriptionNotFound.stream()
					.collect(groupingBy(ParcelDescription::getCode));
				parcelsDescriptionNotFound = mapParcelsDescriptionNotFound.entrySet().stream()
					.map(e -> e.getValue().get(0))
					.collect(toList());
				parcelsDescription.addAll(parcelsDescriptionNotFound);
			});
			
			return parcelsDescription.stream()
					.collect(toMap(ParcelDescription::getCode, pd -> pd));
		} else  
			return pds;
	}

	@Override
	public Map<String, Polygonal> getParcels(RuntimeEnvironment env, String businessId, String domainZoneId,
			LocalDate pointInTime, Geometry touchingGeometry) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));
		
		List<ParcelGeometry> parcelsGeometry = new ArrayList<>();
		try {
			parcelsGeometry.addAll(domainSitiknowDAO.getParcels(businessId, whereDateAtEndOfDay, domainZoneId, touchingGeometry));
		} catch (Exception e) {
			List<String> parcelsCodes = new ArrayList<>();
			domainSitiknowDAO.getParcelsCodes(touchingGeometry, parcelsCodes::add);
			
			UnmodifiableIterator<List<String>> partitions = Iterators.partition(parcelsCodes.iterator(), 666);
			partitions.forEachRemaining(partition -> parcelsGeometry.addAll(domainSitiknowDAO.getParcels(businessId, whereDateAtEndOfDay, domainZoneId, partition, touchingGeometry)));
		}
		
		return parcelsGeometry.stream()
				.filter(pg -> pg.getGeom() != null)
				.collect(toMap(ParcelGeometry::getCode, pg -> (Polygonal) pg.getGeom()));
	}
	
	@Override
	public List<Parcel> getAllParcels(RuntimeEnvironment env, String businessId, String domainZoneId, LocalDate pointInTime, Geometry touchingGeometry) {
		List<Parcel> parcels = new ArrayList<>();
		try {
			parcels.addAll(domainSitiknowDAO.getAllParcels(businessId, domainZoneId, touchingGeometry));
		} catch (Exception e) {
			List<String> parcelsCodes = new ArrayList<>();
			domainSitiknowDAO.getParcelsCodes(touchingGeometry, parcelsCodes::add);
			
			UnmodifiableIterator<List<String>> partitions = Iterators.partition(parcelsCodes.iterator(), 666);
			partitions.forEachRemaining(partition -> parcels.addAll(domainSitiknowDAO.getAllParcels(businessId, domainZoneId, partition, touchingGeometry)));
		}
				
		return parcels.stream()
				.filter(p -> p.getGeom() != null)
				.collect(toList());
	}

	@Override
	public List<Parcel> getCopyCampaignParcels(RuntimeEnvironment env, String businessId, String domainZoneId, LocalDate pointInTime) {
		return new ArrayList<>();
	}

	@Override
	public List<Parcel> getParcelsByParcelCodes(RuntimeEnvironment env, String businessId, String domainZoneId, List<String> parcelCodes,
			LocalDate pointInTime) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));

		List<Parcel> parcels = new ArrayList<>();

		UnmodifiableIterator<List<String>> partitions = Iterators.partition(parcelCodes.iterator(), 500);
		partitions.forEachRemaining(
				partition -> parcels.addAll(domainSitiknowDAO.getParcelsByParcelCodes(businessId, domainZoneId, whereDateAtEndOfDay, partition)));

		return parcels.stream()
				.filter(p -> p.getGeom() != null)
				.collect(toList());
	}

	@Override
	public List<LocalDate> getFutureParcelsIntersections(RuntimeEnvironment env, String businessId,
			String domainZoneId, LocalDate pointInTime, Geometry touchingGeometry) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));

		List<FutureParcelIntersectionDates> intersections = domainSitiknowDAO.getFutureParcelsIntersections(businessId,
				whereDateAtEndOfDay, domainZoneId, touchingGeometry);

		return intersections.stream()
				.flatMap(i -> Stream.of(i.getD1(), i.getD2(), i.getD3(), i.getD4()))
				.distinct()
				.filter(i -> i.isAfter(pointInTime)).filter(i -> i.isBefore(LocalDate.of(9999, 12, 31)))
				.collect(toList());
	}

	@Override
	public String getParcelLandCoverCode(RuntimeEnvironment env, String businessId, String parcelCode,
			LocalDate pointInTime) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));

		var landCoverCodes = domainSitiknowDAO.getParcelsLandCoverCodes(whereDateAtEndOfDay, parcelCode);
		return landCoverCodes.size() > 0 ? landCoverCodes.get(0) : null;
	}

	@Override
	public Geometry getMBROverview(RuntimeEnvironment env, String businessId, List<String> parcelCodes, LocalDate pointInTime) {
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));

		if (parcelCodes.size() > 0) {
			var geoms = domainSitiknowDAO.getParcelsMbr(businessId, whereDateAtEndOfDay, parcelCodes);
			if (geoms.size() > 0)
				return Utils.getUnion(geoms).getEnvelope();
		}
		return null;
	}

	@Override
	public MaxRowsResults<Place> getPlaces(RuntimeEnvironment env, String businessId, String domainZoneId, String search) {
		return new MaxRowsResultsImpl<>(new ArrayList<>(), false);
	}

	@Override
	public InfiniteListResults<ParcelData> getParcelsData(RuntimeEnvironment env, String businessId, String domainZoneId, 
			LocalDate pointInTime, String nextKey, DomainDataSupport support) {
		
		final LocalDateTime whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));
		InfiniteListResults<ParcelData> parcelsDataInfiniteList = domainSitiknowDAO.infinite(
				() -> domainSitiknowDAO.getParcelsData(businessId, domainZoneId, null, whereDateAtEndOfDay), 
				nextKey, 
				PAGE_SIZE);
		
		Map<String, List<ParcelData>> parcelsDataByParcelCode = parcelsDataInfiniteList.getRecords().stream()
				.collect(groupingBy(ParcelData::getParcelCode));
		domainSitiknowDAO.getParcelsDescription(businessId, whereDateAtEndOfDay, new ArrayList<>(parcelsDataByParcelCode.keySet())).forEach(pd ->
			parcelsDataByParcelCode.get(pd.getCode()).forEach(p -> 
				p.setDescription(pd.getDescription())
			)
		);	
		
		parcelsDataInfiniteList.getRecords().forEach(element -> 
			element.setLandCovers(domainSitiknowDAO.getLandCovers(whereDateAtEndOfDay, element.getParcelCode()))
		);
		
		return parcelsDataInfiniteList;
	}

	@Override
	public InfiniteListResults<CadastralParcelData> getCadastralParcelsData(RuntimeEnvironment env, String businessId, String domainZoneId,
			LocalDate pointInTime, String nextKey) {
		
		final LocalDateTime whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));
		return domainSitiDAO.infinite(
				() -> domainSitiDAO.getCadastralParcelData(businessId, domainZoneId, whereDateAtEndOfDay),
				nextKey,
				PAGE_SIZE);
	}
	
	@Override
	public InfiniteListResults<CadastralParcelOverlapData> getCadastralParcelsOverlapsData(RuntimeEnvironment env, String businessId, String domainZoneId,
			LocalDate pointInTime, String nextKey) {
		
		var whereDateAtEndOfDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));
		
		var srs = domainSitiknowDAO.getDomainZone(businessId, whereDateAtEndOfDay, domainZoneId).getSrs();
		
		var councilSectorId = domainSitiknowAppsDAO.getCouncilSectorId(domainZoneId, whereDateAtEndOfDay);
		InfiniteListResults<CadastralParcelOverlapData> parcelsOverlapsDataInfiniteList = domainSitiknowAppsDAO.infinite(
				() -> domainSitiknowAppsDAO.getCadastralParcelsOverlapsData(businessId, councilSectorId, whereDateAtEndOfDay), 
				nextKey, 
				PAGE_SIZE);
		parcelsOverlapsDataInfiniteList.getRecords().forEach(p -> {
			p.setSrs(srs);
		});
		return parcelsOverlapsDataInfiniteList;
	}

	@Override
	public boolean intersectedParcelCodesChanged(RuntimeEnvironment env, String businessId, LocalDate pointInTime,
			List<String> oldIntersectedParcelCodes, List<String> newIntersectedParcelCodes) {
		boolean haveSameSize = oldIntersectedParcelCodes.size() == newIntersectedParcelCodes.size();
		boolean haveSameElements = oldIntersectedParcelCodes.stream()
				.filter(pi -> !newIntersectedParcelCodes.contains(pi))
				.collect(toList())
				.size() == 0;
		if (!haveSameElements && oldIntersectedParcelCodes.size() == 1 && newIntersectedParcelCodes.size() == 1) {			
			var oldLcc = getParcelLandCoverCode(env, businessId, oldIntersectedParcelCodes.get(0), pointInTime);
			var newLcc = getParcelLandCoverCode(env, businessId, newIntersectedParcelCodes.get(0), pointInTime);
			if ((oldLcc == null && newLcc == null) || (oldLcc != null && oldLcc.equals(newLcc)))
				haveSameElements = true;
		}
		return !haveSameSize || !haveSameElements;
	}
	
	@Override
	public String getCropPlanType() {
		return "CROPPLAN";
	}

}
