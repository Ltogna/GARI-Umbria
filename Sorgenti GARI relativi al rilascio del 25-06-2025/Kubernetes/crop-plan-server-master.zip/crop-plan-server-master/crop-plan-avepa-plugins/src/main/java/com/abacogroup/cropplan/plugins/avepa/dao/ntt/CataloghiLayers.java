package com.abacogroup.cropplan.plugins.avepa.dao.ntt;

import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import org.locationtech.jts.geom.Geometry;

import com.abacogroup.cropplan.plugins.avepa.dao.DomainSitiDAO;
import com.abacogroup.cropplan.plugins.avepa.utils.CataloghiLayersUtils;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements.SnapGeometry;
import com.abacogroup.cropplan.sdk.model.layers.GISInfo;
import com.abacogroup.cropplan.sdk.model.layers.GISInfo.GISInfoCard;
import com.abacogroup.cropplan.sdk.model.layers.GISInfo.GISInfoCardField;

public class CataloghiLayers {
	private static String LAYER_DESCRIPTION_PREFIX = "Cataloghi->";
	
	private static String LAYER_SHP_PLT = "SHP_PLT";
	private static String LAYER_DESCRIPTION_SHP_PLT = "Pratiche Locali Tradizionali";
	
	private static String LAYER_SHP_NATURA2000_2017 = "SHP_NATURA2000_2017";
	private static String LAYER_DESCRIPTION_SHP_NATURA2000_2017 = "NATURA 2000 (agg. 2017)";
	
	private static String LAYER_SHP_PIANO_ASSESTAMENTO_TN = "SHP_PIANO_ASSESTAMENTO_TN";
	private static String LAYER_DESCRIPTION_SHP_PIANO_ASSESTAMENTO_TN = "PIANO ASSESTAMENTO TRENTO";
	
	private static String LAYER_SHP_UPAS_TN = "SHP_UPAS_TN";
	private static String LAYER_DESCRIPTION_SHP_UPAS_TN = "UPAS - UNITA' DI PASCOLO TRENTO";

	private static String LAYER_SHP_METANODOTTI = "SHP_METANODOTTI";
	private static String LAYER_DESCRIPTION_SHP_METANODOTTI = "METANODOTTI";
	
	private static String LAYER_SHP_CORPIIDRICI_2022 = "SHP_CORPIIDRICI_2022";
	private static String LAYER_DESCRIPTION_SHP_CORPIIDRICI_2022 = "Corpi Idrici 2022";
	
	private static String LAYER_SHP_FANGHI_2022 = "SHP_FANGHI_2022";
	private static String LAYER_DESCRIPTION_SHP_FANGHI_2022 = "Fanghi 2022";
	
	private static String LAYER_RPPG2023 = "RPPG2023";
	private static String LAYER_DESCRIPTION_RPPG2023 = "RPPG2023 (dati 2022)";

	private static String LAYER_ALTITUDINE1200RECT = "ALTITUDINE1200RECT";
	private static String LAYER_DESCRIPTION_ALTITUDINE1200RECT = "Terreni sopra i 1200m di Altitudine";

	//private static String LAYER_DOMANDE_CONFERMA_14_20 = "DOMANDE_CONFERMA_14_20";
	//private static String LAYER_DESCRIPTION_DOMANDE_CONFERMA_14_20 = "DOMANDE DI CONFERMA";
	
	private static String LAYER_CONFERME_2014_2020 = "CONFERME_2014_2020";
	private static String LAYER_DESCRIPTION_CONFERME_2014_2020 = "DOMANDE DI CONFERMA PSR 2014-2020";
	private static String LAYER_DESCRIPTION_CONFERME_2014_2020_PREFIX = "DOMANDE DI CONFERMA PSR 2014-2020->";
	
	private static String LAYER_CONFERME_2023_2027 = "CONFERME_2023_2027";
	private static String LAYER_DESCRIPTION_CONFERME_2023_2027 = "DOMANDE DI CONFERMA CSR 2023-2027";
	private static String LAYER_DESCRIPTION_CONFERME_2023_2027_PREFIX = "DOMANDE DI CONFERMA CSR 2023-2027->";
	
	private static String LAYER_SHP_ZVN2021 = "SHP_ZVN2021";
	private static String LAYER_DESCRIPTION_SHP_ZVN2021 = "ZVN";
	
	private static String LAYER_SHP_ZONAMONTANA_2015 = "SHP_ZONAMONTANA_2015";
	private static String LAYER_DESCRIPTION_SHP_ZONAMONTANA_2015 = "ZONA MONTANA";


	private static String LAYER_ECOSCHEMI_PREFIX = "IMPEGNI ECOSCHEMI 2023->";

	private static String LAYER_GRASSING_TREE_CROPS = "GRASSING_TREE_CROPS";
	private static String LAYER_DESCRIPTION_GRASSING_TREE_CROPS = "ECO2";
	
	private static String LAYER_SAFEGUARDING_OLIVE_TREE_PLV = "SAFEGUARDING_OLIVE_TREE_PLV";
	private static String LAYER_DESCRIPTION_SAFEGUARDING_OLIVE_TREE_PLV = "ECO3";
	
	private static String LAYER_EXTENSIVE_FORAGE_SYSTEM_ROTATION = "EXTENSIVE_FORAGE_SYSTEM_ROTATION";
	private static String LAYER_DESCRIPTION_EXTENSIVE_FORAGE_SYSTEM_ROTATION = "ECO4";
	
	private static String LAYER_SPECIFIC_MEASURES_POLLINATORS_TREE_CROPS = "SPECIFIC_MEASURES_POLLINATORS_TREE_CROPS";
	private static String LAYER_DESCRIPTION_SPECIFIC_MEASURES_POLLINATORS_TREE_CROPS = "ECO5 Arboree";
	
	private static String LAYER_SPECIFIC_MEASURES_POLLINATORS_ARABLE_LAND = "SPECIFIC_MEASURES_POLLINATORS_ARABLE_LAND";
	private static String LAYER_DESCRIPTION_SPECIFIC_MEASURES_POLLINATORS_ARABLE_LAND = "ECO5 Seminativi";

	private static String LAYER_SHP_CONFINE_OLIO_DOP_VENETO = "SHP_CONFINE_OLIO_DOP_VENETO";
	private static String LAYER_DESCRIPTION_SHP_CONFINE_OLIO_DOP_VENETO = "DENSITA IMPIANTO - ECO3";

	private static String LAYER_SHP_COMUNI_CONTERMINI = "SHP_COMUNI_CONTERMINI";
	private static String LAYER_DESCRIPTION_SHP_COMUNI_CONTERMINI = "COMUNI CONTERMINI";
	
	private static String LAYER_RPPG2024_DEFINITIVI = "RPPG2024_DEFINITIVI";
	private static String LAYER_DESCRIPTION_RPPG2024_DEFINITIVI = "RPPG2024 (definitivi - dati 2023)";
	
	private static String LAYER_RPPG2024_POTENZIALI = "RPPG2024_POTENZIALI";
	private static String LAYER_DESCRIPTION_RPPG2024_POTENZIALI = "RPPG2024 (potenziali - dati 2023)";

	private static String LAYER_SIGRIAN_DISTRETTI_IRRIGUI_VENETO_POA = "SIGRIAN_DISTRETTI_IRRIGUI_VENETO_POA";
	private static String LAYER_DESCRIPTION_SIGRIAN_DISTRETTI_IRRIGUI_VENETO_POA = "SIGRIAN - DISTRETTI IRRIGUI VENETO PER POA";

	public static List<CataloghiLayerDef> getCataloghiLayers(DomainSitiDAO dao, Geometry touchingGeometry) {
		List<CataloghiLayerDef> ret = new ArrayList<>();
		ret.add(new CataloghiLayerDef(LAYER_SHP_PLT, LAYER_DESCRIPTION_PREFIX+LAYER_DESCRIPTION_SHP_PLT, false, true, false) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null) return new ArrayList<>();
				return dao.getShpPltSnapGeometries(touchingGeometry);
			}
		});
		ret.add(new CataloghiLayerDef(LAYER_SHP_NATURA2000_2017, LAYER_DESCRIPTION_PREFIX+LAYER_DESCRIPTION_SHP_NATURA2000_2017, false, false, false) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null) return new ArrayList<>();
				return dao.getShpNaturaSnapGeometries(touchingGeometry);
			}
		});
		ret.add(new CataloghiLayerDef(LAYER_SHP_PIANO_ASSESTAMENTO_TN, LAYER_DESCRIPTION_PREFIX+LAYER_DESCRIPTION_SHP_PIANO_ASSESTAMENTO_TN, false, true, false) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null) return new ArrayList<>();
				return dao.getShpPianoAssestamentoSnapGeometries(touchingGeometry);
			}
		});
		ret.add(new CataloghiLayerDef(LAYER_SHP_UPAS_TN, LAYER_DESCRIPTION_PREFIX+LAYER_DESCRIPTION_SHP_UPAS_TN, false, true, false) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null) return new ArrayList<>();
				return dao.getShpUpasSnapGeometries(touchingGeometry);
			}
		});
		ret.add(new CataloghiLayerDef(LAYER_SHP_METANODOTTI, LAYER_DESCRIPTION_PREFIX+LAYER_DESCRIPTION_SHP_METANODOTTI, false, false, false) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null) return new ArrayList<>();
				return dao.getShpMetanodottiSnapGeometries(touchingGeometry);
			}
		});
		ret.add(new CataloghiLayerDef(LAYER_SHP_CORPIIDRICI_2022, LAYER_DESCRIPTION_PREFIX+LAYER_DESCRIPTION_SHP_CORPIIDRICI_2022, false, true, false) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				List<SnapGeometry> ret = new ArrayList<>();
				if (dao == null || touchingGeometry == null) return ret;
				dao.getShpCorpiIdriciSnapGeometries(touchingGeometry, sg -> {
					ret.add(CataloghiLayersUtils.clipIfNecessary(sg, touchingGeometry));
				});
				return ret;
			}
		});
		ret.add(new CataloghiLayerDef(LAYER_SHP_FANGHI_2022, LAYER_DESCRIPTION_PREFIX+LAYER_DESCRIPTION_SHP_FANGHI_2022, false, false, false) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null) return new ArrayList<>();
				return dao.getShpFanghiSnapGeometries(touchingGeometry);
			}
		});
		ret.add(new CataloghiLayerDef(LAYER_RPPG2023, LAYER_DESCRIPTION_PREFIX + LAYER_DESCRIPTION_RPPG2023, false, true, false) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null)
					return new ArrayList<>();
				return dao.getShpRppg2022SnapGeometries(touchingGeometry);
			}
		});
		ret.add(new CataloghiLayerDef(LAYER_ALTITUDINE1200RECT, LAYER_DESCRIPTION_PREFIX + LAYER_DESCRIPTION_ALTITUDINE1200RECT, false, false, false) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null)
					return new ArrayList<>();
				return dao.getShpAltitudine1200SnapGeometries(touchingGeometry);
			}
		});
		ret.add(new CataloghiLayerDef(LAYER_SIGRIAN_DISTRETTI_IRRIGUI_VENETO_POA,
				LAYER_DESCRIPTION_PREFIX + LAYER_DESCRIPTION_SIGRIAN_DISTRETTI_IRRIGUI_VENETO_POA, true, false, false) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null)
					return new ArrayList<>();
				return dao.getShpDistrettiIrriguiSigrianSnapGeometries(touchingGeometry);
			}
		});
		/*ret.add(new CataloghiLayerDef(LAYER_DOMANDE_CONFERMA_14_20, LAYER_DESCRIPTION_PREFIX + LAYER_DESCRIPTION_DOMANDE_CONFERMA_14_20, false) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null)
					return new ArrayList<>();
				return dao.getShpDomandeConferma1420SnapGeometries(touchingGeometry);
			}
		});*/
		List<String> conferme2014_2020OptionCodes = dao.getLayerConfermeOptionCodes(LAYER_CONFERME_2014_2020, 2023);
		for (String optionCode : conferme2014_2020OptionCodes) {
			String layerCode = LAYER_CONFERME_2014_2020+"-"+optionCode.replace(".", "_");
			ret.add(new CataloghiLayerDef(layerCode, LAYER_DESCRIPTION_CONFERME_2014_2020_PREFIX + optionCode, true, true, true) {
				@Override
				public List<SnapGeometry> getSnapGeometry() {
					if (dao == null || touchingGeometry == null)
						return new ArrayList<>();
					return dao.getLayerConfermeSnapGeometries(LAYER_CONFERME_2014_2020, 2023, optionCode, 
							layerCode, LAYER_DESCRIPTION_CONFERME_2014_2020 + " - " + optionCode,
							touchingGeometry);
				}
			});
		}
		List<String> conferme2023_2027OptionCodes = dao.getLayerConfermeOptionCodes(LAYER_CONFERME_2023_2027, 2023);
		for (String optionCode : conferme2023_2027OptionCodes) {
			String layerCode = LAYER_CONFERME_2023_2027+"-"+optionCode.replace(".", "_");
			ret.add(new CataloghiLayerDef(layerCode, LAYER_DESCRIPTION_CONFERME_2023_2027_PREFIX + optionCode, true, true, true) {
				@Override
				public List<SnapGeometry> getSnapGeometry() {
					if (dao == null || touchingGeometry == null)
						return new ArrayList<>();
					return dao.getLayerConfermeSnapGeometries(LAYER_CONFERME_2023_2027, 2023, optionCode, 
							layerCode, LAYER_DESCRIPTION_CONFERME_2023_2027 + " - " + optionCode,
							touchingGeometry);
				}
			});
		}
		ret.add(new CataloghiLayerDef(LAYER_SHP_ZVN2021, LAYER_DESCRIPTION_PREFIX + LAYER_DESCRIPTION_SHP_ZVN2021, false, false, false) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null)
					return new ArrayList<>();
				return dao.getShpZvn2021SnapGeometries(touchingGeometry);
			}
		});
		ret.add(new CataloghiLayerDef(LAYER_SHP_ZONAMONTANA_2015, LAYER_DESCRIPTION_PREFIX + LAYER_DESCRIPTION_SHP_ZONAMONTANA_2015, false, false, false) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null)
					return new ArrayList<>();
				return dao.getShpZonaMontana2015SnapGeometries(touchingGeometry);
			}
		});

		// --- START ECOSCHEMI
		ret.add(new CataloghiLayerDef(LAYER_GRASSING_TREE_CROPS, LAYER_ECOSCHEMI_PREFIX + LAYER_DESCRIPTION_GRASSING_TREE_CROPS, true, true, true) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null)
					return new ArrayList<>();
				return dao.getEcoschemiSnapGeometries(touchingGeometry, 2023, LAYER_GRASSING_TREE_CROPS, LAYER_GRASSING_TREE_CROPS, LAYER_ECOSCHEMI_PREFIX + LAYER_DESCRIPTION_GRASSING_TREE_CROPS);
			}
		});
		ret.add(new CataloghiLayerDef(LAYER_SAFEGUARDING_OLIVE_TREE_PLV, LAYER_ECOSCHEMI_PREFIX + LAYER_DESCRIPTION_SAFEGUARDING_OLIVE_TREE_PLV, true, true, true) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null)
					return new ArrayList<>();
				return dao.getEcoschemiSnapGeometries(touchingGeometry, 2023, LAYER_SAFEGUARDING_OLIVE_TREE_PLV, LAYER_SAFEGUARDING_OLIVE_TREE_PLV, LAYER_ECOSCHEMI_PREFIX + LAYER_DESCRIPTION_SAFEGUARDING_OLIVE_TREE_PLV);
			}
		});
		ret.add(new CataloghiLayerDef(LAYER_EXTENSIVE_FORAGE_SYSTEM_ROTATION, LAYER_ECOSCHEMI_PREFIX + LAYER_DESCRIPTION_EXTENSIVE_FORAGE_SYSTEM_ROTATION, true, true, true) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null)
					return new ArrayList<>();
				return dao.getEcoschemiSnapGeometries(touchingGeometry, 2023, LAYER_EXTENSIVE_FORAGE_SYSTEM_ROTATION, LAYER_EXTENSIVE_FORAGE_SYSTEM_ROTATION, LAYER_ECOSCHEMI_PREFIX + LAYER_DESCRIPTION_EXTENSIVE_FORAGE_SYSTEM_ROTATION);
			}
		});
		ret.add(new CataloghiLayerDef(LAYER_SPECIFIC_MEASURES_POLLINATORS_TREE_CROPS, LAYER_ECOSCHEMI_PREFIX + LAYER_DESCRIPTION_SPECIFIC_MEASURES_POLLINATORS_TREE_CROPS, true, true, true) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null)
					return new ArrayList<>();
				return dao.getEcoschemiSnapGeometries(touchingGeometry, 2023, LAYER_SPECIFIC_MEASURES_POLLINATORS_TREE_CROPS, LAYER_SPECIFIC_MEASURES_POLLINATORS_TREE_CROPS, LAYER_ECOSCHEMI_PREFIX + LAYER_DESCRIPTION_SPECIFIC_MEASURES_POLLINATORS_TREE_CROPS);
			}
		});
		ret.add(new CataloghiLayerDef(LAYER_SPECIFIC_MEASURES_POLLINATORS_ARABLE_LAND, LAYER_ECOSCHEMI_PREFIX + LAYER_DESCRIPTION_SPECIFIC_MEASURES_POLLINATORS_ARABLE_LAND, true, true, true) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null)
					return new ArrayList<>();
				return dao.getEcoschemiSnapGeometries(touchingGeometry, 2023, LAYER_SPECIFIC_MEASURES_POLLINATORS_ARABLE_LAND, LAYER_SPECIFIC_MEASURES_POLLINATORS_ARABLE_LAND, LAYER_ECOSCHEMI_PREFIX + LAYER_DESCRIPTION_SPECIFIC_MEASURES_POLLINATORS_ARABLE_LAND);
			}
		});
		// --- END ECOSCHEMI

		ret.add(new CataloghiLayerDef(LAYER_SHP_COMUNI_CONTERMINI, LAYER_DESCRIPTION_PREFIX + LAYER_DESCRIPTION_SHP_COMUNI_CONTERMINI, true, true, false) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if(dao == null || touchingGeometry == null)
					return new ArrayList<>();
				return dao.getShpComuniConterminiSnapGeometries(touchingGeometry);
			}
		});
		ret.add(new CataloghiLayerDef(LAYER_SHP_CONFINE_OLIO_DOP_VENETO, LAYER_DESCRIPTION_PREFIX + LAYER_DESCRIPTION_SHP_CONFINE_OLIO_DOP_VENETO, true, true, false) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null)
					return new ArrayList<>();
				return dao.getShpConfineOlioDopVenetoSnapGeometries(touchingGeometry);
			}
		});
		ret.add(new CataloghiLayerDef(LAYER_RPPG2024_DEFINITIVI, LAYER_DESCRIPTION_PREFIX + LAYER_DESCRIPTION_RPPG2024_DEFINITIVI, true, true, true) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null)
					return new ArrayList<>();
				return dao.getShpRppg2023DefinitiviSnapGeometries(touchingGeometry);
			}
		});
		ret.add(new CataloghiLayerDef(LAYER_RPPG2024_POTENZIALI, LAYER_DESCRIPTION_PREFIX + LAYER_DESCRIPTION_RPPG2024_POTENZIALI, true, true, true) {
			@Override
			public List<SnapGeometry> getSnapGeometry() {
				if (dao == null || touchingGeometry == null)
					return new ArrayList<>();
				return dao.getShpRppg2023PotenzialiSnapGeometries(touchingGeometry);
			}
		});

		return ret.stream()
			.sorted(Comparator.comparing(CataloghiLayerDef::getLayerDescription).reversed())
			.collect(toList());
	}
	
	public static List<GISInfo> getCataloghiLayersGISInfos(DomainSitiDAO dao, List<String> layerCodes, Geometry touchingGeometry) {
		ArrayList<GISInfo> gisInfos = new ArrayList<>();
		
		if (layerCodes.contains(LAYER_SHP_CORPIIDRICI_2022)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_SHP_CORPIIDRICI_2022);
			gisInfo.setTitle(LAYER_DESCRIPTION_SHP_CORPIIDRICI_2022);
			gisInfo.setCards(new LinkedList<>());

			List<ShpCorpiIdriciGisInfoData> gisInfoData = dao.getShpCorpiIdriciGisInfoData(touchingGeometry);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(
					new GISInfoCard(
							gis.getTitle(),
							null,
							gis.getMbr(),
							List.of(new GISInfoCardField("BCAA1 PAC 2014-2022", gis.getBcaa1()),
									new GISInfoCardField("BCAA4 del 2023-2027", gis.getBcaa2()),
									new GISInfoCardField("Descrizione", gis.getDescrizione()),
									new GISInfoCardField("Inizio", gis.getInizio()),
									new GISInfoCardField("Fine", gis.getFine())))));
			if (gisInfo.getCards().size() > 0)
				gisInfos.add(gisInfo);
		}
		
		/*if (layerCodes.contains(LAYER_DOMANDE_CONFERMA_14_20)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_DOMANDE_CONFERMA_14_20);
			gisInfo.setTitle(LAYER_DESCRIPTION_DOMANDE_CONFERMA_14_20);
			gisInfo.setCards(new LinkedList<>());

			List<ShpDomandeConferma1420GisInfoData> gisInfoData = dao.getShpDomandeConferma1420GisInfoData(touchingGeometry);
			gisInfoData.forEach(gis -> {
				StringBuilder partCatast = new StringBuilder()
						.append(gis.getCod_nazionale())
						.append(" - ")
						.append(gis.getFoglio())
						.append(" - ")
						.append(gis.getParticella());

				if (StringUtils.isNotBlank(gis.getSub())) {
					partCatast.append("/").append(gis.getSub());
				}

				gisInfo.getCards().add(
						new GISInfoCard(
								gis.getTitle(),
								null,
								gis.getMbr(),
								List.of(new GISInfoCardField("Anno di Rif.", gis.getAnno_riferimento().toString()),
										new GISInfoCardField("Codice Interv.", gis.getCodice_intervento()),
										new GISInfoCardField("Anno Dom. Iniz.", gis.getAnno_domanda_iniziale().toString()),
										new GISInfoCardField("Area Conferm.", gis.getArea_confermata().toString()),
										new GISInfoCardField("Area GIS", gis.getArea_grafica_poligono().toString()),
										new GISInfoCardField("Part. Catast.", partCatast.toString()))));
			});

			if (gisInfo.getCards().size() > 0)
				gisInfos.add(gisInfo);
		}*/
		
		if (layerCodes.stream()
				.filter(layerCode -> layerCode.startsWith(LAYER_CONFERME_2014_2020 + "-"))
				.count() > 0) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_CONFERME_2014_2020);
			gisInfo.setTitle(LAYER_DESCRIPTION_CONFERME_2014_2020);
			gisInfo.setCards(new LinkedList<>());

			List<LayerConfermeGisInfoData> gisInfoData = dao.getLayerConfermeGisInfoData(LAYER_CONFERME_2014_2020, 2023, touchingGeometry);
			gisInfoData.forEach(gis -> {
				StringBuilder partCatast = gis.getCod_nazionale() != null && gis.getFoglio() != null? new StringBuilder()
						.append(gis.getCod_nazionale())
						.append(" - ")
						.append(gis.getFoglio()) : null;

				gisInfo.getCards().add(
						new GISInfoCard(
								gis.getTitle(),
								null,
								gis.getMbr(),
								List.of(new GISInfoCardField("Anno di Rif.", gis.getAnno_riferimento().toString()),
										new GISInfoCardField("Codice Interv.", gis.getCodice_intervento()),
										new GISInfoCardField("Anno Dom. Iniz.", gis.getAnno_domanda_iniziale().toString()),
										new GISInfoCardField("Area Conferm.", gis.getArea_confermata().toString()),
										new GISInfoCardField("Area GIS", gis.getArea_grafica_poligono().toString()),
										new GISInfoCardField("Part. Catast.", partCatast != null ? partCatast.toString() : "N.D."))));
			});

			if (gisInfo.getCards().size() > 0)
				gisInfos.add(gisInfo);
		}
		
		if (layerCodes.stream()
				.filter(layerCode -> layerCode.startsWith(LAYER_CONFERME_2023_2027 + "-"))
				.count() > 0) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_CONFERME_2023_2027);
			gisInfo.setTitle(LAYER_DESCRIPTION_CONFERME_2023_2027);
			gisInfo.setCards(new LinkedList<>());

			List<LayerConfermeGisInfoData> gisInfoData = dao.getLayerConfermeGisInfoData(LAYER_CONFERME_2023_2027, 2023, touchingGeometry);
			gisInfoData.forEach(gis -> {
				StringBuilder partCatast = gis.getCod_nazionale() != null && gis.getFoglio() != null? new StringBuilder()
						.append(gis.getCod_nazionale())
						.append(" - ")
						.append(gis.getFoglio()) : null;

				gisInfo.getCards().add(
						new GISInfoCard(
								gis.getTitle(),
								null,
								gis.getMbr(),
								List.of(new GISInfoCardField("Anno di Rif.", gis.getAnno_riferimento().toString()),
										new GISInfoCardField("Codice Interv.", gis.getCodice_intervento()),
										new GISInfoCardField("Anno Dom. Iniz.", gis.getAnno_domanda_iniziale().toString()),
										new GISInfoCardField("Area Conferm.", gis.getArea_confermata().toString()),
										new GISInfoCardField("Area GIS", gis.getArea_grafica_poligono().toString()),
										new GISInfoCardField("Part. Catast.", partCatast != null ? partCatast.toString() : "N.D."))));
			});

			if (gisInfo.getCards().size() > 0)
				gisInfos.add(gisInfo);
		}
		
		if (layerCodes.contains(LAYER_SHP_FANGHI_2022)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_SHP_FANGHI_2022);
			gisInfo.setTitle(LAYER_DESCRIPTION_SHP_FANGHI_2022);
			gisInfo.setCards(new LinkedList<>());

			List<ShpFanghiGisInfoData> gisInfoData = dao.getShpFanghiGisInfoData(touchingGeometry);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(
					new GISInfoCard(
							gis.getTitle(),
							null,
							gis.getMbr(),
							List.of(new GISInfoCardField("Comune", gis.getComune()),
									new GISInfoCardField("Foglio", gis.getFoglio()),
									new GISInfoCardField("Particella", gis.getParticella())))));
			if (gisInfo.getCards().size() > 0)
				gisInfos.add(gisInfo);
		}
		
		if (layerCodes.contains(LAYER_SHP_METANODOTTI)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_SHP_METANODOTTI);
			gisInfo.setTitle(LAYER_DESCRIPTION_SHP_METANODOTTI);
			gisInfo.setCards(new LinkedList<>());

			List<ShpMetanodottiGisInfoData> gisInfoData = dao.getShpMetanodottiGifInfoData(touchingGeometry);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(
					new GISInfoCard(
							gis.getTitle(),
							null,
							gis.getMbr(),
							List.of(new GISInfoCardField("Proponente", gis.getProponente()),
									new GISInfoCardField("Descrizione", gis.getDescrizione())))));
			if (gisInfo.getCards().size() > 0)
				gisInfos.add(gisInfo);
		}
		
		if (layerCodes.contains(LAYER_SHP_NATURA2000_2017)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_SHP_NATURA2000_2017);
			gisInfo.setTitle(LAYER_DESCRIPTION_SHP_NATURA2000_2017);
			gisInfo.setCards(new LinkedList<>());

			List<ShpNaturaGisInfoData> gisInfoData = dao.getShpNaturaGisInfoData(touchingGeometry);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(
					new GISInfoCard(
							gis.getTitle(),
							gis.getArea(),
							gis.getMbr(),
							List.of(new GISInfoCardField("Tipologia della zona", gis.getTipoSito()),
									new GISInfoCardField("Regione biogeografica", gis.getRegBiogeo()),
									new GISInfoCardField("Regione", gis.getRegione()),
									new GISInfoCardField("Data inizio", gis.getDataInizio()),
									new GISInfoCardField("Data fine", gis.getDataFine())))));
			if (gisInfo.getCards().size() > 0)
				gisInfos.add(gisInfo);
		}
		
		if (layerCodes.contains(LAYER_SHP_PIANO_ASSESTAMENTO_TN)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_SHP_PIANO_ASSESTAMENTO_TN);
			gisInfo.setTitle(LAYER_DESCRIPTION_SHP_PIANO_ASSESTAMENTO_TN);
			gisInfo.setCards(new LinkedList<>());

			List<ShpPianoAssestamentoGisInfoData> gisInfoData = dao.getShpPianoAssestamentoGisInfoData(touchingGeometry);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(
					new GISInfoCard(
							gis.getTitle(),
							gis.getArea(),
							gis.getMbr(),
							List.of(new GISInfoCardField("Anno inizio", gis.getAnnoInizio()),
									new GISInfoCardField("Anno fine", gis.getAnnoFine())))));
			if (gisInfo.getCards().size() > 0)
				gisInfos.add(gisInfo);
		}
		
		if (layerCodes.contains(LAYER_SHP_PLT)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_SHP_PLT);
			gisInfo.setTitle(LAYER_DESCRIPTION_SHP_PLT);
			gisInfo.setCards(new LinkedList<>());

			List<ShpPltGisInfoData> gisInfoData = dao.getShpPltGisInfoData(touchingGeometry);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(
					new GISInfoCard(
							gis.getTitle(),
							gis.getArea(),
							gis.getMbr(),
							List.of(new GISInfoCardField("Note tecniche sulla zona", gis.getNote())))));
			if (gisInfo.getCards().size() > 0)
				gisInfos.add(gisInfo);
		}
		
		if (layerCodes.contains(LAYER_RPPG2023)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_RPPG2023);
			gisInfo.setTitle(LAYER_DESCRIPTION_RPPG2023);
			gisInfo.setCards(new LinkedList<>());

			List<ShpRppg2022GisInfoData> gisInfoData = dao.getShpRppg2022GisInfoData(touchingGeometry);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(
					new GISInfoCard(
							gis.getTitle(),
							null,
							gis.getMbr(),
							List.of(new GISInfoCardField("ID", gis.getId().toString()),
									new GISInfoCardField("Codice ISTAT Regione", gis.getIstatr()),
									new GISInfoCardField("Superficie (mq)", gis.getArea().toString()),
									new GISInfoCardField("Anno Registrazione", gis.getYear())))));
			if (gisInfo.getCards().size() > 0)
				gisInfos.add(gisInfo);
		}
		
		if (layerCodes.contains(LAYER_SHP_UPAS_TN)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_SHP_UPAS_TN);
			gisInfo.setTitle(LAYER_DESCRIPTION_SHP_UPAS_TN);
			gisInfo.setCards(new LinkedList<>());

			List<ShpUpasGisInfoData> gisInfoData = dao.getShpUpasGisInfoData(touchingGeometry);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(
					new GISInfoCard(
							gis.getTitle(),
							gis.getArea(),
							gis.getMbr(),
							List.of(new GISInfoCardField("Nome piano", gis.getNomePiano()),
									new GISInfoCardField("Malga B", gis.getMalgaB()),
									new GISInfoCardField("Malga P", gis.getMalgaP()),
									new GISInfoCardField("Anno inizio", gis.getAnnoInizio()),
									new GISInfoCardField("Anno fine", gis.getAnnoFine())))));
			if (gisInfo.getCards().size() > 0)
				gisInfos.add(gisInfo);
		}
		
		if (layerCodes.contains(LAYER_SHP_ZONAMONTANA_2015)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_SHP_ZONAMONTANA_2015);
			gisInfo.setTitle(LAYER_DESCRIPTION_SHP_ZONAMONTANA_2015);
			gisInfo.setCards(new LinkedList<>());

			List<ShpZonaMontana2015GisInfoData> gisInfoData = dao.getShpZonaMontana2015GisInfoData(touchingGeometry);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(
					new GISInfoCard(
							gis.getTitle(),
							null,
							gis.getMbr(),
							List.of(new GISInfoCardField("Descrizione", gis.getDescrizione())))));
			if (gisInfo.getCards().size() > 0)
				gisInfos.add(gisInfo);
		}
		
		if (layerCodes.contains(LAYER_SHP_ZVN2021)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_SHP_ZVN2021);
			gisInfo.setTitle(LAYER_DESCRIPTION_SHP_ZVN2021);
			gisInfo.setCards(new LinkedList<>());

			List<ShpZvn2021GisInfoData> gisInfoData = dao.getShpZvn2021GisInfoData(touchingGeometry);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(
					new GISInfoCard(
							gis.getTitle(),
							null,
							gis.getMbr(),
							List.of(new GISInfoCardField("Codice", gis.getCodice()),
									new GISInfoCardField("Descrizione", gis.getDescrizione())))));
			if (gisInfo.getCards().size() > 0)
				gisInfos.add(gisInfo);
		}
		
		if (layerCodes.contains(LAYER_GRASSING_TREE_CROPS)) {
			GISInfo gisInfo = getEcoschemiGisInfo(dao, touchingGeometry, LAYER_GRASSING_TREE_CROPS, LAYER_DESCRIPTION_GRASSING_TREE_CROPS);
			if (gisInfo != null)
				gisInfos.add(gisInfo);
		}
		if (layerCodes.contains(LAYER_SAFEGUARDING_OLIVE_TREE_PLV)) {
			GISInfo gisInfo = getEcoschemiGisInfo(dao, touchingGeometry, LAYER_SAFEGUARDING_OLIVE_TREE_PLV, LAYER_DESCRIPTION_SAFEGUARDING_OLIVE_TREE_PLV);
			if (gisInfo != null)
				gisInfos.add(gisInfo);
		}
		if (layerCodes.contains(LAYER_EXTENSIVE_FORAGE_SYSTEM_ROTATION)) {
			GISInfo gisInfo = getEcoschemiGisInfo(dao, touchingGeometry, LAYER_EXTENSIVE_FORAGE_SYSTEM_ROTATION, LAYER_DESCRIPTION_EXTENSIVE_FORAGE_SYSTEM_ROTATION);
			if (gisInfo != null)
				gisInfos.add(gisInfo);
		}
		if (layerCodes.contains(LAYER_SPECIFIC_MEASURES_POLLINATORS_TREE_CROPS)) {
			GISInfo gisInfo = getEcoschemiGisInfo(dao, touchingGeometry, LAYER_SPECIFIC_MEASURES_POLLINATORS_TREE_CROPS, LAYER_DESCRIPTION_SPECIFIC_MEASURES_POLLINATORS_TREE_CROPS);
			if (gisInfo != null)
				gisInfos.add(gisInfo);
		}
		if (layerCodes.contains(LAYER_SPECIFIC_MEASURES_POLLINATORS_ARABLE_LAND)) {
			GISInfo gisInfo = getEcoschemiGisInfo(dao, touchingGeometry, LAYER_SPECIFIC_MEASURES_POLLINATORS_ARABLE_LAND, LAYER_DESCRIPTION_SPECIFIC_MEASURES_POLLINATORS_ARABLE_LAND);
			if (gisInfo != null)
				gisInfos.add(gisInfo);
		}

		if (layerCodes.contains(LAYER_SHP_COMUNI_CONTERMINI)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_SHP_COMUNI_CONTERMINI);
			gisInfo.setTitle(LAYER_DESCRIPTION_SHP_COMUNI_CONTERMINI);
			gisInfo.setCards(new LinkedList<>());

			List<ShpComuniContermini> gisInfoData = dao.getShpComuniConterminiGisInfoData(touchingGeometry);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(
					new GISInfoCard(
							gis.getTitle(),
							null,
							gis.getMbr(),
							List.of(new GISInfoCardField("Codice", gis.getCodice()),
									new GISInfoCardField("Nome", gis.getNome()),
									new GISInfoCardField("Sezioni", gis.getSezioni())))));
			if (gisInfo.getCards().size() > 0)
				gisInfos.add(gisInfo);
		}

		if (layerCodes.contains(LAYER_SHP_CONFINE_OLIO_DOP_VENETO)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_SHP_CONFINE_OLIO_DOP_VENETO);
			gisInfo.setTitle(LAYER_DESCRIPTION_SHP_CONFINE_OLIO_DOP_VENETO);
			gisInfo.setCards(new LinkedList<>());

			List<ShpConfineOlioDopVeneto> gisInfoData = dao.getShpConfineOlioDopVenetoGisInfoData(touchingGeometry);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(
					new GISInfoCard(
							gis.getTitle(),
							null,
							gis.getMbr(),
							List.of(new GISInfoCardField("Codice", gis.getCodice()),
									new GISInfoCardField("Descrizione", gis.getDescrizione())))));
			if (gisInfo.getCards().size() > 0)
				gisInfos.add(gisInfo);
		}
		
		if (layerCodes.contains(LAYER_RPPG2024_DEFINITIVI)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_RPPG2024_DEFINITIVI);
			gisInfo.setTitle(LAYER_DESCRIPTION_RPPG2024_DEFINITIVI);
			gisInfo.setCards(new LinkedList<>());

			List<ShpRppg2023GisInfoData> gisInfoData = dao.getShpRppg2023DefinitiviGisInfoData(touchingGeometry);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(
					new GISInfoCard(
							gis.getTitle(),
							null,
							gis.getMbr(),
							List.of(new GISInfoCardField("ID", gis.getId().toString()),
									new GISInfoCardField("Codice ISTAT Regione", gis.getIstatr()),
									new GISInfoCardField("Superficie (mq)", gis.getArea().toString()),
									new GISInfoCardField("Anno Registrazione", gis.getYear())))));
			if (gisInfo.getCards().size() > 0)
				gisInfos.add(gisInfo);
		}
		
		if (layerCodes.contains(LAYER_RPPG2024_POTENZIALI)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_RPPG2024_POTENZIALI);
			gisInfo.setTitle(LAYER_DESCRIPTION_RPPG2024_POTENZIALI);
			gisInfo.setCards(new LinkedList<>());

			List<ShpRppg2023GisInfoData> gisInfoData = dao.getShpRppg2023PotenzialiGisInfoData(touchingGeometry);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(
					new GISInfoCard(
							gis.getTitle(),
							null,
							gis.getMbr(),
							List.of(new GISInfoCardField("ID", gis.getId().toString()),
									new GISInfoCardField("Codice ISTAT Regione", gis.getIstatr()),
									new GISInfoCardField("Superficie (mq)", gis.getArea().toString()),
									new GISInfoCardField("Anno Registrazione", gis.getYear())))));
			if (gisInfo.getCards().size() > 0)
				gisInfos.add(gisInfo);
		}

		if (layerCodes.contains(LAYER_SIGRIAN_DISTRETTI_IRRIGUI_VENETO_POA)) {
			GISInfo gisInfo = new GISInfo();
			gisInfo.setLayerCode(LAYER_SIGRIAN_DISTRETTI_IRRIGUI_VENETO_POA);
			gisInfo.setTitle(LAYER_DESCRIPTION_SIGRIAN_DISTRETTI_IRRIGUI_VENETO_POA);
			gisInfo.setCards(new LinkedList<>());

			List<ShpDistrettiIrriguiSigrian> gisInfoData = dao.getShpDistrettiIrriguiSigrianData(touchingGeometry);
			gisInfoData.forEach(gis -> gisInfo.getCards().add(new GISInfoCard(gis.getTitle(), gis.getArea(), gis.getMbr(), List.of())));

			if (!gisInfo.getCards().isEmpty()) {
				gisInfos.add(gisInfo);
			}
		}

		return gisInfos;
	}
	
	private static GISInfo getEcoschemiGisInfo(DomainSitiDAO dao, Geometry touchingGeometry, String layerCode, String layerDescription) {
		GISInfo gisInfo = new GISInfo();
		gisInfo.setLayerCode(layerCode);
		gisInfo.setTitle(layerDescription);
		gisInfo.setCards(new LinkedList<>());

		List<EcoschemiGisInfoData> gisInfoData = dao.getEcoschemiGisInfoData(touchingGeometry, 2023, layerCode);
		gisInfoData.forEach(gis -> {
			StringBuilder partCatast = gis.getCod_nazionale() != null && gis.getFoglio() != null? new StringBuilder()
					.append(gis.getCod_nazionale())
					.append(" - ")
					.append(gis.getFoglio()) : null;

			gisInfo.getCards().add(
					new GISInfoCard(
							gis.getTitle(),
							null,
							gis.getMbr(),
							List.of(new GISInfoCardField("Anno di Rif.", gis.getAnno_riferimento().toString()),
									new GISInfoCardField("Codice Interv.", gis.getCodice_intervento()),
									new GISInfoCardField("Anno Dom. Iniz.", gis.getAnno_domanda_iniziale().toString()),
									new GISInfoCardField("Area Conferm.", gis.getArea_confermata().toString()),
									new GISInfoCardField("Area GIS", gis.getArea_grafica_poligono().toString()),
									new GISInfoCardField("Part. Catast.", partCatast != null ? partCatast.toString() : "N.D."))));
		});
		return !gisInfo.getCards().isEmpty() ? gisInfo : null;
	}
}
