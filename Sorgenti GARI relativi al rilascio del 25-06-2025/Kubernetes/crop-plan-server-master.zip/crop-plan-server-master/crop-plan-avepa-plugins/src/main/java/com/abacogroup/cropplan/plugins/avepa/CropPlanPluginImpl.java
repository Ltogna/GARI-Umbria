package com.abacogroup.cropplan.plugins.avepa;

import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.abacogroup.agri.applicationforms.core.model.dto.unified.CropPlanInfoDTO;
import com.abacogroup.cropplan.plugins.avepa.dao.CropPlanSitiknowAppsDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.VersionWithHtuId;
import com.abacogroup.cropplan.plugins.avepa.utils.AuthUtils;
import com.abacogroup.cropplan.sdk.model.CropPlanConfigData;
import com.abacogroup.cropplan.sdk.model.CropPlanVersion;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormExternalCodeDecode;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormSubscription;
import com.abacogroup.cropplan.sdk.model.PublishVersionResult;
import com.abacogroup.cropplan.sdk.spi.CropPlanPlugin;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CropPlanPluginImpl implements CropPlanPlugin, InitializablePlugin {

	private static final String JDBI_NAME_SITIKNOW_APPS = "dbSitiknowApps";
	private static final String URL_APPF = "applicationFormsURL";
	static final String APPF_MESSAGE = "Versione utilizzata per rilascio domanda unificata";

	private CropPlanSitiknowAppsDAO cropPlanSitiknowAppsDAO;
	private String applicationFormsURL;

	private ExecutorService executor;


	@Override
	public void initialize(PluginsEnvironment env) {
		var jdbiSitiknowApps = env.getJdbi(JDBI_NAME_SITIKNOW_APPS);
		if (jdbiSitiknowApps == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITIKNOW_APPS);

		cropPlanSitiknowAppsDAO = jdbiSitiknowApps.onDemand(CropPlanSitiknowAppsDAO.class);

		applicationFormsURL = Optional.ofNullable(env.getProperty(URL_APPF))
				.map(Object::toString)
				.orElseThrow(() -> new IllegalStateException("Cannot get applicationFormsURL property"));

		executor = Executors.newCachedThreadPool();
	}

	@Override
	public boolean isReadOnly(RuntimeEnvironment env, String businessId, Long cropPlanId) {
		if (AuthUtils.isCrplServiceUser(env.getUserName()))
			return false;
		return cropPlanSitiknowAppsDAO.getStatoFascicoloInLavorazione(businessId) == 0;
	}

	@Override
	public boolean canAddPlots(RuntimeEnvironment env, String businessId, Long cropPlanId) {
		return true;
	}

	@Override
	public boolean isExternalChangesPending(RuntimeEnvironment env, String businessId, Long cropPlanId,
			LocalDateTime latestVersionDt) {
		return cropPlanSitiknowAppsDAO.getCropPlanExternalChanges(businessId, cropPlanId, latestVersionDt) > 0;
	}

	@Override
	public CompletionStage<PublishVersionResult> publishVersion(RuntimeEnvironment env, String businessId,
			Long cropPlanId, String version) {

		CompletableFuture<PublishVersionResult> ret = new CompletableFuture<>();
		executor.submit(() -> {
			do {
				var errors = cropPlanSitiknowAppsDAO.getVersionPublishedWithErrors(businessId, cropPlanId, version);
				if (errors > 0) {
					ret.complete(new PublishVersionResult(false));
					break;
				}

				var success = cropPlanSitiknowAppsDAO.getVersionPublishedSuccesfully(businessId, cropPlanId, version);
				if (success > 0) {
					ret.complete(new PublishVersionResult(true));
					break;
				}

				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					ret.completeExceptionally(e);
					Thread.currentThread().interrupt();
				}
			} while (true);
		});

		return ret;
	}

	@Override
	public List<PermanentCropFormSubscription> getPermanentCropFormSubscriptions(RuntimeEnvironment env,
			String externalCode, List<String> subscriptionCodes) {
		return new ArrayList<>();
	}

	@Override
	public List<PermanentCropFormExternalCodeDecode> getPermanentCropFormExternalCodeDescription(RuntimeEnvironment env,
			List<String> externalCodeList) {
		return new ArrayList<>();
	}

	@Override
	public Map<String, String> getVersionsMessagesExt(RuntimeEnvironment env, String businessId, Long cropPlanId, List<CropPlanVersion> versions) {
		if (!versions.isEmpty()) {

			List<String> rawVersions = versions.stream()
					.map(cpv -> cpv.getVersion().getRawValue())
					.collect(toList());

			List<VersionWithHtuId> versionsWithHtuId = cropPlanSitiknowAppsDAO.getVersionWithHtuId(businessId, cropPlanId, rawVersions);
			Map<String, String> versionMessageMap = versionsWithHtuId.stream()
					.collect(toMap(VersionWithHtuId::getVersion, id -> "ID piano: " + id.getHtuId()));

			List<Integer> years = versions.stream()
					.map(CropPlanVersion::getVersionReferenceDate)
					.filter(referenceDate -> referenceDate != null)
					.map(AbsoluteDate::toLocalDate)
					.map(LocalDate::getYear)
					.distinct()
					.collect(toList());
			
			for (Integer year : years) {
				CropPlanInfoDTO cropPlanInfo = getCropPlanInfo(env, businessId, year);
				if (cropPlanInfo != null && cropPlanId.equals(cropPlanInfo.getCropPlanId()) && rawVersions.contains(cropPlanInfo.getCropPlanVersion())) {
					Optional.of(versionMessageMap)
							.map(map -> map.get(cropPlanInfo.getCropPlanVersion()))
							.ifPresentOrElse(message -> {
								versionMessageMap.put(cropPlanInfo.getCropPlanVersion(),
										String.format("%s - %s %s", message, APPF_MESSAGE, year));
							}, () -> {
								versionMessageMap.put(cropPlanInfo.getCropPlanVersion(), APPF_MESSAGE + " " + year);
							});
				}
			}

			return versionMessageMap;
		}
		return new HashMap<>();
	}

	@Override
	public List<CropPlanConfigData> getCropPlanConfig(RuntimeEnvironment env, String businessId, Long cropPlanId,
			List<CropPlanConfigData> cropPlanConfigs) {
		return cropPlanConfigs;
	}

	private CropPlanInfoDTO getCropPlanInfo(RuntimeEnvironment env, String businessId, Integer year) {
		String api = "/{tenant}/public/v1/parties/{party_id}/years/{year}";
		Map<String, Object> pathVariables = Map.of(
				"tenant", env.getTenantId(),
				"party_id", businessId,
				"year", year);

		CropPlanInfoDTO cropPlanInfo;
		try {
			cropPlanInfo = env.getAuthenticatedWebTarget(applicationFormsURL)
					.path(api)
					.resolveTemplates(pathVariables)
					.queryParam("module_code", "UNIF_ART15_"+year, "UNIF_"+year)
					.request(MediaType.APPLICATION_JSON_TYPE)
					.get(new GenericType<>() {
					});
		} catch (Exception e) {
			log.warn("Unable to retrieve crop plan info for party {} of year {} from app-forms: {}", businessId, year, e.getMessage());
			cropPlanInfo = null;
		}
		return cropPlanInfo;
	}

	@Override
	public String getCropPlanType() {
		return "*";
	}

}
