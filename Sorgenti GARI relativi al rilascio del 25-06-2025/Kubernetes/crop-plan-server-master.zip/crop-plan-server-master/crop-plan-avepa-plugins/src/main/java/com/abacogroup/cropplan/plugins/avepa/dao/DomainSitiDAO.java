package com.abacogroup.cropplan.plugins.avepa.dao;

import java.time.LocalDateTime;
import java.util.List;
import java.util.function.Consumer;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.cropplan.plugins.avepa.dao.ntt.Declarations2024GisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.Declarations2024SnapGeometry;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.EcoschemiGisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.LayerConfermeGisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.ShpComuniContermini;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.ShpConfineOlioDopVeneto;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.ShpCorpiIdriciGisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.ShpDistrettiIrriguiSigrian;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.ShpFanghiGisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.ShpMetanodottiGisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.ShpNaturaGisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.ShpPianoAssestamentoGisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.ShpPltGisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.ShpRppg2022GisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.ShpRppg2023GisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.ShpUpasGisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.ShpZonaMontana2015GisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.ShpZvn2021GisInfoData;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.SitiSuoloGisInfoData;
import com.abacogroup.cropplan.sdk.model.domain.CadastralParcelData;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements.SnapGeometry;
import com.abacogroup.jdbi.EnhancedSqlObject;

public interface DomainSitiDAO extends EnhancedSqlObject
{
	@Override
	@SqlQuery("§select_from_dual(§current_timestamp§)§")
	public LocalDateTime getCurrentTimestamp();
	
	@SqlQuery("select sp.se_row_id as id,"
		+ "           'CADPARCEL' as type,"
		+ "           siti_labels.get_label_part(cp.id_cata_part) as description,"
		+ "           sp.shape as geom"
		+ "      from cata_part cp, sitipart sp, TPARTICELLE_COND pc"
		+ "     WHERE cp.cod_nazionale = :domainZoneId"
		+ "       AND sp.id_particella = cp.id_cata_part"
		+ "       AND pc.se_row_id = sp.SE_ROW_ID"
		+ "       AND pc.id_soggetto = :businessId"
		+ "       AND §current_timestamp§ BETWEEN pc.DT_INSERT AND pc.DT_DELETE "
		+ "       AND :pointInTime between pc.data_inizio_conduzione and pc.data_fine_conduzione"
		+ "       AND sdo_relate(sp.shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getCadastralParcelsSnapGeometries(@Bind("businessId") String businessId,
			@Bind("pointInTime") LocalDateTime pointInTime, @Bind("domainZoneId") String domainZoneId,
			@Bind("touchingGeometry") Geometry touchingGeometry);

	@RegisterBeanMapper(CadastralParcelData.class)
	@SqlQuery("SELECT siti_labels.get_label_part(cp.id_cata_part) as parcel, " +
			"         cp.foglio as sectorBlock, " +
			"         (select p.epsg_code from dbmap_proj p where p.projection_id = sp.projection_id) as srs, " +
			"         sp.shape as geom, " +
			"         SDO_GEOM.SDO_MBR(sp.shape) as mbrOverview, " +
			"         sp.area_part as areaSqm, " +
			"         round((pc.supe_condotta*100/pc.SUPE_CATASTALE),2) as holdingPercentage, " +
			"         decode((select count(*) from sitiknow.lpis_build_units_det lbud where lbud.parcel_id = cp.id_cata_part and §current_timestamp§ between lbud.dt_insert and lbud.dt_delete and :pointInTime between lbud.dt_start and lbud.dt_end),0,0,1) as hasUnimm, " +
			"         decode((select count(*) from sitiknow.lpis_permanent_crop_units lpcu where lpcu.parcel_id = cp.id_cata_part and :pointInTime between lpcu.dt_start and lpcu.dt_end),0,0,1) as hasUnar, " +
			"         (select count(*) from TPARTICELLE_COND pc1 where :pointInTime between pc1.data_inizio_conduzione and pc1.data_fine_conduzione and §current_timestamp§ between pc1.dt_insert and pc1.dt_delete and pc1.id_particella = cp.id_cata_part) as holdingCount, " +
			"         decode(pc.tipo_conduzione,1,'PROPERTY',2,'RENT',3,'SHARECROPPPING',4,'OTHER',null) as holdingType, " +
			"         nvl(sitiknow.srv_base.get_decode('PARHOLCOD', pc.tipo_conduzione), pc.tipo_conduzione) as holdingTypeDescription, " +
			"         decode(sp.cod_edif,1,'URBAN',2,'AGRICULTURAL',3,'ROADS',4,'WATERS',null) as parcelType, " +
			"         nvl(sitiknow.srv_base.get_decode('PARTYP', sp.cod_edif), sp.cod_edif) as parcelTypeDescription " +
			"    FROM cata_part cp, sitipart sp, TPARTICELLE_COND pc " +
			"   WHERE cp.cod_nazionale = :domainZoneId " +
			"     AND sp.id_particella = cp.id_cata_part " +
			"     AND pc.se_row_id = sp.SE_ROW_ID" + 
			"     AND pc.id_soggetto = :businessId" +
			"     AND §current_timestamp§ BETWEEN pc.DT_INSERT AND pc.DT_DELETE" + 
			"     AND :pointInTime between pc.data_inizio_conduzione and pc.data_fine_conduzione")
	public ResultIterator<CadastralParcelData> getCadastralParcelData(
			@Bind("businessId") String businessId, @Bind("domainZoneId") String domainZoneId, @Bind("pointInTime") LocalDateTime pointInTime);
	
	@SqlQuery("select sg.id_plt as id,"
		+ "           'SHP_PLT' as type,"
		+ "           sg.descrizione as description,"
		+ "           sg.shape as geom"
		+ "      from SHP_PLT sg"
		+ "     where sdo_relate(sg.shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getShpPltSnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select sg.descrizione as title,"
		+ "           SDO_GEOM.SDO_MBR(sg.shape) as mbr,"
		+ "           SDO_GEOM.SDO_AREA(sg.shape, 0.005) as area,"
		+ "           sg.note_tecniche 	as note"
		+ "      from SHP_PLT sg"
		+ "     where sdo_relate(sg.shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(ShpPltGisInfoData.class)
	public List<ShpPltGisInfoData> getShpPltGisInfoData(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select sg.se_row_id as id,"
		+ "           'SHP_NATURA2000_2017' as type,"
		+ "           sg.denominazi as description,"
		+ "           sg.shape as geom"
		+ "      from SHP_NATURA2000_2017 sg"
		+ "     where sdo_relate(sg.shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getShpNaturaSnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select sg.denominazi as title,"
		+ "           SDO_GEOM.SDO_MBR(sg.shape) as mbr,"
		+ "           SDO_GEOM.SDO_AREA(sg.shape, 0.005) as area,"
		+ "           sg.tipo_sito as tipoSito,"
		+ "           sg.reg_biogeo as regBiogeo,"
		+ "           sg.regione as regione,"
		+ "           to_char(to_date(substr(sg.data_inizi,0,10),'yyyy-mm-dd'),'dd/mm/yyyy') as dataInizio,"
        + "           to_char(to_date(substr(sg.data_fine_,0,10),'yyyy-mm-dd'),'dd/mm/yyyy') as dataFine"
		+ "      from SHP_NATURA2000_2017 sg"
		+ "     where sdo_relate(sg.shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(ShpNaturaGisInfoData.class)
	public List<ShpNaturaGisInfoData> getShpNaturaGisInfoData(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select sg.shape_id as id,"
		+ "           'SHP_PIANO_ASSESTAMENTO_TN' as type,"
		+ "           sg.tipo as description,"
		+ "           sg.shape as geom"
		+ "      from SHP_PIANO_ASSESTAMENTO_TN sg"
		+ "     where sdo_relate(sg.shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getShpPianoAssestamentoSnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select sg.tipo as title,"
		+ "           SDO_GEOM.SDO_MBR(sg.shape) as mbr,"
		+ "           SDO_GEOM.SDO_AREA(sg.shape, 0.005) as area,"
		+ "           sg.anno_inizio as annoInizio,"
		+ "           sg.anno_fine as annoFine"
		+ "      from SHP_PIANO_ASSESTAMENTO_TN sg"
		+ "     where sdo_relate(sg.shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(ShpPianoAssestamentoGisInfoData.class)
	public List<ShpPianoAssestamentoGisInfoData> getShpPianoAssestamentoGisInfoData(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select sg.shape_id as id,"
		+ "           'SHP_UPAS_TN' as type,"
		+ "           sg.k_upas as description,"
		+ "           sg.shape as geom"
		+ "      from SHP_UPAS_TN sg"
		+ "     where sdo_relate(sg.shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getShpUpasSnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select sg.k_upas as title,"
		+ "           SDO_GEOM.SDO_MBR(sg.shape) as mbr,"
		+ "           SDO_GEOM.SDO_AREA(sg.shape, 0.005) as area,"
		+ "           nome_piano as nomePiano,"
		+ "           malga_b as malgaB,"
		+ "           malga_p as malgaP,"
		+ "           anno_inizio as annoInizio,"
		+ "           anno_fine as annoFine"
		+ "      from SHP_UPAS_TN sg"
		+ "     where sdo_relate(sg.shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(ShpUpasGisInfoData.class)
	public List<ShpUpasGisInfoData> getShpUpasGisInfoData(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select sg.shape_id as id,"
		+ "           'SHP_METANODOTTI' as type,"
		+ "           sg.alias as description,"
		+ "           sg.shape as geom"
		+ "      from SHP_METANODOTTI sg"
		+ "     where sdo_relate(sg.shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getShpMetanodottiSnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select sg.alias as title,"
		+ "           SDO_GEOM.SDO_MBR(sg.shape) as mbr,"
		+ "           SDO_GEOM.SDO_AREA(sg.shape, 0.005) as area,"
		+ "           sg.proponente as proponente,"
		+ "           sg.descrizione as descrizione"
		+ "      from SHP_METANODOTTI sg"
		+ "     where sdo_relate(sg.shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(ShpMetanodottiGisInfoData.class)
	public List<ShpMetanodottiGisInfoData> getShpMetanodottiGifInfoData(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select sg.shape_id as id,"
		+ "           'SHP_FANGHI_2022' as type,"
		+ "           sg.descrizione as description,"
		+ "           sg.shape as geom"
		+ "      from SHP_FANGHI_2022 sg"
		+ "     where sdo_relate(sg.shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getShpFanghiSnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select sg.descrizione as title,"
		+ "           SDO_GEOM.SDO_MBR(sg.shape) as mbr,"
		+ "           SDO_GEOM.SDO_AREA(sg.shape, 0.005) as area,"
		+ "           sg.cod_nazion || ' - ' || (select sc.nome from siticomu_all sc where §current_timestamp§ between sc.dt_insert_comu and sc.dt_delete_comu and sc.cod_nazionale = sg.cod_nazion) as comune,"
		+ "           sg.foglio as foglio,"
		+ "           (sg.particella||decode(trim(sg.sub), '', '', '/'||sg.sub)) as particella"
		+ "      from SHP_FANGHI_2022 sg"
		+ "     where sdo_relate(sg.shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(ShpFanghiGisInfoData.class)
	public List<ShpFanghiGisInfoData> getShpFanghiGisInfoData(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select sg.shape_id as id,"
		+ "           'SHP_CORPIIDRICI_2022' as type,"
		+ "           sg.nome as description,"
		+ "           sg.shape as geom"
		+ "      from SHP_CORPIIDRICI_2022 sg"
		+ "     where sdo_relate(sg.shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public void getShpCorpiIdriciSnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry,
			Consumer<SnapGeometry> consumer);
	
	@SqlQuery("select sg.nome as title,"
		+ "           SDO_GEOM.SDO_MBR(sg.shape) as mbr,"
		+ "           SDO_GEOM.SDO_AREA(sg.shape, 0.005) as area,"
		+ "           sg.bcaa1_pac_2014_2022 as bcaa1,"
		+ "           sg.bcaa4_pac_2023_2027 as bcaa2,"
		+ "           sg.descrizione as descrizione,"
		+ "           sg.inziio as inizio,"
		+ "           sg.fine as fine"
		+ "      from SHP_CORPIIDRICI_2022 sg"
		+ "     where sdo_relate(sg.shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(ShpCorpiIdriciGisInfoData.class)
	public List<ShpCorpiIdriciGisInfoData> getShpCorpiIdriciGisInfoData(@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("select ID_RPPG as id,"
			+ "       'RPPG2023' as type,"
			+ "       'RPPG2023 (dati 2022)' as description,"
			+ "       SHAPE as geom"
			+ "  from SHP_RPPG_2022"
			+ " where sdo_relate(SHAPE, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getShpRppg2022SnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("SELECT ID_RPPG AS id, \n"
			+ "         ISTATR, \n"
			+ "         SUPE_RPPG AS area, \n"
			+ "         ANNO_RPPG AS YEAR, \n"
			+ "         SDO_GEOM.SDO_MBR(SHAPE) as mbr \n"
			+ "    FROM SHP_RPPG_2022"
			+ "   WHERE sdo_relate(SHAPE, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(ShpRppg2022GisInfoData.class)
	public List<ShpRppg2022GisInfoData> getShpRppg2022GisInfoData(@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("select PKID as id,"
			+ "       'ALTITUDINE1200RECT' as type,"
			+ "       'Terreni sopra i 1200m di Altitudine' as description,"
			+ "       SHAPE as geom"
			+ "  from SHP_ALTITUDINE_1200"
			+ " where sdo_relate(SHAPE, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getShpAltitudine1200SnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry);

	/*@SqlQuery("select SHAPE_ID as id, \n"
		+ "       'DOMANDE_CONFERMA_14_20' as type, \n"
		+ "       'DOMANDE DI CONFERMA' as description, \n"
		+ "       SHAPE as geom \n"
		+ "  FROM V_PSR_IMPEGNI_PLURI \n"
		+ " where §geom_have_interactions(SHAPE, :touchingGeometry)§")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getShpDomandeConferma1420SnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select SDO_GEOM.SDO_MBR(shape) as mbr, \n"
		+ "       ANNO_RIFERIMENTO, \n"
		+ "       CODICE_INTERVENTO, \n"
		+ "       ANNO_DOMANDA_INIZIALE, \n"
		+ "       AREA_CONFERMATA, \n"
		+ "       AREA_GRAFICA_POLIGONO, \n"
		+ "       COD_NAZIONALE, \n"
		+ "       FOGLIO, \n"
		+ "       PARTICELLA, \n"
		+ "       SUB \n"
		+ "  from V_PSR_IMPEGNI_PLURI \n"
		+ " where §geom_have_interactions(SHAPE, :touchingGeometry)§")
	@RegisterBeanMapper(ShpDomandeConferma1420GisInfoData.class)
	public List<ShpDomandeConferma1420GisInfoData> getShpDomandeConferma1420GisInfoData(@Bind("touchingGeometry") Geometry touchingGeometry);*/
	
	@SqlQuery("select distinct codice_intervento \n"
			+ "  FROM layer_conferme \n"
			+ " where GRUPPO = :group \n"
			+ "   and anno_riferimento = :year")
	public List<String> getLayerConfermeOptionCodes(@Bind("group") String group, @Bind("year") Integer year);
	
	@SqlQuery("select LAYER_ID as id, \n"
			+ "       :type as type, \n"
			+ "       :description as description, \n"
			+ "       SHAPE as geom \n"
			+ "  FROM layer_conferme \n"
			+ " where GRUPPO = :group \n"
			+ "   and anno_riferimento = :year \n"
			+ "   and codice_intervento = :optionCode"
			+ "   and sdo_relate(SHAPE, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getLayerConfermeSnapGeometries(@Bind("group") String group, @Bind("year") Integer year,
			@Bind("optionCode") String optionCode,
			@Bind("type") String type,
			@Bind("description") String description,
			@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select SDO_GEOM.SDO_MBR(shape) as mbr, \n"
			+ "       ANNO_RIFERIMENTO, \n"
			+ "       CODICE_INTERVENTO, \n"
			+ "       ANNO_DOMANDA_INIZIALE, \n"
			+ "       AREA_CONFERMATA, \n"
			+ "       AREA_GRAFICA_POLIGONO, \n"
			+ "       COD_NAZIONALE, \n"
			+ "       FOGLIO \n"
			+ "  from layer_conferme \n"
			+ " where GRUPPO = :group \n"
			+ "   and anno_riferimento = :year \n"
			+ "   and sdo_relate(SHAPE, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(LayerConfermeGisInfoData.class)
	public List<LayerConfermeGisInfoData> getLayerConfermeGisInfoData(@Bind("group") String group, @Bind("year") Integer year,
			@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select SHAPE_ID as id, \n"
			+ "       'ZVN_2021' as type, \n"
			+ "       'ZVN' as description, \n"
			+ "       SHAPE as geom \n"
			+ "  FROM SHP_ZVN2021 \n"
			+ " where sdo_relate(SHAPE, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getShpZvn2021SnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select SDO_GEOM.SDO_MBR(shape) as mbr, "
			+ "       codice, \n"
			+ "       descrizione \n"
			+ "  from SHP_ZVN2021 \n"
			+ " where sdo_relate(shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(ShpZvn2021GisInfoData.class)
	public List<ShpZvn2021GisInfoData> getShpZvn2021GisInfoData(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select PK_ID as id, \n"
			+ "       'ZONA_MONTANA_2015' as type, \n"
			+ "       'ZONA MONTANA' as description, \n"
			+ "       SHAPE as geom \n"
			+ "  FROM SHP_ZONAMONTANA_2015 \n"
			+ " where sdo_relate(SHAPE, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getShpZonaMontana2015SnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select SDO_GEOM.SDO_MBR(shape) as mbr, \n"
			+ "       descrizione \n"
			+ "  from SHP_ZONAMONTANA_2015 \n"
			+ " where sdo_relate(shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(ShpZonaMontana2015GisInfoData.class)
	public List<ShpZonaMontana2015GisInfoData> getShpZonaMontana2015GisInfoData(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select LAYER_ID as id, \n"
			+ "       :type as type, \n"
			+ "       :description as description, \n"
			+ "       SHAPE as geom \n"
			+ "  FROM layer_conferme \n"
			+ " where GRUPPO = 'ECOSCHEMI' \n"
			+ "   and CODICE_INTERVENTO = :optionCode \n"
			+ "   and anno_riferimento = :year \n"
			+ "   and sdo_relate(SHAPE, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getEcoschemiSnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry, @Bind("year") Integer year,
			@Bind("optionCode") String optionCode, @Bind("type") String type, @Bind("description") String description);
	
	@SqlQuery("select SDO_GEOM.SDO_MBR(shape) as mbr, \n"
			+ "       ANNO_RIFERIMENTO, \n"
			+ "       CODICE_INTERVENTO, \n"
			+ "       ANNO_DOMANDA_INIZIALE, \n"
			+ "       AREA_CONFERMATA, \n"
			+ "       AREA_GRAFICA_POLIGONO, \n"
			+ "       COD_NAZIONALE, \n"
			+ "       FOGLIO \n"
			+ "  from layer_conferme \n"
			+ " where GRUPPO = 'ECOSCHEMI' \n"
			+ "   and CODICE_INTERVENTO = :optionCode \n"
			+ "   and anno_riferimento = :year \n"
			+ "   and sdo_relate(SHAPE, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(EcoschemiGisInfoData.class)
	public List<EcoschemiGisInfoData> getEcoschemiGisInfoData(@Bind("touchingGeometry") Geometry touchingGeometry, @Bind("year") Integer year, 
			@Bind("optionCode") String optionCode);

	@SqlQuery("select CODI_FISC_LUNA as id, \n"
			+ "       'SHP_COMUNI_CONTERMINI' as type, \n"
			+ "       'COMUNI CONTERMINI' as description, \n"
			+ "       SHAPE as geom \n"
			+ "  FROM SHP_COMUNI_CONTERMINI \n"
			+ " where sdo_relate(SHAPE, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getShpComuniConterminiSnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("select SDO_GEOM.SDO_MBR(shape) as mbr, \n"
			+ "       CODI_FISC_LUNA as codice, \n"
			+ "       SEZIONI as sezioni, \n"
			+ "       NOME as nome\n"
			+ "  from SHP_COMUNI_CONTERMINI \n"
			+ " where sdo_relate(shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(ShpComuniContermini.class)
	public List<ShpComuniContermini> getShpComuniConterminiGisInfoData(@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("select SHAPE_ID as id, \n"
			+ "       'SHP_CONFINE_OLIO_DOP_VENETO' as type, \n"
			+ "       DESCRIZIONE as description, \n"
			+ "       SHAPE as geom \n"
			+ "  FROM SHP_CONFINE_OLIO_DOP_VENETO \n"
			+ " where sdo_relate(SHAPE, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getShpConfineOlioDopVenetoSnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("select SDO_GEOM.SDO_MBR(shape) as mbr, \n"
			+ "       CODICE as codice, \n"
			+ "       DESCRIZIONE as descrizione \n"
			+ "  from SHP_CONFINE_OLIO_DOP_VENETO \n"
			+ " where sdo_relate(shape, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(ShpConfineOlioDopVeneto.class)
	public List<ShpConfineOlioDopVeneto> getShpConfineOlioDopVenetoGisInfoData(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select ID_RPPG as id,"
			+ "       'RPPG2024_DEFINITIVI' as type,"
			+ "       'RPPG2024 (definitivi - dati 2023)' as description,"
			+ "       SHAPE as geom"
			+ "  from SHP_RPPG_2023"
			+ " where (conta_rppg is null or conta_rppg > 4)"
			+ "   and sdo_relate(SHAPE, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getShpRppg2023DefinitiviSnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("SELECT ID_RPPG AS id, \n"
			+ "       ISTATR, \n"
			+ "       SUPE_RPPG AS area, \n"
			+ "       ANNO_RPPG AS YEAR, \n"
			+ "       SDO_GEOM.SDO_MBR(SHAPE) as mbr \n"
			+ "  FROM SHP_RPPG_2023"
			+ " WHERE (conta_rppg is null or conta_rppg > 4)"
			+ "   AND sdo_relate(SHAPE, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(ShpRppg2023GisInfoData.class)
	public List<ShpRppg2023GisInfoData> getShpRppg2023DefinitiviGisInfoData(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("select ID_RPPG as id,"
			+ "       'RPPG2024_POTENZIALI' as type,"
			+ "       'RPPG2024 (potenziali - dati 2023)' as description,"
			+ "       SHAPE as geom"
			+ "  from SHP_RPPG_2023"
			+ " where conta_rppg <= 4"
			+ "   and sdo_relate(SHAPE, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	public List<SnapGeometry> getShpRppg2023PotenzialiSnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry);
	
	@SqlQuery("SELECT ID_RPPG AS id, \n"
			+ "       ISTATR, \n"
			+ "       SUPE_RPPG AS area, \n"
			+ "       ANNO_RPPG AS YEAR, \n"
			+ "       SDO_GEOM.SDO_MBR(SHAPE) as mbr \n"
			+ "  FROM SHP_RPPG_2023"
			+ " WHERE conta_rppg <= 4"
			+ "   AND sdo_relate(SHAPE, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(ShpRppg2023GisInfoData.class)
	public List<ShpRppg2023GisInfoData> getShpRppg2023PotenzialiGisInfoData(@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("SELECT SHAPE_ID as id,"
			+ "       'SIGRIAN_DISTRETTI_IRRIGUI_VENETO_POA' as type,"
			+ "       NOME as description,"
			+ "       SHAPE as geom"
			+ "  FROM SHP_DISTRETTI_IRRIGUI_SIGRIAN"
			+ " WHERE ladi_id = 274 "
			+ "   AND sdo_relate(SHAPE, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(SnapGeometry.class)
	List<SnapGeometry> getShpDistrettiIrriguiSigrianSnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("SELECT NOME as title, "
			+ "       SDO_GEOM.SDO_AREA(SHAPE, 0.005) as area, "
			+ "       SDO_GEOM.SDO_MBR(SHAPE) as mbr "
			+ "  FROM SHP_DISTRETTI_IRRIGUI_SIGRIAN"
			+ " WHERE ladi_id = 274 "
			+ "   AND sdo_relate(SHAPE, :touchingGeometry, 'mask=ANYINTERACT') = 'TRUE'")
	@RegisterBeanMapper(ShpDistrettiIrriguiSigrian.class)
	List<ShpDistrettiIrriguiSigrian> getShpDistrettiIrriguiSigrianData(@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("select ta.pcg_aggregato_id as id,"
			+ "       'DECLARATIONS_2024' as type,"
			+ "       ta.cod_occupazione || ' - ' || nvl((SELECT de_occupazione_2016 FROM (SELECT c.de_occupazione_2016 FROM codici.t_colture c WHERE c.cod_occupazione_2016 = ta.cod_occupazione AND 2024 BETWEEN c.anno_inizio AND c.anno_fine ORDER BY c.dt_fine DESC) where rownum = 1),ta.cod_occupazione) as description," 
			+ "       ta.shape as geom,"
			+ "       ta.cod_occupazione as landUseCode,"
			+ "       nvl((SELECT de_occupazione_2016 FROM (SELECT c.de_occupazione_2016 FROM codici.t_colture c WHERE c.cod_occupazione_2016 = ta.cod_occupazione AND 2024 BETWEEN c.anno_inizio AND c.anno_fine ORDER BY c.dt_fine DESC) where rownum = 1),ta.cod_occupazione) as landUseDescription,"
			+ "       ta.superficie as declaredArea"
			+ "  from servizi_trasversali.tpcg_aggregati ta"
			+ " where §geom_have_interactions(ta.shape, :touchingGeometry)§"
			+ "   and ta.anno = 2024"
			+ "   and ta.cod_nazionale = :domainZoneId")
	@RegisterBeanMapper(Declarations2024SnapGeometry.class)
	public List<Declarations2024SnapGeometry> getDeclarations2024SnapGeometries(
			@Bind("touchingGeometry") Geometry touchingGeometry,
			@Bind("domainZoneId") String domainZoneId);

	@SqlQuery("select ta.cod_occupazione || ' - ' || nvl((SELECT de_occupazione_2016 FROM (SELECT c.de_occupazione_2016 FROM codici.t_colture c WHERE c.cod_occupazione_2016 = ta.cod_occupazione AND 2024 BETWEEN c.anno_inizio AND c.anno_fine ORDER BY c.dt_fine DESC) where rownum = 1),ta.cod_occupazione) as title,"
			+ "       ta.superficie as area,"
			+ "       SDO_GEOM.SDO_MBR(ta.shape) as mbr," 
			+ "       ta.cod_occupazione as landUseCode,"
			+ "       nvl((SELECT de_occupazione_2016 FROM (SELECT c.de_occupazione_2016 FROM codici.t_colture c WHERE c.cod_occupazione_2016 = ta.cod_occupazione AND 2024 BETWEEN c.anno_inizio AND c.anno_fine ORDER BY c.dt_fine DESC) where rownum = 1),ta.cod_occupazione) as landUseDescription,"
			+ "       ta.superficie as declaredArea"
			+ "  from servizi_trasversali.tpcg_aggregati ta"
			+ " where §geom_have_interactions(ta.shape, :touchingGeometry)§"
			+ "   and ta.anno = 2024"
			+ "   and ta.cod_nazionale = :domainZoneId")
	@RegisterBeanMapper(Declarations2024GisInfoData.class)
	public List<Declarations2024GisInfoData> getDeclarations2024GisInfoData(
			@Bind("touchingGeometry") Geometry touchingGeometry,
			@Bind("domainZoneId") String domainZoneId);

	@SqlQuery("SELECT dcg.s_code_parent || ' - ' || sitiknow_2021.deco_srv.get_decode('COVCOD_CROP_PLAN', dcg.s_code_parent) AS title,"
			+ "       SDO_GEOM.SDO_MBR(shape) AS mbr,"
			+ "       round(sdo_geom.sdo_area(shape,0.005)) AS area"
			+ "  from sitisuolo ss, sitiknow_2021.deco_codes_groups dcg"
			+ " where data_fine_val >= to_date('99991231','yyyymmdd')"
			+ "   AND §geom_have_interactions(shape, :touchingGeometry)§"
			+ "   AND dcg.s_code_child = cod_varieta"
			+ "   AND dcg.p_code_child='COVCOD'"
			+ "   AND dcg.p_code_parent='COVCOD_CROP_PLAN'")
	@RegisterBeanMapper(SitiSuoloGisInfoData.class)
	public List<SitiSuoloGisInfoData> getSitisuoloGisInfoData(@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("select se_row_id as id,"
			+ "       'SITISUOLO' as type,"
			+"        shape as geom"
			+ "  from sitisuolo"
			+ " where data_fine_val >= to_date('99991231','yyyymmdd')"
			+ "   AND §geom_have_interactions(shape, :touchingGeometry)§")
	@RegisterBeanMapper(SnapGeometry.class)
	public void getSitiSuoloSnapGeometries(@Bind("touchingGeometry") Geometry touchingGeometry,
			Consumer<SnapGeometry> consumer);
	
}
