package com.abacogroup.cropplan.plugins.avepa;

import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.NotImplementedException;
import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.core.Jdbi;

import com.abacogroup.cropplan.plugins.avepa.dao.CropCodesSitiknowAppsDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.CropPlanDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.DomainSitiDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.DomainSitiknowDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.CataloghiLayerDef;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.CataloghiLayers;
import com.abacogroup.cropplan.plugins.avepa.model.DeclarationPermanentAndAdditionalData;
import com.abacogroup.cropplan.plugins.avepa.model.PermanentCropFormWithDeclCode;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataConf;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormData;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseClass;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseDetails;
import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormConfig;
import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormFieldConfig;
import com.abacogroup.cropplan.sdk.model.domain.ParcelData;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements.SnapGeometry;
import com.abacogroup.cropplan.sdk.model.validation.AnomalyObjectType;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomaly;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomalyObject;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedDeclaration;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedPlot;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorData;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorOperation;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorResult;
import com.abacogroup.cropplan.sdk.spi.ValidatorPlugin;
import com.abacogroup.cropplan.sdk.support.PermanentCropFormDataFieldToCodeMapper;
import com.abacogroup.cropplan.sdk.support.ValidatorDataSupport;
import com.abacogroup.cropplan.sdk.support.ValidatorDataSupport.VDSDeclaration;
import com.abacogroup.cropplan.sdk.support.ValidatorDataSupport.VDSParcel;
import com.abacogroup.cropplan.sdk.support.ValidatorDataSupport.VDSPlot;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;

public class ValidatorPluginImpl implements ValidatorPlugin, InitializablePlugin {

	public enum ANOMALIES_CODES {
		DECLARATION_WITH_OBSOLETE_LAND_USE,
		DECLARATION_MISSING_MANDATORY_FIELDS,
		PARCEL_NOT_FULLY_DECLARED,
		PARCEL_OVERDECLARED,
		PLOT_WITH_UNDECLARED_AREA,
		PLOT_WITH_MULTI_DECLARED_AREAS,
		PLOT_WITH_INCOMPATIBLE_LAND_USE,
		PLOT_WITH_NOT_HOMOGENEOUS_LAND_USES,
		PLOT_INTERSECT_LAYER,
		PLOT_NOT_FULLY_DECLARED,
		PLOT_WITHOUT_PARCEL,
	};

	private static final String JDBI_NAME_SITI = "dbSiti";
	private static final String JDBI_NAME_SITIKNOW = "dbSitiknow";
	private static final String JDBI_NAME_SITIKNOW_APPS = "dbSitiknowApps";
	private static final String JDBI_NAME_MAIN_DB = "mainDB";

	private static final Integer PARCEL_ANOMALY_AREA_UNUSED_TOLERANCE_MIN = 5;
	private static final Integer PARCEL_ANOMALY_AREA_OVERDECLARED_TOLERANCE_MIN = 5;
	private static final Integer PARCEL_ANOMALY_AREA_UNUSED_TOLERANCE_MAX = 20;
	private static final Integer PARCEL_ANOMALY_AREA_OVERDECLARED_TOLERANCE_MAX = 20;
	
	private DomainSitiDAO domainSitiDAO;
	private DomainSitiknowDAO domainSitiknowDAO;
	private CropCodesSitiknowAppsDAO cropCodesSitiknowAppsDAO;
	private CropPlanDAO cropPlanDAO;
	private PermanentCropFormDataFieldToCodeMapper fieldToCodeMapper;

	@Override
	public void initialize(PluginsEnvironment env) {

		var jdbiSiti = env.getJdbi(JDBI_NAME_SITI);
		if (jdbiSiti == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITI);
		domainSitiDAO = jdbiSiti.onDemand(DomainSitiDAO.class);
		
		Jdbi jdbiSitiknow = env.getJdbi(JDBI_NAME_SITIKNOW);
		if (jdbiSitiknow == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITIKNOW);
		domainSitiknowDAO = jdbiSitiknow.onDemand(DomainSitiknowDAO.class);
		
		Jdbi jdbiSitiknowApps = env.getJdbi(JDBI_NAME_SITIKNOW_APPS);
		if (jdbiSitiknowApps == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITIKNOW_APPS);
		cropCodesSitiknowAppsDAO = jdbiSitiknowApps.onDemand(CropCodesSitiknowAppsDAO.class);

		Jdbi mainJdbi = Optional.ofNullable(env.getJdbi(JDBI_NAME_MAIN_DB))
				.orElseThrow(() -> new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_MAIN_DB));
		cropPlanDAO = mainJdbi.onDemand(CropPlanDAO.class);

		this.fieldToCodeMapper = new PermanentCropFormDataFieldToCodeMapper();
	}

	@Override
	public boolean ignoreBlockingAnomalies(RuntimeEnvironment env) {
		return false; // can't be ignored
	}

	@Override
	public CompletionStage<ValidatorResult> validate(RuntimeEnvironment env, ValidatorData data, ValidatorDataSupport support) {
		try {
			var result = new ValidatorResult();
			result.setMessages(new ArrayList<>());
			result.setAnomalies(calculateAnomalies(env, data, support));
			return CompletableFuture.completedStage(result);

		} catch (Exception e) {
			return CompletableFuture.failedStage(e);
		}
	}

	@Override
	public Map<ValidationAnomalyObject, List<ValidationAnomaly>> calculateAnomalies(RuntimeEnvironment env, ValidatorData data, ValidatorDataSupport support) {
		if (support.isCalculateAtPreviousVersion()) {
			throw new NotImplementedException("Calculate anomalies with version is not supported yet.");
		}

		if (null == data.getReferenceDt()) {
			throw new IllegalStateException("No reference date specified to calculate anomalies!"); // should never happen!
		}

		Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies = new HashMap<>();
		data.getDeclarations().forEach(decl -> {
			anomalies.put(new ValidationAnomalyObject(decl.getDeclCode(), AnomalyObjectType.DECLARATION), new ArrayList<>());
			anomalies.put(new ValidationAnomalyObject(decl.getPlotCode(), AnomalyObjectType.PLOT), new ArrayList<>());
			
		});
		
		data.getPlots().forEach(plot -> {
			anomalies.put(new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT), new ArrayList<>());
		});

		List<String> parcelCodes = Stream.concat(
						data.getPlots().stream().map(ValidatorBoundedPlot::getParcelCodes),
						data.getDeclarations().stream().map(ValidatorBoundedDeclaration::getParcelCodes)
				).flatMap(Collection::stream)
				.distinct().collect(toList());
		
		parcelCodes.forEach(parcelCode -> {
			anomalies.put(new ValidationAnomalyObject(parcelCode, AnomalyObjectType.PARCEL), new ArrayList<>());
		});
		
		Set<String> plotsWithDeclChanges = data.getDeclarations().stream()
				.map(ValidatorBoundedDeclaration::getPlotCode)
				.collect(Collectors.toSet());
		data.getPlots().stream()
				.filter(p -> ValidatorOperation.DELETE.equals(p.getOperation()))
				.map(ValidatorBoundedPlot::getPlotCode)
				.forEach(plotsWithDeclChanges::remove);

		Set<String> plotsUpdated = data.getPlots().stream()
				.filter(p -> !ValidatorOperation.DELETE.equals(p.getOperation()))
				.map(ValidatorBoundedPlot::getPlotCode)
				.collect(Collectors.toSet());
		Set<String> declsUpdated = data.getDeclarations().stream()
				.filter(p -> !ValidatorOperation.DELETE.equals(p.getOperation()))
				.map(ValidatorBoundedDeclaration::getDeclCode)
				.collect(Collectors.toSet());

		Set<String> remainingPlots = new HashSet<>(plotsUpdated);
		remainingPlots.addAll(plotsWithDeclChanges);

		LocalDateTime refDate = LocalDateTime.of(data.getReferenceDt(), LocalTime.of(23, 59, 59));

		LocalCaches localCaches = new LocalCaches();

		for (String parcelCode : parcelCodes) {
			VDSParcel parcel = support.getParcel(parcelCode, data.getReferenceDt(), data.getReferenceDt());
			ParcelData sitiParcel = this.getParcelFromSiti(data, parcelCode, refDate);

			long totalParcelDeclaredAreaSqm = 0L;
			for (VDSPlot plot : parcel.getPlots()) {
				remainingPlots.remove(plot.getPlotCode());
				Double totalPlotDeclaredPerc = plot.getDecls().stream().map(VDSDeclaration::getAreaPerc).reduce(0., Double::sum);
				totalParcelDeclaredAreaSqm += Math.round(plot.getAreaSqm() * (totalPlotDeclaredPerc/100));

				boolean hasDeclChanges = plotsWithDeclChanges.contains(plot.getPlotCode());
				boolean isUpdated = plotsUpdated.contains(plot.getPlotCode());

				if (!hasDeclChanges && !isUpdated) {
					continue;
				}

				calculateAnomaliesOnPlot(env, data, support, plot, sitiParcel, totalPlotDeclaredPerc, hasDeclChanges, isUpdated, declsUpdated,
						localCaches, anomalies);
			}

			checkFullyDeclared(parcelCode, sitiParcel, totalParcelDeclaredAreaSqm, anomalies);
			checkOverDeclared(parcelCode, sitiParcel, totalParcelDeclaredAreaSqm, anomalies);

		}

		for (String plotCode : remainingPlots) {
			VDSPlot plot = support.getPlot(plotCode, data.getReferenceDt(), data.getReferenceDt());
			if (plot != null) {
				Double totalPlotDeclaredPerc = plot.getDecls().stream().map(VDSDeclaration::getAreaPerc).reduce(0. ,Double::sum);
				boolean hasDeclChanges = plotsWithDeclChanges.contains(plot.getPlotCode());
				boolean isUpdated = plotsUpdated.contains(plot.getPlotCode());
	
				calculateAnomaliesOnPlot(env, data, support, plot, null, totalPlotDeclaredPerc, hasDeclChanges, isUpdated, declsUpdated,
						localCaches, anomalies);
			}
		}

		return anomalies;
	}

	private void calculateAnomaliesOnPlot(RuntimeEnvironment env, ValidatorData data, ValidatorDataSupport support, VDSPlot plot, ParcelData sitiParcel,
			Double totalPlotDeclaredPerc, boolean hasDeclChanges, boolean isUpdated, Set<String> declsUpdated,
			LocalCaches localCaches, Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies) {

		this.checkUndeclaredArea(plot, anomalies);
		this.checkFullyDeclared(plot, totalPlotDeclaredPerc, anomalies);
		this.checkLandUseCompatibility(data, support, plot, localCaches, anomalies);

		Set<String> plotLandCoversFromSiti = this.getPlotLandCoversFromSiti(plot, localCaches);
		for (VDSDeclaration decl : plot.getDecls()) {
			this.checkLandUseObsolete(data, support, decl, plotLandCoversFromSiti, localCaches, anomalies);
		}

		List<LandUseClass> landUseClassOptions = this.getLandUseClasses(data, support, plotLandCoversFromSiti, localCaches);
		this.checkMultiDeclaredAreas(plot, landUseClassOptions, anomalies);
		this.checkHomogeneousLandUses(plot, landUseClassOptions, anomalies);

		this.checkNoParcels(plot.getPlotCode(), sitiParcel, anomalies);

		if (hasDeclChanges) {
			Map<String, DeclarationPermanentAndAdditionalData> declData = this.getDeclData(env, data, plot);
			for (VDSDeclaration decl : plot.getDecls()) {
				if (declsUpdated.contains(decl.getDeclCode())) {
					this.checkMandatoryFields(data, support, decl, declData.get(decl.getDeclCode()), localCaches, anomalies);
				}
			}
		}

		if (isUpdated) {
			this.checkIntersectLayer(plot, anomalies);
		}
	}

	private void checkNoParcels(String plotCode, ParcelData sitiParcel, Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies) {
		if (null == sitiParcel) {
			anomalies.get(new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT))
				.add(new ValidationAnomaly(plotCode, AnomalyObjectType.PLOT, ANOMALIES_CODES.PLOT_WITHOUT_PARCEL.name(), null, true));
		}
	}

	@Deprecated
	private void checkNoParcels(ValidatorData data, String plotCode, Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies) {
		if (data.getPlots().stream()
				.filter(p -> plotCode.equals(p.getPlotCode()))
				.map(ValidatorBoundedPlot::getParcelCodes)
				.allMatch(parcelCodes -> null == parcelCodes || parcelCodes.isEmpty())) {
			anomalies.get(new ValidationAnomalyObject(plotCode, AnomalyObjectType.PLOT))
				.add(new ValidationAnomaly(plotCode, AnomalyObjectType.PLOT, ANOMALIES_CODES.PLOT_WITHOUT_PARCEL.name(), null, true));
		}
	}

	private void checkIntersectLayer(VDSPlot plot, Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies) {
		for (CataloghiLayerDef catalog : CataloghiLayers.getCataloghiLayers(domainSitiDAO, plot.getGeom())) {
			List<SnapGeometry> intersectCatGeoms = catalog.getSnapGeometry();

			if(null != intersectCatGeoms && !intersectCatGeoms.isEmpty()) {
				anomalies.get(new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT))
					.add(new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, ANOMALIES_CODES.PLOT_INTERSECT_LAYER.name() + "_" + catalog.getLayerCode().toUpperCase().trim(),	null, false));
			}
		}
	}

	private void checkHomogeneousLandUses(VDSPlot plot, List<LandUseClass> landUseClassOptions, Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies) {
		// Grouping coltures compatible with multi declarations by landUseClassCode
		long multiDeclarationDifferentLandCoverCodesCount = landUseClassOptions.stream()
				.filter(luco -> !luco.getPercFixedTo100())
				.map(LandUseClass::getLandUseClassCode)
				.distinct().count();

		// Check if the plot have different landCoverCodes that are compatible with multi declarations
		// (anomalia "PLOT_WITH_NOT_HOMOGENEOUS_LAND_USES")
		boolean isPlotWithNotHomogeneousLandCoverCodes = multiDeclarationDifferentLandCoverCodesCount > 1;

		if (isPlotWithNotHomogeneousLandCoverCodes) {
			anomalies.get(new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT))
				.add(new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, ANOMALIES_CODES.PLOT_WITH_NOT_HOMOGENEOUS_LAND_USES.name(), null, true));
		}
	}

	private void checkMultiDeclaredAreas(VDSPlot plot, List<LandUseClass> landUseClassOptions, Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies) {
		// Filter the list options for the coltures compatible with multi declarations (percFixedTo100 = false)
		long multiDeclarationColturesCount = landUseClassOptions.stream().filter(luco -> !luco.getPercFixedTo100()).count();

		// Filter the list options for the coltures not compatible with multi declarations (percFixedTo100 = true)
		long nonMultiDeclarationColturesCount = landUseClassOptions.stream().filter(luco -> luco.getPercFixedTo100()).count();

		// Check if the plot doesn't meet the multi declarations requirements
		// ("PLOT_WITH_MULTI_DECLARED_AREAS" anomaly)
		// The anomaly occurs
		boolean isPlotWithMultiDeclaredAreas =
				// If there are more coltures that doesn't support multi declarations
				nonMultiDeclarationColturesCount > 1 ||
						// Or if there are one of more coltures that support multi declarations
						(multiDeclarationColturesCount > 0 &&
								// and there are one or more coltures that doesn't support multi declarations
								nonMultiDeclarationColturesCount > 0);
		if(isPlotWithMultiDeclaredAreas) {
			anomalies.get(new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT))
				.add(new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, ANOMALIES_CODES.PLOT_WITH_MULTI_DECLARED_AREAS.name(), null, true));
		}
	}

	private void checkFullyDeclared(VDSPlot plot, Double totalPlotDeclaredPerc, Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies) {
		if (!plot.getDecls().isEmpty() && new BigDecimal(totalPlotDeclaredPerc).setScale(2, RoundingMode.HALF_UP).doubleValue() != 100.) {
			anomalies.get(new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT))
				.add(new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, ANOMALIES_CODES.PLOT_NOT_FULLY_DECLARED.name(), null, true));
		}
	}

	private void checkMandatoryFields(ValidatorData data, ValidatorDataSupport support, VDSDeclaration decl, DeclarationPermanentAndAdditionalData declData,
			LocalCaches localCaches, Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies) {

		Set<String> mandatoryPermanentFields = this.getMandatoryPermanentFields(data, support, decl.getLandUseCode(), localCaches);
		if (!declData.getPermanentCropForms()
				.stream()
				.allMatch(permanentCropForm ->
						this.hasAllMandatoryFields(permanentCropForm.getPermanentCropFormData(), mandatoryPermanentFields))) {
			anomalies.get(new ValidationAnomalyObject(decl.getDeclCode(), AnomalyObjectType.DECLARATION))
				.add(new ValidationAnomaly(decl.getDeclCode(), AnomalyObjectType.DECLARATION, ANOMALIES_CODES.DECLARATION_MISSING_MANDATORY_FIELDS.name(), null, true));
			return;
		}

		Set<String> mandatoryAdditionalFields = this.getMandatoryAdditionalFields(data, support, decl.getLandUseCode(), localCaches);
		if (!this.hasAllMandatoryFields(declData.getFieldsCodes(), mandatoryAdditionalFields)) {
			anomalies.get(new ValidationAnomalyObject(decl.getDeclCode(), AnomalyObjectType.DECLARATION))
				.add(new ValidationAnomaly(decl.getDeclCode(), AnomalyObjectType.DECLARATION, ANOMALIES_CODES.DECLARATION_MISSING_MANDATORY_FIELDS.name(), null, true));
			return;
		}
	}

	private void checkOverDeclared(String parcelCode, ParcelData sitiParcel, long totalParcelDeclaredAreaSqm, Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies) {
		if (null == sitiParcel) {
			return;
		}

		Integer parcelAreaOverDeclaredTolerance = this.getParcelAreaOverDeclaredTolerance(sitiParcel);
		if ((sitiParcel.getAreaSqm() - totalParcelDeclaredAreaSqm) < -parcelAreaOverDeclaredTolerance)
			anomalies.get(new ValidationAnomalyObject(parcelCode, AnomalyObjectType.PARCEL))
				.add(new ValidationAnomaly(parcelCode, AnomalyObjectType.PARCEL, ANOMALIES_CODES.PARCEL_OVERDECLARED.name(), null, true));
	}

	private void checkFullyDeclared(String parcelCode, ParcelData sitiParcel, long totalParcelDeclaredAreaSqm, Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies) {
		if (null == sitiParcel) {
			return;
		}

		Integer parcelAreaUnusedTolerance = this.getParcelAreaUnusedTolerance(sitiParcel);
		if ((sitiParcel.getAreaSqm() - totalParcelDeclaredAreaSqm) > parcelAreaUnusedTolerance)
			anomalies.get(new ValidationAnomalyObject(parcelCode, AnomalyObjectType.PARCEL))
				.add(new ValidationAnomaly(parcelCode, AnomalyObjectType.PARCEL, ANOMALIES_CODES.PARCEL_NOT_FULLY_DECLARED.name(), null, true));
	}

	private void checkLandUseObsolete(ValidatorData data, ValidatorDataSupport support, VDSDeclaration decl, Set<String> plotLandCoversFromDecls,
			LocalCaches localCaches, Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies) {
		if (!isLandUseAvailable(data, support, decl.getLandUseCode(), plotLandCoversFromDecls, localCaches)) {
			anomalies.get(new ValidationAnomalyObject(decl.getDeclCode(), AnomalyObjectType.DECLARATION))
				.add(new ValidationAnomaly(decl.getDeclCode(), AnomalyObjectType.DECLARATION, ANOMALIES_CODES.DECLARATION_WITH_OBSOLETE_LAND_USE.name(), null, true));
		}
	}

	private void checkLandUseCompatibility(ValidatorData data, ValidatorDataSupport support, VDSPlot plot, LocalCaches localCaches, Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies) {
		if (!plot.getDecls().isEmpty() && plot.getDecls().stream()
				.map(VDSDeclaration::getLandUseCode)
				.distinct()
				.anyMatch(landUseCode -> !isLandUseCompatible(data, support, landUseCode, plot.getLandCoverCodes(), localCaches))) {
			anomalies.get(new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT))
				.add(new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, ANOMALIES_CODES.PLOT_WITH_INCOMPATIBLE_LAND_USE.name(), null, false));
		}
	}

	private void checkUndeclaredArea(VDSPlot plot, Map<ValidationAnomalyObject, List<ValidationAnomaly>> anomalies) {
		if (plot.getDecls().isEmpty()) {
			anomalies.get(new ValidationAnomalyObject(plot.getPlotCode(), AnomalyObjectType.PLOT))
				.add(new ValidationAnomaly(plot.getPlotCode(), AnomalyObjectType.PLOT, ANOMALIES_CODES.PLOT_WITH_UNDECLARED_AREA.name(), null, true));
		}
	}


	private boolean hasAllMandatoryFields(List<LandUseAdditionalDataField> additionalDataFields, Collection<String> mandatoryAdditionalFields) {
		Set<String> fieldsNotNull = additionalDataFields.stream()
				.filter(f -> StringUtils.isNotBlank(f.getValue()))
				.map(LandUseAdditionalDataField::getFieldCode)
				.collect(Collectors.toSet());

		Set<String> mandatory = new HashSet<>(mandatoryAdditionalFields);
		mandatory.removeAll(fieldsNotNull);

		return mandatory.isEmpty();
	}

	private boolean hasAllMandatoryFields(PermanentCropFormData cpfd, Collection<String> permanentCropFormsFieldsMandatory) {
		Set<String> fieldsNotNull = new HashSet<>();
		for (Field field : cpfd.getClass().getDeclaredFields()) {
			String fieldCode = this.fieldToCodeMapper.getCode(field.getName());
			if (null != fieldCode) {
				field.setAccessible(true);
				try {
					Object value = field.get(cpfd);
					if (null != value && StringUtils.isNotBlank(value.toString())) {
						fieldsNotNull.add(fieldCode);
					}
				} catch (IllegalAccessException e) {
					throw new IllegalStateException("checkFieldMandatoryAndLookupValues failed");
				}
			}
		}

		Set<String> mandatory = new HashSet<>(permanentCropFormsFieldsMandatory);
		mandatory.removeAll(fieldsNotNull);
		return mandatory.isEmpty();
	}

	private boolean isLandUseCompatible(ValidatorData data, ValidatorDataSupport support, String landUseCode, List<String> landCoverCodes,
			LocalCaches localCaches) {

		// com/abacogroup/cropplan/plugins/avepa/utils/LandCoverUtils.java:33
		if(landCoverCodes == null || landCoverCodes.isEmpty()) {
			landCoverCodes = Arrays.asList(new String[] { null });
		}

		return landCoverCodes.stream()
				.allMatch(landCoverCode -> localCaches.getLandUseCompatibilityCache()
						.computeIfAbsent(String.format("%s/%s", landUseCode, landCoverCode),
								key -> support.isLandUseCompatible(landUseCode, landCoverCode, data.getBusinessId(), true)));
	}

	private Boolean isLandUseAvailable(ValidatorData data, ValidatorDataSupport support, String landUseCode, Set<String> plotLandCoversFromDecls,
			LocalCaches localCaches) {
		return localCaches.getLandUseAvailabilityCache().computeIfAbsent(new LandUseCoversKey(landUseCode, plotLandCoversFromDecls),
				key -> {
					LandUseDetails landUseDetails = this.getLandUseDetails(data, support, key.getLandUse(), localCaches);

					if (null == landUseDetails) {
						return false;
					}

					return key.getLandCovers().stream().allMatch(landCoverCode ->
							support.isLandUseCompatible(landUseDetails.getCode(), landCoverCode, data.getBusinessId(), false));
				});
	}

	private LandUseDetails getLandUseDetails(ValidatorData data, ValidatorDataSupport support, String landUseCode, LocalCaches localCaches) {
		return localCaches.getLandUseDetailsCache().computeIfAbsent(landUseCode,
				luc -> {
					LandUseDetails landUseDetails = support.getLandUseDetails(luc, null, data.getReferenceDt(), data.getBusinessId());

					if (null != landUseDetails) {
						LandUseClass landUseClass = landUseDetails.getLandUseClass();
						localCaches.getLandUseClassCache().putIfAbsent(landUseClass.getLandUseClassCode(), landUseClass);
					}

					return landUseDetails;
				});
	}

	private List<LandUseClass> getLandUseClasses(ValidatorData data, ValidatorDataSupport support, Set<String> landUseClasses, LocalCaches localCaches) {
		List<LandUseClass> landUseClassOptions = new ArrayList<>();

		Map<String, LandUseClass> landUseClassCache = localCaches.getLandUseClassCache();
		List<String> remaining = new ArrayList<>(landUseClasses);
		for (String landUseClass : landUseClasses) {
			if (landUseClassCache.containsKey(landUseClass)) {
				landUseClassOptions.add(landUseClassCache.get(landUseClass));
				remaining.remove(landUseClass);
			}
		}

		if (!remaining.isEmpty()) {
			List<LandUseClass> newLandUseClassOptions = support.getLandUseClassOptions(remaining, data.getBusinessId());
			landUseClassOptions.addAll(newLandUseClassOptions);
			newLandUseClassOptions.forEach(landUseClass -> landUseClassCache.put(landUseClass.getLandUseClassCode(), landUseClass));
		}

		return landUseClassOptions;
	}

	private Set<String> getMandatoryAdditionalFields(ValidatorData data, ValidatorDataSupport support, String landUseCode, LocalCaches localCaches) {
		return localCaches.getLandUseAdditionalDataConfCache().computeIfAbsent(landUseCode,
						luc -> support.getLandUseCodeFieldsConf(luc, data.getReferenceDt(), data.getBusinessId()))
				.stream()
				.filter(landUseAdditionalDataConf -> !landUseAdditionalDataConf.getNullable())
				.map(LandUseAdditionalDataConf::getFieldCode)
				.collect(Collectors.toSet());
	}

	private Set<String> getMandatoryPermanentFields(ValidatorData data, ValidatorDataSupport support, String landUseCode, LocalCaches localCaches) {
		return Optional.ofNullable(this.getLandUseDetails(data, support, landUseCode, localCaches))
				.map(LandUseDetails::getFormsConfig)
				.stream().flatMap(Collection::stream)
				.map(PermanentCropFormConfig::getFields)
				.flatMap(Collection::stream)
				.filter(PermanentCropFormFieldConfig::isFlMandatory)
				.map(PermanentCropFormFieldConfig::getFieldCode)
				.collect(Collectors.toSet());
	}

	private Set<String> getPlotLandCoversFromSiti(VDSPlot plot, LocalCaches localCaches) {
		return plot.getDecls().stream()
				.map(VDSDeclaration::getLandUseCode)
				.distinct()
				.map(landUseCode -> localCaches.getLandUseLandCoverCache().computeIfAbsent(landUseCode,
						luc -> cropCodesSitiknowAppsDAO.getLandCoverCode(luc)))
				.collect(Collectors.toSet());
	}

	private Map<String, DeclarationPermanentAndAdditionalData> getDeclData(RuntimeEnvironment env, ValidatorData data, VDSPlot plot) {
		if (plot.getDecls().isEmpty()) {
			return new HashMap<>();
		}

		Map<String, DeclarationPermanentAndAdditionalData> declData = plot.getDecls().stream()
				.map(VDSDeclaration::getDeclCode)
				.collect(toMap(Function.identity(), DeclarationPermanentAndAdditionalData::new));

		List<PermanentCropFormWithDeclCode> permanentCropForms = cropPlanDAO.getPermanentCropForms(new ArrayList<>(declData.keySet()), plot.getPlotCode(), data.getCropPlanId(),
				cropPlanDAO.getCurrentTimestamp());
		permanentCropForms.forEach(permanentCropFormWithDeclCode -> declData.get(permanentCropFormWithDeclCode.getDeclCode())
				.getPermanentCropForms().add(permanentCropFormWithDeclCode));

		List<LandUseAdditionalDataField> landUseAdditionalDeclarationFields = cropPlanDAO.getLandUseAdditionalDeclarationFields(env.getTenantId(),
				plot.getPlotCode(), data.getCropPlanId(), new ArrayList<>(declData.keySet()), cropPlanDAO.getCurrentTimestamp());
		landUseAdditionalDeclarationFields.forEach(landUseAdditionalDataField -> declData.get(landUseAdditionalDataField.getDeclCode())
				.getFieldsCodes().add(landUseAdditionalDataField));

		return declData;
	}

	private Integer getParcelAreaOverDeclaredTolerance(ParcelData parcel) {
		Integer tolerance = PARCEL_ANOMALY_AREA_OVERDECLARED_TOLERANCE_MIN;
		if (parcel.getAreaSqm() >= 100000) {
			// recalc tolerance for big areas
			tolerance = (int) Math.round((parcel.getAreaSqm() / 100d) * 0.01);
			if (tolerance > PARCEL_ANOMALY_AREA_OVERDECLARED_TOLERANCE_MAX)
				tolerance = PARCEL_ANOMALY_AREA_OVERDECLARED_TOLERANCE_MAX;
		}
		return tolerance;
	}

	private Integer getParcelAreaUnusedTolerance(ParcelData parcel) {
		Integer tolerance = PARCEL_ANOMALY_AREA_UNUSED_TOLERANCE_MIN;
		if (parcel.getAreaSqm() >= 100000) {
			// recalc tolerance for big areas
			tolerance = (int) Math.round((parcel.getAreaSqm() / 100d) * 0.01);
			if (tolerance > PARCEL_ANOMALY_AREA_UNUSED_TOLERANCE_MAX)
				tolerance = PARCEL_ANOMALY_AREA_UNUSED_TOLERANCE_MAX;
		}
		return tolerance;
	}

	private ParcelData getParcelFromSiti(ValidatorData data, String parcelCode, LocalDateTime refDate) {
		InfiniteListResults<ParcelData> infiniteParcel = domainSitiknowDAO.infinite(
				() -> domainSitiknowDAO.getParcelsData(data.getBusinessId(), null, parcelCode, refDate),
				null, 1);

		ParcelData parcel = null;
		if(infiniteParcel.getCount() > 0) {
			parcel = infiniteParcel.getRecords().get(0);
		}
		return parcel;
	}

	@Getter
	static class LocalCaches {

		/**
		 * landUseCode+landCoverCode - compatibility true/false
		 */
		private final Map<String, Boolean> landUseCompatibilityCache = new HashMap<>();

		/**
		 * landUseCode - landCoverCode
		 */
		private final Map<String, String> landUseLandCoverCache = new HashMap<>();

		/**
		 * landUseCode+[plotLandCoverCodes] - availability true/false
		 */
		private final Map<LandUseCoversKey, Boolean> landUseAvailabilityCache = new HashMap<>();

		/**
		 * landCoverCode - LandUseClass
		 */
		private final Map<String, LandUseClass> landUseClassCache = new HashMap<>();

		/**
		 * landUseCode - LandUseDetails
		 */
		private final Map<String, LandUseDetails> landUseDetailsCache = new HashMap<>();

		/**
		 * landUseCode - [LandUseAdditionalDataConf]
		 */
		private final Map<String, List<LandUseAdditionalDataConf>> landUseAdditionalDataConfCache = new HashMap<>();

	}
	
	@Data
	@AllArgsConstructor
	static class LandUseCoversKey {
		private String landUse;
		private Collection<String> landCovers;
	}

	@Override
	public String getCropPlanType() {
		return "CROPPLAN";
	}

}
