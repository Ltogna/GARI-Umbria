package com.abacogroup.cropplan.plugins.avepa.dao;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.function.Consumer;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.cropplan.sdk.model.sync.SyncParcel;
import com.abacogroup.jdbi.EnhancedSqlObject;

public interface SyncSiti2025DAO extends EnhancedSqlObject
{
	
	@SqlQuery("select (case when oldestDt < to_date('99991231','yyyymmdd') then oldestDt else null end) as oldestDt"
			+ "  from ("
			+ "   select least("
			+ "             min(trunc(cond.data_inizio_conduzione)),"
			+ "             min(case when trunc(cond.data_fine_conduzione-1+1/24/60/60) < to_date('99991231','yyyymmdd') then trunc(cond.data_fine_conduzione-1+1/24/60/60)+1 else to_date('99991231','yyyymmdd') end)"
			+ "          ) as oldestDt"
			+ "     from siti.tisole_cond cond"
			+ "    where cond.id_soggetto = :businessId"
			+ "      and cond.data_aggiornamento <= :currentDt"
			+ "      and cond.data_aggiornamento > :lastSyncDt"
			+ "  )")
	public LocalDate getOldestChangesDate(@Bind("businessId") String businessId,
		@Bind("lastSyncDt") LocalDateTime lastSyncDt, @Bind("currentDt") LocalDateTime currentDt);
	
	@SqlQuery("select (case when nextDt < to_date('99991231','yyyymmdd') then nextDt else null end) as nextDt"
			+ "  from ("
			+ "   select least("
			+ "             min(case when trunc(cond.data_inizio_conduzione) > :pointInTime then trunc(cond.data_inizio_conduzione) else to_date('99991231','yyyymmdd') end),"
			+ "             min(case when trunc(cond.data_fine_conduzione-1+1/24/60/60) < to_date('99991231','yyyymmdd') and trunc(cond.data_fine_conduzione-1+1/24/60/60)+1 > :pointInTime then trunc(cond.data_fine_conduzione-1+1/24/60/60)+1 else to_date('99991231','yyyymmdd') end)"
			+ "          ) as nextDt"
			+ "     from tisole_cond cond"
			+ "    where cond.id_soggetto = :businessId"
			+ "      and cond.data_aggiornamento <= :currentDt"
			+ "      and (:lastSyncDt is null or cond.data_aggiornamento > :lastSyncDt)"
			+ "      and (trunc(cond.data_inizio_conduzione) > :pointInTime or (trunc(cond.data_fine_conduzione-1+1/24/60/60) < to_date('99991231','yyyymmdd') and trunc(cond.data_fine_conduzione-1+1/24/60/60)+1 > :pointInTime))"
			+ "  )")
	public LocalDate getNextChangesDate(@Bind("businessId") String businessId,
		@Bind("lastSyncDt") LocalDateTime lastSyncDt, @Bind("currentDt") LocalDateTime currentDt,
		@Bind("pointInTime") LocalDate pointInTime);
	
	@SqlQuery("select cond.isola_id"
			+ "  from tisole_cond cond"
			+ " where cond.id_soggetto = :businessId"
			+ "   and cond.data_aggiornamento <= :currentDt"
			+ "   and :currentDt between cond.dt_insert and cond.dt_delete"
			+ "   and :pointInTime between trunc(cond.data_inizio_conduzione) and (case when trunc(cond.data_fine_conduzione-1+1/24/60/60) < to_date('99991231','yyyymmdd') then trunc(cond.data_fine_conduzione-1+1/24/60/60)+1 else to_date('99991231','yyyymmdd') end)")
	public void consumeAllParcelIds(@Bind("businessId") String businessId,
		@Bind("currentDt") LocalDateTime currentDt, @Bind("pointInTime") LocalDate pointInTime, Consumer<String> consumer);
	
	@SqlQuery("select cond.isola_id"
			+ "  from tisole_cond cond"
			+ " where cond.id_soggetto = :businessId"
			+ "   and cond.data_aggiornamento <= :currentDt"
			+ "   and (:lastSyncDt is null or cond.data_aggiornamento > :lastSyncDt)"
			+ "   and ("
			+ "      :pointInTime = trunc(cond.data_inizio_conduzione) or"
			+ "      :pointInTime = (case when trunc(cond.data_fine_conduzione-1+1/24/60/60) < to_date('99991231','yyyymmdd') then trunc(cond.data_fine_conduzione-1+1/24/60/60)+1 else to_date('99991231','yyyymmdd') end) or"
			+ "      (:pointInTime = :syncStartDt and :pointInTime between trunc(cond.data_inizio_conduzione) and (case when trunc(cond.data_fine_conduzione-1+1/24/60/60) < to_date('99991231','yyyymmdd') then greatest(trunc(cond.data_fine_conduzione-1+1/24/60/60)+1, :syncStartDt) else to_date('99991231','yyyymmdd') end))"
			+ "   )")
	public List<String> getChangedParcelIds(@Bind("businessId") String businessId, @Bind("lastSyncDt") LocalDateTime lastSyncDt,
		@Bind("currentDt") LocalDateTime currentDt, @Bind("syncStartDt") LocalDate syncStartDt, @Bind("pointInTime") LocalDate pointInTime);
	
	@SqlQuery("select cond.isola_id as code,"
			+ "       cond.cod_nazionale as domainZoneId,"
			+ "       cond.shape as geom,"
			+ "       null as defaultLandUse"
			+ "  from tisole_cond cond"
			+ " where cond.id_soggetto = :businessId"
			+ "   and cond.isola_id in (<changeIds>)")
	@RegisterBeanMapper(SyncParcel.class)
	List<SyncParcel> getParcelsForWizard(@Bind("businessId") String businessId, @BindList("changeIds") List<String> changeIds);

	@SqlQuery("select count(*)"
			+ "  from npr.aablprif_2024_tab npr"
			+ " where sysdate between npr.data_inse_prif and npr.data_scad_prif"
			+ "   AND :pointInTime between to_date((npr.anno_iniz_prif-1)||'1101','yyyymmdd') and to_date((npr.anno_fine_prif-1)||'1031','yyyymmdd')"
			+ "   AND §geom_have_interactions(npr.shape, :plotsMbr)§"
			+ "   AND npr.dt_aggiornamento > :syncDate")
    public int getNprChanges(@Bind("plotsMbr") Geometry plotsMbr, @Bind("syncDate") LocalDateTime syncDate, @Bind("pointInTime") LocalDate pointInTime);

}
