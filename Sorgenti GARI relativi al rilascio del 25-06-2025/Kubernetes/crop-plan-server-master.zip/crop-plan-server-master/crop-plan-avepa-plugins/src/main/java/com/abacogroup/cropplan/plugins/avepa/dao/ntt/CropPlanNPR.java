package com.abacogroup.cropplan.plugins.avepa.dao.ntt;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CropPlanNPR
{
	private String parcelId;
	private Integer area;
	private String landCoverCode;
}