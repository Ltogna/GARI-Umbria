package com.abacogroup.agri.applicationforms.core.model.dto.unified;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CropPlanInfoDTO {

	private Long cropPlanId;
	private String cropPlanVersion;
}
