package com.abacogroup.cropplan.plugins.avepa.dao;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import com.abacogroup.cropplan.plugins.avepa.dao.ntt.LandUseDetailsExt;
import com.abacogroup.cropplan.plugins.avepa.dao.ntt.StyleWithCode;
import com.abacogroup.cropplan.sdk.mapper.LandCoverClassEditabilityArgumentFactory;
import com.abacogroup.cropplan.sdk.mapper.LandCoverClassEditabilityColumnMapper;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseDetails;
import com.abacogroup.cropplan.sdk.model.domain.LandCover;
import com.abacogroup.jdbi.EnhancedSqlObject;

@RegisterArgumentFactory(LandCoverClassEditabilityArgumentFactory.class)
@RegisterColumnMapper(LandCoverClassEditabilityColumnMapper.class)
public interface CropCodesSitiknowAppsDAO extends EnhancedSqlObject
{

	@SqlQuery("select s_code as code,"
		+ "           s_code || ' - ' || short_descr as description"
		+ "      from deco_codes"
		+ "     where p_code = 'CRPLCOVCOD'"
		+ "       and s_code in (<codes>)")
	@RegisterBeanMapper(LandUse.class)
	List<LandUse> getLandUses(@BindList("codes") List<String> codes, 
			@Bind("language") String language);

	@SqlQuery("select dc.s_code as code,"
		+ "		      ds.poly_fill_color as fillColor,"
		+ "		      ds.line_color as borderColor"
		+ "		 from dress_soil ds, deco_codes dc, esup_header eh, esup_dich_classe edc"
		+ "		where ds.p_code = 'COVCOD_CROP_PLAN'"
		+ "		  and ds.s_code = edc.classe"
		+ "		  and edc.id_esito = eh.id_esito"
		+ "       and eh.codice = (select nvl(max(param_val),'CROP_PLAN') from app_params where param_name='FARMER_CROP_PLAN_CODE')"
		+ "		  and edc.cod_vari = dc.s_code"
		+ "		  and dc.p_code = 'CRPLCOVCOD'"
		+ "       and dc.s_code in (<codes>)")
	@RegisterBeanMapper(StyleWithCode.class)
	List<StyleWithCode> getLandUseStyles(@BindList("codes") List<String> codes);

	@SqlQuery("select t.code, "
		+ "           t.description, "
		+ "		  	  null as defaultHarvestDays,"
		+ "		  	  null as defaultFromDate,"
		+ "      	  coalesce "
		+ "    		  ( "
		+ "    		      (select 1 "
		+ "                  from dual "
		+ "                 where (t.code = coalesce(<favouriteLandUseCodes>, null) or t.code in (<favouriteLandUseCodes>)) "
		+ "               ), 0 "
		+ "           ) as isFavourite"
		+ "      from ("
		+ "              select dc.s_code as code,"
		+ "		                dc.s_code || ' - ' || dc.short_descr as description"
		+ "	               from htu_groups gh, htu_groups lh, deco_codes dc"
		+ "	              where gh.type_id = 1"
		+ "	                and gh.p_code = 'HTU_COVCOD'"
		+ "	                and gh.s_code = '000'"
		+ "                 and lh.type_id = gh.type_id"
		+ "    	            and lh.group_code = gh.group_code"
		+ "	                and lh.p_code = 'CRPLCOVCOD'"
		+ "		            and dc.p_code = lh.p_code"
		+ "		            and dc.s_code = lh.s_code"
		+ "                 and :pointInTime between dc.dt_start and dc.dt_end"
		//+ "                 and ("
		//+ "                           select edc.classe "
		//+ "                             from esup_header eh, esup_dich_classe edc"
		//+ "                            where edc.id_esito = eh.id_esito"
		//+ "                              and eh.codice = (select nvl(max(param_val),'CROP_PLAN') from app_params where param_name='FARMER_CROP_PLAN_CODE')"
		//+ "                              and edc.cod_vari = dc.s_code"
		//+ "                     ) in (select lcci.land_cover_class_compatible from land_cover_class_intercomp lcci where lcci.land_cover_class = nvl(:landCoverCode,' ') union select :landCoverCode from dual where :landCoverCode is not null)"
		+ "           ) t"
		+ "     where (:search is null or t.code like '%'||upper(:search)||'%' or upper(t.description) like '%'||upper(:search)||'%')"
		+ "  order by isFavourite desc, t.description, t.code")
	@RegisterBeanMapper(LandUseDetails.class)
	ResultIterator<LandUseDetails> getLandUseCodes(
			//@Bind("landCoverCode") String landCoverCode,
			@Bind("pointInTime") LocalDateTime pointInTime, 
			@Bind("search") String search,
			@BindList(value = "favouriteLandUseCodes", onEmpty = BindList.EmptyHandling.NULL_STRING) List<String> favouriteLandUseCodes,
			@Bind("language") String language);

	@SqlQuery("select "
	+ "  t.code, "
	+ "  t.description, "
	+ "  LandCoverDecoder.landCoverCode as landUseClassCode, "
	+ "  LandCoverDecoder.landCoverDescription as landUseClassDescription, "
	+ "  coalesce((select 1 from dual where (t.code = coalesce(<favouriteLandUseCodes>, null) or t.code in (<favouriteLandUseCodes>))), 0 ) as isFavourite, "
	+ "  coalesce(HarvestInfo.defaultHarvestDays,NULL) as defaultHarvestDays,"
	+ "  coalesce(HarvestInfo.defaultFromDate,NULL) as defaultFromDate"
	+ "  from ("
	+ "        select dc.s_code as code, "
	+ "             dc.s_code || ' - ' || dc.short_descr as description "
	+ "             from htu_groups gh, htu_groups lh, deco_codes dc "
	+ "        where gh.type_id = 1 "
	+ "             and gh.p_code = 'HTU_COVCOD' "
 	+ "             and gh.s_code = '000' "
    + "             and lh.type_id = gh.type_id "
	+ "             and lh.group_code = gh.group_code "
	+ "             and lh.p_code = 'CRPLCOVCOD' "
	+ "             and dc.p_code = lh.p_code "
	+ "             and dc.s_code = lh.s_code "
	+ "             and :pointInTime between dc.dt_start and dc.dt_end "
	+ "             and dc.s_code like :code || '%%' "
 	+ "  ) t "
	+ "  LEFT JOIN "
	+ "  (select edc.classe ,edc.cod_vari "
	+ "    from esup_header eh, esup_dich_classe edc "
	+ "    where edc.id_esito = eh.id_esito "
	+ "    and eh.codice = (select nvl(max(param_val),'CROP_PLAN') from app_params where param_name='FARMER_CROP_PLAN_CODE') "
	+ "  ) LandCover "
	+ "  ON LandCover.cod_vari = t.code "
	+ "  LEFT JOIN "
	+ "  (select distinct decoder.s_code_parent as landCoverCode, decoder.s_code_child AS landCoverChildCode, "
	+ "    deco_srv.get_decode('COVCOD_CROP_PLAN', decoder.s_code_parent) as landCoverDescription "
	+ "    from (select s_code_parent,s_code_child from deco_codes_groups where deco_codes_groups.p_code_child='COVCOD' and deco_codes_groups.p_code_parent='COVCOD_CROP_PLAN' ) decoder "
	+ "  ) LandCoverDecoder "
	+ "  ON LandCoverDecoder.landCoverChildCode in (LandCover.classe) AND ROWNUM <= 1 "
	+ "  LEFT JOIN "
	+ "  (select trunc(c.dt_fine_colt - c.dt_inizio_colt) as defaultHarvestDays, "
	+ "    to_char(c.dt_inizio_colt, 'yyyymmdd') as defaultFromDate, "
	+ "    c.ext_code AS ext_code, "
	+ "    c.anno_inizio AS anno_inizio, "
	+ "    c.anno_fine AS anno_fine "
	+ "    from fascicolo.t_colture c "
	+ "    where :pointInTime between c.dt_inizio and c.dt_fine "
    + "  ) HarvestInfo ON HarvestInfo.ext_code = t.code AND EXTRACT(YEAR FROM :pointInTime ) between HarvestInfo.anno_inizio and HarvestInfo.anno_fine AND ROWNUM <= 1 "
	+ "  where (:search is null or upper(t.description) like '%'||upper(:search)||'%') "
	+ "  order by isFavourite desc, t.description, t.code")
	@RegisterBeanMapper(LandUseDetailsExt.class)
	ResultIterator<LandUseDetailsExt> getLandUseCodesExt(
			//@Bind("landCoverCode") String landCoverCode,
			@Bind("pointInTime") LocalDateTime pointInTime, 
			@Bind("search") String search,
			@BindList(value = "favouriteLandUseCodes", onEmpty = BindList.EmptyHandling.NULL_STRING) List<String> favouriteLandUseCodes,
			@Bind("language") String language,
			@Bind("code") String code);
	
	
	@SqlQuery("select current_code \n"
			+ "  from cropplan_trans_land_uses \n"
			+ " where start_campaign = :year \n"
			+ "   and previous_code = :code \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n"
			+ " fetch first row only")
	String transcodeLandUseCode(@Bind("code") String code, @Bind("year") int year);
	
	
	@SqlQuery("select distinct dc.s_code as code"
		+ "      from htu_groups gh, htu_groups lh, deco_codes dc"
		+ "     where gh.type_id = 1"
		+ "		  and gh.p_code = 'HTU_COVCOD'"
		+ "		  and gh.s_code = '000'"
		+ "       and lh.type_id = gh.type_id"
		+ "		  and lh.group_code = gh.group_code"
		+ "		  and lh.p_code = 'CRPLCOVCOD'"
		+ "		  and dc.p_code = lh.p_code"
		+ "		  and dc.s_code = lh.s_code"
		+ "       and (:landCoverCode = ("
		+ "              select edc.classe"
		+ "                from esup_header eh, esup_dich_classe edc"
		+ "               where edc.id_esito = eh.id_esito"
		+ "	                and eh.codice = (select nvl(max(param_val),'CROP_PLAN') from app_params where param_name='FARMER_CROP_PLAN_CODE')"
		+ "		            and edc.cod_vari = dc.s_code) or"
		+ "            ("
		+ "              select edc.classe"
		+ "                from esup_header eh, esup_dich_classe edc"
		+ "               where edc.id_esito = eh.id_esito"
		+ "	                and eh.codice = (select nvl(max(param_val),'CROP_PLAN') from app_params where param_name='FARMER_CROP_PLAN_CODE')"
		+ "		            and edc.cod_vari = dc.s_code) in (select lcci.land_cover_class_compatible from land_cover_class_intercomp lcci where lcci.land_cover_class = nvl(:landCoverCode, ' '))"
		+ "           )")
	List<String> getLandUseCodesList(@Bind("landCoverCode") String landCoverCode);

	@SqlQuery("select dc.s_code as code,"
		+ "		      dc.s_code || ' - ' || dc.short_descr as description,"
		+ "  		  null as defaultHarvestDays,"
		+ "	    	  null as defaultFromDate"
		+ "      from htu_groups gh, htu_groups lh, deco_codes dc"
		+ "     where gh.type_id = 1"
		+ "	      and gh.p_code = 'HTU_COVCOD'"
		+ "	      and gh.s_code = '000'"
		+ "       and lh.type_id = gh.type_id"
		+ "       and lh.group_code = gh.group_code"
		+ "	      and lh.p_code = 'CRPLCOVCOD'"
		+ "	      and dc.p_code = lh.p_code"
		+ "	      and dc.s_code = lh.s_code"
		+ "       and :pointInTime between dc.dt_start and dc.dt_end"
		+ "       and dc.s_code = :code")
	@RegisterBeanMapper(LandUseDetails.class)
	Optional<LandUseDetails> getLandUseCode(
		@Bind("code") String code,
		@Bind("pointInTime") LocalDateTime pointInTime, 
		@Bind("language") String language);

	/*@SqlQuery("select trunc(c.dt_fine_colt - c.dt_inizio_colt) as defaultHarvestDays,"
		+ "			  to_char(c.dt_inizio_colt, 'yyyymmdd') as defaultFromDate"
		+ "      from fascicolo.t_colture c"
		+ "     where c.ext_code=:code"
		+ "       and :campaignYear between c.anno_inizio and c.anno_fine"
		+ "       and sysdate between c.dt_inizio and c.dt_fine"
		+ "		fetch first 1 row only")
	@RegisterBeanMapper(LandUseHarvestInfo.class)
	LandUseHarvestInfo getLandUseHarvestInfo(
		@Bind("code") String code, @Bind("campaignYear") int campaignYear);*/

	@SqlQuery("select edc.classe"
		+ "      from esup_header eh, esup_dich_classe edc"
		+ "     where edc.id_esito = eh.id_esito"
		+ "       and eh.codice = (select nvl(max(param_val),'CROP_PLAN') from app_params where param_name='FARMER_CROP_PLAN_CODE')"
		+ "       and edc.cod_vari = :landUseCode")
	String getLandCoverCode(@Bind("landUseCode") String landUseCode);

	@SqlQuery("select distinct s_code_parent as landCoverCode,"
		+ "           deco_srv.get_decode('COVCOD_CROP_PLAN', s_code_parent) as landCoverDescription"
		+ "      from (select s_code_parent from deco_codes_groups where p_code_child='COVCOD' and s_code_child in (<landCoverCodes>) and p_code_parent='COVCOD_CROP_PLAN')")
	@RegisterBeanMapper(LandCover.class)
	List<LandCover> getLandCoverDescriptions(@BindList("landCoverCodes") List<String> landCoverCodes);

	@SqlQuery("select dc.s_code as code,"
		+ "           ds.poly_fill_color as fillColor,"
		+ "           ds.line_color as borderColor,"
		+ "           'stroke' as fillStyle"
		+ "      from dress_soil ds, deco_codes dc"
		+ "     where ds.p_code = 'COVCOD_CROP_PLAN'"
		+ "       and ds.s_code in (<codes>)"
		+ "       and dc.p_code = ds.p_code"
		+ "       and dc.s_code = ds.s_code")
	@RegisterBeanMapper(StyleWithCode.class)
	List<StyleWithCode> getLandCoverStyles(@BindList("codes") List<String> codes);

	@SqlQuery("select count(*)"
		+ "      from esup_header eh, esup_dich_classe edc"
		+ "     where edc.id_esito = eh.id_esito"
		+ "       and eh.codice = (select nvl(max(param_val),'CROP_PLAN') from app_params where param_name='FARMER_CROP_PLAN_CODE')"
		+ "       and edc.cod_vari = :code"
		+ "       and (:landCoverCode = edc.classe or edc.classe in (select lcci.land_cover_class_compatible from land_cover_class_intercomp lcci where lcci.land_cover_class = nvl(:landCoverCode, ' ')))")
	Integer isLandUseCompatible(@Bind("code") String code, @Bind("landCoverCode") String landCoverCode);

	@SqlQuery("select distinct land_cover_class "
		+ "      from land_cover_class_intercomp lcci "
		+ "     where lcci.land_cover_class_compatible = nvl(:landCoverCode, ' ')")
	List<String> getLandCoversOnWhichTheLandCoverIsCompatible(@Bind("landCoverCode") String landCoverCode);

	/*default void createCrplCovCodCache() {
		useHandle(h -> {
			h.createUpdate("create table cache_crplcovcod (CODE VARCHAR2(20 CHAR) NOT NULL,"
					+ "DESCRIPTION VARCHAR2(4000 CHAR),"
					+ "DT_START DATE NOT NULL,"
					+ "DT_END DATE NOT NULL,"
					+ "CONSTRAINT cache_crplcovcod_PK PRIMARY KEY (CODE, DT_END))")
					.execute();
		});
	}

	default void updateCrplCovCodCache() {
		useTransaction(dao -> {
			dao.useHandle(h -> h.createUpdate("delete from cache_crplcovcod")
					.execute());
			dao.useHandle(h -> h.createUpdate("insert into cache_crplcovcod SELECT dc.s_code as code"
					+ " ,dc.s_code || ' - ' || deco_srv.get_decode('CRPLCOVCOD', dc.s_code) as description,"
					+ "dc.dt_start, dc.dt_end "
					+ " from htu_groups gh, htu_groups lh, deco_codes dc "
					+ " where gh.type_id = 1 and gh.p_code = 'HTU_COVCOD' and gh.s_code = '000' "
					+ " and lh.type_id = gh.type_id and lh.group_code = gh.group_code and lh.p_code = 'CRPLCOVCOD' "
					+ " and dc.p_code = lh.p_code and dc.s_code = lh.s_code")
					.execute());
		});
	}*/

//	@SqlQuery("select form_type"
//		+ "      from land_cover_class_forms_types"
//		+ "     where land_cover_class = :code")
//	List<LandCoverClassFormsTypes> getLandCoverFormsTypes(@Bind("code") String code);

}
