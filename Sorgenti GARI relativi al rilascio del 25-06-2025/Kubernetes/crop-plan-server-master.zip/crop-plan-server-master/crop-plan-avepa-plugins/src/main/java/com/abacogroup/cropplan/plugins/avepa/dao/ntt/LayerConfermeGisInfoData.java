package com.abacogroup.cropplan.plugins.avepa.dao.ntt;

import org.locationtech.jts.geom.Geometry;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LayerConfermeGisInfoData {
    private String title;
    private Integer area;
    private Geometry mbr;
    private Integer anno_riferimento;
    private String codice_intervento;
    private Integer anno_domanda_iniziale;
    private Long area_confermata;
    private Long area_grafica_poligono;
    private String cod_nazionale;
    private Integer foglio;
}
