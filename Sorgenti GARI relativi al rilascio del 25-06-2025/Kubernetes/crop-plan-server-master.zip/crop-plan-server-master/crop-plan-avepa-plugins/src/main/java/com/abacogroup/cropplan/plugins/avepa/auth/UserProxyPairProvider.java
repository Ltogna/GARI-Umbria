package com.abacogroup.cropplan.plugins.avepa.auth;

import java.util.HashMap;
import java.util.Map;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;

public class UserProxyPairProvider {

	private static final Object PARENT_USERNAME_KEY = "parent_username";
	private static final Object PROXY_CODE_KEY = "cod_ente";

	private final Sso2Client ssoClient;

	public UserProxyPairProvider(Sso2Client ssoClient) {
		this.ssoClient = ssoClient;
	}

	public UserProxyPair getUserProxyPair(User user) {
		Map<String, String> properties = ssoClient.getUserProperties(user); // There is a cache at ssoClient level
		if (properties == null) {
			properties = new HashMap<>(0);
		}

		String parentUserName = properties.get(PARENT_USERNAME_KEY);
		String proxyCode = properties.get(PROXY_CODE_KEY);

		if (parentUserName == null) {
			// This happens in dev and test because we do not have parent users
			return new UserProxyPair(user.getName(), proxyCode);
		}

		return new UserProxyPair(parentUserName, proxyCode);
	}

}
