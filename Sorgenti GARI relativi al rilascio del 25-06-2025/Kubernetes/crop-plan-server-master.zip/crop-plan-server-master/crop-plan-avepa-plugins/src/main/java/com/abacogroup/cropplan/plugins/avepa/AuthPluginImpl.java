package com.abacogroup.cropplan.plugins.avepa;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.cropplan.plugins.avepa.auth.UserProxyPairProvider;
import com.abacogroup.cropplan.plugins.avepa.dao.AuthFascicoloDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.AuthSitiknowAppsDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.AuthSitiknowDAO;
import com.abacogroup.cropplan.plugins.avepa.utils.AuthUtils;
import com.abacogroup.cropplan.sdk.model.auth.BusinessAccessLevel;
import com.abacogroup.cropplan.sdk.model.auth.CropPlanTypeAccessLevel;
import com.abacogroup.cropplan.sdk.spi.AuthPlugin;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

public class AuthPluginImpl implements AuthPlugin, InitializablePlugin
{
	private static final String BUSINESS_LOCKED_MESSAGE_CODE = "BUSINESS_LOCKED";
	private static final String BUSINESS_MANAGED_BY_OTHER_OP_MESSAGE_CODE = "BUSINESS_MANAGED_BY_OTHER_OP";
	
	private static final String JDBI_NAME_SITIKNOW = "dbSitiknow";
	private static final String JDBI_NAME_SITIKNOW_APPS = "dbSitiknowApps";
	private static final String JDBI_NAME_FASCICOLO = "dbFascicolo";
	private static final String AVEPA_CROP_PLAN_TYPE_CODE = "CROPPLAN";
	private static final String AVEPA_CROP_PLAN_2025_TYPE_CODE = "CROPPLAN_2025";
	// private static final String SSO2_URL_PROPERTY_NAME = "sso2url";

	private static final String AVEPA_SCOP_OP = "IT05";

	private AuthSitiknowDAO authSitiknowDAO;
	private AuthSitiknowAppsDAO authSitiknowAppsDAO;
	private AuthFascicoloDAO authFascicoloDAO;

	@Override
	public void initialize(PluginsEnvironment env)
	{
		var jdbiSitiknow = env.getJdbi(JDBI_NAME_SITIKNOW);
		if (jdbiSitiknow == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITIKNOW);

		var jdbiSitiknowApps = env.getJdbi(JDBI_NAME_SITIKNOW_APPS);
		if (jdbiSitiknowApps == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITIKNOW_APPS);

		var jdbiFascicolo = env.getJdbi(JDBI_NAME_FASCICOLO);
		if (jdbiFascicolo == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_FASCICOLO);
		
		authSitiknowDAO = jdbiSitiknow.onDemand(AuthSitiknowDAO.class);
		authSitiknowAppsDAO = jdbiSitiknowApps.onDemand(AuthSitiknowAppsDAO.class);
		authFascicoloDAO = jdbiFascicolo.onDemand(AuthFascicoloDAO.class);
	}

	@Override
	public BusinessAccessLevel getBusinessAccessLevel(RuntimeEnvironment env, String businessId)
	{
		var uppp = new UserProxyPairProvider(env.getSso2Client());
		var userName = uppp.getUserProxyPair(env.getUser()).getUserName();
		try
		{
			var lBusinessId = Long.parseLong(businessId);
			
			var canIngoreProxies = AuthUtils.canIgnoreProxies(userName, authSitiknowDAO);
			if (canIngoreProxies)
				return BusinessAccessLevel.WRITE;

			var canWrite = authSitiknowDAO.checkUserProxy(lBusinessId, userName, true);
			if (canWrite)
				return BusinessAccessLevel.WRITE;

			var canRead = authSitiknowDAO.checkUserProxy(lBusinessId, userName, false);
			if (canRead)
				return BusinessAccessLevel.READ;
		}
		catch (NumberFormatException e)
		{
		}

		return BusinessAccessLevel.NO_ACCESS;
	}

	@Override
	public CropPlanTypeAccessLevel getCropPlanTypeAccessLevel(RuntimeEnvironment env, String businessId, String cropPlanTypeCode)
	{
		var uppp = new UserProxyPairProvider(env.getSso2Client());
		var userName = uppp.getUserProxyPair(env.getUser()).getUserName();
		
		if (AuthUtils.isCrplServiceUser(userName))
			return CropPlanTypeAccessLevel.CREATE;
		
		if(AVEPA_CROP_PLAN_TYPE_CODE.equals(cropPlanTypeCode) || AVEPA_CROP_PLAN_2025_TYPE_CODE.equals(cropPlanTypeCode)) {

			String scopOp = authFascicoloDAO.getScopOpFromBusinessId(businessId);
			if (StringUtils.isBlank(scopOp) || !AVEPA_SCOP_OP.equals(scopOp)) {
				var ret = CropPlanTypeAccessLevel.READ;
				ret.setMessageCode(BUSINESS_MANAGED_BY_OTHER_OP_MESSAGE_CODE);
				return ret;
			}
		}

		if(AVEPA_CROP_PLAN_TYPE_CODE.equals(cropPlanTypeCode) || AVEPA_CROP_PLAN_2025_TYPE_CODE.equals(cropPlanTypeCode)) {
			String businessLockedFunction = authSitiknowAppsDAO.getBusinessLockedFunction();
			String businessLockedResult = authSitiknowAppsDAO.checkBusinessLocked(businessLockedFunction, env.getUserId(), businessId);
			if(businessLockedResult != null) {
				var ret = CropPlanTypeAccessLevel.READ;
				ret.setMessageCode(BUSINESS_LOCKED_MESSAGE_CODE);
				return ret;
			}
		}
		
		try
		{
			var lBusinessId = Long.parseLong(businessId);
			
			var canIngoreProxies = AuthUtils.canIgnoreProxies(userName, authSitiknowDAO);
			if (canIngoreProxies)
				return CropPlanTypeAccessLevel.CREATE;

			var canWrite = authSitiknowDAO.checkUserProxy(lBusinessId, userName, true);
			if (canWrite)
				return CropPlanTypeAccessLevel.CREATE;

			var canRead = authSitiknowDAO.checkUserProxy(lBusinessId, userName, false);
			if (canRead)
				return CropPlanTypeAccessLevel.READ;
		}
		catch (NumberFormatException e)
		{
		}

		return CropPlanTypeAccessLevel.NO_ACCESS;
	}

	/*private String getSSo2Url(RuntimeEnvironment env) {
		if (env.getProperty(SSO2_URL_PROPERTY_NAME) == null || StringUtils.isBlank(String.valueOf(env.getProperty(SSO2_URL_PROPERTY_NAME))))
			throw new IllegalStateException("SSO url not define in config!");

		return String.valueOf(env.getProperty(SSO2_URL_PROPERTY_NAME));
	}*/

	@Override
	public String getCropPlanTypeLockedErrorCode(RuntimeEnvironment env, String businessId, String cropPlanTypeCode) {

		var uppp = new UserProxyPairProvider(env.getSso2Client());
		var userName = uppp.getUserProxyPair(env.getUser()).getUserName();
		
		if (AuthUtils.isCrplServiceUser(userName))
			return null; 
		
		if(AVEPA_CROP_PLAN_TYPE_CODE.equals(cropPlanTypeCode) || AVEPA_CROP_PLAN_2025_TYPE_CODE.equals(cropPlanTypeCode)) {
			String scopOp = authFascicoloDAO.getScopOpFromBusinessId(businessId);
			if (StringUtils.isBlank(scopOp) || !AVEPA_SCOP_OP.equals(scopOp)) {
				return BUSINESS_MANAGED_BY_OTHER_OP_MESSAGE_CODE;
			}
		}

		if(AVEPA_CROP_PLAN_TYPE_CODE.equals(cropPlanTypeCode)) {	
			String businessLockedFunction = authSitiknowAppsDAO.getBusinessLockedFunction();
			String businessLockedResult = authSitiknowAppsDAO.checkBusinessLocked(businessLockedFunction, env.getUserId(), businessId);
			if(businessLockedResult != null) {
				return BUSINESS_LOCKED_MESSAGE_CODE;
			}
		}
		
		return null;
	}
}
