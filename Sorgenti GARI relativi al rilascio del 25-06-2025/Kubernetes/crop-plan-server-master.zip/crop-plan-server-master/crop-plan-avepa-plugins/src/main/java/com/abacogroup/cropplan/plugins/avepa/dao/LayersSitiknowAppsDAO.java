package com.abacogroup.cropplan.plugins.avepa.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import com.abacogroup.cropplan.plugins.avepa.dao.ntt.FarmerAdditionalLayer;
import com.abacogroup.jdbi.EnhancedSqlObject;

public interface LayersSitiknowAppsDAO extends EnhancedSqlObject
{

	@SqlQuery("select fwl.layer_id as code,"
			+ "           fws.server_type as layerType,"
			+ "           fws.description||'->'||fwl.description as description,"
			+ "           fws.url,"
			+ "           fwl.fl_visibile as flVisible,"
			+ "           fwl.name as layer,"
			+ "           fws.srs,"
			+ "           fws.format,"
			+ "           fws.colore as bgcolor,"
			+ "           fws.fl_trasp as flTransparent,"
			+ "           fws.context_function as contextFunction,"
			+ "           fwl.max_pixel_val as maxPixelVal"
			+ "      from farmer_wms_servers fws, farmer_wms_servers_comuni fwsc, farmer_wms_layers fwl"
			+ "     where (fws.subj_entity_id = :businessId or fws.subj_entity_id is null)"
			+ "       and (fws.sso_user = :userId or fws.sso_user is null)"
			+ "       and fwsc.server_id(+) = fws.server_id"
			+ "       and (fwsc.comune = :domainZoneId or fwsc.comune is null)"
			+ "       and fwl.server_id = fws.server_id"
			+ "       and upper(fws.server_id) like upper('agea_wmts_%')"
			+ "  order by fws.display_order, fwl.display_order")
	@RegisterBeanMapper(FarmerAdditionalLayer.class)
	public List<FarmerAdditionalLayer> getAgeaAdditionalLayers(@Bind("businessId") String businessId,
			@Bind("domainZoneId") String domainZoneId, @Bind("userId") String userId);

	@SqlQuery("select council_sector_id from lau_councils_sectors where council_sector_code = :domainZoneId and §current_timestamp§ between dt_start and dt_end")
	public Long getCouncilSectorId(@Bind("domainZoneId") String domainZoneId);

	@SqlQuery("select param_val from app_params where param_name = :paramName")
	public String getAppParam(@Bind("paramName") String paramName);

	@SqlQuery("select deco_srv.get_decode(:pCode, :sCode, :lang) as description from dual")
	public String getDecodedIntlnDescription(
			@Bind("pCode") String pCode,
			@Bind("sCode") String sCode,
			@Bind("lang") String lang);
}
