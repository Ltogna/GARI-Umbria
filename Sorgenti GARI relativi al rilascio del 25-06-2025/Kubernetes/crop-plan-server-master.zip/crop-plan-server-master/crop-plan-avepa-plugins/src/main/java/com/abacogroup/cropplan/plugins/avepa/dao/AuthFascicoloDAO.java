package com.abacogroup.cropplan.plugins.avepa.dao;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import com.abacogroup.jdbi.EnhancedSqlObject;

public interface AuthFascicoloDAO extends EnhancedSqlObject {

	@SqlQuery("select t.sco_op \n"
			+ "  from tfascicolo t \n"
			+ " where t.id_soggetto = :businessId \n"
			+ "   and §current_timestamp§ between t.dt_inizio and t.dt_fine")
	public String getScopOpFromBusinessId(@Bind("businessId") String businessId);
}
