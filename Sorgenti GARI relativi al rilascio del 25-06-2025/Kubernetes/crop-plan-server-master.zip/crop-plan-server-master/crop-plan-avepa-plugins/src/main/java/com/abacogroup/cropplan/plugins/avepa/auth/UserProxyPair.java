package com.abacogroup.cropplan.plugins.avepa.auth;

import lombok.AllArgsConstructor;
import lombok.Value;

@Value
@AllArgsConstructor
public class UserProxyPair {

	private final String userName;
	private final String proxyCode;

}
