package com.abacogroup.cropplan.plugins.avepa;

import static java.util.stream.Collectors.toList;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.locationtech.jts.geom.Geometry;

import com.abacogroup.cropplan.plugins.avepa.dao.SyncCropPlanDAO;
import com.abacogroup.cropplan.plugins.avepa.dao.SyncSitiDAO;
import com.abacogroup.cropplan.sdk.model.sync.LatestSync;
import com.abacogroup.cropplan.sdk.model.sync.SyncParcel;
import com.abacogroup.cropplan.sdk.model.sync.WizardPlot;
import com.abacogroup.cropplan.sdk.spi.SyncPlugin;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

public class SyncPluginImpl implements SyncPlugin, InitializablePlugin {

	private static final String JDBI_NAME_SITI = "dbSiti";
	//private static final String JDBI_NAME_SITIKNOW = "dbSitiknow";
	private static final String JDBI_CROP_PLAN = "mainDB";
	private static final String SYNC_START_DATE = "20221101";
	//private static final String DEFAULT_SYNC_START_DATE = "20211101";
	//private static final String NEW_SYNC_START_DATE = "20221101";
	private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");

	private SyncSitiDAO syncSitiDAO;
	//private SyncSitiknowDAO syncSitiknowDAO;
	private SyncCropPlanDAO syncCropPlanDAO;

	@Override
	public void initialize(PluginsEnvironment env) {
		var jdbiSiti = env.getJdbi(JDBI_NAME_SITI);
		if (jdbiSiti == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITI);
		
		/*var jdbiSitiknow = env.getJdbi(JDBI_NAME_SITIKNOW);
		if (jdbiSitiknow == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_NAME_SITIKNOW);*/
		
		var jdbiCropPlan = env.getJdbi(JDBI_CROP_PLAN);
		if (jdbiCropPlan == null)
			throw new IllegalStateException("Cannot get jdbi instance with name " + JDBI_CROP_PLAN);

		syncSitiDAO = jdbiSiti.onDemand(SyncSitiDAO.class);
		//syncSitiknowDAO = jdbiSitiknow.onDemand(SyncSitiknowDAO.class);
		syncCropPlanDAO = jdbiCropPlan.onDemand(SyncCropPlanDAO.class);
	}

	@Override
	public LocalDate getOldestChangesDateFromLpisDate(RuntimeEnvironment env, String businessId,
			Long cropPlanId, LocalDateTime lastSyncDt, LocalDateTime currentDt, boolean lite) {
		
		LocalDate ssd = LocalDate.parse(SYNC_START_DATE, FORMATTER);
		
		if (lastSyncDt == null)
			return ssd;
		
		LocalDateTime ret = syncSitiDAO.getOldestChangesDate(businessId, lastSyncDt, currentDt, ssd);
		return ret != null ? ret.toLocalDate() : null;
		
		/** OLD SYNC IMPLEMENTATION */
		/*boolean useNewSync = !StringUtils.isBlank(syncSitiknowDAO.useNewSyncFarmer(businessId));
		
		var syncStartDt = useNewSync ? NEW_SYNC_START_DATE : DEFAULT_SYNC_START_DATE;
		var ssd = LocalDate.parse(syncStartDt, FORMATTER);

		if (lastSyncDt == null)
			return ssd;
		
		if (useNewSync) {
			Integer numUpdatedNPR = syncSitiknowDAO.getNumUpdatedNPR(businessId, lastSyncDt, currentDt);
			return numUpdatedNPR > 0 ? ssd : null;
		} else {
			var ret = syncSitiknowDAO.getOldestChangesDate(businessId, lastSyncDt, currentDt, ssd);
			return ret != null ? ret.toLocalDate() : null;		
		}*/
	}

	@Override
	public LocalDate getNextChangesDateFromLpisDate(RuntimeEnvironment env, String businessId,
			Long cropPlanId, LocalDate pointInTime, LocalDateTime lastSyncDt, LocalDateTime currentDt, boolean lite) {
		
		LocalDateTime pointInTimeAtTheEndOfTheDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));
		
		LocalDateTime ret = syncSitiDAO.getNextChangesDate(businessId, lastSyncDt, currentDt, pointInTimeAtTheEndOfTheDay);
		
		return ret != null ? ret.toLocalDate() : null;
		
		/** OLD SYNC IMPLEMENTATION */
		/*boolean useNewSync = !StringUtils.isBlank(syncSitiknowDAO.useNewSyncFarmer(businessId));
		if (useNewSync) {
			return null;
		} else {
			if (pointInTime.getYear() == 2022)
				return LocalDate.of(2023, 5, 15);
			
			var ret = syncSitiknowDAO.getNextChangesDate(businessId, lastSyncDt, currentDt,
					LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59)));
			return ret != null ? ret.toLocalDate() : null;
		}*/
	}

	@Override
	public List<String> getChangesFromLpis(RuntimeEnvironment env, String businessId, Long cropPlanId,
			LocalDate pointInTime, LocalDateTime lastSyncDt, LocalDateTime currentDt, boolean firstSync, boolean lite) {
		
		LocalDateTime pointInTimeAtTheEndOfTheDay = LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59));
		LocalDate ssd = LocalDate.parse(SYNC_START_DATE, FORMATTER);
		
		List<String> changeIds;
		if (lastSyncDt == null) {
			if (firstSync) {
				changeIds = new ArrayList<>();
				// changeIds = syncSitiDAO.getAllParcelIds(businessId, currentDt, pointInTimeAtTheEndOfTheDay);
				syncSitiDAO.consumeAllParcelIds(businessId, currentDt, pointInTimeAtTheEndOfTheDay, changeIds::add);
				// changeIds.addAll(syncCropPlanDAO.getAllCropPlanParcelIds(cropPlanId, currentDt));
				syncCropPlanDAO.consumeAllCropPlanParcelIds(cropPlanId, currentDt, changeIds::add);
			} else {
				changeIds = syncSitiDAO.getChangedParcelIds(businessId, null, currentDt, ssd, pointInTimeAtTheEndOfTheDay);
			}
		} else {
			changeIds = syncSitiDAO.getChangedParcelIds(businessId, lastSyncDt, currentDt, ssd, pointInTimeAtTheEndOfTheDay);
			changeIds.addAll(syncSitiDAO.getDeletedParcelIds(businessId, lastSyncDt, currentDt, ssd, pointInTimeAtTheEndOfTheDay));
		}
		
		return changeIds.stream().distinct().collect(toList());
		
		/** OLD SYNC IMPLEMENTATION */
		/*boolean useNewSync = !StringUtils.isBlank(syncSitiknowDAO.useNewSyncFarmer(businessId));
		
		if (useNewSync) {
			List<String> changeIds = new ArrayList<>();
			
			List<String> currentNPR = syncSitiknowDAO.getAllNPR(businessId, currentDt, 
					LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59)));
			
			List<CropPlanNPR> cropPlanNPR = syncCropPlanDAO.getCropPlanNPR(cropPlanId, currentDt, LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59)));
			cropPlanNPR.forEach(cpNPR -> {
				if (currentNPR.contains(cpNPR.getParcelId())) {
					currentNPR.remove(cpNPR.getParcelId());
				} else {
					changeIds.add(cpNPR.getParcelId());
				}
			});
			changeIds.addAll(currentNPR);
			return changeIds.stream().distinct().collect(toList());
			
		} else {
			if (firstSync)
				return syncSitiknowDAO.getAllCadastralParcels(businessId, currentDt, LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59)));
			else {
				LocalDateTime pointInTimeFrom;
				if (pointInTime.getYear() == 2023)
					pointInTimeFrom = LocalDateTime.of(pointInTime.minusYears(2l).plusDays(1l), LocalTime.of(23, 59, 59));
				else
					pointInTimeFrom = LocalDateTime.of(pointInTime.minusYears(1l).plusDays(1l), LocalTime.of(23, 59, 59));
				
				return syncSitiknowDAO.getChangedCadastralParcels(businessId, lastSyncDt, currentDt, 
						LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59)), pointInTimeFrom);
			}
		}*/
	}
	
	/*private String hashGeom(Geometry geom) {
		MessageDigest digester;
		try {
			digester = MessageDigest.getInstance("SHA-1");
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}
		digester.update(geom.getClass().getName().getBytes());
		ByteBuffer buff = ByteBuffer.allocate(16);
		geom.normalize();
		geom.apply((Coordinate c) -> {
			buff.rewind();
			buff.putDouble(c.getX());
			buff.putDouble(c.getY());
			digester.update(buff.array());
		});

		return Base64.getEncoder().encodeToString(digester.digest());
	}*/

	@Override
	public String getChangeId(RuntimeEnvironment env, String parcelCode) {
		return parcelCode;
	}

    @Override
    public List<SyncParcel> getLpisParcelsForWizard(RuntimeEnvironment env, String businessId, Long cropPlanId,
                                                    LocalDate pointInTime, LocalDateTime currentDt, List<String> changeIds) {

        List<SyncParcel> res = new ArrayList<>(syncSitiDAO.getParcelsForWizard(businessId, currentDt,
                LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59)), changeIds));
        List<String> changedIdsWithParcel = res.stream().map(SyncParcel::getCode).distinct().collect(toList());

        List<String> changeIdsWithoutParcel = new ArrayList<>();
        for (String changeId : changeIds) {
            if(!changedIdsWithParcel.contains(changeId)) {
                changeIdsWithoutParcel.add(changeId);
            }
        }
        if(!changeIdsWithoutParcel.isEmpty()) {
            res.addAll(syncSitiDAO.getParcelDomainZoneIds(changeIdsWithoutParcel));
        }
        
        changeIdsWithoutParcel = new ArrayList<>();
        for (String changeId : changeIds) {
            if(!changedIdsWithParcel.contains(changeId)) {
                changeIdsWithoutParcel.add(changeId);
            }
        }
        if(!changeIdsWithoutParcel.isEmpty()) {
            res.addAll(syncSitiDAO.getParcelDomainZoneIdsByIsolaNprId(changeIdsWithoutParcel));
        }

        return res;

		/** OLD SYNC IMPLEMENTATION */
		/*boolean useNewSync = !StringUtils.isBlank(syncSitiknowDAO.useNewSyncFarmer(businessId));

		List<SyncParcel> parcels = syncSitiknowDAO.getParcelsForWizard(businessId,
				LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59)), changeId);

		if (useNewSync) {
			if (parcels.isEmpty()) {
				parcels.addAll(syncSitiknowDAO.getNoMoreHoldedParcelsForWizard(LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59)), changeId));
			}

			return parcels;
		} else {

			List<SyncParcel> yesterdayParcels = syncSitiknowDAO.getParcelsForWizard(businessId,
					LocalDateTime.of(pointInTime.minusYears(1), LocalTime.of(23, 59, 59)), changeId);
			yesterdayParcels.forEach(yp -> {
				var found = false;
				for (var p : parcels) {
					if (p.getCode().equals(yp.getCode())) {
						found = true;
						break;
					}
				}

				if (!found) {
					yp.setGeom(null);
					parcels.add(yp);
				}
			});

			var found = false;
			for (var p : parcels) {
				if (p.getCode().equals(changeId)) {
					found = true;
					break;
				}
			}
			if (!found) {
				parcels.addAll(syncSitiknowDAO.getNoMoreHoldedParcelsForWizard(LocalDateTime.of(pointInTime, LocalTime.of(23, 59, 59)), changeId));
			}

			Map<String, List<SyncParcel>> parcelsMap = parcels.stream()
					.collect(groupingBy(SyncParcel::getCode));

			List<SyncParcel> ret = new ArrayList<>();

			parcelsMap.entrySet().forEach(p -> {
				var geoms = p.getValue().stream()
						.map(SyncParcel::getGeom)
						.filter(g -> g != null)
						.collect(toList());
				if (geoms.size() > 0)
					ret.add(new SyncParcel(p.getKey(), p.getValue().get(0).getDomainZoneId(), Utils.getUnion(geoms), p.getValue().get(0).getDefaultLandUse(),
							null));
				else
					ret.add(new SyncParcel(p.getKey(), p.getValue().get(0).getDomainZoneId(), null, null, null));
			});
			return ret;
		}*/
    }

	@Override
	public String getDefaultLandUseCode(RuntimeEnvironment env, LocalDate pointInTime, String parcelCode) {
		return null;
	}

	@Override
	public List<WizardPlot> getWizardPlots(RuntimeEnvironment env, String businessId, Long cropPlanId,
			LocalDateTime currentDt, boolean beforePublish) {
		return new ArrayList<>();
	}

	@Override
	public List<SyncParcel> getLpisParcelsForPlotAlign(RuntimeEnvironment env, String domainZoneId,
			LocalDate pointInTime, Geometry geom, String srs) {
		return new ArrayList<>();
	}

	@Override
	public boolean isRecalcAnomaliesNeeded(RuntimeEnvironment env, String businessId, Long cropPlanId,
			LocalDateTime lastSyncDt, LocalDate currentReferenceDt, LatestSync latestSync, LocalDate currentCampaignStartDt) {		
		if (latestSync == null || latestSync.getReferenceDate() == null)
			return true;
		else if (currentReferenceDt == null)
			return true;
		else 
			return !latestSync.getReferenceDate().toLocalDate().equals(currentReferenceDt);
	}
	
	@Override
	public LocalDateTime getSyncPluginDate(RuntimeEnvironment env) {
		return null;
	}

	@Override
	public String getCropPlanType() {
		return "CROPPLAN";
	}

}
