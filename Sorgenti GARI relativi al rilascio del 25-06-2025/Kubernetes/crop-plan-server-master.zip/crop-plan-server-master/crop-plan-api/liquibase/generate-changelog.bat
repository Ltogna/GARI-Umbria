@echo off

liquibase generateChangeLog