package com.abacogroup.cropplan.resources.auth;

import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.AuthorizationContext;
import io.dropwizard.auth.Authorizer;
import jakarta.ws.rs.container.ContainerRequestContext;
import org.checkerframework.checker.nullness.qual.Nullable;

public class MyBasicAuthorizer implements Authorizer<User>
{

	@Override
	public boolean authorize(User user, String role, @Nullable ContainerRequestContext containerRequestContext) {
		return true;
	}

	@Override
	public AuthorizationContext<User> getAuthorizationContext(User principal, String role, @Nullable ContainerRequestContext requestContext) {
		return Authorizer.super.getAuthorizationContext(principal, role, requestContext);
	}
}
