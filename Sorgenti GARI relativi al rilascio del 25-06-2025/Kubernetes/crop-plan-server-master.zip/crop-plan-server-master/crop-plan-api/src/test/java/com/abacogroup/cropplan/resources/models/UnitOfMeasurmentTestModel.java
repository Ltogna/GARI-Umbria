package com.abacogroup.cropplan.resources.models;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class UnitOfMeasurmentTestModel
{
	@NotNull
	private String uomLabel;
	
	@NotNull
	private String uomCode;

	@NotNull
	private boolean perArea;
}
