package com.abacogroup.cropplan.resources.models;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;
import lombok.Data;

@Data
public class PermanentCropFormDataTestModel
{

	@NotNull
	private Integer areaSqm;

	@NotNull
	private Double distanceOnTheRowCm;

	@NotNull
	private Double distanceBetweenRowsCm;

	@NotNull
	private Integer stumpsNumber;

	@NotNull
	private String farmingForm;

	@NotNull
	private String irrigation;

	@NotNull
	private String productDestinationCode;

	@NotNull
	private String cultivationTypeCode;

	@NotNull
	private String varietyCode;

	@NotNull
	private String variationTypeCode;

	@NotNull
	private String vineyardTypeCode;

	@NotNull
	private String plantingType;

	@NotNull
	private String layering;

	@NotNull
	private String rock;

	@NotNull
	private String skeleton;

	@NotNull
	private String vegetativeState;

	@NotNull
	private String pruning;

	@NotNull
	private String judgement;

	@NotNull
	private Double stumpsDensity100;

	@NotNull
	private Double failuresPerc;

	@NotNull
	private Double soilLayeringPerc;

	@NotNull
	private Double altitudeAboveSeaLevel;

	@NotNull
	private String terracing;

	@NotNull
	private String headerAnchoring;

	@NotNull
	private String polesHeader;

	@NotNull
	private String polesWeaving;

	@NotNull
	private Double polesDistanceCm;

	@NotNull
	private String supportWires;

	@NotNull
	private String cultivationState;

	@NotNull
	private String origin;

	@NotNull
	private LocalDateTime graftDate;

	@NotNull
	private String graftHolder;

	@NotNull
	private String covering;

	@NotNull
	private String bio;
	
	@NotNull
	private String subscriptionCodes;
	
	@NotNull
	private String externalCode;

	@NotNull
	private String externalDescription;
	
	@NotNull
	private String qualitySystem;
	
	@NotNull
	private String protectionStructures;

	@NotNull
	private Integer plantingYear;

	@NotNull
	private Integer shiftInYears;

	@NotNull
	private AbsoluteDate expectedCuttingDate;
}
