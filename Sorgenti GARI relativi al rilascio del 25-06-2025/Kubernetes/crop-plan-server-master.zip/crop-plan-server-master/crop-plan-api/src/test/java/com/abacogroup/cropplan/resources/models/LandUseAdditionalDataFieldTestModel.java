package com.abacogroup.cropplan.resources.models;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LandUseAdditionalDataFieldTestModel {

	private String fieldCode;
	private String fieldDescription;
	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;
	private Integer sortOrder;
	private String value;
	private String valueDescription;
	private boolean flShowInTooltip;
}
