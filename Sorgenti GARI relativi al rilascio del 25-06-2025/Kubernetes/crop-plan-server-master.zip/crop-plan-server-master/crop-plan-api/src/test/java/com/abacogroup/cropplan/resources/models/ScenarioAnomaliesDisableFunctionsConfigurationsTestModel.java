package com.abacogroup.cropplan.resources.models;

import java.util.ArrayList;
import java.util.List;

import com.abacogroup.cropplan.bundle.model.AnomScenarioDisableFuncConfigDefinition;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScenarioAnomaliesDisableFunctionsConfigurationsTestModel
{
	@Builder.Default
	private List<AnomScenarioDisableFuncConfigDefinition> anomScenarioConfig = new ArrayList<>();
}
