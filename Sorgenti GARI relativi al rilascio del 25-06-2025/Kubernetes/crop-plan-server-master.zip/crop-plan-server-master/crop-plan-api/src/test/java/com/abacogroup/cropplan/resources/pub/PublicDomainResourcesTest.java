package com.abacogroup.cropplan.resources.pub;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.abacogroup.cropplan.api.DomainZone.MBR;
import com.abacogroup.cropplan.api.DomainZoneExt;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.models.DomainZoneTestModel;
import com.abacogroup.cropplan.resources.models.InfiniteListResultTestModel;
import com.abacogroup.cropplan.resources.models.SnapElementsTestModel;
import com.abacogroup.cropplan.sdk.jackson.WKTGeometryDeserializer;
import com.abacogroup.cropplan.sdk.jackson.WKTGeometrySerializer;
import com.abacogroup.cropplan.sdk.model.domain.DomainZoneGeometry;
import com.abacogroup.cropplan.sdk.model.domain.HoldingArea;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements.SnapElementType;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements.SnapGeometry;
import com.abacogroup.cropplan.sdk.spi.DomainPlugin;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.DomainService;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.plugins.impl.EnvironmentFactory;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.ws.rs.core.GenericType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;

@ExtendWith(DropwizardExtensionsSupport.class)
public class PublicDomainResourcesTest
{
	private static BaseService baseService = mock(BaseService.class);
	private static PluginManager pluginManager = mock(PluginManager.class);
	private static DomainPlugin domainPlugin = mock(DomainPlugin.class);
	private static DomainService domainService = mock(DomainService.class);
	private static ObjectMapper mapper = createMapper();

	private static final ResourceExtension EXT = ResourceExtension.builder()
        .addResource(new PublicTenantDomainResources(baseService, domainService, pluginManager))
        .setMapper(mapper)
        .build();
	
	private static WKTReader wktReader = new WKTReader();
	
	public static ObjectMapper createMapper() {
		ObjectMapper objectMapper = new ObjectMapper()
				.findAndRegisterModules()
				.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true);

		SimpleModule module = new SimpleModule("custom-deserializers", com.fasterxml.jackson.core.Version.unknownVersion());
		module.addSerializer(Geometry.class, new WKTGeometrySerializer());
		module.addDeserializer(Geometry.class, new WKTGeometryDeserializer());
		objectMapper.registerModule(module);

		return objectMapper;
	}

	@BeforeEach
	public void init()
	{
		when(baseService.getEnvironmentFactory())
			.thenReturn(mock(EnvironmentFactory.class));
		when(baseService.canRead(any(), any(), any()))
			.thenReturn(true);
		when(pluginManager.getDomainPlugin(any(), anyLong(), any()))
			.thenReturn(domainPlugin);
		when(domainPlugin.getDomainZoneByCode(any(), any(), any(), any()))
			.thenReturn(mock(DomainZoneGeometry.class));
	}

	@Test
	public void whenGetDomainZones_thenReturnDomainZonesKeepingPropertiesUnchanged()
	{
		List<DomainZoneExt> domainZones = new ArrayList<>();
		domainZones.add(new DomainZoneExt("A123", "code", "descr", "srs", new MBR(1d, 2d, 3d, 4d), new HoldingArea(10)));
		var ret = new InfiniteListResultsImpl<>(domainZones, null);
		when(domainService.getDomainZonesInfinite(any(), any(), anyLong(), any(), any(), any(), anyBoolean(), anyBoolean(), any()))
			.thenReturn(ret);

		var res = EXT.target("_/public/v1/domains/1/plans/2/zones")
			.queryParam("pointInTime", "20220101").request().get(new GenericType<InfiniteListResultTestModel<DomainZoneTestModel>>() {});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<DomainZoneTestModel>> violations = validator.validate(res.getRecords().get(0));
        assertEquals(violations.size(), 0);
	}
	
	@Test
	public void whenGetSnapGeometries_thenReturnSnapGeometriesKeepingPropertiesUnchanged() throws ParseException
	{
		List<SnapElementType> types = new ArrayList<>();
		types.add(new SnapElementType("type", "descr"));
		List<SnapGeometry> geoms = new ArrayList<>();
		var geom = (Polygon) wktReader.read("POLYGON ((430 450, 370 350, 470 340, 550 410, 520 490, 430 450))");
		Map<String,String> tooltipData = new HashMap<>();
		tooltipData.put("label1", "field1");
		tooltipData.put("label2", "field2");
		geoms.add(new SnapGeometry("id", "type", "descr", geom, tooltipData));
		var ret = new SnapElements(types, geoms);
		when(domainService.getSnapGeometries(any(), any(), anyLong(), any(), any(), any()))
			.thenReturn(ret);

		var res = EXT.target("_/public/v1/domains/1/plans/2/domains/A123/snap-geometries")
			.queryParam("pointInTime", "20220101").request().get(SnapElementsTestModel.class);

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<SnapElementsTestModel>> violations = validator.validate(res);
        assertEquals(violations.size(), 0);
	}
	
	// TODO TEST getAdditionalLayers
}
