package com.abacogroup.cropplan.resources.models;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeclarationTestModel
{
	@NotNull
	private String declCode;

	@Valid
	@NotNull
	private LandUseTestModel landuse;

	@NotNull
	private Double areaPerc;

	@Valid
	@NotNull
	private StyleTestModel style;

	@NotNull
	private String fromDate;
	
	@NotNull
	private String fromDatePrecision;

	@NotNull
	private String toDate;

	@Valid
	@NotEmpty
	private List<PermanentCropFormTestModel> permanentCropForms;

	@Valid
	@NotEmpty
	private List<ValidationAnomalyTestModel> anomalies;

	@Valid
	@NotEmpty
	private List<PesticideEntryTestModel> pesticides;
	
	@Valid
	@NotEmpty
	List<LandUseAdditionalDataFieldTestModel> fieldsCodes;
}
