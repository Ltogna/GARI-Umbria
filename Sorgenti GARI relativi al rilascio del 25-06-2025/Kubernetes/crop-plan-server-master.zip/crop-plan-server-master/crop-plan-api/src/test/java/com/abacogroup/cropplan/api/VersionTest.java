package com.abacogroup.cropplan.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.Version;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class VersionTest
{
	private ObjectMapper mapper = new ObjectMapper();

	@Test
	public void deserializesFromString() throws JsonProcessingException
	{
		LocalDateTime dt = LocalDateTime.of(2021, 11, 30, 23, 59, 00, 123);
		Version expected = new Version(dt);
		String json = mapper.writeValueAsString(expected);

		Version version = mapper.readValue(json, Version.class);
		assertEquals(expected, version);
	}

	@Test
	public void serializesToString() throws JsonMappingException, JsonProcessingException
	{
		LocalDateTime expected = LocalDateTime.of(2021, 11, 30, 23, 59, 00, 123);
		Version version = new Version(expected);
		String json = mapper.writeValueAsString(version);
		assertNotNull(json);
		assertTrue(json.length() > 0);
	}

	@Test
	public void whenBadString_thenRaiseDeserializationError()
	{
		assertThrows(JsonProcessingException.class, () -> {
			mapper.readValue("\"PIPPO\"", AbsoluteDate.class);
		});
	}	
	
}
