package com.abacogroup.cropplan.resources.models;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PermanentCropFormSubscriptionTestModel
{

	@NotNull
	private String code;
	
	@NotNull
	private String description;

	@NotEmpty
	private List<PermanentCropFormSubscriptionFieldTestModel> fields;
	

}
