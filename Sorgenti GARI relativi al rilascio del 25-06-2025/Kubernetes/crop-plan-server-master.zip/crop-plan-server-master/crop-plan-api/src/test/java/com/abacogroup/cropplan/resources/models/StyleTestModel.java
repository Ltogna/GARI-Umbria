package com.abacogroup.cropplan.resources.models;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StyleTestModel
{
	@NotEmpty
	private String fillColor;

	@NotEmpty
	private String fillStyle;
	
	@NotEmpty
	private String borderColor;
}
