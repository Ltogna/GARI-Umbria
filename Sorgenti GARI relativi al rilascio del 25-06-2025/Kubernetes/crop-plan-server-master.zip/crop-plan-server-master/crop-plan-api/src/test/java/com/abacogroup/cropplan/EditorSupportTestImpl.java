package com.abacogroup.cropplan;

import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.geom.Polygonal;

import com.abacogroup.geometryeditor.EditorSupport;

public class EditorSupportTestImpl implements EditorSupport<String>
{
	private long lastPreviewKey = 0;
	
	@Override
	public Map<String, Polygon> loadPolygonsForTopologyCorrection(Geometry touchingGeometry)
	{
		return null;
	}

	@Override
	public InvolvedPolygons<String> loadPolygonsWithInteraction(Geometry touchingGeometry,
		InvolvedPolygonsInterest interested)
	{
		return null;
	}

	@Override
	public Map<String, Polygon> createPolygonKeys(String key, Collection<Polygon> polygons)
	{
		Map<String, Polygon> map = new HashMap<String, Polygon>();
		var maxAreaPolygon = polygons.stream().max(Comparator.comparing(Polygon::getArea));
		if (!maxAreaPolygon.isEmpty())
		{
			map.put(key, maxAreaPolygon.get());
		}

		polygons.forEach(p -> {
			if (p != maxAreaPolygon.get())
				map.put(getNewPolygonKey(), p);
		});
		return map;
	}

	@Override
	public Map<String, Polygon> createPolygonKeys(Collection<Polygon> polygons)
	{
		Map<String, Polygon> map = new HashMap<String, Polygon>();
		polygons.forEach(p -> map.put(getNewPolygonKey(), p));
		return map;
	}
	
	private String getNewPolygonKey()
	{
		lastPreviewKey -= 1;
		return "*temp*" + lastPreviewKey;
	}

	@Override
	public Collection<Polygonal> loadCanvasGeometries(Geometry touchingGeometry)
	{
		return null;
	}
}
