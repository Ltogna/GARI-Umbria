package com.abacogroup.cropplan.resources.models;

public enum UomTypeTestModel
{
	VOLUME, WEIGHT
}
