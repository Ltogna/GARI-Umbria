import com.abacogroup.cropplan.CropPlanApplication;

public class Server_iacs_dev {
	public static void main(String[] args) throws Exception {
		CropPlanApplication.main(new String[] {
				"server", "crop-plan-api/config-iacs.yml"
		});
	}
}
