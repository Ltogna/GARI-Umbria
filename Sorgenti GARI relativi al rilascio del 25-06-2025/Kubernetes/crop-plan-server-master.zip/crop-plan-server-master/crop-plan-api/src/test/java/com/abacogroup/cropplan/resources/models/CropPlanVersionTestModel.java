package com.abacogroup.cropplan.resources.models;

import java.time.LocalDateTime;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CropPlanVersionTestModel
{
	@Valid
	@NotNull
	private Long cropPlanId;
	
	@Valid
	@NotEmpty
	private String version;

	@NotNull
	private LocalDateTime versionDate;
	
	@NotNull
	private AbsoluteDate versionReferenceDate;

	@NotEmpty
	private String message;
	
	@NotEmpty
	private String userId;
	
	@NotNull
	private Boolean flPublished;
}
