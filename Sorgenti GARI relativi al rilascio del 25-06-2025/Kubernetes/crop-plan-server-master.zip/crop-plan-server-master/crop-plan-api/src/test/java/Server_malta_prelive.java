import com.abacogroup.cropplan.CropPlanApplication;

public class Server_malta_prelive {
	public static void main(String[] args) throws Exception {
		CropPlanApplication.main(new String[] {
				"server", "crop-plan-api/config-malta-prelive.yml"
		});
	}
}
