package com.abacogroup.cropplan.resources.models;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CropPlanTypeTestModel
{
	@NotEmpty
	private String cropPlanTypeCode;

	@NotEmpty
	private String description;

	@NotNull
	private Boolean multiple;

	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;
}
