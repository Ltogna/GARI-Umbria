package com.abacogroup.cropplan.resources.models;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;

@Data
public class CropPlanTestModel
{
	@NotNull
	private Long cropPlanId;

	@NotEmpty
	private String cropPlanTypeCode;

	@NotEmpty
	private String cropPlanTypeDescription;

	@NotEmpty
	private String description;

	@NotNull
	private Boolean changesPending;
	
	@NotNull
	private Boolean readOnly;

	@NotNull
	private Boolean canAddPlots;
	
	@NotNull
	private Boolean locked;
	
	@NotEmpty
	private String lockedErrorCode;
	
	@NotEmpty
	private List<CropPlanPrintTestModel> cropPlanPrints;
}
