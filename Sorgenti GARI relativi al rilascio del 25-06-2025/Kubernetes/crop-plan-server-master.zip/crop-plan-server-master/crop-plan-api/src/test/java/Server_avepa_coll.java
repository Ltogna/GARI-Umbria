import com.abacogroup.cropplan.CropPlanApplication;

public class Server_avepa_coll {
	public static void main(String[] args) throws Exception {
		CropPlanApplication.main(new String[] {
				"server", "crop-plan-api/config-avepa-coll.yml"
		});
	}
}