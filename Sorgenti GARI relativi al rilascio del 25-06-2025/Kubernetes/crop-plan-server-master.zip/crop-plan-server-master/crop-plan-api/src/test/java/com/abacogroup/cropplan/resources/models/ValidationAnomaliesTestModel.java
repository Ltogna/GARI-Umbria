package com.abacogroup.cropplan.resources.models;

import com.abacogroup.cropplan.sdk.model.domain.BaseDomainZone;
import com.abacogroup.cropplan.sdk.model.validation.AnomalyObjectType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ValidationAnomaliesTestModel
{
	@NotNull
	private Integer numOfBlockingAnomalies;
	
	@NotNull
	private Integer numOfNonBlockingAnomalies;
	
	@NotEmpty
	private List<ValidationAnomalyByTypeTest> anomalies;
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static final class ValidationAnomalyByTypeTest
	{
		@NotNull
		private Integer numOfAnomalies;
		
		@NotNull
		private AnomalyObjectType objectType;

		@NotEmpty
		private String errorCode;
		
		@NotEmpty
		private String errorDescription;

		@NotNull
		private Boolean blocking;
		
		@JsonIgnore
		@Schema(description = "List of Domain zone")
		private List<BaseDomainZone> baseDomainZoneList;
		
		@JsonIgnore
		private String domainZoneId;
	}
}
