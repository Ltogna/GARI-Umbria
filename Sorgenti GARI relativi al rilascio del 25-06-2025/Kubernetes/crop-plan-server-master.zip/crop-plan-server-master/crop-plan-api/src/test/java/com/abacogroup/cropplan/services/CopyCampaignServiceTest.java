package com.abacogroup.cropplan.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.assertj.core.groups.Tuple;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Polygonal;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;
import org.mockito.ArgumentCaptor;

import com.abacogroup.cropplan.RuntimeEnvironmentImpl;
import com.abacogroup.cropplan.api.CopyCampaignLandUseCode;
import com.abacogroup.cropplan.api.CropPlan;
import com.abacogroup.cropplan.api.CropPlanDates;
import com.abacogroup.cropplan.api.CropPlanVersionWithBusinessId;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.payload.CopyCampaignPayload;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.db.dao.PlotEditDAO;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.sdk.model.Version;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.domain.Parcel;
import com.abacogroup.cropplan.sdk.spi.CropCodesPlugin;
import com.abacogroup.cropplan.sdk.spi.DomainPlugin;
import com.abacogroup.cropplan.services.support.EditorSupportParams;
import com.abacogroup.cropplan.services.utils.CopyCampaignUtils;
import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;

class CopyCampaignServiceTest {

	private CropPlansDAO cropPlansDAO = mock(CropPlansDAO.class);
	private PlotEditDAO plotEditDAO = mock(PlotEditDAO.class);
	private DeclarationsDAO declarationsDAO = mock(DeclarationsDAO.class);

	private CropPlanConfigService cropPlanConfigService = mock(CropPlanConfigService.class);
	private CropPlanService cropPlanService = mock(CropPlanService.class);
	private SyncService syncService = mock(SyncService.class);

	private PluginManager pluginManager = mock(PluginManager.class);
	private DomainPlugin domainPlugin = mock(DomainPlugin.class);
	private CropCodesPlugin cropCodesPlugin = mock(CropCodesPlugin.class);

	private CopyCampaignUtils copyCampaignUtils = mock(CopyCampaignUtils.class);

	private WKTReader reader = new WKTReader();

	private CopyCampaignService copyCampaignService = new CopyCampaignService(cropPlansDAO, declarationsDAO,
			cropPlanConfigService, cropPlanService, pluginManager, copyCampaignUtils);

	// ----- copyCampaign -----
	@Test
	void test_copyCampaign_ok() {

		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		String businessId = "555";
		long cropPlanId = 123L;
		long sourceCropPlanId = 456L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20240615");
		AbsoluteDate sourcePointInTime = AbsoluteDate.of("20230615");
		LocalDateTime currentDate = LocalDateTime.of(2025, 03, 06, 17, 32);
		LocalDateTime sourceVersion = LocalDateTime.of(2024, 12, 31, 14, 28);
		AbsoluteDate campaignStartDate = AbsoluteDate.of("20240515");
		AbsoluteDate sourceCampaignStartDate = AbsoluteDate.of("20230515");

		CopyCampaignPayload payload = CopyCampaignPayload.builder()
				.sourceCropPlanId(sourceCropPlanId)
				.sourceVersion(new Version(sourceVersion))
				.sourcePointInTime(sourcePointInTime)
				.destPointInTime(pointInTime)
				.landuseCodesExcludedFromAggregation(List.of(
						"XXX-111-111-111-111",
						"XXX-222-222-222-222",
						"XXX-333-333-333-333"
				))
				.build();

		EditorSupportParams params1 = EditorSupportParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.pointInTime(pointInTime)
				.versionDt(currentDate)
				.domainZoneId("d01")
				.build();
		EditorSupportParams params2 = EditorSupportParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.pointInTime(pointInTime)
				.versionDt(currentDate)
				.domainZoneId("d02")
				.build();

		given(cropPlansDAO.getCurrentTimestamp()).willReturn(currentDate);

		CropPlanDates cropPlanDates = new CropPlanDates();
		cropPlanDates.setCampaignStartDate(campaignStartDate);
		given(cropPlanService.getCropPlanDates(any(), any(), eq(cropPlanId), any()))
				.willReturn(cropPlanDates);

		CropPlanDates sourceCropPlanDates = new CropPlanDates();
		sourceCropPlanDates.setCampaignStartDate(sourceCampaignStartDate);
		given(cropPlanService.getCropPlanDates(any(), any(), eq(sourceCropPlanId), any()))
				.willReturn(sourceCropPlanDates);

		given(cropPlansDAO.getPlotsDomainZoneIds(any(), any(), any()))
				.willReturn(List.of("d01", "d02"));

		given(pluginManager.getDomainPlugin(any(), any(), any())).willReturn(domainPlugin);

		Parcel pt01 = new Parcel("pt01", mock(Geometry.class), "20240101", "99991231");
		Parcel pt02 = new Parcel("pt02", mock(Geometry.class), "20240101", "99991231");
		Parcel pt03 = new Parcel("pt03", mock(Geometry.class), "20240101", "99991231");
		Parcel pt04 = new Parcel("pt04", mock(Geometry.class), "20240101", "99991231");
		given(domainPlugin.getCopyCampaignParcels(any(), any(), any(), any()))
				.willReturn(List.of(pt01, pt02))
				.willReturn(List.of(pt03, pt04));

		Plot p001 = Plot.builder().plotCode("p001").build();
		Plot p002 = Plot.builder().plotCode("p002").build();
		Plot p003 = Plot.builder().plotCode("p003").build();
		Plot p004 = Plot.builder().plotCode("p004").build();
		Plot p005 = Plot.builder().plotCode("p005").build();
		Plot p006 = Plot.builder().plotCode("p006").build();
		Plot p007 = Plot.builder().plotCode("p007").build();
		Plot p008 = Plot.builder().plotCode("p008").build();
		given(cropPlanService.getPlotsByIntersectionWithDeclarationsBetweenDates(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), anyInt(),
				any()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(p001, p002), null))
				.willReturn(new InfiniteListResultsImpl<>(List.of(p003, p004), null))
				.willReturn(new InfiniteListResultsImpl<>(List.of(p005, p006), null))
				.willReturn(new InfiniteListResultsImpl<>(List.of(p007, p008), null));

		willAnswer(i -> {
			((TransactionalConsumer<CropPlansDAO, ?>) i.getArgument(0)).useTransaction(cropPlansDAO);
			return null;
		}).given(cropPlansDAO).useTransaction(any());

		given(copyCampaignUtils.aggregatePlots(any(), any(), any(), any(), any()))
				.willAnswer(i -> List.of(((List<?>) i.getArgument(4)).get(0)));

		// test
		copyCampaignService.copyCampaign(env, businessId, cropPlanId, payload);

		verify(cropPlanService).getCropPlanDates(env, businessId, payload.getSourceCropPlanId(), payload.getSourcePointInTime());
		verify(cropPlanService).getCropPlanDates(env, businessId, cropPlanId, payload.getDestPointInTime());
		verify(cropPlansDAO).getPlotsDomainZoneIds(cropPlanId, currentDate, pointInTime);
		verify(domainPlugin).getCopyCampaignParcels(env, businessId, "d01", pointInTime.toLocalDate());
		verify(domainPlugin).getCopyCampaignParcels(env, businessId, "d02", pointInTime.toLocalDate());
		verify(cropPlanService, times(2)).getPlotsByIntersectionWithDeclarationsBetweenDates(eq(env), eq(businessId), eq(sourceCropPlanId),
				eq("d01"), any(Geometry.class), eq(sourceVersion),
				eq(sourcePointInTime), eq(sourcePointInTime), eq(AbsoluteDate.of("20240514")), any(), anyInt(), any());
		verify(cropPlanService, times(2)).getPlotsByIntersectionWithDeclarationsBetweenDates(eq(env), eq(businessId), eq(sourceCropPlanId),
				eq("d02"), any(Geometry.class), eq(sourceVersion),
				eq(sourcePointInTime), eq(sourcePointInTime), eq(AbsoluteDate.of("20240514")), any(), anyInt(), any());
		verify(copyCampaignUtils).aggregatePlots(env, businessId, cropPlanId, payload, List.of(p001, p002));
		verify(copyCampaignUtils).aggregatePlots(env, businessId, cropPlanId, payload, List.of(p003, p004));
		verify(copyCampaignUtils).aggregatePlots(env, businessId, cropPlanId, payload, List.of(p005, p006));
		verify(copyCampaignUtils).aggregatePlots(env, businessId, cropPlanId, payload, List.of(p007, p008));
		verify(copyCampaignUtils).copyDeclarationsOnParcel(env, payload, pt01, List.of(p001), cropPlanDates, params1);
		verify(copyCampaignUtils).copyDeclarationsOnParcel(env, payload, pt02, List.of(p003), cropPlanDates, params1);
		verify(copyCampaignUtils).copyDeclarationsOnParcel(env, payload, pt03, List.of(p005), cropPlanDates, params2);
		verify(copyCampaignUtils).copyDeclarationsOnParcel(env, payload, pt04, List.of(p007), cropPlanDates, params2);

	}

	@Test
	void test_copyCampaign_sourcePointInTimeAfterCampaignEndOk() {

		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		String businessId = "555";
		long cropPlanId = 123L;
		long sourceCropPlanId = 456L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20240615");
		AbsoluteDate sourcePointInTime = AbsoluteDate.of("20240610");
		LocalDateTime currentDate = LocalDateTime.of(2025, 03, 06, 17, 32);
		LocalDateTime sourceVersion = LocalDateTime.of(2024, 12, 31, 14, 28);
		AbsoluteDate campaignStartDate = AbsoluteDate.of("20240515");
		AbsoluteDate sourceCampaignStartDate = AbsoluteDate.of("20230515");

		CopyCampaignPayload payload = CopyCampaignPayload.builder()
				.sourceCropPlanId(sourceCropPlanId)
				.sourceVersion(null)
				.sourcePointInTime(sourcePointInTime)
				.destPointInTime(pointInTime)
				.landuseCodesExcludedFromAggregation(List.of(
						"XXX-111-111-111-111",
						"XXX-222-222-222-222",
						"XXX-333-333-333-333"
				))
				.build();

		EditorSupportParams params1 = EditorSupportParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.pointInTime(pointInTime)
				.versionDt(currentDate)
				.domainZoneId("d01")
				.build();

		given(cropPlansDAO.getCurrentTimestamp()).willReturn(currentDate);

		CropPlanDates cropPlanDates = new CropPlanDates();
		cropPlanDates.setCampaignStartDate(campaignStartDate);
		given(cropPlanService.getCropPlanDates(any(), any(), eq(cropPlanId), any()))
				.willReturn(cropPlanDates);

		CropPlanDates sourceCropPlanDates = new CropPlanDates();
		sourceCropPlanDates.setCampaignStartDate(sourceCampaignStartDate);
		given(cropPlanService.getCropPlanDates(any(), any(), eq(sourceCropPlanId), any()))
				.willReturn(sourceCropPlanDates);

		given(cropPlansDAO.getPlotsDomainZoneIds(any(), any(), any()))
				.willReturn(List.of("d01"));

		given(pluginManager.getDomainPlugin(any(), any(), any())).willReturn(domainPlugin);

		Parcel pt01 = new Parcel("pt01", mock(Geometry.class), "20240101", "99991231");
		given(domainPlugin.getCopyCampaignParcels(any(), any(), any(), any()))
				.willReturn(List.of(pt01));

		Plot p001 = Plot.builder().plotCode("p001").build();
		given(cropPlanService.getPlotsByIntersectionWithDeclarationsBetweenDates(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), anyInt(),
				any()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(p001), null));

		willAnswer(i -> {
			((TransactionalConsumer<CropPlansDAO, ?>) i.getArgument(0)).useTransaction(cropPlansDAO);
			return null;
		}).given(cropPlansDAO).useTransaction(any());

		given(copyCampaignUtils.aggregatePlots(any(), any(), any(), any(), any()))
				.willAnswer(i -> List.of(((List<?>) i.getArgument(4)).get(0)));

		// test
		copyCampaignService.copyCampaign(env, businessId, cropPlanId, payload);

		verify(cropPlanService).getCropPlanDates(env, businessId, payload.getSourceCropPlanId(), payload.getSourcePointInTime());
		verify(cropPlanService).getCropPlanDates(env, businessId, cropPlanId, payload.getDestPointInTime());
		verify(cropPlansDAO).getPlotsDomainZoneIds(cropPlanId, currentDate, pointInTime);
		verify(domainPlugin).getCopyCampaignParcels(env, businessId, "d01", pointInTime.toLocalDate());
		verify(cropPlanService, times(1)).getPlotsByIntersectionWithDeclarationsBetweenDates(eq(env), eq(businessId), eq(sourceCropPlanId),
				eq("d01"), any(Geometry.class), eq(currentDate),
				eq(sourcePointInTime), eq(sourcePointInTime), eq(sourcePointInTime), any(), anyInt(), any());
		verify(copyCampaignUtils).aggregatePlots(env, businessId, cropPlanId, payload, List.of(p001));
		verify(copyCampaignUtils).copyDeclarationsOnParcel(env, payload, pt01, List.of(p001), cropPlanDates, params1);

	}

	@Test
	void test_copyCampaign_otherPlotsOk() throws ParseException {

		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		String businessId = "555";
		long cropPlanId = 123L;
		long sourceCropPlanId = 456L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20240515");
		AbsoluteDate sourcePointInTime = AbsoluteDate.of("20230515");
		LocalDateTime currentDate = LocalDateTime.of(2025, 03, 06, 17, 32);
		LocalDateTime sourceVersion = LocalDateTime.of(2024, 12, 31, 14, 28);
		AbsoluteDate campaignStartDate = AbsoluteDate.of("20240515");
		AbsoluteDate sourceCampaignStartDate = AbsoluteDate.of("20230515");
		String cropPlanTypeCode = "CROPPLAN";

		CopyCampaignPayload payload = CopyCampaignPayload.builder()
				.sourceCropPlanId(sourceCropPlanId)
				.sourceVersion(new Version(sourceVersion))
				.sourcePointInTime(sourcePointInTime)
				.destPointInTime(pointInTime)
				.landuseCodesExcludedFromAggregation(List.of(
						"XXX-111-111-111-111",
						"XXX-222-222-222-222",
						"XXX-333-333-333-333"
				))
				.flCopyFromOtherBusinesses(true)
				.build();

		EditorSupportParams params1 = EditorSupportParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.pointInTime(pointInTime)
				.versionDt(currentDate)
				.domainZoneId("d01")
				.build();
		EditorSupportParams params2 = EditorSupportParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.pointInTime(pointInTime)
				.versionDt(currentDate)
				.domainZoneId("d02")
				.build();

		given(cropPlansDAO.getCurrentTimestamp()).willReturn(currentDate);

		given(cropPlansDAO.getCropPlanInternal(any(), any(), any()))
				.willReturn(new CropPlan() {{
					setCropPlanTypeCode(cropPlanTypeCode);
				}});

		given(cropPlanConfigService.getCampaignRefDateParam(eq(cropPlanId)))
				.willReturn("0515");

		CropPlanDates cropPlanDates = new CropPlanDates();
		cropPlanDates.setCampaignStartDate(campaignStartDate);
		given(cropPlanService.getCropPlanDates(any(), any(), eq(cropPlanId), any()))
				.willReturn(cropPlanDates);

		CropPlanDates sourceCropPlanDates = new CropPlanDates();
		sourceCropPlanDates.setCampaignStartDate(sourceCampaignStartDate);
		sourceCropPlanDates.setReferenceDate(sourceCampaignStartDate);
		given(cropPlanService.getCropPlanDates(any(), any(), eq(sourceCropPlanId), any()))
				.willReturn(sourceCropPlanDates);

		given(cropPlansDAO.getPlotsDomainZoneIds(any(), any(), any()))
				.willReturn(List.of("d01"));

		given(pluginManager.getDomainPlugin(any(), any(), any())).willReturn(domainPlugin);

		Parcel pt01 = new Parcel("pt01", reader.read("POLYGON ((150 400, 150 100, 400 100, 400 400, 150 400))"), "20240101", "99991231");
		given(domainPlugin.getCopyCampaignParcels(any(), any(), any(), any()))
				.willReturn(List.of(pt01));

		Plot p001 = Plot.builder().geom(reader.read("POLYGON ((100 100, 100 200, 200 200, 200 100, 100 100))")).plotCode("p001").build();
		Plot p002 = Plot.builder().geom(reader.read("POLYGON ((200 100, 200 200, 300 200, 300 100, 200 100))")).plotCode("p002").build();
		Plot p003 = Plot.builder().geom(reader.read("POLYGON ((300 100, 400 100, 400 220, 300 220, 300 100))")).plotCode("p003").build();
		Plot p004 = Plot.builder().geom(reader.read("POLYGON ((100 200, 100 300, 200 300, 200 200, 100 200))")).plotCode("p004").build();
		Plot p105 = Plot.builder().geom(reader.read("POLYGON ((200 400, 200 300, 300 200, 400 200, 200 400))")).plotCode("p105").build();
		Plot p106 = Plot.builder().geom(reader.read("POLYGON ((400 200, 300 300, 400 400, 400 200))         ")).plotCode("p106").build();
		Plot p207 = Plot.builder().geom(reader.read("POLYGON ((200 200, 300 200, 400 400, 300 400, 200 200))")).plotCode("p207").build();
		Plot p208 = Plot.builder().geom(reader.read("POLYGON ((200 200, 300 400, 200 400, 200 200))         ")).plotCode("p208").build();
		Plot p309 = Plot.builder().geom(reader.read("POLYGON ((100 300, 250 300, 200 400, 100 400, 100 300))")).plotCode("p309").build();
		Plot p310 = Plot.builder().geom(reader.read("POLYGON ((200 200, 300 200, 300 300, 200 300, 200 200))")).plotCode("p310").build();
		given(cropPlanService.getPlotsByIntersectionWithDeclarationsBetweenDates(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), anyInt(),
				any()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(p001, p002, p003, p004), null))
				.willReturn(new InfiniteListResultsImpl<>(List.of(p105, p106), null))
				.willReturn(new InfiniteListResultsImpl<>(List.of(p207, p208), null))
				.willReturn(new InfiniteListResultsImpl<>(List.of(p309, p310), null));

		LocalDateTime v1 = LocalDateTime.now().minusSeconds(4);
		LocalDateTime v2 = LocalDateTime.now().minusSeconds(3);
		LocalDateTime v3 = LocalDateTime.now().minusSeconds(2);
		LocalDateTime v4 = LocalDateTime.now().minusSeconds(1);
		LocalDateTime v5 = LocalDateTime.now();
		given(cropPlansDAO.findOtherBusinessesCropPlanIds(any(), any(), any(), any(), any(), any())).willReturn(List.of(147L, 258L, 369L));
		given(cropPlansDAO.findLatestVersionsByPlanIds(any(), any(), any(), any(), any()))
				.willReturn(List.of(
						new CropPlanVersionWithBusinessId(147L, new Version(v3), v3, sourceCampaignStartDate,
								"", cropPlanTypeCode, env.getUserId(), true, "666"),
						new CropPlanVersionWithBusinessId(258L, new Version(v2), v2, sourceCampaignStartDate,
								"", cropPlanTypeCode, env.getUserId(), true, "777"),
						new CropPlanVersionWithBusinessId(369L, new Version(v1), v1, sourceCampaignStartDate,
								"", cropPlanTypeCode, env.getUserId(), true, "888"),
						new CropPlanVersionWithBusinessId(369L, new Version(v4), v4, AbsoluteDate.of("20230601"),
								"", cropPlanTypeCode, env.getUserId(), true, "888"),
						new CropPlanVersionWithBusinessId(258L, new Version(v5), v5, AbsoluteDate.of("20230601"),
								"", cropPlanTypeCode, env.getUserId(), true, "777")
				));

		willAnswer(i -> {
			((TransactionalConsumer<CropPlansDAO, ?>) i.getArgument(0)).useTransaction(cropPlansDAO);
			return null;
		}).given(cropPlansDAO).useTransaction(any());

		given(copyCampaignUtils.aggregatePlots(any(), any(), any(), any(), any()))
				.willAnswer(i -> new ArrayList<>((List<?>) i.getArgument(4)));

		// test
		copyCampaignService.copyCampaign(env, businessId, cropPlanId, payload);

		verify(cropPlanConfigService).getCampaignRefDateParam(cropPlanId);
		verify(cropPlanService).getCropPlanDates(env, businessId, payload.getSourceCropPlanId(), payload.getSourcePointInTime());
		verify(cropPlanService).getCropPlanDates(env, businessId, cropPlanId, payload.getDestPointInTime());
		verify(cropPlansDAO).getPlotsDomainZoneIds(cropPlanId, currentDate, pointInTime);
		verify(domainPlugin).getCopyCampaignParcels(env, businessId, "d01", pointInTime.toLocalDate());
		verify(cropPlansDAO).findOtherBusinessesCropPlanIds(eq(cropPlanTypeCode), eq(env.getTenantId()), eq(businessId), eq("d01"), any(Geometry.class), eq(sourcePointInTime));
		verify(cropPlansDAO).findLatestVersionsByPlanIds(eq(List.of(147L, 258L, 369L)), eq(businessId), eq(sourcePointInTime), eq(cropPlanTypeCode), eq(env.getTenantId()));
		AbsoluteDate sourcePointInTimeTo = AbsoluteDate.of("20240514");
		ArgumentCaptor<Geometry> geometryCaptor = ArgumentCaptor.forClass(Geometry.class);
		verify(cropPlanService).getPlotsByIntersectionWithDeclarationsBetweenDates(eq(env), eq(businessId), eq(sourceCropPlanId),
				eq("d01"), geometryCaptor.capture(), eq(sourceVersion),
				eq(sourcePointInTime), eq(sourcePointInTime), eq(sourcePointInTimeTo), any(), anyInt(), any());
		verify(cropPlanService).getPlotsByIntersectionWithDeclarationsBetweenDates(eq(env), eq("666"), eq(147L),
				eq("d01"), geometryCaptor.capture(), eq(v3),
				eq(sourcePointInTime), eq(sourcePointInTime), eq(sourcePointInTimeTo), any(), anyInt(), any());
		verify(cropPlanService).getPlotsByIntersectionWithDeclarationsBetweenDates(eq(env), eq("777"), eq(258L),
				eq("d01"), geometryCaptor.capture(), eq(v2),
				eq(sourcePointInTime), eq(sourcePointInTime), eq(sourcePointInTimeTo), any(), anyInt(), any());
		verify(cropPlanService).getPlotsByIntersectionWithDeclarationsBetweenDates(eq(env), eq("888"), eq(369L),
				eq("d01"), geometryCaptor.capture(), eq(v1),
				eq(sourcePointInTime), eq(sourcePointInTime), eq(sourcePointInTimeTo), any(), anyInt(), any());
		verify(cropPlanService, never()).getPlotsByIntersectionWithDeclarationsBetweenDates(any(), any(), any(),
				any(), any(), eq(v4),
				any(), any(), any(), any(), anyInt(), any());
		verify(cropPlanService, never()).getPlotsByIntersectionWithDeclarationsBetweenDates(any(), any(), any(),
				any(), any(), eq(v5),
				any(), any(), any(), any(), anyInt(), any());
		ArgumentCaptor<List<Plot>> plotListCaptor = ArgumentCaptor.forClass(List.class);
		verify(copyCampaignUtils).aggregatePlots(eq(env), eq(businessId), eq(cropPlanId), eq(payload), plotListCaptor.capture());
		verify(copyCampaignUtils).copyDeclarationsOnParcel(eq(env), eq(payload), eq(pt01), any(), eq(cropPlanDates), eq(params1));

		assertThat(geometryCaptor.getAllValues()).hasSize(4)
				.satisfies(all -> {
					assertTrue(geomEquals(all.get(0), "POLYGON ((150 400, 150 100, 400 100, 400 400, 150 400))                                                                                       "));
					assertTrue(geomEquals(all.get(1), "POLYGON ((150 300, 150 400, 400 400, 400 220, 300 220, 300 200, 200 200, 200 300, 150 300))                                                   "));
					assertTrue(geomEquals(all.get(2), "MULTIPOLYGON (((200 300, 300 200, 200 200, 200 300)), ((200 400, 200 300, 150 300, 150 400, 200 400)), ((400 400, 300 300, 200 400, 400 400)))"));
					assertTrue(geomEquals(all.get(3), "POLYGON ((150 300, 150 400, 200 400, 200 300, 150 300))                                                                                       "));
				});

		assertThat(plotListCaptor.getValue()).hasSize(11)
				.satisfies(all -> {
					assertTrue(geomEquals(all.get( 0).getGeom(), "POLYGON ((100 100, 100 200, 200 200, 200 100, 100 100))         "));
					assertTrue(geomEquals(all.get( 1).getGeom(), "POLYGON ((200 100, 200 200, 300 200, 300 100, 200 100))         "));
					assertTrue(geomEquals(all.get( 2).getGeom(), "POLYGON ((300 100, 400 100, 400 220, 300 220, 300 100))         "));
					assertTrue(geomEquals(all.get( 3).getGeom(), "POLYGON ((100 200, 100 300, 200 300, 200 200, 100 200))         "));
					assertTrue(geomEquals(all.get( 4).getGeom(), "POLYGON ((200 400, 380 220, 300 220, 300 200, 200 300, 200 400))"));
					assertTrue(geomEquals(all.get( 5).getGeom(), "POLYGON ((380 220, 300 300, 400 400, 400 220, 380 220))         "));
					assertTrue(geomEquals(all.get( 6).getGeom(), "POLYGON ((300 200, 200 200, 233.33 266.67, 300 200))            "));
					assertTrue(geomEquals(all.get( 7).getGeom(), "POLYGON ((400 400, 300 300, 266.67 333.33, 300 400, 400 400))   "));
					assertTrue(geomEquals(all.get( 8).getGeom(), "POLYGON ((200 300, 233.33 266.67, 200 200, 200 300))            "));
					assertTrue(geomEquals(all.get( 9).getGeom(), "POLYGON ((200 400, 300 400, 266.67 333.33, 200 400))            "));
					assertTrue(geomEquals(all.get(10).getGeom(), "POLYGON ((200 300, 100 300, 100 400, 200 400, 200 300))         "));
				});

	}

	// ----- getSourceLandUseCodesForCopyCampaign -----
	@Test
	void test_getSourceLandUseCodesForCopyCampaign_ok() {

		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		String businessId = "555";
		long cropPlanId = 123L;
		long sourceCropPlanId = 456L;
		AbsoluteDate sourcePointInTime = AbsoluteDate.of("20240610");
		LocalDateTime sourceVersion = LocalDateTime.of(2024, 12, 31, 14, 28);
		AbsoluteDate sourceCampaignStartDate = AbsoluteDate.of("20230515");

		CropPlanDates sourceCropPlanDates = new CropPlanDates();
		sourceCropPlanDates.setCampaignStartDate(sourceCampaignStartDate);
		given(cropPlanService.getCropPlanDates(any(), any(), eq(sourceCropPlanId), any()))
				.willReturn(sourceCropPlanDates);

		List<String> lucs = List.of(
				"AAA-000-000-000-000",
				"BBB-000-000-000-000",
				"CCC-000-000-000-000",
				"XXX-111-111-111-111",
				"XXX-222-222-222-222",
				"XXX-333-333-333-333",
				"YYY-000-000-000-000",
				"ZZZ-000-000-000-000"
		);
		given(declarationsDAO.getDeclarationLandUsesCodes(any(), any(), any(), any())).willReturn(lucs);

		given(pluginManager.getCropCodesPlugin(any(), any(), any())).willReturn(cropCodesPlugin);
		given(cropCodesPlugin.getLandUses(any(), any()))
				.willAnswer(i -> ((List<String>) i.getArgument(1)).stream()
						.map(luc -> new LandUse(luc, "it " + luc))
						.collect(Collectors.toList()));
		Set<String> excluded = Set.of(
				"XXX-111-111-111-111",
				"XXX-222-222-222-222",
				"XXX-333-333-333-333"
		);
		given(cropCodesPlugin.getDefaultLandUseCodesExcludedFromAggregation(any())).willReturn(excluded);

		// test
		List<CopyCampaignLandUseCode> res = copyCampaignService.getSourceLandUseCodesForCopyCampaign(env, businessId, cropPlanId,
				sourceCropPlanId, new Version(sourceVersion), sourcePointInTime, null);

		assertThat(res).hasSameSizeAs(lucs)
				.extracting(ccluc -> ccluc.getLanduse().getCode(), ccluc -> ccluc.getExcludedFromAggregation())
				.containsExactly(
						Tuple.tuple("AAA-000-000-000-000", false),
						Tuple.tuple("BBB-000-000-000-000", false),
						Tuple.tuple("CCC-000-000-000-000", false),
						Tuple.tuple("XXX-111-111-111-111", true),
						Tuple.tuple("XXX-222-222-222-222", true),
						Tuple.tuple("XXX-333-333-333-333", true),
						Tuple.tuple("YYY-000-000-000-000", false),
						Tuple.tuple("ZZZ-000-000-000-000", false)
				);

	}

	// ##################################################

	private boolean geomEquals(Geometry g, String polygon) {
		try {
			return geomEquals(g, reader.read(polygon));
		} catch (ParseException e) {
			throw new RuntimeException(e);
		}
	}

	private boolean geomEquals(Geometry g, Geometry g2) {
		return Utils.equalsSnapped((Polygonal) g, (Polygonal) g2);
	}
}
