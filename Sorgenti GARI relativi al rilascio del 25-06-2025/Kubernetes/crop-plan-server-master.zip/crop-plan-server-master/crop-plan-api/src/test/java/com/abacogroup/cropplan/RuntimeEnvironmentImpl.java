package com.abacogroup.cropplan;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import java.util.Locale;
import javax.sql.DataSource;
import org.jdbi.v3.core.Jdbi;

public class RuntimeEnvironmentImpl implements RuntimeEnvironment
{

	@Override
	public Jdbi getJdbi(String name)
	{
		return null;
	}

	@Override
	public DataSource getDatasource(String name)
	{
		return null;
	}

	@Override
	public Object getProperty(String name)
	{
		return null;
	}

	@Override
	public String getTenantId()
	{
		return "_";
	}

	@Override
	public String getUserId()
	{
		return "TEST_USER";
	}
	
	@Override
	public String getUserName()
	{
		return "TEST_USER";
	}
	
	@Override
	public User getUser() {
		return new User("TEST_USER");
	}

	@Override
	public Locale getLocale()
	{
		return Locale.ENGLISH;
	}

	@Override
	public Client getJerseyClient()
	{
		return null;
	}
	
	@Override
	public Sso2Client getSso2Client() {
		return null;
	}
	
	@Override
	public WebTarget getAuthenticatedWebTarget(String url)
	{
		return null;
	}

}
