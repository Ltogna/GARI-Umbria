package com.abacogroup.cropplan.bundle;

import static com.abacogroup.cropplan.sdk.model.LandUseAdditionalFieldType.COMBO;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.ntt.LandUseAdditionalDataConfNTT;
import com.abacogroup.cropplan.db.ntt.LandUseAdditionalDataFieldNTT;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import jakarta.validation.ConstraintViolationException;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class AdditionalDeclarationFieldsConfigProcessorTest {

	private static final String TENANT_ID = "tenant";
	private static final String USER_ID = "importDataBundle";
	protected Function<String, Path> file2Path = filename -> Optional.of(Path.of(
			"src/test/resources",
			this.getClass().getName().replaceAll("\\.", "/"),
			filename)).orElseThrow();

	private CropPlanConfigDAO configDAO = mock();

	private AdditionalDeclarationFieldsConfigProcessor processor = new AdditionalDeclarationFieldsConfigProcessor(configDAO);

	// ----- onMessage -----
	@Test
	void test_onMessage_ok() {

		given(configDAO.getLanduseAdditFieldsSeq()).willReturn(1001L, 1002L, 1003L, 1004L, 1005L);
		given(configDAO.getLanduseAdtFldsValSeq()).willReturn(8888L).willReturn(9001L, 9002L, 9003L, 9004L, 9005L);

		given(configDAO.getDeclAdditFieldsConf(eq("FIELD_V"), any(), any())).willReturn(LandUseAdditionalDataConfNTT.builder().id(9999L).build());
		given(configDAO.getDeclAdditFieldsConf(eq("FIELD_W"), any(), any())).willReturn(null);
		given(configDAO.getDeclAdditFieldsConf(eq("FIELD_1"), any(), any())).willReturn(LandUseAdditionalDataConfNTT.builder().id(1001L).build());
		given(configDAO.getDeclAdditFieldsConf(eq("FIELD_2"), any(), any())).willReturn(LandUseAdditionalDataConfNTT.builder().id(1002L).build());
		given(configDAO.getDeclAdditFieldsConf(eq("FIELD_3"), any(), any())).willReturn(LandUseAdditionalDataConfNTT.builder().id(1003L).build());

		given(configDAO.getRecordListToBeReinserted(any(), eq("FIELD_Y"), any(), any()))
				.willReturn(List.of(LandUseAdditionalDataFieldNTT.builder().id(7777L)
						.fieldCode("FIELD_Y").landUseCode("___-___-___-___-___").allowedValue("VVV_Y").displayOrder(0).flDefault(0)
						.validFrom(AbsoluteDate.of("19700101")).validTo(AbsoluteDate.of("99991231")).build()));

		// test
		processor.onMessage(new ConfigDataMessage(TENANT_ID, List.of(
				file2Path.apply("additionalDeclarationFieldsCodes/fieldsConf.jsonl"),
				file2Path.apply("additionalDeclarationFieldsCodes/fieldsAllowedValues.jsonl"),
				file2Path.apply("additionalDeclarationFieldsCodes/fieldsLandUseConf.jsonl"),
				file2Path.apply("additionalDeclarationFieldsCodes/fieldsConf.delete.jsonl"),
				file2Path.apply("additionalDeclarationFieldsCodes/fieldsAllowedValues.delete.jsonl"),
				file2Path.apply("additionalDeclarationFieldsCodes/fieldsLandUseConf.delete.jsonl")
		)));

		// fieldsConf.jsonl
		verify(configDAO).outdateDeclAdditFieldsConf("FIELD_1", USER_ID, TENANT_ID);
		verify(configDAO).outdateDeclAdditFieldsConf("FIELD_2", USER_ID, TENANT_ID);
		verify(configDAO).outdateDeclAdditFieldsConf("FIELD_3", USER_ID, TENANT_ID);
		verify(configDAO, times(3)).getLanduseAdditFieldsSeq();

		ArgumentCaptor<LandUseAdditionalDataConfNTT> nttCaptor = ArgumentCaptor.forClass(LandUseAdditionalDataConfNTT.class);
		verify(configDAO, times(3)).insertDeclAdditFieldConf(nttCaptor.capture(), eq(USER_ID), eq(TENANT_ID));
		verify(configDAO).insertDeclAdditFieldLucConf(1003L, "000-000-000-000-111", 0, USER_ID);
		verify(configDAO).insertDeclAdditFieldLucConf(1003L, "000-000-000-000-222", 1, USER_ID);

		assertThat(nttCaptor.getAllValues())
				.containsExactlyInAnyOrder(
						LandUseAdditionalDataConfNTT.builder()
								.id(1001L)
								.fieldCode("FIELD_1")
								.fieldType(COMBO)
								.validFrom(AbsoluteDate.of("19700101"))
								.validTo(AbsoluteDate.of("99991231"))
								.displayOrder(100)
								.nullable(1)
								.flShowInTooltip(0)
								.groupCode(null)
								.headerTitleCode("HTC_1")
								.flEditable(1)
								.formula(null)
								.build(),
						LandUseAdditionalDataConfNTT.builder()
								.id(1002L)
								.fieldCode("FIELD_2")
								.fieldType(COMBO)
								.validFrom(AbsoluteDate.of("19700101"))
								.validTo(AbsoluteDate.of("99991231"))
								.displayOrder(200)
								.nullable(0)
								.flShowInTooltip(1)
								.groupCode("group")
								.headerTitleCode(null)
								.flEditable(0)
								.formula("1")
								.build(),
						LandUseAdditionalDataConfNTT.builder()
								.id(1003L)
								.fieldCode("FIELD_3")
								.fieldType(COMBO)
								.validFrom(AbsoluteDate.of("19700101"))
								.validTo(AbsoluteDate.of("99991231"))
								.displayOrder(300)
								.nullable(1)
								.flShowInTooltip(0)
								.groupCode(null)
								.headerTitleCode(null)
								.flEditable(1)
								.formula(null)
								.build()
				);

		// fieldsLandUseConf.jsonl
		verify(configDAO).expireDeclAdditFieldLucConf(1002L, "000-000-000-000-111", USER_ID);
		verify(configDAO).expireDeclAdditFieldLucConf(1002L, "000-000-000-000-222", USER_ID);
		verify(configDAO).expireDeclAdditFieldLucConf(1002L, "000-000-000-000-333", USER_ID);
		verify(configDAO).expireDeclAdditFieldLucConf(1003L, "000-000-000-000-333", USER_ID);

		verify(configDAO).insertDeclAdditFieldLucConf(1002L, "000-000-000-000-111", 1, USER_ID);
		verify(configDAO).insertDeclAdditFieldLucConf(1002L, "000-000-000-000-222", 0, USER_ID);
		verify(configDAO).insertDeclAdditFieldLucConf(1002L, "000-000-000-000-333", 1, USER_ID);
		verify(configDAO).insertDeclAdditFieldLucConf(1003L, "000-000-000-000-333", 0, USER_ID);

		// fieldsAllowedValues.jsonl
		verify(configDAO).outdateDeclAdditFieldsAllowedValInRange("___-___-___-___-___", "FIELD_1",
				"VVV_1", AbsoluteDate.of("19700101"), AbsoluteDate.of("99991231"), USER_ID, TENANT_ID);
		verify(configDAO).outdateDeclAdditFieldsAllowedValInRange("___-___-___-___-___", "FIELD_1",
				"VVV_2", AbsoluteDate.of("19700101"), AbsoluteDate.of("99991231"), USER_ID, TENANT_ID);
		verify(configDAO, never()).outdateDeclAdditFieldsAllowedValInRange(eq("___-___-___-___-___"), eq("FIELD_2"),
				any(), any(), any(), any(), any());

		ArgumentCaptor<LandUseAdditionalDataFieldNTT> allowedValueNttCaptor = ArgumentCaptor.forClass(LandUseAdditionalDataFieldNTT.class);
		verify(configDAO, times(3+1)).insertDeclAdditFieldAlloewdVal(allowedValueNttCaptor.capture(), eq(USER_ID), eq(TENANT_ID));
		// 3 from upsert, 1 from delete

		assertThat(allowedValueNttCaptor.getAllValues())
				.containsExactlyInAnyOrder(
						LandUseAdditionalDataFieldNTT.builder()
								.id(9001L)
								.fieldCode("FIELD_1")
								.landUseCode("___-___-___-___-___")
								.allowedValue("VVV_1")
								.displayOrder(100)
								.flDefault(1)
								.validFrom(AbsoluteDate.of("19700101"))
								.validTo(AbsoluteDate.of("99991231"))
								.build(),
						LandUseAdditionalDataFieldNTT.builder()
								.id(9002L)
								.fieldCode("FIELD_1")
								.landUseCode("___-___-___-___-___")
								.allowedValue("VVV_2")
								.displayOrder(200)
								.flDefault(0)
								.validFrom(AbsoluteDate.of("19700101"))
								.validTo(AbsoluteDate.of("99991231"))
								.build(),
						LandUseAdditionalDataFieldNTT.builder()
								.id(9003L)
								.fieldCode("FIELD_2")
								.landUseCode("___-___-___-___-___")
								.allowedValue("VVV_X")
								.displayOrder(999)
								.flDefault(0)
								.validFrom(AbsoluteDate.of("19700101"))
								.validTo(AbsoluteDate.of("99991231"))
								.build(),
						LandUseAdditionalDataFieldNTT.builder() // from delete
								.id(8888L)
								.fieldCode("FIELD_Y")
								.landUseCode("___-___-___-___-___")
								.allowedValue("VVV_Y")
								.displayOrder(0)
								.flDefault(0)
								.validFrom(AbsoluteDate.of("19700101"))
								.validTo(AbsoluteDate.of("20241231"))
								.build()
				);

		// all i18n
		verify(configDAO).deleteI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_CODE", "FIELD_1", "it", TENANT_ID);
		verify(configDAO).deleteI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_CODE", "FIELD_2", "it", TENANT_ID);
		verify(configDAO).deleteI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_CODE", "FIELD_3", "it", TENANT_ID);
		verify(configDAO).deleteI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_CODE", "FIELD_1", "en", TENANT_ID);
		verify(configDAO).deleteI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_CODE", "FIELD_2", "en", TENANT_ID);
		verify(configDAO).deleteI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_CODE", "FIELD_3", "en", TENANT_ID);
		verify(configDAO).deleteI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "HEADER_TITLE_CODE", "HTC_1", "it", TENANT_ID);
		verify(configDAO).deleteI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_VALUE", "VVV_1", "it", TENANT_ID);
		verify(configDAO).deleteI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_VALUE", "VVV_2", "it", TENANT_ID);
		verify(configDAO).deleteI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_VALUE", "VVV_X", "it", TENANT_ID);

		verify(configDAO).insertI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_CODE", "FIELD_1", "it", "Campo uno", TENANT_ID);
		verify(configDAO).insertI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_CODE", "FIELD_2", "it", "Campo due", TENANT_ID);
		verify(configDAO).insertI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_CODE", "FIELD_3", "it", "Campo tre", TENANT_ID);
		verify(configDAO).insertI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_CODE", "FIELD_1", "en", "Field one", TENANT_ID);
		verify(configDAO).insertI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_CODE", "FIELD_2", "en", "Field two", TENANT_ID);
		verify(configDAO).insertI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_CODE", "FIELD_3", "en", "Field 333", TENANT_ID);
		verify(configDAO).insertI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "HEADER_TITLE_CODE", "HTC_1", "it", "HTC uno", TENANT_ID);
		verify(configDAO).insertI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_VALUE", "VVV_1", "it", "Valore Uno", TENANT_ID);
		verify(configDAO).insertI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_VALUE", "VVV_2", "it", "Valore Due", TENANT_ID);
		verify(configDAO).insertI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_VALUE", "VVV_X", "it", "Valore Nuovo", TENANT_ID);
		verify(configDAO).insertI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_VALUE", "VVV_1", "en", "Value one", TENANT_ID);
		verify(configDAO).insertI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_VALUE", "VVV_2", "en", "Value Two", TENANT_ID);
		verify(configDAO).insertI18nValue("CRPL_LANDUSE_ADDIT_FIELDS", "FIELD_VALUE", "VVV_X", "en", "Value New", TENANT_ID);

		// fieldsConf.delete.jsonl
		verify(configDAO).outdateDeclAdditFieldsConf("FIELD_Z", USER_ID, TENANT_ID);
		verify(configDAO).outdateDeclAdditFieldsAllowedValForFieldCode("FIELD_Z", USER_ID, TENANT_ID);

		// fieldsLandUseConf.delete.jsonl
		verify(configDAO).expireDeclAdditFieldLucConf(9999L, "000-000-000-000-V11", USER_ID);
		verify(configDAO).expireDeclAdditFieldLucConf(9999L, "000-000-000-000-V22", USER_ID);
		verify(configDAO, never()).expireDeclAdditFieldLucConf(any(), eq("000-000-000-000-WWW"), any());

		// fieldsAllowedValues.delete.jsonl
		verify(configDAO).outdateDeclAdditFieldsAllowedVal("___-___-___-___-___", "FIELD_X", USER_ID, TENANT_ID);

		verify(configDAO).getRecordListToBeReinserted("___-___-___-___-___", "FIELD_Y", TENANT_ID, AbsoluteDate.of("20250101"));
		verify(configDAO).outdateDeclAdditFieldsAllowedValForDeleteFrom("___-___-___-___-___", "FIELD_Y", USER_ID, TENANT_ID, AbsoluteDate.of("20250101"));
		// varified insert above
	}

	@Test
	void test_onMessage_fieldsConfValidationError() {

		BundleException bundleException = assertThrows(BundleException.class, () -> processor.onMessage(new ConfigDataMessage(TENANT_ID, List.of(
				file2Path.apply("additionalDeclarationFieldsCodes_validationErrors1/fieldsConf.jsonl")
		))));

		assertThat(bundleException).hasCauseInstanceOf(ConstraintViolationException.class)
				.satisfies(ex -> System.out.println(ex.getCause().getMessage()));
	}

	@Test
	void test_onMessage_fieldsLandUseConfValidationError() {

		BundleException bundleException = assertThrows(BundleException.class, () -> processor.onMessage(new ConfigDataMessage(TENANT_ID, List.of(
				file2Path.apply("additionalDeclarationFieldsCodes_validationErrors1/fieldsLandUseConf.jsonl")
		))));

		assertThat(bundleException).hasCauseInstanceOf(ConstraintViolationException.class)
				.satisfies(ex -> System.out.println(ex.getCause().getMessage()));
	}

	@Test
	void test_onMessage_fieldsAllowedValuesValidationError() {

		BundleException bundleException = assertThrows(BundleException.class, () -> processor.onMessage(new ConfigDataMessage(TENANT_ID, List.of(
				file2Path.apply("additionalDeclarationFieldsCodes_validationErrors1/fieldsAllowedValues.jsonl")
		))));

		assertThat(bundleException).hasCauseInstanceOf(ConstraintViolationException.class)
				.satisfies(ex -> System.out.println(ex.getCause().getMessage()));
	}

	@Test
	void test_onMessage_duplicateLucError() {

		BundleException bundleException = assertThrows(BundleException.class, () -> processor.onMessage(new ConfigDataMessage(TENANT_ID, List.of(
				file2Path.apply("additionalDeclarationFieldsCodes_wrong2/fieldsConf.jsonl")
		))));

		assertThat(bundleException).hasNoCause()
				.satisfies(ex -> System.out.println(ex.getMessage()));
	}
}
