package com.abacogroup.cropplan.services.utils;

import static org.junit.jupiter.api.Assertions.assertTrue;

import com.abacogroup.cropplan.sdk.support.InfiniteListResultsSupport;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import java.util.Iterator;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

@Disabled
class InfiniteListResultsSupportTest {

	private InfiniteListResultsSupport<String> infiniteListResultsSupport = new InfiniteListResultsSupport<>(n -> {
		System.out.println("call with next key " + n);
		String nextKey = null == n ? "11"
				: Long.parseLong(n) > 50000 ? null : (Long.parseLong(n) + 10L) + "";

		return new InfiniteListResultsImpl<>(IntStream.range(0, 5).mapToObj(i -> n + "_" + i).collect(Collectors.toList()), nextKey);
	});

	// ----- stream -----
	@Test
	void test_stream_ok() {

		infiniteListResultsSupport.stream().forEach(s -> System.out.println("got "+s));
		assertTrue(true);
	}

	// ----- iterator -----
	@Test
	void test_iterator_ok() {

		Iterator<String> it = infiniteListResultsSupport.iterator();

		while (it.hasNext()) {
			System.out.println(it.next());
		}

		assertTrue(true);
	}
}
