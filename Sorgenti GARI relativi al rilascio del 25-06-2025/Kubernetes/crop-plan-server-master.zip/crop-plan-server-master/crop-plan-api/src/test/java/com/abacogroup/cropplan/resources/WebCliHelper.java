package com.abacogroup.cropplan.resources;

import com.abacogroup.cropplan.sdk.jackson.WKTGeometryDeserializer;
import com.abacogroup.cropplan.sdk.jackson.WKTGeometrySerializer;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.JwtAuthenticationFilter;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import io.dropwizard.auth.AuthDynamicFeature;
import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.auth.Authorizer;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.TimeZone;
import lombok.extern.slf4j.Slf4j;
import org.glassfish.jersey.server.filter.RolesAllowedDynamicFeature;
import org.locationtech.jts.geom.Geometry;

@Slf4j
public abstract class WebCliHelper {

	public static final String BASIC_USERNAME = "test-user@example";
	public static final String TENANT = "master";
	public static final String FAKE_JWT = createFakeToken(TENANT, BASIC_USERNAME);
	public static final String JWT_MOCK_CREDENTIALS = "JWT " + FAKE_JWT;

	public static final User FAKE_USER = new User(BASIC_USERNAME, FAKE_JWT, TENANT, BASIC_USERNAME);

	public static ResourceExtension createEXT(Object resource) {
		return createEXT(resource, (principal, role, requestContext) -> true);
	}

	public static ResourceExtension createEXT(Object resource, Authorizer<User> userAuthorizer) {

		return ResourceExtension.builder()
				.setMapper(getObjectMapper())
				.addProvider(new AuthDynamicFeature(new JwtAuthenticationFilter.Builder()
						.setAuthenticator(credentials -> Optional.of(new User(
								JWT.decode(credentials).getClaim("name").asString(),
								JWT.decode(credentials).getClaim("tenant").asString())))
						.setAuthorizer(userAuthorizer)
						.buildAuthFilter()))
				.addProvider(RolesAllowedDynamicFeature.class)
				.addProvider(new AuthValueFactoryProvider.Binder<>(User.class))
				.addProvider(new MultitenantFilter("tenant"))
				.addResource(resource)
				.build();
	}

	public static WebTarget addQueryParamsFromMap(Map<String, Object> params, WebTarget wt) {
		if (null == params) {
			return wt;
		}
		for (Map.Entry<String, Object> entry : params.entrySet()) {
			String key = entry.getKey();
			Object v = entry.getValue();
			if (v instanceof Collection) {
				for (Object x : (Collection) v) {
					wt = wt.queryParam(key, x);
				}
			} else {
				wt = wt.queryParam(key, entry.getValue());
			}
		}
		return wt;
	}

	public static Response responseFromFile(String resourcePath) {
		try (InputStream is = WebCliHelper.class.getClassLoader()
				.getResourceAsStream(resourcePath)) {
			if (null == is) {
				log.error("test response file {} null", resourcePath);
				return Response.status(404).build();
			}
			byte[] targetArray = new byte[is.available()];

			is.read(targetArray);

			return Response.ok(targetArray, MediaType.APPLICATION_JSON_TYPE).build();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public static String createFakeToken(String tenant, String userId) {
		return JWT.create()
				.withClaim("name", userId)
				.withClaim("tenant", tenant)
				.sign(Algorithm.HMAC256("testtesttest"));
	}

	public static ObjectMapper getObjectMapper() {
		ObjectMapper objectMapper = new ObjectMapper();

		objectMapper
				.setTimeZone(TimeZone.getDefault())
				.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

		SimpleModule module = new SimpleModule("custom-deserializers", Version.unknownVersion());
		module.addSerializer(Geometry.class, new WKTGeometrySerializer());
		module.addDeserializer(Geometry.class, new WKTGeometryDeserializer());
		objectMapper.registerModule(module);

		return objectMapper;
	}

}
