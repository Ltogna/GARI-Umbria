import com.abacogroup.cropplan.CropPlanApplication;

public class Server_agea_dev {
	public static void main(String[] args) throws Exception {
		CropPlanApplication.main(new String[] {
				"server", "crop-plan-api/config-agea.yml"
		});
	}
}
