import com.abacogroup.cropplan.CropPlanApplication;

public class Server_umbria_dev {
	public static void main(String[] args) throws Exception {
		CropPlanApplication.main(new String[] {
				"server", "crop-plan-api/config-umbria-dev.yml"
		});
	}
}
