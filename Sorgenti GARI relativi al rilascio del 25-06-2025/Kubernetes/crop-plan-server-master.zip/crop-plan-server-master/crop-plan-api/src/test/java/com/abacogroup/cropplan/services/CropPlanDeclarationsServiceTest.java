package com.abacogroup.cropplan.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

import com.abacogroup.cropplan.RuntimeEnvironmentImpl;
import com.abacogroup.cropplan.api.EditDeclarationsResult;
import com.abacogroup.cropplan.api.PlotBuffer;
import com.abacogroup.cropplan.api.payload.EditDeclarationsFieldsPayload;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.db.dao.SyncDAO;
import com.abacogroup.cropplan.db.dao.ValidatorDAO;
import com.abacogroup.cropplan.db.dao.ntt.DeclarationWithPlotCode;
import com.abacogroup.cropplan.db.dao.ntt.PermanentCropFormWithDeclCode;
import com.abacogroup.cropplan.exceptions.InvalidDeclAreaPercZeroException;
import com.abacogroup.cropplan.exceptions.LandUseCodeNotFoundException;
import com.abacogroup.cropplan.exceptions.PlotBufferException;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.sdk.model.PermanentCropForm;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormData;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormExternalCodeDecode;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseDetails;
import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormConfig;
import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormFieldConfig;
import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormType;
import com.abacogroup.cropplan.sdk.spi.CropCodesPlugin;
import com.abacogroup.cropplan.sdk.spi.CropPlanPlugin;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;

class CropPlanDeclarationsServiceTest {

	private CropCodeService cropCodeService = mock(CropCodeService.class);
	private ValidatorService validatorService = mock(ValidatorService.class);
	private PesticidesService pesticidesService = mock(PesticidesService.class);
	private CropPlanConfigService cropPlanConfigService = mock(CropPlanConfigService.class);
	private PluginManager pluginManager = mock(PluginManager.class);
	private CropPlanPlugin  cropPlanPlugin = mock();
	private CropCodesPlugin cropCodesPlugin = mock();
	private CropPlansDAO cropPlansDAO = mock(CropPlansDAO.class);
	private ValidatorDAO validatorDAO = mock(ValidatorDAO.class);
	private SyncDAO syncDAO = mock(SyncDAO.class);
	private DeclarationsDAO declarationsDAO = mock(DeclarationsDAO.class);

	private RuntimeEnvironment env = new RuntimeEnvironmentImpl();

	private DAOContainer daoContainer = DAOContainer.builder()
			.cropPlansDAO(cropPlansDAO)
			.validatorDAO(validatorDAO)
			.syncDAO(syncDAO)
			.declarationsDAO(declarationsDAO)
			.build();

	private CropPlanDeclarationsService cropPlanDeclarationsService =
			spy(new CropPlanDeclarationsService(cropCodeService, validatorService, pesticidesService, cropPlanConfigService,
					pluginManager, daoContainer));

	// ----- validateDecl -----
	@Test
	void test_validateDecl_ok() {

		String landUseCode = "000-111-222-333-444";
		double areaPerc = 5.55;
		String businessId = "555";
		long cropPlanId = 123L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20231212");

		given(cropPlanConfigService.allowDeclsPercToZero(anyLong())).willReturn(false);
		given(cropCodeService.getLandUseCode(any(), anyString(), anyLong(), anyString(), any(), any()))
				.willReturn(new LandUseDetails());

		assertDoesNotThrow(() -> cropPlanDeclarationsService.validateDecl(env, landUseCode, areaPerc, businessId, cropPlanId, pointInTime));
	}

	@Test
	void test_validateDecl_koZeroPerc() {

		String landUseCode = "000-111-222-333-444";
		double areaPerc = 0.;
		String businessId = "555";
		long cropPlanId = 123L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20231212");

		given(cropPlanConfigService.allowDeclsPercToZero(anyLong())).willReturn(false);
		given(cropCodeService.getLandUseCode(any(), anyString(), anyLong(), anyString(), any(), any()))
				.willReturn(new LandUseDetails());

		assertThrows(InvalidDeclAreaPercZeroException.class, () -> cropPlanDeclarationsService.validateDecl(env, landUseCode, areaPerc, businessId, cropPlanId, pointInTime));
	}

	@Test
	void test_validateDecl_okZeroPerc() {

		String landUseCode = "000-111-222-333-444";
		double areaPerc = 0.;
		String businessId = "555";
		long cropPlanId = 123L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20231212");

		given(cropPlanConfigService.allowDeclsPercToZero(anyLong())).willReturn(true);
		given(cropCodeService.getLandUseCode(any(), anyString(), anyLong(), anyString(), any(), any()))
				.willReturn(new LandUseDetails());

		assertDoesNotThrow(() -> cropPlanDeclarationsService.validateDecl(env, landUseCode, areaPerc, businessId, cropPlanId, pointInTime));
	}

	@Test
	void test_validateDecl_koPerc() {

		String landUseCode = "000-111-222-333-444";
		double areaPerc = -10.;
		String businessId = "555";
		long cropPlanId = 123L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20231212");

		given(cropPlanConfigService.allowDeclsPercToZero(anyLong())).willReturn(true);
		given(cropCodeService.getLandUseCode(any(), anyString(), anyLong(), anyString(), any(), any()))
				.willReturn(new LandUseDetails());

		assertThrows(InvalidDeclAreaPercZeroException.class, () -> cropPlanDeclarationsService.validateDecl(env, landUseCode, areaPerc, businessId, cropPlanId, pointInTime));
	}

	@Test
	void test_validateDecl_koLandUseCode() {

		String landUseCode = "000-111-222-333-444";
		double areaPerc = 5.55;
		String businessId = "555";
		long cropPlanId = 123L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20231212");

		given(cropPlanConfigService.allowDeclsPercToZero(anyLong())).willReturn(false);
		given(cropCodeService.getLandUseCode(any(), anyString(), anyLong(), anyString(), any(), any()))
				.willThrow(new LandUseCodeNotFoundException(landUseCode));

		assertThrows(LandUseCodeNotFoundException.class, () -> cropPlanDeclarationsService.validateDecl(env, landUseCode, areaPerc, businessId, cropPlanId, pointInTime));
	}

	// ----- updateDeclarationsFields -----
	@Test
	void test_updateDeclarationsFields_LockDeclarationsFieldsOk() {

		String landUseCode = "000-111-222-333-444";
		String businessId = "555";
		long cropPlanId = 123L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20231212");
		String domainZoneId = "A00";
		LocalDateTime currentDt = LocalDateTime.now();
		EditDeclarationsFieldsPayload payload = new EditDeclarationsFieldsPayload();
		payload.setPointInTime(pointInTime);
		payload.setLanduseCode(landUseCode);
		boolean isBackOffice = false;
		boolean lockDeclarationsFieldsIfExternal = true;

		given(cropCodeService.getLandUseCode(any(), anyString(), anyLong(), anyString(), any(), any()))
				.willReturn(new LandUseDetails());
		given(cropPlanConfigService.isLockDeclarationsFieldsIfExternal(anyLong())).willReturn(lockDeclarationsFieldsIfExternal);
		given(cropPlansDAO.findDeclarationsByLandUseCodeAndDomainZoneId(anyLong(), any(), any(), any(), anyString(), anyString()))
				.willReturn(List.of(
						DeclarationWithPlotCode.builder().plotCode("123").declCode("123111").build(),
						DeclarationWithPlotCode.builder().plotCode("123").declCode("123222").build(),
						DeclarationWithPlotCode.builder().plotCode("456").declCode("456333").build()
				));
		doAnswer(i -> {
			((TransactionalConsumer<CropPlansDAO, ?>) i.getArgument(0)).useTransaction(cropPlansDAO);
			return null;
		}).when(cropPlansDAO).useTransaction(any());
		given(cropPlansDAO.getPermanentCropForms(any(), anyString(), anyLong(), any()))
				.willReturn(List.of(
						PermanentCropFormWithDeclCode.builder().plotCode("123").declCode("123111").formCode("111").formType("TEST").permanentCropFormData(
								PermanentCropFormData.builder().externalCode(null).build()).build(),
						PermanentCropFormWithDeclCode.builder().plotCode("123").declCode("123222").formCode("222").formType("TEST").permanentCropFormData(
								PermanentCropFormData.builder().externalCode("22").build()).build()
				)).willReturn(List.of(
						PermanentCropFormWithDeclCode.builder().plotCode("123").declCode("456333").formCode("333").formType("TEST").permanentCropFormData(
								PermanentCropFormData.builder().externalCode(null).build()).build(),
						PermanentCropFormWithDeclCode.builder().plotCode("123").declCode("456333").formCode("333").formType("TEST").permanentCropFormData(
								PermanentCropFormData.builder().externalCode("33").build()).build()
				));

		EditDeclarationsResult result = cropPlanDeclarationsService.updateDeclarationsFields(env, businessId, cropPlanId, domainZoneId,
				currentDt, payload, true, isBackOffice);

		verify(cropPlansDAO).updateDeclarationFields(eq("123111"), any(), any(), any(), any(), any(), any(), any(), any());
		verify(cropPlansDAO, never()).updateDeclarationFields(eq("123222"), any(), any(), any(), any(), any(), any(), any(), any());
		verify(cropPlansDAO, never()).updateDeclarationFields(eq("456333"), any(), any(), any(), any(), any(), any(), any(), any());

	}

	@Test
	void test_updateDeclarationsFields_noLockDeclarationsFieldsOk() {

		String landUseCode = "000-111-222-333-444";
		String businessId = "555";
		long cropPlanId = 123L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20231212");
		String domainZoneId = "A00";
		LocalDateTime currentDt = LocalDateTime.now();
		EditDeclarationsFieldsPayload payload = new EditDeclarationsFieldsPayload();
		payload.setPointInTime(pointInTime);
		payload.setLanduseCode(landUseCode);
		boolean isBackOffice = false;
		boolean lockDeclarationsFieldsIfExternal = false;

		given(cropCodeService.getLandUseCode(any(), anyString(), anyLong(), anyString(), any(), any()))
				.willReturn(new LandUseDetails());
		given(cropPlanConfigService.isLockDeclarationsFieldsIfExternal(anyLong())).willReturn(lockDeclarationsFieldsIfExternal);
		given(cropPlansDAO.findDeclarationsByLandUseCodeAndDomainZoneId(anyLong(), any(), any(), any(), anyString(), anyString()))
				.willReturn(List.of(
						DeclarationWithPlotCode.builder().plotCode("123").declCode("123111").build(),
						DeclarationWithPlotCode.builder().plotCode("123").declCode("123222").build(),
						DeclarationWithPlotCode.builder().plotCode("456").declCode("456333").build()
				));
		doAnswer(i -> {
			((TransactionalConsumer<CropPlansDAO, ?>) i.getArgument(0)).useTransaction(cropPlansDAO);
			return null;
		}).when(cropPlansDAO).useTransaction(any());
		given(cropPlansDAO.getPermanentCropForms(any(), anyString(), anyLong(), any()))
				.willReturn(List.of(
						PermanentCropFormWithDeclCode.builder().plotCode("123").declCode("123111").formCode("111").formType("TEST").permanentCropFormData(
								PermanentCropFormData.builder().externalCode(null).build()).build(),
						PermanentCropFormWithDeclCode.builder().plotCode("123").declCode("123222").formCode("222").formType("TEST").permanentCropFormData(
								PermanentCropFormData.builder().externalCode("22").build()).build()
				)).willReturn(List.of(
						PermanentCropFormWithDeclCode.builder().plotCode("456").declCode("456333").formCode("333").formType("TEST").permanentCropFormData(
								PermanentCropFormData.builder().externalCode(null).build()).build(),
						PermanentCropFormWithDeclCode.builder().plotCode("456").declCode("456333").formCode("333").formType("TEST").permanentCropFormData(
								PermanentCropFormData.builder().externalCode("33").build()).build()
				));

		EditDeclarationsResult result = cropPlanDeclarationsService.updateDeclarationsFields(env, businessId, cropPlanId, domainZoneId,
				currentDt, payload, true, isBackOffice);

		verify(cropPlansDAO).updateDeclarationFields(eq("123111"), any(), any(), any(), any(), any(), any(), any(), any());
		verify(cropPlansDAO).updateDeclarationFields(eq("123222"), any(), any(), any(), any(), any(), any(), any(), any());
		verify(cropPlansDAO).updateDeclarationFields(eq("456333"), any(), any(), any(), any(), any(), any(), any(), any());

	}

	// ----- getPlotBuffer -----
	@Test
	void test_getPlotBuffer_ok() {
		String businessId = "555";
		long cropPlanId = 123L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20231212");
		String domainZoneId = "A00";
		LocalDateTime currentDt = LocalDateTime.now();
		String plotCode = "456";
		String landUseCode = "000-000-000-000-000";

		given(pluginManager.getCropPlanPlugin(any(), any(), any())).willReturn(cropPlanPlugin);
		given(cropPlanPlugin.getPermanentCropFormExternalCodeDescription(any(), any())).willAnswer(i-> {
			List<String> codes = i.getArgument(1);

			return codes.stream().map(c -> new PermanentCropFormExternalCodeDecode(c, c, "?")).toList();
		});

		given(pluginManager.getCropCodesPlugin(any(), any(), any())).willReturn(cropCodesPlugin);
		given(cropCodesPlugin.getLandUses(any(), any())).willReturn(List.of(new LandUse(landUseCode, "")));

		given(declarationsDAO.getPlotDeclarations(any(), any(), any(), any(), any(), any())).willReturn(List.of(
				DeclarationWithPlotCode.builder()
						.plotCode(plotCode)
						.declCode("456_1")
						.areaPerc(100.)
						.permanentCropForms(List.of(
								PermanentCropForm.builder()
										.formCode("VINEYARD_FORM")
										.formType("VINEYARD_FORM")
										.permanentCropFormData(PermanentCropFormData.builder()
												.distanceBetweenRowsCm(250.)
												.build())
										.build()))
						.landuse(new LandUse(landUseCode, ""))
						.build()
		));

		given(cropCodeService.getLandUseCode(any(), any(), any(), any(), any(), any())).willReturn(
				new LandUseDetails(0, null, false, false, List.of(
						new PermanentCropFormConfig(0L, PermanentCropFormType.VINEYARD_FORM, List.of(
								new PermanentCropFormFieldConfig("DISTANCE_BETWEEN_ROWS_CM", true, true)
						))
				), "")
		);

		PlotBuffer plotBuffer = cropPlanDeclarationsService.getPlotBuffer(env, businessId, cropPlanId, domainZoneId, plotCode, currentDt, pointInTime);

		assertThat(plotBuffer).extracting(PlotBuffer::getBufferSize)
				.isEqualTo(new BigDecimal("1.25"));

	}

	@Test
	void test_getPlotBuffer_multipleOk() {
		String businessId = "555";
		long cropPlanId = 123L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20231212");
		String domainZoneId = "A00";
		LocalDateTime currentDt = LocalDateTime.now();
		String plotCode = "456";
		String landUseCode1 = "000-000-000-000-001";
		String landUseCode2 = "000-000-000-000-002";
		String landUseCode3 = "000-000-000-000-003";

		given(pluginManager.getCropPlanPlugin(any(), any(), any())).willReturn(cropPlanPlugin);
		given(cropPlanPlugin.getPermanentCropFormExternalCodeDescription(any(), any())).willAnswer(i-> {
			List<String> codes = i.getArgument(1);

			return codes.stream().map(c -> new PermanentCropFormExternalCodeDecode(c, c, "?")).toList();
		});

		given(pluginManager.getCropCodesPlugin(any(), any(), any())).willReturn(cropCodesPlugin);
		given(cropCodesPlugin.getLandUses(any(), any())).willAnswer(i-> {
			List<String> codes = i.getArgument(1);

			return codes.stream().map(c -> new LandUse(c, c)).toList();
		});

		given(declarationsDAO.getPlotDeclarations(any(), any(), any(), any(), any(), any())).willReturn(List.of(
				DeclarationWithPlotCode.builder()
						.plotCode(plotCode)
						.declCode("456_1")
						.areaPerc(45.)
						.permanentCropForms(List.of(
								PermanentCropForm.builder()
										.formCode("VINEYARD_FORM")
										.formType("VINEYARD_FORM")
										.permanentCropFormData(PermanentCropFormData.builder()
												.distanceBetweenRowsCm(250.)
												.build())
										.build()))
						.landuse(new LandUse(landUseCode1, ""))
						.build(),
				DeclarationWithPlotCode.builder()
						.plotCode(plotCode)
						.declCode("456_2")
						.areaPerc(35.)
						.permanentCropForms(List.of(
								PermanentCropForm.builder()
										.formCode("VINEYARD_FORM")
										.formType("VINEYARD_FORM")
										.permanentCropFormData(PermanentCropFormData.builder()
												.distanceBetweenRowsCm(350.)
												.build())
										.build()))
						.landuse(new LandUse(landUseCode2, ""))
						.build(),
				DeclarationWithPlotCode.builder()
						.plotCode(plotCode)
						.declCode("456_3")
						.areaPerc(20.)
						.permanentCropForms(List.of(
								PermanentCropForm.builder()
										.formCode("VINEYARD_FORM")
										.formType("VINEYARD_FORM")
										.permanentCropFormData(PermanentCropFormData.builder()
												.distanceBetweenRowsCm(150.)
												.build())
										.build()))
						.landuse(new LandUse(landUseCode3, ""))
						.build()
		));

		given(cropCodeService.getLandUseCode(any(), any(), any(), any(), any(), any())).willReturn(
				new LandUseDetails(0, null, false, false, List.of(
						new PermanentCropFormConfig(0L, PermanentCropFormType.VINEYARD_FORM, List.of(
								new PermanentCropFormFieldConfig("DISTANCE_BETWEEN_ROWS_CM", true, true)
						))
				), "")
		);

		PlotBuffer plotBuffer = cropPlanDeclarationsService.getPlotBuffer(env, businessId, cropPlanId, domainZoneId, plotCode, currentDt, pointInTime);

		assertThat(plotBuffer).extracting(PlotBuffer::getBufferSize)
				.isEqualTo(new BigDecimal("1.33"));

	}

	@Test
	void test_getPlotBuffer_missingFieldKo() {
		String businessId = "555";
		long cropPlanId = 123L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20231212");
		String domainZoneId = "A00";
		LocalDateTime currentDt = LocalDateTime.now();
		String plotCode = "456";
		String landUseCode = "000-000-000-000-000";

		given(pluginManager.getCropPlanPlugin(any(), any(), any())).willReturn(cropPlanPlugin);
		given(cropPlanPlugin.getPermanentCropFormExternalCodeDescription(any(), any())).willAnswer(i-> {
			List<String> codes = i.getArgument(1);

			return codes.stream().map(c -> new PermanentCropFormExternalCodeDecode(c, c, "?")).toList();
		});

		given(pluginManager.getCropCodesPlugin(any(), any(), any())).willReturn(cropCodesPlugin);
		given(cropCodesPlugin.getLandUses(any(), any())).willReturn(List.of(new LandUse(landUseCode, "")));

		given(declarationsDAO.getPlotDeclarations(any(), any(), any(), any(), any(), any())).willReturn(List.of(
				DeclarationWithPlotCode.builder()
						.plotCode(plotCode)
						.declCode("456_1")
						.areaPerc(100.)
						.landuse(new LandUse(landUseCode, ""))
						.build()
		));

		given(cropCodeService.getLandUseCode(any(), any(), any(), any(), any(), any())).willReturn(
				new LandUseDetails(0, null, false, false, List.of(
						new PermanentCropFormConfig(0L, PermanentCropFormType.VINEYARD_FORM, List.of(
								new PermanentCropFormFieldConfig("OTHER", true, true)
						))
				), "")
		);

		PlotBufferException plotBufferException = assertThrows(PlotBufferException.class,
				() -> cropPlanDeclarationsService.getPlotBuffer(env, businessId, cropPlanId, domainZoneId, plotCode, currentDt, pointInTime));

		assertThat(plotBufferException).isNotNull()
				.extracting(ex -> ((PlotBufferException) ex).getErrorBody().getErrorCode())
				.isEqualTo("MISSING_DISTANCE_BETWEEN_ROWS_CM");

	}
}
