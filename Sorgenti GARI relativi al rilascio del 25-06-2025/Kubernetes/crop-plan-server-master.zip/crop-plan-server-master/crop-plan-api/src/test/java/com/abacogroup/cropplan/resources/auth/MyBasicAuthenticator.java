package com.abacogroup.cropplan.resources.auth;

import java.util.Optional;

import com.abacogroup.dropwizard.auth.sso2.User;

import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.auth.Authenticator;
import io.dropwizard.auth.basic.BasicCredentials;

public class MyBasicAuthenticator implements Authenticator<BasicCredentials, User>
{
	@Override
	public Optional<User> authenticate(BasicCredentials credentials) throws AuthenticationException
	{
		return Optional.of(new User(credentials.getUsername(), "_"));
	}
}
