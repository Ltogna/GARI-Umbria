package com.abacogroup.cropplan.resources.models;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class HoldingAreaTestModel
{
	@NotNull
	private Integer areaSqm;
	
}
