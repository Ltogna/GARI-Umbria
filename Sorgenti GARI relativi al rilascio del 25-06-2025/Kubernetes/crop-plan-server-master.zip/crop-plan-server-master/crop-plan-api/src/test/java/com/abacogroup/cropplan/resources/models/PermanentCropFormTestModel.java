package com.abacogroup.cropplan.resources.models;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class PermanentCropFormTestModel
{

	@NotNull
	private String formCode;

	@NotNull
	private String formType;

	@Valid
	@NotNull
	private PermanentCropFormDataTestModel permanentCropFormData;

}
