package com.abacogroup.cropplan.resources.models;

import java.util.List;
import java.util.Map;

import org.locationtech.jts.geom.Geometry;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class SnapElementsTestModel
{
	@NotEmpty
	private List<SnapElementTypeTest> types;

	@NotEmpty
	private List<SnapGeometryTest> geometries;

	@AllArgsConstructor
	@NoArgsConstructor
	@Data
	public static class SnapGeometryTest
	{
		@NotEmpty
		private String id;

		@NotEmpty
		private String type;

		@NotEmpty
		private String description;

		@NotNull
		private Geometry geom;

		@NotNull
		private Map<String,String> tooltipData;
	}

	@AllArgsConstructor
	@NoArgsConstructor
	@Data
	public static class SnapElementTypeTest
	{
		@NotEmpty
		private String type;
		
		@NotEmpty
		private String description;

		@NotNull
		private Boolean flMergeGeomsOnCutOnLayer;
		
		@NotNull
		private Boolean flCalcCoveredByInsertedOnCutOnLayer;
	}
}
