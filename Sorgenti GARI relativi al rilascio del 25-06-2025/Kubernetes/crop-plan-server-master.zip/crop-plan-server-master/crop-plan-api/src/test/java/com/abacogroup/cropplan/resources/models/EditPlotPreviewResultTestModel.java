package com.abacogroup.cropplan.resources.models;

import jakarta.validation.constraints.NotEmpty;
import java.util.List;
import lombok.Data;

@Data
public class EditPlotPreviewResultTestModel
{
	@NotEmpty
	private List<PlotPreviewTestModel> added;
	
	@NotEmpty
	private List<String> deleted;
	
	@NotEmpty
	private List<PlotPreviewTestModel> updated;
	
	@NotEmpty
	private List<String> coveredByInserted;
}
