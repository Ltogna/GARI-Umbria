import com.abacogroup.cropplan.CropPlanApplication;

public class Server_malta_prod {
	public static void main(String[] args) throws Exception {
		CropPlanApplication.main(new String[] {
				"server", "crop-plan-api/config-malta-live.yml"
		});
	}
}
