package com.abacogroup.cropplan.resources.models;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BaseDeclarationTestModel
{
	@NotNull
	private String declCode;

	@NotNull
	private LandUseTestModel landuse;

	@NotNull
	private Double areaPerc;

	@NotNull
	private StyleTestModel style;

	@NotNull
	@NotEmpty
	private String fromDate;
	
	@NotNull
	@NotEmpty
	private String fromDatePrecision;

	@NotNull
	@NotEmpty
	private String toDate;
}
