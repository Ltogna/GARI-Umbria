package com.abacogroup.cropplan.resources.pub;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.auth.MyBasicAuthenticator;
import com.abacogroup.cropplan.resources.auth.MyBasicAuthorizer;
import com.abacogroup.cropplan.resources.models.BusinessTestModel;
import com.abacogroup.cropplan.resources.models.InfiniteListResultTestModel;
import com.abacogroup.cropplan.resources.providers.LocalDateTimeProvider;
import com.abacogroup.cropplan.sdk.model.business.Business;
import com.abacogroup.cropplan.sdk.spi.BusinessPlugin;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.plugins.impl.EnvironmentFactory;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import io.dropwizard.auth.AuthDynamicFeature;
import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.auth.basic.BasicCredentialAuthFilter;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.HttpHeaders;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Set;
import org.glassfish.jersey.test.grizzly.GrizzlyWebTestContainerFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.locationtech.jts.io.ParseException;

@ExtendWith(DropwizardExtensionsSupport.class)
public class PublicBusinessRegistryResourcesTest {
	private static BaseService baseService = mock(BaseService.class);
	private static PluginManager pluginManager = mock(PluginManager.class);
	private static BusinessPlugin businessPlugin = mock(BusinessPlugin.class);
	
	private static final ResourceExtension EXT = ResourceExtension.builder()
			.setTestContainerFactory(new GrizzlyWebTestContainerFactory())
			.addProvider(new AuthDynamicFeature(new BasicCredentialAuthFilter.Builder<User>()
					.setAuthenticator(new MyBasicAuthenticator())
					.setAuthorizer(new MyBasicAuthorizer())
					.buildAuthFilter()))
			.addProvider(new AuthValueFactoryProvider.Binder<>(User.class))
			.addProvider(LocalDateTimeProvider.class)
			.addResource(new PublicTenantBusinessRegistryResources(baseService, pluginManager))
			.addProvider(baseService)
			.build();

	@BeforeEach
	public void init() {
		var envFactory = mock(EnvironmentFactory.class);
		when(baseService.getEnvironmentFactory())
				.thenReturn(envFactory);
		var env = mock(RuntimeEnvironment.class);
		when(envFactory.create(any(), any()))
				.thenReturn(env);
		when(env.getTenantId())
				.thenReturn("_");
		
		when(pluginManager.getBusinessPlugin())
				.thenReturn(businessPlugin);
	}

	@Test
	public void whenSearchBusiness_thenReturnBusinessKeepingPropertiesUnchanged() throws ParseException {
		List<Business> business = new ArrayList<>();
		business.add(getMockedBusiness());
		var ret = new InfiniteListResultsImpl<>(business, null);
		when(businessPlugin.searchBusinessesInfinite(any(), any(), any()))
				.thenReturn(ret);

		var res = EXT.target("_/public/v1/business-registry")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<InfiniteListResultTestModel<BusinessTestModel>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<BusinessTestModel>> violations = validator.validate(res.getRecords().get(0));
		assertEquals(violations.size(), 0);
	}

	private Business getMockedBusiness() {
		var business = new Business();
		business.setBusinessId("THE_BUSINESS_ID");
		business.setCode("THE_BUSINESS_CODE");
		business.setDescription("THE_BUSINESS_DESCR");
		return business;
	}
	
}
