package com.abacogroup.cropplan.resources.models;

import org.locationtech.jts.geom.Geometry;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChangedPlotTestModel
{
	@NotEmpty
	private String plotCode;

	@NotNull
	private Geometry geom;
	
	@NotEmpty
	private String srs;

	@NotEmpty
	private String domainZoneId;

	@NotEmpty
	private String domainZoneCode;

	@NotNull
	private boolean geomChanged;
	
	@NotEmpty
	private String plotDescription;
}
