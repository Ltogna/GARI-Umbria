package com.abacogroup.cropplan.resources.models;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.locationtech.jts.geom.Geometry;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PlotPreviewTestModel
{
	@NotEmpty
	@Schema(description = "The plot 'stable' code, this does not change in history")
	private String plotCode;

	@NotNull
	@Schema(description = "The geometry", type = "string", format = "WKT geometry")
	private Geometry geom;
}
