package com.abacogroup.cropplan.resources.models;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "A registration of pesticide on a declaration")
public class PesticideEntryTestModel
{
	@NotNull
	private String pesticideEntryCode;

	@NotNull
	private Long planId;

	@NotNull
	private String plotCode;

	@NotNull
	private String declCode;

	@NotNull
	private String productCode;

	@NotNull
	private String uomCode;

	@NotNull
	private Long amount;

	@NotNull
	private AbsoluteDate entryDate;

	private String productName;

	private String uomLabel;	

	private String userId;

	private BaseDeclarationTestModel declaration;

	private List<ParcelIntersectionTestModel> parcelIntersection;

	private Integer plotAreaSqm;
}
