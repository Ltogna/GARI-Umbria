package com.abacogroup.cropplan.resources.models;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;
import lombok.Data;

@Data
public class UnitsOfMeasurmentTestModel
{
	@Valid
	@NotEmpty
	private List<UnitOfMeasurmentTestModel> basicUoms;
	
	@Valid
	@NotEmpty
	private List<UnitOfMeasurmentTestModel> perAreaUoms;
}
