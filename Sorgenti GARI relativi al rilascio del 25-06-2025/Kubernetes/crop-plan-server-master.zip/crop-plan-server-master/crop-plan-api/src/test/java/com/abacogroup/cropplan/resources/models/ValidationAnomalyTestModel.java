package com.abacogroup.cropplan.resources.models;

import com.abacogroup.cropplan.sdk.model.validation.AnomalyObjectType;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ValidationAnomalyTestModel
{
	@NotEmpty
	private String objectCode;

	@NotNull
	private AnomalyObjectType objectType;

	@NotEmpty
	private String errorCode;
	
	@NotEmpty
	private String errorDescription;

	@NotNull
	private Boolean blocking;
}
