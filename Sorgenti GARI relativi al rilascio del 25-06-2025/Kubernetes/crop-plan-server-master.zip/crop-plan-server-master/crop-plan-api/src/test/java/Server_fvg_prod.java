import com.abacogroup.cropplan.CropPlanApplication;

public class Server_fvg_prod {
	public static void main(String[] args) throws Exception {
		CropPlanApplication.main(new String[] {
				"server", "crop-plan-api/config-fvg-prod.yml"
		});
	}
}
