package com.abacogroup.cropplan.resources.models;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DomainZoneTestModel
{
	@NotNull
	private String domainZoneId;

	@NotNull
	private String code;

	@NotNull
	private String description;

	@NotNull
	private String srs;

	@Valid
	@NotNull
	private MBRTest mbr;
	
	@Valid
	@NotNull
	private HoldingAreaTestModel holdingArea;
	
	@NotNull
	private boolean bigDomainZone;

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static final class MBRTest
	{
		@NotNull
		private double xMin;

		@NotNull
		private double yMin;

		@NotNull
		private double xMax;

		@NotNull
		private double yMax;
	}
}
