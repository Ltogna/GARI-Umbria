package com.abacogroup.cropplan.services.utils;

import static org.assertj.core.api.Assertions.assertThat;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class DateIntervalTest {

	// ----- cutOnFreeIntervals -----
	@MethodSource
	@ParameterizedTest
	void test_cutOnFreeIntervals_ok(DateInterval dateInterval, List<DateInterval> dates, int freeSize, DateInterval expectedDateInterval) {

		List<DateInterval> freeIntervals = DateInterval.findFreeIntervals(new ArrayList<>(dates));
		assertThat(freeIntervals).hasSize(freeSize);

		DateInterval newDateInterval = DateInterval.cutOnFreeIntervals(dateInterval, freeIntervals);

		assertThat(newDateInterval).isEqualTo(expectedDateInterval);

	}

	static Stream<Arguments> test_cutOnFreeIntervals_ok() {
		return Stream.of(
				Arguments.arguments(
						dateInterval("20240210", "20240630"),
						List.of(
								dateInterval(null, "19700101"),
								dateInterval("20240101", "20240304"),
								dateInterval("20240721", "20241231"),
								dateInterval( "99991231", null)
						), 3,
						dateInterval("20240305", "20240630")
				)
				, Arguments.arguments(
						dateInterval("20240210", "20240630"),
						List.of(
								dateInterval(null, "19700101"),
								dateInterval( "99991231", null)
						), 1,
						dateInterval("20240210", "20240630")
				)
				, Arguments.arguments(
						dateInterval("20240210", "20240630"),
						List.of(
								new DateInterval(LocalDate.MIN, LocalDate.MIN),
								new DateInterval(LocalDate.MAX, LocalDate.MAX)
						), 1,
						dateInterval("20240210", "20240630")
				)
				, Arguments.arguments(
						dateInterval("20240210", "20240630"),
						List.of(
								new DateInterval(LocalDate.MIN, LocalDate.MIN),
								dateInterval("20240101", "20240304"),
								new DateInterval(LocalDate.MAX, LocalDate.MAX)
						), 2,
						dateInterval("20240305", "20240630")
				)
				, Arguments.arguments(
						dateInterval("20240210", "20240630"),
						List.of(
								new DateInterval(LocalDate.MIN, LocalDate.MIN),
								dateInterval("20240101", "20240304"),
								dateInterval("20240721", "20241231"),
								new DateInterval(LocalDate.MAX, LocalDate.MAX)
						), 3,
						dateInterval("20240305", "20240630")
				)
				, Arguments.arguments(
						dateInterval("20240210", "20240630"),
						List.of(
								dateInterval(null, "19700101"),
								dateInterval("20240101", "20240304"),
								dateInterval("20240721", "20241231"),
								dateInterval("20240121", "20240701"),
								dateInterval( "99991231", null)
						), 3,
						null
				)
				, Arguments.arguments(
						dateInterval("20240210", "20241130"),
						List.of(
								dateInterval(null, "19700101"),
								dateInterval("20240221", "20240304"),
								dateInterval("20240721", "20241231"),
								dateInterval( "99991231", null)
						), 3,
						dateInterval("20240305", "20240720")
				)
				, Arguments.arguments(
						dateInterval("20240210", "20241130"),
						List.of(
								dateInterval(null, "20240731"),
								dateInterval("20240221", "20240304"),
								dateInterval("20240901", "20241231"),
								dateInterval( "20241001", null)
						), 1,
						dateInterval("20240801", "20240831")
				)
				, Arguments.arguments(
						dateInterval("20240201", "20241130"),
						List.of(
								dateInterval(null, "20231231"),
								dateInterval("20200202", "20230831"),
								dateInterval("19700101", "20240131"),
								dateInterval("19700101", "20240331"),
								dateInterval("20200202", "20240531"),
								dateInterval("20240701", "99991231"),
								dateInterval("20240801", "99991231"),
								dateInterval("20241201", "99991231"),
								dateInterval("20250301", "99991231"),
								new DateInterval(LocalDate.of(10000, 1, 1), LocalDate.MAX)
						), 1,
						dateInterval("20240601", "20240630")
				)
		);

	}


	private static DateInterval dateInterval(String dtFrom, String dtTo) {
		return new DateInterval(
				null == dtFrom ? LocalDate.MIN : AbsoluteDate.of(dtFrom).toLocalDate(),
				null == dtTo ? LocalDate.MAX : AbsoluteDate.of(dtTo).toLocalDate()
		);
	}
}
