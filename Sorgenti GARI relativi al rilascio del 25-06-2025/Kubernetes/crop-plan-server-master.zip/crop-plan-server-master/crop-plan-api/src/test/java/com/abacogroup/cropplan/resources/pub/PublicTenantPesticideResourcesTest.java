package com.abacogroup.cropplan.resources.pub;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.PesticidesDAO;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.auth.MyBasicAuthenticator;
import com.abacogroup.cropplan.resources.auth.MyBasicAuthorizer;
import com.abacogroup.cropplan.resources.models.InfiniteListResultTestModel;
import com.abacogroup.cropplan.resources.models.PesticideEntryTestModel;
import com.abacogroup.cropplan.resources.models.PesticideTestModel;
import com.abacogroup.cropplan.resources.models.UnitsOfMeasurmentTestModel;
import com.abacogroup.cropplan.resources.providers.LocalDateTimeProvider;
import com.abacogroup.cropplan.sdk.jackson.WKTGeometryDeserializer;
import com.abacogroup.cropplan.sdk.jackson.WKTGeometrySerializer;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.BaseDeclaration;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.auth.CropPlanTypeAccessLevel;
import com.abacogroup.cropplan.sdk.model.pesticides.Pesticide;
import com.abacogroup.cropplan.sdk.model.pesticides.PesticideEntry;
import com.abacogroup.cropplan.sdk.model.pesticides.UnitOfMeasurment;
import com.abacogroup.cropplan.sdk.model.pesticides.UnitsOfMeasurment;
import com.abacogroup.cropplan.sdk.model.pesticides.UomType;
import com.abacogroup.cropplan.sdk.spi.PesticidesPlugin;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.cropplan.services.CropPlanDeclarationsService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.LocksService;
import com.abacogroup.cropplan.services.PesticidesService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.plugins.impl.EnvironmentFactory;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import io.dropwizard.auth.AuthDynamicFeature;
import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.auth.basic.BasicCredentialAuthFilter;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.HttpHeaders;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Set;
import org.glassfish.jersey.test.grizzly.GrizzlyWebTestContainerFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.locationtech.jts.geom.Geometry;

@ExtendWith(DropwizardExtensionsSupport.class)
public class PublicTenantPesticideResourcesTest
{
	private static BaseService baseService = mock(BaseService.class);
	private static PluginManager pluginManager = mock(PluginManager.class);
	private static PesticidesPlugin pesticidesPlugin = mock(PesticidesPlugin.class);
	private static PesticidesDAO pesticidesDAO = mock(PesticidesDAO.class);
	private static PesticidesService pesticidesService = mock(PesticidesService.class);
	private static CropPlanService cropPlanService = mock(CropPlanService.class);
	private static CropPlanDeclarationsService cropPlanDeclarationsService = mock(CropPlanDeclarationsService.class);
	private static LocksService locksService = mock(LocksService.class);
	private static CropCodeService cropCodeService = mock(CropCodeService.class);
	private static ValidatorService validatorService = mock(ValidatorService.class);
	private static CropPlansDAO cropPlansDAO = mock(CropPlansDAO.class);
	private static CropPlanConfigDAO cropPlanConfigDAO = mock(CropPlanConfigDAO.class);
	private static ObjectMapper mapper = createMapper();

	private static DAOContainer daoContainer = DAOContainer.builder()
			.cropPlansDAO(cropPlansDAO)
			.cropPlanConfigDAO(cropPlanConfigDAO)
			.pesticidesDAO(pesticidesDAO)
			.build();

	private static final ResourceExtension EXT = ResourceExtension.builder()
		.setTestContainerFactory(new GrizzlyWebTestContainerFactory())
		.addProvider(new AuthDynamicFeature(new BasicCredentialAuthFilter.Builder<User>()
			.setAuthenticator(new MyBasicAuthenticator())
			.setAuthorizer(new MyBasicAuthorizer())
			.buildAuthFilter()))
        .addProvider(new AuthValueFactoryProvider.Binder<>(User.class))
		
        .addProvider(LocalDateTimeProvider.class)
			.addResource(new PublicTenantPesticideResources(baseService, pluginManager, daoContainer, pesticidesService, cropPlanService,
					cropPlanDeclarationsService, locksService, cropCodeService, validatorService, mock()))
        .addProvider(baseService)
        .setMapper(mapper)
        .build();
	
	public static ObjectMapper createMapper()
	{
		ObjectMapper objectMapper = new ObjectMapper()
			.findAndRegisterModules()
			.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true);

		SimpleModule module = new SimpleModule("custom-deserializers", com.fasterxml.jackson.core.Version.unknownVersion());
		module.addSerializer(Geometry.class, new WKTGeometrySerializer());
		module.addDeserializer(Geometry.class, new WKTGeometryDeserializer());
		objectMapper.registerModule(module);

		return objectMapper;
	}

	@BeforeEach
	public void init()
	{
		var envFactory = mock(EnvironmentFactory.class);
		when(baseService.getEnvironmentFactory())
			.thenReturn(envFactory);
		var env = mock(RuntimeEnvironment.class);
		when(envFactory.create(any(), any()))
			.thenReturn(env);
		when(env.getTenantId())
			.thenReturn("_");
		
		when(pluginManager.getPesticidesPlugin(any(), anyLong(), any()))
			.thenReturn(pesticidesPlugin);

		when(baseService.canRead(any(), any(), any()))
			.thenReturn(true);
		when(cropPlanService.getAccessLevel(any(), any(), any()))
			.thenReturn(CropPlanTypeAccessLevel.CREATE);
	}

	@Test
	public void whenGetPesticides_thenReturnPesticidesKeepingPropertiesUnchanged()
	{
		List<Pesticide> pesticides = new ArrayList<>();
		Pesticide pesticide = new Pesticide("productName", "productCode", "plantProtectionProductType", 1L, "activeSubstanceConcentrationAmountUom", UomType.VOLUME);
		pesticides.add(pesticide);
		var ret = new InfiniteListResultsImpl<>(pesticides, null);
		when(pesticidesPlugin.getPesticides(any(), any(), any(), any()))
			.thenReturn(ret);

		var res = EXT.target("_/public/v1/pesticides/1/plans/1/available-pesticides")
			.queryParam("landUseCodes", "0")
			.request()
        	.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
			.get(new GenericType<InfiniteListResultTestModel<PesticideTestModel>>() {});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<PesticideTestModel>> violations = validator.validate(res.getRecords().get(0));
		assertEquals(violations.size(), 0);
	}

	@Test
	public void whenPesticideUoms_thenReturnUnitsOfMeasurmentKeepingPropertiesUnchanged()
	{
		List<UnitOfMeasurment> basicUoms = new ArrayList<>();
		basicUoms.add(new UnitOfMeasurment("l", "l", false));
		
		List<UnitOfMeasurment> perAreaUoms = new ArrayList<>();
		perAreaUoms.add(new UnitOfMeasurment("l/h", "l_h", true));
		
		UnitsOfMeasurment unitsOfMeasurment = new UnitsOfMeasurment(basicUoms, perAreaUoms);
		when(pesticidesPlugin.getUnitsOfMeasurment(any(), any()))
			.thenReturn(unitsOfMeasurment);

		var res = EXT.target("_/public/v1/pesticides/1/plans/1/available-pesticides/units-of-measurment/VOLUME")
			.request()
			.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
			.get(UnitsOfMeasurmentTestModel.class);

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<UnitsOfMeasurmentTestModel>> violations = validator.validate(res);
		assertEquals(violations.size(), 0);
	}

	@Test
	public void whenDeclPesticides_thenReturnPesticideEntryKeepingPropertiesUnchanged()
	{
		List<ParcelIntersection> parcels = new ArrayList<>();
		var parcel = new ParcelIntersection();
		parcel.setAreaSqm(1);
		parcel.setCode("parcel_code");
		parcel.setDescription("parcel_descr");
		parcel.setParcelCode("parcel_descr");
		parcel.setLandCoverCode("lcc");
		parcel.setLandCoverDescription("lcc_descr");

		parcels.add(parcel);

		List<PesticideEntry> pesticides = new ArrayList<>();
		PesticideEntry pesticide = new PesticideEntry("pesticideEntryCode", 1L, "plotCode", "declCode", "productCode", "uomCode", 1L, AbsoluteDate.of("20220101"), "productName", "uomLabel", "ADMIN", new BaseDeclaration(), parcels, 0);
		pesticides.add(pesticide);
		var ret = new InfiniteListResultsImpl<>(pesticides, null);
		when(pesticidesService.getPesticideEntriesPaged(any(), any(), anyLong(), any(), any(), any(), any(), any(), any(), anyInt())).thenReturn(ret);

		var res = EXT.target("_/public/v1/pesticides/1/plans/1/zones/GMZ0/plots/1/decls/1/pesticides-entries")
			.request()
			.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
			.get(new GenericType<InfiniteListResultTestModel<PesticideEntryTestModel>>() {});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<PesticideEntryTestModel>> violations = validator.validate(res.getRecords().get(0));
		assertEquals(violations.size(), 0);
	}
	
	// TODO TEST getLandUsePesticides
}
