package com.abacogroup.cropplan.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.CropPlanConfigData;
import com.abacogroup.cropplan.sdk.model.config.CropPlanConfigParam;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;

public class CropPlanConfigServiceTest {

	private CropPlanConfigService cropPlanConfigService;
	private CropPlanConfigDAO crplConfigDAO;
	
	@BeforeEach
	public void init() {
		crplConfigDAO = mock(CropPlanConfigDAO.class);
		when(crplConfigDAO.getCropPlanConfig(ArgumentMatchers.anyLong(), ArgumentMatchers.eq(CropPlanConfigParam.SNAP_FROM_CAMPAIGN_REF_DATE.toString()), 
				ArgumentMatchers.eq("TRUE"))).thenReturn(List.of(new CropPlanConfigData(CropPlanConfigParam.SNAP_FROM_CAMPAIGN_REF_DATE.toString(), "TRUE")));

		DAOContainer daoContainer = DAOContainer.builder()
				.cropPlanConfigDAO(crplConfigDAO)
				.build();

		cropPlanConfigService = new CropPlanConfigService(daoContainer);
	}

	@Test
	public void whenGetSnapDates_thenReturnCorrectSnapDates() {
		AbsoluteDate snapFromDate, cmpStartDate;
		
		when(crplConfigDAO.getCropPlanConfig(ArgumentMatchers.anyLong(), ArgumentMatchers.eq(CropPlanConfigParam.CAMPAIGN_START_DATE.toString()), 
				ArgumentMatchers.any())).thenReturn(List.of(new CropPlanConfigData(CropPlanConfigParam.CAMPAIGN_START_DATE.toString(), "0101")));
		when(crplConfigDAO.getCropPlanConfig(ArgumentMatchers.anyLong(), ArgumentMatchers.eq(CropPlanConfigParam.CAMPAIGN_REF_DATE.toString()), 
				ArgumentMatchers.any())).thenReturn(List.of(new CropPlanConfigData(CropPlanConfigParam.CAMPAIGN_REF_DATE.toString(), "0401")));
		
		snapFromDate = cropPlanConfigService.getSnapFromDate(1l, AbsoluteDate.of("20220201"));
		assertEquals("20220401", snapFromDate.toString());
		cmpStartDate = cropPlanConfigService.getCampaignStartDate(1l, AbsoluteDate.of("20220201"));
		assertEquals("20220101", cmpStartDate.toString());
			
		snapFromDate = cropPlanConfigService.getSnapFromDate(1l, AbsoluteDate.of("20221201"));
		assertEquals("20220401", snapFromDate.toString());
		cmpStartDate = cropPlanConfigService.getCampaignStartDate(1l, AbsoluteDate.of("20221201"));
		assertEquals("20220101", cmpStartDate.toString());
		
		snapFromDate = cropPlanConfigService.getSnapFromDate(1l, AbsoluteDate.of("20221101"));
		assertEquals("20220401", snapFromDate.toString());
		cmpStartDate = cropPlanConfigService.getCampaignStartDate(1l, AbsoluteDate.of("20221101"));
		assertEquals("20220101", cmpStartDate.toString());
		
		/********************************************************/
		
		when(crplConfigDAO.getCropPlanConfig(ArgumentMatchers.anyLong(), ArgumentMatchers.eq(CropPlanConfigParam.CAMPAIGN_START_DATE.toString()), 
				ArgumentMatchers.any())).thenReturn(List.of(new CropPlanConfigData(CropPlanConfigParam.CAMPAIGN_START_DATE.toString(), "1101")));
		when(crplConfigDAO.getCropPlanConfig(ArgumentMatchers.anyLong(), ArgumentMatchers.eq(CropPlanConfigParam.CAMPAIGN_REF_DATE.toString()), 
				ArgumentMatchers.any())).thenReturn(List.of(new CropPlanConfigData(CropPlanConfigParam.CAMPAIGN_REF_DATE.toString(), "0401")));
		
		snapFromDate = cropPlanConfigService.getSnapFromDate(1l, AbsoluteDate.of("20220201"));
		assertEquals("20220401", snapFromDate.toString());
		cmpStartDate = cropPlanConfigService.getCampaignStartDate(1l, AbsoluteDate.of("20220201"));
		assertEquals("20211101", cmpStartDate.toString());
		
		snapFromDate = cropPlanConfigService.getSnapFromDate(1l, AbsoluteDate.of("20221201"));
		assertEquals("20230401", snapFromDate.toString());
		cmpStartDate = cropPlanConfigService.getCampaignStartDate(1l, AbsoluteDate.of("20221201"));
		assertEquals("20221101", cmpStartDate.toString());
		
		snapFromDate = cropPlanConfigService.getSnapFromDate(1l, AbsoluteDate.of("20221101"));
		assertEquals("20230401", snapFromDate.toString());
		cmpStartDate = cropPlanConfigService.getCampaignStartDate(1l, AbsoluteDate.of("20221101"));
		assertEquals("20221101", cmpStartDate.toString());
		
	}

	// ----- getBulkDeclarationsAnomaliesFilter -----
	@Test
	void test_getBulkDeclarationsAnomaliesFilter_ok() {
		long cropPlanId = 123L;

		given(crplConfigDAO.getCropPlanConfig(any(), any(), any()))
				.willReturn(List.of(CropPlanConfigData.builder().paramValue("AAA BBB CCC").build()));

		// test
		List<String> bulkDeclarationsAnomaliesFilter = cropPlanConfigService.getBulkDeclarationsAnomaliesFilter(cropPlanId);

		assertThat(bulkDeclarationsAnomaliesFilter).hasSize(3)
				.containsExactlyInAnyOrder("AAA", "BBB", "CCC");
	}

	@Test
	void test_getBulkDeclarationsAnomaliesFilter_emptyOk() {
		long cropPlanId = 123L;

		given(crplConfigDAO.getCropPlanConfig(any(), any(), any()))
				.willReturn(List.of());

		// test
		List<String> bulkDeclarationsAnomaliesFilter = cropPlanConfigService.getBulkDeclarationsAnomaliesFilter(cropPlanId);

		assertThat(bulkDeclarationsAnomaliesFilter).isEmpty();
	}

	@Test
	void test_getBulkDeclarationsAnomaliesFilter_emptyValueOk() {
		long cropPlanId = 123L;

		given(crplConfigDAO.getCropPlanConfig(any(), any(), any()))
				.willReturn(List.of(CropPlanConfigData.builder().paramValue("").build()));

		// test
		List<String> bulkDeclarationsAnomaliesFilter = cropPlanConfigService.getBulkDeclarationsAnomaliesFilter(cropPlanId);

		assertThat(bulkDeclarationsAnomaliesFilter).isEmpty();
	}

	@Test
	void test_getBulkDeclarationsAnomaliesFilter_singleOk() {
		long cropPlanId = 123L;

		given(crplConfigDAO.getCropPlanConfig(any(), any(), any()))
				.willReturn(List.of(CropPlanConfigData.builder().paramValue("AAA").build()));

		// test
		List<String> bulkDeclarationsAnomaliesFilter = cropPlanConfigService.getBulkDeclarationsAnomaliesFilter(cropPlanId);

		assertThat(bulkDeclarationsAnomaliesFilter).hasSize(1)
				.containsExactlyInAnyOrder("AAA");
	}
}
