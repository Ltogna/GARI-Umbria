package com.abacogroup.cropplan.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.abacogroup.cropplan.CropPlanConfiguration;
import com.abacogroup.cropplan.api.CropPlan;
import com.abacogroup.cropplan.api.SyncStatus;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.SyncDAO;
import com.abacogroup.cropplan.db.dao.ntt.SyncPlot;
import com.abacogroup.cropplan.dispatch.CropPlanCommitPayload;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.sync.SyncParcel;
import com.abacogroup.cropplan.sdk.model.sync.SyncType;
import com.abacogroup.cropplan.sdk.spi.SyncPlugin;
import com.abacogroup.cropplan.services.eqjobs.SyncJobConsumer;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.embeddedqueue.AbstractWorkQueue;
import com.abacogroup.plugins.impl.EnvironmentFactory;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.codahale.metrics.MetricRegistry;
import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.ws.rs.core.SecurityContext;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;
import org.mockito.Spy;

@Disabled
@ExtendWith(DropwizardExtensionsSupport.class)
public class SyncServiceTest {
	private static SyncService syncService;
	@Spy
	private static SyncService syncServiceMock;
	
	private static CropPlanService cropPlanService = mock(CropPlanService.class);
	private static CropPlanDeclarationsService cropPlanDeclarationsService = mock(CropPlanDeclarationsService.class);
	
	private static CropPlanConfiguration configuration = mock(CropPlanConfiguration.class);
	private static Sso2Client sso2Client = mock(Sso2Client.class);
	private static Environment environment = mock(Environment.class);
	private static Jdbi jdbi = mock(Jdbi.class);
	
	private static BaseService baseService = mock(BaseService.class);
	private static CropPlanConfigService cropPlanConfigService = mock(CropPlanConfigService.class);
	
	private static MetricRegistry metricRegistry = mock(MetricRegistry.class);
	private static PlotEditService plotEditService = mock(PlotEditService.class);
	private static DeclarationService declarationService = mock(DeclarationService.class);
	private static SyncJobConsumer syncJobConsumer = mock(SyncJobConsumer.class);

	@SuppressWarnings("unchecked")
	private static  AbstractWorkQueue<CropPlanCommitPayload, ?> msgQueue = mock(AbstractWorkQueue.class);

	private static ValidatorService validatorService = mock(ValidatorService.class);
	private static PluginManager pluginManager = mock(PluginManager.class);
	private static SyncPlugin syncPlugin = mock(SyncPlugin.class);

	private static CropPlansDAO cropPlansDAO = mock(CropPlansDAO.class);
	private static CropPlanConfigDAO cropPlanConfigDAO = mock(CropPlanConfigDAO.class);
	private static SyncDAO syncDAO = mock(SyncDAO.class);
	SecurityContext securityContext = mock(SecurityContext.class);

	LocalDate oldestChangesDate;
	private static final LocalDate DEFAULT_DAY_FROM = LocalDate.of(2023, 1, 1);
	AbsoluteDate pointInTime;
	RuntimeEnvironment env = mock(RuntimeEnvironment.class);
	User user = mock(User.class);
	LocalDateTime currentDt = LocalDateTime.now();


	private WKTReader wktReader = new WKTReader();

	@BeforeEach
	public void init() throws IOException, AuthenticationException {
		var envFactory = mock(EnvironmentFactory.class);
		when(baseService.getEnvironmentFactory())
				.thenReturn(envFactory);
		
		when(envFactory.create(any(), any()))
				.thenReturn(env);
		when(env.getTenantId())
				.thenReturn("vine");
		when(environment.metrics())
		.thenReturn(new MetricRegistry());
		when(cropPlanService.getCropPlan(any(), any(), anyLong()))
		.thenReturn(new CropPlan());
		
		when(pluginManager.getSyncPlugin(any(), anyLong(), any()))
		.thenReturn(syncPlugin);
		
		when(syncPlugin.getSyncPluginDate(any()))
		.thenReturn(currentDt);
		
		String inProgress = null;
		when(syncDAO.getSyncProgress(anyLong(), any()))
		.thenReturn(inProgress);
		
		Boolean crplPlanHasErrors = false;
		when( syncDAO.hasErrors(anyLong()))
		.thenReturn(crplPlanHasErrors);
		
		Long cropPlanTypeId = 1L;
		
		when(cropPlanConfigDAO.getCropPlanTypeId(any(), any()))
				.thenReturn(cropPlanTypeId);
		
		oldestChangesDate = DEFAULT_DAY_FROM;
		
		when(syncPlugin.getOldestChangesDateFromLpisDate(any(), any(), anyLong(), any(), any(), anyBoolean()))
		.thenReturn(oldestChangesDate);
		
		int numRecords = 1;
		
		when(syncDAO.setSyncInProgress(anyLong(), any(),  any(), any()))
		.thenReturn(numRecords);
		
		when(configuration.isDevMode())
		.thenReturn(true);
		user = new User("Tester");
		when(sso2Client.createSecurityContextFromUserName(any(),any()))
				.thenReturn(securityContext);
		when(securityContext.getUserPrincipal())
		.thenReturn(user);
		
		DAOContainer daoContainer = DAOContainer.builder()
				.cropPlansDAO(cropPlansDAO)
				.cropPlanConfigDAO(cropPlanConfigDAO)
				.syncDAO(syncDAO)
				.build();

		syncService = new SyncService(cropPlanService, cropPlanConfigService, syncJobConsumer,
				daoContainer, pluginManager, configuration);
		syncServiceMock = syncService;
		
		//doNothing().when(syncService).recalcAnomalies(any(),any(),anyLong(),any());
		doNothing().when(syncDAO).insertSync(anyLong(),any(),any(),any());
		doNothing().when(syncDAO).setSetSyncStop(anyLong());
		doNothing().when(plotEditService).deletePlotWithoutValidation(any(),any(),any(),any());
		doNothing().when(plotEditService).deletePlotWithoutValidation(any(),any(),any(),any());
		
	}

	@Test
	public void whenGetPlotDisabledFunctionsConfig_thenReturnAllScenarioConfig() throws ParseException {
		
		
		
		//----------------------------------------------------------------------------------------------------
		String businessId = "MNGNGL73T01F499H";
		Long cropPlanId = 1L;
		Long cropPlanTypeId = 1L;
		String parcelACode = "parcelCode1";
		LocalDateTime currentDt = LocalDateTime.now();
		LocalDateTime lastSyncDt = currentDt.minusDays(10);
		LocalDateTime syncPluginDt = lastSyncDt;
		List<String> domainZoneIds = new ArrayList<>();
		String domainZoneId = "A";
		domainZoneIds.add(domainZoneId);
		when(syncDAO.getPlotsDomainZoneIds(anyLong(), any()))
		.thenReturn(domainZoneIds);
		
		when(syncDAO.getCurrentTimestamp())
			.thenReturn(currentDt);
		
		List<SyncPlot> plotList = new ArrayList<>();
		SyncPlot plot = new SyncPlot();
		plot.setPlotId(1L);
		plot.setPlotCode("plotTest1");
		var geom = (Polygon) wktReader.read("POLYGON ((430 450, 370 350, 470 340, 550 410, 520 490, 430 450))");
		plot.setGeom(geom);
		plot.setSrs("srs");
		List<String> parcelCodes = new ArrayList<>();
		parcelCodes.add(parcelACode);
		plot.setParcelCodes(parcelCodes);
		AbsoluteDate fromDate = AbsoluteDate.of("20220505");
		plot.setFromDate(fromDate);
		AbsoluteDate toDate = AbsoluteDate.of("20230505");
		plot.setToDate(toDate);
		plotList.add(plot);
		
		when(syncDAO.getPlots(anyLong(), any(), any())).thenReturn(plotList);
		
		Map<Long, List<ParcelIntersection>> parcelsIntersectionByPlotId = new HashMap<Long, List<ParcelIntersection>>();
		
		when(cropPlanService.getCropPlanServiceUtils().loadParcelsIntersectionByPlotId(any(), anyLong(), any(), any(), any()))
		.thenReturn(parcelsIntersectionByPlotId);
		
		List<SyncParcel> parcels = new ArrayList<SyncParcel>();
		SyncParcel parcel = new SyncParcel();
		String defaultLandUse = "00001";
		String plotNameToBeAssigned = "parcelA";
		parcel.setCode(parcelACode);
		parcel.setDefaultLandUse(defaultLandUse);
		parcel.setDomainZoneId(domainZoneId);
		parcel.setGeom(geom);
		parcel.setPlotNameToBeAssigned(plotNameToBeAssigned);
		
		parcels.add(parcel);
		
		when(syncPlugin.getLpisParcelsForPlotAlign(env, domainZoneId, pointInTime.toLocalDate(), plot.getGeom(), plot.getSrs()))
		.thenReturn(parcels);
		
		List<Declaration> declarationList = new ArrayList<>();
		Declaration declaration = new Declaration();
		Double areaPerc = 100.0;
		String declCode = "declA_1";
		declaration.setAreaPerc(areaPerc);
		declaration.setDeclCode(declCode);
		
		
		declarationList.add(declaration);
		
		when(cropPlanDeclarationsService.getPlotDeclarations(any(), any(), anyLong(), any(), any(), any(), any(), any()))
		.thenReturn(declarationList);
		//TODO: arrivato all'analisi alla riga 609 della classe SyncService : var result = plotEditService.createPlotWithoutValidation(env, params, payload, null, true);
		//capire come proseguire e terminare il test
//		EditorResult<String> plotWithoutValidation = editor.insertPolygon((Polygonal) payload.getGeom(), removeUndefinedSpace);
//		
//		plotWithoutValidation.setCreatedParent(plotNameToBeAssigned, declCode);
//		
//		when(plotEditService.createPlotWithoutValidation(any(), any(), any(), any(), any()))
//		.thenReturn(plotWithoutValidation);
		
		boolean ignoreDefaults = true;
		boolean ignorePreviousSyncs = true;
		
		SyncStatus syncStatus = syncService.syncCropPlan(env, businessId, cropPlanId, SyncType.PLOT_ALIGN, null, ignoreDefaults, ignorePreviousSyncs);
		
		
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<SyncStatus>> violations = validator.validate(syncStatus);
		assertEquals(violations.size(), 0);
	}
	
	

	

}
