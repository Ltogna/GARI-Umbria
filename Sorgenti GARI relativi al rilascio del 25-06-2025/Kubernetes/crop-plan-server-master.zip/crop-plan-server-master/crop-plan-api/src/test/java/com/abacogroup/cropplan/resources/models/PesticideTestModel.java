package com.abacogroup.cropplan.resources.models;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class PesticideTestModel
{
	@NotNull
	private String productName;

	@NotNull
	private String productCode;
	
	@NotNull
	private String  plantProtectionProductType;

	@NotNull
	private Long activeSubstanceConcentrationAmount;

	@NotNull
	private String activeSubstanceConcentrationAmountUom;
	
	@Valid
	@NotNull
	private UomTypeTestModel uomType;
}
