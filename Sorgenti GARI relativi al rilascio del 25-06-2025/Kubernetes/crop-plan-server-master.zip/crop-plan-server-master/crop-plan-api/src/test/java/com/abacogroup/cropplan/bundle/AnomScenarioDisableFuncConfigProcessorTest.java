package com.abacogroup.cropplan.bundle;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.abacogroup.cropplan.api.DisabledFunctionCode;
import com.abacogroup.cropplan.bundle.model.AnomScenarioDisableFuncConfigDefinition;
import com.abacogroup.cropplan.bundle.model.AnomScenarioDisableFuncConfigMessage;
import com.abacogroup.cropplan.bundle.model.FunctionsDisabledConfig;
import com.abacogroup.cropplan.bundle.model.ScenarioAnomaliesConfig;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.ntt.FunctionDisableConfig;
import com.abacogroup.jdbi.OraJdbiPlugin;
import java.util.ArrayList;
import java.util.List;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.sqlobject.SqlObjectPlugin;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Disabled("NB: Manual test. Needed a local postgresql Database instance of crop-plan")
public class AnomScenarioDisableFuncConfigProcessorTest {
	private static final Logger log = LoggerFactory.getLogger(AnomScenarioDisableFuncConfigProcessorTest.class);
	private CropPlanConfigDAO crplConfigDAO;
	private CropPlanConfigDAO configDAOReal;
	private String scenarioConfig_ADD_DECLARATIONS = "001-Test";
	private String scenarioConfig_CUT_PLOTS = "002-Test";
	private String scenarioConfig_DELETE_DECLARATIONS = "003-Test";
	private String scenarioConfig_DELETE_PLOTS = "004-Test";
	private String scenarioConfig_EDIT_DECLARATIONS = "005-Test";
	private String scenarioConfig_EDIT_PLOTS = "006-Test";
	private String scenarioConfig_MERGE_DECLARATIONS = "007-Test";
	private String scenarioConfig_REPROPORTION_DECLARATIONS = "008-Test";
	private String anomalyScenarioConfig_ADD_DECLARATIONS = "AN-001";
	private String anomalyScenarioConfig_CUT_PLOTS = "002-Test";
	private String anomalyScenarioConfig_DELETE_DECLARATIONS = "003-Test";
	private String anomalyScenarioConfig_DELETE_PLOTS = "004-Test";
	private String anomalyScenarioConfig_EDIT_DECLARATIONS = "005-Test";
	private String anomalyScenarioConfig_EDIT_PLOTS = "006-Test";
	private String anomalyScenarioConfig_MERGE_DECLARATIONS = "007-Test";
	private String anomalyScenarioConfig_REPROPORTION_DECLARATIONS = "008-Test";
	Long typeId = 0L;
	
	@BeforeEach
	public void init() {
		crplConfigDAO = mock(CropPlanConfigDAO.class);
		
		when(crplConfigDAO.getScenarioDisabledFunctionConfig(
						ArgumentMatchers.anyLong(),
						ArgumentMatchers.eq(DisabledFunctionCode.ADD_DECLARATIONS.toString()),
						ArgumentMatchers.eq(scenarioConfig_ADD_DECLARATIONS)))
		.thenReturn(List.of(new FunctionDisableConfig(scenarioConfig_ADD_DECLARATIONS,DisabledFunctionCode.ADD_DECLARATIONS.toString(),anomalyScenarioConfig_ADD_DECLARATIONS,Boolean.TRUE)));
		
		when(crplConfigDAO.getScenarioDisabledFunctionConfig(
						ArgumentMatchers.anyLong(),
						ArgumentMatchers.eq(DisabledFunctionCode.CUT_PLOTS.toString()),
						ArgumentMatchers.eq(scenarioConfig_CUT_PLOTS)))
		.thenReturn(List.of(new FunctionDisableConfig(scenarioConfig_CUT_PLOTS,DisabledFunctionCode.CUT_PLOTS.toString(),anomalyScenarioConfig_CUT_PLOTS,Boolean.TRUE)));
		
		when(crplConfigDAO.getScenarioDisabledFunctionConfig(
						ArgumentMatchers.anyLong(),
						ArgumentMatchers.eq(DisabledFunctionCode.DELETE_DECLARATIONS.toString()),
						ArgumentMatchers.eq(scenarioConfig_DELETE_DECLARATIONS)))
		.thenReturn(List.of(new FunctionDisableConfig(scenarioConfig_DELETE_DECLARATIONS,DisabledFunctionCode.DELETE_DECLARATIONS.toString(),anomalyScenarioConfig_DELETE_DECLARATIONS,Boolean.TRUE)));
		
		when(crplConfigDAO.getScenarioDisabledFunctionConfig(
						ArgumentMatchers.anyLong(),
						ArgumentMatchers.eq(DisabledFunctionCode.DELETE_PLOTS.toString()),
						ArgumentMatchers.eq(scenarioConfig_DELETE_PLOTS)))
		.thenReturn(List.of(new FunctionDisableConfig(scenarioConfig_DELETE_PLOTS,DisabledFunctionCode.DELETE_PLOTS.toString(),anomalyScenarioConfig_DELETE_PLOTS,Boolean.TRUE)));
		
		when(crplConfigDAO.getScenarioDisabledFunctionConfig(
						ArgumentMatchers.anyLong(),
						ArgumentMatchers.eq(DisabledFunctionCode.EDIT_DECLARATIONS.toString()),
						ArgumentMatchers.eq(scenarioConfig_EDIT_DECLARATIONS)))
		.thenReturn(List.of(new FunctionDisableConfig(scenarioConfig_EDIT_DECLARATIONS,DisabledFunctionCode.EDIT_DECLARATIONS.toString(),anomalyScenarioConfig_EDIT_DECLARATIONS,Boolean.TRUE)));
		
		when(crplConfigDAO.getScenarioDisabledFunctionConfig(
						ArgumentMatchers.anyLong(),
						ArgumentMatchers.eq(DisabledFunctionCode.EDIT_PLOTS.toString()),
						ArgumentMatchers.eq(scenarioConfig_EDIT_PLOTS)))
		.thenReturn(List.of(new FunctionDisableConfig(scenarioConfig_EDIT_PLOTS,DisabledFunctionCode.EDIT_PLOTS.toString(),anomalyScenarioConfig_EDIT_PLOTS,Boolean.TRUE)));
		
		when(crplConfigDAO.getScenarioDisabledFunctionConfig(
						ArgumentMatchers.anyLong(),
						ArgumentMatchers.eq(DisabledFunctionCode.MERGE_DECLARATIONS.toString()),
						ArgumentMatchers.eq(scenarioConfig_MERGE_DECLARATIONS)))
		.thenReturn(List.of(new FunctionDisableConfig(scenarioConfig_MERGE_DECLARATIONS,DisabledFunctionCode.MERGE_DECLARATIONS.toString(),anomalyScenarioConfig_MERGE_DECLARATIONS,Boolean.TRUE)));
		
		when(crplConfigDAO.getScenarioDisabledFunctionConfig(
						ArgumentMatchers.anyLong(),
						ArgumentMatchers.eq(DisabledFunctionCode.REPROPORTION_DECLARATIONS.toString()),
						ArgumentMatchers.eq(scenarioConfig_REPROPORTION_DECLARATIONS)))
		.thenReturn(List.of(new FunctionDisableConfig(scenarioConfig_REPROPORTION_DECLARATIONS,DisabledFunctionCode.REPROPORTION_DECLARATIONS.toString(),anomalyScenarioConfig_REPROPORTION_DECLARATIONS,Boolean.TRUE)));
		
		
		when(crplConfigDAO.getCropPlanTypeId(ArgumentMatchers.anyString(), ArgumentMatchers.anyString()))
		.thenReturn(typeId);
		String url = "jdbc:postgresql://localhost:5432/cropplan";
	    String user = "cropplan";
	    String password = "cropplan_pwd";
		Jdbi jdbiCrplPlan = Jdbi.create(url, user, password);
		jdbiCrplPlan.installPlugin(new SqlObjectPlugin());
		
		jdbiCrplPlan.installPlugin(new OraJdbiPlugin());
		configDAOReal = jdbiCrplPlan.onDemand(CropPlanConfigDAO.class);
	}

	@Test
	public void whenSetScenario_thenReturnScenarioAdded() {
		String cropPlanType = "CROPPLAN";
		String tenantId = "_";
		AnomScenarioDisableFuncConfigMessage message = new AnomScenarioDisableFuncConfigMessage();
		message.setCropPlanType(cropPlanType); //TODO : ??????
		AnomScenarioDisableFuncConfigDefinition scenarioConfig = new AnomScenarioDisableFuncConfigDefinition();
		scenarioConfig.setScenario(scenarioConfig_ADD_DECLARATIONS);
		scenarioConfig.setFunctionsDisabledConfig(List.of(new FunctionsDisabledConfig(DisabledFunctionCode.ADD_DECLARATIONS.toString())));
		scenarioConfig.setScenarioAnomaliesConfig(List.of(new ScenarioAnomaliesConfig(anomalyScenarioConfig_ADD_DECLARATIONS,Boolean.TRUE)));
		List<AnomScenarioDisableFuncConfigDefinition> listOfscenarioConfig = new ArrayList<>();
		listOfscenarioConfig.add(scenarioConfig);
		message.setAnomScenarioConfig(listOfscenarioConfig);
		
		AnomScenarioDisableFuncConfigProcessor anomScenarioDisableFuncConfigProcessor = new AnomScenarioDisableFuncConfigProcessor(
				configDAOReal);
		
		anomScenarioDisableFuncConfigProcessor.doInsertOrUpdate(tenantId, message);
		
		log.info("get Scenario Disabled Function Config typeId:" + typeId +" - functionCode:"+ DisabledFunctionCode.ADD_DECLARATIONS.toString() +" - Scenario:"+ scenarioConfig.getScenario());
		var result = configDAOReal.getScenarioDisabledFunctionConfig(typeId,DisabledFunctionCode.ADD_DECLARATIONS.toString(),scenarioConfig_ADD_DECLARATIONS);
		assertNotNull(result);
		assertNotEquals(0, result.size());
		
		var anomalySenarioConfig = configDAOReal.getAnomalyScenarioConfig(typeId,anomalyScenarioConfig_ADD_DECLARATIONS,scenarioConfig_ADD_DECLARATIONS);
		assertNotNull(anomalySenarioConfig);
		assertNotEquals(0, anomalySenarioConfig.size());
		
		anomScenarioDisableFuncConfigProcessor.doDelete(tenantId, message);
		
		var resultDelete = configDAOReal.getScenarioDisabledFunctionConfig(typeId,DisabledFunctionCode.ADD_DECLARATIONS.toString(),scenarioConfig_ADD_DECLARATIONS);
		assertNotNull(resultDelete);
		assertEquals(0,resultDelete.size());
		
		var anomalyResultDelete = configDAOReal.getAnomalyScenarioConfig(typeId,anomalyScenarioConfig_ADD_DECLARATIONS,scenarioConfig_ADD_DECLARATIONS);
		assertNotNull(anomalyResultDelete);
		assertEquals(0, anomalyResultDelete.size());
	}

}
