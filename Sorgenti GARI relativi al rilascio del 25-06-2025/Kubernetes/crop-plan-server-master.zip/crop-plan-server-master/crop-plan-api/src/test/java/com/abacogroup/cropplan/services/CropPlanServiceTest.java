package com.abacogroup.cropplan.services;

import static com.abacogroup.cropplan.sdk.model.config.CropPlanConfigParam.CONSTRAINTS_DECLS_TO_PLOTS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.assertj.core.api.Assertions;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;
import org.mockito.Spy;

import com.abacogroup.cropplan.CropPlanConfiguration;
import com.abacogroup.cropplan.RuntimeEnvironmentImpl;
import com.abacogroup.cropplan.api.CropPlanType;
import com.abacogroup.cropplan.api.DisabledFunctionCode;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.SubdomainZoneResponse;
import com.abacogroup.cropplan.api.payload.CopyDeclarationsFromSourceYearPayload;
import com.abacogroup.cropplan.api.payload.CreateVersionPayload;
import com.abacogroup.cropplan.api.payload.InsertPermanentCropForm;
import com.abacogroup.cropplan.api.payload.SubdomainZoneRequest;
import com.abacogroup.cropplan.bundle.model.AnomScenarioDisableFuncConfigDefinition;
import com.abacogroup.cropplan.bundle.model.FunctionsDisabledConfig;
import com.abacogroup.cropplan.bundle.model.ScenarioAnomaliesConfig;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDeleteAndRestoreOperationsDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.db.dao.SubdomainZoneDAO;
import com.abacogroup.cropplan.db.dao.SyncDAO;
import com.abacogroup.cropplan.db.dao.ValidatorDAO;
import com.abacogroup.cropplan.db.dao.ntt.DeclarationWithPlotCode;
import com.abacogroup.cropplan.db.dao.ntt.FunctionDisableConfig;
import com.abacogroup.cropplan.db.dao.ntt.ScenarioAnomaliesDisableFunctionsConfigurations;
import com.abacogroup.cropplan.dispatch.CropPlanCommitJob;
import com.abacogroup.cropplan.exceptions.SubdomainZoneException;
import com.abacogroup.cropplan.exceptions.SubdomainZoneException.ErrEnum;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.CropPlanVersion;
import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.PermanentCropForm;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormData;
import com.abacogroup.cropplan.sdk.model.Version;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandCoverClassEditability;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.sync.LatestSync;
import com.abacogroup.cropplan.sdk.model.sync.SyncType;
import com.abacogroup.cropplan.sdk.spi.CropCodesPlugin;
import com.abacogroup.cropplan.sdk.spi.ValidatorPlugin;
import com.abacogroup.cropplan.services.utils.CropPlanServiceUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.embeddedqueue.AbstractWorkQueue;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.plugins.impl.EnvironmentFactory;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.codahale.metrics.MetricRegistry;

import io.dropwizard.core.setup.Environment;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.ws.rs.BadRequestException;

@ExtendWith(DropwizardExtensionsSupport.class)
public class CropPlanServiceTest {
	//	private static CropPlanService cropPlanServiceMock = mock(CropPlanService.class);
	private CropPlanService cropPlanService;
	@Spy
	private CropPlanService cropPlanServiceMock;

	private final CropPlanConfiguration configuration = mock(CropPlanConfiguration.class);
	private final Sso2Client sso2Client = mock(Sso2Client.class);
	private final Environment environment = mock(Environment.class);
	private final Jdbi jdbi = mock(Jdbi.class);

	private final BaseService baseService = mock(BaseService.class);
	private final CropPlanDeclarationsService cropPlanDeclarationsService = mock(CropPlanDeclarationsService.class);
	private final CropPlanConfigService cropPlanConfigService = mock(CropPlanConfigService.class);
	private final CropCodeService cropCodeService = mock(CropCodeService.class);

	@SuppressWarnings("unchecked")
	private final AbstractWorkQueue<CropPlanCommitJob, ?> msgQueue = mock(AbstractWorkQueue.class);

	private final ValidatorService validatorService = mock(ValidatorService.class);
	private final PluginManager pluginManager = mock(PluginManager.class);

	private final CropPlansDAO cropPlansDAO = mock(CropPlansDAO.class);
	private final CropPlanConfigDAO crplConfigDAO = mock(CropPlanConfigDAO.class);
	private final CropPlansDeleteAndRestoreOperationsDAO cropPlansDeleteAndRestoreOperationsDAO = mock(CropPlansDeleteAndRestoreOperationsDAO.class);
	private final ValidatorDAO validatorDAO = mock(ValidatorDAO.class);
	private final SyncDAO syncDAO = mock(SyncDAO.class);
	private final DeclarationsDAO declarationsDAO = mock(DeclarationsDAO.class);
	private final SubdomainZoneDAO subdomainZoneDAO = mock(SubdomainZoneDAO.class);

	private final ValidatorPlugin validatorPlugin = mock(ValidatorPlugin.class);

	private WKTReader reader;

	@BeforeEach
	public void init() throws IOException {
		var envFactory = mock(EnvironmentFactory.class);
		when(baseService.getEnvironmentFactory())
				.thenReturn(envFactory);
		var env = mock(RuntimeEnvironment.class);
		when(envFactory.create(any(), any()))
				.thenReturn(env);
		when(env.getTenantId())
				.thenReturn("vine");
		when(environment.metrics())
				.thenReturn(new MetricRegistry());

		DAOContainer daoContainer = DAOContainer.builder()
				.cropPlansDAO(cropPlansDAO)
				.cropPlanConfigDAO(crplConfigDAO)
				.cropPlansDeleteAndRestoreOperationsDAO(cropPlansDeleteAndRestoreOperationsDAO)
				.validatorDAO(validatorDAO)
				.syncDAO(syncDAO)
				.declarationsDAO(declarationsDAO)
				.subdomainZoneDAO(subdomainZoneDAO)
				.build();

		given(configuration.isDevMode()).willReturn(true);

		cropPlanService = new CropPlanService(sso2Client, environment.metrics(), jdbi, baseService, cropPlanDeclarationsService, cropPlanConfigService,
				validatorService, cropCodeService, daoContainer, pluginManager, msgQueue, configuration);
		cropPlanServiceMock = spy(cropPlanService);

		reader = new WKTReader();
	}

	@Test
	public void whenGetPlotDisabledFunctionsConfig_thenReturnAllScenarioConfig() {

		FunctionDisableConfig functionDisableConfig1 = new FunctionDisableConfig();
		FunctionDisableConfig functionDisableConfig2 = new FunctionDisableConfig();
		String scenario = "ScenarioTest1";
		String functionCode = "ADD_DECLARATIONS";
		String anomaliyCode1 = "SV01";
		String anomaliyCode2 = "SV02";
		Boolean anomaliyPresent1 = true;
		Boolean anomaliyPresent2 = false;

		functionDisableConfig1.setScenario(scenario);
		functionDisableConfig1.setAnomaliyCode(anomaliyCode1);
		functionDisableConfig1.setFunctionCode(functionCode);
		functionDisableConfig1.setAnomaliyPresent(anomaliyPresent1);

		functionDisableConfig2.setScenario(scenario);
		functionDisableConfig2.setAnomaliyCode(anomaliyCode2);
		functionDisableConfig2.setFunctionCode(functionCode);
		functionDisableConfig2.setAnomaliyPresent(anomaliyPresent2);

		List<FunctionDisableConfig> disableAnomailesCodesList = new ArrayList<>();
		disableAnomailesCodesList.add(functionDisableConfig1);
		disableAnomailesCodesList.add(functionDisableConfig2);

		ScenarioAnomaliesDisableFunctionsConfigurations scenarioAnomaliesDisableFunctionsConfigurations = new ScenarioAnomaliesDisableFunctionsConfigurations();
		List<AnomScenarioDisableFuncConfigDefinition> anomScenarioConfig = new ArrayList<>();
		AnomScenarioDisableFuncConfigDefinition anomScenarioDisableFuncConfigDefinition = new AnomScenarioDisableFuncConfigDefinition();
		anomScenarioConfig.add(anomScenarioDisableFuncConfigDefinition);
		scenarioAnomaliesDisableFunctionsConfigurations.setAnomScenarioConfig(anomScenarioConfig);

		Long cropPlanTypeId = 1L;

		when(crplConfigDAO.getCropPlanTypeId(any(), any()))
				.thenReturn(cropPlanTypeId);

		when(crplConfigDAO.getScenarioAnomailesDisableFunctionConfig(any(), any()))
				.thenReturn(disableAnomailesCodesList);

		var env = mock(RuntimeEnvironment.class);

		DisabledFunctionCode disabledFunctionCode = null;

		var res = cropPlanServiceMock.getPlotDisabledFunctionsConfig(disabledFunctionCode, env, "1", 1L);

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<ScenarioAnomaliesDisableFunctionsConfigurations>> violations = validator.validate(res);
		assertEquals(violations.size(), 0);
	}

	@Test
	public void whenGetPlotDisabledFunctionsConfig_thenReturnAllScenarioWithOneAnomalyConfigForEachFunction() {

		List<FunctionDisableConfig> disableAnomailesCodesList = getDisableAnomailesCodesList();

		Long cropPlanTypeId = 1L;

		when(crplConfigDAO.getCropPlanTypeId(any(), any()))
				.thenReturn(cropPlanTypeId);

		when(crplConfigDAO.getScenarioAnomailesDisableFunctionConfig(any(), any()))
				.thenReturn(disableAnomailesCodesList);

		var env = mock(RuntimeEnvironment.class);

		DisabledFunctionCode disabledFunctionCode = null;

		var res = cropPlanServiceMock.getPlotDisabledFunctionsConfig(disabledFunctionCode, env, "1", 1L);

		if (res != null && res.getAnomScenarioConfig().size() > 0) {

			res.getAnomScenarioConfig().stream().forEach(scenario -> {
				//String scenarioId = scenario.getScenario();

				scenario.getFunctionsDisabledConfig();

				Map<String, Long> statisticFunctions = scenario.getFunctionsDisabledConfig().stream()
						.collect(Collectors.groupingByConcurrent(FunctionsDisabledConfig::getFunctionCode, Collectors.counting()));

				for (String functionCode : statisticFunctions.keySet()) {
					Long numOfFunctionCode = statisticFunctions.get(functionCode);
					assertEquals(numOfFunctionCode, 1L);
				}

				scenario.getScenarioAnomaliesConfig();

				Map<String, Long> statisticAnomaly = scenario.getScenarioAnomaliesConfig().stream()
						.collect(Collectors.groupingByConcurrent(ScenarioAnomaliesConfig::getAnomaliyCode, Collectors.counting()));

				for (String anomaliyCode : statisticAnomaly.keySet()) {
					Long numOfAnomaliesConfig = statisticAnomaly.get(anomaliyCode);
					assertEquals(numOfAnomaliesConfig, 1L);
				}
			});
		}

	}

	// ----- newCopyDeclarationsFromPreviousYear -----
	@Test
	void test_newCopyDeclarationsFromPreviousYear_ok() throws ParseException, NoSuchFieldException, IllegalAccessException {

		Field cropPlanServiceUtilsField = CropPlanService.class.getDeclaredField("cropPlanServiceUtils");
		cropPlanServiceUtilsField.setAccessible(true);
		CropPlanServiceUtils cropPlanServiceUtilsMock = mock(CropPlanServiceUtils.class);
		cropPlanServiceUtilsField.set(cropPlanService, cropPlanServiceUtilsMock);

		var env = mock(RuntimeEnvironment.class);
		String user = "MOCK_USER";
		given(env.getUserId()).willReturn(user);
		given(env.getTenantId()).willReturn("TTTT");

		String businessId = "555";
		long cropPlanId = 123L;
		boolean forceNotCompatibleLandCover = false;
		AbsoluteDate pointInTime = AbsoluteDate.of("20240515");
		LocalDateTime currentDt = LocalDateTime.of(2024, Month.MARCH, 11, 16, 9);
		LocalDateTime versionDt = LocalDateTime.of(2024, Month.JANUARY, 12, 15, 31);
		CopyDeclarationsFromSourceYearPayload payload = new CopyDeclarationsFromSourceYearPayload(new Version(versionDt));

		given(crplConfigDAO.getCropPlanConfig(anyLong(), eq(CONSTRAINTS_DECLS_TO_PLOTS.toString()), anyString())).willReturn(List.of());
		given(cropPlansDAO.getCurrentTimestamp()).willReturn(currentDt);
		doAnswer(i -> {
			((TransactionalConsumer<CropPlansDAO, ?>) i.getArgument(0)).useTransaction(cropPlansDAO);
			return null;
		}).when(cropPlansDAO).useTransaction(any());
		//pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId()); cropCodesPlugin.getLandCoverEditability(env, businessId, parcel.getLandCoverCode());
		CropCodesPlugin cropCodesPlugin = mock(CropCodesPlugin.class);
		given(pluginManager.getCropCodesPlugin(any(), any(), any())).willReturn(cropCodesPlugin);
		given(cropCodesPlugin.getLandCoverEditability(any(), any(), any())).willReturn(LandCoverClassEditability.EDITABLE);

		// current plots //
		WKTReader reader = new WKTReader();
		Plot plot1 = Plot.builder()
				.plotCode("12301")
				.parcelIntersections(List.of(givenParcelIntersection("PCL123001", "LC01")))
				.geom(reader.read("POLYGON ((000 100, 100 100, 100 000, 000 000, 000 100))"))
				.fromDate(AbsoluteDate.of("20240101"))
				.toDate(AbsoluteDate.of("99991231"))
				.build();
		// current decls in plot1
		DeclarationWithPlotCode decl1Plot1 = DeclarationWithPlotCode.builder()
				.fromDate(AbsoluteDate.of("20240101"))
				.toDate(AbsoluteDate.of("20240229"))
				.build();
		given(declarationsDAO.getPlotsDeclarationsInternal(anyLong(), eq(List.of(plot1.getPlotCode())), any(), any(), any()))
				.willReturn(List.of(decl1Plot1));
		// prev plots in plot1
		Plot plot1Old1 = Plot.builder()
				.geom(reader.read("POLYGON ((-100 100, 20 100, 20 0, -100 0, -100 100))"))
				.build();
		PermanentCropFormData pcfDataDecl1Plot1Old2 = PermanentCropFormData.builder().bio("YES").build();
		List<LandUseAdditionalDataField> adfListDecl1Plot1Old2 = List.of(
				LandUseAdditionalDataField.builder().fieldCode("FOO").value("BAR").build()
		);
		Plot plot1Old2 = Plot.builder()
				.plotCode("12321")
				.geom(reader.read("POLYGON ((20 100, 100 100, 100 -20, 20 -20, 20 100))"))
				.decls(List.of(
						Declaration.builder()
								.declCode("12321001")
								.landuse(new LandUse("LUC0101", ""))
								.fromDate(AbsoluteDate.of("20230201"))
								.fromDatePrecision("YMD")
								.toDate(AbsoluteDate.of("20230930"))
								.areaPerc(99.)
								.permanentCropForms(List.of(
										PermanentCropForm.builder().formCode("12321001").formType("TEST")
												.permanentCropFormData(pcfDataDecl1Plot1Old2).build()))
								.fieldsCodes(adfListDecl1Plot1Old2)
								.build()
				))
				.build();
		given(cropPlanServiceUtilsMock.getPlotsByIntersection(any(), anyString(), anyLong(), any(), eq(plot1.getGeom()),
				any(), any(), any(), any(), anyInt(), any(), anyBoolean()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(plot1Old1, plot1Old2), null));
		given(cropCodeService.isLandUseCompatible(any(), anyString(), anyLong(), eq("LUC0101"), eq("LC01"), anyBoolean())).willReturn(true);


		Plot plot3 = Plot.builder() // skipped, no intersections > 70%
				.parcelIntersections(List.of(givenParcelIntersection("PCL123002", "LC02")))
				.geom(reader.read("POLYGON ((200 100, 200 000, 100 000, 100 100, 200 100))"))
				.build();
		// prev plots in plot3
		Plot plot3Old1 = Plot.builder()
				.geom(reader.read("POLYGON ((100 100, 200 100, 200 50, 100 50, 100 100))"))
				.build();
		Plot plot3Old2 = Plot.builder()
				.geom(reader.read("POLYGON ((200 0, 100 0, 100 50, 200 50, 200 0))"))
				.build();
		given(cropPlanServiceUtilsMock.getPlotsByIntersection(any(), anyString(), anyLong(), any(), eq(plot3.getGeom()), any(), any(), any(), any(), anyInt(),
				any(), anyBoolean()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(plot3Old1, plot3Old2), null));


		Plot plot4 = Plot.builder()
				.plotCode("12304")
				.parcelIntersections(List.of(givenParcelIntersection("PCL123004", "LC04")))
				.geom(reader.read("POLYGON ((100 -100, 0 -100, 0 0, 100 0, 100 -100))"))
				.fromDate(AbsoluteDate.of("20240501")) // maggio
				.toDate(AbsoluteDate.of("99991231"))
				.build();
		// prev plots in plot1
		Plot plot4Old1 = Plot.builder()
				.plotCode("12314")
				.geom(reader.read("POLYGON ((100 -100, 0 -100, 0 -20, 100 -20, 100 -100))"))
				.decls(List.of(
						Declaration.builder()
								.declCode("12314001")
								.landuse(new LandUse("LUC0401", ""))
								.fromDate(AbsoluteDate.of("20230201"))
								.fromDatePrecision("YMD")
								.toDate(AbsoluteDate.of("20230531"))
								.areaPerc(50.)
								.build(),
						Declaration.builder() // skipped, landuse compatibility
								.declCode("12314002")
								.landuse(new LandUse("LUC0402", ""))
								.fromDate(AbsoluteDate.of("20230201"))
								.fromDatePrecision("YMD")
								.toDate(AbsoluteDate.of("20230930"))
								.areaPerc(50.)
								.build()
				))
				.build();
		given(cropPlanServiceUtilsMock.getPlotsByIntersection(any(), anyString(), anyLong(), any(), eq(plot4.getGeom()), any(), any(), any(), any(), anyInt(),
				any(), anyBoolean()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(plot1Old2, plot4Old1), null));
		given(cropCodeService.isLandUseCompatible(any(), anyString(), anyLong(), eq("LUC0401"), eq("LC04"), anyBoolean())).willReturn(true);
		given(cropCodeService.isLandUseCompatible(any(), anyString(), anyLong(), eq("LUC0402"), eq("LC04"), anyBoolean())).willReturn(false);

		given(cropPlanServiceUtilsMock.getPlotsWithNoDeclsInRange(any(RuntimeEnvironment.class), anyString(), anyLong(), any(), any(), any(), any(), any(), anyInt(), any()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(plot1, plot3, plot4), null));


		// tested
		cropPlanService.copyDeclarationsFromVersion(env, businessId, cropPlanId, true, forceNotCompatibleLandCover,
				pointInTime, AbsoluteDate.of(pointInTime.toLocalDate().minusYears(1)), payload);

		verify(cropPlansDAO).insertDeclaration(cropPlanId, "12301",
				AbsoluteDate.of("20240301"), "YMD", AbsoluteDate.of("20240930"),
				"LUC0101", 99., List.of(new InsertPermanentCropForm("TEST", pcfDataDecl1Plot1Old2)), adfListDecl1Plot1Old2, user, currentDt, currentDt);
		verify(cropPlansDAO).insertDeclaration(cropPlanId, "12304",
				AbsoluteDate.of("20240501"), "YMD", AbsoluteDate.of("20240531"),
				"LUC0401", 50., List.of(), List.of(), user, currentDt, currentDt);

	}

	private ParcelIntersection givenParcelIntersection(String parcelCode, String landCoverCode) {
		ParcelIntersection parcelIntersection = new ParcelIntersection();
		parcelIntersection.setParcelCode(parcelCode);
		parcelIntersection.setLandCoverCode(landCoverCode);
		return parcelIntersection;
	}

	/**
	 * @return
	 */
	private List<FunctionDisableConfig> getDisableAnomailesCodesList() {
		FunctionDisableConfig confScen1Func1Anom1 = new FunctionDisableConfig();
		FunctionDisableConfig confScen1Func1Anom2 = new FunctionDisableConfig();
		FunctionDisableConfig confScen1Func1Anom3 = new FunctionDisableConfig();
		FunctionDisableConfig confScen1Func1Anom4 = new FunctionDisableConfig();

		FunctionDisableConfig confScen1Func2Anom1 = new FunctionDisableConfig();
		FunctionDisableConfig confScen1Func2Anom2 = new FunctionDisableConfig();
		FunctionDisableConfig confScen1Func2Anom3 = new FunctionDisableConfig();
		FunctionDisableConfig confScen1Func2Anom4 = new FunctionDisableConfig();

		FunctionDisableConfig confScen1Func3Anom1 = new FunctionDisableConfig();
		FunctionDisableConfig confScen1Func3Anom2 = new FunctionDisableConfig();
		FunctionDisableConfig confScen1Func3Anom3 = new FunctionDisableConfig();
		FunctionDisableConfig confScen1Func3Anom4 = new FunctionDisableConfig();

		FunctionDisableConfig confScen1Func4Anom1 = new FunctionDisableConfig();
		FunctionDisableConfig confScen1Func4Anom2 = new FunctionDisableConfig();
		FunctionDisableConfig confScen1Func4Anom3 = new FunctionDisableConfig();
		FunctionDisableConfig confScen1Func4Anom4 = new FunctionDisableConfig();

		FunctionDisableConfig confScen2Func1Anom1 = new FunctionDisableConfig();
		FunctionDisableConfig confScen2Func1Anom2 = new FunctionDisableConfig();
		FunctionDisableConfig confScen2Func1Anom3 = new FunctionDisableConfig();
		FunctionDisableConfig confScen2Func1Anom4 = new FunctionDisableConfig();

		FunctionDisableConfig confScen2Func2Anom1 = new FunctionDisableConfig();
		FunctionDisableConfig confScen2Func2Anom2 = new FunctionDisableConfig();
		FunctionDisableConfig confScen2Func2Anom3 = new FunctionDisableConfig();
		FunctionDisableConfig confScen2Func2Anom4 = new FunctionDisableConfig();

		FunctionDisableConfig confScen2Func3Anom1 = new FunctionDisableConfig();
		FunctionDisableConfig confScen2Func3Anom2 = new FunctionDisableConfig();
		FunctionDisableConfig confScen2Func3Anom3 = new FunctionDisableConfig();
		FunctionDisableConfig confScen2Func3Anom4 = new FunctionDisableConfig();

		FunctionDisableConfig confScen2Func4Anom1 = new FunctionDisableConfig();
		FunctionDisableConfig confScen2Func4Anom2 = new FunctionDisableConfig();
		FunctionDisableConfig confScen2Func4Anom3 = new FunctionDisableConfig();
		FunctionDisableConfig confScen2Func4Anom4 = new FunctionDisableConfig();

		String scenario1 = "ScenarioTest1";
		String scenario2 = "ScenarioTest2";
		String functionCode1 = "ADD_DECLARATIONS";
		String functionCode2 = "DELETE_DECLARATIONS";
		String functionCode3 = "REPROPORTION_DECLARATIONS";
		String functionCode4 = "EDIT_DECLARATIONS";
		String anomaliyCode1 = "SV01";
		String anomaliyCode2 = "SV02";
		String anomaliyCode3 = "SV03";
		String anomaliyCode4 = "SV04";
		Boolean anomaliyPresentTrue = true;
		Boolean anomaliyPresentFalse = false;

		//-----------------------------ScenarioTest1----------------------------------------
		//-----------------------------functionCode1----------------------------------------
		confScen1Func1Anom1.setScenario(scenario1);
		confScen1Func1Anom1.setFunctionCode(functionCode1);
		confScen1Func1Anom1.setAnomaliyCode(anomaliyCode1);
		confScen1Func1Anom1.setAnomaliyPresent(anomaliyPresentTrue);

		confScen1Func1Anom2.setScenario(scenario1);
		confScen1Func1Anom2.setFunctionCode(functionCode1);
		confScen1Func1Anom2.setAnomaliyCode(anomaliyCode2);
		confScen1Func1Anom2.setAnomaliyPresent(anomaliyPresentFalse);

		confScen1Func1Anom3.setScenario(scenario1);
		confScen1Func1Anom3.setFunctionCode(functionCode1);
		confScen1Func1Anom3.setAnomaliyCode(anomaliyCode3);
		confScen1Func1Anom3.setAnomaliyPresent(anomaliyPresentFalse);

		confScen1Func1Anom4.setScenario(scenario1);
		confScen1Func1Anom4.setFunctionCode(functionCode1);
		confScen1Func1Anom4.setAnomaliyCode(anomaliyCode4);
		confScen1Func1Anom4.setAnomaliyPresent(anomaliyPresentFalse);
		//-----------------------------functionCode2----------------------------------------
		confScen1Func2Anom1.setScenario(scenario1);
		confScen1Func2Anom1.setFunctionCode(functionCode2);
		confScen1Func2Anom1.setAnomaliyCode(anomaliyCode1);
		confScen1Func2Anom1.setAnomaliyPresent(anomaliyPresentTrue);

		confScen1Func2Anom2.setScenario(scenario1);
		confScen1Func2Anom2.setFunctionCode(functionCode2);
		confScen1Func2Anom2.setAnomaliyCode(anomaliyCode2);
		confScen1Func2Anom2.setAnomaliyPresent(anomaliyPresentFalse);

		confScen1Func2Anom3.setScenario(scenario1);
		confScen1Func2Anom3.setFunctionCode(functionCode2);
		confScen1Func2Anom3.setAnomaliyCode(anomaliyCode3);
		confScen1Func2Anom3.setAnomaliyPresent(anomaliyPresentFalse);

		confScen1Func2Anom4.setScenario(scenario1);
		confScen1Func2Anom4.setFunctionCode(functionCode2);
		confScen1Func2Anom4.setAnomaliyCode(anomaliyCode4);
		confScen1Func2Anom4.setAnomaliyPresent(anomaliyPresentFalse);
		//-----------------------------functionCode3----------------------------------------
		confScen1Func3Anom1.setScenario(scenario1);
		confScen1Func3Anom1.setFunctionCode(functionCode3);
		confScen1Func3Anom1.setAnomaliyCode(anomaliyCode1);
		confScen1Func3Anom1.setAnomaliyPresent(anomaliyPresentTrue);

		confScen1Func3Anom2.setScenario(scenario1);
		confScen1Func3Anom2.setFunctionCode(functionCode3);
		confScen1Func3Anom2.setAnomaliyCode(anomaliyCode2);
		confScen1Func3Anom2.setAnomaliyPresent(anomaliyPresentFalse);

		confScen1Func3Anom3.setScenario(scenario1);
		confScen1Func3Anom3.setFunctionCode(functionCode3);
		confScen1Func3Anom3.setAnomaliyCode(anomaliyCode3);
		confScen1Func3Anom3.setAnomaliyPresent(anomaliyPresentFalse);

		confScen1Func3Anom4.setScenario(scenario1);
		confScen1Func3Anom4.setFunctionCode(functionCode3);
		confScen1Func3Anom4.setAnomaliyCode(anomaliyCode4);
		confScen1Func3Anom4.setAnomaliyPresent(anomaliyPresentFalse);
		//-----------------------------functionCode4----------------------------------------
		confScen1Func4Anom1.setScenario(scenario1);
		confScen1Func4Anom1.setFunctionCode(functionCode4);
		confScen1Func4Anom1.setAnomaliyCode(anomaliyCode1);
		confScen1Func4Anom1.setAnomaliyPresent(anomaliyPresentTrue);

		confScen1Func4Anom2.setScenario(scenario1);
		confScen1Func4Anom2.setFunctionCode(functionCode4);
		confScen1Func4Anom2.setAnomaliyCode(anomaliyCode2);
		confScen1Func4Anom2.setAnomaliyPresent(anomaliyPresentFalse);

		confScen1Func4Anom3.setScenario(scenario1);
		confScen1Func4Anom3.setFunctionCode(functionCode4);
		confScen1Func4Anom3.setAnomaliyCode(anomaliyCode3);
		confScen1Func4Anom3.setAnomaliyPresent(anomaliyPresentFalse);

		confScen1Func4Anom4.setScenario(scenario1);
		confScen1Func4Anom4.setFunctionCode(functionCode4);
		confScen1Func4Anom4.setAnomaliyCode(anomaliyCode4);
		confScen1Func4Anom4.setAnomaliyPresent(anomaliyPresentFalse);

		//-----------------------------ScenarioTest2----------------------------------------
		//-----------------------------functionCode1----------------------------------------
		confScen2Func1Anom1.setScenario(scenario2);
		confScen2Func1Anom1.setFunctionCode(functionCode1);
		confScen2Func1Anom1.setAnomaliyCode(anomaliyCode1);
		confScen2Func1Anom1.setAnomaliyPresent(anomaliyPresentFalse);

		confScen2Func1Anom2.setScenario(scenario2);
		confScen2Func1Anom2.setFunctionCode(functionCode1);
		confScen2Func1Anom2.setAnomaliyCode(anomaliyCode2);
		confScen2Func1Anom2.setAnomaliyPresent(anomaliyPresentTrue);

		confScen2Func1Anom3.setScenario(scenario2);
		confScen2Func1Anom3.setFunctionCode(functionCode1);
		confScen2Func1Anom3.setAnomaliyCode(anomaliyCode3);
		confScen2Func1Anom3.setAnomaliyPresent(anomaliyPresentFalse);

		confScen2Func1Anom4.setScenario(scenario2);
		confScen2Func1Anom4.setFunctionCode(functionCode1);
		confScen2Func1Anom4.setAnomaliyCode(anomaliyCode4);
		confScen2Func1Anom4.setAnomaliyPresent(anomaliyPresentFalse);
		//-----------------------------functionCode2----------------------------------------
		confScen2Func2Anom1.setScenario(scenario2);
		confScen2Func2Anom1.setFunctionCode(functionCode2);
		confScen2Func2Anom1.setAnomaliyCode(anomaliyCode1);
		confScen2Func2Anom1.setAnomaliyPresent(anomaliyPresentFalse);

		confScen2Func2Anom2.setScenario(scenario2);
		confScen2Func2Anom2.setFunctionCode(functionCode2);
		confScen2Func2Anom2.setAnomaliyCode(anomaliyCode2);
		confScen2Func2Anom2.setAnomaliyPresent(anomaliyPresentTrue);

		confScen2Func2Anom3.setScenario(scenario2);
		confScen2Func2Anom3.setFunctionCode(functionCode2);
		confScen2Func2Anom3.setAnomaliyCode(anomaliyCode3);
		confScen2Func2Anom3.setAnomaliyPresent(anomaliyPresentFalse);

		confScen2Func2Anom4.setScenario(scenario2);
		confScen2Func2Anom4.setFunctionCode(functionCode2);
		confScen2Func2Anom4.setAnomaliyCode(anomaliyCode4);
		confScen2Func2Anom4.setAnomaliyPresent(anomaliyPresentFalse);
		//-----------------------------functionCode3----------------------------------------
		confScen2Func3Anom1.setScenario(scenario2);
		confScen2Func3Anom1.setFunctionCode(functionCode3);
		confScen2Func3Anom1.setAnomaliyCode(anomaliyCode1);
		confScen2Func3Anom1.setAnomaliyPresent(anomaliyPresentFalse);

		confScen2Func3Anom2.setScenario(scenario2);
		confScen2Func3Anom2.setFunctionCode(functionCode3);
		confScen2Func3Anom2.setAnomaliyCode(anomaliyCode2);
		confScen2Func3Anom2.setAnomaliyPresent(anomaliyPresentTrue);

		confScen2Func3Anom3.setScenario(scenario2);
		confScen2Func3Anom3.setFunctionCode(functionCode3);
		confScen2Func3Anom3.setAnomaliyCode(anomaliyCode3);
		confScen2Func3Anom3.setAnomaliyPresent(anomaliyPresentFalse);

		confScen2Func3Anom4.setScenario(scenario2);
		confScen2Func3Anom4.setFunctionCode(functionCode3);
		confScen2Func3Anom4.setAnomaliyCode(anomaliyCode4);
		confScen2Func3Anom4.setAnomaliyPresent(anomaliyPresentFalse);
		//-----------------------------functionCode4----------------------------------------
		confScen2Func4Anom1.setScenario(scenario2);
		confScen2Func4Anom1.setFunctionCode(functionCode4);
		confScen2Func4Anom1.setAnomaliyCode(anomaliyCode1);
		confScen2Func4Anom1.setAnomaliyPresent(anomaliyPresentFalse);

		confScen2Func4Anom2.setScenario(scenario2);
		confScen2Func4Anom2.setFunctionCode(functionCode4);
		confScen2Func4Anom2.setAnomaliyCode(anomaliyCode2);
		confScen2Func4Anom2.setAnomaliyPresent(anomaliyPresentTrue);

		confScen2Func4Anom3.setScenario(scenario2);
		confScen2Func4Anom3.setFunctionCode(functionCode4);
		confScen2Func4Anom3.setAnomaliyCode(anomaliyCode3);
		confScen2Func4Anom3.setAnomaliyPresent(anomaliyPresentFalse);

		confScen2Func4Anom4.setScenario(scenario2);
		confScen2Func4Anom4.setFunctionCode(functionCode4);
		confScen2Func4Anom4.setAnomaliyCode(anomaliyCode4);
		confScen2Func4Anom4.setAnomaliyPresent(anomaliyPresentFalse);

		List<FunctionDisableConfig> disableAnomailesCodesList = new ArrayList<>();
		disableAnomailesCodesList.add(confScen1Func1Anom1);
		disableAnomailesCodesList.add(confScen1Func1Anom2);
		disableAnomailesCodesList.add(confScen1Func1Anom3);
		disableAnomailesCodesList.add(confScen1Func1Anom4);
		disableAnomailesCodesList.add(confScen1Func2Anom1);
		disableAnomailesCodesList.add(confScen1Func2Anom2);
		disableAnomailesCodesList.add(confScen1Func2Anom3);
		disableAnomailesCodesList.add(confScen1Func2Anom4);
		disableAnomailesCodesList.add(confScen1Func3Anom1);
		disableAnomailesCodesList.add(confScen1Func3Anom2);
		disableAnomailesCodesList.add(confScen1Func3Anom3);
		disableAnomailesCodesList.add(confScen1Func3Anom4);
		disableAnomailesCodesList.add(confScen1Func4Anom1);
		disableAnomailesCodesList.add(confScen1Func4Anom2);
		disableAnomailesCodesList.add(confScen1Func4Anom3);
		disableAnomailesCodesList.add(confScen1Func4Anom4);

		disableAnomailesCodesList.add(confScen2Func1Anom1);
		disableAnomailesCodesList.add(confScen2Func1Anom2);
		disableAnomailesCodesList.add(confScen2Func1Anom3);
		disableAnomailesCodesList.add(confScen2Func1Anom4);
		disableAnomailesCodesList.add(confScen2Func2Anom1);
		disableAnomailesCodesList.add(confScen2Func2Anom2);
		disableAnomailesCodesList.add(confScen2Func2Anom3);
		disableAnomailesCodesList.add(confScen2Func2Anom4);
		disableAnomailesCodesList.add(confScen2Func3Anom1);
		disableAnomailesCodesList.add(confScen2Func3Anom2);
		disableAnomailesCodesList.add(confScen2Func3Anom3);
		disableAnomailesCodesList.add(confScen2Func3Anom4);
		disableAnomailesCodesList.add(confScen2Func4Anom1);
		disableAnomailesCodesList.add(confScen2Func4Anom2);
		disableAnomailesCodesList.add(confScen2Func4Anom3);
		disableAnomailesCodesList.add(confScen2Func4Anom4);
		return disableAnomailesCodesList;
	}

	// ----- adjustDeclDatesForPlotsBetweenDates -----
	@Test
	void test_adjustDeclDatesForPlotsBetweenDates_ok() {

		DeclarationWithPlotCode theDecl = DeclarationWithPlotCode.builder()
				.plotCode("999")
				.declCode("000")
				.fromDate(AbsoluteDate.of("20200516"))
				.toDate(AbsoluteDate.of("20210515"))
				.build();

		AbsoluteDate plotFromDate1 = AbsoluteDate.of("20200202");
		AbsoluteDate plotToDate1 = AbsoluteDate.of("20201231");
		Plot plot1 = Plot.builder()
				.plotCode("999")
				.fromDate(plotFromDate1)
				.toDate(plotToDate1)
				.decls(new ArrayList<>(List.of(
						theDecl,
						DeclarationWithPlotCode.builder()
								.plotCode("999")
								.declCode("001")
								.fromDate(plotFromDate1)
								.toDate(plotToDate1)
								.build()
				)))
				.build();

		AbsoluteDate plotFromDate2 = AbsoluteDate.of("20210101");
		AbsoluteDate plotToDate2 = AbsoluteDate.of("20211202");
		Plot plot2 = Plot.builder()
				.plotCode("999")
				.fromDate(plotFromDate2)
				.toDate(plotToDate2)
				.decls(new ArrayList<>(List.of(
						theDecl,
						DeclarationWithPlotCode.builder()
								.plotCode("999")
								.declCode("002")
								.fromDate(plotFromDate2)
								.toDate(plotToDate2)
								.build()
				)))
				.build();

		// test
		cropPlanService.adjustDeclDatesForPlotsBetweenDates(plot1, theDecl);
		cropPlanService.adjustDeclDatesForPlotsBetweenDates(plot2, theDecl);

		assertThat(plot1.getDecls())
				.allSatisfy(d -> {
					assertThat(d.getFromDate().toLocalDate()).isAfterOrEqualTo(plotFromDate1.toLocalDate());
					assertThat(d.getToDate().toLocalDate()).isBeforeOrEqualTo(plotToDate1.toLocalDate());
				});
		assertThat(plot2.getDecls())
				.allSatisfy(d -> {
					assertThat(d.getFromDate().toLocalDate()).isAfterOrEqualTo(plotFromDate2.toLocalDate());
					assertThat(d.getToDate().toLocalDate()).isBeforeOrEqualTo(plotToDate2.toLocalDate());
				});

	}

	// ----- createVersion -----
	@Test
	void test_createVersion_ConstraintsVersionToSyncRefDateOk() throws NoSuchFieldException, IllegalAccessException {
		Field cropPlanServiceUtilsField = CropPlanService.class.getDeclaredField("cropPlanServiceUtils");
		cropPlanServiceUtilsField.setAccessible(true);
		CropPlanServiceUtils cropPlanServiceUtilsMock = mock(CropPlanServiceUtils.class);
		cropPlanServiceUtilsField.set(cropPlanService, cropPlanServiceUtilsMock);

		var env = mock(RuntimeEnvironment.class);
		String user = "MOCK_USER";
		given(env.getUserId()).willReturn(user);
		given(env.getTenantId()).willReturn("TTTT");
		given(env.getUser()).willReturn(new User(user));
		given(env.getLocale()).willReturn(Locale.ITALIAN);

		String businessId = "555";
		long cropPlanId = 123L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20240515");
		AbsoluteDate lastSyncReferenceDt = AbsoluteDate.of("20240515");
		LatestSync latestSync = new LatestSync(SyncType.LPIS, LocalDateTime.now(), lastSyncReferenceDt);
		LocalDateTime versionDt = LocalDateTime.of(2024, Month.JANUARY, 12, 15, 31);
		String message = "a message";
		CreateVersionPayload payload = new CreateVersionPayload(message, false, pointInTime);

		CropPlanVersion newCropPlanVersion = new CropPlanVersion(cropPlanId, new Version(versionDt), versionDt, pointInTime,
				message, "CROPPLAN", user, true);

		given(cropPlansDAO.getCropPlanTypeByCropPlanId(any(), any(), any())).willReturn(new CropPlanType("CROPPLAN", null, null, null, null));
		given(cropPlanConfigService.isConstraintsVersionToSyncRefDate(any())).willReturn(true);
		given(syncDAO.getLatestSync(any())).willReturn(latestSync);
		given(pluginManager.getValidatorPlugin(any(), any(), any())).willReturn(validatorPlugin);
		given(validatorPlugin.ignoreBlockingAnomalies(any())).willReturn(true);
		given(cropPlansDAO.infinite(any(), isNull(), anyInt())).willReturn(new InfiniteListResultsImpl<>(List.of(newCropPlanVersion), null));


		// tested
		CropPlanVersion version = cropPlanService.createVersion(env, businessId, cropPlanId, payload, true);

		Assertions.assertThat(version).isSameAs(newCropPlanVersion);

		verify(cropPlansDAO).createVersion(cropPlanId, pointInTime, message, user);
	}

	@Test
	void test_createVersion_ConstraintsVersionToSyncRefDateNullKO() throws NoSuchFieldException, IllegalAccessException {
		Field cropPlanServiceUtilsField = CropPlanService.class.getDeclaredField("cropPlanServiceUtils");
		cropPlanServiceUtilsField.setAccessible(true);
		CropPlanServiceUtils cropPlanServiceUtilsMock = mock(CropPlanServiceUtils.class);
		cropPlanServiceUtilsField.set(cropPlanService, cropPlanServiceUtilsMock);

		var env = mock(RuntimeEnvironment.class);
		String user = "MOCK_USER";
		given(env.getUserId()).willReturn(user);
		given(env.getTenantId()).willReturn("TTTT");
		given(env.getUser()).willReturn(new User(user));
		given(env.getLocale()).willReturn(Locale.ITALIAN);

		String businessId = "555";
		long cropPlanId = 123L;
		AbsoluteDate pointInTime = null;
		String message = "a message";
		CreateVersionPayload payload = new CreateVersionPayload(message, false, pointInTime);

		given(cropPlansDAO.getCropPlanTypeByCropPlanId(any(), any(), any())).willReturn(new CropPlanType("CROPPLAN", null, null, null, null));
		given(cropPlanConfigService.isConstraintsVersionToSyncRefDate(any())).willReturn(true);


		// tested
		assertThrows(BadRequestException.class,
				() -> cropPlanService.createVersion(env, businessId, cropPlanId, payload, true));

		verify(cropPlansDAO, never()).createVersion(any(), any(), any(), any());
	}

	@Test
	void test_createVersion_ConstraintsVersionToSyncRefDateDifferentKO() throws NoSuchFieldException, IllegalAccessException {
		Field cropPlanServiceUtilsField = CropPlanService.class.getDeclaredField("cropPlanServiceUtils");
		cropPlanServiceUtilsField.setAccessible(true);
		CropPlanServiceUtils cropPlanServiceUtilsMock = mock(CropPlanServiceUtils.class);
		cropPlanServiceUtilsField.set(cropPlanService, cropPlanServiceUtilsMock);

		var env = mock(RuntimeEnvironment.class);
		String user = "MOCK_USER";
		given(env.getUserId()).willReturn(user);
		given(env.getTenantId()).willReturn("TTTT");
		given(env.getUser()).willReturn(new User(user));
		given(env.getLocale()).willReturn(Locale.ITALIAN);

		String businessId = "555";
		long cropPlanId = 123L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20231101");
		AbsoluteDate lastSyncReferenceDt = AbsoluteDate.of("20240515");
		LatestSync latestSync = new LatestSync(SyncType.LPIS, LocalDateTime.now(), lastSyncReferenceDt);
		String message = "a message";
		CreateVersionPayload payload = new CreateVersionPayload(message, false, pointInTime);

		given(cropPlansDAO.getCropPlanTypeByCropPlanId(any(), any(), any())).willReturn(new CropPlanType("CROPPLAN", null, null, null, null));
		given(cropPlanConfigService.isConstraintsVersionToSyncRefDate(any())).willReturn(true);
		given(syncDAO.getLatestSync(any())).willReturn(latestSync);


		// tested
		assertThrows(BadRequestException.class, () -> cropPlanService.createVersion(env, businessId, cropPlanId, payload, true));

		verify(cropPlansDAO, never()).createVersion(any(), any(), any(), any());
	}

	// ----- createSubdomainZone -----
	@Test
	void test_createSubdomainZone_ok() throws ParseException {
		String businessId = "555";
		long cropPlanId = 123L;
		String domainZoneId = "AA00";
		LocalDateTime versionDt = LocalDateTime.of(2024, Month.MAY, 24, 10, 26);
		AbsoluteDate pointInTime = AbsoluteDate.of("20240515");
		Geometry geom = reader.read("POLYGON ((000 100, 100 100, 100 000, 000 000, 000 100))");
		SubdomainZoneRequest req = new SubdomainZoneRequest(geom);

		int maxPlots = 50;
		int numPlots = 50;
		long subdomainZoneId = 999L;

		given(cropPlanConfigService.getMaxPlotsOnDomainZone(any())).willReturn(Optional.of(maxPlots));
		given(cropPlansDAO.countPlotsByGeomIntersects(any(), any(), any(), any(), any(), any())).willReturn(numPlots);
		given(subdomainZoneDAO.insertSubdomainZone(any())).willReturn(subdomainZoneId);

		//tested
		SubdomainZoneResponse subdomainZone = cropPlanService.createSubdomainZone(new RuntimeEnvironmentImpl(), businessId, cropPlanId, domainZoneId, versionDt, pointInTime, req);

		assertThat(subdomainZone).isNotNull()
				.isEqualTo(new SubdomainZoneResponse(subdomainZoneId, geom));

		verify(cropPlansDAO).countPlotsByGeomIntersects(cropPlanId, domainZoneId, geom, versionDt, pointInTime, pointInTime);
		verify(subdomainZoneDAO).insertSubdomainZone(geom);

	}

	@Test
	void test_createSubdomainZone_noPlotsOkDefaultId() throws ParseException {
		String businessId = "555";
		long cropPlanId = 123L;
		String domainZoneId = "AA00";
		LocalDateTime versionDt = LocalDateTime.of(2024, Month.MAY, 24, 10, 26);
		AbsoluteDate pointInTime = AbsoluteDate.of("20240515");
		Geometry geom = reader.read("POLYGON ((000 100, 100 100, 100 000, 000 000, 000 100))");
		SubdomainZoneRequest req = new SubdomainZoneRequest(geom);

		int maxPlots = 50;
		int numPlots = 0;

		given(cropPlanConfigService.getMaxPlotsOnDomainZone(any())).willReturn(Optional.of(maxPlots));
		given(cropPlansDAO.countPlotsByGeomIntersects(any(), any(), any(), any(), any(), any())).willReturn(numPlots);

		//tested
		SubdomainZoneResponse subdomainZone = cropPlanService.createSubdomainZone(new RuntimeEnvironmentImpl(), businessId, cropPlanId, domainZoneId, versionDt, pointInTime, req);

		assertThat(subdomainZone).isNotNull()
				.isEqualTo(new SubdomainZoneResponse(-1L, geom));

		verify(cropPlansDAO).countPlotsByGeomIntersects(cropPlanId, domainZoneId, geom, versionDt, pointInTime, pointInTime);
		verify(subdomainZoneDAO, never()).insertSubdomainZone(any());

	}

	@Test
	void test_createSubdomainZone_tooManyPlotsKo() throws ParseException {
		String businessId = "555";
		long cropPlanId = 123L;
		String domainZoneId = "AA00";
		LocalDateTime versionDt = LocalDateTime.of(2024, Month.MAY, 24, 10, 26);
		AbsoluteDate pointInTime = AbsoluteDate.of("20240515");
		Geometry geom = reader.read("POLYGON ((000 100, 100 100, 100 000, 000 000, 000 100))");
		SubdomainZoneRequest req = new SubdomainZoneRequest(geom);

		int maxPlots = 50;
		int numPlots = 111;

		given(cropPlanConfigService.getMaxPlotsOnDomainZone(any())).willReturn(Optional.of(maxPlots));
		given(cropPlansDAO.countPlotsByGeomIntersects(any(), any(), any(), any(), any(), any())).willReturn(numPlots);

		//tested
		SubdomainZoneException subdomainZoneException = assertThrows(SubdomainZoneException.class,
				() -> cropPlanService.createSubdomainZone(new RuntimeEnvironmentImpl(), businessId, cropPlanId, domainZoneId, versionDt, pointInTime, req));

		assertThat(subdomainZoneException).isNotNull()
				.extracting("code")
				.isEqualTo(ErrEnum.TOO_MANY_PLOTS_IN_SUBDOMAIN_ZONE.toString());

		verify(cropPlansDAO).countPlotsByGeomIntersects(cropPlanId, domainZoneId, geom, versionDt, pointInTime, pointInTime);
		verify(subdomainZoneDAO, never()).insertSubdomainZone(any());

	}

	@Test
	void test_createSubdomainZone_noConfigKo() throws ParseException {
		String businessId = "555";
		long cropPlanId = 123L;
		String domainZoneId = "AA00";
		LocalDateTime versionDt = LocalDateTime.of(2024, Month.MAY, 24, 10, 26);
		AbsoluteDate pointInTime = AbsoluteDate.of("20240515");
		Geometry geom = reader.read("POLYGON ((000 100, 100 100, 100 000, 000 000, 000 100))");
		SubdomainZoneRequest req = new SubdomainZoneRequest(geom);

		given(cropPlanConfigService.getMaxPlotsOnDomainZone(any())).willReturn(Optional.empty());

		//tested
		SubdomainZoneException subdomainZoneException = assertThrows(SubdomainZoneException.class,
				() -> cropPlanService.createSubdomainZone(new RuntimeEnvironmentImpl(), businessId, cropPlanId, domainZoneId, versionDt, pointInTime, req));

		assertThat(subdomainZoneException).isNotNull()
				.extracting("code")
				.isEqualTo(ErrEnum.MAX_PLOTS_ON_DOMAIN_ZONE_NOT_SET.toString());

		verify(cropPlansDAO, never()).countPlotsByGeomIntersects(any(), any(), any(), any(), any(), any());
		verify(subdomainZoneDAO, never()).insertSubdomainZone(any());

	}

	// ----- validateCropPlanEditDates -----

	static Arguments[] test_validateCropPlanEditDates_ok() {

		return new Arguments[] {
				Arguments.arguments(
						AbsoluteDate.of("19000101"), AbsoluteDate.of("20241031"), AbsoluteDate.of("20240515")
				),
				Arguments.arguments(
						AbsoluteDate.of("20240515"), AbsoluteDate.of("20241031"), AbsoluteDate.of("20240515")
				),
				Arguments.arguments(
						AbsoluteDate.of("19000101"), AbsoluteDate.of("20240515"), AbsoluteDate.of("20240515")
				),
				Arguments.arguments(
						AbsoluteDate.of("19000101"), null, AbsoluteDate.of("20240515")
				),
				Arguments.arguments(
						null, AbsoluteDate.of("20241031"), AbsoluteDate.of("20240515")
				),
				Arguments.arguments(
						null, null, AbsoluteDate.of("20240515")
				),
				Arguments.arguments(
						null, null, null
				),

		};
	}

	@MethodSource
	@ParameterizedTest
	void test_validateCropPlanEditDates_ok(AbsoluteDate dayFrom, AbsoluteDate dayTo, AbsoluteDate pointInTime) {

		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		long cropPlanId = 123L;

		given(cropPlansDAO.getCropPlanTypeByCropPlanId(any(), any(), any()))
				.willReturn(new CropPlanType("CROPPLAN", null, null, dayFrom, dayTo));

		// test
		assertDoesNotThrow(() -> cropPlanService.validateCropPlanEditDates(env, cropPlanId, pointInTime));

	}

	static Arguments[] test_validateCropPlanEditDates_ko() {

		return new Arguments[] {
				Arguments.arguments(
						AbsoluteDate.of("20240516"), AbsoluteDate.of("20241031"), AbsoluteDate.of("20240515")
				),
				Arguments.arguments(
						AbsoluteDate.of("19000101"), AbsoluteDate.of("20240514"), AbsoluteDate.of("20240515")
				),
				Arguments.arguments(
						AbsoluteDate.of("20240516"), null, AbsoluteDate.of("20240515")
				),
				Arguments.arguments(
						null, AbsoluteDate.of("20240514"), AbsoluteDate.of("20240515")
				),
				Arguments.arguments(
						AbsoluteDate.of("19000101"), AbsoluteDate.of("20241031"), null
				),
				Arguments.arguments(
						AbsoluteDate.of("19000101"), null, null
				),
				Arguments.arguments(
						null, AbsoluteDate.of("20241031"), null
				),

		};
	}

	@MethodSource
	@ParameterizedTest
	void test_validateCropPlanEditDates_ko(AbsoluteDate dayFrom, AbsoluteDate dayTo, AbsoluteDate pointInTime) {

		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		long cropPlanId = 123L;

		given(cropPlansDAO.getCropPlanTypeByCropPlanId(any(), any(), any()))
				.willReturn(new CropPlanType("CROPPLAN", null, null, dayFrom, dayTo));

		// test
		assertThrows(BadRequestException.class, () -> cropPlanService.validateCropPlanEditDates(env, cropPlanId, pointInTime));

	}
}
