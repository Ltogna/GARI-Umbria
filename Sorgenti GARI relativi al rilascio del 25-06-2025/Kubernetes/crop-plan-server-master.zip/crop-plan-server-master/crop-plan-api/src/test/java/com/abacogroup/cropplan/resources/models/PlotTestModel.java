package com.abacogroup.cropplan.resources.models;

import com.abacogroup.cropplan.api.PlotEditability;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.locationtech.jts.geom.Geometry;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PlotTestModel
{
	@NotNull
	private Long plotId;

	@NotEmpty
	private String plotCode;
	
	@NotEmpty
	private String domainZoneId;

	@NotEmpty
	private String description;

	@Valid
	@NotEmpty
	private List<ParcelIntersectionTestModel> parcelIntersections;

	@NotNull
	private Integer areaSqm;

	@NotNull
	private Geometry geom;
	
	@NotEmpty
	private String srs;

	@NotNull
	private Geometry mbrOverview;

	@Valid
	@NotEmpty
	private List<DeclarationTestModel> decls;

	@Valid
	@NotNull
	private StyleTestModel style;

	@NotNull
	private String fromDate;

	@NotNull
	private String toDate;
	
	@NotNull
	private String fullRangeFromDate;

	@NotNull
	private String fullRangeToDate;

	@NotNull
	private PlotEditability editability;

	@Valid
	@NotEmpty
	private List<ValidationAnomalyTestModel> anomalies;
}
