package com.abacogroup.cropplan.resources.models;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
public class CropPlanPrintTestModel
{
	@NotEmpty
	private String code;

	@NotEmpty
	private String description;
}
