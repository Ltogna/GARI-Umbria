package com.abacogroup.cropplan.bundle;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import jakarta.validation.ConstraintViolationException;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Function;
import org.junit.jupiter.api.Test;

class PermCropFormsConfigProcessorTest {

	private static final String TENANT_ID = "tenant";
	private static final String USER_ID = "importDataBundle";
	protected Function<String, Path> file2Path = filename -> Optional.of(Path.of(
			"src/test/resources",
			this.getClass().getName().replaceAll("\\.", "/"),
			filename)).orElseThrow();

	private CropPlanConfigDAO configDAO = mock();

	private PermCropFormsConfigProcessor processor = new PermCropFormsConfigProcessor(configDAO);

	// ----- onMessage -----
	@Test
	void test_onMessage_ok() {

		given(configDAO.getCropPlanTypeId(eq("CROPPLAN"), any())).willReturn(111L);
		given(configDAO.getCropPlanTypeId(eq("CROPPLAN_2025"), any())).willReturn(222L);
		AtomicLong atomicId = new AtomicLong(1000L);
		given(configDAO.getPermCropFormsConfigSeq()).willAnswer(i -> atomicId.incrementAndGet());

		processor.onMessage(new ConfigDataMessage(TENANT_ID, List.of(
				file2Path.apply("permCropFormsConfig/iacs-config-00026.crpl_config_cropplan.json"),
				file2Path.apply("permCropFormsConfig/iacs-config-00026.crpl_config_cropplan_landusecodes.json"),
				file2Path.apply("permCropFormsConfig/iacs-config-00119.perm-crop-form.delete.json"),
				file2Path.apply("permCropFormsConfig/iacs-config-00122.perm-crop-form_2025.json"),
				file2Path.apply("permCropFormsConfig/new_crpl_config_cropplan.json"),
				file2Path.apply("permCropFormsConfig/new_perm-crop-form.delete.json")
		)));

		verify(configDAO).deletePermCropFormsConfig("VINEYARD_FORM", 111L, null, null, AbsoluteDate.of("19700101"), AbsoluteDate.of("99991231"));
		verify(configDAO).updatePermCropFormsConfigDates("VINEYARD_FORM", 111L, "111-000-000-000-000", null, AbsoluteDate.of("19700101"), AbsoluteDate.of("20241231"), AbsoluteDate.of("20241231"));
		verify(configDAO).updatePermCropFormsConfigDates("VINEYARD_FORM", 111L, "222-000-000-000-000", null, AbsoluteDate.of("19700101"), AbsoluteDate.of("20241231"), AbsoluteDate.of("20241231"));
		verify(configDAO).updatePermCropFormsConfigDates("VINEYARD_FORM", 111L, null, "111", AbsoluteDate.of("19700101"), AbsoluteDate.of("20241231"), AbsoluteDate.of("20241231"));
		verify(configDAO).updatePermCropFormsConfigDates("VINEYARD_FORM", 111L, null, "222", AbsoluteDate.of("19700101"), AbsoluteDate.of("20241231"), AbsoluteDate.of("20241231"));

		verify(configDAO).deletePermCropFormsConfig("VINEYARD_FORM", 111L, null, "420", AbsoluteDate.of("19700101"), AbsoluteDate.of("99991231"));
		verify(configDAO).deletePermCropFormsConfig("VINEYARD_FORM", 111L, null, "500", AbsoluteDate.of("19700101"), AbsoluteDate.of("99991231"));
		verify(configDAO).deletePermCropFormsConfig("VINEYARD_FORM", 111L, "420-005-000-000-000", null, AbsoluteDate.of("19700101"), AbsoluteDate.of("99991231"));
		verify(configDAO).deletePermCropFormsConfig("VINEYARD_FORM", 111L, "420-006-000-000-000", null, AbsoluteDate.of("19700101"), AbsoluteDate.of("99991231"));
		verify(configDAO).deletePermCropFormsConfig("VINEYARD_FORM", 222L, null, "410", AbsoluteDate.of("19700101"), AbsoluteDate.of("99991231"));
		verify(configDAO).deletePermCropFormsConfig("VINEYARD_FORM", 222L, null, "420", AbsoluteDate.of("19700101"), AbsoluteDate.of("99991231"));
		verify(configDAO).deletePermCropFormsConfig("VINEYARD_FORM", 222L, "420-000-000-000-000", null, AbsoluteDate.of("20250101"), AbsoluteDate.of("20251231"));
		verify(configDAO).deletePermCropFormsConfig("VINEYARD_FORM", 222L, "420-000-059-000-000", null, AbsoluteDate.of("20250101"), AbsoluteDate.of("20251231"));

		verify(configDAO).insertPermCropFormsConfig(1001L, "VINEYARD_FORM", 111L, null, "420", AbsoluteDate.of("19700101"), AbsoluteDate.of("99991231"));
		verify(configDAO).insertPermCropFormsConfig(1002L, "VINEYARD_FORM", 111L, null, "500", AbsoluteDate.of("19700101"), AbsoluteDate.of("99991231"));
		verify(configDAO).insertPermCropFormsConfig(1003L, "VINEYARD_FORM", 111L, "420-005-000-000-000", null, AbsoluteDate.of("19700101"), AbsoluteDate.of("99991231"));
		verify(configDAO).insertPermCropFormsConfig(1004L, "VINEYARD_FORM", 111L, "420-006-000-000-000", null, AbsoluteDate.of("19700101"), AbsoluteDate.of("99991231"));
		verify(configDAO).insertPermCropFormsConfig(1005L, "VINEYARD_FORM", 222L, null, "410", AbsoluteDate.of("19700101"), AbsoluteDate.of("99991231"));
		verify(configDAO).insertPermCropFormsConfig(1006L, "VINEYARD_FORM", 222L, null, "420", AbsoluteDate.of("19700101"), AbsoluteDate.of("99991231"));
		verify(configDAO).insertPermCropFormsConfig(1007L, "VINEYARD_FORM", 222L, "420-000-000-000-000", null, AbsoluteDate.of("20250101"), AbsoluteDate.of("20251231"));
		verify(configDAO).insertPermCropFormsConfig(1008L, "VINEYARD_FORM", 222L, "420-000-059-000-000", null, AbsoluteDate.of("20250101"), AbsoluteDate.of("20251231"));

		verify(configDAO).insertPermCropFormsFieldConfig(1001L, "DISTANCE_BETWEEN_ROWS_CM", 0, 1);
		verify(configDAO).insertPermCropFormsFieldConfig(1001L, "DISTANCE_ON_THE_ROW_CM", 0, 1);
		verify(configDAO).insertPermCropFormsFieldConfig(1002L, "DISTANCE_BETWEEN_ROWS_CM", 0, 1);
		verify(configDAO).insertPermCropFormsFieldConfig(1002L, "DISTANCE_ON_THE_ROW_CM", 0, 1);
		// no fields in 1003, 1004
		verify(configDAO).insertPermCropFormsFieldConfig(1005L, "PLANTING_TYPE", 0, 1);
		verify(configDAO).insertPermCropFormsFieldConfig(1005L, "PLANTING_YEAR", 1, 0);
		verify(configDAO).insertPermCropFormsFieldConfig(1006L, "PLANTING_TYPE", 0, 1);
		verify(configDAO).insertPermCropFormsFieldConfig(1006L, "PLANTING_YEAR", 1, 0);
		verify(configDAO).insertPermCropFormsFieldConfig(1007L, "STUMPS_NUMBER", 1, 1);
		verify(configDAO).insertPermCropFormsFieldConfig(1007L, "STUMPS_DENSITY_100", 0, 0);
		verify(configDAO).insertPermCropFormsFieldConfig(1008L, "STUMPS_NUMBER", 1, 1);
		verify(configDAO).insertPermCropFormsFieldConfig(1008L, "STUMPS_DENSITY_100", 0, 0);

	}

	@Test
	void test_onMessage_validationKO() {

		BundleException be1 = assertThrows(BundleException.class, () -> processor.onMessage(new ConfigDataMessage(TENANT_ID, List.of(
				file2Path.apply("permCropFormsConfig/not_valid_1_crpl_config_cropplan.delete.json")
		))));

		assertThat(be1).hasCauseInstanceOf(ConstraintViolationException.class)
				.satisfies(ex -> System.out.println(ex.getCause().getMessage()))
				.hasMessageContainingAll("cropPlanType", "formType")
				.hasMessageNotContainingAny("landUseCodes", "landUseClassCodes", "validFrom", "validTo", "fields", "deleteFrom");

		// ---

		BundleException be2 = assertThrows(BundleException.class, () -> processor.onMessage(new ConfigDataMessage(TENANT_ID, List.of(
				file2Path.apply("permCropFormsConfig/not_valid_1_crpl_config_cropplan.json")
		))));

		assertThat(be2).hasCauseInstanceOf(ConstraintViolationException.class)
				.satisfies(ex -> System.out.println(ex.getCause().getMessage()))
				.hasMessageContainingAll("cropPlanType", "formType", "fields[0].fieldCode", "deleteFrom")
				.hasMessageNotContainingAny("landUseCodes", "landUseClassCodes", "validFrom", "validTo");
	}
}
