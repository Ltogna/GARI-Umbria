import com.abacogroup.cropplan.CropPlanApplication;

public class Server_avepa_dev {
	public static void main(String[] args) throws Exception {
		CropPlanApplication.main(new String[] {
				"server", "config-avepa-dev.yml"
		});
	}
}
