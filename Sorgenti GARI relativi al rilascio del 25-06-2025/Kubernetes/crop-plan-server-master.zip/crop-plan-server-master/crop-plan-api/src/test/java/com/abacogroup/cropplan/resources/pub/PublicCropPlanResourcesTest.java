package com.abacogroup.cropplan.resources.pub;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Set;

import org.assertj.core.api.Assertions;
import org.glassfish.jersey.test.grizzly.GrizzlyWebTestContainerFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryCollection;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;

import com.abacogroup.cropplan.api.ChangedPlot;
import com.abacogroup.cropplan.api.CropPlan;
import com.abacogroup.cropplan.api.CropPlanPrint;
import com.abacogroup.cropplan.api.CropPlanType;
import com.abacogroup.cropplan.api.CutBehaviour;
import com.abacogroup.cropplan.api.EditPlotPreviewResult;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.PlotEditability;
import com.abacogroup.cropplan.api.PlotPreview;
import com.abacogroup.cropplan.api.ValidationAnomalies;
import com.abacogroup.cropplan.api.payload.EditPlotPayload.CutParameters;
import com.abacogroup.cropplan.api.payload.GetPermanentCropFormSubscriptionsPayload;
import com.abacogroup.cropplan.api.payload.InsertPlotPayload;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.PlotEditDAO;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.PlotEditResources;
import com.abacogroup.cropplan.resources.auth.MyBasicAuthenticator;
import com.abacogroup.cropplan.resources.auth.MyBasicAuthorizer;
import com.abacogroup.cropplan.resources.models.ChangedPlotTestModel;
import com.abacogroup.cropplan.resources.models.CropPlanTestModel;
import com.abacogroup.cropplan.resources.models.CropPlanTypeTestModel;
import com.abacogroup.cropplan.resources.models.CropPlanVersionTestModel;
import com.abacogroup.cropplan.resources.models.EditPlotPreviewResultTestModel;
import com.abacogroup.cropplan.resources.models.InfiniteListResultTestModel;
import com.abacogroup.cropplan.resources.models.PermanentCropFormFieldCodesTestModel;
import com.abacogroup.cropplan.resources.models.PermanentCropFormSubscriptionTestModel;
import com.abacogroup.cropplan.resources.models.ValidationAnomaliesTestModel;
import com.abacogroup.cropplan.resources.models.ValidationAnomalyTestModel;
import com.abacogroup.cropplan.resources.providers.LocalDateTimeProvider;
import com.abacogroup.cropplan.sdk.jackson.WKTGeometryDeserializer;
import com.abacogroup.cropplan.sdk.jackson.WKTGeometrySerializer;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.BaseDeclaration;
import com.abacogroup.cropplan.sdk.model.CropPlanVersion;
import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.PermanentCropForm;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormData;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormFieldCodes;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormFieldValue;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormSubscription;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormSubscriptionField;
import com.abacogroup.cropplan.sdk.model.Version;
import com.abacogroup.cropplan.sdk.model.auth.CropPlanTypeAccessLevel;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.cropcodes.Style;
import com.abacogroup.cropplan.sdk.model.pesticides.PesticideEntry;
import com.abacogroup.cropplan.sdk.model.validation.AnomalyObjectType;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomaly;
import com.abacogroup.cropplan.sdk.spi.CropPlanPlugin;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.CropPlanDeclarationsService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.DeclarationService;
import com.abacogroup.cropplan.services.LocksService;
import com.abacogroup.cropplan.services.PlotEditService;
import com.abacogroup.cropplan.services.PrintService;
import com.abacogroup.cropplan.services.SyncService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.plugins.impl.EnvironmentFactory;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;

import io.dropwizard.auth.AuthDynamicFeature;
import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.auth.basic.BasicCredentialAuthFilter;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;

@ExtendWith(DropwizardExtensionsSupport.class)
public class PublicCropPlanResourcesTest {
	private static BaseService baseService = mock(BaseService.class);
	private static CropPlanService cropPlanService = mock(CropPlanService.class);
	private static CropPlanDeclarationsService cropPlanDeclarationsService = mock(CropPlanDeclarationsService.class);
	private static SyncService syncService = mock(SyncService.class);
	private static CropPlansDAO cropPlansDAO = mock(CropPlansDAO.class);
	private static CropPlanConfigDAO crplConfigDAO = mock(CropPlanConfigDAO.class);
	private static LocksService locksService = mock(LocksService.class);
	private static DeclarationService declarationService = mock(DeclarationService.class);
	private static CropCodeService cropCodeService = mock(CropCodeService.class);
	private static ValidatorService validatorService = mock(ValidatorService.class);
	private static PluginManager pluginManager = mock(PluginManager.class);
	private static CropPlanPlugin cropPlanPlugin = mock(CropPlanPlugin.class);
	private static PlotEditDAO plotEditDAO = mock(PlotEditDAO.class);
	private static CropPlanConfigService cropPlanConfigService = mock(CropPlanConfigService.class);
	private static ObjectMapper mapper = createMapper();
	private static PlotEditService plotEditService = mock(PlotEditService.class);
	private static PrintService printService = mock(PrintService.class);
	private static final AbsoluteDate UNIX_START_DATE = AbsoluteDate.of("19700101");
	private static final AbsoluteDate END_OF_WORLD = AbsoluteDate.of("99991231");

	private static DAOContainer daoContainer = DAOContainer.builder()
			.cropPlansDAO(cropPlansDAO)
			.cropPlanConfigDAO(crplConfigDAO)
			.plotEditDAO(plotEditDAO)
			.build();

	private static final ResourceExtension EXT = ResourceExtension.builder()
			.setTestContainerFactory(new GrizzlyWebTestContainerFactory())
			.addProvider(new AuthDynamicFeature(new BasicCredentialAuthFilter.Builder<User>()
					.setAuthenticator(new MyBasicAuthenticator())
					.setAuthorizer(new MyBasicAuthorizer())
					.buildAuthFilter()))
			.addProvider(new AuthValueFactoryProvider.Binder<>(User.class))
			.addProvider(LocalDateTimeProvider.class)
			.addResource(new PublicTenantCropPlanResources(baseService, cropPlanService, cropPlanDeclarationsService, declarationService, syncService, locksService, cropCodeService,
					validatorService, mock(), printService, pluginManager, daoContainer))
			.addProvider(baseService)
			.setMapper(mapper)
			.build();
	
	private static final ResourceExtension EXT_PLOTS = ResourceExtension.builder()
			.setTestContainerFactory(new GrizzlyWebTestContainerFactory())
			.addProvider(new AuthDynamicFeature(new BasicCredentialAuthFilter.Builder<User>()
					.setAuthenticator(new MyBasicAuthenticator())
					.setAuthorizer(new MyBasicAuthorizer())
					.buildAuthFilter()))
			.addProvider(new AuthValueFactoryProvider.Binder<>(User.class))
			.addProvider(LocalDateTimeProvider.class)
			.addResource(new PlotEditResources(baseService, cropPlanConfigService, plotEditService, 
					cropPlanService, locksService, validatorService,
					daoContainer, pluginManager))
			.addProvider(baseService)
			.setMapper(mapper)
			.build();

	private static WKTReader wktReader = new WKTReader();

	public static ObjectMapper createMapper() {
		ObjectMapper objectMapper = new ObjectMapper()
				.findAndRegisterModules()
				.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true);

		SimpleModule module = new SimpleModule("custom-deserializers", com.fasterxml.jackson.core.Version.unknownVersion());
		module.addSerializer(Geometry.class, new WKTGeometrySerializer());
		module.addDeserializer(Geometry.class, new WKTGeometryDeserializer());
		objectMapper.registerModule(module);

		return objectMapper;
	}

	@BeforeEach
	public void init() {
		var envFactory = mock(EnvironmentFactory.class);
		when(baseService.getEnvironmentFactory())
				.thenReturn(envFactory);
		var env = mock(RuntimeEnvironment.class);
		when(envFactory.create(any(), any()))
				.thenReturn(env);
		when(env.getTenantId())
				.thenReturn("_");

		when(baseService.canRead(any(), any(), any()))
				.thenReturn(true);
		when(cropPlanService.getAccessLevel(any(), any(), any()))
				.thenReturn(CropPlanTypeAccessLevel.CREATE);
		when(cropPlanService.getCropPlan(any(), any(), anyLong()))
				.thenReturn(new CropPlan());
		when(cropPlanService.getCropPlanTypeCode(any(), any(), anyLong()))
				.thenReturn(new String());
		when(pluginManager.getCropPlanPlugin(any(), anyLong(), any()))
				.thenReturn(cropPlanPlugin);
		when(locksService.hasLock(any(), anyLong()))
				.thenReturn(true);
	}

	@Test
	public void whenGetCropPlanTypes_thenReturnCropPlanTypesKeepingPropertiesUnchanged() {
		List<CropPlanType> cropPlanTypes = new ArrayList<>();
		cropPlanTypes.add(new CropPlanType("cpt_code", "cpt_descr", false, null, null));
		when(cropPlansDAO.getCropPlanTypes(any(), any()))
				.thenReturn(cropPlanTypes);

		var res = EXT.target("_/public/v1/crop-plans/1/plan-types")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<ArrayList<CropPlanTypeTestModel>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<CropPlanTypeTestModel>> violations = validator.validate(res.get(0));
		assertEquals(violations.size(), 0);
	}

	@Test
	public void whenGetCropPlans_thenReturnCropPlansKeepingPropertiesUnchanged() {
		List<CropPlan> cropPlans = new ArrayList<>();
		var cropPlan = getMockedCropPlan();
		cropPlans.add(cropPlan);
		var ret = new InfiniteListResultsImpl<>(cropPlans, null);
		when(cropPlanService.getCropPlans(any(), any(), any(), any(), any(), anyInt()))
				.thenReturn(ret);

		var res = EXT.target("_/public/v1/crop-plans/1/plans")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<InfiniteListResultTestModel<CropPlanTestModel>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<CropPlanTestModel>> violations = validator.validate(res.getRecords().get(0));
		assertEquals(violations.size(), 0);
	}

	@Test
	public void whenGetAllVersions_thenReturnAllVersionsKeepingPropertiesUnchanged() {
		List<CropPlanVersion> cropPlanVersions = new ArrayList<>();
		var cropPlanVersion = new CropPlanVersion(1L, new Version(LocalDateTime.now()), LocalDateTime.now(), AbsoluteDate.of("20230515"), "msg", "cp_type_code", "THE_USER", true);
		cropPlanVersions.add(cropPlanVersion);
		var ret = new InfiniteListResultsImpl<>(cropPlanVersions, null);
		when(cropPlanService.getAllVersions(any(), any(), anyLong(), anyBoolean(), any(), any(), anyInt()))
				.thenReturn(ret);

		var res = EXT.target("_/public/v1/crop-plans/1/plans/2/versions")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<InfiniteListResultTestModel<CropPlanVersionTestModel>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<CropPlanVersionTestModel>> violations = validator.validate(res.getRecords().get(0));
		assertEquals(violations.size(), 0);
	}

	@Test
	public void whenCreateVersion_thenReturnCropPlanVersionKeepingPropertiesUnchanged() {
		var cropPlanVersion = new CropPlanVersion(1L, new Version(LocalDateTime.now()), LocalDateTime.now(), AbsoluteDate.of("20230515"), "msg", "cp_type_code", "THE_USER", true);
		when(cropPlanService.createVersion(any(), any(), anyLong(), any(), anyBoolean()))
				.thenReturn(cropPlanVersion);

		var res = EXT.target("_/public/v1/crop-plans/1/plans/2/versions")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.post(Entity.json("{\"message\":\"msg\"}"), CropPlanVersionTestModel.class);

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<CropPlanVersionTestModel>> violations = validator.validate(res);
		assertEquals(violations.size(), 0);
	}
	
	@Test
	public void whenCreateCropPlan_thenReturnCropPlanKeepingPropertiesUnchanged() {
		var cropPlan = getMockedCropPlan();
		when(cropPlanService.getCropPlan(any(), any(), anyLong()))
				.thenReturn(cropPlan);

		var res = EXT.target("_/public/v1/crop-plans/1/plans")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.post(Entity.json("{\"cropPlanTypeCode\":\"CROPPLAN\",\"description\":\"test\"}"), CropPlanTestModel.class);

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<CropPlanTestModel>> violations = validator.validate(res);
		assertEquals(violations.size(), 0);
	}

	@Test
	public void whenGetPlots_thenReturnPlotsKeepingPropertiesUnchanged() throws ParseException {
		List<Plot> plots = new ArrayList<>();
		plots.add(getMockedPlot());
		var ret = new InfiniteListResultsImpl<>(plots, null);
		when(cropPlanService.getPlots(any(), any(), anyLong(), any(), any(), any(), any(), any(), any(), anyInt(), any()))
				.thenReturn(ret);

		var res = EXT.target("_/public/v1/crop-plans/1/plans/2/zones/3/plots")
				.queryParam("pointInTime", "20220101")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<InfiniteListResultTestModel<Plot>>() {
				});

		Assertions.assertThat(res).isNotNull()
				.extracting(InfiniteListResultTestModel::getRecords)
				.asList().hasSize(1)
				.zipSatisfy(ret.getRecords(), (resPlot, retPlot) -> {
					Assertions.assertThat(resPlot).isNotNull()
							.usingRecursiveComparison()
							.ignoringFields("decls")
							.isEqualTo(retPlot);
					Assertions.assertThat(((Plot) resPlot).getDecls())
							.zipSatisfy(retPlot.getDecls(), (resDecl, retDecl) -> Assertions.assertThat(resDecl)
									.usingRecursiveComparison()
									.ignoringFields("declId")
									.isEqualTo(retDecl));
				});
	}
	
	@Test
	public void whenGetAllPlots_thenReturnPlotsKeepingPropertiesUnchanged() throws ParseException {
		List<Plot> plots = new ArrayList<>();
		plots.add(getMockedPlot());
		var ret = new InfiniteListResultsImpl<>(plots, null);
		when(cropPlanService.getPlots(any(), any(), anyLong(), any(), any(), any(), any(), any(), any(), anyInt(), any()))
				.thenReturn(ret);

		var res = EXT.target("_/public/v1/crop-plans/1/plans/2/plots")
				.queryParam("pointInTime", "20220101")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<InfiniteListResultTestModel<Plot>>() {
				});

		Assertions.assertThat(res).isNotNull()
				.extracting(InfiniteListResultTestModel::getRecords)
				.asList().hasSize(1)
				.zipSatisfy(ret.getRecords(), (resPlot, retPlot) -> {
					Assertions.assertThat(resPlot).isNotNull()
							.usingRecursiveComparison()
							.ignoringFields("decls")
							.isEqualTo(retPlot);
					Assertions.assertThat(((Plot) resPlot).getDecls())
							.zipSatisfy(retPlot.getDecls(), (resDecl, retDecl) -> Assertions.assertThat(resDecl)
									.usingRecursiveComparison()
									.ignoringFields("declId")
									.isEqualTo(retDecl));
				});
	}
	
	@Test
	public void whenGetPlotsPreview_thenReturnPlotPreviewKeepingPropertiesUnchanged() throws ParseException {
		EditPlotPreviewResult editPlotPreviewResult = new EditPlotPreviewResult();
		List<PlotPreview> added = new ArrayList<PlotPreview>();
		PlotPreview plotPreview = new PlotPreview();
		plotPreview.setPlotCode("Test");
		GeometryCollection geom = (GeometryCollection) wktReader.read("GEOMETRYCOLLECTION (POLYGON ((47873.3 73139, 47871.35 73134.9, 47874.45 73127, 47881.9 73131.7, 47879 73137, 47877.4 73138.65, 47873.3 73139)), \n"
				+ "  LINESTRING (47875.55 73137.15, 47875.05 73129.7, 47878 73134))");
		plotPreview.setGeom(geom);
		added.add(plotPreview);
		editPlotPreviewResult.setAdded(added);
		editPlotPreviewResult.setCoveredByInserted(List.of("CBI1", "CBI2"));	
		editPlotPreviewResult.setDeleted(List.of("D1", "D2"));
		List<PlotPreview> listPlotPreview = new ArrayList<PlotPreview>();
		PlotPreview plotPreviewRes = new PlotPreview();
		plotPreviewRes.setPlotCode("plotPreview");
		plotPreviewRes.setGeom(geom);		
		listPlotPreview.add(plotPreviewRes);
		editPlotPreviewResult.setUpdated(listPlotPreview);
		InsertPlotPayload payload = new InsertPlotPayload();
		var fromDate = AbsoluteDate.of("20230515");
		payload.setFromPointInTime(fromDate);
		payload.setDescription("test");
		GeometryCollection geomInput = (GeometryCollection) wktReader.read("GEOMETRYCOLLECTION (POLYGON ((47873.3 73139, 47871.35 73134.9, 47874.45 73127, 47881.9 73131.7, 47879 73137, 47877.4 73138.65, 47873.3 73139)), \n"
				+ "  LINESTRING (47875.55 73137.15, 47875.05 73129.7, 47878 73134))");
		payload.setGeom(geomInput);	
		CutParameters cutParameters = new CutParameters();
		cutParameters.setBehaviour(CutBehaviour.CUT_ON_EXISTING);
		List<String> plotCodes = List.of("T1", "T2");
		cutParameters.setPlotCodes(plotCodes);		
		payload.setCutParameters(cutParameters);		
		Entity<InsertPlotPayload> payloadEntity = Entity.entity(payload, MediaType.APPLICATION_JSON);
		
//		EditPlotsPayload payload = new EditPlotsPayload();
//		var fromDate = AbsoluteDate.of("20230515");
//		payload.setFromPointInTime(fromDate);
//		
//		List<PlotPayload> plots = new ArrayList<PlotPayload>();
//		PlotPayload plotPayload = new PlotPayload();
//		plotPayload.setPlotCode("test");
//		Polygon geomInput = (Polygon) wktReader.read("POLYGON ((430 450, 370 350, 470 340, 550 410, 520 490, 430 450))");
//		plotPayload.setGeom(geomInput);		
//		plots.add(plotPayload);
//		payload.setPlots(plots);
//		CutParameters cutParameters = new CutParameters();
//		cutParameters.setBehaviour(CutBehaviour.CUT_ON_EXISTING);		
//		payload.setCutParameters(cutParameters);
//		Entity<EditPlotsPayload> payloadEntity = Entity.entity(payload, MediaType.APPLICATION_JSON);
		
		when(plotEditService.createPlotPreview(any(), any(), any()))
				.thenReturn(editPlotPreviewResult);
		
		var res = EXT_PLOTS.target("_/api-priv/v1/crop-plans/1/plans/2/3/plots/preview")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				//.get(EditPlotPreviewResultTest.class);
				//.put(payloadEntity);
				.post(payloadEntity);
		assertNotNull(res);
		if (res.getStatus() != 200) {
		    throw new RuntimeException("Test plots/preview failed! http status: "+res.getStatus());
		}
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		EditPlotPreviewResultTestModel response = res.readEntity(EditPlotPreviewResultTestModel.class);
		Set<ConstraintViolation<EditPlotPreviewResultTestModel>> violations = validator.validate(response);
		assertEquals(violations.size(), 0);
	}
	
	// TODO TEST getDeclaredPlots
	// TODO TEST getDeclarablePlots

	@Test
	public void whenGetPlot_thenReturnPlotKeepingPropertiesUnchanged() throws ParseException
	{
		Plot plot = getMockedPlot();
		when(cropPlanService.getPlot(any(), any(), anyLong(), any(), any(), any(), any(), any()))
			.thenReturn(plot);

		var res = EXT.target("_/public/v1/crop-plans/1/plans/2/zones/3/plots/4")
        	.queryParam("pointInTime", "20220101")
        	.request()
        	.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
        	.get(Plot.class);

		Assertions.assertThat(res).isNotNull()
				.usingRecursiveComparison()
				.ignoringFields("decls")
				.isEqualTo(plot);
		Assertions.assertThat(res.getDecls())
				.zipSatisfy(plot.getDecls(), (resDecl, plotDecl) -> Assertions.assertThat(resDecl)
						.usingRecursiveComparison()
						.ignoringFields("declId")
						.isEqualTo(plotDecl));
	}
	
	// TODO TEST getSyncOperations
	// TODO TEST getSyncProgressStatus
	// TODO TEST syncCropPlan
	// TODO TEST createDeclaration
	// TODO TEST createDeclarations
	// TODO TEST getDeclarations
	// TODO TEST getDeclarationsUpdates
	// TODO TEST getDeclarationsLastModificationDate
	// TODO TEST getDeclarationsLandUses
	// TODO TEST getDeclarationsParcels
	// TODO TEST updateDeclaration
	// TODO TEST getPlotLifecycle
	// TODO TEST getLandUseCodes
	// TODO TEST getCropPlanTypeCodeLandUseCodesV1_1
	// TODO TEST getPlotDeclaredAreas

	@Test
	public void whenGetPCFFieldsCodes_thenReturnPCFFieldsCodesKeepingPropertiesUnchanged() throws ParseException {
		List<PermanentCropFormFieldCodes> pcfFieldCodes = new ArrayList<>();
		List<PermanentCropFormFieldValue> pcfFieldValues = new ArrayList<>();
		pcfFieldValues.add(new PermanentCropFormFieldValue("field_code", "field_value", "fv_description"));
		pcfFieldCodes.add(new PermanentCropFormFieldCodes("field_code", pcfFieldValues));
		when(cropPlanService.getPermanentCropFormFieldsCodes(any(), anyLong(), any()))
				.thenReturn(pcfFieldCodes);

		var res = EXT.target("_/public/v1/crop-plans/1/plans/2/permanent-crop-form/fields-codes/FORM_TYPE")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<ArrayList<PermanentCropFormFieldCodesTestModel>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<PermanentCropFormFieldCodesTestModel>> violations = validator.validate(res.get(0));
		assertEquals(violations.size(), 0);
	}

	@Test
	public void whenGetCropPlanAnomalies_thenReturnCropPlanAnomaliesKeepingPropertiesUnchanged() throws ParseException {
		List<ValidationAnomaly> anomalies = new ArrayList<>();
		anomalies.add(getMockedAnomaly(AnomalyObjectType.PLOT));
		var ret = new InfiniteListResultsImpl<>(anomalies, null);
		when(cropPlanService.getCropPlanAnomalies(any(), any(), any(), any(), anyInt()))
				.thenReturn(ret);

		var res = EXT.target("_/public/v1/crop-plans/1/plans/2/anomalies")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<InfiniteListResultTestModel<ValidationAnomalyTestModel>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<ValidationAnomalyTestModel>> violations = validator.validate(res.getRecords().get(0));
		assertEquals(violations.size(), 0);
	}

	@Test
	public void whenGetGroupedCropPlanAnomalies_thenReturnGroupedCropPlanAnomaliesKeepingPropertiesUnchanged() throws ParseException {
		List<ValidationAnomalies.ValidationAnomalyByType> anomaliesByType = new ArrayList<>();
		anomaliesByType.add(new ValidationAnomalies.ValidationAnomalyByType(2, AnomalyObjectType.PLOT, "MY_ERROR_1", "ERR1", true, null, null));
		anomaliesByType.add(new ValidationAnomalies.ValidationAnomalyByType(1, AnomalyObjectType.DECLARATION, "MY_ERROR_2", "ERR2", false, null, null));
		ValidationAnomalies anomalies = new ValidationAnomalies(2, 1, anomaliesByType);

		when(cropPlanService.getGroupedCropPlanAnomalies(any(), any(), anyLong(), any(), anyBoolean()))
				.thenReturn(anomalies);

		var res = EXT.target("_/public/v1/crop-plans/1/plans/2/grouped-anomalies")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<ValidationAnomaliesTestModel>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<ValidationAnomaliesTestModel>> violations = validator.validate(res);
		assertEquals(violations.size(), 0);
	}

	@Test
	public void whenGetChangedPlots_thenReturnChangedPlotsKeepingPropertiesUnchanged() throws ParseException {
		List<ChangedPlot> plots = new ArrayList<>();
		var geom = (Polygon) wktReader.read("POLYGON ((430 450, 370 350, 470 340, 550 410, 520 490, 430 450))");
		plots.add(new ChangedPlot("plot_code", geom, "EPSG:3857", "A061", "A061", true, "descr"));
		var ret = new InfiniteListResultsImpl<>(plots, null);
		when(cropPlanService.getChangedPlots(any(), any(), any(), any(), any(), anyInt(), anyBoolean()))
				.thenReturn(ret);

		var res = EXT.target("_/public/v1/crop-plans/1/plans/2/changed-plots")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<InfiniteListResultTestModel<ChangedPlotTestModel>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<ChangedPlotTestModel>> violations = validator.validate(res.getRecords().get(0));
		assertEquals(violations.size(), 0);
	}

	@Test
	public void whenGetPermanentCropFormSubscriptions_thenReturnPermanentCropFormSubscriptionsKeepingPropertiesUnchanged() throws ParseException {
		List<PermanentCropFormSubscription> subs = new ArrayList<>();
		subs.add(new PermanentCropFormSubscription("sub_code", "sub_descr", List.of(new PermanentCropFormSubscriptionField("field_label", "field_value"))));
		when(cropPlanService.getPermanentCropFormSubscriptions(any(), any(), anyLong(), any()))
				.thenReturn(subs);

		GetPermanentCropFormSubscriptionsPayload payload = new GetPermanentCropFormSubscriptionsPayload();
		payload.setSubscriptionCodes(Arrays.asList("sub_code"));

		var res = EXT.target("_/public/v1/crop-plans/1/plans/2/subscriptions")
				.queryParam("subscriptionCodes", "sub_code")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.post(Entity.json(payload), new GenericType<ArrayList<PermanentCropFormSubscriptionTestModel>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<PermanentCropFormSubscriptionTestModel>> violations = validator.validate(res.get(0));
		assertEquals(violations.size(), 0);
	}
	
	// TODO TEST getCropPlanDates
	// TODO TEST getPlotTimeline
	
	private CropPlan getMockedCropPlan() {
		var cropPlan = new CropPlan();
		cropPlan.setChangesPending(false);
		cropPlan.setCropPlanId(1l);
		cropPlan.setCropPlanTypeCode("cp_type_code");
		cropPlan.setCropPlanTypeDescription("cp_type_description");
		cropPlan.setDescription("cp_descr");
		cropPlan.setReadOnly(false);
		cropPlan.setLocked(false);
		cropPlan.setLockedErrorCode("NO_ERROR");
		cropPlan.setCanAddPlots(true);
		cropPlan.setCropPlanPrints(List.of(new CropPlanPrint("print_code", "print_description")));
		return cropPlan;
	}

	private Plot getMockedPlot() throws ParseException {
		var style = new Style("#FF0000", "stroke", "#0000FF");
		var fromDate = AbsoluteDate.of("20220101");
		var toDate = END_OF_WORLD;

		List<ParcelIntersection> parcels = new ArrayList<>();
		var parcel = new ParcelIntersection();
		parcel.setAreaSqm(1);
		parcel.setCode("parcel_code");
		parcel.setDescription("parcel_descr");
		parcel.setParcelCode("parcel_descr");
		parcel.setNotes("notes");
		parcel.setLandCoverCode("lcc");
		parcel.setLandCoverDescription("lcc_descr");
		parcel.setHoldingPercentage(100.0);
		
		List<ValidationAnomaly> parcelAnomalies = new ArrayList<>();
		parcelAnomalies.add(getMockedAnomaly(AnomalyObjectType.PARCEL));
		parcel.setAnomalies(parcelAnomalies);

		parcels.add(parcel);

		var geom = (Polygon) wktReader.read("POLYGON ((430 450, 370 350, 470 340, 550 410, 520 490, 430 450))");
		var mbr = (Polygon) wktReader.read("POLYGON ((370 340, 550 340, 550 490, 370 490, 370 340))");

		List<Declaration> decls = new ArrayList<>();
		var landUse = new LandUse("lu_code", "lu_descr");

		List<PermanentCropForm> pcfs = new ArrayList<>();
		var permanentCropFormData = new PermanentCropFormData();
		permanentCropFormData.setAreaSqm(10);
		permanentCropFormData.setDistanceOnTheRowCm(3D);
		permanentCropFormData.setDistanceBetweenRowsCm(2D);
		permanentCropFormData.setStumpsNumber(5);
		permanentCropFormData.setFarmingForm("002");
		permanentCropFormData.setIrrigation("1");
		permanentCropFormData.setProductDestinationCode("1");
		permanentCropFormData.setCultivationTypeCode("1");
		permanentCropFormData.setVarietyCode("010");
		permanentCropFormData.setVariationTypeCode("1");
		permanentCropFormData.setVineyardTypeCode("1");
		permanentCropFormData.setPlantingType("1");
		permanentCropFormData.setLayering("1");
		permanentCropFormData.setRock("M");
		permanentCropFormData.setSkeleton("1");
		permanentCropFormData.setVegetativeState("B");
		permanentCropFormData.setPruning("A");
		permanentCropFormData.setJudgement("B");
		permanentCropFormData.setStumpsDensity100(100D);
		permanentCropFormData.setFailuresPerc(1D);
		permanentCropFormData.setSoilLayeringPerc(1D);
		permanentCropFormData.setAltitudeAboveSeaLevel(100D);
		permanentCropFormData.setTerracing("1");
		permanentCropFormData.setHeaderAnchoring("1");
		permanentCropFormData.setPolesHeader("1");
		permanentCropFormData.setPolesWeaving("1");
		permanentCropFormData.setPolesDistanceCm(1D);
		permanentCropFormData.setSupportWires("1");
		permanentCropFormData.setCultivationState("1");
		permanentCropFormData.setOrigin("H");
		permanentCropFormData.setGraftDate(LocalDateTime.now());
		permanentCropFormData.setGraftHolder("1");
		permanentCropFormData.setCovering("X");
		permanentCropFormData.setBio("1");
		permanentCropFormData.setSubscriptionCodes("sub_code");
		permanentCropFormData.setExternalCode("external_code");
		permanentCropFormData.setExternalDescription("external_description");
		permanentCropFormData.setQualitySystem("X");
		permanentCropFormData.setProtectionStructures("Y");
		pcfs.add(new PermanentCropForm("form_code", "form_type", permanentCropFormData));

		List<ValidationAnomaly> declAnomalies = new ArrayList<>();
		declAnomalies.add(getMockedAnomaly(AnomalyObjectType.DECLARATION));

		List<PesticideEntry> pesticides = new ArrayList<>();
		var pesticide = new PesticideEntry("code", 1L, "code", "code", "code", "code", 1L, AbsoluteDate.of("20220101"), "name", "label", "admin",
				new BaseDeclaration(), parcels, 0);

		pesticides.add(pesticide);
		
		List<LandUseAdditionalDataField> fieldsCodes = new ArrayList<>();
		fieldsCodes.add(LandUseAdditionalDataField.builder()
					.fieldCode("IRRIGATION_TYPE")
					.fieldDescription("Tipo Irrigazione")
					.dayFrom(UNIX_START_DATE)
					.dayTo(END_OF_WORLD)
					.sortOrder(1)
					.value("FLOOD")
					.valueDescription("a scorrimento")
				.build()
			);
		

		decls.add(new Declaration(1l, "decl_code", landUse, 100d, style, fromDate, "YMD", toDate, pcfs, declAnomalies, pesticides, fieldsCodes));

		List<ValidationAnomaly> plotAnomalies = new ArrayList<>();
		plotAnomalies.add(getMockedAnomaly(AnomalyObjectType.PLOT));

		return new Plot(1l, "plot_code", "A123", "plot_descr", "notes", parcels, 10, geom, "EPSG:3857", mbr, decls, style, fromDate, toDate, fromDate, toDate, PlotEditability.EDITABLE, plotAnomalies);
	}

	private ValidationAnomaly getMockedAnomaly(AnomalyObjectType type) {
		var anomaly = new ValidationAnomaly();
		anomaly.setBlocking(true);
		anomaly.setErrorCode("MY_ERROR");
		anomaly.setErrorDescription("MY_ERROR_DESCRIPTION");
		anomaly.setObjectCode("1");
		anomaly.setObjectType(type);
		return anomaly;
	}
}
