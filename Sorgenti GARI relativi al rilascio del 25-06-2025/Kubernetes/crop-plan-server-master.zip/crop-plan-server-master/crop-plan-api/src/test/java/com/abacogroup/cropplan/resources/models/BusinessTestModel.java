package com.abacogroup.cropplan.resources.models;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BusinessTestModel
{
	@NotEmpty
	private String businessId;
	
	@NotEmpty
	private String code;
	
	@NotEmpty
	private String description;
}
