package com.abacogroup.cropplan.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.abacogroup.cropplan.api.CropPlan;
import com.abacogroup.cropplan.api.EditPlotPreviewResult;
import com.abacogroup.cropplan.api.PlotPreview;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.auth.MyBasicAuthenticator;
import com.abacogroup.cropplan.resources.auth.MyBasicAuthorizer;
import com.abacogroup.cropplan.resources.providers.LocalDateTimeProvider;
import com.abacogroup.cropplan.resources.pub.PublicTenantCropPlanResources;
import com.abacogroup.cropplan.sdk.jackson.WKTGeometryDeserializer;
import com.abacogroup.cropplan.sdk.jackson.WKTGeometrySerializer;
import com.abacogroup.cropplan.sdk.model.auth.CropPlanTypeAccessLevel;
import com.abacogroup.cropplan.sdk.spi.CropPlanPlugin;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.plugins.impl.EnvironmentFactory;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import io.dropwizard.auth.AuthDynamicFeature;
import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.auth.basic.BasicCredentialAuthFilter;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import java.util.ArrayList;
import java.util.List;
import org.glassfish.jersey.test.grizzly.GrizzlyWebTestContainerFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryCollection;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;

@ExtendWith(DropwizardExtensionsSupport.class)
public class DomainSitiTest {
	private static BaseService baseService = mock(BaseService.class);
	private static CropPlanService cropPlanService = mock(CropPlanService.class);
	private static CropPlanDeclarationsService cropPlanDeclarationsService = mock(CropPlanDeclarationsService.class);
	private static SyncService syncService = mock(SyncService.class);
	private static CropPlansDAO cropPlansDAO = mock(CropPlansDAO.class);
	private static CropPlanConfigDAO crplConfigDAO = mock(CropPlanConfigDAO.class);
	private static LocksService locksService = mock(LocksService.class);
	private static DeclarationService declarationService = mock(DeclarationService.class);
	private static CropCodeService cropCodeService = mock(CropCodeService.class);
	private static ValidatorService validatorService = mock(ValidatorService.class);
	private static PluginManager pluginManager = mock(PluginManager.class);
	private static CropPlanPlugin cropPlanPlugin = mock(CropPlanPlugin.class);
	private static ObjectMapper mapper = createMapper();
	private static PlotEditService plotEditService = mock(PlotEditService.class);
	private static PrintService printService = mock(PrintService.class);

	private static DAOContainer daoContainer = DAOContainer.builder()
			.cropPlansDAO(cropPlansDAO)
			.cropPlanConfigDAO(crplConfigDAO)
			.build();

	private static final ResourceExtension EXT = ResourceExtension.builder()
			.setTestContainerFactory(new GrizzlyWebTestContainerFactory())
			.addProvider(new AuthDynamicFeature(new BasicCredentialAuthFilter.Builder<User>()
					.setAuthenticator(new MyBasicAuthenticator())
					.setAuthorizer(new MyBasicAuthorizer())
					.buildAuthFilter()))
			.addProvider(new AuthValueFactoryProvider.Binder<>(User.class))
			.addProvider(LocalDateTimeProvider.class)
			.addResource(new PublicTenantCropPlanResources(baseService, cropPlanService, cropPlanDeclarationsService, declarationService, syncService, locksService, cropCodeService,
					validatorService, mock(), printService, pluginManager, daoContainer))
			.addProvider(baseService)
			.setMapper(mapper)
			.build();

	private static WKTReader wktReader = new WKTReader();

	public static ObjectMapper createMapper() {
		ObjectMapper objectMapper = new ObjectMapper()
				.findAndRegisterModules()
				.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true);

		SimpleModule module = new SimpleModule("custom-deserializers", com.fasterxml.jackson.core.Version.unknownVersion());
		module.addSerializer(Geometry.class, new WKTGeometrySerializer());
		module.addDeserializer(Geometry.class, new WKTGeometryDeserializer());
		objectMapper.registerModule(module);

		return objectMapper;
	}

	@BeforeEach
	public void init() {
		var envFactory = mock(EnvironmentFactory.class);
		when(baseService.getEnvironmentFactory())
				.thenReturn(envFactory);
		var env = mock(RuntimeEnvironment.class);
		when(envFactory.create(any(), any()))
				.thenReturn(env);
		when(env.getTenantId())
				.thenReturn("_");

		when(baseService.canRead(any(), any(), any()))
				.thenReturn(true);
		when(cropPlanService.getAccessLevel(any(), any(), any()))
				.thenReturn(CropPlanTypeAccessLevel.CREATE);
		when(cropPlanService.getCropPlan(any(), any(), anyLong()))
				.thenReturn(new CropPlan());
		when(cropPlanService.getCropPlanTypeCode(any(), any(), anyLong()))
				.thenReturn(new String());
		when(pluginManager.getCropPlanPlugin(any(), anyLong(), any()))
				.thenReturn(cropPlanPlugin);

		when(locksService.hasLock(any(), anyLong()))
				.thenReturn(true);
	}
	
	@Test
	public void whenGetPlotsPreview_thenReturnPlotPreviewKeepingPropertiesUnchanged() throws ParseException {
		EditPlotPreviewResult editPlotPreviewResult = new EditPlotPreviewResult();
		List<PlotPreview> added = new ArrayList<PlotPreview>();
		PlotPreview plotPreview = new PlotPreview();
		plotPreview.setPlotCode("Test");
		GeometryCollection geom = (GeometryCollection) wktReader.read("GEOMETRYCOLLECTION (POLYGON ((47873.3 73139, 47871.35 73134.9, 47874.45 73127, 47881.9 73131.7, 47879 73137, 47877.4 73138.65, 47873.3 73139)), \n"
				+ "  LINESTRING (47875.55 73137.15, 47875.05 73129.7, 47878 73134))");
		plotPreview.setGeom(geom);
		added.add(plotPreview);
		editPlotPreviewResult.setAdded(added);
		when(plotEditService.createPlotPreview(any(), any(), any())
				)
				.thenReturn(editPlotPreviewResult);

		var result = plotEditService.createPlotPreview(any(), any(), any());

		assertNotNull(result);
		assertEquals(1, result.getAdded().size());
	}
	
	
}
