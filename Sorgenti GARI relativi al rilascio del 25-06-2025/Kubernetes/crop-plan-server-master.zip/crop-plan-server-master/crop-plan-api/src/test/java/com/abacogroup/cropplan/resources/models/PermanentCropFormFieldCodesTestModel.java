package com.abacogroup.cropplan.resources.models;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PermanentCropFormFieldCodesTestModel
{
	@NotNull
	private String fieldCode;

	@Valid
	@NotEmpty
	private List<PermanentCropFormFieldValueTestModel> fieldValues;
}
