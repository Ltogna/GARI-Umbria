package com.abacogroup.cropplan.resources.models;

import java.util.List;
import java.util.function.Function;

import com.abacogroup.jdbi.paging.MaxRowsResults;

import lombok.Data;

@Data
public class MaxRowsResultsTestModel<T> implements MaxRowsResults<T>
{
	private int count;
	private boolean haveMore;
	private List<T> records;

	@Override
	public <M> MaxRowsResultsTestModel<M> map(Function<T, M> mapper)
	{
		return null;
	}

	@Override
	public boolean getHaveMore()
	{
		return haveMore;
	}
}
