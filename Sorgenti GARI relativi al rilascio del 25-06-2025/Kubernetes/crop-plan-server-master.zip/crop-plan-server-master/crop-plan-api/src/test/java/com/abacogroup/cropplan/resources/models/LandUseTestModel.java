package com.abacogroup.cropplan.resources.models;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LandUseTestModel
{
	@NotNull
	private String code;

	@NotNull
	private String description;
}
