package com.abacogroup.cropplan.db;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;

import com.abacogroup.cropplan.api.CutBehaviour;
import com.abacogroup.cropplan.api.payload.DrawLineBufferPayload.LineBufferBehaviour;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.PlotEditDAO;
import com.abacogroup.cropplan.db.dao.SubdomainZoneDAO;
import com.abacogroup.cropplan.db.dao.ntt.PlotGeometryInSubdomain;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandCoverClassEditability;
import com.abacogroup.cropplan.sdk.spi.CropCodesPlugin;
import com.abacogroup.cropplan.sdk.spi.DomainPlugin;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.support.EditorSupportParams;
import com.abacogroup.geometryeditor.EditorSupport.InvolvedPolygons;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;

@ExtendWith(DropwizardExtensionsSupport.class)
class EditorSupportImplTest {

	private PlotEditDAO plotEditDAO = mock(PlotEditDAO.class);
	private CropPlansDAO cropPlansDAO = mock(CropPlansDAO.class);
	private SubdomainZoneDAO subdomainZoneDAO = mock(SubdomainZoneDAO.class);
	private DomainPlugin domainPlugin = mock(DomainPlugin.class);
	private CropCodesPlugin cropCodesPlugin = mock(CropCodesPlugin.class);
	private CropPlanConfigService cropPlanConfigService = mock(CropPlanConfigService.class);

	private WKTReader reader = new WKTReader();

	private EditorSupportImpl getEditorSupport(EditorSupportParams editorSupportParams, CutBehaviour cutBehaviour, LineBufferBehaviour lineBufferBehaviour,
			Map<String, Polygon> cutPolygons, AbsoluteDate snapFromDate, Boolean isForPreview) {
		return new EditorSupportImpl(
				mock(RuntimeEnvironment.class),
				editorSupportParams,
				cutBehaviour,
				lineBufferBehaviour,
				false,
				cutPolygons,
				editorSupportParams.getPointInTime(),
				snapFromDate,
				isForPreview,
				plotEditDAO,
				cropPlansDAO,
				subdomainZoneDAO,
				domainPlugin,
				cropCodesPlugin, 
				cropPlanConfigService
		);
	}

	// ----- loadPolygonsWithInteraction -----

	/***
	 *  _____________
	 *  |SDZ        |
	 *  |  _________|_____
	 *  |  | 1 || 8 || 7 |
	 *  |  =========|=====
	 *  |  | 2 || X || 6 |
	 *  |__=_=_=_=_=|=====
	 *     | 3 || 4 || 5 |
	 *     ---------------
	 ***/
	@Test
	void test_loadPolygonsWithInteraction_withExistingSubdomainZoneOk() throws ParseException {

		EditorSupportParams editorSupportParams = EditorSupportParams.builder()
				.cropPlanId(123L)
				.domainZoneId("AA00")
				.businessId("555")
				.subdomainZoneId(111L)
				.pointInTime(AbsoluteDate.of("20240515"))
				.build();
		EditorSupportImpl editorSupport = this.getEditorSupport(
				editorSupportParams,
				CutBehaviour.CUT_EXISTING,
				LineBufferBehaviour.INTERNAL,
				null,
				null,
				true
		);

		given(subdomainZoneDAO.findSubdomainZoneGeomById(any()))
				.willReturn(Optional.of(reader.read("POLYGON ((0 500, 300 500, 300 190, 0 190, 0 500))")));
		
		given(plotEditDAO.getPolygonsWithInteractionInSubdomain(any(), any(), any(), any(), any()))
			.willReturn(List.of(
					new PlotGeometryInSubdomain(1L, "1", reader.read("POLYGON ((100 400, 200 400, 200 300, 100 300, 100 400))"), true),
					new PlotGeometryInSubdomain(2L, "2", reader.read("POLYGON ((100 300, 200 300, 200 200, 100 200, 100 300))"), true),
					new PlotGeometryInSubdomain(3L, "3", reader.read("POLYGON ((100 200, 200 200, 200 100, 100 100, 100 200))"), true),
					new PlotGeometryInSubdomain(4L, "4", reader.read("POLYGON ((200 200, 300 200, 300 100, 200 100, 200 200))"), true),
					new PlotGeometryInSubdomain(5L, "5", reader.read("POLYGON ((300 200, 400 200, 400 100, 300 100, 300 200))"), false),
					new PlotGeometryInSubdomain(6L, "6", reader.read("POLYGON ((300 300, 400 300, 400 200, 300 200, 300 300))"), false),
					new PlotGeometryInSubdomain(7L, "7", reader.read("POLYGON ((300 400, 400 400, 400 300, 300 300, 300 400))"), false),
					new PlotGeometryInSubdomain(8L, "8", reader.read("POLYGON ((200 400, 300 400, 300 300, 200 300, 200 400))"), true)
			));
		
		
		
		given(cropPlansDAO.getPlotsParcelsInternal(any(), any(), any()))
				.willReturn(new ArrayList<>());

		given(cropCodesPlugin.getLandCoverEditability(any(), any(), any())).willReturn(LandCoverClassEditability.EDITABLE);

		//tested
		InvolvedPolygons<String> involvedPolygons = editorSupport.loadPolygonsWithInteraction(
				reader.read("POLYGON ((200 300, 300 300, 300 200, 200 200, 200 300))"), null);

		assertThat(involvedPolygons).isNotNull();
		assertThat(involvedPolygons.getModifiablePolygons()).hasSize(5)
				.containsKeys("1", "8", "2", "3", "4");
		assertThat(involvedPolygons.getUnmodifiablePolygons()).hasSize(3)
				.containsKeys("7", "6", "5");
	}

	@Test
	void test_loadPolygonsWithInteraction_withNoExistingSubdomainZoneAllUnmodifiable() throws ParseException {

		EditorSupportParams editorSupportParams = EditorSupportParams.builder()
				.cropPlanId(123L)
				.domainZoneId("AA00")
				.businessId("555")
				.subdomainZoneId(111L)
				.pointInTime(AbsoluteDate.of("20240515"))
				.build();
		EditorSupportImpl editorSupport = this.getEditorSupport(
				editorSupportParams,
				CutBehaviour.CUT_EXISTING,
				LineBufferBehaviour.INTERNAL,
				null,
				null,
				true
		);

		given(subdomainZoneDAO.findSubdomainZoneGeomById(any()))
				.willReturn(Optional.empty());
		
		given(plotEditDAO.getPolygonsWithInteractionInSubdomain(any(), any(), any(), any(), any()))
			.willReturn(List.of(
					new PlotGeometryInSubdomain(1L, "1", reader.read("POLYGON ((100 400, 200 400, 200 300, 100 300, 100 400))"), false),
					new PlotGeometryInSubdomain(2L, "2", reader.read("POLYGON ((100 300, 200 300, 200 200, 100 200, 100 300))"), false),
					new PlotGeometryInSubdomain(3L, "3", reader.read("POLYGON ((100 200, 200 200, 200 100, 100 100, 100 200))"), false),
					new PlotGeometryInSubdomain(4L, "4", reader.read("POLYGON ((200 200, 300 200, 300 100, 200 100, 200 200))"), false),
					new PlotGeometryInSubdomain(5L, "5", reader.read("POLYGON ((300 200, 400 200, 400 100, 300 100, 300 200))"), false),
					new PlotGeometryInSubdomain(6L, "6", reader.read("POLYGON ((300 300, 400 300, 400 200, 300 200, 300 300))"), false),
					new PlotGeometryInSubdomain(7L, "7", reader.read("POLYGON ((300 400, 400 400, 400 300, 300 300, 300 400))"), false),
					new PlotGeometryInSubdomain(8L, "8", reader.read("POLYGON ((200 400, 300 400, 300 300, 200 300, 200 400))"), false)
			));
		
		
		given(cropPlansDAO.getPlotsParcelsInternal(any(), any(), any()))
				.willReturn(new ArrayList<>());

		given(cropCodesPlugin.getLandCoverEditability(any(), any(), any())).willReturn(LandCoverClassEditability.EDITABLE);

		//tested
		Geometry touchingGeometry = reader.read("POLYGON ((200 300, 300 300, 300 200, 200 200, 200 300))");
		InvolvedPolygons<String> involvedPolygons = editorSupport.loadPolygonsWithInteraction(touchingGeometry, null);

		assertThat(involvedPolygons).isNotNull();
		assertThat(involvedPolygons.getModifiablePolygons()).isEmpty();
		assertThat(involvedPolygons.getUnmodifiablePolygons()).hasSize(8)
				.containsKeys("1", "8", "2", "3", "4", "7", "6", "5");
		
		verify(plotEditDAO).getPolygonsWithInteractionInSubdomain(123L, "AA00", AbsoluteDate.of("20240515"),
			touchingGeometry, new GeometryFactory().createPolygon());
		
		
	}

	@Test
	void test_loadPolygonsWithInteraction_withNoSubdomainZoneIdAllModifiable() throws ParseException {

		EditorSupportParams editorSupportParams = EditorSupportParams.builder()
				.cropPlanId(123L)
				.domainZoneId("AA00")
				.businessId("555")
				.subdomainZoneId(null)
				.pointInTime(AbsoluteDate.of("20240515"))
				.build();
		EditorSupportImpl editorSupport = this.getEditorSupport(
				editorSupportParams,
				CutBehaviour.CUT_EXISTING,
				LineBufferBehaviour.INTERNAL,
				null,
				null,
				true
		);
		
		given(plotEditDAO.getPolygonsWithInteraction(any(), any(), any(), any()))
			.willReturn(List.of(
					new PlotGeometryInSubdomain(1L, "1", reader.read("POLYGON ((100 400, 200 400, 200 300, 100 300, 100 400))"), true),
					new PlotGeometryInSubdomain(2L, "2", reader.read("POLYGON ((100 300, 200 300, 200 200, 100 200, 100 300))"), true),
					new PlotGeometryInSubdomain(3L, "3", reader.read("POLYGON ((100 200, 200 200, 200 100, 100 100, 100 200))"), true),
					new PlotGeometryInSubdomain(4L, "4", reader.read("POLYGON ((200 200, 300 200, 300 100, 200 100, 200 200))"), true),
					new PlotGeometryInSubdomain(5L, "5", reader.read("POLYGON ((300 200, 400 200, 400 100, 300 100, 300 200))"), true),
					new PlotGeometryInSubdomain(6L, "6", reader.read("POLYGON ((300 300, 400 300, 400 200, 300 200, 300 300))"), true),
					new PlotGeometryInSubdomain(7L, "7", reader.read("POLYGON ((300 400, 400 400, 400 300, 300 300, 300 400))"), true),
					new PlotGeometryInSubdomain(8L, "8", reader.read("POLYGON ((200 400, 300 400, 300 300, 200 300, 200 400))"), true)
			));
		
		

		given(cropPlansDAO.getPlotsParcelsInternal(any(), any(), any()))
				.willReturn(new ArrayList<>());

		given(cropCodesPlugin.getLandCoverEditability(any(), any(), any())).willReturn(LandCoverClassEditability.EDITABLE);

		//tested
		Geometry touchingGeometry = reader.read("POLYGON ((200 300, 300 300, 300 200, 200 200, 200 300))");
		InvolvedPolygons<String> involvedPolygons = editorSupport.loadPolygonsWithInteraction(
				touchingGeometry, null);

		assertThat(involvedPolygons).isNotNull();
		assertThat(involvedPolygons.getModifiablePolygons()).hasSize(8)
				.containsKeys("1", "8", "2", "3", "4", "7", "6", "5");
		assertThat(involvedPolygons.getUnmodifiablePolygons()).isEmpty();

		verifyNoInteractions(subdomainZoneDAO);
		
		verify(plotEditDAO).getPolygonsWithInteraction(123L, "AA00", AbsoluteDate.of("20240515"), touchingGeometry);
		
		
	}
}
