package com.abacogroup.cropplan.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AbsoluteDateTest
{
	private ObjectMapper mapper = new ObjectMapper();

	@Test
	public void deserializesFromString() throws JsonProcessingException
	{
		LocalDate expected = LocalDate.of(2021, 11, 30);
		AbsoluteDate date = mapper.readValue("\"20211130\"", AbsoluteDate.class);
		assertEquals(expected, date.toLocalDate());
	}

	@Test
	public void deserializesFromNull() throws JsonProcessingException
	{
		AbsoluteDate date = mapper.readValue("null", AbsoluteDate.class);
		assertNull(date);
	}

	@Test
	public void serializesToString() throws JsonMappingException, JsonProcessingException
	{
		String expected = "\"20211130\"";
		AbsoluteDate date = AbsoluteDate.of("20211130");
		assertEquals(expected, mapper.writeValueAsString(date));
	}

	@Test
	public void whenBadString_thenRaiseDeserializationError()
	{
		assertThrows(JsonProcessingException.class, () -> {
			mapper.readValue("\"20213011\"", AbsoluteDate.class);
		});
		assertThrows(JsonProcessingException.class, () -> {
			mapper.readValue("\"PIPPO\"", AbsoluteDate.class);
		});
	}	
	
}
