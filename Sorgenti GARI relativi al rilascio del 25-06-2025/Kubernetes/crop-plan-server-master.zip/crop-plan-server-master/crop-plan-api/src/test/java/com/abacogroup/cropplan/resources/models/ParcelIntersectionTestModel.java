package com.abacogroup.cropplan.resources.models;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;

@Data
public class ParcelIntersectionTestModel
{
	@NotNull
	private String code;

	@NotNull
	private String description;

	@NotNull
	private String parcelCode;
	
	@NotNull
	private String notes;

	@NotNull
	private String landCoverCode;

	@NotNull
	private String landCoverDescription;

	@NotNull
	private Integer areaSqm;
	
	private Double holdingPercentage;
	
	@NotEmpty
	private List<ValidationAnomalyTestModel> anomalies;

	private Boolean canDeclarePesticides;
}
