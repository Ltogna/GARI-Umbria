package com.abacogroup.cropplan.resources.models;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PermanentCropFormSubscriptionFieldTestModel
{

	@NotNull
	private String label;

	@NotNull
	private String value;
	
}
