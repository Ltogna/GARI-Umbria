package com.abacogroup.cropplan.resources;

import static com.abacogroup.cropplan.resources.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.time.Month;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;

import com.abacogroup.cropplan.api.SubdomainZoneResponse;
import com.abacogroup.cropplan.api.payload.SubdomainZoneRequest;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.Version;
import com.abacogroup.cropplan.sdk.model.auth.CropPlanTypeAccessLevel;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.cropplan.services.CropPlanDeclarationsService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.LocksService;
import com.abacogroup.cropplan.services.PrintService;
import com.abacogroup.cropplan.services.SyncService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.plugins.impl.EnvironmentFactory;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.UriBuilder;

@ExtendWith(DropwizardExtensionsSupport.class)
class CropPlanResourcesTest {

	private BaseService baseService = mock(BaseService.class);
	private CropPlanService cropPlanService = mock(CropPlanService.class);

	private final CropPlanResources cropPlanResources = new CropPlanResources(
			baseService,
			cropPlanService,
			mock(CropPlanDeclarationsService.class),
			mock(SyncService.class),
			mock(LocksService.class),
			mock(CropCodeService.class),
			mock(ValidatorService.class),
			mock(),
			mock(PrintService.class),
			mock(PluginManager.class),
			DAOContainer.builder()
					.cropPlansDAO(mock(CropPlansDAO.class))
					.build()
	);

	private final ResourceExtension EXT = WebCliHelper.createEXT(cropPlanResources);

	private WKTReader reader;

	@BeforeEach
	void setUp() {
		var envFactory = mock(EnvironmentFactory.class);
		when(baseService.getEnvironmentFactory())
			.thenReturn(envFactory);
		var env = mock(RuntimeEnvironment.class);
		when(envFactory.create(any(), any()))
			.thenReturn(env);
		when(env.getTenantId())
			.thenReturn(TENANT);

		when(baseService.canRead(any(), any(), any()))
				.thenReturn(true);
		when(cropPlanService.getAccessLevel(any(), any(), any()))
				.thenReturn(CropPlanTypeAccessLevel.CREATE);
		given(cropPlanService.getCropPlanTypeCode(any(), any(), any())).willReturn("CROPPLAN");

		reader = new WKTReader();
	}


	// ----- createSubdomainZone -----
	@Test
	void test_createSubdomainZone_ok() throws ParseException {
		String businessId = "555";
		long cropPlanId = 123L;
		String domainZoneId = "AA00";
		LocalDateTime versionDt = LocalDateTime.of(2024, Month.MAY, 24, 10, 26);
		AbsoluteDate pointInTime = AbsoluteDate.of("20240515");

		Geometry geom = reader.read("POLYGON ((000 100, 100 100, 100 000, 000 000, 000 100))");
		SubdomainZoneRequest createReq = new SubdomainZoneRequest(geom);

		UriBuilder uriBuilder = UriBuilder.fromResource(cropPlanResources.getClass()).path(cropPlanResources.getClass(), "createSubdomainZone")
				.queryParam("version", new Version(versionDt).getRawValue())
				.queryParam("pointInTime", pointInTime);
		String uri = StringUtils.prependIfMissing(uriBuilder.build(TENANT, businessId, cropPlanId, domainZoneId).toString(), "/");
		//System.out.println(uri);

		SubdomainZoneResponse mockRes = new SubdomainZoneResponse(999L, geom);
		given(cropPlanService.createSubdomainZone(any(), any(), any(), any(), any(), any(), any()))
				.willReturn(mockRes);

		SubdomainZoneResponse res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header(HttpHeaders.AUTHORIZATION, WebCliHelper.JWT_MOCK_CREDENTIALS)
				.post(Entity.json(createReq), new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(mockRes);

		verify(cropPlanService).createSubdomainZone(any(RuntimeEnvironment.class), eq(businessId), eq(cropPlanId), eq(domainZoneId),
				eq(versionDt), eq(pointInTime), eq(createReq));
	}

	@Test
	void test_createSubdomainZone_emptyPayloadKo() {
		String businessId = "555";
		long cropPlanId = 123L;
		String domainZoneId = "AA00";
		LocalDateTime versionDt = LocalDateTime.of(2024, Month.MAY, 24, 10, 26);
		AbsoluteDate pointInTime = AbsoluteDate.of("20240515");

		SubdomainZoneRequest createReq = new SubdomainZoneRequest();

		UriBuilder uriBuilder = UriBuilder.fromResource(cropPlanResources.getClass()).path(cropPlanResources.getClass(), "createSubdomainZone")
				.queryParam("version", new Version(versionDt).getRawValue())
				.queryParam("pointInTime", pointInTime);
		String uri = StringUtils.prependIfMissing(uriBuilder.build(TENANT, businessId, cropPlanId, domainZoneId).toString(), "/");
		//System.out.println(uri);

		int status = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header(HttpHeaders.AUTHORIZATION, WebCliHelper.JWT_MOCK_CREDENTIALS)
				.post(Entity.json(createReq)).getStatus();

		assertThat(status).isEqualTo(422);

		verify(cropPlanService, never()).createSubdomainZone(any(), any(), any(), any(), any(), any(), any());
	}
}
