package com.abacogroup.cropplan.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;
import org.mockito.ArgumentMatchers;

import com.abacogroup.cropplan.EditorSupportTestImpl;
import com.abacogroup.cropplan.RuntimeEnvironmentImpl;
import com.abacogroup.cropplan.api.CutBehaviour;
import com.abacogroup.cropplan.api.payload.CutPlotsByLinePayload;
import com.abacogroup.cropplan.api.payload.CutPlotsByLinePayload.LineCutParameters;
import com.abacogroup.cropplan.api.payload.DrawLineBufferPayload.LineBufferBehaviour;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.PlotEditDAO;
import com.abacogroup.cropplan.db.dao.SyncDAO;
import com.abacogroup.cropplan.db.dao.ntt.CropPlanTypeEditorParams;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.services.support.EditorSupportParams;
import com.abacogroup.geometryeditor.EditorSupport;
import com.abacogroup.geometryeditor.EditorSupport.InvolvedPolygons;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

public class PlotEditServiceTest
{
	private CropPlanConfigService cropPlanConfigService;
	private CropPlanService cropPlanService;
	private CropPlanDeclarationsService cropPlanDeclarationsService;
	private DeclarationService declarationService;
	private PropagationService propagationService;
	private ValidatorService validatorService;
	private PlotEditDAO plotEditDAO;
	private CropPlansDAO cropPlansDAO;
	private CropPlanConfigDAO cropPlanConfigDAO;
	private SyncDAO syncDAO;
	private EditorSupport<String> editorSupport;

	private PlotEditService plotEditService;

	private WKTReader wktReader = new WKTReader();

	@BeforeEach
	public void init()
	{
		cropPlanService = mock(CropPlanService.class);
		cropPlanDeclarationsService = mock(CropPlanDeclarationsService.class);
		declarationService = mock(DeclarationService.class);
		propagationService = mock(PropagationService.class);
		validatorService = mock(ValidatorService.class);
		plotEditDAO = mock(PlotEditDAO.class);
		cropPlansDAO = mock(CropPlansDAO.class);
		cropPlanConfigDAO = mock(CropPlanConfigDAO.class);
		syncDAO = mock(SyncDAO.class);
		editorSupport = mock(EditorSupportTestImpl.class);

		when(plotEditDAO.getCurrentTimestamp()).thenReturn(LocalDateTime.now());
		when(plotEditDAO.getCropPlanTypeEditorParams(ArgumentMatchers.anyLong(), ArgumentMatchers.anyString())).thenReturn(new CropPlanTypeEditorParams(true, true));

		when(editorSupport.createPolygonKeys(ArgumentMatchers.anyCollection())).thenCallRealMethod();
		when(editorSupport.createPolygonKeys(ArgumentMatchers.anyString(), ArgumentMatchers.anyCollection())).thenCallRealMethod();

		DAOContainer daoContainer = DAOContainer.builder()
				.cropPlansDAO(cropPlansDAO)
				.cropPlanConfigDAO(cropPlanConfigDAO)
				.plotEditDAO(plotEditDAO)
				.syncDAO(syncDAO)
				.build();

		plotEditService = new PlotEditService(cropPlanConfigService, cropPlanService, cropPlanDeclarationsService, declarationService, propagationService, validatorService,
				//TODO: Check if this test still passes, is RuntimeEnvironmentImpl correct here?
				daoContainer, new PluginManager(new RuntimeEnvironmentImpl(), cropPlansDAO));

		plotEditService.setEditorSupportFactory((RuntimeEnvironment env, EditorSupportParams params, CutBehaviour cutBehaviour, LineBufferBehaviour lineBufferBehaviour, 
				boolean ignoreEditability, Map<String, Polygon> cutPolygons, AbsoluteDate pointInTime, boolean isForPreview) -> {
			return editorSupport;
		});
	}

	@Test
	public void whenCutPlotsByLinePreview_thenReturnTwoPolygons() throws ParseException
	{
		var env = new RuntimeEnvironmentImpl();
		var businessId = "1";
		var cropPlanId = 2L;
		var domainZoneId = "A123";
		var payload = new CutPlotsByLinePayload(AbsoluteDate.of("20220101"), null,
			wktReader.read("LINESTRING (411 295, 460 420, 635 481)"), new LineCutParameters(null));

		var geom = (Polygon) wktReader.read("POLYGON ((430 450, 370 350, 470 340, 550 410, 520 490, 430 450))");
		var map = new HashMap<String, Polygon>();
		map.put("123", geom);
		when(editorSupport.loadPolygonsWithInteraction(ArgumentMatchers.any(), ArgumentMatchers.any()))
			.thenReturn(new InvolvedPolygons<>(map, new HashMap<String, Polygon>()));

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(AbsoluteDate.of("20220101"))
			.build();
		var result = plotEditService.cutPlotsByLinePreview(env, params, payload);
		assertNotNull(result);
		assertEquals(1, result.getAdded().size());
		assertEquals(1, result.getUpdated().size());
		assertEquals(0, result.getDeleted().size());
	}
}
