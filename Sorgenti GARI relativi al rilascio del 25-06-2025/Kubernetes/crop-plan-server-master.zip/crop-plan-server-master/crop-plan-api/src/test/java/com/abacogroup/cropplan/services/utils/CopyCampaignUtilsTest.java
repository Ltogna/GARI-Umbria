package com.abacogroup.cropplan.services.utils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.groups.Tuple.tuple;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Polygonal;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;
import org.mockito.ArgumentCaptor;

import com.abacogroup.cropplan.RuntimeEnvironmentImpl;
import com.abacogroup.cropplan.api.CropPlanDates;
import com.abacogroup.cropplan.api.EditPlotResult;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.payload.CopyCampaignPayload;
import com.abacogroup.cropplan.api.payload.InsertPermanentCropForm;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import com.abacogroup.cropplan.sdk.model.PermanentCropForm;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormData;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseDetails;
import com.abacogroup.cropplan.sdk.model.domain.Parcel;
import com.abacogroup.cropplan.sdk.spi.CropCodesPlugin;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.PlotEditService;
import com.abacogroup.cropplan.services.support.EditorSupportParams;
import com.abacogroup.geometryeditor.op.Utils;

class CopyCampaignUtilsTest {

	private CropPlansDAO cropPlansDAO = mock(CropPlansDAO.class);

	private PlotEditService plotEditService = mock(PlotEditService.class);
	private CropCodeService cropCodeService = mock(CropCodeService.class);
	private CropPlanConfigService cropPlanConfigService = mock(CropPlanConfigService.class);

	private PluginManager pluginManager = mock(PluginManager.class);
	private CropCodesPlugin cropCodesPlugin = mock(CropCodesPlugin.class);

	private WKTReader reader = new WKTReader();

	private CopyCampaignUtils copyCampaignUtils = new CopyCampaignUtils(cropPlansDAO, plotEditService, cropCodeService, cropPlanConfigService, pluginManager);

	// ----- aggregatePlots -----
	@Test
	void test_aggregatePlots_ok() throws Exception {

		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		String businessId = "555";
		long cropPlanId = 123L;

		CopyCampaignPayload payload = CopyCampaignPayload.builder()
				.sourcePointInTime(AbsoluteDate.of("20240515"))
				.landuseCodesExcludedFromAggregation(List.of(
						"XXX-111-111-111-111",
						"XXX-222-222-222-222",
						"XXX-333-333-333-333"
				))
				.build();

		// geom-luc
		//*********************************//
		//*                               *//
		//*   _________________________   *//
		//*   | 10C <| 7C || 8B || 9A |   *//
		//*   -------==================   *//
		//*          | 4B || 5X || 6X |   *//
		//*          ==================-  *//
		//*          | 1A || 2A || 3A  |  *//
		//*          ------|    ||     |  *//
		//*                |    |-------  *//
		//*                |    |         *//
		//*                ------         *//
		//*                               *//
		//*********************************//
		Map<String, Geometry> polygons = getPolygons();
		Iterator<String> lucs = List.of(
				"AAA-000-000-000-000",
				"AAA-000-000-000-000",
				"AAA-000-000-000-000",
				"BBB-000-000-000-000",
				"XXX-111-111-111-111",
				"XXX-111-111-111-111",
				"CCC-000-000-000-000",
				"BBB-000-000-000-000",
				"AAA-000-000-000-000",
				"CCC-000-000-000-000"
		).iterator();
		List<Plot> previousPlots = polygons.entrySet().stream()
				.sorted(Entry.comparingByKey())
				.map(e -> Plot.builder()
						.plotCode(e.getKey())
						.geom(e.getValue())
						.decls(List.of(Declaration.builder().landuse(new LandUse(lucs.next(), "")).fromDate(AbsoluteDate.of("19700101")).build()))
						.build())
				.collect(Collectors.toList());

		given(pluginManager.getCropCodesPlugin(any(), any(), any())).willReturn(cropCodesPlugin);
		given(cropCodesPlugin.canAggregate(any(), any(), any(), any()))
				.willAnswer(i -> ((List<Declaration>) i.getArgument(2)).get(0).getLanduse().getCode()
						.equals(((List<Declaration>) i.getArgument(3)).get(0).getLanduse().getCode()));

		// test
		List<Plot> aggregatedPlots = copyCampaignUtils.aggregatePlots(env, businessId, cropPlanId, payload, previousPlots);

		assertThat(aggregatedPlots).hasSize(8)
				.extracting(Plot::getPlotCode, plot -> plot.getGeom().getArea())
				.containsExactlyInAnyOrder(
						tuple("p002", polygons.get("p001").getArea()+polygons.get("p002").getArea()+polygons.get("p003").getArea()),
						tuple("p004", polygons.get("p004").getArea()),
						tuple("p005", polygons.get("p005").getArea()),
						tuple("p006", polygons.get("p006").getArea()),
						tuple("p007", polygons.get("p007").getArea()),
						tuple("p008", polygons.get("p008").getArea()),
						tuple("p009", polygons.get("p009").getArea()),
						tuple("p010", polygons.get("p010").getArea())
				);

	}

	@Test
	void test_aggregatePlots_empty_ok() throws Exception {

		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		String businessId = "555";
		long cropPlanId = 123L;

		CopyCampaignPayload payload = CopyCampaignPayload.builder()
				.sourcePointInTime(AbsoluteDate.of("20240515"))
				.landuseCodesExcludedFromAggregation(List.of(
						"XXX-111-111-111-111",
						"XXX-222-222-222-222",
						"XXX-333-333-333-333"
				))
				.build();

		List<Plot> previousPlots = new ArrayList<>();

		given(pluginManager.getCropCodesPlugin(any(), any(), any())).willReturn(cropCodesPlugin);
		given(cropCodesPlugin.canAggregate(any(), any(), any(), any()))
				.willAnswer(i -> ((List<Declaration>) i.getArgument(2)).get(0).getLanduse().getCode()
						.equals(((List<Declaration>) i.getArgument(3)).get(0).getLanduse().getCode()));

		// test
		List<Plot> aggregatedPlots = copyCampaignUtils.aggregatePlots(env, businessId, cropPlanId, payload, previousPlots);

		assertThat(aggregatedPlots).isEmpty();

	}

	@Test
	void test_aggregatePlots_single_ok() throws Exception {

		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		String businessId = "555";
		long cropPlanId = 123L;

		CopyCampaignPayload payload = CopyCampaignPayload.builder()
				.sourcePointInTime(AbsoluteDate.of("20240515"))
				.landuseCodesExcludedFromAggregation(List.of(
						"XXX-111-111-111-111",
						"XXX-222-222-222-222",
						"XXX-333-333-333-333"
				))
				.build();

		Map<String, Geometry> polygons = getPolygons();
		List<Plot> previousPlots = List.of(Plot.builder()
				.plotCode("p001")
				.geom(polygons.get("p001"))
				.decls(List.of(Declaration.builder().landuse(new LandUse("AAA-000-000-000-000", ""))
						.fromDate(AbsoluteDate.of("19700101")).build()))
				.build());

		given(pluginManager.getCropCodesPlugin(any(), any(), any())).willReturn(cropCodesPlugin);
		given(cropCodesPlugin.canAggregate(any(), any(), any(), any()))
				.willAnswer(i -> ((List<Declaration>) i.getArgument(2)).get(0).getLanduse().getCode()
						.equals(((List<Declaration>) i.getArgument(3)).get(0).getLanduse().getCode()));

		// test
		List<Plot> aggregatedPlots = copyCampaignUtils.aggregatePlots(env, businessId, cropPlanId, payload, previousPlots);

		assertThat(aggregatedPlots).hasSize(1)
				.isEqualTo(previousPlots);

	}

	@Test
	void test_aggregatePlots_thirdCropExcludedIgnoredOk() throws Exception {

		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		String businessId = "555";
		long cropPlanId = 123L;

		CopyCampaignPayload payload = CopyCampaignPayload.builder()
				.sourcePointInTime(AbsoluteDate.of("20240515"))
				.landuseCodesExcludedFromAggregation(List.of(
						"XXX-111-111-111-111",
						"XXX-222-222-222-222",
						"XXX-333-333-333-333"
				))
				.build();

		Map<String, Geometry> polygons = getPolygons();
		List<Plot> previousPlots = List.of(
				Plot.builder().plotCode("p001")
						.geom(polygons.get("p001"))
						.decls(List.of(
								Declaration.builder().fromDate(AbsoluteDate.of("19700101")).toDate(AbsoluteDate.of("20240601"))
										.landuse(new LandUse("AAA-000-000-000-000", "")).build(),
								Declaration.builder().fromDate(AbsoluteDate.of("20240601")).toDate(AbsoluteDate.of("20240731"))
										.landuse(new LandUse("BBB-000-000-000-000", "")).build(),
								Declaration.builder().fromDate(AbsoluteDate.of("20240801")).toDate(AbsoluteDate.of("99991231"))
										.landuse(new LandUse("XXX-333-333-333-333", "")).build()
						)).build(),
				Plot.builder().plotCode("p002")
						.geom(polygons.get("p002"))
						.decls(List.of(
								Declaration.builder().fromDate(AbsoluteDate.of("19700101")).toDate(AbsoluteDate.of("20240601"))
										.landuse(new LandUse("AAA-000-000-000-000", "")).build(),
								Declaration.builder().fromDate(AbsoluteDate.of("20240601")).toDate(AbsoluteDate.of("20240731"))
										.landuse(new LandUse("BBB-000-000-000-000", "")).build(),
								Declaration.builder().fromDate(AbsoluteDate.of("20240801")).toDate(AbsoluteDate.of("99991231"))
										.landuse(new LandUse("XXX-333-333-333-333", "")).build()
						)).build(),
				Plot.builder().plotCode("p003") // poligono di controllo
						.geom(polygons.get("p003"))
						.decls(List.of(
								Declaration.builder().fromDate(AbsoluteDate.of("19700101")).toDate(AbsoluteDate.of("20240601"))
										.landuse(new LandUse("AAA-000-000-000-000", "")).build(),
								Declaration.builder().fromDate(AbsoluteDate.of("20240801")).toDate(AbsoluteDate.of("99991231"))
										.landuse(new LandUse("XXX-333-333-333-333", "")).build()
						)).build()
		);

		given(pluginManager.getCropCodesPlugin(any(), any(), any())).willReturn(cropCodesPlugin);
		given(cropCodesPlugin.canAggregate(any(), any(), any(), any())).willReturn(true);

		// test
		List<Plot> aggregatedPlots = copyCampaignUtils.aggregatePlots(env, businessId, cropPlanId, payload, previousPlots);

		assertThat(aggregatedPlots).hasSize(2)
				.extracting(Plot::getPlotCode, plot -> plot.getGeom().getArea())
				.containsExactlyInAnyOrder(
						tuple("p002", polygons.get("p001").getArea()+polygons.get("p002").getArea()),
						tuple("p003", polygons.get("p003").getArea())
				);


	}

	// ----- copyDeclarationsOnPlot -----
	@Test
	void test_copyDeclarationsOnPlot_ok() throws Exception {
		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		String businessId = "555";
		long cropPlanId = 123L;
		String plotCode = "p001";
		AbsoluteDate plotFromDate = AbsoluteDate.of("20240601");
		AbsoluteDate plotToDate = AbsoluteDate.of("20251001");
		AbsoluteDate pointInTime = AbsoluteDate.of("20240515");
		LocalDateTime currentDate = LocalDateTime.of(2025, 05, 06, 17, 32);

		CopyCampaignPayload payload = CopyCampaignPayload.builder()
				.destPointInTime(pointInTime)
				.build();
		EditorSupportParams params = EditorSupportParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.pointInTime(pointInTime)
				.versionDt(currentDate)
				.build();

		Plot plot = Plot.builder()
				.plotCode(plotCode)
				.geom(reader.read("POLYGON ((100 200, 200 200, 200 100, 100 100, 100 200))"))
				.fromDate(plotFromDate)
				.toDate(plotToDate)
				.build();

		PermanentCropFormData permanentCropFormData = PermanentCropFormData.builder().bio("YES").build();
		PermanentCropForm permanentCropForm = new PermanentCropForm("TEST", "TEST", permanentCropFormData);
		List<Declaration> sourceDeclarationsFirstCrop = List.of(
				Declaration.builder().landuse(new LandUse("123-000-000-000-000", "")).areaPerc(100.)
						.permanentCropForms(List.of(permanentCropForm)).build()
		);
		List<LandUseAdditionalDataField> landUseAdditionalDataFields = List.of(LandUseAdditionalDataField.builder().fieldCode("FOO").value("BAR").build());
		List<Declaration> sourceDeclarationsSecondCrop = List.of(
				Declaration.builder().landuse(new LandUse("456-000-000-000-000", "")).areaPerc(60.)
						.fieldsCodes(landUseAdditionalDataFields).build()
		);

		given(cropCodeService.getLandUseCode(any(), any(), any(), eq("123-000-000-000-000"), any(), any()))
				.willAnswer(i -> {
					LandUseDetails landUseDetails = new LandUseDetails();
					landUseDetails.setDefaultFromDate("20240101");
					landUseDetails.setDefaultHarvestDays(60);
					return landUseDetails;
				});
		given(cropCodeService.getLandUseCode(any(), any(), any(), eq("456-000-000-000-000"), any(), any()))
				.willAnswer(i -> {
					LandUseDetails landUseDetails = new LandUseDetails();
					landUseDetails.setDefaultFromDate("20240101");
					landUseDetails.setDefaultHarvestDays(100);
					return landUseDetails;
				});

		// test
		copyCampaignUtils.copyDeclarationsOnPlotEvaluatingFreeIntervals(env, payload, params, plot, List.of(sourceDeclarationsFirstCrop, sourceDeclarationsSecondCrop));

		ArgumentCaptor<AbsoluteDate> dateCaptor = ArgumentCaptor.forClass(AbsoluteDate.class);
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), eq(plotCode), dateCaptor.capture(), any(), dateCaptor.capture(), eq("123-000-000-000-000"),
				eq(100.), eq(List.of(new InsertPermanentCropForm("TEST", permanentCropFormData))), any(), eq(env.getUserId()), eq(currentDate), isNull());
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), eq(plotCode), dateCaptor.capture(), any(), dateCaptor.capture(), eq("456-000-000-000-000"),
				eq(60.), any(), eq(landUseAdditionalDataFields), eq(env.getUserId()), eq(currentDate), isNull());

		assertThat(dateCaptor.getAllValues()).containsExactly(
				plotFromDate,
				AbsoluteDate.of(plotFromDate.toLocalDate().plusDays(60)),
				AbsoluteDate.of(plotFromDate.toLocalDate().plusDays(61)),
				AbsoluteDate.of(plotFromDate.toLocalDate().plusDays(161))
		);

	}

	@Test
	void test_copyDeclarationsOnPlot_firstCropOnlyOk() throws Exception {
		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		String businessId = "555";
		long cropPlanId = 123L;
		String plotCode = "p001";
		AbsoluteDate plotFromDate = AbsoluteDate.of("20240601");
		AbsoluteDate plotToDate = AbsoluteDate.of("20251001");
		AbsoluteDate pointInTime = AbsoluteDate.of("20240515");
		LocalDateTime currentDate = LocalDateTime.of(2025, 05, 06, 17, 32);

		CopyCampaignPayload payload = CopyCampaignPayload.builder()
				.destPointInTime(pointInTime)
				.build();
		EditorSupportParams params = EditorSupportParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.pointInTime(pointInTime)
				.versionDt(currentDate)
				.build();

		Plot plot = Plot.builder()
				.plotCode(plotCode)
				.geom(reader.read("POLYGON ((100 200, 200 200, 200 100, 100 100, 100 200))"))
				.fromDate(plotFromDate)
				.toDate(plotToDate)
				.build();

		PermanentCropFormData permanentCropFormData = PermanentCropFormData.builder().bio("YES").build();
		List<LandUseAdditionalDataField> landUseAdditionalDataFields = List.of(LandUseAdditionalDataField.builder().fieldCode("FOO").value("BAR").build());
		PermanentCropForm permanentCropForm = new PermanentCropForm("TEST", "TEST", permanentCropFormData);
		List<Declaration> sourceDeclarationsFirstCrop = List.of(
				Declaration.builder().landuse(new LandUse("123-000-000-000-000", "")).areaPerc(100.)
						.permanentCropForms(List.of(permanentCropForm)).fieldsCodes(landUseAdditionalDataFields).build()
		);

		given(cropCodeService.getLandUseCode(any(), any(), any(), eq("123-000-000-000-000"), any(), any()))
				.willAnswer(i -> {
					LandUseDetails landUseDetails = new LandUseDetails();
					landUseDetails.setDefaultFromDate("20240101");
					landUseDetails.setDefaultHarvestDays(60);
					return landUseDetails;
				});

		// test
		copyCampaignUtils.copyDeclarationsOnPlotEvaluatingFreeIntervals(env, payload, params, plot, List.of(sourceDeclarationsFirstCrop));

		ArgumentCaptor<AbsoluteDate> dateCaptor = ArgumentCaptor.forClass(AbsoluteDate.class);
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), eq(plotCode), dateCaptor.capture(), any(), dateCaptor.capture(), eq("123-000-000-000-000"),
				eq(100.), eq(List.of(new InsertPermanentCropForm("TEST", permanentCropFormData))), any(), eq(env.getUserId()), eq(currentDate), isNull());
		verifyNoMoreInteractions(cropPlansDAO);

		assertThat(dateCaptor.getAllValues()).containsExactly(
				plotFromDate,
				AbsoluteDate.of(plotFromDate.toLocalDate().plusDays(60))
		);

	}

	@Test
	void test_copyDeclarationsOnPlot_secondCropCutOffOk() throws Exception {
		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		String businessId = "555";
		long cropPlanId = 123L;
		String plotCode = "p001";
		AbsoluteDate plotFromDate = AbsoluteDate.of("20240601");
		AbsoluteDate plotToDate = AbsoluteDate.of("20251001");
		AbsoluteDate pointInTime = AbsoluteDate.of("20240515");
		LocalDateTime currentDate = LocalDateTime.of(2025, 05, 06, 17, 32);

		CopyCampaignPayload payload = CopyCampaignPayload.builder()
				.destPointInTime(pointInTime)
				.build();
		EditorSupportParams params = EditorSupportParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.pointInTime(pointInTime)
				.versionDt(currentDate)
				.build();

		Plot plot = Plot.builder()
				.plotCode(plotCode)
				.geom(reader.read("POLYGON ((100 200, 200 200, 200 100, 100 100, 100 200))"))
				.fromDate(plotFromDate)
				.toDate(plotToDate)
				.build();

		PermanentCropFormData permanentCropFormData = PermanentCropFormData.builder().bio("YES").build();
		PermanentCropForm permanentCropForm = new PermanentCropForm("TEST", "TEST", permanentCropFormData);
		List<Declaration> sourceDeclarationsFirstCrop = List.of(
				Declaration.builder().landuse(new LandUse("123-000-000-000-000", "")).areaPerc(50.)
						.permanentCropForms(List.of(permanentCropForm)).build(),
				Declaration.builder().landuse(new LandUse("789-000-000-000-000", "")).areaPerc(50.)
						.build()
		);
		List<LandUseAdditionalDataField> landUseAdditionalDataFields = List.of(LandUseAdditionalDataField.builder().fieldCode("FOO").value("BAR").build());
		List<Declaration> sourceDeclarationsSecondCrop = List.of(
				Declaration.builder().landuse(new LandUse("456-000-000-000-000", "")).areaPerc(60.)
						.fieldsCodes(landUseAdditionalDataFields).build()
		);

		given(cropCodeService.getLandUseCode(any(), any(), any(), eq("123-000-000-000-000"), any(), any()))
				.willAnswer(i -> {
					LandUseDetails landUseDetails = new LandUseDetails();
					landUseDetails.setDefaultFromDate("20240101");
					landUseDetails.setDefaultHarvestDays(60);
					return landUseDetails;
				});
		given(cropCodeService.getLandUseCode(any(), any(), any(), eq("456-000-000-000-000"), any(), any()))
				.willAnswer(i -> {
					LandUseDetails landUseDetails = new LandUseDetails();
					landUseDetails.setDefaultFromDate("20240101");
					landUseDetails.setDefaultHarvestDays(100);
					return landUseDetails;
				});
		given(cropCodeService.getLandUseCode(any(), any(), any(), eq("789-000-000-000-000"), any(), any()))
				.willAnswer(i -> {
					LandUseDetails landUseDetails = new LandUseDetails();
					landUseDetails.setDefaultFromDate("20240701");
					landUseDetails.setDefaultHarvestDays(365*2);
					return landUseDetails;
				});

		// test
		copyCampaignUtils.copyDeclarationsOnPlotEvaluatingFreeIntervals(env, payload, params, plot, List.of(sourceDeclarationsFirstCrop, sourceDeclarationsSecondCrop));

		ArgumentCaptor<AbsoluteDate> dateCaptor = ArgumentCaptor.forClass(AbsoluteDate.class);
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), eq(plotCode), dateCaptor.capture(), any(), dateCaptor.capture(), eq("123-000-000-000-000"),
				eq(50.), eq(List.of(new InsertPermanentCropForm("TEST", permanentCropFormData))), any(), eq(env.getUserId()), eq(currentDate), isNull());
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), eq(plotCode), dateCaptor.capture(), any(), dateCaptor.capture(), eq("789-000-000-000-000"),
				eq(50.), any(), any(), eq(env.getUserId()), eq(currentDate), isNull());
		verifyNoMoreInteractions(cropPlansDAO);

		assertThat(dateCaptor.getAllValues()).containsExactly(
				plotFromDate,
				AbsoluteDate.of(plotFromDate.toLocalDate().plusDays(60)),
				AbsoluteDate.of("20240701"),
				plotToDate
		);

	}

	/// [issue #171489](https://abacogroup.easyredmine.com/issues/171489)
	@Test
	void test_copyDeclarationsOnPlot_rm171489ok() throws Exception {
		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		String businessId = "555";
		long cropPlanId = 123L;
		String plotCode = "p001";
		AbsoluteDate plotFromDate = AbsoluteDate.of("19700101");
		AbsoluteDate plotToDate = AbsoluteDate.of("99991231");
		AbsoluteDate pointInTime = AbsoluteDate.of("20250515");
		LocalDateTime currentDate = LocalDateTime.of(2025, 04, 10, 16, 53);

		CopyCampaignPayload payload = CopyCampaignPayload.builder()
				.destPointInTime(pointInTime)
				.build();
		EditorSupportParams params = EditorSupportParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.pointInTime(pointInTime)
				.versionDt(currentDate)
				.build();

		Plot plot = Plot.builder()
				.plotCode(plotCode)
				.geom(reader.read("POLYGON ((100 200, 200 200, 200 100, 100 100, 100 200))"))
				.fromDate(plotFromDate)
				.toDate(plotToDate)
				.build();

		List<Declaration> sourceDeclarationsFirstCrop = List.of(
				Declaration.builder().landuse(new LandUse("800-002-050-044-000", "")).areaPerc(100.)
						.fromDate(AbsoluteDate.of("20250101")).toDate(AbsoluteDate.of("20250531")).build()
		);
		List<Declaration> sourceDeclarationsSecondCrop = List.of(
				Declaration.builder().landuse(new LandUse("001-002-010-022-000", "")).areaPerc(100.)
						.fromDate(AbsoluteDate.of("20250610")).toDate(AbsoluteDate.of("20251015")).build()
		);

		/*
		|001-002-010-022-000|2025-04-01 00:00:00.000|2025-09-01 00:00:00.000|
|800-002-050-044-000|2025-03-01 00:00:00.000|2025-11-10 00:00:00.000|
		 */

		given(cropCodeService.getLandUseCode(any(), any(), any(), eq("001-002-010-022-000"), any(), any()))
				.willAnswer(i -> {
					LandUseDetails landUseDetails = new LandUseDetails();
					landUseDetails.setDefaultFromDate("20250401");
					landUseDetails.setDefaultHarvestDays(152);
					return landUseDetails;
				});
		given(cropCodeService.getLandUseCode(any(), any(), any(), eq("800-002-050-044-000"), any(), any()))
				.willAnswer(i -> {
					LandUseDetails landUseDetails = new LandUseDetails();
					landUseDetails.setDefaultFromDate("20250301");
					landUseDetails.setDefaultHarvestDays(254);
					return landUseDetails;
				});

		// test
		copyCampaignUtils.copyDeclarationsOnPlotEvaluatingFreeIntervals(env, payload, params, plot, List.of(sourceDeclarationsFirstCrop, sourceDeclarationsSecondCrop));

		ArgumentCaptor<AbsoluteDate> dateCaptor = ArgumentCaptor.forClass(AbsoluteDate.class);
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), eq(plotCode), dateCaptor.capture(), any(), dateCaptor.capture(), eq("800-002-050-044-000"),
				eq(100.), any(), any(), eq(env.getUserId()), eq(currentDate), isNull());
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), eq(plotCode), dateCaptor.capture(), any(), dateCaptor.capture(), eq("001-002-010-022-000"),
				eq(100.), any(), any(), eq(env.getUserId()), eq(currentDate), isNull());

		assertThat(dateCaptor.getAllValues()).containsExactly(
				AbsoluteDate.of("20250301"),
				AbsoluteDate.of("20251110"),
				AbsoluteDate.of("20251111"),
				AbsoluteDate.of("20260412")
		);

	}

	@Test
	void test_copyDeclarationsOnPlot_preserveDelcDatesOk() throws Exception {
		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		String businessId = "555";
		long cropPlanId = 123L;
		String plotCode = "p001";
		AbsoluteDate plotFromDate = AbsoluteDate.of("20240601");
		AbsoluteDate plotToDate = AbsoluteDate.of("20251001");
		AbsoluteDate pointInTime = AbsoluteDate.of("20240515");
		LocalDateTime currentDate = LocalDateTime.of(2025, 05, 06, 17, 32);

		CopyCampaignPayload payload = CopyCampaignPayload.builder()
				.destPointInTime(pointInTime)
				.preserveSourceDeclDates(true)
				.build();
		EditorSupportParams params = EditorSupportParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.pointInTime(pointInTime)
				.versionDt(currentDate)
				.build();

		Plot plot = Plot.builder()
				.plotCode(plotCode)
				.geom(reader.read("POLYGON ((100 200, 200 200, 200 100, 100 100, 100 200))"))
				.fromDate(plotFromDate)
				.toDate(plotToDate)
				.build();

		List<Declaration> sourceDeclarationsFirstCrop = List.of(
				Declaration.builder().landuse(new LandUse("123-000-000-000-000", "")).areaPerc(50.)
						.fromDate(AbsoluteDate.of("20240101")).toDate(AbsoluteDate.of("20240630")).build(),
				Declaration.builder().landuse(new LandUse("789-000-000-000-000", "")).areaPerc(50.)
						.fromDate(AbsoluteDate.of("20240301")).toDate(AbsoluteDate.of("20240509")).build()
		);
		List<Declaration> sourceDeclarationsSecondCrop = List.of(
				Declaration.builder().landuse(new LandUse("456-000-000-000-000", "")).areaPerc(100.)
						.fromDate(AbsoluteDate.of("20240701")).toDate(AbsoluteDate.of("20250131")).build()
		);

		// test
		copyCampaignUtils.copyDeclarationsOnPlotEvaluatingFreeIntervals(env, payload, params, plot, List.of(sourceDeclarationsFirstCrop, sourceDeclarationsSecondCrop));

		ArgumentCaptor<AbsoluteDate> dateCaptor = ArgumentCaptor.forClass(AbsoluteDate.class);
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), eq(plotCode), dateCaptor.capture(), any(), dateCaptor.capture(), eq("123-000-000-000-000"),
				eq(50.), any(), any(), eq(env.getUserId()), eq(currentDate), isNull());
		verify(cropPlansDAO, never()).insertDeclaration(any(), any(), any(), any(), any(), eq("789-000-000-000-000"),
				any(), any(), any(), any(), any(), any());
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), eq(plotCode), dateCaptor.capture(), any(), dateCaptor.capture(), eq("456-000-000-000-000"),
				eq(100.), any(), any(), eq(env.getUserId()), eq(currentDate), isNull());

		assertThat(dateCaptor.getAllValues()).containsExactly(
				plotFromDate,
				AbsoluteDate.of("20240630"),
				AbsoluteDate.of("20240701"),
				AbsoluteDate.of("20250131")
		);

	}

	// ----- copyDeclarationsOnParcel -----
	@Test
	void test_copyDeclarationsOnParcel_ok() throws Exception {
		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		String businessId = "555";
		long cropPlanId = 123L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20240601");
		AbsoluteDate campaignStartDate = AbsoluteDate.of("20240515");
		LocalDateTime currentDate = LocalDateTime.of(2025, 05, 06, 17, 32);

		CopyCampaignPayload payload = CopyCampaignPayload.builder()
				.destPointInTime(pointInTime)
				.sourcePointInTime(AbsoluteDate.of("20230515"))
				.build();
		EditorSupportParams params = EditorSupportParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.pointInTime(pointInTime)
				.versionDt(currentDate)
				.build();
		CropPlanDates cropPlanDates = new CropPlanDates();
		cropPlanDates.setCampaignStartDate(campaignStartDate);

		Parcel parcel = new Parcel("test", reader.read("POLYGON ((50 150, 50 350, 350 350, 350 150, 50 150))"),
				"20240101", "99991231");
		Map<String, Geometry> polygons = getPolygons();
		Iterator<String> lucs = List.of(
				"001-000-000-000-000",
				"002-000-000-000-000",
				"003-000-000-000-000",
				"004-000-000-000-000",
				"005-000-000-000-000",
				"006-000-000-000-000",
				"007-000-000-000-000",
				"008-000-000-000-000",
				"009-000-000-000-000",
				"010-000-000-000-000"
		).iterator();
		List<Plot> previousPlots = polygons.entrySet().stream()
				.sorted(Entry.comparingByKey())
				.map(e -> Plot.builder()
						.plotCode(e.getKey())
						.geom(e.getValue())
						.decls(List.of(Declaration.builder().landuse(new LandUse(lucs.next(), "")).fromDate(AbsoluteDate.of("19700101"))
								.areaPerc(100.).build()))
						.build())
				.collect(Collectors.toList());

		given(cropCodeService.getLandUseCode(any(), any(), any(), any(), any(), any()))
				.willAnswer(i -> {
					LandUseDetails landUseDetails = new LandUseDetails();
					landUseDetails.setDefaultFromDate("20240701");
					landUseDetails.setDefaultHarvestDays(365);
					return landUseDetails;
				});
		given(plotEditService.drawGeometryPropagatingBehaviour(any(), any(), any(), any(), any(), anyBoolean(), any(), anyBoolean()))
				.willAnswer(i -> {
					EditPlotResult res = new EditPlotResult();
					res.setAdded(List.of(Plot.builder()
									.plotCode("new")
									.geom(i.getArgument(2))
									.fromDate(i.getArgument(4))
									.fullRangeFromDate(i.getArgument(4))
									.toDate(i.getArgument(3))
									.fullRangeToDate(i.getArgument(3))
							.build()));
					return res;
				});


		// test
		copyCampaignUtils.copyDeclarationsOnParcel(env, payload, parcel, previousPlots, cropPlanDates, params);


		ArgumentCaptor<Geometry> geometryCaptor = ArgumentCaptor.forClass(Geometry.class);
		verify(plotEditService, times(10+2)).drawGeometryPropagatingBehaviour(any(), any(), geometryCaptor.capture(),
				eq(AbsoluteDate.of(parcel.getToDate())), eq(campaignStartDate), anyBoolean(), any(), anyBoolean());

		assertThat(geometryCaptor.getAllValues()).hasSize(12)
				.anyMatch(g -> geomEquals(g, "POLYGON ((50 150, 50 300, 100 300, 100 200, 100 150, 50 150))"))
				.anyMatch(g -> geomEquals(g, "POLYGON ((85.71428571428571 350, 100 350, 100 300, 85.71428571428571 350))"))
				.anyMatch(g -> geomEquals(g, "POLYGON ((100 200, 200 200, 200 150, 100 150, 100 200))"))
				.anyMatch(g -> geomEquals(g, "POLYGON ((200 150, 200 200, 300 200, 300 150, 200 150))"))
				.anyMatch(g -> geomEquals(g, "POLYGON ((300 150, 300 200, 350 200, 350 150, 300 150))"))
				.anyMatch(g -> geomEquals(g, "POLYGON ((100 300, 200 300, 200 200, 100 200, 100 300))"))
				.anyMatch(g -> geomEquals(g, "POLYGON ((200 300, 300 300, 300 200, 200 200, 200 300))"))
				.anyMatch(g -> geomEquals(g, "POLYGON ((300 300, 350 300, 350 200, 300 200, 300 300))"))
				.anyMatch(g -> geomEquals(g, "POLYGON ((200 350, 200 300, 100 300, 100 350, 200 350))"))
				.anyMatch(g -> geomEquals(g, "POLYGON ((300 350, 300 300, 200 300, 200 350, 300 350))"))
				.anyMatch(g -> geomEquals(g, "POLYGON ((350 300, 300 300, 300 350, 350 350, 350 300))"))
				.anyMatch(g -> geomEquals(g, "POLYGON ((85.71428571428571 350, 100 300, 50 300, 50 350, 85.71428571428571 350))"))
				;

		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), anyString(),
				eq(AbsoluteDate.of("20240701")), any(), eq(AbsoluteDate.of("20250701")), eq("001-000-000-000-000"),
				eq(100.), any(), any(), eq(env.getUserId()), eq(currentDate), isNull());
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), anyString(),
				eq(AbsoluteDate.of("20240701")), any(), eq(AbsoluteDate.of("20250701")), eq("002-000-000-000-000"),
				eq(100.), any(), any(), eq(env.getUserId()), eq(currentDate), isNull());
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), anyString(),
				eq(AbsoluteDate.of("20240701")), any(), eq(AbsoluteDate.of("20250701")), eq("003-000-000-000-000"),
				eq(100.), any(), any(), eq(env.getUserId()), eq(currentDate), isNull());
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), anyString(),
				eq(AbsoluteDate.of("20240701")), any(), eq(AbsoluteDate.of("20250701")), eq("004-000-000-000-000"),
				eq(100.), any(), any(), eq(env.getUserId()), eq(currentDate), isNull());
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), anyString(),
				eq(AbsoluteDate.of("20240701")), any(), eq(AbsoluteDate.of("20250701")), eq("005-000-000-000-000"),
				eq(100.), any(), any(), eq(env.getUserId()), eq(currentDate), isNull());
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), anyString(),
				eq(AbsoluteDate.of("20240701")), any(), eq(AbsoluteDate.of("20250701")), eq("006-000-000-000-000"),
				eq(100.), any(), any(), eq(env.getUserId()), eq(currentDate), isNull());
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), anyString(),
				eq(AbsoluteDate.of("20240701")), any(), eq(AbsoluteDate.of("20250701")), eq("007-000-000-000-000"),
				eq(100.), any(), any(), eq(env.getUserId()), eq(currentDate), isNull());
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), anyString(),
				eq(AbsoluteDate.of("20240701")), any(), eq(AbsoluteDate.of("20250701")), eq("008-000-000-000-000"),
				eq(100.), any(), any(), eq(env.getUserId()), eq(currentDate), isNull());
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), anyString(),
				eq(AbsoluteDate.of("20240701")), any(), eq(AbsoluteDate.of("20250701")), eq("009-000-000-000-000"),
				eq(100.), any(), any(), eq(env.getUserId()), eq(currentDate), isNull());
		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), anyString(),
				eq(AbsoluteDate.of("20240701")), any(), eq(AbsoluteDate.of("20250701")), eq("010-000-000-000-000"),
				eq(100.), any(), any(), eq(env.getUserId()), eq(currentDate), isNull());
	}

	@Test
	void test_copyDeclarationsOnParcel_noCampaignDateOk() throws Exception {
		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		String businessId = "555";
		long cropPlanId = 123L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20240601");
		AbsoluteDate campaignStartDate = null;
		LocalDateTime currentDate = LocalDateTime.of(2025, 05, 06, 17, 32);

		CopyCampaignPayload payload = CopyCampaignPayload.builder()
				.destPointInTime(pointInTime)
				.sourcePointInTime(AbsoluteDate.of("20230515"))
				.build();
		EditorSupportParams params = EditorSupportParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.pointInTime(pointInTime)
				.versionDt(currentDate)
				.build();
		CropPlanDates cropPlanDates = new CropPlanDates();
		cropPlanDates.setCampaignStartDate(campaignStartDate);

		Parcel parcel = new Parcel("test", reader.read("POLYGON ((50 150, 50 350, 350 350, 350 150, 50 150))"),
				"20240101", "99991231");
		Map<String, Geometry> polygons = getPolygons();
		List<Plot> previousPlots = List.of(Plot.builder()
						.plotCode("p001")
						.geom(polygons.get("p001"))
						.decls(List.of(Declaration.builder().landuse(new LandUse("001-000-000-000-000", "")).fromDate(AbsoluteDate.of("19700101"))
								.areaPerc(100.).build()))
						.build());

		given(cropCodeService.getLandUseCode(any(), any(), any(), any(), any(), any()))
				.willAnswer(i -> {
					LandUseDetails landUseDetails = new LandUseDetails();
					landUseDetails.setDefaultFromDate("19700101");
					landUseDetails.setDefaultHarvestDays(365);
					return landUseDetails;
				});
		given(plotEditService.drawGeometryPropagatingBehaviour(any(), any(), any(), any(), any(), anyBoolean(), any(), anyBoolean()))
				.willAnswer(i -> {
					EditPlotResult res = new EditPlotResult();
					res.setAdded(List.of(Plot.builder()
							.plotCode("new")
							.geom(i.getArgument(2))
							.fromDate(i.getArgument(4))
							.fullRangeFromDate(i.getArgument(4))
							.toDate(i.getArgument(3))
							.fullRangeToDate(i.getArgument(3))
							.build()));
					return res;
				});


		// test
		copyCampaignUtils.copyDeclarationsOnParcel(env, payload, parcel, previousPlots, cropPlanDates, params);


		ArgumentCaptor<Geometry> geometryCaptor = ArgumentCaptor.forClass(Geometry.class);
		verify(plotEditService, times(2)).drawGeometryPropagatingBehaviour(any(), any(), geometryCaptor.capture(),
				eq(AbsoluteDate.of(parcel.getToDate())), eq(pointInTime), anyBoolean(), any(), anyBoolean());

		assertThat(geometryCaptor.getAllValues()).hasSize(2)
				.anyMatch(g -> geomEquals(g, "POLYGON ((100 200, 200 200, 200 150, 100 150, 100 200))"))
		;

		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), anyString(),
				eq(AbsoluteDate.of("20240601")), any(), eq(AbsoluteDate.of("20250601")), eq("001-000-000-000-000"),
				eq(100.), any(), any(), eq(env.getUserId()), eq(currentDate), isNull());
	}

	@Test
	void test_copyDeclarationsOnParcel_parcelAfterCampaignDateOk() throws Exception {
		RuntimeEnvironmentImpl env = new RuntimeEnvironmentImpl();
		String businessId = "555";
		long cropPlanId = 123L;
		AbsoluteDate pointInTime = AbsoluteDate.of("20241001");
		AbsoluteDate campaignStartDate = AbsoluteDate.of("20240515");
		LocalDateTime currentDate = LocalDateTime.of(2025, 05, 06, 17, 32);
		String parcelFrom = "20240801";
		String parcelTo = "20250101";

		CopyCampaignPayload payload = CopyCampaignPayload.builder()
				.destPointInTime(pointInTime)
				.sourcePointInTime(AbsoluteDate.of("20230515"))
				.build();
		EditorSupportParams params = EditorSupportParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.pointInTime(pointInTime)
				.versionDt(currentDate)
				.build();
		CropPlanDates cropPlanDates = new CropPlanDates();
		cropPlanDates.setCampaignStartDate(campaignStartDate);

		Parcel parcel = new Parcel("test", reader.read("POLYGON ((50 150, 50 350, 350 350, 350 150, 50 150))"),
				parcelFrom, parcelTo);
		Map<String, Geometry> polygons = getPolygons();
		List<Plot> previousPlots = List.of(Plot.builder()
				.plotCode("p001")
				.geom(polygons.get("p001"))
				.decls(List.of(Declaration.builder().landuse(new LandUse("001-000-000-000-000", "")).fromDate(AbsoluteDate.of("19700101"))
						.areaPerc(100.).build()))
				.build());

		given(cropCodeService.getLandUseCode(any(), any(), any(), any(), any(), any()))
				.willAnswer(i -> {
					LandUseDetails landUseDetails = new LandUseDetails();
					landUseDetails.setDefaultFromDate("19700101");
					landUseDetails.setDefaultHarvestDays(365);
					return landUseDetails;
				});
		given(plotEditService.drawGeometryPropagatingBehaviour(any(), any(), any(), any(), any(), anyBoolean(), any(), anyBoolean()))
				.willAnswer(i -> {
					EditPlotResult res = new EditPlotResult();
					res.setAdded(List.of(Plot.builder()
							.plotCode("new")
							.geom(i.getArgument(2))
							.fromDate(i.getArgument(4))
							.fullRangeFromDate(i.getArgument(4))
							.toDate(i.getArgument(3))
							.fullRangeToDate(i.getArgument(3))
							.build()));
					return res;
				});


		// test
		copyCampaignUtils.copyDeclarationsOnParcel(env, payload, parcel, previousPlots, cropPlanDates, params);


		ArgumentCaptor<Geometry> geometryCaptor = ArgumentCaptor.forClass(Geometry.class);
		verify(plotEditService, times(2)).drawGeometryPropagatingBehaviour(any(), any(), geometryCaptor.capture(),
				eq(AbsoluteDate.of(parcel.getToDate())), eq(AbsoluteDate.of(parcelFrom)), anyBoolean(), any(), anyBoolean());

		assertThat(geometryCaptor.getAllValues()).hasSize(2)
				.anyMatch(g -> geomEquals(g, "POLYGON ((100 200, 200 200, 200 150, 100 150, 100 200))"))
		;

		verify(cropPlansDAO).insertDeclaration(eq(cropPlanId), anyString(),
				eq(AbsoluteDate.of(parcelFrom)), any(), eq(AbsoluteDate.of(parcelTo)), eq("001-000-000-000-000"),
				eq(100.), any(), any(), eq(env.getUserId()), eq(currentDate), isNull());
	}

	// ############################################################# //

	private Map<String, Geometry> getPolygons() throws ParseException {
		return Map.of(
				"p001", reader.read("POLYGON ((100 200, 200 200, 200 100, 100 100, 100 200))          "),
				"p002", reader.read("POLYGON ((200 050, 200 200, 300 200, 300 050, 200 050))          "),
				"p003", reader.read("POLYGON ((300 090, 300 200, 410 200, 410 090, 300 090))          "),
				"p004", reader.read("POLYGON ((100 300, 200 300, 200 200, 100 200, 100 300))          "),
				"p005", reader.read("POLYGON ((200 300, 300 300, 300 200, 200 200, 200 300))          "),
				"p006", reader.read("POLYGON ((300 300, 400 300, 400 200, 300 200, 300 300))          "),
				"p007", reader.read("POLYGON ((100 400, 200 400, 200 300, 100 300, 100 400))          "),
				"p008", reader.read("POLYGON ((200 400, 300 400, 300 300, 200 300, 200 400))          "),
				"p009", reader.read("POLYGON ((300 400, 400 400, 400 300, 300 300, 300 400))          "),
				"p010", reader.read("POLYGON ((100 400, 080 370, 100 300, 000 300, 000 400, 100 400)) ")
		);
	}

	private boolean geomEquals(Geometry g, String polygon) {
		try {
			return Utils.equalsSnapped((Polygonal) g, (Polygonal) reader.read(polygon));
		} catch (ParseException e) {
			throw new RuntimeException(e);
		}
	}

}
