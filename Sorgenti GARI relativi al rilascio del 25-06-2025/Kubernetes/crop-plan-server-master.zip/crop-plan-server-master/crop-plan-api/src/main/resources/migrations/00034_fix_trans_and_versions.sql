--liquibase formatted sql  
--changeset ABACO:00034_fix_trans_and_versions

update CRPL_DECL_PESTICIDES set transaction_id = null;
update CRPL_DECL_PESTS set transaction_id = null;

update CRPL_DECL_ADDIT_FIELDS set transaction_id = null
WHERE id IN (
SELECT cdaf.id
FROM CRPL_DECL_ADDIT_FIELDS cdaf
WHERE NOT EXISTS (SELECT 1 FROM CRPL_DECLARATIONS cd WHERE cd.plan_id = cdaf.PLAN_ID AND cd.plot_code = cdaf.plot_code AND cd.decl_code = cdaf.decl_code AND cd.transaction_id = cdaf.TRANSACTION_id)
AND cdaf.TRANSACTION_ID IS NOT NULL
);

update CRPL_DECL_ADDIT_FIELDS SET FL_VERSIONED = 1
where id in (
select t.id from (
	select (select max(cv1.version_dt) from crpl_versions cv1 where cv1.plan_id = cdp.plan_id and cv1.fl_published = 1) as ver, cdp.dt_insert, cdp.id
	from CRPL_DECL_ADDIT_FIELDS cdp
) t
where t.ver is not null
and t.dt_insert <= t.ver);

update CRPL_DECL_PESTS SET FL_VERSIONED = 1
where id in (
select t.id from (
	select (select max(cv1.version_dt) from crpl_versions cv1 where cv1.plan_id = cdp.plan_id and cv1.fl_published = 1) as ver, cdp.dt_insert, cdp.id
	from crpl_decl_pests cdp
) t
where t.ver is not null
and t.dt_insert <= t.ver);

commit;