--liquibase formatted sql  
--changeset ABACO:00048_clear_cache

DELETE FROM cache_decodes;

commit;
