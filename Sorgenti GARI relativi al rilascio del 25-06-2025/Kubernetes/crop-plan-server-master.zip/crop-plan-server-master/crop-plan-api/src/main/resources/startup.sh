#!/bin/sh

umask 0002 && \
java -XX:MaxRAMPercentage=75 -XshowSettings:vm -cp "/app/*" com.abacogroup.cropplan.CropPlanApplication server config.yml
