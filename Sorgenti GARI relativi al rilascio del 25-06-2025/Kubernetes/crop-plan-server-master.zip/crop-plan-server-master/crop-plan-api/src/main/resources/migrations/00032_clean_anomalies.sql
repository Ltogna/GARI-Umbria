--liquibase formatted sql  
--changeset ABACO:00032_clean_anomalies

DELETE FROM CRPL_ANOMALIES ca
WHERE id NOT IN (SELECT max(id) FROM CRPL_ANOMALIES
GROUP BY plan_id, object_code, object_type, error_code, dt_insert, dt_delete);

commit;
