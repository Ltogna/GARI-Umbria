--liquibase formatted sql  
--changeset ABACO:00039_clear_cache

DELETE FROM cache_decodes;

commit;
