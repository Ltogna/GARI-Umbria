--liquibase formatted sql  
--changeset ABACO:00002_populate

INSERT INTO crpl_types (code,fl_multiple) VALUES ('CROPPLAN',0);

INSERT INTO i18n_values (table_name,field_name,i18n_value,lang,i18n_text)
  VALUES ('CRPL_TYPES','CODE','CROPPLAN','en','Standard Crop Plan');

commit;
