package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class CreateVersionException extends WebApplicationException
{
	private static final long serialVersionUID = 7503065279451614010L;

	public static  class CreateVersionExceptionErrorBody
	{
		@Schema(allowableValues = "CREATE_VERSION_EXCEPTION")
		public String getErrorCode()
		{
			return "CREATE_VERSION_EXCEPTION";
		}
	}
	
	private static final CreateVersionExceptionErrorBody BODY = new CreateVersionExceptionErrorBody();

	public CreateVersionException()
	{
		super("Error while creating version",
			Response.status(Status.INTERNAL_SERVER_ERROR).entity(BODY).build());
	}
}
