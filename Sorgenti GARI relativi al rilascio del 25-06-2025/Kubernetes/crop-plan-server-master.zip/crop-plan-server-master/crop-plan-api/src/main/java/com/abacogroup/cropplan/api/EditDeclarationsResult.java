package com.abacogroup.cropplan.api;

import java.util.ArrayList;
import java.util.List;

import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.validation.ValidationMessage;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "A declarations edit result")
public class EditDeclarationsResult extends ValidationResult
{
	private List<Declaration> declarations;

	public EditDeclarationsResult()
	{
		setValidationMessages(new ArrayList<>());
	}

	public EditDeclarationsResult(List<Declaration> declarations, List<ValidationMessage> messages)
	{
		this.declarations = declarations;
		setValidationMessages(messages);
	}
}
