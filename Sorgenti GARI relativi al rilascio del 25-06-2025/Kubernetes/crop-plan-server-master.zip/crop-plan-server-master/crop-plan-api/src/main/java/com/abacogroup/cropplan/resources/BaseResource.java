package com.abacogroup.cropplan.resources;

import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import jakarta.ws.rs.ForbiddenException;

public abstract class BaseResource
{
	private BaseService baseService;

	public BaseResource(BaseService baseService)
	{
		this.baseService = baseService;
	}

	protected RuntimeEnvironment createEnvironment(User user, String language)
	{
		return baseService.getEnvironmentFactory().create(user, language);
	}

	protected void checkCanRead(User user, String language, String businessId)
	{
		if (!baseService.canRead(user, language, businessId))
			throw new ForbiddenException("You are not allowed to access this business");
	}

	protected void checkCanWrite(User user, String language, String businessId)
	{
		if (!baseService.canWrite(user, language, businessId))
			throw new ForbiddenException("You are not allowed to write this business data");
	}

}
