package com.abacogroup.cropplan.services;

import java.awt.Color;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.core.result.ResultIterator;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.cropplan.api.CropPlan;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.CropPlanVersion;
import com.abacogroup.geometryeditor.GeometryTransform;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.wms4j.layers.LayerDefinition;
import com.abacogroup.wms4j.layers.LayerRequest;
import com.abacogroup.wms4j.renderer.DrawFeature;
import com.abacogroup.wms4j.renderer.GeometryDrawerStyle;

import jakarta.ws.rs.core.MultivaluedMap;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class WmsService {
    protected static final String LAYER_NAME_DOMAIN_PLOTS = "DOMAIN_PLOTS";
    protected static final String LAYER_NAME_LATEST_VERSION_DOMAIN_PLOTS = "LATEST_VERSION_DOMAIN_PLOTS";
    protected static final String LAYER_NAME_LATEST_OTHER_PLANS_VERSION_EMPTY_DOMAIN_PLOTS = "LATEST_OTHER_PLANS_VERSION_EMPTY_DOMAIN_PLOTS";
    
    private CropPlansDAO cropPlansDAO;
    private CropPlanConfigService cropPlanConfigService;

    public List<LayerDefinition> getInternalWMSLayers() {
        List<LayerDefinition> layers = new ArrayList<>();

        layers.add(getDomainPlotsLayer());
        layers.add(getLatestVersionDomainPlotsLayer());
        layers.add(getLatestOtherPlansVersionEmptyDomainPlotsLayer());

        return layers;
    }

    private LayerDefinition getDomainPlotsLayer() {
        return new LayerDefinition(
                LAYER_NAME_DOMAIN_PLOTS,
                new LayerDefinition.Range(null, null),
                new GeometryDrawerStyle(new Color(1f, 0f, 0f, 1f), new Color(1f, 0f, 0f, .5f), 3),
                this::providePlotsData);
    }

	private void providePlotsData(LayerRequest req, Consumer<DrawFeature> consumer) {
		// Determine Data from Params
		MultivaluedMap<String, String> params = req.getUriInfo().getQueryParameters();

		// Version Dt
		String versionDt = params.getFirst("versionDt");
		LocalDateTime dt = versionDt == null ? cropPlansDAO.getCurrentTimestamp() : LocalDateTime.parse(versionDt);

		//Point In Time
		AbsoluteDate pointInTime = AbsoluteDate.of(params.getFirst("pointInTime"));

		//Crop Plan Id
		Long cropPlanId = Optional.ofNullable(params.getFirst("cropPlanId"))
				.map(Long::valueOf)
				.orElseGet(() -> {
					String businessId = params.getFirst("businessId");
					if (StringUtils.isBlank(businessId)) {
						return null;
					}

					String cropPlanTypeCode = params.getFirst("cropPlanTypeCode");

					ResultIterator<CropPlan> it = cropPlansDAO.getCropPlansInternal(businessId, cropPlanTypeCode, null, req.getTenant(), "en");
					return it.hasNext() ? it.next().getCropPlanId() : null;
				});

		// Srs
		String paramSrs = params.entrySet().stream()
				.filter(entry -> "srs".equalsIgnoreCase(entry.getKey()))
				.map(entry -> entry.getValue().get(0))
				.findFirst()
				.filter(srs -> !"none".equalsIgnoreCase(srs))
				.orElse(null);

		// DomainZoneId
		String domainZoneId = Optional.ofNullable(params.getFirst("domainZoneId")).orElse(params.getFirst("sectorCode"));

		// Actual core method logic
		Geometry areaOfInterest = req.getAreaOfInterest();
		if (domainZoneId != null) {
			List<String> domainZoneSrs = cropPlansDAO.getDomainZoneSrs(cropPlanId, domainZoneId, dt, pointInTime);

			if (domainZoneSrs.size() != 1) {
				return;
			}

			String currentDomainZoneSrs = domainZoneSrs.get(0);
			boolean shouldConvertGeomToAnotherSrs = paramSrs != null && !currentDomainZoneSrs.equals(paramSrs);

			if (shouldConvertGeomToAnotherSrs) {
				areaOfInterest = transformGeometry(req.getAreaOfInterest(), paramSrs, currentDomainZoneSrs).getEnvelope();
			}

			cropPlansDAO.getPlotsInternalWithConsumer(
					cropPlanId,
					domainZoneId,
					null,
					dt,
					pointInTime,
					pointInTime,
					null,
					areaOfInterest,
					ntt -> {
						Geometry geom = shouldConvertGeomToAnotherSrs ? transformGeometry(ntt.getGeom(), currentDomainZoneSrs, paramSrs) : ntt.getGeom();
						consumer.accept(new DrawFeature(geom));
					});
		} else {
			cropPlansDAO.getPlotsInternalWithConsumer(
					cropPlanId,
					null,
					paramSrs,
					dt,
					pointInTime,
					pointInTime,
					null,
					areaOfInterest,
					ntt -> consumer.accept(new DrawFeature(ntt.getGeom())));
		}
	}

    private LayerDefinition getLatestVersionDomainPlotsLayer() {
        return new LayerDefinition(
                LAYER_NAME_LATEST_VERSION_DOMAIN_PLOTS,
                new LayerDefinition.Range(null, null),
                new GeometryDrawerStyle(new Color(1f, 0f, 1f, 1f), new Color(1f, 0f, 1f, .5f), 3),
                this::provideLatestVersionDomainPlotsData);
    }

	private void provideLatestVersionDomainPlotsData(LayerRequest req, Consumer<DrawFeature> consumer) {
		// Determine Data from Params
		MultivaluedMap<String, String> params = req.getUriInfo().getQueryParameters();

		// BusinessId
		String businessId = params.getFirst("businessId");

		// DomainZoneId
		String domainZoneId = Optional.ofNullable(params.getFirst("domainZoneId")).orElse(params.getFirst("sectorCode"));

		// LucStartWithFilter
		String lucStartWithFilter = params.getFirst("lucStartWithFilter");

		// Srs
		String paramSrs = params.entrySet().stream()
				.filter(entry -> "srs".equalsIgnoreCase(entry.getKey()))
				.map(entry -> entry.getValue().get(0))
				.findFirst()
				.filter(srs -> !"none".equalsIgnoreCase(srs))
				.orElse(null);

		// Check on required params
		if (businessId == null || (domainZoneId == null && paramSrs == null)) {
			return;
		}

		// Crop Plan Id
		InfiniteListResults<CropPlan> cropPlans = cropPlansDAO.infinite(
				() -> cropPlansDAO.getCropPlansInternal(businessId, "CROPPLAN", null, req.getTenant(), "en"), null, 1);
		if (cropPlans.getCount() == 0) {
			return;
		}
		Long cropPlanId = cropPlans.getRecords().get(0).getCropPlanId();

		// Latest Crop Plan version
		List<CropPlanVersion> cropPlanVersions = cropPlansDAO.infinite(
						() -> cropPlansDAO.getAllVersions(businessId, cropPlanId, req.getTenant(), null, null), null, 1)
				.getRecords();

		if (cropPlanVersions.isEmpty()) {
			return;
		}
		CropPlanVersion latestVersion = cropPlanVersions.get(0);

		// Actual core method logic
		Geometry areaOfInterest = req.getAreaOfInterest();
		if (domainZoneId != null) {
			List<String> domainZoneSrs = cropPlansDAO.getDomainZoneSrs(cropPlanId, domainZoneId,
					latestVersion.getVersionDate(), latestVersion.getVersionReferenceDate());

			if (domainZoneSrs.size() != 1) {
				return;
			}

			String currentDomainZoneSrs = domainZoneSrs.get(0);
			boolean shouldTransform = paramSrs != null && !currentDomainZoneSrs.equals(paramSrs);

			if (shouldTransform) {
				areaOfInterest = transformGeometry(req.getAreaOfInterest(), paramSrs, currentDomainZoneSrs).getEnvelope();
			}

			cropPlansDAO.getPlotsFilteredByDeclStartWithWithConsumer(cropPlanId, domainZoneId, null,
					latestVersion.getVersionDate(), latestVersion.getVersionReferenceDate(),
					lucStartWithFilter, areaOfInterest, ntt -> {
						Geometry geom = shouldTransform
								? transformGeometry(ntt, currentDomainZoneSrs, paramSrs)
								: ntt;
						consumer.accept(new DrawFeature(geom));
					});
		} else {
			cropPlansDAO.getPlotsFilteredByDeclStartWithWithConsumer(cropPlanId, null, paramSrs,
					latestVersion.getVersionDate(), latestVersion.getVersionReferenceDate(),
					lucStartWithFilter, areaOfInterest, ntt -> consumer.accept(new DrawFeature(ntt)));
		}
	}

    private Geometry transformGeometry(Geometry geom, String sourceSrs, String targetSrs) {
		try {
			GeometryTransform gt = new GeometryTransform();
			return gt.transform(geom, sourceSrs, targetSrs);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	private LayerDefinition getLatestOtherPlansVersionEmptyDomainPlotsLayer() {
		return new LayerDefinition(
				LAYER_NAME_LATEST_OTHER_PLANS_VERSION_EMPTY_DOMAIN_PLOTS,
				new LayerDefinition.Range(null, null),
				new GeometryDrawerStyle(new Color(.29f, .627f, .658f, 1f), new Color(.29f, .627f, .658f, .5f), 3),
				this::provideLatestOtherPlansVersionEmptyDomainPlotsData
		);
	}

	private void provideLatestOtherPlansVersionEmptyDomainPlotsData(LayerRequest req, Consumer<DrawFeature> consumer) {
		// Determine Data from Params
		MultivaluedMap<String, String> params = req.getUriInfo().getQueryParameters();

		// BusinessId
		String paramBusinessId = params.getFirst("businessId");

		// DomainZoneId
		String domainZoneId = Optional.ofNullable(params.getFirst("domainZoneId")).orElse(params.getFirst("sectorCode"));

		// PointInTime
		String paramPointInTime = params.getFirst("pointInTime");

		// Srs
		String paramSrs = params.entrySet().stream()
				.filter(entry -> "srs".equalsIgnoreCase(entry.getKey()))
				.map(entry -> entry.getValue().get(0))
				.findFirst()
				.filter(srs -> !"none".equalsIgnoreCase(srs))
				.orElse(null);

		// Check on required params
		if (paramBusinessId == null || (domainZoneId == null && paramSrs == null) || paramPointInTime == null) {
			return;
		}

		// Crop Plan Id
		InfiniteListResults<CropPlan> cropPlans = cropPlansDAO.infinite(
				() -> cropPlansDAO.getCropPlansInternal(paramBusinessId, "CROPPLAN", null, req.getTenant(), "en"), null, 1);
		if (cropPlans.getCount() == 0) {
			return;
		}
		Long cropPlanId = cropPlans.getRecords().get(0).getCropPlanId();

		AbsoluteDate pointInTime = AbsoluteDate.of(paramPointInTime);

		// CropPlanTypeId
		Long typeId = cropPlansDAO.getTypeId(cropPlans.getRecords().get(0).getCropPlanTypeCode(), req.getTenant());
		// ToleranceArea
		Long tolArea = cropPlanConfigService.getLatestOtherPlansVersionEmptyDomainPlotsLayerAreaTolerance(cropPlanId);

		// Actual core method logic
		Geometry areaOfInterest = req.getAreaOfInterest();
		if (domainZoneId != null) {
			retrieveAndTransformGeometries(cropPlanId, domainZoneId, paramSrs, pointInTime, areaOfInterest, consumer, req, tolArea, typeId);
		} else {
			cropPlansDAO.getIntersectingCropGeometriesWithConsumer(cropPlanId, typeId, null, paramSrs, pointInTime, tolArea,
					areaOfInterest, ntt -> consumer.accept(new DrawFeature(ntt)));
		}
	}

	protected void retrieveAndTransformGeometries(Long cropPlanId, String domainZoneId, String paramSrs,
			AbsoluteDate pointInTime, Geometry areaOfInterest, Consumer<DrawFeature> consumer, LayerRequest req, Long tolArea, Long typeId) {

		List<String> domainZoneSrs = cropPlansDAO.getDomainZoneSrs(cropPlanId, domainZoneId, cropPlansDAO.getCurrentTimestamp(), pointInTime);

			if (domainZoneSrs.size() != 1) {
				return;
			}

			String currentDomainZoneSrs = domainZoneSrs.get(0);

			boolean shouldTransform = paramSrs != null && !currentDomainZoneSrs.equals(paramSrs);

			if (shouldTransform) {
				areaOfInterest = transformGeometry(req.getAreaOfInterest(), paramSrs, currentDomainZoneSrs).getEnvelope();
			}

			cropPlansDAO.getIntersectingCropGeometriesWithConsumer(cropPlanId, typeId, domainZoneId, null, pointInTime, tolArea,
					areaOfInterest, ntt -> {
						Geometry geom = shouldTransform ? transformGeometry(ntt, currentDomainZoneSrs, paramSrs) : ntt;
						consumer.accept(new DrawFeature(geom));
					});

	}
}
