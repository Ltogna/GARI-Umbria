package com.abacogroup.cropplan.bundle.model;

import com.abacogroup.cropplan.bundle.model.ValidationGroups.Delete;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalFieldType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.groups.Default;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AdditDeclFieldConfMessage {

	@NotBlank(groups = {Default.class, Delete.class})
	private String code;
	@Valid
	private List<I18nValueDefinition> description;
	@NotNull
	private LandUseAdditionalFieldType type;
	@Builder.Default
	private AbsoluteDate validFrom = AbsoluteDate.of("19700101");
	@Builder.Default
	private AbsoluteDate validTo = AbsoluteDate.of("99991231");
	private Integer displayOrder;
	@NotNull
	private Boolean nullable;
	private Boolean flShowInTooltip;
	private String group;
	@Valid
	private HeaderTitle headerTitle;
	private Boolean flEditable;
	private String formula;

	@Valid
	private List<AdditDeclFieldLucConfMessage> landUseConfigurations;
}
