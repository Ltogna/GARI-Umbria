package com.abacogroup.cropplan.services.support;

import java.util.List;
import java.util.Map;

import com.abacogroup.cropplan.sdk.spi.CropCodesPlugin;
import com.abacogroup.cropplan.sdk.support.DomainDataSupport;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

public class DomainDataSupportImpl implements DomainDataSupport {
	
	private RuntimeEnvironment env;
	private CropCodesPlugin cropCodesPlugin;

	public DomainDataSupportImpl(RuntimeEnvironment env, CropCodesPlugin cropCodesPlugin) {
		this.env = env;
		this.cropCodesPlugin = cropCodesPlugin;
	}	
	
	@Override
	public Map<String, String> getLandCoverClassDescriptions(List<String> landcoverClassCodes) {
		return cropCodesPlugin.getLandCoverDescriptions(env, landcoverClassCodes);
	}

}
