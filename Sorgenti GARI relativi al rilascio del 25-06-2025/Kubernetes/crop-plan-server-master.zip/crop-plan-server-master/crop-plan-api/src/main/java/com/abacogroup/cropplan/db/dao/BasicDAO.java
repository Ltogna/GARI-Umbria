package com.abacogroup.cropplan.db.dao;

import java.time.LocalDateTime;

import org.jdbi.v3.sqlobject.statement.SqlQuery;

import com.abacogroup.jdbi.EnhancedSqlObject;

public interface BasicDAO extends EnhancedSqlObject
{

	@SqlQuery("§select_from_dual(§current_timestamp§)§")
	public LocalDateTime getCurrentTimestamp();

}
