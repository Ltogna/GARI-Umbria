package com.abacogroup.cropplan.services;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.locationtech.jts.geom.Polygon;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.cropplan.api.CutBehaviour;
import com.abacogroup.cropplan.api.ValidationResult;
import com.abacogroup.cropplan.api.payload.CreateVersionPayload;
import com.abacogroup.cropplan.api.payload.EditPlotPayload;
import com.abacogroup.cropplan.api.payload.EditPlotPayload.CutParameters;
import com.abacogroup.cropplan.api.payload.InsertPermanentCropForm;
import com.abacogroup.cropplan.api.payload.InsertPlotPayload;
import com.abacogroup.cropplan.api.payload.MergePlotsPayload;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.SyncDAO;
import com.abacogroup.cropplan.db.dao.ntt.ParcelCodeWithPlotId;
import com.abacogroup.cropplan.db.dao.ntt.SyncPlot;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.sdk.model.CropPlanConfigData;
import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import com.abacogroup.cropplan.sdk.model.config.CropPlanConfigParam;
import com.abacogroup.cropplan.sdk.model.sync.SyncParcel;
import com.abacogroup.cropplan.sdk.model.sync.WizardPlot;
import com.abacogroup.cropplan.sdk.model.validation.ValidationMessage;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedDeclaration;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedPlot;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorData;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorOperation;
import com.abacogroup.cropplan.sdk.spi.SyncPlugin;
import com.abacogroup.cropplan.services.support.EditorSupportParams;
import com.abacogroup.cropplan.services.support.PlotTimeWindowParams;
import com.abacogroup.cropplan.services.support.ValidatorSupport;
import com.abacogroup.geometryeditor.Editor.CanvasPreprocess;
import com.abacogroup.geometryeditor.EditorResult;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.google.common.collect.Iterables;

import jakarta.ws.rs.BadRequestException;

public class SyncOperationsService
{
	private static final Logger log = LoggerFactory.getLogger(SyncOperationsService.class);

	private CropPlanService cropPlanService;
	private CropPlanDeclarationsService cropPlanDeclarationsService;
	private CropPlanConfigService cropPlanConfigService;
	private PlotEditService plotEditService;
	private DeclarationService declarationService;
	private ValidatorService validatorService;

	private SyncDAO syncDAO;
	private CropPlanConfigDAO cropPlanConfigDAO;

	private PluginManager pluginManager;

	public SyncOperationsService(CropPlanService cropPlanService, CropPlanConfigService cropPlanConfigService, CropPlanDeclarationsService cropPlanDeclarationsService,
			PlotEditService plotEditService, DeclarationService declarationService, ValidatorService validatorService,
			DAOContainer daocontainer, PluginManager pluginManager)
	{
		this.cropPlanService = cropPlanService;
		this.cropPlanDeclarationsService = cropPlanDeclarationsService;
		this.cropPlanConfigService = cropPlanConfigService;
		this.plotEditService = plotEditService;
		this.declarationService = declarationService;
		this.validatorService = validatorService;

		this.syncDAO = daocontainer.getSyncDAO();
		this.cropPlanConfigDAO = daocontainer.getCropPlanConfigDAO();

		this.pluginManager = pluginManager;
	}

	public void syncFromLpisChanges(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime currentDt, LocalDateTime lastSyncDt,
			LocalDateTime syncPluginDt, LocalDate oldestChangesDateFromLpisDate, boolean ignoreDefaults, boolean lite)
	{
		var syncPlugin = pluginManager.getSyncPlugin(businessId, cropPlanId, env.getTenantId());
		CanvasPreprocess canvasPreprocess = plotEditService.getPlotEditServiceUtils().getCanvasPreprocess(cropPlanId);

		// load the oldest pointInTime (from the current pointInTime) where to apply the sync algorithm
		var pointInTime = oldestChangesDateFromLpisDate != null ? AbsoluteDate.of(oldestChangesDateFromLpisDate) : null;

		var firstSync = lastSyncDt == null;
		Set<String> changesIds = new HashSet<>();
		// Init Parcel And Plot Maps To Limit Sync Operations
		HashMap<String, AbsoluteDate> plotsMaxDate = new HashMap<>();
		while (pointInTime != null && pointInTime.toLocalDate().getYear() < 9999)
		{
			// apply changes at pointInTime
			var snapFromDate = applyLpisChanges(env, businessId, cropPlanId, currentDt, lastSyncDt,
					syncPluginDt, pointInTime, changesIds, firstSync, lite, ignoreDefaults, canvasPreprocess, plotsMaxDate);
			if (firstSync)
				firstSync = false;

			// load the next pointInTime where to apply the sync algorithm
			var ncd = syncPlugin.getNextChangesDateFromLpisDate(env, businessId, cropPlanId, snapFromDate.toLocalDate(),
					lastSyncDt, syncPluginDt, lite);
			var nextChangesDate = ncd != null ? AbsoluteDate.of(ncd) : null;

			// check if the nextFutureCrplChanges from the current pointInTime is oldest than the
			// nextChangesDate to calc the next pointInTime where to apply the sync algorithm
			var nextFutureCrplChangeDates = getBreakingPoints(env, businessId, cropPlanId, snapFromDate, changesIds, plotsMaxDate);
			if (nextFutureCrplChangeDates != null
				&& nextChangesDate != null
				&& nextFutureCrplChangeDates.isBefore(nextChangesDate))
				pointInTime = nextFutureCrplChangeDates;
			else
				pointInTime = nextChangesDate != null ? nextChangesDate : nextFutureCrplChangeDates;
		}
	}

	private AbsoluteDate applyLpisChanges(RuntimeEnvironment env, String businessId, Long cropPlanId,
		LocalDateTime currentDt, LocalDateTime lastSyncDt, LocalDateTime syncPluginDt, AbsoluteDate pointInTime, Set<String> changesIds, 
		boolean firstSync, boolean lite, boolean ignoreDefaults, CanvasPreprocess canvasPreprocess, HashMap<String, AbsoluteDate> plotsMaxDate)
	{
		var nextSnapFromDate = cropPlanConfigService.getNextSnapFromDate(cropPlanId, pointInTime);
		var syncPlugin = pluginManager.getSyncPlugin(businessId, cropPlanId, env.getTenantId());

		//long startTime = System.currentTimeMillis();
		changesIds.addAll(syncPlugin.getChangesFromLpis(env, businessId, cropPlanId, nextSnapFromDate.toLocalDate(), 
				lastSyncDt, syncPluginDt, firstSync, lite));
		
		List<SyncParcel> changedParcels = new ArrayList<>();
		for (List<String> partition : Iterables.partition(changesIds, 666)) {
			changedParcels.addAll(syncPlugin.getLpisParcelsForWizard(env, businessId, cropPlanId, nextSnapFromDate.toLocalDate(), currentDt, partition));
		}
		//long endTime = System.currentTimeMillis( );
		//log.info("TIME ELAPSED (" + cropPlanId + "): loadChangedParcels at " + nextSnapFromDate.toString() + ": " + TimeUnit.MILLISECONDS.toSeconds((endTime-startTime)) + "s");								
		
		var snapToDate = cropPlanConfigService.isForceEditAtFixedDate(cropPlanId) ? cropPlanConfigService.getFixedEditDate(cropPlanId, nextSnapFromDate) : nextSnapFromDate;
		var changedParcelsMap = changedParcels.stream()
			.collect(groupingBy(SyncParcel::getDomainZoneId));
		changedParcelsMap.entrySet().forEach(cp -> { // for each domainZoneId...
			long startTime = System.currentTimeMillis();
			log.info("SYNC STATUS (planId: " + cropPlanId + "): START apply changes at " + snapToDate.toString() + " on domain " + cp.getKey() + " (" + cp.getValue().size() + " parcels to be processed)");
			applyLpisChangesOnDomain(env, businessId, cropPlanId, currentDt, ignoreDefaults, canvasPreprocess, syncPlugin, snapToDate, cp, plotsMaxDate);
			long endTime = System.currentTimeMillis();
			log.info("SYNC STATUS (planId: " + cropPlanId + "): END apply changes at " + snapToDate.toString() + " on domain " + cp.getKey() + " (" + cp.getValue().size() + " parcels processed in "  + TimeUnit.MILLISECONDS.toSeconds((endTime-startTime)) + "s)");
		});
		
		return nextSnapFromDate;
	}

	private void applyLpisChangesOnDomain(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime currentDt,
			boolean ignoreDefaults, CanvasPreprocess canvasPreprocess, SyncPlugin syncPlugin, AbsoluteDate snapToDate, Entry<String, List<SyncParcel>> cp,
			HashMap<String, AbsoluteDate> plotsMaxDate) {
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.versionDt(currentDt)
			.domainZoneId(cp.getKey())
			.build();
		var cutParameters = new CutParameters();
		cutParameters.setBehaviour(CutBehaviour.CUT_ON_EXISTING);

		Comparator<Double> comparator = canvasPreprocess == CanvasPreprocess.ASSIGN_OVERLAPS_TO_BIGGER ? Comparator.reverseOrder() : Comparator.naturalOrder();
		List<String> deletedPlots = new ArrayList<>();
		
		// loop on domain parcels
		// TODO !!! FIX SYNC se un appezzamento sta su due parcelle, devo tenermi via i plotCode per non riprocessarli 2 volte!
		cp.getValue().stream()
				.sorted(Comparator.comparing(SyncParcel::getArea, Comparator.nullsLast(comparator)))
				.forEach(parcel -> {
					applyLpisChangesOnDomainParcel(env, businessId, cropPlanId, ignoreDefaults, syncPlugin,
							snapToDate, cp, parcel, params, cutParameters, plotsMaxDate, deletedPlots);
				});
	}
	
	private void applyLpisChangesOnDomainParcel(RuntimeEnvironment env, String businessId, Long cropPlanId, 
			boolean ignoreDefaults, SyncPlugin syncPlugin, AbsoluteDate snapToDate, Entry<String, List<SyncParcel>> cp,
			SyncParcel parcel, EditorSupportParams params,	CutParameters cutParameters, 
			HashMap<String, AbsoluteDate> plotsMaxDate, List<String> deletedPlots) {
		// 1 - cut the current fields on the changed fields
		List<SyncPlot> plots = getCurrentPlotsByParcelCode(cropPlanId, snapToDate, cp.getKey(), parcel.getCode());
		plots.forEach(plot -> {
			// Retrieve plot max date from map
			AbsoluteDate plotMaxDate = plotsMaxDate.get(plot.getPlotCode());
				
			// if not found or plot propagation date is lesser than current point in time (snapToDate) then update plot and save new result data to map
			if (!deletedPlots.contains(plot.getPlotCode()) && (plotMaxDate == null || plotMaxDate.isBefore(snapToDate)))
			{
				//long startTime = System.currentTimeMillis();
				PersistEditorResult updatePlotResult = updatePlot(env, businessId, cropPlanId, ignoreDefaults, syncPlugin, snapToDate, cp, params, cutParameters, deletedPlots, plot);
				//long endTime = System.currentTimeMillis();
				//log.info("TIME ELAPSED (" + cropPlanId + "): updatePlot " + plot.getPlotCode() + " at " + snapToDate.toString() + ": " + TimeUnit.MILLISECONDS.toSeconds((endTime-startTime)) + "s");								
				updatePlotResult.getEditorResult().getCreated().keySet().forEach(plotCode -> {
					plotsMaxDate.put(plotCode, updatePlotResult.getFutureIntersections().getMaximumDayTo());
				});
				updatePlotResult.getEditorResult().getModified().keySet().forEach(plotCode -> {
					plotsMaxDate.put(plotCode, updatePlotResult.getFutureIntersections().getMaximumDayTo());
				});
			}
		});
		
		// 2 - fill the holes
		if (parcel.getGeom() != null) {
			try
			{
				InsertPlotPayload payload = new InsertPlotPayload();
				payload.setCutParameters(cutParameters);
				payload.setFromPointInTime(snapToDate);
				payload.setGeom(parcel.getGeom());
				payload.setDescription(parcel.getPlotNameToBeAssigned());
				
				//long startTime = System.currentTimeMillis();
				PersistEditorResult plotCreateResult = plotEditService.createPlotWithoutValidation(env, params, payload,
						(ignoreDefaults ? null : parcel.getDefaultLandUse()), true);								
				//long endTime = System.currentTimeMillis();
				//log.info("TIME ELAPSED (" + cropPlanId + "): updateParcel " + parcel.getCode() + " at " + snapToDate.toString() + ": " + TimeUnit.MILLISECONDS.toSeconds((endTime-startTime)) + "s");								
				plotCreateResult.getEditorResult().getCreated().keySet().forEach(plotCode -> {
					plotsMaxDate.put(plotCode, plotCreateResult.getFutureIntersections().getMaximumDayTo());
				});
				plotCreateResult.getEditorResult().getModified().keySet().forEach(plotCode -> {
					plotsMaxDate.put(plotCode, plotCreateResult.getFutureIntersections().getMaximumDayTo());
				});
			}
			catch (IllegalStateException e)
			{
				log.error("Unable to create plot of the parcel " + parcel.getCode(), e);
			}
			catch (Exception e)
			{
				log.error("Error during create plot of the parcel " + parcel.getCode(), e);
				throw e;
			}
		}

		if(this.cropPlanConfigService.isEnableAutoMergeForLpisSync(cropPlanId)){
			doAutoMerge(env, businessId, cropPlanId, cp.getKey(), snapToDate,
					parcel.getCode(), params);
		}
	}
	
	private void doAutoMerge(RuntimeEnvironment env, String businessId, Long cropPlanId, 
			String domainZoneId, AbsoluteDate snapToDate, String parcelCode, EditorSupportParams params) {
		// I will get again all the plots because during the step of filling the holes, it might have created other plots
		List<SyncPlot> updatedPlots = getCurrentPlotsByParcelCode(cropPlanId, snapToDate, domainZoneId, parcelCode);

		List<List<SyncPlot>> groupedPlot = this.groupPlotsByDecls(env, businessId, cropPlanId, updatedPlots, snapToDate,
				snapToDate);

		groupedPlot.forEach(plotList -> {
			if(plotList.size() > 1){
				String plotCode = plotList.get(0).getPlotCode();

				List<String> plotCodes = new ArrayList<>();
				for (int i = 1; i < plotList.size(); i++) {
					plotCodes.add(plotList.get(i).getPlotCode());
				}

				MergePlotsPayload mergePlotsPayload = new MergePlotsPayload();
				mergePlotsPayload.setFromPointInTime(snapToDate);
				mergePlotsPayload.setPlotCodes(plotCodes);

				plotEditService.mergePlotsWithoutValidation(env, params, plotCode, mergePlotsPayload);
			}
		});
	}

	private List<List<SyncPlot>> groupPlotsByDecls(RuntimeEnvironment env, String businessId, Long cropPlanId,
			List<SyncPlot> plots, AbsoluteDate pointIntimeFrom, AbsoluteDate pointInTimeTo){

		List<List<SyncPlot>> groupedPlots = new ArrayList<>();
		Map<SyncPlot, List<Declaration>> plotWithDeclarations = new HashMap<>();
		Set<SyncPlot> seen = new HashSet<>(); // used for not iterating over the same plot twice making the process faster

		for (SyncPlot plot : plots) {
			List<Declaration> decls = cropPlanDeclarationsService.getPlotDeclarations(env, businessId, cropPlanId, plot.getPlotCode(), null,
					null, pointIntimeFrom, pointInTimeTo);

			plotWithDeclarations.put(plot, decls);
		}


		for (int i = 0; i < plots.size(); i++) {
			if(seen.contains(plots.get(i)))
				continue;
			else
				seen.add(plots.get(i));

			List<Declaration> decls1 = plotWithDeclarations.get(plots.get(i));
			List<SyncPlot> plotGroup = new ArrayList<>();

			plotGroup.add(plots.get(i));

			for (int j = i+1; j < plots.size(); j++) {
				if(seen.contains(plots.get(j)))
					continue;

				List<Declaration> decls2 = plotWithDeclarations.get(plots.get(j));

				if(declarationService.compareDecl(decls1, decls2)){
					plotGroup.add(plots.get(j));
					seen.add(plots.get(j));
				}
			}

			groupedPlots.add(plotGroup);
		}

		return groupedPlots;
	}

	private PersistEditorResult updatePlot(RuntimeEnvironment env, String businessId, Long cropPlanId, boolean ignoreDefaults, SyncPlugin syncPlugin, AbsoluteDate snapToDate,
			Entry<String, List<SyncParcel>> cp, EditorSupportParams params, CutParameters cutParameters, List<String> deletedPlots, SyncPlot plot) {
		var payload = new EditPlotPayload();
		payload.setCutParameters(cutParameters);
		payload.setFromPointInTime(snapToDate);
		payload.setGeom(plot.getGeom());

		try
		{
			PersistEditorResult result = plotEditService.updatePlotWithoutValidation(env, params, plot.getPlotCode(),
				payload, true);
			deletedPlots.addAll(result.getEditorResult().getDeleted());

			// check declaration on the cutted field and fix if necessary
			// EDIT: it is not necessary because changed soil will result as new parcel
			/*declarationService.checkAndFixDeclarationsForChangedPlot(env, plot.getPlotCode(), params.getCropPlanId(),
				params.getBusinessId(), cp.getKey(), pointInTime, params.getVersionDt());*/

			// loop on fields created during update to assign default land uses
			if (!ignoreDefaults) {
				result.getEditorResult().getCreated().keySet().forEach(plotCode -> {
					var createdPlot = cropPlanService.getPlot(env, businessId, cropPlanId, cp.getKey(),
						params.getVersionDt(),
						snapToDate, snapToDate, plotCode);
					if (createdPlot == null || createdPlot.getParcelIntersections().size() != 1 ||
							createdPlot.getDecls().size() > 0)
						return;

					var parcelCode = createdPlot.getParcelIntersections().get(0).getCode();
					var defaultLandUse = syncPlugin.getDefaultLandUseCode(env, snapToDate.toLocalDate(), parcelCode);
					if (defaultLandUse != null)
						declarationService.addDefaultLandUseForChangedPlot(env, createdPlot,
							params.getCropPlanId(),
							cp.getKey(), snapToDate, params.getVersionDt(), defaultLandUse);
				});
			}
			return result;
		}
		catch (IllegalStateException e)
		{
			log.error("Unable to update plot " + plot.getPlotCode() + " of parcels " + plot.getParcelCodes(), e);
			throw new RuntimeException(e);
		}
		catch (Exception e)
		{
			log.error(
				"Error during update plot " + plot.getPlotCode() + " of parcels " + plot.getParcelCodes(), e);
			throw new RuntimeException(e);
		}
	}
	
	private List<SyncPlot> getCurrentPlots(RuntimeEnvironment env, Long cropPlanId, String businessId, LocalDateTime versionDt, AbsoluteDate pointInTime, 
			String domainZoneId)
	{
		List<SyncPlot> plots = syncDAO.getPlots(cropPlanId, pointInTime, domainZoneId);
		List<Long> plotIds = plots.stream()
			.map(SyncPlot::getPlotId)
			.collect(toList());
		Map<Long, List<ParcelCodeWithPlotId>> parcelsIntersectionByPlotId = cropPlanService.getCropPlanServiceUtils().loadParcelsCodesByPlotId(cropPlanId, versionDt, plotIds);
		plots.forEach(p -> {
			var parcels = parcelsIntersectionByPlotId.compute(p.getPlotId(), (k, v) -> v == null ? new ArrayList<>(0) : v);
			p.setParcelCodes(parcels.stream().map(ParcelCodeWithPlotId::getParcelCode).collect(toList()));
		});
		return plots;
	}
	
	private List<SyncPlot> getCurrentPlotsByParcelCode(Long cropPlanId, AbsoluteDate pointInTime, String domainZoneId, String parcelCode)
	{
		List<SyncPlot> plots = syncDAO.getPlotsByParcelCode(cropPlanId, pointInTime, domainZoneId, parcelCode);
		plots.forEach(p -> p.setParcelCodes(List.of(parcelCode)));
		return plots;
	}

	private AbsoluteDate getBreakingPoints(RuntimeEnvironment env, String businessId, Long cropPlanId,
		AbsoluteDate pointInTime, Set<String> changesIds, HashMap<String, AbsoluteDate> plotsMaxDate)
	{
		var syncPlugin = pluginManager.getSyncPlugin(businessId, cropPlanId, env.getTenantId());

		if (plotsMaxDate.size() > 0) {
			AbsoluteDate minPlotsMaxDate = plotsMaxDate.values().stream().sorted().collect(toList()).get(0);
			if (minPlotsMaxDate.isAfter(pointInTime))
				pointInTime = minPlotsMaxDate;
		}
		
		var breakingPoints = syncDAO.getBreakingPoints(cropPlanId, pointInTime); // TODO OPTIMIZE SYNC: da rivedere per caricare solo quelli con i changeIds
		var it = breakingPoints.iterator();
		while (it.hasNext())
		{
			var bp = it.next();
			if (changesIds.contains(syncPlugin.getChangeId(env, bp.getParcelCode())))
				return bp.getBreakingPointDt();
		}
		return null;
	}

	public void syncWizard(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime currentDt, LocalDateTime syncPluginDt)
	{		
		var syncPlugin = pluginManager.getSyncPlugin(businessId, cropPlanId, env.getTenantId());

		var wizardPlots = syncPlugin.getWizardPlots(env, businessId, cropPlanId, syncPluginDt, true);
		wizardPlots.forEach(wizardPlot -> {
			syncWizardPlot(env, wizardPlot, businessId, cropPlanId, currentDt);
		});

		cropPlanService.createVersion(env, businessId, cropPlanId, new CreateVersionPayload("Version created from wizard", false, null), true);
		
		wizardPlots = syncPlugin.getWizardPlots(env, businessId, cropPlanId, syncPluginDt, false);
		var importAfterPublishDt = syncDAO.getCurrentTimestamp();
		wizardPlots.forEach(wizardPlot -> {
			syncWizardPlot(env, wizardPlot, businessId, cropPlanId, importAfterPublishDt);
		});
	}

	private void syncWizardPlot(RuntimeEnvironment env, WizardPlot plot, String businessId, Long cropPlanId,
		LocalDateTime importDt)
	{
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.versionDt(importDt)
			.domainZoneId(plot.getDomainZoneId())
			.build();
		
		var cutParameters = new CutParameters();
		cutParameters.setBehaviour(CutBehaviour.CUT_ON_EXISTING);
		
		var payload = new InsertPlotPayload();
		payload.setCutParameters(cutParameters);
		payload.setFromPointInTime(AbsoluteDate.of(plot.getDayFrom()));
		payload.setGeom(plot.getGeom());
		payload.setDescription(plot.getPlotName());
		
		try
		{
			var result = plotEditService.createPlotWithoutValidation(env, params, payload, null, true);
			var insertedRecords =  result.getEditorResult().getCreated().entrySet();
			if (insertedRecords.size() > 0)
			{
				var entry = insertedRecords.iterator().next();
				plot.getDecls().forEach(d -> {
					var plotCode = entry.getKey();
					var plotTimeWindowParams = PlotTimeWindowParams.builder()
						.businessId(businessId)
						.cropPlanId(cropPlanId)
						.domainZoneId(plot.getDomainZoneId())
						.plotCode(plotCode)
						.pointInTimeFrom(AbsoluteDate.of(d.getDayFrom()))
						.pointInTimeTo(AbsoluteDate.of(d.getDayTo()))
						.versionDt(importDt)
						.build();
					
					var areaPerc = d.getAreaSqm() * 100d / ((int) Math.round(entry.getValue().getArea())); 
					List<InsertPermanentCropForm> pcfs = new ArrayList<>();
					d.getPcfs().forEach(pcf -> {
						var ipcf = new InsertPermanentCropForm();
						ipcf.setFormType(pcf.getFormType());
						ipcf.setPermanentCropFormData(pcf.getPermanentCropFormData());
						pcfs.add(ipcf);
					});
					
					// For eventually future use
					List<LandUseAdditionalDataField> fieldsCodes = new ArrayList<>();
					
					cropPlanDeclarationsService.insertDeclarationWithoutValidation(env, plotTimeWindowParams, d.getLandUseCode(), areaPerc, 
						d.getFromDatePrecision(), new ArrayList<>(), pcfs, fieldsCodes);
				});
			}
		}
		catch (Exception e)
		{
			log.error("Error during create plot (" + plot.getGeom().toText() + ")", e);
			throw e;
		}
	}
	
	public void syncPlotAlign(RuntimeEnvironment env, String businessId, Long cropPlanId,
		LocalDateTime currentDt, LocalDateTime lastSyncDt, LocalDateTime syncPluginDt)
	{
		var cropPlan = cropPlanService.getCropPlan(env, businessId, cropPlanId);
		if (cropPlan == null)
			throw new BadRequestException("The crop plan was not found");
		//if (cropPlan.getChangesPending())
		//	throw new IllegalStateException("The crop plan has changes pending");
		
		var syncPlugin = pluginManager.getSyncPlugin(businessId, cropPlanId, env.getTenantId());
		
		var oldestChangesDate = syncPlugin.getOldestChangesDateFromLpisDate(env, businessId, cropPlanId, lastSyncDt, syncPluginDt, false);
		var pointInTime = oldestChangesDate != null ? AbsoluteDate.of(oldestChangesDate) : null;
		
		// align the crop plan at specified pointInTime (does not propagate modifies...)
		if (pointInTime != null)
		{
			var domainZoneIds = syncDAO.getPlotsDomainZoneIds(cropPlanId, pointInTime);
			domainZoneIds.forEach(domainZoneId -> {
				alignDomain(env, businessId, cropPlanId, currentDt, syncPlugin, pointInTime, domainZoneId);
			});
		}	
		
		cropPlanService.createVersion(env, businessId, cropPlanId, new CreateVersionPayload("Version created after plot align", false, null), true);
	}

	private void alignDomain(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime currentDt, SyncPlugin syncPlugin,
			AbsoluteDate pointInTime, String domainZoneId) {
		var alignedPlots = new HashMap<String, EditorResult<String>>();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.versionDt(currentDt)
			.domainZoneId(domainZoneId)
			.build();
		
		List<SyncPlot> plots = getCurrentPlots(env, cropPlanId, businessId, currentDt, pointInTime, domainZoneId);
		for (SyncPlot plot : plots) {
			alignPlot(env, businessId, cropPlanId, currentDt, syncPlugin, pointInTime, domainZoneId, alignedPlots, params, plot);
		}
	}

	private void alignPlot(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime currentDt, SyncPlugin syncPlugin, AbsoluteDate pointInTime,
			String domainZoneId, HashMap<String, EditorResult<String>> alignedPlots, EditorSupportParams params, SyncPlot plot) {
		Double oldTotPlotArea = plot.getGeom().getArea();
		BigDecimal oldTotPlotAreaBD = BigDecimal.valueOf(oldTotPlotArea).setScale(2, RoundingMode.HALF_UP); //Round to centimeter
		
		var parcels = getSyncParcels(env, syncPlugin, pointInTime, domainZoneId, plot);
		if (parcels.size() > 0)
		{
			var oldPlotData = declarationService.getPlotDatas(cropPlanId, plot.getPlotCode(), pointInTime, pointInTime);
			var oldDecls = cropPlanDeclarationsService.getPlotDeclarations(env, businessId, cropPlanId, plot.getPlotCode(), null, currentDt, plot.getFromDate(), plot.getToDate());
			
			plotEditService.deletePlotWithoutValidation(env, params, plot.getPlotCode(), pointInTime);
			
			try
			{
				if (alignedPlots.get(parcels.get(0).getCode()) == null)
				{
					var cutParameters = new CutParameters();
					cutParameters.setBehaviour(CutBehaviour.CUT_EXISTING);
					
					var payload = new InsertPlotPayload();
					payload.setCutParameters(cutParameters);
					payload.setFromPointInTime(pointInTime);
					payload.setGeom(parcels.get(0).getGeom());
					payload.setDescription(parcels.get(0).getPlotNameToBeAssigned());
					payload.setNotes(!oldPlotData.isEmpty() ? oldPlotData.get(0).getNotes() : null);
					
					var result = plotEditService.createPlotWithoutValidation(env, params, payload, null, true);
					alignedPlots.put(parcels.get(0).getCode(), result.getEditorResult());
				}
				var insertedRecords =  alignedPlots.get(parcels.get(0).getCode()).getCreated().entrySet();
				if (insertedRecords.size() > 0)
				{
					var entry = insertedRecords.iterator().next();
					Double newTotPlotArea = parcels.get(0).getGeom().getArea();
					//String parcelCode = parcels.get(0).getCode();
					BigDecimal newTotPlotAreaBD = BigDecimal.valueOf(newTotPlotArea).setScale(2, RoundingMode.HALF_UP); //Round to centimeter
					oldDecls.forEach(d -> {
						alignDecl(env, businessId, cropPlanId, currentDt, domainZoneId, oldTotPlotAreaBD, entry, newTotPlotAreaBD, d);
					});
				}
			}
			catch (Exception e)
			{
				log.error("Error during create plot (" + plot.getGeom().toText() + ")", e);
				throw new RuntimeException(e);
			}
		}
		else
		{
			plotEditService.deletePlotWithoutValidation(env, params, plot.getPlotCode(), pointInTime);
		}
	}

	private void alignDecl(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime currentDt, String domainZoneId,
			BigDecimal oldTotPlotAreaBD, Entry<String, Polygon> entry, BigDecimal newTotPlotAreaBD, Declaration d) {
		var plotCode = entry.getKey();
		var plotTimeWindowParams = PlotTimeWindowParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.plotCode(plotCode)
			.pointInTimeFrom(d.getFromDate())
			.pointInTimeTo(d.getToDate())
			.versionDt(currentDt)
			.build();
		
		List<InsertPermanentCropForm> pcfs = new ArrayList<>();
		d.getPermanentCropForms().forEach(pcf -> {
			var ipcf = new InsertPermanentCropForm();
			ipcf.setFormType(pcf.getFormType());
			ipcf.setPermanentCropFormData(pcf.getPermanentCropFormData());
			pcfs.add(ipcf);
		});
		
		
		List<LandUseAdditionalDataField> fieldsCodes = d.getFieldsCodes();
		Double newDeclPerc = d.getAreaPerc();
		
		if(Boolean.TRUE.equals(getReproportionDeclAreaOnSyncPlotAlign(cropPlanId)))
			//Do the recalc if there is an area perc valid and if the difference between old and new plot area are higher than 1
			if (newDeclPerc!=null && newDeclPerc!=0 && newTotPlotAreaBD.subtract(oldTotPlotAreaBD).abs().doubleValue() >= 1) {
				Double oldDeclArea = d.getAreaPerc() * oldTotPlotAreaBD.doubleValue() / 100;
				newDeclPerc = oldDeclArea * 100 / newTotPlotAreaBD.doubleValue();
			}
		cropPlanDeclarationsService.insertDeclarationWithoutValidation(env, plotTimeWindowParams, d.getLanduse().getCode(), newDeclPerc, 
			d.getFromDatePrecision(), new ArrayList<>(), pcfs, fieldsCodes);
	}

	private List<SyncParcel> getSyncParcels(RuntimeEnvironment env, SyncPlugin syncPlugin, AbsoluteDate pointInTime, String domainZoneId, SyncPlot plot) {
		var parcels = syncPlugin.getLpisParcelsForPlotAlign(env, domainZoneId, pointInTime.toLocalDate(), plot.getGeom(), plot.getSrs());
		parcels = parcels.stream()
			.filter(parcel -> plot.getGeom().intersection(parcel.getGeom()).getArea() > 0)
			.sorted((p1, p2) -> {
				var i1 = plot.getGeom().intersection(p1.getGeom());
				var i2 = plot.getGeom().intersection(p2.getGeom());
				return i1.getArea() > i2.getArea() ? -1 : +1;
			})
			.collect(toList());
		return parcels;
	}

	public void recalcAnomalies(RuntimeEnvironment env, String businessId, Long cropPlanId, AbsoluteDate referenceDt, LocalDateTime versionDt)
	{
		validatorService.recalcAnomalies(env, new ValidatorSupport<ValidationResult>() {
			@Override
			public ValidatorData getValidatorData()
			{
				var validatorData = new ValidatorData();
				validatorData.setBusinessId(businessId);
				validatorData.setCropPlanId(cropPlanId);
				validatorData.setReferenceDt(referenceDt != null ? referenceDt.toLocalDate() : null);

				var boundedPlots = getCurrentPlots(env, cropPlanId, businessId, versionDt, referenceDt, null).stream()
						.map(sc -> new ValidatorBoundedPlot(sc.getPlotCode(), sc.getParcelCodes(), sc.getFromDate().toLocalDate(), sc.getToDate().toLocalDate(), ValidatorOperation.INSERT))
						.collect(toList());
				validatorData.setPlots(boundedPlots);

				List<ValidatorBoundedDeclaration> boundedDecls = new ArrayList<>();
				boundedPlots.forEach(bp -> {
					var decls = cropPlanDeclarationsService.getPlotDeclarations(env, businessId, cropPlanId, bp.getPlotCode(), null, versionDt,
							AbsoluteDate.of(bp.getFromDate()), AbsoluteDate.of(bp.getToDate()));
					boundedDecls.addAll(decls.stream()
							.map(d -> new ValidatorBoundedDeclaration(bp.getPlotCode(), bp.getParcelCodes(), d.getDeclId(), d.getDeclCode(), d.getLanduse().getCode(), d.getAreaPerc(),
									d.getFromDate().toLocalDate(), d.getToDate().toLocalDate(), d.getFromDatePrecision(), ValidatorOperation.INSERT))
							.collect(toList()));
				});
				validatorData.setDeclarations(boundedDecls);

				return validatorData;
			}

			@Override
			public ValidationResult getResult(List<ValidationMessage> msgs, List<String> updatedAnomaliesPlotCodes)
			{
				return null;
			}
		}, businessId, cropPlanId, versionDt);
	}
	
	public Boolean getReproportionDeclAreaOnSyncPlotAlign(Long cropPlanId) {
		List<CropPlanConfigData> reproportionDeclAreaOnSyncPlotAlignList = cropPlanConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.REPROPORTION_DECL_AREA_ON_SYNC_PLOT_ALIGN.toString(), "TRUE");
		Boolean reproportionDeclAreaOnSyncPlotAlign = reproportionDeclAreaOnSyncPlotAlignList.size() > 0;
		return reproportionDeclAreaOnSyncPlotAlign;
	}
}
