package com.abacogroup.cropplan.db.dao.ntt;

import org.locationtech.jts.geom.Geometry;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PlotDataParcelWithDomainZoneId {
	private String parcelCode;
	private String domainZoneId;
	private Geometry geom;
}
