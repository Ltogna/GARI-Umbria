package com.abacogroup.cropplan.api;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalFieldType;
import lombok.Data;

@Data
public class LandUseCommonAdditFieldsWithValuesReadDto {
	private String fieldCode;
	private String fieldDescription;
	private LandUseAdditionalFieldType fieldType;
	private AbsoluteDate validFrom;
	private AbsoluteDate validTo;
	private Integer sortOrder;
	private Boolean nullable;
	private String groupCode;
	private String headerTitleCode;
	private String headerTitleDescription;
	private Boolean flEditable;
	private String formula;
	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;
	private Integer flDefault;
	private Integer valueSortOrder;
	private String value;
	private String valueDescription;
}
