package com.abacogroup.cropplan.api;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Function Code that can be Disabled")
public enum DisabledFunctionCode
{
	ADD_DECLARATIONS,
	CUT_PLOTS,
	DELETE_DECLARATIONS,
	DELETE_PLOTS,
	EDIT_DECLARATIONS,
	EDIT_PLOTS,
	MERGE_DECLARATIONS,
	REPROPORTION_DECLARATIONS
}
