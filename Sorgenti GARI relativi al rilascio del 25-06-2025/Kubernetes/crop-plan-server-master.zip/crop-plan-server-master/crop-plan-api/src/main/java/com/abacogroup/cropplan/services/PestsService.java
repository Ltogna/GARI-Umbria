package com.abacogroup.cropplan.services;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.abacogroup.cropplan.api.PestEntry;
import com.abacogroup.cropplan.api.payload.InsertDeclPestPayload;
import com.abacogroup.cropplan.db.dao.CacheDecodesDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.db.dao.PestsDAO;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.sdk.model.pests.Pest;
import com.abacogroup.cropplan.sdk.spi.PestsPlugin;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import jakarta.ws.rs.BadRequestException;

public class PestsService
{
	private PestsDAO pestsDAO;
	private DeclarationsDAO declarationsDAO;
	private PluginManager pluginManager;
	private CacheDecodesDAO cacheDecodesDAO;


	public PestsService(DAOContainer daocontainer,
			PluginManager pluginManager)
	{
		this.pestsDAO = daocontainer.getPestsDAO();
		this.declarationsDAO = daocontainer.getDeclarationsDAO();
		this.cacheDecodesDAO = daocontainer.getCacheDecodesDAO();
		this.pluginManager = pluginManager;
	}

	public InfiniteListResults<PestEntry> getPestEntriesPaged(RuntimeEnvironment env, String businessId, Long planId, String tenantId, LocalDateTime version, String plotCode, String declCode, String search, String nextKey, int pageSize)
	{
		PestsPlugin pestsPlugin = pluginManager.getPestsPlugin(businessId, planId, tenantId);
		if (pestsPlugin == null)
			return new InfiniteListResultsImpl<>(new ArrayList<>(), null);

		// TODO: use valkey to lock cache while updating
		var cacheDt = pestsDAO.getCurrentTimestamp();
		var cacheValidityDt = cacheDt.minusDays(1);
		cacheDecodesDAO.clearCacheDecodes(planId, CacheDecodesDAO.CACHE_DECODES_TYPE.PESTS.toString(), cacheValidityDt);
		var pestCodesNotIn = pestsDAO.getPestCodesNotInCache(planId, version, CacheDecodesDAO.CACHE_DECODES_TYPE.PESTS.toString());
		if (pestCodesNotIn.size() > 0)
		{
			List<Pest> pests = new ArrayList<>();
			String nextKeyC = null;
			do
			{
				var pestPage = pestsPlugin.getPests(env, null, pestCodesNotIn.stream().map(code -> code.getPestCode()).collect(Collectors.toList()), nextKeyC);
				pests.addAll(pestPage.getRecords());			
				nextKeyC = pestPage.getNextKey();
				
			} while(nextKeyC != null);

			pests.forEach(pest -> {
				cacheDecodesDAO.insertCacheDecodes(planId, CacheDecodesDAO.CACHE_DECODES_TYPE.PESTS.toString(), cacheDt, pest.getPestCode(), pest.getPestName());
			});

			pests.forEach(pest -> {
				cacheDecodesDAO.insertCacheDecodes(planId, CacheDecodesDAO.CACHE_DECODES_TYPE.PESTS_QUARANTINE_DAYS.toString(), cacheDt, pest.getPestCode(), pest.getQuarantineDays().toString());
			});
		}

		var pestsEntries = pestsDAO.infinite(() -> pestsDAO.getPestEntries(planId, version, plotCode, declCode, null, search, CacheDecodesDAO.CACHE_DECODES_TYPE.PESTS.toString(),  CacheDecodesDAO.CACHE_DECODES_TYPE.PESTS_QUARANTINE_DAYS.toString()), nextKey, pageSize);

		return pestsEntries;
	}

	public void deletePests(String pestEntryCode, String declCode, String plotCode, Long cropPlanId, LocalDateTime deleteDt, String userId)
	{
		pestsDAO.deletePestsInternal(pestEntryCode, declCode, plotCode, cropPlanId, deleteDt, userId);
	}

	public void updatePests(String pestEntryCode, String declCode, String plotCode, Long cropPlanId, LocalDateTime updateDt, String userId, InsertDeclPestPayload payload)
	{
		pestsDAO.updatePest(pestEntryCode, declCode, plotCode, cropPlanId, updateDt, userId, payload);		
	}

	public void checkCanEditPestOnDeclaration(Long cropPlanId, String plotCode, String declCode)
	{
		var decl = declarationsDAO.getDeclarationByDeclCode(cropPlanId, plotCode, pestsDAO.getCurrentTimestamp(), declCode);
		if(decl == null)
			throw new BadRequestException("The decl " + declCode + " on plot " + plotCode + " was not found");
	}
}
