package com.abacogroup.cropplan.db.dao;

import com.abacogroup.cropplan.api.ValidationAnomalies;
import com.abacogroup.cropplan.sdk.mapper.VersionColumnMapper;
import com.abacogroup.cropplan.sdk.model.validation.AnomalyObjectType;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomaly;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomalyObject;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorData;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transaction;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(VersionColumnMapper.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface ValidatorDAO extends BasicDAO
{
	/**
	 * @param cropPlanId Long
	 * @return max(t.transaction_id) LocalDateTime
	 * check all tables with transaction_id: 
	 *  crpl_plot_data, crpl_declarations, crpl_perm_crop_forms, 
	 *  CRPL_MERGED_DECLS, CRPL_DECL_ADDIT_FIELDS, CRPL_DECL_PESTS 
	 *  & CRPL_DECL_PESTICIDES
	 */
	@SqlQuery("select max(t.transaction_id)"
		+ "      from ("
		+ "        select transaction_id"
		+ "          from crpl_plot_data"
		+ "         where transaction_id is not null"
		+ "           and plan_id = :cropPlanId"
		+ "         union"
		+ "        select transaction_id"
		+ "          from crpl_declarations"
		+ "         where transaction_id is not null"
		+ "           and plan_id = :cropPlanId"
		+ "         union"
		+ "        select transaction_id"
		+ "          from crpl_perm_crop_forms"
		+ "         where transaction_id is not null"
		+ "           and plan_id = :cropPlanId"
		+ "			union"
		+ "        select transaction_id"
		+ "          from CRPL_MERGED_DECLS"
		+ "         where transaction_id is not null"
		+ "           and plan_id = :cropPlanId"
		+ "			union"
		+ "        select transaction_id"
		+ "          from CRPL_DECL_ADDIT_FIELDS"
		+ "         where transaction_id is not null"
		+ "           and plan_id = :cropPlanId"
		+ "			union"
		+ "        select transaction_id"
		+ "          from CRPL_DECL_PESTS"
		+ "         where transaction_id is not null"
		+ "           and plan_id = :cropPlanId"
		+ "			union"
		+ "        select transaction_id"
		+ "          from CRPL_DECL_PESTICIDES"
		+ "         where transaction_id is not null"
		+ "           and plan_id = :cropPlanId"
		+ "      ) t")
	public LocalDateTime getActiveTransactionId(@Bind("cropPlanId") Long cropPlanId); 
	
	@SqlUpdate("update CRPL_DECL_ADDIT_FIELDS set transaction_id = null where transaction_id = :transId and plan_id = :cropPlanId")
	public void commitCrplDeclAdditFieldsTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);
	
	@SqlUpdate("update CRPL_DECL_PESTICIDES set transaction_id = null where transaction_id = :transId and plan_id = :cropPlanId")
	public void commitCrplDeclPesticidesTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);
	
	@SqlUpdate("update CRPL_DECL_PESTS set transaction_id = null where transaction_id = :transId and plan_id = :cropPlanId")
	public void commitCrplDeclPestsTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);
	
	@SqlUpdate("update crpl_plot_data set transaction_id = null where transaction_id = :transId and plan_id = :cropPlanId")
	public void commitPlotDataTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);

	@SqlUpdate("update crpl_declarations set transaction_id = null where transaction_id = :transId and plan_id = :cropPlanId")
	public void commitDeclarationsTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);

	@SqlUpdate("update crpl_perm_crop_forms set transaction_id = null where transaction_id = :transId and plan_id = :cropPlanId")
	public void commitPermanentCropFormsTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);

	@SqlUpdate("insert into crpl_anomalies(id, plan_id, object_code, object_type, error_code, blocking, user_id_insert, dt_insert, dt_delete)"
		+ "     values (:id, :cropPlanId, :object_code, :object_type, :error_code, :blocking, :user_id_insert, :dt_insert, TO_DATE('99991231','YYYYMMDD'))")
	public void saveAnomalies(
		@Bind("id") Long id,
		@Bind("cropPlanId") Long cropPlanId,
		@Bind("object_code") String fk_object_id,
		@Bind("object_type") String object_type,
		@Bind("error_code") String error_code,
		@Bind("blocking") Integer blocking,
		@Bind("user_id_insert") String user_id_insert,
		@Bind("dt_insert") LocalDateTime dt_insert);

	@SqlQuery("§select_nextval(crpl_anomalies_seq)§")
	public Long getAnomaliesSeq();

	@SqlQuery("select object_code as objectCode," +
			"         object_type as objectType, " +
			"         error_code as errorCode, " +
			"         §i18n(:tenantId, 'CRPL_ANOMALIES', 'ERROR_CODE', error_code, :language)§ as errorDescription," +
			"         blocking " +
			"    from crpl_anomalies " +
			"   where plan_id = :cropPlanId" +
			"     and :versionDt between dt_insert and dt_delete" +
			"   order by blocking, error_code, object_type")
	@RegisterBeanMapper(ValidationAnomaly.class)
	public ResultIterator<ValidationAnomaly> getCropPlanAnomalies(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt,
			@Bind("tenantId") String tenantId, @Bind("language") String language);

	@SqlQuery("select object_type as objectType," +
		"             error_code as errorCode," +
		"             §i18n(:tenantId, 'CRPL_ANOMALIES', 'ERROR_CODE:GENERIC', error_code, :language)§ as errorDescription," +
		"             blocking," +
		"             count(*) as numOfAnomalies" +
		"        from crpl_anomalies" +
		"       where plan_id = :cropPlanId" +
		"         and :versionDt between dt_insert and dt_delete" +
		"    group by blocking, error_code, object_type" +
		"    order by blocking, error_code, object_type")
	@RegisterBeanMapper(ValidationAnomalies.ValidationAnomalyByType.class)
	public List<ValidationAnomalies.ValidationAnomalyByType> getGroupedCropPlanAnomalies(@Bind("cropPlanId") Long cropPlanId, 
		@Bind("versionDt") LocalDateTime versionDt, @Bind("tenantId") String tenantId, @Bind("language") String language);

	@SqlQuery("SELECT t.blocking, \n"
			+ "       t.errorCode, \n"
			+ "       §i18n(:tenantId, 'CRPL_ANOMALIES', 'ERROR_CODE:GENERIC', t.errorCode, :language)§ as errorDescription,\n"
			+ "       t.objectType, \n"
			+ "       t.domainZoneId, \n"
			+ "       count(*) AS numOfAnomalies\n"
			+ "  FROM (\n"
			+ "	SELECT anom.object_type as objectType, \n"
			+ "	       anom.error_code as errorCode, \n"
			+ "		   anom.blocking as blocking, \n"
			+ "		   (SELECT min(cp.DOMAIN_ZONE_ID) \n"
			+ "			  FROM crpl_plot_data_parcels cpdp, CRPL_PLOT_DATA cpd, CRPL_PLOTS cp \n"
			+ "			 WHERE cpdp.PARCEL_CODE = anom.OBJECT_CODE \n"
			+ "            AND cpd.id = cpdp.PLOT_DATA_ID \n"
			+ "            AND cpd.PLAN_ID = anom.plan_id \n"
			+ "            AND :versionDt BETWEEN cpd.DT_INSERT AND cpd.DT_DELETE \n"
			+ "            AND (:pointInTime BETWEEN cpd.DAY_FROM AND cpd.DAY_TO or :pointInTime is null) \n"
			+ "			   AND cp.PLOT_CODE = cpd.PLOT_CODE \n"
			+ "			   AND cp.plan_id = cpd.PLAN_ID \n"
			+ "		) AS domainZoneId \n"
			+ "	  FROM crpl_anomalies anom\n"
			+ "	 where anom.PLAN_ID = :cropPlanId\n"
			+ "	   AND anom.OBJECT_TYPE = 'PARCEL'\n"
			+ "	   AND :versionDt between anom.dt_insert and anom.dt_delete\n"
			+ "	 UNION all\n"
			+ "	SELECT anom.object_type as objectType, \n"
			+ "	       anom.error_code as errorCode, \n"
			+ "		   anom.blocking as blocking,\n"
			+ "		   cp.DOMAIN_ZONE_ID AS domainZoneId\n"
			+ "	  FROM crpl_anomalies anom, CRPL_PLOTS cp \n"
			+ "	 where anom.PLAN_ID = :cropPlanId\n"
			+ "	   AND anom.OBJECT_TYPE = 'PLOT'\n"
			+ "	   AND :versionDt between anom.dt_insert and anom.dt_delete\n"
			+ "	   AND cp.PLAN_ID = anom.plan_id\n"
			+ "	   AND cp.PLOT_CODE = anom.OBJECT_CODE\n"
			+ "	 UNION all\n"
			+ "	SELECT anom.object_type as objectType, \n"
			+ "	       anom.error_code as errorCode, \n"
			+ "		   anom.blocking as blocking,\n"
			+ "		   cp.DOMAIN_ZONE_ID AS domainZoneId\n"
			+ "	  FROM crpl_anomalies anom, CRPL_DECLARATIONS cd, CRPL_PLOTS cp \n"
			+ "	 where anom.PLAN_ID = :cropPlanId\n"
			+ "	   AND anom.OBJECT_TYPE = 'DECLARATION'\n"
			+ "	   AND :versionDt between anom.dt_insert and anom.dt_delete\n"
			+ "	   AND cd.PLAN_ID = anom.plan_id\n"
			+ "	   AND cd.DECL_CODE = anom.OBJECT_CODE\n"
			+ "	   AND :versionDt BETWEEN cd.DT_INSERT AND cd.DT_DELETE \n"
			+ "	   AND cp.PLAN_ID = anom.plan_id\n"
			+ "	   AND cp.PLOT_CODE = cd.PLOT_CODE \n"
			+ "	 ) t\n"
			+ " GROUP BY t.blocking, t.errorCode, t.objectType, t.domainZoneId\n"
			+ " order by t.blocking, t.errorCode, t.objectType, t.domainZoneId")
	@RegisterBeanMapper(ValidationAnomalies.ValidationAnomalyByType.class)
	public List<ValidationAnomalies.ValidationAnomalyByType> getGroupedCropPlanAnomaliesWithDomainZoneId(@Bind("cropPlanId") Long cropPlanId, 
		@Bind("versionDt") LocalDateTime versionDt, @Bind("pointInTime") AbsoluteDate pointInTime,
		@Bind("tenantId") String tenantId, @Bind("language") String language);
	
	@SqlQuery("SELECT t.blocking, \n"
			+ "       t.errorCode, \n"
			+ "       §i18n(:tenantId, 'CRPL_ANOMALIES', 'ERROR_CODE:GENERIC', t.errorCode, :language)§ as errorDescription,\n"
			+ "       t.objectType, \n"
			+ "       t.domainZoneId, \n"
			+ "       count(*) AS numOfAnomalies\n"
			+ "  FROM (\n"
			+ "	SELECT anom.object_type as objectType, \n"
			+ "	       anom.error_code as errorCode, \n"
			+ "		   anom.blocking as blocking, \n"
			+ "		   (SELECT min(cp.DOMAIN_ZONE_ID) \n"
			+ "			  FROM crpl_plot_data_parcels cpdp, CRPL_PLOT_DATA cpd, CRPL_PLOTS cp \n"
			+ "			 WHERE cpdp.PARCEL_CODE = anom.OBJECT_CODE \n"
			+ "            AND cpd.id = cpdp.PLOT_DATA_ID \n"
			+ "            AND cpd.PLAN_ID = anom.plan_id \n"
			+ "            AND :versionDt BETWEEN cpd.DT_INSERT AND cpd.DT_DELETE \n"
			+ "            AND (:pointInTime BETWEEN cpd.DAY_FROM AND cpd.DAY_TO or :pointInTime is null) \n"
			+ "			   AND cp.PLOT_CODE = cpd.PLOT_CODE \n"
			+ "			   AND cp.plan_id = cpd.PLAN_ID \n"
			+ "		) AS domainZoneId \n"
			+ "	  FROM crpl_anomalies anom\n"
			+ "	 where anom.PLAN_ID = :cropPlanId\n"
			+ "	   AND anom.OBJECT_TYPE = 'PARCEL'\n"
			+ "	   AND :versionDt between anom.dt_insert and anom.dt_delete\n"
			+ "	 UNION all\n"
			+ "	SELECT anom.object_type as objectType, \n"
			+ "	       anom.error_code as errorCode, \n"
			+ "		   anom.blocking as blocking,\n"
			+ "		   cp.DOMAIN_ZONE_ID AS domainZoneId\n"
			+ "	  FROM crpl_anomalies anom, CRPL_PLOTS cp \n"
			+ "	 where anom.PLAN_ID = :cropPlanId\n"
			+ "	   AND anom.OBJECT_TYPE = 'PLOT'\n"
			+ "	   AND :versionDt between anom.dt_insert and anom.dt_delete\n"
			+ "	   AND cp.PLAN_ID = anom.plan_id\n"
			+ "	   AND cp.PLOT_CODE = anom.OBJECT_CODE\n"
			+ "	 UNION all\n"
			+ "	SELECT 'PLOT' as objectType, \n"
			+ "	       anom.error_code as errorCode, \n"
			+ "		   anom.blocking as blocking,\n"
			+ "		   cp.DOMAIN_ZONE_ID AS domainZoneId\n"
			+ "	  FROM crpl_anomalies anom, CRPL_DECLARATIONS cd, CRPL_PLOTS cp \n"
			+ "	 where anom.PLAN_ID = :cropPlanId\n"
			+ "	   AND anom.OBJECT_TYPE = 'DECLARATION'\n"
			+ "	   AND :versionDt between anom.dt_insert and anom.dt_delete\n"
			+ "	   AND cd.PLAN_ID = anom.plan_id\n"
			+ "	   AND cd.DECL_CODE = anom.OBJECT_CODE\n"
			+ "	   AND :versionDt BETWEEN cd.DT_INSERT AND cd.DT_DELETE \n"
			+ "	   AND cp.PLAN_ID = anom.plan_id\n"
			+ "	   AND cp.PLOT_CODE = cd.PLOT_CODE \n"
			+ "  GROUP BY anom.object_type, anom.error_code, anom.blocking, cp.domain_zone_id, cp.plot_code \n"
			+ "	 ) t\n"
			+ " GROUP BY t.blocking, t.errorCode, t.objectType, t.domainZoneId\n"
			+ " order by t.blocking, t.errorCode, t.objectType, t.domainZoneId")
	@RegisterBeanMapper(ValidationAnomalies.ValidationAnomalyByType.class)
	public List<ValidationAnomalies.ValidationAnomalyByType> getGroupedCropPlanAnomaliesWithDomainZoneIdGroupDeclAnomaliesOnPlots(@Bind("cropPlanId") Long cropPlanId, 
		@Bind("versionDt") LocalDateTime versionDt, @Bind("pointInTime") AbsoluteDate pointInTime,
		@Bind("tenantId") String tenantId, @Bind("language") String language);

	/// @deprecated do not consider object_code validity dates
	@Deprecated
	@SqlQuery("select count(*) " +
			"    from crpl_anomalies " +
			"   where plan_id = :cropPlanId" +
			"     and :versionDt between dt_insert and dt_delete" +
			"     and blocking = 1")
	public Integer countCropPlanBlockingAnomalies(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlQuery("select object_code as objectCode," +
			"         object_type as objectType, " +
			"         error_code as errorCode, " +
			"         §i18n(:tenantId, 'CRPL_ANOMALIES', 'ERROR_CODE', error_code, :language)§ as errorDescription," +
			"         blocking " +
			"    from crpl_anomalies " +
			"   where plan_id = :cropPlanId" +
			"     and :versionDt between dt_insert and dt_delete" +
			"     and object_type = :anomalyObjectType and object_code = :objCode")
	@RegisterBeanMapper(ValidationAnomaly.class)
	public List<ValidationAnomaly> getAnomaliesByObjectType(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt, 
			@Bind("objCode") String objCode, @Bind("anomalyObjectType") AnomalyObjectType anomalyObjectType,
			@Bind("tenantId") String tenantId, @Bind("language") String language);

	@SqlQuery("select object_code as objectCode," +
			  "         object_type as objectType, " +
			  "         error_code as errorCode, " +
			  "         §i18n(:tenantId, 'CRPL_ANOMALIES', 'ERROR_CODE', error_code, :language)§ as errorDescription," +
			  "         blocking " +
			  "    from crpl_anomalies " +
			  "   where plan_id = :cropPlanId" +
			  "     and :versionDt between dt_insert and dt_delete" +
			  "     and object_type = :anomalyObjectType and object_code = :objCode"
			  + " and error_code in (<errorCodes>) ")
	@RegisterBeanMapper(ValidationAnomaly.class)
	List<ValidationAnomaly> getAnomaliesByObjectType(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt,
			@Bind("objCode") String objCode, @Bind("anomalyObjectType") AnomalyObjectType anomalyObjectType,
			@BindList("errorCodes") List<String> errorCodes,
			@Bind("tenantId") String tenantId, @Bind("language") String language);

	@SqlUpdate("delete from crpl_plot_data_parcels where plot_data_id in (select id from crpl_plot_data where transaction_id = :transId and plan_id = :cropPlanId and :transId between dt_insert and dt_delete)")
	public void deletePlotDataParcelsTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);

	@SqlUpdate("delete from crpl_plot_data where transaction_id = :transId and plan_id = :cropPlanId and :transId between dt_insert and dt_delete")
	public void deletePlotDataTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);

	@SqlUpdate("update crpl_plot_data set transaction_id = null, dt_delete = TO_DATE('99991231','YYYYMMDD'), user_id_delete = null where transaction_id = :transId and plan_id = :cropPlanId and :transId > dt_delete")
	public void restorePlotDataTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);

	@SqlUpdate("delete from crpl_declarations where transaction_id = :transId and plan_id = :cropPlanId and :transId between dt_insert and dt_delete")
	public void deleteDeclarationsTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);

	@SqlUpdate("update crpl_declarations set transaction_id = null, dt_delete = TO_DATE('99991231','YYYYMMDD'), user_id_delete = null where transaction_id = :transId and plan_id = :cropPlanId and :transId > dt_delete")
	public void restoreDeclarationsTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);

	@SqlUpdate("delete from crpl_perm_crop_forms where transaction_id = :transId and plan_id = :cropPlanId and :transId between dt_insert and dt_delete")
	public void deletePermanentCropFormsTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);

	@SqlUpdate("update crpl_perm_crop_forms set transaction_id = null, dt_delete = TO_DATE('99991231','YYYYMMDD'), user_id_delete = null where transaction_id = :transId and plan_id = :cropPlanId and :transId > dt_delete")
	public void restorePermanentCropFormsTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);
	
	@SqlUpdate("delete from CRPL_DECL_ADDIT_FIELDS where transaction_id = :transId and plan_id = :cropPlanId and :transId between dt_insert and dt_delete")
	public void deleteCrplDeclAdditFieldsTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);
	
	@SqlUpdate("update CRPL_DECL_ADDIT_FIELDS set transaction_id = null, dt_delete = TO_DATE('99991231','YYYYMMDD'), user_id_delete = null where transaction_id = :transId and plan_id = :cropPlanId and :transId > dt_delete")
	public void restoreCrplDeclAdditFieldsTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);
	
	@SqlUpdate("delete from CRPL_DECL_PESTS where transaction_id = :transId and plan_id = :cropPlanId and :transId between dt_insert and dt_delete")
	public void deleteCrplDeclPestsTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);
	
	@SqlUpdate("update CRPL_DECL_PESTS set transaction_id = null, dt_delete = TO_DATE('99991231','YYYYMMDD'), user_id_delete = null where transaction_id = :transId and plan_id = :cropPlanId and :transId > dt_delete")
	public void restoreCrplDeclPestsTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);
	
	@SqlUpdate("delete from CRPL_DECL_PESTICIDES where transaction_id = :transId and plan_id = :cropPlanId and :transId between dt_insert and dt_delete")
	public void deleteCrplDeclPesticidesTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);
	
	@SqlUpdate("update CRPL_DECL_PESTICIDES set transaction_id = null, dt_delete = TO_DATE('99991231','YYYYMMDD'), user_id_delete = null where transaction_id = :transId and plan_id = :cropPlanId and :transId > dt_delete")
	public void restoreCrplDeclPesticidesTransactionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);
	
	
	
	@SqlUpdate("UPDATE CRPL_ANOMALIES SET DT_DELETE = :deleteDt, user_id_delete = :userId "
		+ "      WHERE PLAN_ID = :cropPlanId "
		+ "        AND (:objectCode is null or OBJECT_CODE = :objectCode) "
		+ "        AND (:objectType is null or OBJECT_TYPE = :objectType) "
		+ "        AND §current_timestamp§ BETWEEN DT_INSERT AND DT_DELETE")
	public void expireAnomalies(
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("deleteDt") LocalDateTime deleteDt,
			@Bind("userId") String userId,
			@Bind("objectCode") String objectCode,
			@Bind("objectType") String objectType);

	@Transaction
	default public void commitTransaction(RuntimeEnvironment env, Long cropPlanId, LocalDateTime versionDt, LocalDateTime transId, ValidatorData data,
			Map<ValidationAnomalyObject, List<ValidationAnomaly>> validationAnomalies, boolean clearCurrentAnomalies) {
		
		if (transId != null)
		{
			commitPlotDataTransactionInternal(cropPlanId, transId);
			commitDeclarationsTransactionInternal(cropPlanId, transId);
			commitPermanentCropFormsTransactionInternal(cropPlanId, transId);
			commitMergedDeclsInternal(cropPlanId, transId);
			commitCrplDeclAdditFieldsTransactionInternal(cropPlanId, transId);
			commitCrplDeclPesticidesTransactionInternal(cropPlanId, transId);
			commitCrplDeclPestsTransactionInternal(cropPlanId, transId);
		}

		var deleteDt = versionDt.minus(Duration.ofMillis(1));
		if (clearCurrentAnomalies)
		{
			expireAnomalies(cropPlanId, deleteDt, env.getUserId(), null, null);
		}
		/*else if (data != null)
		{
			List<String> parcelCodes = new ArrayList<>();
			var dataPlots = data.getPlots();
			var dataDecls = data.getDeclarations();
			
			if(dataDecls != null) {
				dataDecls.forEach(declaration -> {
					expireAnomalies(cropPlanId, deleteDt, env.getUserId(), declaration.getPlotCode(), AnomalyObjectType.PLOT.name());
					expireAnomalies(cropPlanId, deleteDt, env.getUserId(), declaration.getDeclCode(), AnomalyObjectType.DECLARATION.name());
				});
				
				parcelCodes.addAll(dataDecls
						.stream()
						.filter(dec -> dec.getOperation() == ValidatorOperation.INSERT || dec.getOperation() == ValidatorOperation.UPDATE)
						.flatMap(d -> d.getParcelCodes().stream())
						.collect(toList()));
			}
			
			if(dataPlots != null) {
				dataPlots.forEach(plot -> {
					expireAnomalies(cropPlanId, deleteDt, env.getUserId(), plot.getPlotCode(), AnomalyObjectType.PLOT.name());
				});
				
				parcelCodes.addAll(dataPlots
					.stream()
					.filter(plot -> plot.getOperation() == ValidatorOperation.INSERT || plot.getOperation() == ValidatorOperation.UPDATE)
					.flatMap(p -> p.getParcelCodes().stream())
					.collect(toList()));
			}
			
			// Compact the list
			parcelCodes = parcelCodes.stream().distinct().collect(toList());
			
			parcelCodes.forEach(parcel -> {
				expireAnomalies(cropPlanId, deleteDt, env.getUserId(), parcel, AnomalyObjectType.PARCEL.name());
			});
		}*/

		for (Entry<ValidationAnomalyObject, List<ValidationAnomaly>> entry : validationAnomalies.entrySet()) {
			if (!clearCurrentAnomalies)
				expireAnomalies(cropPlanId, deleteDt, env.getUserId(), entry.getKey().getObjectCode(), entry.getKey().getObjectType().name());
			
			for (ValidationAnomaly anomaly : entry.getValue()) {
				saveAnomalies(
						getAnomaliesSeq(),
						cropPlanId,
						anomaly.getObjectCode(),
						anomaly.getObjectType().name(),
						anomaly.getErrorCode(),
						anomaly.getBlocking() ? 1 : 0,
						env.getUserId(),
						versionDt);
			}
		}
	}

	@Transaction
	default public void rollbackTransaction(Long cropPlanId, LocalDateTime transId)
	{
		deletePlotDataParcelsTransactionInternal(cropPlanId, transId);
		deleteMergedDeclsInternal(cropPlanId, transId);

		deletePlotDataTransactionInternal(cropPlanId, transId);
		restorePlotDataTransactionInternal(cropPlanId, transId);

		deleteDeclarationsTransactionInternal(cropPlanId, transId);
		restoreDeclarationsTransactionInternal(cropPlanId, transId);

		deletePermanentCropFormsTransactionInternal(cropPlanId, transId);
		restorePermanentCropFormsTransactionInternal(cropPlanId, transId);
		
		deleteCrplDeclAdditFieldsTransactionInternal(cropPlanId, transId);
		restoreCrplDeclAdditFieldsTransactionInternal(cropPlanId, transId);
		
		deleteCrplDeclPestsTransactionInternal(cropPlanId, transId);
		restoreCrplDeclPestsTransactionInternal(cropPlanId, transId);
		
		deleteCrplDeclPesticidesTransactionInternal(cropPlanId, transId);
		restoreCrplDeclPesticidesTransactionInternal(cropPlanId, transId);
	}

	@SqlUpdate("update crpl_merged_decls set transaction_id = null where transaction_id = :transId and plan_id = :cropPlanId")
	public void commitMergedDeclsInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);

	@SqlUpdate("delete from crpl_merged_decls where transaction_id = :transId and plan_id = :cropPlanId")
	public void deleteMergedDeclsInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("transId") LocalDateTime transId);


}
