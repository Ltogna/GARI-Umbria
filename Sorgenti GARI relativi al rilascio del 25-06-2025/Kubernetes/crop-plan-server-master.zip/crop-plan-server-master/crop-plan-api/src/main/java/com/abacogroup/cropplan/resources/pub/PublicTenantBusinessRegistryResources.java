package com.abacogroup.cropplan.resources.pub;

import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.BaseResource;
import com.abacogroup.cropplan.sdk.model.business.Business;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.codahale.metrics.annotation.Timed;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("{tenant}/public")
@Tag(name = "PUBLIC - Business registry resources")
@Timed
@RolesAllowed({"CRPL|USER","CRPL|EDITOR"})
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class PublicTenantBusinessRegistryResources extends BaseResource
{
	private PluginManager pluginManager;

	public PublicTenantBusinessRegistryResources(BaseService baseService, PluginManager pluginManager)
	{
		super(baseService);
		this.pluginManager = pluginManager;
	}

	@GET
	@Path("/v1/business-registry")
	@Operation(description = "Search for a business")
	@ApiResponse(description = "The list of businesses that matches the search criteria")
	public InfiniteListResults<Business> searchBusiness(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The search string") @QueryParam("search") String search,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		return pluginManager.getBusinessPlugin().searchBusinessesInfinite(createEnvironment(user, language), search, nextKey);
	}
}
