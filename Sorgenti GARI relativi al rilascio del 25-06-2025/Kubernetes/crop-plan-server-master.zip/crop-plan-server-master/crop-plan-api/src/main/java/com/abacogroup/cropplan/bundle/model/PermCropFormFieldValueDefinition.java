package com.abacogroup.cropplan.bundle.model;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PermCropFormFieldValueDefinition
{
	private String formType;
	private String fieldCode;
	private String fieldValue;

	@Builder.Default
	private List<I18nValueDefinition> i18nValues = new ArrayList<>();
}
