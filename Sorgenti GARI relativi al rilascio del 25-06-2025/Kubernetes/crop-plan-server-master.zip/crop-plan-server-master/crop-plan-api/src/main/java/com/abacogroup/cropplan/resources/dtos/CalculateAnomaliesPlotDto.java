package com.abacogroup.cropplan.resources.dtos;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Data
public class CalculateAnomaliesPlotDto {
	@NotNull
	private String plotCode;
	private List<String> declCodes;
}
