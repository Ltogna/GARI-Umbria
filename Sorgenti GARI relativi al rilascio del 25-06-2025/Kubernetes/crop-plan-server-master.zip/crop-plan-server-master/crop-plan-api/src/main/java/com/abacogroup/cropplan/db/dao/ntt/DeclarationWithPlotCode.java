package com.abacogroup.cropplan.db.dao.ntt;

import com.abacogroup.cropplan.sdk.model.Declaration;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class DeclarationWithPlotCode extends Declaration
{
	@JsonIgnore
	private String plotCode;
	
	public String getPlotCodeDeclCodeKey() {
		return plotCode + "|" + getDeclCode();
	}
}
