package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class InvalidDeclException extends WebApplicationException
{
	private static final long serialVersionUID = 8706674880381003148L;

	public static  class InvalidDeclExceptionErrorBody
	{
		@Schema(allowableValues = "INVALID_DECLARATION_EXCEPTION")
		public String getErrorCode()
		{
			return "INVALID_DECLARATION_EXCEPTION";
		}
	}
	
	private static final InvalidDeclExceptionErrorBody BODY = new InvalidDeclExceptionErrorBody();

	public InvalidDeclException(String cause)
	{
		super("Invalid declaration: " + cause,
			Response.status(Status.BAD_REQUEST).entity(BODY).build());
	}
}
