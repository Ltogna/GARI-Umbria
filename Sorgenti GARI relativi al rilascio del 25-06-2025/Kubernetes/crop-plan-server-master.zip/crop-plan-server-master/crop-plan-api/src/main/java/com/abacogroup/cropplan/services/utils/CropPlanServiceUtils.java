package com.abacogroup.cropplan.services.utils;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.summingDouble;
import static java.util.stream.Collectors.summingInt;
import static java.util.stream.Collectors.toList;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.stream.Collectors;

import org.javatuples.Triplet;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.cropplan.api.CropPlan;
import com.abacogroup.cropplan.api.EditDeclarationResult;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.PlotDataToInclude;
import com.abacogroup.cropplan.api.PlotEditability;
import com.abacogroup.cropplan.api.ValidationAnomalies;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.db.dao.PrintsDAO;
import com.abacogroup.cropplan.db.dao.SyncDAO;
import com.abacogroup.cropplan.db.dao.ValidatorDAO;
import com.abacogroup.cropplan.db.dao.ntt.DeclarationWithPlotCode;
import com.abacogroup.cropplan.db.dao.ntt.FunctionDisableConfig;
import com.abacogroup.cropplan.db.dao.ntt.ParcelCodeWithPlotId;
import com.abacogroup.cropplan.db.dao.ntt.ParcelIntersectionWithPlotId;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandCoverClassEditability;
import com.abacogroup.cropplan.sdk.model.domain.BaseDomainZone;
import com.abacogroup.cropplan.sdk.model.domain.DomainZoneGeometry;
import com.abacogroup.cropplan.sdk.model.domain.ParcelDescription;
import com.abacogroup.cropplan.sdk.model.sync.LatestSync;
import com.abacogroup.cropplan.sdk.model.validation.AnomalyObjectType;
import com.abacogroup.cropplan.sdk.model.validation.ValidationMessage;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedDeclaration;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorData;
import com.abacogroup.cropplan.sdk.spi.CropCodesPlugin;
import com.abacogroup.cropplan.sdk.spi.DomainPlugin;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.CropPlanDeclarationsService;
import com.abacogroup.cropplan.services.support.ValidatorSupport;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.google.common.collect.Iterators;
import com.google.common.collect.Lists;
import com.google.common.collect.UnmodifiableIterator;

public class CropPlanServiceUtils {

	private CropPlanConfigService cropPlanConfigService;
	private CropPlanDeclarationsService cropPlanDeclarationsService;
	private CropPlansDAO cropPlansDAO;
	private ValidatorDAO validatorDAO;
	private DeclarationsDAO declarationsDAO;
	private PrintsDAO printsDAO;
	private SyncDAO syncDAO;
	private PluginManager pluginManager;

	public CropPlanServiceUtils(CropPlanConfigService cropPlanConfigService, CropPlanDeclarationsService cropPlanDeclarationsService,
			DAOContainer daocontainer, PluginManager pluginManager) {

		this.cropPlanConfigService = cropPlanConfigService;
		this.cropPlanDeclarationsService = cropPlanDeclarationsService;
		this.cropPlansDAO = daocontainer.getCropPlansDAO();
		this.validatorDAO = daocontainer.getValidatorDAO();
		this.declarationsDAO = daocontainer.getDeclarationsDAO();
		this.printsDAO = daocontainer.getPrintsDAO();
		this.syncDAO = daocontainer.getSyncDAO();
		this.pluginManager = pluginManager;
	}

	public void populateCropPlansData(List<CropPlan> cropPlans, String businessId, RuntimeEnvironment env) {
		if (cropPlans.size() == 0)
			return;

		var ids = cropPlans.stream()
				.map(e -> e.getCropPlanId())
				.collect(toList());

		Map<Long, LocalDateTime> lastVersions = cropPlansDAO.getLastVersions(ids);

		cropPlans.forEach(c -> {
			Boolean isChangesPending = isCropPlanChangesPending(env, businessId, c.getCropPlanId(),
					lastVersions.containsKey(c.getCropPlanId()) ? lastVersions.get(c.getCropPlanId())
							: LocalDateTime.of(1700, 1, 1, 0, 0, 0));
			c.setChangesPending(isChangesPending);
			var cropPlanPlugin = pluginManager.getCropPlanPlugin(businessId, c.getCropPlanId(), env.getTenantId());
			var canAddPlots = cropPlanPlugin.canAddPlots(env, businessId, c.getCropPlanId());
			var isReadOnly = isCropPlanNotManaged(c.getCropPlanId());
			if (!isReadOnly) {
				isReadOnly = cropPlanPlugin.isReadOnly(env, businessId, c.getCropPlanId());
			}
			c.setReadOnly(isReadOnly);

			String lockedErrorCode = pluginManager.getAuthPlugin().getCropPlanTypeLockedErrorCode(env, businessId, c.getCropPlanTypeCode());
			c.setLocked(lockedErrorCode != null);
			c.setLockedErrorCode(lockedErrorCode);

			c.setCanAddPlots(canAddPlots);

			c.setCropPlanPrints(printsDAO.getCropPlanPrints(env.getTenantId(), c.getCropPlanTypeCode(), env.getLocale().getLanguage()));
		});
	}

	public boolean isCropPlanNotManaged(Long cropPlanId) {
		return cropPlansDAO.isCropPlanNotManaged(cropPlanId);
	}

	public boolean isCropPlanChangesPending(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime versionDt) {
		var isChangesPending = cropPlansDAO.isCropPlanChangesPending(cropPlanId, versionDt);
		if (!isChangesPending) {
			return pluginManager.getCropPlanPlugin(businessId, cropPlanId, env.getTenantId()).isExternalChangesPending(env, businessId, cropPlanId, versionDt);
		}
		return isChangesPending;
	}

	public InfiniteListResults<Plot> getPlotsInternal(RuntimeEnvironment env, String businessId, Long cropPlanId,
			String domainZoneId, LocalDateTime versionDt, AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo,
			String plotCode, String parcelCodeStartsWith, Long subdomainZoneId,
			String nextKey, int pageSize, PlotDataToInclude plotDataToInclude) {

		InfiniteListResults<Plot> plots = cropPlansDAO.infinite(
				() -> cropPlansDAO.getPlotsInternal(cropPlanId, domainZoneId, versionDt, pointInTimeFrom, pointInTimeTo,
						plotCode, parcelCodeStartsWith, subdomainZoneId),
				nextKey,
				pageSize);

		return this.fillPlots(env, businessId, cropPlanId, versionDt, pointInTimeFrom, pointInTimeTo, plotDataToInclude, plots);
	}

	/**
	 * @param env
	 * @param businessId
	 * @param cropPlanId
	 * @param domainZoneId
	 * @param geom
	 * @param versionDt
	 * @param pointInTimeFrom
	 * @param pointInTimeTo
	 * @param nextKey
	 * @param pageSize
	 * @param plotDataToInclude
	 * @param plain
	 *            true --> returns no additional data, false --> fill plots
	 * @return
	 */
	public InfiniteListResults<Plot> getPlotsByIntersection(RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId, Geometry geom,
			LocalDateTime versionDt, AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo,
			String nextKey, int pageSize, PlotDataToInclude plotDataToInclude, boolean plain) {

		InfiniteListResults<Plot> plots = cropPlansDAO.infinite(
				() -> cropPlansDAO.findPlotsByGeomIntersects(cropPlanId, domainZoneId, geom, versionDt, pointInTimeFrom, pointInTimeTo),
				nextKey,
				pageSize);

		if (plain) {
			return plots;
		} else {
			return this.fillPlots(env, businessId, cropPlanId, versionDt, pointInTimeFrom, pointInTimeTo, plotDataToInclude, plots);
		}
	}

	public InfiniteListResults<Plot> getPlotsWithNoDeclsInRange(RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId,
			LocalDateTime versionDt, AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo,
			String nextKey, int pageSize, PlotDataToInclude plotDataToInclude) {

		plotDataToInclude.setDecls(false);
		plotDataToInclude.setDeclsPesticides(false);
		plotDataToInclude.setDeclsStyle(false);

		InfiniteListResults<Plot> plots = cropPlansDAO.infinite(
				() -> cropPlansDAO.findPlotsWithNoDeclsInRange(cropPlanId, domainZoneId, versionDt, pointInTimeFrom, pointInTimeTo),
				nextKey,
				pageSize);

		return this.fillPlots(env, businessId, cropPlanId, versionDt, pointInTimeFrom, pointInTimeTo, plotDataToInclude, plots);
	}

	public Plot fillPlot(RuntimeEnvironment env, String businessId, Long cropPlanId, Plot plot,
			LocalDateTime versionDt, AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo,
			PlotDataToInclude plotDataToInclude) {
		InfiniteListResults<Plot> plotInfiniteListResults = this.fillPlots(env, businessId, cropPlanId, versionDt, pointInTimeFrom, pointInTimeTo,
				plotDataToInclude, new InfiniteListResultsImpl<>(List.of(plot), null));

		return Optional.of(plotInfiniteListResults)
				.map(InfiniteListResults::getRecords)
				.stream().flatMap(Collection::stream)
				.findFirst()
				.orElse(null);
	}

	public InfiniteListResults<Plot> fillPlots(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime versionDt,
			AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo, PlotDataToInclude plotDataToInclude, InfiniteListResults<Plot> plots) {
		var cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId());
		var domainPlugin = pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId());

		Map<String, List<DeclarationWithPlotCode>> declarationsByPlots = plotDataToInclude.getDecls() ? loadDeclarationsByPlots(cropPlanId,
				versionDt, pointInTimeFrom, pointInTimeTo, plots.getRecords()) : new HashMap<String, List<DeclarationWithPlotCode>>();

		Map<Long, List<ParcelIntersection>> parcelsIntersectionByPlotId = plotDataToInclude.getParcInt()
				? loadParcelsIntersectionByPlotId(env, cropPlanId, businessId, versionDt,
						plots.getRecords().stream()
								.map(r -> r.getPlotId())
								.collect(toList()))
				: new HashMap<Long, List<ParcelIntersection>>();

		Map<String, LandCoverClassEditability> editabilities = new HashMap<>();

		plots.getRecords().forEach(p -> {
			fillPlotsDeclarations(plotDataToInclude, declarationsByPlots, p);

			if (plotDataToInclude.getParcInt()) {
				p.setParcelIntersections(
						parcelsIntersectionByPlotId.compute(p.getPlotId(), (k, v) -> v == null ? new ArrayList<>(0) : v));
			}

			fillPlotsMbrOverviewData(env, businessId, plotDataToInclude, domainPlugin, p);
		});

		fillPlotsParcelDescriptionsData(env, businessId, plotDataToInclude, domainPlugin, plots);
		fillPlotsLandCoverDescriptionsData(env, plotDataToInclude, cropCodesPlugin, plots);
		fillPlotsDeclarationsData(env, businessId, cropPlanId, versionDt, plotDataToInclude, plots);

		plots.getRecords().forEach(p -> {
			fillPlotStyleData(env, businessId, cropPlanId, plotDataToInclude, p);
			fillPlotsAnomaliesData(env, cropPlanId, versionDt, plotDataToInclude, p);

			if (plotDataToInclude.getParcInt()) {
				fillPlotsEditabilityData(env, businessId, plotDataToInclude, cropCodesPlugin, editabilities, p);
			}
		});

		return plots;
	}

	private void fillPlotsDeclarations(PlotDataToInclude plotDataToInclude, Map<String, List<DeclarationWithPlotCode>> declarationsByPlots, Plot p) {
		if (plotDataToInclude.getDecls()) {
			p.setDecls(declarationsByPlots.compute(p.getPlotCode(), (k, v) -> v == null ? new ArrayList<>(0) : v)
					.stream()
					.map(decl -> (Declaration) decl)
					.collect(toList()));
		}
	}

	private void fillPlotsAnomaliesData(RuntimeEnvironment env, Long cropPlanId, LocalDateTime versionDt, PlotDataToInclude plotDataToInclude, Plot p) {
		if (plotDataToInclude.getAnomalies()) {
			p.setAnomalies(validatorDAO.getAnomaliesByObjectType(cropPlanId, versionDt, p.getPlotCode(), AnomalyObjectType.PLOT,
					env.getTenantId(), env.getLocale().getLanguage()));
		}
	}

	private void fillPlotsMbrOverviewData(RuntimeEnvironment env, String businessId, PlotDataToInclude plotDataToInclude, DomainPlugin domainPlugin, Plot p) {
		if (plotDataToInclude.getMbrOverview()) {
			/*** load MBR overview from external plugin ***/
			var parcelCodes = p.getParcelIntersections().stream()
					.map(ParcelIntersection::getCode)
					.collect(toList());
			Geometry mbrOverview = domainPlugin.getMBROverview(env, businessId, parcelCodes, p.getFromDate().toLocalDate());
			if (mbrOverview == null)
				mbrOverview = p.getGeom().getEnvelope();
			p.setMbrOverview(mbrOverview);
		}
	}

	private void fillPlotsEditabilityData(RuntimeEnvironment env, String businessId, PlotDataToInclude plotDataToInclude, CropCodesPlugin cropCodesPlugin,
			Map<String, LandCoverClassEditability> editabilities, Plot plot) {
		if (plotDataToInclude.getPlotEditability()) {
			/*** load plot editability from external plugin ***/
			plot.setEditability(PlotEditability.EDITABLE);
			if (plot.getParcelIntersections().size() > 0) {
				fillPlotsEditabilityDataByParcelIntersections(env, businessId, cropCodesPlugin, editabilities, plot);
			} else {
				var editability = editabilities.get(null);
				if (editability == null) {
					editability = cropCodesPlugin.getLandCoverEditability(env, businessId, null);
					editabilities.put(null, editability);
				}
				if (editability == LandCoverClassEditability.NOT_EDITABLE) {
					plot.setEditability(PlotEditability.NOT_EDITABLE);
				} else if (editability == LandCoverClassEditability.ONLY_DECLARATIONS) {
					plot.setEditability(PlotEditability.ONLY_DECLARATIONS);
				}
			}
		}
	}

	private void fillPlotsEditabilityDataByParcelIntersections(RuntimeEnvironment env, String businessId, CropCodesPlugin cropCodesPlugin,
			Map<String, LandCoverClassEditability> editabilities, Plot plot) {
		for (var parcel : plot.getParcelIntersections()) {
			var editability = editabilities.get(parcel.getLandCoverCode());
			if (editability == null) {
				editability = cropCodesPlugin.getLandCoverEditability(env, businessId, parcel.getLandCoverCode());
				editabilities.put(parcel.getLandCoverCode(), editability);
			}

			if (editability == LandCoverClassEditability.NOT_EDITABLE) {
				plot.setEditability(PlotEditability.NOT_EDITABLE);
				break;
			} else if (editability == LandCoverClassEditability.ONLY_DECLARATIONS) {
				plot.setEditability(PlotEditability.ONLY_DECLARATIONS);
			}
		}
	}

	private void fillPlotsParcelDescriptionsData(RuntimeEnvironment env, String businessId, PlotDataToInclude plotDataToInclude, DomainPlugin domainPlugin,
			InfiniteListResults<Plot> plots) {
		if (plotDataToInclude.getParcIntDesc()) {
			/*** load parcel descriptions from external plugin ***/
			Map<AbsoluteDate, List<Plot>> plotsByToDate = plots.getRecords().stream()
					.collect(groupingBy(Plot::getToDate));

			plotsByToDate.keySet().forEach(toDate -> {
				Map<String, List<ParcelIntersection>> allParcelIntersectionsByParcelCode = plotsByToDate.get(toDate).stream()
						.flatMap(plot -> plot.getParcelIntersections().stream())
						.collect(groupingBy(ParcelIntersection::getCode));

				UnmodifiableIterator<List<String>> partitionsOfParcelCodes = Iterators.partition(
						allParcelIntersectionsByParcelCode.keySet().iterator(),
						666);
				partitionsOfParcelCodes.forEachRemaining(partition -> {
					Map<String, ParcelDescription> parcelDescriptions = domainPlugin.getParcelsDescription(env, businessId, toDate.toLocalDate(), partition);
					parcelDescriptions.keySet().forEach(parcelCode -> allParcelIntersectionsByParcelCode.get(parcelCode)
							.forEach(parcelIntersection -> {
								parcelIntersection.setDescription(parcelDescriptions.get(parcelCode).getDescription());
								parcelIntersection.setParcelCode(parcelDescriptions.get(parcelCode).getParcelCode());
								parcelIntersection.setHoldingPercentage(parcelDescriptions.get(parcelCode).getHoldingPercentage());
							}));
				});
			});
		}
	}

	private void fillPlotsLandCoverDescriptionsData(RuntimeEnvironment env, PlotDataToInclude plotDataToInclude, CropCodesPlugin cropCodesPlugin,
			InfiniteListResults<Plot> plots) {
		if (plotDataToInclude.getParcIntLandCoverDesc()) {
			/*** load land cover descriptions from external plugin ***/
			Map<String, List<ParcelIntersection>> allParcelIntersectionsByLandCoverCode = plots.getRecords().stream()
					.flatMap(plot -> plot.getParcelIntersections().stream())
					.filter(parcel -> parcel.getLandCoverCode() != null)
					.collect(groupingBy(parcel -> parcel.getLandCoverCode()));

			UnmodifiableIterator<List<String>> partitionsOfLandCovers = Iterators.partition(
					allParcelIntersectionsByLandCoverCode.keySet().iterator(),
					666);
			partitionsOfLandCovers.forEachRemaining(partition -> {
				Map<String, String> landCoverDescriptions = cropCodesPlugin.getLandCoverDescriptions(env, partition);
				landCoverDescriptions.keySet().forEach(landCoverCode -> allParcelIntersectionsByLandCoverCode.get(landCoverCode)
						.forEach(parcelIntersection -> parcelIntersection.setLandCoverDescription(landCoverDescriptions.get(landCoverCode))));
			});
		}
	}

	private void fillPlotsDeclarationsData(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime versionDt,
			PlotDataToInclude plotDataToInclude, InfiniteListResults<Plot> plots) {
		if (plotDataToInclude.getDecls()) {
			/*** load land use descriptions and styles from external plugin ***/
			/*** load also anomalies, permanent crop forms and pesticides (plotCode is required) ***/
			List<DeclarationWithPlotCode> decls = plots.getRecords().stream()
					.flatMap(plot -> plot.getDecls().stream()
							.map(decl -> {
								DeclarationWithPlotCode ret = (DeclarationWithPlotCode) decl;
								ret.setPlotCode(plot.getPlotCode());
								return ret;
							}))
					.collect(toList());
			cropPlanDeclarationsService.fillDeclarationsData(env, decls, businessId, cropPlanId, versionDt, plotDataToInclude);
			plots.getRecords().forEach(p -> p.getDecls().sort(Comparator.comparing(Declaration::getSorting, Comparator.nullsLast(Comparator.naturalOrder()))));
		}
	}

	public Map<String, List<DeclarationWithPlotCode>> loadDeclarationsByPlots(Long cropPlanId,
			LocalDateTime versionDt, AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo, List<Plot> plots) {
		List<String> plotCodes = plots.stream()
				.map(r -> r.getPlotCode())
				.collect(toList());

		List<List<String>> partitions = Lists.partition(plotCodes, 666);
		return partitions.stream()
				.flatMap(part -> declarationsDAO.getPlotsDeclarationsInternal(cropPlanId, part, versionDt, pointInTimeFrom, pointInTimeTo).stream())
				.collect(groupingBy(row -> row.getPlotCode()));
	}

	public Map<Long, List<ParcelIntersection>> loadParcelsIntersectionByPlotId(RuntimeEnvironment env, Long cropPlanId, String businessId,
			LocalDateTime versionDt, List<Long> plotIds) {
		var pesticidePlugin = this.pluginManager.getPesticidesPlugin(businessId, cropPlanId, env.getTenantId());
		List<List<Long>> partitions = Lists.partition(plotIds, 666);
		return partitions.stream()
				.flatMap(part -> cropPlansDAO.getPlotsParcelsInternal(part, cropPlanId, versionDt).stream())
				.map(m -> {
					m.setAnomalies(validatorDAO.getAnomaliesByObjectType(cropPlanId, versionDt, m.getCode(), AnomalyObjectType.PARCEL,
							env.getTenantId(), env.getLocale().getLanguage()));
					if (pesticidePlugin != null)
						m.setCanDeclarePesticides(pesticidePlugin.checkCanDeclarePesticidesOnParcel(env, m.getCode()));
					else
						m.setCanDeclarePesticides(false);
					return (ParcelIntersection) m;
				})
				.collect(groupingBy(row -> ((ParcelIntersectionWithPlotId) row).getPlotId()));
	}

	public Map<Long, List<ParcelCodeWithPlotId>> loadParcelsCodesByPlotId(Long cropPlanId, LocalDateTime versionDt, List<Long> plotIds) {
		List<List<Long>> partitions = Lists.partition(plotIds, 666);
		return partitions.stream()
				.flatMap(part -> cropPlansDAO.getPlotsParcelCodesInternal(part, cropPlanId, versionDt).stream())
				.collect(groupingBy(row -> row.getPlotId()));
	}

	private void fillPlotStyleData(RuntimeEnvironment env, String businessId, Long cropPlanId, PlotDataToInclude plotDataToInclude, Plot plot) {
		if (plotDataToInclude.getParcStyle()) {
			var cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId());

			Map<String, Double> groupedDecls = plotDataToInclude.getDecls()
					? plot.getDecls().stream().collect(groupingBy(Declaration::getDeclCode, summingDouble(Declaration::getAreaPerc)))
					: new HashMap<>();

			Optional<Entry<String, Double>> maxDeclEntry = groupedDecls.entrySet().stream()
					.max(Entry.comparingByValue());

			List<Declaration> maxPlotDecl = plotDataToInclude.getDecls()
					? plot.getDecls().stream().filter(d -> d.getDeclCode().equals(maxDeclEntry.get().getKey())).collect(toList())
					: new ArrayList<>();

			if (maxPlotDecl.size() > 0) {
				plot.setStyle(maxPlotDecl.get(0).getStyle());
			} else {
				Map<String, Integer> groupedLandCovers = plot.getParcelIntersections().stream()
						.filter(p -> p.getLandCoverCode() != null)
						.collect(groupingBy(ParcelIntersection::getLandCoverCode,
								summingInt(ParcelIntersection::getAreaSqm)));

				Optional<Entry<String, Integer>> maxLandCoverEntry = groupedLandCovers.entrySet().stream()
						.max(Comparator.comparing(Map.Entry::getValue));
				if (!maxLandCoverEntry.isEmpty()) {
					var landCoverCode = maxLandCoverEntry.get().getKey();
					var styles = cropCodesPlugin.getLandCoverStyles(env, Arrays.asList(landCoverCode));
					plot.setStyle(styles.get(landCoverCode));
				} else {
					plot.setStyle(cropCodesPlugin.getDefaultStyle(env));
				}
			}
		}
	}

	/**
	 * if the anomailesCodesList match the combination of the configurationMap then the Anomalies are blocking for functions
	 */
	public boolean isFunctionDisabledByAnomaliesScenarioConfig(List<FunctionDisableConfig> functionDisableConfigs,
			List<String> anomaliesCodesList) {

		Map<String, List<FunctionDisableConfig>> configGroupByScenario = functionDisableConfigs.stream()
				.collect(Collectors.groupingBy(FunctionDisableConfig::getScenario));

		for (String scenarioId : configGroupByScenario.keySet()) {
			if (checkScenario(configGroupByScenario.get(scenarioId), anomaliesCodesList))
				return true;
		}
		return false;
	}

	private boolean checkScenario(List<FunctionDisableConfig> scenarioConf, List<String> anomaliesCodesList) {
		var scenarioConfList = scenarioConf.stream()
				.map(e -> {
					Boolean returnValue = false;
					if (e.getAnomaliyPresent() == null)
						returnValue = null;
					else {
						if (e.getAnomaliyPresent().booleanValue() == true && anomaliesCodesList.contains(e.getAnomaliyCode()) ||
								e.getAnomaliyPresent().booleanValue() == false && !anomaliesCodesList.contains(e.getAnomaliyCode())) {
							returnValue = true;
						}
					}
					return returnValue;
				})
				.filter(val -> val != null)
				.collect(toList());

		// se ho trovato una combinazione di blocco valida esco
		return scenarioConfList.size() > 0 && scenarioConfList.stream().allMatch(val -> val == true);
	}

	public List<ValidationAnomalies.ValidationAnomalyByType> getGroupedCropPlanAnomaliesWithDomainZone(
			RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime versionDt, boolean groupDeclAnomaliesOnPlots) {
		LatestSync latestSync = syncDAO.getLatestSync(cropPlanId);
		AbsoluteDate lastSyncReferenceDt = latestSync != null ? latestSync.getReferenceDate() : null;
		List<ValidationAnomalies.ValidationAnomalyByType> validationAnomalies = groupDeclAnomaliesOnPlots
				? validatorDAO.getGroupedCropPlanAnomaliesWithDomainZoneIdGroupDeclAnomaliesOnPlots(cropPlanId, versionDt, lastSyncReferenceDt,
						env.getTenantId(), env.getLocale().getLanguage())
				: validatorDAO.getGroupedCropPlanAnomaliesWithDomainZoneId(cropPlanId, versionDt, lastSyncReferenceDt, env.getTenantId(),
						env.getLocale().getLanguage());

		Map<Triplet<Boolean, String, AnomalyObjectType>, ValidationAnomalies.ValidationAnomalyByType> validationAnomalyFulfilled = new HashMap<>();

		Map<Triplet<Boolean, String, AnomalyObjectType>, List<ValidationAnomalies.ValidationAnomalyByType>> validationAnomalyMap = validationAnomalies.stream()
				.collect(groupingBy(validationAnomaly -> new Triplet<>(validationAnomaly.getBlocking(), validationAnomaly.getErrorCode(),
						validationAnomaly.getObjectType())));

		Map<String, BaseDomainZone> baseDomainZonesMap = new HashMap<>();
		AbsoluteDate snapFromDate = cropPlanConfigService.getSnapFromDate(cropPlanId, AbsoluteDate.of(versionDt.toLocalDate()));
		validationAnomalyMap.entrySet().stream()
				.forEach(mapEntry -> {
					evaluateValidationAnomalyMapEntry(env, businessId, cropPlanId, snapFromDate, baseDomainZonesMap, validationAnomalyFulfilled, mapEntry);
				});

		validationAnomalies = new ArrayList<ValidationAnomalies.ValidationAnomalyByType>(validationAnomalyFulfilled.values());
		return validationAnomalies;
	}

	private void evaluateValidationAnomalyMapEntry(RuntimeEnvironment env, String businessId, Long cropPlanId, AbsoluteDate snapFromDate, Map<String, BaseDomainZone> baseDomainZonesMap,
			Map<Triplet<Boolean, String, AnomalyObjectType>, ValidationAnomalies.ValidationAnomalyByType> validationAnomalyFulfilled,
			Entry<Triplet<Boolean, String, AnomalyObjectType>, List<ValidationAnomalies.ValidationAnomalyByType>> mapEntry) {
		// validationAnomaly <Blocking, ErrorCode, ObjectType>
		Triplet<Boolean, String, AnomalyObjectType> mapKey = mapEntry.getKey();
		List<ValidationAnomalies.ValidationAnomalyByType> mapValues = mapEntry.getValue();
		mapValues.forEach(validationAnomaly -> {
			// check if this mapKey (Triplet) is already present if is not must be added if present must be updated
			// things to do:
			// - update the NumOfAnomalies
			// - update the baseDomainZoneList if BaseDomainZone with domainZoneId not already added
			var mapKeyFound = validationAnomalyFulfilled.containsKey(mapKey);
			if (mapKeyFound) {
				// mapKey found so get the ValidationAnomalyByType from the map to update it
				var validationAnomalyFulfilledValue = validationAnomalyFulfilled.get(mapKey);
				// update the NumOfAnomalies
				validationAnomalyFulfilledValue
						.setNumOfAnomalies(validationAnomalyFulfilledValue.getNumOfAnomalies() + validationAnomaly.getNumOfAnomalies());
			} else {
				// mapKey not found so must add the validationAnomaly to the map with the new key
				validationAnomalyFulfilled.put(mapKey, validationAnomaly);
			}

			if (baseDomainZonesMap.get(validationAnomaly.getDomainZoneId()) == null) {
				BaseDomainZone baseDomainZone = new BaseDomainZone();
				baseDomainZone.setDomainZoneId(validationAnomaly.getDomainZoneId());
				DomainZoneGeometry domainZone = pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId())
						.getDomainZone(env, businessId, snapFromDate.toLocalDate(), validationAnomaly.getDomainZoneId());
				if (domainZone != null) {
					baseDomainZone.setCode(domainZone.getCode());
					baseDomainZone.setDescription(domainZone.getDescription());
				}
				baseDomainZonesMap.put(validationAnomaly.getDomainZoneId(), baseDomainZone);
			}

			// check if the domainZoneId of this record is already present into the list of baseDomainZone? if not it must be set
			if (validationAnomalyFulfilled.get(mapKey).getBaseDomainZoneList().stream()
					.filter(d -> d.getDomainZoneId().equals(validationAnomaly.getDomainZoneId()))
					.count() == 0) {
				validationAnomalyFulfilled.get(mapKey).getBaseDomainZoneList().add(baseDomainZonesMap.get(validationAnomaly.getDomainZoneId()));
			}
		});
	}

	public ValidatorSupport<EditDeclarationResult> buildValidatorSupport(String businessId, Long cropPlanId, AbsoluteDate referenceDt,
			List<ValidatorBoundedDeclaration> bds) {
		return new ValidatorSupport<EditDeclarationResult>() {
			@Override
			public EditDeclarationResult getResult(List<ValidationMessage> msgs, List<String> updatedAnomaliesPlotCodes) {
				if (msgs != null && !msgs.isEmpty())
					return new EditDeclarationResult(msgs);
				else
					return new EditDeclarationResult(); // TODO [improve-reload-all] return updated plots
			}

			@Override
			public ValidatorData getValidatorData() {
				var data = new ValidatorData();
				data.setBusinessId(businessId);
				data.setCropPlanId(cropPlanId);
				data.setReferenceDt(referenceDt.toLocalDate());
				data.setPlots(new ArrayList<>());
				data.setDeclarations(bds);
				return data;
			}
		};
	}
}
