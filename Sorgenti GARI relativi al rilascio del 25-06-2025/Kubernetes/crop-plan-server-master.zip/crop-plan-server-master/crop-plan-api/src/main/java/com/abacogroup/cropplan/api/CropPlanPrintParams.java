package com.abacogroup.cropplan.api;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Crop plan prints params")
public class CropPlanPrintParams {
    private List<CropPlanPrintParam> printParams;
}

