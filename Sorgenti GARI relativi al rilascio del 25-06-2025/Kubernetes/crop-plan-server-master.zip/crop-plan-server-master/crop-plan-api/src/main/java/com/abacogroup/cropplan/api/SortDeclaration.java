package com.abacogroup.cropplan.api;

public enum SortDeclaration 
{
	LAND_USE,
	PARCEL
}
