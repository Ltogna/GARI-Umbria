package com.abacogroup.cropplan.services;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;

import com.abacogroup.cropplan.CropPlanConfiguration;
import com.abacogroup.cropplan.api.CompleteWithTareDates;
import com.abacogroup.cropplan.api.CropPlan;
import com.abacogroup.cropplan.api.CropPlanDates;
import com.abacogroup.cropplan.api.CropPlanType;
import com.abacogroup.cropplan.api.CuaaAreasAndAnomalies;
import com.abacogroup.cropplan.api.DisabledFunctionCode;
import com.abacogroup.cropplan.api.EditDeclarationResult;
import com.abacogroup.cropplan.api.ExtCodeWithArea;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.PlotDataToInclude;
import com.abacogroup.cropplan.api.PlotDeclaredAreas;
import com.abacogroup.cropplan.api.PlotDeclaredAreas.PlotDeclaredArea;
import com.abacogroup.cropplan.api.PlotDomain;
import com.abacogroup.cropplan.api.SubdomainZoneResponse;
import com.abacogroup.cropplan.api.ValidationAnomalies;
import com.abacogroup.cropplan.api.ValidationAnomalies.ValidationAnomalyByType;
import com.abacogroup.cropplan.api.payload.CopyDeclarationsFromSourceYearPayload;
import com.abacogroup.cropplan.api.payload.CreateVersionPayload;
import com.abacogroup.cropplan.api.payload.InsertPermanentCropForm;
import com.abacogroup.cropplan.api.payload.SubdomainZoneRequest;
import com.abacogroup.cropplan.api.payload.SwapLandUsesPayload;
import com.abacogroup.cropplan.bundle.model.AnomScenarioDisableFuncConfigDefinition;
import com.abacogroup.cropplan.bundle.model.FunctionsDisabledConfig;
import com.abacogroup.cropplan.bundle.model.ScenarioAnomaliesConfig;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.db.dao.SubdomainZoneDAO;
import com.abacogroup.cropplan.db.dao.SyncDAO;
import com.abacogroup.cropplan.db.dao.ValidatorDAO;
import com.abacogroup.cropplan.db.dao.ntt.DeclarationWithPlotCode;
import com.abacogroup.cropplan.db.dao.ntt.FunctionDisableConfig;
import com.abacogroup.cropplan.db.dao.ntt.ScenarioAnomaliesDisableFunctionsConfigurations;
import com.abacogroup.cropplan.dispatch.CropPlanCommitJob;
import com.abacogroup.cropplan.dispatch.CropPlanCommitJob.CommiType;
import com.abacogroup.cropplan.exceptions.BlockingAnomaliesException;
import com.abacogroup.cropplan.exceptions.CreateVersionException;
import com.abacogroup.cropplan.exceptions.DisableFunctionException;
import com.abacogroup.cropplan.exceptions.IncompatibleLandUseException;
import com.abacogroup.cropplan.exceptions.InvalidDeclDatesException;
import com.abacogroup.cropplan.exceptions.PlotDeclarationsNotEditableException;
import com.abacogroup.cropplan.exceptions.PlotNotEmptyAtNewDeclDatesException;
import com.abacogroup.cropplan.exceptions.SubdomainZoneException;
import com.abacogroup.cropplan.exceptions.SubdomainZoneException.ErrEnum;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.sdk.model.BaseDeclaration;
import com.abacogroup.cropplan.sdk.model.CropPlanVersion;
import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.PlotTimeline.PlotArea;
import com.abacogroup.cropplan.sdk.model.PublishVersionResult;
import com.abacogroup.cropplan.sdk.model.Version;
import com.abacogroup.cropplan.sdk.model.config.CropPlanConfigParam;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseClass;
import com.abacogroup.cropplan.sdk.model.domain.DomainZoneGeometry;
import com.abacogroup.cropplan.sdk.model.sync.LatestSync;
import com.abacogroup.cropplan.sdk.model.sync.WizardDeclarations;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomaly;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedDeclaration;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorOperation;
import com.abacogroup.cropplan.sdk.spi.CropCodesPlugin;
import com.abacogroup.cropplan.sdk.spi.DomainPlugin;
import com.abacogroup.cropplan.sdk.spi.ProjectionTransformerPlugin;
import com.abacogroup.cropplan.sdk.support.InfiniteListResultsSupport;
import com.abacogroup.cropplan.services.support.PlotTimeWindowParams;
import com.abacogroup.cropplan.services.support.ReproportionDeclsSupportParams;
import com.abacogroup.cropplan.services.support.ValidatorSupport;
import com.abacogroup.cropplan.services.utils.CopyDeclarationsFromPreviousYearUtils;
import com.abacogroup.cropplan.services.utils.CropPlanServiceUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.embeddedqueue.AbstractWorkQueue;
import com.abacogroup.embeddedqueue.QueueErrorListener.ErrorAction;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.geometryeditor.GeometryTransform;
import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.codahale.metrics.MetricRegistry;
import io.dropwizard.auth.AuthenticationException;
import jakarta.ws.rs.BadRequestException;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutionException;
import java.util.stream.Stream;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.jdbi.v3.core.Jdbi;
import org.locationtech.jts.geom.Geometry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CropPlanService extends BaseCropPlanService {
	private static final Logger log = LoggerFactory.getLogger(CropPlanService.class);
	private static final String PUBLISH_QUEUE_ID = "crpl-publish-queue";
	private static final int PUBLISH_QUEUE_THREAD = 20;
	private static final long PUBLISH_QUEUE_TIMEOUT = Duration.ofHours(12).toMillis();

	private static final AbsoluteDate DEFAULT_END_DATE = AbsoluteDate.of("99991231");

	private final Sso2Client sso2Client;
	private final BaseService baseService;
	private final CropPlanDeclarationsService cropPlanDeclarationService;
	private final CropPlanConfigService cropPlanConfigService;
	private final ValidatorService validatorService;
	private final CropCodeService cropCodeService;

	private final CropPlansDAO cropPlansDAO;
	private final CropPlanConfigDAO cropPlanConfigDAO;
	private final ValidatorDAO validatorDAO;
	private final SyncDAO syncDAO;
	private final DeclarationsDAO declarationsDAO;
	private final SubdomainZoneDAO subdomainZoneDAO;

	private final PluginManager pluginManager;
	private final AbstractWorkQueue<CropPlanCommitJob, ?> msgQueue;
	private final WorkQueue<PublishQueuePayload> publishQueue;

	@Getter
	private final CropPlanServiceUtils cropPlanServiceUtils;
	private final CopyDeclarationsFromPreviousYearUtils copyDeclarationsFromPreviousYearUtils;

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	private static class PublishQueuePayload {
		private String username;
		private String tenant;
		private String language;
		private String businessId;
		private Long cropPlanId;
		private String cropPlanTypeCode;
		private LocalDate versionReferenceDate;
		private LocalDateTime versionDate;
		private String version;
	}

	public CropPlanService(Sso2Client sso2Client, MetricRegistry metricRegistry, Jdbi jdbi,
			BaseService baseService,
			CropPlanDeclarationsService cropPlanDeclarationService,
			CropPlanConfigService cropPlanConfigService,
			ValidatorService validatorService,
			CropCodeService cropCodeService,
			DAOContainer daocontainer,
			PluginManager pluginManager,
			AbstractWorkQueue<CropPlanCommitJob, ?> msgQueue,
			CropPlanConfiguration configuration) throws IOException {
		super(pluginManager, daocontainer.getCropPlansDAO(), daocontainer.getCropPlanConfigDAO(), daocontainer.getCropPlansDeleteAndRestoreOperationsDAO());

		this.sso2Client = sso2Client;
		this.baseService = baseService;

		this.cropPlanDeclarationService = cropPlanDeclarationService;
		this.cropPlanConfigService = cropPlanConfigService;
		this.validatorService = validatorService;
		this.cropCodeService = cropCodeService;

		this.cropPlansDAO = daocontainer.getCropPlansDAO();
		this.cropPlanConfigDAO = daocontainer.getCropPlanConfigDAO();
		this.validatorDAO = daocontainer.getValidatorDAO();
		this.syncDAO = daocontainer.getSyncDAO();
		this.declarationsDAO = daocontainer.getDeclarationsDAO();
		this.subdomainZoneDAO = daocontainer.getSubdomainZoneDAO();

		this.pluginManager = pluginManager;
		this.msgQueue = msgQueue;

		publishQueue = new WorkQueue<>(PUBLISH_QUEUE_ID, new JdbiRepository(jdbi), PUBLISH_QUEUE_THREAD, PUBLISH_QUEUE_TIMEOUT) {
			@Override
			protected Class<PublishQueuePayload> getJobClass() {
				return PublishQueuePayload.class;
			}
		};
		publishQueue.setMetricRegistry(metricRegistry);
		publishQueue.setConsumer(this::doPublish);
		publishQueue.setErrorListener((payload, t) -> {
			log.error("Error during crop plan creation " + payload.getCropPlanId(), t);
			cropPlansDAO.deleteVersion(payload.getCropPlanId(), payload.getVersionDate());
			return ErrorAction.DELETE_FROM_QUEUE;
		});
		if (!configuration.isDevMode())
			publishQueue.start();

		this.cropPlanServiceUtils = new CropPlanServiceUtils(cropPlanConfigService, cropPlanDeclarationService, daocontainer, pluginManager);
		this.copyDeclarationsFromPreviousYearUtils = new CopyDeclarationsFromPreviousYearUtils(cropCodeService, cropPlansDAO, declarationsDAO);
	}

	public InfiniteListResults<CropPlan> getCropPlans(RuntimeEnvironment env, String businessId, String cropPlanTypeCode, String search,
			String nextKey, int pageSize) {
		var cropPlans = cropPlansDAO.infinite(() -> cropPlansDAO.getCropPlansInternal(businessId, cropPlanTypeCode, search,
				env.getTenantId(), env.getLocale().getLanguage()),
				nextKey,
				pageSize);

		cropPlanServiceUtils.populateCropPlansData(cropPlans.getRecords(), businessId, env);

		return cropPlans;
	}

	public CropPlan getCropPlan(RuntimeEnvironment env, String businessId, Long cropPlanId) {
		var cropPlan = cropPlansDAO.getCropPlanInternal(businessId, cropPlanId, env.getTenantId());
		if (cropPlan == null)
			return null;

		cropPlanServiceUtils.populateCropPlansData(List.of(cropPlan), businessId, env);

		return cropPlan;
	}

	public InfiniteListResults<Plot> getPlots(RuntimeEnvironment env, String businessId, Long cropPlanId,
			String domainZoneId, LocalDateTime versionDt, AbsoluteDate pointInTime, String parcelCodeStartsWith,
			Long subdomainZoneId, String nextKey, int pageSize, PlotDataToInclude plotDataToInclude) {
		return cropPlanServiceUtils.getPlotsInternal(env, businessId, cropPlanId, domainZoneId, versionDt, pointInTime, pointInTime,
				null, parcelCodeStartsWith, subdomainZoneId, nextKey, pageSize, plotDataToInclude);
	}

	public InfiniteListResults<Plot> getPlotsBetweenDates(RuntimeEnvironment env, String businessId, Long cropPlanId,
			String domainZoneId, LocalDateTime versionDt, AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo, String parcelCodeStartsWith, String nextKey,
			int pageSize, PlotDataToInclude plotDataToInclude, boolean doNotAdjustDeclDates) {
		InfiniteListResults<Plot> plots = cropPlanServiceUtils.getPlotsInternal(env, businessId, cropPlanId, domainZoneId, versionDt, pointInTimeFrom,
				pointInTimeTo,
				null, parcelCodeStartsWith, null, nextKey, pageSize, plotDataToInclude);

		if (!doNotAdjustDeclDates && plotDataToInclude.getDecls()) {
			plots.getRecords().forEach(p -> {
				List<Declaration> decls = new ArrayList<>(p.getDecls());
				decls.forEach(d -> adjustDeclDatesForPlotsBetweenDates(p, d));
			});
		}
		return plots;
	}

	public InfiniteListResults<Plot> getPlotsByIntersectionWithDeclarationsBetweenDates(RuntimeEnvironment env,
			String businessId, Long cropPlanId, String domainZoneId, Geometry geom,
			LocalDateTime versionDt, AbsoluteDate plotPointInTime, AbsoluteDate declPointInTimeFrom, AbsoluteDate declPointInTimeTo,
			String nextKey, int pageSize, PlotDataToInclude plotDataToInclude) {

		InfiniteListResults<Plot> plots = cropPlanServiceUtils.getPlotsByIntersection(env, businessId, cropPlanId,
				domainZoneId, geom, versionDt, plotPointInTime, plotPointInTime,
				nextKey, pageSize, plotDataToInclude, true);

		return cropPlanServiceUtils.fillPlots(env, businessId, cropPlanId,
				versionDt, declPointInTimeFrom, declPointInTimeTo,
				plotDataToInclude, plots);
	}

	/**
	 * If pointInTimeTo is null then plot is loaded at pointInTimeFrom specified, otherwise, if an interval is specified then the plot is loaded at its from
	 * date
	 */
	public List<PlotDomain> getPlotsByLandCoverCode(RuntimeEnvironment env, String businessId, Long cropPlanId,
			LocalDateTime versionDt, AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo,
			String landCoverCode, String srs, PlotDataToInclude plotDataToInclude) {
		CropCodesPlugin cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId());
		DomainPlugin domainPlugin = pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId());
		ProjectionTransformerPlugin projTransformerPlugin = pluginManager.getProjectionTransformerPlugin(businessId, cropPlanId, env.getTenantId());

		List<String> landCoverCodes = cropCodesPlugin.getLandCoversOnWhichTheLandCoverIsCompatible(env, landCoverCode);
		landCoverCodes.add(landCoverCode);

		List<Plot> plotsInfo = cropPlansDAO.getPlotsInfoByLandCoverCode(cropPlanId, versionDt, pointInTimeFrom,
				pointInTimeTo != null ? pointInTimeTo : pointInTimeFrom, landCoverCodes);

		List<PlotDomain> plotsDomains = plotsInfo.stream().map(plotInfo -> {
			AbsoluteDate fromDate = (pointInTimeTo == null) ? pointInTimeFrom : plotInfo.getFromDate();
			LocalDate snapFromDate = cropPlanConfigService.getSnapFromDate(cropPlanId, fromDate).toLocalDate();
			String domainZoneId = cropPlansDAO.getDomainZoneIdByPlotCode(cropPlanId, plotInfo.getPlotCode());
			DomainZoneGeometry domainZone = domainPlugin.getDomainZone(env, businessId, snapFromDate, domainZoneId);
			Plot plot = getPlot(env, businessId, cropPlanId, domainZoneId, versionDt, fromDate, fromDate, plotInfo.getPlotCode(), plotDataToInclude);
			return new PlotDomain(plot, domainZone);
		}).collect(toList());

		// convert geometries in the requested srs
		if (srs != null) {
			GeometryTransform gt = new GeometryTransform();
			plotsDomains = assignGeomAndMbrOverviewToPlotDomains(env, projTransformerPlugin, plotsDomains, srs, plotDataToInclude, gt);
		}

		return plotsDomains;
	}

	private List<PlotDomain> assignGeomAndMbrOverviewToPlotDomains(RuntimeEnvironment env, ProjectionTransformerPlugin projTransformerPlugin,
			List<PlotDomain> plotsDomains,
			String srs, PlotDataToInclude plotDataToInclude, GeometryTransform gt) {
		List<PlotDomain> plotDomainsWithGeomAndMbr = new ArrayList<>();

		plotsDomains.forEach(pd -> {
			try {
				Geometry transformedGeom = projTransformerPlugin != null
						? projTransformerPlugin.transform(env, pd.getPlot().getGeom(), pd.getDomainZone().getSrs(), srs)
						: gt.transform(pd.getPlot().getGeom(), pd.getDomainZone().getSrs(), srs);

				pd.getPlot().setGeom(transformedGeom);

				if (plotDataToInclude.getMbrOverview()) {
					Geometry transformedMbr = projTransformerPlugin != null
							? projTransformerPlugin.transform(env, pd.getPlot().getMbrOverview(), pd.getDomainZone().getSrs(), srs).getEnvelope()
							: gt.transform(pd.getPlot().getMbrOverview(), pd.getDomainZone().getSrs(), srs).getEnvelope();

					pd.getPlot().setMbrOverview(transformedMbr);
				}

				pd.getDomainZone().setSrs(srs);

				plotDomainsWithGeomAndMbr.add(pd);
			} catch (Exception e) {
				throw new IllegalStateException("Failed to transform geometry: " + e.getMessage(), e);
			}
		});

		return plotDomainsWithGeomAndMbr;
	}

	public Plot getPlot(RuntimeEnvironment env, String businessId, Long cropPlanId,
			String domainZoneId, LocalDateTime versionDt, AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo, String plotCode) {
		return getPlot(env, businessId, cropPlanId, domainZoneId, versionDt, pointInTimeFrom, pointInTimeTo, plotCode, new PlotDataToInclude());
	}

	public Plot getPlot(RuntimeEnvironment env, String businessId, Long cropPlanId,
			String domainZoneId, LocalDateTime versionDt, AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo, String plotCode,
			PlotDataToInclude plotDataToInclude) {
		var plots = cropPlanServiceUtils.getPlotsInternal(env, businessId, cropPlanId, domainZoneId, versionDt, pointInTimeFrom, pointInTimeTo, plotCode, null, null, null, 1, plotDataToInclude);
		if (plots.getCount() > 0)
			return plots.getRecords().get(0);
		else
			return null;
	}

	public List<ParcelIntersection> getParcelIntersectionsByPlotCode(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime versionDt,
			AbsoluteDate pointInTime, String plotCode) {
		var domainPlugin = pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId());
		var cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId());

		var plotId = cropPlansDAO.infinite(
				() -> cropPlansDAO.getPlotsInternal(cropPlanId, null, versionDt, pointInTime, pointInTime, plotCode, null, null),
				null,
				1).getRecords().get(0).getPlotId();

		var intersections = cropPlanServiceUtils.loadParcelsIntersectionByPlotId(env, cropPlanId, businessId, versionDt, List.of(plotId)).get(plotId);
		for (var intersection : intersections) {
			var parcelDescriptions = domainPlugin.getParcelsDescription(env, businessId, pointInTime.toLocalDate(), List.of(intersection.getCode()));
			intersection.setDescription(parcelDescriptions.get(intersection.getCode()).getDescription());
			intersection.setParcelCode(parcelDescriptions.get(intersection.getCode()).getParcelCode());
			intersection.setHoldingPercentage(parcelDescriptions.get(intersection.getCode()).getHoldingPercentage());

			if (intersection.getLandCoverCode() != null) {
				var landCoverDescriptions = cropCodesPlugin.getLandCoverDescriptions(env, List.of(intersection.getLandCoverCode()));
				intersection.setLandCoverDescription(landCoverDescriptions.get(intersection.getLandCoverCode()));
			}
		}

		return intersections;
	}

	public PlotDeclaredAreas getPlotDeclaredAreas(PlotTimeWindowParams params, boolean withTolerance) {
		var ret = new PlotDeclaredAreas();
		final Double toleranceMultiplier = withTolerance ? cropPlanDeclarationService.calcToleranceMultiplier(params) : 1d;

		var totalAreaPerc = 100 * toleranceMultiplier;

		ret.setPlotCode(params.getPlotCode());
		ret.setTotalDeclarableAreaPerc(totalAreaPerc);
		ret.setMaxDeclarableAreaPerc(totalAreaPerc / toleranceMultiplier);
		ret.setDeclaredAreas(new ArrayList<>());

		List<PlotArea> plotAreas = getPlotAreas(params);
		List<DeclarationWithPlotCode> plotDecls = declarationsDAO.getPlotDeclarations(params.getCropPlanId(), params.getPlotCode(),
				params.getExcludedDeclCode(),
				params.getVersionDt(), params.getPointInTimeFrom(), params.getPointInTimeTo());

		List<AbsoluteDate> allDates = new ArrayList<>();
		allDates.add(params.getPointInTimeFrom());
		// allDates.add(AbsoluteDate.of(params.getPointInTimeTo().get().plusDays(1)));

		plotAreas.stream().forEach(p -> {
			allDates.add(p.getFromDate());
			if (p.getToDate().isBefore(DEFAULT_END_DATE))
				allDates.add(AbsoluteDate.of(p.getToDate().toLocalDate().plusDays(1)));
		});
		plotDecls.stream().forEach(d -> {
			allDates.add(d.getFromDate());
			if (d.getToDate().isBefore(DEFAULT_END_DATE))
				allDates.add(AbsoluteDate.of(d.getToDate().toLocalDate().plusDays(1)));
		});

		// reorder and filter dates
		List<AbsoluteDate> dates = allDates.stream()
				.filter(d ->  d.isAfterOrEqual(params.getPointInTimeFrom()) && d.isBeforeOrEqual(params.getPointInTimeFrom()))
				.sorted()
				.distinct()
				.collect(toList());

		// elaborate intervals for declared and plot areas
		var pdas = new ArrayList<PlotDeclaredArea>();
		dates.forEach(date -> elaborateDateIntervals(ret, toleranceMultiplier, totalAreaPerc, plotAreas, plotDecls, pdas, date));
		return getProcessedPlotDeclaredAreas(pdas, ret);
	}

	private PlotDeclaredAreas getProcessedPlotDeclaredAreas(List<PlotDeclaredArea> pdas, PlotDeclaredAreas ret) {
		if (ret.getMaxDeclarableAreaPerc().compareTo(0d) < 0)
			ret.setMaxDeclarableAreaPerc(0d);

		// compact and return
		pdas.forEach(pda -> {
			if (ret.getDeclaredAreas().isEmpty())
				ret.getDeclaredAreas().add(pda);
			else {
				PlotDeclaredArea lastPda = ret.getDeclaredAreas().get(ret.getDeclaredAreas().size() - 1);
				if (Integer.compare(pda.getAreaSqm(), lastPda.getAreaSqm()) != 0 ||
						Double.compare(pda.getDeclaredAreaPerc(), lastPda.getDeclaredAreaPerc()) != 0) {
					ret.getDeclaredAreas().add(pda);
				}
			}
		});

		return ret;
	}

	private void elaborateDateIntervals(PlotDeclaredAreas ret, final Double toleranceMultiplier, double totalAreaPerc, List<PlotArea> plotAreas,
			List<DeclarationWithPlotCode> plotDecls, ArrayList<PlotDeclaredArea> pdas, AbsoluteDate date) {
		double declaredAreaPerc = plotDecls.stream()
				.filter(plotDecl ->  date.isAfterOrEqual(plotDecl.getFromDate()) && date.isBeforeOrEqual(plotDecl.getToDate()))
				.mapToDouble(Declaration::getAreaPerc)
				.sum();

		var areas = plotAreas.stream()
				.filter(plotArea ->   date.isAfterOrEqual(plotArea.getFromDate()) && date.isBeforeOrEqual(plotArea.getToDate()))
				.map(PlotArea::getAreaSqm)
				.collect(toList());
		if (!areas.isEmpty()) { // it should be one! (or 0 for decl without plot)
			Integer areaSqm = areas.stream().reduce(0, Integer::sum);

			areaSqm = (int) Math.floor(areaSqm * toleranceMultiplier);

			pdas.add(new PlotDeclaredArea(areaSqm, declaredAreaPerc, date));

			/*
			 * if (areaSqm.intValue() == 0) ret.setMaxDeclarableAreaPerc(0d); else
			 */
			if (ret.getMaxDeclarableAreaPerc().compareTo(totalAreaPerc - declaredAreaPerc) > 0) {
				ret.setMaxDeclarableAreaPerc(totalAreaPerc - declaredAreaPerc);
			}
		} else {
			pdas.add(new PlotDeclaredArea(0, declaredAreaPerc, date));
		}
	}

	public CropPlanVersion createVersion(RuntimeEnvironment env, String businessId, Long cropPlanId,
			CreateVersionPayload payload, boolean skipChangesPendingCheck) {
		var lastVersion = cropPlansDAO.getLastVersions(List.of(cropPlanId)).getOrDefault(cropPlanId, LocalDateTime.of(1700, 1, 1, 0, 0, 0));

		this.validateCropPlanEditDates(env, cropPlanId, payload.getPointInTime());
		validateSyncReferenceDate(cropPlanId, payload);

		if (!skipChangesPendingCheck && !cropPlanServiceUtils.isCropPlanChangesPending(env, businessId, cropPlanId, lastVersion)) {
			throw new BadRequestException("No changes pending on the crop plan");
		}

		validateBlockingAnomalies(env, businessId, cropPlanId, cropPlansDAO.getCurrentTimestamp(), payload.getPointInTime());

		cropPlansDAO.createVersion(cropPlanId, payload.getPointInTime(), payload.getMessage(), env.getUserId());

		var cropPlanVersion = cropPlansDAO.infinite(() -> cropPlansDAO.getAllVersions(businessId, cropPlanId, env.getTenantId(), 1, null), null, 1)
				.getRecords().get(0);

		if (payload.isHavingAcknowledgedAnomalies()) {
			cropPlansDAO.saveAnomaliesAcknowledgment(env.getUserId(), cropPlanId, cropPlanVersion.getVersionDate());
		}

		LocalDate versionRefDate = cropPlanVersion.getVersionReferenceDate() != null ? cropPlanVersion.getVersionReferenceDate().toLocalDate() : null;

		addToMessageQueue(env, businessId, cropPlanId, versionRefDate, 
				cropPlanVersion.getCropPlanTypeCode(), cropPlanVersion.getVersion(), cropPlanVersion.getVersionDate(),
				CommiType.IN_PUBLISHING);

		publishQueue.add(new PublishQueuePayload(env.getUser().getName(), env.getTenantId(), env.getLocale().getLanguage(),
				businessId, cropPlanId, cropPlanVersion.getCropPlanTypeCode(), versionRefDate,
				cropPlanVersion.getVersionDate(), cropPlanVersion.getVersion().getRawValue()),
				System.currentTimeMillis());

		return cropPlanVersion;
	}

	public void validateCropPlanEditDates(RuntimeEnvironment env, Long cropPlanId, AbsoluteDate pointInTime) {
		CropPlanType cropPlanType = cropPlansDAO.getCropPlanTypeByCropPlanId(cropPlanId, env.getTenantId(), env.getLocale().getLanguage());

		if (cropPlanType == null) {
			throw new BadRequestException("crop plan type not found");
		}

		if (cropPlanType.getDayFrom() != null) {
			if (pointInTime == null || pointInTime.toLocalDate().isBefore(cropPlanType.getDayFrom().toLocalDate())) {
				throw new BadRequestException(String.format("cannot create version on %s. crop plan type date from: %s", pointInTime, cropPlanType.getDayFrom()));
			}
		}

		if (cropPlanType.getDayTo() != null) {
			if (pointInTime == null || pointInTime.toLocalDate().isAfter(cropPlanType.getDayTo().toLocalDate())) {
				throw new BadRequestException(String.format("cannot create version on %s. crop plan type date to: %s", pointInTime, cropPlanType.getDayTo()));
			}
		}

	}

	private void validateSyncReferenceDate(Long cropPlanId, CreateVersionPayload payload) {
		if (cropPlanConfigService.isConstraintsVersionToSyncRefDate(cropPlanId)) {
			if (payload.getPointInTime() == null) {
				throw new BadRequestException("missing pointInTime in payload");
			}

			LatestSync latestSync = syncDAO.getLatestSync(cropPlanId);
			AbsoluteDate lastSyncReferenceDt = latestSync != null ? latestSync.getReferenceDate() : null;
			if (!payload.getPointInTime().equals(lastSyncReferenceDt)) {
				throw new BadRequestException(String.format("cannot create version on %s. last sync date: %s", payload.getPointInTime(), lastSyncReferenceDt));
			}
		}
	}

	private void validateBlockingAnomalies(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime versionDt, AbsoluteDate pointInTime) {
		var validatorPlugin = pluginManager.getValidatorPlugin(businessId, cropPlanId, env.getTenantId());
		if (validatorPlugin == null || !validatorPlugin.ignoreBlockingAnomalies(env)) {
			for (ValidationAnomalyByType va : validatorDAO.getGroupedCropPlanAnomaliesWithDomainZoneIdGroupDeclAnomaliesOnPlots(
					cropPlanId, versionDt, pointInTime, env.getTenantId(), env.getLocale().getLanguage())) {
				if (va.getBlocking()) {
					throw new BlockingAnomaliesException();
				}
			}
		}
	}

	public void addToMessageQueue(RuntimeEnvironment env, String businessId, Long cropPlanId,
			LocalDate versionReferenceDate, String cropPlanTypeCode, Version version, LocalDateTime versionDate, CommiType commitype) {
		if (msgQueue != null) {
			String referenceDate = versionReferenceDate != null ? AbsoluteDate.of(versionReferenceDate).toString() : null;

			msgQueue.add(new CropPlanCommitJob(
					env.getTenantId(), businessId, cropPlanId, cropPlanTypeCode,
					version, versionDate, referenceDate,
					env.getUserName(), commitype), System.currentTimeMillis());
		}
	}

	private void doPublish(PublishQueuePayload payload) throws InterruptedException, ExecutionException, AuthenticationException {
		User user = (User) sso2Client.createSecurityContextFromUserName(payload.getTenant(), payload.getUsername()).getUserPrincipal();
		RuntimeEnvironment env = baseService.getEnvironmentFactory().create(user, payload.getLanguage());

		CompletionStage<PublishVersionResult> publishVersionResult = pluginManager
				.getCropPlanPlugin(payload.getBusinessId(), payload.getCropPlanId(), env.getTenantId())
				.publishVersion(env, payload.getBusinessId(), payload.getCropPlanId(), payload.getVersion());

		PublishVersionResult res = publishVersionResult.toCompletableFuture().get();
		if (res.getPublished()) {
			cropPlansDAO.updateVersionToPublished(payload.getCropPlanId(), payload.getVersionDate());
			addToMessageQueue(env, payload.getBusinessId(), payload.getCropPlanId(), payload.getVersionReferenceDate(), payload.getCropPlanTypeCode(), 
					new Version(payload.getVersion()), payload.getVersionDate(), CommiType.PUBLISHED);
		} else {
			throw new CreateVersionException();
		}
	}

	public InfiniteListResults<ValidationAnomaly> getCropPlanAnomalies(RuntimeEnvironment env, Long cropPlanId, LocalDateTime versionDt, String nextKey, int pageSize) {
		return validatorDAO.infinite(() -> validatorDAO.getCropPlanAnomalies(cropPlanId, versionDt, env.getTenantId(), env.getLocale().getLanguage()), nextKey, pageSize);
	}

	public ValidationAnomalies getGroupedCropPlanAnomalies(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime versionDt,
			boolean groupDeclAnomaliesOnPlots) {
		ValidationAnomalies anomalies = new ValidationAnomalies();
		anomalies.setNumOfBlockingAnomalies(0);
		anomalies.setNumOfNonBlockingAnomalies(0);

		List<ValidationAnomalyByType> validationAnomalies = cropPlanServiceUtils.getGroupedCropPlanAnomaliesWithDomainZone(env, businessId, cropPlanId, versionDt, groupDeclAnomaliesOnPlots);

		anomalies.setAnomalies(validationAnomalies);

		anomalies.getAnomalies().forEach(a -> {
			if (a.getBlocking()) {
				anomalies.setNumOfBlockingAnomalies(anomalies.getNumOfBlockingAnomalies() + a.getNumOfAnomalies());
			} else {
				anomalies.setNumOfNonBlockingAnomalies(anomalies.getNumOfNonBlockingAnomalies() + a.getNumOfAnomalies());
			}
		});

		return anomalies;
	}

	public EditDeclarationResult copyDeclarationsFromPreviousYear(RuntimeEnvironment env, String businessId, Long cropPlanId,
			boolean ignoreDeclValidationWarnings, AbsoluteDate pointInTime) {
		var cropPlan = cropPlansDAO.getCropPlanInternal(businessId, cropPlanId, env.getTenantId());

		var params = cropPlanConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.COPY_DECLARATIONS_AT_DATE.toString(), null);
		if (params.isEmpty())
			throw new BadRequestException("Parameters COPY_DECLARATIONS_AT_DATE not set");

		var ignoreCropPlanConstraintsDeclsToPlots = !cropPlanConfigDAO
				.getCropPlanConfig(cropPlanId, CropPlanConfigParam.CONSTRAINTS_DECLS_TO_PLOTS.toString(), "FALSE").isEmpty();

		var refDate = params.get(0).getParamValue();
		var currentDate = cropPlansDAO.getCurrentTimestamp();
		var deleteDate = currentDate.minus(Duration.ofMillis(1));
		var cropPlanDates = getCropPlanDates(env, businessId, cropPlanId, pointInTime);

		var campaignStartDate = cropPlanDates.getCampaignStartDate();
		if (campaignStartDate == null)
			throw new BadRequestException("Parameters CAMPAIGN_START_DATE not set");

		var previousCampaignEndDate = AbsoluteDate.of(cropPlanDates.getCampaignStartDate().toLocalDate().minusDays(1));
		var currentYear = cropPlanDates.getReferenceDate().toLocalDate().getYear();
		var currentPointInTime = AbsoluteDate.of(currentYear + refDate);
		var previousYear = currentYear - 1;
		var previousPointInTime = AbsoluteDate.of(previousYear + refDate);

		var bds = new ArrayList<ValidatorBoundedDeclaration>();

		Map<String, LandUseClass> lucMap = new HashMap<>();

		cropPlansDAO.useTransaction(dao -> {
			// load current plots
			String nextKey = null;
			do {
				var result = this.getPlots(env, businessId, cropPlanId, null, currentDate, currentPointInTime, null, null, nextKey, 50,
						new PlotDataToInclude());
				result.getRecords().forEach(currentPlot -> {
					var parcelCodes = currentPlot.getParcelIntersections().stream().map(ParcelIntersection::getCode).collect(toList());
					if (isPlotLandCoverEditable(env, businessId, cropPlanId, currentPlot)) {
						// for each current plot check if plot existed previous year
						var previousPlot = this.getPlot(env, businessId, cropPlanId, null, currentDate, previousPointInTime, previousPointInTime,
								currentPlot.getPlotCode());

						copyDeclarationsFromPreviousYearUtils.copyPlotDeclarationsFromPreviousYear(env, businessId, cropPlanId, cropPlan,
								ignoreCropPlanConstraintsDeclsToPlots, currentDate, deleteDate,
								campaignStartDate, previousCampaignEndDate, previousPointInTime, bds, lucMap, currentPlot, parcelCodes, previousPlot);
					}
				});
				nextKey = result.getNextKey();
			} while (nextKey != null);
		});

		ValidatorSupport<EditDeclarationResult> support = cropPlanServiceUtils.buildValidatorSupport(businessId, cropPlanId, pointInTime, bds);

		return validatorService.validate(env, support, ignoreDeclValidationWarnings, false, businessId, cropPlanId,
				currentDate, currentDate);
	}

	public EditDeclarationResult copyDeclarationsFromVersion(RuntimeEnvironment env, String businessId, Long cropPlanId,
			boolean ignoreDeclValidationWarnings, boolean forceNotCompatibleLandCover,
			AbsoluteDate pointInTime, AbsoluteDate sourcePointInTime, CopyDeclarationsFromSourceYearPayload payload) {

		var ignoreCropPlanConstraintsDeclsToPlots = !cropPlanConfigDAO
				.getCropPlanConfig(cropPlanId, CropPlanConfigParam.CONSTRAINTS_DECLS_TO_PLOTS.toString(), "FALSE").isEmpty();

		var tol = cropPlanConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.COPY_PREVIOUS_YEAR_DECLS_FROM_VERSION_TOLERANCE_PERC.toString(), null);
		double minCoveredPerc = !tol.isEmpty() ? Double.parseDouble(tol.get(0).getParamValue()) / 100 : 0.7;

		LocalDateTime currentDate = cropPlansDAO.getCurrentTimestamp();
		LocalDateTime versionDt = Optional.ofNullable(payload)
				.map(CopyDeclarationsFromSourceYearPayload::getVersion)
				.map(Version::toDateTime)
				.orElse(currentDate);

		var bds = new ArrayList<ValidatorBoundedDeclaration>();

		PlotDataToInclude currentPlotDataToInclude = PlotDataToInclude.builder()
				.anomalies(false)
				.decls(false)
				.declsPesticides(false)
				.declsStyle(false)
				.parcStyle(false)
				.parcIntDesc(false)
				.parcIntLandCoverDesc(false)
				.build();
		PlotDataToInclude previousPlotDataToInclude = PlotDataToInclude.builder()
				.anomalies(false)
				.parcStyle(false)
				.parcIntDesc(false)
				.parcIntLandCoverDesc(false)
				.build();

		cropPlansDAO.useTransaction(dao -> {
			// load current plots
			new InfiniteListResultsSupport<>(nextKey -> cropPlanServiceUtils.getPlotsWithNoDeclsInRange(env, businessId, cropPlanId,
					null, currentDate, pointInTime, pointInTime, nextKey, 50, currentPlotDataToInclude))
							.forEach(currentPlot -> {
								List<String> parcelCodes = currentPlot.getParcelIntersections().stream().map(ParcelIntersection::getCode).collect(toList());

								if (isPlotLandCoverEditable(env, businessId, cropPlanId, currentPlot)) {
									Geometry currentPlotGeom = currentPlot.getGeom();

									// for each current plot check if plot existed previous year
									Plot previousPlot = new InfiniteListResultsSupport<>(
											nextKey -> cropPlanServiceUtils.getPlotsByIntersection(env, businessId, cropPlanId,
													currentPlot.getDomainZoneId(), currentPlotGeom, versionDt, sourcePointInTime, sourcePointInTime,
													nextKey, 50, previousPlotDataToInclude, false))
															.stream()
															.max(Comparator
																	.comparing(pp -> Utils.snappedIntersectionAB(currentPlotGeom, pp.getGeom()).getArea()))
															.filter(pp -> Utils.snappedIntersectionAB(currentPlotGeom, pp.getGeom()).getArea()
																	/ currentPlotGeom.getArea() >= minCoveredPerc)
															.orElse(null);

									copyDeclarationsFromPreviousYearUtils.newCopyPlotDeclarationsFromPreviousYear(env, businessId, cropPlanId,
											ignoreCropPlanConstraintsDeclsToPlots, forceNotCompatibleLandCover, currentDate,
											pointInTime, bds, currentPlot, parcelCodes, previousPlot, !sourcePointInTime.equals(pointInTime));
								}
							});

		});

		ValidatorSupport<EditDeclarationResult> support = cropPlanServiceUtils.buildValidatorSupport(businessId, cropPlanId, pointInTime, bds);

		return validatorService.validate(env, support, ignoreDeclValidationWarnings, false, businessId, cropPlanId,
				currentDate, currentDate);
	}

	public EditDeclarationResult swapLandUses(RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId, LocalDateTime currentDt,
			boolean ignoreDeclValidationWarnings, SwapLandUsesPayload payload) {

		var bds = new ArrayList<ValidatorBoundedDeclaration>();

		cropPlansDAO.useTransaction(dao -> {
			String nextKey = null;
			Map<String, Plot> targetPlots = new HashMap<>();
			swapPlotsLandUses(env, businessId, cropPlanId, domainZoneId, currentDt, payload, bds, dao, nextKey, targetPlots);

			if (payload.getNewFromDate() != null && payload.getNewToDate() != null) {
				var declarations = cropPlanServiceUtils.loadDeclarationsByPlots(cropPlanId, currentDt, payload.getNewFromDate(), payload.getNewToDate(),
						new ArrayList<>(targetPlots.values()));
				for (var key : declarations.keySet()) {
					// Note: loadDeclarationsByPlotCode will return the declarations with pending transaction updates in their updated form, hence "> 1" and not
					// "> 0".
					// There are additional declarations to the modified one in the given date range only if a key contains more than one value.
					if (declarations.get(key).size() > 1) {
						throw new PlotNotEmptyAtNewDeclDatesException(key);
					}
				}
			}
		});

		ValidatorSupport<EditDeclarationResult> support = cropPlanServiceUtils.buildValidatorSupport(businessId, cropPlanId, payload.getPointInTime(), bds);

		return validatorService.validate(env, support, ignoreDeclValidationWarnings, false, businessId, cropPlanId,
				currentDt, currentDt);
	}

	private void swapPlotsLandUses(RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId, LocalDateTime currentDt,
			SwapLandUsesPayload payload, ArrayList<ValidatorBoundedDeclaration> bds, CropPlansDAO dao, String nextKey, Map<String, Plot> targetPlots) {
		InfiniteListResults<Plot> plotResponse;
		do {
			plotResponse = getPlots(env, businessId, cropPlanId, domainZoneId, currentDt, payload.getPointInTime(), null, null, nextKey, 50,
					new PlotDataToInclude());
			for (var plot : plotResponse.getRecords()) {
				swapPlotLandUses(env, cropPlanId, currentDt, payload, bds, dao, targetPlots, plot);
			}
			nextKey = plotResponse.getNextKey();
		} while (nextKey != null);
	}

	private void swapPlotLandUses(RuntimeEnvironment env, Long cropPlanId, LocalDateTime currentDt, SwapLandUsesPayload payload,
			ArrayList<ValidatorBoundedDeclaration> bds, CropPlansDAO dao, Map<String, Plot> targetPlots, Plot plot) {
		if (payload.getNewFromDate() != null && payload.getNewToDate() != null) {
			if (!(!cropPlanConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.CONSTRAINTS_DECLS_TO_PLOTS.toString(), "FALSE").isEmpty())) {
				if (payload.getNewFromDate().isBefore(plot.getFromDate()) || payload.getNewToDate().isAfter(plot.getToDate())) {
					throw new InvalidDeclDatesException();
				}
			}
		}
		for (var declaration : plot.getDecls()) {
			swapPlotLandUse(env, cropPlanId, currentDt, payload, bds, dao, targetPlots, plot, declaration);
		}
	}

	private void swapPlotLandUse(RuntimeEnvironment env, Long cropPlanId, LocalDateTime currentDt, SwapLandUsesPayload payload,
			ArrayList<ValidatorBoundedDeclaration> bds, CropPlansDAO dao, Map<String, Plot> targetPlots, Plot plot, Declaration declaration) {
		if (declaration.getLanduse().getCode().equals(payload.getSourceLandUseCode())) {
			targetPlots.put(plot.getPlotCode(), plot);
			var declId = dao.updateDeclaration(declaration.getDeclCode(), cropPlanId, plot.getPlotCode(),
					payload.getNewFromDate() != null ? payload.getNewFromDate() : declaration.getFromDate(),
					declaration.getFromDatePrecision(),
					payload.getNewToDate() != null ? payload.getNewToDate() : declaration.getToDate(),
					payload.getNewLandUseCode(), declaration.getAreaPerc(),
					null, null, true, env.getUserId(), currentDt, currentDt);
			var parcelCodes = plot.getParcelIntersections().stream().map(ParcelIntersection::getCode).collect(toList());
			bds.add(new ValidatorBoundedDeclaration(plot.getPlotCode(), parcelCodes, declaration.getDeclId(), declaration.getDeclCode(),
					declaration.getLanduse().getCode(),
					declaration.getAreaPerc(), declaration.getFromDate().toLocalDate(), declaration.getToDate().toLocalDate(), declaration.getFromDatePrecision(),
					ValidatorOperation.DELETE));
			bds.add(new ValidatorBoundedDeclaration(plot.getPlotCode(), parcelCodes, declId, String.valueOf(declId),
					payload.getNewLandUseCode(),
					declaration.getAreaPerc(), declaration.getFromDate().toLocalDate(), declaration.getToDate().toLocalDate(), declaration.getFromDatePrecision(),
					ValidatorOperation.INSERT));
		}
	}

	public CropPlanDates getCropPlanDates(RuntimeEnvironment env, String businessId, Long cropPlanId, AbsoluteDate pointInTime) {
		var startDate = cropPlanConfigService.getCampaignStartDate(cropPlanId, pointInTime);
		var refDate = cropPlanConfigService.getSnapFromDate(cropPlanId, pointInTime);
		LatestSync latestSync = syncDAO.getLatestSync(cropPlanId);
		AbsoluteDate lastSyncReferenceDt = latestSync != null ? latestSync.getReferenceDate() : null;
		var fixedOpenDate = getCropPlanDefaultOpenDate(env, businessId, cropPlanId, lastSyncReferenceDt);
		var isForceEditAtFixedDate = cropPlanConfigService.isForceEditAtFixedDate(cropPlanId);
		var fixedEditDate = isForceEditAtFixedDate ? null : cropPlanConfigService.getFixedEditDate(cropPlanId, pointInTime);

		return new CropPlanDates(startDate, refDate, fixedOpenDate, fixedEditDate, lastSyncReferenceDt);
	}

	public AbsoluteDate getCropPlanDefaultOpenDate(RuntimeEnvironment env, String businessId, Long cropPlanId) {
		LatestSync latestSync = syncDAO.getLatestSync(cropPlanId);
		AbsoluteDate lastSyncReferenceDt = latestSync != null ? latestSync.getReferenceDate() : null;
		return getCropPlanDefaultOpenDate(env, businessId, cropPlanId, lastSyncReferenceDt);
	}

	private AbsoluteDate getCropPlanDefaultOpenDate(RuntimeEnvironment env, String businessId, Long cropPlanId, AbsoluteDate lastSyncReferenceDt) {
		AbsoluteDate defaultOpenDate = cropPlanConfigService.getFixedOpenDate(cropPlanId);
		if (cropPlanConfigService.isDisableChangeDateWhenReadOnly(cropPlanId)) {
			CropPlan cropPlan = getCropPlan(env, businessId, cropPlanId);
			if (Boolean.TRUE.equals(cropPlan.getReadOnly()) && lastSyncReferenceDt != null) {
				defaultOpenDate = lastSyncReferenceDt;
			}
		}
		return defaultOpenDate;
	}

	public EditDeclarationResult reproportionDecls(RuntimeEnvironment env, ReproportionDeclsSupportParams params, Plot plot) {

		var bds = new ArrayList<ValidatorBoundedDeclaration>();
		String plotCode = plot.getPlotCode();
		var deleteDate = params.getVersionDt().minus(Duration.ofMillis(1));
		var parcelCodes = plot.getParcelIntersections().stream().map(ParcelIntersection::getCode).collect(toList());

		double totSupPercOnDecl = plot.getDecls().stream().map(BaseDeclaration::getAreaPerc).reduce(0.0, Double::sum);

		List<Declaration> decls = plot.getDecls().stream()
				.sorted(Comparator.comparing(Declaration::getAreaPerc))
				.collect(toList());

		// Se ho decl e la perc tot delle decl non é 100 procedo al Fix delle perc
		boolean proceedWithCAlcFixAreaPercOnDecl = !decls.isEmpty() && totSupPercOnDecl != 100;

		if (proceedWithCAlcFixAreaPercOnDecl) {
			cropPlansDAO.useTransaction(dao -> {
				String declWithMaxArea = decls.get(decls.size() - 1).getDeclCode();
				BigDecimal declarationsAreaPercTotal = new BigDecimal(0).setScale(8, RoundingMode.HALF_UP);

				for (var declaration : decls) {
					double newDeclarationAreaPerc = totSupPercOnDecl != 0 ? ((declaration.getAreaPerc() / totSupPercOnDecl) * 100.0) : (100.0 / decls.size());
					BigDecimal areaPerc = BigDecimal.valueOf(newDeclarationAreaPerc).setScale(8, RoundingMode.HALF_UP);
					newDeclarationAreaPerc = areaPerc.doubleValue();

					if (!declWithMaxArea.equals(declaration.getDeclCode())) {
						declarationsAreaPercTotal = declarationsAreaPercTotal.add(areaPerc);
					} else {
						newDeclarationAreaPerc = new BigDecimal(100).setScale(8, RoundingMode.HALF_UP).subtract(declarationsAreaPercTotal).doubleValue();
					}

					/*
					 * if (declWithMaxArea.equals(declaration.getDeclCode())) { if (declarationsAreaPercTotal < 100.0) { double declAreaPercTotDiff = 100.0 -
					 * declarationsAreaPercTotal; newDeclarationAreaPerc += declAreaPercTotDiff; } else if (declarationsAreaPercTotal > 100.0) { double
					 * declAreaPercTotDiff = declarationsAreaPercTotal - 100.0; newDeclarationAreaPerc -= declAreaPercTotDiff; } }
					 */

					// cancel old declaration and add new declaration with new AreaPerc
					var pcfs = declaration.getPermanentCropForms().stream()
							.map(pcf -> new InsertPermanentCropForm(pcf.getFormType(), pcf.getPermanentCropFormData()))
							.collect(toList());

					dao.deleteDeclaration(declaration.getDeclCode(), params.getCropPlanId(), plotCode, deleteDate, env.getUserId(), params.getVersionDt());

					bds.add(new ValidatorBoundedDeclaration(plotCode, parcelCodes, declaration.getDeclId(), declaration.getDeclCode(),
							declaration.getLanduse().getCode(), declaration.getAreaPerc(),
							declaration.getFromDate().toLocalDate(), declaration.getToDate().toLocalDate(), declaration.getFromDatePrecision(), ValidatorOperation.DELETE));

					Long declId = cropPlansDAO.insertDeclaration(params.getCropPlanId(), plotCode,
							declaration.getFromDate(), declaration.getFromDatePrecision(), declaration.getToDate(),
							declaration.getLanduse().getCode(), newDeclarationAreaPerc, pcfs, declaration.getFieldsCodes(), env.getUserId(),
							params.getVersionDt(), params.getVersionDt());

					bds.add(new ValidatorBoundedDeclaration(plotCode, parcelCodes, declId, String.valueOf(declId),
							declaration.getLanduse().getCode(), newDeclarationAreaPerc,
							declaration.getFromDate().toLocalDate(), declaration.getToDate().toLocalDate(), declaration.getFromDatePrecision(), ValidatorOperation.INSERT));
				}
			});
		}

		ValidatorSupport<EditDeclarationResult> support = cropPlanServiceUtils.buildValidatorSupport(params.getBusinessId(), params.getCropPlanId(),
				params.getPointInTime(), bds);

		return validatorService.validate(env, support, params.isIgnoreDeclValidationWarnings(), false, params.getBusinessId(), params.getCropPlanId(),
				params.getVersionDt(), params.getVersionDt());
	}

	public void checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode disableFunctionCode, RuntimeEnvironment env, String businessId, Long cropPlanId,
			Plot plot) {
		String cropPlanTypeCode = getCropPlanTypeCode(env, businessId, cropPlanId);
		List<ValidationAnomaly> plotAnomalies = plot.getAnomalies() != null ? plot.getAnomalies() : new ArrayList<>();
		List<ValidationAnomaly> declsAnomalies = plot.getDecls()
				.stream()
				.flatMap(decl -> decl.getAnomalies().stream()).filter(Objects::nonNull).distinct()
				.collect(toList());
		List<ValidationAnomaly> parcelsAnomalies = plot.getParcelIntersections()
				.stream()
				.flatMap(parcels -> parcels.getAnomalies().stream()).filter(Objects::nonNull).distinct()
				.collect(toList());
		List<ValidationAnomaly> listAnomalies;
		listAnomalies = Stream.concat(plotAnomalies.stream(), declsAnomalies.stream()).collect(toList());
		listAnomalies = Stream.concat(listAnomalies.stream(), parcelsAnomalies.stream()).collect(toList());
		List<String> anomailesCodesList = listAnomalies.stream().map(ValidationAnomaly::getErrorCode).distinct().collect(toList());
		Long typeId = cropPlanConfigDAO.getCropPlanTypeId(cropPlanTypeCode, env.getTenantId());
		List<FunctionDisableConfig> disableAnomailesCodesList = getScenarioAnomailesDisableFunctionConfig(disableFunctionCode, typeId);
		boolean functionToBlock = cropPlanServiceUtils.isFunctionDisabledByAnomaliesScenarioConfig(disableAnomailesCodesList, anomailesCodesList);

		if (functionToBlock)
			throw new DisableFunctionException(disableFunctionCode, plot.getPlotCode());
	}

	public ScenarioAnomaliesDisableFunctionsConfigurations getPlotDisabledFunctionsConfig(DisabledFunctionCode disableFunctionCode, RuntimeEnvironment env,
			String businessId, Long cropPlanId) {
		String cropPlanTypeCode = getCropPlanTypeCode(env, businessId, cropPlanId);
		Long typeId = cropPlanConfigDAO.getCropPlanTypeId(cropPlanTypeCode, env.getTenantId());

		List<FunctionDisableConfig> disableAnomailesCodesList = getConfigSceneriesDisabledFunc(disableFunctionCode, env, typeId);

		Map<String, List<FunctionDisableConfig>> configGroupByScenario = disableAnomailesCodesList.stream()
				.collect(groupingBy(FunctionDisableConfig::getScenario));

		List<AnomScenarioDisableFuncConfigDefinition> confList = configGroupByScenario.keySet().stream().map(scenarioId -> {
			AnomScenarioDisableFuncConfigDefinition recordConfiguration = new AnomScenarioDisableFuncConfigDefinition();
			List<FunctionDisableConfig> scenarioConf = configGroupByScenario.get(scenarioId);

			Map<String, List<FunctionDisableConfig>> configGroupByFunction = scenarioConf.stream()
					.collect(groupingBy(FunctionDisableConfig::getFunctionCode));

			List<ScenarioAnomaliesConfig> scenarioAnomaliesConfigList = new ArrayList<>();
			List<FunctionsDisabledConfig> functionsDisabledConfigList = new ArrayList<>();
			boolean saveAnomaliesConf = true;
			for (String functionId : configGroupByFunction.keySet()) {
				List<FunctionDisableConfig> configForFunctionList = configGroupByFunction.get(functionId);
				// Configuration Anomalies are the same for each function
				// so we need to save it only for the first function that we extract
				if (saveAnomaliesConf) {
					for (FunctionDisableConfig configForFunction : configForFunctionList) {
						ScenarioAnomaliesConfig scenarioAnomalies = new ScenarioAnomaliesConfig();

						scenarioAnomalies.setAnomaliyCode(configForFunction.getAnomaliyCode());
						scenarioAnomalies.setFl_present(configForFunction.getAnomaliyPresent());
						scenarioAnomaliesConfigList.add(scenarioAnomalies);
					}
					saveAnomaliesConf = false;
				}
				functionsDisabledConfigList.add(new FunctionsDisabledConfig(functionId));
			}

			recordConfiguration.setScenario(scenarioId);
			recordConfiguration.setFunctionsDisabledConfig(functionsDisabledConfigList);
			recordConfiguration.setScenarioAnomaliesConfig(scenarioAnomaliesConfigList);
			return recordConfiguration;
		}).collect(toList());
		return new ScenarioAnomaliesDisableFunctionsConfigurations(confList);
	}

	public List<FunctionDisableConfig> getConfigSceneriesDisabledFunc(DisabledFunctionCode disableFunctionCode, RuntimeEnvironment env, Long cropPlanTypeCode) {
		return getScenarioAnomailesDisableFunctionConfig(disableFunctionCode, cropPlanTypeCode);
	}

	private List<FunctionDisableConfig> getScenarioAnomailesDisableFunctionConfig(DisabledFunctionCode disableFunctionCode, Long typeId) {
		String disableFunctionCodeParam = disableFunctionCode != null ? disableFunctionCode.toString() : null;
		return cropPlanConfigDAO.getScenarioAnomailesDisableFunctionConfig(disableFunctionCodeParam, typeId);
	}

	public CuaaAreasAndAnomalies getCuaaAreasAndAnomalies(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime versionDt,
			AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo, String permanentCropFormType, boolean groupDeclAnomaliesOnPlots) {

		int oldUVTotalAreaSqm;
		int newUVTotalAreaSqm = 0;
		int newGraphicTotalAreaSqm = 0;
		int differenceBetweenNewUVAndGraphicAreaSqm;

		List<Plot> allPlots = getAllPlots(env, businessId, cropPlanId, versionDt, pointInTimeFrom, pointInTimeTo);

		var wizardPlots = pluginManager.getSyncPlugin(businessId, cropPlanId, env.getTenantId())
				.getWizardPlots(env, businessId, cropPlanId, versionDt, true);

		List<WizardDeclarations> decls = wizardPlots.stream()
				.flatMap(wp -> wp.getDecls().stream())
				.collect(toList());

		var extCodesWithAreas = decls.stream()
				.map(d -> new ExtCodeWithArea(
						d.getPcfs().stream()
								.filter(pcf -> permanentCropFormType.equals(pcf.getFormType()))
								.map(pcf -> pcf.getPermanentCropFormData().getExternalCode())
								.findFirst().orElse(null),
						d.getAreaSqm()))
				.collect(toList());

		oldUVTotalAreaSqm = calculateOldUVTotalArea(extCodesWithAreas);

		for (Plot plot : allPlots) {
			newGraphicTotalAreaSqm += plot.getAreaSqm();

			BigDecimal declarationAreaPercTotal = calculatePlotDeclarationsAreaPercTotal(plot, permanentCropFormType);

			newUVTotalAreaSqm += ((Long) Math.round(plot.getAreaSqm() * declarationAreaPercTotal.doubleValue() / 100)).intValue();
		}

		differenceBetweenNewUVAndGraphicAreaSqm = newGraphicTotalAreaSqm - newUVTotalAreaSqm;

		ValidationAnomalies anomalies = getGroupedCropPlanAnomalies(env, businessId, cropPlanId, versionDt, groupDeclAnomaliesOnPlots);

		return CuaaAreasAndAnomalies.builder()
				.differenceBetweenNewUVAndGraphicAreaSqm(differenceBetweenNewUVAndGraphicAreaSqm)
				.newGraphicTotalAreaSqm(newGraphicTotalAreaSqm)
				.newUVTotalAreaSqm(newUVTotalAreaSqm)
				.oldUVTotalAreaSqm(oldUVTotalAreaSqm)
				.anomalies(anomalies)
				.build();
	}

	private List<Plot> getAllPlots(RuntimeEnvironment env, String businessId, Long cropPlanId,
			LocalDateTime versionDt, AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo) {
		List<Plot> allPlots = new ArrayList<>();
		String nextKey = null;

		PlotDataToInclude plotDataToInclude = new PlotDataToInclude();
		plotDataToInclude.setAnomalies(false);
		plotDataToInclude.setDecls(true);
		plotDataToInclude.setDeclsPesticides(false);
		plotDataToInclude.setDeclsStyle(false);
		plotDataToInclude.setMbrOverview(false);
		plotDataToInclude.setParcInt(true);
		plotDataToInclude.setParcIntDesc(false);
		plotDataToInclude.setParcIntLandCoverDesc(false);
		plotDataToInclude.setParcStyle(false);
		plotDataToInclude.setPlotEditability(false);

		do {
			var plots = cropPlanServiceUtils.getPlotsInternal(env, businessId, cropPlanId, null, versionDt,
					pointInTimeFrom, pointInTimeTo, null, null, null, nextKey, 10, plotDataToInclude);
			allPlots.addAll(plots.getRecords());
			nextKey = plots.getNextKey();
		} while (nextKey != null);

		return allPlots;
	}

	private int calculateOldUVTotalArea(List<ExtCodeWithArea> extCodesWithAreas) {
		int totalArea = extCodesWithAreas.stream()
				.filter(ecwa -> ecwa.getExtCode() == null)
				.mapToInt(ExtCodeWithArea::getAreaSqm)
				.sum();

		totalArea += extCodesWithAreas.stream()
				.filter(ecwa -> ecwa.getExtCode() != null)
				.collect(groupingBy(ExtCodeWithArea::getExtCode))
				.values().stream()
				.flatMap(ecwas -> ecwas.stream().limit(1))
				.mapToInt(ExtCodeWithArea::getAreaSqm)
				.sum();

		return totalArea;
	}

	private BigDecimal calculatePlotDeclarationsAreaPercTotal(Plot plot, String permanentCropFormType) {
		BigDecimal declarationAreaPercTotal = new BigDecimal(0);

		for (var declaration : plot.getDecls()) {
			for (var permanentCropForm : declaration.getPermanentCropForms()) {
				if (permanentCropFormType.equals(permanentCropForm.getFormType())) {
					declarationAreaPercTotal = declarationAreaPercTotal.add(BigDecimal.valueOf(declaration.getAreaPerc()));
					break;
				}
			}
		}

		return declarationAreaPercTotal;
	}

	public CompleteWithTareDates getCompleteWithTareDates(RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId,
			String tareLandUseCode, List<String> plotCodes, AbsoluteDate pointInTime) {
		var currentDt = cropPlansDAO.getCurrentTimestamp();
		CropPlanDates dates = getCropPlanDates(env, businessId, cropPlanId, pointInTime);

		AbsoluteDate minFromDate = null;
		AbsoluteDate maxToDate = null;

		PlotDataToInclude pdti = createPlotDataToInclude();

		for (String plotCode : plotCodes) {
			Plot plot = validateAndFetchPlot(env, businessId, cropPlanId, domainZoneId, pointInTime, pdti, plotCode, currentDt);

			String landCoverCode = getMaxParcelLandCoverCode(plot);
			validateLandUseCompatibility(env, businessId, cropPlanId, tareLandUseCode, landCoverCode);

			PlotTimeWindowParams ptwp = createPlotTimeWindowParams(businessId, cropPlanId, domainZoneId, plotCode, currentDt);
			List<PlotArea> areas = getPlotAreas(ptwp);

			minFromDate = calculateMinFromDate(minFromDate, areas, dates);
			maxToDate = calculateMaxToDate(maxToDate, areas);

			List<Declaration> decls = cropPlanDeclarationService.getPlotDeclarations(env, businessId, cropPlanId, plotCode, null, currentDt, minFromDate,
					maxToDate);
			minFromDate = adjustMinFromDate(minFromDate, decls, pointInTime);
			maxToDate = adjustMaxToDate(maxToDate, decls, pointInTime);
		}
		return new CompleteWithTareDates(minFromDate, maxToDate);
	}

	private PlotDataToInclude createPlotDataToInclude() {
		return PlotDataToInclude.builder()
				.anomalies(false)
				.decls(true)
				.declsPesticides(false)
				.declsStyle(false)
				.mbrOverview(false)
				.parcInt(true)
				.parcIntDesc(false)
				.parcIntLandCoverDesc(false)
				.parcStyle(false)
				.plotEditability(false)
				.build();
	}

	private Plot validateAndFetchPlot(RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId,
			AbsoluteDate pointInTime, PlotDataToInclude pdti, String plotCode, LocalDateTime currentDt) {

		Plot plot = getPlot(env, businessId, cropPlanId, domainZoneId, currentDt, pointInTime, pointInTime, plotCode, pdti);

		if (plot == null) {
			throw new BadRequestException("The plot " + plotCode + " was not found");
		}
		if (!plot.getDecls().isEmpty()) {
			throw new PlotNotEmptyAtNewDeclDatesException(plotCode);
		}
		if (!isPlotLandCoverEditable(env, businessId, cropPlanId, plot)) {
			throw new PlotDeclarationsNotEditableException(plot.getPlotCode());
		}

		return plot;
	}

	private String getMaxParcelLandCoverCode(Plot plot) {
		return plot.getParcelIntersections().stream()
				.max(Comparator.comparing(ParcelIntersection::getAreaSqm))
				.map(ParcelIntersection::getLandCoverCode)
				.orElse(null);
	}

	private void validateLandUseCompatibility(RuntimeEnvironment env, String businessId, Long cropPlanId,
			String tareLandUseCode, String landCoverCode) {

		if (!cropCodeService.isLandUseCompatible(env, businessId, cropPlanId, tareLandUseCode, landCoverCode)) {
			throw new IncompatibleLandUseException();
		}
	}

	private PlotTimeWindowParams createPlotTimeWindowParams(String businessId, Long cropPlanId, String domainZoneId,
			String plotCode, LocalDateTime currentDt) {

		return PlotTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.domainZoneId(domainZoneId)
				.plotCode(plotCode)
				.pointInTimeFrom(null)
				.pointInTimeTo(null)
				.versionDt(currentDt)
				.build();
	}

	private AbsoluteDate calculateMinFromDate(AbsoluteDate minFromDate, List<PlotArea> areas, CropPlanDates dates) {
		AbsoluteDate plotMinFromDate = (dates.getCampaignStartDate() != null
				&& dates.getCampaignStartDate().isAfter(areas.get(0).getFromDate()))
						? dates.getCampaignStartDate()
						: areas.get(0).getFromDate();

		return (minFromDate == null || plotMinFromDate.isAfter(minFromDate)) ? plotMinFromDate : minFromDate;
	}

	private AbsoluteDate calculateMaxToDate(AbsoluteDate maxToDate, List<PlotArea> areas) {
		AbsoluteDate plotMaxToDate = areas.get(areas.size() - 1).getToDate();

		return (maxToDate == null || plotMaxToDate.isBefore(maxToDate)) ? plotMaxToDate : maxToDate;
	}

	private AbsoluteDate adjustMinFromDate(AbsoluteDate minFromDate, List<Declaration> decls, AbsoluteDate pointInTime) {
		for (Declaration decl : decls) {
			if (decl.getToDate().isBefore(pointInTime) && decl.getToDate().isAfterOrEqual(minFromDate)) {
				minFromDate = AbsoluteDate.of(decl.getToDate().toLocalDate().plusDays(1));
			}
		}
		return minFromDate;
	}

	private AbsoluteDate adjustMaxToDate(AbsoluteDate maxToDate, List<Declaration> decls, AbsoluteDate pointInTime) {
		for (Declaration decl : decls) {
			if (decl.getFromDate().isAfter(pointInTime) && decl.getFromDate().isBeforeOrEqual(maxToDate)) {
				maxToDate = AbsoluteDate.of(decl.getFromDate().toLocalDate().minusDays(1));
			}
		}
		return maxToDate;
	}

	public SubdomainZoneResponse createSubdomainZone(RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId,
			LocalDateTime versionDt, AbsoluteDate pointInTime, SubdomainZoneRequest req) {

		Integer maxPlotsOnDomainZone = cropPlanConfigService.getMaxPlotsOnDomainZone(cropPlanId)
				.orElseThrow(() -> new SubdomainZoneException(ErrEnum.MAX_PLOTS_ON_DOMAIN_ZONE_NOT_SET, "MAX_PLOTS_ON_DOMAIN_ZONE config not set"));

		Integer numPlots = cropPlansDAO.countPlotsByGeomIntersects(cropPlanId, domainZoneId, req.getGeom(), versionDt, pointInTime, pointInTime);

		if (numPlots > maxPlotsOnDomainZone) {
			throw new SubdomainZoneException(ErrEnum.TOO_MANY_PLOTS_IN_SUBDOMAIN_ZONE,
					String.format("too many plots in subdomain zone. found %s, max %s", numPlots, maxPlotsOnDomainZone));

		} else if (numPlots == 0) {
			return new SubdomainZoneResponse(-1L, req.getGeom());

		} else {
			Long id = subdomainZoneDAO.insertSubdomainZone(req.getGeom());
			return new SubdomainZoneResponse(id, req.getGeom());
		}
	}
}
