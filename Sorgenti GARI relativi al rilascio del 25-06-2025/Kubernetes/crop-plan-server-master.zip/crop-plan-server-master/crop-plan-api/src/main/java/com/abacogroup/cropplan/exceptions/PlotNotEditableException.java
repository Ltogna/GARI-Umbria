package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class PlotNotEditableException extends WebApplicationException
{
	private static final long serialVersionUID = -1179479414258913159L;

	public static  class PlotNotEditableExceptionErrorBody
	{
		@Schema(allowableValues = "PLOT_NOT_EDITABLE_EXCEPTION")
		public String getErrorCode()
		{
			return "PLOT_NOT_EDITABLE_EXCEPTION";
		}
	}
	
	private static final PlotNotEditableExceptionErrorBody BODY = new PlotNotEditableExceptionErrorBody();

	public PlotNotEditableException(String plotCode)
	{
		super("The plot " + plotCode + " is not editable",
			Response.status(Status.BAD_REQUEST).entity(BODY).build());
	}
}
