package com.abacogroup.cropplan.bundle;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.cropplan.bundle.model.AdditDeclFieldAallowedValueMessage;
import com.abacogroup.cropplan.bundle.model.AdditDeclFieldAllowedConfMessage;
import com.abacogroup.cropplan.bundle.model.AdditDeclFieldConfMessage;
import com.abacogroup.cropplan.bundle.model.AdditDeclFieldLucConfMessage;
import com.abacogroup.cropplan.bundle.model.I18nValueDefinition;
import com.abacogroup.cropplan.bundle.model.ValidationGroups;
import com.abacogroup.cropplan.bundle.model.ValidationGroups.Delete;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.ntt.LandUseAdditionalDataConfNTT;
import com.abacogroup.cropplan.db.ntt.LandUseAdditionalDataFieldNTT;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AdditionalDeclarationFieldsConfigProcessor implements ConfigMessageProcessor {
	
	private static final String USER = "importDataBundle";
	private Map<String, List<I18nValueDefinition>> confDescription = new HashMap<>();
	private Map<String, List<I18nValueDefinition>> valDescription = new HashMap<>();
	private Map<String, List<I18nValueDefinition>> headerTitleCodeDescription = new HashMap<>();
	
	private static final Logger log = LoggerFactory.getLogger(AdditionalDeclarationFieldsConfigProcessor.class);
	
	private static final String I18N_TABLE_NAME = "CRPL_LANDUSE_ADDIT_FIELDS";
	private static final String I18N_FIELD_CODE_NAME = "FIELD_CODE";
	private static final String I18N_FIELD_VALUE_NAME = "FIELD_VALUE";
	private static final String I18N_HEADER_TITLE_CODE_NAME = "HEADER_TITLE_CODE";
	
	private final CropPlanConfigDAO configDAO;
	
	private final ObjectMapper objectMapper;
	
	public AdditionalDeclarationFieldsConfigProcessor(CropPlanConfigDAO configDAO) {
		this.configDAO = configDAO;
		
		objectMapper = new ObjectMapper();
		SimpleModule module = new SimpleModule("custom-deserializers", Version.unknownVersion());
		objectMapper.registerModule(module);
	}
	
	
	@Override
	public String getDomainName() {
		return "additionalDeclarationFieldsCodes";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {

		confDescription.clear();
		valDescription.clear();
		headerTitleCodeDescription.clear();

		// delete
		message.getConfigFiles().stream()
				.filter(path -> StringUtils.equalsIgnoreCase(path.getFileName().toString(), "fieldsAllowedValues.delete.jsonl"))
				.forEach(path -> this.deleteAllowedValues(message.getTenantId(), path));
		message.getConfigFiles().stream()
				.filter(path -> StringUtils.equalsIgnoreCase(path.getFileName().toString(), "fieldsLandUseConf.delete.jsonl"))
				.forEach(path -> this.deleteFieldsLandUseConf(message.getTenantId(), path));
		message.getConfigFiles().stream()
				.filter(path -> StringUtils.equalsIgnoreCase(path.getFileName().toString(), "fieldsConf.delete.jsonl"))
				.forEach(path -> this.deleteFieldsConf(message.getTenantId(), path));

		// upsert
		message.getConfigFiles().stream()
				.filter(path -> StringUtils.equalsIgnoreCase(path.getFileName().toString(), "fieldsConf.jsonl"))
				.forEach(path -> this.upsertFieldsConf(message.getTenantId(), path));
		message.getConfigFiles().stream()
				.filter(path -> StringUtils.equalsIgnoreCase(path.getFileName().toString(), "fieldsLandUseConf.jsonl"))
				.forEach(path -> this.upsertFieldsLandUseConf(message.getTenantId(), path));
		message.getConfigFiles().stream()
				.filter(path -> StringUtils.equalsIgnoreCase(path.getFileName().toString(), "fieldsAllowedValues.jsonl"))
				.forEach(path -> this.upsertAllowedValues(message.getTenantId(), path));

	}


	private void deleteAllowedValues(String tenantId, Path path) {
		log.debug("Starting additional declarations fields allowed values bundle deletes for tenant '{}'...", tenantId);

		int lineCount = 1;
		try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
				Stream<String> sf = Files.lines(path)) {
			Validator validator = validatorFactory.getValidator();

			for (Iterator<String> it = sf.filter(StringUtils::isNotBlank).iterator(); it.hasNext(); ) {
				AdditDeclFieldAllowedConfMessage additDeclAllowedValues = objectMapper.readValue(it.next(), new TypeReference<>() {});

				this.validateAdditDeclFieldAllowedConfOnDelete(validator, additDeclAllowedValues, lineCount);

				this.doDeleteAdditDeclFieldAllowedConf(tenantId, additDeclAllowedValues, lineCount);

				Optional.of(additDeclAllowedValues)
						.map(AdditDeclFieldAllowedConfMessage::getAllowedValues)
						.stream().flatMap(Collection::stream)
						.filter(av -> av.getDescription() != null)
						.forEach(av -> valDescription.put(av.getValue(), av.getDescription()));

				if(lineCount%1000 == 0) {
					log.debug("{} codes deleted for additional declaration fields allowed value for tenant '{}'...", lineCount, tenantId);
				}
				lineCount++;
			}

			this.doUpsertI18N(valDescription, tenantId, I18N_TABLE_NAME, I18N_FIELD_VALUE_NAME);

		} catch (IOException e) {
			throw new BundleException(String.format("error reading file %s", path), e);
		}

		log.debug("Additional declarations fields allowed values bundle deletes for tenant '{}' completed", tenantId);
	}

	private void validateAdditDeclFieldAllowedConfOnDelete(Validator validator, AdditDeclFieldAllowedConfMessage additDeclAllowedValues, int lineCount) {
		Set<ConstraintViolation<AdditDeclFieldAllowedConfMessage>> constraintViolations = validator.validate(additDeclAllowedValues, Delete.class);
		if (!constraintViolations.isEmpty()) {
			ConstraintViolationException constraintViolationException = new ConstraintViolationException(constraintViolations);
			throw new BundleException(String.format("line (%d) with code '%s/%s' is not valid: %s",
					lineCount, additDeclAllowedValues.getCode(), additDeclAllowedValues.getLandUseCode(), constraintViolationException.getMessage()),
					constraintViolationException);
		}
	}

	private void doDeleteAdditDeclFieldAllowedConf(String tenantId, AdditDeclFieldAllowedConfMessage additDeclAllowedValues, int lineCount) {
		if(additDeclAllowedValues.getDeleteFrom() == null)
			configDAO.outdateDeclAdditFieldsAllowedVal(additDeclAllowedValues.getLandUseCode(), additDeclAllowedValues.getCode(), USER, tenantId);
		else {
			List<LandUseAdditionalDataFieldNTT> filteredListOfRecordToBeReinserted = configDAO.getRecordListToBeReinserted(
					additDeclAllowedValues.getLandUseCode(), additDeclAllowedValues.getCode(), tenantId, additDeclAllowedValues.getDeleteFrom());

			configDAO.outdateDeclAdditFieldsAllowedValForDeleteFrom(additDeclAllowedValues.getLandUseCode(),
					additDeclAllowedValues.getCode(), USER, tenantId, additDeclAllowedValues.getDeleteFrom());

			if(!filteredListOfRecordToBeReinserted.isEmpty()){
				filteredListOfRecordToBeReinserted.forEach(record -> {
					record.setValidTo(AbsoluteDate.of(additDeclAllowedValues.getDeleteFrom().toLocalDate().minusDays(1)));
					if (record.getValidFrom().isBeforeOrEqual(record.getValidTo())) {
						record.setId(configDAO.getLanduseAdtFldsValSeq());
						configDAO.insertDeclAdditFieldAlloewdVal(record, USER, tenantId);
					}
				});
			}
		}
	}


	private void deleteFieldsLandUseConf(String tenantId, Path path) {

		log.debug("Starting additional declarations fields land use configuration bundle deletes for tenant '{}'...", tenantId);

		int lineCount = 1;
		try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
				Stream<String> sf = Files.lines(path)) {
			Validator validator = validatorFactory.getValidator();

			for (Iterator<String> it = sf.filter(StringUtils::isNotBlank).iterator(); it.hasNext(); ) {
				AdditDeclFieldLucConfMessage additDeclFieldLuc = objectMapper.readValue(it.next(), new TypeReference<>() {});

				this.validateAdditDeclFieldLucConfOnDelete(validator, additDeclFieldLuc, lineCount);

				this.doDeleteAdditDeclFieldLucConf(tenantId, additDeclFieldLuc, lineCount);

				if(lineCount%1000 == 0) {
					log.debug("Deleted {} rows of additional declaration fields land use conf for tenant '{}'...", lineCount, tenantId);
				}
				lineCount++;
			}

		} catch (IOException e) {
			throw new BundleException(String.format("error reading file %s", path), e);
		}

		log.debug("Additional declarations fields land use configuration bundle deletes for tenant '{}' completed", tenantId);
	}

	private void validateAdditDeclFieldLucConfOnDelete(Validator validator, AdditDeclFieldLucConfMessage additDeclFieldLuc, int lineCount) {
		Set<ConstraintViolation<AdditDeclFieldLucConfMessage>> constraintViolations = validator.validate(additDeclFieldLuc, Delete.class);
		if (!constraintViolations.isEmpty()) {
			ConstraintViolationException constraintViolationException = new ConstraintViolationException(constraintViolations);
			throw new BundleException(String.format("line (%d) with code '%s/%s' is not valid: %s",
					lineCount, additDeclFieldLuc.getCode(), additDeclFieldLuc.getLandUseCode(), constraintViolationException.getMessage()),
					constraintViolationException);
		}
	}

	private void doDeleteAdditDeclFieldLucConf(String tenantId, AdditDeclFieldLucConfMessage additDeclFieldLuc, int lineCount) {
		LandUseAdditionalDataConfNTT declAdditFieldsConf = configDAO.getDeclAdditFieldsConf(additDeclFieldLuc.getCode(), tenantId,
				additDeclFieldLuc.getValidDateFilter());

		if (declAdditFieldsConf != null) {
			configDAO.expireDeclAdditFieldLucConf(declAdditFieldsConf.getId(), additDeclFieldLuc.getLandUseCode(), USER);
		}
	}


	private void deleteFieldsConf(String tenantId, Path path) {

		log.debug("Starting additional declarations fields configuration bundle deletes for tenant '{}'...", tenantId);

		int lineCount = 1;
		try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
				Stream<String> sf = Files.lines(path)) {
			Validator validator = validatorFactory.getValidator();

			for (Iterator<String> it = sf.filter(StringUtils::isNotBlank).iterator(); it.hasNext(); ) {
				AdditDeclFieldConfMessage additDeclField = objectMapper.readValue(it.next(), new TypeReference<>() {});

				this.validateAdditDeclFieldConfOnDelete(validator, additDeclField, lineCount);

				this.doDeleteAdditDeclFieldConf(tenantId, additDeclField, lineCount);

				if(lineCount%1000 == 0) {
					log.debug("Deleted {} rows of additional declaration fields conf for tenant '{}'...", lineCount, tenantId);
				}
				lineCount++;
			}

		} catch (IOException e) {
			throw new BundleException(String.format("error reading file %s", path), e);
		}

		log.debug("Additional declarations fields configuration bundle deletes for tenant '{}' completed", tenantId);
	}

	private void validateAdditDeclFieldConfOnDelete(Validator validator, AdditDeclFieldConfMessage additDeclField, int lineCount) {
		Set<ConstraintViolation<AdditDeclFieldConfMessage>> constraintViolations = validator.validate(additDeclField, Delete.class);
		if (!constraintViolations.isEmpty()) {
			ConstraintViolationException constraintViolationException = new ConstraintViolationException(constraintViolations);
			throw new BundleException(String.format("line (%d) with code '%s' is not valid: %s",
					lineCount, additDeclField.getCode(), constraintViolationException.getMessage()),
					constraintViolationException);
		}
	}

	private void doDeleteAdditDeclFieldConf(String tenantId, AdditDeclFieldConfMessage additDeclField, int lineCount) {
		configDAO.outdateDeclAdditFieldsConf(additDeclField.getCode(), USER, tenantId);
		configDAO.outdateDeclAdditFieldsAllowedValForFieldCode(additDeclField.getCode(), USER, tenantId);
	}


	private void upsertAllowedValues(String tenantId, Path path) {
		log.debug("Starting additional declarations fields allowed values bundle import for tenant '{}'...", tenantId);

		int lineCount = 1;
		try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
				Stream<String> sf = Files.lines(path)) {
			Validator validator = validatorFactory.getValidator();

			for (Iterator<String> it = sf.filter(StringUtils::isNotBlank).iterator(); it.hasNext(); ) {
				AdditDeclFieldAllowedConfMessage additDeclAllowedValues = objectMapper.readValue(it.next(), new TypeReference<>() {});

				this.validateAdditDeclFieldAllowedConfOnUpsert(validator, additDeclAllowedValues, lineCount);

				this.doUpsertAdditDeclFieldAllowedConf(tenantId, additDeclAllowedValues, lineCount);

				Optional.of(additDeclAllowedValues)
						.map(AdditDeclFieldAllowedConfMessage::getAllowedValues)
						.stream().flatMap(Collection::stream)
						.filter(av -> av.getDescription() != null)
						.forEach(av -> valDescription.put(av.getValue(), av.getDescription()));

				if(lineCount%1000 == 0) {
					log.debug("Imported {} rows of additional declaration fields allowed values for tenant '{}'...", lineCount, tenantId);
				}
				lineCount++;
			}

			this.doUpsertI18N(valDescription, tenantId, I18N_TABLE_NAME, I18N_FIELD_VALUE_NAME);

		} catch (IOException e) {
			throw new BundleException(String.format("error reading file %s", path), e);
		}

		log.debug("Additional declarations fields allowed values bundle import for tenant '{}' completed", tenantId);
	}

	private void validateAdditDeclFieldAllowedConfOnUpsert(Validator validator, AdditDeclFieldAllowedConfMessage additDeclAllowedValues, int lineCount) {
		Set<ConstraintViolation<AdditDeclFieldAllowedConfMessage>> constraintViolations = validator.validate(additDeclAllowedValues);
		if (!constraintViolations.isEmpty()) {
			ConstraintViolationException constraintViolationException = new ConstraintViolationException(constraintViolations);
			throw new BundleException(String.format("line (%d) with code '%s/%s' is not valid: %s",
					lineCount, additDeclAllowedValues.getCode(), additDeclAllowedValues.getLandUseCode(), constraintViolationException.getMessage()),
					constraintViolationException);
		}

		if (additDeclAllowedValues.getAllowedValues() != null) {
			for (AdditDeclFieldAallowedValueMessage allowedValue : additDeclAllowedValues.getAllowedValues()) {
				if (allowedValue.getValidTo().toLocalDate().isBefore(allowedValue.getValidFrom().toLocalDate())) {
					throw new BundleException(String.format("line (%d) with code '%s/%s/%s' is not valid: allowedValues.validTo is before allowedValues.validFrom",
							lineCount, additDeclAllowedValues.getCode(), additDeclAllowedValues.getLandUseCode(), allowedValue.getValue()));
				}
			}
		}

		// TODO validate unique values in range ?
	}

	private void doUpsertAdditDeclFieldAllowedConf(String tenantId, AdditDeclFieldAllowedConfMessage additDeclAllowedValues, int lineCount) {
		for (AdditDeclFieldAallowedValueMessage val : additDeclAllowedValues.getAllowedValues()) {
			if(!additDeclAllowedValues.getInsertKeepExisting()) {
				configDAO.outdateDeclAdditFieldsAllowedValInRange(additDeclAllowedValues.getLandUseCode(), additDeclAllowedValues.getCode(),
						val.getValue(), val.getValidFrom(), val.getValidTo(), USER, tenantId);
			}

			configDAO.insertDeclAdditFieldAlloewdVal(
					LandUseAdditionalDataFieldNTT.builder()
							.id(configDAO.getLanduseAdtFldsValSeq())
							.landUseCode(additDeclAllowedValues.getLandUseCode())
							.fieldCode(additDeclAllowedValues.getCode())
							.validFrom(val.getValidFrom())
							.validTo(val.getValidTo())
							.displayOrder(val.getDisplayOrder())
							.allowedValue(val.getValue())
							.flDefault(Boolean.TRUE.equals(val.getIsDefault()) ? 1 : 0)
							.build(),
					USER, tenantId);
		}
	}


	private void upsertFieldsLandUseConf(String tenantId, Path path) {
		log.debug("Starting additional declarations fields land use configuration bundle import for tenant '{}'...", tenantId);

		int lineCount = 1;
		try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
				Stream<String> sf = Files.lines(path)) {
			Validator validator = validatorFactory.getValidator();

			for (Iterator<String> it = sf.filter(StringUtils::isNotBlank).iterator(); it.hasNext(); ) {
				AdditDeclFieldLucConfMessage additDeclFieldLuc = objectMapper.readValue(it.next(), new TypeReference<>() {});

				this.validateAdditDeclFieldLucConfOnUpsert(validator, additDeclFieldLuc, lineCount);

				this.doUpsertAdditDeclFieldLucConf(tenantId, additDeclFieldLuc, lineCount);

				if(lineCount%1000 == 0) {
					log.debug("Imported {} rows of additional declaration fields land use conf for tenant '{}'...", lineCount, tenantId);
				}
				lineCount++;
			}

		} catch (IOException e) {
			throw new BundleException(String.format("error reading file %s", path), e);
		}

		log.debug("Additional declarations fields land use configuration bundle import for tenant '{}' completed", tenantId);
	}

	private void validateAdditDeclFieldLucConfOnUpsert(Validator validator, AdditDeclFieldLucConfMessage additDeclFieldLuc, int lineCount) {
		Set<ConstraintViolation<AdditDeclFieldLucConfMessage>> constraintViolations = validator.validate(additDeclFieldLuc, ValidationGroups.Update.class);
		if (!constraintViolations.isEmpty()) {
			ConstraintViolationException constraintViolationException = new ConstraintViolationException(constraintViolations);
			throw new BundleException(String.format("line (%d) with code '%s/%s' is not valid: %s",
					lineCount, additDeclFieldLuc.getCode(), additDeclFieldLuc.getLandUseCode(), constraintViolationException.getMessage()),
					constraintViolationException);
		}

		// TODO validate unique land use
	}

	private void doUpsertAdditDeclFieldLucConf(String tenantId, AdditDeclFieldLucConfMessage additDeclFieldLuc, int lineCount) {
		LandUseAdditionalDataConfNTT declAdditFieldsConf = configDAO.getDeclAdditFieldsConf(additDeclFieldLuc.getCode(), tenantId,
				additDeclFieldLuc.getValidDateFilter());

		if (declAdditFieldsConf == null) {
			throw new BundleException(String.format("line (%d) with code '%s/%s' is not valid: no configuration found for code %s found on date %s", lineCount,
					additDeclFieldLuc.getCode(), additDeclFieldLuc.getLandUseCode(), additDeclFieldLuc.getCode(), additDeclFieldLuc.getValidDateFilter()));
		}

		configDAO.expireDeclAdditFieldLucConf(declAdditFieldsConf.getId(), additDeclFieldLuc.getLandUseCode(), USER);

		configDAO.insertDeclAdditFieldLucConf(declAdditFieldsConf.getId(), additDeclFieldLuc.getLandUseCode(),
				Boolean.TRUE.equals(additDeclFieldLuc.getNullable()) ? 1 : 0, USER);
	}


	private void upsertFieldsConf(String tenantId, Path path) {
		log.debug("Starting additional declarations fields configuration bundle import for tenant '{}'...", tenantId);

		int lineCount = 1;
		try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
				Stream<String> sf = Files.lines(path)) {
			Validator validator = validatorFactory.getValidator();

			for (Iterator<String> it = sf.filter(StringUtils::isNotBlank).iterator(); it.hasNext(); ) {
				AdditDeclFieldConfMessage additDeclField = objectMapper.readValue(it.next(), new TypeReference<>() {});

				this.validateAdditDeclFieldConfOnUpsert(validator, additDeclField, lineCount);

				this.doUpsertAdditDeclFieldConf(tenantId, additDeclField, lineCount);

				Optional.of(additDeclField)
						.filter(adf -> adf.getDescription() != null)
						.ifPresent(adf -> confDescription.put(adf.getCode(), adf.getDescription()));
				Optional.of(additDeclField)
						.map(AdditDeclFieldConfMessage::getHeaderTitle)
						.filter(ht -> ht.getI18nValues() != null)
						.ifPresent(ht -> headerTitleCodeDescription.put(ht.getHeaderTitleCode(), ht.getI18nValues()));

				if(lineCount%1000 == 0) {
					log.debug("Imported {} rows of additional declaration fields conf for tenant '{}'...", lineCount, tenantId);
				}
				lineCount++;
			}

			this.doUpsertI18N(confDescription, tenantId, I18N_TABLE_NAME, I18N_FIELD_CODE_NAME);
			this.doUpsertI18N(headerTitleCodeDescription, tenantId, I18N_TABLE_NAME, I18N_HEADER_TITLE_CODE_NAME);

		} catch (IOException e) {
			throw new BundleException(String.format("error reading file %s", path), e);
		}

		log.debug("Additional declarations fields configuration bundle import for tenant '{}' completed", tenantId);
	}

	private void validateAdditDeclFieldConfOnUpsert(Validator validator, AdditDeclFieldConfMessage additDeclField, int lineCount) {
		Set<ConstraintViolation<AdditDeclFieldConfMessage>> constraintViolations = validator.validate(additDeclField);
		if (!constraintViolations.isEmpty()) {
			ConstraintViolationException constraintViolationException = new ConstraintViolationException(constraintViolations);
			throw new BundleException(String.format("line (%d) with code '%s' is not valid: %s",
					lineCount, additDeclField.getCode(), constraintViolationException.getMessage()),
					constraintViolationException);
		}

		if (additDeclField.getLandUseConfigurations() != null) {
			Set<String> lucs = additDeclField.getLandUseConfigurations().stream()
					.map(AdditDeclFieldLucConfMessage::getLandUseCode)
					.collect(Collectors.toSet());

			if (additDeclField.getLandUseConfigurations().size() > lucs.size()) {
				throw new BundleException(
						String.format("line (%d) with code '%s' is not valid: duplicate landUseCode in landUseConfigurations", lineCount, additDeclField.getCode()));
			}
		}

		if (additDeclField.getValidTo().toLocalDate().isBefore(additDeclField.getValidFrom().toLocalDate())) {
			throw new BundleException(String.format("line (%d) with code '%s' is not valid: validTo is before validFrom", lineCount, additDeclField.getCode()));
		}
	}

	private void doUpsertAdditDeclFieldConf(String tenantId, AdditDeclFieldConfMessage additDeclField, int lineCount) {
		configDAO.outdateDeclAdditFieldsConf(additDeclField.getCode(), USER, tenantId);

		Long id = configDAO.getLanduseAdditFieldsSeq();
		configDAO.insertDeclAdditFieldConf(
				LandUseAdditionalDataConfNTT.builder()
						.id(id)
						.fieldCode(additDeclField.getCode())
						.fieldType(additDeclField.getType())
						.validFrom(additDeclField.getValidFrom())
						.validTo(additDeclField.getValidTo())
						.displayOrder(additDeclField.getDisplayOrder())
						.nullable(Boolean.TRUE.equals(additDeclField.getNullable()) ? 1 : 0)
						.flShowInTooltip(Boolean.TRUE.equals(additDeclField.getFlShowInTooltip()) ? 1 : 0)
						.groupCode(additDeclField.getGroup())
						.headerTitleCode(additDeclField.getHeaderTitle() != null ? additDeclField.getHeaderTitle().getHeaderTitleCode() : null)
						.flEditable(Boolean.FALSE.equals(additDeclField.getFlEditable()) ? 0 : 1)
						.formula(additDeclField.getFormula())
						.build(),
				USER, tenantId);

		Optional.of(additDeclField).map(AdditDeclFieldConfMessage::getLandUseConfigurations)
				.stream().flatMap(Collection::stream)
				.forEach(additDeclFieldLucConfMessage -> {
					configDAO.insertDeclAdditFieldLucConf(id,
							additDeclFieldLucConfMessage.getLandUseCode(),
							Boolean.TRUE.equals(additDeclFieldLucConfMessage.getNullable()) ? 1 : 0,
							USER);
				});

		// TODO check if valid dates overlaps!!!!
	}


	private void doUpsertI18N(Map<String, List<I18nValueDefinition>> i18n, String tenantId, String i18nTableName, String i18nCodeName) {
		if(!i18n.isEmpty()) {

			i18n.forEach((fc, descs) -> descs.forEach(d -> {
				configDAO.deleteI18nValue(i18nTableName, i18nCodeName, fc,
						d.getLanguage(), tenantId);

				configDAO.insertI18nValue(i18nTableName, i18nCodeName, fc,
						d.getLanguage(), d.getText(), tenantId);
			}));
		}

		i18n.clear();
	}

}
