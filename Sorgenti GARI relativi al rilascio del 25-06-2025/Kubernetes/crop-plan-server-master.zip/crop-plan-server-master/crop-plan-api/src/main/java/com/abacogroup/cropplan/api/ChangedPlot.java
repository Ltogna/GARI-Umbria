package com.abacogroup.cropplan.api;

import org.locationtech.jts.geom.Geometry;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChangedPlot {
	@Schema(description = "The plot 'stable' code, this does not change in history")
	private String plotCode;

	@Schema(description = "The geometry", type = "string", format = "WKT geometry")
	private Geometry geom;

	@Schema(description = "The spatial reference system", format = "AUTHORITY:ID", example = "EPSG:3857")
	private String srs;

	@Schema(description = "The domain zone id")
	private String domainZoneId;

	@Schema(description = "The domain zone code")
	private String domainZoneCode;

	@Schema(description = "Flag to understand if area has changed over defined tolerance")
	private boolean geomChanged = true;

	@Schema(description = "The plot description")
	private String plotDescription;
}
