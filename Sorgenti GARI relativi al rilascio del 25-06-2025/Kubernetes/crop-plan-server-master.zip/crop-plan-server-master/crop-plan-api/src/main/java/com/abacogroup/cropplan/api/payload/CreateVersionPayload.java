package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateVersionPayload
{
	@Schema(description = "The 'commit' message")
	@NotEmpty
	private String message;
	
	@Schema(description = "If it is set to true then user acknowledgment of anomalies is saved; default false")
	@NotNull
	private boolean havingAcknowledgedAnomalies = false;
	
	@Schema(description = "Version reference date")
	private AbsoluteDate pointInTime;
}
