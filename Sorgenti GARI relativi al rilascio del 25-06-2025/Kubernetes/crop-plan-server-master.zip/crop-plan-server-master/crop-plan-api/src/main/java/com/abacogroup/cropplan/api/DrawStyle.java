package com.abacogroup.cropplan.api;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DrawStyle {

    @Schema(description = "an optional reference for the style property", type = "string")
    String referenceName;

    @Schema(description = "fill rgba color for layer", type = "string")
    String fillRgba;

    @Schema(description = "line rgba color for layer", type = "string")
    String lineRgba;

    @Schema(description = "line thick for layers", type = "string")
    Integer lineThick;

    @Schema(description = "label color", type = "string")
    String textColor;

    @Schema(description = "label size", type = "string")
    Integer textSize;

    @Schema(description = "minimum zoom to view", type = "Double")
    Double fromMetersForPixel;

    @Schema(description = "maximum zoom to view", type = "Double")
    Double toMetersForPixel;
}
