package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.locationtech.jts.geom.Geometry;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DrawLineBufferPayload
{
	@Schema(description = "From date")
	@NotNull
	AbsoluteDate fromPointInTime;

	@Schema(description = "To date (optional, default propagate to infinity)")
	AbsoluteDate toPointInTime;
	
	@Schema(description = "The line buffer geometry", type = "string", format = "WKT geometry")
	@NotNull
	private Geometry geom;
	
	@Schema(description = "The line buffer size")
	@NotNull
	private Double bufferSize;

	@Schema(description = "The paramters used to apply the geometry in relation to the already existing ones")
	@NotNull
	@Valid
	private DrawLineBufferParameters drawLineBufferParameters;
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	public static class DrawLineBufferParameters
	{
		@Schema(description = "The line buffer behaviour")
		@NotNull
		private LineBufferBehaviour behaviour;
		
		@Schema(description = "The line buffer position")
		@NotNull
		private LineBufferPosition position;
		
		@Schema(description = "The plots to consider during the line buffer operation; if null, all plots are considered")	 
		@Size(min = 1)
		private List<String> plotCodes;
	}
	
	@Schema(description = "The line buffer behaviour: ")
	public static enum LineBufferBehaviour
	{
		INTERNAL,
		EXTERNAL,
		FREE_DRAW
	}
	
	@Schema(description = "The line buffer position: ")
	public static enum LineBufferPosition
	{
		CENTER,
		RIGHT,
		LEFT
	}
}
