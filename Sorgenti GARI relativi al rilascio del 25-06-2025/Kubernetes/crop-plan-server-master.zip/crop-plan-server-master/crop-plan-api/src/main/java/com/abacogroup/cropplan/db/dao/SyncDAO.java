package com.abacogroup.cropplan.db.dao;

import com.abacogroup.cropplan.api.SyncOperation;
import com.abacogroup.cropplan.db.dao.ntt.SyncBreakingPoint;
import com.abacogroup.cropplan.db.dao.ntt.SyncPlot;
import com.abacogroup.cropplan.sdk.mapper.VersionColumnMapper;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.cropplan.sdk.model.sync.LatestSync;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;

import java.time.LocalDateTime;
import java.util.List;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(VersionColumnMapper.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface SyncDAO extends EnhancedSqlObject, BasicDAO, Transactional<SyncDAO>
{
	@SqlQuery("select sync_type as syncType, dt_sync as syncDate from crpl_sync where plan_id = :planId order by dt_sync desc")
	@RegisterBeanMapper(SyncOperation.class)
	public ResultIterator<SyncOperation> getSyncOperations(@Bind("planId") Long cropPlanId);
	
	@SqlQuery("select sync_type_in_progress from crpl_plans where id = :planId and dt_sync_in_progress >= :yesterdayDt")
	public String getSyncProgress(@Bind("planId") Long cropPlanId, @Bind("yesterdayDt") LocalDateTime yesterdayDt);

	@SqlUpdate("update crpl_plans set dt_sync_in_progress = :currentDt, last_sync_with_errors = 0, sync_type_in_progress = :syncType"
			+ "  where id = :planId and (dt_sync_in_progress is null or dt_sync_in_progress < :yesterdayDt)")
	public int setSyncInProgress(@Bind("planId") Long cropPlanId, @Bind("currentDt") LocalDateTime currentDt,
		@Bind("yesterdayDt") LocalDateTime yesterdayDt, @Bind("syncType") String syncType);

	@SqlUpdate("update crpl_plans set dt_sync_in_progress = null, sync_type_in_progress = null where id = :planId")
	public void setSetSyncStop(@Bind("planId") Long cropPlanId);

	@SqlQuery("select max(dt_sync) from crpl_sync where plan_id = :planId and sync_type in (<syncTypes>)")
	public LocalDateTime getLastSyncDate(@Bind("planId") Long cropPlanId, @BindList("syncTypes") List<String> syncTypes);

	@SqlQuery("select distinct t.parcel_code, t.breakingPointDt"
		+ "  from ("
		+ " select cpdp.parcel_code, cpd.day_from as breakingPointDt"
		+ "   from crpl_plot_data cpd, crpl_plot_data_parcels cpdp"
		+ "  where cpd.plan_id = :cropPlanId"
		+ "    and §current_timestamp§ between cpd.dt_insert and cpd.dt_delete"
		+ "    and cpdp.plot_data_id  = cpd.id"
		+ "    and day_from > :pointInTime"
		+ "  union"
		+ " select cpdp.parcel_code, to_char((to_date(cpd.day_to,'YYYYMMDD')+1),'YYYYMMDD') as breakingPointDt"
		+ "   from crpl_plot_data cpd, crpl_plot_data_parcels cpdp"
		+ "  where cpd.plan_id = :cropPlanId"
		+ "    and §current_timestamp§ between cpd.dt_insert and cpd.dt_delete"
		+ "    and cpdp.plot_data_id  = cpd.id"
		+ "    and (CASE WHEN day_to < '99991231' THEN to_char((to_date(day_to,'YYYYMMDD')+1),'YYYYMMDD') ELSE '99991231' END) > :pointInTime"
		+ "    and cpd.day_to < '99991231'"
		+ " ) t"
		+ " order by breakingPointDt")
	@RegisterBeanMapper(SyncBreakingPoint.class)
	public List<SyncBreakingPoint> getBreakingPoints(@Bind("cropPlanId") Long cropPlanId,
		@Bind("pointInTime") AbsoluteDate pointInTime);

	@SqlQuery("select cpd.id as plotId,"
		+ "           cpd.plot_code as plotCode,"
		+ "           cpd.geom,"
		+ "           cpd.srs,"
		+ "           cpd.day_from as fromDate,"
		+ "           cpd.day_to as toDate"
		+ "      from crpl_plot_data cpd, crpl_plots cp"
		+ "     where cpd.plan_id = :cropPlanId"
		+ "       and §current_timestamp§ between cpd.dt_insert and cpd.dt_delete"
		+ "       and (:pointInTime is null or :pointInTime between cpd.day_from and cpd.day_to)"
		+ "       and cp.plan_id = cpd.plan_id"
		+ "       and cp.plot_code = cpd.plot_code"
		+ "       and (:domainZoneId is null or cp.domain_zone_id = :domainZoneId)")
	@RegisterBeanMapper(SyncPlot.class)
	public List<SyncPlot> getPlots(@Bind("cropPlanId") Long cropPlanId, @Bind("pointInTime") AbsoluteDate pointInTime,
		@Bind("domainZoneId") String domainZoneId);
	
	@SqlQuery("select cpd.id as plotId,"
		+ "           cpd.plot_code as plotCode,"
		+ "           cpd.geom,"
		+ "           cpd.srs,"
		+ "           cpd.day_from as fromDate,"
		+ "           cpd.day_to as toDate"
		+ "      from crpl_plot_data cpd, crpl_plots cp, crpl_plot_data_parcels cpdp"
		+ "     where cpd.plan_id = :cropPlanId"
		+ "       and §current_timestamp§ between cpd.dt_insert and cpd.dt_delete"
		+ "       and (:pointInTime is null or :pointInTime between cpd.day_from and cpd.day_to)"
		+ "       and cp.plan_id = cpd.plan_id"
		+ "       and cp.plot_code = cpd.plot_code"
		+ "       and (:domainZoneId is null or cp.domain_zone_id = :domainZoneId)"
		+ "       and cpdp.plot_data_id = cpd.id"
		+ "       and cpdp.parcel_code = :parcelCode")
	@RegisterBeanMapper(SyncPlot.class)
	public List<SyncPlot> getPlotsByParcelCode(@Bind("cropPlanId") Long cropPlanId, @Bind("pointInTime") AbsoluteDate pointInTime,
		@Bind("domainZoneId") String domainZoneId, @Bind("parcelCode") String parcelCode);
	
	@SqlQuery("select cp.domain_zone_id"
		+ "      from crpl_plot_data cpd, crpl_plots cp"
		+ "     where cpd.plan_id = :cropPlanId"
		+ "       and §current_timestamp§ between cpd.dt_insert and cpd.dt_delete"
		+ "       and (:pointInTime is null or :pointInTime between cpd.day_from and cpd.day_to)"
		+ "       and cp.plan_id = cpd.plan_id"
		+ "       and cp.plot_code = cpd.plot_code"
		+ "  group by cp.domain_zone_id")
	public List<String> getPlotsDomainZoneIds(@Bind("cropPlanId") Long cropPlanId, @Bind("pointInTime") AbsoluteDate pointInTime);

	@SqlUpdate("insert into crpl_sync (plan_id, sync_type, dt_sync, reference_dt) values (:cropPlanId, :syncType, :currentDt, :referenceDt)")
	public void insertSync(@Bind("cropPlanId") Long cropPlanId, @Bind("syncType") String syncType,
		@Bind("currentDt") LocalDateTime currentDt,
		@Bind("referenceDt") AbsoluteDate referenceDt);

	@SqlQuery("select last_sync_with_errors from crpl_plans where id = :cropPlanId")
	public Boolean hasErrors(@Bind("cropPlanId") Long cropPlanId);

	@SqlUpdate("update crpl_plans set last_sync_with_errors = 1 where id = :cropPlanId")
	public void setSyncError(@Bind("cropPlanId") Long planId);
	
	@SqlQuery("select cs.sync_type as syncType,"
			+ "       cs.dt_sync as syncDate,"
			+ "       cs.reference_dt as referenceDate"
			+ "  from crpl_sync cs"
			+ " where cs.plan_id = :cropPlanId"
			+ "   and cs.dt_sync = (SELECT max(cs1.dt_sync) FROM crpl_sync cs1 WHERE cs1.plan_id = :cropPlanId)")
	@RegisterBeanMapper(LatestSync.class)
	public LatestSync getLatestSync(@Bind("cropPlanId") Long cropPlanId);
	
}

