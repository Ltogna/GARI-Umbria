package com.abacogroup.cropplan.bundle.model;

import com.abacogroup.cropplan.bundle.model.ValidationGroups.Delete;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Null;
import jakarta.validation.groups.Default;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PermCropFormsConfigMessage
{
	@NotBlank(groups = {Default.class, Delete.class})
	private String cropPlanType;
	@NotBlank(groups = {Default.class, Delete.class})
	private String formType;
	
	@Builder.Default
	private List<String> landUseCodes = new ArrayList<>();
	
	@Builder.Default
	private List<String> landUseClassCodes = new ArrayList<>();

	@Builder.Default
	private AbsoluteDate validFrom = AbsoluteDate.of("19700101");
	@Builder.Default
	private AbsoluteDate validTo = AbsoluteDate.of("99991231");

	/// not allowed in upsert
	@Null
	private AbsoluteDate deleteFrom;

	@Valid
	@Builder.Default
	private List<PermCropFormsFieldDefinition> fields = new ArrayList<>();
}
