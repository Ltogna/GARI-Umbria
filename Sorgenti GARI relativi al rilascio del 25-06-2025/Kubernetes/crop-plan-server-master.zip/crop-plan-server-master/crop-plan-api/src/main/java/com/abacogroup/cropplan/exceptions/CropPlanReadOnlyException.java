package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class CropPlanReadOnlyException extends WebApplicationException {
	private static final long serialVersionUID = 4973519283505241729L;

	public static class CropPlanReadOnlyExceptionErrorBody {
		@Schema(allowableValues = "CROP_PLAN_READ_ONLY_EXCEPTION")
		public String getErrorCode() {
			return "CROP_PLAN_READ_ONLY_EXCEPTION";
		}
	}

	private static final CropPlanReadOnlyExceptionErrorBody BODY = new CropPlanReadOnlyExceptionErrorBody();

	public CropPlanReadOnlyException() {
		super("The crop plan is read only",
				Response.status(Status.FORBIDDEN).entity(BODY).build());
	}
}
