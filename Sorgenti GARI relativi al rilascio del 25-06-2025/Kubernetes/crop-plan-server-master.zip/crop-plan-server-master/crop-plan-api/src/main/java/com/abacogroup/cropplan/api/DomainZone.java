package com.abacogroup.cropplan.api;

import org.jdbi.v3.core.mapper.Nested;

import com.abacogroup.cropplan.sdk.model.domain.BaseDomainZone;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "A domain area (i.e.: council, region, ...)")
public class DomainZone extends BaseDomainZone
{
	@Schema(description = "The domain zone spatial reference system", format = "AUTHORITY:ID", example = "EPSG:3857")
	private String srs;

	@Schema(description = "The domain bounding rectangle: business holded area or full domain MBR if none present")
	private MBR mbr;

	@Nested("mbr")
	public MBR getMbr()
	{
		return mbr;
	}

	public DomainZone(String domainZoneId, String code, String description, String srs, MBR mbr) {
		super( domainZoneId,  code,  description);
		this.srs = srs;
		this.mbr = mbr;
	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Schema(description = "A rectangle")
	public static final class MBR
	{
		private double xMin;
		private double yMin;
		private double xMax;
		private double yMax;
	}
}
