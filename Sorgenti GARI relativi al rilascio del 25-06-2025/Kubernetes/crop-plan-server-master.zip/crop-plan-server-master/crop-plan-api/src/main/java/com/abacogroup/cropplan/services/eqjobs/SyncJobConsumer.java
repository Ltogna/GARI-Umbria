package com.abacogroup.cropplan.services.eqjobs;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.abacogroup.cropplan.api.CropPlanDates;
import com.abacogroup.cropplan.api.payload.CopyCampaignPayload;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.SyncDAO;
import com.abacogroup.cropplan.sdk.model.sync.SyncType;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CopyCampaignService;
import com.abacogroup.cropplan.services.CropPlanDeclarationsService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.SyncOperationsService;
import com.abacogroup.cropplan.services.eqjobs.payload.SyncQueuePayload;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SyncJobConsumer implements ThrowingConsumer<SyncQueuePayload>, QueueErrorListener<SyncQueuePayload> {

	private final SyncDAO syncDAO;

	private final Sso2Client sso2Client;

	private final BaseService baseService;
	private final SyncOperationsService syncOperationsService;
	private final CopyCampaignService copyCampaignService;
	private final CropPlanService cropPlanService;
	private final CropPlanDeclarationsService cropPlanDeclarationsService;

	public SyncJobConsumer(Sso2Client sso2Client, BaseService baseService,
			SyncOperationsService syncOperationsService, CopyCampaignService copyCampaignService, CropPlanService cropPlanService,
			CropPlanDeclarationsService cropPlanDeclarationsService, DAOContainer daoContainer) {
		this(daoContainer.getSyncDAO(), sso2Client, baseService, syncOperationsService, copyCampaignService, cropPlanService, cropPlanDeclarationsService);
	}

	SyncJobConsumer(SyncDAO syncDAO, Sso2Client sso2Client, BaseService baseService, SyncOperationsService syncOperationsService,
			CopyCampaignService copyCampaignService, CropPlanService cropPlanService, CropPlanDeclarationsService cropPlanDeclarationsService) {
		this.syncDAO = syncDAO;
		this.sso2Client = sso2Client;
		this.baseService = baseService;
		this.syncOperationsService = syncOperationsService;
		this.copyCampaignService = copyCampaignService;
		this.cropPlanService = cropPlanService;
		this.cropPlanDeclarationsService = cropPlanDeclarationsService;
	}

	@Override
	public void accept(SyncQueuePayload payload) throws Exception {
		User user = (User) sso2Client.createSecurityContextFromUserName(payload.getTenant(), payload.getUsername()).getUserPrincipal();
		RuntimeEnvironment env = baseService.getEnvironmentFactory().create(user, payload.getLanguage());

		this.doSyncCropPlan(env, payload);
	}

	public void doSyncCropPlan(RuntimeEnvironment env, SyncQueuePayload payload) {
		try
		{
			syncDAO.useTransaction(dao -> {
				LocalDateTime currentDt = syncDAO.getCurrentTimestamp();
				if (payload.getCurrentDt().compareTo(currentDt.minusDays(1)) < 0)
				{
					throw new IllegalStateException("Sync queued more than a day ago!");
				}

				if (payload.getSyncType() == SyncType.LPIS || payload.getSyncType() == SyncType.LPIS_LITE || payload.getSyncType() == SyncType.PLOT_ALIGN) {
					List<String> syncTypes = new ArrayList<>();
					syncTypes.add(payload.getSyncType().toString());
					if (payload.getSyncType() == SyncType.LPIS_LITE)
						syncTypes.add(SyncType.LPIS.toString());

					LocalDateTime lastSyncDate = dao.getLastSyncDate(payload.getCropPlanId(), syncTypes);
					if (lastSyncDate != null && lastSyncDate.compareTo(payload.getCurrentDt()) >= 0) {
						throw new IllegalStateException("Another sync is already performed after queuing this sync!");
					}
				}

				this.handleSyncType(payload, env);
				

				if (payload.isRecalcAnomaliesNeeded())
					syncOperationsService.recalcAnomalies(env, payload.getBusinessId(), payload.getCropPlanId(), payload.getReferenceDt(), syncDAO.getCurrentTimestamp());

				String syncType = determineSyncType(payload);

				syncDAO.insertSync(payload.getCropPlanId(), syncType, payload.getSyncPluginDt(), payload.getReferenceDt());
			});
		}
		finally
		{
			syncDAO.setSetSyncStop(payload.getCropPlanId());
		}
	}

	protected String determineSyncType(SyncQueuePayload payload){
		if (payload.getOldestChangesDateFromLpisDate() == null &&
					(payload.getSyncType() == SyncType.LPIS || payload.getSyncType() == SyncType.LPIS_LITE)) {
					return SyncType.RECALC_ANOMALIES.toString();
		} 

		return payload.getSyncType().toString();
	}
	
	protected void handleSyncType(SyncQueuePayload payload, RuntimeEnvironment env){
		switch (payload.getSyncType())
				{
				case LPIS:
					
					syncOperationsService.syncFromLpisChanges(env, payload.getBusinessId(), payload.getCropPlanId(), payload.getCurrentDt(), payload.getLastSyncDt(),
							payload.getSyncPluginDt(), payload.getOldestChangesDateFromLpisDate(), payload.isIgnoreDefaults(), false
					);
					break;
				case LPIS_LITE:
					syncOperationsService.syncFromLpisChanges(env, payload.getBusinessId(), payload.getCropPlanId(), payload.getCurrentDt(), payload.getLastSyncDt(),
							payload.getSyncPluginDt(), payload.getOldestChangesDateFromLpisDate(), payload.isIgnoreDefaults(), true
					);
					break;
				case WIZARD:
					syncOperationsService.syncWizard(env, payload.getBusinessId(), payload.getCropPlanId(), payload.getCurrentDt(), payload.getSyncPluginDt());
					break;
				case PLOT_ALIGN:
					syncOperationsService.syncPlotAlign(env, payload.getBusinessId(), payload.getCropPlanId(), payload.getCurrentDt(), payload.getLastSyncDt(), payload.getSyncPluginDt());
					break;
				case COPY_CAMPAIGN:
					copyCampaignService.copyCampaign(env, payload.getBusinessId(), payload.getCropPlanId(),
							new CopyCampaignPayload(payload.getSourceCropPlanId(), payload.getSourceVersion(), payload.getSourcePointInTime(),
									payload.getReferenceDt(), payload.getLanduseCodesExcludedFromAggregation(),
									payload.isFlCopyFromOtherBusinesses(), payload.isPreserveSourceDeclDates(), payload.isSkipAggregation(),
									payload.getDeclsPointInTimeTo()));
					break;
				case MASSIVE_FIELDS_UPDATE:
					CropPlanDates cropPlanDates = cropPlanService.getCropPlanDates(env, payload.getBusinessId(), payload.getCropPlanId(),
							payload.getReferenceDt());

					cropPlanDeclarationsService.declMassiveFieldsUpdate(env, payload.getCropPlanId(), payload.getBusinessId(),
							payload.getCurrentDt(), cropPlanDates, payload.getReferenceDt(),
							payload.getDomainZoneIds(), payload.getLandUseCodesWithRotation(), payload.getNewPermanentCropForms(),
							payload.getNewFieldsCodes(), payload.isIgnoreDeclValidationWarnings());
					break;
				case RECALC_ANOMALIES:
					// nothing to do
					break;
				default:
					throw new IllegalStateException("Unsupported " + payload.getSyncType() + " SyncType!");
				}
	}

	@Override
	public ErrorAction onJobError(SyncQueuePayload payload, Throwable t) {
		log.error("Error during synchronization {}", payload.getSyncType().toString(), t);
		syncDAO.setSyncError(payload.getCropPlanId());
		return ErrorAction.MARK_AS_ERRORED;
	}
}
