package com.abacogroup.cropplan.bundle.model;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HeaderTitle {
	@NotBlank
	private String headerTitleCode;
	@Valid
	private List<I18nValueDefinition> i18nValues;
}
