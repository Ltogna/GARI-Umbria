package com.abacogroup.cropplan.api;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "The plot editability: EDITABLE (geometry and declarations), ONLY_DECLARATIONS or NOT_EDITABLE")
public enum PlotEditability
{
	NOT_EDITABLE, ONLY_DECLARATIONS, EDITABLE
}
