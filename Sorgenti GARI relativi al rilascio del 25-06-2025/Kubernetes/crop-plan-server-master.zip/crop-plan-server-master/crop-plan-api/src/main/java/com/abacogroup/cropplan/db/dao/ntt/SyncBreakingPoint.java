package com.abacogroup.cropplan.db.dao.ntt;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.Data;

@Data
public class SyncBreakingPoint
{
	private String parcelCode;
	private AbsoluteDate breakingPointDt;
}
