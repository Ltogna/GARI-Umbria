package com.abacogroup.cropplan.resources.providers;

import jakarta.ws.rs.ext.ParamConverter;
import jakarta.ws.rs.ext.ParamConverterProvider;
import jakarta.ws.rs.ext.Provider;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Provider
public class LocalDateTimeProvider implements ParamConverterProvider
{

	@Override
	public <T> ParamConverter<T> getConverter(Class<T> clazz, Type type, Annotation[] annotations)
	{
		if (!clazz.equals(LocalDateTime.class))
			return null;
		
		return new ParamConverter<T>()
		{
			@Override
			@SuppressWarnings("unchecked")
			public T fromString(String value)
			{
				if (value == null)
					return null;
				return (T) LocalDateTime.parse(value);
			}

			@Override
			public String toString(T time)
			{
				LocalDateTime dt = (LocalDateTime) time;
				return dt.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
			}
		};
	}
}
