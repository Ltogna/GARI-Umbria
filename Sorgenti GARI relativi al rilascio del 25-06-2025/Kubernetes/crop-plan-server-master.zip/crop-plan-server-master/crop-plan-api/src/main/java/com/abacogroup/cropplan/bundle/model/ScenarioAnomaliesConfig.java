package com.abacogroup.cropplan.bundle.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScenarioAnomaliesConfig {
	
	private String anomaliyCode;
	
	private Boolean fl_present;
}
