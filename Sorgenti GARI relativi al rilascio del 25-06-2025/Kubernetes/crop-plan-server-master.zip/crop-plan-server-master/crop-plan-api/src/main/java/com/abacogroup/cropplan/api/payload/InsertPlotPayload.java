package com.abacogroup.cropplan.api.payload;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
public class InsertPlotPayload extends EditPlotPayload
{
	@Schema(description = "The description")
	private String description;
	private String notes;
}
