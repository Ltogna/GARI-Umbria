package com.abacogroup.cropplan.resources.pub;

import com.abacogroup.cropplan.api.payload.InsertDeclPesticidePayload;
import com.abacogroup.cropplan.api.payload.InsertPlotPesticidePayload;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.PesticidesDAO;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.BaseCropPlanResource;
import com.abacogroup.cropplan.sdk.model.Version;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.pesticides.Pesticide;
import com.abacogroup.cropplan.sdk.model.pesticides.PesticideEntry;
import com.abacogroup.cropplan.sdk.model.pesticides.UnitsOfMeasurment;
import com.abacogroup.cropplan.sdk.model.pesticides.UomType;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.CropPlanDeclarationsService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.LocksService;
import com.abacogroup.cropplan.services.PesticidesService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("{tenant}/public/v1/pesticides")
@Tag(name = "PUBLIC - Pesticides resources")
@Timed
@RolesAllowed({"CRPL|USER","CRPL|EDITOR"})
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class PublicTenantPesticideResources extends BaseCropPlanResource
{
	private static int PAGE_SIZE = 25;

	private PluginManager pluginManager;
	private PesticidesDAO pesticidesDAO;
	private PesticidesService pesticidesService;
	private CropPlanDeclarationsService cropPlanDeclarationsService;
	
	public PublicTenantPesticideResources(BaseService baseService, PluginManager pluginManager, DAOContainer daocontainer, 
			PesticidesService pesticidesService, CropPlanService cropPlanService, CropPlanDeclarationsService cropPlanDeclarationsService,
			LocksService locksService, CropCodeService cropCodeService, ValidatorService validatorService, CropPlanConfigService cropPlanConfigService)
	{
		super(baseService, cropPlanService, locksService, cropCodeService,
				validatorService, cropPlanConfigService, pluginManager, daocontainer.getCropPlansDAO());
		this.pluginManager = pluginManager;
		this.pesticidesDAO = daocontainer.getPesticidesDAO();
		this.pesticidesService = pesticidesService;
		this.cropPlanDeclarationsService = cropPlanDeclarationsService;
	}

	@GET
	@Path("{businessId}/plans/{cropPlanId}/available-pesticides")
	@Operation(description = "Get the list of available pesticides for the selected crop type")
	@ApiResponse(description = "The list of the available pesticides for the selected crop type")
	public InfiniteListResults<Pesticide> getPesticides(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The list of the land use codes") @QueryParam("landUseCode") String landUseCode,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(user, language, businessId);
		
		return this.pluginManager.getPesticidesPlugin(businessId, cropPlanId, tenantId).getPesticides(env, landUseCode, null, nextKey);
	}
	
	@GET
	@Path("{businessId}/plans/{cropPlanId}/available-pesticides/units-of-measurment/{type}")
	@Operation(description = "Get the list of available units of measurment")
	@ApiResponse(description = "The list of the available units of measurment")
	public UnitsOfMeasurment getPesticideUoms(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The type of unit of measurment") @PathParam("type") UomType type,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(user, language, businessId);
		
		return this.pluginManager.getPesticidesPlugin(businessId, cropPlanId, tenantId).getUnitsOfMeasurment(env, type);
	}

	@POST
	@Path("{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/decls/{declCode}/pesticides-entries")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Inserts a pesticide entry")
	public void insertPesticide(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,		
		@Parameter(description = "The plot declaration code") @PathParam("declCode") String declCode,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid InsertDeclPesticidePayload payload)
	{
		checkCanWrite(user, language, businessId);
		pesticidesService.checkCanEditPesticideOnDeclaration(cropPlanId, plotCode, declCode);

		var id = pesticidesDAO.getDeclPesticidesSeq();
		pesticidesDAO.insertPesticide(id, id.toString(), cropPlanId, plotCode, declCode, payload.getProductCode(), payload.getUomCode(), payload.getAmount(), payload.getDate(), user.getUserId(), pesticidesDAO.getCurrentTimestamp());		
	}

	@GET
	@Path("{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/decls/{declCode}/pesticides-entries")
	@Operation(description = "Get the list of the pesticides of a declaration")
	@ApiResponse(description = "The list of the pesticides of a declaration")
	public InfiniteListResults<PesticideEntry> getDeclPesticides(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,		
		@Parameter(description = "The plot declaration code") @PathParam("declCode") String declCode,		
		@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
		@Parameter(description = "The search string") @QueryParam("search") String search,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(user, language, businessId);
		
		var versionDt = version != null ? version.toDateTime() : pesticidesDAO.getCurrentTimestamp();
		return pesticidesService.getPesticideEntriesPaged(env, businessId, cropPlanId, tenantId, versionDt, plotCode, declCode, search, nextKey, PAGE_SIZE);
	}

	@DELETE
	@Path("{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/decls/{declCode}/pesticides-entries/{pesticideEntryCode}")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Deletes a pesticide entry on a declaration")
	public void deletePesticide( 
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,		
		@Parameter(description = "The plot declaration code") @PathParam("declCode") String declCode,
		@Parameter(description = "The pesticide entry code") @PathParam("pesticideEntryCode") String pesticideEntryCode,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(user, language, businessId);
		checkLock(env, cropPlanId);
		pesticidesService.checkCanEditPesticideOnDeclaration(cropPlanId, plotCode, declCode);		
		pesticidesService.deletePesticides(pesticideEntryCode, declCode, plotCode, cropPlanId, pesticidesDAO.getCurrentTimestamp(), user.getUserId());
	}

	@GET
	@Path("{businessId}/plans/{cropPlanId}/available-pesticides/{pesticideProductCode}/land-uses")
	@Operation(description = "Get the list of the land uses")
	@ApiResponse(description = "The list of the land uses")
	public InfiniteListResults<LandUse> getLandUsePesticides(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The pesticide product code") @PathParam("pesticideProductCode") String pesticideProductCode,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);

		var landUsesCodes = pluginManager.getPesticidesPlugin(businessId, cropPlanId, tenantId).getCompatibleLandUses(env, pesticideProductCode, nextKey);
		var landUses = pluginManager.getCropCodesPlugin(businessId, cropPlanId, tenantId).getLandUses(env, landUsesCodes.getRecords());
		return new InfiniteListResultsImpl<LandUse>(landUses, landUsesCodes.getNextKey());
	}

	@POST
	@Path("{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/land-uses/{landUseCode}/pesticides-entries")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Inserts pesticide entries on a crop")
	public void insertPlotPesticides(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
		@Parameter(description = "The land use code") @PathParam("landUseCode") String landUseCode,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid InsertPlotPesticidePayload payload)
	{
		checkCanWrite(user, language, businessId);
		var decls = cropPlanDeclarationsService.getPlotDeclarationsByLanduse(cropPlanId, pesticidesDAO.getCurrentTimestamp(), payload.getDate(), payload.getDate(), plotCode, landUseCode);
		decls.forEach(decl ->
		{
			var id = pesticidesDAO.getDeclPesticidesSeq();
			pesticidesDAO.insertPesticide(id, id.toString(), cropPlanId, plotCode, decl.getDeclCode(), payload.getProductCode(), payload.getUomCode(), payload.getAmount(), payload.getDate(), user.getUserId(),  pesticidesDAO.getCurrentTimestamp());	
		});
	}
	
}
