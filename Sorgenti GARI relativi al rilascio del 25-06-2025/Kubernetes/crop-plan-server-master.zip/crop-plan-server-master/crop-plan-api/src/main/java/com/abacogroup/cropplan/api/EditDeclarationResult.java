package com.abacogroup.cropplan.api;

import java.util.ArrayList;
import java.util.List;

import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.validation.ValidationMessage;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "A declaration edit result")
public class EditDeclarationResult extends ValidationResult
{
	private Declaration declaration;

	public EditDeclarationResult()
	{
		setValidationMessages(new ArrayList<>());
	}

	public EditDeclarationResult(Declaration declaration)
	{
		this.declaration = declaration;
		setValidationMessages(new ArrayList<>());
	}

	public EditDeclarationResult(List<ValidationMessage> messages)
	{
		setValidationMessages(messages);
	}
}
