package com.abacogroup.cropplan;

import static java.util.stream.Collectors.toSet;

import java.io.IOException;
import java.sql.DatabaseMetaData;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeoutException;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.jdbi.v3.core.Jdbi;
import org.locationtech.jts.geom.Geometry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.initializer.BundleInitServiceBuilder;
import com.abacogroup.bundles.listener.ListenerBuilder;
import com.abacogroup.bundles.listener.configdata.ProcessorOrderPolicyEnum;
import com.abacogroup.bundles.listener.configdata.builder.ConfigDataConsumerBuilder;
import com.abacogroup.bundles.listener.tenant.builder.NewTenantEventConsumerBuilder;
import com.abacogroup.cropplan.CropPlanConfiguration.PluginsConfig;
import com.abacogroup.cropplan.CropPlanConfiguration.RabbitmqConfig;
import com.abacogroup.cropplan.bundle.AdditionalDeclarationFieldsConfigProcessor;
import com.abacogroup.cropplan.bundle.AnomScenarioDisableFuncConfigProcessor;
import com.abacogroup.cropplan.bundle.AnomaliesProcessor;
import com.abacogroup.cropplan.bundle.CropPlanConfigProcessor;
import com.abacogroup.cropplan.bundle.CropPlanLandUseClassOptionsProcessor;
import com.abacogroup.cropplan.bundle.CropPlanPrintParamProcessor;
import com.abacogroup.cropplan.bundle.CropPlanPrintProcessor;
import com.abacogroup.cropplan.bundle.CropPlanTenantMessageProcessor;
import com.abacogroup.cropplan.bundle.CropPlanTypeProcessor;
import com.abacogroup.cropplan.bundle.PermCropFormFieldValuesConfigProcessor;
import com.abacogroup.cropplan.bundle.PermCropFormsConfigProcessor;
import com.abacogroup.cropplan.db.dao.CacheDecodesDAO;
import com.abacogroup.cropplan.db.dao.CacheLandCoverCompatibilityDAO;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDeleteAndRestoreOperationsDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.db.dao.LocksDAO;
import com.abacogroup.cropplan.db.dao.PesticidesDAO;
import com.abacogroup.cropplan.db.dao.PestsDAO;
import com.abacogroup.cropplan.db.dao.PlotEditDAO;
import com.abacogroup.cropplan.db.dao.PrintsDAO;
import com.abacogroup.cropplan.db.dao.SubdomainZoneDAO;
import com.abacogroup.cropplan.db.dao.SyncDAO;
import com.abacogroup.cropplan.db.dao.ValidatorDAO;
import com.abacogroup.cropplan.dispatch.CropPlanCommitJob;
import com.abacogroup.cropplan.dispatch.CropPlanCommitPayload;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.BusinessRegistryResources;
import com.abacogroup.cropplan.resources.CropCodeResources;
import com.abacogroup.cropplan.resources.CropPlanDeclarationResources;
import com.abacogroup.cropplan.resources.CropPlanResources;
import com.abacogroup.cropplan.resources.DomainResources;
import com.abacogroup.cropplan.resources.PestResources;
import com.abacogroup.cropplan.resources.PesticideResources;
import com.abacogroup.cropplan.resources.PlotEditResources;
import com.abacogroup.cropplan.resources.providers.LocalDateTimeProvider;
import com.abacogroup.cropplan.resources.providers.OffsetDateTimeProvider;
import com.abacogroup.cropplan.resources.pub.PublicCropPlanResources;
import com.abacogroup.cropplan.resources.pub.PublicDomainResources;
import com.abacogroup.cropplan.resources.pub.PublicTenantBusinessRegistryResources;
import com.abacogroup.cropplan.resources.pub.PublicTenantCropPlanDeclarationResources;
import com.abacogroup.cropplan.resources.pub.PublicTenantCropPlanResources;
import com.abacogroup.cropplan.resources.pub.PublicTenantDomainResources;
import com.abacogroup.cropplan.resources.pub.PublicTenantInternalCropPlanResources;
import com.abacogroup.cropplan.resources.pub.PublicTenantPesticideResources;
import com.abacogroup.cropplan.resources.pub.PublicTenantPlotEditResources;
import com.abacogroup.cropplan.sdk.jackson.WKTGeometryDeserializer;
import com.abacogroup.cropplan.sdk.jackson.WKTGeometrySerializer;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CopyCampaignService;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.CropPlanDeclarationsService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.DeclarationService;
import com.abacogroup.cropplan.services.DomainService;
import com.abacogroup.cropplan.services.LocksService;
import com.abacogroup.cropplan.services.PesticidesService;
import com.abacogroup.cropplan.services.PestsService;
import com.abacogroup.cropplan.services.PlotEditService;
import com.abacogroup.cropplan.services.PrintService;
import com.abacogroup.cropplan.services.PropagationService;
import com.abacogroup.cropplan.services.SyncOperationsService;
import com.abacogroup.cropplan.services.SyncService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.cropplan.services.WmsService;
import com.abacogroup.cropplan.services.eqjobs.SyncJobConsumer;
import com.abacogroup.cropplan.services.eqjobs.payload.SyncQueuePayload;
import com.abacogroup.distributedlocks.LockManager;
import com.abacogroup.distributedlocks.impl.valkey.ValkeyLockManager;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.SsoAuthorizer;
import com.abacogroup.embeddedqueue.AbstractWorkQueue;
import com.abacogroup.embeddedqueue.KeyedJob;
import com.abacogroup.embeddedqueue.Queue;
import com.abacogroup.embeddedqueue.QueueErrorListener.ErrorAction;
import com.abacogroup.embeddedqueue.ScheduledQueue;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisher;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisherWorkQueue;
import com.abacogroup.jdbi.OraJdbiPlugin;
import com.abacogroup.jdbi.OraJdbiPlugin.OraJdbiPluginParams;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.plugins.impl.EnvironmentFactory;
import com.abacogroup.tracing.dropwizard.AbacoApplication;
import com.abacogroup.tracing.jaxrs.client.AddRequestId;
import com.abacogroup.wms4j.resources.WmsResourceTenantAware;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.db.ManagedDataSource;
import io.dropwizard.db.PooledDataSourceFactory;
import io.dropwizard.jdbi3.JdbiFactory;
import io.dropwizard.jdbi3.bundles.JdbiExceptionsBundle;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import io.dropwizard.migrations.MigrationsBundle;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import io.swagger.v3.oas.integration.SwaggerConfiguration;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration.Dynamic;
import jakarta.ws.rs.client.Client;
import oracle.jdbc.OracleConnection;

public class CropPlanApplication extends AbacoApplication<CropPlanConfiguration>
{
	private static final Logger log = LoggerFactory.getLogger(CropPlanApplication.class);

	@Override
	public String getName()
	{
		return "CropPlan";
	}

	@Override
	public void initialize(Bootstrap<CropPlanConfiguration> bootstrap)
	{
		bootstrap.addBundle(new JdbiExceptionsBundle());
		bootstrap.addBundle(new MigrationsBundle<>()
		{
			@Override
			public PooledDataSourceFactory getDataSourceFactory(CropPlanConfiguration configuration)
			{
				return configuration.getDatabase();
			}
		});

		// bootstrap.addCommand(new ShutdownCommand());

		SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
			new EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);
		// bootstrap.addBundle(new MultiPartBundle());
	}

	@Override
	public void doRun(CropPlanConfiguration configuration, Environment environment) throws Exception
	{
		ObjectMapper objectMapper = environment.getObjectMapper();
		configure(objectMapper);

		var jersey = environment.jersey();
		configureProviders(jersey);

		Jdbi jdbi = createJdbi(environment, "mainDB", configuration.getDatabase(), null);

		DAOContainer daocontainer = buildDaoContainer(jdbi);

		PluginsConfig pluginsConfig = configuration.getPluginsConfig();
		Map<String, ManagedDataSource> datasources = createDatasources(environment, pluginsConfig);
		Map<String, Jdbi> jdbis = createJdbi(environment, pluginsConfig, datasources);
		jdbis.put("mainDB", jdbi);
		Client client = createJerseyClient(environment, pluginsConfig);
		Sso2Client sso2Client = new Sso2Client(pluginsConfig.getProperties().get("sso2AuthSecret").toString(), 
				client.target(pluginsConfig.getProperties().get("sso2url").toString()));
		EnvironmentFactory environmenFactory = new EnvironmentFactory(datasources, jdbis,
			pluginsConfig.getProperties(), client, sso2Client);

		PluginManager pluginManager = new PluginManager(environmenFactory.get(), daocontainer.getCropPlansDAO());
		pluginManager.init();

		registerAuthFilters(environment, sso2Client);
		
		Connection rabbitmqConnection = createRabbitmqConnection(configuration.getRabbitmqConfig());

		LockManager lockManager = setupLockManager(configuration.getLockManagerUrl());

		AbstractWorkQueue<CropPlanCommitJob, ?> msgQueue = this.createMessageQueue(environment, jdbi, rabbitmqConnection);
		ScheduledQueue<Void> subdomainZonesCleanerQueue = this.createSubdomainZonesCleanerQueue(environment, jdbi, daocontainer);

		// ExecutorService executorService = createExecutorService(configuration);
		
		BaseService baseService = new BaseService(environmenFactory, pluginManager);
		CropPlanConfigService cropPlanConfigService = new CropPlanConfigService(daocontainer);
		CropCodeService cropCodeService = new CropCodeService(cropPlanConfigService, pluginManager, daocontainer);
		ValidatorService validatorService = new ValidatorService(cropCodeService, cropPlanConfigService, daocontainer, pluginManager);
		DomainService domainService = new DomainService(cropPlanConfigService, daocontainer, pluginManager);
		PesticidesService pesticidesService = new PesticidesService(daocontainer, pluginManager);
		PestsService pestsService = new PestsService(daocontainer, pluginManager);
		CropPlanDeclarationsService cropPlanDeclarationsService = new CropPlanDeclarationsService(cropCodeService, validatorService, pesticidesService,
				cropPlanConfigService, pluginManager, daocontainer);
		CropPlanService cropPlanService = new CropPlanService(sso2Client, environment.metrics(), jdbi, baseService, cropPlanDeclarationsService, cropPlanConfigService, validatorService, cropCodeService,
				daocontainer, pluginManager, msgQueue, configuration);
		DeclarationService declarationService = new DeclarationService(cropPlanConfigService, cropCodeService, daocontainer, pluginManager, lockManager);
		PropagationService propagationService = new PropagationService(cropPlanConfigService, daocontainer, pluginManager);
		PlotEditService plotEditService = new PlotEditService(cropPlanConfigService, cropPlanService, cropPlanDeclarationsService, declarationService,
				propagationService, validatorService, daocontainer, pluginManager);
		SyncOperationsService syncOperationsService = new SyncOperationsService(cropPlanService, cropPlanConfigService,
				cropPlanDeclarationsService, plotEditService, declarationService, validatorService, daocontainer, pluginManager);
		CopyCampaignService copyCampaignService = new CopyCampaignService(cropPlanConfigService, cropPlanService, plotEditService, cropCodeService, daocontainer, pluginManager);
		SyncJobConsumer syncJobConsumer = new SyncJobConsumer(sso2Client, baseService, syncOperationsService, copyCampaignService, cropPlanService,
				cropPlanDeclarationsService, daocontainer);
		SyncService syncService = new SyncService(cropPlanService, cropPlanConfigService, syncJobConsumer, daocontainer, pluginManager, configuration);
		LocksService locksService = new LocksService(validatorService, syncService, daocontainer);
		PrintService printService = new PrintService(daocontainer);

		WorkQueue<SyncQueuePayload> syncQueue = this.createSyncQueue(environment, jdbi, syncJobConsumer);
		syncService.setSyncQueue(syncQueue);
		this.registerResources(jersey, baseService, cropPlanConfigService, cropPlanService, cropPlanDeclarationsService, syncService, 
								locksService, cropCodeService, validatorService, declarationService, domainService, pesticidesService, pestsService, 
								plotEditService, printService, copyCampaignService, syncOperationsService, syncJobConsumer, pluginManager, daocontainer);
		
		createBundleInfrastructure(rabbitmqConnection, jdbi, daocontainer.getCropPlanConfigDAO());

		initMultiTenant(environment);
		initWmsServer(jersey, daocontainer.getCropPlansDAO(), cropPlanConfigService);
		initOpenApi(jersey);
		setupCORS(configuration, environment);
		startQueues(configuration, subdomainZonesCleanerQueue, msgQueue, syncQueue);
	}
	protected void registerResources(JerseyEnvironment jersey, BaseService baseService, CropPlanConfigService cropPlanConfigService,
			CropPlanService cropPlanService, CropPlanDeclarationsService cropPlanDeclarationsService, SyncService syncService,
			LocksService locksService, CropCodeService cropCodeService, ValidatorService validatorService,
			DeclarationService declarationService, DomainService domainService, PesticidesService pesticidesService,
			PestsService pestsService, PlotEditService plotEditService, PrintService printService,
			CopyCampaignService copyCampaignService, SyncOperationsService syncOperationsService,
			SyncJobConsumer syncJobConsumer, PluginManager pluginManager, DAOContainer daocontainer){

		jersey.register(new BusinessRegistryResources(baseService, pluginManager));
		jersey.register(new CropCodeResources(baseService, cropPlanService, locksService, cropCodeService, validatorService, cropPlanConfigService, pluginManager, daocontainer));
		jersey.register(new CropPlanResources(baseService, cropPlanService, cropPlanDeclarationsService, syncService, locksService, cropCodeService,
				validatorService, cropPlanConfigService, printService, pluginManager, daocontainer));
		jersey.register(new CropPlanDeclarationResources(baseService, cropPlanService, cropPlanDeclarationsService, locksService, cropCodeService,
				validatorService, cropPlanConfigService, copyCampaignService, syncService, pluginManager, daocontainer));
		jersey.register(new PublicCropPlanResources(baseService, cropPlanService, cropPlanDeclarationsService, declarationService, syncService, locksService,
				cropCodeService, validatorService, cropPlanConfigService, pluginManager, daocontainer));
		jersey.register(new PublicTenantCropPlanResources(baseService, cropPlanService, cropPlanDeclarationsService, declarationService, syncService,
				locksService, cropCodeService, validatorService, cropPlanConfigService, printService, pluginManager, daocontainer));
		jersey.register(new PublicTenantCropPlanDeclarationResources(baseService, cropPlanService, cropPlanDeclarationsService, declarationService,
				locksService, cropCodeService, validatorService, cropPlanConfigService, pluginManager, daocontainer));
		jersey.register(new PublicTenantInternalCropPlanResources(baseService, cropPlanService, locksService, cropCodeService, validatorService, cropPlanConfigService, pluginManager,
				daocontainer));
		jersey.register(new PlotEditResources(baseService, cropPlanConfigService, plotEditService, cropPlanService, locksService, validatorService,
				daocontainer, pluginManager));
		jersey.register(new PublicTenantPlotEditResources(baseService, cropPlanConfigService, plotEditService, cropPlanService, locksService, validatorService,
				daocontainer, pluginManager));
		jersey.register(new DomainResources(baseService, domainService));
		jersey.register(new PublicDomainResources(baseService, domainService, pluginManager));
		jersey.register(new PublicTenantDomainResources(baseService, domainService, pluginManager));
		jersey.register(new PublicTenantBusinessRegistryResources(baseService, pluginManager));

		jersey.register(new PublicTenantPesticideResources(baseService, pluginManager, daocontainer, pesticidesService, cropPlanService,
				cropPlanDeclarationsService, locksService, cropCodeService, validatorService, cropPlanConfigService));
		//jersey.register(new PesticideResources(baseService, pluginManager, cropPlansDAO, pesticidesDAO, pesticidesService, cropPlanService, locksService));
		jersey.register(new PesticideResources(baseService, cropPlanService, cropPlanDeclarationsService, locksService, cropCodeService, validatorService, cropPlanConfigService,
				pluginManager, daocontainer, pesticidesService));
		jersey.register(new PestResources(baseService, cropPlanService, cropPlanDeclarationsService, locksService, cropCodeService, validatorService, cropPlanConfigService,
				pluginManager, daocontainer, pestsService));
		//jersey.register(new PestResources(baseService, pluginManager, cropPlansDAO, pestsDAO, pestsService, cropPlanService, locksService));
	}

	private DAOContainer buildDaoContainer(Jdbi jdbi) {
		return DAOContainer.builder()
				.cropPlansDAO(jdbi.onDemand(CropPlansDAO.class))
				.cropPlansDeleteAndRestoreOperationsDAO(jdbi.onDemand(CropPlansDeleteAndRestoreOperationsDAO.class))
				.declarationsDAO(jdbi.onDemand(DeclarationsDAO.class))
				.plotEditDAO(jdbi.onDemand(PlotEditDAO.class))
				.locksDAO(jdbi.onDemand(LocksDAO.class))
				.validatorDAO(jdbi.onDemand(ValidatorDAO.class))
				.syncDAO(jdbi.onDemand(SyncDAO.class))
				.cacheDecodesDAO(jdbi.onDemand(CacheDecodesDAO.class))
				.cacheLandCoverCompatibilityDAO(jdbi.onDemand(CacheLandCoverCompatibilityDAO.class))
				.cropPlanConfigDAO(jdbi.onDemand(CropPlanConfigDAO.class))
				.pesticidesDAO(jdbi.onDemand(PesticidesDAO.class))
				.pestsDAO(jdbi.onDemand(PestsDAO.class))
				.printsDAO(jdbi.onDemand(PrintsDAO.class))
				.subdomainZoneDAO(jdbi.onDemand(SubdomainZoneDAO.class))
				.build();
	}

	private Connection createRabbitmqConnection(RabbitmqConfig rabbitmqConfig)
	{
		if (rabbitmqConfig == null)
		{
			return null;
		}

		if (StringUtils.isBlank(rabbitmqConfig.getHost()))
		{
			return null;
		}

		ConnectionFactory factory = new ConnectionFactory();
		factory.setMaxInboundMessageBodySize(120*1024*1024); //120MB
		factory.setHost(rabbitmqConfig.getHost());

		if (!StringUtils.isBlank(rabbitmqConfig.getUser()))
		{
			factory.setUsername(rabbitmqConfig.getUser());
		}
		if (!StringUtils.isBlank(rabbitmqConfig.getPassword()))
		{
			factory.setPassword(rabbitmqConfig.getPassword());
		}
		if (!StringUtils.isBlank(rabbitmqConfig.getVirtualhost()))
		{
			factory.setVirtualHost(rabbitmqConfig.getVirtualhost());
		}
		if (rabbitmqConfig.getPort() != null)
		{
			factory.setPort(rabbitmqConfig.getPort());
		}
		factory.setAutomaticRecoveryEnabled(true);

		try
		{
			return factory.newConnection();
		}
		catch (IOException | TimeoutException e)
		{
			throw new IllegalStateException("Cannot connect to rabbit mq", e);
		}
	}

	private LockManager setupLockManager(String lockManagerUrl) {
        String[] tokens = lockManagerUrl.split(":");
        String host = tokens[0];
        int port = ValkeyLockManager.DEFAULT_PORT;
        if (tokens.length > 1)
            port = Integer.parseInt(tokens[1]);
        return new ValkeyLockManager(host, port);
    }

	private void createBundleInfrastructure(Connection rabbitmqConnection, Jdbi jdbi, CropPlanConfigDAO configDAO)
	{
		if (rabbitmqConnection == null)
		{
			log.info("NOT CONNECTED TO RABBITMQ; bundles infrastructure is disabled");
			return;
		}

		final String serviceName = "crop-plan";

		try
		{
			ListenerBuilder.newBuilder(rabbitmqConnection)
				.withConfigDataConsumer(ConfigDataConsumerBuilder.newBuilder(jdbi, rabbitmqConnection)
						.route(serviceName)
						.processors(
								new CropPlanTypeProcessor(configDAO),
								new CropPlanConfigProcessor(configDAO),
								new CropPlanPrintProcessor(configDAO),
								new CropPlanPrintParamProcessor(configDAO),
								new CropPlanLandUseClassOptionsProcessor(configDAO),
								new PermCropFormsConfigProcessor(configDAO),
								new PermCropFormFieldValuesConfigProcessor(configDAO),
								new AnomaliesProcessor(configDAO),
								new AdditionalDeclarationFieldsConfigProcessor(configDAO),
								new AnomScenarioDisableFuncConfigProcessor(configDAO))
						.withOrderPolicy(ProcessorOrderPolicyEnum.PROCESSOR)
						.build())
				.withNewTenantEventConsumer(NewTenantEventConsumerBuilder.newBuilder(jdbi)
						.route(serviceName)
						.processors(new CropPlanTenantMessageProcessor(configDAO))
						.build())
				.buildListener()
				.start();

			BundleInitServiceBuilder.producer(rabbitmqConnection)
				.configLocation("./bundles")
				.build()
				.start();
		}
		catch (Exception e)
		{
			throw new IllegalStateException("Error starting rabbitmq listener", e);
		}
	}

	private Client createJerseyClient(Environment environment, PluginsConfig pluginsConfig)
	{
		var jerseyClient = pluginsConfig.getJerseyClient();
		Client client = null;
		if (jerseyClient != null)
			client = new JerseyClientBuilder(environment).using(jerseyClient).build("pluginsHttpClient").register(new AddRequestId());
		return client;
	}
	
	private static final String EXCHANGE_NAME = "crop-plan-commit";
	private static final String QUEUE_ID = "crpl-commit-queue";
	private AbstractWorkQueue<CropPlanCommitJob, ?> createMessageQueue(Environment environment, Jdbi jdbi,
			Connection rabbitmqConnection)
		throws IOException
	{
		if (rabbitmqConnection == null)
			return null;
		
		RabbitMqPublisherWorkQueue<CropPlanCommitJob> queue = new RabbitMqPublisherWorkQueue<>(QUEUE_ID, new JdbiRepository(jdbi)) {
			@Override
			protected Class<CropPlanCommitJob> getJobClass() {
				return CropPlanCommitJob.class;
			}
		};
		queue.setMetricRegistry(environment.metrics());
		var publisher = new RabbitMqPublisher<CropPlanCommitJob>(rabbitmqConnection) {
			@Override
			protected String getExchangeName() {
				return EXCHANGE_NAME;
			}
			
			@Override
			protected String getRoutingKey(CropPlanCommitJob payload) {
				if (payload.getCommiType() == CropPlanCommitJob.CommiType.IN_PUBLISHING)
					return payload.getCropPlanTypeCode();
				
				return payload.getCropPlanTypeCode() + "." + payload.getCommiType().name().toLowerCase();
			}
			
			@Override
			protected Map<String, Object> getMessageHeaders(CropPlanCommitJob payload) {
				return Map.of("tenant", payload.getTenant());
			}

			@Override
			protected byte[] getPayload(CropPlanCommitJob element) throws Exception {
				return getObjectMapper().writeValueAsBytes(new CropPlanCommitPayload(element));
			}
		};
		queue.setConsumer(publisher);
		
		return queue;
	}

	private ScheduledQueue<Void> createSubdomainZonesCleanerQueue(Environment environment, Jdbi jdbi, DAOContainer daocontainer) {
		String id = "crpl-subdomain-clean";
		ScheduledQueue<Void> subdomainZonesCleaner = ScheduledQueue.builder(id, new JdbiRepository(jdbi), Void.class)
				.withNumThreads(1)
				.withTimeoutMs(Duration.ofHours(6).toMillis())
				.withMetricsRegistry(environment.metrics())
				.withConsumer(x -> {
					SubdomainZoneDAO subdomainZoneDAO = daocontainer.getSubdomainZoneDAO();

					subdomainZoneDAO.useTransaction(h -> {
						LocalDateTime currentTimestamp = h.getCurrentTimestamp();

						h.deleteExpiredSubdomainZones(currentTimestamp.minusDays(2));
					});

				}).withErrorListener((x, e) -> ErrorAction.RESCHEDULE)
				.build();

		LocalDate tomorrow = LocalDate.now().plusDays(1);
		long startTime = tomorrow.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
		int rescheduleTime = (int) Duration.ofDays(1).toSeconds();
		subdomainZonesCleaner.addIfNotPresent(new KeyedJob<>(id, null), startTime, rescheduleTime);

		return subdomainZonesCleaner;
	}

	private static final String SYNC_QUEUE_ID = "crpl-sync-queue";
	private static final int SYNC_QUEUE_THREAD = 20;
	private static final long SYNC_QUEUE_TIMEOUT = Duration.ofDays(3).toMillis();
	private WorkQueue<SyncQueuePayload> createSyncQueue(Environment environment, Jdbi jdbi, SyncJobConsumer syncJobConsumer) {

		return WorkQueue.builder(SYNC_QUEUE_ID, new JdbiRepository(jdbi), SyncQueuePayload.class)
				.withNumThreads(SYNC_QUEUE_THREAD)
				.withTimeoutMs(SYNC_QUEUE_TIMEOUT)
				.withMetricsRegistry(environment.metrics())
				.withConsumer(syncJobConsumer)
				.withErrorListener(syncJobConsumer)
				.build();
	}

	private void startQueues(CropPlanConfiguration configuration, Queue<?, ?>... queues ) {
		if (!configuration.isDevMode()) {
			log.info("starting queues");
			for (Queue<?, ?> queue : queues) {
				if (queue != null) {
					queue.start();
				}
			}
		} else {
			log.warn("** SKIP QUEUES START ON DEV MODE! **");
		}
	}

	/*private ExecutorService createExecutorService(CropPlanConfiguration configuration)
	{
		if (configuration.getExecutorServiceConfig() == null)
			throw new IllegalStateException("No executor service configuration found");
		return Executors.newFixedThreadPool(configuration.getExecutorServiceConfig().getMaxThreads());
	}*/

	private Jdbi createJdbi(Environment environment, String name, DataSourceFactory dsFactory,
		ManagedDataSource datasource)
	{
		JdbiFactory factory = new JdbiFactory();
		Jdbi jdbi;
		if (datasource != null)
			jdbi = factory.build(environment, dsFactory, datasource, name);
		else
			jdbi = factory.build(environment, dsFactory, name);

		var isPostgres = jdbi.withHandle(h -> {
			String db = h.queryMetadata(DatabaseMetaData::getDatabaseProductName);
			log.info("Database connection '{}' is '{}'", name, db);
			return db.toLowerCase().contains("postgresql");
		});

		if (isPostgres)
			jdbi.installPlugin(new PgJdbiPlugin());
		else
		{
			var params = new OraJdbiPluginParams(cnn -> cnn.unwrap(OracleConnection.class), true);
			jdbi.installPlugin(new OraJdbiPlugin(params));
		}

		//jdbi.setSqlLogger(new Slf4JSqlLogger());

		return jdbi;
	}

	private Map<String, Jdbi> createJdbi(Environment environment, PluginsConfig pluginsConfig,
		Map<String, ManagedDataSource> datasources)
	{
		Map<String, Jdbi> ret = new HashMap<>();
		if (pluginsConfig.getDataSources() != null) {
			pluginsConfig.getDataSources()
					.entrySet()
					.stream()
					.forEach(e -> {
						String name = e.getKey();
						DataSourceFactory dsFactory = e.getValue();
						ret.put(name, createJdbi(environment, name, dsFactory, datasources.get(name)));
					});
		}

		return ret;
	}

	private Map<String, ManagedDataSource> createDatasources(Environment environment, PluginsConfig pluginsConfig)
	{
		Map<String, ManagedDataSource> ret = new HashMap<>();
		if (pluginsConfig.getDataSources() != null) {
			pluginsConfig.getDataSources()
			.entrySet()
			.stream()
			.forEach(e -> ret.put(e.getKey(), e.getValue().build(environment.metrics(), "plugins.ds." + e.getKey())));
		}

		return ret;
	}

	private void registerAuthFilters(Environment environment, Sso2Client sso2Client)
	{
		AuthUtils.installAuthFilter(
				environment,
				sso2Client,
				new SsoAuthorizer(sso2Client));
		
		/*List<AuthFilter<?, ? extends User>> filters = new ArrayList(
				pluginManager.getAuthPlugin().getAuthFilters(environment, pluginsEnvironment));
		// if (filters.isEmpty())
		if (configuration.isDevMode())
		{
			filters.add(new BasicCredentialAuthFilter.Builder<User>()
				.setAuthenticator(new YouAreWelcomeAuthenticator())
				.setRealm("GUEST authenticator")
				.buildAuthFilter());
		}

		ChainedAuthFilter usersFilter = new ChainedAuthFilter(filters);

		final PolymorphicAuthDynamicFeature<? extends User> feature = new PolymorphicAuthDynamicFeature<>(
			ImmutableMap.of(User.class, usersFilter));

		PolymorphicAuthValueFactoryProvider.Binder<? extends User> binder = new PolymorphicAuthValueFactoryProvider.Binder<>(
			ImmutableSet.of(User.class));

		environment.jersey().register(feature);
		environment.jersey().register(binder);
		environment.jersey().register(RolesAllowedDynamicFeature.class);*/
	}

	private void initMultiTenant(Environment environment)
	{
		environment.jersey().register(new MultitenantFilter("tenant"));
	}
	
	private void initWmsServer(JerseyEnvironment jersey, CropPlansDAO cropPlansDAO, CropPlanConfigService cropPlanConfigService)
	{
		WmsResourceTenantAware wmsResource = new WmsResourceTenantAware();
		WmsService wmsService = new WmsService(cropPlansDAO, cropPlanConfigService);
		wmsService.getInternalWMSLayers().forEach(wmsResource::addLayer);
		jersey.register(wmsResource);
	}

	private void initOpenApi(JerseyEnvironment jersey)
	{
		OpenAPI oas = new OpenAPI();

		oas.info(new Info()
			.title("ABACO CropPlan")
			.description("CropPlan APIs")
			.version("1.0")
			// .termsOfService("http://example.com/terms")
			.contact(new Contact().email("info@abacogroup.eu")));

		SwaggerConfiguration oasConfig = new SwaggerConfiguration()
			.openAPI(oas)
			.prettyPrint(true)
			.resourcePackages(Stream.of("com.abacogroup.cropplan.resources").collect(toSet()))
			//.resourcePackages(Stream.of("com.abacogroup.cropplan.resources.pub").collect(toSet()))
			.ignoredRoutes(Stream.of("/public").collect(toSet()));

		jersey.register(new OpenApiResource()
			.openApiConfiguration(oasConfig));
	}

	private void setupCORS(CropPlanConfiguration configuration, Environment environment)
	{
		if (!configuration.isCors())
		{
			log.info("CORS is disabled");
			return;
		}

		log.info("CORS is enabled");

		Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,DELETE");

		// OPTIONS pre-flight request will be served by the filter ONLY and not
		// passed ahead
		// cors.setInitParameter(CrossOriginFilter.CHAIN_PREFLIGHT_PARAM,
		// "false");

		// Add URL mapping
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

	private void configureProviders(JerseyEnvironment jersey)
	{
		jersey.register(OffsetDateTimeProvider.class);
		jersey.register(LocalDateTimeProvider.class);
	}

	private void configure(ObjectMapper objectMapper)
	{
		objectMapper
			.setTimeZone(TimeZone.getDefault())
			.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

		SimpleModule module = new SimpleModule("custom-deserializers", Version.unknownVersion());
		module.addSerializer(Geometry.class, new WKTGeometrySerializer());
		module.addDeserializer(Geometry.class, new WKTGeometryDeserializer());
		objectMapper.registerModule(module);
	}

	public static void main(String[] args)
	{
		try {
			new CropPlanApplication().run(args);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

}
