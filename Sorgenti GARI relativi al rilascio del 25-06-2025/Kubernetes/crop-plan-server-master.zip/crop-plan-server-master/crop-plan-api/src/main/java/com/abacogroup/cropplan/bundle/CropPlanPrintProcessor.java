package com.abacogroup.cropplan.bundle;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.cropplan.bundle.model.CropPlanPrintsMessage;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;

public class CropPlanPrintProcessor extends AbstractConfigProcessor
{
	private static final String I18N_TABLE_NAME = "CRPL_PRINTS";
	private static final String I18N_FIELD_NAME = "CODE";

	public CropPlanPrintProcessor(CropPlanConfigDAO configDAO)
	{
		super(configDAO);
	}

	@Override
	public String getDomainName()
	{
		return "prints";
	}

	@Override
	public void onMessageInTransaction(CropPlanConfigDAO dao, ConfigDataMessage message)
	{
		message.getConfigFiles().stream()
			.map(Path::toFile)
			.filter(file -> file.getAbsolutePath().endsWith(".json"))
			.sorted()
			.forEach(file -> processFile(message.getTenantId(), file));
	}

	private void processFile(String tenantId, File file)
	{
		CropPlanPrintsMessage message;
		try
		{
			message = objectMapper.readValue(file, CropPlanPrintsMessage.class);
		}
		catch (IOException e)
		{
			throw new IllegalStateException("Error processing file " + file.getName() + " for tenant " + tenantId, e);
		}

		if (file.getAbsolutePath().endsWith(".delete.json"))
		{
			doDelete(tenantId, message);
		}
		else
		{
			doInsertOrUpdate(tenantId, message);
		}
	}

	private void doInsertOrUpdate(String tenantId, CropPlanPrintsMessage message)
	{
		if (message == null || message.getCropPlanPrints() == null || message.getCropPlanPrints().isEmpty())
		{
			return;
		}

		Long typeId = configDAO.getCropPlanTypeId(message.getCropPlanType(), tenantId);
		message.getCropPlanPrints().forEach(cropPlanPrint -> {
			configDAO.deleteCropPlanPrint(cropPlanPrint.getCode(), typeId);
			configDAO.insertCropPlanPrint(cropPlanPrint.getCode(), typeId);
			
			cropPlanPrint.getI18nValues().forEach(i18nValue -> {
				configDAO.deleteI18nValue(I18N_TABLE_NAME, I18N_FIELD_NAME, cropPlanPrint.getCode(),
					i18nValue.getLanguage(), tenantId);

				configDAO.insertI18nValue(I18N_TABLE_NAME, I18N_FIELD_NAME, cropPlanPrint.getCode(),
					i18nValue.getLanguage(), i18nValue.getText(), tenantId);
			});
		});
	}

	private void doDelete(String tenantId, CropPlanPrintsMessage message)
	{
		if (message == null || message.getCropPlanPrints() == null || message.getCropPlanPrints().isEmpty())
		{
			return;
		}

		Long typeId = configDAO.getCropPlanTypeId(message.getCropPlanType(), tenantId);
		message.getCropPlanPrints().forEach(cropPlanPrint -> {
			configDAO.deleteCropPlanPrint(cropPlanPrint.getCode(), typeId);
			
			cropPlanPrint.getI18nValues().forEach(i18nValue -> {
				configDAO.deleteI18nValue(I18N_TABLE_NAME, I18N_FIELD_NAME, cropPlanPrint.getCode(),
					i18nValue.getLanguage(), tenantId);
			});
		});
	}
}
