package com.abacogroup.cropplan.db.dao.ntt;

import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormType;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Data for permanent crop form configuration")
public class PermanentCropFormConfigWithFields
{
	private String land_use_code;
	
	private String land_use_class_code;
	
	private Long perm_crop_forms_cfg_id;
	
	private PermanentCropFormType formType;
	
	private String fieldCode;
	
	private boolean flMandatory;
	
	private boolean flEditable;
}
