package com.abacogroup.cropplan.bundle.model;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class I18nValueDefinition
{
	@NotBlank
	private String language;
	private String text;
}
