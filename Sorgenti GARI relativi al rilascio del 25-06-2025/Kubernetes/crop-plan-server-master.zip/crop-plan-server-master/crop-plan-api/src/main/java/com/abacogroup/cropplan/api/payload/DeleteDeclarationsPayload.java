package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;
import lombok.Data;

@Data
public class DeleteDeclarationsPayload
{
	@Schema(description = "The date to be evaluated")
	@NotNull
	private AbsoluteDate pointInTime;

	@Schema(description = "The plots to be evaluated")
	@NotNull
	@Size(min = 1)
	@Valid
	private List<String> plotCodes;
}
