package com.abacogroup.cropplan.resources;

import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.sdk.model.business.Business;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.MaxRowsResults;
import com.codahale.metrics.annotation.Timed;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.PermitAll;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.ForbiddenException;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.SecurityContext;

@Path("{tenant}/api-priv/v1/business-registry")
@Tag(name = "PRIVATE - Business registry resources")
@Timed
@PermitAll
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class BusinessRegistryResources extends BaseResource
{
	private PluginManager pluginManager;

	public BusinessRegistryResources(BaseService baseService, PluginManager pluginManager)
	{
		super(baseService);
		this.pluginManager = pluginManager;
	}

	@GET
	@Operation(description = "Search for a business")
	@ApiResponse(description = "The list of businesses that matches the search criteria")
	public MaxRowsResults<Business> searchBusiness(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The search string") @QueryParam("search") String search,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		return pluginManager.getBusinessPlugin().searchBusinesses(createEnvironment(user, language), search);
	}

	@GET
	@Path("/{businessId}")
	@Operation(description = "Get a business based on it's business ID")
	@ApiResponses({
		@ApiResponse(description = "The business"),
		@ApiResponse(responseCode = "404", description = "Business not found")
	})
	public Business getBusiness(
		@Context SecurityContext context,
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		if (!context.isUserInRole("CRPL|USER") && !context.isUserInRole("CRPL|EDITOR"))
			throw new ForbiddenException("You are not allowed to access this business");
		
		checkCanRead(user, language, businessId);

		return pluginManager.getBusinessPlugin().getBusinessDetails(createEnvironment(user, language), businessId);
	}

}
