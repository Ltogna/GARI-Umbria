package com.abacogroup.cropplan.api;

import java.time.LocalDateTime;

import com.abacogroup.cropplan.sdk.model.PermanentCropForm;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder=true)
@Schema(description = "A permanent crop form")
public class PermanentCropFormSave
{
	private boolean isNew;
	private String declCode;
	private Long cropPlanId;
	private String plotCode;
	private String userId;
	private LocalDateTime saveDt;
	private PermanentCropForm pcf;
}
