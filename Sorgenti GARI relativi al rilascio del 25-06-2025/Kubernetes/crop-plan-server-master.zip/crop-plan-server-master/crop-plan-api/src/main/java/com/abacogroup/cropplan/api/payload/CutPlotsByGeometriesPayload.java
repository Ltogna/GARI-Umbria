package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.DefaultValue;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.locationtech.jts.geom.Geometry;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class CutPlotsByGeometriesPayload
{
	@Schema(description = "From date")
	@NotNull
	AbsoluteDate fromPointInTime;

	@Schema(description = "To date (optional, default propagate to infinity)")
	AbsoluteDate toPointInTime;

	@Schema(description = "The list of cut geometries", type = "string", format = "WKT geometry")
	@NotEmpty
	private List<Geometry> geoms;

	@Schema(description = "The parameters used to apply the geometry in relation to the already existing ones")
	@NotNull
	@Valid
	private GeometriesCutParameters cutParameters;

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@SuperBuilder
	public static class GeometriesCutParameters
	{
		@Schema(description = "The plots to consider during the cut operation; if null, all plots are considered")
		@Size(min = 1)
		private List<String> plotCodes;

		@Schema(description = "If true, the specified cut geometries are merged before cut")
		@DefaultValue("false")
		private boolean flMergeGeomsOnCutOnLayer;
		
		@Schema(description = "If true, covered by inserted are computed")
		@DefaultValue("false")
		private boolean flCalcCoveredByInsertedOnCutOnLayer;
	}
}
