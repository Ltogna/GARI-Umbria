package com.abacogroup.cropplan.bundle;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.cropplan.bundle.model.CropPlanConfigMessage;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;

public class CropPlanConfigProcessor extends AbstractConfigProcessor
{
	public CropPlanConfigProcessor(CropPlanConfigDAO configDAO)
	{
		super(configDAO);
	}

	@Override
	public String getDomainName()
	{
		return "configurations";
	}

	@Override
	public void onMessageInTransaction(CropPlanConfigDAO dao, ConfigDataMessage message)
	{
		message.getConfigFiles().stream()
			.map(Path::toFile)
			.filter(file -> file.getAbsolutePath().endsWith(".json"))
			.sorted()
			.forEach(file -> processFile(message.getTenantId(), file));
	}

	private void processFile(String tenantId, File file)
	{
		CropPlanConfigMessage message;
		try
		{
			message = objectMapper.readValue(file, CropPlanConfigMessage.class);
		}
		catch (IOException e)
		{
			throw new IllegalStateException("Error processing file " + file.getName() + " for tenant " + tenantId, e);
		}

		if (file.getAbsolutePath().endsWith(".delete.json"))
		{
			doDelete(tenantId, message);
		}
		else
		{
			doInsertOrUpdate(tenantId, message);
		}
	}

	private void doInsertOrUpdate(String tenantId, CropPlanConfigMessage message)
	{
		if (message == null || message.getCropPlanConfig() == null || message.getCropPlanConfig().isEmpty())
		{
			return;
		}

		Long typeId = configDAO.getCropPlanTypeId(message.getCropPlanType(), tenantId);
		message.getCropPlanConfig().forEach(cropPlanConfig -> {
			configDAO.deleteCropPlanConfig(cropPlanConfig.getParamName(), typeId);
			configDAO.insertCropPlanConfig(cropPlanConfig.getParamName(), cropPlanConfig.getParamValue(), typeId);
		});
	}

	private void doDelete(String tenantId, CropPlanConfigMessage message)
	{
		if (message == null || message.getCropPlanConfig() == null || message.getCropPlanConfig().isEmpty())
		{
			return;
		}

		Long typeId = configDAO.getCropPlanTypeId(message.getCropPlanType(), tenantId);
		message.getCropPlanConfig().forEach(cropPlanConfig -> {
			configDAO.deleteCropPlanConfig(cropPlanConfig.getParamName(), typeId);
		});
	}
}
