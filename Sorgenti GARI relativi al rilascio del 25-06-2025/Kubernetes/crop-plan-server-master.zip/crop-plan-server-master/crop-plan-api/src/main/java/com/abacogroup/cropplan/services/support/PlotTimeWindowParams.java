package com.abacogroup.cropplan.services.support;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class PlotTimeWindowParams
{
	private Long cropPlanId;
	private String domainZoneId;
	private String businessId;
	private LocalDateTime versionDt;
	private AbsoluteDate pointInTimeFrom;
	private AbsoluteDate pointInTimeTo;
	private String plotCode;
	private String excludedDeclCode;
}
