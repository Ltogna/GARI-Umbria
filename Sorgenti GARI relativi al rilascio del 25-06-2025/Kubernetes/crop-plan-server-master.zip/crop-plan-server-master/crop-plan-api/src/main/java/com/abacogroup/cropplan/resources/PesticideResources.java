package com.abacogroup.cropplan.resources;

import java.util.List;

import com.abacogroup.cropplan.api.PlotDataToInclude;
import com.abacogroup.cropplan.api.payload.InsertDeclPesticidePayload;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.db.dao.PesticidesDAO;
import com.abacogroup.cropplan.exceptions.CropPlanCantBeDeletedException;
import com.abacogroup.cropplan.exceptions.CropPlanNotWriteableException;
import com.abacogroup.cropplan.exceptions.CropPlanReadOnlyException;
import com.abacogroup.cropplan.exceptions.LockException;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.sdk.model.BaseDeclaration;
import com.abacogroup.cropplan.sdk.model.Version;
import com.abacogroup.cropplan.sdk.model.pesticides.Pesticide;
import com.abacogroup.cropplan.sdk.model.pesticides.PesticideEntry;
import com.abacogroup.cropplan.sdk.model.pesticides.UnitsOfMeasurment;
import com.abacogroup.cropplan.sdk.model.pesticides.UomType;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.CropPlanDeclarationsService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.LocksService;
import com.abacogroup.cropplan.services.PesticidesService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.MaxRowsResults;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("{tenant}/api-priv/v1/pesticides")
@Tag(name = "PRIVATE - Pesticides resources")
@Timed
@RolesAllowed({"CRPL|USER","CRPL|EDITOR"})
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class PesticideResources extends BaseCropPlanResource {
	private static int PAGE_SIZE = 10;

	private PluginManager pluginManager;
	private CropPlanService cropPlanService;
	private CropPlanDeclarationsService cropPlanDeclarationsService;
	private DeclarationsDAO declarationsDAO;
	private PesticidesDAO pesticidesDAO;
	private PesticidesService pesticidesService;

	public PesticideResources(BaseService baseService, 
			CropPlanService cropPlanService,
			CropPlanDeclarationsService cropPlanDeclarationsService,
			LocksService locksService,
			CropCodeService cropCodeService,
			ValidatorService validatorService,
			CropPlanConfigService cropPlanConfigService,
			PluginManager pluginManager, 
			DAOContainer daocontainer,
			PesticidesService pesticidesService
			) {
				super(baseService, cropPlanService, locksService, cropCodeService, validatorService, cropPlanConfigService, pluginManager, daocontainer.getCropPlansDAO()
				);
		this.cropPlanService = cropPlanService;
		this.cropPlanDeclarationsService = cropPlanDeclarationsService;
		this.pluginManager = pluginManager;
		this.pesticidesDAO = daocontainer.getPesticidesDAO();
		this.declarationsDAO = daocontainer.getDeclarationsDAO();
		this.pesticidesService = pesticidesService;
		
	}

	@GET
	@Path("{businessId}/plans/{cropPlanId}/available-pesticides")
	@Operation(description = "Get the list of available pesticides for the selected crop type")
	@ApiResponse(description = "The list of the available pesticides for the selected crop type")
	public MaxRowsResults<Pesticide> searchPesticides(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The list of the land use codes") @QueryParam("landUseCode") String landUseCode,
			@Parameter(description = "The search string") @QueryParam("search") String search,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);
		
		return this.pluginManager.getPesticidesPlugin(businessId, cropPlanId, tenantId).searchPesticides(env, landUseCode, search);
	}

	@GET
	@Path("{businessId}/plans/{cropPlanId}/available-pesticides/units-of-measurment/{type}")
	@Operation(description = "Get the list of available units of measurment")
	@ApiResponse(description = "The list of the available units of measurment")
	public UnitsOfMeasurment getPesticideUoms(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The type of unit of measurment") @PathParam("type") UomType type,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);
		
		return this.pluginManager.getPesticidesPlugin(businessId, cropPlanId, tenantId).getUnitsOfMeasurment(env, type);
	}

	@POST
	@Path("{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/decls/{declCode}/pesticides-entries")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Inserts a pesticide entry")
	@ApiResponses({
			@ApiResponse(description = "The pesticide entry operation result")
	})
	public void insertPesticide(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The plot declaration code") @PathParam("declCode") String declCode,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid InsertDeclPesticidePayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		pesticidesService.checkCanEditPesticideOnDeclaration(cropPlanId, plotCode, declCode);

		var id = pesticidesDAO.getDeclPesticidesSeq();
		pesticidesDAO.insertPesticide(id, id.toString(), cropPlanId, plotCode, declCode, payload.getProductCode(), payload.getUomCode(), payload.getAmount(),
				payload.getDate(), user.getUserId(), pesticidesDAO.getCurrentTimestamp());
	}

	@GET
	@Path("{businessId}/plans/{cropPlanId}/pesticides-entries")
	@Operation(description = "Get the list of all pesticides entries")
	@ApiResponse(description = "The list of all pesticides entries")
	public InfiniteListResults<PesticideEntry> getAllPesticides(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,		
		@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@Parameter(description = "The search string") @QueryParam("search") String search,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);
		
		var versionDt = version != null ? version.toDateTime() : pesticidesDAO.getCurrentTimestamp();	
		var pestEntries = pesticidesService.getPesticideEntriesPaged(env, businessId, cropPlanId, tenantId, versionDt, null, null, search, nextKey, PAGE_SIZE);
		pestEntries.getRecords().forEach(pestEntry ->
		{
			var decl = declarationsDAO.getDeclarationByDeclCode(cropPlanId, pestEntry.getPlotCode(), versionDt, pestEntry.getDeclCode());
			cropPlanDeclarationsService.fillLandUsesData(env, businessId, cropPlanId, versionDt, List.of(decl), new PlotDataToInclude());
			pestEntry.setDeclaration(new BaseDeclaration(decl.getDeclId(), decl.getDeclCode(), decl.getLanduse(), decl.getAreaPerc(), decl.getStyle(), decl.getFromDate(), decl.getFromDatePrecision(), decl.getToDate()));
			pestEntry.setParcelIntersection(cropPlanService.getParcelIntersectionsByPlotCode(env, businessId, cropPlanId, versionDt, pestEntry.getEntryDate(), pestEntry.getPlotCode()));
			pestEntry.setPlotAreaSqm(cropPlanService.getPlotAreaSqm(cropPlanId, versionDt, pestEntry.getEntryDate(), pestEntry.getPlotCode()));
		});
		return pestEntries;
	}

	@DELETE
	@Path("{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/decls/{declCode}/pesticides-entries/{pesticideEntryCode}")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Deletes a pesticide entry on a declaration")
	@ApiResponses({
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan Pesticide lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "400", description = "The crop plan Pesticide can't be deleted", content = @Content(schema = @Schema(implementation = CropPlanCantBeDeletedException.CropPlanCantBeDeletedExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan Pesticide", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public void deletePesticide(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The plot declaration code") @PathParam("declCode") String declCode,
			@Parameter(description = "The pesticide entry code") @PathParam("pesticideEntryCode") String pesticideEntryCode,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);
		
		pesticidesService.checkCanEditPesticideOnDeclaration(cropPlanId, plotCode, declCode);
		pesticidesService.deletePesticides(pesticideEntryCode, declCode, plotCode, cropPlanId, pesticidesDAO.getCurrentTimestamp(), user.getUserId());
	}

	@PUT
	@Path("{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/decls/{declCode}/pesticides-entries/{pesticideEntryCode}")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Updates a pesticide entry on a declaration")
	@ApiResponses({
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan Pesticide lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan Pesticide is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan Pesticide", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public void updatePesticide(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The plot declaration code") @PathParam("declCode") String declCode,
			@Parameter(description = "The pesticide entry code") @PathParam("pesticideEntryCode") String pesticideEntryCode,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid InsertDeclPesticidePayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);
		
		pesticidesService.checkCanEditPesticideOnDeclaration(cropPlanId, plotCode, declCode);
		pesticidesService.updatePesticides(pesticideEntryCode, declCode, plotCode, cropPlanId, pesticidesDAO.getCurrentTimestamp(), user.getUserId(), payload);
	}
}
