package com.abacogroup.cropplan.services.utils;

import static java.util.stream.Collectors.toList;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.locationtech.jts.geom.Geometry;

import com.abacogroup.cropplan.api.CropPlanDates;
import com.abacogroup.cropplan.api.EditPlotResult;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.payload.CopyCampaignPayload;
import com.abacogroup.cropplan.api.payload.InsertPermanentCropForm;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.exceptions.LandUseCodeNotFoundException;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseDetails;
import com.abacogroup.cropplan.sdk.model.domain.Parcel;
import com.abacogroup.cropplan.sdk.spi.CropCodesPlugin;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.PlotEditService;
import com.abacogroup.cropplan.services.support.EditorSupportParams;
import com.abacogroup.geometryeditor.PolygonMerger;
import com.abacogroup.geometryeditor.PolygonMerger.ResultingPolygon;
import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.model.AuditEntity;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CopyCampaignUtils {

	private final CropPlansDAO cropPlansDAO;

	private final PlotEditService plotEditService;
	private final CropCodeService cropCodeService;
	private final CropPlanConfigService cropPlanConfigService;

	private final PluginManager pluginManager;

	private final Cache<String, LandUseDetails> landUseDetailsCache;

	public CopyCampaignUtils(CropPlansDAO cropPlansDAO, PlotEditService plotEditService, CropCodeService cropCodeService,
			CropPlanConfigService cropPlanConfigService, PluginManager pluginManager) {
		this.cropPlansDAO = cropPlansDAO;

		this.plotEditService = plotEditService;
		this.cropCodeService = cropCodeService;
		this.cropPlanConfigService = cropPlanConfigService;

		this.pluginManager = pluginManager;

		this.landUseDetailsCache = Caffeine.newBuilder()
				.maximumSize(10000)
				.expireAfterWrite(60, TimeUnit.MINUTES)
				.build();
	}

	public List<Plot> aggregatePlots(RuntimeEnvironment env, String businessId, Long cropPlanId, CopyCampaignPayload payload, List<Plot> previousPlots) {
		CropCodesPlugin cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId());

		List<Plot> toAggregatePlots = new ArrayList<>(previousPlots);
		toAggregatePlots.sort(Comparator.comparingDouble((Plot p) -> Optional.of(p)
				.map(Plot::getGeom).map(Geometry::getArea).orElse(0.)).reversed()
				.thenComparing((Plot p) -> Optional.of(p).map(Plot::getDecls)
						.stream().flatMap(Collection::stream)
						.map(Declaration::getLanduse).map(LandUse::getCode)
						.sorted().findFirst().orElse("")));

		List<Plot> aggregatedPlots = new ArrayList<>();

		// remove excluded
		for (Iterator<Plot> iterator = toAggregatePlots.iterator(); iterator.hasNext();) {
			Plot p = iterator.next();
			if (Optional.of(p).map(plot -> this.splitDeclarationsByCropRotation(plot, payload.getSourcePointInTime()))
					.stream().flatMap(Collection::stream).flatMap(Collection::stream)
					.map(Declaration::getLanduse)
					.map(LandUse::getCode)
					.anyMatch(luc -> payload.getLanduseCodesExcludedFromAggregation().contains(luc))) {
				aggregatedPlots.add(p);
				iterator.remove();
			}
		}

		// aggregate
		while (toAggregatePlots.size() > 1) {
			Plot candidatePlot = toAggregatePlots.remove(0);

			List<Plot> canBeAggregatedPlots = new ArrayList<>();
			canBeAggregatedPlots.add(candidatePlot);

			for (Iterator<Plot> iterator = toAggregatePlots.iterator(); iterator.hasNext();) {
				Plot toAggregatePlot = iterator.next();
				if (cropCodesPlugin.canAggregate(env,
						payload.getSourcePointInTime(),
						candidatePlot.getDecls(),
						toAggregatePlot.getDecls())) {
					canBeAggregatedPlots.add(toAggregatePlot);
					iterator.remove();
				}
			}

			if (canBeAggregatedPlots.size() > 1) {
				Geometry allPlotsGeom = Utils.getUnion(canBeAggregatedPlots.stream()
						.map(Plot::getGeom).filter(Objects::nonNull).collect(toList()));

				addAggregatedPlots(aggregatedPlots, canBeAggregatedPlots, allPlotsGeom);
			} else {
				aggregatedPlots.addAll(canBeAggregatedPlots);
			}
		}

		if (!toAggregatePlots.isEmpty()) {
			aggregatedPlots.add(toAggregatePlots.remove(0));
		}

		return aggregatedPlots;
	}

	private void addAggregatedPlots(List<Plot> aggregatedPlots, List<Plot> canBeAggregatedPlots,
			Geometry allPlotsGeom) {
		for (int i = 0; i < allPlotsGeom.getNumGeometries(); i++) {
			Geometry aggregatedPlotsGeom = allPlotsGeom.getGeometryN(i);

			List<Plot> adjacentPlots = new ArrayList<>();
			for (Plot canBeAggregatedPlot : canBeAggregatedPlots) {
				if (Utils.snappedIntersectionAB(aggregatedPlotsGeom, canBeAggregatedPlot.getGeom()).getArea() > 0) {
					adjacentPlots.add(canBeAggregatedPlot);
				}
			}

			if (adjacentPlots.size() > 1) {
				Plot biggerPlot = adjacentPlots.get(0);

				biggerPlot.setGeom(aggregatedPlotsGeom);
				aggregatedPlots.add(biggerPlot);
			} else {
				aggregatedPlots.addAll(adjacentPlots);
			}
		}
	}

	public void copyDeclarationsOnParcel(RuntimeEnvironment env, CopyCampaignPayload payload, Parcel currentParcel, List<Plot> sourcePlots,
			CropPlanDates cropPlanDates, EditorSupportParams editorSupportParams) {

		AbsoluteDate currentParcelFromDate = AbsoluteDate.of(currentParcel.getFromDate());
		AbsoluteDate currentParcelToDate = AbsoluteDate.of(currentParcel.getToDate());

		List<ResultingPolygon<String, Plot>> resultingPolygons = this.cutParcel(currentParcel, sourcePlots);

		AbsoluteDate fromDate = Optional.of(cropPlanDates)
				.map(CropPlanDates::getCampaignStartDate)
				.or(() -> Optional.of(payload.getDestPointInTime()))
				.filter(absoluteDate -> currentParcelFromDate.toLocalDate().isBefore(absoluteDate.toLocalDate()))
				.orElse(currentParcelFromDate);

		for (ResultingPolygon<String, Plot> resultingPolygon : resultingPolygons) {
			if (null == resultingPolygon.getKeyA() || resultingPolygon.getPolygon().getArea() < 1) {
				continue;
			}

			processResultingPolygon(env, payload, currentParcelToDate, fromDate, editorSupportParams, resultingPolygon);
		}
	}

	private void processResultingPolygon(RuntimeEnvironment env, CopyCampaignPayload payload, AbsoluteDate currentParcelToDate, AbsoluteDate fromDate,
			EditorSupportParams editorSupportParams, ResultingPolygon<String, Plot> resultingPolygon) {
		EditPlotResult editPlotResult = plotEditService.drawGeometryPropagatingBehaviour(env, editorSupportParams,
				resultingPolygon.getPolygon(), currentParcelToDate, fromDate, true, null, true);

		List<List<Declaration>> splittedDeclarations = payload.isPreserveSourceDeclDates()
				? (resultingPolygon.getKeyB() != null ? Arrays.asList(resultingPolygon.getKeyB().getDecls()) : new ArrayList<>())
				: this.splitDeclarationsByCropRotation(resultingPolygon.getKeyB(), payload.getSourcePointInTime());

		for (Plot newPlot : editPlotResult.getAdded()) {
			if (newPlot.getFullRangeFromDate().isAfter(payload.getDestPointInTime())
					|| newPlot.getFullRangeToDate().isBefore(payload.getDestPointInTime())) {
				continue; // the inserted plot is not alive at point in time (should never happen) => then ignore it
			}

			if (cropPlanConfigService.isIgnoreCropPlanConstraintsDeclsToPlots(editorSupportParams.getCropPlanId())) {
				this.copyDeclarationsOnPlot(env, payload, editorSupportParams, newPlot, splittedDeclarations);
			} else {
				this.copyDeclarationsOnPlotEvaluatingFreeIntervals(env, payload, editorSupportParams, newPlot, splittedDeclarations);
			}
		}
	}

	private void copyDeclarationsOnPlot(RuntimeEnvironment env, CopyCampaignPayload payload, EditorSupportParams editorSupportParams,
			Plot currentPlot, List<List<Declaration>> groupedSourceDeclarations) {
		for (List<Declaration> sourceDeclarations : groupedSourceDeclarations) {
			for (Declaration declaration : sourceDeclarations) {
				this.insertDecl(env, editorSupportParams, currentPlot, declaration,
						new DateInterval(declaration.getFromDate().toLocalDate(), declaration.getToDate().toLocalDate()));
			}
		}
	}

	public void copyDeclarationsOnPlotEvaluatingFreeIntervals(RuntimeEnvironment env, CopyCampaignPayload payload, EditorSupportParams editorSupportParams,
			Plot currentPlot, List<List<Declaration>> groupedSourceDeclarations) {

		List<DateInterval> plotInUseDates = new ArrayList<>(DateInterval.fromPlotDates(currentPlot));

		for (List<Declaration> sourceDeclarations : groupedSourceDeclarations) {
			List<DateInterval> freeIntervals = DateInterval.findFreeIntervals(plotInUseDates);
			if (freeIntervals.isEmpty()) {
				break;
			}
			DateInterval freeInterval = freeIntervals.get(freeIntervals.size() - 1);

			for (Declaration declaration : sourceDeclarations) {

				DateInterval declDates = this.calculateDeclDates(env, payload, editorSupportParams, declaration,
						freeInterval.getDtFrom(), freeInterval.getDtTo());

				if (null != declDates) {
					plotInUseDates.add(declDates);

					this.insertDecl(env, editorSupportParams, currentPlot, declaration, declDates);
				}
			}
		}
	}

	private void insertDecl(RuntimeEnvironment env, EditorSupportParams editorSupportParams, Plot currentPlot, Declaration declaration,
			DateInterval declDates) {
		boolean isLandUseCompatible = Optional.of(currentPlot)
				.map(Plot::getParcelIntersections)
				.stream().flatMap(Collection::stream)
				.map(ParcelIntersection::getLandCoverCode)
				.allMatch(landCoverCode -> cropCodeService.isLandUseCompatible(env, editorSupportParams.getBusinessId(), editorSupportParams.getCropPlanId(),
						declaration.getLanduse().getCode(), landCoverCode, false));
		if (!isLandUseCompatible) {
			log.debug("cannot copy decl {} in plot {} of crop plan {}: land use code not compatible",
					declaration.getDeclCode(), currentPlot.getPlotCode(), editorSupportParams.getCropPlanId());
			return;
		}

		List<InsertPermanentCropForm> pcfs = declaration.getPermanentCropForms().stream()
				.map(pcf -> new InsertPermanentCropForm(pcf.getFormType(), pcf.getPermanentCropFormData()))
				.collect(toList());

		AbsoluteDate dayFrom = AbsoluteDate.of(declDates.getDtFrom());
		AbsoluteDate dayTo = AbsoluteDate.of(declDates.getDtTo().isAfter(AuditEntity.dateActive.toLocalDate())
				? AuditEntity.dateActive.toLocalDate()
				: declDates.getDtTo());

		cropPlansDAO.insertDeclaration(editorSupportParams.getCropPlanId(), currentPlot.getPlotCode(),
				dayFrom, declaration.getFromDatePrecision(), dayTo,
				declaration.getLanduse().getCode(), declaration.getAreaPerc(), pcfs, declaration.getFieldsCodes(), env.getUserId(),
				editorSupportParams.getVersionDt(), null);
	}

	private DateInterval calculateDeclDates(RuntimeEnvironment env, CopyCampaignPayload payload, EditorSupportParams editorSupportParams,
			Declaration declaration, LocalDate plotFromDate, LocalDate plotToDate) {
		if (payload.isPreserveSourceDeclDates()) {
			return declDatesFromDecl(declaration, plotFromDate, plotToDate);
		} else {
			return declDatesFromDefaults(env, payload, editorSupportParams, declaration, plotFromDate, plotToDate);
		}
	}

	private DateInterval declDatesFromDefaults(RuntimeEnvironment env, CopyCampaignPayload payload, EditorSupportParams editorSupportParams,
			Declaration declaration,
			LocalDate plotFromDate, LocalDate plotToDate) {
		String landUseCode = declaration.getLanduse().getCode();

		LandUseDetails landUseDetails = this.getCachedLandUseDetails(env, editorSupportParams.getBusinessId(), editorSupportParams.getCropPlanId(),
				payload.getDestPointInTime(), landUseCode);

		LocalDate declFromDate = Optional.of(landUseDetails)
				.map(LandUseDetails::getDefaultFromDate)
				.map(AbsoluteDate::of)
				.map(AbsoluteDate::toLocalDate)
				.filter(defaultFromDate -> defaultFromDate.isAfter(plotFromDate))
				.orElse(plotFromDate);

		LocalDate declToDate = Optional.of(landUseDetails)
				.map(LandUseDetails::getDefaultHarvestDays)
				.filter(days -> days > 0)
				.map(declFromDate::plusDays)
				.filter(defaultToDate -> defaultToDate.isBefore(plotToDate))
				.orElse(plotToDate);

		return new DateInterval(declFromDate, declToDate);
	}

	private DateInterval declDatesFromDecl(Declaration declaration, LocalDate plotFromDate, LocalDate plotToDate) {

		DateInterval fromDecl = DateInterval.fromDecl(declaration);

		return DateInterval.cutOnFreeIntervals(fromDecl, List.of(new DateInterval(plotFromDate, plotToDate)));
	}

	/*
	 * private DateInterval declDatesFromDeclRanges(Declaration declaration, LocalDate plotFromDate, LocalDate plotToDate) {
	 * 
	 * LocalDate declFromDate = Stream.of(plotFromDate, declaration.getFromDate().toLocalDate()) .filter(d -> d.isBefore(plotToDate)) .max(LocalDate::compareTo)
	 * .orElse(plotFromDate);
	 * 
	 * LocalDate declToDate = Stream.of(plotToDate, declFromDate.plusDays(ChronoUnit.DAYS.between(declaration.getFromDate().toLocalDate(),
	 * declaration.getToDate().toLocalDate()))) .filter(d -> d.isAfter(declFromDate)) .min(LocalDate::compareTo) .orElse(plotToDate);
	 * 
	 * return new DateInterval(declFromDate, declToDate); }
	 */

	private LandUseDetails getCachedLandUseDetails(RuntimeEnvironment env, String businessId, Long cropPlanId, AbsoluteDate pointInTime, String landUseCode) {
		String key = String.format("%s_%s_%s_%s__%s", env.getTenantId(), businessId, cropPlanId, pointInTime, landUseCode);

		return landUseDetailsCache.asMap().computeIfAbsent(key,
				k -> {
					try {
						return Optional.ofNullable(cropCodeService.getLandUseCode(env, businessId, cropPlanId, landUseCode, null, pointInTime))
								.orElse(new LandUseDetails());
					} catch (LandUseCodeNotFoundException e) {
						log.warn("Land use code {} not found during copy campaign for crop plan {}: {}", landUseCode, cropPlanId, e.getMessage());
						return new LandUseDetails();
					}
				});
	}

	private List<ResultingPolygon<String, Plot>> cutParcel(Parcel currentParcel, List<Plot> sourcePlots) {

		Map<String, Geometry> parcelGeom = Map.of(currentParcel.getCode(), currentParcel.getGeom());
		Map<Plot, Geometry> plotGeoms = sourcePlots.stream().map(p -> Map.entry(p, p.getGeom()))
				.collect(Collectors.toMap(Entry::getKey, Entry::getValue));

		return new PolygonMerger<>(parcelGeom, plotGeoms).apply();
	}

	/// list of first crop declarations and second crop declarations, removes other declarations
	private List<List<Declaration>> splitDeclarationsByCropRotation(Plot plot, AbsoluteDate pointInTime) {

		List<List<Declaration>> splittedDeclarations = new ArrayList<>();
		splittedDeclarations.add(new ArrayList<>());
		splittedDeclarations.add(new ArrayList<>());

		if (null != plot && null != plot.getDecls()
				&& !plot.getDecls().isEmpty()) {

			List<Declaration> sourceDeclarations = new ArrayList<>(plot.getDecls());

			sourceDeclarations.sort(Comparator.comparing((Declaration d) -> d.getFromDate().toLocalDate()).thenComparing(d -> d.getToDate().toLocalDate()));

			for (Declaration sourceDeclaration : sourceDeclarations) {
				if (!pointInTime.toLocalDate().isBefore(sourceDeclaration.getFromDate().toLocalDate())) {
					splittedDeclarations.get(0).add(sourceDeclaration);
				} else if (splittedDeclarations.get(1).isEmpty()) {
					splittedDeclarations.get(1).add(sourceDeclaration);
				} else {
					break;
				}
			}

		}

		return splittedDeclarations;
	}
}
