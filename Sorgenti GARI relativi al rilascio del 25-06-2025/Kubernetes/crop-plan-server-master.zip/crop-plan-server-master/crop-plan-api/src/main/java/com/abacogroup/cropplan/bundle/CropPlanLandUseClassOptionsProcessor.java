package com.abacogroup.cropplan.bundle;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.cropplan.bundle.model.CropPlanLandUseClassOptionsMessage;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;

public class CropPlanLandUseClassOptionsProcessor extends AbstractConfigProcessor
{
	public CropPlanLandUseClassOptionsProcessor(CropPlanConfigDAO configDAO)
	{
		super(configDAO);
	}

	@Override
	public String getDomainName()
	{
		return "crplLandUseClassOptions";
	}

	@Override
	public void onMessageInTransaction(CropPlanConfigDAO dao, ConfigDataMessage message)
	{
		message.getConfigFiles().stream()
			.map(Path::toFile)
			.filter(file -> file.getAbsolutePath().endsWith(".json"))
			.sorted()
			.forEach(file -> processFile(message.getTenantId(), file));
	}

	private void processFile(String tenantId, File file)
	{
		CropPlanLandUseClassOptionsMessage message;
		try
		{
			message = objectMapper.readValue(file, CropPlanLandUseClassOptionsMessage.class);
		}
		catch (IOException e)
		{
			throw new IllegalStateException("Error processing file " + file.getName() + " for tenant " + tenantId, e);
		}

		if (file.getAbsolutePath().endsWith(".delete.json"))
		{
			doDelete(tenantId, message);
		}
		else
		{
			doInsertOrUpdate(tenantId, message);
		}
	}

	private void doInsertOrUpdate(String tenantId, CropPlanLandUseClassOptionsMessage message)
	{
		if (message == null || message.getCrplLandUseClassOptions() == null || message.getCrplLandUseClassOptions().isEmpty())
		{
			return;
		}

		Long typeId = configDAO.getCropPlanTypeId(message.getCropPlanType(), tenantId);
		message.getCrplLandUseClassOptions().forEach(cropPlanLandUseClassOption -> {
			configDAO.deleteLandUseClassOption(typeId, cropPlanLandUseClassOption.getLandUseClassCode());
			var isPermanent = cropPlanLandUseClassOption.getPermanent();
			if (isPermanent == null)
				isPermanent = false;
			configDAO.insertLandUseClassOption(typeId, cropPlanLandUseClassOption.getLandUseClassCode(), 
					cropPlanLandUseClassOption.getPercFixedTo100() ? 1 : 0,
					isPermanent ? 1 : 0);
		});
	}

	private void doDelete(String tenantId, CropPlanLandUseClassOptionsMessage message)
	{
		if (message == null || message.getCrplLandUseClassOptions() == null || message.getCrplLandUseClassOptions().isEmpty())
		{
			return;
		}

		Long typeId = configDAO.getCropPlanTypeId(message.getCropPlanType(), tenantId);
		message.getCrplLandUseClassOptions().forEach(cropPlanLandUseClassOption -> {
			configDAO.deleteLandUseClassOption(typeId, cropPlanLandUseClassOption.getLandUseClassCode());
		});
	}
}
