package com.abacogroup.cropplan.services.utils;

import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.BaseDeclaration;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DateInterval {

	private LocalDate dtFrom;
	private LocalDate dtTo;

	public DateInterval(LocalDate dtFrom, Integer plusDays) {
		this.dtFrom = dtFrom;
		this.dtTo = dtFrom.plusDays(plusDays);
	}

	public static DateInterval fromDecl(BaseDeclaration declaration) {
		DateInterval dateInterval = new DateInterval();
		dateInterval.setDtFrom(Optional.ofNullable(declaration)
				.map(BaseDeclaration::getFromDate)
				.map(AbsoluteDate::toLocalDate)
				.orElseGet(() -> LocalDate.MIN.plusDays(1)));
		dateInterval.setDtTo(Optional.ofNullable(declaration)
				.map(BaseDeclaration::getToDate)
				.map(AbsoluteDate::toLocalDate)
				.orElseGet(() -> LocalDate.MAX.minusDays(1)));

		return dateInterval;
	}

	public static List<DateInterval> fromPlotDates(Plot plot) {
		DateInterval di1 = new DateInterval();
		di1.setDtFrom(LocalDate.MIN);
		di1.setDtTo(Optional.ofNullable(plot)
				.map(Plot::getFromDate)
				.map(AbsoluteDate::toLocalDate)
				.map(d -> d.minusDays(1))
				.orElse(LocalDate.MIN));

		DateInterval di2 = new DateInterval();
		di2.setDtFrom(Optional.ofNullable(plot)
				.map(Plot::getToDate)
				.map(AbsoluteDate::toLocalDate)
				.map(d -> d.plusDays(1))
				.orElse(LocalDate.MAX));
		di2.setDtTo(LocalDate.MAX);

		return List.of(di1, di2);
	}

	public static List<DateInterval> findFreeIntervals(List<DateInterval> intervals) {
		if (null == intervals || intervals.size() < 2) {
			return new ArrayList<>();
		}

		// To store the set of free interval
		List<DateInterval> free = new ArrayList<>();

		intervals.sort(Comparator.comparing(DateInterval::getDtFrom).thenComparing(DateInterval::getDtTo));

		LocalDate prevTo = intervals.get(0).getDtTo();
		for (int i = 1; i < intervals.size(); i++) {

			LocalDate currFrom = intervals.get(i).getDtFrom();
			LocalDate currTo = intervals.get(i).getDtTo();

			if (prevTo.isBefore(currFrom.minusDays(1))) {
				free.add(new DateInterval(prevTo.plusDays(1), currFrom.minusDays(1)));
			}

			prevTo = currTo.isAfter(prevTo) ? currTo : prevTo;
		}

		return free;
	}

	public static DateInterval cutOnFreeIntervals(DateInterval candidate, List<DateInterval> free) {
		return free.stream()
				.dropWhile(i -> i.getDtTo().isBefore(candidate.getDtFrom()))
				.takeWhile(i -> i.getDtFrom().isBefore(candidate.getDtTo()))
				.min(Comparator.comparingInt(o -> o.getDuration().getDays()))
				.map(i -> {
					LocalDate dtFrom = candidate.getDtFrom().isBefore(i.getDtFrom()) ? i.getDtFrom() : candidate.getDtFrom();
					LocalDate dtTo = candidate.getDtTo().isAfter(i.getDtTo()) ? i.getDtTo() : candidate.getDtTo();

					return new DateInterval(dtFrom, dtTo);
				}).orElse(null);
	}

	public Period getDuration() {
		return dtFrom.until(dtTo);
	}

	public DateInterval plusYears(long yearsToAdd) {
		dtFrom = dtFrom.plusYears(yearsToAdd);
		dtTo = dtTo.plusYears(yearsToAdd);
		return this;
	}
}
