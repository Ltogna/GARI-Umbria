package com.abacogroup.cropplan.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Crop plan prints param")
public class CropPlanPrintParam {
    @Schema(description = "Print Param Name")
    @NotEmpty
    private String paramName;

    @Schema(description = "Print Param Value")
    @NotEmpty
    private String paramValue;
}
