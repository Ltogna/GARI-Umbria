package com.abacogroup.cropplan.dispatch;

import java.time.LocalDateTime;

import com.abacogroup.cropplan.sdk.model.Version;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CropPlanCommitJob
{
	@NotNull
	private String tenant;
	
	@NotNull
	private String businessId;
	
	@NotNull
	private Long cropPlanId;
	
	@NotNull
	private String cropPlanTypeCode;
	
	@NotNull
	private Version version;
	
	@NotNull
	private LocalDateTime versionDate;
	
	private String referenceDate;
	
	@NotNull
	private String username;

	@NotNull
	private CommiType commiType;

	public enum CommiType {
		IN_PUBLISHING, PUBLISHED
	}
}
