package com.abacogroup.cropplan.api;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "The print progress status")
public enum PrintProgress
{
	IN_PROGRESS, COMPLETED
}
