package com.abacogroup.cropplan.db.dao;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.KeyColumn;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.config.ValueColumn;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transaction;
import org.jdbi.v3.sqlobject.transaction.Transactional;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.cropplan.api.ChangedPlot;
import com.abacogroup.cropplan.api.CropPlan;
import com.abacogroup.cropplan.api.CropPlanTimeline.ChangingPoint;
import com.abacogroup.cropplan.api.CropPlanType;
import com.abacogroup.cropplan.api.CropPlanVersionWithBusinessId;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.PlotLifecycle;
import com.abacogroup.cropplan.api.payload.EditPermanentCropForm;
import com.abacogroup.cropplan.api.payload.InsertPermanentCropForm;
import com.abacogroup.cropplan.api.payload.ParcelDataPayload;
import com.abacogroup.cropplan.api.payload.UpdateCropPlanPayload;
import com.abacogroup.cropplan.db.dao.ntt.DeclarationWithPlotCode;
import com.abacogroup.cropplan.db.dao.ntt.ParcelCodeWithPlotId;
import com.abacogroup.cropplan.db.dao.ntt.ParcelIntersectionWithPlotId;
import com.abacogroup.cropplan.db.dao.ntt.PlotCodeWithArea;
import com.abacogroup.cropplan.db.dao.sql.CropPlansRawQueries;
import com.abacogroup.cropplan.db.dao.support.DaoSupportParams;
import com.abacogroup.cropplan.sdk.mapper.VersionColumnMapper;
import com.abacogroup.cropplan.sdk.model.CropPlanVersion;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import com.abacogroup.cropplan.sdk.model.PlotTimeline.PlotArea;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseClass;
import com.abacogroup.jdbi.annotations.CacheDefinition;
import com.abacogroup.jdbi.annotations.Cached;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import jakarta.ws.rs.BadRequestException;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(VersionColumnMapper.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface CropPlansDAO extends CommonPcfDAO, CommonLandUseAdtFldDAO, Transactional<CropPlansDAO> {
	LocalDateTime DT_END_OF_WORLD = LocalDateTime.of(9999, 12, 31, 23, 59);

	@SqlQuery("select ct.code as crop_Plan_Type_Code,"
			+ "           §i18n(:tenantId, 'CRPL_TYPES', 'CODE', ct.code, :language)§ as description,"
			+ "           ct.fl_multiple as multiple, "
			  + " ct.day_from, "
			  + " ct.day_to "
			+ "      from crpl_types ct"
			+ "     where ct.tenant_id = :tenantId"
			+ "       and §current_timestamp§ between ct.dt_insert and ct.dt_delete")
	@RegisterBeanMapper(CropPlanType.class)
	List<CropPlanType> getCropPlanTypes(@Bind("tenantId") String tenantId, @Bind("language") String language);

	@SqlQuery("select ct.code as crop_Plan_Type_Code,"
			+ "           §i18n(:tenantId, 'CRPL_TYPES', 'CODE', ct.code, :language)§ as description,"
			+ "           ct.fl_multiple as multiple, "
			  + " ct.day_from, "
			  + " ct.day_to "
			+ "      from crpl_types ct"
			+ "     where ct.code = :cropPlanTypeCode"
			+ "       and ct.tenant_id = :tenantId"
			+ "       and §current_timestamp§ between ct.dt_insert and ct.dt_delete")
	@RegisterBeanMapper(CropPlanType.class)
	CropPlanType getCropPlanType(@Bind("cropPlanTypeCode") String cropPlanTypeCode,
			@Bind("tenantId") String tenantId, @Bind("language") String language);

	@SqlQuery("select ct.code as crop_Plan_Type_Code,"
			  + "           §i18n(:tenantId, 'CRPL_TYPES', 'CODE', ct.code, :language)§ as description,"
			  + "           ct.fl_multiple as multiple, "
			  + " ct.day_from, "
			  + " ct.day_to "
			  + "      from crpl_types ct "
			  + " join crpl_plans cp on ct.id = cp.type_id "
			  + "     where cp.id = :id"
			  + "       and ct.tenant_id = :tenantId"
			  + "       and §current_timestamp§ between ct.dt_insert and ct.dt_delete")
	@RegisterBeanMapper(CropPlanType.class)
	CropPlanType getCropPlanTypeByCropPlanId(@Bind("id") Long cropPlanId,
			@Bind("tenantId") String tenantId, @Bind("language") String language);

	@SqlQuery("select t.cropPlanId, t.cropPlanTypeCode, t.cropPlanTypeDescription, t.description"
			+ "      from ("
			+ "              select cp.id as cropPlanId,"
			+ "                     ct.code as cropPlanTypeCode,"
			+ "                     coalesce(§i18n(:tenantId, 'CRPL_TYPES', 'CODE', ct.code, :language)§, ct.code) as cropPlanTypeDescription,"
			+ "                     cp.description"
			+ "                from crpl_plans cp, crpl_types ct"
			+ "               where cp.business_id = :businessId"
			+ "                 and §current_timestamp§ < cp.dt_delete"
			+ "                 and ct.id = cp.type_id"
			+ "                 and ct.tenant_id = :tenantId"
			+ "                 and (ct.code = :type or :type is null)"
			+ "                 and §current_timestamp§ between ct.dt_insert and ct.dt_delete"
			+ "           ) t"
			+ "     where (:search is null or upper(cropPlanTypeCode) like '%'||upper(:search)||'%' or upper(cropPlanTypeDescription) like '%'||upper(:search)||'%' or upper(description) like '%'||upper(:search)||'%')"
			+ "  order by cropPlanTypeDescription, description, cropPlanId")
	@RegisterBeanMapper(CropPlan.class)
	ResultIterator<CropPlan> getCropPlansInternal(@Bind("businessId") String businessId,
			@Bind("type") String cropPlanTypeCode, @Bind("search") String search,
			@Bind("tenantId") String tenantId, @Bind("language") String language);

	@SqlQuery("select count(*) "
			+ "      from crpl_plans cp, crpl_types ct"
			+ "     where cp.business_id = :businessId"
			+ "       and §current_timestamp§ < cp.dt_delete"
			+ "       and ct.id = cp.type_id"
			+ "       and ct.tenant_id = :tenantId"
			+ "       and (ct.code = :type or :type is null)"
			+ "       and §current_timestamp§ between ct.dt_insert and ct.dt_delete")
	Long countCropPlans(@Bind("businessId") String businessId,
			@Bind("type") String cropPlanTypeCode, @Bind("tenantId") String tenantId);

	// the query is filterind using current_timestamp but caching works even because only 3 static fields are read from the DB
	@Cached
	@CacheDefinition(maxWeight = 1000, expireAfterWriteMinutes = 60)
	@SqlQuery("select cp.id as cropPlanId, ct.code as cropPlanTypeCode, cp.description "
			+ "      from crpl_plans cp, crpl_types ct"
			+ "     where cp.id = :id"
			+ "       and cp.business_id = :businessId"
			+ "       and ct.id = cp.type_id"
			+ "       and ct.tenant_id = :tenantId"
			+ "       and §current_timestamp§ between ct.dt_insert and ct.dt_delete")
	@RegisterBeanMapper(CropPlan.class)
	CropPlan getCropPlanInternal(@Bind("businessId") String businessId,
			@Bind("id") Long cropPlanId, @Bind("tenantId") String tenantId);

	@SqlQuery("select cp.business_id"
			+ "		     from crpl_plans cp"
			+ "     	where cp.id = :cropPlanId"
			+ "           and §current_timestamp§ between cp.dt_insert and cp.dt_delete")
	Long getCropPlanBusinessId(@Bind("cropPlanId") Long cropPlanId);

	@SqlQuery(CropPlansRawQueries.GET_INTERSECTING_CROP_GEOMETRIES_WITH_CONSUMER)
	void getIntersectingCropGeometriesWithConsumer(
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("typeId") Long typeId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("srs") String srs,
			@Bind("pointInTime") AbsoluteDate pointInTime,
			@Bind("intersectingArea") Long intersectingArea,
			@Bind("areaOfInterest") Geometry areaOfInterest,
			Consumer<Geometry> consumer);

	@SqlQuery("SELECT DISTINCT cp.id AS planId" + 
			"   FROM CRPL_PLANS cp, crpl_plots cpl, crpl_plot_data cpd" + 
			"  WHERE §current_timestamp§ BETWEEN cp.dt_insert AND cp.dt_delete" + 
			"    AND cp.type_id = (select ct.id from crpl_types ct where §current_timestamp§ between ct.dt_insert and ct.dt_delete and ct.tenant_id = :tenantId AND ct.CODE = :cropPlanType)" + 
			"    AND cp.business_id <> :excludedBusinessId" + 
			"    AND cpl.plan_id = cp.id" + 
			"    AND cpl.domain_zone_id = :domainZoneId" + 
			"    AND cpd.plan_id = cpl.plan_id" + 
			"    AND cpd.plot_code = cpl.plot_code" +
			"    AND §geom_have_interactions(cpd.geom, :geom)§" + 
			"    AND cpd.FL_VERSIONED = 1" +
			"    AND :pointInTime BETWEEN cpd.day_from AND cpd.day_to")
	List<Long> findOtherBusinessesCropPlanIds(
			@Bind("cropPlanType") String cropPlanType,
			@Bind("tenantId") String tenantId,
			@Bind("excludedBusinessId") String excludedBusinessId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("geom") Geometry geom,
			@Bind("pointInTime") AbsoluteDate pointInTime);

	@SqlQuery(CropPlansRawQueries.FIND_LATEST_VERSIONS_BY_PLAN_IDS)
	@RegisterBeanMapper(CropPlanVersionWithBusinessId.class)
	List<CropPlanVersionWithBusinessId> findLatestVersionsByPlanIds(
			@BindList("plan_ids") List<Long> planIds,
			@Bind("excludedBusinessId") String excludedBusinessId,
			@Bind("referenceDt") AbsoluteDate referenceDt,
			@Bind("cropPlanType") String cropPlanType,
			@Bind("tenantId") String tenantId);

	@SqlQuery(CropPlansRawQueries.GET_ALL_VERSIONS)
	@RegisterBeanMapper(CropPlanVersion.class)
	ResultIterator<CropPlanVersion> getAllVersions(@Bind("businessId") String businessId,
			@Bind("cropPlanId") Long cropPlanId, @Bind("tenantId") String tenantId,
			@Bind("includeInPublishing") Integer includeInPublishing,
			@Bind("referenceDate") AbsoluteDate referenceDate);

	@SqlQuery("select cp.id as cropPlanId,"
			+ "       cv.version_dt as version,"
			+ "       cv.version_dt as versionDate,"
			+ "       cv.reference_dt as versionReferenceDate,"
			+ "       cv.message as message,"
			+ "       ct.code as cropPlanTypeCode,"
			+ "       cv.user_id as userId,"
			+ "       (case when cv.fl_published = 1 then 1 else 0 end) as flPublished"
			+ "  from crpl_types ct, crpl_plans cp, crpl_versions cv"
			+ " where ct.tenant_id = :tenantId"
			+ "   and §current_timestamp§ between ct.dt_insert and ct.dt_delete"
			+ "   and cp.type_id = ct.id"
			+ "   and cp.business_id = :businessId"
			+ "   and cp.id = :cropPlanId"
			+ "   and cv.plan_id = cp.id"
			+ "   and cv.fl_published = 1"
			+ "   and cv.version_dt = (select min(cv1.version_dt) from crpl_versions cv1 where cv1.plan_id = cv.plan_id and cv1.fl_published = 1)")
	@RegisterBeanMapper(CropPlanVersion.class)
	CropPlanVersion getFirstVersion(@Bind("businessId") String businessId,
			@Bind("cropPlanId") Long cropPlanId, @Bind("tenantId") String tenantId);

	@SqlQuery("select cv.plan_id, max(cv.version_dt) as version_dt"
			+ "      from crpl_versions cv"
			+ "     where cv.plan_id in (<ids>)"
			+ "  group by cv.plan_id")
	@KeyColumn("plan_id")
	@ValueColumn("version_dt")
	Map<Long, LocalDateTime> getLastVersions(@BindList("ids") List<Long> ids);

	@Cached
	@CacheDefinition(maxWeight = 1000, expireAfterWriteMinutes = 30)
	@SqlQuery("select fl_not_managed from crpl_plans where id = :id")
	Boolean isCropPlanNotManaged(@Bind("id") Long id);

	@SqlQuery(CropPlansRawQueries.IS_CROP_PLAN_CHANGES_PENDING)
	Boolean isCropPlanChangesPending(@Bind("id") Long id, @Bind("versionDt") LocalDateTime versionDt);

	@SqlQuery("§select_nextval(crpl_plans_seq)§")
	Long getCropPlanSeq();

	@SqlUpdate("insert into crpl_plans (id, type_id, business_id, description, dt_insert, dt_delete, user_id_insert, fl_not_managed) "
			+ "      values (:cropPlanId, (select id from crpl_types where code = :cropPlanTypeCode and tenant_id = :tenantId and §current_timestamp§ between dt_insert and dt_delete), :businessId, :description, §current_timestamp§, TO_DATE('99991231','YYYYMMDD'), :userId, :flNotManaged)")
	void insertCropPlan(
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("businessId") String businessId,
			@Bind("userId") String userId,
			@Bind("cropPlanTypeCode") String cropPlanTypeCode,
			@Bind("description") String description,
			@Bind("flNotManaged") Integer flNotManaged,
			@Bind("tenantId") String tenantId);

	@SqlUpdate("update crpl_plans"
			+ "        set description = :cropPlanPayload.description"
			+ "      where id = :cropPlanId"
			+ "        and §current_timestamp§ between dt_insert and dt_delete")
	void updateCropPlan(@Bind("cropPlanId") Long cropPlanId,
			@BindBean("cropPlanPayload") UpdateCropPlanPayload cropPlanPayload);

	@SqlUpdate("update crpl_plans"
			+ "        set dt_delete = :deleteDt,"
			+ "            user_id_delete = :userId"
			+ "      where id = :cropPlanId"
			+ "        and §current_timestamp§ between dt_insert and dt_delete")
	void deleteCropPlan(@Bind("cropPlanId") Long cropPlanId,
			@Bind("deleteDt") LocalDateTime deleteDt, @Bind("userId") String userId);

	@SqlUpdate("update crpl_plot_names set fl_versioned = 1 where plan_id = :cropPlanId and :versionDt between dt_insert and dt_delete and fl_versioned = 0")
	void markPlotNamesVersionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("update crpl_parcel_data set fl_versioned = 1 where plan_id = :cropPlanId and :versionDt between dt_insert and dt_delete and fl_versioned = 0")
	void markParcelDataVersionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("update crpl_plot_data set fl_versioned = 1 where plan_id = :cropPlanId and :versionDt between dt_insert and dt_delete and fl_versioned = 0")
	void markPlotDataVersionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("update crpl_declarations set fl_versioned = 1 where plan_id = :cropPlanId and :versionDt between dt_insert and dt_delete and fl_versioned = 0")
	void markDeclarationsVersionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("update crpl_perm_crop_forms set fl_versioned = 1 where plan_id = :cropPlanId and :versionDt between dt_insert and dt_delete and fl_versioned = 0")
	void markPermanentCropFormsVersionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("update crpl_decl_pesticides set fl_versioned = 1 where plan_id = :cropPlanId and :versionDt between dt_insert and dt_delete and fl_versioned = 0")
	void markDeclPesticidesVersionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("update crpl_decl_pests set fl_versioned = 1 where plan_id = :cropPlanId and :versionDt between dt_insert and dt_delete and fl_versioned = 0")
	void markDeclPestsVersionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("update crpl_decl_addit_fields set fl_versioned = 1 where plan_id = :cropPlanId and :versionDt between dt_insert and dt_delete and fl_versioned = 0")
	void markDeclAdditFieldsVersionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("update crpl_anomalies set fl_versioned = 1 where plan_id = :cropPlanId and :versionDt between dt_insert and dt_delete and fl_versioned = 0")
	void markAnomaliesVersionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("delete from crpl_plot_names where plan_id = :cropPlanId and :versionDt > dt_delete and fl_versioned = 0")
	void cleanPlotNamesUnversionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("delete from crpl_parcel_data where plan_id = :cropPlanId and :versionDt > dt_delete and fl_versioned = 0")
	void cleanParcelDataUnversionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("delete from crpl_plot_data where plan_id = :cropPlanId and :versionDt > dt_delete and fl_versioned = 0")
	void cleanPlotDataUnversionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("delete from crpl_perm_crop_forms where plan_id = :cropPlanId and :versionDt > dt_delete and fl_versioned = 0")
	void cleanPermanentCropFormsUnversionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("delete from crpl_decl_pesticides where plan_id = :cropPlanId and :versionDt > dt_delete and fl_versioned = 0")
	void cleanDeclPesticidesUnversionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("delete from crpl_decl_pests where plan_id = :cropPlanId and :versionDt > dt_delete and fl_versioned = 0")
	void cleanDeclPestsUnversionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("delete from crpl_decl_addit_fields where plan_id = :cropPlanId and :versionDt > dt_delete and fl_versioned = 0")
	void cleanDeclAdditFieldsUnversionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("delete from crpl_anomalies where plan_id = :cropPlanId and :versionDt > dt_delete and fl_versioned = 0")
	void cleanAnomaliesUnversionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("delete from crpl_declarations where plan_id = :cropPlanId and :versionDt > dt_delete and fl_versioned = 0")
	void cleanDeclarationsUnversionedInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("insert into crpl_versions (plan_id, version_dt, reference_dt, message, user_id, fl_published) values (:cropPlanId, :versionDt, :pointInTime, :message, :userId, 0)")
	void insertVersionInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTime") AbsoluteDate pointInTime, @Bind("message") String message, @Bind("userId") String userId);

	@SqlUpdate("update crpl_versions set fl_published = 1 where plan_id = :cropPlanId and version_dt = :versionDt")
	void updateVersionToPublished(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("delete from crpl_versions where plan_id = :cropPlanId and version_dt = :versionDt")
	void deleteVersion(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlQuery("select sum(cpd.area_sqm * (coalesce(cd.area_perc, 0) / 100)) as areaperc" +
			"    from crpl_plot_data cpd, crpl_declarations cd, crpl_plots cp" +
			"   where cpd.plan_id = :cropPlanId" +
			"     and :versionDt between cpd.dt_insert and cpd.dt_delete" +
			"     and :pointInTime between cpd.day_from and cpd.day_to" +
			"     and cpd.plan_id = cd.plan_id" +
			"     and cpd.plot_code = cd.plot_code" +
			"     and :versionDt between cd.dt_insert and cd.dt_delete" +
			"     and :pointInTime between cd.day_from and cd.day_to" +
			"     and cp.plan_id = cpd.plan_id" +
			"     and cp.plot_code = cpd.plot_code" +
			"     and (:domainZoneId is null or cp.domain_zone_id = :domainZoneId)")
	Long getDeclaredArea(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTime") AbsoluteDate pointInTime, @Bind("domainZoneId") String domainZoneId);

	@SqlQuery("select sum(data.area_sqm) as totalAreaSqm "
			+ "  from crpl_plot_data data, crpl_plots cp"
			+ " where data.plan_id = :cropPlanId "
			+ "   and :versionDt between data.dt_insert and data.dt_delete"
			+ "   and :pointInTime between data.day_from and data.day_to"
			+ "   and cp.plan_id = data.plan_id"
			+ "   and cp.plot_code = data.plot_code"
			+ "   and (:domainZoneId is null or cp.domain_zone_id = :domainZoneId)")
	Integer getTotalPlotsArea(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTime") AbsoluteDate pointInTime, @Bind("domainZoneId") String domainZoneId);

	@SqlQuery("SELECT ct.ID	\n"
			+ "  FROM CRPL_TYPES ct	\n"
			+ " WHERE ct.CODE = :type \n"
			+ "   AND ct.TENANT_ID = :tenantId"
			+ "   AND §current_timestamp§ BETWEEN ct.DT_INSERT AND ct.DT_DELETE")
	Long getTypeId(
			@Bind("type") String cropPlanTypeCode,
			@Bind("tenantId") String tenantId);

	@SqlQuery("select §aggr_mbr(cpd.geom)§ as geom"
			+ "      from crpl_plots cp, crpl_plot_data cpd"
			+ "     where cp.plan_id = :cropPlanId"
			+ "       and cp.domain_zone_id = :domainZoneId"
			+ "       and cpd.plan_id = cp.plan_id"
			+ "       and cpd.plot_code = cp.plot_code"
			+ "       and :versionDt between cpd.dt_insert and cpd.dt_delete"
			+ "       and :pointInTime between cpd.day_from and cpd.day_to")
	Geometry getPlotsDomainMBR(@Bind("cropPlanId") Long cropPlanId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTime") AbsoluteDate pointInTime);

	@SqlQuery("select distinct cp.domain_zone_id"
			+ "      from crpl_plots cp, crpl_plot_data cpd"
			+ "     where cp.plan_id = :cropPlanId"
			+ "       and cpd.plan_id = cp.plan_id"
			+ "       and cpd.plot_code = cp.plot_code"
			+ "       and :versionDt between cpd.dt_insert and cpd.dt_delete"
			+ "       and :pointInTime between cpd.day_from and cpd.day_to"
			+ "  order by cp.domain_zone_id")
	List<String> getPlotsDomainZoneIds(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTime") AbsoluteDate pointInTime);

	@SqlQuery("select cpd.id as plotId,"
			+ "           cpd.plot_code as plotCode,"
			+ "           cp.domain_zone_id as domainZoneId,"
			+ "           (select cpn.description from crpl_plot_names cpn where cpn.plan_id = cp.plan_id and cpn.plot_code = cp.plot_code and :versionDt between cpn.dt_insert and cpn.dt_delete) as description,"
			+ "           (select cpn.notes from crpl_plot_names cpn where cpn.plan_id = cp.plan_id and cpn.plot_code = cp.plot_code and :versionDt between cpn.dt_insert and cpn.dt_delete) as notes,"
			+ "           cpd.area_sqm as areaSqm,"
			+ "           cpd.geom as geom,"
			+ "           cpd.srs as srs,"
			+ "           cpd.day_from as fromDate,"
			+ "           cpd.day_to as toDate,"
			+ "           (select min(cpd1.day_from) from crpl_plot_data cpd1 where cpd1.PLAN_ID = cpd.PLAN_ID AND cpd1.PLOT_CODE = cpd.PLOT_CODE AND :versionDt between cpd1.dt_insert and cpd1.dt_delete) as fullRangeFromDate,"
			+ "           (select max(cpd1.day_to) from crpl_plot_data cpd1 where cpd1.PLAN_ID = cpd.PLAN_ID AND cpd1.PLOT_CODE = cpd.PLOT_CODE AND :versionDt between cpd1.dt_insert and cpd1.dt_delete) as fullRangeToDate"
			+ "      from crpl_plots cp, crpl_plot_data cpd"
			+ "     where cp.plan_id = :cropPlanId"
			+ "       and (:domainZoneId is null or cp.domain_zone_id = :domainZoneId)"
			+ "       and cpd.plan_id = cp.plan_id"
			+ "       and cpd.plot_code = cp.plot_code"
			+ "       and :versionDt between cpd.dt_insert and cpd.dt_delete"
			+ "       and :pointInTimeFrom <= cpd.day_to"
			+ "       and :pointInTimeTo >= cpd.day_from"
			+ "       and (:plotCode is null or cpd.plot_code = :plotCode)"
			+ "       and (:parcelCodeStartsWith is null or cpd.id in ("
			+ "              select cpdp.plot_data_id"
			+ "                from crpl_plot_data_parcels cpdp"
			+ "               where cpdp.parcel_code like :parcelCodeStartsWith || '%'"
			+ "           ))"
			+ "       and (:subdomainZoneId is null or EXISTS ( "
			+ "              SELECT 1 FROM crpl_subdomain_zone sdz "
			+ "              WHERE sdz.id = :subdomainZoneId "
			+ "              AND §geom_have_interactions(cpd.geom, sdz.geom)§ "
			+ "           )) "
			+ "  order by cpd.plot_code, cpd.id")
	@RegisterBeanMapper(Plot.class)
	ResultIterator<Plot> getPlotsInternal(@Bind("cropPlanId") Long cropPlanId,
			@Bind("domainZoneId") String domainZoneId, @Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom, @Bind("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@Bind("plotCode") String plotCode, @Bind("parcelCodeStartsWith") String parcelCodeStartsWith,
			@Bind("subdomainZoneId") Long subdomainZoneId);

	@SqlQuery("select cpd.geom as geom"
			+ "  from crpl_plots cp, crpl_plot_data cpd"
			+ " where cp.plan_id = :cropPlanId"
			+ "   and (:domainZoneId is null or cp.domain_zone_id = :domainZoneId)"
			+ "   and (:srs is null or cpd.srs = :srs)"
			+ "   and cpd.plan_id = cp.plan_id"
			+ "   and cpd.plot_code = cp.plot_code"
			+ "   and :versionDt between cpd.dt_insert and cpd.dt_delete"
			+ "   and :pointInTime between cpd.day_from and cpd.day_to"
			+ "   and (:declStartWith is null or exists (select 1 from crpl_declarations cd where cd.plan_id = cpd.plan_id and cd.plot_code = cpd.plot_code and :versionDt between cd.dt_insert and cd.dt_delete and :pointInTime between cd.day_from and cd.day_to and cd.land_use_code like :declStartWith || '%'))"
			+ "   and §geom_have_interactions(cpd.geom, :areaOfInterest)§"
			+ " order by cpd.plot_code, cpd.id")
	void getPlotsFilteredByDeclStartWithWithConsumer(
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("srs") String srs,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTime") AbsoluteDate pointInTime,
			@Bind("declStartWith") String declStartWith,
			@Bind("areaOfInterest") Geometry areaOfInterest,
			Consumer<Geometry> consumer);

	@SqlQuery("select DISTINCT cpd.srs "
			+ "  from crpl_plots cp, crpl_plot_data cpd "
			+ " where cp.plan_id = :cropPlanId "
			+ "   and cp.domain_zone_id = :domainZoneId "
			+ "   and cpd.plan_id = cp.plan_id "
			+ "   and cpd.plot_code = cp.plot_code "
			+ "   and :versionDt between cpd.dt_insert and cpd.dt_delete "
			+ "   and :pointInTime between cpd.day_from and cpd.day_to")
	List<String> getDomainZoneSrs(@Bind("cropPlanId") Long cropPlanId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTime") AbsoluteDate pointInTime);

	@SqlQuery("select count(cpd.id) "
			+ "      from crpl_plots cp, crpl_plot_data cpd"
			+ "     where cp.plan_id = :cropPlanId"
			+ "       and (:domainZoneId is null or cp.domain_zone_id = :domainZoneId)"
			+ "       and cpd.plan_id = cp.plan_id"
			+ "       and cpd.plot_code = cp.plot_code"
			+ "       and :versionDt between cpd.dt_insert and cpd.dt_delete"
			+ "       and :pointInTime between cpd.day_from and cpd.day_to")
	Integer countPlotsInternalWithoutPlotCode(@Bind("cropPlanId") Long cropPlanId,
			@Bind("domainZoneId") String domainZoneId, @Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTime") AbsoluteDate pointInTime);

	@SqlQuery("select cpd.id as plotId,"
			+ "           cpd.plot_code as plotCode,"
			+ "           cp.domain_zone_id as domainZoneId,"
			+ "           (select cpn.description from crpl_plot_names cpn where cpn.plan_id = cp.plan_id and cpn.plot_code = cp.plot_code and :versionDt between cpn.dt_insert and cpn.dt_delete) as description,"
			+ "           (select cpn.notes from crpl_plot_names cpn where cpn.plan_id = cp.plan_id and cpn.plot_code = cp.plot_code and :versionDt between cpn.dt_insert and cpn.dt_delete) as notes,"
			+ "           cpd.area_sqm as areaSqm,"
			+ "           cpd.geom as geom,"
			+ "           cpd.srs as srs,"
			+ "           cpd.day_from as fromDate,"
			+ "           cpd.day_to as toDate,"
			+ "           (select min(cpd1.day_from) from crpl_plot_data cpd1 where cpd1.PLAN_ID = cpd.PLAN_ID AND cpd1.PLOT_CODE = cpd.PLOT_CODE AND :versionDt between cpd1.dt_insert and cpd1.dt_delete) as fullRangeFromDate,"
			+ "           (select max(cpd1.day_to) from crpl_plot_data cpd1 where cpd1.PLAN_ID = cpd.PLAN_ID AND cpd1.PLOT_CODE = cpd.PLOT_CODE AND :versionDt between cpd1.dt_insert and cpd1.dt_delete) as fullRangeToDate"
			+ "      from crpl_plots cp, crpl_plot_data cpd"
			+ "     where cp.plan_id = :cropPlanId"
			+ "       and (:domainZoneId is null or cp.domain_zone_id = :domainZoneId)"
			+ "       and (:srs is null or cpd.srs = :srs)"
			+ "       and cpd.plan_id = cp.plan_id"
			+ "       and cpd.plot_code = cp.plot_code"
			+ "       and :versionDt between cpd.dt_insert and cpd.dt_delete"
			+ "       and :pointInTimeFrom <= cpd.day_to"
			+ "       and :pointInTimeTo >= cpd.day_from"
			+ "       and (:plotCode is null or cpd.plot_code = :plotCode)"
			+ "       and §geom_have_interactions(cpd.geom, :areaOfInterest)§"
			+ "  order by cpd.plot_code, cpd.id")
	@RegisterBeanMapper(Plot.class)
	void getPlotsInternalWithConsumer(
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("srs") String srs,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
			@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@Bind("plotCode") String plotCode,
			@Bind("areaOfInterest") Geometry areaOfInterest,
			Consumer<Plot> consumer);

	@SqlQuery(CropPlansRawQueries.FIND_PLOTS_BY_GEOM_INTERSECTS)
	@RegisterBeanMapper(Plot.class)
	ResultIterator<Plot> findPlotsByGeomIntersects(
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("geom") Geometry geometry,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
			@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo);

	@SqlQuery("select count(cpd.id) "
			+ "      from crpl_plots cp, crpl_plot_data cpd"
			+ "     where cp.plan_id = :cropPlanId "
			+ "       and cpd.plan_id = cp.plan_id"
			+ "       and cpd.plot_code = cp.plot_code"
			+ "       and :versionDt between cpd.dt_insert and cpd.dt_delete"
			+ "       and :pointInTimeFrom <= cpd.day_to"
			+ "       and :pointInTimeTo >= cpd.day_from"
			+ "       and (:domainZoneId is null or cp.domain_zone_id = :domainZoneId) "
			+ "       and §geom_have_interactions(cpd.geom, :geom)§ ")
	Integer countPlotsByGeomIntersects(
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("geom") Geometry geometry,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
			@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo);

	@SqlQuery(CropPlansRawQueries.FIND_PLOTS_WITH_NO_DECLS_IN_RANGE)
	@RegisterBeanMapper(Plot.class)
	ResultIterator<Plot> findPlotsWithNoDeclsInRange(
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
			@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo);

	@SqlQuery(CropPlansRawQueries.GET_PLOTS_INFO_BY_LAND_COVER_CODE)
	@RegisterBeanMapper(Plot.class)
	List<Plot> getPlotsInfoByLandCoverCode(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
			@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@BindList("landCoverCodes") List<String> landCoverCodes);

	@SqlQuery("select cpd.plot_code, min(cpd.day_from) as minFromDate, max(cpd.day_to) as maxToDate"
			+ "      from crpl_plots cp, crpl_plot_data cpd"
			+ "     where cp.plan_id = :cropPlanId"
			+ "       and cp.domain_zone_id = :domainZoneId"
			+ "       and cpd.plan_id = cp.plan_id"
			+ "       and cpd.plot_code = cp.plot_code"
			+ "       and :versionDt between cpd.dt_insert and cpd.dt_delete"
			+ "       and cpd.plot_code = :plotCode"
			+ "  group by cpd.plot_code")
	@RegisterBeanMapper(PlotLifecycle.class)
	PlotLifecycle getPlotLifecycle(@Bind("cropPlanId") Long cropPlanId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("plotCode") String plotCode);

	@SqlQuery("select cpd.plot_code as plotCode,"
			+ "           cpd.area_sqm as areaSqm"
			+ "      from crpl_plot_data cpd"
			+ "     where cpd.plan_id = :cropPlanId"
			+ "       and :versionDt between cpd.dt_insert and cpd.dt_delete"
			+ "       and :pointInTime between cpd.day_from and cpd.day_to"
			+ "       and cpd.plot_code in (<plotCodes>)")
	@RegisterBeanMapper(PlotCodeWithArea.class)
	List<PlotCodeWithArea> getPlotCodesWithAreas(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt, @Bind("pointInTime") AbsoluteDate pointInTime,
			@BindList("plotCodes") List<String> plotCodes);

	@SqlQuery("select d.plot_code as plotCode,"
			+ "           d.id as declId,"
			+ "           d.decl_code as declCode,"
			+ "           d.land_use_code as landuse_code,"
			+ "           d.area_perc as areaPerc,"
			+ "           d.day_from as fromDate,"
			+ "           d.day_from_precision as fromDatePrecision,"
			+ "           d.day_to as toDate"
			+ "      from crpl_declarations d join crpl_plots p "
			+ "      on d.plot_code = p.plot_code and d.plan_id = p.plan_id "
			+ "     where p.plan_id = :cropPlanId"
			+ "       and d.land_use_code = :landUseCode"
			+ "       and p.domain_zone_id = :domainZoneId"
			+ "   and :pointInTimeFrom <= d.day_to \n"
			+ "   and :pointInTimeTo >= d.day_from \n"
			+ "       and :versionDt between d.dt_insert and d.dt_delete ")
	@RegisterBeanMapper(DeclarationWithPlotCode.class)
	@RegisterBeanMapper(LandUse.class)
	List<DeclarationWithPlotCode> findDeclarationsByLandUseCodeAndDomainZoneId(
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
			@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@Bind("landUseCode") String landUseCode,
			@Bind("domainZoneId") String domainZoneId);

	/*
	 * @SqlQuery("select plot_code" + "  from crpl_declarations" + " where plan_id = :cropPlanId" + "   and :versionDt between dt_insert and dt_delete" +
	 * "   and decl_code = :declCode")
	 * 
	 * @RegisterBeanMapper(Declaration.class)
	 * 
	 * @RegisterBeanMapper(LandUse.class) String getPlotCodeByDeclCode(@Bind("cropPlanId") Long cropPlanId,
	 * 
	 * @Bind("declCode") String declCode, @Bind("versionDt") LocalDateTime versionDt);
	 */

	@SqlQuery("select distinct pp.parcel_code \n"
			+ "  from crpl_plot_data_parcels pp, crpl_plot_data dd \n"
			+ " where dd.plan_id = :cropPlanId \n"
			+ "   and dd.plot_code = :plotCode \n"
			+ "   and :versionDt between dd.dt_insert and dd.dt_delete \n"
			+ "   and :pointInTime between dd.day_to and dd.day_to \n"
			+ "   and pp.plot_data_id = dd.id")
	List<String> getIntersectedParcelCodesByPlotCode(
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("plotCode") String plotCode,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTime") AbsoluteDate pointInTime);

	@SqlQuery("select cpdp.plot_data_id as plotId,"
			+ "       cpdp.parcel_code as parcelCode"
			+ "  from crpl_plot_data_parcels cpdp"
			+ " where cpdp.plot_data_id in (<plotIds>)"
			+ " order by cpdp.plot_data_id")
	@RegisterBeanMapper(ParcelCodeWithPlotId.class)
	List<ParcelCodeWithPlotId> getPlotsParcelCodesInternal(@BindList("plotIds") List<Long> plotIds,
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlQuery("select cpdp.plot_data_id as plotId,"
			+ "       cpdp.parcel_code as code,"
			+ "       cpdp.area_sqm as areaSqm,"
			+ "       cpdp.land_cover_code as landcoverCode,"
			+ "       (select cpad.notes from crpl_parcel_data cpad where cpad.plan_id = :cropPlanId and cpad.parcel_code = cpdp.parcel_code and :versionDt between cpad.dt_insert and cpad.dt_delete) as notes"
			+ "  from crpl_plot_data_parcels cpdp"
			+ " where cpdp.plot_data_id in (<plotIds>)"
			+ " order by cpdp.plot_data_id")
	@RegisterBeanMapper(ParcelIntersectionWithPlotId.class)
	List<ParcelIntersectionWithPlotId> getPlotsParcelsInternal(@BindList("plotIds") List<Long> plotIds,
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlQuery("select pp.plot_data_id as plotId,"
			+ "       pp.parcel_code as code,"
			+ "       pp.area_sqm as areaSqm,"
			+ "       pp.land_cover_code as landcoverCode,"
			+ "       (select cpad.notes from crpl_parcel_data cpad where cpad.plan_id = :cropPlanId and cpad.parcel_code = pp.parcel_code and :versionDt between cpad.dt_insert and cpad.dt_delete) as notes"
			+ "  from crpl_plot_data_parcels pp \n"
			+ " inner join crpl_plot_data dd on pp.plot_data_id = dd.id \n"
			+ " where dd.plan_id = :cropPlanId \n"
			+ "   and dd.plot_code = :plotCode \n"
			+ "   and :versionDt between dd.dt_insert and dd.dt_delete \n"
			+ "   and :pointInTimeFrom <= dd.day_to \n"
			+ "   and :pointInTimeTo >= dd.day_from \n")
	@RegisterBeanMapper(ParcelIntersectionWithPlotId.class)
	List<ParcelIntersectionWithPlotId> findPlotsParcelsInternalByPlotCode(
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("plotCode") String plotCode,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
			@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo);

	@SqlQuery("\n"
			+ "select distinct dd.plot_code \n"
			+ "  from crpl_plot_data_parcels pp \n"
			+ " inner join crpl_plot_data dd on pp.plot_data_id = dd.id \n"
			+ " where dd.plan_id = :cropPlanId \n"
			+ "   and parcel_code = :parcelcode \n"
			+ "   and :versionDt between dd.dt_insert and dd.dt_delete \n"
			+ "   and :pointInTimeFrom <= dd.day_to \n"
			+ "   and :pointInTimeTo >= dd.day_from \n")
	List<String> getIntersectedParcelsPlotCodes(
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("parcelcode") String parcelCode,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
			@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo);

	@SqlQuery("\n"
			+ "select distinct pp.land_cover_code \n"
			+ "  from crpl_plot_data_parcels pp \n"
			+ " inner join crpl_plot_data dd on pp.plot_data_id = dd.id \n"
			+ " where dd.plan_id = :cropPlanId \n"
			+ "   and dd.plot_code = :plotCode \n"
			+ "   and :versionDt between dd.dt_insert and dd.dt_delete \n"
			+ "   and :pointInTimeFrom <= dd.day_to \n"
			+ "   and :pointInTimeTo >= dd.day_from \n"
			+ " ")
	List<String> getPlotLandCoverCodes(
			@Bind("plotCode") String plotCode,
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
			@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo);

	@SqlQuery("§select_nextval(crpl_declarations_seq)§")
	Long getDeclarationSeq();

	@SqlUpdate("insert into crpl_declarations (id, decl_code, plan_id, plot_code, day_from, day_from_precision, day_to, land_use_code, area_perc, fl_versioned, user_id_insert, dt_insert, dt_delete, transaction_id)"
			+ "      values (:declId, :declCode, :cropPlanId, :plotCode, :dayFrom, :dayFromPrecision, :dayTo, :landUseCode, :areaPerc, 0, :userId, :insertDt, TO_DATE('99991231','YYYYMMDD'), :transId)")
	void insertDeclarationInternal(@Bind("declId") Long declId, @Bind("declCode") String declCode,
			@Bind("cropPlanId") Long cropPlanId, @Bind("plotCode") String plotCode, @Bind("dayFrom") AbsoluteDate dayFrom,
			@Bind("dayFromPrecision") String dayFromPrecision,
			@Bind("dayTo") AbsoluteDate dayTo, @Bind("landUseCode") String landUseCode, @Bind("areaPerc") Double areaPerc,
			@Bind("userId") String userId, @Bind("insertDt") LocalDateTime insertDt,
			@Bind("transId") LocalDateTime transId);

	@SqlUpdate("update crpl_declarations"
			+ "        set dt_delete = :deleteDt, user_id_delete = :userId, transaction_id = :transId"
			+ "      where decl_code = :declCode"
			+ "        and plan_id = :cropPlanId"
			+ "        and §current_timestamp§ between dt_insert and dt_delete")
	int deleteDeclarationInternal(@Bind("declCode") String declCode, @Bind("cropPlanId") Long cropPlanId,
			@Bind("deleteDt") LocalDateTime deleteDt, @Bind("userId") String userId,
			@Bind("transId") LocalDateTime transId);

	@SqlQuery("select area_sqm as areaSqm, "
			+ "           geom as geom, "
			+ "           day_from as fromDate, "
			+ "           day_to as toDate, "
			+ "           fl_soft_modified as flSoftModified "
			+ "      from crpl_plot_data "
			+ "     where plot_code = :plotCode "
			+ "       and plan_id = :planId "
			+ "       and :versionDt between dt_insert and dt_delete "
			+ "       and (:pointInTimeFrom is null or :pointInTimeFrom <= day_to) "
			+ "       and (:pointInTimeTo is null or :pointInTimeTo >= day_from) "
			+ "     order by day_from, day_to ")
	@RegisterBeanMapper(PlotArea.class)
	List<PlotArea> getPlotAreas(@Bind("plotCode") String plotCode, @Bind("planId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom, @Bind("pointInTimeTo") AbsoluteDate pointInTimeTo);

	@SqlQuery(CropPlansRawQueries.GET_CROP_PLAN_TIME_LINE)
	@RegisterBeanMapper(ChangingPoint.class)
	List<ChangingPoint> getCropPlanTimeline(
			@Bind("planId") Long cropPlanId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
			@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo);

	@SqlQuery("select domain_zone_id from crpl_plots where plan_id = :planId and plot_code = :plotCode")
	String getDomainZoneIdByPlotCode(@Bind("planId") Long cropPlanId, @Bind("plotCode") String plotCode);

	@Transaction
	default void createVersion(Long cropPlanId, AbsoluteDate pointInTime, String message, String userId) {
		LocalDateTime versionDt = getCurrentTimestamp();
		markPlotNamesVersionedInternal(cropPlanId, versionDt);
		markParcelDataVersionedInternal(cropPlanId, versionDt);
		markPlotDataVersionedInternal(cropPlanId, versionDt);
		markDeclarationsVersionedInternal(cropPlanId, versionDt);
		markPermanentCropFormsVersionedInternal(cropPlanId, versionDt);
		markDeclPesticidesVersionedInternal(cropPlanId, versionDt);
		markAnomaliesVersionedInternal(cropPlanId, versionDt);
		markDeclPestsVersionedInternal(cropPlanId, versionDt);
		markDeclAdditFieldsVersionedInternal(cropPlanId, versionDt);

		cleanPlotNamesUnversionedInternal(cropPlanId, versionDt);
		cleanParcelDataUnversionedInternal(cropPlanId, versionDt);
		cleanPlotDataUnversionedInternal(cropPlanId, versionDt);
		cleanDeclarationsUnversionedInternal(cropPlanId, versionDt);
		cleanPermanentCropFormsUnversionedInternal(cropPlanId, versionDt);
		cleanDeclPesticidesUnversionedInternal(cropPlanId, versionDt);
		cleanAnomaliesUnversionedInternal(cropPlanId, versionDt);
		cleanDeclPestsUnversionedInternal(cropPlanId, versionDt);
		cleanDeclAdditFieldsUnversionedInternal(cropPlanId, versionDt);

		insertVersionInternal(cropPlanId, versionDt, pointInTime, message, userId);
	}

	@Transaction
	default Long insertDeclaration(Long cropPlanId, String plotCode, AbsoluteDate dayFrom,
			String dayFromPrecision,
			AbsoluteDate dayTo, String landUseCode, Double areaPerc, List<InsertPermanentCropForm> permanentCropForms,
			List<LandUseAdditionalDataField> fieldsCodes,
			String userId, LocalDateTime insertDt, LocalDateTime transId) {
		var declId = getDeclarationSeq();

		DaoSupportParams daoParm = DaoSupportParams.builder()
				.insertDt(insertDt)
				.deleteDt(DT_END_OF_WORLD)
				.insertUserId(userId)
				.deleteUserId(null)
				.transId(transId)
				.flVersioned(0)
				.cropPlanId(cropPlanId)
				.plotCode(plotCode)
				.declCode(String.valueOf(declId))
				.landUseCode(landUseCode)
				.build();

		insertDeclarationInternal(declId, String.valueOf(declId), cropPlanId, plotCode,
				dayFrom, dayFromPrecision, dayTo, landUseCode, areaPerc, userId, insertDt, transId);

		if (permanentCropForms != null) {
			permanentCropForms.forEach(pcf -> {
				var pcfId = getPermanentCropFormsSeq();
				var formType = pcf.getFormType();
				insertPermanentCropForm(pcfId, String.valueOf(pcfId), formType, cropPlanId, plotCode,
						String.valueOf(declId), userId, insertDt, transId, pcf.getPermanentCropFormData());
			});
		}

		if (fieldsCodes != null) {
			fieldsCodes.forEach(fc -> {
				Long nextId = getDeclAdditFieldsSeq();
				insertDeclAdditFields(daoParm, nextId, fc);
			});
		}

		return declId;
	}

	@Transaction
	default Long updateDeclaration(String declCode, Long cropPlanId, String plotCode, AbsoluteDate dayFrom, String dayFromPrecision,
			AbsoluteDate dayTo, String landUseCode, Double areaPerc,
			List<EditPermanentCropForm> permanentCropForms, List<LandUseAdditionalDataField> fieldsCodes,
			boolean preserveCurrentPermanentCropForms, String userId, LocalDateTime insertDt, LocalDateTime transId) {
		var deleteDt = insertDt.minus(Duration.ofMillis(1));
		var n = deleteDeclarationInternal(declCode, cropPlanId, deleteDt, userId, transId);
		if (n == 0)
			throw new BadRequestException("The declaration was not found");

		DaoSupportParams daoParm = DaoSupportParams.builder()
				.insertDt(insertDt)
				.deleteDt(deleteDt)
				.insertUserId(userId)
				.deleteUserId(userId)
				.transId(transId)
				.flVersioned(0)
				.cropPlanId(cropPlanId)
				.plotCode(plotCode)
				.declCode(declCode)
				.landUseCode(landUseCode)
				.build();

		// First outdate the current state for additional declaration fields
		outdateDeclAdditFieldsInternal(daoParm, null);

		if (!preserveCurrentPermanentCropForms)
			deletePermanentCropFormsInternal(null, declCode, plotCode, cropPlanId, deleteDt, userId, transId);

		// then insert new data
		var declId = getDeclarationSeq();

		// Reset daoParam for insert
		daoParm.setDeleteDt(DT_END_OF_WORLD);
		daoParm.setDeleteUserId(null);

		insertDeclarationInternal(declId, declCode, cropPlanId, plotCode,
				dayFrom, dayFromPrecision, dayTo, landUseCode, areaPerc, userId, insertDt, transId);

		if (permanentCropForms != null) {
			permanentCropForms.forEach(pcf -> {
				var pcfId = getPermanentCropFormsSeq();
				var formCode = pcf.getFormCode();
				if (formCode == null)
					formCode = String.valueOf(pcfId);
				var formType = pcf.getFormType();
				insertPermanentCropForm(pcfId, formCode, formType, cropPlanId, plotCode, declCode, userId, insertDt,
						transId,
						pcf.getPermanentCropFormData());
			});
		}

		// Additional declaration fields codes
		if (fieldsCodes != null) {
			fieldsCodes.forEach(fc -> {
				Long nextId = getDeclAdditFieldsSeq();
				insertDeclAdditFields(daoParm, nextId, fc);
			});
		}

		return declId;
	}

	@Transaction
	default void updateDeclarationFields(String declCode, Long cropPlanId, String plotCode, String landUseCode,
			List<EditPermanentCropForm> permanentCropForms, List<LandUseAdditionalDataField> fieldsCodes,
			String userId, LocalDateTime insertDt, LocalDateTime transId) {
		var deleteDt = insertDt.minus(Duration.ofMillis(1));

		DaoSupportParams daoParm = DaoSupportParams.builder()
				.insertDt(insertDt)
				.deleteDt(deleteDt)
				.insertUserId(userId)
				.deleteUserId(userId)
				.transId(transId)
				.flVersioned(0)
				.cropPlanId(cropPlanId)
				.plotCode(plotCode)
				.declCode(declCode)
				.landUseCode(landUseCode)
				.build();

		// First outdate the current state for additional declaration fields
		if (fieldsCodes != null) {
			fieldsCodes.forEach(fc -> outdateDeclAdditFieldsInternal(daoParm, fc.getFieldCode()));
		}

		if (permanentCropForms != null) {
			for (EditPermanentCropForm permanentCropForm : permanentCropForms) {
				// This is needed, because permanent crop forms can now contain null form codes
				if (permanentCropForm.getFormCode() != null) {
					deletePermanentCropFormsInternal(permanentCropForm.getFormCode(), declCode, plotCode, cropPlanId, deleteDt, userId, transId);
				}
			}
		}

		// Reset daoParam for insert
		daoParm.setDeleteDt(DT_END_OF_WORLD);
		daoParm.setDeleteUserId(null);

		if (permanentCropForms != null) {
			permanentCropForms.forEach(pcf -> {
				var pcfId = getPermanentCropFormsSeq();

				var formCode = pcf.getFormCode();
				if (formCode == null) {
					formCode = String.valueOf(pcfId);
				}

				var formType = pcf.getFormType();

				insertPermanentCropForm(pcfId, formCode, formType, cropPlanId, plotCode, declCode, userId, insertDt,
						transId,
						pcf.getPermanentCropFormData());
			});
		}

		// Additional declaration fields codes
		if (fieldsCodes != null) {
			fieldsCodes.forEach(fc -> {
				Long nextId = getDeclAdditFieldsSeq();
				insertDeclAdditFields(daoParm, nextId, fc);
			});
		}
	}

	@Transaction
	default void deleteDeclaration(String declCode, Long cropPlanId, String plotCode, LocalDateTime deleteDt,
			String userId, LocalDateTime transId) {
		var n = deleteDeclarationInternal(declCode, cropPlanId, deleteDt, userId, transId);
		if (n == 0)
			throw new BadRequestException("The declaration was not found");

		DaoSupportParams daoParm = DaoSupportParams.builder()
				.insertDt(null)
				.deleteDt(deleteDt)
				.insertUserId(userId)
				.deleteUserId(userId)
				.transId(transId)
				.flVersioned(0)
				.cropPlanId(cropPlanId)
				.plotCode(plotCode)
				.declCode(declCode)
				.landUseCode(null)
				.build();

		deletePermanentCropFormsInternal(null, declCode, plotCode, cropPlanId, deleteDt, userId, transId);

		outdateDeclAdditFieldsInternal(daoParm, null);
	}

	@SqlQuery("select cluco.land_use_class_code as landUseClassCode," +
			"             cluco.perc_fixed_to_100 as percFixedTo100," +
			"             cluco.permanent as permanent" +
			"        from crpl_land_use_class_options cluco, crpl_types ct" +
			"       where ct.code = :cropPlanTypeCode" +
			"         and ct.tenant_id = :tenantId" +
			"         and cluco.type_id = ct.id" +
			"         and cluco.land_use_class_code in (<landUseClasses>)")
	@RegisterBeanMapper(LandUseClass.class)
	List<LandUseClass> getLandUseClassOptions(@Bind("tenantId") String tenantId,
			@Bind("cropPlanTypeCode") String cropPlanTypeCode, @BindList("landUseClasses") List<String> landUseClasses);

	@SqlQuery("SELECT "
			+ "  cpd.plot_code AS plotCode, "
			+ "  cpd.geom AS geom, "
			+ "  cpd.srs AS srs, "
			+ "  cp.domain_zone_id AS domainZoneId, "
			+ "  cpn.DESCRIPTION AS plotDescription "
			+ "FROM crpl_plot_data cpd "
			+ "INNER JOIN crpl_plots cp "
			+ "        ON cp.PLOT_CODE = cpd.PLOT_CODE "
			+ "        AND cp.PLAN_ID = cpd.PLAN_ID "
			+ "INNER JOIN CRPL_PLOT_NAMES cpn "
			+ "        ON cp.PLAN_ID = CPN.PLAN_ID "
			+ "        AND cp.PLOT_CODE = cpn.PLOT_CODE "
			+ "WHERE cpd.plan_id = :cropPlanId "
			+ "  and cpd.dt_insert > :versionDt "
			+ "  and cpd.dt_delete >= §current_timestamp§ "
			+ "  AND §current_timestamp§ BETWEEN cpn.dt_insert AND cpn.dt_delete"
			+ "  and cpd.fl_soft_modified = 0")
	@RegisterBeanMapper(ChangedPlot.class)
	ResultIterator<ChangedPlot> getChangedPlots(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlQuery(CropPlansRawQueries.GET_PREVIOUS_VERSION_CHANGED_PLOTS)
	@RegisterBeanMapper(ChangedPlot.class)
	List<ChangedPlot> getPreviousVersionChangedPlots(@Bind("cropPlanId") Long cropPlanId, @BindList("plotCodes") List<String> plotCodes,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlQuery(CropPlansRawQueries.GET_PREVIOUS_VERSIONS_CHANGED_PLOTS_BY_DESCRIPTION)
	@RegisterBeanMapper(ChangedPlot.class)
	List<ChangedPlot> getPreviousVersionChangedPlotsByDescription(@Bind("cropPlanId") Long cropPlanId, @Bind("plotDescription") String plotDescription,
			@Bind("versionDt") LocalDateTime versionDt);

	@SqlQuery("SELECT cflu.land_use_code " +
			"    FROM crpl_favourites_land_uses cflu " +
			"   WHERE cflu.user_id = :userId " +
			"     AND cflu.type_id = (select ct.id from crpl_types ct where ct.code = :cropPlanTypeCode and ct.tenant_id = :tenantId and §current_timestamp§ between dt_insert and dt_delete)")
	List<String> getFavouriteLandUses(@Bind("userId") String userId,
			@Bind("cropPlanTypeCode") String cropPlanTypeCode, @Bind("tenantId") String tenantId);

	@SqlUpdate("INSERT INTO crpl_favourites_land_uses (user_id, type_id, land_use_code) " +
			"   VALUES (:userId, (select ct.id from crpl_types ct where ct.code = :cropPlanTypeCode and ct.tenant_id = :tenantId and §current_timestamp§ between dt_insert and dt_delete), :landUseCode)")
	void addFavouriteLandUseInternal(@Bind("userId") String userId,
			@Bind("cropPlanTypeCode") String cropPlanTypeCode, @Bind("tenantId") String tenantId, @Bind("landUseCode") String landUseCode);

	@SqlUpdate("DELETE FROM crpl_favourites_land_uses cflu " +
			"   WHERE cflu.user_id = :userId " +
			"     AND cflu.type_id = (select ct.id from crpl_types ct where ct.code = :cropPlanTypeCode and ct.tenant_id = :tenantId and §current_timestamp§ between dt_insert and dt_delete) "
			+
			"     AND cflu.land_use_code = :landUseCode")
	void removeFavouriteLandUse(@Bind("userId") String userId,
			@Bind("cropPlanTypeCode") String cropPlanTypeCode, @Bind("tenantId") String tenantId, @Bind("landUseCode") String landUseCode);

	@Transaction
	default void addFavouriteLandUse(String userId, String cropPlanTypeCode, String tenantId, String landUseCode) {
		removeFavouriteLandUse(userId, cropPlanTypeCode, tenantId, landUseCode);
		addFavouriteLandUseInternal(userId, cropPlanTypeCode, tenantId, landUseCode);
	}

	@SqlUpdate("insert into anomalies_acknowledgment(user_id, plan_id, dt_acknowledgment) values(:userId, :cropPlanId, :dtAck)")
	void saveAnomaliesAcknowledgment(@Bind("userId") String userId, @Bind("cropPlanId") Long cropPlanId, @Bind("dtAck") LocalDateTime dtAck);

	@SqlUpdate("insert into crpl_merged_decls (merged_decl_id, source_decl_id, plan_id, plot_code, dt_merge, transaction_id) "
			+ "      values (:merged_decl_id, :source_decl_id, :plan_id, :plot_code, :dt_merge, :transaction_id)")
	void insertMergedDecl(
			@Bind("merged_decl_id") Long mergedDeclId,
			@Bind("source_decl_id") Long sourceDeclId,
			@Bind("plan_id") Long cropPlanId,
			@Bind("plot_code") String plotCode,
			@Bind("dt_merge") LocalDateTime dtMerge,
			@Bind("transaction_id") LocalDateTime transactionId);

	@SqlUpdate("update crpl_plot_data set user_id_delete = :deleteUserId, dt_delete = :deleteDt where plan_id = :cropPlanId and :currentDt between dt_insert and dt_delete")
	void cleanupCropPlan(@Bind("cropPlanId") Long cropPlanId,
			@Bind("deleteUserId") String deleteUserId,
			@Bind("currentDt") LocalDateTime currentDt,
			@Bind("deleteDt") LocalDateTime deleteDt);

	@Transaction
	default void updateParcelData(RuntimeEnvironment env, Long cropPlanId, String parcelCode, ParcelDataPayload payload) {
		LocalDateTime currentDt = getCurrentTimestamp();
		var deleteDt = currentDt.minus(Duration.ofMillis(1));

		updateParcelDataInternal(parcelCode, cropPlanId, env.getUserId(), currentDt, deleteDt);
		insertParcelDataInternal(parcelCode, cropPlanId, payload.getNotes(), env.getUserId(), currentDt, LocalDateTime.of(9999, 12, 31, 0, 0));
	}

	@SqlUpdate("insert into crpl_parcel_data (id, parcel_code, plan_id, notes, user_id_insert, dt_insert, dt_delete)"
			+ "      values (§nextval(crpl_parcel_data_seq)§, :parcelCode, :cropPlanId, :notes, :insertUserId, :insertDt, :deleteDt)")
	void insertParcelDataInternal(@Bind("parcelCode") String parcelCode, @Bind("cropPlanId") Long cropPlanId,
			@Bind("notes") String notes, @Bind("insertUserId") String insertUserId,
			@Bind("insertDt") LocalDateTime insertDt, @Bind("deleteDt") LocalDateTime deleteDt);

	@SqlUpdate("update crpl_parcel_data"
			+ "        set user_id_delete = :deleteUserId,"
			+ "            dt_delete = :deleteDt"
			+ "      where parcel_code = :parcelCode"
			+ "        and plan_id = :cropPlanId"
			+ "        and :insertDt between dt_insert and dt_delete")
	void updateParcelDataInternal(@Bind("parcelCode") String parcelCode, @Bind("cropPlanId") Long cropPlanId,
			@Bind("deleteUserId") String deleteUserId, @Bind("insertDt") LocalDateTime insertDt, @Bind("deleteDt") LocalDateTime deleteDt);

	@SqlQuery("select cpn.plot_code \n"
			+ "  from crpl_plot_names cpn \n"
			+ " where cpn.plan_id = :cropPlanId \n"
			+ "   and cpn.description = :description \n"
			+ "   and :versionDt between cpn.dt_insert and cpn.dt_delete")
	List<String> getPlotCodesByDescription(@Bind("cropPlanId") Long cropPlanId,
			@Bind("description") String description,
			@Bind("versionDt") LocalDateTime versionDt);

}
