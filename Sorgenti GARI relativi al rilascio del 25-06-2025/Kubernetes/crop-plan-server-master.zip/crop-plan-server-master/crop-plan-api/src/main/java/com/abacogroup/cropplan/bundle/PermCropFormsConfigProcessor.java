package com.abacogroup.cropplan.bundle;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.cropplan.bundle.model.PermCropFormsConfigMessage;
import com.abacogroup.cropplan.bundle.model.ValidationGroups.Delete;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;

public class PermCropFormsConfigProcessor implements ConfigMessageProcessor {

	private final ObjectMapper objectMapper;
	private final CropPlanConfigDAO configDAO;

	public PermCropFormsConfigProcessor(CropPlanConfigDAO configDAO)
	{
		this.configDAO = configDAO;
		this.objectMapper = new ObjectMapper();
	}

	@Override
	public String getDomainName()
	{
		return "permCropFormsConfig";
	}

	@Override
	public void onMessage(ConfigDataMessage message)
	{
		String tenantId = message.getTenantId();
		Map<FileOperationEnum, ArrayList<Path>> map = collectFilesByOperation(message);

		map.getOrDefault(FileOperationEnum.DELETE, new ArrayList<>()).forEach(path -> this.removeContent(tenantId, path));
		map.getOrDefault(FileOperationEnum.DEFAULT, new ArrayList<>()).forEach(path -> this.upsertContent(tenantId, path));
	}

	private void upsertContent(String tenantId, Path path) {
		try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory()) {
			Validator validator = validatorFactory.getValidator();

			PermCropFormsConfigMessage message = this.readFile(path);

			this.validateOnUpsert(message, validator, path);

			this.doInsertOrUpdate(tenantId, message);
		}
	}

	private void validateOnUpsert(PermCropFormsConfigMessage entry, Validator validator, Path path) {
		Set<ConstraintViolation<PermCropFormsConfigMessage>> constraintViolations = validator.validate(entry);

		if (!constraintViolations.isEmpty()) {
			ConstraintViolationException constraintViolationException = new ConstraintViolationException(constraintViolations);
			throw new BundleException(
					String.format("message from file '%s' not valid: %s", path, constraintViolationException.getMessage()),
					constraintViolationException);
		}

		if (entry.getValidTo().toLocalDate().isBefore(entry.getValidFrom().toLocalDate())) {
			throw new BundleException(String.format("message from file '%s' not valid: validTo is before validFrom", path));
		}
	}


	private void removeContent(String tenantId, Path path) {
		try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory()) {
			Validator validator = validatorFactory.getValidator();

			PermCropFormsConfigMessage message = this.readFile(path);

			this.validateOnDelete(message, validator, path);

			this.doDelete(tenantId, message);

		}
	}

	private void validateOnDelete(PermCropFormsConfigMessage entry, Validator validator, Path path) {
		Set<ConstraintViolation<PermCropFormsConfigMessage>> constraintViolations = validator.validate(entry, Delete.class);

		if (!constraintViolations.isEmpty()) {
			ConstraintViolationException constraintViolationException = new ConstraintViolationException(constraintViolations);
			throw new BundleException(
					String.format("message from file '%s' not valid: %s", path, constraintViolationException.getMessage()),
					constraintViolationException);
		}
	}


	private void doInsertOrUpdate(String tenantId, PermCropFormsConfigMessage message)
	{
		if (checkIfMessageLandUseCodeAndClassCodesAreNotDefined(message)) {
			return; // TODO error?
		}

		Long typeId = configDAO.getCropPlanTypeId(message.getCropPlanType(), tenantId);
		if (message.getLandUseCodes() != null)
			message.getLandUseCodes().forEach(luc -> {
				configDAO.deletePermCropFormsConfig(message.getFormType(), typeId, luc, null, message.getValidFrom(), message.getValidTo());
				
				var id = configDAO.getPermCropFormsConfigSeq();
				configDAO.insertPermCropFormsConfig(id, message.getFormType(), typeId, luc, null, message.getValidFrom(), message.getValidTo());
				message.getFields().forEach(field -> {
					configDAO.insertPermCropFormsFieldConfig(id, field.getFieldCode(), booleanToInt(field.getMandatory()), booleanToInt(field.getEditable()));
				});
			});
		
		if (message.getLandUseClassCodes() != null)
			message.getLandUseClassCodes().forEach(lucc -> {
				configDAO.deletePermCropFormsConfig(message.getFormType(), typeId, null, lucc, message.getValidFrom(), message.getValidTo());
				
				var id = configDAO.getPermCropFormsConfigSeq();
				configDAO.insertPermCropFormsConfig(id, message.getFormType(), typeId, null, lucc, message.getValidFrom(), message.getValidTo());
				message.getFields().forEach(field -> {
					configDAO.insertPermCropFormsFieldConfig(id, field.getFieldCode(), booleanToInt(field.getMandatory()), booleanToInt(field.getEditable()));
				});
			});
	}

	private int booleanToInt(Boolean flag) {
		return flag ? 1 : 0;
	}

	private boolean checkIfMessageLandUseCodeAndClassCodesAreNotDefined(PermCropFormsConfigMessage message) {
		return message == null || ((message.getLandUseCodes() == null || message.getLandUseCodes().isEmpty())
				&& (message.getLandUseClassCodes() == null || message.getLandUseClassCodes().isEmpty()));
	}

	private void doDelete(String tenantId, PermCropFormsConfigMessage message)
	{
		if (message == null) 
		{
			return;
		}

		Long typeId = configDAO.getCropPlanTypeId(message.getCropPlanType(), tenantId);

		List<LandUsePair> toDelete = new ArrayList<>();
		Optional.ofNullable(message.getLandUseCodes())
				.stream().flatMap(Collection::stream)
				.map(luc -> new LandUsePair(luc, null))
				.forEach(toDelete::add);
		Optional.ofNullable(message.getLandUseClassCodes())
				.stream().flatMap(Collection::stream)
				.map(lucc -> new LandUsePair(null, lucc))
				.forEach(toDelete::add);
		if (toDelete.isEmpty()) {
			// if no LandUseCodes and LandUseClassCodes delete/update all
			toDelete.add(new LandUsePair(null, null));
		}

		if (null == message.getDeleteFrom()) {
			for (LandUsePair landUsePair : toDelete) {
				configDAO.deletePermCropFormsConfig(message.getFormType(), typeId, landUsePair.getLandUseCode(), landUsePair.getLandUseClassCode(),
						message.getValidFrom(), message.getValidTo());
			}
		} else {
			AbsoluteDate newValidTo = AbsoluteDate.of(message.getDeleteFrom().toLocalDate().minusDays(1));

			for (LandUsePair landUsePair : toDelete) {
				configDAO.updatePermCropFormsConfigDates(message.getFormType(), typeId, landUsePair.getLandUseCode(), landUsePair.getLandUseClassCode(),
						message.getValidFrom(), message.getValidTo(), newValidTo);
			}
		}
	}

	private PermCropFormsConfigMessage readFile(Path path) {
		try {
			String json = Files.readString(path);
			return objectMapper.readValue(json, new TypeReference<>() {});
		} catch (IOException e) {
			throw new BundleException(String.format("error reading file %s", path), e);
		}
	}

	private Map<FileOperationEnum, ArrayList<Path>> collectFilesByOperation(ConfigDataMessage message) {
		Function<String, FileOperationEnum> groupingPredicate = x -> {
			if (StringUtils.endsWith(x, ".delete.json")) {
				return FileOperationEnum.DELETE;
			} else {
				return FileOperationEnum.DEFAULT;
			}
		};

		List<Path> paths = message.getConfigFiles();
		return paths.stream()
				.filter(p -> FilenameUtils.isExtension(FilenameUtils.getName(p.getFileName().toString()).toLowerCase(), "json"))
				.sorted()
				.collect(Collectors.groupingBy(x -> groupingPredicate.apply(x.toString()),
						Collectors.toCollection(ArrayList::new)));
	}

	private enum FileOperationEnum {
		DELETE,
		DEFAULT,
	}

	@Getter
	@AllArgsConstructor
	private static class LandUsePair {
		private String landUseCode;
		private String landUseClassCode;
	}
}
