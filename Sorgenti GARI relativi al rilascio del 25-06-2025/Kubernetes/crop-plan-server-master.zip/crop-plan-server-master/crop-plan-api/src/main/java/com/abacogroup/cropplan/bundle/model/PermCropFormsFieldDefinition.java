package com.abacogroup.cropplan.bundle.model;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PermCropFormsFieldDefinition
{
	@NotBlank
	private String fieldCode;
	
	@Builder.Default
	private Boolean mandatory = false;
	
	@Builder.Default
	private Boolean editable = true;
}
