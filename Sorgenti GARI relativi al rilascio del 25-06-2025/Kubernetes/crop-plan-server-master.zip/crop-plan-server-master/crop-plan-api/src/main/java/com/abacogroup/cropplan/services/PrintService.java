package com.abacogroup.cropplan.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abacogroup.cropplan.api.CreatePrintJobResponse;
import com.abacogroup.cropplan.api.CropPlan;
import com.abacogroup.cropplan.api.CropPlanPrintParam;
import com.abacogroup.cropplan.api.CropPlanPrintParams;
import com.abacogroup.cropplan.api.PrintJobResponse;
import com.abacogroup.cropplan.api.PrintJobStatus;
import com.abacogroup.cropplan.api.PrintProgress;
import com.abacogroup.cropplan.api.PrintStatus;
import com.abacogroup.cropplan.api.payload.CropPlanPrintPayload;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.PrintsDAO;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

public class PrintService {

	private static final String URL_PRINT_ENGINE = "printEngineURL";
	private static final String URL_FILE_STORE = "fileStoreURL";
	private static final String PRINT_DESTINATION = "crop-plan";

    private final PrintsDAO printsDAO;
    private final CropPlanConfigDAO configDAO;
	private final CropPlansDAO cropPlansDAO;

    public PrintService(DAOContainer daoContainer) {
        this.printsDAO = daoContainer.getPrintsDAO();
        this.configDAO = daoContainer.getCropPlanConfigDAO();
		this.cropPlansDAO = daoContainer.getCropPlansDAO();
    }

	public String generateCropPlanPrint(RuntimeEnvironment env, String businessId, Long cropPlanId, CropPlanPrintPayload payload) {
		Object url = env.getProperty(URL_PRINT_ENGINE);
		if (url == null) {
			throw new BadRequestException("Print engine URL not configured");
		}

		Map<String, Object> params = new HashMap<>();
		params.put("businessId", businessId);
		params.put("cropPlanId", cropPlanId);
		params.put("pointInTime", payload.getPointInTime());

		var target = env.getAuthenticatedWebTarget(url.toString())
				.path(env.getTenantId())
				.path("public")
				.path("v1")
				.path(payload.getPrintCode())
				.queryParam("dest", PRINT_DESTINATION);
		try (var response = target.request(MediaType.APPLICATION_JSON)
				.post(Entity.json(params))) {

			if (response.getStatus() != 200)
				throw new IllegalStateException("Unexpected response status: " + response.getStatus());

			var printJobResponse = response.readEntity(CreatePrintJobResponse.class);
			return printJobResponse.getUuid();
		}
	}

	public PrintStatus getCropPlanPrintProgressStatus(RuntimeEnvironment env, String businessId, Long cropPlanId, String printId) {
		Object url = env.getProperty(URL_PRINT_ENGINE);
		if (url == null) {
			throw new BadRequestException("Print engine URL not configured");
		}

		var target = env.getAuthenticatedWebTarget(url.toString())
				.path(env.getTenantId())
				.path("public")
				.path("v1")
				.path("jobs")
				.path(printId);
		try (var response = target.request(MediaType.APPLICATION_JSON)
				.get()) {

			if (response.getStatus() != 200)
				throw new IllegalStateException("Unexpected response status: " + response.getStatus());

			var printJobResponse = response.readEntity(PrintJobResponse.class);
			if (printJobResponse.getStatus() == PrintJobStatus.ERROR)
				return new PrintStatus(PrintProgress.COMPLETED, true);
			else if (printJobResponse.getStatus() == PrintJobStatus.READY)
				return new PrintStatus(PrintProgress.COMPLETED, false);
			return new PrintStatus(PrintProgress.IN_PROGRESS, false);
		}
	}

	public Response getCropPlanPrintFile(RuntimeEnvironment env, String businessId, Long cropPlanId, String printId) {

		Object url = env.getProperty(URL_PRINT_ENGINE);
		if (url == null) {
			throw new BadRequestException("Print engine URL not configured");
		}

		PrintJobResponse printJobResponse;
		var target = env.getAuthenticatedWebTarget(url.toString())
				.path(env.getTenantId())
				.path("public")
				.path("v1")
				.path("jobs")
				.path(printId);
		try (var response = target.request(MediaType.APPLICATION_JSON)
				.get()) {

			if (response.getStatus() != 200)
				throw new IllegalStateException("Unexpected response status: " + response.getStatus());

			printJobResponse = response.readEntity(PrintJobResponse.class);
		}

		url = env.getProperty(URL_FILE_STORE);
		if (url == null) {
			throw new BadRequestException("File store URL not configured");
		}
		target = env.getAuthenticatedWebTarget(url.toString())
				.path(env.getTenantId())
				.path("public")
				.path("v1")
				.path("files")
				.path(printJobResponse.getBucket())
				.path(printJobResponse.getFileStoreId());
		return target.request().get();
	}

    public CropPlanPrintParams getCropPlanPrintParams(RuntimeEnvironment env, String businessId, Long cropPlanId, String printCode) {
		CropPlan cropPlanData = cropPlansDAO.getCropPlanInternal(businessId, cropPlanId, env.getTenantId());
        Long cropPlanTypeId = configDAO.getCropPlanTypeId(cropPlanData.getCropPlanTypeCode(), env.getTenantId());
		List<CropPlanPrintParam> printParams = printsDAO.getCropPlanPrintParamsByPrintCode(cropPlanTypeId, printCode);

		CropPlanPrintParams printParamRes = new CropPlanPrintParams();
		printParamRes.setPrintParams(printParams);
		return printParamRes;
    }
}
