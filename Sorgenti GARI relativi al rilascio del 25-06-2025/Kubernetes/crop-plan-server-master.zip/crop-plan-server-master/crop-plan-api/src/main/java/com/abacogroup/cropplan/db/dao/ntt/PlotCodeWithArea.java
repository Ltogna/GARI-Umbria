package com.abacogroup.cropplan.db.dao.ntt;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PlotCodeWithArea
{
	private String plotCode;
	private Integer areaSqm;
}
