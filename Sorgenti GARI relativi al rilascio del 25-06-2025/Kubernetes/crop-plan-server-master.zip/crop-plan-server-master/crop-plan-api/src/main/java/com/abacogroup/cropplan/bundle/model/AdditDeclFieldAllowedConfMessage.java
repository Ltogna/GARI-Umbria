package com.abacogroup.cropplan.bundle.model;

import com.abacogroup.cropplan.bundle.model.ValidationGroups.Delete;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.groups.Default;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AdditDeclFieldAllowedConfMessage {

	@NotBlank(groups = { Default.class, Delete.class})
	private String landUseCode;
	@NotBlank(groups = { Default.class, Delete.class})
	private String code;

	@Valid
	@NotNull
	List<AdditDeclFieldAallowedValueMessage> allowedValues;

	private AbsoluteDate deleteFrom;

	@Builder.Default
	private Boolean insertKeepExisting = false;
}
