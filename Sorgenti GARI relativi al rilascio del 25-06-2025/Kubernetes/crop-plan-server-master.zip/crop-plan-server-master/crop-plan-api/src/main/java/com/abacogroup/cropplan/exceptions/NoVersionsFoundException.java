package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class NoVersionsFoundException extends WebApplicationException
{
	private static final long serialVersionUID = -3604317965298652788L;

	public static  class NoVersionsFoundExceptionErrorBody
	{
		@Schema(allowableValues = "NO_VERSIONS_FOUND_EXCEPTION")
		public String getErrorCode()
		{
			return "NO_VERSIONS_FOUND_EXCEPTION";
		}
	}

	private static final NoVersionsFoundExceptionErrorBody BODY = new NoVersionsFoundExceptionErrorBody();

	public NoVersionsFoundException()
	{
		super("No versions found",
			Response.status(Status.NOT_FOUND).entity(BODY).build());
	}
}
