package com.abacogroup.cropplan.api;

import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Copy campaign land use code")
public class CopyCampaignLandUseCode
{
	@Schema(description = "The land use")
	@NotNull
	private LandUse landuse;

	@Schema(description = "The default excluded from aggregation attribute")
	@NotNull
	private Boolean excludedFromAggregation;

}
