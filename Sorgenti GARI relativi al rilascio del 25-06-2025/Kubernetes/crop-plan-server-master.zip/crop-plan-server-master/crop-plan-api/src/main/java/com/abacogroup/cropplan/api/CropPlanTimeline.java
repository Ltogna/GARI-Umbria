package com.abacogroup.cropplan.api;

import java.util.List;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Schema(description = "A crop plan's timeline")
public class CropPlanTimeline
{
	@Schema(description = "The changing points, when a plot is added/modified/deleted")
	private List<ChangingPoint> changingPoints;
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static class ChangingPoint
	{
		@Schema(description = "Date")
		private AbsoluteDate date;
		
		@Schema(description = "One or more plot added flag")
		private Integer flAdded;
		
		@Schema(description = "One or more plot modified flag")
		private Integer flModified;
		
		@Schema(description = "One or more plot deleted flag")
		private Integer flDeleted;
		
	}
}
