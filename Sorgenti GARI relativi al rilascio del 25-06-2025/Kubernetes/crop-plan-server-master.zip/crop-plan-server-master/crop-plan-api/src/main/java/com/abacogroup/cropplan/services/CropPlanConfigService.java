package com.abacogroup.cropplan.services;

import static com.abacogroup.cropplan.sdk.model.config.CropPlanConfigParam.BULK_DECLARATIONS_ANOMALIES_FILTER;
import static com.abacogroup.cropplan.sdk.model.config.CropPlanConfigParam.DISABLE_CHECK_ON_MANDATORY_DECL_FIELDS;
import static com.abacogroup.cropplan.sdk.model.config.CropPlanConfigParam.DISABLE_PLOT_DATA_SPATIAL_INDEX;
import static com.abacogroup.cropplan.sdk.model.config.CropPlanConfigParam.MAX_PLOTS_ON_DOMAIN_ZONE;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.sdk.model.CropPlanConfigData;
import com.abacogroup.cropplan.sdk.model.config.CropPlanConfigParam;
import com.abacogroup.jdbi.datatype.AbsoluteDate;

public class CropPlanConfigService {

	private final CropPlanConfigDAO crplConfigDAO;
	
	public CropPlanConfigService(DAOContainer daocontainer) {
		this.crplConfigDAO = daocontainer.getCropPlanConfigDAO();
	}
	
	public boolean isIgnoreCropPlanConstraintsDeclsToPlots(Long cropPlanId) {
		return isFalse(cropPlanId, CropPlanConfigParam.CONSTRAINTS_DECLS_TO_PLOTS);
	}
	
	public boolean isIgnoreConstraintsDeclsPercTo100(Long cropPlanId) {
		return isFalse(cropPlanId, CropPlanConfigParam.CONSTRAINTS_DECLS_PERC_TO_100);
	}
	
	public boolean isDoNotReproportionDeclsAreas(Long cropPlanId) {
		return isTrue(cropPlanId, CropPlanConfigParam.DO_NOT_REPROPORTION_DECLS_AREAS);
	}
	
	private boolean isSnapFromCampaignRefDate(Long cropPlanId) {
		return isTrue(cropPlanId, CropPlanConfigParam.SNAP_FROM_CAMPAIGN_REF_DATE);
	}
	
	private String getCampaignStartDateParam(Long cropPlanId) {
		var cmpStartDate = crplConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.CAMPAIGN_START_DATE.toString(), null);
		if (!cmpStartDate.isEmpty())
			return cmpStartDate.get(0).getParamValue();
		return null;
	}
	
	public AbsoluteDate getCampaignStartDate(Long cropPlanId, AbsoluteDate pointInTime) {
		var cmpStartDateParam = getCampaignStartDateParam(cropPlanId);
		if (cmpStartDateParam != null) {
			var cmpStartDate = AbsoluteDate.of(pointInTime.toLocalDate().getYear()+cmpStartDateParam);
			if (pointInTime.isBefore(cmpStartDate))
				cmpStartDate = AbsoluteDate.of(cmpStartDate.toLocalDate().minusYears(1));
			return cmpStartDate;
		}
		return null;
	}
	
	public String getCampaignRefDateParam(Long cropPlanId) {
		var cmpRefDate = crplConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.CAMPAIGN_REF_DATE.toString(), null);
		if (!cmpRefDate.isEmpty())
			return cmpRefDate.get(0).getParamValue();
		return null;
	}
	
	public AbsoluteDate getSnapFromDate(Long cropPlanId, AbsoluteDate pointInTime) {
		if (isSnapFromCampaignRefDate(cropPlanId)) {
			var cmpRefDateParam = getCampaignRefDateParam(cropPlanId);
			if (cmpRefDateParam != null) {
				var cmpStartDate = getCampaignStartDate(cropPlanId, pointInTime);
				if (cmpStartDate != null) {
					var snapFromDate = AbsoluteDate.of(cmpStartDate.toLocalDate().getYear()+cmpRefDateParam);
					if (snapFromDate.isBefore(cmpStartDate))
						snapFromDate = AbsoluteDate.of(snapFromDate.toLocalDate().plusYears(1));
					return snapFromDate;
				}
			}
		}
		return pointInTime;
	}
	
	public AbsoluteDate getNextSnapFromDate(Long cropPlanId, AbsoluteDate pointInTime) {
		if (isSnapFromCampaignRefDate(cropPlanId)) {
			var cmpRefDateParam = getCampaignRefDateParam(cropPlanId);
			if (cmpRefDateParam != null) {
				var pointInTimeDate = pointInTime.toString().substring(4);
				if (pointInTimeDate.compareTo(cmpRefDateParam) > 0)
					return AbsoluteDate.of((pointInTime.toLocalDate().getYear()+1)+cmpRefDateParam);				
				else 
					return AbsoluteDate.of(pointInTime.toLocalDate().getYear()+cmpRefDateParam);				
			}
		}
		return pointInTime;
	}
	
	private String getFixedOpenDateParam(Long cropPlanId) {
		var fixedOpenDate = crplConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.OPEN_AT_FIXED_DATE.toString(), null);
		if (!fixedOpenDate.isEmpty())
			return fixedOpenDate.get(0).getParamValue();
		return null;
	}
	
	public AbsoluteDate getFixedOpenDate(Long cropPlanId) {
		var fixedOpenDateParam = getFixedOpenDateParam(cropPlanId);
		if (fixedOpenDateParam != null) {
			if (fixedOpenDateParam.length() == 8)
				return AbsoluteDate.of(fixedOpenDateParam);
			else {
				var cmpStartDate = getCampaignStartDate(cropPlanId, AbsoluteDate.of(crplConfigDAO.getCurrentTimestamp().toLocalDate()));
				if (cmpStartDate != null) {
					var fixedOpenDate = AbsoluteDate.of(cmpStartDate.toLocalDate().getYear()+fixedOpenDateParam);
					if (fixedOpenDate.isBefore(cmpStartDate))
						fixedOpenDate = AbsoluteDate.of(fixedOpenDate.toLocalDate().plusYears(1));
					return fixedOpenDate;
				}
			}
		}
		return null;
	}
	
	private String getFixedEditDateParam(Long cropPlanId) {
		var fixedEditDate = crplConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.EDIT_AT_FIXED_DATE.toString(), null);
		if (!fixedEditDate.isEmpty())
			return fixedEditDate.get(0).getParamValue();
		return null;
	}
	
	public boolean isForceEditAtFixedDate(Long cropPlanId) {
		return isTrue(cropPlanId, CropPlanConfigParam.FORCE_EDIT_AT_FIXED_DATE);
	}
	
	public AbsoluteDate getFixedEditDate(Long cropPlanId, AbsoluteDate pointInTime) {
		var fixedEditDateParam = getFixedEditDateParam(cropPlanId);
		if (fixedEditDateParam != null) {
			if (fixedEditDateParam.length() == 8)
				return AbsoluteDate.of(fixedEditDateParam);
			else {
				var cmpStartDate = getCampaignStartDate(cropPlanId, pointInTime);
				if (cmpStartDate != null) {
					var fixedEditDate = AbsoluteDate.of(cmpStartDate.toLocalDate().getYear()+fixedEditDateParam);
					if (fixedEditDate.isBefore(cmpStartDate))
						fixedEditDate = AbsoluteDate.of(fixedEditDate.toLocalDate().plusYears(1));
					return fixedEditDate;
				}
			}
		}
		return null;
	}

	public Double getPerimeterMultiplierAreaTolerance(Long cropPlanId) {
		var tol = crplConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.PERIMETER_MULTIPLIER_AREA_TOLERANCE.toString(), null);
		if (!tol.isEmpty())
			return Double.parseDouble(tol.get(0).getParamValue());
		return 0d;
	}
	
	public boolean isDisableChangeDateWhenReadOnly(Long cropPlanId) {
		return isTrue(cropPlanId, CropPlanConfigParam.DISABLE_CHANGE_DATE_WHEN_READ_ONLY);
	}
	
	public boolean allowDeclsPercToZero(Long cropPlanId) {
		return isTrue(cropPlanId, CropPlanConfigParam.ALLOW_DECLS_PERC_TO_ZERO);
	}
	
	public boolean isRestorePlotsPropagatingBehaviour(Long cropPlanId) {
		return isTrue(cropPlanId, CropPlanConfigParam.RESTORE_PLOTS_PROPAGATING_BEHAVIOUR);
	}
	
	public boolean isRestorePlotsAtCampaignStartDate(Long cropPlanId) {
		return isTrue(cropPlanId, CropPlanConfigParam.RESTORE_PLOTS_AT_CAMPAIGN_START_DATE);
	}
	
	public Double getEditPropagationTolerance(Long cropPlanId) {
		var tol = crplConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.EDIT_PROPAGATION_TOLERANCE.toString(), null);
		if (!tol.isEmpty())
			return Double.parseDouble(tol.get(0).getParamValue());
		return 0d;
	}
	
	public boolean isLockDeclarationsFieldsIfExternal(Long cropPlanId) {
		return isTrue(cropPlanId, CropPlanConfigParam.LOCK_DECLARATIONS_FIELDS_IF_EXTERNAL);
	}
	
	public boolean isIgnoreLandUseCompatibility(Long cropPlanId) {
		return isTrue(cropPlanId, CropPlanConfigParam.IGNORE_LAND_USE_COMPATIBILITY);
	}

	public Optional<Integer> getMaxPlotsOnDomainZone(Long cropPlanId) {
		return Optional.ofNullable(crplConfigDAO.getCropPlanConfig(cropPlanId, MAX_PLOTS_ON_DOMAIN_ZONE.toString(), null))
				.filter(cropPlanConfigData -> !cropPlanConfigData.isEmpty())
				.map(configs -> configs.get(0))
				.map(CropPlanConfigData::getParamValue)
				.map(Integer::parseInt);
	}

	public boolean isConstraintsVersionToSyncRefDate(Long cropPlanId) {
		return isTrue(cropPlanId, CropPlanConfigParam.CONSTRAINTS_VERSION_TO_SYNC_REF_DATE);
	}

	public boolean isEnableAutoMergeForLpisSync(Long cropPlanId) {
		return isTrue(cropPlanId, CropPlanConfigParam.ENABLE_AUTOMERGE_FOR_LPIS_SYNC);
	}
	
	public List<CropPlanConfigData> getCropPlanConfig(Long cropPlanId, String paramName, String paramValue) {
		return crplConfigDAO.getCropPlanConfig(cropPlanId, paramName, paramValue);
	}
	
	public Long getLatestOtherPlansVersionEmptyDomainPlotsLayerAreaTolerance(Long cropPlanId) {
		var tol = crplConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.LATEST_OTHER_PLANS_VERSION_EMPTY_DOMAIN_PLOTS_LAYER_AREA_TOLERANCE.toString(), null);
		if (!tol.isEmpty())
			return Long.valueOf(tol.get(0).getParamValue());
		return 1L;
	}

	public List<String> getBulkDeclarationsAnomaliesFilter(Long cropPlanId) {
		return this.getMultipleConfigValues(cropPlanId, BULK_DECLARATIONS_ANOMALIES_FILTER, " ");
	}

	public boolean disableCheckOnMandatoryDeclFields(Long cropPlanId) {
		return this.isTrue(cropPlanId, DISABLE_CHECK_ON_MANDATORY_DECL_FIELDS);
	}

	public boolean disablePlotDataSpatialIndex(Long cropPlanId) {
		return this.isTrue(cropPlanId, DISABLE_PLOT_DATA_SPATIAL_INDEX);
	}

	private boolean isTrue(Long cropPlanId, CropPlanConfigParam configParam) {
		return hasConfigValue(cropPlanId, configParam, "TRUE");
	}

	private boolean isFalse(Long cropPlanId, CropPlanConfigParam configParam) {
		return hasConfigValue(cropPlanId, configParam, "FALSE");
	}

	private boolean hasConfigValue(Long cropPlanId, CropPlanConfigParam configParam, String value) {
		return !crplConfigDAO.getCropPlanConfig(cropPlanId, configParam.toString(), value).isEmpty();
	}

	private List<String> getMultipleConfigValues(Long cropPlanId, CropPlanConfigParam configParam, String valuesSeparator) {
		return crplConfigDAO.getCropPlanConfig(cropPlanId, configParam.toString(), null)
				.stream()
				.map(CropPlanConfigData::getParamValue)
				.filter(StringUtils::isNotBlank)
				.map(v -> StringUtils.split(v, valuesSeparator))
				.flatMap(Stream::of)
				.collect(Collectors.toList());
	}
}
