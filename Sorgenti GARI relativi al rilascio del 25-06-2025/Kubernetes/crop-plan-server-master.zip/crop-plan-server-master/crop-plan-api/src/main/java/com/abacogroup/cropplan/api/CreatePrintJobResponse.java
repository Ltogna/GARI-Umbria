package com.abacogroup.cropplan.api;

import lombok.Data;

@Data
public class CreatePrintJobResponse {
	private String uuid;
}
