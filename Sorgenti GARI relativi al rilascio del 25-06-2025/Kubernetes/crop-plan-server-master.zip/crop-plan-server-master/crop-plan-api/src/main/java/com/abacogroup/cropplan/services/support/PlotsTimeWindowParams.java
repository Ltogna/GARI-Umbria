package com.abacogroup.cropplan.services.support;

import java.time.LocalDateTime;
import java.util.List;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class PlotsTimeWindowParams
{
	private Long cropPlanId;
	private String domainZoneId;
	private String businessId;
	private LocalDateTime versionDt;
	private AbsoluteDate pointInTimeFrom;
	private AbsoluteDate pointInTimeTo;
	private List<PlotsTimeWindowPlotData> plotsData;
}