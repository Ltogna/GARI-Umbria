package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class CropPlanNotWriteableException extends WebApplicationException
{
	private static final long serialVersionUID = 4354782762623924044L;

	public static class CropPlanNotWriteableExceptionErrorBody
	{
		private String messageCode;
		
		public CropPlanNotWriteableExceptionErrorBody() {
			this.messageCode = null;
		}
		
		public CropPlanNotWriteableExceptionErrorBody(String messageCode) {
			this.messageCode = messageCode;
		}

		@Schema(allowableValues = {"CROP_PLAN_NOT_WRITEABLE_EXCEPTION", "CROP_PLAN_NOT_WRITEABLE_EXCEPTION-[THE_MESSAGE_CODE]"})
		public String getErrorCode()
		{
			if (messageCode != null)
				return "CROP_PLAN_NOT_WRITEABLE_EXCEPTION-" + messageCode;
			else
				return "CROP_PLAN_NOT_WRITEABLE_EXCEPTION";
		}
	}

	public CropPlanNotWriteableException(String messageCode)
	{
		super("You are not allowed to change this business crop plan",
			Response.status(Status.FORBIDDEN).entity(new CropPlanNotWriteableExceptionErrorBody(messageCode)).build());
	}
}
