package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class InvalidDeclDatesException extends WebApplicationException
{
	private static final long serialVersionUID = -5572671375637015782L;

	public static  class InvalidDeclDatesExceptionErrorBody
	{
		@Schema(allowableValues = "INVALID_DECLARATION_DATES_EXCEPTION")
		public String getErrorCode()
		{
			return "INVALID_DECLARATION_DATES_EXCEPTION";
		}
	}
	
	private static final InvalidDeclDatesExceptionErrorBody BODY = new InvalidDeclDatesExceptionErrorBody();

	public InvalidDeclDatesException()
	{
		super("Invalid declaration dates",
			Response.status(Status.BAD_REQUEST).entity(BODY).build());
	}
}
