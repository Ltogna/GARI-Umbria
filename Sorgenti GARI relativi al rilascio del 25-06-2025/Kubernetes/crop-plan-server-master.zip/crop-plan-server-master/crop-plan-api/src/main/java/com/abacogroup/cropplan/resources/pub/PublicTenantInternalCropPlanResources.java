package com.abacogroup.cropplan.resources.pub;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.abacogroup.cropplan.api.internal.InternalInsertedPlotResponse;
import com.abacogroup.cropplan.api.internal.InternalInsertedPlotResponse.InternalInsertedDeclaration;
import com.abacogroup.cropplan.api.internal.payload.InternalInsertPlotPayload;
import com.abacogroup.cropplan.api.payload.CreateVersionPayload;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.PlotEditDAO;
import com.abacogroup.cropplan.db.dao.ntt.DeclarationData;
import com.abacogroup.cropplan.db.dao.ntt.PlotData;
import com.abacogroup.cropplan.db.dao.ntt.SavePlotDatas;
import com.abacogroup.cropplan.dispatch.CropPlanCommitJob.CommiType;
import com.abacogroup.cropplan.exceptions.LockException;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.BaseCropPlanResource;
import com.abacogroup.cropplan.sdk.model.CropPlanVersion;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.LocksService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("{tenant}/public/internal")
@Tag(name = "INTERNAL - Crop plan resources (for crop plan not managed)")
@Timed
@RolesAllowed({"CRPL|USER","CRPL|EDITOR"})
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class PublicTenantInternalCropPlanResources extends BaseCropPlanResource
{
	private LocksService locksService;
	private CropPlanService cropPlanService;
	private CropPlansDAO cropPlansDAO;
	private PlotEditDAO plotEditDAO;

	public PublicTenantInternalCropPlanResources(BaseService baseService, CropPlanService cropPlanService,
			 LocksService locksService, CropCodeService cropCodeService, ValidatorService validatorService, CropPlanConfigService cropPlanConfigService,
			PluginManager pluginManager, DAOContainer daocontainer)
	{
		super(baseService, cropPlanService, locksService, cropCodeService, validatorService, cropPlanConfigService, pluginManager, daocontainer.getCropPlansDAO()
		);
		this.cropPlanService = cropPlanService;
		this.locksService = locksService;
		this.cropPlansDAO = daocontainer.getCropPlansDAO();
		this.plotEditDAO = daocontainer.getPlotEditDAO();
	}
	
	private void checkFlNotManaged(Long cropPlanId) {
		if(!cropPlanService.getCropPlanServiceUtils().isCropPlanNotManaged(cropPlanId))
			throw new BadRequestException("The crop plan is not marked as not managed");
	}
	
	@POST
	@Path("v1/crop-plans/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Insert a plot and its declarations")
	@ApiResponses({
		@ApiResponse(description = "The insert plot result"),
		@ApiResponse(responseCode = "404", description = "The crop plan is not marked as not managed"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneCode was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class)))
	})
	public InternalInsertedPlotResponse insertPlot(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "If it is set to true then the specified crop plan is locked for the current user") @QueryParam("autoLock") @DefaultValue("false") boolean autoLock,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid InternalInsertPlotPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkFlNotManaged(cropPlanId);
		if (autoLock)
			locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
		else
			checkLock(env, cropPlanId);
		
		LocalDateTime insertDt = plotEditDAO.getCurrentTimestamp();
		Long plotId = plotEditDAO.getCropPlotDataSeq();
		String plotCode = String.valueOf(plotId);
		List<PlotData> plotDatas = new ArrayList<>();
		PlotData plotData = new PlotData(true, plotId, plotCode, cropPlanId, payload.getDescription(), payload.getNotes(), payload.getFromDate(),
				payload.getToDate(), payload.getSrs(), (int) Math.round(payload.getGeom().getArea()), false, env.getUserId(), null, insertDt,
				LocalDateTime.of(9999, 12, 31, 0, 0), payload.getGeom());
		plotDatas.add(plotData);
		
		List<InternalInsertedDeclaration> declarations = new ArrayList<>();
		List<DeclarationData> declarationDatas = new ArrayList<>();
		if (payload.getDeclarations() != null)
			payload.getDeclarations().stream().forEach(d -> {
				Long declId = plotEditDAO.getDeclarationsSeq();
				String declCode = String.valueOf(declId);
				DeclarationData declarationData = new DeclarationData(true, declId, declCode, cropPlanId, plotCode, d.getFromDate(), 
						d.getFromDatePrecision(), d.getToDate(), d.getLanduseCode(), d.getAreaPerc(), env.getUserId(), null,
						insertDt, LocalDateTime.of(9999, 12, 31, 0, 0));
				declarationDatas.add(declarationData);
				declarations.add(new InternalInsertedDeclaration(declCode, d.getExternalCode()));
			});
		
		SavePlotDatas savePlotDatas = new SavePlotDatas(plotDatas, new ArrayList<>(), declarationDatas, new ArrayList<>(), new ArrayList<>());
		plotEditDAO.savePlotDatas(savePlotDatas, domainZoneId, null);
		
		return new InternalInsertedPlotResponse(plotCode, declarations);
	}
	
	@POST
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/versions")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Create a new version of the specified crop plan")
	@ApiResponses({
		@ApiResponse(description = "The new crop plan version created"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class)))
	})
	public CropPlanVersion createVersion(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "If it is set to true then the specified crop plan is locked for the current user before version creation") @QueryParam("autoLock") @DefaultValue("false") boolean autoLock,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid CreateVersionPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkFlNotManaged(cropPlanId);
		if (autoLock)
			locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
		else
			checkLock(env, cropPlanId);

		cropPlanService.validateCropPlanEditDates(env, cropPlanId, payload.getPointInTime());

		cropPlansDAO.createVersion(cropPlanId, payload.getPointInTime(), payload.getMessage(), env.getUserId());
		
		var cpvs = cropPlansDAO.infinite(() -> cropPlansDAO.getAllVersions(businessId, cropPlanId, env.getTenantId(), 1, null), null, 1);
		var cropPlanVersion = cpvs.getRecords().get(0);
		
		cropPlansDAO.updateVersionToPublished(cropPlanId, cropPlanVersion.getVersionDate());
		cropPlanVersion.setFlPublished(true);
		
		if (payload.isHavingAcknowledgedAnomalies())
			cropPlansDAO.saveAnomaliesAcknowledgment(env.getUserId(), cropPlanId, cropPlanVersion.getVersionDate());

		cropPlanService.addToMessageQueue(env, businessId, cropPlanId, cropPlanVersion.getVersionReferenceDate().toLocalDate(), cropPlanVersion.getCropPlanTypeCode(), 
				cropPlanVersion.getVersion(), cropPlanVersion.getVersionDate(), CommiType.PUBLISHED);

		return cropPlanVersion;
	}

	@DELETE
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/cleanup")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Cleanup a crop plan deleting all its plots")
	@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class)))
	public void cleanupCropPlan(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "If it is set to true then the specified crop plan is locked for the current user before version creation") @QueryParam("autoLock") @DefaultValue("false") boolean autoLock,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkFlNotManaged(cropPlanId);
		if (autoLock)
			locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
		else
			checkLock(env, cropPlanId);

		LocalDateTime currentDt = cropPlansDAO.getCurrentTimestamp();
		LocalDateTime deleteDt = currentDt.minus(Duration.ofMillis(1));
		
		cropPlansDAO.cleanupCropPlan(cropPlanId, env.getUserId(), currentDt, deleteDt);
	}
	
}
