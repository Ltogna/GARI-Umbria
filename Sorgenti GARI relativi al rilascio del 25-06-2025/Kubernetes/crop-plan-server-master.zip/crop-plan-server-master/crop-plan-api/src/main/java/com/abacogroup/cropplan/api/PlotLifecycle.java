package com.abacogroup.cropplan.api;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PlotLifecycle
{
	@Schema(description = "The plot 'stable' code, this does not change in history")
	private String plotCode;

	@Schema(description = "Min date from")
	private AbsoluteDate minFromDate;

	@Schema(description = "Max date to")
	private AbsoluteDate maxToDate;
}
