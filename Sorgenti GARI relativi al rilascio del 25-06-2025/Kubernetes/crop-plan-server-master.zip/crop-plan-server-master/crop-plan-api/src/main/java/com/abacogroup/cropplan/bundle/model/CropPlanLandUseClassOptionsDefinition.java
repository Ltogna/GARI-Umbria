package com.abacogroup.cropplan.bundle.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CropPlanLandUseClassOptionsDefinition
{
	private String landUseClassCode;
	private Boolean percFixedTo100;
	private Boolean permanent;
}
