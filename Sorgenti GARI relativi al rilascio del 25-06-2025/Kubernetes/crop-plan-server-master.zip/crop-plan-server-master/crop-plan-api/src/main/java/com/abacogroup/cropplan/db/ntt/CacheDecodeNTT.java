package com.abacogroup.cropplan.db.ntt;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class CacheDecodeNTT {
    private String type;
    private LocalDateTime cacheDt;
    private String code;
    private String description;
    private Long cropPlanTypeId;
}
