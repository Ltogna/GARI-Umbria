package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class BlockingAnomaliesException extends WebApplicationException
{
	private static final long serialVersionUID = 694292105978030197L;

	public static  class BlockingAnomaliesExceptionBody
	{
		@Schema(allowableValues = "BLOCKING_ANOMALIES_EXCEPTION")
		public String getErrorCode()
		{
			return "BLOCKING_ANOMALIES_EXCEPTION";
		}
	}
	
	private static final BlockingAnomaliesExceptionBody BODY = new BlockingAnomaliesExceptionBody();

	public BlockingAnomaliesException()
	{
		super("Blocking anomalies in the crop plan have been found",
			Response.status(Status.BAD_REQUEST).entity(BODY).build());
	}
}
