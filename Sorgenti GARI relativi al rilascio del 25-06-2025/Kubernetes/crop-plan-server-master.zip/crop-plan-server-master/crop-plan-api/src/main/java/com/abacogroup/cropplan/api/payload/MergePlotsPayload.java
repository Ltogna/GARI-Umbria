package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;
import lombok.Data;

@Data
public class MergePlotsPayload
{
	@Schema(description = "From date")
	@NotNull
	private AbsoluteDate fromPointInTime;

	@Schema(description = "To date (optional, default propagate to infinity)")
	private AbsoluteDate toPointInTime;

	@Schema(description = "The plots to merge")
	@NotNull
	@Size(min = 1)
	@Valid
	private List<String> plotCodes;
	
}
