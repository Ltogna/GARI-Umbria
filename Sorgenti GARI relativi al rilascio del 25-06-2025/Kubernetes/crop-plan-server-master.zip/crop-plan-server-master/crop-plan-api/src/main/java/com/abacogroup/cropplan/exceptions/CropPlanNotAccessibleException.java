package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class CropPlanNotAccessibleException extends WebApplicationException
{
	private static final long serialVersionUID = -2455349595203235877L;

	public static class CropPlanNotAccessibleExceptionErrorBody
	{
		private String messageCode;
		
		public CropPlanNotAccessibleExceptionErrorBody() {
			this.messageCode = null;
		}
		
		public CropPlanNotAccessibleExceptionErrorBody(String messageCode) {
			this.messageCode = messageCode;
		}

		@Schema(allowableValues = {"CROP_PLAN_NOT_ACCESSIBLE_EXCEPTION", "CROP_PLAN_NOT_ACCESSIBLE_EXCEPTION-[THE_MESSAGE_CODE]"})
		public String getErrorCode()
		{
			if (messageCode != null)
				return "CROP_PLAN_NOT_ACCESSIBLE_EXCEPTION-" + messageCode;
			else
				return "CROP_PLAN_NOT_ACCESSIBLE_EXCEPTION";
		}
	}

	public CropPlanNotAccessibleException(String messageCode)
	{
		super("You are not allowed to access this business crop plans",
			Response.status(Status.FORBIDDEN).entity(new CropPlanNotAccessibleExceptionErrorBody(messageCode)).build());
	}
}
