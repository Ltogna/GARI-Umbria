package com.abacogroup.cropplan.resources.pub;

import com.abacogroup.cropplan.api.DomainZoneExt;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.BaseResource;
import com.abacogroup.cropplan.sdk.model.Version;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements;
import com.abacogroup.cropplan.sdk.model.layers.AdditionalLayer;
import com.abacogroup.cropplan.sdk.model.layers.GISInfo;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.DomainService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.codahale.metrics.annotation.Timed;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@Path("{tenant}/public/v1/domains")
@Tag(name = "PUBLIC - Domains resources")
@Timed
@RolesAllowed({"CRPL|USER","CRPL|EDITOR"})
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class PublicTenantDomainResources extends BaseResource
{
	private DomainService domainService;
	private PluginManager pluginManager;

	public PublicTenantDomainResources(BaseService baseService, DomainService domainService, PluginManager pluginManager)
	{
		super(baseService);
		this.domainService = domainService;
		this.pluginManager = pluginManager;
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/zones")
	@Operation(description = "Get and/or search the domains, regardless the point in time; the point in time parameter is only used to compute the zone MBR")
	@ApiResponse(description = "The domain zones")
	public InfiniteListResults<DomainZoneExt> getDomainZones(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
		@Parameter(description = "The search string") @QueryParam("search") String search,
		@Parameter(description = "If it is set to true then it returns only domain zones that belong to the business") @QueryParam("filterByBusiness") @DefaultValue("true") boolean filterByBusiness,
		@Parameter(description = "If it is set to true then it returns also the domain zones holding area") @QueryParam("includeHoldingArea") @DefaultValue("false") boolean includeHoldingArea,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		checkCanRead(user, language, businessId);

		var versionDt = version != null ? version.toDateTime() : null;
		return domainService.getDomainZonesInfinite(createEnvironment(user, language), businessId, cropPlanId, versionDt, pointInTime, search, filterByBusiness, includeHoldingArea, nextKey);
	}
	
	@GET
	@Path("/{businessId}/plans/{cropPlanId}/domains/{domainZoneCode}/snap-geometries")
	@Operation(description = "Get the geometries on which snap operation is possible")
	@ApiResponse(description = "The geometries on which snap operation is possible")
	public SnapElements getSnapGeometries(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone code") @PathParam("domainZoneCode") String domainZoneCode,
		@Parameter(description = "The point in time to be evaluated", required = true) @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
		@Parameter(description = "The list of snap element types to be returned") @QueryParam("snapElementTypes") List<String> snapElementTypes,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(user, language, businessId);
		
		var domainZone = pluginManager.getDomainPlugin(businessId, cropPlanId, tenantId).getDomainZoneByCode(env, businessId, pointInTime.toLocalDate(), domainZoneCode);
		if (domainZone == null)
			throw new BadRequestException("The specified domainZoneCode was not found");

		return domainService.getSnapGeometries(env, businessId, cropPlanId, domainZone.getDomainZoneId(), snapElementTypes, pointInTime);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/additional-layers")
	@Operation(description = "Get the additional layers")
	@ApiResponse(description = "The additional layers")
	public List<AdditionalLayer> getAdditionalLayers(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @QueryParam("domainZoneId") @DefaultValue("") String domainZoneId,
		@Parameter(description = "The campaignYear") @QueryParam("campaignYear") Integer campaignYear,
		@Parameter(description = "The module") @QueryParam("module") @DefaultValue("cropplan") String module,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		checkCanRead(user, language, businessId);

		return domainService.getAdditionalLayers(createEnvironment(user, language), businessId, cropPlanId, domainZoneId, campaignYear, module);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/domains/{domainZoneCode}/gis-info")
	@Operation(description = "Get GIS info")
	@ApiResponse(description = "The GIS info on the specified layers")
	public List<GISInfo> getGISInfo(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone code") @PathParam("domainZoneCode") String domainZoneCode,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "The X coord (Web Mercator) of the picked point") @QueryParam("x") @NotNull Double x,
			@Parameter(description = "The Y coord (Web Mercator) of the picked point") @QueryParam("y") @NotNull Double y,
			@Parameter(description = "The list of the layer codes") @QueryParam("layerCodes") List<String> layerCodes,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(user, language, businessId);
		
		var domainZone = pluginManager.getDomainPlugin(businessId, cropPlanId, tenantId).getDomainZoneByCode(env, businessId, pointInTime.toLocalDate(), domainZoneCode);
		if (domainZone == null)
			throw new BadRequestException("The specified domainZoneCode was not found");

		return domainService.getGISInfo(createEnvironment(user, language), businessId, cropPlanId, domainZone.getDomainZoneId(), pointInTime, x, y, layerCodes);
	}
}
