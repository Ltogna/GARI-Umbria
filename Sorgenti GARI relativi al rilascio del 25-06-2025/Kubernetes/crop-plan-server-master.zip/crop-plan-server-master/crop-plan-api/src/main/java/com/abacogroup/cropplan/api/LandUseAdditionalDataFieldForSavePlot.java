package com.abacogroup.cropplan.api;

import java.time.LocalDateTime;

import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class LandUseAdditionalDataFieldForSavePlot extends LandUseAdditionalDataField {
	
	@EqualsAndHashCode.Exclude
	private boolean isNew;
	private String declCode;
	private Long cropPlanId;
	private String plotCode;
	private String landUseCode;
	@EqualsAndHashCode.Exclude
	private String userId;
	@EqualsAndHashCode.Exclude
	private LocalDateTime saveDt;
	
	public LandUseAdditionalDataFieldForSavePlot(LandUseAdditionalDataField fc) {
		super(fc.getDeclCode(), fc.getFieldCode(), fc.getFieldDescription(), fc.getDayFrom(), fc.getDayTo(), fc.getSortOrder(), fc.getValue(), fc.getValueDescription(),fc.isFlShowInTooltip());
	}
	
}
