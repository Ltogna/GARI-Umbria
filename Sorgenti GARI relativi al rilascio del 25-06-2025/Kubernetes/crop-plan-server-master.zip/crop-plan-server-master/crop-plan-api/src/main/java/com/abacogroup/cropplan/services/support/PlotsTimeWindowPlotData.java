package com.abacogroup.cropplan.services.support;

import java.util.List;

import com.abacogroup.cropplan.sdk.model.Declaration;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class PlotsTimeWindowPlotData
{
	private String plotCode;
	private List<String> parcelCodes;
	private Double areaPerc;
	private List<Declaration> declarations;
}