package com.abacogroup.cropplan.resources;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

import com.abacogroup.cropplan.api.CropPlan;
import com.abacogroup.cropplan.api.CropPlanDates;
import com.abacogroup.cropplan.api.CropPlanPrintParams;
import com.abacogroup.cropplan.api.CropPlanTimeline;
import com.abacogroup.cropplan.api.CropPlanTimeline.ChangingPoint;
import com.abacogroup.cropplan.api.CropPlanType;
import com.abacogroup.cropplan.api.DeclaredArea;
import com.abacogroup.cropplan.api.DisabledFunctionCode;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.PlotDataToInclude;
import com.abacogroup.cropplan.api.PlotDeclaredAreas;
import com.abacogroup.cropplan.api.PlotLifecycle;
import com.abacogroup.cropplan.api.PrintStatus;
import com.abacogroup.cropplan.api.SubdomainZoneResponse;
import com.abacogroup.cropplan.api.SyncStatus;
import com.abacogroup.cropplan.api.ValidationAnomalies;
import com.abacogroup.cropplan.api.payload.CreateCropPlanPayload;
import com.abacogroup.cropplan.api.payload.CreateVersionPayload;
import com.abacogroup.cropplan.api.payload.CropPlanPrintPayload;
import com.abacogroup.cropplan.api.payload.GetPermanentCropFormSubscriptionsPayload;
import com.abacogroup.cropplan.api.payload.ParcelDataPayload;
import com.abacogroup.cropplan.api.payload.SubdomainZoneRequest;
import com.abacogroup.cropplan.api.payload.SyncCropPlanPayload;
import com.abacogroup.cropplan.api.payload.UpdateCropPlanPayload;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.ntt.FunctionDisableConfig;
import com.abacogroup.cropplan.db.dao.ntt.ScenarioAnomaliesDisableFunctionsConfigurations;
import com.abacogroup.cropplan.exceptions.CreateVersionException;
import com.abacogroup.cropplan.exceptions.CropPlanCantBeDeletedException;
import com.abacogroup.cropplan.exceptions.CropPlanNotCreateableException;
import com.abacogroup.cropplan.exceptions.CropPlanNotWriteableException;
import com.abacogroup.cropplan.exceptions.CropPlanReadOnlyException;
import com.abacogroup.cropplan.exceptions.LockException;
import com.abacogroup.cropplan.exceptions.SubdomainZoneException;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.CropPlanConfigData;
import com.abacogroup.cropplan.sdk.model.CropPlanVersion;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormFieldCodes;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormSubscription;
import com.abacogroup.cropplan.sdk.model.PlotTimeline;
import com.abacogroup.cropplan.sdk.model.Version;
import com.abacogroup.cropplan.sdk.model.cropcodes.Style;
import com.abacogroup.cropplan.sdk.model.sync.SyncType;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.CropPlanDeclarationsService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.LocksService;
import com.abacogroup.cropplan.services.PrintService;
import com.abacogroup.cropplan.services.SyncService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.cropplan.services.support.PlotTimeWindowParams;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.ForbiddenException;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.SecurityContext;

@Path("{tenant}/api-priv/v1/crop-plans")
@Tag(name = "PRIVATE - Crop plan resources")
@Timed
@RolesAllowed({ "CRPL|USER", "CRPL|EDITOR" })
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class CropPlanResources extends BaseCropPlanResource {
	private static int PAGE_SIZE = 10;
	private static int LARGE_PAGE_SIZE = 50;

	private CropPlanService cropPlanService;
	private CropPlanDeclarationsService cropPlanDeclarationsService;
	private SyncService syncService;
	private LocksService locksService;
	private PrintService printService;
	private CropPlansDAO cropPlansDAO;

	public CropPlanResources(BaseService baseService, CropPlanService cropPlanService, CropPlanDeclarationsService cropPlanDeclarationsService,
			SyncService syncService, LocksService locksService,
			CropCodeService cropCodeService, ValidatorService validatorService, CropPlanConfigService cropPlanConfigService, PrintService printService, PluginManager pluginManager,
			DAOContainer daocontainer) {
		super(baseService, cropPlanService, locksService, cropCodeService, validatorService, cropPlanConfigService, pluginManager, daocontainer.getCropPlansDAO()
		);
		this.cropPlanService = cropPlanService;
		this.cropPlanDeclarationsService = cropPlanDeclarationsService;
		this.syncService = syncService;
		this.locksService = locksService;
		this.printService = printService;
		this.cropPlansDAO = daocontainer.getCropPlansDAO();
	}

	@GET
	@Path("/{businessId}/plan-types")
	@Operation(description = "Get the list of the available crop plan types")
	@ApiResponse(description = "The list of the available crop plan types")
	public List<CropPlanType> getCropPlanTypes(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		checkCanRead(user, language, businessId);

		return cropPlanService.getCropPlanTypes(createEnvironment(user, language));
	}

	@GET
	@Path("/{businessId}/plans")
	@Operation(description = "Get the list of the crop plans of a business")
	@ApiResponse(description = "The list of the crop plans of the specified business")
	public InfiniteListResults<CropPlan> getCropPlans(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan type code; can be specified to filter crop plans of a specific type") @QueryParam("cropPlanTypeCode") String cropPlanTypeCode,
			@Parameter(description = "The search string to search by crop plan type or crop plan description") @QueryParam("search") String search,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		checkCanRead(user, language, businessId);
		RuntimeEnvironment env = createEnvironment(user, language);

		return cropPlanService.getCropPlans(env, businessId, cropPlanTypeCode, search, nextKey, PAGE_SIZE);
	}

	@POST
	@Path("/{businessId}/plans")
	@Operation(description = "Create a new crop plan")
	@RolesAllowed("CRPL|EDITOR")
	@ApiResponses({
			@ApiResponse(description = "The new crop plan created"),
			@ApiResponse(responseCode = "400", description = "The crop plan type specified does not exist"),
			@ApiResponse(responseCode = "405", description = "A crop plan of the specified not multiple type already exist"),
			@ApiResponse(responseCode = "403", description = "You are not allowed to create crop plans for this business", content = @Content(schema = @Schema(implementation = CropPlanNotCreateableException.CropPlanNotCreateableExceptionErrorBody.class)))
	})
	public CropPlan createCropPlan(
			@Context SecurityContext context,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@NotNull @Valid CreateCropPlanPayload payload,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);

		var cropPlanId = cropPlanService.insertCropPlan(env, businessId, payload);
		return cropPlanService.getCropPlan(env, businessId, cropPlanId);
	}

	@PUT
	@Path("/{businessId}/plans/{cropPlanId}")
	@Operation(description = "Update a crop plan")
	@RolesAllowed("CRPL|CAN_EDIT_CROPPLAN_DESC")
	@ApiResponses({
			@ApiResponse(description = "The crop plan updated"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public CropPlan updateCropPlan(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@NotNull @Valid UpdateCropPlanPayload payload,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		locksService.lockCropPlan(env, cropPlanId);

		cropPlansDAO.updateCropPlan(cropPlanId, payload);

		return cropPlanService.getCropPlan(env, businessId, cropPlanId);
	}

	@DELETE
	@Path("/{businessId}/plans/{cropPlanId}")
	@Operation(description = "Delete a crop plan")
	@RolesAllowed("CRPL|CAN_DELETE_CROPPLAN")
	@ApiResponses({
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The crop plan can't be deleted", content = @Content(schema = @Schema(implementation = CropPlanCantBeDeletedException.CropPlanCantBeDeletedExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public void deleteCropPlan(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanDelete(env, businessId, cropPlanId);
		locksService.lockCropPlan(env, cropPlanId);

		var deleteDt = cropPlansDAO.getCurrentTimestamp().minus(Duration.ofMillis(1));
		cropPlansDAO.deleteCropPlan(cropPlanId, deleteDt, env.getUserId());
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}")
	@Operation(description = "Get the details of a crop plan")
	@ApiResponse(description = "The specified crop plan details")
	public CropPlan getCropPlan(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return cropPlanService.getCropPlan(env, businessId, cropPlanId);
	}

	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/lock")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Lock the specified crop plan for the current user")
	@ApiResponses({
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public void lockCropPlan(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);

		locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/versions")
	@Operation(description = "Get the versions list of a crop plan")
	@ApiResponse(description = "The versions list of the specified crop plan")
	public InfiniteListResults<CropPlanVersion> getAllVersions(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "Can be supplied to obtain only versions created at a specified reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "If true then all the business ID crop plans versions are returned (also versions of other crop plan types)") @QueryParam("ignoreCropPlanId") @DefaultValue("false") boolean ignoreCropPlanId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return cropPlanService.getAllVersions(env, businessId, cropPlanId, true, referenceDate, ignoreCropPlanId, nextKey, PAGE_SIZE);
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/versions")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Create a new version of the specified crop plan")
	@ApiResponses({
			@ApiResponse(description = "The new crop plan version created"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "No changes pending on the crop plan"),
			@ApiResponse(responseCode = "500", description = "Error while creating version", content = @Content(schema = @Schema(implementation = CreateVersionException.CreateVersionExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public CropPlanVersion createVersion(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "If it is set to true then the new version is created also if the crop plan does not have changes pending") @QueryParam("forcePublish") @DefaultValue("false") boolean forcePublish,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid CreateVersionPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		return cropPlanService.createVersion(createEnvironment(user, language), businessId, cropPlanId, payload, forcePublish);
	}

	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/versions/restore-last")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Restore the last version of the specified crop plan")
	@ApiResponses({
			@ApiResponse(description = "The crop plan version restored"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "No version found"),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public CropPlanVersion restoreLastVersion(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		return cropPlanService.restoreLastVersion(createEnvironment(user, language), businessId, cropPlanId);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/declared-area")
	@Operation(description = "Get the declared area of a crop plan")
	@ApiResponse(description = "The declared area of the specified crop plan")
	public DeclaredArea getTotalDeclaredArea(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @QueryParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		var totalAreaSqm = cropPlansDAO.getTotalPlotsArea(cropPlanId, versionDt, pointInTime, null);
		if (totalAreaSqm == null)
			return new DeclaredArea(0, 0d, 0, 0d);
		var totalDeclaredArea = cropPlansDAO.getDeclaredArea(cropPlanId, versionDt, pointInTime, null);
		var totalDeclaredAreaPercentage = totalDeclaredArea != null ? ((double) totalDeclaredArea / totalAreaSqm * 100) : 0;
		
		if (domainZoneId != null) {
			var domainAreaSqm = cropPlansDAO.getTotalPlotsArea(cropPlanId, versionDt, pointInTime, domainZoneId);
			if (domainAreaSqm != null) {
				var domainDeclaredArea = cropPlansDAO.getDeclaredArea(cropPlanId, versionDt, pointInTime, domainZoneId);
				var domainDeclaredAreaPercentage = domainDeclaredArea != null ? ((double) domainDeclaredArea / domainAreaSqm * 100) : 0;
				return new DeclaredArea(totalAreaSqm, totalDeclaredAreaPercentage, domainAreaSqm, domainDeclaredAreaPercentage);
			}
		}
		
		return new DeclaredArea(totalAreaSqm, totalDeclaredAreaPercentage, 0, 0d);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/style")
	@Operation(description = "Get the style of a plot")
	@ApiResponses({
			@ApiResponse(description = "The style of the specified plot"),
			@ApiResponse(responseCode = "400", description = "The specified plot was not found")
	})
	public Style getPlotStyle(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		var plot = cropPlanService.getPlot(createEnvironment(user, language), businessId, cropPlanId, domainZoneId,
				versionDt, pointInTime, pointInTime, plotCode);

		if (plot == null)
			throw new BadRequestException("The specified plot was not found");

		return plot.getStyle();
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots")
	@Operation(description = "Get the list of the plots of a crop plan")
	@ApiResponse(description = "The list of the plots of the specified crop plan")
	public InfiniteListResults<Plot> getPlots(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "the subdomain zone id") @QueryParam("subdomainZoneId") Long subdomainZoneId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		return cropPlanService.getPlots(createEnvironment(user, language), businessId, cropPlanId, domainZoneId,
				versionDt, pointInTime, null, subdomainZoneId, nextKey, LARGE_PAGE_SIZE, new PlotDataToInclude());
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/subdomain-zones")
	@Operation(description = "create subdomain zone")
	@ApiResponse(description = "the newly created subdomain zone with id", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "subdomain zone creation error",
			content = @Content(schema = @Schema(implementation = SubdomainZoneException.ErrorBody.class)))
	public SubdomainZoneResponse createSubdomainZone(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Valid @NotNull SubdomainZoneRequest request,
			@HeaderParam("accept-language") @DefaultValue("en") String language
	) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();

		return cropPlanService.createSubdomainZone(env, businessId, cropPlanId, domainZoneId, versionDt, pointInTime, request);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}")
	@Operation(description = "Get a plot")
	@ApiResponses({
			@ApiResponse(description = "The specified plot"),
			@ApiResponse(responseCode = "400", description = "The specified plot was not found")
	})
	public Plot getPlot(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		var plot = cropPlanService.getPlot(createEnvironment(user, language), businessId, cropPlanId, domainZoneId,
				versionDt, pointInTime, pointInTime, plotCode);

		if (plot == null)
			throw new BadRequestException("The specified plot was not found");

		return plot;
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/lifecycle")
	@Operation(description = "Get the lifecycle details of a plot")
	@ApiResponses({
			@ApiResponse(description = "The lifecycle details of the specified plot"),
			@ApiResponse(responseCode = "400", description = "The specified plot was not found")
	})
	public PlotLifecycle getPlotLifecycle(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		return cropPlansDAO.getPlotLifecycle(cropPlanId, domainZoneId, versionDt, plotCode);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/timeline")
	@Operation(description = "Get the timeline of a crop plan in a time window")
	@ApiResponse(description = "The timeline of the crop plan in the specified time window")
	public CropPlanTimeline getCropPlanTimeline(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The starting point in time to be evaluated") @QueryParam("pointInTimeFrom") @NotNull AbsoluteDate pointInTimeFrom,
			@Parameter(description = "The ending point in time to be evaluated") @QueryParam("pointInTimeTo") @NotNull AbsoluteDate pointInTimeTo,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		LocalDateTime versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();

		List<ChangingPoint> chp = cropPlansDAO.getCropPlanTimeline(cropPlanId, domainZoneId, versionDt, pointInTimeFrom, pointInTimeTo);

		CropPlanTimeline ret = new CropPlanTimeline();
		ret.setChangingPoints(chp);

		return ret;
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/timeline")
	@Operation(description = "Get the timeline of a plot in a time window")
	@ApiResponse(description = "The timeline of the plot in the specified time window")
	public PlotTimeline getPlotTimeline(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The starting point in time to be evaluated") @QueryParam("pointInTimeFrom") @NotNull AbsoluteDate pointInTimeFrom,
			@Parameter(description = "The ending point in time to be evaluated") @QueryParam("pointInTimeTo") @NotNull AbsoluteDate pointInTimeTo,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		var params = PlotTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.domainZoneId(domainZoneId)
				.plotCode(plotCode)
				.pointInTimeFrom(null)
				.pointInTimeTo(null)
				.versionDt(versionDt)
				.build();
		var ret = new PlotTimeline();
		ret.setPlotCode(plotCode);
		ret.setAreas(cropPlanService.getPlotAreas(params));
		ret.setDecls(cropPlanDeclarationsService.getPlotDeclarations(createEnvironment(user, language), businessId, cropPlanId, plotCode, null,
				versionDt, pointInTimeFrom, pointInTimeTo));

		return ret;
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/declared-areas")
	@Operation(description = "Get the declared areas of a plot in a time window")
	@ApiResponse(description = "The declared areas of the plot in the specified time window")
	public PlotDeclaredAreas getPlotDeclaredAreas(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The starting point in time to be evaluated") @QueryParam("pointInTimeFrom") @NotNull AbsoluteDate pointInTimeFrom,
			@Parameter(description = "The ending point in time to be evaluated") @QueryParam("pointInTimeTo") @NotNull AbsoluteDate pointInTimeTo,
			@Parameter(description = "Optional declaration code to exclude from the result") @QueryParam("excludedDeclCode") String excludedDeclCode,
			@Parameter(description = "If it is set to true then the areas are returned considering tolerance") @QueryParam("withTolerance") @DefaultValue("false") boolean withTolerance,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		var params = PlotTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.domainZoneId(domainZoneId)
				.plotCode(plotCode)
				.excludedDeclCode(excludedDeclCode)
				.pointInTimeFrom(pointInTimeFrom)
				.pointInTimeTo(pointInTimeTo)
				.versionDt(versionDt)
				.build();
		return cropPlanService.getPlotDeclaredAreas(params, withTolerance);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/sync/status")
	@Operation(description = "Get the crop plan sync progress status")
	@ApiResponse(description = "The sync progress status")
	public SyncStatus getSyncProgressStatus(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return syncService.getSyncProgress(cropPlanId);
	}

	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/sync/{syncType}")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Synchronize crop plan")
	@ApiResponses({
		@ApiResponse(description = "The sync progress status"),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public SyncStatus syncCropPlan(
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext context,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The sync type") @PathParam("syncType") SyncType syncType,
			@Parameter(description = "If it is set to true then the sync process ignore previous syncs") @QueryParam("ignorePreviousSyncs") @DefaultValue("false") boolean ignorePreviousSyncs,
			@Valid SyncCropPlanPayload payload,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		if (ignorePreviousSyncs && !context.isUserInRole("CRPL|CAN_FORCE_SYNC"))
			throw new ForbiddenException("You are not allowed to perform a forced sync operation");
			
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		return syncService.syncCropPlan(env, businessId, cropPlanId, syncType, payload, false, ignorePreviousSyncs);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/grouped-anomalies")
	@Operation(description = "Get the crop plan anomalies grouped by type")
	@ApiResponse(description = "The crop plan anomalies grouped by type")
	public ValidationAnomalies getGroupedCropPlanAnomalies(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "If it is set to true then the declarations anomalies are marked as plots anomalies grouped by plot") @QueryParam("groupDeclAnomaliesOnPlots") @DefaultValue("false") boolean groupDeclAnomaliesOnPlots,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		return cropPlanService.getGroupedCropPlanAnomalies(env, businessId, cropPlanId, versionDt, groupDeclAnomaliesOnPlots);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/config")
	@Operation(description = "Get the configuration of a crop plan")
	@ApiResponse(description = "The configuration of the specified crop plan")
	public List<CropPlanConfigData> getConfig(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return cropPlanService.getCropPlanConfig(env, businessId, cropPlanId);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/permanent-crop-form/fields-codes/{formType}")
	@Operation(description = "Get the permanent crop form fields codes")
	@ApiResponse(description = "The permanent crop form field codes")
	public List<PermanentCropFormFieldCodes> getPermanentCropFormFieldsCodes(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The permanent crop form type") @PathParam("formType") String formType,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return cropPlanService.getPermanentCropFormFieldsCodes(env, cropPlanId, formType);
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/prints")
	@Operation(description = "Generate a crop plan print")
	@ApiResponse(description = "The crop plan print ID")
	public String generateCropPlanPrint(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@NotNull @Valid CropPlanPrintPayload payload,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return printService.generateCropPlanPrint(env, businessId, cropPlanId, payload);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/prints/{printId}/status")
	@Operation(description = "Get the crop plan print progress status")
	@ApiResponse(description = "The crop plan print progress status")
	public PrintStatus getCropPlanPrintProgressStatus(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The print ID") @PathParam("printId") String printId,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return printService.getCropPlanPrintProgressStatus(env, businessId, cropPlanId, printId);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/prints/{printId}")
	@Operation(description = "Get the crop plan print file")
	@ApiResponse(description = "The crop plan print file bytes")
	public Response getCropPlanPrintFile(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The print ID") @PathParam("printId") String printId,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return printService.getCropPlanPrintFile(env, businessId, cropPlanId, printId);
	}
	
	@GET
	@Path("/{businessId}/plans/{cropPlanId}/prints/{printCode}/params")
	@Operation(description = "Get the crop plan print parameters")
	@ApiResponse(description = "The crop plan print parameters")
	public CropPlanPrintParams getCropPlanPrintParams(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The print code") @PathParam("printCode") String printCode,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return printService.getCropPlanPrintParams(env, businessId, cropPlanId, printCode);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/dates")
	@Operation(description = "Get the crop plan dates")
	@ApiResponse(description = "The crop plan dates")
	public CropPlanDates getCropPlanDates(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return cropPlanService.getCropPlanDates(env, businessId, cropPlanId, pointInTime);
	}
	
	@GET
	@Path("/{businessId}/plans/{cropPlanId}/default-open-date")
	@Operation(description = "Get the crop plan default open date")
	@ApiResponse(description = "The crop plan default open date")
	public AbsoluteDate getCropPlanDefaultOpenDate(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return cropPlanService.getCropPlanDefaultOpenDate(env, businessId, cropPlanId);
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/subscriptions")
	@Operation(description = "Get the permanent crop form subscriptions details")
	@ApiResponse(description = "The permanent crop form subscriptions details")
	public List<PermanentCropFormSubscription> getPermanentCropFormSubscriptions(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid GetPermanentCropFormSubscriptionsPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return cropPlanService.getPermanentCropFormSubscriptions(env, businessId, cropPlanId, payload);
	}

	@GET
	@Path("/{businessId}/{typeId}/config-sceneries-disabled-func")
	@Operation(description = "Get a plot configuration of sceneries for disabled functions")
	@ApiResponses({
			@ApiResponse(description = "The specified plot configuration of sceneries for disabled functions"),
			@ApiResponse(responseCode = "400", description = "The specified plot was not found")
	})
	public List<FunctionDisableConfig> getConfigSceneriesDisabledFunc(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("typeId") Long typeId,
			@Parameter(description = "The func type") @QueryParam("funcType") DisabledFunctionCode disableFunctionCode,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);

		List<FunctionDisableConfig> config = cropPlanService.getConfigSceneriesDisabledFunc(disableFunctionCode, env, typeId);

		return config;
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/config-functions-disabled")
	@Operation(description = "Get the Scenario Anomalies Disabled Functions Configurations")
	@ApiResponse(description = "The Scenario Anomalies Disabled Functions Configurations")
	public ScenarioAnomaliesDisableFunctionsConfigurations getFunctionsdDisabledConfig(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The Disabled Function Code") @QueryParam("disabledFunctionCode") DisabledFunctionCode disabledFunctionCode,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);
		return cropPlanService.getPlotDisabledFunctionsConfig(disabledFunctionCode, env, businessId, cropPlanId);
	}
	
	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/parcels/{parcelCode}/data")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Update parcel data")
	@ApiResponses({
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public void updateParcelData(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The parcel code") @PathParam("parcelCode") String parcelCode,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid ParcelDataPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);
		cropPlanService.updateParcelData(env, cropPlanId, parcelCode, payload);
	}
}
