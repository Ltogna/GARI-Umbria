package com.abacogroup.cropplan.api.payload;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
public class UpdateCropPlanPayload
{
	@NotEmpty
	private String description;
}
