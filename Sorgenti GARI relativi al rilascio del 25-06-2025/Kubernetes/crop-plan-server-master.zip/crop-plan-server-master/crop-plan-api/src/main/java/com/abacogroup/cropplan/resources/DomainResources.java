package com.abacogroup.cropplan.resources;

import com.abacogroup.cropplan.api.DomainZoneExt;
import com.abacogroup.cropplan.sdk.model.Version;
import com.abacogroup.cropplan.sdk.model.domain.CadastralParcelData;
import com.abacogroup.cropplan.sdk.model.domain.CadastralParcelOverlapData;
import com.abacogroup.cropplan.sdk.model.domain.HoldingArea;
import com.abacogroup.cropplan.sdk.model.domain.ParcelData;
import com.abacogroup.cropplan.sdk.model.domain.Place;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements;
import com.abacogroup.cropplan.sdk.model.layers.AdditionalLayer;
import com.abacogroup.cropplan.sdk.model.layers.GISInfo;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.DomainService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.MaxRowsResults;
import com.codahale.metrics.annotation.Timed;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@Path("{tenant}/api-priv/v1/domains")
@Tag(name = "PRIVATE - Domain resources")
@Timed
@RolesAllowed({"CRPL|USER","CRPL|EDITOR"})
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class DomainResources extends BaseResource
{
	private DomainService domainService;

	public DomainResources(BaseService baseService, DomainService domainService)
	{
		super(baseService);
		this.domainService = domainService;
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/holding-area")
	@Operation(description = "Get the holding area of a crop plan")
	@ApiResponse(description = "The holding area of the specified crop plan")
	public HoldingArea getHoldingArea(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		checkCanRead(user, language, businessId);

		return domainService.getHoldingArea(createEnvironment(user, language), businessId, cropPlanId, pointInTime);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/zones")
	@Operation(description = "Get and/or search the domains, regardless the point in time; the point in time parameter is only used to compute the zone MBR")
	@ApiResponse(description = "The domain zones")
	public MaxRowsResults<DomainZoneExt> getDomainZones(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
		@Parameter(description = "The search string") @QueryParam("search") String search,
		@Parameter(description = "If it is set to true then it returns only domain zones that belong to the business") @QueryParam("filterByBusiness") @DefaultValue("true") boolean filterByBusiness,
		@Parameter(description = "If it is set to true then it returns also the domain zones holding area") @QueryParam("includeHoldingArea") @DefaultValue("false") boolean includeHoldingArea,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		checkCanRead(user, language, businessId);

		var versionDt = version != null ? version.toDateTime() : null;
		return domainService.getDomainZonesMaxRows(createEnvironment(user, language), businessId, cropPlanId, versionDt, pointInTime, search, filterByBusiness, includeHoldingArea);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/holding-area")
	@Operation(description = "Get the holding area of a crop plan in a domain zone")
	@ApiResponse(description = "The crop plan holding area in the specified domain zone")
	public HoldingArea getHoldingAreaByDomainZone(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		checkCanRead(user, language, businessId);

		return domainService.getHoldingAreaByDomainZone(createEnvironment(user, language), businessId, cropPlanId, domainZoneId, pointInTime);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/snap-geometries")
	@Operation(description = "Get the geometries on which snap operation is possible")
	@ApiResponse(description = "The geometries on which snap operation is possible")
	public SnapElements getSnapGeometries(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The point in time to be evaluated", required = true) @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
		@Parameter(description = "The list of snap element types to be returned") @QueryParam("snapElementTypes") List<String> snapElementTypes,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		checkCanRead(user, language, businessId);

		return domainService.getSnapGeometries(createEnvironment(user, language), businessId, cropPlanId, domainZoneId, snapElementTypes, pointInTime);
	}
	
	@GET
	@Path("/{businessId}/plans/{cropPlanId}/additional-layers")
	@Operation(description = "Get additional layers")
	@ApiResponse(description = "The additional layers")
	public List<AdditionalLayer> getAdditionalLayers(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @QueryParam("domainZoneId") @NotNull String domainZoneId,	
		@Parameter(description = "The campaignYear") @QueryParam("campaignYear") Integer campaignYear,
		@Parameter(description = "The module") @QueryParam("module") @DefaultValue("cropplan") String module,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		checkCanRead(user, language, businessId);

		return domainService.getAdditionalLayers(createEnvironment(user, language), businessId, cropPlanId, domainZoneId, campaignYear, module);
	}
	
	@GET
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/gis-info")
	@Operation(description = "Get GIS info")
	@ApiResponse(description = "The GIS info on the specified layers")
	public List<GISInfo> getGISInfo(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
		@Parameter(description = "The X coord (Web Mercator) of the picked point") @QueryParam("x") @NotNull Double x,
		@Parameter(description = "The Y coord (Web Mercator) of the picked point") @QueryParam("y") @NotNull Double y,
		@Parameter(description = "The list of the layer codes") @QueryParam("layerCodes") List<String> layerCodes,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		checkCanRead(user, language, businessId);

		return domainService.getGISInfo(createEnvironment(user, language), businessId, cropPlanId, domainZoneId, pointInTime, x, y, layerCodes);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/places")
	@Operation(description = "Get the places")
	@ApiResponse(description = "The places")
	public MaxRowsResults<Place> getPlaces(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The search string") @QueryParam("search") String search,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		checkCanRead(user, language, businessId);

		return domainService.getPlaces(createEnvironment(user, language), businessId, cropPlanId, domainZoneId, search);
	}
	
	@GET
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/parcels")
	@Operation(description = "Get the parcels data")
	@ApiResponse(description = "The parcels data")
	public InfiniteListResults<ParcelData> getParcelsData(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		checkCanRead(user, language, businessId);

		return domainService.getParcelsData(createEnvironment(user, language), businessId, cropPlanId, domainZoneId, pointInTime, nextKey);
	}
	
	@GET
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/cadastral-parcels")
	@Operation(description = "Get the cadastral parcels data")
	@ApiResponse(description = "The cadastral parcels data")
	public InfiniteListResults<CadastralParcelData> getCadastralParcelsData(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		checkCanRead(user, language, businessId);

		return domainService.getCadastralParcelsData(createEnvironment(user, language), businessId, cropPlanId, domainZoneId, pointInTime, nextKey);
	}
	
	@GET
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/cadastral-parcels/overlaps")
	@Operation(description = "Get the cadastral parcels overlaps data")
	@ApiResponse(description = "The cadastral parcels overlaps data")
	public InfiniteListResults<CadastralParcelOverlapData> getCadastralParcelsOverlapsData(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		checkCanRead(user, language, businessId);

		return domainService.getCadastralParcelsOverlapsData(createEnvironment(user, language), businessId, cropPlanId, domainZoneId, pointInTime, nextKey);
	}	
	
}
