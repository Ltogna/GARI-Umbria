package com.abacogroup.cropplan.services;

import java.util.List;
import java.util.Map;

import org.locationtech.jts.geom.Polygon;

import com.abacogroup.cropplan.api.EditPlotResult;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.geometryeditor.EditorResult;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class PersistEditorResult {
	
	private EditPlotResult editPlotResult;
	private FutureIntersections futureIntersections;
	private EditorResult<String> editorResult;

	@AllArgsConstructor
	@Data
	public static class FutureIntersections
	{
		private AbsoluteDate maximumDayTo;
		private List<ValidIntersection> validIntersections;
	}
	
	@AllArgsConstructor
	@Data
	public static class ValidIntersection
	{
		private AbsoluteDate pointInTime;
		private Map<String, Polygon> topologyCorrected;
		private boolean validWithTolerance;
		private Map<String, Polygon> created;
		private Map<String, Polygon> modified;
	}
}
