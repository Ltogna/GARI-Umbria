package com.abacogroup.cropplan.db.dao;

import com.abacogroup.cropplan.db.dao.ntt.LandCoverCompatibilityCacheEntry;
import java.time.LocalDateTime;
import java.util.Iterator;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.BatchChunkSize;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

public interface CacheLandCoverCompatibilityDAO extends BasicDAO {

    @Deprecated
    @SqlUpdate("delete from crpl_cache_land_cover_compat"
          + "         where dt_cache < :cacheValidityDt" +
            "           and type_id = (select type_id from crpl_plans where id = :cropPlanId)")
    void clearCacheLandCoverCompatibility(@Bind("cropPlanId") Long cropPlanId, @Bind("cacheValidityDt") LocalDateTime cacheValidityDt);

    @SqlUpdate("delete from crpl_cache_land_cover_compat"
               + "         where dt_cache < :cacheValidityDt" +
               "           and type_id = :typeId")
    void clearCacheLandCoverCompatibility(@Bind("cacheValidityDt") LocalDateTime cacheValidityDt, @Bind("typeId") Long cropPlanTypeId);

    @SqlBatch("insert into crpl_cache_land_cover_compat (type_id, dt_cache, land_cover_code, land_use_code) values (:typeId, :cacheDt, :landCoverCode, :landUseCode)")
    @BatchChunkSize(2000)
    void insertCacheLandCoverCompatibility(@BindBean Iterator<LandCoverCompatibilityCacheEntry> entries);
}
