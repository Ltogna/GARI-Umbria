package com.abacogroup.cropplan.resources.dtos;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.util.List;

@Data
public class LandUseCommonConfigAndValuesDto {
	@NotNull
	@Size(min = 1)
	private List<String> landUseCodes;
}
