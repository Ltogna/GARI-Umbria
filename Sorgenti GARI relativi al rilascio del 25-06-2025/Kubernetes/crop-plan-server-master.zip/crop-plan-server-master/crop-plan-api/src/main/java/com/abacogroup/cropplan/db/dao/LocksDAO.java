package com.abacogroup.cropplan.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transaction;

public interface LocksDAO extends EnhancedSqlObject {

	@SqlUpdate("delete from crpl_locks where plan_id = :cropPlanId")
	void deleteLockInternal(@Bind("cropPlanId") Long cropPlanId);

	@SqlUpdate("insert into crpl_locks (plan_id, lock_dt, user_id) values (:cropPlanId, §current_timestamp§, :userId)")
	void insertLockInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("userId") String userId);

	@SqlQuery("select least(count(*), 1)"
			+ "      from crpl_locks"
			+ "     where plan_id = :cropPlanId"
			+ "       and user_id = :userId")
	Boolean hasLock(@Bind("cropPlanId") Long cropPlanId, @Bind("userId") String userId);

	@SqlUpdate("delete from crpl_locks where plan_id = :cropPlanId and user_id = :userId")
	void deleteLockIfMine(@Bind("cropPlanId") Long cropPlanId, @Bind("userId") String userId);

	@Transaction
	default void lockCropPlan(Long cropPlanId, String userId) {
		deleteLockInternal(cropPlanId);
		insertLockInternal(cropPlanId, userId);
	}

}
