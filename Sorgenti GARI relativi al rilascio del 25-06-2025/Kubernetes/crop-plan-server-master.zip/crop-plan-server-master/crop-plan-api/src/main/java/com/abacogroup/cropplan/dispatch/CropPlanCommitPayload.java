package com.abacogroup.cropplan.dispatch;

import java.time.LocalDateTime;

import com.abacogroup.cropplan.sdk.model.Version;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CropPlanCommitPayload
{
	public CropPlanCommitPayload(CropPlanCommitJob job) {
		this.tenant = job.getTenant();
		this.businessId = job.getBusinessId();
		this.cropPlanId = job.getCropPlanId();
		this.cropPlanTypeCode = job.getCropPlanTypeCode();
		this.version = job.getVersion();
		this.versionDate = job.getVersionDate();
		this.referenceDate = job.getReferenceDate();
		this.username = job.getUsername();
	}

	@NotNull
	private String tenant;
	
	@NotNull
	private String businessId;
	
	@NotNull
	private Long cropPlanId;
	
	@NotNull
	private String cropPlanTypeCode;
	
	@NotNull
	private Version version;
	
	@NotNull
	private LocalDateTime versionDate;
	
	private String referenceDate;
	
	@NotNull
	private String username;
}
