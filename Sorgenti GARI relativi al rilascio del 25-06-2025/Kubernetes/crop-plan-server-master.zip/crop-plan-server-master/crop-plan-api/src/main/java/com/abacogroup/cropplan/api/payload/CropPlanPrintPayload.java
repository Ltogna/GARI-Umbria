package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CropPlanPrintPayload
{
	@Schema(description = "The crop plan print code")
	@NotEmpty
	private String printCode;
	
	@Schema(description = "The point in time to be evaluated")
	@NotNull
	private AbsoluteDate pointInTime;
}
