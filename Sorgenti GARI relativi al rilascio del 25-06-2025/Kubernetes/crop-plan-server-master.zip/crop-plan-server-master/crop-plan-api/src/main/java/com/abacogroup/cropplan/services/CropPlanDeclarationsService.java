package com.abacogroup.cropplan.services;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;

import com.abacogroup.cropplan.api.CopyDeclarationsResult;
import com.abacogroup.cropplan.api.CropPlanDates;
import com.abacogroup.cropplan.api.DeclRotationDto;
import com.abacogroup.cropplan.api.EditDeclarationResult;
import com.abacogroup.cropplan.api.EditDeclarationsResult;
import com.abacogroup.cropplan.api.MergedDeclaration;
import com.abacogroup.cropplan.api.PlotBuffer;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.PlotDataToInclude;
import com.abacogroup.cropplan.api.PlotDeclRotationDto;
import com.abacogroup.cropplan.api.payload.EditDeclarationsFieldsPayload;
import com.abacogroup.cropplan.api.payload.EditPermanentCropForm;
import com.abacogroup.cropplan.api.payload.InsertPermanentCropForm;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.db.dao.SyncDAO;
import com.abacogroup.cropplan.db.dao.ValidatorDAO;
import com.abacogroup.cropplan.db.dao.ntt.DeclarationWithPlotCode;
import com.abacogroup.cropplan.db.dao.ntt.ParcelIntersectionWithPlotId;
import com.abacogroup.cropplan.db.dao.ntt.PermanentCropFormWithDeclCode;
import com.abacogroup.cropplan.db.dao.ntt.PlotCodeWithArea;
import com.abacogroup.cropplan.exceptions.InvalidDeclAreaPercZeroException;
import com.abacogroup.cropplan.exceptions.PlotBufferException;
import com.abacogroup.cropplan.exceptions.PlotBufferException.ErrEnum;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.sdk.model.BaseDeclaration;
import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataFieldWithPlotCode;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.PermanentCropForm;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormData;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormExternalCodeDecode;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseDetails;
import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormConfig;
import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormFieldConfig;
import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormType;
import com.abacogroup.cropplan.sdk.model.cropcodes.Style;
import com.abacogroup.cropplan.sdk.model.sync.LatestSync;
import com.abacogroup.cropplan.sdk.model.validation.AnomalyObjectType;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomaly;
import com.abacogroup.cropplan.sdk.model.validation.ValidationMessage;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedDeclaration;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorData;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorOperation;
import com.abacogroup.cropplan.sdk.spi.CropCodesPlugin;
import com.abacogroup.cropplan.sdk.spi.DomainPlugin;
import com.abacogroup.cropplan.services.support.PlotTimeWindowParams;
import com.abacogroup.cropplan.services.support.PlotsTimeWindowParams;
import com.abacogroup.cropplan.services.support.PlotsTimeWindowPlotData;
import com.abacogroup.cropplan.services.support.ValidatorSupport;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.google.common.collect.Iterators;
import com.google.common.collect.UnmodifiableIterator;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.NotFoundException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class CropPlanDeclarationsService {
	
	private final CropCodeService cropCodeService;
	private final ValidatorService validatorService;
	private final PesticidesService pesticidesService;
	private final CropPlanConfigService cropPlanConfigService;
	private final PluginManager pluginManager;
	private final CropPlansDAO cropPlansDAO;
	private final ValidatorDAO validatorDAO;
	private final SyncDAO syncDAO;
	private final DeclarationsDAO declarationsDAO;
	
	public CropPlanDeclarationsService(CropCodeService cropCodeService, ValidatorService validatorService, 
			PesticidesService pesticidesService, CropPlanConfigService cropPlanConfigService,
			PluginManager pluginManager, DAOContainer daocontainer) {
		this.cropCodeService = cropCodeService;
		this.validatorService = validatorService;
		this.pesticidesService = pesticidesService;
		this.cropPlanConfigService = cropPlanConfigService;
		this.pluginManager = pluginManager;
		this.cropPlansDAO = daocontainer.getCropPlansDAO();
		this.validatorDAO = daocontainer.getValidatorDAO();
		this.syncDAO = daocontainer.getSyncDAO();
		this.declarationsDAO = daocontainer.getDeclarationsDAO();
	}


	public PlotBuffer getPlotBuffer(RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId,
                                    String plotCode, LocalDateTime versionDt, AbsoluteDate pointInTime) {

		List<DeclarationWithPlotCode> decls = declarationsDAO.getPlotDeclarations(cropPlanId, plotCode, null, versionDt, pointInTime, pointInTime);
		fillDeclarationsData(env, decls, businessId, cropPlanId, versionDt, PlotDataToInclude.EXCLUDE_ALL);

		BigDecimal numerator = new BigDecimal(0);
		BigDecimal denominator = new  BigDecimal(0);
		for (Declaration decl : decls) {
			LandUseDetails landUseDetails = cropCodeService.getLandUseCode(env, businessId, cropPlanId, decl.getLanduse().getCode(), null, pointInTime);

			boolean hasField = landUseDetails.getFormsConfig().stream()
					.filter(c -> PermanentCropFormType.VINEYARD_FORM.equals(c.getFormType()))
					.map(PermanentCropFormConfig::getFields)
					.flatMap(Collection::stream)
					.map(PermanentCropFormFieldConfig::getFieldCode)
					.anyMatch("DISTANCE_BETWEEN_ROWS_CM"::equalsIgnoreCase);

			if (hasField) {
				BigDecimal distanceBetweenRowsM = decl.getPermanentCropForms().stream()
						.filter(c -> PermanentCropFormType.VINEYARD_FORM.toString().equalsIgnoreCase(c.getFormType()))
						.findFirst()
						.map(PermanentCropForm::getPermanentCropFormData)
						.map(PermanentCropFormData::getDistanceBetweenRowsCm)
						.filter(v -> v > 0.)
						.map(BigDecimal::new)
						.map(v -> v.divide(BigDecimal.valueOf(100), 5, RoundingMode.HALF_UP))
						.orElse(new BigDecimal(0));

				BigDecimal perc = Optional.of(decl).map(BaseDeclaration::getAreaPerc)
						.filter(v -> v > 0.)
						.map(BigDecimal::new)
						.map(v -> v.divide(BigDecimal.valueOf(100), 5, RoundingMode.HALF_UP))
						.orElse(new BigDecimal(0));

				numerator = numerator.add(distanceBetweenRowsM.multiply(perc));
				denominator = denominator.add(perc);
			} else {
				throw new PlotBufferException(ErrEnum.MISSING_DISTANCE_BETWEEN_ROWS_CM,
						String.format("declaration '%s' of plot '%s' has no 'DISTANCE_BETWEEN_ROWS_CM' field", decl.getDeclCode(), plotCode));
			}
		}

		BigDecimal distanceBetweenRowsM = denominator.doubleValue() <= 0
				? new BigDecimal(0)
				: numerator.divide(denominator, 5, RoundingMode.HALF_UP);

		return new PlotBuffer(distanceBetweenRowsM.divide(new BigDecimal(2), 2, RoundingMode.HALF_UP));
	}


	public InfiniteListResults<PlotDeclRotationDto> getPlotWithDeclarationsAndRotation(RuntimeEnvironment env, String businessId, Long cropPlanId,
			CropPlanDates cropPlanDates, LocalDateTime versionDt, AbsoluteDate pointInTime, String nextKey) {
		InfiniteListResults<PlotDeclRotationDto> plots = declarationsDAO.infinite(() ->
				declarationsDAO.getPlotWithDeclarationsInPointInTimeByCropPlanIdAndDomainZoneIdsAndVersionDt(
						cropPlanId, null, versionDt, pointInTime), nextKey, 50
		);

		if (plots.getRecords().isEmpty()) {
			throw new NotFoundException("No data found with requested parameters");
		}

		List<String> plotCodes = plots.getRecords().stream()
				.map(PlotDeclRotationDto::getPlotCode)
				.collect(toList());

		Map<String, List<DeclRotationDto>> declsToAssignToPlots = this.getDeclRotationDtosGroupedByPlotCode(env, businessId, cropPlanId, cropPlanDates, versionDt,
				pointInTime, plotCodes);

		DomainPlugin domainPlugin = pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId());
		Map<String, String> domainZoneDescriptions = new HashMap<>();
		plots.getRecords().forEach(currentPlot -> {
			// Assign plot decls
			currentPlot.setDecls(declsToAssignToPlots.getOrDefault(currentPlot.getPlotCode(), new ArrayList<>()));

			String domainZoneDescription = domainZoneDescriptions.get(currentPlot.getDomainZoneId());
			if (domainZoneDescription == null) {
				domainZoneDescription = domainPlugin.getDomainZoneDescription(env, pointInTime.toLocalDate(), currentPlot.getDomainZoneId());
				domainZoneDescriptions.put(currentPlot.getDomainZoneId(), domainZoneDescription);
			}
			currentPlot.setDomainZoneDescription(domainZoneDescription);
		});

		return plots;
	}

	private Map<String, List<DeclRotationDto>> getDeclRotationDtosGroupedByPlotCode(RuntimeEnvironment env, String businessId, Long cropPlanId, CropPlanDates cropPlanDates,
			LocalDateTime versionDt, AbsoluteDate pointInTime, List<String> plotCodes) {

		boolean areCampaignStartDateAndReferenceDateNotNull = cropPlanDates.getCampaignStartDate() != null && cropPlanDates.getReferenceDate() != null;
		boolean isRefDateEqualToPointInTime = cropPlanDates.getReferenceDate() != null && cropPlanDates.getReferenceDate().equals(pointInTime);

		List<DeclRotationDto> declsToAssignToPlots = new ArrayList<>();

		if (areCampaignStartDateAndReferenceDateNotNull && isRefDateEqualToPointInTime) {
			AbsoluteDate campaignEndDate = AbsoluteDate.of(cropPlanDates.getCampaignStartDate().toLocalDate().plusYears(1).minusDays(1));

			List<DeclRotationDto> plotCodesDeclarations = new ArrayList<>();
			UnmodifiableIterator<List<String>> partitions = Iterators.partition(plotCodes.iterator(), 666);
			partitions.forEachRemaining(partition -> plotCodesDeclarations.addAll(declarationsDAO.getPlotCodesDeclsByCropPlanAndVersion(cropPlanId, versionDt, pointInTime, campaignEndDate, partition)));

			declsToAssignToPlots.addAll(calculateRotationOnPlotCodesDeclarations(plotCodesDeclarations, pointInTime));
		} else {
			UnmodifiableIterator<List<String>> partitions = Iterators.partition(plotCodes.iterator(), 666);
			partitions.forEachRemaining(partition -> declsToAssignToPlots.addAll(declarationsDAO.getPlotCodesDeclsByCropPlanAndVersion(cropPlanId, versionDt, pointInTime, pointInTime, partition)));
		}

		// assign landUse Description
		List<String> declasLandUseCodes = declsToAssignToPlots.stream().map(el -> el.getLandUse().getCode()).distinct().collect(toList());

		CropCodesPlugin cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId());
		List<LandUse> landUses = cropCodesPlugin.getLandUses(env, declasLandUseCodes);

		List<String> bulkDeclarationsAnomaliesFilter = cropPlanConfigService.getBulkDeclarationsAnomaliesFilter(cropPlanId);

		Map<String, List<DeclRotationDto>> res = new HashMap<>();
		for (DeclRotationDto decl : declsToAssignToPlots) {
			Optional<LandUse> landUse = landUses.stream().filter(el -> el.getCode().equals(decl.getLandUse().getCode())).findFirst();
			landUse.ifPresent(decl::setLandUse);

			List<ValidationAnomaly> anomalies;
			if (bulkDeclarationsAnomaliesFilter.isEmpty()) {
				anomalies = validatorDAO.getAnomaliesByObjectType(cropPlanId, versionDt, decl.getDeclCode(),
						AnomalyObjectType.DECLARATION,
						env.getTenantId(), env.getLocale().getLanguage());
			} else {
				anomalies = validatorDAO.getAnomaliesByObjectType(cropPlanId, versionDt, decl.getDeclCode(),
						AnomalyObjectType.DECLARATION, bulkDeclarationsAnomaliesFilter,
						env.getTenantId(), env.getLocale().getLanguage());
			}

			decl.setAnomalies(anomalies);

			res.computeIfAbsent(decl.getPlotCode(), k -> new ArrayList<>()).add(decl);
		}

		return res;
	}

	public List<DeclarationWithPlotCode> getPlotDeclarationsByLanduse(Long cropPlanId,
			LocalDateTime versionDt, AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo, String plotCode, String landUseCode) {
		List<String> plotCodes = new ArrayList<>();
		plotCodes.add(plotCode);

		var ret = declarationsDAO.getPlotsDeclarationsInternal(cropPlanId, plotCodes, versionDt, pointInTimeFrom, pointInTimeTo);
		ret = ret.stream().filter(decl -> decl.getLanduse().getCode().equals(landUseCode)).collect(toList());

		return ret;
	}

	public Declaration getDeclaration(RuntimeEnvironment env, String plotCode, String businessId, Long cropPlanId, LocalDateTime versionDt, Long declId) {
		DeclarationWithPlotCode decl = declarationsDAO.getDeclaration(declId);
		decl.setPlotCode(plotCode);
		fillDeclarationsData(env, List.of(decl), businessId, cropPlanId, versionDt, new PlotDataToInclude());
		return decl;
	}
	
	public Declaration getDeclarationByDeclCode(RuntimeEnvironment env, String plotCode, String businessId, Long cropPlanId, LocalDateTime versionDt, String declCode) {
		DeclarationWithPlotCode decl = declarationsDAO.getDeclarationByDeclCode(cropPlanId, plotCode, versionDt, declCode);
		decl.setPlotCode(plotCode);
		fillDeclarationsData(env, List.of(decl), businessId, cropPlanId, versionDt, new PlotDataToInclude());
		return decl;
	}

	public List<Declaration> getPlotDeclarations(RuntimeEnvironment env, String businessId, Long cropPlanId, String plotCode, String excludedDeclCode,
			LocalDateTime versionDt, AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo) {
		List<DeclarationWithPlotCode> decls = declarationsDAO.getPlotDeclarations(cropPlanId, plotCode, excludedDeclCode, versionDt, pointInTimeFrom,
				pointInTimeTo);
		fillDeclarationsData(env, decls, businessId, cropPlanId, versionDt, new PlotDataToInclude());
		return decls.stream()
				.sorted(Comparator.comparing(Declaration::getSorting, Comparator.nullsLast(Comparator.naturalOrder())))
				.map(decl -> (Declaration) decl)
				.collect(toList());
	}
	
	public void fillDeclarationsData(RuntimeEnvironment env, List<DeclarationWithPlotCode> decls, String businessId, Long cropPlanId, LocalDateTime versionDt,
			PlotDataToInclude plotDataToInclude) {
		fillLandUsesData(env, businessId, cropPlanId, versionDt, decls, plotDataToInclude);
		
		// load permanent crop forms
		List<PermanentCropFormWithDeclCode> pcfs = new ArrayList<>();
		List<LandUseAdditionalDataFieldWithPlotCode> luAddDeclFields = new ArrayList<>();
		UnmodifiableIterator<List<DeclarationWithPlotCode>> partitions = Iterators.partition(decls.iterator(), 666);
		partitions.forEachRemaining(partition -> {
			List<String> declCodes = partition.stream()
				.map(BaseDeclaration::getDeclCode)
				.collect(toList());
			pcfs.addAll(cropPlansDAO.getPermanentCropForms(declCodes, null, cropPlanId, versionDt));
			
			luAddDeclFields.addAll(cropPlansDAO.getLandUseAdditionalDeclarationFields(env.getTenantId(), env.getLocale().getLanguage(), null, cropPlanId, declCodes, versionDt));
		});
		Map<String, List<PermanentCropFormWithDeclCode>> pcfsMap = pcfs.stream()
				.collect(groupingBy(PermanentCropFormWithDeclCode::getPlotCodeDeclCodeKey));
		Map<String, List<LandUseAdditionalDataFieldWithPlotCode>> luAddDeclFieldsMap = luAddDeclFields.stream()
				.collect(groupingBy(LandUseAdditionalDataFieldWithPlotCode::getPlotCodeDeclCodeKey));
		
		List<String> externalCodeList = pcfs.stream()
				.filter(pcf-> pcf.getPermanentCropFormData() != null)
				.map(pcf-> pcf.getPermanentCropFormData().getExternalCode())
				.distinct()
				.collect(toList());
		List<PermanentCropFormExternalCodeDecode> externalCodeDecodeList = getPermanentCropFormExternalCodeDescription(
				 env, businessId, cropPlanId, externalCodeList);

		decls.forEach(d -> {
			List<PermanentCropFormWithDeclCode> declPcfs = pcfsMap.get(d.getPlotCodeDeclCodeKey());
			if (declPcfs != null) {
				d.setPermanentCropForms(
						declPcfs.stream().map(pcf->{ 
						List<PermanentCropFormExternalCodeDecode> externalDescriptionList = externalCodeDecodeList.stream().filter(externalCodeDecode-> externalCodeDecode.getCode().equals(pcf.getPermanentCropFormData().getExternalCode())).collect(toList());
						if (!externalDescriptionList.isEmpty()) {
							PermanentCropFormData newPcf = pcf.getPermanentCropFormData();
							newPcf.setExternalDescription(externalDescriptionList.get(0).getDescription());
							d.setSorting(externalDescriptionList.get(0).getSorting());
							pcf.setPermanentCropFormData(newPcf);
						}
						return pcf;
					}).collect(toList())
				);
			}
			
			if (plotDataToInclude.getAnomalies()) {
				d.setAnomalies(validatorDAO.getAnomaliesByObjectType(cropPlanId, versionDt, d.getDeclCode(), AnomalyObjectType.DECLARATION, 
					env.getTenantId(), env.getLocale().getLanguage()));
			} else {
				d.setAnomalies(new ArrayList<>());
			}
			
			if (plotDataToInclude.getDeclsPesticides()) {
				d.setPesticides(pesticidesService
					.getPesticideEntriesPaged(env, businessId, cropPlanId, env.getTenantId(), versionDt, d.getPlotCode(), d.getDeclCode(), null, null, 9999)
					.getRecords());
			} else {
				d.setPesticides(new ArrayList<>());
			}
		
			List<LandUseAdditionalDataFieldWithPlotCode> fieldCodes = luAddDeclFieldsMap.get(d.getPlotCodeDeclCodeKey());
			if (fieldCodes != null) {
				d.setFieldsCodes(fieldCodes.stream()
						.map(fc -> (LandUseAdditionalDataField) fc)
						.collect(toList()));
			}
		});
	}
	
	private List<PermanentCropFormExternalCodeDecode> getPermanentCropFormExternalCodeDescription(
			RuntimeEnvironment env, String businessId, Long cropPlanId, List<String> externalCodeList) {
		return pluginManager.getCropPlanPlugin(businessId, cropPlanId, env.getTenantId()).getPermanentCropFormExternalCodeDescription(env, externalCodeList);
	}
	
	public void fillLandUsesData(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime versionDt,
			List<? extends Declaration> decls, PlotDataToInclude plotDataToInclude) {
		var cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId());

		Map<String, List<Declaration>> declsMap = decls.stream()
				.collect(groupingBy(decl -> decl.getLanduse().getCode()));

		UnmodifiableIterator<List<String>> partitions = Iterators.partition(declsMap.keySet().iterator(), 666);
		partitions.forEachRemaining(partition -> {
			List<LandUse> landUses = cropCodesPlugin.getLandUses(env, partition);
			landUses.forEach(l -> declsMap.get(l.getCode())
					.forEach(decl -> decl.getLanduse().setDescription(l.getDescription())));
			
			if (plotDataToInclude.getDeclsStyle()) {
				Map<String, Style> styles = cropCodesPlugin.getLandUseStyles(env, partition);
				styles.keySet().forEach(code -> declsMap.get(code)
						.forEach(decl -> decl.setStyle(styles.get(code))));
			}
		});
	}

	public void insertDeclarationWithoutValidation(RuntimeEnvironment env, PlotTimeWindowParams params,
			String landUseCode, Double areaPerc, String dayFromPrecision, List<ParcelIntersection> parcels,
			List<InsertPermanentCropForm> permanentCropForms, List<LandUseAdditionalDataField> fieldsCodes) {
		insertDeclaration(env, params, landUseCode, areaPerc, dayFromPrecision, parcels, permanentCropForms, fieldsCodes, null, false, true, false, false, true);
	}

	public EditDeclarationResult insertDeclaration(RuntimeEnvironment env, PlotTimeWindowParams params,
			String landUseCode, Double areaPerc, String dayFromPrecision, List<ParcelIntersection> parcels,
			List<InsertPermanentCropForm> permanentCropForms, List<LandUseAdditionalDataField> fieldsCodes, 
			List<Declaration> plotDeclaration, boolean removeExistingDeclarations, 
			boolean ignoreDeclValidationWarnings, boolean ignoreAllDeclValidationMessages, boolean withTolerance, boolean ignoreValidation) {

		this.validateDecl(env, landUseCode, areaPerc, params.getBusinessId(), params.getCropPlanId(), params.getPointInTimeFrom());
		
		var bds = new ArrayList<ValidatorBoundedDeclaration>();
		var parcelCodes = parcels.stream().map(ParcelIntersection::getCode).collect(toList());

		var transId = ignoreValidation ? null : params.getVersionDt();
		
		if (removeExistingDeclarations) {
			var deleteDt = params.getVersionDt().minus(Duration.ofMillis(1));
			plotDeclaration.forEach(d -> {
				if (d.getFromDate().isBeforeOrEqual(params.getPointInTimeTo()) && d.getToDate().isAfterOrEqual(params.getPointInTimeFrom())) {
					cropPlansDAO.deleteDeclaration(d.getDeclCode(), params.getCropPlanId(), params.getPlotCode(), deleteDt,
							env.getUserId(), params.getVersionDt());
					
					bds.add(new ValidatorBoundedDeclaration(params.getPlotCode(), parcelCodes, d.getDeclId(), d.getDeclCode(), d.getLanduse().getCode(),
							d.getAreaPerc(), d.getFromDate().toLocalDate(), d.getToDate().toLocalDate(), d.getFromDatePrecision(), ValidatorOperation.DELETE));
				}
			});
		}

		final Double tolleranceMultiplier = withTolerance ? calcToleranceMultiplier(params) : 1d;

		var newAreaPerc = areaPerc * tolleranceMultiplier;

		Long declId = cropPlansDAO.insertDeclaration(params.getCropPlanId(), params.getPlotCode(),
				params.getPointInTimeFrom(), dayFromPrecision, params.getPointInTimeTo(), landUseCode,
				newAreaPerc, permanentCropForms, fieldsCodes, env.getUserId(), params.getVersionDt(), transId);
		
		bds.add(new ValidatorBoundedDeclaration(params.getPlotCode(), parcelCodes, declId, String.valueOf(declId), landUseCode, newAreaPerc,
				params.getPointInTimeFrom().toLocalDate(), params.getPointInTimeTo().toLocalDate(), dayFromPrecision, ValidatorOperation.INSERT));

		if (ignoreValidation) {
			return null;
		}

		var support = getInsertDeclarationValidatorSupport(env, params, bds, declId);
		return validatorService.validate(env, support, ignoreDeclValidationWarnings, false, params.getBusinessId(), params.getCropPlanId(),
				params.getVersionDt(), params.getVersionDt());
	}

	private ValidatorSupport<EditDeclarationResult> getInsertDeclarationValidatorSupport(RuntimeEnvironment env, PlotTimeWindowParams params, List<ValidatorBoundedDeclaration> bds, Long declId) {
		return new ValidatorSupport<EditDeclarationResult>() {
			@Override
			public EditDeclarationResult getResult(List<ValidationMessage> msgs, List<String> updatedAnomaliesPlotCodes) {
				if (msgs != null && !msgs.isEmpty())
					return new EditDeclarationResult(msgs);
				else
					return new EditDeclarationResult(getDeclaration(env, params.getPlotCode(), params.getBusinessId(), params.getCropPlanId(),
							params.getVersionDt(), declId)); // TODO [improve-reload-all] return updated plots
			}

			@Override
			public ValidatorData getValidatorData() {
				var data = new ValidatorData();
				data.setBusinessId(params.getBusinessId());
				data.setCropPlanId(params.getCropPlanId());
				LatestSync latestSync = syncDAO.getLatestSync(params.getCropPlanId());
				data.setReferenceDt(latestSync != null && latestSync.getReferenceDate() != null ? latestSync.getReferenceDate().toLocalDate() : null);
				data.setPlots(new ArrayList<>());
				/*if (sourceDeclCode != null) {
					String sourcePlotCode = cropPlansDAO.getPlotCodeByDeclCode(params.getCropPlanId(), sourceDeclCode, params.getVersionDt());
					Declaration sourceDecl = cropPlansDAO.getDeclarationByDeclCode(params.getCropPlanId(), null, params.getVersionDt(), sourceDeclCode);
					List<String> sourceParcels = cropPlansDAO.getIntersectedParcelCodesByPlotCode(params.getCropPlanId(), sourcePlotCode, params.getVersionDt(),
							sourceDecl.getFromDate(), sourceDecl.getToDate());
					bds.add(new ValidatorBoundedDeclaration(sourcePlotCode, sourceParcels, sourceDecl.getDeclId(), sourceDecl.getDeclCode(), sourceDecl.getLanduse().getCode(),
							sourceDecl.getAreaPerc(), sourceDecl.getFromDate().get(), sourceDecl.getToDate().get(), sourceDecl.getFromDatePrecision(), ValidatorOperation.UPDATE));
				}*/
				data.setDeclarations(bds);

				return data;
			}
		};
	}

	public EditDeclarationResult insertDeclarations(RuntimeEnvironment env, PlotsTimeWindowParams params, 
			String landUseCode, String dayFromPrecision, List<InsertPermanentCropForm> permanentCropForms, 
			List<LandUseAdditionalDataField> fieldsCodes, boolean removeExistingDeclarations, boolean ignoreDeclValidationWarnings,
			boolean ignoreAllDeclValidationMessages) {
		List<ValidatorBoundedDeclaration> bds = new ArrayList<>();

		Optional<Double> lowestArea = params.getPlotsData().stream().map(PlotsTimeWindowPlotData::getAreaPerc).sorted().findFirst();
		validateDecl(env, landUseCode, lowestArea.orElse(-1d), params.getBusinessId(), params.getCropPlanId(), params.getPointInTimeFrom());
		
		var deleteDt = params.getVersionDt().minus(Duration.ofMillis(1));
		params.getPlotsData().forEach(pd -> {		
			if (removeExistingDeclarations) {
				pd.getDeclarations().forEach(d -> {
					if ((d.getFromDate().isBeforeOrEqual(params.getPointInTimeTo()) && d.getToDate().isAfterOrEqual(params.getPointInTimeFrom()))) {
						cropPlansDAO.deleteDeclaration(d.getDeclCode(), params.getCropPlanId(), pd.getPlotCode(), deleteDt,
								env.getUserId(), params.getVersionDt());
						
						bds.add(new ValidatorBoundedDeclaration(pd.getPlotCode(), pd.getParcelCodes(), d.getDeclId(), d.getDeclCode(), d.getLanduse().getCode(),
								d.getAreaPerc(), d.getFromDate().toLocalDate(), d.getToDate().toLocalDate(), d.getFromDatePrecision(), ValidatorOperation.DELETE));
					}
				});
			}
			
			Long declId = cropPlansDAO.insertDeclaration(params.getCropPlanId(), pd.getPlotCode(),
					params.getPointInTimeFrom(), dayFromPrecision, params.getPointInTimeTo(), landUseCode, pd.getAreaPerc(),
					permanentCropForms, fieldsCodes, env.getUserId(), params.getVersionDt(), params.getVersionDt());

			bds.add(new ValidatorBoundedDeclaration(pd.getPlotCode(), pd.getParcelCodes(), declId, String.valueOf(declId), landUseCode,
					pd.getAreaPerc(), params.getPointInTimeFrom().toLocalDate(), params.getPointInTimeTo().toLocalDate(), dayFromPrecision, ValidatorOperation.INSERT));
		});

		var support = getInsertDeclarationsValidatorSupport(params, bds);
		return validatorService.validate(env, support, ignoreDeclValidationWarnings, ignoreAllDeclValidationMessages, params.getBusinessId(), params.getCropPlanId(),
				params.getVersionDt(), params.getVersionDt());
	}

	private ValidatorSupport<EditDeclarationResult> getInsertDeclarationsValidatorSupport(PlotsTimeWindowParams params, List<ValidatorBoundedDeclaration> bds) {
		return new ValidatorSupport<EditDeclarationResult>() {
			@Override
			public EditDeclarationResult getResult(List<ValidationMessage> msgs, List<String> updatedAnomaliesPlotCodes) {
				if (msgs != null && !msgs.isEmpty())
					return new EditDeclarationResult(msgs);
				else
					return new EditDeclarationResult(); // TODO [improve-reload-all] return updated plots
			}

			@Override
			public ValidatorData getValidatorData() {
				var data = new ValidatorData();
				data.setBusinessId(params.getBusinessId());
				data.setCropPlanId(params.getCropPlanId());
				LatestSync latestSync = syncDAO.getLatestSync(params.getCropPlanId());
				data.setReferenceDt(latestSync != null && latestSync.getReferenceDate() != null ? latestSync.getReferenceDate().toLocalDate() : null);
				data.setPlots(new ArrayList<>());
				data.setDeclarations(bds);
				return data;
			}
		};
	}

	public EditDeclarationResult updateDeclaration(RuntimeEnvironment env, PlotTimeWindowParams params, String declCode,
			String landUseCode, Double areaPerc, String dayFromPrecision, List<ParcelIntersection> parcels, List<EditPermanentCropForm> permanentCropForms,
			List<LandUseAdditionalDataField> fieldsCodes, boolean ignoreDeclValidationWarnings, boolean ignoreAllDeclValidationMessages, boolean withTolerance) {

		this.validateDecl(env, landUseCode, areaPerc, params.getBusinessId(), params.getCropPlanId(), params.getPointInTimeFrom());

		final Double tolleranceMultiplier;
		
		if (withTolerance)
			tolleranceMultiplier = calcToleranceMultiplier(params);
		else
			tolleranceMultiplier = 1d;

		var newAreaPerc = areaPerc * tolleranceMultiplier;

		var oldDecl = declarationsDAO.getDeclarationByDeclCode(params.getCropPlanId(), params.getPlotCode(), params.getVersionDt(), declCode);
		var declId = cropPlansDAO.updateDeclaration(declCode, params.getCropPlanId(), params.getPlotCode(), params.getPointInTimeFrom(),
				dayFromPrecision, params.getPointInTimeTo(), landUseCode,
				newAreaPerc, permanentCropForms, fieldsCodes, false, env.getUserId(), params.getVersionDt(), params.getVersionDt());

		var support = new ValidatorSupport<EditDeclarationResult>() {
			@Override
			public EditDeclarationResult getResult(List<ValidationMessage> msgs, List<String> updatedAnomaliesPlotCodes) {
				if (msgs != null && !msgs.isEmpty())
					return new EditDeclarationResult(msgs);
				else
					return new EditDeclarationResult(getDeclaration(env, params.getPlotCode(), params.getBusinessId(), params.getCropPlanId(),
							params.getVersionDt(), declId)); // TODO [improve-reload-all] return updated plots
			}

			@Override
			public ValidatorData getValidatorData() {
				var data = new ValidatorData();
				data.setBusinessId(params.getBusinessId());
				data.setCropPlanId(params.getCropPlanId());
				LatestSync latestSync = syncDAO.getLatestSync(params.getCropPlanId());
				data.setReferenceDt(latestSync != null && latestSync.getReferenceDate() != null ? latestSync.getReferenceDate().toLocalDate() : null);
				data.setPlots(new ArrayList<>());

				var bds = new ArrayList<ValidatorBoundedDeclaration>();
				var parcelCodes = parcels.stream().map(ParcelIntersection::getCode).collect(toList());
				bds.add(new ValidatorBoundedDeclaration(params.getPlotCode(), parcelCodes, oldDecl.getDeclId(), declCode, oldDecl.getLanduse().getCode(),
						oldDecl.getAreaPerc(),
						oldDecl.getFromDate().toLocalDate(), oldDecl.getToDate().toLocalDate(), dayFromPrecision, ValidatorOperation.DELETE));
				bds.add(new ValidatorBoundedDeclaration(params.getPlotCode(), parcelCodes, declId, declCode, landUseCode, newAreaPerc,
						params.getPointInTimeFrom().toLocalDate(), params.getPointInTimeTo().toLocalDate(), dayFromPrecision, ValidatorOperation.INSERT));
				data.setDeclarations(bds);

				return data;
			}
		};
		return validatorService.validate(env, support, ignoreDeclValidationWarnings, ignoreAllDeclValidationMessages, params.getBusinessId(), params.getCropPlanId(),
				params.getVersionDt(), params.getVersionDt());
	}
	
	public EditDeclarationResult mergeDeclarations(RuntimeEnvironment env, PlotTimeWindowParams params, List<ParcelIntersection> parcels, 
			boolean ignoreDeclValidationWarnings) {
		var transId = params.getVersionDt();
		var deleteDt = params.getVersionDt().minus(Duration.ofMillis(1));
		
		var parcelCodes = parcels.stream().map(ParcelIntersection::getCode).collect(toList());
		List<ValidatorBoundedDeclaration> bds = new ArrayList<>();
		
		var decls = getPlotDeclarations(env, params.getBusinessId(), params.getCropPlanId(), params.getPlotCode(), null, params.getVersionDt(), 
				params.getPointInTimeFrom(), params.getPointInTimeTo());
		decls = decls.stream()
				.filter(decl -> decl.getPesticides() == null || decl.getPesticides().isEmpty())
				.filter(decl -> {
					var luc = cropCodeService.getLandUseCode(env, params.getBusinessId(), params.getCropPlanId(), decl.getLanduse().getCode(), null, decl.getFromDate());
					return !luc.getLandUseClass().getPercFixedTo100();
				})
				.collect(toList());
		
		List<MergedDeclaration> mergedDecls = getMergedDecls(decls);
		
		mergedDecls.forEach(md -> {
			if (md.getSourceDeclarations().size() > 1) {
				ArrayList<Long> mergedDeclsId = new ArrayList<>();
				md.getSourceDeclarations().forEach(sd -> {
					cropPlansDAO.deleteDeclaration(sd.getDeclCode(), params.getCropPlanId(), params.getPlotCode(), deleteDt, env.getUserId(), transId);
					
					bds.add(new ValidatorBoundedDeclaration(params.getPlotCode(), parcelCodes, sd.getDeclId(), sd.getDeclCode(), sd.getLanduse().getCode(),
							sd.getAreaPerc(), sd.getFromDate().toLocalDate(), sd.getToDate().toLocalDate(), sd.getFromDatePrecision(), ValidatorOperation.DELETE));
					mergedDeclsId.add(sd.getDeclId());
				});
				
				var decl = md.getDeclaration();
				
				List<InsertPermanentCropForm> pcfs = new ArrayList<>();
				decl.getPermanentCropForms().forEach(pcf -> {
					var ipcf = new InsertPermanentCropForm();
					ipcf.setFormType(pcf.getFormType());
					var pcfd = pcf.getPermanentCropFormData();
					//pcfd.setExternalCode(null); // TODO !!! è corretto preservare l'externalCode di una decl (casuale) tra quelle raggruppate?
					ipcf.setPermanentCropFormData(pcfd);
					pcfs.add(ipcf);
				});
				
				List<LandUseAdditionalDataField> fieldsCodes = decl.getFieldsCodes();
				
				Long declId = cropPlansDAO.insertDeclaration(params.getCropPlanId(), params.getPlotCode(),
						decl.getFromDate(), decl.getFromDatePrecision(), decl.getToDate(), decl.getLanduse().getCode(),
						decl.getAreaPerc(), pcfs, fieldsCodes, env.getUserId(), params.getVersionDt(), transId);
				bds.add(new ValidatorBoundedDeclaration(params.getPlotCode(), parcelCodes, declId, String.valueOf(declId), decl.getLanduse().getCode(), 
						decl.getAreaPerc(),	decl.getFromDate().toLocalDate(), decl.getToDate().toLocalDate(), decl.getFromDatePrecision(), ValidatorOperation.INSERT));

				// Add the merged operation to the history (CRPL_MERGED_DECLS)
				for (var source_decl_id : mergedDeclsId) {
					cropPlansDAO.insertMergedDecl(declId, source_decl_id, params.getCropPlanId(), params.getPlotCode(), params.getVersionDt(), transId);
				}
			}
		});
		
		var support = new ValidatorSupport<EditDeclarationResult>() {
			@Override
			public EditDeclarationResult getResult(List<ValidationMessage> msgs, List<String> updatedAnomaliesPlotCodes) {
				if (msgs != null && !msgs.isEmpty())
					return new EditDeclarationResult(msgs);
				else
					return new EditDeclarationResult(); // TODO [improve-reload-all] return updated plots
			}

			@Override
			public ValidatorData getValidatorData() {
				var data = new ValidatorData();
				data.setBusinessId(params.getBusinessId());
				data.setCropPlanId(params.getCropPlanId());
				LatestSync latestSync = syncDAO.getLatestSync(params.getCropPlanId());
				data.setReferenceDt(latestSync != null && latestSync.getReferenceDate() != null ? latestSync.getReferenceDate().toLocalDate() : null);
				data.setPlots(new ArrayList<>());
				data.setDeclarations(bds);
				return data;
			}
		};
		return validatorService.validate(env, support, ignoreDeclValidationWarnings, false, params.getBusinessId(), params.getCropPlanId(),
				params.getVersionDt(), params.getVersionDt());
	}

	private List<MergedDeclaration> getMergedDecls(List<Declaration> decls) {
		List<MergedDeclaration> mergedDecls = new ArrayList<>();
		
		for(var decl : decls) {
			boolean found = mergeDecl(mergedDecls, decl);
			
			if (!found) {
				var md = new MergedDeclaration();
				md.setDeclaration(new Declaration(null, null, decl.getLanduse(), decl.getAreaPerc(), decl.getStyle(), 
						decl.getFromDate(), decl.getFromDatePrecision(), decl.getToDate(), 
						decl.getPermanentCropForms(), new ArrayList<>(), new ArrayList<>(), decl.getFieldsCodes()));
				md.setSourceDeclarations(new ArrayList<>());
				md.getSourceDeclarations().add(decl);
				mergedDecls.add(md);
			}
		}
		
		return mergedDecls;
	}

	private boolean mergeDecl(List<MergedDeclaration> mergedDecls, Declaration decl) {
		for (var mergedDecl : mergedDecls) {
			var md = mergedDecl.getDeclaration();
			if (decl.getLanduse().getCode().equals(md.getLanduse().getCode()) &&
					decl.getFromDate().equals(md.getFromDate()) &&
					decl.getFromDatePrecision().equals(md.getFromDatePrecision()) &&
					decl.getToDate().equals(md.getToDate())) {
				
				// Check if the merged declarations have the same data 
				boolean mergedDeclsHaveSameData;
				
				// Check permanent crop forms data
				mergedDeclsHaveSameData = (decl.getPermanentCropForms().size() == md.getPermanentCropForms().size()); // same size
				mergedDeclsHaveSameData = mergedDeclsHaveSameData && (decl.getPermanentCropForms().stream()
						.filter(pcf -> !md.getPermanentCropForms().contains(pcf))
						.collect(toList())
						.isEmpty());
				
				// Check additional declaration land use fields 
				mergedDeclsHaveSameData = mergedDeclsHaveSameData && (decl.getFieldsCodes().size() == md.getFieldsCodes().size()); // same size
				mergedDeclsHaveSameData = mergedDeclsHaveSameData && (decl.getFieldsCodes().stream()
						.filter(mfc -> !md.getFieldsCodes().contains(mfc))
						.collect(toList())
						.isEmpty());
				
				if (mergedDeclsHaveSameData) {
					md.setAreaPerc(md.getAreaPerc() + decl.getAreaPerc());
					mergedDecl.getSourceDeclarations().add(decl);
					return true;
				}
			}
		}
		return false;
	}

	public EditDeclarationResult deleteDeclaration(RuntimeEnvironment env, PlotTimeWindowParams params, Declaration decl,
			List<ParcelIntersection> parcels, boolean ignoreDeclValidationWarnings, boolean ignoreAllDeclValidationMessages) {
		var deleteDt = params.getVersionDt().minus(Duration.ofMillis(1));
		cropPlansDAO.deleteDeclaration(decl.getDeclCode(), params.getCropPlanId(), params.getPlotCode(), deleteDt, env.getUserId(), params.getVersionDt());

		var support = new ValidatorSupport<EditDeclarationResult>() {
			@Override
			public EditDeclarationResult getResult(List<ValidationMessage> msgs, List<String> updatedAnomaliesPlotCodes) {
				if (msgs != null && !msgs.isEmpty())
					return new EditDeclarationResult(msgs);
				else
					return new EditDeclarationResult(); // TODO [improve-reload-all] return updated plots
			}

			@Override
			public ValidatorData getValidatorData() {
				var data = new ValidatorData();
				data.setBusinessId(params.getBusinessId());
				data.setCropPlanId(params.getCropPlanId());
				LatestSync latestSync = syncDAO.getLatestSync(params.getCropPlanId());
				data.setReferenceDt(latestSync != null && latestSync.getReferenceDate() != null ? latestSync.getReferenceDate().toLocalDate() : null);
				data.setPlots(new ArrayList<>());

				var bds = new ArrayList<ValidatorBoundedDeclaration>();
				var parcelCodes = parcels.stream().map(ParcelIntersection::getCode).collect(toList());
				bds.add(new ValidatorBoundedDeclaration(params.getPlotCode(), parcelCodes, decl.getDeclId(), decl.getDeclCode(), decl.getLanduse().getCode(),
						decl.getAreaPerc(),
						decl.getFromDate().toLocalDate(), decl.getToDate().toLocalDate(), decl.getFromDatePrecision(), ValidatorOperation.DELETE));
				data.setDeclarations(bds);

				return data;
			}
		};
		return validatorService.validate(env, support, ignoreDeclValidationWarnings, ignoreAllDeclValidationMessages, params.getBusinessId(), params.getCropPlanId(),
				params.getVersionDt(), params.getVersionDt());
	}

	public EditDeclarationResult deletePlotsDeclarations(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime versionDt,
			List<Plot> plots, boolean ignoreDeclValidationWarnings) {

		var deleteDt = versionDt.minus(Duration.ofMillis(1));

		plots.forEach(plot -> plot.getDecls().forEach(decl -> cropPlansDAO.deleteDeclaration(decl.getDeclCode(), cropPlanId, plot.getPlotCode(), deleteDt,
				env.getUserId(), versionDt)));

		var support = new ValidatorSupport<EditDeclarationResult>() {
			@Override
			public EditDeclarationResult getResult(List<ValidationMessage> msgs, List<String> updatedAnomaliesPlotCodes) {
				if (msgs != null && !msgs.isEmpty())
					return new EditDeclarationResult(msgs);
				else
					return new EditDeclarationResult(); // TODO [improve-reload-all] return updated plots
			}

			@Override
			public ValidatorData getValidatorData() {
				var data = new ValidatorData();
				data.setBusinessId(businessId);
				data.setCropPlanId(cropPlanId);
				LatestSync latestSync = syncDAO.getLatestSync(cropPlanId);
				data.setReferenceDt(latestSync != null && latestSync.getReferenceDate() != null ? latestSync.getReferenceDate().toLocalDate() : null);
				data.setPlots(new ArrayList<>());

				var bds = new ArrayList<ValidatorBoundedDeclaration>();

				plots.forEach(plot -> {
					var parcelCodes = plot.getParcelIntersections().stream().map(ParcelIntersection::getCode).collect(toList());
					plot.getDecls()
							.forEach(decl -> bds.add(new ValidatorBoundedDeclaration(plot.getPlotCode(), parcelCodes, decl.getDeclId(), decl.getDeclCode(),
									decl.getLanduse().getCode(),
									decl.getAreaPerc(),
									decl.getFromDate().toLocalDate(), decl.getToDate().toLocalDate(), decl.getFromDatePrecision(), ValidatorOperation.DELETE)));
				});

				data.setDeclarations(bds);

				return data;
			}
		};

		return validatorService.validate(env, support, ignoreDeclValidationWarnings, false, businessId, cropPlanId,
				versionDt, versionDt);
	}
	
	public Double calcToleranceMultiplier(PlotTimeWindowParams params) {
		var tol = cropPlanConfigService.getPerimeterMultiplierAreaTolerance(params.getCropPlanId());

		var rawPlotResponse = cropPlansDAO.infinite(
			() -> cropPlansDAO.getPlotsInternal(params.getCropPlanId(), params.getDomainZoneId(), params.getVersionDt(), params.getPointInTimeFrom(), params.getPointInTimeTo(), params.getPlotCode(), null, null),
			null,
			1).getRecords();
		
		if (rawPlotResponse.size() != 1)
			throw new BadRequestException("The plot " + params.getPlotCode() + " was not found");

		Plot plot = rawPlotResponse.get(0);
		Integer originalPlotAreaSqm = plot.getAreaSqm();
		Double plotAreaSqmWithTolerance = originalPlotAreaSqm + plot.getGeom().getLength() * tol;

		return plotAreaSqmWithTolerance / originalPlotAreaSqm;	
	}

	protected void validateDecl(RuntimeEnvironment env, String landUseCode, Double areaPerc, String businessId, Long cropPlanId, AbsoluteDate pointInTime) {
		if (areaPerc < 0) {
			throw new InvalidDeclAreaPercZeroException();
		}
		if (areaPerc == 0. && !cropPlanConfigService.allowDeclsPercToZero(cropPlanId)) {
			throw new InvalidDeclAreaPercZeroException();
		}
		cropCodeService.getLandUseCode(env, businessId, cropPlanId, landUseCode, null, pointInTime);
	}
	
	public EditDeclarationsResult updateDeclarationsFields(RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId,
			LocalDateTime currentDt, EditDeclarationsFieldsPayload payload, boolean ignoreDeclValidationWarnings, boolean isBackOffice) {

		cropCodeService.getLandUseCode(env, businessId, cropPlanId, payload.getLanduseCode(), null, payload.getPointInTime());
		boolean lockDeclarationsFieldsIfExternal = cropPlanConfigService.isLockDeclarationsFieldsIfExternal(cropPlanId);

		List<DeclarationWithPlotCode> oldDecls = cropPlansDAO.findDeclarationsByLandUseCodeAndDomainZoneId(
				cropPlanId, currentDt, payload.getPointInTime(), payload.getPointInTime(), payload.getLanduseCode(), domainZoneId);

		Map<String, List<DeclarationWithPlotCode>> oldPlotDeclsMap = oldDecls.stream()
				.collect(groupingBy(DeclarationWithPlotCode::getPlotCode, toList()));

		cropPlansDAO.useTransaction(h -> {
			for (Entry<String, List<DeclarationWithPlotCode>> plotDecls : oldPlotDeclsMap.entrySet()) {

				String plotCode = plotDecls.getKey();
				List<String> declCodes = plotDecls.getValue().stream().map(BaseDeclaration::getDeclCode).collect(toList());
				List<PermanentCropFormWithDeclCode> oldPermanentCropForms = h.getPermanentCropForms(
						declCodes, plotCode, cropPlanId, currentDt);

				Map<String, Map<String, List<PermanentCropFormWithDeclCode>>> declFormTypePCF = oldPermanentCropForms.stream()
						.collect(groupingBy(PermanentCropFormWithDeclCode::getDeclCode,
								groupingBy(PermanentCropFormWithDeclCode::getFormType, toList())));

				for (DeclarationWithPlotCode oldDecl : plotDecls.getValue()) {
					String declCode = oldDecl.getDeclCode();

					Optional<Map<String, List<PermanentCropFormWithDeclCode>>> optDeclPCF = Optional.of(declFormTypePCF).map(m -> m.get(declCode));

					if (lockDeclarationsFieldsIfExternal && !isBackOffice
							&& optDeclPCF.map(Map::values).stream()
							.flatMap(Collection::stream)
							.flatMap(Collection::stream)
							.map(PermanentCropForm::getPermanentCropFormData)
							.map(PermanentCropFormData::getExternalCode)
							.anyMatch(StringUtils::isNotBlank)) {
						log.debug("preserve external decl '{}' of plot '{}' of plan '{}'",
								oldDecl.getDeclCode(), oldDecl.getPlotCode(), cropPlanId);
						continue;
					}

					List<EditPermanentCropForm> permanentCropForms = Optional.of(payload)
							.map(EditDeclarationsFieldsPayload::getPermanentCropForms)
							.stream().flatMap(Collection::stream)
							.flatMap(ipcf -> optDeclPCF.map(m -> m.get(ipcf.getFormType()))
									.stream().flatMap(Collection::stream)
									.map(oldPCF -> {
										PermanentCropFormData newPermanentCropFormData = ipcf.getPermanentCropFormData().toBuilder()
												.externalCode(oldPCF.getPermanentCropFormData().getExternalCode())
												.subscriptionCodes(oldPCF.getPermanentCropFormData().getSubscriptionCodes())
												.build();
										return new EditPermanentCropForm(oldPCF.getFormCode(), ipcf.getFormType(), newPermanentCropFormData);
									}))
							.collect(toList());

					h.updateDeclarationFields(declCode, cropPlanId, oldDecl.getPlotCode(), payload.getLanduseCode(),
							permanentCropForms, payload.getFieldsCodes(), env.getUserId(), currentDt, currentDt);

				}
			}
		});

		var support = new ValidatorSupport<EditDeclarationsResult>() {
			@Override
			public EditDeclarationsResult getResult(List<ValidationMessage> msgs, List<String> updatedAnomaliesPlotCodes) {
				// TODO [improve-reload-all] return updated plots
				return buildEditDeclarationResult(env, businessId, cropPlanId, currentDt, oldDecls, msgs);
			}

			@Override
			public ValidatorData getValidatorData() {
				return buildValidatorData(businessId, cropPlanId, currentDt, payload.getPointInTime(), oldPlotDeclsMap);
			}
		};
		return validatorService.validate(env, support, ignoreDeclValidationWarnings, false, businessId, cropPlanId, currentDt, currentDt);
	}

	private EditDeclarationsResult buildEditDeclarationResult(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime currentDt,
			List<DeclarationWithPlotCode> oldDecls, List<ValidationMessage> msgs) {
		if (msgs != null && !msgs.isEmpty())
			return new EditDeclarationsResult(null, msgs);
		else {
			List<Declaration> decls = oldDecls.stream()
					.map(oldDecl -> getDeclaration(env, oldDecl.getPlotCode(), businessId, cropPlanId, currentDt, oldDecl.getDeclId()))
					.collect(toList());
			return new EditDeclarationsResult(decls, new ArrayList<>());
		}
	}

	private ValidatorData buildValidatorData(String businessId, Long cropPlanId, LocalDateTime currentDt, AbsoluteDate pointInTime,
			Map<String, List<DeclarationWithPlotCode>> oldPlotDeclsMap) {
		ValidatorData data = new ValidatorData();
		data.setBusinessId(businessId);
		data.setCropPlanId(cropPlanId);
		LatestSync latestSync = syncDAO.getLatestSync(cropPlanId);
		data.setReferenceDt(latestSync != null && latestSync.getReferenceDate() != null ? latestSync.getReferenceDate().toLocalDate() : null);
		data.setPlots(new ArrayList<>());

		List<ValidatorBoundedDeclaration> bds = oldPlotDeclsMap.entrySet().stream()
				.flatMap(plotDecl -> {
					List<ParcelIntersectionWithPlotId> plotsParcels = cropPlansDAO.findPlotsParcelsInternalByPlotCode(cropPlanId, plotDecl.getKey(), currentDt, pointInTime, pointInTime);
					List<String> parcelCodes = plotsParcels.stream()
							.map(ParcelIntersection::getCode)
							.collect(toList());

					return plotDecl.getValue().stream()
							.map(decl -> new ValidatorBoundedDeclaration(decl.getPlotCode(), parcelCodes, decl.getDeclId(), decl.getDeclCode(), decl.getLanduse().getCode(), decl.getAreaPerc(), decl.getFromDate().toLocalDate(), decl.getToDate().toLocalDate(), decl.getFromDatePrecision(), ValidatorOperation.UPDATE));
				}).collect(toList());

		data.setDeclarations(bds);

		return data;
	}

	public CopyDeclarationsResult copyDeclarations(RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId, LocalDateTime currentDt,
			Plot sourcePlot, List<Declaration> sourceDecls, Plot destPlot, boolean removeSourceDecls, boolean ignoreDeclValidationWarnings) {
		
		var deleteDt = currentDt.minus(Duration.ofMillis(1));
		var bds = new ArrayList<ValidatorBoundedDeclaration>();
		
		List<String> sourceParcelCodes = sourcePlot.getParcelIntersections()
				.stream()
				.map(ParcelIntersection::getCode)
				.collect(toList());
		
		List<String> destParcelCodes = destPlot.getParcelIntersections()
				.stream()
				.map(ParcelIntersection::getCode)
				.collect(toList());
		
		sourceDecls.forEach(d -> {		
			List<InsertPermanentCropForm> ipcfs = d.getPermanentCropForms().stream()
					.map(pcf -> new InsertPermanentCropForm(pcf.getFormType(), pcf.getPermanentCropFormData()))
					.collect(toList());
			
			Double newAreaPerc = d.getAreaPerc();
			if (cropPlanConfigService.isDoNotReproportionDeclsAreas(cropPlanId))
				newAreaPerc = Math.round(d.getAreaPerc()*sourcePlot.getAreaSqm())*1d/destPlot.getAreaSqm();
			
			Long declId = cropPlansDAO.insertDeclaration(cropPlanId, destPlot.getPlotCode(),
					d.getFromDate(), d.getFromDatePrecision(), d.getToDate(), d.getLanduse().getCode(), newAreaPerc,
					ipcfs, d.getFieldsCodes(), env.getUserId(), currentDt, currentDt);

			bds.add(new ValidatorBoundedDeclaration(destPlot.getPlotCode(), destParcelCodes, declId, String.valueOf(declId), d.getLanduse().getCode(),
					d.getAreaPerc(), d.getFromDate().toLocalDate(), d.getToDate().toLocalDate(), d.getFromDatePrecision(), ValidatorOperation.INSERT));
			
			if (removeSourceDecls) {
				cropPlansDAO.deleteDeclaration(d.getDeclCode(), cropPlanId, sourcePlot.getPlotCode(), deleteDt,
						env.getUserId(), currentDt);
				
				bds.add(new ValidatorBoundedDeclaration(sourcePlot.getPlotCode(), sourceParcelCodes, d.getDeclId(), d.getDeclCode(), d.getLanduse().getCode(),
						d.getAreaPerc(), d.getFromDate().toLocalDate(), d.getToDate().toLocalDate(), d.getFromDatePrecision(), ValidatorOperation.DELETE));
			}
		});
		
		var support = new ValidatorSupport<CopyDeclarationsResult>() {
			@Override
			public CopyDeclarationsResult getResult(List<ValidationMessage> msgs, List<String> updatedAnomaliesPlotCodes) {
				if (msgs != null && !msgs.isEmpty())
					return new CopyDeclarationsResult(msgs);
				else {
					return new CopyDeclarationsResult(); // TODO [improve-reload-all] return updated plots
				}
			}

			@Override
			public ValidatorData getValidatorData() {
				var data = new ValidatorData();
				data.setBusinessId(businessId);
				data.setCropPlanId(cropPlanId);
				LatestSync latestSync = syncDAO.getLatestSync(cropPlanId);
				data.setReferenceDt(latestSync != null && latestSync.getReferenceDate() != null ? latestSync.getReferenceDate().toLocalDate() : null);
				data.setPlots(new ArrayList<>());
				data.setDeclarations(bds);
				return data;
			}
		};
		return validatorService.validate(env, support, ignoreDeclValidationWarnings, false, businessId, cropPlanId,
				currentDt, currentDt);
	}

	public boolean doesConfigListHaveDuplicates(List<String> configs) {
		Set<String> seenConfigs = new HashSet<>();
		for (String config : configs) {
			if (!seenConfigs.add(config)) {
				return true;
			}
		}
		return false;
	}

	public void declMassiveFieldsUpdate(RuntimeEnvironment env, Long cropPlanId, String businessId, LocalDateTime versionDt, CropPlanDates cropPlanDates,
			AbsoluteDate pointInTime, List<String> domainZoneIds, Map<String, List<Integer>> landUseCodesWithRotation,
			List<InsertPermanentCropForm> newPermanentCropForms,
			List<LandUseAdditionalDataField> newFieldsCodes, boolean ignoreDeclValidationWarnings) {
		List<DeclRotationDto> declsToUpdate = getDeclsToUpdateMassively(cropPlanId, versionDt, cropPlanDates, pointInTime, domainZoneIds,
				landUseCodesWithRotation, ignoreDeclValidationWarnings);
		executeDeclMassiveFieldsUpdate(env, cropPlanId, businessId, versionDt, pointInTime, newPermanentCropForms, newFieldsCodes, declsToUpdate,
				ignoreDeclValidationWarnings);
	}

	private List<DeclRotationDto> getDeclsToUpdateMassively(Long cropPlanId, LocalDateTime versionDt, CropPlanDates cropPlanDates,
			AbsoluteDate pointInTime, List<String> domainZoneIds, Map<String, List<Integer>> landUseCodesWithRotation,
			boolean ignoreDeclValidationWarnings) {
		boolean areCampaignStartDateAndReferenceDateNotNull = cropPlanDates.getCampaignStartDate() != null && cropPlanDates.getReferenceDate() != null;
		boolean isRefDateEqualToPointInTime = cropPlanDates.getReferenceDate() != null && cropPlanDates.getReferenceDate().equals(pointInTime);

		boolean areAllLandUseCosesWithRotationValue = landUseCodesWithRotation.values()
				.stream()
				.allMatch(list -> list != null && !list.contains(null));

		List<DeclRotationDto> declsToUpdate = new ArrayList<>();

		// If true -> need to calculate rotation and must have all rotation defined from FE
		// If false -> no need to calculate rotation and must not have rotation defined from FE
		if (areCampaignStartDateAndReferenceDateNotNull && isRefDateEqualToPointInTime) {
			if (!areAllLandUseCosesWithRotationValue) {
				throw new BadRequestException("LandUseCodes Rotation values contain at least one null value.");
			}

			declsToUpdate.addAll(getDeclsToUpdateMassivelyWithRotationData(cropPlanId, versionDt, cropPlanDates, pointInTime, domainZoneIds,
					landUseCodesWithRotation, ignoreDeclValidationWarnings));
		} else {
			if (areAllLandUseCosesWithRotationValue) {
				throw new BadRequestException("LandUseCodes Rotation values contain at least one not null value.");
			}
			List<String> landUseCodes = new ArrayList<>(landUseCodesWithRotation.keySet());
			declsToUpdate.addAll(declarationsDAO.getPlotCodesDeclsByCropPlanAndDomainZoneIdsAndLandUseCodes(cropPlanId, versionDt, pointInTime, domainZoneIds,
					landUseCodes));
		}

		return declsToUpdate;
	}

	private List<DeclRotationDto> getDeclsToUpdateMassivelyWithRotationData(Long cropPlanId, LocalDateTime versionDt, CropPlanDates cropPlanDates,
			AbsoluteDate pointInTime, List<String> domainZoneIds, Map<String, List<Integer>> landUseCodesWithRotation,
			boolean ignoreDeclValidationWarnings) {
		List<DeclRotationDto> declsToUpdate = new ArrayList<>();

		// Get all plots on domainZoneIds
		List<PlotDeclRotationDto> plotDeclRotationDtos = getAllPlotDeclRotationDtosByDomainZoneIds(cropPlanId, domainZoneIds, versionDt,
				pointInTime);

		if (plotDeclRotationDtos.isEmpty()) {
			throw new NotFoundException("Impossible to find plots on requested domain zone ids");
		}

		List<String> plotCodes = plotDeclRotationDtos.stream()
				.map(PlotDeclRotationDto::getPlotCode)
				.collect(toList());

		AbsoluteDate campaignEndDate = AbsoluteDate.of(cropPlanDates.getCampaignStartDate().toLocalDate().plusYears(1).minusDays(1));

		// Get plot codes declarations
		List<DeclRotationDto> plotCodesDeclarations = new ArrayList<>();
		UnmodifiableIterator<List<String>> partitions = Iterators.partition(plotCodes.iterator(), 666);
		partitions.forEachRemaining(partition -> plotCodesDeclarations.addAll(declarationsDAO.getPlotCodesDeclsByCropPlanAndVersion(cropPlanId, versionDt, pointInTime, campaignEndDate, partition)));

		// Assign rotation value to declarations
		List<DeclRotationDto> plotCodesDeclarationsWithRotationValue = calculateRotationOnPlotCodesDeclarations(plotCodesDeclarations, pointInTime);
		// Filter declarations by landUseCode and rotation values
		for (Entry<String, List<Integer>> entry : landUseCodesWithRotation.entrySet()) {
			List<DeclRotationDto> filteredDeclsWithRotation = plotCodesDeclarationsWithRotationValue.stream()
					.filter(el -> el.getLandUse().getCode().equals(entry.getKey()) && entry.getValue().contains(el.getRotation())).collect(toList());
			declsToUpdate.addAll(filteredDeclsWithRotation);
		}

		return declsToUpdate;
	}

	private void executeDeclMassiveFieldsUpdate(RuntimeEnvironment env, Long cropPlanId, String businessId, LocalDateTime versionDt, AbsoluteDate pointInTime,
			List<InsertPermanentCropForm> newPermanentCropForms, List<LandUseAdditionalDataField> newFieldsCodes, List<DeclRotationDto> declsToUpdate,
			boolean ignoreDeclValidationWarnings) {
		// We need get the decl area, so we need the plot area
		// Here we will retrieve all decl's plots with area
		List<String> declPlotCodes = declsToUpdate.stream().map(DeclRotationDto::getPlotCode).distinct().toList();
		List<PlotCodeWithArea> plotCodesWithAreas = new ArrayList<>();
		UnmodifiableIterator<List<String>> partitions = Iterators.partition(declPlotCodes.iterator(), 666);
		partitions.forEachRemaining(partition -> plotCodesWithAreas.addAll(cropPlansDAO.getPlotCodesWithAreas(cropPlanId, versionDt, pointInTime, partition)));

		// Need to reuse already existing method updateDeclarationFields, that need DeclarationWithPlotCode class to operate
		List<DeclarationWithPlotCode> declarationToUpdateWithPlotCodes = mapDeclRotationDtoListToDeclarationWithPlotCodeList(declsToUpdate);

		// Group up declarations by plot code
		Map<String, List<DeclarationWithPlotCode>> declarationsGroupedByPlotCode = declarationToUpdateWithPlotCodes.stream()
				.collect(groupingBy(DeclarationWithPlotCode::getPlotCode));

		// Need to execute this all in a Transaction
		cropPlansDAO.useTransaction(h -> {
			for (Map.Entry<String, List<DeclarationWithPlotCode>> plotCodeDeclarations : declarationsGroupedByPlotCode.entrySet()) {
				// Cycle Plot Declarations
				for (DeclarationWithPlotCode plotDeclaration : plotCodeDeclarations.getValue()) {
					// There are the array of all permanent crop forms i need to edit for a declaration
					List<EditPermanentCropForm> editDeclPermanentCropForms = retrieveEditDeclPermanentCropForms(
							cropPlanId, versionDt, newPermanentCropForms, plotCodesWithAreas, h, plotDeclaration);

					// Execute the update of current decl code, adding new permanent crop form (if found) and new additional values
					h.updateDeclarationFields(plotDeclaration.getDeclCode(), cropPlanId, plotDeclaration.getPlotCode(),
							plotDeclaration.getLanduse().getCode(),
							editDeclPermanentCropForms, newFieldsCodes, env.getUserId(), versionDt, versionDt);
				}
			}
		});

		var support = new ValidatorSupport<EditDeclarationsResult>() {
			@Override
			public EditDeclarationsResult getResult(List<ValidationMessage> msgs, List<String> updatedAnomaliesPlotCodes) {
				return buildEditDeclarationResult(env, businessId, cropPlanId, versionDt, declarationToUpdateWithPlotCodes, msgs);
			}

			@Override
			public ValidatorData getValidatorData() {
				return buildValidatorData(businessId, cropPlanId, versionDt, pointInTime, declarationsGroupedByPlotCode);
			}
		};

		validatorService.validate(env, support, ignoreDeclValidationWarnings, false, businessId, cropPlanId, versionDt, versionDt);
	}

	private List<EditPermanentCropForm> retrieveEditDeclPermanentCropForms(Long cropPlanId, LocalDateTime versionDt,
			List<InsertPermanentCropForm> newPermanentCropForms, List<PlotCodeWithArea> plotCodesWithAreas,
			CropPlansDAO h, DeclarationWithPlotCode plotDeclaration) {
		
		List<EditPermanentCropForm> editDeclPermanentCropForms = new ArrayList<>();

		// Check if i received data from FE, if not, i can skip all these calculations
		if (newPermanentCropForms != null && !newPermanentCropForms.isEmpty()) {
			// Find curret decl plot code with area
			Optional<PlotCodeWithArea> currentOptionalDeclPlotWithArea = plotCodesWithAreas.stream()
					.filter(el -> el.getPlotCode().equals(plotDeclaration.getPlotCode())).findFirst();

			//	This should never happen
			if (currentOptionalDeclPlotWithArea.isEmpty()) {
				return editDeclPermanentCropForms;
			}

			// Calculare decl area sqm
			double declAreaSqm = plotDeclaration.getAreaPerc() * currentOptionalDeclPlotWithArea.get().getAreaSqm() / 100;

			// Get current declaration permanent crop forms
			// There should be one for form type
			List<PermanentCropFormWithDeclCode> currentDeclToUpdatePermanentCropForms = h.getPermanentCropForms(
					List.of(plotDeclaration.getDeclCode()),
					plotDeclaration.getPlotCode(),
					cropPlanId, versionDt);

			// When creating a declaration the permanent crop form row is not created automatically for various reasons
			// So, the current declarations does not have this row, we should create it
			// Every decl should have only 1 row for form type
			// So i need to get the current decl permanent crop form form types
			List<String> currentDeclToUpdatePermanentCropFormTypes = currentDeclToUpdatePermanentCropForms.stream()
					.map(PermanentCropForm::getFormType).distinct().collect(toList());

			// Now i need to split the new permanent crop form that the declarations has already a row, from the ones that does not have it
			List<InsertPermanentCropForm> newPermanentCropFormsWithAlreadyExistingData = newPermanentCropForms.stream()
					.filter(el -> currentDeclToUpdatePermanentCropFormTypes.contains(el.getFormType())).collect(toList());

			List<InsertPermanentCropForm> newPermanentCropFormsWithoutAlreadyExistingData = newPermanentCropForms.stream()
					.filter(el -> !currentDeclToUpdatePermanentCropFormTypes.contains(el.getFormType())).collect(toList());

			// Cycle all new permanent crop form with already existing data
			// This will edit the existing data
			for (InsertPermanentCropForm newPermanentCropFormWithAlreadyExistingData : newPermanentCropFormsWithAlreadyExistingData) {
				Optional<PermanentCropFormWithDeclCode> permanentCropForm = currentDeclToUpdatePermanentCropForms.stream()
						.filter(el -> el.getFormType().equals(newPermanentCropFormWithAlreadyExistingData.getFormType())).findFirst();

				// this should never happen
				if (permanentCropForm.isEmpty()) {
					continue;
				}

				EditPermanentCropForm editPermanentCropForm = buildEditPermanentCropForm(permanentCropForm.get(),
						newPermanentCropFormWithAlreadyExistingData, declAreaSqm);

				editDeclPermanentCropForms.add(editPermanentCropForm);
			}

			// Cycle all new permanent crop form without already existing data
			// This will create a new permanent crop form record
			for (InsertPermanentCropForm newPermanentCropFormWithoutAlreadyExistingData : newPermanentCropFormsWithoutAlreadyExistingData) {
				PermanentCropFormData newPermanentCropFormData = newPermanentCropFormWithoutAlreadyExistingData.getPermanentCropFormData();

				// This is the same calculation made on client to calculate
				// Stumps Number and Stumps Density
				// We need to do this because on client
				// This fields are calculated automatically
				if (newPermanentCropFormData.getDistanceBetweenRowsCm() != null &&
						newPermanentCropFormData.getDistanceOnTheRowCm() != null) {
					int stumpsNumber = (int) (declAreaSqm / ((newPermanentCropFormData.getDistanceBetweenRowsCm() / 100) * (
							newPermanentCropFormData.getDistanceOnTheRowCm()
									/ 100)));

					Double stumpsDensity100 = (stumpsNumber * 10000) / declAreaSqm;

					newPermanentCropFormData.setStumpsNumber(stumpsNumber);
					newPermanentCropFormData.setStumpsDensity100(stumpsDensity100);
				}

				// The updateDeclarationFields will handle the new form code providing a new one
				EditPermanentCropForm editPermanentCropForm = new EditPermanentCropForm(null,
						newPermanentCropFormWithoutAlreadyExistingData.getFormType(),
						newPermanentCropFormData);

				editDeclPermanentCropForms.add(editPermanentCropForm);
			}
		}
		return editDeclPermanentCropForms;
	}

	private static EditPermanentCropForm buildEditPermanentCropForm(PermanentCropFormWithDeclCode currentDeclToUpdatePermanentCropForm,
			InsertPermanentCropForm newPermanentCropForm, double declAreaSqm) {
		PermanentCropFormData newPermanentCropFormData = newPermanentCropForm.getPermanentCropFormData();
		newPermanentCropFormData.setExternalCode(currentDeclToUpdatePermanentCropForm.getPermanentCropFormData().getExternalCode());
		newPermanentCropFormData.setSubscriptionCodes(
				currentDeclToUpdatePermanentCropForm.getPermanentCropFormData().getSubscriptionCodes());

		// This is the same calculation made on client to calculate
		// Stumps Number and Stumps Density
		// We need to do this because on client
		// This fields are calculated automatically
		if (newPermanentCropFormData.getDistanceBetweenRowsCm() != null &&
				newPermanentCropFormData.getDistanceOnTheRowCm() != null) {
			int stumpsNumber = (int) (declAreaSqm / ((newPermanentCropFormData.getDistanceBetweenRowsCm() / 100) * (
					newPermanentCropFormData.getDistanceOnTheRowCm()
							/ 100)));

			Double stumpsDensity100 = (stumpsNumber * 10000) / declAreaSqm;

			newPermanentCropFormData.setStumpsNumber(stumpsNumber);
			newPermanentCropFormData.setStumpsDensity100(stumpsDensity100);
		}

		return new EditPermanentCropForm(currentDeclToUpdatePermanentCropForm.getFormCode(),
				newPermanentCropForm.getFormType(),
				newPermanentCropFormData);
	}

	private List<DeclarationWithPlotCode> mapDeclRotationDtoListToDeclarationWithPlotCodeList(List<DeclRotationDto> declRotationDtos) {
		return declRotationDtos.stream().map(dto -> {
			DeclarationWithPlotCode declaration = new DeclarationWithPlotCode();
			declaration.setPlotCode(dto.getPlotCode());
			declaration.setDeclId(dto.getDeclId());
			declaration.setDeclCode(dto.getDeclCode());

			LandUse landUse = new LandUse();
			landUse.setCode(dto.getLandUse().getCode());
			declaration.setLanduse(landUse);

			declaration.setAreaPerc(dto.getAreaPerc());
			declaration.setFromDate(dto.getDayFrom());
			declaration.setFromDatePrecision(dto.getDayFromPrecision());
			declaration.setToDate(dto.getDayTo());

			return declaration;
		}).collect(Collectors.toList());
	}

	private List<PlotDeclRotationDto> getAllPlotDeclRotationDtosByDomainZoneIds(Long cropPlanId, List<String> domainZoneIds, LocalDateTime versionDt,
			AbsoluteDate pointInTime) {
		String nextKey = null;
		List<PlotDeclRotationDto> plotDeclRotationDtos = new ArrayList<>();

		do {
			InfiniteListResults<PlotDeclRotationDto> plotWithDeclarationsInPointInTimeByCropPlanIdAndDomainZoneIdsAndVersionDt = declarationsDAO.infinite(
					() -> declarationsDAO.getPlotWithDeclarationsInPointInTimeByCropPlanIdAndDomainZoneIdsAndVersionDt(
							cropPlanId, domainZoneIds, versionDt, pointInTime), nextKey, 100);

			nextKey = plotWithDeclarationsInPointInTimeByCropPlanIdAndDomainZoneIdsAndVersionDt.getNextKey();

			plotDeclRotationDtos.addAll(plotWithDeclarationsInPointInTimeByCropPlanIdAndDomainZoneIdsAndVersionDt.getRecords());
		} while (nextKey != null);

		return plotDeclRotationDtos;
	}

	private List<DeclRotationDto> calculateRotationOnPlotCodesDeclarations(List<DeclRotationDto> plotCodesDeclarations, AbsoluteDate pointInTime) {
		Map<String, List<DeclRotationDto>> declarationsGrouped = plotCodesDeclarations.stream()
				.collect(Collectors.groupingBy(DeclRotationDto::getPlotCode));

		return declarationsGrouped.values().stream()
				.flatMap(declList -> {
					AtomicInteger rotation = new AtomicInteger(2);
					return declList.stream().peek(decl -> {
						if (decl.getDayFrom().isBeforeOrEqual(pointInTime) && pointInTime.isBeforeOrEqual(decl.getDayTo())) {
							decl.setRotation(1);
						} else {
							decl.setRotation(rotation.getAndIncrement());
						}
					});
				}).collect(Collectors.toList());
	}
}
