package com.abacogroup.cropplan.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import java.time.LocalDateTime;
import java.util.Optional;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.GetGeneratedKeys;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;
import org.locationtech.jts.geom.Geometry;

public interface SubdomainZoneDAO extends EnhancedSqlObject, Transactional<SubdomainZoneDAO> {


	@SqlUpdate("delete from crpl_subdomain_zone "
		+ " where dt_insert < :expireDate ")
	void deleteExpiredSubdomainZones(@Bind("expireDate") LocalDateTime expireDate);

	@SqlUpdate("insert into crpl_subdomain_zone (geom) "
			+ " values (:geom) ")
	@GetGeneratedKeys("id")
	Long insertSubdomainZone(@Bind("geom") Geometry geom);

	@SqlQuery("select geom from crpl_subdomain_zone where id = :id ")
	@RegisterBeanMapper(Geometry.class)
	Optional<Geometry> findSubdomainZoneGeomById(@Bind("id") Long id);

}
