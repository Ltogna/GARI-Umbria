package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class SyncCropPlanPayload {
    @Schema(description = "The point in time")
    private AbsoluteDate pointInTime;
}
