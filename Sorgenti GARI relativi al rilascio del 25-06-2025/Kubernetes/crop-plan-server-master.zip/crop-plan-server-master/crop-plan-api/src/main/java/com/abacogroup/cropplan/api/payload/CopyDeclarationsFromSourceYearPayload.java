package com.abacogroup.cropplan.api.payload;

import com.abacogroup.cropplan.sdk.model.Version;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CopyDeclarationsFromSourceYearPayload
{
	private Version version;
}
