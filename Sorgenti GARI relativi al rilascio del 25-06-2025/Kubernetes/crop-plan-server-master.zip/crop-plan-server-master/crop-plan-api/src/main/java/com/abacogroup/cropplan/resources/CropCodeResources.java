package com.abacogroup.cropplan.resources;

import com.abacogroup.cropplan.api.CommonAdditionalDataAndPermanentCropFormConfigs;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.dtos.LandUseCommonConfigAndValuesDto;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataConf;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandCoverFilter;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseDetails;
import com.abacogroup.cropplan.sdk.model.domain.LandCover;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.LocksService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.MaxRowsResults;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.codahale.metrics.annotation.Timed;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@Path("{tenant}/api-priv/v1/crop-codes")
@Tag(name = "PRIVATE - Crop codes resources")
@Timed
@RolesAllowed({"CRPL|USER","CRPL|EDITOR"})
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class CropCodeResources extends BaseCropPlanResource
{
	private CropCodeService cropCodeService;
	private PluginManager pluginManager;
	// private static final Logger log = LoggerFactory.getLogger(CropCodeResources.class);
	
	public CropCodeResources(BaseService baseService, CropPlanService cropPlanService, LocksService locksService, CropCodeService cropCodeService,
			ValidatorService validatorService, CropPlanConfigService cropPlanConfigService, PluginManager pluginManager, DAOContainer daocontainer)
	{
		super(baseService, cropPlanService, locksService, cropCodeService, validatorService, cropPlanConfigService, pluginManager, daocontainer.getCropPlansDAO()
		);
		this.cropCodeService = cropCodeService;
		this.pluginManager = pluginManager;
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/land-uses/common-config-and-values")
	@Operation(description = "Get the list of common config and common values by the landUse code list")
	@ApiResponse(description = "The list of common config and common values by the landUse code list")
	public CommonAdditionalDataAndPermanentCropFormConfigs getCommonLandUseAndPermanentCropFormConfigsByLandUseCodes(
			@Parameter(hidden = true) @Auth User user,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@NotNull @Valid LandUseCommonConfigAndValuesDto landUseCommonConfigAndValuesDto
	) {
		RuntimeEnvironment env = createEnvironment(user, language);
		return cropCodeService.getCommonLandUseAndPermanentCropFormConfigsByLandUseCodes(env, businessId, cropPlanId, landUseCommonConfigAndValuesDto, pointInTime);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/land-uses")
	@Operation(description = "Get the list of the land uses")
	@ApiResponse(description = "The list of the land uses")
	public MaxRowsResults<LandUseDetails> getLandUseCodes(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The list of the land cover codes") @QueryParam("landCoverCodes") List<String> landCoverCodes,
		@Parameter(description = "The search string") @QueryParam("search") String search,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);
		return cropCodeService.getLandUseCodesMaxRows(env, businessId, cropPlanId, landCoverCodes, search, pointInTime);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/land-uses/{code}")
	@Operation(description = "Get the details of the land use code requested")
	@ApiResponse(description = "The land use")
	public LandUseDetails getLandUseCode(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "Land use code") @PathParam("code") String code,
			@Parameter(description = "The list of the land cover codes") @QueryParam("landCoverCodes") List<String> landCoverCodes,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);
		return cropCodeService.getLandUseCode(env, businessId, cropPlanId, code, landCoverCodes, pointInTime);
	}
	
	
	@GET
	@Path("/{businessId}/plans/{cropPlanId}/land-uses/{code}/fields-codes")
	@Operation(description = "Get the details of the land use code requested")
	@ApiResponse(description = "The land use")
	public List<LandUseAdditionalDataConf> getLandUseCodeFieldsConf(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "Land use code") @PathParam("code") String landUseCode,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);
		
		return cropCodeService.getLandUseCodeFieldsConf(env, businessId, cropPlanId, landUseCode, pointInTime);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/land-cover-filters")
	@Operation(description = "Get the list of land cover filters")
	@ApiResponse(description = "The list of land cover filters")
	public List<LandCoverFilter> getLandCoverFilters(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);
		
		return pluginManager.getCropCodesPlugin(businessId, cropPlanId, tenantId).getLandCoverFilters(env);
	}
	
	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/land-uses/{code}/favourite")
	@Operation(description = "Set the land use as favourite")
	public void addFavouriteLandUse(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "Land use code") @PathParam("code") String code,
			@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);
		
		cropCodeService.addFavouriteLandUse(env, businessId, cropPlanId, code);		
	}
	
	@DELETE
	@Path("/{businessId}/plans/{cropPlanId}/land-uses/{code}/favourite")
	@Operation(description = "Remove the land use from favourites")
	public void removeFavouriteLandUse(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "Land use code") @PathParam("code") String code,
			@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);
		
		cropCodeService.removeFavouriteLandUse(env, businessId, cropPlanId, code);		
	}
	
	@GET
	@Path("/{businessId}/plans/{cropPlanId}/land-uses/{code}/land-cover")
	@Operation(description = "Get the land cover of the land use code requested")
	@ApiResponse(description = "The land cover")
	public LandCover getLandCoverCode(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "Land use code") @PathParam("code") String code,
			@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);
		
		var cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, tenantId);
		var landCoverCode = cropCodesPlugin.getLandCoverCode(env, code); 
		var landCovers = cropCodesPlugin.getLandCoverDescriptions(env, List.of(landCoverCode));
		var landCoverDescription = landCovers.get(landCoverCode);
		return new LandCover(landCoverCode, landCoverDescription != null ? landCoverDescription : landCoverCode);
	}

}
