package com.abacogroup.cropplan.services;

import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

import com.abacogroup.cropplan.api.CutBehaviour;
import com.abacogroup.cropplan.api.DisabledFunctionCode;
import com.abacogroup.cropplan.api.EditPlotPreviewResult;
import com.abacogroup.cropplan.api.EditPlotResult;
import com.abacogroup.cropplan.api.ModifiedMerged;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.PlotDataToInclude;
import com.abacogroup.cropplan.api.PlotEditability;
import com.abacogroup.cropplan.api.PlotPreview;
import com.abacogroup.cropplan.api.payload.CutPlotsByGeometriesPayload;
import com.abacogroup.cropplan.api.payload.CutPlotsByLayerPayload;
import com.abacogroup.cropplan.api.payload.CutPlotsByLinePayload;
import com.abacogroup.cropplan.api.payload.DrawLineBufferPayload;
import com.abacogroup.cropplan.api.payload.DrawLineBufferPayload.DrawLineBufferParameters;
import com.abacogroup.cropplan.api.payload.DrawLineBufferPayload.LineBufferBehaviour;
import com.abacogroup.cropplan.api.payload.DrawLineBufferPayload.LineBufferPosition;
import com.abacogroup.cropplan.api.payload.EditPlotPayload;
import com.abacogroup.cropplan.api.payload.EditPlotPayload.CutParameters;
import com.abacogroup.cropplan.api.payload.EditPlotsPayload;
import com.abacogroup.cropplan.api.payload.EditPlotsPayload.PlotPayload;
import com.abacogroup.cropplan.api.payload.GetCuttableLayersPayload;
import com.abacogroup.cropplan.api.payload.InsertPermanentCropForm;
import com.abacogroup.cropplan.api.payload.InsertPlotPayload;
import com.abacogroup.cropplan.api.payload.MergePlotsPayload;
import com.abacogroup.cropplan.api.payload.RenamePlotPayload;
import com.abacogroup.cropplan.db.EditorSupportImpl;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.PlotEditDAO;
import com.abacogroup.cropplan.db.dao.ntt.PlotGeometry;
import com.abacogroup.cropplan.exceptions.NoPlotVersionsFoundInFirstVersionException;
import com.abacogroup.cropplan.exceptions.NoVersionsFoundException;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.sdk.model.CropPlanVersion;
import com.abacogroup.cropplan.sdk.model.domain.Parcel;
import com.abacogroup.cropplan.sdk.model.layers.CuttableLayer;
import com.abacogroup.cropplan.sdk.spi.LayersPlugin;
import com.abacogroup.cropplan.sdk.support.InfiniteListResultsSupport;
import com.abacogroup.cropplan.services.PersistEditorResult.FutureIntersections;
import com.abacogroup.cropplan.services.support.EditorResultParams;
import com.abacogroup.cropplan.services.support.EditorSupportFactory;
import com.abacogroup.cropplan.services.support.EditorSupportParams;
import com.abacogroup.cropplan.services.support.PlotTimeWindowParams;
import com.abacogroup.cropplan.services.utils.PlotEditServiceUtils;
import com.abacogroup.geometryeditor.Editor;
import com.abacogroup.geometryeditor.EditorResult;
import com.abacogroup.geometryeditor.ntt.ComputeCoveredByInserted;
import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.google.common.collect.Iterators;
import com.google.common.collect.UnmodifiableIterator;
import jakarta.ws.rs.BadRequestException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import lombok.Getter;
import lombok.Setter;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.LineString;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.geom.Polygonal;

public class PlotEditService {
	//private static final Logger log = LoggerFactory.getLogger(PlotEditService.class);
	private static final int MIN_AREA_AFTER_EDIT = 1;
	
	private final CropPlanConfigService cropPlanConfigService;
	private final CropPlanService cropPlanService;
	private final CropPlanDeclarationsService cropPlanDeclarationsService;
	private final PropagationService propagationService;
	private final PlotEditDAO plotEditDAO;
	private final CropPlansDAO cropPlansDAO;
	@Setter
	private EditorSupportFactory<String> editorSupportFactory;
	private final PluginManager pluginManager;
	
	@Getter
	private final PlotEditServiceUtils plotEditServiceUtils;
	
	public PlotEditService(CropPlanConfigService cropPlanConfigService, CropPlanService cropPlanService, 
			CropPlanDeclarationsService cropPlanDeclarationsService, DeclarationService declarationService, 
			PropagationService propagationService, ValidatorService validatorService, 
			DAOContainer daocontainer,
			PluginManager pluginManager) {
		this.cropPlanConfigService = cropPlanConfigService;
		this.cropPlanService = cropPlanService;
		this.cropPlanDeclarationsService = cropPlanDeclarationsService;
		this.propagationService = propagationService;
		plotEditDAO = daocontainer.getPlotEditDAO();
		this.cropPlansDAO = daocontainer.getCropPlansDAO();
		this.editorSupportFactory = (RuntimeEnvironment env, EditorSupportParams params, CutBehaviour cutBehaviour, LineBufferBehaviour lineBufferBehaviour,
				boolean ignoreEditability, Map<String, Polygon> cutPolygons, AbsoluteDate pointInTime, boolean isForPreview) -> {
			var snapFromDate = cropPlanConfigService.getSnapFromDate(params.getCropPlanId(), pointInTime);
			return new EditorSupportImpl(env, params, cutBehaviour, lineBufferBehaviour, ignoreEditability, cutPolygons,
					pointInTime, snapFromDate, isForPreview, plotEditDAO, cropPlansDAO, daocontainer.getSubdomainZoneDAO(),
					pluginManager.getDomainPlugin(params.getBusinessId(), params.getCropPlanId(), env.getTenantId()),
					pluginManager.getCropCodesPlugin(params.getBusinessId(), params.getCropPlanId(), env.getTenantId()), cropPlanConfigService);
		};
		this.pluginManager = pluginManager;
		
		this.plotEditServiceUtils = new PlotEditServiceUtils(cropPlanService, cropPlanDeclarationsService, cropPlanConfigService, 
				declarationService, propagationService, validatorService, pluginManager, plotEditDAO, daocontainer.getCropPlanConfigDAO(),
				daocontainer.getSyncDAO());
	}
	
	private void cleanResult(EditorResult<String> result) {
		var it = result.getCreated().keySet().iterator();
		while(it.hasNext()) {
			var key = it.next();
			var geom = result.getCreated().get(key);
			if (Math.round(geom.getArea()) < 1) it.remove();
		}
		
		it = result.getModified().keySet().iterator();
		while(it.hasNext()) {
			var key = it.next();
			var geom = result.getModified().get(key);
			if (Math.round(geom.getArea()) < 1) {
				result.getDeleted().add(key);
				it.remove();
			}
		}
	}

	public boolean canEditPlot(RuntimeEnvironment env, EditorSupportParams params, AbsoluteDate pointInTime, String plotCode) {
		var plot = cropPlanService.getPlot(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(), params.getVersionDt(),
				pointInTime, pointInTime, plotCode);
		if (plot == null)
			throw new BadRequestException("The plot " + plotCode + " was not found");
		else
			return plot.getEditability() == PlotEditability.EDITABLE;
	}

	public EditPlotPreviewResult cutPlotsByLinePreview(RuntimeEnvironment env, EditorSupportParams params, CutPlotsByLinePayload payload) {
		var result = cutPlotsByLineInternal(env, params, payload, true, false);
		return getEditPlotPreviewResult(result.getEditorResult());
	}

	public EditPlotResult cutPlotsByLine(RuntimeEnvironment env, EditorSupportParams params, CutPlotsByLinePayload payload,
			boolean ignoreValidationWarnings) {
		if (payload.getCutParameters().getPlotCodes() != null) {
			payload.getCutParameters().getPlotCodes().forEach(plotCode->{
				var plot = cropPlanService.getPlot(env, params.getBusinessId(),params.getCropPlanId(),params.getDomainZoneId(),
						params.getVersionDt(), payload.getFromPointInTime(), payload.getFromPointInTime(), plotCode);
				if (plot == null)
					throw new BadRequestException("The plot " + plotCode + " was not found");
				
				cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.CUT_PLOTS ,env, params.getBusinessId(), params.getCropPlanId(), plot);
			});
		}
		PersistEditorResult result = cutPlotsByLineInternal(env, params, payload, false, ignoreValidationWarnings);
		return result.getEditPlotResult();
	}

	private PersistEditorResult cutPlotsByLineInternal(RuntimeEnvironment env, EditorSupportParams params,
			CutPlotsByLinePayload payload, boolean isForPreview, boolean ignoreValidationWarnings) {
		
		Function<EditorResultParams, EditorResult<String>> editFunction = (editorResultParams) -> {
			EditorResult<String> result;
			Editor<String> editor;
			if (payload.getCutParameters().getPlotCodes() != null) {
				var cutPolygons = loadPolygons(params, editorResultParams.getPointInTime(),
						payload.getCutParameters().getPlotCodes());
				if (cutPolygons.keySet().size() != payload.getCutParameters().getPlotCodes().size())
					throw new BadRequestException("Some plot codes specified in cut parameters were not found");
				editor = getEditor(env, params, CutBehaviour.CUT_EXISTING, null, cutPolygons, editorResultParams.getPointInTime(), isForPreview);
			} else {
				editor = getEditor(env, params, CutBehaviour.CUT_EXISTING, null, null, editorResultParams.getPointInTime(), isForPreview);
			}
			
			try {
				result = editor.cutPolygonsByLine((LineString) payload.getGeom(), MIN_AREA_AFTER_EDIT);
			} catch(IllegalStateException e) {
				editor.setResolveOverlaps(true); // retry resolving overlaps
				result = editor.cutPolygonsByLine((LineString) payload.getGeom(), MIN_AREA_AFTER_EDIT);
			}
			
			return result;
		};
		
		Function<EditorResultParams, EditorResult<String>> editFunctionForFutures = (editorResultParams) -> { // TODO manage editorResultParams
			EditorResult<String> ret;
			Editor<String> editorForPreview;
			if (payload.getCutParameters().getPlotCodes() != null) {
				var cutPolygons = loadPolygons(params, editorResultParams.getPointInTime(),
						payload.getCutParameters().getPlotCodes());
				editorForPreview = getEditor(env, params, CutBehaviour.CUT_EXISTING, null, cutPolygons, editorResultParams.getPointInTime(), true);
			} else {
				editorForPreview = getEditor(env, params, CutBehaviour.CUT_EXISTING, null, null, editorResultParams.getPointInTime(), true);
			}
			
			try {
				ret = editorForPreview.cutPolygonsByLine((LineString) payload.getGeom(), MIN_AREA_AFTER_EDIT);
			} catch(IllegalStateException e) {
				editorForPreview.setResolveOverlaps(true); // retry resolving overlaps
				ret = editorForPreview.cutPolygonsByLine((LineString) payload.getGeom(), MIN_AREA_AFTER_EDIT);
			}
			
			return ret;
		};

		PersistEditorResult persistEditorResult;
		if (!isForPreview)
			persistEditorResult = plotEditServiceUtils.persistEditorResult(env, params, null, null,
					payload.getFromPointInTime(),payload.getToPointInTime(), editFunction, null, editFunctionForFutures, ignoreValidationWarnings, null, false);
		else {
			EditorResultParams editorResultParams = EditorResultParams.builder()
					.pointInTime(payload.getFromPointInTime())
					.parcels(null)
					.build();
			EditorResult<String> result = editFunction.apply(editorResultParams);
			persistEditorResult = new PersistEditorResult(null, null, result);
		}

		return persistEditorResult;
	}
	
	public EditPlotPreviewResult cutPlotsByGeometriesPreview(RuntimeEnvironment env, EditorSupportParams params, CutPlotsByGeometriesPayload payload) {
		var result = cutPlotsByGeometriesInternal(env, params, payload.getGeoms(), payload.getCutParameters().getPlotCodes(),
				payload.getCutParameters().isFlMergeGeomsOnCutOnLayer(), payload.getCutParameters().isFlCalcCoveredByInsertedOnCutOnLayer(),
				true, false, payload.getFromPointInTime(), payload.getToPointInTime());
		return getEditPlotPreviewResult(result.getEditorResult());
	}

	public EditPlotResult cutPlotsByGeometries(RuntimeEnvironment env, EditorSupportParams params, CutPlotsByGeometriesPayload payload,
			boolean ignoreValidationWarnings) {
		if (payload.getCutParameters().getPlotCodes() != null) {
			payload.getCutParameters().getPlotCodes().forEach(plotCode->{
				var plot = cropPlanService.getPlot(env, params.getBusinessId(),params.getCropPlanId(),params.getDomainZoneId(),
						params.getVersionDt(), payload.getFromPointInTime(), payload.getFromPointInTime(), plotCode);
				if (plot == null)
					throw new BadRequestException("The plot " + plotCode + " was not found");
				
				cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.CUT_PLOTS ,env, params.getBusinessId(), params.getCropPlanId(), plot);
			});
		}
		PersistEditorResult result = cutPlotsByGeometriesInternal(env, params, payload.getGeoms(), payload.getCutParameters().getPlotCodes(),
				payload.getCutParameters().isFlMergeGeomsOnCutOnLayer(), payload.getCutParameters().isFlCalcCoveredByInsertedOnCutOnLayer(),
				false, ignoreValidationWarnings, payload.getFromPointInTime(), payload.getToPointInTime());
		return result.getEditPlotResult();
	}

	public List<CuttableLayer> getCuttableLayers(RuntimeEnvironment env, EditorSupportParams params, GetCuttableLayersPayload payload) {

		List<Geometry> plotsGeoms = new ArrayList<>();
		if (payload.getPlotCodes() != null) {
			for (String plotCode : payload.getPlotCodes()) {
				var plot = cropPlanService.getPlot(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(),
						params.getVersionDt(), payload.getPointInTime(), payload.getPointInTime(), plotCode);
				if (plot == null) {
					throw new BadRequestException("The plot " + plotCode + " was not found");
				}

				plotsGeoms.add(plot.getGeom().getEnvelope());
			}
		} else {
			new InfiniteListResultsSupport<>(nextKey ->
					cropPlanService.getPlots(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(),
							params.getVersionDt(), payload.getPointInTime(), null, null,
							nextKey, 50, PlotDataToInclude.EXCLUDE_ALL)
			).forEach(plot -> {
				plotsGeoms.add(plot.getGeom().getEnvelope());
			});
		}
		Geometry plotsUnion = Utils.getUnion(plotsGeoms);

		LayersPlugin layersPlugin = this.pluginManager.getLayersPlugin(params.getBusinessId(), params.getCropPlanId(), env.getTenantId());
		return layersPlugin.getCuttableLayers(env, params.getBusinessId(), params.getDomainZoneId(),
				payload.getPointInTime().toLocalDate(), payload.getLayerCodes(), plotsUnion);
	}

	public EditPlotPreviewResult cutPlotsByLayerPreview(RuntimeEnvironment env, EditorSupportParams params, CutPlotsByLayerPayload payload) {

		List<Geometry> plotsGeoms = new ArrayList<>();
		if (payload.getCutParameters().getPlotCodes() != null) {
			for (String plotCode : payload.getCutParameters().getPlotCodes()) {
				var plot = cropPlanService.getPlot(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(),
						params.getVersionDt(), payload.getFromPointInTime(), payload.getFromPointInTime(), plotCode);
				if (plot == null) {
					throw new BadRequestException("The plot " + plotCode + " was not found");
				}

				plotsGeoms.add(plot.getGeom().getEnvelope());
			}
		} else {
			new InfiniteListResultsSupport<>(nextKey ->
					cropPlanService.getPlots(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(),
							params.getVersionDt(), payload.getFromPointInTime(), null, null,
							nextKey, 50, PlotDataToInclude.EXCLUDE_ALL)
			).forEach(plot -> {
				plotsGeoms.add(plot.getGeom().getEnvelope());
			});
		}
		Geometry plotsUnion = Utils.getUnion(plotsGeoms);

		LayersPlugin layersPlugin = this.pluginManager.getLayersPlugin(params.getBusinessId(), params.getCropPlanId(), env.getTenantId());
		List<Geometry> layerGeometries = layersPlugin.getLayerGeometries(env, params.getBusinessId(), params.getDomainZoneId(),
				payload.getFromPointInTime().toLocalDate(), payload.getLayerCode(), plotsUnion);

		var result = this.cutPlotsByGeometriesInternal(env, params, layerGeometries, payload.getCutParameters().getPlotCodes(),
				payload.getCutParameters().isFlMergeGeomsOnCutOnLayer(), payload.getCutParameters().isFlCalcCoveredByInsertedOnCutOnLayer(),
				true, false, payload.getFromPointInTime(), payload.getToPointInTime());
		return getEditPlotPreviewResult(result.getEditorResult());
	}

	public EditPlotResult cutPlotsByLayer(RuntimeEnvironment env, EditorSupportParams params, CutPlotsByLayerPayload payload,
			boolean ignoreValidationWarnings) {

		List<Geometry> plotsGeoms = new ArrayList<>();
		if (payload.getCutParameters().getPlotCodes() != null) {
			for (String plotCode : payload.getCutParameters().getPlotCodes()) {
				var plot = cropPlanService.getPlot(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(),
						params.getVersionDt(), payload.getFromPointInTime(), payload.getFromPointInTime(), plotCode);
				if (plot == null) {
					throw new BadRequestException("The plot " + plotCode + " was not found");
				}

				cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.CUT_PLOTS, env, params.getBusinessId(), params.getCropPlanId(), plot);
				plotsGeoms.add(plot.getGeom().getEnvelope());
			}
		} else {
			new InfiniteListResultsSupport<>(nextKey ->
					cropPlanService.getPlots(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(),
							params.getVersionDt(), payload.getFromPointInTime(), null, null,
							nextKey, 50, PlotDataToInclude.ALL_ANOMALIES)
			).forEach(plot -> {
				cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.CUT_PLOTS, env, params.getBusinessId(), params.getCropPlanId(), plot);

				plotsGeoms.add(plot.getGeom().getEnvelope());
			});
		}
		Geometry plotsUnion = Utils.getUnion(plotsGeoms);

		LayersPlugin layersPlugin = this.pluginManager.getLayersPlugin(params.getBusinessId(), params.getCropPlanId(), env.getTenantId());
		List<Geometry> layerGeometries = layersPlugin.getLayerGeometries(env, params.getBusinessId(), params.getDomainZoneId(),
				payload.getFromPointInTime().toLocalDate(), payload.getLayerCode(), plotsUnion);

		PersistEditorResult result = this.cutPlotsByGeometriesInternal(env, params, layerGeometries, payload.getCutParameters().getPlotCodes(),
				payload.getCutParameters().isFlMergeGeomsOnCutOnLayer(), payload.getCutParameters().isFlCalcCoveredByInsertedOnCutOnLayer(),
				false, ignoreValidationWarnings, payload.getFromPointInTime(), payload.getToPointInTime());
		return result.getEditPlotResult();
	}

	private PersistEditorResult cutPlotsByGeometriesInternal(RuntimeEnvironment env, EditorSupportParams params, List<Geometry> geoms, List<String> plotCodes,
			boolean flMergeGeomsOnCutOnLayer, boolean flCalcCoveredByInsertedOnCutOnLayer, boolean isForPreview, boolean ignoreValidationWarnings,
			AbsoluteDate fromPointInTime, AbsoluteDate toPointInTime) {

		List<Geometry> geometries = flMergeGeomsOnCutOnLayer
				? Collections.singletonList(Utils.reducePrecision(Utils.getUnion(geoms), true, true))
				: geoms.stream().map(geometry -> Utils.reducePrecision(geometry, true, true)).collect(toList());

		Function<EditorResultParams, EditorResult<String>> editFunction =
				buildEditFunction(env, params, plotCodes, flCalcCoveredByInsertedOnCutOnLayer, isForPreview, ignoreValidationWarnings, geometries);
		
		Function<EditorResultParams, EditorResult<String>> editFunctionForFutures = buildEditFunctionForFutures(env, params, plotCodes, geometries);

		return persistEditorResult(env, params, fromPointInTime, toPointInTime, isForPreview, ignoreValidationWarnings, editFunction, editFunctionForFutures
		);
	}

	private PersistEditorResult persistEditorResult(RuntimeEnvironment env, EditorSupportParams params,
			AbsoluteDate fromPointInTime, AbsoluteDate toPointInTime, boolean isForPreview, boolean ignoreValidationWarnings,
			Function<EditorResultParams, EditorResult<String>> editFunction, Function<EditorResultParams, EditorResult<String>> editFunctionForFutures) {

		if (!isForPreview)
			return plotEditServiceUtils.persistEditorResult(env, params, null, null,
					fromPointInTime, toPointInTime, editFunction, null,
					editFunctionForFutures, ignoreValidationWarnings, null, false);
		else {
			EditorResultParams editorResultParams = EditorResultParams.builder()
					.pointInTime(fromPointInTime)
					.parcels(null)
					.build();
			EditorResult<String> result = editFunction.apply(editorResultParams);
			return new PersistEditorResult(null, null, result);
		}
	}

	private Function<EditorResultParams, EditorResult<String>> buildEditFunctionForFutures(
			RuntimeEnvironment env, EditorSupportParams params, List<String> plotCodes, List<Geometry> geoms) {
		return (editorResultParams) -> { // TODO manage editorResultParams
			Editor<String> editorForPreview;
			if (plotCodes != null) {
				var cutPolygons = loadPolygons(params, editorResultParams.getPointInTime(), plotCodes);
				editorForPreview = getEditor(env, params, CutBehaviour.CUT_EXISTING, null, cutPolygons, editorResultParams.getPointInTime(), true);
			} else {
				editorForPreview = getEditor(env, params, CutBehaviour.CUT_EXISTING, null, null, editorResultParams.getPointInTime(), true);
			}

			try {
				return editorForPreview.cutPolygonsByGeometries(geoms, MIN_AREA_AFTER_EDIT, ComputeCoveredByInserted.NONE);
			} catch(IllegalStateException e) {
				editorForPreview.setResolveOverlaps(true); // retry resolving overlaps
				return editorForPreview.cutPolygonsByGeometries(geoms, MIN_AREA_AFTER_EDIT, ComputeCoveredByInserted.NONE);
			}
		};
	}

	private Function<EditorResultParams, EditorResult<String>> buildEditFunction(
			RuntimeEnvironment env, EditorSupportParams params, List<String> plotCodes, boolean flCalcCoveredByInsertedOnCutOnLayer,
			boolean isForPreview, boolean ignoreValidationWarnings, List<Geometry> geoms) {
		return  (editorResultParams) -> {
			Editor<String> editor;
			if (plotCodes != null) {
				var cutPolygons = loadPolygons(params, editorResultParams.getPointInTime(), plotCodes);
				if (cutPolygons.keySet().size() != plotCodes.size())
					throw new BadRequestException("Some plot codes specified in cut parameters were not found");
				editor = getEditor(env, params, CutBehaviour.CUT_EXISTING, null, cutPolygons, editorResultParams.getPointInTime(), isForPreview);
			} else {
				editor = getEditor(env, params, CutBehaviour.CUT_EXISTING, null, null, editorResultParams.getPointInTime(), isForPreview);
			}

			ComputeCoveredByInserted computeCoveredByInteserd = flCalcCoveredByInsertedOnCutOnLayer ?
					ComputeCoveredByInserted.ALL_INTERACTIONS : ComputeCoveredByInserted.NONE;
			try {
				return editor.cutPolygonsByGeometries(geoms, MIN_AREA_AFTER_EDIT, computeCoveredByInteserd);
			} catch(IllegalStateException e) {
				editor.setResolveOverlaps(true); // retry resolving overlaps
				return editor.cutPolygonsByGeometries(geoms, MIN_AREA_AFTER_EDIT, computeCoveredByInteserd);
			}
		};
	}

	public EditPlotPreviewResult createPlotPreview(RuntimeEnvironment env, EditorSupportParams params, InsertPlotPayload payload) {
		var result = createPlotInternal(env, params, payload, true, false, null, false, false);
		return getEditPlotPreviewResult(result.getEditorResult());
	}

	public EditPlotResult createPlot(RuntimeEnvironment env, EditorSupportParams params, InsertPlotPayload payload,
			boolean ignoreValidationWarnings, boolean cleanResult) {
		PersistEditorResult result = createPlotInternal(env, params, payload, false, ignoreValidationWarnings, null, cleanResult, false);
		return result.getEditPlotResult();
	}

	public PersistEditorResult createPlotWithoutValidation(RuntimeEnvironment env, EditorSupportParams params,
			InsertPlotPayload payload, String defaultLandUseCode, boolean cleanResult) {
		return createPlotInternal(env, params, payload, false, true, defaultLandUseCode, cleanResult, true);
	}

	private PersistEditorResult createPlotInternal(RuntimeEnvironment env, EditorSupportParams params,
			InsertPlotPayload payload, boolean isForPreview, boolean ignoreValidationWarnings, String defaultLandUseCode,
			boolean cleanResult, boolean ignoreValidation) {
		boolean removeUndefinedSpace = (payload.getCutParameters().getPlotCodes() != null && 
				payload.getCutParameters().getBehaviour() == CutBehaviour.CUT_EXISTING);

		Geometry geom = payload.getGeom();
		Function<EditorResultParams, EditorResult<String>> editFunction = (editorResultParams) -> {
			Editor<String> editor = getEditorForCreatePlot(env, params, editorResultParams.getPointInTime(), payload.getCutParameters(), isForPreview);
			EditorResult<String> result;
			try {
				result = editor.insertPolygon((Polygonal) geom, removeUndefinedSpace, MIN_AREA_AFTER_EDIT);
			} catch(IllegalStateException e) {
				editor.setResolveOverlaps(true); // retry resolving overlaps
				result = editor.insertPolygon((Polygonal) geom, removeUndefinedSpace, MIN_AREA_AFTER_EDIT);
			}
			
			if (cleanResult)
				cleanResult(result);
			
			return result;
		};
		
		Function<EditorResultParams, EditorResult<String>> editFunctionForFutures = (editorResultParams) -> {
			Editor<String> editorForPreview;
			try {
				editorForPreview = getEditorForCreatePlot(env, params, editorResultParams.getPointInTime(), payload.getCutParameters(), true);
			} catch(BadRequestException e) {
				return new EditorResult<>();
			}
			if (editorResultParams.getParcels() != null) {
				((EditorSupportImpl) editorForPreview.getEditorSupport()).setCanvasGeometries(editorResultParams.getParcels().stream()
						.map(p -> (Polygonal) p.getGeom())
						.collect(toList()));
			}
			
			EditorResult<String> ret;
			try {
				ret = editorForPreview.insertPolygon((Polygonal) geom, removeUndefinedSpace, MIN_AREA_AFTER_EDIT);
			} catch(IllegalStateException e) {
				editorForPreview.setResolveOverlaps(true); // retry resolving overlaps
				ret = editorForPreview.insertPolygon((Polygonal) geom, removeUndefinedSpace, MIN_AREA_AFTER_EDIT);
			}
			
			if (cleanResult)
				cleanResult(ret);
			
			return ret;
		};

		PersistEditorResult persistEditorResult;
		if (!isForPreview)
			persistEditorResult = plotEditServiceUtils.persistEditorResult(env, params,
					payload.getDescription(),payload.getNotes(), payload.getFromPointInTime(),payload.getToPointInTime(), editFunction, null,
					editFunctionForFutures, ignoreValidationWarnings, defaultLandUseCode, ignoreValidation);
		else {
			EditorResultParams editorResultParams = EditorResultParams.builder()
					.pointInTime(payload.getFromPointInTime())
					.parcels(null)
					.build();
			EditorResult<String> result = editFunction.apply(editorResultParams);
			persistEditorResult = new PersistEditorResult(null, null, result);
		}
		
		return persistEditorResult;
	}

	private Editor<String> getEditorForCreatePlot(RuntimeEnvironment env, EditorSupportParams params, AbsoluteDate pointInTime,
			CutParameters cutParameters, boolean isForPreview) {
		Editor<String> editor;
		if (cutParameters.getPlotCodes() != null) {
			var cutPolygons = loadPolygons(params, pointInTime,
					cutParameters.getPlotCodes());
			if (cutPolygons.keySet().size() != cutParameters.getPlotCodes().size())
				throw new BadRequestException("Some plot codes specified in cut parameters were not found");
			editor = getEditor(env, params, cutParameters.getBehaviour(), null, cutPolygons,
					pointInTime, isForPreview);
		} else {
			editor = getEditor(env, params, cutParameters.getBehaviour(), null, null,
					pointInTime, isForPreview);
			// editor.setMinAreaAfterCanvas(isHoleFiller ? 1 : 0);
		}
		return editor;
	}

	public EditPlotPreviewResult updatePlotPreview(RuntimeEnvironment env, EditorSupportParams params, String plotCode, EditPlotPayload payload) {
		var result = updatePlotInternal(env, params, plotCode, payload, true, false, false, false);
		return getEditPlotPreviewResult(result.getEditorResult());
	}

	public EditPlotResult updatePlot(RuntimeEnvironment env, EditorSupportParams params, String plotCode, EditPlotPayload payload,
			boolean ignoreValidationWarnings) {
		var plot = cropPlanService.getPlot(env, params.getBusinessId(),params.getCropPlanId(),params.getDomainZoneId(),
				params.getVersionDt(), payload.getFromPointInTime(), payload.getFromPointInTime(), plotCode);
		if (plot == null)
			throw new BadRequestException("The plot " + plotCode + " was not found");
		
		cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.EDIT_PLOTS ,env, params.getBusinessId(), params.getCropPlanId(), plot);
		
		PersistEditorResult result = updatePlotInternal(env, params, plotCode, payload, false, ignoreValidationWarnings, false, false);
		return result.getEditPlotResult();
	}

	public PersistEditorResult updatePlotWithoutValidation(RuntimeEnvironment env, EditorSupportParams params, String plotCode, EditPlotPayload payload,
			boolean cleanResult) {
		return updatePlotInternal(env, params, plotCode, payload, false, true, cleanResult, true);
	}

	private PersistEditorResult updatePlotInternal(RuntimeEnvironment env, EditorSupportParams params,
			String plotCode, EditPlotPayload payload, boolean isForPreview, boolean ignoreValidationWarnings, 
			boolean cleanResult, boolean ignoreValidation) {

		Geometry geom = payload.getBufferedGeom();
		Function<EditorResultParams, EditorResult<String>> editFunction = (editorResultParams) -> {
			Editor<String> editor = getEditorForUpdatePlot(env, params, editorResultParams.getPointInTime(), payload.getCutParameters(), isForPreview);
			EditorResult<String> result;
			try {
				//long startTime = System.currentTimeMillis();
				result = editor.modifyPolygon((Polygon) geom, plotCode, MIN_AREA_AFTER_EDIT);
				//long endTime = System.currentTimeMillis();
				//log.info("TIME ELAPSED (" + params.getCropPlanId() + "): updatePlotInternal.modifyPolygon " + plotCode + ": " + TimeUnit.MILLISECONDS.toSeconds((endTime-startTime)) + "s");
			} catch(IllegalStateException e) {
				editor.setResolveOverlaps(true); // retry resolving overlaps
				result = editor.modifyPolygon((Polygon) geom, plotCode, MIN_AREA_AFTER_EDIT);
			}
			
			if (cleanResult)
				cleanResult(result);
			
			//long startTime = System.currentTimeMillis();
			// check intersected parcel codes and fix modified and deleted
			processIntersectedParcelCodes(env, params, editorResultParams.getPointInTime(), result, editor);
			//long endTime = System.currentTimeMillis();
			//log.info("TIME ELAPSED (" + params.getCropPlanId() + "): updatePlotInternal.processIntersectedParcelCodes " + plotCode + ": " + TimeUnit.MILLISECONDS.toSeconds((endTime-startTime)) + "s");
			
			return result;
		};
		
		Function<EditorResultParams, EditorResult<String>> editFunctionForFutures = (editorResultParams) -> {
			//long startTime = System.currentTimeMillis();
			
			Editor<String> editorForPreview;
			try {
				editorForPreview = getEditorForUpdatePlot(env, params, editorResultParams.getPointInTime(), payload.getCutParameters(), true);
			} catch (BadRequestException e) {
				return new EditorResult<>();
			}
			if (editorResultParams.getParcels() != null) {
				((EditorSupportImpl) editorForPreview.getEditorSupport()).setCanvasGeometries(editorResultParams.getParcels().stream()
						.map(p -> (Polygonal) p.getGeom())
						.collect(toList()));
			}
			
			EditorResult<String> ret;
			try {
				ret = editorForPreview.modifyPolygon((Polygon) geom, plotCode, MIN_AREA_AFTER_EDIT);
			} catch(IllegalStateException e) {
				editorForPreview.setResolveOverlaps(true); // retry resolving overlaps
				ret = editorForPreview.modifyPolygon((Polygon) geom, plotCode, MIN_AREA_AFTER_EDIT);
			}
			
			if (cleanResult)
				cleanResult(ret);
			
			// check intersected parcel codes and fix modified and deleted
			processIntersectedParcelCodes(env, params, editorResultParams.getPointInTime(), ret, editorForPreview);
			//long endTime = System.currentTimeMillis();
			//log.info("TIME ELAPSED (" + params.getCropPlanId() + "): updatePlotInternal.editFunctionForFutures " + plotCode + ": " + TimeUnit.MILLISECONDS.toSeconds((endTime-startTime)) + "s");
			
			return ret;
		};

		PersistEditorResult persistEditorResult;
		if (!isForPreview)
			persistEditorResult  = plotEditServiceUtils.persistEditorResult(env, params,
					null, null, payload.getFromPointInTime(), payload.getToPointInTime(), editFunction, null,
					editFunctionForFutures, ignoreValidationWarnings, null, ignoreValidation);
		else {
			EditorResultParams editorResultParams = EditorResultParams.builder()
					.pointInTime(payload.getFromPointInTime())
					.parcels(null)
					.build();
			EditorResult<String> result = editFunction.apply(editorResultParams);
			persistEditorResult = new PersistEditorResult(null, null, result);
		}
		
		return persistEditorResult;
	}

	private Editor<String> getEditorForUpdatePlot(RuntimeEnvironment env, EditorSupportParams params, AbsoluteDate pointInTime,
			CutParameters cutParameters, boolean isForPreview) {
		Editor<String> editor;
		if (cutParameters.getPlotCodes() != null) {
			var cutPolygons = loadPolygons(params, pointInTime,
					cutParameters.getPlotCodes());
			if (cutPolygons.keySet().size() != cutParameters.getPlotCodes().size())
				throw new BadRequestException("Some plot codes specified in cut parameters were not found");
			editor = getEditor(env, params, cutParameters.getBehaviour(), null, cutPolygons,
					pointInTime, isForPreview);
		} else {
			editor = getEditor(env, params, cutParameters.getBehaviour(), null, null,
					pointInTime, isForPreview);
			// editor.setMinAreaAfterCanvas(isSyncUpdate ? 1 : 0);
		}
		return editor;
	}

	public void renamePlot(RuntimeEnvironment env, EditorSupportParams params, String plotCode, RenamePlotPayload payload) {
		plotEditDAO.renamePlot(env, params, plotCode, payload.getDescription(), payload.getNotes());
	}

	public EditPlotPreviewResult updatePlotsPreview(RuntimeEnvironment env, EditorSupportParams params, EditPlotsPayload payload) {
		var result = updatePlotsInternal(env, params, payload, true, false);
		return getEditPlotPreviewResult(result.getEditorResult());
	}

	public EditPlotResult updatePlots(RuntimeEnvironment env, EditorSupportParams params, EditPlotsPayload payload,
			boolean ignoreValidationWarnings) {
		payload.getPlots().forEach(p ->{ 
			var plot = cropPlanService.getPlot(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(),
					params.getVersionDt(), payload.getFromPointInTime(), payload.getFromPointInTime(), p.getPlotCode());
			if (plot == null)
				throw new BadRequestException("The plot " + p.getPlotCode() + " was not found");
			
			cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.EDIT_PLOTS ,env, params.getBusinessId(), params.getCropPlanId(), plot);
		});
		
		PersistEditorResult result = updatePlotsInternal(env, params, payload, false, ignoreValidationWarnings);
		return result.getEditPlotResult();
	}

	private PersistEditorResult updatePlotsInternal(RuntimeEnvironment env, EditorSupportParams params,
			EditPlotsPayload payload, boolean isForPreview, boolean ignoreValidationWarnings) {
		
		Map<String, Polygon> plots = payload.getPlots().stream()
				.collect(toMap(PlotPayload::getPlotCode, PlotPayload::getPolygon));
		
		Function<EditorResultParams, EditorResult<String>> editFunction = (editorResultParams) -> {
			Editor<String> editor = getEditor(env, params, payload.getCutParameters().getBehaviour(), null, null, 
					editorResultParams.getPointInTime(), isForPreview);

			EditorResult<String> result;
			try {
				result = editor.modifyPolygons(plots, MIN_AREA_AFTER_EDIT);
			} catch(IllegalStateException e) {
				editor.setResolveOverlaps(true); // retry resolving overlaps
				result = editor.modifyPolygons(plots, MIN_AREA_AFTER_EDIT);
			}

			// check intersected parcel codes and fix modified and deleted
			processIntersectedParcelCodes(env, params, editorResultParams.getPointInTime(), result, editor);
			
			return result;
		};
		
		Function<EditorResultParams, EditorResult<String>> editFunctionForFutures = (editorResultParams) -> { // TODO manage editorResultParams
			Editor<String> editorForPreview = getEditor(env, params, payload.getCutParameters().getBehaviour(), null, 
					null, editorResultParams.getPointInTime(), true);
			
			EditorResult<String> ret;
			try {
				ret = editorForPreview.modifyPolygons(plots, MIN_AREA_AFTER_EDIT);
			} catch(IllegalStateException e) {
				editorForPreview.setResolveOverlaps(true); // retry resolving overlaps
				ret = editorForPreview.modifyPolygons(plots, MIN_AREA_AFTER_EDIT);
			}
			
			// check intersected parcel codes and fix modified and deleted
			processIntersectedParcelCodes(env, params, editorResultParams.getPointInTime(), ret, editorForPreview);
			
			return ret;
		};

		PersistEditorResult persistEditorResult;
		if (!isForPreview)
			persistEditorResult = plotEditServiceUtils.persistEditorResult(env, params,
					null, null, payload.getFromPointInTime(), payload.getToPointInTime(), editFunction, null,
					editFunctionForFutures, ignoreValidationWarnings, null, false);
		else {
			EditorResultParams editorResultParams = EditorResultParams.builder()
					.pointInTime(payload.getFromPointInTime())
					.parcels(null)
					.build();
			EditorResult<String> result = editFunction.apply(editorResultParams);
			persistEditorResult = new PersistEditorResult(null, null, result);
		}
		
		return persistEditorResult;
	}

	public void deletePlotWithoutValidation(RuntimeEnvironment env, EditorSupportParams params, String plotCode, AbsoluteDate fromPointInTime) {
		deletePlot(env, params, plotCode, fromPointInTime, true, true);
	}

	public PersistEditorResult deletePlot(RuntimeEnvironment env, EditorSupportParams params, String plotCode, AbsoluteDate fromPointInTime,
			boolean ignoreValidationWarnings, boolean ignoreValidation) {
		var plot = cropPlanService.getPlot(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(),
				params.getVersionDt(), fromPointInTime, fromPointInTime, plotCode);
		if (plot == null)
			throw new BadRequestException("The plot " + plotCode + " was not found");
		if(!ignoreValidation)
			cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.DELETE_PLOTS ,env, params.getBusinessId(), params.getCropPlanId(), plot);
		
		Function<EditorResultParams, EditorResult<String>> editFunction = (editorResultParams) -> {
			var result = new EditorResult<String>();
			result.getDeleted().add(plotCode);
			
			return result;
		};
		return plotEditServiceUtils.persistEditorResult(env, params, null, null, fromPointInTime, null, editFunction, null, null, ignoreValidationWarnings, null, ignoreValidation);
	}

	public PersistEditorResult deletePlots(RuntimeEnvironment env, EditorSupportParams params, List<String> plotCodes, AbsoluteDate fromPointInTime,
			boolean ignoreValidationWarnings, boolean ignoreValidation) {

		for (String plotCode : plotCodes) {
			var plot = cropPlanService.getPlot(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(),
					params.getVersionDt(), fromPointInTime, fromPointInTime, plotCode);

			if (plot == null)
				throw new BadRequestException("The plot " + plotCode + " was not found");

			if(!ignoreValidation)
				cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.DELETE_PLOTS ,env, params.getBusinessId(), params.getCropPlanId(), plot);
		}

		Function<EditorResultParams, EditorResult<String>> editFunction = (editorResultParams) -> {
			var result = new EditorResult<String>();
			result.getDeleted().addAll(plotCodes);
			return result;
		};
		return plotEditServiceUtils.persistEditorResult(env, params, null, null, fromPointInTime, null,editFunction, null, null, ignoreValidationWarnings, null, ignoreValidation);
	}

	public EditPlotPreviewResult mergePlotsPreview(RuntimeEnvironment env, EditorSupportParams params, String plotCode, MergePlotsPayload payload) {
		var result = mergePlotsInternal(env, params, plotCode, payload, true, false, false);
		return getEditPlotPreviewResult(result.getEditorResult());
	}

	public EditPlotResult mergePlots(RuntimeEnvironment env, EditorSupportParams params, String plotCode, MergePlotsPayload payload,
			boolean ignoreValidationWarnings) {
		PersistEditorResult result = mergePlotsInternal(env, params, plotCode, payload, false, ignoreValidationWarnings, false);
		return result.getEditPlotResult();
	}

	public void mergePlotsWithoutValidation(RuntimeEnvironment env, EditorSupportParams params,
			String plotCode, MergePlotsPayload payload){
		mergePlotsInternal(env, params, plotCode, payload, false, true, true);
	}


	private PersistEditorResult mergePlotsInternal(RuntimeEnvironment env, EditorSupportParams params,
			String plotCode, MergePlotsPayload payload, boolean isForPreview,
			boolean ignoreValidationWarnings, boolean ignoreValidation) {
		
		Map<String, List<String>> mergedPlots = new HashMap<>();
		mergedPlots.put(plotCode, payload.getPlotCodes());
		
		ModifiedMerged modifiedMerged = new ModifiedMerged(mergedPlots, !plotEditServiceUtils.isNotPreserveDeclsOnPlotsMerge(params.getCropPlanId()));
		
		var plotCodes = payload.getPlotCodes();
		plotCodes.add(plotCode);
		
		Function<EditorResultParams, EditorResult<String>> editFunction = (editorResultParams) -> {
			Editor<String> editor = getEditor(env, params, CutBehaviour.CUT_EXISTING, null, null, payload.getFromPointInTime(), isForPreview);

			var plots = loadPolygons(params, editorResultParams.getPointInTime(), plotCodes);
			if (plots.keySet().size() != plotCodes.size())
				throw new BadRequestException("Some plot codes specified were not found");

			EditorResult<String> result;
			try {
				result = editor.mergePolygons(plots, plotCode);
			} catch(IllegalStateException e) {
				editor.setResolveOverlaps(true); // retry resolving overlaps
				result = editor.mergePolygons(plots, plotCode);
			}
			
			return result;
		};
		
		Function<EditorResultParams, EditorResult<String>> editFunctionForFutures = (editorResultParams) -> { // TODO manage editorResultParams
			Editor<String> editorForPreview = getEditor(env, params, CutBehaviour.CUT_EXISTING, null, null, editorResultParams.getPointInTime(), true);
			var p = loadPolygons(params, editorResultParams.getPointInTime(), plotCodes);
			if (p.containsKey(plotCode)) {
				
				EditorResult<String> ret;
				try {
					ret = editorForPreview.mergePolygons(p, plotCode);
				} catch(IllegalStateException e) {
					editorForPreview.setResolveOverlaps(true); // retry resolving overlaps
					ret = editorForPreview.mergePolygons(p, plotCode);
				}
				
				return ret;
			} else {
				return new EditorResult<>();
			}
		};

		PersistEditorResult persistEditorResult;
		if (!isForPreview)
			persistEditorResult = plotEditServiceUtils.persistEditorResult(env, params, null, null,
					payload.getFromPointInTime(), payload.getToPointInTime(), editFunction, modifiedMerged,
					editFunctionForFutures, ignoreValidationWarnings, null, ignoreValidation);
		else {
			EditorResultParams editorResultParams = EditorResultParams.builder()
					.pointInTime(payload.getFromPointInTime())
					.parcels(null)
					.build();
			EditorResult<String> result = editFunction.apply(editorResultParams);
			persistEditorResult = new PersistEditorResult(null, null, result);
		}
		
		return persistEditorResult;
	}

	public EditPlotResult restorePlotsDefault(RuntimeEnvironment env, EditorSupportParams params, List<String> plotCodes, AbsoluteDate fromPointInTime,
			boolean ignoreValidationWarnings) {

		UnmodifiableIterator<List<String>> partitions = Iterators.partition(plotCodes.iterator(), 500);

		// load selected plots parcels
		List<String> parcelCodes = new ArrayList<>();
		partitions.forEachRemaining(partition ->
				parcelCodes.addAll(plotEditDAO.getParcelCodesByPlotCodes(partition, params.getCropPlanId(), params.getVersionDt(), fromPointInTime)));

		if (!parcelCodes.isEmpty()) {
			AbsoluteDate snapFromDate = cropPlanConfigService.getSnapFromDate(params.getCropPlanId(), fromPointInTime);
			
			List<Parcel> parcels = pluginManager.getDomainPlugin(params.getBusinessId(), params.getCropPlanId(), env.getTenantId()).getParcelsByParcelCodes(env,
					params.getBusinessId(), params.getDomainZoneId(), parcelCodes, snapFromDate.toLocalDate());
			
			if (cropPlanConfigService.isRestorePlotsPropagatingBehaviour(params.getCropPlanId())) {
				restoreParcelsDefaultPropagatingBehaviour(env, params, parcels, fromPointInTime, ignoreValidationWarnings);
			} else {
				PersistEditorResult result = restoreParcelsDefault(env, params, parcels, fromPointInTime, ignoreValidationWarnings);
				return result.getEditPlotResult();
			}
		} 

		return new EditPlotResult();
	}
	
	private void restoreParcelsDefaultPropagatingBehaviour(RuntimeEnvironment env, EditorSupportParams params, List<Parcel> parcels, AbsoluteDate fromPointInTime,
			boolean ignoreValidationWarnings) {
		if (env.getProperty("validatorUrl") != null)
			throw new BadRequestException("Configuration error: RESTORE_PLOTS_PROPAGATING_BEHAVIOUR is not available with a validatorUrl configured!");
		
		plotEditDAO.useTransaction(dao -> {
			// for each parcels
			parcels.forEach(parcel -> {
				AbsoluteDate pointInTime = fromPointInTime;
				// restore from greatest between parcel from date and campaign start date
				if (cropPlanConfigService.isRestorePlotsAtCampaignStartDate(params.getCropPlanId())) {
					AbsoluteDate parcelFromDate = parcel.getFromDate() != null ? AbsoluteDate.of(parcel.getFromDate()) : fromPointInTime;
					AbsoluteDate campaignStartDate = cropPlanConfigService.getCampaignStartDate(params.getCropPlanId(), fromPointInTime);
					pointInTime = parcelFromDate.toLocalDate().isAfter(campaignStartDate.toLocalDate()) ? parcelFromDate : campaignStartDate;
				}
	
				drawGeometryPropagatingBehaviour(env, params, parcel.getGeom(), AbsoluteDate.of(parcel.getToDate()), pointInTime, ignoreValidationWarnings, null, false);
				
				// TODO !!! recalcAnomalies
				plotEditDAO.clearSyncRefDateToForceRecalcAnomalies(params.getCropPlanId());
			});
		});
	}
	
	public EditPlotResult drawGeometryPropagatingBehaviour(RuntimeEnvironment env, EditorSupportParams params, Geometry geom, AbsoluteDate maxPropagatingDate,
			AbsoluteDate pointInTime, boolean ignoreValidationWarnings, EditorResult<String> previousResult, boolean ignoreEditability) {
		// at evaluated pointInTime re-insert geometry with cut existing option
		
		Function<EditorResultParams, EditorResult<String>> editFunction = (editorResultParams) -> buildEditorResultDrawGeometryPropagatingBehaviour(env, params, geom, previousResult, editorResultParams, ignoreEditability);
		
		Function<EditorResultParams, EditorResult<String>> editFunctionForFutures = (editorResultParams) -> { // TODO manage editorResultParams
			return buildEditorResultForFutureDrawGeometryPropagatingBehaviour(env, params, geom, previousResult, editorResultParams, ignoreEditability);
		};
		
		PersistEditorResult persistEditorResult = plotEditServiceUtils.persistEditorResult(env, params, null, null,
				pointInTime, null, editFunction, null,
				editFunctionForFutures, ignoreValidationWarnings, null, (previousResult != null ? previousResult.getCreated() : null), true); 
		
		FutureIntersections futureIntersections = persistEditorResult.getFutureIntersections();
		if (futureIntersections.getMaximumDayTo().isBefore(AbsoluteDate.of("99991231"))) {
			AbsoluteDate nextPointInTime = AbsoluteDate.of(futureIntersections.getMaximumDayTo().toLocalDate().plusDays(1));
			AbsoluteDate nextSnapDate = cropPlanConfigService.getSnapFromDate(params.getCropPlanId(), nextPointInTime);
			if (!nextSnapDate.isAfter(maxPropagatingDate)) {
				drawGeometryPropagatingBehaviour(env, params, geom, maxPropagatingDate, nextSnapDate, ignoreValidationWarnings, persistEditorResult.getEditorResult(), ignoreEditability);
			}
		}

		return persistEditorResult.getEditPlotResult();
	}

	private EditorResult<String> buildEditorResultForFutureDrawGeometryPropagatingBehaviour(RuntimeEnvironment env, EditorSupportParams params, Geometry geom,
			EditorResult<String> previousResult, EditorResultParams editorResultParams, boolean ignoreEditability) {
		Editor<String> editorForPreview = getEditor(env, params, CutBehaviour.CUT_EXISTING, null, ignoreEditability, null, editorResultParams.getPointInTime(), true);
		editorForPreview.setMinAreaAfterCanvas(MIN_AREA_AFTER_EDIT);
		
		EditorResult<String> ret;
		if (previousResult == null) {
			try {
				ret = editorForPreview.insertPolygon((Polygonal) geom, MIN_AREA_AFTER_EDIT);
			} catch(IllegalStateException e) {
				editorForPreview.setResolveOverlaps(true); // retry resolving overlaps
				ret = editorForPreview.insertPolygon((Polygonal) geom, MIN_AREA_AFTER_EDIT);
			}
		} else {
			try {
				ret = editorForPreview.modifyPolygons(previousResult.getCreated(), MIN_AREA_AFTER_EDIT);
			} catch(IllegalStateException e) {
				editorForPreview.setResolveOverlaps(true); // retry resolving overlaps
				ret = editorForPreview.modifyPolygons(previousResult.getCreated(), MIN_AREA_AFTER_EDIT);
			}
			for (String previousCreatedKey : previousResult.getCreated().keySet()) {
				Polygon p = ret.getModified().remove(previousCreatedKey);
				if (p != null)
					ret.getCreated().put(previousCreatedKey, p);
				
				ret.getDeleted().remove(previousCreatedKey);
			}
		}
		
		return ret;
	}

	private EditorResult<String> buildEditorResultDrawGeometryPropagatingBehaviour(RuntimeEnvironment env, EditorSupportParams params, Geometry geom, EditorResult<String> previousResult,
			EditorResultParams editorResultParams, boolean ignoreEditability) {
		Editor<String> editor = getEditor(env, params, CutBehaviour.CUT_EXISTING, null, ignoreEditability, null, editorResultParams.getPointInTime(), false);
		editor.setMinAreaAfterCanvas(MIN_AREA_AFTER_EDIT);
		
		EditorResult<String> result;
		if (previousResult == null) {
			try {
				result = editor.insertPolygon((Polygonal) geom, MIN_AREA_AFTER_EDIT);
			} catch(IllegalStateException e) {
				editor.setResolveOverlaps(true); // retry resolving overlaps
				result = editor.insertPolygon((Polygonal) geom, MIN_AREA_AFTER_EDIT);
			}
		} else {
			try {
				result = editor.modifyPolygons(previousResult.getCreated(), MIN_AREA_AFTER_EDIT);
			} catch(IllegalStateException e) {
				editor.setResolveOverlaps(true); // retry resolving overlaps
				result = editor.modifyPolygons(previousResult.getCreated(), MIN_AREA_AFTER_EDIT);
			}

			for (String previousCreatedKey : previousResult.getCreated().keySet()) {
				Polygon p = result.getModified().remove(previousCreatedKey);
				if (p != null) 
					result.getCreated().put(previousCreatedKey, p);
	
				result.getCreatedParent().entrySet().removeIf(entry -> previousCreatedKey.equals(entry.getValue()));
	
				result.getDeleted().remove(previousCreatedKey);
			}
		}
		
		return result;
	}

	private PersistEditorResult restoreParcelsDefault(RuntimeEnvironment env, EditorSupportParams params, List<Parcel> parcels, AbsoluteDate fromPointInTime,
			boolean ignoreValidationWarnings) {
		
		List<String> parcelCodes = parcels.stream()
				.map(Parcel::getCode)
				.collect(toList());

		UnmodifiableIterator<List<String>> partitions = Iterators.partition(parcelCodes.iterator(), 500);

		Geometry parcelsGeometry = Utils.getUnion(parcels.stream()
				.map(Parcel::getGeom)
				.collect(toList()));

		Function<EditorResultParams, EditorResult<String>> editFunction = (editorResultParams) -> {

			List<PlotGeometry> plots = new ArrayList<>();

			partitions.forEachRemaining(partition -> plots.addAll(
					plotEditDAO.getPolygonsByParcelCodes(params.getCropPlanId(), params.getDomainZoneId(), editorResultParams.getPointInTime(),
							partition)));

			List<String> parcelPlotCodes = new ArrayList<>();
			plots.forEach(p -> {
				if (!parcelPlotCodes.contains(p.getPlotCode()) && canEditPlot(env, params, editorResultParams.getPointInTime(), p.getPlotCode()))
					parcelPlotCodes.add(p.getPlotCode());
			});
			
			var cutPolygons = loadPolygons(params, editorResultParams.getPointInTime(), parcelPlotCodes);
			if (cutPolygons.keySet().size() != parcelPlotCodes.size())
				throw new BadRequestException("Some plot codes to be restored were not found");
			
			Editor<String> editor = getEditor(env, params, CutBehaviour.CUT_EXISTING, null, cutPolygons,
					editorResultParams.getPointInTime(), false);
			editor.setMinAreaAfterCanvas(MIN_AREA_AFTER_EDIT);
			EditorResult<String> result;
			try {
				result = editor.insertPolygon((Polygonal) parcelsGeometry, MIN_AREA_AFTER_EDIT);
			} catch(IllegalStateException e) {
				editor.setResolveOverlaps(true); // retry resolving overlaps
				result = editor.insertPolygon((Polygonal) parcelsGeometry, MIN_AREA_AFTER_EDIT);
			}
			
			return result;
		};
		
		Function<EditorResultParams, EditorResult<String>> editFunctionForFutures = (editorResultParams) -> { // TODO manage editorResultParams
			List<String> parcelPlotCodes = new ArrayList<>();
			var plots = plotEditDAO.getPolygonsByParcelCodes(params.getCropPlanId(), params.getDomainZoneId(), editorResultParams.getPointInTime(), parcelCodes);
			plots.forEach(p -> {
				if (!parcelPlotCodes.contains(p.getPlotCode()) && canEditPlot(env, params, editorResultParams.getPointInTime(), p.getPlotCode()))
					parcelPlotCodes.add(p.getPlotCode());
			});
			
			var cutPolygons = loadPolygons(params, editorResultParams.getPointInTime(), parcelPlotCodes);
			
			Editor<String> editorForPreview = getEditor(env, params, CutBehaviour.CUT_EXISTING, null, cutPolygons, editorResultParams.getPointInTime(), true);
			editorForPreview.setMinAreaAfterCanvas(MIN_AREA_AFTER_EDIT);
			
			EditorResult<String> ret;
			try {
				ret = editorForPreview.insertPolygon((Polygonal) parcelsGeometry, MIN_AREA_AFTER_EDIT);
			} catch(IllegalStateException e) {
				editorForPreview.setResolveOverlaps(true); // retry resolving overlaps
				ret = editorForPreview.insertPolygon((Polygonal) parcelsGeometry, MIN_AREA_AFTER_EDIT);
			}
			
			return ret;
		};
		
		return plotEditServiceUtils.persistEditorResult(env, params, null, null,
				fromPointInTime, null, editFunction, null,
				editFunctionForFutures, ignoreValidationWarnings, null, false);
	}
	
	public EditPlotPreviewResult drawLineBufferPreview(RuntimeEnvironment env, EditorSupportParams params, DrawLineBufferPayload payload) {
		var result = drawLineBufferInternal(env, params, payload, true, false);
		return getEditPlotPreviewResult(result.getEditorResult());
	}

	public EditPlotResult drawLineBuffer(RuntimeEnvironment env, EditorSupportParams params, DrawLineBufferPayload payload,
			boolean ignoreValidationWarnings) {
		PersistEditorResult result = drawLineBufferInternal(env, params, payload, false, ignoreValidationWarnings);
		return result.getEditPlotResult();
	}

	private PersistEditorResult drawLineBufferInternal(RuntimeEnvironment env, EditorSupportParams params,
			DrawLineBufferPayload payload, boolean isForPreview, boolean ignoreValidationWarnings) {
		var bufferSize = payload.getBufferSize();
		if (payload.getDrawLineBufferParameters().getBehaviour() == LineBufferBehaviour.FREE_DRAW &&
				payload.getDrawLineBufferParameters().getPosition() == LineBufferPosition.CENTER)
			bufferSize /= 2;
		
		Polygonal geom;
		if (payload.getDrawLineBufferParameters().getBehaviour() != LineBufferBehaviour.FREE_DRAW ||
				payload.getDrawLineBufferParameters().getPosition() == LineBufferPosition.CENTER)
			geom = Utils.getLinearPolygon((LineString) payload.getGeom(), bufferSize);
		else
			geom = Utils.getLinearPolygonSingleSide((LineString) payload.getGeom(), bufferSize, payload.getDrawLineBufferParameters().getPosition() == LineBufferPosition.LEFT);
			
		var removeUndefinedSpace = payload.getDrawLineBufferParameters().getBehaviour() == LineBufferBehaviour.INTERNAL;
		
		Function<EditorResultParams, EditorResult<String>> editFunction = (editorResultParams) -> {	
			Editor<String> editor = getEditorForDrawLineBuffer(env, params, editorResultParams.getPointInTime(), payload.getDrawLineBufferParameters(), isForPreview);
			
			EditorResult<String> result;
			try {
				result = editor.insertPolygon(geom, removeUndefinedSpace, true, MIN_AREA_AFTER_EDIT);
			} catch(IllegalStateException e) {
				editor.setResolveOverlaps(true); // retry resolving overlaps
				result = editor.insertPolygon(geom, removeUndefinedSpace, true, MIN_AREA_AFTER_EDIT);
			}
			
			return result;
		};
		
		Function<EditorResultParams, EditorResult<String>> editFunctionForFutures = (editorResultParams) -> { // TODO manage editorResultParams
			Editor<String> editorForPreview;
			try {
				editorForPreview = getEditorForDrawLineBuffer(env, params, editorResultParams.getPointInTime(), payload.getDrawLineBufferParameters(), true);
			} catch (BadRequestException e) {
				return new EditorResult<>();
			}
			
			EditorResult<String> ret;
			try {
				ret = editorForPreview.insertPolygon(geom, removeUndefinedSpace, false, MIN_AREA_AFTER_EDIT);
			} catch(IllegalStateException e) {
				editorForPreview.setResolveOverlaps(true); // retry resolving overlaps
				ret = editorForPreview.insertPolygon(geom, removeUndefinedSpace, false, MIN_AREA_AFTER_EDIT);
			}
			
			return ret;
		};

		PersistEditorResult persistEditorResult;
		if (!isForPreview)
			persistEditorResult = plotEditServiceUtils.persistEditorResult(env, params, null, null,
					payload.getFromPointInTime(), payload.getToPointInTime(), editFunction, null,
					editFunctionForFutures, ignoreValidationWarnings, null, false);
		else {
			EditorResultParams editorResultParams = EditorResultParams.builder()
					.pointInTime(payload.getFromPointInTime())
					.parcels(null)
					.build();
			EditorResult<String> result = editFunction.apply(editorResultParams);
			persistEditorResult = new PersistEditorResult(null, null, result);
		}
		
		return persistEditorResult;
	}

	private Editor<String> getEditorForDrawLineBuffer(RuntimeEnvironment env, EditorSupportParams params, AbsoluteDate pointInTime, 
			DrawLineBufferParameters dlbParams, boolean isForPreview) {
		Editor<String> editor;
		if (dlbParams.getPlotCodes() != null) {
			var cutPolygons = loadPolygons(params, pointInTime,
					dlbParams.getPlotCodes());
			if (cutPolygons.keySet().size() != dlbParams.getPlotCodes().size())
				throw new BadRequestException("Some plot codes specified in cut parameters were not found");
			editor = getEditor(env, params, CutBehaviour.CUT_EXISTING, dlbParams.getBehaviour(), cutPolygons, 
					pointInTime, isForPreview);
		} else {
			editor = getEditor(env, params, CutBehaviour.CUT_EXISTING, dlbParams.getBehaviour(), null, 
					pointInTime, isForPreview);
		}
		return editor;
	}

	private Editor<String> getEditor(RuntimeEnvironment env, EditorSupportParams params, CutBehaviour cutBehaviour, LineBufferBehaviour lineBufferBehaviour,
			Map<String, Polygon> cutPolygons, AbsoluteDate pointInTime, boolean isForPreview) {
		return getEditor(env, params, cutBehaviour, lineBufferBehaviour, false, cutPolygons, pointInTime, isForPreview);
	}

	private Editor<String> getEditor(RuntimeEnvironment env, EditorSupportParams params, CutBehaviour cutBehaviour, LineBufferBehaviour lineBufferBehaviour,
			boolean ignoreEditability, Map<String, Polygon> cutPolygons, AbsoluteDate pointInTime, boolean isForPreview) {
		var editorParams = plotEditDAO.getCropPlanTypeEditorParams(params.getCropPlanId(), env.getTenantId());
		var editor = new Editor<>(editorSupportFactory.createEditorSupport(env, params, cutBehaviour, lineBufferBehaviour, ignoreEditability, cutPolygons, pointInTime, isForPreview),
				editorParams.isFlLimitToCanvas(), editorParams.isFlSplitOnCanvas());
		editor.setCanvasPreprocess(plotEditServiceUtils.getCanvasPreprocess(params.getCropPlanId()));
		editor.setTolerateAreaReduction(true);
		return editor;
	}

	private Map<String, Polygon> loadPolygons(EditorSupportParams params, AbsoluteDate pointInTime, List<String> plotCodes) {
		Map<String, Polygon> map = new HashMap<>();
		UnmodifiableIterator<List<String>> partitions = Iterators.partition(plotCodes.iterator(), 666);
		partitions.forEachRemaining(partition -> {
			var polygons = plotEditDAO.getPolygons(params.getCropPlanId(), params.getDomainZoneId(),
					pointInTime, partition);
			polygons.forEach(p -> map.put(p.getPlotCode(), (Polygon) p.getGeom()));
		});
		return map;
	}

	private EditPlotPreviewResult getEditPlotPreviewResult(EditorResult<String> editorResult) {
		EditPlotPreviewResult ret = new EditPlotPreviewResult();
		ret.setAdded(new ArrayList<>());
		editorResult.getCreated().keySet()
				.forEach(k -> ret.getAdded().add(new PlotPreview(k, editorResult.getCreated().get(k))));

		ret.setUpdated(new ArrayList<>());
		editorResult.getModified().keySet()
				.forEach(k -> ret.getUpdated().add(new PlotPreview(k, editorResult.getModified().get(k))));

		ret.setDeleted(List.copyOf(editorResult.getDeleted()));
		ret.setCoveredByInserted(List.copyOf(editorResult.getCoveredByInserted()));

		return ret;
	}

	private void processIntersectedParcelCodes(RuntimeEnvironment env, EditorSupportParams params, AbsoluteDate pointInTime,
			EditorResult<String> editorResult, Editor<String> editor) {
		var it = editorResult.getModified().entrySet().iterator();
		while (it.hasNext()) {
			var entry = it.next();
			String plotCode = entry.getKey();
			List<String> oldIntersectedParcelCodes = cropPlansDAO.getIntersectedParcelCodesByPlotCode(params.getCropPlanId(), plotCode,
					params.getVersionDt(), pointInTime);

			var newIntersectedParcelCodes = processPlotParcelData(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(),
					pointInTime, entry.getValue());

			/*boolean haveSameSize = oldIntersectedParcelCodes.size() == newIntersectedParcelCodes.size();
			boolean haveSameElements = oldIntersectedParcelCodes.stream()
					.filter(pi -> !newIntersectedParcelCodes.contains(pi))
					.collect(toList())
					.size() == 0;
			if (!haveSameSize || !haveSameElements) {*/
			boolean intersectedParcelCodesChanged = pluginManager.getDomainPlugin(params.getBusinessId(), params.getCropPlanId(), env.getTenantId())
					.intersectedParcelCodesChanged(env, params.getBusinessId(), pointInTime.toLocalDate(), oldIntersectedParcelCodes, newIntersectedParcelCodes);
			if (intersectedParcelCodesChanged) {
				var polygonKeys = editor.getEditorSupport().createPolygonKeys(Collections.singletonList(entry.getValue()));
				editorResult.getCreated().putAll(polygonKeys);

				for (var polygonKey : polygonKeys.keySet())
					editorResult.setCreatedParent(polygonKey, plotCode);

				editorResult.getDeleted().add(entry.getKey());
				it.remove();
			}
		}
	}
	
	private List<String> processPlotParcelData(RuntimeEnvironment env, String businessId, Long cropPlanId,
			String domainZoneId, AbsoluteDate dayFrom, Geometry plotGeom) {
		return propagationService.processPlotParcelData(null, env, businessId, cropPlanId, domainZoneId, dayFrom, plotGeom, null, 
				plotEditServiceUtils.getCanvasPreprocess(cropPlanId));
	}
	
	public void resumePlotFromCropPlanFirstVersion(RuntimeEnvironment env, EditorSupportParams params, String plotCode)
	{
		if (env.getProperty("validatorUrl") != null)
			throw new BadRequestException("Configuration error: ENABLE_RESUME_PLOT_FROM_FIRST_CROP_PLAN_VERSION is not available with a validatorUrl configured!");
		
		CropPlanVersion crplVersion = cropPlansDAO.getFirstVersion(params.getBusinessId(), params.getCropPlanId(), env.getTenantId());
		if (crplVersion == null)
			throw new NoVersionsFoundException();
		
		Plot currentPlot = cropPlanService.getPlot(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(), params.getVersionDt(),
				params.getPointInTime(), params.getPointInTime(), plotCode);
		
		Plot plot = cropPlanService.getPlot(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(), crplVersion.getVersionDate(),
				params.getPointInTime(), params.getPointInTime(), plotCode);
		if (plot == null) {
			// try to load plot by description
			if (currentPlot.getDescription() != null && !currentPlot.getDescription().isEmpty()) {
				List<String> plotCodes = cropPlansDAO.getPlotCodesByDescription(params.getCropPlanId(), currentPlot.getDescription(), crplVersion.getVersionDate());
				if (plotCodes.size() == 1) {
					plot = cropPlanService.getPlot(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(), crplVersion.getVersionDate(),
							params.getPointInTime(), params.getPointInTime(), plotCodes.get(0));
				}
			}
		}
		if (plot == null) {
			throw new NoPlotVersionsFoundInFirstVersionException(plotCode);
		}
		
		cropPlanDeclarationsService.deletePlotsDeclarations(env, params.getBusinessId(), params.getCropPlanId(), params.getVersionDt(),
				List.of(currentPlot), true);
		
		var cutParameters = new CutParameters();
		cutParameters.setBehaviour(CutBehaviour.CUT_EXISTING);
		
		var payload = new EditPlotPayload();
		payload.setCutParameters(cutParameters);
		payload.setFromPointInTime(plot.getFromDate());
		payload.setGeom(plot.getGeom());

		var updatePlotParams = EditorSupportParams.builder()
				.businessId(params.getBusinessId())
				.cropPlanId(params.getCropPlanId())
				.domainZoneId(params.getDomainZoneId())
				.versionDt(plotEditDAO.getCurrentTimestamp())
				.pointInTime(params.getPointInTime())
				.build();
		EditPlotResult result = updatePlot(env, updatePlotParams, plotCode, payload, true);
		for (Plot updatedPlot : result.getUpdated()) {
			if (plotCode.equals(updatedPlot.getPlotCode())) {
				plot.getDecls().forEach(d -> {
					var plotTimeWindowParams = PlotTimeWindowParams.builder()
						.businessId(params.getBusinessId())
						.cropPlanId(params.getCropPlanId())
						.domainZoneId(params.getDomainZoneId())
						.plotCode(updatedPlot.getPlotCode())
						.pointInTimeFrom(d.getFromDate())
						.pointInTimeTo(d.getToDate())
						.versionDt(plotEditDAO.getCurrentTimestamp())
						.build();
					
					List<InsertPermanentCropForm> pcfs = new ArrayList<>();
					d.getPermanentCropForms().forEach(pcf -> {
						var ipcf = new InsertPermanentCropForm();
						ipcf.setFormType(pcf.getFormType());
						ipcf.setPermanentCropFormData(pcf.getPermanentCropFormData());
						pcfs.add(ipcf);
					});
					
					cropPlanDeclarationsService.insertDeclaration(env, plotTimeWindowParams, d.getLanduse().getCode(), d.getAreaPerc(), 
						d.getFromDatePrecision(), updatedPlot.getParcelIntersections(), pcfs, d.getFieldsCodes(), null, false, true, false, false, false);
				});
			}
		}
	}
}
