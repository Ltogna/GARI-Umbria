package com.abacogroup.cropplan.api.payload;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ParcelDataPayload
{
	@Schema(description = "The parcel notes")
	private String notes;
}
