package com.abacogroup.cropplan.db.mappings;

import com.abacogroup.cropplan.db.dao.ntt.LandCoverCompatibilityCacheEntry;

import java.time.LocalDateTime;

public class LandCoverCompatibilityCacheMappings {

    public static LandCoverCompatibilityCacheEntry map(Integer typeId, LocalDateTime cacheDt, String lcc, String luc) {
        LandCoverCompatibilityCacheEntry entry = new LandCoverCompatibilityCacheEntry();
        entry.setTypeId(typeId);
        entry.setCacheDt(cacheDt);
        entry.setLandCoverCode(lcc);
        entry.setLandUseCode(luc);
        return entry;
    }
}
