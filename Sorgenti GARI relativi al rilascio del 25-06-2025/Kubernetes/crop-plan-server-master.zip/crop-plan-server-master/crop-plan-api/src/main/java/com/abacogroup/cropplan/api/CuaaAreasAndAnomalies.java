package com.abacogroup.cropplan.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CuaaAreasAndAnomalies {
	@NotNull
	@Schema(description = "The old UV total area")
	private Integer oldUVTotalAreaSqm;

	@NotNull
	@Schema(description = "The new UV total area")
	private Integer newUVTotalAreaSqm;

	@NotNull
	@Schema(description = "The new graphic total area")
	private Integer newGraphicTotalAreaSqm;

	@NotNull
	@Schema(description = "The difference between graphical total area sqm and new UV total area sqm")
	private Integer differenceBetweenNewUVAndGraphicAreaSqm;

	@NotNull
	@Schema(description = "Anomalies")
	private ValidationAnomalies anomalies;
}
