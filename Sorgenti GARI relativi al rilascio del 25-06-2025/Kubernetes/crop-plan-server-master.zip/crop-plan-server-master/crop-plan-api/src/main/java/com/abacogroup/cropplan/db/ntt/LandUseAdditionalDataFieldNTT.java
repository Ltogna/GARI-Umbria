package com.abacogroup.cropplan.db.ntt;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LandUseAdditionalDataFieldNTT {
	private Long id;
	private String landUseCode;
	private String fieldCode;
	private AbsoluteDate validFrom;
	private AbsoluteDate validTo;
	private Integer displayOrder;
	private String allowedValue;
	private Integer flDefault;
}
