package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class PlotDeclarationsNotEditableException extends WebApplicationException
{
	private static final long serialVersionUID = -4062149940247695272L;

	public static  class PlotDeclarationsNotEditableExceptionErrorBody
	{
		@Schema(allowableValues = "PLOT_DECLARATIONS_NOT_EDITABLE_EXCEPTION")
		public String getErrorCode()
		{
			return "PLOT_DECLARATIONS_NOT_EDITABLE_EXCEPTION";
		}
	}
	
	private static final PlotDeclarationsNotEditableExceptionErrorBody BODY = new PlotDeclarationsNotEditableExceptionErrorBody();

	public PlotDeclarationsNotEditableException(String plotCode)
	{
		super("The plot " + plotCode + " declarations are not editable",
			Response.status(Status.BAD_REQUEST).entity(BODY).build());
	}
}
