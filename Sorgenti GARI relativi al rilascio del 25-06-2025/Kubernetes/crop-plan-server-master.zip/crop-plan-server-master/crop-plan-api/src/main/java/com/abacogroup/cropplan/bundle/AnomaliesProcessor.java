package com.abacogroup.cropplan.bundle;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.cropplan.bundle.model.AnomaliesMessage;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;

public class AnomaliesProcessor extends AbstractConfigProcessor
{
	private static final String I18N_TABLE_NAME = "CRPL_ANOMALIES";
	private static final String I18N_FIELD_NAME = "ERROR_CODE";
	private static final String I18N_GENERIC_FIELD_NAME = "ERROR_CODE:GENERIC";

	public AnomaliesProcessor(CropPlanConfigDAO configDAO)
	{
		super(configDAO);
	}

	@Override
	public String getDomainName()
	{
		return "anomalies";
	}

	@Override
	public void onMessageInTransaction(CropPlanConfigDAO dao, ConfigDataMessage message)
	{
		message.getConfigFiles().stream()
			.map(Path::toFile)
			.filter(file -> file.getAbsolutePath().endsWith(".json"))
			.sorted()
			.forEach(file -> processFile(message.getTenantId(), file));
	}

	private void processFile(String tenantId, File file)
	{
		AnomaliesMessage message;
		try
		{
			message = objectMapper.readValue(file, AnomaliesMessage.class);
		}
		catch (IOException e)
		{
			throw new IllegalStateException("Error processing file " + file.getName() + " for tenant " + tenantId, e);
		}

		if (file.getAbsolutePath().endsWith(".delete.json"))
		{
			doDelete(tenantId, message);
		}
		else
		{
			doInsertOrUpdate(tenantId, message);
		}
	}

	private void doInsertOrUpdate(String tenantId, AnomaliesMessage message)
	{
		if (message == null || message.getAnomalies() == null || message.getAnomalies().isEmpty())
		{
			return;
		}

		message.getAnomalies().forEach(anomaly -> {
			anomaly.getI18nValues().forEach(i18nValue -> {
				configDAO.deleteI18nValue(I18N_TABLE_NAME, I18N_FIELD_NAME, anomaly.getErrorCode(), 
						i18nValue.getLanguage(), tenantId);

				configDAO.insertI18nValue(I18N_TABLE_NAME, I18N_FIELD_NAME, anomaly.getErrorCode(),
					i18nValue.getLanguage(), i18nValue.getText(), tenantId);
			});
			
			anomaly.getGenericI18nValues().forEach(i18nValue -> {
				configDAO.deleteI18nValue(I18N_TABLE_NAME, I18N_GENERIC_FIELD_NAME, anomaly.getErrorCode(), 
						i18nValue.getLanguage(), tenantId);

				configDAO.insertI18nValue(I18N_TABLE_NAME, I18N_GENERIC_FIELD_NAME, anomaly.getErrorCode(),
					i18nValue.getLanguage(), i18nValue.getText(), tenantId);
			});
		});
	}
	
	private void doDelete(String tenantId, AnomaliesMessage message)
	{
		if (message == null || message.getAnomalies() == null || message.getAnomalies().isEmpty())
		{
			return;
		}

		message.getAnomalies().forEach(anomaly -> {
			configDAO.deleteI18nValue(I18N_TABLE_NAME, I18N_FIELD_NAME, anomaly.getErrorCode(), null, tenantId);
			configDAO.deleteI18nValue(I18N_TABLE_NAME, I18N_GENERIC_FIELD_NAME, anomaly.getErrorCode(), null, tenantId);
		});
	}

}
