package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class CropPlanNotManagedException extends WebApplicationException {
	private static final long serialVersionUID = 4973519283505241729L;

	public static class CropPlanNotManagedExceptionErrorBody {
		@Schema(allowableValues = "CROP_PLAN_NOT_MANAGED_EXCEPTION")
		public String getErrorCode() {
			return "CROP_PLAN_NOT_MANAGED_EXCEPTION";
		}
	}

	private static final CropPlanNotManagedExceptionErrorBody BODY = new CropPlanNotManagedExceptionErrorBody();

	public CropPlanNotManagedException() {
		super("The crop plan is marked as not managed",
				Response.status(Status.FORBIDDEN).entity(BODY).build());
	}
}
