package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class SwapLandUsesPayload {
	@Schema(description = "The source land use code")
	@NotNull
	private String sourceLandUseCode;

	@Schema(description = "The new land use code")
	@NotNull
	private String newLandUseCode;

    @Schema(description = "The date to be evaluated")
    @NotNull
    private AbsoluteDate pointInTime;
    
    @Schema(description = "The date of the land use to be swapped to be evaluated")
    @NotNull
    private AbsoluteDate sourcePointInTime;
    
    @Schema(description = "The new from date (optional, if not set then the original date is preserved; if specified then also newToDate must be specified)")
    private AbsoluteDate newFromDate;
    
    @Schema(description = "The new to date (optional, if not set then the original date is preserved; if specified then also newFromDate must be specified)")
    private AbsoluteDate newToDate;
}
