package com.abacogroup.cropplan.enums;

public enum IgnoreValidationMessages {
	DO_NOT_IGNORE_MESSAGES,
	IGNORE_ALL_DECL_VALIDATION_WARNINGS,
	IGNORE_ALL_DECL_VALIDATION_MESSAGES
}
