package com.abacogroup.cropplan.db.ntt;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalFieldType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LandUseAdditionalDataConfNTT {
	private Long id; 
	private String fieldCode;
	private LandUseAdditionalFieldType fieldType;
	private AbsoluteDate validFrom;	
	private AbsoluteDate validTo;
	private Integer displayOrder;
	private Integer nullable;
	private Integer flShowInTooltip;
	private String groupCode;
	private String headerTitleCode;
	private Integer flEditable;
	private String formula;
}
