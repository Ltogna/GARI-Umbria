package com.abacogroup.cropplan.resources.pub;

import static java.util.stream.Collectors.toList;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.abacogroup.cropplan.api.CropPlan;
import com.abacogroup.cropplan.api.CropPlanType;
import com.abacogroup.cropplan.api.DisabledFunctionCode;
import com.abacogroup.cropplan.api.EditDeclarationResult;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.PlotDataToInclude;
import com.abacogroup.cropplan.api.PlotDeclaration;
import com.abacogroup.cropplan.api.PlotDeclaredAreas;
import com.abacogroup.cropplan.api.PlotDomain;
import com.abacogroup.cropplan.api.PlotLifecycle;
import com.abacogroup.cropplan.api.SortDeclaration;
import com.abacogroup.cropplan.api.SyncProgress;
import com.abacogroup.cropplan.api.SyncStatus;
import com.abacogroup.cropplan.api.payload.CreateCropPlanPayload;
import com.abacogroup.cropplan.api.payload.CreateVersionPayload;
import com.abacogroup.cropplan.api.payload.EditDeclarationPayload;
import com.abacogroup.cropplan.api.payload.EditDeclarationsPayload;
import com.abacogroup.cropplan.api.payload.SyncCropPlanPayload;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.exceptions.IncompatibleLandUseException;
import com.abacogroup.cropplan.exceptions.InvalidDeclAreaPercZeroException;
import com.abacogroup.cropplan.exceptions.InvalidDeclDatesException;
import com.abacogroup.cropplan.exceptions.InvalidDeclException;
import com.abacogroup.cropplan.exceptions.LandUseCodeNotFoundException;
import com.abacogroup.cropplan.exceptions.LockException;
import com.abacogroup.cropplan.exceptions.MaxDeclAreaException;
import com.abacogroup.cropplan.exceptions.PermanentCropFormNotAllowedException;
import com.abacogroup.cropplan.exceptions.PlotDeclarationsNotEditableException;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.BaseCropPlanResource;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.CropPlanVersion;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.Version;
import com.abacogroup.cropplan.sdk.model.config.CropPlanConfigParam;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseDetails;
import com.abacogroup.cropplan.sdk.model.domain.ParcelDescription;
import com.abacogroup.cropplan.sdk.model.sync.SyncType;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.CropPlanDeclarationsService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.DeclarationService;
import com.abacogroup.cropplan.services.LocksService;
import com.abacogroup.cropplan.services.SyncService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.cropplan.services.support.PlotTimeWindowParams;
import com.abacogroup.cropplan.services.support.PlotsTimeWindowParams;
import com.abacogroup.cropplan.services.support.PlotsTimeWindowPlotData;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.ForbiddenException;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("/public")
@Tag(name = "PUBLIC")
@Timed
@RolesAllowed({ "CRPL|USER", "CRPL|EDITOR" })
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class PublicCropPlanResources extends BaseCropPlanResource {
	private static final String DEFAULT_CROP_PLAN_TYPE = "CROPPLAN";
	private static final String DEFAULT_TENANT_ID = "_";
	private static final int PAGE_SIZE = 10;

	private final CropPlanService cropPlanService;
	private final CropPlanDeclarationsService cropPlanDeclarationsService;
	private final DeclarationService declarationsService;
	private final SyncService syncService;
	private final LocksService locksService;
	private final CropPlansDAO cropPlansDAO;
	private final DeclarationsDAO declarationsDAO;
	private final CropPlanConfigDAO cropPlanConfigDAO;
	private final PluginManager pluginManager;

	public PublicCropPlanResources(BaseService baseService, CropPlanService cropPlanService, CropPlanDeclarationsService cropPlanDeclarationsService,
			DeclarationService declarationsService, SyncService syncService, LocksService locksService,
			CropCodeService cropCodeService, ValidatorService validatorService, CropPlanConfigService cropPlanConfigService,
			PluginManager pluginManager, DAOContainer daocontainer) {
		super(baseService, cropPlanService, locksService, cropCodeService, validatorService, cropPlanConfigService, pluginManager, daocontainer.getCropPlansDAO()
		);
		this.cropPlanService = cropPlanService;
		this.cropPlanDeclarationsService = cropPlanDeclarationsService;
		this.declarationsService = declarationsService;
		this.syncService = syncService;
		this.locksService = locksService;
		this.pluginManager = pluginManager;
		this.cropPlansDAO = daocontainer.getCropPlansDAO();
		this.declarationsDAO = daocontainer.getDeclarationsDAO();
		this.cropPlanConfigDAO = daocontainer.getCropPlanConfigDAO();
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plan-types")
	@Operation(description = "Get the list of the available crop plan types")
	@ApiResponse(description = "The list of the available crop plan types")
	@Deprecated
	public List<CropPlanType> getCropPlanTypes(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		checkCanRead(user, language, businessId);

		return this.cropPlansDAO.getCropPlanTypes(DEFAULT_TENANT_ID, language);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans")
	@Operation(description = "Get the list of the crop plans of a business")
	@ApiResponse(description = "The list of the crop plans of the specified business")
	@Deprecated
	public InfiniteListResults<CropPlan> getCropPlans(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan type code; can be specified to filter crop plans of a specific type") @QueryParam("cropPlanTypeCode") String cropPlanTypeCode,
			@Parameter(description = "The search string to search by crop plan type or crop plan description") @QueryParam("search") String search,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(user, language, businessId);

		return cropPlanService.getCropPlans(env, businessId, cropPlanTypeCode, search, nextKey, PAGE_SIZE);
	}

	@PUT
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/lock")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Lock the specified crop plan for the current user")
	@ApiResponses({
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class)))
	})
	@Deprecated
	public void lockCropPlan(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);

		locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/versions")
	@Operation(description = "Get the versions list of a crop plan")
	@ApiResponse(description = "The versions list of the specified crop plan")
	@Deprecated
	public InfiniteListResults<CropPlanVersion> getAllVersions(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return cropPlanService.getAllVersions(env, businessId, cropPlanId, false, null, nextKey, PAGE_SIZE);
	}

	@POST
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/versions")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Create a new version of the specified crop plan")
	@ApiResponses({
			@ApiResponse(description = "The new crop plan version created"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "No changes pending on the crop plan")
	})
	@Deprecated
	public CropPlanVersion createVersion(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "If it is set to true then the specified crop plan is locked for the current user before version creation") @QueryParam("autoLock") @DefaultValue("false") boolean autoLock,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid CreateVersionPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		if (autoLock)
			locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
		else
			checkLock(env, cropPlanId);

		return cropPlanService.createVersion(createEnvironment(user, language), businessId, cropPlanId, payload, false);
	}

	@POST
	@Path("/v1/crop-plans/{businessId}/plans")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Create a new crop plan")
	@ApiResponses({
			@ApiResponse(description = "The new crop plan created"),
			@ApiResponse(responseCode = "400", description = "The crop plan type specified does not exist"),
			@ApiResponse(responseCode = "405", description = "A crop plan of the specified not multiple type already exist")
	})
	@Deprecated
	public CropPlan createCropPlan(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@NotNull @Valid CreateCropPlanPayload payload,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);

		var cropPlanId = cropPlanService.insertCropPlan(env, businessId, payload);
		return cropPlanService.getCropPlan(env, businessId, cropPlanId);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots")
	@Operation(description = "Get the list of the plots of a crop plan")
	@ApiResponse(description = "The list of the plots of the specified crop plan")
	@Deprecated
	public InfiniteListResults<Plot> getPlots(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "The ending point in time to be evaluated (optional, if set then the plots are evaluated between point in time and point in time to") @QueryParam("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		if (pointInTimeTo != null)
			return cropPlanService.getPlotsBetweenDates(createEnvironment(user, language), businessId, cropPlanId, domainZoneId,
					versionDt, pointInTime, pointInTimeTo, null, nextKey, PAGE_SIZE, new PlotDataToInclude(), false);
		else
			return cropPlanService.getPlots(createEnvironment(user, language), businessId, cropPlanId, domainZoneId,
					versionDt, pointInTime, null, null, nextKey, PAGE_SIZE, new PlotDataToInclude());
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/plots")
	@Operation(description = "Get the list of the plots of a crop plan")
	@ApiResponse(description = "The list of the plots of the specified crop plan")
	@Deprecated
	public InfiniteListResults<Plot> getPlotsByParcelCode(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "The ending point in time to be evaluated (optional, if set then the plots are evaluated between point in time and point in time to") @QueryParam("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@Parameter(description = "The parcel code search string to filter plots intersecting parcels") @QueryParam("parcelCodeStartsWith") @NotNull String parcelCodeStartsWith,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		if (pointInTimeTo != null)
			return cropPlanService.getPlotsBetweenDates(createEnvironment(user, language), businessId, cropPlanId, null,
					versionDt, pointInTime, pointInTimeTo, parcelCodeStartsWith, nextKey, PAGE_SIZE, new PlotDataToInclude(), false);
		else
			return cropPlanService.getPlots(createEnvironment(user, language), businessId, cropPlanId, null,
					versionDt, pointInTime, parcelCodeStartsWith, null, nextKey, PAGE_SIZE, new PlotDataToInclude());
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/plots/declarable-plots")
	@Operation(description = "Get the list of the plots of a crop plan")
	@ApiResponse(description = "The list of the plots of the specified crop plan")
	@Deprecated
	public List<PlotDomain> getDeclarablePlots(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "The ending point in time to be evaluated") @QueryParam("pointInTimeTo") @NotNull AbsoluteDate pointInTimeTo,
			@Parameter(description = "The land use code filter") @QueryParam("landUseCode") @NotNull String landUseCode,
			@Parameter(description = "The percentage of declared area") @QueryParam("declaredAreaPerc") @NotNull String declaredAreaPerc,
			@Parameter(description = "Can be supplied to convert geometries returned in the specified srs") @QueryParam("srs") String srs,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, DEFAULT_TENANT_ID);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		var landCoverCode = cropCodesPlugin.getLandCoverCode(env, landUseCode);
		var plotsByLandCoverCode = cropPlanService.getPlotsByLandCoverCode(env, businessId, cropPlanId, versionDt, pointInTime, pointInTimeTo, landCoverCode,
				srs, new PlotDataToInclude());

		List<PlotDomain> output = new ArrayList<>();
		for (PlotDomain plot : plotsByLandCoverCode) {
			var params = PlotTimeWindowParams.builder()
					.businessId(businessId)
					.cropPlanId(cropPlanId)
					.domainZoneId(plot.getDomainZone().getDomainZoneId())
					.plotCode(plot.getPlot().getPlotCode())
					.excludedDeclCode(null)
					.pointInTimeFrom(pointInTime)
					.pointInTimeTo(pointInTimeTo)
					.versionDt(versionDt)
					.build();
			var plotDeclaredAreas = cropPlanService.getPlotDeclaredAreas(params, false);

			if (Double.parseDouble(declaredAreaPerc) <= plotDeclaredAreas.getMaxDeclarableAreaPerc())
				output.add(plot);
		}
		return output;
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}")
	@Operation(description = "Get a plot")
	@ApiResponses({
			@ApiResponse(description = "The specified plot"),
			@ApiResponse(responseCode = "400", description = "The specified plot was not found")
	})
	@Deprecated
	public Plot getPlot(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		var plot = cropPlanService.getPlot(createEnvironment(user, language), businessId, cropPlanId, domainZoneId,
				versionDt, pointInTime, pointInTime, plotCode);

		if (plot == null)
			throw new BadRequestException("The specified plot was not found");

		return plot;
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/sync/status")
	@Operation(description = "Get the crop plan sync progress status")
	@ApiResponse(description = "The sync progress status")
	@Deprecated
	public SyncProgress getSyncProgressStatus(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return syncService.getSyncProgress(cropPlanId).getSyncProgressStatus();
	}

	@PUT
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/sync/{syncType}")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Synchronize crop plan")
	@ApiResponses({
			@ApiResponse(description = "The sync progress status"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class)))
	})
	@Deprecated
	public SyncProgress syncCropPlan(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@PathParam("syncType") SyncType syncType,
			@Parameter(description = "If it is set to true then the specified crop plan is locked for the current user before version creation") @QueryParam("autoLock") @DefaultValue("false") boolean autoLock,
			@Valid SyncCropPlanPayload payload,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		if (autoLock)
			locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
		else
			checkLock(env, cropPlanId);

		return syncService.syncCropPlan(env, businessId, cropPlanId, syncType, payload, false, false).getSyncProgressStatus();
	}

	@GET
	@Path("/v1.1/crop-plans/{businessId}/plans/{cropPlanId}/sync/status")
	@Operation(description = "Get the crop plan sync progress status")
	@ApiResponse(description = "The sync progress status")
	@Deprecated
	public SyncStatus getSyncProgressStatusV1_1(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return syncService.getSyncProgress(cropPlanId);
	}

	@PUT
	@Path("/v1.1/crop-plans/{businessId}/plans/{cropPlanId}/sync/{syncType}")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Synchronize crop plan")
	@ApiResponses({
			@ApiResponse(description = "The sync progress status"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class)))
	})
	@Deprecated
	public SyncStatus syncCropPlanV1_1(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@PathParam("syncType") SyncType syncType,
			@Parameter(description = "If it is set to true then the specified crop plan is locked for the current user before version creation") @QueryParam("autoLock") @DefaultValue("false") boolean autoLock,
			@Valid SyncCropPlanPayload payload,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		if (autoLock)
			locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
		else
			checkLock(env, cropPlanId);

		return syncService.syncCropPlan(env, businessId, cropPlanId, syncType, payload, false, false);
	}

	@POST
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/plots/decls")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Create multiple plots declarations")
	@ApiResponses({
			@ApiResponse(description = "The new plots declarations created"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot declarations are not editable", content = @Content(schema = @Schema(implementation = PlotDeclarationsNotEditableException.PlotDeclarationsNotEditableExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use is not allowed for the land cover", content = @Content(schema = @Schema(implementation = IncompatibleLandUseException.IncompatibleLandUseExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Maximum declarable area exceeded", content = @Content(schema = @Schema(implementation = MaxDeclAreaException.MaxDeclAreaExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration", content = @Content(schema = @Schema(implementation = InvalidDeclException.InvalidDeclExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration dates", content = @Content(schema = @Schema(implementation = InvalidDeclDatesException.InvalidDeclDatesExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid Decl Area Perc Zero", content = @Content(schema = @Schema(implementation = InvalidDeclAreaPercZeroException.ErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use was not found", content = @Content(schema = @Schema(implementation = LandUseCodeNotFoundException.LandUseCodeNotFoundExceptionErrorBody.class))),
	})
	@Deprecated
	public EditDeclarationResult createDeclarations(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@Parameter(description = "The point in time used to retrieve permanent crop form and land use additional field") @QueryParam("pointInTime") AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid EditDeclarationsPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		if (cropPlanConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.DISABLE_ADD_DECLARATIONS.toString(), "TRUE").size() > 0)
			throw new ForbiddenException("DISABLE_ADD_DECLARATIONS is set to TRUE");

		LocalDateTime currentDt = cropPlansDAO.getCurrentTimestamp();
		List<PlotsTimeWindowPlotData> plotsData = new ArrayList<>();
		payload.getPlots().forEach(p -> {
			var domainZoneId = cropPlansDAO.getDomainZoneIdByPlotCode(cropPlanId, p.getPlotCode());

			PlotTimeWindowParams ptwp = PlotTimeWindowParams.builder()
					.businessId(businessId)
					.cropPlanId(cropPlanId)
					.domainZoneId(domainZoneId)
					.plotCode(p.getPlotCode())
					.pointInTimeFrom(payload.getFromDate())
					.pointInTimeTo(payload.getToDate())
					.versionDt(currentDt)
					.build();
			checkCanDeclare(env, ptwp, payload.getLanduseCode(), p.getAreaPerc(), payload.isRemoveExistingDeclarations());

			var plot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId,
					currentDt, payload.getFromDate(), payload.getToDate(), p.getPlotCode());
			if (plot == null)
				throw new BadRequestException("The plot " + p.getPlotCode() + " was not found");

			checkPlotEditability(env, businessId, cropPlanId, plot);
			checkLandUseCompatibility(env, businessId, cropPlanId, plot, payload.getLanduseCode());

			cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.ADD_DECLARATIONS, env, businessId, cropPlanId, plot);

			List<String> parcelCodes = plot.getParcelIntersections().stream().map(ParcelIntersection::getCode).collect(toList());
			plotsData.add(PlotsTimeWindowPlotData.builder()
					.plotCode(p.getPlotCode())
					.parcelCodes(parcelCodes)
					.areaPerc(p.getAreaPerc())
					.declarations(plot.getDecls())
					.build());
		});

		if (payload.getPermanentCropForms() != null) {
			payload.getPermanentCropForms().forEach(pcf -> checkCanHavePermanentCropForm(env, businessId, cropPlanId, payload.getLanduseCode(),
					(pointInTime != null ? pointInTime : payload.getFromDate()), pcf.getFormType()));
		}
		checkCanHaveLandUseAdditionalField(env, businessId, cropPlanId, payload.getLanduseCode(), (pointInTime != null ? pointInTime : payload.getFromDate()),
				payload.getFieldsCodes());

		PlotsTimeWindowParams params = PlotsTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				//.domainZoneId(domainZoneId)
				.pointInTimeFrom(payload.getFromDate())
				.pointInTimeTo(payload.getToDate())
				.versionDt(currentDt)
				.plotsData(plotsData)
				.build();

		return cropPlanDeclarationsService.insertDeclarations(env, params, payload.getLanduseCode(), payload.getFromDatePrecision(),
				payload.getPermanentCropForms(), payload.getFieldsCodes(), payload.isRemoveExistingDeclarations(),
				ignoreDeclValidationWarnings, false);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/declarations")
	@Operation(description = "Get the declarations of the plots of a crop plan")
	@ApiResponse(description = "The declarations of the plots of the specified crop plan")
	@Deprecated
	public InfiniteListResults<PlotDeclaration> getDeclarations(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "The ending point in time to be evaluated (optional, if set then the declarations are evaluated between point in time and point in time to") @QueryParam("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@Parameter(description = "Exclude all declarations planted before this point in time") @QueryParam("excludePlantedBefore") AbsoluteDate excludePlantedBefore,
			@Parameter(description = "Exclude all declarations harvested after this point in time") @QueryParam("excludeHarvestedAfter") AbsoluteDate excludeHarvestedAfter,
			@Parameter(description = "The declarations sorting") @QueryParam("sort") SortDeclaration sort,
			@Parameter(description = "The search string to search by land use, parcel or domain zone") @QueryParam("search") String search,
			@Parameter(description = "The list of the land cover codes filter") @QueryParam("landCoverCodes") List<String> landCoverCodes,
			@Parameter(description = "The land use code filter") @QueryParam("landUseCode") String landUseCode,
			@Parameter(description = "The parcelCode filter") @QueryParam("parcelCode") String parcelCode,
			@Parameter(description = "The list of the declaration codes filter") @QueryParam("declCodes") List<String> declCodes,
			@Parameter(description = "Can be supplied to convert geometries returned in the specified srs") @QueryParam("srs") String srs,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		if (pointInTimeTo == null)
			pointInTimeTo = pointInTime;
		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		return declarationsService.getDeclarations(env, cropPlanId, businessId, pointInTime, pointInTimeTo, null, null, excludePlantedBefore,
				excludeHarvestedAfter,
				versionDt, sort, search, landCoverCodes, landUseCode, parcelCode, declCodes, null, srs, nextKey, PAGE_SIZE, null);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/declarations/updates")
	@Operation(description = "Get the declarations of the plots of a crop plan")
	@ApiResponse(description = "The declarations of the plots of the specified crop plan")
	@Deprecated
	public InfiniteListResults<PlotDeclaration> getDeclarationsUpdates(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "The ending point in time to be evaluated (optional, if set then the declarations are evaluated between point in time and point in time to") @QueryParam("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@Parameter(description = "The point in time to be evaluated for updates") @QueryParam("updateTimeFrom") LocalDateTime updateTimeFrom,
			@Parameter(description = "The ending point in time to be evaluated for updates") @QueryParam("updateTimeTo") @NotNull LocalDateTime updateTimeTo,
			@Parameter(description = "The list of the land cover codes filter") @QueryParam("landCoverCodes") List<String> landCoverCodes,
			@Parameter(description = "Can be supplied to convert geometries returned in the specified srs") @QueryParam("srs") String srs,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		if (pointInTimeTo == null)
			pointInTimeTo = pointInTime;
		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		return declarationsService.getDeclarations(env, cropPlanId, businessId, pointInTime, pointInTimeTo, updateTimeFrom, updateTimeTo, null, null,
				versionDt, null, null, landCoverCodes, null, null, null, null, srs, nextKey, PAGE_SIZE, null);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/declarations/updates/last-modification-date")
	@Operation(description = "Get the declarations updates of the plots of a crop plan")
	@ApiResponse(description = "The declarations updates of the plots of the specified crop plan")
	@Deprecated
	public LocalDateTime getDeclarationsLastModificationDate(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The list of the land cover codes filter") @QueryParam("landCoverCode") @NotNull List<String> landCoverCode,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var date = declarationsService.getDeclarationsLastModificationDate(env, businessId, cropPlanId, landCoverCode);
		if (date == null)
			return LocalDateTime.of(1970, 1, 1, 0, 0);
		else
			return date;
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/declarations/land-uses")
	@Operation(description = "Get the declarations land uses of a crop plan")
	@ApiResponses(@ApiResponse(description = "The declarations land uses of a crop plan"))
	@Deprecated
	public List<LandUse> getDeclarationsLandUses(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "The ending point in time to be evaluated (optional, if set then the declarations are evaluated between point in time and point in time to") @QueryParam("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		if (pointInTimeTo == null)
			pointInTimeTo = pointInTime;
		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();

		return declarationsService.getDeclarationsLandUses(env, cropPlanId, businessId, pointInTime, pointInTimeTo, versionDt);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/declarations/parcels")
	@Operation(description = "Get the declarations parcels of a crop plan")
	@ApiResponses(@ApiResponse(description = "The declarations parcels of a crop plan"))
	@Deprecated
	public List<ParcelDescription> getDeclarationsParcels(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "The ending point in time to be evaluated (optional, if set then the declarations are evaluated between point in time and point in time to") @QueryParam("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		if (pointInTimeTo == null)
			pointInTimeTo = pointInTime;
		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();

		return declarationsService.getDeclarationsParcels(env, cropPlanId, businessId, pointInTime, pointInTimeTo, versionDt);
	}

	@PUT
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/decls/{declCode}")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Update a plot declaration")
	@ApiResponses({
			@ApiResponse(description = "The updated plot declaration"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot declarations are not editable", content = @Content(schema = @Schema(implementation = PlotDeclarationsNotEditableException.PlotDeclarationsNotEditableExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use is not allowed for the land cover", content = @Content(schema = @Schema(implementation = IncompatibleLandUseException.IncompatibleLandUseExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Maximum declarable area exceeded", content = @Content(schema = @Schema(implementation = MaxDeclAreaException.MaxDeclAreaExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration", content = @Content(schema = @Schema(implementation = InvalidDeclException.InvalidDeclExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration dates", content = @Content(schema = @Schema(implementation = InvalidDeclDatesException.InvalidDeclDatesExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Permanent crop form not allowed for the land use", content = @Content(schema = @Schema(implementation = PermanentCropFormNotAllowedException.PermanentCropFormNotAllowedExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid Decl Area Perc Zero", content = @Content(schema = @Schema(implementation = InvalidDeclAreaPercZeroException.ErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use was not found", content = @Content(schema = @Schema(implementation = LandUseCodeNotFoundException.LandUseCodeNotFoundExceptionErrorBody.class))),
	})
	@Deprecated
	public EditDeclarationResult updateDeclaration(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The plot declaration code") @PathParam("declCode") String declCode,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@Parameter(description = "The point in time used to retrieve permanent crop form and land use additional field") @QueryParam("pointInTime") AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid EditDeclarationPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		LocalDateTime currentDt = cropPlansDAO.getCurrentTimestamp();
		PlotTimeWindowParams params = PlotTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.domainZoneId(domainZoneId)
				.plotCode(plotCode)
				.excludedDeclCode(declCode)
				.pointInTimeFrom(payload.getFromDate())
				.pointInTimeTo(payload.getToDate())
				.versionDt(currentDt)
				.build();
		checkCanDeclare(env, params, payload.getLanduseCode(), payload.getAreaPerc());

		var plot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId,
				currentDt, payload.getFromDate(), payload.getToDate(), plotCode);
		if (plot == null)
			throw new BadRequestException("The plot " + plotCode + " was not found");
		checkPlotEditability(env, businessId, cropPlanId, plot);
		checkLandUseCompatibility(env, businessId, cropPlanId, plot, payload.getLanduseCode());

		if (payload.getPermanentCropForms() != null) {
			payload.getPermanentCropForms().forEach(pcf -> checkCanHavePermanentCropForm(env, businessId, cropPlanId, payload.getLanduseCode(),
					(pointInTime != null ? pointInTime : payload.getFromDate()), pcf.getFormType()));
		}

		checkCanHaveLandUseAdditionalField(env, businessId, cropPlanId, payload.getLanduseCode(), (pointInTime != null ? pointInTime : payload.getFromDate()),
				payload.getFieldsCodes());

		return cropPlanDeclarationsService.updateDeclaration(env, params, declCode, payload.getLanduseCode(), payload.getAreaPerc(),
				payload.getFromDatePrecision(),
				plot.getParcelIntersections(), payload.getPermanentCropForms(), payload.getFieldsCodes(), ignoreDeclValidationWarnings, false, false);
	}

	@DELETE
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/decls/{declCode}")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Delete a plot declaration")
	@ApiResponses({
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot declarations are not editable", content = @Content(schema = @Schema(implementation = PlotDeclarationsNotEditableException.PlotDeclarationsNotEditableExceptionErrorBody.class))),
	})
	@Deprecated
	public EditDeclarationResult deleteDeclaration(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The plot declaration code") @PathParam("declCode") String declCode,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		LocalDateTime currentDt = cropPlansDAO.getCurrentTimestamp();
		PlotTimeWindowParams params = PlotTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.domainZoneId(domainZoneId)
				.plotCode(plotCode)
				.excludedDeclCode(declCode)
				.pointInTimeFrom(null)
				.pointInTimeTo(null)
				.versionDt(currentDt)
				.build();

		var decl = declarationsDAO.getDeclarationByDeclCode(cropPlanId, plotCode, currentDt, declCode);

		var plot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId,
				currentDt, decl.getFromDate(), decl.getToDate(), plotCode);
		if (plot == null)
			throw new BadRequestException("The plot " + plotCode + " was not found");
		checkPlotEditability(env, businessId, cropPlanId, plot);

		return cropPlanDeclarationsService.deleteDeclaration(env, params, decl, plot.getParcelIntersections(), ignoreDeclValidationWarnings, false);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/lifecycle")
	@Operation(description = "Get the lifecycle details of a plot")
	@ApiResponses({
			@ApiResponse(description = "The lifecycle details of the specified plot"),
			@ApiResponse(responseCode = "400", description = "The specified plot was not found")
	})
	@Deprecated
	public PlotLifecycle getPlotLifecycle(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		return cropPlansDAO.getPlotLifecycle(cropPlanId, domainZoneId, versionDt, plotCode);
	}

	@GET
	@Path("/v1/crop-plans/land-uses")
	@Operation(description = "Get the list of the land uses")
	@ApiResponse(description = "The list of the land uses")
	@Deprecated
	public InfiniteListResults<LandUseDetails> getLandUseCodes(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The list of the land cover codes") @QueryParam("landCoverCodes") List<String> landCoverCodes,
			@Parameter(description = "The search string") @QueryParam("search") String search,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		return pluginManager.getCropCodesPlugin(env, DEFAULT_CROP_PLAN_TYPE).getLandUseCodesInfinite(env, null, landCoverCodes, search,
				new ArrayList<>(), pointInTime.toLocalDate(), false, nextKey);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/declared-areas")
	@Operation(description = "Get the declared areas of a plot in a time window")
	@ApiResponse(description = "The declared areas of the plot in the specified time window")
	@Deprecated
	public PlotDeclaredAreas getPlotDeclaredAreas(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The starting point in time to be evaluated") @QueryParam("pointInTimeFrom") @NotNull AbsoluteDate pointInTimeFrom,
			@Parameter(description = "The ending point in time to be evaluated") @QueryParam("pointInTimeTo") @NotNull AbsoluteDate pointInTimeTo,
			@Parameter(description = "Optional declaration code to exclude from the result") @QueryParam("excludedDeclCode") String excludedDeclCode,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		var params = PlotTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.domainZoneId(domainZoneId)
				.plotCode(plotCode)
				.excludedDeclCode(excludedDeclCode)
				.pointInTimeFrom(pointInTimeFrom)
				.pointInTimeTo(pointInTimeTo)
				.versionDt(versionDt)
				.build();
		return cropPlanService.getPlotDeclaredAreas(params, false);
	}

	/*@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/anomalies")
	@Operation(description = "Get the crop plan anomalies")
	@ApiResponse(description = "The crop plan anomalies")
	public List<CropPlanAnomaly> getCropPlanAnomalies(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		return cropPlanService.getCropPlanAnomaliesProxy(cropPlanId, versionDt);
	}*/
}
