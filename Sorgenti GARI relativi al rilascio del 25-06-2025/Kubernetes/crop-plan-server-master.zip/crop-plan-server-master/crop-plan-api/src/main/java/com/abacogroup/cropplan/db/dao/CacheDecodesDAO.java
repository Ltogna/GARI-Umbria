package com.abacogroup.cropplan.db.dao;

import com.abacogroup.cropplan.db.ntt.CacheDecodeNTT;
import java.time.LocalDateTime;
import java.util.List;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.BatchChunkSize;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

public interface CacheDecodesDAO extends BasicDAO, Transactional<CacheDecodesDAO> {
	public enum CACHE_DECODES_TYPE {
		LAND_USE,
		PARCEL,
		PARCEL_CODE,
		LAND_COVER_COMPATIBILITY,
		DOMAIN,
		PESTICIDES,
		PESTS,
		PESTS_QUARANTINE_DAYS,
		PESTICIDES_UOM
	};

	@SqlQuery("select type_id from crpl_plans where id = :cropPlanId")
	Long findCropPlanTypeId(@Bind("cropPlanId") Long cropPlanId);

	@Deprecated
	@SqlUpdate("delete from cache_decodes"
			+ "           where type_id = (select type_id from crpl_plans where id = :cropPlanId)"
			+ "             and type = :type"
			+ "             and dt_cache < :cacheValidityDt")
	public void clearCacheDecodes(@Bind("cropPlanId") Long cropPlanId, @Bind("type") String type,
			@Bind("cacheValidityDt") LocalDateTime cacheValidityDt);

	@Deprecated
	@SqlUpdate("insert into cache_decodes (type, dt_cache, code, description, type_id)"
			+ "     values (:type, :cacheDt, :code, :description, (select type_id from crpl_plans where id = :cropPlanId))")
	public void insertCacheDecodes(@Bind("cropPlanId") Long cropPlanId, @Bind("type") String type,
			@Bind("cacheDt") LocalDateTime cacheDt,
			@Bind("code") String code, @Bind("description") String description);

	@SqlUpdate("delete from cache_decodes"
			   + "           where type_id = :typeId"
			   + "             and type in (<types>)"
			   + "             and dt_cache < :cacheValidityDt")
	public void clearCacheDecodes(
			@BindList("types") List<String> types,
			@Bind("cacheValidityDt") LocalDateTime cacheValidityDt,
			@Bind("typeId") Long cropPlanTypeId
	);

	@SqlBatch("insert into cache_decodes (type, dt_cache, code, description, type_id)"
			  + "     values (:type, :cacheDt, :code, :description, :cropPlanTypeId)")
	@BatchChunkSize(2000)
	public void insertCacheDecodes(@BindBean CacheDecodeNTT... cacheDecodeNTT);
}
