package com.abacogroup.cropplan.db.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.cropplan.db.dao.ntt.PermanentCropFormWithDeclCode;
import com.abacogroup.cropplan.sdk.mapper.VersionColumnMapper;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormData;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormFieldValue;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(VersionColumnMapper.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface CommonPcfDAO extends BasicDAO
{

	@SqlQuery("§select_nextval(crpl_perm_crop_forms_seq)§")
	public Long getPermanentCropFormsSeq();

	@SqlUpdate("insert into crpl_perm_crop_forms (id, form_code, form_type, plan_id, plot_code, decl_code, user_id_insert, dt_insert, dt_delete, transaction_id," +
		"         area_sqm, distance_on_the_row_cm, distance_between_rows_cm, stumps_number," +
		"         farming_form, irrigation, product_destination_code, cultivation_type_code, variety_code, variation_type_code," +
		"         vineyard_type_code, planting_type, layering, rock, skeleton, vegetative_state, pruning, judgement," +
		"         stumps_density_100, failures_perc, soil_layering_perc, altitude_above_sea_level, terracing," +
		"         header_anchoring, poles_header, poles_weaving, poles_distance_cm, support_wires, cultivation_state, origin," +
		"         graft_date, graft_holder, covering, bio, fl_versioned, subscription_codes, external_code, quality_system, protection_structures, " +
		" 		  planting_year, shift_in_years, expected_cutting_date)" +
		"        values (:pcfId, :formCode, :formType, :cropPlanId, :plotCode, :declCode, :userId, :insertDt, TO_DATE('99991231','YYYYMMDD'), :transId," +
		"         :pcf.areaSqm, :pcf.distanceOnTheRowCm, :pcf.distanceBetweenRowsCm," +
		"         :pcf.stumpsNumber, :pcf.farmingForm, :pcf.irrigation, :pcf.productDestinationCode, :pcf.cultivationTypeCode, :pcf.varietyCode," +
		"         :pcf.variationTypeCode, :pcf.vineyardTypeCode, :pcf.plantingType, :pcf.layering, :pcf.rock, :pcf.skeleton, :pcf.vegetativeState," +
		"         :pcf.pruning, :pcf.judgement, :pcf.stumpsDensity100, :pcf.failuresPerc, :pcf.soilLayeringPerc, :pcf.altitudeAboveSeaLevel," +
		"         :pcf.terracing, :pcf.headerAnchoring, :pcf.polesHeader, :pcf.polesWeaving, :pcf.polesDistanceCm, :pcf.supportWires, :pcf.cultivationState, " +
		"         :pcf.origin, :pcf.graftDate, :pcf.graftHolder, :pcf.covering, :pcf.bio, 0, :pcf.subscriptionCodes, :pcf.externalCode, "
		+ "       :pcf.qualitySystem, :pcf.protectionStructures, :pcf.plantingYear, :pcf.shiftInYears, :pcf.expectedCuttingDate)")
	public void insertPermanentCropForm(@Bind("pcfId") Long pcfId, @Bind("formCode") String formCode, @Bind("formType") String formType,
		@Bind("cropPlanId") Long cropPlanId, @Bind("plotCode") String plotCode, @Bind("declCode") String declCode, @Bind("userId") String userId,
		@Bind("insertDt") LocalDateTime insertDt, @Bind("transId") LocalDateTime transId,
		@BindBean("pcf") PermanentCropFormData pcf);

	@SqlUpdate("update CRPL_PERM_CROP_FORMS"
		+ "        set DT_DELETE = :deleteDt, USER_ID_DELETE = :userId, transaction_id = :transId"
		+ "      where (:formCode is null or form_code = :formCode)"
		+ "        and DECL_CODE = :declCode"
		+ "        and plot_code = :plotCode"
		+ "        and PLAN_ID = :cropPlanId"
		+ "        and §current_timestamp§ between DT_INSERT and DT_DELETE")
	public int deletePermanentCropFormsInternal(@Bind("formCode") String formCode, @Bind("declCode") String declCode, @Bind("plotCode") String plotCode,
		@Bind("cropPlanId") Long cropPlanId, @Bind("deleteDt") LocalDateTime deleteDt, @Bind("userId") String userId, @Bind("transId") LocalDateTime transId);
	
	@SqlQuery("SELECT plot_code as plotCode, DECL_CODE as declCode, FORM_CODE as formCode, FORM_TYPE as formType, " 
			+ "       AREA_SQM as pcfd_areaSqm, DISTANCE_ON_THE_ROW_CM as pcfd_distanceOnTheRowCm, " 
			+ "       DISTANCE_BETWEEN_ROWS_CM as pcfd_distanceBetweenRowsCm, STUMPS_NUMBER as pcfd_stumpsNumber, FARMING_FORM as pcfd_farmingForm, IRRIGATION as pcfd_irrigation, PRODUCT_DESTINATION_CODE as pcfd_productDestinationCode,"
			+ "       CULTIVATION_TYPE_CODE as pcfd_cultivationTypeCode, VARIETY_CODE as pcfd_varietyCode, VARIATION_TYPE_CODE as pcfd_variationTypeCode, VINEYARD_TYPE_CODE as pcfd_vineyardTypeCode,"
			+ "       PLANTING_TYPE as pcfd_plantingType, LAYERING as pcfd_layering, ROCK as pcfd_rock, SKELETON as pcfd_skeleton, VEGETATIVE_STATE as pcfd_vegetativeState, PRUNING as pcfd_pruning, JUDGEMENT as pcfd_judgement,"
			+ "       STUMPS_DENSITY_100 as pcfd_stumpsDensity100, FAILURES_PERC as pcfd_failuresPerc, SOIL_LAYERING_PERC as pcfd_soilLayeringPerc, ALTITUDE_ABOVE_SEA_LEVEL as pcfd_altitudeAboveSeaLevel, "
			+ "       TERRACING as pcfd_terracing, HEADER_ANCHORING as pcfd_headerAnchoring, POLES_HEADER as pcfd_polesHeader, POLES_WEAVING as pcfd_polesWeaving, POLES_DISTANCE_CM as pcfd_polesDistanceCm, SUPPORT_WIRES as pcfd_supportWires,"
			+ "       CULTIVATION_STATE as pcfd_cultivationState, ORIGIN as pcfd_origin, GRAFT_DATE as pcfd_graftDate, GRAFT_HOLDER as pcfd_graftHolder, COVERING as pcfd_covering, BIO as pcfd_bio,"
			+ "       subscription_codes as pcfd_subscriptionCodes, external_code as pcfd_externalCode, quality_system as pcfd_qualitySystem, protection_structures as pcfd_protectionStructures, "
			+ "       planting_year as pcfd_plantingYear, shift_in_years as pcfd_shiftInYears, expected_cutting_date as pcfd_expectedCuttingDate"
			+ "  FROM CRPL_PERM_CROP_FORMS " 
			+ " WHERE DECL_CODE in (<declCodes>) " 
			+ " AND (:plotCode is null or PLOT_CODE = :plotCode) " 
			+ " AND PLAN_ID = :cropPlanId " 
			+ " AND :versionDt between dt_insert and dt_delete")
	@RegisterBeanMapper(PermanentCropFormWithDeclCode.class)
	@RegisterBeanMapper(PermanentCropFormData.class)
	public List<PermanentCropFormWithDeclCode> getPermanentCropForms(@BindList("declCodes") List<String> declCodes,
			@Bind("plotCode") String plotCode,
			@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlQuery("select cpcfv.field_code as fieldCode," +
			"             cpcfv.field_value as fieldValue," +
			"             coalesce(§i18n(:tenantId, 'CRPL_PERM_CROP_FIELD_VALUES', 'I18N_VALUE', cpcfv.i18n_value, :language)§, cpcfv.i18n_value) as fieldValueDescription"
			+
			"        from crpl_perm_crop_field_values cpcfv, crpl_plans cp" +
			"       where cp.id = :cropPlanId" +
			"         and cpcfv.type_id = cp.type_id" +
			"         and cpcfv.form_type = :formType")
	@RegisterBeanMapper(PermanentCropFormFieldValue.class)
	public List<PermanentCropFormFieldValue> getPermanentCropFormFieldsValues(@Bind("tenantId") String tenantId,
			@Bind("language") String language, @Bind("cropPlanId") Long cropPlanId, @Bind("formType") String formType);
}
