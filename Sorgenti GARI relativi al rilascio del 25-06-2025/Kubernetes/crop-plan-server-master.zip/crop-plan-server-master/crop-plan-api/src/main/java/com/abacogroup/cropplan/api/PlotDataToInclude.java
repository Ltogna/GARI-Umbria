package com.abacogroup.cropplan.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PlotDataToInclude 
{
	public static final PlotDataToInclude EXCLUDE_ALL = new PlotDataToInclude(false, false, false, false, false, false, false, false, false, false);
	public static final PlotDataToInclude ONLY_DECLS = new PlotDataToInclude(false, false, false, false, false, false, true, false, false, false);
	public static final PlotDataToInclude ALL_ANOMALIES = new PlotDataToInclude(true, false, false, false, false, false, true, false, false, true);

	@Builder.Default
	private Boolean parcInt = true;
	
	@Builder.Default
	private Boolean parcIntDesc = true;
	
	@Builder.Default
	private Boolean parcIntLandCoverDesc = true;
	
	@Builder.Default
	private Boolean mbrOverview = true;
	
	@Builder.Default
	private Boolean parcStyle = true;
	
	@Builder.Default
	private Boolean plotEditability = true;
	
	@Builder.Default
	private Boolean decls = true;
	
	@Builder.Default
	private Boolean declsPesticides = true;
	
	@Builder.Default
	private Boolean declsStyle = true;
	
	@Builder.Default
	private Boolean anomalies = true;

}
