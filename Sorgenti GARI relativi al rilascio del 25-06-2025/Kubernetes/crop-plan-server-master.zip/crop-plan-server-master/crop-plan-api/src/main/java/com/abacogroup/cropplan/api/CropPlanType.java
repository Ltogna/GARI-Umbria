package com.abacogroup.cropplan.api;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Crop plan type")
public class CropPlanType
{
	@Schema(description = "The crop plan type code")
	@NotEmpty
	private String cropPlanTypeCode;
	
	@NotEmpty
	private String description;
	
	@Schema(description = "When true, multiple instances of this crop plan type can exist in parallel for a any businesses")
	@NotNull
	private Boolean multiple;

	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;

}
