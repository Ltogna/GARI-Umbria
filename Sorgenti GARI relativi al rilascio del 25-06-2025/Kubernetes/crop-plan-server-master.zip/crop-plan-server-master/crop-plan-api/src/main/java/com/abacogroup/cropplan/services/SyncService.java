package com.abacogroup.cropplan.services;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.cropplan.CropPlanConfiguration;
import com.abacogroup.cropplan.api.SyncOperation;
import com.abacogroup.cropplan.api.SyncProgress;
import com.abacogroup.cropplan.api.SyncStatus;
import com.abacogroup.cropplan.api.payload.CopyCampaignPayload;
import com.abacogroup.cropplan.api.payload.InsertPermanentCropForm;
import com.abacogroup.cropplan.api.payload.SyncCropPlanPayload;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.SyncDAO;
import com.abacogroup.cropplan.exceptions.CropPlanNotManagedException;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import com.abacogroup.cropplan.sdk.model.sync.LatestSync;
import com.abacogroup.cropplan.sdk.model.sync.SyncType;
import com.abacogroup.cropplan.sdk.spi.SyncPlugin;
import com.abacogroup.cropplan.services.eqjobs.SyncJobConsumer;
import com.abacogroup.cropplan.services.eqjobs.payload.SyncQueuePayload;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import jakarta.ws.rs.BadRequestException;
import lombok.Setter;

public class SyncService
{
	private static final Logger log = LoggerFactory.getLogger(SyncService.class);

	private final CropPlanService cropPlanService;
	private final CropPlanConfigService cropPlanConfigService;
	private final SyncJobConsumer syncJobConsumer;

	private final SyncDAO syncDAO;
	private final PluginManager pluginManager;
	private final CropPlanConfiguration configuration;

	@Setter
	private WorkQueue<SyncQueuePayload> syncQueue;

	public SyncService(CropPlanService cropPlanService, CropPlanConfigService cropPlanConfigService, SyncJobConsumer syncJobConsumer,
			DAOContainer daocontainer, PluginManager pluginManager, CropPlanConfiguration configuration)
	{
		this.cropPlanService = cropPlanService;
		this.cropPlanConfigService = cropPlanConfigService;
		this.syncJobConsumer = syncJobConsumer;

		this.syncDAO = daocontainer.getSyncDAO();

		this.pluginManager = pluginManager;
		this.configuration = configuration;
	}
	
	public InfiniteListResults<SyncOperation> getSyncOperations(Long cropPlanId, String nextKey, int pageSize)
	{
		return syncDAO.infinite(() -> syncDAO.getSyncOperations(cropPlanId),
				nextKey,
				pageSize);
	}

	public SyncStatus getSyncProgress(Long cropPlanId)
	{
		var currentDt = syncDAO.getCurrentTimestamp();
		return getSyncProgressInternal(cropPlanId, currentDt);
	}

	public SyncStatus declMassiveFieldsUpdate(RuntimeEnvironment env, String businessId, Long cropPlanId,
			AbsoluteDate pointInTime, List<String> domainZoneIds, Map<String, List<Integer>> landUseCodesWithRotation,
			List<InsertPermanentCropForm> newPermanentCropForms,
			List<LandUseAdditionalDataField> newFieldsCodes, boolean ignoreDeclValidationWarnings) {

		checkIsCropPlanNotManaged(cropPlanId);

		var currentDt = syncDAO.getCurrentTimestamp();

		var inProgress = getSyncProgressInternal(cropPlanId, currentDt);
		if (inProgress.getSyncProgressStatus() == SyncProgress.IN_PROGRESS)
			return inProgress;

		var syncPlugin = pluginManager.getSyncPlugin(businessId, cropPlanId, env.getTenantId());
		var syncPluginDt = syncPlugin.getSyncPluginDate(env);
		if (syncPluginDt == null)
			syncPluginDt = currentDt;


		launchSyncCropPlan(env, SyncQueuePayload.builder()
				.username(env.getUserName())
				.tenant(env.getTenantId())
				.language(env.getLocale().getLanguage())
				.syncType(SyncType.MASSIVE_FIELDS_UPDATE)
				.syncPluginDt(syncPluginDt)
				.currentDt(currentDt)
				.isRecalcAnomaliesNeeded(false)
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.referenceDt(pointInTime)
				.domainZoneIds(domainZoneIds)
				.landUseCodesWithRotation(landUseCodesWithRotation)
				.newPermanentCropForms(newPermanentCropForms)
				.newFieldsCodes(newFieldsCodes)
				.ignoreDeclValidationWarnings(ignoreDeclValidationWarnings)
				.build());

		return getSyncProgress(cropPlanId);
	}

	public SyncStatus copyCampaign(RuntimeEnvironment env, String businessId, Long cropPlanId, CopyCampaignPayload payload) {

		/*if (env.getProperty("validatorUrl") != null) {
			throw new BadRequestException("Configuration error: copyCampaign is not available with a validatorUrl configured!");
		}*/

		checkIsCropPlanNotManaged(cropPlanId);

		var currentDt = syncDAO.getCurrentTimestamp();

		var inProgress = getSyncProgressInternal(cropPlanId, currentDt);
		if (inProgress.getSyncProgressStatus() == SyncProgress.IN_PROGRESS)
			return inProgress;

		var syncPlugin = pluginManager.getSyncPlugin(businessId, cropPlanId, env.getTenantId());
		var syncPluginDt = syncPlugin.getSyncPluginDate(env);
		if (syncPluginDt == null)
			syncPluginDt = currentDt;


		launchSyncCropPlan(env, SyncQueuePayload.builder()
				.username(env.getUserName())
				.tenant(env.getTenantId())
				.language(env.getLocale().getLanguage())
				.syncType(SyncType.COPY_CAMPAIGN)
				.syncPluginDt(syncPluginDt)
				.currentDt(currentDt)
				.isRecalcAnomaliesNeeded(true)
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.referenceDt(payload.getDestPointInTime())
				.sourceCropPlanId(payload.getSourceCropPlanId())
				.sourceVersion(payload.getSourceVersion())
				.sourcePointInTime(payload.getSourcePointInTime())
				.landuseCodesExcludedFromAggregation(payload.getLanduseCodesExcludedFromAggregation())
				.flCopyFromOtherBusinesses(payload.isFlCopyFromOtherBusinesses())
				.preserveSourceDeclDates(payload.isPreserveSourceDeclDates())
				.skipAggregation(payload.isSkipAggregation())
				.declsPointInTimeTo(payload.getDeclsPointInTimeTo())
				.build());

		return getSyncProgress(cropPlanId);
	}

	public SyncStatus syncCropPlan(RuntimeEnvironment env, String businessId, Long cropPlanId, SyncType syncType, SyncCropPlanPayload payload, 
			boolean ignoreDefaults, boolean ignorePreviousSyncs)
	{
		checkSyncTypeAllowed(syncType);
		checkIsCropPlanNotManaged(cropPlanId);

		var currentDt = syncDAO.getCurrentTimestamp();

		var inProgress = getSyncProgressInternal(cropPlanId, currentDt);
		if (inProgress.getSyncProgressStatus() == SyncProgress.IN_PROGRESS)
			return inProgress;

		var syncPlugin = pluginManager.getSyncPlugin(businessId, cropPlanId, env.getTenantId());
		var syncPluginDt = syncPlugin.getSyncPluginDate(env);
		if (syncPluginDt == null)
			syncPluginDt = currentDt;

		var lastSyncDt = buildLastSyncDt(cropPlanId, syncType, ignorePreviousSyncs);
		
		AbsoluteDate referenceDt = buildSyncReferenceDate(payload);
		
		boolean recalcAnomaliesNeeded = isRecalcAnomaliesNeeded(env, businessId, cropPlanId, syncPlugin, lastSyncDt, ignorePreviousSyncs, currentDt,
				referenceDt);

		LocalDate oldestChangesDateFromLpisDate = buildOldestChangesDateFromLpisDate(env, businessId, cropPlanId, syncType, syncPlugin, syncPluginDt,
				lastSyncDt);
		
		var needsSync = needsSync(syncType, recalcAnomaliesNeeded, oldestChangesDateFromLpisDate);
		if (!needsSync)
			return new SyncStatus(SyncProgress.COMPLETED, null, false);

		if (syncType == SyncType.LPIS || syncType == SyncType.LPIS_LITE) {
			if (oldestChangesDateFromLpisDate == null && recalcAnomaliesNeeded)
				syncType = SyncType.RECALC_ANOMALIES;
			else if (!recalcAnomaliesNeeded)
				recalcAnomaliesNeeded = true;
		}

		launchSyncCropPlan(env, new SyncQueuePayload(env.getUser().getName(), env.getTenantId(), env.getLocale().getLanguage(),
				businessId, cropPlanId, syncType, ignoreDefaults, currentDt, syncPluginDt, lastSyncDt, referenceDt, recalcAnomaliesNeeded,
				oldestChangesDateFromLpisDate));

		return getSyncProgressInternal(cropPlanId, currentDt);

	}

	private void checkSyncTypeAllowed(SyncType syncType) {
		if (SyncType.COPY_CAMPAIGN.equals(syncType) || SyncType.MASSIVE_FIELDS_UPDATE.equals(syncType)) {
			throw new BadRequestException(syncType.toString() + " not allowed here");
		}
	}

	private void checkIsCropPlanNotManaged(Long cropPlanId) {
		if (cropPlanService.getCropPlanServiceUtils().isCropPlanNotManaged(cropPlanId))
			throw new CropPlanNotManagedException();
	}

	private AbsoluteDate buildSyncReferenceDate(SyncCropPlanPayload payload) {
		return payload != null ? payload.getPointInTime() : null;
	}

	private LocalDate buildOldestChangesDateFromLpisDate(RuntimeEnvironment env, String businessId, Long cropPlanId, SyncType syncType, SyncPlugin syncPlugin,
			LocalDateTime syncPluginDt, LocalDateTime lastSyncDt) {

		return syncType == SyncType.LPIS || syncType == SyncType.LPIS_LITE
				? syncPlugin.getOldestChangesDateFromLpisDate(env, businessId, cropPlanId, lastSyncDt, syncPluginDt, syncType == SyncType.LPIS_LITE)
				: null;
	}

	private LocalDateTime buildLastSyncDt(Long cropPlanId, SyncType syncType, boolean ignorePreviousSyncs) {
		List<String> syncTypes = new ArrayList<>();
		syncTypes.add(syncType.toString());

		if (syncType == SyncType.LPIS_LITE)
			syncTypes.add(SyncType.LPIS.toString());

		return ignorePreviousSyncs ? null : syncDAO.getLastSyncDate(cropPlanId, syncTypes);
	}

	private boolean isRecalcAnomaliesNeeded(RuntimeEnvironment env, String businessId, Long cropPlanId, SyncPlugin syncPlugin, LocalDateTime lastSyncDt,
			boolean ignorePreviousSyncs, LocalDateTime currentDt, AbsoluteDate referenceDt) {

		var campaignStartDateResult = cropPlanConfigService.getCampaignStartDate(cropPlanId, AbsoluteDate.of(currentDt.toLocalDate()));
		LocalDate campaignStartDate = null;
		if (campaignStartDateResult != null) {
			campaignStartDate = campaignStartDateResult.toLocalDate();
		}

		LatestSync latestSync = ignorePreviousSyncs ? null : syncDAO.getLatestSync(cropPlanId);

		return syncPlugin.isRecalcAnomaliesNeeded(env, businessId, cropPlanId, lastSyncDt,
				referenceDt != null ? referenceDt.toLocalDate() : null,
				latestSync, campaignStartDate);
	}

	private void launchSyncCropPlan(RuntimeEnvironment env, SyncQueuePayload payload) {
		var numRecords = syncDAO.setSyncInProgress(payload.getCropPlanId(), payload.getCurrentDt(), payload.getCurrentDt().minusDays(1), payload.getSyncType().toString());
		if (numRecords > 0)
		{
			if (!configuration.isDevMode()) {
				syncQueue.add(payload, System.currentTimeMillis());
			} else {
				syncJobConsumer.doSyncCropPlan(env, payload);
			}
		}
	}

	private SyncStatus getSyncProgressInternal(Long cropPlanId, LocalDateTime currentDt)
	{
		var inProgress = syncDAO.getSyncProgress(cropPlanId, currentDt.minusDays(5));
		if (inProgress != null)
			return new SyncStatus(SyncProgress.IN_PROGRESS, SyncType.valueOf(inProgress), false);
		return new SyncStatus(SyncProgress.COMPLETED, null, syncDAO.hasErrors(cropPlanId));
	}

	private boolean needsSync(SyncType syncType, boolean recalcAnomaliesNeeded, LocalDate oldestChangesDateFromLpisDate)
	{
		switch (syncType)
		{
			case LPIS: 
				return recalcAnomaliesNeeded || oldestChangesDateFromLpisDate != null;
			case LPIS_LITE: 
				return recalcAnomaliesNeeded || oldestChangesDateFromLpisDate != null;
			case WIZARD:
				return true; //lastSyncDt == null;
			case PLOT_ALIGN:
				return true;
			case COPY_CAMPAIGN:
				return true;
			case MASSIVE_FIELDS_UPDATE:
				return false;
			case RECALC_ANOMALIES:
				return recalcAnomaliesNeeded;
			default:
				throw new IllegalStateException("Unsupported " + syncType + " SyncType!");
		}
	}

}
