package com.abacogroup.cropplan.services.utils;

import static java.util.stream.Collectors.toList;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Polygon;

import com.abacogroup.cropplan.api.AlertCode;
import com.abacogroup.cropplan.api.EditPlotResult;
import com.abacogroup.cropplan.api.ModifiedMerged;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.PlotEditDAO;
import com.abacogroup.cropplan.db.dao.SyncDAO;
import com.abacogroup.cropplan.db.dao.ntt.DeclarationData;
import com.abacogroup.cropplan.db.dao.ntt.PlotData;
import com.abacogroup.cropplan.db.dao.ntt.PlotDataParcel;
import com.abacogroup.cropplan.db.dao.ntt.SavePlotDatas;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.config.CropPlanConfigParam;
import com.abacogroup.cropplan.sdk.model.domain.DomainZoneGeometry;
import com.abacogroup.cropplan.sdk.model.sync.LatestSync;
import com.abacogroup.cropplan.sdk.model.validation.ValidationMessage;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedDeclaration;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedPlot;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorData;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorOperation;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.CropPlanDeclarationsService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.DeclarationService;
import com.abacogroup.cropplan.services.PersistEditorResult;
import com.abacogroup.cropplan.services.PersistEditorResult.FutureIntersections;
import com.abacogroup.cropplan.services.PersistEditorResult.ValidIntersection;
import com.abacogroup.cropplan.services.PropagationService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.cropplan.services.support.EditorResultParams;
import com.abacogroup.cropplan.services.support.EditorSupportParams;
import com.abacogroup.cropplan.services.support.ValidatorSupport;
import com.abacogroup.geometryeditor.Editor.CanvasPreprocess;
import com.abacogroup.geometryeditor.EditorResult;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import jakarta.ws.rs.BadRequestException;

public class PlotEditServiceUtils {
	//private static final Logger log = LoggerFactory.getLogger(PlotEditServiceUtils.class);
	
	private final CropPlanService cropPlanService;
	private final CropPlanDeclarationsService cropPlanDeclarationsService;
	private final CropPlanConfigService cropPlanConfigService;
	private final DeclarationService declarationService;
	private final PropagationService propagationService;
	private final ValidatorService validatorService;
	private final PluginManager pluginManager;
	private final PlotEditDAO plotEditDAO;
	private final CropPlanConfigDAO crplConfigDAO;
	private final SyncDAO syncDAO;
	
	public PlotEditServiceUtils(CropPlanService cropPlanService, CropPlanDeclarationsService cropPlanDeclarationsService,
			CropPlanConfigService cropPlanConfigService, DeclarationService declarationService,
			PropagationService propagationService, ValidatorService validatorService,
			PluginManager pluginManager, PlotEditDAO plotEditDAO, CropPlanConfigDAO crplConfigDAO, SyncDAO syncDAO) {
		this.cropPlanService = cropPlanService;
		this.cropPlanDeclarationsService = cropPlanDeclarationsService;
		this.cropPlanConfigService = cropPlanConfigService;
		this.declarationService = declarationService;
		this.propagationService = propagationService;
		this.validatorService = validatorService;
		this.pluginManager = pluginManager; 
		this.plotEditDAO = plotEditDAO;
		this.crplConfigDAO = crplConfigDAO;
		this.syncDAO = syncDAO;
	}
	
	public PersistEditorResult persistEditorResult(RuntimeEnvironment env, EditorSupportParams params,
			String description, String notes, AbsoluteDate pointInTime, AbsoluteDate toPointInTime,
			Function<EditorResultParams, EditorResult<String>> editFunction, ModifiedMerged modifiedMerged,
			Function<EditorResultParams, EditorResult<String>> editFunctionForFutures,
			boolean ignoreValidationWarnings, String defaultLandUseCode, boolean ignoreValidation) {
		return persistEditorResult(env, params, description, notes, pointInTime, toPointInTime, editFunction, modifiedMerged, editFunctionForFutures, ignoreValidationWarnings,
				defaultLandUseCode, null, ignoreValidation);
	}
	
	public PersistEditorResult persistEditorResult(RuntimeEnvironment env, EditorSupportParams params,
			String description, String notes, AbsoluteDate pointInTime, AbsoluteDate toPointInTime,
			Function<EditorResultParams, EditorResult<String>> editFunction, ModifiedMerged modifiedMerged,
			Function<EditorResultParams, EditorResult<String>> editFunctionForFutures,
			boolean ignoreValidationWarnings, String defaultLandUseCode, 
			Map<String, Polygon> createdWithExistingPlotCode, boolean ignoreValidation) {
		
		EditorResultParams editorResultParams = EditorResultParams.builder()
				.pointInTime(pointInTime)
				.parcels(null)
				.build();
		EditorResult<String> result = editFunction.apply(editorResultParams);
		
		var domainPlugin = pluginManager.getDomainPlugin(params.getBusinessId(), params.getCropPlanId(), env.getTenantId());

		var deleteDt = params.getVersionDt().minus(Duration.ofMillis(1));

		var snapFromDate = cropPlanConfigService.getSnapFromDate(params.getCropPlanId(), pointInTime);
		DomainZoneGeometry domainZone = domainPlugin.getDomainZone(env, params.getBusinessId(), snapFromDate.toLocalDate(), params.getDomainZoneId()); // SHOULD BE NULL!!! USED ONLY FOR CREATED
		
		SavePlotDatas savePlotDatas = new SavePlotDatas(new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>());

		Double tolerance = cropPlanConfigService.getEditPropagationTolerance(params.getCropPlanId());
		FutureIntersections futureIntersections = propagationService.buildFutureIntersections(env, params, pointInTime, toPointInTime, result, editFunctionForFutures, tolerance, getCanvasPreprocess(params.getCropPlanId()));
		
		//long startTime = System.currentTimeMillis(); 
		result.getCreated().keySet().forEach(plotCode -> {
			Long plotId = Long.valueOf(plotCode);
			boolean flSoftModified = false;
			if (createdWithExistingPlotCode != null && createdWithExistingPlotCode.get(plotCode) != null) { // check for restoreParcelsDefaultPropagatingBehaviour
				plotId = null;
				flSoftModified = (int) Math.round(createdWithExistingPlotCode.get(plotCode).getArea()) == (int) Math.round(result.getCreated().get(plotCode).getArea());
			}
			
			if (domainZone == null)
				throw new BadRequestException("The specified domainZoneId was not found");
			persistCreated(env, params, description, notes, pointInTime, result, defaultLandUseCode, domainZone.getSrs(), futureIntersections, savePlotDatas, plotId, plotCode, flSoftModified);
		});

		result.getModified().keySet().forEach(plotCode -> persistModified(env, params, pointInTime, result, modifiedMerged, deleteDt, futureIntersections, savePlotDatas, plotCode));

		processTopologyCorrectedAtPointInTime(savePlotDatas, env, params.getBusinessId(), params.getCropPlanId(),
				params.getDomainZoneId(), pointInTime, params.getVersionDt(), deleteDt,
				result.getTopologyCorrected(), futureIntersections.getValidIntersections(),
				futureIntersections.getMaximumDayTo());
		for (ValidIntersection validIntersection : futureIntersections.getValidIntersections()) {
			var nextValidIntersections = futureIntersections.getValidIntersections().stream()
					.filter(v -> v.getPointInTime().isAfter(validIntersection.getPointInTime()))
					.collect(toList());
			processTopologyCorrectedAtPointInTime(savePlotDatas, env, params.getBusinessId(), params.getCropPlanId(),
					params.getDomainZoneId(), validIntersection.getPointInTime(),
					params.getVersionDt(), deleteDt, validIntersection.getTopologyCorrected(), nextValidIntersections,
					futureIntersections.getMaximumDayTo());
		}

		Map<String, Plot> deletedPlots = ignoreValidation ? null : new HashMap<>();
		List<DeclarationData> deletedDecls = ignoreValidation ? null : new ArrayList<>();
		result.getDeleted().forEach(plotCode -> persistDeleted(env, params, pointInTime, deleteDt, savePlotDatas, deletedPlots, deletedDecls, plotCode));
		//long endTime = System.currentTimeMillis();
		//log.info("TIME ELAPSED (" + params.getCropPlanId() + "): persistEditorResult.processResult at " + pointInTime.toString() + ": " + TimeUnit.MILLISECONDS.toSeconds((endTime-startTime)) + "s");								

		EditPlotResult editPlotResult = null;
		if (ignoreValidation) {
			//startTime = System.currentTimeMillis();
			plotEditDAO.savePlotDatas(savePlotDatas, params.getDomainZoneId(), null);

			ValidatorSupport<EditPlotResult> support = getPersistEditorValidatorSupport(env, params, pointInTime, result, futureIntersections, savePlotDatas, deletedPlots, deletedDecls);

			editPlotResult = support.getResult(null, new ArrayList<>());
			//endTime = System.currentTimeMillis();
			//log.info("TIME ELAPSED (" + params.getCropPlanId() + "): persistEditorResult.savePlotDatas at " + pointInTime.toString() + ": " + TimeUnit.MILLISECONDS.toSeconds((endTime-startTime)) + "s");							
		} else {
			plotEditDAO.savePlotDatas(savePlotDatas, params.getDomainZoneId(), params.getVersionDt());

			ValidatorSupport<EditPlotResult> support = getPersistEditorValidatorSupport(env, params, pointInTime, result, futureIntersections, savePlotDatas, deletedPlots, deletedDecls);

			editPlotResult = validatorService.validate(env, support, ignoreValidationWarnings, false, params.getBusinessId(), params.getCropPlanId(),
					params.getVersionDt(), params.getVersionDt());
		}
		
		return new PersistEditorResult(editPlotResult, futureIntersections, result);
	}
	
	private void persistCreated(RuntimeEnvironment env, EditorSupportParams params, String description, String notes, AbsoluteDate pointInTime, EditorResult<String> result,
			String defaultLandUseCode, String srs, FutureIntersections futureIntersections, SavePlotDatas savePlotDatas, Long plotId, String plotCode,
			boolean flSoftModified) {		
		var parentPlotCode = result.getCreatedParent(plotCode);
		if (parentPlotCode != null) { // created from parent
			persistCreatedWithParent(env, params, pointInTime, result, srs, futureIntersections, savePlotDatas, plotId, plotCode, flSoftModified,
					parentPlotCode);
		} else { // created without parent
			persistCreatedWithoutParent(env, params, description, notes, pointInTime, result, defaultLandUseCode, srs, futureIntersections, savePlotDatas, plotId,
					plotCode, flSoftModified);
		}
	}

	private void persistCreatedWithParent(RuntimeEnvironment env, EditorSupportParams params, AbsoluteDate pointInTime, EditorResult<String> result, String srs,
			FutureIntersections futureIntersections, SavePlotDatas savePlotDatas, Long plotId, String plotCode, boolean flSoftModified, String parentPlotCode) {
		PlotData firstIntervalPlotData = null;
		List<String> firstIntervalIntersectedParcelCodes = null;
		
		AbsoluteDate currentPointInTime = pointInTime;
		AbsoluteDate lastPointInTime = !futureIntersections.getValidIntersections().isEmpty() ? 
				futureIntersections.getValidIntersections().get(futureIntersections.getValidIntersections().size()-1).getPointInTime() : 
				currentPointInTime;
		var parentPlot = plotEditDAO.getPlotDatas(params.getCropPlanId(), parentPlotCode, pointInTime, lastPointInTime);
		checkPlotIsDefined(parentPlotCode, parentPlot);

		PlotData firstParentPlot = parentPlot.get(0);
		PlotData lastParentPlot = parentPlot.get(parentPlot.size()-1);
		boolean currentFlSoftModified = flSoftModified;
		Polygon currentGeometry = result.getCreated().get(plotCode);
		for (ValidIntersection vi : futureIntersections.getValidIntersections().stream().filter(ValidIntersection::isValidWithTolerance).collect(toList())) {

			AbsoluteDate maximumIntervalDate = AbsoluteDate.of(vi.getPointInTime().toLocalDate().minusDays(1));

			var dayTo = buildDayTo(lastParentPlot.getDayTo(), maximumIntervalDate);
			if (dayTo.isBefore(currentPointInTime))
				break;

			plotId = buildPlotId(plotId);
			PlotData plotData = new PlotData(true, plotId, plotCode, params.getCropPlanId(),
					firstParentPlot.getDescription(), firstParentPlot.getNotes(), currentPointInTime, dayTo, srs,
					(int) Math.round(currentGeometry.getArea()), currentFlSoftModified, env.getUserId(),
					null, params.getVersionDt(), LocalDateTime.of(9999, 12, 31, 0, 0), currentGeometry);
			plotId = null;
			firstIntervalPlotData = buildFirstIntervalPlotData(firstIntervalPlotData, plotData);
			savePlotDatas.getPlotDatas().add(plotData);
			List<String> intersectedParcelCodes = processPlotParcelData(savePlotDatas, env, params.getBusinessId(), params.getCropPlanId(),
					params.getDomainZoneId(), plotData);
			firstIntervalIntersectedParcelCodes = buildFirstIntervalIntersectedParcelCodes(firstIntervalIntersectedParcelCodes, intersectedParcelCodes);

			currentPointInTime = vi.getPointInTime();
			currentFlSoftModified = isSoftModified(plotCode, vi, plotData);
			currentGeometry = vi.getCreated().get(plotCode);
		}
		
		var dayTo = buildDayTo(lastParentPlot.getDayTo(), futureIntersections.getMaximumDayTo());
		if (dayTo.isAfterOrEqual(currentPointInTime)) {
			plotId = buildPlotId(plotId);
			PlotData plotData = new PlotData(true, plotId, plotCode, params.getCropPlanId(),
					firstParentPlot.getDescription(), firstParentPlot.getNotes(), currentPointInTime, dayTo, srs,
					(int) Math.round(currentGeometry.getArea()), currentFlSoftModified, env.getUserId(),
					null, params.getVersionDt(), LocalDateTime.of(9999, 12, 31, 0, 0), currentGeometry);
			firstIntervalPlotData = buildFirstIntervalPlotData(firstIntervalPlotData, plotData);
			savePlotDatas.getPlotDatas().add(plotData);
			List<String> intersectedParcelCodes = processPlotParcelData(savePlotDatas, env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(), plotData);
			firstIntervalIntersectedParcelCodes = buildFirstIntervalIntersectedParcelCodes(firstIntervalIntersectedParcelCodes, intersectedParcelCodes);
		}
		
		processDeclarationsDatasForNewPlotWithParent(env, params, pointInTime, futureIntersections, savePlotDatas, firstIntervalPlotData,
				firstIntervalIntersectedParcelCodes, firstParentPlot);
	}

	private List<String> buildFirstIntervalIntersectedParcelCodes(List<String> firstIntervalIntersectedParcelCodes, List<String> intersectedParcelCodes) {
		if (firstIntervalIntersectedParcelCodes == null)
			firstIntervalIntersectedParcelCodes = intersectedParcelCodes;
		return firstIntervalIntersectedParcelCodes;
	}

	private PlotData buildFirstIntervalPlotData(PlotData firstIntervalPlotData, PlotData plotData) {
		if (firstIntervalPlotData == null)
			firstIntervalPlotData = plotData;
		return firstIntervalPlotData;
	}

	private boolean isSoftModified(String plotCode, ValidIntersection vi, PlotData plotData) {
		return plotData.getAreaSqm() == (int) Math.round(vi.getCreated().get(plotCode).getArea());
	}

	private void checkPlotIsDefined(String parentPlotCode, List<PlotData> parentPlot) {
		if (parentPlot.isEmpty())
			throw new BadRequestException("The plot " + parentPlotCode + " was not found");
	}

	private Long buildPlotId(Long plotId) {
		if (plotId == null)
			plotId = plotEditDAO.getCropPlotDataSeq();
		return plotId;
	}

	private void processDeclarationsDatasForNewPlotWithParent(RuntimeEnvironment env, EditorSupportParams params, AbsoluteDate pointInTime,
			FutureIntersections futureIntersections, SavePlotDatas savePlotDatas, PlotData firstIntervalPlotData,
			List<String> firstIntervalIntersectedParcelCodes, PlotData firstParentPlot) {
		Long firstIntervalPlotId = firstIntervalPlotData != null ? firstIntervalPlotData.getPlotId() : null;
		if (firstIntervalIntersectedParcelCodes != null && firstIntervalPlotData != null && !firstIntervalIntersectedParcelCodes.isEmpty()) {
			var parcelIntersections = savePlotDatas.getPlotDataParcels().stream()
					.filter(pdp -> pdp.getPlotId().equals(firstIntervalPlotId))
					.collect(toList());
			var landCoverCodes = parcelIntersections.stream()
					.map(PlotDataParcel::getLandCoverCode)
					.distinct()
					.collect(toList());

			if (landCoverCodes.size() == 1)
				declarationService.processDeclarationDatasForNewPlotWithParent(savePlotDatas, env, firstIntervalPlotData, firstParentPlot, params.getBusinessId(),
						params.getCropPlanId(), pointInTime, futureIntersections.getMaximumDayTo(), params.getVersionDt(), landCoverCodes.get(0));
		} else if (firstIntervalPlotData != null) {
			declarationService.processDeclarationDatasForNewPlotWithParent(savePlotDatas, env, firstIntervalPlotData, firstParentPlot, params.getBusinessId(),
					params.getCropPlanId(), pointInTime, futureIntersections.getMaximumDayTo(), params.getVersionDt(), null);
		}
	}

	private void persistCreatedWithoutParent(RuntimeEnvironment env, EditorSupportParams params, String description, String notes, AbsoluteDate pointInTime,
			EditorResult<String> result, String defaultLandUseCode, String srs, FutureIntersections futureIntersections, SavePlotDatas savePlotDatas,
			Long plotId, String plotCode, boolean flSoftModified) {
		AbsoluteDate currentPointInTime = pointInTime;
		boolean currentFlSoftModified = flSoftModified;
		Polygon currentGeometry = result.getCreated().get(plotCode);
		for (ValidIntersection vi : futureIntersections.getValidIntersections()) {
			if (vi.isValidWithTolerance()) {
				AbsoluteDate maximumIntervalDate = AbsoluteDate.of(vi.getPointInTime().toLocalDate().minusDays(1));
				
				plotId = buildPlotId(plotId);
				PlotData plotData = new PlotData(true, plotId, plotCode, params.getCropPlanId(), description, notes,
						currentPointInTime, maximumIntervalDate, srs,
						(int) Math.round(currentGeometry.getArea()), currentFlSoftModified,	env.getUserId(),
						null, params.getVersionDt(), LocalDateTime.of(9999, 12, 31, 0, 0), currentGeometry);
				plotId = null;
				savePlotDatas.getPlotDatas().add(plotData);
				processPlotParcelData(savePlotDatas, env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(), plotData);
				
				currentPointInTime = vi.getPointInTime();
				currentFlSoftModified = isSoftModified(plotCode, vi, plotData);
				currentGeometry = vi.getCreated().get(plotCode);
			}
		}
		
		plotId = buildPlotId(plotId);
		PlotData plotData = new PlotData(true, plotId, plotCode, params.getCropPlanId(), description, notes,
				currentPointInTime, futureIntersections.getMaximumDayTo(), srs,
				(int) Math.round(currentGeometry.getArea()), currentFlSoftModified,	env.getUserId(),
				null, params.getVersionDt(), LocalDateTime.of(9999, 12, 31, 0, 0), currentGeometry);
		savePlotDatas.getPlotDatas().add(plotData);
		processPlotParcelData(savePlotDatas, env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(), plotData);
		
		if (defaultLandUseCode != null) {
			declarationService.processDefaultDeclarationDatasForNewPlot(savePlotDatas, env, plotCode, defaultLandUseCode, params.getCropPlanId(),
					pointInTime, futureIntersections.getMaximumDayTo(), params.getVersionDt());
		}
	}

	private void persistModified(RuntimeEnvironment env, EditorSupportParams params, AbsoluteDate pointInTime, EditorResult<String> result,
			ModifiedMerged modifiedMerged, LocalDateTime deleteDt, FutureIntersections futureIntersections, SavePlotDatas savePlotDatas,
			String plotCode) {
		processModifiedPlotDatas(savePlotDatas, env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(), plotCode,
				pointInTime, futureIntersections, params.getVersionDt(), deleteDt, result.getModified().get(plotCode), false, env.getUserId(), false, false);
		if (modifiedMerged != null) {
			var mergedPlots = modifiedMerged.getMergedPlots().get(plotCode);
			if (mergedPlots != null) {
				declarationService.processDeclarationDatasForMergedPlot(savePlotDatas, env, plotCode,
						mergedPlots, modifiedMerged.isPreserveDeclarations(), params.getCropPlanId(), pointInTime,
						futureIntersections.getMaximumDayTo(), params.getVersionDt(), deleteDt);
			}
		} else {
			var oldPlotData = plotEditDAO.getPlotDatas(params.getCropPlanId(), plotCode, pointInTime, pointInTime);
			checkPlotIsDefined(plotCode, oldPlotData);

			declarationService.processDeclarationDatasForModifiedPlot(savePlotDatas, env, (int) Math.round(result.getModified().get(plotCode).getArea()),
					oldPlotData.get(0).getAreaSqm(), plotCode, params.getCropPlanId(),
					pointInTime, futureIntersections.getMaximumDayTo(), params.getVersionDt(), deleteDt);
		}
	}
	
	private void persistDeleted(RuntimeEnvironment env, EditorSupportParams params, AbsoluteDate pointInTime, LocalDateTime deleteDt,
			SavePlotDatas savePlotDatas, Map<String, Plot> deletedPlots, List<DeclarationData> deletedDecls, String plotCode) {
		FutureIntersections futureIntersections = new FutureIntersections(AbsoluteDate.of("99991231"), new ArrayList<>());
		processModifiedPlotDatas(savePlotDatas, env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(), plotCode, pointInTime,
				futureIntersections, params.getVersionDt(), deleteDt, null, false, env.getUserId(), true, true);

		if (deletedPlots != null) {
			deletedPlots.put(plotCode,
					cropPlanService.getPlot(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(), params.getVersionDt(),
							pointInTime, pointInTime, plotCode));
		}
		if (deletedDecls != null) {
			deletedDecls.addAll(declarationService.processDeclarationDatasForDeletedPlot(savePlotDatas, env, plotCode, params.getCropPlanId(), pointInTime,
					AbsoluteDate.of("99991231"), params.getVersionDt(), deleteDt));
		}
	}
	
	private void processTopologyCorrectedAtPointInTime(SavePlotDatas savePlotDatas, RuntimeEnvironment env,
			String businessId, Long cropPlanId, String domainZoneId,
			AbsoluteDate pointInTime, LocalDateTime insertDt, LocalDateTime deleteDt,
			Map<String, Polygon> topologyCorrected, List<ValidIntersection> nextValidIntersections,
			AbsoluteDate maximumDayTo) {
		// for each topologyCorrected check if it exists in
		// nextValidIntersections
		// if it exists and it is equal to the current then remove the next from
		// the map
		// else insert topologyCorrected with maximumDayTo =
		// nextValidIntersections pointInTime minus 1 day
		// at the end, if current topologyCorrected was not found then insert
		// with maximumDayTo
		topologyCorrected.keySet().forEach(plotCode -> {
			boolean found = false;
			for (ValidIntersection nextValidIntersection : nextValidIntersections) {
				var tc = nextValidIntersection.getTopologyCorrected().get(plotCode);
				if (tc != null) {
					if (tc.equalsNorm(topologyCorrected.get(plotCode))) {
						nextValidIntersection.getTopologyCorrected().remove(plotCode);
					} else {
						var dayTo = AbsoluteDate.of(nextValidIntersection.getPointInTime().toLocalDate().minusDays(1));
						FutureIntersections futureIntersections = new FutureIntersections(dayTo, new ArrayList<>());
						processModifiedPlotDatas(savePlotDatas, env, businessId, cropPlanId, domainZoneId, plotCode,
								pointInTime, futureIntersections, insertDt, deleteDt,
								topologyCorrected.get(plotCode), true, env.getUserId(), false, true);
						found = true;
						break;
					}
				}
			}
			if (!found) {
				FutureIntersections futureIntersections = new FutureIntersections(maximumDayTo, new ArrayList<>());
				processModifiedPlotDatas(savePlotDatas, env, businessId, cropPlanId, domainZoneId, plotCode, pointInTime,
						futureIntersections, insertDt, deleteDt,
						topologyCorrected.get(plotCode), true, env.getUserId(), false, true);
			}
		});
	}

	private void processModifiedPlotDatas(SavePlotDatas savePlotDatas, RuntimeEnvironment env, String businessId,
			Long cropPlanId, String domainZoneId, String plotCode, AbsoluteDate fromPointInTime,
			FutureIntersections futureIntersections, LocalDateTime insertDt, LocalDateTime deleteDt, Polygon geom,
			boolean flSoftModified, String userId, boolean isDeleted, boolean doNotRecalcPlotDataParcels) {

		var currentPlots = plotEditDAO.getPlotDatas(cropPlanId, plotCode, fromPointInTime, futureIntersections.getMaximumDayTo());
		checkPlotIsDefined(plotCode, currentPlots);

		AbsoluteDate maxCalcDayTo = null;
		Boolean hardModifiedSoppressed = null;
		for (PlotData currentPlot : currentPlots) {
			var plotToBeUpdated = currentPlot.toBuilder().build();
			plotToBeUpdated.setNew(false);
			plotToBeUpdated.setDeleteDt(deleteDt);
			plotToBeUpdated.setDeleteUserId(userId);
			savePlotDatas.getPlotDatas().add(plotToBeUpdated);

			// reinserisco il primo segmento, che ha data inizio precedente alla data della modifica (fromPointInTime)
			reinsertFirstSegment(savePlotDatas, fromPointInTime, insertDt, userId, currentPlot);

			// calcolo la data fine del segmento modificato da inserire
			AbsoluteDate dayTo = buildDayTo(currentPlot.getDayTo(), futureIntersections.getMaximumDayTo());
			if (maxCalcDayTo == null || dayTo.isAfter(maxCalcDayTo))
				maxCalcDayTo = dayTo;

			if (hardModifiedSoppressed == null)
				hardModifiedSoppressed = false;
			else if (!currentPlot.isFlSoftModified())
				hardModifiedSoppressed = true;

			// resinserisco (se non è una cancellazione) l'ultimo segmento, che ha data fine successiva alla data fine modifica (maximumDayTo)
			reinsertLastSegment(savePlotDatas, futureIntersections.getMaximumDayTo(), insertDt, flSoftModified, userId, isDeleted, hardModifiedSoppressed, currentPlot);
		}

		// inserisco ii segmenti modificati
		if (!isDeleted) {
			inserModifiedSegments(savePlotDatas, env, businessId, cropPlanId, domainZoneId, plotCode, fromPointInTime, futureIntersections, insertDt, geom,
					flSoftModified, userId, doNotRecalcPlotDataParcels, currentPlots, maxCalcDayTo);
			
		}
	}

	private void inserModifiedSegments(SavePlotDatas savePlotDatas, RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId,
			String plotCode, AbsoluteDate fromPointInTime, FutureIntersections futureIntersections, LocalDateTime insertDt, Polygon geom,
			boolean flSoftModified, String userId, boolean doNotRecalcPlotDataParcels, List<PlotData> currentPlots, AbsoluteDate maxCalcDayTo) {
		AbsoluteDate currentPointInTime = fromPointInTime;
		boolean currentFlSoftModified = flSoftModified;
		Polygon currentGeometry = geom;
		for (ValidIntersection vi : futureIntersections.getValidIntersections()) {
			if (vi.isValidWithTolerance()) {
				AbsoluteDate maximumIntervalDate = AbsoluteDate.of(vi.getPointInTime().toLocalDate().minusDays(1));
				
				var dayTo = buildDayTo(maxCalcDayTo, maximumIntervalDate);
				if (dayTo.isBefore(currentPointInTime))
					break;

				PlotData plotData = insertModifiedSegment(savePlotDatas, env, businessId, cropPlanId, domainZoneId, currentPointInTime, insertDt, currentGeometry, 
						currentFlSoftModified, userId, doNotRecalcPlotDataParcels, currentPlots.get(0), dayTo);
				
				currentPointInTime = vi.getPointInTime();
				currentFlSoftModified = plotData.getAreaSqm() == (int) Math.round(vi.getModified().get(plotCode).getArea());
				currentGeometry = vi.getModified().get(plotCode);
			}
		}
		
		var dayTo = buildDayTo(maxCalcDayTo, futureIntersections.getMaximumDayTo());
		if (dayTo.isAfterOrEqual(currentPointInTime)) {
			insertModifiedSegment(savePlotDatas, env, businessId, cropPlanId, domainZoneId, currentPointInTime, insertDt, currentGeometry, 
					currentFlSoftModified, userId, doNotRecalcPlotDataParcels, currentPlots.get(0), dayTo);
		}
	}

	private AbsoluteDate buildDayTo(AbsoluteDate maxCalcDayTo, AbsoluteDate maximumDateTo) {
		return maxCalcDayTo.isAfter(maximumDateTo)
				? maximumDateTo
				: maxCalcDayTo;
	}
	
	private PlotData insertModifiedSegment(SavePlotDatas savePlotDatas, RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId,
			AbsoluteDate fromPointInTime, LocalDateTime insertDt, Geometry geom, boolean flSoftModified, String userId, 
			boolean doNotRecalcPlotDataParcels, PlotData currentPlot, AbsoluteDate maxCalcDayTo) {
		var plotToBeUpdated = currentPlot.toBuilder().build();
		plotToBeUpdated.setNew(true);
		plotToBeUpdated.setPlotId(plotEditDAO.getCropPlotDataSeq());
		plotToBeUpdated.setDayFrom(fromPointInTime);
		plotToBeUpdated.setDayTo(maxCalcDayTo);
		if (currentPlot.getDayFrom().isBefore(AbsoluteDate.of(fromPointInTime.toLocalDate().minusDays(1))))
			plotToBeUpdated.setFlSoftModified(flSoftModified);
		else if (!flSoftModified)
			plotToBeUpdated.setFlSoftModified(false);
		plotToBeUpdated.setInsertUserId(userId);
		plotToBeUpdated.setInsertDt(insertDt);
		if (geom != null) {
			plotToBeUpdated.setAreaSqm((int) Math.round(geom.getArea()));
			plotToBeUpdated.setGeom(geom);
		}
		savePlotDatas.getPlotDatas().add(plotToBeUpdated);
		if (doNotRecalcPlotDataParcels) {
			// se non devo ricalcolare le particelle preservo le precedenti
			var plotId = plotToBeUpdated.getPlotId();
			var plotDataParcels = plotEditDAO.getPlotDataParcels(currentPlot.getPlotId());
			plotDataParcels.forEach(pdp -> savePlotDatas.getPlotDataParcels().add(new PlotDataParcel(null, plotId, pdp.getParcelCode(),
					pdp.getAreaSqm(), pdp.getLandCoverCode(), pdp.isFlOutside(), pdp.getGeom())));
		}				
		else {
			processPlotParcelData(savePlotDatas, env, businessId, cropPlanId, domainZoneId, plotToBeUpdated);
		}
		return plotToBeUpdated;
	}

	private void reinsertLastSegment(SavePlotDatas savePlotDatas, AbsoluteDate maximumDayTo, LocalDateTime insertDt, boolean flSoftModified, String userId,
			boolean isDeleted, Boolean hardModifiedSoppressed, PlotData currentPlot) {
		if (maximumDayTo.isBefore(AbsoluteDate.of("99991231"))) {
			var dayFrom = AbsoluteDate.of(maximumDayTo.toLocalDate().plusDays(1));
			if (!isDeleted && currentPlot.getDayTo().isAfterOrEqual(dayFrom)) {
				PlotData plotToBeUpdated = currentPlot.toBuilder().build();
				plotToBeUpdated.setNew(true);
				plotToBeUpdated.setPlotId(plotEditDAO.getCropPlotDataSeq());
				plotToBeUpdated.setDayFrom(dayFrom);
				plotToBeUpdated.setFlSoftModified(flSoftModified && !hardModifiedSoppressed);
				plotToBeUpdated.setInsertUserId(userId);
				plotToBeUpdated.setInsertDt(insertDt);
				savePlotDatas.getPlotDatas().add(plotToBeUpdated);

				// quando reinserisco non ricalcolo le particelle, preservo le precedenti
				// processPlotParcelData(savePlotDatas, env, businessId, domainZoneId, plotToBeUpdated);
				var plotId = plotToBeUpdated.getPlotId();
				var plotDataParcels = plotEditDAO.getPlotDataParcels(currentPlot.getPlotId());
				plotDataParcels.forEach(pdp -> savePlotDatas.getPlotDataParcels().add(new PlotDataParcel(null, plotId, pdp.getParcelCode(),
						pdp.getAreaSqm(), pdp.getLandCoverCode(), pdp.isFlOutside(), pdp.getGeom())));
			}
		}
	}

	private void reinsertFirstSegment(SavePlotDatas savePlotDatas, AbsoluteDate fromPointInTime, LocalDateTime insertDt, String userId, PlotData currentPlot) {
		AbsoluteDate dayTo = AbsoluteDate.of(fromPointInTime.toLocalDate().minusDays(1));
		if (currentPlot.getDayFrom().isBeforeOrEqual(dayTo)) {
			PlotData plotToBeUpdated = currentPlot.toBuilder().build();
			plotToBeUpdated.setNew(true);
			plotToBeUpdated.setPlotId(plotEditDAO.getCropPlotDataSeq());
			plotToBeUpdated.setDayTo(dayTo);
			plotToBeUpdated.setInsertUserId(userId);
			plotToBeUpdated.setInsertDt(insertDt);
			savePlotDatas.getPlotDatas().add(plotToBeUpdated);

			// quando reinserisco non ricalcolo le particelle, preservo le precedenti
			// processPlotParcelData(savePlotDatas, env, businessId, domainZoneId, plotToBeUpdated);
			var plotId = plotToBeUpdated.getPlotId();
			var plotDataParcels = plotEditDAO.getPlotDataParcels(currentPlot.getPlotId());
			plotDataParcels.forEach(pdp -> savePlotDatas.getPlotDataParcels().add(new PlotDataParcel(null, plotId, pdp.getParcelCode(),
					pdp.getAreaSqm(), pdp.getLandCoverCode(), pdp.isFlOutside(), pdp.getGeom())));
		}
	}
	
	private List<String> processPlotParcelData(SavePlotDatas savePlotDatas, RuntimeEnvironment env, String businessId,
			Long cropPlanId, String domainZoneId, PlotData plotData) {
		return propagationService.processPlotParcelData(savePlotDatas, env, businessId, cropPlanId, domainZoneId, plotData.getDayFrom(),
				plotData.getGeom(), plotData.getPlotId(), getCanvasPreprocess(cropPlanId));
	}	
	
	private ValidatorSupport<EditPlotResult> getPersistEditorValidatorSupport(RuntimeEnvironment env, EditorSupportParams params, AbsoluteDate pointInTime,
			EditorResult<String> result, FutureIntersections futureIntersections, SavePlotDatas savePlotDatas, Map<String, Plot> deletedPlots,
			List<DeclarationData> deletedDecls) {
		return new ValidatorSupport<>() {
			@Override
			public EditPlotResult getResult(List<ValidationMessage> msgs, List<String> updatedAnomaliesPlotCodes) {
				if (msgs != null && !msgs.isEmpty())
					return new EditPlotResult(msgs);
				else {
					List<AlertCode> alertCodes = new ArrayList<>();
					if (!savePlotDatas.getPermanentCropFormSaveDatas().isEmpty())
						alertCodes.add(AlertCode.PERMANENT_CROP_FORMS_HAVE_CHANGED);
					return getEditPlotResult(env, params, result, alertCodes, updatedAnomaliesPlotCodes);
				}
			}

			@Override
			public ValidatorData getValidatorData() {
				return getPersistEditorValidatorData(env, params, pointInTime, result, futureIntersections, deletedPlots, deletedDecls);
			}	
		};
	}
	
	private ValidatorData getPersistEditorValidatorData(RuntimeEnvironment env, EditorSupportParams params, AbsoluteDate pointInTime,
			EditorResult<String> result, FutureIntersections futureIntersections, Map<String, Plot> deletedPlots, List<DeclarationData> deletedDecls) {
		var data = new ValidatorData();
		data.setBusinessId(params.getBusinessId());
		data.setCropPlanId(params.getCropPlanId());
		LatestSync latestSync = syncDAO.getLatestSync(params.getCropPlanId());
		AbsoluteDate referenceDt = latestSync != null ? latestSync.getReferenceDate() : null;
		data.setReferenceDt(referenceDt != null ? referenceDt.toLocalDate() : null);

		var bps = new ArrayList<ValidatorBoundedPlot>();
		var bds = new ArrayList<ValidatorBoundedDeclaration>();

		result.getCreated().keySet().forEach(plotCode -> evaluateCreatedForPersistEditorValidatorData(env, params, pointInTime, result, futureIntersections, bps, bds, plotCode));

		result.getModified().keySet().forEach(plotCode -> evaluateModifiedForPersistEditorValidatorData(env, params, pointInTime, futureIntersections, bps, bds, plotCode));

		result.getDeleted().forEach(plotCode -> evaluateDeletedForPersistEditorValidatorData(pointInTime, deletedPlots, deletedDecls, bps, bds, plotCode));

		data.setPlots(bps);
		data.setDeclarations(bds);
		return data;
	}

	public void evaluateCreatedForPersistEditorValidatorData(RuntimeEnvironment env, EditorSupportParams params, AbsoluteDate pointInTime,
			EditorResult<String> result, FutureIntersections futureIntersections, ArrayList<ValidatorBoundedPlot> bps,
			ArrayList<ValidatorBoundedDeclaration> bds, String plotCode) {
		var plot = cropPlanService.getPlot(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(), params.getVersionDt(),
				pointInTime, pointInTime, plotCode);

		var plotPointInTimeFrom = plot.getFromDate().isBefore(pointInTime) ? pointInTime : plot.getFromDate();
		var plotPointInTimeTo = plot.getToDate().isAfter(futureIntersections.getMaximumDayTo()) ? futureIntersections.getMaximumDayTo()
				: plot.getToDate();
		var parcelCodes = plot.getParcelIntersections().stream().map(ParcelIntersection::getCode).collect(toList());
		bps.add(new ValidatorBoundedPlot(plotCode, parcelCodes, plotPointInTimeFrom.toLocalDate(), plotPointInTimeTo.toLocalDate(), ValidatorOperation.INSERT));

		var parentPlotCode = result.getCreatedParent(plotCode);
		if (parentPlotCode != null) {
			var decls = cropPlanDeclarationsService.getPlotDeclarations(env, params.getBusinessId(), params.getCropPlanId(), plotCode, null,
					params.getVersionDt(), pointInTime, futureIntersections.getMaximumDayTo());
			decls.forEach(decl -> {
				var declPointInTimeFrom = decl.getFromDate().isBefore(pointInTime) ? pointInTime : decl.getFromDate();
				var declPointInTimeTo = decl.getToDate().isAfter(futureIntersections.getMaximumDayTo())
						? futureIntersections.getMaximumDayTo()
						: decl.getToDate();
				bds.add(new ValidatorBoundedDeclaration(plotCode, parcelCodes, decl.getDeclId(), decl.getDeclCode(),
						decl.getLanduse().getCode(), decl.getAreaPerc(),
						declPointInTimeFrom.toLocalDate(), declPointInTimeTo.toLocalDate(), decl.getFromDatePrecision(), ValidatorOperation.INSERT));
			});
		}
	}

	private void evaluateModifiedForPersistEditorValidatorData(RuntimeEnvironment env, EditorSupportParams params, AbsoluteDate pointInTime,
			FutureIntersections futureIntersections, ArrayList<ValidatorBoundedPlot> bps, ArrayList<ValidatorBoundedDeclaration> bds, String plotCode) {
		var plot = cropPlanService.getPlot(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(), params.getVersionDt(),
				pointInTime, pointInTime, plotCode);

		var plotPointInTimeFrom = plot.getFromDate().isBefore(pointInTime) ? pointInTime : plot.getFromDate();
		var plotPointInTimeTo = plot.getToDate().isAfter(futureIntersections.getMaximumDayTo()) ? futureIntersections.getMaximumDayTo()
				: plot.getToDate();
		var parcelCodes = plot.getParcelIntersections().stream().map(ParcelIntersection::getCode).collect(toList());
		bps.add(new ValidatorBoundedPlot(plotCode, parcelCodes, plotPointInTimeFrom.toLocalDate(), plotPointInTimeTo.toLocalDate(), ValidatorOperation.UPDATE));

		var decls = cropPlanDeclarationsService.getPlotDeclarations(env, params.getBusinessId(), params.getCropPlanId(), plotCode, null,
				params.getVersionDt(), pointInTime, futureIntersections.getMaximumDayTo());
		decls.forEach(decl -> {
			var declPointInTimeFrom = decl.getFromDate().isBefore(pointInTime) ? pointInTime : decl.getFromDate();
			var declPointInTimeTo = decl.getToDate().isAfter(futureIntersections.getMaximumDayTo())
					? futureIntersections.getMaximumDayTo()
					: decl.getToDate();
			bds.add(new ValidatorBoundedDeclaration(plotCode, parcelCodes, decl.getDeclId(), decl.getDeclCode(), decl.getLanduse().getCode(),
					decl.getAreaPerc(),
					declPointInTimeFrom.toLocalDate(), declPointInTimeTo.toLocalDate(), decl.getFromDatePrecision(), ValidatorOperation.UPDATE));
		});
	}

	private void evaluateDeletedForPersistEditorValidatorData(AbsoluteDate pointInTime, Map<String, Plot> deletedPlots, List<DeclarationData> deletedDecls,
			ArrayList<ValidatorBoundedPlot> bps, ArrayList<ValidatorBoundedDeclaration> bds, String plotCode) {
		var plot = deletedPlots.get(plotCode);
		var plotPointInTimeFrom = plot.getFromDate().isBefore(pointInTime) ? pointInTime : plot.getFromDate();
		var parcelCodes = plot.getParcelIntersections().stream().map(ParcelIntersection::getCode).collect(toList());
		bps.add(new ValidatorBoundedPlot(plotCode, parcelCodes, plotPointInTimeFrom.toLocalDate(), plot.getToDate().toLocalDate(), ValidatorOperation.DELETE));

		deletedDecls.forEach(decl -> {
			var pointInTimeFrom = decl.getDayFrom().isBefore(pointInTime) ? pointInTime : decl.getDayFrom();
			bds.add(new ValidatorBoundedDeclaration(plotCode, parcelCodes, decl.getDeclId(), decl.getDeclCode(), decl.getLandUseCode(),
					decl.getAreaPerc(),
					pointInTimeFrom.toLocalDate(), decl.getDayTo().toLocalDate(), decl.getDayFromPrecision(), ValidatorOperation.DELETE));
		});
	}
	
	public CanvasPreprocess getCanvasPreprocess(Long cropPlanId) {
		var canvasPreprocess = CanvasPreprocess.NONE;
		var canvasPreprocessParams = crplConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.CANVAS_PREPROCESS_BEHAVIOUR.toString(), null);
		if (!canvasPreprocessParams.isEmpty())
			canvasPreprocess = CanvasPreprocess.valueOf(canvasPreprocessParams.get(0).getParamValue());
		return canvasPreprocess;
	}
	
	public EditPlotResult getEditPlotResult(RuntimeEnvironment env, EditorSupportParams params, 
			EditorResult<String> editorResult, List<AlertCode> alertCodes, List<String> updatedAnomaliesPlotCodes) {
		
		EditPlotResult ret = new EditPlotResult();
		ret.setAdded(new ArrayList<>());
		editorResult.getCreated().keySet().forEach(k -> {
			var p = cropPlanService.getPlot(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(),
					params.getVersionDt(), params.getPointInTime(), params.getPointInTime(), k);
			if (p != null)
				ret.getAdded().add(p);
		});

		ret.setUpdated(new ArrayList<>());
		editorResult.getModified().keySet().forEach(k -> {
			var p = cropPlanService.getPlot(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(),
					params.getVersionDt(), params.getPointInTime(), params.getPointInTime(), k);
			if (p != null)
				ret.getUpdated().add(p);
		});

		editorResult.getTopologyCorrected().keySet().forEach(k -> {
			var p = cropPlanService.getPlot(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(),
					params.getVersionDt(), params.getPointInTime(), params.getPointInTime(), k);
			if (p != null)
				ret.getUpdated().add(p);
		});

		ret.setDeleted(List.copyOf(editorResult.getDeleted()));
		
		ret.setCoveredByInserted(List.copyOf(editorResult.getCoveredByInserted()));

		ret.setAlertCodes(alertCodes);
		
		List<String> allPlotCodes = new ArrayList<>();
		allPlotCodes.addAll(ret.getAdded().stream().map(Plot::getPlotCode).collect(toList()));
		allPlotCodes.addAll(ret.getUpdated().stream().map(Plot::getPlotCode).collect(toList()));
		allPlotCodes.addAll(new ArrayList<>(ret.getDeleted()));
		
		updatedAnomaliesPlotCodes.removeAll(allPlotCodes);
		
		updatedAnomaliesPlotCodes.forEach(k -> {
			var p = cropPlanService.getPlot(env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(),
					params.getVersionDt(), params.getPointInTime(), params.getPointInTime(), k);
			if (p != null)
				ret.getUpdated().add(p);
		});
		
		return ret;
	}
	
	public boolean isNotPreserveDeclsOnPlotsMerge(Long cropPlanId) {
		return !crplConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.ENABLE_DEFAULT_NOT_PRESERVE_DECLS_ON_PLOTS_MERGE.toString(), "TRUE").isEmpty();
	}
}
