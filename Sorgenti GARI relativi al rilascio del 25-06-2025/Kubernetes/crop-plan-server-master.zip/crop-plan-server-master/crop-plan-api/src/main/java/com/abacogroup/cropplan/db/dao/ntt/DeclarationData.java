package com.abacogroup.cropplan.db.dao.ntt;

import java.time.LocalDateTime;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder=true)
public class DeclarationData
{
	private boolean isNew;
	private Long declId;
	private String declCode;
	private Long cropPlanId;
	private String plotCode;
	private AbsoluteDate dayFrom;
	private String dayFromPrecision;
	private AbsoluteDate dayTo;
	private String landUseCode;
	private Double areaPerc;
	private String insertUserId;
	private String deleteUserId;
	private LocalDateTime insertDt;
	private LocalDateTime deleteDt;
}
