package com.abacogroup.cropplan.api;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class DeclaredArea
{
	private Integer totalPlotsAreaSqm;
	private Double areaPerc;
	private Integer domainPlotsAreaSqm;
	private Double domainAreaPerc;

	public Integer getTotalPlotsAreaSqm()
	{
		if (totalPlotsAreaSqm == null)
			return 0;
		return totalPlotsAreaSqm;
	}

	public Double getAreaPerc()
	{
		if (areaPerc == null)
			return 0d;
		return areaPerc;
	}
	
	public Integer getDomainPlotsAreaSqm()
	{
		if (domainPlotsAreaSqm == null)
			return 0;
		return domainPlotsAreaSqm;
	}

	public Double getDomainAreaPerc()
	{
		if (domainAreaPerc == null)
			return 0d;
		return domainAreaPerc;
	}
}
