package com.abacogroup.cropplan.db.dao.ntt;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Config for Disable Function by Anomalies")
public class FunctionDisableConfig
{
	private String scenario;
	
	private String functionCode;
	
	private String anomaliyCode;
	
	private Boolean anomaliyPresent;
}
