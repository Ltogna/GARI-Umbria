package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class LockException extends WebApplicationException {
	private static final long serialVersionUID = 4520853843492940569L;

	public enum ErrorType {
		LOCK_EXCEPTION,
		SYNC_IN_PROGRESS_EXCEPTION
	}

	public static class LockExceptionErrorBody {
		private final String errorCode;

		public LockExceptionErrorBody(ErrorType errorType) {
			this.errorCode = errorType.name();
		}

		@Schema(allowableValues = "LOCK_EXCEPTION, SYNC_IN_PROGRESS_EXCEPTION")
		public String getErrorCode() {
			return this.errorCode;
		}
	}

	public LockException() {
		this(ErrorType.LOCK_EXCEPTION);
	}

	public LockException(ErrorType errorType) {
		super(getErrorMessage(errorType),
				Response.status(Status.CONFLICT)
						.entity(new LockExceptionErrorBody(errorType))
						.build());
	}

	private static String getErrorMessage(ErrorType errorType) {
		switch (errorType) {
		case SYNC_IN_PROGRESS_EXCEPTION:
			return "Synchronization is currently in progress. Please try again later.";
		case LOCK_EXCEPTION:
		default:
			return "You do not hold this crop plan lock";
		}
	}
}
