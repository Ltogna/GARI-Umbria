package com.abacogroup.cropplan.api;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.cropcodes.Style;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomaly;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.locationtech.jts.geom.Geometry;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "A polygon representing an area with it's crops")
public class Plot
{
	@Schema(description = "The plot identifier, this changes in history")
	@NotNull
	private Long plotId;

	@Schema(description = "The plot 'stable' code, this does not change in history")
	@NotEmpty
	private String plotCode;
	
	@Schema(description = "The plot domain zone identifier")
	@NotNull
	private String domainZoneId;

	@Schema(description = "The description")
	private String description;
	
	@Schema(description = "The notes")
	private String notes;

	@Schema(description = "The parcels assigned to this plot")
	@NotNull
	private List<ParcelIntersection> parcelIntersections;

	@Schema(description = "The area, in square meters")
	@NotNull
	private Integer areaSqm;

	@Schema(description = "The geometry", type = "string", format = "WKT geometry")
	@NotNull
	private Geometry geom;
	
	@Schema(description = "The spatial reference system", format = "AUTHORITY:ID", example = "EPSG:3857")
	@NotNull
	private String srs;

	@Schema(description = "The MBR overview", type = "string", format = "WKT geometry")
	private Geometry mbrOverview;

	@Schema(description = "The declarations")
	@NotNull
	private List<Declaration> decls;

	@Schema(description = "The graphical style of this plot")
	private Style style;

	@Schema(description = "From date")
	@NotNull
	private AbsoluteDate fromDate;

	@Schema(description = "To date")
	@NotNull
	private AbsoluteDate toDate;
	
	@Schema(description = "Full range from date")
	@NotNull
	private AbsoluteDate fullRangeFromDate;

	@Schema(description = "Full range to date")
	@NotNull
	private AbsoluteDate fullRangeToDate;

	private PlotEditability editability;

	@Schema(description = "The plot anomalies")
	private List<ValidationAnomaly> anomalies;
}
