package com.abacogroup.cropplan.db.dao.ntt;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ParcelDeclarationsData
{
	private String parcelCode;

	private LocalDate fromDate;

	private LocalDate toDate;

	private Integer areaSqm;

	private String plotCode;
}
