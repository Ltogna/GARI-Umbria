package com.abacogroup.cropplan.api;

import lombok.Data;

import java.util.List;

@Data
public class PlotDeclRotationDto {
	private String domainZoneId;
	private String domainZoneDescription;
	private String plotCode;
	private List<DeclRotationDto> decls;
}

