package com.abacogroup.cropplan.db.dao.ntt;

import java.util.List;

import org.locationtech.jts.geom.Geometry;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.Data;

@Data
public class SyncPlot
{
	private Long plotId;
	private String plotCode;
	private Geometry geom;
	private String srs;
	private List<String> parcelCodes;
	private AbsoluteDate fromDate;
	private AbsoluteDate toDate;
}
