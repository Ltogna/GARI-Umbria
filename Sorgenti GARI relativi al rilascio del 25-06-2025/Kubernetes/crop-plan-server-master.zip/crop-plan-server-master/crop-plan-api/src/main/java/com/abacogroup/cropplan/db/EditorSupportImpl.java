package com.abacogroup.cropplan.db;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.geom.Polygonal;

import com.abacogroup.cropplan.api.CutBehaviour;
import com.abacogroup.cropplan.api.payload.DrawLineBufferPayload.LineBufferBehaviour;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.PlotEditDAO;
import com.abacogroup.cropplan.db.dao.SubdomainZoneDAO;
import com.abacogroup.cropplan.db.dao.ntt.ParcelIntersectionWithPlotId;
import com.abacogroup.cropplan.db.dao.ntt.PlotGeometry;
import com.abacogroup.cropplan.db.dao.ntt.PlotGeometryInSubdomain;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandCoverClassEditability;
import com.abacogroup.cropplan.sdk.spi.CropCodesPlugin;
import com.abacogroup.cropplan.sdk.spi.DomainPlugin;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.support.EditorSupportParams;
import com.abacogroup.geometryeditor.EditorSupport;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.google.common.collect.Lists;

public class EditorSupportImpl implements EditorSupport<String> {
	//private static final Logger log = LoggerFactory.getLogger(EditorSupportImpl.class);

	private RuntimeEnvironment env;
	private Long cropPlanId;
	private String domainZoneId;
	private String businessId;
	private Long subdomainZoneId;
	private CutBehaviour cutBehaviour;
	private LineBufferBehaviour lineBufferBehaviour;
	private boolean ignoreEditability;
	private Map<String, Polygon> cutPolygons;
	private AbsoluteDate pointInTime;
	private AbsoluteDate snapFromDate;
	private boolean isForPreview;
	private PlotEditDAO plotEditDAO;
	private CropPlansDAO cropPlansDAO;
	private SubdomainZoneDAO subdomainZoneDAO;
	private DomainPlugin domainPlugin;
	private CropCodesPlugin cropCodesPlugin;
	private long lastPreviewKey = 0;
	private CropPlanConfigService cropPlanConfigService;
	
	private Collection<Polygonal> canvasGeometries = null;

	public EditorSupportImpl(RuntimeEnvironment env, EditorSupportParams editorSupportParams, CutBehaviour cutBehaviour,
			LineBufferBehaviour lineBufferBehaviour, boolean ignoreEditability,
			Map<String, Polygon> cutPolygons, AbsoluteDate pointInTime, AbsoluteDate snapFromDate, boolean isForPreview,
			PlotEditDAO plotEditDAO, CropPlansDAO cropPlansDAO, SubdomainZoneDAO subdomainZoneDAO, DomainPlugin domainPlugin, CropCodesPlugin cropCodesPlugin, CropPlanConfigService cropPlanConfigService) {
		this.env = env;
		this.cropPlanId = editorSupportParams.getCropPlanId();
		this.domainZoneId = editorSupportParams.getDomainZoneId();
		this.businessId = editorSupportParams.getBusinessId();
		this.subdomainZoneId = editorSupportParams.getSubdomainZoneId();
		this.cutBehaviour = cutBehaviour;
		this.lineBufferBehaviour = lineBufferBehaviour;
		this.ignoreEditability = ignoreEditability;
		this.cutPolygons = cutPolygons;
		this.pointInTime = pointInTime;
		this.snapFromDate = snapFromDate;
		this.isForPreview = isForPreview;
		this.plotEditDAO = plotEditDAO;
		this.cropPlansDAO = cropPlansDAO;
		this.subdomainZoneDAO = subdomainZoneDAO;
		this.domainPlugin = domainPlugin;
		this.cropCodesPlugin = cropCodesPlugin;
		this.cropPlanConfigService = cropPlanConfigService;
	}

	@Override
	public Map<String, Polygon> loadPolygonsForTopologyCorrection(Geometry touchingGeometry) {
		//long startTime = System.currentTimeMillis();
		List<PlotGeometryInSubdomain> polygons;
		if(cropPlanConfigService.disablePlotDataSpatialIndex(cropPlanId)){
			polygons = plotEditDAO.getPolygonsWithInteractionWithNoSpatialIndex(cropPlanId, domainZoneId, pointInTime, touchingGeometry);
		} else {
			polygons = plotEditDAO.getPolygonsWithInteraction(cropPlanId, domainZoneId, pointInTime, touchingGeometry);
		}

		
		Map<String, Polygon> map = new HashMap<>();
		polygons.forEach(p -> map.put(p.getPlotCode(), (Polygon) p.getGeom()));
		//long endTime = System.currentTimeMillis();
		//log.info("TIME ELAPSED loadPolygonsForTopologyCorrection (loaded n. " + polygons.size() + "): " + (endTime-startTime) + "s");
		return map;
	}

	@Override
	public InvolvedPolygons<String> loadPolygonsWithInteraction(Geometry touchingGeometry, InvolvedPolygonsInterest interested) {
		final Map<String, Polygon> modifiablePolygons = new HashMap<>();
		final Map<String, Polygon> unmodifiablePolygons = new HashMap<>();

		//long startTime = System.currentTimeMillis();					
		List<PlotGeometryInSubdomain> polygons = Optional.ofNullable(subdomainZoneId)
				.map(id -> subdomainZoneDAO.findSubdomainZoneGeomById(id)
						.orElseGet(() -> new GeometryFactory().createPolygon()))
				.map(subdomainZone -> cropPlanConfigService.disablePlotDataSpatialIndex(cropPlanId)? 
						plotEditDAO.getPolygonsWithInteractionInSubdomainWithNoSpatialIndex(cropPlanId, domainZoneId, pointInTime, touchingGeometry, subdomainZone)  
						: plotEditDAO.getPolygonsWithInteractionInSubdomain(cropPlanId, domainZoneId, pointInTime, touchingGeometry, subdomainZone))				
				.orElseGet(() -> cropPlanConfigService.disablePlotDataSpatialIndex(cropPlanId)? 
					plotEditDAO.getPolygonsWithInteractionWithNoSpatialIndex(cropPlanId, domainZoneId, pointInTime, touchingGeometry) 
					: plotEditDAO.getPolygonsWithInteraction(cropPlanId, domainZoneId, pointInTime, touchingGeometry));

		var plotIdsInSubdomainZone = polygons.stream()
				.filter(PlotGeometryInSubdomain::isInSubdomain)
				.map(PlotGeometry::getPlotId)
				.collect(toList());
		List<List<Long>> partitions = Lists.partition(plotIdsInSubdomainZone, 666);
		Map<Long, List<ParcelIntersection>> parcelsIntersectionByPlotId = partitions.stream()
				.flatMap(part -> cropPlansDAO.getPlotsParcelsInternal(part, cropPlanId, cropPlansDAO.getCurrentTimestamp()).stream()).map(m -> (ParcelIntersection) m)
				.collect(groupingBy(row -> ((ParcelIntersectionWithPlotId) row).getPlotId()));

		Map<String, LandCoverClassEditability> editabilities = new HashMap<>();
		polygons.forEach(p -> {
			computePolygonInteraction(modifiablePolygons, unmodifiablePolygons, parcelsIntersectionByPlotId, editabilities, p);
		});

		if (cutBehaviour != CutBehaviour.CUT_EXISTING || cutPolygons != null || lineBufferBehaviour == LineBufferBehaviour.EXTERNAL) {
			var it = modifiablePolygons.entrySet().iterator();
			while (it.hasNext()) {
				var entry = it.next();

				if (isPolygonUnmodifiableCheckCutExisting(entry) || isPolygonUnmodifiableCheckCutOnExisting(entry)) {
					unmodifiablePolygons.put(entry.getKey(), entry.getValue());
					it.remove();
				}
			}
		}
		//long endTime = System.currentTimeMillis();
		//log.info("TIME ELAPSED (" + cropPlanId + "): loadPolygonsWithInteraction: " + TimeUnit.MILLISECONDS.toSeconds((endTime-startTime)) + "s");								
		
		return new InvolvedPolygons<>(modifiablePolygons, unmodifiablePolygons);
	}

	private boolean isPolygonUnmodifiableCheckCutExisting(Entry<String, Polygon> entry) {
		return cutBehaviour == CutBehaviour.CUT_EXISTING && cutPolygons != null && 
					((lineBufferBehaviour == LineBufferBehaviour.EXTERNAL && cutPolygons.get(entry.getKey()) != null) || 
					(lineBufferBehaviour != LineBufferBehaviour.EXTERNAL && cutPolygons.get(entry.getKey()) == null));
	}
	
	private boolean isPolygonUnmodifiableCheckCutOnExisting(Entry<String, Polygon> entry) {
		return (cutBehaviour == CutBehaviour.CUT_ON_EXISTING && cutPolygons != null && cutPolygons.get(entry.getKey()) != null) ||
				(cutBehaviour == CutBehaviour.CUT_ON_EXISTING && cutPolygons == null);
	}

	private void computePolygonInteraction(final Map<String, Polygon> modifiablePolygons, final Map<String, Polygon> unmodifiablePolygons,
			Map<Long, List<ParcelIntersection>> parcelsIntersectionByPlotId, Map<String, LandCoverClassEditability> editabilities,
			PlotGeometryInSubdomain p) {
		var parcels = parcelsIntersectionByPlotId.compute(p.getPlotId(), (k, v) -> v == null ? new ArrayList<>(0) : v);

		boolean isEditable = true;
		if (p.isInSubdomain()) {
			if (parcels.size() > 0) {
				isEditable = getEditabilityByParcels(editabilities, parcels);
			} else {
				var editability = editabilities.get(null);
				if (editability == null) {
					isEditable = cropCodesPlugin.getLandCoverEditability(env, businessId, null) == LandCoverClassEditability.EDITABLE;
					editabilities.put(null, editability);
				} else
					isEditable = (editability == LandCoverClassEditability.EDITABLE);
			}
		} else {
			isEditable = false;
		}

		if (ignoreEditability || isEditable)
			modifiablePolygons.put(p.getPlotCode(), (Polygon) p.getGeom());
		else
			unmodifiablePolygons.put(p.getPlotCode(), (Polygon) p.getGeom());
	}

	private boolean getEditabilityByParcels(Map<String, LandCoverClassEditability> editabilities, List<ParcelIntersection> parcels) {
		for (var parcel : parcels) {
			var editability = editabilities.get(parcel.getLandCoverCode());
			if (editability == null) {
				editability = cropCodesPlugin.getLandCoverEditability(env, businessId, parcel.getLandCoverCode());
				editabilities.put(parcel.getLandCoverCode(), editability);
			}

			if (editability != LandCoverClassEditability.EDITABLE) {
				return false;
			}
		}
		return true;
	}

	@Override
	public Map<String, Polygon> createPolygonKeys(String key, Collection<Polygon> polygons) {
		Map<String, Polygon> map = new HashMap<>();
		var maxAreaPolygon = polygons.stream().max(Comparator.comparing(Polygon::getArea));
		if (!maxAreaPolygon.isEmpty()) {
			map.put(key, maxAreaPolygon.get());
		}

		polygons.forEach(p -> {
			if (p != maxAreaPolygon.get())
				map.put(getNewPolygonKey(), p);
		});
		return map;
	}

	@Override
	public Map<String, Polygon> createPolygonKeys(Collection<Polygon> polygons) {
		Map<String, Polygon> map = new HashMap<>();
		polygons.forEach(p -> map.put(getNewPolygonKey(), p));
		return map;
	}

	private String getNewPolygonKey() {
		if (isForPreview) {
			lastPreviewKey -= 1;
			return "*temp*" + lastPreviewKey;
		} else {
			return plotEditDAO.getCropPlotDataSeq().toString();
		}
	}

	@Override
	public Collection<Polygonal> loadCanvasGeometries(Geometry touchingGeometry) {
		if (canvasGeometries != null)
			return canvasGeometries;
		//long startTime = System.currentTimeMillis();
		var map = domainPlugin.getParcels(env, businessId, domainZoneId, snapFromDate.toLocalDate(),
				touchingGeometry);
		//long endTime = System.currentTimeMillis();
		//log.info("TIME ELAPSED: loadCanvasGeometries (loaded n. " + map.size() + "): " + TimeUnit.MILLISECONDS.toSeconds((endTime-startTime)) + "s");
		return map.values();
	}

	public void setCanvasGeometries(Collection<Polygonal> canvasGeometries) {
		this.canvasGeometries = canvasGeometries;
	}

}
