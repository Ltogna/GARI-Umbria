package com.abacogroup.cropplan.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;

@Data
public class CropPlan
{
	@Schema(description = "The crop plan id, this does not change in history")
	@NotNull
	private Long cropPlanId;

	@Schema(description = "The crop plan type code")
	@NotEmpty
	private String cropPlanTypeCode;

	@Schema(description = "The crop plan type description")
	@NotEmpty
	private String cropPlanTypeDescription;

	@Schema(description = "The crop plan description")
	@NotEmpty
	private String description;

	@Schema(description = "Are there any pending changes not yet versioned?")
	@NotNull
	private Boolean changesPending;
	
	@Schema(description = "If it is set to true then the crop plan is read only")
	@NotNull
	private Boolean readOnly = false;
	
	@Schema(description = "If it is set to true then the crop plan is locked")
	@NotNull
	private Boolean locked = false;
	
	@Schema(description = "The locked error code")
	private String lockedErrorCode;
	
	@Schema(description = "If it is set to true then plots can be added")
	@NotNull
	private Boolean canAddPlots;
	
	@NotNull
	private List<CropPlanPrint> cropPlanPrints;
}
