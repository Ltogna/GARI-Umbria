package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;

@Data
@Schema(description = "A crop declaration for a time period")
public class InsertDeclarationPayload
{
	@Schema(description = "Land use code")
	@NotEmpty
	private String landuseCode;

	@Schema(description = "The declared area in percentage")
	@NotNull
	private Double areaPerc;

	@Schema(description = "From date")
	@NotNull
	private AbsoluteDate fromDate;
	
	@Schema(description = "From date precision ('Y' if only year is specified, 'YM' if year month is specified, 'YMD' if year month date is specified, '-' if nothing is specified and plot day from is used); default 'YMD'")
	@NotNull
	private String fromDatePrecision = "YMD";

	@Schema(description = "To date")
	@NotNull
	private AbsoluteDate toDate;

	private List<InsertPermanentCropForm> permanentCropForms;
	
	@Schema(description = "List of additional fields codes values")
	private List<LandUseAdditionalDataField> fieldsCodes;
	
	@Schema(description = "If it is set to true then existing declarations between from date and to date are removed")
	private boolean removeExistingDeclarations = false;
	
	/*@Schema(description = "The source declaration code from which it was copied (null if the declaration is not a copy)")
	private String sourceDeclCode;*/

}
