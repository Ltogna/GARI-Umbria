package com.abacogroup.cropplan.db.dao.support;

import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DaoSupportParams {
	String insertUserId;
	String deleteUserId;
	LocalDateTime insertDt; 
	LocalDateTime deleteDt;
	
	LocalDateTime transId;
	Integer flVersioned;
	
	Long cropPlanId; 
	String plotCode; 
	String declCode;
	
	String landUseCode;
	
}
