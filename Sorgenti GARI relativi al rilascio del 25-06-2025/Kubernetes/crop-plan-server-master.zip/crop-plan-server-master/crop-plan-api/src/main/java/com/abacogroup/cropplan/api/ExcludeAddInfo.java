package com.abacogroup.cropplan.api;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Additional info to esclude from get plots API")
public enum ExcludeAddInfo
{
	PARCELS,
	PARCELS_DESCRIPTION,
	PARCELS_LAND_COVER_DESC,
	PARCELS_MBR_OVERVIEW,
	PARCELS_PLOT_STYLE,
	PARCELS_PLOT_EDITABILITY,
	DECLARATIONS,
	DECLARATIONS_PLOT_STYLE,
	DECLARATIONS_PESTICIDES,
	ANOMALIES
}
