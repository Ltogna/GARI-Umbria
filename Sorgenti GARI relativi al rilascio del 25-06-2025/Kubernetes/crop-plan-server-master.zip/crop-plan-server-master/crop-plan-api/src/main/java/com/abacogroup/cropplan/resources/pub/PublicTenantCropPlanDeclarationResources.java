package com.abacogroup.cropplan.resources.pub;

import static java.util.stream.Collectors.toList;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.abacogroup.cropplan.api.CropPlanLandUse;
import com.abacogroup.cropplan.api.DisabledFunctionCode;
import com.abacogroup.cropplan.api.EditDeclarationResult;
import com.abacogroup.cropplan.api.PlotDeclaration;
import com.abacogroup.cropplan.api.SortDeclaration;
import com.abacogroup.cropplan.api.payload.EditDeclarationPayload;
import com.abacogroup.cropplan.api.payload.EditDeclarationsPayload;
import com.abacogroup.cropplan.api.payload.InsertDeclarationPayload;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.db.dao.ntt.DeclarationBaseInfo;
import com.abacogroup.cropplan.exceptions.CropPlanNotWriteableException;
import com.abacogroup.cropplan.exceptions.CropPlanReadOnlyException;
import com.abacogroup.cropplan.exceptions.IncompatibleLandUseException;
import com.abacogroup.cropplan.exceptions.InvalidDeclAreaPercZeroException;
import com.abacogroup.cropplan.exceptions.InvalidDeclDatesException;
import com.abacogroup.cropplan.exceptions.InvalidDeclException;
import com.abacogroup.cropplan.exceptions.LandUseCodeNotFoundException;
import com.abacogroup.cropplan.exceptions.LockException;
import com.abacogroup.cropplan.exceptions.MaxDeclAreaException;
import com.abacogroup.cropplan.exceptions.PermanentCropFormNotAllowedException;
import com.abacogroup.cropplan.exceptions.PlotDeclarationsNotEditableException;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.BaseCropPlanResource;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.Version;
import com.abacogroup.cropplan.sdk.model.config.CropPlanConfigParam;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.domain.ParcelDescription;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.CropPlanDeclarationsService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.DeclarationService;
import com.abacogroup.cropplan.services.LocksService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.cropplan.services.support.PlotTimeWindowParams;
import com.abacogroup.cropplan.services.support.PlotsTimeWindowParams;
import com.abacogroup.cropplan.services.support.PlotsTimeWindowPlotData;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.ForbiddenException;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.SecurityContext;

@Path("{tenant}/public")
@Tag(name = "PUBLIC - Crop plan declaration resources")
@Timed
@RolesAllowed({ "CRPL|USER", "CRPL|EDITOR" })
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class PublicTenantCropPlanDeclarationResources extends BaseCropPlanResource {
	private final static int PAGE_SIZE = 10;
	private final CropPlanService cropPlanService;
	private final CropPlanDeclarationsService cropPlanDeclarationsService;
	private final DeclarationService declarationsService;
	private final LocksService locksService;
	private final PluginManager pluginManager;
	private final CropPlansDAO cropPlansDAO;
	private final DeclarationsDAO declarationsDAO;
	private final CropPlanConfigDAO cropPlanConfigDAO;

	public PublicTenantCropPlanDeclarationResources(BaseService baseService, CropPlanService cropPlanService,
			CropPlanDeclarationsService cropPlanDeclarationsService,
			DeclarationService declarationsService, LocksService locksService, CropCodeService cropCodeService,
			ValidatorService validatorService, CropPlanConfigService cropPlanConfigService,
			PluginManager pluginManager, DAOContainer daocontainer) {
		super(baseService, cropPlanService, locksService, cropCodeService, validatorService, cropPlanConfigService, pluginManager, daocontainer.getCropPlansDAO()
		);
		this.cropPlanService = cropPlanService;
		this.cropPlanDeclarationsService = cropPlanDeclarationsService;
		this.declarationsService = declarationsService;
		this.locksService = locksService;
		this.pluginManager = pluginManager;
		this.cropPlansDAO = daocontainer.getCropPlansDAO();
		this.declarationsDAO = daocontainer.getDeclarationsDAO();
		this.cropPlanConfigDAO = daocontainer.getCropPlanConfigDAO();
	}

	@POST
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/domains/{domainZoneCode}/plots/{plotCode}/decls")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Create a new plot declaration")
	@ApiResponses({
			@ApiResponse(description = "The new plot declaration created"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot declarations are not editable", content = @Content(schema = @Schema(implementation = PlotDeclarationsNotEditableException.PlotDeclarationsNotEditableExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use is not allowed for the land cover", content = @Content(schema = @Schema(implementation = IncompatibleLandUseException.IncompatibleLandUseExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Maximum declarable area exceeded", content = @Content(schema = @Schema(implementation = MaxDeclAreaException.MaxDeclAreaExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration", content = @Content(schema = @Schema(implementation = InvalidDeclException.InvalidDeclExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration dates", content = @Content(schema = @Schema(implementation = InvalidDeclDatesException.InvalidDeclDatesExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Permanent crop form not allowed for the land use", content = @Content(schema = @Schema(implementation = PermanentCropFormNotAllowedException.PermanentCropFormNotAllowedExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid Decl Area Perc Zero", content = @Content(schema = @Schema(implementation = InvalidDeclAreaPercZeroException.ErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use was not found", content = @Content(schema = @Schema(implementation = LandUseCodeNotFoundException.LandUseCodeNotFoundExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditDeclarationResult createDeclaration(
			@Context SecurityContext context,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone code") @PathParam("domainZoneCode") String domainZoneCode,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "If it is set to true then the areas are returned considering tolerance") @QueryParam("withTolerance") @DefaultValue("false") boolean withTolerance,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@Parameter(description = "If it is set to true then the declarations validation messages will be ignored") @QueryParam("ignoreAllDeclValidationMessages") @DefaultValue("false") boolean ignoreAllDeclValidationMessages,
			@Parameter(description = "If it is set to true then the can declare check is skipped") @QueryParam("skipCheckCanDeclare") @DefaultValue("false") boolean skipCheckCanDeclare,
			@Parameter(description = "If it is set to true then partial additional fields are allowed") @QueryParam("allowPartialAdditionalFields") @DefaultValue("false") boolean allowPartialAdditionalFields,
			@Parameter(description = "If it is set to true then the specified crop plan is locked for the current user") @QueryParam("autoLock") @DefaultValue("false") boolean autoLock,
			@Parameter(description = "The point in time used to retrieve permanent crop form and land use additional field") @QueryParam("pointInTime") AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid InsertDeclarationPayload payload) {

		// this checks are calling cropCodeService.getLandUseCode at least 2 times
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		if (autoLock)
			locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
		else
			checkLock(env, cropPlanId);

		if (ignoreAllDeclValidationMessages && !context.isUserInRole("CRPL|CAN_IGNORE_VALIDATION_MSGS")) {
			throw new ForbiddenException("You are not authorized to ignore all declS validation messages");
		}

		if (!cropPlanConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.DISABLE_ADD_DECLARATIONS.toString(), "TRUE").isEmpty())
			throw new ForbiddenException("DISABLE_ADD_DECLARATIONS is set to TRUE");

		var domainZone = pluginManager.getDomainPlugin(businessId, cropPlanId, tenantId)
				.getDomainZoneByCode(env, businessId, payload.getFromDate().toLocalDate(), domainZoneCode);
		if (domainZone == null)
			throw new BadRequestException("The specified domainZoneCode was not found");

		LocalDateTime currentDt = cropPlansDAO.getCurrentTimestamp();
		PlotTimeWindowParams params = PlotTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.domainZoneId(domainZone.getDomainZoneId())
				.plotCode(plotCode)
				.pointInTimeFrom(payload.getFromDate())
				.pointInTimeTo(payload.getToDate())
				.versionDt(currentDt)
				.build();
		if (!skipCheckCanDeclare)
			checkCanDeclare(env, params, payload.getLanduseCode(), payload.getAreaPerc(), payload.isRemoveExistingDeclarations());

		var plot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZone.getDomainZoneId(),
				currentDt, payload.getFromDate(), payload.getToDate(), plotCode);
		if (plot == null)
			throw new BadRequestException("The plot " + plotCode + " was not found");
		checkPlotEditability(env, businessId, cropPlanId, plot);
		checkLandUseCompatibility(env, businessId, cropPlanId, plot, payload.getLanduseCode());

		cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.ADD_DECLARATIONS, env, businessId, cropPlanId, plot);

		if (payload.getPermanentCropForms() != null) {
			payload.getPermanentCropForms().forEach(pcf -> checkCanHavePermanentCropForm(env, businessId, cropPlanId, payload.getLanduseCode(),
					(pointInTime != null ? pointInTime : payload.getFromDate()), pcf.getFormType()));
		}

		checkCanHaveLandUseAdditionalField(env, businessId, cropPlanId, payload.getLanduseCode(), payload.getFromDate(), payload.getFieldsCodes(),
				allowPartialAdditionalFields);

		return cropPlanDeclarationsService.insertDeclaration(env, params, payload.getLanduseCode(), payload.getAreaPerc(), payload.getFromDatePrecision(),
				plot.getParcelIntersections(), payload.getPermanentCropForms(), payload.getFieldsCodes(), plot.getDecls(),
				payload.isRemoveExistingDeclarations(),
				ignoreDeclValidationWarnings, ignoreAllDeclValidationMessages, withTolerance, false);
	}

	@POST
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/plots/decls")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Create multiple plots declarations")
	@ApiResponses({
			@ApiResponse(description = "The new plots declarations created"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot declarations are not editable", content = @Content(schema = @Schema(implementation = PlotDeclarationsNotEditableException.PlotDeclarationsNotEditableExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use is not allowed for the land cover", content = @Content(schema = @Schema(implementation = IncompatibleLandUseException.IncompatibleLandUseExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Maximum declarable area exceeded", content = @Content(schema = @Schema(implementation = MaxDeclAreaException.MaxDeclAreaExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration", content = @Content(schema = @Schema(implementation = InvalidDeclException.InvalidDeclExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration dates", content = @Content(schema = @Schema(implementation = InvalidDeclDatesException.InvalidDeclDatesExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid Decl Area Perc Zero", content = @Content(schema = @Schema(implementation = InvalidDeclAreaPercZeroException.ErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use was not found", content = @Content(schema = @Schema(implementation = LandUseCodeNotFoundException.LandUseCodeNotFoundExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditDeclarationResult createDeclarations(
			@Context SecurityContext context,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@Parameter(description = "If it is set to true then the declarations validation messages will be ignored") @QueryParam("ignoreAllDeclValidationMessages") @DefaultValue("false") boolean ignoreAllDeclValidationMessages,
			@Parameter(description = "The point in time used to retrieve permanent crop form and land use additional field") @QueryParam("pointInTime") AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid EditDeclarationsPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		if (ignoreAllDeclValidationMessages && !context.isUserInRole("CRPL|CAN_IGNORE_VALIDATION_MSGS")) {
			throw new ForbiddenException("You are not authorized to ignore all declS validation messages");
		}

		if (!cropPlanConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.DISABLE_ADD_DECLARATIONS.toString(), "TRUE").isEmpty())
			throw new ForbiddenException("DISABLE_ADD_DECLARATIONS is set to TRUE");

		LocalDateTime currentDt = cropPlansDAO.getCurrentTimestamp();
		List<PlotsTimeWindowPlotData> plotsData = new ArrayList<>();
		payload.getPlots().forEach(p -> {
			var domainZoneId = cropPlansDAO.getDomainZoneIdByPlotCode(cropPlanId, p.getPlotCode());

			PlotTimeWindowParams ptwp = PlotTimeWindowParams.builder()
					.businessId(businessId)
					.cropPlanId(cropPlanId)
					.domainZoneId(domainZoneId)
					.plotCode(p.getPlotCode())
					.pointInTimeFrom(payload.getFromDate())
					.pointInTimeTo(payload.getToDate())
					.versionDt(currentDt)
					.build();
			checkCanDeclare(env, ptwp, payload.getLanduseCode(), p.getAreaPerc(), payload.isRemoveExistingDeclarations());

			var plot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId,
					currentDt, payload.getFromDate(), payload.getToDate(), p.getPlotCode());
			if (plot == null)
				throw new BadRequestException("The plot " + p.getPlotCode() + " was not found");

			checkPlotEditability(env, businessId, cropPlanId, plot);
			checkLandUseCompatibility(env, businessId, cropPlanId, plot, payload.getLanduseCode());

			cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.ADD_DECLARATIONS, env, businessId, cropPlanId, plot);

			List<String> parcelCodes = plot.getParcelIntersections().stream().map(ParcelIntersection::getCode).collect(toList());
			plotsData.add(PlotsTimeWindowPlotData.builder()
					.plotCode(p.getPlotCode())
					.parcelCodes(parcelCodes)
					.areaPerc(p.getAreaPerc())
					.declarations(plot.getDecls())
					.build());
		});

		if (payload.getPermanentCropForms() != null) {
			payload.getPermanentCropForms().forEach(pcf -> checkCanHavePermanentCropForm(env, businessId, cropPlanId, payload.getLanduseCode(),
					(pointInTime != null ? pointInTime : payload.getFromDate()), pcf.getFormType()));
		}
		checkCanHaveLandUseAdditionalField(env, businessId, cropPlanId, payload.getLanduseCode(), (pointInTime != null ? pointInTime : payload.getFromDate()),
				payload.getFieldsCodes());

		PlotsTimeWindowParams params = PlotsTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				// .domainZoneId(domainZoneId)
				.pointInTimeFrom(payload.getFromDate())
				.pointInTimeTo(payload.getToDate())
				.versionDt(currentDt)
				.plotsData(plotsData)
				.build();

		return cropPlanDeclarationsService.insertDeclarations(env, params, payload.getLanduseCode(), payload.getFromDatePrecision(),
				payload.getPermanentCropForms(), payload.getFieldsCodes(), payload.isRemoveExistingDeclarations(), ignoreDeclValidationWarnings,
				ignoreAllDeclValidationMessages);
	}

	// GET per avere tutte le declarations dell'azienda -> partiamo da qui per creare quella specifica
	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/declarations")
	@Operation(description = "Get the declarations of the plots of a crop plan")
	@ApiResponse(description = "The declarations of the plots of the specified crop plan")
	public InfiniteListResults<PlotDeclaration> getDeclarations(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "The ending point in time to be evaluated (optional, if set then the declarations are evaluated between point in time and point in time to") @QueryParam("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@Parameter(description = "Exclude all declarations planted before this point in time") @QueryParam("excludePlantedBefore") AbsoluteDate excludePlantedBefore,
			@Parameter(description = "Exclude all declarations harvested after this point in time") @QueryParam("excludeHarvestedAfter") AbsoluteDate excludeHarvestedAfter,
			@Parameter(description = "The declarations sorting") @QueryParam("sort") SortDeclaration sort,
			@Parameter(description = "The search string to search by land use, parcel or domain zone") @QueryParam("search") String search,
			@Parameter(description = "The list of the land cover codes filter") @QueryParam("landCoverCodes") List<String> landCoverCodes,
			@Parameter(description = "The land use code filter") @QueryParam("landUseCode") String landUseCode,
			@Parameter(description = "The parcelCode filter") @QueryParam("parcelCode") String parcelCode,
			@Parameter(description = "The list of the declaration codes filter") @QueryParam("declCodes") List<String> declCodes,
			@Parameter(description = "The anomalies error code (declaration or plot) filter") @QueryParam("anomaliesErrorCode") String anomaliesErrorCode,
			@Parameter(description = "Can be supplied to convert geometries returned in the specified srs") @QueryParam("srs") String srs,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		if (pointInTimeTo == null)
			pointInTimeTo = pointInTime;
		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		return declarationsService.getDeclarations(env, cropPlanId, businessId, pointInTime, pointInTimeTo, null, null, excludePlantedBefore,
				excludeHarvestedAfter,
				versionDt, sort, search, landCoverCodes, landUseCode, parcelCode, declCodes, anomaliesErrorCode, srs, nextKey, PAGE_SIZE, null);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/domains/{domainZoneCode}/declarations")
	@Operation(description = "Get the declarations of the plots of a crop plan on a specified domain zone")
	@ApiResponse(description = "The declarations of the plots of the specified crop plan on a specified domain zone")
	public InfiniteListResults<PlotDeclaration> getDeclarationsByDomainZone(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone code") @PathParam("domainZoneCode") String domainZoneCode,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "The ending point in time to be evaluated (optional, if set then the declarations are evaluated between point in time and point in time to") @QueryParam("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@Parameter(description = "Exclude all declarations planted before this point in time") @QueryParam("excludePlantedBefore") AbsoluteDate excludePlantedBefore,
			@Parameter(description = "Exclude all declarations harvested after this point in time") @QueryParam("excludeHarvestedAfter") AbsoluteDate excludeHarvestedAfter,
			@Parameter(description = "The declarations sorting") @QueryParam("sort") SortDeclaration sort,
			@Parameter(description = "The search string to search by land use, parcel or domain zone") @QueryParam("search") String search,
			@Parameter(description = "The list of the land cover codes filter") @QueryParam("landCoverCodes") List<String> landCoverCodes,
			@Parameter(description = "The land use code filter") @QueryParam("landUseCode") String landUseCode,
			@Parameter(description = "The parcelCode filter") @QueryParam("parcelCode") String parcelCode,
			@Parameter(description = "The list of the declaration codes filter") @QueryParam("declCodes") List<String> declCodes,
			@Parameter(description = "The anomalies error code (declaration or plot) filter") @QueryParam("anomaliesErrorCode") String anomaliesErrorCode,
			@Parameter(description = "Can be supplied to convert geometries returned in the specified srs") @QueryParam("srs") String srs,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@HeaderParam("accept-language") @DefaultValue("en") String language
	){

		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		if (pointInTimeTo == null)
			pointInTimeTo = pointInTime;

		var domainZone = pluginManager.getDomainPlugin(businessId, cropPlanId, tenantId)
		.getDomainZoneByCode(env, businessId, pointInTime.toLocalDate(), domainZoneCode);

		if(domainZone == null) {
			throw new BadRequestException("The specified domainZoneCode was not found");
		}
				
		String domainZoneId = domainZone.getDomainZoneId();		

		return declarationsService.getDeclarations(env, cropPlanId, businessId, pointInTime, pointInTimeTo, null, null, excludePlantedBefore,
		excludeHarvestedAfter,
		versionDt, sort, search, landCoverCodes, landUseCode, parcelCode, declCodes, anomaliesErrorCode, srs, nextKey, PAGE_SIZE, domainZoneId);

	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/declarations/updates")
	@Operation(description = "Get the declarations of the plots of a crop plan")
	@ApiResponse(description = "The declarations of the plots of the specified crop plan")
	public InfiniteListResults<PlotDeclaration> getDeclarationsUpdates(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "The ending point in time to be evaluated (optional, if set then the declarations are evaluated between point in time and point in time to") @QueryParam("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@Parameter(description = "The point in time to be evaluated for updates") @QueryParam("updateTimeFrom") LocalDateTime updateTimeFrom,
			@Parameter(description = "The ending point in time to be evaluated for updates") @QueryParam("updateTimeTo") @NotNull LocalDateTime updateTimeTo,
			@Parameter(description = "The list of the land cover codes filter") @QueryParam("landCoverCodes") List<String> landCoverCodes,
			@Parameter(description = "Can be supplied to convert geometries returned in the specified srs") @QueryParam("srs") String srs,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		if (pointInTimeTo == null)
			pointInTimeTo = pointInTime;
		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		return declarationsService.getDeclarations(env, cropPlanId, businessId, pointInTime, pointInTimeTo, updateTimeFrom, updateTimeTo, null, null,
				versionDt, null, null, landCoverCodes, null, null, null, null, srs, nextKey, PAGE_SIZE, null);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/declarations/updates/last-modification-date")
	@Operation(description = "Get the declarations updates of the plots of a crop plan")
	@ApiResponse(description = "The declarations updates of the plots of the specified crop plan")
	public LocalDateTime getDeclarationsLastModificationDate(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The list of the land cover codes filter") @QueryParam("landCoverCode") @NotNull List<String> landCoverCode,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var date = declarationsService.getDeclarationsLastModificationDate(env, businessId, cropPlanId, landCoverCode);
		if (date == null)
			return LocalDateTime.of(1970, 1, 1, 0, 0);
		else
			return date;
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/declarations/land-uses")
	@Operation(description = "Get the declarations land uses of a crop plan")
	@ApiResponses(@ApiResponse(description = "The declarations land uses of a crop plan"))
	public List<LandUse> getDeclarationsLandUses(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "The ending point in time to be evaluated (optional, if set then the declarations are evaluated between point in time and point in time to") @QueryParam("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		if (pointInTimeTo == null)
			pointInTimeTo = pointInTime;
		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();

		return declarationsService.getDeclarationsLandUses(env, cropPlanId, businessId, pointInTime, pointInTimeTo, versionDt);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/declarations/land-uses-with-area")
	@Operation(description = "Get the declarations land uses of a crop plan with total declared area")
	@ApiResponses(@ApiResponse(description = "The declarations land uses of a crop plan with total declared area"))
	public List<CropPlanLandUse> getDeclarationsLandUsesWithArea(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();

		return declarationsService.getDeclarationsLandUsesWithArea(env, cropPlanId, businessId, pointInTime, versionDt);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/declarations/parcels")
	@Operation(description = "Get the declarations parcels of a crop plan")
	@ApiResponses(@ApiResponse(description = "The declarations parcels of a crop plan"))
	public List<ParcelDescription> getDeclarationsParcels(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "The ending point in time to be evaluated (optional, if set then the declarations are evaluated between point in time and point in time to") @QueryParam("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		if (pointInTimeTo == null)
			pointInTimeTo = pointInTime;
		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();

		return declarationsService.getDeclarationsParcels(env, cropPlanId, businessId, pointInTime, pointInTimeTo, versionDt);
	}

	@PUT
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/decls/{declCode}")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Update a plot declaration")
	@ApiResponses({
			@ApiResponse(description = "The updated plot declaration"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot declarations are not editable", content = @Content(schema = @Schema(implementation = PlotDeclarationsNotEditableException.PlotDeclarationsNotEditableExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use is not allowed for the land cover", content = @Content(schema = @Schema(implementation = IncompatibleLandUseException.IncompatibleLandUseExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Maximum declarable area exceeded", content = @Content(schema = @Schema(implementation = MaxDeclAreaException.MaxDeclAreaExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration", content = @Content(schema = @Schema(implementation = InvalidDeclException.InvalidDeclExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration dates", content = @Content(schema = @Schema(implementation = InvalidDeclDatesException.InvalidDeclDatesExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Permanent crop form not allowed for the land use", content = @Content(schema = @Schema(implementation = PermanentCropFormNotAllowedException.PermanentCropFormNotAllowedExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid Decl Area Perc Zero", content = @Content(schema = @Schema(implementation = InvalidDeclAreaPercZeroException.ErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use was not found", content = @Content(schema = @Schema(implementation = LandUseCodeNotFoundException.LandUseCodeNotFoundExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class)))
	})
	public EditDeclarationResult updateDeclaration(
			@Context SecurityContext context,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The plot declaration code") @PathParam("declCode") String declCode,
			@Parameter(description = "If it is set to true then the areas are returned considering tolerance") @QueryParam("withTolerance") @DefaultValue("false") boolean withTolerance,
			@Parameter(description = "If it is set to true then the land use additional fields check will be ignored") @QueryParam("ignoreAdditionalFieldsCheck") @DefaultValue("false") boolean ignoreAdditionalFieldsCheck,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@Parameter(description = "If it is set to true then the declarations validation messages will be ignored") @QueryParam("ignoreAllDeclValidationMessages") @DefaultValue("false") boolean ignoreAllDeclValidationMessages,
			@Parameter(description = "If it is set to true then the specified crop plan is locked for the current user before declaration updating") @QueryParam("autoLock") @DefaultValue("false") boolean autoLock,
			@Parameter(description = "The point in time used to retrieve permanent crop form and land use additional field") @QueryParam("pointInTime") AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid EditDeclarationPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);

		if (autoLock)
			locksService.lockCropPlan(env, cropPlanId);
		else
			checkLock(env, cropPlanId);

		if (ignoreAllDeclValidationMessages && !context.isUserInRole("CRPL|CAN_IGNORE_VALIDATION_MSGS")) {
			throw new ForbiddenException("You are not authorized to ignore all declS validation messages");
		}

		LocalDateTime currentDt = cropPlansDAO.getCurrentTimestamp();
		PlotTimeWindowParams params = PlotTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.domainZoneId(domainZoneId)
				.plotCode(plotCode)
				.excludedDeclCode(declCode)
				.pointInTimeFrom(payload.getFromDate())
				.pointInTimeTo(payload.getToDate())
				.versionDt(currentDt)
				.build();
		checkCanDeclare(env, params, payload.getLanduseCode(), payload.getAreaPerc());

		var plot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId,
				currentDt, payload.getFromDate(), payload.getToDate(), plotCode);
		if (plot == null)
			throw new BadRequestException("The plot " + plotCode + " was not found");
		checkPlotEditability(env, businessId, cropPlanId, plot);
		checkLandUseCompatibility(env, businessId, cropPlanId, plot, payload.getLanduseCode());

		cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.EDIT_DECLARATIONS, env, businessId, cropPlanId, plot);

		if (payload.getPermanentCropForms() != null) {
			payload.getPermanentCropForms().forEach(pcf -> checkCanHavePermanentCropForm(env, businessId, cropPlanId, payload.getLanduseCode(),
					(pointInTime != null ? pointInTime : payload.getFromDate()), pcf.getFormType()));
		}

		if (!ignoreAdditionalFieldsCheck)
			checkCanHaveLandUseAdditionalField(env, businessId, cropPlanId, payload.getLanduseCode(),
					(pointInTime != null ? pointInTime : payload.getFromDate()), payload.getFieldsCodes());

		return cropPlanDeclarationsService.updateDeclaration(env, params, declCode, payload.getLanduseCode(), payload.getAreaPerc(),
				payload.getFromDatePrecision(),
				plot.getParcelIntersections(), payload.getPermanentCropForms(), payload.getFieldsCodes(), ignoreDeclValidationWarnings,
				ignoreAllDeclValidationMessages, withTolerance);
	}

	@DELETE
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/decls/{declCode}")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Delete a plot declaration")
	@ApiResponses({
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot declarations are not editable", content = @Content(schema = @Schema(implementation = PlotDeclarationsNotEditableException.PlotDeclarationsNotEditableExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class)))
	})
	public EditDeclarationResult deleteDeclaration(
			@Context SecurityContext context,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The plot declaration code") @PathParam("declCode") String declCode,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@Parameter(description = "If it is set to true then the declarations validation messages will be ignored") @QueryParam("ignoreAllDeclValidationMessages") @DefaultValue("false") boolean ignoreAllDeclValidationMessages,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		if (ignoreAllDeclValidationMessages && !context.isUserInRole("CRPL|CAN_IGNORE_VALIDATION_MSGS")) {
			throw new ForbiddenException("You are not authorized to ignore all declS validation messages");
		}

		LocalDateTime currentDt = cropPlansDAO.getCurrentTimestamp();
		PlotTimeWindowParams params = PlotTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.domainZoneId(domainZoneId)
				.plotCode(plotCode)
				.excludedDeclCode(declCode)
				.pointInTimeFrom(null)
				.pointInTimeTo(null)
				.versionDt(currentDt)
				.build();

		var decl = declarationsDAO.getDeclarationByDeclCode(cropPlanId, plotCode, currentDt, declCode);
		if (decl == null)
			throw new BadRequestException("The declaration " + declCode + " was not found");

		var plot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId,
				currentDt, decl.getFromDate(), decl.getToDate(), plotCode);
		if (plot == null)
			throw new BadRequestException("The plot " + plotCode + " was not found");
		checkPlotEditability(env, businessId, cropPlanId, plot);

		cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.DELETE_DECLARATIONS, env, businessId, cropPlanId, plot);

		return cropPlanDeclarationsService.deleteDeclaration(env, params, decl, plot.getParcelIntersections(), ignoreDeclValidationWarnings,
				ignoreAllDeclValidationMessages);
	}

	@GET
	@Path("/v1/crop-plans-by-id/{cropPlanId}/declarations/base-info")
	@Operation(description = "Get the declarations of the plots of a crop plan")
	@ApiResponse(description = "The declarations of the plots of the specified crop plan")
	public List<DeclarationBaseInfo> getDeclarationBaseInfo(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The declaration code") @QueryParam("declCode") @NotNull @Size(min = 1, max = 900) List<String> declCodes,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "The ending point in time to be evaluated (optional, if set then the declarations are evaluated between point in time and point in time to") @QueryParam("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, cropPlanId);

		if (pointInTimeTo == null)
			pointInTimeTo = pointInTime;
		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		return declarationsDAO.getDeclarationBaseInfo(cropPlanId, declCodes, versionDt, pointInTime, pointInTimeTo);
	}
}
