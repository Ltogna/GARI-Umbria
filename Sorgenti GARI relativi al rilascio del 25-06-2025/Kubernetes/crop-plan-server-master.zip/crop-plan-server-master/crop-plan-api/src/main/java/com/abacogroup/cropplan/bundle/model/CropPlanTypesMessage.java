package com.abacogroup.cropplan.bundle.model;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CropPlanTypesMessage
{
	@Builder.Default
	private List<CropPlanTypeDefinition> cropPlanTypes = new ArrayList<>();
}
