package com.abacogroup.cropplan.api;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "The alert code")
public enum AlertCode
{
	PERMANENT_CROP_FORMS_HAVE_CHANGED
}
