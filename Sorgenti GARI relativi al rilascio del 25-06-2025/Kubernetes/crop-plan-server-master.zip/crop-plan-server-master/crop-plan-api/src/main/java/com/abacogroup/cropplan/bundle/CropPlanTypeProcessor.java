package com.abacogroup.cropplan.bundle;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.cropplan.bundle.model.CropPlanTypesMessage;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;

public class CropPlanTypeProcessor extends AbstractConfigProcessor
{
	private static final String I18N_TABLE_NAME = "CRPL_TYPES";
	private static final String I18N_FIELD_NAME = "CODE";

	public CropPlanTypeProcessor(CropPlanConfigDAO configDAO)
	{
		super(configDAO);
	}

	@Override
	public String getDomainName()
	{
		return "crplTypes";
	}

	@Override
	public void onMessageInTransaction(CropPlanConfigDAO dao, ConfigDataMessage message)
	{
		message.getConfigFiles().stream()
			.map(Path::toFile)
			.filter(file -> file.getAbsolutePath().endsWith(".json"))
			.sorted()
			.forEach(file -> processFile(message.getTenantId(), file));
	}

	private void processFile(String tenantId, File file)
	{
		CropPlanTypesMessage message;
		try
		{
			message = objectMapper.readValue(file, CropPlanTypesMessage.class);
		}
		catch (IOException e)
		{
			throw new IllegalStateException("Error processing file " + file.getName() + " for tenant " + tenantId, e);
		}

		if (file.getAbsolutePath().endsWith(".delete.json"))
		{
			doDelete(tenantId, message);
		}
		else
		{
			doInsertOrUpdate(tenantId, message);
		}
	}

	private void doInsertOrUpdate(String tenantId, CropPlanTypesMessage message)
	{
		if (message == null || message.getCropPlanTypes() == null || message.getCropPlanTypes().isEmpty())
		{
			return;
		}

		message.getCropPlanTypes().forEach(cropPlanType -> {
			if(configDAO.countCrplTypes(cropPlanType.getCode(), tenantId) > 0)
				configDAO.updateCropPlanType(cropPlanType.getCode(), cropPlanType.getFlMultipleInt(),
					cropPlanType.getFlLimitToCanvasInt(), cropPlanType.getFlSplitOnCanvasInt(),
						cropPlanType.getDayFrom(), cropPlanType.getDayTo(), tenantId);
			else
				configDAO.insertCropPlanType(cropPlanType.getCode(), cropPlanType.getFlMultipleInt(),
					cropPlanType.getFlLimitToCanvasInt(), cropPlanType.getFlSplitOnCanvasInt(),
						cropPlanType.getDayFrom(), cropPlanType.getDayTo(), tenantId);

			cropPlanType.getI18nValues().forEach(i18nValue -> {
				configDAO.deleteI18nValue(I18N_TABLE_NAME, I18N_FIELD_NAME, cropPlanType.getCode(),
					i18nValue.getLanguage(), tenantId);

				configDAO.insertI18nValue(I18N_TABLE_NAME, I18N_FIELD_NAME, cropPlanType.getCode(),
					i18nValue.getLanguage(), i18nValue.getText(), tenantId);
			});
		});
	}
	
	private void doDelete(String tenantId, CropPlanTypesMessage message)
	{
		if (message == null || message.getCropPlanTypes() == null || message.getCropPlanTypes().isEmpty())
		{
			return;
		}

		message.getCropPlanTypes().forEach(cropPlanType -> {
			configDAO.expireCropPlanType(cropPlanType.getCode(), tenantId);
		});
	}

}
