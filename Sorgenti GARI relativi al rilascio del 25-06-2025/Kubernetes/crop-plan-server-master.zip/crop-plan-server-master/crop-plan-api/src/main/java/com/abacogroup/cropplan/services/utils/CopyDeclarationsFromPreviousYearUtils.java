package com.abacogroup.cropplan.services.utils;

import static java.util.stream.Collectors.toList;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

import com.abacogroup.cropplan.api.CropPlan;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.payload.InsertPermanentCropForm;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.db.dao.ntt.DeclarationWithPlotCode;
import com.abacogroup.cropplan.exceptions.LandUseCodeNotFoundException;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseClass;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseDetails;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedDeclaration;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorOperation;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CopyDeclarationsFromPreviousYearUtils {

	private static final AbsoluteDate DEFAULT_END_DATE = AbsoluteDate.of("99991231");

	private CropCodeService cropCodeService;
	private CropPlansDAO cropPlansDAO;
	private DeclarationsDAO declarationsDAO;

	public CopyDeclarationsFromPreviousYearUtils(CropCodeService cropCodeService, CropPlansDAO cropPlansDAO, DeclarationsDAO declarationsDAO) {
		this.cropCodeService = cropCodeService;
		this.cropPlansDAO = cropPlansDAO;
		this.declarationsDAO = declarationsDAO;
	}

	public void newCopyPlotDeclarationsFromPreviousYear(RuntimeEnvironment env, String businessId, Long cropPlanId,
			boolean ignoreCropPlanConstraintsDeclsToPlots, boolean forceNotCompatibleLandCover, LocalDateTime currentDate,
			AbsoluteDate pointInTime, ArrayList<ValidatorBoundedDeclaration> bds,
			Plot currentPlot, List<String> parcelCodes, Plot previousPlot, boolean fromPreviousYear) {

		if (null != previousPlot && null != previousPlot.getDecls() && !previousPlot.getDecls().isEmpty()) {

			List<DateInterval> freeIntervals = this.calculateFreeIntervals(cropPlanId, currentDate, pointInTime, currentPlot, previousPlot,
					ignoreCropPlanConstraintsDeclsToPlots);

			for (Declaration previousPlotDecl : previousPlot.getDecls()) {

				this.newCopyPlotDeclarationFromPreviousYear(env, businessId, cropPlanId, forceNotCompatibleLandCover,
						currentDate,
						bds, currentPlot, parcelCodes, previousPlotDecl, freeIntervals, fromPreviousYear);
			}
		}

	}

	private List<DateInterval> calculateFreeIntervals(Long cropPlanId, LocalDateTime currentDate, AbsoluteDate pointInTime, Plot currentPlot, Plot previousPlot,
			boolean ignoreCropPlanConstraintsDeclsToPlots) {
		AbsoluteDate minFromDate = previousPlot.getDecls()
				.stream()
				.map(Declaration::getFromDate)
				.min(Comparator.comparing(AbsoluteDate::toLocalDate))
				.map(d -> AbsoluteDate.of(d.toLocalDate().plusYears(1)))
				.orElse(pointInTime);

		AbsoluteDate maxToDate = previousPlot.getDecls()
				.stream()
				.map(Declaration::getToDate)
				.max(Comparator.comparing(AbsoluteDate::toLocalDate))
				.map(d -> AbsoluteDate.of(d.toLocalDate().plusYears(1)))
				.orElse(pointInTime);

		List<DeclarationWithPlotCode> currentDeclsOnRange = declarationsDAO.getPlotsDeclarationsInternal(cropPlanId, List.of(currentPlot.getPlotCode()),
				currentDate, minFromDate, maxToDate);

		List<DateInterval> currentPlotDates = Stream.concat(
				currentDeclsOnRange.stream().map(DateInterval::fromDecl),
				ignoreCropPlanConstraintsDeclsToPlots
						? Stream.of(new DateInterval(LocalDate.MIN, LocalDate.MIN), new DateInterval(LocalDate.MAX, LocalDate.MAX))
						: DateInterval.fromPlotDates(currentPlot).stream()
		).collect(toList());

		return DateInterval.findFreeIntervals(currentPlotDates);
	}

	private void newCopyPlotDeclarationFromPreviousYear(RuntimeEnvironment env, String businessId, Long cropPlanId,
			boolean forceNotCompatibleLandCover, LocalDateTime currentDate,
			ArrayList<ValidatorBoundedDeclaration> bds, Plot currentPlot,
			List<String> parcelCodes, Declaration previousDecl, List<DateInterval> freeIntervals, boolean fromPreviousYear) {

		DateInterval oldDeclDates = DateInterval.fromDecl(previousDecl);
		DateInterval newDeclDates = DateInterval.cutOnFreeIntervals(fromPreviousYear ? oldDeclDates.plusYears(1) : oldDeclDates, freeIntervals);

		if (null == newDeclDates || !newDeclDates.getDtTo().isAfter(newDeclDates.getDtFrom())) {
			return;
		}

		var newPointInTimeFrom = AbsoluteDate.of(newDeclDates.getDtFrom());
		var newPointInTimeTo = DEFAULT_END_DATE.toLocalDate().isBefore(newDeclDates.getDtTo()) ? DEFAULT_END_DATE : AbsoluteDate.of(newDeclDates.getDtTo());

		if (!forceNotCompatibleLandCover) {
			boolean isLandUseCompatible = Optional.of(currentPlot)
					.map(Plot::getParcelIntersections)
					.stream().flatMap(Collection::stream)
					.map(ParcelIntersection::getLandCoverCode)
					.allMatch(landCoverCode -> cropCodeService.isLandUseCompatible(env, businessId, cropPlanId, previousDecl.getLanduse().getCode(), landCoverCode, true));
			if (!isLandUseCompatible) {
				log.debug("cannot copy decl {} in plot {} of crop plan {}: land use code not compatible",
						previousDecl.getDeclCode(), currentPlot.getPlotCode(), cropPlanId);
				return;
			}

		}

		var pcfs = previousDecl.getPermanentCropForms().stream()
				.map(pcf -> new InsertPermanentCropForm(pcf.getFormType(), pcf.getPermanentCropFormData()))
				.collect(toList());

		// copy the declaration with the new code
		Long declId = cropPlansDAO.insertDeclaration(cropPlanId, currentPlot.getPlotCode(),
				newPointInTimeFrom, previousDecl.getFromDatePrecision(), newPointInTimeTo,
				previousDecl.getLanduse().getCode(), previousDecl.getAreaPerc(), pcfs, previousDecl.getFieldsCodes(), env.getUserId(), currentDate, currentDate);

		bds.add(new ValidatorBoundedDeclaration(currentPlot.getPlotCode(), parcelCodes, declId, String.valueOf(declId),
				previousDecl.getLanduse().getCode(), previousDecl.getAreaPerc(),
				newPointInTimeFrom.toLocalDate(), newPointInTimeTo.toLocalDate(), previousDecl.getFromDatePrecision(), ValidatorOperation.INSERT));

	}

	public void copyPlotDeclarationsFromPreviousYear(RuntimeEnvironment env, String businessId, Long cropPlanId, CropPlan cropPlan,
			boolean ignoreCropPlanConstraintsDeclsToPlots, LocalDateTime currentDate, LocalDateTime deleteDate, AbsoluteDate campaignStartDate,
			AbsoluteDate previousCampaignEndDate, AbsoluteDate previousPointInTime, ArrayList<ValidatorBoundedDeclaration> bds,
			Map<String, LandUseClass> lucMap, Plot currentPlot, List<String> parcelCodes, Plot previousPlot) {
		
		// if plot existed previous year and has declarations
		if (previousPlot != null) {
			// delete current year plot declarations
			currentPlot.getDecls().forEach(decl -> {
				deleteCurrentYearPlotDeclaration(env, businessId, cropPlanId, cropPlan, currentDate, deleteDate, previousPointInTime, bds, lucMap,
						currentPlot, parcelCodes, decl);
			});
			
			// copy previous declarations to current year
			previousPlot.getDecls().forEach(decl -> {	
				copyPlotDeclarationFromPreviousYear(env, businessId, cropPlanId, cropPlan, ignoreCropPlanConstraintsDeclsToPlots, currentDate, deleteDate,
						campaignStartDate, previousCampaignEndDate, bds, lucMap, currentPlot, parcelCodes, decl);
			});
		}
	}

	private void deleteCurrentYearPlotDeclaration(RuntimeEnvironment env, String businessId, Long cropPlanId, CropPlan cropPlan, LocalDateTime currentDate,
			LocalDateTime deleteDate, AbsoluteDate previousPointInTime, ArrayList<ValidatorBoundedDeclaration> bds, Map<String, LandUseClass> lucMap,
			Plot currentPlot, List<String> parcelCodes, Declaration decl) {
		var landUseCode = decl.getLanduse().getCode();
		var luc = cropCodeService.getLandUseCode(env, businessId, cropPlanId, landUseCode, null, decl.getFromDate());
		if (!lucMap.containsKey(luc.getLandUseClass().getLandUseClassCode())) {
			var lucOption = cropPlansDAO.getLandUseClassOptions(env.getTenantId(), cropPlan.getCropPlanTypeCode(), List.of(luc.getLandUseClass().getLandUseClassCode()));
			lucMap.put(luc.getLandUseClass().getLandUseClassCode(), (lucOption.size() > 0 ? lucOption.get(0) : null));
		}

		if (decl.getFromDate().isAfter(previousPointInTime))
		{
			cropPlansDAO.deleteDeclaration(decl.getDeclCode(), cropPlanId, currentPlot.getPlotCode(), deleteDate, env.getUserId(), currentDate);	
			
			bds.add(new ValidatorBoundedDeclaration(currentPlot.getPlotCode(), parcelCodes, decl.getDeclId(), decl.getDeclCode(), 
					decl.getLanduse().getCode(), decl.getAreaPerc(),
					decl.getFromDate().toLocalDate(), decl.getToDate().toLocalDate(), decl.getFromDatePrecision(), ValidatorOperation.DELETE));
		}
	}

	private void copyPlotDeclarationFromPreviousYear(RuntimeEnvironment env, String businessId, Long cropPlanId, CropPlan cropPlan,
			boolean ignoreCropPlanConstraintsDeclsToPlots, LocalDateTime currentDate, LocalDateTime deleteDate, AbsoluteDate campaignStartDate,
			AbsoluteDate previousCampaignEndDate, ArrayList<ValidatorBoundedDeclaration> bds, Map<String, LandUseClass> lucMap, Plot currentPlot,
			List<String> parcelCodes, Declaration decl) {
		var landUseCode = decl.getLanduse().getCode();
		LandUseDetails luc = null;
		try {
			// try to transcode the landuse code before use it in the new campaign
			var newLandUseCode = cropCodeService.transcodeLandUseCode(env, businessId, cropPlanId, landUseCode, null, AbsoluteDate.of(decl.getFromDate().toLocalDate().plusYears(1)));
			luc = cropCodeService.getLandUseCode(env, businessId, cropPlanId, newLandUseCode, null, AbsoluteDate.of(decl.getFromDate().toLocalDate().plusYears(1)));
		} catch (LandUseCodeNotFoundException ex) {
			// land use code not found in the current year, skip this declaration
		}
		
		if (luc == null)
			return;
		
		if (!lucMap.containsKey(luc.getLandUseClass().getLandUseClassCode())) {
			var lucOption = cropPlansDAO.getLandUseClassOptions(env.getTenantId(), cropPlan.getCropPlanTypeCode(), List.of(luc.getLandUseClass().getLandUseClassCode()));
			lucMap.put(luc.getLandUseClass().getLandUseClassCode(), (lucOption.size() > 0 ? lucOption.get(0) : null));
		}
		
		var pcfs = decl.getPermanentCropForms().stream()
				.map(pcf -> new InsertPermanentCropForm(pcf.getFormType(), pcf.getPermanentCropFormData()))
				.collect(toList());
		
		// check if the old declaration has a to date > 31/10 then update it with the to date = 31/10
		this.checkAndUpdateToDate(decl, campaignStartDate, cropPlanId, currentDate, deleteDate, env, currentPlot, parcelCodes, previousCampaignEndDate, pcfs, bds);
		
		// copy the declaration with the new code										
		var newPointInTimeFrom = AbsoluteDate.of(decl.getFromDate().toLocalDate().plusYears(1));
		if (newPointInTimeFrom.isBefore(campaignStartDate))
			newPointInTimeFrom = campaignStartDate;
		var newPointInTimeTo = AbsoluteDate.of(decl.getToDate().toLocalDate().plusYears(1));
		if (newPointInTimeTo.isAfter(DEFAULT_END_DATE))
			newPointInTimeTo = DEFAULT_END_DATE; 
		if (!ignoreCropPlanConstraintsDeclsToPlots && newPointInTimeTo.isAfter(currentPlot.getToDate())) 
			newPointInTimeTo = currentPlot.getToDate();
		
		if (newPointInTimeTo.isAfter(newPointInTimeFrom)) {
			Long declId = cropPlansDAO.insertDeclaration(cropPlanId, currentPlot.getPlotCode(),
					newPointInTimeFrom, decl.getFromDatePrecision(), newPointInTimeTo, 
					luc.getCode(), decl.getAreaPerc(), pcfs, decl.getFieldsCodes(), env.getUserId(), currentDate, currentDate);
			
			bds.add(new ValidatorBoundedDeclaration(currentPlot.getPlotCode(), parcelCodes, declId, String.valueOf(declId),
					luc.getCode(), decl.getAreaPerc(),
					newPointInTimeFrom.toLocalDate(), newPointInTimeTo.toLocalDate(), decl.getFromDatePrecision(), ValidatorOperation.INSERT));
		}
	}

	protected void checkAndUpdateToDate(Declaration decl, AbsoluteDate campaignStartDate, Long cropPlanId, LocalDateTime currentDate, LocalDateTime deleteDate,
		RuntimeEnvironment env, Plot currentPlot, List<String> parcelCodes, AbsoluteDate previousCampaignEndDate, List<InsertPermanentCropForm> pcfs, ArrayList<ValidatorBoundedDeclaration> bds){
		if (decl.getToDate().isAfter(campaignStartDate) || decl.getToDate().equals(campaignStartDate)) {
			cropPlansDAO.deleteDeclaration(decl.getDeclCode(), cropPlanId, currentPlot.getPlotCode(), deleteDate, env.getUserId(), currentDate);	
			
			bds.add(new ValidatorBoundedDeclaration(currentPlot.getPlotCode(), parcelCodes, decl.getDeclId(), decl.getDeclCode(), 
					decl.getLanduse().getCode(), decl.getAreaPerc(),
					decl.getFromDate().toLocalDate(), decl.getToDate().toLocalDate(), decl.getFromDatePrecision(), ValidatorOperation.DELETE));
			
			Long declId = cropPlansDAO.insertDeclaration(cropPlanId, currentPlot.getPlotCode(),
					decl.getFromDate(), decl.getFromDatePrecision(), previousCampaignEndDate, 
					decl.getLanduse().getCode(), decl.getAreaPerc(), pcfs, decl.getFieldsCodes(), env.getUserId(), currentDate, currentDate);
			
			bds.add(new ValidatorBoundedDeclaration(currentPlot.getPlotCode(), parcelCodes, declId, String.valueOf(declId),
					decl.getLanduse().getCode(), decl.getAreaPerc(),
					decl.getFromDate().toLocalDate(), previousCampaignEndDate.toLocalDate(), decl.getFromDatePrecision(), ValidatorOperation.INSERT));
		}
	}

}
