package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "A pest entry")
public class InsertDeclPestPayload
{
	@Schema(description = "The pest code")
	@NotNull
	private String pestCode;	

	@Schema(description = "Percentage Area Affected by the Pest")
	private Long areaAffected;

	@Schema(description = "Plant protection measures applied")
	private String measuresApplied;

	@Schema(description = "The date")
	private AbsoluteDate date;
}
