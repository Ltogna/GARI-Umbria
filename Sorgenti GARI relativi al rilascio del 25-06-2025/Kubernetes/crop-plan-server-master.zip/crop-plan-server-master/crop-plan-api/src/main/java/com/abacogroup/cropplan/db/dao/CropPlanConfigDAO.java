package com.abacogroup.cropplan.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transaction;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.cropplan.db.dao.ntt.FunctionDisableConfig;
import com.abacogroup.cropplan.db.dao.ntt.PermanentCropFormConfigWithFields;
import com.abacogroup.cropplan.db.ntt.LandUseAdditionalDataConfNTT;
import com.abacogroup.cropplan.db.ntt.LandUseAdditionalDataFieldNTT;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.cropplan.sdk.model.CropPlanConfigData;
import com.abacogroup.jdbi.annotations.CacheDefinition;
import com.abacogroup.jdbi.annotations.Cached;
import com.abacogroup.jdbi.annotations.WeighterType;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface CropPlanConfigDAO extends BasicDAO, Transactional<CropPlanConfigDAO> {

	@Cached
	@CacheDefinition(maxWeight = 10000, expireAfterWriteMinutes = 15, weighterType = WeighterType.ELEMENT_SIZE)
	@SqlQuery("select param_name as paramName, param_value as paramValue"
			+ "      from crpl_config cc, crpl_plans cp"
			+ "     where cp.id = :cropPlanId"
			+ "       and cc.type_id = cp.type_id"
			+ "       and (:paramName is null or param_name = :paramName)"
			+ "       and (:paramValue is null or param_value = :paramValue)")
	@RegisterBeanMapper(CropPlanConfigData.class)
	public List<CropPlanConfigData> getCropPlanConfig(
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("paramName") String paramName,
			@Bind("paramValue") String paramValue);

	@Transaction
	default void copyTenant(String fromTenantId, String toTenantId) {
		// TODO !!! SIMONE !!! verificare di gestire tutte le tabelle
		useHandle(h -> {
			h.createUpdate("insert into crpl_types (code, fl_multiple, id, tenant_id, fl_limit_to_canvas, fl_split_on_canvas, day_from, day_to, dt_insert, dt_delete)"
					+ "         select code, fl_multiple, §nextval(crpl_types_seq)§, :toTenantId, fl_limit_to_canvas, fl_split_on_canvas, day_from, day_to, §current_timestamp§, to_date('99991231','YYYYMMDD')"
					+ "           from crpl_types"
					+ "          where tenant_id = :fromTenantId"
					+ "            and §current_timestamp§ between dt_insert and dt_delete")
					.bind("fromTenantId", fromTenantId)
					.bind("toTenantId", toTenantId)
					.execute();

			h.createUpdate("insert into crpl_config (type_id, param_name, param_value)"
					+ "         select (select ct1.id from crpl_types ct1 where ct1.tenant_id = :toTenantId and ct1.code = ct.code and §current_timestamp§ between ct1.dt_insert and ct1.dt_delete), cc.param_name, cc.param_value"
					+ "           from crpl_config cc, crpl_types ct"
					+ "          where ct.id = cc.type_id"
					+ "            and ct.tenant_id = :fromTenantId"
					+ "            and §current_timestamp§ between ct.dt_insert and ct.dt_delete")
					.bind("fromTenantId", fromTenantId)
					.bind("toTenantId", toTenantId)
					.execute();

			h.createUpdate("insert into crpl_perm_crop_field_values (type_id, form_type, field_code, field_value, i18n_value)"
					+ "         select (select ct1.id from crpl_types ct1 where ct1.tenant_id = :toTenantId and ct1.code = ct.code and §current_timestamp§ between ct1.dt_insert and ct1.dt_delete), cpcfv.form_type, cpcfv.field_code, cpcfv.field_value, cpcfv.i18n_value"
					+ "           from crpl_perm_crop_field_values cpcfv, crpl_types ct"
					+ "          where ct.id = cpcfv.type_id"
					+ "            and ct.tenant_id = :fromTenantId"
					+ "            and §current_timestamp§ between ct.dt_insert and ct.dt_delete")
					.bind("fromTenantId", fromTenantId)
					.bind("toTenantId", toTenantId)
					.execute();

			h.createUpdate("insert into i18n_values (table_name, field_name, i18n_value, lang, i18n_text, tenant_id)"
					+ "         select table_name, field_name, i18n_value, lang, i18n_text, :toTenantId"
					+ "           from i18n_values"
					+ "          where tenant_id = :fromTenantId")
					.bind("fromTenantId", fromTenantId)
					.bind("toTenantId", toTenantId)
					.execute();
		});
	}

	@Cached
	@CacheDefinition(maxWeight = 100, expireAfterWriteMinutes = 60)
	@SqlQuery("SELECT ID FROM CRPL_TYPES WHERE CODE = :code AND TENANT_ID = :tenantId and §current_timestamp§ between dt_insert and dt_delete")
	public Long getCropPlanTypeId(@Bind("code") String code, @Bind("tenantId") String tenantId);

	@SqlUpdate("INSERT INTO CRPL_CONFIG (PARAM_NAME, PARAM_VALUE, TYPE_ID) "
			+ "     VALUES (:paramName, :paramValue, :typeId)")
	public void insertCropPlanConfig(@Bind("paramName") String paramName, @Bind("paramValue") String paramValue,
			@Bind("typeId") Long typeId);

	@SqlUpdate("DELETE FROM CRPL_CONFIG WHERE PARAM_NAME = :paramName AND TYPE_ID = :typeId")
	public void deleteCropPlanConfig(@Bind("paramName") String paramName, @Bind("typeId") Long typeId);

	@SqlUpdate("INSERT INTO CRPL_PRINTS (PRINT_CODE, TYPE_ID) VALUES (:code, :typeId)")
	public void insertCropPlanPrint(@Bind("code") String code, @Bind("typeId") Long typeId);

	@SqlUpdate("DELETE FROM CRPL_PRINTS WHERE PRINT_CODE = :code AND TYPE_ID = :typeId")
	public void deleteCropPlanPrint(@Bind("code") String code, @Bind("typeId") Long typeId);

	@SqlUpdate("INSERT INTO CRPL_PRINTS_PARAMS (TYPE_ID, PRINT_CODE, PARAM_NAME, PARAM_VALUE) VALUES (:typeId, :printCode, :paramName, :paramValue)")
	void insertCropPlanPrintParam(@Bind("typeId") Long typeId, @Bind("printCode") String printCode, @Bind("paramName") String paramName,
			@Bind("paramValue") String paramValue);

	@SqlUpdate("DELETE FROM CRPL_PRINTS_PARAMS WHERE PRINT_CODE = :printCode AND TYPE_ID = :typeId")
	void deleteCropPlanPrintParamByTypeAndCode(@Bind("typeId") Long typeId, @Bind("printCode") String printCode);

	@SqlUpdate("DELETE FROM CRPL_PRINTS_PARAMS WHERE PRINT_CODE = :printCode AND TYPE_ID = :typeId AND PARAM_NAME = :paramName")
	void deleteCropPlanPrintParamByTypeAndCodeAndParamName(@Bind("typeId") Long typeId, @Bind("printCode") String printCode,
			@Bind("paramName") String paramName);

	@SqlQuery("SELECT I18N_VALUE"
			+ "      FROM CRPL_PERM_CROP_FIELD_VALUES"
			+ "     WHERE FORM_TYPE = :formType"
			+ "       AND FIELD_CODE = :fieldCode"
			+ "       AND FIELD_VALUE = :fieldValue"
			+ "       AND TYPE_ID = :typeId")
	public String getI18nValue(@Bind("formType") String formType, @Bind("fieldCode") String fieldCode,
			@Bind("fieldValue") String fieldValue, @Bind("typeId") Long typeId);

	@SqlQuery("SELECT COUNT(*)"
			+ "      FROM CRPL_PERM_CROP_FIELD_VALUES"
			+ "     WHERE I18N_VALUE = :i18nValue"
			+ "       AND TYPE_ID = :typeId")
	public int countI18nValues(@Bind("i18nValue") String i18nValue, @Bind("typeId") Long typeId);

	@SqlUpdate("INSERT INTO CRPL_PERM_CROP_FIELD_VALUES (FORM_TYPE, FIELD_CODE, FIELD_VALUE, I18N_VALUE, TYPE_ID)"
			+ "     VALUES (:formType, :fieldCode, :fieldValue, :i18nValue, :typeId)")
	public void insertFieldValue(@Bind("formType") String formType, @Bind("fieldCode") String fieldCode,
			@Bind("fieldValue") String fieldValue, @Bind("i18nValue") String i18nValue, @Bind("typeId") Long typeId);

	@SqlUpdate("DELETE FROM CRPL_PERM_CROP_FIELD_VALUES"
			+ "      WHERE FORM_TYPE = :formType"
			+ "        AND FIELD_CODE = :fieldCode"
			+ "        AND FIELD_VALUE = :fieldValue"
			+ "        AND TYPE_ID = :typeId")
	public void deleteFieldValue(@Bind("formType") String formType, @Bind("fieldCode") String fieldCode,
			@Bind("fieldValue") String fieldValue, @Bind("typeId") Long typeId);

	@SqlUpdate("INSERT INTO I18N_VALUES (TABLE_NAME, FIELD_NAME, I18N_VALUE, LANG, I18N_TEXT, TENANT_ID)"
			+ "     VALUES (:tableName, :fieldName, :i18nValue, :lang, :i18nText, :tenantId)")
	public void insertI18nValue(@Bind("tableName") String tableName, @Bind("fieldName") String fieldName,
			@Bind("i18nValue") String i18nValue, @Bind("lang") String lang, @Bind("i18nText") String i18nText,
			@Bind("tenantId") String tenantId);

	@SqlUpdate("DELETE FROM I18N_VALUES"
			+ "      WHERE TABLE_NAME = :tableName"
			+ "        AND FIELD_NAME = :fieldName"
			+ "        AND I18N_VALUE = :i18nValue"
			+ "        AND (:lang IS NULL OR LANG = :lang)"
			+ "        AND TENANT_ID = :tenantId")
	public void deleteI18nValue(@Bind("tableName") String tableName, @Bind("fieldName") String fieldName,
			@Bind("i18nValue") String i18nValue, @Bind("lang") String lang, @Bind("tenantId") String tenantId);

	@SqlQuery("select count(*) from crpl_types where code = :code and tenant_id = :tenantId")
	public int countCrplTypes(@Bind("code") String code, @Bind("tenantId") String tenantId);

	@SqlUpdate("insert into crpl_types (code, fl_multiple, fl_limit_to_canvas, fl_split_on_canvas, id, day_from, day_to, tenant_id, dt_insert, dt_delete) "
			+ "     values (:code, :flMultiple, :flLimitToCanvas, :flSplitOnCanvas, §nextval(crpl_types_seq)§, :dayFrom, :dayTo, :tenantId, §current_timestamp§, to_date('99991231','YYYYMMDD'))")
	public void insertCropPlanType(@Bind("code") String code, @Bind("flMultiple") Integer flMultiple,
			@Bind("flLimitToCanvas") Integer flLimitToCanvas, @Bind("flSplitOnCanvas") Integer flSplitOnCanvas,
			@Bind("dayFrom") AbsoluteDate dayFrom, @Bind("dayTo") AbsoluteDate dayTo,
			@Bind("tenantId") String tenantId);

	@SqlUpdate("update crpl_types set fl_multiple = :flMultiple, fl_limit_to_canvas = :flLimitToCanvas, fl_split_on_canvas = :flSplitOnCanvas, "
			   + " day_from = :dayFrom, day_to = :dayTo, dt_delete = to_date('99991231','YYYYMMDD') "
			+ "      where code = :code and tenant_id = :tenantId")
	public void updateCropPlanType(@Bind("code") String code, @Bind("flMultiple") Integer flMultiple,
			@Bind("flLimitToCanvas") Integer flLimitToCanvas, @Bind("flSplitOnCanvas") Integer flSplitOnCanvas,
			@Bind("dayFrom") AbsoluteDate dayFrom, @Bind("dayTo") AbsoluteDate dayTo,
			@Bind("tenantId") String tenantId);

	@SqlUpdate("update crpl_types set dt_delete = §current_timestamp§"
			+ "      where code = :code and tenant_id = :tenantId")
	public void expireCropPlanType(@Bind("code") String code, @Bind("tenantId") String tenantId);

	@SqlUpdate("delete from crpl_land_use_class_options where type_id = :type and land_use_class_code = :landUseClass")
	public void deleteLandUseClassOption(@Bind("type") Long cropPlanType, @Bind("landUseClass") String landUseClass);

	@SqlUpdate("insert into crpl_land_use_class_options (type_id, land_use_class_code, perc_fixed_to_100, permanent) "
			+ " values (:type, :landUseClass, :percFixedTo100, :permanent)")
	public void insertLandUseClassOption(@Bind("type") Long cropPlanType, @Bind("landUseClass") String landUseClass,
			@Bind("percFixedTo100") Integer percFixedTo100, @Bind("permanent") Integer permanent);

	@Transaction
	default void deletePermCropFormsConfig(String formType, Long typeId, String landUseCode, String landUseClassCode,
			AbsoluteDate validFrom, AbsoluteDate validTo) {
		internalDeletePermCropFormsFieldsConfig(formType, typeId, landUseCode, landUseClassCode, validFrom, validTo);
		internalDeletePermCropFormsConfig(formType, typeId, landUseCode, landUseClassCode, validFrom, validTo);
	}

	@SqlUpdate("DELETE FROM crpl_perm_crop_forms_fields_cfg WHERE PERM_CROP_FORMS_CFG_ID in"
			   + "  (select ID FROM crpl_perm_crop_forms_cfg WHERE FORM_TYPE = :formType AND TYPE_ID = :typeId"
			   + "    AND (land_use_code = coalesce(:landUseCode, land_use_code) or (:landUseCode is null and land_use_code is null))"
			   + "    AND (land_use_class_code = coalesce(:landUseClassCode, land_use_class_code) or (:landUseClassCode is null and land_use_class_code is null)) "
			   + "    and valid_to >= :validFrom "
			   + "    and valid_from <= :validTo "
			   + ")")
	public void internalDeletePermCropFormsFieldsConfig(@Bind("formType") String formType, @Bind("typeId") Long typeId,
			@Bind("landUseCode") String landUseCode, @Bind("landUseClassCode") String landUseClassCode,
			@Bind("validFrom") AbsoluteDate validFrom, @Bind("validTo") AbsoluteDate validTo);

	@SqlUpdate("DELETE FROM crpl_perm_crop_forms_cfg WHERE FORM_TYPE = :formType AND TYPE_ID = :typeId"
			   + "  AND (land_use_code = coalesce(:landUseCode, land_use_code) or (:landUseCode is null and land_use_code is null))"
			   + "  AND (land_use_class_code = coalesce(:landUseClassCode, land_use_class_code) or (:landUseClassCode is null and land_use_class_code is null)) "
			   + "  and valid_to >= :validFrom "
			   + "  and valid_from <= :validTo ")
	public void internalDeletePermCropFormsConfig(@Bind("formType") String formType, @Bind("typeId") Long typeId,
			@Bind("landUseCode") String landUseCode, @Bind("landUseClassCode") String landUseClassCode,
			@Bind("validFrom") AbsoluteDate validFrom, @Bind("validTo") AbsoluteDate validTo);

	@SqlUpdate("update crpl_perm_crop_forms_cfg "
			   + "set valid_to = :newValidTo "
			   + "WHERE FORM_TYPE = :formType AND TYPE_ID = :typeId "
			   + "  AND (land_use_code = coalesce(:landUseCode, land_use_code) or (:landUseCode is null and land_use_code is null))"
			   + "  AND (land_use_class_code = coalesce(:landUseClassCode, land_use_class_code) or (:landUseClassCode is null and land_use_class_code is null)) "
			   + "  and valid_to >= :validFrom "
			   + "  and valid_from <= :validTo "
			   + "  and valid_from <= :newValidTo "
			   + "  and valid_to >= :newValidTo ")
	public void updatePermCropFormsConfigDates(@Bind("formType") String formType, @Bind("typeId") Long typeId,
			@Bind("landUseCode") String landUseCode, @Bind("landUseClassCode") String landUseClassCode,
			@Bind("validFrom") AbsoluteDate validFrom, @Bind("validTo") AbsoluteDate validTo, @Bind("newValidTo") AbsoluteDate newValidTo);

	@SqlQuery("§select_nextval(crpl_perm_crop_forms_cfg_seq)§")
	public Long getPermCropFormsConfigSeq();

	@SqlUpdate("insert into crpl_perm_crop_forms_cfg (id, form_type, type_id, land_use_code, land_use_class_code, valid_from, valid_to) "
			+ " values (:id, :formType, :typeId, :landUseCode, :landUseClassCode, :validFrom, :validTo)")
	public void insertPermCropFormsConfig(@Bind("id") Long id, @Bind("formType") String formType, @Bind("typeId") Long typeId,
			@Bind("landUseCode") String landUseCode, @Bind("landUseClassCode") String landUseClassCode,
			@Bind("validFrom") AbsoluteDate validFrom, @Bind("validTo") AbsoluteDate validTo);

	@SqlUpdate("insert into crpl_perm_crop_forms_fields_cfg (PERM_CROP_FORMS_CFG_ID, FIELD_CODE, FL_MANDATORY, FL_EDITABLE) "
			+ " values (:id, :fieldCode, :flMandatory, :flEditable)")
	public void insertPermCropFormsFieldConfig(@Bind("id") Long id, @Bind("fieldCode") String fieldCode,
			@Bind("flMandatory") Integer flMandatory, @Bind("flEditable") Integer flEditable);

	/* ************************************************** */
	/* * Additional landcover declarations fields * */
	/* ************************************************** */

	@SqlQuery("§select_nextval(crpl_landuse_addit_fields_seq)§")
	public Long getLanduseAdditFieldsSeq();

	@SqlQuery("§select_nextval(crpl_landuse_adt_flds_val_seq)§")
	public Long getLanduseAdtFldsValSeq();

	@SqlUpdate(""
			+ "insert into crpl_landuse_addit_fields \n"
			+ "(id, field_code, field_type, "
			+ " valid_from, valid_to, "
			+ " display_order, nullable, "
			+ " dt_insert, dt_delete, user_id_insert, user_id_delete, tenant_id, fl_show_in_tooltip, group_code, header_title_code, fl_editable, formula) \n"
			+ "values("
			+ " :fc.id, :fc.fieldCode, :fc.fieldType, "
			+ " :fc.validFrom, :fc.validTo, "
			+ " :fc.displayOrder, :fc.nullable, "
			+ " §current_timestamp§, TO_TIMESTAMP('9999-12-31 23:59:59', 'YYYY-MM-DD HH24:mi:ss'), "
			+ " :userId, NULL, :tenantId, :fc.flShowInTooltip, :fc.groupCode, :fc.headerTitleCode, :fc.flEditable, :fc.formula) \n"
			+ "")
	public void insertDeclAdditFieldConf(
			@BindBean("fc") LandUseAdditionalDataConfNTT fc,
			@Bind("userId") String userId,
			@Bind("tenantId") String tenantId);

	@SqlUpdate("update crpl_landuse_addit_fields \n"
			+ "   set dt_delete = §current_timestamp§, user_id_delete = :userId \n"
			+ " where field_code = :fieldCode \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n"
			+ "   and tenant_id = :tenantId \n"
			+ "")
	public int outdateDeclAdditFieldsConf(
			@Bind("fieldCode") String fieldCode,
			@Bind("userId") String userId,
			@Bind("tenantId") String tenantId);

	@SqlQuery("select id, field_code, field_type, valid_from, valid_to, "
			  + " display_order, nullable, fl_show_in_tooltip, group_code, header_title_code, fl_editable, formula, "
			  + " dt_insert, dt_delete, user_id_insert, user_id_delete, tenant_id "
			  + " from crpl_landuse_addit_fields "
			  + " where  field_code = :fieldCode "
			  + "   and §current_timestamp§ between dt_insert and dt_delete "
			  + "   and :deleteFrom between valid_from and valid_to "
			  + "   and tenant_id = :tenantId ")
	@RegisterBeanMapper(LandUseAdditionalDataConfNTT.class)
	LandUseAdditionalDataConfNTT getDeclAdditFieldsConf(
			@Bind("fieldCode") String fieldCode,
			@Bind("tenantId") String tenantId,
			@Bind("deleteFrom") AbsoluteDate deleteFrom);

	@SqlUpdate("INSERT INTO crpl_landuse_addit_fields_cfg (config_id, land_use_code, nullable, dt_insert, dt_delete, user_id_insert, user_id_delete) "
			   + "VALUES (:configId, :landUseCode, :nullable, "
			   + "§current_timestamp§, TO_TIMESTAMP('9999-12-31 23:59:59', 'YYYY-MM-DD HH24:mi:ss'), :userId, NULL)")
	void insertDeclAdditFieldLucConf(
			@Bind("configId") Long configId,
			@Bind("landUseCode") String landUseCode,
			@Bind("nullable") Integer nullable,
			@Bind("userId") String userId
	);

	@SqlUpdate("update crpl_landuse_addit_fields_cfg "
			+ "   set dt_delete = §current_timestamp§, user_id_delete = :userId "
			+ " where config_id = :configId and land_use_code = :landUseCode "
			+ "   and §current_timestamp§ between dt_insert and dt_delete ")
	int expireDeclAdditFieldLucConf(
			@Bind("configId") Long configId,
			@Bind("landUseCode") String landUseCode,
			@Bind("userId") String userId
	);

	@SqlQuery("select id, land_use_code_filter as landUseCode, field_code as fieldCode, "
			+ "       valid_from as validFrom, valid_to as validTo, display_order as displayOrder, allowed_value as allowedValue, fl_default as flDefault \n"
			+ " from crpl_landuse_addit_fields_val \n"
			+ " where land_use_code_filter = :landUseCode \n"
			+ "   and field_code = :fieldCode \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n"
			+ "   and :deleteFrom between valid_from and valid_to\n"
			+ "   and tenant_id = :tenantId \n"
			+ "")
	@RegisterBeanMapper(LandUseAdditionalDataFieldNTT.class)
	public List<LandUseAdditionalDataFieldNTT> getRecordListToBeReinserted(
			@Bind("landUseCode") String landUseCode,
			@Bind("fieldCode") String fieldCode,
			@Bind("tenantId") String tenantId,
			@Bind("deleteFrom") AbsoluteDate deleteFrom);

	@SqlUpdate(""
			+ "insert into crpl_landuse_addit_fields_val \n"
			+ "(id, land_use_code_filter, field_code, "
			+ " valid_from, valid_to, display_order, allowed_value, "
			+ " dt_insert, dt_delete, user_id_insert, user_id_delete, "
			+ " fl_default, tenant_id) \n"
			+ "values("
			+ " :av.id, :av.landUseCode, :av.fieldCode, "
			+ " :av.validFrom, :av.validTo, :av.displayOrder, :av.allowedValue, "
			+ " §current_timestamp§, TO_TIMESTAMP('9999-12-31 23:59:59', 'YYYY-MM-DD HH24:mi:ss'), :userId, NULL,"
			+ " :av.flDefault, :tenantId) \n"
			+ "")
	public void insertDeclAdditFieldAlloewdVal(
			@BindBean("av") LandUseAdditionalDataFieldNTT av,
			@Bind("userId") String userId,
			@Bind("tenantId") String tenantId);

	@SqlUpdate("update crpl_landuse_addit_fields_val \n"
			+ "   set dt_delete = §current_timestamp§, user_id_delete = :userId \n"
			+ " where land_use_code_filter = :landUseCode \n"
			+ "   and field_code = :fieldCode \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n"
			+ "   and tenant_id = :tenantId \n"
			+ "")
	public int outdateDeclAdditFieldsAllowedVal(
			@Bind("landUseCode") String landUseCode,
			@Bind("fieldCode") String fieldCode,
			@Bind("userId") String userId,
			@Bind("tenantId") String tenantId);

	@SqlUpdate("update crpl_landuse_addit_fields_val \n"
			   + "   set dt_delete = §current_timestamp§, user_id_delete = :userId \n"
			   + " where land_use_code_filter = :landUseCode \n"
			   + "   and field_code = :fieldCode \n"
			   + "   and allowed_value = :allowedValue "
			   + "   and §current_timestamp§ between dt_insert and dt_delete \n"
			   + "   and valid_to >= :validFrom "
			   + "   and valid_from <= :validTo "
			   + "   and tenant_id = :tenantId \n")
	public int outdateDeclAdditFieldsAllowedValInRange(
			@Bind("landUseCode") String landUseCode,
			@Bind("fieldCode") String fieldCode,
			@Bind("allowedValue") String allowedValue,
			@Bind("validFrom") AbsoluteDate validFrom,
			@Bind("validTo") AbsoluteDate validTo,
			@Bind("userId") String userId,
			@Bind("tenantId") String tenantId);

	@SqlUpdate("update crpl_landuse_addit_fields_val \n"
			+ "   set dt_delete = §current_timestamp§, user_id_delete = :userId \n"
			+ " where field_code = :fieldCode \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n"
			+ "   and tenant_id = :tenantId \n"
			+ "")
	public int outdateDeclAdditFieldsAllowedValForFieldCode(
			@Bind("fieldCode") String fieldCode,
			@Bind("userId") String userId,
			@Bind("tenantId") String tenantId);

	@SqlUpdate("update crpl_landuse_addit_fields_val \n"
			+ "   set dt_delete = §current_timestamp§, user_id_delete = :userId \n"
			+ " where land_use_code_filter = :landUseCode \n"
			+ "   and field_code = :fieldCode \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n"
			+ "   and (:deleteFrom between valid_from and valid_to or \n"
			+ "        valid_from >= :deleteFrom) \n"
			+ "   and tenant_id = :tenantId \n"
			+ "")
	public int outdateDeclAdditFieldsAllowedValForDeleteFrom(
			@Bind("landUseCode") String landUseCode,
			@Bind("fieldCode") String fieldCode,
			@Bind("userId") String userId,
			@Bind("tenantId") String tenantId,
			@Bind("deleteFrom") AbsoluteDate deleteFrom);

	/* *********************************************************** */
	/* * Anomalies Scenario Disable Function Configuration * */
	/* *********************************************************** */
	@SqlQuery("select SCENARIO as scenario, "
			+ "       DISABLED_FUNCTION_CODE as functionCode "
			+ "     from CRPL_ANOM_SCENARIO_DISABLED_FUNC_CFG func_cfg "
			+ "     where "
			+ "       func_cfg.DISABLED_FUNCTION_CODE = :functionCode "
			+ "       AND func_cfg.SCENARIO = :scenario "
			+ "       AND func_cfg.TYPE_ID = :typeId ")
	@RegisterBeanMapper(FunctionDisableConfig.class)
	public List<FunctionDisableConfig> getScenarioDisabledFunctionConfig(@Bind("typeId") Long typeId, @Bind("functionCode") String functionCode,
			@Bind("scenario") String scenario);

	@SqlUpdate("delete from CRPL_ANOM_SCENARIO_DISABLED_FUNC_CFG func_cfg where func_cfg.SCENARIO = :scenario AND func_cfg.TYPE_ID = :typeId")
	public void deleteScenarioDisabledFunctionConfig(@Bind("typeId") Long typeId, @Bind("scenario") String scenario);

	@SqlUpdate(""
			+ "insert into CRPL_ANOM_SCENARIO_DISABLED_FUNC_CFG "
			+ "(SCENARIO, DISABLED_FUNCTION_CODE, TYPE_ID "
			+ " ) \n"
			+ "values("
			+ " :scenario, :functionCode, :typeId "
			+ " ) \n")
	public void insertScenarioDisabledFunctionConfig(@Bind("typeId") Long typeId, @Bind("functionCode") String functionCoded,
			@Bind("scenario") String scenario);

	@SqlQuery("select SCENARIO as scenario, "
			+ "       ERROR_CODE as anomaliyCode, "
			+ "       FL_PRESENT as anomaliyPresent "
			+ "     from CRPL_ANOM_SCENARIO_CFG sc_cfg "
			+ "     where "
			+ "       sc_cfg.ERROR_CODE = :anomaliyCode "
			+ "       AND sc_cfg.SCENARIO = :scenario "
			+ "       AND sc_cfg.TYPE_ID = :typeId ")
	@RegisterBeanMapper(FunctionDisableConfig.class)
	public List<FunctionDisableConfig> getAnomalyScenarioConfig(@Bind("typeId") Long typeId, @Bind("anomaliyCode") String anomaliyCode,
			@Bind("scenario") String scenario);

	@SqlUpdate("delete from CRPL_ANOM_SCENARIO_CFG sc_cfg where sc_cfg.SCENARIO = :scenario AND sc_cfg.TYPE_ID = :typeId")
	public void deleteAnomalyScenarioConfig(@Bind("typeId") Long typeId, @Bind("scenario") String scenario);

	@SqlUpdate(""
			+ "insert into CRPL_ANOM_SCENARIO_CFG "
			+ "(SCENARIO, ERROR_CODE, FL_PRESENT, TYPE_ID "
			+ " ) \n"
			+ "values("
			+ " :scenario, :anomaliyCode, :anomaliyPresent, :typeId "
			+ " ) \n")
	public void insertAnomalyScenarioConfig(@Bind("typeId") Long typeId, @Bind("anomaliyCode") String anomaliyCode, @Bind("scenario") String scenario,
			@Bind("anomaliyPresent") Integer anomaliyPresent);

	@Cached
	@CacheDefinition(maxWeight = 1000, expireAfterWriteMinutes = 60)
	@SqlQuery("select \n"
			+ " t.land_use_code AS land_use_code,\n"
			+ " t.land_use_class_code AS land_use_class_code,\n"
			+ " t.id as perm_crop_forms_cfg_id,\n"
			+ " t.formType as formType,\n"
			+ " crpl_cfg.field_code as fieldCode,\n"
			+ " crpl_cfg.fl_mandatory as flMandatory,\n"
			+ " crpl_cfg.fl_editable as flEditable\n"
			+ "FROM \n"
			+ "(\n"
			+ " SELECT q.id as id,\n"
			+ "        q.formType as formType,\n"
			+ "        q.land_use_class_code AS land_use_class_code, \n"
			+ "        q.land_use_code AS land_use_code\n"
			+ " FROM (\n"
			+ "   select pcfc.id as id,\n"
			+ "          pcfc.form_type as formType,\n"
			+ "          pcfc.land_use_class_code AS land_use_class_code,\n"
			+ "          pcfc.land_use_code AS land_use_code\n"
			+ "     from crpl_perm_crop_forms_cfg pcfc, crpl_types ct\n"
			+ "    where ct.code = :cropPlanTypeCode\n"
			+ "          and ct.tenant_id = :tenantId\n"
			+ "          and pcfc.type_id = ct.id\n"
			+ "          and pcfc.land_use_code in (<landUseCodes>)\n"
			  + "        and :pointInTime between pcfc.valid_from and pcfc.valid_to\n"
			+ " ) q\n"
			+ " UNION ALL \n"
			+ " SELECT qt.id as id,\n"
			+ "        qt.formType as formType,\n"
			+ "        qt.land_use_class_code AS land_use_class_code,  \n"
			+ "        qt.land_use_code AS land_use_code\n"
			+ " FROM (\n"
			+ "   select pcfc.id as id,\n"
			+ "          pcfc.form_type as formType,\n"
			+ "          pcfc.land_use_class_code AS land_use_class_code, \n"
			+ "          pcfc.land_use_code AS land_use_code\n"
			+ "     from crpl_perm_crop_forms_cfg pcfc, crpl_types ct\n"
			+ "    where ct.code = :cropPlanTypeCode  \n"
			+ "      and ct.tenant_id = :tenantId \n"
			+ "      and pcfc.type_id = ct.id\n"
			+ "      and pcfc.land_use_class_code in (<landUseClassCodes>)\n"
			+ "      and :pointInTime between pcfc.valid_from and pcfc.valid_to\n"
			+ " ) qt \n"
			+ ") t\n"
			+ "LEFT JOIN crpl_perm_crop_forms_fields_cfg crpl_cfg ON crpl_cfg.perm_crop_forms_cfg_id = t.id")
	@RegisterBeanMapper(PermanentCropFormConfigWithFields.class)
	public List<PermanentCropFormConfigWithFields> getPermanentCropFormsConfigByLandUseCodeAndByLandUseClassCode(@Bind("tenantId") String tenantId,
			@Bind("cropPlanTypeCode") String cropPlanTypeCode,
			@BindList("landUseCodes") List<String> landUseCodes,
			@BindList("landUseClassCodes") List<String> landUseClassCodes,
			@Bind("pointInTime") AbsoluteDate pointInTime);

	@SqlQuery("select sc_cfg.SCENARIO as scenario, \n"
			+ "       func_cfg.DISABLED_FUNCTION_CODE as functionCode, \n"
			+ "       sc_cfg.ERROR_CODE as anomaliyCode, \n"
			+ "       MIN(sc_cfg.FL_PRESENT) as anomaliyPresent \n"
			+ "      from CRPL_ANOM_SCENARIO_CFG sc_cfg, CRPL_ANOM_SCENARIO_DISABLED_FUNC_CFG func_cfg \n"
			+ "     where sc_cfg.SCENARIO = func_cfg.scenario \n"
			+ "       and sc_cfg.TYPE_ID = func_cfg.TYPE_ID \n"
			+ "       and (:typeId is NULL or func_cfg.TYPE_ID = :typeId) \n"
			+ "       and (:functionCode is NULL or func_cfg.DISABLED_FUNCTION_CODE = :functionCode) "
			+ "     GROUP BY sc_cfg.SCENARIO,func_cfg.DISABLED_FUNCTION_CODE,sc_cfg.ERROR_CODE\n"
			+ "     order by sc_cfg.SCENARIO,functionCode,anomaliyCode")
	@RegisterBeanMapper(FunctionDisableConfig.class)
	public List<FunctionDisableConfig> getScenarioAnomailesDisableFunctionConfig(@Bind("functionCode") String functionCode, @Bind("typeId") Long typeId);
}
