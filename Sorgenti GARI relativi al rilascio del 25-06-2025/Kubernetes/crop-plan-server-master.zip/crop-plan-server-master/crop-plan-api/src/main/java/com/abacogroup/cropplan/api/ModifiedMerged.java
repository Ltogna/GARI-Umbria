package com.abacogroup.cropplan.api;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ModifiedMerged {
	private Map<String, List<String>> mergedPlots;
	private boolean preserveDeclarations;
}
