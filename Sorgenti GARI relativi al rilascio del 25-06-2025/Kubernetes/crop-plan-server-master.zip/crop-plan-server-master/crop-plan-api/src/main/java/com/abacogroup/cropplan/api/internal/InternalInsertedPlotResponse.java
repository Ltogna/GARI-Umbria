package com.abacogroup.cropplan.api.internal;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "An internal insert plot response")
public class InternalInsertedPlotResponse {
	
	@Schema(description = "The inserted plot code")
	@NotNull
	private String plotCode;
	
	@Schema(description = "The list of the inserted declarations")
	private List<InternalInsertedDeclaration> declarations;
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Schema(description = "An internal inserted declaration")
	public static class InternalInsertedDeclaration {
		
		@Schema(description = "The inserted declaration code")
		@NotNull
		private String declCode;
		
		@Schema(description = "The external declaration code")
		private String externalCode;
	}
}
