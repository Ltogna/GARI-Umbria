package com.abacogroup.cropplan.services;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import com.abacogroup.cropplan.api.ChangedPlot;
import com.abacogroup.cropplan.api.CropPlanType;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.payload.CreateCropPlanPayload;
import com.abacogroup.cropplan.api.payload.GetPermanentCropFormSubscriptionsPayload;
import com.abacogroup.cropplan.api.payload.ParcelDataPayload;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDeleteAndRestoreOperationsDAO;
import com.abacogroup.cropplan.exceptions.CropPlanNotCreateableException;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.CropPlanConfigData;
import com.abacogroup.cropplan.sdk.model.CropPlanVersion;
import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormFieldCodes;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormFieldValue;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormSubscription;
import com.abacogroup.cropplan.sdk.model.PlotTimeline;
import com.abacogroup.cropplan.sdk.model.Version;
import com.abacogroup.cropplan.sdk.model.auth.CropPlanTypeAccessLevel;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandCoverClassEditability;
import com.abacogroup.cropplan.sdk.model.domain.DomainZoneGeometry;
import com.abacogroup.cropplan.services.support.PlotTimeWindowParams;
import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.NotAllowedException;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class BaseCropPlanService {
	private final PluginManager pluginManager;

	private final CropPlansDAO cropPlansDAO;
	private final CropPlanConfigDAO cropPlanConfigDAO;
	private final CropPlansDeleteAndRestoreOperationsDAO cropPlansDeleteAndRestoreOperationsDAO;

	private static final int CHANGED_PLOT_AREA_TOLERANCE = 1;

	public CropPlanTypeAccessLevel getAccessLevel(RuntimeEnvironment env, String businessId, String cropPlanTypeCode) {
		return pluginManager.getAuthPlugin().getCropPlanTypeAccessLevel(env, businessId, cropPlanTypeCode);
	}

	public boolean isPlotLandCoverEditable(RuntimeEnvironment env, String businessId, Long cropPlanId, Plot plot) {
		var cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId());

		Map<String, LandCoverClassEditability> editabilities = new HashMap<>();
		if (!plot.getParcelIntersections().isEmpty()) {
			for (var parcel : plot.getParcelIntersections()) {
				var editability = editabilities.get(parcel.getLandCoverCode());
				if (editability == null) {
					editability = cropCodesPlugin.getLandCoverEditability(env, businessId, parcel.getLandCoverCode());
					editabilities.put(parcel.getLandCoverCode(), editability);
				}
				if (editability == LandCoverClassEditability.NOT_EDITABLE)
					return false;
			}
		}

		return cropCodesPlugin.getLandCoverEditability(env, businessId, null) != LandCoverClassEditability.NOT_EDITABLE;
	}

	public boolean isLandCoverEditable(RuntimeEnvironment env, String businessId, Long cropPlanId, String landCoverCode) {
		var cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId());

		var editability = cropCodesPlugin.getLandCoverEditability(env, businessId, landCoverCode);
		return editability != LandCoverClassEditability.NOT_EDITABLE;
	}

	public List<CropPlanType> getCropPlanTypes(RuntimeEnvironment env) {
		return this.cropPlansDAO.getCropPlanTypes(env.getTenantId(), env.getLocale().getLanguage());
	}

	public CropPlanType getCropPlanType(RuntimeEnvironment env, String type) {
		return this.cropPlansDAO.getCropPlanType(type, env.getTenantId(), env.getLocale().getLanguage());
	}

	public Long insertCropPlan(RuntimeEnvironment env, String businessId, CreateCropPlanPayload payload) {
		var accessLevel = getAccessLevel(env, businessId, payload.getCropPlanTypeCode());
		if (!accessLevel.canCreate())
			throw new CropPlanNotCreateableException(accessLevel.getMessageCode());

		var cropPlanType = cropPlansDAO.getCropPlanType(payload.getCropPlanTypeCode(), env.getTenantId(), env.getLocale().getLanguage());
		if (cropPlanType == null)
			throw new BadRequestException("The crop plan type specified does not exist");

		if (!cropPlanType.getMultiple()) {
			var numCropPlans = cropPlansDAO.countCropPlans(businessId, payload.getCropPlanTypeCode(), env.getTenantId());
			if (numCropPlans > 0)
				throw new NotAllowedException("A crop plan of the specified not multiple type already exist");
		}

		var cropPlanId = cropPlansDAO.getCropPlanSeq();

		cropPlansDAO.insertCropPlan(cropPlanId, businessId, env.getUserId(), payload.getCropPlanTypeCode(), payload.getDescription(),
				payload.getFlNotManaged() ? 1 : 0, env.getTenantId());

		return cropPlanId;
	}

	public InfiniteListResults<CropPlanVersion> getAllVersions(RuntimeEnvironment env, String businessId, Long cropPlanId,
			boolean includeInPublishing, AbsoluteDate referenceDate, String nextKey, int pageSize) {
		return getAllVersions(env, businessId, cropPlanId, includeInPublishing, referenceDate, false, nextKey, pageSize);
	}

	public InfiniteListResults<CropPlanVersion> getAllVersions(RuntimeEnvironment env, String businessId, Long cropPlanId,
			boolean includeInPublishing, AbsoluteDate referenceDate, boolean ignoreCropPlanId, String nextKey, int pageSize) {
		// Criteria criteria = referenceDate != null ? CriteriaBuilder.string("cv.reference_dt").eq(referenceDate.toString()) : CriteriaBuilder.number("1").eq(1);
		InfiniteListResults<CropPlanVersion> ret = cropPlansDAO.infinite(
				() -> cropPlansDAO.getAllVersions(businessId, ignoreCropPlanId ? null : cropPlanId, env.getTenantId(), (includeInPublishing ? 1 : 0), referenceDate),
				nextKey,
				pageSize);

		Map<Long,List<CropPlanVersion>> versionsByCropPlanId = ret.getRecords().stream()
				.collect(groupingBy(CropPlanVersion::getCropPlanId, toList()));
		for (Entry<Long,List<CropPlanVersion>> entry : versionsByCropPlanId.entrySet()) {
			setVersionsMessagesExt(env, businessId, ret, entry);
		}

		return ret;
	}

	private void setVersionsMessagesExt(RuntimeEnvironment env, String businessId,
			InfiniteListResults<CropPlanVersion> ret, Entry<Long, List<CropPlanVersion>> entry) {
		Map<String, String> versionsMessagesExt = pluginManager.getCropPlanPlugin(businessId, entry.getKey(), env.getTenantId())
				.getVersionsMessagesExt(env, businessId, entry.getKey(), entry.getValue());

		if (versionsMessagesExt != null && !versionsMessagesExt.keySet().isEmpty()) {
			ret.getRecords().forEach(cpv -> {
				if (!cpv.getCropPlanId().equals(entry.getKey()))
					return;
				String messageExt = versionsMessagesExt.get(cpv.getVersion().getRawValue());
				if (messageExt != null && !messageExt.isEmpty()) {
					String message = cpv.getMessage().trim();
					cpv.setMessage(message.isEmpty() ? messageExt : (message + " - " + messageExt));
				}
			});
		}
	}

	public String getCropPlanTypeCode(RuntimeEnvironment env, String businessId, Long cropPlanId) {
		var basicCropPlanData = cropPlansDAO.getCropPlanInternal(businessId, cropPlanId, env.getTenantId());
		if (basicCropPlanData == null)
			return null;

		return basicCropPlanData.getCropPlanTypeCode();
	}

	public CropPlanVersion restoreLastVersion(RuntimeEnvironment env, String businessId, Long cropPlanId) {
		InfiniteListResults<CropPlanVersion> infinite = cropPlansDAO
				.infinite(() -> cropPlansDAO.getAllVersions(businessId, cropPlanId, env.getTenantId(), 1, null),
						null, 1);
		if (infinite.getCount() == 0) {
			throw new BadRequestException("No version found");
		}
		CropPlanVersion cropPlanLastVersion = infinite.getRecords().get(0);
		if (!cropPlanLastVersion.getFlPublished()) {
			throw new BadRequestException("Version " + cropPlanLastVersion.getVersion().getRawValue() + " is not published yet!");
		}
		LocalDateTime versionDate = cropPlanLastVersion.getVersionDate();
		cropPlansDeleteAndRestoreOperationsDAO.restoreLastVersion(cropPlanId, versionDate);
		return cropPlanLastVersion;
	}

	public List<CropPlanConfigData> getCropPlanConfig(RuntimeEnvironment env, String businessId, Long cropPlanId) {
		return pluginManager.getCropPlanPlugin(businessId, cropPlanId, env.getTenantId())
				.getCropPlanConfig(env, businessId, cropPlanId,
						cropPlanConfigDAO.getCropPlanConfig(cropPlanId, null, null));
	}

	public List<PermanentCropFormSubscription> getPermanentCropFormSubscriptions(RuntimeEnvironment env, String businessId, Long cropPlanId,
			GetPermanentCropFormSubscriptionsPayload payload) {
		return pluginManager.getCropPlanPlugin(businessId, cropPlanId, env.getTenantId()).getPermanentCropFormSubscriptions(env, payload.getExternalCode(),
				payload.getSubscriptionCodes());
	}

	public InfiniteListResults<ChangedPlot> getChangedPlots(Long cropPlanId, Version fromVersion, String businessId, RuntimeEnvironment env, String nextKey,
			int pageSize, Boolean checkByPlotDescriptionIfPlotCodeNotFound) {
		// Define fromVersion value if not provided
		if (fromVersion == null) {
			var lastVersions = cropPlansDAO.getLastVersions(Collections.singletonList(cropPlanId));
			var lastVersion = lastVersions.containsKey(cropPlanId) ? lastVersions.get(cropPlanId)
					: LocalDateTime.of(1700, 1, 1, 0, 0, 0);
			fromVersion = new Version(lastVersion);
		}

		final var versionDt = fromVersion.toDateTime();

		// Extract changedPlots
		InfiniteListResults<ChangedPlot> changedPlots = cropPlansDAO.infinite(() -> cropPlansDAO.getChangedPlots(cropPlanId, versionDt), nextKey, pageSize);

		if (changedPlots.getRecords().isEmpty()) {
			return new InfiniteListResultsImpl<>();
		}

		List<String> changedPlotCodes = changedPlots.getRecords().stream().map(ChangedPlot::getPlotCode).collect(toList());

		// Extract Previous Versione of Changed Plots
		List<ChangedPlot> previousVersionChangedPlots = cropPlansDAO.getPreviousVersionChangedPlots(cropPlanId, changedPlotCodes, versionDt);

		// Create and Populate Map with domain zone id and domain zone code
		Map<String, String> domainZones = new HashMap<>();

		changedPlots.getRecords().stream().map(ChangedPlot::getDomainZoneId).distinct().forEach(id -> {
			DomainZoneGeometry domainZone = pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId()).getDomainZone(env, businessId,
					LocalDate.now(), id);
			domainZones.put(id, domainZone != null ? domainZone.getCode() : null);
		});

		// For every changed plot
		for (ChangedPlot plot : changedPlots.getRecords()) {
			fillChangedPlot(plot, previousVersionChangedPlots, checkByPlotDescriptionIfPlotCodeNotFound, domainZones, cropPlanId, versionDt);
		}

		return changedPlots;
	}

	private void fillChangedPlot(ChangedPlot plot, List<ChangedPlot> previousVersionChangedPlots, Boolean checkByPlotDescriptionIfPlotCodeNotFound,
			Map<String, String> domainZones, Long cropPlanId, LocalDateTime versionDt) {
		// Set domain zone code
		plot.setDomainZoneCode(domainZones.get(plot.getDomainZoneId()));

		// Try to find his previous plot version
		Optional<ChangedPlot> previousPlot = previousVersionChangedPlots.stream().filter(el -> el.getPlotCode().equals(plot.getPlotCode())).findFirst();

		if (previousPlot.isEmpty() && checkByPlotDescriptionIfPlotCodeNotFound) {
			List<ChangedPlot> previousVersionChangedPlotsByDescription = cropPlansDAO.getPreviousVersionChangedPlotsByDescription(cropPlanId,
					plot.getPlotDescription(), versionDt);

			if (previousVersionChangedPlotsByDescription.size() != 1) {
				return;
			}

			previousPlot = Optional.of(previousVersionChangedPlotsByDescription.get(0));
		}

		// If not find skip current element
		if (previousPlot.isEmpty()) {
			return;
		}

		// Find if area and mbr of current and previous version of plot are below define tolerance
		boolean areChangedPlotPreviousAndCurrentAreaAlmostEquals =
				Math.abs(previousPlot.get().getGeom().getArea() - plot.getGeom().getArea()) < CHANGED_PLOT_AREA_TOLERANCE;
		boolean areChangedPlotPreviousAndCurrentGeomAlmostEquals =
				Utils.snappedIntersectionAB(previousPlot.get().getGeom(), plot.getGeom()).getArea() - plot.getGeom().getArea() < CHANGED_PLOT_AREA_TOLERANCE;

		// If they are, them geom is not changed, so we flag it to false (default is true in class)
		if (areChangedPlotPreviousAndCurrentAreaAlmostEquals && areChangedPlotPreviousAndCurrentGeomAlmostEquals) {
			plot.setGeomChanged(false);
		}
	}

	public void adjustDeclDatesForPlotsBetweenDates(Plot p, Declaration d) {
		if (d.getFromDate().isBeforeOrEqual(p.getToDate()) && d.getToDate().isAfterOrEqual(p.getFromDate())) {
			var fromDate = d.getFromDate().isBefore(p.getFromDate()) ? p.getFromDate() : d.getFromDate();
			var toDate = d.getToDate().isAfter(p.getToDate()) ? p.getToDate() : d.getToDate();

			if (!fromDate.equals(d.getFromDate()) || !toDate.equals(d.getToDate())) {
				p.getDecls().remove(d);
				p.getDecls().add(d.toBuilder().toDate(toDate).fromDate(fromDate).build());
			}
		}
	}

	public Integer getPlotAreaSqm(Long cropPlanId, LocalDateTime versionDt, AbsoluteDate pointInTime, String plotCode)
	{
		return cropPlansDAO.getPlotCodesWithAreas(cropPlanId, versionDt, pointInTime, List.of(plotCode)).get(0).getAreaSqm();
	}

	public List<PlotTimeline.PlotArea> getPlotAreas(PlotTimeWindowParams params) {
		// filter the soft modified plot enlarging the end date of the previous hard plot
		List<PlotTimeline.PlotArea> hardModAreas = new ArrayList<>();
		List<PlotTimeline.PlotArea> areas = cropPlansDAO.getPlotAreas(params.getPlotCode(), params.getCropPlanId(), params.getVersionDt(),
				params.getPointInTimeFrom(), params.getPointInTimeTo());

		if (areas.size() <= 1)
			return areas;

		hardModAreas.add(areas.get(0));
		areas.remove(0);

		areas.forEach(a -> {
			PlotTimeline.PlotArea lastOfTheHards = hardModAreas.get(hardModAreas.size() - 1);
			if (a != null && a.getFlSoftModified() > 0 && Integer.compare(a.getAreaSqm(), lastOfTheHards.getAreaSqm()) == 0)
				lastOfTheHards.setToDate(a.getToDate());
			else
				hardModAreas.add(a);
		});

		return hardModAreas;
	}

	public List<PermanentCropFormFieldCodes> getPermanentCropFormFieldsCodes(RuntimeEnvironment env, Long cropPlanId, String formType) {
		List<PermanentCropFormFieldCodes> fcs = new ArrayList<>();
		var fvs = cropPlansDAO.getPermanentCropFormFieldsValues(env.getTenantId(), env.getLocale().getLanguage(), cropPlanId, formType);
		var map = fvs.stream().collect(groupingBy(PermanentCropFormFieldValue::getFieldCode));
		map.keySet().iterator().forEachRemaining(fieldCode -> fcs.add(new PermanentCropFormFieldCodes(fieldCode, map.get(fieldCode))));
		return fcs;
	}

	public void updateParcelData(RuntimeEnvironment env, Long cropPlanId, String parcelCode, ParcelDataPayload payload) {
		cropPlansDAO.updateParcelData(env, cropPlanId, parcelCode, payload);
	}
}
