package com.abacogroup.cropplan.api;

import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class CropPlanLandUse extends LandUse {
	@Schema(description = "The total declared area, in square meters")
	@NotNull
	private Long areaSqm;
}