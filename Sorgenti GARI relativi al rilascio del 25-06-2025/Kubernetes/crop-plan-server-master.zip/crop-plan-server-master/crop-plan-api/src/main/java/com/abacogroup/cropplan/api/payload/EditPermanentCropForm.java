package com.abacogroup.cropplan.api.payload;

import com.abacogroup.cropplan.sdk.model.PermanentCropFormData;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "The permanent crop form data")
public class EditPermanentCropForm
{

	@Schema(description = "The permanent crop form code (this does not change in history)")
	private String formCode;

	@Schema(description = "The permanent crop form type")
	@NotNull
	private String formType;

	@NotNull
	private PermanentCropFormData permanentCropFormData;

}
