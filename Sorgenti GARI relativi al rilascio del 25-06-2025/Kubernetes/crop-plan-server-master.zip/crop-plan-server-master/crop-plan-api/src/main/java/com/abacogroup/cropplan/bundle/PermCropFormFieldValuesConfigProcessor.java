package com.abacogroup.cropplan.bundle;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.cropplan.bundle.model.PermCropFormFieldValuesConfigMessage;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;

public class PermCropFormFieldValuesConfigProcessor extends AbstractConfigProcessor
{
	private static final String I18N_TABLE_NAME = "CRPL_PERM_CROP_FIELD_VALUES";
	private static final String I18N_FIELD_NAME = "I18N_VALUE";

	public PermCropFormFieldValuesConfigProcessor(CropPlanConfigDAO configDAO)
	{
		super(configDAO);
	}

	@Override
	public String getDomainName()
	{
		return "permCropFormFieldValues";
	}

	@Override
	public void onMessageInTransaction(CropPlanConfigDAO dao, ConfigDataMessage message)
	{
		message.getConfigFiles().stream()
			.map(Path::toFile)
			.filter(file -> file.getAbsolutePath().endsWith(".json"))
			.sorted()
			.forEach(file -> processFile(message.getTenantId(), file));
	}

	private void processFile(String tenantId, File file)
	{
		PermCropFormFieldValuesConfigMessage message;
		try
		{
			message = objectMapper.readValue(file, PermCropFormFieldValuesConfigMessage.class);
		}
		catch (IOException e)
		{
			throw new IllegalStateException("Error processing file " + file.getName() + " for tenant " + tenantId, e);
		}

		if (file.getAbsolutePath().endsWith(".delete.json"))
		{
			doDelete(tenantId, message);
		}
		else
		{
			doInsertOrUpdate(tenantId, message);
		}
	}

	private void doInsertOrUpdate(String tenantId, PermCropFormFieldValuesConfigMessage message)
	{
		if (message == null || message.getFieldValues() == null || message.getFieldValues().isEmpty())
		{
			return;
		}

		Long typeId = configDAO.getCropPlanTypeId(message.getCropPlanType(), tenantId);
		message.getFieldValues().forEach(fieldValue -> {
			var oldI18nValue = configDAO.getI18nValue(fieldValue.getFormType(), fieldValue.getFieldCode(),
				fieldValue.getFieldValue(), typeId);

			configDAO.deleteFieldValue(fieldValue.getFormType(), fieldValue.getFieldCode(),
				fieldValue.getFieldValue(), typeId);

			if (configDAO.countI18nValues(oldI18nValue, typeId) == 0)
				configDAO.deleteI18nValue(I18N_TABLE_NAME, I18N_FIELD_NAME, oldI18nValue, null, tenantId);

			String i18nValueId = fieldValue.getFormType() + "_" + fieldValue.getFieldCode() + "_" + fieldValue.getFieldValue();

			configDAO.insertFieldValue(fieldValue.getFormType(), fieldValue.getFieldCode(),
				fieldValue.getFieldValue(), i18nValueId, typeId);
			fieldValue.getI18nValues().forEach(i18nValue -> {
				configDAO.deleteI18nValue(I18N_TABLE_NAME, I18N_FIELD_NAME, i18nValueId,
					i18nValue.getLanguage(), tenantId);

				configDAO.insertI18nValue(I18N_TABLE_NAME, I18N_FIELD_NAME, i18nValueId,
					i18nValue.getLanguage(), i18nValue.getText(), tenantId);
			});
		});
	}

	private void doDelete(String tenantId, PermCropFormFieldValuesConfigMessage message)
	{
		if (message == null || message.getFieldValues() == null || message.getFieldValues().isEmpty())
		{
			return;
		}

		Long typeId = configDAO.getCropPlanTypeId(message.getCropPlanType(), tenantId);
		message.getFieldValues().forEach(fieldValue -> {
			var oldI18nValue = configDAO.getI18nValue(fieldValue.getFormType(), fieldValue.getFieldCode(),
				fieldValue.getFieldValue(), typeId);

			configDAO.deleteFieldValue(fieldValue.getFormType(), fieldValue.getFieldCode(),
				fieldValue.getFieldValue(), typeId);

			if (configDAO.countI18nValues(oldI18nValue, typeId) == 0)
				configDAO.deleteI18nValue(I18N_TABLE_NAME, I18N_FIELD_NAME, oldI18nValue, null, tenantId);
		});
	}

}
