package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class IncompatibleLandUseException extends WebApplicationException
{
	private static final long serialVersionUID = 6137627279062251928L;

	public static  class IncompatibleLandUseExceptionErrorBody
	{
		@Schema(allowableValues = "INCOMPATIBLE_LAND_USE_EXCEPTION")
		public String getErrorCode()
		{
			return "INCOMPATIBLE_LAND_USE_EXCEPTION";
		}
	}
	
	private static final IncompatibleLandUseExceptionErrorBody BODY = new IncompatibleLandUseExceptionErrorBody();

	public IncompatibleLandUseException()
	{
		super("The land use is not allowed for the land cover",
			Response.status(Status.BAD_REQUEST).entity(BODY).build());
	}
}
