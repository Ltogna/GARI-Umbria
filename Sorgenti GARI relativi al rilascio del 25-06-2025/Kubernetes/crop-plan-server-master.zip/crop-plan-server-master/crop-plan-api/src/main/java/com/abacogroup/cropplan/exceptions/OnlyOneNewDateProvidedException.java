package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class OnlyOneNewDateProvidedException extends WebApplicationException
{
	private static final long serialVersionUID = -5877956665832492013L;

	public static  class OnlyOneNewDateProvidedExceptionErrorBody
	{
		@Schema(allowableValues = "ONLY_ONE_NEW_DATE_PROVIDED_EXCEPTION")
		public String getErrorCode()
		{
			return "ONLY_ONE_NEW_DATE_PROVIDED_EXCEPTION";
		}
	}

	private static final OnlyOneNewDateProvidedExceptionErrorBody BODY = new OnlyOneNewDateProvidedExceptionErrorBody();

	public OnlyOneNewDateProvidedException()
	{
		super("You must provide both newFromDate and newToDate or none of them",
			Response.status(Status.BAD_REQUEST).entity(BODY).build());
	}
}
