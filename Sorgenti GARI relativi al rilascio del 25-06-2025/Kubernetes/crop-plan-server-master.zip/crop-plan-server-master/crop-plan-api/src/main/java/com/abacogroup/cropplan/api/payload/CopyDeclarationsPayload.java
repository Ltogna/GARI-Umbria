package com.abacogroup.cropplan.api.payload;

import java.util.List;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "A copy declarations payload")
public class CopyDeclarationsPayload
{
	@Schema(description = "The point in time")
	@NotNull
	private AbsoluteDate pointInTime;
	
	@Schema(description = "The source plot code")
	@NotNull
	private String sourcePlotCode;
	
	@Schema(description = "The source declaration codes")
	@NotEmpty
	private List<String> sourceDeclCodes;
	
	@Schema(description = "The destination plot code")
	@NotNull
	private String destPlotCode;
	
	@Schema(description = "If it is set to true then source declarations are removed")
	private boolean removeSourceDecls = false;
}
