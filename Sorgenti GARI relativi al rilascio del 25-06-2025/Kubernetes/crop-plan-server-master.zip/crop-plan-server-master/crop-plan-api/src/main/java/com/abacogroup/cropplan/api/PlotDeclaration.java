package com.abacogroup.cropplan.api;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomaly;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.locationtech.jts.geom.Geometry;

@Data
@EqualsAndHashCode(callSuper = true)
public class PlotDeclaration extends Declaration
{
	@Schema(description = "The plot identifier, this changes in history")
	@NotNull
	private Long plotId;

	@Schema(description = "The plot 'stable' code, this does not change in history")
	@NotEmpty
	private String plotCode;

	@Schema(description = "The plot description")
	private String plotDescription;
	
	@Schema(description = "The plot notes")
	private String plotNotes;

	@Schema(description = "The parcels assigned to the plot")
	@NotNull
	private List<ParcelIntersection> parcelIntersections;

	@Schema(description = "The plot area, in square meters")
	@NotNull
	private Integer plotAreaSqm;

	@Schema(description = "The geometry", type = "string", format = "WKT geometry")
	@NotNull
	private Geometry geom;

	@Schema(description = "The geometry srs")
	@NotNull
	private String srs;

	@Schema(description = "The MBR overview", type = "string", format = "WKT geometry")
	@NotNull
	private Geometry mbrOverview;

	@Schema(description = "Plot from date")
	@NotNull
	private AbsoluteDate plotFromDate;

	@Schema(description = "Plot to date")
	@NotNull
	private AbsoluteDate plotToDate;

	@NotNull
	private PlotEditability editability;

	@Schema(description = "The domain zone code")
	@NotNull
	private String domainZoneCode;

	@Schema(description = "The domain zone description")
	private String domainZoneDescription;

	@Schema(description = "The deletion flag")
	private boolean isDeleted;
	
	@Schema(description = "The plot anomalies")
	private List<ValidationAnomaly> plotAnomalies;
	
	public String getPlotCodeDeclCodeKey() {
		return plotCode + "|" + getDeclCode();
	} 

}
