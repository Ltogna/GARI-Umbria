package com.abacogroup.cropplan.api;

import com.abacogroup.cropplan.sdk.model.domain.HoldingArea;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "A domain area (i.e.: council, region, ...)")
public class DomainZoneExt extends DomainZone
{
	private HoldingArea holdingArea;
	
	public DomainZoneExt(String domainZoneId, String code, String description, String srs, MBR mbr, HoldingArea holdingArea) {
		super(domainZoneId, code, description, srs, mbr);
		this.holdingArea = holdingArea;
	}

	private boolean bigDomainZone = false;
}
