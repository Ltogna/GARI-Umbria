package com.abacogroup.cropplan.bundle.model;

///  jakarta validation groups
public final class ValidationGroups {

	public interface Insert {}
	public interface Update {}
	public interface Delete {}

}
