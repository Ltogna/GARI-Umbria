package com.abacogroup.cropplan.api;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "The sync progress status")
public enum SyncProgress
{
	IN_PROGRESS, COMPLETED
}
