package com.abacogroup.cropplan.api.payload;

import java.util.List;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.DefaultValue;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CutPlotsByLayerPayload
{
	@Schema(description = "From date")
	@NotNull
	private AbsoluteDate fromPointInTime;

	@Schema(description = "To date (optional, default propagate to infinity)")
	private AbsoluteDate toPointInTime;

	@Schema(description = "The layer code")
	private String layerCode;

	@Schema(description = "The parameters used to apply the geometry in relation to the already existing ones")
	@NotNull
	@Valid
	private LayerCutParameters cutParameters;
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	public static class LayerCutParameters
	{
		@Schema(description = "The plots to consider during the cut operation; if null, all plots are considered")	 
		@Size(min = 1)
		private List<String> plotCodes;

		@Schema(description = "If true, the specified cut geometries are merged before cut")
		@DefaultValue("false")
		private boolean flMergeGeomsOnCutOnLayer;
		
		@Schema(description = "If true, covered by inserted are computed")
		@DefaultValue("false")
		private boolean flCalcCoveredByInsertedOnCutOnLayer;
	}
}
