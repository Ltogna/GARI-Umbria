package com.abacogroup.cropplan.services.support;

import java.util.List;

import com.abacogroup.cropplan.api.ValidationResult;
import com.abacogroup.cropplan.sdk.model.validation.ValidationMessage;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorData;

public interface ValidatorSupport<T extends ValidationResult>
{
	public ValidatorData getValidatorData();
	public T getResult(List<ValidationMessage> msgs, List<String> updatedAnomaliesPlotCodes);
}
