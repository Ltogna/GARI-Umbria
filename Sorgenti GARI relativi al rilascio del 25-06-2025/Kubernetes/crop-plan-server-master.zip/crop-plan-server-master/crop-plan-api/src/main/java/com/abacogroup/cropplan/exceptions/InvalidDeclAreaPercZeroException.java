package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class InvalidDeclAreaPercZeroException extends WebApplicationException
{
	private static final long serialVersionUID = -5572671375637015782L;

	@Schema(name = "InvalidDeclAreaPercZeroExceptionErrorBody")
	public static  class ErrorBody
	{
		@Schema(allowableValues = "INVALID_DECL_AREA_PERC_ZERO_EXCEPTION")
		public String getErrorCode()
		{
			return "INVALID_DECL_AREA_PERC_ZERO_EXCEPTION";
		}
	}

	private static final ErrorBody BODY = new ErrorBody();

	public InvalidDeclAreaPercZeroException()
	{
		super("INVALID_DECL_AREA_PERC_ZERO_EXCEPTION",
			Response.status(Status.BAD_REQUEST).entity(BODY).build());
	}
}
