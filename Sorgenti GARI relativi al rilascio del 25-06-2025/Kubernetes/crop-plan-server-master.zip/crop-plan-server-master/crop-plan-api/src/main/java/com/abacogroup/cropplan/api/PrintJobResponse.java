package com.abacogroup.cropplan.api;

import lombok.Data;

@Data
public class PrintJobResponse {
	private String uuid;
	private PrintJobStatus status;
	private String fileStoreId;
	private String bucket;
	private String dest;
}