package com.abacogroup.cropplan.services;

import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;

import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.geom.Polygonal;

import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.PlotEditDAO;
import com.abacogroup.cropplan.db.dao.ntt.PlotDataParcel;
import com.abacogroup.cropplan.db.dao.ntt.SavePlotDatas;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.domain.Parcel;
import com.abacogroup.cropplan.sdk.spi.DomainPlugin;
import com.abacogroup.cropplan.services.PersistEditorResult.FutureIntersections;
import com.abacogroup.cropplan.services.PersistEditorResult.ValidIntersection;
import com.abacogroup.cropplan.services.support.EditorResultParams;
import com.abacogroup.cropplan.services.support.EditorSupportParams;
import com.abacogroup.geometryeditor.Editor.CanvasPreprocess;
import com.abacogroup.geometryeditor.EditorResult;
import com.abacogroup.geometryeditor.GeomsToBeCompared;
import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

public class PropagationService
{
	//private static final Logger log = LoggerFactory.getLogger(PropagationService.class);

	private CropPlanConfigService cropPlanConfigService;
	private PlotEditDAO plotEditDAO;
	private PluginManager pluginManager;

	public PropagationService(CropPlanConfigService cropPlanConfigService, DAOContainer daocontainer, PluginManager pluginManager)
	{
		this.cropPlanConfigService = cropPlanConfigService;
		this.plotEditDAO = daocontainer.getPlotEditDAO();
		this.pluginManager = pluginManager;
	}

	public FutureIntersections buildFutureIntersections(RuntimeEnvironment env, EditorSupportParams editorSupportParams,
		AbsoluteDate fromPointInTime, AbsoluteDate toPointInTime, EditorResult<String> result,
		Function<EditorResultParams, EditorResult<String>> editFunction, Double tolerance, CanvasPreprocess canvasPreprocess)
	{
		var snapFromDate = cropPlanConfigService.getSnapFromDate(editorSupportParams.getCropPlanId(), fromPointInTime);
		var domainPlugin = pluginManager.getDomainPlugin(editorSupportParams.getBusinessId(), editorSupportParams.getCropPlanId(), env.getTenantId());

		FutureIntersections ret = new FutureIntersections(toPointInTime != null ? toPointInTime : AbsoluteDate.of("99991231"), new ArrayList<>());	
		if (editFunction == null) // for delete plot (the maximumDayTo will not be used)
			return ret;

		List<Geometry> polygons = new ArrayList<>();
		polygons.addAll(result.getCreated().values());
		polygons.addAll(result.getModified().values());

		if (polygons.isEmpty())
			return ret;

		var touchingGeometry = Utils.getUnion(polygons).buffer(Utils.getNearDistance());

		//long startTime = System.currentTimeMillis(); 

		List<AbsoluteDate> fiPointInTimes;

		if(cropPlanConfigService.disablePlotDataSpatialIndex(editorSupportParams.getCropPlanId())){
			fiPointInTimes = plotEditDAO.getFutureInteractionsWithNoSpatialIndex(editorSupportParams.getCropPlanId(), editorSupportParams.getDomainZoneId(),fromPointInTime, touchingGeometry);
		} else {
			fiPointInTimes = plotEditDAO.getFutureInteractions(editorSupportParams.getCropPlanId(), editorSupportParams.getDomainZoneId(),fromPointInTime, touchingGeometry);
		}
		
		
		
		//long endTime = System.currentTimeMillis();
		//log.info("TIME ELAPSED (" + editorSupportParams.getCropPlanId() + "): buildFutureIntersections.getFutureInteractions at " + fromPointInTime.toString() + ": " + TimeUnit.MILLISECONDS.toSeconds((endTime-startTime)) + "s");								
		
		//startTime = System.currentTimeMillis(); 
		var fiParcels = domainPlugin.getFutureParcelsIntersections(env, editorSupportParams.getBusinessId(),
			editorSupportParams.getDomainZoneId(), snapFromDate.toLocalDate(), touchingGeometry);
		//endTime = System.currentTimeMillis();
		//log.info("TIME ELAPSED (" + editorSupportParams.getCropPlanId() + "): buildFutureIntersections.getFutureParcelsIntersections at " + fromPointInTime.toString() + ": " + TimeUnit.MILLISECONDS.toSeconds((endTime-startTime)) + "s");								
		
		fiPointInTimes.addAll(fiParcels.stream()
			.map(fiParcel -> {
				var fi = AbsoluteDate.of(fiParcel);
				return Optional.ofNullable(cropPlanConfigService.getFixedEditDate(editorSupportParams.getCropPlanId(), fi)).orElse(fi);
			})
			.collect(toList()));

		fiPointInTimes = fiPointInTimes.stream()
			.distinct()
			.filter(i -> i.toLocalDate().isAfter(fromPointInTime.toLocalDate()) && i.toLocalDate().getYear() < 9999 && i.toLocalDate().compareTo(ret.getMaximumDayTo().toLocalDate()) <= 0)
			.sorted()
			.collect(toList());
		
		Geometry geomForCanvas = Utils.reducePrecision(touchingGeometry, true, false); // TODO da rivedere per altre operazioni (attualmente utilizzato solo per insert/update plot
		//startTime = System.currentTimeMillis(); 
		List<Parcel> parcels = domainPlugin.getAllParcels(env, editorSupportParams.getBusinessId(), editorSupportParams.getDomainZoneId(), null, geomForCanvas);
		//endTime = System.currentTimeMillis();
		//log.info("TIME ELAPSED (" + editorSupportParams.getCsropPlanId() + "): buildFutureIntersections.getAllParcels (loaded n. " + parcels.size() + ") at " + fromPointInTime.toString() + ": " + TimeUnit.MILLISECONDS.toSeconds((endTime-startTime)) + "s");								
		
		boolean foundValidWithTolerance = false;
		for (AbsoluteDate pointInTime : fiPointInTimes)
		{
			List<Parcel> parcelsAtPointInTime = this.getParcelsAtPointInTime(parcels, pointInTime);
				
			EditorResultParams params = EditorResultParams.builder()
				.pointInTime(pointInTime)
				.parcels(parcelsAtPointInTime)
				.build();
			EditorResult<String> futureResult = editFunction.apply(params);
			if (!foundValidWithTolerance && futureResult.equals(result, true, true, 
					getCreatedParcelIntersectionsEqualsFunction(env, editorSupportParams, canvasPreprocess, fromPointInTime, pointInTime))) {
				ret.getValidIntersections().add(new ValidIntersection(pointInTime, futureResult.getTopologyCorrected(), false, null, null));
			} else {
				ValidIntersection validIntersectionWithTolerance = getValidWithTolerance(result, futureResult, pointInTime, tolerance, env, editorSupportParams, canvasPreprocess, fromPointInTime);
				if (validIntersectionWithTolerance != null) {
					foundValidWithTolerance = true;
					ret.getValidIntersections().add(validIntersectionWithTolerance);
				} else {
					ret.setMaximumDayTo(AbsoluteDate.of(pointInTime.toLocalDate().minusDays(1)));
					break;
				}
			}
		}

		return ret;
	}

	protected List<Parcel> getParcelsAtPointInTime(List<Parcel> parcels,AbsoluteDate pointInTime){
		List<Parcel> parcelsAtPointInTime = null;
		if (parcels != null) {
			parcelsAtPointInTime = parcels.stream()
				.filter(p -> pointInTime.isAfterOrEqual(AbsoluteDate.of(p.getFromDate())) && pointInTime.isBeforeOrEqual(AbsoluteDate.of(p.getToDate())))
				.collect(toList());
		}

		return parcelsAtPointInTime;
	}
	
	private ValidIntersection getValidWithTolerance(EditorResult<String> result, EditorResult<String> futureResult, AbsoluteDate pointInTime, double tolerance,
			RuntimeEnvironment env, EditorSupportParams params, CanvasPreprocess canvasPreprocess, AbsoluteDate fromPointInTime) {
		if (tolerance <= 0) 
			return null;
		
		Map<String, Polygon> viCreated = new HashMap<>();
		Map<String, Polygon> viModified = new HashMap<>();
		
		// check deleted, modified and created
		if (checkDeletedModifiedAndCreated(result, futureResult))
			return null;

		// check modified
		for (String plotCode : futureResult.getModified().keySet()) {
			Polygon modified = futureResult.getModified().get(plotCode);
			Polygon previousModified = result.getModified().get(plotCode);
			Geometry intersection = Utils.snappedIntersectionAB(previousModified, modified);
			if (Math.abs(intersection.getArea() - previousModified.getArea()) > tolerance)
				return null;
			viModified.put(plotCode, modified);
		}
				
		// check created
		for (String plotCode : futureResult.getCreated().keySet()) {
			Polygon created = futureResult.getCreated().get(plotCode);
			for (String previousPlotCode : result.getCreated().keySet()) {
				Polygon previousCreated = result.getCreated().get(previousPlotCode);
				Geometry intersection = Utils.snappedIntersectionAB(previousCreated, created);
				Function<GeomsToBeCompared, Boolean> comparator = getCreatedParcelIntersectionsEqualsFunction(env, params, canvasPreprocess, fromPointInTime, pointInTime);
				if (Math.abs(intersection.getArea() - previousCreated.getArea()) <= tolerance && comparator.apply(new GeomsToBeCompared(created, previousCreated)).booleanValue()) {
					viCreated.put(previousPlotCode, created);
					break;
				}
			}
		}
		if (!isResultKeysEqual(viCreated.keySet(), result.getCreated().keySet()))
			return null;
		
		//futureResult.getCreatedParent(null);
	
		return new ValidIntersection(pointInTime, futureResult.getTopologyCorrected(), true, viCreated, viModified);
	}

	private boolean checkDeletedModifiedAndCreated(EditorResult<String> result, EditorResult<String> futureResult) {
		return !isResultKeysEqual(futureResult.getDeleted(), result.getDeleted())
				|| !isResultKeysEqual(futureResult.getModified().keySet(), result.getModified().keySet())
				|| futureResult.getCreated().size() != result.getCreated().size();
	}
	
	private boolean isResultKeysEqual(Set<String> set1, Set<String> set2) {
		boolean haveSameSize = set1.size() == set2.size();
		boolean haveSameElements = set1.containsAll(set2);
		return haveSameSize && haveSameElements;
	}
	
	private Function<GeomsToBeCompared, Boolean> getCreatedParcelIntersectionsEqualsFunction(RuntimeEnvironment env, EditorSupportParams params, CanvasPreprocess canvasPreprocess,
			AbsoluteDate fromPointInTime, AbsoluteDate futurePointInTime) {
		return (GeomsToBeCompared geoms) -> {	
			List<String> fromParcels = processPlotParcelData(null, env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(), fromPointInTime, 
					geoms.getGeomB(), null, canvasPreprocess);
			
			List<String> futureParcels = processPlotParcelData(null, env, params.getBusinessId(), params.getCropPlanId(), params.getDomainZoneId(), futurePointInTime, 
					geoms.getGeomA(), null, canvasPreprocess);
			
			boolean haveSameSize = fromParcels.size() == futureParcels.size();
			boolean haveSameElements = fromParcels.stream()
					.filter(pi -> !futureParcels.contains(pi))
					.collect(toList())
					.isEmpty();
			return haveSameSize && haveSameElements;
		};
	}
	
	public List<String> processPlotParcelData(SavePlotDatas savePlotDatas, RuntimeEnvironment env, String businessId, Long cropPlanId,
			String domainZoneId, AbsoluteDate dayFrom, Geometry plotGeom, Long plotId, CanvasPreprocess canvasPreprocess) {
		var snapFromDate = cropPlanConfigService.getSnapFromDate(cropPlanId, dayFrom);
		var domainPlugin = pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId());

		var parcels = domainPlugin.getParcels(env, businessId, domainZoneId, snapFromDate.toLocalDate(), plotGeom);
		Map<String, PlotDataParcel> intersectedParcelCodes = new HashMap<>();
		findIntersectedParcelCodes(env, businessId, plotGeom, plotId, snapFromDate, domainPlugin, parcels, intersectedParcelCodes, false);

		// if no intersection found then use all intersections with area not rounded > 0
		if (intersectedParcelCodes.size() == 0 && parcels.size() > 0) {
			findIntersectedParcelCodes(env, businessId, plotGeom, plotId, snapFromDate, domainPlugin, parcels,
					intersectedParcelCodes, true);
		}
		
		// if (intersectedParcelCodes.size() == 1)
		// {
		// Map<String, String> parcelDescriptions = domainPlugin.getParcelsDescription(env, businessId,
		// intersectedParcelCodes,
		// plotData.getInsertDt(), plotData.getDayFrom().get());
		// return parcelDescriptions.get(intersectedParcelCodes.get(0));
		// }
		List<String> ret = new ArrayList<>();
		if (intersectedParcelCodes.size() > 0)
		{
			if (canvasPreprocess == CanvasPreprocess.NONE)
				ret.addAll(intersectedParcelCodes.keySet());
			else {
				Entry<String, PlotDataParcel> maxParcelEntry = intersectedParcelCodes.entrySet().stream()
						.max((p1, p2) -> p1.getValue().getAreaSqm() > p2.getValue().getAreaSqm() ? 1 : -1).orElse(null);
				if (maxParcelEntry != null)
					ret.add(maxParcelEntry.getKey());
			}
		}
		
		if (savePlotDatas != null) {
			ret.forEach(ipc -> {
				savePlotDatas.getPlotDataParcels().add(intersectedParcelCodes.get(ipc));
			});
		}
		
		return ret;
	}
	
	private void findIntersectedParcelCodes(RuntimeEnvironment env, String businessId, Geometry plotGeom, Long plotId, AbsoluteDate snapFromDate,
			DomainPlugin domainPlugin, Map<String, Polygonal> parcels, Map<String, PlotDataParcel> intersectedParcelCodes, boolean useRoundedArea) {
		parcels.keySet().forEach(parcelCode -> {
			// var parcelGeom = Utils.reducePrecision((Geometry) parcels.get(parcelCode), true, true);
			var parcelGeom = (Geometry) parcels.get(parcelCode);
			// var intersection = plotGeom.intersection(parcelGeom);
			var intersection = Utils.snappedIntersectionAB(plotGeom, parcelGeom);
			for (int i = 0; i < intersection.getNumGeometries(); i++) {
				var geom = intersection.getGeometryN(i);
				var areaSqm = (int) Math.round(geom.getArea());
				// if (geom.getArea() > 0) {
				if ((useRoundedArea && areaSqm > 0) || (!useRoundedArea && geom.getArea() > 0)) {
					if (intersectedParcelCodes.get(parcelCode) == null)
					{
						var landCoverCode = domainPlugin.getParcelLandCoverCode(env, businessId, parcelCode, snapFromDate.toLocalDate());
						intersectedParcelCodes.put(parcelCode, new PlotDataParcel(null, plotId, parcelCode, areaSqm, landCoverCode, false, geom));
					}
					else
					{
						intersectedParcelCodes.get(parcelCode).setAreaSqm(intersectedParcelCodes.get(parcelCode).getAreaSqm()+areaSqm);
						intersectedParcelCodes.get(parcelCode).setGeom(Utils.getUnion(List.of(intersectedParcelCodes.get(parcelCode).getGeom(), geom)));
					}
				}
			}
		});
	}
}
