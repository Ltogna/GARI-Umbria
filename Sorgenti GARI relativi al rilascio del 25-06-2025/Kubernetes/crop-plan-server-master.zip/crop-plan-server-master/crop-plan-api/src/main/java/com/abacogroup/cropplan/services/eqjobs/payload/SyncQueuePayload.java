package com.abacogroup.cropplan.services.eqjobs.payload;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.abacogroup.cropplan.api.payload.InsertPermanentCropForm;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import com.abacogroup.cropplan.sdk.model.Version;
import com.abacogroup.cropplan.sdk.model.sync.SyncType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SyncQueuePayload {
	private String username;
	private String tenant;
	private String language;

	private SyncType syncType;
	private LocalDateTime syncPluginDt;
	private LocalDateTime currentDt;
	private boolean isRecalcAnomaliesNeeded;

	private String businessId;
	private Long cropPlanId;
	private AbsoluteDate referenceDt;

	private LocalDateTime lastSyncDt;
	private boolean ignoreDefaults;
	private LocalDate oldestChangesDateFromLpisDate;

	private Long sourceCropPlanId;
	private Version sourceVersion;
	private AbsoluteDate sourcePointInTime;
	private List<String> landuseCodesExcludedFromAggregation;
	private boolean flCopyFromOtherBusinesses;
	private boolean preserveSourceDeclDates;
	private boolean skipAggregation;
	private AbsoluteDate declsPointInTimeTo;

	private List<String> domainZoneIds;
	private Map<String, List<Integer>> landUseCodesWithRotation;
	private List<InsertPermanentCropForm> newPermanentCropForms;
	private List<LandUseAdditionalDataField> newFieldsCodes;
	private boolean ignoreDeclValidationWarnings;

	public SyncQueuePayload(String username, String tenant, String language, String businessId, Long cropPlanId,
			SyncType syncType, boolean ignoreDefaults, LocalDateTime currentDt, LocalDateTime syncPluginDt, LocalDateTime lastSyncDt, AbsoluteDate referenceDt,
			boolean recalcAnomaliesNeeded, LocalDate oldestChangesDateFromLpisDate) {
		this.username = username;
		this.tenant = tenant;
		this.language = language;
		this.businessId = businessId;
		this.cropPlanId = cropPlanId;
		this.currentDt = currentDt;
		this.lastSyncDt = lastSyncDt;
		this.syncPluginDt = syncPluginDt;
		this.syncType = syncType;
		this.referenceDt = referenceDt;
		this.ignoreDefaults = ignoreDefaults;
		this.isRecalcAnomaliesNeeded = recalcAnomaliesNeeded;
		this.oldestChangesDateFromLpisDate = oldestChangesDateFromLpisDate;
	}
}
