package com.abacogroup.cropplan.db.dao.ntt;

import com.abacogroup.cropplan.sdk.model.PermanentCropForm;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class PermanentCropFormWithDeclCode extends PermanentCropForm
{
	@JsonIgnore
	private String plotCode;
	
	@JsonIgnore
	private String declCode;
	
	public String getPlotCodeDeclCodeKey() {
		return plotCode + "|" + declCode;
	}

}
