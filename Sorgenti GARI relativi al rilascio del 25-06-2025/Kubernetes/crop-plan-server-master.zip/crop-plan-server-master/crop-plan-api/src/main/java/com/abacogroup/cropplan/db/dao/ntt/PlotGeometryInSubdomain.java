package com.abacogroup.cropplan.db.dao.ntt;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.locationtech.jts.geom.Geometry;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
public class PlotGeometryInSubdomain extends PlotGeometry {
	private boolean inSubdomain = true;

	public PlotGeometryInSubdomain(Long plotId, String plotCode, Geometry geometry, boolean inSubdomain) {
		super(plotId, plotCode, geometry);
		this.inSubdomain = inSubdomain;
	}
}
