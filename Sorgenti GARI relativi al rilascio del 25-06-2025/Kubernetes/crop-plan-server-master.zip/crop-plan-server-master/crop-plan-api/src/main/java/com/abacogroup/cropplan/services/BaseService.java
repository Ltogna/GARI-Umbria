package com.abacogroup.cropplan.services;

import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.plugins.impl.EnvironmentFactory;

public class BaseService
{
	private final EnvironmentFactory environmentFactory;
	private PluginManager pluginManager;

	public BaseService(EnvironmentFactory environmentFactory, PluginManager pluginManager)
	{
		this.environmentFactory = environmentFactory;
		this.pluginManager = pluginManager;
	}

	public EnvironmentFactory getEnvironmentFactory()
	{
		return environmentFactory;
	}

	public boolean canRead(User user, String language, String businessId)
	{
		return pluginManager.getAuthPlugin().getBusinessAccessLevel(getEnvironmentFactory().create(user, language), businessId).canRead();
	}

	public boolean canWrite(User user, String language, String businessId)
	{
		return pluginManager.getAuthPlugin().getBusinessAccessLevel(getEnvironmentFactory().create(user, language), businessId).canWrite();
	}

}
