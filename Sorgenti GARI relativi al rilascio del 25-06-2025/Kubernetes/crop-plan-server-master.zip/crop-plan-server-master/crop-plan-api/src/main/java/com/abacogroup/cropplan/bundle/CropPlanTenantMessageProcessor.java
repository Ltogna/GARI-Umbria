package com.abacogroup.cropplan.bundle;

import java.util.Objects;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;

public class CropPlanTenantMessageProcessor implements TenantMessageProcessor
{
	private static final String TEMPLATE_TENANT_ID = "*";

	private final CropPlanConfigDAO configDAO;

	public CropPlanTenantMessageProcessor(CropPlanConfigDAO configDAO)
	{
		this.configDAO = configDAO;
	}

	@Override
	public void onMessage(TenantMessage message)
	{
		Objects.requireNonNull(message);
		Objects.requireNonNull(message.getTenantId());

		if (TEMPLATE_TENANT_ID.equals(message.getTenantId()))
		{
			return;
		}

		configDAO.copyTenant(TEMPLATE_TENANT_ID, message.getTenantId());
	}

}
