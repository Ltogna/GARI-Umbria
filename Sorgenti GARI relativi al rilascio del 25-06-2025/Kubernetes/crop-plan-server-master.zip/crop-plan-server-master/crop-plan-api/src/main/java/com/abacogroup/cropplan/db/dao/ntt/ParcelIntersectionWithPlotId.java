package com.abacogroup.cropplan.db.dao.ntt;

import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class ParcelIntersectionWithPlotId extends ParcelIntersection
{
	@JsonIgnore
	private Long plotId;
}
