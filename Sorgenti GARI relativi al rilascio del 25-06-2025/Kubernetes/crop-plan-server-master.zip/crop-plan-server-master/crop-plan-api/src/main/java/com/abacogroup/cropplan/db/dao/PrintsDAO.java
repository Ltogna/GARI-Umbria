package com.abacogroup.cropplan.db.dao;

import com.abacogroup.cropplan.api.CropPlanPrint;
import com.abacogroup.cropplan.api.CropPlanPrintParam;
import com.abacogroup.cropplan.sdk.mapper.VersionColumnMapper;
import com.abacogroup.jdbi.annotations.CacheDefinition;
import com.abacogroup.jdbi.annotations.Cached;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(VersionColumnMapper.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface PrintsDAO extends BasicDAO {

	@Cached
	@CacheDefinition(maxWeight = 1000, expireAfterWriteMinutes = 15)
	@SqlQuery("select t.code, t.description from ("
			+ "    select cp.print_code as code,"
			+ "           §i18n(:tenantId, 'CRPL_PRINTS', 'CODE', cp.print_code, :language)§ as description"
			+ "      from crpl_types ct, crpl_prints cp"
			+ "     where ct.code = :cropPlanTypeCode"
			+ "       and ct.tenant_id = :tenantId"
			+ "       and cp.type_id = ct.id) t order by t.description")
	@RegisterBeanMapper(CropPlanPrint.class)
	public List<CropPlanPrint> getCropPlanPrints(@Bind("tenantId") String tenantId, @Bind("cropPlanTypeCode") String cropPlanTypeCode,
			@Bind("language") String language);

	@SqlQuery("select param_name as paramName, \n"
			+ "       param_value as ParamValue \n"
			+ "  from crpl_prints_params \n"
			+ " where print_code = :printCode \n"
			+ "   and type_id = :typeId")
	@RegisterBeanMapper(CropPlanPrintParam.class)
	List<CropPlanPrintParam> getCropPlanPrintParamsByPrintCode(@Bind("typeId") Long typeId, @Bind("printCode") String printCode);
}
