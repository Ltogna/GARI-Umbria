package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class CropPlanNotCreateableException extends WebApplicationException
{
	private static final long serialVersionUID = 2761916954226060653L;

	public static class CropPlanNotCreateableExceptionErrorBody
	{
		private String messageCode;
		
		public CropPlanNotCreateableExceptionErrorBody() {
			this.messageCode = null;
		}
		
		public CropPlanNotCreateableExceptionErrorBody(String messageCode) {
			this.messageCode = messageCode;
		}

		@Schema(allowableValues = {"CROP_PLAN_NOT_CREATEABLE_EXCEPTION", "CROP_PLAN_NOT_CREATEABLE_EXCEPTION-[THE_MESSAGE_CODE]"})
		public String getErrorCode()
		{
			if (messageCode != null)
				return "CROP_PLAN_NOT_CREATEABLE_EXCEPTION-" + messageCode;
			else
				return "CROP_PLAN_NOT_CREATEABLE_EXCEPTION";
		}
	}

	public CropPlanNotCreateableException(String messageCode)
	{
		super("You are not allowed to create crop plans for this business",
			Response.status(Status.FORBIDDEN).entity(new CropPlanNotCreateableExceptionErrorBody(messageCode)).build());
	}
}
