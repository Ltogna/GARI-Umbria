package com.abacogroup.cropplan.api;

import com.abacogroup.cropplan.sdk.model.domain.BaseDomainZone;
import com.abacogroup.cropplan.sdk.model.validation.AnomalyObjectType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "The crop plan anomalies data")
public class ValidationAnomalies
{
	@Schema(description = "The number of the blocking anomalies")
	@NotNull
	private Integer numOfBlockingAnomalies;
	
	@Schema(description = "The number of the non-blocking anomalies")
	@NotNull
	private Integer numOfNonBlockingAnomalies;
	
	@NotNull
	private List<ValidationAnomalyByType> anomalies;
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Schema(description = "The list of the anomalies grouped by type")
	public static final class ValidationAnomalyByType
	{
		@Schema(description = "The number of the anomalies")
		@NotNull
		private Integer numOfAnomalies;
		
		@NotNull
		private AnomalyObjectType objectType;

		@Schema(description = "The error code of the anomalies")
		@NotEmpty
		private String errorCode;

		@Schema(description = "The error description of the anomaly")
		private String errorDescription;

		@Schema(description = "Field that indicates wether the anomalies is blocking (1, 0 otherwise")
		@NotNull
		private Boolean blocking;
		
		@Schema(description = "List of Domain zone")
		@NotNull
		private List<BaseDomainZone> baseDomainZoneList = new ArrayList<>();
		
		@JsonIgnore
		private String domainZoneId;
	}
}
