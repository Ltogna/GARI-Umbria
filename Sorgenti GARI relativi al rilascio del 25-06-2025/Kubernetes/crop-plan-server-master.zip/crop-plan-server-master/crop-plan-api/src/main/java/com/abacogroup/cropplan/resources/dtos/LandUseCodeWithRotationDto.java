package com.abacogroup.cropplan.resources.dtos;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class LandUseCodeWithRotationDto {
	@NotNull
	private String landUseCode;
	private Integer rotation;
}
