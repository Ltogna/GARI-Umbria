package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class LandUseCodeNotFoundException extends WebApplicationException
{
	private static final long serialVersionUID = 2636793965430374988L;

	public static  class LandUseCodeNotFoundExceptionErrorBody
	{
		@Schema(allowableValues = "LAND_USE_CODE_NOT_FOUND_EXCEPTION")
		public String getErrorCode()
		{
			return "LAND_USE_CODE_NOT_FOUND_EXCEPTION";
		}
	}
	
	private static final LandUseCodeNotFoundExceptionErrorBody BODY = new LandUseCodeNotFoundExceptionErrorBody();

	public LandUseCodeNotFoundException(String landUseCode)
	{
		super("The land use " + landUseCode + " was not found",
			Response.status(Status.BAD_REQUEST).entity(BODY).build());
	}
}
