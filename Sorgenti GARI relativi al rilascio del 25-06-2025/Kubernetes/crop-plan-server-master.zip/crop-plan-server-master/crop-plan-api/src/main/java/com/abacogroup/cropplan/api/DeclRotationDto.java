package com.abacogroup.cropplan.api;

import java.util.List;

import org.jdbi.v3.core.mapper.Nested;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomaly;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class DeclRotationDto {
	private String plotCode;
	private Long declId;
	private String declCode;
	private LandUse landUse;
	private Double areaPerc;
	private Long declAreaSqm;
	private Integer rotation;
	private AbsoluteDate dayFrom;
	private String dayFromPrecision;
	private AbsoluteDate dayTo;

	@Schema(description = "The declaration anomalies")
	private List<ValidationAnomaly> anomalies;

	@Nested("lu")
	public LandUse getLandUse()
	{
		return landUse;
	}
}

