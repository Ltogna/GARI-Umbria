package com.abacogroup.cropplan.api;

import com.abacogroup.cropplan.sdk.model.sync.SyncType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SyncStatus 
{
	private SyncProgress syncProgressStatus;
	private SyncType syncType;
	private Boolean withErrors;
}
