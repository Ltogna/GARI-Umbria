package com.abacogroup.cropplan.api;

import org.locationtech.jts.geom.Geometry;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PlotPreview
{
	@Schema(description = "The plot 'stable' code, this does not change in history")
	private String plotCode;

	@Schema(description = "The geometry", type = "string", format = "WKT geometry")
	private Geometry geom;
}
