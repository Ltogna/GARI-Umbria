package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Schema(description = "A multiple crop declarations for a time period")
public class EditDeclarationsPayload
{

	@Schema(description = "Land use code")
	@NotEmpty
	private String landuseCode;

	@Schema(description = "From date")
	@NotNull
	private AbsoluteDate fromDate;
	
	@Schema(description = "From date precision ('Y' if only year is specified, 'YM' if year month is specified, 'YMD' if year month date is specified, '-' if nothing is specified and plot day from is used); default 'YMD'")
	@NotNull
	private String fromDatePrecision = "YMD";

	@Schema(description = "To date")
	@NotNull
	private AbsoluteDate toDate;

	@Schema(description = "The plots")
	@NotEmpty
	private List<PlotCodeWithAreaPercPayload> plots;

	private List<InsertPermanentCropForm> permanentCropForms;

	@Schema(description = "List of additional fields codes values")
	private List<LandUseAdditionalDataField> fieldsCodes;
	
	@Schema(description = "If it is set to true then existing declarations between from date and to date are removed")
	private boolean removeExistingDeclarations = false;
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	public static class PlotCodeWithAreaPercPayload
	{
		@Schema(description = "The plot code")
		@NotNull
		private String plotCode;

		@Schema(description = "The declared area in percentage")
		@NotNull
		private Double areaPerc;
	}

}
