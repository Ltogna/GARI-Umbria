package com.abacogroup.cropplan.db.dao.ntt;

import lombok.Data;

@Data
public class ParcelCodeWithPlotId
{
	private Long plotId;
	
	private String parcelCode;
}
