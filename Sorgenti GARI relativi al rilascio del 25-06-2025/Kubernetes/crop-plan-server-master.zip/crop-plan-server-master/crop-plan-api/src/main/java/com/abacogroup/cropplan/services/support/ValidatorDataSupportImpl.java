package com.abacogroup.cropplan.services.support;

import static java.util.stream.Collectors.toList;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.exceptions.LandUseCodeNotFoundException;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.CropPlanConfigData;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataConf;
import com.abacogroup.cropplan.sdk.model.PermanentCropForm;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormFieldValue;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseClass;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseDetails;
import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormConfig;
import com.abacogroup.cropplan.sdk.support.ValidatorDataSupport;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import jakarta.ws.rs.BadRequestException;

public class ValidatorDataSupportImpl implements ValidatorDataSupport {

	private CropCodeService cropCodeService;
	private CropPlanConfigService cropPlanConfigService;
	private CropPlansDAO cropPlansDAO;
	private DeclarationsDAO declarationsDAO;
	private RuntimeEnvironment env;
	private Long cropPlanId;
	private LocalDateTime versionDt;
	private boolean calculateAtPreviousVersion;

	public ValidatorDataSupportImpl(CropCodeService cropCodeService, CropPlanConfigService cropPlanConfigService, CropPlansDAO cropPlansDAO,
			DeclarationsDAO declarationsDAO,
			RuntimeEnvironment env, Long cropPlanId, LocalDateTime versionDt, boolean calculateAtPreviousVersion) {
		this.cropCodeService = cropCodeService;
		this.cropPlanConfigService = cropPlanConfigService;
		this.cropPlansDAO = cropPlansDAO;
		this.declarationsDAO = declarationsDAO;
		this.env = env;
		this.cropPlanId = cropPlanId;
		this.versionDt = versionDt;
		this.calculateAtPreviousVersion = calculateAtPreviousVersion;
	}

	@Override
	public VDSParcel getParcel(String parcelCode, LocalDate pointInTimeFrom, LocalDate pointInTimeTo) {
		List<String> intersectedParcelPlots = cropPlansDAO.getIntersectedParcelsPlotCodes(cropPlanId, parcelCode, versionDt,
				AbsoluteDate.of(pointInTimeFrom), AbsoluteDate.of(pointInTimeTo));

		if (intersectedParcelPlots == null || intersectedParcelPlots.size() < 1)
			return new VDSParcel(parcelCode, new ArrayList<VDSPlot>(0));

		List<VDSPlot> plots = new ArrayList<>();

		intersectedParcelPlots.forEach(plotCode -> {
			var p = getPlot(plotCode, pointInTimeFrom, pointInTimeTo);
			if (p != null)
				plots.add(p);
		});

		return new VDSParcel(parcelCode, plots);
	}

	@Override
	public VDSPlot getPlot(String plotCode, LocalDate pointInTimeFrom, LocalDate pointInTimeTo) {
		String domainZoneId = cropPlansDAO.getDomainZoneIdByPlotCode(cropPlanId, plotCode);
		InfiniteListResults<Plot> plots = cropPlansDAO.infinite(
				() -> cropPlansDAO.getPlotsInternal(cropPlanId, domainZoneId, versionDt, AbsoluteDate.of(pointInTimeFrom),
						AbsoluteDate.of(pointInTimeTo), plotCode, null, null),
				null, 1);

		if (plots.getCount() > 0) {
			Plot plot = plots.getRecords().get(0);

			List<String> plotLandCoverCodes = cropPlansDAO.getPlotLandCoverCodes(plot.getPlotCode(), cropPlanId, versionDt, AbsoluteDate.of(pointInTimeFrom),
					AbsoluteDate.of(pointInTimeTo));

			List<VDSDeclaration> decls = declarationsDAO.getPlotDeclarations(cropPlanId, plotCode, null,
					versionDt, AbsoluteDate.of(pointInTimeFrom), AbsoluteDate.of(pointInTimeTo))
					.stream()
					.map(d -> new VDSDeclaration(d.getDeclCode(), plotCode, d.getAreaPerc(), d.getLanduse().getCode())) // d.getLanduse() can not bu null
					.collect(toList());
			return new VDSPlot(plotCode, domainZoneId, plot.getAreaSqm(), plot.getGeom(), plotLandCoverCodes, decls);
		} else
			return null;
	}

	@Override
	public List<PermanentCropForm> getPermanentCropForms(String declCode, String plotCode) {
		return cropPlansDAO.getPermanentCropForms(Arrays.asList(declCode), plotCode, cropPlanId, versionDt)
				.stream()
				.map(pcf -> (PermanentCropForm) pcf)
				.collect(toList());
	}

	@Override
	public List<PermanentCropFormFieldValue> getPermanentCropFormFieldsValues(String formType) {
		return cropPlansDAO.getPermanentCropFormFieldsValues(env.getTenantId(), env.getLocale().getLanguage(), cropPlanId, formType);
	}

	@Override
	public List<PermanentCropFormConfig> getPermanentCropFormConfig(String landUseCode, LocalDate pointInTime, String businessId) {
		try {
			LandUseDetails landUseDetails = this.getLandUseDetails(landUseCode, null, pointInTime, businessId);
			if (null == landUseDetails) {
				return new ArrayList<>();
			} else {
				return landUseDetails.getFormsConfig();
			}
		} catch (LandUseCodeNotFoundException | BadRequestException exception) {
			return new ArrayList<>(); // TODO
		}
	}

	@Override
	public List<LandUseAdditionalDataConf> getLandUseCodeFieldsConf(String landUseCode, LocalDate pointInTime, String businessId) {
		return cropCodeService.getLandUseCodeFieldsConf(this.env, businessId, this.cropPlanId, landUseCode, AbsoluteDate.of(pointInTime));
	}

	@Override
	public LocalDate getReferenceDate(LocalDate pointInTime) {
		return cropPlanConfigService.getSnapFromDate(cropPlanId, AbsoluteDate.of(pointInTime)).toLocalDate();
	}

	@Override
	public Double getPerimeterMultiplierAreaTolerance() {
		return cropPlanConfigService.getPerimeterMultiplierAreaTolerance(cropPlanId);
	}

	public List<CropPlanConfigData> getCropPlanConfig(Long cropPlanId, String paramName, String paramValue) {
		return cropPlanConfigService.getCropPlanConfig(cropPlanId, paramName, paramValue);
	}

	@Override
	public List<LandUseClass> getLandUseClassOptions(List<String> landUseClass, String businessId) {
		var cropPlanTypeCode = cropPlansDAO.getCropPlanInternal(businessId, cropPlanId, env.getTenantId()).getCropPlanTypeCode();
		return cropPlansDAO.getLandUseClassOptions(env.getTenantId(), cropPlanTypeCode, landUseClass);
	}

	@Override
	public Boolean checkLandUseAvailability(String landuseCode, List<String> landCoverCodes, LocalDate pointInTime, String businessId) {
		var isLandUseAvailable = true;
		try {
			var landUseCheck = this.getLandUseDetails(landuseCode, landCoverCodes, pointInTime, businessId);
			if (landUseCheck == null)
				isLandUseAvailable = false;
		} catch (LandUseCodeNotFoundException exception) {
			isLandUseAvailable = false;
		} catch (BadRequestException exception) {
			isLandUseAvailable = false;
		}
		return isLandUseAvailable;
	}

	@Override
	public Boolean isLandUseCompatible(String landUseCode, String landCoverCode, String businessId, boolean forceCompatibilityCheck) {
		return cropCodeService.isLandUseCompatible(this.env, businessId, this.cropPlanId, landUseCode, landCoverCode, forceCompatibilityCheck);
	}

	@Override
	public LandUseDetails getLandUseDetails(String landUseCode, List<String> landCoverCodes, LocalDate pointInTime, String businessId) {
		try {
			return cropCodeService.getLandUseCode(this.env, businessId, this.cropPlanId, landUseCode, landCoverCodes, AbsoluteDate.of(pointInTime));
		} catch (LandUseCodeNotFoundException | BadRequestException exception) {
			return null; // TODO
		}
	}

	@Override
	public LocalDateTime getVersionDt() {
		return versionDt;
	}

	@Override
	public boolean isCalculateAtPreviousVersion() {
		return calculateAtPreviousVersion;
	}
}
