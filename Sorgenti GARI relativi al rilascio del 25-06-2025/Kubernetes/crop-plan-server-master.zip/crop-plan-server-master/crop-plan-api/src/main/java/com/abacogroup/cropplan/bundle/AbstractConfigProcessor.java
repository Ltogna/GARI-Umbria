package com.abacogroup.cropplan.bundle;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.fasterxml.jackson.databind.ObjectMapper;

public abstract class AbstractConfigProcessor implements ConfigMessageProcessor
{
	protected static final String TEMPLATE_TENANT_ID = "*";

	protected final ObjectMapper objectMapper = new ObjectMapper();
	protected final CropPlanConfigDAO configDAO;


	public AbstractConfigProcessor(CropPlanConfigDAO configDAO)
	{
		this.configDAO = configDAO;
	}

	@Override
	public void onMessage(ConfigDataMessage message)
	{
		configDAO.useTransaction(dao -> {
			onMessageInTransaction(dao, message);
		});
	}

	protected abstract void onMessageInTransaction(CropPlanConfigDAO dao, ConfigDataMessage message);
}
