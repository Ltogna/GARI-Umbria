package com.abacogroup.cropplan.services;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

import com.abacogroup.cropplan.api.CropPlanLandUse;
import com.abacogroup.cropplan.api.LandUseAdditionalDataFieldForSavePlot;
import com.abacogroup.cropplan.api.PermanentCropFormSave;
import com.abacogroup.cropplan.api.PlanHasDeclarationsForLandUse;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.PlotDeclaration;
import com.abacogroup.cropplan.api.PlotEditability;
import com.abacogroup.cropplan.api.SortDeclaration;
import com.abacogroup.cropplan.db.dao.CacheDecodesDAO;
import com.abacogroup.cropplan.db.dao.CacheDecodesDAO.CACHE_DECODES_TYPE;
import com.abacogroup.cropplan.db.dao.CacheLandCoverCompatibilityDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.db.dao.PlotEditDAO;
import com.abacogroup.cropplan.db.dao.ValidatorDAO;
import com.abacogroup.cropplan.db.dao.ntt.DeclarationData;
import com.abacogroup.cropplan.db.dao.ntt.LandCoverAndTypeId;
import com.abacogroup.cropplan.db.dao.ntt.LandCoverCompatibilityCacheEntry;
import com.abacogroup.cropplan.db.dao.ntt.ParcelCodeWithPointInTime;
import com.abacogroup.cropplan.db.dao.ntt.PermanentCropFormWithDeclCode;
import com.abacogroup.cropplan.db.dao.ntt.PlotData;
import com.abacogroup.cropplan.db.dao.ntt.SavePlotDatas;
import com.abacogroup.cropplan.db.mappings.LandCoverCompatibilityCacheMappings;
import com.abacogroup.cropplan.db.ntt.CacheDecodeNTT;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataFieldWithPlotCode;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.PermanentCropForm;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandCoverClassEditability;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.cropcodes.Style;
import com.abacogroup.cropplan.sdk.model.domain.ParcelDescription;
import com.abacogroup.cropplan.sdk.model.validation.AnomalyObjectType;
import com.abacogroup.cropplan.sdk.spi.CropCodesPlugin;
import com.abacogroup.cropplan.sdk.spi.DomainPlugin;
import com.abacogroup.cropplan.sdk.spi.ProjectionTransformerPlugin;
import com.abacogroup.distributedlocks.Lock;
import com.abacogroup.distributedlocks.LockManager;
import com.abacogroup.geometryeditor.GeometryTransform;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.google.common.collect.Iterators;
import com.google.common.collect.UnmodifiableIterator;
import jakarta.ws.rs.BadRequestException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import org.locationtech.jts.geom.Geometry;

public class DeclarationService {
	private final CropPlanConfigService cropPlanConfigService;
	private final CropCodeService cropCodeService;
	private final CropPlansDAO cropPlansDAO;
	private final PlotEditDAO plotEditDAO;
	private final DeclarationsDAO declarationsDAO;
	private final CacheDecodesDAO cacheDecodesDAO;
	private final ValidatorDAO validatorDAO;
	private final PluginManager pluginManager;
	private final CacheLandCoverCompatibilityDAO cacheLandCoverCompatibilityDAO;
	private final LockManager lockManager;

	public DeclarationService(CropPlanConfigService cropPlanConfigService, CropCodeService cropCodeService,
			DAOContainer daoContainer, PluginManager pluginManager, LockManager lockManager) {
		this.cropPlanConfigService = cropPlanConfigService;
		this.cropCodeService = cropCodeService;
		this.cropPlansDAO = daoContainer.getCropPlansDAO();
		this.plotEditDAO = daoContainer.getPlotEditDAO();
		this.cacheDecodesDAO = daoContainer.getCacheDecodesDAO();
		this.validatorDAO = daoContainer.getValidatorDAO();
		this.declarationsDAO = daoContainer.getDeclarationsDAO();
		this.pluginManager = pluginManager;
		this.cacheLandCoverCompatibilityDAO = daoContainer.getCacheLandCoverCompatibilityDAO();
		this.lockManager = lockManager;
	}

	public void processDeclarationDatasForModifiedPlot(SavePlotDatas savePlotDatas, RuntimeEnvironment env,
			Integer newArea, Integer oldArea, String plotCode, Long cropPlanId,
			AbsoluteDate pointInTime, AbsoluteDate maximumDayTo, LocalDateTime insertDt, LocalDateTime deleteDt) {
		if (cropPlanConfigService.isDoNotReproportionDeclsAreas(cropPlanId)) {
			var decls = declarationsDAO.getDeclarationDatas(cropPlanId, plotCode, insertDt, pointInTime, maximumDayTo);
			decls.forEach(decl -> {
				var ddToBeUpdated = decl.toBuilder().build();
				ddToBeUpdated.setNew(false);
				ddToBeUpdated.setDeleteDt(deleteDt);
				ddToBeUpdated.setDeleteUserId(env.getUserId());
				savePlotDatas.getDeclarationDatas().add(ddToBeUpdated);

				var declId = plotEditDAO.getDeclarationsSeq();
				ddToBeUpdated = decl.toBuilder().build();
				ddToBeUpdated.setNew(true);
				ddToBeUpdated.setDeclId(declId);
				ddToBeUpdated.setAreaPerc(Math.round(ddToBeUpdated.getAreaPerc() * oldArea) * 1d / newArea);
				ddToBeUpdated.setInsertUserId(env.getUserId());
				ddToBeUpdated.setInsertDt(insertDt);
				savePlotDatas.getDeclarationDatas().add(ddToBeUpdated);
			});
		}
	}

	public void processDeclarationDatasForNewPlotWithParent(SavePlotDatas savePlotDatas, RuntimeEnvironment env,
			PlotData plotData, PlotData parentPlot, String businessId, Long cropPlanId,
			AbsoluteDate pointInTime, AbsoluteDate maximumDayTo, LocalDateTime insertDt,
			String landCoverCode) {
		var ignoreCropPlanConstraintsDeclsToPlots = cropPlanConfigService
				.isIgnoreCropPlanConstraintsDeclsToPlots(cropPlanId);
		var doNotReproportionDeclsAreas = cropPlanConfigService.isDoNotReproportionDeclsAreas(cropPlanId);
		String plotCode = plotData.getPlotCode();
		String parentPlotCode = parentPlot.getPlotCode();

		var decls = declarationsDAO.getDeclarationDatas(cropPlanId, parentPlotCode, insertDt, pointInTime,
				maximumDayTo);
		decls.forEach(decl -> {
			if (landCoverCode != null && !cropCodeService.isLandUseCompatible(env, businessId, cropPlanId,
					decl.getLandUseCode(), landCoverCode))
				return;

			var declId = plotEditDAO.getDeclarationsSeq();
			var dayFrom = (decl.getDayFrom().isBefore(pointInTime) && !ignoreCropPlanConstraintsDeclsToPlots)
					? pointInTime
					: decl.getDayFrom();
			var dayTo = (decl.getDayTo().isAfter(maximumDayTo) && !ignoreCropPlanConstraintsDeclsToPlots)
					? maximumDayTo
					: decl.getDayTo();
			var ddToBeDuplicated = decl.toBuilder().build();
			ddToBeDuplicated.setNew(true);
			ddToBeDuplicated.setDeclId(declId);
			ddToBeDuplicated.setDeclCode(String.valueOf(declId));
			ddToBeDuplicated.setPlotCode(plotCode);
			ddToBeDuplicated.setDayFrom(dayFrom);
			ddToBeDuplicated.setDayTo(dayTo);
			if (doNotReproportionDeclsAreas)
				ddToBeDuplicated.setAreaPerc(Math.round(ddToBeDuplicated.getAreaPerc() * parentPlot.getAreaSqm()) * 1d
						/ plotData.getAreaSqm());
			ddToBeDuplicated.setInsertUserId(env.getUserId());
			ddToBeDuplicated.setInsertDt(insertDt);

			var pcfs = cropPlansDAO.getPermanentCropForms(Arrays.asList(decl.getDeclCode()), parentPlotCode, cropPlanId,
					insertDt);
			pcfs.forEach(pcf -> {
				PermanentCropForm pcfToBeDuplicated = pcf.toBuilder().build();
				pcfToBeDuplicated.setFormCode(null);

				PermanentCropFormSave pcfsSaveToBeDuplicated = new PermanentCropFormSave();
				pcfsSaveToBeDuplicated.setPcf(pcfToBeDuplicated);
				pcfsSaveToBeDuplicated.setNew(true);
				pcfsSaveToBeDuplicated.setDeclCode(ddToBeDuplicated.getDeclCode());
				pcfsSaveToBeDuplicated.setPlotCode(plotCode);
				pcfsSaveToBeDuplicated.setCropPlanId(cropPlanId);
				pcfsSaveToBeDuplicated.setUserId(env.getUserId());
				pcfsSaveToBeDuplicated.setSaveDt(insertDt);

				/*
				 * var pcfd = pcfsSaveToBeDuplicated.getPcf().getPermanentCropFormData(); if(pcf.getPermanentCropFormData().getAreaSqm() != null)
				 * pcfd.setAreaSqm(pcf.getPermanentCropFormData().getAreaSqm() * plotData.getAreaSqm() / parentPlot.getAreaSqm());
				 */

				savePlotDatas.getPermanentCropFormSaveDatas().add(pcfsSaveToBeDuplicated);
			});

			// Additional declaration fields
			List<LandUseAdditionalDataFieldWithPlotCode> fcsToDup = cropPlansDAO.getLandUseAdditionalDeclarationFields(
					env.getTenantId(), env.getLocale().getLanguage(), parentPlotCode, cropPlanId,
					Arrays.asList(decl.getDeclCode()), insertDt);

			fcsToDup.forEach(fc -> {
				LandUseAdditionalDataFieldForSavePlot fcToDup = new LandUseAdditionalDataFieldForSavePlot(fc);
				fcToDup.setNew(true);
				fcToDup.setDeclCode(ddToBeDuplicated.getDeclCode());
				fcToDup.setCropPlanId(cropPlanId);
				fcToDup.setPlotCode(plotCode);
				fcToDup.setLandUseCode(ddToBeDuplicated.getLandUseCode());
				fcToDup.setUserId(env.getUserId());
				fcToDup.setSaveDt(insertDt);

				savePlotDatas.getFieldsCodes().add(fcToDup);
			});

			savePlotDatas.getDeclarationDatas().add(ddToBeDuplicated);
		});
	}

	public void processDefaultDeclarationDatasForNewPlot(SavePlotDatas savePlotDatas, RuntimeEnvironment env,
			String plotCode, String defaultLandUseCode, Long cropPlanId, AbsoluteDate pointInTime,
			AbsoluteDate maximumDayTo, LocalDateTime insertDt) {
		savePlotDatas.getDeclarationDatas().add(new DeclarationData(true, null, null, cropPlanId, plotCode,
				pointInTime, "YMD", maximumDayTo, defaultLandUseCode, 100d, env.getUserId(), null, insertDt,
				LocalDateTime.of(9999, 12, 31, 0, 0)));
	}

	public void processDeclarationDatasForMergedPlot(SavePlotDatas savePlotDatas, RuntimeEnvironment env,
			String plotCode, List<String> mergedPlots, boolean preserveDeclarations, Long cropPlanId,
			AbsoluteDate pointInTime, AbsoluteDate maximumDayTo, LocalDateTime insertDt, LocalDateTime deleteDt) {
		if (preserveDeclarations) {
			preserveDeclarationDatasForMergedPlot(savePlotDatas, env, plotCode, mergedPlots, cropPlanId, pointInTime,
					maximumDayTo, insertDt, deleteDt);
		} else {
			var decls = declarationsDAO.getDeclarationDatas(cropPlanId, plotCode, insertDt, pointInTime, maximumDayTo);
			decls.forEach(decl -> {
				processDeclForMergedPlot(savePlotDatas, env, plotCode, cropPlanId, pointInTime, insertDt, deleteDt,
						false /* unused */, decl, false);
			});
		}
	}

	public void preserveDeclarationDatasForMergedPlot(SavePlotDatas savePlotDatas, RuntimeEnvironment env,
			String plotCode, List<String> mergedPlots, Long cropPlanId,
			AbsoluteDate pointInTime, AbsoluteDate maximumDayTo, LocalDateTime insertDt, LocalDateTime deleteDt) {
		var oldPlotData = getPlotDatas(cropPlanId, plotCode, pointInTime, pointInTime);
		if (oldPlotData.isEmpty())
			throw new BadRequestException("The plot " + plotCode + " was not found");

		var ignoreCropPlanConstraintsDeclsToPlots = cropPlanConfigService
				.isIgnoreCropPlanConstraintsDeclsToPlots(cropPlanId);
		var doNotReproportionDeclsAreas = cropPlanConfigService.isDoNotReproportionDeclsAreas(cropPlanId);

		var declsDataToBeMerged = new ArrayList<DeclarationData>();
		var decls = declarationsDAO.getDeclarationDatas(cropPlanId, plotCode, insertDt, pointInTime, maximumDayTo);
		decls.forEach(decl -> {
			processDeclForMergedPlot(savePlotDatas, env, plotCode, cropPlanId, pointInTime, insertDt, deleteDt,
					ignoreCropPlanConstraintsDeclsToPlots, decl, true);
		});

		Map<PlotData, List<DeclarationData>> plotsWithDecls = new HashMap<>();
		Map<String, List<LandUseAdditionalDataField>> declsWithAdditFileds = new HashMap<>();
		var newAreaSqm = 0;
		for (var mp : mergedPlots) {
			var oldMergedPlotData = getPlotDatas(cropPlanId, mp, pointInTime, pointInTime);
			if (oldMergedPlotData.isEmpty())
				throw new BadRequestException("The plot " + plotCode + " was not found");
			newAreaSqm += oldMergedPlotData.get(0).getAreaSqm();

			var oldMergedDecls = declarationsDAO.getDeclarationDatas(cropPlanId, mp, insertDt, pointInTime,
					maximumDayTo);
			plotsWithDecls.put(oldMergedPlotData.get(0), oldMergedDecls);

			// Get Additional declaration fields codes
			for (DeclarationData oldDecl : oldMergedDecls) {
				List<LandUseAdditionalDataFieldWithPlotCode> fcs = cropPlansDAO.getLandUseAdditionalDeclarationFields(
						env.getTenantId(), env.getLocale().getLanguage(), mp, cropPlanId,
						Arrays.asList(oldDecl.getDeclCode()), insertDt);
				declsWithAdditFileds.put(oldDecl.getDeclCode(),
						fcs.stream().map(fc -> (LandUseAdditionalDataField) fc).collect(toList()));
			}

		}

		for (var e : plotsWithDecls.entrySet()) {
			for (var decl : e.getValue()) {
				mergeDecl(savePlotDatas, env, plotCode, cropPlanId, pointInTime, insertDt,
						ignoreCropPlanConstraintsDeclsToPlots, doNotReproportionDeclsAreas,
						declsDataToBeMerged, declsWithAdditFileds, newAreaSqm, e, decl);

			}
		}

		savePlotDatas.getDeclarationDatas().addAll(declsDataToBeMerged);
	}

	private void processDeclForMergedPlot(SavePlotDatas savePlotDatas, RuntimeEnvironment env, String plotCode,
			Long cropPlanId, AbsoluteDate pointInTime,
			LocalDateTime insertDt, LocalDateTime deleteDt, boolean ignoreCropPlanConstraintsDeclsToPlots,
			DeclarationData decl,
			boolean preserveDeclarations) {
		var ddToBeUpdated = decl.toBuilder().build();
		ddToBeUpdated.setDeleteDt(deleteDt);
		ddToBeUpdated.setDeleteUserId(env.getUserId());
		savePlotDatas.getDeclarationDatas().add(ddToBeUpdated);

		if (preserveDeclarations) {
			ddToBeUpdated = decl.toBuilder().build();
			ddToBeUpdated.setNew(true);
			ddToBeUpdated.setDeclId(null);
			ddToBeUpdated.setInsertUserId(env.getUserId());
			ddToBeUpdated.setInsertDt(insertDt);
			if (ddToBeUpdated.getDayFrom().isBefore(pointInTime) && !ignoreCropPlanConstraintsDeclsToPlots) {
				ddToBeUpdated.setDayTo(AbsoluteDate.of(pointInTime.toLocalDate().minusDays(1)));
				if (ddToBeUpdated.getDayFrom().isBeforeOrEqual(ddToBeUpdated.getDayTo()))
					savePlotDatas.getDeclarationDatas().add(ddToBeUpdated);
			}
			/*
			 * else { var oldAreaDecl = ddToBeUpdated.getAreaPerc() * oldPlotData.get(0).getAreaSqm() / 100; var newAreaPerc = 100 * oldAreaDecl / newAreaSqm;
			 * ddToBeUpdated.setAreaPerc(newAreaPerc); declsDataToBeMerged.add(ddToBeUpdated); }
			 */
		}

		var pcfsToBeDeleted = cropPlansDAO.getPermanentCropForms(Arrays.asList(decl.getDeclCode()), decl.getPlotCode(),
				cropPlanId, insertDt);
		pcfsToBeDeleted.forEach(pcf -> {
			PermanentCropFormSave pcfsSaveToBeDeleted = new PermanentCropFormSave();
			pcfsSaveToBeDeleted.setPcf(pcf);
			pcfsSaveToBeDeleted.setNew(false);
			pcfsSaveToBeDeleted.setDeclCode(decl.getDeclCode());
			pcfsSaveToBeDeleted.setPlotCode(plotCode);
			pcfsSaveToBeDeleted.setCropPlanId(cropPlanId);
			pcfsSaveToBeDeleted.setUserId(env.getUserId());
			pcfsSaveToBeDeleted.setSaveDt(deleteDt);

			savePlotDatas.getPermanentCropFormSaveDatas().add(pcfsSaveToBeDeleted);
		});

		List<LandUseAdditionalDataFieldWithPlotCode> fcToBeDeleted = cropPlansDAO.getLandUseAdditionalDeclarationFields(
				env.getTenantId(), env.getLocale().getLanguage(), decl.getPlotCode(), cropPlanId,
				Arrays.asList(decl.getDeclCode()), insertDt);

		fcToBeDeleted.forEach(fc -> {
			LandUseAdditionalDataFieldForSavePlot fcToDelete = new LandUseAdditionalDataFieldForSavePlot(fc);
			fcToDelete.setNew(false);
			fcToDelete.setDeclCode(decl.getDeclCode());
			fcToDelete.setCropPlanId(cropPlanId);
			fcToDelete.setPlotCode(plotCode);
			fcToDelete.setLandUseCode(decl.getLandUseCode());
			fcToDelete.setUserId(env.getUserId());
			fcToDelete.setSaveDt(deleteDt);

			savePlotDatas.getFieldsCodes().add(fcToDelete);
		});
	}

	private void mergeDecl(SavePlotDatas savePlotDatas, RuntimeEnvironment env, String plotCode, Long cropPlanId,
			AbsoluteDate pointInTime,
			LocalDateTime insertDt, boolean ignoreCropPlanConstraintsDeclsToPlots, boolean doNotReproportionDeclsAreas,
			ArrayList<DeclarationData> declsDataToBeMerged,
			Map<String, List<LandUseAdditionalDataField>> declsWithAdditFileds, int newAreaSqm,
			Entry<PlotData, List<DeclarationData>> e, DeclarationData decl) {
		var ddToBeMerged = decl.toBuilder().build();
		if (ddToBeMerged.getDayFrom().isAfterOrEqual(pointInTime) || ignoreCropPlanConstraintsDeclsToPlots) {
			var newAreaPerc = Math.round(ddToBeMerged.getAreaPerc() * e.getKey().getAreaSqm()) * 1d / newAreaSqm;

			var pcfsToBeMerged = cropPlansDAO.getPermanentCropForms(Arrays.asList(ddToBeMerged.getDeclCode()),
					ddToBeMerged.getPlotCode(), cropPlanId, insertDt);
			List<LandUseAdditionalDataField> additFieldsToBeMerged = declsWithAdditFileds
					.get(ddToBeMerged.getDeclCode()) != null ? declsWithAdditFileds.get(ddToBeMerged.getDeclCode())
							: new ArrayList<>();

			boolean found = updateMergedDecl(doNotReproportionDeclsAreas, declsDataToBeMerged, declsWithAdditFileds,
					ddToBeMerged, newAreaPerc, pcfsToBeMerged,
					additFieldsToBeMerged);

			if (!found) {
				ddToBeMerged.setNew(true);
				ddToBeMerged.setDeclId(null);
				ddToBeMerged.setPlotCode(plotCode);
				ddToBeMerged.setInsertUserId(env.getUserId());
				ddToBeMerged.setInsertDt(insertDt);
				if (doNotReproportionDeclsAreas)
					ddToBeMerged.setAreaPerc(
							Math.round(ddToBeMerged.getAreaPerc() * e.getKey().getAreaSqm()) * 1d / newAreaSqm);
				else
					ddToBeMerged.setAreaPerc(newAreaPerc);
				declsDataToBeMerged.add(ddToBeMerged);

				pcfsToBeMerged.forEach(pcf -> {
					PermanentCropForm pcfToBeMerged = pcf.toBuilder().build();
					pcfToBeMerged.setFormCode(null);

					PermanentCropFormSave pcfsSaveToBeMerged = new PermanentCropFormSave();
					pcfsSaveToBeMerged.setPcf(pcfToBeMerged);
					pcfsSaveToBeMerged.setNew(true);
					pcfsSaveToBeMerged.setDeclCode(ddToBeMerged.getDeclCode());
					pcfsSaveToBeMerged.setPlotCode(plotCode);
					pcfsSaveToBeMerged.setCropPlanId(cropPlanId);
					pcfsSaveToBeMerged.setUserId(env.getUserId());
					pcfsSaveToBeMerged.setSaveDt(insertDt);

					savePlotDatas.getPermanentCropFormSaveDatas().add(pcfsSaveToBeMerged);
				});

				// additional declaration fields
				additFieldsToBeMerged.forEach(fc -> {
					LandUseAdditionalDataFieldForSavePlot fcToSave = new LandUseAdditionalDataFieldForSavePlot(fc);
					fcToSave.setNew(true);
					fcToSave.setDeclCode(ddToBeMerged.getDeclCode());
					fcToSave.setCropPlanId(cropPlanId);
					fcToSave.setPlotCode(plotCode);
					fcToSave.setLandUseCode(ddToBeMerged.getLandUseCode());
					fcToSave.setUserId(env.getUserId());
					fcToSave.setSaveDt(insertDt);
					savePlotDatas.getFieldsCodes().add(fcToSave);
				});

			}
		}
	}

	private boolean updateMergedDecl(boolean doNotReproportionDeclsAreas,
			ArrayList<DeclarationData> declsDataToBeMerged,
			Map<String, List<LandUseAdditionalDataField>> declsWithAdditFileds, DeclarationData ddToBeMerged,
			double newAreaPerc,
			List<PermanentCropFormWithDeclCode> pcfsToBeMerged,
			List<LandUseAdditionalDataField> additFieldsToBeMerged) {
		if ((pcfsToBeMerged).isEmpty() && !doNotReproportionDeclsAreas) {
			for (var i = 0; i < declsDataToBeMerged.size(); i++) {
				var d = declsDataToBeMerged.get(i);

				// Check if the merged declarations have the same data for additional
				// declaration land use fields
				List<LandUseAdditionalDataField> additFieldsOfPreviousPlots = declsWithAdditFileds
						.get(d.getDeclCode()) != null ? declsWithAdditFileds.get(d.getDeclCode()) : new ArrayList<>();

				boolean mergedDeclsHaveSameAdditFields = additFieldsToBeMerged.size() == additFieldsOfPreviousPlots
						.size();
				mergedDeclsHaveSameAdditFields = mergedDeclsHaveSameAdditFields && (additFieldsOfPreviousPlots.stream()
						.filter(mfc -> !additFieldsToBeMerged.contains(mfc))
						.collect(toList())
						.isEmpty());

				if (declHaveSameData(d, ddToBeMerged) && mergedDeclsHaveSameAdditFields) {
					/*
					 * if (doNotReproportionDeclsAreas) d.setAreaPerc(d.getAreaPerc() + (ddToBeMerged.getAreaPerc()*e.getKey().getAreaSqm()/newAreaSqm)); else
					 */
					d.setAreaPerc(d.getAreaPerc() + newAreaPerc);
					return true;
				}
			}
		}
		return false;
	}

	public boolean compareDecl(List<Declaration> decls1, List<Declaration> decls2) {
		if (decls1.size() != decls2.size())
			return false;

		Set<Declaration> seen = new HashSet<>();

		for (int i = 0; i < decls1.size(); i++) {
			List<LandUseAdditionalDataField> additFieldsOfDeclOne = decls1.get(i).getFieldsCodes();

			DeclarationData dd1 = new DeclarationData();
			dd1.setLandUseCode(decls1.get(i).getLanduse().getCode());
			dd1.setDayFrom(decls1.get(i).getFromDate());
			dd1.setDayFromPrecision(decls1.get(i).getFromDatePrecision());
			dd1.setDayTo(decls1.get(i).getToDate());

			for (int j = 0; j < decls2.size(); j++) {
				if (seen.contains(decls2.get(j)))
					continue;

				List<LandUseAdditionalDataField> additFieldsOfDeclTwo = decls2.get(j).getFieldsCodes();

				DeclarationData dd2 = new DeclarationData();
				dd2.setLandUseCode(decls2.get(j).getLanduse().getCode());
				dd2.setDayFrom(decls2.get(j).getFromDate());
				dd2.setDayFromPrecision(decls2.get(j).getFromDatePrecision());
				dd2.setDayTo(decls2.get(j).getToDate());

				boolean declsHaveSameAdditFields = additFieldsOfDeclOne.size() == additFieldsOfDeclTwo.size();
				declsHaveSameAdditFields = declsHaveSameAdditFields && (additFieldsOfDeclTwo.stream()
						.filter(mfc -> !additFieldsOfDeclOne.contains(mfc))
						.collect(toList())
						.isEmpty());

				if (declHaveSameData(dd1, dd2) && declsHaveSameAdditFields) {
					seen.add(decls2.get(j));
					break;
				}
			}
		}

		if (seen.size() == decls1.size())
			return true;

		return false;
	}

	private boolean declHaveSameData(DeclarationData d, DeclarationData ddToBeMerged) {
		return d.getLandUseCode().equals(ddToBeMerged.getLandUseCode()) &&
				d.getDayFrom().equals(ddToBeMerged.getDayFrom()) &&
				d.getDayFromPrecision().equals(ddToBeMerged.getDayFromPrecision()) &&
				d.getDayTo().equals(ddToBeMerged.getDayTo());
	}

	public List<DeclarationData> processDeclarationDatasForDeletedPlot(SavePlotDatas savePlotDatas,
			RuntimeEnvironment env,
			String plotCode, Long cropPlanId, AbsoluteDate pointInTime, AbsoluteDate maximumDayTo,
			LocalDateTime insertDt,
			LocalDateTime deleteDt) {
		var ignoreCropPlanConstraintsDeclsToPlots = cropPlanConfigService
				.isIgnoreCropPlanConstraintsDeclsToPlots(cropPlanId);
		if (!ignoreCropPlanConstraintsDeclsToPlots) {
			var decls = declarationsDAO.getDeclarationDatas(cropPlanId, plotCode, insertDt, pointInTime, maximumDayTo);
			decls.forEach(decl -> {
				var ddToBeUpdated = decl.toBuilder().build();
				ddToBeUpdated.setNew(false);
				ddToBeUpdated.setDeleteDt(deleteDt);
				ddToBeUpdated.setDeleteUserId(env.getUserId());
				savePlotDatas.getDeclarationDatas().add(ddToBeUpdated);

				var dayTo = AbsoluteDate.of(pointInTime.toLocalDate().minusDays(1));
				if (decl.getDayFrom().isBeforeOrEqual(dayTo)) {
					ddToBeUpdated = decl.toBuilder().build();
					ddToBeUpdated.setNew(true);
					ddToBeUpdated.setDeclId(null);
					ddToBeUpdated.setDayTo(dayTo);
					ddToBeUpdated.setInsertUserId(env.getUserId());
					ddToBeUpdated.setInsertDt(insertDt);
					savePlotDatas.getDeclarationDatas().add(ddToBeUpdated);
				} else {
					var pcfs = cropPlansDAO.getPermanentCropForms(Arrays.asList(decl.getDeclCode()), plotCode,
							cropPlanId, insertDt);
					pcfs.forEach(pcf -> {
						PermanentCropFormSave pcfsSaveToBeDeleted = new PermanentCropFormSave();
						pcfsSaveToBeDeleted.setNew(false);
						pcfsSaveToBeDeleted.setDeclCode(decl.getDeclCode());
						pcfsSaveToBeDeleted.setCropPlanId(cropPlanId);
						pcfsSaveToBeDeleted.setPlotCode(plotCode);
						pcfsSaveToBeDeleted.setUserId(env.getUserId());
						pcfsSaveToBeDeleted.setSaveDt(deleteDt);
						pcfsSaveToBeDeleted.setPcf(pcf);
						savePlotDatas.getPermanentCropFormSaveDatas().add(pcfsSaveToBeDeleted);
					});

					// Additional declaration fields
					List<LandUseAdditionalDataFieldWithPlotCode> fcToBeDeleted = cropPlansDAO
							.getLandUseAdditionalDeclarationFields(
									env.getTenantId(), env.getLocale().getLanguage(), decl.getPlotCode(), cropPlanId,
									Arrays.asList(decl.getDeclCode()), insertDt);

					fcToBeDeleted.forEach(fc -> {
						LandUseAdditionalDataFieldForSavePlot fcToDelete = new LandUseAdditionalDataFieldForSavePlot(
								fc);
						fcToDelete.setNew(false);
						fcToDelete.setDeclCode(decl.getDeclCode());
						fcToDelete.setCropPlanId(cropPlanId);
						fcToDelete.setPlotCode(plotCode);
						fcToDelete.setLandUseCode(decl.getLandUseCode());
						fcToDelete.setUserId(env.getUserId());
						fcToDelete.setSaveDt(deleteDt);

						savePlotDatas.getFieldsCodes().add(fcToDelete);
					});
				}
			});
			return decls;
		}
		return new ArrayList<>();
	}

	public void addDefaultLandUseForChangedPlot(RuntimeEnvironment env, Plot plot, Long cropPlanId,
			String domainZoneId, AbsoluteDate pointInTime, LocalDateTime versionDt,
			String defaultLandUse) {
		var savePlotDatas = new SavePlotDatas(new ArrayList<>(), new ArrayList<>(), new ArrayList<>(),
				new ArrayList<>(), new ArrayList<>());

		savePlotDatas.getDeclarationDatas().add(new DeclarationData(true, null, null, cropPlanId, plot.getPlotCode(),
				pointInTime, "YMD", plot.getToDate(), defaultLandUse, 100d, env.getUserId(), null, versionDt,
				LocalDateTime.of(9999, 12, 31, 0, 0)));

		plotEditDAO.savePlotDatas(savePlotDatas, domainZoneId, null);
	}

	// unused
	/*
	 * public void checkAndFixDeclarationsForChangedPlot(RuntimeEnvironment env, String plotCode, Long cropPlanId, String businessId, String domainZoneId,
	 * AbsoluteDate pointInTime, LocalDateTime versionDt) { var deleteDt = versionDt.minus(Duration.ofMillis(1)); var savePlotDatas = new SavePlotDatas(new
	 * ArrayList<PlotData>(), new ArrayList<PlotDataParcel>(), new ArrayList<DeclarationData>(), new ArrayList<PermanentCropFormSave>());
	 * 
	 * var plot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId, versionDt, pointInTime, pointInTime, plotCode); if (plot == null) return;
	 * var landCoverCodes = plot.getParcelIntersections().stream() .map(ParcelIntersection::getLandCoverCode) .distinct() .collect(toList());
	 * 
	 * var decls = cropPlansDAO.getDeclarationDatas(cropPlanId, plotCode, versionDt, pointInTime, AbsoluteDate.of("99991231")); decls.forEach(decl -> { boolean
	 * isCompatible = landCoverCodes.size() == 1 && cropCodeService.isLandUseCompatible(env, businessId, cropPlanId, decl.getLandUseCode(),
	 * landCoverCodes.get(0)); if (!isCompatible) { var ddToBeUpdated = decl.toBuilder().build(); ddToBeUpdated.setNew(false);
	 * ddToBeUpdated.setDeleteDt(deleteDt); ddToBeUpdated.setDeleteUserId(env.getUserId()); savePlotDatas.getDeclarationDatas().add(ddToBeUpdated);
	 * 
	 * var dayTo = AbsoluteDate.of(pointInTime.get().minusDays(1)); if (decl.getDayFrom().compareTo(dayTo) <= 0) { ddToBeUpdated = decl.toBuilder().build();
	 * ddToBeUpdated.setNew(true); ddToBeUpdated.setDeclId(null); ddToBeUpdated.setDayTo(dayTo); ddToBeUpdated.setInsertUserId(env.getUserId());
	 * ddToBeUpdated.setInsertDt(versionDt); savePlotDatas.getDeclarationDatas().add(ddToBeUpdated); } } });
	 * 
	 * plotEditDAO.savePlotDatas(savePlotDatas, domainZoneId, versionDt); }
	 */

	public InfiniteListResults<PlotDeclaration> getDeclarations(RuntimeEnvironment env, Long cropPlanId,
			String businessId,
			AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo, LocalDateTime updateTimeFrom,
			LocalDateTime updateTimeTo, AbsoluteDate excludePlantedBefore, AbsoluteDate excludeHarvestedAfter,
			LocalDateTime versionDt, SortDeclaration sort, String search, List<String> landCoverCodes,
			String landUseCode, String parcelCode,
			List<String> declCodes, String anomaliesErrorCode, String srs, String nextKey, int pageSize, String domainZoneId) {

		var snapFromDate = cropPlanConfigService.getSnapFromDate(cropPlanId, pointInTimeFrom);
		var cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId());
		var domainPlugin = pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId());
		var projTransformerPlugin = pluginManager.getProjectionTransformerPlugin(businessId, cropPlanId,
				env.getTenantId());

		if (nextKey == null) {
			updateCacheDecodes(env, cropPlanId, businessId, pointInTimeFrom, pointInTimeTo, excludePlantedBefore,
					excludeHarvestedAfter, versionDt,
					snapFromDate, cropCodesPlugin, domainPlugin);
		}

		String orderBy;
		if (SortDeclaration.PARCEL == sort)
			orderBy = "parcelDescription, parcelCode, plotCode, toDate, areaPerc, landuseDescription, landUseCode, declCode";
		else
			orderBy = "landuseDescription, landUseCode, toDate, parcelDescription, parcelCode, plotCode, areaPerc, declCode";

		var decls = declarationsDAO.infinite(
				() -> declarationsDAO.getDeclarations(cropPlanId, versionDt, pointInTimeFrom, pointInTimeTo,
						updateTimeFrom != null ? 1 : 0, updateTimeFrom, updateTimeTo != null ? 1 : 0, updateTimeTo,
						excludePlantedBefore, excludeHarvestedAfter,
						CacheDecodesDAO.CACHE_DECODES_TYPE.LAND_USE.toString(),
						CacheDecodesDAO.CACHE_DECODES_TYPE.LAND_COVER_COMPATIBILITY.toString(),
						CacheDecodesDAO.CACHE_DECODES_TYPE.PARCEL.toString(),
						CacheDecodesDAO.CACHE_DECODES_TYPE.PARCEL_CODE.toString(),
						CacheDecodesDAO.CACHE_DECODES_TYPE.DOMAIN.toString(),
						landCoverCodes,
						landUseCode,
						parcelCode,
						declCodes,
						anomaliesErrorCode,
						search,
						orderBy,
						domainZoneId),
				nextKey,
				pageSize);

		decls.getRecords().forEach(d -> {
			fillDeclData(env, cropPlanId, businessId, pointInTimeFrom, pointInTimeTo, versionDt, snapFromDate,
					cropCodesPlugin, domainPlugin, d);
		});

		/*** load parcel descriptions from external plugin ***/
		fillParcelsDescriptionData(env, businessId, domainPlugin, decls);

		/*** load land cover descriptions from external plugin ***/
		fillLandCoversDescriptionData(env, cropCodesPlugin, decls);

		/*** load plot editability from external plugin ***/
		fillDeclsEditabilityData(env, businessId, cropCodesPlugin, decls);

		/*** convert geometries in the requested srs ***/
		convertDeclsGeoms(env, srs, projTransformerPlugin, decls);

		fillDeclPcfAndAdditionalFieldsData(env, cropPlanId, versionDt, decls);

		return decls;
	}

	private void fillDeclData(RuntimeEnvironment env, Long cropPlanId, String businessId, AbsoluteDate pointInTimeFrom,
			AbsoluteDate pointInTimeTo,
			LocalDateTime versionDt, AbsoluteDate snapFromDate, CropCodesPlugin cropCodesPlugin,
			DomainPlugin domainPlugin, PlotDeclaration d) {
		d.setAnomalies(validatorDAO.getAnomaliesByObjectType(cropPlanId, versionDt, d.getDeclCode(),
				AnomalyObjectType.DECLARATION,
				env.getTenantId(), env.getLocale().getLanguage()));
		d.setPlotAnomalies(
				validatorDAO.getAnomaliesByObjectType(cropPlanId, versionDt, d.getPlotCode(), AnomalyObjectType.PLOT,
						env.getTenantId(), env.getLocale().getLanguage()));

		var plots = declarationsDAO.maxRows(
				() -> declarationsDAO.getDeclarationPlotData(cropPlanId, d.getPlotCode(), versionDt, pointInTimeFrom,
						pointInTimeTo),
				1).getRecords();
		/*
		 * if (plots.isEmpty()) // if declaration has no plot in time interval (pointInTimeFrom-pointInTimeTo) load plot anyway { plots =
		 * declarationsDAO.maxRows( () -> declarationsDAO.getDeclarationPlotData(d.getPlotCode(), versionDt, d.getFromDate(), d.getToDate()), 1).getRecords(); }
		 */
		PlotDeclaration p = null;
		if (!plots.isEmpty()) {
			p = plots.get(0);
			d.setPlotId(p.getPlotId());
			d.setPlotDescription(p.getPlotDescription());
			d.setPlotAreaSqm(p.getPlotAreaSqm());
			d.setGeom(p.getGeom());
			d.setSrs(p.getSrs());
			d.setPlotFromDate(p.getPlotFromDate());
			d.setPlotToDate(p.getPlotToDate());
			d.setDomainZoneCode(p.getDomainZoneCode());

			var pesticidePlugin = this.pluginManager.getPesticidesPlugin(businessId, cropPlanId, env.getTenantId());
			var pi = cropPlansDAO.getPlotsParcelsInternal(Arrays.asList(p.getPlotId()), cropPlanId, versionDt);
			d.setParcelIntersections(pi.stream().map(m -> {
				m.setAnomalies(validatorDAO.getAnomaliesByObjectType(cropPlanId, versionDt, m.getCode(),
						AnomalyObjectType.PARCEL,
						env.getTenantId(), env.getLocale().getLanguage()));
				if (pesticidePlugin != null)
					m.setCanDeclarePesticides(pesticidePlugin.checkCanDeclarePesticidesOnParcel(env, m.getCode()));
				else
					m.setCanDeclarePesticides(false);
				return (ParcelIntersection) m;
			}).collect(toList()));

			/*** load MBR overview from external plugin ***/
			var parcelCodes = d.getParcelIntersections().stream()
					.map(ParcelIntersection::getCode)
					.collect(toList());
			Geometry mbrOverview = domainPlugin.getMBROverview(env, businessId, parcelCodes, d.getPlotFromDate().toLocalDate());
			if (mbrOverview == null)
				d.setMbrOverview(p.getGeom().getEnvelope());
			else
				d.setMbrOverview(mbrOverview);
		}

		/*** load land use style from external plugin ***/
		Map<String, Style> styles = cropCodesPlugin.getLandUseStyles(env, Arrays.asList(d.getLanduse().getCode()));
		d.setStyle(styles.get(d.getLanduse().getCode()));

		/*** load domain zone description from external plugin ***/
		d.setDomainZoneDescription(
				domainPlugin.getDomainZoneDescription(env, snapFromDate.toLocalDate(), d.getDomainZoneCode()));
	}

	private void fillParcelsDescriptionData(RuntimeEnvironment env, String businessId, DomainPlugin domainPlugin,
			InfiniteListResults<PlotDeclaration> decls) {
		Map<AbsoluteDate, List<PlotDeclaration>> declsByPlotToDate = decls.getRecords().stream()
				.filter(decl -> (decl.getParcelIntersections() != null && !decl.getParcelIntersections().isEmpty()))
				.collect(groupingBy(PlotDeclaration::getPlotToDate));

		declsByPlotToDate.keySet().forEach(toDate -> {
			Map<String, List<ParcelIntersection>> allParcelIntersectionsByParcelCode = declsByPlotToDate.get(toDate)
					.stream()
					.flatMap(d -> d.getParcelIntersections().stream())
					.collect(groupingBy(ParcelIntersection::getCode));

			UnmodifiableIterator<List<String>> partitionsOfParcelCodes = Iterators.partition(
					allParcelIntersectionsByParcelCode.keySet().iterator(),
					666);
			partitionsOfParcelCodes.forEachRemaining(partition -> {
				Map<String, ParcelDescription> parcelDescriptions = domainPlugin.getParcelsDescription(env, businessId,
						toDate.toLocalDate(), partition);
				parcelDescriptions.keySet().forEach(pc -> {
					allParcelIntersectionsByParcelCode.get(pc).forEach(parcelIntersection -> {
						parcelIntersection.setDescription(parcelDescriptions.get(pc).getDescription());
						parcelIntersection.setParcelCode(parcelDescriptions.get(pc).getParcelCode());
						parcelIntersection.setHoldingPercentage(parcelDescriptions.get(pc).getHoldingPercentage());
					});
				});
			});
		});
	}

	private void fillLandCoversDescriptionData(RuntimeEnvironment env, CropCodesPlugin cropCodesPlugin,
			InfiniteListResults<PlotDeclaration> decls) {
		Map<String, List<ParcelIntersection>> allParcelIntersectionsByLandCoverCode = decls.getRecords().stream()
				.filter(decl -> (decl.getParcelIntersections() != null && !decl.getParcelIntersections().isEmpty()))
				.flatMap(d -> d.getParcelIntersections().stream())
				.filter(parcel -> parcel.getLandCoverCode() != null)
				.collect(groupingBy(parcel -> parcel.getLandCoverCode()));

		UnmodifiableIterator<List<String>> partitionsOfLandCovers = Iterators.partition(
				allParcelIntersectionsByLandCoverCode.keySet().iterator(),
				666);
		partitionsOfLandCovers.forEachRemaining(partition -> {
			Map<String, String> landCoverDescriptions = cropCodesPlugin.getLandCoverDescriptions(env, partition);
			landCoverDescriptions.keySet()
					.forEach(landCoverCode -> allParcelIntersectionsByLandCoverCode.get(landCoverCode)
							.forEach(parcelIntersection -> parcelIntersection
									.setLandCoverDescription(landCoverDescriptions.get(landCoverCode))));
		});
	}

	private void fillDeclsEditabilityData(RuntimeEnvironment env, String businessId, CropCodesPlugin cropCodesPlugin,
			InfiniteListResults<PlotDeclaration> decls) {
		Map<String, LandCoverClassEditability> editabilities = new HashMap<>();
		decls.getRecords().forEach(d -> {
			d.setEditability(PlotEditability.EDITABLE);
			if (d.getParcelIntersections() != null && !d.getParcelIntersections().isEmpty()) {
				fillDeclsEditabilityDataByParcelIntersections(env, businessId, cropCodesPlugin, editabilities, d);
			} else {
				var editability = editabilities.get(null);
				if (editability == null) {
					editability = cropCodesPlugin.getLandCoverEditability(env, businessId, null);
					editabilities.put(null, editability);
				}
				if (editability == LandCoverClassEditability.NOT_EDITABLE) {
					d.setEditability(PlotEditability.NOT_EDITABLE);
				} else if (editability == LandCoverClassEditability.ONLY_DECLARATIONS) {
					d.setEditability(PlotEditability.ONLY_DECLARATIONS);
				}
			}
		});
	}

	private void fillDeclsEditabilityDataByParcelIntersections(RuntimeEnvironment env, String businessId,
			CropCodesPlugin cropCodesPlugin,
			Map<String, LandCoverClassEditability> editabilities, PlotDeclaration d) {
		for (var parcel : d.getParcelIntersections()) {
			var editability = editabilities.get(parcel.getLandCoverCode());
			if (editability == null) {
				editability = cropCodesPlugin.getLandCoverEditability(env, businessId, parcel.getLandCoverCode());
				editabilities.put(parcel.getLandCoverCode(), editability);
			}
			if (editability == LandCoverClassEditability.NOT_EDITABLE) {
				d.setEditability(PlotEditability.NOT_EDITABLE);
				break;
			} else if (editability == LandCoverClassEditability.ONLY_DECLARATIONS) {
				d.setEditability(PlotEditability.ONLY_DECLARATIONS);
			}
		}
	}

	private void convertDeclsGeoms(RuntimeEnvironment env, String srs,
			ProjectionTransformerPlugin projTransformerPlugin,
			InfiniteListResults<PlotDeclaration> decls) {
		if (srs != null) {
			var gt = new GeometryTransform();
			decls.getRecords().forEach(d -> {
				try {
					if (projTransformerPlugin != null) {
						d.setGeom(projTransformerPlugin.transform(env, d.getGeom(), d.getSrs(), srs));
						d.setMbrOverview(projTransformerPlugin.transform(env, d.getMbrOverview(), d.getSrs(), srs)
								.getEnvelope());
					} else {
						d.setGeom(gt.transform(d.getGeom(), d.getSrs(), srs));
						d.setMbrOverview(gt.transform(d.getMbrOverview(), d.getSrs(), srs).getEnvelope());
					}
					d.setSrs(srs);
				} catch (Exception e) {
					// throw new IllegalStateException(e.getMessage());
				}
			});
		}
	}

	private void fillDeclPcfAndAdditionalFieldsData(RuntimeEnvironment env, Long cropPlanId, LocalDateTime versionDt,
			InfiniteListResults<PlotDeclaration> decls) {
		if (!decls.getRecords().isEmpty()) {
			List<String> dcs = decls.getRecords().stream()
					.map(d -> d.getDeclCode())
					.collect(toList());

			/*** Find PermanentCropForms for each declaration (if there is one or more) ***/
			List<PermanentCropFormWithDeclCode> pcfs = cropPlansDAO.getPermanentCropForms(dcs, null, cropPlanId,
					versionDt);
			Map<String, List<PermanentCropFormWithDeclCode>> pcfsMap = pcfs.stream()
					.collect(groupingBy(PermanentCropFormWithDeclCode::getPlotCodeDeclCodeKey));

			List<LandUseAdditionalDataFieldWithPlotCode> luAddDeclFields = cropPlansDAO
					.getLandUseAdditionalDeclarationFields(env.getTenantId(), env.getLocale().getLanguage(), null,
							cropPlanId, dcs, versionDt);
			Map<String, List<LandUseAdditionalDataFieldWithPlotCode>> luAddDeclFieldsMap = luAddDeclFields.stream()
					.collect(groupingBy(LandUseAdditionalDataFieldWithPlotCode::getPlotCodeDeclCodeKey));

			decls.getRecords().forEach(d -> {
				List<PermanentCropFormWithDeclCode> declPcfs = pcfsMap.get(d.getPlotCodeDeclCodeKey());
				if (declPcfs != null) {
					d.setPermanentCropForms(declPcfs.stream()
							.map(pcf -> (PermanentCropForm) pcf)
							.collect(toList()));
				}

				// Add additional fields
				List<LandUseAdditionalDataFieldWithPlotCode> fieldCodes = luAddDeclFieldsMap
						.get(d.getPlotCodeDeclCodeKey());
				if (fieldCodes != null) {
					d.setFieldsCodes(fieldCodes.stream()
							.map(fc -> (LandUseAdditionalDataField) fc)
							.collect(toList()));
				}
			});
		}
	}

	private void updateCacheDecodes(RuntimeEnvironment env, Long cropPlanId, String businessId,
			AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo,
			AbsoluteDate excludePlantedBefore, AbsoluteDate excludeHarvestedAfter, LocalDateTime versionDt,
			AbsoluteDate snapFromDate,
			CropCodesPlugin cropCodesPlugin, DomainPlugin domainPlugin) {

		Optional<Lock> optLock = lockManager.aquire("crop-plan-api", "updateCacheDecodes", Duration.ofSeconds(10 * 60L), Duration.ofSeconds(10 * 60L));
		if (optLock.isPresent()) {
			try (Lock olc = optLock.get()) {
				cacheDecodesDAO.useTransaction(dao -> {

					Long cropPlanTypeId = cacheDecodesDAO.findCropPlanTypeId(cropPlanId);
					LocalDateTime cacheDt = cacheDecodesDAO.getCurrentTimestamp();
					LocalDateTime cacheValidityDt = cacheDt.minusDays(2);

					// -- CacheDecodes -- //
					cacheDecodesDAO.clearCacheDecodes(List.of(
							CacheDecodesDAO.CACHE_DECODES_TYPE.LAND_USE.toString(),
							CacheDecodesDAO.CACHE_DECODES_TYPE.PARCEL_CODE.toString(),
							CacheDecodesDAO.CACHE_DECODES_TYPE.PARCEL.toString(),
							CacheDecodesDAO.CACHE_DECODES_TYPE.DOMAIN.toString()
					), cacheValidityDt, cropPlanTypeId);

					List<CacheDecodeNTT> newCacheDecodeNTTS = new ArrayList<>();

					newCacheDecodeNTTS.addAll(this.getLandUseNewCacheDecodes(env, cropPlanId, pointInTimeFrom, pointInTimeTo,
							excludePlantedBefore, excludeHarvestedAfter, versionDt, cropCodesPlugin, cacheDt, cropPlanTypeId));
					newCacheDecodeNTTS.addAll(this.getParcelAndParcelCodeNewCacheDecodes(env, cropPlanId, businessId, pointInTimeFrom, pointInTimeTo,
							versionDt, domainPlugin, cacheDt, cropPlanTypeId));
					newCacheDecodeNTTS.addAll(this.getDomainNewCacheDecodes(env, cropPlanId, pointInTimeFrom, pointInTimeTo, versionDt, snapFromDate,
							domainPlugin, cacheDt, cropPlanTypeId));

					if (!newCacheDecodeNTTS.isEmpty()) {
						cacheDecodesDAO.insertCacheDecodes(newCacheDecodeNTTS.toArray(new CacheDecodeNTT[0]));
					}

					// -- CacheLandCoverCompatibility -- //
					cacheLandCoverCompatibilityDAO.clearCacheLandCoverCompatibility(cacheValidityDt, cropPlanTypeId);

					List<LandCoverCompatibilityCacheEntry> newLandCoverCompatibilityCacheEntries = new ArrayList<>();

					newLandCoverCompatibilityCacheEntries.addAll(this.getLandCoverCompatibilityNewCacheEntries(env, cropPlanId,
							pointInTimeFrom, pointInTimeTo, versionDt, cropCodesPlugin, cacheDt));

					if (!newLandCoverCompatibilityCacheEntries.isEmpty()) {
						cacheLandCoverCompatibilityDAO.insertCacheLandCoverCompatibility(newLandCoverCompatibilityCacheEntries.iterator());
					}

				});
			} catch (Exception e) {
				throw new RuntimeException("Error lock updateCacheDecodes", e);
			}
		}
	}

	private List<CacheDecodeNTT> getDomainNewCacheDecodes(RuntimeEnvironment env, Long cropPlanId, AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo, LocalDateTime versionDt,
			AbsoluteDate snapFromDate, DomainPlugin domainPlugin, LocalDateTime cacheDt, Long cropPlanTypeId) {
		List<String> cacheDomainCodesNotIn = declarationsDAO.getDeclarationsDomainCodesNotInCache(cropPlanId, versionDt, pointInTimeFrom,
				pointInTimeTo, CACHE_DECODES_TYPE.DOMAIN.toString());

		if (!cacheDomainCodesNotIn.isEmpty()) {
			List<CacheDecodeNTT> cacheDecodeNTTS = cacheDomainCodesNotIn.stream()
					.map(dc -> {
						String domainZoneDescription = domainPlugin.getDomainZoneDescription(env, snapFromDate.toLocalDate(), dc);
						return new CacheDecodeNTT(
								CACHE_DECODES_TYPE.DOMAIN.toString(),
								cacheDt,
								dc,
								domainZoneDescription,
								cropPlanTypeId
						);
					}).toList();

			return cacheDecodeNTTS;
		} else {
			return new ArrayList<>();
		}
	}

	private List<CacheDecodeNTT> getParcelAndParcelCodeNewCacheDecodes(RuntimeEnvironment env, Long cropPlanId, String businessId, AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo,
			LocalDateTime versionDt, DomainPlugin domainPlugin, LocalDateTime cacheDt, Long cropPlanTypeId) {

		List<ParcelCodeWithPointInTime> cacheParcelCodesNotIn = declarationsDAO.getDeclarationsParcelCodesNotInCache(
				cropPlanId, versionDt, pointInTimeFrom, pointInTimeTo, CACHE_DECODES_TYPE.PARCEL.toString());

		if (!cacheParcelCodesNotIn.isEmpty()) {
			Map<AbsoluteDate, List<ParcelCodeWithPointInTime>> parcelsAtPointInTime = cacheParcelCodesNotIn.stream()
					.collect(groupingBy(ParcelCodeWithPointInTime::getPointInTime));

			List<CacheDecodeNTT> cacheDecodeNTTS = new ArrayList<>();
			parcelsAtPointInTime.keySet().forEach(pointInTime -> {
				List<String> parcelCodes = parcelsAtPointInTime.get(pointInTime).stream()
						.map(ParcelCodeWithPointInTime::getParcelCode)
						.collect(toList());
				Map<String, ParcelDescription> cacheParcelDescriptions = domainPlugin.getParcelsDescription(env,
						businessId, pointInTime.toLocalDate(), parcelCodes);

				cacheParcelDescriptions.keySet().forEach(pc -> {
					String code = pointInTime.toString() + "|" + pc;
					cacheDecodeNTTS.add(new CacheDecodeNTT(
							CACHE_DECODES_TYPE.PARCEL.toString(), cacheDt, code,
							cacheParcelDescriptions.get(pc).getDescription(), cropPlanTypeId));
					cacheDecodeNTTS.add(new CacheDecodeNTT(
							CACHE_DECODES_TYPE.PARCEL_CODE.toString(), cacheDt, code,
							cacheParcelDescriptions.get(pc).getParcelCode(), cropPlanTypeId));
				});
			});

			return cacheDecodeNTTS;
		} else {
			return new ArrayList<>();
		}
	}

	private List<LandCoverCompatibilityCacheEntry> getLandCoverCompatibilityNewCacheEntries(RuntimeEnvironment env, Long cropPlanId, AbsoluteDate pointInTimeFrom,
			AbsoluteDate pointInTimeTo, LocalDateTime versionDt, CropCodesPlugin cropCodesPlugin, LocalDateTime cacheDt) {

		List<LandCoverAndTypeId> cacheLandCoverCodesNotIn = declarationsDAO.getDeclarationsLandCoverCodesNotInCache(
				cropPlanId, versionDt, pointInTimeFrom, pointInTimeTo);

		if (!cacheLandCoverCodesNotIn.isEmpty()) {
			List<LandCoverCompatibilityCacheEntry> entries = new ArrayList<>();

			for (LandCoverAndTypeId landCoverCodeAndTypeId : cacheLandCoverCodesNotIn) {
				var typeId = landCoverCodeAndTypeId.getTypeId();
				var landCoverCode = landCoverCodeAndTypeId.getLandCoverCode();
				var cacheLandUsesCodes = cropCodesPlugin.getLandUseCodesByLandCoverCode(env, landCoverCode);

				for (String landUseCode : cacheLandUsesCodes) {
					entries.add(LandCoverCompatibilityCacheMappings.map(typeId, cacheDt, landCoverCode,
							landUseCode));
				}
			}

			return entries;
		} else {
			return new ArrayList<>();
		}
	}

	private List<CacheDecodeNTT> getLandUseNewCacheDecodes(RuntimeEnvironment env, Long cropPlanId, AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo,
			AbsoluteDate excludePlantedBefore, AbsoluteDate excludeHarvestedAfter, LocalDateTime versionDt, CropCodesPlugin cropCodesPlugin,
			LocalDateTime cacheDt, Long cropPlanTypeId) {
		List<String> cacheLandUseCodeNotIn = declarationsDAO.getDeclarationsLandUseCodesNotInCache(cropPlanId, versionDt, pointInTimeFrom,
				pointInTimeTo, excludePlantedBefore, excludeHarvestedAfter, CACHE_DECODES_TYPE.LAND_USE.toString());

		if (!cacheLandUseCodeNotIn.isEmpty()) {

			List<LandUse> cacheLandUses = cropCodesPlugin.getLandUses(env, cacheLandUseCodeNotIn);
			List<CacheDecodeNTT> cacheDecodeNTTS = cacheLandUses.stream().map(lu -> new CacheDecodeNTT(
					CACHE_DECODES_TYPE.LAND_USE.toString(),
					cacheDt,
					lu.getCode(),
					lu.getDescription(),
					cropPlanTypeId
			)).toList();

			return cacheDecodeNTTS;
		} else {
			return new ArrayList<>();
		}
	}



	public List<LandUse> getDeclarationsLandUses(RuntimeEnvironment env, Long cropPlanId, String businessId,
			AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo, LocalDateTime versionDt) {
		var cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId());

		var landUsesCodes = declarationsDAO.getDeclarationLandUsesCodes(cropPlanId, versionDt, pointInTimeFrom,
				pointInTimeTo);
		return cropCodesPlugin.getLandUses(env, landUsesCodes);
	}

	public List<CropPlanLandUse> getDeclarationsLandUsesWithArea(RuntimeEnvironment env, Long cropPlanId, String businessId,
			AbsoluteDate pointInTime, LocalDateTime versionDt) {
		var cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId());

		List<CropPlanLandUse> cropPlanLandUses = declarationsDAO.getDeclarationLandUsesCodesWithArea(cropPlanId, versionDt, pointInTime);
		List<String> landUseCodes = cropPlanLandUses.stream()
				.map(CropPlanLandUse::getCode)
				.collect(toList());
		List<LandUse> landUses = cropCodesPlugin.getLandUses(env, landUseCodes);

		Map<String, CropPlanLandUse> cropPlanLandUsesMap = cropPlanLandUses.stream()
				.collect(toMap(CropPlanLandUse::getCode, lu -> lu));
		landUses.forEach(lu -> cropPlanLandUsesMap.get(lu.getCode()).setDescription(lu.getDescription()));
		return new ArrayList<>(cropPlanLandUsesMap.values());
	}

	public List<ParcelDescription> getDeclarationsParcels(RuntimeEnvironment env, Long cropPlanId, String businessId,
			AbsoluteDate pointInTimeFrom, AbsoluteDate pointInTimeTo, LocalDateTime versionDt) {
		var domainPlugin = pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId());

		List<ParcelCodeWithPointInTime> parcels = declarationsDAO.getDeclarationParcels(cropPlanId, versionDt,
				pointInTimeFrom, pointInTimeTo);
		Map<AbsoluteDate, List<ParcelCodeWithPointInTime>> parcelsAtPointInTime = parcels.stream()
				.collect(groupingBy(ParcelCodeWithPointInTime::getPointInTime));

		List<ParcelDescription> parcelDescriptions = new ArrayList<>();
		parcelsAtPointInTime.keySet().forEach(pointInTime -> {
			List<String> parcelCodes = parcelsAtPointInTime.get(pointInTime).stream()
					.map(ParcelCodeWithPointInTime::getParcelCode)
					.collect(toList());
			parcelDescriptions.addAll(
					domainPlugin.getParcelsDescription(env, businessId, pointInTime.toLocalDate(), parcelCodes).values());
		});

		return parcelDescriptions.stream()
				.distinct()
				.collect(toList());
	}

	public LocalDateTime getDeclarationsLastModificationDate(RuntimeEnvironment env, String businessId, Long cropPlanId,
			List<String> landCoverCodes) {
		var cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId());

		List<String> landUseCodes = new ArrayList<>();
		for (String lcc : landCoverCodes) {
			landUseCodes.addAll(cropCodesPlugin.getLandUseCodesByLandCoverCode(env, lcc));
		}

		if (landUseCodes.isEmpty())
			throw new BadRequestException("Invalid land cover codes");

		landUseCodes = landUseCodes.stream()
				.distinct()
				.collect(toList());

		List<LocalDateTime> maxDates = new ArrayList<>();
		UnmodifiableIterator<List<String>> partitionsOfLandUseCodes = Iterators.partition(
				landUseCodes.iterator(),
				666);
		partitionsOfLandUseCodes.forEachRemaining(partition -> {
			var res = declarationsDAO.getDeclarationsLastModificationDate(cropPlanId, partition);
			if (res != null)
				maxDates.add(res);
		});

		return maxDates.stream().max(LocalDateTime::compareTo).orElse(null);
	}

	public PlanHasDeclarationsForLandUse getPlanHasDeclarationsForLandUse(RuntimeEnvironment env, String businessId,
			Long cropPlanId,
			LocalDateTime versionDt, AbsoluteDate pointInTime, List<String> landUseCodes) {
		PlanHasDeclarationsForLandUse planHasDeclarationsForLandUse = declarationsDAO
				.getPlanHasDeclarationsForLandUse(cropPlanId, versionDt, pointInTime, landUseCodes);

		return planHasDeclarationsForLandUse;
	}

	public List<PlotData> getPlotDatas(Long cropPlanId, String plotCode, AbsoluteDate pointInTimeFrom,
			AbsoluteDate pointInTimeTo) {
		return plotEditDAO.getPlotDatas(cropPlanId, plotCode, pointInTimeFrom, pointInTimeTo);
	}
}
