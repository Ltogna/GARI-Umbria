package com.abacogroup.cropplan.api;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PlanHasDeclarationsForLandUse 
{
	private Boolean hasDeclarations;
}
