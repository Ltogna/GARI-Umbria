package com.abacogroup.cropplan.resources.dtos;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Data
public class CalculateAnomaliesDto {
	@NotNull
	private AbsoluteDate referenceDt;
	@NotNull
	private List<CalculateAnomaliesPlotDto> plots;
}
