package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class DeclarationAdditionalFieldNotValidException extends WebApplicationException
{
	private static final long serialVersionUID = -1205943738478719157L;

	public static  class DeclarationAdditionalFieldNotValidExceptionErrorBody
	{
		@Schema(allowableValues = "DECLARATION_ADDITIONAL_FIELD_NOT_VALID_EXCEPTION")
		public String getErrorCode()
		{
			return "DECLARATION_ADDITIONAL_FIELD_NOT_VALID_EXCEPTION";
		}
	}

	private static final DeclarationAdditionalFieldNotValidExceptionErrorBody BODY = new DeclarationAdditionalFieldNotValidExceptionErrorBody();

	public DeclarationAdditionalFieldNotValidException(String landUseCode)
	{
		super(
				"Declaration additional fields for land use '"+landUseCode+"' are not valid",
			Response.status(Status.BAD_REQUEST).entity(BODY).build());
	}
}
