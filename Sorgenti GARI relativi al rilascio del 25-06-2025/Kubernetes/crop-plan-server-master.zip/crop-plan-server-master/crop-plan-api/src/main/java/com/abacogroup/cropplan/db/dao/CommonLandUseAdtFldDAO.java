package com.abacogroup.cropplan.db.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.cropplan.api.LandUseAdditFieldsWithValuesReadDto;
import com.abacogroup.cropplan.db.dao.support.DaoSupportParams;
import com.abacogroup.cropplan.sdk.mapper.VersionColumnMapper;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataConf;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataFieldWithPlotCode;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.annotations.CacheDefinition;
import com.abacogroup.jdbi.annotations.Cached;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(VersionColumnMapper.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface CommonLandUseAdtFldDAO extends EnhancedSqlObject, BasicDAO {

	@SqlQuery("§select_nextval(crpl_decl_addit_fields_seq)§")
	public Long getDeclAdditFieldsSeq();

	@SqlUpdate(""
			+ "insert into crpl_decl_addit_fields \n"
			+ "(id, plan_id, plot_code, decl_code, \n"
			+ " dt_insert, dt_delete, user_id_insert, user_id_delete, \n"
			+ " land_use_code, field_code, day_from, day_to, field_value, \n"
			+ " transaction_id, fl_versioned) \n"
			+ "values(:nextId, :parm.cropPlanId, :parm.plotCode, :parm.declCode, \n"
			+ " :parm.insertDt, :parm.deleteDt, :parm.insertUserId, :parm.deleteUserId, \n"
			+ " :parm.landUseCode, :fc.fieldCode, :fc.dayFrom, :fc.dayTo, :fc.value, \n"
			+ " :parm.transId, :parm.flVersioned) \n"
			+ "")
	public void insertDeclAdditFields(
			@BindBean("parm") DaoSupportParams parm,
			@Bind("nextId") Long nextId,
			@BindBean("fc") LandUseAdditionalDataField fc);

	@SqlUpdate("update crpl_decl_addit_fields \n"
			+ "   set dt_delete = :parm.deleteDt, user_id_delete = :parm.deleteUserId, transaction_id = :parm.transId"
			+ " where (:fieldCode is null or field_code = :fieldCode) \n"
			+ "   and plan_id = :parm.cropPlanId \n"
			+ "   and plot_code = :parm.plotCode \n"
			+ "   and decl_code = :parm.declCode \n"
			+ "   and §current_timestamp§ between dt_insert and dt_delete \n"
			+ "")
	public int outdateDeclAdditFieldsInternal(
			@BindBean("parm") DaoSupportParams parm,
			@Bind("fieldCode") String fieldCode);

	@SqlQuery("SELECT "
			+ "  t1.FIELD_CODE AS field_code, "
			+ "  COALESCE(§i18n(:tenantId, 'CRPL_LANDUSE_ADDIT_FIELDS', 'FIELD_CODE', t1.field_code, :LANGUAGE)§, t1.field_code) AS fieldDescription, "
			+ "  t1.field_type AS fieldType, "
			+ "  t1.valid_from AS validFrom, "
			+ "  t1.valid_to AS validTo, "
			+ "  t1.display_order AS sortOrder, "
			+ "  coalesce(t1luc.nullable, t1.nullable) AS nullable, "
			+ "  t1.group_code AS groupCode, "
			+ "  t1.header_title_code AS headerTitleCode, "
			+ "  COALESCE(§i18n(:tenantId, 'CRPL_LANDUSE_ADDIT_FIELDS', 'HEADER_TITLE_CODE', t1.header_title_code, :LANGUAGE)§, t1.header_title_code) AS headerTitleDescription, "
			+ "  t1.fl_editable AS flEditable, "
			+ "  t1.formula AS formula, "
			+ "  :landUseCode AS landUseCode, "
			+ "  t2.valid_from AS dayFrom, "
			+ "  t2.valid_to AS dayTo, "
			+ "  t2.fl_default as flDefault, "
			+ "  t2.display_order AS valueSortOrder, "
			+ "  t2.ALLOWED_VALUE AS value, "
			+ "  COALESCE(§i18n(:tenantId, 'CRPL_LANDUSE_ADDIT_FIELDS', 'FIELD_VALUE', t2.allowed_value, :LANGUAGE)§, t2.allowed_value) AS valueDescription "
			+ "FROM "
			+ "  crpl_landuse_addit_fields t1 "
			+ "left join crpl_landuse_addit_fields_cfg t1luc on t1luc.config_id = t1.id and :landUseCode LIKE t1luc.land_use_code AND §current_timestamp§ BETWEEN t1luc.dt_insert AND t1luc.dt_delete "
			+ "INNER JOIN CRPL_LANDUSE_ADDIT_FIELDS_VAL t2 ON "
			+ "  t1.FIELD_CODE = t2.FIELD_CODE "
			+ "WHERE "
			+ "  :landUseCode LIKE LAND_USE_CODE_FILTER "
			+ "  AND §current_timestamp§ BETWEEN t1.dt_insert AND t1.dt_delete "
			+ "  AND :pointInTime BETWEEN t1.valid_from AND t1.valid_to "
			+ "  AND t1.tenant_id = :tenantId "
			+ "  AND §current_timestamp§ BETWEEN t2.dt_insert AND t2.dt_delete "
			+ "  AND :pointInTime BETWEEN t2.valid_from AND t2.valid_to "
			+ "  AND t2.tenant_id = :tenantId")
	@RegisterBeanMapper(LandUseAdditFieldsWithValuesReadDto.class)
	List<LandUseAdditFieldsWithValuesReadDto> getLandUseConfigWithValuesAndDefaultByLandUseCodeList(
			@Bind("tenantId") String tenantId,
			@Bind("language") String language,
			@Bind("landUseCode") String landUseCode,
			@Bind("pointInTime") AbsoluteDate pointInTime);

	@SqlQuery(""
			+ "select pdec.plot_code as plotCode, \n"
			+ "       af.decl_code as declCode, \n"
			+ "       laf.field_type AS fieldType, \n"
			+ "       af.field_code as fieldCode, \n"
			+ "       coalesce(§i18n(:tenantId, 'CRPL_LANDUSE_ADDIT_FIELDS', 'FIELD_CODE', af.field_code, :language)§, af.field_code) as fieldDescription, \n"
			+ "       af.field_value as value, \n"
			+ "       coalesce(§i18n(:tenantId, 'CRPL_LANDUSE_ADDIT_FIELDS', 'FIELD_VALUE', af.field_value, :language)§, af.field_value) as valueDescription, \n"
			+ "       af.day_from as dayFrom, \n"
			+ "       af.day_to as dayTo, \n"
			+ "       laf.display_order as sortOrder, \n"
			+ "       laf.fl_show_in_tooltip as flShowInTooltip \n"
			+ "  from crpl_decl_addit_fields af \n"
			+ " inner join crpl_landuse_addit_fields laf on af.field_code = laf.field_code \n"
			+ " inner join crpl_declarations pdec on af.decl_code = pdec.decl_code and af.plot_code = pdec.plot_code and af.plan_id = pdec.plan_id \n"
			+ " where pdec.plan_id = :cropPlanId \n"
			+ "   and (:plotCode is null or pdec.plot_code = :plotCode) \n"
			+ "   and pdec.decl_code in (<declCodes>) \n"
			+ "   and :versionDt between af.dt_insert and af.dt_delete \n"
			+ "   and :versionDt between laf.dt_insert and laf.dt_delete \n"
			+ "   and :versionDt between pdec.dt_insert and pdec.dt_delete \n"
			+ " order by laf.display_order"
			+ "")
	@RegisterBeanMapper(LandUseAdditionalDataFieldWithPlotCode.class)
	List<LandUseAdditionalDataFieldWithPlotCode> getLandUseAdditionalDeclarationFields(
			@Bind("tenantId") String tenantId,
			@Bind("language") String language,
			@Bind("plotCode") String plotCode,
			@Bind("cropPlanId") Long cropPlanId,
			@BindList("declCodes") List<String> declCodes,
			@Bind("versionDt") LocalDateTime versionDt);

	@Cached
	@CacheDefinition(maxWeight = 2000, expireAfterWriteMinutes = 15)
	@SqlQuery(""
			+ "select distinct \n"
			+ "       :landUseCode as landUseCode, \n"
			+ "       ' ' as landUseDescription, \n"
			+ "       f.field_code as fieldCode, \n"
			+ "       coalesce(§i18n(:tenantId, 'CRPL_LANDUSE_ADDIT_FIELDS', 'FIELD_CODE', f.field_code, :language)§, f.field_code) as fieldDescription, \n"
			+ "       f.field_type as fieldType, \n"
			+ "       f.valid_from as validFrom, \n"
			+ "       f.valid_to as validTo, \n"
			+ "       f.display_order as sortOrder, \n"
			+ "       (  select allowed_value from crpl_landuse_addit_fields_val nest \n"
			+ "           where :landUseCode like land_use_code_filter \n"
			+ "             and field_code = f.field_code \n"
			+ "             and fl_default = 1 \n"
			+ "             and §current_timestamp§ between dt_insert and dt_delete \n"
			+ "             and :pointInTime between valid_from and valid_to \n"
			+ "           order by display_order \n"
			+ "           fetch first row only \n"
			+ "       ) as defaultValue, \n"
			+ "       coalesce(fluc.nullable, f.nullable) AS nullable, \n"
			+ "       null as allowedValues, \n"
			+ "       f.group_code as groupCode, \n"
			+ "       f.header_title_code as headerTitleCode, \n"
			+ "       coalesce(§i18n(:tenantId, 'CRPL_LANDUSE_ADDIT_FIELDS', 'HEADER_TITLE_CODE', f.header_title_code, :language)§, f.header_title_code) as headerTitleDescription, \n"
			+ "       f.fl_editable as flEditable, \n"
			+ "       f.formula \n"
			+ "  from crpl_landuse_addit_fields f \n"
			+ "left join crpl_landuse_addit_fields_cfg fluc on fluc.config_id = f.id and :landUseCode like fluc.land_use_code and §current_timestamp§ between fluc.dt_insert and fluc.dt_delete "
			+ " inner join crpl_landuse_addit_fields_val fv on f.field_code = fv.field_code \n"
			+ " where :landUseCode like fv.land_use_code_filter \n"
			+ "   and §current_timestamp§ between f.dt_insert and f.dt_delete \n"
			+ "   and §current_timestamp§ between fv.dt_insert and fv.dt_delete \n"
			+ "   and :pointInTime between f.valid_from and f.valid_to \n"
			+ "   and :pointInTime between fv.valid_from and fv.valid_to \n"
			+ " order by f.display_order, f.field_code, f.field_type"
			+ "")
	@RegisterBeanMapper(LandUseAdditionalDataConf.class)
	List<LandUseAdditionalDataConf> getLandUseAdditionalConf(
			@Bind("tenantId") String tenantId,
			@Bind("language") String language,
			@Bind("pointInTime") AbsoluteDate pointInTime,
			@Bind("landUseCode") String landUseCode);

	@Cached
	@CacheDefinition(maxWeight = 5000, expireAfterWriteMinutes = 15)
	@SqlQuery("select distinct \n"
			+ "       fv.field_code as fieldCode, \n"
			+ "       coalesce(§i18n(:tenantId, 'CRPL_LANDUSE_ADDIT_FIELDS', 'FIELD_CODE', fv.field_code, :language)§, fv.field_code) as fieldDescription, \n"
			+ "       fv.valid_from as dayFrom, \n"
			+ "       fv.valid_to as dayTo, \n"
			+ "       fv.display_order as sortOrder, \n"
			+ "       fv.allowed_value as value, \n"
			+ "       coalesce(§i18n(:tenantId, 'CRPL_LANDUSE_ADDIT_FIELDS', 'FIELD_VALUE', fv.allowed_value, :language)§, fv.allowed_value) as valueDescription \n"
			+ "  from crpl_landuse_addit_fields_val fv \n"
			+ " where :landUseCode like fv.land_use_code_filter \n"
			+ "   and fv.field_code = :fieldCode \n"
			+ "   and :pointInTime BETWEEN fv.valid_from AND fv.valid_to \n"
			+ "   and §current_timestamp§ between fv.dt_insert and fv.dt_delete \n"
			+ " order BY fv.display_order \n"
			+ "")
	@RegisterBeanMapper(LandUseAdditionalDataField.class)
	public List<LandUseAdditionalDataField> getLandUseAllowedAdditionalFileds(
			@Bind("tenantId") String tenantId,
			@Bind("language") String language,
			@Bind("pointInTime") AbsoluteDate pointInTime,
			@Bind("landUseCode") String code,
			@Bind("fieldCode") String fieldCode);

	/*@SqlQuery(""
			+ "select distinct \n"
			+ "       field_code as fieldCode, \n"
			+ "       coalesce(§i18n(:tenantId, 'CRPL_LANDUSE_ADDIT_FIELDS', 'FIELD_CODE', field_code, :language)§, field_code) as fieldDescription, \n"
			+ "       valid_from as dayFrom, \n"
			+ "       valid_to as dayTo, \n"
			+ "       display_order as sortOrder, \n"
			+ "       allowed_value as value, \n"
			+ "       coalesce(§i18n(:tenantId, 'CRPL_LANDUSE_ADDIT_FIELDS', 'FIELD_VALUE', fv.allowed_value, :language)§, fv.allowed_value) as valueDescription \n"
			+ "  from crpl_landuse_addit_fields_val \n"
			+ " where :landUseCode like land_use_code_filter \n"
			+ "   and field_code = :fieldCode \n"
			+ "   and :versionDt between dt_insert and dt_delete \n"
			+ "   and tenant_id = :tenantId \n"
			+ "")
	@RegisterBeanMapper(LandUseAdditionalDataField.class)
	public LandUseAdditionalDataField findDeclAdditFieldAllowedVal(
			@Bind("landUseCode") String landUseCode,
			@Bind("fieldCode") String fieldCode,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("tenantId") String tenantId);*/

}
