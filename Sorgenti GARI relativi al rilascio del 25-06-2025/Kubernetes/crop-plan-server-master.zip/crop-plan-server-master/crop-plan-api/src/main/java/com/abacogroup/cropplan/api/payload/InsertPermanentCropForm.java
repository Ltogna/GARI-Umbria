package com.abacogroup.cropplan.api.payload;

import com.abacogroup.cropplan.sdk.model.PermanentCropFormData;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "The permanent crop form data")
public class InsertPermanentCropForm
{

	@Schema(description = "The permanent crop form type")
	@NotNull
	private String formType;

	@NotNull
	private PermanentCropFormData permanentCropFormData;

}
