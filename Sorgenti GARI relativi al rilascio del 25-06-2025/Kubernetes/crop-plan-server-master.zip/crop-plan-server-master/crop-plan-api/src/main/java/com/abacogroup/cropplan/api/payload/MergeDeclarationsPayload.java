package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class MergeDeclarationsPayload
{
	@Schema(description = "From date")
	@NotNull
	private AbsoluteDate fromDate;

}
