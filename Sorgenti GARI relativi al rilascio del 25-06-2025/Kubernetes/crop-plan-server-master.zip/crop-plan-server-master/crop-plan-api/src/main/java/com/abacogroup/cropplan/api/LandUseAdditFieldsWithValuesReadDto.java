package com.abacogroup.cropplan.api;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class LandUseAdditFieldsWithValuesReadDto extends LandUseCommonAdditFieldsWithValuesReadDto {
	private String landUseCode;
}
