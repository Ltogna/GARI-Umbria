package com.abacogroup.cropplan.api;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "The complete with tare dates")
public class CompleteWithTareDates
{
	private AbsoluteDate minFromDate;
	private AbsoluteDate maxToDate;
}
