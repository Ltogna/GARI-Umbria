package com.abacogroup.cropplan.db.dao;

import com.abacogroup.cropplan.api.PesticideCode;
import com.abacogroup.cropplan.api.UomCode;
import com.abacogroup.cropplan.api.payload.InsertDeclPesticidePayload;
import com.abacogroup.cropplan.sdk.mapper.VersionColumnMapper;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.cropplan.sdk.model.pesticides.PesticideEntry;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transaction;

@RegisterColumnMapper(VersionColumnMapper.class)
@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface PesticidesDAO extends BasicDAO, EnhancedSqlObject
{
	@SqlQuery("§select_nextval(crpl_decl_pesticides_seq)§")
	public Long getDeclPesticidesSeq();

	@SqlUpdate("insert into CRPL_DECL_PESTICIDES (id, pesticide_entry_code, plan_id, plot_code, decl_code, product_code, uom_code, amount, entry_date, user_id_insert, dt_insert, dt_delete, transaction_id, fl_versioned)"
		+ "      values (:id, :pesticideEntryCode, :cropPlanId, :plotCode, :declCode, :productCode, :uomCode, :amount, :date, :userId, :insertDt, TO_DATE('99991231','YYYYMMDD'), null, 0)")
	public void insertPesticide(
		@Bind("id") Long id, 
		@Bind("pesticideEntryCode") String pesticideEntryCode,
		@Bind("cropPlanId") Long cropPlanId, 
		@Bind("plotCode") String plotCode, 
		@Bind("declCode") String declCode, 
		@Bind("productCode") String productCode,
		@Bind("uomCode") String uomCode, 
		@Bind("amount") Double amount,
		@Bind("date") AbsoluteDate date,
		@Bind("userId") String userId, 
		@Bind("insertDt") LocalDateTime insertDt);


		@SqlQuery("select distinct cdp.product_code as productCode"
		+ "      from CRPL_DECL_PESTICIDES cdp, crpl_declarations cd"
		+ "		where cdp.plan_id = :planId"
		+ "       and :versionDt between cdp.dt_insert and cdp.dt_delete"
		+ "       and :versionDt between cd.dt_insert and cd.dt_delete"
		+ "       and cd.plan_id = cdp.plan_id"
		+ "       and cd.decl_code = cdp.decl_code"
		+ "       and cd.plot_code = cdp.plot_code"
		+ "       and cdp.product_code not in (select c.code from cache_decodes c, crpl_plans cp where c.type = :cacheDecodesType and cp.type_id = c.type_id and cp.id = :planId)")
		@RegisterBeanMapper(PesticideCode.class)
		public List<PesticideCode> getProductCodesNotInCache(@Bind("planId") Long planId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("cacheDecodesType") String cacheDecodesType);

		@SqlQuery("select distinct cdp.uom_code as uomCode"
		+ "      from CRPL_DECL_PESTICIDES cdp, crpl_declarations cd"
		+ "		where cdp.plan_id = :planId"
		+ "       and :versionDt between cdp.dt_insert and cdp.dt_delete"
		+ "       and :versionDt between cd.dt_insert and cd.dt_delete"
		+ "       and cd.plan_id = cdp.plan_id"
		+ "       and cd.decl_code = cdp.decl_code"
		+ "       and cd.plot_code = cdp.plot_code"
		+ "       and cdp.uom_code not in (select c.code from cache_decodes c, crpl_plans cp where c.type = :cacheDecodesType and cp.type_id = c.type_id and cp.id = :planId)")
		@RegisterBeanMapper(UomCode.class)
		public List<UomCode> getUomCodesNotInCache(@Bind("planId") Long planId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("cacheDecodesType") String cacheDecodesType);

	@SqlQuery("select cdp.pesticide_entry_code as pesticideEntryCode,"
		+ "      	  cdp.plan_id as planId,"
		+ "      	  cdp.plot_code as plotCode,"
		+ "      	  cdp.decl_code as declCode,"
		+ "      	  cdp.product_code as productCode,"
		+ "      	  cdp.uom_code as uomCode,"
		+ "      	  cdp.amount,"
		+ "           cdp.entry_date as entryDate,"
		+ "           c_deco.description as productName,"
		+ "           (select cd_uom.description from cache_decodes cd_uom where cd_uom.code = cdp.uom_code and cd_uom.type = :cachePestUom) as uomLabel,"
		+ "           cdp.user_id_insert as userId"
		+ "      from CRPL_DECL_PESTICIDES cdp, crpl_declarations cd, cache_decodes c_deco"
		+ "		where cdp.plan_id = :planId"
		+ "		  and (:plotCode is null or cdp.plot_code = :plotCode)"
		+ "		  and (:declCode is null or cdp.decl_code = :declCode)"
		+ "		  and (:pesticideEntryCode is null or cdp.pesticide_entry_code = :pesticideEntryCode)"
		+ "       and :version between cdp.dt_insert and cdp.dt_delete"
		+ "       and :version between cd.dt_insert and cd.dt_delete"
		+ "       and (:search is null or upper( c_deco.description) like '%'||upper(:search)||'%')"
		+ "       and cd.plan_id = cdp.plan_id"
		+ "       and cd.decl_code = cdp.decl_code"
		+ "       and cd.plot_code = cdp.plot_code"
		+ "       and cdp.product_code = c_deco.code"
		+ "       and c_deco.type = :cachePestType"
		+ "  order by pesticideEntryCode"
		)
	@RegisterBeanMapper(PesticideEntry.class)
	public ResultIterator<PesticideEntry> getPesticideEntries(
		@Bind("planId") Long planId,		
		@Bind("version") LocalDateTime version,
		@Bind("plotCode") String plotCode,
		@Bind("declCode") String declCode,
		@Bind("pesticideEntryCode") String pesticideEntryCode, 
		@Bind("search") String search,
		@Bind("cachePestType") String cachePestType,
		@Bind("cachePestUom") String cachePestUom
		);

	@SqlUpdate("update CRPL_DECL_PESTICIDES"
		+ "        set DT_DELETE = :deleteDt, USER_ID_DELETE = :userId, transaction_id = null"
		+ "      where (:pesticideEntryCode is null or pesticide_entry_code = :pesticideEntryCode)"
		+ "        and DECL_CODE = :declCode"
		+ "        and plot_code = :plotCode"
		+ "        and PLAN_ID = :cropPlanId"
		+ "        and §current_timestamp§ between DT_INSERT and DT_DELETE")
	public int deletePesticidesInternal(@Bind("pesticideEntryCode") String pesticideEntryCode, @Bind("declCode") String declCode, @Bind("plotCode") String plotCode,
		@Bind("cropPlanId") Long cropPlanId, @Bind("deleteDt") LocalDateTime deleteDt, @Bind("userId") String userId);

	@Transaction
	default public void updatePesticide(String pesticideEntryCode, String declCode, String plotCode, Long cropPlanId, LocalDateTime updateDt, String userId, InsertDeclPesticidePayload payload)
	{
		var entry = infinite(() -> getPesticideEntries(cropPlanId, updateDt, plotCode, declCode, pesticideEntryCode, null, CacheDecodesDAO.CACHE_DECODES_TYPE.PESTICIDES.toString(),CacheDecodesDAO.CACHE_DECODES_TYPE.PESTICIDES_UOM.toString()), null, 1).getRecords().get(0);
		deletePesticidesInternal(pesticideEntryCode, declCode, plotCode, cropPlanId, updateDt.minus(Duration.ofMillis(1)), userId);
		insertPesticide(getDeclPesticidesSeq(), pesticideEntryCode, cropPlanId, plotCode, declCode, payload.getProductCode(), payload.getUomCode(), payload.getAmount(), entry.getEntryDate(), userId, updateDt);
	}
}

