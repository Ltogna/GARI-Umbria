package com.abacogroup.cropplan.resources.pub;

import java.util.Objects;

import com.abacogroup.cropplan.api.EditPlotResult;
import com.abacogroup.cropplan.api.payload.InsertPlotPayload;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.PlotEditDAO;
import com.abacogroup.cropplan.exceptions.CropPlanNotWriteableException;
import com.abacogroup.cropplan.exceptions.CropPlanReadOnlyException;
import com.abacogroup.cropplan.exceptions.LockException;
import com.abacogroup.cropplan.exceptions.PlotNotEditableException;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.BasePlotEditResource;
import com.abacogroup.cropplan.resources.dtos.PlotsDeleteDto;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.LocksService;
import com.abacogroup.cropplan.services.PersistEditorResult;
import com.abacogroup.cropplan.services.PlotEditService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.cropplan.services.support.EditorSupportParams;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.ForbiddenException;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.SecurityContext;

@Path("{tenant}/public")
@Tag(name = "PUBLIC - Plot edit resources")
@Timed
@RolesAllowed({"CRPL|USER","CRPL|EDITOR"})
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class PublicTenantPlotEditResources extends BasePlotEditResource {

	private CropPlanConfigService cropPlanConfigService;
	private PlotEditService plotEditService;
	private LocksService locksService;
	private PlotEditDAO plotEditDAO;
	private PluginManager pluginManager;

	public PublicTenantPlotEditResources(BaseService baseService, CropPlanConfigService cropPlanConfigService, PlotEditService plotEditService,
			CropPlanService cropPlanService, LocksService locksService, ValidatorService validatorService,
			DAOContainer daocontainer, PluginManager pluginManager) {
		super(baseService, cropPlanConfigService, plotEditService, cropPlanService, locksService, validatorService);
		this.cropPlanConfigService = cropPlanConfigService;
		this.plotEditService = plotEditService;
		this.locksService = locksService;
		this.plotEditDAO = daocontainer.getPlotEditDAO();
		this.pluginManager = pluginManager;
	}

	@POST
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/domains/{domainZoneCode}/plots")	
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Create a plot")
	@ApiResponses({
			@ApiResponse(description = "The plot creation operation result"),
			@ApiResponse(responseCode = "404", description = "The specified domainZoneCode was not found"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotResult createPlot(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone code") @PathParam("domainZoneCode") String domainZoneCode,
			@Parameter(description = "If it is set to true then the zero area results is ignored") @QueryParam("cleanZeroAreaResults") @DefaultValue("false") boolean cleanZeroAreaResults,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@Parameter(description = "If it is set to true then the specified crop plan is locked for the current user") @QueryParam("autoLock") @DefaultValue("false") boolean autoLock,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid InsertPlotPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		if (autoLock)
			locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
		else
			checkLock(env, cropPlanId);
		
		var domainZone = pluginManager.getDomainPlugin(businessId, cropPlanId, tenantId).getDomainZoneByCode(env, businessId, payload.getFromPointInTime().toLocalDate(), domainZoneCode);
		if (domainZone == null)
			throw new BadRequestException("The specified domainZoneCode was not found");

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.domainZoneId(domainZone.getDomainZoneId())
				.versionDt(versionDt)
				.pointInTime(pointInTime)
				.build();

		return plotEditService.createPlot(env, params, payload, ignoreDeclValidationWarnings, cleanZeroAreaResults);
	}

	@DELETE
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/domains/{domainZoneCode}/plots/{plotCode}")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Delete a plot")
	@ApiResponses({
		@ApiResponse(description = "The plot delete operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "The plot is not editable", content = @Content(schema = @Schema(implementation = PlotNotEditableException.PlotNotEditableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotResult deletePlot(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone code") @PathParam("domainZoneCode") String domainZoneCode,
		@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("fromPointInTime") @NotNull @Valid AbsoluteDate fromPointInTime,
		@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
		@Parameter(description = "If it is set to true then the specified crop plan is locked for the current user") @QueryParam("autoLock") @DefaultValue("false") boolean autoLock,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(fromPointInTime.toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			fromPointInTime = cropPlanConfigService.getFixedEditDate(cropPlanId, fromPointInTime);
		checkCanWrite(env, businessId, cropPlanId, fromPointInTime);
		if (autoLock)
			locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
		else
			checkLock(env, cropPlanId);

		var domainZone = pluginManager.getDomainPlugin(businessId, cropPlanId, tenantId).getDomainZoneByCode(env, businessId, fromPointInTime.toLocalDate(), domainZoneCode);
		if (domainZone == null)
			throw new BadRequestException("The specified domainZoneCode was not found");

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZone.getDomainZoneId())
			.versionDt(versionDt)
			.pointInTime(pointInTime)
			.build();
		checkPlotEditability(env, params, fromPointInTime, plotCode);

		PersistEditorResult result = plotEditService.deletePlot(env, params, plotCode, fromPointInTime, ignoreDeclValidationWarnings, false);
		return result.getEditPlotResult();
	}

	@DELETE
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/domains/{domainZoneCode}/plots")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Delete a list of plots")
	@ApiResponses({
		@ApiResponse(description = "The plot delete operation results"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "The plot is not editable", content = @Content(schema = @Schema(implementation = PlotNotEditableException.PlotNotEditableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	@Deprecated
	public EditPlotResult deletePlots(
		@Context SecurityContext context,
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone code") @PathParam("domainZoneCode") String domainZoneCode,
		@Parameter(description = "List of plot codes to be deleted") @NotNull @Valid PlotsDeleteDto plotsDeleteDto,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("fromPointInTime") @NotNull @Valid AbsoluteDate fromPointInTime,
		@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
		@Parameter(description = "If it is set to true then the specified crop plan is locked for the current user") @QueryParam("autoLock") @DefaultValue("false") boolean autoLock,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		if (!context.isUserInRole("CRPL|CAN_DELETE_PLOTS"))
			throw new ForbiddenException("You are not allowed to delete multiple plots");

		if (plotsDeleteDto.getPlotCodes().stream().anyMatch(Objects::isNull)) {
			throw new BadRequestException("Plot codes cannot be null");
		}

		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(fromPointInTime.toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			fromPointInTime = cropPlanConfigService.getFixedEditDate(cropPlanId, fromPointInTime);
		checkCanWrite(env, businessId, cropPlanId, fromPointInTime);
		if (autoLock)
			locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
		else
			checkLock(env, cropPlanId);

		var domainZone = pluginManager.getDomainPlugin(businessId, cropPlanId, tenantId).getDomainZoneByCode(env, businessId, fromPointInTime.toLocalDate(), domainZoneCode);
		if (domainZone == null)
			throw new BadRequestException("The specified domainZoneCode was not found");

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZone.getDomainZoneId())
			.versionDt(versionDt)
			.pointInTime(pointInTime)
			.build();

		for (String plotCode: plotsDeleteDto.getPlotCodes()) {
			checkPlotEditability(env, params, fromPointInTime, plotCode);
		}

		PersistEditorResult result = plotEditService.deletePlots(env, params, plotsDeleteDto.getPlotCodes(), fromPointInTime, ignoreDeclValidationWarnings, false);
		return result.getEditPlotResult();
	}

	@POST
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/domains/{domainZoneCode}/delete-plots")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Delete a list of plots")
	@ApiResponses({
		@ApiResponse(description = "The plot delete operation results"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "The plot is not editable", content = @Content(schema = @Schema(implementation = PlotNotEditableException.PlotNotEditableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotResult deletePlotByPlotCodes(
		@Context SecurityContext context,
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone code") @PathParam("domainZoneCode") String domainZoneCode,
		@Parameter(description = "List of plot codes to be deleted") @NotNull @Valid PlotsDeleteDto plotsDeleteDto,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("fromPointInTime") @NotNull @Valid AbsoluteDate fromPointInTime,
		@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
		@Parameter(description = "If it is set to true then the specified crop plan is locked for the current user") @QueryParam("autoLock") @DefaultValue("false") boolean autoLock,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		if (!context.isUserInRole("CRPL|CAN_DELETE_PLOTS"))
			throw new ForbiddenException("You are not allowed to delete multiple plots");

		if (plotsDeleteDto.getPlotCodes().stream().anyMatch(Objects::isNull)) {
			throw new BadRequestException("Plot codes cannot be null");
		}

		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(fromPointInTime.toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			fromPointInTime = cropPlanConfigService.getFixedEditDate(cropPlanId, fromPointInTime);
		checkCanWrite(env, businessId, cropPlanId, fromPointInTime);
		if (autoLock)
			locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
		else
			checkLock(env, cropPlanId);

		var domainZone = pluginManager.getDomainPlugin(businessId, cropPlanId, tenantId).getDomainZoneByCode(env, businessId, fromPointInTime.toLocalDate(), domainZoneCode);
		if (domainZone == null)
			throw new BadRequestException("The specified domainZoneCode was not found");

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZone.getDomainZoneId())
			.versionDt(versionDt)
			.pointInTime(pointInTime)
			.build();

		for (String plotCode: plotsDeleteDto.getPlotCodes()) {
			checkPlotEditability(env, params, fromPointInTime, plotCode);
		}

		PersistEditorResult result = plotEditService.deletePlots(env, params, plotsDeleteDto.getPlotCodes(), fromPointInTime, ignoreDeclValidationWarnings, false);
		return result.getEditPlotResult();
	}

}
