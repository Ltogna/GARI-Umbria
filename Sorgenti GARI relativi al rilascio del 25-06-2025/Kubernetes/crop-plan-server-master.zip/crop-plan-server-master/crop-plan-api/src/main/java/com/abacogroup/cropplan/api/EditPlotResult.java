package com.abacogroup.cropplan.api;

import java.util.ArrayList;
import java.util.List;

import com.abacogroup.cropplan.sdk.model.validation.ValidationMessage;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class EditPlotResult extends ValidationResult
{
	private List<Plot> added;
	private List<String> deleted;
	private List<Plot> updated;
	private List<String> coveredByInserted;

	private List<AlertCode> alertCodes;

	public EditPlotResult()
	{
		setValidationMessages(new ArrayList<>());
	}

	public EditPlotResult(List<Plot> added, List<String> deleted, List<Plot> updated)
	{
		this.added = added;
		this.deleted = deleted;
		this.updated = updated;
		setValidationMessages(new ArrayList<>());
	}

	public EditPlotResult(List<ValidationMessage> messages)
	{
		setValidationMessages(messages);
	}
}
