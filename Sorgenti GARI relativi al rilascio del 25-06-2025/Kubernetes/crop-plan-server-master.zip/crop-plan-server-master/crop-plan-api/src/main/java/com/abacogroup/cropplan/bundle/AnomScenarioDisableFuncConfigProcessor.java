package com.abacogroup.cropplan.bundle;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.cropplan.bundle.model.AnomScenarioDisableFuncConfigMessage;
import com.abacogroup.cropplan.bundle.model.FunctionsDisabledConfig;
import com.abacogroup.cropplan.bundle.model.ScenarioAnomaliesConfig;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;

public class AnomScenarioDisableFuncConfigProcessor extends AbstractConfigProcessor
{

	public AnomScenarioDisableFuncConfigProcessor(CropPlanConfigDAO configDAO)
	{
		super(configDAO);
	}

	@Override
	public String getDomainName()
	{
		return "anomScenarioDisableFuncConfig";
	}

	@Override
	public void onMessageInTransaction(CropPlanConfigDAO dao, ConfigDataMessage message)
	{
		message.getConfigFiles().stream()
			.map(Path::toFile)
			.filter(file -> file.getAbsolutePath().endsWith(".json"))
			.sorted()
			.forEach(file -> processFile(message.getTenantId(), file));
	}

	public void processFile(String tenantId, File file)
	{
		AnomScenarioDisableFuncConfigMessage message;
		try
		{
			message = objectMapper.readValue(file, AnomScenarioDisableFuncConfigMessage.class);
		}
		catch (IOException e)
		{
			throw new IllegalStateException("Error processing file " + file.getName() + " for tenant " + tenantId, e);
		}

		if (file.getAbsolutePath().endsWith(".delete.json"))
		{
			doDelete(tenantId, message);
		}
		else
		{
			doInsertOrUpdate(tenantId, message);
		}
	}

	public void doInsertOrUpdate(String tenantId, AnomScenarioDisableFuncConfigMessage message)
	{
		if (message == null || message.getAnomScenarioConfig() == null || message.getAnomScenarioConfig().isEmpty())
		{
			return;
		}

		Long typeId = configDAO.getCropPlanTypeId(message.getCropPlanType(), tenantId);
		message.getAnomScenarioConfig().forEach(anomScenarioConfig -> {
			configDAO.deleteScenarioDisabledFunctionConfig(typeId, anomScenarioConfig.getScenario());
			configDAO.deleteAnomalyScenarioConfig(typeId, anomScenarioConfig.getScenario());
			
			for (FunctionsDisabledConfig functionDisabledConfig : anomScenarioConfig.getFunctionsDisabledConfig()) {
				configDAO.insertScenarioDisabledFunctionConfig(typeId,functionDisabledConfig.getFunctionCode(),anomScenarioConfig.getScenario()); 
			}
			for (ScenarioAnomaliesConfig scenarioAnomaliesConfig : anomScenarioConfig.getScenarioAnomaliesConfig()) {
				configDAO.insertAnomalyScenarioConfig(typeId,scenarioAnomaliesConfig.getAnomaliyCode(),anomScenarioConfig.getScenario(),scenarioAnomaliesConfig.getFl_present()== null ? null : scenarioAnomaliesConfig.getFl_present() ? 1 : 0);
			}
			
		});
	}

	public void doDelete(String tenantId, AnomScenarioDisableFuncConfigMessage message)
	{
		if (message == null || message.getAnomScenarioConfig() == null || message.getAnomScenarioConfig().isEmpty())
		{
			return;
		}

		Long typeId = configDAO.getCropPlanTypeId(message.getCropPlanType(), tenantId);
		message.getAnomScenarioConfig().forEach(anomScenarioConfig -> {
			configDAO.deleteScenarioDisabledFunctionConfig(typeId, anomScenarioConfig.getScenario());
			configDAO.deleteAnomalyScenarioConfig(typeId, anomScenarioConfig.getScenario());
		});
	}

}
