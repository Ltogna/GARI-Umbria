package com.abacogroup.cropplan.db.dao.ntt;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.locationtech.jts.geom.Geometry;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PlotGeometry
{
	private Long plotId;
	private String plotCode;
	private Geometry geom;
}
