package com.abacogroup.cropplan.api.payload;

import java.util.List;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetCuttableLayersPayload
{
	@Schema(description = "The plot codes")
	@NotEmpty
	private List<String> plotCodes;

	@Schema(description = "The layer codes")
	@NotEmpty
	private List<String> layerCodes;

	@Schema(description = "The point in time")
	@NotNull
	AbsoluteDate pointInTime;
}
