package com.abacogroup.cropplan.api;

import java.time.LocalDateTime;

import com.abacogroup.cropplan.sdk.model.sync.SyncType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SyncOperation 
{
	private SyncType syncType;
	private LocalDateTime syncDate;
}
