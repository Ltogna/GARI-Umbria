package com.abacogroup.cropplan.api;

import java.util.ArrayList;
import java.util.List;

import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.validation.ValidationMessage;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "A copy declarations result")
public class CopyDeclarationsResult extends ValidationResult
{
	private Plot sourceUpdatedPlot;
	private Plot destUpdatedPlot;
	
	private List<Declaration> sourceDeclarationsAlreadyExisting;

	public CopyDeclarationsResult()
	{
		setValidationMessages(new ArrayList<>());
	}

	public CopyDeclarationsResult(List<ValidationMessage> messages)
	{
		setValidationMessages(messages);
	}
}
