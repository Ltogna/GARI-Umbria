package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class SubdomainZoneException extends AbstractAppException {

	public SubdomainZoneException(ErrEnum code, String message) {
		super(new ErrorBody(code.name(), message), code.statusCode);
	}

	public enum ErrEnum {
		MAX_PLOTS_ON_DOMAIN_ZONE_NOT_SET(Status.BAD_REQUEST.getStatusCode()),
		TOO_MANY_PLOTS_IN_SUBDOMAIN_ZONE(Status.BAD_REQUEST.getStatusCode()),
		;

		private final int statusCode;

		ErrEnum(int statusCode) {
			this.statusCode = statusCode;
		}
	}

	@Schema(name = "SubdomainZoneExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = {
				"MAX_PLOTS_ON_DOMAIN_ZONE_NOT_SET",
				"TOO_MANY_PLOTS_IN_SUBDOMAIN_ZONE",
		})
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}
}
