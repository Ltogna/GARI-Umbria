package com.abacogroup.cropplan.bundle.model;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnomaliesDefinition
{
	private String errorCode;

	@Builder.Default
	private List<I18nValueDefinition> i18nValues = new ArrayList<>();
	
	@Builder.Default
	private List<I18nValueDefinition> genericI18nValues = new ArrayList<>();
}
