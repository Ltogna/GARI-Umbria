	package com.abacogroup.cropplan.services;

	import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.abacogroup.cropplan.api.payload.InsertDeclPesticidePayload;
import com.abacogroup.cropplan.db.dao.CacheDecodesDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.db.dao.PesticidesDAO;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.sdk.model.pesticides.Pesticide;
import com.abacogroup.cropplan.sdk.model.pesticides.PesticideEntry;
import com.abacogroup.cropplan.sdk.model.pesticides.UnitOfMeasurment;
import com.abacogroup.cropplan.sdk.spi.PesticidesPlugin;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import jakarta.ws.rs.BadRequestException;

public class PesticidesService
{
	private PesticidesDAO pesticidesDAO;
	private PluginManager pluginManager;
	private CacheDecodesDAO cacheDecodesDAO;
	private DeclarationsDAO declarationsDAO;

	public PesticidesService(
			DAOContainer daocontainer,
			PluginManager pluginManager)
	{
		this.pesticidesDAO = daocontainer.getPesticidesDAO();
		this.cacheDecodesDAO = daocontainer.getCacheDecodesDAO();
		this.declarationsDAO = daocontainer.getDeclarationsDAO();
		this.pluginManager = pluginManager;
	}

	public InfiniteListResults<PesticideEntry> getPesticideEntriesPaged(RuntimeEnvironment env, String businessId, Long planId, String tenantId, LocalDateTime version, String plotCode, String declCode, String search, String nextKey, int pageSize)
	{
		PesticidesPlugin pesticidesPlugin = pluginManager.getPesticidesPlugin(businessId, planId, tenantId);
		if (pesticidesPlugin == null)
			return new InfiniteListResultsImpl<>(new ArrayList<>(), null);

		// TODO: use valkey to lock cache while updating
		var cacheDt = pesticidesDAO.getCurrentTimestamp();
		var cacheValidityDt = cacheDt.minusDays(1);
		cacheDecodesDAO.clearCacheDecodes(planId, CacheDecodesDAO.CACHE_DECODES_TYPE.PESTICIDES.toString(), cacheValidityDt);
		var productCodesNotIn = pesticidesDAO.getProductCodesNotInCache(planId, version, CacheDecodesDAO.CACHE_DECODES_TYPE.PESTICIDES.toString());
		if (productCodesNotIn.size() > 0)
		{
			List<Pesticide> pesticides = new ArrayList<Pesticide>();
			String nextKeyC = null;
			do
			{
				var pestPage = pesticidesPlugin.getPesticides(env, null, productCodesNotIn.stream().map(code -> code.getProductCode()).collect(Collectors.toList()), nextKeyC);
				pesticides.addAll(pestPage.getRecords());			
				nextKeyC = pestPage.getNextKey();
				
			} while(nextKeyC != null);

			pesticides.forEach(pesticide -> {
				cacheDecodesDAO.insertCacheDecodes(planId, CacheDecodesDAO.CACHE_DECODES_TYPE.PESTICIDES.toString(), cacheDt, pesticide.getProductCode(), pesticide.getProductName());
			});
		}

		cacheDecodesDAO.clearCacheDecodes(planId, CacheDecodesDAO.CACHE_DECODES_TYPE.PESTICIDES_UOM.toString(), cacheValidityDt);
		var uomsCodesNotIn = pesticidesDAO.getUomCodesNotInCache(planId, version, CacheDecodesDAO.CACHE_DECODES_TYPE.PESTICIDES_UOM.toString());
		if (uomsCodesNotIn.size() > 0)
		{
			List<UnitOfMeasurment> uoms = pesticidesPlugin.getUnitOfMeasurmentList(env, uomsCodesNotIn.stream().map(code -> code.getUomCode()).collect(Collectors.toList()));

			uoms.forEach(uom -> {
				cacheDecodesDAO.insertCacheDecodes(planId, CacheDecodesDAO.CACHE_DECODES_TYPE.PESTICIDES_UOM.toString(), cacheDt, uom.getUomCode(), uom.getUomLabel());
			});
		}

		var pesticidesEntries = pesticidesDAO.infinite(() -> pesticidesDAO.getPesticideEntries(planId, version, plotCode, declCode, null, search, CacheDecodesDAO.CACHE_DECODES_TYPE.PESTICIDES.toString(), CacheDecodesDAO.CACHE_DECODES_TYPE.PESTICIDES_UOM.toString()), nextKey, pageSize);

		return pesticidesEntries;
	}

	public void deletePesticides(String pesticideEntryCode, String declCode, String plotCode, Long cropPlanId, LocalDateTime deleteDt, String userId)
	{
		pesticidesDAO.deletePesticidesInternal(pesticideEntryCode, declCode, plotCode, cropPlanId, deleteDt, userId);
	}

	public void updatePesticides(String pesticideEntryCode, String declCode, String plotCode, Long cropPlanId, LocalDateTime updateDt, String userId, InsertDeclPesticidePayload payload)
	{
		pesticidesDAO.updatePesticide(pesticideEntryCode, declCode, plotCode, cropPlanId, updateDt, userId, payload);		
	}

	public void checkCanEditPesticideOnDeclaration(Long cropPlanId, String plotCode, String declCode)
	{
		var decl = declarationsDAO.getDeclarationByDeclCode(cropPlanId, plotCode, pesticidesDAO.getCurrentTimestamp(), declCode);
		if(decl == null)
			throw new BadRequestException("The decl " + declCode + " on plot " + plotCode + " was not found");
	}
}
