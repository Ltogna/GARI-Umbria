package com.abacogroup.cropplan.resources;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.PlotLifecycle;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.exceptions.CropPlanNotAccessibleException;
import com.abacogroup.cropplan.exceptions.CropPlanNotWriteableException;
import com.abacogroup.cropplan.exceptions.CropPlanReadOnlyException;
import com.abacogroup.cropplan.exceptions.DeclarationAdditionalFieldNotAllowedException;
import com.abacogroup.cropplan.exceptions.DeclarationAdditionalFieldNotValidException;
import com.abacogroup.cropplan.exceptions.IncompatibleLandUseException;
import com.abacogroup.cropplan.exceptions.InvalidDeclDatesException;
import com.abacogroup.cropplan.exceptions.InvalidDeclException;
import com.abacogroup.cropplan.exceptions.LandCoverNotEditableException;
import com.abacogroup.cropplan.exceptions.LockException;
import com.abacogroup.cropplan.exceptions.MaxDeclAreaException;
import com.abacogroup.cropplan.exceptions.PermanentCropFormNotAllowedException;
import com.abacogroup.cropplan.exceptions.PlotDeclarationsNotEditableException;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataConf;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalFieldType;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseDetails;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.LocksService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.cropplan.services.support.PlotTimeWindowParams;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

import jakarta.ws.rs.BadRequestException;

public abstract class BaseCropPlanResource extends BaseResource {
	private CropPlanService cropPlanService;
	private LocksService locksService;
	private CropCodeService cropCodeService;
	private ValidatorService validatorService;
	private CropPlanConfigService cropPlanConfigService;
	private CropPlansDAO cropPlansDAO;

	public BaseCropPlanResource(BaseService baseService, CropPlanService cropPlanService, LocksService locksService, CropCodeService cropCodeService,
			ValidatorService validatorService, CropPlanConfigService cropPlanConfigService, PluginManager pluginManager, CropPlansDAO cropPlansDAO) {
		super(baseService);
		this.cropPlanService = cropPlanService;
		this.locksService = locksService;
		this.cropCodeService = cropCodeService;
		this.validatorService = validatorService;
		this.cropPlanConfigService = cropPlanConfigService;
		this.cropPlansDAO = cropPlansDAO;
	}

	protected void checkCanRead(RuntimeEnvironment env, String businessId, Long cropPlanId) {
		var cropPlanTypeCode = cropPlanService.getCropPlanTypeCode(env, businessId, cropPlanId);
		if (cropPlanTypeCode == null)
			throw new BadRequestException("The crop plan was not found");
		var accessLevel = cropPlanService.getAccessLevel(env, businessId, cropPlanTypeCode);
		if (!accessLevel.canRead())
			throw new CropPlanNotAccessibleException(accessLevel.getMessageCode());
	}

	protected void checkCanRead(RuntimeEnvironment env, Long cropPlanId) {
		Long businessId = cropPlansDAO.getCropPlanBusinessId(cropPlanId);
		if (businessId == null) {
			throw new BadRequestException("The crop plan was not found");
		}
		checkCanRead(env, businessId.toString(), cropPlanId);
	}

	protected void checkCanWrite(RuntimeEnvironment env, String businessId, Long cropPlanId) {
		checkCanWrite(env, businessId, cropPlanId, false);
	}

	protected void checkCanWrite(RuntimeEnvironment env, String businessId, Long cropPlanId, boolean ignoreReadOnly) {
		var cropPlan = cropPlanService.getCropPlan(env, businessId, cropPlanId);
		if (cropPlan == null)
			throw new BadRequestException("The crop plan was not found");
		var accessLevel = cropPlanService.getAccessLevel(env, businessId, cropPlan.getCropPlanTypeCode());
		if (!accessLevel.canWrite())
			throw new CropPlanNotWriteableException(accessLevel.getMessageCode());
		if (!ignoreReadOnly && cropPlan.getReadOnly())
			throw new CropPlanReadOnlyException();
		if (validatorService.getActiveTransactionId(cropPlanId) != null)
			throw new LockException();
	}

	protected void checkCanDelete(RuntimeEnvironment env, String businessId, Long cropPlanId) {
		var cropPlanTypeCode = cropPlanService.getCropPlanTypeCode(env, businessId, cropPlanId);
		if (cropPlanTypeCode == null)
			throw new BadRequestException("The crop plan was not found");
		var accessLevel = cropPlanService.getAccessLevel(env, businessId, cropPlanTypeCode);
		if (!accessLevel.canWrite())
			throw new CropPlanNotWriteableException(accessLevel.getMessageCode());
		// var cropPlanType = cropPlanService.getCropPlanType(env, cropPlanTypeCode);
		// if (!cropPlanType.getMultiple())
		// throw new CropPlanCantBeDeletedException(cropPlanId);
	}

	protected void checkLock(RuntimeEnvironment env, Long cropPlanId) {
		if (!locksService.hasLock(env, cropPlanId))
			throw new LockException();
	}

	protected void checkPlotEditability(RuntimeEnvironment env, String businessId, Long cropPlanId, Plot plot) {
		if (!cropPlanService.isPlotLandCoverEditable(env, businessId, cropPlanId, plot))
			throw new PlotDeclarationsNotEditableException(plot.getPlotCode());
	}

	protected void checkLandCoverEditability(RuntimeEnvironment env, String businessId, Long cropPlanId, String landCoverCode) {
		if (!cropPlanService.isLandCoverEditable(env, businessId, cropPlanId, landCoverCode))
			throw new LandCoverNotEditableException(landCoverCode);
	}

	protected void checkLandUseCompatibility(RuntimeEnvironment env, String businessId, Long cropPlanId, Plot plot, String landUseCode) {
		var maxParcel = plot.getParcelIntersections().stream().max(Comparator.comparing(ParcelIntersection::getAreaSqm));
		var landCoverCode = maxParcel.isEmpty() ? null : maxParcel.get().getLandCoverCode();
		if (!cropCodeService.isLandUseCompatible(env, businessId, cropPlanId, landUseCode, landCoverCode))
			throw new IncompatibleLandUseException();
	}

	protected void checkCanDeclare(RuntimeEnvironment env, PlotTimeWindowParams params, String landUseCode, Double declaredAreaPerc) {
		checkCanDeclare(env, params, landUseCode, declaredAreaPerc, false);
	}

	protected void checkCanDeclare(RuntimeEnvironment env, PlotTimeWindowParams params, String landUseCode, Double declaredAreaPerc,
			boolean ignoreExistingDeclarations) {
		var luc = cropCodeService.getLandUseCode(env, params.getBusinessId(), params.getCropPlanId(), landUseCode, null, params.getPointInTimeFrom());
		if (luc.getLandUseClass().getPercFixedTo100() && declaredAreaPerc != 100)
			throw new InvalidDeclException("Declared area percentage must be 100");

		var plotLifecycle = cropPlansDAO.getPlotLifecycle(params.getCropPlanId(), params.getDomainZoneId(), params.getVersionDt(), params.getPlotCode());
		var ignoreCropPlanConstraintsDeclsToPlots = cropPlanConfigService.isIgnoreCropPlanConstraintsDeclsToPlots(params.getCropPlanId());

		checkDeclDates(params, plotLifecycle, ignoreCropPlanConstraintsDeclsToPlots);

		var ignoreConstraintsDeclsPercTo100 = cropPlanConfigService.isIgnoreConstraintsDeclsPercTo100(params.getCropPlanId());
		checkMaxDeclArea(params, declaredAreaPerc, ignoreExistingDeclarations, luc, ignoreConstraintsDeclsPercTo100);
	}

	private void checkMaxDeclArea(PlotTimeWindowParams params, Double declaredAreaPerc,
			boolean ignoreExistingDeclarations, LandUseDetails luc, boolean ignoreConstraintsDeclsPercTo100) {
		if (!ignoreExistingDeclarations && (!ignoreConstraintsDeclsPercTo100 || luc.getLandUseClass().getPercFixedTo100())) {
			var freePlotAreas = cropPlanService.getPlotDeclaredAreas(params, false);
			if (Double.compare(declaredAreaPerc, freePlotAreas.getMaxDeclarableAreaPerc()) > 0)
				throw new MaxDeclAreaException();
		}
	}

	private void checkDeclDates(PlotTimeWindowParams params, PlotLifecycle plotLifecycle,
			boolean ignoreCropPlanConstraintsDeclsToPlots) {
		if (plotLifecycle == null || ((params.getPointInTimeFrom().isBefore(plotLifecycle.getMinFromDate())
				|| params.getPointInTimeTo().isAfter(plotLifecycle.getMaxToDate()) )
				&& !ignoreCropPlanConstraintsDeclsToPlots))
			throw new InvalidDeclDatesException();
	}

	protected void checkCanHavePermanentCropForm(RuntimeEnvironment env, String businessId, Long cropPlanId, String landUseCode,
			AbsoluteDate pointInTime, String formType) {

		var landUse = cropCodeService.getLandUseCode(env, businessId, cropPlanId, landUseCode, null, pointInTime);
		landUse.getFormsConfig().stream()
				.filter(ft -> ft.getFormType().toString().equals(formType))
				.findAny()
				.orElseThrow(() -> new PermanentCropFormNotAllowedException(formType, landUse.getCode()));
	}

	protected void checkCanHaveLandUseAdditionalField(RuntimeEnvironment env, String businessId, Long cropPlanId, String landUseCode,
			AbsoluteDate pointInTime, List<LandUseAdditionalDataField> fieldsCodes) {
		checkCanHaveLandUseAdditionalField(env, businessId, cropPlanId, landUseCode, pointInTime, fieldsCodes,
				false);
	}

	protected void checkCanHaveLandUseAdditionalField(RuntimeEnvironment env, String businessId, Long cropPlanId, String landUseCode,
			AbsoluteDate pointInTime, List<LandUseAdditionalDataField> fieldsCodes, boolean allowPartial) {

		List<LandUseAdditionalDataConf> fieldsConf = cropCodeService.getLandUseCodeFieldsConf(env, businessId, cropPlanId, landUseCode, pointInTime);
		if (!(allowPartial || cropPlanConfigService.disableCheckOnMandatoryDeclFields(cropPlanId))) {
			if (fieldsCodes == null) {
				if (fieldsConf.stream().allMatch(LandUseAdditionalDataConf::getNullable)) {
					return;
				} else {
					throw new DeclarationAdditionalFieldNotAllowedException(null, null, landUseCode);
				}
			}

			if (fieldsCodes.size() != fieldsConf.size()) {
				throw new DeclarationAdditionalFieldNotAllowedException(null, null, landUseCode);
			}

			if (fieldsConf
					.stream()
					.filter(f -> LandUseAdditionalFieldType.COMBO.equals(f.getFieldType()))
					.filter(f -> !f.getNullable())
					.map(LandUseAdditionalDataConf::getFieldCode)
					.anyMatch(fConf -> fieldsCodes.stream()
							.map(LandUseAdditionalDataField::getFieldCode)
							.noneMatch(fCode -> fCode.equals(fConf)))) {
				throw new DeclarationAdditionalFieldNotValidException(landUseCode);
			}
		}

		fieldsCodes.forEach(field -> {
			fieldsConf.stream()
					.filter(fc -> fc.getFieldCode().equals(field.getFieldCode()))
					.findFirst()
					.ifPresentOrElse(fc -> {
						checkDeclAddFieldNotAllowed(landUseCode, field, fc);
					}, () -> {
						throw new DeclarationAdditionalFieldNotAllowedException(field.getFieldCode(), field.getValue(), landUseCode);
					});

		});

		checkForDefaultValues(fieldsConf, fieldsCodes);

	}

	private void checkForDefaultValues(List<LandUseAdditionalDataConf> fc, List<LandUseAdditionalDataField> fieldsCodes) {
		// Creating a map for quick searching fields in fieldsCodes
		Map<String, LandUseAdditionalDataField> fieldCodeMap = fieldsCodes.stream()
				.collect(Collectors.toMap(LandUseAdditionalDataField::getFieldCode, field -> field));

		fc.stream()
				.filter(c -> StringUtils.isNotBlank(c.getGroupCode()))
				.collect(Collectors.groupingBy(LandUseAdditionalDataConf::getGroupCode))
				.forEach((group, fieldsInGroup) -> {
					boolean nonDefaultFound = false;

					for (LandUseAdditionalDataConf conf : fieldsInGroup) {
						LandUseAdditionalDataField field = fieldCodeMap.get(conf.getFieldCode());

						// If there is no default, skip checking for this field and if field value is different from the default
						if (field != null && conf.getDefaultValue() != null && !conf.getDefaultValue().equals(field.getValue())) {

							// if field value is different from the default
							if (nonDefaultFound) {
								throw new DeclarationAdditionalFieldNotAllowedException(field.getFieldCode(), field.getValue(), conf.getLandUseCode());
							}
							nonDefaultFound = true;
						}
					}
				});
	}

	private void checkDeclAddFieldNotAllowed(String landUseCode, LandUseAdditionalDataField field, LandUseAdditionalDataConf fc) {
		if (field.getValue() == null)
			return;
		if (LandUseAdditionalFieldType.COMBO.equals(fc.getFieldType())) {
			fc.getAllowedValues().stream()
					.filter(v -> ((v.getValue() == null && field.getValue() == null) || (v.getValue() != null && v.getValue().equals(field.getValue()))))
					.findAny()
					.orElseThrow(() -> new DeclarationAdditionalFieldNotAllowedException(field.getFieldCode(), field.getValue(), landUseCode));
		} else if (LandUseAdditionalFieldType.PERCENTAGE.equals(fc.getFieldType())) {
			fc.getAllowedValues().stream()
					.filter(v -> (v.getValue() != null))
					.filter(v -> (field.getValue() != null && field.getValue().matches(v.getValue())))
					.findAny()
					.orElseThrow(() -> new DeclarationAdditionalFieldNotAllowedException(field.getFieldCode(), field.getValue(), landUseCode));
		}
	}
}
