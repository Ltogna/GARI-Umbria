package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class MaxDeclAreaException extends WebApplicationException
{
	private static final long serialVersionUID = 694292105978030197L;

	public static  class MaxDeclAreaExceptionErrorBody
	{
		@Schema(allowableValues = "MAX_ALLOWED_DECLARABLE_AREA_EXCEPTION")
		public String getErrorCode()
		{
			return "MAX_ALLOWED_DECLARABLE_AREA_EXCEPTION";
		}
	}
	
	private static final MaxDeclAreaExceptionErrorBody BODY = new MaxDeclAreaExceptionErrorBody();

	public MaxDeclAreaException()
	{
		super("Maximum declarable area exceeded",
			Response.status(Status.BAD_REQUEST).entity(BODY).build());
	}
}
