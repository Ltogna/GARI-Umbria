package com.abacogroup.cropplan.services.support;

import java.util.Map;

import org.locationtech.jts.geom.Polygon;

import com.abacogroup.cropplan.api.CutBehaviour;
import com.abacogroup.cropplan.api.payload.DrawLineBufferPayload.LineBufferBehaviour;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.geometryeditor.EditorSupport;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

@FunctionalInterface
public interface EditorSupportFactory<K> {
	EditorSupport<K> createEditorSupport(RuntimeEnvironment env, EditorSupportParams params, CutBehaviour cutBehaviour, LineBufferBehaviour lineBufferBehaviour,
			boolean ignoreEditability, Map<String, Polygon> cutPolygons, AbsoluteDate pointInTime, boolean isForPreview);
}
