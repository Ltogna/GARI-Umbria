package com.abacogroup.cropplan.db.dao.ntt;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeclarationBaseInfo
{
	private String declCode;
	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;
	private String landUseCode;
}
