package com.abacogroup.cropplan.services;

import com.abacogroup.cropplan.api.SyncProgress;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.LocksDAO;
import com.abacogroup.cropplan.exceptions.LockException;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

public class LocksService {
	private final ValidatorService validatorService;
	private final SyncService syncService;
	private final LocksDAO locksDAO;

	public LocksService(ValidatorService validatorService, SyncService syncService, DAOContainer daocontainer) {
		this.validatorService = validatorService;
		this.syncService = syncService;
		this.locksDAO = daocontainer.getLocksDAO();
	}

	public boolean hasLock(RuntimeEnvironment env, Long cropPlanId) {
		return locksDAO.hasLock(cropPlanId, env.getUserId());
	}

	public void lockCropPlan(RuntimeEnvironment env, Long cropPlanId) {
		var syncProgress = syncService.getSyncProgress(cropPlanId);
		var transId = validatorService.getActiveTransactionId(cropPlanId);

		if (transId == null && syncProgress.getSyncProgressStatus() == SyncProgress.COMPLETED) {
			locksDAO.lockCropPlan(cropPlanId, env.getUserId());
		} else {
			locksDAO.deleteLockIfMine(cropPlanId, env.getUserId());
		}

		if (!hasLock(env, cropPlanId)) {
			if (transId == null) {
				throw new LockException(LockException.ErrorType.SYNC_IN_PROGRESS_EXCEPTION);
			} else {
				throw new LockException(LockException.ErrorType.LOCK_EXCEPTION);
			}
		}
	}
}
