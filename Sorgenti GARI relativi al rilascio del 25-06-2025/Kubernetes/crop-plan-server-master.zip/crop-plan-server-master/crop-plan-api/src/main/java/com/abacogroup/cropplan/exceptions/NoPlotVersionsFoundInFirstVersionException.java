package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class NoPlotVersionsFoundInFirstVersionException extends WebApplicationException
{
	private static final long serialVersionUID = 5339483952662738955L;

	public static  class NoPlotVersionsFoundInFirstVersionExceptionErrorBody
	{
		@Schema(allowableValues = "NO_PLOT_VERSIONS_FOUND_IN_FIRST_VERSION_EXCEPTION")
		public String getErrorCode()
		{
			return "NO_PLOT_VERSIONS_FOUND_IN_FIRST_VERSION_EXCEPTION";
		}
	}

	private static final NoPlotVersionsFoundInFirstVersionExceptionErrorBody BODY = new NoPlotVersionsFoundInFirstVersionExceptionErrorBody();

	public NoPlotVersionsFoundInFirstVersionException(String plotCode)
	{
		super("No plot " + plotCode + " versions found in first version",
			Response.status(Status.NOT_FOUND).entity(BODY).build());
	}
}
