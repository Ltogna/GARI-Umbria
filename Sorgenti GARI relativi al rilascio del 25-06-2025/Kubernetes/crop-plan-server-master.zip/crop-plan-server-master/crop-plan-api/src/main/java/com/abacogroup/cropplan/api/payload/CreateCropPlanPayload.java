package com.abacogroup.cropplan.api.payload;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CreateCropPlanPayload
{
	@Schema(description = "The crop plan type code")
	@NotEmpty
	private String cropPlanTypeCode;
	
	@NotEmpty
	private String description;
	
	@Schema(description = "If it is set to true then the crop plan is marked as not managed; default false")
	@NotNull
	private Boolean flNotManaged = false;
}
