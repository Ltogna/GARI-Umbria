package com.abacogroup.cropplan.api;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ServiceSupportEnv {
	private AbsoluteDate referenceDate;
	private Long partyId;
	private String sectorCode;
}
