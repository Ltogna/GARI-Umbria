package com.abacogroup.cropplan.api.payload;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.locationtech.jts.geom.Geometry;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SubdomainZoneRequest {

	@NotNull
	private Geometry geom;

}
