package com.abacogroup.cropplan.resources;

import com.abacogroup.cropplan.exceptions.CropPlanNotWriteableException;
import com.abacogroup.cropplan.exceptions.CropPlanReadOnlyException;
import com.abacogroup.cropplan.exceptions.LockException;
import com.abacogroup.cropplan.exceptions.PlotNotEditableException;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.LocksService;
import com.abacogroup.cropplan.services.PlotEditService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.cropplan.services.support.EditorSupportParams;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.ForbiddenException;

public abstract class BasePlotEditResource extends BaseResource {
	private CropPlanConfigService cropPlanConfigService;
	private PlotEditService plotEditService;
	private CropPlanService cropPlanService;
	private LocksService locksService;
	private ValidatorService validatorService;

	public BasePlotEditResource(BaseService baseService, CropPlanConfigService cropPlanConfigService, 
			PlotEditService plotEditService, CropPlanService cropPlanService,
			LocksService locksService, ValidatorService validatorService) {
		super(baseService);
		this.cropPlanConfigService = cropPlanConfigService;
		this.cropPlanService = cropPlanService;
		this.plotEditService = plotEditService;
		this.locksService = locksService;
		this.validatorService = validatorService;
	}

	protected void checkCanWrite(RuntimeEnvironment env, String businessId, Long cropPlanId, AbsoluteDate pointInTime)
	{
		var cropPlan = cropPlanService.getCropPlan(env, businessId, cropPlanId);
		if (cropPlan == null)
			throw new BadRequestException("The crop plan was not found");
		var accessLevel = cropPlanService.getAccessLevel(env, businessId, cropPlan.getCropPlanTypeCode());
		if (!accessLevel.canWrite())
			throw new CropPlanNotWriteableException(accessLevel.getMessageCode());
		if (cropPlan.getReadOnly())
			throw new CropPlanReadOnlyException();
		if (validatorService.getActiveTransactionId(cropPlanId) != null)
			throw new LockException();
		if (pointInTime != null)
		{
			var editAtFixedDate = cropPlanConfigService.getFixedEditDate(cropPlanId, pointInTime);
			if (editAtFixedDate != null && !pointInTime.equals(editAtFixedDate))
				throw new ForbiddenException("You are not allowed to change this business crop plan on " + pointInTime);
		}
	}

	protected void checkLock(RuntimeEnvironment env, Long cropPlanId)
	{
		if (!locksService.hasLock(env, cropPlanId))
			throw new LockException();
	}

	protected void checkPlotEditability(RuntimeEnvironment env, EditorSupportParams params, AbsoluteDate pointInTime, String plotCode)
	{
		if (!plotEditService.canEditPlot(env, params, pointInTime, plotCode))
			throw new PlotNotEditableException(plotCode);
	}

}
