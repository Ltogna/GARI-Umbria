package com.abacogroup.cropplan.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.locationtech.jts.geom.Geometry;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SubdomainZoneResponse {

	private Long id;
	private Geometry geom;

}
