package com.abacogroup.cropplan.resources.dtos;

import java.util.List;

import com.abacogroup.cropplan.api.payload.InsertPermanentCropForm;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class MassiveUpdateFieldsDto {
	@NotNull
	@Size(min = 1)
	private List<String> domainZoneIds;

	@NotNull
	@Size(min = 1)
	@Valid
	private List<LandUseCodeWithRotationDto> landUseCodeWithRotationDtos;

	@Valid
	private List<InsertPermanentCropForm> permanentCropForms;

	@Valid
	private List<LandUseAdditionalDataField> fields;
}
