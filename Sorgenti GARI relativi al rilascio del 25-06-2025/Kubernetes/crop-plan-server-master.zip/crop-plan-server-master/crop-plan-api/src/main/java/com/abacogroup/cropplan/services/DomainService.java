package com.abacogroup.cropplan.services;

import com.abacogroup.cropplan.api.DomainZone.MBR;
import com.abacogroup.cropplan.api.DomainZoneExt;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.ValidatorDAO;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.sdk.model.domain.CadastralParcelData;
import com.abacogroup.cropplan.sdk.model.domain.CadastralParcelOverlapData;
import com.abacogroup.cropplan.sdk.model.domain.DomainZoneGeometry;
import com.abacogroup.cropplan.sdk.model.domain.HoldingArea;
import com.abacogroup.cropplan.sdk.model.domain.ParcelData;
import com.abacogroup.cropplan.sdk.model.domain.Place;
import com.abacogroup.cropplan.sdk.model.domain.SnapElements;
import com.abacogroup.cropplan.sdk.model.layers.AdditionalLayer;
import com.abacogroup.cropplan.sdk.model.layers.GISInfo;
import com.abacogroup.cropplan.sdk.model.validation.AnomalyObjectType;
import com.abacogroup.cropplan.sdk.support.DomainDataSupport;
import com.abacogroup.cropplan.services.support.DomainDataSupportImpl;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.MaxRowsResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.jdbi.paging.impl.MaxRowsResultsImpl;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import org.locationtech.jts.geom.Envelope;
import org.locationtech.jts.geom.Geometry;

public class DomainService
{
	private CropPlanConfigService cropPlanConfigService;
	private CropPlansDAO cropPlansDAO;
	private ValidatorDAO validatorDAO;
	private PluginManager pluginManager;

	public DomainService(CropPlanConfigService cropPlanConfigService, DAOContainer daocontainer,
			PluginManager pluginManager) throws IOException
	{
		this.cropPlanConfigService = cropPlanConfigService;
		this.cropPlansDAO = daocontainer.getCropPlansDAO();
		this.validatorDAO = daocontainer.getValidatorDAO();
		this.pluginManager = pluginManager;
	}
	
	public HoldingArea getHoldingArea(RuntimeEnvironment env, String businessId, Long cropPlanId,
			AbsoluteDate pointInTime)
	{
		var snapFromDate = cropPlanConfigService.getSnapFromDate(cropPlanId, pointInTime);
		return pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId())
				.getHoldingArea(env, businessId, snapFromDate.toLocalDate());
	}

	public MaxRowsResults<DomainZoneExt> getDomainZonesMaxRows(RuntimeEnvironment env, String businessId, Long cropPlanId,
		LocalDateTime versionDt, AbsoluteDate pointInTime, String search, boolean filterByBusiness, boolean includeHoldingArea)
	{
		var domainPlugin = pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId());
		var snapFromDate = cropPlanConfigService.getSnapFromDate(cropPlanId, pointInTime);
		MaxRowsResults<DomainZoneGeometry> dzs;
		if (versionDt != null) {
			List<String> plotsDomainZoneIds = cropPlansDAO.getPlotsDomainZoneIds(cropPlanId, versionDt, snapFromDate);
			if (plotsDomainZoneIds.isEmpty()) {
				dzs = new MaxRowsResultsImpl<>(new ArrayList<>(), false);
			} else {
				dzs = domainPlugin.getDomainZonesByIdsMaxRows(env, businessId, search, plotsDomainZoneIds);
			}
		} else {
			versionDt = cropPlansDAO.getCurrentTimestamp();
			dzs = domainPlugin.getDomainZonesMaxRows(env, businessId, snapFromDate.toLocalDate(), search, filterByBusiness);
		}
		var ret = toDomainZonesList(env, dzs.getRecords(), businessId, cropPlanId, versionDt, pointInTime, includeHoldingArea);
		return new MaxRowsResultsImpl<>(ret, dzs.getHaveMore());
	}
	
	public HoldingArea getHoldingAreaByDomainZone(RuntimeEnvironment env, String businessId, Long cropPlanId,
			String domainZoneId, AbsoluteDate pointInTime)
	{
		var snapFromDate = cropPlanConfigService.getSnapFromDate(cropPlanId, pointInTime);
		return pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId())
				.getHoldingAreaByDomainZone(env, businessId, domainZoneId, snapFromDate.toLocalDate());
	}

	public InfiniteListResults<DomainZoneExt> getDomainZonesInfinite(RuntimeEnvironment env, String businessId, Long cropPlanId,
		LocalDateTime versionDt, AbsoluteDate pointInTime, String search, boolean filterByBusiness, boolean includeHoldingArea, String nextKey)
	{
		var domainPlugin = pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId());
		var snapFromDate = cropPlanConfigService.getSnapFromDate(cropPlanId, pointInTime);
		InfiniteListResults<DomainZoneGeometry> dzs;
		if (versionDt != null) {
			List<String> plotsDomainZoneIds = cropPlansDAO.getPlotsDomainZoneIds(cropPlanId, versionDt, snapFromDate);
			if (plotsDomainZoneIds.isEmpty()) {
				dzs = new InfiniteListResultsImpl<>(new ArrayList<>(), null);
			} else {
				dzs = domainPlugin.getDomainZonesByIdsInfinite(env, businessId, search, plotsDomainZoneIds, nextKey);
			}
		} else {
			versionDt = cropPlansDAO.getCurrentTimestamp();
			dzs = domainPlugin.getDomainZonesInfinite(env, businessId, snapFromDate.toLocalDate(), search, filterByBusiness, nextKey);
		}
		var ret = toDomainZonesList(env, dzs.getRecords(), businessId, cropPlanId, versionDt, pointInTime, includeHoldingArea);
		return new InfiniteListResultsImpl<>(ret, dzs.getNextKey());
	}

	private List<DomainZoneExt> toDomainZonesList(RuntimeEnvironment env, List<DomainZoneGeometry> dzgs, String businessId, Long cropPlanId,
		LocalDateTime versionDt, AbsoluteDate pointInTime, boolean includeHoldingArea)
	{
		var ret = new ArrayList<DomainZoneExt>();
		dzgs.forEach(dz -> {
			var domainZone = new DomainZoneExt();
			domainZone.setCode(dz.getCode());
			domainZone.setDescription(dz.getDescription());
			domainZone.setDomainZoneId(dz.getDomainZoneId());
			domainZone.setSrs(dz.getSrs());

			Geometry mbr = cropPlansDAO.getPlotsDomainMBR(cropPlanId, dz.getDomainZoneId(), versionDt, pointInTime);
			Envelope mbrEnvelope;
			if (mbr != null)
			{
				mbrEnvelope = mbr.getEnvelopeInternal();
			}
			else
			{
				mbrEnvelope = dz.getMbr().getEnvelopeInternal();
			}
			domainZone.setMbr(new MBR(mbrEnvelope.getMinX(), mbrEnvelope.getMinY(), mbrEnvelope.getMaxX(), mbrEnvelope.getMaxY()));
			
			if (includeHoldingArea)
				domainZone.setHoldingArea(getHoldingAreaByDomainZone(env, businessId, cropPlanId, dz.getDomainZoneId(), pointInTime));
			domainZone.setBigDomainZone(this.isBigDomainZone(cropPlanId, dz.getDomainZoneId(), versionDt, pointInTime));

			ret.add(domainZone);

		});
		return ret;
	}

	private boolean isBigDomainZone(Long cropPlanId, String domainZoneId, LocalDateTime versionDt, AbsoluteDate pointInTime) {
		return cropPlanConfigService.getMaxPlotsOnDomainZone(cropPlanId)
				.map(maxPlotsOnDomainZone ->
						cropPlansDAO.countPlotsInternalWithoutPlotCode(cropPlanId, domainZoneId, versionDt, pointInTime) >= maxPlotsOnDomainZone)
				.orElse(false);
	}

	public SnapElements getSnapGeometries(RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId, List<String> snapElementTypes,
			AbsoluteDate pointInTime)
	{
		var snapFromDate = cropPlanConfigService.getSnapFromDate(cropPlanId, pointInTime);
		return pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId())
				.getSnapGeometries(env, businessId, domainZoneId, snapElementTypes, snapFromDate.toLocalDate());
	}

	public List<AdditionalLayer> getAdditionalLayers(RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId, Integer campaignYear,
			String module)
	{
		return pluginManager.getLayersPlugin(businessId, cropPlanId, env.getTenantId()).getAdditionalLayers(env, businessId, domainZoneId, campaignYear, module);
	}

	public List<GISInfo> getGISInfo(RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId, AbsoluteDate pointInTime, 
		Double x, Double y, List<String> layerCodes)
	{
		var snapFromDate = cropPlanConfigService.getSnapFromDate(cropPlanId, pointInTime);
		return pluginManager.getLayersPlugin(businessId, cropPlanId, env.getTenantId()).getGISInfo(env, businessId, domainZoneId, snapFromDate.toLocalDate(), x, y, layerCodes);
	}
	
	public MaxRowsResults<Place> getPlaces(RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId, String search)
	{
		return pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId()).getPlaces(env, businessId, domainZoneId, search);
	}
	
	public InfiniteListResults<ParcelData> getParcelsData(RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId,
			AbsoluteDate pointInTime, String nextKey)
	{
		DomainDataSupport support = new DomainDataSupportImpl(env, pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId()));
		
		var snapFromDate = cropPlanConfigService.getSnapFromDate(cropPlanId, pointInTime);
		var parcels = pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId()).getParcelsData(env, businessId, domainZoneId, snapFromDate.toLocalDate(), nextKey, support);
		parcels.getRecords().forEach(parcel -> {
			parcel.setAnomalies(validatorDAO.getAnomaliesByObjectType(cropPlanId, validatorDAO.getCurrentTimestamp(), parcel.getParcelCode(), AnomalyObjectType.PARCEL, 
					env.getTenantId(), env.getLocale().getLanguage()));
		});
		return parcels;
	}
	
	public InfiniteListResults<CadastralParcelData> getCadastralParcelsData(RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId,
			AbsoluteDate pointInTime, String nextKey)
	{
		var snapFromDate = cropPlanConfigService.getSnapFromDate(cropPlanId, pointInTime);
		return pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId())
				.getCadastralParcelsData(env, businessId, domainZoneId, snapFromDate.toLocalDate(), nextKey);
	}
	
	public InfiniteListResults<CadastralParcelOverlapData> getCadastralParcelsOverlapsData(RuntimeEnvironment env, String businessId, Long cropPlanId, String domainZoneId,
			AbsoluteDate pointInTime, String nextKey)
	{
		var snapFromDate = cropPlanConfigService.getSnapFromDate(cropPlanId, pointInTime);
		return pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId())
				.getCadastralParcelsOverlapsData(env, businessId, domainZoneId, snapFromDate.toLocalDate(), nextKey);
	}

}
