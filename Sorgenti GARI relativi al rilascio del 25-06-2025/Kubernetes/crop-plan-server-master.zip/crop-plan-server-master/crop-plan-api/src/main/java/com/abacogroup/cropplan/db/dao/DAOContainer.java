package com.abacogroup.cropplan.db.dao;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DAOContainer {
	private CropPlansDAO cropPlansDAO;
	private CropPlansDeleteAndRestoreOperationsDAO cropPlansDeleteAndRestoreOperationsDAO;
	private DeclarationsDAO declarationsDAO;
	private PlotEditDAO plotEditDAO;
	private LocksDAO locksDAO;
	private ValidatorDAO validatorDAO;
	private SyncDAO syncDAO;
	private CacheDecodesDAO cacheDecodesDAO;
	private CacheLandCoverCompatibilityDAO cacheLandCoverCompatibilityDAO;
	private CropPlanConfigDAO cropPlanConfigDAO;
	private PesticidesDAO pesticidesDAO;
	private PestsDAO pestsDAO;
	private PrintsDAO printsDAO;
	private SubdomainZoneDAO subdomainZoneDAO;
}
