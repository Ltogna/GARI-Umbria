package com.abacogroup.cropplan.api.payload;

import com.abacogroup.cropplan.api.CutBehaviour;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;
import lombok.Data;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Polygon;

@Data
public class EditPlotsPayload
{
	@Schema(description = "From date")
	@NotNull
	private AbsoluteDate fromPointInTime;

	@Schema(description = "To date (optional, default propagate to infinity)")
	private AbsoluteDate toPointInTime;

	@Schema(description = "The plots")
	@NotNull
	@Size(min = 1)
	@Valid
	private List<PlotPayload> plots;

	@Data
	public static class PlotPayload
	{
		@Schema(description = "The plot code")
		@NotNull
		private String plotCode;

		@Schema(description = "The polygon geometry", type = "string", format = "WKT geometry")
		@NotNull
		private Geometry geom;
		
		public Polygon getPolygon()
		{
			return (Polygon) geom;
		}
	}

	@Schema(description = "The parameters used to apply the geometry in relation to the already existing ones")
	@NotNull
	@Valid
	private CutParameters cutParameters;

	@Data
	public static class CutParameters
	{
		@Schema(description = "The cut behaviour")
		@NotNull
		private CutBehaviour behaviour;
	}
}
