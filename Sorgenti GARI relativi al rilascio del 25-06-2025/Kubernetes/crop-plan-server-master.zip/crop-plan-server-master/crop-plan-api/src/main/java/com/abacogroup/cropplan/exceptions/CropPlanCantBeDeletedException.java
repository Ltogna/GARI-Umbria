package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class CropPlanCantBeDeletedException extends WebApplicationException
{
	private static final long serialVersionUID = -6168655621110811276L;

	public static  class CropPlanCantBeDeletedExceptionErrorBody
	{
		@Schema(allowableValues = "CROP_PLAN_CANT_BE_DELETED_EXCEPTION")
		public String getErrorCode()
		{
			return "CROP_PLAN_CANT_BE_DELETED_EXCEPTION";
		}
	}

	private static final CropPlanCantBeDeletedExceptionErrorBody BODY = new CropPlanCantBeDeletedExceptionErrorBody();

	public CropPlanCantBeDeletedException(Long cropPlanId)
	{
		super("The crop plan " + cropPlanId + " can't be deleted beacuse is not multiple",
			Response.status(Status.BAD_REQUEST).entity(BODY).build());
	}
}
