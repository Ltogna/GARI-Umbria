package com.abacogroup.cropplan.db.dao;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.customizer.QueryTimeOut;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transaction;
import org.jdbi.v3.sqlobject.transaction.Transactional;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.cropplan.db.dao.ntt.CropPlanTypeEditorParams;
import com.abacogroup.cropplan.db.dao.ntt.DeclarationData;
import com.abacogroup.cropplan.db.dao.ntt.PlotData;
import com.abacogroup.cropplan.db.dao.ntt.PlotDataParcel;
import com.abacogroup.cropplan.db.dao.ntt.PlotGeometry;
import com.abacogroup.cropplan.db.dao.ntt.PlotGeometryInSubdomain;
import com.abacogroup.cropplan.db.dao.ntt.SavePlotDatas;
import com.abacogroup.cropplan.db.dao.support.DaoSupportParams;
import com.abacogroup.cropplan.sdk.mapper.VersionColumnMapper;
import com.abacogroup.cropplan.services.support.EditorSupportParams;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(VersionColumnMapper.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface PlotEditDAO extends CommonPcfDAO, CommonLandUseAdtFldDAO, Transactional<PlotEditDAO>
{
	static final LocalDateTime DT_END_OF_WORLD = LocalDateTime.of(9999, 12, 31, 23, 59);

	@SqlQuery("§select_nextval(crpl_plot_data_seq)§")
	public Long getCropPlotDataSeq();

	@SqlQuery("§select_nextval(crpl_plot_data_parcels_seq)§")
	public Long getCropPlotDataParcelsSeq();

	@SqlQuery("§select_nextval(crpl_declarations_seq)§")
	public Long getDeclarationsSeq();

	@SqlQuery("select cpd.id as plotId,"
		+ "           cpd.plot_code as plotCode,"
		+ "           cpd.geom as geom, "
		+ "           1 as inSubdomain "
		+ "      from crpl_plots cp, crpl_plot_data cpd"
		+ "     where cp.plan_id = :cropPlanId"
		+ "       and cp.domain_zone_id = :domainZoneId"
		+ "       and cpd.plan_id = cp.plan_id"
		+ "       and cpd.plot_code = cp.plot_code"
		+ "       and §current_timestamp§ between cpd.dt_insert and cpd.dt_delete"
		+ "       and :pointInTime between cpd.day_from and cpd.day_to"
		+ "       and §geom_have_interactions(cpd.geom, :touchingGeometry)§")
	@RegisterBeanMapper(PlotGeometryInSubdomain.class)
	public List<PlotGeometryInSubdomain> getPolygonsWithInteraction(@Bind("cropPlanId") Long cropPlanId,
		@Bind("domainZoneId") String domainZoneId,
		@Bind("pointInTime") AbsoluteDate pointInTime,
		@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("select cpd.id as plotId,"
			+ "           cpd.plot_code as plotCode,"
			+ "           cpd.geom as geom, "
			+ "           §geom_have_interactions(cpd.geom, :subdomainZoneGeometry)§ as inSubdomain "
			+ "      from crpl_plots cp, crpl_plot_data cpd"
			+ "     where cp.plan_id = :cropPlanId"
			+ "       and cp.domain_zone_id = :domainZoneId"
			+ "       and cpd.plan_id = cp.plan_id"
			+ "       and cpd.plot_code = cp.plot_code"
			+ "       and §current_timestamp§ between cpd.dt_insert and cpd.dt_delete"
			+ "       and :pointInTime between cpd.day_from and cpd.day_to"
			+ "       and §geom_have_interactions(cpd.geom, :touchingGeometry)§")
	@RegisterBeanMapper(PlotGeometryInSubdomain.class)
	public List<PlotGeometryInSubdomain> getPolygonsWithInteractionInSubdomain(@Bind("cropPlanId") Long cropPlanId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("pointInTime") AbsoluteDate pointInTime,
			@Bind("touchingGeometry") Geometry touchingGeometry,
			@Bind("subdomainZoneGeometry") Geometry subdomainZoneGeometry);

	@SqlQuery("select cpd.id as plotId,"
		+ "           cpd.plot_code as plotCode,"
		+ "           cpd.geom as geom"
		+ "      from crpl_plots cp, crpl_plot_data cpd"
		+ "     where cp.plan_id = :cropPlanId"
		+ "       and cp.domain_zone_id = :domainZoneId"
		+ "       and cpd.plan_id = cp.plan_id"
		+ "       and cpd.plot_code = cp.plot_code"
		+ "       and §current_timestamp§ between cpd.dt_insert and cpd.dt_delete"
		+ "       and :pointInTime between cpd.day_from and cpd.day_to"
		+ "       and cpd.plot_code in (<plotCodes>)")
	@RegisterBeanMapper(PlotGeometry.class)
	public List<PlotGeometry> getPolygons(@Bind("cropPlanId") Long cropPlanId,
		@Bind("domainZoneId") String domainZoneId,
		@Bind("pointInTime") AbsoluteDate pointInTime,
		@BindList("plotCodes") List<String> plotCodes);
	
	@SqlQuery("select cpd.id as plotId,"
			+ "       cpd.plot_code as plotCode,"
			+ "       cpd.geom as geom"
			+ "  from crpl_plots cp, crpl_plot_data cpd, crpl_plot_data_parcels cpdp"
			+ " where cp.plan_id = :cropPlanId"
			+ "   and cp.domain_zone_id = :domainZoneId"
			+ "   and cpd.plan_id = cp.plan_id"
			+ "   and cpd.plot_code = cp.plot_code"
			+ "   and §current_timestamp§ between cpd.dt_insert and cpd.dt_delete"
			+ "   and :pointInTime between cpd.day_from and cpd.day_to"
			+ "   and cpdp.plot_data_id = cpd.id"
			+ "   and cpdp.parcel_code in (<parcelCodes>)")
		@RegisterBeanMapper(PlotGeometry.class)
		public List<PlotGeometry> getPolygonsByParcelCodes(@Bind("cropPlanId") Long cropPlanId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("pointInTime") AbsoluteDate pointInTime,
			@BindList("parcelCodes") List<String> parcelCodes);

	@SqlQuery("select cpd.id as plotId,"
		+ "           cpd.plot_code as plotCode,"
		+ "           cpd.plan_id as cropPlanId,"
		+ "           (select cpn.description from crpl_plot_names cpn where cpn.plan_id = cpd.plan_id and cpn.plot_code = cpd.plot_code and §current_timestamp§ between cpn.dt_insert and cpn.dt_delete) as description,"
		+ "           (select cpn.notes from crpl_plot_names cpn where cpn.plan_id = cpd.plan_id and cpn.plot_code = cpd.plot_code and §current_timestamp§ between cpn.dt_insert and cpn.dt_delete) as notes,"
		+ "           cpd.day_from as dayFrom,"
		+ "           cpd.day_to as dayTo,"
		+ "           cpd.srs,"
		+ "           cpd.area_sqm as areaSqm,"
		+ "           cpd.fl_soft_modified as flSoftModified,"
		+ "           cpd.user_id_insert as insertUserId,"
		+ "           cpd.user_id_delete as deleteUserId,"
		+ "           cpd.dt_insert as insertDt,"
		+ "           cpd.dt_delete as deleteDt,"
		+ "           cpd.geom"
		+ "      from crpl_plot_data cpd"
		+ "     where cpd.plan_id = :cropPlanId"
		+ "       and cpd.plot_code = :plotCode"
		+ "       and :pointInTimeFrom <= cpd.day_to"
		+ "       and :pointInTimeTo >= cpd.day_from"
		+ "       and §current_timestamp§ between cpd.dt_insert and cpd.dt_delete"
		+ "  order by cpd.day_from")
	@RegisterBeanMapper(PlotData.class)
	public List<PlotData> getPlotDatas(@Bind("cropPlanId") Long cropPlanId, @Bind("plotCode") String plotCode, 
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom, @Bind("pointInTimeTo") AbsoluteDate pointInTimeTo);

	@SqlQuery("select id, "
			+ "       plot_data_id as plotId, "
			+ "       parcel_code as parcelCode, "
			+ "       area_sqm as areaSqm, "
			+ "       land_cover_code as landCoverCode, "
			+ "       fl_outside as flOutside, "
			+ "       geom"
			+ "  from crpl_plot_data_parcels"
			+ " where plot_data_id = :plotId")
	@RegisterBeanMapper(PlotDataParcel.class)
	public List<PlotDataParcel> getPlotDataParcels(@Bind("plotId") Long plotId);

//	@SqlQuery("SELECT t.parcel_code AS parcelCode,"
//			+ "       t.domain_zone_id AS domainZoneId,"
//			+ "       (SELECT cpdp1.geom FROM crpl_plot_data_parcels cpdp1 WHERE cpdp1.id = t.id) AS geom"
//			+ "  from ("
//			+ "          select cpdp.parcel_code, cp.DOMAIN_ZONE_ID, min(cpdp.id) AS id"
//			+ "            from crpl_plots cp, crpl_plot_data cpd, crpl_plot_data_parcels cpdp"
//			+ "           where cp.plan_id = :cropPlanId"
//			+ "             and cpd.plan_id = cp.plan_id"
//			+ "             and cpd.plot_code = cp.plot_code"
//			+ "             and :versionDt between cpd.dt_insert and cpd.dt_delete"
//			+ "             and :pointInTime between cpd.day_from and cpd.day_to"
//			+ "             and cpdp.plot_data_id = cpd.id"
//			+ "           GROUP BY cpdp.parcel_code, cp.domain_zone_id"
//			+ "       ) t")
//	@RegisterBeanMapper(PlotDataParcelWithDomainZoneId.class)
//	public List<PlotDataParcelWithDomainZoneId> getAllPlotDataParcels(
//			@Bind("cropPlanId") Long cropPlanId,
//			@Bind("versionDt") LocalDateTime versionDt,
//			@Bind("pointInTime") AbsoluteDate pointInTime);
	
	@SqlQuery("select distinct pp.parcel_code \n"
			+ "  from crpl_plot_data_parcels pp \n"
			+ " inner join crpl_plot_data dd on pp.plot_data_id = dd.id \n"
			+ " where dd.plan_id = :cropPlanId \n"
			+ "   and dd.plot_code in (<plotCodes>) \n"
			+ "   and :versionDt between dd.dt_insert and dd.dt_delete \n"
			+ "   and :pointInTime between dd.day_from and dd.day_to")
	public List<String> getParcelCodesByPlotCodes(
			@BindList("plotCodes") List<String> plotCodes,
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTime") AbsoluteDate pointInTime);

	@SqlUpdate("insert into crpl_plots (plan_id, plot_code, domain_zone_id)"
		+ "      values (:cropPlanId, :plotCode, :domainZoneId)")
	public void insertPlot(@Bind("plotCode") String plotCode, @Bind("cropPlanId") Long cropPlanId,
		@Bind("domainZoneId") String domainZoneId);

	@SqlUpdate("insert into crpl_plot_names (id, plot_code, plan_id, description, notes, user_id_insert, dt_insert, dt_delete)"
		+ "      values (§nextval(crpl_plot_names_seq)§, :plotCode, :cropPlanId, :description, :notes, :insertUserId, :insertDt, :deleteDt)")
	public void insertPlotNameInternal(@Bind("plotCode") String plotCode, @Bind("cropPlanId") Long cropPlanId,
		@Bind("description") String description, @Bind("notes") String notes, @Bind("insertUserId") String insertUserId,
		@Bind("insertDt") LocalDateTime insertDt, @Bind("deleteDt") LocalDateTime deleteDt);

	@SqlUpdate("update crpl_plot_names"
		+ "        set user_id_delete = :deleteUserId,"
		+ "            dt_delete = :deleteDt"
		+ "      where plot_code = :plotCode"
		+ "        and plan_id = :cropPlanId"
		+ "        and :insertDt between dt_insert and dt_delete")
	public void updatePlotNameInternal(@Bind("plotCode") String plotCode, @Bind("cropPlanId") Long cropPlanId,
		@Bind("deleteUserId") String deleteUserId,
		@Bind("insertDt") LocalDateTime insertDt, @Bind("deleteDt") LocalDateTime deleteDt);

	@SqlUpdate("insert into crpl_plot_data (id, plot_code, plan_id, day_from, day_to, srs, area_sqm, fl_soft_modified, fl_versioned, user_id_insert, user_id_delete, dt_insert, dt_delete, geom, transaction_id)"
		+ "      values (:plotId, :plotCode, :cropPlanId, :dayFrom, :dayTo, :srs, :areaSqm, :flSoftModified, 0, :insertUserId, :deleteUserId, :insertDt, :deleteDt, :geom, :transId)")
	public void insertPlotDataInternal(@Bind("plotId") Long plotId, @Bind("plotCode") String plotCode,
		@Bind("cropPlanId") Long cropPlanId,
		@Bind("dayFrom") AbsoluteDate dayFrom, @Bind("dayTo") AbsoluteDate dayTo, @Bind("srs") String srs,
		@Bind("areaSqm") Integer areaSqm, @Bind("flSoftModified") Integer flSoftModified,
		@Bind("insertUserId") String insertUserId,
		@Bind("deleteUserId") String deleteUserId, @Bind("insertDt") LocalDateTime insertDt,
		@Bind("deleteDt") LocalDateTime deleteDt, @Bind("geom") Geometry geom, @Bind("transId") LocalDateTime transId);

	@SqlUpdate("update crpl_plot_data"
		+ "        set plot_code = :plotCode,"
		+ "            plan_id = :cropPlanId,"
		+ "            day_from = :dayFrom,"
		+ "            day_to = :dayTo,"
		+ "            srs = :srs,"
		+ "            area_sqm = :areaSqm,"
		+ "            fl_soft_modified = :flSoftModified,"
		+ "            user_id_insert = :insertUserId,"
		+ "            user_id_delete = :deleteUserId,"
		+ "            dt_insert = :insertDt,"
		+ "            dt_delete = :deleteDt,"
		+ "            geom = :geom,"
		+ "            transaction_id = :transId"
		+ "      where id = :plotId")
	@QueryTimeOut(10)
	public void updatePlotDataInternal(@Bind("plotId") Long plotId, @Bind("plotCode") String plotCode,
		@Bind("cropPlanId") Long cropPlanId,
		@Bind("dayFrom") AbsoluteDate dayFrom, @Bind("dayTo") AbsoluteDate dayTo, @Bind("srs") String srs,
		@Bind("areaSqm") Integer areaSqm, @Bind("flSoftModified") Integer flSoftModified,
		@Bind("insertUserId") String insertUserId,
		@Bind("deleteUserId") String deleteUserId, @Bind("insertDt") LocalDateTime insertDt,
		@Bind("deleteDt") LocalDateTime deleteDt, @Bind("geom") Geometry geom, @Bind("transId") LocalDateTime transId);

	@SqlUpdate("insert into crpl_plot_data_parcels (id, plot_data_id, parcel_code, area_sqm, land_cover_code, fl_outside, geom)"
		+ "      values (:id, :plotId, :parcelCode, :areaSqm, :landCoverCode, :flOutside, :geom)")
	public void insertPlotDataParcelInternal(@Bind("id") Long id, @Bind("plotId") Long plotId, @Bind("parcelCode") String parcelCode,
		@Bind("areaSqm") Integer areaSqm, @Bind("landCoverCode") String landCoverCode,
		@Bind("flOutside") Integer flOutside, @Bind("geom") Geometry geom);

	@SqlUpdate("insert into crpl_declarations (id, decl_code, plan_id, plot_code, day_from, day_from_precision, day_to, land_use_code, area_perc, fl_versioned, user_id_insert, user_id_delete, dt_insert, dt_delete, transaction_id)"
		+ "      values (:declId, :declCode, :cropPlanId, :plotCode, :dayFrom, :dayFromPrecision, :dayTo, :landUseCode, :areaPerc, 0, :insertUserId, :deleteUserId, :insertDt, :deleteDt, :transId)")
	public void insertDeclarationDataInternal(@Bind("declId") Long declId, @Bind("declCode") String declCode,
		@Bind("cropPlanId") Long cropPlanId, @Bind("plotCode") String plotCode, @Bind("dayFrom") AbsoluteDate dayFrom, 
		@Bind("dayFromPrecision") String dayFromPrecision, @Bind("dayTo") AbsoluteDate dayTo, @Bind("landUseCode") String landUseCode,
		@Bind("areaPerc") Double areaPerc, @Bind("insertUserId") String insertUserId,
		@Bind("deleteUserId") String deleteUserId, @Bind("insertDt") LocalDateTime insertDt,
		@Bind("deleteDt") LocalDateTime deleteDt, @Bind("transId") LocalDateTime transId);

	@SqlUpdate("update crpl_declarations"
		+ "        set decl_code = :declCode,"
		+ "            plan_id = :cropPlanId,"
		+ "            plot_code = :plotCode,"
		+ "            day_from = :dayFrom,"
		+ "            day_from_precision = :dayFromPrecision,"
		+ "            day_to = :dayTo,"
		+ "            land_use_code = :landUseCode,"
		+ "            area_perc = :areaPerc,"
		+ "            user_id_insert = :insertUserId,"
		+ "            user_id_delete = :deleteUserId,"
		+ "            dt_insert = :insertDt,"
		+ "            dt_delete = :deleteDt,"
		+ "            transaction_id = :transId"
		+ "      where id = :declId")
	public void updateDeclarationDataInternal(@Bind("declId") Long declId, @Bind("declCode") String declCode,
		@Bind("cropPlanId") Long cropPlanId, @Bind("plotCode") String plotCode, @Bind("dayFrom") AbsoluteDate dayFrom, 
		@Bind("dayFromPrecision") String dayFromPrecision, @Bind("dayTo") AbsoluteDate dayTo, @Bind("landUseCode") String landUseCode,
		@Bind("areaPerc") Double areaPerc, @Bind("insertUserId") String insertUserId,
		@Bind("deleteUserId") String deleteUserId, @Bind("insertDt") LocalDateTime insertDt,
		@Bind("deleteDt") LocalDateTime deleteDt, @Bind("transId") LocalDateTime transId);

	@SqlQuery("select cpd.day_from as dayFrom"
		+ "      from crpl_plots cp, crpl_plot_data cpd"
		+ "     where cp.plan_id = :cropPlanId"
		+ "       and cp.domain_zone_id = :domainZoneId"
		+ "       and cpd.plan_id = cp.plan_id"
		+ "       and cpd.plot_code = cp.plot_code"
		+ "       and §current_timestamp§ between cpd.dt_insert and cpd.dt_delete"
		+ "       and cpd.day_from > :pointInTime"
		+ "       and §geom_have_interactions(cpd.geom, :touchingGeometry)§"
		+ "  order by cpd.day_from")
	public List<AbsoluteDate> getFutureInteractions(@Bind("cropPlanId") Long cropPlanId,
		@Bind("domainZoneId") String domainZoneId,
		@Bind("pointInTime") AbsoluteDate pointInTime,
		@Bind("touchingGeometry") Geometry touchingGeometry);

	@SqlQuery("select ct.fl_limit_to_canvas, fl_split_on_canvas"
		+ "      from crpl_types ct, crpl_plans cp"
		+ "     where ct.tenant_id = :tenantId"
		+ "       and §current_timestamp§ between ct.dt_insert and ct.dt_delete"
		+ "       and cp.type_id = ct.id"
		+ "       and cp.id = :cropPlanId")
	@RegisterBeanMapper(CropPlanTypeEditorParams.class)
	public CropPlanTypeEditorParams getCropPlanTypeEditorParams(@Bind("cropPlanId") Long cropPlanId, @Bind("tenantId") String tenantId);

	
	@SqlUpdate("update crpl_sync cs set reference_dt = null"
			+ "  WHERE cs.PLAN_ID = :cropPlanId"
			+ "    AND cs.DT_SYNC = (SELECT max(cs1.dt_sync) FROM crpl_sync cs1 WHERE cs1.PLAN_ID = cs.PLAN_ID)")
	public void clearSyncRefDateToForceRecalcAnomalies(@Bind("cropPlanId") Long cropPlanId);
	
	@SqlQuery("select cpd.id as plotId,"
	+ "           cpd.plot_code as plotCode,"
	+ "           cpd.geom as geom, "
	+ "           1 as inSubdomain "
	+ "      from crpl_plots cp, crpl_plot_data cpd"
	+ "     where cp.plan_id = :cropPlanId"
	+ "       and cp.domain_zone_id = :domainZoneId"
	+ "       and cpd.plan_id = cp.plan_id"
	+ "       and cpd.plot_code = cp.plot_code"
	+ "       and §current_timestamp§ between cpd.dt_insert and cpd.dt_delete"
	+ "       and :pointInTime between cpd.day_from and cpd.day_to"
	+ "       and §geom_have_interactions(:touchingGeometry, cpd.geom)§")
	@RegisterBeanMapper(PlotGeometryInSubdomain.class)
	public List<PlotGeometryInSubdomain> getPolygonsWithInteractionWithNoSpatialIndex(@Bind("cropPlanId") Long cropPlanId,
		@Bind("domainZoneId") String domainZoneId,
		@Bind("pointInTime") AbsoluteDate pointInTime,
		@Bind("touchingGeometry") Geometry touchingGeometry);


		@SqlQuery("select cpd.id as plotId,"
		+ "           cpd.plot_code as plotCode,"
		+ "           cpd.geom as geom, "
		+ "           §geom_have_interactions(:subdomainZoneGeometry, cpd.geom )§ as inSubdomain "
		+ "      from crpl_plots cp, crpl_plot_data cpd"
		+ "     where cp.plan_id = :cropPlanId"
		+ "       and cp.domain_zone_id = :domainZoneId"
		+ "       and cpd.plan_id = cp.plan_id"
		+ "       and cpd.plot_code = cp.plot_code"
		+ "       and §current_timestamp§ between cpd.dt_insert and cpd.dt_delete"
		+ "       and :pointInTime between cpd.day_from and cpd.day_to"
		+ "       and §geom_have_interactions(:touchingGeometry, cpd.geom)§")
	@RegisterBeanMapper(PlotGeometryInSubdomain.class)
	public List<PlotGeometryInSubdomain> getPolygonsWithInteractionInSubdomainWithNoSpatialIndex(@Bind("cropPlanId") Long cropPlanId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("pointInTime") AbsoluteDate pointInTime,
			@Bind("touchingGeometry") Geometry touchingGeometry,
			@Bind("subdomainZoneGeometry") Geometry subdomainZoneGeometry);

		@SqlQuery("select cpd.day_from as dayFrom"
		+ "      from crpl_plots cp, crpl_plot_data cpd"
		+ "     where cp.plan_id = :cropPlanId"
		+ "       and cp.domain_zone_id = :domainZoneId"
		+ "       and cpd.plan_id = cp.plan_id"
		+ "       and cpd.plot_code = cp.plot_code"
		+ "       and §current_timestamp§ between cpd.dt_insert and cpd.dt_delete"
		+ "       and cpd.day_from > :pointInTime"
		+ "       and §geom_have_interactions(:touchingGeometry, cpd.geom)§"
		+ "  order by cpd.day_from")
		public List<AbsoluteDate> getFutureInteractionsWithNoSpatialIndex(@Bind("cropPlanId") Long cropPlanId,
			@Bind("domainZoneId") String domainZoneId,
			@Bind("pointInTime") AbsoluteDate pointInTime,
			@Bind("touchingGeometry") Geometry touchingGeometry);
	@Transaction
	public default void savePlotDatas(SavePlotDatas savePlotDatas, String domainZoneId, LocalDateTime transId)
	{
		savePlotDatas.getPlotDatas().forEach(p -> {
			savePlot(domainZoneId, transId, p);
		});

		savePlotDatas.getPlotDataParcels().forEach(p -> {
			 p.setId(getCropPlotDataParcelsSeq());
			 insertPlotDataParcel(p);
		});

		savePlotDatas.getDeclarationDatas().forEach(d -> {
			saveDeclaration(transId, d);
		});

		
		savePlotDatas.getPermanentCropFormSaveDatas().forEach(pcfData ->
		{
			if (pcfData.isNew())
			{
				var pcfId = getPermanentCropFormsSeq();
				var pcf = pcfData.getPcf();
				insertPermanentCropForm(pcfId, pcf.getFormCode() == null ? String.valueOf(pcfId) : pcf.getFormCode(), pcf.getFormType(), pcfData.getCropPlanId(), pcfData.getPlotCode(),
				pcfData.getDeclCode(), pcfData.getUserId(), pcfData.getSaveDt(), transId, pcf.getPermanentCropFormData());
			}
			else
				deletePermanentCropFormsInternal(pcfData.getPcf().getFormCode(), pcfData.getDeclCode(), pcfData.getPlotCode(), pcfData.getCropPlanId(),
					pcfData.getSaveDt(), pcfData.getUserId(), transId);
		});

		// additional declaration fields
		savePlotDatas.getFieldsCodes().forEach(fc -> {
			
			DaoSupportParams daoParm = DaoSupportParams.builder()
					.insertDt(fc.getSaveDt())
					.deleteDt(fc.getSaveDt())
					.insertUserId(fc.getUserId())
					.deleteUserId(fc.getUserId())
					.transId(transId)
					.flVersioned(0)
					.cropPlanId(fc.getCropPlanId())
					.plotCode(fc.getPlotCode())
					.declCode(fc.getDeclCode())
					.landUseCode(fc.getLandUseCode())
				.build();
			
			outdateDeclAdditFieldsInternal(daoParm, fc.getFieldCode()); // FIXME if in future there might be more rows with the same field_code this could be a problem 
			if(fc.isNew()) {
				daoParm.setDeleteDt(DT_END_OF_WORLD);
				daoParm.setDeleteUserId(null);
				Long nextId = getDeclAdditFieldsSeq();
				insertDeclAdditFields(daoParm, nextId, fc);
			}
			
		});
		
	}
	
	private void savePlot(String domainZoneId, LocalDateTime transId, PlotData p) {
		try {
		if (p.isNew())
		{
			if (p.getPlotId() == null)
			{
				p.setPlotId(getCropPlotDataSeq());
			}
			else if (p.getPlotId().toString().compareTo(p.getPlotCode()) == 0)
			{
				insertPlot(p.getPlotCode(), p.getCropPlanId(), domainZoneId);
				insertPlotNameInternal(p.getPlotCode(), p.getCropPlanId(), p.getDescription(), p.getNotes(),
					p.getInsertUserId(), p.getInsertDt(), LocalDateTime.of(9999, 12, 31, 0, 0));
			}

			insertPlotData(p, transId);
		}
		else
			updatePlotData(p, transId);
		} catch (Exception e) {
			throw e;
		}
	}

	private void saveDeclaration(LocalDateTime transId, DeclarationData d) {
		if (d.isNew())
		{
			if (d.getDeclId() == null)
			{
				d.setDeclId(getDeclarationsSeq());
			}
			if (d.getDeclCode() == null)
			{
				d.setDeclCode(String.valueOf(d.getDeclId()));
			}

			insertDeclarationData(d, transId);
		}
		else
			updateDeclarationData(d, transId);
	}

	

	@Transaction
	default public void renamePlot(RuntimeEnvironment env, EditorSupportParams editorSupportParams, String plotCode, String description, String notes)
	{
		var deleteDt = editorSupportParams.getVersionDt().minus(Duration.ofMillis(1));

		updatePlotNameInternal(plotCode, editorSupportParams.getCropPlanId(), env.getUserId(), editorSupportParams.getVersionDt(), deleteDt);
		insertPlotNameInternal(plotCode, editorSupportParams.getCropPlanId(), description, notes, env.getUserId(), editorSupportParams.getVersionDt(), LocalDateTime.of(9999, 12, 31, 0, 0));
	}

	private void insertPlotData(PlotData plotData, LocalDateTime transId)
	{
		insertPlotDataInternal(plotData.getPlotId(), plotData.getPlotCode(), plotData.getCropPlanId(),
			plotData.getDayFrom(), plotData.getDayTo(), plotData.getSrs(),
			plotData.getAreaSqm(), plotData.isFlSoftModified() ? 1 : 0, 
			plotData.getInsertUserId(), plotData.getDeleteUserId(), plotData.getInsertDt(), plotData.getDeleteDt(),
			plotData.getGeom(), transId);
	}

	private void updatePlotData(PlotData plotData, LocalDateTime transId)
	{
		updatePlotDataInternal(plotData.getPlotId(), plotData.getPlotCode(), plotData.getCropPlanId(),
			plotData.getDayFrom(), plotData.getDayTo(), plotData.getSrs(),
			plotData.getAreaSqm(), plotData.isFlSoftModified() ? 1 : 0, 
			plotData.getInsertUserId(), plotData.getDeleteUserId(), plotData.getInsertDt(), plotData.getDeleteDt(),
			plotData.getGeom(), transId);
	}

	private void insertPlotDataParcel(PlotDataParcel plotDataParcel)
	{
		insertPlotDataParcelInternal(plotDataParcel.getId(), plotDataParcel.getPlotId(), plotDataParcel.getParcelCode(),
			plotDataParcel.getAreaSqm(), plotDataParcel.getLandCoverCode(), plotDataParcel.isFlOutside() ? 1 : 0,
				plotDataParcel.getGeom());
	}

	private void insertDeclarationData(DeclarationData declarationData, LocalDateTime transId)
	{
		insertDeclarationDataInternal(declarationData.getDeclId(), declarationData.getDeclCode(), declarationData.getCropPlanId(),
			declarationData.getPlotCode(), declarationData.getDayFrom(), declarationData.getDayFromPrecision(), declarationData.getDayTo(),
			declarationData.getLandUseCode(), declarationData.getAreaPerc(), 
			declarationData.getInsertUserId(), declarationData.getDeleteUserId(), declarationData.getInsertDt(),
			declarationData.getDeleteDt(), transId);
	}

	private void updateDeclarationData(DeclarationData declarationData, LocalDateTime transId)
	{
		updateDeclarationDataInternal(declarationData.getDeclId(), declarationData.getDeclCode(), declarationData.getCropPlanId(),
			declarationData.getPlotCode(), declarationData.getDayFrom(), declarationData.getDayFromPrecision(), declarationData.getDayTo(),
			declarationData.getLandUseCode(), declarationData.getAreaPerc(), 
			declarationData.getInsertUserId(), declarationData.getDeleteUserId(), declarationData.getInsertDt(),
			declarationData.getDeleteDt(), transId);
	}



}
