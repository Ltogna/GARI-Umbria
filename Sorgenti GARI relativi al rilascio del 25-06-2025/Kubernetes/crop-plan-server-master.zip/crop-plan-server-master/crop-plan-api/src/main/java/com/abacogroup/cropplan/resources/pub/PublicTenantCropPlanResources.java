package com.abacogroup.cropplan.resources.pub;

import static java.util.stream.Collectors.toList;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.cropplan.api.ChangedPlot;
import com.abacogroup.cropplan.api.CropPlan;
import com.abacogroup.cropplan.api.CropPlanDates;
import com.abacogroup.cropplan.api.CropPlanPrintParams;
import com.abacogroup.cropplan.api.CropPlanType;
import com.abacogroup.cropplan.api.CuaaAreasAndAnomalies;
import com.abacogroup.cropplan.api.DisabledFunctionCode;
import com.abacogroup.cropplan.api.ExcludeAddInfo;
import com.abacogroup.cropplan.api.PlanHasDeclarationsForLandUse;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.PlotDataToInclude;
import com.abacogroup.cropplan.api.PlotDeclaredAreas;
import com.abacogroup.cropplan.api.PlotDomain;
import com.abacogroup.cropplan.api.PlotLifecycle;
import com.abacogroup.cropplan.api.SyncOperation;
import com.abacogroup.cropplan.api.SyncStatus;
import com.abacogroup.cropplan.api.ValidationAnomalies;
import com.abacogroup.cropplan.api.payload.CreateCropPlanPayload;
import com.abacogroup.cropplan.api.payload.CreateVersionPayload;
import com.abacogroup.cropplan.api.payload.GetPermanentCropFormSubscriptionsPayload;
import com.abacogroup.cropplan.api.payload.SyncCropPlanPayload;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.ntt.ScenarioAnomaliesDisableFunctionsConfigurations;
import com.abacogroup.cropplan.exceptions.CropPlanCantBeDeletedException;
import com.abacogroup.cropplan.exceptions.CropPlanNotCreateableException;
import com.abacogroup.cropplan.exceptions.CropPlanNotWriteableException;
import com.abacogroup.cropplan.exceptions.CropPlanReadOnlyException;
import com.abacogroup.cropplan.exceptions.LockException;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.BaseCropPlanResource;
import com.abacogroup.cropplan.resources.dtos.CalculateAnomaliesDto;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.CropPlanVersion;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormFieldCodes;
import com.abacogroup.cropplan.sdk.model.PermanentCropFormSubscription;
import com.abacogroup.cropplan.sdk.model.PlotTimeline;
import com.abacogroup.cropplan.sdk.model.Version;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseDetails;
import com.abacogroup.cropplan.sdk.model.sync.SyncType;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomaly;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorAnomaliesResult;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.CropPlanDeclarationsService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.DeclarationService;
import com.abacogroup.cropplan.services.LocksService;
import com.abacogroup.cropplan.services.PrintService;
import com.abacogroup.cropplan.services.SyncService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.cropplan.services.support.PlotTimeWindowParams;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.ForbiddenException;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.SecurityContext;

@Path("{tenant}/public")
@Tag(name = "PUBLIC - Crop plan resources")
@Timed
@RolesAllowed({"CRPL|USER","CRPL|EDITOR"})
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class PublicTenantCropPlanResources extends BaseCropPlanResource
{
	private static int PAGE_SIZE = 10;
	private static int LARGE_PAGE_SIZE = 50;
	private static final Logger log = LoggerFactory.getLogger(PublicTenantCropPlanResources.class);
	private CropPlanService cropPlanService;
	private CropPlanDeclarationsService cropPlanDeclarationsService;
	private DeclarationService declarationsService;
	private SyncService syncService;
	private LocksService locksService;
	private CropCodeService cropCodeService;
	private PrintService printService;
	private ValidatorService validatorService;
	private PluginManager pluginManager;
	private CropPlansDAO cropPlansDAO;

	public PublicTenantCropPlanResources(BaseService baseService, CropPlanService cropPlanService, CropPlanDeclarationsService cropPlanDeclarationsService,
			DeclarationService declarationsService, SyncService syncService, LocksService locksService, CropCodeService cropCodeService,
			ValidatorService validatorService, CropPlanConfigService cropPlanConfigService, PrintService printService, PluginManager pluginManager, DAOContainer daocontainer) {
		super(baseService, cropPlanService, locksService, cropCodeService, validatorService, cropPlanConfigService, pluginManager, daocontainer.getCropPlansDAO()
		);
		this.cropPlanService = cropPlanService;
		this.cropPlanDeclarationsService = cropPlanDeclarationsService;
		this.declarationsService = declarationsService;
		this.syncService = syncService;
		this.locksService = locksService;
		this.cropCodeService = cropCodeService;
		this.printService = printService;
		this.validatorService = validatorService;
		this.pluginManager = pluginManager;
		this.cropPlansDAO = daocontainer.getCropPlansDAO();
	}
	
	/**
	 * @param excludes List<excludeAddInfo>
	 * 
	 * @return plotDataToInclude
	 */
	private PlotDataToInclude setPlotDataToIncludeFromQueryParam(List<ExcludeAddInfo> excludes) {
		PlotDataToInclude plotDataToInclude = new PlotDataToInclude();
		if(excludes.size()>1) {
			excludes = excludes.stream().distinct().collect(toList());
		}
		if(excludes.size()>0) {
			excludes.stream().distinct().forEach(excludeAddInfo->{
				switch (excludeAddInfo) {
			    case PARCELS: 
			    	plotDataToInclude.setParcInt(false);
			    	plotDataToInclude.setParcIntDesc(false);
			    	plotDataToInclude.setParcIntLandCoverDesc(false);
			    	plotDataToInclude.setMbrOverview(false);
			    	plotDataToInclude.setParcStyle(false);
			    	break;
			    case PARCELS_DESCRIPTION: plotDataToInclude.setParcIntDesc(false);break;
			    case PARCELS_LAND_COVER_DESC: plotDataToInclude.setParcIntLandCoverDesc(false);break;
			    case PARCELS_PLOT_STYLE: plotDataToInclude.setParcStyle(false);break;
			    case PARCELS_MBR_OVERVIEW: plotDataToInclude.setMbrOverview(false);break;
			    case PARCELS_PLOT_EDITABILITY: plotDataToInclude.setPlotEditability(false);break;
			    case DECLARATIONS: 
			    	plotDataToInclude.setDecls(false);
			    	plotDataToInclude.setDeclsPesticides(false);
			    	plotDataToInclude.setDeclsStyle(false);
			    	break;
			    case DECLARATIONS_PESTICIDES: plotDataToInclude.setDeclsPesticides(false);break;
			    case DECLARATIONS_PLOT_STYLE: plotDataToInclude.setDeclsStyle(false);break;
			    case ANOMALIES: plotDataToInclude.setAnomalies(false);break;
			    default: log.info("API getPlots excludes param contain an unknow value: {}",excludeAddInfo);break;
				};
			});
		}
		return plotDataToInclude;
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plan-types")
	@Operation(description = "Get the list of the available crop plan types")
	@ApiResponse(description = "The list of the available crop plan types")
	public List<CropPlanType> getCropPlanTypes(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		checkCanRead(user, language, businessId);

		return this.cropPlansDAO.getCropPlanTypes(tenantId, language);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans")
	@Operation(description = "Get the list of the crop plans of a business")
	@ApiResponse(description = "The list of the crop plans of the specified business")
	public InfiniteListResults<CropPlan> getCropPlans(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan type code; can be specified to filter crop plans of a specific type") @QueryParam("cropPlanTypeCode") String cropPlanTypeCode,
		@Parameter(description = "The search string to search by crop plan type or crop plan description") @QueryParam("search") String search,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(user, language, businessId);

		return cropPlanService.getCropPlans(env, businessId, cropPlanTypeCode, search, nextKey, PAGE_SIZE);
	}

	@PUT
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/lock")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Lock the specified crop plan for the current user")
	@ApiResponses({
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class)))
	})
	public void lockCropPlan(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);

		locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/versions")
	@Operation(description = "Get the versions list of a crop plan")
	@ApiResponse(description = "The versions list of the specified crop plan")
	public InfiniteListResults<CropPlanVersion> getAllVersions(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "If it is set to true then also in publishing versions are returned") @QueryParam("includeInPublishing") @DefaultValue("false") boolean includeInPublishing,
		@Parameter(description = "Can be supplied to obtain only versions created at a specified reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return cropPlanService.getAllVersions(env, businessId, cropPlanId, includeInPublishing, referenceDate, nextKey, PAGE_SIZE);
	}

	@POST
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/versions")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Create a new version of the specified crop plan")
	@ApiResponses({
		@ApiResponse(description = "The new crop plan version created"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "400", description = "No changes pending on the crop plan"),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public CropPlanVersion createVersion(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "If it is set to true then the new version is created also if the crop plan does not have changes pending") @QueryParam("forcePublish") @DefaultValue("false") boolean forcePublish,
		@Parameter(description = "If it is set to true then the specified crop plan is locked for the current user before version creation") @QueryParam("autoLock") @DefaultValue("false") boolean autoLock,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid CreateVersionPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		if (autoLock)
			locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
		else
			checkLock(env, cropPlanId);

		return cropPlanService.createVersion(createEnvironment(user, language), businessId, cropPlanId, payload, forcePublish);
	}

	@POST
	@Path("/v1/crop-plans/{businessId}/plans")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Create a new crop plan")
	@ApiResponses({
		@ApiResponse(description = "The new crop plan created"),
		@ApiResponse(responseCode = "400", description = "The crop plan type specified does not exist"),
		@ApiResponse(responseCode = "405", description = "A crop plan of the specified not multiple type already exist"),
		@ApiResponse(responseCode = "403", description = "You are not allowed to create crop plans for this business", content = @Content(schema = @Schema(implementation = CropPlanNotCreateableException.CropPlanNotCreateableExceptionErrorBody.class)))
	})
	public CropPlan createCropPlan(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@NotNull @Valid CreateCropPlanPayload payload,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);

		var cropPlanId = cropPlanService.insertCropPlan(env, businessId, payload);
		return cropPlanService.getCropPlan(env, businessId, cropPlanId);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots")
	@Operation(description = "Get the list of the plots of a crop plan")
	@ApiResponse(description = "The list of the plots of the specified crop plan")
	public InfiniteListResults<Plot> getPlots(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "The ending point in time to be evaluated (optional, if set then the plots are evaluated between point in time and point in time to") @QueryParam("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@Parameter(description = "If set to true then the declaration dates are not cropped to the pointInTime dates with a pointInTimeTo specified") @QueryParam("doNotAdjustDeclDates") @DefaultValue("false") boolean doNotAdjustDeclDates,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@Parameter(description = "The crop plan additional info to exclude (optional, if not set all data is returned)") @QueryParam("excludes") List<ExcludeAddInfo> excludes,
			@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);
		PlotDataToInclude plotDataToInclude = setPlotDataToIncludeFromQueryParam(excludes);
		
		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		if (pointInTimeTo != null)
			return cropPlanService.getPlotsBetweenDates(createEnvironment(user, language), businessId, cropPlanId, domainZoneId,
					versionDt, pointInTime, pointInTimeTo, null, nextKey, PAGE_SIZE, plotDataToInclude, doNotAdjustDeclDates);
		else
			return cropPlanService.getPlots(createEnvironment(user, language), businessId, cropPlanId, domainZoneId,
				versionDt, pointInTime, null, null, nextKey, PAGE_SIZE, plotDataToInclude);
	}
	
	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/plots")
	@Operation(description = "Get the list of the plots of a crop plan")
	@ApiResponse(description = "The list of the plots of the specified crop plan")
	public InfiniteListResults<Plot> getAllPlots(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
		@Parameter(description = "The ending point in time to be evaluated (optional, if set then the plots are evaluated between point in time and point in time to") @QueryParam("pointInTimeTo") AbsoluteDate pointInTimeTo,
		@Parameter(description = "If set to true then the declaration dates are not cropped to the pointInTime dates with a pointInTimeTo specified") @QueryParam("doNotAdjustDeclDates") @DefaultValue("false") boolean doNotAdjustDeclDates,
		@Parameter(description = "The parcel code search string to filter plots intersecting parcels") @QueryParam("parcelCodeStartsWith") String parcelCodeStartsWith,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@Parameter(description = "The crop plan additional info to exclude (optional, if not set all data is returned)") @QueryParam("excludes") List<ExcludeAddInfo> excludes,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);
		PlotDataToInclude plotDataToInclude = setPlotDataToIncludeFromQueryParam(excludes);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		if (pointInTimeTo != null)
			return cropPlanService.getPlotsBetweenDates(createEnvironment(user, language), businessId, cropPlanId, null,
				versionDt, pointInTime, pointInTimeTo, parcelCodeStartsWith, nextKey, LARGE_PAGE_SIZE, plotDataToInclude, doNotAdjustDeclDates);
		else
			return cropPlanService.getPlots(createEnvironment(user, language), businessId, cropPlanId, null,
				versionDt, pointInTime, parcelCodeStartsWith, null, nextKey, LARGE_PAGE_SIZE, plotDataToInclude);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/declared-plots/{landUseCode}")
	@Operation(description = "Get the list of the plots with at least a declaration with a given land use of a crop plan")
	@ApiResponse(description = "The list of the plots with at least a declaration with a given land use of the specified crop plan")
	public List<PlotDomain> getDeclaredPlots(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The land use code filter") @PathParam("landUseCode") @NotNull String landUseCode,
		@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
		@Parameter(description = "Can be supplied to convert geometries returned in the specified srs") @QueryParam("srs") String srs,
		@Parameter(description = "If it is set to true then it returns only plots on which are declareable pesticides") @QueryParam("filterDeclareablePesticidesPlots") @DefaultValue("true") boolean filterDeclareablePesticidesPlots,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, tenantId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		var landCoverCode = cropCodesPlugin.getLandCoverCode(env, landUseCode);
		var plotsByLandCoverCode = cropPlanService.getPlotsByLandCoverCode(env, businessId, cropPlanId, versionDt, pointInTime, null, landCoverCode, srs, new PlotDataToInclude());

		//The plot has declarations and there is at least a declaration with the given landusecode
		return plotsByLandCoverCode.stream().filter(plot -> 
			plot.getPlot().getDecls().size() > 0 
			&& 
			plot.getPlot().getDecls().stream().filter(decl -> 
				decl.getLanduse().getCode().equals(landUseCode)
			).count() > 0
			&& ((filterDeclareablePesticidesPlots &&
			plot.getPlot().getParcelIntersections().stream().filter(parc -> 
				parc.getCanDeclarePesticides() == false
			).count() == 0) || !filterDeclareablePesticidesPlots)
		).collect(toList());
	}
	
	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/has-declarations")
	@Operation(description = "Get the list of the plots with at least a declaration of a crop plan at the specified point in time")
	@ApiResponse(description = "The list of the plots with at least a declaration of a crop plan at the specified point in time")
	public PlanHasDeclarationsForLandUse getPlanHasDeclarationsForLandUse(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The list of the land use codes") @QueryParam("landUseCodes") @NotEmpty List<String> landUseCodes,
		@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		
		PlanHasDeclarationsForLandUse planHasDeclarationsForLandUse = declarationsService.getPlanHasDeclarationsForLandUse(env, businessId, cropPlanId,
				versionDt, pointInTime, landUseCodes);
		
		return planHasDeclarationsForLandUse;
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/plots/declarable-plots")
	@Operation(description = "Get the list of the plots of a crop plan")
	@ApiResponse(description = "The list of the plots of the specified crop plan")
	public List<PlotDomain> getDeclarablePlots(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
		@Parameter(description = "The ending point in time to be evaluated") @QueryParam("pointInTimeTo") @NotNull AbsoluteDate pointInTimeTo,
		@Parameter(description = "The land use code filter") @QueryParam("landUseCode") @NotNull String landUseCode,
		@Parameter(description = "The percentage of declared area") @QueryParam("declaredAreaPerc") @NotNull String declaredAreaPerc,
		@Parameter(description = "Can be supplied to convert geometries returned in the specified srs") @QueryParam("srs") String srs,
		@Parameter(description = "The crop plan additional info to exclude (optional, if not set all data is returned)") @QueryParam("excludes") List<ExcludeAddInfo> excludes,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);
		PlotDataToInclude plotDataToInclude = setPlotDataToIncludeFromQueryParam(excludes);

		var cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, tenantId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		var landCoverCode = cropCodesPlugin.getLandCoverCode(env, landUseCode);
		var plotsByLandCoverCode = cropPlanService.getPlotsByLandCoverCode(env, businessId, cropPlanId, versionDt, pointInTime, pointInTimeTo, landCoverCode, srs, plotDataToInclude);

		List<PlotDomain> output = new ArrayList<>();
		for (PlotDomain plot : plotsByLandCoverCode)
		{
			var params = PlotTimeWindowParams.builder()
					.businessId(businessId)
					.cropPlanId(cropPlanId)
					.domainZoneId(plot.getDomainZone().getDomainZoneId())
					.plotCode(plot.getPlot().getPlotCode())
					.excludedDeclCode(null)
					.pointInTimeFrom(pointInTime)
					.pointInTimeTo(pointInTimeTo)
					.versionDt(versionDt)
					.build();
			var plotDeclaredAreas = cropPlanService.getPlotDeclaredAreas(params, false);

			if (Double.parseDouble(declaredAreaPerc) <= plotDeclaredAreas.getMaxDeclarableAreaPerc())
				output.add(plot);
		}
		return output;
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}")
	@Operation(description = "Get a plot")
	@ApiResponses({
		@ApiResponse(description = "The specified plot"),
		@ApiResponse(responseCode = "400", description = "The specified plot was not found")
	})
	public Plot getPlot(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
		@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		var plot = cropPlanService.getPlot(createEnvironment(user, language), businessId, cropPlanId, domainZoneId,
			versionDt, pointInTime, pointInTime, plotCode);

		if (plot == null)
			throw new BadRequestException("The specified plot was not found");

		return plot;
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/sync")
	@Operation(description = "Get the crop plan sync operations")
	@ApiResponse(description = "The sync operations")
	public InfiniteListResults<SyncOperation> getSyncOperations(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return syncService.getSyncOperations(cropPlanId, nextKey, PAGE_SIZE);
	}
	
	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/sync/status")
	@Operation(description = "Get the crop plan sync progress status")
	@ApiResponse(description = "The sync progress status")
	public SyncStatus getSyncProgressStatus(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return syncService.getSyncProgress(cropPlanId);
	}

	@PUT
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/sync/{syncType}")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Synchronize crop plan")
	@ApiResponses({
		@ApiResponse(description = "The sync progress status"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public SyncStatus syncCropPlan(
		@Parameter(hidden = true) @Auth User user,
		@Context SecurityContext context,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The sync type") @PathParam("syncType") SyncType syncType,
		@Parameter(description = "If it is set to true then the specified crop plan is locked for the current user before version creation") @QueryParam("autoLock") @DefaultValue("false") boolean autoLock,
		@Parameter(description = "If it is set to true then new plots are created without assigning default crops") @QueryParam("ignoreDefaults") @DefaultValue("false") boolean ignoreDefaults,
		@Parameter(description = "If it is set to true then the sync process ignore previous syncs") @QueryParam("ignorePreviousSyncs") @DefaultValue("false") boolean ignorePreviousSyncs,
		@Valid SyncCropPlanPayload payload,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		if (ignorePreviousSyncs && !context.isUserInRole("CRPL|CAN_FORCE_SYNC"))
			throw new ForbiddenException("You are not allowed to perform a forced sync operation");
		
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId, true);
		if (autoLock)
			locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
		else
			checkLock(env, cropPlanId);

		return syncService.syncCropPlan(env, businessId, cropPlanId, syncType, payload, ignoreDefaults, ignorePreviousSyncs);
	}
	
	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/config-functions-disabled")
	@Operation(description = "Get the Scenario Anomalies Disabled Functions Configurations")
	@ApiResponse(description = "The Scenario Anomalies Disabled Functions Configurations")
	public ScenarioAnomaliesDisableFunctionsConfigurations getFunctionsdDisabledConfig(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The Disabled Function Code") @QueryParam("disabledFunctionCode") DisabledFunctionCode disabledFunctionCode,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);
		return cropPlanService.getPlotDisabledFunctionsConfig(disabledFunctionCode ,env, businessId, cropPlanId);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/lifecycle")
	@Operation(description = "Get the lifecycle details of a plot")
	@ApiResponses({
		@ApiResponse(description = "The lifecycle details of the specified plot"),
		@ApiResponse(responseCode = "400", description = "The specified plot was not found")
	})
	public PlotLifecycle getPlotLifecycle(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
		@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		return cropPlansDAO.getPlotLifecycle(cropPlanId, domainZoneId, versionDt, plotCode);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/land-uses")
	@Operation(description = "Get the list of the land uses")
	@ApiResponse(description = "The list of the land uses")
	public InfiniteListResults<LandUseDetails> getLandUseCodes(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The list of the land cover codes") @QueryParam("landCoverCodes") List<String> landCoverCodes,
		@Parameter(description = "The search string") @QueryParam("search") String search,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);
		
		return cropCodeService.getLandUseCodesInfinite(env, businessId, cropPlanId, landCoverCodes, search, pointInTime, nextKey);
	}
	
	@GET
	@Path("/v1/crop-plans/land-uses/{cropPlanTypeCode}")
	@Operation(description = "Get the list of the land uses of the specified crop plan type code")
	@ApiResponse(description = "The list of the land uses of the specified crop plan type code")
	public InfiniteListResults<LandUseDetails> getLandUseCodesNoBusiness(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The crop plan type code") @PathParam("cropPlanTypeCode") String cropPlanTypeCode,
		@Parameter(description = "The list of the land cover codes") @QueryParam("landCoverCodes") List<String> landCoverCodes,
		@Parameter(description = "The search string") @QueryParam("search") String search,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		return pluginManager.getCropCodesPlugin(env, cropPlanTypeCode)
			.getLandUseCodesInfinite(env, "-1", landCoverCodes, search, new ArrayList<>(), cropPlansDAO.getCurrentTimestamp().toLocalDate(), false, nextKey);
	}
	
	@GET
	@Path("/v1.1/crop-plans/{businessId}/land-uses/{cropPlanTypeCode}")
	@Operation(description = "Get the list of the land uses of the specified crop plan type code")
	@ApiResponse(description = "The list of the land uses of the specified crop plan type code")
	public InfiniteListResults<LandUseDetails> getCropPlanTypeCodeLandUseCodesV1_1(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan type code") @PathParam("cropPlanTypeCode") String cropPlanTypeCode,
		@Parameter(description = "The list of the land cover codes") @QueryParam("landCoverCodes") List<String> landCoverCodes,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") AbsoluteDate pointInTime,
		@Parameter(description = "The search string") @QueryParam("search") String search,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		if (pointInTime == null) pointInTime =  AbsoluteDate.of(cropPlansDAO.getCurrentTimestamp().toLocalDate());
		return cropCodeService.getCropPlanTypeCodeLandUseCodes(env, businessId, cropPlanTypeCode, landCoverCodes, search, pointInTime, nextKey);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/declared-areas")
	@Operation(description = "Get the declared areas of a plot in a time window")
	@ApiResponse(description = "The declared areas of the plot in the specified time window")
	public PlotDeclaredAreas getPlotDeclaredAreas(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
		@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
		@Parameter(description = "The starting point in time to be evaluated") @QueryParam("pointInTimeFrom") @NotNull AbsoluteDate pointInTimeFrom,
		@Parameter(description = "The ending point in time to be evaluated") @QueryParam("pointInTimeTo") @NotNull AbsoluteDate pointInTimeTo,
		@Parameter(description = "Optional declaration code to exclude from the result") @QueryParam("excludedDeclCode") String excludedDeclCode,
		@Parameter(description = "If it is set to true then the areas are returned considering tolerance") @QueryParam("withTolerance") @DefaultValue("false") boolean withTolerance,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		var params = PlotTimeWindowParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.plotCode(plotCode)
			.excludedDeclCode(excludedDeclCode)
			.pointInTimeFrom(pointInTimeFrom)
			.pointInTimeTo(pointInTimeTo)
			.versionDt(versionDt)
			.build();
		return cropPlanService.getPlotDeclaredAreas(params, withTolerance);
	}
	
	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/permanent-crop-form/fields-codes/{formType}")
	@Operation(description = "Get the permanent crop form fields codes")
	@ApiResponse(description = "The permanent crop form field codes")
	public List<PermanentCropFormFieldCodes> getPermanentCropFormFieldsCodes(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The permanent crop form type") @PathParam("formType") String formType,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return cropPlanService.getPermanentCropFormFieldsCodes(env, cropPlanId, formType);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/anomalies")
	@Operation(description = "Get the crop plan anomalies")
	@ApiResponse(description = "The crop plan anomalies")
	public InfiniteListResults<ValidationAnomaly> getCropPlanAnomalies(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		return cropPlanService.getCropPlanAnomalies(env, cropPlanId, versionDt, nextKey, PAGE_SIZE);
	}
	
	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/grouped-anomalies")
	@Operation(description = "Get the crop plan anomalies grouped by type")
	@ApiResponse(description = "The crop plan anomalies grouped by type")
	public ValidationAnomalies getGroupedCropPlanAnomalies(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
		@Parameter(description = "If it is set to true then the declarations anomalies are marked as plots anomalies grouped by plot") @QueryParam("groupDeclAnomaliesOnPlots") @DefaultValue("false") boolean groupDeclAnomaliesOnPlots,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		return cropPlanService.getGroupedCropPlanAnomalies(env, businessId, cropPlanId, versionDt, groupDeclAnomaliesOnPlots);
	}
	
	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/changed-plots")
	@Operation(description = "Get the crop plan changed plots (not deleted) of the current version")
	@ApiResponse(description = "The crop plan changed plots")
	public InfiniteListResults<ChangedPlot> getChangedPlots(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The crop plan version from which evaluate changed plots (optional, if not set then the current version is used)") @QueryParam("fromVersion") Version fromVersion,
		@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
		@Parameter(description = "Add check by plot description if plot has changed") @QueryParam("checkByPlotDescriptionIfPlotCodeNotFound") @DefaultValue("false") Boolean checkByPlotDescriptionIfPlotCodeNotFound,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return cropPlanService.getChangedPlots(cropPlanId, fromVersion, businessId, env, nextKey, PAGE_SIZE, checkByPlotDescriptionIfPlotCodeNotFound);
	}
	
	@Deprecated
	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/subscriptions")
	@Operation(description = "Get the permanent crop form subscriptions details")
	@ApiResponse(description = "The permanent crop form subscriptions details")
	public List<PermanentCropFormSubscription> getPermanentCropFormSubscriptions(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The external code") @QueryParam("externalCode") String externalCode,
			@Parameter(description = "The list of the permanent crop form subscription codes") @QueryParam("subscriptionCodes") @NotEmpty List<String> subscriptionCodes,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		GetPermanentCropFormSubscriptionsPayload payload = new GetPermanentCropFormSubscriptionsPayload();
		payload.setExternalCode(externalCode);
		payload.setSubscriptionCodes(subscriptionCodes);

		return cropPlanService.getPermanentCropFormSubscriptions(env, businessId, cropPlanId, payload);
	}

	@POST
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/subscriptions")
	@Operation(description = "Get the permanent crop form subscriptions details")
	@ApiResponse(description = "The permanent crop form subscriptions details")
	public List<PermanentCropFormSubscription> getPermanentCropFormSubscriptionsWithPayload(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid GetPermanentCropFormSubscriptionsPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return cropPlanService.getPermanentCropFormSubscriptions(env, businessId, cropPlanId, payload);
	}
	
	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/dates")
	@Operation(description = "Get the crop plan dates")
	@ApiResponse(description = "The crop plan dates")
	public CropPlanDates getCropPlanDates(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return cropPlanService.getCropPlanDates(env, businessId, cropPlanId, pointInTime);
	}
	
	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/domains/{domainZoneCode}/plots/{plotCode}/timeline")
	@Operation(description = "Get the timeline of a plot in a time window")
	@ApiResponse(description = "The timeline of the plot in the specified time window")
	public PlotTimeline getPlotTimeline(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone code") @PathParam("domainZoneCode") String domainZoneCode,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The starting point in time to be evaluated") @QueryParam("pointInTimeFrom") @NotNull AbsoluteDate pointInTimeFrom,
			@Parameter(description = "The ending point in time to be evaluated") @QueryParam("pointInTimeTo") @NotNull AbsoluteDate pointInTimeTo,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var domainZone = pluginManager.getDomainPlugin(businessId, cropPlanId, tenantId).getDomainZoneByCode(env, businessId, pointInTimeFrom.toLocalDate(), domainZoneCode);
		if (domainZone == null)
			throw new BadRequestException("The specified domainZoneCode was not found");
		
		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		var params = PlotTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.domainZoneId(domainZone.getDomainZoneId())
				.plotCode(plotCode)
				.pointInTimeFrom(null)
				.pointInTimeTo(null)
				.versionDt(versionDt)
				.build();
		var ret = new PlotTimeline();
		ret.setPlotCode(plotCode);
		ret.setAreas(cropPlanService.getPlotAreas(params));
		ret.setDecls(cropPlanDeclarationsService.getPlotDeclarations(createEnvironment(user, language), businessId, cropPlanId, plotCode, null,
				versionDt, pointInTimeFrom, pointInTimeTo));

		return ret;
	}
	
	@DELETE
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}")
	@Operation(description = "Delete a crop plan")
	@RolesAllowed("CRPL|CAN_DELETE_CROPPLAN")
	@ApiResponses({
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The crop plan can't be deleted", content = @Content(schema = @Schema(implementation = CropPlanCantBeDeletedException.CropPlanCantBeDeletedExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public void deleteCropPlan(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "If it is set to true then the specified crop plan is locked for the current user before version creation") @QueryParam("autoLock") @DefaultValue("false") boolean autoLock,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanDelete(env, businessId, cropPlanId);
		if (autoLock)
			locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
		else
			checkLock(env, cropPlanId);

		var deleteDt = cropPlansDAO.getCurrentTimestamp().minus(Duration.ofMillis(1));
		cropPlansDAO.deleteCropPlan(cropPlanId, deleteDt, env.getUserId());
	}

	@DELETE
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/cleanup")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Cleanup a crop plan deleting all its plots")
	@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class)))
	public void cleanupCropPlan(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "If it is set to true then the specified crop plan is locked for the current user before version creation") @QueryParam("autoLock") @DefaultValue("false") boolean autoLock,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		if (autoLock)
			locksService.lockCropPlan(createEnvironment(user, language), cropPlanId);
		else
			checkLock(env, cropPlanId);

		LocalDateTime currentDt = cropPlansDAO.getCurrentTimestamp();
		LocalDateTime deleteDt = currentDt.minus(Duration.ofMillis(1));
		
		cropPlansDAO.cleanupCropPlan(cropPlanId, env.getUserId(), currentDt, deleteDt);
	}

	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/plots/areas-and-anomalies")
	@Operation(description = "Get report of areas and ")
	@ApiResponse(description = "The list of the plots of the specified crop plan")
	public CuaaAreasAndAnomalies getCuuaAreaAndAnomaliesPlots(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "The permanent crop form type") @QueryParam("permanentCropFormType") @NotNull String permanentCropFormType,
			@Parameter(description = "If it is set to true then the declarations anomalies are marked as plots anomalies grouped by plot") @QueryParam("groupDeclAnomaliesOnPlots") @DefaultValue("false") boolean groupDeclAnomaliesOnPlots,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();

		return cropPlanService.getCuaaAreasAndAnomalies(env, businessId, cropPlanId, versionDt, pointInTime, pointInTime, permanentCropFormType, groupDeclAnomaliesOnPlots);
	}
	
	@GET
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/prints/{printCode}/params")
	@Operation(description = "Get the crop plan print parameters")
	@ApiResponse(description = "The crop plan print parameters")
	public CropPlanPrintParams getCropPlanPrintParams(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The print code") @PathParam("printCode") String printCode,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return printService.getCropPlanPrintParams(env, businessId, cropPlanId, printCode);
	}
	
	@POST
	@Path("/v1/crop-plans/{businessId}/plans/{cropPlanId}/validator-anomalies-result")
	@Operation(description = "Get the anomalies validator result of the specified plots and declarations")
	@ApiResponse(description = "The anomalies validator result of the specified plots and declarations")
	public ValidatorAnomaliesResult getAnomaliesValidatorResult(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@NotNull @Valid CalculateAnomaliesDto calculateAnomaliesDto,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();
		return validatorService.getValidatorAnomaliesResult(env, businessId, cropPlanId, versionDt, (version != null), calculateAnomaliesDto);
	}
}
