package com.abacogroup.cropplan.bundle;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.cropplan.bundle.model.CropPlanPrintsParamsMessage;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;

public class CropPlanPrintParamProcessor extends AbstractConfigProcessor {
    public CropPlanPrintParamProcessor(CropPlanConfigDAO configDAO) {
        super(configDAO);
    }

    @Override
    public String getDomainName() {
        return "printsParams";
    }

    @Override
    public void onMessageInTransaction(CropPlanConfigDAO dao, ConfigDataMessage message) {
        message.getConfigFiles().stream()
                .map(Path::toFile)
                .filter(file -> file.getAbsolutePath().endsWith(".json"))
                .sorted()
                .forEach(file -> processFile(message.getTenantId(), file));
    }

    private void processFile(String tenantId, File file) {
        CropPlanPrintsParamsMessage message;
        try {
            message = objectMapper.readValue(file, CropPlanPrintsParamsMessage.class);
        } catch (IOException e) {
            throw new IllegalStateException("Error processing file " + file.getName() + " for tenant " + tenantId, e);
        }

        Long typeId = configDAO.getCropPlanTypeId(message.getCropPlanType(), tenantId);

        if (typeId == null) {
            return;
        }

        if (file.getAbsolutePath().endsWith(".delete.json")) {
            doDelete(typeId, message);
        } else {
            doInsertOrUpdate(typeId, message);
        }
    }

    private void doInsertOrUpdate(Long typeId, CropPlanPrintsParamsMessage message) {
        if (message == null || message.getPrintCode() == null || message.getPrintParams().isEmpty()) {
            return;
        }

        message.getPrintParams().forEach(cropPlanPrintParam -> {
            configDAO.deleteCropPlanPrintParamByTypeAndCodeAndParamName(typeId, message.getPrintCode(), cropPlanPrintParam.getName());
            configDAO.insertCropPlanPrintParam(typeId, message.getPrintCode(), cropPlanPrintParam.getName(), cropPlanPrintParam.getValue());
        });
    }

    private void doDelete(Long typeId, CropPlanPrintsParamsMessage message) {
        if (message == null || message.getPrintCode() == null) {
            return;
        }

        configDAO.deleteCropPlanPrintParamByTypeAndCode(typeId, message.getPrintCode());
    }
}
