package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "A pesticide entry")
public class InsertPlotPesticidePayload 
{
	@Schema(description = "The product code")
	@NotNull
	private String productCode;

	@Schema(description = "The unit of measure")
	@NotNull
	private String uomCode;

	@Schema(description = "The product amount")
	@NotNull
	private Double amount;

	@Schema(description = "The date")
	private AbsoluteDate date;
}
