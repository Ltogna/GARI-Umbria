package com.abacogroup.cropplan.resources.dtos;

import jakarta.validation.constraints.NotEmpty;
import java.util.List;
import lombok.Data;

@Data
public class PlotsDeleteDto {
  @NotEmpty
  private List<String> plotCodes;
}
