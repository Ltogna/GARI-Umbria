package com.abacogroup.cropplan.api;

import java.util.List;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Schema(description = "A plot's declared areas")
public class PlotDeclaredAreas
{
	@Schema(description = "The plot 'stable' code, this does not change in history")
	private String plotCode;
	
	@Schema(description = "The declared areas, when the plot geometry possibly changed")
	private List<PlotDeclaredArea> declaredAreas;
	
	@Schema(description = "The total declarable area percentage in the time window")
	private Double totalDeclarableAreaPerc;
	
	@Schema(description = "The max declarable area percentage in the time window")
	private Double maxDeclarableAreaPerc;
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static class PlotDeclaredArea
	{		
		@Schema(description = "The plot area, in square meters")
		private Integer areaSqm;
		
		@Schema(description = "The declared area percentage")
		private Double declaredAreaPerc;
		
		@Schema(description = "The date")
		private AbsoluteDate date;
	}
}
