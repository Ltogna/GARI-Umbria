package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResumePlotPayload
{
	@Schema(description = "The point in time")
	@NotNull
	AbsoluteDate pointInTime;
}
