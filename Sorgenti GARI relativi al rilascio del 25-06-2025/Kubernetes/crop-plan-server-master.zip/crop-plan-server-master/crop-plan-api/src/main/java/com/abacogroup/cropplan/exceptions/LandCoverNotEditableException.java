package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class LandCoverNotEditableException extends WebApplicationException
{
	private static final long serialVersionUID = 3787673581088604092L;

	public static  class LandCoverNotEditableExceptionErrorBody
	{
		@Schema(allowableValues = "LAND_COVER_NOT_EDITABLE_EXCEPTION")
		public String getErrorCode()
		{
			return "LAND_COVER_NOT_EDITABLE_EXCEPTION";
		}
	}
	
	private static final LandCoverNotEditableExceptionErrorBody BODY = new LandCoverNotEditableExceptionErrorBody();

	public LandCoverNotEditableException(String landCoverCode)
	{
		super("The " + landCoverCode + " land cover is not editable",
			Response.status(Status.BAD_REQUEST).entity(BODY).build());
	}
}
