package com.abacogroup.cropplan.api.internal.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;
import org.locationtech.jts.geom.Geometry;

@Data
public class InternalInsertPlotPayload {
	
	@Schema(description = "From date")
	@NotNull
	private AbsoluteDate fromDate;
	
	@Schema(description = "To date")
	@NotNull
	private AbsoluteDate toDate;
	
	@Schema(description = "The polygon geometry", type = "string", format = "WKT geometry")
	@NotNull
	private Geometry geom;
	
	@Schema(description = "The spatial reference system", format = "AUTHORITY:ID", example = "EPSG:3857")
	@NotNull
	private String srs;
	
	@Schema(description = "The description")
	private String description;
	private String notes;

	@Schema(description = "The plot declarations")
	private List<InternalInsertDeclarationPayload> declarations;
	
}
