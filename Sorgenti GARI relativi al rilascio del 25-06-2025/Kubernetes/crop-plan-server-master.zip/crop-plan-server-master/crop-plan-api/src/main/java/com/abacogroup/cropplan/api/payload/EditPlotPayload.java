package com.abacogroup.cropplan.api.payload;

import com.abacogroup.cropplan.api.CutBehaviour;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import lombok.Data;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.operation.buffer.BufferOp;
import org.locationtech.jts.operation.buffer.BufferParameters;

@Data
public class EditPlotPayload
{
	@Schema(description = "From date")
	@NotNull
	private AbsoluteDate fromPointInTime;

	@Schema(description = "To date (optional, default propagate to infinity)")
	private AbsoluteDate toPointInTime;
	
	@Schema(description = "The polygon geometry", type = "string", format = "WKT geometry")
	@NotNull
	private Geometry geom;

	@Min(0)
	private BigDecimal bufferSize;

	@Schema(description = "The parameters used to apply the geometry in relation to the already existing ones")
	@NotNull
	@Valid
	private CutParameters cutParameters;
	
	@Data
	public static class CutParameters 
	{
		@Schema(description = "The cut behaviour")
		@NotNull
		private CutBehaviour behaviour;

		@Schema(description = "The plots to consider during the cut operation; if null, all plots are considered")
		@Size(min = 1)
		private List<String> plotCodes;
	}

	@JsonIgnore
	public Geometry getBufferedGeom() {
		if (this.geom == null || this.bufferSize == null) {
			return this.geom;
		} else {
			double distance = this.bufferSize.setScale(2, RoundingMode.HALF_UP).doubleValue();
			if (distance > 0) {
				return BufferOp.bufferOp(this.geom, distance, new BufferParameters(0,
						BufferParameters.CAP_SQUARE, BufferParameters.JOIN_MITRE, BufferParameters.DEFAULT_MITRE_LIMIT));
			} else {
				return this.geom;
			}
		}
	}
}
