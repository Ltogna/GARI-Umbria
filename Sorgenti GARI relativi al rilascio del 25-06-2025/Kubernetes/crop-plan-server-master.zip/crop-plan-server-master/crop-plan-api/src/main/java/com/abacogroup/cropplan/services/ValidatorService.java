package com.abacogroup.cropplan.services;

import static java.util.stream.Collectors.toList;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.cropplan.api.ValidationResult;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.db.dao.ValidatorDAO;
import com.abacogroup.cropplan.db.dao.ntt.DeclarationWithPlotCode;
import com.abacogroup.cropplan.db.dao.ntt.ParcelIntersectionWithPlotId;
import com.abacogroup.cropplan.enums.IgnoreValidationMessages;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.dtos.CalculateAnomaliesDto;
import com.abacogroup.cropplan.resources.dtos.CalculateAnomaliesPlotDto;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.validation.AnomalyObjectType;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomaly;
import com.abacogroup.cropplan.sdk.model.validation.ValidationAnomalyObject;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorAnomaliesResult;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedDeclaration;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorBoundedPlot;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorData;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorOperation;
import com.abacogroup.cropplan.sdk.model.validation.ValidatorResult;
import com.abacogroup.cropplan.sdk.spi.ValidatorPlugin;
import com.abacogroup.cropplan.sdk.support.ValidatorDataSupport;
import com.abacogroup.cropplan.services.support.ValidatorDataSupportImpl;
import com.abacogroup.cropplan.services.support.ValidatorSupport;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;

public class ValidatorService {
	// private static final Logger log = LoggerFactory.getLogger(ValidatorService.class);

	private final CropCodeService cropCodeService;
	private final CropPlanConfigService cropPlanConfigService;
	private final ValidatorDAO validatorDAO;
	private final CropPlansDAO cropPlansDAO;
	private final DeclarationsDAO declarationsDAO;
	private final PluginManager pluginManager;

	// TODO remove after testing issue
	private static final Logger log = LoggerFactory.getLogger(ValidatorService.class);

	public ValidatorService(CropCodeService cropCodeService, CropPlanConfigService cropPlanConfigService, DAOContainer daocontainer,
			PluginManager pluginManager) {
		this.cropCodeService = cropCodeService;
		this.cropPlanConfigService = cropPlanConfigService;
		this.validatorDAO = daocontainer.getValidatorDAO();
		this.pluginManager = pluginManager;
		this.cropPlansDAO = daocontainer.getCropPlansDAO();
		this.declarationsDAO = daocontainer.getDeclarationsDAO();
	}

	public <T extends ValidationResult> T validate(RuntimeEnvironment env, ValidatorSupport<T> support, boolean ignoreAllDeclValidationWarnings,
			boolean ignoreAllDeclValidationMessages, String businessId, Long cropPlanId, LocalDateTime versionDt, LocalDateTime transactionId) {
		CompletionStage<ValidatorResult> validatorResult;
		var validatorPlugin = pluginManager.getValidatorPlugin(businessId, cropPlanId, env.getTenantId());
		var data = validatorPlugin != null ? support.getValidatorData() : null;
		if (validatorPlugin != null) {
			validatorResult = validatorPlugin.validate(env, data, buildValidatorSupport(env, cropPlanId, versionDt, false));
		} else {
			var result = new ValidatorResult();
			result.setMessages(new ArrayList<>(0));
			result.setAnomalies(new HashMap<>(0));
			validatorResult = CompletableFuture.completedFuture(result);
		}

		IgnoreValidationMessages ignoreValidationMessages;
		if (ignoreAllDeclValidationMessages) {
			ignoreValidationMessages = IgnoreValidationMessages.IGNORE_ALL_DECL_VALIDATION_MESSAGES;
		} else if (ignoreAllDeclValidationWarnings) {
			ignoreValidationMessages = IgnoreValidationMessages.IGNORE_ALL_DECL_VALIDATION_WARNINGS;
		} else {
			ignoreValidationMessages = IgnoreValidationMessages.DO_NOT_IGNORE_MESSAGES;
		}

		var future = validatorResult.thenApply(
				result -> getValidationResult(env, support, ignoreValidationMessages, cropPlanId, versionDt, transactionId, data, result));

		try {
			return future.toCompletableFuture().get();
		} catch (Exception e) {
			if (transactionId != null)
				validatorDAO.rollbackTransaction(cropPlanId, transactionId);

			if (e instanceof InterruptedException) {
				Thread.currentThread().interrupt();
			}

			throw new IllegalStateException(e);
		}
	}

	private <T extends ValidationResult> T getValidationResult(RuntimeEnvironment env, ValidatorSupport<T> support,
			IgnoreValidationMessages ignoreValidationMessages, Long cropPlanId, LocalDateTime versionDt, LocalDateTime transactionId, ValidatorData data,
			ValidatorResult result) {
		if (!ignoreValidationMessages.equals(IgnoreValidationMessages.IGNORE_ALL_DECL_VALIDATION_MESSAGES)) {
			if (transactionId != null && !result.getMessages().isEmpty()) {
				var retMessages = retrieveRetMessages(ignoreValidationMessages, result);

				if (retMessages) {
					validatorDAO.rollbackTransaction(cropPlanId, transactionId);
					return support.getResult(result.getMessages(), null);
				}
			}
		}

		validatorDAO.commitTransaction(env, cropPlanId, versionDt, transactionId, data, result.getAnomalies(), false);

		List<String> vao = result.getAnomalies()
				.keySet()
				.stream()
				.filter(s -> s.getObjectType().equals(AnomalyObjectType.PLOT))
				.map(ValidationAnomalyObject::getObjectCode)
				.distinct()
				.collect(toList());

		return support.getResult(result.getMessages(), vao);
	}

	private boolean retrieveRetMessages(IgnoreValidationMessages ignoreValidationMessages, ValidatorResult result) {
		var retMessages = true;
		if (ignoreValidationMessages.equals(IgnoreValidationMessages.IGNORE_ALL_DECL_VALIDATION_WARNINGS)) {
			retMessages = false;
			for (var msg : result.getMessages()) {
				if (msg.isBlocking()) {
					retMessages = true;
					break;
				}
			}
		}
		return retMessages;
	}

	public void recalcAnomalies(RuntimeEnvironment env, ValidatorSupport<?> support, String businessId, Long cropPlanId, LocalDateTime versionDt) {
		var result = new ValidatorResult();
		var validatorPlugin = pluginManager.getValidatorPlugin(businessId, cropPlanId, env.getTenantId());
		var data = validatorPlugin != null ? support.getValidatorData() : null;
		if (validatorPlugin != null) {
			result.setAnomalies(validatorPlugin.calculateAnomalies(env, data, buildValidatorSupport(env, cropPlanId, versionDt, false)));
		} else {
			result.setMessages(new ArrayList<>(0));
			result.setAnomalies(new HashMap<>(0));
		}

		validatorDAO.commitTransaction(env, cropPlanId, versionDt, null, data, result.getAnomalies(), true);
	}

	private ValidatorDataSupport buildValidatorSupport(RuntimeEnvironment env, Long cropPlanId, LocalDateTime versionDt, boolean calculateAtPreviousVersion) {
		return new ValidatorDataSupportImpl(cropCodeService, cropPlanConfigService, cropPlansDAO, declarationsDAO, env, cropPlanId, versionDt,
				calculateAtPreviousVersion);
	}

	public LocalDateTime getActiveTransactionId(Long cropPlanId) {
		var transId = validatorDAO.getActiveTransactionId(cropPlanId);

		if (transId != null && transId.plusHours(1).compareTo(validatorDAO.getCurrentTimestamp()) < 0) {
			validatorDAO.rollbackTransaction(cropPlanId, transId);
			return null;
		}

		return transId;
	}

	public ValidatorAnomaliesResult getValidatorAnomaliesResult(RuntimeEnvironment env, String businessId, Long cropPlanId, LocalDateTime versionDt,
			boolean calculateAtPreviousVersion, CalculateAnomaliesDto calculateAnomaliesDto) {
		if (calculateAnomaliesDto.getPlots().isEmpty()) {
			return new ValidatorAnomaliesResult();
		}

		ValidatorData data = createValidatorData(businessId, cropPlanId, calculateAnomaliesDto);

		List<ValidatorBoundedPlot> plots = new ArrayList<>();
		List<ValidatorBoundedDeclaration> declarations = new ArrayList<>();

		for (CalculateAnomaliesPlotDto plot : calculateAnomaliesDto.getPlots()) {
			List<ParcelIntersectionWithPlotId> plotsParcelsInternal = cropPlansDAO.findPlotsParcelsInternalByPlotCode(
					cropPlanId, plot.getPlotCode(), versionDt,
					calculateAnomaliesDto.getReferenceDt(),
					calculateAnomaliesDto.getReferenceDt());

			List<String> parcelCodes = plotsParcelsInternal.stream()
					.map(ParcelIntersection::getCode)
					.collect(Collectors.toList());

			ValidatorBoundedPlot validatorBoundedPlot = createValidatorBoundedPlot(plot.getPlotCode(), parcelCodes, calculateAnomaliesDto.getReferenceDt());
			plots.add(validatorBoundedPlot);

			if (plot.getDeclCodes() != null && !plot.getDeclCodes().isEmpty()) {
				declarations.addAll(
						createValidatorBoundedDeclarations(plot, cropPlanId, validatorBoundedPlot, versionDt, calculateAnomaliesDto.getReferenceDt().toLocalDate()));
			}
		}

		data.setPlots(plots);
		data.setDeclarations(declarations);

		return calculateValidatorAnomalies(env, data, versionDt, calculateAtPreviousVersion);
	}

	private ValidatorData createValidatorData(String businessId, Long cropPlanId, CalculateAnomaliesDto calculateAnomaliesDto) {
		ValidatorData data = new ValidatorData();
		data.setBusinessId(businessId);
		data.setCropPlanId(cropPlanId);
		data.setReferenceDt(calculateAnomaliesDto.getReferenceDt().toLocalDate());
		return data;
	}

	private ValidatorBoundedPlot createValidatorBoundedPlot(String plotCode, List<String> parcelCodes, AbsoluteDate referenceDt) {
		ValidatorBoundedPlot plot = new ValidatorBoundedPlot();
		plot.setPlotCode(plotCode);
		plot.setParcelCodes(parcelCodes);
		plot.setFromDate(referenceDt.toLocalDate());
		plot.setToDate(referenceDt.toLocalDate());
		plot.setOperation(ValidatorOperation.UPDATE);
		return plot;
	}

	private List<ValidatorBoundedDeclaration> createValidatorBoundedDeclarations(CalculateAnomaliesPlotDto plot, Long cropPlanId,
			ValidatorBoundedPlot validatorBoundedPlot,
			LocalDateTime versionDt, LocalDate referenceDt) {
		List<ValidatorBoundedDeclaration> declarations = new ArrayList<>();

		for (String declCode : plot.getDeclCodes()) {
			DeclarationWithPlotCode declaration = declarationsDAO.getDeclarationByDeclCode(cropPlanId, validatorBoundedPlot.getPlotCode(), versionDt, declCode);

			if (declaration != null) {
				ValidatorBoundedDeclaration validatorBoundedDeclaration = new ValidatorBoundedDeclaration();
				validatorBoundedDeclaration.setPlotCode(validatorBoundedPlot.getPlotCode());
				validatorBoundedDeclaration.setParcelCodes(validatorBoundedPlot.getParcelCodes());
				validatorBoundedDeclaration.setDeclId(declaration.getDeclId());
				validatorBoundedDeclaration.setDeclCode(declaration.getDeclCode());
				validatorBoundedDeclaration.setLanduseCode(declaration.getLanduse().getCode());
				validatorBoundedDeclaration.setAreaPerc(declaration.getAreaPerc());
				validatorBoundedDeclaration.setFromDate(referenceDt);
				validatorBoundedDeclaration.setToDate(referenceDt);
				validatorBoundedDeclaration.setFromDatePrecision(declaration.getFromDatePrecision());
				validatorBoundedDeclaration.setOperation(ValidatorOperation.UPDATE);

				declarations.add(validatorBoundedDeclaration);
			}
		}

		return declarations;
	}

	private ValidatorAnomaliesResult calculateValidatorAnomalies(RuntimeEnvironment env, ValidatorData data, LocalDateTime versionDt,
			boolean calculateAtPreviousVersion) {
		ValidatorAnomaliesResult result = new ValidatorAnomaliesResult();
		ValidatorPlugin validatorPlugin = pluginManager.getValidatorPlugin(data.getBusinessId(), data.getCropPlanId(), env.getTenantId());

		if (validatorPlugin != null) {
			Map<ValidationAnomalyObject, List<ValidationAnomaly>> validationAnomalyObjectListMap = validatorPlugin.calculateAnomalies(env, data,
					buildValidatorSupport(env, data.getCropPlanId(), versionDt, calculateAtPreviousVersion));
			result.setAnomalies(validationAnomalyObjectListMap.values().stream().flatMap(List::stream).collect(Collectors.toList()));
		} else {
			result.setAnomalies(new ArrayList<>());
		}
		return result;
	}

}
