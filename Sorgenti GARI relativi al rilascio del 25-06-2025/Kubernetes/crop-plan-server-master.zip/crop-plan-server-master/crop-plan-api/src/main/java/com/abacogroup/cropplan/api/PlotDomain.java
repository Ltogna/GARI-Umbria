package com.abacogroup.cropplan.api;

import com.abacogroup.cropplan.sdk.model.domain.DomainZoneGeometry;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "A polygon representing an area with it's crops and domain zone")
public class PlotDomain
{
	@NotNull
	private Plot plot;

	@NotNull
	private DomainZoneGeometry domainZone;
}
