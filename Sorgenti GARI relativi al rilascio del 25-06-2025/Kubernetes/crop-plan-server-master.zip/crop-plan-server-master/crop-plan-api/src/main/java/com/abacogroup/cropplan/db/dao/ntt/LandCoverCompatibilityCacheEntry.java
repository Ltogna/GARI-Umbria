package com.abacogroup.cropplan.db.dao.ntt;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class LandCoverCompatibilityCacheEntry {
    private Integer typeId;
    private LocalDateTime cacheDt;
    private String landCoverCode;
    private String landUseCode;
}
