package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.AllArgsConstructor;
import lombok.Getter;

public class DeclarationAdditionalFieldNotAllowedException extends WebApplicationException {
	private static final long serialVersionUID = -1205943738478719157L;
	private static final String ERROR_CODE = "DECLARATION_ADDITIONAL_FIELD_NOT_ALLOWED_EXCEPTION";

	@Getter
	@AllArgsConstructor
	public static class DeclarationAdditionalFieldNotAllowedExceptionErrorBody {
		@Schema(allowableValues = ERROR_CODE)
		private final String errorCode = ERROR_CODE;
		private final String message;
	}

	public DeclarationAdditionalFieldNotAllowedException(final String fieldCode, final String fieldValue, final String landUseCode) {
		super(
				buildMessage(fieldCode, fieldValue, landUseCode),
				Response.status(Status.BAD_REQUEST)
						.entity(new DeclarationAdditionalFieldNotAllowedExceptionErrorBody(
								buildMessage(fieldCode, fieldValue, landUseCode)
						))
						.build()
		);
	}

	private static String buildMessage(String fieldCode, String fieldValue, String landUseCode) {
		return "Declaration additional field "
				+ (fieldCode != null ? "'" + fieldCode + "' " : "")
				+ (fieldValue != null ? "with value '" + fieldValue + "' " : "")
				+ "not allowed for land use " + landUseCode;
	}
}

