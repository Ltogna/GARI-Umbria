package com.abacogroup.cropplan.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Crop plan prints")
public class CropPlanPrint
{
	@Schema(description = "The print code")
	@NotEmpty
	private String code;
	
	@Schema(description = "The print description")
	@NotEmpty
	private String description;
}
