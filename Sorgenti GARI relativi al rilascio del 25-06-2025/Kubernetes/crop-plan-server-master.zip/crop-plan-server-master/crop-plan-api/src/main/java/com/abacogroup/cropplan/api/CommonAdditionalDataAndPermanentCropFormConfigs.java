package com.abacogroup.cropplan.api;

import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataConf;
import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormConfig;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class CommonAdditionalDataAndPermanentCropFormConfigs {
	public List<LandUseAdditionalDataConf> landUseAdditionalDataConfigs;
	public List<PermanentCropFormConfig> permanentCropFormConfigs;
}
