package com.abacogroup.cropplan.db.dao.ntt;

import lombok.Data;

@Data
public class LandCoverAndTypeId {
    private String landCoverCode;
    private Integer typeId;
}
