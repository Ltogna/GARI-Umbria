package com.abacogroup.cropplan.db.dao.ntt;

import org.locationtech.jts.geom.Geometry;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder=true)
public class PlotDataParcel
{
	private Long id;
	private Long plotId;
	private String parcelCode;
	private Integer areaSqm;
	private String landCoverCode;
	private boolean flOutside;
	private Geometry geom;
	//private LocalDateTime insertDt;
}
