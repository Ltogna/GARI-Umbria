package com.abacogroup.cropplan.resources;

import static java.util.stream.Collectors.toList;

import com.abacogroup.cropplan.api.CompleteWithTareDates;
import com.abacogroup.cropplan.api.CopyCampaignLandUseCode;
import com.abacogroup.cropplan.api.CopyDeclarationsResult;
import com.abacogroup.cropplan.api.CropPlanDates;
import com.abacogroup.cropplan.api.DisabledFunctionCode;
import com.abacogroup.cropplan.api.EditDeclarationResult;
import com.abacogroup.cropplan.api.EditDeclarationsResult;
import com.abacogroup.cropplan.api.PlotBuffer;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.PlotDeclRotationDto;
import com.abacogroup.cropplan.api.SyncStatus;
import com.abacogroup.cropplan.api.payload.CompleteWithTareLandUsePayload;
import com.abacogroup.cropplan.api.payload.CopyCampaignPayload;
import com.abacogroup.cropplan.api.payload.CopyDeclarationsFromSourceYearPayload;
import com.abacogroup.cropplan.api.payload.CopyDeclarationsPayload;
import com.abacogroup.cropplan.api.payload.DeleteDeclarationsPayload;
import com.abacogroup.cropplan.api.payload.EditDeclarationPayload;
import com.abacogroup.cropplan.api.payload.EditDeclarationsFieldsPayload;
import com.abacogroup.cropplan.api.payload.EditDeclarationsPayload;
import com.abacogroup.cropplan.api.payload.GetCompleteWithTareLandUseDatesPayload;
import com.abacogroup.cropplan.api.payload.InsertDeclarationPayload;
import com.abacogroup.cropplan.api.payload.InsertPermanentCropForm;
import com.abacogroup.cropplan.api.payload.MergeDeclarationsPayload;
import com.abacogroup.cropplan.api.payload.ReproportionDeclsPayload;
import com.abacogroup.cropplan.api.payload.SwapLandUsesPayload;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.db.dao.ntt.ParcelIntersectionWithPlotId;
import com.abacogroup.cropplan.exceptions.CropPlanNotWriteableException;
import com.abacogroup.cropplan.exceptions.CropPlanReadOnlyException;
import com.abacogroup.cropplan.exceptions.DeclarationAdditionalFieldNotAllowedException;
import com.abacogroup.cropplan.exceptions.IncompatibleLandUseException;
import com.abacogroup.cropplan.exceptions.InvalidDeclAreaPercZeroException;
import com.abacogroup.cropplan.exceptions.InvalidDeclDatesException;
import com.abacogroup.cropplan.exceptions.InvalidDeclException;
import com.abacogroup.cropplan.exceptions.LandCoverNotEditableException;
import com.abacogroup.cropplan.exceptions.LandUseCodeNotFoundException;
import com.abacogroup.cropplan.exceptions.LockException;
import com.abacogroup.cropplan.exceptions.MaxDeclAreaException;
import com.abacogroup.cropplan.exceptions.OnlyOneNewDateProvidedException;
import com.abacogroup.cropplan.exceptions.PermanentCropFormNotAllowedException;
import com.abacogroup.cropplan.exceptions.PlotBufferException;
import com.abacogroup.cropplan.exceptions.PlotDeclarationsNotEditableException;
import com.abacogroup.cropplan.exceptions.PlotNotEmptyAtNewDeclDatesException;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.dtos.LandUseCodeWithRotationDto;
import com.abacogroup.cropplan.resources.dtos.MassiveUpdateFieldsDto;
import com.abacogroup.cropplan.sdk.model.Declaration;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import com.abacogroup.cropplan.sdk.model.PermanentCropForm;
import com.abacogroup.cropplan.sdk.model.Version;
import com.abacogroup.cropplan.sdk.model.config.CropPlanConfigParam;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CopyCampaignService;
import com.abacogroup.cropplan.services.CropCodeService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.CropPlanDeclarationsService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.LocksService;
import com.abacogroup.cropplan.services.SyncService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.cropplan.services.support.PlotTimeWindowParams;
import com.abacogroup.cropplan.services.support.PlotsTimeWindowParams;
import com.abacogroup.cropplan.services.support.PlotsTimeWindowPlotData;
import com.abacogroup.cropplan.services.support.ReproportionDeclsSupportParams;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.codahale.metrics.annotation.Timed;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.ForbiddenException;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.SecurityContext;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Path("{tenant}/api-priv/v1/crop-plans")
@Tag(name = "PRIVATE - Crop plan declaration resources")
@Timed
@RolesAllowed({"CRPL|USER","CRPL|EDITOR"})
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class CropPlanDeclarationResources extends BaseCropPlanResource {

	private final CropPlanService cropPlanService;
	private final CropPlanDeclarationsService cropPlanDeclarationsService;
	private final CropCodeService cropCodeService;
	private final CopyCampaignService copyCampaignService;
	private final SyncService syncService;
	private final CropPlansDAO cropPlansDAO;
	private final CropPlanConfigDAO cropPlanConfigDAO;
	private final DeclarationsDAO declarationsDAO;

	public CropPlanDeclarationResources(BaseService baseService, CropPlanService cropPlanService, CropPlanDeclarationsService cropPlanDeclarationsService,
			LocksService locksService, CropCodeService cropCodeService, ValidatorService validatorService, CropPlanConfigService cropPlanConfigService,
			CopyCampaignService copyCampaignService, SyncService syncService, PluginManager pluginManager, DAOContainer daocontainer) {
		super(baseService, cropPlanService, locksService, cropCodeService, validatorService, cropPlanConfigService, pluginManager, daocontainer.getCropPlansDAO()
		);
		this.cropPlanService = cropPlanService;
		this.cropPlanDeclarationsService = cropPlanDeclarationsService;
		this.cropCodeService = cropCodeService;
		this.copyCampaignService = copyCampaignService;
		this.syncService = syncService;
		this.cropPlansDAO = daocontainer.getCropPlansDAO();
		this.cropPlanConfigDAO = daocontainer.getCropPlanConfigDAO();
		this.declarationsDAO = daocontainer.getDeclarationsDAO();
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/buffer")
	@Operation(description = "Get plot buffer")
	@ApiResponse(description = "The plot buffer", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Missing distance between rows in at least one declaration",
			content = @Content(schema = @Schema(implementation = PlotBufferException.ErrorBody.class)))
	public PlotBuffer getPlotBuffer(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The crop plan version (optional, if not set then the current version is used)") @QueryParam("version") Version version,
			@Parameter(description = "The starting point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var versionDt = version != null ? version.toDateTime() : cropPlansDAO.getCurrentTimestamp();

		return cropPlanDeclarationsService.getPlotBuffer(env, businessId, cropPlanId, domainZoneId, plotCode, versionDt, pointInTime);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/decls")
	@Operation(description = "Get all plots with declarations and rotations")
	public InfiniteListResults<PlotDeclRotationDto> getPlotWithDeclarationsAndRotation(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@HeaderParam("accept-language") @DefaultValue("en") String language
	) {
		RuntimeEnvironment env = createEnvironment(user, language);
		CropPlanDates cropPlanDates = cropPlanService.getCropPlanDates(env, businessId, cropPlanId, pointInTime);
		LocalDateTime versionDt = cropPlansDAO.getCurrentTimestamp();
		return cropPlanDeclarationsService.getPlotWithDeclarationsAndRotation(env, businessId, cropPlanId, cropPlanDates, versionDt, pointInTime, nextKey);
	}


	@POST
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/{plotCode}/reproportion-decls")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Reproportion plot declarations percentage")
	@ApiResponses({
		@ApiResponse(description = "The plot declarations with the percentage adapted to 100%"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "400", description = "The plot declarations are not editable", content = @Content(schema = @Schema(implementation = PlotDeclarationsNotEditableException.PlotDeclarationsNotEditableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditDeclarationResult reproportionDecls(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
		@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid ReproportionDeclsPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		LocalDateTime versionDt = cropPlansDAO.getCurrentTimestamp();
		var pointInTime = AbsoluteDate.of(payload.getPointInTime().toLocalDate());
		
		var params = ReproportionDeclsSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
			.ignoreDeclValidationWarnings(ignoreDeclValidationWarnings)
			.build();
		
		var plot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId,
				versionDt, payload.getPointInTime(), payload.getPointInTime(), plotCode);
		if (plot == null)
			throw new BadRequestException("The plot " + plotCode + " was not found");
		if (cropPlanConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.ENABLE_DECLARATIONS_REPROPORTION_WHEN_NOT_EDITABLE.toString(), "TRUE").isEmpty())
			checkPlotEditability(env, businessId, cropPlanId, plot);
		
		cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.REPROPORTION_DECLARATIONS ,env, businessId, cropPlanId, plot);
		
		return cropPlanService.reproportionDecls(env, params, plot);
	}
	
	@POST
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/decls")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Create a new plot declaration")
	@ApiResponses({
			@ApiResponse(description = "The new plot declaration created"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot declarations are not editable", content = @Content(schema = @Schema(implementation = PlotDeclarationsNotEditableException.PlotDeclarationsNotEditableExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use is not allowed for the land cover", content = @Content(schema = @Schema(implementation = IncompatibleLandUseException.IncompatibleLandUseExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Maximum declarable area exceeded", content = @Content(schema = @Schema(implementation = MaxDeclAreaException.MaxDeclAreaExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration", content = @Content(schema = @Schema(implementation = InvalidDeclException.InvalidDeclExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration dates", content = @Content(schema = @Schema(implementation = InvalidDeclDatesException.InvalidDeclDatesExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Permanent crop form not allowed for the land use", content = @Content(schema = @Schema(implementation = PermanentCropFormNotAllowedException.PermanentCropFormNotAllowedExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid Decl Area Perc Zero", content = @Content(schema = @Schema(implementation = InvalidDeclAreaPercZeroException.ErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use was not found", content = @Content(schema = @Schema(implementation = LandUseCodeNotFoundException.LandUseCodeNotFoundExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditDeclarationResult createDeclaration(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "If it is set to true then the areas are returned considering tolerance") @QueryParam("withTolerance") @DefaultValue("false") boolean withTolerance,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@Parameter(description = "If it is set to true then this API is used for the flow of copy Declaration") @QueryParam("isCopyFromDecl") @DefaultValue("false") boolean isCopyFromDecl,
			@Parameter(description = "The point in time used to retrieve permanent crop form and land use additional field") @NotNull @QueryParam("pointInTime") AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid InsertDeclarationPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);
		
		if (!cropPlanConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.DISABLE_ADD_DECLARATIONS.toString(), "TRUE").isEmpty())
			throw new ForbiddenException("DISABLE_ADD_DECLARATIONS is set to TRUE");

		LocalDateTime currentDt = cropPlansDAO.getCurrentTimestamp();
		PlotTimeWindowParams params = PlotTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.domainZoneId(domainZoneId)
				.plotCode(plotCode)
				.pointInTimeFrom(payload.getFromDate())
				.pointInTimeTo(payload.getToDate())
				.versionDt(currentDt)
				.build();
		checkCanDeclare(env, params, payload.getLanduseCode(), payload.getAreaPerc(), payload.isRemoveExistingDeclarations());

		var plot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId,
				currentDt, payload.getFromDate(), payload.getToDate(), plotCode);
		if (plot == null)
			throw new BadRequestException("The plot " + plotCode + " was not found");
		checkPlotEditability(env, businessId, cropPlanId, plot);
		checkLandUseCompatibility(env, businessId, cropPlanId, plot, payload.getLanduseCode());
		
		//excluded this check if this is the flow of copy Declaration
		if(!isCopyFromDecl)
			cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.ADD_DECLARATIONS ,env, businessId, cropPlanId, plot);
		
		if (payload.getPermanentCropForms() != null) {
			payload.getPermanentCropForms().forEach(pcf -> checkCanHavePermanentCropForm(env, businessId, cropPlanId, payload.getLanduseCode(), pointInTime, pcf.getFormType()));
		}

		checkCanHaveLandUseAdditionalField(env, businessId, cropPlanId, payload.getLanduseCode(), pointInTime, payload.getFieldsCodes());
		
		return cropPlanDeclarationsService.insertDeclaration(env, params, payload.getLanduseCode(), payload.getAreaPerc(), payload.getFromDatePrecision(),
				plot.getParcelIntersections(), payload.getPermanentCropForms(), payload.getFieldsCodes(), plot.getDecls(), payload.isRemoveExistingDeclarations(),
				ignoreDeclValidationWarnings, false, withTolerance, false);
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/decls")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Create multiple plots declarations")
	@ApiResponses({
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot declarations are not editable", content = @Content(schema = @Schema(implementation = PlotDeclarationsNotEditableException.PlotDeclarationsNotEditableExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use is not allowed for the land cover", content = @Content(schema = @Schema(implementation = IncompatibleLandUseException.IncompatibleLandUseExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Maximum declarable area exceeded", content = @Content(schema = @Schema(implementation = MaxDeclAreaException.MaxDeclAreaExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration", content = @Content(schema = @Schema(implementation = InvalidDeclException.InvalidDeclExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration dates", content = @Content(schema = @Schema(implementation = InvalidDeclDatesException.InvalidDeclDatesExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid Decl Area Perc Zero", content = @Content(schema = @Schema(implementation = InvalidDeclAreaPercZeroException.ErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use was not found", content = @Content(schema = @Schema(implementation = LandUseCodeNotFoundException.LandUseCodeNotFoundExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditDeclarationResult createDeclarations(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@Parameter(description = "The point in time used to retrieve permanent crop form and land use additional field") @NotNull @QueryParam("pointInTime") AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid EditDeclarationsPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);
		
		if (!cropPlanConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.DISABLE_ADD_DECLARATIONS.toString(), "TRUE").isEmpty())
			throw new ForbiddenException("DISABLE_ADD_DECLARATIONS is set to TRUE");

		LocalDateTime currentDt = cropPlansDAO.getCurrentTimestamp();
		List<PlotsTimeWindowPlotData> plotsData = new ArrayList<>();
		payload.getPlots().forEach(p -> {
			PlotTimeWindowParams ptwp = PlotTimeWindowParams.builder()
					.businessId(businessId)
					.cropPlanId(cropPlanId)
					.domainZoneId(domainZoneId)
					.plotCode(p.getPlotCode())
					.pointInTimeFrom(payload.getFromDate())
					.pointInTimeTo(payload.getToDate())
					.versionDt(currentDt)
					.build();
			checkCanDeclare(env, ptwp, payload.getLanduseCode(), p.getAreaPerc(), payload.isRemoveExistingDeclarations());

			var plot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId,
					currentDt, payload.getFromDate(), payload.getToDate(), p.getPlotCode());
			if (plot == null)
				throw new BadRequestException("The plot " + p.getPlotCode() + " was not found");

			checkPlotEditability(env, businessId, cropPlanId, plot);
			checkLandUseCompatibility(env, businessId, cropPlanId, plot, payload.getLanduseCode());
			
			cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.ADD_DECLARATIONS ,env, businessId, cropPlanId, plot);
			
			List<String> parcelCodes = plot.getParcelIntersections().stream().map(ParcelIntersection::getCode).collect(toList());
			plotsData.add(PlotsTimeWindowPlotData.builder()
					.plotCode(p.getPlotCode())
					.parcelCodes(parcelCodes)
					.areaPerc(p.getAreaPerc())
					.declarations(plot.getDecls())
					.build());
		});
		
		if (payload.getPermanentCropForms() != null) {
			payload.getPermanentCropForms().forEach(pcf -> checkCanHavePermanentCropForm(env, businessId, cropPlanId, payload.getLanduseCode(), pointInTime, pcf.getFormType()));
		}
		checkCanHaveLandUseAdditionalField(env, businessId, cropPlanId, payload.getLanduseCode(), pointInTime, payload.getFieldsCodes());

		PlotsTimeWindowParams params = PlotsTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.domainZoneId(domainZoneId)
				.pointInTimeFrom(payload.getFromDate())
				.pointInTimeTo(payload.getToDate())
				.versionDt(currentDt)
				.plotsData(plotsData)
				.build();
				
		return cropPlanDeclarationsService.insertDeclarations(env, params, payload.getLanduseCode(), payload.getFromDatePrecision(),
				payload.getPermanentCropForms(), payload.getFieldsCodes(), payload.isRemoveExistingDeclarations(), ignoreDeclValidationWarnings, false);
	}

	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/decls/massive-fields-update")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Update declarations fields (permanent crop form and additional values) by domain zones ids, landuse codes and rotations")
	public SyncStatus declMassiveFieldsUpdate(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The point in time used to retrieve permanent crop form and land use additional field") @NotNull @QueryParam("pointInTime") AbsoluteDate pointInTime,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid MassiveUpdateFieldsDto massiveUpdateFieldsDto
	) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		// Check that dto does not have duplicated permanent crop form types
		List<String> formTypes = massiveUpdateFieldsDto.getPermanentCropForms().stream().map(InsertPermanentCropForm::getFormType)
				.collect(toList());
		if (cropPlanDeclarationsService.doesConfigListHaveDuplicates(formTypes)) {
			throw new BadRequestException("Permanent Crop Form Config Update List has duplicate form types.");
		}

		// Check that dto does not have duplicated additional fields configs
		List<LandUseAdditionalDataField> additFields = massiveUpdateFieldsDto.getFields();
		if (cropPlanDeclarationsService.doesConfigListHaveDuplicates(additFields.stream().map(LandUseAdditionalDataField::getFieldCode).collect(toList()))) {
			throw new BadRequestException("Additional fields update list has duplicate configs.");
		}

		// Create a map with landUseCode as key and rotations as values
		Map<String, List<Integer>> groupedLandUseCodesWithRotation = massiveUpdateFieldsDto.getLandUseCodeWithRotationDtos().stream()
				.collect(Collectors.groupingBy(
						LandUseCodeWithRotationDto::getLandUseCode,
						Collectors.mapping(LandUseCodeWithRotationDto::getRotation, Collectors.toList())
				));

		// Check that landUseCodes can have that addit fields
		for (Map.Entry<String, List<Integer>> entry : groupedLandUseCodesWithRotation.entrySet()) {
			checkCanHaveLandUseAdditionalField(env, businessId, cropPlanId, entry.getKey(), pointInTime, additFields, true);
			// Check that formType exist for current landUseCode
			for (String formType : formTypes) {
				checkCanHavePermanentCropForm(env, businessId, cropPlanId, entry.getKey(), pointInTime, formType);
			}
		}

		return syncService.declMassiveFieldsUpdate(env, businessId, cropPlanId, pointInTime,
				massiveUpdateFieldsDto.getDomainZoneIds(), groupedLandUseCodesWithRotation, massiveUpdateFieldsDto.getPermanentCropForms(),
				massiveUpdateFieldsDto.getFields(), ignoreDeclValidationWarnings);
	}

	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/decls/{declCode}")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Update a plot declaration")
	@ApiResponses({
			@ApiResponse(description = "The updated plot declaration"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot declarations are not editable", content = @Content(schema = @Schema(implementation = PlotDeclarationsNotEditableException.PlotDeclarationsNotEditableExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use is not allowed for the land cover", content = @Content(schema = @Schema(implementation = IncompatibleLandUseException.IncompatibleLandUseExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Maximum declarable area exceeded", content = @Content(schema = @Schema(implementation = MaxDeclAreaException.MaxDeclAreaExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration", content = @Content(schema = @Schema(implementation = InvalidDeclException.InvalidDeclExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration dates", content = @Content(schema = @Schema(implementation = InvalidDeclDatesException.InvalidDeclDatesExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Permanent crop form not allowed for the land use", content = @Content(schema = @Schema(implementation = PermanentCropFormNotAllowedException.PermanentCropFormNotAllowedExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Additional field not allowed for the land use", content = @Content(schema = @Schema(implementation = DeclarationAdditionalFieldNotAllowedException.DeclarationAdditionalFieldNotAllowedExceptionErrorBody.class))),			
			@ApiResponse(responseCode = "400", description = "Invalid Decl Area Perc Zero", content = @Content(schema = @Schema(implementation = InvalidDeclAreaPercZeroException.ErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use was not found", content = @Content(schema = @Schema(implementation = LandUseCodeNotFoundException.LandUseCodeNotFoundExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditDeclarationResult updateDeclaration(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The plot declaration code") @PathParam("declCode") String declCode,
			@Parameter(description = "If it is set to true then the areas are returned considering tolerance") @QueryParam("withTolerance") @DefaultValue("false") boolean withTolerance,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@Parameter(description = "The point in time used to retrieve permanent crop form and land use additional field") @NotNull @QueryParam("pointInTime") AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid EditDeclarationPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		LocalDateTime currentDt = cropPlansDAO.getCurrentTimestamp();
		PlotTimeWindowParams params = PlotTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.domainZoneId(domainZoneId)
				.plotCode(plotCode)
				.excludedDeclCode(declCode)
				.pointInTimeFrom(payload.getFromDate())
				.pointInTimeTo(payload.getToDate())
				.versionDt(currentDt)
				.build();
		checkCanDeclare(env, params, payload.getLanduseCode(), payload.getAreaPerc());

		var plot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId,
				currentDt, payload.getFromDate(), payload.getToDate(), plotCode);
		if (plot == null)
			throw new BadRequestException("The plot " + plotCode + " was not found");
		checkPlotEditability(env, businessId, cropPlanId, plot);
		checkLandUseCompatibility(env, businessId, cropPlanId, plot, payload.getLanduseCode());

		cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.EDIT_DECLARATIONS ,env, businessId, cropPlanId, plot);
		
		if (payload.getPermanentCropForms() != null) {
			payload.getPermanentCropForms().forEach(pcf -> checkCanHavePermanentCropForm(env, businessId, cropPlanId, payload.getLanduseCode(), pointInTime, pcf.getFormType()));
		}
		
		checkCanHaveLandUseAdditionalField(env, businessId, cropPlanId, payload.getLanduseCode(), pointInTime, payload.getFieldsCodes());

		return cropPlanDeclarationsService.updateDeclaration(env, params, declCode, payload.getLanduseCode(), payload.getAreaPerc(), payload.getFromDatePrecision(),
				plot.getParcelIntersections(), payload.getPermanentCropForms(), payload.getFieldsCodes(), ignoreDeclValidationWarnings, false, withTolerance);
	}

	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/merge-decls")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Merge plot declarations")
	@ApiResponses({
			@ApiResponse(description = "The merged plot declarations"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot declarations are not editable", content = @Content(schema = @Schema(implementation = PlotDeclarationsNotEditableException.PlotDeclarationsNotEditableExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditDeclarationResult mergeDeclarations(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid MergeDeclarationsPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		LocalDateTime currentDt = cropPlansDAO.getCurrentTimestamp();
		PlotTimeWindowParams params = PlotTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.domainZoneId(domainZoneId)
				.plotCode(plotCode)
				.pointInTimeFrom(payload.getFromDate())
				.pointInTimeTo(payload.getFromDate())
				.versionDt(currentDt)
				.build();

		var plot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId,
				currentDt, payload.getFromDate(), payload.getFromDate(), plotCode);
		if (plot == null)
			throw new BadRequestException("The plot " + plotCode + " was not found");
		checkPlotEditability(env, businessId, cropPlanId, plot);

		cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.MERGE_DECLARATIONS ,env, businessId, cropPlanId, plot);
		
		return cropPlanDeclarationsService.mergeDeclarations(env, params, plot.getParcelIntersections(), ignoreDeclValidationWarnings);
	}

	@DELETE
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/{plotCode}/decls/{declCode}")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Delete a plot declaration")
	@ApiResponses({
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot declarations are not editable", content = @Content(schema = @Schema(implementation = PlotDeclarationsNotEditableException.PlotDeclarationsNotEditableExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditDeclarationResult deleteDeclaration(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The plot declaration code") @PathParam("declCode") String declCode,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		LocalDateTime currentDt = cropPlansDAO.getCurrentTimestamp();
		PlotTimeWindowParams params = PlotTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.domainZoneId(domainZoneId)
				.plotCode(plotCode)
				.excludedDeclCode(declCode)
				.pointInTimeFrom(null)
				.pointInTimeTo(null)
				.versionDt(currentDt)
				.build();

		var decl = declarationsDAO.getDeclarationByDeclCode(cropPlanId, plotCode, currentDt, declCode);
		if (decl == null)
			throw new BadRequestException("The declaration " + declCode + " was not found");

		var plot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId,
				currentDt, decl.getFromDate(), decl.getToDate(), plotCode);
		if (plot == null)
			throw new BadRequestException("The plot " + plotCode + " was not found");
		checkPlotEditability(env, businessId, cropPlanId, plot);
		
		cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.DELETE_DECLARATIONS ,env, businessId, cropPlanId, plot);
		
		return cropPlanDeclarationsService.deleteDeclaration(env, params, decl, plot.getParcelIntersections(), ignoreDeclValidationWarnings, false);
	}
	
	@DELETE
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/plots/decls")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Delete plots declarations")
	@ApiResponses({
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot declarations are not editable", content = @Content(schema = @Schema(implementation = PlotDeclarationsNotEditableException.PlotDeclarationsNotEditableExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditDeclarationResult deleteDeclarations(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid DeleteDeclarationsPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);
		
		LocalDateTime currentDt = cropPlansDAO.getCurrentTimestamp();

		List<String> plotCodes = payload.getPlotCodes().stream().distinct().collect(toList());

		List<Plot> plots = new ArrayList<>();
		for (String plotCode : plotCodes) {
			Plot plot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId,
					currentDt, payload.getPointInTime(), payload.getPointInTime(), plotCode);

			if (plot == null)
				throw new BadRequestException("The plot " + plotCode + " was not found");

			checkPlotEditability(env, businessId, cropPlanId, plot);
			
			cropPlanService.checkPlotDisabledFunctionsForAnomaly(DisabledFunctionCode.DELETE_DECLARATIONS ,env, businessId, cropPlanId, plot);
			
			plots.add(plot);
		}

		return cropPlanDeclarationsService.deletePlotsDeclarations(env, businessId, cropPlanId, currentDt, plots, ignoreDeclValidationWarnings);
	}
	
	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/decls/copy-from-previous-year")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Copy declarations from previous year")
	@ApiResponses({
			@ApiResponse(description = "The updated declarations"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditDeclarationResult copyDeclarationsFromPreviousYear(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		return cropPlanService.copyDeclarationsFromPreviousYear(env, businessId, cropPlanId, ignoreDeclValidationWarnings, pointInTime);
	}

	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/decls/copy-previous-year-from-version")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Copy previous year declarations from version")
	@ApiResponses({
			@ApiResponse(description = "The updated declarations"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditDeclarationResult copyPreviousYearDeclarationsFromVersion(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored")
			@QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@QueryParam("forceNotCompatibleLandCover") @DefaultValue("false") boolean forceNotCompatibleLandCover,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@Valid CopyDeclarationsFromSourceYearPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		return cropPlanService.copyDeclarationsFromVersion(env, businessId, cropPlanId, ignoreDeclValidationWarnings,
				forceNotCompatibleLandCover, pointInTime, AbsoluteDate.of(pointInTime.toLocalDate().minusYears(1)), payload);
	}

	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/decls/copy-current-year-from-version")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Copy current year declarations from version")
	@ApiResponses({
			@ApiResponse(description = "The updated declarations"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditDeclarationResult copyCurrentYearDeclarationsFromVersion(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The point in time to be evaluated") @QueryParam("pointInTime") @NotNull AbsoluteDate pointInTime,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored")
			@QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@QueryParam("forceNotCompatibleLandCover") @DefaultValue("false") boolean forceNotCompatibleLandCover,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@Valid CopyDeclarationsFromSourceYearPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		return cropPlanService.copyDeclarationsFromVersion(env, businessId, cropPlanId,
				ignoreDeclValidationWarnings, forceNotCompatibleLandCover, pointInTime, pointInTime, payload);
	}

	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/copy-campaign")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Copy campaign")
	public SyncStatus copyCampaign(@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@Valid CopyCampaignPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		return syncService.copyCampaign(env, businessId, cropPlanId, payload);
	}

	@GET
	@Path("/{businessId}/plans/{cropPlanId}/copy-campaign/land-use-codes")
	@Operation(description = "Get the land use codes of the source crop plan to be copied (copy campaign)")
	@ApiResponse(description = "The land use codes of the source crop plan to be copied (copy campaign)")
	public List<CopyCampaignLandUseCode> getSourceLandUseCodesForCopyCampaign(@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The source crop plan ID") @QueryParam("sourceCropPlanId") @NotNull Long sourceCropPlanId,
			@Parameter(description = "The source version (if null then the current situation is evaluated)") @QueryParam("sourceVersion") Version sourceVersion,
			@Parameter(description = "The source point in time") @QueryParam("sourcePointInTime") @NotNull AbsoluteDate sourcePointInTime,
			@Parameter(description = "The declarations point in time to (if null then the campaign end date is used)") @QueryParam("declsPointInTimeTo") AbsoluteDate declsPointInTimeTo,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		return copyCampaignService.getSourceLandUseCodesForCopyCampaign(env, businessId, cropPlanId,
				sourceCropPlanId, sourceVersion, sourcePointInTime, declsPointInTimeTo);
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/decls/swap-land-uses")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Swap the source land use with the new one specified")
	@ApiResponses({
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "You must provide both newFromDate and newToDate or none of them", content = @Content(schema = @Schema(implementation = OnlyOneNewDateProvidedException.OnlyOneNewDateProvidedExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration dates", content = @Content(schema = @Schema(implementation = InvalidDeclDatesException.InvalidDeclDatesExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land cover is not editable", content = @Content(schema = @Schema(implementation = LandCoverNotEditableException.LandCoverNotEditableExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use is not allowed for the land cover", content = @Content(schema = @Schema(implementation = IncompatibleLandUseException.IncompatibleLandUseExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot already has declarations at new dates", content = @Content(schema = @Schema(implementation = PlotNotEmptyAtNewDeclDatesException.PlotNotEmptyAtNewDeclDatesExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditDeclarationResult swapLandUses(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid SwapLandUsesPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		var currentDt = cropPlansDAO.getCurrentTimestamp();

		if ((payload.getNewFromDate() == null && payload.getNewToDate() != null) || (payload.getNewFromDate() != null && payload.getNewToDate() == null))
			throw new OnlyOneNewDateProvidedException();

		var sourceLandUse = cropCodeService.getLandUseCode(env, businessId, cropPlanId, payload.getSourceLandUseCode(), null, payload.getSourcePointInTime()); //payload.getPointInTime());
		if (!sourceLandUse.getIsEditable())
			throw new LandCoverNotEditableException(sourceLandUse.getLandUseClass().getLandUseClassCode());

		var newLandUse = cropCodeService.getLandUseCode(env, businessId, cropPlanId, payload.getNewLandUseCode(), null, 
				(payload.getNewFromDate() != null ? payload.getNewFromDate() : payload.getPointInTime()));
		if (newLandUse == null) 
			throw new BadRequestException("The land use " + payload.getNewLandUseCode() + " was not found");
		if (!newLandUse.getIsEditable())
			throw new LandCoverNotEditableException(newLandUse.getLandUseClass().getLandUseClassCode());

		if (!cropCodeService.isLandUseCompatible(env, businessId, cropPlanId, payload.getNewLandUseCode(), sourceLandUse.getLandUseClass().getLandUseClassCode()))
			throw new IncompatibleLandUseException();

		return cropPlanService.swapLandUses(env, businessId, cropPlanId, domainZoneId, currentDt, ignoreDeclValidationWarnings, payload);
	}
	
	@POST
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/decls/complete-with-tare/dates")
	@Operation(description = "Get complete plots with tare land use dates")
	@ApiResponses({
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration dates", content = @Content(schema = @Schema(implementation = InvalidDeclDatesException.InvalidDeclDatesExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot declarations are not editable", content = @Content(schema = @Schema(implementation = PlotDeclarationsNotEditableException.PlotDeclarationsNotEditableExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use is not allowed for the land cover", content = @Content(schema = @Schema(implementation = IncompatibleLandUseException.IncompatibleLandUseExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot already has declarations at new dates", content = @Content(schema = @Schema(implementation = PlotNotEmptyAtNewDeclDatesException.PlotNotEmptyAtNewDeclDatesExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid Decl Area Perc Zero", content = @Content(schema = @Schema(implementation = InvalidDeclAreaPercZeroException.ErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use was not found", content = @Content(schema = @Schema(implementation = LandUseCodeNotFoundException.LandUseCodeNotFoundExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public CompleteWithTareDates getCompleteWithTareLandUseDates(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid GetCompleteWithTareLandUseDatesPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanRead(env, businessId, cropPlanId);

		var config = cropPlanConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.TARE_LAND_USE_CODE.toString(),
				null);
		if (config.isEmpty() || config.get(0) == null)
			throw new BadRequestException("The tare land use was not configured");
		var tareLandUseCode = config.get(0).getParamValue();
		
		return cropPlanService.getCompleteWithTareDates(env, businessId, cropPlanId, domainZoneId, tareLandUseCode, payload.getPlotCodes(), payload.getPointInTime());	
	}

	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/decls/complete-with-tare")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Complete plots with tare land use")
	@ApiResponses({
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration dates", content = @Content(schema = @Schema(implementation = InvalidDeclDatesException.InvalidDeclDatesExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot declarations are not editable", content = @Content(schema = @Schema(implementation = PlotDeclarationsNotEditableException.PlotDeclarationsNotEditableExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use is not allowed for the land cover", content = @Content(schema = @Schema(implementation = IncompatibleLandUseException.IncompatibleLandUseExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot already has declarations at new dates", content = @Content(schema = @Schema(implementation = PlotNotEmptyAtNewDeclDatesException.PlotNotEmptyAtNewDeclDatesExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid Decl Area Perc Zero", content = @Content(schema = @Schema(implementation = InvalidDeclAreaPercZeroException.ErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use was not found", content = @Content(schema = @Schema(implementation = LandUseCodeNotFoundException.LandUseCodeNotFoundExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditDeclarationResult completeWithTareLandUse(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid CompleteWithTareLandUsePayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		var currentDt = cropPlansDAO.getCurrentTimestamp();

		var config = cropPlanConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.TARE_LAND_USE_CODE.toString(),
				null);
		if (config.isEmpty() || config.get(0) == null)
			throw new BadRequestException("The tare land use was not configured");
		var tareLandUseCode = config.get(0).getParamValue();

		CompleteWithTareDates completeWithTareDates = cropPlanService.getCompleteWithTareDates(env, businessId, cropPlanId, domainZoneId, tareLandUseCode, 
				payload.getPlotCodes(), payload.getPointInTime());
		if (completeWithTareDates.getMinFromDate().isAfter(payload.getFromDate()) || completeWithTareDates.getMaxToDate().isBefore(payload.getToDate()))
				throw new InvalidDeclDatesException();
		
		List<PlotsTimeWindowPlotData> plotsData = payload.getPlotCodes().stream()
			.map(pc -> {
				List<ParcelIntersectionWithPlotId> parcels = cropPlansDAO.findPlotsParcelsInternalByPlotCode(cropPlanId, pc, currentDt, payload.getPointInTime(), payload.getPointInTime());
				List<String> parcelCodes = parcels.stream().map(ParcelIntersection::getCode).collect(toList());
				return PlotsTimeWindowPlotData.builder()
						.plotCode(pc)
						.parcelCodes(parcelCodes)
						.areaPerc(100d)
						.build();
			})
			.collect(toList());
		
		PlotsTimeWindowParams params = PlotsTimeWindowParams.builder()
				.businessId(businessId)
				.cropPlanId(cropPlanId)
				.domainZoneId(domainZoneId)
				.pointInTimeFrom(payload.getFromDate())
				.pointInTimeTo(payload.getToDate())
				.versionDt(currentDt)
				.plotsData(plotsData)
				.build();
		return cropPlanDeclarationsService.insertDeclarations(env, params, tareLandUseCode, "YMD",
				new ArrayList<>(), new ArrayList<>(), false, ignoreDeclValidationWarnings, false);
	}
	
	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/decls/fields")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Update declarations fields")
	@ApiResponses({
			@ApiResponse(description = "The updated declarations"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use was not found", content = @Content(schema = @Schema(implementation = LandUseCodeNotFoundException.LandUseCodeNotFoundExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Permanent crop form not allowed for the land use", content = @Content(schema = @Schema(implementation = PermanentCropFormNotAllowedException.PermanentCropFormNotAllowedExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Additional field not allowed for the land use", content = @Content(schema = @Schema(implementation = DeclarationAdditionalFieldNotAllowedException.DeclarationAdditionalFieldNotAllowedExceptionErrorBody.class))),			
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditDeclarationsResult updateDeclarationsFields(
			@Parameter(hidden = true) @Context SecurityContext context,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@Parameter(description = "The point in time used to retrieve permanent crop form and land use additional field") @NotNull @QueryParam("pointInTime") AbsoluteDate pointInTime,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid EditDeclarationsFieldsPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		if (payload.getPermanentCropForms() != null) {
			payload.getPermanentCropForms().forEach(pcf -> 
				checkCanHavePermanentCropForm(env, businessId, cropPlanId, payload.getLanduseCode(), pointInTime, pcf.getFormType()));
		}

		checkCanHaveLandUseAdditionalField(env, businessId, cropPlanId, payload.getLanduseCode(), pointInTime, payload.getFieldsCodes(), true);

		LocalDateTime currentDt = cropPlansDAO.getCurrentTimestamp();

		boolean isBackOffice = context.isUserInRole("VINEALIGN|BACKOFFICE");

		return cropPlanDeclarationsService.updateDeclarationsFields(env, businessId, cropPlanId, domainZoneId, currentDt, payload,
				ignoreDeclValidationWarnings, isBackOffice);
	}
	
	@POST
	@Path("/{businessId}/plans/{cropPlanId}/zones/{domainZoneId}/copy-decls")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Copy declarations")
	@ApiResponses({
			@ApiResponse(description = "The copy declarations result with source and destination updated plots"),
			@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The plot declarations are not editable", content = @Content(schema = @Schema(implementation = PlotDeclarationsNotEditableException.PlotDeclarationsNotEditableExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use is not allowed for the land cover", content = @Content(schema = @Schema(implementation = IncompatibleLandUseException.IncompatibleLandUseExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Maximum declarable area exceeded", content = @Content(schema = @Schema(implementation = MaxDeclAreaException.MaxDeclAreaExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration", content = @Content(schema = @Schema(implementation = InvalidDeclException.InvalidDeclExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "Invalid declaration dates", content = @Content(schema = @Schema(implementation = InvalidDeclDatesException.InvalidDeclDatesExceptionErrorBody.class))),
			@ApiResponse(responseCode = "400", description = "The land use was not found", content = @Content(schema = @Schema(implementation = LandUseCodeNotFoundException.LandUseCodeNotFoundExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
			@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public CopyDeclarationsResult copyDeclarations(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
			@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
			@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
			@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
			@HeaderParam("accept-language") @DefaultValue("en") String language,
			@NotNull @Valid CopyDeclarationsPayload payload) {
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId);
		checkLock(env, cropPlanId);

		LocalDateTime currentDt = cropPlansDAO.getCurrentTimestamp();

		List<Declaration> sourceDecls = payload.getSourceDeclCodes().stream()
				.map(declCode -> cropPlanDeclarationsService.getDeclarationByDeclCode(env, payload.getSourcePlotCode(), businessId, cropPlanId, currentDt, declCode))
				.collect(Collectors.toList());

		double totalAreaPerc = sourceDecls.stream().mapToDouble(Declaration::getAreaPerc).sum();

		AbsoluteDate minFromDate = null;
		AbsoluteDate maxToDate = null;

		List<Declaration> sourceDeclsToBeCopied = new ArrayList<>();
		List<Declaration> sourceDeclsAlreadyExisting = new ArrayList<>();

		for (Declaration decl : sourceDecls) {
			PlotTimeWindowParams params = PlotTimeWindowParams.builder()
					.businessId(businessId)
					.cropPlanId(cropPlanId)
					.domainZoneId(domainZoneId)
					.plotCode(payload.getDestPlotCode())
					.pointInTimeFrom(decl.getFromDate())
					.pointInTimeTo(decl.getToDate())
					.versionDt(currentDt)
					.build();

			checkCanDeclare(env, params, decl.getLanduse().getCode(), totalAreaPerc, false);

			boolean alreadyExisting = !cropPlanConfigDAO.getCropPlanConfig(cropPlanId, CropPlanConfigParam.DISABLE_COPY_DUPLICATED_EXTERNAL_DECLARATIONS.toString(), "TRUE").isEmpty()
					&& externalCodeAlreadyExist(cropPlanId, payload, currentDt, decl, false, buildExternalPermanentCropFormCodes(decl));

			if (alreadyExisting) {
				sourceDeclsAlreadyExisting.add(decl);
			} else {
				sourceDeclsToBeCopied.add(decl);

				minFromDate = (minFromDate == null || decl.getFromDate().isBefore(minFromDate)) ? decl.getFromDate() : minFromDate;
				maxToDate = (maxToDate == null || decl.getToDate().isAfter(maxToDate)) ? decl.getToDate() : maxToDate;
			}
		}
		
		return getCopyDeclarationResult(businessId, cropPlanId, domainZoneId, ignoreDeclValidationWarnings, payload,
				env, currentDt, minFromDate, maxToDate, sourceDeclsToBeCopied, sourceDeclsAlreadyExisting);
	}

	private CopyDeclarationsResult getCopyDeclarationResult(String businessId, Long cropPlanId, String domainZoneId,
			boolean ignoreDeclValidationWarnings, CopyDeclarationsPayload payload, RuntimeEnvironment env,
			LocalDateTime currentDt, AbsoluteDate minFromDate, AbsoluteDate maxToDate,
			List<Declaration> sourceDeclsToBeCopied, List<Declaration> sourceDeclsAlreadyExisting) {
		if (!sourceDeclsToBeCopied.isEmpty()) {
			var sourcePlot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId,
					currentDt, minFromDate, maxToDate, payload.getSourcePlotCode());
			if (sourcePlot == null)
				throw new BadRequestException("The source plot " + payload.getSourcePlotCode() + " was not found");
			if (payload.isRemoveSourceDecls()) {
				checkPlotEditability(env, businessId, cropPlanId, sourcePlot);
			}
			
			var destPlot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId,
					currentDt, minFromDate, maxToDate, payload.getDestPlotCode());
			if (destPlot == null)
				throw new BadRequestException("The destination plot " + payload.getDestPlotCode() + " was not found");
			
			checkPlotEditability(env, businessId, cropPlanId, destPlot);
			
			checkDeclLandUSeCompatibility(businessId, cropPlanId, env, sourceDeclsToBeCopied, destPlot);
			
			return buildCopyDeclarationsResult(businessId, cropPlanId, domainZoneId, ignoreDeclValidationWarnings,
					payload, env, currentDt, sourceDeclsToBeCopied, sourceDeclsAlreadyExisting, sourcePlot, destPlot);
		} else {
			CopyDeclarationsResult result = new CopyDeclarationsResult();
			result.setSourceDeclarationsAlreadyExisting(sourceDeclsAlreadyExisting);
			return result;
		}
	}

	private CopyDeclarationsResult buildCopyDeclarationsResult(String businessId, Long cropPlanId, String domainZoneId,
			boolean ignoreDeclValidationWarnings, CopyDeclarationsPayload payload, RuntimeEnvironment env,
			LocalDateTime currentDt, List<Declaration> sourceDeclsToBeCopied,
			List<Declaration> sourceDeclsAlreadyExisting, Plot sourcePlot, Plot destPlot) {
		
		CopyDeclarationsResult result = cropPlanDeclarationsService.copyDeclarations(env, businessId, cropPlanId, domainZoneId, currentDt, sourcePlot, sourceDeclsToBeCopied, destPlot, 
				payload.isRemoveSourceDecls(), ignoreDeclValidationWarnings);
		if (result.getValidationMessages().isEmpty()) {
			Plot sourceUpdatedPlot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId,
					currentDt, payload.getPointInTime(), payload.getPointInTime(), payload.getSourcePlotCode());
			result.setSourceUpdatedPlot(sourceUpdatedPlot);
		
			Plot destUpdatedPlot = cropPlanService.getPlot(env, businessId, cropPlanId, domainZoneId,
					currentDt, payload.getPointInTime(), payload.getPointInTime(), payload.getDestPlotCode());
			result.setDestUpdatedPlot(destUpdatedPlot);
			result.setSourceDeclarationsAlreadyExisting(sourceDeclsAlreadyExisting);
		}
		return result;
	}

	private void checkDeclLandUSeCompatibility(String businessId, Long cropPlanId, RuntimeEnvironment env,
			List<Declaration> sourceDeclsToBeCopied, Plot destPlot) {
		List<String> lucs = sourceDeclsToBeCopied.stream()
				.map(d -> d.getLanduse().getCode())
				.distinct()
				.collect(toList());
		for (String luc : lucs)
			checkLandUseCompatibility(env, businessId, cropPlanId, destPlot, luc);
	}

	private boolean externalCodeAlreadyExist(Long cropPlanId, CopyDeclarationsPayload payload, LocalDateTime currentDt,
			Declaration decl, boolean alreadyExisting, List<String> externalCodes) {
		if (!externalCodes.isEmpty()
				&& declarationsDAO.getExternalCodeCount(cropPlanId, payload.getDestPlotCode(), currentDt, payload.getPointInTime(), decl.getFromDate(), 
						decl.getToDate(), externalCodes) > 0)
			alreadyExisting = true;
		return alreadyExisting;
	}

	private List<String> buildExternalPermanentCropFormCodes(Declaration decl) {
		List<String> externalCodes = new ArrayList<>();
		
		for (PermanentCropForm cpf : decl.getPermanentCropForms())
			if (cpf.getPermanentCropFormData().getExternalCode() != null && !cpf.getPermanentCropFormData().getExternalCode().isEmpty())
				externalCodes.add(cpf.getPermanentCropFormData().getExternalCode());
		
		return externalCodes;
	}
}
