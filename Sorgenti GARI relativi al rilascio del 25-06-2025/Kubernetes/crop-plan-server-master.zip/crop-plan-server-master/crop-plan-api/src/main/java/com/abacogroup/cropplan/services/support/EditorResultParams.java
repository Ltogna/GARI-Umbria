package com.abacogroup.cropplan.services.support;

import java.util.List;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.domain.Parcel;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class EditorResultParams {

	private AbsoluteDate pointInTime;
	private List<Parcel> parcels;
}
