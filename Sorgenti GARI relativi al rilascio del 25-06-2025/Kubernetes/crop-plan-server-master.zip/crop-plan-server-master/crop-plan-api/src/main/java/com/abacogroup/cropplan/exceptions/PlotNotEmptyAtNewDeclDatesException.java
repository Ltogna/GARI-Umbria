package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class PlotNotEmptyAtNewDeclDatesException extends WebApplicationException
{
	private static final long serialVersionUID = -1258759764600153142L;

	public static  class PlotNotEmptyAtNewDeclDatesExceptionErrorBody
	{
		@Schema(allowableValues = "PLOT_NOT_EMPTY_AT_NEW_DECL_DATES_EXCEPTION")
		public String getErrorCode()
		{
			return "PLOT_NOT_EMPTY_AT_NEW_DECL_DATES_EXCEPTION";
		}
	}
	
	private static final PlotNotEmptyAtNewDeclDatesExceptionErrorBody BODY = new PlotNotEmptyAtNewDeclDatesExceptionErrorBody();

	public PlotNotEmptyAtNewDeclDatesException(String plotCode)
	{
		super("Plot " + plotCode + " already has declarations at new dates",
			Response.status(Status.BAD_REQUEST).entity(BODY).build());
	}
}
