package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import java.util.List;

import com.abacogroup.cropplan.sdk.model.Version;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CopyCampaignPayload
{
	@Schema(description = "The source crop plan id")
	@NotNull
	private Long sourceCropPlanId;

	@Schema(description = "The source crop plan version (if null then current plan in progress is used)")
	private Version sourceVersion;

	@Schema(description = "The source point in time")
	@NotNull
	private AbsoluteDate sourcePointInTime; 

	@Schema(description = "The destination point in time")
	@NotNull
	private AbsoluteDate destPointInTime; 

	@Schema(description = "The list of land use codes to be excluded from aggregation (if the skipAggregation parameter is set to true then this list is ignored)")
	private List<String> landuseCodesExcludedFromAggregation;

	@Schema(description = "If it is set to true then new acquired areas is copied from other businesses")
	@Builder.Default
	private boolean flCopyFromOtherBusinesses = false;

	@Schema(description = "If it is set to true then the copied declarations retain the same dates. "
		+ "Warning: copying from different year may generate inconsistent declarations dates")
	@Builder.Default
	private boolean preserveSourceDeclDates = false;

	@Schema(description = "If it is set to true then the source plots are not aggregated")
	@Builder.Default
	private boolean skipAggregation = false;

	@Schema(description = "The declarations point in time to (if null then the campaign end date is used)")
	private AbsoluteDate declsPointInTimeTo;
}
