package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;

@Data
public class RestorePlotsDefaultPayload
{
	@Schema(description = "The plot codes")
	@NotNull
	private List<String> plotCodes;
	
	@Schema(description = "From date")
	@NotNull
	private AbsoluteDate fromPointInTime;
}
