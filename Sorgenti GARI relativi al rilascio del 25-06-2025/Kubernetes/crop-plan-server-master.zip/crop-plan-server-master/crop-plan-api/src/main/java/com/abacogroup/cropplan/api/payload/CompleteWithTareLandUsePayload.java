package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;

@Data
public class CompleteWithTareLandUsePayload {
	@Schema(description = "The plot codes to be completed")
	@NotEmpty
	private List<String> plotCodes;
    
    @Schema(description = "The from date")
	@NotNull
    private AbsoluteDate fromDate;
    
    @Schema(description = "The to date")
    @NotNull
    private AbsoluteDate toDate;
    
    @Schema(description = "The point in time")
    @NotNull
    private AbsoluteDate pointInTime;
    
}
