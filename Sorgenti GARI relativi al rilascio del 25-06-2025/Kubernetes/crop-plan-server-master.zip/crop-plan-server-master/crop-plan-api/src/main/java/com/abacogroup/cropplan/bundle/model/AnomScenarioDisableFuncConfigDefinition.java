package com.abacogroup.cropplan.bundle.model;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnomScenarioDisableFuncConfigDefinition
{
	private String scenario;
	
	private List<FunctionsDisabledConfig> functionsDisabledConfig = new ArrayList<>();
	
	private List<ScenarioAnomaliesConfig> scenarioAnomaliesConfig = new ArrayList<>();
}
