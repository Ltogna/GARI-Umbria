package com.abacogroup.cropplan.bundle.model;

import com.abacogroup.cropplan.bundle.model.ValidationGroups.Delete;
import com.abacogroup.cropplan.bundle.model.ValidationGroups.Update;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AdditDeclFieldLucConfMessage {

	@NotBlank(groups = { Default.class, Update.class, Delete.class})
	private String landUseCode;
	@NotBlank(groups = { Update.class, Delete.class})
	private String code;

	@NotNull(groups = { Default.class, Update.class})
	private Boolean nullable;

	/// filter correct config row using a date between CRPL_LANDUSE_ADDIT_FIELDS.VALID_FROM and CRPL_LANDUSE_ADDIT_FIELDS.VALID_TO
	@NotNull(groups = { Update.class, Delete.class})
	private AbsoluteDate validDateFilter;

}
