package com.abacogroup.cropplan.api;

import java.util.List;

import com.abacogroup.cropplan.sdk.model.Declaration;

import lombok.Data;

@Data
public class MergedDeclaration {
	private Declaration declaration;
	private List<Declaration> sourceDeclarations;
}
