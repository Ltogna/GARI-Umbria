package com.abacogroup.cropplan.api.internal.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class InternalInsertDeclarationPayload {
	
	@Schema(description = "From date")
	@NotNull
	private AbsoluteDate fromDate;
	
	@Schema(description = "From date precision ('Y' if only year is specified, 'YM' if year month is specified, 'YMD' if year month date is specified, '-' if nothing is specified and plot day from is used); default 'YMD'")
	@NotNull
	private String fromDatePrecision = "YMD";
	
	@Schema(description = "To date")
	@NotNull
	private AbsoluteDate toDate;
	
	@Schema(description = "Land use code")
	@NotEmpty
	private String landuseCode;
	
	@Schema(description = "The declared area in percentage")
	@NotNull
	private Double areaPerc;
	
	@Schema(description = "The external declaration code")
	private String externalCode;
	
}
