package com.abacogroup.cropplan.db.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.customizer.Define;
import org.jdbi.v3.sqlobject.statement.SqlQuery;

import com.abacogroup.cropplan.api.CropPlanLandUse;
import com.abacogroup.cropplan.api.DeclRotationDto;
import com.abacogroup.cropplan.api.PlanHasDeclarationsForLandUse;
import com.abacogroup.cropplan.api.PlotDeclRotationDto;
import com.abacogroup.cropplan.api.PlotDeclaration;
import com.abacogroup.cropplan.db.dao.ntt.DeclarationBaseInfo;
import com.abacogroup.cropplan.db.dao.ntt.DeclarationData;
import com.abacogroup.cropplan.db.dao.ntt.DeclarationWithPlotCode;
import com.abacogroup.cropplan.db.dao.ntt.LandCoverAndTypeId;
import com.abacogroup.cropplan.db.dao.ntt.ParcelCodeWithPointInTime;
import com.abacogroup.cropplan.sdk.mapper.VersionColumnMapper;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(VersionColumnMapper.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface DeclarationsDAO extends BasicDAO
{
	@SqlQuery("select distinct cd.land_use_code"
		+ "      from crpl_declarations cd"
		+ "     where cd.plan_id = :cropPlanId"
		+ "       and :versionDt between cd.dt_insert and cd.dt_delete"
		+ "       and :pointInTimeFrom <= cd.day_to"
		+ "       and :pointInTimeTo >= cd.day_from"
		+ "       and (:excludePlantedBefore is null or cd.day_from >= :excludePlantedBefore)"
		+ "       and (:excludeHarvestedAfter is null or cd.day_to <= :excludeHarvestedAfter)"
		+ "       and cd.land_use_code not in (select c.code from cache_decodes c, crpl_plans cp where c.type = :cacheDecodesType and cp.type_id = c.type_id and cp.id = :cropPlanId)")
	@RegisterBeanMapper(DeclarationWithPlotCode.class)
	@RegisterBeanMapper(LandUse.class)
	public List<String> getDeclarationsLandUseCodesNotInCache(@Bind("cropPlanId") Long cropPlanId,
		@Bind("versionDt") LocalDateTime versionDt,
		@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
		@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo,
		@Bind("excludePlantedBefore") AbsoluteDate excludePlantedBefore,
		@Bind("excludeHarvestedAfter") AbsoluteDate excludeHarvestedAfter,
		@Bind("cacheDecodesType") String cacheDecodesType);

	@SqlQuery("select cd.decl_code, cd.land_use_code, cd.day_from, cd.day_to"
		+ "		 from crpl_declarations cd"
		+ "		where cd.plan_id = :cropPlanId"
		+ "		  and cd.decl_code in (<declCodes>)"
		+ "		  and :versionDt between cd.dt_insert and cd.dt_delete"
		+ "       and :pointInTimeFrom <= cd.day_to"
		+ "       and :pointInTimeTo >= cd.day_from")
	@RegisterBeanMapper(DeclarationBaseInfo.class)
	public List<DeclarationBaseInfo> getDeclarationBaseInfo(@Bind("cropPlanId") Long cropPlanId,
		@BindList("declCodes") List<String> declCodes,
		@Bind("versionDt") LocalDateTime versionDt,
		@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
		@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo);

	@SqlQuery("SELECT DISTINCT cpdp.land_cover_code AS landCoverCode, cplans.TYPE_ID AS typeId" +
			"     FROM crpl_plot_data cpd, crpl_plot_data_parcels cpdp, CRPL_PLANS cplans \n" +
			"    WHERE cpd.plan_id = :cropPlanId \n" +
			"     AND cplans.id = cpd.plan_id" +
			"     AND :versionDt BETWEEN cpd.dt_insert AND cpd.dt_delete \n" +
			"     AND :pointInTimeFrom <= cpd.day_to \n" +
			"     AND :pointInTimeTo >= cpd.day_from \n" +
			"     AND cpdp.plot_data_id = cpd.id \n" +
			"     AND cpdp.land_cover_code IS NOT NULL \n" +
			"     AND cpdp.land_cover_code NOT IN ( SELECT c.land_cover_code \n" +
			"     FROM crpl_cache_land_cover_compat c, crpl_plans cp WHERE cp.type_id = c.type_id AND cp.id = :cropPlanId)")
	@RegisterBeanMapper(LandCoverAndTypeId.class)
    List<LandCoverAndTypeId> getDeclarationsLandCoverCodesNotInCache(
            @Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt, @Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
            @Bind("pointInTimeTo") AbsoluteDate pointInTimeTo);

	@SqlQuery("select distinct cpd.day_to as pointInTime, cpdp.parcel_code as parcelCode"
		+ "      from crpl_plot_data cpd, crpl_plot_data_parcels cpdp"
		+ "     where cpd.plan_id = :cropPlanId"
		+ "       and :versionDt between cpd.dt_insert and cpd.dt_delete"
		+ "       and :pointInTimeFrom <= cpd.day_to"
		+ "       and :pointInTimeTo >= cpd.day_from"
		+ "       and cpdp.plot_data_id = cpd.id"
		+ "       and (cpd.day_to || '|' || cpdp.parcel_code) not in (select c.code from cache_decodes c, crpl_plans cp where c.type = :cacheDecodesType and cp.type_id = c.type_id and cp.id = :cropPlanId)")
	@RegisterBeanMapper(ParcelCodeWithPointInTime.class)
	public List<ParcelCodeWithPointInTime> getDeclarationsParcelCodesNotInCache(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
			@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@Bind("cacheDecodesType") String cacheDecodesType);

	@SqlQuery("select distinct cp.domain_zone_id"
		+ "      from crpl_plot_data cpd, crpl_plots cp"
		+ "     where cpd.plan_id = :cropPlanId"
		+ "       and :versionDt between cpd.dt_insert and cpd.dt_delete"
		+ "       and :pointInTimeFrom <= cpd.day_to"
		+ "       and :pointInTimeTo >= cpd.day_from"
		+ "       and cp.plot_code = cpd.plot_code and cp.plan_id = cpd.plan_id"
		+ "       and cp.domain_zone_id not in (select c.code from cache_decodes c, crpl_plans cpl where c.type = :cacheDecodesType and cpl.type_id = c.type_id and cpl.id = :cropPlanId)")
	public List<String> getDeclarationsDomainCodesNotInCache(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
			@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@Bind("cacheDecodesType") String cacheDecodesType);

	@SqlQuery("select *"
		+ "    from "
		+ "    ("
		+ "       select cd.plot_code as plotCode,"
		+ "              cd.decl_code as declCode,"
		+ "              cd.land_use_code as landuseCode,"
		+ "              upper((select c1.description from cache_decodes c1, crpl_plans cp1 where c1.code = cd.land_use_code and c1.type = :landUseCacheDecodesType and cp1.type_id = c1.type_id and cp1.id = :cropPlanId)) as landuseDescription,"
		+ "              cd.area_perc as areaPerc,"
		+ "              cd.day_from as fromDate,"
		+ "              cd.day_from_precision as fromDatePrecision,"
		+ "              cd.day_to as toDate,"
		+ "              cd.dt_insert,"
		+ "              ("
		+ "                     select upper((select c2.description from cache_decodes c2, crpl_plans cp2 where c2.code = (cpd2.day_to || '|' || cpdp.parcel_code) and c2.type = :parcelCacheDecodesType and cp2.type_id = c2.type_id and cp2.id = :cropPlanId))"
		+ "                       from crpl_plot_data cpd2, crpl_plot_data_parcels cpdp"
		+ "                      where cpd2.day_from ="
		+ "                               ("
		+ "                                  select max(cpd1.day_from)"
		+ "                                    from crpl_plot_data cpd1"
		+ "                                   where cpd1.plot_code = cd.plot_code"
		+ "                                     and :versionDt between cpd1.dt_insert and cpd1.dt_delete"
		+ "                                     and :pointInTimeFrom <= cpd1.day_to"
		+ "                                     and :pointInTimeTo >= cpd1.day_from"
		+ "                                     and cpd1.plan_id = :cropPlanId"
		+ "                               )"
		+ "                        and cpd2.plan_id = :cropPlanId"
		+ "                        and cpd2.plot_code = cd.plot_code"
		+ "                        and :versionDt between cpd2.dt_insert and cpd2.dt_delete"
		+ "                        and cpdp.plot_data_id = cpd2.id"
		+ "                        and (select count(*) from crpl_plot_data_parcels cpdp_count where cpdp_count.plot_data_id = cpd2.id) = 1" // exclude plots linked to more than 1 parcel
		+ "              ) as parcelDescription,"
		+ "              ("
		+ "                     select (select c2.description from cache_decodes c2, crpl_plans cp2 where c2.code = (cpd2.day_to || '|' || cpdp.parcel_code) and c2.type = :parcelCodeCacheDecodesType and cp2.type_id = c2.type_id and cp2.id = :cropPlanId)"
		+ "                       from crpl_plot_data cpd2, crpl_plot_data_parcels cpdp"
		+ "                      where cpd2.day_from ="
		+ "                               ("
		+ "                                  select max(cpd1.day_from)"
		+ "                                    from crpl_plot_data cpd1"
		+ "                                   where cpd1.plot_code = cd.plot_code"
		+ "                                     and :versionDt between cpd1.dt_insert and cpd1.dt_delete"
		+ "                                     and :pointInTimeFrom <= cpd1.day_to"
		+ "                                     and :pointInTimeTo >= cpd1.day_from"
		+ "                                     and cpd1.plan_id = :cropPlanId"
		+ "                               )"
		+ "                        and cpd2.plan_id = :cropPlanId"
		+ "                        and cpd2.plot_code = cd.plot_code"
		+ "                        and :versionDt between cpd2.dt_insert and cpd2.dt_delete"
		+ "                        and cpdp.plot_data_id = cpd2.id"
		+ "                        and (select count(*) from crpl_plot_data_parcels cpdp_count where cpdp_count.plot_data_id = cpd2.id) = 1" // exclude plots linked to more than 1 parcel
		+ "              ) as parcelCode,"
		+ "              upper((select c2.description from cache_decodes c2, crpl_plans cp2 where c2.code = cp.domain_zone_id and c2.type = :domainCacheDecodesType and cp2.type_id = c2.type_id and cp2.id = :cropPlanId)  || ' - ' || cp.domain_zone_id) as domainDescription,"
		+ "              (case when cd.dt_delete < :versionDt or not exists ("
		+ "                    select 1"
		+ "                      from crpl_plot_data cpd "
		+ "                     where cpd.plan_id = :cropPlanId"
		+ "                       and cpd.plot_code = cd.plot_code"
		+ "                       and :versionDt between cpd.dt_insert and cpd.dt_delete"
		+ "                       and :pointInTimeFrom <= cpd.day_to"
		+ "                       and :pointInTimeTo >= cpd.day_from"
		+ "              ) then 1 else 0 end) as deleted"
		+ "         from crpl_declarations cd, crpl_plots cp"
		+ "        where cd.plan_id = :cropPlanId"
		+ "		  	 and cp.plan_id = cd.plan_id"
		+ "          and cp.plot_code = cd.plot_code"
		+"			 and ( :domainZoneId is null or (cp.domain_zone_id = :domainZoneId))"
	
		+ "          and ("
		+ "                 (:evaluateUpdateTimeTo = 0 and :versionDt between cd.dt_insert and cd.dt_delete)"
		+ " 		   	    or"
		+ "     			("
		+ "                        :evaluateUpdateTimeTo = 1"
		+ " 		   	       and cd.id in (select cd2.id from crpl_declarations cd2, (select cd1.plan_id, cd1.decl_code, max(cd1.dt_delete) as dt_delete from crpl_declarations cd1 where cd1.plan_id = cd.plan_id group by cd1.plan_id, cd1.decl_code) cd3 where cd2.plan_id = cd3.plan_id and cd2.decl_code = cd3.decl_code and cd2.dt_delete = cd3.dt_delete)"
		+ "		               and ("
		+ "	                          ("
		+ "	       	                         cd.dt_delete > :updateTimeFrom"
		+ "	    	                     and cd.dt_delete <= :updateTimeTo"
		+ "		                         and :evaluateUpdateTimeFrom = 1"
		+ "		                      )"
		+ "	                          or"
		+ "	                          ("
		+ "	     	                         exists (select 1"
		+ "	                                           from crpl_plot_data cpd"
		+ "	                                          where cpd.plan_id = cd.plan_id"
		+ "	     	                                    and cpd.plot_code = cd.plot_code"
		+ "	     	                                    and :versionDt between cpd.dt_insert and cpd.dt_delete"
		+ "	     	                                    and ("
        + "	     	                                     	 	(:evaluateUpdateTimeFrom = 0 or cpd.dt_insert > :updateTimeFrom)"
		+ "	     	                                     	 	and cpd.dt_insert <= :updateTimeTo"
		+ "	     	                                     	))"
		+ "	                          )"
		+ "	                          or"
		+ "	                          ("
		+ "	     	                         :versionDt between cd.dt_insert and cd.dt_delete"
		+ "	                             and (:evaluateUpdateTimeFrom = 0 or cd.dt_insert > :updateTimeFrom)"
		+ "	                             and cd.dt_insert <= :updateTimeTo"
		+ "	                          )"
		+ "                    )"
		+ "                 )"
		+ "	             )"
		+ "          and :pointInTimeFrom <= cd.day_to"
		+ "          and :pointInTimeTo >= cd.day_from"
		+ "          and (:excludePlantedBefore is null or cd.day_from >= :excludePlantedBefore)"
		+ "          and (:excludeHarvestedAfter is null or cd.day_to <= :excludeHarvestedAfter)"
		+ "          and exists (select 1"
		+ "                        from crpl_plot_data cpd"
		+ "                       where cpd.plan_id = cd.plan_id"
		+ "                         and cpd.plot_code = cd.plot_code"
		+ "                         and :versionDt between cpd.dt_insert and cpd.dt_delete"
		+ "                         and ("
		+ "                                  ("
		+ "                                      :pointInTimeFrom <= cpd.day_to"
		+ "                                      and :pointInTimeTo >= cpd.day_from"
		+ "                                      and :evaluateUpdateTimeTo = 0"
		+ "                                  )"
		+ "                                  or :evaluateUpdateTimeTo = 1"
		+ "                             )"
		+ "          )"
		+ "   ) t"
		+ "   where (landuseDescription like coalesce(upper('%' || :search || '%'), landuseDescription)"
		+ "            or parcelDescription like coalesce(upper('%' || :search || '%'), parcelDescription)"
		+ "            or domainDescription like coalesce(upper('%' || :search || '%'), domainDescription))"
		+ "     and (landuseCode = coalesce(<landCoverCodes>, landuseCode) or exists (select 1 from CRPL_CACHE_LAND_COVER_COMPAT c3, crpl_plans cp3 where c3.LAND_COVER_CODE in (<landCoverCodes>) and cp3.type_id = c3.type_id and cp3.id = :cropPlanId and c3.LAND_USE_CODE = landuseCode))"
		+ "     and landUseCode = coalesce(:landUseCode, landUseCode)"
		+ "     and (:parcelCode is null or :parcelCode in "
		+ "         ("
		+ "				select c3.description"
		+ "				  from crpl_plot_data cpd2, crpl_plot_data_parcels cpdp, cache_decodes c3, crpl_plans cp3"
		+ "				 where cpd2.day_from ="
		+ "				       ("
		+ "				          select max(cpd1.day_from)"
		+ "				            from crpl_plot_data cpd1"
		+ "				           where cpd1.plot_code = plotCode"
		+ "				             and :versionDt between cpd1.dt_insert and cpd1.dt_delete"
		+ "				             and :pointInTimeFrom <= cpd1.day_to"
		+ "				             and :pointInTimeTo >= cpd1.day_from"
		+ "                          and cpd1.plan_id = :cropPlanId"
		+ "				       )"
		+ "                and cpd2.plan_id = :cropPlanId"
		+ "                and cpd2.plot_code = plotCode"
		+ "                and :versionDt between cpd2.dt_insert and cpd2.dt_delete"
		+ "                and cpdp.plot_data_id = cpd2.id"
		+ "                and c3.code = (cpd2.day_to || '|' || cpdp.parcel_code)"
		+ "                and c3.type = :parcelCodeCacheDecodesType"
		+ "                and cp3.type_id = c3.type_id "
		+ "                and cp3.id = :cropPlanId"
		+ "         ))"
		+ "     and (declCode = coalesce(<declCodes>, declCode) or declCode in (<declCodes>)) "
		+ "     and (:anomaliesErrorCode is null or ("
		+ "             select count(*) "
		+ "               from crpl_anomalies anom "
		+ "              where anom.PLAN_ID = :cropPlanId"
		+ "                and anom.OBJECT_CODE = t.declCode "
		+ "                and anom.OBJECT_TYPE = 'DECLARATION' "
		+ "                and anom.ERROR_CODE = :anomaliesErrorCode "
		+ "                and :versionDt between anom.dt_insert and anom.dt_delete) > 0 "
		+ "         or ("
		+ "             select count(*) "
		+ "               from crpl_anomalies anom "
		+ "              where anom.PLAN_ID = :cropPlanId"
		+ "                and anom.OBJECT_CODE = t.plotCode "
		+ "                and anom.OBJECT_TYPE = 'PLOT' "
		+ "                and anom.ERROR_CODE = :anomaliesErrorCode "
		+ "                and :versionDt between anom.dt_insert and anom.dt_delete) > 0)"
		+ "order by dt_insert, <order>")
	@RegisterBeanMapper(PlotDeclaration.class)
	@RegisterBeanMapper(LandUse.class)
    ResultIterator<PlotDeclaration> getDeclarations(@Bind("cropPlanId") Long cropPlanId,
                                                    @Bind("versionDt") LocalDateTime versionDt,
                                                    @Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
                                                    @Bind("pointInTimeTo") AbsoluteDate pointInTimeTo,
                                                    @Bind("evaluateUpdateTimeFrom") Integer evaluateUpdateTimeFrom,
                                                    @Bind("updateTimeFrom") LocalDateTime updateTimeFrom,
                                                    @Bind("evaluateUpdateTimeTo") Integer evaluateUpdateTimeTo,
                                                    @Bind("updateTimeTo") LocalDateTime updateTimeTo,
                                                    @Bind("excludePlantedBefore") AbsoluteDate excludePlantedBefore,
                                                    @Bind("excludeHarvestedAfter") AbsoluteDate excludeHarvestedAfter,
                                                    @Bind("landUseCacheDecodesType") String landUseCacheDecodesType,
                                                    @Bind("landCoverCacheDecodesType") String landCoverCacheDecodesType,
                                                    @Bind("parcelCacheDecodesType") String parcelCacheDecodesType,
                                                    @Bind("parcelCodeCacheDecodesType") String parcelCodeCacheDecodesType,
                                                    @Bind("domainCacheDecodesType") String domainCacheDecodesType,
                                                    @BindList(value = "landCoverCodes", onEmpty = BindList.EmptyHandling.NULL_STRING) List<String> landCoverCodes,
                                                    @Bind("landUseCode") String landUseCode,
                                                    @Bind("parcelCode") String parcelCode,
                                                    @BindList(value = "declCodes", onEmpty = BindList.EmptyHandling.NULL_STRING) List<String> declCodes,
                                                    @Bind("anomaliesErrorCode") String anomaliesErrorCode,
                                                    @Bind("search") String search,
                                                    @Define("order") String order,
													@Bind("domainZoneId") String domainZoneId
													);
													
	@SqlQuery("select max(dt_update)"
			+ "     from"
			+ "        ("
			+ "            select max(dt_delete) as dt_update "
			+ "			    from"
			+ "    		       ("
			+ "        			  select max(cd.dt_delete) as dt_delete"
			+ "        			    from crpl_declarations cd  "
			+ "       			   where cd.plan_id = :cropPlanId"
			+ "         		     and land_use_code in (<landUseCodes>)"
			+ "				    group by cd.plan_id, cd.decl_code"
			+ "    			   ) a"
			+ "			  where dt_delete < §current_timestamp§"
			+ "           union all"
			+ "           select max(dt_insert) as dt_update from"
			+ "                ("
			+ "        	          select max(cd.dt_insert) as dt_insert, max(cd.dt_delete) as dt_delete"
			+ "       	            from crpl_declarations cd"
			+ "                    where cd.plan_id = :cropPlanId"
			+ "                      and land_use_code in (<landUseCodes>)"
			+ "	                group by cd.plan_id, cd.decl_code"
			+ "                ) b"
			+ "           where §current_timestamp§ between dt_insert and dt_delete"
			+ "           union all"
			+ "           select max(dt_insert) as dt_update from "
			+ "                  ( "
			+ "                     SELECT max(cpd.dt_insert) as dt_insert, max(cpd.dt_delete) as dt_delete "
			+ "                       FROM crpl_declarations cd, crpl_plot_data cpd "
			+ "                      WHERE cd.plan_id = :cropPlanId "
			+ "                        and cd.land_use_code in (<landUseCodes>)"
			+ "                        and cd.plot_code = cpd.plot_code "
			+ "                   group by cpd.plan_id, cpd.plot_code "
			+ "                  ) c"
			+ "             where §current_timestamp§ between dt_insert and dt_delete "
			+ "       ) d")
	public LocalDateTime getDeclarationsLastModificationDate(@Bind("cropPlanId") Long cropPlanId,
		@BindList("landUseCodes") List<String> landUseCodes);


	@SqlQuery("select cpd.id as plotId,"
		+ "           (select cpn.description from crpl_plot_names cpn where cpn.plan_id = cpd.plan_id and cpn.plot_code = cpd.plot_code and :versionDt between cpn.dt_insert and cpn.dt_delete) as plotDescription,"
		+ "           (select cpn.notes from crpl_plot_names cpn where cpn.plan_id = cpd.plan_id and cpn.plot_code = cpd.plot_code and :versionDt between cpn.dt_insert and cpn.dt_delete) as plotNotes,"
		+ "           cpd.area_sqm as plotAreaSqm,"
		+ "           cpd.geom,"
		+ "           cpd.srs,"
		+ "           cpd.day_from as plotFromDate,"
		+ "           cpd.day_to as plotToDate,"
		+ "           cp.domain_zone_id as domainZoneCode"
		+ "      from crpl_plot_data cpd, crpl_plots cp"
		+ "     where cpd.plan_id = :cropPlanId"
		+ "       and cpd.plot_code = :plotCode"
		+ "		  and :versionDt between cpd.dt_insert and cpd.dt_delete"
		+ "		  and :pointInTimeFrom <= cpd.day_to"
		+ "		  and :pointInTimeTo >= cpd.day_from"
		+ "       and cp.plan_id = cpd.plan_id"
		+ "       and cp.plot_code = cpd.plot_code"
		+ "  order by cpd.day_from desc")
	@RegisterBeanMapper(PlotDeclaration.class)
	public ResultIterator<PlotDeclaration> getDeclarationPlotData(@Bind("cropPlanId") Long cropPlanId,
		@Bind("plotCode") String plotCode,
		@Bind("versionDt") LocalDateTime versionDt,
		@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
		@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo);

	@SqlQuery("select distinct cd.land_use_code as landuseCode"
		+ "      from crpl_declarations cd"
		+ "     where cd.plan_id = :cropPlanId"
		+ "	      and :versionDt between cd.dt_insert and cd.dt_delete"
		+ "		  and :pointInTimeFrom <= cd.day_to"
		+ "		  and :pointInTimeTo >= cd.day_from"
			  + " order by cd.land_use_code asc ")
	public List<String> getDeclarationLandUsesCodes(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
			@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo);

	@SqlQuery("select cd.land_use_code as code, round(sum(cd.area_perc / 100 * cpd.area_sqm)) as areaSqm"
		+ "      from crpl_declarations cd, crpl_plot_data cpd"
		+ "     where cd.plan_id = :cropPlanId"
		+ "       and :versionDt between cd.dt_insert and cd.dt_delete"
		+ "       and :pointInTime between cd.day_from and cd.day_to"
		+ "       and cpd.plan_id = cd.plan_id"
		+ "       and cpd.plot_code = cd.plot_code"
		+ "       and :versionDt between cpd.dt_insert and cpd.dt_delete"
		+ "       and :pointInTime between cpd.day_from and cpd.day_to"
		+ "     group by cd.land_use_code")
	@RegisterBeanMapper(CropPlanLandUse.class)
	public List<CropPlanLandUse> getDeclarationLandUsesCodesWithArea(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTime") AbsoluteDate pointInTime);

	@SqlQuery("select distinct cpd.day_to as pointInTime, cpdp.parcel_code as parcelCode"
		+ "      from crpl_plot_data_parcels cpdp, crpl_plot_data cpd, crpl_declarations cd"
		+ "     where cpd.day_from ="
		+ "              ("
		+ "                 select max(cpd1.day_from)"
		+ "                   from crpl_plot_data cpd1"
		+ "                  where cpd1.plot_code = cd.plot_code"
		+ "                    and :versionDt between cpd1.dt_insert and cpd1.dt_delete"
		+ "                    and :pointInTimeFrom <= cpd1.day_to"
		+ "                    and :pointInTimeTo >= cpd1.day_from"
		+ "              )"
		+ "       and :versionDt between cpd.dt_insert and cpd.dt_delete"
		+ "       and cd.plan_id = :cropPlanId"
		+ "       and :pointInTimeFrom <= cd.day_to"
		+ "       and :pointInTimeTo >= cd.day_from"
		+ "       and cpd.plot_code = cd.plot_code"
		+ "       and cpd.plan_id = cd.plan_id"
		+ "       and (select count(*) from crpl_plot_data_parcels cpdp1 where cpdp1.plot_data_id = cpd.id group by cpdp1.plot_data_id) = 1"
		+ "       and :versionDt between cd.dt_insert and cd.dt_delete"
		+ "       and cpdp.plot_data_id = cpd.id")
	@RegisterBeanMapper(ParcelCodeWithPointInTime.class)
	public List<ParcelCodeWithPointInTime> getDeclarationParcels(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
			@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo);

	@SqlQuery("select PLOT_CODE "
		+ "FROM CRPL_DECLARATIONS "
		+ "WHERE "
		+ "	PLAN_ID = :cropPlanId"
		+ "	AND DECL_CODE = :declCode")
	public String getPlotCode(@Bind("cropPlanId") Long cropPlanId,
			@Bind("declCode") String declCode);
	
	@SqlQuery("SELECT CASE WHEN t.declOfPlanFound >= 1 THEN 1 ELSE 0 END AS hasDeclarations"
			+ "  FROM ("
			+ "    select count(*) AS declOfPlanFound"
			+ "      from crpl_declarations decl, crpl_plot_data cpd"
			+ "     where decl.LAND_USE_CODE in (<landUseCodes>)"
			+ "       and :versionDt between decl.DT_INSERT and decl.DT_DELETE"
			+ "       and :pointInTime between decl.DAY_FROM and decl.DAY_TO"
			+ "       and decl.PLAN_ID = :cropPlanId"
			+ "       and cpd.plan_id = decl.plan_id"
			+ "       and cpd.plot_code = decl.plot_code"
			+ "       and :versionDt between cpd.DT_INSERT and cpd.DT_DELETE"
			+ "       and :pointInTime between cpd.DAY_FROM and cpd.DAY_TO ) t")
	@RegisterBeanMapper(PlanHasDeclarationsForLandUse.class)
	public PlanHasDeclarationsForLandUse getPlanHasDeclarationsForLandUse(@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTime") AbsoluteDate pointInTime,
			@BindList("landUseCodes") List<String> landUseCodes);

	@SqlQuery("select plot_code as plotCode,"
			+ "           decl_code as declCode,"
			+ "           land_use_code as landuse_code,"
			+ "           area_perc as areaPerc,"
			+ "           day_from as fromDate,"
			+ "           day_from_precision as fromDatePrecision,"
			+ "           day_to as toDate"
			+ "      from crpl_declarations"
			+ "     where plan_id = :cropPlanId"
			+ "       and plot_code in (<plotCodes>)"
			+ "       and :versionDt between dt_insert and dt_delete"
			+ "       and :pointInTimeFrom <= day_to"
			+ "       and :pointInTimeTo >= day_from"
			+ "  order by plot_code")
	@RegisterBeanMapper(DeclarationWithPlotCode.class)
	@RegisterBeanMapper(LandUse.class)
	public List<DeclarationWithPlotCode> getPlotsDeclarationsInternal(@Bind("cropPlanId") Long cropPlanId,
			@BindList("plotCodes") List<String> plotCodes, @Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom, @Bind("pointInTimeTo") AbsoluteDate pointInTimeTo);

	@SqlQuery("select plot_code as plotCode, "
			+ "           id as declId,"
			+ "           decl_code as declCode,"
			+ "           land_use_code as landuse_code,"
			+ "           area_perc as areaPerc,"
			+ "           day_from as fromDate,"
			+ "           day_from_precision as fromDatePrecision,"
			+ "           day_to as toDate"
			+ "      from crpl_declarations"
			+ "     where plan_id = :cropPlanId"
			+ "       and plot_code = :plotCode"
			+ "       and :versionDt between dt_insert and dt_delete"
			+ "       and :pointInTimeFrom <= day_to"
			+ "       and :pointInTimeTo >= day_from"
			+ "       and (:exclDeclCode is null or decl_code <> :exclDeclCode)")
	@RegisterBeanMapper(DeclarationWithPlotCode.class)
	@RegisterBeanMapper(LandUse.class)
	public List<DeclarationWithPlotCode> getPlotDeclarations(
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("plotCode") String plotCode,
			@Bind("exclDeclCode") String excludedDeclCode,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
			@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo);

	@SqlQuery("select id as declId,"
			+ "           decl_code as declCode,"
			+ "           plan_id as cropPlanId,"
			+ "           plot_code as plotCode,"
			+ "           day_from as dayFrom,"
			+ "           day_from_precision as dayFromPrecision,"
			+ "           day_to as dayTo,"
			+ "           land_use_code as landUseCode,"
			+ "           area_perc as areaPerc,"
			+ "           user_id_insert as insertUserId,"
			+ "           user_id_delete as deleteUserId,"
			+ "           dt_insert as insertDt,"
			+ "           dt_delete as deleteDt"
			+ "      from crpl_declarations"
			+ "     where plan_id = :cropPlanId"
			+ "       and plot_code = :plotCode"
			+ "       and :versionDt between dt_insert and dt_delete"
			+ "       and :pointInTimeFrom <= day_to"
			+ "       and :pointInTimeTo >= day_from")
	@RegisterBeanMapper(DeclarationData.class)
	public List<DeclarationData> getDeclarationDatas(@Bind("cropPlanId") Long cropPlanId,
			@Bind("plotCode") String plotCode, @Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom, @Bind("pointInTimeTo") AbsoluteDate pointInTimeTo);

	@SqlQuery("select plot_code as plotCode,"
			+ "           id as declId,"
			+ "           decl_code as declCode,"
			+ "           land_use_code as landuse_code,"
			+ "           area_perc as areaPerc,"
			+ "           day_from as fromDate,"
			+ "           day_from_precision as fromDatePrecision,"
			+ "           day_to as toDate"
			+ "      from crpl_declarations"
			+ "     where id = :declId")
	@RegisterBeanMapper(DeclarationWithPlotCode.class)
	@RegisterBeanMapper(LandUse.class)
	public DeclarationWithPlotCode getDeclaration(@Bind("declId") Long declId);

	@SqlQuery("select plot_code as plotCode,"
			+ "           id as declId,"
			+ "           decl_code as declCode,"
			+ "           land_use_code as landuse_code,"
			+ "           area_perc as areaPerc,"
			+ "           day_from as fromDate,"
			+ "           day_from_precision as fromDatePrecision,"
			+ "           day_to as toDate"
			+ "      from crpl_declarations"
			+ "     where plan_id = :cropPlanId"
			+ "       and plot_code = :plotCode"
			+ "       and :versionDt between dt_insert and dt_delete"
			+ "       and decl_code = :declCode")
	@RegisterBeanMapper(DeclarationWithPlotCode.class)
	@RegisterBeanMapper(LandUse.class)
	public DeclarationWithPlotCode getDeclarationByDeclCode(@Bind("cropPlanId") Long cropPlanId,
			@Bind("plotCode") String plotCode, @Bind("versionDt") LocalDateTime versionDt,
			@Bind("declCode") String declCode);

	@SqlQuery("SELECT count(*) \n"
			+ "  FROM CRPL_PLOT_DATA cpd, \n"
			+ "       CRPL_DECLARATIONS cd, \n"
			+ "       CRPL_PERM_CROP_FORMS cpcf \n"
			+ " WHERE cpd.PLAN_ID = :cropPlanId "
			+ "   AND cpd.PLOT_CODE = :plotCode \n"
			+ "   AND :pointInTime between cpd.day_from and cpd.day_to \n"
			+ "   AND :versionDt BETWEEN cpd.DT_INSERT AND cpd.DT_DELETE \n"
			+ "   AND cd.PLAN_ID = cpd.PLAN_ID \n"
			+ "   AND cd.PLOT_CODE = cpd.PLOT_CODE \n"
			+ "   AND :versionDt BETWEEN cd.DT_INSERT AND cd.DT_DELETE \n"
			+ "   AND cd.DAY_FROM < :declPointInTimeTo \n"
			+ "   AND cd.day_to > :declPointInTimeFrom \n"
			+ "   AND cpcf.PLAN_ID = cd.PLAN_ID \n"
			+ "   AND cpcf.PLOT_CODE = cd.PLOT_CODE \n"
			+ "   and cpcf.DECL_CODE = cd.DECL_CODE \n"
			+ "   AND :versionDt BETWEEN cpcf.DT_INSERT AND cpcf.DT_DELETE \n"
			+ "   and cpcf.external_code in (<externalCodes>)")
	public Integer getExternalCodeCount(@Bind("cropPlanId") Long cropPlanId,
			@Bind("plotCode") String plotCode, @Bind("versionDt") LocalDateTime versionDt, @Bind("pointInTime") AbsoluteDate pointInTime,
			@Bind("declPointInTimeFrom") AbsoluteDate declPointInTimeFrom, @Bind("declPointInTimeTo") AbsoluteDate declPointInTimeTo,
			@BindList("externalCodes") List<String> externalCodes);

	@SqlQuery("     SELECT cp.DOMAIN_ZONE_ID as domainZoneId, "
			+ "            null as domainZoneDescription, "
			+ "            cp.plot_code as plotCode "
			+ "       FROM CRPL_PLOTS cp "
			+ " INNER JOIN CRPL_PLOT_DATA cpd "
			+ "         ON cp.PLOT_CODE = cpd.PLOT_CODE AND "
			+ "            cp.PLAN_ID = cpd.PLAN_ID AND "
			+ "            :pointInTime BETWEEN cpd.DAY_FROM AND cpd.DAY_TO AND "
			+ "            :versionDt BETWEEN cpd.DT_INSERT AND cpd.DT_DELETE "
			+ " INNER JOIN CRPL_DECLARATIONS cd "
			+ "         ON cpd.PLOT_CODE = cd.PLOT_CODE AND "
			+ "            cpd.PLAN_ID = cd.PLAN_ID AND "
			+ "            :pointInTime BETWEEN cd.DAY_FROM AND cd.DAY_TO AND "
			+ "            :versionDt BETWEEN cd.DT_INSERT AND cd.DT_DELETE "
			+ "      WHERE (cp.DOMAIN_ZONE_ID = coalesce(<domainZoneIds>, cp.DOMAIN_ZONE_ID) or cp.DOMAIN_ZONE_ID in (<domainZoneIds>)) AND "
			+ "            cp.PLAN_ID = :cropPlanId "
			+ "   GROUP BY cp.domain_zone_id, cp.plot_code "
			+ "   ORDER BY cp.domain_zone_id, cp.plot_code")
	@RegisterBeanMapper(PlotDeclRotationDto.class)
	ResultIterator<PlotDeclRotationDto> getPlotWithDeclarationsInPointInTimeByCropPlanIdAndDomainZoneIdsAndVersionDt(
			@Bind("cropPlanId") Long cropPlanId,
			@BindList(value = "domainZoneIds", onEmpty = BindList.EmptyHandling.NULL_STRING) List<String> domainZoneIds,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTime") AbsoluteDate pointInTime);

	@SqlQuery("    SELECT cp.plot_code as plotCode, "
			+ "           cd.id as declId, "
			+ "           cd.decl_code as declCode, "
			+ "           cd.area_perc as areaPerc, "
			+ "           cd.area_perc * cpd.area_sqm / 100 as declAreaSqm, "
			+ "           cd.land_use_code as lu_code, "
			+ "           cd.day_from as dayFrom, "
			+ "           cd.day_from_precision as dayFromPrecision, "
			+ "           cd.day_to as dayTo "
			+ "      FROM CRPL_PLOTS cp "
			+ "INNER JOIN CRPL_PLOT_DATA cpd "
			+ "        ON cp.PLOT_CODE = cpd.PLOT_CODE AND "
			+ "           cp.PLAN_ID = cpd.PLAN_ID AND "
			+ "           (:versionDt BETWEEN cpd.DT_INSERT AND cpd.DT_DELETE) AND "
			+ "           :pointInTimeFrom <= cpd.day_to AND "
			+ "           :pointInTimeTo >= cpd.day_from "
			+ "INNER JOIN CRPL_DECLARATIONS cd "
			+ "        ON cpd.PLOT_CODE = cd.PLOT_CODE AND "
			+ "           cpd.PLAN_ID = cd.PLAN_ID AND "
			+ "           (:versionDt BETWEEN cd.DT_INSERT AND cd.DT_DELETE) AND "
			+ "           :pointInTimeFrom <= cd.day_to AND "
			+ "           :pointInTimeTo >= cd.day_from "
			+ "     WHERE cp.PLAN_ID = :cropPlanId AND "
			+ "           cp.plot_code in (<plotCodes>) "
			+ "  ORDER BY cp.plot_code, cd.day_from")
	@RegisterBeanMapper(DeclRotationDto.class)
	@RegisterBeanMapper(LandUse.class)
	List<DeclRotationDto> getPlotCodesDeclsByCropPlanAndVersion(
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTimeFrom") AbsoluteDate pointInTimeFrom,
			@Bind("pointInTimeTo") AbsoluteDate pointInTimeTo,
			@BindList("plotCodes") List<String> plotCodes);

	@SqlQuery("    SELECT cp.plot_code as plotCode, "
			+ "           cd.id as declId, "
			+ "           cd.decl_code as declCode, "
			+ "           cd.area_perc as areaPerc, "
			+ "           cd.area_perc * cpd.area_sqm / 100 as declAreaSqm, "
			+ "           cd.land_use_code as lu_code, "
			+ "           cd.day_from as dayFrom, "
			+ "           cd.day_from_precision as dayFromPrecision, "
			+ "           cd.day_to as dayTo "
			+ "      FROM CRPL_PLOTS cp "
			+ "INNER JOIN CRPL_PLOT_DATA cpd "
			+ "        ON cp.PLOT_CODE = cpd.PLOT_CODE AND "
			+ "           cp.PLAN_ID = cpd.PLAN_ID AND "
			+ "           (:versionDt BETWEEN cpd.DT_INSERT AND cpd.DT_DELETE) AND "
			+ "           :pointInTime BETWEEN cpd.DAY_FROM AND cpd.DAY_TO "
			+ "INNER JOIN CRPL_DECLARATIONS cd "
			+ "        ON cpd.PLOT_CODE = cd.PLOT_CODE AND "
			+ "           cpd.PLAN_ID = cd.PLAN_ID AND "
			+ "           (:versionDt BETWEEN cd.DT_INSERT AND cd.DT_DELETE) AND "
			+ "           :pointInTime BETWEEN cd.DAY_FROM AND cd.DAY_TO "
			+ "     WHERE cp.DOMAIN_ZONE_ID IN (<domainZoneIds>) AND "
			+ "           cp.PLAN_ID = :cropPlanId AND "
			+ "           cd.land_use_code in (<landUseCodes>) "
			+ "  ORDER BY cp.plot_code, cd.day_from")
	@RegisterBeanMapper(DeclRotationDto.class)
	@RegisterBeanMapper(LandUse.class)
	List<DeclRotationDto> getPlotCodesDeclsByCropPlanAndDomainZoneIdsAndLandUseCodes(
			@Bind("cropPlanId") Long cropPlanId,
			@Bind("versionDt") LocalDateTime versionDt,
			@Bind("pointInTime") AbsoluteDate pointInTime,
			@BindList("domainZoneIds") List<String> domainZoneIds,
			@BindList("landUseCodes") List<String> landUseCodes);
}
