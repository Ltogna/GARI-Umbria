package com.abacogroup.cropplan.services;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

import com.abacogroup.cropplan.api.CommonAdditionalDataAndPermanentCropFormConfigs;
import com.abacogroup.cropplan.api.LandUseAdditFieldsWithValuesReadDto;
import com.abacogroup.cropplan.api.LandUseCommonAdditFieldsWithValuesReadDto;
import com.abacogroup.cropplan.db.dao.CropPlanConfigDAO;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.ntt.PermanentCropFormConfigWithFields;
import com.abacogroup.cropplan.exceptions.LandUseCodeNotFoundException;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.dtos.LandUseCommonConfigAndValuesDto;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataConf;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseClass;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUseDetails;
import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormConfig;
import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormFieldConfig;
import com.abacogroup.cropplan.sdk.model.cropcodes.PermanentCropFormType;
import com.abacogroup.cropplan.sdk.spi.CropCodesPlugin;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.MaxRowsResults;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import jakarta.ws.rs.BadRequestException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class CropCodeService {

	private final CropPlanConfigService cropPlanConfigService;
	private final PluginManager pluginManager;
	private final CropPlansDAO cropPlansDAO;
	private final CropPlanConfigDAO cropPlanConfigDAO;
	// private static final Logger log = LoggerFactory.getLogger(CropCodeService.class);

	// List of common field to exclude from getPermanentCropFormConfigCommonFieldCodes method
	// This list of values could change over time or removed
	// Need to sync with FE before changing or remove this values
	private final static Set<String> commonConfigsToExclude = Set.of("STUMPS_NUMBER", "STUMPS_DENSITY_100");

	public CropCodeService(CropPlanConfigService cropPlanConfigService,
			PluginManager pluginManager, DAOContainer daocontainer) {
		this.cropPlanConfigService = cropPlanConfigService;
		this.pluginManager = pluginManager;
		this.cropPlansDAO = daocontainer.getCropPlansDAO();
		this.cropPlanConfigDAO = daocontainer.getCropPlanConfigDAO();
	}

	public MaxRowsResults<LandUseDetails> getLandUseCodesMaxRows(RuntimeEnvironment env, String businessId, Long cropPlanId, List<String> landCoverCodes,
			String search, AbsoluteDate pointInTime) {
		var cropPlan = cropPlansDAO.getCropPlanInternal(businessId, cropPlanId, env.getTenantId());
		var favouriteLandUseCodes = cropPlansDAO.getFavouriteLandUses(env.getUserId(), cropPlan.getCropPlanTypeCode(), env.getTenantId());
		var ret = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId())
				.getLandUseCodesMaxRows(env, businessId, landCoverCodes, search, favouriteLandUseCodes,
						cropPlanConfigService.getSnapFromDate(cropPlanId, pointInTime).toLocalDate(), cropPlanConfigService.isIgnoreLandUseCompatibility(cropPlanId));
		fillLandUseClasses(env, cropPlan.getCropPlanTypeCode(), ret.getRecords(), pointInTime);
		return ret;
	}

	public InfiniteListResults<LandUseDetails> getLandUseCodesInfinite(RuntimeEnvironment env, String businessId, Long cropPlanId, List<String> landCoverCodes,
			String search, AbsoluteDate pointInTime, String nextKey) {
		var cropPlan = cropPlansDAO.getCropPlanInternal(businessId, cropPlanId, env.getTenantId());
		var favouriteLandUseCodes = cropPlansDAO.getFavouriteLandUses(env.getUserId(), cropPlan.getCropPlanTypeCode(), env.getTenantId());
		var ret = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId())
				.getLandUseCodesInfinite(env, businessId, landCoverCodes, search, favouriteLandUseCodes,
						cropPlanConfigService.getSnapFromDate(cropPlanId, pointInTime).toLocalDate(), cropPlanConfigService.isIgnoreLandUseCompatibility(cropPlanId),
						nextKey);
		fillLandUseClasses(env, cropPlan.getCropPlanTypeCode(), ret.getRecords(), pointInTime);
		return ret;
	}

	public InfiniteListResults<LandUseDetails> getCropPlanTypeCodeLandUseCodes(RuntimeEnvironment env, String businessId, String cropPlanTypeCode,
			List<String> landCoverCodes, String search, AbsoluteDate pointInTime, String nextKey) {
		var cropPlans = cropPlansDAO.infinite(() -> cropPlansDAO.getCropPlansInternal(businessId, cropPlanTypeCode, null,
				env.getTenantId(), env.getLocale().getLanguage()), null, 1);
		var cropPlan = cropPlans.getCount() > 0 ? cropPlans.getRecords().get(0) : null;
		var favouriteLandUseCodes = cropPlansDAO.getFavouriteLandUses(env.getUserId(), cropPlanTypeCode, env.getTenantId());
		var ret = pluginManager.getCropCodesPlugin(env, cropPlanTypeCode)
				.getLandUseCodesInfinite(env, businessId, landCoverCodes, search, favouriteLandUseCodes,
						(cropPlan != null ? cropPlanConfigService.getSnapFromDate(cropPlan.getCropPlanId(), pointInTime).toLocalDate() : pointInTime.toLocalDate()), false,
						nextKey);
		fillLandUseClasses(env, cropPlanTypeCode, ret.getRecords(), pointInTime);
		return ret;
	}

	/**
	 * Based on the params given, use the configured plugin to transcode the landuse over the campaigns, business or everithing in the plugin
	 */
	public String transcodeLandUseCode(RuntimeEnvironment env, String businessId, Long cropPlanId, String code, String landCoverCode,
			AbsoluteDate pointInTime) {

		return (pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId()))
				.transcodeLandUseCode(env, code, landCoverCode, businessId, cropPlanConfigService.getSnapFromDate(cropPlanId, pointInTime).toLocalDate())
				.orElse(code);

	}

	// TODO documentare LandUseCodeNotFoundException in chi la chiama
	public LandUseDetails getLandUseCode(RuntimeEnvironment env, String businessId, Long cropPlanId, String code, List<String> landCoverCodes,
			AbsoluteDate pointInTime) {
		var luc = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId())
				.getLandUseCode(env, code, businessId, cropPlanConfigService.getSnapFromDate(cropPlanId, pointInTime).toLocalDate())
				.orElseThrow(() -> new LandUseCodeNotFoundException(code));
		var cropPlan = cropPlansDAO.getCropPlanInternal(businessId, cropPlanId, env.getTenantId());
		var favouriteLandUseCodes = cropPlansDAO.getFavouriteLandUses(env.getUserId(), cropPlan.getCropPlanTypeCode(), env.getTenantId());
		luc.setIsFavourite(favouriteLandUseCodes.contains(luc.getCode()));
		fillLandUseClasses(env, cropPlan.getCropPlanTypeCode(), List.of(luc), pointInTime);
		if (landCoverCodes != null && !landCoverCodes.isEmpty()) {
			for (String lcc : landCoverCodes) {
				if (isLandUseCompatible(env, businessId, cropPlanId, code, lcc)) {
					return luc;
				}
			}
			return null;
		} else {
			return luc;
		}
	}

	public CommonAdditionalDataAndPermanentCropFormConfigs getCommonLandUseAndPermanentCropFormConfigsByLandUseCodes(RuntimeEnvironment env, String businessId,
			Long cropPlanId, LandUseCommonConfigAndValuesDto landUseCommonConfigAndValuesDto, AbsoluteDate pointInTime) {
		// Avoid issue from FE about duplicated land use codes
		List<String> uniqueListOfLandUseCodes = landUseCommonConfigAndValuesDto.getLandUseCodes().stream().distinct().collect(toList());
		// Retrieve land use detail data for land use codes
		List<LandUseDetails> landUseDetails = getLandUseDetailsByLandUseCodes(env, businessId, cropPlanId, uniqueListOfLandUseCodes, pointInTime);

		// If is not possible to find land use details for all land use codes then will return empty results
		if (uniqueListOfLandUseCodes.size() != landUseDetails.size()) {
			return new CommonAdditionalDataAndPermanentCropFormConfigs(new ArrayList<>(), new ArrayList<>());
		}

		List<PermanentCropFormConfig> commonPermanentCropFormValues = getCommonPermanentCropFormValues(env, businessId, cropPlanId, landUseDetails, pointInTime);
		List<LandUseAdditionalDataConf> landUseAdditionalDataConfigs = getCommonLandUseAdditionalDataConfigs(env, landUseDetails, pointInTime);

		return new CommonAdditionalDataAndPermanentCropFormConfigs(landUseAdditionalDataConfigs, commonPermanentCropFormValues);
	}

	private List<LandUseDetails> getLandUseDetailsByLandUseCodes(RuntimeEnvironment env, String businessId,
			Long cropPlanId, List<String> landUseCodes, AbsoluteDate pointInTime) {
		CropCodesPlugin cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId());

		List<LandUseDetails> landUseDetails = new ArrayList<>();

		for (String landUseCode : landUseCodes) {
			Optional<LandUseDetails> landUseDetail = cropCodesPlugin.getLandUseCode(env, landUseCode, businessId, pointInTime.toLocalDate());

			if (landUseDetail.isEmpty()) {
				continue;
			}

			landUseDetails.add(landUseDetail.get());
		}

		return landUseDetails;
	}

	private List<PermanentCropFormConfig> getCommonPermanentCropFormValues(RuntimeEnvironment env, String businessId,
			Long cropPlanId, List<LandUseDetails> landUseDetails, AbsoluteDate pointInTime) {
		var cropPlan = cropPlansDAO.getCropPlanInternal(businessId, cropPlanId,
				env.getTenantId());

		// Safety net, this should never happen
		if (cropPlan == null) {
			throw new BadRequestException("The crop plan was not found");
		}

		// Create lists of unique land use codes and land use class code
		List<String> landUseCodes = landUseDetails.stream().map(LandUse::getCode).distinct().collect(toList());
		List<String> landUseClassCodes = landUseDetails.stream().map(el -> el.getLandUseClass().getLandUseClassCode()).distinct().collect(toList());

		List<PermanentCropFormConfigWithFields> completeListOfPcfConfigsToProcess = cropPlanConfigDAO.getPermanentCropFormsConfigByLandUseCodeAndByLandUseClassCode(
				env.getTenantId(), cropPlan.getCropPlanTypeCode(), landUseCodes, landUseClassCodes, pointInTime);

		// If no configs has be found, return empty list
		if (completeListOfPcfConfigsToProcess.isEmpty()) {
			return new ArrayList<>();
		}

		Map<PermanentCropFormType, Set<String>> commonFlMandatoryFieldCodesByFormType = getPermanentCropFormConfigsWithSameNullableValuesByFormType(completeListOfPcfConfigsToProcess);
		List<PermanentCropFormConfigWithFields> filteredMandatoryConfigList = completeListOfPcfConfigsToProcess.stream()
				.filter(a -> commonFlMandatoryFieldCodesByFormType.getOrDefault(a.getFormType(), Collections.emptySet())
						.contains(a.getFieldCode()))
				.collect(Collectors.toList());

		// Create Map with LandUseCode as key value is another map
		// The second map has key as form type and value the set of fieldCode
		// To this is the final hierarchy -> LandUseCode/FormType/FieldCodes
		Map<String, Map<PermanentCropFormType, Set<String>>> landUseCodeMap = new HashMap<>();

		// Group Configs by LandUseCode
		Map<String, List<PermanentCropFormConfigWithFields>> configsByLandUseCode = filteredMandatoryConfigList.stream()
				.filter(el -> el.getLand_use_code() != null)
				.collect(Collectors.groupingBy(PermanentCropFormConfigWithFields::getLand_use_code));

		// Group Configs by LandUseClassCode
		Map<String, List<PermanentCropFormConfigWithFields>> configsByLandUseClassCode = filteredMandatoryConfigList.stream()
				.filter(el -> el.getLand_use_class_code() != null)
				.collect(Collectors.groupingBy(PermanentCropFormConfigWithFields::getLand_use_class_code));

		// For every land use detail find his configs and his class configs
		for (LandUseDetails landUseDetail : landUseDetails) {
			List<PermanentCropFormConfigWithFields> landUseDetailConfigs = new ArrayList<>();
			landUseDetailConfigs.addAll(configsByLandUseCode.getOrDefault(landUseDetail.getCode(), Collections.emptyList()));
			landUseDetailConfigs.addAll(configsByLandUseClassCode.getOrDefault(landUseDetail.getLandUseClass().getLandUseClassCode(), Collections.emptyList()));

			// Populate the map defined above
			for (PermanentCropFormConfigWithFields item : landUseDetailConfigs) {
				landUseCodeMap
						.computeIfAbsent(landUseDetail.getCode(), k -> new HashMap<>())
						.computeIfAbsent(item.getFormType(), k -> new HashSet<>())
						.add(item.getFieldCode());
			}

			if (landUseDetailConfigs.isEmpty()) {
				landUseCodeMap.putIfAbsent(landUseDetail.getCode(), new HashMap<>());
			}
		}

		// Retrieve common form types for all land use codes
		Set<PermanentCropFormType> commonFormTypes = landUseCodeMap.values().stream()
				.map(Map::keySet)
				.reduce((set1, set2) -> {
					set1.retainAll(set2);
					return set1;
				})
				.orElse(Collections.emptySet());

		// If there are no common form types, return empty list
		if (commonFormTypes.isEmpty()) {
			return Collections.emptyList();
		}

		// Get common field codes for every form type
		return commonFormTypes.stream()
				.map(formType -> getPermanentCropFormCommonConfig(formType, getPermanentCropFormConfigCommonFieldCodes(landUseCodeMap, formType)))
				.collect(Collectors.toList());
	}

	private Map<PermanentCropFormType, Set<String>> getPermanentCropFormConfigsWithSameNullableValuesByFormType(List<PermanentCropFormConfigWithFields> permanentCropFromConfigs) {
		Map<PermanentCropFormType, Map<String, Set<Boolean>>> possibleMandatoryValuesOnConfigsByFormTypeMap = new HashMap<>();

		permanentCropFromConfigs.forEach(el ->
				possibleMandatoryValuesOnConfigsByFormTypeMap.computeIfAbsent(el.getFormType(), k -> new HashMap<>())
						.computeIfAbsent(el.getFieldCode(), k -> new HashSet<>())
						.add(el.isFlMandatory())
		);

		return possibleMandatoryValuesOnConfigsByFormTypeMap.entrySet().stream()
				.collect(Collectors.toMap(
						Map.Entry::getKey,
						e -> e.getValue().entrySet().stream()
								.filter(entry -> entry.getValue().size() == 1)
								.map(Map.Entry::getKey)
								.collect(Collectors.toSet())
				));
	}

	private static Set<String> getPermanentCropFormConfigCommonFieldCodes(Map<String, Map<PermanentCropFormType, Set<String>>> landUseCodeMap,
			PermanentCropFormType formType) {
		Set<String> commonConfigFieldCodes = landUseCodeMap.values().stream()
				.map(formTypeMap -> formTypeMap.getOrDefault(formType, Collections.emptySet()))
				.reduce((set1, set2) -> {
					set1.retainAll(set2);
					return set1;
				})
				.orElse(Collections.emptySet());

		// This produce side effect on commonConfigFieldCodes set, will remove common field to remove commonConfigFieldCodes
		commonConfigFieldCodes.removeAll(commonConfigsToExclude);

		return commonConfigFieldCodes;
	}

	private static PermanentCropFormConfig getPermanentCropFormCommonConfig(PermanentCropFormType formType, Set<String> fieldCodes) {
		PermanentCropFormConfig permanentCropFormConfig = new PermanentCropFormConfig();
		permanentCropFormConfig.setFormType(formType);

		List<PermanentCropFormFieldConfig> fieldConfigs = fieldCodes.stream()
				.map(fieldCode -> {
					PermanentCropFormFieldConfig fieldConfig = new PermanentCropFormFieldConfig();
					fieldConfig.setFieldCode(fieldCode);
					fieldConfig.setFlEditable(true);
					fieldConfig.setFlMandatory(false);
					return fieldConfig;
				})
				.collect(Collectors.toList());

		permanentCropFormConfig.setFields(fieldConfigs);
		return permanentCropFormConfig;
	}

	public List<LandUseAdditionalDataConf> getCommonLandUseAdditionalDataConfigs(RuntimeEnvironment env,
			List<LandUseDetails> landUseWithDetails, AbsoluteDate pointInTime) {
		List<String> uniqueListOfLandUseCodes = landUseWithDetails.stream().map(LandUse::getCode).collect(toList());

		List<LandUseAdditFieldsWithValuesReadDto> landUseAdditFieldsWithValuesByLandUseCodeList = new ArrayList<>();

		for (String lu : uniqueListOfLandUseCodes) {
			// this retrieve land use code addit fields and common addit fields config by the same land use code structure
			landUseAdditFieldsWithValuesByLandUseCodeList.addAll(cropPlansDAO.getLandUseConfigWithValuesAndDefaultByLandUseCodeList(
					env.getTenantId(), env.getLocale().getLanguage(), lu, pointInTime));
		}

		List<String> uniqueListOfLandUseCodeWithValues = landUseAdditFieldsWithValuesByLandUseCodeList.stream().map(
				LandUseAdditFieldsWithValuesReadDto::getLandUseCode).distinct().collect(toList());

		// This is needed to prevent issue if some landUseCodes hasn't configs set
		if (uniqueListOfLandUseCodeWithValues.size() != uniqueListOfLandUseCodes.size()) {
			return new ArrayList<>();
		}

		Set<String> landUseCodesCommonFieldCodes = findCommonFieldCodesByLandUseCodes(landUseAdditFieldsWithValuesByLandUseCodeList);

		Map<String, List<String>> commonFieldCodesValues = findCommonFieldCodeValues(landUseAdditFieldsWithValuesByLandUseCodeList,
				landUseCodesCommonFieldCodes);

		List<LandUseAdditFieldsWithValuesReadDto> commonLandUseAdditFieldsWithValues = landUseAdditFieldsWithValuesByLandUseCodeList.stream()
				.filter(dto -> {
					String fieldCode = dto.getFieldCode();
					String value = dto.getValue();
					return commonFieldCodesValues.containsKey(fieldCode) && commonFieldCodesValues.get(fieldCode).contains(value);
				})
				.collect(toList());

		// Remove landUseCode field, and group up values
		List<LandUseCommonAdditFieldsWithValuesReadDto> landUseCommonAdditionalFieldsWithValuesReadDtos = mapToCommonAdditFieldsWithValues(
				commonLandUseAdditFieldsWithValues);

		List<LandUseAdditionalDataConf> landUseAdditionalDataConfigs = new ArrayList<>();

		for (String fieldCode : landUseCodesCommonFieldCodes) {
			List<LandUseCommonAdditFieldsWithValuesReadDto> fieldCodeWithValues = landUseCommonAdditionalFieldsWithValuesReadDtos.stream()
					.filter(el -> el.getFieldCode().equals(fieldCode)).collect(toList());
			// The LandUseCommonAdditFieldsWithValuesReadDto contain all the data that i need, but i need to split in different dtos (LandUseAdditionalDataConf,
			// that contain a list of LandUseAdditionalDataField). So i need to map data in the correct way.
			landUseAdditionalDataConfigs.add(mapToLandUseAdditionalDataConf(fieldCodeWithValues.get(0), fieldCodeWithValues));
		}

		return landUseAdditionalDataConfigs.stream().sorted(Comparator.comparing(LandUseAdditionalDataConf::getSortOrder)).collect(toList());
	}

	private LandUseAdditionalDataConf mapToLandUseAdditionalDataConf(LandUseCommonAdditFieldsWithValuesReadDto landUseCommonAdditFieldsWithValuesReadDto,
			List<LandUseCommonAdditFieldsWithValuesReadDto> landUseCommonAdditFieldsWithValuesReadDtos) {
		LandUseAdditionalDataConf landUseAdditionalDataConf = new LandUseAdditionalDataConf();

		Optional<LandUseCommonAdditFieldsWithValuesReadDto> defaultValue = landUseCommonAdditFieldsWithValuesReadDtos.stream()
				.filter(el -> el.getFlDefault() == 1).findFirst();

		landUseAdditionalDataConf.setLandUseCode(null);
		landUseAdditionalDataConf.setLandUseDescription(null);
		landUseAdditionalDataConf.setFieldCode(landUseCommonAdditFieldsWithValuesReadDto.getFieldCode());
		landUseAdditionalDataConf.setFieldDescription(landUseCommonAdditFieldsWithValuesReadDto.getFieldDescription());
		landUseAdditionalDataConf.setFieldType(landUseCommonAdditFieldsWithValuesReadDto.getFieldType());
		landUseAdditionalDataConf.setValidFrom(landUseCommonAdditFieldsWithValuesReadDto.getValidFrom());
		landUseAdditionalDataConf.setValidTo(landUseCommonAdditFieldsWithValuesReadDto.getValidTo());
		landUseAdditionalDataConf.setSortOrder(landUseCommonAdditFieldsWithValuesReadDto.getSortOrder());
		landUseAdditionalDataConf.setDefaultValue(defaultValue.<Object>map(LandUseCommonAdditFieldsWithValuesReadDto::getValue).orElse(null));
		landUseAdditionalDataConf.setNullable(landUseCommonAdditFieldsWithValuesReadDto.getNullable());
		landUseAdditionalDataConf.setAllowedValues(mapToLandUseAdditionalDataField(landUseCommonAdditFieldsWithValuesReadDtos));
		landUseAdditionalDataConf.setGroupCode(landUseCommonAdditFieldsWithValuesReadDto.getGroupCode());
		landUseAdditionalDataConf.setHeaderTitleCode(landUseCommonAdditFieldsWithValuesReadDto.getHeaderTitleCode());
		landUseAdditionalDataConf.setHeaderTitleDescription(landUseCommonAdditFieldsWithValuesReadDto.getHeaderTitleDescription());
		landUseAdditionalDataConf.setFlEditable(landUseCommonAdditFieldsWithValuesReadDto.getFlEditable());
		landUseAdditionalDataConf.setFormula(landUseCommonAdditFieldsWithValuesReadDto.getFormula());

		return landUseAdditionalDataConf;
	}

	private List<LandUseAdditionalDataField> mapToLandUseAdditionalDataField(
			List<LandUseCommonAdditFieldsWithValuesReadDto> landUseCommonAdditFieldsWithValuesReadDtos) {
		List<LandUseAdditionalDataField> landUseAdditionalDataFields = new ArrayList<>();

		for (LandUseCommonAdditFieldsWithValuesReadDto landUseCommonAdditFieldsWithValuesReadDto : landUseCommonAdditFieldsWithValuesReadDtos) {
			LandUseAdditionalDataField landUseAdditionalDataField = new LandUseAdditionalDataField();

			landUseAdditionalDataField.setDeclCode(null);
			landUseAdditionalDataField.setFieldCode(landUseCommonAdditFieldsWithValuesReadDto.getFieldCode());
			landUseAdditionalDataField.setFieldDescription(landUseCommonAdditFieldsWithValuesReadDto.getFieldDescription());
			landUseAdditionalDataField.setDayFrom(landUseCommonAdditFieldsWithValuesReadDto.getDayFrom());
			landUseAdditionalDataField.setDayTo(landUseCommonAdditFieldsWithValuesReadDto.getDayTo());
			landUseAdditionalDataField.setSortOrder(landUseCommonAdditFieldsWithValuesReadDto.getValueSortOrder());
			landUseAdditionalDataField.setValue(landUseCommonAdditFieldsWithValuesReadDto.getValue());
			landUseAdditionalDataField.setValueDescription(landUseCommonAdditFieldsWithValuesReadDto.getValueDescription());
			landUseAdditionalDataField.setFlShowInTooltip(false);

			landUseAdditionalDataFields.add(landUseAdditionalDataField);
		}

		return landUseAdditionalDataFields;
	}

	private static Set<String> findCommonFieldCodesByLandUseCodes(List<LandUseAdditFieldsWithValuesReadDto> landUseConfigList) {
		Map<String, Set<Boolean>> fieldCodeWithPossibleNullableValues = new HashMap<>();
		Map<String, Set<String>> landUseCodeToFieldCodesMap = new HashMap<>();

		for (LandUseAdditFieldsWithValuesReadDto config : landUseConfigList) {
			fieldCodeWithPossibleNullableValues
					.computeIfAbsent(config.getFieldCode(), k -> new HashSet<>())
					.add(config.getNullable());
		}

		Set<String> validFieldCodes = fieldCodeWithPossibleNullableValues.entrySet().stream()
				.filter(entry -> entry.getValue().size() == 1)
				.map(Map.Entry::getKey)
				.collect(Collectors.toSet());

		for (LandUseAdditFieldsWithValuesReadDto config : landUseConfigList) {
			if (validFieldCodes.contains(config.getFieldCode())) {
				landUseCodeToFieldCodesMap
						.computeIfAbsent(config.getLandUseCode(), k -> new HashSet<>())
						.add(config.getFieldCode());
			}
		}

		return landUseCodeToFieldCodesMap.values().stream()
				.reduce((set1, set2) -> {
					set1.retainAll(set2);
					return set1;
				}).orElse(Collections.emptySet());
	}

	private static Map<String, List<String>> findCommonFieldCodeValues(List<LandUseAdditFieldsWithValuesReadDto> landUseConfigWithValuesByLandUseCodeList,
			Set<String> commonFieldCodes) {
		List<LandUseAdditFieldsWithValuesReadDto> commonLandUseConfigs = landUseConfigWithValuesByLandUseCodeList.stream()
				.filter(dto -> commonFieldCodes.contains(dto.getFieldCode()))
				.collect(Collectors.toList());

		Map<String, List<String>> commonConfigAndFieldValues = new HashMap<>();

		for (String fieldCode : commonFieldCodes) {
			List<String> possibleValuesForFieldCode = commonLandUseConfigs.stream()
					.filter(dto -> dto.getFieldCode().equals(fieldCode))
					.map(LandUseAdditFieldsWithValuesReadDto::getValue)
					.distinct()
					.collect(Collectors.toList());

			List<String> currentFieldCodeCommonValues = commonLandUseConfigs.stream()
					.filter(dto -> dto.getFieldCode().equals(fieldCode))
					.map(LandUseAdditFieldsWithValuesReadDto::getLandUseCode)
					.distinct()
					.map(landUseCode -> commonLandUseConfigs.stream()
							.filter(dto -> dto.getFieldCode().equals(fieldCode) && dto.getLandUseCode().equals(landUseCode))
							.map(LandUseAdditFieldsWithValuesReadDto::getValue)
							.collect(Collectors.toList()))
					.reduce(possibleValuesForFieldCode, (list1, list2) -> {
						list1.retainAll(list2);
						return list1;
					});

			if (!currentFieldCodeCommonValues.isEmpty()) {
				commonConfigAndFieldValues.put(fieldCode, currentFieldCodeCommonValues);
			}
		}

		return commonConfigAndFieldValues;
	}

	private static List<LandUseCommonAdditFieldsWithValuesReadDto> mapToCommonAdditFieldsWithValues(
			List<LandUseAdditFieldsWithValuesReadDto> landUseConfigWithValuesFiltered) {
		return landUseConfigWithValuesFiltered.stream()
				.map(dto -> {
					LandUseCommonAdditFieldsWithValuesReadDto commonDto = new LandUseCommonAdditFieldsWithValuesReadDto();
					commonDto.setFieldCode(dto.getFieldCode());
					commonDto.setFieldDescription(dto.getFieldDescription());
					commonDto.setFieldType(dto.getFieldType());
					commonDto.setValidFrom(dto.getValidFrom());
					commonDto.setValidTo(dto.getValidTo());
					commonDto.setSortOrder(dto.getSortOrder());
					commonDto.setNullable(dto.getNullable());
					commonDto.setGroupCode(dto.getGroupCode());
					commonDto.setHeaderTitleCode(dto.getHeaderTitleCode());
					commonDto.setHeaderTitleDescription(dto.getHeaderTitleDescription());
					commonDto.setFlEditable(dto.getFlEditable());
					commonDto.setFormula(dto.getFormula());
					commonDto.setDayFrom(dto.getDayFrom());
					commonDto.setDayTo(dto.getDayTo());
					commonDto.setFlDefault(dto.getFlDefault());
					commonDto.setValueSortOrder(dto.getValueSortOrder());
					commonDto.setValue(dto.getValue());
					commonDto.setValueDescription(dto.getValueDescription());
					return commonDto;
				})
				.distinct()
				.collect(Collectors.toList());
	}

	public List<LandUseAdditionalDataConf> getLandUseCodeFieldsConf(RuntimeEnvironment env, String businessId, Long cropPlanId, String landUseCode,
			AbsoluteDate pointInTime) {
		CropCodesPlugin cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId());
		List<LandUse> landUses = cropCodesPlugin.getLandUses(env, Arrays.asList(landUseCode));
		if (landUses == null || landUses.isEmpty())
			throw new BadRequestException("The land use " + landUseCode + " was not found");

		LandUse landUse = landUses.get(0);

		List<LandUseAdditionalDataConf> landUseAdditionalConf = cropPlansDAO.getLandUseAdditionalConf(env.getTenantId(), env.getLocale().getLanguage(),
				pointInTime, landUse.getCode());

		landUseAdditionalConf.forEach(cc -> {
			cc.setLandUseDescription(landUse.getDescription());
			cc.setAllowedValues(cropPlansDAO.getLandUseAllowedAdditionalFileds(env.getTenantId(), env.getLocale().getLanguage(), pointInTime, landUse.getCode(),
					cc.getFieldCode()));
		});

		return landUseAdditionalConf;
	}

	public boolean isLandUseCompatible(RuntimeEnvironment env, String businessId, Long cropPlanId, String code, String landCoverCode) {
		return isLandUseCompatible(env, businessId, cropPlanId, code, landCoverCode, false);
	}

	public boolean isLandUseCompatible(RuntimeEnvironment env, String businessId, Long cropPlanId, String code, String landCoverCode,
			boolean forceCompatibilityCheck) {
		if (!forceCompatibilityCheck && cropPlanConfigService.isIgnoreLandUseCompatibility(cropPlanId))
			return true;
		else
			return pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId()).isLandUseCompatible(env, code, landCoverCode);
	}

	// private void fillLandUseClasses(RuntimeEnvironment env, String cropPlanTypeCode, List<LandUseDetails> landUses) {
	// if (landUses.size() == 0)
	// return;
	// var landUseClassCodes = landUses.stream().map(lud -> lud.getLandUseClass().getLandUseClassCode()).distinct().collect(toList());
	// var optionsMap = cropPlansDAO.getLandUseClassOptions(env.getTenantId(), cropPlanTypeCode, landUseClassCodes).stream()
	// .collect(toMap(LandUseClass::getLandUseClassCode, luc -> luc));
	// landUses.forEach(lud -> {
	// var options = optionsMap.get(lud.getLandUseClass().getLandUseClassCode());
	// if (options != null) {
	// lud.getLandUseClass().setPercFixedTo100(options.getPercFixedTo100());
	// lud.getLandUseClass().setPermanent(options.getPermanent());
	// }
	// // Load permanent crop forms configuration
	// var pcfsConfig = cropPlansDAO.getPermanentCropFormsConfigByLandUseCode(env.getTenantId(), cropPlanTypeCode, lud.getCode());
	// pcfsConfig.addAll(cropPlansDAO.getPermanentCropFormsConfigByLandUseClassCode(env.getTenantId(), cropPlanTypeCode,
	// lud.getLandUseClass().getLandUseClassCode(),
	// pcfsConfig.stream().map(p -> p.getFormType().toString()).collect(toList())));
	// pcfsConfig.forEach(p -> {
	// p.setFields(cropPlansDAO.getPermanentCropFormsFieldsConfig(p.getId()));
	// });
	// lud.setFormsConfig(pcfsConfig.stream().filter(p -> p.getFields().size() > 0).collect(toList()));
	// });
	// }

	private void fillLandUseClasses(RuntimeEnvironment env, String cropPlanTypeCode, List<LandUseDetails> landUses, AbsoluteDate pointInTime) {
		if (landUses.isEmpty())
			return;
		var landUseClassCodes = landUses.stream()
				.map(lud -> lud.getLandUseClass().getLandUseClassCode())
				.distinct()
				.collect(toList());

		var optionsMap = cropPlansDAO.getLandUseClassOptions(env.getTenantId(), cropPlanTypeCode, landUseClassCodes).stream()
				.collect(toMap(LandUseClass::getLandUseClassCode, luc -> luc));
		List<String> landUsesCodes = landUses.stream()
				.map(land -> land.getCode())
				.distinct()
				.collect(toList());
		List<PermanentCropFormConfigWithFields> pcfsConfigWithFields = cropPlanConfigDAO.getPermanentCropFormsConfigByLandUseCodeAndByLandUseClassCode(
				env.getTenantId(),
				cropPlanTypeCode,
				landUsesCodes,
				landUseClassCodes,
				pointInTime);
		landUses.forEach(lud -> {
			var options = optionsMap.get(lud.getLandUseClass().getLandUseClassCode());
			if (options != null) {
				lud.getLandUseClass().setPercFixedTo100(options.getPercFixedTo100());
				lud.getLandUseClass().setPermanent(options.getPermanent());
			}
			var pcfsConfigWithFieldsFiltered = pcfsConfigWithFields.stream()
					.filter(rec -> (Objects.nonNull(rec.getLand_use_code()) && rec.getLand_use_code().equals(lud.getCode())))
					.collect(toList());
			if (pcfsConfigWithFieldsFiltered.isEmpty())
				pcfsConfigWithFieldsFiltered = pcfsConfigWithFields.stream()
						.filter(rec -> (Objects.nonNull(rec.getLand_use_class_code())
								&& rec.getLand_use_class_code().equals(lud.getLandUseClass().getLandUseClassCode())))
						.collect(toList());

			Map<Long, List<PermanentCropFormConfigWithFields>> cfgMap = pcfsConfigWithFieldsFiltered.stream()
					.filter(cfg -> cfg.getFieldCode() != null)
					.collect(groupingBy(PermanentCropFormConfigWithFields::getPerm_crop_forms_cfg_id));
			List<PermanentCropFormConfig> pcfsConfigOfLand = new ArrayList<>();
			cfgMap.entrySet().forEach(cfg -> {
				List<PermanentCropFormFieldConfig> fields = cfg.getValue().stream()
						.map(field -> new PermanentCropFormFieldConfig(field.getFieldCode(), field.isFlMandatory(), field.isFlEditable()))
						.collect(toList());
				pcfsConfigOfLand.add(new PermanentCropFormConfig(
						cfg.getKey(),
						cfg.getValue().get(0).getFormType(),
						fields));
			});
			lud.setFormsConfig(pcfsConfigOfLand.stream().filter(p -> !p.getFields().isEmpty()).collect(toList()));
		});
	}

	public void addFavouriteLandUse(RuntimeEnvironment env, String businessId, Long cropPlanId, String code) {
		var cropPlan = cropPlansDAO.getCropPlanInternal(businessId, cropPlanId, env.getTenantId());
		cropPlansDAO.removeFavouriteLandUse(env.getUserId(), cropPlan.getCropPlanTypeCode(), env.getTenantId(), code);
		cropPlansDAO.addFavouriteLandUse(env.getUserId(), cropPlan.getCropPlanTypeCode(), env.getTenantId(), code);
	}

	public void removeFavouriteLandUse(RuntimeEnvironment env, String businessId, Long cropPlanId, String code) {
		var cropPlan = cropPlansDAO.getCropPlanInternal(businessId, cropPlanId, env.getTenantId());
		cropPlansDAO.removeFavouriteLandUse(env.getUserId(), cropPlan.getCropPlanTypeCode(), env.getTenantId(), code);
	}

}
