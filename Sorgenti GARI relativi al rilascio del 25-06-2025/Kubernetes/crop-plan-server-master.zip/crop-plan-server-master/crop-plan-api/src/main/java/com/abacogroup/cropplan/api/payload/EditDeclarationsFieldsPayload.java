package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.LandUseAdditionalDataField;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;

@Data
public class EditDeclarationsFieldsPayload
{

	@Schema(description = "Land use code")
	@NotEmpty
	private String landuseCode;

	@Schema(description = "The point in time")
	@NotNull
	private AbsoluteDate pointInTime;
	
	private List<InsertPermanentCropForm> permanentCropForms;

	@Schema(description = "List of additional fields codes values")
	private List<LandUseAdditionalDataField> fieldsCodes;
}
