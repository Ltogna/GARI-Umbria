package com.abacogroup.cropplan.bundle.model;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CropPlanTypeDefinition
{
	private String code;
	private Boolean flMultiple;
	
	@Builder.Default
	private Boolean flLimitToCanvas = true;
	
	@Builder.Default
	private Boolean flSplitOnCanvas = true;

	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;

	@Builder.Default
	private List<I18nValueDefinition> i18nValues = new ArrayList<>();
	
	public int getFlMultipleInt() {
		return flMultiple ? 1 : 0;
	}
	
	public int getFlLimitToCanvasInt() {
		return flLimitToCanvas ? 1 : 0;
	}
	
	public int getFlSplitOnCanvasInt() {
		return flSplitOnCanvas ? 1 : 0;
	}
}
