package com.abacogroup.cropplan.db.dao.ntt;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.locationtech.jts.geom.Geometry;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder=true)
public class PlotData
{
	private boolean isNew;
	private Long plotId;
	private String plotCode;
	private Long cropPlanId;
	private String description;
	private String notes;
	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;
	private String srs;
	private Integer areaSqm;
	private boolean flSoftModified;
	private String insertUserId;
	private String deleteUserId;
	private LocalDateTime insertDt;
	private LocalDateTime deleteDt;
	private Geometry geom;
}
