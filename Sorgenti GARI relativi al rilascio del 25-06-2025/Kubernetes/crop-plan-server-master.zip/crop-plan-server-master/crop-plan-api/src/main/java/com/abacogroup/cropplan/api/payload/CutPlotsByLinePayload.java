package com.abacogroup.cropplan.api.payload;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.locationtech.jts.geom.Geometry;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CutPlotsByLinePayload
{
	@Schema(description = "From date")
	@NotNull
	AbsoluteDate fromPointInTime;

	@Schema(description = "To date (optional, default propagate to infinity)")
	AbsoluteDate toPointInTime;
	
	@Schema(description = "The cut line geometry", type = "string", format = "WKT geometry")
	@NotNull
	private Geometry geom;

	@Schema(description = "The parameters used to apply the geometry in relation to the already existing ones")
	@NotNull
	@Valid
	private LineCutParameters cutParameters;
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	public static class LineCutParameters
	{
		@Schema(description = "The plots to consider during the cut operation; if null, all plots are considered")	 
		@Size(min = 1)
		private List<String> plotCodes;
	}
}
