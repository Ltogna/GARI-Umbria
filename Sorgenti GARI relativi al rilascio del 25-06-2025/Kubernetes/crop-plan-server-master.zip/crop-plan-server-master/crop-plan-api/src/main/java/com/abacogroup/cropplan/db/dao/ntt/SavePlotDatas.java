package com.abacogroup.cropplan.db.dao.ntt;

import java.util.List;

import com.abacogroup.cropplan.api.LandUseAdditionalDataFieldForSavePlot;
import com.abacogroup.cropplan.api.PermanentCropFormSave;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SavePlotDatas
{
	private List<PlotData> plotDatas;
	private List<PlotDataParcel> plotDataParcels;
	private List<DeclarationData> declarationDatas;
	private List<PermanentCropFormSave> permanentCropFormSaveDatas;
	private List<LandUseAdditionalDataFieldForSavePlot> fieldsCodes;
}
