package com.abacogroup.cropplan.db.dao.ntt;

import java.util.ArrayList;
import java.util.List;

import com.abacogroup.cropplan.bundle.model.AnomScenarioDisableFuncConfigDefinition;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScenarioAnomaliesDisableFunctionsConfigurations
{
	@Builder.Default
	private List<AnomScenarioDisableFuncConfigDefinition> anomScenarioConfig = new ArrayList<>();
}
