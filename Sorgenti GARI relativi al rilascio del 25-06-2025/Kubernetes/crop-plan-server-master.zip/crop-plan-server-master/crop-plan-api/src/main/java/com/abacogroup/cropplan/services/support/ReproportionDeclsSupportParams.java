package com.abacogroup.cropplan.services.support;

import java.time.LocalDateTime;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class ReproportionDeclsSupportParams
{
	private Long cropPlanId;
	private String domainZoneId;
	private String businessId;
	private LocalDateTime versionDt;
	private AbsoluteDate pointInTime;
	private boolean ignoreDeclValidationWarnings;
}
