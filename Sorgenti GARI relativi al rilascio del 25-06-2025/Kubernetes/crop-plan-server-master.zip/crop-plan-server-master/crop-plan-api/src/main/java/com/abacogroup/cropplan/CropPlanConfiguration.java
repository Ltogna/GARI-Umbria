package com.abacogroup.cropplan;

import java.util.Map;

import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.Configuration;
import io.dropwizard.db.DataSourceFactory;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class CropPlanConfiguration extends Configuration
{
	private boolean cors = true;
	private boolean devMode;
	private DataSourceFactory database;
	private PluginsConfig pluginsConfig;
	private RabbitmqConfig rabbitmqConfig;

	@Data
	public class RabbitmqConfig
	{
		private String host;
		private String user;
		private String password;
		private String virtualhost;
		private Integer port;
	}

	private String lockManagerUrl;

	@Data
	public class PluginsConfig
	{
		@Valid
		private JerseyClientConfiguration jerseyClient;

		@Valid
		private Map<String, @Valid DataSourceFactory> dataSources;

		@NotNull
		private Map<String, Object> properties;
	}

}
