package com.abacogroup.cropplan.managers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.ServiceLoader;

import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.sdk.spi.AuthPlugin;
import com.abacogroup.cropplan.sdk.spi.BasePlugin;
import com.abacogroup.cropplan.sdk.spi.BusinessPlugin;
import com.abacogroup.cropplan.sdk.spi.CropCodesPlugin;
import com.abacogroup.cropplan.sdk.spi.CropPlanPlugin;
import com.abacogroup.cropplan.sdk.spi.DomainPlugin;
import com.abacogroup.cropplan.sdk.spi.LayersPlugin;
import com.abacogroup.cropplan.sdk.spi.PesticidesPlugin;
import com.abacogroup.cropplan.sdk.spi.PestsPlugin;
import com.abacogroup.cropplan.sdk.spi.ProjectionTransformerPlugin;
import com.abacogroup.cropplan.sdk.spi.SyncPlugin;
import com.abacogroup.cropplan.sdk.spi.ValidatorPlugin;
import com.abacogroup.cropplan.sdk.spi.constants.PluginProperties;
import com.abacogroup.plugins.sdk.InitializablePlugin;
import com.abacogroup.plugins.sdk.PluginsEnvironment;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.BadRequestException;

public class PluginManager {
    private static final String PLUGIN_CROP_PLAN_TYPE_WILDCARD = "*";

    private PluginsEnvironment env;
    private CropPlansDAO cropPlansDAO;

    private AuthPlugin authPlugin;
    private BusinessPlugin businessPlugin;

    private List<CropPlanPlugin> cropPlanPlugins;
    private List<DomainPlugin> domainPlugins;
    private List<LayersPlugin> layersPlugins;
    private List<CropCodesPlugin> cropCodesPlugins;
    private List<ValidatorPlugin> validatorPlugins;
    private List<SyncPlugin> syncPlugins;
    private List<ProjectionTransformerPlugin> projectionTransformerPlugins;
    private List<PesticidesPlugin> pesticidesPlugin;
    private List<PestsPlugin> pestsPlugin;

    public PluginManager(PluginsEnvironment env, CropPlansDAO cropPlansDAO) {
        this.env = env;
        this.cropPlansDAO = cropPlansDAO;
    }

    public void init() {
        Map<String, Object> externalProperties = null;
        if (env.getProperty(PluginProperties.EXTERNAL_PLUGINS_PROPERTIES_PROPERTY_NAME) != null) {
            ObjectMapper mapper = new ObjectMapper();
            externalProperties = mapper.convertValue(env.getProperty(PluginProperties.EXTERNAL_PLUGINS_PROPERTIES_PROPERTY_NAME),
                    new TypeReference<Map<String, Object>>() {
                    });
        }

        var authPlugins = loadPlugins(AuthPlugin.class, true, true, externalProperties, PluginProperties.AUTH_PLUGIN_BASE_URL_PROPERTY_NAME);
        authPlugin = authPlugins != null ? authPlugins.get(0) : null;
        var businessPlugins = loadPlugins(BusinessPlugin.class, true, true, externalProperties, PluginProperties.BUSINESS_PLUGIN_BASE_URL_PROPERTY_NAME);
        businessPlugin = businessPlugins != null ? businessPlugins.get(0) : null;
        cropPlanPlugins = loadPlugins(CropPlanPlugin.class, false, true, externalProperties, PluginProperties.CROP_PLAN_PLUGINS_BASE_URL_PROPERTY_NAME);
        domainPlugins = loadPlugins(DomainPlugin.class, false, true, externalProperties, PluginProperties.DOMAIN_PLUGINS_BASE_URL_PROPERTY_NAME);
        layersPlugins = loadPlugins(LayersPlugin.class, false, true, externalProperties, PluginProperties.LAYERS_PLUGINS_BASE_URL_PROPERTY_NAME);
        cropCodesPlugins = loadPlugins(CropCodesPlugin.class, false, true, externalProperties, PluginProperties.CROP_CODES_PLUGINS_BASE_URL_PROPERTY_NAME);
        validatorPlugins = loadPlugins(ValidatorPlugin.class, false, false, externalProperties, PluginProperties.VALIDATOR_PLUGINS_BASE_URL_PROPERTY_NAME);
        syncPlugins = loadPlugins(SyncPlugin.class, false, true, externalProperties, PluginProperties.SYNC_PLUGINS_BASE_URL_PROPERTY_NAME);
        projectionTransformerPlugins = loadPlugins(ProjectionTransformerPlugin.class, false, false, externalProperties,
                PluginProperties.PROJECTION_TRANSFORMER_PLUGINS_BASE_URL_PROPERTY_NAME);
        pesticidesPlugin = loadPlugins(PesticidesPlugin.class, false, false, externalProperties, PluginProperties.PESTICIDES_PLUGINS_BASE_URL_PROPERTY_NAME);
        pestsPlugin = loadPlugins(PestsPlugin.class, false, false, externalProperties, PluginProperties.PESTS_PLUGINS_BASE_URL_PROPERTY_NAME);
    }

    public AuthPlugin getAuthPlugin() {
        return authPlugin;
    }

    public BusinessPlugin getBusinessPlugin() {
        return businessPlugin;
    }

    public CropPlanPlugin getCropPlanPlugin(String businessId, Long cropPlanId, String tenantId) {
        return getPlugin(cropPlanPlugins, getCropPlanTypeCode(businessId, cropPlanId, tenantId));
    }

    public CropCodesPlugin getCropCodesPlugin(RuntimeEnvironment env, String cropPlanTypeCode) {
        checkCropPlanTypeCode(env, cropPlanTypeCode);
        return getPlugin(cropCodesPlugins, cropPlanTypeCode);
    }

    public CropCodesPlugin getCropCodesPlugin(String businessId, Long cropPlanId, String tenantId) {
        return getPlugin(cropCodesPlugins, getCropPlanTypeCode(businessId, cropPlanId, tenantId));
    }

    public DomainPlugin getDomainPlugin(String businessId, Long cropPlanId, String tenantId) {
        return getPlugin(domainPlugins, getCropPlanTypeCode(businessId, cropPlanId, tenantId));
    }

    public LayersPlugin getLayersPlugin(RuntimeEnvironment env, String cropPlanTypeCode) {
        checkCropPlanTypeCode(env, cropPlanTypeCode);
        return getPlugin(layersPlugins, cropPlanTypeCode);
    }

    public LayersPlugin getLayersPlugin(String businessId, Long cropPlanId, String tenantId) {
        return getPlugin(layersPlugins, getCropPlanTypeCode(businessId, cropPlanId, tenantId));
    }

    public ProjectionTransformerPlugin getProjectionTransformerPlugin(String businessId, Long cropPlanId, String tenantId) {
        return getPlugin(projectionTransformerPlugins, getCropPlanTypeCode(businessId, cropPlanId, tenantId));
    }

    public SyncPlugin getSyncPlugin(String businessId, Long cropPlanId, String tenantId) {
        return getPlugin(syncPlugins, getCropPlanTypeCode(businessId, cropPlanId, tenantId));
    }

    public ValidatorPlugin getValidatorPlugin(String businessId, Long cropPlanId, String tenantId) {
        return getPlugin(validatorPlugins, getCropPlanTypeCode(businessId, cropPlanId, tenantId));
    }

    public PesticidesPlugin getPesticidesPlugin(String businessId, Long cropPlanId, String tenantId) {
        return getPlugin(pesticidesPlugin, getCropPlanTypeCode(businessId, cropPlanId, tenantId));
    }

    public PestsPlugin getPestsPlugin(String businessId, Long cropPlanId, String tenantId) {
        return getPlugin(pestsPlugin, getCropPlanTypeCode(businessId, cropPlanId, tenantId));
    }

    private <T> T getPlugin(List<T> plugins, String cropPlanTypeCode) {
        // Attempt finding a plugin with the same cropPlanTypeCode
        var targetPlugin = plugins.stream().filter(plugin -> cropPlanTypeCode.equals(((BasePlugin) plugin).getCropPlanType())).findAny().orElse(null);
        if (targetPlugin == null) {
            // If no plugin with the same cropPlanTypeCode is found, attempt finding a wildcard plugin
            targetPlugin = plugins.stream().filter(plugin -> PLUGIN_CROP_PLAN_TYPE_WILDCARD.equals(((BasePlugin) plugin).getCropPlanType())).findAny()
                    .orElse(null);
        }

        return targetPlugin;
    }

    private <T> List<T> loadPlugins(Class<T> clazz, Boolean singleImplementation, Boolean mandatory, Map<String, Object> externalProperties,
            String externalPropertyKey) {
        if (externalProperties == null || externalProperties.containsKey(externalPropertyKey)) {
            ServiceLoader<T> loader = ServiceLoader.load(clazz);
            var iter = loader.iterator();
            List<T> plugins = new ArrayList<>();
            iter.forEachRemaining(plugins::add);
            initPlugins(plugins, clazz, singleImplementation, mandatory);
            return plugins;
        }
        return Collections.emptyList();
    }

    private <T> void initPlugins(List<T> plugins, Class<T> clazz, Boolean singleImplementation, Boolean mandatory) {
        if (mandatory && plugins.size() == 0) {
            throw new IllegalStateException("Cannot load any implementation of " + clazz.getName());
        }

        if (singleImplementation && plugins.size() > 1)
            throw new IllegalStateException("Found too many implementations of " + clazz.getName());

        List<String> pluginImplementations = new ArrayList<>();

        plugins.forEach(plugin -> {
            if (plugin instanceof BasePlugin) {
                var cropPlanPlugin = (BasePlugin) plugin;
                if (pluginImplementations.contains(cropPlanPlugin.getCropPlanType()))
                    throw new IllegalStateException(
                            "Found too many implementations of " + clazz.getName() + " for cropPlanType " + cropPlanPlugin.getCropPlanType());

                pluginImplementations.add(cropPlanPlugin.getCropPlanType());
            }

            if (plugin instanceof InitializablePlugin)
                ((InitializablePlugin) plugin).initialize(env);
        });
    }

    private String getCropPlanTypeCode(String businessId, Long cropPlanId, String tenantId) {
        return cropPlansDAO.getCropPlanInternal(businessId, cropPlanId, tenantId).getCropPlanTypeCode();
    }

    private void checkCropPlanTypeCode(RuntimeEnvironment env, String cropPlanTypeCode) {
        if (cropPlansDAO.getCropPlanType(cropPlanTypeCode, env.getTenantId(), env.getLocale().getLanguage()) == null)
            throw new BadRequestException("The " + cropPlanTypeCode + " crop plan type code does not exist");
    }
}
