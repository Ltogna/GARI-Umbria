package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class PermanentCropFormNotAllowedException extends WebApplicationException
{
	private static final long serialVersionUID = -1205943738478719157L;

	public static  class PermanentCropFormNotAllowedExceptionErrorBody
	{
		@Schema(allowableValues = "PERMANENT_CROP_FORM_NOT_ALLOWED_EXCEPTION")
		public String getErrorCode()
		{
			return "PERMANENT_CROP_FORM_NOT_ALLOWED_EXCEPTION";
		}
	}

	private static final PermanentCropFormNotAllowedExceptionErrorBody BODY = new PermanentCropFormNotAllowedExceptionErrorBody();

	public PermanentCropFormNotAllowedException(String formType, String landUseCode)
	{
		super("Permanent crop form " + formType + " not allowed for land use " + landUseCode,
			Response.status(Status.BAD_REQUEST).entity(BODY).build());
	}
}
