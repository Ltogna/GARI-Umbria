package com.abacogroup.cropplan.api;

import java.util.List;

import com.abacogroup.cropplan.sdk.model.validation.ValidationMessage;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ValidationResult
{
	@Schema(description = "The list of validation messages (warnings and errors)")
	private List<ValidationMessage> validationMessages;
}
