package com.abacogroup.cropplan.api;

public enum PrintJobStatus {
	ACKNOWLEDGE,
	PROGRESS,
	ERROR,
	READY
}
