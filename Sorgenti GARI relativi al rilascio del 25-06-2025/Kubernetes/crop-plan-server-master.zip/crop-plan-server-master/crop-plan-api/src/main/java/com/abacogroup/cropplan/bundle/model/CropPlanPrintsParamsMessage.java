package com.abacogroup.cropplan.bundle.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CropPlanPrintsParamsMessage {
    private String cropPlanType;
    private String printCode;
    private List<PrintParam> printParams;
}

