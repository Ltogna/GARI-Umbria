package com.abacogroup.cropplan.api;

import java.util.List;

import lombok.Data;

@Data
public class EditPlotPreviewResult
{
	private List<PlotPreview> added;
	private List<String> deleted;
	private List<PlotPreview> updated;
	private List<String> coveredByInserted;
}
