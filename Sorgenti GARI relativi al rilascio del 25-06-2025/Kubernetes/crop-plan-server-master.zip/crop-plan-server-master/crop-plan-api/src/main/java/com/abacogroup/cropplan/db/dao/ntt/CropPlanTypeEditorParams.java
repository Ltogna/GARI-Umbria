package com.abacogroup.cropplan.db.dao.ntt;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class CropPlanTypeEditorParams
{
	@NotNull
	private boolean flLimitToCanvas;

	@NotNull
	private boolean flSplitOnCanvas;
}
