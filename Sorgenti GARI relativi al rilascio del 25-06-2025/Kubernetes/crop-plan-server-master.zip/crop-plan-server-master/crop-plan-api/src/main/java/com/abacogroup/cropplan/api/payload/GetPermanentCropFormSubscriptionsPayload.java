package com.abacogroup.cropplan.api.payload;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;
import lombok.Data;

@Data
@Schema(description = "Permanent crop form subscriptions")
public class GetPermanentCropFormSubscriptionsPayload {

	@Schema(description = "External code")
	private String externalCode;

	@ArraySchema(schema = @Schema(description = "Subscription codes", implementation = String.class))
	@NotEmpty
	private List<String> subscriptionCodes;
}
