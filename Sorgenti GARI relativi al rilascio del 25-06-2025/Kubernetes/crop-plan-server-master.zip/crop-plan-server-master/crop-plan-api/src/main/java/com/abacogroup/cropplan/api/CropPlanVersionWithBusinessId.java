package com.abacogroup.cropplan.api;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.CropPlanVersion;
import com.abacogroup.cropplan.sdk.model.Version;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@NoArgsConstructor
public class CropPlanVersionWithBusinessId extends CropPlanVersion {

	private String businessId;

	public CropPlanVersionWithBusinessId(Long cropPlanId, Version version, LocalDateTime versionDate,
			AbsoluteDate versionReferenceDate, String message, String cropPlanTypeCode, String userId, Boolean flPublished,
			String businessId) {
		super(cropPlanId, version, versionDate, versionReferenceDate, message, cropPlanTypeCode, userId, flPublished);
		this.businessId = businessId;
	}
}
