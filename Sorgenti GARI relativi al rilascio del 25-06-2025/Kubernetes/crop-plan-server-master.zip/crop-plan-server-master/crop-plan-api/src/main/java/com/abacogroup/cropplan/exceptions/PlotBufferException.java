package com.abacogroup.cropplan.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class PlotBufferException extends AbstractAppException {

	public PlotBufferException(ErrEnum code, String message) {
		super(new ErrorBody(code.name(), message), code.statusCode);
	}

	public enum ErrEnum {
		MISSING_DISTANCE_BETWEEN_ROWS_CM(Status.BAD_REQUEST.getStatusCode()),
		;

		private final int statusCode;

		ErrEnum(int statusCode) {
			this.statusCode = statusCode;
		}
	}

	@Schema(name = "PlotBufferExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = {
				"MISSING_DISTANCE_BETWEEN_ROWS_CM",
		})
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}
}
