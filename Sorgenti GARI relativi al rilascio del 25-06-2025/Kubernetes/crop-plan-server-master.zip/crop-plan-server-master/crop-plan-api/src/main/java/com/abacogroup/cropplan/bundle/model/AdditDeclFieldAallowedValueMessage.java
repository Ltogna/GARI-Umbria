package com.abacogroup.cropplan.bundle.model;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import jakarta.validation.Valid;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AdditDeclFieldAallowedValueMessage {

	private String value;
	@Valid
	private List<I18nValueDefinition> description;
	@Builder.Default
	private AbsoluteDate validFrom = AbsoluteDate.of("19700101");
	@Builder.Default
	private AbsoluteDate validTo = AbsoluteDate.of("99991231");
	private Integer displayOrder;
	private Boolean isDefault;
}
