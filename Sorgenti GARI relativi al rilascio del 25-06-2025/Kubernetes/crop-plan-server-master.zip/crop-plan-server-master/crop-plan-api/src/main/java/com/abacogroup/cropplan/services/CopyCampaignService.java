package com.abacogroup.cropplan.services;

import static com.abacogroup.cropplan.api.PlotDataToInclude.ONLY_DECLS;
import static java.util.stream.Collectors.toList;

import com.abacogroup.cropplan.api.CopyCampaignLandUseCode;
import com.abacogroup.cropplan.api.CropPlan;
import com.abacogroup.cropplan.api.CropPlanDates;
import com.abacogroup.cropplan.api.CropPlanVersionWithBusinessId;
import com.abacogroup.cropplan.api.Plot;
import com.abacogroup.cropplan.api.payload.CopyCampaignPayload;
import com.abacogroup.cropplan.db.dao.CropPlansDAO;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.DeclarationsDAO;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.sdk.model.Version;
import com.abacogroup.cropplan.sdk.model.cropcodes.LandUse;
import com.abacogroup.cropplan.sdk.model.domain.Parcel;
import com.abacogroup.cropplan.sdk.spi.CropCodesPlugin;
import com.abacogroup.cropplan.sdk.spi.DomainPlugin;
import com.abacogroup.cropplan.sdk.support.InfiniteListResultsSupport;
import com.abacogroup.cropplan.services.support.EditorSupportParams;
import com.abacogroup.cropplan.services.utils.CopyCampaignUtils;
import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.google.common.collect.Iterators;
import com.google.common.collect.UnmodifiableIterator;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryFactory;

@Slf4j
public class CopyCampaignService {

	private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("MMdd");

	private final CropPlansDAO cropPlansDAO;
	private final DeclarationsDAO declarationsDAO;

	private final CropPlanConfigService cropPlanConfigService;
	private final CropPlanService cropPlanService;

	private final PluginManager pluginManager;

	private final CopyCampaignUtils copyCampaignUtils;
	
	public CopyCampaignService(CropPlanConfigService cropPlanConfigService, CropPlanService cropPlanService, PlotEditService plotEditService,
			CropCodeService cropCodeService, DAOContainer daocontainer, PluginManager pluginManager) {
		this(daocontainer.getCropPlansDAO(), daocontainer.getDeclarationsDAO(),
				cropPlanConfigService, cropPlanService, pluginManager,
				new CopyCampaignUtils(daocontainer.getCropPlansDAO(), plotEditService, cropCodeService, cropPlanConfigService, pluginManager));
	}

	CopyCampaignService(CropPlansDAO cropPlansDAO, DeclarationsDAO declarationsDAO, CropPlanConfigService cropPlanConfigService,
			CropPlanService cropPlanService, PluginManager pluginManager, CopyCampaignUtils copyCampaignUtils) {
		this.cropPlansDAO = cropPlansDAO;
		this.declarationsDAO = declarationsDAO;

		this.cropPlanConfigService = cropPlanConfigService;
		this.cropPlanService = cropPlanService;

		this.pluginManager = pluginManager;

		this.copyCampaignUtils = copyCampaignUtils;
		
	}

	public void copyCampaign(RuntimeEnvironment env, String businessId, Long cropPlanId,
			CopyCampaignPayload payload) {

		log.info("START COPY CAMPAIGN for businessId: {} and cropPlanId: {}", businessId, cropPlanId);
		log.debug("COPY CAMPAIGN (cropPlanId: {}). payload: {}", cropPlanId, payload);

		DomainPlugin domainPlugin = pluginManager.getDomainPlugin(businessId, cropPlanId, env.getTenantId());

		cropPlansDAO.useTransaction(dao -> {

			LocalDateTime currentVersion = dao.getCurrentTimestamp();
			LocalDateTime sourceVersion = Optional.ofNullable(payload.getSourceVersion())
					.map(Version::toDateTime)
					.orElse(currentVersion);

			CropPlanDates sourceCropPlanDates = cropPlanService.getCropPlanDates(env, businessId, payload.getSourceCropPlanId(), payload.getSourcePointInTime());
			String campaignRefDate = cropPlanConfigService.getCampaignRefDateParam(cropPlanId);
			CropPlanDates destCropPlanDates = cropPlanService.getCropPlanDates(env, businessId, cropPlanId, payload.getDestPointInTime());

			CropPlan sourceCropPlan = cropPlansDAO.getCropPlanInternal(businessId, payload.getSourceCropPlanId(), env.getTenantId());

			List<String> domainZoneIds = cropPlansDAO.getPlotsDomainZoneIds(cropPlanId, currentVersion, payload.getDestPointInTime());
			for (int i = 0; i < domainZoneIds.size(); i++) {
				String domainZoneId = domainZoneIds.get(i);

				log.info("COPY CAMPAIGN (cropPlanId: {}). START copy on domainZoneId {} ({}/{})",
						cropPlanId, domainZoneId, i+1, domainZoneIds.size());

				EditorSupportParams editorSupportParams = EditorSupportParams.builder()
						.businessId(businessId)
						.cropPlanId(cropPlanId)
						.domainZoneId(domainZoneId)
						.versionDt(currentVersion)
						.pointInTime(payload.getDestPointInTime())
						.build();

				List<Parcel> allParcels = domainPlugin.getCopyCampaignParcels(env, businessId, domainZoneId, payload.getDestPointInTime().toLocalDate());
				log.info("COPY CAMPAIGN (cropPlanId: {}). start copying on {} parcels of domainZoneId {}", cropPlanId, allParcels.size(), domainZoneId);

				for (int j = 0; j < allParcels.size(); j++) {
					Parcel currentParcel = allParcels.get(j);

					log.debug("COPY CAMPAIGN (cropPlanId: {}). START copy on parcel {} ({}/{}) of domainZoneId {} ({}/{})",
							cropPlanId, currentParcel.getCode(), j+1, allParcels.size(), domainZoneId, i+1, domainZoneIds.size());

					List<Plot> sourcePlots = this.getSourcePlots(env, businessId, payload.getSourceCropPlanId(), domainZoneId, sourceCropPlanDates,
							sourceVersion, payload.getSourcePointInTime(), payload.getDeclsPointInTimeTo(), currentParcel.getGeom());

					if (payload.isFlCopyFromOtherBusinesses() && campaignRefDate != null
						&& payload.getDestPointInTime().toLocalDate().format(FORMATTER).equals(campaignRefDate)) {
						this.addOtherBusinessesSourcePlots(env, businessId, payload, domainZoneId, currentParcel, sourceCropPlanDates, campaignRefDate,
								sourceCropPlan, sourcePlots);
					}

					log.debug("COPY CAMPAIGN (cropPlanId: {}). start copy from {} plots on parcel {}", cropPlanId, sourcePlots.size(), currentParcel.getCode());

					List<Plot> aggregatedPlots = payload.isSkipAggregation() ? sourcePlots : copyCampaignUtils.aggregatePlots(env, businessId, cropPlanId, payload, sourcePlots);

					copyCampaignUtils.copyDeclarationsOnParcel(env, payload, currentParcel, aggregatedPlots, destCropPlanDates, editorSupportParams);

					log.debug("COPY CAMPAIGN (cropPlanId: {}). END copy on parcel {} ({}/{}) of domainZoneId {} ({}/{})",
							cropPlanId, currentParcel.getCode(), j+1, allParcels.size(), domainZoneId, i+1, domainZoneIds.size());
				}

				log.info("COPY CAMPAIGN (cropPlanId: {}). END copy on domainZoneId {} ({}/{})",
						cropPlanId, domainZoneId, i+1, domainZoneIds.size());
			}

		});

		log.info("END COPY CAMPAIGN for businessId: {} and cropPlanId: {}", businessId, cropPlanId);
	}

	public List<CopyCampaignLandUseCode> getSourceLandUseCodesForCopyCampaign(RuntimeEnvironment env, String businessId, Long cropPlanId,
			Long sourceCropPlanId, Version sourceVersion, AbsoluteDate sourcePointInTime, AbsoluteDate declsPointInTimeTo) {

		LocalDateTime sourceVersionDt = Optional.ofNullable(sourceVersion)
				.map(Version::toDateTime)
				.orElse(declarationsDAO.getCurrentTimestamp());

		CropPlanDates sourceCropPlanDates = cropPlanService.getCropPlanDates(env, businessId, sourceCropPlanId, sourcePointInTime);
		AbsoluteDate sourcePointInTimeTo = declsPointInTimeTo != null ? declsPointInTimeTo : this.getSourcePointInTimeTo(sourcePointInTime, sourceCropPlanDates);

		List<String> landUsesCodes = declarationsDAO.getDeclarationLandUsesCodes(sourceCropPlanId, sourceVersionDt, sourcePointInTime, sourcePointInTimeTo);

		CropCodesPlugin cropCodesPlugin = pluginManager.getCropCodesPlugin(businessId, cropPlanId, env.getTenantId());
		List<LandUse> landUses = cropCodesPlugin.getLandUses(env, landUsesCodes);
		Set<String> defaultLandUseCodesExcludedFromAggregation = cropCodesPlugin.getDefaultLandUseCodesExcludedFromAggregation(env);

		return landUses.stream()
				.map(l -> new CopyCampaignLandUseCode(l, defaultLandUseCodesExcludedFromAggregation.contains(l.getCode())))
				.collect(toList());

	}


	private List<Plot> getSourcePlots(RuntimeEnvironment env, String businessId, Long sourceCropPlanId, String domainZoneId,
			CropPlanDates sourceCropPlanDates, LocalDateTime sourceVersionDate, AbsoluteDate sourcePointInTime, AbsoluteDate declsPointInTimeTo, Geometry parcelGeom) {

		AbsoluteDate declsPointInTimeFrom = sourcePointInTime;

		return new InfiniteListResultsSupport<>(nextKey ->
				cropPlanService.getPlotsByIntersectionWithDeclarationsBetweenDates(env, businessId, sourceCropPlanId, domainZoneId,
						parcelGeom, sourceVersionDate, sourcePointInTime, declsPointInTimeFrom, 
						declsPointInTimeTo != null ? declsPointInTimeTo : this.getSourcePointInTimeTo(sourcePointInTime, sourceCropPlanDates),
						nextKey, 50, ONLY_DECLS))
				.getAll();
	}

	private void addOtherBusinessesSourcePlots(RuntimeEnvironment env, String businessId, CopyCampaignPayload payload, String domainZoneId, Parcel currentParcel,
		CropPlanDates sourceCropPlanDates, String campaignRefDate, CropPlan sourceCropPlan, List<Plot> plots) {

		Geometry usedArea = plots.size() > 0 ? Utils.getUnion(plots.stream().map(Plot::getGeom).collect(toList())) : new GeometryFactory().createPolygon();
		Geometry whiteArea = Utils.snappedDifferenceAB(currentParcel.getGeom(), usedArea);

		if (whiteArea.getArea() < 1) {
			return;
		}

		List<Long> intersectingCropPlanIds = cropPlansDAO.findOtherBusinessesCropPlanIds(sourceCropPlan.getCropPlanTypeCode(), env.getTenantId(), businessId, domainZoneId, whiteArea, payload.getSourcePointInTime());
		if (intersectingCropPlanIds.isEmpty()) {
			return;
		}
		
		UnmodifiableIterator<List<Long>> partitions = Iterators.partition(intersectingCropPlanIds.iterator(), 666);
		List<CropPlanVersionWithBusinessId> intersectingPlans = new ArrayList<>();
		partitions.forEachRemaining(partition -> {
			intersectingPlans.addAll(cropPlansDAO.findLatestVersionsByPlanIds(partition, businessId, payload.getSourcePointInTime(),
					sourceCropPlan.getCropPlanTypeCode(), env.getTenantId()));
		});
		List<CropPlanVersionWithBusinessId> orderedIntersectingPlans = intersectingPlans.stream()
			.sorted((cpv1, cpv2) -> compareCpvByDates(campaignRefDate, cpv1, cpv2))
			.collect(toList());

		for (Iterator<CropPlanVersionWithBusinessId> iterator = orderedIntersectingPlans.iterator(); iterator.hasNext() && whiteArea.getArea() >= 1; ) {
			CropPlanVersionWithBusinessId version = iterator.next();

			List<Plot> othersSourcePlots = this.getSourcePlots(env, version.getBusinessId(), version.getCropPlanId(), domainZoneId,
					sourceCropPlanDates, version.getVersionDate(), payload.getSourcePointInTime(), payload.getDeclsPointInTimeTo(), whiteArea);

			Geometry prevUsedArea = usedArea.copy();

			usedArea = Utils.getUnion(Stream.concat(othersSourcePlots.stream().map(Plot::getGeom), Stream.of(prevUsedArea)).collect(toList()));
			whiteArea = Utils.snappedDifferenceAB(currentParcel.getGeom(), usedArea);

			othersSourcePlots.forEach(p -> {
				Geometry geom = Utils.snappedDifferenceAB(p.getGeom(), prevUsedArea);
				for (int i = 0; i < geom.getNumGeometries(); i++) {
					Geometry pol = geom.getGeometryN(i);
					if (pol.getArea() >= 1) {
						plots.add(Plot.builder()
								.geom(pol)
								.srs(p.getSrs())
								.decls(p.getDecls())
								.notes(String.format("from plot %s (%d)", p.getPlotCode(), i))
								.fromDate(p.getFromDate())
								.toDate(p.getToDate())
								.build());
					}
				}
			});
		}
	}

	private int compareCpvByDates(String campaignRefDate, CropPlanVersionWithBusinessId cpv1,
			CropPlanVersionWithBusinessId cpv2) {
		int cmp1 = campaignRefDate.equals(cpv1.getVersionReferenceDate() != null ? cpv1.getVersionReferenceDate().toLocalDate().format(FORMATTER) : null) ? 1 : 0;
		int cmp2 = campaignRefDate.equals(cpv2.getVersionReferenceDate() != null ? cpv2.getVersionReferenceDate().toLocalDate().format(FORMATTER) : null) ? 1 : 0;
		return cmp1 == cmp2 ? cpv2.getVersionDate().compareTo(cpv1.getVersionDate()) : cmp1 == 1 ? -1 : 1;
	}

	private AbsoluteDate getSourcePointInTimeTo(AbsoluteDate sourcePointInTime, CropPlanDates sourceCropPlanDates) {
		return Optional.of(sourceCropPlanDates)
				.map(CropPlanDates::getCampaignStartDate)
				.map(AbsoluteDate::toLocalDate)
				.map(ld -> ld.plusYears(1).minusDays(1))
				.filter(ld -> ld.isAfter(sourcePointInTime.toLocalDate()))
				.map(AbsoluteDate::of)
				.orElse(sourcePointInTime);
	}
}
