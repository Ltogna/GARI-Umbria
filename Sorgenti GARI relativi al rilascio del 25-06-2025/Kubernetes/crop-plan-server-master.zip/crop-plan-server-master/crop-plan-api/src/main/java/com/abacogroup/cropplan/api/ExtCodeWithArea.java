package com.abacogroup.cropplan.api;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ExtCodeWithArea {
	private String extCode;
	private Integer areaSqm;
}
