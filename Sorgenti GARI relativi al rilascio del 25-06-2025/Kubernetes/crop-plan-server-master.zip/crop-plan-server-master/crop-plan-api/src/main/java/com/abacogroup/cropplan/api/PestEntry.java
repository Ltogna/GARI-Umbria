package com.abacogroup.cropplan.api;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.cropplan.sdk.model.BaseDeclaration;
import com.abacogroup.cropplan.sdk.model.ParcelIntersection;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "A registration of pesticide on a declaration")
public class PestEntry {
	@NotNull
	private String pestEntryCode;

	@NotNull
	private Long planId;

	@NotNull
	private String plotCode;

	@NotNull
	private String declCode;

	@NotNull
	private String pestCode;

	@NotNull
	private Long areaAffected;

	@NotNull
	private String measuresApplied;

	@NotNull
	private AbsoluteDate entryDate;

	private String pestName;

	private String userId;

	private BaseDeclaration declaration;

	private List<ParcelIntersection> parcelIntersection;

	private Integer plotAreaSqm;

	private String quarantineDays;
}
