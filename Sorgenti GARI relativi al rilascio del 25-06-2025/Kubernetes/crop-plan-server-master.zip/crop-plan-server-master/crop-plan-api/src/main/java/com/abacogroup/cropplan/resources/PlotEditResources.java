package com.abacogroup.cropplan.resources;

import com.abacogroup.cropplan.api.EditPlotPreviewResult;
import com.abacogroup.cropplan.api.EditPlotResult;
import com.abacogroup.cropplan.api.payload.CutPlotsByGeometriesPayload;
import com.abacogroup.cropplan.api.payload.CutPlotsByLayerPayload;
import com.abacogroup.cropplan.api.payload.CutPlotsByLinePayload;
import com.abacogroup.cropplan.api.payload.DrawLineBufferPayload;
import com.abacogroup.cropplan.api.payload.EditPlotPayload;
import com.abacogroup.cropplan.api.payload.EditPlotsPayload;
import com.abacogroup.cropplan.api.payload.GetCuttableLayersPayload;
import com.abacogroup.cropplan.api.payload.InsertPlotPayload;
import com.abacogroup.cropplan.api.payload.MergePlotsPayload;
import com.abacogroup.cropplan.api.payload.RenamePlotPayload;
import com.abacogroup.cropplan.api.payload.RestorePlotDefaultPayload;
import com.abacogroup.cropplan.api.payload.RestorePlotsDefaultPayload;
import com.abacogroup.cropplan.api.payload.ResumePlotPayload;
import com.abacogroup.cropplan.db.dao.DAOContainer;
import com.abacogroup.cropplan.db.dao.PlotEditDAO;
import com.abacogroup.cropplan.exceptions.CropPlanNotWriteableException;
import com.abacogroup.cropplan.exceptions.CropPlanReadOnlyException;
import com.abacogroup.cropplan.exceptions.LockException;
import com.abacogroup.cropplan.exceptions.NoPlotVersionsFoundInFirstVersionException;
import com.abacogroup.cropplan.exceptions.NoVersionsFoundException;
import com.abacogroup.cropplan.exceptions.PlotNotEditableException;
import com.abacogroup.cropplan.managers.PluginManager;
import com.abacogroup.cropplan.resources.dtos.PlotsDeleteDto;
import com.abacogroup.cropplan.sdk.model.layers.CuttableLayer;
import com.abacogroup.cropplan.services.BaseService;
import com.abacogroup.cropplan.services.CropPlanConfigService;
import com.abacogroup.cropplan.services.CropPlanService;
import com.abacogroup.cropplan.services.LocksService;
import com.abacogroup.cropplan.services.PersistEditorResult;
import com.abacogroup.cropplan.services.PlotEditService;
import com.abacogroup.cropplan.services.ValidatorService;
import com.abacogroup.cropplan.services.support.EditorSupportParams;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.plugins.sdk.RuntimeEnvironment;
import com.codahale.metrics.annotation.Timed;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.ForbiddenException;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.SecurityContext;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@Path("{tenant}/api-priv/v1/crop-plans")
@Tag(name = "PRIVATE - Plot edit resources")
@Timed
@RolesAllowed({"CRPL|USER","CRPL|EDITOR"})
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class PlotEditResources extends BasePlotEditResource
{
	private CropPlanConfigService cropPlanConfigService;
	private PlotEditService plotEditService;
	private PlotEditDAO plotEditDAO;

	public PlotEditResources(BaseService baseService, CropPlanConfigService cropPlanConfigService, PlotEditService plotEditService, 
		CropPlanService cropPlanService, LocksService locksService, ValidatorService validatorService,
			DAOContainer daocontainer, PluginManager pluginManager)
	{
		super(baseService, cropPlanConfigService, plotEditService, cropPlanService, locksService, validatorService);
		this.cropPlanConfigService = cropPlanConfigService;
		this.plotEditService = plotEditService;
		this.plotEditDAO = daocontainer.getPlotEditDAO();
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/cut-lines/preview")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Preview a cut plots by line operation")
	@ApiResponses({
		@ApiResponse(description = "The cut plots by line preview operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotPreviewResult cutPlotsByLinePreview(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The subdomain zone ID") @QueryParam("subdomainZoneId") Long subdomainZoneId,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid CutPlotsByLinePayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
				.subdomainZoneId(subdomainZoneId)
			.build();

		return plotEditService.cutPlotsByLinePreview(env, params, payload);
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/cut-lines")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Cut plots by line")
	@ApiResponses({
		@ApiResponse(description = "The cut plots by line operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotResult cutPlotsByLine(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The subdomain zone ID") @QueryParam("subdomainZoneId") Long subdomainZoneId,
		@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid CutPlotsByLinePayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
				.subdomainZoneId(subdomainZoneId)
			.build();
		
		return plotEditService.cutPlotsByLine(env, params, payload, ignoreDeclValidationWarnings);
	}
	
	@POST
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/cut-geometries/preview")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Preview a cut plots by geometries operation")
	@ApiResponses({
		@ApiResponse(description = "The cut plots by geometries preview operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotPreviewResult cutPlotsByGeometriesPreview(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The subdomain zone ID") @QueryParam("subdomainZoneId") Long subdomainZoneId,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid CutPlotsByGeometriesPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
				.subdomainZoneId(subdomainZoneId)
			.build();

		return plotEditService.cutPlotsByGeometriesPreview(env, params, payload);
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/cut-geometries")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Cut plots by geometries")
	@ApiResponses({
		@ApiResponse(description = "The cut plots by geometries operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotResult cutPlotsByGeometries(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The subdomain zone ID") @QueryParam("subdomainZoneId") Long subdomainZoneId,
		@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid CutPlotsByGeometriesPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
				.subdomainZoneId(subdomainZoneId)
			.build();

		return plotEditService.cutPlotsByGeometries(env, params, payload, ignoreDeclValidationWarnings);
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/cuttable-layers")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Returns the list of cuttable layers")
	@ApiResponses({
		@ApiResponse(description = "The list of cuttable layers"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public List<CuttableLayer> getCuttableLayers(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The subdomain zone ID") @QueryParam("subdomainZoneId") Long subdomainZoneId,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid GetCuttableLayersPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
			.subdomainZoneId(subdomainZoneId)
			.build();

		return plotEditService.getCuttableLayers(env, params, payload);
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/cut-by-layer/preview")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Preview a cut plots by layer operation")
	@ApiResponses({
		@ApiResponse(description = "The cut plots by layer preview operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotPreviewResult cutPlotsByLayerPreview(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The subdomain zone ID") @QueryParam("subdomainZoneId") Long subdomainZoneId,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid CutPlotsByLayerPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
				.subdomainZoneId(subdomainZoneId)
			.build();

		return plotEditService.cutPlotsByLayerPreview(env, params, payload);
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/cut-by-layer")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Cut plots by layer")
	@ApiResponses({
		@ApiResponse(description = "The cut plots by layer operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotResult cutPlotsByLayer(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The subdomain zone ID") @QueryParam("subdomainZoneId") Long subdomainZoneId,
		@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid CutPlotsByLayerPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
				.subdomainZoneId(subdomainZoneId)
			.build();

		return plotEditService.cutPlotsByLayer(env, params, payload, ignoreDeclValidationWarnings);
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/preview")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Preview a plot creation operation")
	@ApiResponses({
		@ApiResponse(description = "The plot creation preview operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotPreviewResult createPlotPreview(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The subdomain zone ID") @QueryParam("subdomainZoneId") Long subdomainZoneId,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid InsertPlotPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
				.subdomainZoneId(subdomainZoneId)
			.build();

		return plotEditService.createPlotPreview(env, params, payload);
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Create a plot")
	@ApiResponses({
		@ApiResponse(description = "The plot creation operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotResult createPlot(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The subdomain zone ID") @QueryParam("subdomainZoneId") Long subdomainZoneId,
		@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid InsertPlotPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
				.subdomainZoneId(subdomainZoneId)
			.build();

		return plotEditService.createPlot(env, params, payload, ignoreDeclValidationWarnings, false);
	}

	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/{plotCode}/preview")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Preview a plot update operation")
	@ApiResponses({
		@ApiResponse(description = "The plot update preview operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "The plot is not editable", content = @Content(schema = @Schema(implementation = PlotNotEditableException.PlotNotEditableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotPreviewResult updatePlotPreview(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The subdomain zone ID") @QueryParam("subdomainZoneId") Long subdomainZoneId,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid EditPlotPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
				.subdomainZoneId(subdomainZoneId)
			.build();
		checkPlotEditability(env, params, payload.getFromPointInTime(), plotCode);

		return plotEditService.updatePlotPreview(env, params, plotCode, payload);
	}

	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/{plotCode}")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Update a plot")
	@ApiResponses({
		@ApiResponse(description = "The plot update operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "The plot is not editable", content = @Content(schema = @Schema(implementation = PlotNotEditableException.PlotNotEditableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotResult updatePlot(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
			@Parameter(description = "The subdomain zone ID") @QueryParam("subdomainZoneId") Long subdomainZoneId,
		@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid EditPlotPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
				.subdomainZoneId(subdomainZoneId)
			.build();
		
		checkPlotEditability(env, params, payload.getFromPointInTime(), plotCode);

		return plotEditService.updatePlot(env, params, plotCode, payload, ignoreDeclValidationWarnings);
	}

	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/{plotCode}/name")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Rename a plot")
	@ApiResponses({
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public void renamePlot(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid RenamePlotPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		checkCanWrite(env, businessId, cropPlanId, null);
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.build();

		plotEditService.renamePlot(env, params, plotCode, payload);
	}

	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/preview")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Preview a plots update operation")
	@ApiResponses({
		@ApiResponse(description = "The plots update preview operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "The plot is not editable", content = @Content(schema = @Schema(implementation = PlotNotEditableException.PlotNotEditableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotPreviewResult updatePlotsPreview(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The subdomain zone ID") @QueryParam("subdomainZoneId") Long subdomainZoneId,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid EditPlotsPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
				.subdomainZoneId(subdomainZoneId)
			.build();
		payload.getPlots().forEach(p -> checkPlotEditability(env, params, payload.getFromPointInTime(), p.getPlotCode()));

		return plotEditService.updatePlotsPreview(env, params, payload);
	}

	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Update plots")
	@ApiResponses({
		@ApiResponse(description = "The plots update operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "The plot is not editable", content = @Content(schema = @Schema(implementation = PlotNotEditableException.PlotNotEditableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotResult updatePlots(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The subdomain zone ID") @QueryParam("subdomainZoneId") Long subdomainZoneId,
		@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid EditPlotsPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
				.subdomainZoneId(subdomainZoneId)
			.build();
		payload.getPlots().forEach(p -> checkPlotEditability(env, params, payload.getFromPointInTime(), p.getPlotCode()));

		return plotEditService.updatePlots(env, params, payload, ignoreDeclValidationWarnings);
	}

	@DELETE
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/{plotCode}")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Delete a plot")
	@ApiResponses({
		@ApiResponse(description = "The plot delete operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "The plot is not editable", content = @Content(schema = @Schema(implementation = PlotNotEditableException.PlotNotEditableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotResult deletePlot(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("fromPointInTime") @NotNull @Valid AbsoluteDate fromPointInTime,
		@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(fromPointInTime.toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			fromPointInTime = cropPlanConfigService.getFixedEditDate(cropPlanId, fromPointInTime);
		checkCanWrite(env, businessId, cropPlanId, fromPointInTime);
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
			.build();
		checkPlotEditability(env, params, fromPointInTime, plotCode);

		PersistEditorResult result = plotEditService.deletePlot(env, params, plotCode, fromPointInTime, ignoreDeclValidationWarnings, false);
		return result.getEditPlotResult();
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/delete-plots")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Delete a list of plots")
	@ApiResponses({
		@ApiResponse(description = "The plot delete operation results"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "The plot is not editable", content = @Content(schema = @Schema(implementation = PlotNotEditableException.PlotNotEditableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotResult deletePlotByPlotCodes(
		@Context SecurityContext context,
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "List of plot codes to be deleted") @NotNull @Valid PlotsDeleteDto plotsDeleteDto,
		@Parameter(description = "The point in time to be evaluated") @QueryParam("fromPointInTime") @NotNull @Valid AbsoluteDate fromPointInTime,
		@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
		@HeaderParam("accept-language") @DefaultValue("en") String language)
	{
		if (!context.isUserInRole("CRPL|CAN_DELETE_PLOTS"))
			throw new ForbiddenException("You are not allowed to delete multiple plots");

		if (plotsDeleteDto.getPlotCodes().stream().anyMatch(Objects::isNull)) {
			throw new BadRequestException("Plot codes cannot be null");
		}

		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(fromPointInTime.toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			fromPointInTime = cropPlanConfigService.getFixedEditDate(cropPlanId, fromPointInTime);
		checkCanWrite(env, businessId, cropPlanId, fromPointInTime);
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
			.build();

		for (String plotCode: plotsDeleteDto.getPlotCodes()) {
			checkPlotEditability(env, params, fromPointInTime, plotCode);
		}

		PersistEditorResult result = plotEditService.deletePlots(env, params, plotsDeleteDto.getPlotCodes(), fromPointInTime, ignoreDeclValidationWarnings, false);
		return result.getEditPlotResult();
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/{plotCode}/merged_plots/preview")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Preview a plots merge operation")
	@ApiResponses({
		@ApiResponse(description = "The plots merge preview operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "The plot is not editable", content = @Content(schema = @Schema(implementation = PlotNotEditableException.PlotNotEditableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotPreviewResult mergePlotsPreview(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid MergePlotsPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
			.build();
		payload.getPlotCodes().forEach(pc -> checkPlotEditability(env, params, payload.getFromPointInTime(), pc));

		return plotEditService.mergePlotsPreview(env, params, plotCode, payload);
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/{plotCode}/merged_plots")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Merge plots")
	@ApiResponses({
		@ApiResponse(description = "The plots merge operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "The plot is not editable", content = @Content(schema = @Schema(implementation = PlotNotEditableException.PlotNotEditableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotResult mergePlots(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
		@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid MergePlotsPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
			.build();
		payload.getPlotCodes().forEach(pc -> checkPlotEditability(env, params, payload.getFromPointInTime(), pc));

		return plotEditService.mergePlots(env, params, plotCode, payload, ignoreDeclValidationWarnings);
	}
	
	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/{plotCode}/restore_default")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Restore plot default")
	@ApiResponses({
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "The plot is not editable", content = @Content(schema = @Schema(implementation = PlotNotEditableException.PlotNotEditableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotResult restorePlotDefault(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
		@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid RestorePlotDefaultPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
			.build();
		checkPlotEditability(env, params, payload.getFromPointInTime(), plotCode);

		return plotEditService.restorePlotsDefault(env, params, Arrays.asList(plotCode), payload.getFromPointInTime(), ignoreDeclValidationWarnings);
	}
	
	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/restore_default")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Restore plots default")
	@ApiResponses({
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "The plot is not editable", content = @Content(schema = @Schema(implementation = PlotNotEditableException.PlotNotEditableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotResult restorePlotsDefault(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid RestorePlotsDefaultPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
			.build();
		payload.getPlotCodes().forEach(p -> checkPlotEditability(env, params, payload.getFromPointInTime(), p));

		return plotEditService.restorePlotsDefault(env, params, payload.getPlotCodes(), payload.getFromPointInTime(), ignoreDeclValidationWarnings);
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/line-buffer/preview")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Preview a line buffer drawing operation")
	@ApiResponses({
		@ApiResponse(description = "The line buffer drawing preview operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "The plot is not editable", content = @Content(schema = @Schema(implementation = PlotNotEditableException.PlotNotEditableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotPreviewResult drawLineBufferPreview(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The subdomain zone ID") @QueryParam("subdomainZoneId") Long subdomainZoneId,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid DrawLineBufferPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
				.subdomainZoneId(subdomainZoneId)
			.build();

		return plotEditService.drawLineBufferPreview(env, params, payload);
	}

	@POST
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/line-buffer")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Draw a line buffer")
	@ApiResponses({
		@ApiResponse(description = "The line buffer drawing operation result"),
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "The plot is not editable", content = @Content(schema = @Schema(implementation = PlotNotEditableException.PlotNotEditableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class)))
	})
	public EditPlotResult drawLineBuffer(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
			@Parameter(description = "The subdomain zone ID") @QueryParam("subdomainZoneId") Long subdomainZoneId,
		@Parameter(description = "If it is set to true then the declarations validation warnings will be ignored") @QueryParam("ignoreDeclValidationWarnings") @DefaultValue("false") boolean ignoreDeclValidationWarnings,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid DrawLineBufferPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		var pointInTime = AbsoluteDate.of(payload.getFromPointInTime().toLocalDate());
		if (cropPlanConfigService.isForceEditAtFixedDate(cropPlanId))
			payload.setFromPointInTime(cropPlanConfigService.getFixedEditDate(cropPlanId, payload.getFromPointInTime()));
		checkCanWrite(env, businessId, cropPlanId, payload.getFromPointInTime());
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(pointInTime)
				.subdomainZoneId(subdomainZoneId)
			.build();

		return plotEditService.drawLineBuffer(env, params, payload, ignoreDeclValidationWarnings);
	}
	
	@PUT
	@Path("/{businessId}/plans/{cropPlanId}/{domainZoneId}/plots/{plotCode}/resume-first-version")
	@RolesAllowed("CRPL|EDITOR")
	@Operation(description = "Resume plot from crop plan first version")
	@ApiResponses({
		@ApiResponse(responseCode = "404", description = "The specified domainZoneId was not found"),
		@ApiResponse(responseCode = "409", description = "You do not hold this crop plan lock", content = @Content(schema = @Schema(implementation = LockException.LockExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "The plot is not editable", content = @Content(schema = @Schema(implementation = PlotNotEditableException.PlotNotEditableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "The crop plan is read only", content = @Content(schema = @Schema(implementation = CropPlanReadOnlyException.CropPlanReadOnlyExceptionErrorBody.class))),
		@ApiResponse(responseCode = "403", description = "You are not allowed to change this business crop plan", content = @Content(schema = @Schema(implementation = CropPlanNotWriteableException.CropPlanNotWriteableExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "No versions found", content = @Content(schema = @Schema(implementation = NoVersionsFoundException.NoVersionsFoundExceptionErrorBody.class))),
		@ApiResponse(responseCode = "404", description = "No plot versions found in first version", content = @Content(schema = @Schema(implementation = NoPlotVersionsFoundInFirstVersionException.NoPlotVersionsFoundInFirstVersionExceptionErrorBody.class)))
	})
	public void resumePlotFromCropPlanFirstVersion(
		@Parameter(hidden = true) @Auth User user,
		@Parameter(description = "The tenant ID") @PathParam("tenant") String tenantId,
		@Parameter(description = "The business ID") @PathParam("businessId") String businessId,
		@Parameter(description = "The crop plan ID") @PathParam("cropPlanId") Long cropPlanId,
		@Parameter(description = "The domain zone ID") @PathParam("domainZoneId") String domainZoneId,
		@Parameter(description = "The plot code") @PathParam("plotCode") String plotCode,
		@HeaderParam("accept-language") @DefaultValue("en") String language,
		@NotNull @Valid ResumePlotPayload payload)
	{
		RuntimeEnvironment env = createEnvironment(user, language);
		
		checkCanWrite(env, businessId, cropPlanId, null);
		checkLock(env, cropPlanId);

		var versionDt = plotEditDAO.getCurrentTimestamp();
		var params = EditorSupportParams.builder()
			.businessId(businessId)
			.cropPlanId(cropPlanId)
			.domainZoneId(domainZoneId)
			.versionDt(versionDt)
			.pointInTime(payload.getPointInTime())
			.build();

		plotEditService.resumePlotFromCropPlanFirstVersion(env, params, plotCode);
	}

}
