package com.abacogroup.cropplan.api;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Crop plan dates")
public class CropPlanDates {
	
	@Schema(description = "The campaign start date")
	private AbsoluteDate campaignStartDate;
	
	@Schema(description = "The reference date")
	@NotNull
	private AbsoluteDate referenceDate;
	
	@Schema(description = "The fixed open date")
	@Deprecated
	private AbsoluteDate fixedOpenDate;
	
	@Schema(description = "The fixed edit date")
	private AbsoluteDate fixedEditDate;

	@Schema(description = "The last sync reference date")
	private AbsoluteDate lastSyncReferenceDate;
	
}
