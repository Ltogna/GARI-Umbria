package com.abacogroup.cropplan.db.dao;

import com.abacogroup.cropplan.api.PestCode;
import com.abacogroup.cropplan.api.PestEntry;
import com.abacogroup.cropplan.api.payload.InsertDeclPestPayload;
import com.abacogroup.cropplan.sdk.mapper.VersionColumnMapper;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transaction;

@RegisterColumnMapper(VersionColumnMapper.class)
@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface PestsDAO extends BasicDAO, EnhancedSqlObject
{
	@SqlQuery("§select_nextval(crpl_decl_pests_seq)§")
	public Long getDeclPestsSeq();


	@SqlUpdate("insert into CRPL_DECL_PESTS (id, pest_entry_code, plan_id, plot_code, decl_code, pest_code, percentage_area_affected, measures_applied, entry_date, user_id_insert, dt_insert, dt_delete, transaction_id, fl_versioned)"
		+ "      values (:id, :pestEntryCode, :cropPlanId, :plotCode, :declCode, :pestCode, :percentage_area_affected,:measures_applied, :date, :userId, :insertDt, TO_DATE('99991231','YYYYMMDD'), null, 0)")
	public void insertPest(
		@Bind("id") Long id, 
		@Bind("pestEntryCode") String pestEntryCode,
		@Bind("cropPlanId") Long cropPlanId, 
		@Bind("plotCode") String plotCode, 
		@Bind("declCode") String declCode, 
		@Bind("pestCode") String pestCode,
		@Bind("percentage_area_affected") Long percentage_area_affected,
		@Bind("measures_applied") String measures_applied,
		@Bind("date") AbsoluteDate date,
		@Bind("userId") String userId, 
		@Bind("insertDt") LocalDateTime insertDt);


	@SqlQuery("select distinct cdp.pest_code as pestCode"
	+ "      from CRPL_DECL_PESTS cdp, crpl_declarations cd"
	+ "		where cdp.plan_id = :planId"
	+ "       and :versionDt between cdp.dt_insert and cdp.dt_delete"
	+ "       and :versionDt between cd.dt_insert and cd.dt_delete"
	+ "       and cd.decl_code = cdp.decl_code"
	+ "       and cdp.pest_code not in (select c.code from cache_decodes c, crpl_plans cp where c.type = :cacheDecodesType and cp.type_id = c.type_id and cp.id = :planId)")
	@RegisterBeanMapper(PestCode.class)
	public List<PestCode> getPestCodesNotInCache(@Bind("planId") Long planId,
		@Bind("versionDt") LocalDateTime versionDt,
		@Bind("cacheDecodesType") String cacheDecodesType);


	@SqlQuery("select cdp.pest_entry_code as pestEntryCode,"
		+ "      	  cdp.plan_id as planId,"
		+ "      	  cdp.plot_code as plotCode,"
		+ "      	  cdp.decl_code as declCode,"
		+ "      	  cdp.pest_code as pestCode,"
		+ "      	  cdp.percentage_area_affected as areaAffected,"
		+ "      	  cdp.measures_applied as measuresApplied,"
		+ "           cdp.entry_date as entryDate,"
		+ "           c_deco.description as pestName,"
		+ "           c_deco_q.description as quarantineDays,"
		+ "           cdp.user_id_insert as userId"
		+ "      from CRPL_DECL_PESTS cdp, crpl_declarations cd, cache_decodes c_deco, cache_decodes c_deco_q"
		+ "		where cdp.plan_id = :planId"
		+ "		  and (:plotCode is null or cdp.plot_code = :plotCode)"
		+ "		  and (:declCode is null or cdp.decl_code = :declCode)"
		+ "		  and (:pestEntryCode is null or cdp.pest_entry_code = :pestEntryCode)"
		+ "       and :version between cdp.dt_insert and cdp.dt_delete"
		+ "       and :version between cd.dt_insert and cd.dt_delete"
		+ "       and (:search is null or upper( c_deco.description) like '%'||upper(:search)||'%')"
		+ "       and cd.decl_code = cdp.decl_code"
		+ "       and cd.plot_code = cdp.plot_code"
		+ "       and cdp.pest_code = c_deco.code"
		+ "       and c_deco.type = :cachePestType"
		+ "       and cdp.pest_code = c_deco_q.code"
		+ "       and c_deco_q.type = :cachePestTypeQuarantineDays"
		+ "  order by pestEntryCode"
		)
	@RegisterBeanMapper(PestEntry.class)
	public ResultIterator<PestEntry> getPestEntries(
		@Bind("planId") Long planId,		
		@Bind("version") LocalDateTime version,
		@Bind("plotCode") String plotCode,
		@Bind("declCode") String declCode,
		@Bind("pestEntryCode") String pestEntryCode, 
		@Bind("search") String search,
		@Bind("cachePestType") String cachePestType,
		@Bind("cachePestTypeQuarantineDays") String cachePestTypeQuarantineDays
		);

	@SqlUpdate("update CRPL_DECL_PESTS"
		+ "        set DT_DELETE = :deleteDt, USER_ID_DELETE = :userId, transaction_id = null"
		+ "      where (:pestEntryCode is null or pest_entry_code = :pestEntryCode)"
		+ "        and DECL_CODE = :declCode"
		+ "        and plot_code = :plotCode"
		+ "        and PLAN_ID = :cropPlanId"
		+ "        and §current_timestamp§ between DT_INSERT and DT_DELETE")
	public int deletePestsInternal(@Bind("pestEntryCode") String pestEntryCode, @Bind("declCode") String declCode, @Bind("plotCode") String plotCode,
		@Bind("cropPlanId") Long cropPlanId, @Bind("deleteDt") LocalDateTime deleteDt, @Bind("userId") String userId);

	@Transaction
	default public void updatePest(String pestEntryCode, String declCode, String plotCode, Long cropPlanId, LocalDateTime updateDt, String userId, InsertDeclPestPayload payload)
	{
		//TODO [Edoardo] se provo ad aggiornare un pest che non esiste o non viene trovato da un 500, da gestire meglio
		var entry = infinite(() -> getPestEntries(cropPlanId, updateDt, plotCode, declCode, pestEntryCode, null, CacheDecodesDAO.CACHE_DECODES_TYPE.PESTS.toString(), CacheDecodesDAO.CACHE_DECODES_TYPE.PESTS_QUARANTINE_DAYS.toString()), null, 1).getRecords().get(0);
		deletePestsInternal(pestEntryCode, declCode, plotCode, cropPlanId, updateDt.minus(Duration.ofMillis(1)), userId);
		insertPest(getDeclPestsSeq(), pestEntryCode, cropPlanId, plotCode, declCode, payload.getPestCode(), payload.getAreaAffected(), payload.getMeasuresApplied(), entry.getEntryDate(), userId, updateDt);
	}
}

