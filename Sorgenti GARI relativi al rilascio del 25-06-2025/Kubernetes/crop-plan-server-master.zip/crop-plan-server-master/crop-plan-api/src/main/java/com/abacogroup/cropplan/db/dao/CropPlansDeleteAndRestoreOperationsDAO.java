package com.abacogroup.cropplan.db.dao;

import java.time.LocalDateTime;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transaction;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.cropplan.sdk.mapper.VersionColumnMapper;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(VersionColumnMapper.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface CropPlansDeleteAndRestoreOperationsDAO
		extends CommonPcfDAO, CommonLandUseAdtFldDAO, Transactional<CropPlansDeleteAndRestoreOperationsDAO> {

	@SqlUpdate("DELETE FROM crpl_decl_addit_fields " +
			"    WHERE DT_INSERT > :versionDt " +
			"      AND PLAN_ID = :cropPlanId ")
	public void deleteUnversionedDeclAdditFieldsInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("DELETE FROM crpl_decl_pests " +
			"    WHERE DT_INSERT > :versionDt " +
			"      AND PLAN_ID = :cropPlanId ")
	public void deleteUnversionedDeclPestsInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("DELETE FROM crpl_decl_pesticides " +
			"    WHERE DT_INSERT > :versionDt " +
			"      AND PLAN_ID = :cropPlanId ")
	public void deleteUnversionedDeclPesticidesInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("DELETE FROM crpl_perm_crop_forms " +
			"    WHERE DT_INSERT > :versionDt " +
			"      AND PLAN_ID = :cropPlanId ")
	public void deleteUnversionedPermCropFormsInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("DELETE FROM crpl_declarations " +
			"    WHERE DT_INSERT > :versionDt " +
			"      AND PLAN_ID = :cropPlanId ")
	public void deleteUnversionedDeclarationsInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("DELETE FROM crpl_plot_names " +
			"    WHERE DT_INSERT > :versionDt " +
			"      AND PLAN_ID = :cropPlanId ")
	public void deleteUnversionedPlotNamesInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("DELETE FROM crpl_parcel_data " +
			"    WHERE DT_INSERT > :versionDt " +
			"      AND PLAN_ID = :cropPlanId ")
	public void deleteUnversionedParcelDataInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("DELETE FROM crpl_plot_data " +
			"    WHERE DT_INSERT > :versionDt " +
			"      AND PLAN_ID = :cropPlanId ")
	public void deleteUnversionedPlotDataInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("DELETE FROM crpl_anomalies " +
			"    WHERE DT_INSERT > :versionDt " +
			"      AND PLAN_ID = :cropPlanId ")
	public void deleteUnversionedAnomaliesInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("DELETE FROM crpl_sync " +
			"    WHERE DT_SYNC > :versionDt " +
			"      AND PLAN_ID = :cropPlanId ")
	public void deleteSyncsInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("UPDATE crpl_decl_addit_fields " +
			"      SET DT_DELETE = TO_DATE('99991231','YYYYMMDD'), " +
			"          USER_ID_DELETE = NULL " +
			"    WHERE DT_DELETE > :versionDt " +
			"      AND PLAN_ID = :cropPlanId")
	public void restoreDeclAdditFieldsInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("UPDATE crpl_decl_pests " +
			"      SET DT_DELETE = TO_DATE('99991231','YYYYMMDD'), " +
			"          USER_ID_DELETE = NULL " +
			"    WHERE DT_DELETE > :versionDt " +
			"      AND PLAN_ID = :cropPlanId")
	public void restoreDeclPestsInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("UPDATE crpl_decl_pesticides " +
			"      SET DT_DELETE = TO_DATE('99991231','YYYYMMDD'), " +
			"          USER_ID_DELETE = NULL " +
			"    WHERE DT_DELETE > :versionDt " +
			"      AND PLAN_ID = :cropPlanId")
	public void restoreDeclPesticidesInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("UPDATE crpl_perm_crop_forms " +
			"      SET DT_DELETE = TO_DATE('99991231','YYYYMMDD'), " +
			"          USER_ID_DELETE = NULL " +
			"    WHERE DT_DELETE > :versionDt " +
			"      AND PLAN_ID = :cropPlanId")
	public void restorePermCropFormsInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("UPDATE crpl_declarations " +
			"      SET DT_DELETE = TO_DATE('99991231','YYYYMMDD'), " +
			"          USER_ID_DELETE = NULL " +
			"    WHERE DT_DELETE > :versionDt " +
			"      AND PLAN_ID = :cropPlanId")
	public void restoreDeclarationsInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("UPDATE crpl_plot_names " +
			"      SET DT_DELETE = TO_DATE('99991231','YYYYMMDD'), " +
			"          USER_ID_DELETE = NULL " +
			"    WHERE DT_DELETE > :versionDt " +
			"      AND PLAN_ID = :cropPlanId")
	public void restorePlotNamesInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("UPDATE crpl_parcel_data " +
			"      SET DT_DELETE = TO_DATE('99991231','YYYYMMDD'), " +
			"          USER_ID_DELETE = NULL " +
			"    WHERE DT_DELETE > :versionDt " +
			"      AND PLAN_ID = :cropPlanId")
	public void restoreParcelDataInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("UPDATE crpl_plot_data " +
			"      SET DT_DELETE = TO_DATE('99991231','YYYYMMDD'), " +
			"          USER_ID_DELETE = NULL " +
			"    WHERE DT_DELETE > :versionDt " +
			"      AND PLAN_ID = :cropPlanId")
	public void restorePlotDataInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@SqlUpdate("UPDATE crpl_anomalies " +
			"      SET DT_DELETE = TO_DATE('99991231','YYYYMMDD'), " +
			"          USER_ID_DELETE = NULL " +
			"    WHERE DT_DELETE > :versionDt " +
			"      AND PLAN_ID = :cropPlanId")
	public void restoreAnomaliesInternal(@Bind("cropPlanId") Long cropPlanId, @Bind("versionDt") LocalDateTime versionDt);

	@Transaction
	public default void restoreLastVersion(Long cropPlanId, LocalDateTime versionDt) {
		deleteUnversionedDeclPesticidesInternal(cropPlanId, versionDt);
		deleteUnversionedPermCropFormsInternal(cropPlanId, versionDt);
		deleteUnversionedDeclarationsInternal(cropPlanId, versionDt);
		deleteUnversionedPlotNamesInternal(cropPlanId, versionDt);
		deleteUnversionedParcelDataInternal(cropPlanId, versionDt);
		deleteUnversionedPlotDataInternal(cropPlanId, versionDt);
		deleteUnversionedAnomaliesInternal(cropPlanId, versionDt);
		deleteUnversionedDeclAdditFieldsInternal(cropPlanId, versionDt);
		deleteUnversionedDeclPestsInternal(cropPlanId, versionDt);

		restoreDeclPesticidesInternal(cropPlanId, versionDt);
		restorePermCropFormsInternal(cropPlanId, versionDt);
		restoreDeclarationsInternal(cropPlanId, versionDt);
		restorePlotNamesInternal(cropPlanId, versionDt);
		restoreParcelDataInternal(cropPlanId, versionDt);
		restorePlotDataInternal(cropPlanId, versionDt);
		restoreAnomaliesInternal(cropPlanId, versionDt);
		restoreDeclAdditFieldsInternal(cropPlanId, versionDt);
		restoreDeclPestsInternal(cropPlanId, versionDt);

		deleteSyncsInternal(cropPlanId, versionDt);
	}
}
