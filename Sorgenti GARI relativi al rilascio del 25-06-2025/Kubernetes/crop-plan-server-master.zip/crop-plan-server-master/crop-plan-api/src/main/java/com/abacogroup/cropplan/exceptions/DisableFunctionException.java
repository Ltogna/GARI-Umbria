package com.abacogroup.cropplan.exceptions;

import com.abacogroup.cropplan.api.DisabledFunctionCode;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class DisableFunctionException extends WebApplicationException
{
	private static final long serialVersionUID = -670320492611801915L;

	public static  class DisableFunctionExceptionErrorBody
	{
		@Schema(allowableValues = "DISABLE_FUNCTION_EXCEPTION")
		public String getErrorCode()
		{
			return "DISABLE_FUNCTION_EXCEPTION";
		}
	}
	
	private static final DisableFunctionExceptionErrorBody BODY = new DisableFunctionExceptionErrorBody();

	public DisableFunctionException(DisabledFunctionCode functionCode,String plotCode)
	{
		super("Disabled Function " + functionCode + " for the plot " + plotCode,
			Response.status(Status.BAD_REQUEST).entity(BODY).build());
	}
}
