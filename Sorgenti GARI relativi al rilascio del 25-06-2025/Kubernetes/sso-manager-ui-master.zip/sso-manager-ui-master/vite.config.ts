import vue from "@vitejs/plugin-vue";
import { execSync } from "child_process";
import { fileURLToPath, URL } from "url";
import { defineConfig, type ConfigEnv, loadEnv } from "vite";
import { viteStaticCopy } from "vite-plugin-static-copy";
import nodePackage from "./package.json";
import VueDevTools from "vite-plugin-vue-devtools";

export default function (config: ConfigEnv) {
  process.env = {
    ...process.env,
    ...loadEnv(config.mode, process.cwd(), ["VITE"]),
    VITE_APP_VERSION: nodePackage.version,
    VITE_APP_GIT_COMMIT: execSync("git rev-parse --short=8 HEAD").toString().trim(),
  };

  const forceContext = process.env.VITE_FORCED_CONTEXT ?? "";

  // https://vitejs.dev/config/
  return defineConfig({
    define: {
      // enable hydration mismatch details in production build
      __VUE_PROD_HYDRATION_MISMATCH_DETAILS__: "true",
    },
    plugins: [
      viteStaticCopy({
        targets: [
          {
            src: "node_modules/bootstrap-italia/dist/**/*",
            dest: "bootstrap-italia/dist",
          },
        ],
      }),
      vue(),
      VueDevTools(),
    ],
    base: `${forceContext}${process.env.VITE_BASE}`,
    resolve: {
      alias: {
        "@": fileURLToPath(new URL("./src", import.meta.url)),
      },
    },
    css: {
      devSourcemap: true,
    },
    build: {
      // target: "esnext",
      rollupOptions: {
        output: {
          entryFileNames: "[name].[hash].js",
          assetFileNames: "assets/[name].[hash].[ext]",
        },
      },
    },
    server: {
      port: 3000,
      proxy: {
        [`${forceContext}/sso2`]: {
          target: "https://iacs-dev.fe.abacogroup.eu/",
          // target: "http://localhost:8082/",
          rewrite: (url) => url.replace(forceContext, ""),
          secure: false,
          changeOrigin: true,
        },
      },
    },
  });
}
