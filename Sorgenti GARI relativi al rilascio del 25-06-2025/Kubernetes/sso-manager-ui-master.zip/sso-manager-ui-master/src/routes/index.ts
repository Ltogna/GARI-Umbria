import { RouteName } from "@/models/routes";
import type { RouteRecordRaw } from "vue-router";

function getRoutes(basePath = "/") {
  if (!basePath?.endsWith("/")) {
    basePath += "/";
  }
  const routes: RouteRecordRaw[] = [];

  routes.push({
    path: "",
    redirect: { name: RouteName.SEARCH },
  });
  routes.push({
    path: "/search",
    name: RouteName.SEARCH,
    component: () => import("../views/SearchView.vue"),
  });
  routes.push({
    path: "/users",
    name: RouteName.USERS_LIST,
    component: () => import("../views/UsersView.vue"),
  });

  routes.push({
    path: "/users/:username",
    name: RouteName.USER_DETAILS,
    component: () => import("../views/UserDetailsView.vue"),
  });

  routes.push({
    path: "/users/:username/roles",
    name: RouteName.ROLES_LIST,
    component: () => import("../views/RolesListView.vue"),
  });

  routes.push({
    path: "/users/create",
    components: {
      default: () => import("../views/UserCreateView.vue"),
      leaveConfirmationModal: () => import("../components/LeaveDirtyPageModal.vue"),
    },
    children: [
      {
        path: "",
        name: RouteName.USER_CREATE,
        component: () => import("../components/users/UserCreateForm.vue"),
      },
    ],
  });

  routes.push({
    path: "/users/:username/edit",
    components: {
      default: () => import("../views/UserEditView.vue"),
      leaveConfirmationModal: () => import("../components/LeaveDirtyPageModal.vue"),
    },
    children: [
      {
        path: "",
        name: RouteName.USER_EDIT,
        component: () => import("../components/users/UserEditForm.vue"),
      },
    ],
  });

  return routes;
}

export default getRoutes;
