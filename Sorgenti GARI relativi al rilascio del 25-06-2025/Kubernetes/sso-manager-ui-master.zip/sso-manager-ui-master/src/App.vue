<script setup lang="ts">
import BiCallout from "@abaco/bootstrap-italia-components/src/components/BiCallout/BiCallout.vue";
import { useAlertsStore } from "@abaco/bootstrap-italia-components/src/stores/alertsStore";
import { computed, inject, onUnmounted, onMounted } from "vue";
import { useI18n } from "vue-i18n";
import { RouterView } from "vue-router";
import useModuleId from "./composables/useModuleId";
import { useLanguageStore } from "./stores/language";
import { useConfigStore } from "./stores/config";

const { t } = useI18n();

const hasPermission = inject("hasPermission");
const moduleId = useModuleId();

/**
 * If user has permission to use SSO Manager
 */
const ssoManagerAllowed = computed(() => hasPermission);

const alertStore = useAlertsStore();
const { loadLanguages } = useLanguageStore();
const { loadConfig } = useConfigStore();

onMounted(async () => {
  await loadConfig();
  await loadLanguages();
});

onUnmounted(async () => {
  alertStore.$reset();
});
</script>

<template>
  <div v-if="ssoManagerAllowed" class="container sso-manager my-5">
    <main>
      <section>
        <RouterView />
        <RouterView name="leaveConfirmationModal" />
      </section>
    </main>
  </div>
  <BiCallout
    v-else
    type="danger"
    :title="t(`${moduleId}.alerts.user_not_allowed_title`)"
    class="mx-auto"
  >
    <p>{{ t(`${moduleId}.alerts.user_not_allowed_text`) }}</p>
  </BiCallout>
  <!-- <BiNotification v-bind="notificationProps" v-model="message.open" /> -->
</template>
