import { computed, ref } from "vue";
import { defineStore } from "pinia";
import type { LanguageListModel } from "@/models/users";
import { getUserLocalesList } from "@/resources/api/users";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";

export const useLanguageStore = defineStore("language", () => {
  const _languages = ref<LanguageListModel>([]);
  const _loading = ref<boolean>(true);
  const _hasError = ref<boolean>(false);

  async function loadLanguages(force: boolean = false) {
    _loading.value = true;
    _hasError.value = false;
    if (force || !_languages.value.length) {
      const resp = await getUserLocalesList();

      if (resp.errorType === ErrorType.NONE) {
        _languages.value = resp.data;
      } else {
        _hasError.value = true;
      }
    }
    _loading.value = false;
  }

  const languages = computed(() => _languages.value);
  const loading = computed(() => _loading.value);
  const hasError = computed(() => _hasError.value);

  const getLanguageDescription = computed<(code: string) => string>(
    () =>
      (code: string): string => {
        const language = _languages.value.find((lang) => lang.code === code);
        return language ? language.description ?? code : code;
      },
  );

  return { loadLanguages, languages, loading, hasError, getLanguageDescription };
});
