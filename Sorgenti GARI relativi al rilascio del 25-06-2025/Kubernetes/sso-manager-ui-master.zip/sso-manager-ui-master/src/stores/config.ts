import { ConfigSchema, type ConfigModel } from "@/models/config";
import type { UserDataModel } from "@/models/users";
import { http } from "@/resources/api/http";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";
import { computed, ref } from "vue";

export const useConfigStore = defineStore("config", () => {
  const _loading = ref<boolean>(false);
  const _config = ref<ConfigModel>({
    userProperties: [],
    allowsExternalUserRolesManagement: true,
  });
  async function loadConfig() {
    _loading.value = true;
    const res = await http.getJson(ConfigSchema, `${import.meta.env.BASE_URL}config.json`);
    if (res.errorType === ErrorType.NONE) {
      _config.value = res.data;
    }
    _loading.value = false;
  }

  const config = computed(() => _config.value);
  const loading = computed(() => _loading.value);

  const canEditRoles = computed<(user: UserDataModel) => boolean>(
    () =>
      (user: UserDataModel): boolean => {
        return (
          user.internalUser ||
          (!user.internalUser && _config.value.allowsExternalUserRolesManagement)
        );
      },
  );

  return { loadConfig, config, loading, canEditRoles };
});
