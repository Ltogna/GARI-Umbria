import i18n from "@/i18n";
import { MODULE_REF } from "@/constants";
import {
  ErrorType,
  type GenericResponseError,
  type HttpJsonResult,
  type HttpResponseError,
  type HttpResult,
} from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";

export interface State {
  message: string;
  isError: boolean;
  // #141557 added warning notification
  isWarning?: boolean;
}

const initialState: Readonly<State> = {
  message: "",
  isError: false,
  // #141557 set warning notification
  isWarning: false,
};

const state: State = structuredClone(initialState);

export const useNotificationStore = defineStore("notification", {
  state: (): State => state,
  getters: {},
  actions: {
    async setMessage(httpResponse: HttpJsonResult<unknown>) {
      const { t } = i18n.global;
      if (httpResponse.errorType === ErrorType.NONE) {
        import.meta.env.DEV && console.trace("setMessage");
        this.isError = false;
        this.message = t(`${MODULE_REF}.success.GENERIC_SAVE`);
      } else {
        await this.setErrorMessage(httpResponse);
      }
    },
    async setErrorMessage(
      httpResponse?: HttpResponseError | GenericResponseError | HttpResult,
    ) {
      import.meta.env.DEV && console.trace("setErrorMessage");
      const { t } = i18n.global;
      this.isError = true;
      if (httpResponse && httpResponse.errorType === ErrorType.HTTP_STATUS) {
        if (httpResponse.response.status === 500) {
          this.message = t(`${MODULE_REF}.errors.GENERIC_ERROR`);
          return;
        }
        try {
          const { errorCode, message } = await httpResponse.response.json();
          this.message = message || t(`${MODULE_REF}.errors.GENERIC_ERROR`);
          !message && console.warn(errorCode);
        } catch (err) {
          console.warn(err);
          this.message = t(`${MODULE_REF}.errors.GENERIC_ERROR`);
        }
      } else this.message = t(`${MODULE_REF}.errors.GENERIC_ERROR`);
    },
    setRawMessge(state: State) {
      console.trace("setRawMessge");
      this.isError = state.isError;
      // #141557 set warning notification
      this.isWarning = state.isWarning;
      this.message = state.message;
    },
    $reset() {
      this.$state = structuredClone(initialState);
    },
  },
});
