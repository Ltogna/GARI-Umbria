import { BASE } from "@/constants";
import { http } from "@/resources/api/http";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { nextTick } from "vue";
import { createI18n } from "vue-i18n";

export const DEFAULT_LANGUAGE = "en";

const i18n = createI18n({
  legacy: false,
  locale: DEFAULT_LANGUAGE,
  fallbackLocale: DEFAULT_LANGUAGE,
  // XXX WARNING
  // missingWarn: false,
  // fallbackWarn: false,
  datetimeFormats: {
    it: {
      short: {
        year: "numeric",
        month: "short",
        day: "numeric",
      },
      long: {
        year: "numeric",
        month: "long",
        day: "numeric",
        weekday: "long",
        hour: "numeric",
        minute: "numeric",
      },
    },
    en: {
      short: {
        year: "numeric",
        month: "short",
        day: "numeric",
      },
      long: {
        year: "numeric",
        month: "long",
        day: "numeric",
        weekday: "long",
        hour: "numeric",
        minute: "numeric",
      },
    },
  },
});

export function setI18nLanguage(locale: string) {
  // WARNING: datetimeFormats can't be loaded in lazyloading, but hardcoding it change the type of global.locale
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  i18n.global.locale.value = locale;

  /**
   * NOTE:
   * If you need to specify the language setting for headers, such as the `fetch` API, set it here.
   * The following is an example for axios.
   *
   * axios.defaults.headers.common['Accept-Language'] = locale
   */
  document.querySelector("html")?.setAttribute("lang", locale);
}

function getAllLocales(locale: string): Set<string> {
  const ls = locale.replace("_", "-").split("-");
  const locales = new Set<string>([DEFAULT_LANGUAGE]);
  let loc = "";
  for (let i = 0; i < ls.length; i++) {
    loc += "-" + ls[i];
    locales.add(loc.slice(1));
  }
  return locales;
}

export async function loadLocaleMessages(locale: string) {
  const lcs = [...getAllLocales(locale)];
  for (let i = 0; i < lcs.length; i++) {
    const res = await http.get(`${BASE}locales/${lcs[i]}.json`);
    if (res.errorType == ErrorType.NONE) {
      const messages = await res.response.json();
      i18n.global.mergeLocaleMessage(lcs[lcs.length - 1], messages);
    } else {
      console.error(res);
    }
  }
  setI18nLanguage(lcs[lcs.length - 1]);
  return nextTick();
}

export default i18n;
