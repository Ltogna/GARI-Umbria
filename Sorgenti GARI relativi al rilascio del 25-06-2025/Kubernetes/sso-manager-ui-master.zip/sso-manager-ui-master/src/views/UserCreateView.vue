<script setup lang="ts">
import RootNotification from "@/components/RootNotification.vue";
import UserCreateForm from "@/components/users/UserCreateForm.vue";
import UsersMainContent from "@/components/users/UsersMainContent.vue";
import useGetDateFormats from "@/composables/useGetDateFormats";
import useModuleId from "@/composables/useModuleId";
import { RouteName } from "@/models/routes";
import { useLanguageStore } from "@/stores/language";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import { computed } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";

const { t } = useI18n();
const router = useRouter();
const moduleId = useModuleId();
const languageStore = useLanguageStore();

const { isLoading: isDatasLoading, isError, dateFormatsList } = useGetDateFormats();

function goBack() {
  router.push({
    name: RouteName.SEARCH,
  });
}
const isLoading = computed(() => isDatasLoading.value || languageStore.loading);
</script>

<template>
  <RootNotification />
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded', 'no-after']">
      <template #card-header>
        <div class="card-header px-4">
          <div class="d-flex justify-content-between align-items-end">
            <BiBackButton
              icon="arrow-left"
              is-outlined
              color="primary"
              icon-color="primary"
              class="me-2"
              :visually-hidden-text="t(`${moduleId}.general.go_back`)"
              @click="goBack"
            >
            </BiBackButton>
            <h3 class="flex-grow-1 text-primary m-0">{{ t(`${moduleId}.users.manage_users`) }}</h3>
          </div>
        </div>
      </template>
      <template #card-body>
        <UsersMainContent icon="file-lines" :title="t(`${moduleId}.users.user`)">
          <UserCreateForm
            v-if="!isLoading && !isError"
            :data-format-list="dateFormatsList"
            :user-locale-list="languageStore.languages"
          />
          <!-- TOOD SHOW ERRORS AND LOADINGS -->
        </UsersMainContent>
      </template>
    </BiCard>
  </div>
</template>
