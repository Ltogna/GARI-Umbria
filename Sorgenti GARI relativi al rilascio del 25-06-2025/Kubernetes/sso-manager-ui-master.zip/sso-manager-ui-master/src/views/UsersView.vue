<script setup lang="ts">
import UsersList from "@/components/UsersList.vue";
import UsersMainContent from "@/components/users/UsersMainContent.vue";
import useModuleId from "@/composables/useModuleId";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import RootNotification from "@/components/RootNotification.vue";
import { useRouteQuery } from "@vueuse/router";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import { RouteName } from "@/models/routes";

const { t } = useI18n();
const router = useRouter();
const moduleId = useModuleId();
const search = useRouteQuery("search", "");

function goBack() {
  router.push({
    name: RouteName.SEARCH,
    query: {
      search: search.value,
    },
  });
}
</script>

<template>
  <RootNotification />
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded', 'no-after']">
      <template #card-header>
        <div class="card-header px-4">
          <div class="d-flex justify-content-between align-items-end">
            <BiBackButton
              icon="arrow-left"
              is-outlined
              color="primary"
              icon-color="primary"
              class="me-2"
              :visually-hidden-text="t(`${moduleId}.general.go_back`)"
              @click="goBack"
            >
            </BiBackButton>
            <h3 class="flex-grow-1 text-primary m-0">{{ t(`${moduleId}.users.manage_users`) }}</h3>
          </div>
        </div>
      </template>
      <template #card-body>
        <UsersMainContent icon="list" :title="t(`${moduleId}.users.users_list`)">
          <UsersList :user-name="search" />
        </UsersMainContent>
      </template>
    </BiCard>
  </div>
</template>
