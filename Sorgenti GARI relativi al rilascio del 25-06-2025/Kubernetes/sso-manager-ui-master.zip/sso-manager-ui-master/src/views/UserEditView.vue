<script setup lang="ts">
import RootNotification from "@/components/RootNotification.vue";
import UserEditForm from "@/components/users/UserEditForm.vue";
import UsersHeaderBar from "@/components/users/UsersHeaderBar.vue";
import UsersMainContent from "@/components/users/UsersMainContent.vue";
import useGetDateFormats from "@/composables/useGetDateFormats";
import useModuleId from "@/composables/useModuleId";
import { RouteName } from "@/models/routes";
import { type UserDataModel } from "@/models/users";
import { getUserByUsername } from "@/resources/api/users";
import { useLanguageStore } from "@/stores/language";
import { useNotificationStore } from "@/stores/notification";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { computed, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";

const notificationStore = useNotificationStore();

const { t } = useI18n();
const router = useRouter();
const moduleId = useModuleId();
const user = ref<UserDataModel | null>(null);
const route = useRoute();

const isUserLoading = ref(false);
const isUserError = ref(false);
const languageStore = useLanguageStore();

const { isLoading: isDatasLoading, isError: isDatasError, dateFormatsList } = useGetDateFormats();

onMounted(async () => {
  isUserLoading.value = true;
  isUserError.value = false;
  const username = route.params.username as string;
  const respUsers = await getUserByUsername(username as string);
  if (respUsers.errorType === ErrorType.NONE) {
    user.value = respUsers.data;
  } else {
    console.warn(respUsers);
    isUserError.value = true;
    await notificationStore.setMessage(respUsers);
  }
  isUserLoading.value = false;
});

const isLoading = computed(
  () => isUserLoading.value || isDatasLoading.value || languageStore.loading,
);
const isError = computed(() => isUserError.value && isDatasError.value);

function gotoRoles() {
  const username = route.params.username as string;
  router.push({
    name: RouteName.ROLES_LIST,
    params: { username },
  });
}

function goBack() {
  router.push({
    name: RouteName.USERS_LIST,
    query: {
      search: route.query.search,
    },
  });
}
</script>

<template>
  <RootNotification />
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded', 'no-after']">
      <template #card-header>
        <div class="card-header px-4">
          <div class="d-flex justify-content-between align-items-end">
            <BiBackButton
              icon="arrow-left"
              is-outlined
              color="primary"
              icon-color="primary"
              class="me-2"
              :visually-hidden-text="t(`${moduleId}.general.go_back`)"
              @click="goBack"
            >
            </BiBackButton>
            <h3 class="flex-grow-1 text-primary m-0">{{ t(`${moduleId}.users.manage_users`) }}</h3>
            <BiButton is-outlined color="primary" @click="gotoRoles">
              {{ t(`${moduleId}.roles.roles`) }}
            </BiButton>
          </div>
        </div>
      </template>
      <template #card-body>
        <div :class="['col-12', 'pe-0 ps-0 ps-lg-2']">
          <UsersHeaderBar :username="user?.userName" :info-internal="user?.internalUser ?? false">
          </UsersHeaderBar>
        </div>
        <UsersMainContent icon="file-lines" :title="t(`${moduleId}.users.edit_user`)">
          <UserEditForm
            v-if="user && !isLoading && !isError"
            :user="user"
            :format-dates="dateFormatsList"
            :user-locales="languageStore.languages"
          />
          <!-- TOOD SHOW ERRORS AND LOADINGS -->
        </UsersMainContent>
      </template>
    </BiCard>
  </div>
</template>
