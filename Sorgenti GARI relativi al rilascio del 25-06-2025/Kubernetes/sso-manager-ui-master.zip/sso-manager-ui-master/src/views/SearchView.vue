<script setup lang="ts">
import RootNotification from "@/components/RootNotification.vue";
import SearchForm from "@/components/SearchForm.vue";
import useModuleId from "@/composables/useModuleId";
import { RouteName } from "@/models/routes";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";

const { t } = useI18n();
const moduleId = useModuleId();
const router = useRouter();

function gotoCreateUser() {
  router.push({ name: RouteName.USER_CREATE });
}
</script>

<template>
  <RootNotification />
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded', 'no-after']">
      <template #card-header>
        <div class="card-header px-4">
          <div class="d-flex justify-content-between align-items-end">
            <h3 class="flex-grow-1 text-primary m-0">{{ t(`${moduleId}.users.manage_users`) }}</h3>
            <BiButton is-outlined color="primary" @click="gotoCreateUser">
              {{ t(`${moduleId}.users.new_user`) }}
            </BiButton>
          </div>
        </div>
      </template>
      <template #card-body>
        <SearchForm />
      </template>
    </BiCard>
  </div>
</template>
