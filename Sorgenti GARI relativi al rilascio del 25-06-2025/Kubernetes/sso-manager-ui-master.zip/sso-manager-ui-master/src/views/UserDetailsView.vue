<script setup lang="ts">
import RootNotification from "@/components/RootNotification.vue";
import UserDetail from "@/components/UserDetail.vue";
import UsersHeaderBar from "@/components/users/UsersHeaderBar.vue";
import UsersMainContent from "@/components/users/UsersMainContent.vue";
import useModuleId from "@/composables/useModuleId";
import { RouteName } from "@/models/routes";
import type { UserDataModel } from "@/models/users";
import { getUserByUsername } from "@/resources/api/users";
import { useNotificationStore } from "@/stores/notification";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";

const { t } = useI18n();
const moduleId = useModuleId();
const user = ref<UserDataModel | null>(null);
const isError = ref<boolean>(false);
const notificationStore = useNotificationStore();
const route = useRoute();
const router = useRouter();

onMounted(async () => {
  const username = route.params.username as string;
  const resp = await getUserByUsername(username);
  if (resp.errorType === ErrorType.NONE) {
    user.value = resp.data;
  } else {
    isError.value = true;
    console.warn(resp);
    await notificationStore.setMessage(resp);
  }
});

function gotoRoles() {
  const username = route.params.username as string;
  router.push({
    name: RouteName.ROLES_LIST,
    params: { username },
  });
}

function goBack() {
  router.back();
}
</script>

<template>
  <RootNotification />
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded', 'no-after']">
      <template #card-header>
        <div class="card-header px-4">
          <div class="d-flex justify-content-between align-items-end">
            <BiBackButton
              icon="arrow-left"
              is-outlined
              color="primary"
              icon-color="primary"
              class="me-2"
              :visually-hidden-text="t(`${moduleId}.general.go_back`)"
              @click="goBack()"
            >
            </BiBackButton>
            <h3 class="flex-grow-1 text-primary m-0">{{ t(`${moduleId}.users.manage_users`) }}</h3>
            <BiButton is-outlined color="primary" @click="gotoRoles">
              {{ t(`${moduleId}.roles.roles`) }}
            </BiButton>
          </div>
        </div>
      </template>
      <template #card-body>
        <div :class="['col-12', 'pe-0 ps-0 ps-lg-2']">
          <UsersHeaderBar :username="user?.userName" :info-internal="user?.internalUser ?? false">
          </UsersHeaderBar>
        </div>
        <UsersMainContent icon="file-lines" :title="t(`${moduleId}.users.details`)">
          <UserDetail v-if="user" :user="user"></UserDetail>
          <BiAlert
            v-else-if="isError"
            isError
            class="mt-3"
            :title="t(`${moduleId}.errors.GENERIC_ERROR`)"
          />
        </UsersMainContent>
      </template>
    </BiCard>
  </div>
</template>
