<script setup lang="ts">
import AddRolesModal from "@/components/add-roles/AddRolesModal.vue";
import RolesList from "@/components/RolesList.vue";
import RootNotification from "@/components/RootNotification.vue";
import UsersHeaderBar from "@/components/users/UsersHeaderBar.vue";
import UsersMainContent from "@/components/users/UsersMainContent.vue";
import useModuleId from "@/composables/useModuleId";
import type { UserDataModel } from "@/models/users";
import { getUserByUsername } from "@/resources/api/users";
import { useConfigStore } from "@/stores/config";
import { useNotificationStore } from "@/stores/notification";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";

const { t } = useI18n();
const moduleId = useModuleId();
const user = ref<UserDataModel | null>(null);
const notificationStore = useNotificationStore();
const route = useRoute();
const router = useRouter();
const loading = ref(false);
const isError = ref<boolean>(false);
const configStore = useConfigStore();

const openAddRolesModal = ref(false);

onMounted(async () => {
  loading.value = true;
  const username = route.params.username as string;
  const resp = await getUserByUsername(username);
  if (resp.errorType === ErrorType.NONE) {
    user.value = resp.data;
  } else {
    isError.value = true;
    console.warn(resp);
    await notificationStore.setMessage(resp);
  }
  loading.value = false;
});

function goBack() {
  router.back();
}

function addRoles() {
  openAddRolesModal.value = true;
}

async function reloadUser() {
  loading.value = true;
  const username = route.params.username as string;
  const resp = await getUserByUsername(username);
  if (resp.errorType === ErrorType.NONE) {
    user.value = resp.data;
  } else {
    isError.value = true;
    console.warn(resp);
    await notificationStore.setMessage(resp);
  }
  loading.value = false;
}
</script>

<template>
  <RootNotification />
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded', 'no-after']">
      <template #card-header>
        <div class="card-header px-4">
          <div class="d-flex justify-content-between align-items-end">
            <BiBackButton
              icon="arrow-left"
              is-outlined
              color="primary"
              icon-color="primary"
              class="me-2"
              :visually-hidden-text="t(`${moduleId}.general.go_back`)"
              @click="goBack"
            >
            </BiBackButton>
            <h3 class="flex-grow-1 text-primary m-0">
              {{ t(`${moduleId}.users.manage_users`) }}
            </h3>
            <BiButton
              is-outlined
              color="primary"
              @click="addRoles"
              v-if="user && configStore.canEditRoles(user)"
            >
              {{ t(`${moduleId}.roles.add_roles`) }}
            </BiButton>
          </div>
        </div>
      </template>
      <template #card-body>
        <div :class="['col-12', 'pe-0 ps-0 ps-lg-2']">
          <UsersHeaderBar :username="user?.userName" :info-internal="user?.internalUser ?? false">
          </UsersHeaderBar>
        </div>
        <UsersMainContent icon="list" :title="t(`${moduleId}.roles.list_view_title`)">
          <div class="p-1">
            <template v-if="!loading && user">
              <RolesList :user="user" @reload="reloadUser" />
            </template>
            <BiAlert
              v-if="!loading && user && user.userRoles && user.userRoles.length === 0"
              isInfo
              class="mt-3"
              :title="t(`${moduleId}.alerts.no_roles_found`)"
            />
            <BiAlert
              v-else-if="isError"
              isError
              :title="t(`${moduleId}.errors.GENERIC_ERROR`)"
            /></div
        ></UsersMainContent>
      </template>
    </BiCard>
  </div>
  <AddRolesModal v-if="user" :user="user" v-model="openAddRolesModal" @reload="reloadUser" />
</template>
