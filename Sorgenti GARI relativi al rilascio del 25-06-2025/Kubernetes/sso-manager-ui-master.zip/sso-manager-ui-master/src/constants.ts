import z from "zod";
export const MODULE_REF = "sso-manager"; //! IMPORTANT not override

const envSchema = z.object({
  VITE_BASE: z.string().min(1),
  VITE_MODULE_ID: z.string().min(1),
  VITE_SSO_BASE_URL: z.string().min(1),
  VITE_FORCED_CONTEXT: z.string().default(""),
});

const env = envSchema.parse(import.meta.env);

export const FORCED_CONTEXT = env.VITE_FORCED_CONTEXT;
export const BASE = `${FORCED_CONTEXT}${env.VITE_BASE}`;
export const MODULE_ID = env.VITE_MODULE_ID;
export const SSO_BASE_URL = env.VITE_SSO_BASE_URL;

export type FORCED_CONTEXT = typeof FORCED_CONTEXT;
export type MODULE_ID = typeof MODULE_ID;
export type BASE = typeof BASE;
