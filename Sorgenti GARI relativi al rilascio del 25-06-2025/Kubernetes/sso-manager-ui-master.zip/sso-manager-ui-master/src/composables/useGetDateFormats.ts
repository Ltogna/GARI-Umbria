import { type SelectI18nModel } from "@/models/users";
import { getFormatDatesList } from "@/resources/api/users";
import { useNotificationStore } from "@/stores/notification";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { onMounted, ref, computed } from "vue";

const isLoading = ref(false);
const isError = ref<boolean>(false);
const dateFormatsList = ref<SelectI18nModel[]>([]);

export default function () {
  onMounted(async () => {
    const notificationStore = useNotificationStore();
    isLoading.value = true;
    try {
      const dateFormatsListResp = await getFormatDatesList();
      if (dateFormatsListResp.errorType === ErrorType.NONE) {
        dateFormatsList.value = dateFormatsListResp.data.records;
      } else {
        notificationStore.setMessage(dateFormatsListResp);
        console.warn(dateFormatsListResp);

        isError.value = true;
      }
    } catch (error) {
      notificationStore.setRawMessge({ isError: true, message: "Error" });
      isError.value = true;
      console.warn(error);
    }
    isLoading.value = false;
  });

  return {
    isLoading: computed(() => isLoading.value),
    isError: computed(() => isError.value),
    dateFormatsList: computed(() => dateFormatsList.value),
  };
}
