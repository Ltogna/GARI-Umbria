import { inject } from "vue";
export default function (): string {
  return inject("moduleRef") as string;
}
