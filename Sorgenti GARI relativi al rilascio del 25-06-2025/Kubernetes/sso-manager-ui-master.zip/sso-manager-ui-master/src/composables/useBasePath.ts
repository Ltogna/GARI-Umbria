import { inject } from "vue";
import { BASE } from "@/constants";
export default function (): BASE {
  return inject("basePath", BASE);
}
