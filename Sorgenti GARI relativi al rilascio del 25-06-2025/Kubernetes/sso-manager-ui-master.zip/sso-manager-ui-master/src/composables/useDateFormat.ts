import { getUserData } from "@abaco/safe-rest/src/sso2";
import { format } from "date-fns";

export default function () {
  function dateFormat(date: Date, withTime?: boolean) {
    const userData = getUserData();
    if (userData && userData.dateFormat) {
      let pattern = userData.dateFormat;
      if (withTime) {
        pattern += " HH:mm:ss";
      }
      return format(date, pattern);
    }

    let pattern = "dd/MM/yyyy";
    if (withTime) {
      pattern += " HH:mm:ss";
    }
    return format(date, pattern);
  }

  return {
    dateFormat,
  };
}
