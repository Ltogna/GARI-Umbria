import type { Emitter } from "mitt";
import { inject } from "vue";

type Events = {
  "is:dirty": boolean;
};

export default function (): Emitter<Events> {
  return inject("emitter") as Emitter<Events>;
}
