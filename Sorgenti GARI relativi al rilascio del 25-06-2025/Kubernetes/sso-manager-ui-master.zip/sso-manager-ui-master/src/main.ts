import "@/assets/sso-manager.scss";
import createBootstrapItaliaComponentPlugin from "@abaco/bootstrap-italia-components/src/components/BootstrapItaliaComponentPlugin";
import { onModuleLoaded } from "@abaco/micro-frontend/src/Application";
import {
  NOOP_STOP_LISTENER,
  type SetStopListenerFunction,
  type StopListener,
} from "@abaco/micro-frontend/src/StopPreventionSuport";
import { createAbcRouter } from "@abaco/micro-frontend/src/Utility";
import { getUserData, login, userHasPermission } from "@abaco/safe-rest/src/sso2";
import mitt from "mitt";
import { createPinia, type Pinia } from "pinia";
import { createApp, type App as VueApp } from "vue";
import App from "./App.vue";
import { BASE, MODULE_ID, MODULE_REF } from "./constants";
import i18n, { loadLocaleMessages } from "./i18n";
import getRoutes from "./routes";
import { isStandalone } from "./utils/isStandalone";

console.log(
  `${MODULE_ID}: v${import.meta.env.VITE_APP_VERSION}-${import.meta.env.VITE_APP_GIT_COMMIT}`,
);

let pinia: Pinia | null = null;

if (isStandalone) {
  if (
    import.meta.env.VITE_USERNAME &&
    import.meta.env.VITE_PASSWORD &&
    import.meta.env.VITE_TENANT
  ) {
    login(
      {
        tenant: import.meta.env.VITE_TENANT,
        username: import.meta.env.VITE_USERNAME,
        password: import.meta.env.VITE_PASSWORD,
      },
      "/sso2",
    );
  }
  window.bootstrap.loadFonts(BASE + "bootstrap-italia/dist/fonts");
  const router = createAbcRouter(getRoutes(import.meta.env.BASE_URL), import.meta.env.BASE_URL);
  const app = createApp(App);
  app.use(router);
  app.provide("setStopListener", undefined);
  await init(app, import.meta.env.BASE_URL);
  app.mount("#app");
} else {
  let appModule: VueApp<Element> | null;
  let stopListener: StopListener = NOOP_STOP_LISTENER;
  const fnc: SetStopListenerFunction = (l: StopListener | null) =>
    (stopListener = l || NOOP_STOP_LISTENER);

  onModuleLoaded(MODULE_ID, {
    async start(node, basePath?: string) {
      appModule = createApp(App);
      appModule.provide("setStopListener", fnc);
      const router = createAbcRouter(getRoutes(basePath), basePath);
      appModule.use(router);

      await init(appModule, basePath);
      appModule.mount(node);
    },
    css() {
      return { index: `${BASE}assets/index.css.json` };
    },
    async canStop() {
      return stopListener();
    },
    async stop() {
      appModule?.unmount();
      pinia = null;
      appModule = null;
    },
  });
}

async function init(app: VueApp, basePath?: string) {
  const emitter = mitt();
  pinia ??= createPinia();
  app.use(pinia);
  const bootstrapItaliaComponentPlugin = await createBootstrapItaliaComponentPlugin({
    includeGlobalComponent: false,
    includeFontAwesome: isStandalone,
  });

  const user = getUserData();
  const hasPermission = isStandalone ? true : userHasPermission("SSO2", "ADMIN");
  const lang = user?.locale ?? window.navigator.language;

  await loadLocaleMessages(lang);
  app.config.globalProperties.$emitter = emitter;

  try {
    app.use(i18n);
    app.use(bootstrapItaliaComponentPlugin);
    app.provide("hasPermission", hasPermission);
    app.provide("basePath", basePath);
    app.provide("moduleRef", MODULE_REF);
    app.provide("emitter", emitter);
  } catch (err) {
    console.warn(err);
  }
}
