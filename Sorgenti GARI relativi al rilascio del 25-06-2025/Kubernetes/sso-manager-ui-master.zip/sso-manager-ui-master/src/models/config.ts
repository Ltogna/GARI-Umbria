import { z } from "zod";

export enum FieldType {
  TEXT = "text",
}

const UserPropertySchema = z.object({
  name: z.string(),
  description: z.string().nullish(),
  require: z.boolean().default(false),
  type: z.nativeEnum(FieldType),
});

export const ConfigSchema = z.object({
  userProperties: UserPropertySchema.array().nullish(),
  allowsExternalUserRolesManagement: z.boolean().default(true),
});

export type UserPropertyModel = z.infer<typeof UserPropertySchema>;
export type ConfigModel = z.infer<typeof ConfigSchema>;
