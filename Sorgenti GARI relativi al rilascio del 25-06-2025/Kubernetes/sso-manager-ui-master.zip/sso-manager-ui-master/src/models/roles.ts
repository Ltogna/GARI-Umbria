import { z } from "zod";
import { getNextPagedResultsSchema } from "@abaco/safe-rest/src/pagination";

export const RoleSchema = z.object({
  roleCode: z.string(),
  description: z.string().nullable(),
  assignmentDate: z.coerce.date().nullish(),
});

export type RoleModel = z.infer<typeof RoleSchema>;

export const ResponseRoleSchema = z.object({
  roleCode: z.string(),
  description: z.string().nullable(),
});

export type ResponseRoleModel = z.infer<typeof ResponseRoleSchema>;
export const ResponseRolesListSchema = getNextPagedResultsSchema(ResponseRoleSchema);
export type ResponseRolesListModel = z.infer<typeof ResponseRolesListSchema>;

export const FormSearchRolesSchema = z.object({
  search: z.string().optional(),
});

export type FormSearchRolesModel = z.infer<typeof FormSearchRolesSchema>;
