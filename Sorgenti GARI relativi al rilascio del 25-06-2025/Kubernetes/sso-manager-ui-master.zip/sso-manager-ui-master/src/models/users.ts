import { z } from "zod";
import { getNextPagedResultsSchema } from "@abaco/safe-rest/src/pagination";
import { RoleSchema } from "./roles";
import { MODULE_REF } from "@/constants";

export const errorMessages = {
  invalid_type_error: `${MODULE_REF}.form_errors.type_error`,
  required_error: `${MODULE_REF}.form_errors.required`,
};

const PasswordSchema = z
  .string(errorMessages)
  .min(8, { message: `${MODULE_REF}.form_errors.password_errors` })
  .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[~!@#$%^&*_\-+=|(){}[\]:;<>,.?])/, {
    message: `${MODULE_REF}.form_errors.password_errors`,
  });

export const SelectSchema = z.object(
  {
    value: z.string(),
    description: z.string().optional(),
  },
  { message: `${MODULE_REF}.form_errors.required` },
);

export type SelectModel = z.infer<typeof SelectSchema>;

export const SelectListResponseSchema = z.object({
  records: z.array(SelectSchema),
});

export type SelectListResponseModel = z.infer<typeof SelectListResponseSchema>;

export const SelectI18nSchema = SelectSchema.extend({
  description: z.string(),
});

export const SelectListI18nSchema = z.object({
  records: SelectI18nSchema.array(),
});

export type SelectI18nModel = z.infer<typeof SelectI18nSchema>;
export type SelectListI18nModel = z.infer<typeof SelectListI18nSchema>;

export const UserPropertiesSchema = z.record(z.string().min(1), z.string());

export type UserPropertiesModel = z.infer<typeof UserPropertiesSchema>;

export enum LockedEnum {
  Y = "Y",
  N = "N",
}

export const UserDataSchema = z.object({
  userId: z.string(),
  tenant: z.string(),
  userName: z.string(),
  description: z.string().nullable(),
  internalUser: z.boolean().nullable(),
  isLocked: z.nativeEnum(LockedEnum).nullish(),
  userLocale: z.string(),
  dateFormat: z.string(),
  creationDate: z.coerce.date().nullable(),
  lastLoginDate: z.coerce.date().nullable(),
  lastLoginModificationDate: z.coerce.date().nullable(),
  userRoles: RoleSchema.array(),
  userProperties: z.union([
    z.record(z.string().min(1), z.string()),
    z.object({
      email: z.string(errorMessages).nullish(),
    }),
  ]),
  isModifyPasswordOnNextLogin: z.nativeEnum(LockedEnum).nullish(),
});
export const UsersDataListSchema = getNextPagedResultsSchema(UserDataSchema);

export type UserDataModel = z.infer<typeof UserDataSchema>;
export type UsersDataListModel = z.infer<typeof UsersDataListSchema>;

/**
 * Language model
 */
export const LanguageSchema = z.object(
  {
    code: z.string(),
    description: z.string().optional(),
  },
  { message: `${MODULE_REF}.form_errors.required` },
);

export type LanguageModel = z.infer<typeof LanguageSchema>;
export const LanguageListSchema = LanguageSchema.array();
export type LanguageListModel = z.infer<typeof LanguageListSchema>;

const emailField = z
  .string(errorMessages)
  .min(1, { message: `${MODULE_REF}.form_errors.required` })
  .email(`${MODULE_REF}.form_errors.email`);

export const CreateUserBaseSchema = z.object({
  username: z
    .string(errorMessages)
    .min(1, { message: `${MODULE_REF}.form_errors.required` })
    .max(70, { message: `${MODULE_REF}.form_errors.username_too_long` }),
  description: z.string(errorMessages).min(1, { message: `${MODULE_REF}.form_errors.required` }),
  password: PasswordSchema.nullish(),
  email: emailField,
  userLocale: LanguageSchema,
  dateFormat: SelectSchema,
  isModifyPasswordOnNextLogin: z.boolean().nullable(),
});

export const CreateUserSchema = CreateUserBaseSchema.extend({
  confirmPassword: z.string(errorMessages).nullish(),
}).refine((data) => data.password === data.confirmPassword, {
  message: `${MODULE_REF}.form_errors.passwords_do_not_match`,
  path: ["confirmPassword"],
});

export const EditUserFormBaseSchema = CreateUserBaseSchema.omit({ username: true }).extend({
  description: z.string().nullish(),
  internalUser: z.boolean(),
  email: z.string().nullish(),
  password: PasswordSchema.nullish(),
  isLocked: z.boolean().default(false),
  isModifyPasswordOnNextLogin: z.boolean(),
});

// extended form with confirmPassword
export const EditUserFormSchema = EditUserFormBaseSchema.extend({
  confirmPassword: z.string().nullish(),
})
  .refine((data) => data.password === data.confirmPassword, {
    message: `${MODULE_REF}.form_errors.passwords_do_not_match`,
    path: ["confirmPassword"],
  })
  .superRefine((data, ctx) => {
    if (data.internalUser) {
      const parsedEmail = emailField.safeParse(data.email);
      if (!parsedEmail.success) {
        for (const issue of parsedEmail.error.issues) {
          issue.path = ["email"];
          ctx.addIssue(issue);
        }
      }

      const pardeDescription = z
        .string(errorMessages)
        .min(1, { message: `${MODULE_REF}.form_errors.required` })
        .safeParse(data.description);

      if (!pardeDescription.success) {
        for (const issue of pardeDescription.error.issues) {
          issue.path = ["description"];
          ctx.addIssue(issue);
        }
      }
    }
  });

export type EditUserFormModel = z.infer<typeof EditUserFormSchema>;
export type EditUserFormBaseModel = z.infer<typeof EditUserFormBaseSchema>;

export type CreateUserModel = z.infer<typeof CreateUserSchema>;
export type CreateUserBaseModel = z.infer<typeof CreateUserBaseSchema>;

// --------------------defined schema user create

export const CreateUserBaseSchemaOff = z.object({
  dateFormat: z.string(errorMessages),
  description: z.string(errorMessages),
  flInternal: z.string(errorMessages).nullable(),
  isLocked: z.string(errorMessages).nullable(),
  isParent: z.number(errorMessages).nullable(),
  parentUserId: z.string(errorMessages).nullable(),
  password: z.string(errorMessages).nullable(),
  isPasswordEncoded: z.number(errorMessages),
  username: z.string(errorMessages).min(1, { message: `${MODULE_REF}.form_errors.required` }),
  language: z.string(errorMessages),
  userProperties: UserPropertiesSchema,
  isModifyPasswordOnNextLogin: z.string(errorMessages).nullable(),
});

export const CreateUserSchemaOff = CreateUserBaseSchemaOff.extend({
  confirmPassword: z.string(errorMessages),
}).refine((data) => data.password === data.confirmPassword, {
  message: `${MODULE_REF}.form_errors.passwords_do_not_match`,
  path: ["confirmPassword"],
});

export type CreateUserModelOff = z.infer<typeof CreateUserSchemaOff>;
export type CreateUserBaseModelOff = z.infer<typeof CreateUserBaseSchemaOff>;

export const UpdateUserPayloadSchema = z.object({
  dateFormat: z.string(errorMessages),
  description: z.string(errorMessages).nullable(),
  isLocked: z.string(errorMessages),
  password: z.string(errorMessages).nullable(),
  language: z.string(errorMessages),
  // flInternal: z.string(errorMessages),
  // isParent: z.number(errorMessages).nullable(),
  // parentUserId: z.string(errorMessages).nullable(),
  // isPasswordEncoded: z.number(errorMessages),
  userProperties: UserPropertiesSchema,
  isModifyPasswordOnNextLogin: z.string(errorMessages),
});

export type UpdateUserPayloadModel = z.infer<typeof UpdateUserPayloadSchema>;

export const CreateUserUsernameSchema = z.object({
  userName: z.string(),
});
export type CreateUserUsernameModel = z.infer<typeof CreateUserUsernameSchema>;
