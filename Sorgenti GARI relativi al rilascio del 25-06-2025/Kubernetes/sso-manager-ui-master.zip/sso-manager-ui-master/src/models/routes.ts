const SSO_MANAGER = "sso-manager";

export enum RouteName {
  INDEX = `${SSO_MANAGER}:index`,
  SEARCH = `${SSO_MANAGER}:search`,
  USERS_LIST = `${SSO_MANAGER}:users:list`,
  USER_DETAILS = `${SSO_MANAGER}:user:details`,
  ROLES_LIST = `${SSO_MANAGER}:roles:list`,
  USER_CREATE = `${SSO_MANAGER}:user:create`,
  USER_EDIT = `${SSO_MANAGER}:user:edit`      
}
