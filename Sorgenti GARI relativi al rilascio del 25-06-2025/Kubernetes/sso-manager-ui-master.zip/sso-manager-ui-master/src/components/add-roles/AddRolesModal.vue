<script lang="ts" setup>
import useModuleId from "@/composables/useModuleId";
import type { FormSearchRolesModel, ResponseRoleModel } from "@/models/roles";
import type { UserDataModel } from "@/models/users";
import { addRolesToUser, getRoles } from "@/resources/api/roles";
import { useNotificationStore } from "@/stores/notification";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import RolesList from "./RolesList.vue";
import SearchForm from "./SearchForm.vue";

const props = defineProps<{
  user: UserDataModel;
}>();

const emits = defineEmits<{
  reload: [];
}>();

const { t } = useI18n();
const moduleId = useModuleId();
const notificationStore = useNotificationStore();
const searchForm = ref<InstanceType<typeof SearchForm> | null>(null);
const openModal = defineModel<boolean>({ default: false });
const nextKey = ref<string | null>(null);
const loading = ref<boolean>(false);
const items = ref<ResponseRoleModel[]>([]);
const paramsRef = ref<FormSearchRolesModel>({});

function resetForm() {
  searchForm.value?.reset();
  openModal.value = false;
  nextKey.value = null;
  loading.value = false;
  items.value = [];
  paramsRef.value = {};
}

async function onSubmit(params: FormSearchRolesModel, force = false) {
  loading.value = true;
  paramsRef.value = params;
  const nk = force ? undefined : nextKey.value ?? undefined;
  const resp = await getRoles(params, nk);
  if (resp.errorType === ErrorType.NONE) {
    if (force) {
      nextKey.value = resp.data.nextKey;
      items.value = resp.data.records;
    }
  } else {
    console.warn(resp);
    await notificationStore.setMessage(resp);
  }

  loading.value = false;
}

async function loadMore() {
  loading.value = true;
  const resp = await getRoles(paramsRef.value, nextKey.value ?? undefined);
  if (resp.errorType === ErrorType.NONE) {
    nextKey.value = resp.data.nextKey;
    items.value = [...items.value, ...resp.data.records];
  } else {
    console.warn(resp);
    await notificationStore.setMessage(resp);
  }

  loading.value = false;
}

async function selectRole(role: ResponseRoleModel) {
  const resp = await addRolesToUser(props.user.userName, [role.roleCode]);
  if (resp.errorType === ErrorType.NONE) {
    emits("reload");
  } else {
    console.warn(resp);
    await notificationStore.setMessage(resp);
  }
}

watch(openModal, () => {
  loading.value = true;
});
</script>

<template>
  <BiModal
    size="xl"
    v-model="openModal"
    class="modal-sheets sso-manager__add-roles-modal"
    extra-footer-class="justify-content-center"
    extra-header-class="p-4"
    :title="t(`${moduleId}.roles.modal_roles_title`)"
  >
    <template #body>
      <SearchForm ref="searchForm" @submit="onSubmit" />
      <RolesList
        :next-key="nextKey"
        :is-loading="loading"
        :items="items"
        :user-roles="user.userRoles"
        @load-more="loadMore"
        @selected="selectRole"
      />
      <BiAlert
        v-if="!loading && items.length === 0"
        isInfo
        class="mt-3"
        :title="t(`${moduleId}.alerts.no_roles_found`)"
      />
    </template>
    <template #footer>
      <BiButton @click="resetForm" color="primary" is-outlined :tabindex="1">
        {{ t(`${moduleId}.general.close`) }}
      </BiButton>
      <BiButton @click="() => searchForm?.submit()" color="success" :tabindex="1">
        {{ t(`${moduleId}.roles.search`) }}
      </BiButton>
    </template>
  </BiModal>
</template>

<style lang="scss">
.sso-manager {
  &__add-roles-modal {
    .modal-header {
      padding: 0 !important;
      background-color: rgba(var(--bs-100-rgb), 0.4);
    }

    &.modal-sheets {
      .fixed-table {
        max-height: 400px;
        overflow: auto;
        overflow-anchor: none;
        table {
          width: 100%;
          margin-bottom: 0;
          tr {
            border-bottom: 1px solid #ddd;
            line-height: 2;
          }
          thead {
            table-layout: fixed;
            border-collapse: collapse;
            th {
              background-color: var(--bs-gray-100);
              border: none;
              position: sticky;
              top: 0;
            }
          }
          tbody {
            border: 1px solid #ccc;
            tr {
              table-layout: fixed;
              &:hover {
                background-color: #e5ebe7; //TODO variable
                // background-color: hls(var(--bs-primary-rgb));
              }
            }
          }
          & > :not(:first-child) {
            border-top: none;
          }
        }
        .table-actions {
          font-weight: 700;
          font-size: medium;
        }

        &.show-more-mode {
          tbody {
            overflow-y: auto;
            border-right: none;
          }
        }
      }
    }
  }
}
</style>
