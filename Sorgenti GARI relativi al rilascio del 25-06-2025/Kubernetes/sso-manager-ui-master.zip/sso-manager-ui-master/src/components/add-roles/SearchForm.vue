<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import { useForm } from "vee-validate";
import { toTypedSchema } from "@vee-validate/zod";
import { useI18n } from "vue-i18n";
import { FormSearchRolesSchema, type FormSearchRolesModel } from "@/models/roles";

const { t } = useI18n();
const moduleId = useModuleId();

defineExpose({
  submit,
  reset,
});

const emits = defineEmits<{
  submit: [FormSearchRolesModel, boolean];
}>();

const { errors, defineField, handleReset, handleSubmit } = useForm({
  validationSchema: toTypedSchema(FormSearchRolesSchema),
});

function submit() {
  onSubmit();
}
function reset() {
  handleReset();
}
const [search] = defineField("search");

const onSubmit = handleSubmit((value) => {
  emits("submit", value, true);
});
</script>
<template>
  <form class="row mt-4 g-4 mb-1 sso-manager__form" novalidate @submit="onSubmit" @reset="reset">
    <div class="col-12 align-self-end">
      <BiInput
        v-model="search"
        type="search"
        :label="t(`${moduleId}.roles.role`)"
        :placeholder="t(`${moduleId}.roles.role`)"
        :tabindex="1"
        :errors="errors.search ? [errors.search] : []"
        :default-return-if-not-value="'undefined'"
      />
    </div>
    <button class="invisible" type="submit"></button>
  </form>
</template>
