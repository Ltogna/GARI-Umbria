<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import { type ResponseRoleModel, type RoleModel } from "@/models/roles";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { useI18n } from "vue-i18n";

defineProps<{
  nextKey: string | null;
  items: ResponseRoleModel[];
  userRoles: RoleModel[];
  isLoading: boolean;
}>();

const emits = defineEmits<{
  selected: [ResponseRoleModel];
  loadMore: [];
}>();

const moduleId = useModuleId();
const { t } = useI18n();

function setRole(role: ResponseRoleModel) {
  emits("selected", role);
}

function loadMore() {
  emits("loadMore");
}
</script>

<template>
  <div v-show="items.length > 0">
    <BiTable class="fixed-table mt-3" is-responsive is-row-hover>
      <template #head>
        <tr>
          <th>
            {{ t(`${moduleId}.roles.name`) }}
          </th>
          <th>
            {{ t(`${moduleId}.roles.description`) }}
          </th>
          <th>
            <BiHiddenContent :text="t(`${moduleId}.roles.select`)"></BiHiddenContent>
          </th>
        </tr>
      </template>
      <!-- eslint-disable -->
      <template #body>
        <tr v-for="data in items" :key="`data-${data.roleCode}`">
          <td :data-label="t(`${moduleId}.roles.name`)">
            {{ data.roleCode }}
          </td>
          <td
            style="max-width: 1px; width: 70%"
            class="text-truncate"
            :data-label="t(`${moduleId}.roles.description`)"
          >
            {{ data.description }}
          </td>
          <td class="table-actions text-center">
            <BiIconButton
              v-if="!userRoles.some((role) => role.roleCode === data.roleCode)"
              class="me-2"
              is-outlined
              :title="t(`${moduleId}.roles.select`)"
              :icon="'plus'"
              icon-style="fas"
              :color="'secondary'"
              @click="setRole(data)"
              :tabindex="1"
            />
          </td>
        </tr>
        <tr class="show-more-row" v-if="nextKey">
          <td colspan="9999" class="text-center">
            <BiButton
              color="primary"
              is-outlined
              class="py-1 px-2"
              :is-disabled="isLoading"
              :tabindex="1"
              @click="loadMore()"
            >
              {{ t(`${moduleId}.general.load_more`) }}
            </BiButton>
          </td>
        </tr>
      </template>
      <!-- eslint-enable -->
    </BiTable>
  </div>
</template>
