<script setup lang="ts">
import useDateFormat from "@/composables/useDateFormat";
import useModuleId from "@/composables/useModuleId";
import type { UserDataModel } from "@/models/users";
import { turnOnWithI18n } from "@/resources/api/users";
import { useLanguageStore } from "@/stores/language";
import { computed } from "vue";
import { useI18n } from "vue-i18n";

const { t } = useI18n();
const moduleId = useModuleId();
const { dateFormat } = useDateFormat();
const { getLanguageDescription } = useLanguageStore();

const props = defineProps<{
  user: UserDataModel;
}>();

const userDateFormatI18n = turnOnWithI18n();

const dateFormatI18n = computed<string>(() => {
  const value = props.user.dateFormat;
  if (value) {
    return userDateFormatI18n({ value }).description;
  }
  return "-";
});
</script>

<template>
  <dl class="row ps-1 my-2" v-if="user">
    <dt class="col-sm-3">{{ t(`${moduleId}.users.description`) }}:</dt>
    <dd class="col-sm-9">
      {{ user.description ?? "-" }}
    </dd>
    <dt class="col-sm-3">{{ t(`${moduleId}.users.locale`) }}:</dt>
    <dd class="col-sm-9">
      {{ getLanguageDescription(user.userLocale) }}
    </dd>
    <dt class="col-sm-3">{{ t(`${moduleId}.users.format_date`) }}:</dt>
    <dd class="col-sm-9">
      {{ dateFormatI18n }}
    </dd>
    <dt class="col-sm-3">{{ t(`${moduleId}.users.creation_date`) }}:</dt>
    <dd class="col-sm-9">
      {{ user.creationDate ? dateFormat(user.creationDate, true) : "-" }}
    </dd>
    <dt class="col-sm-3">{{ t(`${moduleId}.users.last_login_date`) }}:</dt>
    <dd class="col-sm-9">
      {{ user.lastLoginDate ? dateFormat(user.lastLoginDate, true) : "-" }}
    </dd>
    <dt class="col-sm-3">{{ t(`${moduleId}.users.last_edit_login_date`) }}:</dt>
    <dd class="col-sm-9">
      {{ user.lastLoginModificationDate ? dateFormat(user.lastLoginModificationDate, true) : "-" }}
    </dd>
  </dl>
</template>
