<script setup lang="ts">
import useDateFormat from "@/composables/useDateFormat";
import useEmitter from "@/composables/useEmitter";
import useModuleId from "@/composables/useModuleId";
import { useNotificationStore } from "@/stores/notification";
import {
  EditUserFormSchema,
  type EditUserFormModel,
  type LanguageListModel,
  type SelectI18nModel,
  type UpdateUserPayloadModel,
  type UserDataModel,
} from "@/models/users";
import { turnOnWithI18n, updateUser } from "@/resources/api/users";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiAutocompleteNext from "@abaco/bootstrap-italia-components/src/components/form/BiAutocompleteNext.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiToggle from "@abaco/bootstrap-italia-components/src/components/form/BiToggle.vue";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { toTypedSchema } from "@vee-validate/zod";
import { useForm } from "vee-validate";
import { toRaw, watch } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";

const moduleId = useModuleId();
const router = useRouter();
const { dateFormat: dateFormatFormatter } = useDateFormat();
const { setRawMessge, setMessage } = useNotificationStore();
const { t, te, tm } = useI18n();
const emitter = useEmitter();

const props = defineProps<{
  user: UserDataModel;
  formatDates: SelectI18nModel[];
  userLocales: LanguageListModel;
}>();

const dateFormatI18n = turnOnWithI18n();

const initialValues: Partial<EditUserFormModel> = {
  internalUser: !!props.user.internalUser,
  description: props.user.description ?? "",
  password: undefined,
  confirmPassword: undefined,
  email: props.user.userProperties?.email ?? "",
  userLocale: props.user.userLocale
    ? props.userLocales.find(({ code }) => code === props.user.userLocale)
    : undefined,
  dateFormat: props.user.dateFormat ? dateFormatI18n({ value: props.user.dateFormat }) : undefined,
  isLocked: props.user.isLocked === "Y" ? true : false,
  isModifyPasswordOnNextLogin: props.user.isModifyPasswordOnNextLogin === "Y" ? true : false,
};

const { handleSubmit, errors, defineField, resetForm, submitCount, meta } =
  useForm<EditUserFormModel>({
    validationSchema: toTypedSchema(EditUserFormSchema),
    initialValues: initialValues,
    validateOnMount: false,
  });

const confirmForm = async (values: UpdateUserPayloadModel) => {
  const resp = await updateUser(props.user.userName, values);
  if (resp.errorType === ErrorType.NONE) {
    emitter.emit("is:dirty", false);
    setRawMessge({
      isError: false,
      message: t(`${moduleId}.success.GENERIC_SAVE`),
    });
    router.back();
  } else {
    await setMessage(resp);
    console.warn(resp);
  }
};

const onSubmit = handleSubmit(async (values) => {
  const up = (props.user.userProperties as Record<string, string>) ?? {};
  const userProperties = { ...up };

  if (values.internalUser) {
    if (typeof values.email === "string") {
      userProperties.email = values.email;
    } else {
      delete userProperties.email;
    }
  }

  const userFields: UpdateUserPayloadModel = {
    dateFormat: values.dateFormat.value,
    description: values.description || null,
    isLocked: values.isLocked ? "Y" : "N",
    language: values.userLocale.code,
    password: values.password ? values.password : null,
    userProperties,
    isModifyPasswordOnNextLogin: values.isModifyPasswordOnNextLogin ? "Y" : "N",
  };
  await confirmForm(userFields);
});

const [description] = defineField("description");
const [password] = defineField("password");
const [confirmPassword] = defineField("confirmPassword");
const [email] = defineField("email");
const [userLocale] = defineField("userLocale");
const [dateFormat] = defineField("dateFormat");
const [isLocked] = defineField("isLocked");
const [isModifyPasswordOnNextLogin] = defineField("isModifyPasswordOnNextLogin");

function onReset() {
  resetForm();
}

function printError(data?: string): string[] {
  const errors = new Set<string>();
  if (data && submitCount.value > 0) {
    const errorRaw = toRaw(tm(data));
    if (errorRaw) {
      if (Array.isArray(errorRaw)) {
        return errorRaw as string[];
      } else if (typeof errorRaw === "string") {
        errors.add(errorRaw);
      }
    } else {
      errors.add(data);
    }
    errors.add(te(data) ? t(data) : data);
  }
  return [...errors];
}

watch(
  () => meta.value.dirty,
  (newValues) => {
    emitter.emit("is:dirty", newValues);
  },
);
</script>

<template>
  <form
    ref="formRef"
    class="sso-manager__form-edit-users mt-4 ps-2 row sso-manager__form"
    novalidate
    autocomplete="off"
    @submit="onSubmit"
    @reset="onReset"
  >
    <div class="col-6">
      <div class="form-group" :class="{ 'field-required': !!user.internalUser }">
        <BiInput
          name="input-field-description"
          v-model="description"
          type="text"
          autocomplete="new-description"
          :label="t(`${moduleId}.users.description`)"
          :disabled="!user.internalUser"
          :placeholder="t(`${moduleId}.users.description`)"
          :default-return-if-not-value="'null'"
          :errors="printError(errors.description)"
        />
      </div>
      <div v-if="user.internalUser" class="form-group">
        <BiInput
          name="input-field-password"
          v-model="password"
          type="password"
          autocomplete="new-password"
          :label="t(`${moduleId}.users.password`)"
          :placeholder="t(`${moduleId}.users.password`)"
          :errors="printError(errors.password)"
          :default-return-if-not-value="'undefined'"
        />
      </div>
      <div v-if="user.internalUser" class="form-group">
        <BiInput
          name="input-field-confirmPassword"
          v-model="confirmPassword"
          type="password"
          autocomplete="new-confirm-password"
          :label="t(`${moduleId}.users.confirm_password`)"
          :placeholder="t(`${moduleId}.users.confirm_password`)"
          :errors="printError(errors.confirmPassword)"
          :default-return-if-not-value="'undefined'"
        />
      </div>

      <div v-if="!!user.internalUser" class="field-required form-group">
        <BiInput
          name="input-field-email"
          v-model="email"
          type="email"
          autocomplete="new-email"
          :hide-arrows="true"
          :label="t(`${moduleId}.users.email`)"
          :placeholder="t(`${moduleId}.users.email`)"
          :errors="printError(errors.email)"
        />
      </div>
      <div class="mb-5 field-required">
        <BiAutocompleteNext
          name="input-field-userLocale"
          v-model="userLocale"
          :items="userLocales"
          :item-value="'code'"
          :item-title="'description'"
          :min-search-lenght="1"
          :label-no-result="`${t(`${moduleId}.form_errors.no_results`)}`"
          :label="t(`${moduleId}.users.locale`)"
          :placeholder="t(`${moduleId}.users.locale`)"
          :label-no-items="`${t(`${moduleId}.form_errors.no_results`)}`"
          :errors="printError(errors.userLocale)"
          required
        >
        </BiAutocompleteNext>
      </div>
      <div class="mb-5 field-required">
        <BiAutocompleteNext
          name="input-field-dateFormat"
          v-model="dateFormat"
          :items="formatDates"
          :item-value="'value'"
          :item-title="'description'"
          :min-search-lenght="1"
          :label-no-result="`${t(`${moduleId}.form_errors.no_results`)}`"
          :label="t(`${moduleId}.users.format_date`)"
          :placeholder="t(`${moduleId}.users.format_date`)"
          :label-no-items="`${t(`${moduleId}.form_errors.no_results`)}`"
          :errors="printError(errors.dateFormat)"
          required
        >
        </BiAutocompleteNext>
      </div>

      <div v-if="user.internalUser" class="my-5">
        <BiToggle :label="t(`${moduleId}.users.blocked`)" v-model="isLocked" />
      </div>

      <div v-if="user.internalUser" class="my-5">
        <BiToggle
          :label="t(`${moduleId}.users.changePassword`)"
          v-model="isModifyPasswordOnNextLogin"
        />
      </div>
    </div>

    <div class="my-3 pt-3">
      <dl class="my-2 ps-1 row" v-if="user">
        <dt class="col-sm-3">{{ t(`${moduleId}.users.creation_date`) }}:</dt>
        <dd class="col-sm-9">
          {{ user.creationDate ? dateFormatFormatter(user.creationDate, true) : "-" }}
        </dd>
        <dt class="col-sm-3">{{ t(`${moduleId}.users.last_login_date`) }}:</dt>
        <dd class="col-sm-9">
          {{ user.lastLoginDate ? dateFormatFormatter(user.lastLoginDate, true) : "-" }}
        </dd>
        <template v-if="user.internalUser">
          <dt class="col-sm-3">{{ t(`${moduleId}.users.last_edit_login_date`) }}:</dt>
          <dd class="col-sm-9">
            {{
              user.lastLoginModificationDate
                ? dateFormatFormatter(user.lastLoginModificationDate, true)
                : "-"
            }}
          </dd>
        </template>
      </dl>
    </div>
    <div class="col-6">
      <div class="my-2 col-12">
        <BiButton color="primary" is-outlined type="reset">
          {{ t(`${moduleId}.general.cancel`) }}
        </BiButton>
        <BiButton class="mx-2" color="success" type="submit" :is-disabled="!meta.dirty">
          {{ t(`${moduleId}.general.confirm`) }}
        </BiButton>
      </div>
    </div>
  </form>
</template>

<style lang="scss">
.sso-manager__form-edit-users {
  .multiselect.it-list.form-control {
    box-shadow: none;
  }
}
</style>
<style scoped lang="scss">
:deep([type="password"]) {
  &::-ms-reveal {
    display: none;
  }
}
</style>
