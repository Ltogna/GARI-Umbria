<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import BiToggle from "@abaco/bootstrap-italia-components/src/components/form/BiToggle.vue";
import useEmitter from "@/composables/useEmitter";
import { RouteName } from "@/models/routes";
import { ErrorCode } from "@/models/errors";
import {
  CreateUserSchema,
  type CreateUserBaseModelOff,
  type CreateUserModel,
  type LanguageListModel,
  type SelectI18nModel,
} from "@/models/users";
import { createUser } from "@/resources/api/users";
import { useNotificationStore } from "@/stores/notification";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiAutocompleteNext from "@abaco/bootstrap-italia-components/src/components/form/BiAutocompleteNext.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { toTypedSchema } from "@vee-validate/zod";
import { useForm } from "vee-validate";
import { ref, toRaw, watch } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";

const router = useRouter();
const moduleId = useModuleId();
const notificationStore = useNotificationStore();
const { t, te, tm } = useI18n();
const emitter = useEmitter();
const isDirty = ref(false);

defineProps<{
  dataFormatList: SelectI18nModel[];
  userLocaleList: LanguageListModel;
}>();

const initialValues: Partial<CreateUserModel> = {
  username: "",
  description: "",
  password: undefined,
  confirmPassword: undefined,
  email: "",
  isModifyPasswordOnNextLogin: true,
};

const { handleSubmit, errors, defineField, submitCount, resetForm, values } =
  useForm<CreateUserModel>({
    validationSchema: toTypedSchema(CreateUserSchema),
    initialValues: initialValues,
  });

const confirmForm = async (values: CreateUserBaseModelOff) => {
  const resp = await createUser(values);
  if (resp.errorType === ErrorType.NONE) {
    emitter.emit("is:dirty", false);
    notificationStore.setRawMessge({
      isError: false,
      message: t(`${moduleId}.success.GENERIC_SAVE`),
    });
    router.replace({ name: RouteName.USER_EDIT, params: { username: resp.data.userName } });
  } else {
    console.warn(resp);
    if (resp.errorType === ErrorType.HTTP_STATUS) {
      try {
        const err = await resp.response.clone().json();
        if (err.errorCode === ErrorCode.USER_ALREADY_EXISTS) {
          await notificationStore.setRawMessge({
            isError: true,
            message: t(`${moduleId}.errors.USER_DUPLICATED`),
          });
        } else {
          await notificationStore.setMessage(resp);
        }
      } catch (err) {
        console.warn(err);
        await notificationStore.setMessage(resp);
      }
    } else {
      await notificationStore.setMessage(resp);
    }
  }
};

const onSubmit = handleSubmit(async (values) => {
  const userFields: CreateUserBaseModelOff = {
    dateFormat: values.dateFormat.value,
    description: values.description,
    flInternal: null,
    isLocked: null,
    isParent: null,
    isPasswordEncoded: 0,
    parentUserId: null,
    language: values.userLocale.code!,
    password: values.password ? values.password : null,
    username: values.username,
    userProperties: { email: values.email },
    isModifyPasswordOnNextLogin: "Y",
  };
  await confirmForm(userFields);
});

const [username] = defineField("username");
const [description] = defineField("description");
const [password] = defineField("password");
const [confirmPassword] = defineField("confirmPassword");
const [email] = defineField("email");
const [language] = defineField("userLocale");
const [dateFormat] = defineField("dateFormat");
const [isModifyPasswordOnNextLogin] = defineField("isModifyPasswordOnNextLogin");

function onReset() {
  resetForm();
}

function printError(data?: string): string[] {
  const errors = new Set<string>();
  if (data && submitCount.value > 0) {
    const errorRaw = toRaw(tm(data));
    if (errorRaw) {
      if (Array.isArray(errorRaw)) {
        return errorRaw as string[];
      } else if (typeof errorRaw === "string") {
        errors.add(errorRaw);
      }
    } else {
      errors.add(data);
    }
    errors.add(te(data) ? t(data) : data);
  }
  return [...errors];
}
// the values 'null' will be empty string as initial values
function normalizeValues(values: any) {
  return Object.keys(values).reduce(
    (acc, key) => {
      acc[key] = values[key] === null ? "" : values[key];
      return acc;
    },
    {} as Record<string, any>,
  );
}

watch(
  () => values,
  (newValues) => {
    isDirty.value =
      JSON.stringify(normalizeValues(newValues)) !== JSON.stringify(normalizeValues(initialValues));
    emitter.emit("is:dirty", isDirty.value);
  },
  { deep: true },
);
</script>

<template>
  <form
    ref="formRef"
    class="row mt-4 ps-2 sso-manager__form sso-manager__form-edit-users"
    novalidate
    autocomplete="off"
    @submit="onSubmit"
    @reset="onReset"
  >
    <div class="col-6">
      <div class="form-group field-required">
        <BiInput
          name="input-field-username"
          v-model="username"
          type="text"
          autocomplete="new-username"
          :label="t(`${moduleId}.users.user_name`)"
          :placeholder="t(`${moduleId}.users.user_name`)"
          :default-return-if-not-value="'null'"
          :errors="printError(errors.username)"
        />
      </div>
      <div class="form-group field-required">
        <BiInput
          name="input-field-description"
          v-model="description"
          type="text"
          autocomplete="new-description"
          :label="t(`${moduleId}.users.description`)"
          :placeholder="t(`${moduleId}.users.description`)"
          :default-return-if-not-value="'null'"
          :errors="printError(errors.description)"
        />
      </div>
      <div class="form-group">
        <BiInput
          name="input-field-password"
          v-model="password"
          type="password"
          autocomplete="new-password"
          :label="t(`${moduleId}.users.password`)"
          :placeholder="t(`${moduleId}.users.password`)"
          :errors="printError(errors.password)"
          :default-return-if-not-value="'undefined'"
        />
      </div>
      <div class="form-group">
        <BiInput
          name="input-field-confirmPassword"
          v-model="confirmPassword"
          type="password"
          :label="t(`${moduleId}.users.confirm_password`)"
          :placeholder="t(`${moduleId}.users.confirm_password`)"
          :errors="printError(errors.confirmPassword)"
          :default-return-if-not-value="'undefined'"
        />
      </div>

      <div class="form-group field-required">
        <BiInput
          name="input-field-email"
          v-model="email"
          type="email"
          :hide-arrows="true"
          :label="t(`${moduleId}.users.email`)"
          :placeholder="t(`${moduleId}.users.email`)"
          :errors="printError(errors.email)"
        />
      </div>
      <div class="mb-5 field-required">
        <BiAutocompleteNext
          name="input-field-language"
          v-model="language"
          :items="userLocaleList"
          :item-value="'code'"
          :item-title="'description'"
          :min-search-lenght="1"
          :label-no-result="`${t(`${moduleId}.form_errors.no_results`)}`"
          :label="t(`${moduleId}.users.locale`)"
          :placeholder="t(`${moduleId}.users.locale`)"
          :label-no-items="`${t(`${moduleId}.form_errors.no_results`)}`"
          :errors="printError(errors.userLocale)"
          required
        >
        </BiAutocompleteNext>
      </div>
      <div class="mb-5 field-required">
        <BiAutocompleteNext
          name="input-field-dateFormat"
          v-model="dateFormat"
          :items="dataFormatList"
          :item-value="'value'"
          :item-title="'description'"
          :min-search-lenght="1"
          :label-no-result="`${t(`${moduleId}.form_errors.no_results`)}`"
          :label="t(`${moduleId}.users.format_date`)"
          :placeholder="t(`${moduleId}.users.format_date`)"
          :label-no-items="`${t(`${moduleId}.form_errors.no_results`)}`"
          :errors="printError(errors.dateFormat)"
          required
        >
        </BiAutocompleteNext>
      </div>
      <div class="my-5">
        <BiToggle
          :label="t(`${moduleId}.users.changePassword`)"
          name="input-field-isModifyPasswordOnNextLogin"
          v-model="isModifyPasswordOnNextLogin"
          isDisabled
        />
      </div>
    </div>

    <div class="col-12">
      <div class="col-12 my-2">
        <BiButton color="primary" is-outlined type="reset">
          {{ t(`${moduleId}.general.cancel`) }}
        </BiButton>
        <BiButton class="mx-2" color="success" type="submit">
          {{ t(`${moduleId}.general.confirm`) }}
        </BiButton>
      </div>
    </div>
  </form>
</template>

<style lang="scss">
.sso-manager__form-edit-users {
  .multiselect.it-list.form-control {
    box-shadow: none;
  }
}
</style>
<style scoped lang="scss">
:deep([type="password"]) {
  &::-ms-reveal {
    display: none;
  }
}
</style>
