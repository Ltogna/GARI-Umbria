<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import { computed, defineProps } from "vue";
import { useI18n } from "vue-i18n";

const { t } = useI18n();
const moduleId = useModuleId();

const props = defineProps<{
  username?: string;
  infoInternal?: boolean;
}>();

const internalUserHeader = computed(() => {
  return t(`${moduleId}.users.internal_user_header`, {
    data: props.infoInternal ? t(`${moduleId}.general.yes`) : t(`${moduleId}.general.no`),
  });
});
</script>

<template>
  <div class="w-100 d-flex col-12 text-white justify-content-between p-2 mandate-header-bar">
    <div class="text-left px-2">
      {{ username?.toLocaleUpperCase() }}
    </div>
    <span class="justify-content-end pe-sm-2 status-nowrap">
      {{ internalUserHeader }}
    </span>
  </div>
</template>

<style lang="scss" scoped>
.mandate-header-bar {
  background-color: var(--bs-primary) !important;
  font-weight: 500 !important;
  padding-left: 20px !important;
}

@media (min-width: 500px) {
  .status-nowrap {
    white-space: nowrap !important;
  }
}
</style>
