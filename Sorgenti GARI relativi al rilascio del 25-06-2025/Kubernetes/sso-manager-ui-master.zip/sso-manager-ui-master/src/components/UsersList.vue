<script setup lang="ts">
import useDateFormat from "@/composables/useDateFormat";
import useModuleId from "@/composables/useModuleId";
import { RouteName } from "@/models/routes";
import type { UserDataModel } from "@/models/users";
import { getUsersList } from "@/resources/api/users";
import { useNotificationStore } from "@/stores/notification";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiChip from "@abaco/bootstrap-italia-components/src/components/BiChip/BiChip.vue";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { useRouteQuery } from "@vueuse/router";
import { computed, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
const moduleId = useModuleId();
const { t } = useI18n();
const router = useRouter();
const { dateFormat } = useDateFormat();
const notificationStore = useNotificationStore();

const isLoading = ref(false);
const users = ref<UserDataModel[]>([]);
const search = useRouteQuery("search", "");
const nextKey = ref<string>();
const isError = ref<boolean>(false);

const props = defineProps<{
  userName: string;
}>();

onMounted(async () => {
  isLoading.value = true;
  nextKey.value = undefined;
  const resp = await getUsersList(search.value, nextKey.value);
  if (resp.errorType === ErrorType.NONE) {
    users.value = resp.data.records;
    nextKey.value = resp.data.nextKey ?? undefined;
  } else {
    console.warn(resp);
    await notificationStore.setMessage(resp);
    isError.value = true;
  }
  isLoading.value = false;
});

const goToDetailUser = (user: UserDataModel) => {
  router.push({
    name: RouteName.USER_EDIT,
    params: { username: user.userName },
    query: { search: search.value },
  });
};

const userNameChips = computed(() => {
  if (props.userName) {
    return t(`${moduleId}.users.username_or_desc_chip`, { name: props.userName.toUpperCase() });
  }
  return null;
});

async function loadMore() {
  isLoading.value = true;
  const resp = await getUsersList(search.value, nextKey.value ?? undefined);
  if (resp.errorType === ErrorType.NONE) {
    users.value = [...users.value, ...resp.data.records];
    nextKey.value = resp.data.nextKey ?? undefined;
  } else {
    console.warn(resp);
    await notificationStore.setMessage(resp);
  }
  isLoading.value = false;
}
</script>

<template>
  <BiChip :model-value="!!userNameChips" :label="userNameChips ?? '-'"></BiChip>

  <BiTable
    class="table-hover mb-0 table-responsive mt-3"
    extraTableClasses="table-head-bg"
    is-custom
    responsive-breakpoint="md"
    isRowHover
  >
    <template #head>
      <tr class="bg-light">
        <th scope="col">
          {{ t(`${moduleId}.users.user_name`) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.users.description`) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.users.last_login`) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.users.blocked`) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.users.internal`) }}
        </th>
        <th scope="col">
          <BiHiddenContent :text="t(`${moduleId}.action`)"> </BiHiddenContent>
        </th>
      </tr>
    </template>
    <template #body>
      <tr v-for="user in users" :key="user.userId">
        <td :data-label="`${t(`${moduleId}.users.user_name`)}:`" class="text-break max-w-xs">
          {{ user.userName }}
        </td>
        <td :data-label="`${t(`${moduleId}.users.description`)}:`">
          {{ user.description }}
        </td>
        <td :data-label="`${t(`${moduleId}.users.last_login`)}:`">
          {{ user.lastLoginDate ? dateFormat(user.lastLoginDate, true) : "" }}
        </td>
        <td :data-label="`${t(`${moduleId}.users.blocked`)}:`">
          {{
            user.internalUser
              ? user.isLocked === "Y"
                ? t(`${moduleId}.general.yes`)
                : t(`${moduleId}.general.no`)
              : undefined
          }}
        </td>
        <td :data-label="`${t(`${moduleId}.users.internal`)}:`">
          {{ user.internalUser ? t(`${moduleId}.general.yes`) : t(`${moduleId}.general.no`) }}
        </td>
        <td>
          <div class="d-flex flex-nowrap justify-content-end">
            <BiIconButton
              class="me-2"
              is-outlined
              :title="t(`${moduleId}.users.goto_detail_user`)"
              :icon="'arrow-right'"
              icon-style="fas"
              :color="'secondary'"
              @click="() => goToDetailUser(user)"
            />
          </div>
        </td>
      </tr>
      <tr class="show-more-row" v-if="nextKey">
        <td colspan="9999" class="text-center">
          <BiButton
            color="primary"
            is-outlined
            class="py-1 px-2"
            :is-disabled="isLoading"
            :tabindex="1"
            @click="loadMore()"
          >
            {{ t(`${moduleId}.general.load_more`) }}
          </BiButton>
        </td>
      </tr>
    </template>
  </BiTable>

  <BiAlert
    v-if="!isLoading && !users.length && !isError"
    isInfo
    class="mt-3"
    :title="t(`${moduleId}.alerts.no_users_found`)"
  />
  <BiAlert
    v-else-if="isError"
    isError
    class="mt-3"
    :title="t(`${moduleId}.errors.GENERIC_ERROR`)"
  />
</template>
