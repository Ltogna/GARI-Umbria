<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import { useI18n } from "vue-i18n";
import { useRouteQuery } from "@vueuse/router";
import { useRouter } from "vue-router";
import { RouteName } from "@/models/routes";
import { useForm } from "vee-validate";
import { toTypedSchema } from "@vee-validate/zod";
import { z } from "zod";

const { t } = useI18n();
const router = useRouter();
const moduleId = useModuleId();
const search = useRouteQuery("search", "");

const FormModel = z.object({
  search: z
    .string({
      message: t(`${moduleId}.users.user_search_form_error`),
      invalid_type_error: t(`${moduleId}.users.user_search_form_error`),
    })
    .min(1, t(`${moduleId}.users.user_search_form_error`)),
});

const { handleSubmit, defineField, resetForm, errors, submitCount } = useForm({
  initialValues: {
    search: search.value,
  },
  validationSchema: toTypedSchema(FormModel),
  validateOnMount: false,
});

const [searchModel] = defineField("search");

const formHandler = handleSubmit(function (values) {
  router.push({ name: RouteName.USERS_LIST, query: { search: values.search } });
});

function resetFormHandler() {
  search.value = "";
  resetForm({
    values: {
      search: "",
    },
  });
}
</script>

<template>
  <form @submit="formHandler" @reset="resetFormHandler" class="pt-5" novalidate>
    <div class="row">
      <div class="col-md-6 form-group">
        <BiInput
          v-model="searchModel"
          type="search"
          :label="t(`${moduleId}.users.search_user`)"
          :placeholder="t(`${moduleId}.users.user_name_or_desc`)"
          :tabindex="1"
          :errors="submitCount > 0 && errors.search ? [errors.search] : []"
        />
      </div>
    </div>
    <div class="row">
      <div class="d-flex justify-content-center col-md-12 form-group">
        <BiButton type="reset" size="lg" class="btn" color="secondary" is-outlined :tabindex="1">
          {{ t(`${moduleId}.cancel`) }}
        </BiButton>
        <BiButton type="submit" size="lg" class="btn ms-3" color="success">
          {{ t(`${moduleId}.search`) }}
        </BiButton>
      </div>
    </div>
  </form>
</template>
