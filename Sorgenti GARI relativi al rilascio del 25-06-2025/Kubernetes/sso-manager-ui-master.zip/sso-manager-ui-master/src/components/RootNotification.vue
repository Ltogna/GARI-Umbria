<script setup lang="ts">
import useModuleId from "@/composables/useModuleId";
import { useNotificationStore } from "@/stores/notification";
import BiNotification from "@abaco/bootstrap-italia-components/src/components/BiNotification/BiNotification.vue";
import { computed } from "vue";
import { useI18n } from "vue-i18n";

const { t } = useI18n();
const moduleId = useModuleId();

const notificationStore = useNotificationStore();
const showNotification = computed(() => !!notificationStore.message);
const onCloseNotification = (value: boolean) => {
  if (!value) notificationStore.$reset();
};
//TODO: notification text required for accessibility
</script>

<template>
  <BiNotification
    is-dismissible
    class="sso-manager__root-notification"
    :title="
      !notificationStore.isWarning
        ? notificationStore.isError
          ? t(`${moduleId}.errors.error`)
          : notificationStore.message
        : t(`${moduleId}.general.warning`)
    "
    :model-value="showNotification"
    @update:model-value="(value: boolean) => onCloseNotification(value)"
    :variant="
      !notificationStore.isWarning
        ? notificationStore.isError
          ? 'error'
          : 'success'
        : 'warning'
    "
    :text="
      notificationStore.isError || notificationStore.isWarning
        ? notificationStore.message
        : undefined
    "
    :icon="
      !notificationStore.isWarning
        ? notificationStore.isError
          ? 'circle-xmark'
          : 'circle-check'
        : 'triangle-exclamation'
    "
  ></BiNotification>
</template>

<style lang="scss">
.sso-manager {
  &__root-notification {
    z-index: calc(var(--bs-z-index-modal, 1020) + 1) !important;
  }
}
</style>
