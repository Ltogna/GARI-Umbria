<script setup lang="ts">
import useDateFormat from "@/composables/useDateFormat";
import useModuleId from "@/composables/useModuleId";
import type { RoleModel } from "@/models/roles";
import type { UserDataModel } from "@/models/users";
import { deleteRolesToUser } from "@/resources/api/roles";
import { useConfigStore } from "@/stores/config";
import { useNotificationStore } from "@/stores/notification";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";

import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { ref } from "vue";
import { useI18n } from "vue-i18n";
const moduleId = useModuleId();
const { t } = useI18n();
const { dateFormat } = useDateFormat();
const notificationStore = useNotificationStore();
const configStore = useConfigStore();

const emits = defineEmits<{
  reload: [];
}>();
const props = defineProps<{ user: UserDataModel }>();

const deleteModalOpen = ref(false);
const roleToDelete = ref<RoleModel | null>(null);

const openDeleteModal = (role: RoleModel) => {
  roleToDelete.value = role;
  deleteModalOpen.value = true;
};

const confirmDeleteRole = async () => {
  if (roleToDelete.value) {
    const resp = await deleteRolesToUser(props.user.userName, [roleToDelete.value.roleCode]);
    if (resp.errorType === ErrorType.NONE) {
      emits("reload");
      roleToDelete.value = null;
      deleteModalOpen.value = false;
    } else {
      console.warn(resp);
      await notificationStore.setMessage(resp);
    }
  }
};

const closeDeleteModal = () => {
  roleToDelete.value = null;
  deleteModalOpen.value = false;
};
</script>
<template>
  <BiTable
    v-if="user.userRoles && user.userRoles.length > 0"
    class="table-hover mb-0 table-responsive"
    extraTableClasses="table-head-bg"
    is-custom
    responsive-breakpoint="md"
    isRowHover
  >
    <template #head>
      <tr class="bg-light">
        <th scope="col">
          {{ t(`${moduleId}.roles.name`) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.roles.description`) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.roles.assignment_date`) }}
        </th>
        <th scope="col">
          <BiHiddenContent :text="t(`${moduleId}.action`)"> </BiHiddenContent>
        </th>
      </tr>
    </template>
    <template #body>
      <tr v-for="role in user.userRoles" :key="role.roleCode">
        <td :data-label="`${t(`${moduleId}.roles.name`)}:`" class="text-break max-w-xs">
          {{ role.roleCode }}
        </td>
        <td :data-label="`${t(`${moduleId}.roles.description`)}:`">
          {{ role.description }}
        </td>
        <td :data-label="`${t(`${moduleId}.roles.assignment_date`)}:`">
          {{ role.assignmentDate ? dateFormat(role.assignmentDate, true) : "-" }}
        </td>
        <td>
          <div class="d-flex flex-nowrap justify-content-end">
            <BiIconButton
              v-if="configStore.canEditRoles(user)"
              class="me-2"
              is-outlined
              :title="t(`${moduleId}.roles.delete`)"
              :icon="'trash'"
              icon-style="fas"
              :color="'danger'"
              @click="openDeleteModal(role)"
            />
          </div>
        </td>
      </tr>
    </template>
  </BiTable>
  <BiModal
    v-model="deleteModalOpen"
    :title="t(`${moduleId}.roles.delete_role_alert_title`)"
    size="lg"
    class="sso-manager__modal"
    extra-header-class="p-4"
    extra-footer-class="justify-content-center"
  >
    <template #body>
      {{ t(`${moduleId}.roles.delete_role_warning_message`) }}
    </template>
    <template #footer>
      <BiButton color="primary" is-outlined @click="closeDeleteModal">
        {{ t(`${moduleId}.cancel`) }}
      </BiButton>
      <BiButton color="danger" @click="confirmDeleteRole">
        {{ t(`${moduleId}.general.proceed`) }}
      </BiButton>
    </template>
  </BiModal>
</template>
