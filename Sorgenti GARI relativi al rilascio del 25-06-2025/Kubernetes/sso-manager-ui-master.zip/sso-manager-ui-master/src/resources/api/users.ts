/**
 * @file User API client
 * This file contains functions for interacting with the user-related endpoints of the API.
 */

import { MODULE_ID } from "@/constants";
import i18n from "@/i18n";
import {
  CreateUserUsernameSchema,
  LanguageListSchema,
  SelectListI18nSchema,
  SelectListResponseSchema,
  UserDataSchema,
  UsersDataListSchema,
  type CreateUserBaseModelOff,
  type CreateUserUsernameModel,
  type LanguageListModel,
  type SelectI18nModel,
  type SelectListI18nModel,
  type SelectModel,
  type UpdateUserPayloadModel,
  type UserDataModel,
  type UsersDataListModel,
} from "@/models/users";
import { ErrorType, type HttpJsonResult } from "@abaco/safe-rest/src/HTTPClient";
import { httpSSOClientServer as http } from "./http";

export async function getUsersList(
  search?: string,
  nextKey?: string,
): Promise<HttpJsonResult<UsersDataListModel>> {
  const params: Record<string, string> = {};
  if (search) {
    params.search = search;
  }
  if (nextKey) {
    params.nextKey = nextKey;
  }
  return http.getJson(UsersDataListSchema, `/public/v1/user-management/users`, {
    params,
  });
}

/**
 * Retrieves user data by username.
 *
 * This function makes a GET request to the API to fetch user data for a specific username.
 * The response is validated against the UserDataSchema.
 *
 * @param {string} username - The username of the user to retrieve.
 * @returns {Promise<HttpJsonResult<UserDataModel>>} A promise that resolves to the HTTP result containing the user data.
 * @throws Will throw an error if the API request fails or if the response doesn't match the UserDataSchema.
 *
 * @example
 * const result = await getUserByUsername('johndoe');
 * if (result.ok) {
 *   console.log(result.data);
 * } else {
 *   console.error(result.error);
 * }
 */
// export async function getUserByUsername(username: string): Promise<HttpJsonResult<UserDataModel>> {
//   return http.getJson(UserDataSchema, `/public/v1/users/${encodeURIComponent(username)}`);
// }

export async function getUserByUsername(username: string): Promise<HttpJsonResult<UserDataModel>> {
  return await http.getJson(
    UserDataSchema,
    `/public/v1/user-management/users/${encodeURI(username)}`,
  );
}

export async function createUser(
  data: CreateUserBaseModelOff,
): Promise<HttpJsonResult<CreateUserUsernameModel>> {
  return await http.postJson(CreateUserUsernameSchema, `/public/v1/user-management`, data);
}

export async function updateUser(
  username: string,
  data: UpdateUserPayloadModel,
): Promise<HttpJsonResult<UserDataModel>> {
  return await http.putJson(
    UserDataSchema,
    `/public/v1/user-management/users/${encodeURI(username)}`,
    data,
  );
}

const { t, te } = i18n.global;

/**
 * Transforms a selected model into an internationalized model.
 *
 * This function returns a function that takes a `SelectModel` and returns a `SelectI18nModel`.
 * If the selected value has a corresponding internationalized description, it will use that.
 * Otherwise, it will use the selected value as the description.
 *
 * @returns A function that takes a `SelectModel` and returns a `SelectI18nModel`.
 */
export function turnOnWithI18n(): (selected: SelectModel) => SelectI18nModel {
  return (selected: SelectModel): SelectI18nModel => {
    if (te(`${MODULE_ID}.dateFormats.${selected.value}`)) {
      return {
        value: selected.value,
        description: t(`${MODULE_ID}.dateFormats.${selected.value}`),
      };
    } else {
      return { value: selected.value, description: selected.value };
    }
  };
}

const formatDates = {
  records: [{ value: "dd/MM/yyyy" }, { value: "MM/dd/yyyy" }],
};

export async function getFormatDatesList(): Promise<HttpJsonResult<SelectListI18nModel>> {
  try {
    const dataResponse = SelectListResponseSchema.parse(formatDates);
    dataResponse.records = dataResponse.records.map(turnOnWithI18n());
    const data = SelectListI18nSchema.parse(dataResponse);

    return {
      errorType: ErrorType.NONE,
      data,
      response: new Response(JSON.stringify(dataResponse)),
    };
  } catch (err) {
    return {
      errorType: ErrorType.OTHER,
      err,
    };
  }
}

/**
 * Fetches the list of user locales.
 *
 * @returns {Promise<HttpJsonResult<LanguageListModel>>} A promise that resolves to LanguageListModel objects wrapped in an HttpJsonResult.
 */
export async function getUserLocalesList(): Promise<HttpJsonResult<LanguageListModel>> {
  return http.getJson(LanguageListSchema, `/public/v1/user-management/languages`);
}
