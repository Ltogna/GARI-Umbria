import { FORCED_CONTEXT, SSO_BASE_URL } from "@/constants";
import { isStandalone } from "@/utils/isStandalone";
import {
  ErrorType,
  HTTPClient,
  type HTTPClientOptions,
  type HttpResult,
  type RequestConfig,
} from "@abaco/safe-rest/src/HTTPClient";
import { getUserData, installSso2RequestConfigProvider } from "@abaco/safe-rest/src/sso2";

class HTTPSSOClientServer extends HTTPClient {
  constructor(config: HTTPClientOptions = {}) {
    super(config);
  }

  public async provideConfig(config?: RequestConfig): Promise<RequestConfig> {
    const provide = await super.provideConfig(config);
    if (isStandalone && provide.params && provide.params._nc) {
      delete provide.params._nc;
    }
    return provide;
  }

  protected async performCall(
    method: string,
    url: string,
    config?: RequestConfig | undefined,
    body?: BodyInit | undefined,
  ): Promise<HttpResult> {
    const user = getUserData();
    if (!user) {
      return {
        errorType: ErrorType.OTHER,
        err: 401,
      };
    }
    return super.performCall(method, `${SSO_BASE_URL}${user.tenant}${url}`, config, body);
  }
}
export const http = new HTTPClient({ forcedContext: FORCED_CONTEXT });
export const httpSSOClientServer = new HTTPSSOClientServer({
  forcedContext: FORCED_CONTEXT,
});

installSso2RequestConfigProvider(httpSSOClientServer, "/sso2");
installSso2RequestConfigProvider(http, "/sso2");
