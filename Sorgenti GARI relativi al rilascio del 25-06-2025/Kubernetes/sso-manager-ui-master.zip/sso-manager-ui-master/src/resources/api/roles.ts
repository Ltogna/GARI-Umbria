/**
 * @file Roles API client
 * This file contains functions for interacting with the roles-related endpoints of the API.
 */

import {
  ResponseRolesListSchema,
  type FormSearchRolesModel,
  type ResponseRolesListModel,
} from "@/models/roles";
import { type HttpJsonResult, type HttpResult } from "@abaco/safe-rest/src/HTTPClient";
import { httpSSOClientServer as http } from "./http";

export async function getRoles(
  formSearchRoles: FormSearchRolesModel,
  nextKey?: string,
): Promise<HttpJsonResult<ResponseRolesListModel>> {
  const params: Record<string, string> = {};
  if (formSearchRoles.search) {
    params.search = formSearchRoles.search;
  }
  if (nextKey) {
    params.nextKey = nextKey;
  }
  return http.getJson(ResponseRolesListSchema, `/public/v1/user-management/roles`, { params });
}

export function addRolesToUser(username: string, roles: string[]): Promise<HttpResult> {
  return http.post(
    `/public/v1/user-management/${decodeURI(username)}/roles`,
    JSON.stringify(roles),
    {
      headers: {
        "Content-Type": "application/json",
      },
    },
  );
}

export function deleteRolesToUser(username: string, roleCode: string[]): Promise<HttpResult> {
  return http.delete(`/public/v1/user-management/${decodeURI(username)}/roles`, {
    params: {
      roleCode,
    },
  });
}
