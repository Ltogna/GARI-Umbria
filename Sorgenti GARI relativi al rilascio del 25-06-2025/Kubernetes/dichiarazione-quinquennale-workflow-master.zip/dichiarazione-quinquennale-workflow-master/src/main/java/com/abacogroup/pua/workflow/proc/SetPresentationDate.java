package com.abacogroup.pua.workflow.proc;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.v2.procedures.ApplicationProcedure;
import com.abacogroup.workflow.sdk.beans.ProcessData;

public class SetPresentationDate extends ApplicationProcedure {

    @Override
    protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {
        Long applicationId = getApplicationsWorkflowParams().getApplicationId();
        env.getApplicationDetailsService().setPresentationDate(processData.getTenantId(), applicationId, processData.getAuthContext().getUserId());
    }

}
