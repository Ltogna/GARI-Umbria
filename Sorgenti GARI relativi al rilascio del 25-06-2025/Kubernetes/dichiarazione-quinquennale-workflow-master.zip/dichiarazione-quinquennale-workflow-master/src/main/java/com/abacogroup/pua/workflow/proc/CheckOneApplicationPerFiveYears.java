package com.abacogroup.pua.workflow.proc;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.applicationworkflowsdk.model.GetApplicationFilters;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.pua.workflow.model.TipologiaDichiarazione;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Optional;

@Slf4j
public class CheckOneApplicationPerFiveYears extends BaseProcedure {

    private static final String APP_MODULE_CODE = "DICHIARAZIONE_QUINQUENNALE";
    private static final String APP_MODULE_CODE_RECTIFIED = "DICHIARAZIONE_QUINQUENNALE_RECTIFIED";

    @Override
    protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {
        
        log.debug("Starting CheckOneApplicationPerFiveYears procedure execution");
        
    	TipologiaDichiarazione tipologiaDichiarazione = processData.<TipologiaDichiarazione>getGlobalVar(TipologiaDichiarazione.KEY)
                .orElseThrow();
        
        log.debug("Retrieved TipologiaDichiarazione with year: {}", tipologiaDichiarazione.getYear());

        ApplicationsWorkflowParams params = getApplicationsWorkflowParams();
        
        Long amendedApplicationId = params.getAmendedApplicationId();
        log.debug("Amended application ID: {}", amendedApplicationId);
		
    	if(amendedApplicationId != null){
			
    		int thisAppYear = tipologiaDichiarazione.getYear();
            log.debug("Current application year: {}", thisAppYear);

    		int amendedAppYear = 
					getTipologiaDichiarazioneYear(amendedApplicationId, processData, env).get(); // rectified App
		    
            log.debug("Amended application year: {}", amendedAppYear);
		
			if ( thisAppYear != amendedAppYear ) {
                log.debug("Year mismatch detected - current: {}, amended: {}", thisAppYear, amendedAppYear);
				String code = "APP_YEAR_CANNOT_BE_DIFFERENT_AS_RECTIFIED";
				String description = "Non puoi inserire un anno differente rispetto a l'anno della domanda che stai rettificando (%s).";
				var workflowMessage = new WorkflowMessage(code, String.format(description, amendedAppYear), WorkflowMessage.Type.ERROR);
				processData.getWorkflowMessages().add(workflowMessage);
			} else {
                log.debug("Year validation passed for amended application");
            }
		}

        String currentModuleCode = env.getApplicationDetailsService().retrieveApplicationDetails(processData.getTenantId(),
                params.getApplicationId(), (User) processData.getAuthContext().getPrincipal()).getModuleCode();
        
        log.debug("Current application module code: {}", currentModuleCode);
        
        if(APP_MODULE_CODE_RECTIFIED.equals(currentModuleCode)){
            log.debug("Application is rectified type, skipping five-year check");
            return;
        }

        log.debug("Searching for existing applications for party ID: {}", params.getPartyId());
        
        List<ApplicationDetailsPublicDTO> apps = env.getApplicationDetailsService().getApplicationsByParty(processData.getTenantId(), params.getPartyId(),
                GetApplicationFilters.builder().moduleCode(APP_MODULE_CODE).build(),
                (User) processData.getAuthContext().getPrincipal());

        log.debug("Found {} applications for party", apps.size());

        boolean found = apps.stream()
                .filter(a -> !a.getApplicationId().equals(params.getApplicationId())) // Not the current app
                .filter(a -> {
                    boolean isValidStatus = "PROTOCOLLED".equals(a.getProcessStatus()) || "RECTIFIED".equals(a.getProcessStatus());
                    log.debug("Application ID {} has status: {} (valid: {})", a.getApplicationId(), a.getProcessStatus(), isValidStatus);
                    return isValidStatus;
                })
                .anyMatch(a -> {
                    Optional<Integer> otherAppYear = Optional.ofNullable(puaAppRequest(TipologiaDichiarazione.class, "tipologia-dichiarazione", a.getApplicationId()).getYear());
                    boolean overlaps = lessThanFiveYearsDifference(tipologiaDichiarazione.getYear(), otherAppYear);
                    log.debug("Checking overlap between current year {} and application {} year {}: {}", 
                        tipologiaDichiarazione.getYear(), a.getApplicationId(), otherAppYear.orElse(null), overlaps);
                    return overlaps;
                });

        log.debug("Five-year overlap check result: {}", found);

        if (found) {
            log.debug("Adding error message for existing quinquennial application");
            processData.getWorkflowMessages()
                    .add(new WorkflowMessage("APP_ALREADY_EXIST", "Esiste già una domanda quinquennale comprendente l'anno selezionato", WorkflowMessage.Type.ERROR));
        }
        
        log.debug("CheckOneApplicationPerFiveYears procedure execution completed");
    }

    private boolean lessThanFiveYearsDifference(Integer year, Optional<Integer> other) {
        log.debug("Checking five-year difference between {} and {}", year, other.orElse(null));
        
        if (year == null && other.isEmpty()) {
            log.debug("Both years are null/empty, returning true");
            return true;
        }

        if (year == null || other.isEmpty()) {
            log.debug("One year is null/empty, returning false");
            return false;
        }

        boolean result = year >= other.get() && year <= other.get() + 5;
        log.debug("Year {} is within range [{}, {}]: {}", year, other.get(), other.get() + 5, result);
        return result;
    }

    public Optional<Integer> getTipologiaDichiarazioneYear(Long applicationId, ProcessData processData, IAgriProcedureEnvironment env) {
        
        log.debug("Retrieving TipologiaDichiarazione year for application ID: {}", applicationId);
        
        String url = env.getProperty("puaAppFormsUrl").orElseThrow().toString();
        log.debug("Using PUA app forms URL: {}", url);

        Client client = env.getJerseyClient().orElseThrow();
        WebTarget target = processData.getAuthContext()
                .getAuthenticatedWebTarget(client, url)
                .path("/master/v1/applications/")
                .path(applicationId.toString())
                .path("tipologia-dichiarazione");
        
        log.debug("Making GET request to: {}", target.getUri());
        
        try (Response response = target.request(MediaType.APPLICATION_JSON).get()) {
            int status = response.getStatus();
            log.debug("HTTP response status: {}", status);
            
            if (status == 404) {
                log.debug("TipologiaDichiarazione not found for application {}", applicationId);
                return Optional.empty();
            }

            if (status < 200 || status > 299) {
                log.debug("Bad HTTP response status {} for application {}", status, applicationId);
                throw new IllegalStateException("Got a bad response loading 'tipologia dichiarazione' for app" + applicationId + "; status is: " + status);
            }

            TipologiaDichiarazione tipologiaDichiarazione = response.readEntity(TipologiaDichiarazione.class);
            Integer year = tipologiaDichiarazione.getYear();
            log.debug("Retrieved year {} for application {}", year, applicationId);
            return Optional.ofNullable(year);
            
        } catch (Exception e) {
            log.error("Exception during loading of tipologia dichiarazione for app {}: {}", applicationId, e.getMessage(), e);
            throw e;
        }
    }
}
