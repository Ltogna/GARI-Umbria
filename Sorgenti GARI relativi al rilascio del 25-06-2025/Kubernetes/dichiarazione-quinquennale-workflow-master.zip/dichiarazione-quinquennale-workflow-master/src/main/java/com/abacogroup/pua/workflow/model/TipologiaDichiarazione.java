package com.abacogroup.pua.workflow.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class TipologiaDichiarazione {
    public static final String KEY = TipologiaDichiarazione.class.getName();

    private Integer year;
}
