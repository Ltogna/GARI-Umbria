package com.abacogroup.pua.workflow.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class SectorsDTO {

	public int nextKey;

	public int count;

	public List<Sector> records;
 
	@Data
	@SuperBuilder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class Sector {
		
		public Integer id;
		
		public String description;
		
		@JsonProperty("short_descr")
		public String shortDescr;
		
		@JsonProperty("sector_code")
		public String sectorCode;
		
		public String srs;
		
		public String geom;
		
		@JsonProperty("world_geom")
		public String worldGeom;
		
	}
	
	public Map<String, Sector> getSectorsAsMap() {
		return (Map<String, Sector>) records.stream()
			    .collect(Collectors.toMap(
			        Sector::getSectorCode,    // chiave
			        sector -> sector  // valore
			    ));
	}
}
