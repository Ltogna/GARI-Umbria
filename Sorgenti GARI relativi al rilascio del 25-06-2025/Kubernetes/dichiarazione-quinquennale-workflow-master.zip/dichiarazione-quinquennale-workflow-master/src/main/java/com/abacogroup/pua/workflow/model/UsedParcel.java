package com.abacogroup.pua.workflow.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
public class UsedParcel {
    public static final String KEY = UsedParcel.class.getName();

    private String sectorCode;
    private String blockCode;
    private String parcelCode;
    private String subParcelCode;
    private Long applicationId;
    private Integer usedArea;
    private Integer availableArea;

}
