package com.abacogroup.pua.workflow.proc;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.pua.workflow.dto.SectorsDTO;
import com.abacogroup.pua.workflow.model.UsedParcel;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.proc.StopTransitionException;
import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.core.Jdbi;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CheckParcelUsedArea extends BaseProcedure {

	public static final String PUA_APP_FORMS = "PUA_APP_FORMS";

	private static final String CONTROLLED = "CONTROLLED";
	private static final String PROTOCOLLED = "PROTOCOLLED";

	@Override
	protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {
		
		List<UsedParcel> usedParcels = getUsedPercels(env);
		UsedParcel unavailableArea = getUnavailableArea(processData, env, usedParcels);

		if(unavailableArea != null){

			Map<String, List<String>> payload = new HashMap<String, List<String>>();
			payload.put("codes", List.of(unavailableArea.getSectorCode()));
			Map<String, Object> queryParams = Map.of("include_geometries", false);
			SectorsDTO sectorsDTO = lpisServerPostRequest(SectorsDTO.class, "sectors", queryParams, payload);

			String message = """
					Impossibile passare la domanda allo stato 'Controllata'. 
					La particella catastale %s %s in località %s non ha sufficiente terreno disponibile rispetto a quanto occupato.""";
			message = String.format(message, unavailableArea.getParcelCode(),
					StringUtils.isNotEmpty(unavailableArea.getSubParcelCode()) ? "(di Subalterno " + unavailableArea.getSubParcelCode() + ")" : "",
					sectorsDTO.getRecords().get(0).getDescription());
			processData.getWorkflowMessages().add(new WorkflowMessage("UNAVAILABLE_AREA_PRESENT", message,
					WorkflowMessage.Type.ERROR));

			throw new StopTransitionException();
		}

	}

	UsedParcel getUnavailableArea(ProcessData processData, IAgriProcedureEnvironment env, List<UsedParcel> usedParcels) throws Exception {

		String status = null;
		boolean isCurrentApplicationId;
		boolean  isUserParcelApplicationStatusValid;

		Map<String, ParcelSumAndMin> usedParcelsSumMap = new HashMap<>();
		
		Long currentApplicationId = getApplicationsWorkflowParams().getApplicationId();

		for (UsedParcel usedParcel : usedParcels) {
		
			status = getApplicationDetailsPublicDTO(processData, env, usedParcel.getApplicationId()).getProcessStatus();
			
			// my question will be in PRE_CONTROLLED status so we have to "bypass" the status check
			isCurrentApplicationId = currentApplicationId.equals(usedParcel.getApplicationId());
			isUserParcelApplicationStatusValid = CONTROLLED.equals(status) || PROTOCOLLED.equals(status) ;
			
			if ( isCurrentApplicationId || isUserParcelApplicationStatusValid ) {
				
				String searchingKey = usedParcel.getSectorCode() + usedParcel.getBlockCode() + usedParcel.getParcelCode() + usedParcel.getSubParcelCode();
				ParcelSumAndMin parcelSumAndMin = usedParcelsSumMap.get(searchingKey);
				
				if (parcelSumAndMin == null) {
					parcelSumAndMin = new ParcelSumAndMin();
					usedParcelsSumMap.put(searchingKey, parcelSumAndMin);
				}
				
				parcelSumAndMin.sum += usedParcel.getUsedArea();
				parcelSumAndMin.min = parcelSumAndMin.min == 0 ? usedParcel.getAvailableArea() : Math.min(parcelSumAndMin.min, usedParcel.getAvailableArea());
				
				if(parcelSumAndMin.sum > parcelSumAndMin.min){
					return usedParcel;
				}
			}
		}
		
		return null;
	}

	ApplicationDetailsPublicDTO getApplicationDetailsPublicDTO(ProcessData processData, IAgriProcedureEnvironment env,
			Long applicationId) throws Exception {
		return env.getApplicationDetailsService()
				.retrieveApplicationDetails(processData.getTenantId(), applicationId,
						(User) processData.getAuthContext().getPrincipal());
	}

	List<UsedParcel> getUsedPercels(IAgriProcedureEnvironment env) {
		Jdbi jdbi = env.getJdbi(PUA_APP_FORMS).orElseThrow();
		return jdbi.withHandle(h ->
				h.createQuery("""
								SELECT sector_code, block_code, parcel_code, sub_parcel_code, application_id, 
								SUM(used_area_sqm) AS used_area, MIN(cadastral_area_sqm) AS available_area
								FROM appfpua_five_year_declaration
								WHERE (sector_code, block_code, parcel_code, sub_parcel_code) IN
									(SELECT sector_code, block_code, parcel_code, sub_parcel_code 
									    FROM appfpua_five_year_declaration afyd WHERE application_id = :applicationId
										AND §current_timestamp§ BETWEEN dt_insert AND dt_delete) AND
									§current_timestamp§ BETWEEN dt_insert AND dt_delete
								GROUP BY sector_code, block_code, parcel_code, sub_parcel_code, application_id
								ORDER BY application_id
								""")
						.bind("applicationId", getApplicationsWorkflowParams().getApplicationId())
						.mapToBean(UsedParcel.class)
						.list()
		);
	}

	public class ParcelSumAndMin {
		Integer sum = 0;
		Integer min = 0;
	}
}
