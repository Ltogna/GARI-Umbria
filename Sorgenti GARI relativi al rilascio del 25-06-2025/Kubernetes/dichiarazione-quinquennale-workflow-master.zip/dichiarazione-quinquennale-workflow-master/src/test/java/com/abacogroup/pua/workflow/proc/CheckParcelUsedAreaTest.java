package com.abacogroup.pua.workflow.proc;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.applicationworkflowsdk.v2.procedures.ApplicationProcedure;
import com.abacogroup.applicationworkflowsdk.v2.services.ApplicationDetailsService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.pua.workflow.model.UsedParcel;
import com.abacogroup.workflow.sdk.auth.AuthContext;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.security.Principal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CheckParcelUsedAreaTest {
	
	protected static final String TENANT = "tenant";
	protected static final String LOGGED_USER_ID = "user1";
	protected static final User LOGGED_USER = new User(LOGGED_USER_ID, TENANT);
	
	@Mock
	private ApplicationDetailsService applicationDetailsService;
	
	@Mock
	private IAgriProcedureEnvironment env;

	@Mock
	private ProcessData processData;

	@Mock
	private AuthContext authContext;
	
	@Mock
	private Principal principal;

	@Mock
	private ApplicationProcedure applicationProcedure;

	@Mock
	private ApplicationsWorkflowParams applicationsWorkflowParams;

	@InjectMocks
	private CheckParcelUsedArea proc;
	 
	private static ApplicationDetailsPublicDTO adpd_CONTROLLED, adpd_PROTOCOLLED, adpd_CREATED;
	
	/**
	 * 
	 * General info:
	 * 
	 * When  <code>proc.getUnavailableArea(processData, env, list)</code> returns a null value
	 * it means that the validation succeeded
	 * 
	 */
	
	@BeforeAll
    public static void init() {
		adpd_CONTROLLED = new ApplicationDetailsPublicDTO();
        adpd_CONTROLLED.setProcessStatus("CONTROLLED");
        
        adpd_PROTOCOLLED = new ApplicationDetailsPublicDTO();
        adpd_PROTOCOLLED.setProcessStatus("PROTOCOLLED");
        
        adpd_CREATED = new ApplicationDetailsPublicDTO();
        adpd_CREATED.setProcessStatus("CREATED");

	}

    @Test
    void testGetUnavailableArea_KO_0() throws Exception {

    	/**
    	 * UsedParcel constructor parameters are: 
    	 * 		applicationId - sectorCode - blockCode - parcelCode - subParcelCode - availableArea - usedArea 
    	 */
        List<UsedParcel> list = Arrays.asList(
        		makeUsedParcel(1, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 35000, 20000), 
                makeUsedParcel(2, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 55000, 5000),
                makeUsedParcel(3, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 55000, 35000)
        );
        
        when(authContext.getPrincipal()).thenReturn(LOGGED_USER);
        when(processData.getTenantId()).thenReturn(TENANT);
        when(processData.getAuthContext()).thenReturn(authContext);
        when(env.getApplicationDetailsService()).thenReturn(applicationDetailsService);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 1L, LOGGED_USER)).thenReturn(adpd_CONTROLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 2L, LOGGED_USER)).thenReturn(adpd_CONTROLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 3L, LOGGED_USER)).thenReturn(adpd_PROTOCOLLED);
        when(processData.getGlobalVar("workflowParams")).thenReturn(Optional.of(applicationsWorkflowParams));
        when(applicationsWorkflowParams.getApplicationId()).thenReturn(1L);
         
        UsedParcel unavailableArea =  proc.getUnavailableArea(processData, env, list);
        
        assertNotNull(unavailableArea);
    }
    
    @Test
    void testGetUnavailableArea_KO_1() throws Exception {

    	/**
    	 * UsedParcel constructor parameters are: 
    	 * 		applicationId - sectorCode - blockCode - parcelCode - subParcelCode - availableArea - usedArea 
    	 */
        List<UsedParcel> list = Arrays.asList(
        		makeUsedParcel(1, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 125000, 5000), 
                makeUsedParcel(2, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 155000, 20000),
                makeUsedParcel(3, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 135000, 10000),
                makeUsedParcel(4, "A122", "BLOCK_2", "PARCEL_1", "SUBPARCEL_1", 135000, 10000),
                makeUsedParcel(5, "X445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 125000, 10000),
                makeUsedParcel(6, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 135000, 10000),
                makeUsedParcel(7, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 145000, 5000),
                makeUsedParcel(7, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 135000, 120000)
        );
        
        when(authContext.getPrincipal()).thenReturn(LOGGED_USER);
        when(processData.getTenantId()).thenReturn(TENANT);
        when(processData.getAuthContext()).thenReturn(authContext);
        when(env.getApplicationDetailsService()).thenReturn(applicationDetailsService);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 1L, LOGGED_USER)).thenReturn(adpd_CONTROLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 2L, LOGGED_USER)).thenReturn(adpd_PROTOCOLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 3L, LOGGED_USER)).thenReturn(adpd_CONTROLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 4L, LOGGED_USER)).thenReturn(adpd_CONTROLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 5L, LOGGED_USER)).thenReturn(adpd_PROTOCOLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 6L, LOGGED_USER)).thenReturn(adpd_PROTOCOLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 7L, LOGGED_USER)).thenReturn(adpd_CONTROLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 7L, LOGGED_USER)).thenReturn(adpd_PROTOCOLLED);
        when(processData.getGlobalVar("workflowParams")).thenReturn(Optional.of(applicationsWorkflowParams));
        when(applicationsWorkflowParams.getApplicationId()).thenReturn(1L);
         
        UsedParcel unavailableArea =  proc.getUnavailableArea(processData, env, list);

        assertNotNull(unavailableArea);
    }
    
    @Test
    void testGetUnavailableArea_OK_0() throws Exception {

    	/**
    	 * UsedParcel constructor parameters are: 
    	 * 		applicationId - sectorCode - blockCode - parcelCode - subParcelCode - availableArea - usedArea 
    	 */
        List<UsedParcel> list = Arrays.asList(
        		makeUsedParcel(1, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 35000, 10000), 
                makeUsedParcel(2, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 55000, 20000)
        );
        
        when(authContext.getPrincipal()).thenReturn(LOGGED_USER);
        when(processData.getTenantId()).thenReturn(TENANT);
        when(processData.getAuthContext()).thenReturn(authContext);
        when(env.getApplicationDetailsService()).thenReturn(applicationDetailsService);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 1L, LOGGED_USER)).thenReturn(adpd_CONTROLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 2L, LOGGED_USER)).thenReturn(adpd_CONTROLLED);
        when(processData.getGlobalVar("workflowParams")).thenReturn(Optional.of(applicationsWorkflowParams));
        when(applicationsWorkflowParams.getApplicationId()).thenReturn(1L);
         
        UsedParcel unavailableArea =  proc.getUnavailableArea(processData, env, list);

        assertNull(unavailableArea);
    }
    
    @Test
    void testGetUnavailableArea_OK_1() throws Exception {

    	/**
    	 * UsedParcel constructor parameters are: 
    	 * 		applicationId - sectorCode - blockCode - parcelCode - subParcelCode - availableArea - usedArea 
    	 */
        List<UsedParcel> list = Arrays.asList(
        		makeUsedParcel(1, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 35000, 10000), 
                makeUsedParcel(2, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 55000, 20000),
                makeUsedParcel(3, "G445", "BLOCK_2", "PARCEL_1", "SUBPARCEL_1", 55000, 20000)
        );
        
        when(authContext.getPrincipal()).thenReturn(LOGGED_USER);
        when(processData.getTenantId()).thenReturn(TENANT);
        when(processData.getAuthContext()).thenReturn(authContext);
        when(env.getApplicationDetailsService()).thenReturn(applicationDetailsService);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 1L, LOGGED_USER)).thenReturn(adpd_CONTROLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 2L, LOGGED_USER)).thenReturn(adpd_CONTROLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 3L, LOGGED_USER)).thenReturn(adpd_CONTROLLED);
        when(processData.getGlobalVar("workflowParams")).thenReturn(Optional.of(applicationsWorkflowParams));
        when(applicationsWorkflowParams.getApplicationId()).thenReturn(1L);
         
        UsedParcel unavailableArea =  proc.getUnavailableArea(processData, env, list);

        assertNull(unavailableArea);
    }
    
    @Test
    void testGetUnavailableArea_OK_2() throws Exception {

    	/**
    	 * UsedParcel constructor parameters are: 
    	 * 		applicationId - sectorCode - blockCode - parcelCode - subParcelCode - availableArea - usedArea 
    	 */
        List<UsedParcel> list = Arrays.asList(
        		makeUsedParcel(1, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 35000, 5000), 
                makeUsedParcel(2, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 55000, 20000),
                makeUsedParcel(3, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 35000, 10000),
                makeUsedParcel(4, "A122", "BLOCK_2", "PARCEL_1", "SUBPARCEL_1", 35000, 10000),
                makeUsedParcel(5, "X445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 35000, 10000)
        );
        
        when(authContext.getPrincipal()).thenReturn(LOGGED_USER);
        when(processData.getTenantId()).thenReturn(TENANT);
        when(processData.getAuthContext()).thenReturn(authContext);
        when(env.getApplicationDetailsService()).thenReturn(applicationDetailsService);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 1L, LOGGED_USER)).thenReturn(adpd_CONTROLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 2L, LOGGED_USER)).thenReturn(adpd_PROTOCOLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 3L, LOGGED_USER)).thenReturn(adpd_CONTROLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 4L, LOGGED_USER)).thenReturn(adpd_CONTROLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 5L, LOGGED_USER)).thenReturn(adpd_PROTOCOLLED);
        when(processData.getGlobalVar("workflowParams")).thenReturn(Optional.of(applicationsWorkflowParams));
        when(applicationsWorkflowParams.getApplicationId()).thenReturn(1L);
         
        UsedParcel unavailableArea =  proc.getUnavailableArea(processData, env, list);

        assertNull(unavailableArea);
    }
    
    @Test
    void testGetUnavailableArea_NOT_CONTROLLED() throws Exception {

    	/**
    	 * UsedParcel constructor parameters are: 
    	 * 		applicationId - sectorCode - blockCode - parcelCode - subParcelCode - availableArea - usedArea 
    	 */
        List<UsedParcel> list = Arrays.asList(
        		makeUsedParcel(1, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 35000, 10000), 
        		makeUsedParcel(2, "G445", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 55000, 20000), 
                makeUsedParcel(3, "A240", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 290000, 280000), 
                makeUsedParcel(4, "A240", "BLOCK_1", "PARCEL_1", "SUBPARCEL_1", 240000, 280000)
        );
        
        when(authContext.getPrincipal()).thenReturn(LOGGED_USER);
        when(processData.getTenantId()).thenReturn(TENANT);
        when(processData.getAuthContext()).thenReturn(authContext);
        when(env.getApplicationDetailsService()).thenReturn(applicationDetailsService);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 1L, LOGGED_USER)).thenReturn(adpd_CONTROLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 2L, LOGGED_USER)).thenReturn(adpd_CREATED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 3L, LOGGED_USER)).thenReturn(adpd_CONTROLLED);
        when(applicationDetailsService.retrieveApplicationDetails(TENANT, 4L, LOGGED_USER)).thenReturn(adpd_CREATED);
        when(processData.getGlobalVar("workflowParams")).thenReturn(Optional.of(applicationsWorkflowParams));
        when(applicationsWorkflowParams.getApplicationId()).thenReturn(1L);
         
        UsedParcel unavailableArea =  proc.getUnavailableArea(processData, env, list);

        assertNull(unavailableArea);
    }
    
    
    /**
     * 
     * @param applicationId
     * @param sectorCode
     * @param blockCode
     * @param parcelCode
     * @param subParcelCode
     * @param availableArea
     * @param usedArea
     * @return a new UsedParcel instance
     */
    private UsedParcel makeUsedParcel(Integer applicationId, String sectorCode, String blockCode, 
    		String parcelCode, String subParcelCode, Integer availableArea, Integer usedArea) {
    	 
    	return UsedParcel.builder()
    			.applicationId(Long.valueOf(applicationId))
		        .sectorCode(sectorCode)
		        .blockCode(blockCode)
		        .parcelCode(parcelCode)
		        .subParcelCode(subParcelCode)
		        .availableArea(availableArea)
		        .usedArea(usedArea)
		        .build();
    }
    
    private void logOnConsole(String callerMethod, String s) {
    	 java.util.logging.Logger.getAnonymousLogger().log(java.util.logging.Level.INFO, "caller method: " + callerMethod + 
    			 " / message: " + s);
    }
    

//  UsedParcel up1 = new UsedParcel();
//  up1.setSectorCode("G445");
//  up1.setSectorCode("BLOCK_1");
//  up1.setSectorCode("PARCEL1");
//  up1.setSectorCode("SUB1");
//  up1.setApplicationId(1L);
//  up1.setAvailableArea(50000);
//  up1.setUsedArea(40000);
//  list.add(up1);
//
//  UsedParcel up2 = new UsedParcel();
//  up1.setSectorCode("G445");
//  up1.setSectorCode("BLOCK_1");
//  up1.setSectorCode("PARCEL1");
//  up1.setSectorCode("SUB1");
//  up1.setApplicationId(2L);
//  up1.setAvailableArea(60000);
//  up1.setAvailableArea(20000);
//  list.add(up1);

}
