package com.abacogroup.pua.workflow.proc;

import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import static org.hamcrest.MatcherAssert.assertThat;

import com.abacogroup.pua.workflow.model.TipologiaDichiarazione;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class ComputeAndSetProfilesTest {

    @Test
    void testComputeProfiles() {
        ComputeAndSetProfiles proc = new ComputeAndSetProfiles();
        TipologiaDichiarazione td;
        List<String> profiles;

        td = new TipologiaDichiarazione(2024);
        profiles = proc.computeProfiles(td, Set.of("Y2024"));
        assertThat(profiles, containsInAnyOrder("Y2024"));
    }

    @Test
    void testErrorWhenYearProfileIsMissing() {
        ComputeAndSetProfiles proc = new ComputeAndSetProfiles();
        TipologiaDichiarazione td = new TipologiaDichiarazione(2025);
        assertThrows(IllegalStateException.class, () -> proc.computeProfiles(td, Set.of("Y2024")));
    }
}
