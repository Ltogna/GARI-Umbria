package com.abacogroup.pua.workflow.proc;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.abacogroup.pua.workflow.util.Const;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage.Type;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
class CheckDichiarazioneQuinquennaleCompiledTest {

    @Test
    void testCheckDichiarazioneQuinquennaleCompiled_OK() {
    	
    	CheckDichiarazioneQuinquennaleCompiled proc = new CheckDichiarazioneQuinquennaleCompiled();
        
        List<String> profiles = proc.getFormCodesToCheck();
        
        assertThat(profiles, containsInAnyOrder(
        		 Const.PUA_DICHIARAZIONE_QUINQUENNALE, Const.PUA_DICHIARAZIONE_FINALE));

//        Set<String> allowedProfiles = proc.getAllowedProfiles();
//        assertThat(allowedProfiles, containsInAnyOrder(Const.SEMPLICE));
        
        WorkflowMessage workflowMessage = proc.createMessage( Const.PUA_DICHIARAZIONE_QUINQUENNALE, 
        		Const.PUA_DICHIARAZIONE_QUINQUENNALE, null, null);
        
        assertThat(workflowMessage.getCode(), containsString(Const.PUA_DICHIARAZIONE_QUINQUENNALE_INCOMPLETED));
        assertThat(workflowMessage.getDescription(), containsString("Dichiarazione quinquennale incompleta"));
        assertEquals(workflowMessage.getType(), Type.ERROR);
    }
    
    @Test
    void testCheckDichiarazioneQuinquennaleCompiled_KO() {
    	
    	CheckDichiarazioneQuinquennaleCompiled proc = new CheckDichiarazioneQuinquennaleCompiled();
         
        WorkflowMessage workflowMessage = proc.createMessage( Const.PUA_DICHIARAZIONE_QUINQUENNALE, 
        		Const.PUA_DICHIARAZIONE_QUINQUENNALE, null, null);
        
        assertNotEquals(workflowMessage.getCode(), Const.PUA_DICHIARAZIONE_QUINQUENNALE);
    }
 
}
