package com.abacogroup.pua.workflow.proc;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.ArgumentMatchers.any;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.abacogroup.pua.workflow.util.Const;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage.Type;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
class CheckSignatureCompiledCompiledTest {

    @Test
    void testCheckProfileSempliceCompiled_OK() {
    	
    	CheckSignatureCompiled proc = new CheckSignatureCompiled();
        
        List<String> profiles = proc.getFormCodesToCheck();
        
        assertThat(profiles, containsInAnyOrder(Const.PUA_FIRMA));
 
        WorkflowMessage workflowMessage = proc.createMessage( Const.PUA_FIRMA, Const.PUA_FIRMA, any(), any());
        
        assertThat(workflowMessage.getCode(), containsString(Const.PUA_FIRMA_INCOMPLETED));
        assertThat(workflowMessage.getDescription(), containsString("Documento firmato non inserito o non valido"));
        assertEquals(workflowMessage.getType(), Type.ERROR);
         
    }
    
    @Test
    void testCheckProfileSempliceCompiled_KO() {
    	
    	CheckSignatureCompiled proc = new CheckSignatureCompiled();
        
        WorkflowMessage workflowMessage = proc.createMessage( Const.PUA_FIRMA, Const.PUA_FIRMA, any(), any());
        
        assertNotEquals(workflowMessage.getCode(), Const.PUA_FINAL_DECLARATION_INCOMPLETED);
    }
 
}
