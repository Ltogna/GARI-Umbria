package com.abacogroup.banchedati;

public class Run {
    public static void main(String[] args) throws Exception {
        BancheDatiApplication.main(new String[] { "server", "config.yml" });
    }
}
