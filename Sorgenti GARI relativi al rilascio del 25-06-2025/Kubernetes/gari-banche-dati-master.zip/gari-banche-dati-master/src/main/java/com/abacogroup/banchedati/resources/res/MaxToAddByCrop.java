package com.abacogroup.banchedati.resources.res;

import com.abacogroup.banchedati.api.ListaLimitiMasResponse.LimiteMas;

import lombok.Value;

@Value
public class MaxToAddByCrop {
    private String cropCode;
    private Double nitrogenQt;
    private Double yield;
    private Double nitrogenCorrectionFactor;

    public MaxToAddByCrop(LimiteMas mas) {
        this.cropCode = String.format("%s-%s-%s-%s-%s",
                mas.getOccupazioneCodAgea(), mas.getDestinazioneCodAgea(), mas.getUsoCodAgea(), mas.getQualitaCodAgea(), mas.getCulCodAgea());
        this.nitrogenQt = mas.getN();
        this.yield = mas.getResa();
        this.nitrogenCorrectionFactor = mas.getFattoreCorrettivoN();
    }
}
