package com.abacogroup.banchedati.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class AgronicaGenericException extends AbstractWebException {
    private static final String ERROR_CODE = "INVALID_CITIZENSHIP";

    public AgronicaGenericException(String errorMessage) {
        super(Status.INTERNAL_SERVER_ERROR, new ErrorBody(ERROR_CODE, errorMessage));
    }

    @Schema(name = "AgronicaErrorBody")
    public static class ErrorBody implements ExceptionErrorBody {
        private final String code;
        private final String message;

        public ErrorBody(String code, String message) {
            this.code = code;
            this.message = message;
        }

        @Override
        @Schema(allowableValues = { ERROR_CODE })
        public String getErrorCode() {
            return code;
        }

        @Override
        @Schema
        public String getMessage() {
            return message;
        }
    }

}
