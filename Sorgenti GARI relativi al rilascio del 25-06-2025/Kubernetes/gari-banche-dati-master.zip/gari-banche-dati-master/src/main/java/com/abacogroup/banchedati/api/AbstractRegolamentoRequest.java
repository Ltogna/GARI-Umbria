package com.abacogroup.banchedati.api;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public abstract class AbstractRegolamentoRequest {
    @JsonProperty("Regolamento_Cod")
    private int regulationCode = 125;
}
