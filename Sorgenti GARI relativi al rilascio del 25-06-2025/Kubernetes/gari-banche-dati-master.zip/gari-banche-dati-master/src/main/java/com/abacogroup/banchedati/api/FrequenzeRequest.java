package com.abacogroup.banchedati.api;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class FrequenzeRequest extends AbstractRegolamentoRequest {
    @JsonProperty("Eff_Cod")
    private String effluentCode;

    public FrequenzeRequest(String effluentCode) {
        this.effluentCode = effluentCode;
    }

}
