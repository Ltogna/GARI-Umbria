package com.abacogroup.banchedati.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class ListaLimitiMasRequest extends AbstractRegolamentoRequest {

    @JsonProperty("ElencoSpecieAgea")
    private List<CodiceColturaAgea> elencoSpecieAgea;

    public ListaLimitiMasRequest(List<CodiceColturaAgea> codes) {
        this.elencoSpecieAgea = codes;
    }
}
