package com.abacogroup.banchedati.resources;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

import com.abacogroup.banchedati.api.*;
import com.abacogroup.banchedati.resources.res.MaxToAddByCrop;
import com.abacogroup.banchedati.resources.res.ProductType;
import com.abacogroup.banchedati.util.LogUtils;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.*;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Timed
@Path("/{tenant}/public/v1/nitrogen")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "tags", description = "MAS related APIs")
public class NitrogenResources {

    private final WebTarget agronicaWebClient;

    public NitrogenResources(WebTarget agronicaWebClient) {
        this.agronicaWebClient = agronicaWebClient;
    }

    @GET
    @Path("/max-to-add-by-crop")
    @Operation(summary = "Returns MAS data")
    public List<MaxToAddByCrop> limitiMas(@Auth User user, @QueryParam("cropCode") @Valid @NotNull @Size(min = 1) List<String> cropCodes) {
        ListaLimitiMasRequest request = null;
        AgronicaResponse<ListaLimitiMasResponse> res = null;
        try{
            List<CodiceColturaAgea> codes = cropCodesToCodiceColturaAgea(cropCodes);
               if(codes == null || codes.isEmpty()){
                   return new ArrayList<>();
               }

                request = new ListaLimitiMasRequest(codes);

                res = agronicaWebClient.path("/DatiEsterniNewAgri.svc/LimiteMASElencoAgea")
                    .request(MediaType.APPLICATION_JSON)
                    .post(Entity.json(request), new GenericType<AgronicaResponse<ListaLimitiMasResponse>>() {
                    });


            res.validate();

            List<MaxToAddByCrop> response = res.getDati().getListaLimitiMas().stream()
                    .map(MaxToAddByCrop::new)
                    .collect(Collectors.toList());
            return response;
        }catch (Exception e){
            LogUtils.logErrorServiceData(log, request, res, agronicaWebClient, "/DatiEsterniNewAgri.svc/LimiteMASElencoAgea");
            throw new RuntimeException(e);
        }
    }

    @GET
    @Path("/product-types-by-crop")
    @Operation(summary = "Returns the product types based on crop codes")
    public List<ProductType> tipiProdotto(@Auth User user, @QueryParam("cropCode") @Valid @NotNull @Size(min = 1) List<String> cropCodes) {
        TipologiaLimiteMASResaElencoAgeaRequest request = null;
        AgronicaResponse<TipologiaLimiteMASResaElencoAgeaResponse> res = null;
        try{
            List<CodiceColturaAgea> codes = cropCodesToCodiceColturaAgea(cropCodes);
            if(codes == null || codes.isEmpty()){
                return new ArrayList<>();
            }

             request = new TipologiaLimiteMASResaElencoAgeaRequest(codes);

             res = agronicaWebClient.path("/DatiEsterniNewAgri.svc/TipologiaLimiteMASResaElencoAgea")
                    .request(MediaType.APPLICATION_JSON)
                    .post(Entity.json(request),
                            new GenericType<AgronicaResponse<TipologiaLimiteMASResaElencoAgeaResponse>>() {
                            });


            res.validate();

            List<ProductType> response = res.getDati().getListaTipologieLimitiMasResa().stream()
                    .map(ProductType::new)
                    .collect(Collectors.toList());
            return response;
        }catch (Exception e){
            LogUtils.logErrorServiceData(log, request, res, agronicaWebClient, "/DatiEsterniNewAgri.svc/TipologiaLimiteMASResaElencoAgea");
            throw new RuntimeException(e);
        }
    }

    @POST
    @Path("/product-types-by-crop")
    @Operation(summary = "Returns the product types based on multiple crop codes")
    public List<ProductType> batchTipiProdotto(@Auth User user, List<String> cropCodes) {
        List<ProductType> allProductTypes = new ArrayList<>();
        Set<String> uniqueCropCodes = new HashSet<>(cropCodes);

        List<CodiceColturaAgea> codes = parseCropCodes(new ArrayList<>(uniqueCropCodes));
        if(codes == null || codes.isEmpty()){
            return new ArrayList<>();
        }
        
        TipologiaLimiteMASResaElencoAgeaRequest request = new TipologiaLimiteMASResaElencoAgeaRequest(codes);
        AgronicaResponse<TipologiaLimiteMASResaElencoAgeaResponse> res = null;
        try{
            res = agronicaWebClient.path("/DatiEsterniNewAgri.svc/TipologiaLimiteMASResaElencoAgea")
                    .request(MediaType.APPLICATION_JSON)
                    .post(Entity.json(request),
                            new GenericType<AgronicaResponse<TipologiaLimiteMASResaElencoAgeaResponse>>() {
                            });

            res.validate();

            List<ProductType> response = res.getDati().getListaTipologieLimitiMasResa().stream()
                    .map(ProductType::new)
                    .collect(Collectors.toList());

            allProductTypes.addAll(response);

            return allProductTypes;
        }catch (Exception e){
            LogUtils.logErrorServiceData(log, request, res, agronicaWebClient, "/DatiEsterniNewAgri.svc/TipologiaLimiteMASResaElencoAgea");
            throw new RuntimeException(e);
        }
    }

    private List<CodiceColturaAgea> parseCropCodes(List<String> cropCodes) {
        List<CodiceColturaAgea> codes = cropCodes.stream()
                .map(c -> c.split("-"))
                .filter(tokens -> tokens.length == 5)
                .map(tokens -> new CodiceColturaAgea(tokens[0], tokens[1], tokens[2], tokens[3], tokens[4]))
                .collect(Collectors.toList());

        log.debug("Parsed Codes: {}", codes);

        return codes;
    }

    @GET
    @Path("/calculate-fabbisogno")
    public FabbisognoResponseDati calculateFabbisogno(@Auth User user,
            @QueryParam("cropCode") @Valid @NotNull @Size(min = 1) List<String> cropCodes,
            @QueryParam("chiaveAppezzamento") String chiaveAppezzamento,
            @QueryParam("tipologiaCod") Integer tipologiaCod,
            @QueryParam("resa") double resa,
            @QueryParam("precessioneCod") Integer precessioneCod,
            @QueryParam("nFertilizzazioniPrecedenti") double nFertilizzazioniPrecedenti) {
        ListaLimitiFabbisogno request = null;
        FabbisognoResponseEnvelope envelope = null;
        try {
            List<AppezzamentoDto> appezzamentos = cropCodesTofabbisogno(cropCodes);
            appezzamentos.forEach(x -> {
                x.setChiaveAppezzamento(chiaveAppezzamento);
                x.setTipologiaCod(tipologiaCod);
                x.setResa(resa);
                x.setPrecessioneCod(precessioneCod);
                x.setNFertilizzazioniPrecedenti(nFertilizzazioniPrecedenti);
            });

             request = ListaLimitiFabbisogno.builder()
                    .elencoAppezzamenti(appezzamentos)
                    .build();

             envelope = agronicaWebClient
                    .path("/DatiEsterniNewAgri.svc/PUAFabbisogno")
                    .request(MediaType.APPLICATION_JSON)
                    .post(Entity.json(request), FabbisognoResponseEnvelope.class);
            

            if (envelope != null && envelope.getDati() != null) {
                return envelope.getDati();
            } else {
                return  new FabbisognoResponseDati(){};
            }

        } catch (Exception ex) {
            LogUtils.logErrorServiceData(log, request, envelope, agronicaWebClient, "/DatiEsterniNewAgri.svc/PUAFabbisogno");
            throw ex;
        }
    }

    private List<CodiceColturaAgea> cropCodesToCodiceColturaAgea(List<String> cropCodes) {
        List<CodiceColturaAgea> codes = cropCodes.stream()
                .map(c -> c.split("-"))
                .filter(tokens -> tokens.length == 5)  // Skip invalid crop codes
                .map(tokens -> new CodiceColturaAgea(tokens[0], tokens[1], tokens[2], tokens[3], tokens[4]))
                .collect(Collectors.toList());

        log.debug("Codes: {}", codes);

        return codes;
    }
    private List<AppezzamentoDto> cropCodesTofabbisogno(List<String> cropCodes) {
        return cropCodes.stream()
                .map(c -> c.split("-"))
                .filter(tokens -> tokens.length == 5)  // Skip invalid crop codes
                .map(tokens -> new AppezzamentoDto(tokens[0], tokens[1], tokens[2], tokens[3], tokens[4]))
                .collect(Collectors.toList());
    }
}
