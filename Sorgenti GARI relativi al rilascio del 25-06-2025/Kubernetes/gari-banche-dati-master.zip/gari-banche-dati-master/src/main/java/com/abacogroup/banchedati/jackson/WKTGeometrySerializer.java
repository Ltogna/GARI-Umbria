package com.abacogroup.banchedati.jackson;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.io.WKTWriter;

import java.io.IOException;

public class WKTGeometrySerializer extends StdSerializer<Geometry> {
	private static final long serialVersionUID = -195010080189831836L;
	private static final WKTWriter WRITER = new WKTWriter();

	public WKTGeometrySerializer() {
		super(Geometry.class);
	}

	@Override
	public void serialize(Geometry value, JsonGenerator gen, SerializerProvider provider) throws IOException {
		gen.writeString(WRITER.write(value));
	}

}
