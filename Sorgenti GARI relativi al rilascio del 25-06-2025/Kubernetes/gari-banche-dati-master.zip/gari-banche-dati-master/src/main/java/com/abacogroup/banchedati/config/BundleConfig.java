package com.abacogroup.banchedati.config;

import jakarta.validation.constraints.NotBlank;

public class BundleConfig {
	@NotBlank
	private String configLocation;

	public String getConfigLocation() {
		return configLocation;
	}

	public void setConfigLocation(String configLocation) {
		this.configLocation = configLocation;
	}

}
