package com.abacogroup.banchedati.resources;

import java.util.List;
import java.util.stream.Collectors;

import com.abacogroup.banchedati.api.AgronicaResponse;
import com.abacogroup.banchedati.api.PrecessioneRequest;
import com.abacogroup.banchedati.api.PrecessioneResponse;
import com.abacogroup.banchedati.resources.res.PrecedingCropType;
import com.abacogroup.banchedati.util.LogUtils;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Timed
@Path("/{tenant}/public/v1/preceding-crops")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "tags", description = "Preceding crops related APIs")
public class PrecessioneResources {

    private final WebTarget agronicaWebClient;

    public PrecessioneResources(WebTarget agronicaWebClient) {
        this.agronicaWebClient = agronicaWebClient;
    }

    @GET
    @Path("/types")
    @Operation(summary = "Returns the preceding crop types")
    public List<PrecedingCropType> precedingCropTypes(@Auth User user) {
        PrecessioneRequest request = new PrecessioneRequest();
        AgronicaResponse<PrecessioneResponse> res = null;
        try{

            res = agronicaWebClient.path("/DatiEsterniNewAgri.svc/Precessione")
                    .request(MediaType.APPLICATION_JSON)
                    .post(Entity.json(request), new GenericType<AgronicaResponse<PrecessioneResponse>>() {
                    });


            res.validate();

            List<PrecedingCropType> response = res.getDati().getListaPrecessione().stream()
                    .map(PrecedingCropType::new)
                    .collect(Collectors.toList());
            return response;
        }catch (Exception e){
            LogUtils.logErrorServiceData(log, request, res, agronicaWebClient, "/DatiEsterniNewAgri.svc/Precessione");
            throw new RuntimeException(e);
        }
    }
}
