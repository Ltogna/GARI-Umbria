package com.abacogroup.banchedati.resources.res;

import com.abacogroup.banchedati.api.CategorieAnimaliResponse.CategoriaAnimali;

import lombok.Value;

@Value
public class AnimalCategory {
    private String genreCode;
    private String specieCode;
    private String code;
    private String productionCode;
    private String description;
    private Double averageWeight;
    private Double nitrogenPV;

    public AnimalCategory(CategoriaAnimali c) {
        this.genreCode = "" + c.getGenCod();
        this.specieCode = "" + c.getSpeCod();
        this.code = "" + c.getCatCod();
        this.productionCode = "" + c.getIProCod();
        this.description = c.getCatDes();
        this.averageWeight = c.getPesoMedio();
        this.nitrogenPV = c.getNPv();
    }

}
