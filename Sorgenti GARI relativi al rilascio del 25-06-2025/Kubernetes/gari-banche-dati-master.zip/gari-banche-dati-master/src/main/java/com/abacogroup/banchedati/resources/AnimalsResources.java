package com.abacogroup.banchedati.resources;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import com.abacogroup.banchedati.api.*;
import com.abacogroup.banchedati.resources.res.AnimalCategory;
import com.abacogroup.banchedati.resources.res.AnimalHousing;
import com.abacogroup.banchedati.resources.res.Specie;
import com.abacogroup.banchedati.util.LogUtils;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.codahale.metrics.annotation.Timed;

import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.*;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;

@Timed
@Path("/{tenant}/public/v1/animals")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "tags", description = "Animals related APIs")
@Slf4j
public class AnimalsResources {

    private final WebTarget agronicaWebClient;
    private final LoadingCache<SpeciesCategoryRequest, List<AnimalCategory>> speciesCategoryRequestCache;
    private final LoadingCache<HousingRequest, List<AnimalHousing>> animalHousingRequestCache;
    public AnimalsResources(WebTarget agronicaWebClient) {
        this.speciesCategoryRequestCache = Caffeine.newBuilder()
                .maximumSize(100L)
                .expireAfterAccess(24, TimeUnit.HOURS)
                .build(key -> this.getAnimalCategories(key.getGenreCode(), key.getSpecieCode()));

        this.animalHousingRequestCache = Caffeine.newBuilder()
                .maximumSize(100L)
                .expireAfterAccess(24, TimeUnit.HOURS)
                .build(key -> this.getAnimalHousings(key.getGenreCode(), key.getSpecieCode(), key.getCategoryCode(), key.getProductionCode()));


        this.agronicaWebClient = agronicaWebClient;
    }

    @GET
    @Path("/species")
    @Operation(summary = "Returns the allowed animal species")
    public List<Specie> species(@Auth User user) {
        SpecieAnimaliRequest request = new SpecieAnimaliRequest();
        AgronicaResponse<SpecieAnimaliResponse> res = null;

        try{
             res = agronicaWebClient.path("/DatiEsterniNewAgri.svc/SpecieAnimali")
                    .request(MediaType.APPLICATION_JSON)
                    .post(Entity.json(request), new GenericType<AgronicaResponse<SpecieAnimaliResponse>>() {
                    });


            res.validate();

            List<Specie> response = res.getDati().getListaSpecieAnimali().stream()
                    .map(Specie::new)
                    .collect(Collectors.toList());
            return response;

        }catch (Exception e){
            LogUtils.logErrorServiceData(log, request, res, agronicaWebClient, "/DatiEsterniNewAgri.svc/SpecieAnimali");
            throw  new RuntimeException(e);
        }
    }

    @GET
    @Path("/species/{genreCode}/{specieCode}/categories")
    @Operation(summary = "Returns the allowed animal species")
    public List<AnimalCategory> categories(@Auth User user, @PathParam("genreCode") String genreCode, @PathParam("specieCode") String specieCode) {

    	CategorieAnimaliRequest request = new CategorieAnimaliRequest(genreCode, specieCode);

        AgronicaResponse<CategorieAnimaliResponse> res = null;
        try{
            res = agronicaWebClient.path("/DatiEsterniNewAgri.svc/CategorieAnimali")
                    .request(MediaType.APPLICATION_JSON)
                    .post(Entity.json(request), new GenericType<AgronicaResponse<CategorieAnimaliResponse>>() {
                    });


            res.validate();

            List<AnimalCategory> response = res.getDati().getListasCategoriaAnimali().stream()
                    .map(AnimalCategory::new)
                    .collect(Collectors.toList());
            return response;

        }catch (Exception e){
            LogUtils.logErrorServiceData(log, request, res, agronicaWebClient, "/DatiEsterniNewAgri.svc/CategorieAnimali");
            throw new RuntimeException(e);
        }
    }

    @POST
    @Path("/species/categories")
    @Operation(summary = "Returns the allowed animal species for multiple genreCode and specieCode values")
    public List<AnimalCategory> batchCategories(@Auth User user, List<SpeciesCategoryRequest> speciesCategoryRequests) {
        List<AnimalCategory> allCategories = new ArrayList<>();
        Set<SpeciesCategoryRequest> uniqueRequests = new HashSet<>(speciesCategoryRequests);
        for (SpeciesCategoryRequest request : uniqueRequests) {
            List<AnimalCategory> response =   this.speciesCategoryRequestCache.get(
                     SpeciesCategoryRequest.builder()
                    .genreCode(request.getGenreCode())
                    .specieCode(request.getSpecieCode())
                    .build());
            allCategories.addAll(response);
        }
        return allCategories;
    }

    private List<AnimalCategory> getAnimalCategories(String genreCode, String specieCode) {

    	CategorieAnimaliRequest request = new CategorieAnimaliRequest(genreCode, specieCode);
        AgronicaResponse<CategorieAnimaliResponse> res = null;
        try{
            res = agronicaWebClient.path("/DatiEsterniNewAgri.svc/CategorieAnimali")
                    .request(MediaType.APPLICATION_JSON)
                    .post(Entity.json(request), new GenericType<AgronicaResponse<CategorieAnimaliResponse>>() {
                    });


            res.validate();

            List<AnimalCategory> response = res.getDati().getListasCategoriaAnimali().stream()
                    .map(AnimalCategory::new)
                    .collect(Collectors.toList());
            return response;
        }catch (Exception e){
            LogUtils.logErrorServiceData(log, request, res, agronicaWebClient, "/DatiEsterniNewAgri.svc/CategorieAnimali");
            throw new RuntimeException(e);
        }
    }

    @GET
    @Path("/species/{genreCode}/{specieCode}/{categoryCode}/{productionCode}/housing")
    @Operation(summary = "Returns the allowed animal housing")
    public List<AnimalHousing> stabulazione(@Auth User user,
            @PathParam("genreCode") String genreCode, @PathParam("specieCode") String specieCode,
            @PathParam("categoryCode") String categoryCode, @PathParam("productionCode") String productionCode) {
    	
    	StabulazioneRequest request = new StabulazioneRequest(genreCode, specieCode, categoryCode, productionCode);
        AgronicaResponse<StabulazioneResponse> res = null;
        try{

            res = agronicaWebClient.path("/DatiEsterniNewAgri.svc/Stabulazione")
                    .request(MediaType.APPLICATION_JSON)
                    .post(Entity.json(request),
                            new GenericType<AgronicaResponse<StabulazioneResponse>>() {
                            });

            res.validate();

            List<AnimalHousing> response = res.getDati().getListaTipiStallaXCategorie().stream()
                    .map(AnimalHousing::new)
                    .collect(Collectors.toList());
            return response;

        }catch (Exception e){
            LogUtils.logErrorServiceData(log, request, res, agronicaWebClient, "/DatiEsterniNewAgri.svc/Stabulazione");
            throw new RuntimeException(e);
        }
    }

    @POST
    @Path("/species/housing")
    @Operation(summary = "Returns the allowed animal housing for multiple genreCode, specieCode, categoryCode, and productionCode values")
    public List<AnimalHousing> batchHousing(@Auth User user, List<HousingRequest> housingRequests) {
        List<AnimalHousing> allHousings = new ArrayList<>();
        Set<HousingRequest> uniqueRequests = new HashSet<>(housingRequests);
        for (HousingRequest request : uniqueRequests) {
            List<AnimalHousing> response =   this.animalHousingRequestCache.get(
                             HousingRequest.builder()
                            .genreCode(request.getGenreCode()).specieCode(request.getSpecieCode()).categoryCode(request.getCategoryCode()).productionCode(request.getProductionCode())
                            .build());
            allHousings.addAll(response);
        }
        return allHousings;
    }

    private List<AnimalHousing> getAnimalHousings(String genreCode, String specieCode, String categoryCode, String productionCode) {
    	StabulazioneRequest request = new StabulazioneRequest(genreCode, specieCode, categoryCode, productionCode);
        AgronicaResponse<StabulazioneResponse> res = null;

        try{
            res = agronicaWebClient.path("/DatiEsterniNewAgri.svc/Stabulazione")
                    .request(MediaType.APPLICATION_JSON)
                    .post(Entity.json(request),
                            new GenericType<AgronicaResponse<StabulazioneResponse>>() {
                            });

            LogUtils.logErrorServiceData(log, request, res, agronicaWebClient, "/DatiEsterniNewAgri.svc/Stabulazione");

            res.validate();
            List<AnimalHousing> response = res.getDati().getListaTipiStallaXCategorie().stream()
                    .map(AnimalHousing::new)
                    .collect(Collectors.toList());
            return response;
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }

}
