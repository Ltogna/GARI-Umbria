package com.abacogroup.banchedati.api;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
public class FrequenzeCodesRequest  {
	@JsonProperty("effluentCodes")
	private List<String> effluentCodes;

	public FrequenzeCodesRequest() {
	}

}
