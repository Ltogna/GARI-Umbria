package com.abacogroup.banchedati.resources.res;

import com.abacogroup.banchedati.api.PrecessioneResponse.Precessione;

import lombok.Value;

@Value
public class PrecedingCropType {
    private String code;
    private String description;
    private Double resudualNitrogen;

    public PrecedingCropType(Precessione prec) {
        this.code = "" + prec.getCodice();
        this.description = prec.getDescrizione();
        this.resudualNitrogen = prec.getNResiduo();
    }
}
