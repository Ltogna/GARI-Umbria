package com.abacogroup.banchedati.resources.res;

import com.abacogroup.banchedati.api.SpecieAnimaliResponse.SpecieAnimale;

import lombok.Value;

@Value
public class Specie {
    private String genreCode;
    private String code;
    private String description;

    public Specie(SpecieAnimale s) {
        this.genreCode = "" + s.getGenCod();
        this.code = "" + s.getSpeCod();
        this.description = s.getSpeDes();
    }
}
