package com.abacogroup.banchedati.api;

public class PrecessioneRequest extends AbstractRegolamentoRequest {
}
