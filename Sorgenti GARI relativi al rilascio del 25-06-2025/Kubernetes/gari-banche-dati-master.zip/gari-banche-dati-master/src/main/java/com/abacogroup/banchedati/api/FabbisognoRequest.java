package com.abacogroup.banchedati.api;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

public class FabbisognoRequest {
	@JsonProperty("Regolamento_Cod")
	private Integer regolamentoCod;

	@JsonProperty("ElencoAppezzamenti")
	private List<AppezzamentoDto> elencoAppezzamenti;
}

