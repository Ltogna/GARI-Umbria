package com.abacogroup.banchedati.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class StabulazioneResponse {
    @JsonProperty("ListaTipiStallaxCategorie")
    private List<TipiStallaxCategorie> listaTipiStallaXCategorie;

    @Data
    public static class TipiStallaxCategorie {
        @JsonProperty("Gen_Cod")
        private int genCod;
        @JsonProperty("Spe_Cod")
        private int speCod;
        @JsonProperty("Cat_Cod")
        private int catCod;
        @JsonProperty("IPro_Cod")
        private int iProCod;
        @JsonProperty("Cod_Fabb")
        private String codFabb;
        @JsonProperty("Descr_Fabb")
        private String descrFabb;
        @JsonProperty("Liquame")
        private Double liquame;
        @JsonProperty("Liquami_perc")
        private Double liquamiPrec;
        @JsonProperty("N_Liq")
        private Double nLiq;
        @JsonProperty("N_Pal")
        private Double nPal;
        @JsonProperty("Paglia")
        private Double paglia;
        @JsonProperty("Palabile_mc")
        private Double palabileMc;
        @JsonProperty("Palabile_t")
        private Double palabileT;

    }
}
