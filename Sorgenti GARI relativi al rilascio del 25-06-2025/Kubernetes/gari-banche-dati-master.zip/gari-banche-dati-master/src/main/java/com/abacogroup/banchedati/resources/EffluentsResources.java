package com.abacogroup.banchedati.resources;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.abacogroup.banchedati.api.*;
import com.abacogroup.banchedati.resources.res.Effluent;
import com.abacogroup.banchedati.resources.res.EffluentFrequency;
import com.abacogroup.banchedati.util.LogUtils;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.*;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Timed
@Path("/{tenant}/public/v1/effluents")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "tags", description = "Effluents related APIs")
public class EffluentsResources {

    private final WebTarget agronicaWebClient;

    public EffluentsResources(WebTarget agronicaWebClient) {
        this.agronicaWebClient = agronicaWebClient;
    }

    @GET
    @Operation(summary = "Returns the allowed effluents")
    public List<Effluent> precedingCropTypes(@Auth User user, @QueryParam("filterOnceWithFrequency") @DefaultValue("false") boolean onlyWithFrequency) {
        AgronicaResponse<EffluentiResponse> res = null;
        EffluentiRequest request = new EffluentiRequest();
        String path = null;

        try{
            if (onlyWithFrequency) {
                path = "/DatiEsterniNewAgri.svc/EffluentiXFrequenza";
                res = agronicaWebClient.path(path)
                        .request(MediaType.APPLICATION_JSON)
                        .post(Entity.json(request), new GenericType<AgronicaResponse<EffluentiResponse>>() {
                        });
            } else {
                path = "/DatiEsterniNewAgri.svc/Effluenti";
                res = agronicaWebClient.path(path)
                        .request(MediaType.APPLICATION_JSON)
                        .post(Entity.json(request), new GenericType<AgronicaResponse<EffluentiResponse>>() {
                        });
            }



            res.validate();

            List<Effluent> response = res.getDati().getListaEffluenti().stream()
                    .map(Effluent::new)
                    .collect(Collectors.toList());
            return response;
        }catch (Exception e){
            LogUtils.logErrorServiceData(log, request, res, agronicaWebClient, path);
            throw  new RuntimeException(e);
        }
    }

    @GET
    @Path("/{effluentCode}/frequencies")
    @Operation(summary = "Returns the allowed frequecies for an effluent")
    public List<EffluentFrequency> frequencies(@Auth User user, @PathParam("effluentCode") String effluentCode) {
        FrequenzeRequest request = new FrequenzeRequest(effluentCode);
        AgronicaResponse<FrequenzeResponse> res = null;

        try{
             res = agronicaWebClient.path("/DatiEsterniNewAgri.svc/Frequenza")
                    .request(MediaType.APPLICATION_JSON)
                    .post(Entity.json(request), new GenericType<AgronicaResponse<FrequenzeResponse>>() {
                    });

            res.validate();

            List<EffluentFrequency> response = res.getDati().getListaFrequenze().stream()
                    .map(EffluentFrequency::new)
                    .collect(Collectors.toList());
            return response;
        }catch(Exception e){
            LogUtils.logErrorServiceData(log, request, res, agronicaWebClient, "/DatiEsterniNewAgri.svc/Frequenza");
            throw new RuntimeException(e);
        }
    }

    @POST
    @Path("/frequencies")
    @Operation(summary = "Returns the allowed frequencies for an effluent")
    public List<EffluentFrequency> frequenciesList(@Auth User user, @RequestBody FrequenzeCodesRequest dto) {

        if (dto == null || dto.getEffluentCodes().isEmpty()) {
           return  new ArrayList<>();
        }
        Set<String> uniqueCodes = dto.getEffluentCodes().stream()
                .map(String::trim)
                .filter(code -> !code.isEmpty()) // Ignore empty codes
                .collect(Collectors.toSet());

        List<EffluentFrequency> allFrequencies = new ArrayList<>();
        
        FrequenzeRequest request = null;
        String path = "/DatiEsterniNewAgri.svc/Frequenza";
        AgronicaResponse<FrequenzeResponse> res = null;

        try{
            for (String code : uniqueCodes) {

                request = new FrequenzeRequest(code);

                 res = agronicaWebClient.path(path)
                        .request(MediaType.APPLICATION_JSON)
                        .post(Entity.json(request), new GenericType<AgronicaResponse<FrequenzeResponse>>() {
                        });


                res.validate();

                List<EffluentFrequency> frequencies = res.getDati().getListaFrequenze().stream()
                        .map(EffluentFrequency::new)
                        .collect(Collectors.toList());

                allFrequencies.addAll(frequencies);
            }

            return allFrequencies;

        }catch(Exception e){
            LogUtils.logErrorServiceData(log, request, res, agronicaWebClient, path);
            throw new RuntimeException(e);
        }
    }

}
