package com.abacogroup.banchedati.resources.res;

import com.abacogroup.banchedati.api.FrequenzeResponse.Frequenza;

import lombok.Value;

@Value
public class EffluentFrequency {

    private String code;
    private String description;
    private Double nitrogen;

    public EffluentFrequency(Frequenza f) {
        this.code = "" + f.getIdFre();
        this.description = f.getFrequenzaDes();
        this.nitrogen = f.getN();
    }
}
