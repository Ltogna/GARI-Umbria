package com.abacogroup.banchedati.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PrecessioneResponse {
    @JsonProperty("ListaPrecessione")
    private List<Precessione> listaPrecessione;

    @Data
    public static class Precessione {
        @JsonProperty("Codice")
        private int codice;
        @JsonProperty("Descrizione")
        private String descrizione;
        @JsonProperty("N_Residuo")
        private Double nResiduo;
    }
}
