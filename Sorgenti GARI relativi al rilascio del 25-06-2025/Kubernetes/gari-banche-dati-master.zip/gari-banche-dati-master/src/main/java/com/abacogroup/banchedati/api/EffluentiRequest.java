package com.abacogroup.banchedati.api;

public class EffluentiRequest extends AbstractRegolamentoRequest {

}
