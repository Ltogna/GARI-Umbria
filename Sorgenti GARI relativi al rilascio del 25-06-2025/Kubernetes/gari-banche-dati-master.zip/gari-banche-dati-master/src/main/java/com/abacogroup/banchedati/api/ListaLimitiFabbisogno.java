package com.abacogroup.banchedati.api;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class ListaLimitiFabbisogno extends AbstractRegolamentoRequest {

    @JsonProperty("ElencoAppezzamenti")
    private List<AppezzamentoDto> elencoAppezzamenti;

}
