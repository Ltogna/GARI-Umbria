package com.abacogroup.banchedati.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

// Wraps the entire top-level JSON: { "dati": {...}, "errore": "", "message": "OK" }
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FabbisognoResponseEnvelope {
	private FabbisognoResponseDati dati;
	private String errore;
	private String message;
}

