package com.abacogroup.banchedati.api;

import com.fasterxml.jackson.annotation.JsonProperty;

public class StabulazioneRequest extends AbstractRegolamentoRequest {

    @JsonProperty("Gen_Cod")
    private String genreCode;
    @JsonProperty("Spe_Cod")
    private String specieCode;
    @JsonProperty("Cat_Cod")
    private String categoryCode;
    @JsonProperty("IPro_Cod")
    private String productionCode;

    public StabulazioneRequest(String genreCode, String specieCode, String categoryCode, String productionCode) {
        this.genreCode = genreCode;
        this.specieCode = specieCode;
        this.categoryCode = categoryCode;
        this.productionCode = productionCode;
    }

}
