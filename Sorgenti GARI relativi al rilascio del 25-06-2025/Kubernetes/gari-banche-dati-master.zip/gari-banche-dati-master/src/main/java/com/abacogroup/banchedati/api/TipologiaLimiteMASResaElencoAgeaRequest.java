package com.abacogroup.banchedati.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class TipologiaLimiteMASResaElencoAgeaRequest extends AbstractRegolamentoRequest {

    @JsonProperty("ElencoSpecieAgea")
    private List<CodiceColturaAgea> elencoSpecieAgea;

    @JsonProperty("Includi_NMasResa")
    private boolean includiResa;

    public TipologiaLimiteMASResaElencoAgeaRequest(List<CodiceColturaAgea> codes) {
        this(codes, true);
    }

    public TipologiaLimiteMASResaElencoAgeaRequest(List<CodiceColturaAgea> codes, boolean includiResa) {
        this.elencoSpecieAgea = codes;
        this.includiResa = includiResa;
    }
}
