package com.abacogroup.banchedati.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
public class ListaLimitiMasResponse {
    @JsonProperty("ListaLimitiMas")
    private List<LimiteMas> listaLimitiMas;

    @Data
    @EqualsAndHashCode(callSuper = true)
    public static class LimiteMas extends CodiceColturaAgea {
        @JsonProperty("N")
        private Double n;
        @JsonProperty("Resa")
        private Double resa;
        @JsonProperty("FattoreCorrettivo_N")
        private double fattoreCorrettivoN;
    }
}
