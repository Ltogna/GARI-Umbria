package com.abacogroup.banchedati.api;

public class SpecieAnimaliRequest extends AbstractRegolamentoRequest {

}
