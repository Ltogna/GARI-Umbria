package com.abacogroup.banchedati;

import java.io.IOException;
import java.util.List;

import org.locationtech.jts.geom.Geometry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.SsoAuthorizer;
import com.abacogroup.tracing.dropwizard.AbacoApplication;
import com.abacogroup.tracing.jaxrs.client.AddRequestId;
import com.codahale.metrics.health.HealthCheck;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.jdbi3.bundles.JdbiExceptionsBundle;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import io.dropwizard.migrations.MigrationsBundle;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import io.swagger.v3.oas.integration.ClasspathOpenApiConfigurationLoader;
import io.swagger.v3.oas.integration.api.OpenAPIConfiguration;
import com.abacogroup.banchedati.jackson.WKTGeometryDeserializer;
import com.abacogroup.banchedati.jackson.WKTGeometrySerializer;
import com.abacogroup.banchedati.resources.AnimalsResources;
import com.abacogroup.banchedati.resources.EffluentsResources;
import com.abacogroup.banchedati.resources.NitrogenResources;
import com.abacogroup.banchedati.resources.PrecessioneResources;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientRequestContext;
import jakarta.ws.rs.client.ClientRequestFilter;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.HttpHeaders;

public class BancheDatiApplication extends AbacoApplication<BancheDatiConfiguration> {
    private static final Logger log = LoggerFactory.getLogger(BancheDatiApplication.class);

    public static void main(final String[] args) throws Exception {
        new BancheDatiApplication().run(args);
    }

    @Override
    public String getName() {
        return "BancheDati";
    }

    @Override
    public void initialize(Bootstrap<BancheDatiConfiguration> bootstrap) {
        bootstrap.addBundle(new JdbiExceptionsBundle());
        bootstrap.addBundle(new MigrationsBundle<>() {
            @Override
            public DataSourceFactory getDataSourceFactory(BancheDatiConfiguration configuration) {
                return configuration.getDatabase();
            }
        });
        SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
                new EnvironmentVariableSubstitutor(false));
        bootstrap.setConfigurationSourceProvider(provider);
    }

    @Override
    public void doRun(BancheDatiConfiguration config, Environment environment) throws Exception {
        configure(environment.getObjectMapper());

        // This is needed only to avoid dropwizard complaining about missing healthchecks in the startup logs
        environment.healthChecks().register("dummy", new HealthCheck() {
            @Override
            protected Result check() throws Exception {
                return Result.healthy();
            }
        });

        // build the http client
        JerseyClientConfiguration clientConfig = config.getJerseyClientConfiguration();
        final Client client = new JerseyClientBuilder(environment)
                .using(clientConfig)
                .build(getName());

        WebTarget remoteDataTarget = client.target(config.getRemoteBaseUrl());
        final String authHeaderValue = "Bearer " + config.getRemoteToken();
        final List<Object> contentEncoding = List.of("identity");
        remoteDataTarget.register(new ClientRequestFilter() {
            @Override
            public void filter(ClientRequestContext requestContext) throws IOException {
                // Disable gzip on POST, it looks like the remote service doesn't like that
                requestContext.getHeaders().put(HttpHeaders.CONTENT_ENCODING, contentEncoding);
                requestContext.getHeaders().add("Authorization", authHeaderValue);
            }
        });

        // Register the AddRequestId only at this point, because we do not want to send x-request-id headers to the remote service
        client.register(new AddRequestId());

        // Auth
        Sso2Client sso2Client = createSso2Client(config, client);
        AuthUtils.installAuthFilter(environment, sso2Client, new SsoAuthorizer(sso2Client));

        // Resources
        JerseyEnvironment jersey = environment.jersey();
        jersey.register(new MultitenantFilter("tenant"));

        jersey.register(new AnimalsResources(remoteDataTarget));
        jersey.register(new EffluentsResources(remoteDataTarget));
        jersey.register(new NitrogenResources(remoteDataTarget));
        jersey.register(new PrecessioneResources(remoteDataTarget));

        // OpenAPI
        initOpenApi(jersey);
    }

    private Sso2Client createSso2Client(BancheDatiConfiguration config, Client client) {
        Sso2Client sso2Client;
        String secretAuthToken = config.getSso2TokenSecretAuth();
        if (secretAuthToken == null || secretAuthToken.isBlank() || "${SSO2_TOKENS_AUTH_SECRET}".equals(secretAuthToken)) {
            log.debug("SSO2_TOKENS_AUTH_SECRET not set");
            sso2Client = new Sso2Client(client.target(config.getSso2Url()));
        } else {
            sso2Client = new Sso2Client(config.getSso2TokenSecretAuth(), client.target(config.getSso2Url()));
        }

        return sso2Client;
    }

    private void initOpenApi(JerseyEnvironment jersey) throws IOException {
        OpenAPIConfiguration oasConfig = new ClasspathOpenApiConfigurationLoader()
                .load("openapi-configuration.yaml");

        jersey.register(new OpenApiResource().openApiConfiguration(oasConfig));
    }

    private void configure(ObjectMapper objectMapper) {
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        objectMapper.disable(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE);

        SimpleModule module = new SimpleModule("custom-deserializers", Version.unknownVersion());
        module.addSerializer(Geometry.class, new WKTGeometrySerializer());
        module.addDeserializer(Geometry.class, new WKTGeometryDeserializer());
        objectMapper.registerModule(module);
    }
}
