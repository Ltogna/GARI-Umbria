package com.abacogroup.banchedati.api;

import com.abacogroup.banchedati.exceptions.AgronicaGenericException;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class AgronicaResponse<T> {
    private String message;
    private String errore;
    private T dati;

    @JsonIgnore
    public final void validate() {
        if ("OK".equals(message)) {
            return;
        }

        throw new AgronicaGenericException(errore);
    }
}
