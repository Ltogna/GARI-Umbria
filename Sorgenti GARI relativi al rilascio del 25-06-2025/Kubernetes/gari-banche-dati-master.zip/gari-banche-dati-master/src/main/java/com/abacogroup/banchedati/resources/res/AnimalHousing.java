package com.abacogroup.banchedati.resources.res;

import com.abacogroup.banchedati.api.StabulazioneResponse.TipiStallaxCategorie;

import lombok.Value;

@Value
public class AnimalHousing {

    private String genreCode;
    private String specieCode;
    private String categoryCode;
    private String productionCode;
    private String code;
    private String description;
    private Double sewageSludge; // liquame;
    private Double sewageSludgePct;
    private Double nitrogenSewage; // n liq
    private Double nitrogenShovellable; // m Pal
    private Double hay; // paglia;
    private Double shovellableMc;// palabielMc;
    private Double shovellableT;// palabielT;

    public AnimalHousing(TipiStallaxCategorie c) {
        this.genreCode = "" + c.getGenCod();
        this.specieCode = "" + c.getSpeCod();
        this.categoryCode = "" + c.getCatCod();
        this.productionCode = "" + c.getIProCod();
        this.code = c.getCodFabb();
        this.description = c.getDescrFabb();
        this.sewageSludge = c.getLiquame();
        this.sewageSludgePct = c.getLiquamiPrec();
        this.nitrogenSewage = c.getNLiq();
        this.nitrogenShovellable = c.getNPal();
        this.hay = c.getPaglia();
        this.shovellableMc = c.getPalabileMc();
        this.shovellableT = c.getPalabileT();
    }
}
