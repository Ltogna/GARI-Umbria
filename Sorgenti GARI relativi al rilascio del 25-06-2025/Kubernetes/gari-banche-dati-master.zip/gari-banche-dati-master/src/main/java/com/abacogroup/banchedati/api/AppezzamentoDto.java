package com.abacogroup.banchedati.api;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AppezzamentoDto extends CodiceColturaAgea {

	@JsonProperty("Chiave_Appezzamento")
	private String chiaveAppezzamento;

	@JsonProperty("Tipologia_Cod")
	private Integer tipologiaCod;

	@JsonProperty("Resa")
	private double resa;

	@JsonProperty("Precessione_Cod")
	private Integer precessioneCod;

	@JsonProperty("N_FertilizzazioniPrecedenti")
	private double nFertilizzazioniPrecedenti;


	/// Codice
	@JsonProperty("Occupazione_Cod_Agea")
	private String occupazioneCodAgea;

	@JsonProperty("Destinazione_Cod_Agea")
	private String destinazioneCodAgea;

	@JsonProperty("Uso_Cod_Agea")
	private String usoCodAgea;

	@JsonProperty("Qualita_Cod_Agea")
	private String qualitaCodAgea;

	@JsonProperty("Cul_Cod_Agea")
	private String culCodAgea;

	public AppezzamentoDto(String occupazioneCodAgea, String destinazioneCodAgea, String usoCodAgea, String qualitaCodAgea, String culCodAgea) {
		this.culCodAgea = culCodAgea;
		this.usoCodAgea = usoCodAgea;
		this.occupazioneCodAgea = occupazioneCodAgea;
		this.destinazioneCodAgea = destinazioneCodAgea;
		this.qualitaCodAgea = qualitaCodAgea;
	}
}