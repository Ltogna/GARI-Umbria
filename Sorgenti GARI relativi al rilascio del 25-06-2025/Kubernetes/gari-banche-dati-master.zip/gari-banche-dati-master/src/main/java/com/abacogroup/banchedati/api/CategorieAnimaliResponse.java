package com.abacogroup.banchedati.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CategorieAnimaliResponse {
    @JsonProperty("ListaCategorieAnimali")
    private List<CategoriaAnimali> listasCategoriaAnimali;

    @Data
    public static class CategoriaAnimali {
        @JsonProperty("Gen_Cod")
        private int genCod;
        @JsonProperty("Spe_Cod")
        private int speCod;
        @JsonProperty("Cat_Cod")
        private int catCod;
        @JsonProperty("IPro_Cod")
        private Integer iProCod;
        @JsonProperty("Acque_Residue")
        private Double acqueResidue;
        @JsonProperty("Cat_Des")
        private String catDes;
        @JsonProperty("N_PV")
        private Double nPv;
        @JsonProperty("Peso_Medio")
        private Double pesoMedio;
    }
}
