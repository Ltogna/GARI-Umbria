package com.abacogroup.banchedati.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class FrequenzeResponse {
    @JsonProperty("ListaFrequenze")
    private List<Frequenza> listaFrequenze;

    @Data
    public static class Frequenza {
        @JsonProperty("Frequenza_Des")
        private String frequenzaDes;
        @JsonProperty("Id_Fre")
        private int idFre;
        @JsonProperty("N")
        private Double n;
    }
}
