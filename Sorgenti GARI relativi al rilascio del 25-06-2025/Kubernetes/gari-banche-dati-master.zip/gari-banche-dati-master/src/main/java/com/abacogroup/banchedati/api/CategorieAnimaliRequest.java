package com.abacogroup.banchedati.api;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class CategorieAnimaliRequest extends AbstractRegolamentoRequest {

    @JsonProperty("Gen_Cod")
    private String genreCode;
    @JsonProperty("Spe_Cod")
    private String code;

    public CategorieAnimaliRequest(String genreCode, String code) {
        this.genreCode = genreCode;
        this.code = code;
    }

}
