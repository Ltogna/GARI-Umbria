package com.abacogroup.banchedati.resources.res;

import com.abacogroup.banchedati.api.TipologiaLimiteMASResaElencoAgeaResponse.TipologieLimitiMasResa;

import lombok.Value;

@Value
public class ProductType {

    private String cropCode;
    private double nitrogenQt;
    private double yield;
    private double nitrogenCorrectionFactor;
    private String productTypeCode;
    private String productTypeDescr;

    public ProductType(TipologieLimitiMasResa res) {
        this.cropCode = String.format("%s-%s-%s-%s-%s",
                res.getOccupazioneCodAgea(), res.getDestinazioneCodAgea(), res.getUsoCodAgea(), res.getQualitaCodAgea(), res.getCulCodAgea());
        this.nitrogenQt = res.getN();
        this.yield = res.getResa();
        this.nitrogenCorrectionFactor = res.getFattoreCorrettivoN();
        this.productTypeCode = "" + res.getTipologiaCod();
        this.productTypeDescr = res.getTipologiaDes();
    }
}
