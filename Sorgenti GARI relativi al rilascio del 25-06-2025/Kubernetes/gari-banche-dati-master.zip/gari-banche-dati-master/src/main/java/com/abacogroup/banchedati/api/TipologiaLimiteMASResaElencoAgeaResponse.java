package com.abacogroup.banchedati.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
public class TipologiaLimiteMASResaElencoAgeaResponse {
    @JsonProperty("ListaTipologieLimitiMasResa")
    private List<TipologieLimitiMasResa> listaTipologieLimitiMasResa;

    @Data
    @EqualsAndHashCode(callSuper = true)
    public static class TipologieLimitiMasResa extends CodiceColturaAgea {
        @JsonProperty("N")
        private Double n;
        @JsonProperty("Resa")
        private Double resa;
        @JsonProperty("FattoreCorrettivo_N")
        private Double fattoreCorrettivoN;
        @JsonProperty("Tipologia_Cod")
        private int tipologiaCod;
        @JsonProperty("Tipologia_Des")
        private String tipologiaDes;
    }
}
