package com.abacogroup.banchedati;

import com.abacogroup.banchedati.config.BundleConfig;
import com.abacogroup.banchedati.config.RabbitMqConfig;

import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.Configuration;
import io.dropwizard.db.DataSourceFactory;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public class BancheDatiConfiguration extends Configuration {
    @NotEmpty
    private String remoteBaseUrl;

    @NotEmpty
    private String remoteToken;

    @NotEmpty
    private String sso2Url;
    private String sso2TokenSecretAuth;

    private BundleConfig bundleConfig;
    private RabbitMqConfig rabbitmqConfig;

    private DataSourceFactory database;

    @Valid
    @NotNull
    private JerseyClientConfiguration jerseyClientConfiguration;

    public String getSso2Url() {
        return sso2Url;
    }

    public void setSso2Url(String sso2Url) {
        this.sso2Url = sso2Url;
    }

    public BundleConfig getBundleConfig() {
        return bundleConfig;
    }

    public void setBundleConfig(BundleConfig bundleConfig) {
        this.bundleConfig = bundleConfig;
    }

    public RabbitMqConfig getRabbitmqConfig() {
        return rabbitmqConfig;
    }

    public void setRabbitmqConfig(RabbitMqConfig rabbitmqConfig) {
        this.rabbitmqConfig = rabbitmqConfig;
    }

    public DataSourceFactory getDatabase() {
        return database;
    }

    public void setDatabase(DataSourceFactory database) {
        this.database = database;
    }

    public JerseyClientConfiguration getJerseyClientConfiguration() {
        return jerseyClientConfiguration;
    }

    public void setJerseyClientConfiguration(JerseyClientConfiguration jerseyClientConfiguration) {
        this.jerseyClientConfiguration = jerseyClientConfiguration;
    }

    public String getSso2TokenSecretAuth() {
        return sso2TokenSecretAuth;
    }

    public void setSso2TokenSecretAuth(String sso2TokenSecretAuth) {
        this.sso2TokenSecretAuth = sso2TokenSecretAuth;
    }

    public String getRemoteToken() {
        return remoteToken;
    }

    public void setRemoteToken(String remoteToken) {
        this.remoteToken = remoteToken;
    }

    public String getRemoteBaseUrl() {
        return remoteBaseUrl;
    }

    public void setRemoteBaseUrl(String remoteBaseUrl) {
        this.remoteBaseUrl = remoteBaseUrl;
    }

}
