package com.abacogroup.banchedati.config;

import java.util.Objects;

public class RabbitMqConfig {
	private String host;
	private String user;
	private String password;
	private String virtualhost;
	private Integer port;

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getVirtualhost() {
		return virtualhost;
	}

	public void setVirtualhost(String virtualhost) {
		this.virtualhost = virtualhost;
	}

	public Integer getPort() {
		return port;
	}

	public void setPort(Integer port) {
		this.port = port;
	}

	@Override
	public int hashCode() {
		return Objects.hash(host, password, port, user, virtualhost);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		RabbitMqConfig other = (RabbitMqConfig) obj;
		return Objects.equals(host, other.host) && Objects.equals(password, other.password) && Objects.equals(port, other.port)
				&& Objects.equals(user, other.user) && Objects.equals(virtualhost, other.virtualhost);
	}

}
