package com.abacogroup.banchedati.resources.res;

import com.abacogroup.banchedati.api.EffluentiResponse.Effluente;

import lombok.Value;

@Value
public class Effluent {

    private String code;
    private String description;
    private Double nitrogen;
    private String codeUom;
    private String descriptionUom;
    private String ferCod;

    public Effluent(Effluente e) {
        this.code = "" + e.getEffCode();
        this.description = e.getEffDes();
        this.nitrogen = e.getNTitolo();
        this.codeUom = "" + e.getUdmCod();
        this.descriptionUom = e.getUdmDes();
        this.ferCod = e.getFerCod();
    }
}
