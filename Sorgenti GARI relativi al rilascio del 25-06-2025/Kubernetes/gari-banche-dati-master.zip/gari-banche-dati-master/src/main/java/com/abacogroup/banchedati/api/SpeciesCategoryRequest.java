package com.abacogroup.banchedati.api;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;
import java.util.Objects;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SpeciesCategoryRequest {
	@JsonProperty("genreCode")
	private String genreCode;

	@JsonProperty("specieCode")
	private String specieCode;
}
