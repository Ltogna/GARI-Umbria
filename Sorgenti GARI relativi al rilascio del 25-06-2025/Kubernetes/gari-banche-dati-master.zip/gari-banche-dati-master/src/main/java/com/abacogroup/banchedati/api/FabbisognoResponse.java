package com.abacogroup.banchedati.api;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class FabbisognoResponse {

	@JsonProperty("Chiave_Appezzamneto") // <-- Must match exact field from JSON
	private String chiaveAppezzamento;

	@JsonProperty("N_Fabbisogno")
	private BigDecimal nFabbisogno;
}
