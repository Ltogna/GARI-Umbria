package com.abacogroup.banchedati.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class EffluentiResponse {
    @JsonProperty("ListaEffluenti")
    private List<Effluente> listaEffluenti;

    @Data
    public static class Effluente {
        @JsonProperty("Eff_Cod")
        private int effCode;
        @JsonProperty("Eff_Des")
        private String effDes;
        @JsonProperty("N_Titolo")
        private Double nTitolo;
        @JsonProperty("Udm_Cod")
        private int udmCod;
        @JsonProperty("Udm_Des")
        private String udmDes;
        @JsonProperty("Fer_Cod")
        private String ferCod;
    }
}
