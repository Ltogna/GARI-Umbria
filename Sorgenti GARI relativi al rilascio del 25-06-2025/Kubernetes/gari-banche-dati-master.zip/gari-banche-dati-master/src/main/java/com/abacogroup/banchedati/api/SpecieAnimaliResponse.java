package com.abacogroup.banchedati.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SpecieAnimaliResponse {
    @JsonProperty("ListaSpecieAnimali")
    private List<SpecieAnimale> listaSpecieAnimali;

    @Data
    public static class SpecieAnimale {
        @JsonProperty("Gen_Cod")
        private int genCod;
        @JsonProperty("Spe_Cod")
        private int speCod;
        @JsonProperty("Spe_Des")
        private String speDes;

    }
}
