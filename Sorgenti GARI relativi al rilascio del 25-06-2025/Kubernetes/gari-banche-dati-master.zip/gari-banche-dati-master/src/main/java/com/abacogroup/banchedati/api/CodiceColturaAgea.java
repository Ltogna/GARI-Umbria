package com.abacogroup.banchedati.api;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CodiceColturaAgea {
    @JsonProperty("Occupazione_Cod_Agea")
    private String occupazioneCodAgea;
    @JsonProperty("Destinazione_Cod_Agea")
    private String destinazioneCodAgea;
    @JsonProperty("Uso_Cod_Agea")
    private String usoCodAgea;
    @JsonProperty("Qualita_Cod_Agea")
    private String qualitaCodAgea;
    @JsonProperty("Cul_Cod_Agea")
    private String culCodAgea;

    public CodiceColturaAgea() {
    }

    public CodiceColturaAgea(String occupazioneCodAgea, String destinazioneCodAgea, String usoCodAgea, String qualitaCodAgea, String culCodAgea) {
        this.culCodAgea = culCodAgea;
        this.usoCodAgea = usoCodAgea;
        this.occupazioneCodAgea = occupazioneCodAgea;
        this.destinazioneCodAgea = destinazioneCodAgea;
        this.qualitaCodAgea = qualitaCodAgea;
    }

}
