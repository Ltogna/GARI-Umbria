#!/bin/sh


umask 0002 && \
java -XX:MaxRAMPercentage=80 -XshowSettings:vm -Djava.security.egd=file:/dev/./urandom -jar ${project.build.finalName}.jar server config.yml