# Custom spit-testenv2 image
This is a custom image for spiud-testenv that comes auto-configured for abaco's dev/test envs.

    docker build -t docker-registry.fe.abacogroup.eu/abaco/spid-testenv2:1.0.0 .