package com.abacogroup.sso.server2.resources;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.sso.server2.api.LoginCredentials;
import com.abacogroup.sso.server2.api.LoginResponse;
import com.abacogroup.sso.server2.api.LoginResponse.Messages;
import com.abacogroup.sso.server2.api.RefreshTokensResquest;
import com.abacogroup.sso.server2.core.KeysService;
import com.abacogroup.sso.server2.core.UserService;
import com.abacogroup.sso.server2.core.passwords.PasswordHasherFactory;
import com.abacogroup.sso.server2.db.RefreshTokensDAO;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.abacogroup.sso.server2.db.ntt.Sso2RefreshToken;
import com.abacogroup.sso.server2.db.ntt.SsoUser;
import com.abacogroup.sso.server2.db.ntt.SsoUserLog;
import com.abacogroup.sso.server2.resources.exceptions.UnauthorizedException;
import com.auth0.jwt.algorithms.Algorithm;

import javax.servlet.http.HttpServletRequest;

@ExtendWith(MockitoExtension.class)
public class TokensResourcesTest {

	private static final String PWD = "welcome";
	private static final String PWD_MD5 = "40be4e59b9a2a2b5dffb918c0e86b3d7";

	@Mock
	Sso1DAO ssoDAO;
	@Mock
	RefreshTokensDAO refreshTokensDAO;
	@Mock
	KeysService keysService;

	private TokensResources resources;

	@BeforeEach
	public void setup() {
		Map<String, String> ssoParams = new HashMap<>();
		ssoParams.put("MAX_LOGIN_FAILURES", "5");
		ssoParams.put("PASSWORD_VALIDITY", "20");
		ssoParams.put("SSO_EXPIRE_WARNING_1", "2");
		when(ssoDAO.getSsoParameters()).thenReturn(ssoParams);

		UserService service = new UserService(ssoDAO, refreshTokensDAO,
				Algorithm.HMAC256(new byte[] { 1, 2, 3, 4 }),
				new PasswordHasherFactory(""),
				false, new HashMap<>(),
				null);

		resources = new TokensResources(service, keysService);
	}

	@Test
	public void mustSuceed() {
		SsoUser user = SsoUser.builder()
				.created_on(OffsetDateTime.now().minus(1, ChronoUnit.DAYS))
				.userid("x")
				.password(PWD_MD5)
				.is_locked('N')
				.password_last_modified_on(OffsetDateTime.now())
				.build();
		when(ssoDAO.getSsoUser(anyString(), anyString())).thenReturn(Optional.of(user));
		when(ssoDAO.getUserLog(anyString())).thenReturn(SsoUserLog.builder()
				.failed_logins(0)
				.build());

		HttpServletRequest requestServlet = mock(HttpServletRequest.class);
		when(requestServlet.getRemoteAddr()).thenReturn("dsgfdhfgh1");

		LoginResponse res = resources.login(new LoginCredentials("x", PWD), requestServlet);
		assertNotNull(res);
		assertNotNull(res.getAuth_token());
		assertFalse(res.getAuth_token().equals(""));
		assertNotNull(res.getRefresh_token());
		assertFalse(res.getRefresh_token().equals(""));
		assertNotNull(res.getWarnings());
		assertEquals(res.getWarnings().size(), 0);
		assertNotNull(res.getErrors());
		assertEquals(res.getErrors().size(), 0);
	}

	public void mustFailOnUnknownUser() {
		when(ssoDAO.getSsoUser(Sso1DAO.DEFAULT_TENANT, anyString())).thenReturn(Optional.empty());
		HttpServletRequest requestServlet = mock(HttpServletRequest.class);
		when(requestServlet.getRemoteAddr()).thenReturn("dsgfdhfgh2");
		assertThrows(UnauthorizedException.class, () -> resources.login(new LoginCredentials("x", PWD), requestServlet));
	}

	public void mustFailOnLockedUser() {
		SsoUser user = SsoUser.builder()
				.userid("x")
				.password(PWD_MD5)
				.is_locked('Y')
				.build();

		SsoUserLog userLog = SsoUserLog.builder()
				.last_login(OffsetDateTime.now())
				.userid("x")
				.failed_logins(0)
				.build();

		when(ssoDAO.getSsoUser(Sso1DAO.DEFAULT_TENANT, anyString())).thenReturn(Optional.of(user));
		when(ssoDAO.getUserLog(anyString())).thenReturn(userLog);
		HttpServletRequest requestServlet = mock(HttpServletRequest.class);
		when(requestServlet.getRemoteAddr()).thenReturn("dsgfdhfgh8");
		assertThrows(UnauthorizedException.class, () -> resources.login(new LoginCredentials("x", PWD), requestServlet));
	}

	public void mustFailOnTooManyLoginfailures() {
		SsoUser user = SsoUser.builder()
				.userid("x")
				.password(PWD_MD5)
				.is_locked('N')
				.build();
		when(ssoDAO.getSsoUser(Sso1DAO.DEFAULT_TENANT, anyString())).thenReturn(Optional.of(user));
		when(ssoDAO.getUserLog(anyString())).thenReturn(SsoUserLog.builder()
				.failed_logins(10)
				.build());
		HttpServletRequest requestServlet = mock(HttpServletRequest.class);
		when(requestServlet.getRemoteAddr()).thenReturn("dsgfdhfgh9");
		assertThrows(UnauthorizedException.class, () -> resources.login(new LoginCredentials("x", PWD), requestServlet));
	}

	@Test
	public void mustReturnNullTokensWhenPasswordIsExpired() {
		SsoUser user = SsoUser.builder()
				.created_on(OffsetDateTime.now().minus(1, ChronoUnit.DAYS))
				.userid("x")
				.password(PWD_MD5)
				.is_locked('N')
				.password_last_modified_on(OffsetDateTime.of(2000, 1, 1, 0, 0, 0, 0, ZoneOffset.UTC))
				.build();

		when(ssoDAO.getSsoUser(anyString(), anyString())).thenReturn(Optional.of(user));
		when(ssoDAO.getUserLog(anyString())).thenReturn(SsoUserLog.builder()
				.failed_logins(0)
				.build());
		HttpServletRequest requestServlet = mock(HttpServletRequest.class);


		LoginResponse res = resources.login(new LoginCredentials("x", PWD), requestServlet);
		assertNotNull(res);
		assertNull(res.getAuth_token());
		assertNull(res.getRefresh_token());
		assertNotNull(res.getWarnings());
		assertEquals(0, res.getWarnings().size());
		assertNotNull(res.getErrors());
		assertEquals(1, res.getErrors().size());
		assertEquals(Messages.ERROR_PASSWORD_MUST_BE_CHANGED.key(), res.getErrors().get(0).getKey());
	}

	@Test
	public void mustFailWhenPasswordWasNeverChanged() {
		OffsetDateTime dt = OffsetDateTime.now().minus(1, ChronoUnit.DAYS);
		SsoUser user = SsoUser.builder()
				.created_on(dt)
				.userid("x")
				.password(PWD_MD5)
				.is_locked('N')
				.password_last_modified_on(dt)
				.build();

		when(ssoDAO.getSsoUser(anyString(), anyString())).thenReturn(Optional.of(user));
		when(ssoDAO.getUserLog(anyString())).thenReturn(SsoUserLog.builder()
				.failed_logins(0)
				.build());
		HttpServletRequest requestServlet = mock(HttpServletRequest.class);


		LoginResponse res = resources.login(new LoginCredentials("x", PWD), requestServlet);
		assertNotNull(res);
		assertNull(res.getAuth_token());
		assertNull(res.getRefresh_token());
		assertNotNull(res.getErrors());
		assertEquals(1, res.getErrors().size());
		assertEquals(Messages.ERROR_PASSWORD_MUST_BE_CHANGED_AT_START.key(), res.getErrors().get(0).getKey());
	}

	@Test
	public void mustWarnIfPasswordIsAboutToExpire() {
		SsoUser user = SsoUser.builder()
				.created_on(OffsetDateTime.now().minus(40, ChronoUnit.DAYS))
				.userid("x")
				.password(PWD_MD5)
				.is_locked('N')
				.password_last_modified_on(OffsetDateTime.now().minus(19, ChronoUnit.DAYS))
				.build();

		when(ssoDAO.getSsoUser(anyString(), anyString())).thenReturn(Optional.of(user));
		when(ssoDAO.getUserLog(anyString())).thenReturn(SsoUserLog.builder()
				.failed_logins(0)
				.build());
		HttpServletRequest requestServlet = mock(HttpServletRequest.class);
		when(requestServlet.getRemoteAddr()).thenReturn("dsgfdhfgh44");

		LoginResponse res = resources.login(new LoginCredentials("x", PWD), requestServlet);
		assertNotNull(res);
		assertNotNull(res.getAuth_token());
		assertNotNull(res.getRefresh_token());
		assertNotNull(res.getErrors());
		assertEquals(0, res.getErrors().size());
		assertNotNull(res.getWarnings());
		assertEquals(1, res.getWarnings().size());
		assertEquals(Messages.WARNING_PASSWORD_EXPIRES_IN.key(), res.getWarnings().get(0).getKey());
		assertEquals("1", res.getWarnings().get(0).getValues().get(0));
	}

	public void mustFailOnUnknownRefreshToken() {
		RefreshTokensResquest req = new RefreshTokensResquest();
		req.setRefresh_token("x");
		when(refreshTokensDAO.getToken(Sso1DAO.DEFAULT_TENANT, anyString())).thenReturn(Optional.empty());
		assertThrows(UnauthorizedException.class, () -> resources.refresh(req));
	}

	public void mustFailOnExpiredRefreshToken() {
		RefreshTokensResquest req = new RefreshTokensResquest();
		req.setRefresh_token("x");

		Sso2RefreshToken token = Sso2RefreshToken.builder()
				.expires_at(OffsetDateTime.now().minusDays(1))
				.issued_at(OffsetDateTime.now().minusDays(2))
				.refresh_token("x")
				.userid("x")
				.build();

		when(refreshTokensDAO.getToken(Sso1DAO.DEFAULT_TENANT, anyString())).thenReturn(Optional.of(token));
		assertThrows(UnauthorizedException.class, () -> resources.refresh(req));
	}

}
