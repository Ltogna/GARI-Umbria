package com.abacogroup.sso.server2.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

public class DeleteOldPubkeysCommandTest {
	private DeleteOldPubKeysCommand cmd;

	@BeforeEach
	void beforeEach() {
		// setting the file creation date do not work (sometime) in the CI
		cmd = new DeleteOldPubKeysCommand() {
			@Override
			protected boolean isOld(Path path, int days) {
				Instant ref = Instant.now().minus(days, ChronoUnit.DAYS);

				var name = path.toFile().getName();
				int pos = name.lastIndexOf('.');
				long epochMilli = Long.parseLong(name.substring(pos + 1, name.length()));
				Instant instant = Instant.ofEpochMilli(epochMilli);
				return instant.isBefore(ref);
			}
		};
	}

	@Test
	public void whenAllKeysAreRecent_thenDeleteNone(@TempDir File tempDir) throws IOException {
		int numToCreate = 5;
		int numExpected = 5;
		long creationDate = Instant.now().minus(Duration.ofDays(5)).toEpochMilli();

		createFiles(tempDir, creationDate, numToCreate);

		cmd.run(tempDir, 10);
		assertEquals(numExpected, tempDir.list().length);
	}

	@Test
	public void whenAllKeysAreOld_thenDeleteAll(@TempDir File tempDir) throws IOException {
		int numToCreate = 5;
		int numExpected = 0;
		long creationDate = Instant.now().minus(Duration.ofDays(11)).toEpochMilli();

		createFiles(tempDir, creationDate, numToCreate);

		cmd.run(tempDir, 10);
		assertEquals(numExpected, tempDir.list().length);
	}

	@Test
	public void whenKeysHaveMixedCreationDates_thenDeleteOnlyOldOnes(@TempDir File tempDir) throws IOException {
		int numExpected = 3;
		long creationDate;

		creationDate = Instant.now().minus(Duration.ofDays(11)).toEpochMilli();
		createFiles(tempDir, creationDate, 5);

		creationDate = Instant.now().minus(Duration.ofDays(9)).toEpochMilli();
		createFiles(tempDir, creationDate, 1);

		creationDate = Instant.now().minus(Duration.ofDays(2)).toEpochMilli();
		createFiles(tempDir, creationDate, 2);

		cmd.run(tempDir, 10);
		assertEquals(numExpected, tempDir.list().length);
	}

	private void createFiles(File dir, long creationDate, int num) throws IOException {
		String uuid = UUID.randomUUID().toString();
		byte[] bytes = uuid.getBytes();

		Path path;
		for (int i = 0; i < num; i++) {
			path = new File(dir, uuid + i + "." + creationDate).toPath();
			Files.write(path, bytes, StandardOpenOption.CREATE_NEW);
		}
	}
}
