package com.abacogroup.sso.server2.core.bundle;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

import java.sql.Connection;
import java.sql.DriverManager;
import java.time.OffsetDateTime;
import java.util.*;

import javax.ws.rs.NotFoundException;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.sqlobject.SqlObjectPlugin;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.sso.server2.api.ApiKeyResponse;
import com.abacogroup.sso.server2.core.ApiKeyService;
import com.abacogroup.sso.server2.core.UserService;
import com.abacogroup.sso.server2.core.bundle.model.*;
import com.abacogroup.sso.server2.core.passwords.PasswordHasherFactory;
import com.abacogroup.sso.server2.db.ConfigDAO;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.abacogroup.sso.server2.db.ntt.SsoRoleFunctionCodesEntity;
import com.abacogroup.sso.server2.db.ntt.SsoRolesEntity;
import com.abacogroup.sso.server2.db.ntt.SsoUser;
import com.fasterxml.jackson.databind.ObjectMapper;

import liquibase.Liquibase;
import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.resource.ClassLoaderResourceAccessor;

public class Sso2BundleProcessorTest {

	private static Jdbi jdbi;
	private static Sso2FunctionsConfigProcessor functionsConfigProcessor;
	private static Sso2UsersConfigProcessor usersConfigProcessor;
	private static Sso2ParametersConfigProcessor parametersConfigProcessor;
	private static Sso2TenantMessageProcessor tenantProcessor;
	private static ConfigDAO configDAO;
	private static Sso1DAO ssoDAO;
	private static ApiKeyService apiKeyService;
	private static ObjectMapper objectMapper;

	@BeforeAll
	public static void beforeAll() throws Exception {
		String url = "jdbc:postgresql://localhost:5432/sso";
		String user = "sso";
		String password = "postgres";

		Connection cnn = DriverManager.getConnection(url, user, password);
		JdbcConnection conn = new JdbcConnection(cnn);
		Database database = DatabaseFactory.getInstance().findCorrectDatabaseImplementation(conn);

		try (Liquibase liquibase = new Liquibase("migrations.xml", new ClassLoaderResourceAccessor(), database)) {
			String ctx = null;
			liquibase.update(ctx);
		}

		jdbi = Jdbi.create(url, user, password);

		jdbi.installPlugin(new SqlObjectPlugin());
		jdbi.installPlugin(new PgJdbiPlugin());

		configDAO = jdbi.onDemand(ConfigDAO.class);
		ssoDAO = jdbi.onDemand(Sso1DAO.class);
		apiKeyService = new ApiKeyService(ssoDAO, mock(UserService.class));

		objectMapper = new ObjectMapper();
		objectMapper.findAndRegisterModules();

		functionsConfigProcessor = new Sso2FunctionsConfigProcessor(configDAO, objectMapper);
		usersConfigProcessor = new Sso2UsersConfigProcessor(configDAO, ssoDAO, apiKeyService, new PasswordHasherFactory("argon2id"), objectMapper);
		tenantProcessor = new Sso2TenantMessageProcessor(configDAO, ssoDAO);
		parametersConfigProcessor = new Sso2ParametersConfigProcessor(configDAO, ssoDAO, objectMapper);
	}

	@Test
	public void testCreateFunctions() {
		String tenantId = "*";
		String contextId = "TEST-CTX";

		jdbi.useTransaction(h -> {
			functionsConfigProcessor.doInsertOrUpdate(tenantId, FunctionsConfigMessage.builder()
					.functions(List.of(
							new FunctionDefinition(contextId, "FNC1", "Function 1"),
							new FunctionDefinition(contextId, "FNC2", "Function 2")))
					.build());

			assertNotNull(configDAO.getSsoContextFunction(tenantId, contextId, "FNC1"));
			assertNotNull(configDAO.getSsoContextFunction(tenantId, contextId, "FNC2"));

			h.rollback();
		});
	}

	@Test
	public void testCreateRole() {
		jdbi.useTransaction(h -> {
			String tenantId = "*";
			functionsConfigProcessor.doInsertOrUpdate(tenantId, FunctionsConfigMessage.builder()
					.roles(List.of(new RoleDefinition("ROLE1", "Role 1")))
					.build());

			assertNotNull(configDAO.getSsoRole(tenantId, "ROLE1"));

			h.rollback();
		});
	}

	@Test
	public void testCreateFunctionsAndRole() {
		jdbi.useTransaction(h -> {
			String tenantId = "*";
			String contextId = "TEST-CTX2";
			String roleCode = "ROLE2";

			RoleFunctions rf = new RoleFunctions(roleCode, List.of(new FunctionID(contextId, "FNC1")));

			functionsConfigProcessor.doInsertOrUpdate(tenantId, FunctionsConfigMessage.builder()
					.functions(List.of(
							new FunctionDefinition(contextId, "FNC1", "Function 1"),
							new FunctionDefinition(contextId, "FNC2", "Function 2")))
					.roles(List.of(new RoleDefinition(roleCode, "Role 2")))
					.roleFunctions(List.of(rf))
					.build());

			SsoRolesEntity roleNtt = configDAO.getSsoRole(tenantId, roleCode);
			List<SsoRoleFunctionCodesEntity> roleFunctions = configDAO.getRoleFunctionCodes(roleNtt.getRoleId());

			assertEquals(1, roleFunctions.size());
			assertEquals(contextId, roleFunctions.get(0).getContextId());
			assertEquals("FNC1", roleFunctions.get(0).getFunctionCode());

			h.rollback();
		});
	}

	@Test
	public void testCreateFunctionsAndRoleTwice() {
		jdbi.useTransaction(h -> {
			String tenantId = "*";
			String contextId = "TEST-CTX3";
			String roleCode = "ROLE3";

			RoleFunctions rf = new RoleFunctions(roleCode, List.of(new FunctionID(contextId, "FNC1")));

			functionsConfigProcessor.doInsertOrUpdate(tenantId, FunctionsConfigMessage.builder()
					.functions(List.of(
							new FunctionDefinition(contextId, "FNC1", "Function 1"),
							new FunctionDefinition(contextId, "FNC2", "Function 2")))
					.roles(List.of(new RoleDefinition(roleCode, "Role 2")))
					.roleFunctions(List.of(rf))
					.build());

			functionsConfigProcessor.doInsertOrUpdate(tenantId, FunctionsConfigMessage.builder()
					.functions(List.of(
							new FunctionDefinition(contextId, "FNC1", "Function 1"),
							new FunctionDefinition(contextId, "FNC2", "Function 2")))
					.roles(List.of(new RoleDefinition(roleCode, "Role 2")))
					.roleFunctions(List.of(rf))
					.build());

			SsoRolesEntity roleNtt = configDAO.getSsoRole(tenantId, roleCode);
			List<SsoRoleFunctionCodesEntity> roleFunctions = configDAO.getRoleFunctionCodes(roleNtt.getRoleId());

			assertEquals(1, roleFunctions.size());
			assertEquals(contextId, roleFunctions.get(0).getContextId());
			assertEquals("FNC1", roleFunctions.get(0).getFunctionCode());

			h.rollback();
		});
	}

	@Test
	public void testCreateApiKey() {
		String tenantId = "*";

		jdbi.useTransaction(h -> {
			usersConfigProcessor.doInsertOrUpdate(tenantId, UsersConfigMessage.builder()
					.users(List.of(new UserDefinition("user1", "password", "Description 1")))
					.apiKeys(List.of(new ApiKeyDefinition("user1", OffsetDateTime.now(), OffsetDateTime.now().plusDays(1), "TEST-KEY")))
					.build());

			SsoUser user = ssoDAO.getSsoUser("*", "USER1").orElseThrow();
			List<ApiKeyResponse> keys = apiKeyService.getApiKeysFromUserId(user.getUserid(), true);
			assertEquals(1, keys.size());

			h.rollback();
		});
	}

	@Test
	public void testCreateUserWithProps() {
		String tenantId = "*";
		String uuid = UUID.randomUUID().toString();
		Map<String, String> props = Map.of("key", uuid);

		var user = new UserDefinition("UseR2", "password", "Description 2");
		jdbi.useTransaction(h -> {
			usersConfigProcessor.doInsertOrUpdate(tenantId, UsersConfigMessage.builder()
					.users(List.of(user))
					.properties(List.of(new UserProperties("user2", props)))
					.build());

			Map<String, String> dbProps = ssoDAO.getUserProperties(tenantId, "USER2");
			assertEquals(props, dbProps);

			h.rollback();
		});
	}

	@Test
	public void testRemoveUserProps() {
		String tenantId = "*";
		String uuid = UUID.randomUUID().toString();
		Map<String, String> props = Map.of("key", uuid);

		var user = new UserDefinition("UseR2", "password", "Description 2");
		jdbi.useTransaction(h -> {
			usersConfigProcessor.doInsertOrUpdate(tenantId, UsersConfigMessage.builder()
					.users(List.of(user))
					.properties(List.of(new UserProperties("user2", props)))
					.build());

			Map<String, String> dbProps = ssoDAO.getUserProperties(tenantId, "USER2");
			assertThat(dbProps).isNotEmpty();

			usersConfigProcessor.doInsertOrUpdate(tenantId, UsersConfigMessage.builder()
					.properties(List.of(new UserProperties("user2", Map.of())))
					.build());

			dbProps = ssoDAO.getUserProperties(tenantId, "USER2");
			assertThat(dbProps).isEmpty();

			h.rollback();
		});
	}

	@Test
	public void testCreateUsers() {
		String tenantId = "*";

		jdbi.useTransaction(h -> {
			usersConfigProcessor.doInsertOrUpdate(tenantId, UsersConfigMessage.builder()
					.users(List.of(
							new UserDefinition("user1", "password", "Description 1"),
							new UserDefinition("UseR2", "password", "Description 2")))
					.build());

			assertDoesNotThrow(() -> ssoDAO.getSsoUser("*", "USER1").orElseThrow(NotFoundException::new));
			assertDoesNotThrow(() -> ssoDAO.getSsoUser("*", "USER2").orElseThrow(NotFoundException::new));

			h.rollback();
		});
	}

	@Test
	public void testCreateUsersWithTotpSecret() {
		String tenantId = "*";

		jdbi.useTransaction(h -> {
			usersConfigProcessor.doInsertOrUpdate(tenantId, UsersConfigMessage.builder()
					.users(List.of(
							new UserDefinition("user1", "password", "Description 1", "JBSWY3DPEHPK3PXP"),
							new UserDefinition("UseR2", "password", "Description 2", "JBSWY3DPEHPK3PXP")))
					.build());

			assertDoesNotThrow(() -> ssoDAO.getSsoUser("*", "USER1").orElseThrow(NotFoundException::new));
			assertDoesNotThrow(() -> ssoDAO.getSsoUser("*", "USER2").orElseThrow(NotFoundException::new));
			assertEquals(ssoDAO.getSsoUser("*", "USER1").get().getTwo_factor_auth_key(), "JBSWY3DPEHPK3PXP");

			h.rollback();
		});

	}

	@Test
	public void testCreateUsers2() {
		String tenantId = "*";

		List<UserDefinition> users = new ArrayList<UserDefinition>();
		users.add(new UserDefinition("userDontChangePassword1", "password", "Description 1"));
		users.add(new UserDefinition("userDontChangePassword2", "password", "Description 2"));
		users.add(new UserDefinition("userChangePassword1", "password", "Description 3"));

		users.get(1).setForceChangePassword(false);
		users.get(2).setForceChangePassword(true);

		jdbi.useTransaction(h -> {
			usersConfigProcessor.doInsertOrUpdate(tenantId, UsersConfigMessage.builder()
					.users(users)
					.build());

			Optional<SsoUser> userDontChangePassword1 = ssoDAO.getSsoUser(tenantId, "userDontChangePassword1");
			Optional<SsoUser> userDontChangePassword2 = ssoDAO.getSsoUser(tenantId, "userDontChangePassword2");
			Optional<SsoUser> userChangePassword1 = ssoDAO.getSsoUser(tenantId, "userChangePassword1");

			assertNotEquals(userDontChangePassword1.get().getCreated_on(), userDontChangePassword1.get().getPassword_last_modified_on());
			assertNotEquals(userDontChangePassword2.get().getCreated_on(), userDontChangePassword2.get().getPassword_last_modified_on());
			assertEquals(userChangePassword1.get().getCreated_on(), userChangePassword1.get().getPassword_last_modified_on());

			h.rollback();
		});
	}

	@Test
	public void testCreateUserWithRole() {
		String tenantId = "*";

		jdbi.useTransaction(h -> {
			functionsConfigProcessor.doInsertOrUpdate(tenantId, FunctionsConfigMessage.builder()
					.roles(List.of(new RoleDefinition("ROLE1", "Role 1")))
					.roleFunctions(List.of())
					.build());

			usersConfigProcessor.doInsertOrUpdate(tenantId, UsersConfigMessage.builder()
					.users(List.of(new UserDefinition("user1", "password", "Description 1")))
					.userRoles(List.of(new UserRole("uSEr1", List.of("ROLE1"))))
					.build());

			SsoUser user = ssoDAO.getSsoUser("*", "USER1").orElseThrow(NotFoundException::new);
			List<String> roles = ssoDAO.getUserRoleCodes(user.getUserid());

			assertNotNull(roles);
			assertEquals(1, roles.size());
			assertEquals("ROLE1", roles.get(0));

			h.rollback();
		});
	}

	@Test
	public void testCreateUserWithRoleTwice() {
		String tenantId = "*";

		jdbi.useTransaction(h -> {
			functionsConfigProcessor.doInsertOrUpdate(tenantId, FunctionsConfigMessage.builder()
					.roles(List.of(new RoleDefinition("ROLE1", "Role 1")))
					.roleFunctions(List.of())
					.build());

			UsersConfigMessage msg = UsersConfigMessage.builder()
					.users(List.of(new UserDefinition("user1", "password", "Description 1")))
					.userRoles(List.of(new UserRole("uSEr1", List.of("ROLE1"))))
					.build();

			usersConfigProcessor.doInsertOrUpdate(tenantId, msg);
			usersConfigProcessor.doInsertOrUpdate(tenantId, msg);

			SsoUser user = ssoDAO.getSsoUser("*", "USER1").orElseThrow(NotFoundException::new);
			List<String> roles = ssoDAO.getUserRoleCodes(user.getUserid());

			assertNotNull(roles);
			assertEquals(1, roles.size());
			assertEquals("ROLE1", roles.get(0));

			h.rollback();
		});
	}

	@Test
	public void testAddRoleToUser() {
		String tenantId = "*";

		jdbi.useTransaction(h -> {
			functionsConfigProcessor.doInsertOrUpdate(tenantId, FunctionsConfigMessage.builder()
					.roles(List.of(new RoleDefinition("ROLE1", "Role 1"), new RoleDefinition("ROLE2", "Role 2")))
					.build());

			usersConfigProcessor.doInsertOrUpdate(tenantId, UsersConfigMessage.builder()
					.users(List.of(new UserDefinition("user1", "password", "Description 1")))
					.userRoles(List.of(new UserRole("uSEr1", List.of("ROLE1"))))
					.build());
			usersConfigProcessor.doInsertOrUpdate(tenantId, UsersConfigMessage.builder()
					.userRoles(List.of(new UserRole("USER1", List.of("roLE2"))))
					.build());

			SsoUser user = ssoDAO.getSsoUser("*", "USER1").orElseThrow(NotFoundException::new);
			List<String> roles = ssoDAO.getUserRoleCodes(user.getUserid());

			assertNotNull(roles);
			assertEquals(2, roles.size());

			Set<String> expected = new TreeSet<>(List.of("ROLE1", "ROLE2"));
			expected.removeAll(roles);

			assertEquals(0, expected.size());

			h.rollback();
		});
	}

	@Test
	public void testRemoveRoleFromUser() {
		String tenantId = "*";

		jdbi.useTransaction(h -> {
			functionsConfigProcessor.doInsertOrUpdate(tenantId, FunctionsConfigMessage.builder()
					.roles(List.of(new RoleDefinition("ROLE1", "Role 1")))
					.roleFunctions(List.of())
					.build());

			usersConfigProcessor.doInsertOrUpdate(tenantId, UsersConfigMessage.builder()
					.users(List.of(new UserDefinition("user1", "password", "Description 1")))
					.userRoles(List.of(new UserRole("uSEr1", List.of("ROLE1"))))
					.build());

			usersConfigProcessor.doDeleteUserRoles(tenantId, List.of(new UserRole("uSEr1", List.of("ROLE1"))));

			SsoUser user = ssoDAO.getSsoUser(tenantId, "USER1").orElseThrow(NotFoundException::new);
			List<String> roles = ssoDAO.getUserRoleCodes(user.getUserid());

			assertNotNull(roles);
			assertEquals(0, roles.size());

			h.rollback();
		});
	}

	@Test
	public void testCreateNewTenant() {
		jdbi.useTransaction(h -> {
			String tenantId = "new-tenant";
			String contextId = "TEST-CTX_COPY-1";
			String roleCode = "ROLE_COPY";

			RoleFunctions rf = new RoleFunctions(roleCode, List.of(new FunctionID(contextId, "FNC1")));

			functionsConfigProcessor.doInsertOrUpdate("*", FunctionsConfigMessage.builder()
					.functions(List.of(
							new FunctionDefinition(contextId, "FNC1", "Function 1"),
							new FunctionDefinition(contextId, "FNC2", "Function 2")))
					.roles(List.of(new RoleDefinition(roleCode, "Role 2")))
					.roleFunctions(List.of(rf))
					.build());

			usersConfigProcessor.doInsertOrUpdate("*", UsersConfigMessage.builder()
					.users(List.of(new UserDefinition("user1", "password", "Description 1")))
					.userRoles(List.of(new UserRole("uSEr1", List.of(roleCode))))
					.build());

			tenantProcessor.onMessage(new TenantMessage().setTenantId(tenantId));

			SsoRolesEntity roleNtt = configDAO.getSsoRole(tenantId, roleCode);
			List<SsoRoleFunctionCodesEntity> roleFunctions = configDAO.getRoleFunctionCodes(roleNtt.getRoleId());

			assertEquals(1, roleFunctions.size());
			assertEquals(contextId, roleFunctions.get(0).getContextId());
			assertEquals("FNC1", roleFunctions.get(0).getFunctionCode());

			assertTrue(ssoDAO.getSsoUser(tenantId, "USER1").isPresent(), "Missing user in new tenant");

			h.rollback();
		});
	}

	@Test
	public void testDeleteFunctions() {
		jdbi.useTransaction(h -> {
			String tenantId = "*";
			String contextId = "TEST-CTX-D";
			String roleCode = "ROLE1";

			RoleFunctions rf = new RoleFunctions(roleCode, List.of(new FunctionID(contextId, "FNC1")));

			functionsConfigProcessor.doInsertOrUpdate("*", FunctionsConfigMessage.builder()
					.functions(List.of(
							new FunctionDefinition(contextId, "FNC1", "Function 1"),
							new FunctionDefinition(contextId, "FNC2", "Function 2")))
					.roles(List.of(new RoleDefinition(roleCode, "Role 2")))
					.roleFunctions(List.of(rf))
					.build());

			SsoRolesEntity roleNtt = configDAO.getSsoRole(tenantId, roleCode);
			List<SsoRoleFunctionCodesEntity> roleFunctions = configDAO.getRoleFunctionCodes(roleNtt.getRoleId());
			assertEquals(1, roleFunctions.size());

			functionsConfigProcessor.doDelete(tenantId, FunctionsConfigMessage.builder()
					.functions(List.of(
							new FunctionDefinition(contextId, "FNC1", null)))
					.build());

			roleFunctions = configDAO.getRoleFunctionCodes(roleNtt.getRoleId());

			assertEquals(0, roleFunctions.size());
			assertNull(configDAO.getSsoContextFunction(tenantId, contextId, "FNC1"));

			h.rollback();
		});
	}

	@Test
	public void testDeleteRoleFunctions() {
		jdbi.useTransaction(h -> {
			String tenantId = "*";
			String contextId = "TEST-CTX-D-2";
			String roleCode = "ROLE1";

			RoleFunctions rf = new RoleFunctions(roleCode, List.of(new FunctionID(contextId, "FNC1")));

			functionsConfigProcessor.doInsertOrUpdate("*", FunctionsConfigMessage.builder()
					.functions(List.of(
							new FunctionDefinition(contextId, "FNC1", "Function 1"),
							new FunctionDefinition(contextId, "FNC2", "Function 2")))
					.roles(List.of(new RoleDefinition(roleCode, "Role 2")))
					.roleFunctions(List.of(rf))
					.build());

			SsoRolesEntity roleNtt = configDAO.getSsoRole(tenantId, roleCode);
			List<SsoRoleFunctionCodesEntity> roleFunctions = configDAO.getRoleFunctionCodes(roleNtt.getRoleId());
			assertEquals(1, roleFunctions.size());

			functionsConfigProcessor.doDelete(tenantId, FunctionsConfigMessage.builder()
					.roleFunctions(List.of(
							new RoleFunctions(roleCode, List.of(new FunctionID(contextId, "FNC1")))))
					.build());

			roleFunctions = configDAO.getRoleFunctionCodes(roleNtt.getRoleId());
			assertEquals(0, roleFunctions.size());
			assertNotNull(configDAO.getSsoContextFunction(tenantId, contextId, "FNC1"));

			h.rollback();
		});
	}

	@Test
	public void testDeleteRole() {
		jdbi.useTransaction(h -> {
			String tenantId = "*";
			String contextId = "TEST-CTX-D-3";
			String roleCode = "ROLE1";

			RoleFunctions rf = new RoleFunctions(roleCode, List.of(new FunctionID(contextId, "FNC1")));

			functionsConfigProcessor.doInsertOrUpdate("*", FunctionsConfigMessage.builder()
					.functions(List.of(
							new FunctionDefinition(contextId, "FNC1", "Function 1"),
							new FunctionDefinition(contextId, "FNC2", "Function 2")))
					.roles(List.of(new RoleDefinition(roleCode, "Role 2")))
					.roleFunctions(List.of(rf))
					.build());

			SsoRolesEntity roleNtt = configDAO.getSsoRole(tenantId, roleCode);
			List<SsoRoleFunctionCodesEntity> roleFunctions = configDAO.getRoleFunctionCodes(roleNtt.getRoleId());
			assertEquals(1, roleFunctions.size());

			functionsConfigProcessor.doDelete(tenantId, FunctionsConfigMessage.builder()
					.roles(List.of(new RoleDefinition(roleCode, null)))
					.build());

			assertNull(configDAO.getSsoRole(tenantId, roleCode));

			h.rollback();
		});
	}

	@Test
	public void testCreateParameter(){
		jdbi.useTransaction(h -> {
			ParametersConfigMessage parametersConfig = new ParametersConfigMessage(Map.ofEntries(
					Map.entry("SSO_UC_LETTERS", "SI"),
					Map.entry("SSO_LC_LETTERS", "SI"),
					Map.entry("SSO_LETTERS", "SI"),
					Map.entry("SSO_SYMBOLS", "SI"),
					Map.entry("SSO_MIN_PWD_LEN", "8"),
					Map.entry("SSO_MAX_PWD_LEN", "64")));


			parametersConfigProcessor.doInsertOrUpdate(parametersConfig);

			assertEquals(6, ssoDAO.getSsoParameters().size());
		});
	}

	@Test
	public void testDeleteParameter() {
		jdbi.useTransaction(h -> {
			ParametersConfigMessage parametersConfigInsert = new ParametersConfigMessage(Map.ofEntries(
					Map.entry("SSO_UC_LETTERS", "SI"),
					Map.entry("SSO_LC_LETTERS", "SI"),
					Map.entry("SSO_LETTERS", "SI"),
					Map.entry("SSO_SYMBOLS", "SI"),
					Map.entry("SSO_MIN_PWD_LEN", "8"),
					Map.entry("SSO_MAX_PWD_LEN", "64")));

			parametersConfigProcessor.doInsertOrUpdate(parametersConfigInsert);

			ParametersConfigMessage parametersConfigDelete= new ParametersConfigMessage(Map.ofEntries(
					Map.entry("SSO_UC_LETTERS", "SI"),
					Map.entry("SSO_LC_LETTERS", "SI")));

			parametersConfigProcessor.doDelete(parametersConfigDelete);

			assertEquals(4, ssoDAO.getSsoParameters().size());
		});
	}
}
