package com.abacogroup.sso.server2.resources;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.sso.server2.api.ChangePasswordRequest;
import com.abacogroup.sso.server2.api.PasswordResponse;
import com.abacogroup.sso.server2.api.UnAuthChangePasswordRequest;
import com.abacogroup.sso.server2.core.UserService;
import com.abacogroup.sso.server2.core.passwords.PasswordHasherFactory;
import com.abacogroup.sso.server2.db.RefreshTokensDAO;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.abacogroup.sso.server2.db.ntt.SsoUser;
import com.abacogroup.sso.server2.db.ntt.SsoUserLog;
import com.abacogroup.sso.server2.resources.exceptions.UnauthorizedException;
import com.abacogroup.sso.server2.resources.exceptions.UnauthorizedExceptionMaxLogFail;
import com.auth0.jwt.algorithms.Algorithm;

@ExtendWith(MockitoExtension.class)
public class PasswordResourcesTest {

	@Mock
	Sso1DAO ssoDAO;
	@Mock
	RefreshTokensDAO refreshTokensDAO;

	private static final String USER = "USER";
	private static final String TENANT = "TEST_TENANT";

	private static final String PWD = "Welcome_0";
	private static final String PWD_MD5 = "47af88718a714b8b3e325c4f09f4fd19";
	private static final String NEW_CORRECT_PWD = "New_pass1234!";

	private SsoUser ssoUser;
	private PasswordResources passwordResources;

	@BeforeEach
	public void setup() {
		Map<String, String> ssoParams = new HashMap<>();
		ssoParams.put("MAX_LOGIN_FAILURES", "5");
		ssoParams.put("PASSWORD_VALIDITY", "20");
		ssoParams.put("SSO_EXPIRE_WARNING_1", "2");
		ssoParams.put("USERNAME_VALIDITY", "90");
		ssoParams.put("SSO_UC_LETTERS", "SI");
		ssoParams.put("SSO_LC_LETTERS", "SI");
		ssoParams.put("SSO_LETTERS", "SI");
		ssoParams.put("SSO_NUMBERS", "SI");
		ssoParams.put("SSO_SYMBOLS", "SI");
		ssoParams.put("SSO_MIN_PWD_LEN", "8");
		ssoParams.put("SSO_MAX_PWD_LEN", "30");

		ssoUser = SsoUser.builder()
				.created_on(OffsetDateTime.now().minus(1, ChronoUnit.DAYS))
				.userid("x")
				.password(PWD_MD5)
				.is_locked('N')
				.password_last_modified_on(OffsetDateTime.now())
				.build();

		when(ssoDAO.getSsoParameters()).thenReturn(ssoParams);

		UserService userService = new UserService(ssoDAO, refreshTokensDAO,
				Algorithm.HMAC256(new byte[] { 1, 2, 3, 4 }),
				new PasswordHasherFactory("argon2id"),
				false, new HashMap<>(),
				null);

		passwordResources = new PasswordResources(userService);
	}

	@Test
	public void changePasswordMustSucceed() {
		when(ssoDAO.getSsoUser(anyString())).thenReturn(Optional.of(ssoUser));
		when(ssoDAO.getUserLog(anyString())).thenReturn(SsoUserLog.builder()
				.last_login(OffsetDateTime.now().minusDays(3))
				.failed_logins(0)
				.build());

		User user = getDefaultUser();
		ChangePasswordRequest request = new ChangePasswordRequest();
		request.setOldPassword(PWD);
		request.setNewPassword(NEW_CORRECT_PWD);
		PasswordResponse response = passwordResources.changePassword(user, request);

		assertTrue(response.isOk());
		assertEquals(0, response.getErrors().size());
	}

	@Test
	public void changePasswordMustFailOnWrongOldPassword() {
		when(ssoDAO.getSsoUser(anyString())).thenReturn(Optional.of(ssoUser));
		lenient().when(ssoDAO.getUserLog(anyString())).thenReturn(SsoUserLog.builder()
				.last_login(OffsetDateTime.now().minusDays(3))
				.failed_logins(0)
				.build());

		User user = getDefaultUser();
		ChangePasswordRequest request = new ChangePasswordRequest();
		request.setOldPassword("wrong_old_pass");
		request.setNewPassword(NEW_CORRECT_PWD);
		PasswordResponse response = passwordResources.changePassword(user, request);

		assertFalse(response.isOk());
		assertTrue(response.getErrors().size() > 0);
		assertTrue(response.getErrors().stream()
				.anyMatch(m -> m.getKey().equals(PasswordResponse.Messages.ERROR_WRONG_OLD_PASSWORD.key())));
	}

	@Test
	public void changePasswordMustFailIfOldPasswordEqualsNewPassword() {
		when(ssoDAO.getSsoUser(anyString())).thenReturn(Optional.of(ssoUser));
		lenient().when(ssoDAO.getUserLog(anyString())).thenReturn(SsoUserLog.builder()
				.last_login(OffsetDateTime.now().minusDays(3))
				.failed_logins(0)
				.build());

		User user = getDefaultUser();
		ChangePasswordRequest request = new ChangePasswordRequest();
		request.setOldPassword(PWD);
		request.setNewPassword(PWD);
		PasswordResponse response = passwordResources.changePassword(user, request);

		assertFalse(response.isOk());
		assertTrue(response.getErrors().size() > 0);
		assertTrue(response.getErrors().stream().anyMatch(
				m -> m.getKey().equals(PasswordResponse.Messages.ERROR_OLD_PASSWORD_MUST_BE_DIFFERENT_FROM_NEW_ONE.key())));
	}

	@Test
	public void changePasswordMustFailForNewPasswordWithoutUppercaseLetters() {
		when(ssoDAO.getSsoUser(anyString())).thenReturn(Optional.of(ssoUser));
		when(ssoDAO.getUserLog(anyString())).thenReturn(SsoUserLog.builder()
				.last_login(OffsetDateTime.now().minusDays(3))
				.failed_logins(0)
				.build());

		User user = getDefaultUser();
		ChangePasswordRequest request = new ChangePasswordRequest();
		request.setOldPassword(PWD);
		request.setNewPassword("new_pass1234!");
		PasswordResponse response = passwordResources.changePassword(user, request);

		assertFalse(response.isOk());
		assertTrue(response.getErrors().size() > 0);
		assertTrue(response.getErrors().stream()
				.anyMatch(m -> m.getKey().equals(PasswordResponse.Messages.PASSWORD_MUST_CONTAIN_UPPERCASE_LETTERS.key())));
	}

	@Test
	public void changePasswordMustFailForNewPasswordWithoutLowercaseLetters() {
		when(ssoDAO.getSsoUser(anyString())).thenReturn(Optional.of(ssoUser));
		when(ssoDAO.getUserLog(anyString())).thenReturn(SsoUserLog.builder()
				.last_login(OffsetDateTime.now().minusDays(3))
				.failed_logins(0)
				.build());

		User user = getDefaultUser();
		ChangePasswordRequest request = new ChangePasswordRequest();
		request.setOldPassword(PWD);
		request.setNewPassword("NEW_PASS1234!");
		PasswordResponse response = passwordResources.changePassword(user, request);

		assertFalse(response.isOk());
		assertTrue(response.getErrors().size() > 0);
		assertTrue(response.getErrors().stream()
				.anyMatch(m -> m.getKey().equals(PasswordResponse.Messages.PASSWORD_MUST_CONTAIN_LOWERCASE_LETTERS.key())));
	}

	@Test
	public void changePasswordMustFailForNewPasswordWithoutLetters() {
		when(ssoDAO.getSsoUser(anyString())).thenReturn(Optional.of(ssoUser));
		when(ssoDAO.getUserLog(anyString())).thenReturn(SsoUserLog.builder()
				.last_login(OffsetDateTime.now().minusDays(3))
				.failed_logins(0)
				.build());

		User user = getDefaultUser();
		ChangePasswordRequest request = new ChangePasswordRequest();
		request.setOldPassword(PWD);
		request.setNewPassword("53453451234!");
		PasswordResponse response = passwordResources.changePassword(user, request);

		assertFalse(response.isOk());
		assertTrue(response.getErrors().size() > 0);
		assertTrue(response.getErrors().stream()
				.anyMatch(m -> m.getKey().equals(PasswordResponse.Messages.PASSWORD_MUST_CONTAIN_LETTERS.key())));
	}

	@Test
	public void changePasswordMustFailForNewPasswordWithoutNumeric() {
		when(ssoDAO.getSsoUser(anyString())).thenReturn(Optional.of(ssoUser));
		when(ssoDAO.getUserLog(anyString())).thenReturn(SsoUserLog.builder()
				.last_login(OffsetDateTime.now().minusDays(3))
				.failed_logins(0)
				.build());

		User user = getDefaultUser();
		ChangePasswordRequest request = new ChangePasswordRequest();
		request.setOldPassword(PWD);
		request.setNewPassword("NewPass!");
		PasswordResponse response = passwordResources.changePassword(user, request);

		assertFalse(response.isOk());
		assertTrue(response.getErrors().size() > 0);
		assertTrue(response.getErrors().stream()
				.anyMatch(m -> m.getKey().equals(PasswordResponse.Messages.PASSWORD_MUST_CONTAIN_DIGITS.key())));
	}

	@Test
	public void changePasswordMustFailForNewPasswordWithoutSymbols() {
		when(ssoDAO.getSsoUser(anyString())).thenReturn(Optional.of(ssoUser));
		when(ssoDAO.getUserLog(anyString())).thenReturn(SsoUserLog.builder()
				.last_login(OffsetDateTime.now().minusDays(3))
				.failed_logins(0)
				.build());

		User user = getDefaultUser();
		ChangePasswordRequest request = new ChangePasswordRequest();
		request.setOldPassword(PWD);
		request.setNewPassword("NewPass");
		PasswordResponse response = passwordResources.changePassword(user, request);

		assertFalse(response.isOk());
		assertTrue(response.getErrors().size() > 0);
		assertTrue(response.getErrors().stream()
				.anyMatch(m -> m.getKey().equals(PasswordResponse.Messages.PASSWORD_MUST_CONTAIN_SYMBOLS.key())));
	}

	@Test
	public void changePasswordMustFailForNewPasswordTooShort() {
		when(ssoDAO.getSsoUser(anyString())).thenReturn(Optional.of(ssoUser));
		when(ssoDAO.getUserLog(anyString())).thenReturn(SsoUserLog.builder()
				.last_login(OffsetDateTime.now().minusDays(3))
				.failed_logins(0)
				.build());

		User user = getDefaultUser();
		ChangePasswordRequest request = new ChangePasswordRequest();
		request.setOldPassword(PWD);
		request.setNewPassword("pass");
		PasswordResponse response = passwordResources.changePassword(user, request);

		assertFalse(response.isOk());
		assertTrue(response.getErrors().size() > 0);
		assertTrue(response.getErrors().stream()
				.anyMatch(m -> m.getKey().equals(PasswordResponse.Messages.PASSWORD_IS_TOO_SHORT.key())));
	}

	@Test
	public void changePasswordMustFailForNewPasswordTooLong() {
		when(ssoDAO.getSsoUser(anyString())).thenReturn(Optional.of(ssoUser));
		when(ssoDAO.getUserLog(anyString())).thenReturn(SsoUserLog.builder()
				.last_login(OffsetDateTime.now().minusDays(3))
				.failed_logins(0)
				.build());

		User user = getDefaultUser();
		ChangePasswordRequest request = new ChangePasswordRequest();
		request.setOldPassword(PWD);
		request.setNewPassword("pass1212121641561d56sa1d56151561sad4da1das4d98as4d89sa4");
		PasswordResponse response = passwordResources.changePassword(user, request);

		assertFalse(response.isOk());
		assertTrue(response.getErrors().size() > 0);
		assertTrue(response.getErrors().stream()
				.anyMatch(m -> m.getKey().equals(PasswordResponse.Messages.PASSWORD_IS_TOO_LONG.key())));
	}

	@Test
	public void changePasswordMustFailForMaxLoginFailures() {
		when(ssoDAO.getUserLog(anyString())).thenReturn(SsoUserLog.builder()
				.last_login(OffsetDateTime.now().minusDays(3))
				.failed_logins(5)
				.build());

		User user = getDefaultUser();
		ChangePasswordRequest request = new ChangePasswordRequest();
		request.setOldPassword(PWD);
		request.setNewPassword(NEW_CORRECT_PWD);

		assertThrows(UnauthorizedExceptionMaxLogFail.class, () -> passwordResources.changePassword(user, request));
	}

	@Test
	public void unAuthChangePasswordMustThrowWhenWrongOldPassword() {
		when(ssoDAO.getSsoUser(anyString())).thenReturn(Optional.of(ssoUser));
		lenient().when(ssoDAO.getUserLog(anyString())).thenReturn(SsoUserLog.builder()
				.last_login(OffsetDateTime.now().minusDays(3))
				.failed_logins(0)
				.build());

		User user = getDefaultUser();
		UnAuthChangePasswordRequest request = new UnAuthChangePasswordRequest();
		request.setOldPassword("Wrong_oldPass0rd");
		request.setNewPassword(NEW_CORRECT_PWD);
		request.setUserid(user.getName());

		assertThrows(UnauthorizedException.class, () -> passwordResources.unAuthChangePassword(request));
	}

	private User getDefaultUser() {
		return new User(USER, TENANT);
	}

}
