package com.abacogroup.sso.server2.resources;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.OutParameters;
import org.jdbi.v3.sqlobject.SqlObjectPlugin;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.sso.server2.core.Sso1CompatibilityService;
import com.abacogroup.sso.server2.core.UserService;
import com.abacogroup.sso.server2.core.model.JSession;
import com.abacogroup.sso.server2.core.model.LoginStatus;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.abacogroup.sso.server2.db.ntt.SsoUser;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.github.benmanes.caffeine.cache.Cache;

import liquibase.Liquibase;
import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.resource.ClassLoaderResourceAccessor;

@ExtendWith(MockitoExtension.class)
public class Sso1CompatibilityTest {

	static TestSso1CompatibilityService sso1CompatibilityService;

	@Mock
	OutParameters outCanILogin;

	private static Sso1DAO ssoDAO;

	private static UserService userService;

	private static Jdbi jdbi = null;
	private static final String TASKAUTHSTRING = "af7284474f0ceb6758036cf7e253d94a";
	private static final String AUDIENCE = "initLogin";
	private static final String ISSUER = "sso2-server";
	private static final long MAX_AGE = 30000L;
	private static final String COOKIE_LOGIN = "X-INIT_LOGIN";
	private static final String PWD_MD5 = "40be4e59b9a2a2b5dffb918c0e86b3d7";
	private static final String TASKAUTHPHRASE = "af7284474f0ceb6758036cf7e253d94a";

	@Mock
	HttpServletResponse httpServletResponse;

	@BeforeAll
	public static void setup() throws Exception {

		String url = "jdbc:postgresql://localhost:5432/sso";
		String user = "sso";
		String password = "postgres";

		Connection cnn = DriverManager.getConnection(url, user, password);
		JdbcConnection conn = new JdbcConnection(cnn);
		Database database = DatabaseFactory.getInstance().findCorrectDatabaseImplementation(conn);

		try (Liquibase liquibase = new Liquibase("migrations.xml", new ClassLoaderResourceAccessor(), database)) {
			String ctx = null;
			liquibase.update(ctx);
		}

		jdbi = Jdbi.create(url, user, password);

		jdbi.installPlugin(new SqlObjectPlugin());
		jdbi.installPlugin(new PgJdbiPlugin());

		// ssoDAO = jdbi.onDemand(Sso1DAO.class);

		SsoUser user_ = SsoUser.builder()
				.userid("x")
				.username("username")
				.password(PWD_MD5)
				.is_locked('N')
				.build();
		userService = mock(UserService.class);
		when(userService.getUser("_", "username")).thenReturn(Optional.ofNullable(user_));

		ssoDAO = mock(Sso1DAO.class);

		sso1CompatibilityService = new TestSso1CompatibilityService(TASKAUTHSTRING, ssoDAO, userService, Algorithm.HMAC256(TASKAUTHPHRASE)) {
			@Override
			public Cache<String, JSession> getCache() {
				return super.getCache();
			}
		};
	}

	@Test
	public void test_init_login() throws IOException, NoSuchAlgorithmException {
		String secret = "af7284474f0ceb6758036cf7e253d94a";
		Algorithm algorithm = Algorithm.HMAC256(secret);
		String jwtToken = JWT.create()
				.withIssuer(ISSUER)
				.withAudience(AUDIENCE)
				.withIssuedAt(new Date())
				.withExpiresAt(new Date(System.currentTimeMillis() + MAX_AGE))
				.withJWTId(UUID.randomUUID()
						.toString())
				.sign(algorithm);

		Map<String, String[]> params = new HashMap<String, String[]>();
		params.put("function", new String[] { "initLogin" });

		final FileOutputStream fos = new FileOutputStream("somefile.txt");
		PrintWriter writer = new PrintWriter(fos, true);
		when(httpServletResponse.getWriter()).thenReturn(writer);

		Cookie cookie = new Cookie(COOKIE_LOGIN, jwtToken);

		sso1CompatibilityService.dispatchRequest(params, httpServletResponse, new Cookie[] { cookie }, "/sso2/");
		List<String> lines = Files.readAllLines(Paths.get("somefile.txt"));
		assertEquals(3, lines.size(), "The file should have exactly three rows.");
	}

	private String getHash(String ssoPhrase) throws NoSuchAlgorithmException {
		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(ssoPhrase.getBytes());
		byte[] digest = md.digest();
		return DatatypeConverter.printHexBinary(digest).toUpperCase();
	}

	@Test
	public void test_login() throws IOException, NoSuchAlgorithmException {
		Map<String, String[]> params = new HashMap<String, String[]>();
		params.put("function", new String[] { "Login" });
		params.put("username", new String[] { "username" });

		String secret = "af7284474f0ceb6758036cf7e253d94a";
		Algorithm algorithm = Algorithm.HMAC256(secret);
		String jwtToken = JWT.create()
				.withIssuer(ISSUER)
				.withAudience(AUDIENCE)
				.withIssuedAt(new Date())
				.withExpiresAt(new Date(System.currentTimeMillis() + MAX_AGE))
				.withJWTId(UUID.randomUUID()
						.toString())
				.sign(algorithm);

		params.put("ssoMD5", new String[] { getHash(PWD_MD5 + jwtToken) });

		SsoUser user = SsoUser.builder()
				.userid("username")
				.username("username")
				.password(PWD_MD5)
				.is_locked('N')
				.build();
		when(ssoDAO.getSsoUser(Sso1DAO.DEFAULT_TENANT, "username")).thenReturn(Optional.of(user));

		// when(outCanILogin.getInt("OUTPUT_STATUS")).thenReturn(0);
		// when(outCanILogin.getInt("OUTPUT_WARNINGS")).thenReturn(0);
		// when(outCanILogin.getInt("OUTPUT_ERRORS")).thenReturn(0);

		when(ssoDAO.callCanILogin(anyString(), anyString(), anyString())).thenReturn(new LoginStatus(0, 0, 0));

		// Lower(GET_HASH_VAL(Lower(DBPASS)||IN_INIT_TOKEN))

		final FileOutputStream fos = new FileOutputStream("somefile.txt");
		PrintWriter writer = new PrintWriter(fos, true);
		when(httpServletResponse.getWriter()).thenReturn(writer);

		Cookie cookie = new Cookie(COOKIE_LOGIN, jwtToken);
		sso1CompatibilityService.dispatchRequest(params, httpServletResponse, new Cookie[] { cookie }, "/sso2/");

		List<String> lines = Files.readAllLines(Paths.get("somefile.txt"));
		assertEquals(2, lines.size(), "The file should have exactly two rows.");
	}

	// @Test
	// public void test_do_check_login() throws IOException, NoSuchAlgorithmException {
	// String jSessionToken = "WTIo_EvSOmVSaO58h0wFHy_5xguc9UoA";
	// Cache sessionCache = sso1CompatibilityService.getCache();
	// sessionCache.put(jSessionToken, new JSession("username", OffsetDateTime.now().plus(30, ChronoUnit.MINUTES)));
	// Cookie cookie = new Cookie(JSESSIONID, jSessionToken);
	// cookie.setMaxAge(60*30);
	// cookie.setPath("/sso2/");
	// cookie.setHttpOnly(true);
	// Map<String, String[]> params_ = new HashMap<String, String[]>();
	// params_.put("function", new String[]{"GetJwtToken"});
	// final FileOutputStream fos = new FileOutputStream("somefile.txt");
	// PrintWriter writer = new PrintWriter(fos, true);
	// when(httpServletResponse.getWriter()).thenReturn(writer);
	// sso1CompatibilityService.dispatchRequest(params_, httpServletResponse, new Cookie[]{cookie}, "/sso2/");
	//
	//
	// Map<String, String[]> params = new HashMap<String, String[]>();
	// params.put("function", new String[]{"CheckLogin"});
	// //generare un token con doGetJwtToken
	// params.put("SSO_TOKEN", new
	// String[]{"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJpbml0TG9naW4iLCJpc3MiOiJzc28yLXNlcnZlciIsIkpTRVNTSU9OSUQiOiJXVElvX0V2U09tVlNhTzU4aDB3Rkh5XzV4Z3VjOVVvQSIsImV4cCI6MTcxMDUyMDkxMywiaWF0IjoxNzEwNTE0OTEzLCJqdGkiOiIwMWUwZGEyZi0zYTEwLTRlYjYtOWZjMS0wMzk4ZDkxMjBmNmQifQ.yHuyj4qf2DPacJzBRIYV4GjV7z3g8RJ5w46_qC-9rJ8"});
	//
	// sso1CompatibilityService.dispatchRequest(params, httpServletResponse, new Cookie[]{cookie}, "/sso2/");
	// }

	@SuppressWarnings("unchecked")
	@AfterAll
	public static void test_expiration_to_be_refreshed() {
		ssoDAO = jdbi.onDemand(Sso1DAO.class);
		sso1CompatibilityService = new TestSso1CompatibilityService(TASKAUTHSTRING, ssoDAO, userService, Algorithm.HMAC256(TASKAUTHPHRASE));
		try {
			ssoDAO.insertSessionData("username", "7EiIhe_KnMWdlXlmN3BszNjOY3KWaqhJ", OffsetDateTime.now(), OffsetDateTime.now().plus(10, ChronoUnit.MINUTES));
		} catch (Exception e) {
		}
		@SuppressWarnings("rawtypes")
		Cache sessionCache = sso1CompatibilityService.getCache();
		sessionCache.put("7EiIhe_KnMWdlXlmN3BszNjOY3KWaqhJ", new JSession("username", OffsetDateTime.now().plus(15, ChronoUnit.MINUTES)));
		sso1CompatibilityService.validateRequest("7EiIhe_KnMWdlXlmN3BszNjOY3KWaqhJ");
		JSession jSession = (JSession) sessionCache.getIfPresent("7EiIhe_KnMWdlXlmN3BszNjOY3KWaqhJ");
		assertTrue(jSession.getDt_delete().isAfter(OffsetDateTime.now().plus(20, ChronoUnit.MINUTES)));
	}

	private static class TestSso1CompatibilityService extends Sso1CompatibilityService {

		public TestSso1CompatibilityService(String taskAuthSecret, Sso1DAO sso1Dao, UserService userService, Algorithm algorithm) {
			super(taskAuthSecret, sso1Dao, userService, algorithm);
		}

		@Override
		public Cache<String, JSession> getCache() {
			return super.getCache();
		}
	}

}
