package com.abacogroup.sso.server2.resources;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.Connection;
import java.sql.DriverManager;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.sqlobject.SqlObjectPlugin;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.platform.commons.util.StringUtils;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.sso.server2.api.ApiKeyLoginRequest;
import com.abacogroup.sso.server2.api.ApiKeyRequest;
import com.abacogroup.sso.server2.api.ApiKeyResponse;
import com.abacogroup.sso.server2.core.ApiKeyService;
import com.abacogroup.sso.server2.core.UserService;
import com.abacogroup.sso.server2.core.passwords.PasswordHasherFactory;
import com.abacogroup.sso.server2.db.RefreshTokensDAO;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.abacogroup.sso.server2.db.ntt.SsoUser;
import com.abacogroup.sso.server2.exceptions.ApiKeyNotFoundException;
import com.auth0.jwt.algorithms.Algorithm;

import liquibase.Liquibase;
import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.resource.ClassLoaderResourceAccessor;

public class ApiKeyResourcesTest {
	private static Jdbi jdbi = null;
	private static Sso1DAO ssoDAO = null;
	private static ApiKeyResources resources = null;
	private static UserService userService = null;
	private static ApiKeyService apiKeyService = null;
	private static RefreshTokensDAO refreshTokensDAO = null;

	@BeforeAll
	public static void setup() throws Exception {
		String url = "jdbc:postgresql://localhost:5432/sso";
		String user = "sso";
		String password = "postgres";

		Connection cnn = DriverManager.getConnection(url, user, password);
		JdbcConnection conn = new JdbcConnection(cnn);
		Database database = DatabaseFactory.getInstance().findCorrectDatabaseImplementation(conn);

		try (Liquibase liquibase = new Liquibase("migrations.xml", new ClassLoaderResourceAccessor(), database)) {
			String ctx = null;
			liquibase.update(ctx);
		}

		jdbi = Jdbi.create(url, user, password);

		jdbi.installPlugin(new SqlObjectPlugin());
		jdbi.installPlugin(new PgJdbiPlugin());

		ssoDAO = jdbi.onDemand(Sso1DAO.class);
		refreshTokensDAO = jdbi.onDemand(RefreshTokensDAO.class);

		userService = new UserService(ssoDAO, refreshTokensDAO,
				Algorithm.HMAC256(new byte[] { 1, 2, 3, 4 }),
				new PasswordHasherFactory(""),
				false, new HashMap<>(),
				null);

		apiKeyService = new ApiKeyService(ssoDAO, userService);
		resources = new ApiKeyResources(apiKeyService);
	}

	@AfterEach
	public void clean() {
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_api_keys CASCADE"));
	}

	@Test
	public void generateApiKeyTest() {
		OffsetDateTime validFrom = OffsetDateTime.now().minus(1, ChronoUnit.MINUTES);
		OffsetDateTime validTo = OffsetDateTime.now().plus(1, ChronoUnit.MINUTES);
		ApiKeyRequest request = new ApiKeyRequest();
		request.setValidFrom(validFrom);
		request.setValidTo(validTo);
		request.setDescription(null);

		String apikey = resources.generateApiKey(new User("0001"), request);

		assertTrue(StringUtils.isNotBlank(apikey));
	}

	@Test
	public void generateApiKeyNotValidDateTest() {
		OffsetDateTime validTo = OffsetDateTime.now().minus(1, ChronoUnit.MINUTES);
		OffsetDateTime validFrom = OffsetDateTime.now().plus(1, ChronoUnit.MINUTES);
		ApiKeyRequest request = new ApiKeyRequest();
		request.setValidFrom(validFrom);
		request.setValidTo(validTo);
		request.setDescription(null);

		assertThrows(IllegalStateException.class,
				() -> resources.generateApiKey(new User("0001"), request));
	}

	@Test
	public void deleteApiKeyTest() {
		OffsetDateTime validFrom = OffsetDateTime.now().minus(1, ChronoUnit.MINUTES);
		OffsetDateTime validTo = OffsetDateTime.now().plus(1, ChronoUnit.MINUTES);
		ApiKeyRequest request = new ApiKeyRequest();
		request.setValidFrom(validFrom);
		request.setValidTo(validTo);
		request.setDescription(null);

		List<ApiKeyResponse> list = resources.getUserApiKeys(new User("0001"), false);
		int prev = list.size();

		String apikey = resources.generateApiKey(new User("0001"), request);
		assertDoesNotThrow(() -> resources.deleteApiKey(new User("0001"), apikey));

		list = resources.getUserApiKeys(new User("0001"), false);
		assertEquals(prev, list.size());
	}

	@Test
	public void getOnlyValidApiUserKeysTest() {
		OffsetDateTime validFrom = OffsetDateTime.now().minus(1, ChronoUnit.MINUTES);
		OffsetDateTime validTo = OffsetDateTime.now().plus(1, ChronoUnit.MINUTES);
		ApiKeyRequest request = new ApiKeyRequest();
		request.setValidFrom(validFrom);
		request.setValidTo(validTo);
		request.setDescription(null);

		resources.generateApiKey(new User("0001"), request);

		validFrom = OffsetDateTime.now().plus(1, ChronoUnit.MINUTES);
		validTo = OffsetDateTime.now().plus(2, ChronoUnit.MINUTES);
		request = new ApiKeyRequest();
		request.setValidFrom(validFrom);
		request.setValidTo(validTo);
		request.setDescription(null);

		resources.generateApiKey(new User("0001"), request);

		validFrom = OffsetDateTime.now().plus(1, ChronoUnit.MINUTES);
		validTo = OffsetDateTime.now().plus(2, ChronoUnit.MINUTES);
		request = new ApiKeyRequest();
		request.setValidFrom(validFrom);
		request.setValidTo(validTo);
		request.setDescription(null);

		resources.generateApiKey(new User("0002"), request);

		validFrom = OffsetDateTime.now().minus(1, ChronoUnit.MINUTES);
		validTo = OffsetDateTime.now().plus(1, ChronoUnit.MINUTES);
		request = new ApiKeyRequest();
		request.setValidFrom(validFrom);
		request.setValidTo(validTo);
		request.setDescription(null);

		resources.generateApiKey(new User("0001"), request);

		List<ApiKeyResponse> list = resources.getUserApiKeys(new User("0001"), true);
		assertEquals(2, list.size());

		list = resources.getUserApiKeys(new User("0001"), false);
		assertEquals(3, list.size());
	}

	@Test
	public void loginTest() {
		assertDoesNotThrow(() -> ssoDAO.insertUser(SsoUser.builder()
				.created_on(OffsetDateTime.now())
				.date_format("dd/MM/yyyy")
				.descr("0001")
				.fl_internal('Y')
				.is_locked('N')
				.is_parent((short) 0)
				.parent_userid(null)
				.password("X")
				.password_last_modified_on(OffsetDateTime.now().plusSeconds(1))
				.tenant_id("_")
				.userid("0001")
				.username("0001")
				.usr_locale("it")
				.build(),
				false));

		// "0001", "0001", "X", "_", false);

		/*
		 * OffsetDateTime validFrom = OffsetDateTime.of(2022, 10, 10, 10, 10, 10, 10, ZoneOffset.ofHours(0)); OffsetDateTime validTo = OffsetDateTime.of(2022,
		 * 11, 10, 10, 10, 10, 10, ZoneOffset.ofHours(0)); ApiKeyRequest request = new ApiKeyRequest(); request.setValidFrom(validFrom);
		 * request.setValidTo(validTo); request.setDescription(null);
		 *
		 * String apikey = resources.generateApiKey(new User("0001"), request);
		 *
		 * LoginResponse response = resources.apiKeyLogin(new ApiKeyLoginRequest(apikey));
		 *
		 * assertTrue(response != null && response.getErrors().isEmpty());
		 *
		 * ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso2_refresh_tokens CASCADE")); ssoDAO.withHandle(h ->
		 * h.execute("TRUNCATE TABLE sso_users CASCADE")); ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_users_log CASCADE"));
		 */

	}

	@Test
	public void loginFailedTest() {
		OffsetDateTime validFrom = OffsetDateTime.of(2022, 10, 10, 10, 10, 10, 10, ZoneOffset.ofHours(0));
		OffsetDateTime validTo = OffsetDateTime.of(2022, 11, 10, 10, 10, 10, 10, ZoneOffset.ofHours(0));
		ApiKeyRequest request = new ApiKeyRequest();
		request.setValidFrom(validFrom);
		request.setValidTo(validTo);
		request.setDescription(null);

		String apikey = resources.generateApiKey(new User("0006"), request);

		assertThrows(ApiKeyNotFoundException.class,
				() -> resources.apiKeyLogin(new ApiKeyLoginRequest(apikey)));
	}
}
