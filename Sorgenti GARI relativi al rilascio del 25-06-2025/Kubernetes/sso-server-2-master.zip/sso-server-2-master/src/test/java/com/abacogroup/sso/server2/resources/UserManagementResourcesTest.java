package com.abacogroup.sso.server2.resources;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.sqlobject.SqlObjectPlugin;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.jdbi.config.AbacoJdbiConfig;
import com.abacogroup.sso.server2.api.CreateUserRequestInternal;
import com.abacogroup.sso.server2.api.Language;
import com.abacogroup.sso.server2.api.UpdateUserRequest;
import com.abacogroup.sso.server2.api.UserData;
import com.abacogroup.sso.server2.api.UserDetails;
import com.abacogroup.sso.server2.core.UserManagementService;
import com.abacogroup.sso.server2.core.passwords.PasswordHasherFactory;
import com.abacogroup.sso.server2.db.Sso1DAO;

import liquibase.Liquibase;
import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.resource.ClassLoaderResourceAccessor;

@ExtendWith(MockitoExtension.class)
class UserManagementResourcesTest {
	private static final String DEFAULT_TENANT_ID = "master";

	private static final String USER_NAME = UUID.randomUUID().toString();
	private static final String USER_NAME_NO_PROPS = UUID.randomUUID().toString();

	public static Sso1DAO ssoDAO = null;
	public static UserManagementService userManagementService = null;
	public static Jdbi jdbi = null;
	public static UserManagementResources userManagementResources = null;

	@BeforeAll
	public static void setup() throws Exception {
		String url = "jdbc:postgresql://localhost:5432/sso";
		String user = "sso";
		String password = "postgres";

		Connection cnn = DriverManager.getConnection(url, user, password);
		JdbcConnection conn = new JdbcConnection(cnn);
		Database database = DatabaseFactory.getInstance().findCorrectDatabaseImplementation(conn);

		try (Liquibase liquibase = new Liquibase("migrations.xml", new ClassLoaderResourceAccessor(), database)) {
			String ctx = null;
			liquibase.update(ctx);
		}

		jdbi = Jdbi.create(url, user, password);

		jdbi.installPlugin(new SqlObjectPlugin());
		jdbi.installPlugin(new PgJdbiPlugin());

		jdbi.configure(AbacoJdbiConfig.class, cfg -> cfg.setTablesPrefix("sso"));

		ssoDAO = jdbi.onDemand(Sso1DAO.class);

		// inserimento tabella i18n_values
		ssoDAO.withHandle(h -> h.createUpdate("INSERT INTO sso_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)" +
				"values (:tenant_id, :table_name, :field_name, :i18n_value, :lang, :i18n_text)")
				.bind("tenant_id", DEFAULT_TENANT_ID)
				.bind("table_name", "SSO_USERS")
				.bind("field_name", "USR_LOCALE")
				.bind("i18n_value", "it")
				.bind("lang", "it")
				.bind("i18n_text", "Italiano")
				.execute());

		ssoDAO.withHandle(h -> h.createUpdate("INSERT INTO sso_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)" +
				"values (:tenant_id, :table_name, :field_name, :i18n_value, :lang, :i18n_text)")
				.bind("tenant_id", DEFAULT_TENANT_ID)
				.bind("table_name", "SSO_USERS")
				.bind("field_name", "USR_LOCALE")
				.bind("i18n_value", "it")
				.bind("lang", "en")
				.bind("i18n_text", "Italian")
				.execute());

		ssoDAO.withHandle(h -> h.createUpdate("INSERT INTO sso_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)" +
				"values (:tenant_id, :table_name, :field_name, :i18n_value, :lang, :i18n_text)")
				.bind("tenant_id", DEFAULT_TENANT_ID)
				.bind("table_name", "SSO_USERS")
				.bind("field_name", "USR_LOCALE")
				.bind("i18n_value", "fr")
				.bind("lang", "it")
				.bind("i18n_text", "Francese")
				.execute());

		ssoDAO.withHandle(h -> h.createUpdate("INSERT INTO sso_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)" +
				"values (:tenant_id, :table_name, :field_name, :i18n_value, :lang, :i18n_text)")
				.bind("tenant_id", DEFAULT_TENANT_ID)
				.bind("table_name", "SSO_USERS")
				.bind("field_name", "USR_LOCALE")
				.bind("i18n_value", "fr")
				.bind("lang", "en")
				.bind("i18n_text", "French")
				.execute());

		CreateUserRequestInternal cr = CreateUserRequestInternal.builder()
				.tenant(DEFAULT_TENANT_ID)
				.contexts(null)
				.roleNames(null)
				.userId(USER_NAME)
				.password("PASSWORD")
				.description("TEST user " + USER_NAME)
				.language("it")
				.userProperties(Map.of("città", "Mantova", "Stato", "Celibe"))
				.alignContextToRoles(true)
				.build();

		CreateUserRequestInternal crNoPro = CreateUserRequestInternal.builder()
				.tenant(DEFAULT_TENANT_ID)
				.contexts(null)
				.roleNames(null)
				.userId(USER_NAME_NO_PROPS)
				.password("PASSWORD")
				.description("TEST user " + USER_NAME_NO_PROPS)
				.language("it")
				.userProperties(Map.of())
				.dateFormat("dd/MM/yyyy")
				.alignContextToRoles(true)
				.build();				

		PasswordHasherFactory passwordHasherFactory = new PasswordHasherFactory("");

		ssoDAO.createUser(cr, "TEST", passwordHasherFactory, false);
		ssoDAO.createUser(crNoPro, "TEST", passwordHasherFactory, false);

		userManagementService = new UserManagementService(null, ssoDAO, false, null, null);

		userManagementResources = new UserManagementResources(userManagementService, null);

	}

	@Test
	void getLanguagesOfAUser_withExistingLangCode() {
		List<Language> actualLanguages = userManagementResources.getLanguages(new User(USER_NAME, DEFAULT_TENANT_ID), DEFAULT_TENANT_ID, "it");

		List<Language> expectedLanguages = new ArrayList<>();
		expectedLanguages.add(new Language("it", "Italiano"));
		expectedLanguages.add(new Language("fr", "Francese"));

		assertEquals(expectedLanguages.size(), actualLanguages.size());
		assertThat(expectedLanguages).containsExactlyInAnyOrderElementsOf(actualLanguages);
	}

	@Test 
	void updateUser_withEmptyUserProperties() {
		String description = "test description of "+USER_NAME_NO_PROPS;
		String language = "en";
		String dateFormat = "MM/dd/yyyy";

		UpdateUserRequest updateUserRequest = UpdateUserRequest.builder()
				.description(description)
				.language(language)
				.dateFormat(dateFormat)
				.flInternal('N')
				.isLocked('N')				
				.userProperties(Map.of())
				.build();

		
		assertDoesNotThrow(() -> {
			UserData userData;
			userData = userManagementResources.updatedUser(DEFAULT_TENANT_ID, USER_NAME_NO_PROPS,new User(USER_NAME_NO_PROPS, DEFAULT_TENANT_ID), updateUserRequest);
			assertEquals(description, userData.getDescription());
		});
		
		
		UserDetails userDetails = ssoDAO.getUserByUsername(DEFAULT_TENANT_ID, USER_NAME_NO_PROPS.toUpperCase());	
		assertEquals(description, userDetails.getDescription());
		assertEquals(language, userDetails.getUserLocale());
		assertEquals(dateFormat, userDetails.getDateFormat());
		Map<String,String> props = userDetails.getUserProperties();
		assertTrue(props==null || props.isEmpty());
	}

	@AfterAll
	public static void clearDB() {
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_i18n_values CASCADE"));
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_users CASCADE"));
	}

}
