package com.abacogroup.sso.server2.core.passwords.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.charset.StandardCharsets;
import java.util.List;

import org.junit.jupiter.api.Test;

public class Argon2IdPasswordHasherTest {

	private static final String ENCODED = "$argon2id$v=19$m=15360,t=2,p=1$MnFselZ6cE1nU2s0b0NqRg$6Jou00BHnpIbbvzwDu9ElQOJagWDIKVpNbNfvTZDC4k";
	private static final List<String> PARAMS = List.of(
			"v=19",
			"m=15360,t=2,p=1",
			"MnFselZ6cE1nU2s0b0NqRg");
	private static final byte[] SALT = "2qlzVzpMgSk4oCjF".getBytes(StandardCharsets.UTF_8);
	private static final String PASSWORD = "welcome";

	@Test
	public void testHashingCorrectness() {
		int t = 2;
		int p = 1;
		int m = 15 * 1024;

		Argon2IdPasswordHasher hasher = new Argon2IdPasswordHasher(m, t, p, SALT);
		assertEquals(ENCODED, hasher.computeHash(PASSWORD));
	}

	@Test
	public void testInitFromEncodedHash() {
		Argon2IdPasswordHasher hasher = new Argon2IdPasswordHasher();
		hasher.setParams(PARAMS);
		assertEquals(ENCODED, hasher.computeHash(PASSWORD));
	}

	@Test
	public void testDefaults() {
		Argon2IdPasswordHasher hasher = new Argon2IdPasswordHasher();
		String encoded = hasher.computeHash(PASSWORD);
		assertTrue(encoded.length() > 54, "Encoded hash is too short");
	}

}
