package com.abacogroup.sso.server2;

public class Run {
    public static void main(String[] args) {
        SSOServer2Application.main(new String[] { "server", "config.yml" });
    }
}
