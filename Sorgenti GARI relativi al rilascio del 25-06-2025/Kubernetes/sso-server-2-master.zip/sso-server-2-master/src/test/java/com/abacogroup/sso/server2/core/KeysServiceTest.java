package com.abacogroup.sso.server2.core;

import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;
import java.security.SecureRandom;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import com.fasterxml.jackson.databind.ObjectMapper;

public class KeysServiceTest {

	private static ObjectMapper objectMapper;

	@BeforeAll
	public static void setup() {
		objectMapper = new ObjectMapper();
		objectMapper.findAndRegisterModules();
	}

	@Test
	public void testRSAKeyPairCreation(@TempDir File pubFolder) throws IOException {
		byte[] aesSecret = new byte[32];
		new SecureRandom().nextBytes(aesSecret);

		KeysService service = new KeysService(objectMapper, pubFolder.getAbsolutePath(), aesSecret);
		boolean loaded = service.loadPublicKey(service.getPrivateKeyId());
		assertTrue(loaded);
	}

	@Test
	public void testRSAKeyPairCreationWithoutEncryption(@TempDir File pubFolder) throws IOException {
		KeysService service = new KeysService(objectMapper, pubFolder.getAbsolutePath(), null);
		boolean loaded = service.loadPublicKey(service.getPrivateKeyId());
		assertTrue(loaded);
	}

	@Test
	public void whenPublikKeysAreEncrypted_thenNonAesServiceIgnoresThem(@TempDir File pubFolder) throws IOException {
		byte[] aesSecret = new byte[32];
		new SecureRandom().nextBytes(aesSecret);

		KeysService serviceWithAes = new KeysService(objectMapper, pubFolder.getAbsolutePath(), aesSecret);
		KeysService service = new KeysService(objectMapper, pubFolder.getAbsolutePath(), null);

		assertNotNull(serviceWithAes.getPrivateKeyId());
		assertNotNull(service.getPrivateKeyId());
		assertNotEquals(serviceWithAes.getPrivateKeyId(), service.getPrivateKeyId());

		assertNull(service.getPublicKeyById(serviceWithAes.getPrivateKeyId()));
	}

	@Test
	public void whenPublikKeysAreNotEncrypted_thenAesServiceIgnoresThem(@TempDir File pubFolder) throws IOException {
		byte[] aesSecret = new byte[32];
		new SecureRandom().nextBytes(aesSecret);

		KeysService service = new KeysService(objectMapper, pubFolder.getAbsolutePath(), null);
		KeysService serviceWithAes = new KeysService(objectMapper, pubFolder.getAbsolutePath(), aesSecret);

		assertNotNull(serviceWithAes.getPrivateKeyId());
		assertNotNull(service.getPrivateKeyId());
		assertNotEquals(serviceWithAes.getPrivateKeyId(), service.getPrivateKeyId());

		assertNull(serviceWithAes.getPublicKeyById(service.getPrivateKeyId()));
	}

}
