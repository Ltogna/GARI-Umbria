package com.abacogroup.sso.server2.resources;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.spec.SecretKeySpec;
import javax.ws.rs.core.Response;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.sqlobject.SqlObjectPlugin;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.sso.server2.api.ChangePasswordRequest;
import com.abacogroup.sso.server2.api.CreateUserRequestInternal;
import com.abacogroup.sso.server2.api.TotpVerificationRequest;
import com.abacogroup.sso.server2.core.TotpService;
import com.abacogroup.sso.server2.core.UserService;
import com.abacogroup.sso.server2.core.passwords.PasswordHasherFactory;
import com.abacogroup.sso.server2.db.RefreshTokensDAO;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.auth0.jwt.algorithms.Algorithm;
import com.eatthepath.otp.TimeBasedOneTimePasswordGenerator;
import com.google.zxing.WriterException;

import liquibase.Liquibase;
import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.resource.ClassLoaderResourceAccessor;

@ExtendWith(MockitoExtension.class)
public class OtpResourcesTest {
	private static Sso1DAO ssoDAO = null;
	private static RefreshTokensDAO refreshTokensDAO = null;
	private static OtpResources otpResources = null;
	private static Jdbi jdbi = null;
	private static UserService service = null;

	@BeforeAll
	public static void setup() throws Exception {
		String url = "jdbc:postgresql://localhost:5432/sso";
		String user = "sso";
		String password = "postgres";

		Connection cnn = DriverManager.getConnection(url, user, password);
		JdbcConnection conn = new JdbcConnection(cnn);
		Database database = DatabaseFactory.getInstance().findCorrectDatabaseImplementation(conn);

		try (Liquibase liquibase = new Liquibase("migrations.xml", new ClassLoaderResourceAccessor(), database)) {
			String ctx = null;
			liquibase.update(ctx);
		}

		jdbi = Jdbi.create(url, user, password);

		jdbi.installPlugin(new SqlObjectPlugin());
		jdbi.installPlugin(new PgJdbiPlugin());

		ssoDAO = jdbi.onDemand(Sso1DAO.class);
		refreshTokensDAO = jdbi.onDemand(RefreshTokensDAO.class);

		// Inserimento ruoli
		ssoDAO.withHandle(
				h -> h.createUpdate("INSERT INTO SSO_ROLES(ROLE_ID,NAME,TENANT_ID) values (:roleId,:name,:tenant)")
						.bind("name", "DEVELOPER").bind("tenant", "_").bind("roleId", 3)
						.execute());

		ssoDAO.withHandle(
				h -> h.createUpdate("INSERT INTO SSO_ROLES(ROLE_ID,NAME,TENANT_ID) values (:roleId,:name,:tenant)")
						.bind("name", "GUEST").bind("tenant", "_").bind("roleId", 2)
						.execute());

		ssoDAO.withHandle(
				h -> h.createUpdate("INSERT INTO SSO_ROLES(ROLE_ID,NAME,TENANT_ID) values (:roleId,:name,:tenant)")
						.bind("name", "SUPERUSER").bind("tenant", "_").bind("roleId", 1)
						.execute());

		// Inserimento contexts
		ssoDAO.withHandle(h -> h.createUpdate("INSERT INTO SSO_CONTESTI(CONTEXTID) values (:contextid)")
				.bind("contextid", "TEST-CONTEXT-1").execute());

		ssoDAO.withHandle(h -> h.createUpdate("INSERT INTO SSO_CONTESTI(CONTEXTID) values (:contextid)")
				.bind("contextid", "TEST-CONTEXT-2").execute());

		ssoDAO.withHandle(h -> h.createUpdate("INSERT INTO SSO_CONTESTI(CONTEXTID) values (:contextid)")
				.bind("contextid", "TEST-CONTEXT-3").execute());

		// Inserimento sso contexts functions
		ssoDAO.withHandle(
				h -> h.createUpdate(
						"INSERT INTO SSO_CONTEXT_FUNCTIONS(FUNCTION_ID,CONTEXT_ID,NAME) values (:functionId,:contextId,:name)")
						.bind("functionId", 1).bind("contextId", "TEST-CONTEXT-1").bind("name", "FUNZIONE1")
						.execute());

		ssoDAO.withHandle(
				h -> h.createUpdate(
						"INSERT INTO SSO_CONTEXT_FUNCTIONS(FUNCTION_ID,CONTEXT_ID,NAME) values (:functionId,:contextId,:name)")
						.bind("functionId", 2).bind("contextId", "TEST-CONTEXT-2").bind("name", "FUNZIONE2")
						.execute());

		ssoDAO.withHandle(
				h -> h.createUpdate(
						"INSERT INTO SSO_CONTEXT_FUNCTIONS(FUNCTION_ID,CONTEXT_ID,NAME) values (:functionId,:contextId,:name)")
						.bind("functionId", 3).bind("contextId", "TEST-CONTEXT-3").bind("name", "FUNZIONE3")
						.execute());

		// Inserimento sso roles functions
		ssoDAO.withHandle(
				h -> h.createUpdate(
						"INSERT INTO SSO_ROLES_FUNCTIONS(ROLE_ID,FUNCTION_ID) values (:roleId,:functionId)")
						.bind("roleId", 1).bind("functionId", 1)
						.execute());

		ssoDAO.withHandle(
				h -> h.createUpdate(
						"INSERT INTO SSO_ROLES_FUNCTIONS(ROLE_ID,FUNCTION_ID) values (:roleId,:functionId)")
						.bind("roleId", 2).bind("functionId", 2)
						.execute());

		ssoDAO.withHandle(
				h -> h.createUpdate(
						"INSERT INTO SSO_ROLES_FUNCTIONS(ROLE_ID,FUNCTION_ID) values (:roleId,:functionId)")
						.bind("roleId", 3).bind("functionId", 3)
						.execute());

		Map<String, String> ssoParams = new HashMap<>();
		ssoParams.put("MAX_LOGIN_FAILURES", "5");
		ssoParams.put("PASSWORD_VALIDITY", "20");
		ssoParams.put("SSO_EXPIRE_WARNING_1", "2");

		PasswordHasherFactory hasherFactory = new PasswordHasherFactory("");

		service = new UserService(ssoDAO, refreshTokensDAO,
				Algorithm.HMAC256(new byte[] { 1, 2, 3, 4 }),
				hasherFactory,
				false, new HashMap<>(),
				null);

		String issuer = "totp-issuer";
		TotpService totpService = new TotpService(issuer, 30);

		otpResources = new OtpResources(service, totpService);

		List<String> roleNames = new ArrayList<String>();
		roleNames.add("DEVELOPER");
		roleNames.add("GUEST");

		List<String> contexts = new ArrayList<String>();
		contexts.add("TEST-CONTEXT-1");

		CreateUserRequestInternal cr = CreateUserRequestInternal.builder()
				.contexts(contexts).roleNames(roleNames)
				.userId("0001")
				.password("PASSWORD")
				.description("TEST user 0001")
				.language("en")
				.userProperties(Map.of("città", "Mantova", "Stato", "Celibe"))
				.alignContextToRoles(true).build();

		ssoDAO.createUser(cr, "TEST", hasherFactory, false);

		roleNames.clear();
		roleNames.add("DEVELOPER");
		roleNames.add("SUPERUSER");

		contexts.clear();
		contexts.add("TEST-CONTEXT-2");

		cr = CreateUserRequestInternal.builder().contexts(contexts)
				.roleNames(roleNames)
				.userId("0002")
				.description("TEST user 0002")
				.password("PASSWORD")
				.language("en")
				.userProperties(Map.of("città", "Verona", "Stato", "Vedovo"))
				.alignContextToRoles(true).build();

		ssoDAO.createUser(cr, "TEST", hasherFactory, false);

		roleNames.clear();
		roleNames.add("SUPERUSER");

		contexts.clear();
		contexts.add("TEST-CONTEXT-3");

		cr = CreateUserRequestInternal.builder().contexts(contexts)
				.roleNames(roleNames).userId("0003").description("TEST user 0003")
				.password("PASSWORD").userProperties(Map.of("città", "Padova",
						"Stato", "Sposato"))
				.alignContextToRoles(true).build();

		ssoDAO.createUser(cr, "TEST", hasherFactory, false);

		ChangePasswordRequest pwdRequest = new ChangePasswordRequest();
		pwdRequest.setNewPassword("Paperino");
		pwdRequest.setOldPassword("PASSWORD");

		service.changePassword("0001", pwdRequest, true);
		service.changePassword("0002", pwdRequest, true);
		service.changePassword("0003", pwdRequest, true);

		// Inserimento sso user_roles
		/*
		 * var now = OffsetDateTime.now();
		 *
		 * ssoDAO.withHandle(h -> h.createUpdate( "INSERT INTO SSO_USER_ROLES(ROLE_ID,USERID,DATA_INIZIO_VAL) values (:roleId,:userId,:date)" ) .bind("roleId",
		 * 1).bind("userId", "0001").bind("date", now).execute());
		 *
		 * ssoDAO.withHandle(h -> h.createUpdate( "INSERT INTO SSO_USER_ROLES(ROLE_ID,USERID,DATA_INIZIO_VAL) values (:roleId,:userId,CURRENT_TIMESTAMP)" )
		 * .bind("roleId", 2).bind("userId", "0002").execute());
		 *
		 * ssoDAO.withHandle(h -> h.createUpdate( "INSERT INTO SSO_USER_ROLES(ROLE_ID,USERID,DATA_INIZIO_VAL) values (:roleId,:userId,CURRENT_TIMESTAMP)" )
		 * .bind("roleId", 3).bind("userId", "0003").execute());
		 */

		/*
		 * ssoDAO.addRole("0001", 1); // ssoDAO.addRole("0001", 1); ssoDAO.addRole("0002", 2); ssoDAO.addRole("0003", 3);
		 */
	}

	@AfterAll
	public static void clearDB() {
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE no_password_roules CASCADE"));
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE spid_sso_users_log CASCADE"));
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso2_refresh_tokens CASCADE"));
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_contesti CASCADE"));
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_context_functions CASCADE"));
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_old_passwords CASCADE"));
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_parameters CASCADE"));
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_roles CASCADE"));
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_roles_functions CASCADE"));
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_user_roles CASCADE"));
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_user_roles_history CASCADE"));
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_users CASCADE"));
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_users_log CASCADE"));
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_users_properties CASCADE"));
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_utenti_contesti CASCADE"));

	}

	private String getActualTotpCode(String secret) throws InvalidKeyException {
		TimeBasedOneTimePasswordGenerator totp = new TimeBasedOneTimePasswordGenerator();
		Instant time = Instant.now();
		byte[] secretBytes = secret.getBytes();
		SecretKeySpec secretKeySpec = new SecretKeySpec(secretBytes, "HmacSHA1");
		return totp.generateOneTimePasswordString(secretKeySpec, time);
	}

	@Test
	public void checkAuthenticationOtp() throws InvalidKeyException {

		TotpVerificationRequest request = new TotpVerificationRequest();
		String code = getActualTotpCode("secretaaaa");

		// assertEquals(code, "339387");

		request.setCode(code);

		System.out.print("totp code: " + code);

		List<String> roleNames = new ArrayList<String>();
		roleNames.add("DEVELOPER");
		roleNames.add("GUEST");
		List<String> contexts = new ArrayList<String>();
		contexts.add("TEST-CONTEXT-4");

		CreateUserRequestInternal cr = CreateUserRequestInternal.builder()
				.contexts(contexts)
				.roleNames(roleNames)
				.userId("0004")
				.description("TEST user 0004")
				.password("PASSWORD")
				.userProperties(Map.of("città", "Mantova", "Stato", "Celibe"))
				.username("user_id")
				.tenant("tenant_prova")
				.twoFactorAuthKey("secretaaaa")
				.alignContextToRoles(true).build();

		ssoDAO.withHandle(
				h -> h.createUpdate("INSERT INTO SSO_ROLES(ROLE_ID,NAME,TENANT_ID) values (:roleId,:name,:tenant)")
						.bind("name", "DEVELOPER").bind("tenant", "tenant_prova").bind("roleId", 4)
						.execute());

		ssoDAO.withHandle(
				h -> h.createUpdate("INSERT INTO SSO_ROLES(ROLE_ID,NAME,TENANT_ID) values (:roleId,:name,:tenant)")
						.bind("name", "GUEST").bind("tenant", "tenant_prova").bind("roleId", 5)
						.execute());

		ssoDAO.createUser(cr, "TEST", new PasswordHasherFactory(""), false);

		Response response = otpResources.whoAmI(new User("user_id", "tenant_prova"), "tenant_prova", request);
		assertEquals(response.getStatus(), 204);
	}

	private void saveInputStreamToFile(InputStream inputStream, String fileName) {
		try (FileOutputStream outputStream = new FileOutputStream(fileName)) {
			byte[] buffer = new byte[1024];
			int bytesRead;
			while ((bytesRead = inputStream.read(buffer)) != -1) {
				outputStream.write(buffer, 0, bytesRead);
			}
		} catch (IOException e) {
		}
	}

	@Test
	public void checkQRCodeOtp() throws InvalidKeyException, WriterException, IOException {

		List<String> roleNames = new ArrayList<String>();
		roleNames.add("DEVELOPER");
		roleNames.add("GUEST");
		List<String> contexts = new ArrayList<String>();
		contexts.add("TEST-CONTEXT-4");

		Response response = otpResources.whoAmIQrCode(new User("user_id", "tenant_prova"), "tenant_prova");
		assertEquals(response.getStatus(), 200);

		byte[] imageBytes = (byte[]) response.getEntity();
		InputStream targetStream = new ByteArrayInputStream(imageBytes);
		saveInputStreamToFile(targetStream, "downloadedImage.png");
	}

}
