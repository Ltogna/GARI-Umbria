package com.abacogroup.sso.server2.core.bundle;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.sqlobject.SqlObjectPlugin;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.jdbi.config.AbacoJdbiConfig;
import com.abacogroup.sso.server2.api.Language;
import com.abacogroup.sso.server2.core.bundle.model.I18nLang;
import com.abacogroup.sso.server2.core.bundle.model.LanguagesConfigMessage;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.fasterxml.jackson.databind.ObjectMapper;

import liquibase.Liquibase;
import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.resource.ClassLoaderResourceAccessor;

@ExtendWith(MockitoExtension.class)
class Sso2LanguageMessageProcessorTest {
	public static Sso1DAO ssoDAO = null;
	public static Jdbi jdbi = null;
	public static Sso2LanguageMessageProcessor languageMessageProcessor = null;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		String url = "jdbc:postgresql://localhost:5432/sso";
		String user = "sso";
		String password = "postgres";

		Connection cnn = DriverManager.getConnection(url, user, password);
		JdbcConnection conn = new JdbcConnection(cnn);
		Database database = DatabaseFactory.getInstance().findCorrectDatabaseImplementation(conn);

		try (Liquibase liquibase = new Liquibase("migrations.xml", new ClassLoaderResourceAccessor(), database)) {
			String ctx = null;
			liquibase.update(ctx);
		}

		jdbi = Jdbi.create(url, user, password);

		jdbi.installPlugin(new SqlObjectPlugin());
		jdbi.installPlugin(new PgJdbiPlugin());

		jdbi.configure(AbacoJdbiConfig.class, cfg -> cfg.setTablesPrefix("sso"));

		ssoDAO = jdbi.onDemand(Sso1DAO.class);

		ssoDAO.withHandle(h -> h.createUpdate("INSERT INTO sso_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)" +
				"values (:tenant_id, :table_name, :field_name, :i18n_value, :lang, :i18n_text)")
				.bind("tenant_id", "master")
				.bind("table_name", "SSO_USERS")
				.bind("field_name", "USR_LOCALE")
				.bind("i18n_value", "it")
				.bind("lang", "it")
				.bind("i18n_text", "Italiano")
				.execute());

		ssoDAO.withHandle(h -> h.createUpdate("INSERT INTO sso_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)" +
				"values (:tenant_id, :table_name, :field_name, :i18n_value, :lang, :i18n_text)")
				.bind("tenant_id", "master")
				.bind("table_name", "SSO_USERS")
				.bind("field_name", "USR_LOCALE")
				.bind("i18n_value", "it")
				.bind("lang", "en")
				.bind("i18n_text", "Italian")
				.execute());

		ssoDAO.withHandle(h -> h.createUpdate("INSERT INTO sso_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)" +
				"values (:tenant_id, :table_name, :field_name, :i18n_value, :lang, :i18n_text)")
				.bind("tenant_id", "master")
				.bind("table_name", "SSO_USERS")
				.bind("field_name", "USR_LOCALE")
				.bind("i18n_value", "fr")
				.bind("lang", "it")
				.bind("i18n_text", "Francese")
				.execute());

		ssoDAO.withHandle(h -> h.createUpdate("INSERT INTO sso_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)" +
				"values (:tenant_id, :table_name, :field_name, :i18n_value, :lang, :i18n_text)")
				.bind("tenant_id", "master")
				.bind("table_name", "SSO_USERS")
				.bind("field_name", "USR_LOCALE")
				.bind("i18n_value", "fr")
				.bind("lang", "en")
				.bind("i18n_text", "French")
				.execute());

		languageMessageProcessor = new Sso2LanguageMessageProcessor(null, ssoDAO, new ObjectMapper());
	}

	@Test
	void doInsertOrUpdate_InsertingNewLanguage() {
		List<I18nLang> traduzione = new ArrayList<>();

		traduzione.add(new I18nLang("it", "Indonesiano"));
		traduzione.add(new I18nLang("en", "Indonesian"));

		Map<String, List<I18nLang>> languagesToAdd = new HashMap<>();

		languagesToAdd.put("id", traduzione);

		languageMessageProcessor.doInsertOrUpdate("master", new LanguagesConfigMessage(languagesToAdd));

		assertEquals(false, ssoDAO.getLanguages("master", "id").isEmpty());
	}

	@Test
	void doInsertOrUpdate_UpdateExistingLanguage() {
		Map<String, List<I18nLang>> languagesToAdd = new HashMap<>();
		List<I18nLang> traduzione = new ArrayList<>();

		traduzione.add(new I18nLang("en", "French"));
		languagesToAdd.put("fr", traduzione);
		languageMessageProcessor.doInsertOrUpdate("master", new LanguagesConfigMessage(languagesToAdd));
		assertThat(ssoDAO.getLanguages("master", "it")).containsExactly(new Language("fr", "French"));

		traduzione.clear();
		traduzione.add(new I18nLang("it", "Francese"));
		traduzione.add(new I18nLang("en", "French"));
		traduzione.add(new I18nLang("id", "????"));
		languagesToAdd.put("fr", traduzione);
		languageMessageProcessor.doInsertOrUpdate("master", new LanguagesConfigMessage(languagesToAdd));
		assertThat(ssoDAO.getLanguages("master", "it")).containsExactly(new Language("fr", "Francese"));
	}

	@AfterAll
	public static void clearDB() {
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_i18n_values CASCADE"));
		ssoDAO.withHandle(h -> h.execute("TRUNCATE TABLE sso_users CASCADE"));
	}
}
