package com.abacogroup.sso.server2.core;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.abacogroup.sso.server2.core.passwords.PasswordHasherFactory;
import com.abacogroup.sso.server2.db.RefreshTokensDAO;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.auth0.jwt.algorithms.Algorithm;

public class UserServiceTest {

	private Sso1DAO ssoUsersDAO;
	private RefreshTokensDAO refreshTokensDAO;
	private UserService userService;

	@BeforeEach
	public void beforeEach() {
		ssoUsersDAO = mock(Sso1DAO.class);
		refreshTokensDAO = mock(RefreshTokensDAO.class);

		userService = new UserService(ssoUsersDAO, refreshTokensDAO, Algorithm.HMAC256("supersecret".getBytes()),
				new PasswordHasherFactory(""),
				false, new HashMap<>(),
				() -> null);
	}

	@Test
	public void whenGetUsersDescriptionWithMnayUsers_thanSplitDbCallsInChunks() {
		List<String> list = IntStream.range(1, 2000)
				.mapToObj(i -> "user" + i)
				.collect(Collectors.toList());

		userService.getUsersDescription("_", list);

		verify(ssoUsersDAO, times(3)).findSsoUsers(anyString(), any());
	}

}
