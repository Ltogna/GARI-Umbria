package com.abacogroup.sso.server2.db;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transaction;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.sso.server2.db.ntt.SsoContextFunctionEntity;
import com.abacogroup.sso.server2.db.ntt.SsoRoleFunctionCodesEntity;
import com.abacogroup.sso.server2.db.ntt.SsoRolesEntity;

public interface ConfigDAO extends Transactional<ConfigDAO> {

	// Tenants

	@Transaction
	default void copyTenant(String fromTenantId, String toTenantId) {
		useHandle(h -> {
			h.createUpdate("""
					INSERT INTO sso_contesti (contextid, descr, tenant_id)
					 select contextid, descr, :toTenantId
					   from sso_contesti c
					  where c.tenant_id = :fromTenantId
					    and not exists (select 1 from sso_contesti sc2
					                    where sc2.tenant_id = :toTenantId
					                      and sc2.contextid = c.contextid)
					""")
					.bind("fromTenantId", fromTenantId)
					.bind("toTenantId", toTenantId)
					.execute();

			h.createUpdate("""
					INSERT INTO sso_context_functions (function_id, context_id, name, descr, tenant_id)
					 select §nextval(SSO_CONTEXT_FUNCTIONS_SEQ)§, context_id, name, descr, :toTenantId
					   from sso_context_functions c
					  where c.tenant_id = :fromTenantId
					    and not exists (select 1 from sso_context_functions sc2
					                    where sc2.tenant_id = :toTenantId
					                      and sc2.context_id = c.context_id
					                      and sc2.name = c.name)
					""")
					.bind("fromTenantId", fromTenantId)
					.bind("toTenantId", toTenantId)
					.execute();

			h.createUpdate("""
					INSERT INTO sso_roles (role_id, tenant_id, name, descr)
					 select §nextval(SSO_ROLES_SEQ)§, :toTenantId, name, descr
					   from sso_roles c
					  where c.tenant_id = :fromTenantId
					""")
					.bind("fromTenantId", fromTenantId)
					.bind("toTenantId", toTenantId)
					.execute();

			h.createUpdate("""
					DELETE FROM sso_i18n_values
					 WHERE tenant_id = :toTenantId
					""")
					.bind("toTenantId", toTenantId)
					.execute();

			h.createUpdate("""
					INSERT INTO sso_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
						 select :toTenantId, 'SSO_USERS', 'USR_LOCALE', i18n_value, lang, i18n_text
						   from sso_i18n_values s
						  where s.tenant_id = :fromTenantId
						""")
					.bind("fromTenantId", fromTenantId)
					.bind("toTenantId", toTenantId)
					.execute();
		});

		List<SsoRolesEntity> rolesToCopy = getAllSsoRole(fromTenantId);

		SsoRolesEntity toRole;
		List<SsoRoleFunctionCodesEntity> functions;
		for (SsoRolesEntity fromRole : rolesToCopy) {
			toRole = getSsoRole(toTenantId, fromRole.getName());
			functions = getRoleFunctionCodes(fromRole.getRoleId());
			for (SsoRoleFunctionCodesEntity function : functions) {
				insertRoleFunction(toRole.getRoleId(), toTenantId, function.getContextId(), function.getFunctionCode());
			}
		}
	}

	// Contexts

	@SqlQuery("select contextid from sso_contesti WHERE tenant_id = :tenantId")
	List<String> getAllContextIds(@Bind("tenantId") String tenantId);

	@SqlUpdate("INSERT INTO SSO_CONTESTI (CONTEXTID, DESCR, TENANT_ID) VALUES (:contextId, :contextId, :tenantId)")
	void insertContext(@Bind("tenantId") String tenantId, @Bind("contextId") String contextId);

	// Context functions

	@SqlQuery("""
			SELECT FUNCTION_ID, CONTEXT_ID, NAME, DESCR, TENANT_ID FROM SSO_CONTEXT_FUNCTIONS
					 WHERE TENANT_ID = :tenantId and CONTEXT_ID=:contextId and NAME=:name""")

	@RegisterBeanMapper(SsoContextFunctionEntity.class)
	SsoContextFunctionEntity getSsoContextFunction(@Bind("tenantId") String tenantId, @Bind("contextId") String contextId, @Bind("name") String name);

	@SqlQuery("§select_nextval(SSO_CONTEXT_FUNCTIONS_SEQ)§")
	Long nextSsoContextFunctionId();

	@SqlUpdate("INSERT INTO SSO_CONTEXT_FUNCTIONS (FUNCTION_ID, CONTEXT_ID, NAME, DESCR, TENANT_ID) VALUES (:functionId, :contextId, :name, :descr, :tenantId)")
	void insertContextFunction(@BindBean SsoContextFunctionEntity ntt);

	@SqlUpdate("UPDATE SSO_CONTEXT_FUNCTIONS SET DESCR=:descr where FUNCTION_ID = :functionId")
	void updateContextFunction(@Bind("functionId") Long functionId, @Bind("descr") String newDescription);

	@Transaction
	default void deleteFunction(String tenantId, String contextId, String name) {
		SsoContextFunctionEntity func = getSsoContextFunction(tenantId, contextId, name);
		if (func == null) {
			return;
		}

		useHandle(h -> {
			h.createUpdate("delete from sso_roles_functions where function_id = :functionId")
					.bind("functionId", func.getFunctionId())
					.execute();

			h.createUpdate("delete from sso_context_functions where function_id = :functionId")
					.bind("functionId", func.getFunctionId())
					.execute();
		});
	}

	// Roles

	@SqlQuery("SELECT ROLE_ID, TENANT_ID, NAME, DESCR FROM SSO_ROLES where TENANT_ID = :tenantId and NAME = :name")
	@RegisterBeanMapper(SsoRolesEntity.class)
	SsoRolesEntity getSsoRole(@Bind("tenantId") String tenantId, @Bind("name") String name);

	@SqlQuery("SELECT ROLE_ID, TENANT_ID, NAME, DESCR FROM SSO_ROLES where TENANT_ID = :tenantId")
	@RegisterBeanMapper(SsoRolesEntity.class)
	List<SsoRolesEntity> getAllSsoRole(@Bind("tenantId") String tenantId);

	@SqlQuery("§select_nextval(SSO_ROLES_SEQ)§")
	Long nextSsoRoleId();

	@SqlUpdate("INSERT INTO SSO_ROLES (ROLE_ID, TENANT_ID, NAME, DESCR) VALUES (:roleId, :tenantId, :name, :descr)")
	void insertRole(@BindBean SsoRolesEntity ntt);

	@SqlUpdate("UPDATE SSO_ROLES SET DESCR=:descr where ROLE_ID = :roleId")
	void updateRole(@Bind("roleId") Long roleId, @Bind("descr") String newDescription);

	// Roles functions

	@SqlUpdate("delete from SSO_ROLES_FUNCTIONS where role_id = :roleId")
	void deleteAllFunctionsForRole(@Bind("roleId") Long roleId);

	@SqlUpdate("""
			insert into sso_roles_functions (ROLE_ID, FUNCTION_ID)
			 select :roleId, function_id
			   from sso_context_functions
			  where tenant_id = :tenantId
			    and context_id = :contextId
			    and name = :functionCode""")
	void insertRoleFunction(@Bind("roleId") Long roleId, @Bind("tenantId") String tenantId, @Bind("contextId") String contextId,
			@Bind("functionCode") String functionCode);

	@SqlQuery("""
			SELECT scf.FUNCTION_ID, scf.CONTEXT_ID, scf.NAME AS function_code
			  FROM SSO_ROLES_FUNCTIONS srf
			       INNER JOIN SSO_CONTEXT_FUNCTIONS scf ON scf.FUNCTION_ID =srf.FUNCTION_ID
			 WHERE srf.ROLE_ID = :roleId
			 ORDER BY scf.CONTEXT_ID, scf.NAME""")
	@RegisterBeanMapper(SsoRoleFunctionCodesEntity.class)
	List<SsoRoleFunctionCodesEntity> getRoleFunctionCodes(@Bind("roleId") Long roleId);

	default void deleteRole(String tenantId, String code) {
		SsoRolesEntity role = getSsoRole(tenantId, code);
		if (role == null) {
			return;
		}

		useHandle(h -> {
			h.createUpdate("delete from sso_user_roles where role_id = :roleId")
					.bind("roleId", role.getRoleId())
					.execute();

			h.createUpdate("delete from sso_roles_functions where role_id = :roleId")
					.bind("roleId", role.getRoleId())
					.execute();

			h.createUpdate("delete from sso_roles where role_id = :roleId")
					.bind("roleId", role.getRoleId())
					.execute();
		});
	}

	@SqlUpdate("delete from SSO_ROLES_FUNCTIONS where role_id = :roleId and function_id = :functionId")
	void deleteRoleFunction(@Bind("roleId") Long roleId, @Bind("functionId") Long functionId);

}
