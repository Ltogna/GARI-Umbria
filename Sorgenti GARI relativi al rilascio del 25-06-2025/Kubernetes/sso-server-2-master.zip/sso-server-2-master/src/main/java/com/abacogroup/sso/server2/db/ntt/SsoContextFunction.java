package com.abacogroup.sso.server2.db.ntt;

import lombok.Data;
import org.jdbi.v3.core.mapper.reflect.ColumnName;

@Data
public class SsoContextFunction
{
	Long id;
	String contextId;
	String name;
	String description;
	String tenantId;

	@ColumnName("function_id")
	public Long getId()
	{
		return id;
	}

	@ColumnName("context_id")
	public String getContextId()
	{
		return contextId;
	}

	@ColumnName("descr")
	public String getDescription()
	{
		return description;
	}

	@ColumnName("tenant_id")
	public String getTenantId()
	{
		return tenantId;
	}
}
