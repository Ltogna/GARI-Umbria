package com.abacogroup.sso.server2.db.ntt;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SsoContextFunctionEntity {
	private Long functionId;
	private String contextId;
	private String name;
	private String descr;
	private String tenantId;
}
