package com.abacogroup.sso.server2.api;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import com.abacogroup.dropwizard.auth.sso2.UserFunction;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class FunctionRequest {
	@NotEmpty
	@Schema(description = "The role name")
	String roleName;

	@Schema(description = "The functions to add")
	List<UserFunction> functions;
}
