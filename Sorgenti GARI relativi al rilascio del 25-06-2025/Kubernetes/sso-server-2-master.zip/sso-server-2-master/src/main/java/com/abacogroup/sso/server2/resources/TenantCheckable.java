package com.abacogroup.sso.server2.resources;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.sso.server2.exceptions.TenantMismatchException;

public interface TenantCheckable {
	default void checkTenant(String tenantId, User user) {
		if (StringUtils.isBlank(tenantId) || StringUtils.isBlank(user.getTenant()) || !tenantId.equalsIgnoreCase(user.getTenant())) {
			throw new TenantMismatchException(
					"Tenant: '" + tenantId + "' is not equals to user tenant: '" + user.getTenant() + "'");
		}
	}
}
