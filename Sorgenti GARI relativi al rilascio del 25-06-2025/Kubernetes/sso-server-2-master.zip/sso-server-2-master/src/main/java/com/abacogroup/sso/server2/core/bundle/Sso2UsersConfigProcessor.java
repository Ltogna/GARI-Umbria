package com.abacogroup.sso.server2.core.bundle;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.sso.server2.api.CreateUserRequest;
import com.abacogroup.sso.server2.api.UserDetails;
import com.abacogroup.sso.server2.core.ApiKeyService;
import com.abacogroup.sso.server2.core.bundle.model.ApiKeyDefinition;
import com.abacogroup.sso.server2.core.bundle.model.UserDefinition;
import com.abacogroup.sso.server2.core.bundle.model.UserProperties;
import com.abacogroup.sso.server2.core.bundle.model.UserRole;
import com.abacogroup.sso.server2.core.bundle.model.UsersConfigMessage;
import com.abacogroup.sso.server2.core.passwords.PasswordHasherFactory;
import com.abacogroup.sso.server2.db.ConfigDAO;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.abacogroup.sso.server2.db.ntt.SsoUser;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Sso2UsersConfigProcessor extends AbstractConfigProcessor {

	private static final Logger log = LoggerFactory.getLogger(Sso2UsersConfigProcessor.class);

	private static final String WHO_AM_I = "BUNDLE";

	private final Sso1DAO ssoDAO;
	private final ApiKeyService apiKeyService;
	private final PasswordHasherFactory hasherFactory;

	public Sso2UsersConfigProcessor(ConfigDAO configDAO, Sso1DAO ssoDAO, ApiKeyService apiKeyService, PasswordHasherFactory hasherFactory,
			ObjectMapper objectMapper) {
		super(configDAO, objectMapper);
		this.ssoDAO = ssoDAO;
		this.apiKeyService = apiKeyService;
		this.hasherFactory = hasherFactory;
	}

	@Override
	public String getDomainName() {
		return "users";
	}

	@Override
	public void onMessageInTransaction(ConfigDAO dao, ConfigDataMessage message) {
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> file.getAbsolutePath().endsWith(".json"))
				.forEach(file -> processFile(message.getTenantId(), file));
	}

	private void processFile(String tenantId, File file) {
		UsersConfigMessage message;
		try {
			message = objectMapper.readValue(file, UsersConfigMessage.class);
		} catch (IOException e) {
			throw new IllegalStateException("Error processing file " + file.getName() + " for tenant " + tenantId, e);
		}

		if (file.getAbsolutePath().endsWith(".delete.json")) {
			if (message.getUsers() != null) {
				throw new UnsupportedOperationException("Users deletion is not allowed");
			}
			if (message.getApiKeys() != null) {
				throw new UnsupportedOperationException("Api keys deletion is not allowed");
			}

			doDeleteUserRoles(tenantId, message.getUserRoles());
		} else {
			doInsertOrUpdate(tenantId, message);
		}
	}

	void doDeleteUserRoles(String tenantId, List<UserRole> userRoles) {
		if (userRoles == null || userRoles.isEmpty()) {
			return;
		}

		for (UserRole current : userRoles) {
			Optional<SsoUser> opt = ssoDAO.getSsoUser(tenantId, current.getUsername());
			if (opt.isEmpty()) {
				log.warn("Unknown username {} in tenant {}", current.getUsername(), tenantId);
				continue;
			}

			SsoUser currentUser = opt.get();
			ssoDAO.deleteUserRoles(current.getRoleCodes(), currentUser.getUserid(), tenantId, WHO_AM_I);
		}

	}

	// visible for testing
	void doInsertOrUpdate(String tenantId, UsersConfigMessage message) {
		if (message == null) {
			return;
		}

		insertOrUpdateUsers(tenantId, message.getUsers());
		insertOrUpdateUserProperties(tenantId, message.getProperties());
		insertOrUpdateUserRoles(tenantId, message.getUserRoles());
		insertApiKeys(tenantId, message.getApiKeys());
	}

	private void insertOrUpdateUserProperties(String tenantId, List<UserProperties> properties) {
		if (properties == null) {
			return;
		}

		for (UserProperties p : properties) {
			Map<String, String> propertiesMap = p.getProperties();
			if (properties == null) {
				throw new IllegalArgumentException("properties are null for user: " + p.getUserName());
			}

			UserDetails user = ssoDAO.getUserByUsername(tenantId, p.getUserName().toUpperCase());
			ssoDAO.deleteAllUserProperties(user.getUserId());
			ssoDAO.addUserProperties(propertiesMap, user.getUserId());
		}
	}

	private void insertApiKeys(String tenantId, List<ApiKeyDefinition> apiKeys) {
		if (apiKeys == null || apiKeys.isEmpty()) {
			return;
		}

		for (ApiKeyDefinition k : apiKeys) {

			UserDetails user = ssoDAO.getUserByUsername(tenantId, k.getUserName().toUpperCase());
			if (user == null) {
				throw new IllegalStateException("user " + k.getUserName() + " not found in tenant " + tenantId);
			}

			apiKeyService.createApiKey(k.getValidFrom(), k.getValidTo(), k.getDescription(), user.getUserId());
		}
	}

	private void insertOrUpdateUsers(String tenantId, List<UserDefinition> users) {
		if (users == null || users.isEmpty()) {
			return;
		}

		for (UserDefinition currentUser : users) {
			Optional<SsoUser> ntt = ssoDAO.getSsoUser(tenantId, currentUser.getUsername());
			String userId;
			if (ntt.isEmpty()) {
				userId = CreateUserRequest.createUserId(tenantId, currentUser.getUsername());
				String encoded = encodePassword(currentUser.getPassword());
				OffsetDateTime now = ssoDAO.getSysdate();
				ssoDAO.insertUser(SsoUser.builder()
						.created_on(now)
						.date_format(currentUser.getDateFormat())
						.descr(currentUser.getDescr())
						.fl_internal('Y')
						.is_locked('N')
						.is_parent((short) 0)
						.parent_userid(null)
						.password(encoded)
						.password_last_modified_on(currentUser.isForceChangePassword() ? now : now.plusSeconds(1))
						.tenant_id(tenantId)
						.userid(userId)
						.username(currentUser.getUsername().toUpperCase())
						.usr_locale(currentUser.getLocale())
						.two_factor_auth_key(currentUser.getSecret())
						.build(),
						false);
			} else {
				userId = ntt.get().getUserid();
				ssoDAO.updateUser(userId, currentUser.getDescr(), currentUser.getDateFormat(), currentUser.getLocale());
			}
		}

	}

	private String encodePassword(String password) {
		if ("$random$".equals(password)) {
			password = UUID.randomUUID().toString();
		}

		return hasherFactory.getDefault().encodePassword(password);
	}

	private void insertOrUpdateUserRoles(String tenantId, List<UserRole> userRoles) {
		if (userRoles == null || userRoles.isEmpty()) {
			return;
		}

		for (UserRole current : userRoles) {
			Optional<SsoUser> opt = ssoDAO.getSsoUser(tenantId, current.getUsername());
			if (opt.isEmpty()) {
				log.warn("Unknown username {} in tenant {}", current.getUsername(), tenantId);
				continue;
			}

			SsoUser currentUser = opt.get();
			ssoDAO.addUserRoles(current.getRoleCodes(), currentUser.getUserid(), tenantId, WHO_AM_I, false);
		}
	}

}
