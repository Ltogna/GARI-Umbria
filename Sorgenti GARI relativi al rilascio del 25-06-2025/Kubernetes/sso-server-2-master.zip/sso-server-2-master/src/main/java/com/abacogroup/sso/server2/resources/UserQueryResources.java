package com.abacogroup.sso.server2.resources;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.sso.server2.api.UserData;
import com.abacogroup.sso.server2.core.UserService;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@Timed
@Path("{tenant}/public/v1")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Tenant aware APIs", description = "API that works on tenants")
public class UserQueryResources implements TenantCheckable {

	private UserService userService;

	public UserQueryResources(UserService userService) {
		this.userService = userService;
	}

	@GET
	@Path("/users/{userName}")
	@Operation(description = "Query minimum user data to check if a user exists and get it's user id")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "The user object", content = { @Content(schema = @Schema(anyOf = { UserData.class })) }),
			@ApiResponse(responseCode = "404", description = "The user was not found")
	})
	public @NotNull UserData getUserData(
			@PathParam("tenant") String tenantId,
			@PathParam("userName") String userName,
			@Parameter(hidden = true) @Auth User user) {
		checkTenant(tenantId, user);
		return userService.getUser(tenantId, userName)
				.map(ssoUser -> UserData.builder()
						.description(ssoUser.getDescr())
						.tenant(ssoUser.getTenant_id())
						.userId(ssoUser.getUserid())
						.userName(ssoUser.getUsername())
						.build())
				.orElseThrow(NotFoundException::new);
	}

	@POST
	@Path("/users-description")
	@Operation(description = "Get the user IDs for a set of user names in a tenant")
	public @NotNull Map<String, String> getUsersDescription(@PathParam("tenant") String tenantId,
			@Parameter(hidden = true) @Auth User user,
			@NotNull @Size(max = 2000) List<String> userNames) {
		checkTenant(tenantId, user);

		userNames.removeIf(userName -> userName == null);

		if (userNames.size() == 0) {
			return new HashMap<>(0);
		}

		return userService.getUsersDescription(tenantId, userNames);
	}

}
