package com.abacogroup.sso.server2.api;

import java.time.OffsetDateTime;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ApiKeyResponse {
	@Schema(description = "The API key")
	private String apiKey;

	@Schema(description = "Valid from")
	private OffsetDateTime validFrom;

	@Schema(description = "Valid to")
	private OffsetDateTime validTo;

	@Schema(description = "The description of the API key")
	private String description;
}
