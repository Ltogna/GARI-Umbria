package com.abacogroup.sso.server2.core.saml.config;

public interface ContactPersonConfig {
	String getEmail();

	String getVatNumber();

	String getPhoneNumber();

	boolean isPublic();
}
