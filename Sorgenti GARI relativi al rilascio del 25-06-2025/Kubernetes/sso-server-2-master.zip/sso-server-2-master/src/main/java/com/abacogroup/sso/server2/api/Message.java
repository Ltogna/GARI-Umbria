package com.abacogroup.sso.server2.api;

import java.util.ArrayList;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class Message {
	@Schema(description = "The message key")
	private String key;

	@Schema(description = "The message")
	private List<String> values;

	public Message(String key) {
		this.key = key;
		this.values = new ArrayList<>(0);
	}

	public Message(String key, List<String> values) {
		this.key = key;
		this.values = values;
	}
}
