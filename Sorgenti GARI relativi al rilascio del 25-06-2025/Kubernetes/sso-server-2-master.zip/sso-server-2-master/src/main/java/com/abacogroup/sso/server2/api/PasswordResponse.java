package com.abacogroup.sso.server2.api;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PasswordResponse {
	@Schema(description = "On success, this is true")
	private boolean ok;

	@Schema(description = "Any errors")
	private List<Message> errors;

	public enum Messages {
		ERROR_OLD_PASSWORD_MUST_BE_DIFFERENT_FROM_NEW_ONE("sso2.old_password_must_differ_from_new_one"),
		ERROR_WRONG_OLD_PASSWORD("sso2.wrong-old-password"),
		PASSWORD_MUST_CONTAIN_UPPERCASE_LETTERS("sso2.pwd_must_contain_uppercase_letter"),
		PASSWORD_MUST_CONTAIN_LOWERCASE_LETTERS("sso2.pwd_must_contain_lowercase_letter"),
		PASSWORD_MUST_CONTAIN_LETTERS("sso2.pwd_must_contain_letters"),
		PASSWORD_MUST_CONTAIN_DIGITS("sso2.pwd_must_contain_digits"),
		PASSWORD_MUST_CONTAIN_SYMBOLS("sso2.pwd_must_contain_symbols"),
		PASSWORD_IS_TOO_SHORT("sso2.pwd_too_short"),
		PASSWORD_IS_TOO_LONG("sso2.pwd_too_long");

		private String key;

		Messages(String key) {
			this.key = key;
		}

		public String key() {
			return key;
		}
	}

}
