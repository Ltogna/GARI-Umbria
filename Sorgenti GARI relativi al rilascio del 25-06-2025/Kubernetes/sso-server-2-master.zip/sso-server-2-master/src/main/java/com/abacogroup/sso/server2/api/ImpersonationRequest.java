package com.abacogroup.sso.server2.api;

import javax.validation.constraints.NotEmpty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class ImpersonationRequest {

	@NotEmpty
	@Schema(description = "The user ID")
	private String userid;

}
