package com.abacogroup.sso.server2.core;

import static com.abacogroup.sso.server2.db.Sso1DAO.DEFAULT_TENANT;
import static com.abacogroup.sso.util.SSOConstants.RES_ERR;
import static com.abacogroup.sso.util.SSOConstants.RES_OK;
import static java.time.temporal.ChronoUnit.MINUTES;
import static java.util.stream.Collectors.joining;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.jdbi.v3.core.statement.OutParameters;

import com.abacogroup.dropwizard.auth.sso2.Constants;
import com.abacogroup.sso.server2.core.entities.dbgis.TimeSeKillNtt;
import com.abacogroup.sso.server2.core.model.Function;
import com.abacogroup.sso.server2.core.model.JSession;
import com.abacogroup.sso.server2.core.model.LoginStatus;
import com.abacogroup.sso.server2.core.model.Role;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.abacogroup.sso.server2.db.ntt.SsoUser;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Sso1CompatibilityService {

	private static final String DUMMY_USER = "$";

	private JWTVerifier verifierInitLogin;
	private JWTVerifier verifierSSOToken;
	private JWTVerifier verifierJ2;
	private Sso1DAO sso1Dao;
	private UserService userService;
	private static final SecureRandom secureRandom = new SecureRandom();
	private static final Base64.Encoder base64Encoder = Base64.getUrlEncoder().withoutPadding();
	private Algorithm algorithm;
	private Algorithm initLoginAlgorithm;
	private static float PROTOCOL_VERSION = 5.0f;

	private static final String COOKIE_LOGIN = "X-INIT_LOGIN";
	private static final String JSESSIONID = "JSESSIONID";
	private static final String JSESSIONID_CLAIM = "_sid";
	private static final String AUDIENCE_INIT_LOGIN = "initLogin";
	private static final String AUDIENCE_SSO_TOKEN = "SSO_TOKEN";
	private static final String ISSUER = "sso2-server";
	private static final int RECORD_AGE = 30;
	private final static String SSO_TOKEN = "SSO_TOKEN";

	private final Cache<String, JSession> sessionCache;

	protected Cache<String, JSession> getCache() {
		return sessionCache;
	}

	public Sso1CompatibilityService(String taskAuthSecret, Sso1DAO sso1Dao, UserService userService,
			Algorithm algorithm) {
		this.sso1Dao = sso1Dao;
		this.initLoginAlgorithm = Algorithm.HMAC256(taskAuthSecret);
		this.userService = userService;
		this.algorithm = algorithm;

		verifierInitLogin = JWT.require(Algorithm.HMAC256(taskAuthSecret))
				.acceptLeeway(5)
				.withAudience(AUDIENCE_INIT_LOGIN)
				.withIssuer(ISSUER)
				.build();

		verifierSSOToken = JWT.require(algorithm)
				.acceptLeeway(5)
				.withAudience(AUDIENCE_SSO_TOKEN)
				.build();

		verifierJ2 = JWT.require(algorithm)
				.withIssuer(Constants.ISSUER)
				.acceptLeeway(Constants.DEFAULT_LEEWAY)
				.build();

		sessionCache = Caffeine.newBuilder()
				.expireAfterAccess(10, TimeUnit.MINUTES)
				.maximumSize(20_000)
				.build();
	}

	public void dispatchRequest(Map<String, String[]> params, HttpServletResponse response, Cookie[] cookies,
			String contextPath)
			throws IOException, NoSuchAlgorithmException {
		try {
			String[] pfunction = params.get("function");
			if (pfunction == null) {
				throw new RuntimeException("Mandatory parameter 'function' not supplied!");
			}

			String function = pfunction[0];

			log.debug("Function is {}", function);

			if (function.equalsIgnoreCase("initLogin")) {
				doInitLogin(response, contextPath);
			} else if (function.equalsIgnoreCase("Login")) {
				doLogin(params, response, cookies, contextPath);
			} else if (function.equalsIgnoreCase("Logout")) {
				doLogout(params, response, cookies, contextPath);
			} else if (function.equalsIgnoreCase("GetJwtToken")) {
				doGetJwtToken(params, response, cookies, contextPath);
			} else if (function.equalsIgnoreCase("GetToken")) {
				doGetJwtToken(params, response, cookies, contextPath);
			} else if (function.equalsIgnoreCase("Ping")) {
				ping(response);
			} else if (function.equalsIgnoreCase("getProtocolVersion")) {
				doGetProtocolVersion(response);
			} else if (function.equalsIgnoreCase("WhoAmI")) {
				doWhoAmI(response, cookies);
			} else if (function.equalsIgnoreCase("CheckLogin")) {
				doCheckLogin(params, response, cookies, contextPath);
			} else if (function.equalsIgnoreCase("IsFunctionEnabledForUser")) {
				isFunctionEnabledForUser(params, response, cookies);
			} else if (function.equalsIgnoreCase("HasCompetenceOnSoftware")) {
				doHasCompetenceOnSoftware(params, response, cookies);
			} else if (function.equalsIgnoreCase("HasCompetenceOnSoftwareCuaa")) {
				doHasCompetenceOnSoftwareCuaa(params, response, cookies);
			} else if (function.equalsIgnoreCase("HasCompetenceOnModule")) {
				doHasCompetenceOnModule(params, response, cookies);
			} else if (function.equalsIgnoreCase("HasCompetenceOnModuleCuaa")) {
				doHasCompetenceOnModuleCuaa(params, response, cookies);
			} else if (function.equalsIgnoreCase("HasCompetence")) {
				doHasCompetence(params, response, cookies);
			} else if (function.equalsIgnoreCase("HasCompetenceCuaa")) {
				doHasCompetenceCuaa(params, response, cookies);
			} else if (function.equalsIgnoreCase("GetUser")) {
				doGetUser(params, response, cookies);
			} else if (function.equalsIgnoreCase("GetUserRoles")) {
				doGetUserRoles(response, cookies);
			} else if (function.equalsIgnoreCase("GetUserFunctions")) {
				doGetUserFunctions(response, cookies);
			} else if (function.equalsIgnoreCase("IsControllore")) {
				doIsControllore(response, cookies);
			} else if (function.equalsIgnoreCase("IsGestore")) {
				doIsGestore(response, cookies);
			} else if (function.equalsIgnoreCase("GetLift")) {
				doGetLift(params, response, cookies);
			} else if (function.equalsIgnoreCase("GetDbgisSecret")) {
				doGetDbgisSecret(params, response, cookies);
			} else {
				log.warn("invalid method {}", function);
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public void doInitLogin(HttpServletResponse response, String contextPath) throws IOException {
		String jSessionId = initializeSession(DUMMY_USER, false);

		String initIdToken = JWT.create()
				.withIssuer(ISSUER)
				.withAudience(AUDIENCE_INIT_LOGIN)
				.withIssuedAt(new Date())
				.withExpiresAt(new Date(System.currentTimeMillis() + 1000 * 60))
				.withJWTId(jSessionId)
				.sign(initLoginAlgorithm);

		Cookie initLoginCookie = new Cookie(COOKIE_LOGIN, initIdToken);
		initLoginCookie.setMaxAge(120);
		initLoginCookie.setPath(contextPath);
		initLoginCookie.setHttpOnly(true);
		response.addCookie(initLoginCookie);

		Cookie jSessionIdCookie = new Cookie(JSESSIONID, jSessionId);
		jSessionIdCookie.setMaxAge(30 * 60);
		jSessionIdCookie.setPath(contextPath);
		jSessionIdCookie.setHttpOnly(true);
		response.addCookie(jSessionIdCookie);

		respondOK(response, Arrays.asList(initIdToken, jSessionId));
	}

	private LoginStatus canILoginInternal(String username, String jsonToken, String ssoMd5) {
		return sso1Dao.callCanILogin(username, jsonToken, ssoMd5);
	}

	private Pair<Boolean, String> checkLogin(String ssoMd5, String username, String jsonToken) {
		LoginStatus loginStatus = canILoginInternal(username, jsonToken, ssoMd5);
		String message = null;

		if (loginStatus.getStatus().equals(0)) {
			return Pair.of(true, message);
		}

		if (loginStatus.getErrors() != null) {
			message = "sso.error." + loginStatus.getErrors().toString();
			return Pair.of(false, message);
		}

		if (loginStatus.getWarnings() != null && loginStatus.getWarnings().intValue() == 0) {
			return Pair.of(true, message);
		}

		message = "sso.warning." + loginStatus.getWarnings().toString();
		if (loginStatus.getWarnings() != null
				&& (loginStatus.getWarnings().intValue() == 1 || loginStatus.getWarnings().intValue() == 2)) {
			return Pair.of(false, message);
		}

		return Pair.of(true, message);
	}

	private static String generateNewJsessionId() {
		byte[] randomBytes = new byte[24];
		secureRandom.nextBytes(randomBytes);
		return base64Encoder.encodeToString(randomBytes);
	}

	private boolean expirationToBeRefreshed(OffsetDateTime endDate) {
		double minutes = Math.ceil(MINUTES.between(OffsetDateTime.now(), endDate));
		if (minutes < (RECORD_AGE - (20 * RECORD_AGE / 100))) {
			return true;
		}
		return false;
	}

	public boolean validateRequest(String jSessionToken) {
		JSession sessionData = sessionCache.getIfPresent(jSessionToken);
		if (sessionData != null) {
			OffsetDateTime endDate = sessionData.getDt_delete();
			if (expirationToBeRefreshed(endDate)) {
				OffsetDateTime newExpirationTime = OffsetDateTime.now().plus(RECORD_AGE, MINUTES);
				sessionData.setDt_delete(newExpirationTime);
				sso1Dao.updateSessionData(newExpirationTime, jSessionToken);
			}
			return true;
		}

		OffsetDateTime expirationTime = sso1Dao.getSessionExpirationDate(jSessionToken);
		if (expirationTime == null) {
			return false;
		}

		OffsetDateTime currentDate = OffsetDateTime.now();
		if (expirationTime.isBefore(currentDate)) {
			log.debug("Deleting jSessionId {}", jSessionToken);
			sso1Dao.deleteSessionData(jSessionToken);
			return false;
		}

		String userId = sso1Dao.getUserIdFromJsessionId(jSessionToken);
		if (expirationToBeRefreshed(expirationTime)) {
			expirationTime = OffsetDateTime.now().plus(RECORD_AGE, MINUTES);
			sso1Dao.updateSessionData(expirationTime, jSessionToken);
		}

		sessionCache.put(jSessionToken, new JSession(userId, expirationTime));

		return true;
	}

	private String getJsessionId(Cookie[] cookies) {
		for (Cookie cookie : cookies) {
			log.debug("Got cookie {} with value {}", cookie.getName(), cookie.getValue());
			if (cookie.getName().equals(JSESSIONID)) {
				return cookie.getValue();
			}
		}
		return null;
	}

	private void doLogin(Map<String, String[]> params, HttpServletResponse response, Cookie[] cookies,
			String contextPath)
			throws IOException, NoSuchAlgorithmException {

		if (!(params.containsKey("username") && params.containsKey("ssoMD5"))) {
			throw new RuntimeException("username and ssoMD5 not passed to request parameters");
		}
		String userName = params.get("username")[0];
		String ssoMD5 = params.get("ssoMD5")[0];

		if (userName.isEmpty()) {
			throw new RuntimeException("Username is mandatory");
		}

		String tokenJwt = null;
		String jSessionId = null;
		boolean receivedInitLoginCookie = false;
		for (Cookie cookie : cookies) {
			log.debug("Got cookie {} with value {}", cookie.getName(), cookie.getValue());
			if (cookie.getName().equals(COOKIE_LOGIN)) {
				tokenJwt = cookie.getValue();
				DecodedJWT jwt = this.verifierInitLogin.verify(tokenJwt);
				jSessionId = jwt.getId();
				receivedInitLoginCookie = true;
				break;
			}
		}

		if (!receivedInitLoginCookie) {
			respondKO(response);
			log.debug("Cookie {} was not sent", COOKIE_LOGIN);
			return;
		}

		Optional<SsoUser> optionalUser = userService.getUser(DEFAULT_TENANT, userName);

		Pair<Boolean, String> checkLogin = checkLogin(ssoMD5, userName, tokenJwt);

		// genero il token random e lo metto sia nel cookie che nella risposta
		if (optionalUser.isPresent() && checkLogin.getKey()) {
			String userId = optionalUser.get().getUserid();
			updateSessionUser(jSessionId, userId);

			Cookie initLoginCookie = new Cookie(COOKIE_LOGIN, "x");
			initLoginCookie.setMaxAge(1);
			initLoginCookie.setPath(contextPath);
			initLoginCookie.setHttpOnly(true);
			response.addCookie(initLoginCookie);

			respondOK(response, Arrays.asList(jSessionId));
		} else {
			respondKO(response, checkLogin.getValue());
		}
	}

	private void doLogout(Map<String, String[]> params, HttpServletResponse response, Cookie[] cookies,
			String contextPath) throws IOException {
		String jSessionId = getJsessionId(cookies);
		if (jSessionId == null) {
			respondKO(response, "No JSESSIONID specified");
			return;
		}

		sso1Dao.updateSessionData(jSessionId, null, OffsetDateTime.now().minusSeconds(1));
		respondOK(response);
	}

	private void respondKO(PrintWriter out, String message) {
		out.println(RES_ERR);
		out.println(message);
		out.flush();
	}

	private void respondKO(PrintWriter out) {
		respondKO(out, "Generic error");
	}

	private void respondKO(HttpServletResponse response, String message) throws IOException {
		PrintWriter out = response.getWriter();
		respondKO(out, message);
	}

	private void respondKO(HttpServletResponse response) throws IOException {
		respondKO(response, "Generic Error");
	}

	private void respondOK(PrintWriter out, List<String> message) {
		out.println(RES_OK);
		out.println(message.stream().collect(Collectors.joining("\n")));
		out.flush();
	}

	private void respondOK(PrintWriter out) {
		out.println(RES_OK);
		out.flush();
	}

	private void respondOK(HttpServletResponse response) throws IOException {
		respondOK(response.getWriter());
	}

	private void respondOK(HttpServletResponse response, List<String> message) throws IOException {
		respondOK(response.getWriter(), message);
	}

	private void updateSessionUser(String jSessionId, String userId) {
		var endDate = OffsetDateTime.now().plus(RECORD_AGE, MINUTES);
		sso1Dao.updateSessionData(jSessionId, userId, endDate);
		JSession jSession = new JSession(userId, endDate);
		sessionCache.put(jSessionId, jSession);
	}

	private String initializeSession(String userId) {
		return initializeSession(userId, true);
	}

	private String initializeSession(String userId, boolean storeAlsoInMemory) {
		String jSessionId = generateNewJsessionId();

		OffsetDateTime endDate = OffsetDateTime.now().plus(RECORD_AGE, MINUTES);
		sso1Dao.insertSessionData(userId, jSessionId, OffsetDateTime.now(), endDate);

		if (storeAlsoInMemory) {
			JSession jSession = new JSession(userId, endDate);
			sessionCache.put(jSessionId, jSession);
		}

		return jSessionId;
	}

	private void doGetJwtToken(Map<String, String[]> params, HttpServletResponse response, Cookie[] cookies,
			String contextPath) throws IOException {
		String jSessionId = getJsessionId(cookies);
		if (!validateRequest(jSessionId)) {
			respondKO(response);
			return;
		}

		JSession jSession = sessionCache.getIfPresent(jSessionId);
		assert jSession != null : "validateRequest ensures that jSession is in cache when returniong true";

		String jwtToken = JWT.create()
				.withIssuer(ISSUER)
				.withAudience(AUDIENCE_SSO_TOKEN)
				.withIssuedAt(new Date())
				.withClaim(JSESSIONID_CLAIM, jSessionId)
				.withSubject(jSession.getUserId())
				.withExpiresAt(new Date(System.currentTimeMillis() + 1000 * 60 * 2))
				.sign(algorithm);

		respondOK(response, Arrays.asList(jwtToken));
	}

	private void ping(HttpServletResponse response) throws IOException {
		respondOK(response);
	}

	private void doGetProtocolVersion(HttpServletResponse response) throws IOException {
		respondOK(response, Arrays.asList(PROTOCOL_VERSION + ""));
	}

	private void doWhoAmI(HttpServletResponse response, Cookie[] cookies) throws IOException {
		String jSessionId = getJsessionId(cookies);
		if (jSessionId == null) {
			respondKO(response);
			return;
		}
		respondOK(response, Arrays.asList(sso1Dao.getUserIdFromJsessionId(jSessionId)));
	}

	private void doCheckLogin(Map<String, String[]> params, HttpServletResponse response, Cookie[] cookies,
			String contextPath) throws IOException {
		if (params.containsKey(SSO_TOKEN)) {
			doCheckLoginWithSsoToken(params, response, contextPath);
			return;
		}

		PrintWriter out = response.getWriter();
		String jSessionIdCookie = getJsessionId(cookies);
		if (jSessionIdCookie != null) {
			if (validateRequest(jSessionIdCookie)) {
				respondOK(response, Arrays.asList(jSessionIdCookie));
				return;
			}
		}

		respondKO(out);
	}

	private void doCheckLoginWithSsoToken(Map<String, String[]> params, HttpServletResponse response,
			String contextPath) throws IOException {
		String reqToken = params.get(SSO_TOKEN)[0];
		String jSessionId = "";
		if (reqToken.startsWith("j2_")) {
			DecodedJWT jwt = verifierJ2.verify(reqToken.replace("j2_", ""));
			jSessionId = initializeSession(jwt.getSubject());
		} else {
			DecodedJWT jwt = verifierSSOToken.verify(reqToken);
			jSessionId = jwt.getClaims().get(JSESSIONID_CLAIM).asString();
			if (!validateRequest(jSessionId)) {
				// If the session in expired ,we create a new one, because the SSO_TOKEN is
				// valid anyway.
				jSessionId = initializeSession(jwt.getSubject());
			}
		}

		respondOK(response, Arrays.asList(jSessionId));
	}

	private void isFunctionEnabledForUser(Map<String, String[]> params, HttpServletResponse response, Cookie[] cookies)
			throws IOException {
		PrintWriter out = response.getWriter();
		String jSessionIdCookie = getJsessionId(cookies);
		if (!validateRequest(jSessionIdCookie)) {
			respondKO(out);
			return;
		}

		// validate ensures that the chage is updated
		JSession jSession = sessionCache.getIfPresent(jSessionIdCookie);

		String userId = jSession.getUserId();
		if (!(params.containsKey("contextId") && params.containsKey("functionName"))) {
			throw new RuntimeException("contextId and functionName not passed to request parameters");
		}
		String contextId = params.get("contextId")[0];
		String functionName = params.get("functionName")[0];
		List<Function> functions = sso1Dao.getFunction(contextId, functionName);
		if (functions.size() > 1) {
			throw new RuntimeException(String.format("More than one %s in the same context", functionName));
		}
		Function function = functions.get(0);
		Integer functionId = function.getFunctionId();
		List<Function> functionEnabled = sso1Dao.getFunctionsEnabled(functionId, userId);
		boolean enabled = !functionEnabled.isEmpty();
		if (enabled) {
			respondOK(response, Arrays.asList(Boolean.toString(enabled)));
		} else {
			respondKO(out);
		}
	}
	
	private void doHasCompetenceOnSoftware(Map<String, String[]> params, HttpServletResponse response, Cookie[] cookies) throws IOException {
		PrintWriter out = response.getWriter();
		String jSessionIdCookie = getJsessionId(cookies);
		if (!validateRequest(jSessionIdCookie)) {
			respondKO(out);
			return;
		}

		// validate ensures that the chage is updated
		JSession jSession = sessionCache.getIfPresent(jSessionIdCookie);

		String userId = jSession.getUserId();
		if (!(params.containsKey("software"))) {
			throw new RuntimeException("software not passed to request parameters");
		}
		String software = params.get("software")[0];
		
		boolean enabled = sso1Dao.hasCompetenceOnSoftware(userId, software);
		if (enabled) {
			respondOK(response, Arrays.asList(Boolean.toString(enabled)));
		} else {
			respondKO(out);
		}
	}

	private void doHasCompetenceOnSoftwareCuaa(Map<String, String[]> params, HttpServletResponse response, Cookie[] cookies) throws IOException {
		PrintWriter out = response.getWriter();
		String jSessionIdCookie = getJsessionId(cookies);
		if (!validateRequest(jSessionIdCookie)) {
			respondKO(out);
			return;
		}

		// validate ensures that the chage is updated
		JSession jSession = sessionCache.getIfPresent(jSessionIdCookie);

		String userId = jSession.getUserId();
		if (!(params.containsKey("software") && params.containsKey("pkcuaa"))) {
			throw new RuntimeException("software and pkcuaa not passed to request parameters");
		}
		String software = params.get("software")[0];
		String pkcuaa = params.get("pkcuaa")[0];
		String ignoraGestore = params.containsKey("ignora_gestore") ? params.get("ignora_gestore")[0] : null;
		
		boolean enabled = sso1Dao.hasCompetenceOnSoftwareCuaa(userId, software, pkcuaa, ignoraGestore);
		if (enabled) {
			respondOK(response, Arrays.asList(Boolean.toString(enabled)));
		} else {
			respondKO(out);
		}
	}

	private void doHasCompetenceOnModule(Map<String, String[]> params, HttpServletResponse response, Cookie[] cookies) throws IOException {
		PrintWriter out = response.getWriter();
		String jSessionIdCookie = getJsessionId(cookies);
		if (!validateRequest(jSessionIdCookie)) {
			respondKO(out);
			return;
		}

		// validate ensures that the chage is updated
		JSession jSession = sessionCache.getIfPresent(jSessionIdCookie);

		String userId = jSession.getUserId();
		if (!(params.containsKey("software") && params.containsKey("module"))) {
			throw new RuntimeException("software and module not passed to request parameters");
		}
		String software = params.get("software")[0];
		String module = params.get("module")[0];
		
		boolean enabled = sso1Dao.hasCompetenceOnModule(userId, software, module);
		if (enabled) {
			respondOK(response, Arrays.asList(Boolean.toString(enabled)));
		} else {
			respondKO(out);
		}
	}

	private void doHasCompetenceOnModuleCuaa(Map<String, String[]> params, HttpServletResponse response, Cookie[] cookies) throws IOException {
		PrintWriter out = response.getWriter();
		String jSessionIdCookie = getJsessionId(cookies);
		if (!validateRequest(jSessionIdCookie)) {
			respondKO(out);
			return;
		}

		// validate ensures that the chage is updated
		JSession jSession = sessionCache.getIfPresent(jSessionIdCookie);

		String userId = jSession.getUserId();
		if (!(params.containsKey("software") && params.containsKey("module") && params.containsKey("pkcuaa"))) {
			throw new RuntimeException("software and module and pkcuaa not passed to request parameters");
		}
		String software = params.get("software")[0];
		String module = params.get("module")[0];
		String pkcuaa = params.get("pkcuaa")[0];
		String ignoraGestore = params.containsKey("ignora_gestore") ? params.get("ignora_gestore")[0] : null;
		
		boolean enabled = sso1Dao.hasCompetenceOnModuleCuaa(userId, software, module, pkcuaa, ignoraGestore);
		if (enabled) {
			respondOK(response, Arrays.asList(Boolean.toString(enabled)));
		} else {
			respondKO(out);
		}
	}

	private void doHasCompetence(Map<String, String[]> params, HttpServletResponse response, Cookie[] cookies) throws IOException {
		PrintWriter out = response.getWriter();
		String jSessionIdCookie = getJsessionId(cookies);
		if (!validateRequest(jSessionIdCookie)) {
			respondKO(out);
			return;
		}

		// validate ensures that the chage is updated
		JSession jSession = sessionCache.getIfPresent(jSessionIdCookie);

		String userId = jSession.getUserId();
		if (!(params.containsKey("id") && params.containsKey("ambito") && params.containsKey("cod_competenza"))) {
			throw new RuntimeException("id and ambito and cod_competenza not passed to request parameters");
		}
		String id = params.get("id")[0];
		String ambito = params.get("ambito")[0];
		String codCompetenza = params.get("cod_competenza")[0];
		String ignoraGestore = params.containsKey("ignora_gestore") ? params.get("ignora_gestore")[0] : null;
		
		boolean enabled = sso1Dao.hasCompetence(userId, id, ambito, codCompetenza, ignoraGestore);
		if (enabled) {
			respondOK(response, Arrays.asList(Boolean.toString(enabled)));
		} else {
			respondKO(out);
		}
	}

	private void doHasCompetenceCuaa(Map<String, String[]> params, HttpServletResponse response, Cookie[] cookies) throws IOException {
		PrintWriter out = response.getWriter();
		String jSessionIdCookie = getJsessionId(cookies);
		if (!validateRequest(jSessionIdCookie)) {
			respondKO(out);
			return;
		}

		// validate ensures that the chage is updated
		JSession jSession = sessionCache.getIfPresent(jSessionIdCookie);

		String userId = jSession.getUserId();
		if (!(params.containsKey("id") && params.containsKey("pkcuaa") && params.containsKey("cod_competenza"))) {
			throw new RuntimeException("id and pkcuaa and cod_competenza not passed to request parameters");
		}
		String id = params.get("id")[0];
		String pkcuaa = params.get("pkcuaa")[0];
		String codCompetenza = params.get("cod_competenza")[0];
		String ignoraGestore = params.containsKey("ignora_gestore") ? params.get("ignora_gestore")[0] : null;
		
		boolean enabled = sso1Dao.hasCompetenceCuaa(userId, id, pkcuaa, codCompetenza, ignoraGestore);
		if (enabled) {
			respondOK(response, Arrays.asList(Boolean.toString(enabled)));
		} else {
			respondKO(out);
		}
	}
	
	private void doGetUser(Map<String, String[]> params, HttpServletResponse response, Cookie[] cookies)
			throws IOException {
		PrintWriter out = response.getWriter();
		String jSessionIdCookie = getJsessionId(cookies);
		if (!validateRequest(jSessionIdCookie)) {
			respondKO(out);
			return;
		}

		String[] userName = params.get("userName");
		if (userName == null) {
			throw new RuntimeException("Mandatory parameter 'userName' not supplied!");
		}

		Optional<SsoUser> optionalUser = userService.getUser(DEFAULT_TENANT, userName[0]);
		if (optionalUser.isEmpty()) {
			log.warn("User " + userName + "not found");
			respondKO(out);
			return;
		}

		SsoUser user = optionalUser.get();
		StringBuffer msg = new StringBuffer();
		msg.append(user.getUserid()).append("|").append(user.getUsr_locale()).append("|").append(user.getDate_format())
				.append("|").append(user.getDescr() != null ? user.getDescr() : " ");
		respondOK(response, Arrays.asList(msg.toString()));
	}

	private void doGetUserRoles(HttpServletResponse response, Cookie[] cookies) throws IOException {
		PrintWriter out = response.getWriter();
		String jSessionIdCookie = getJsessionId(cookies);
		if (!validateRequest(jSessionIdCookie)) {
			respondKO(out);
			return;
		}

		// validate ensures that the chage is updated
		JSession jSession = sessionCache.getIfPresent(jSessionIdCookie);

		String userId = jSession.getUserId();
		List<Role> roles = sso1Dao.getSsoRoles(userId);
		respondOK(response, Arrays.asList(roles.stream().map(Role::toString).collect(joining("\n"))));
	}

	private void doGetUserFunctions(HttpServletResponse response, Cookie[] cookies) throws IOException {
		String jSessionIdCookie = getJsessionId(cookies);
		if (!validateRequest(jSessionIdCookie)) {
			respondKO(response);
			return;
		}

		// validate ensures that the chage is updated
		JSession jSession = sessionCache.getIfPresent(jSessionIdCookie);

		String userId = jSession.getUserId();
		List<Function> functions = sso1Dao.getUserFunctions(userId);
		respondOK(response, Arrays.asList(functions.stream().map(Function::toString).collect(joining("\n"))));
	}

	private void doIsControllore(HttpServletResponse response, Cookie[] cookies) throws IOException {
		String jSessionIdCookie = getJsessionId(cookies);
		if (!validateRequest(jSessionIdCookie)) {
			respondKO(response);
			return;
		}

		// validate ensures that the chage is updated
		JSession jSession = sessionCache.getIfPresent(jSessionIdCookie);

		String userId = jSession.getUserId();
		boolean isController = sso1Dao.isController(userId);

		if (userId != null) {
			respondOK(response, Arrays.asList(Boolean.toString(isController)));
		} else {
			respondKO(response);
		}
	}

	private void doIsGestore(HttpServletResponse response, Cookie[] cookies) throws IOException {
		String jSessionIdCookie = getJsessionId(cookies);
		if (!validateRequest(jSessionIdCookie)) {
			respondKO(response);
			return;
		}

		// validate ensures that the chage is updated
		JSession jSession = sessionCache.getIfPresent(jSessionIdCookie);

		String userId = jSession.getUserId();

		Boolean isGestore = sso1Dao.inTransaction(transactionHandle -> {
			OutParameters functions = sso1Dao.isGestore(userId);
			boolean isGestoreResult;
			try {
				isGestoreResult = functions.getInt("IS_GURL_ADMIN") > 0;
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}
			return isGestoreResult;
		});

		if (userId != null && isGestore != null) {
			respondOK(response, Arrays.asList(Boolean.toString(isGestore)));
		} else {
			respondKO(response);
		}
	}

	private String encryptAesCbc(String plaintext, String key)
			throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
		Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");

		SecretKeySpec secretKeySpec = new SecretKeySpec(key.getBytes(), "AES");

		cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivParameterSpec);
		byte[] encryptedBytes = cipher.doFinal(plaintext.getBytes());
		return Base64.getEncoder().encodeToString(encryptedBytes);
	}

	private void doGetLift(Map<String, String[]> params, HttpServletResponse response, Cookie[] cookies)
			throws IOException, InvalidAlgorithmParameterException,
			NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, BadPaddingException,
			InvalidKeyException {
		String jSessionIdCookie = getJsessionId(cookies);
		if (!validateRequest(jSessionIdCookie)) {
			respondKO(response);
			return;
		}

		// validate ensures that the chage is updated
		JSession jSession = sessionCache.getIfPresent(jSessionIdCookie);

		String userId = jSession.getUserId();
		sso1Dao.openLift(userId);

		String lift = sso1Dao.getLift(userId);

		if (lift != null && !lift.isEmpty()) {
			if (params.containsKey("val")) {
				String val = params.get("val")[0];
				if (!StringUtils.isBlank(val)) {
					if (val.length() > 16) {
						val = val.substring(0, 16);
					} else if (val.length() < 16) {
						val = StringUtils.rightPad(val, 16, "0");
					}

					lift = encryptAesCbc(lift, val);
				}
			}

			respondOK(response, Arrays.asList(lift));
		} else {
			respondKO(response);
		}
	}

	private void doGetDbgisSecret(Map<String, String[]> params, HttpServletResponse response, Cookie[] cookies)
			throws IOException {
		String jSessionIdCookie = getJsessionId(cookies);
		if (!validateRequest(jSessionIdCookie)) {
			respondKO(response);
			return;
		}

		// validate ensures that the chage is updated
		JSession jSession = sessionCache.getIfPresent(jSessionIdCookie);

		String userId = jSession.getUserId();

		String dbgisUrl = params.get("dbgis_url")[0];
		if (!dbgisUrl.endsWith("/")) {
			dbgisUrl += "/";
		}
		dbgisUrl += "time?sekill=1";

		Client dbgisclient = ClientBuilder.newClient();
		try (Response resp = dbgisclient.target(dbgisUrl).request(MediaType.APPLICATION_JSON, MediaType.TEXT_HTML)
				.get()) {
			if (resp.getStatus() != 200) {
				throw new RuntimeException(
						String.format("Error in calling url: %s. Server responded with code %d and status %s", dbgisUrl,
								resp.getStatus(),
								resp.getStatusInfo().getReasonPhrase()));
			}

			TimeSeKillNtt timeSeKill = resp.readEntity(TimeSeKillNtt.class);

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
			LocalDateTime dateTime = LocalDateTime.parse(timeSeKill.getUtime(), formatter);

			String dbgisSecret = sso1Dao.getDbgisSecret(userId, timeSeKill.getServer_id(), dateTime);

			respondOK(response, Arrays.asList(dbgisSecret));
		} catch (Exception e) {
			log.error(e.getMessage());
			respondKO(response, e.getMessage());
		}
	}

}
