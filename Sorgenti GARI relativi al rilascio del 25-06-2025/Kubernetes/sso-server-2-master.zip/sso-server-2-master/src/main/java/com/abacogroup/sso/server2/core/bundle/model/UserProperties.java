package com.abacogroup.sso.server2.core.bundle.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAlias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserProperties {
    @JsonAlias({ "username", "userName" })
    private String userName;
    private Map<String, String> properties;
}
