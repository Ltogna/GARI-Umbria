package com.abacogroup.sso.server2.api;

import java.util.List;

import lombok.Builder;
import lombok.Builder.Default;
import lombok.Value;

@Value
public class Jwks {
	private List<Jwk> keys;

	@Value
	@Builder
	public static class Jwk {
		@Default
		private String alg = "RS256";

		@Default
		private String use = "sig";

		@Default
		private String kty = "RSA";

		private String e;
		private String n;
		private String kid;
	}
}
