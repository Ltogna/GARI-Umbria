package com.abacogroup.sso.server2.core;

import static java.util.stream.Collectors.toList;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.List;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.dropwizard.auth.sso2.exceptions.KeyCreationException;
import com.abacogroup.dropwizard.auth.sso2.exceptions.KeyLoadException;
import com.abacogroup.sso.server2.api.Jwks;
import com.abacogroup.sso.server2.api.Jwks.Jwk;
import com.auth0.jwt.interfaces.RSAKeyProvider;
import com.fasterxml.jackson.databind.ObjectMapper;

public class KeysService implements RSAKeyProvider {
	private static final String PUB_BEGIN = "-----BEGIN PUBLIC KEY-----";
	private static final String PUB_END = "-----END PUBLIC KEY-----";
	public static final int PUB_KEY_GC_INTERVAL_MINS = 30;

	private static final int AES_BITS = 256;

	private static final Logger log = LoggerFactory.getLogger(KeysService.class);
	private static final String IV_EXTENSION = ".iv";
	private static final String PUB_EXTENSION = ".pub";
	private static final String PING_EXTENSION = ".ping";

	private ObjectMapper objectMapper;
	private File publicKeysDir;

	private ConcurrentHashMap<String, RSAPublicKey> publicKeys;
	private GeneratedPrivateKey privateKey;
	private SecretKeySpec pubKeyEncriptionKey;

	private volatile Jwks jwksCache;
	private SecureRandom secureRandom;

	public KeysService(ObjectMapper objectMapper, String publicKeysDir, byte[] aesSecret) {
		Objects.requireNonNull(publicKeysDir);

		this.objectMapper = objectMapper;
		this.publicKeysDir = new File(publicKeysDir);

		if (!this.publicKeysDir.exists()) {
			this.publicKeysDir.mkdirs();
		}

		publicKeys = new ConcurrentHashMap<>();
		secureRandom = new SecureRandom();

		createPubKeyEncriptionKey(aesSecret);

		this.privateKey = generateRSAKeyPair();
		updatePingFile();
		loadPublicKeys();
	}

	private void createPubKeyEncriptionKey(byte[] aesSecret) {
		if (aesSecret == null || aesSecret.length == 0) {
			return;
		}

		if (aesSecret.length != AES_BITS / 8) {
			throw new IllegalArgumentException(String.format("AES key must be %s bits", AES_BITS));
		}

		this.pubKeyEncriptionKey = new SecretKeySpec(aesSecret, "AES");

		// Fast fail if cipher is not loadable for any reasons
		getAesCipher();
	}

	@Override
	public RSAPublicKey getPublicKeyById(String keyId) {
		RSAPublicKey ret = publicKeys.get(keyId);
		if (ret != null) {
			return ret;
		}

		try {
			loadPublicKey(keyId);
			return publicKeys.get(keyId);
		} catch (KeyLoadException e) {
			return null;
		}
	}

	public Jwks getPublicKeysAsJwks() {
		boolean loadedNew = loadPublicKeys(); // Make sure we have all keys loaded

		if (loadedNew || jwksCache == null) {
			List<Jwk> keys = publicKeys.entrySet().stream()
					.map(this::toJwk)
					.collect(toList());

			jwksCache = new Jwks(keys);
		}

		return jwksCache;
	}

	private Jwk toJwk(Entry<String, RSAPublicKey> entry) {
		Encoder encoder = Base64.getUrlEncoder().withoutPadding();

		RSAPublicKey key = entry.getValue();
		byte[] exponent = key.getPublicExponent().toByteArray();
		byte[] modulus = key.getModulus().toByteArray();

		return Jwk.builder()
				.e(encoder.encodeToString(exponent))
				.kid(entry.getKey())
				.n(encoder.encodeToString(modulus))
				.build();
	}

	@Override
	public RSAPrivateKey getPrivateKey() {
		return privateKey.getKey();
	}

	@Override
	public String getPrivateKeyId() {
		return privateKey.getId();
	}

	private boolean loadPublicKeys() {
		boolean ret = false;
		boolean loaded;
		String[] files = publicKeysDir.list((dir, name) -> name.endsWith(PUB_EXTENSION));
		for (String f : files) {
			loaded = loadPublicKey(f.substring(0, f.length() - 4));
			ret |= loaded;
		}
		return ret;
	}

	boolean loadPublicKey(String id) {
		if (this.publicKeys.contains(id)) {
			return false;
		}

		try {
			File keyFile = new File(publicKeysDir, id + PUB_EXTENSION);

			byte[] bytes;
			if (pubKeyEncriptionKey != null) {
				File ivFile = new File(keyFile.getAbsolutePath() + IV_EXTENSION);
				if (!ivFile.exists()) {
					log.warn("Initialization vector file not found for key: {}", id);
					return false;
				}
				bytes = aesDecryptFile(keyFile, ivFile);
			} else {
				bytes = readAllBytes(keyFile);
			}

			String str = new String(bytes);
			str = str.replace(PUB_BEGIN, "");
			str = str.replace(PUB_END, "");
			str = str.replace("\r", "");
			str = str.replace("\n", "");

			byte[] keyBytes = Base64.getDecoder().decode(str.getBytes());
			X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
			KeyFactory kf = KeyFactory.getInstance("RSA");
			this.publicKeys.put(id, (RSAPublicKey) kf.generatePublic(spec));
		} catch (Exception e) {
			log.warn("Error loading key: " + id, e);
			return false;
		}

		return true;
	}

	private void updatePingFile() {
		File pingFile = new File(publicKeysDir, privateKey.getId() + PING_EXTENSION);
		try {
			objectMapper.writeValue(pingFile, Instant.now());
		} catch (IOException e) {
			log.error("Error updating ping file: " + pingFile.getAbsolutePath(), e);
		}
	}

	/**
	 * Cleans up public keys that are not used anymore
	 */
	public void cleanupUnusedPublicKeys() {
		updatePingFile(); // We update our ping file before removing old keys
		Arrays.stream(publicKeysDir.listFiles((dir, name) -> name.endsWith(PUB_EXTENSION)))
				.forEach(this::cleanupPublicKeyIfNeeded);
	}

	private void cleanupPublicKeyIfNeeded(File pubKeyFile) {
		String base = pubKeyFile.getName().substring(0, pubKeyFile.getName().length() - PUB_EXTENSION.length());
		File pingFile = new File(publicKeysDir, base + PING_EXTENSION);
		File ivFile = new File(publicKeysDir, base + IV_EXTENSION);

		Instant lastUsed = readInstantFromPingFile(pingFile);
		if (lastUsed.plusSeconds((PUB_KEY_GC_INTERVAL_MINS + 5) * 60L).isBefore(Instant.now())) {
			deleteQuietly(pingFile);
			deleteQuietly(pubKeyFile);
			deleteQuietly(ivFile);
		}
	}

	private Instant readInstantFromPingFile(File pingFile) {
		if (!pingFile.exists()) {
			return Instant.ofEpochMilli(0L);
		}
		try {
			return objectMapper.readValue(pingFile, Instant.class);
		} catch (IOException e) {
			log.warn("Error reading ping file: " + pingFile.getAbsolutePath(), e);
			return Instant.ofEpochMilli(0L);
		}
	}

	private void deleteQuietly(File file) {
		try {
			Files.deleteIfExists(file.toPath());
		} catch (IOException e) {
			log.warn("Error deleting file: " + file.getAbsolutePath(), e);
		}
	}

	private byte[] readAllBytes(File file) throws IOException {
		if (file.length() > 200 * 1024) {
			throw new IllegalStateException("Key file size too big, " + file.getAbsolutePath() + " size is " + file.length());
		}
		return Files.readAllBytes(file.toPath());
	}

	/**
	 * Creates an RSA key pair and returns the absolute file name of the private key that was written to disk
	 *
	 * @return the generated private key
	 */
	private GeneratedPrivateKey generateRSAKeyPair() {
		String suffix = Long.toString(secureRandom.nextLong(), Character.MAX_RADIX);
		LocalDateTime now = LocalDateTime.now();
		String id = now.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + suffix;
		KeyPair pair;
		try {
			KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
			generator.initialize(2048);
			pair = generator.generateKeyPair();
			writePublicKey(id + PUB_EXTENSION, pair.getPublic());
		} catch (NoSuchAlgorithmException e) {
			throw new KeyCreationException(e);
		}

		return new GeneratedPrivateKey(id, (RSAPrivateKey) pair.getPrivate());
	}

	private String keyToString(byte[] bytes) {
		StringBuilder buf = new StringBuilder(bytes.length + 64);
		buf.append(PUB_BEGIN).append('\n');
		for (int i = 0; i < bytes.length; i++) {
			if (i > 0 && (i % 64) == 0) {
				buf.append('\n');
			}

			buf.append((char) bytes[i]);
		}
		buf.append('\n').append(PUB_END);
		return buf.toString();
	}

	private void writePublicKey(String fileName, PublicKey key) {
		try {
			X509EncodedKeySpec spec = new X509EncodedKeySpec(key.getEncoded());
			byte[] bytes = Base64.getEncoder().encode(spec.getEncoded());

			String str = keyToString(bytes);
			if (pubKeyEncriptionKey != null) {
				AESEncoded encoded = aesEncrypt(str);
				Files.write(Paths.get(publicKeysDir.getAbsolutePath(), fileName + IV_EXTENSION), encoded.getIv());
				Files.write(Paths.get(publicKeysDir.getAbsolutePath(), fileName), encoded.getValue());
			} else {
				Files.write(Paths.get(publicKeysDir.getAbsolutePath(), fileName), str.getBytes());
			}
		} catch (IOException e) {
			throw new KeyCreationException(e);
		}
	}

	private byte[] aesDecryptFile(File keyFile, File ivFile) throws IOException {
		byte[] iv = readAllBytes(ivFile);
		Cipher cipher = getAesDecryptingCipher(iv);

		byte[] encrypted = readAllBytes(keyFile);
		try {
			return cipher.doFinal(encrypted);
		} catch (IllegalBlockSizeException | BadPaddingException e) {
			throw new IllegalStateException(e.getMessage(), e);
		}
	}

	private AESEncoded aesEncrypt(String str) {
		Cipher cipher = getAesEnccryptingCipher();
		try {
			byte[] value = cipher.doFinal(str.getBytes(StandardCharsets.UTF_8));
			return new AESEncoded(value, cipher.getIV());
		} catch (IllegalBlockSizeException | BadPaddingException e) {
			throw new IllegalStateException(e.getMessage(), e);
		}
	}

	private Cipher getAesEnccryptingCipher() {
		var cipher = getAesCipher();
		try {
			byte[] iv = new byte[16];
			secureRandom.nextBytes(iv);
			cipher.init(Cipher.ENCRYPT_MODE, pubKeyEncriptionKey, new IvParameterSpec(iv));
		} catch (InvalidKeyException | InvalidAlgorithmParameterException e) {
			throw new IllegalStateException(e.getMessage(), e);
		}
		return cipher;
	}

	private Cipher getAesDecryptingCipher(byte[] iv) {
		var cipher = getAesCipher();
		try {
			cipher.init(Cipher.DECRYPT_MODE, pubKeyEncriptionKey, new IvParameterSpec(iv));
		} catch (InvalidKeyException | InvalidAlgorithmParameterException e) {
			throw new IllegalStateException(e.getMessage(), e);
		}
		return cipher;
	}

	private Cipher getAesCipher() {
		// This is sometimes reported as a weak algorithm but:
		// - we are using it to encrypt data at rest, we do not use it in network communications
		// - we use it as a verification mechanism, to be sure that the data on disk is written by us; we don't really need public keys to be encrypted, if not
		// for this reason
		try {
			return Cipher.getInstance("AES/CBC/PKCS5Padding");
		} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
			throw new IllegalStateException(e.getMessage(), e);
		}
	}
}
