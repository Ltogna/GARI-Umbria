package com.abacogroup.sso.server2.core.bundle;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.sso.server2.core.bundle.model.LanguagesConfigMessage;
import com.abacogroup.sso.server2.db.ConfigDAO;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Sso2LanguageMessageProcessor extends AbstractConfigProcessor {
	private final Sso1DAO ssoDAO;

	public Sso2LanguageMessageProcessor(ConfigDAO configDAO, Sso1DAO ssoDAO, ObjectMapper objectMapper) {
		super(configDAO, objectMapper);
		this.ssoDAO = ssoDAO;
	}

	@Override
	public String getDomainName() { // Nome della directory
		return "languages";
	}

	@Override
	protected void onMessageInTransaction(ConfigDAO dao, ConfigDataMessage message) {
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> file.getAbsolutePath().endsWith(".json"))
				.forEach(file -> processFile(message.getTenantId(), file));
	}

	void processFile(String tenantId, File file) {
		LanguagesConfigMessage message;

		try {
			message = objectMapper.readValue(file, LanguagesConfigMessage.class);
		} catch (IOException e) {
			throw new IllegalStateException("Error processing file " + file.getName() + " for tenant " + tenantId, e);
		}

		doInsertOrUpdate(tenantId, message);
	}

	void doInsertOrUpdate(String tenantId, LanguagesConfigMessage languages) {
		if (languages == null) {
			return;
		}

		ssoDAO.useTransaction($ -> {
			ssoDAO.deleteAllLanguages(tenantId);

			languages.getLanguages().forEach((languageCode, langs) -> {
				langs.forEach(lang -> ssoDAO.insertLanguage(tenantId, languageCode, lang.getLang(), lang.getDescription()));
			});
		});
	}
}
