package com.abacogroup.sso.server2.cli;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.sso.server2.SSOServer2Configuration;

import io.dropwizard.core.cli.ConfiguredCommand;
import io.dropwizard.core.setup.Bootstrap;
import net.sourceforge.argparse4j.inf.Namespace;
import net.sourceforge.argparse4j.inf.Subparser;

public class DeleteOldPubKeysCommand extends ConfiguredCommand<SSOServer2Configuration> {

	private static final Logger log = LoggerFactory.getLogger(DeleteOldPubKeysCommand.class);
	private static final String NAME = "delete-old-pubkeys";

	public DeleteOldPubKeysCommand() {
		super(NAME, "Delete public keys");
	}

	@Override
	public void configure(Subparser subparser) {
		super.configure(subparser);

		// Add a command line option
		subparser.addArgument("-d", "--days")
				.dest("days")
				.type(Integer.class)
				.required(true)
				.help("The number of days to keep");
	}

	@Override
	protected void run(Bootstrap<SSOServer2Configuration> bootstrap, Namespace namespace,
			SSOServer2Configuration configuration) throws Exception {
		Integer days = namespace.getInt("days");

		File dir = new File(configuration.getPublicKeysDir());
		if (!dir.exists()) {
			log.warn(configuration.getPublicKeysDir() + " not found");
			return;
		}
		if (!dir.isDirectory()) {
			throw new IllegalArgumentException(configuration.getPublicKeysDir() + " is not a directory");
		}

		run(dir, days);
	}

	// Visible for testing
	void run(File publicKeysDir, int days) throws IOException {
		try (var stream = Files.list(publicKeysDir.toPath())) {
			stream.filter(path -> isOld(path, days))
					.forEach(this::deleteFile);
		}
	}

	protected boolean isOld(Path path, int days) {
		try {
			FileTime creationTime = (FileTime) Files.getAttribute(path, "creationTime");
			return creationTime.toInstant()
					.plus(days, ChronoUnit.DAYS)
					.isBefore(Instant.now());
		} catch (IOException e) {
			throw new IllegalStateException(e);
		}
	}

	private void deleteFile(Path path) {
		try {
			log.info("Deleting {}", path.toUri());
			Files.delete(path);
		} catch (IOException e) {
			throw new IllegalStateException(e);
		}
	}

}
