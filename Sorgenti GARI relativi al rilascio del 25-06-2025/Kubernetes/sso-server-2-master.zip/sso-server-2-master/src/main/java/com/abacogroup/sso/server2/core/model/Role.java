package com.abacogroup.sso.server2.core.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Role {
	private Integer roleId;
	private String name;
	private String descr;
	private String tenantId;

	@Override
	public String toString() {
		StringBuilder buff = new StringBuilder();
		buff.append(roleId).append('|').append(name).append('|').append(descr != null ? descr : "");
		return buff.toString();
	}
}
