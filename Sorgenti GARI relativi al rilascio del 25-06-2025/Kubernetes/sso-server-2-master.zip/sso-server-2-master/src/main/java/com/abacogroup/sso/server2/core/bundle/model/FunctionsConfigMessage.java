package com.abacogroup.sso.server2.core.bundle.model;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FunctionsConfigMessage {
	@Builder.Default
	private List<FunctionDefinition> functions = new ArrayList<>();

	@Builder.Default
	private List<RoleDefinition> roles = new ArrayList<>();

	@Builder.Default
	private List<RoleFunctions> roleFunctions = new ArrayList<>();
}
