package com.abacogroup.sso.server2.api;

import javax.validation.constraints.NotEmpty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class UnAuthChangePasswordRequest extends ChangePasswordRequest {
	@NotEmpty
	@Schema(description = "The user ID")
	String userid;
}
