package com.abacogroup.sso.server2.exceptions;

import javax.ws.rs.ClientErrorException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import io.swagger.v3.oas.annotations.media.Schema;

public class UserAlreadyExistsException extends ClientErrorException {
	private static final long serialVersionUID = 4040716101981231699L;

	private static final UserAlreadyExistsExceptionErrorBody BODY = new UserAlreadyExistsExceptionErrorBody();

	public UserAlreadyExistsException() {
		super("User already exists!", Response.status(Status.CONFLICT).entity(BODY).build());
	}

	public static class UserAlreadyExistsExceptionErrorBody {
		@Schema(allowableValues = "USER_ALREADY_EXISTS")
		public String getErrorCode() {
			return "USER_ALREADY_EXISTS";
		}
	}
}
