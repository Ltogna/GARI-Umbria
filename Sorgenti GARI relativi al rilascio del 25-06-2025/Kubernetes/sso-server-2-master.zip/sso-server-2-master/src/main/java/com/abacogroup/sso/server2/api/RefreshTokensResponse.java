package com.abacogroup.sso.server2.api;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RefreshTokensResponse {
	@Schema(description = "The new access token")
	private String auth_token;

	@Schema(description = "The (possibly) new refresh token")
	private String refresh_token;
}
