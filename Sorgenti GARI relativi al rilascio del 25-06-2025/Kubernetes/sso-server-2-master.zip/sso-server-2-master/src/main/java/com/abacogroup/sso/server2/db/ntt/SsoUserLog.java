package com.abacogroup.sso.server2.db.ntt;

import java.time.OffsetDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class SsoUserLog {
	private String userid;
	private OffsetDateTime last_login;
	private Integer failed_logins;

	public SsoUserLog() {
	}

}
