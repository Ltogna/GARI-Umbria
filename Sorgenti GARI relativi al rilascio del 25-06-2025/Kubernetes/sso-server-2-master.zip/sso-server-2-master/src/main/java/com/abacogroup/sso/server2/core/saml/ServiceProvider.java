package com.abacogroup.sso.server2.core.saml;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.time.Instant;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.Supplier;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang3.StringUtils;
import org.opensaml.core.xml.XMLObject;
import org.opensaml.core.xml.config.XMLObjectProviderRegistrySupport;
import org.opensaml.core.xml.io.Marshaller;
import org.opensaml.core.xml.io.Unmarshaller;
import org.opensaml.core.xml.schema.XSAny;
import org.opensaml.core.xml.schema.XSString;
import org.opensaml.saml.common.SAMLVersion;
import org.opensaml.saml.common.xml.SAMLConstants;
import org.opensaml.saml.saml2.core.Assertion;
import org.opensaml.saml.saml2.core.Attribute;
import org.opensaml.saml.saml2.core.AttributeStatement;
import org.opensaml.saml.saml2.core.Audience;
import org.opensaml.saml.saml2.core.AudienceRestriction;
import org.opensaml.saml.saml2.core.AuthnContext;
import org.opensaml.saml.saml2.core.AuthnContextClassRef;
import org.opensaml.saml.saml2.core.AuthnContextComparisonTypeEnumeration;
import org.opensaml.saml.saml2.core.AuthnRequest;
import org.opensaml.saml.saml2.core.AuthnStatement;
import org.opensaml.saml.saml2.core.Conditions;
import org.opensaml.saml.saml2.core.Issuer;
import org.opensaml.saml.saml2.core.NameID;
import org.opensaml.saml.saml2.core.NameIDPolicy;
import org.opensaml.saml.saml2.core.RequestedAuthnContext;
import org.opensaml.saml.saml2.core.Response;
import org.opensaml.saml.saml2.core.Status;
import org.opensaml.saml.saml2.core.StatusCode;
import org.opensaml.saml.saml2.core.StatusMessage;
import org.opensaml.saml.saml2.core.Subject;
import org.opensaml.saml.saml2.core.SubjectConfirmation;
import org.opensaml.saml.saml2.core.SubjectConfirmationData;
import org.opensaml.saml.saml2.metadata.AssertionConsumerService;
import org.opensaml.saml.saml2.metadata.AttributeConsumingService;
import org.opensaml.saml.saml2.metadata.ContactPerson;
import org.opensaml.saml.saml2.metadata.ContactPersonTypeEnumeration;
import org.opensaml.saml.saml2.metadata.EmailAddress;
import org.opensaml.saml.saml2.metadata.EntityDescriptor;
import org.opensaml.saml.saml2.metadata.Extensions;
import org.opensaml.saml.saml2.metadata.KeyDescriptor;
import org.opensaml.saml.saml2.metadata.NameIDFormat;
import org.opensaml.saml.saml2.metadata.Organization;
import org.opensaml.saml.saml2.metadata.OrganizationDisplayName;
import org.opensaml.saml.saml2.metadata.OrganizationName;
import org.opensaml.saml.saml2.metadata.OrganizationURL;
import org.opensaml.saml.saml2.metadata.RequestedAttribute;
import org.opensaml.saml.saml2.metadata.SPSSODescriptor;
import org.opensaml.saml.saml2.metadata.ServiceName;
import org.opensaml.saml.saml2.metadata.SingleLogoutService;
import org.opensaml.saml.saml2.metadata.TelephoneNumber;
import org.opensaml.security.SecurityException;
import org.opensaml.security.credential.UsageType;
import org.opensaml.security.x509.BasicX509Credential;
import org.opensaml.security.x509.X509Credential;
import org.opensaml.xmlsec.SignatureSigningParameters;
import org.opensaml.xmlsec.keyinfo.KeyInfoGenerator;
import org.opensaml.xmlsec.keyinfo.impl.X509KeyInfoGeneratorFactory;
import org.opensaml.xmlsec.signature.SignableXMLObject;
import org.opensaml.xmlsec.signature.Signature;
import org.opensaml.xmlsec.signature.support.SignatureConstants;
import org.opensaml.xmlsec.signature.support.SignatureException;
import org.opensaml.xmlsec.signature.support.SignatureSupport;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.abacogroup.sso.server2.core.saml.config.ContactPersonConfig;
import com.abacogroup.sso.server2.core.saml.config.PrivateContactPerson;
import com.abacogroup.sso.server2.core.saml.config.PublicContactPerson;
import com.abacogroup.sso.server2.core.saml.config.ReturnMode;
import com.abacogroup.sso.server2.core.saml.config.SamlServiceProviderConfig;
import com.auth0.jwt.algorithms.Algorithm;

import net.shibboleth.utilities.java.support.xml.ParserPool;

public class ServiceProvider {

	private static final String LANG = "it";
	private static final String IDP_METADATA_EXTENSION = ".metadata.xml";
	private static final long ACCEPT_LEEWAY = 30000;
	private static final Set<String> ALLOWED_AUTHN_LEVELS = new TreeSet<>();
	private static final Set<String> USER_ERROR_CODES = new TreeSet<>();
	private static final String TAG_NO_STRICT_CHECKS = "noStrictChecks";

	static {
		USER_ERROR_CODES.add("ErrorCode nr19");
		USER_ERROR_CODES.add("ErrorCode nr20");
		USER_ERROR_CODES.add("ErrorCode nr21");
		USER_ERROR_CODES.add("ErrorCode nr22");
		USER_ERROR_CODES.add("ErrorCode nr23");
		USER_ERROR_CODES.add("ErrorCode nr25");
		ALLOWED_AUTHN_LEVELS.add("https://www.spid.gov.it/SpidL1");
		ALLOWED_AUTHN_LEVELS.add("https://www.spid.gov.it/SpidL2");
		ALLOWED_AUTHN_LEVELS.add("https://www.spid.gov.it/SpidL3");
	}

	private ParserPool parserPool;
	private final SamlServiceProviderConfig config;
	private final X509Credential credential;

	private X509KeyInfoGeneratorFactory keyInfoGeneratorFactory;
	private Map<String, RemoteIdentityProvider> identityProvidersByName;
	private Map<String, RemoteIdentityProvider> identityProvidersByEntityID;

	private Algorithm algorithm;

	public ServiceProvider(ParserPool parserPool, SamlServiceProviderConfig config, Algorithm algorithm) {
		this.parserPool = parserPool;
		this.config = config;
		this.algorithm = algorithm;
		credential = loadX509Credentials(config.getCert(), config.getPrivKey());

		keyInfoGeneratorFactory = new X509KeyInfoGeneratorFactory();
		keyInfoGeneratorFactory.setEmitEntityCertificate(true);

		loadIdentityProviders(config.getIdpMetadataDirectory());
	}

	public Optional<RemoteIdentityProvider> getRemoteIDPByName(String remoteIdpName) {
		return Optional.ofNullable(identityProvidersByName.get(remoteIdpName));
	}

	public Set<String> getRemoteIDPNames() {
		return Collections.unmodifiableSet(identityProvidersByName.keySet());
	}

	public Optional<ReturnMode> getReturnMode(String url) {
		Map<String, ReturnMode> returnMap = this.config.getReturnMapping();
		return Optional.ofNullable(returnMap.get(url));
	}

	public List<String> getRequiredAttibutes() {
		return this.config.getAttributes();
	}

	public Map<String, String> getSsoUserPropertiesFields() {
		return this.config.getSsoUserPropertiesFields();
	}

	public Boolean isTagPresent(String tag) {
		return this.config.getTags()
				.stream()
				.anyMatch(t -> t.equals(tag));
	}

	public String createMetadata(String contextBaseURL) {
		try {
			return createMetadataInternal(contextBaseURL);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	public AuthnRequestObj createLoginRequest(RemoteIdentityProvider remoteIDP) {
		String id = remoteIDP.createAuthnID();

		AuthnRequest request = OpenSAMLUtils.buildSAMLObject(AuthnRequest.class);
		request.setID(id);
		request.setIssueInstant(Instant.now());
		request.setDestination(remoteIDP.getDestinationUrl());
		// request.setProtocolBinding(SAMLConstants.SAML2_POST_BINDING_URI);
		request.setVersion(SAMLVersion.VERSION_20);
		request.setAssertionConsumerServiceIndex(0);
		request.setAttributeConsumingServiceIndex(0);

		Issuer issuer = OpenSAMLUtils.buildSAMLObject(Issuer.class);
		issuer.setValue(config.getEntityId());
		issuer.setFormat(NameID.ENTITY);
		if (!this.isTagPresent(TAG_NO_STRICT_CHECKS)) {
			issuer.setNameQualifier(config.getEntityId());
		}
		request.setIssuer(issuer);

		NameIDPolicy policy = OpenSAMLUtils.buildSAMLObject(NameIDPolicy.class);
		policy.setFormat(NameID.TRANSIENT);
		request.setNameIDPolicy(policy);

		if (!this.isTagPresent(TAG_NO_STRICT_CHECKS)) {
			RequestedAuthnContext ctx = OpenSAMLUtils.buildSAMLObject(RequestedAuthnContext.class);
			ctx.setComparison(AuthnContextComparisonTypeEnumeration.MINIMUM);

			AuthnContextClassRef classRef = OpenSAMLUtils.buildSAMLObject(AuthnContextClassRef.class);
			classRef.setURI(config.getMinAuthRef());
			ctx.getAuthnContextClassRefs().add(classRef);

			request.setRequestedAuthnContext(ctx);
		}
		request.setForceAuthn(true);

		try {
			return new AuthnRequestObj(id, signAndMarshal(request, remoteIDP.getCanonicalizationAlgorithm()));
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	// https://docs.italia.it/italia/spid/spid-regole-tecniche/it/stabile/single-sign-on.html
	// (Response)
	public ResponseAttributes getAssertedAttributes(String samlResponse, String contextBaseURL) throws Exception {
		Document doc = parserPool.parse(new ByteArrayInputStream(samlResponse.getBytes()));
		Element el = doc.getDocumentElement();
		Unmarshaller unmarshaller = XMLObjectProviderRegistrySupport.getUnmarshallerFactory().getUnmarshaller(el);
		XMLObject obj = unmarshaller.unmarshall(el);
		if (!(obj instanceof Response)) {
			throw new SAMLValidationExcpetion("Bad SAMLResponse");
		}

		Response response = (Response) obj;
		RemoteIdentityProvider idp = getIdentityProviderFromResponseIdentity(response);

		if (response.isSigned()) {
			// Message signature is not mandatoy for SPID
			Signature signature = response.getSignature();
			if (signature != null) {
				idp.validateSignature(signature);
			}
		}

		validateResponseAttributes(response, idp, contextBaseURL);
		validateStatus(response);
		if (!isResponseStatusSuccess(response)) {
			return new ResponseAttributes(new AssertedAttributesImpl(false), response.getInResponseTo());
		}

		idp.validateIssuer(response.getIssuer(), !this.isTagPresent(TAG_NO_STRICT_CHECKS), idp.getIssuerFormatResponseCheck());

		List<Assertion> assertions = requireNonEmpty(response.getAssertions(), () -> "Expected exactly one Assertion");
		validateAuthnResponseAssertion(assertions.get(0), contextBaseURL, idp);

		return new ResponseAttributes(getAttributes(assertions.get(0)), response.getInResponseTo());
	}

	private AssertedAttributes getAttributes(Assertion assertion) {
		List<AttributeStatement> statements = requireNonEmpty(assertion.getAttributeStatements(),
				() -> "Assertion must have a child note og type AttributeStatement");

		AssertedAttributesImpl ret = new AssertedAttributesImpl(true);

		List<Attribute> attributes;
		for (AttributeStatement stmt : statements) {
			attributes = requireNonEmpty(stmt.getAttributes(),
					() -> "AttributeStatement must have a child note of type Attribute");
			attributes.forEach(attr -> {
				if ("fiscalNumber".equals(attr.getName())) {
					XMLObject xml = attr.getAttributeValues().get(0);
					XSString res = OpenSAMLUtils.buildXSString(xml.getElementQName());
					String value = ((XSString) xml).getValue().replace("TINIT-", "");
					res.setValue(value);
					attr.getAttributeValues().set(0, res);
				}
				ret.addAttribute(attr);
			});
		}

		return ret;
	}

	private void validateAuthnResponseAssertion(Assertion assertion, String baseURL, RemoteIdentityProvider idp) {
		if (!SAMLVersion.VERSION_20.equals(assertion.getVersion())) {
			throw new SAMLValidationExcpetion("Bad SAML version");
		}
		String assertionID = requireNonEmpty(assertion.getID(), () -> "Asserion ID is missing");
		if (!assertion.isSigned()) {
			throw new SAMLValidationExcpetion("Assertion " + assertionID + " is not signed");
		}
		idp.validateIssuer(assertion.getIssuer(), !this.isTagPresent(TAG_NO_STRICT_CHECKS), idp.getIssuerFormatAssertionCheck());

		try {
			idp.validateSignature(assertion.getSignature());
		} catch (SignatureException e) {
			throw new SAMLValidationExcpetion("Bad Assertion signature", e);
		}

		requireIssueInstant(assertion.getIssueInstant(), "assertion");
		Subject subject = requireNonNull(assertion.getSubject(), () -> "Missing Subject in assertion " + assertionID);
		NameID nameID = requireNonNull(subject.getNameID(), () -> "Missing NameID");
		if (!NameID.TRANSIENT.equals(nameID.getFormat())) {
			throw new SAMLValidationExcpetion("Identity type must be transient");
		}

		if (!this.isTagPresent(TAG_NO_STRICT_CHECKS)) {
			requireNonEmpty(nameID.getNameQualifier(), () -> "NameID not specified");
		}

		SubjectConfirmation confirmation = subject.getSubjectConfirmations().stream()
				.filter(c -> SubjectConfirmation.METHOD_BEARER.equals(c.getMethod()))
				.findFirst()
				.orElseThrow(() -> new SAMLValidationExcpetion(
						"No SubjectConfirmations with method " + SubjectConfirmation.METHOD_BEARER));

		SubjectConfirmationData data = requireNonNull(confirmation.getSubjectConfirmationData(),
				() -> "Missing SubjectConfirmationData");
		if (!getAssertionConsumerLocation(baseURL).equals(data.getRecipient())) {
			throw new SAMLValidationExcpetion("Bad recipient in SubjectConfirmationData");
		}

		requireNotOnOrAfter(data.getNotOnOrAfter());
		requireNonEmpty(data.getInResponseTo(), () -> "Missing inResponseTo attribute");
		idp.validateAuthnID(data.getInResponseTo());
		validateAsserionsConditions(assertion.getConditions());
		validateaAuthnStatements(assertion.getAuthnStatements());
	}

	private void validateaAuthnStatements(List<AuthnStatement> authnStatements) {
		requireNonEmpty(authnStatements, () -> "Must have AuthnStatement");

		AuthnContext ctx;
		AuthnContextClassRef ref;
		String level;
		for (AuthnStatement stmt : authnStatements) {
			ctx = requireNonNull(stmt.getAuthnContext(),
					() -> "AuthnStatement must have a child node of type AuthnContext");
			ref = requireNonNull(ctx.getAuthnContextClassRef(),
					() -> "AuthnContext must have a child node of type AuthnContextClassRef");

			/*
			 * The following works only for SPID where AuthnContextClassRef are: - https://www.spid.gov.it/SpidL1 - https://www.spid.gov.it/SpidL2 -
			 * https://www.spid.gov.it/SpidL3 so we can compare the strings directly...
			 */
			level = requireNonNull(ref.getURI(), () -> "AuthnContextClassRef is not specified");
			if (ALLOWED_AUTHN_LEVELS.contains(level) && config.getMinAuthRef().compareTo(level) <= 0) {
				return;
			}
		}

		throw new SAMLValidationExcpetion("Minimum authentication level not met.");
	}

	private void validateAsserionsConditions(Conditions conditions) {
		requireNonNull(conditions, () -> "Conditions is missing");
		requireNotOnOrAfter(conditions.getNotOnOrAfter());
		requireNotBefore(conditions.getNotBefore());

		List<AudienceRestriction> restrictions = requireNonEmpty(conditions.getAudienceRestrictions(),
				() -> "Must have AudienceRestriction");
		validateAudienceRestriction(restrictions);
	}

	private void validateAudienceRestriction(List<AudienceRestriction> restrictions) {
		for (AudienceRestriction ar : restrictions) {
			for (Audience audience : requireNonEmpty(ar.getAudiences(),
					() -> "AudienceRestriction must have achild node named Audience")) {
				if (config.getEntityId().equals(audience.getURI())) {
					return;
				}
			}
		}

		throw new SAMLValidationExcpetion("Missing AudienceRestriction with correct audience");
	}

	private void validateResponseAttributes(Response response, RemoteIdentityProvider idp, String baseURL) {
		if (!SAMLVersion.VERSION_20.equals(response.getVersion())) {
			throw new SAMLValidationExcpetion("Bad SAML version");
		}

		requireIssueInstant(response.getIssueInstant(), "Response");
		requireNonEmpty(response.getID(), () -> "ID is missing in response");

		String inResponseTo = requireNonEmpty(response.getInResponseTo(), () -> "InResponseTo is missing in response");
		idp.validateAuthnID(inResponseTo);

		String destination = response.getDestination();
		if (!getAssertionConsumerLocation(baseURL).equals(destination)) {
			throw new SAMLValidationExcpetion("This response is not for me; bad Destination attribute");
		}
	}

	private void validateStatus(Response response) {
		Status status = requireNonNull(response.getStatus(), () -> "Status not specified");
		StatusCode statusCodeObj = requireNonNull(status.getStatusCode(), () -> "Status code not specified");

		String statusCode = statusCodeObj.getValue();

		if (StatusCode.RESPONDER.equals(statusCode)) {
			StatusMessage statusMessage = requireNonNull(status.getStatusMessage(), () -> "Status message not specified");
			String errorCodeMessage = requireNonEmpty(statusMessage.getValue(), () -> "Error code message not specified");
			if (USER_ERROR_CODES.contains(errorCodeMessage)) {
				throw new SPIDUserAnomalyException(errorCodeMessage);
			}
		}
		if (!StatusCode.SUCCESS.equals(statusCode) && !StatusCode.AUTHN_FAILED.equals(statusCode)) {
			throw new SAMLValidationExcpetion("Bad response status,"
					+ " expected: " + StatusCode.SUCCESS + " or " + StatusCode.AUTHN_FAILED
					+ " got: " + statusCode);
		}
	}

	private boolean isResponseStatusSuccess(Response response) {
		Status status = response.getStatus();
		String statusCode = status.getStatusCode().getValue();
		return StatusCode.SUCCESS.equals(statusCode);
	}

	private RemoteIdentityProvider getIdentityProviderFromResponseIdentity(Response response) {
		Issuer issuer = requireNonNull(response.getIssuer(), () -> "Issuer cannot be null");
		String idpID = issuer.getValue();
		return requireNonNull(identityProvidersByEntityID.get(idpID),
				() -> "Unknown IDP: " + idpID);
	}

	// https://docs.italia.it/italia/spid/spid-regole-tecniche/it/stabile/metadata.html
	private String createMetadataInternal(String contextBaseURL) throws Exception {
		EntityDescriptor spEntityDescriptor = OpenSAMLUtils.buildSAMLObject(EntityDescriptor.class);
		spEntityDescriptor.setEntityID(config.getEntityId());

		SPSSODescriptor spSSODescriptor = OpenSAMLUtils.buildSAMLObject(SPSSODescriptor.class);
		spSSODescriptor.setWantAssertionsSigned(true);
		spSSODescriptor.setAuthnRequestsSigned(true);
		spSSODescriptor.addSupportedProtocol(SAMLConstants.SAML20P_NS);

		// Keys
		KeyInfoGenerator keyInfoGenerator = keyInfoGeneratorFactory.newInstance();

		KeyDescriptor encKeyDescriptor = createEncodingKeyDescriptor(keyInfoGenerator);
		spSSODescriptor.getKeyDescriptors().add(encKeyDescriptor);

		KeyDescriptor signKeyDescriptor = createSignKeyDescriptor(keyInfoGenerator);
		spSSODescriptor.getKeyDescriptors().add(signKeyDescriptor);

		// Request transient pseudonym
		NameIDFormat nameIDFormat = OpenSAMLUtils.buildSAMLObject(NameIDFormat.class);
		nameIDFormat.setURI(NameID.TRANSIENT);
		spSSODescriptor.getNameIDFormats().add(nameIDFormat);

		// ASSERTION CONSUMER
		AssertionConsumerService assertionConsumerService = createAssertionConsumerService(contextBaseURL);
		spSSODescriptor.getAssertionConsumerServices().add(assertionConsumerService);

		// SINGLE SIGNOUT
		SingleLogoutService logoutService = createSingleSignout(contextBaseURL);
		spSSODescriptor.getSingleLogoutServices().add(logoutService); // ResponseLocation is optional for SPID

		// AttributeConsumingService
		AttributeConsumingService attrConsService = OpenSAMLUtils.buildSAMLObject(AttributeConsumingService.class);
		attrConsService.setIndex(0);

		{
			ServiceName serviceName = OpenSAMLUtils.buildSAMLObject(ServiceName.class);
			serviceName.setXMLLang(LANG);
			serviceName.setValue(config.getDisplayName());
			attrConsService.getNames().add(serviceName);
		}

		this.addRequestedAttributes(config.getAttributes(), attrConsService);

		spSSODescriptor.getAttributeConsumingServices().add(attrConsService);

		// eIDAS attributes
		AttributeConsumingService minimumAttributeSet = createMinimumAttributeSet();
		this.addRequestedAttributes(config.getEidasMinimumAttributes(), minimumAttributeSet);
		spSSODescriptor.getAttributeConsumingServices().add(minimumAttributeSet);

		AttributeConsumingService fullAttributeSet = createFullAttributeSet();
		this.addRequestedAttributes(config.getEidasMinimumAttributes(), fullAttributeSet);
		this.addRequestedAttributes(config.getEidasFullAttributes(), fullAttributeSet);
		spSSODescriptor.getAttributeConsumingServices().add(fullAttributeSet);

		// Organization metadata
		Organization org = createOrganization(spEntityDescriptor, spSSODescriptor);
		spEntityDescriptor.setOrganization(org);

		if (config.getPaContactPerson() != null) {
			addContactPerson(spEntityDescriptor, config.getPaContactPerson());
		} else {
			addContactPerson(spEntityDescriptor, config.getPrivateContactPerson());
		}

		return signAndMarshal(spEntityDescriptor, SignatureConstants.ALGO_ID_C14N11_OMIT_COMMENTS);
	}

	private SingleLogoutService createSingleSignout(String contextBaseURL) {
		SingleLogoutService logoutService = OpenSAMLUtils.buildSAMLObject(SingleLogoutService.class);
		logoutService.setLocation(contextBaseURL + "/api/v1/saml/" + config.getId() + "/slo");
		logoutService.setBinding(SAMLConstants.SAML2_POST_BINDING_URI);
		return logoutService;
	}

	private AttributeConsumingService createFullAttributeSet() {
		AttributeConsumingService fullAttributeSet = OpenSAMLUtils.buildSAMLObject(AttributeConsumingService.class);
		fullAttributeSet.setIndex(100);
		{
			ServiceName serviceName = OpenSAMLUtils.buildSAMLObject(ServiceName.class);
			serviceName.setXMLLang(LANG);
			serviceName.setValue("eIDAS Natural Person Full Attribute Set");
			fullAttributeSet.getNames().add(serviceName);
		}
		return fullAttributeSet;
	}

	private AttributeConsumingService createMinimumAttributeSet() {
		AttributeConsumingService minimumAttributeSet = OpenSAMLUtils.buildSAMLObject(AttributeConsumingService.class);
		minimumAttributeSet.setIndex(99);
		{
			ServiceName serviceName = OpenSAMLUtils.buildSAMLObject(ServiceName.class);
			serviceName.setXMLLang(LANG);
			serviceName.setValue("eIDAS Natural Person Minimum Attribute Set");
			minimumAttributeSet.getNames().add(serviceName);
		}
		return minimumAttributeSet;
	}

	private Organization createOrganization(EntityDescriptor spEntityDescriptor, SPSSODescriptor spSSODescriptor) {
		Organization org = OpenSAMLUtils.buildSAMLObject(Organization.class);
		{
			OrganizationName name = OpenSAMLUtils.buildSAMLObject(OrganizationName.class);
			name.setValue(config.getDisplayName());
			name.setXMLLang(LANG);
			org.getOrganizationNames().add(name);
		}
		{
			OrganizationDisplayName name = OpenSAMLUtils.buildSAMLObject(OrganizationDisplayName.class);
			name.setValue(config.getDisplayName());
			name.setXMLLang(LANG);
			org.getDisplayNames().add(name);
		}
		{
			OrganizationURL name = OpenSAMLUtils.buildSAMLObject(OrganizationURL.class);
			name.setURI(config.getOrgURL());
			name.setXMLLang(LANG);
			org.getURLs().add(name);
		}

		spEntityDescriptor.getRoleDescriptors().add(spSSODescriptor);
		return org;
	}

	private AssertionConsumerService createAssertionConsumerService(String contextBaseURL) {
		AssertionConsumerService assertionConsumerService = OpenSAMLUtils
				.buildSAMLObject(AssertionConsumerService.class);
		assertionConsumerService.setIndex(0);
		assertionConsumerService.setBinding(SAMLConstants.SAML2_POST_BINDING_URI);
		assertionConsumerService.setIsDefault(true);
		assertionConsumerService.setLocation(getAssertionConsumerLocation(contextBaseURL));
		return assertionConsumerService;
	}

	private KeyDescriptor createSignKeyDescriptor(KeyInfoGenerator keyInfoGenerator) throws SecurityException {
		KeyDescriptor signKeyDescriptor = OpenSAMLUtils.buildSAMLObject(KeyDescriptor.class);
		signKeyDescriptor.setUse(UsageType.SIGNING);
		signKeyDescriptor.setKeyInfo(keyInfoGenerator.generate(credential));
		return signKeyDescriptor;
	}

	private KeyDescriptor createEncodingKeyDescriptor(KeyInfoGenerator keyInfoGenerator) throws SecurityException {
		KeyDescriptor encKeyDescriptor = OpenSAMLUtils.buildSAMLObject(KeyDescriptor.class);
		encKeyDescriptor.setUse(UsageType.ENCRYPTION);
		encKeyDescriptor.setKeyInfo(keyInfoGenerator.generate(credential));
		return encKeyDescriptor;
	}

	private void addRequestedAttributes(List<String> attributes, AttributeConsumingService attrConsService) {
		RequestedAttribute ra;
		for (String a : attributes) {
			ra = OpenSAMLUtils.buildSAMLObject(RequestedAttribute.class);
			ra.setName(a);
			attrConsService.getRequestedAttributes().add(ra);
		}
	}

	// https://docs.italia.it/italia/spid/spid-regole-tecniche/it/stabile/metadata.html
	private void addContactPerson(EntityDescriptor spEntityDescriptor, ContactPersonConfig cfg) {
		ContactPerson person = OpenSAMLUtils.buildSAMLObject(ContactPerson.class);
		person.setType(ContactPersonTypeEnumeration.OTHER);

		EmailAddress email = OpenSAMLUtils.buildSAMLObject(EmailAddress.class);
		email.setURI(cfg.getEmail());
		person.getEmailAddresses().add(email);

		if (!StringUtils.isEmpty(cfg.getPhoneNumber())) {
			TelephoneNumber num = OpenSAMLUtils.buildSAMLObject(TelephoneNumber.class);
			num.setValue(cfg.getPhoneNumber());
			person.getTelephoneNumbers().add(num);
		}

		Extensions extensions = OpenSAMLUtils.buildSAMLObject(Extensions.class);
		List<XMLObject> tags = extensions.getUnknownXMLObjects();

		XSAny any;
		if (cfg instanceof PublicContactPerson) {
			PublicContactPerson pc = (PublicContactPerson) cfg;
			tags.add(OpenSAMLUtils.buildAnySpid("Public"));

			any = OpenSAMLUtils.buildAnySpid("IPACode");
			any.setTextContent(pc.getIpaCode());
			tags.add(any);
		} else {
			PrivateContactPerson pc = (PrivateContactPerson) cfg;
			tags.add(OpenSAMLUtils.buildAnySpid("Private"));

			if (!StringUtils.isEmpty(pc.getFiscalCode())) {
				any = OpenSAMLUtils.buildAnySpid("FiscalCode");
				any.setTextContent(pc.getFiscalCode());
				tags.add(any);
			}
		}

		if (!StringUtils.isEmpty(cfg.getVatNumber())) {
			any = OpenSAMLUtils.buildAnySpid("VATNumber");
			any.setTextContent(cfg.getVatNumber());
			tags.add(any);
		}

		person.setExtensions(extensions);

		spEntityDescriptor.getContactPersons().add(person);
	}

	private String getAssertionConsumerLocation(String baseURL) {
		return baseURL + "/api/v1/saml/" + config.getId() + "/ac";
	}

	private void loadIdentityProviders(String idpMetadataDirectory) {
		Map<String, RemoteIdentityProvider> byName = new HashMap<>();
		Map<String, RemoteIdentityProvider> byEntityID = new HashMap<>();

		File dir = new File(config.getIdpMetadataDirectory());
		if (!dir.exists()) {
			throw new IllegalStateException(dir.getAbsolutePath() + " does not exist");
		}
		if (!dir.isDirectory()) {
			throw new IllegalStateException(dir.getAbsolutePath() + " is not a directory");
		}
		if (!dir.canRead()) {
			throw new IllegalStateException(dir.getAbsolutePath() + " is not readable");
		}

		File[] files = dir
				.listFiles(f -> f.isFile() && f.canRead() && f.getName().toLowerCase().endsWith(IDP_METADATA_EXTENSION));

		File propsFile;
		Properties props;
		RemoteIdentityProvider idp;
		for (File f : files) {
			try {
				propsFile = new File(f.getAbsolutePath() + ".properties");
				props = new Properties();
				if (propsFile.exists()) {
					try (InputStream in = new FileInputStream(propsFile)) {
						props.load(in);
					}
				}

				String name = f.getName().toLowerCase();
				name = name.substring(0, name.indexOf(IDP_METADATA_EXTENSION));
				idp = new RemoteIdentityProvider(parserPool, algorithm, Files.readAllBytes(f.toPath()), props);
				byName.put(name, idp);
				byEntityID.put(idp.getEntityID(), idp);
			} catch (IOException e) {
				throw new RuntimeException(e.getMessage(), e);
			}
		}

		this.identityProvidersByName = Collections.unmodifiableMap(byName);
		this.identityProvidersByEntityID = Collections.unmodifiableMap(byEntityID);
	}

	private PrivateKey readPrivateKey(File keyFile) throws Exception {
		// read key bytes
		byte[] keyBytes = Files.readAllBytes(keyFile.toPath());

		String privateKey = new String(keyBytes, StandardCharsets.UTF_8);
		privateKey = privateKey
				.replaceAll("(-+BEGIN [RSA ]?PRIVATE KEY-+\\r?\\n|-+END [RSA ]?PRIVATE KEY-+\\r?\\n?)", "")
				.replaceAll("\\r|\\n", "");

		keyBytes = Base64.getDecoder().decode(privateKey);

		PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		return keyFactory.generatePrivate(spec);
	}

	private X509Credential loadX509Credentials(String certPath, String keyPath) {
		try {
			X509Certificate cert;
			try (InputStream in = new FileInputStream(certPath)) {
				CertificateFactory cf = CertificateFactory.getInstance("X.509");
				cert = (X509Certificate) cf.generateCertificate(in);
			}

			PrivateKey privKey = readPrivateKey(new File(keyPath));

			return new BasicX509Credential(cert, privKey);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	private String signAndMarshal(SignableXMLObject obj, String canonicalizationAlgorithm) throws Exception {
		X509KeyInfoGeneratorFactory keyInfoGeneratorFactory = new X509KeyInfoGeneratorFactory();
		keyInfoGeneratorFactory.setEmitEntityCertificate(true);
		KeyInfoGenerator keyInfoGenerator = keyInfoGeneratorFactory.newInstance();

		Signature signature = OpenSAMLUtils.buildSAMLObject(Signature.class);
		SignatureSigningParameters parameters = new SignatureSigningParameters();
		parameters.setKeyInfoGenerator(keyInfoGenerator);
		parameters.setSigningCredential(credential);
		parameters.setSignatureAlgorithm(SignatureConstants.ALGO_ID_SIGNATURE_RSA_SHA256);
		parameters.setSignatureCanonicalizationAlgorithm(canonicalizationAlgorithm);
		SignatureSupport.prepareSignatureParams(signature, parameters);
		SignatureSupport.signObject(obj, parameters);

		Document document = parserPool.newDocument();

		Marshaller out = XMLObjectProviderRegistrySupport.getMarshallerFactory().getMarshaller(obj);
		out.marshall(obj, document);

		Transformer transformer = TransformerFactory.newInstance().newTransformer();
		StringWriter writer = new StringWriter();
		StreamResult streamResult = new StreamResult(writer);
		DOMSource source = new DOMSource(document);
		transformer.transform(source, streamResult);
		writer.close();

		return writer.toString();
	}

	private <T> T requireNonNull(T obj, Supplier<String> errorMessage) {
		if (obj == null) {
			throw new SAMLValidationExcpetion(errorMessage.get());
		}
		return obj;
	}

	private String requireNonEmpty(String str, Supplier<String> errorMessage) {
		if (str == null || str.isEmpty()) {
			throw new SAMLValidationExcpetion(errorMessage.get());
		}
		return str;
	}

	private <T> List<T> requireNonEmpty(List<T> list, Supplier<String> errorMessage) {
		if (requireNonNull(list, errorMessage).size() < 1) {
			throw new SAMLValidationExcpetion(errorMessage.get());
		}
		return list;
	}

	private void requireNotOnOrAfter(Instant notOnOrAfter) {
		requireNonNull(notOnOrAfter, () -> "NotOnOrAfter attribute is missing");
		if (System.currentTimeMillis() - notOnOrAfter.toEpochMilli() > ACCEPT_LEEWAY) {
			throw new SAMLValidationExcpetion("Assertion is expired due to NotOnOrAfter");
		}
	}

	private void requireNotBefore(Instant notBefore) {
		requireNonNull(notBefore, () -> "NotBefore attribute is missing");
		if (System.currentTimeMillis() - notBefore.toEpochMilli() < -ACCEPT_LEEWAY) {
			throw new SAMLValidationExcpetion("Assertion is not usable yet due to NotBefore");
		}
	}

	private void requireIssueInstant(Instant issueInstant, String context) {
		requireNonNull(issueInstant, () -> "IssueInstant attribute is missing in " + context);
		long diff = System.currentTimeMillis() - issueInstant.toEpochMilli();

		if (diff > ACCEPT_LEEWAY) {
			throw new SAMLValidationExcpetion(context + " is expired due to IssueInstant");
		}
		if (diff < -ACCEPT_LEEWAY) {
			throw new SAMLValidationExcpetion(context + " is not usable yet due to IssueInstant");
		}
	}

}
