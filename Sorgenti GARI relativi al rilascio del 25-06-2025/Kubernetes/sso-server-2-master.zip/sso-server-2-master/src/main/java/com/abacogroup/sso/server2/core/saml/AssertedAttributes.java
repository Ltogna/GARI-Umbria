package com.abacogroup.sso.server2.core.saml;

public interface AssertedAttributes {
	boolean isSuccess();

	<T> T get(String name);

}
