package com.abacogroup.sso.server2.resources;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import com.abacogroup.sso.server2.core.Sso1CompatibilityService;
import com.codahale.metrics.annotation.Timed;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@Timed
@Path("{tenant}/public/v1/sso1-compat/sso")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Tenant aware APIs", description = "API that works on tenants")
public class Sso1CompatibilityResource implements TenantCheckable {
	private Sso1CompatibilityService compatService;

	public Sso1CompatibilityResource(Sso1CompatibilityService compatService) {
		this.compatService = compatService;
	}

	@POST
	@Operation(summary = "Get the current user details", description = "Get the current logged in user details")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public void getFunctionResultPost(@PathParam("tenant") String tenant, @Context HttpServletRequest request, @Context HttpServletResponse response,
			MultivaluedMap<String, String> formParams)
			throws IOException, NoSuchAlgorithmException {
		String contextPath = request.getContextPath();
		Cookie[] cookies = request.getCookies();
		Map<String, String[]> params = convertMultivaluedMapToMap(formParams);
		compatService.dispatchRequest(params, response, cookies, contextPath);
	}

	@GET
	@Operation(summary = "Get the current user details", description = "Get the current logged in user details")
	@Produces(MediaType.TEXT_PLAIN)
	public void getFunctionResultGet(@PathParam("tenant") String tenant, @Context HttpServletRequest request, @Context HttpServletResponse response)
			throws IOException, NoSuchAlgorithmException {
		String contextPath = request.getContextPath();
		Map<String, String[]> params = request.getParameterMap();
		Cookie[] cookies = request.getCookies();
		compatService.dispatchRequest(params, response, cookies, contextPath);
	}

	private Map<String, String[]> convertMultivaluedMapToMap(MultivaluedMap<String, String> formParams) {
		Map<String, String[]> params = new HashMap<>(formParams.size());

		String[] values;
		for (Entry<String, List<String>> entry : formParams.entrySet()) {
			if (entry.getValue() != null) {
				values = entry.getValue().toArray(new String[0]);
				params.put(entry.getKey(), values);
			}
		}

		return params;
	}
}
