package com.abacogroup.sso.server2.core.bundle;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.sso.server2.core.bundle.model.ParametersConfigMessage;
import com.abacogroup.sso.server2.db.ConfigDAO;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Map;

public class Sso2ParametersConfigProcessor extends AbstractConfigProcessor{
	private final Sso1DAO ssoDAO;

	public Sso2ParametersConfigProcessor(ConfigDAO configDAO, Sso1DAO ssoDAO, ObjectMapper objectMapper) {
		super(configDAO, objectMapper);
		this.ssoDAO = ssoDAO;
	}

	@Override
	public String getDomainName() {
		return "parameters";
	}

	@Override
	protected void onMessageInTransaction(ConfigDAO dao, ConfigDataMessage message) {
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> file.getAbsolutePath().endsWith(".json"))
				.forEach(file -> processFile(message.getTenantId(), file));
	}

	private void processFile(String tenantId, File file) {
		ParametersConfigMessage message;
		try {
			message = objectMapper.readValue(file, ParametersConfigMessage.class);
		} catch (IOException e) {
			throw new IllegalStateException("Error processing file " + file.getName() + " for tenant " + tenantId, e);
		}

		if (file.getAbsolutePath().endsWith(".delete.json")) {
			doDelete( message);
		} else {
			doInsertOrUpdate(message);
		}
	}

	void doInsertOrUpdate(ParametersConfigMessage message) {
		if (message ==null) {
			return;
		}

		Map<String, String> parameters = message.getParameters();

		if (parameters == null || parameters.isEmpty()){
			return;
		}

		this.ssoDAO.deleteAllParameters();
		this.ssoDAO.addParameters(parameters);
	}

	void doDelete(ParametersConfigMessage message) {
		if (message ==null) {
			return;
		}

		Map<String, String> parameters = message.getParameters();

		if (parameters == null || parameters.isEmpty()){
			return;
		}

		Map<String, String> currentParameters = this.ssoDAO.getSsoParameters();

		for (String key : parameters.keySet()) {
			currentParameters.remove(key);
		}

		this.ssoDAO.deleteAllParameters();
		this.ssoDAO.addParameters(currentParameters);
	}
}
