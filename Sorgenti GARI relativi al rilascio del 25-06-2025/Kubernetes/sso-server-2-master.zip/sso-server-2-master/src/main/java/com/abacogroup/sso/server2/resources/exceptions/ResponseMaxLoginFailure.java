package com.abacogroup.sso.server2.resources.exceptions;

import javax.ws.rs.core.Response;

public enum ResponseMaxLoginFailure implements Response.StatusType {
   OK(200, "OK"),
   MAXLOGINFAILURE(401, "Max Login Failure");

   private final int code;
   private final String reason;
   private final Response.Status.Family family;

   private ResponseMaxLoginFailure(int statusCode, String reasonPhrase) {
      this.code = statusCode;
      this.reason = reasonPhrase;
      this.family = javax.ws.rs.core.Response.Status.Family.familyOf(statusCode);
   }

   @Override
   public Response.Status.Family getFamily() {
      return this.family;
   }

   @Override
   public int getStatusCode() {
      return this.code;
   }

   @Override
   public String getReasonPhrase() {
      return this.toString();
   }

   @Override
   public String toString() {
      return this.reason;
   }

}
