package com.abacogroup.sso.server2.views.saml;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.dropwizard.jersey.errors.ErrorMessage;
import io.dropwizard.jersey.validation.ValidationErrorMessage;
import io.dropwizard.views.common.View;

public class ErrorView extends View {

	private int errorStatus;
	private List<String> errorMessage;

	public ErrorView(ErrorMessage error) {
		super("error-view.mustache");

		this.errorMessage = new ArrayList<>(Collections.singletonList(error.getMessage()));
		this.errorStatus = error.getCode();
	}

	public ErrorView(ValidationErrorMessage error) {
		super("error-view.mustache");

		this.errorMessage = error.getErrors();
		this.errorStatus = 500;
	}

	public int getErrorStatus() {
		return errorStatus;
	}

	public List<String> getErrorMessage() {
		return errorMessage;
	}
}
