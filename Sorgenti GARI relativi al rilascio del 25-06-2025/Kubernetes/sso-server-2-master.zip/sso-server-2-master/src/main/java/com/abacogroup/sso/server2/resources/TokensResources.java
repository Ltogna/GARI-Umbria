package com.abacogroup.sso.server2.resources;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.Suspended;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.server.ManagedAsync;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.dropwizard.auth.sso2.UserFunction;
import com.abacogroup.sso.server2.api.ExchangeSso1Request;
import com.abacogroup.sso.server2.api.Jwks;
import com.abacogroup.sso.server2.api.LoginCredentials;
import com.abacogroup.sso.server2.api.LoginResponse;
import com.abacogroup.sso.server2.api.RefreshTokensResponse;
import com.abacogroup.sso.server2.api.RefreshTokensResquest;
import com.abacogroup.sso.server2.api.WhoAmIResponse;
import com.abacogroup.sso.server2.core.KeysService;
import com.abacogroup.sso.server2.core.UserService;
import com.abacogroup.sso.server2.db.ntt.SsoUser;
import com.abacogroup.sso.server2.exceptions.TenantMismatchException;
import com.abacogroup.sso.server2.resources.exceptions.UnauthorizedException;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;

@Timed
@Path("/api/v1")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Legacy APIs (all but /api/v1/certs)", description = "Deprecated, backwards compatibility only, use the new tenant aware version of these APIs")
public class TokensResources {
	private static final String DEFAULT_TENANT = "_";

	private UserService userService;
	private KeysService keysService;

	public TokensResources(UserService userService, KeysService keysService) {
		this.userService = userService;
		this.keysService = keysService;
	}

	@POST
	@Path("/login")
	public LoginResponse login(@NotNull @Valid LoginCredentials credentials, @Context HttpServletRequest requestServlet) {
		return userService.login(DEFAULT_TENANT, credentials, requestServlet.getRemoteAddr());
	}

	@POST
	@Path("/proxy-login/{service}")
	@SuppressWarnings("removal")
	public LoginResponse proxyLogin(@PathParam("service") String serviceId,
			@NotNull @Valid LoginCredentials credentials,
			@Context HttpServletRequest requestServlet) {
		return userService.proxyLogin(serviceId, credentials, requestServlet.getRemoteAddr());
	}

	@POST
	@Path("/refresh")
	public RefreshTokensResponse refresh(@NotNull @Valid RefreshTokensResquest request) {
		return userService.refresh(DEFAULT_TENANT, request);
	}

	@GET
	@Path("/certs")
	public Jwks getCerts() {
		return keysService.getPublicKeysAsJwks();
	}

	@POST
	@ManagedAsync
	@Path("/exchange-sso1")
	@Deprecated(forRemoval = true)
	public void exchangeSso1(@Suspended AsyncResponse response, @NotNull @Valid ExchangeSso1Request request) {
		response.setTimeout(5, TimeUnit.SECONDS);
		try {
			response.resume(userService.exchangeSsoToken(request));
		} catch (Throwable t) {
			response.resume(t);
		}
	}

	@POST
	@ManagedAsync
	@Path("/exchange-login-token")
	public void exchangeLoginToken(@Suspended AsyncResponse response, @NotNull @Valid ExchangeSso1Request request) {
		response.setTimeout(5, TimeUnit.SECONDS);
		try {
			response.resume(userService.exchangeSsoToken(request));
		} catch (Throwable t) {
			response.resume(t);
		}
	}

	@GET
	@Path("/who-am-i")
	public WhoAmIResponse whoAmI(@Parameter(hidden = true) @Auth User user) {
		SsoUser ssoUser = this.userService.getUser(user.getTenant(), user.getName())
				.orElseThrow(UnauthorizedException::new);
		return new WhoAmIResponse(ssoUser);
	}

	@GET
	@Path("/user-functions")
	public @NotNull List<UserFunction> getUserFunctions(@Parameter(hidden = true) @Auth User user) {
		checkTenant(user);
		return userService.getUserFunctions(DEFAULT_TENANT, user.getName());
	}

	@GET
	@Path("/user-contexts")
	public @NotNull List<String> getUserContexts(@Parameter(hidden = true) @Auth User user) {
		checkTenant(user);
		return userService.getUserContexts(DEFAULT_TENANT, user.getName());
	}

	@GET
	@Path("/user-properties")
	public @NotNull Map<String, String> getUserProperties(@Parameter(hidden = true) @Auth User user) {
		checkTenant(user);
		return userService.getUserProperties(DEFAULT_TENANT, user.getName());
	}

	@GET
	@Path("/proxy-login/services")
	public @NotNull List<String> getProxyLoginServicesAvailable(@QueryParam("filterBy") List<String> filterBy) {
		if (filterBy.isEmpty()) {
			return new ArrayList<>(this.userService.proxyLoginExecutorMap.keySet());
		}
		return this.userService.proxyLoginExecutorMap.keySet().stream().filter(k -> filterBy.contains(k))
				.collect(Collectors.toList());
	}

	private void checkTenant(User user) {
		if (!DEFAULT_TENANT.equalsIgnoreCase(user.getTenant())) {
			throw new TenantMismatchException(
					"Tenant: '" + DEFAULT_TENANT + "' is not equals to user tenant: '" + user.getTenant() + "'");
		}
	}

}
