package com.abacogroup.sso.server2.api;

import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;

import org.apache.commons.lang3.StringUtils;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateUserRequestInternal {

	@NotEmpty
	@Schema(description = "The user ID")
	private String userId;

	@NotEmpty
	@Schema(description = "The password")
	private String password;

	@NotEmpty
	@Schema(description = "The tenant ID")
	private String tenant;

	@NotEmpty
	@Schema(description = "The username")
	private String username;

	@Schema(description = "The user description")
	private String description;

	@Schema(description = "The date format", example = "dd/MM/yyyy")
	private String dateFormat;

	@Schema(description = "The language", example = "en")
	private String language;


	@NotEmpty
	@Schema(description = "The user roles")
	private List<String> roleNames;

	@NotEmpty
	@Schema(description = "The user contexts")
	private List<String> contexts;

	@Schema(description = "The user properties")
	private Map<String, String> userProperties;

	@Nullable
	@Schema(description = "If true, automatically add any missing contexts that comes from granted permissions")
	private Boolean alignContextToRoles;
	
	@Schema(description = "key for OTP", example = "secretaaaa")
	private String twoFactorAuthKey;

	public CreateUserRequestInternal() {
		this.tenant = "_";
	}
	
	public CreateUserRequestInternal(@NotEmpty String userId, @NotEmpty String password, @NotEmpty String tenant,
			@NotEmpty String username, String description, String dateFormat, String language,
			@NotEmpty List<String> roleNames,
			@NotEmpty List<String> contexts, Map<String, String> userProperties, Boolean alignContextToRoles) {
		this.userId = userId.toUpperCase();
		this.password = password;
		this.tenant = StringUtils.isBlank(tenant) ? "_" : tenant;
		this.username = StringUtils.isBlank(username) ? userId.toUpperCase() : username.toUpperCase();
		this.description = description;
		this.dateFormat = dateFormat == null ? "dd/MM/yyyy" : dateFormat;
		this.language = language == null ? "en" : language;
		this.roleNames = roleNames;
		this.contexts = contexts;
		this.userProperties = userProperties;
		this.alignContextToRoles = alignContextToRoles;
	}
	
	
	
	
	public CreateUserRequestInternal(@NotEmpty String userId, @NotEmpty String password, @NotEmpty String tenant,
			@NotEmpty String username, String description, String dateFormat, String language,
			@NotEmpty List<String> roleNames,
			@NotEmpty List<String> contexts, Map<String, String> userProperties, Boolean alignContextToRoles,
			@NotEmpty String twoFactorAuthKey) {
		this.userId = userId.toUpperCase();
		this.password = password;
		this.tenant = StringUtils.isBlank(tenant) ? "_" : tenant;
		this.username = StringUtils.isBlank(username) ? userId.toUpperCase() : username.toUpperCase();
		this.description = description;
		this.dateFormat = dateFormat == null ? "dd/MM/yyyy" : dateFormat;
		this.language = language == null ? "en" : language;
		this.roleNames = roleNames;
		this.contexts = contexts;
		this.userProperties = userProperties;
		this.alignContextToRoles = alignContextToRoles;
		this.twoFactorAuthKey = twoFactorAuthKey;
	}

}
