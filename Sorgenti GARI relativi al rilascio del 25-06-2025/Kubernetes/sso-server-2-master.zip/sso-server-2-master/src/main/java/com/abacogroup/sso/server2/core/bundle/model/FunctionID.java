package com.abacogroup.sso.server2.core.bundle.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FunctionID implements Comparable<FunctionID> {
	private String context;
	private String code;

	@Override
	public int compareTo(FunctionID o) {
		int ret = 0;
		ret = nvl(context).compareTo(nvl(o.context));
		if (ret == 0) {
			ret = nvl(code).compareTo(nvl(o.code));
		}

		return ret;
	}

	private String nvl(String str) {
		return str == null ? "" : str;
	}

}
