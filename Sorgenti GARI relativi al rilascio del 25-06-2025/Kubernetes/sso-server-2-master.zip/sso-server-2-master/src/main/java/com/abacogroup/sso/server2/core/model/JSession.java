package com.abacogroup.sso.server2.core.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.OffsetDateTime;

@AllArgsConstructor
@Data
public class JSession {
    private String userId;
    private OffsetDateTime dt_delete;
}
