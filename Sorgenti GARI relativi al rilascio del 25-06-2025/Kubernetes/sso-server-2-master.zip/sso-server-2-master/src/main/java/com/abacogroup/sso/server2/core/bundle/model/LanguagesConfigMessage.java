package com.abacogroup.sso.server2.core.bundle.model;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LanguagesConfigMessage {
	private Map<String, List<I18nLang>> languages;
}
