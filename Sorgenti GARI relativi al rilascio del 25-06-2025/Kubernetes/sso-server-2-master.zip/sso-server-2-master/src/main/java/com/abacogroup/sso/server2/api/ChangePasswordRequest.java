package com.abacogroup.sso.server2.api;

import javax.validation.constraints.NotEmpty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class ChangePasswordRequest {
	@NotEmpty
	@Schema(description = "The old password")
	private String oldPassword;

	@NotEmpty
	@Schema(description = "The new password")
	private String newPassword;
}
