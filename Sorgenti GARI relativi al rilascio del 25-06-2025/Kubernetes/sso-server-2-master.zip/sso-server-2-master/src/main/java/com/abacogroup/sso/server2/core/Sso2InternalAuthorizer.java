package com.abacogroup.sso.server2.core;

import javax.ws.rs.container.ContainerRequestContext;

import org.checkerframework.checker.nullness.qual.Nullable;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.dropwizard.auth.sso2.UserFunction;
import com.abacogroup.sso.server2.db.Sso1DAO;

import io.dropwizard.auth.Authorizer;

public class Sso2InternalAuthorizer implements Authorizer<User> {
	private Sso1DAO sso1DAO;

	public Sso2InternalAuthorizer(Sso1DAO sso1DAO) {
		this.sso1DAO = sso1DAO;
	}

	@Override
	public boolean authorize(User principal, String role, @Nullable ContainerRequestContext requestContext) {
		int userFunctionsCount = this.sso1DAO.getUserFunctionsCount(principal.getTenant(), principal.getName(), UserFunction.fromPipeSeparatedString(role));
		return userFunctionsCount > 0;
	}
}
