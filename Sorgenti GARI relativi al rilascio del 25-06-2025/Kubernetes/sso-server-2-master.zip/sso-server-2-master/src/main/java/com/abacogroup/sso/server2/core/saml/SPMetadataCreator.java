package com.abacogroup.sso.server2.core.saml;

import java.io.StringWriter;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.opensaml.core.xml.config.XMLObjectProviderRegistrySupport;
import org.opensaml.core.xml.io.Marshaller;
import org.opensaml.saml.common.xml.SAMLConstants;
import org.opensaml.saml.saml2.metadata.AssertionConsumerService;
import org.opensaml.saml.saml2.metadata.AttributeConsumingService;
import org.opensaml.saml.saml2.metadata.EntityDescriptor;
import org.opensaml.saml.saml2.metadata.KeyDescriptor;
import org.opensaml.saml.saml2.metadata.NameIDFormat;
import org.opensaml.saml.saml2.metadata.RequestedAttribute;
import org.opensaml.saml.saml2.metadata.SPSSODescriptor;
import org.opensaml.saml.saml2.metadata.ServiceName;
import org.opensaml.saml.saml2.metadata.SingleLogoutService;
import org.opensaml.security.credential.UsageType;
import org.opensaml.security.x509.X509Credential;
import org.opensaml.xmlsec.SignatureSigningParameters;
import org.opensaml.xmlsec.keyinfo.KeyInfoGenerator;
import org.opensaml.xmlsec.keyinfo.impl.X509KeyInfoGeneratorFactory;
import org.opensaml.xmlsec.signature.Signature;
import org.opensaml.xmlsec.signature.support.SignatureConstants;
import org.opensaml.xmlsec.signature.support.SignatureSupport;
import org.w3c.dom.Document;

import net.shibboleth.utilities.java.support.xml.ParserPool;

public class SPMetadataCreator {
	private ParserPool parserPool;
	private final String entityId;
	private final String assertionConsumerUri;
	private final String singleLogoutUri;

	public SPMetadataCreator(ParserPool parserPool, String entityId, String assertionConsumerUri, String singleLogoutUri) {
		this.parserPool = parserPool;
		this.entityId = entityId;
		this.assertionConsumerUri = assertionConsumerUri;
		this.singleLogoutUri = singleLogoutUri;
	}

	public void create(X509Credential x509, String[] requestAttributes) throws Exception {
		EntityDescriptor spEntityDescriptor = OpenSAMLUtils.buildSAMLObject(EntityDescriptor.class);
		spEntityDescriptor.setEntityID(entityId);

		SPSSODescriptor spSSODescriptor = OpenSAMLUtils.buildSAMLObject(SPSSODescriptor.class);
		spSSODescriptor.setWantAssertionsSigned(true);
		spSSODescriptor.setAuthnRequestsSigned(true);

		////

		X509KeyInfoGeneratorFactory keyInfoGeneratorFactory = new X509KeyInfoGeneratorFactory();
		keyInfoGeneratorFactory.setEmitEntityCertificate(true);
		KeyInfoGenerator keyInfoGenerator = keyInfoGeneratorFactory.newInstance();

		KeyDescriptor encKeyDescriptor = OpenSAMLUtils.buildSAMLObject(KeyDescriptor.class);

		encKeyDescriptor.setUse(UsageType.ENCRYPTION); // Set usage

		// Generating key info. The element will contain the public key. The key
		// is used to by the IDP to encrypt data
		encKeyDescriptor.setKeyInfo(keyInfoGenerator.generate(x509));
		spSSODescriptor.getKeyDescriptors().add(encKeyDescriptor);

		KeyDescriptor signKeyDescriptor = OpenSAMLUtils.buildSAMLObject(KeyDescriptor.class);

		signKeyDescriptor.setUse(UsageType.SIGNING); // Set usage

		// Generating key info. The element will contain the public key. The key
		// is used to by the IDP to verify signatures
		signKeyDescriptor.setKeyInfo(keyInfoGenerator.generate(x509));
		spSSODescriptor.getKeyDescriptors().add(signKeyDescriptor);

		////

		// Request transient pseudonym
		NameIDFormat nameIDFormat = OpenSAMLUtils.buildSAMLObject(NameIDFormat.class);
		nameIDFormat.setURI("urn:oasis:names:tc:SAML:2.0:nameid-format:transient");
		spSSODescriptor.getNameIDFormats().add(nameIDFormat);

		////
		// ASSERTION CONSUMER
		AssertionConsumerService assertionConsumerService = OpenSAMLUtils
				.buildSAMLObject(AssertionConsumerService.class);
		assertionConsumerService.setIndex(0);
		assertionConsumerService.setBinding(SAMLConstants.SAML2_POST_BINDING_URI);
		assertionConsumerService.setIsDefault(true);
		assertionConsumerService.setLocation(assertionConsumerUri);
		spSSODescriptor.getAssertionConsumerServices().add(assertionConsumerService);

		////
		// SINGLE SIGNOUT
		SingleLogoutService logoutService = OpenSAMLUtils.buildSAMLObject(SingleLogoutService.class);
		logoutService.setLocation(singleLogoutUri);
		logoutService.setBinding(SAMLConstants.SAML2_POST_BINDING_URI);
		// ResponseLocation is optional for SPID
		spSSODescriptor.getSingleLogoutServices().add(logoutService);

		////
		// AttributeConsumingService
		AttributeConsumingService attrConsService = OpenSAMLUtils.buildSAMLObject(AttributeConsumingService.class);
		attrConsService.setIndex(0);

		ServiceName serviceName = OpenSAMLUtils.buildSAMLObject(ServiceName.class);
		serviceName.setValue("Set 0");
		attrConsService.getNames().add(serviceName);

		// String[] requestAttributes = { "email", "fiscalNumber" };
		RequestedAttribute ra;
		for (String a : requestAttributes) {
			ra = OpenSAMLUtils.buildSAMLObject(RequestedAttribute.class);
			ra.setName(a);
			attrConsService.getRequestedAttributes().add(ra);
		}

		spSSODescriptor.getAttributeConsumingServices().add(attrConsService);

		////

		spSSODescriptor.addSupportedProtocol(SAMLConstants.SAML20P_NS);

		spEntityDescriptor.getRoleDescriptors().add(spSSODescriptor);

		Signature signature = OpenSAMLUtils.buildSAMLObject(Signature.class);

		SignatureSigningParameters parameters = new SignatureSigningParameters();
		parameters.setKeyInfoGenerator(keyInfoGenerator);
		parameters.setSigningCredential(x509);
		parameters.setSignatureAlgorithm(SignatureConstants.ALGO_ID_SIGNATURE_RSA);
		parameters.setSignatureCanonicalizationAlgorithm(SignatureConstants.ALGO_ID_C14N11_OMIT_COMMENTS);
		SignatureSupport.prepareSignatureParams(signature, parameters);
		SignatureSupport.signObject(spEntityDescriptor, parameters);

		Document document = parserPool.newDocument();

		Marshaller out = XMLObjectProviderRegistrySupport.getMarshallerFactory().getMarshaller(spEntityDescriptor);
		out.marshall(spEntityDescriptor, document);

		Transformer transformer = TransformerFactory.newInstance().newTransformer();
		StringWriter stringWriter = new StringWriter();
		StreamResult streamResult = new StreamResult(stringWriter);
		DOMSource source = new DOMSource(document);
		transformer.transform(source, streamResult);
		stringWriter.close();
		String metadataXML = stringWriter.toString();

		System.out.println(metadataXML);
	}

}
