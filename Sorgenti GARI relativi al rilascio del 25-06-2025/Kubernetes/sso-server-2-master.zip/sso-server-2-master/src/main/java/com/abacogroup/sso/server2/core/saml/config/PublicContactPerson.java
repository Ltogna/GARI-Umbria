package com.abacogroup.sso.server2.core.saml.config;

import javax.validation.constraints.NotEmpty;

import lombok.Data;

@Data
public class PublicContactPerson implements ContactPersonConfig {
	@NotEmpty
	private String ipaCode;
	@NotEmpty
	private String email;
	private String vatNumber;
	private String phoneNumber;
	private final boolean isPublic = true;
}
