package com.abacogroup.sso.server2.api;

import java.time.OffsetDateTime;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class ApiKeyRequest {
	@NotNull
	@Schema(description = "Valid from")
	private OffsetDateTime validFrom;

	@NotNull
	@Schema(description = "Valid to")
	private OffsetDateTime validTo;

	@NotNull
	@Schema(description = "A description for the API key")
	private String description;
}
