package com.abacogroup.sso.server2.core.model;

import java.security.SecureRandom;
import java.time.OffsetDateTime;

import lombok.Builder;
import lombok.Getter;
import lombok.NonNull;

@Getter
@Builder
public class CreateLoginTokenParams {
	private static final SecureRandom RANDOM = new SecureRandom();

	@NonNull
	private final String userId;

	@NonNull
	private final String tenant;

	@NonNull
	private final String username;

	@NonNull
	private String session;

	@NonNull
	private final OffsetDateTime start;

	@NonNull
	private final OffsetDateTime end;

	// It is not needed for this ID to be super-strong; it is part of an RSA signed JET token so it cannot be used by itself
	// However, we introduce a bit of randomness so it cannot be guessed trivially
	public static String createSessionID() {
		long cnt = RANDOM.nextInt() & 0xffffffffL; // 32bits of randomness
		return Long.toString(System.currentTimeMillis(), 36) + '.' + Long.toString(cnt, 36);
	}

}
