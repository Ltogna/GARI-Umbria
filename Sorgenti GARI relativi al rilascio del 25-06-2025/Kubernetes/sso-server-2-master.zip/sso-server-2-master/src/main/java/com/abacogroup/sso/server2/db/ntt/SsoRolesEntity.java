package com.abacogroup.sso.server2.db.ntt;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SsoRolesEntity {
	private Long roleId;
	private String tenantId;
	private String name;
	private String descr;
}
