package com.abacogroup.sso.server2.core.passwords;

import static java.util.stream.Collectors.toList;

import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.abacogroup.sso.server2.core.passwords.impl.Argon2IdPasswordHasher;
import com.abacogroup.sso.server2.core.passwords.impl.Md5PasswordHasher;
import com.abacogroup.sso.server2.core.passwords.impl.RunInExecutorPasswordHasher;

public class PasswordHasherFactory implements AutoCloseable {

	private static final int NUM_THREADS = 4;

	// We want to limit the amount of resources we use, especially RAM
	private ExecutorService executorService;
	private PasswordHasher defaultPasswordHasher;

	public PasswordHasherFactory(String defaultAlgorithmName) {
		executorService = Executors.newFixedThreadPool(NUM_THREADS);
		defaultPasswordHasher = getFromAlgorithm(defaultAlgorithmName);
		if (defaultPasswordHasher.isResourceIntensive()) {
			defaultPasswordHasher = new RunInExecutorPasswordHasher(defaultPasswordHasher, executorService);
		}
	}

	@Override
	public synchronized void close() {
		if (executorService != null && !executorService.isShutdown()) {
			executorService.shutdownNow();
		}
	}

	public PasswordHasher getDefault() {
		return defaultPasswordHasher;
	}

	public PasswordHasher getFromAlgorithm(String name) {
		PasswordHasher hasher = null;
		switch (name) {
			case "":
			case Md5PasswordHasher.NAME:
				hasher = new Md5PasswordHasher();
				break;
			case Argon2IdPasswordHasher.NAME:
				hasher = new Argon2IdPasswordHasher();
				break;
		}

		// $no_log_password$
		if (hasher == null) {
			throw new NoSuchPasswordHasherException(name);
		}

		if (hasher.isResourceIntensive()) {
			hasher = new RunInExecutorPasswordHasher(hasher, executorService);
		}

		return hasher;
	}

	public PasswordHasher getFromEncodedPassword(String encoded) {
		if (encoded == null || encoded.isEmpty()) {
			return null;
		}

		String[] tokens = getTokens(encoded);
		if (!"".equals(tokens[0])) {
			return getFromAlgorithm("");
		}

		// Serialization format is: $algorithm$param1$param2$paramN$hash

		PasswordHasher passwordHasher = getFromAlgorithm(tokens[1]);
		passwordHasher.setParams(Arrays.stream(tokens)
				.skip(2)
				.limit(tokens.length - 3L) // Remove first empty token, algorithm and last token (hash)
				.collect(toList()));

		return passwordHasher;
	}

	private String[] getTokens(String hash) {
		return hash.split("\\$");
	}

}
