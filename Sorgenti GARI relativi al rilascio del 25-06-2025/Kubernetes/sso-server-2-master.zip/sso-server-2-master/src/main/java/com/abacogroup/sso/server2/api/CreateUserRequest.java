package com.abacogroup.sso.server2.api;

import java.util.UUID;

import javax.validation.constraints.NotEmpty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(toBuilder = true)
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
public class CreateUserRequest extends UpdateUserRequest {

	@NotEmpty
	@Schema(description = "The username")
	private String username;

	public static String createUserId(String tenantId, String username) {
		String id = tenantId + '/' + username;
		if (id.length() > 80) {
			id = tenantId + '/' + UUID.randomUUID().toString();
		}

		return id.toUpperCase();
	}
}
