package com.abacogroup.sso.server2;

import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.abacogroup.sso.server2.core.RabbitMqConfig;
import com.abacogroup.sso.server2.core.saml.config.SamlServiceProviderConfig;
import com.abacogroup.sso.server2.sdk.proxylogin.ProxyLoginExecutorConfig;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.dropwizard.core.Configuration;
import io.dropwizard.db.DataSourceFactory;

public class SSOServer2Configuration extends Configuration {

	@Valid
	@NotNull
	private DataSourceFactory database;

	@NotEmpty
	private String publicKeysDir;

	@Nullable
	@Deprecated(forRemoval = true)
	private String privateKeyDir;

	@Nullable
	private String tasksAuthSecret;

	@Nullable
	private String publicKeyEncryptSecret;

	@NotEmpty
	private String sso1Url;

	@Nullable
	private List<SamlServiceProviderConfig> samlServiceProviders;

	@Nullable
	private Map<String, ProxyLoginExecutorConfig> proxyLoginExecutors;

	@Nullable
	private RabbitMqConfig rabbitmqConfig;

	@NotEmpty
	private String bundlesDir = "/bundles";

	private String totpIssuer;

	private String totpPeriod;

	private boolean updateDigest;

	public List<SamlServiceProviderConfig> getSamlServiceProviders() {
		return samlServiceProviders;
	}

	public void setSamlServiceProviders(List<SamlServiceProviderConfig> samlServiceProviders) {
		this.samlServiceProviders = samlServiceProviders;
	}

	@Nullable
	public Map<String, ProxyLoginExecutorConfig> getProxyLoginExecutors() {
		return proxyLoginExecutors;
	}

	public void setProxyLoginExecutors(@Nullable Map<String, ProxyLoginExecutorConfig> proxyLoginExecutors) {
		this.proxyLoginExecutors = proxyLoginExecutors;
	}

	public String getSso1Url() {
		return sso1Url;
	}

	public void setSso1Url(String sso1BaseUrl) {
		this.sso1Url = sso1BaseUrl;
	}

	/**
	 * @deprecated
	 */
	@Deprecated(forRemoval = true)
	public String getPrivateKeyDir() {
		return privateKeyDir;
	}

	public String getPublicKeysDir() {
		return publicKeysDir;
	}

	@JsonProperty("database")
	public void setDataSourceFactory(DataSourceFactory factory) {
		this.database = factory;
	}

	@JsonProperty("database")
	public DataSourceFactory getDataSourceFactory() {
		return database;
	}

	public String getTotpIssuer() {
		return totpIssuer == null ? "ABACO TOTP" : totpIssuer;
	}

	public Integer getTotpPeriod() {
		if(totpPeriod==null){
			return 30;
		}
		else{
			return Integer.parseInt(totpPeriod);
		}
	}

	public boolean isUpdateDigest() {
		return updateDigest;
	}

	public void setUpdateDigest(boolean updateDigest) {
		this.updateDigest = updateDigest;
	}

	public String getTasksAuthSecret() {
		return tasksAuthSecret;
	}

	public void setTasksAuthSecret(String tasksAuthSecret) {
		this.tasksAuthSecret = tasksAuthSecret;
	}

	public String getPublicKeyEncryptSecret() {
		return publicKeyEncryptSecret;
	}

	public void setPublicKeyEncryptSecret(String publicKeyEncryptSecret) {
		if (publicKeyEncryptSecret == null || publicKeyEncryptSecret.isEmpty()) {
			publicKeyEncryptSecret = null;
		}

		this.publicKeyEncryptSecret = publicKeyEncryptSecret;
	}

	public RabbitMqConfig getRabbitmqConfig() {
		return rabbitmqConfig;
	}

	public void setRabbitmqConfig(RabbitMqConfig rabbitmqConfig) {
		this.rabbitmqConfig = rabbitmqConfig;
	}

	public String getBundlesDir() {
		return bundlesDir;
	}

	public void setBundlesDir(String bundlesDir) {
		this.bundlesDir = bundlesDir;
	}
}
