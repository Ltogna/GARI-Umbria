package com.abacogroup.sso.server2.core;

import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.abacogroup.dropwizard.auth.sso2.Constants;
import com.abacogroup.sso.server2.api.ApiKeyLoginRequest;
import com.abacogroup.sso.server2.api.ApiKeyResponse;
import com.abacogroup.sso.server2.api.LoginCredentials;
import com.abacogroup.sso.server2.api.LoginResponse;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.abacogroup.sso.server2.db.ntt.SsoApiKeys;
import com.abacogroup.sso.server2.db.ntt.SsoUser;
import com.abacogroup.sso.server2.exceptions.ApiKeyNotFoundException;


/**
 * Service to use for apikey
 **/
public class ApiKeyService {
	private Sso1DAO ssoDAO;
	private UserService userService;

	public ApiKeyService(Sso1DAO ssoDAO, UserService userService) {
		this.ssoDAO = ssoDAO;
		this.userService = userService;
	}

	/**
	 * Create an apikey for a user
	 *
	 * @param validFrom
	 *            Date to start validation of generated apikey
	 * @param validTo
	 *            Date to end validation of generated apikey
	 * @param description
	 *            Description of apikey
	 * @param userId
	 *            User of apikey
	 * @return apikey generated
	 **/
	public String createApiKey(OffsetDateTime validFrom, OffsetDateTime validTo, String description, String userId) {
		if (validFrom == null) {
			validFrom = OffsetDateTime.now();
		}

		if (validTo == null) {
			throw new IllegalStateException("Valid to date is not set");
		}

		if (userId == null) {
			throw new IllegalStateException("User id is not set");
		}

		if (validFrom.compareTo(validTo) > 0) {
			throw new IllegalStateException(
					"Valid from date " + validFrom.toString() + " is greater then valid to date " + validTo.toString());
		}

		String apiKey = UUID.randomUUID().toString();

		SsoApiKeys ssoApiKeys = SsoApiKeys.builder()
				.apiKey(apiKey)
				.description(description)
				.userId(userId)
				.validFrom(validFrom)
				.validTo(validTo)
				.build();

		ssoDAO.insertApiKey(ssoApiKeys);

		return apiKey;
	}

	/**
	 * Delete an apikey from db
	 *
	 * @param apiKey
	 *            Apikey to delete
	 * @param userId
	 **/
	public int deleteApiKey(String apiKey, String userId) {
		return ssoDAO.deleteApiKey(apiKey, userId);
	}

	/**
	 * Get apikeys of user
	 *
	 * @param userId
	 *            Id of user
	 * @param onlyValidApiKeys
	 *            true for retrieve only valid apikeys, false for all apikeys
	 * @return List of ApiKeyResponse with the query result
	 **/
	public List<ApiKeyResponse> getApiKeysFromUserId(String userId, boolean onlyValidApiKeys) {
		if (userId == null) {
			throw new IllegalStateException("User id is not defined");
		}

		List<SsoApiKeys> apiKeys = onlyValidApiKeys ? ssoDAO.getValidUserApiKeys(userId, OffsetDateTime.now())
				: ssoDAO.getAllUserApiKeys(userId);

		List<ApiKeyResponse> result = new ArrayList<ApiKeyResponse>();
		for (SsoApiKeys ssoApiKey : apiKeys) {
			ApiKeyResponse response = ApiKeyResponse.builder()
					.apiKey(ssoApiKey.getApiKey())
					.description(ssoApiKey.getDescription())
					.validFrom(ssoApiKey.getValidFrom())
					.validTo(ssoApiKey.getValidTo())
					.build();

			result.add(response);
		}

		return result;
	}

	/**
	 * Execute a login with an apikey
	 *
	 * @param request
	 *            Apikey to use for login
	 * @return LoginResponse with info of login
	 **/
	public LoginResponse apiKeyLogin(ApiKeyLoginRequest request) {
		SsoUser user = ssoDAO.getUserInfoFromApiKey(request.getApikey())
				.orElseThrow(() -> new ApiKeyNotFoundException("Unknown api key: " + request.getApikey()));

		LoginResponse res = userService.login(user.getTenant_id(), new LoginCredentials(user.getUsername(), null), true, null);

		if (!res.getIsParentUser()) {
			OffsetDateTime now = OffsetDateTime.now();
			var token = userService.createAuthToken(res.getUser_id(), res.getUsername(), res.getTenant(), Constants.AUTH_AUDIENCE,
					now, now.plus(Duration.ofMinutes(120)));

			res.setAuth_token(token);
		}

		return res;
	}
}
