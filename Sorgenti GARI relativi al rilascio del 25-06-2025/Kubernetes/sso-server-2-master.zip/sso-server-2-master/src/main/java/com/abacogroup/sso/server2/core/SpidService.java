package com.abacogroup.sso.server2.core;

import java.security.SecureRandom;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abacogroup.dropwizard.auth.sso2.AuthenticationSupport;
import com.abacogroup.dropwizard.auth.sso2.JwtAuthenticator;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.sso.server2.api.CreateUserRequestInternal;
import com.abacogroup.sso.server2.api.SpidUser;
import com.abacogroup.sso.server2.core.passwords.PasswordHasherFactory;
import com.abacogroup.sso.server2.core.saml.AssertedAttributes;
import com.abacogroup.sso.server2.core.saml.AuthnRequestObj;
import com.abacogroup.sso.server2.core.saml.config.ReturnMode;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTCreator;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;

import io.dropwizard.auth.AuthenticationException;

public class SpidService {
	private static final Duration AUTH_DURATION = Duration.of(5, ChronoUnit.MINUTES);
	private static final String ISSUER_TRANSPORT = "ABACO_SSO2_TRANSPORT";

	private Sso1DAO ssoDAO;
	private Algorithm algorithm;
	private JwtAuthenticator jwtAuthenticator;
	private boolean updateDigest;
	private PasswordHasherFactory hasherFactory;

	public SpidService(Sso1DAO ssoDAO, Algorithm algorithm, PasswordHasherFactory hasherFactory, boolean updateDigest) {
		this.ssoDAO = ssoDAO;
		this.algorithm = algorithm;
		this.jwtAuthenticator = new JwtAuthenticator(new AuthenticationSupport(algorithm), ISSUER_TRANSPORT);
		this.hasherFactory = hasherFactory;
		this.updateDigest = updateDigest;
	}

	public void logSpidRequest(AuthnRequestObj authnRequest) {
		ssoDAO.logSpidRequest(authnRequest);
	}

	public void logSpidResponse(String response, String inResponseTo) {
		ssoDAO.logSpidResponse(response, inResponseTo);
	}

	public String createUserFromSpid(AssertedAttributes attributes, Map<String, String> dbFields, ReturnMode returnMode) {
		Map<String, String> userProperties = new HashMap<>();
		dbFields.forEach((key, value) -> {
			String attrValue = attributes.get(key);
			if (attrValue != null) {
				userProperties.putIfAbsent(value, attrValue);
			}
		});
		String password = this.generateRandomPassword(18, 48, 122);
		CreateUserRequestInternal spidUserRequest = CreateUserRequestInternal.builder()
				.userId("SPID-" + attributes.get("fiscalNumber"))
				.password(password)
				.roleNames(Arrays.asList(returnMode.getRoleName()))
				.contexts(Arrays.asList(returnMode.getContext()))
				.userProperties(userProperties)
				.build();

		this.ssoDAO.createUser(spidUserRequest, "SPID", hasherFactory, updateDigest);
		return spidUserRequest.getUserId();
	}

	public String createUserJWTFromSpid(AssertedAttributes attributes, List<String> requiredFields) {
		Map<String, String> userProperties = new HashMap<>();
		requiredFields.forEach(field -> {
			String attrValue = attributes.get(field);
			if (attrValue != null) {
				userProperties.putIfAbsent(field, attrValue);
			}
		});

		return this.createUserJWT("SPID-" + attributes.get("fiscalNumber"), userProperties);
	}

	private String generateRandomPassword(int len, int randNumOrigin, int randNumBound) {
		SecureRandom random = new SecureRandom();
		return random.ints(randNumOrigin, randNumBound + 1)
				.limit(len)
				.filter(i -> Character.isAlphabetic(i) || Character.isDigit(i))
				.collect(StringBuilder::new, StringBuilder::appendCodePoint,
						StringBuilder::append)
				.toString();
	}

	private String createUserJWT(String userId, Map<String, String> userProperties) {
		OffsetDateTime now = OffsetDateTime.now();
		JWTCreator.Builder tempJwt = JWT.create().withIssuer(ISSUER_TRANSPORT).withSubject(userId.toUpperCase())
				.withIssuedAt(new Date(now.toEpochSecond() * 1000))
				.withExpiresAt(new Date(now.plus(AUTH_DURATION).toEpochSecond() * 1000));

		for (Map.Entry<String, String> prop : userProperties.entrySet()) {
			tempJwt.withClaim(prop.getKey(), prop.getValue());
		}

		return tempJwt.sign(algorithm);
	}

	public SpidUser validateAndGetUserInfo(String userJWT, List<String> requiredFields) throws AuthenticationException {
		User user = this.jwtAuthenticator.authenticate(userJWT)
				.orElseThrow(() -> new AuthenticationException("Invalid User JWT"));

		DecodedJWT decoded = JWT.decode(userJWT);
		Map<String, String> userProperties = new HashMap<>();

		requiredFields.forEach(field -> userProperties.putIfAbsent(field, decoded.getClaim(field).asString()));

		return SpidUser.builder()
				.userId(user.getName())
				.userProperties(userProperties)
				.build();
	}
}
