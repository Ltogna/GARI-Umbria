package com.abacogroup.sso.server2.db;

import java.sql.Types;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;

import javax.ws.rs.NotFoundException;

import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.core.statement.OutParameters;
import org.jdbi.v3.sqlobject.config.KeyColumn;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterRowMapper;
import org.jdbi.v3.sqlobject.config.ValueColumn;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.OutParameter;
import org.jdbi.v3.sqlobject.statement.SqlCall;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transaction;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.dropwizard.auth.sso2.UserFunction;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.sso.server2.api.CreateUserRequestInternal;
import com.abacogroup.sso.server2.api.Language;
import com.abacogroup.sso.server2.api.RoleData;
import com.abacogroup.sso.server2.api.UserDetails;
import com.abacogroup.sso.server2.api.UserRoleData;
import com.abacogroup.sso.server2.core.model.Function;
import com.abacogroup.sso.server2.core.model.FunctionMapper;
import com.abacogroup.sso.server2.core.model.LoginStatus;
import com.abacogroup.sso.server2.core.model.Role;
import com.abacogroup.sso.server2.core.model.RolesMapper;
import com.abacogroup.sso.server2.core.passwords.PasswordHasherFactory;
import com.abacogroup.sso.server2.core.saml.AuthnRequestObj;
import com.abacogroup.sso.server2.db.ntt.SsoApiKeys;
import com.abacogroup.sso.server2.db.ntt.SsoContextFunction;
import com.abacogroup.sso.server2.db.ntt.SsoContextFunctionEntity;
import com.abacogroup.sso.server2.db.ntt.SsoUser;
import com.abacogroup.sso.server2.db.ntt.SsoUserLog;
import com.google.common.collect.ArrayListMultimap;

public interface Sso1DAO extends EnhancedSqlObject, Transactional<Sso1DAO> {
	static final String DEFAULT_TENANT = "_";

	@SqlQuery("§select_from_dual(current_timestamp)§")
	OffsetDateTime getSysdate();

	@SqlQuery("select * from sso_users where tenant_id=:tenantId and username=upper(:userName)")
	@RegisterBeanMapper(SsoUser.class)
	Optional<SsoUser> getSsoUser(@Bind("tenantId") String tenantId, @Bind("userName") String userName);

	@SqlQuery("select * from sso_users where userid=upper(:userid)")
	@RegisterBeanMapper(SsoUser.class)
	Optional<SsoUser> getSsoUser(@Bind("userid") String userid);

	@SqlQuery("select * from sso_users where tenant_id=:tenantId and <criteria>")
	@RegisterBeanMapper(SsoUser.class)
	List<SsoUser> findSsoUsers(@Bind("tenantId") String tenantId, @BindCriteria("criteria") Criteria criteria);

	@SqlQuery("select count(userid) from sso_users where userid=upper(:userid)")
	Integer getUserCount(@Bind("userid") String userId);

	@SqlQuery("select * from sso_users where parent_userid=upper(:userid) and <criteria> order by descr")
	@RegisterBeanMapper(SsoUser.class)
	void consumeChildren(@Bind("userid") String userid, @BindCriteria("criteria") Criteria citeria, Consumer<SsoUser> consumer);

	@SqlQuery("select * from sso_users where parent_userid=upper(:userid) and <criteria> order by descr")
	@RegisterBeanMapper(SsoUser.class)
	ResultIterator<SsoUser> getChildren(@Bind("userid") String userid, @BindCriteria("criteria") Criteria citeria);

	@SqlQuery("SELECT userid FROM sso_users_properties WHERE name=:fiscal_code_field AND upper(content)=upper(:fiscal_code)")
	List<String> getUserIdFromFiscalCode(@Bind("fiscal_code") String fiscalCode,
			@Bind("fiscal_code_field") String fiscalCodeField);

	@SqlQuery("select * from sso_users_log where userid=upper(:userid)")
	@RegisterBeanMapper(SsoUserLog.class)
	SsoUserLog getUserLog(@Bind("userid") String userId);

	@SqlQuery("SELECT COUNT(*) FROM NO_PASSWORD_ROULES WHERE USERID=upper(:userid)")
	int noPasswordRules(@Bind("userid") String userId);

	@Transaction
	default int addParameters(Map<String, String> parameters) {
		int count = 0;
		for (Map.Entry<String, String> entry : parameters.entrySet()) {
			this.addParameter(entry.getKey(), entry.getValue());
			count += 1;
		}
		return count;
	}

	@SqlUpdate("INSERT INTO sso_parameters(NAME, VALUE) VALUES(:key,:val)")
	void addParameter(@Bind("key") String key, @Bind("val") String val);

	@SqlUpdate("DELETE FROM sso_parameters")
	void deleteAllParameters();

	@SqlQuery("SELECT name, value FROM sso_parameters")
	@KeyColumn("name")
	@ValueColumn("value")
	Map<String, String> getSsoParameters();

	@SqlQuery("""
			SELECT su.USERID AS userId,
				   su.TENANT_ID AS tenant,
			 	   su.FL_INTERNAL AS internalUser,
			 	   su.USERNAME AS username,
			 	   su.DESCR AS description,
			       su.USR_LOCALE AS userLocale,
			       su.DATE_FORMAT AS dateFormat,
			       su.IS_LOCKED as isLocked,
			       su.CREATED_ON AS creation_date,
			       sul.LAST_LOGIN AS lastLogin_date,
			       su.PASSWORD_LAST_MODIFIED_ON AS last_login_modification_date
			     FROM SSO_USERS su, SSO_USERS_LOG sul
			    WHERE su.USERID = sul.USERID
			      AND su.TENANT_ID = :tenantId
			      AND <criteria>
			    ORDER BY su.USERNAME""")
	@RegisterBeanMapper(UserDetails.class)
	ResultIterator<UserDetails> getUsersList(@Bind("tenantId") String tenantId, @BindCriteria("criteria") Criteria criteria);

	@SqlQuery("""
			SELECT su.USERID AS userId,
				   su.TENANT_ID AS tenant,
			 	   su.FL_INTERNAL AS internalUser,
			 	   su.USERNAME AS userName,
			 	   su.DESCR AS description,
			       su.USR_LOCALE AS userLocale,
			       su.DATE_FORMAT AS dateFormat,
			       su.IS_LOCKED as isLocked,
			       su.CREATED_ON AS creation_date,
			       sul.LAST_LOGIN AS lastLogin_date,
			       su.PASSWORD_LAST_MODIFIED_ON AS last_login_modification_date
			     FROM SSO_USERS su, SSO_USERS_LOG sul
			    WHERE su.USERID = sul.USERID
			      AND su.TENANT_ID = :tenantId
			      AND su.USERNAME = :username""")
	@RegisterBeanMapper(UserDetails.class)
	UserDetails getUserByUsername(@Bind("tenantId") String tenantId, @Bind("username") String username);

	@SqlQuery("""
			select distinct cf.*
			 from sso_user_roles ur, sso_roles_functions rf, sso_context_functions cf, sso_users su
			 where su.username = upper(:username)
			 and ur.userId = su.userId
			 and su.tenant_id=:tenantId
			 and rf.role_id = ur.role_id
			 and cf.tenant_id = :tenantId
			 and cf.function_id = rf.function_id""")
	@RegisterBeanMapper(SsoContextFunctionEntity.class)
	List<SsoContextFunctionEntity> getUserFunctions(@Bind("tenantId") String tenantId, @Bind("username") String username);

	@SqlQuery("""
			SELECT count(cf.NAME)
			 FROM sso_user_roles ur, sso_roles_functions rf, sso_context_functions cf, sso_users su
			 WHERE su.username = upper(:username)
			 AND ur.userId = su.userId
			 AND su.tenant_id = :tenantId
			 AND rf.role_id = ur.role_id
			 AND cf.tenant_id = :tenantId
			 AND cf.function_id = rf.function_id
			 AND cf.name = :function_name
			 AND cf.context_id = :context_id""")
	int getUserFunctionsCount(@Bind("tenantId") String tenantId, @Bind("username") String username, @BindBean UserFunction userFunction);

	@SqlQuery("""
			select sc.contextid
			 from sso_utenti_contesti sc, sso_users su
			 where su.username = upper(:username)
			 and sc.userid = su.userid
			 and su.tenant_id = :tenantId""")
	List<String> getUserContexts(@Bind("tenantId") String tenantId, @Bind("username") String username);

	@SqlQuery("""
			select sp.name, sp.content
			 from sso_users_properties sp, sso_users su
			 where su.username = upper(:username)
			 and sp.userid = su.userid
			 and su.tenant_id = :tenantId""")
	@KeyColumn("name")
	@ValueColumn("content")
	Map<String, String> getUserProperties(@Bind("tenantId") String tenantId, @Bind("username") String username);

	@SqlQuery("""
			SELECT sc.userid, sc.contextid\s\
			  FROM sso_utenti_contesti sc\
			 WHERE <user_criteria>""")
	@KeyColumn("userid")
	@ValueColumn("contextid")
	ArrayListMultimap<String, String> getContextsForUsers(@BindCriteria("user_criteria") Criteria usersCriteria);

	// TODO move to a service
	@Transaction
	default void createUser(CreateUserRequestInternal createUserRequestInternal, String whoAmI, PasswordHasherFactory hasherFactory, boolean updateDigest) {
		String userId = createUserRequestInternal.getUserId();
		String encodedPassword = hasherFactory.getDefault().computeHash(createUserRequestInternal.getPassword());

		OffsetDateTime now = getSysdate();
		insertUser(SsoUser.builder()
				.created_on(now)
				.date_format(createUserRequestInternal.getDateFormat())
				.descr(createUserRequestInternal.getDescription())
				.fl_internal('Y')
				.is_locked('N')
				.is_parent((short) 0)
				.parent_userid(null)
				.password(encodedPassword)
				.password_last_modified_on(now)
				.tenant_id(createUserRequestInternal.getTenant())
				.userid(userId)
				.username(createUserRequestInternal.getUsername().toUpperCase())
				.usr_locale(createUserRequestInternal.getLanguage())
				.two_factor_auth_key(createUserRequestInternal.getTwoFactorAuthKey())
				.build(),
				updateDigest);

		addUserRoles(createUserRequestInternal.getRoleNames(), userId, createUserRequestInternal.getTenant(), whoAmI, false);
		alignContextWithRoles(createUserRequestInternal.getAlignContextToRoles(), createUserRequestInternal.getTenant(), userId);
		addUserContext(createUserRequestInternal.getContexts(), userId);
		addUserProperties(createUserRequestInternal.getUserProperties(), userId);
	}

	@Transaction
	default boolean insertUser(SsoUser user, boolean updateDigest) {
		if (!user.getUserid().equals(user.getUserid().toUpperCase())) {
			throw new IllegalArgumentException("userid must be uppercase");
		}
		if (!user.getUsername().equals(user.getUsername().toUpperCase())) {
			throw new IllegalArgumentException("username must be uppercase");
		}

		if (getSsoUser(user.getTenant_id(), user.getUserid()).isPresent()) {
			return false;
		}

		useHandle(h -> {
			h.createUpdate(
					"""
							INSERT INTO SSO_USERS (USERID, USERNAME, TENANT_ID, PASSWORD, DESCR, IS_LOCKED, CREATED_ON, PASSWORD_LAST_MODIFIED_ON, USR_LOCALE, DATE_FORMAT, FL_INTERNAL, PARENT_USERID, IS_PARENT, TWO_FACTOR_AUTH_KEY)
							  VALUES (:userid, :username, :tenant_id, :password, :descr, :is_locked, :created_on, :password_last_modified_on, lower(:usr_locale), :date_format, :fl_internal, :parent_userid, :is_parent, :two_factor_auth_key)""")
					.bindBean(user)
					.execute();

			h.createUpdate("INSERT INTO SSO_USERS_LOG (USERID) VALUES(:userId)")
					.bind("userId", user.getUserid())
					.execute();

			if (updateDigest) {
				callUpdateDigest(user.getPassword(), user.getUserid());
			}
		});

		return true;
	}

	@Transaction
	default boolean updateUser(SsoUser user) {
		if (!user.getUserid().equals(user.getUserid().toUpperCase())) {
			throw new IllegalArgumentException("userid must be uppercase");
		}
		if (!user.getUsername().equals(user.getUsername().toUpperCase())) {
			throw new IllegalArgumentException("username must be uppercase");
		}

		if (!getSsoUser(user.getTenant_id(), user.getUsername()).isPresent()) {
			throw new NotFoundException("User to modify does not exist!");
		}

		useHandle(h -> {
			h.createUpdate(
					"""
							UPDATE SSO_USERS
								SET DESCR = :descr,
									PASSWORD = :password,
									PASSWORD_LAST_MODIFIED_ON = :password_last_modified_on,
									USR_LOCALE = :usr_locale,
									DATE_FORMAT = :date_format,
									IS_LOCKED = :is_locked
								WHERE USERID = :userid
								AND TENANT_ID = :tenant_id""")
					.bindBean(user)
					.execute();
		});

		return true;
	}

	@Transaction
	default int updateUserProperties(Map<String, String> userProperties, String userId) {
		int count = 0;
		for (Map.Entry<String, String> entry : userProperties.entrySet()) {
			this.updateUserProperty(entry.getKey(), entry.getValue(), userId);
			count += 1;
		}
		return count;
	}

	@Transaction
	default void addUserContext(List<String> contexts, String userId) {
		if (contexts != null) {
			contexts.forEach(context -> {
				this.addContext(userId, context);
			});
		}
	}

	@SqlQuery("""
			SELECT sr.NAME AS roleCode,
				   sr.DESCR AS description,
			       sur.DATA_INIZIO_VAL as assignment_date
			  FROM SSO_USER_ROLES sur, SSO_ROLES sr
			 WHERE sur.ROLE_ID = sr.ROLE_ID
			   AND sur.USERID = :userId
			""")
	@RegisterBeanMapper(UserRoleData.class)
	List<UserRoleData> getUserRoles(@Bind("userId") String userid);

	@SqlQuery("""
			SELECT r.NAME
			  FROM sso_user_roles ur
			       INNER JOIN sso_roles r ON r.ROLE_ID = ur.ROLE_ID
			 WHERE ur.USERID = :userId""")
	List<String> getUserRoleCodes(@Bind("userId") String userid);

	@SqlQuery("""
			SELECT r.name FROM sso_user_roles ur, sso_users su, sso_roles r
			 WHERE ur.userid = su.userid
			 AND r.role_id = ur.role_id
			 AND su.username = upper(:username)
			 AND su.tenant_id = :tenantId""")
	List<String> getUserRoleCodes(@Bind("tenantId") String tenantId, @Bind("username") String username);

	@Transaction
	default void addUserRoles(List<String> roleNames, String userId, String tenant, String whoAmI, boolean ignoreUnknownRoles) {
		if (roleNames == null) {
			return;
		}

		roleNames.forEach(role -> {
			Integer roleId = this.getRoleIdFromNameAndTenant(role, tenant);
			if (roleId != null) {
				this.addRole(userId, roleId, whoAmI);
			} else if (!ignoreUnknownRoles) {
				throw new IllegalArgumentException(String.format("Unknown role %s in tenant %s", role, tenant));
			}
		});
	}

	@Transaction
	default void deleteUserRoles(Collection<String> roleNames, String userId, String tenant, String whoAmI) {
		if (roleNames == null) {
			return;
		}

		roleNames.forEach(role -> {
			Integer roleId = this.getRoleIdFromNameAndTenant(role, tenant);
			if (roleId == null) {
				throw new IllegalArgumentException(String.format("Unknown role %s in tenant %s", role, tenant));
			}
			this.removeRole(userId, roleId, whoAmI);
		});
	}

	@SqlQuery("SELECT * FROM sso_context_functions WHERE context_id = :context_id AND name = :function_name AND tenant_id = :tenant_id")
	@RegisterBeanMapper(SsoContextFunction.class)
	SsoContextFunction getFunction(@BindBean() UserFunction userFunction, @Bind("tenant_id") String tenantId);

	@Transaction
	default void addUserFunctions(List<UserFunction> functions, String role, String tenantId, boolean ignoreMissingFunctions) {
		if (functions == null) {
			return;
		}

		Integer roleId = this.getRoleIdFromNameAndTenant(role, tenantId);
		if (roleId == null) {
			throw new IllegalArgumentException(String.format("Unknown role %s in tenant %s", role, tenantId));
		}

		functions.forEach(function -> {
			SsoContextFunction functionToBeAssigned = this.getFunction(function, tenantId);
			if (functionToBeAssigned == null && !ignoreMissingFunctions) {
				throw new IllegalArgumentException(
						String.format("Unknown function %s in tenant %s", function.getContext_id() + "|" + function.getFunction_name(), tenantId));
			}

			if (functionToBeAssigned != null) {
				this.addFunction(roleId, functionToBeAssigned.getId());
			}
		});
	}

	@SqlUpdate("INSERT INTO sso_roles_functions (role_id, function_id) VALUES (:role_id, :function_id)")
	void addFunction(@Bind("role_id") Integer roleId, @Bind("function_id") Long functionId);

	@Transaction
	default void removeUserFunctions(List<UserFunction> functions, String role, String tenantId) {
		if (functions == null) {
			return;
		}
		functions.forEach(function -> {
			SsoContextFunction userFunction = this.getFunction(function, tenantId);
			Integer roleId = this.getRoleIdFromNameAndTenant(role, tenantId);
			if (userFunction == null || roleId == null) {
				throw new IllegalArgumentException(
						String.format("Unknown function %s in tenant %s", function.getContext_id() + "|" + function.getFunction_name(), tenantId));
			}
			this.removeUserFunction(roleId, userFunction.getId());
		});
	}

	@SqlUpdate("DELETE FROM sso_roles_functions WHERE role_id = :role_id AND function_id = :function_id")
	void removeUserFunction(@Bind("role_id") int roleId, @Bind("function_id") Long functionId);

	@Transaction
	default void alignContextWithRoles(Boolean canAlign, String tenantId, String userId) {
		if (!canAlign) {
			return;
		}

		this.deleteAllContextWithAFunction(tenantId, userId);
		this.doAlignContext(userId);
	}

	@SqlUpdate("UPDATE SSO_USERS SET DESCR = :descr WHERE USERID = upper(:userId)")
	void updateUserDescr(@Bind("userId") String userId, @Bind("descr") String descr);

	@SqlUpdate("UPDATE SSO_USERS SET DESCR = :descr, usr_locale = :locale, date_format = :dateFormat WHERE USERID = upper(:userId)")
	void updateUser(@Bind("userId") String userid, @Bind("descr") String descr, @Bind("dateFormat") String dateFormat, @Bind("locale") String locale);

	@SqlUpdate("""
			DELETE FROM sso_utenti_contesti uc
				WHERE userid = :user_id
				AND EXISTS (SELECT 1 FROM sso_context_functions cf WHERE cf.tenant_id = :tenant_id AND cf.context_id = uc.contextid)""")
	void deleteAllContextWithAFunction(@Bind("tenant_id") String tenantId, @Bind("user_id") String userId);

	@SqlUpdate("""
			INSERT INTO sso_utenti_contesti (userid, contextid)
				SELECT DISTINCT upper(:user_id), cf.context_id
			 FROM sso_user_roles ur, sso_roles_functions rf, sso_context_functions cf
			 WHERE ur.userid = upper(:user_id)
			   AND rf.role_id = ur.role_id
			   AND cf.function_id = rf.function_id
			   AND NOT EXISTS (SELECT 1 FROM sso_utenti_contesti WHERE userid = upper(:user_id) AND contextid = cf.context_id)""")
	void doAlignContext(@Bind("user_id") String userId);

	@Transaction
	default int addUserProperties(Map<String, String> properties, String userId) {
		int count = 0;
		for (Map.Entry<String, String> entry : properties.entrySet()) {
			this.addUserProperty(entry.getKey(), entry.getValue(), userId);
			count += 1;
		}
		return count;
	}

	@SqlUpdate("delete from sso_users_properties where userid=:userid")
	void deleteAllUserProperties(@Bind("userid") String userid);

	@SqlUpdate("INSERT INTO SSO_USERS_PROPERTIES(NAME, CONTENT, USERID, SKIP_AGG_GU) VALUES(:key,:val,Upper(:userId),9999)")
	void addUserProperty(@Bind("key") String key, @Bind("val") String val, @Bind("userId") String userId);

	@SqlUpdate("""
			UPDATE SSO_USERS_PROPERTIES
			   SET CONTENT = :val
			 WHERE USERID = Upper(:userId)
			   AND NAME = :key""")
	void updateUserProperty(@Bind("key") String key, @Bind("val") String val, @Bind("userId") String userId);

	default int getRoleIdFromName(String roleName) {
		return this.getRoleIdFromNameAndTenant(roleName, DEFAULT_TENANT);
	}

	@SqlUpdate("INSERT INTO sso_roles (role_id, tenant_id, name, descr) values (§nextval(sso_roles_seq)§, :tenant_id, :role_name, :descr)")
	void createRole(@Bind("tenant_id") String tenantId, @Bind("role_name") String name, @Bind("descr") String descr);

	@SqlQuery("SELECT COUNT(*) FROM sso_roles WHERE name = :role_name AND tenant_id = :tenant_id")
	int getRoleCount(@Bind("tenant_id") String tenantId, @Bind("role_name") String name);

	@SqlQuery("select ROLE_ID from SSO_ROLES where NAME = upper(:roleName) and TENANT_ID = :tenantId")
	Integer getRoleIdFromNameAndTenant(@Bind("roleName") String roleName, @Bind("tenantId") String tenantId);

	@SqlQuery("""
			SELECT sr.NAME AS roleCode,
				   sr.DESCR AS description
			           FROM SSO_ROLES sr
			 WHERE sr.TENANT_ID = :tenantId
			   AND (sr.NAME LIKE '%' || UPPER(:search) || '%' OR UPPER(sr.DESCR) LIKE '%' || UPPER(:search) || '%')
			 ORDER BY sr.NAME""")
	@RegisterBeanMapper(RoleData.class)
	ResultIterator<RoleData> getRoles(@Bind("tenantId") String tenantId, @Bind("search") String search);

	@SqlQuery("""
			SELECT a.i18n_value as code, §i18n(:tenant_id, a.table_name, a.field_name, a.i18n_value, :lang)§ as description
			  FROM ( SELECT DISTINCT v.TABLE_NAME, v.FIELD_NAME, v.I18N_VALUE
					   FROM SSO_I18N_VALUES v
					  WHERE v.TABLE_NAME = 'SSO_USERS'
					    AND v.FIELD_NAME = 'USR_LOCALE'
						AND v.TENANT_ID = :tenant_id) a""")
	@RegisterBeanMapper(Language.class)
	List<Language> getLanguages(@Bind("tenant_id") String tenantId, @Bind("lang") String userLanguage);

	@Transaction
	default void addRole(String userId, int roleId, String whoAmI) {
		if (hasRole(userId, roleId) != 0) {
			return;
		}

		final long id = nextSsoUserRolesSequence();
		useHandle(h -> {
			h.createUpdate(
					"INSERT INTO SSO_USER_ROLES (ROLE_ID, USERID, DATA_INIZIO_VAL, UTENTE_INI, ID) VALUES(:roleId, :userId, CURRENT_TIMESTAMP, :whoAmI, :id)")
					.bind("roleId", roleId)
					.bind("userId", userId.toUpperCase())
					.bind("whoAmI", whoAmI.toUpperCase())
					.bind("id", id)
					.execute();

			h.createUpdate("INSERT INTO sso_user_roles_history (role_id, userid, data_inizio_val, utente_ini, fl_operation, id)"
					+ " VALUES (:roleId, :userId, CURRENT_TIMESTAMP, :whoAmI, 'I', :id)")
					.bind("roleId", roleId)
					.bind("userId", userId.toUpperCase())
					.bind("whoAmI", whoAmI.toUpperCase())
					.bind("id", id)
					.execute();
		});
	}

	@Transaction
	default void removeRole(String userId, int roleId, String whoAmI) {
		useHandle(h -> {
			int cnt = h.createUpdate("DELETE FROM SSO_USER_ROLES WHERE ROLE_ID = :roleId AND USERID = :userId")
					.bind("roleId", roleId)
					.bind("userId", userId.toUpperCase())
					.execute();

			if (cnt > 0) {
				h.createUpdate(
						"INSERT INTO sso_user_roles_history (role_id, userid, data_inizio_val, utente_ini, fl_operation, id) VALUES (:roleId, :userId, CURRENT_TIMESTAMP, :whoAmI, 'D', §nextval(sso_user_roles_seq)§)")
						.bind("roleId", roleId)
						.bind("userId", userId.toUpperCase())
						.bind("whoAmI", whoAmI.toUpperCase())
						.execute();
			}
		});
	}

	@SqlQuery("§select_nextval(sso_user_roles_seq)§")
	long nextSsoUserRolesSequence();

	@SqlQuery("SELECT COUNT(*) FROM SSO_USER_ROLES WHERE ROLE_ID = :roleId AND USERID = UPPER(:userId)")
	int hasRole(@Bind("userId") String userId, @Bind("roleId") int roleId);

	@SqlQuery("SELECT COUNT(*) FROM sso_user_roles sur, sso_users su WHERE sur.userid = su.userid AND su.tenant = :tenant_id AND su.username = :username AND sur.role_id = :role_id ")
	int hasRole(@Bind("tenant_id") String tenantId, @Bind("username") String username, @Bind("role_id") int roleId);

	@Transaction
	default void addContext(String userId, String context) {
		if (hasContext(userId, context) == 0) {
			this.doAddContext(userId, context);
		}
	}

	@Transaction
	default void removeContext(String userId, String context) {
		if (hasContext(userId, context) > 0) {
			this.doRemoveContext(userId, context);
		}
	}

	@SqlUpdate("INSERT INTO SSO_UTENTI_CONTESTI(USERID, CONTEXTID) VALUES(upper(:userId), upper(:context))")
	void doAddContext(@Bind("userId") String userId, @Bind("context") String context);

	@SqlUpdate("DELETE FROM SSO_UTENTI_CONTESTI WHERE USERID = upper(:userId) AND CONTEXTID = upper(:context)")
	void doRemoveContext(@Bind("userId") String userId, @Bind("context") String context);

	@SqlQuery("SELECT COUNT(*) FROM SSO_UTENTI_CONTESTI WHERE USERID = upper(:userId) AND CONTEXTID = :context")
	int hasContext(@Bind("userId") String userId, @Bind("context") String context);

	@SqlUpdate("INSERT INTO SPID_SSO_USERS_LOG(AuthnReq_ID, AuthnRequest, AuthnReq_IssueInstant) VALUES(:authnRequest.id, :authnRequest.request, CURRENT_TIMESTAMP)")
	void logSpidRequest(@BindBean("authnRequest") AuthnRequestObj authnRequest);

	@SqlUpdate("UPDATE SPID_SSO_USERS_LOG SET RESPONSE = :response WHERE AuthnReq_ID = :inResponseTo")
	void logSpidResponse(@Bind("response") String response, @Bind("inResponseTo") String inResponseTo);

	@SqlUpdate("UPDATE sso_users_log SET failed_logins = :failed_logins WHERE userid = UPPER(:userId)")
	void incrementFailedLogins(@Bind("userId") String userId, @Bind("failed_logins") int failedLogins);

	@Transaction
	default void incrementWrongPasswordCount(String userId) {
		int count = getUserLog(userId).getFailed_logins();
		incrementFailedLogins(userId, ++count);
	}

	@SqlUpdate("UPDATE sso_users SET password_last_modified_on = CURRENT_TIMESTAMP  WHERE userid = UPPER(:userId)")
	void updatePasswordLastModifiedOn(@Bind("userId") String userId);

	@SqlUpdate("UPDATE sso_users SET password = :md5NewPassword, password_last_modified_on = :sysdate  WHERE userid = UPPER(:userId)")
	void setNewPassword(@Bind("md5NewPassword") String md5NewPassword, @Bind("sysdate") OffsetDateTime sysdate,
			@Bind("userId") String userId);

	@SqlQuery("SELECT num FROM sso_old_passwords WHERE password = :md5OldPassword AND userid = UPPER(:userId)")
	Optional<Integer> getNumOldPassword(@Bind("md5OldPassword") String md5OldPassword, @Bind("userId") String userId);

	@SqlUpdate("UPDATE sso_old_passwords SET num = :numOldPassword WHERE password = :md5OldPassword AND userid = UPPER(:userId)")
	void updateNumOldPassword(@Bind("numOldPassword") int numOldPassword, @Bind("md5OldPassword") String md5OldPassword,
			@Bind("userId") String userId);

	@SqlUpdate("INSERT INTO sso_old_passwords(USERID, PASSWORD, NUM) VALUES(UPPER(:userId), :md5OldPassword, 1)")
	void insertOldPassword(@Bind("md5OldPassword") String md5OldPassword, @Bind("userId") String userId);

	@Transaction
	default void updateOldPasswords(String userId) {
		String encodedDbPass = getSsoUser(userId)
				.map(SsoUser::getPassword)
				.orElseThrow(NullPointerException::new);

		int numOldPassword = getNumOldPassword(encodedDbPass, userId).orElse(0);

		if (numOldPassword > 0) {
			updateNumOldPassword(++numOldPassword, encodedDbPass, userId);
		} else {
			insertOldPassword(encodedDbPass, userId);
		}
	}

	@SqlUpdate("UPDATE sso_users_log SET failed_logins = 0, last_login = :now WHERE userid = UPPER(:userId)")
	void resetUserFailedLogin(@Bind("now") OffsetDateTime now, @Bind("userId") String userId);

	@SqlCall("{call USER_ADMIN.UPDATE_DIGEST_PASSWORD(UPPER(:userId), :md5NewPassword, UPPER(:userId))}")
	void callUpdateDigest(@Bind("md5NewPassword") String md5NewPassword, @Bind("userId") String userId);

	default LoginStatus callCanILogin(String username, String initToken, String md5Token) {
		return withHandle(h -> {
			OutParameters outParams = h.createCall(
					"{call USER_ADMIN.CAN_I_LOGIN(:username, :initToken, :md5Token, :OUTPUT_STATUS, :OUTPUT_WARNINGS, :OUTPUT_ERRORS, :OUT_ERROR_PARAMETER)}")
					.bind("username", username)
					.bind("initToken", initToken)
					.bind("md5Token", md5Token)
					.registerOutParameter("OUTPUT_STATUS", Types.INTEGER)
					.registerOutParameter("OUTPUT_WARNINGS", Types.INTEGER)
					.registerOutParameter("OUTPUT_ERRORS", Types.INTEGER)
					.registerOutParameter("OUT_ERROR_PARAMETER", Types.INTEGER)
					.invoke();

			return new LoginStatus(outParams.getIntValue("OUTPUT_STATUS"), outParams.getIntValue("OUTPUT_WARNINGS"), outParams.getIntValue("OUTPUT_ERRORS"));
		});
	}

	@SqlUpdate("INSERT INTO sso_api_keys(USERID, API_KEY, VALID_FROM, VALID_TO, DESCRIPTION) VALUES(UPPER(:userId), :apiKey, :validFrom, :validTo, :description)")
	void insertApiKey(@BindBean SsoApiKeys ssoApiKeys);

	@SqlUpdate("DELETE FROM sso_api_keys WHERE API_KEY = :apiKey AND userid = UPPER(:userId)")
	int deleteApiKey(@Bind("apiKey") String apiKey, @Bind("userId") String userId);

	@RegisterBeanMapper(SsoApiKeys.class)
	@SqlQuery("SELECT * FROM sso_api_keys WHERE USERID = :userId")
	List<SsoApiKeys> getAllUserApiKeys(@Bind("userId") String userId);

	@RegisterBeanMapper(SsoApiKeys.class)
	@SqlQuery("SELECT * FROM sso_api_keys WHERE USERID = :userId AND :timestamp BETWEEN valid_from AND valid_to")
	List<SsoApiKeys> getValidUserApiKeys(@Bind("userId") String userId, @Bind("timestamp") OffsetDateTime timestamp);

	@SqlQuery("""
			SELECT s.*
			FROM sso_api_keys a, sso_users s
			WHERE a.api_key = :apiKey
			AND a.userid = s.userid""")
	@RegisterBeanMapper(SsoUser.class)
	Optional<SsoUser> getUserInfoFromApiKey(@Bind("apiKey") String apiKey);

	@Transaction
	default void copyTenant(String fromTenantId, String toTenantId) {
		useHandle(h -> {
			h.createUpdate(
					"""
							INSERT INTO sso_users (userid, username, tenant_id, password, descr, is_locked, created_on, password_last_modified_on, usr_locale, date_format, fl_internal, parent_userid, is_parent, two_factor_auth_key)
							 select replace(userid, :fromTenantId || '/', upper(:toTenantId) || '/'), username, :toTenantId, password, descr, is_locked, created_on, password_last_modified_on, usr_locale, date_format, fl_internal, replace(parent_userid, :fromTenantId || '/', :toTenantId || '/'), is_parent, two_factor_auth_key
							   from sso_users u
							  where u.tenant_id = :fromTenantId""")
					.bind("fromTenantId", fromTenantId)
					.bind("toTenantId", toTenantId)
					.execute();

			h.createUpdate(
					"""
							INSERT INTO SSO_USERS_LOG (USERID)
							 select replace(userid, :fromTenantId || '/', upper(:toTenantId) || '/')
							   from sso_users u
							  where u.tenant_id = :fromTenantId""")
					.bind("fromTenantId", fromTenantId)
					.bind("toTenantId", toTenantId)
					.execute();

			h.createUpdate(
					"""
							     INSERT INTO SSO_USER_ROLES (ROLE_ID, USERID, DATA_INIZIO_VAL, UTENTE_INI, ID)
							select r_to.role_id, replace(ur_from.userid, :fromTenantId || '/', upper(:toTenantId) || '/'),
							            ur_from.data_inizio_val, ur_from.utente_ini,
							            §nextval(sso_user_roles_seq)§
							       from sso_user_roles ur_from inner join sso_roles r_from
							            on r_from.role_id = ur_from.role_id
							            inner join sso_roles r_to
							            on r_to.tenant_id = :toTenantId and r_to.name = r_from.name
							      where r_from.tenant_id = :fromTenantId""")
					.bind("fromTenantId", fromTenantId)
					.bind("toTenantId", toTenantId)
					.execute();

			h.createUpdate(
					"""
							INSERT INTO sso_user_roles_history (role_id, userid, data_inizio_val, utente_ini, fl_operation, id)
							 select r.role_id, r.userid, r.data_inizio_val, r.utente_ini, 'I', r.id
							   from sso_user_roles r inner join sso_users u
							        on r.userid = u.userid
							  where u.tenant_id = :toTenantId""")
					.bind("fromTenantId", toTenantId)
					.bind("toTenantId", toTenantId)
					.execute();
		});
	}

	@SqlUpdate("UPDATE sso_users SET parent_userid = :parent_userid where userid = :userid")
	void setParentUser(@Bind("parent_userid") String parentUserId, @Bind("userid") String userId);

	@SqlUpdate("INSERT into sso_access_log (event_date, type, remote_address, context, username) VALUES (:event_date, :type, :remote_address, :context, :userId)")
	void insertAccessLog(@Bind("event_date") OffsetDateTime eventDate, @Bind("type") Integer type, @Bind("remote_address") String remoteAddress,
			@Bind("context") String context, @Bind("userId") String userId);

	@SqlUpdate("INSERT into sso_session (userId, jsession_id, dt_creation, dt_expiration) VALUES (:userId, :jSessionId, :dtCreation, :dtDelete)")
	void insertSessionData(@Bind("userId") String userId, @Bind("jSessionId") String jSessionId, @Bind("dtCreation") OffsetDateTime dtCreation,
			@Bind("dtDelete") OffsetDateTime dtDelete);

	@SqlUpdate("UPDATE sso_session set userid=coalesce(:userId, userid), dt_expiration=:dt WHERE jsession_id=:jsessionId")
	void updateSessionData(@Bind("jsessionId") String jSessionId, @Bind("userId") String userId, @Bind("dt") OffsetDateTime endDate);

	@SqlUpdate("UPDATE sso_session SET dt_expiration=:dtDelete where jsession_id = :jSessionId")
	void updateSessionData(@Bind("dtDelete") OffsetDateTime dtDelete, @Bind("jSessionId") String jSessionId);

	@SqlQuery("SELECT dt_expiration FROM sso_session where jsession_id = :jSessionId")
	OffsetDateTime getSessionExpirationDate(@Bind("jSessionId") String jSessionId);

	@SqlQuery("SELECT userid FROM sso_session where jsession_id = :jSessionId")
	String getUserIdFromJsessionId(@Bind("jSessionId") String jSessionId);

	@SqlUpdate("DELETE FROM sso_session where jsession_id = :jSessionId")
	void deleteSessionData(@Bind("jSessionId") String jSessionId);

	@SqlUpdate("DELETE FROM sso_session where dt_expiration < :dt")
	void deleteExpiredSessionData(@Bind("dt") OffsetDateTime olderThan);

	@SqlQuery("SELECT * from SSO_CONTEXT_FUNCTIONS where context_id=:contextId and name=:name")
	@RegisterRowMapper(FunctionMapper.class)
	List<Function> getFunction(@Bind("contextId") String contextId, @Bind("name") String name);

	@SqlQuery("""
			SELECT F.* FROM SSO_CONTEXT_FUNCTIONS F, SSO_ROLES_FUNCTIONS F_R, SSO_USER_ROLES R_U WHERE\s\
			F.FUNCTION_ID = :functionId AND F.CONTEXT_ID IN (select contextid from sso_utenti_contesti where userid = :userId) AND\s\
			F.FUNCTION_ID = F_R.FUNCTION_ID AND F_R.ROLE_ID = R_U.ROLE_ID AND R_U.USERID = :userId""")
	@RegisterRowMapper(FunctionMapper.class)
	List<Function> getFunctionsEnabled(@Bind("functionId") Integer functionId, @Bind("userId") String userId);

	@SqlQuery("SELECT R.* FROM SSO_ROLES R, SSO_USER_ROLES MM WHERE MM.ROLE_ID = R.ROLE_ID AND MM.USERID = :userId")
	@RegisterRowMapper(RolesMapper.class)
	List<Role> getSsoRoles(@Bind("userId") String userId);

	@SqlQuery("SELECT DISTINCT F.* FROM SSO_CONTEXT_FUNCTIONS F, SSO_ROLES_FUNCTIONS F_R, SSO_USER_ROLES R_U WHERE 1=1" +
			"AND F.CONTEXT_ID IN (select contextid from sso_utenti_contesti where userid = :userId) AND F.FUNCTION_ID = F_R.FUNCTION_ID AND F_R.ROLE_ID = R_U.ROLE_ID AND R_U.USERID = :userId")
	@RegisterRowMapper(FunctionMapper.class)
	List<Function> getUserFunctions(@Bind("userId") String userId);

	@SqlUpdate("INSERT INTO sso_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)"
			+ "      VALUES (:tenant_id, 'SSO_USERS', 'USR_LOCALE', :i18n_value, :lang, :i18n_text)")
	void insertLanguage(@Bind("tenant_id") String tenantId, @Bind("i18n_value") String language,
			@Bind("lang") String langForDescription, @Bind("i18n_text") String description);

	@SqlUpdate("DELETE FROM sso_i18n_values"
			+ " 	  WHERE tenant_id = :tenant_id"
			+ " 		AND table_name = 'SSO_USERS'"
			+ "			AND field_name = 'USR_LOCALE'")
	int deleteAllLanguages(@Bind("tenant_id") String tenantId);

	default boolean isController(String userId) {
		return withHandle(h -> {
			OutParameters outParams = h.createCall("""
					DECLARE
						IS_GURL_ADMIN_RESULT NUMBER;
					      begin
						IS_GURL_ADMIN_RESULT := USER_COMP.IS_CONTROLLORE(:userId);
						:IS_GURL_ADMIN := IS_GURL_ADMIN_RESULT;
					end;
					""")
					.bind("userId", userId)
					.registerOutParameter("IS_GURL_ADMIN", Types.INTEGER)
					.invoke();

			return outParams.getIntValue("IS_GURL_ADMIN") > 0;
		});
	}

	@SqlCall("""
			DECLARE
				IS_GURL_ADMIN_RESULT NUMBER;
			begin
				IS_GURL_ADMIN_RESULT := USER_COMP.IS_GESTORE(:userId);
				:IS_GURL_ADMIN := IS_GURL_ADMIN_RESULT;
			end;
			""")
	@OutParameter(name = "IS_GURL_ADMIN", sqlType = Types.INTEGER)
	OutParameters isGestore(@Bind("userId") String userId);

	@SqlCall("{call USER_LIFT.OPEN_LIFT(:userId)}")
	void openLift(@Bind("userId") String userId);

	default String getLift(String userId) {
		return withHandle(h -> {
			OutParameters outParams = h.createCall("""
					DECLARE
						RETVAL_RESULT VARCHAR2(255);
					begin
						RETVAL_RESULT:=USER_LIFT.GET_LIFT(:userId);
						:lift := RETVAL_RESULT;
					end;
					""")
					.bind("userId", userId)
					.registerOutParameter("lift", Types.VARCHAR)
					.invoke();

			return outParams.getString("lift");
		});
	}

	default String getDbgisSecret(String userId, String serverId, LocalDateTime dt) {
		return withHandle(h -> {
			OutParameters outParams = h.createCall("""
					DECLARE
					    RETVAL_RESULT VARCHAR2(255);
					begin
					    RETVAL_RESULT:=USER_LIFT.GENERATE_DBGIS_PASSWORD(:userId, :serverId, :dt);
					    :secret := RETVAL_RESULT;
					end;
					""")
					.bind("userId", userId)
					.bind("serverId", serverId)
					.bind("dt", dt)
					.registerOutParameter("secret", Types.VARCHAR)
					.invoke();

			return outParams.getString("secret");
		});
	}

	default boolean hasCompetenceOnSoftware(String userId, String software) {
		return withHandle(h -> {
			OutParameters outParams = h.createCall("""
					DECLARE
						HAS_SOFTWARE_RESULT NUMBER;
					BEGIN
						HAS_SOFTWARE_RESULT := USER_COMP.HAS_SOFTWARE(:userId, :software);
						:HAS_SOFTWARE := HAS_SOFTWARE_RESULT;
					END;
					""")
					.bind("userId", userId)
					.bind("software", software)
					.registerOutParameter("HAS_SOFTWARE", Types.INTEGER)
					.invoke();

			return outParams.getIntValue("HAS_SOFTWARE") > 0;
		});
	}

	default boolean hasCompetenceOnSoftwareCuaa(String userId, String software, String pkcuaa, String ignoraGestore) {
		int sw = getSoftware(software);
		return hasCompetenceCuaa(userId, sw + "", pkcuaa, "SOFT", ignoraGestore);
	}

	default boolean hasCompetenceOnModule(String userId, String software, String module) {
		return withHandle(h -> {
			OutParameters outParams = h.createCall("""
					DECLARE
						HAS_MODULE_RESULT NUMBER;
					BEGIN
						HAS_MODULE_RESULT := USER_COMP.HAS_MODULO(:userId, :software, :module);
						:HAS_MODULE := HAS_MODULE_RESULT;
					END;
					""")
					.bind("userId", userId)
					.bind("software", software)
					.bind("module", module)
					.registerOutParameter("HAS_MODULE", Types.INTEGER)
					.invoke();

			return outParams.getIntValue("HAS_MODULE") > 0;
		});
	}

	default boolean hasCompetenceOnModuleCuaa(String userId, String software, String module, String pkcuaa, String ignoraGestore) {
		int mod = getModule(software, module);
		return hasCompetenceCuaa(userId, mod + "", pkcuaa, "MODU", ignoraGestore);
	}

	default boolean hasCompetence(String userId, String id, String ambito, String codCompetenza, String ignoraGestore) {
		if (StringUtils.isEmpty(ambito)) {
			ambito = "PROD";
		}
		ignoraGestore = (StringUtils.isEmpty(ignoraGestore) ? "0" : "1");

		final String fAmbito = ambito;
		final String fIgnoraGestore = ignoraGestore;

		return withHandle(h -> {
			OutParameters outParams = h.createCall("""
					DECLARE
						HAS_COMP_RESULT NUMBER;
					BEGIN
						HAS_COMP_RESULT := USER_COMP.HAS_COMPETENZA(:userId, :id, :ambito, :codCompetenza, :ignoraGestore);
						:HAS_COMP := HAS_COMP_RESULT;
					END;
					""")
					.bind("userId", userId)
					.bind("id", id)
					.bind("ambito", fAmbito)
					.bind("codCompetenza", codCompetenza)
					.bind("ignoraGestore", fIgnoraGestore)
					.registerOutParameter("HAS_COMP", Types.INTEGER)
					.invoke();

			return outParams.getIntValue("HAS_COMP") > 0;
		});
	}

	default boolean hasCompetenceCuaa(String userId, String id, String pkcuaa, String codCompetenza, String ignoraGestore) {
		ignoraGestore = (StringUtils.isEmpty(ignoraGestore) ? "0" : "1");

		final String fIgnoraGestore = ignoraGestore;

		return withHandle(h -> {
			OutParameters outParams = h.createCall("""
					DECLARE
						HAS_COMP_RESULT NUMBER;
					BEGIN
						HAS_COMP_RESULT := USER_COMP.HAS_COMPETENZA_CUAA(:userId, :id, :pkcuaa, :codCompetenza, :ignoraGestore);
						:HAS_COMP := HAS_COMP_RESULT;
					END;
					""")
					.bind("userId", userId)
					.bind("id", id)
					.bind("pkcuaa", pkcuaa)
					.bind("codCompetenza", codCompetenza)
					.bind("ignoraGestore", fIgnoraGestore)
					.registerOutParameter("HAS_COMP", Types.INTEGER)
					.invoke();

			return outParams.getIntValue("HAS_COMP") > 0;
		});
	}

	default int getSoftware(String software) {
		return withHandle(h -> {
			OutParameters outParams = h.createCall("""
					DECLARE
						SW_RESULT NUMBER;
					BEGIN
						SW_RESULT := USER_COMP.GET_SOFTWARE(:software);
						:SW := SW_RESULT;
					END;
					""")
					.bind("software", software)
					.registerOutParameter("SW", Types.INTEGER)
					.invoke();

			return outParams.getIntValue("SW");
		});
	}

	default int getModule(String software, String module) {
		return withHandle(h -> {
			OutParameters outParams = h.createCall("""
					DECLARE
						MOD_RESULT NUMBER;
					BEGIN
						MOD_RESULT := USER_COMP.GET_MODULO(:software, :module);
						:MOD := MOD_RESULT;
					END;
					""")
					.bind("software", software)
					.bind("module", module)
					.registerOutParameter("MOD", Types.INTEGER)
					.invoke();

			return outParams.getIntValue("MOD");
		});
	}
}
