package com.abacogroup.sso.server2.core.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class LoginStatus {
    Integer status;
    Integer warnings;
    Integer errors;
}
