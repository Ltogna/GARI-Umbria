package com.abacogroup.sso.server2.core.bundle.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ParametersConfigMessage {
	private Map<String, String> parameters;
}
