package com.abacogroup.sso.server2.api.internal;

import javax.validation.constraints.NotEmpty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class GetTokenRequest {
	@NotEmpty
	@Schema(description = "The token")
	private String requestToken;
}
