package com.abacogroup.sso.server2.core.passwords.impl;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import com.abacogroup.sso.server2.core.passwords.PasswordHasher;

public class RunInExecutorPasswordHasher implements PasswordHasher {

	private final ExecutorService executorService;
	private final PasswordHasher delegate;

	public RunInExecutorPasswordHasher(PasswordHasher delegate, ExecutorService executorService) {
		this.executorService = executorService;
		this.delegate = delegate;
	}

	@Override
	public String getAlgorithmName() {
		return delegate.getAlgorithmName();
	}

	@Override
	public String computeHash(String password) {
		Future<String> future = executorService.submit(() -> delegate.computeHash(password));
		try {
			return future.get();
		} catch (ExecutionException e) {
			throw new RuntimeException(e);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			throw new RuntimeException(e);
		}
	}

	@Override
	public void setParams(List<String> params) {
		delegate.setParams(params);
	}

	@Override
	public boolean isResourceIntensive() {
		return false;
	}

}
