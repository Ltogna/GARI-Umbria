package com.abacogroup.sso.server2.views.saml;

import java.util.HashMap;
import java.util.Map;

import com.abacogroup.sso.server2.core.saml.RemoteIdentityProvider;

import io.dropwizard.views.common.View;

public class InitLoginView extends View {

	private Map<String, Object> params;

	public InitLoginView(RemoteIdentityProvider idp, String base64SAMLRequest, String relayState) {
		super("init-login.mustache");

		params = new HashMap<>();
		params.put("idp", idp);
		params.put("SAMLRequest", base64SAMLRequest);
		params.put("RelayState", relayState);
	}

	public Map<String, ?> getParams() {
		return params;
	}

}
