package com.abacogroup.sso.server2.core.passwords.impl;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import com.abacogroup.sso.server2.core.passwords.PasswordHasher;

public class Md5PasswordHasher implements PasswordHasher {

	public static final String NAME = "md5";

	private static final byte[] HEX_ARRAY = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
			'a', 'b', 'c', 'd', 'e', 'f' };

	private MessageDigest md5Digester;

	public Md5PasswordHasher() {
		try {
			md5Digester = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public String getAlgorithmName() {
		return NAME;
	}

	@Override
	public String computeHash(String password) {
		return bytesToHex(md5Digester.digest(password.getBytes(StandardCharsets.UTF_8)));
	}

	@Override
	public void setParams(List<String> params) {
		// NOOP
	}

	@Override
	public boolean isResourceIntensive() {
		return false;
	}

	static String bytesToHex(byte[] bytes) {
		byte[] hexChars = new byte[bytes.length * 2];
		for (int j = 0; j < bytes.length; j++) {
			int v = bytes[j] & 0xFF;
			hexChars[j * 2] = HEX_ARRAY[v >>> 4];
			hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
		}
		return new String(hexChars, StandardCharsets.UTF_8);
	}

}
