package com.abacogroup.sso.server2.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.abacogroup.sso.server2.api.Message;
import com.abacogroup.sso.server2.api.PasswordResponse;

public class PasswordChecker {

	private final Map<String, String> ssoParametersMap;

	public PasswordChecker(Map<String, String> ssoParametersMap) {
		this.ssoParametersMap = ssoParametersMap;
	}

	public List<Message> checkPassword(String password) {
		List<Message> res = new ArrayList<>();

		checkUppercaseLetters(password, res);
		checkLowercaseLetters(password, res);
		checkLetters(password, res);
		checkNumbers(password, res);
		checkSymbols(password, res);
		checkMinLength(password, res);
		checkMaxLength(password, res);

		return res;
	}

	private void checkUppercaseLetters(String password, List<Message> res) {
		Object v = ssoParametersMap.get("SSO_UC_LETTERS");
		if (!"SI".equals(v)) {
			return;
		}
		if (password.chars().noneMatch(i -> Character.isLetter(i) && Character.isUpperCase(i))) {
			res.add(new Message(PasswordResponse.Messages.PASSWORD_MUST_CONTAIN_UPPERCASE_LETTERS.key()));
		}
	}

	private void checkLowercaseLetters(String password, List<Message> res) {
		Object v = ssoParametersMap.get("SSO_LC_LETTERS");
		if (!"SI".equals(v)) {
			return;
		}
		if (password.chars().noneMatch(i -> Character.isLetter(i) && Character.isLowerCase(i))) {
			res.add(new Message(PasswordResponse.Messages.PASSWORD_MUST_CONTAIN_LOWERCASE_LETTERS.key()));
		}
	}

	private void checkLetters(String password, List<Message> res) {
		Object v = ssoParametersMap.get("SSO_LETTERS");
		if (!"SI".equals(v)) {
			return;
		}
		if (password.chars().noneMatch(Character::isLetter)) {
			res.add(new Message(PasswordResponse.Messages.PASSWORD_MUST_CONTAIN_LETTERS.key()));
		}
	}

	private void checkNumbers(String password, List<Message> res) {
		Object v = ssoParametersMap.get("SSO_NUMBERS");
		if (!"SI".equals(v)) {
			return;
		}
		if (password.chars().noneMatch(Character::isDigit)) {
			res.add(new Message(PasswordResponse.Messages.PASSWORD_MUST_CONTAIN_DIGITS.key()));
		}
	}

	private void checkSymbols(String password, List<Message> res) {
		Object v = ssoParametersMap.get("SSO_SYMBOLS");
		if (!"SI".equals(v)) {
			return;
		}
		if (password.matches("[a-zA-Z0-9]+$")) {
			res.add(new Message(PasswordResponse.Messages.PASSWORD_MUST_CONTAIN_SYMBOLS.key()));
		}
	}

	private void checkMinLength(String password, List<Message> res) {
		Object v = ssoParametersMap.get("SSO_MIN_PWD_LEN");
		if (v == null) {
			return;
		}
		int required = Integer.parseInt(v.toString());
		if (required > 0 && password.length() < required) {
			res.add(new Message(PasswordResponse.Messages.PASSWORD_IS_TOO_SHORT.key(), Arrays.asList(v.toString())));
		}
	}

	private void checkMaxLength(String password, List<Message> res) {
		Object v = ssoParametersMap.get("SSO_MAX_PWD_LEN");
		if (v == null) {
			return;
		}
		int required = Integer.parseInt(v.toString());
		if (required > 0 && password.length() > required) {
			res.add(new Message(PasswordResponse.Messages.PASSWORD_IS_TOO_LONG.key(), Arrays.asList(v.toString())));
		}
	}

}
