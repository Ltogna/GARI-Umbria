package com.abacogroup.sso.server2.core.bundle;

import java.util.Objects;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.sso.server2.db.ConfigDAO;
import com.abacogroup.sso.server2.db.Sso1DAO;

public class Sso2TenantMessageProcessor implements TenantMessageProcessor {

	private static final String TEMPLATE_TENANT_ID = "*";

	private final ConfigDAO configDAO;
	private final Sso1DAO ssoDAO;

	public Sso2TenantMessageProcessor(ConfigDAO configDAO, Sso1DAO ssoDAO) {
		this.configDAO = configDAO;
		this.ssoDAO = ssoDAO;
	}

	@Override
	public void onMessage(TenantMessage message) {
		Objects.requireNonNull(message);
		Objects.requireNonNull(message.getTenantId());

		if (TEMPLATE_TENANT_ID.equals(message.getTenantId())) {
			return;
		}

		configDAO.copyTenant(TEMPLATE_TENANT_ID, message.getTenantId());
		ssoDAO.copyTenant(TEMPLATE_TENANT_ID, message.getTenantId());
	}

}
