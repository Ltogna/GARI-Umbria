package com.abacogroup.sso.server2.core.bundle.model;

import com.fasterxml.jackson.annotation.JsonAlias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDefinition {
	@JsonAlias({ "username", "userName" })
	private String username;
	private String password;
	private String descr;
	private String locale = "en";
	private String dateFormat = "dd/MM/yyyy";
	private boolean forceChangePassword = false;
	private String secret = null;

	public UserDefinition(String username, String password, String descr) {
		this.username = username;
		this.password = password;
		this.descr = descr;
	}

	public UserDefinition(String username, String password, String descr, String secret) {
		this.username = username;
		this.password = password;
		this.descr = descr;
		this.secret = secret;
	}
}
