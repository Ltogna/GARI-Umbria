package com.abacogroup.sso.server2.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import javax.ws.rs.core.Response;

public class ApiKeyNotFoundException extends AbstractException {

	private static final long serialVersionUID = -7445280668790829881L;
	private static final ErrorBody BODY = new ErrorBody();

	public ApiKeyNotFoundException(String msg) {
		super(BODY, Response.Status.FORBIDDEN, msg);
	}

	@Schema(name = "ApiKeyNotFoundExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {

		private static final String ERR = "API_KEY_NOT_FOUND";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}

}
