package com.abacogroup.sso.server2.core.passwords;

import java.util.List;

public interface PasswordHasher {

	public static final String NO_LOG_PASSWORD = "$no_log_password$";

	/**
	 * Get the password hasher algorithm name
	 *
	 * @return the algorithm name
	 */
	String getAlgorithmName();

	/**
	 * Computes the hash of the supplied string
	 *
	 * @param string
	 *            the string to hash
	 * @return the hash
	 */
	String computeHash(String string);

	/**
	 * Set the hashed parameters
	 *
	 * @param params
	 *            the parameters
	 */
	void setParams(List<String> params);

	boolean isResourceIntensive();

	/**
	 * Encodes the password
	 *
	 * @param password
	 *            the password to encode
	 * @return the encoded password
	 */
	default String encodePassword(String password) {
		if (password == null || password.isEmpty()) {
			return NO_LOG_PASSWORD;
		}

		return computeHash(password);
	}

}
