package com.abacogroup.sso.server2.core.saml;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.opensaml.core.xml.XMLObject;
import org.opensaml.core.xml.schema.*;
import org.opensaml.saml.saml2.core.Attribute;

public class AssertedAttributesImpl implements AssertedAttributes {
	private boolean isSuccess;
	private Map<String, Object> attributes;

	protected AssertedAttributesImpl(boolean isSuccess) {
		this.isSuccess = isSuccess;
		attributes = new HashMap<>();
	}

	@Override
	public boolean isSuccess() {
		return isSuccess;
	}

	@Override
	@SuppressWarnings("unchecked")
	public <T> T get(String name) {
		return (T) attributes.get(name);
	}

	public void addAttribute(Attribute attr) {
		String name = attr.getName();

		List<XMLObject> values = attr.getAttributeValues();
		if (values == null || values.size() != 1)
			throw new SAMLValidationExcpetion("Attribute must have exactly one value");

		Object value;
		XMLObject xml = values.get(0);
		if (xml instanceof XSBoolean)
			value = ((XSBoolean) xml).getValue().getValue();
		else if (xml instanceof XSInteger)
			value = ((XSInteger) xml).getValue();
		else if (xml instanceof XSDateTime)
			value = ((XSDateTime) xml).getValue();
		else if (xml instanceof XSString)
			value = ((XSString) xml).getValue();
		else if (xml instanceof XSAny)
			value = ((XSAny) xml).getTextContent();
		else
			throw new SAMLValidationExcpetion("Unsupported value type: " + xml.getSchemaType());

		int pos = name.indexOf(":");
		if (pos == -1) {
			attributes.put(name, value);
			return;
		}
		pos = Math.max(name.lastIndexOf("/"), pos);
		attributes.put(name.substring(pos + 1), value);
	}

}
