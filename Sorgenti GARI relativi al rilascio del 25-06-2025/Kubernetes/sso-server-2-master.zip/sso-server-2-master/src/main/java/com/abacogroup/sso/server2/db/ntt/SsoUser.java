package com.abacogroup.sso.server2.db.ntt;

import java.time.OffsetDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class SsoUser {
	private String userid;
	private String password;
	private String username;
	private String tenant_id;
	private String descr;
	private char is_locked;
	private OffsetDateTime created_on;
	private OffsetDateTime password_last_modified_on;
	private String usr_locale;
	private String date_format;
	private char fl_internal;
	private String parent_userid;
	private Short is_parent;
	private String two_factor_auth_key;

	public SsoUser() {
	}

}
