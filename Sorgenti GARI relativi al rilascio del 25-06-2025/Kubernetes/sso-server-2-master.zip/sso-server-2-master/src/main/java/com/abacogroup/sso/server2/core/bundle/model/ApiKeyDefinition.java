package com.abacogroup.sso.server2.core.bundle.model;

import java.time.OffsetDateTime;

import com.fasterxml.jackson.annotation.JsonAlias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApiKeyDefinition {
    @JsonAlias({ "username", "userName" })
    private String userName;
    private OffsetDateTime validFrom = OffsetDateTime.now();
    private OffsetDateTime validTo;
    private String description;
}
