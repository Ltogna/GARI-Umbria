package com.abacogroup.sso.server2.api.internal;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class StringResponse {
	@Schema(description = "The string value")
	private String value;
}
