package com.abacogroup.sso.server2.resources;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.sso.server2.api.ChangePasswordRequest;
import com.abacogroup.sso.server2.api.IsPasswordOkRequest;
import com.abacogroup.sso.server2.api.PasswordResponse;
import com.abacogroup.sso.server2.api.UnAuthChangePasswordRequest;
import com.abacogroup.sso.server2.core.UserService;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;

@Timed
@Path("/api/v1")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Password", description = "Passwords related resources")
public class PasswordResources {
	private UserService userService;

	public PasswordResources(UserService userService) {
		this.userService = userService;
	}

	@PUT
	@Path("/change-password")
	@Operation(summary = "Change password", description = "Change current user password")
	public PasswordResponse changePassword(@Parameter(hidden = true) @Auth User user, @NotNull @Valid ChangePasswordRequest request) {
		return userService.changePassword(user.getUserId(), request, true);
	}

	@PUT
	@Path("/unauth-change-password")
	@Operation(summary = "Change password without being authenticated", description = "Change a user password when the user is not yet authenticated")
	public PasswordResponse unAuthChangePassword(@NotNull @Valid UnAuthChangePasswordRequest request) {
		return userService.changePassword(request.getUserid(), request, false);
	}

	@POST
	@Path("/is-password-ok")
	@Operation(summary = "Check if a password is usable", description = "Check if a password is usable based on current systen config")
	public PasswordResponse isPasswordOk(IsPasswordOkRequest request) {
		return userService.isPasswordOk(request.getPassword());
	}

}
