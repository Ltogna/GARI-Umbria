package com.abacogroup.sso.server2.core.bundle.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAlias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserRole {
	@JsonAlias({ "username", "userName" })
	private String username;
	private List<String> roleCodes;
}
