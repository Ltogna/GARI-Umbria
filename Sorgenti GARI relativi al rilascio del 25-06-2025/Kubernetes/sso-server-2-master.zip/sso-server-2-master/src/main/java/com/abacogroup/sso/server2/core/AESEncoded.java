package com.abacogroup.sso.server2.core;

import lombok.Value;

@Value
public class AESEncoded {
	private byte[] value;
	private byte[] iv;
}
