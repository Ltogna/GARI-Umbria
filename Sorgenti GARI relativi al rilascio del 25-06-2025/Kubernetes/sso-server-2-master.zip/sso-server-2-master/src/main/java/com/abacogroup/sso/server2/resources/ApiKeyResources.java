package com.abacogroup.sso.server2.resources;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.sso.server2.api.ApiKeyLoginRequest;
import com.abacogroup.sso.server2.api.ApiKeyRequest;
import com.abacogroup.sso.server2.api.ApiKeyResponse;
import com.abacogroup.sso.server2.api.LoginResponse;
import com.abacogroup.sso.server2.core.ApiKeyService;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@Timed
@Path("/api/v1/apikey")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "API Keys", description = "Operations on API keys")
public class ApiKeyResources {
	private final ApiKeyService apikeyService;

	public ApiKeyResources(ApiKeyService apikeyService) {
		this.apikeyService = apikeyService;
	}

	@POST
	@Operation(summary = "Generate an API key", description = "Generate an API key for the authenticated user")
	public String generateApiKey(@Parameter(hidden = true) @Auth User user, @Valid @NotNull ApiKeyRequest request) {
		return apikeyService.createApiKey(request.getValidFrom(), request.getValidTo(), request.getDescription(), user.getUserId());
	}

	@DELETE
	@Path("/{apikey}")
	@Operation(summary = "Delete an API key", description = "Delete an API key for the authenticated user")
	@ApiResponses({
			@ApiResponse(responseCode = "204", description = "API key was deleted"),
			@ApiResponse(responseCode = "404", description = "API key not found")
	})
	public void deleteApiKey(@Parameter(hidden = true) @Auth User user, @NotBlank @PathParam("apikey") String apikey) {
		int num = apikeyService.deleteApiKey(apikey, user.getUserId());
		if (num == 0) {
			throw new NotFoundException("API key not found");
		}
	}

	@GET
	@Operation(summary = "List user's API keys", description = "Get a list of API keys for the authenticated user")
	public List<ApiKeyResponse> getUserApiKeys(@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "false to get also the epired ones") @DefaultValue("true") @QueryParam("onlyValid") boolean onlyValidApiKeys) {
		return apikeyService.getApiKeysFromUserId(user.getUserId(), onlyValidApiKeys);
	}

	@POST
	@Path("/login")
	@Operation(summary = "Login", description = "Login using an API key")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Login was successfull", content = {
					@Content(schema = @Schema(anyOf = { LoginResponse.class }))
			}),
			@ApiResponse(responseCode = "403", description = "API key not found") })

	public LoginResponse apiKeyLogin(@Valid @NotNull ApiKeyLoginRequest request) {
		return apikeyService.apiKeyLogin(request);
	}
}
