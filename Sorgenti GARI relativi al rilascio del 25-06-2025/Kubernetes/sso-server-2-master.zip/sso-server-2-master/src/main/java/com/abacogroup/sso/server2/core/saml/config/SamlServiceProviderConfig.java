package com.abacogroup.sso.server2.core.saml.config;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class SamlServiceProviderConfig {
	@NotEmpty
	private String id;
	@NotEmpty
	private String entityId;
	private String displayName;
	@NotEmpty
	private String orgURL;
	@NotEmpty
	private String privKey;
	@NotEmpty
	private String cert;
	@NotNull
	private List<String> attributes;
	@NotNull
	private List<String> eidasMinimumAttributes;
	@NotNull
	private List<String> eidasFullAttributes;
	@NotEmpty
	private String minAuthRef;
	@NotEmpty
	private String idpMetadataDirectory;
	@NotNull
	private List<String> tags;
	@Valid
	PublicContactPerson paContactPerson;
	@Valid
	PrivateContactPerson privateContactPerson;
	@NotNull
	private Map<String, String> ssoUserPropertiesFields;
	@NotNull
	private Map<String, ReturnMode> returnMapping;
}
