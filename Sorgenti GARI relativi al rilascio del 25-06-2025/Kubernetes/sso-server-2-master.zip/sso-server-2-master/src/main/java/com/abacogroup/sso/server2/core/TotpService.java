package com.abacogroup.sso.server2.core;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.security.InvalidKeyException;
import java.security.Key;
import java.time.Instant;
import java.util.Hashtable;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import javax.crypto.spec.SecretKeySpec;
import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;

import org.apache.commons.codec.binary.Base32;

import com.abacogroup.sso.server2.db.ntt.SsoUser;
import com.eatthepath.otp.TimeBasedOneTimePasswordGenerator;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

public class TotpService {
	
	private TimeBasedOneTimePasswordGenerator totp;
	
	private String totpIssuer;
	
	private Integer totpPeriod;
	
	private static final Integer size = 1000;
	
	private void createTotpEngine() {
		totp = new TimeBasedOneTimePasswordGenerator();
	}
 
    public TotpService(String totpIssuer, Integer totpPeriod) {
    	createTotpEngine();
    	this.totpIssuer = totpIssuer;
    	this.totpPeriod = totpPeriod;
    }


	public boolean validateTotp(String secret, String requestCode, boolean isLong) {
		int[] intervals;
		if(isLong){
			intervals = new int[]{0, 30, 60, 90, 120, 150};
		}
		else{
			intervals = new int[]{0, 30};
		}
		Instant time = Instant.now();
		byte[] secretBytes = secret.getBytes();
		SecretKeySpec secretKeySpec = new SecretKeySpec(secretBytes, "HmacSHA1");

		boolean validCode = IntStream.of(intervals).boxed().flatMap(interval -> Stream.of(time, time.plusSeconds(interval), time.minusSeconds(interval))).distinct().map(instant -> {
			try {
				return totp.generateOneTimePasswordString((Key) secretKeySpec, instant);
			} catch (Exception e) {
				throw new RuntimeException("couldn't calculate geoash, reason: "+e.getMessage());
			}
		}).filter(code -> code.equals(requestCode)).findFirst().isPresent();

		return validCode;
	}


	public String createTotpCode(String secret) throws InvalidKeyException {
		Instant time = Instant.now();
		byte[] secretBytes = secret.getBytes();
		if(secretBytes.length < 16){
			throw new InvalidKeyException("Provided key is too short");
		}
		SecretKeySpec secretKeySpec = new SecretKeySpec(secretBytes, "HmacSHA1");
		return totp.generateOneTimePasswordString((Key) secretKeySpec, time);
	}
	
	
	public OutputStream createQRImage(SsoUser user, OutputStream out)
			throws WriterException, IOException {
		
		Base32 base32 = new Base32(); 
		String base32Secret = base32.encodeAsString(user.getTwo_factor_auth_key().getBytes());
		String qrCodeText = String.format("otpauth://totp/%s:%s?secret=%s&issuer=%s&period=%d", this.totpIssuer, user.getUsername(), base32Secret ,this.totpIssuer,this.totpPeriod);
		
		
		Hashtable<EncodeHintType, ErrorCorrectionLevel> hintMap = new Hashtable<>();
		hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
		QRCodeWriter qrCodeWriter = new QRCodeWriter();
		BitMatrix byteMatrix = qrCodeWriter.encode(qrCodeText, BarcodeFormat.QR_CODE, size, size, hintMap);
		int matrixWidth = byteMatrix.getWidth();
		
		
		BufferedImage image = new BufferedImage(matrixWidth, matrixWidth, BufferedImage.TYPE_BYTE_GRAY);
		image.createGraphics();
		Graphics2D graphics = (Graphics2D) image.getGraphics();
		//draw in the graphics
		graphics.setColor(Color.WHITE);
		graphics.fillRect(0, 0, matrixWidth, matrixWidth);
		graphics.setColor(Color.BLACK);
		
		for (int i = 0; i < matrixWidth; i++) {
			for (int j = 0; j < matrixWidth; j++) {
				if (byteMatrix.get(i, j)) {
					graphics.fillRect(i, j, 1, 1);
				}
			}
		}
		
	     ImageWriter imgWrtr = ImageIO.getImageWritersByFormatName("png").next();        
	     ImageOutputStream imgOutStrm = ImageIO.createImageOutputStream(out);
	     imgWrtr.setOutput(imgOutStrm);
	     ImageWriteParam jpgWrtPrm = imgWrtr.getDefaultWriteParam();
	     jpgWrtPrm.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
	     float quality = 0.8f;
	     jpgWrtPrm.setCompressionQuality(quality);        
	     imgWrtr.write(null, new IIOImage(image, null, null), jpgWrtPrm);
	     return out;

	}
}
