package com.abacogroup.sso.server2.resources;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.sso.server2.api.ChildUser;
import com.abacogroup.sso.server2.api.ImpersonationRequest;
import com.abacogroup.sso.server2.api.LoginResponse;
import com.abacogroup.sso.server2.core.UserService;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;

@Timed
@Path("{tenant}/public/v1/impersonation")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Impersonation", description = "Impersonation resources")
public class ImpersonationResources {

	private UserService userService;

	public ImpersonationResources(UserService userService) {
		this.userService = userService;
	}

	@GET
	@Operation(summary = "Find children users", description = "Search for current authenticated user's children")
	public InfiniteListResults<ChildUser> findChildrenToImpersonate(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant") @PathParam("tenant") String tenantId,
			@QueryParam("filter") String filter,
			@QueryParam("includeContexts") @DefaultValue("false") Boolean includeContexts,
			@QueryParam("nextKey") String nextKey) {

		return userService.findChildren(user.getUserId(), filter, includeContexts, nextKey);
	}

	@POST
	@Operation(summary = "Impersonate a child users", description = "Impersonate on of current user children")
	public LoginResponse impersonate(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant") @PathParam("tenant") String tenantId,
			@Parameter(description = "Whether to issue auth and refresh tokens") @HeaderParam("X-ABACO-ISSUE-TOKENS") @DefaultValue("true") boolean issueTokens,
			@NotNull @Valid ImpersonationRequest request,
			@Context HttpServletRequest requestServlet) {

		return userService.impersonate(user, request, issueTokens, requestServlet.getRemoteAddr());
	}

}
