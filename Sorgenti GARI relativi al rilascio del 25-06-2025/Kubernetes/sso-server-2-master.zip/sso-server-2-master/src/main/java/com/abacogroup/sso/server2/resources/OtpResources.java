package com.abacogroup.sso.server2.resources;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.sso.server2.api.TotpVerificationRequest;
import com.abacogroup.sso.server2.core.TotpService;
import com.abacogroup.sso.server2.core.UserService;
import com.abacogroup.sso.server2.db.ntt.SsoUser;
import com.codahale.metrics.annotation.Timed;
import com.google.zxing.WriterException;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@Timed
@Path("{tenant}/public/v1/totp")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Tenant aware APIs", description = "API that works on tenants")
public class OtpResources implements TenantCheckable {

	private UserService userService;

	private TotpService totpService;

	public OtpResources(UserService userService, TotpService totpService) {
		this.userService = userService;
		this.totpService = totpService;
	}

	@POST
	@Path("/code")
	@Operation(summary = "Get the current user details", description = "Get the current logged in user details")
	@ApiResponses({
			@ApiResponse(responseCode = "204", description = "The code is valid"),
			@ApiResponse(responseCode = "403", description = "The code is invalid")
	})
	public Response whoAmI(@Parameter(hidden = true) @Auth User user, @PathParam("tenant") String tenantId,
			TotpVerificationRequest request) {

		checkTenant(tenantId, user);
		SsoUser userAuthenticated = this.userService.getUser(tenantId, user.getName()).orElseThrow();
		String secret = userAuthenticated.getTwo_factor_auth_key();
		if (totpService.validateTotp(secret, request.getCode(), false)) {
			return Response.status(204).build();
		}
		return Response.status(403).build();
	}

	@GET
	@Path("/qr-code")
	@Produces("image/png")
	@Operation(summary = "Get the current user details", description = "Get the current logged in user details")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "QR Code generated"),
			@ApiResponse(responseCode = "500", description = "The secret is not invalid")
	})
	public Response whoAmIQrCode(@Parameter(hidden = true) @Auth User user, @PathParam("tenant") String tenantId)
			throws WriterException, IOException {
		checkTenant(tenantId, user);
		SsoUser userAuthenticated = this.userService.getUser(tenantId, user.getName()).orElseThrow();
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		totpService.createQRImage(userAuthenticated, out);
		byte[] imageData = out.toByteArray();
		return Response.ok(imageData, "image/png")
				.header("Content-Disposition", "inline")
				.build();
	}
}
