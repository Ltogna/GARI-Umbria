package com.abacogroup.sso.server2.api;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ChildUser {
	@NotEmpty
	@Schema(description = "The tenant")
	private String tenant;

	@NotEmpty
	@Schema(description = "The user ID")
	private String userid;

	@NotEmpty
	@Schema(description = "The user name")
	private String username;

	@NotEmpty
	@Schema(description = "The user description")
	private String descr;

	@Schema(description = "The user's contexts")
	private List<String> contexts;
}
