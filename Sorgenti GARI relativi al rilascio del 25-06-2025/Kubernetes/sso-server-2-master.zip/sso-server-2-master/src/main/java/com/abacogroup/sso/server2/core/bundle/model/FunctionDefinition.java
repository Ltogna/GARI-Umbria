package com.abacogroup.sso.server2.core.bundle.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FunctionDefinition {
	private String context;
	private String code;
	private String description;
}
