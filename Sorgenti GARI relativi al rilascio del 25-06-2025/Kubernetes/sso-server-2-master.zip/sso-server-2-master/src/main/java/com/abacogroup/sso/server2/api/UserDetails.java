package com.abacogroup.sso.server2.api;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(toBuilder = true)
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
public class UserDetails extends UserData {
	private Boolean internalUser;
	private String userLocale;
	private String dateFormat;
	private char isLocked;
	private char isModifyPasswordOnNextLogin;
	private OffsetDateTime creationDate;
	private OffsetDateTime lastLoginDate;
	private OffsetDateTime lastLoginModificationDate;
	private List<UserRoleData> userRoles;
	private Map<String, String> userProperties;
}
