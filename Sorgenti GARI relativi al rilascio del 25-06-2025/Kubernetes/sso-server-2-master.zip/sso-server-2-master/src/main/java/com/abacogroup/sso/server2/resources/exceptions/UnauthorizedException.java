package com.abacogroup.sso.server2.resources.exceptions;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

public class UnauthorizedException extends WebApplicationException {
	private static final long serialVersionUID = -9073391659787524990L;

	public UnauthorizedException() {
		super(Response.status(Status.UNAUTHORIZED).header("WWW-Authenticate", "JWT").build());
	}

}
