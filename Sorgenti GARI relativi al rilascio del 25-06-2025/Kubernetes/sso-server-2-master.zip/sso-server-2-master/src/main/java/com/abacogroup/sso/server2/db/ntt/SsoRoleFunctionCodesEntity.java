package com.abacogroup.sso.server2.db.ntt;

import lombok.Data;

@Data
public class SsoRoleFunctionCodesEntity {
	private Long functionId;
	private String contextId;
	private String functionCode;
}
