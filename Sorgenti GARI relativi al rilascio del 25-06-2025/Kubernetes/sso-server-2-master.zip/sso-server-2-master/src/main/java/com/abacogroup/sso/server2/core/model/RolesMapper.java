package com.abacogroup.sso.server2.core.model;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class RolesMapper implements RowMapper<Role> {
    @Override
    public Role map(ResultSet rs, StatementContext ctx) throws SQLException {
        Role role = new Role();
        role.setRoleId(rs.getInt("ROLE_ID"));
        role.setName(rs.getString("NAME"));
        role.setDescr(rs.getString("DESCR"));
        role.setTenantId(rs.getString("TENANT_ID"));
        return role;
    }
}

