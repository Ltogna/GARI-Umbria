package com.abacogroup.sso.server2.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

public class TenantMismatchException extends AbstractException {

	private static final long serialVersionUID = 6977775740052534295L;
	private static final ErrorBody BODY = new ErrorBody();

	public TenantMismatchException(String msg) {
		super(BODY, msg);
	}

	@Schema(name = "TenantMismatchExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {

		private static final String ERR = "TENANT_MISMATCH";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}

}
