package com.abacogroup.sso.server2.resources.exceptions;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

public class UnauthorizedExceptionMaxLogFail extends WebApplicationException {
	private static final long serialVersionUID = -9073391659787524990L;

	public UnauthorizedExceptionMaxLogFail() {
		super(Response.status(ResponseMaxLoginFailure.MAXLOGINFAILURE).header("WWW-Authenticate", "JWT").build());
	}

}
