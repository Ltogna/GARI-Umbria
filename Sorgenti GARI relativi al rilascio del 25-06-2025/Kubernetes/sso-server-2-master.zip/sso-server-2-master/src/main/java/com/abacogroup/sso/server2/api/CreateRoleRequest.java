package com.abacogroup.sso.server2.api;

import javax.validation.constraints.NotEmpty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateRoleRequest {
	@NotEmpty
	@Schema(description = "The description")
	String description;

	@NotEmpty
	@Schema(description = "The role code")
	String code;
}
