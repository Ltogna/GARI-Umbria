package com.abacogroup.sso.server2.api;

import com.abacogroup.sso.server2.db.ntt.SsoUser;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class WhoAmIResponse {
	@Schema(description = "The date format", example = "dd/MM/yyyy")
	private String dateFormat;

	@Schema(description = "The user description")
	private String description;

	@Schema(description = "True if the user is a parent user")
	private Boolean isParentUser;

	@Schema(description = "The user locale", example = "en")
	private String locale;

	@Schema(description = "The user ID", example = "MASTER/JOE")
	private String user_id;

	@Schema(description = "The username", example = "JOE")
	private String username;

	@Schema(description = "The tenant ID", example = "master")
	private String tenant;

	public WhoAmIResponse(SsoUser user) {
		this.dateFormat = user.getDate_format();
		this.description = user.getDescr();
		this.isParentUser = user.getIs_parent() == 1;
		this.locale = user.getUsr_locale();
		this.user_id = user.getUserid();
		this.username = user.getUsername();
		this.tenant = user.getTenant_id();
	}
}
