package com.abacogroup.sso.server2.core.bundle.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class I18nLang {
	private String lang;
	private String description;
}
