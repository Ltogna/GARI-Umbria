package com.abacogroup.sso.server2.core.bundle;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.sso.server2.db.ConfigDAO;
import com.fasterxml.jackson.databind.ObjectMapper;

public abstract class AbstractConfigProcessor implements ConfigMessageProcessor {

	protected static final String TEMPLATE_TENANT_ID = "*";

	protected final ObjectMapper objectMapper;
	protected final ConfigDAO configDAO;

	protected AbstractConfigProcessor(ConfigDAO configDAO, ObjectMapper objectMapper) {
		this.configDAO = configDAO;
		this.objectMapper = objectMapper;
	}

	@Override
	public final void onMessage(ConfigDataMessage message) {
		configDAO.useTransaction(dao -> {
			onMessageInTransaction(dao, message);
		});
	}

	protected abstract void onMessageInTransaction(ConfigDAO dao, ConfigDataMessage message);
}
