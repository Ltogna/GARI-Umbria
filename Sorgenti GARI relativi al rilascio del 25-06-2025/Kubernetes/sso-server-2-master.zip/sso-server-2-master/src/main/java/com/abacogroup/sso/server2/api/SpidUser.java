package com.abacogroup.sso.server2.api;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.Map;

@Data
@Builder
public class SpidUser {
	private @NotEmpty String userId;
	private Map<String, String> userProperties;
}
