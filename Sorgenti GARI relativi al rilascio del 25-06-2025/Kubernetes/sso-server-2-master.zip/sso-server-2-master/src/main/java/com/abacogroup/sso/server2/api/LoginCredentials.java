package com.abacogroup.sso.server2.api;

import javax.validation.constraints.NotEmpty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class LoginCredentials {
	@NotEmpty
	@Schema(description = "The username")
	private String username;

	@NotEmpty
	@Schema(description = "The password")
	private String password;

	public LoginCredentials() {
	}
}
