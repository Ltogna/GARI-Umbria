package com.abacogroup.sso.server2.core;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.ws.rs.ForbiddenException;
import javax.ws.rs.NotFoundException;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.dropwizard.auth.sso2.UserFunction;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.sso.server2.api.CreateRoleRequest;
import com.abacogroup.sso.server2.api.CreateUserRequest;
import com.abacogroup.sso.server2.api.FunctionRequest;
import com.abacogroup.sso.server2.api.Language;
import com.abacogroup.sso.server2.api.RoleData;
import com.abacogroup.sso.server2.api.UpdateUserRequest;
import com.abacogroup.sso.server2.api.UserDetails;
import com.abacogroup.sso.server2.core.passwords.PasswordHasher;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.abacogroup.sso.server2.db.ntt.SsoUser;
import com.abacogroup.sso.server2.exceptions.UserAlreadyExistsException;

public class UserManagementService {
	private static int PAGE_SIZE = 10;

	private PasswordHasher passwordHasher;
	private Sso1DAO sso1DAO;
	private boolean updateDigest;
	private UserService userService;
	private String deletedUserUsername;

	public UserManagementService(PasswordHasher passwordHasher, Sso1DAO sso1DAO, boolean updateDigest, UserService userService, String deletedUserUsername) {
		this.passwordHasher = passwordHasher;
		this.sso1DAO = sso1DAO;
		this.updateDigest = updateDigest;
		this.userService = userService;
		this.deletedUserUsername = deletedUserUsername;
	}

	public InfiniteListResults<UserDetails> getUsers(String tenantId, String search, String nextKey) {
		Criteria criteria = null;
		if (search != null && !search.isBlank()) {
			criteria = CriteriaBuilder.or(
					CriteriaBuilder.string("username").caseInsensitiveStartsWith(search),
					CriteriaBuilder.string("descr").caseInsensitiveContains(search));
		}

		final Criteria finalCriteria = criteria;
		InfiniteListResults<UserDetails> users = this.sso1DAO.infinite(
				() -> this.sso1DAO.getUsersList(tenantId, finalCriteria),
				nextKey,
				PAGE_SIZE);

		// TODO: rework this to avoid n*m queries
		users.getRecords().forEach(rec -> {
			enrichUser(rec);
		});

		return users;
	}

	private void enrichUser(UserDetails user) {
		user.setUserRoles(this.sso1DAO.getUserRoles(user.getUserId()));
		user.setUserProperties(this.sso1DAO.getUserProperties(user.getTenant(), user.getUserName()));
		user.setIsModifyPasswordOnNextLogin(user.getCreationDate().equals(user.getLastLoginModificationDate()) ? 'Y' : 'N');
	}

	public boolean createUser(String tenantId, CreateUserRequest createUserRequest) {
		checkUserAlreadyExist(tenantId, createUserRequest);

		String userId = CreateUserRequest.createUserId(tenantId, createUserRequest.getUsername());
		SsoUser deletedUser = this.getDeletedUser(userId);
		if (deletedUser != null) {
			this.sso1DAO.setParentUser(createUserRequest.getParentUserId(), userId);
			return true;
		}

		return this.sso1DAO.inTransaction(ssoHandle -> {
			OffsetDateTime now = ssoHandle.getSysdate();

			String upperCaseParentUserId = getUpperParentUserId(createUserRequest);

			char flInternal = nvl(createUserRequest.getFlInternal(), 'Y');
			char isLocked = nvl(createUserRequest.getIsLocked(), 'N');
			short isParent = nvl(createUserRequest.getIsParent(), (short) 0);
			boolean isPasswordEncoded = nvl(createUserRequest.getIsPasswordEncoded(), (short) 0) == (short) 1;

			String password = createUserRequest.getPassword();
			if (PasswordHasher.NO_LOG_PASSWORD.equals(password)) {
				password = null;
			}
			String encodedPassword = isPasswordEncoded ? password : passwordHasher.encodePassword(password);

			OffsetDateTime passwordLastModifiedOn;
			if (createUserRequest.getIsModifyPasswordOnNextLogin() == 'Y') {
				passwordLastModifiedOn = now;
			} else {
				passwordLastModifiedOn = isPasswordEncoded ? now.plusSeconds(1) : now;
			}

			boolean created = ssoHandle.insertUser(SsoUser.builder()
					.created_on(now)
					.date_format(nvl(createUserRequest.getDateFormat(), "dd/MM/yyyy"))
					.descr(createUserRequest.getDescription())
					.fl_internal(flInternal)
					.is_locked(isLocked)
					.is_parent(isParent)
					.parent_userid(upperCaseParentUserId)
					.password(encodedPassword)
					.password_last_modified_on(passwordLastModifiedOn)
					.tenant_id(tenantId)
					.userid(userId)
					.username(createUserRequest.getUsername().toUpperCase())
					.usr_locale(nvl(createUserRequest.getLanguage(), "en"))
					.build(),
					updateDigest);
			if (createUserRequest.getUserProperties() != null) {
				ssoHandle.addUserProperties(createUserRequest.getUserProperties(), userId);
			}

			return created;
		});
	}

	private void checkUserAlreadyExist(String tenantId, CreateUserRequest createUserRequest) {
		if (this.sso1DAO.getSsoUser(tenantId, createUserRequest.getUsername()).isPresent()) {
			throw new UserAlreadyExistsException();
		}
	}

	private String getUpperParentUserId(CreateUserRequest createUserRequest) {
		return createUserRequest.getParentUserId() != null ? createUserRequest.getParentUserId().toUpperCase() : null;
	}

	public boolean updateUser(String tenantId, String username, UpdateUserRequest updatedUserRequest) {
		String upUsername = username.toUpperCase();
		Optional<SsoUser> ssoUser = this.sso1DAO.getSsoUser(tenantId, username);

		if (!ssoUser.isPresent()) {
			throw new NotFoundException("User to modify does not exist!");
		}

		return this.sso1DAO.inTransaction(ssoHandle -> {
			SsoUser currentUserData = ssoUser.get();

			OffsetDateTime now = ssoHandle.getSysdate();

			String currentPassword = currentUserData.getPassword();
			String updatedPassword = updatedUserRequest.getPassword();
			boolean isPasswordEncoded = nvl(updatedUserRequest.getIsPasswordEncoded(), (short) 0) == (short) 1;
			OffsetDateTime passwordLastModifiedOn = currentUserData.getPassword_last_modified_on();

			if (updatedPassword == null || updatedPassword.isEmpty()) {
				updatedPassword = currentPassword;
			} else {
				updatedPassword = isPasswordEncoded ? updatedPassword : passwordHasher.encodePassword(updatedPassword);
				passwordLastModifiedOn = now;
			}

			passwordLastModifiedOn = setPasswordLastModifiedOn(updatedUserRequest, currentUserData,
					passwordLastModifiedOn);

			boolean updated = ssoHandle.updateUser(SsoUser.builder()
					.created_on(currentUserData.getCreated_on())
					.date_format(nvl(updatedUserRequest.getDateFormat(), "dd/MM/yyyy"))
					.descr(updatedUserRequest.getDescription())
					.fl_internal(currentUserData.getFl_internal())
					.is_locked(updatedUserRequest.getIsLocked())
					.is_parent(currentUserData.getIs_parent())
					.parent_userid(currentUserData.getParent_userid())
					.password(updatedPassword)
					.password_last_modified_on(passwordLastModifiedOn)
					.tenant_id(tenantId)
					.userid(currentUserData.getUserid())
					.username(upUsername)
					.usr_locale(nvl(updatedUserRequest.getLanguage(), "en"))
					.build());

			Map<String, String> requestUserProperties = updatedUserRequest.getUserProperties();

			if (requestUserProperties == null || requestUserProperties.isEmpty()) 
				ssoHandle.deleteAllUserProperties(currentUserData.getUserid());
			else
				setUserProperties(tenantId, upUsername, ssoHandle, currentUserData, requestUserProperties);

			return updated;
		});
	}

	private OffsetDateTime setPasswordLastModifiedOn(UpdateUserRequest updatedUserRequest, SsoUser currentUserData,
			OffsetDateTime passwordLastModifiedOn) {
		if (updatedUserRequest.getIsModifyPasswordOnNextLogin() == 'Y') {
			passwordLastModifiedOn = currentUserData.getCreated_on();
		} else {
			if (currentUserData.getCreated_on().equals(currentUserData.getPassword_last_modified_on())) {
				passwordLastModifiedOn = passwordLastModifiedOn.plusMinutes(1);
			}
		}
		return passwordLastModifiedOn;
	}

	private void setUserProperties(String tenantId, String username, Sso1DAO ssoHandle, SsoUser currentUserData,
			Map<String, String> requestUserProperties) {

		Map<String, String> currentUserProperties = ssoHandle.getUserProperties(tenantId, username);
		Map<String, String> propertiesToUpdate = new HashMap<>();
		Map<String, String> propertiesToAdd = new HashMap<>();

		requestUserProperties.forEach((propertyName, propertyValue) -> {
			if (currentUserProperties.containsKey(propertyName)) {
				if (!currentUserProperties.get(propertyName).equals(propertyValue)) {
					propertiesToUpdate.put(propertyName, propertyValue);
				}
			} else {
				propertiesToAdd.put(propertyName, propertyValue);
			}
		});

		if (!propertiesToUpdate.isEmpty()) {
			ssoHandle.updateUserProperties(propertiesToUpdate, currentUserData.getUserid());
		}

		if (!propertiesToAdd.isEmpty()) {
			ssoHandle.addUserProperties(propertiesToAdd, currentUserData.getUserid());
		}
	}

	public UserDetails getUserDetails(String tenantId, String username) {
		UserDetails user = this.sso1DAO.getUserByUsername(tenantId, username.toUpperCase());
		if (user == null) {
			return null;
		}

		enrichUser(user);
		return user;
	}

	public InfiniteListResults<RoleData> getRoles(String tenantId, String search, String nextKey) {
		InfiniteListResults<RoleData> roles = this.sso1DAO.infinite(
				() -> this.sso1DAO.getRoles(tenantId, search),
				nextKey,
				PAGE_SIZE);

		return roles;
	}

	public List<Language> getLanguages(String tenantId, String userLanguage) {
		return this.sso1DAO.getLanguages(tenantId, userLanguage);
	}

	public void createRole(String tenantId, CreateRoleRequest roleRequest) {
		if (this.sso1DAO.getRoleCount(tenantId, roleRequest.getCode()) > 0) {
			throw new IllegalStateException("Role already present");
		}
		this.sso1DAO.createRole(tenantId, roleRequest.getCode(), roleRequest.getDescription());
	}

	public void assignRolesToUser(List<String> roleCodes, String tenantId, String username, User userExecutingAction, boolean ignoreUnknownRoles) {
		SsoUser ssoUser = this.userService.getUser(tenantId, username).orElseThrow(NotFoundException::new);
		this.sso1DAO.addUserRoles(roleCodes, ssoUser.getUserid(), tenantId, userExecutingAction.getUserId(), ignoreUnknownRoles);
	}

	public void setUserRoles(List<String> roleCodes, String tenantId, String username, User userExecutingAction, boolean ignoreUnknownRoles) {
		SsoUser ssoUser = this.userService.getUser(tenantId, username)
				.orElseThrow(() -> new NotFoundException("User not found"));

		Set<String> currentRoles = new HashSet<>(sso1DAO.getUserRoleCodes(ssoUser.getUserid()));
		List<String> rolesToAdd = new ArrayList<>();
		for (String role : roleCodes) {
			if (!currentRoles.remove(role)) {
				rolesToAdd.add(role);
			}
		}

		sso1DAO.useTransaction(dao -> {
			dao.deleteUserRoles(currentRoles, ssoUser.getUserid(), ssoUser.getTenant_id(), userExecutingAction.getUserId());
			dao.addUserRoles(rolesToAdd, ssoUser.getUserid(), ssoUser.getTenant_id(), userExecutingAction.getUserId(), ignoreUnknownRoles);
		});
	}

	public void removeRolesFromUser(List<String> roleCodes, String tenantId, String username, String userExecutingActionId) {
		SsoUser ssoUser = this.userService.getUser(tenantId, username).orElseThrow(NotFoundException::new);

		// Remove the roles from the user
		this.sso1DAO.deleteUserRoles(roleCodes, ssoUser.getUserid(), tenantId, userExecutingActionId);
	}

	public void assignFunctionToUser(FunctionRequest functionRequest, String tenantId, String username, boolean ignoreMissingFunctions) {
		checkUserHasRole(tenantId, username, functionRequest.getRoleName());
		List<UserFunction> functionAlreadyAssignedToUser = this.userService.getUserFunctions(tenantId, username);
		List<UserFunction> functionsToBeAssigned = functionRequest.getFunctions().stream().filter(function -> !functionAlreadyAssignedToUser.contains(function))
				.collect(Collectors.toList());
		this.sso1DAO.addUserFunctions(functionsToBeAssigned, functionRequest.getRoleName(), tenantId, ignoreMissingFunctions);
	}

	public void removeFunctionFromUser(FunctionRequest functionRequest, String tenantId, String username) {
		checkUserHasRole(tenantId, username, functionRequest.getRoleName());
		List<UserFunction> functionAlreadyAssignedToUser = this.userService.getUserFunctions(tenantId, username);
		List<UserFunction> functionsToBeRemoved = functionAlreadyAssignedToUser.stream().filter(function -> functionRequest.getFunctions().contains(function))
				.collect(Collectors.toList());
		this.sso1DAO.removeUserFunctions(functionsToBeRemoved, functionRequest.getRoleName(), tenantId);
	}

	public void deleteUser(String tenantId, String username) {
		this.sso1DAO.useTransaction(ssoHandle -> {
			SsoUser userToBeDeleted = this.userService.getUser(tenantId, username)
					.orElseThrow(() -> new NotFoundException(String.format("No user found for tenant %s and username %s", tenantId, username)));
			ssoHandle.setParentUser(this.getDeletedUserUserId(tenantId), userToBeDeleted.getUserid());
		});
	}

	private String getDeletedUserUserId(String tenantId) {
		return tenantId.toUpperCase() + "/" + this.deletedUserUsername;
	}

	private SsoUser getDeletedUser(String userId) {
		SsoUser user = this.sso1DAO.getSsoUser(userId).orElse(null);
		boolean isUserDeleted = user != null
				&& user.getParent_userid() != null
				&& user.getParent_userid().equals(this.getDeletedUserUserId(user.getTenant_id()));
		return isUserDeleted ? user : null;
	}

	private char nvl(Character value, char defaultValue) {
		if (value == null) {
			return defaultValue;
		}
		return value;
	}

	private short nvl(Short value, short defaultValue) {
		if (value == null) {
			return defaultValue;
		}
		return value;
	}

	private String nvl(String value, String defaultValue) {
		if (value == null) {
			return defaultValue;
		}
		return value;
	}

	private void checkUserHasRole(String tenantId, String username, String roleName) {
		SsoUser user = this.userService.getUser(tenantId, username).orElseThrow(NotFoundException::new);
		int rolesCount = this.sso1DAO.inTransaction(handle -> {
			int roleId = handle.getRoleIdFromNameAndTenant(roleName, tenantId);
			return handle.hasRole(user.getUserid(), roleId);
		});
		if (rolesCount == 0) {
			throw new ForbiddenException("User role mismatch");
		}
	}
}
