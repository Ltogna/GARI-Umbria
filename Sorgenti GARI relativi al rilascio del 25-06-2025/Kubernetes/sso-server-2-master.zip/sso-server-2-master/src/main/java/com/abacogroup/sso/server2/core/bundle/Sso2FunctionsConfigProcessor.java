package com.abacogroup.sso.server2.core.bundle;

import static java.util.stream.Collectors.toCollection;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.sso.server2.core.bundle.model.FunctionDefinition;
import com.abacogroup.sso.server2.core.bundle.model.FunctionID;
import com.abacogroup.sso.server2.core.bundle.model.FunctionsConfigMessage;
import com.abacogroup.sso.server2.core.bundle.model.RoleDefinition;
import com.abacogroup.sso.server2.core.bundle.model.RoleFunctions;
import com.abacogroup.sso.server2.db.ConfigDAO;
import com.abacogroup.sso.server2.db.ntt.SsoContextFunctionEntity;
import com.abacogroup.sso.server2.db.ntt.SsoRoleFunctionCodesEntity;
import com.abacogroup.sso.server2.db.ntt.SsoRolesEntity;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Sso2FunctionsConfigProcessor extends AbstractConfigProcessor {

	public Sso2FunctionsConfigProcessor(ConfigDAO configDAO, ObjectMapper objectMapper) {
		super(configDAO, objectMapper);
	}

	@Override
	public String getDomainName() {
		return "functions";
	}

	@Override
	public void onMessageInTransaction(ConfigDAO dao, ConfigDataMessage message) {
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> file.getAbsolutePath().endsWith(".json"))
				.forEach(file -> processFile(message.getTenantId(), file));
	}

	private void processFile(String tenantId, File file) {
		FunctionsConfigMessage message;
		try {
			message = objectMapper.readValue(file, FunctionsConfigMessage.class);
		} catch (IOException e) {
			throw new IllegalStateException("Error processing file " + file.getName() + " for tenant " + tenantId, e);
		}

		if (file.getAbsolutePath().endsWith(".delete.json")) {
			doDelete(tenantId, message);
		} else {
			doInsertOrUpdate(tenantId, message);
		}
	}

	// visible for testing
	void doInsertOrUpdate(String tenantId, FunctionsConfigMessage message) {
		if (message == null) {
			return;
		}

		insertOrUpdateFunctions(tenantId, message.getFunctions());
		insertOrUpdateRoles(tenantId, message.getRoles());
		insertOrUpdateRoleFunctions(tenantId, message.getRoleFunctions());
	}

	private void insertOrUpdateFunctions(String tenantId, List<FunctionDefinition> functions) {
		if (functions == null || functions.isEmpty()) {
			return;
		}

		insertContexts(tenantId, functions);

		for (FunctionDefinition currentFunction : functions) {
			SsoContextFunctionEntity ntt = configDAO.getSsoContextFunction(tenantId, currentFunction.getContext(), currentFunction.getCode());
			if (ntt == null) {
				ntt = new SsoContextFunctionEntity(configDAO.nextSsoContextFunctionId(),
						currentFunction.getContext(), currentFunction.getCode(), currentFunction.getDescription(), tenantId);
				configDAO.insertContextFunction(ntt);
			} else {
				configDAO.updateContextFunction(ntt.getFunctionId(), currentFunction.getDescription());
			}
		}
	}

	private void insertContexts(String tenantId, List<FunctionDefinition> functions) {
		Set<String> contextsToAdd = functions.stream()
				.map(FunctionDefinition::getContext)
				.distinct()
				.collect(toCollection(TreeSet::new));

		List<String> existingContexts = configDAO.getAllContextIds(tenantId);
		contextsToAdd.removeAll(existingContexts);

		contextsToAdd.forEach(contextId -> configDAO.insertContext(tenantId, contextId));
	}

	private void insertOrUpdateRoles(String tenantId, List<RoleDefinition> roles) {
		if (roles == null || roles.isEmpty()) {
			return;
		}

		for (RoleDefinition currentRole : roles) {
			SsoRolesEntity ntt = configDAO.getSsoRole(tenantId, currentRole.getCode());
			if (ntt == null) {
				ntt = new SsoRolesEntity(configDAO.nextSsoRoleId(), tenantId, currentRole.getCode(), currentRole.getDescription());
				configDAO.insertRole(ntt);
			} else {
				configDAO.updateRole(ntt.getRoleId(), currentRole.getDescription());
			}
		}
	}

	private void insertOrUpdateRoleFunctions(String tenantId, List<RoleFunctions> roleFunctions) {
		if (roleFunctions == null || roleFunctions.isEmpty()) {
			return;
		}

		for (RoleFunctions current : roleFunctions) {
			SsoRolesEntity currentRole = configDAO.getSsoRole(tenantId, current.getRoleCode());

			Set<FunctionID> functionsToAdd = new TreeSet<>(current.getFunctions());
			List<SsoRoleFunctionCodesEntity> allFunctions = configDAO.getRoleFunctionCodes(currentRole.getRoleId());

			allFunctions.forEach(f -> functionsToAdd.remove(new FunctionID(f.getContextId(), f.getFunctionCode())));
			functionsToAdd.forEach(fid -> {
				configDAO.insertRoleFunction(currentRole.getRoleId(), tenantId, fid.getContext(), fid.getCode());
			});
		}
	}

	// visible for testing
	void doDelete(String tenantId, FunctionsConfigMessage message) {
		if (message == null) {
			return;
		}

		deleteFunctions(tenantId, message.getFunctions());
		deleteRoles(tenantId, message.getRoles());
		deleteRoleFunctions(tenantId, message.getRoleFunctions());
	}

	private void deleteFunctions(String tenantId, List<FunctionDefinition> functions) {
		if (functions == null || functions.isEmpty()) {
			return;
		}

		functions.forEach(function -> configDAO.deleteFunction(tenantId, function.getContext(), function.getCode()));
	}

	private void deleteRoles(String tenantId, List<RoleDefinition> roles) {
		if (roles == null || roles.isEmpty()) {
			return;
		}

		roles.forEach(role -> configDAO.deleteRole(tenantId, role.getCode()));
	}

	private void deleteRoleFunctions(String tenantId, List<RoleFunctions> roleFunctions) {
		if (roleFunctions == null || roleFunctions.isEmpty()) {
			return;
		}

		for (RoleFunctions rf : roleFunctions) {
			SsoRolesEntity roleNtt = configDAO.getSsoRole(tenantId, rf.getRoleCode());
			for (FunctionID fun : rf.getFunctions()) {
				SsoContextFunctionEntity ntt = configDAO.getSsoContextFunction(tenantId, fun.getContext(), fun.getCode());
				if (ntt != null) {
					configDAO.deleteRoleFunction(roleNtt.getRoleId(), ntt.getFunctionId());
				}
			}
		}

	}

}
