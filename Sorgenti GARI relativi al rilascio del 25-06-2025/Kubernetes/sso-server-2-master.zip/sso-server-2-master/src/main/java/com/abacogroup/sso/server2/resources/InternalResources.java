package com.abacogroup.sso.server2.resources;

import static com.abacogroup.dropwizard.auth.sso2.Constants.AUTH_AUDIENCE;

import java.time.Duration;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.function.BiFunction;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.ws.rs.BadRequestException;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.ForbiddenException;
import javax.ws.rs.GET;
import javax.ws.rs.InternalServerErrorException;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.ServiceUnavailableException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.sso.server2.api.TotpVerificationRequest;
import com.abacogroup.sso.server2.api.internal.GetTokenRequest;
import com.abacogroup.sso.server2.api.internal.StringResponse;
import com.abacogroup.sso.server2.core.TotpService;
import com.abacogroup.sso.server2.core.UserService;
import com.abacogroup.sso.server2.core.model.CreateLoginTokenParams;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.abacogroup.sso.server2.db.ntt.SsoUser;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;

@Path("/internal-api")
@Timed
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Tag(name = "Internal", description = "Internal APIs, not exposed on the internet")
public class InternalResources {
	private final UserService userService;
	private JWTVerifier verifier;
	private TotpService totpService;

	public InternalResources(String tasksAuthSecret, UserService userService, TotpService totpService) {
		this.userService = userService;
		this.totpService = totpService;

		String secret = tasksAuthSecret;
		if (secret == null || secret.isBlank()) {
			return;
		}

		this.verifier = JWT.require(Algorithm.HMAC256(secret))
				.acceptLeeway(5_000)
				.build();
	}

	@POST
	@Path("/exchange-token")
	@Operation(description = "Exchange a signed JWT request for an access token")
	public StringResponse exechangeToken(@NotNull @Valid GetTokenRequest req) {
		if (verifier == null) {
			throw new ServiceUnavailableException("tasksAuthPhrase not set; cannot issue any tokens");
		}

		DecodedJWT jwt = verifyToken(req);

		String userid = jwt.getSubject();

		Claim tenantClaim = jwt.getClaim("tenant");
		Claim usernameClaim = jwt.getClaim("username");
		String tenant = tenantClaim.isNull() ? Sso1DAO.DEFAULT_TENANT : tenantClaim.asString();
		String username = usernameClaim.asString();

		if (username == null) {
			SsoUser user = userService.getUser(userid)
					.orElseThrow(() -> new NotFoundException("User id not found: " + userid));
			username = user.getUsername();
		}

		return new StringResponse(userService.createAuthToken(userid, username, tenant, AUTH_AUDIENCE, OffsetDateTime.now()));
	}

	@POST
	@Path("/exchange-token-by-username")
	@Operation(description = "Exchange a signed JWT request (containing the user name and not the userid) for an access token")
	public StringResponse exechangeTokenByUserName(@NotNull @Valid GetTokenRequest req) {
		return useUserFromToken(req, (user, jwt) -> new StringResponse(
				userService.createAuthToken(user.getUserid(), user.getUsername(), user.getTenant_id(), AUTH_AUDIENCE, OffsetDateTime.now())));
	}

	@POST
	@Path("/login-token-by-username")
	@Operation(description = "Exchange a signed JWT request for a login token")
	public StringResponse getLoginToken(@NotNull @Valid GetTokenRequest req) {
		return useUserFromToken(req,
				(user, jwt) -> {
					String sessionId = jwt.getClaim(UserService.USER_SESSION_CLAIM).asString();
					if (sessionId == null || sessionId.isBlank()) {
						sessionId = CreateLoginTokenParams.createSessionID();
					}

					OffsetDateTime now = OffsetDateTime.now();
					CreateLoginTokenParams params = CreateLoginTokenParams.builder()
							.end(now.plus(41, ChronoUnit.MINUTES))
							.session(sessionId)
							.start(now)
							.tenant(user.getTenant_id())
							.userId(user.getUserid())
							.username(user.getUsername())
							.build();

					return new StringResponse(userService.createLoginToken(params));
				});
	}

	private DecodedJWT verifyToken(GetTokenRequest req) {
		if (verifier == null) {
			throw new ServiceUnavailableException("tasksAuthPhrase not set; cannot issue any tokens");
		}

		try {
			return verifier.verify(req.getRequestToken());
		} catch (Exception e) {
			throw new BadRequestException("Cannot validate the request");
		}
	}

	private <T> T useUserFromToken(GetTokenRequest req, BiFunction<SsoUser, DecodedJWT, T> func) {
		DecodedJWT jwt = verifyToken(req);

		String username = jwt.getSubject();

		Claim tenantClaim = jwt.getClaim("tenant");
		String tenant = tenantClaim.asString();

		SsoUser user = userService.getUser(tenant, username)
				.orElseThrow(() -> new NotFoundException("User not found: " + tenant + "/" + username));

		return func.apply(user, jwt);
	}

	@GET
	@Path("/get-long-living-token")
	@Operation(description = "Get a logn living access token")
	public StringResponse getLongLivingAuthToken(@Parameter(hidden = true) @Auth User user,
			@QueryParam("durationInMnutes") @NotNull @Min(10) @Max(120) @DefaultValue("120") Short durationInMnutes) {
		// no need to verify, @Auth guarantees that the token is valid
		DecodedJWT jwt = JWT.decode(user.getAuthToken());

		/*
		 * We allow tokens to be made "long living" only once; the dropwizard-auth-sso2 client does this automatically for server to server communications, to
		 * avoid using expired tokens to call other services.
		 *
		 * i.e.: we receive an access token expiring in 5 seconds; we do some operation that last 6 seconds; we then call another service using the auth token;
		 * this last call would fail, because the token is now expired.
		 *
		 * This long living tokens must not leave the internal network and must not be renewable for security reasons (i.e.: if the token is somehow stolen).
		 *
		 * You need to use a refresh token to refresh an access token for the public internet.
		 */
		Claim longLiving = jwt.getClaim(UserService.LONG_LIVING_AUTH_TOKEN_CLAIM);
		if (!longLiving.isNull() && longLiving.asBoolean()) {
			throw new ForbiddenException("You cannot extend the duration of a long living access token");
		}

		var now = OffsetDateTime.now();
		return new StringResponse(userService.createAuthToken(user.getUserId(), user.getName(), user.getTenant(), AUTH_AUDIENCE,
				now, now.plus(Duration.ofMinutes(durationInMnutes))));
	}

	@POST
	@Path("{tenant}/{key}/code")
	@Operation(description = "Validates a totp token using the specified key")
	public Response validateCode(@PathParam("key") String key, @PathParam("tenant") String tenantId, TotpVerificationRequest request) {
		if (totpService.validateTotp(key, request.getCode(), true)) {
			return Response.status(204).build();
		}
		return Response.status(403).build();
	}

	@GET
	@Path("{tenant}/{key}/get-code")
	@Produces("application/json")
	@Operation(description = "Generates a totp token using the specified key")
	public StringResponse produceCode(@PathParam("key") String key, @PathParam("tenant") String tenantId) {
		try {
			return new StringResponse(totpService.createTotpCode(key));
		} catch (Exception e) {
			throw new InternalServerErrorException("Could produce a top code, reason: " + e.getMessage());
		}
	}
}
