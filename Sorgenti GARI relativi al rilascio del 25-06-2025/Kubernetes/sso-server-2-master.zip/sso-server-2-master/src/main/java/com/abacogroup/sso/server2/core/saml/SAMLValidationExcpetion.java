package com.abacogroup.sso.server2.core.saml;

public class SAMLValidationExcpetion extends RuntimeException {

	private static final long serialVersionUID = -4525035549588382910L;

	public SAMLValidationExcpetion(String message, Throwable cause) {
		super(message, cause);
	}

	public SAMLValidationExcpetion(String message) {
		super(message);
	}

	public SAMLValidationExcpetion(Throwable cause) {
		super(cause);
	}

}
