package com.abacogroup.sso.server2.core.entities.dbgis;

import lombok.Data;

@Data
public class TimeSeKillNtt {
    private String time;
    private String utime;
    private String server_id;
    private Integer tz_offset_sec;
}
