package com.abacogroup.sso.server2.resources;

import java.util.List;

import javax.annotation.security.RolesAllowed;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.sso.server2.api.CreateRoleRequest;
import com.abacogroup.sso.server2.api.CreateUserRequest;
import com.abacogroup.sso.server2.api.FunctionRequest;
import com.abacogroup.sso.server2.api.Language;
import com.abacogroup.sso.server2.api.RoleData;
import com.abacogroup.sso.server2.api.UpdateUserRequest;
import com.abacogroup.sso.server2.api.UserData;
import com.abacogroup.sso.server2.api.UserDetails;
import com.abacogroup.sso.server2.core.UserManagementService;
import com.abacogroup.sso.server2.core.UserService;
import com.abacogroup.sso.server2.exceptions.UserAlreadyExistsException;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Path("{tenant}/public/v1/user-management")
@Tag(name = "Users managements", description = "Users management APIs")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@RolesAllowed(("SSO2|ADMIN"))
public class UserManagementResources implements TenantCheckable {
	private UserManagementService userManagementService;
	private UserService userService;

	public UserManagementResources(UserManagementService userManagementService, UserService userService) {
		this.userManagementService = userManagementService;
		this.userService = userService;
	}

	@POST
	@Path("/")
	@Operation(summary = "Create user", description = "Creates a new user")
	@ApiResponse(responseCode = "409", description = "The user already exists", content = @Content(schema = @Schema(implementation = UserAlreadyExistsException.UserAlreadyExistsExceptionErrorBody.class)))
	public UserData createUser(@PathParam("tenant") String tenantId, @Parameter(hidden = true) @Auth User userExecutingCreation,
			@Valid @NotNull CreateUserRequest createUserRequest) {
		checkTenant(tenantId, userExecutingCreation);

		this.userManagementService.createUser(tenantId, createUserRequest);
		return userService.getUser(tenantId, createUserRequest.getUsername())
				.map(ssoUser -> UserData.builder()
						.description(ssoUser.getDescr())
						.tenant(ssoUser.getTenant_id())
						.userId(ssoUser.getUserid())
						.userName(ssoUser.getUsername())
						.build())
				.orElseThrow(() -> new NotFoundException("Unable to create new user"));
	}

	@DELETE
	@Path("/{username}")
	@Operation(summary = "Delete user", description = "Deletes a user")
	public void deleteUser(@PathParam("tenant") String tenantId, @PathParam("username") String username,
			@Parameter(hidden = true) @Auth User userExecutingDeletion) {
		checkTenant(tenantId, userExecutingDeletion);
		this.userManagementService.deleteUser(tenantId, username);
	}

	@POST
	@Path("/roles")
	@Operation(summary = "Create a role", description = "Creates a new role")
	public void createRole(
			@PathParam("tenant") String tenantId,
			@Parameter(hidden = true) @Auth User userExecutingAction,
			@NotNull @Valid List<CreateRoleRequest> roleRequest) {
		checkTenant(tenantId, userExecutingAction);
		roleRequest.forEach(role -> {
			try {
				this.userManagementService.createRole(tenantId, role);
			} catch (IllegalStateException e) {
				log.info("role already present skipping");
			}
		});
	}

	@POST
	@Path("/{username}/roles")
	@Operation(summary = "Assign roles to a user")
	public void assignRolesToUser(
			@PathParam("tenant") String tenantId,
			@PathParam("username") String username,
			@Parameter(hidden = true) @Auth User userExecutingAction,
			@QueryParam("ignoreUnknownRoles") @DefaultValue("false") boolean ignoreUnknownRoles,
			@NotNull List<String> roleCodes) {
		checkTenant(tenantId, userExecutingAction);
		this.userManagementService.assignRolesToUser(roleCodes, tenantId, username, userExecutingAction, ignoreUnknownRoles);
	}

	@PUT
	@Path("/{username}/roles")
	@Operation(summary = "Set user roles, removing any previously assigned role")
	public void setUserRoles(
			@PathParam("tenant") String tenantId,
			@PathParam("username") String username,
			@Parameter(hidden = true) @Auth User userExecutingAction,
			@QueryParam("ignoreUnknownRoles") @DefaultValue("false") boolean ignoreUnknownRoles,
			@NotNull List<String> roleCodes) {
		checkTenant(tenantId, userExecutingAction);
		this.userManagementService.setUserRoles(roleCodes, tenantId, username, userExecutingAction, ignoreUnknownRoles);
	}

	@DELETE
	@Path("/{username}/roles")
	@Consumes(MediaType.APPLICATION_JSON)
	@Operation(summary = "Remove roles from a user")
	public void removeRolesFromUser(
			@PathParam("tenant") String tenantId,
			@PathParam("username") String username,
			@Parameter(hidden = true) @Auth User userExecutingAction,
			@QueryParam("roleCode") @NotNull List<@NotEmpty String> roleCodes) {
		checkTenant(tenantId, userExecutingAction);
		this.userManagementService.removeRolesFromUser(roleCodes, tenantId, username, userExecutingAction.getUserId());
	}

	@POST
	@Path("/{username}/functions")
	@Operation(summary = "Grant permissions", description = "Assign a set of functions (ignoring non existsnt functions) to a role that must be already granted to a user")
	public void assignFunctionsToUser(
			@PathParam("tenant") String tenantId,
			@PathParam("username") String username,
			@Parameter(hidden = true) @Auth User userExecutingAction,
			@NotNull FunctionRequest functionRequest) {
		checkTenant(tenantId, userExecutingAction);
		this.userManagementService.assignFunctionToUser(functionRequest, tenantId, username, true);
	}

	@POST
	@Path("/{username}/functions/bulk-delete")
	@Operation(summary = "Removes permissions", description = "Removes a set of functions to a role that must be already granted to a user")
	public void removeFunctionFromUser(
			@PathParam("tenant") String tenantId,
			@PathParam("username") String username,
			@Parameter(hidden = true) @Auth User userExecutingAction,
			@NotNull FunctionRequest functionRequest) {
		checkTenant(tenantId, userExecutingAction);
		this.userManagementService.removeFunctionFromUser(functionRequest, tenantId, username);
	}

	@GET
	@Path("/users")
	@Operation(description = "Get all users list")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "The users list")
	})
	public InfiniteListResults<UserDetails> getUsers(
			@PathParam("tenant") String tenantId,
			@Parameter(description = "used to filter the results") @QueryParam("search") String search,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User userExecutingAction) {
		checkTenant(tenantId, userExecutingAction);
		return this.userManagementService.getUsers(tenantId, search, nextKey);
	}

	@GET
	@Path("/users/{username}")
	@Operation(description = "Get a user details")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "The user"),
			@ApiResponse(responseCode = "404", description = "The user was not found")
	})
	public @NotNull UserDetails getUser(
			@PathParam("tenant") String tenantId,
			@PathParam("username") String username,
			@Parameter(hidden = true) @Auth User userExecutingAction) {
		checkTenant(tenantId, userExecutingAction);

		UserDetails user = this.userManagementService.getUserDetails(tenantId, username);

		if (user == null) {
			throw new NotFoundException("User not found!");
		}
		return user;
	}

	@PUT
	@Path("/users/{username}")
	@Operation(description = "Modifies a user")
	public UserDetails updatedUser(
			@PathParam("tenant") String tenantId,
			@PathParam("username") String username,
			@Parameter(hidden = true) @Auth User userExecutingUpdate,
			@Valid @NotNull UpdateUserRequest updatedUserRequest) {
		checkTenant(tenantId, userExecutingUpdate);

		this.userManagementService.updateUser(tenantId, username, updatedUserRequest);
		return this.userManagementService.getUserDetails(tenantId, username);
	}

	@GET
	@Path("/roles")
	@Operation(description = "Get roles list")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "The roles list")
	})
	public InfiniteListResults<RoleData> getRoles(
			@PathParam("tenant") String tenantId,
			@Parameter(description = "Used to filter return list of roles based on the search string") @DefaultValue("") @QueryParam("search") String search,
			@Parameter(description = "Can be supplied to obtain the records that follows those obtained by a previous call") @QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User userExecutingAction) {
		checkTenant(tenantId, userExecutingAction);
		return this.userManagementService.getRoles(tenantId, search, nextKey);
	}

	@GET
	@Path("/languages")
	@Operation(description = "Get the list of all languages")
	public List<Language> getLanguages(
			@Parameter(hidden = true) @Auth User userExecutingAction,
			@PathParam("tenant") String tenantId,
			@HeaderParam("accept-language") @DefaultValue("en") String language) {
		checkTenant(tenantId, userExecutingAction);
		return this.userManagementService.getLanguages(tenantId, language);
	}
}
