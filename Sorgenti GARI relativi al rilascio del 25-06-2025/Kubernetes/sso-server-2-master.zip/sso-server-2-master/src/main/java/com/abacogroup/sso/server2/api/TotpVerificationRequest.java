package com.abacogroup.sso.server2.api;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class TotpVerificationRequest {

	@Schema(description = "The code to verify")
	private String code;
	
	

}
