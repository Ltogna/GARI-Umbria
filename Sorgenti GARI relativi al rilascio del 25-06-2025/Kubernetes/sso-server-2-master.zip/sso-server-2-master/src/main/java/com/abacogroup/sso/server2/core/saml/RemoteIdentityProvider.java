package com.abacogroup.sso.server2.core.saml;

import static com.abacogroup.dropwizard.auth.sso2.Constants.ISSUER;

import java.io.ByteArrayInputStream;
import java.util.Date;
import java.util.Optional;
import java.util.Properties;
import java.util.function.Predicate;

import org.opensaml.core.criterion.EntityIdCriterion;
import org.opensaml.core.xml.XMLObject;
import org.opensaml.core.xml.config.XMLObjectProviderRegistrySupport;
import org.opensaml.core.xml.io.Unmarshaller;
import org.opensaml.saml.common.xml.SAMLConstants;
import org.opensaml.saml.criterion.EntityRoleCriterion;
import org.opensaml.saml.metadata.resolver.impl.DOMMetadataResolver;
import org.opensaml.saml.metadata.resolver.impl.PredicateRoleDescriptorResolver;
import org.opensaml.saml.saml2.core.Issuer;
import org.opensaml.saml.saml2.core.NameID;
import org.opensaml.saml.saml2.metadata.EntityDescriptor;
import org.opensaml.saml.saml2.metadata.IDPSSODescriptor;
import org.opensaml.saml.saml2.metadata.SingleLogoutService;
import org.opensaml.saml.saml2.metadata.SingleSignOnService;
import org.opensaml.saml.security.impl.MetadataCredentialResolver;
import org.opensaml.security.credential.Credential;
import org.opensaml.security.credential.UsageType;
import org.opensaml.xmlsec.config.impl.DefaultSecurityConfigurationBootstrap;
import org.opensaml.xmlsec.keyinfo.KeyInfoCredentialResolver;
import org.opensaml.xmlsec.signature.Signature;
import org.opensaml.xmlsec.signature.support.SignatureConstants;
import org.opensaml.xmlsec.signature.support.SignatureException;
import org.opensaml.xmlsec.signature.support.SignatureValidator;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;

import net.shibboleth.utilities.java.support.resolver.CriteriaSet;
import net.shibboleth.utilities.java.support.xml.ParserPool;

public class RemoteIdentityProvider {
	private static final long AUTHN_ID_DURATION_MS = 1000L * 60 * 15;
	private static final String SAML_AUTHN_AUDIENCE = "SAML-AUTHN";

	private ParserPool parserPool;
	private Algorithm algorithm;
	private JWTVerifier verifier;

	private String destinationUrl;
	private String canonicalizationAlgorithm;
	private String entityID;
	private Iterable<Credential> credentials;
	private SingleSignOnService singleSignOnService;
	private SingleLogoutService singleLogoutService;
	private final Predicate<String> IssuerFormatResponseCheck = format -> format != null && !format.isEmpty() && !NameID.ENTITY.equals((format));
	private final Predicate<String> IssuerFormatAssertionCheck = format -> format == null || format.isEmpty() || !NameID.ENTITY.equals(format);

	public RemoteIdentityProvider(ParserPool parserPool, Algorithm algorithm, byte[] metadataBytes, Properties props) {
		this.parserPool = parserPool;
		this.algorithm = algorithm;

		try {
			init(metadataBytes, props);
		} catch (Exception e) {
			throw new IllegalStateException(e.getMessage(), e);
		}

		verifier = JWT.require(algorithm)
				.acceptLeeway(5000)
				.withIssuer(ISSUER)
				.withAudience(SAML_AUTHN_AUDIENCE)
				.withSubject(getEntityID())
				.build();
	}

	public String createAuthnID() {
		long now = System.currentTimeMillis();
		return JWT.create()
				.withIssuer(ISSUER)
				.withAudience(SAML_AUTHN_AUDIENCE)
				.withSubject(getEntityID())
				.withIssuedAt(new Date(now))
				.withExpiresAt(new Date(now + AUTHN_ID_DURATION_MS))
				.sign(algorithm);
	}

	public void validateAuthnID(String id) {
		try {
			verifier.verify(id);
		} catch (JWTVerificationException e) {
			throw new SAMLValidationExcpetion("Bad Authn ID", e);
		}

	}

	public Predicate<String> getIssuerFormatAssertionCheck() {
		return IssuerFormatAssertionCheck;
	}

	public Predicate<String> getIssuerFormatResponseCheck() {
		return IssuerFormatResponseCheck;
	}

	public void validateIssuer(Issuer issuer, boolean strictCheks, Predicate<String> condition) {
		if (issuer == null) {
			throw new SAMLValidationExcpetion("Issuer is null");
		}

		String format = issuer.getFormat();
		if (strictCheks && condition.test(format)) {
			throw new SAMLValidationExcpetion("Format attribute must be equal to: " + NameID.ENTITY);
		}

		if (!getEntityID().equals(issuer.getValue())) {
			throw new SAMLValidationExcpetion("Bad issuer; expected: " + getEntityID() + " got: " + issuer.getValue());
		}
	}

	public String getEntityID() {
		return entityID;
	}

	public String getDestinationUrl() {
		return destinationUrl;
	}

	public String getCanonicalizationAlgorithm() {
		return canonicalizationAlgorithm;
	}

	public SingleSignOnService getSingleSignOnService() {
		return singleSignOnService;
	}

	public Optional<SingleLogoutService> getSingleLogoutService() {
		return Optional.ofNullable(singleLogoutService);
	}

	public void validateSignature(Signature signature) throws SignatureException {
		boolean ok = false;
		for (Credential c : credentials) {
			if (c.getUsageType() != UsageType.SIGNING) {
				continue;
			}

			try {
				SignatureValidator.validate(signature, c);
				ok = true;
				break;
			} catch (SignatureException e) {
				// Try next credential, if any...
			}
		}

		if (!ok) {
			throw new SignatureException("Invalid signature");
		}
	}

	private void init(byte[] metadataBytes, Properties props) throws Exception {
		Document doc = parserPool.parse(new ByteArrayInputStream(metadataBytes));
		Element el = doc.getDocumentElement();

		Unmarshaller unmarshaller = XMLObjectProviderRegistrySupport.getUnmarshallerFactory().getUnmarshaller(el);
		XMLObject obj = unmarshaller.unmarshall(el);
		if (!(obj instanceof EntityDescriptor)) {
			throw new IllegalStateException("Bad IDP metadata XML document");
		}

		EntityDescriptor entityDescriptor = (EntityDescriptor) obj;
		this.entityID = entityDescriptor.getEntityID();

		String tmp = props.getProperty("destinationUrl");
		this.destinationUrl = tmp == null ? entityID : tmp;

		tmp = props.getProperty("canonicalizationAlgorithm");
		this.canonicalizationAlgorithm = tmp == null ? SignatureConstants.ALGO_ID_C14N11_OMIT_COMMENTS : tmp;

		DOMMetadataResolver domResolver = new DOMMetadataResolver(doc.getDocumentElement());
		domResolver.setId("domResolver");
		domResolver.initialize();

		PredicateRoleDescriptorResolver roleDescriptorResolver = new PredicateRoleDescriptorResolver(domResolver);
		roleDescriptorResolver.initialize();

		KeyInfoCredentialResolver keyInfoCredentialResolver = DefaultSecurityConfigurationBootstrap.buildBasicInlineKeyInfoCredentialResolver();

		MetadataCredentialResolver credentialResolver = new MetadataCredentialResolver();
		credentialResolver.setRoleDescriptorResolver(roleDescriptorResolver);
		credentialResolver.setKeyInfoCredentialResolver(keyInfoCredentialResolver);
		credentialResolver.initialize();

		CriteriaSet criteriaSet = new CriteriaSet();
		criteriaSet.add(new EntityIdCriterion(entityID));
		criteriaSet.add(new EntityRoleCriterion(IDPSSODescriptor.DEFAULT_ELEMENT_NAME));

		credentials = credentialResolver.resolve(criteriaSet);

		initSsoAndSlo(entityDescriptor);
	}

	private void initSsoAndSlo(EntityDescriptor entityDescriptor) {
		IDPSSODescriptor idpSSODescriptor = entityDescriptor.getIDPSSODescriptor(SAMLConstants.SAML20P_NS);
		if (idpSSODescriptor == null) {
			throw new IllegalStateException("No IDPSSODescriptor in metadata");
		}

		this.singleSignOnService = idpSSODescriptor.getSingleSignOnServices().stream()
				.filter(s -> SAMLConstants.SAML2_POST_BINDING_URI.equals(s.getBinding()))
				.findFirst()
				.orElseThrow(() -> new IllegalStateException("No SingleSignOnService with HTTP-POST binding found"));

		this.singleLogoutService = idpSSODescriptor.getSingleLogoutServices().stream()
				.filter(s -> SAMLConstants.SAML2_POST_BINDING_URI.equals(s.getBinding()))
				.findFirst()
				.orElse(null);
	}

}
