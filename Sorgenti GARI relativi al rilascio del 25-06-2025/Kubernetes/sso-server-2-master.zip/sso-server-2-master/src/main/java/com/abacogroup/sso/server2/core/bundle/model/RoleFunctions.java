package com.abacogroup.sso.server2.core.bundle.model;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoleFunctions {
	private String roleCode;
	private List<FunctionID> functions = new ArrayList<>();
}
