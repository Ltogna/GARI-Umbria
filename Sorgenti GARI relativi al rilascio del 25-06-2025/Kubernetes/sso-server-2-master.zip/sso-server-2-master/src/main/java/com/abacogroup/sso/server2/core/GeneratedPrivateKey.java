package com.abacogroup.sso.server2.core;

import java.security.interfaces.RSAPrivateKey;

import lombok.Value;

@Value
public class GeneratedPrivateKey {
	private String id;
	private RSAPrivateKey key;
}
