package com.abacogroup.sso.server2.core.saml;

import java.util.UUID;

import javax.xml.namespace.QName;

import org.opensaml.core.xml.XMLObjectBuilderFactory;
import org.opensaml.core.xml.config.XMLObjectProviderRegistrySupport;
import org.opensaml.core.xml.schema.XSAny;
import org.opensaml.core.xml.schema.XSString;
import org.opensaml.core.xml.schema.impl.XSAnyBuilder;
import org.opensaml.core.xml.schema.impl.XSStringBuilder;

public class OpenSAMLUtils {
	public static final String SPID_NS = "https://spid.gov.it/saml-extensions";
	public static final String SPID_PREFIX = "spid";

	@SuppressWarnings("unchecked")
	public static <T> T buildSAMLObject(final Class<T> clazz) {
		T object = null;
		try {
			XMLObjectBuilderFactory builderFactory = XMLObjectProviderRegistrySupport.getBuilderFactory();
			QName defaultElementName = (QName) clazz.getDeclaredField("DEFAULT_ELEMENT_NAME").get(null);
			object = (T) builderFactory.getBuilder(defaultElementName).buildObject(defaultElementName);
		} catch (IllegalAccessException e) {
			throw new IllegalArgumentException("Could not create SAML object");
		} catch (NoSuchFieldException e) {
			throw new IllegalArgumentException("Could not create SAML object");
		}

		return object;
	}

	public static XSAny buildAnySpid(String tagName) {
		return new XSAnyBuilder().buildObject(SPID_NS, tagName, SPID_PREFIX);
	}

	public static XSString buildXSString(QName qname) {
		return new XSStringBuilder().buildObject(qname);
	}

	public static String generateSecureRandomId() {
		return "_" + UUID.randomUUID().toString();
	}

}
