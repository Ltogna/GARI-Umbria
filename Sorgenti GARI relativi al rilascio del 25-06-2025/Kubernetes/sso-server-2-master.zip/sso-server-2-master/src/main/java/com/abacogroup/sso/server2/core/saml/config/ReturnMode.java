package com.abacogroup.sso.server2.core.saml.config;

import lombok.Data;

import javax.validation.constraints.NotEmpty;

@Data
public class ReturnMode {
	@NotEmpty
	private String url;
	private boolean create = false;
	private boolean jwt = false;
	private String context;
	private String roleName;
}
