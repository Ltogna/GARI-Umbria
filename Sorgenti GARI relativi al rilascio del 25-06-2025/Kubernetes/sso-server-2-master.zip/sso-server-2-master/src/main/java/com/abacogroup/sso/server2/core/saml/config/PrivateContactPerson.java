package com.abacogroup.sso.server2.core.saml.config;

import javax.validation.constraints.NotEmpty;

import lombok.Data;

@Data
public class PrivateContactPerson implements ContactPersonConfig {
	@NotEmpty
	private String email;
	private String vatNumber;
	private String fiscalCode;
	private String phoneNumber;
	private final boolean isPublic = false;
}
