package com.abacogroup.sso.server2.core.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Function {
	private Integer functionId;
	private String contextId;
	private String name;
	private String descr;
	private String tenantId;

	@Override
	public String toString() {
		StringBuilder buff = new StringBuilder();
		buff.append(functionId).append('|').append(name).append('|').append(contextId);
		return buff.toString();
	}

}
