package com.abacogroup.sso.server2.core.passwords;

public class NoSuchPasswordHasherException extends RuntimeException {

	private static final long serialVersionUID = -1827892457133783028L;

	public NoSuchPasswordHasherException(String name) {
		super("Unknown password hasher: " + name);
	}

	@Override
	public StackTraceElement[] getStackTrace() {
		return new StackTraceElement[0];
	}
}
