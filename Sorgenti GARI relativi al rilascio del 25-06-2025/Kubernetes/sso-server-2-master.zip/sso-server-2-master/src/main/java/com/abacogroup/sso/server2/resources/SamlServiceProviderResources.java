package com.abacogroup.sso.server2.resources;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotEmpty;
import javax.ws.rs.BadRequestException;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.sso.client.SSO;
import com.abacogroup.sso.server2.api.LoginResponse;
import com.abacogroup.sso.server2.api.SpidUser;
import com.abacogroup.sso.server2.core.SpidService;
import com.abacogroup.sso.server2.core.UserService;
import com.abacogroup.sso.server2.core.saml.AssertedAttributes;
import com.abacogroup.sso.server2.core.saml.AuthnRequestObj;
import com.abacogroup.sso.server2.core.saml.RemoteIdentityProvider;
import com.abacogroup.sso.server2.core.saml.ResponseAttributes;
import com.abacogroup.sso.server2.core.saml.SPIDUserAnomalyException;
import com.abacogroup.sso.server2.core.saml.ServiceProvider;
import com.abacogroup.sso.server2.core.saml.config.ReturnMode;
import com.abacogroup.sso.server2.resources.exceptions.UnauthorizedException;
import com.abacogroup.sso.server2.views.saml.InitLoginView;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.views.common.View;
import io.swagger.v3.oas.annotations.tags.Tag;

@Timed
@Path("/api/v1/saml")
@Tag(name = "SAML", description = "Deprecated, backwards compatibility for direct SAML integration, use the api gateway instead")
public class SamlServiceProviderResources {
	private final String SPID_ERROR_STATUS = "SPID_ERROR_STATUS";
	private final String SPID_ERROR_MESSAGE = "SPID_ERROR_MESSAGE";
	private final String USER_JWT = "USER_JWT";

	private static final Logger log = LoggerFactory.getLogger(SamlServiceProviderResources.class);

	private String contextPath;
	private UserService userService;
	private SpidService spidService;
	private Map<String, ServiceProvider> serviceProviders;

	private ConcurrentHashMap<String, String> cachedMetadata;

	public SamlServiceProviderResources(String contextPath, UserService userService, SpidService spidService, Map<String, ServiceProvider> serviceProviders) {
		this.contextPath = contextPath;
		this.userService = userService;
		this.spidService = spidService;
		this.serviceProviders = Collections.unmodifiableMap(serviceProviders);
		this.cachedMetadata = new ConcurrentHashMap<>();
	}

	@GET
	@Path("/tags/{tag}/count")
	public Integer getTagCounts(@PathParam("tag") String tag) {
		return (int) serviceProviders
				.values()
				.stream()
				.filter(sp -> sp.isTagPresent(tag))
				.count();
	}

	@GET
	@Path("/{service}/metadata")
	@Produces(MediaType.TEXT_XML)
	public String getMetadata(@PathParam("service") String service, @Context HttpServletRequest request) {
		ServiceProvider sp = getServiceProvider(service);
		return cachedMetadata.computeIfAbsent(service, k -> sp.createMetadata(getContextBaseURL(request)));
	}

	@GET
	@Path("/{service}/idp/{name}/init-login")
	@Produces(MediaType.TEXT_HTML)
	public View initLogin(@PathParam("service") String service, @PathParam("name") String remoteIdpName,
			@QueryParam("return") @NotEmpty String returnURL, @Context HttpServletRequest request) {

		ServiceProvider sp = getServiceProvider(service);

		Optional<ReturnMode> mode = sp.getReturnMode(returnURL);
		if (mode.isEmpty()) {
			throw new BadRequestException("<b>" + returnURL + "</b> is not a valid return choice");
		}

		RemoteIdentityProvider idp = sp.getRemoteIDPByName(remoteIdpName)
				.orElseThrow(() -> new NotFoundException("No IDP with name " + remoteIdpName));

		AuthnRequestObj authnRequest = sp.createLoginRequest(idp);
		this.spidService.logSpidRequest(authnRequest);
		String b64 = Base64.getEncoder().encodeToString(authnRequest.getRequest().getBytes());

		return new InitLoginView(idp, b64, returnURL);
	}

	@POST
	@Path("/{service}/ac")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public View assertionConsumer(@PathParam("service") String service,
			@FormParam("SAMLResponse") @NotEmpty String base64SamlResponse, @FormParam("RelayState") String relayState,
			@Context HttpServletRequest request) {
		ServiceProvider sp = getServiceProvider(service);

		ReturnMode returnMode = sp.getReturnMode(relayState)
				.orElseThrow(() -> new BadRequestException(relayState + " is not a valid return choice"));
		String uriString = returnMode.getUrl();
		AssertedAttributes attributes;

		URI uri;
		try {
			byte[] tmp = Base64.getDecoder().decode(base64SamlResponse);
			String samlResponse = new String(tmp, StandardCharsets.UTF_8);

			ResponseAttributes rsAttributes = sp.getAssertedAttributes(samlResponse, getContextBaseURL(request));
			this.spidService.logSpidResponse(samlResponse, rsAttributes.getInResponseTo());
			attributes = rsAttributes.getAttributes();
			if (!attributes.isSuccess()) {
				throw new IllegalStateException("SAML asserted attributes error: isSuccess = false");
			}

			if (returnMode.isJwt()) {
				uri = this.returnJWT(sp, attributes, returnMode);
			} else {
				uri = this.returnSSO(sp, attributes, returnMode, request.getRemoteAddr());
			}
		} catch (WebApplicationException e) {
			log.warn(e.toString());
			uri = UriBuilder.fromUri(uriString)
					.queryParam(SPID_ERROR_MESSAGE, e.getMessage())
					.queryParam(SPID_ERROR_STATUS, e.getResponse().getStatus())
					.build();
		} catch (SPIDUserAnomalyException e) {
			log.warn(e.toString());
			uri = UriBuilder.fromUri(uriString)
					.queryParam(SPID_ERROR_MESSAGE, e.getMessage())
					.queryParam(SPID_ERROR_STATUS, 400)
					.build();
		} catch (Exception e) {
			log.warn(e.toString());
			uri = UriBuilder.fromUri(uriString)
					.queryParam(SPID_ERROR_MESSAGE, e.getMessage())
					.queryParam(SPID_ERROR_STATUS, 500)
					.build();
		}

		Response response = Response.seeOther(uri).build();
		throw new WebApplicationException(response);
	}

	private URI returnSSO(ServiceProvider sp, AssertedAttributes attributes, ReturnMode returnMode, String remoteAddr) {
		String userId = this.userService.getUserIdFromFiscalCode(attributes.get("fiscalNumber"), sp.getSsoUserPropertiesFields().get("fiscalNumber"),
				returnMode.isCreate());
		if (userId == null) {
			userId = this.spidService.createUserFromSpid(attributes, sp.getSsoUserPropertiesFields(), returnMode);
		}

		LoginResponse loginResponse = userService.loginFromExternalSysWithoutPassword(userId, remoteAddr);
		String token = loginResponse.getAuth_token();
		return UriBuilder.fromUri(returnMode.getUrl())
				.queryParam(SSO.SSO_TOKEN, "j2_" + token)
				.build();
	}

	private URI returnJWT(ServiceProvider sp, AssertedAttributes attributes, ReturnMode returnMode) {
		String JWT = this.spidService.createUserJWTFromSpid(attributes, sp.getRequiredAttibutes());
		return UriBuilder.fromUri(returnMode.getUrl())
				.queryParam(USER_JWT, JWT)
				.build();
	}

	@POST
	@Path("/{service}/slo")
	public void singleLogout(@PathParam("service") String service) {
		System.out.println("singleLogout");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{service}/user-jwt")
	public SpidUser getUserFromJWT(@PathParam("service") String service, @NotEmpty @QueryParam("userJWT") String userJWT) {
		ServiceProvider sp = getServiceProvider(service);
		try {
			return this.spidService.validateAndGetUserInfo(userJWT, sp.getRequiredAttibutes());
		} catch (AuthenticationException e) {
			throw new UnauthorizedException();
		}
	}

	private String getContextBaseURL(HttpServletRequest request) {
		String ff = request.getHeader("x-forwarded-for");
		if (!StringUtils.isEmpty(ff) && ff.startsWith("http")) {
			return StringUtils.stripEnd(ff, "/") + contextPath;
		}

		StringBuffer buf = request.getRequestURL();
		String ret = buf.toString();

		String proto = request.getHeader("x-forwarded-proto");

		if (!StringUtils.isEmpty(proto) && !ret.startsWith(proto + "://")) {
			int i = ret.indexOf("://");
			ret = proto + ret.substring(i);
		}

		int pos = ret.indexOf("/api/");
		ret = ret.substring(0, pos);
		if (!ret.endsWith(contextPath)) {
			ret += contextPath;
		}

		return ret;
	}

	private ServiceProvider getServiceProvider(String service) {
		ServiceProvider sp = serviceProviders.get(service);
		if (sp == null) {
			throw new NotFoundException("No such service: " + service);
		}
		return sp;
	}

}
