package com.abacogroup.sso.server2.core.passwords.impl;

import static java.util.stream.Collectors.joining;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.List;

import org.bouncycastle.crypto.generators.Argon2BytesGenerator;
import org.bouncycastle.crypto.params.Argon2Parameters;

import com.abacogroup.sso.server2.core.passwords.PasswordHasher;

public class Argon2IdPasswordHasher implements PasswordHasher {

	public static final String NAME = "argon2id";

	private static SecureRandom RANDOM = new SecureRandom();
	private static int OUTPUT_LEN = 32;

	private int version;
	private int memoryKb;
	private int iterations;
	private int parallelism;
	private byte[] salt;

	public Argon2IdPasswordHasher() {
	}

	public Argon2IdPasswordHasher(int memoryKb, int iterations, int parallelism, byte[] salt) {
		this.memoryKb = memoryKb;
		this.iterations = iterations;
		this.parallelism = parallelism;
		this.salt = salt;
	}

	@Override
	public String getAlgorithmName() {
		return NAME;
	}

	@Override
	public String computeHash(String password) {
		applyDefaults();

		Argon2Parameters params = new Argon2Parameters.Builder(Argon2Parameters.ARGON2_id)
				.withVersion(version)
				.withIterations(iterations)
				.withMemoryAsKB(memoryKb)
				.withParallelism(parallelism)
				.withSalt(salt)
				.build();

		Argon2BytesGenerator generator = new Argon2BytesGenerator();
		generator.init(params);

		byte[] hash = new byte[OUTPUT_LEN];
		generator.generateBytes(password.getBytes(StandardCharsets.UTF_8), hash);

		return toString(hash);

	}

	@Override
	public void setParams(List<String> params) {
		params.forEach(this::parseParam);
	}

	@Override
	public boolean isResourceIntensive() {
		return true;
	}

	private String toString(byte[] hash) {
		Encoder encoder = Base64.getEncoder().withoutPadding();

		// $argon2id$v=19$m=15360,t=2,p=1$YpRuuQhW1dHOimAnWD5TRU6Sebitu+fIrmIrenr+YOM$hkEXhhHpu2NUcPwhV4IUQelQdf4I8V+iyFsFiC8BYEisE3oWFv96zYeNA1i/awhaDo1XHz6Pp/1r55SS/I4AIA
		List<String> params = List.of(
				"v=" + version,
				"m=" + memoryKb + ",t=" + iterations + ",p=" + parallelism,
				encoder.encodeToString(salt));

		return hashToString(params, encoder.encodeToString(hash));
	}

	/**
	 * Encodes a hashed password with the parameters used to produce it
	 *
	 * @param params
	 *            the parameters
	 * @param hash
	 *            the hashed password
	 * @return the encoded value
	 */
	private String hashToString(List<String> params, String hash) {
		final char sep = '$';

		StringBuilder buf = new StringBuilder();
		buf.append(sep).append(getAlgorithmName());
		if (params.size() > 0) {
			buf.append(sep).append(params.stream().collect(joining("$")));
		}
		buf.append(sep).append(hash);

		return buf.toString();
	}

	private void parseParam(String param) {
		if (param.indexOf('=') > -1) {
			parseKeyValuesParam(param);
		} else {
			salt = Base64.getDecoder().decode(param);
		}

	}

	private void parseKeyValuesParam(String param) {
		String[] keyValues = param.split(",");
		String[] tokens;
		for (String kv : keyValues) {
			tokens = kv.split("=");
			if (tokens.length != 2) {
				throw new IllegalStateException("Bad parameter: " + kv);
			}
			readParam(tokens[0].trim(), tokens[1].trim());
		}
	}

	private void readParam(String key, String value) {
		int num = Integer.parseInt(value);
		switch (key) {
		case "v":
			version = num;
			break;
		case "t":
			iterations = num;
			break;
		case "p":
			parallelism = num;
			break;
		case "m":
			memoryKb = num;
			break;
		default:
			throw new IllegalArgumentException("Unknown parameter: " + key + "=" + value);
		}
	}

	private void applyDefaults() {
		// OWASP advised: https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html
		// Use Argon2id with a minimum configuration of
		// 15 MiB of memory,
		// an iteration count of 2,
		// and 1 degree of parallelism.

		if (version == 0) {
			version = Argon2Parameters.ARGON2_VERSION_13; // 19
		}
		if (memoryKb == 0) {
			memoryKb = 15 * 1024;
		}
		if (iterations == 0) {
			iterations = 2;
		}
		if (parallelism == 0) {
			parallelism = 1;
		}
		if (salt == null) {
			byte[] buf = new byte[16];
			RANDOM.nextBytes(buf);
			salt = buf;
		}
	}

}
