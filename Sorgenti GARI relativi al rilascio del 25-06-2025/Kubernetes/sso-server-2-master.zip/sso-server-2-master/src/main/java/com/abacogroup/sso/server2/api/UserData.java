package com.abacogroup.sso.server2.api;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class UserData {
	private String userId;
	private String tenant;
	private String userName;
	private String description;
}
