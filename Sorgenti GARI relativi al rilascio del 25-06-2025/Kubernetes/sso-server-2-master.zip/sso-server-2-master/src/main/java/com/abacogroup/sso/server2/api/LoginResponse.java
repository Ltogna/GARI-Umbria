package com.abacogroup.sso.server2.api;

import java.util.List;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LoginResponse {
	@Schema(description = "The user ID")
	private String user_id;

	@NotNull
	@Schema(description = "True if this is a parent user")
	private Boolean isParentUser;

	@Schema(description = "The access token, this lasts 5 minutes")
	private String auth_token;

	@Schema(description = "The user name")
	private String username;

	@Schema(description = "The user tenant")
	private String tenant;

	@Schema(description = "The refresh token to renew access tokens")
	private String refresh_token;

	@Schema(description = "The user description")
	private String description;

	@Schema(description = "The user locale")
	private String locale;

	@Schema(description = "The user preferred date format")
	private String dateFormat;

	@NotNull
	@Schema(description = "A list of login warnings")
	private final List<Message> warnings;

	@NotNull
	@Schema(description = "A list of login errors")
	private final List<Message> errors;

	public enum Messages {
		ERROR_PASSWORD_MUST_BE_CHANGED("sso2.err.mustChangePassword"),
		ERROR_PASSWORD_MUST_BE_CHANGED_AT_START("sso2.err.mustChangePasswordAtStart"),
		WARNING_PASSWORD_EXPIRES_IN("sso2.warn.passwordExpiresIn");

		private String key;

		Messages(String key) {
			this.key = key;
		}

		public String key() {
			return key;
		}
	}
}
