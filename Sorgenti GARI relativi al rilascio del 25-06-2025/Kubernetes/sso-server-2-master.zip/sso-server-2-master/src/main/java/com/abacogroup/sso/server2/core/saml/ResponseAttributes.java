package com.abacogroup.sso.server2.core.saml;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ResponseAttributes {
	private AssertedAttributes attributes;
	private String inResponseTo;
}
