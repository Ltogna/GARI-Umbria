package com.abacogroup.sso.server2.db.ntt;

import java.time.OffsetDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SsoApiKeys {
	private String userId;
	private String apiKey;
	private String description;
	private OffsetDateTime validFrom;
	private OffsetDateTime validTo;
}
