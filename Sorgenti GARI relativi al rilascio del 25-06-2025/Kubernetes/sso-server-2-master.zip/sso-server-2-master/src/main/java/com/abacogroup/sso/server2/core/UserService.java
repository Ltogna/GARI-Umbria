package com.abacogroup.sso.server2.core;

import static com.abacogroup.dropwizard.auth.sso2.Constants.AUTH_AUDIENCE;
import static com.abacogroup.dropwizard.auth.sso2.Constants.ISSUER;
import static com.abacogroup.sso.server2.db.Sso1DAO.DEFAULT_TENANT;
import static java.util.stream.Collectors.toList;

import java.security.SecureRandom;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;

import javax.ws.rs.NotFoundException;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import com.abacogroup.dropwizard.auth.sso2.AuthenticationSupport;
import com.abacogroup.dropwizard.auth.sso2.JwtAuthenticator;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.dropwizard.auth.sso2.UserFunction;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.sso.client.SSO;
import com.abacogroup.sso.server2.api.ChangePasswordRequest;
import com.abacogroup.sso.server2.api.ChildUser;
import com.abacogroup.sso.server2.api.CreateUserRequestInternal;
import com.abacogroup.sso.server2.api.ExchangeSso1Request;
import com.abacogroup.sso.server2.api.ImpersonationRequest;
import com.abacogroup.sso.server2.api.LoginCredentials;
import com.abacogroup.sso.server2.api.LoginResponse;
import com.abacogroup.sso.server2.api.Message;
import com.abacogroup.sso.server2.api.PasswordResponse;
import com.abacogroup.sso.server2.api.RefreshTokensResponse;
import com.abacogroup.sso.server2.api.RefreshTokensResquest;
import com.abacogroup.sso.server2.core.model.CreateLoginTokenParams;
import com.abacogroup.sso.server2.core.passwords.PasswordHasher;
import com.abacogroup.sso.server2.core.passwords.PasswordHasherFactory;
import com.abacogroup.sso.server2.db.RefreshTokensDAO;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.abacogroup.sso.server2.db.ntt.Sso2RefreshToken;
import com.abacogroup.sso.server2.db.ntt.SsoUser;
import com.abacogroup.sso.server2.db.ntt.SsoUserLog;
import com.abacogroup.sso.server2.resources.exceptions.UnauthorizedException;
import com.abacogroup.sso.server2.resources.exceptions.UnauthorizedExceptionMaxLogFail;
import com.abacogroup.sso.server2.sdk.proxylogin.ProxyLoginCredentials;
import com.abacogroup.sso.server2.sdk.proxylogin.ProxyLoginExecutor;
import com.abacogroup.sso.server2.sdk.proxylogin.ProxyLoginResponse;
import com.abacogroup.sso.server2.sdk.proxylogin.ProxyLoginUser;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;
import com.google.common.collect.ArrayListMultimap;

import io.dropwizard.auth.AuthenticationException;

public class UserService {
	public static final String LOGIN_AUDIENCE = "sso2-login";
	public static final String PARENT_USER_AUDIENCE = "sso2-pu";
	public static final String LONG_LIVING_AUTH_TOKEN_CLAIM = "_ll";
	public static final String USER_SESSION_CLAIM = "_us";

	private static final Duration AUTH_DURATION = Duration.of(5, ChronoUnit.MINUTES);
	private static final Duration REFRESH_DURATION = Duration.of(24, ChronoUnit.HOURS);
	private static final int REFRESH_TOKEN_NUM_BYTES = 128;
	private static final Encoder BASE64_URL_ENCODER = Base64.getUrlEncoder().withoutPadding();

	private Sso1DAO ssoDAO;
	private RefreshTokensDAO refreshTokenDAO;
	private Algorithm algorithm;
	private Supplier<SSO> ssoClientSupplier;
	private JwtAuthenticator jwtAuthenticator;
	public Map<String, ProxyLoginExecutor> proxyLoginExecutorMap;

	private SecureRandom secureRandom;

	private int maxLoginfailures;
	private Duration passwordValidity;
	private Duration usernameValidity;
	private int expireWarning1;
	private boolean updateDigest;

	private PasswordHasherFactory hasherFactory;

	public UserService(Sso1DAO ssoDAO, RefreshTokensDAO refreshTokenDAO, Algorithm algorithm,
			PasswordHasherFactory hasherFactory, boolean updateDigest, Map<String, ProxyLoginExecutor> proxyLoginExecutorMap,
			Supplier<SSO> ssoClientSupplier) {

		this.ssoDAO = ssoDAO;
		this.refreshTokenDAO = refreshTokenDAO;
		this.algorithm = algorithm;
		this.ssoClientSupplier = ssoClientSupplier;
		this.jwtAuthenticator = new JwtAuthenticator(new AuthenticationSupport(algorithm), List.of(AUTH_AUDIENCE));
		this.updateDigest = updateDigest;
		this.proxyLoginExecutorMap = proxyLoginExecutorMap;
		this.hasherFactory = hasherFactory;

		secureRandom = new SecureRandom(); // use platform dependent algorithm

		Map<String, String> ssoParameters = ssoDAO.getSsoParameters();
		maxLoginfailures = Integer.parseInt(ssoParameters.computeIfAbsent("MAX_LOGIN_FAILURES", k -> "0"));
		long tmp = Long.parseLong(ssoParameters.computeIfAbsent("PASSWORD_VALIDITY", k -> "0"));
		passwordValidity = Duration.ofDays(tmp);
		tmp = Long.parseLong(ssoParameters.computeIfAbsent("USERNAME_VALIDITY", k -> "0"));
		usernameValidity = Duration.ofDays(tmp);
		expireWarning1 = Integer.parseInt(ssoParameters.computeIfAbsent("SSO_EXPIRE_WARNING_1", k -> "0"));
	}

	public String getUserIdFromFiscalCode(String fiscalCode, String fiscalCodeField, boolean isCreate) {
		List<String> fiscalCodes = this.ssoDAO.getUserIdFromFiscalCode(fiscalCode, fiscalCodeField);
		int size = fiscalCodes.size();
		switch (size) {
			case 0:
				if (isCreate) {
					return null;
				}
				throw new WebApplicationException(Response.Status.UNAUTHORIZED);
			case 1:
				return fiscalCodes.get(0);
			default:
				throw new WebApplicationException(Response.Status.CONFLICT);
		}
	}

	/**
	 * @deprecated
	 */
	@Deprecated(forRemoval = true)
	public void checkUserPresenceOrCreateIt(CreateUserRequestInternal createUserRequestInternal, String whoAmI) {
		Optional<SsoUser> user = this.ssoDAO.getSsoUser(createUserRequestInternal.getTenant(), createUserRequestInternal.getUsername().toUpperCase());

		if (user.isEmpty()) {
			ssoDAO.createUser(createUserRequestInternal, whoAmI, hasherFactory, updateDigest);
			return;
		}

		createUserRequestInternal.getRoleNames()
				.stream()
				.forEach(role -> {
					int roleId = ssoDAO.getRoleIdFromNameAndTenant(role, createUserRequestInternal.getTenant());
					int hasRoleCount = ssoDAO.hasRole(user.get().getUserid(), roleId);
					if (hasRoleCount == 0) {
						throw new WebApplicationException(Response.Status.UNAUTHORIZED);
					}
				});
	}

	public LoginResponse login(String tenantId, LoginCredentials credentials, String remoteAddr) {
		return login(tenantId, credentials, false, remoteAddr);
	}

	public LoginResponse loginFromExternalSysWithoutPassword(String userId, String remoteAddr) {
		LoginCredentials credentials = new LoginCredentials(userId, null);
		this.ssoDAO.updatePasswordLastModifiedOn(userId);
		return login(DEFAULT_TENANT, credentials, true, remoteAddr);
	}

	/**
	 * @deprecated Use external auth; this method does not support multitenantcy
	 */
	@Deprecated(forRemoval = true)
	public LoginResponse proxyLogin(String serviceId, LoginCredentials credentials, String remoteAddr) {
		ProxyLoginExecutor proxyLoginExecutor = this.proxyLoginExecutorMap.get(serviceId);

		List<Message> errors = new ArrayList<>();
		if (proxyLoginExecutor == null) {
			throw new NotFoundException("No proxy login service found for service id: " + serviceId);
		}

		ProxyLoginResponse proxyLoginResponse = proxyLoginExecutor
				.proxyLogin(new ProxyLoginCredentials(credentials.getUsername(), credentials.getPassword()));
		if (proxyLoginResponse.getStatusCode() != 200) {
			errors.add(new Message(proxyLoginResponse.getErrorMsg()));
			return LoginResponse.builder().errors(errors).build();
		}

		ProxyLoginUser user = proxyLoginResponse.getUser();
		CreateUserRequestInternal createUserRequestInternal = CreateUserRequestInternal.builder()
				.userId(user.getUsername())
				.password(user.getPassword())
				.userProperties(user.getUserProperties())
				.description(user.getDescription())
				.contexts(user.getContexts())
				.roleNames(user.getRoles())
				.alignContextToRoles(true)
				.tenant(DEFAULT_TENANT)
				.language(user.getLanguage())
				.build();

		this.checkUserPresenceOrCreateIt(createUserRequestInternal, "PROXY-LOGIN");

		proxyLoginExecutor.afterProxyLogin(proxyLoginResponse.getUser());

		return this.loginFromExternalSysWithoutPassword(credentials.getUsername(), remoteAddr);
	}

	public Optional<SsoUser> getUser(String tenantId, String userName) {
		return ssoDAO.getSsoUser(tenantId, userName.toUpperCase());
	}

	public Optional<SsoUser> getUser(String userId) {
		return ssoDAO.getSsoUser(userId);
	}

	public LoginResponse login(String tenantId, LoginCredentials credentials, boolean withoutPassword, String remoteAddr) {
		SsoUser user = ssoDAO.getSsoUser(tenantId, credentials.getUsername().toUpperCase()).orElseThrow(UnauthorizedException::new);
		SsoUserLog userLog = ssoDAO.getUserLog(user.getUserid());

		checkUserExpired(userLog);
		checkNotLocked(user);
		checkMaxLoginFailures(userLog);
		if (!withoutPassword) {
			checkPassword(user, credentials);
		}

		List<Message> errors = new ArrayList<>();
		List<Message> warnings = new ArrayList<>();
		if (!withoutPassword) {
			if (user.getParent_userid() != null) {
				throw new UnauthorizedException();
			}
			checkPasswordValidity(user, errors, warnings);
		}

		if (errors.size() > 0) {
			return LoginResponse.builder().warnings(warnings).errors(errors).build();
		}

		return loginSuccess(user, warnings, true, remoteAddr);
	}

	public LoginResponse impersonate(User user, ImpersonationRequest request, boolean issueTokens, String remoteAddr) {
		SsoUser child = ssoDAO.getSsoUser(request.getUserid().toUpperCase())
				.orElseThrow(UnauthorizedException::new);

		if (!user.getUserId().equals(child.getParent_userid())) {
			throw new UnauthorizedException();
		}

		if (!user.getTenant().equals(child.getTenant_id())) {
			throw new IllegalStateException("Parent and child have different tenant");
		}

		checkNotLocked(child);
		return loginSuccess(child, new ArrayList<>(0), issueTokens, remoteAddr);
	}

	private LoginResponse loginSuccess(SsoUser user, List<Message> warnings, boolean issueTokens, String remoteAddr) {
		OffsetDateTime now = OffsetDateTime.now();

		ssoDAO.resetUserFailedLogin(now, user.getUserid());
		if (remoteAddr != null) {
			ssoDAO.insertAccessLog(now, 1, remoteAddr, "", user.getUserid());
		}

		SsoUser correctUser = user;
		// If this user is a parent, update the password on its children and if has only one child, continue as that child.
		if (user.getIs_parent() != null && user.getIs_parent() != 0) {
			final String userid = user.getUserid();
			correctUser = ssoDAO.inTransaction(dao -> {
				AtomicInteger childrenCount = new AtomicInteger();
				AtomicReference<SsoUser> firstChildren = new AtomicReference<>();
				ssoDAO.consumeChildren(userid, null, child -> {
					ssoDAO.updatePasswordLastModifiedOn(child.getUserid());
					childrenCount.getAndIncrement();
					if (childrenCount.get() == 1) {
						firstChildren.set(child);
					}
				});
				if (childrenCount.get() == 1 && firstChildren.get() != null) {
					return firstChildren.get();
				}

				return user;
			});
		}

		String refreshToken = issueTokens ? createRefreshToken() : null;
		String audience = getAudienceFromuser(correctUser);
		String authToken = issueTokens ? createAuthToken(correctUser.getUserid(), correctUser.getUsername(), correctUser.getTenant_id(), audience, now) : null;
		final String userid = correctUser.getUserid();

		if (issueTokens) {
			// Register the token into the db
			refreshTokenDAO.useTransaction(tx -> refreshTokenDAO.insertToken(
					Sso2RefreshToken.builder()
							.expires_at(now.plus(REFRESH_DURATION))
							.issued_at(now)
							.refresh_token(refreshToken)
							.userid(userid)
							.build()));
		}

		return LoginResponse.builder()
				.auth_token(authToken)
				.dateFormat(correctUser.getDate_format())
				.description(user.getDescr())
				.errors(new ArrayList<>(0))
				.isParentUser(correctUser.getIs_parent() != null && correctUser.getIs_parent() != 0)
				.locale(correctUser.getUsr_locale())
				.refresh_token(refreshToken)
				.user_id(correctUser.getUserid())
				.warnings(warnings)
				.username(correctUser.getUsername())
				.tenant(correctUser.getTenant_id()).build();
	}

	public PasswordResponse changePassword(String userid, ChangePasswordRequest request, Boolean isAuthenticated) {
		PasswordResponse response = validateChangePassword(userid, request, isAuthenticated);

		if (response.isOk()) {
			String encodedPassword = setNewPassword(userid, request);
			ssoDAO.resetUserFailedLogin(OffsetDateTime.now(), userid);
			if (updateDigest) {
				ssoDAO.callUpdateDigest(encodedPassword, userid);
			}
		}
		return response;
	}

	private String setNewPassword(String userid, ChangePasswordRequest request) {
		ssoDAO.updateOldPasswords(userid); // TODO: Limit to max number of passwords to remember

		String encodedNewPass = hasherFactory.getDefault().computeHash(request.getNewPassword());
		ssoDAO.setNewPassword(encodedNewPass, OffsetDateTime.now(), userid);

		return encodedNewPass;
	}

	private PasswordResponse validateChangePassword(String userid, ChangePasswordRequest request, Boolean isAuthenticated) {
		// checkUserExpired(userid); TOM: you can change your password if the password is expired
		SsoUserLog userLog = ssoDAO.getUserLog(userid);
		checkMaxLoginFailures(userLog);

		PasswordResponse response = PasswordResponse.builder()
				.ok(Boolean.FALSE)
				.errors(new ArrayList<>())
				.build();

		String encodedDbPass = ssoDAO.getSsoUser(userid)
				.orElseThrow(UnauthorizedException::new)
				.getPassword();

		PasswordHasher hasher = hasherFactory.getFromEncodedPassword(encodedDbPass);
		String encodedOldPass = hasher.computeHash(request.getOldPassword());

		if (!encodedOldPass.equals(encodedDbPass)) {
			ssoDAO.incrementWrongPasswordCount(userid);
			if (!isAuthenticated) {
				throw new UnauthorizedException();
			}
			response.getErrors().add(new Message(PasswordResponse.Messages.ERROR_WRONG_OLD_PASSWORD.key()));
		}

		Map<String, String> ssoParametersMap = ssoDAO.getSsoParameters();
		checkPassword(request.getNewPassword(), ssoParametersMap, response);

		// TODO: Leggere parametro da ssoparametersMap e confrontare con le enne vecchie passwords da sso_old_passwords
		isNewPasswordDifferentFromOldPassword(encodedDbPass, hasher.computeHash(request.getNewPassword()), response);

		if (response.getErrors().isEmpty()) {
			response.setOk(Boolean.TRUE);
		}

		return response;
	}

	private void isNewPasswordDifferentFromOldPassword(String md5DbPass, String md5NewPass, PasswordResponse response) {
		if (md5DbPass.equals(md5NewPass)) {
			response.getErrors()
					.add(new Message(PasswordResponse.Messages.ERROR_OLD_PASSWORD_MUST_BE_DIFFERENT_FROM_NEW_ONE.key()));
		}
	}

	public PasswordResponse isPasswordOk(String password) {
		PasswordResponse response = PasswordResponse.builder()
				.ok(Boolean.FALSE)
				.errors(new ArrayList<>())
				.build();

		this.checkPassword(password, ssoDAO.getSsoParameters(), response);

		if (response.getErrors().isEmpty()) {
			response.setOk(true);
		}
		return response;
	}

	private void checkPassword(String newPassword, Map<String, String> ssoParametersMap, PasswordResponse response) {
		PasswordChecker checker = new PasswordChecker(ssoParametersMap);
		List<Message> messages = checker.checkPassword(newPassword);
		response.getErrors().addAll(messages);
	}

	private void checkUserExpired(SsoUserLog userLog) {
		OffsetDateTime lastLoginDate = userLog.getLast_login();
		if (this.usernameValidity.toDays() > 0
				&& lastLoginDate.truncatedTo(ChronoUnit.DAYS).plus(this.usernameValidity).isBefore(OffsetDateTime.now())) {
			throw new UnauthorizedException();
		}
	}

	public RefreshTokensResponse refresh(String tenantId, RefreshTokensResquest request) {
		Sso2RefreshToken refreshToken = refreshTokenDAO.getToken(tenantId, request.getRefresh_token())
				.orElseThrow(UnauthorizedException::new);

		OffsetDateTime now = OffsetDateTime.now();
		if (refreshToken.getExpires_at().isBefore(now)) {
			throw new UnauthorizedException();
		}

		SsoUser user = ssoDAO.getSsoUser(refreshToken.getUserid())
				.orElseThrow(() -> new NotFoundException("user not found"));

		String token = refreshToken.getRefresh_token();
		String username = user.getUsername();
		String audience = getAudienceFromuser(user);
		String authToken = createAuthToken(refreshToken.getUserid(), username, tenantId, audience, now);

		if (now.plus(REFRESH_DURATION.dividedBy(2)).isAfter(refreshToken.getExpires_at())) {
			// Create a new refresh token if we are halfway it's deadline
			final String oldToken = token;
			final String newToken = createRefreshToken();
			token = newToken;

			// Register the token into the db
			refreshTokenDAO.useTransaction(tx -> {
				refreshTokenDAO.insertToken(Sso2RefreshToken.builder()
						.expires_at(now.plus(REFRESH_DURATION))
						.issued_at(now)
						.refresh_token(newToken)
						.userid(refreshToken.getUserid())
						.build());

				refreshTokenDAO.delete(oldToken);
			});
		}

		return new RefreshTokensResponse(authToken, token);
	}

	public LoginResponse exchangeSsoToken(ExchangeSso1Request request) throws AuthenticationException {
		String token = request.getSsoToken();
		String userid;
		String tenant = DEFAULT_TENANT;
		if (token.startsWith("j2_")) {
			String realToken = token.substring(3);
			userid = this.validateSSO2TokenUsedAsJ2(realToken).getName();
			Claim decodedTenant = JWT.decode(realToken).getClaim("tenant");
			tenant = decodedTenant.isNull() ? DEFAULT_TENANT : decodedTenant.asString();
		} else {
			if (request.getLoginContext() == null || request.getLoginContext().isBlank()) {
				throw new WebApplicationException("Login context is required to exchange a sso1 token", Response.Status.BAD_REQUEST);
			}
			SSO sso = ssoClientSupplier.get();
			if (!sso.checkLogin(request.getLoginContext(), request.getSsoToken())) {
				throw new UnauthorizedException();
			}
			userid = sso.whoAmI();
		}

		SsoUser user = ssoDAO.getSsoUser(tenant, userid).orElseThrow(UnauthorizedException::new);

		return loginSuccess(user, new ArrayList<>(0), true, null);
	}

	public List<UserFunction> getUserFunctions(String tenantId, String userName) {
		return ssoDAO.getUserFunctions(tenantId, userName.toUpperCase()).stream()
				.map(db -> new UserFunction(db.getContextId(), db.getName()))
				.collect(toList());
	}

	public List<String> getUserContexts(String tenantId, String userName) {
		return ssoDAO.getUserContexts(tenantId, userName.toUpperCase());
	}

	public Map<String, String> getUserProperties(String tenantId, String userName) {
		return ssoDAO.getUserProperties(tenantId, userName.toUpperCase());
	}

	public List<String> getUserRoles(String tenantId, String userName) {
		return ssoDAO.getUserRoleCodes(tenantId, userName.toUpperCase());
	}

	public Map<String, String> getUsersDescription(String tenantId, List<String> userNames) {
		Map<String, String> ret = new HashMap<>();

		Set<String> uniqueUserNames = new TreeSet<>(userNames);

		int skip = 0;
		List<String> chunk;
		List<SsoUser> users;
		while (true) {
			chunk = uniqueUserNames.stream()
					.skip(skip)
					.limit(900)
					.map(String::toUpperCase)
					.collect(toList());

			if (chunk.isEmpty()) {
				break;
			}
			skip += chunk.size();

			users = ssoDAO.findSsoUsers(tenantId, CriteriaBuilder.string("username").in(chunk));
			users.forEach(user -> ret.put(user.getUsername(), user.getDescr()));
		}

		return ret;
	}

	public InfiniteListResults<ChildUser> findChildren(String userId, String filter, Boolean includeContexts, String nextKey) {
		Criteria criteria = CriteriaBuilder
				.string("descr")
				.contains(filter == null ? "" : filter);

		InfiniteListResults<SsoUser> children = ssoDAO.infinite(() -> ssoDAO.getChildren(userId, criteria), nextKey, 25);

		ArrayListMultimap<String, String> contextsForUsers = ArrayListMultimap.create();

		if (includeContexts && children.getRecords().size() > 0) {
			Criteria userCriteria = CriteriaBuilder.string("userid")
					.in(children.map(SsoUser::getUserid).map(String::toUpperCase).getRecords());
			contextsForUsers = ssoDAO.getContextsForUsers(userCriteria);
		}

		ArrayListMultimap<String, String> finalContextsForUsers = contextsForUsers;
		return children.map(ssoUser -> ChildUser.builder()
				.descr(ssoUser.getDescr())
				.tenant(ssoUser.getTenant_id())
				.userid(ssoUser.getUserid())
				.username(ssoUser.getUsername())
				.contexts(finalContextsForUsers.get(ssoUser.getUserid()))
				.build());
	}

	public String createAuthToken(String userId, OffsetDateTime now) {
		return createAuthToken(userId, userId, DEFAULT_TENANT, AUTH_AUDIENCE, now, now.plus(AUTH_DURATION));
	}

	public String createAuthToken(String userId, String username, String tenant, String audience, OffsetDateTime now) {
		return createAuthToken(userId, username, tenant, audience, now, now.plus(AUTH_DURATION));
	}

	public String createAuthToken(String userId, String username, String tenant, String audience, OffsetDateTime now, OffsetDateTime end) {
		return JWT.create()
				.withIssuer(ISSUER)
				.withSubject(userId.toUpperCase())
				.withIssuedAt(new Date(now.toEpochSecond() * 1000))
				.withExpiresAt(new Date(end.toEpochSecond() * 1000))
				.withAudience(audience)
				.withClaim("tenant", tenant)
				.withClaim("username", username)
				.withClaim(LONG_LIVING_AUTH_TOKEN_CLAIM, end.isAfter(now.plus(AUTH_DURATION)))
				.sign(algorithm);
	}

	public String createLoginToken(CreateLoginTokenParams params) {
		return JWT.create()
				.withIssuer(ISSUER)
				.withSubject(params.getUserId().toUpperCase())
				.withIssuedAt(new Date(params.getStart().toEpochSecond() * 1000))
				.withExpiresAt(new Date(params.getEnd().toEpochSecond() * 1000))
				.withAudience(LOGIN_AUDIENCE)
				.withClaim("tenant", params.getTenant())
				.withClaim("username", params.getUsername())
				.withClaim(USER_SESSION_CLAIM, params.getSession())
				.sign(algorithm);
	}

	private User validateSSO2TokenUsedAsJ2(String token) throws AuthenticationException {
		return this.jwtAuthenticator.authenticate(token)
				.orElseThrow(() -> new AuthenticationException("Invalid token"));
	}

	private void checkPasswordValidity(SsoUser user, List<Message> errors, List<Message> warnings) {
		boolean hasNoPasswordRule = this.ssoDAO.noPasswordRules(user.getUserid()) > 0;
		if (hasNoPasswordRule) {
			return;
		}

		OffsetDateTime now = OffsetDateTime.now();
		OffsetDateTime createdOn = user.getCreated_on();
		OffsetDateTime modifiedOn = user.getPassword_last_modified_on();

		if (createdOn.isEqual(modifiedOn)) {
			errors.add(new Message(LoginResponse.Messages.ERROR_PASSWORD_MUST_BE_CHANGED_AT_START.key()));
			return;
		}

		if (this.passwordValidity.toDays() > 0
				&& modifiedOn.truncatedTo(ChronoUnit.DAYS).plus(passwordValidity).isBefore(now)) {
			errors.add(new Message(LoginResponse.Messages.ERROR_PASSWORD_MUST_BE_CHANGED.key()));
			return;
		}

		if (this.passwordValidity.toDays() > 0 && this.expireWarning1 > 0) {
			long daysToExpire = Duration.between(now.truncatedTo(ChronoUnit.DAYS),
					modifiedOn.truncatedTo(ChronoUnit.DAYS).plus(this.passwordValidity)).toDays();
			if (daysToExpire <= expireWarning1) {
				warnings.add(new Message(LoginResponse.Messages.WARNING_PASSWORD_EXPIRES_IN.key(),
						new ArrayList<>(Collections.singletonList(String.valueOf(daysToExpire)))));
			}
		}
	}

	private String createRefreshToken() {
		byte[] bytes = new byte[REFRESH_TOKEN_NUM_BYTES];
		secureRandom.nextBytes(bytes);
		return BASE64_URL_ENCODER.encodeToString(bytes);
	}

	private void checkMaxLoginFailures(SsoUserLog userLog) {
		if (maxLoginfailures <= 0) {
			return;
		}

		Integer failed = userLog.getFailed_logins();
		if (failed == null || failed >= maxLoginfailures) {
			throw new UnauthorizedExceptionMaxLogFail();
		}
	}

	private void checkNotLocked(SsoUser user) {
		if (user.getIs_locked() != 'N') {
			throw new UnauthorizedException();
		}
	}

	private void checkPassword(SsoUser user, LoginCredentials credentials) {
		PasswordHasher hasher = hasherFactory.getFromEncodedPassword(user.getPassword());

		String encoded = hasher.computeHash(credentials.getPassword());
		if (!encoded.equals(user.getPassword())) {
			ssoDAO.incrementWrongPasswordCount(user.getUserid());
			throw new UnauthorizedException();
		}
	}

	private String getAudienceFromuser(SsoUser user) {
		boolean flParent = user.getIs_parent() != null && user.getIs_parent() == 0;
		return flParent ? AUTH_AUDIENCE : PARENT_USER_AUDIENCE;
	}

}
