package com.abacogroup.sso.server2.core.saml;

public class SPIDUserAnomalyException extends RuntimeException {
	private static final long serialVersionUID = -180213505737168678L;

	public SPIDUserAnomalyException(String message) {
		super(message);
	}
}
