package com.abacogroup.sso.server2.resources;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.dropwizard.auth.sso2.UserFunction;
import com.abacogroup.sso.server2.api.LoginCredentials;
import com.abacogroup.sso.server2.api.LoginResponse;
import com.abacogroup.sso.server2.api.RefreshTokensResponse;
import com.abacogroup.sso.server2.api.RefreshTokensResquest;
import com.abacogroup.sso.server2.api.WhoAmIResponse;
import com.abacogroup.sso.server2.core.UserService;
import com.abacogroup.sso.server2.db.ntt.SsoUser;
import com.abacogroup.sso.server2.resources.exceptions.UnauthorizedException;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;

@Timed
@Path("{tenant}/public/v1")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Tenant aware APIs", description = "API that works on tenants")
public class TenantTokensResources implements TenantCheckable {

	private UserService userService;

	public TenantTokensResources(UserService userService) {
		this.userService = userService;
	}

	@POST
	@Path("/login")
	@Operation(summary = "Login", description = "Logs a user into the system")
	public LoginResponse login(@PathParam("tenant") String tenantId, @NotNull @Valid LoginCredentials credentials, @Context HttpServletRequest request) {
		return userService.login(tenantId, credentials, request.getRemoteAddr());
	}

	@POST
	@Path("/logout")
	@Operation(summary = "Logout", description = "NO OP - for backwards compatibility", deprecated = true)
	public void logout(@Parameter(hidden = true) @Auth User user, @PathParam("tenant") String tenantId) {
		// NO OP
	}

	@POST
	@Path("/refresh")
	@Operation(summary = "Refresh an access token", description = "Get a new access token based on a refresh token")
	public RefreshTokensResponse refresh(@PathParam("tenant") String tenantId, @NotNull @Valid RefreshTokensResquest request) {
		return userService.refresh(tenantId, request);
	}

	@GET
	@Path("/who-am-i")
	@Operation(summary = "Get the current user details", description = "Get the current logged in user details")
	public WhoAmIResponse whoAmI(@Parameter(hidden = true) @Auth User user, @PathParam("tenant") String tenantId) {
		checkTenant(tenantId, user);
		SsoUser ssoUser = this.userService.getUser(tenantId, user.getName()).orElseThrow(UnauthorizedException::new);
		return new WhoAmIResponse(ssoUser);
	}

	@GET
	@Path("/user-functions")
	@Operation(summary = "Get the current user permissions")
	public @NotNull List<UserFunction> getUserFunctions(@PathParam("tenant") String tenantId,
			@Parameter(hidden = true) @Auth User user) {
		checkTenant(tenantId, user);
		return userService.getUserFunctions(tenantId, user.getName());
	}

	@GET
	@Path("/user-contexts")
	@Operation(summary = "Get the current user contexts (modules)")
	public @NotNull List<String> getUserContexts(@PathParam("tenant") String tenantId,
			@Parameter(hidden = true) @Auth User user) {
		checkTenant(tenantId, user);
		return userService.getUserContexts(tenantId, user.getName());
	}

	@GET
	@Path("/user-properties")
	@Operation(summary = "Get the current user properties")
	public @NotNull Map<String, String> getUserProperties(@PathParam("tenant") String tenantId,
			@Parameter(hidden = true) @Auth User user) {
		checkTenant(tenantId, user);
		return userService.getUserProperties(tenantId, user.getName());
	}

	@GET
	@Path("/user-roles")
	@Operation(summary = "Get the current user roles")
	public @NotNull List<String> getUserRoles(@PathParam("tenant") String tenantId,
			@Parameter(hidden = true) @Auth User user) {
		checkTenant(tenantId, user);
		return userService.getUserRoles(tenantId, user.getName());
	}

}
