package com.abacogroup.sso.server2.core.saml;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AuthnRequestObj {
	private String id;
	private String request;
}
