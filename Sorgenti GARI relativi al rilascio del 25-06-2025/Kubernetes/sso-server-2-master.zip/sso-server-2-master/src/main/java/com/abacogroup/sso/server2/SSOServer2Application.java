package com.abacogroup.sso.server2;

import static com.abacogroup.dropwizard.auth.sso2.Constants.AUTH_AUDIENCE;
import static com.abacogroup.sso.server2.core.UserService.PARENT_USER_AUDIENCE;

import java.io.IOException;
import java.sql.DatabaseMetaData;
import java.time.OffsetDateTime;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ServiceLoader;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.servlet.DispatcherType;
import javax.servlet.FilterRegistration.Dynamic;
import javax.ws.rs.core.MediaType;

import com.abacogroup.sso.server2.core.bundle.*;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.glassfish.jersey.server.filter.RolesAllowedDynamicFeature;
import org.jdbi.v3.core.Jdbi;
import org.opensaml.core.config.InitializationException;
import org.opensaml.core.config.InitializationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.initializer.BundleInitServiceBuilder;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.listener.ListenerBuilder;
import com.abacogroup.bundles.listener.configdata.builder.ConfigDataConsumerBuilder;
import com.abacogroup.bundles.listener.tenant.builder.NewTenantEventConsumerBuilder;
import com.abacogroup.dropwizard.auth.sso2.AuthenticationSupport;
import com.abacogroup.dropwizard.auth.sso2.JwtAuthenticationFilter;
import com.abacogroup.dropwizard.auth.sso2.JwtAuthenticator;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.OraJdbiPlugin;
import com.abacogroup.jdbi.OraJdbiPlugin.OraJdbiPluginParams;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.jdbi.config.AbacoJdbiConfig;
import com.abacogroup.sso.client.SSO;
import com.abacogroup.sso.server2.cli.DeleteOldPubKeysCommand;
import com.abacogroup.sso.server2.core.ApiKeyService;
import com.abacogroup.sso.server2.core.KeysService;
import com.abacogroup.sso.server2.core.RabbitMqConfig;
import com.abacogroup.sso.server2.core.SpidService;
import com.abacogroup.sso.server2.core.Sso1CompatibilityService;
import com.abacogroup.sso.server2.core.Sso2InternalAuthorizer;
import com.abacogroup.sso.server2.core.TotpService;
import com.abacogroup.sso.server2.core.UserManagementService;
import com.abacogroup.sso.server2.core.UserService;
import com.abacogroup.sso.server2.core.passwords.PasswordHasherFactory;
import com.abacogroup.sso.server2.core.passwords.impl.Argon2IdPasswordHasher;
import com.abacogroup.sso.server2.core.saml.ServiceProvider;
import com.abacogroup.sso.server2.core.saml.config.SamlServiceProviderConfig;
import com.abacogroup.sso.server2.db.ConfigDAO;
import com.abacogroup.sso.server2.db.RefreshTokensDAO;
import com.abacogroup.sso.server2.db.Sso1DAO;
import com.abacogroup.sso.server2.resources.*;
import com.abacogroup.sso.server2.sdk.proxylogin.ProxyLoginExecutor;
import com.abacogroup.sso.server2.sdk.proxylogin.ProxyLoginExecutorConfig;
import com.abacogroup.sso.server2.sdk.proxylogin.ProxyLoginExecutorFactory;
import com.abacogroup.sso.server2.views.saml.ErrorView;
import com.abacogroup.tracing.dropwizard.AbacoApplication;
import com.abacogroup.tracing.jaxrs.server.MDCFilter;
import com.auth0.jwt.algorithms.Algorithm;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import io.dropwizard.auth.AuthDynamicFeature;
import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.jdbi3.JdbiFactory;
import io.dropwizard.jdbi3.bundles.JdbiExceptionsBundle;
import io.dropwizard.jersey.errors.ErrorEntityWriter;
import io.dropwizard.jersey.errors.ErrorMessage;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import io.dropwizard.jersey.validation.ValidationErrorMessage;
import io.dropwizard.lifecycle.Managed;
import io.dropwizard.migrations.MigrationsBundle;
import io.dropwizard.views.common.View;
import io.dropwizard.views.common.ViewBundle;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import io.swagger.v3.oas.integration.ClasspathOpenApiConfigurationLoader;
import io.swagger.v3.oas.integration.api.OpenAPIConfiguration;
import net.shibboleth.utilities.java.support.component.ComponentInitializationException;
import net.shibboleth.utilities.java.support.xml.BasicParserPool;
import oracle.jdbc.OracleConnection;

public class SSOServer2Application extends AbacoApplication<SSOServer2Configuration> {

	private static final Logger log = LoggerFactory.getLogger(SSOServer2Application.class);

	public static void main(final String[] args) {
		try {
			new SSOServer2Application().run(args);
		} catch (Exception e) {
			log.error("Error in main", e);
			System.exit(1);
		}
	}

	@Override
	public String getName() {
		return "Abaco SSO server 2";
	}

	@Override
	public void initialize(final Bootstrap<SSOServer2Configuration> bootstrap) {
		bootstrap.addBundle(new JdbiExceptionsBundle());
		bootstrap.addBundle(new ViewBundle<SSOServer2Configuration>());
		bootstrap.addBundle(new MigrationsBundle<>() {
			@Override
			public DataSourceFactory getDataSourceFactory(SSOServer2Configuration configuration) {
				return configuration.getDataSourceFactory();
			}
		});
		bootstrap.addBundle(new MigrationsBundle<>() {
			@Override
			public DataSourceFactory getDataSourceFactory(SSOServer2Configuration configuration) {
				return configuration.getDataSourceFactory();
			}

			@Override
			public String name() {
				return "db-legacy";
			}

			@Override
			public String getMigrationsFileName() {
				return "migrations-legacy.xml";
			}
		});

		bootstrap.addCommand(new DeleteOldPubKeysCommand());

		SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
				new EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);
	}

	@Override
	public void doRun(final SSOServer2Configuration config, final Environment environment) throws IOException {
		ObjectMapper objectMapper = environment.getObjectMapper();
		configure(objectMapper);

		final JdbiFactory factory = new JdbiFactory();
		final Jdbi jdbi = factory.build(environment, config.getDataSourceFactory(), "mainDB");

		var isPostgres = jdbi.withHandle(h -> {
			String db = h.queryMetadata(DatabaseMetaData::getDatabaseProductName);
			log.info("Database connection is '{}'", db);
			return db.toLowerCase().contains("postgresql");
		});

		if (isPostgres) {
			jdbi.installPlugin(new PgJdbiPlugin());
		} else {
			var params = new OraJdbiPluginParams(cnn -> cnn.unwrap(OracleConnection.class), true);
			jdbi.installPlugin(new OraJdbiPlugin(params));
		}

		jdbi.configure(AbacoJdbiConfig.class, cfg -> cfg.setTablesPrefix("sso"));

		// DAOs
		RefreshTokensDAO refreshTokensDAO = jdbi.onDemand(RefreshTokensDAO.class);
		Sso1DAO ssoUsersDAO = jdbi.onDemand(Sso1DAO.class);
		ConfigDAO configDAO = jdbi.onDemand(ConfigDAO.class);

		final KeysService keysService = new KeysService(objectMapper, config.getPublicKeysDir(),
				bytes(config.getPublicKeyEncryptSecret()));
		Algorithm algorithm = initAuth(environment, keysService, ssoUsersDAO);

		Map<String, ProxyLoginExecutor> proxyLoginExecutorMap = loadProxyLoginExecutor(config.getProxyLoginExecutors());

		// Services
		PasswordHasherFactory hasherFactory = createPasswordHasherFactory(environment);

		UserService userService = new UserService(ssoUsersDAO, refreshTokensDAO, algorithm,
				hasherFactory,
				config.isUpdateDigest(), proxyLoginExecutorMap,
				() -> new SSO(config.getSso1Url()));
		SpidService spidService = new SpidService(ssoUsersDAO, algorithm, hasherFactory, config.isUpdateDigest());
		UserManagementService userManagementService = new UserManagementService(hasherFactory.getDefault(), ssoUsersDAO,
				config.isUpdateDigest(), userService,
				"DELETED_USER");
		Sso1CompatibilityService sso1CompatibilityService = new Sso1CompatibilityService(config.getTasksAuthSecret(),
				ssoUsersDAO, userService, algorithm);

		TotpService totpService = new TotpService(config.getTotpIssuer(), config.getTotpPeriod());

		ApiKeyService apiKeyService = new ApiKeyService(ssoUsersDAO, userService);

		Connection rabbitmqConnection = createRabbitmqConnection(config.getRabbitmqConfig());
		createBundleInfrastructure(rabbitmqConnection, jdbi, configDAO, ssoUsersDAO, apiKeyService, hasherFactory, config.getBundlesDir(), objectMapper);

		// Resources...
		// Internal resources...
		environment.jersey().register(new InternalResources(config.getTasksAuthSecret(), userService, totpService));

		environment.jersey().register(new Sso1CompatibilityResource(
				new Sso1CompatibilityService(config.getTasksAuthSecret(), ssoUsersDAO, userService, algorithm)));

		environment.jersey().register(new ApiKeyResources(apiKeyService));
		environment.jersey().register(new PasswordResources(userService));

		// Tenant Token Resources
		environment.jersey().register(new TokensResources(userService, keysService));
		environment.jersey().register(new TenantTokensResources(userService));

		// User queries resources
		environment.jersey().register(new UserQueryResources(userService));

		// Impersonation resources
		environment.jersey().register(new ImpersonationResources(userService));

		environment.jersey().register(new OtpResources(userService, totpService));

		// User management resoursec
		environment.jersey().register(new UserManagementResources(userManagementService, userService));

		environment.jersey().register(sso1CompatibilityService);

		environment.jersey().register(new ErrorEntityWriter<ErrorMessage, View>(MediaType.TEXT_HTML_TYPE, View.class) {
			@Override
			protected View getRepresentation(ErrorMessage errorMessage) {
				return new ErrorView(errorMessage);
			}
		});
		environment.jersey()
				.register(new ErrorEntityWriter<ValidationErrorMessage, View>(MediaType.TEXT_HTML_TYPE, View.class) {
					@Override
					protected View getRepresentation(ValidationErrorMessage message) {
						return new ErrorView(message);
					}
				});

		environment.jersey().register(new MDCFilter());

		addSamlServiceProvidersResources(environment, config, userService, spidService, algorithm);

		setupCORS(config, environment);
		initOpenApi(environment.jersey());

		// Cleanup
		createCleanupExecutor(environment, ssoUsersDAO, refreshTokensDAO, keysService);
	}

	private void configure(ObjectMapper objectMapper) {
		objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		objectMapper.disable(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE);
	}

	private Algorithm initAuth(Environment environment, KeysService keysService, Sso1DAO sso1DAO) {
		Algorithm algorithm = Algorithm.RSA256(keysService);

		environment.jersey().register(new AuthDynamicFeature(
				JwtAuthenticationFilter.builder()
						.setAuthenticator(new JwtAuthenticator(new AuthenticationSupport(algorithm),
								List.of(AUTH_AUDIENCE, PARENT_USER_AUDIENCE)))
						.setRealm("Abaco SSO2")
						.setAuthorizer(new Sso2InternalAuthorizer(sso1DAO))
						.buildAuthFilter()));
		environment.jersey().register(new AuthValueFactoryProvider.Binder<>(User.class));
		environment.jersey().register(RolesAllowedDynamicFeature.class);

		return algorithm;
	}

	private PasswordHasherFactory createPasswordHasherFactory(Environment environment) {
		String pwdDefaultAlgo = System.getenv("PWD_HASH_ALGO");
		if (pwdDefaultAlgo == null || pwdDefaultAlgo.isBlank()) {
			pwdDefaultAlgo = Argon2IdPasswordHasher.NAME;
		}

		PasswordHasherFactory hasherFactory = new PasswordHasherFactory(pwdDefaultAlgo);

		environment.lifecycle().manage(new Managed() {
			@Override
			public void stop() throws Exception {
				hasherFactory.close();
			}
		});

		return hasherFactory;
	}

	protected Connection createRabbitmqConnection(RabbitMqConfig rabbitmqConfig) {
		if (rabbitmqConfig == null) {
			return null;
		}

		if (StringUtils.isBlank(rabbitmqConfig.getHost()) || rabbitmqConfig.getHost().indexOf("${") > -1) {
			return null;
		}

		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(rabbitmqConfig.getHost());

		if (!StringUtils.isBlank(rabbitmqConfig.getUser())) {
			factory.setUsername(rabbitmqConfig.getUser());
		}
		if (!StringUtils.isBlank(rabbitmqConfig.getPassword())) {
			factory.setPassword(rabbitmqConfig.getPassword());
		}
		if (!StringUtils.isBlank(rabbitmqConfig.getVirtualhost())) {
			factory.setVirtualHost(rabbitmqConfig.getVirtualhost());
		}
		if (rabbitmqConfig.getPort() != null) {
			factory.setPort(rabbitmqConfig.getPort());
		}
		factory.setAutomaticRecoveryEnabled(true);

		try {
			return factory.newConnection();
		} catch (IOException | TimeoutException e) {
			throw new IllegalStateException("Cannot connect to rabbit mq", e);
		}
	}

	private void createBundleInfrastructure(Connection rabbitmqConnection, Jdbi jdbi, ConfigDAO configDAO, Sso1DAO ssoDAO, ApiKeyService apiKeyService,
			PasswordHasherFactory hasherFactory, String bundlesDir, ObjectMapper objectMapper) {
		if (rabbitmqConnection == null) {
			log.info("NOT CONNECTED TO RABBITMQ; bundles infrastructure is disabled");
			return;
		}

		final String serviceName = "sso-server-2";

		try {
			ListenerBuilder.newBuilder(rabbitmqConnection)
					.withConfigDataConsumer(ConfigDataConsumerBuilder.newBuilder(jdbi, rabbitmqConnection)
							.route(serviceName)
							.processors(
									new Sso2FunctionsConfigProcessor(configDAO, objectMapper),
									new Sso2LanguageMessageProcessor(configDAO, ssoDAO, objectMapper),
									new Sso2UsersConfigProcessor(configDAO, ssoDAO, apiKeyService, hasherFactory, objectMapper),
									new Sso2ParametersConfigProcessor(configDAO, ssoDAO, objectMapper))
							.build())
					.withNewTenantEventConsumer(NewTenantEventConsumerBuilder.newBuilder(jdbi)
							.route(serviceName)
							.processors(new Sso2TenantMessageProcessor(configDAO, ssoDAO))
							.build())
					.buildListener()
					.start();

			log.info("Bundles to pubish dir is {}", bundlesDir);
			if (bundlesDir != null && !bundlesDir.isBlank()) {
				BundleInitServiceBuilder
						.producer(new BundleInitServiceProducer(rabbitmqConnection))
						.configLocation(bundlesDir)
						.build()
						.start();
			}
		} catch (Exception e) {
			throw new IllegalStateException("Error starting rabbitmq listener", e);
		}

	}

	private byte[] bytes(String str) {
		if (str == null) {
			return null;
		}
		return str.getBytes();
	}

	private void addSamlServiceProvidersResources(Environment environment, SSOServer2Configuration config, UserService userService, SpidService spidService,
			Algorithm algorithm) {
		List<SamlServiceProviderConfig> spConfigs = config.getSamlServiceProviders();
		if (spConfigs == null || spConfigs.size() == 0) {
			return;
		}

		BasicParserPool parserPool;
		try {
			parserPool = new BasicParserPool();
			parserPool.initialize();

			InitializationService.initialize();
		} catch (InitializationException | ComponentInitializationException e) {
			throw new RuntimeException(e.getMessage(), e);
		}

		Map<String, ServiceProvider> serviceProviders = new HashMap<>();
		for (SamlServiceProviderConfig c : spConfigs) {
			serviceProviders.put(c.getId(), new ServiceProvider(parserPool, c, algorithm));
		}

		String contextPath = environment.getApplicationContext().getContextPath();
		environment.jersey()
				.register(new SamlServiceProviderResources(contextPath, userService, spidService, serviceProviders));
	}

	private void createCleanupExecutor(Environment environment, Sso1DAO ssoUsersDAO, RefreshTokensDAO refreshTokensDAO, KeysService keysService) {
		ScheduledExecutorService executor = environment.lifecycle().scheduledExecutorService("refreshTokensCleaner")
				.threads(1)
				.build();

		int initialDelay = ThreadLocalRandom.current().nextInt(16);
		executor.scheduleWithFixedDelay(() -> {
			try {
				refreshTokensDAO.deleteExpired();
				ssoUsersDAO.deleteExpiredSessionData(OffsetDateTime.now().minusHours(1));
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
		}, initialDelay, 16, TimeUnit.MINUTES);

		initialDelay = ThreadLocalRandom.current().nextInt(30);
		executor.scheduleWithFixedDelay(keysService::cleanupUnusedPublicKeys, initialDelay, KeysService.PUB_KEY_GC_INTERVAL_MINS * 60L, TimeUnit.SECONDS);
	}

	private void setupCORS(SSOServer2Configuration config, Environment environment) {
		log.info("CORS is enabled");

		Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,DELETE");

		// OPTIONS pre-flight request will be served by the filter ONLY and not
		// passed ahead
		// cors.setInitParameter(CrossOriginFilter.CHAIN_PREFLIGHT_PARAM,
		// "false");

		// Add URL mapping
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

	protected void initOpenApi(JerseyEnvironment jersey) throws IOException {
		OpenAPIConfiguration oasConfig = new ClasspathOpenApiConfigurationLoader()
				.load("openapi-configuration.yaml");

		jersey.register(new OpenApiResource()
				.openApiConfiguration(oasConfig));
	}

	private Map<String, ProxyLoginExecutor> loadProxyLoginExecutor(
			Map<String, ProxyLoginExecutorConfig> configurationsAvailable) {
		if (configurationsAvailable == null) {
			return new HashMap<>();
		}

		ServiceLoader<ProxyLoginExecutorFactory> loader = ServiceLoader.load(ProxyLoginExecutorFactory.class);
		Map<String, ProxyLoginExecutor> loginExecutors = new HashMap<>();

		loader.iterator().forEachRemaining(l -> {
			Map<String, ProxyLoginExecutor> loginExecutorsMap = l.getProxyLoginExecutors(configurationsAvailable);
			loginExecutorsMap.forEach((k, v) -> {
				loginExecutors.putIfAbsent(k, v);
				log.info("PROXY_LOGIN: Added proxy login with id: " + k);
			});
		});

		return loginExecutors;
	}

}
