package com.abacogroup.sso.server2.db.ntt;

import java.time.OffsetDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class Sso2RefreshToken {
	private String refresh_token;
	private String userid;
	private OffsetDateTime issued_at;
	private OffsetDateTime expires_at;

	public Sso2RefreshToken() {
	}

}
