package com.abacogroup.sso.server2.exceptions;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public abstract class AbstractException extends WebApplicationException {

	private static final long serialVersionUID = 4608998223109912890L;

	private String code;
	private String message;

	AbstractException(ExceptionErrorBody body, String message) {
		this(body, Status.BAD_REQUEST, message);
	}

	AbstractException(ExceptionErrorBody body, Response.Status status, String message) {
		super(message,
				Response.status(status).entity(body).build());
		this.code = body.getErrorCode();
		this.message = message;
	}

	public interface ExceptionErrorBody {
		String getErrorCode();
	}
}
