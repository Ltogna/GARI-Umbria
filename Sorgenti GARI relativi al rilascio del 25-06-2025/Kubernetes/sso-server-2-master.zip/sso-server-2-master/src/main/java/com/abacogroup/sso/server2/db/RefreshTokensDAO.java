package com.abacogroup.sso.server2.db;

import java.util.Optional;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.Timestamped;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.sso.server2.db.ntt.Sso2RefreshToken;

public interface RefreshTokensDAO extends Transactional<RefreshTokensDAO> {

	@SqlUpdate("insert into sso2_refresh_tokens (refresh_token, userid, issued_at, expires_at) values (:refresh_token, :userid, :issued_at, :expires_at)")
	void insertToken(@BindBean Sso2RefreshToken token);

	@SqlQuery("""
			select st.*
			 from sso2_refresh_tokens st, sso_users su
			 where st.refresh_token=:token
			 and st.expires_at >= :now
			 and st.userid = su.userid
			 and su.tenant_id = :tenantId""")
	@Timestamped
	@RegisterBeanMapper(Sso2RefreshToken.class)
	Optional<Sso2RefreshToken> getToken(@Bind("tenantId") String tenantId, @Bind("token") String token);

	@SqlUpdate("delete from sso2_refresh_tokens where refresh_token = :token")
	void delete(@Bind("token") String token);

	@SqlUpdate("delete from sso2_refresh_tokens where expires_at <= :now")
	@Timestamped
	void deleteExpired();

}
