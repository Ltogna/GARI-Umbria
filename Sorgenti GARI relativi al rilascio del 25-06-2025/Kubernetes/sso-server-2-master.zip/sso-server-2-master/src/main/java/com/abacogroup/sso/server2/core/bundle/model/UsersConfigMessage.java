package com.abacogroup.sso.server2.core.bundle.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UsersConfigMessage {
	private List<UserDefinition> users;
	private List<UserProperties> properties;
	private List<UserRole> userRoles;
	private List<ApiKeyDefinition> apiKeys;
}
