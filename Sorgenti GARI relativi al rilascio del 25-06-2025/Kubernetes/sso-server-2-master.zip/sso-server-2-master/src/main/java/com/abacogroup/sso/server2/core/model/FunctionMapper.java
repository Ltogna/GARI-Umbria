package com.abacogroup.sso.server2.core.model;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class FunctionMapper implements RowMapper<Function> {
    @Override
    public Function map(ResultSet rs, StatementContext ctx) throws SQLException {
        Function function = new Function();
        function.setFunctionId(rs.getInt("FUNCTION_ID"));
        function.setContextId(rs.getString("CONTEXT_ID"));
        function.setName(rs.getString("NAME"));
        function.setDescr(rs.getString("DESCR"));
        function.setTenantId(rs.getString("TENANT_ID"));
        return function;
    }
}
