package com.abacogroup.sso.server2.api;

import javax.validation.constraints.NotEmpty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class RefreshTokensResquest {
	@NotEmpty
	@Schema(description = "The refresh token")
	private String refresh_token;
}
