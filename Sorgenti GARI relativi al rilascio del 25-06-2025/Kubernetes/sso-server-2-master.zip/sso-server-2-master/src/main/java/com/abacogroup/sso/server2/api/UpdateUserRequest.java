package com.abacogroup.sso.server2.api;

import java.util.Map;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class UpdateUserRequest {
	@Schema(description = "The date format", example = "dd/MM/yyyy")
	private String dateFormat;

	@Schema(description = "The description")
	private String description;

	@Schema(description = "Y for internal users, N otherwise")
	private Character flInternal;

	@Schema(description = "Y if the user is locked, N otherwise")
	private Character isLocked;

	@Schema(description = "1 if the user is a parent user")
	private Short isParent;

	@Schema(description = "The parent user ID")
	private String parentUserId;

	@Schema(description = "The password")
	private String password;

	@Schema(description = "1 if the password is already encoded")
	private Short isPasswordEncoded;

	@Schema(description = "The user language", example = "en")
	private String language;

	@Schema(description = "The user properties")
	private Map<String, String> userProperties;

	@Schema(description = "Y if the user wants to change password on next login, N otherwise")
	private char isModifyPasswordOnNextLogin;
}
