#!/bin/sh
umask 0002

java -Djava.security.egd=file:/dev/./urandom -XX:MaxRAMPercentage=70 -XshowSettings:vm -jar original-${project.build.finalName}.jar server config.yml
