#!/bin/sh
umask 0002

java -jar original-${project.build.finalName}.jar delete-old-pubkeys -d 90 config.yml
