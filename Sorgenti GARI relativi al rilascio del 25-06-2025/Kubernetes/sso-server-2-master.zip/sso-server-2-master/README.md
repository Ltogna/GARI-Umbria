# Abaco SSO server v2

## Bundles format

The application can be conencted to a RabbitMQ instance usign this configuration snippet:
```yaml
    rabbitmqConfig:
      host: ${RMQ_HOST}
      user: ${RMQ_USER}
      password: ${RMQ_PASSWORD}
      virtualhost: ${RMQ_VHOST}
      port: ${RMQ_PORT}
```

If the connection is configured, the bundles infrastructure will be automatically setup to allow automatic configuration.

The application module id is `sso-server-2` and the supported changeset domains are: 

```
📂functions
 ┣ 📜 <any file>.json
 ┗ 📜 <any file>.delete.json
📂users 
 ┗📜 <any file>.json
📂languages
 ┗📜 <any file>.json
📂parameters
 ┣ 📜<any file>.json
 ┗ 📜<any file>.json
```

The `functions` domain allows to load, update and delete:
- functions
- roles
- role functions

The `users` domain allows to load and update and delete:
- users (no delete!)
- user roles
- user api keys

The `languages` domain allows to load `languages`

The `parameters` domain allows to load, update and delete `parameters`:
- parameters

The insert and update files extension is `.json`; the received file will replace all languages previously loaded, if any.

### functions .json files

.json files must follow this structure:

```json
{
    "functions": [],
    "roles": [],
    "roleFunctions": []
}
```

where any of functions, roles and roleFunctions can be omitted.

an example file is:

```json
{
    "functions": [
        {
            "context": "TEST-CONTEXT",
            "code": "ADMIN",
            "description": "Administrators"
        },
        {
            "context": "ANOTHER-CONTEXT",
            "code": "ADMIN",
            "description": "Administrators"
        }
    ],
    "roles": [
        {
            "code": "ROLE1",
            "description": "Role 1"
        },
        {
            "code": "ROLE2",
            "description": "Role 2"
        }
    ],
    "roleFunctions": [
        {
            "roleCode": "ROLE1",
            "functions": [
                {
                    "context": "TEST-CONTEXT",
                    "code": "ADMIN"
                },
                {
                    "context": "ANOTHER-CONTEXT",
                    "code": "ADMIN"
                }
            ]
        },
        {
            "roleCode": "ROLE2",
            "functions": [
                {
                    "context": "ANOTHER-CONTEXT",
                    "code": "ADMIN"
                }
            ]
        }
    ]
}
```

### functions .json.delete files

.json.delete files must have the same structure as .json file but the content is only composed by the "keys" of the elements to delete; an example file is:

```json
{
    "functions": [
        {
            "context": "TEST-CONTEXT",
            "code": "ADMIN"
        },
        {
            "context": "ANOTHER-CONTEXT",
            "code": "ADMIN"
        }
    ],
    "roles": [
        { "code": "ROLE1" },
        { "code": "ROLE2" }
    ],
    "roleFunctions": [
        {
            "roleCode": "ROLE1",
            "functions": [
                {
                    "context": "TEST-CONTEXT",
                    "code": "ADMIN"
                },
                {
                    "context": "ANOTHER-CONTEXT",
                    "code": "ADMIN"
                }
            ]
        },
        {
            "roleCode": "ROLE2",
            "functions": [
                {
                    "context": "ANOTHER-CONTEXT",
                    "code": "ADMIN"
                }
            ]
        }
    ]
}
```

### users .json files
.json files must follow this structure:

```json
{
    "users": [],
    "userRoles": [],
    "apiKeys": []
}
```

where any of functions, roles and roleFunctions can be omitted.

an example file is:

```json
{
    "users": [
        {
            "username": "t.nolli@abacogroup.eu",
            "password": "plain text password",
            // "password": "$random$",  Creates a random password on the server, you will never know what that is
            // "password": "",  Create a user that cannot login
            "descr": "Tommaso Nolli",
            "locale": "it",
            "dateFormat": "dd/MM/yyyy",
            "forceChangePassword": false,
        }
    ],
    "properties": [
        {
            "username": "t.nolli@abacogroup.eu",
            // "properties": {} ->  An empty map removes all properties on the DB
            "properties": {
                "key": "value"  // Values must be strings
            }
        }
    ],
    "userRoles": [
        {
            "username": "t.nolli@abacogroup.eu",
            "roleCodes": [ "ROLE1", "ROLE2" ]
        }
    ],
    "apiKeys": [
        {
            "username": "t.nolli@abacogroup.eu",
            "validFrom": "2025-02-11T00:00:00Z",
            "validTo": "9999-12-31T00:00:00Z",
            "description": "The api key description"
        }
    ]
}
```

### users .json.delete files
.json.delete files must have the same structure as .json file but the content is only composed by the "keys" of the elements to delete (users can not be deleted); an example file is:

```json
{
    "userRoles": [
        {
            "username": "t.nolli@abacogroup.eu",
            "roleCodes": [ "ROLE1", "ROLE2" ]
        }
    ]
}
```

### languages .json files

.json files must follow this structure:

```json
{
    "languages": {
        "language_code": [
            {
                "lang": "String",
                "description": "String"
            },
            ...
        ],
        ...
    }
}
```

All previous languages are deleted for the tenant; you must load the whole list of supported languages every time.

an example file is:

```json
{
    "languages": {
        "it": [
            {
                "lang": "it",
                "description": "Italiano"
            },
            {
                "lang": "en",
                "description": "Inglese"
            }
        ],
        "en": [
            {
                "lang": "it",
                "description": "Italian"
            },
            {
                "lang": "en",
                "description": "English"
            }
        ]
    }
}
```

### parameters .json files

.json files must follow this structure:

```json
{
    "parameters": {
        "key": "value",
        // ...
    }
}
```

All previous parameters are deleted; you must load the whole list of supported parameters every time.

An example:

```json
{
    "parameters": {
        "sso_key_1": "sso_val_1",
        "sso_key_2": "sso_val_2",
        "sso_key_3": "sso_val_3"
    }
}
```

### parameters .delete.json files

.delete.json files must the structured the same as the json file, but composed of only key entries to delete. An example file:


```json
{
    "parameters": {
        "sso_key_2": "sso_val_2"
    }
}
```

## Health Check

To see your applications health enter url `http://localhost:8081/healthcheck`

## SPID
### RSA key generation

```bash
openssl genrsa -out private_key.pem 2048

# Convert to PKCS-8
openssl pkcs8 -topk8 -inform PEM -outform DER -in private_key.pem -out private_key.der -nocrypt

openssl rsa -in private_key.pem -pubout -outform DER -out public_key.der

```

### SPID test2

```bash
openssl req -x509 \
            -nodes \
            -sha256 \
            -subj '/C=IT' \
            -newkey rsa:2048 \
            -keyout conf/idp.key \
            -days 36500 \
            -out conf/idp.crt

docker run --rm -p 8088:8088 -v C:\temp\spid-testenv2:/app/conf italia/spid-testenv2
```
