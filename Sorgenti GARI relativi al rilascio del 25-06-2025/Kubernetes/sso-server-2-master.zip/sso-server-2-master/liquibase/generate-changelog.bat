@echo off
liquibase generateChangeLog
