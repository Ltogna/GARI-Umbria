CREATE TABLE sso2_refresh_tokens (
  refresh_token VARCHAR2(4000 CHAR) NOT NULL,
  userid varchar2(100) NOT NULL,
  issued_at date default sysdate not null,
  expires_at DATE NOT NULL,
  CONSTRAINT sso2_refresh_tokens_pk PRIMARY KEY (refresh_token)
);

create index sso2_refresh_tokens_ix1 on sso2_refresh_tokens (expires_at);

COMMENT ON TABLE sso2_refresh_tokens IS 'SSO2 Refresh tokens';
COMMENT ON COLUMN sso2_refresh_tokens.refresh_token IS 'Refresh token';
COMMENT ON COLUMN sso2_refresh_tokens.userid IS 'User ID';
COMMENT ON COLUMN sso2_refresh_tokens.issued_at IS 'Date at which the token was issued';
COMMENT ON COLUMN sso2_refresh_tokens.expires_at IS 'Date at which the token expires';
