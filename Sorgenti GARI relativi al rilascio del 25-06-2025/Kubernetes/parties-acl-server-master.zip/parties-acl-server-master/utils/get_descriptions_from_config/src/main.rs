use serde::Deserialize;
use std::fs::File;
use std::io::prelude::*;
use serde_yaml::to_string;

#[derive(Debug, Deserialize)]
struct ConfigEntry {
    key: String,
    description: String,
    #[serde(rename = "type")]
    data_type: String,
    is_array: Option<bool>,
    default_value: Option<serde_yaml::Value>,
    fl_client: bool,
}

#[derive(Debug, Deserialize)]
struct Config {
    #[serde(rename = "internalConfig")]
    entries: Vec<ConfigEntry>,
}

fn main() -> std::io::Result<()> {
    // Define the path to your YAML file
    let file_path = "..\\..\\application-config.yml";

    // Open the file and read its contents
    let mut file = File::open(file_path)?;
    let mut contents = String::new();
    file.read_to_string(&mut contents)?;

    let config: Result<Config, serde_yaml::Error> = serde_yaml::from_str(&contents);

    // Print the table header
    println!("#### Internal config variables");
    println!("| Key | Description | Type | is array | Default Value | fl_client |");
    println!("|:---|:---|:---|:---|:---|:---|");

    match config {
        Ok(config) => {
            for entry in config.entries {

                let mut default_value_str = String::new();
                let is_arr = match entry.is_array {
                    Some(value) => value,
                    None => false,
                  }; 

                if let Some(default_value) = entry.default_value {
                    match default_value {
                        serde_yaml::Value::Sequence(values) => {
                            for (i, value) in values.iter().enumerate() {
                                if i > 0 {
                                    default_value_str.push(',');
                                }
                                default_value_str.push_str(&to_string(value).unwrap().trim_end_matches(&['\r', '\n'][..]));
                            }
                        },
                        serde_yaml::Value::String(s) => default_value_str = s,
                        _ => default_value_str = to_string(&default_value).unwrap().trim_end_matches(&['\r', '\n'][..]).to_string(),
                    }
                } else {
                    default_value_str = "-".to_string();
                }

                // Print each row of the table
                println!(
                    "| {} | {} | {} | {} | {} | {} |",
                    entry.key, entry.description, entry.data_type.split(".").last().unwrap(), is_arr, default_value_str.replace("\n", "<br /> "), entry.fl_client
                );

            }
        }
        Err(err) => println!("Error parsing YAML: {}", err),
    }

    Ok(())
}
