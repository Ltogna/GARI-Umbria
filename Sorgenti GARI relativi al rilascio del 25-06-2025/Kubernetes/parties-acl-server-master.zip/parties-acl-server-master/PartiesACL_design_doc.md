# Parties ACL

## NOTE VARIE

Esiste una tabella dei tipi di ente che ha un codice e una descrizione internazionalizzata

Nella relazione utente-ente c'è il tipo (admin o standard)

Esiste una tabella dei tipi di relazione soggetto-ente che contiene
 - descrizione internazionalizzata
 - flag esclusivo (determina che in un lasso di tempo può avere una sola relazione di questo tipo)
 - lista tipi di ente utilizzabili
 - flag gestione

Nella relazione soggetto-ente deve esserci il codice del tipo di relazione soggetto-ente e il periodo temporale (diventano 4 date)

Nella tabella degli enti potremo avere un id_soggetto nullabile

## TABELLE GESTITE

### Enti

| id | descrizione | fl_single_party | id_ente_padre (opzionale) | tree_path |

### Enti-Soggetti

| id_ente | id_soggetto |

### Enti-Utenti

| id_ente | id_utente | livello (ADMIN | STANDARD) |

## TABELLE DI SERVIZIO

### Tabella storia modifiche

| progressivo | operazione | id_soggetto_o_utente | tree_path | new_tree_path | add_user_livello | data_operazione |

Dove:
- progressivo: progressivo numerico ordinato che identifica l'ordine e le modifiche
- operazione: ADD_USER | ADD_PARTY | REMOVE_USER | REMOVE_PARTY | TRUNC_PATH | EXT_PATH 
- id_soggetto_o_utente: soggetto o utente (dipende da operazione (ADD_USER | ADD_PARTY | REMOVE_USER | REMOVE_PARTY))
- tree_path: il tree path dei record in oggetto
- new_tree_path: nuovo path (nel caso di TRUNC_PATH | EXT_PATH)

### Sincronizzazione dei "client"
Il software memorizza un log dei cambiamenti nella "Tabella storia modifiche"

Ad ogni operazione (o blocco di operazioni) verrà inviata notifica RabbitMQ di nuovi record disponibili.

Sarà disponibile una api per otterere (in ordine) tutte le modifiche successive ad un determinato progressivo.

La copia locale dell'applicazione interessata, dopo aver importato le modifiche, memorizzerà in loc0.al l'ultimo progressivo sincronizzato per poi utilizzarlo nella successiva sincronizzazione.

La "Tabella storia modifiche" verrà "ogni tanto" ripulita dai record vecchi.

Se un software richiede tutte le modifiche partendo da un progressivo non più presente allora deve essere forzata una reimportazione totale.

Anche nel caso di prima sincronizzazione (progressivo non disponibile nel software interessato) viene fatta reimportazione totale.

TODO (tabelle e query del client)

## Note:
- Il software deve impedire la creazione di loop su enti-enti (es: non devono esserci enti che sono padri o nonni di enti che sono suoi padri o nonni)
- Esiste il soggetto * che da l'accesso a tutti i soggetti
- Gli enti fl_single_party sono invisibili e ingestibili dall'esterno (dai software che "gestiscono"). Vengono creati implicitamente dall'api che assegna un utente ad un soggetto.
- Non possono esisteri più enti fl_single_party per lo stesso soggetto
- Manca da analizzare chi può fare cosa e su cosa può farlo
- Andrà sviluppata una libreria client che creerà la copia locale e recepirà le notifiche rabbitmq per tenerla aggiornata. La copia locale sarà comqunque ritenuta accessibile tramite sql (non privata per la libreria).
- Prevediamo una sincronizzazione massiva "ogni tanto"? magari fatta dalla libreria invocando le api del Parties ACL?
- La libreria dovrà comunque fare una sincronizzazione iniziale

## API

### Crea ente

  Aggiunge un record a "Enti" con id_ente_padre a NULL e tree_path composto come "/"+id_ente+"/"

### Elenco Enti

  Ritorna elenco degli enti esistenti (gli enti fl_single_party non vengono considerati)
  
### Elimina Ente

  Verifica che l'ente non sia associato a nessun utente e a nessuna gerarchia (non deve avere figli, non deve avere soggetti, non deve avere utenti).
  Se non associato allora lo cancella e basta

### Aggiungi soggetto ad ente 

  non può lavorare su enti fl_single_party
  
  se già aggiunto non fa nulla
  
  Una volta inserito il record in "Enti-Soggetti" deve anche:
  - Inserisce una riga in "Tabella storia modifiche":
    - progressivo: nuovo progressivo
    - operazione: ADD_PARTY
    - id_soggetto_o_utente: il party_id
    - tree_path: il tree_path dell'ente a cui è stato aggiunto
  - invia notifica RabbitMQ
  
### Rimuovi soggetto da ente 
  
  non può lavorare su enti fl_single_party
  
  se non era presente allora errore
  
  Una volta cancellato il record in "Enti-Soggetti" deve anche:
  - Inserisce una riga in "Tabella storia modifiche":
    - progressivo: nuovo progressivo
    - operazione: REMOVE_PARTY
    - id_soggetto_o_utente: il party_id
    - tree_path: il tree_path dell'ente a cui è stato rimosso
  - invia notifica RabbitMQ

### Aggiunti utente ad ente
  
 non può lavorare su enti fl_single_party

 se già aggiunto non fa nulla

  Una volta inserito il record in "Enti-Utenti" deve anche:
  - Inserisce una riga in "Tabella storia modifiche":
    - progressivo: nuovo progressivo
    - operazione: ADD_USER
    - id_soggetto_o_utente: lo user_id
    - add_user_livello: il livello con il quale è stato aggiunto
    - tree_path: il tree_path dell'ente a cui è stato aggiunto
  - invia notifica RabbitMQ

### Rimuovi utente da ente
  
 non può lavorare su enti fl_single_party

 se non era presente allora errore
  
  Una volta cancellato il record in "Enti-Utenti" deve anche:
  - Inserisce una riga in "Tabella storia modifiche":
    - progressivo: nuovo progressivo
    - operazione: REMOVE_USER
    - id_soggetto_o_utente: il party_id
    - tree_path: il tree_path dell'ente a cui è stato rimosso
  - invia notifica RabbitMQ

### Aggiungi mandato utente soggetto 
  
  crea implicitamente, se non esiste, un ente fl_single_party per il soggetto
  
  poi fa la medesima cosa dell'aggiunta utente a ente per l'ente fl_single_party del soggetto
  
### Rimuovi mandato utente soggetto 

  Fa quanto descritto nella rimozione utente da ente utilizzando l'ente fl_single_party di quel soggetto

### Aggiungi mandato utente "tutti" 

  crea implicitamente, se non esiste, un ente fl_single_party per il soggetto *

  poi fa la medesima cosa dell'aggiunta utente a ente per l'ente fl_single_party del soggetto
  
### Rimuovi mandato utente "tutti" 

  Fa quanto descritto nella rimozione utente da ente utilizzando l'ente fl_single_party del soggetto *

### Aggiungi Ente figlio ad Ente padre

  non può lavorare su enti fl_single_party (ne figli ne padri)
  
  Controlla la possibilità di farlo senza creare gerarchie "circolari" (loop gerarchici).
  
  Controlla che l'ente figlio non abbia già un padre altrimenti errore.
  
  esegue le seguenti operazioni sulla tabella "Enti"
  
  - update dell'ente figlio:
    - imposta id_ente_padre con id dell'ente padre
	- imposta tree_path con tree_path_dell_ente_padre + id_ente_figlio + "/"
  - update di tutti i record in cui il tree_path inizia con '/'+id_ente_figlio+"/ rimuovendo prima barra e concatenando all'inizio il tree_path dell'ente padre

  inoltre:

  - inserisce una riga in "Tabella storia modifiche":  
    - progressivo: nuovo progressivo
    - operazione: EXT_PATH
    - tree_path: il tree_path dell'ente figlio originale
	- new_tree_path: il tree_path dell'ente figlio dopo l'update
  - invia notifica RabbitMQ
  
  
### Rimuovi Ente figlio da ente padre

  Controlla che l'ente figlio abbia un padre altrimenti errore.

  esegue le seguenti operazioni sulla tabella "Enti"
  
  - update dell'ente figlio:
    - imposta id_ente_padre a null
	- imposta tree_path con "/"+id_ente+"/"
  - update di tutti i record in cui il tree_path inizia con il vecchio tree_path rimuovendo il vecchio inizio e sostituendolo con "/"+id_ente+"/" calcolato sull'ente di cui ho rimosso il padre

  inoltre:

  - inserisce una riga in "Tabella storia modifiche":  
    - progressivo: nuovo progressivo
    - operazione: TRUNC_PATH
    - tree_path: il tree_path dell'ente figlio originale
	- new_tree_path: il tree_path dell'ente figlio dopo l'update
  - invia notifica RabbitMQ

### Elenco appiattito

Ritorna l'elenco completo appiattito utile per resincronizzazione totale.
