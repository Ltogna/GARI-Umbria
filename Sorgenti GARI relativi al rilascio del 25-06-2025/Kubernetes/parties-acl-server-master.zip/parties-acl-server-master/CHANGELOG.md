# Parties ACL Server

# Changelog

[README](README.md)

### [v1.4.4](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.4.3...v1.4.4) (2025-04-05)

### Fixes
* :bug: error on adding user to a single party relation

### [v1.4.3](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.4.2...v1.4.3) (2025-02-24)

### Fixes
* :bug: fix party entities search for admin queries


### [v1.4.2](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.4.1...v1.4.2) (2025-02-14)

### Features

* :sparkles: added new query param to include parties of children by entity code, closes [#164124](https://abacogroup.easyredmine.com/issues/164124)

### Other

* :fire: removed unused query param

### [v1.4.1](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.4.0...v1.4.1) (2025-02-03)

### Features
* :sparkles: updated tracing-utils

### Fixes
* :green_heart: Fixed doc job in CI
* :bug: Fixed path generation on create as children

### [v1.4.0](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.3.5...v1.4.0) (2025-02-03)

### Features
* :sparkles: Allow setting a parent on entity creation

### Other
* :recycle: Bulk reformatting
* :recycle: updated tracing-utils

### [v1.3.5](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.3.4...v1.3.5) (2024-12-04)

### Features
* :sparkles: :boom: Added query param skipPermissionCheck on get all entities and get entity by code endpoints

### [v1.3.4](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.3.3...v1.3.4) (2024-08-06)

### Fixes
* :bug: fixed some queries

### [v1.3.3](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.3.2...v1.3.3) (2024-07-30)

### Fixes
* :bug: fixed some queries
* :bug: fixed RevisionHistoryDAO query
* :bug: fixed some entityType and partyType message processor logic, closes [#145826](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/issues/145826)
* :bug: fixed edit mandate issue for child entities, closes [#145894](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/issues/145894)


### [v1.3.2](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.3.1...v1.3.2) (2024-07-17) 

### Fixes
* **dao:** :bug: fix an error in mandates DAO getAllPartiesIdByEntityId, closes [#145396](https://abacogroup.easyredmine.com/issues/145396)
* :bug: fixed mandate count in parties search, closes [#145819](https://abacogroup.easyredmine.com/issues/145819)

### Other
* :recycle: refactor some query code

### Documentation
* :memo: sample bundle for revoke mandate config


### [v1.3.1](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.3.0...v1.3.1) (2024-07-05) run forrest run

### Fixes
* **docTypes:** :bug: :zap: fix performance issue in doc types search API


## [v1.3.0](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.2.8...v1.3.0) (2024-07-02) :boom: set revoke document

### Features
* :sparkles: :boom: changed visibility of mandates for user, closes [#142050](https://abacogroup.easyredmine.com/issues/142050)
* :sparkles: implement mandate status variable (VALID,NOT_VALID,CLOSED), closes [#141281](https://abacogroup.easyredmine.com/issues/141281)
* :sparkles: implement dynamic documents manage, closes [#141281](https://abacogroup.easyredmine.com/issues/141281)
  * :sparkles: new configuration for mandatory documents in mandate revision (create/close/extend/revoke) that can manage Mandate Status
  * :memo: create sample bundle for create mandate document, *with api call to unique code*
  * :memo: create sample bundle for close mandate document, *with api call to unique code*
  * :memo: create sample bundle for revoke mandate document, *with api call to unique code*
* :sparkles: implement revoke mandate, closes [#141281](https://abacogroup.easyredmine.com/issues/141281)
  * :sparkles: add new config key 'revoke_mandate_config' to set revoke types and validity dates see [readme](README.md)
* :sparkles: add new config key 'allow_past_close_date' to allow free close mandate date
* :sparkles: add new config key 'show_chronological_due_date' used only on the UI side, closes [#141281](https://abacogroup.easyredmine.com/issues/141281)
* :sparkles: add public version of create mandate, closes [#142051](https://abacogroup.easyredmine.com/issues/142051)
* :sparkles: add new config key 'party_registry_search_additional_query_param', closes [#142050](https://abacogroup.easyredmine.com/issues/142050)

### Other
* :recycle: minor refactor
* :green_heart: fix SSO2_TOKENS_AUTH_SECRET value definition in helm deployment
* :recycle: some fixes to make sonar happy
* :hammer: little utility program to export all application config keys with description
* :recycle: used client helper for PartyRegistryClient
* :recycle: used abaco jdbi AbsoluteDate
* :arrow_up: upgrade some dependencies
* :fire: remove unused code

### Documentation
* :memo: upload anlisys document [New AGRI - Gestione Mandati v.2.0.docx](docs/analisi/New AGRI - Gestione Mandati v.2.0.docx)
* :memo: update docs and ReadMe
* :memo: update error descriptions


### [v1.2.8](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.2.7...v1.2.8) (2024-05-29) only one fix

### Fixes
* **madates:** :bug: fix a big typo error in getAllMandatesByUserId


### [v1.2.7](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.2.6...v1.2.7) (2024-05-27) better user error message

### Other
* :green_heart: add automatic release on tag
* :recycle: refactor error description messages, closes [#140168](https://abacogroup.easyredmine.com/issues/140168)


### [v1.2.6](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.2.5...v1.2.6) (2024-05-20) exclusives fixes

### Fixes
* :bug: fixed import party type bundle issue
* **mandate:** :bug: fix issue in exlusive mandate elaboration, closes [#140168](https://abacogroup.easyredmine.com/issues/140168)


### [v1.2.5](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.2.4...v1.2.5) (2024-05-17)

### Fixes
* :bug: fix a null pointer in withmanage evalution in private API


### [v1.2.4](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.2.3...v1.2.4) (2024-05-17)

### Features
* :beers: As requested permit to all user to see all mandates with aprameter, closes [#138998](https://abacogroup.easyredmine.com/issues/138998)
* :construction: REMOVE roles permission in getAllEntitiesByPartyId public API for CLL, closes [#138998](https://abacogroup.easyredmine.com/issues/138998)

### Fixes
* :bug: fix double variable declaration


### [v1.2.3](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.2.2...v1.2.3) (2024-05-08)

### Feature
* :sparkles: implement get all entities by partyId public API with entityTypeCode filter


### [v1.2.2](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.2.1...v1.2.2) (2024-03-29)

### Fixes
* :bug: added new tenant message processor for entity type, party type and i18n values

### Other
* :pencil2: minor fix typos


### [v1.2.1](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.2.0...v1.2.1) (2024-01-29)

### Features
* :sparkles: added new public api to get parties by entity code, closes [#129433](https://abacogroup.easyredmine.com/issues/129433)

### Fixes
* :bug: fixed duplicate mandates result with inherit_management flag issue, closes [#126355](https://abacogroup.easyredmine.com/issues/126355)
* :bug: fixed clob issue in getAllEntitiesByPartyId query


## [v1.2.0](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.1.7...HEAD) (2023-11-07)

### Features
* :sparklesL added public api to get users bu group id, closes [#121108](https://abacogroup.easyredmine.com/issues/121108)
* :sparkles: added publicTypesResources

### Fixes
* :bug: fixed and refactor PublicEntitiesService

### Other
* :recycle: refactor PublicMandatesService


## [v1.1.7](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.1.6...v1.1.7) (2023-10-03) Apigateway Configuration

### Fixes
* **Abaco Apigateway:** :boom: New apigateway configuration NEED minimum **_abaco apigateway version v1.5.3_**


## [v1.1.6](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.1.5...v1.1.6) (2023-09-27) internal api routes

### Fixes
* **internalApi:** :bug: fixed internal api route
* **helm:** :lock: fix internal api expose in apiGateway

## [v1.1.5](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.1.4...v1.1.5) (2023-09-12) new config keys to inherit management

### Features

* :sparkles: added new hidden api to get internal configuration values by config keys
* :sparkles: added new config key inherit_management
* :wrench: added new config key hierarchical_inheritance_level

### Fixes

* :bug: fixed internal api to get config keys
* :bug: fixed queries to inherit management from parent group
* :bug: fixed public method to search parties

## [v1.1.4](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.1.3...v1.1.4) (2023-08-18) fixes and allt tenant party

### Features

* implement internal api for tenant list
* update error codes internazionalization bundle
* add invalid request error if env is null

### Fixes

* :bug: fix issue in userid check, now is case insensitive
* :bug: fix check past date in update party mandate
* **mandates:** fix issue in mandate comparision check

### Other

* some comments cleanup
* :pencil2: fix some typos
* :recycle: embedded queue builder refactor


## [v1.1.3](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.1.2...v1.1.3) (2023-07-24) hide hidden party types

### Fixes
* :bug: not show hidden entity types in standard apis

### Other
* :arrow_up: upgrade dropwizard to 4.0.1
* :arrow_up: upgrade jaxrs jackarta to 2.2.15
* :arrow_up: upgrade abaco tracing utils to 4.1.0
* :arrow_up: upgrade embedded db queue to 1.9.0
* :arrow_up: upgrade abaco jdbi to 2.13.0
* set max age for helm db migrate job


## [v1.1.2](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.1.1...v1.1.2) (2023-07-11) public proxy release party

### Features
* :sparkles: added public api to proxy the search of parties from party-registry with additional informations [#107623](https://abacogroup.easyredmine.com/issues/107623)
* :sparkles: implemented public api to add user to an entity
* :sparkles: implemented public api to create entity
* :sparkles: implemented new public api to get all entities

### Fixes
* **mandates:** :bug: fix issue in single party creation now send insert operation message

### Other
* :recycle: some code refactor
* fix issue in party registry url config in config-docker file


## [v1.1.1](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.1.0...v1.1.1) (2023-07-05) fix issue for single party

### Fixes
* **mandates:** :bug: fix issue in single party user add api


## [v1.1.0](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.0.1...v1.1.0) (2023-07-03) DropWizard 4 and tracing lib

### Features
* :sparkles: implement abaco tracing lib
* :arrow_up: upgrade to dropwizard 4.0.0
* :sparkles: implemented public api getMandates
* **publicApis:** :sparkles: implement new api for user party authorizations

### Fixes
* :bug: fixed getAllEntitiesByPartyId in MandatesDAO
* :bug: update hasManage query
* **resources:** :passport_control: fix authorizations on resources apis

### Other
* :recycle: fixed some sonar issue


## [v1.0.1](https://gitlab.fe.abacogroup.eu/new-agri/parties-acl-server/compare/v1.0.0...v1.0.1) (2023-06-15) Public APIs

### Features
* **public:** :sparkles: implement get entity by code public api
* **public:** :sparkles: implement has manage check public api

### Fixes
* **mandates:** :bug: fix an error code
* :bug: fix check for past date
* :bug: fix issue in parent values sub queries


## [v1.0.0] (2023-06-05) A new Bal-ance

### Parties ACL Server
#### Manage link between users and parties

Connection are defined in typed group (entities) who link a list of roled users and a list of typed mandates on subjects (parties)

New API written, view OpenAPI swagger file for details:
    GET     /{tenant}/api-priv/v1/parties-acl/anomalies/parties/{partyId}
    GET     /{tenant}/api-priv/v1/parties-acl/entities
    POST    /{tenant}/api-priv/v1/parties-acl/entities
    GET     /{tenant}/api-priv/v1/parties-acl/entities/types
    POST    /{tenant}/api-priv/v1/parties-acl/entities/types
    DELETE  /{tenant}/api-priv/v1/parties-acl/entities/types/{id}
    GET     /{tenant}/api-priv/v1/parties-acl/entities/types/{id}
    GET     /{tenant}/api-priv/v1/parties-acl/entities/{entityId}
    PUT     /{tenant}/api-priv/v1/parties-acl/entities/{entityId}
    GET     /{tenant}/api-priv/v1/parties-acl/entities/{entityId}/children
    DELETE  /{tenant}/api-priv/v1/parties-acl/entities/{entityId}/children/{childId}
    PUT     /{tenant}/api-priv/v1/parties-acl/entities/{entityId}/children/{childId}
    POST    /{tenant}/api-priv/v1/parties-acl/entities/{entityId}/closedate
    GET     /{tenant}/api-priv/v1/parties-acl/entities/{entityId}/parties
    POST    /{tenant}/api-priv/v1/parties-acl/entities/{entityId}/parties
    GET     /{tenant}/api-priv/v1/parties-acl/entities/{entityId}/users
    POST    /{tenant}/api-priv/v1/parties-acl/entities/{entityId}/users
    DELETE  /{tenant}/api-priv/v1/parties-acl/entities/{entityId}/users/{userId}
    GET     /{tenant}/api-priv/v1/parties-acl/entities/{entityId}/users/{userId}
    PUT     /{tenant}/api-priv/v1/parties-acl/entities/{entityId}/users/{userId}
    GET     /{tenant}/api-priv/v1/parties-acl/internal-api/mandates
    GET     /{tenant}/api-priv/v1/parties-acl/internal-api/revisions
    DELETE  /{tenant}/api-priv/v1/parties-acl/mandates/{mandateId}
    GET     /{tenant}/api-priv/v1/parties-acl/mandates/{mandateId}
    PUT     /{tenant}/api-priv/v1/parties-acl/mandates/{mandateId}
    POST    /{tenant}/api-priv/v1/parties-acl/mandates/{mandateId}/closedate
    GET     /{tenant}/api-priv/v1/parties-acl/parties/types
    POST    /{tenant}/api-priv/v1/parties-acl/parties/types
    DELETE  /{tenant}/api-priv/v1/parties-acl/parties/types/{id}
    GET     /{tenant}/api-priv/v1/parties-acl/parties/types/{id}
    PUT     /{tenant}/api-priv/v1/parties-acl/parties/types/{id}
    GET     /{tenant}/api-priv/v1/parties-acl/parties/{partyId}/entities
    POST    /{tenant}/api-priv/v1/parties-acl/parties/{partyId}/users
    DELETE  /{tenant}/api-priv/v1/parties-acl/parties/{partyId}/users/{userId}
    PUT     /{tenant}/api-priv/v1/parties-acl/parties/{partyId}/users/{userId}
    GET     /{tenant}/api-priv/v1/parties-acl/support/config
    GET     /{tenant}/api-priv/v1/parties-acl/support/config/{configKey}
    GET     /{tenant}/api-priv/v1/parties-acl/users/{userId}/entities
    GET     /{tenant}/api-priv/v1/parties-acl/users/{userId}/parties
    GET     /{tenant}/api-priv/v1/parties-acl/users/{userId}/parties/{partyId}
    GET     /{tenant}/api-priv/v1/parties-acl/utility/api.version

