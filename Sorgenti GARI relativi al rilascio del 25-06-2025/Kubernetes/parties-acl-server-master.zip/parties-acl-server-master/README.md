# Parties ACL Server (v1.4.3)

Backend software based on Dropwizard for Parties ACL Server project

[CHANGELOG](CHANGELOG.md)

API: [OpenAPI.yaml](openapi.yaml)

### Compile: `mvn clean compile package`

### Execution: `java -jar target/parties-acl-server-X.X.X.jar server config.yml`

dev url: http://localhost:8080/parties-acl-server


### To exec database upgrade: `java -jar target/parties-acl-server-X.X.X.jar db migrate config.yml`

## Security Context and functions used

The SSO context|functions used in the software are:
- PACL|ADMIN,
   - it enable the user to create entities
- PACL|EDITOR
   - it enable the user to edit entities or mandates
- PACL|VIEWER
   - it enable the user to view all the data in PACL

## Configure application-config
The application-config.yml contains the internal configuration of project, the file name is setted in yaml config file with `applicationConfigFile` key.
A property is compose with:

- `key`: (mandatory) name of property to configure
- `type`: type of property value ( java.lang.Double, java.lang.String, ...). Default is java.lang.String if is not set
- `is_array`: flag if property value is an array
- `default_value`: (mandatory) Value of property
- `fl_client`: (mandatory) flag if property is visible for client
- `name`: name of property for client

## Bundles Infrastructure integration
The application must be connected to a RabbitMQ instance.

The bundles infrastructure will automatically set up to allow automatic configuration.

The application module id is `parties-acl-server` and the supported changeset domains are:

```
📂 parties-acl-server
┗━📂 <client-id>-<nnnnn>
  ┣━📂 internal-config
  ┃ ┣━📜 <any file>.json
  ┃ ┗━📜 <any file>.delete.json
  ┣━📂 entity-type
  ┃ ┣━📜 <any file>.json
  ┃ ┗━📜 <any file>.delete.json
  ┣━📂 party-type
  ┃ ┣━📜 <any file>.json
  ┃ ┗━📜 <any file>.delete.json
  ┣━📂 anomaly-categories
  ┃ ┣━📜 <any file>.json
  ┃ ┗━📜 <any file>.delete.json
  ┣━📂 dynamic-documents
  ┃ ┣━📜 <any file>.json
  ┃ ┣━📜 settings<.*>.json
  ┃ ┗━📜 settings<.*>delete<.*>.json
  ┗━📂 i18n
    ┣━📜 <any file>.json
    ┗━📜 <any file>.delete.json
```
### Internal configuration

The internal-config JSON file(s) must have the following structure:
```json
{
  "internalConfig":[
	    {
	      "key": "String (mandatory)",          // Name of configuration
	      "value": "Object (mandatory)",        // Value of configuration
	      "fl_client": "Boolean (mandatory)",   // Flag set to true if the configuration is for client
	      "name": "String"                      // Optional name of configuration for client
	    },
	    // ...
    ]
}
```

Internal-config file(s) end with ".delete.json" is used for delete pacl_config table table entries and must have the following structure:
```json
{
  "internalConfig":[
	    {
	      "key": "String (mandatory)"          // Name of configuration
	    },
	    // ...
    ]
}
```
`Internal config variables`:
| Key | Description | Type | is array | Default Value | fl_client |
|:---|:---|:---|:---|:---|:---|
| allow_past_date | indicates if start validation date can be before current date | Boolean | false | true | true |
| allow_past_close_date | indicates if close validation date can be before current date | Boolean | false | true | true |
| party_registry_url | the url of party registry to get party details by Id | String | false | /party-registry/{tenant}/public/v1/parties/{partyId} | true |
| anomalies_registry_url | the url of anomaly registry to get anomalies list by Id | String | false | /anomaly-registry/{tenant}/public/v1/anomalies/{anomalyEntityCode}?entityId={anomalyEntityId} | true |
| fl_show_uncategorized_anomaly_types | indicates if to show uncategorized anomlies | Boolean | false | true | true |
| anomalies_party_code_key | anomaly entity code for search party anomalies | String | false | REFERENCE_PARTY | true |
| anomalies_entity_code_key | anomaly entity code for search entity anomalies | String | false | REFERENCE_ENTITY | true |
| anomalies_user_code_key | anomaly entity code for search user anomalies | String | false | REFERENCE_USER | true |
| max_anomly_level_allowed_edit_party | the maximum anomaly level allowed for parties | String | false | WARN | true |
| max_anomly_level_allowed_edit_user | the maximum anomaly level allowed for users | String | false | WARN | true |
| max_anomly_level_allowed_edit_entity | the maximum anomaly level allowed for entities | String | false | WARN | true |
| external_check_before_close | the check for anomalies before closing a mandate | Boolean | false | false | true |
| hierarchical_inheritance_level | the max lavel of inheritance by which a user of a parent group inherits all the mandates of child groups | Integer | false | 0 | true |
| inherit_management | if true a user of a parent group inherits all the mandates with fl_manage true of child groups | Boolean | false | false | true |
| show_chronological_due_date | if true shows the chronological due date | Boolean | false | false | true |
| revoke_mandate_config | validation dates to revake a mandate | RevokeDatesConfig | true | empty | true |
| party_registry_search_additional_query_param | additional query params for party registry search | String | true | hasCode=true,withManage=-1 | true |

#### `RevokeDatesConfig` yaml config example:
```json
{
    "internalConfig":[
        {
           "key" : "revoke_mandate_config",
		   "value" : "[{\"partyTypeCode\": \"MANWGEST\", \"entityTypeCode\": \"CAA\", \"dayFrom\": \"1131\", \"dayTo\": \"1208\"}]",
           "name": "revoke_mandate_config",
		   "fl_client" : false
        }
    ]
}
```

### Entity-type codes

The entity-type JSON file(s) is used for insert entity type codes and i18n tables and must have the following structure:
```json
{
  "entity_type_list":
    [
    	{
	      "code": "String (mandatory)",
	      "fl_entity_code_mandatory": "Boolean (mandatory)",
	      "fl_single_relation": "Boolean (mandatory)",
	      "fl_hidden": "Boolean (mandatory)",
	      "translations" (mandatory) : {
	      			"String" : "String",
	      			// ...
	      	}
	    }
    ]
}
```
Example:
```json
{
  "entity_type_list":
    [
    	{
	      "code": "CAA",
	      "fl_entity_code_mandatory": true,
	      "fl_single_relation": false,
	      "fl_hidden": false,
	      "translations": {
                    "en" : "agricultural assistance center",
                    "it" : "centro di assistenza agricola"
	      	}
	    }
    ]
}
```

Entity-type file(s) end with ".delete.json" is used for delete pacl_entity_types table entries and must have the following structure:
```json
{
  "entity_type_code_list":[
	      "String (mandatory)",          // Entity type code to delete
	      // ...
    ]
}
```
Example:
```json
{
  "entity_type_code_list":["CAA"]
}
```

`Entity-type values`:

- `code`: code of entity type to insert/update in pacl_entity_types and i18n tables
- `fl_entity_code_mandatory`: flag to indicate if the entity code is required for the given entity-type code
- `fl_single_relation`: flag to indicate if the entity-type code is for single-party entities
- `fl_hidden`: flag to indicate if the entity-type code is for hidden entities
- `translations`: map of lang and description for entity-types to insert/update in i18n table


### Party-type codes

The party-type JSON file(s) is used for insert/update party type codes and i18n tables and must have the following structure:
```json
{
  "party_type_list":
    [
    	{
	      "code": "String (mandatory)",
	      "fl_exclusive": "Boolean (mandatory)",
	      "fl_manage": "Boolean (mandatory)",
	      "entity_type_codes" (mandatory): [
	      						"String",          // Entity type code to link with party type
	      						// ...
	      						]
	      "translations" (mandatory) : {
	      			"String" : "String",
	      			// ...
	      	}
	    }
    ]
}
```

Example:
```json
{
  "party_type_list":
    [
    	{
	      "code": "EXC-MAN",
	      "fl_exclusive": true,
	      "fl_manage": true,
	      "entity_type_codes": [
	      						"CAA"          // Entity type code to link with party type
	      						]
	      "translations": {
	      			"en" : "Exclusive mandate",
                    "it" : "Mandato esclusivo"
	      	}
	    }
    ]
}
```

Party-type file(s) end with ".delete.json" is used for delete pacl_party_types table entries and must have the following structure:
```json
{
  "party_type_code_list":[
	      "String (mandatory)",          // Party type code to delete
	      // ...
    ]
}
```

Example:
```json
{
  "party_type_code_list":["EXC-MAN"]         // Party type code to delete
}
```


`Party-type values`:

- `code`: code of party type to insert/update in pacl_party_types and i18n tables
- `fl_exclusive`: flag to indicate if the party is required exclusive in an entity
- `fl_manage`: flag to indicate if the party can be managed by the users of an entity
- `entity_type_codes`: list of entity type codes to link with party type
- `translations`: map of lang and description for party-types to insert/update in i18n table

### Anomaly categories

The anomaly categories JSONL file(s) is used for insert/update pacl_anomaly_categories table and must have the following structure:
```json
{"group_code": "String (mandatory)", "code": "String (mandatory)" ,"level": "AnomalyLevel (mandatory)", "fl_exclude": "boolean"}
// ...
```
The anomaly categories end with ".delete.jsonl" file(s) is used for delete pacl_anomaly_categories entries and must have the following structure:
```json
{"group_code": "String (mandatory)", "code": "String (mandatory)"}
// ...
```

`Anomaly categories values`:

- `group_code`: code group of anomaly categories
- `code`: code of anomaly categories
- `level`: level of anomaly, allowable values: DANGER, WARN, INFO
- `fl_exclude`: flag for exclude a category, default is false

### I18n

The i18n JSON file(s) is used for insert/ update i18n table and must have the following structure:
```json
{
  "i18n_list": [
        {
            "table": "String (mandatory)",
            "field": "String (mandatory)",
            "value": "String (mandatory)",
            "translations": {
            	"String" : "String",  (mandatory)
            	// ...
            }
        },
        // ...
    ]
}
```
I18n JSON file(s) end with ".delete.json" is used for delete i18n table entries.
If translations is set, delete only row for translation keys, all rows of table field otherwise. It must have the following structure:
```json
{
  "i18n_list": [
        {
            "table": "String (mandatory)",
            "field": "String (mandatory)",
            "value": "String (mandatory)",
            "translations": {
            	"String" : "String",
            	// ...
            }
        },
        // ...
    ]
}
```

`I18n values`:

- `table`: Table name of field
- `field`: Field name
- `value`: Value of field to translate
- `translations`: Map of lang and text for the field value


### Dynamic Documents

The `dynamic_documents` file(s) are used to insert/update dynamic document schemas.
JSON file(s) must have the following structure:

#### dynamic doc definitions

(see dynamic document documentation)

#### settings

The application handles `dynamic documents` (abbr: _DD_)

A sample configuration can be found at `Sample_Bundle/dynamicDoc/parties-acl-server`

The system will assume as definition file **any** `json` in the directory except those whose names begin with `settings` (e.g.: _settings_01.json_)

When loading a `DD` definition the i18n labels of the DD will be automatically created.

The settings file is used to define the usage of the _DD_ in the program.
An example of a settings file:

```json
[
    {
        "revision_code": "ADD_MANDATE",
        "scope_code": "MANDATES",
        "display_order": 100,
        "entity_type_code": "CAA",
        "party_type_code": "MANWGEST",
        "definition_code": "DEF_ADD_MANDATE"
    }
]
```
```json
[
    {
        "revision_code": "REMOVE_MANDATE",
        "scope_code": "MANDATES",
        "display_order": 700,
        "entity_type_code": "CAA",
        "party_type_code": "MANWGEST",
        "definition_code": "DEF_CLOSE_MANDATE"
    }
]
```
```json
[
    {
        "revision_code": "REVOKE_MANDATE",
        "scope_code": "MANDATES",
        "display_order": 900,
        "entity_type_code": "CAA",
        "party_type_code": "MANWGEST",
        "definition_code": "DEF_REVOKE_MANDATE"
    }
]
```

In the example above, for the revision **REVOKE_MANDATE**, activated when a mandate is revoked, there is a document associated for the mandate scope, the only one active now,
enbled for mandate in the **CAA** entity type and **MANWGEST** party type will be set the **DEF_REVOKE_MANDATE** document definition imported before.

#### delete settings

`dynamic_documents` files starting with `settings` and containing `delete` in the name (ex. 'settings_0001.delete.json') are used to delete settings related to
the specific DDType (definitionCode) and titleType.
The DDs will no longer be visualised by the FE but remain in the db and can be reactivated by a new settings file. JSON file(s) must
have the following structure:

```json
[
  {
    "revision_code": "REVOKE_MANDATE",
    "scope_code": "MANDATES",
    "display_order": 900,
    "entity_type_code": "CAA",
    "party_type_code": "MANWGEST",
    "definition_code": "DEF_REVOKE_MANDATE"
    // revision_code, entity_type_code, definition_code and scope are mandatory
    //they define the docType relation to remove
  }
  //[...]
]
```
