package com.abacogroup.partiesaclserver.resources.auth;

import java.util.Optional;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.partiesaclserver.resources.ResourcesTest;

import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.auth.Authenticator;
import io.dropwizard.auth.basic.BasicCredentials;

public class MyBasicAuthenticator implements Authenticator<BasicCredentials, User> {
	@Override
	public Optional<User> authenticate(BasicCredentials credentials) throws AuthenticationException {
		return Optional.of(new User(credentials.getUsername(), ResourcesTest.TENANT_ID));
	}
}
