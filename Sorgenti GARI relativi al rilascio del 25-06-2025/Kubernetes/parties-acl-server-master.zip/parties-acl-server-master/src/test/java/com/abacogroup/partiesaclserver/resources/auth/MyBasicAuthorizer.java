package com.abacogroup.partiesaclserver.resources.auth;

import org.checkerframework.checker.nullness.qual.Nullable;

import com.abacogroup.dropwizard.auth.sso2.User;

import io.dropwizard.auth.Authorizer;
import jakarta.ws.rs.container.ContainerRequestContext;

public class MyBasicAuthorizer implements Authorizer<User>
{
	@Override
	public boolean authorize(User principal, String role, @Nullable ContainerRequestContext requestContext) {
		return true;
	}
}
