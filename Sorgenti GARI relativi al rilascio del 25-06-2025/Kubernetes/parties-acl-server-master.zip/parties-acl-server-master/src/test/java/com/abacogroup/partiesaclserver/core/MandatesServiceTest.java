package com.abacogroup.partiesaclserver.core;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.function.Supplier;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.core.statement.StatementContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partiesaclserver.core.enums.AnomalyLevel;
import com.abacogroup.partiesaclserver.core.enums.InternalConfigKeys;
import com.abacogroup.partiesaclserver.core.enums.MandateStatus;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidEndDateException;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidPayloadException;
import com.abacogroup.partiesaclserver.core.exceptions.NothingToUpdateException;
import com.abacogroup.partiesaclserver.core.exceptions.PastDateNotallowedException;
import com.abacogroup.partiesaclserver.core.exceptions.ValidationDatesConflictException;
import com.abacogroup.partiesaclserver.core.exceptions.documents.CloseMandateDocumentNotFoundException;
import com.abacogroup.partiesaclserver.core.exceptions.documents.ExtendMandateDocumentNotFoundException;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityWithoutAdminExecption;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.ExclusivePartyException;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.PartyAnomalyException;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.PartyInEntityException;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.UserInEntityException;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.UserNotAssociatedWithEntityException;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.UserNotAssociatedWithPartyException;
import com.abacogroup.partiesaclserver.core.exceptions.security.UserNotAllowedExecption;
import com.abacogroup.partiesaclserver.core.mappers.MandatorUserMapper;
import com.abacogroup.partiesaclserver.core.mappers.PartyWithEntityMapper;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.ntt.EntityNTT;
import com.abacogroup.partiesaclserver.db.ntt.EntityTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.MandatorUserNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyWithEntityNTT;
import com.abacogroup.partiesaclserver.resources.req.AddMandatorUserPayload;
import com.abacogroup.partiesaclserver.resources.req.AddPartyPayload;
import com.abacogroup.partiesaclserver.resources.req.CloseDatePayload;
import com.abacogroup.partiesaclserver.resources.req.PartyEntitySearchFilters;
import com.abacogroup.partiesaclserver.resources.req.UpdateEntityUserPayload;
import com.abacogroup.partiesaclserver.resources.res.PartyWithEntity;
import com.abacogroup.partiesaclserver.resources.res.anomalies.AnomaliesList;
import com.abacogroup.partiesaclserver.utils.MyMockGenerator;

class MandatesServiceTest extends ServiceTest {

	private ServiceSupportEnv env;
	private MandatesService mandatesService;

	@Override
	protected void createService() {
		mandatesService = new MandatesService(daoContainer, securityService, revisionService, internalConfigService,
				anomaliesService, errorDescriptionsService, utilityService);
	}

	@BeforeEach
	void mockServiceSupportEnv() {
		env = getMockServiceSupportEnv("Username", "UserId", TENANT);
		when(utilityService.checkEnv(any(ServiceSupportEnv.class))).thenReturn(env);
		when(utilityService.getCurrentLocalDate()).thenReturn(LocalDate.now());
	}

	@Test
	void testAddPartyToEntity_Success() {
		Long entityId = 165L;
		Long mandateId = 15646L;
		AddPartyPayload payload = AddPartyPayload.builder()
				.id("165466")
				.partyTypeCode("test")
				.dayFrom(now)
				.dayTo(infinite)
				.build();

		when(mandatesDAO.nextSequenceValEntitiesParties()).thenReturn(16494L);
		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(utilityService.checkMandateStatus(eq(env), any(), any(), any())).thenReturn(MandateStatus.NOT_VALID);
		when(utilityService.getPartyTypeNTTByCode(eq(env), anyString(), any())).thenReturn(MyMockGenerator.getMockedPartyTypeNTT());
		when(mandatesDAO.checkExclusiveParty(eq(env.getTenantId()), eq(entityId), eq(payload.getId()), eq(payload.getDayFrom()), eq(payload.getDayTo()))).thenReturn(0);
		when(mandatesDAO.checkPartyInEntity(eq(env.getTenantId()), eq(entityId), eq(payload.getId()), any(AbsoluteDate.class),any(AbsoluteDate.class))).thenReturn(0);
		when(internalConfigService.getBooleanValue(eq(env.getTenantId()), anyString())).thenReturn(true);
		when(mandatesDAO.nextSequenceValMandateId()).thenReturn(mandateId);

		assertEquals(mandateId, mandatesService.addPartyToEntity(env, entityId, payload));
		verify(utilityService).getEntityById(any(), any(), any(), any(), any());
		verify(utilityService).checkEntityPartyTypeCompatibility(any(), any(), any(), any());
		verify(utilityService).checkEnv(any());
		verify(utilityService).getPartyTypeNTTByCode(any(), any(), any());
		verify(utilityService).checkEntityPartyTypeCompatibility(any(), any(), any(), any());
	}

	@Test
	void testAddPartyToEntityThrowsExclusivePartyException() {
		Long entityId = 165L;
		AddPartyPayload payload = AddPartyPayload.builder()
				.id("165466")
				.partyTypeCode("test")
				.dayFrom(now)
				.dayTo(infinite)
				.build();

		when(mandatesDAO.nextSequenceValEntitiesParties()).thenReturn(16494L);
		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(utilityService.getPartyTypeNTTByCode(eq(env), anyString(), any())).thenReturn(MyMockGenerator.getMockedPartyTypeNTT());
		when(mandatesDAO.checkExclusiveParty(eq(env.getTenantId()), eq(entityId), eq(payload.getId()), eq(payload.getDayFrom()), eq(payload.getDayTo()))).thenReturn(1);
		
		assertThrows(ExclusivePartyException.class, () -> mandatesService.addPartyToEntity(env, entityId, payload));
	}

	@Test
	void testAddPartyToEntityThrowsValidationDatesConflictException() {
		Long entityId = 165L;
		AddPartyPayload payload = AddPartyPayload.builder()
				.id("165466")
				.partyTypeCode("test")
				.dayFrom(now)
				.dayTo(AbsoluteDate.of("99990101"))
				.build();

		EntityNTT entityNTT = MyMockGenerator.getMockedEntityNTT();
		entityNTT.setDay_to(AbsoluteDate.of("99981231"));

		when(mandatesDAO.nextSequenceValEntitiesParties()).thenReturn(16494L);
		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(entityNTT);
		when(utilityService.getPartyTypeNTTByCode(eq(env), eq(payload.getPartyTypeCode()), any())).thenReturn(MyMockGenerator.getMockedPartyTypeNTT());
		when(mandatesDAO.checkExclusiveParty(eq(env.getTenantId()), eq(entityId), eq(payload.getId()), eq(payload.getDayFrom()), eq(payload.getDayTo()))).thenReturn(0);
		when(internalConfigService.getBooleanValue(eq(env.getTenantId()), anyString())).thenReturn(true);

		assertThrows(ValidationDatesConflictException.class, () -> mandatesService.addPartyToEntity(env, entityId, payload));
	}

	@Test
	void testAddPartyToEntityThrowsPartyInEntityException() {
		Long entityId = 165L;
		AddPartyPayload payload = AddPartyPayload.builder()
				.id("165466")
				.partyTypeCode("test")
				.dayFrom(now)
				.dayTo(infinite)
				.build();

		when(mandatesDAO.nextSequenceValEntitiesParties()).thenReturn(16494L);
		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(utilityService.getPartyTypeNTTByCode(eq(env), eq(payload.getPartyTypeCode()), any())).thenReturn(MyMockGenerator.getMockedPartyTypeNTT());
		when(mandatesDAO.checkExclusiveParty(eq(env.getTenantId()), eq(entityId), eq(payload.getId()), eq(payload.getDayFrom()), eq(payload.getDayTo()))).thenReturn(0);
		when(mandatesDAO.checkPartyInEntity(eq(env.getTenantId()), eq(entityId), eq(payload.getId()), any(AbsoluteDate.class),any(AbsoluteDate.class))).thenReturn(1);
		when(internalConfigService.getBooleanValue(eq(env.getTenantId()), anyString())).thenReturn(false);

		assertThrows(PartyInEntityException.class, () -> mandatesService.addPartyToEntity(env, entityId, payload));
	}

	@Test
	void testAddPartyToEntityThrowsPastDateNotallowedException() {
		Long entityId = 165L;
		AddPartyPayload payload = AddPartyPayload.builder()
				.id("165466")
				.partyTypeCode("test")
				.dayFrom(now)
				.dayTo(infinite)
				.build();

		when(mandatesDAO.nextSequenceValEntitiesParties()).thenReturn(16494L);
		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(utilityService.getPartyTypeNTTByCode(eq(env), eq(payload.getPartyTypeCode()), any())).thenReturn(MyMockGenerator.getMockedPartyTypeNTT());
		when(mandatesDAO.checkExclusiveParty(eq(env.getTenantId()), eq(entityId), eq(payload.getId()), eq(payload.getDayFrom()), eq(payload.getDayTo()))).thenReturn(0);
		when(mandatesDAO.checkPartyInEntity(eq(env.getTenantId()), eq(entityId), eq(payload.getId()), any(AbsoluteDate.class),any(AbsoluteDate.class))).thenReturn(0);
		when(internalConfigService.getBooleanValue(eq(env.getTenantId()), anyString())).thenReturn(false);

		payload.setDayFrom(AbsoluteDate.of("20000101"));
		assertThrows(PastDateNotallowedException.class, () -> mandatesService.addPartyToEntity(env, entityId, payload));
	}

	@Test
	void TestAddUsersToEntity_Success() {
		Long entityId = 166576L;
		AddMandatorUserPayload payload = AddMandatorUserPayload.builder()
				.username("TestUsername")
				.role("ADMIN")
				.description("TestDescription")
				.build();

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(securityService.getUserId(eq(env), eq(payload.getUsername()), any(Operation.class))).thenReturn("TestUser");
		when(mandatesDAO.checkUserInEntity(eq(env.getTenantId()), eq(entityId), anyString())).thenReturn(0);
		when(mandatesDAO.nextSequenceValEntitiesUsers()).thenReturn(16496L);

		assertTrue(mandatesService.addUsersToEntity(env, entityId, payload, false, false));
		verify(utilityService).getEntityById(any(), any(), any(), any(), any());
		verify(utilityService).checkEnv(any());
	}

	@Test
	void TestAddUsersToEntityThrowsUserInEntityException() {
		Long entityId = 166576L;
		AddMandatorUserPayload payload = AddMandatorUserPayload.builder()
				.username("TestUsername")
				.role("ADMIN")
				.description("TestDescription")
				.build();

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(securityService.getUserId(eq(env), eq(payload.getUsername()), any(Operation.class))).thenReturn("TestUser");
		when(mandatesDAO.checkUserInEntity(eq(env.getTenantId()), eq(entityId), anyString())).thenReturn(1);
		when(mandatesDAO.nextSequenceValEntitiesUsers()).thenReturn(16496L);

		assertThrows(UserInEntityException.class, () -> mandatesService.addUsersToEntity(env, entityId, payload, false, false));
	}

	@Test
	void TestRemoveUserFromEntity_Success() {
		Long entityId = 44567L;
		String mandatorUserId = "TestUserId";

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.getUserById(eq(env.getTenantId()), eq(entityId), eq(mandatorUserId), anyInt(), anyInt())).thenReturn(MyMockGenerator.getMockedMandatorUserNTT());

		assertEquals(mandatorUserId, mandatesService.removeUserFromEntity(env, entityId, mandatorUserId, false, false));
		verify(utilityService).checkEnv(any());
	}

	@Test
	void TestRemoveUserFromEntityThrowsUserNotAssociatedWithEntityException() {
		Long entityId = 44567L;
		String mandatorUserId = "TestUserId";

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.getUserById(eq(env.getTenantId()), eq(entityId), eq(mandatorUserId), anyInt(), anyInt())).thenReturn(null);

		assertThrows(UserNotAssociatedWithEntityException.class, () -> mandatesService.removeUserFromEntity(env, entityId, mandatorUserId, false, false));
	}

	@Test
	void TestRemoveUserFromEntityThrowsUserNotAllowedExecption() {
		Long entityId = 44567L;
		String mandatorUserId = "TestUserId";

		MandatorUserNTT userNTT = MyMockGenerator.getMockedMandatorUserNTT();
		userNTT.setUser_id(env.getUser().getUserId());

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.getUserById(eq(env.getTenantId()), eq(entityId), eq(mandatorUserId), anyInt(), anyInt())).thenReturn(userNTT);

		assertThrows(UserNotAllowedExecption.class, () -> mandatesService.removeUserFromEntity(env, entityId, mandatorUserId, false, false));
	}

	@Test
	void TestUpdateEntityUser_Success() {
		Long entityId = 87387L;
		String mandatorUserId = "TEST/USER";
		UpdateEntityUserPayload payload = UpdateEntityUserPayload.builder()
				.role("USER")
				.description("test_description")
				.build();

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.getUserById(eq(env.getTenantId()), eq(entityId), eq(mandatorUserId), anyInt(), anyInt())).thenReturn(MyMockGenerator.getMockedMandatorUserNTT());

		assertTrue(mandatesService.updateEntityUser(env, entityId, mandatorUserId, payload, false, false));
		verify(utilityService).checkEnv(any());
		verify(utilityService).getEntityById(any(), any(), any(), any(), any());

	}

	@Test
	void TestUpdateEntityUserThrowsInvalidPayloadException() {
		Long entityId = 87387L;
		String mandatorUserId = "TEST/USER";
		UpdateEntityUserPayload payload = UpdateEntityUserPayload.builder().build();

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.getUserById(eq(env.getTenantId()), eq(entityId), eq(mandatorUserId), anyInt(), anyInt())).thenReturn(MyMockGenerator.getMockedMandatorUserNTT());

		assertThrows(InvalidPayloadException.class, () -> mandatesService.updateEntityUser(env, entityId, mandatorUserId, payload, false, false));

	}

	@Test
	void TestUpdateEntityUserThrowsUserNotAssociatedWithEntityException() {
		Long entityId = 87387L;
		String mandatorUserId = "TEST/USER";
		UpdateEntityUserPayload payload = UpdateEntityUserPayload.builder()
				.role("USER")
				.description("test_description")
				.build();

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.getUserById(eq(env.getTenantId()), eq(entityId), eq(mandatorUserId), anyInt(), anyInt())).thenReturn(null);

		assertThrows(UserNotAssociatedWithEntityException.class, () -> mandatesService.updateEntityUser(env, entityId, mandatorUserId, payload, false, false));

	}

	@Test
	void TestUpdateEntityUserThrowsEntityWithoutAdminExecption() {
		Long entityId = 87387L;
		String mandatorUserId = env.getUser().getUserId(); //a user trying to remove himself from entity
		UpdateEntityUserPayload payload = UpdateEntityUserPayload.builder()
				.role("USER")
				.description("test_description")
				.build();

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.getUserById(eq(env.getTenantId()), eq(entityId), eq(mandatorUserId), anyInt(), anyInt())).thenReturn(MyMockGenerator.getMockedMandatorUserNTT());

		assertThrows(EntityWithoutAdminExecption.class, () -> mandatesService.updateEntityUser(env, entityId, mandatorUserId, payload, false, false));
	}

	@Test
	void TestUpdateEntityUserThrowsNothingToUpdateException() {
		Long entityId = 87387L;
		String mandatorUserId = "TEST/USER";
		UpdateEntityUserPayload payload = UpdateEntityUserPayload.builder()
				.role("ADMIN")
				.description("TestDescription")
				.build();

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.getUserById(eq(env.getTenantId()), eq(entityId), eq(mandatorUserId), anyInt(), anyInt())).thenReturn(MyMockGenerator.getMockedMandatorUserNTT());

		assertThrows(NothingToUpdateException.class, () -> mandatesService.updateEntityUser(env, entityId, mandatorUserId, payload, false, false));
	}

	@Test
	void TestAddUserToSingleParty_Success() {
		Long entityId = 345767L;
		String partyId = "TestParty";
		AddMandatorUserPayload payload = AddMandatorUserPayload.builder()
				.username("TestUsername")
				.role("ADMIN")
				.description("TestDescription")
				.build();

		when(mandatesDAO.getSinglePartyEntityId(eq(env.getTenantId()), eq(partyId))).thenReturn(null);
		when(securityService.checkAdminPermission(eq(env), any(Operation.class))).thenReturn(true);
		when(typesDAO.getEntityTypeByCode(eq(env), anyString())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(utilityService.getPartyTypeNTTByCode(eq(env), anyString(), any())).thenReturn(MyMockGenerator.getMockedPartyTypeNTT());
		when(partyRegistryClientService.getName(eq(env), eq(partyId))).thenReturn("TestEntityName");
		when(entityDAO.nextSequenceValEntityId()).thenReturn(entityId);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(16587L);
		when(mandatesDAO.nextSequenceValEntitiesParties()).thenReturn(46756L);
		when(securityService.getUserId(eq(env), eq(payload.getUsername()), any(Operation.class))).thenReturn("TestUser");
		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.checkUserInEntity(eq(env.getTenantId()), eq(entityId), anyString())).thenReturn(0);
		when(mandatesDAO.nextSequenceValEntitiesUsers()).thenReturn(16496L);

		assertTrue(mandatesService.addUserToSingleParty(env, partyId, payload));
		verify(utilityService, atLeast(1)).checkEnv(any());
		verify(utilityService).getPartyTypeNTTByCode(any(), any(), any());
		verify(utilityService).getEntityTypeNTTByCode(any(), any(), any());
	}

	@Test
	void TestAddUserToSinglePartyThrowsUserNotAllowedExecption() {
		Long entityId = 345767L;
		String partyId = "TestParty";
		AddMandatorUserPayload payload = AddMandatorUserPayload.builder()
				.username("TestUsername")
				.role("ADMIN")
				.description("TestDescription")
				.build();

		when(mandatesDAO.getSinglePartyEntityId(eq(env.getTenantId()), eq(partyId))).thenReturn(null);
		when(securityService.checkAdminPermission(eq(env), any(Operation.class))).thenReturn(false);
		when(typesDAO.getEntityTypeByCode(eq(env), anyString())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(utilityService.getPartyTypeNTTByCode(eq(env), anyString(), any())).thenReturn(MyMockGenerator.getMockedPartyTypeNTT());
		when(partyRegistryClientService.getName(eq(env), eq(partyId))).thenReturn("TestEntityName");
		when(entityDAO.nextSequenceValEntityId()).thenReturn(entityId);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(16587L);
		when(mandatesDAO.nextSequenceValEntitiesParties()).thenReturn(46756L);
		when(securityService.getUserId(eq(env), eq(payload.getUsername()), any(Operation.class))).thenReturn("TestUser");
		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.checkUserInEntity(eq(env.getTenantId()), eq(entityId), anyString())).thenReturn(0);
		when(mandatesDAO.nextSequenceValEntitiesUsers()).thenReturn(16496L);

		assertThrows(UserNotAllowedExecption.class, () -> mandatesService.addUserToSingleParty(env, partyId, payload));
	}

	@Test
	void TestRemoveUserFromSingleParty_Success() {
		Long entityId = 16584L;
		String partyId = "TestPartyId";
		String mandatorUserId = "TestMandatorUserId";

		when(mandatesDAO.getSinglePartyEntityId(eq(env.getTenantId()), eq(partyId))).thenReturn(entityId);
		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.getUserById(eq(env.getTenantId()), eq(entityId), eq(mandatorUserId), anyInt(), anyInt())).thenReturn(MyMockGenerator.getMockedMandatorUserNTT());

		assertEquals(mandatorUserId, mandatesService.removeUserFromSingleParty(env, partyId, mandatorUserId));
		verify(utilityService, atLeast(1)).checkEnv(any());
	}

	@Test
	void TestRemoveUserFromSinglePartyThrowsUserNotAssociatedWithPartyException() {
		Long entityId = 16584L;
		String partyId = "TestPartyId";
		String mandatorUserId = "TestMandatorUserId";

		when(mandatesDAO.getSinglePartyEntityId(eq(env.getTenantId()), eq(partyId))).thenReturn(null);
		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.getUserById(eq(env.getTenantId()), eq(entityId), eq(mandatorUserId), anyInt(), anyInt())).thenReturn(MyMockGenerator.getMockedMandatorUserNTT());

		assertThrows(UserNotAssociatedWithPartyException.class, () -> mandatesService.removeUserFromSingleParty(env, partyId, mandatorUserId));
	}

	@Test
	void TestUpdateSinglePartyUser_Success() {
		Long entityId = 16584L;
		String partyId = "TestPartyId";
		String mandatorUserId = "TestMandatorUserId";

		UpdateEntityUserPayload payload = UpdateEntityUserPayload.builder()
				.role("USER")
				.description("test_description")
				.build();

		when(mandatesDAO.getSinglePartyEntityId(eq(env.getTenantId()), eq(partyId))).thenReturn(entityId);
		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.getUserById(eq(env.getTenantId()), eq(entityId), eq(mandatorUserId), anyInt(), anyInt())).thenReturn(MyMockGenerator.getMockedMandatorUserNTT());

		assertTrue(mandatesService.updateSinglePartyUser(env, partyId, mandatorUserId, payload));
		verify(utilityService, atLeast(1)).checkEnv(any());
	}

	@Test
	void TestUpdateSinglePartyUserThrowsUserNotAssociatedWithPartyException() {
		Long entityId = 16584L;
		String partyId = "TestPartyId";
		String mandatorUserId = "TestMandatorUserId";

		UpdateEntityUserPayload payload = UpdateEntityUserPayload.builder()
				.role("USER")
				.description("test_description")
				.build();

		when(mandatesDAO.getSinglePartyEntityId(eq(env.getTenantId()), eq(partyId))).thenReturn(null);
		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.getUserById(eq(env.getTenantId()), eq(entityId), eq(mandatorUserId), anyInt(), anyInt())).thenReturn(MyMockGenerator.getMockedMandatorUserNTT());

		assertThrows(UserNotAssociatedWithPartyException.class, () -> mandatesService.updateSinglePartyUser(env, partyId, mandatorUserId, payload));
	}
	
	@Test
	void TestGetUserByEntityId_Success() {
		Long entityId = 16584L;
		String mandatorUserId = "TestMandatorUserId";
		
		when(mandatesDAO.getUserById(eq(env.getTenantId()), eq(entityId), eq(mandatorUserId), eq(0), eq(0))).thenReturn(MyMockGenerator.getMockedMandatorUserNTT());
		
		assertEquals(MandatorUserMapper.INSTANCE.entityTODto(MyMockGenerator.getMockedMandatorUserNTT()), mandatesService.getUserByEntityId(env, entityId, mandatorUserId));
		verify(utilityService).checkEnv(any());
		verify(utilityService).getEntityById(any(), any(), any(), any(), any());
	}
	
	@Test
	void TestGetUserByEntityIdThrowsUserNotAssociatedWithEntityException() {
		Long entityId = 16584L;
		String mandatorUserId = "TestMandatorUserId";
		
		when(mandatesDAO.getUserById(eq(env.getTenantId()), eq(entityId), eq(mandatorUserId), eq(0), eq(0))).thenReturn(null);
		when(utilityService.getEntityById(eq(env), anyLong(), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		
		assertThrows(UserNotAssociatedWithEntityException.class, () -> mandatesService.getUserByEntityId(env, entityId, mandatorUserId));
	}
	
	@Test
	void TestGetEntityByMandateId_Success() {
		Long mandateId = 1564L;
		
		when(utilityService.getPartyWithEntityNTT(eq(env), eq(mandateId), any(Operation.class))).thenReturn(MyMockGenerator.getMockedPartyWithEntityNTT());
		
		assertEquals(PartyWithEntityMapper.INSTANCE.entityTODto(MyMockGenerator.getMockedPartyWithEntityNTT()), mandatesService.getEntityByMandateId(env, mandateId));
		verify(utilityService).checkEnv(any());
		verify(utilityService).getPartyWithEntityNTT(any(), any(), any());
	}
	
	@Test
	void TestCloseMandate_Success() {
		Long mandateId = 16574L;
		AnomaliesList anomaliesList = AnomaliesList.builder().anomalies_list(new ArrayList<>()).build();
		CloseDatePayload payload = CloseDatePayload.builder()
				.dayTo(null)
				.build();

		when(utilityService.getPartyWithEntityNTT(eq(env), eq(mandateId), any(Operation.class))).thenReturn(MyMockGenerator.getMockedPartyWithEntityNTT());
		when(mandatesDAO.checkPartyInEntity(eq(env.getTenantId()), anyLong(), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(1);
		when(mandatesDAO.checkExclusiveParty(eq(env.getTenantId()), anyLong(), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);
		when(anomaliesService.getPartyAnomalies(eq(env), anyString())).thenReturn(anomaliesList);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(16544L);
		when(utilityService.checkMandateStatus(eq(env), any(), any(), any())).thenReturn(MandateStatus.VALID);
		
		assertTrue(mandatesService.closeMandate(env, mandateId, payload));
		verify(utilityService, atLeast(1)).checkEnv(any());
		verify(utilityService).getPartyWithEntityNTT(any(), any(), any());
	}
	
	@Test
	void TestCloseMandateThrowsInvalidEndDateException() {
		Long mandateId = 16574L;
		AnomaliesList anomaliesList = AnomaliesList.builder().anomalies_list(new ArrayList<>()).build();
		CloseDatePayload payload = CloseDatePayload.builder()
				.dayTo(AbsoluteDate.of(LocalDate.now().minusDays(2)))
				.build();

		when(utilityService.getPartyWithEntityNTT(eq(env), eq(mandateId), any(Operation.class))).thenReturn(MyMockGenerator.getMockedPartyWithEntityNTT());
		when(mandatesDAO.checkExclusiveParty(eq(env.getTenantId()), anyLong(), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);
		when(anomaliesService.getPartyAnomalies(eq(env), anyString())).thenReturn(anomaliesList);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(16544L);
		when(utilityService.checkMandateStatus(eq(env), any(), any(), any())).thenReturn(MandateStatus.VALID);

		assertThrows(InvalidEndDateException.class, () -> mandatesService.closeMandate(env, mandateId, payload));
		
		payload.setDayTo(AbsoluteDate.of(LocalDate.now()));
		when(mandatesDAO.checkPartyInEntity(eq(env.getTenantId()), anyLong(), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(2);
		assertThrows(InvalidEndDateException.class, () -> mandatesService.closeMandate(env, mandateId, payload));
		
	}
	
//	@Test
//	void TestCloseMandateThrowsValidationDateException() {
//		Long mandateId = 16574L;
//		AnomaliesList anomaliesList = AnomaliesList.builder().anomalies_list(new ArrayList<>()).build();
//		CloseDatePayload payload = CloseDatePayload.builder()
//				.dayTo(AbsoluteDate.of(LocalDate.now()))
//				.build();
//		
//		PartyWithEntityNTT partyWithEntityNTT = MyMockGenerator.getMockedPartyWithEntityNTT();
//		partyWithEntityNTT.setDay_from(AbsoluteDate.of(LocalDate.now().plusDays(50)));
//
//		when(mandatesDAO.getPartyWithEntityByMandateId(eq(env), eq(mandateId))).thenReturn(partyWithEntityNTT);
//		when(mandatesDAO.checkExclusiveParty(eq(env.getTenantId()), anyLong(), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);
//		when(mandatesDAO.checkPartyInEntity(eq(env.getTenantId()), anyLong(), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(1);
//		when(anomaliesService.getPartyAnomalies(eq(env), anyString())).thenReturn(anomaliesList);
//		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(16544L);
//
//		assertThrows(ValidationDateException.class, () -> mandatesService.closeMandate(env, mandateId, payload));		
//	}
	
	@Test
	void TestCloseMandateThrowsValidationDatesConflictException() {
		Long mandateId = 16574L;
		AnomaliesList anomaliesList = AnomaliesList.builder().anomalies_list(new ArrayList<>()).build();
		CloseDatePayload payload = CloseDatePayload.builder()
				.dayTo(AbsoluteDate.of(LocalDate.now().plusDays(51)))
				.build();
		
		PartyWithEntityNTT partyWithEntityNTT = MyMockGenerator.getMockedPartyWithEntityNTT();
		partyWithEntityNTT.getEntity().setDay_to(AbsoluteDate.of(LocalDate.now().plusDays(50)));

		when(utilityService.getPartyWithEntityNTT(eq(env), anyLong(), any(Operation.class))).thenReturn(partyWithEntityNTT);
		when(utilityService.checkMandateStatus(eq(env), any(), any(), any())).thenReturn(MandateStatus.VALID);
		when(mandatesDAO.checkExclusiveParty(eq(env.getTenantId()), anyLong(), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);
		when(mandatesDAO.checkPartyInEntity(eq(env.getTenantId()), anyLong(), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(1);
		when(anomaliesService.getPartyAnomalies(eq(env), anyString())).thenReturn(anomaliesList);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(16544L);

		assertThrows(ValidationDatesConflictException.class, () -> mandatesService.closeMandate(env, mandateId, payload));		
	}
	
	@Test
	void TestCloseMandateThrowsCloseMandateDocumentNotFoundException() {
		Long mandateId = 16574L;
		AnomaliesList anomaliesList = AnomaliesList.builder().anomalies_list(new ArrayList<>()).build();
		CloseDatePayload payload = CloseDatePayload.builder()
				.dayTo(AbsoluteDate.of(LocalDate.now().plusDays(51)))
				.build();
		
		PartyWithEntityNTT partyWithEntityNTT = MyMockGenerator.getMockedPartyWithEntityNTT();
		partyWithEntityNTT.getEntity().setDay_to(AbsoluteDate.of(LocalDate.now().plusDays(50)));
		
		when(utilityService.getPartyWithEntityNTT(eq(env), anyLong(), any(Operation.class))).thenReturn(partyWithEntityNTT);
		when(utilityService.checkMandateStatus(eq(env), any(), any(), any())).thenReturn(MandateStatus.NOT_VALID);
		when(mandatesDAO.checkExclusiveParty(eq(env.getTenantId()), anyLong(), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);
		when(mandatesDAO.checkPartyInEntity(eq(env.getTenantId()), anyLong(), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(1);
		when(anomaliesService.getPartyAnomalies(eq(env), anyString())).thenReturn(anomaliesList);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(16544L);
		
		assertThrows(CloseMandateDocumentNotFoundException.class, () -> mandatesService.closeMandate(env, mandateId, payload));		
	}
	
	@Test
	void TestCloseMandateThrowsExtendMandateDocumentNotFoundException() {
		Long mandateId = 16574L;
		AnomaliesList anomaliesList = AnomaliesList.builder().anomalies_list(new ArrayList<>()).build();
		CloseDatePayload payload = CloseDatePayload.builder()
				.dayTo(AbsoluteDate.of(LocalDate.now().plusDays(60)))
				.build();
		
		PartyWithEntityNTT partyWithEntityNTT = MyMockGenerator.getMockedPartyWithEntityNTT();
		partyWithEntityNTT.setDay_to(AbsoluteDate.of(LocalDate.now().plusDays(50)));
		
		when(utilityService.getPartyWithEntityNTT(eq(env), anyLong(), any(Operation.class))).thenReturn(partyWithEntityNTT);
		when(utilityService.checkMandateStatus(eq(env), any(), any(), any())).thenReturn(MandateStatus.NOT_VALID);
		when(mandatesDAO.checkExclusiveParty(eq(env.getTenantId()), anyLong(), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);
		when(mandatesDAO.checkPartyInEntity(eq(env.getTenantId()), anyLong(), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(1);
		when(anomaliesService.getPartyAnomalies(eq(env), anyString())).thenReturn(anomaliesList);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(16544L);
		
		assertThrows(ExtendMandateDocumentNotFoundException.class, () -> mandatesService.closeMandate(env, mandateId, payload));		
	}
	
	@Test
	void TestCloseMandateThrowsExclusivePartyException() {
		Long mandateId = 16574L;
		AnomaliesList anomaliesList = AnomaliesList.builder().anomalies_list(new ArrayList<>()).build();
		CloseDatePayload payload = CloseDatePayload.builder()
				.dayTo(AbsoluteDate.of(LocalDate.now().plusDays(51)))
				.build();
		
		when(utilityService.getPartyWithEntityNTT(eq(env), eq(mandateId), any(Operation.class))).thenReturn(MyMockGenerator.getMockedPartyWithEntityNTT());
		when(mandatesDAO.checkExclusiveParty(eq(env.getTenantId()), anyLong(), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(2);
		when(mandatesDAO.checkPartyInEntity(eq(env.getTenantId()), anyLong(), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(1);
		when(anomaliesService.getPartyAnomalies(eq(env), anyString())).thenReturn(anomaliesList);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(16544L);
		when(utilityService.checkMandateStatus(eq(env), any(), any(), any())).thenReturn(MandateStatus.VALID);

		assertThrows(ExclusivePartyException.class, () -> mandatesService.closeMandate(env, mandateId, payload));		
	}

	// ----- getAllEntitiesByPartyId -----
	@Test
	void test_getAllEntitiesByPartyId_noFiltersOk() {
		String partyId = "555";
		PartyEntitySearchFilters filters = PartyEntitySearchFilters.builder().build();

		given(securityService.checkAdminPermission(env, Operation.GET_PARTY))
				.willReturn(true);
		given(internalConfigService.getIntegerValue(env.getTenantId(), InternalConfigKeys.HIERARCHICAL_INHERITANCE_LEVEL.getKey()))
				.willReturn(1);
		given(internalConfigService.getBooleanValue(env.getTenantId(), InternalConfigKeys.INHERIT_MANAGEMENT.getKey()))
				.willReturn(true);

		given(mandatesDAO.getAllEntitiesByPartyId(any(), any(), any(), any(), any()))
				.willReturn(new MockResultIterator<>(List.of(
						MyMockGenerator.getMockedPartyWithEntityNTT()
				)));
		doAnswer(i -> {
			Supplier<ResultIterator<PartyWithEntityNTT>> supplier = i.getArgument(0);

			List<Object> resList = new ArrayList<>();
			supplier.get().forEachRemaining(resList::add);

			return new InfiniteListResultsImpl<>(resList, null);
		}).when(mandatesDAO).infinite(any(), any(), anyInt());

		InfiniteListResults<PartyWithEntity> res = mandatesService.getAllEntitiesByPartyId(env, partyId, filters, null, null);

		assertThat(res).isNotNull()
				.extracting(InfiniteListResults::getRecords)
				.asList().hasSize(1);

		verify(mandatesDAO).getAllEntitiesByPartyId(eq(env), eq(1), eq(1), eq(1), any(Criteria.class));
		verifyNoInteractions(typesDAO);
	}

	@Test
	void test_getAllEntitiesByPartyId_withFiltersOk() {
		String partyId = "555";
		EntityTypeNTT entityType = MyMockGenerator.getMockedEntityTypeNTT();
		PartyEntitySearchFilters filters = PartyEntitySearchFilters.builder()
				.history(true)
				.entityTypeCode(entityType.getCode())
				.build();

		given(securityService.checkAdminPermission(env, Operation.GET_PARTY))
				.willReturn(false);
		given(internalConfigService.getIntegerValue(env.getTenantId(), InternalConfigKeys.HIERARCHICAL_INHERITANCE_LEVEL.getKey()))
				.willReturn(0);
		given(internalConfigService.getBooleanValue(env.getTenantId(), InternalConfigKeys.INHERIT_MANAGEMENT.getKey()))
				.willReturn(false);

		given(typesDAO.getEntityTypeByCode(any(), anyString()))
				.willReturn(entityType);

		given(mandatesDAO.getAllEntitiesByPartyId(any(), any(), any(), any(), any()))
				.willReturn(new MockResultIterator<>(List.of(
						MyMockGenerator.getMockedPartyWithEntityNTT()
				)));
		doAnswer(i -> {
			Supplier<ResultIterator<PartyWithEntityNTT>> supplier = i.getArgument(0);

			List<Object> resList = new ArrayList<>();
			supplier.get().forEachRemaining(resList::add);

			return new InfiniteListResultsImpl<>(resList, null);
		}).when(mandatesDAO).infinite(any(), any(), anyInt());

		InfiniteListResults<PartyWithEntity> res = mandatesService.getAllEntitiesByPartyId(env, partyId, filters, null, null);

		assertThat(res).isNotNull()
				.extracting(InfiniteListResults::getRecords)
				.asList().hasSize(1);

		verify(mandatesDAO).getAllEntitiesByPartyId(eq(env), eq(0), eq(0), eq(0), any(Criteria.class));
		verify(utilityService).getEntityTypeNTTByCode(eq(env), eq(entityType.getCode()), any());
	}

	private static class MockResultIterator<T> implements ResultIterator<T> {

		private final Iterator<T> it;
		private final StatementContext statementContext;

		public MockResultIterator(Collection<T> collection) {
			this.it = collection.iterator();
			this.statementContext = mock(StatementContext.class);
		}

		@Override
		public void close() {}

		@Override
		public StatementContext getContext() {
			return statementContext;
		}

		@Override
		public boolean hasNext() {
			return it.hasNext();
		}

		@Override
		public T next() {
			return it.next();
		}
	}
	
	@Test
	void TestRemovePartyFromEntity_Success() {
		Long mandateId = 12165L;
		AnomaliesList anomaliesList = AnomaliesList.builder().anomalies_list(new ArrayList<>()).build();
		when(utilityService.getPartyWithEntityNTT(eq(env), anyLong(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedPartyWithEntityNTT());
		when(utilityService.getMaxLevel(eq(env), any(), any(Operation.class))).thenReturn(AnomalyLevel.UNCATEGORIZED);
		when(anomaliesService.getPartyAnomalies(eq(env), anyString())).thenReturn(anomaliesList);

		assertEquals(mandateId, mandatesService.removeMandateFromEntity(env, mandateId));
		verify(utilityService, atLeast(1)).checkEnv(any());
		verify(utilityService).getPartyWithEntityNTT(any(), any(), any());
	}

	@Test
	void TestRemovePartyFromEntityThrowsPartyAnomalyException() {
		Long mandateId = 12165L;
		AnomaliesList anomaliesList = AnomaliesList.builder().anomalies_list(new ArrayList<>()).build();
		anomaliesList.getAnomalies_list().add(MyMockGenerator.getMockedAnomaly(null));
		when(mandatesDAO.getPartyWithEntityByMandateId(eq(env), eq(mandateId), any(), any(), any())).thenReturn(MyMockGenerator.getMockedPartyWithEntityNTT());
		when(utilityService.getMaxLevel(eq(env), any(), any(Operation.class))).thenReturn(AnomalyLevel.UNCATEGORIZED);
		when(utilityService.getPartyWithEntityNTT(eq(env), anyLong(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedPartyWithEntityNTT());
		when(anomaliesService.getPartyAnomalies(eq(env), anyString())).thenReturn(anomaliesList);
		when(internalConfigService.getBooleanValue(anyString(), anyString())).thenReturn(true);

		assertThrows(PartyAnomalyException.class, () -> mandatesService.removeMandateFromEntity(env, mandateId));
	}

}
