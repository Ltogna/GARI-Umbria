package com.abacogroup.partiesaclserver.resources.res;


import java.util.List;
import java.util.function.Function;

import com.abacogroup.jdbi.paging.InfiniteListResults;

import lombok.Data;

@Data
public class MyInfiniteListResult<T> implements InfiniteListResults<T>
{
	private String nextKey;
	private List<T> records;
	private int count;

	@Override
	public <M> InfiniteListResults<M> map(Function<T, M> mapper)
	{
		return null;
	}
}
