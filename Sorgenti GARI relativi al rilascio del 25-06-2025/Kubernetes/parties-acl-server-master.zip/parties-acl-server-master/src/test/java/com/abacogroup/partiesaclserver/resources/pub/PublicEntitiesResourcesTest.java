package com.abacogroup.partiesaclserver.resources.pub;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Base64;
import java.util.Set;

import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import org.junit.jupiter.api.Test;

import com.abacogroup.partiesaclserver.core.pub.EntitiesV1Service;
import com.abacogroup.partiesaclserver.resources.ResourcesTest;
import com.abacogroup.partiesaclserver.resources.pub.res.EntityV1;
import com.abacogroup.partiesaclserver.resources.res.pub.MyEntityV1;
import com.abacogroup.partiesaclserver.utils.MyMockGenerator;

import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.HttpHeaders;

class PublicEntitiesResourcesTest extends ResourcesTest{
	
	private static final EntitiesV1Service entitiesService = mock(EntitiesV1Service.class);
	private static final ResourceExtension EXT = createResourceExtension(new PublicEntitiesResources(entitiesService));
	
	@Test
	void getEntityByCodeTest(){
		EntityV1 entity = MyMockGenerator.getMockedEntityV1();
		
		String entityCode = "TestCode";
		
		when(entitiesService.getEntityByCode(any(ServiceSupportEnv.class), any(String.class), any(Boolean.class))).thenReturn(entity);
		
		MyEntityV1 res = EXT.target(PUBLIC_MOCK_BASE_URL_PATH + "/entities/" + entityCode)
				.queryParam("skipPermissionCheck", "true")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<>() {
				});
		
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyEntityV1>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}
}
