package com.abacogroup.partiesaclserver.core;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidEndDateException;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidPayloadException;
import com.abacogroup.partiesaclserver.core.exceptions.NothingToUpdateException;
import com.abacogroup.partiesaclserver.core.exceptions.PastDateNotallowedException;
import com.abacogroup.partiesaclserver.core.exceptions.ValidationDateException;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityCodeRequiredExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityCodeUniqueExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityExistsWithRegistryPartyIdExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityNameExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityWithExclusivePartyExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityWithParentExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityWithoutParentExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.HierarchialLoopExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.ParentNotValidExecption;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.ntt.EntityNTT;
import com.abacogroup.partiesaclserver.resources.req.CloseDatePayload;
import com.abacogroup.partiesaclserver.resources.req.CreateEntityPayload;
import com.abacogroup.partiesaclserver.resources.req.UpdateEntityPayload;
import com.abacogroup.partiesaclserver.resources.res.Entity;
import com.abacogroup.partiesaclserver.utils.MyMockGenerator;

class EntitiesServiceTest extends ServiceTest {

	private EntitiesService entitiesService;
	private ServiceSupportEnv env;

	@Override
	protected void createService() {
		entitiesService = new EntitiesService(daoContainer, securityService, revisionService, internalConfigService,
				utilityService, partyRegistryClientService, errorDescriptionsService);
	}

	@BeforeEach
	void mockServiceSupportEnv() {
		env = getMockServiceSupportEnv("UserTest", "UserTest", TENANT);
		when(utilityService.checkEnv(any(ServiceSupportEnv.class))).thenReturn(env);
		when(utilityService.getCurrentLocalDate()).thenReturn(LocalDate.now());
	}

	@Test
	void TestCreateEntity_Success() {
		Long entityId = 4647L;
		CreateEntityPayload payload = CreateEntityPayload.builder()
				.code("TestEntityCode")
				.description("Test")
				.entityTypeCode("TestEntityTypeCode")
				.registryPartyId("TestRegistryPartyId")
				.dayFrom(now)
				.build();

		when(entityDAO.nextSequenceValEntityId()).thenReturn(entityId);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(64564L);
		when(utilityService.getEntityTypeNTTByCode(eq(env), anyString(), any())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(internalConfigService.getBooleanValue(eq(env.getTenantId()), anyString())).thenReturn(false);
		when(entityDAO.checkEntityByRegistryPartyId(eq(env), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);
		when(entityDAO.checkEntityByEntityCode(eq(env.getTenantId()), anyString())).thenReturn(0);
		when(partyRegistryClientService.getName(eq(env), anyString())).thenReturn("TestEntityName");

		assertEquals(entityId, entitiesService.createEntity(env, payload));
		verify(utilityService).checkEnv(any());
		verify(utilityService).getEntityTypeNTTByCode(any(), any(), any());
	}

	@Test
	void TestCreateEntityThrowsEntityCodeRequiredExecption() {
		Long entityId = 4647L;
		CreateEntityPayload payload = CreateEntityPayload.builder()
				.description("Test")
				.entityTypeCode("TestEntityTypeCode")
				.registryPartyId("TestRegistryPartyId")
				.dayFrom(now)
				.build();

		when(entityDAO.nextSequenceValEntityId()).thenReturn(entityId);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(64564L);
		when(utilityService.getEntityTypeNTTByCode(eq(env), anyString(), any())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(internalConfigService.getBooleanValue(eq(env.getTenantId()), anyString())).thenReturn(false);
		when(entityDAO.checkEntityByRegistryPartyId(eq(env), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);
		when(entityDAO.checkEntityByEntityCode(eq(env.getTenantId()), anyString())).thenReturn(0);
		when(partyRegistryClientService.getName(eq(env), anyString())).thenReturn("TestEntityName");


		assertThrows(EntityCodeRequiredExecption.class, () -> entitiesService.createEntity(env, payload));
	}
	@Test
	void TestCreateEntityThrowsEntityCodeUniqueExecption() {
		Long entityId = 4647L;
		CreateEntityPayload payload = CreateEntityPayload.builder()
				.description("Test")
				.entityTypeCode("TestEntityTypeCode")
				.registryPartyId("TestRegistryPartyId")
				.dayFrom(now)
				.code("TestEntityCode")
				.build();

		when(entityDAO.nextSequenceValEntityId()).thenReturn(entityId);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(64564L);
		when(utilityService.getEntityTypeNTTByCode(eq(env), anyString(), any())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(internalConfigService.getBooleanValue(eq(env.getTenantId()), anyString())).thenReturn(false);
		when(entityDAO.checkEntityByRegistryPartyId(eq(env), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);
		when(entityDAO.checkEntityByEntityCode(eq(env.getTenantId()), anyString())).thenReturn(1);
		when(partyRegistryClientService.getName(eq(env), anyString())).thenReturn("TestEntityName");


		assertThrows(EntityCodeUniqueExecption.class, () -> entitiesService.createEntity(env, payload));
	}

	@Test
	void TestCreateEntityThrowsPastDateNotallowedException() {
		Long entityId = 4647L;
		CreateEntityPayload payload = CreateEntityPayload.builder()
				.code("TestEntityCode")
				.description("Test")
				.entityTypeCode("TestEntityTypeCode")
				.registryPartyId("TestRegistryPartyId")
				.dayFrom(AbsoluteDate.of(LocalDate.now().minusDays(1)))
				.build();

		when(entityDAO.nextSequenceValEntityId()).thenReturn(entityId);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(64564L);
		when(utilityService.getEntityTypeNTTByCode(eq(env), anyString(), any())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(internalConfigService.getBooleanValue(eq(env.getTenantId()), anyString())).thenReturn(false);
		when(entityDAO.checkEntityByRegistryPartyId(eq(env), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);
		when(entityDAO.checkEntityByEntityCode(eq(env.getTenantId()), anyString())).thenReturn(0);
		when(partyRegistryClientService.getName(eq(env), anyString())).thenReturn("TestEntityName");


		assertThrows(PastDateNotallowedException.class, () -> entitiesService.createEntity(env, payload));
	}

	@Test
	void TestCreateEntityThrowsValidationDateException() {
		Long entityId = 4647L;
		CreateEntityPayload payload = CreateEntityPayload.builder()
				.code("TestEntityCode")
				.description("Test")
				.entityTypeCode("TestEntityTypeCode")
				.registryPartyId("TestRegistryPartyId")
				.dayFrom(AbsoluteDate.of(LocalDate.now().plusDays(100)))
				.dayTo(AbsoluteDate.of(LocalDate.now().plusDays(50)))
				.build();

		when(entityDAO.nextSequenceValEntityId()).thenReturn(entityId);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(64564L);
		when(utilityService.getEntityTypeNTTByCode(eq(env), anyString(), any())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(internalConfigService.getBooleanValue(eq(env.getTenantId()), anyString())).thenReturn(false);
		when(entityDAO.checkEntityByRegistryPartyId(eq(env), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);
		when(entityDAO.checkEntityByEntityCode(eq(env.getTenantId()), anyString())).thenReturn(0);
		when(partyRegistryClientService.getName(eq(env), anyString())).thenReturn("TestEntityName");


		assertThrows(ValidationDateException.class, () -> entitiesService.createEntity(env, payload));
	}

	@Test
	void TestCreateEntityThrowsEntityExistsWithRegistryPartyIdExecption() {
		Long entityId = 4647L;
		CreateEntityPayload payload = CreateEntityPayload.builder()
				.code("TestEntityCode")
				.description("Test")
				.entityTypeCode("TestEntityTypeCode")
				.registryPartyId("TestRegistryPartyId")
				.dayFrom(now)
				.build();

		when(entityDAO.nextSequenceValEntityId()).thenReturn(entityId);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(64564L);
		when(utilityService.getEntityTypeNTTByCode(eq(env), anyString(), any())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(internalConfigService.getBooleanValue(eq(env.getTenantId()), anyString())).thenReturn(false);
		when(entityDAO.checkEntityByRegistryPartyId(eq(env), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(1);
		when(entityDAO.checkEntityByEntityCode(eq(env.getTenantId()), anyString())).thenReturn(0);
		when(partyRegistryClientService.getName(eq(env), anyString())).thenReturn("TestEntityName");


		assertThrows(EntityExistsWithRegistryPartyIdExecption.class, () -> entitiesService.createEntity(env, payload));
	}

	@Test
	void TestCreateEntityThrowsEntityNameExecption() {
		Long entityId = 4647L;
		CreateEntityPayload payload = CreateEntityPayload.builder()
				.code("TestEntityCode")
				.description("Test")
				.entityTypeCode("TestEntityTypeCode")
				.registryPartyId("TestRegistryPartyId")
				.dayFrom(now)
				.build();

		when(entityDAO.nextSequenceValEntityId()).thenReturn(entityId);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(64564L);
		when(utilityService.getEntityTypeNTTByCode(eq(env), anyString(), any())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(internalConfigService.getBooleanValue(eq(env.getTenantId()), anyString())).thenReturn(false);
		when(entityDAO.checkEntityByRegistryPartyId(eq(env), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);
		when(entityDAO.checkEntityByEntityCode(eq(env.getTenantId()), anyString())).thenReturn(0);
		when(partyRegistryClientService.getName(eq(env), anyString())).thenReturn(null);


		assertThrows(EntityNameExecption.class, () -> entitiesService.createEntity(env, payload));
	}

	@Test
	void TestGetEntity_Success() {
		Long entityId = 5567L;
		EntityNTT entityNTT = MyMockGenerator.getMockedEntityNTT();

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(entityNTT);
		when(mandatesDAO.getAllAdminByEntityId(eq(env), anyLong())).thenReturn(new ArrayList<>());

		assertEquals(Entity.class, entitiesService.getEntityById(env, entityId).getClass());
		assertEquals(AbsoluteDate.of("99991231"), entitiesService.getEntityById(env, entityId).getCloseDay());

		entityNTT.setDay_to(AbsoluteDate.of("20230228"));
		
		assertEquals(AbsoluteDate.of("20230301"), entitiesService.getEntityById(env, entityId).getCloseDay());
		verify(utilityService, atLeast(1)).getEntityById(any(), any(), any(), any(), any());
		verify(utilityService, atLeast(1)).checkEnv(any());
	}

	@Test
	void TestAddChildToParent_Success() {
		Long parentId = 16574L;
		Long childId = 7655L;

		EntityNTT parent = MyMockGenerator.getMockedEntityNTT();
		parent.setEntity_id(parentId);

		EntityNTT child = MyMockGenerator.getMockedEntityNTT();
		child.setEntity_id(childId);
		child.setParent_id(null);

		when(utilityService.getEntityById(eq(env), eq(parentId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(parent);
		when(utilityService.getEntityById(eq(env), eq(childId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(child);
		when(securityService.checkAdminPermission(eq(env), any(Operation.class))).thenReturn(false);
		when (entityDAO.getChild(eq(env), eq(childId))).thenReturn(null);
		
		assertTrue(entitiesService.addChildToParent(env, parentId, childId, false));	
		verify(utilityService, atLeast(2)).getEntityById(any(), any(), any(), any(), any());
		verify(utilityService).checkEnv(any());
	}

	@Test
	void TestAddChildToParentThrowsEntityWithParentExecption() {
		Long parentId = 16574L;
		Long childId = 7655L;

		EntityNTT parent = MyMockGenerator.getMockedEntityNTT();
		parent.setEntity_id(parentId);

		EntityNTT child = MyMockGenerator.getMockedEntityNTT();
		child.setEntity_id(childId);

		when(utilityService.getEntityById(eq(env), eq(parentId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(parent);
		when(utilityService.getEntityById(eq(env), eq(childId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(child);
		when(utilityService.getEntityById(eq(env), eq(1L), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(child);
		when(securityService.checkAdminPermission(eq(env), any(Operation.class))).thenReturn(false);
		when (entityDAO.getChild(eq(env), eq(childId))).thenReturn(null);

		assertThrows(EntityWithParentExecption.class, () -> entitiesService.addChildToParent(env, parentId, childId, false));	
	}

	@Test
	void TestAddChildToParentThrowsHierarchialLoopExecption() {
		Long parentId = 16574L;
		Long childId = 7655L;

		EntityNTT parent = MyMockGenerator.getMockedEntityNTT();
		parent.setEntity_id(parentId);
		parent.setPath("/" + childId + "/" + parentId + "/");

		EntityNTT child = MyMockGenerator.getMockedEntityNTT();
		child.setEntity_id(childId);
		child.setParent_id(null);

		when(utilityService.getEntityById(eq(env), eq(parentId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(parent);
		when(utilityService.getEntityById(eq(env), eq(childId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(child);
		when(securityService.checkAdminPermission(eq(env), any(Operation.class))).thenReturn(false);
		when (entityDAO.getChild(eq(env), eq(childId))).thenReturn(null);

		assertThrows(HierarchialLoopExecption.class, () -> entitiesService.addChildToParent(env, parentId, childId, false));	
	}

	@Test
	void TestRemoveChildFromParent_Success() {
		Long parentId = 16574L;
		Long childId = 7655L;

		EntityNTT parent = MyMockGenerator.getMockedEntityNTT();
		parent.setEntity_id(parentId);

		EntityNTT child = MyMockGenerator.getMockedEntityNTT();
		child.setEntity_id(childId);
		child.setParent_id(parentId);

		when(utilityService.getEntityById(eq(env), eq(childId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(child);
		when(utilityService.getEntityById(eq(env), eq(parentId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(parent);
		when(securityService.checkAdminPermission(eq(env), any(Operation.class))).thenReturn(false);
		when (entityDAO.getChild(eq(env), eq(childId))).thenReturn(null);

		assertTrue(entitiesService.removeChildFromParent(env, parentId, childId));	
		verify(utilityService, atLeast(1)).getEntityById(any(), any(), any(), any(), any());
		verify(utilityService).checkEnv(any());
	}

	@Test
	void TestRemoveChildFromParentThrowsEntityWithoutParentExecption() {
		Long parentId = 16574L;
		Long childId = 7655L;

		EntityNTT parent = MyMockGenerator.getMockedEntityNTT();
		parent.setEntity_id(parentId);

		EntityNTT child = MyMockGenerator.getMockedEntityNTT();
		child.setEntity_id(childId);
		child.setParent_id(null);

		when(utilityService.getEntityById(eq(env), eq(childId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(child);
		when(securityService.checkAdminPermission(eq(env), any(Operation.class))).thenReturn(false);
		when (entityDAO.getChild(eq(env), eq(childId))).thenReturn(null);

		assertThrows(EntityWithoutParentExecption.class, () -> entitiesService.removeChildFromParent(env, parentId, childId));	
	}

	@Test
	void TestRemoveChildFromParentThrowsParentNotValidExecption() {
		Long parentId = 16574L;
		Long childId = 7655L;

		EntityNTT parent = MyMockGenerator.getMockedEntityNTT();
		parent.setEntity_id(parentId);

		EntityNTT child = MyMockGenerator.getMockedEntityNTT();
		child.setEntity_id(childId);
		child.setParent_id(16465L);

		when(utilityService.getEntityById(eq(env), eq(childId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(child);
		when(utilityService.getEntityById(eq(env), eq(parentId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(parent);
		when(securityService.checkAdminPermission(eq(env), any(Operation.class))).thenReturn(false);
		when (entityDAO.getChild(eq(env), eq(childId))).thenReturn(null);

		assertThrows(ParentNotValidExecption.class, () -> entitiesService.removeChildFromParent(env, parentId, childId));	
	}

	@Test
	void TestUpdateEntity_Success() {
		Long entityId = 16574L;
		UpdateEntityPayload payload = UpdateEntityPayload.builder()
				.dayTo(AbsoluteDate.of("99981231"))
				.description("TestDescription")
				.entityTypeCode("TestType")
				.code("TestCode")
				.name("TestName")
				.registryPartyId("15468")
				.build();		

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.checkExclusivePartiesAfterDate(eq(env.getTenantId()), eq(entityId), any(AbsoluteDate.class))).thenReturn(0);
		when(utilityService.getEntityTypeNTTByCode(eq(env), anyString(), any())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(entityDAO.getPartyTypesByEntityId(eq(env.getTenantId()), eq(entityId))).thenReturn(MyMockGenerator.getMockedPartyTypeNTTList());
		when(typesDAO.checkEntityPartyTypeLink(anyLong(), anyLong())).thenReturn(1);
		when(entityDAO.checkEntityByRegistryPartyId(eq(env), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);

		assertTrue(entitiesService.updateEntity(env, entityId, payload));	
		verify(utilityService).checkEnv(any());
		verify(utilityService).getEntityById(any(), any(), any(), any(), any());
		verify(utilityService).getEntityTypeNTTByCode(any(), any(), any());
		verify(utilityService).checkEntityPartyTypeCompatibility(any(), any(), any(), any());
	}

	@Test
	void TestUpdateEntityThrowsInvalidPayloadException() {
		Long entityId = 16574L;
		UpdateEntityPayload payload = UpdateEntityPayload.builder().build();		

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.checkExclusivePartiesAfterDate(eq(env.getTenantId()), eq(entityId), any(AbsoluteDate.class))).thenReturn(0);
		when(typesDAO.getEntityTypeByCode(eq(env), anyString())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(entityDAO.getPartyTypesByEntityId(eq(env.getTenantId()), eq(entityId))).thenReturn(MyMockGenerator.getMockedPartyTypeNTTList());
		when(typesDAO.checkEntityPartyTypeLink(anyLong(), anyLong())).thenReturn(1);
		when(entityDAO.checkEntityByRegistryPartyId(eq(env), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);


		assertThrows(InvalidPayloadException.class, () -> entitiesService.updateEntity(env, entityId, payload));	
	}

	@Test
	void TestUpdateEntityThrowsInvalidEndDateException() {
		Long entityId = 16574L;
		UpdateEntityPayload payload = UpdateEntityPayload.builder()
				.dayTo(AbsoluteDate.of(LocalDate.now().minusDays(1)))
				.description("TestDescription")
				.entityTypeCode("TestType")
				.code("TestCode")
				.name("TestName")
				.registryPartyId("15468")
				.build();		

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.checkExclusivePartiesAfterDate(eq(env.getTenantId()), eq(entityId), any(AbsoluteDate.class))).thenReturn(0);
		when(typesDAO.getEntityTypeByCode(eq(env), anyString())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(entityDAO.getPartyTypesByEntityId(eq(env.getTenantId()), eq(entityId))).thenReturn(MyMockGenerator.getMockedPartyTypeNTTList());
		when(typesDAO.checkEntityPartyTypeLink(anyLong(), anyLong())).thenReturn(1);
		when(entityDAO.checkEntityByRegistryPartyId(eq(env), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);


		assertThrows(InvalidEndDateException.class, () -> entitiesService.updateEntity(env, entityId, payload));	
	}

	@Test
	void TestUpdateEntityThrowsEntityWithExclusivePartyExecption() {
		Long entityId = 2L;
		UpdateEntityPayload payload = UpdateEntityPayload.builder()
				.dayTo(AbsoluteDate.of("99981231"))
				.description("TestDescription")
				.entityTypeCode("TestType")
				.code("TestCode")
				.name("TestName")
				.registryPartyId("15468")
				.build();		

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.checkExclusivePartiesAfterDate(eq(env.getTenantId()), eq(entityId), any(AbsoluteDate.class))).thenReturn(1);
		when(utilityService.getEntityTypeNTTByCode(eq(env), anyString(), any())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(entityDAO.getPartyTypesByEntityId(eq(env.getTenantId()), eq(entityId))).thenReturn(MyMockGenerator.getMockedPartyTypeNTTList());
		when(entityDAO.checkEntityByRegistryPartyId(eq(env), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(1);


		assertThrows(EntityWithExclusivePartyExecption.class, () -> entitiesService.updateEntity(env, entityId, payload));	
	}

	//	@Test
	//	void TestUpdateEntityThrowsValidationDateException() {
	//		Long entityId = 16574L;
	//		UpdateEntityPayload payload = UpdateEntityPayload.builder()
	//				.dayTo(AbsoluteDate.of(LocalDate.now().plusDays(50)))
	//				.description("TestDescription")
	//				.entityTypeCode("TestType")
	//				.code("TestCode")
	//				.name("TestName")
	//				.registryPartyId("15468")
	//				.build();	
	//
	//		EntityNTT entityNTT = MyMockGenerator.getMockedEntityNTT();
	//		entityNTT.setDay_from(AbsoluteDate.of(LocalDate.now().plusDays(100)));
	//
	//		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(entityNTT);
	//		when(mandatesDAO.checkExclusivePartyAfterDate(eq(env.getTenantId()), eq(entityId), any(AbsoluteDate.class))).thenReturn(0);
	//		when(typesDAO.getEntityTypeByCode(eq(env), anyString())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
	//		when(entityDAO.getPartyTypesByEntityId(eq(env.getTenantId()), eq(entityId))).thenReturn(MyMockGenerator.getMockedPartyTypeNTTList());
	//		when(typesDAO.checkEntityPartyTypeLink(anyLong(), anyLong())).thenReturn(1);
	//		when(entityDAO.checkEntityByRegistryPartyId(eq(env), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);
	//		
	//
	//		assertThrows(ValidationDateException.class, () -> entitiesService.updateEntity(env, entityId, payload));	
	//	}

	@Test
	void TestUpdateEntityThrowsEntityCodeExecption() {
		Long entityId = 16574L;
		UpdateEntityPayload payload = UpdateEntityPayload.builder()
				.dayTo(AbsoluteDate.of("99981231"))
				.description("TestDescription")
				.entityTypeCode("TestType")
				.code("")
				.name("TestName")
				.registryPartyId("15468")
				.build();		

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.checkExclusivePartiesAfterDate(eq(env.getTenantId()), eq(entityId), any(AbsoluteDate.class))).thenReturn(0);
		when(utilityService.getEntityTypeNTTByCode(eq(env), anyString(), any())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(entityDAO.getPartyTypesByEntityId(eq(env.getTenantId()), eq(entityId))).thenReturn(MyMockGenerator.getMockedPartyTypeNTTList());
		when(typesDAO.checkEntityPartyTypeLink(anyLong(), anyLong())).thenReturn(1);
		when(entityDAO.checkEntityByRegistryPartyId(eq(env), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);


		assertThrows(EntityCodeRequiredExecption.class, () -> entitiesService.updateEntity(env, entityId, payload));	
	}

	@Test
	void TestUpdateEntityThrowsEntityExistsWithRegistryPartyIdExecption() {
		Long entityId = 16574L;
		UpdateEntityPayload payload = UpdateEntityPayload.builder()
				.dayTo(AbsoluteDate.of("99981231"))
				.description("TestDescription")
				.entityTypeCode("TestType")
				.code("TestCode")
				.name("TestName")
				.registryPartyId("15468")
				.build();		

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.checkExclusivePartiesAfterDate(eq(env.getTenantId()), eq(entityId), any(AbsoluteDate.class))).thenReturn(0);
		when(typesDAO.getEntityTypeByCode(eq(env), anyString())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(entityDAO.getPartyTypesByEntityId(eq(env.getTenantId()), eq(entityId))).thenReturn(MyMockGenerator.getMockedPartyTypeNTTList());
		when(typesDAO.checkEntityPartyTypeLink(anyLong(), anyLong())).thenReturn(1);
		when(entityDAO.checkEntityByRegistryPartyId(eq(env), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(1);


		assertThrows(EntityExistsWithRegistryPartyIdExecption.class, () -> entitiesService.updateEntity(env, entityId, payload));	
	}

	@Test
	void TestUpdateEntityThrowsNothingToUpdateException() {
		Long entityId = 16574L;
		UpdateEntityPayload payload = UpdateEntityPayload.builder()
				.name("TEST")
				.code("TestCode")
				.build();

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.checkExclusivePartiesAfterDate(eq(env.getTenantId()), eq(entityId), any(AbsoluteDate.class))).thenReturn(0);
		when(typesDAO.getEntityTypeByCode(eq(env), anyString())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(entityDAO.getPartyTypesByEntityId(eq(env.getTenantId()), eq(entityId))).thenReturn(MyMockGenerator.getMockedPartyTypeNTTList());
		when(typesDAO.checkEntityPartyTypeLink(anyLong(), anyLong())).thenReturn(1);
		when(entityDAO.checkEntityByRegistryPartyId(eq(env), anyString(), any(AbsoluteDate.class), any(AbsoluteDate.class))).thenReturn(0);


		assertThrows(NothingToUpdateException.class, () -> entitiesService.updateEntity(env, entityId, payload));	
	}

	@Test
	void TestCloseEntity_Success() {
		Long entityId = 16574L;
		CloseDatePayload payload = CloseDatePayload.builder()
				.dayTo(null)
				.build();

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.checkExclusivePartiesAfterDate(eq(env.getTenantId()), eq(entityId), any(AbsoluteDate.class))).thenReturn(0);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(16544L);

		assertTrue(entitiesService.closeEntity(env, entityId, payload));	
		verify(utilityService).checkEnv(any());
		verify(utilityService).getEntityById(any(), any(), any(), any(), any());
	}

	@Test	
	void TestCloseEntityThrowsInvalidEndDateException() {
		Long entityId = 16574L;
		CloseDatePayload payload = CloseDatePayload.builder()
				.dayTo(AbsoluteDate.of(LocalDate.now().minusDays(2)))
				.build();

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.checkExclusivePartiesAfterDate(eq(env.getTenantId()), eq(entityId), any(AbsoluteDate.class))).thenReturn(0);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(16544L);


		assertThrows(InvalidEndDateException.class, () -> entitiesService.closeEntity(env, entityId, payload));	
	}

	@Test
	void TestCloseEntityThrowsEntityWithExclusivePartyExecption() {
		Long entityId = 16574L;
		CloseDatePayload payload = CloseDatePayload.builder()
				.dayTo(null)
				.build();

		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(MyMockGenerator.getMockedEntityNTT());
		when(mandatesDAO.checkExclusivePartiesAfterDate(eq(env.getTenantId()), eq(entityId), any(AbsoluteDate.class))).thenReturn(1);
		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(16544L);


		assertThrows(EntityWithExclusivePartyExecption.class, () -> entitiesService.closeEntity(env, entityId, payload));	
	}

	//	@Test
	//	void TestCloseEntityThrowsValidationDateException() {
	//		Long entityId = 16574L;
	//		CloseDatePayload payload = CloseDatePayload.builder()
	//				.dayTo(AbsoluteDate.of(LocalDate.now()))
	//				.build();
	//		EntityNTT entityNTT = MyMockGenerator.getMockedEntityNTT();
	//		entityNTT.setDay_from(AbsoluteDate.of(LocalDate.now().plusDays(50)));
	//		
	//		when(utilityService.getEntityById(eq(env), eq(entityId), anyBoolean(), anyBoolean(), any(Operation.class))).thenReturn(entityNTT);
	//		when(mandatesDAO.checkExclusivePartyAfterDate(eq(env.getTenantId()), eq(entityId), any(AbsoluteDate.class))).thenReturn(0);
	//		when(entityDAO.nextSequenceValEntityDetailsId()).thenReturn(16544L);
	//		
	//
	//		assertThrows(ValidationDateException.class, () -> entitiesService.closeEntity(env, entityId, payload));	
	//	}
}
