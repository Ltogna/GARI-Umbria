package com.abacogroup.partiesaclserver.resources.res;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class MyParty {
	@Schema(description = "mandate id", type = "Integer", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Long mandateId;
	
	@Schema(description = "Party's id", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotBlank
	private String id;
	
	@Schema(description = "Party's type", implementation = PartyType.class, requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private MyPartyType partyType;
	
	@Schema(description = "Start validity date - format YYYYMMDD", type = "string", format = "YYYYMMDD", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private AbsoluteDate dayFrom;
	
	@Schema(description = "End validity date - format YYYYMMDD", type = "string", format = "YYYYMMDD")
	private AbsoluteDate dayTo;
}