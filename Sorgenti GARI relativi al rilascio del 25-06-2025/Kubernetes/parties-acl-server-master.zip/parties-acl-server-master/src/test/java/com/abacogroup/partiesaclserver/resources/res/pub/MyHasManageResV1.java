package com.abacogroup.partiesaclserver.resources.res.pub;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MyHasManageResV1 {
		private Boolean canRead;
}
