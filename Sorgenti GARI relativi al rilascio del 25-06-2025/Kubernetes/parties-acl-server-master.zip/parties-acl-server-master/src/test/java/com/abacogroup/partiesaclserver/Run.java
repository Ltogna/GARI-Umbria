package com.abacogroup.partiesaclserver;

public class Run {
    public static void main(String[] args) throws Exception {
        PartiesACLServerApplication.main(new String[] { "server", "config.yml" });
    }
}
