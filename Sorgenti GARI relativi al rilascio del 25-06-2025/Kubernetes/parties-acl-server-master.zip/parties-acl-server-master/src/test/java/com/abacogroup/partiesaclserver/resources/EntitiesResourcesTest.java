package com.abacogroup.partiesaclserver.resources;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partiesaclserver.core.EntitiesService;
import com.abacogroup.partiesaclserver.resources.req.CloseDatePayload;
import com.abacogroup.partiesaclserver.resources.req.CreateEntityPayload;
import com.abacogroup.partiesaclserver.resources.req.UpdateEntityPayload;
import com.abacogroup.partiesaclserver.resources.res.MyEntity;
import com.abacogroup.partiesaclserver.resources.res.MyInfiniteListResult;
import com.abacogroup.partiesaclserver.utils.MyMockGenerator;

import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.HttpHeaders;

class EntitiesResourcesTest extends ResourcesTest{
	private static EntitiesService entitiesService = mock(EntitiesService.class);
	private static final ResourceExtension EXT = createResourceExtension(new EntitiesResources(entitiesService));

	private static Long entityId = 1L;

	@Test
	void TestCreateEntity() {
		CreateEntityPayload payload = CreateEntityPayload.builder()
				.code("TestEntityCode")
				.description("Test")
				.entityTypeCode("TestEntityTypeCode")
				.registryPartyId("TestRegistryPartyId")
				.dayFrom(NOW)
				.build();
		when(entitiesService.createEntity(any(), any())).thenReturn(entityId);

		Long res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.post(Entity.json(payload), new GenericType<Long>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Long>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}

	@Test
	void TestGetEntities() {
		List<com.abacogroup.partiesaclserver.resources.res.Entity> entities = new ArrayList<>();
		entities.add(MyMockGenerator.getMockedEntity());
		InfiniteListResultsImpl<com.abacogroup.partiesaclserver.resources.res.Entity> ret = new InfiniteListResultsImpl<com.abacogroup.partiesaclserver.resources.res.Entity>(entities, null);

		when(entitiesService.getEntities(any(), any(), any(), any())).thenReturn(ret);

		MyInfiniteListResult<MyEntity> res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyInfiniteListResult<MyEntity>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyEntity>> violations = validator.validate(res.getRecords().get(0));
		assertEquals(0, violations.size());
	}

	@Test
	void TestGetEntityById() {
		com.abacogroup.partiesaclserver.resources.res.Entity entity = MyMockGenerator.getMockedEntity();

		when(entitiesService.getEntityById(any(), any())).thenReturn(entity);

		MyEntity res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities/" + entityId)
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyEntity>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyEntity>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}

	@Test
	void TestAddChildToParent() {
		Long parentId = 16574L;
		Long childId = 7655L;
		when(entitiesService.addChildToParent(any(), any(), any(), any())).thenReturn(true);

		Boolean res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities/" + parentId + "/children/" + childId)
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.put(Entity.json(""), new GenericType<Boolean>(){
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Boolean>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}

	@Test
	void TestRemoveChildFromParent() {
		Long parentId = 16574L;
		Long childId = 7655L;
		when(entitiesService.removeChildFromParent(any(), any(), any())).thenReturn(true);

		Boolean res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities/" + parentId + "/children/" + childId)
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.delete(new GenericType<Boolean>(){
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Boolean>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}

	@Test
	void TestUpdateEntity() {
		UpdateEntityPayload payload = UpdateEntityPayload.builder()
				.dayTo(AbsoluteDate.of("99981231"))
				.description("TestDescription")
				.entityTypeCode("TestType")
				.code("TestCode")
				.name("TestName")
				.registryPartyId("15468")
				.build();
		when(entitiesService.updateEntity(any(), any(), any())).thenReturn(true);

		Boolean res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities/" + entityId)
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.put(Entity.json(payload), new GenericType<Boolean>(){
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Boolean>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}

	@Test
	void TestGetAllChildrenByEntityId() {
		List<com.abacogroup.partiesaclserver.resources.res.Entity> entities = new ArrayList<>();
		entities.add(MyMockGenerator.getMockedEntity());
		InfiniteListResultsImpl<com.abacogroup.partiesaclserver.resources.res.Entity> ret = new InfiniteListResultsImpl<com.abacogroup.partiesaclserver.resources.res.Entity>(entities, null);

		when(entitiesService.getAllChildrenByParentId(any(), any(), any())).thenReturn(ret);

		MyInfiniteListResult<MyEntity> res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities/" + entityId + "/children")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyInfiniteListResult<MyEntity>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyEntity>> violations = validator.validate(res.getRecords().get(0));
		assertEquals(0, violations.size());
	}

	@Test
	void TestCloseMandate() {
		CloseDatePayload payload = CloseDatePayload.builder()
				.dayTo(NOW)
				.build();
		when(entitiesService.closeEntity(any(), any(), any())).thenReturn(true);

		Boolean res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities/" + entityId + "/closedate")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.post(Entity.json(payload), new GenericType<Boolean>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Boolean>> violations = validator.validate(res);
		assertEquals(0, violations.size());

	}

}
