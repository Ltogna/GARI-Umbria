package com.abacogroup.partiesaclserver.resources.res;

import java.util.List;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class MyEntity {
	
	@Schema(description = "Entity id", type = "integer", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Long id;
	
	@Schema(description = "Code of Entity", type = "string")
	private String code;
	
	@Schema(description = "Entity's name", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String name;
	
	@Schema(description = "Entity's type", implementation = EntityType.class, requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private MyEntityType entityType;
	
	@Schema(description = "Registry party id", type = "string")
	private String registryPartyId;
	
	@Schema(description = "Description of the entity", type = "string")
	private String description;
	
	@Schema(description = "Entity's parent Id", type = "integer")
	private Long parentId;
	
	@Schema(description = "Entity's tree path", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String path;
	
	@Schema(description = "Start validity date - format YYYYMMDD", type = "string", format = "YYYYMMDD", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private AbsoluteDate dayFrom;
	
	@Schema(description = "End validity date - format YYYYMMDD", type = "string", format = "YYYYMMDD")
	private AbsoluteDate dayTo;
	
	@ArraySchema(schema = @Schema(description = "List of admins of the Entity", implementation = MyMandatorUser.class))
	@Valid
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<String> adminUsers;
	
	@Schema(description = "Current user role, null if not associated", type = "string")
	private String currentUserRole;

}
