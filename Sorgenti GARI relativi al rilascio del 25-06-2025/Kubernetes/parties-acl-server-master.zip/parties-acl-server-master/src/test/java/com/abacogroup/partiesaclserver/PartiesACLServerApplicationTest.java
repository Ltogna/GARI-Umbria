package com.abacogroup.partiesaclserver;

import java.io.IOException;

import org.junit.jupiter.api.Test;

import io.dropwizard.core.setup.Environment;
import lombok.extern.slf4j.Slf4j;

@Slf4j
class PartiesACLServerApplicationTest extends PartiesACLServerApplication {
	@Override
	public void doRun(PartiesACLServerConfiguration configuration, Environment environment) throws IOException {
		log.debug("starting debug...");
		super.doRun(configuration, environment);
	}

	@Test
	void afterServicesUp() {
		log.debug("application started");
	}

}
