package com.abacogroup.partiesaclserver.resources;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;

import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partiesaclserver.core.MandatesService;
import com.abacogroup.partiesaclserver.resources.req.AddMandatorUserPayload;
import com.abacogroup.partiesaclserver.resources.req.AddPartyPayload;
import com.abacogroup.partiesaclserver.resources.req.CloseDatePayload;
import com.abacogroup.partiesaclserver.resources.req.UpdateEntityUserPayload;
import com.abacogroup.partiesaclserver.resources.res.MandatorUser;
import com.abacogroup.partiesaclserver.resources.res.MyEntity;
import com.abacogroup.partiesaclserver.resources.res.MyInfiniteListResult;
import com.abacogroup.partiesaclserver.resources.res.MyMandatorUser;
import com.abacogroup.partiesaclserver.resources.res.MyParty;
import com.abacogroup.partiesaclserver.resources.res.MyPartyWithEntity;
import com.abacogroup.partiesaclserver.resources.res.MyUserParty;
import com.abacogroup.partiesaclserver.resources.res.Party;
import com.abacogroup.partiesaclserver.resources.res.PartyWithEntity;
import com.abacogroup.partiesaclserver.resources.res.UserParty;
import com.abacogroup.partiesaclserver.utils.MyMockGenerator;

import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.HttpHeaders;

class MandatesResourcesTest extends ResourcesTest{
	private static MandatesService mandatesService = mock(MandatesService.class);
	private static final ResourceExtension EXT = createResourceExtension(new MandatesResources(mandatesService));

	private static Long entityId = 164465L;
	private static String partyId = "5678";
	private static Long mandateId = 48582L;
	private static String mandatorUserId = "TEST%2fUSER";

	@Test
	void TestAddPartyToEntity() {
		AddPartyPayload payload = AddPartyPayload.builder()
				.id("165466")
				.partyTypeCode("test")
				.dayFrom(NOW)
				.build();
		when(mandatesService.addPartyToEntity(any(), any(), any())).thenReturn(entityId);

		Long res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities/" + entityId + "/parties")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.post(Entity.json(payload), new GenericType<Long>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Long>> violations = validator.validate(res);
		assertEquals(0, violations.size());

	}

	@Test
	void TestAddUsersToEntity() {
		AddMandatorUserPayload payload = AddMandatorUserPayload.builder()
				.username("TestUsername")
				.role("ADMIN")
				.description("TestDescription")
				.build();
		when(mandatesService.addUsersToEntity(any(), any(), any(), any(), any())).thenReturn(true);

		Boolean res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities/" + entityId + "/users")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.post(Entity.json(payload), new GenericType<Boolean>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Boolean>> violations = validator.validate(res);
		assertEquals(0, violations.size());

	}

	@Test
	void TestRemoveUsersFromEntity() {
		when(mandatesService.removeUserFromEntity(any(), any(), any(), any(), any())).thenReturn("56498");

		String res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities/" + entityId + "/users/" + mandatorUserId)
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.delete(new GenericType<String>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<String>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}

	@Test
	void TestUpdateEntityUser() {
		UpdateEntityUserPayload payload = UpdateEntityUserPayload.builder()
				.role("USER")
				.description("test_description")
				.build();
		when(mandatesService.updateEntityUser(any(), any(), any(), any(), any(), any())).thenReturn(true);

		Boolean res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities/" + entityId + "/users/" + mandatorUserId)
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.put(Entity.json(payload), new GenericType<Boolean>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Boolean>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}

	@Test
	void TestAddUserToParty() {
		AddMandatorUserPayload payload = AddMandatorUserPayload.builder()
				.username("TestUsername")
				.role("ADMIN")
				.description("TestDescription")
				.build();
		when(mandatesService.addUserToSingleParty(any(), any(), any())).thenReturn(true);

		Boolean res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/parties/" + partyId + "/users")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.post(Entity.json(payload), new GenericType<Boolean>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Boolean>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}

	@Test
	void TestRemoveUsersFromParty() {
		when(mandatesService.removeUserFromSingleParty(any(), any(), any())).thenReturn(mandatorUserId);

		String res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/parties/" + entityId + "/users/" + mandatorUserId)
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.delete(new GenericType<String>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<String>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}

	@Test
	void TestUpdatePartyUser() {
		UpdateEntityUserPayload payload = UpdateEntityUserPayload.builder()
				.role("USER")
				.description("test_description")
				.build();
		when(mandatesService.updateSinglePartyUser(any(), any(), any(), any())).thenReturn(true);

		Boolean res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/parties/" + entityId + "/users/" + mandatorUserId)
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.put(Entity.json(payload), new GenericType<Boolean>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Boolean>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}

	@Test
	void TestGetAllPartiesByUserId() {
		List<UserParty> userParties = new ArrayList<>();
		userParties.add(MyMockGenerator.getMockedUserParty());
		InfiniteListResultsImpl<UserParty> ret = new InfiniteListResultsImpl<UserParty>(userParties, null);

		when(mandatesService.getAllPartiesByUserId(any(), any(), any(), any(), any())).thenReturn(ret);

		MyInfiniteListResult<MyUserParty> res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/users/" + mandatorUserId + "/parties")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyInfiniteListResult<MyUserParty>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyUserParty>> violations = validator.validate(res.getRecords().get(0));
		assertEquals(0, violations.size());
	}

	@Test
	void TestGetEntityByPartyId() {
		List<UserParty> userParties = new ArrayList<>();
		userParties.add(MyMockGenerator.getMockedUserParty());
		InfiniteListResultsImpl<UserParty> ret = new InfiniteListResultsImpl<UserParty>(userParties, null);

		when(mandatesService.getAllPartiesByUserId(any(), any(), any(), any(), any())).thenReturn(ret);

		MyInfiniteListResult<MyUserParty> res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/users/" + mandatorUserId + "/parties/" + partyId)
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyInfiniteListResult<MyUserParty>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyUserParty>> violations = validator.validate(res.getRecords().get(0));
		assertEquals(0, violations.size());
	}

	@Test
	void TestGetAllUsersByEntityId() {
		List<MandatorUser> mandatorUsers = new ArrayList<>();
		mandatorUsers.add(MyMockGenerator.getMockedMandatorUser());
		InfiniteListResultsImpl<MandatorUser> ret = new InfiniteListResultsImpl<MandatorUser>(mandatorUsers, null);

		when(mandatesService.getAllUsersByEntityId(any(), any(), any(), any())).thenReturn(ret);

		MyInfiniteListResult<MyMandatorUser> res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities/" + entityId + "/users")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyInfiniteListResult<MyMandatorUser>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyMandatorUser>> violations = validator.validate(res.getRecords().get(0));
		assertEquals(0, violations.size());
	}

	@Test
	void TestGetUserByEntityId() {
		MandatorUser mandatorUser = MyMockGenerator.getMockedMandatorUser();

		when(mandatesService.getUserByEntityId(any(), any(), any())).thenReturn(mandatorUser);

		MyMandatorUser res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities/" + entityId + "/users/" + mandatorUserId)
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyMandatorUser>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyMandatorUser>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}

	@Test
	void TestGetAllPartiesByEntityId() {
		List<Party> parties = new ArrayList<>();
		parties.add(MyMockGenerator.getMockedParty());
		InfiniteListResultsImpl<Party> ret = new InfiniteListResultsImpl<Party>(parties, null);

		when(mandatesService.getAllPartiesByEntityId(any(), any(), any(), any(), any(), any())).thenReturn(ret);

		MyInfiniteListResult<MyParty> res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities/" + entityId + "/parties")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyInfiniteListResult<MyParty>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyParty>> violations = validator.validate(res.getRecords().get(0));
		assertEquals(0, violations.size());
	}

	@Test
	void TestGetAllEntitiesByPartyId() {
		List<PartyWithEntity> list = new ArrayList<>();
		list.add(MyMockGenerator.getMockedPartyWithEntity());
		InfiniteListResultsImpl<PartyWithEntity> ret = new InfiniteListResultsImpl<PartyWithEntity>(list, null);

		when(mandatesService.getAllEntitiesByPartyId(any(), any(), any(), any(), any())).thenReturn(ret);

		MyInfiniteListResult<MyPartyWithEntity> res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/parties/" + partyId + "/entities")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyInfiniteListResult<MyPartyWithEntity>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyPartyWithEntity>> violations = validator.validate(res.getRecords().get(0));
		assertEquals(0, violations.size());
	}

	@Test
	void TestGetEntityByMandateId() {
		PartyWithEntity partyWithEntity = MyMockGenerator.getMockedPartyWithEntity();

		when(mandatesService.getEntityByMandateId(any(), any())).thenReturn(partyWithEntity);

		MyPartyWithEntity res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/mandates/" + mandateId)
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyPartyWithEntity>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyPartyWithEntity>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}

	@Test
	void TestGetEntitiesByUserId() {
		List<com.abacogroup.partiesaclserver.resources.res.Entity> list = new ArrayList<>();
		list.add(MyMockGenerator.getMockedEntity());
		InfiniteListResultsImpl<com.abacogroup.partiesaclserver.resources.res.Entity> ret = new InfiniteListResultsImpl<com.abacogroup.partiesaclserver.resources.res.Entity>(list, null);

		when(mandatesService.getEntitiesByUserId(any(), any(), any(), any())).thenReturn(ret);

		MyInfiniteListResult<MyEntity> res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/users/" + mandatorUserId + "/entities")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyInfiniteListResult<MyEntity>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyEntity>> violations = validator.validate(res.getRecords().get(0));
		assertEquals(0, violations.size());
	}

	@Test
	void TestCloseMandate() {
		CloseDatePayload payload = CloseDatePayload.builder()
				.dayTo(NOW)
				.build();
		when(mandatesService.closeMandate(any(), any(), any())).thenReturn(true);

		Boolean res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/mandates/" + mandateId+ "/closedate")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.post(Entity.json(payload), new GenericType<Boolean>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Boolean>> violations = validator.validate(res);
		assertEquals(0, violations.size());

	}
	
	@Test
	void TestRemoveMandateFromEntity() {
		when(mandatesService.removeMandateFromEntity(any(), any())).thenReturn(mandateId);

		Long res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/mandates/" + mandateId)
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.delete(new GenericType<Long>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Long>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}


}
