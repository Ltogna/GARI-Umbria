package com.abacogroup.partiesaclserver.utils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partiesaclserver.core.enums.AnomalyLevel;
import com.abacogroup.partiesaclserver.core.mappers.EntityTypeMapper;
import com.abacogroup.partiesaclserver.core.mappers.pub.EntityTypeV1ResponseMapper;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.ntt.EntityNTT;
import com.abacogroup.partiesaclserver.db.ntt.EntityTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.I18nNTT;
import com.abacogroup.partiesaclserver.db.ntt.MandatorUserNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyWithEntityNTT;
import com.abacogroup.partiesaclserver.resources.pub.res.EntityTypeV1;
import com.abacogroup.partiesaclserver.resources.pub.res.EntityV1;
import com.abacogroup.partiesaclserver.resources.res.Entity;
import com.abacogroup.partiesaclserver.resources.res.EntityType;
import com.abacogroup.partiesaclserver.resources.res.MandatorUser;
import com.abacogroup.partiesaclserver.resources.res.Party;
import com.abacogroup.partiesaclserver.resources.res.PartyType;
import com.abacogroup.partiesaclserver.resources.res.PartyWithEntity;
import com.abacogroup.partiesaclserver.resources.res.UserParty;
import com.abacogroup.partiesaclserver.resources.res.anomalies.Anomaly;
import com.abacogroup.partiesaclserver.resources.res.anomalies.AnomalyType;

public class MyMockGenerator {

	public static final AbsoluteDate now = AbsoluteDate.of(LocalDate.now());
	public static final AbsoluteDate infinte = AbsoluteDate.of("99991231");
	public static final String TENANT = "master";

	public static ServiceSupportEnv getMockServiceSupportEnv(String userName, String userId, String tenantId) {
		return ServiceSupportEnv.builder()
				.user(new User(userName, null, tenantId, userId))
				.tenantId(tenantId)
				.lang("en")
				.referenceDate(now)
				.build();		
	}


	public static EntityNTT getMockedEntityNTT() {
		return EntityNTT.builder()
				.pkid(1L)
				.name("TEST")
				.entity_id(2L)
				.parent_id(1L)
				.code("TestCode")
				.entity_type(getMockedEntityTypeNTT())
				.day_from(now)
				.day_to(infinte)
				.path("/5649/654/")
				.build();
	}

	public static List<EntityNTT> getMockedEntityNTTList() {
		List<EntityNTT> entityNTTs = new ArrayList<>();
		entityNTTs.add(MyMockGenerator.getMockedEntityNTT());
		return entityNTTs;
	}

	public static EntityTypeNTT getMockedEntityTypeNTT() {
		return EntityTypeNTT.builder()
				.id(1L)
				.code("test_code")
				.fl_entity_code_mandatory(1)
				.fl_single_relation(0)
				.fl_hidden(0)
				.build();
	}

	public static EntityType getMockedEntityType() {
		return EntityType.builder()
				.id(1L)
				.code("test_code")
				.flEntityCodeMandatory(true)
				.description("TestEntityTypeDescription")
				.build();
	}
	
	public static EntityTypeV1 getMockedEntityTypeV1() {
		return EntityTypeV1ResponseMapper.INSTANCE.toResponseV1(getMockedEntityType());
	}

	public static List<EntityTypeNTT> getMockedEntityTypeNTTList() {
		List<EntityTypeNTT> entityTypeNTTs = new ArrayList<>();
		entityTypeNTTs.add(MyMockGenerator.getMockedEntityTypeNTT());
		return entityTypeNTTs;
	}

	public static PartyTypeNTT getMockedPartyTypeNTT() {
		return PartyTypeNTT.builder()
				.id(1L)
				.code("test_code")
				.fl_exclusive(1)
				.fl_manage(1)
				.build();
	}

	public static PartyType getMockedPartyType() {
		return PartyType.builder()
				.id(1L)
				.code("test_code")
				.flExclusive(true)
				.flManage(true)
				.description("Test party type description")
				.build();
	}

	public static List<PartyTypeNTT> getMockedPartyTypeNTTList() {
		List<PartyTypeNTT> partyTypeNTTs = new ArrayList<>();
		partyTypeNTTs.add(MyMockGenerator.getMockedPartyTypeNTT());
		return partyTypeNTTs;
	}

	public static I18nNTT getMockedI18nNTT() {
		return I18nNTT.builder()
				.lang("it")
				.i18n_text("test_text")
				.build();
	}

	public static List<I18nNTT> getMockedI18nNTTList() {
		List<I18nNTT> i18nNTTs = new ArrayList<>();
		i18nNTTs.add(MyMockGenerator.getMockedI18nNTT());
		return i18nNTTs;
	}

	public static Party getMockedParty() {
		return Party.builder()
				.id("165466")
				.mandateId(784L)
				.partyType(getMockedPartyType())
				.dayFrom(now)
				.dayTo(infinte)
				.build();
	}

	public static PartyWithEntity getMockedPartyWithEntity() {
		return PartyWithEntity.builder()
				.id("165466")
				.mandateId(784L)
				.partyType(getMockedPartyType())
				.dayFrom(now)
				.dayTo(infinte)
				.editable(true)
				.entity(getMockedEntity())
				.build();
	}

	public static UserParty getMockedUserParty() {
		return UserParty.builder()
				.id("165466")
				.mandateId(784L)
				.partyType(getMockedPartyType())
				.dayFrom(now)
				.dayTo(infinte)
				.userId("TestUser")
				.userRole("ADMIN")
				.entityId(7648L)
				.build();
	}

	public static PartyNTT getMockedPartyNTT() {
		return PartyNTT.builder()
				.pkid(5498L)
				.day_from(now)
				.day_to(infinte)
				.mandate_id(1L)
				.entity_id(1L)
				.party_id("2")
				.party_type(getMockedPartyTypeNTT())
				.build();
	}

	public static MandatorUserNTT getMockedMandatorUserNTT() {
		return MandatorUserNTT.builder()
				.pkid(5498L)
				.entity_id(1L)
				.user_id("2")
				.role_code("ADMIN")
				.description("TestDescription")
				.build();
	}

	public static MandatorUser getMockedMandatorUser() {
		return MandatorUser.builder()
				.id("TestId")
				.role("ADMIN")
				.username("TestUsername")
				.description("TestDescription")
				.build();
	}

	public static List<MandatorUserNTT> getMockedMandatorUserNTTList() {
		List<MandatorUserNTT> entityUserNTTs = new ArrayList<>();
		entityUserNTTs.add(MyMockGenerator.getMockedMandatorUserNTT());
		return entityUserNTTs;
	}

	public static AnomalyType getMockedAnomalyType(AnomalyLevel level) {
		return AnomalyType.builder()
				.code("TestCode")
				.groupCode("TestGroupCode")
				.i18nCode("i18n")
				.level(level != null ? level : AnomalyLevel.DANGER)
				.build();
	}

	public static Anomaly getMockedAnomaly(AnomalyLevel level) {
		return Anomaly.builder()
				.entityCode("Test")
				.entityId("Test")
				.dt_insert(LocalDateTime.now())
				.type(MyMockGenerator.getMockedAnomalyType(level))
				.build();
	}	

	public static PartyWithEntityNTT getMockedPartyWithEntityNTT () {
		return PartyWithEntityNTT.builder()
				.entity(getMockedEntityNTT())
				.pkid(5498L)
				.day_from(now)
				.day_to(infinte)
				.mandate_id(1L)
				.entity_id(1L)
				.party_id("2")
				.party_type(getMockedPartyTypeNTT())
				.editable(true)
				.revocable(false)
				.build();
	}


	public static Entity getMockedEntity() {
		return Entity.builder()
				.name("TEST")
				.id(2L)
				.parentId(1L)
				.code("TestCode")
				.entityType(EntityTypeMapper.INSTANCE.entityTODto(getMockedEntityTypeNTT()))
				.dayFrom(now)
				.dayTo(infinte)
				.path("/5649/654/")
				.build();
	}



	// ##################################################################
	// ########    PUBLIC     ###########################################
	// ##################################################################
	
	
	
	public static EntityV1 getMockedEntityV1() {
		return EntityV1.builder()
				.name("TEST")
				.id(2L)
				.parentId(1L)
				.code("TestCode")
				.entityType(EntityTypeV1ResponseMapper.INSTANCE.toResponseV1(getMockedEntityType()))
				.dayFrom(now)
				.dayTo(infinte)
				.path("/5649/654/")
				.build();
	}
}