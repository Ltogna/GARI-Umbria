package com.abacogroup.partiesaclserver.resources.pub;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Base64;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;

import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partiesaclserver.core.pub.TypesV1Service;
import com.abacogroup.partiesaclserver.resources.ResourcesTest;
import com.abacogroup.partiesaclserver.resources.pub.res.EntityTypeV1;
import com.abacogroup.partiesaclserver.resources.res.MyInfiniteListResult;
import com.abacogroup.partiesaclserver.resources.res.pub.MyEntityTypeV1;
import com.abacogroup.partiesaclserver.utils.MyMockGenerator;

import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.HttpHeaders;

class PublicTypesResourcesTest extends ResourcesTest{
	
	private static TypesV1Service typesService = mock(TypesV1Service.class);
	private static final ResourceExtension EXT = createResourceExtension(new PublicTypesResources(typesService));
	
	@Test
	void getAllEntityTypesTest(){
		EntityTypeV1 entityType = MyMockGenerator.getMockedEntityTypeV1();
		InfiniteListResultsImpl<EntityTypeV1> ret = new InfiniteListResultsImpl<EntityTypeV1>(List.of(entityType), null);
		
		when(typesService.getAllEntityTypes(any(), any(), any())).thenReturn(ret);
		
		MyInfiniteListResult<MyEntityTypeV1> res = EXT.target(PUBLIC_MOCK_BASE_URL_PATH + "/entities/types")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyInfiniteListResult<MyEntityTypeV1>>() {
				});
		
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyInfiniteListResult<MyEntityTypeV1>>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}
}
