package com.abacogroup.partiesaclserver;

public class RunDbMigrate {
    public static void main(String[] args) throws Exception {
        PartiesACLServerApplication.main(new String[] { "db", "migrate", "config.yml" });
    }
}
