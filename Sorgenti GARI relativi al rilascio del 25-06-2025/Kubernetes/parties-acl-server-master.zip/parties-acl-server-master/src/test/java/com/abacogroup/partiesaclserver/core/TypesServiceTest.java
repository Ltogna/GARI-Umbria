package com.abacogroup.partiesaclserver.core;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.abacogroup.partiesaclserver.core.exceptions.InvalidPayloadException;
import com.abacogroup.partiesaclserver.core.exceptions.type.EntitiesWithTypeExecption;
import com.abacogroup.partiesaclserver.core.exceptions.type.PartiesWithTypeExecption;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeAlreadyExistExecption;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeNotFoundExecption;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.ntt.I18nNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyTypeNTT;
import com.abacogroup.partiesaclserver.resources.req.AddEntityTypePayload;
import com.abacogroup.partiesaclserver.resources.req.AddPartyTypePayload;
import com.abacogroup.partiesaclserver.resources.req.UpdatePartyTypePayload;
import com.abacogroup.partiesaclserver.utils.MyMockGenerator;

class TypesServiceTest extends ServiceTest {

	private ServiceSupportEnv env;
	private TypesService typesService;

	@Override
	protected void createService() {
		typesService = new TypesService(daoContainer, utilityService, errorDescriptionsService);
	}

	@BeforeEach
	void mockServiceSupportenv() {
		env = getMockServiceSupportEnv("UserTest", "UserTest", TENANT);
		when(utilityService.checkEnv(any(ServiceSupportEnv.class))).thenReturn(env);
	}

	@Test
	void testAddEntityTypesSuccess() {
		AddEntityTypePayload payload = AddEntityTypePayload.builder()
				.code("EntityTypeCode")
				.flEntityCodeMandatory(true)
				.flHidden(false)
				.flSingleRelation(false)
				.translations(new HashMap<>())
				.build();
		payload.getTranslations().put("en", "English");
		payload.getTranslations().put("it", "Italiano");

		when(typesDAO.getEntityTypeByCode(eq(env), eq(payload.getCode()))).thenReturn(null);
		when(utilityService.getCurrentLocalDate()).thenReturn(LocalDate.now());
		when(typesDAO.nextSequenceValEntityTypes()).thenReturn(1L);
		doNothing().when(typesDAO).useTransaction(any());
		doNothing().when(typesDAO).insertEntityType(eq(env.getTenantId()), any());
		doNothing().when(i18nDAO).insert(any());

		assertTrue(typesService.addEntityTypes(env, payload));
	}

	@Test
	void testAddEntityTypesThrowsTypeAlreadyExistExecption() {
		AddEntityTypePayload payload = AddEntityTypePayload.builder()
				.code("EntityTypeCode")
				.flEntityCodeMandatory(true)
				.flHidden(false)
				.flSingleRelation(false)
				.translations(new HashMap<>())
				.build();
		payload.getTranslations().put("en", "English");
		payload.getTranslations().put("it", "Italiano");

		when(typesDAO.getEntityTypeByCode(eq(env), any())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());

		assertThrows(TypeAlreadyExistExecption.class, () -> typesService.addEntityTypes(env, payload));
	}

	@Test
	void testDeleteEntitytype_Success() {
		Long typeId = 1L;

		when(typesDAO.getEntityTypeById(eq(env), eq(typeId))).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(typesDAO.countEntitiesByType(eq(env.getTenantId()), eq(typeId))).thenReturn(0L);
		doNothing().when(typesDAO).deleteEntityType(eq(env.getTenantId()), eq(typeId));
		doNothing().when(i18nDAO).deleteAllI18n(any(I18nNTT.class));

		assertTrue(typesService.deleteEntitytype(env, typeId));
	}

	@Test
	void testDeleteEntitytypeThrowsTypeNotFoundException() {
		Long typeId = 1L;

		when(typesDAO.getEntityTypeById(eq(env), eq(typeId))).thenReturn(null);

		assertThrows(TypeNotFoundExecption.class, () -> typesService.deleteEntitytype(env, typeId));
	}

	@Test
	void testDeleteEntitytypeThrowsEntitiesWithTypeException() {
		Long typeId = 1L;

		when(typesDAO.getEntityTypeById(eq(env), eq(typeId))).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(typesDAO.countEntitiesByType(eq(env.getTenantId()), eq(typeId))).thenReturn(1828L);

		assertThrows(EntitiesWithTypeExecption.class, () -> typesService.deleteEntitytype(env, typeId));
	}

	@Test
	void testgetEntityTypeById_Success() {
		Long typeId = 1L;
		when(typesDAO.getEntityTypeById(eq(env), eq(typeId))).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		when(i18nDAO.findAllI18nByPaclI18nKeys(any(I18nNTT.class))).thenReturn(new ArrayList<>());
		when(typesDAO.getPartyTypeWithEntityType(env, typeId)).thenReturn(MyMockGenerator.getMockedPartyTypeNTTList());

		assertEquals(typesService.getEntityTypeById(env, typeId, false).getId(), MyMockGenerator.getMockedEntityTypeNTT().getId());
		assertEquals(typesService.getEntityTypeById(env, typeId, true).getPartyTypesList().size(), MyMockGenerator.getMockedPartyTypeNTTList().size());
	}

	@Test
	void testgetEntityTypeByIdThrowsTypeNotFoundException() {
		Long typeId = 1L;

		when(typesDAO.getEntityTypeById(eq(env), eq(typeId))).thenReturn(null);

		assertThrows(TypeNotFoundExecption.class, () -> typesService.getEntityTypeById(env, typeId, true));
	}

	@Test
	void testAddPartyType_Success() {
		AddPartyTypePayload payload = AddPartyTypePayload.builder()
				.code("PartyTypeCode")
				.fl_exclusive(true)
				.fl_manage(true)
				.entityTypeCodes(new ArrayList<>())
				.translations(new HashMap<>())
				.build();
		payload.getTranslations().put("en", "English");
		payload.getTranslations().put("it", "Italiano");

		when(typesDAO.getPartyTypeByCode(eq(env), eq(payload.getCode()))).thenReturn(null);
		when(typesDAO.nextSequenceValPartyTypes()).thenReturn(1L);
		when(i18nDAO.findAllI18nByPaclI18nKeys(any(I18nNTT.class))).thenReturn(new ArrayList<>());

		Boolean res = typesService.addPartyType(env, payload);

		verify(errorDescriptionsService, never()).getTenantErrorDescriptions(any());

		assertTrue(res);
	}

	@Test
	void testAddPartyTypeThrowsTypeAlreadyExistException() {
		AddPartyTypePayload payload = AddPartyTypePayload.builder()
				.code("PartyTypeCode")
				.fl_exclusive(true)
				.fl_manage(true)
				.entityTypeCodes(new ArrayList<>())
				.translations(new HashMap<>())
				.build();
		payload.getTranslations().put("en", "English");
		payload.getTranslations().put("it", "Italiano");
		when(typesDAO.getPartyTypeByCode(eq(env), eq(payload.getCode()))).thenReturn(PartyTypeNTT.builder().build());

		assertThrows(TypeAlreadyExistExecption.class, () -> typesService.addPartyType(env, payload));
	}

	@Test
	void testAddPartyTypeThrowsTypeNotFoundExecption() {
		Long partyTypeId = 1L;
		List<String> entityTypeCodeList = new ArrayList<>();
		entityTypeCodeList.add("EntityTypeCode");
	
		when(typesDAO.getEntityTypeByCode(eq(env), anyString())).thenReturn(null);		

		assertThrows(TypeNotFoundExecption.class, () -> typesService.insertEntityPartyTypeLink(env, partyTypeId, entityTypeCodeList));
	}

	@Test
	void testDeletePartytype_Success() {
		Long partyTypeId = 1L;
		when(typesDAO.getPartyTypeById(eq(env), eq(partyTypeId))).thenReturn(MyMockGenerator.getMockedPartyTypeNTT());
		when(typesDAO.countPartiesByType(eq(env.getTenantId()), eq(partyTypeId))).thenReturn(0);

		assertEquals(true, typesService.deletePartytype(env, partyTypeId));
	}

	@Test
	void testDeletePartytypeThrowsTypeNotFoundExecption() {
		Long partyTypeId = 1L;
		when(typesDAO.getPartyTypeById(eq(env), eq(partyTypeId))).thenReturn(null);

		assertThrows(TypeNotFoundExecption.class, () -> typesService.deletePartytype(env, partyTypeId));
	}

	@Test
	void testDeletePartytypeThrowsPartiesWithTypeExecption() {
		Long partyTypeId = 1L;
		when(typesDAO.getPartyTypeById(eq(env), eq(partyTypeId))).thenReturn(MyMockGenerator.getMockedPartyTypeNTT());
		when(typesDAO.countPartiesByType(eq(env.getTenantId()), eq(partyTypeId))).thenReturn(56468);

		assertThrows(PartiesWithTypeExecption.class, () -> typesService.deletePartytype(env, partyTypeId));
	}

	@Test
	void testUpdatePartyType_Success() {
		Long partyTypeId = 1L;
		UpdatePartyTypePayload payload = UpdatePartyTypePayload.builder().fl_exclusive(false).build();

		when(typesDAO.getPartyTypeById(eq(env), eq(partyTypeId))).thenReturn(MyMockGenerator.getMockedPartyTypeNTT());

		assertEquals(true, typesService.updatePartyType(env, partyTypeId, payload));
	}

	@Test
	void testUpdatePartyTypeThrowsInvalidPayloadException() {
		Long partyTypeId = 1L;
		UpdatePartyTypePayload payload = UpdatePartyTypePayload.builder().build();

		assertThrows(InvalidPayloadException.class, () -> typesService.updatePartyType(env, partyTypeId, payload));
	}

	@Test
	void testUpdatePartyTypeThrowsTypeNotFoundExecption() {
		Long partyTypeId = 1L;
		UpdatePartyTypePayload payload = UpdatePartyTypePayload.builder().fl_exclusive(false).build();

		when(typesDAO.getPartyTypeById(eq(env), eq(partyTypeId))).thenReturn(null);

		assertThrows(TypeNotFoundExecption.class, () -> typesService.updatePartyType(env, partyTypeId, payload));
	}

	@Test
	void testGetPartyTypeById_Success() {
		Long partyTypeId = 15L;
		when(typesDAO.getPartyTypeById(eq(env), eq(partyTypeId))).thenReturn(MyMockGenerator.getMockedPartyTypeNTT());

		assertEquals(MyMockGenerator.getMockedPartyTypeNTT().getId(), typesService.getPartyTypeById(env, partyTypeId).getId());
	}
	
	@Test
	void testGetPartyTypeByIdThrowsTypeNotFoundExecption() {
		Long partyTypeId = 15L;
		when(typesDAO.getPartyTypeById(eq(env), eq(partyTypeId))).thenReturn(null);

		assertThrows(TypeNotFoundExecption.class, () -> typesService.getPartyTypeById(env, partyTypeId));
	}
}
