package com.abacogroup.partiesaclserver.resources.res.pub;


import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class MyPartyTypeV1 {

	@Schema(description = "Party type id", type = "integer", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Long id;
	
	@Schema(description = "Party type code", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String code;
	
	@Schema(description = "Party type code description", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String description;
	
	@Schema(description = "1: if exclusive", type = "boolean", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Boolean flExclusive;
	
	@Schema(description = "1: if manage", type = "boolean", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Boolean flManage;
	
}
