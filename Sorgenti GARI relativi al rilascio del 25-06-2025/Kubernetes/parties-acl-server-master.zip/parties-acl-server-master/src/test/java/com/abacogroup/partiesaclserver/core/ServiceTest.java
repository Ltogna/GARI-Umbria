package com.abacogroup.partiesaclserver.core;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partiesaclserver.PartiesACLServerConfiguration;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.dao.ConfigDAO;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.EntityDAO;
import com.abacogroup.partiesaclserver.db.dao.I18nDAO;
import com.abacogroup.partiesaclserver.db.dao.MandatesDAO;
import com.abacogroup.partiesaclserver.db.dao.RevisionHistoryDAO;
import com.abacogroup.partiesaclserver.db.dao.TypesDAO;

public abstract class ServiceTest {

	protected EntityDAO entityDAO;
	protected MandatesDAO mandatesDAO;
	protected RevisionHistoryDAO revisionHistoryDAO;
	protected TypesDAO typesDAO;
	protected I18nDAO i18nDAO;
	protected ConfigDAO configDAO;
	protected DAOContainer daoContainer;
	protected PartiesACLServerConfiguration config;

	protected InternalConfigService internalConfigService;
	protected PartyRegistryClientService partyRegistryClientService;
	protected ErrorDescriptionsService errorDescriptionsService;
	protected SecurityService securityService;
	protected AnomaliesService anomaliesService;
	protected UtilityService utilityService;
	protected RevisionService revisionService;

	protected final String TENANT = "master";
	protected final AbsoluteDate now = AbsoluteDate.of(LocalDate.now());
	protected final AbsoluteDate infinite = AbsoluteDate.of("99991231");
	
	@BeforeEach
	protected void init() {
		entityDAO = mock(EntityDAO.class);
		mandatesDAO = mock(MandatesDAO.class);
		revisionHistoryDAO = mock(RevisionHistoryDAO.class);
		typesDAO = mock(TypesDAO.class);
		i18nDAO = mock(I18nDAO.class);
		configDAO = mock(ConfigDAO.class);
		entityDAO = mock(EntityDAO.class);
		mandatesDAO = mock(MandatesDAO.class);
		daoContainer = DAOContainer.builder()
				.entityDAO(entityDAO)
				.mandatesDAO(mandatesDAO)
				.revisionHistoryDAO(revisionHistoryDAO)
				.typesDAO(typesDAO)
				.i18nDAO(i18nDAO)
				.configDAO(configDAO)
				.entityDAO(entityDAO)
				.build();

		config = mock(PartiesACLServerConfiguration.class);
		when(config.getApplicationConfigFile()).thenReturn("./application-config.yml");
		internalConfigService = mock(InternalConfigService.class);
		errorDescriptionsService = mock(ErrorDescriptionsService.class);
		partyRegistryClientService = mock(PartyRegistryClientService.class);
		securityService = mock(SecurityService.class);
		anomaliesService = mock(AnomaliesService.class);
		utilityService = mock(UtilityService.class);
		revisionService = mock(RevisionService.class);
		createService();
	}

	protected abstract void createService();

	protected ServiceSupportEnv getMockServiceSupportEnv(String userName, String userId, String tenantId) {
		return ServiceSupportEnv.builder()
				.user(new User(userName, null, tenantId, userId))
				.tenantId(tenantId)
				.lang("en")
				.referenceDate(now)
				.build();		
	}
}
