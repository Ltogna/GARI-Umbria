package com.abacogroup.partiesaclserver.core;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import com.abacogroup.partiesaclserver.core.exceptions.support.InternalConfigNotFoundException;

class SupportServiceTest extends ServiceTest {

	private SupportService supportService;

	@Override
	protected void createService() {
		supportService = new SupportService(internalConfigService, errorDescriptionsService);
	}

	@Test
	void getClientConfigTest() {
		assertThrows(InternalConfigNotFoundException.class, () -> supportService.getClientConfig(TENANT, "en", null));
	}

}
