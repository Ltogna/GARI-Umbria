package com.abacogroup.partiesaclserver.resources;

import java.time.LocalDate;

import org.glassfish.jersey.test.grizzly.GrizzlyWebTestContainerFactory;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partiesaclserver.resources.auth.MyBasicAuthenticator;
import com.abacogroup.partiesaclserver.resources.auth.MyBasicAuthorizer;

import io.dropwizard.auth.AuthDynamicFeature;
import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.auth.basic.BasicCredentialAuthFilter;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;

@ExtendWith(DropwizardExtensionsSupport.class)
public abstract class ResourcesTest {

	public static final String TENANT_ID = "master";
	protected static final String PRIVATE_MOCK_BASE_URL_PATH = "/" + TENANT_ID + "/api-priv/v1/parties-acl";
	protected static final String PUBLIC_MOCK_BASE_URL_PATH = "/" + TENANT_ID + "/public/v1/parties-acl";
	protected static final AbsoluteDate NOW = AbsoluteDate.of(LocalDate.now());
	protected static final AbsoluteDate INFINITE = AbsoluteDate.of("99991231");

	protected static ResourceExtension createResourceExtension(Object o) {
		return ResourceExtension.builder()
				.setTestContainerFactory(new GrizzlyWebTestContainerFactory())
				.addProvider(new AuthDynamicFeature(new BasicCredentialAuthFilter.Builder<User>()
						.setAuthenticator(new MyBasicAuthenticator())
						.setAuthorizer(new MyBasicAuthorizer())
						.buildAuthFilter()))
				.addProvider(new AuthValueFactoryProvider.Binder<>(User.class))
				.addResource(o)
				.build();
	}
}
