package com.abacogroup.partiesaclserver.resources;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;

import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.partiesaclserver.core.TypesService;
import com.abacogroup.partiesaclserver.resources.req.AddEntityTypePayload;
import com.abacogroup.partiesaclserver.resources.req.AddPartyTypePayload;
import com.abacogroup.partiesaclserver.resources.req.UpdatePartyTypePayload;
import com.abacogroup.partiesaclserver.resources.res.EntityType;
import com.abacogroup.partiesaclserver.resources.res.MyEntityType;
import com.abacogroup.partiesaclserver.resources.res.MyInfiniteListResult;
import com.abacogroup.partiesaclserver.resources.res.MyPartyType;
import com.abacogroup.partiesaclserver.resources.res.PartyType;
import com.abacogroup.partiesaclserver.utils.MyMockGenerator;

import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.HttpHeaders;

class TypesResourcesTest extends ResourcesTest{
	private static TypesService typesService = mock(TypesService.class);
	private static final ResourceExtension EXT = createResourceExtension(new TypesResources(typesService));

	private static Long entityTypeId = 1L;
	private static Long partyTypeId = 1L;

	@Test
	void TestAddEntitytype() {
		AddEntityTypePayload payload = AddEntityTypePayload.builder()
				.code("EntityTypeCode")
				.flEntityCodeMandatory(true)
				.flHidden(false)
				.flSingleRelation(false)
				.translations(new HashMap<>())
				.build();
		payload.getTranslations().put("en", "English");
		payload.getTranslations().put("it", "Italiano");
		when(typesService.addEntityTypes(any(), any())).thenReturn(true);

		Boolean res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities/types")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.post(Entity.json(payload), new GenericType<Boolean>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Boolean>> violations = validator.validate(res);
		assertEquals(0, violations.size());

	}

	@Test
	void TestDeleteEntityType() {
		when(typesService.deleteEntitytype(any(), any())).thenReturn(true);

		Boolean res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities/types/" + entityTypeId)
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.delete(new GenericType<Boolean>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Boolean>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}
	
	@Test
	void TestGetAllEntityTypes() {
		List<EntityType> list = new ArrayList<>();
		list.add(MyMockGenerator.getMockedEntityType());
		InfiniteListResultsImpl<EntityType> ret = new InfiniteListResultsImpl<EntityType>(list, null);
		
		when(typesService.getAllEntityTypes(any(), any(), any(), any())).thenReturn(ret);

		MyInfiniteListResult<MyEntityType> res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities/types")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyInfiniteListResult<MyEntityType>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyEntityType>> violations = validator.validate(res.getRecords().get(0));
		assertEquals(0, violations.size());
	}
	
	@Test
	void TestGetEntityTypeById() {
		EntityType entityType = MyMockGenerator.getMockedEntityType();
		
		when(typesService.getEntityTypeById(any(), any(), any())).thenReturn(entityType);

		MyEntityType res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/entities/types/" + entityTypeId)
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyEntityType>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyEntityType>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}
	
	@Test
	void TestAddPartyType() {
		AddPartyTypePayload payload = AddPartyTypePayload.builder()
				.code("PartyTypeCode")
				.fl_exclusive(true)
				.fl_manage(true)
				.entityTypeCodes(new ArrayList<>())
				.translations(new HashMap<>())
				.build();
		payload.getTranslations().put("en", "English");
		payload.getTranslations().put("it", "Italiano");
		
		when(typesService.addPartyType(any(), any())).thenReturn(true);
		
		Boolean res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/parties/types")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.post(Entity.json(payload), new GenericType<Boolean>(){
					
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Boolean>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}
	
	@Test
	void TestDeletePartytype() {
		when(typesService.deletePartytype(any(), any())).thenReturn(true);

		Boolean res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/parties/types/" + partyTypeId)
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.delete(new GenericType<Boolean>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Boolean>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}

	@Test
	void updatePartyTypeTest() {
		UpdatePartyTypePayload payload = UpdatePartyTypePayload.builder().fl_exclusive(false).build();
		
		when(typesService.updatePartyType(any(), any(), any())).thenReturn(true);
		
		Boolean res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/parties/types/" + partyTypeId)
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.put(Entity.json(payload), new GenericType<Boolean>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Boolean>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}
	
	@Test
	void TestGetAllPartyTypes() {
		List<PartyType> list = new ArrayList<>();
		list.add(MyMockGenerator.getMockedPartyType());
		InfiniteListResultsImpl<PartyType> ret = new InfiniteListResultsImpl<PartyType>(list, null);
		
		when(typesService.getAllPartyTypes(any(), any(), any())).thenReturn(ret);

		MyInfiniteListResult<MyPartyType> res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/parties/types")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyInfiniteListResult<MyPartyType>>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyPartyType>> violations = validator.validate(res.getRecords().get(0));
		assertEquals(0, violations.size());
	}
	
	@Test
	void TestGetPartyTypeById() {
		PartyType partyType = MyMockGenerator.getMockedPartyType();
		
		when(typesService.getPartyTypeById(any(), any())).thenReturn(partyType);

		MyPartyType res = EXT.target(PRIVATE_MOCK_BASE_URL_PATH + "/parties/types/" + partyTypeId)
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyPartyType>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyPartyType>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}

	
}
