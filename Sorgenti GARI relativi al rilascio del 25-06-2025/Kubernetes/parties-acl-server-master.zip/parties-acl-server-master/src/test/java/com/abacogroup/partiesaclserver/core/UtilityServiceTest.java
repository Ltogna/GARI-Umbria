package com.abacogroup.partiesaclserver.core;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partiesaclserver.core.enums.AnomalyLevel;
import com.abacogroup.partiesaclserver.core.enums.InternalConfigKeys;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.InternalConfigException;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidRequestException;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityNotFoundExecption;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.MandateNotFoundException;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeNotCompatibleExecption;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeNotFoundExecption;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.ntt.EntityTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyTypeNTT;
import com.abacogroup.partiesaclserver.utils.MyMockGenerator;

class UtilityServiceTest extends ServiceTest {

	private ServiceSupportEnv env;
	private UtilityService utilityService;

	@Override
	protected void createService() {
		utilityService = new UtilityService(daoContainer, securityService, revisionService, internalConfigService, errorDescriptionsService);
	}

	@BeforeEach
	void mockServiceSupportenv() {
		env = getMockServiceSupportEnv("UserTest", "UserTest", TENANT);
	}

	@Test
	void testGetEntityById_Success() {
		Long entityId = 156L;
		
		when(securityService.checkAdminPermission(eq(env), any(Operation.class))).thenReturn(false);
		when(entityDAO.getEntityByID(eq(env), eq(entityId), any(), anyInt(), anyInt(), anyInt())).thenReturn(MyMockGenerator.getMockedEntityNTT());

		assertEquals(MyMockGenerator.getMockedEntityNTT(), utilityService.getEntityById(env, entityId, false, false, Operation.GET_ENTITY));
	}

	@Test
	void testGetEntityByIdThrowsEntityNotFoundExecption() {
		Long entityId = 156L;
		
		when(securityService.checkAdminPermission(eq(env), any(Operation.class))).thenReturn(true);
		when(entityDAO.getEntityByID(eq(env), eq(entityId), any(), anyInt(), anyInt(), anyInt())).thenReturn(null);

		assertThrows(EntityNotFoundExecption.class, () -> utilityService.getEntityById(env, entityId, false, false, Operation.GET_ENTITY));
	}
	
	@Test
	void testGetPartyWithEntityNTT_Success() {
		Long mandateId = 156L;
		
		when(mandatesDAO.getPartyWithEntityByMandateId(eq(env), eq(mandateId), any(), any(), any())).thenReturn(MyMockGenerator.getMockedPartyWithEntityNTT());

		assertEquals(MyMockGenerator.getMockedPartyWithEntityNTT(), utilityService.getPartyWithEntityNTT(env, mandateId, Operation.GET_ENTITY));
	}

	@Test
	void testGetPartyWithEntityNTTThrowsMandateNotFoundException() {
		Long mandateId = 156L;
		
		when(mandatesDAO.getPartyWithEntityByMandateId(eq(env), eq(mandateId), any(), any(), any())).thenReturn(null);

		assertThrows(MandateNotFoundException.class, () -> utilityService.getPartyWithEntityNTT(env, mandateId, Operation.GET_ENTITY));
	}
	
	@Test
	void testGetMaxLevel_Success() {
		String level = "WARN";
		when(internalConfigService.getStringValue(eq(env.getTenantId()), eq(InternalConfigKeys.MAX_ANOMALY_LEVEL_ALLOWED_EDIT_PARTY.getKey()))).thenReturn(level);
		
		assertEquals(AnomalyLevel.WARN, utilityService.getMaxLevel(env, InternalConfigKeys.MAX_ANOMALY_LEVEL_ALLOWED_EDIT_PARTY, Operation.REMOVE_MANDATE));
		
	}
	
	@Test
	void testGetMaxLevelThrowsInternalConfigException() {
		String level = "TEST";
		when(internalConfigService.getStringValue(eq(env.getTenantId()), eq(InternalConfigKeys.MAX_ANOMALY_LEVEL_ALLOWED_EDIT_PARTY.getKey()))).thenReturn(level);

		assertThrows(InternalConfigException.class, () -> utilityService.getMaxLevel(env, InternalConfigKeys.MAX_ANOMALY_LEVEL_ALLOWED_EDIT_PARTY, Operation.REMOVE_MANDATE));
	}
	
	@Test
	void testCheckEnv_Success() {
		when(entityDAO.getCurrentTimestamp()).thenReturn(LocalDateTime.now());
		assertEquals(AbsoluteDate.of(LocalDateTime.now()), utilityService.checkEnv(env).getReferenceDate());
	}
	
	@Test
	void testCheckEnvThrowsInvalidRequestException() {
		assertThrows(InvalidRequestException.class, () -> utilityService.checkEnv(null));
	}
	
	@Test
	void testGetPartyTypeNTTByCode_Success() {
		when(typesDAO.getPartyTypeByCode(any(), any())).thenReturn(MyMockGenerator.getMockedPartyTypeNTT());
		assertEquals(MyMockGenerator.getMockedPartyTypeNTT(), utilityService.getPartyTypeNTTByCode(env, "test_code", Operation.ADD_MANDATE));
	}
	
	@Test
	void testGetPartyTypeNTTByCodeThrowsTypeNotFoundExecption() {

		when(typesDAO.getPartyTypeByCode(any(), any())).thenReturn(null);
		assertThrows(TypeNotFoundExecption.class, () -> utilityService.getPartyTypeNTTByCode(env, "test_code", Operation.ADD_MANDATE));
	}
	
	@Test
	void testGetEntityTypeNTTByCode_Success() {
		when(typesDAO.getEntityTypeByCode(any(), any())).thenReturn(MyMockGenerator.getMockedEntityTypeNTT());
		assertEquals(MyMockGenerator.getMockedEntityTypeNTT(), utilityService.getEntityTypeNTTByCode(env, "test_code", Operation.ADD_MANDATE));
	}
	
	@Test
	void testGetEntityTypeNTTByCodeThrowsTypeNotFoundExecption() {
		when(typesDAO.getEntityTypeByCode(any(), any())).thenReturn(null);
		assertThrows(TypeNotFoundExecption.class, () -> utilityService.getEntityTypeNTTByCode(env, "test_code", Operation.ADD_MANDATE));
	}
	
	@Test
	void testCheckEntityPartyTypeCompatibilityThrowsTypeNotCompatibleExecption() {
		PartyTypeNTT partyTypeNTT = MyMockGenerator.getMockedPartyTypeNTT();
		EntityTypeNTT entityTypeNTT = MyMockGenerator.getMockedEntityTypeNTT();
		when(typesDAO.checkEntityPartyTypeLink(any(), any())).thenReturn(0);
		assertThrows(TypeNotCompatibleExecption.class, () -> utilityService.checkEntityPartyTypeCompatibility(env, partyTypeNTT, entityTypeNTT, Operation.ADD_MANDATE));
	}
}
