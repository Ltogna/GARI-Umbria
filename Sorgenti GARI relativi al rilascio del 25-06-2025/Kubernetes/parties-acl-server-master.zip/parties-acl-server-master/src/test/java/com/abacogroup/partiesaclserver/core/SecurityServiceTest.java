package com.abacogroup.partiesaclserver.core;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.security.UserNotAllowedExecption;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.ntt.MandatorUserNTT;
import com.abacogroup.partiesaclserver.utils.MyMockGenerator;

class SecurityServiceTest extends ServiceTest {

	private ServiceSupportEnv env;
	private SecurityService securityService;

	@Override
	protected void createService() {
		securityService = new SecurityService(daoContainer, errorDescriptionsService, null, null);
	}

	@BeforeEach
	void mockServiceSupportenv() {
		env = getMockServiceSupportEnv("UserTest", "UserTest", TENANT);
	}

	@Test
	void testCheckPermission_Success() {
		Long entityId = 1465L;
		when(mandatesDAO.getParentHierarchy(eq(env.getTenantId()), eq(entityId), eq(env.getUser().getUserId()), anyInt(), anyInt())).thenReturn(List.of(MyMockGenerator.getMockedMandatorUserNTT()));

		securityService.checkPermission(env, entityId, true, Operation.ADD_MANDATE, ErrorField.MANDATE);
	}

	@Test
	void testCheckPermissionThrowsUserNotAllowedExecption() {
		Long entityId = 1465L;
		env = getMockServiceSupportEnv("UserTest", null, TENANT);
		MandatorUserNTT userNTT = MyMockGenerator.getMockedMandatorUserNTT();
		userNTT.setRole_code("USER");

		assertThrows(UserNotAllowedExecption.class, () -> securityService.checkPermission(env, entityId, true, Operation.ADD_MANDATE, ErrorField.MANDATE));

		env = getMockServiceSupportEnv("UserTest", "UserTest", TENANT);
		when(mandatesDAO.getUserById(eq(env.getTenantId()), eq(entityId), eq(env.getUser().getUserId()), anyInt(), anyInt())).thenReturn(null, userNTT);

		//User not exists
		assertThrows(UserNotAllowedExecption.class, () -> securityService.checkPermission(env, entityId, true, Operation.ADD_MANDATE, ErrorField.MANDATE));

		//User is not ADMIN
		assertThrows(UserNotAllowedExecption.class, () -> securityService.checkPermission(env, entityId, true, Operation.ADD_MANDATE, ErrorField.MANDATE));
	}

	@Test
	void testCheckAdminPermission_Success() {
		assertFalse(securityService.checkAdminPermission(env, Operation.ADD_MANDATE));
	}

	@Test
	void testCheckAdminPermissionThrowsUserNotAllowedExecption() {
		env = getMockServiceSupportEnv("UserTest", null, TENANT);

		assertThrows(UserNotAllowedExecption.class, () -> securityService.checkAdminPermission(env, Operation.ADD_MANDATE));
	}


}
