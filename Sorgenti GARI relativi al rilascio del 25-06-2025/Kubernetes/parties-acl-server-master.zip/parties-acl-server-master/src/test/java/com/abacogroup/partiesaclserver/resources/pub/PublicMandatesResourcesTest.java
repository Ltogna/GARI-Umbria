package com.abacogroup.partiesaclserver.resources.pub;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Base64;
import java.util.Set;

import org.junit.jupiter.api.Test;

import com.abacogroup.partiesaclserver.core.pub.MandatesV1Service;
import com.abacogroup.partiesaclserver.resources.ResourcesTest;
import com.abacogroup.partiesaclserver.resources.pub.req.AddPartyPayloadV1;
import com.abacogroup.partiesaclserver.resources.pub.res.HasManageV1Res;
import com.abacogroup.partiesaclserver.resources.pub.res.UserPartyAuthV1;
import com.abacogroup.partiesaclserver.resources.res.pub.MyHasManageResV1;
import com.abacogroup.partiesaclserver.resources.res.pub.MyUserPartyAuthV1;

import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.HttpHeaders;

class PublicMandatesResourcesTest extends ResourcesTest{
	
	private static MandatesV1Service MandatesV1Service = mock(MandatesV1Service.class);
	private static final ResourceExtension EXT = createResourceExtension(new PublicMandatesResources(MandatesV1Service));
	
	@Test
	void getEntityByCodeTest(){
		HasManageV1Res resp = new HasManageV1Res(true);
		
		when(MandatesV1Service.hasManage(any(), any())).thenReturn(resp);
		
		String partyId = "test_id";
		
		MyHasManageResV1 res = EXT.target(PUBLIC_MOCK_BASE_URL_PATH + "/parties/" + partyId + "/manage")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyHasManageResV1>() {
				});
		
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyHasManageResV1>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}
	
	@Test
	void getAuthorizationsByPartyIdAndUserTest(){
		UserPartyAuthV1 resp = new UserPartyAuthV1();
		
		when(MandatesV1Service.getAuthorizations(any(), any())).thenReturn(resp);
		
		String partyId = "test_id";
		
		MyUserPartyAuthV1 res = EXT.target(PUBLIC_MOCK_BASE_URL_PATH + "/parties/" + partyId + "/auth")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.get(new GenericType<MyUserPartyAuthV1>() {
				});
		
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyUserPartyAuthV1>> violations = validator.validate(res);
		assertEquals(0, violations.size());
	}
	
	@Test
	void TestAddPartyToEntity() {
		Long mandateId = 123L;
		Long entityId = 123L;
		
		AddPartyPayloadV1 payload = AddPartyPayloadV1.builder()
				.id("165466")
				.partyTypeCode("test")
				.dayFrom(NOW)
				.build();
		when(MandatesV1Service.addPartyToEntity(any(), any(), any())).thenReturn(mandateId);

		Long res = EXT.target(PUBLIC_MOCK_BASE_URL_PATH + "/entities/" + entityId + "/parties")
				.request()
				.header(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString("admin:welcome".getBytes()))
				.post(Entity.json(payload), new GenericType<Long>() {
				});

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Long>> violations = validator.validate(res);
		assertEquals(0, violations.size());

	}
}
