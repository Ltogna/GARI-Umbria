package com.abacogroup.partiesaclserver.core;

import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.List;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.revision.IdNotFoundException;
import com.abacogroup.partiesaclserver.core.exceptions.support.InternalConfigNotFoundException;
import com.abacogroup.partiesaclserver.core.mappers.PathPartyMapper;
import com.abacogroup.partiesaclserver.core.mappers.PathUserMapper;
import com.abacogroup.partiesaclserver.core.mappers.RevisionHistoryMapper;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.RevisionHistoryDAO;
import com.abacogroup.partiesaclserver.db.ntt.PathPartyNTT;
import com.abacogroup.partiesaclserver.db.ntt.PathUserNTT;
import com.abacogroup.partiesaclserver.db.ntt.RevisionHistoryNTT;
import com.abacogroup.partiesaclserver.resources.res.ClientConfiguration;
import com.abacogroup.partiesaclserver.resources.res.PathDetails;
import com.abacogroup.partiesaclserver.resources.res.PathParty;
import com.abacogroup.partiesaclserver.resources.res.PathUser;
import com.abacogroup.partiesaclserver.resources.res.RevisionHistory;
import com.abacogroup.partiesaclserver.resources.res.TenantsList;

import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class InternalAPIService {

	private InternalConfigService internalConfigService;
	private RevisionHistoryDAO revisionHistoryDAO;
	private ErrorDescriptionsService errorDescriptionsService;
	private static final int INTERNAL_DEFAULT_PAGE_SIZE = 50;

	public InternalAPIService(DAOContainer container, InternalConfigService internalConfigService, ErrorDescriptionsService errorDescriptionsService) {
		this.revisionHistoryDAO = container.getRevisionHistoryDAO();
		this.errorDescriptionsService = errorDescriptionsService;
		this.internalConfigService = internalConfigService;
	}

	public InfiniteListResults<RevisionHistory> getHistoryWithLastId(ServiceSupportEnv env, Long fromId, String nextKey) {
		log.info("Internal request for history log starting from id: {}", fromId);
		
		//check if fromId exists
		RevisionHistoryNTT revisionHistoryNTT = revisionHistoryDAO.getById(env.getTenantId(), fromId);

		InfiniteListResults<RevisionHistory> results = null;

		if(revisionHistoryNTT != null) {
			results = this.revisionHistoryDAO.infinite(() -> revisionHistoryDAO.getFromId(env.getTenantId(), fromId),
					nextKey,
					INTERNAL_DEFAULT_PAGE_SIZE)
					.map(RevisionHistoryMapper.INSTANCE::entityTODto);
		} else {
			throw new IdNotFoundException(Status.NOT_FOUND, Operation.GET_REVISION_HISTORY, ErrorField.REVISION,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), fromId, revisionHistoryDAO.getLastId(env.getTenantId()));
		}

		return results;
	}

	public InfiniteListResults<PathDetails> getFullRevisionHistory(ServiceSupportEnv env, String nextKey) {
		InfiniteListResults<PathDetails> results = this.revisionHistoryDAO.infinite(() -> revisionHistoryDAO.getAllPath(env.getTenantId()),
				nextKey, INTERNAL_DEFAULT_PAGE_SIZE);

		results.getRecords().forEach(rec -> {
			List<PathUserNTT> usersNTT = revisionHistoryDAO.getUsersByPath(env.getTenantId(), rec.getPath());

			List<PathUser> usersList = usersNTT == null ? new ArrayList<>()
					: usersNTT.stream().map(PathUserMapper.INSTANCE::entityTODto).collect(toList());

			rec.setMandatorUsersList(usersList);

			List<PathPartyNTT> partiesNTT = revisionHistoryDAO.getPartiesByPath(env.getTenantId(), rec.getPath());

			List<PathParty> partyList = partiesNTT == null ? new ArrayList<>()
					: partiesNTT.stream().map(PathPartyMapper.INSTANCE::entityTODto).collect(toList());

			rec.setPartiesList(partyList);
		});

		return results;
	}

	public TenantsList getTenantsList() {
		return new TenantsList(revisionHistoryDAO.findTenants());
	}
	
	public ClientConfiguration getClientConfigKey(String tenantId, String lang, String key) {
		String value = internalConfigService.getStringValue(tenantId, key);
		
		if(value == null) {
			throw new InternalConfigNotFoundException(Status.NOT_FOUND, Operation.GET_INTERNAL_CONFIG, ErrorField.CONFIG,
					this.errorDescriptionsService.getTenantErrorDescriptions(tenantId), lang);
		}
		
		return ClientConfiguration.builder()
				.name(key)
				.value(value)
				.build();
	}

}
