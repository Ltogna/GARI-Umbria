package com.abacogroup.partiesaclserver.db.ntt;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PathUserNTT {
	private String id;
	private String role;
}