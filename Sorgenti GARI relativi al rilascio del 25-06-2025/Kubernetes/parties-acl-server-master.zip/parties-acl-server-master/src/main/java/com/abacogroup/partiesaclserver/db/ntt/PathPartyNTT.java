package com.abacogroup.partiesaclserver.db.ntt;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PathPartyNTT {
	private String party_id;
	private String mandate_id;
	private Integer fl_exclusive;
	private Integer fl_manage;
	private AbsoluteDate day_from;
	private AbsoluteDate day_to;
}