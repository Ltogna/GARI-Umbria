package com.abacogroup.partiesaclserver.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.InternalConfigKeys;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.enums.Revision;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidEndDateException;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidPayloadException;
import com.abacogroup.partiesaclserver.core.exceptions.NothingToUpdateException;
import com.abacogroup.partiesaclserver.core.exceptions.PastDateNotallowedException;
import com.abacogroup.partiesaclserver.core.exceptions.ValidationDateException;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityCodeRequiredExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityCodeUniqueExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityExistsWithRegistryPartyIdExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityNameExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityNotFoundExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityTypeNotCompatibleExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityWithExclusivePartyExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityWithParentExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityWithoutParentExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.HierarchialLoopExecption;
import com.abacogroup.partiesaclserver.core.exceptions.entity.ParentNotValidExecption;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeNotFoundExecption;
import com.abacogroup.partiesaclserver.core.mappers.EntityMapper;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.EntityDAO;
import com.abacogroup.partiesaclserver.db.dao.MandatesDAO;
import com.abacogroup.partiesaclserver.db.ntt.EntityNTT;
import com.abacogroup.partiesaclserver.db.ntt.EntityTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.UpdatedObjectDataNTT;
import com.abacogroup.partiesaclserver.resources.req.CloseDatePayload;
import com.abacogroup.partiesaclserver.resources.req.CreateEntityPayload;
import com.abacogroup.partiesaclserver.resources.req.EntitySearchFilters;
import com.abacogroup.partiesaclserver.resources.req.UpdateEntityPayload;
import com.abacogroup.partiesaclserver.resources.res.Entity;

import jakarta.ws.rs.core.Response.Status;

public class EntitiesService {

	private EntityDAO entityDAO;
	private MandatesDAO mandatesDAO;
	private RevisionService revisionService;
	private SecurityService securityService;
	private InternalConfigService internalConfigService;
	private PartyRegistryClientService partyRegistryClientService;
	private UtilityService utilityService;
	private ErrorDescriptionsService errorDescriptionsService;
	private static final int DEFAULT_PAGE_SIZE = 25;

	/**
	 * The EntitiesService class provides methods to manage entities. It provides methods to create entities, retrieve entities based on filters, and manage
	 * entity hierarchy.
	 */
	public EntitiesService(DAOContainer container, SecurityService securityService, RevisionService revisionService,
			InternalConfigService internalConfigService, UtilityService utilityService, PartyRegistryClientService entityNameService,
			ErrorDescriptionsService errorDescriptionsService) {
		this.entityDAO = container.getEntityDAO();
		this.mandatesDAO = container.getMandatesDAO();
		this.revisionService = revisionService;
		this.securityService = securityService;
		this.internalConfigService = internalConfigService;
		this.utilityService = utilityService;
		this.partyRegistryClientService = entityNameService;
		this.errorDescriptionsService = errorDescriptionsService;
	}

	/**
	 * The createEntity method creates a new Entity object with the given attributes and saves it to the database. It first validates the input data to ensure
	 * that it meets the required criteria. If any validation fails, it throws an exception with an appropriate error message. If all validations pass, it
	 * creates a new EntityNTT object with the given data and saves it to the Entity table using the entityDAO object.
	 *
	 * @param env
	 * @param payload
	 *            the payload containing the entity data
	 * @return the ID of the created entity
	 * @throws TypeNotFoundExecption
	 *             if the specified entity type is not found
	 * @throws EntityCodeExecption
	 *             if the entity code is missing for a mandatory code entity type
	 * @throws PastDateNotallowedException
	 *             if the provided dayFrom is in the past and not allowed
	 * @throws ValidationDateException
	 *             if the provided dayFrom is greater than or equal to the dayTo
	 * @throws EntityExistsWithRegistryPartyIdExecption
	 *             if the entity already exists with the given registry-party ID and validation date interval
	 * @throws EntityNameExecption
	 *             if the entity name is missing
	 */
	public Long createEntity(ServiceSupportEnv e, CreateEntityPayload payload) {
		ServiceSupportEnv env = utilityService.checkEnv(e);
		EntityTypeNTT type = utilityService.getEntityTypeNTTByCode(env, payload.getEntityTypeCode(), Operation.CREATE_ENTITY);

		if (type.getFl_entity_code_mandatory() == 1 && (payload.getCode() == null || payload.getCode().isBlank())) {
			throw new EntityCodeRequiredExecption(Status.BAD_REQUEST, Operation.CREATE_ENTITY, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					utilityService.getFormatedErrorMsg(type.getCode(), type.getDescription()));
		}

		if (payload.getCode() != null && !payload.getCode().isBlank() && entityDAO.checkEntityByEntityCode(env.getTenantId(), payload.getCode()) != 0) {
			throw new EntityCodeUniqueExecption(Status.BAD_REQUEST, Operation.CREATE_ENTITY, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), payload.getCode());
		}

		Boolean pastDateAllowed = internalConfigService.getBooleanValue(env.getTenantId(), InternalConfigKeys.ALLOW_PAST_DATE.getKey());
		if (Boolean.FALSE.equals(pastDateAllowed) && payload.getDayFrom().toLocalDate().isBefore(env.getReferenceDate().toLocalDate())) {
			throw new PastDateNotallowedException(Status.BAD_REQUEST, Operation.CREATE_ENTITY, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		if (payload.getDayTo() == null) {
			payload.setDayTo(AbsoluteDate.of("99991231"));
		}

		Boolean pastDateCloseAllowed = internalConfigService.getBooleanValue(env.getTenantId(), InternalConfigKeys.ALLOW_PAST_CLOSE_DATE.getKey());
		if (Boolean.FALSE.equals(pastDateCloseAllowed) && payload.getDayTo().toLocalDate().isBefore(env.getReferenceDate().toLocalDate())) {
			throw new InvalidEndDateException(Status.BAD_REQUEST, Operation.CREATE_ENTITY, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		if (payload.getDayFrom().toLocalDate().isAfter(payload.getDayTo().toLocalDate())
				|| payload.getDayFrom().toLocalDate().isEqual(payload.getDayTo().toLocalDate())) {
			throw new ValidationDateException(Status.BAD_REQUEST, Operation.CREATE_ENTITY, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		String name = getEntityName(payload, env);

		Entity parentEntity = getParentEntity(payload, env);
		Long parentEntityId = parentEntity == null ? null : parentEntity.getId();
		Long id = entityDAO.nextSequenceValEntityId();

		String path = (parentEntityId == null ? "/" + id : parentEntity.getPath() + id)
				+ "/";

		entityDAO.useTransaction(dao -> {
			EntityNTT entityNTT = EntityNTT.builder()
					.pkid(entityDAO.nextSequenceValEntityDetailsId())
					.entity_id(id)
					.name(name)
					.code(payload.getCode())
					.entity_type(type)
					.registry_party_id(payload.getRegistryPartyId())
					.description(payload.getDescription())
					.parent_id(parentEntityId)
					.path(path)
					.day_from(payload.getDayFrom())
					.day_to(payload.getDayTo())
					.build();

			entityDAO.insertEntity(id, env.getTenantId());
			entityDAO.insertEntityDetails(entityNTT, env.getUser().getUserId());
		});

		return id;
	}

	private Entity getParentEntity(CreateEntityPayload payload, ServiceSupportEnv env) {
		if (payload.getParentCode() == null) {
			return null;
		}
		return getEntityByCode(env, payload.getParentCode(), false);
	}

	private String getEntityName(CreateEntityPayload payload, ServiceSupportEnv env) {
		String name;
		if (payload.getRegistryPartyId() != null) {
			checkEntityByRegistryPartyId(env, payload.getRegistryPartyId(), payload.getDayFrom(), payload.getDayTo(), Operation.CREATE_ENTITY);
			name = partyRegistryClientService.getName(env, payload.getRegistryPartyId());
		} else {
			name = payload.getName();
		}

		if (name == null) {
			throw new EntityNameExecption(Status.BAD_REQUEST, Operation.CREATE_ENTITY, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		return name;
	}

	/**
	 * The getEntity method retrieves a paginated list of Entity objects from the database that match the given filters.
	 * 
	 * @param env
	 *            the service support environment
	 * @param filter
	 *            the entity search filters
	 * @param skipPermissionCheck
	 *            set user as Admin
	 * @param nextKey
	 *            the pagination token for retrieving the next page of results
	 * @return the list of entities
	 */
	public InfiniteListResults<Entity> getEntities(ServiceSupportEnv e, EntitySearchFilters filter, Boolean skipPermissionCheck, String nextKey) {
		ServiceSupportEnv env = utilityService.checkEnv(e);
		InfiniteListResults<Entity> results;
		Boolean isAdmin;
		if (Boolean.FALSE.equals(skipPermissionCheck)) {
			isAdmin = securityService.checkAdminPermission(env, Operation.GET_ENTITY);
		} else {
			isAdmin = true;
		}

		Criteria nameFilter = filter.getName() == null ? CriteriaBuilder.number("1").eq(1)
				: CriteriaBuilder.string("ped.name").caseInsensitiveContains(filter.getName());
		Criteria codeFilter = filter.getCode() == null ? CriteriaBuilder.number("1").eq(1)
				: CriteriaBuilder.string("ped.code").caseInsensitiveContains(filter.getCode());
		Criteria registryPartyFilter = filter.getRegistryId() == null ? CriteriaBuilder.number("1").eq(1)
				: CriteriaBuilder.string("ped.registry_party_id").caseInsensitiveContains(filter.getRegistryId());
		Criteria entityTypeCodeFilter = filter.getEntityTypeCode() == null ? CriteriaBuilder.number("1").eq(1)
				: CriteriaBuilder.string("pet.code").caseInsensitiveContains(filter.getEntityTypeCode());

		Criteria criteria = CriteriaBuilder.and(List.of(
				nameFilter,
				codeFilter,
				registryPartyFilter,
				entityTypeCodeFilter).toArray(new Criteria[0]));

		results = this.entityDAO
				.infinite(
						() -> entityDAO.getAllEntitiesInfinite(env, env.getUser().getUserId(), criteria, booleanToInteger(filter.getHistory()),
								booleanToInteger(isAdmin)),
						nextKey,
						DEFAULT_PAGE_SIZE)
				.map(EntityMapper.INSTANCE::entityTODto);

		results.getRecords().forEach(rec -> {
			List<String> adminList = new ArrayList<>();
			mandatesDAO.getAllAdminByEntityId(env, rec.getId()).stream().forEach(admin -> adminList.add(admin.getUsername()));
			rec.setAdminUsers(adminList);
		});

		return results;
	}

	/**
	 * Retrieves an entity by its ID.
	 *
	 * @param env
	 *            the service support environment
	 * @param entityId
	 *            the ID of the entity to retrieve
	 * @return the retrieved entity
	 */
	public Entity getEntityById(ServiceSupportEnv e, Long entityId) {
		ServiceSupportEnv env = utilityService.checkEnv(e);
		securityService.checkPermission(env, entityId, false, Operation.GET_ENTITY, ErrorField.ENTITY);

		EntityNTT entityNTT = utilityService.getEntityById(env, entityId, false, false, Operation.GET_ENTITY);

		Entity entity = EntityMapper.INSTANCE.entityTODto(entityNTT);

		List<String> adminList = new ArrayList<>();
		mandatesDAO.getAllAdminByEntityId(env, entity.getId()).stream().forEach(admin -> adminList.add(admin.getUsername()));
		entity.setAdminUsers(adminList);

		return entity;
	}

	/**
	 * Retrieves an entity by its code.
	 *
	 * @param env
	 *            the service support environment
	 * @param entityCode
	 *            the code of the entity to retrieve
	 * @return the retrieved entity
	 */
	public Entity getEntityByCode(ServiceSupportEnv e, String entityCode, Boolean skipPermissionCheck) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		Boolean isAdmin;
		if (Boolean.FALSE.equals(skipPermissionCheck)) {
			isAdmin = securityService.checkAdminPermission(env, Operation.GET_ENTITY);
		} else {
			isAdmin = true;
		}

		EntityNTT entityNTT = entityDAO.getEntityByCode(env, entityCode, env.getUser().getUserId(), 0, 0, booleanToInteger(isAdmin));

		if (entityNTT == null) {
			throw new EntityNotFoundExecption(Status.NOT_FOUND, Operation.GET_ENTITY, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), entityCode);
		}

		if (Boolean.FALSE.equals(skipPermissionCheck)) {
			securityService.checkPermission(env, entityNTT.getEntity_id(), false, Operation.GET_ENTITY, ErrorField.ENTITY);
		}

		Entity entity = EntityMapper.INSTANCE.entityTODto(entityNTT);

		List<String> adminList = new ArrayList<>();
		mandatesDAO.getAllAdminByEntityId(env, entity.getId()).stream().forEach(admin -> adminList.add(admin.getUsername()));
		entity.setAdminUsers(adminList);

		return entity;
	}

	/**
	 * Adds a child entity to a parent entity.
	 *
	 * @param env
	 *            the service support environment
	 * @param parentId
	 *            the ID of the parent entity
	 * @param childId
	 *            the ID of the child entity
	 * @param forceUpdate
	 *            whether to force the update if the child entity already has a parent
	 * @return true if the child entity was successfully added to the parent entity
	 */
	public Boolean addChildToParent(ServiceSupportEnv e, Long parentId, Long childId, Boolean forceUpdate) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		// security check
		securityService.checkPermission(env, parentId, true, Operation.UPDATE_HIERARCHY, ErrorField.ENTITY);

		securityService.checkPermission(env, childId, true, Operation.UPDATE_HIERARCHY, ErrorField.ENTITY);

		// check parent
		EntityNTT parent = utilityService.getEntityById(env, parentId, false, false, Operation.UPDATE_HIERARCHY);

		// check child
		EntityNTT child = utilityService.getEntityById(env, childId, false, false, Operation.UPDATE_HIERARCHY);

		// check parte and child types
		if (!parent.getEntity_type().getId().equals(child.getEntity_type().getId())) {
			throw new EntityTypeNotCompatibleExecption(Status.CONFLICT, Operation.UPDATE_HIERARCHY, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					utilityService.getFormatedErrorMsg(parent.getEntity_type().getCode(), parent.getEntity_type().getDescription()),
					utilityService.getFormatedErrorMsg(child.getEntity_type().getCode(), child.getEntity_type().getDescription()));
		}

		// check for hierarchical loops
		if (parent.getPath().contains("/" + childId + "/")) {
			throw new HierarchialLoopExecption(Status.CONFLICT, Operation.UPDATE_HIERARCHY, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					utilityService.getFormatedErrorMsg(parent.getCode(), parent.getName()),
					utilityService.getFormatedErrorMsg(child.getCode(), child.getName()));
		}

		// check if child already has parent and want to force update
		if (child.getParent_id() != null && forceUpdate && !child.getParent_id().equals(parentId)) {
			return moveChild(env, child, parent);
		}

		// check if child already has parent and do not want to force update
		if (child.getParent_id() != null) {
			EntityNTT presentParent = utilityService.getEntityById(env, child.getParent_id(), false, false, Operation.UPDATE_HIERARCHY);
			throw new EntityWithParentExecption(Status.BAD_REQUEST, Operation.UPDATE_HIERARCHY, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					utilityService.getFormatedErrorMsg(child.getCode(), child.getName()),
					utilityService.getFormatedErrorMsg(presentParent.getCode(), presentParent.getName()));
		}

		entityDAO.useTransaction(dao -> {
			EntityNTT newChild = EntityNTT.builder()
					.pkid(entityDAO.nextSequenceValEntityDetailsId())
					.entity_id(childId)
					.name(child.getName())
					.code(child.getCode())
					.entity_type(child.getEntity_type())
					.registry_party_id(child.getRegistry_party_id())
					.description(child.getDescription())
					.parent_id(parentId)
					.path(parent.getPath() + childId + "/")
					.day_from(child.getDay_from())
					.day_to(child.getDay_to())
					.build();

			entityDAO.outdateEntityById(env.getTenantId(), env.getUser().getUserId(), childId);
			entityDAO.insertEntityDetails(newChild, env.getUser().getUserId());

			// update revision history table
			revisionService.insertOperation(env, Revision.EXT_PATH, null, child.getPath(), newChild.getPath(), null);

			// update child path of childId
			List<EntityNTT> childList = entityDAO.getChild(env, childId);

			if (childList != null && !childList.isEmpty()) {
				childList.parallelStream().forEach(ent -> updateChildPath(env, newChild.getPath(), ent, Revision.EXT_PATH));
			}
		});

		return true;
	}

	private Boolean moveChild(ServiceSupportEnv env, EntityNTT child, EntityNTT parent) {

		entityDAO.useTransaction(dao -> {
			EntityNTT newChild = EntityNTT.builder()
					.pkid(entityDAO.nextSequenceValEntityDetailsId())
					.entity_id(child.getEntity_id())
					.name(child.getName())
					.code(child.getCode())
					.entity_type(child.getEntity_type())
					.registry_party_id(child.getRegistry_party_id())
					.description(child.getDescription())
					.parent_id(parent.getEntity_id())
					.path(parent.getPath() + child.getEntity_id() + "/")
					.day_from(child.getDay_from())
					.day_to(child.getDay_to())
					.build();

			entityDAO.outdateEntityById(env.getTenantId(), env.getUser().getUserId(), child.getEntity_id());
			entityDAO.insertEntityDetails(newChild, env.getUser().getUserId());

			// update revision history table
			revisionService.insertOperation(env, Revision.UPDATE_PATH, null, child.getPath(), newChild.getPath(), null);

			// update child path of childId
			List<EntityNTT> childList = entityDAO.getChild(env, child.getEntity_id());

			if (childList != null && !childList.isEmpty()) {
				childList.parallelStream().forEach(e -> updateChildPath(env, newChild.getPath(), e, Revision.UPDATE_PATH));
			}
		});
		return true;
	}

	/**
	 * Removes a child entity from its parent entity.
	 *
	 * @param env
	 *            the service support environment
	 * @param childId
	 *            the ID of the child entity
	 * @param parentId
	 *            the ID of the parent entity
	 * @return true if the child entity was successfully removed from the parent entity
	 */
	public Boolean removeChildFromParent(ServiceSupportEnv e, Long parentId, Long childId) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		// security check
		securityService.checkPermission(env, parentId, true, Operation.UPDATE_HIERARCHY, ErrorField.ENTITY);

		securityService.checkPermission(env, childId, true, Operation.UPDATE_HIERARCHY, ErrorField.ENTITY);

		// check parent
		EntityNTT parent = utilityService.getEntityById(env, parentId, false, false, Operation.UPDATE_HIERARCHY);

		// check child
		EntityNTT child = utilityService.getEntityById(env, childId, false, false, Operation.UPDATE_HIERARCHY);

		// check if child has parent
		if (child.getParent_id() == null) {
			throw new EntityWithoutParentExecption(Status.BAD_REQUEST, Operation.UPDATE_HIERARCHY, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					utilityService.getFormatedErrorMsg(child.getCode(), child.getDescription()));
		}

		if (!child.getParent_id().equals(parent.getEntity_id())) {
			throw new ParentNotValidExecption(Status.BAD_REQUEST, Operation.UPDATE_HIERARCHY, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					utilityService.getFormatedErrorMsg(parent.getCode(), parent.getName()),
					utilityService.getFormatedErrorMsg(child.getCode(), child.getName()));
		}

		entityDAO.useTransaction(dao -> {
			EntityNTT newChild = EntityNTT.builder()
					.pkid(entityDAO.nextSequenceValEntityDetailsId())
					.entity_id(childId)
					.code(child.getCode())
					.name(child.getName())
					.entity_type(child.getEntity_type())
					.registry_party_id(child.getRegistry_party_id())
					.description(child.getDescription())
					.parent_id(null)
					.path("/" + childId + "/")
					.day_from(child.getDay_from())
					.day_to(child.getDay_to())
					.build();

			entityDAO.outdateEntityById(env.getTenantId(), env.getUser().getUserId(), childId);
			entityDAO.insertEntityDetails(newChild, env.getUser().getUserId());

			// update revision history table
			revisionService.insertOperation(env, Revision.TRUNC_PATH, null, child.getPath(), newChild.getPath(), null);

			// update child path of childId
			List<EntityNTT> childList = entityDAO.getChild(env, childId);

			if (childList != null && !childList.isEmpty()) {
				childList.parallelStream().forEach(ent -> updateChildPath(env, newChild.getPath(), ent, Revision.TRUNC_PATH));
			}
		});

		return true;
	}

	/**
	 * Updates an existing entity with the given attributes.
	 *
	 * @param env
	 *            the service support environment
	 * @param payload
	 *            the payload containing the updated entity data
	 * @return true if the entity was successfully updated
	 * @throws PastDateNotallowedException
	 *             if the provided dayFrom is in the past and not allowed
	 * @throws ValidationDateException
	 *             if the provided dayFrom is greater than or equal to the dayTo
	 * @throws EntityCodeExecption
	 *             if the entity code is missing for a mandatory code entity type
	 * @throws EntityNameExecption
	 *             if the entity name is missing
	 */
	public Boolean updateEntity(ServiceSupportEnv e, Long entityId, UpdateEntityPayload payload) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		if (Boolean.TRUE.equals(payload.isEmpty())) {
			throw new InvalidPayloadException(Status.BAD_REQUEST, Operation.UPDATE_ENTITY, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		// security check
		securityService.checkPermission(env, entityId, true, Operation.UPDATE_ENTITY, ErrorField.ENTITY);

		EntityNTT entityNTT = utilityService.getEntityById(env, entityId, false, false, Operation.UPDATE_ENTITY);

		String newDescription = payload.getDescription();

		AbsoluteDate newDayTo = getUpdatedDayTo(env, entityNTT, payload);

		// An entity can be closed before it's start date
		// if(entityNTT.getDay_from().compareTo(newDayTo) >= 0) {
		// throw new ValidationDateException(Status.BAD_REQUEST, Operation.UPDATE_ENTITY, ErrorField.ENTITY,
		// this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		// }

		EntityTypeNTT newEntityType = entityNTT.getEntity_type();
		Boolean entityTypeCodeUpdated = false;

		// poi se il codice nel payload è diverso da quello di entityTypeNTT allora faccio
		if (payload.getEntityTypeCode() != null && !entityNTT.getEntity_type().getCode().equals(payload.getEntityTypeCode())) {
			newEntityType = utilityService.getEntityTypeNTTByCode(env, payload.getEntityTypeCode(), Operation.UPDATE_ENTITY);
			List<PartyTypeNTT> partyTypeList = entityDAO.getPartyTypesByEntityId(env.getTenantId(), entityId);
			final EntityTypeNTT finalEntityType = newEntityType;

			if (partyTypeList != null && !partyTypeList.isEmpty()) {
				partyTypeList.forEach(p -> utilityService.checkEntityPartyTypeCompatibility(env, p, finalEntityType, Operation.UPDATE_ENTITY));
				entityTypeCodeUpdated = true;
			}
		}

		String newCode = getUpdatedEntityCode(env, entityNTT, newEntityType, payload);
		String newName = payload.getName() != null ? payload.getName() : entityNTT.getName();

		String newRegisterPartyId = entityNTT.getRegistry_party_id();
		if (payload.getRegistryPartyId() != null && !payload.getRegistryPartyId().equals(entityNTT.getRegistry_party_id())) {
			newRegisterPartyId = payload.getRegistryPartyId();
			checkEntityByRegistryPartyId(env, newRegisterPartyId, entityNTT.getDay_from(), newDayTo, Operation.UPDATE_ENTITY);
			newName = partyRegistryClientService.getName(env, newRegisterPartyId);
		}

		if (newDayTo.equals(entityNTT.getDay_to()) && newName.equals(entityNTT.getName()) &&
				newEntityType.getId().equals(entityNTT.getEntity_type().getId()) && Objects.equals(newDescription, entityNTT.getDescription())
				&& Objects.equals(newRegisterPartyId, entityNTT.getRegistry_party_id()) && Objects.equals(newCode, entityNTT.getCode())) {

			throw new NothingToUpdateException(Status.BAD_REQUEST, Operation.UPDATE_ENTITY, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		EntityNTT newEntityNTT = EntityNTT.builder()
				.entity_id(entityId)
				.code(newCode)
				.name(newName)
				.entity_type(newEntityType)
				.registry_party_id(newRegisterPartyId)
				.description(newDescription)
				.parent_id(entityNTT.getParent_id())
				.path(entityNTT.getPath())
				.day_from(entityNTT.getDay_from())
				.day_to(newDayTo)
				.build();

		entityDAO.outdateEntityById(env.getTenantId(), env.getUser().getUserId(), entityNTT.getEntity_id());

		if (entityNTT.getDay_from().toLocalDate().isBefore(newDayTo.toLocalDate())) {
			newEntityNTT.setPkid(entityDAO.nextSequenceValEntityDetailsId());
			entityDAO.insertEntityDetails(newEntityNTT, env.getUser().getUserId());

			// notifica rabbit
			if (Boolean.TRUE.equals(entityTypeCodeUpdated)) {
				UpdatedObjectDataNTT data = UpdatedObjectDataNTT.builder()
						.entityTypeCode(newEntityType.getCode())
						.dayFrom(entityNTT.getDay_from())
						.dayTo(newDayTo)
						.build();

				revisionService.insertOperation(env, Revision.UPDATE_ENTITY, null, newEntityNTT.getPath(), null, data);
			}
		} else {
			UpdatedObjectDataNTT data = UpdatedObjectDataNTT.builder()
					.entityTypeCode(newEntityType.getCode())
					.dayFrom(entityNTT.getDay_from())
					.dayTo(newDayTo)
					.build();
			revisionService.insertOperation(env, Revision.REMOVE_ENTITY, null, newEntityNTT.getPath(), null, data);
		}

		return true;
	}

	private void checkEntityByRegistryPartyId(ServiceSupportEnv env, String registerPartyId, AbsoluteDate dayFrom, AbsoluteDate dayTo, Operation operation) {
		Integer count = entityDAO.checkEntityByRegistryPartyId(env, registerPartyId, dayFrom, dayTo);
		if (count != 0) {
			throw new EntityExistsWithRegistryPartyIdExecption(Status.BAD_REQUEST, operation, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}
	}

	private String getUpdatedEntityCode(ServiceSupportEnv env, EntityNTT entityNTT, EntityTypeNTT newEntityType,
			UpdateEntityPayload payload) {
		String newCode = entityNTT.getCode();

		if (payload.getCode() != null && !payload.getCode().equals(entityNTT.getCode())) {
			if (newEntityType.getFl_entity_code_mandatory() == 1 && (payload.getCode() == null || payload.getCode().isBlank())) {
				throw new EntityCodeRequiredExecption(Status.BAD_REQUEST, Operation.UPDATE_ENTITY, ErrorField.ENTITY,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
						utilityService.getFormatedErrorMsg(newEntityType.getCode(), newEntityType.getDescription()));
			}

			if (payload.getCode() != null && !payload.getCode().isBlank() && entityDAO.checkEntityByEntityCode(env.getTenantId(), payload.getCode()) != 0) {
				throw new EntityCodeUniqueExecption(Status.BAD_REQUEST, Operation.UPDATE_ENTITY, ErrorField.ENTITY,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), payload.getCode());
			}

			newCode = payload.getCode();
		}
		return newCode;
	}

	private AbsoluteDate getUpdatedDayTo(ServiceSupportEnv env, EntityNTT oldEntity, UpdateEntityPayload payload) {
		Boolean pastDateCloseAllowed = internalConfigService.getBooleanValue(env.getTenantId(), InternalConfigKeys.ALLOW_PAST_CLOSE_DATE.getKey());
		AbsoluteDate newDayTo = oldEntity.getDay_to();
		if (payload.getDayTo() != null) {
			if (Boolean.FALSE.equals(pastDateCloseAllowed) && payload.getDayTo().toLocalDate().isBefore(env.getReferenceDate().toLocalDate())) {
				throw new InvalidEndDateException(Status.BAD_REQUEST, Operation.UPDATE_ENTITY, ErrorField.ENTITY,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
			}
			if (mandatesDAO.checkExclusivePartiesAfterDate(env.getTenantId(), oldEntity.getEntity_id(), payload.getDayTo()) != 0) {
				throw new EntityWithExclusivePartyExecption(Status.BAD_REQUEST, Operation.UPDATE_ENTITY, ErrorField.ENTITY,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
						utilityService.getFormatedErrorMsg(oldEntity.getCode(), oldEntity.getName()));
			}
			newDayTo = payload.getDayTo();
		}

		return newDayTo;
	}

	private void updateChildPath(ServiceSupportEnv env, String parentPath, EntityNTT child, Revision operation) {

		String newPath = parentPath + child.getEntity_id() + "/";
		EntityNTT ent = EntityNTT.builder()
				.pkid(entityDAO.nextSequenceValEntityDetailsId())
				.entity_id(child.getEntity_id())
				.code(child.getCode())
				.name(child.getName())
				.entity_type(child.getEntity_type())
				.registry_party_id(child.getRegistry_party_id())
				.description(child.getDescription())
				.parent_id(child.getParent_id())
				.path(newPath)
				.day_from(child.getDay_from())
				.day_to(child.getDay_to())
				.build();

		entityDAO.outdateEntityById(env.getTenantId(), env.getUser().getUserId(), child.getEntity_id());
		entityDAO.insertEntityDetails(ent, env.getUser().getUserId());

		// update revision history table
		revisionService.insertOperation(env, operation, null, child.getPath(), ent.getPath(), null);

		List<EntityNTT> childList = entityDAO.getChild(env, ent.getEntity_id());

		if (childList != null && !childList.isEmpty()) {
			childList.parallelStream().forEach(e -> updateChildPath(env, ent.getPath(), e, operation));
		}
	}

	public InfiniteListResults<Entity> getAllChildrenByParentId(ServiceSupportEnv e, Long entityId, String nextKey) {
		ServiceSupportEnv env = utilityService.checkEnv(e);
		securityService.checkPermission(env, entityId, false, Operation.GET_ENTITY_CHILDREN, ErrorField.ENTITY);

		Integer includeLevels = internalConfigService.getIntegerValue(env.getTenantId(), InternalConfigKeys.HIERARCHICAL_INHERITANCE_LEVEL.getKey());

		return this.entityDAO.infinite(() -> entityDAO.getAllChildbyParentId(env, entityId, includeLevels),
				nextKey,
				DEFAULT_PAGE_SIZE)
				.map(EntityMapper.INSTANCE::entityTODto);
	}

	public Boolean closeEntity(ServiceSupportEnv e, Long entityId, CloseDatePayload payload) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		if (payload.getCloseDay() != null) {
			payload.setDayTo(AbsoluteDate.of(payload.getCloseDay().toLocalDate().minusDays(1)));
		}

		EntityNTT entityNTT = utilityService.getEntityById(env, entityId, false, false, Operation.CLOSE_ENTITY);

		securityService.checkPermission(env, entityId, true, Operation.CLOSE_ENTITY, ErrorField.ENTITY);

		if (payload.getDayTo() == null) {
			payload.setDayTo(AbsoluteDate.of("99991231"));
		}

		Boolean pastDateCloseAllowed = internalConfigService.getBooleanValue(env.getTenantId(), InternalConfigKeys.ALLOW_PAST_CLOSE_DATE.getKey());
		if (Boolean.FALSE.equals(pastDateCloseAllowed) && payload.getDayTo().toLocalDate().isBefore(env.getReferenceDate().toLocalDate().minusDays(1))) {
			throw new InvalidEndDateException(Status.BAD_REQUEST, Operation.CLOSE_ENTITY, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}
		if (mandatesDAO.checkExclusivePartiesAfterDate(env.getTenantId(), entityId, payload.getDayTo()) != 0) {
			throw new EntityWithExclusivePartyExecption(Status.BAD_REQUEST, Operation.CLOSE_ENTITY, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					utilityService.getFormatedErrorMsg(entityNTT.getCode(), entityNTT.getName()));
		}

		// An entity can be closed before it's start date
		// if(entityNTT.getDay_from().compareTo(payload.getDayTo()) > 0) {
		// throw new ValidationDateException(Status.BAD_REQUEST, Operation.CLOSE_ENTITY, ErrorField.ENTITY,
		// this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		// }

		entityDAO.useTransaction(dao -> {
			entityDAO.outdateEntityById(env.getTenantId(), env.getUser().getUserId(), entityNTT.getEntity_id());
			// notifica rabbit
			UpdatedObjectDataNTT data = UpdatedObjectDataNTT.builder()
					.entityTypeCode(entityNTT.getEntity_type().getCode())
					.dayFrom(entityNTT.getDay_from())
					.dayTo(payload.getDayTo())
					.build();

			if (entityNTT.getDay_from().toLocalDate().isBefore(payload.getDayTo().toLocalDate())) {
				EntityNTT newEntityNTT = EntityNTT.builder()
						.pkid(entityDAO.nextSequenceValEntityDetailsId())
						.entity_id(entityId)
						.code(entityNTT.getCode())
						.name(entityNTT.getName())
						.entity_type(entityNTT.getEntity_type())
						.registry_party_id(entityNTT.getRegistry_party_id())
						.description(entityNTT.getDescription())
						.parent_id(entityNTT.getParent_id())
						.path(entityNTT.getPath())
						.day_from(entityNTT.getDay_from())
						.day_to(payload.getDayTo())
						.build();

				entityDAO.insertEntityDetails(newEntityNTT, env.getUser().getUserId());
				revisionService.insertOperation(env, Revision.UPDATE_ENTITY, null, entityNTT.getPath(), null, data);
			} else {
				revisionService.insertOperation(env, Revision.REMOVE_ENTITY, null, entityNTT.getPath(), null, data);
			}
		});
		return true;
	}

	private Integer booleanToInteger(Boolean x) {
		return Boolean.TRUE.equals(x) ? 1 : 0;
	}

}
