package com.abacogroup.partiesaclserver.bundles;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.dynamicdocuments.services.SavedDocumentType;
import com.abacogroup.partiesaclserver.bundles.models.DDocSettingMessage;
import com.abacogroup.partiesaclserver.core.exceptions.bundles.BundleDynamicDocException;
import com.abacogroup.partiesaclserver.core.queues.UpdateMandateStatusQueue;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.DocTypeRelationDAO;
import com.abacogroup.partiesaclserver.db.dao.I18nDAO;
import com.abacogroup.partiesaclserver.db.dao.TypesDAO;
import com.abacogroup.partiesaclserver.db.ntt.DocTypeRelationNTT;
import com.abacogroup.partiesaclserver.db.ntt.EntityTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.I18nNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyTypeNTT;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DynamicDocConfigMessageProcessor implements ConfigMessageProcessor {

	private final TypesDAO typesDAO;
	private final DocTypeRelationDAO docTypeRelationDAO;
	private final I18nDAO i18nDAO;
	private final DocumentTypeService documentTypeService;
	private final UpdateMandateStatusQueue updateMandateStatusQueue;
	
	private static final String SETTINGS = "settings";
	private static final String DELETE = "delete";
	private static final String DD = "dd";

	private final ObjectMapper objectMapper = new ObjectMapper().disable(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES);

	private static final String USER = "importFromBundle";

	private static final String I18N_TABLENAME = "pacl_doc_type_relations";
	private static final String I18N_FIELDNAME = "definition_code";

	public DynamicDocConfigMessageProcessor(DAOContainer container, DocumentTypeService documentTypeService, 
			UpdateMandateStatusQueue updateMandateStatusQueue) {
		this.typesDAO = container.getTypesDAO();
		this.docTypeRelationDAO = container.getDocTypeRelationDAO();
		this.i18nDAO = container.getI18nDAO();
		this.documentTypeService = documentTypeService;
		this.updateMandateStatusQueue = updateMandateStatusQueue;
	}

	@Override
	public String getDomainName() {
		return "dynamic-documents";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		String tenantId = message.getTenantId();

		List<Path> paths = message.getConfigFiles();
		var map = paths.stream()
				.filter(p -> FilenameUtils.isExtension(p.getFileName().toString(), "json"))
				.collect(Collectors.groupingBy(x -> {
					if (StringUtils.startsWithIgnoreCase(x.getFileName().toString(), SETTINGS)) {
						if (StringUtils.containsIgnoreCase(x.getFileName().toString(), DELETE)) {
							return DELETE;
						} else {
							return SETTINGS;
						}
					} else {
						return DD;
					}
				},
						Collectors.toCollection(ArrayList::new)));

		map.getOrDefault(DELETE, new ArrayList<>()).stream().map(Path::toFile).forEach(path -> this.deleteSettings(tenantId, path));
		map.getOrDefault(DD, new ArrayList<>()).forEach(path -> this.saveDocumentType(tenantId, path));
		map.getOrDefault(SETTINGS, new ArrayList<>()).stream().map(Path::toFile).forEach(path -> this.saveSettings(tenantId, path));
	}

	private void saveSettings(String tenantId, File file) {
		log.info("processing DD settings from bundle file: {}", file);
		try {
			List<DDocSettingMessage> settings = objectMapper.readValue(file, new TypeReference<List<DDocSettingMessage>>() {});
			// save the docType relations
			saveDocTypeRelations(tenantId, settings);

		} catch (Exception e) {
			throw new BundleDynamicDocException(String.format("error processing DD settings from bundle file '%s': '%s'", file, e.getMessage()));
		}
	}

	private void deleteSettings(String tenantId, File file) {
		try {

			List<DDocSettingMessage> settings = objectMapper.readValue(file, new TypeReference<List<DDocSettingMessage>>() {});

			// expire the docType relations
			deleteDocTypeRelations(tenantId, settings);

		} catch (Exception e) {
			throw new BundleDynamicDocException(String.format("error processing DD settings from bundle file '%s': '%s'", file, e.getMessage()));
		}
	}

	private SavedDocumentType saveDocumentType(String tenantId, Path path) {
		log.info("processing DD from bundle file: {}", path);
		try {
			String jsonContent = Files.readString(path);

			return documentTypeService.saveDocumentType(tenantId, jsonContent, USER);
		} catch (IOException e) {
			throw new BundleDynamicDocException(String.format("error saving %s: %s", path, e.getMessage()));
		}
	}

	private void deleteDocTypeRelations(String tenantId, List<DDocSettingMessage> entries) {
		ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).build();
		entries.stream().forEach(relation -> docTypeRelationDAO.useTransaction(handle -> {
			Long entityTypeId = getEntityTypeIdByCode(env, relation.getEntityTypeCode());
			Long partyTypeId = getPartyTypeIdByCode(env, relation.getPartyTypeCode());

			handle.findByTypeIdsScopeCodeRevisionCodeAndDefCode(env, entityTypeId, partyTypeId, relation.getScopeCode(), relation.getRevisionCode(), relation.getDefinitionCode())
			.ifPresentOrElse(e -> handle.expireRow(e, USER),
					() -> {
						throw new BundleDynamicDocException(String.format("cannot remove docTypeRelation not found '%s' !", relation.toString()));
					});
		}));
		updateMandateStatus(env, entries);
	}

	private void saveDocTypeRelations(String tenantId, List<DDocSettingMessage> entries) {
		ServiceSupportEnv env = ServiceSupportEnv.builder()
				.tenantId(tenantId)
				.build();
		entries.forEach(entry -> {
			DocumentDefinition documentDefinition = this.getDocumentDefinition(tenantId, entry.getDefinitionCode());

			Long entityTypeId = getEntityTypeIdByCode(env, entry.getEntityTypeCode());
			Long partyTypeId = getPartyTypeIdByCode(env, entry.getPartyTypeCode());

			DocTypeRelationNTT entity = DocTypeRelationNTT.builder()
					.pkid(docTypeRelationDAO.nextSequenceVal())
					.revisionCode(entry.getRevisionCode())
					.scopeCode(entry.getScopeCode())
					.displayOrder(entry.getDisplayOrder() == null ? 0 : entry.getDisplayOrder())
					.entityTypeId(entityTypeId)
					.partyTypeId(partyTypeId)
					.definitionCode(documentDefinition.getCode())
					.build();

			docTypeRelationDAO.findByTypeIdsScopeCodeRevisionCodeAndDefCode(env, entityTypeId, partyTypeId, entity.getScopeCode(), entity.getRevisionCode(), entity.getDefinitionCode())
			.ifPresentOrElse(e -> {
				throw new BundleDynamicDocException(String.format("DocTypeRelation '%s' already exists for tenant '%s'!",
						entry.toString(), tenantId));
			},
					() -> {
						docTypeRelationDAO.insert(tenantId, USER, entity);
						upsertDocTypeTranslastions(tenantId, documentDefinition.getCode() ,documentDefinition.getTitle());
					});

		});
		
		updateMandateStatus(env, entries);
	}

	/**
	 * Upsert translation for doctype relation translation
	 * @param tenantId
	 * @param docCode
	 * @param title
	 */
	private void upsertDocTypeTranslastions(String tenantId, String docCode, Map<String, String> title) {
		if(tenantId == null || title == null)
			return;
		
		title.keySet().stream().forEach(k -> {
			I18nNTT i18nNTT = I18nNTT.builder()
					.tenant_id(tenantId) 
			        .table_name(I18N_TABLENAME)
			        .field_name(I18N_FIELDNAME)
			        .i18n_value(docCode)
			        .lang(k)
			        .i18n_text(title.get(k)) 
				.build();
			
			// delete + insert -> upsert
			i18nDAO.deleteI18nLang(i18nNTT);
			i18nDAO.insert(i18nNTT);
			
		});
		
	}

	private Long getEntityTypeIdByCode(ServiceSupportEnv env, String code) {
		if(StringUtils.isBlank(code)) {
			return null;
		}
		EntityTypeNTT type = typesDAO.getEntityTypeByCode(env, code);

		if(type == null) {
			throw new BundleDynamicDocException("Entity type with code '" + code + "' not found for tenant '" + env.getTenantId() + "'.\n");
		}
		return type.getId();
	}

	private Long getPartyTypeIdByCode(ServiceSupportEnv env, String code) {
		if(StringUtils.isBlank(code)) {
			return null;
		}

		PartyTypeNTT type = typesDAO.getPartyTypeByCode(env, code);

		if(type == null) {
			throw new BundleDynamicDocException("Party type with code '" + code + "' not found for tenant '" + env.getTenantId() + "'.\n");
		}
		return type.getId();
	}

	private DocumentDefinition getDocumentDefinition(String tenantId, String definitionCode) {
		return documentTypeService.getDocumentDefinition(tenantId, definitionCode)
				.orElseThrow(() -> new BundleException(String.format("docType '%s' does not exists", definitionCode)));
	}
	
	private void updateMandateStatus(ServiceSupportEnv env, List<DDocSettingMessage> entries) {
		
		Map<Long, List<Long>> typeMap = getTypeMap(env, entries);
		
		typeMap.forEach((entityTypeId, partyTypeList) -> partyTypeList
					.stream()
					.forEach(partyTypeId -> updateMandateStatusQueue.add(env.getTenantId(), USER, entityTypeId, partyTypeId))
			);
	}

	private Map<Long, List<Long>> getTypeMap(ServiceSupportEnv env, List<DDocSettingMessage> entries) {
		Map<Long, List<Long>> typeMap = new HashMap<>();
		if(entries == null) {
			return typeMap;
		}
		
		entries.stream().forEach(e -> {
			Long entityTypeId = getEntityTypeIdByCode(env, e.getEntityTypeCode());
			Long partyTypeId = getPartyTypeIdByCode(env, e.getPartyTypeCode());
			
			List<Long> partytypelList = typeMap.getOrDefault(entityTypeId, new ArrayList<>());
			if(!partytypelList.contains(partyTypeId)) {
				partytypelList.add(partyTypeId);
			}
			
			typeMap.put(entityTypeId, partytypelList);
		});
		
		return typeMap;
	}
}
