package com.abacogroup.partiesaclserver.core;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.partiesaclserver.client.PartyRegistryClient;
import com.abacogroup.partiesaclserver.client.ReqContext;
import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.InternalConfigKeys;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.InternalConfigException;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidPayloadException;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidUserException;
import com.abacogroup.partiesaclserver.core.exceptions.PartyRegistryResponseException;
import com.abacogroup.partiesaclserver.core.exceptions.entity.InvalidPartyNameException;
import com.abacogroup.partiesaclserver.core.models.PartyRegistryResponse;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.MandatesDAO;
import com.abacogroup.partiesaclserver.db.ntt.pub.MandatesCountNTT;
import com.abacogroup.partiesaclserver.resources.pub.req.PartySearchFilters;
import com.abacogroup.partiesaclserver.resources.res.PaclPartySearchResponse;
import com.abacogroup.partiesaclserver.resources.res.PaclPartySearchResponseInfinite;

import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class PartyRegistryClientService {
	
	private MandatesDAO mandatesDAO;
	private PartyRegistryClient partyRegistryClient;
	private UtilityService utilityService;
	private InternalConfigService internalConfigService;
	private SecurityService securityService;
	private ErrorDescriptionsService errorDescriptionsService;
	
	private static final String SPECIAL_ALL_SUBJECT_CODE = "*";
	private static final String SPECIAL_ALL_SUBJECT_NAME = "ALL SUBJECTS";
	
	private static final String GET_ALL_PARTY_URL_PATH = "/{tenant}/public/v1/parties";
	private static final String GET_PARTY_URL_PATH = "/{tenant}/public/v1/parties/{partyId}";
	
	public PartyRegistryClientService(DAOContainer container, WebTarget partiesRegistryWT, UtilityService utilityService, InternalConfigService internalConfigService,
			SecurityService securityService, ErrorDescriptionsService errorDescriptionsService) {
		this.mandatesDAO = container.getMandatesDAO();
		this.errorDescriptionsService = errorDescriptionsService;
		this.utilityService = utilityService;
		this.securityService = securityService;
		this.internalConfigService = internalConfigService;
		
		this.partyRegistryClient = new PartyRegistryClient(partiesRegistryWT);
	}
	
	public String getName(ServiceSupportEnv env, String registryPartyId) {
		
		if(SPECIAL_ALL_SUBJECT_CODE.equals(registryPartyId))
			return SPECIAL_ALL_SUBJECT_NAME;
		
		String lang = env.getLang();
		String authToken = env.getUser().getAuthToken();
		String tenantId = env.getTenantId();
		
		if (lang == null || authToken == null || tenantId == null) {
			throw new InvalidUserException(Status.BAD_REQUEST, Operation.GET_PARTY_NAME, ErrorField.PARTY_REGISTRY, 
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}
		
		PartyRegistryResponse partyRegistryResponse = null;
		Response response = null;
		
		HashMap<String, Object> pathVariables = new HashMap<>();
		pathVariables.put("tenant", tenantId);
		pathVariables.put("partyId", registryPartyId);

		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		
		ReqContext reqContext = new ReqContext(env.getUser(), env.getLang());

		try {
			response = partyRegistryClient.get(GET_PARTY_URL_PATH, reqContext, pathVariables, queryParams, new GenericType<>() { });
			
			if (response.getStatus() == 200) {
				response.bufferEntity();
				partyRegistryResponse = response.readEntity(PartyRegistryResponse.class);
			} else {
				Map<String, Object> errorResponse = response.readEntity(new GenericType<HashMap<String, Object>>() {
				});
				String errorCode = (String) errorResponse.get("errorCode");
				
				throw new InvalidPartyNameException(Status.BAD_REQUEST, Operation.GET_PARTY_NAME, ErrorField.PARTY_REGISTRY, 
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), errorCode);
			}
			
		} catch (Exception e) {
			throw new InvalidPartyNameException(Status.BAD_REQUEST, Operation.GET_PARTY_NAME, ErrorField.PARTY_REGISTRY, 
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), null);
		}
		
		if(partyRegistryResponse.getFirstName() != null) {
			return partyRegistryResponse.getLastName() + " " + partyRegistryResponse.getFirstName();
		}
		
		return partyRegistryResponse.getLastName();
	}
	
	public PaclPartySearchResponseInfinite searchParties(ServiceSupportEnv env,
			PartySearchFilters partySearchReq, String nextKey) {
		env = utilityService.checkEnv(env);

		String lang = env.getLang();
		String authToken = env.getUser().getAuthToken();
		String tenantId = env.getTenantId();

		if (lang == null || authToken == null || tenantId == null) {
			throw new InvalidUserException(Status.BAD_REQUEST, Operation.GET_ALL_PARTY, ErrorField.PARTY_REGISTRY, 
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		if (StringUtils.isBlank(partySearchReq.getCode()) && StringUtils.isBlank(partySearchReq.getFullName())) {
			throw new InvalidPayloadException(Status.BAD_REQUEST, Operation.GET_ALL_PARTY, ErrorField.PARTY_REGISTRY, 
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}	

		PaclPartySearchResponseInfinite partyRegistryResponse = null;
		Response response = null;
		
		HashMap<String, Object> pathVariables = new HashMap<>();
		pathVariables.put("tenant", tenantId);

		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		queryParams.add("referenceDate", env.getReferenceDate());
		queryParams.add("code", partySearchReq.getCode());
		queryParams.add("fullName", partySearchReq.getFullName());
		queryParams.add("nextKey", nextKey);
		
		List<String> defaultQueryParams = internalConfigService.getValuesList(tenantId, String.class, InternalConfigKeys.PARTY_REGISTRY_SEARCH_ADDITIONAL_QUERY_PARAM.getKey());
		defaultQueryParams.forEach(p -> {
			String[] param = p.split("=");
			if(param.length != 2) {
				throw new InternalConfigException(Status.BAD_REQUEST, Operation.GET_ALL_PARTY, ErrorField.CONFIG,
						this.errorDescriptionsService.getTenantErrorDescriptions(tenantId), lang, InternalConfigKeys.PARTY_REGISTRY_SEARCH_ADDITIONAL_QUERY_PARAM.getKey());
			
			}
			queryParams.add(param[0], param[1]);
		});
		
		ReqContext reqContext = new ReqContext(env.getUser(), env.getLang());

		try {
			response = partyRegistryClient.get(GET_ALL_PARTY_URL_PATH, reqContext, pathVariables, queryParams, new GenericType<>() { });

			if (response.getStatus() == 200) {
				response.bufferEntity();
				partyRegistryResponse = response.readEntity(PaclPartySearchResponseInfinite.class);
			} else {
				Map<String, Object> errorResponse = response.readEntity(new GenericType<HashMap<String, Object>>() {
				});
				String errorCode = (String) errorResponse.get("errorCode");

				throw new PartyRegistryResponseException (Status.BAD_REQUEST, Operation.GET_ALL_PARTY, ErrorField.PARTY_REGISTRY, 
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), errorCode);
			}

		} catch (Exception e) {
			throw new PartyRegistryResponseException(Status.BAD_REQUEST, Operation.GET_ALL_PARTY, ErrorField.PARTY_REGISTRY, 
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), null);
		}

		return completePartyRegistryResponse(env, partyRegistryResponse);

	}

	private PaclPartySearchResponseInfinite completePartyRegistryResponse(ServiceSupportEnv env, PaclPartySearchResponseInfinite response) {

		Boolean isAdmin = securityService.checkAdminPermission(env, Operation.GET_PARTY);
		Integer includeLevels = internalConfigService.getIntegerValue(env.getTenantId(), InternalConfigKeys.HIERARCHICAL_INHERITANCE_LEVEL.getKey());
		Boolean inheritManagement = internalConfigService.getBooleanValue(env.getTenantId(), InternalConfigKeys.INHERIT_MANAGEMENT.getKey());

		for (PaclPartySearchResponse party : response.getRecords()) {

			MandatesCountNTT count = mandatesDAO.getMandatesCount(env, party.getId().toString(), 
					Boolean.TRUE.equals(isAdmin) ? 1 : 0, includeLevels, Boolean.TRUE.equals(inheritManagement) ? 1 : 0);

			if(count.getMandatesCount() != 0) {
				party.setHasMandates(true);
				party.setMandatesCount(count.getMandatesCount());
				party.setManageCount(count.getManageCount());
				party.setExclusiveCount(count.getExclusiveCount());
			}
		}

		return response;
	}
}
