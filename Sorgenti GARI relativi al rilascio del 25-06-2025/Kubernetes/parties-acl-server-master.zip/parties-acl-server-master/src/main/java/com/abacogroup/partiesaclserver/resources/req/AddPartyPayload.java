package com.abacogroup.partiesaclserver.resources.req;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class AddPartyPayload {
	@Schema(description = "Party's id", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	@NotBlank
	private String id;
	
	@Schema(description = "Party's type code", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	@NotBlank
	private String partyTypeCode;
	
	@Schema(description = "Start validity date - format YYYYMMDD", type = "string", format = "YYYYMMDD", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private AbsoluteDate dayFrom;
	
	@Schema(description = "End validity date - format YYYYMMDD", type = "string", format = "YYYYMMDD")
	private AbsoluteDate dayTo;
}
