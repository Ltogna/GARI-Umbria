package com.abacogroup.partiesaclserver.core.models;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ApiVersion {
	private String name;
	private String description;
	private String version;
	private String buildtime;
	private String commitId;
}
