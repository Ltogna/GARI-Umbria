package com.abacogroup.partiesaclserver.core.enums;

public enum DocTypeRelationScope {
	 MANDATES;
}
