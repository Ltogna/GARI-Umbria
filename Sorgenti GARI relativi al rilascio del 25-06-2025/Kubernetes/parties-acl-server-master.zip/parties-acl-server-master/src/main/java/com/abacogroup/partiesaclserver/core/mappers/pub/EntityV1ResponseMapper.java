package com.abacogroup.partiesaclserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.resources.pub.res.EntityV1;
import com.abacogroup.partiesaclserver.resources.res.Entity;

@Mapper(uses = EntityTypeV1ResponseMapper.class)
public interface EntityV1ResponseMapper {
	
	EntityV1ResponseMapper INSTANCE = Mappers.getMapper(EntityV1ResponseMapper.class);
	
	@InheritInverseConfiguration()	
	EntityV1 toResponseV1(Entity entity);
	
}