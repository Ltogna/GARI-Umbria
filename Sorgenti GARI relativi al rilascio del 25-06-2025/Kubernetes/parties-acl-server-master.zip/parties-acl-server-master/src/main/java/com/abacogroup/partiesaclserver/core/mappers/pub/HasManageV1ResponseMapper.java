package com.abacogroup.partiesaclserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.resources.pub.res.HasManageV1Res;
import com.abacogroup.partiesaclserver.resources.res.HasManageRes;

@Mapper
public interface HasManageV1ResponseMapper {
	
	HasManageV1ResponseMapper INSTANCE = Mappers.getMapper(HasManageV1ResponseMapper.class);
	
	@InheritInverseConfiguration()	
	HasManageV1Res toResponseV1(HasManageRes entity);
	
}