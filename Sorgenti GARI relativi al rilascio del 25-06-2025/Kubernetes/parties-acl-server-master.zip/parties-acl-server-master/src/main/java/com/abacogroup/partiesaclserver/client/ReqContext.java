package com.abacogroup.partiesaclserver.client;

import java.util.Optional;

import com.abacogroup.dropwizard.auth.sso2.User;

import io.dropwizard.auth.PrincipalImpl;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NonNull;

/**
 * dto per la propagazione delle informazioni di richiesta:
 * <p>
 * - user
 * <p>
 * - lang
 * <p>
 * - tenant
 * <p>
 * per limitazioni relative a @BeanParam deve essere creato nella resource:
 */
@Data
@AllArgsConstructor
public class ReqContext {

  @NonNull
  private User user;
  private String lang;

  public ReqContext(@NonNull String tenantId, @NonNull String username, String lang) {
    this.user = new User(username, tenantId);
    this.lang = lang;
  }

  public String getUsername() {
    return Optional.ofNullable(user)
        .map(PrincipalImpl::getName)
        .orElseThrow();
  }

  public String getTenantId() {
    return Optional.ofNullable(user)
        .map(User::getTenant)
        .orElseThrow();
  }

  public String getLang() {
    return Optional.ofNullable(lang).orElse("en");
  }

}

