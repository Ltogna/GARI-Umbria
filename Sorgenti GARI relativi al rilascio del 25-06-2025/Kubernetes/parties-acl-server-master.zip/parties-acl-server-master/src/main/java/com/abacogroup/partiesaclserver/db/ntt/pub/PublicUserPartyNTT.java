package com.abacogroup.partiesaclserver.db.ntt.pub;

import org.jdbi.v3.core.mapper.Nested;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PublicUserPartyNTT {
	private String party_id;
	private AbsoluteDate day_from;
	private AbsoluteDate day_to;
	private Long entity_id;
	private Long mandate_id;
	
	private PublicPartyTypeNTT party_type;

	private String userId;
	private String userRole;
	
	@Nested("ppt")
	public PublicPartyTypeNTT getParty_type() {
		return party_type;
	}
}
