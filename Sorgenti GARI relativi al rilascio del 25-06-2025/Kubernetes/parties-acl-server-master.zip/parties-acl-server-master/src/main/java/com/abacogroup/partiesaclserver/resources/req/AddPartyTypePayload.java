package com.abacogroup.partiesaclserver.resources.req;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class AddPartyTypePayload {
	@Schema(description = "Code of party type", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String code;
	
	@Schema(description = "1: if exclusive", type = "boolean", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Boolean fl_exclusive;
	
	@Schema(description = "1: if manage", type = "boolean", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Boolean fl_manage;
	
	@ArraySchema(schema = @Schema(description = "Entities List ", implementation = String.class, requiredMode = RequiredMode.REQUIRED))
	@NotNull
	@Valid
	private List<String> entityTypeCodes;
	
	@ArraySchema(schema = @Schema(description = "translations", requiredMode = RequiredMode.REQUIRED))
	@NotNull
	@Size(min = 1)
	@Valid
	private Map<String, String> translations;
}
