package com.abacogroup.partiesaclserver.db.ntt;

import com.abacogroup.partiesaclserver.core.enums.AnomalyLevel;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnomalyCategoriesNTT {
	private String group_code;
	private String code;
	private AnomalyLevel level;
	private Integer fl_exclude;
}
