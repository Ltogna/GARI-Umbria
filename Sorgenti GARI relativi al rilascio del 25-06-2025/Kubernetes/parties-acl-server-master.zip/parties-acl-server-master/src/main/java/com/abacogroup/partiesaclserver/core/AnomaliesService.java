package com.abacogroup.partiesaclserver.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.partiesaclserver.core.enums.AnomalyLevel;
import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.InternalConfigKeys;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidIdException;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidUserException;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.dao.AnomalyCategoriesDAO;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.ntt.AnomalyCategoriesNTT;
import com.abacogroup.partiesaclserver.resources.res.anomalies.AnomaliesList;
import com.abacogroup.partiesaclserver.resources.res.anomalies.Anomaly;

import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AnomaliesService {

	private WebTarget anomaliesRegistryWT;
	private InternalConfigService internalConfigService;
	private ErrorDescriptionsService errorDescriptionsService;
	private UtilityService utilityService;
	private AnomalyCategoriesDAO anomalyCategoriesDAO;

	private static final String DEFAULT_LANG_CODE = "en";

	public AnomaliesService(DAOContainer container, WebTarget anomaliesRegistryWT, InternalConfigService internalConfigService, UtilityService utilityService, ErrorDescriptionsService errorDescriptionsService) {
		this.anomaliesRegistryWT = anomaliesRegistryWT;
		this.internalConfigService = internalConfigService;
		this.errorDescriptionsService = errorDescriptionsService;
		this.utilityService = utilityService;
		this.anomalyCategoriesDAO = container.getAnomalyCategoriesDAO();
	}

	public AnomaliesList getPartyAnomalies(ServiceSupportEnv e, String partyId) {
		ServiceSupportEnv env = utilityService.checkEnv(e);	
		
		if (env == null) {
			throw new InvalidUserException(Status.BAD_REQUEST, Operation.GET_ANOMALIES, ErrorField.ENV,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);
		}

		String lang = env.getLang();
		String authToken = env.getUser().getAuthToken();
		String tenantId = env.getUser().getTenant();

		if (lang == null || authToken == null || tenantId == null) {
			throw new InvalidUserException(Status.BAD_REQUEST, Operation.GET_ANOMALIES, ErrorField.ENV,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), DEFAULT_LANG_CODE);
		}

		if (partyId == null || partyId.isBlank()) {
			throw new InvalidIdException(Status.BAD_REQUEST, Operation.GET_ANOMALIES, ErrorField.ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), DEFAULT_LANG_CODE);
		}

		String anomalyEntityCode = internalConfigService.getStringValue(tenantId, InternalConfigKeys.ANOMALIES_PARTY_CODE_KEY.getKey());
		
		return getAnomalies(env, partyId, anomalyEntityCode);
	}
	
	public AnomaliesList getEntityAnomalies(ServiceSupportEnv env, String entityId) {
		if (env == null) {
			throw new InvalidUserException(Status.BAD_REQUEST, Operation.GET_ANOMALIES, ErrorField.ENV,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);
		}

		String lang = env.getLang();
		String authToken = env.getUser().getAuthToken();
		String tenantId = env.getUser().getTenant();

		if (lang == null || authToken == null || tenantId == null) {
			throw new InvalidUserException(Status.BAD_REQUEST, Operation.GET_ANOMALIES, ErrorField.ENV,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), DEFAULT_LANG_CODE);
		}

		if (entityId == null || entityId.isBlank()) {
			throw new InvalidIdException(Status.BAD_REQUEST, Operation.GET_ANOMALIES, ErrorField.ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), DEFAULT_LANG_CODE);
		}

		//String anomalyEntityCode = internalConfigService.getStringValue(tenantId, InternalConfigKeys.ANOMALIES_ENTITY_CODE_KEY.getKey());
		//return getAnomalies(env, entityId, anomalyEntityCode);
		return AnomaliesList.builder().anomalies_list(new ArrayList<>()).build();
	}
	
	public AnomaliesList getUserAnomalies(ServiceSupportEnv env, String userId) {
		if (env == null) {
			throw new InvalidUserException(Status.BAD_REQUEST, Operation.GET_ANOMALIES, ErrorField.ENV,
					this.errorDescriptionsService.getTenantErrorDescriptions(StringUtils.EMPTY), DEFAULT_LANG_CODE);
		}

		String lang = env.getLang();
		String authToken = env.getUser().getAuthToken();
		String tenantId = env.getUser().getTenant();

		if (lang == null || authToken == null || tenantId == null) {
			throw new InvalidUserException(Status.BAD_REQUEST, Operation.GET_ANOMALIES, ErrorField.ENV,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), DEFAULT_LANG_CODE);
		}

		if (userId == null || userId.isBlank()) {
			throw new InvalidIdException(Status.BAD_REQUEST, Operation.GET_ANOMALIES, ErrorField.ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), DEFAULT_LANG_CODE);
		}

		//String anomalyEntityCode = internalConfigService.getStringValue(tenantId, InternalConfigKeys.ANOMALIES_USER_CODE_KEY.getKey());
		//return getAnomalies(env, userId, anomalyEntityCode);
		return AnomaliesList.builder().anomalies_list(new ArrayList<>()).build();
	}

	private AnomaliesList getAnomalies(ServiceSupportEnv env, String anomalyEntityId, String anomalyEntityCode) {
		AnomaliesList result = AnomaliesList.builder().anomalies_list(new ArrayList<>()).build();

		Response response = null;

		//GET /anomaly-registry/{tenant}/public/v1/anomalies/{entityCode}?entityId={Id}
		try {
			response = anomaliesRegistryWT
					.resolveTemplate("tenant", env.getTenantId())
					.resolveTemplate("anomalyEntityCode", anomalyEntityCode)
					.resolveTemplate("anomalyEntityId", anomalyEntityId)

					.request(MediaType.APPLICATION_JSON_TYPE)
					.accept(MediaType.APPLICATION_JSON_TYPE)
					.header("accept-language", env.getLang())
					.header("Authorization", String.format("JWT %s", env.getUser().getAuthToken()))
					.get();

			if (response.getStatus() == 200) {
				response.bufferEntity();
				List<Anomaly> anomaliesResponse = response.readEntity(new GenericType<List<Anomaly>>() {
				});

				List<Anomaly> anomaliesFiltered = new ArrayList<>();
				anomaliesResponse.forEach(anomaly -> {
					AnomalyCategoriesNTT anomalyCategory = anomalyCategoriesDAO.findByTenantGroupCodeAndCode(env.getTenantId(), anomaly.getType().getGroupCode(),
							anomaly.getType().getCode());

					AnomalyLevel level = anomalyCategory != null ? anomalyCategory.getLevel() : AnomalyLevel.UNCATEGORIZED;

					if ((anomalyCategory != null && anomalyCategory.getFl_exclude() != 1) ||
							(anomalyCategory == null
							&& this.internalConfigService.getBooleanValue(env.getTenantId(), InternalConfigKeys.FL_SHOW_UNCATEGORIZED_ANOMALY_TYPES_KEY.getKey()))) {

						anomaly.getType().setLevel(level);
						anomaliesFiltered.add(anomaly);
					}
				});

				result.setAnomalies_list(anomaliesFiltered);
			}

			else {
				Map<String, Object> errorResponse = response.readEntity(new GenericType<HashMap<String, Object>>() {
				});
				String errorMsg = (String) errorResponse.get("message");

				result.setError(errorMsg);

				log.error("Error : {} ", errorMsg);
			}

		} catch (Exception e) {
			result.setError(e.getMessage());
			log.error("Error message '{}', {} ", e.getMessage(), e);
		} finally {
			if (response != null)
				response.close();
		}

		return result;
	}



}