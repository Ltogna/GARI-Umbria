package com.abacogroup.partiesaclserver.core.exceptions.documents;

import static org.apache.commons.text.StringEscapeUtils.escapeHtml4;

import java.util.Map;

import jakarta.ws.rs.core.Response.Status;

import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractException;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class InvalidDocumentException extends AbstractException {

	private static final long serialVersionUID = 5683637794083193490L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_DOCUMENT_DEFINITION;

	public InvalidDocumentException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang, String documentCode) {
		super(code, new InvalidPartyNameExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
		
		String msg = String.format(this.getBody().getMessage(), escapeHtml4(documentCode));
		this.getBody().setMessage(msg);
		log.error(this.getBody().getLogErrorMessage());
	}

	@Schema(description = "Error loading definition")
	public static class InvalidPartyNameExceptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = -6196402541546172600L;

		public InvalidPartyNameExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
