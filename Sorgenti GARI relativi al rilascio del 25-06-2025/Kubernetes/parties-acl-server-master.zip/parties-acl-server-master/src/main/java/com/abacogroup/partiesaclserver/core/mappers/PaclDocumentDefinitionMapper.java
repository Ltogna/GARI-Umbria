package com.abacogroup.partiesaclserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.partiesaclserver.resources.res.PaclDocumentDefinition;

@Mapper
public interface PaclDocumentDefinitionMapper {
	
	PaclDocumentDefinitionMapper INSTANCE = Mappers.getMapper(PaclDocumentDefinitionMapper.class);
	
	@InheritInverseConfiguration
	@Mapping(target = "bucketName", ignore = true)
	PaclDocumentDefinition toPaclDocumentDefinition(DocumentDefinition dd);

}
