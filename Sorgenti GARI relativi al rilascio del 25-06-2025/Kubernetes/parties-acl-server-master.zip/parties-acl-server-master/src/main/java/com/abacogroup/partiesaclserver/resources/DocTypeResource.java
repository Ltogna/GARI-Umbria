package com.abacogroup.partiesaclserver.resources;

import java.util.List;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.partiesaclserver.core.DocTypeService;
import com.abacogroup.partiesaclserver.core.enums.DocTypeRelationScope;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.resources.res.DocTypeRelation;
import com.abacogroup.partiesaclserver.resources.res.PaclDocumentDefinition;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PRIV + "/doc-types")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Document types", description = "Operations on Dynamic documents definitions")
public class DocTypeResource {

	private final DocTypeService docTypeService;

	public DocTypeResource(DocTypeService docTypeService) {
		this.docTypeService = docTypeService;
	}

	@GET
	@Path("/scopes/{scopeCode}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "Get the list of dynamic document types filtered by scope")
	@ApiResponse(responseCode = "200", description = "Get the list of dynamic document types filtered by scope", useReturnTypeSchema = true)
	public List<DocTypeRelation> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "scope code of document") @PathParam("scopeCode") DocTypeRelationScope scopeCode,
			@Parameter(description = "entity id") @QueryParam("entityId") Long entityId,
			@Parameter(description = "mandate id") @QueryParam("mandateId") Long mandateId) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.build();
		
		return docTypeService.getByScopeCodeAndId(env, entityId, mandateId, scopeCode);
	}

	@GET
	@Path("/{definitionCode}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(summary = "document definition", description = "Get document definition by its code")
	@ApiResponse(responseCode = "200", description = "Successfully, returns a document definition", useReturnTypeSchema = true)
	public PaclDocumentDefinition getDefinition(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@PathParam("definitionCode") String definitionCode) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.build();
		
		return docTypeService.getDefinition(env, definitionCode);
	}
}
