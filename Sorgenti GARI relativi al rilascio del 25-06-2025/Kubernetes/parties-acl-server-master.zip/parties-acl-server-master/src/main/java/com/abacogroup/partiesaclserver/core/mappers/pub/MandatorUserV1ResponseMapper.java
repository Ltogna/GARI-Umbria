package com.abacogroup.partiesaclserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.resources.pub.res.MandatorUserV1;
import com.abacogroup.partiesaclserver.resources.res.MandatorUser;

@Mapper
public interface MandatorUserV1ResponseMapper {

	MandatorUserV1ResponseMapper INSTANCE = Mappers.getMapper(MandatorUserV1ResponseMapper.class);
		
	@InheritInverseConfiguration()
	MandatorUserV1 toResponseV1(MandatorUser type);	
	
}
