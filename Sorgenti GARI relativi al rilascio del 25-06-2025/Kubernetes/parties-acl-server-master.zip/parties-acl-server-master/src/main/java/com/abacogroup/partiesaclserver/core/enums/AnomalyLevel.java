package com.abacogroup.partiesaclserver.core.enums;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "The level of anomaly")
public enum AnomalyLevel {
	UNCATEGORIZED,
	INFO,
	WARN,
	DANGER
}
