package com.abacogroup.partiesaclserver.dispatch.payload;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdatePACLPayload {
	
	private String tenantId;
	private LocalDateTime dtOperation;
	private Long lastKey;
	private String notes;
	

}
