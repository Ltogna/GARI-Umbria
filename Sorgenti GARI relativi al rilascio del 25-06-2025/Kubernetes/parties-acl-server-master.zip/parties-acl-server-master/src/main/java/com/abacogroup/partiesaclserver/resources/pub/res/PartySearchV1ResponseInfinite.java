package com.abacogroup.partiesaclserver.resources.pub.res;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PartySearchV1ResponseInfinite {
	
	private String nextKey;
	private List<PartySearchV1Response> records;
	private Long count; 

}
