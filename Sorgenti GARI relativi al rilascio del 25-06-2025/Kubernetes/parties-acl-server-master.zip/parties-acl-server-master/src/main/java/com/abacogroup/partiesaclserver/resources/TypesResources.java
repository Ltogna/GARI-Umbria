package com.abacogroup.partiesaclserver.resources;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partiesaclserver.core.TypesService;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidPayloadException.InvalidPayloadExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.type.EntitiesWithTypeExecption.EntitiesWithTypeExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.type.PartiesWithTypeExecption.PartiesWithTypeExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeAlreadyExistExecption.TypeAlreadyExistExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeNotFoundExecption.TypeNotFoundExecptionBody;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.resources.req.AddEntityTypePayload;
import com.abacogroup.partiesaclserver.resources.req.AddPartyTypePayload;
import com.abacogroup.partiesaclserver.resources.req.UpdatePartyTypePayload;
import com.abacogroup.partiesaclserver.resources.res.EntityType;
import com.abacogroup.partiesaclserver.resources.res.PartyType;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PRIV)
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "types", description = "Operations on types")
public class TypesResources {

	private TypesService typesService;

	public TypesResources(TypesService typesService) {
		this.typesService = typesService;
	}

	@POST
	@Path("/entities/types")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "Add Entity type", tags = { "types" })
	@ApiResponse(responseCode = "200", description = "Type added successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "409", description = "Type code already exists", content = @Content(schema = @Schema(implementation = TypeAlreadyExistExecptionBody.class)))
	public Boolean addEntitytype(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@NotNull @Valid AddEntityTypePayload payload) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return typesService.addEntityTypes(env, payload);
	}

	@DELETE
	@Path("/entities/types/{id}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "Delete Entity type", tags = { "types" })
	@ApiResponse(responseCode = "200", description = "Type deleted successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			TypeNotFoundExecptionBody.class, EntitiesWithTypeExecptionBody.class})))
	public Boolean deleteEntitytype(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity type id") @PathParam("id") Long id,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return typesService.deleteEntitytype(env, id);
	}

	@GET
	@Path("/entities/types")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "Get all Entity types", tags = { "types" })
	@ApiResponse(responseCode = "200", description = "Get all Entity types", useReturnTypeSchema = true)
	public InfiniteListResults<EntityType> getAllEntityTypes(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity type code") @QueryParam("code") String code,
			@Parameter(description = "true if include compatible party type list") @DefaultValue("false")@QueryParam("partyTypeList") Boolean partyTypeList,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("next_key") String nextKey) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return typesService.getAllEntityTypes(env, code, partyTypeList, nextKey);
	}

	@GET
	@Path("/entities/types/{id}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "Get Entity type by id", tags = { "types" })
	@ApiResponse(responseCode = "200", description = "Get Entity type by id", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "404", description = "Type code not found", content = @Content(schema = @Schema(implementation = TypeNotFoundExecptionBody.class)))
	public EntityType getEntityTypeById(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity type id") @PathParam("id") Long id,
			@Parameter(description = "true if include compatible party type list") @DefaultValue("false")@QueryParam("partyTypeList") Boolean partyTypesList,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return typesService.getEntityTypeById(env, id, partyTypesList);
	}

	@POST
	@Path("/parties/types")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "Add Party type", tags = { "types" })
	@ApiResponse(responseCode = "200", description = "Type added successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			TypeNotFoundExecptionBody.class, TypeAlreadyExistExecptionBody.class})))
	public Boolean addPartyType(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@NotNull @Valid AddPartyTypePayload payload) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return typesService.addPartyType(env, payload);
	}

	@DELETE
	@Path("/parties/types/{id}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "Delete Party type", tags = { "types" })
	@ApiResponse(responseCode = "200", description = "Type deleted successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			TypeNotFoundExecptionBody.class, PartiesWithTypeExecptionBody.class})))
	public Boolean deletePartytype(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Party type id") @PathParam("id") Long id,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return typesService.deletePartytype(env, id);
	}

	@PUT
	@Path("/parties/types/{id}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "update Party type", tags = { "types" })
	@ApiResponse(responseCode = "200", description = "Type updated successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			TypeNotFoundExecptionBody.class, InvalidPayloadExceptionBody.class})))
	public Boolean updatePartyType(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Party type id") @PathParam("id") Long id,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@NotNull @Valid UpdatePartyTypePayload payload) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return typesService.updatePartyType(env, id, payload);
	}

	@GET
	@Path("/parties/types")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "Get Party type", tags = { "types" })
	@ApiResponse(responseCode = "200", description = "Get Party type", useReturnTypeSchema = true)
	public InfiniteListResults<PartyType> getAllPartyTypes(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Party type code") @QueryParam("code") String code,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("next_key") String nextKey) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return typesService.getAllPartyTypes(env, code, nextKey);
	}

	@GET
	@Path("/parties/types/{id}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "Get Party type by id", tags = { "types" })
	@ApiResponse(responseCode = "200", description = "Get Party type by id", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "404", description = "Type code not found", content = @Content(schema = @Schema(implementation = TypeNotFoundExecptionBody.class)))
	public PartyType getPartyTypeById(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Party type id") @PathParam("id") Long id,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return typesService.getPartyTypeById(env, id);
	}


}