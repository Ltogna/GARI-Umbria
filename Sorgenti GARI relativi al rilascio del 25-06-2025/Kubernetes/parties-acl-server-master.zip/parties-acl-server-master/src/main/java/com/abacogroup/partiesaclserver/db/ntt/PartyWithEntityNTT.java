package com.abacogroup.partiesaclserver.db.ntt;

import org.jdbi.v3.core.mapper.Nested;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@EqualsAndHashCode(callSuper = true)
public class PartyWithEntityNTT extends PartyNTT {
	
	private EntityNTT entity;
	private Boolean editable;
	private Boolean revocable;
	
	@Nested("ped")
	public EntityNTT getEntity() {
		return entity;
	}
}
