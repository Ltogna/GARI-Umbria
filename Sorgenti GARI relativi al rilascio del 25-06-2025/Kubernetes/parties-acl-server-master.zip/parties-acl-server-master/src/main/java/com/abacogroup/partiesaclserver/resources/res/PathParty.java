package com.abacogroup.partiesaclserver.resources.res;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class PathParty {	
	@Schema(description = "Party id", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String partyId;
	
	@Schema(description = "Mandate id", type = "long", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Long mandateId;
	
	@Schema(description = "1: if party is exclusive", type = "boolean", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Boolean flExclusive;
	
	@Schema(description = "1: if party can be manage", type = "boolean", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Boolean flManage;
	
	@Schema(description = "Start validity date - format YYYYMMDD", type = "string", format = "YYYYMMDD", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private AbsoluteDate dayFrom;
	
	@Schema(description = "End validity date - format YYYYMMDD", type = "string", format = "YYYYMMDD", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private AbsoluteDate dayTo;
}
