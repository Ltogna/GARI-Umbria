package com.abacogroup.partiesaclserver.resources.pub.res;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@EqualsAndHashCode(callSuper = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class UserPartyV1 extends PartyV1 {
	
	@Schema(description = "Mandator user's id", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	@NotBlank
	private String userId;
	
	@Schema(description = "Mandator user's role", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String userRole;
	
	@Schema(description = "Entity id", type = "integer", requiredMode = RequiredMode.REQUIRED)
	private Long entityId;
	
}
