package com.abacogroup.partiesaclserver.core.exceptions.entity;

import java.util.Map;

import jakarta.ws.rs.core.Response.Status;

import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractException;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EntityWithParentExecption extends AbstractException{

	private static final long serialVersionUID = -7042838456954883313L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.ENTITY_WITH_PARENT;

	public EntityWithParentExecption(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang, String child, String parent) {
		super(code, new EntityWithParentExecptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
		
		String msg = String.format(this.getBody().getMessage(), child, parent);
		this.getBody().setMessage(msg);
		log.error(this.getBody().getLogErrorMessage());
	}

	@Schema(description = "Entity has parent")
	public static class EntityWithParentExecptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = -230796541489800056L;

		public EntityWithParentExecptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
