package com.abacogroup.partiesaclserver.resources.pub;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partiesaclserver.core.exceptions.PastDateNotallowedException.PastDateNotallowedExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.ValidationDateException.ValidationDateExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityCodeRequiredExecption.EntityCodeRequiredExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityExistsWithRegistryPartyIdExecption.EntityExistsWithRegistryPartyIdExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityNameExecption.EntityNameExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityNotFoundExecption.EntityNotFoundExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeNotFoundExecption.TypeNotFoundExecptionBody;
import com.abacogroup.partiesaclserver.core.pub.EntitiesV1Service;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.resources.ResourceConstants;
import com.abacogroup.partiesaclserver.resources.pub.req.CreateEntityPayloadV1;
import com.abacogroup.partiesaclserver.resources.pub.req.EntitySearchFiltersV1;
import com.abacogroup.partiesaclserver.resources.pub.res.EntityV1;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.PermitAll;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PUB)
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "public", description = "Public resources")
public class PublicEntitiesResources {

	private final EntitiesV1Service entitiesService;

	public PublicEntitiesResources(EntitiesV1Service entitiesService) {
		this.entitiesService = entitiesService;
	}
	
	@POST
	@Path("/entities")
	@RolesAllowed({"PACL|ADMIN"})
	@Operation(description = "Creates new entity", tags = { "entities" })
	@ApiResponse(responseCode = "200", description = "Entity created successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			TypeNotFoundExecptionBody.class, EntityCodeRequiredExecptionBody.class, PastDateNotallowedExceptionBody.class,
			ValidationDateExceptionBody.class, EntityNameExecptionBody.class, EntityExistsWithRegistryPartyIdExecptionBody.class,
			EntityCodeRequiredExecptionBody.class})))
	public Long publicCreateEntity(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@NotNull @Valid CreateEntityPayloadV1 payload) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return entitiesService.createEntity(env, payload);
	}
	
	@GET
	@Path("/entities")
	@PermitAll
	@Operation(description = "Gets all entities", tags = { "public" })
	@ApiResponse(responseCode = "200", description = "Gets all entities", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			EntityNotFoundExecptionBody.class})))
	public InfiniteListResults<EntityV1> getAllEntities(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("next_key") String nextKey,
			@BeanParam EntitySearchFiltersV1 filter) {
		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(filter.getReferenceDate())
				.build();

		return entitiesService.getAllEntities(env, filter, nextKey);
	}
	
	@GET
	@Path("/entities/{entityCode}")
	@PermitAll
	@Operation(description = "Gets entity by Code", tags = { "public" })
	@ApiResponse(responseCode = "200", description = "Gets entity by code", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			EntityNotFoundExecptionBody.class})))
	public EntityV1 getEntityByCode(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity Code") @PathParam("entityCode") String entityCode,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "if true skip entities permission check") @QueryParam("skipPermissionCheck") @DefaultValue("true") Boolean skipPermissionCheck
	) {
		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return entitiesService.getEntityByCode(env, entityCode, skipPermissionCheck);
	}
}
