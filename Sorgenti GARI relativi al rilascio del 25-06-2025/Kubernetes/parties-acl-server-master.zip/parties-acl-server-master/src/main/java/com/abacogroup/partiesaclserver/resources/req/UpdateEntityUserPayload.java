package com.abacogroup.partiesaclserver.resources.req;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class UpdateEntityUserPayload {
	@Schema(description = "User's new role", type = "string")
	private String role;
	
	@Schema(description = "Description of the entity", type = "string")
	private String description;
	
}
