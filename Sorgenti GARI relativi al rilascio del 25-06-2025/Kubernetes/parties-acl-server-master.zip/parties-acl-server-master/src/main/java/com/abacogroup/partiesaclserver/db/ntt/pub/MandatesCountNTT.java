package com.abacogroup.partiesaclserver.db.ntt.pub;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MandatesCountNTT {
	
	private Integer mandatesCount;
	private Integer manageCount;
	private Integer exclusiveCount;
	
}
