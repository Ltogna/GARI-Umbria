package com.abacogroup.partiesaclserver.bundles.models;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PartyType {

	private String code;
	private Boolean fl_exclusive;
	private Boolean fl_manage;
	private Map<String, String> translations;
	private List<String> entity_type_codes;
}
