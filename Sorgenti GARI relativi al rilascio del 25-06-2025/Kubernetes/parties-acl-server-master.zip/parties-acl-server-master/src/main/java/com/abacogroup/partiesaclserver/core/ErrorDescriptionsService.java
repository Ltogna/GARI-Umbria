package com.abacogroup.partiesaclserver.core;


import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.I18nDAO;
import com.abacogroup.partiesaclserver.db.ntt.I18nNTT;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;

public class ErrorDescriptionsService {

	private I18nDAO i18nDAO;

	public static final String DEFAULT_LANG_CODE = "en";

	private static final String ERROR_DESCRIPTIONS_TABLE_NAME = "pacl_errors";
	private static final String ERROR_DESCRIPTIONS_FIELD_NAME = "error_code";

	private LoadingCache<String, Map<String, Map<String, String>>> errorDescriptionsCache;

	public ErrorDescriptionsService(DAOContainer dc) {
		this.i18nDAO = dc.getI18nDAO();

		errorDescriptionsCache = Caffeine.newBuilder()
				.maximumSize(1000)
				.expireAfterWrite(Duration.ofMinutes(60))
				.build(this::loadErrorDescriptions);
	}

	public Map<String, Map<String, String>> getTenantErrorDescriptions(String tenantId) {
		return errorDescriptionsCache.get(tenantId);
	}

	private Map<String, Map<String, String>> loadErrorDescriptions(String tenantId) {

		List<I18nNTT> errors = i18nDAO.findAllI18nByTenantTableAndField(tenantId, ERROR_DESCRIPTIONS_TABLE_NAME, ERROR_DESCRIPTIONS_FIELD_NAME);

		Map<String, Map<String, String>> result = new HashMap<>();

		errors.stream().forEach(errorDescription -> {
			if (result.containsKey(errorDescription.getI18n_value())) {
				result.get(errorDescription.getI18n_value()).put(errorDescription.getLang(), errorDescription.getI18n_text());
			} else {
				result.put(errorDescription.getI18n_value(), new HashMap<>(Map.of(errorDescription.getLang(), errorDescription.getI18n_text())));
			}
		});

		return result;
	}
}
