package com.abacogroup.partiesaclserver.resources.pub.req;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class AddMandatorUserPayloadV1 {	
	@Schema(description = "User's name", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotBlank
	private String username;

	@Schema(description = "User's role", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotBlank
	private String role;

	@Schema(description = "Notes for user", type = "string")
	private String description;
}
