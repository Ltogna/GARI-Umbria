package com.abacogroup.partiesaclserver.resources;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partiesaclserver.core.MandatesService;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidEndDateException.InvalidEndDateExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidPayloadException.InvalidPayloadExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.NothingToUpdateException.NothingToUpdateExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.PastDateNotallowedException.PastDateNotallowedExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.ValidationDateException;
import com.abacogroup.partiesaclserver.core.exceptions.ValidationDateException.ValidationDateExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.ValidationDatesConflictException.ValidationDatesConflictExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityNotFoundExecption.EntityNotFoundExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityWithoutAdminExecption.EntityWithoutAdminExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.ExclusivePartyException.ExclusivePartyExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.MandateNotFoundException.MandateNotFoundExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.PartyInEntityException.PartyInEntityExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.UserInEntityException.UserInEntityExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.UserNotAssociatedWithEntityException.UserNotAssociatedWithEntityExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.UserNotAssociatedWithPartyException.UserNotAssociatedWithPartyExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.security.UserNotAllowedExecption.UserNotAllowedExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.type.GenericTypeExecption.GenericTypeExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeNotCompatibleExecption.TypeNotCompatibleExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeNotFoundExecption.TypeNotFoundExecptionBody;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.resources.req.AddMandatorUserPayload;
import com.abacogroup.partiesaclserver.resources.req.AddPartyPayload;
import com.abacogroup.partiesaclserver.resources.req.CloseDatePayload;
import com.abacogroup.partiesaclserver.resources.req.PartyEntitySearchFilters;
import com.abacogroup.partiesaclserver.resources.req.UpdateEntityUserPayload;
import com.abacogroup.partiesaclserver.resources.res.Entity;
import com.abacogroup.partiesaclserver.resources.res.MandatorUser;
import com.abacogroup.partiesaclserver.resources.res.Party;
import com.abacogroup.partiesaclserver.resources.res.PartyWithEntity;
import com.abacogroup.partiesaclserver.resources.res.UserParty;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PRIV)
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "mandates", description = "Operations on mandates")
public class MandatesResources {

	private MandatesService mandatesService;

	public MandatesResources(MandatesService mandatesService) {
		this.mandatesService = mandatesService;
	}

	@POST
	@Path("/entities/{entityId}/parties")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "Add parties to Entity", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "Parties added successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			EntityNotFoundExecptionBody.class, UserNotAllowedExecptionBody.class, TypeNotFoundExecptionBody.class,
			TypeNotCompatibleExecptionBody.class, ExclusivePartyExecptionBody.class, PartyInEntityExecptionBody.class,
			PastDateNotallowedExceptionBody.class, ValidationDateExceptionBody.class, ValidationDatesConflictExceptionBody.class,
			InvalidEndDateExceptionBody.class})))
	public Long addPartyToEntity(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity id") @PathParam("entityId") Long entityId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@NotNull @Valid AddPartyPayload payload) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.addPartyToEntity(env, entityId, payload);
	}

	@POST
	@Path("/entities/{entityId}/users")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "Add user to Entity", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "User added successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			EntityNotFoundExecptionBody.class, UserNotAllowedExecptionBody.class, PastDateNotallowedExceptionBody.class,
			ValidationDateException.class, ValidationDatesConflictExceptionBody.class, UserInEntityExecptionBody.class})))
	public Boolean addUsersToEntity(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity id") @PathParam("entityId") Long entityId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@NotNull @Valid AddMandatorUserPayload payload) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.addUsersToEntity(env, entityId, payload, false, false);
	}

	@DELETE
	@Path("/entities/{entityId}/users/{userId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "Remove user from Entity", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "User removed successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			EntityNotFoundExecptionBody.class, UserNotAllowedExecptionBody.class, UserNotAssociatedWithEntityExecptionBody.class,
			EntityWithoutAdminExecptionBody.class})))
	public String removeUsersFromEntity(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity id") @PathParam("entityId") Long entityId,
			@Parameter(description = "Mandator user id") @PathParam("userId") String mandatorUserId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.removeUserFromEntity(env, entityId, mandatorUserId, false, false);
	}

	@PUT
	@Path("/entities/{entityId}/users/{userId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "Update user in entity", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "User updated successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			EntityNotFoundExecptionBody.class, UserNotAllowedExecptionBody.class, UserNotAssociatedWithEntityExecptionBody.class, 
			PastDateNotallowedExceptionBody.class, InvalidPayloadExceptionBody.class, NothingToUpdateExceptionBody.class,
			InvalidEndDateExceptionBody.class, ValidationDateException.class, ValidationDatesConflictExceptionBody.class,
			EntityWithoutAdminExecptionBody.class})))
	public Boolean updateEntityUser(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity id") @PathParam("entityId") Long entityId,
			@Parameter(description = "Mandator user id") @PathParam("userId") String mandatorUserId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@NotNull @Valid UpdateEntityUserPayload payload) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.updateEntityUser(env, entityId, mandatorUserId, payload, false, false);
	}
	
	@POST
	@Path("/parties/{partyId}/users")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "Add user to party", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "User added successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			EntityNotFoundExecptionBody.class, UserNotAllowedExecptionBody.class, PastDateNotallowedExceptionBody.class,
			ValidationDateException.class, ValidationDatesConflictExceptionBody.class, UserInEntityExecptionBody.class,
			GenericTypeExecptionBody.class})))
	public Boolean addUserToParty(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Party id") @PathParam("partyId") String partyId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@NotNull @Valid AddMandatorUserPayload payload) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.addUserToSingleParty(env, partyId, payload);
	}
	
	@DELETE
	@Path("/parties/{partyId}/users/{userId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "Remove user from Party", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "User removed successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			UserNotAllowedExecptionBody.class, UserNotAssociatedWithEntityExecptionBody.class})))
	public String removeUsersFromParty(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Party id") @PathParam("partyId") String partyId,
			@Parameter(description = "Mandator user id") @PathParam("userId") String mandatorUserId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.removeUserFromSingleParty(env, partyId, mandatorUserId);
	}
	
	@PUT
	@Path("/parties/{partyId}/users/{userId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "Update user in Party", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "User updated successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			UserNotAllowedExecptionBody.class, UserNotAssociatedWithEntityExecptionBody.class, PastDateNotallowedExceptionBody.class,
			InvalidPayloadExceptionBody.class, NothingToUpdateExceptionBody.class, InvalidEndDateExceptionBody.class,
			ValidationDateException.class, ValidationDatesConflictExceptionBody.class})))
	public Boolean updatePartyUser(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Party id") @PathParam("partyId") String partyId,
			@Parameter(description = "Mandator user id") @PathParam("userId") String mandatorUserId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@NotNull @Valid UpdateEntityUserPayload payload) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.updateSinglePartyUser(env, partyId, mandatorUserId, payload);
	}

	@GET
	@Path("/users/{userId}/parties")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "GET parties by Entity user id", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "GET parties by Entity user id", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			UserNotAssociatedWithPartyExecptionBody.class})))
	public InfiniteListResults<UserParty> getAllPartiesByUserId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Mandator user id") @PathParam("userId") String mandatorUserId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("next_key") String nextKey) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.getAllPartiesByUserId(env, mandatorUserId, null, null, nextKey);
	}

	@GET
	@Path("/users/{userId}/parties/{partyId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "GET parties by mandator user id", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "GET parties by Entity user id", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			UserNotAllowedExecptionBody.class})))
	public InfiniteListResults<UserParty> getEntityByPartyId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Mandator user id") @PathParam("userId") String mandatorUserId,
			@Parameter(description = "Party id") @PathParam("partyId") String partyId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("next_key") String nextKey) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.getAllPartiesByUserId(env, mandatorUserId, partyId, null, nextKey);
	}
	
	@GET
	@Path("/entities/{entityId}/users")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "GET users by entity id", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "GET users by entity id", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			UserNotAllowedExecptionBody.class})))
	public InfiniteListResults<MandatorUser> getAllUsersByEntityId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity id") @PathParam("entityId") Long entityId,
			@Parameter(description = "Filter by username") @QueryParam("username") String usernameFilter,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("next_key") String nextKey) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.getAllUsersByEntityId(env, entityId, usernameFilter, nextKey);
	}
	
	@GET
	@Path("/entities/{entityId}/users/{userId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "GET user by entity id", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "GET user by entity id", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			UserNotAllowedExecptionBody.class, UserNotAssociatedWithEntityExecptionBody.class})))
	public MandatorUser getUserByEntityId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity id") @PathParam("entityId") Long entityId,
			@Parameter(description = "Mandator user id") @PathParam("userId") String userId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.getUserByEntityId(env, entityId, userId);
	}
	
	@GET
	@Path("/entities/{entityId}/parties")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "GET parties by entity id", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "GET parties by entity id", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			UserNotAllowedExecptionBody.class})))
	public InfiniteListResults<Party> getAllPartiesByEntityId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity id") @PathParam("entityId") Long entityId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "Set true to get history") @DefaultValue("false")@QueryParam("history") Boolean history,
			@Parameter(description = "If true includes parties of children") @DefaultValue("false")@QueryParam("include_children") Boolean includeChildren,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("next_key") String nextKey) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.getAllPartiesByEntityId(env, entityId, history, includeChildren, null, nextKey);
	}
	
	@GET
	@Path("/parties/{partyId}/entities")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "GET entities by party id", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "GET entities by party id", useReturnTypeSchema = true)
	public InfiniteListResults<PartyWithEntity> getAllEntitiesByPartyId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Party id") @PathParam("partyId") String partyId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("next_key") String nextKey,
			@BeanParam PartyEntitySearchFilters filters) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.getAllEntitiesByPartyId(env, partyId, filters, null, nextKey);
	}
	
	@GET
	@Path("/mandates/{mandateId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "GET entities by party id", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "GET entities by party id", useReturnTypeSchema = true)
	public PartyWithEntity getEntityByMandateId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "mandate id") @PathParam("mandateId") Long mandateId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.getEntityByMandateId(env, mandateId);
	}
	
	@GET
	@Path("/users/{userId}/entities")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "GET entities by user id", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "GET entities by user id", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			MandateNotFoundExecptionBody.class})))
	public InfiniteListResults<Entity> getEntitiesByUserId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "User id") @PathParam("userId") String userId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "Set true to get history") @DefaultValue("false")@QueryParam("history") Boolean history,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("next_key") String nextKey) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.getEntitiesByUserId(env, userId, history, nextKey);
	}
	
	@POST
	@Path("/mandates/{mandateId}/closedate")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "Close mandate", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "Mandate closed successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			UserNotAllowedExecptionBody.class, InvalidEndDateExceptionBody.class, ValidationDateException.class,
			ValidationDatesConflictExceptionBody.class, ExclusivePartyExecptionBody.class})))
	public Boolean closeMandate(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "mandate id") @PathParam("mandateId") Long mandateId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@NotNull @Valid CloseDatePayload payload) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.closeMandate(env, mandateId, payload);
	}
	
	@DELETE
	@Path("/mandates/{mandateId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "Remove party from Entity", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "Party removed successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			MandateNotFoundExecptionBody.class, UserNotAllowedExecptionBody.class})))
	public Long removeMandateFromEntity(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Mandate id") @PathParam("mandateId") Long mandateId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.removeMandateFromEntity(env, mandateId);
	}


}
