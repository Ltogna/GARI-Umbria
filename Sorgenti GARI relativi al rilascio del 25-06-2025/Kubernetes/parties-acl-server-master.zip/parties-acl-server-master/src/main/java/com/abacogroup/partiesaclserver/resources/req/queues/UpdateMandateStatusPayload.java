package com.abacogroup.partiesaclserver.resources.req.queues;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UpdateMandateStatusPayload {

	private String tenantId;
	private String username;
	
	private Long entityTypeId;
	private Long partyTypeId;
}
