package com.abacogroup.partiesaclserver.resources.res;

import java.util.List;

import com.abacogroup.dynamicdocuments.bean.SummaryFieldDefinition;
import com.abacogroup.partiesaclserver.core.enums.DocTypeRelationScope;
import com.abacogroup.partiesaclserver.core.enums.Revision;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class DocTypeRelation {

	private String definitionCode;  //docType
	private String definitionCodeI18n;

	private Long entityId;  
	private Long mandateId; 
	private Integer displayOrder;
	private DocTypeRelationScope scope;
	private List<Revision> revisionCodes;

	private int flDocPresent; // flag used to indicate if there is already documents inserted of this docType

	private  boolean multiple;
	private List<SummaryFieldDefinition> summaryFieldDefinitions;
	
}
