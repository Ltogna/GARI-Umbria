package com.abacogroup.partiesaclserver.core.exceptions.type;

import java.util.Map;

import jakarta.ws.rs.core.Response.Status;

import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractException;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class GenericTypeExecption extends AbstractException{

	private static final long serialVersionUID = -7042838456954883313L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.GENERIC_TYPE_ERROR;

	public GenericTypeExecption(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new GenericTypeExecptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
		
		log.error(this.getBody().getLogErrorMessage());
	}

	@Schema(description = "Generic type error!")
	public static class GenericTypeExecptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = -230796541489800056L;

		public GenericTypeExecptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
