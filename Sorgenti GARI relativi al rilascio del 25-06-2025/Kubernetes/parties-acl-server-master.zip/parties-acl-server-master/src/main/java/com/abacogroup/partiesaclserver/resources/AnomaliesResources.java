package com.abacogroup.partiesaclserver.resources;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partiesaclserver.core.AnomaliesService;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidIdException.InvalidIdExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidUserException.InvalidUserExceptionBody;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.resources.res.anomalies.AnomaliesList;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PRIV + "/anomalies")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "anomalies", description = "Operations on anomalies")
public class AnomaliesResources {
	
	private AnomaliesService anomaliesService;

	public AnomaliesResources(AnomaliesService anomaliesService) {
		this.anomaliesService = anomaliesService;
	}

	@GET
	@Path("/parties/{partyId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "Get the anomalies of party")
			@ApiResponse(responseCode = "200", description = "Get the anomalies of party", useReturnTypeSchema = true)
			@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
					InvalidIdExceptionBody.class, InvalidUserExceptionBody.class })))
		public AnomaliesList getEntityAnomalies(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Party id") @PathParam("partyId") String partyId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return anomaliesService.getPartyAnomalies(env, partyId);
	}
}