package com.abacogroup.partiesaclserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partiesaclserver.resources.pub.res.PartyWithEntityV1;
import com.abacogroup.partiesaclserver.resources.res.PartyWithEntity;

@Mapper(uses = {EntityTypeV1ResponseMapper.class, PartyTypeV1ResponseMapper.class, EntityV1ResponseMapper.class, PartyV1ResponseMapper.class})
public interface PartyWithEntityV1ResponseMapper {
	
	PartyWithEntityV1ResponseMapper INSTANCE = Mappers.getMapper(PartyWithEntityV1ResponseMapper.class);

	@InheritInverseConfiguration()
	PartyWithEntityV1 toResponseV1(PartyWithEntity res);

	default InfiniteListResults<PartyWithEntityV1> toResponseV1InfiniteList(InfiniteListResults<PartyWithEntity> res) {
		return res.map(this::toResponseV1);
	}
	
}
