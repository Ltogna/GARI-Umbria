package com.abacogroup.partiesaclserver.db.ntt;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MandatorUserNTT {
	private Long pkid;
	private Long entity_id;
	private String user_id;
	private String username;
	private String role_code;
	private String description;
}
