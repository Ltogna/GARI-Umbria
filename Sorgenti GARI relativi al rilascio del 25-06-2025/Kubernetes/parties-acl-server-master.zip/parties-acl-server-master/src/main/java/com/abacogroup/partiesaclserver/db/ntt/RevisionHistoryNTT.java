package com.abacogroup.partiesaclserver.db.ntt;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RevisionHistoryNTT {
	private Long pkid;
	private String tenant_id;
	private String operation;
	private String object_id;
	private String old_path;
	private String new_path;
	private Object object_data;
	private AbsoluteDate revision_date;
}
