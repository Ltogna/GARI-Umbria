package com.abacogroup.partiesaclserver.resources.pub.res;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class HasManageV1Res {
	private Boolean canRead;
}
