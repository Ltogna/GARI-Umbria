package com.abacogroup.partiesaclserver.resources.res;

import com.abacogroup.partyregistry.api.v1.PartySearchResponseV1;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder(setterPrefix = "set")
@NoArgsConstructor
public class PaclPartySearchResponse extends PartySearchResponseV1{

	@Builder.Default
	private Boolean hasMandates = false;
	
	@Builder.Default
	private Integer mandatesCount = 0;
	
	@Builder.Default
	private Integer manageCount = 0;

	@Builder.Default
	private Integer exclusiveCount = 0;
	
}
