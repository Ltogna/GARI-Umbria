package com.abacogroup.partiesaclserver.resources.res.anomalies;

import com.abacogroup.partiesaclserver.core.enums.AnomalyLevel;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class AnomalyType {
	@Schema(description = "Group code of anomaly", type = "string")
	private String groupCode;

	@Schema(description = "Code of anomaly", type = "string")
	private String code;

	@Schema(description = "I18n code of anomaly", type = "string")
	private String i18nCode;

	@Schema(description = "level of anomaly", type = "string", allowableValues = { "DANGER", "WARN", "INFO",
			"UNCATEGORIZED" }, implementation = AnomalyLevel.class)
	private AnomalyLevel level;
}
