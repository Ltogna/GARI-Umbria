package com.abacogroup.partiesaclserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.resources.pub.req.AddMandatorUserPayloadV1;
import com.abacogroup.partiesaclserver.resources.req.AddMandatorUserPayload;

@Mapper
public interface AddMandatorUserPayloadV1Mapper {

	AddMandatorUserPayloadV1Mapper INSTANCE = Mappers.getMapper(AddMandatorUserPayloadV1Mapper.class);

	@InheritInverseConfiguration()
	AddMandatorUserPayload toResponse(AddMandatorUserPayloadV1 payload);

	
	AddMandatorUserPayloadV1 toResponseV1(AddMandatorUserPayload dto);

}