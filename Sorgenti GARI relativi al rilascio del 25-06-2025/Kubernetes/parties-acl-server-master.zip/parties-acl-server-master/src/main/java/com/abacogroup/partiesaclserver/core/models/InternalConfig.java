package com.abacogroup.partiesaclserver.core.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class InternalConfig extends Config {
	private Boolean fl_client;
	private String name;
	private String description;
	private String type;
	private Boolean is_array;
}
