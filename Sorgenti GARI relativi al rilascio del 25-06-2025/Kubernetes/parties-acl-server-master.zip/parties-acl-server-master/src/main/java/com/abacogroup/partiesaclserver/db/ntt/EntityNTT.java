package com.abacogroup.partiesaclserver.db.ntt;

import org.jdbi.v3.core.mapper.Nested;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EntityNTT {
	private Long pkid;
	private Long entity_id;
	private String name;
	private String code;
	private EntityTypeNTT entity_type;
	private String registry_party_id;
	private String description;
	private Long parent_id;
	private String parent_name;
	private String parent_code;
	private String path;
	private AbsoluteDate day_from;
	private AbsoluteDate day_to;
	private String current_user_role;
	private Boolean editable;
	private Boolean closed;
	
	@Nested("pet")
	public EntityTypeNTT getEntity_type() {
		return entity_type;
	}
}
