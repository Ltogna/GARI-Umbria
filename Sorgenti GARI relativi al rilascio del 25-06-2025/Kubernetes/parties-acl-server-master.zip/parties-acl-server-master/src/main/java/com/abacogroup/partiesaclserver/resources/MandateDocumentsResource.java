package com.abacogroup.partiesaclserver.resources;

import java.util.Map;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partiesaclserver.core.MandateDocumentService;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.resources.res.MandateDocumentRes;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HEAD;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path(ResourceConstants.API_PRIV + "/mandates/{mandateId}/documents")
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "Document types", description = "Operations on Dynamic documents definitions")
public class MandateDocumentsResource {

	private final MandateDocumentService mandateDocumentService;

	public MandateDocumentsResource(MandateDocumentService mandateDocumentService) {
		this.mandateDocumentService = mandateDocumentService;
	}

	@GET
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(summary = "List of documents of a specific type", description = "Get list of documents filtered with criteria")
	@ApiResponse(responseCode = "200", description = "Successfully, returns a list of documents (sorted/filtered)", useReturnTypeSchema = true)
	public InfiniteListResults<MandateDocumentRes> search(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "mandate id") @PathParam("mandateId") Long mandateId,
			@Parameter(description = "DD definition Code") @QueryParam("definitionCode") String definitionCode,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
			@Parameter(description = "page size") @QueryParam("pageSize") @DefaultValue("10") Integer pageSize) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.build();

		return mandateDocumentService.search(env, mandateId, definitionCode, nextKey, pageSize);
	}
	
	@GET
	@Path("/{documentId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(summary = "Find document by code and id", description = "Returns document based on its definition code and document id")
	@ApiResponse(responseCode = "200", description = "Document successfully found", useReturnTypeSchema = true)
	public MandateDocumentRes getByDocumentId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "mandate id") @PathParam("mandateId") Long mandateId,
			@Parameter(description = "document ID") @PathParam("documentId") Long documentId) {
		
		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.build();

		return mandateDocumentService.getMandateDocument(env, mandateId, documentId);
	}

	@GET
	@Path("/{documentId}/attachments/{bucket}/{fileId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(summary = "get document attachment content", description = "Returns document attachment content")
	@ApiResponse(responseCode = "200", description = "The file bytes",
	content = @Content(mediaType = MediaType.APPLICATION_OCTET_STREAM, schema = @Schema(type = "string", format = "binary")))
	public Response getDocumentFileContent(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "mandate id") @PathParam("mandateId") Long mandateId,
			@Parameter(description = "document ID") @PathParam("documentId") Long documentId,
			@PathParam("bucket") String bucket,
			@PathParam("fileId") String fileId) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.build();

		return mandateDocumentService.getDocumentFileContent(env, mandateId, documentId, fileId);
	}

	@HEAD
	@Path("/{documentId}/attachments/{bucket}/{fileId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(summary = "get document attachment metadata", description = "Returns document attachment metadata in header")
	@ApiResponse(responseCode = "200", description = "The file metadata in header")
	public Response getDocumentFileMetadata(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "mandate id") @PathParam("mandateId") Long mandateId,
			@Parameter(description = "document ID") @PathParam("documentId") Long documentId,
			@PathParam("bucket") String bucket,
			@PathParam("fileId") String fileId) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.build();
		
		return mandateDocumentService.getDocumentFileMetadata(env, mandateId, documentId, fileId);
	}

	@POST
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(summary = "Create document", description = "Insert a new document")
	@ApiResponse(responseCode = "200", description = "Successfully, the document has been correctly created", useReturnTypeSchema = true)
	public MandateDocumentRes insert(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "mandate id") @PathParam("mandateId") Long mandateId,
			@NotNull @Valid InsertDocument document) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.build();

		return mandateDocumentService.insert(env, mandateId, document);
	}

	@PUT
	@Path("/{documentId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(summary = "update document", description = "update an existing document")
	@ApiResponse(responseCode = "200", description = "document updated", useReturnTypeSchema = true)
	public MandateDocumentRes update(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "mandate id") @PathParam("mandateId") Long mandateId,
			@PathParam("documentId") Long documentId,
			@NotNull @Valid Document updateReq) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.build();

		return mandateDocumentService.update(env, mandateId, documentId, updateReq);
	}

	@DELETE
	@Path("/{documentId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(summary = "delete document", description = "delete an existing document by expiring it")
	@ApiResponse(responseCode = "200", description = "document expired")
	public Response delete(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@PathParam("tenant") String tenantId,
			@Parameter(description = "mandate id") @PathParam("mandateId") Long mandateId,
			@PathParam("documentId") Long documentId) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.build();

		mandateDocumentService.expire(env, mandateId, documentId);
		return Response.ok(Map.of()).build();
	}

}
