package com.abacogroup.partiesaclserver.core.exceptions.entity;

import java.util.Map;

import jakarta.ws.rs.core.Response.Status;

import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractException;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EntityExistsWithRegistryPartyIdExecption extends AbstractException{

	private static final long serialVersionUID = 2986260552933116233L;

	private static final ErrorCode ERROR_CODE = ErrorCode.ENTITY_EXISTS_WITH_REGISTRY_PARTY_ID;

	public EntityExistsWithRegistryPartyIdExecption(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new EntityExistsWithRegistryPartyIdExecptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
		
		log.error(this.getBody().getLogErrorMessage());
	}

	@Schema(description = "Entity already exists with given registry-party id")
	public static class EntityExistsWithRegistryPartyIdExecptionBody extends AbstractExceptionBody {

		private static final long serialVersionUID = 1607352454020317074L;

		public EntityExistsWithRegistryPartyIdExecptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
