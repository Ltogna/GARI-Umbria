package com.abacogroup.partiesaclserver.resources.res;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@EqualsAndHashCode(callSuper=true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class PartyWithEntity extends Party{
	
	@Schema(description = "Entity's type", implementation = Entity.class, requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Entity entity;
	
	@Schema(description = "if true, mandate is editable", type = "boolean", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Boolean editable;

	@Schema(description = "if true, mandate is editable", type = "revokable", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Boolean revocable;
}
