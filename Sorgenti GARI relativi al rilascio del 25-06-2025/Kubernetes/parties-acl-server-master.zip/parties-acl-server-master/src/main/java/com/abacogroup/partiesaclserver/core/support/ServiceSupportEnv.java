package com.abacogroup.partiesaclserver.core.support;

import java.time.LocalDate;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;

@Data
@Builder(builderClassName = "Builder")
public class ServiceSupportEnv {

	private User user;
	
	@Default
	private String lang = "en";
	private String tenantId;
	
	@Default
	private AbsoluteDate referenceDate = AbsoluteDate.of(LocalDate.now());
	
	private String partyId;	
	
}