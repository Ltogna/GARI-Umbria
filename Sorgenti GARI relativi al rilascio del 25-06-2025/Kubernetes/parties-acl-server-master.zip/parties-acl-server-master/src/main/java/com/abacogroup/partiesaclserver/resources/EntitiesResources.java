package com.abacogroup.partiesaclserver.resources;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partiesaclserver.core.EntitiesService;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidEndDateException.InvalidEndDateExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidPayloadException.InvalidPayloadExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidRequestException;
import com.abacogroup.partiesaclserver.core.exceptions.NothingToUpdateException.NothingToUpdateExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.PastDateNotallowedException.PastDateNotallowedExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.ValidationDateException;
import com.abacogroup.partiesaclserver.core.exceptions.ValidationDateException.ValidationDateExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityCodeRequiredExecption.EntityCodeRequiredExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityExistsWithRegistryPartyIdExecption.EntityExistsWithRegistryPartyIdExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityNameExecption.EntityNameExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityNotFoundExecption.EntityNotFoundExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityWithExclusivePartyExecption.EntityWithExclusivePartyExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityWithParentExecption.EntityWithParentExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityWithoutParentExecption.EntityWithoutParentExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.entity.HierarchialLoopExecption.HierarchialLoopExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.entity.ParentNotValidExecption.ParentNotValidExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.security.UserNotAllowedExecption.UserNotAllowedExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeNotCompatibleExecption.TypeNotCompatibleExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeNotFoundExecption.TypeNotFoundExecptionBody;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.resources.req.CloseDatePayload;
import com.abacogroup.partiesaclserver.resources.req.CreateEntityPayload;
import com.abacogroup.partiesaclserver.resources.req.EntitySearchFilters;
import com.abacogroup.partiesaclserver.resources.req.UpdateEntityPayload;
import com.abacogroup.partiesaclserver.resources.res.Entity;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PRIV)
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "entities", description = "Operations on parcels")
public class EntitiesResources {

	private EntitiesService entitiesService;

	public EntitiesResources(EntitiesService entitiesService) {
		this.entitiesService = entitiesService;
	}

	@POST
	@Path("/entities")
	@RolesAllowed({"PACL|ADMIN"})
	@Operation(description = "Creates new entity", tags = { "entities" })
	@ApiResponse(responseCode = "200", description = "Entity created successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			TypeNotFoundExecptionBody.class, EntityCodeRequiredExecptionBody.class, PastDateNotallowedExceptionBody.class,
			ValidationDateExceptionBody.class, EntityNameExecptionBody.class, EntityExistsWithRegistryPartyIdExecptionBody.class,
			EntityCodeRequiredExecptionBody.class})))
	public Long createEntity(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@NotNull @Valid CreateEntityPayload payload) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return entitiesService.createEntity(env, payload);
	}
	
	@GET
	@Path("/entities")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "Gets List of existing entities", tags = { "entities" })
	@ApiResponse(responseCode = "200", description = "Gets List of existing entities", useReturnTypeSchema = true)
	public InfiniteListResults<Entity> getEntities(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("next_key") String nextKey,
			@BeanParam EntitySearchFilters filter) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return entitiesService.getEntities(env, filter, false, nextKey);
	}
	
	@GET
	@Path("/entities/{entityId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "Gets entity by id", tags = { "entities" })
	@ApiResponse(responseCode = "200", description = "Gets entity by id", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			EntityNotFoundExecptionBody.class})))
	public Entity getEntityById(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity Id") @PathParam("entityId") Long entityId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return entitiesService.getEntityById(env, entityId);
	}

	@PUT
	@Path("/entities/{entityId}/children/{childId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "Add child to parent", tags = { "entities" })
	@ApiResponse(responseCode = "200", description = "Child added to parent successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			EntityNotFoundExecptionBody.class, UserNotAllowedExecptionBody.class, EntityWithParentExecptionBody.class,
			HierarchialLoopExecptionBody.class})))
	public Boolean addChildToParent(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity id") @PathParam("entityId") Long entityId,
			@Parameter(description = "child id") @PathParam("childId") Long childId,
			@Parameter(description = "if true updates parent forcefully") @QueryParam("forceUpdate") @DefaultValue("false") Boolean forceUpdate,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return entitiesService.addChildToParent(env, entityId, childId, forceUpdate);
	}
	
	@DELETE
	@Path("/entities/{entityId}/children/{childId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "Remove child from parent", tags = { "entities" })
	@ApiResponse(responseCode = "200", description = "Child removed from parent successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			EntityNotFoundExecptionBody.class, UserNotAllowedExecptionBody.class, EntityWithoutParentExecptionBody.class,
			ParentNotValidExecptionBody.class})))
	public Boolean removeChildFromParent(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity id") @PathParam("entityId") Long entityId,
			@Parameter(description = "child id") @PathParam("childId") Long childId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return entitiesService.removeChildFromParent(env, entityId, childId);
	}
	
	@PUT
	@Path("/entities/{entityId}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "Update an entity", tags = { "entities" })
	@ApiResponse(responseCode = "200", description = "Entity cupdated successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			EntityNotFoundExecptionBody.class, UserNotAllowedExecptionBody.class, InvalidPayloadExceptionBody.class, InvalidEndDateExceptionBody.class,
			TypeNotCompatibleExecptionBody.class, TypeNotFoundExecptionBody.class, EntityCodeRequiredExecptionBody.class , PastDateNotallowedExceptionBody.class,
			ValidationDateExceptionBody.class, NothingToUpdateExceptionBody.class, EntityExistsWithRegistryPartyIdExecptionBody.class,
			EntityWithExclusivePartyExecptionBody.class, InvalidRequestException.class})))
	public Boolean updateEntity(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity id") @PathParam("entityId") Long entityId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@NotNull @Valid UpdateEntityPayload payload) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return entitiesService.updateEntity(env, entityId, payload);
	}
	
	@GET
	@Path("/entities/{entityId}/children")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "Return all child for an entity", tags = { "entities" })
	@ApiResponse(responseCode = "200", description = "Child added to parent successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			EntityNotFoundExecptionBody.class, UserNotAllowedExecptionBody.class, EntityWithParentExecptionBody.class,
			HierarchialLoopExecptionBody.class, InvalidRequestException.class})))
	public InfiniteListResults<Entity> getAllChildrenByEntityId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity id") @PathParam("entityId") Long entityId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("next_key") String nextKey) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return entitiesService.getAllChildrenByParentId(env, entityId, nextKey);
	}
	
	@POST
	@Path("/entities/{entityId}/closedate")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR"})
	@Operation(description = "Close Entity", tags = { "entities" })
	@ApiResponse(responseCode = "200", description = "Entity closed successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			UserNotAllowedExecptionBody.class, InvalidEndDateExceptionBody.class, ValidationDateException.class,
			EntityWithExclusivePartyExecptionBody.class})))
	public Boolean closeEntity(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity id") @PathParam("entityId") Long entityId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@NotNull @Valid CloseDatePayload payload) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return entitiesService.closeEntity(env, entityId, payload);
	}


}
