package com.abacogroup.partiesaclserver.bundles;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.partiesaclserver.bundles.models.I18nListMessage;
import com.abacogroup.partiesaclserver.bundles.models.I18nMessage;
import com.abacogroup.partiesaclserver.core.exceptions.bundles.I18nMessageException;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.I18nDAO;
import com.abacogroup.partiesaclserver.db.ntt.I18nNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

public class I18nMessageProcessor implements ConfigMessageProcessor{
	
	private final ObjectMapper objectMapper;

	private I18nDAO i18nDAO;

	private static final Logger log = LoggerFactory.getLogger(I18nMessageProcessor.class);

	public I18nMessageProcessor(DAOContainer dc) {
		this.i18nDAO = dc.getI18nDAO();
		this.objectMapper = new ObjectMapper();
	}

	@Override
	public String getDomainName() {
		return "i18n";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> deleteMessage(message.getTenantId(), file));
		
		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
				&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> insertOrUpdateMessage(message.getTenantId(), file));
	}

	private void insertOrUpdateMessage(String tenantId, File file) {
		try {
			I18nListMessage i18nMessages = objectMapper.readValue(file, I18nListMessage.class);

			if (i18nMessages == null || i18nMessages.getI18n_list() == null || i18nMessages.getI18n_list().isEmpty()) {
				return;
			}

			i18nMessages.getI18n_list().stream().forEach(message -> {
				try {
					if (message.getTranslations() == null || message.getTranslations().isEmpty()) {
						throw new IllegalStateException("Translations are not define!");
					}

					message.getTranslations().forEach((lang, text) -> {
						try {
							I18nNTT messageNTT = I18nNTT.builder()
									.field_name(message.getField())
									.i18n_text(text)
									.i18n_value(message.getValue())
									.lang(lang)
									.table_name(message.getTable())
									.tenant_id(tenantId)
									.build();

							I18nNTT toFind = i18nDAO.findI18nByPaclI18nKeys(messageNTT);

							if (toFind == null) {
								i18nDAO.insert(messageNTT);
							} else if (!toFind.getI18n_text().equals(text)) {
								i18nDAO.updateI18nText(messageNTT);
							}
						} catch (Exception e) {
							throw new I18nMessageException("Error during insert or update i18n message " + message.toString() + " for tenant " + tenantId + ".\n" + e);
						}
					});
				} catch (Exception e) {
					throw new I18nMessageException("Error processing row " + message.toString() + " for tenant " + tenantId + ".\n" + e);
				}
			
				log.info("I18n message with table '{}', field '{}' and value '{}' is valid for tenant '{}'. ", message.getTable(), message.getField(), message.getValue(), tenantId);
				
			});

		} catch (Exception e) {
			throw new I18nMessageException("Error processing file " + file.getName() + " for tenant " + tenantId + ".\n" + e);
		}
	}
	
	private void deleteMessage(String tenantId, File file) {
		try {
			I18nListMessage i18nMessages = objectMapper.readValue(file, I18nListMessage.class);

			if (i18nMessages == null || i18nMessages.getI18n_list() == null || i18nMessages.getI18n_list().isEmpty()) {
				return;
			}

			i18nMessages.getI18n_list().stream().forEach(message -> deleteMessageInternal(tenantId, message));

		} catch (Exception e) {
			throw new I18nMessageException("Error processing file " + file.getName() + " for tenant " + tenantId + ".\n" + e);
		}
	}
	
	private void deleteMessageInternal(String tenantId, I18nMessage message) {

		try {
			if (message.getTranslations() == null || message.getTranslations().isEmpty()) {
				I18nNTT messageNTT = I18nNTT.builder()
						.field_name(message.getField())
						.i18n_value(message.getValue())
						.table_name(message.getTable())
						.tenant_id(tenantId)
						.build();

				List<I18nNTT> toDelete = i18nDAO.findAllI18nByPaclI18nKeys(messageNTT);
				if (!toDelete.isEmpty()) {
					i18nDAO.deleteAllI18n(messageNTT);
				}
			} else {
				message.getTranslations().forEach((lang, text) -> {
					try {
						I18nNTT messageNTT = I18nNTT.builder()
								.field_name(message.getField())
								.i18n_text(text)
								.i18n_value(message.getValue())
								.lang(lang)
								.table_name(message.getTable())
								.tenant_id(tenantId)
								.build();

						if (i18nDAO.findI18nByPaclI18nKeys(messageNTT) != null) {
							i18nDAO.deleteI18nLang(messageNTT);
						}
					} catch (Exception e) {
						throw new I18nMessageException("Error during delete i18n message " + message.toString() + " with lang " + lang + " for tenant " + tenantId + ".\n" + e);
					}
				});
			}
		} catch (Exception e) {
			throw new I18nMessageException("Error during delete i18n message " + message.toString() + " for tenant " + tenantId + ".\n" + e);
		}
	}

}
