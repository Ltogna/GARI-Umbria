package com.abacogroup.partiesaclserver.resources;

public final class ResourceConstants {

	private ResourceConstants() {
	}

	public static final String API_INTERNAL = "/internal-api";
	public static final String API_PRIV = "/{tenant}/api-priv/v1/parties-acl";
	public static final String API_PUB = "/{tenant}/public/v1/parties-acl";
	
}
