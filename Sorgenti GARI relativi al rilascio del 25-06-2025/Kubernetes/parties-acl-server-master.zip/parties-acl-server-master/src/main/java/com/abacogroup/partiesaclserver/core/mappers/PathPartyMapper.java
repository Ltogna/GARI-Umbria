package com.abacogroup.partiesaclserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.db.ntt.PathPartyNTT;
import com.abacogroup.partiesaclserver.resources.res.PathParty;

@Mapper
public interface PathPartyMapper {

	PathPartyMapper INSTANCE = Mappers.getMapper(PathPartyMapper.class);

	@InheritInverseConfiguration()
	@Mapping(source = "party_id", target = "partyId")
	@Mapping(source = "mandate_id", target = "mandateId")
	@Mapping(target = "flExclusive", expression = "java(entity.getFl_exclusive() == 1)")
    @Mapping(target = "flManage", expression = "java(entity.getFl_manage() == 1)")
	@Mapping(source = "day_from", target = "dayFrom")
	@Mapping(source = "day_to", target = "dayTo")
	PathParty entityTODto(PathPartyNTT entity);

	@Mapping(source = "partyId", target = "party_id")
	@Mapping(source = "mandateId", target = "mandate_id")
	@Mapping(target = "fl_exclusive", expression = "java(dto.getFlExclusive() ? 1 : 0)")
    @Mapping(target = "fl_manage", expression = "java(dto.getFlManage() ? 1 : 0)")
	@Mapping(source = "dayFrom", target = "day_from")
	@Mapping(source = "dayTo", target = "day_to")
	PathPartyNTT dtoToEntity(PathParty dto);

}
