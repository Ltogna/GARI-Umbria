package com.abacogroup.partiesaclserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.resources.pub.res.UserPartyAuthV1;
import com.abacogroup.partiesaclserver.resources.res.UserPartyAuth;

@Mapper
public interface UserPartyAuthV1ResponseMapper {

	UserPartyAuthV1ResponseMapper INSTANCE = Mappers.getMapper(UserPartyAuthV1ResponseMapper.class);
		
	@InheritInverseConfiguration()
	UserPartyAuthV1 toResponseV1(UserPartyAuth type);	
	
}
