package com.abacogroup.partiesaclserver.core;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.partiesaclserver.core.enums.DocTypeRelationScope;
import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.MandateStatus;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.enums.Revision;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidPayloadException;
import com.abacogroup.partiesaclserver.core.exceptions.documents.InvalidDocumentException;
import com.abacogroup.partiesaclserver.core.mappers.PaclDocumentDefinitionMapper;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.DocTypeRelationDAO;
import com.abacogroup.partiesaclserver.db.ntt.DocTypeRelationNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyWithEntityNTT;
import com.abacogroup.partiesaclserver.resources.res.DocTypeRelation;
import com.abacogroup.partiesaclserver.resources.res.PaclDocumentDefinition;

import jakarta.ws.rs.core.Response.Status;

public class DocTypeService {

	private final DocTypeRelationDAO docTypeRelationDAO;

	private final UtilityService utilityService;
	private final DocumentTypeService documentTypeService;
	private final MandateDocumentService mandateDocumentService;
	private final ErrorDescriptionsService errorDescriptionsService;
	private final SecurityService securityService;
	private final String dynamicDocumentsBucket;

	public DocTypeService(DAOContainer container, UtilityService utilityService, ErrorDescriptionsService errorDescriptionsService, 
			MandateDocumentService mandateDocumentService, DocumentTypeService documentTypeService, SecurityService securityService,
			String dynamicDocumentsBucket) {
		this.docTypeRelationDAO = container.getDocTypeRelationDAO();
		this.utilityService = utilityService;
		this.errorDescriptionsService = errorDescriptionsService;
		this.mandateDocumentService = mandateDocumentService;
		this.documentTypeService = documentTypeService;
		this.securityService = securityService;
		this.dynamicDocumentsBucket = dynamicDocumentsBucket;
	}

	public List<DocTypeRelation> getByScopeCodeAndId(ServiceSupportEnv env, Long entityId, Long mandateId, DocTypeRelationScope scopeCode) {
	
		if(entityId == null && mandateId == null) {
			throw new InvalidPayloadException(Status.BAD_REQUEST, Operation.GET_DOC_TYPES, ErrorField.TYPE_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}
		
		Long entityTypeId = null;
		Long partyTypeId = null;
		final Long finalEntityId;
		final PartyWithEntityNTT mandate;
//		if(DocTypeRelationScope.GROUPS.equals(scopeCode)) {
//			EntityNTT entity = utilityService.getEntityById(env, entityId, false, false, Operation.GET_DOC_TYPES, ErrorField.ENTITY);
//			entityTypeId = entity.getEntity_type().getId();
//			finalEntityId = entityId;
//		} else
		if(DocTypeRelationScope.MANDATES.equals(scopeCode)) {
			mandate = utilityService.getPartyWithEntityNTT(env, mandateId, Operation.GET_DOC_TYPES);

			if(entityId != null && !entityId.equals(mandate.getEntity().getEntity_id())) {
				throw new InvalidPayloadException(Status.BAD_REQUEST, Operation.GET_DOC_TYPES, ErrorField.TYPE_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());

			}

			finalEntityId = mandate.getEntity().getEntity_id();
			partyTypeId = mandate.getParty_type().getId();
			entityTypeId = mandate.getEntity().getEntity_type().getId();
			
		} else {
			throw new InvalidPayloadException(Status.BAD_REQUEST, Operation.GET_DOC_TYPES, ErrorField.TYPE_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		Boolean isAdmin = securityService.checkAdminPermission(env, Operation.GET_DOC_TYPES);
		
		List<Long> entityIds = utilityService.getAdminEntitiesIdsByUserId(env, env.getUser().getUserId(), null, false, isAdmin);
		
		boolean hasMandate = entityIds.contains(mandate.getEntity().getEntity_id());
		
		return docTypeRelationDAO.getByEntityTypeIdPartyTypeIdAndScopeCode(env, entityTypeId, partyTypeId, scopeCode).stream()
				.collect(Collectors.groupingBy(
						ntt -> DocTypeRelation.builder()
						.setDefinitionCode(ntt.getDefinitionCode())
						.setDefinitionCodeI18n(ntt.getDefinitionCodeI18n())
						.setDisplayOrder(ntt.getDisplayOrder())
						.setScope(ntt.getScopeCode()) 
						.setEntityId(finalEntityId)
						.setMandateId(DocTypeRelationScope.MANDATES.equals(ntt.getScopeCode()) ? mandateId : null)
						.build(),
						Collectors.mapping(DocTypeRelationNTT::getRevisionCode, Collectors.toList())
						))
				.entrySet().stream()
				.map(entry -> {
					DocTypeRelation relation = entry.getKey();
					List<Revision> revisions = entry.getValue().stream()
		                    .filter(Objects::nonNull)
		                    .distinct()
		                    .collect(Collectors.toList());
		                relation.setRevisionCodes(revisions);
		                return relation;
				})
				.map(d -> addSummaryFields(env, d, documentTypeService))
				.map(d -> addFlDocPresent(env, d, scopeCode, finalEntityId, mandateId, mandateDocumentService))
				.filter(d -> {
					if(d.getRevisionCodes().contains(Revision.REVOKE_MANDATE) && d.getRevisionCodes().size() == 1) {
						return ((MandateStatus.CLOSED.equals(mandate.getStatus()) && d.getFlDocPresent() == 1) || mandate.getRevocable());
					}
					else {
						return hasMandate;
					}
				})
				.sorted((a,b) -> a.getDisplayOrder().compareTo(b.getDisplayOrder()))
				.collect(Collectors.toList());
	}

	public PaclDocumentDefinition getDefinition(ServiceSupportEnv env, String definitionCode) {
		return documentTypeService.getDocumentDefinition(env.getTenantId(), definitionCode)
				.map(PaclDocumentDefinitionMapper.INSTANCE::toPaclDocumentDefinition)
				.map(groupDocumentDefinition -> groupDocumentDefinition.setBucketName(dynamicDocumentsBucket))
				.orElseThrow(
						() -> new InvalidDocumentException(Status.BAD_REQUEST, Operation.GET_DOC_TYPES, ErrorField.DOCUMENT_DEFINITION,
								this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), definitionCode));
	}
	
	public static DocTypeRelation addSummaryFields(ServiceSupportEnv env, DocTypeRelation docTypeRelationRes, DocumentTypeService documentTypeService) {
		Optional<DocumentDefinition> def = documentTypeService.getDocumentDefinition(env.getTenantId(), docTypeRelationRes.getDefinitionCode());

		def.ifPresent(d -> {
			docTypeRelationRes.setSummaryFieldDefinitions(documentTypeService.getSummaryFields(def.get(), env.getLang()));
			docTypeRelationRes.setMultiple(d.getMetadata().getMaxOccurs() != null && d.getMetadata().getMaxOccurs() > 1);
		});
		return docTypeRelationRes;
	}
	
	public static DocTypeRelation addFlDocPresent(ServiceSupportEnv env, DocTypeRelation docTypeRelation, 
			DocTypeRelationScope scopeCode, Long entityId, Long mandateId, MandateDocumentService mandateDocumentsService) {
		
		if(entityId == null && mandateId == null) {
			return docTypeRelation;
		}
		
		Long documentsCount = 0L;
//		if(DocTypeRelationScope.GROUPS.equals(scopeCode) && entityId != null) {
//		XXX FIXME entitydocservice
//			documentsCount = mandateDocumentsService.countDocumentsByEntityIdMandateIdAndDefinitionCode(env, entityId, mandateId, docTypeRelation.getDefinitionCode());
//		}
		
		if(DocTypeRelationScope.MANDATES.equals(scopeCode) && mandateId != null) {
			documentsCount = mandateDocumentsService.countDocumentsByEntityIdMandateIdAndDefinitionCode(env, entityId, mandateId, docTypeRelation.getDefinitionCode());
			docTypeRelation.setMandateId(mandateId);
		}

		docTypeRelation.setFlDocPresent(documentsCount > 0L ? 1 : 0);
		
		docTypeRelation.setEntityId(entityId);
		return docTypeRelation;
	}
}
