package com.abacogroup.partiesaclserver.db.ntt;

import lombok.Data;

@Data
public class UserPartyAuthNTT {

	private Boolean hasManadates;
	private Boolean canManage;
	private String userRole;
	
}
