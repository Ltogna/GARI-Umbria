package com.abacogroup.partiesaclserver.core.exceptions.bundles;

public class BundlePartyTypeException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public BundlePartyTypeException(String message) {
		super(message);
	}
}
