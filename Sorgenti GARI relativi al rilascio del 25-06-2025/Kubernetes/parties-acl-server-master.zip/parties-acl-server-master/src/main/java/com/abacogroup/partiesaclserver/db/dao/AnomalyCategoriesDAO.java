package com.abacogroup.partiesaclserver.db.dao;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.partiesaclserver.db.ntt.AnomalyCategoriesNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface AnomalyCategoriesDAO extends Transactional<AnomalyCategoriesDAO>, EnhancedSqlObject {

	@SqlUpdate("insert into pacl_anomaly_categories (tenant_id, group_code, code, level, fl_exclude) values (:tenant_id, :group_code, :code, :level, :fl_exclude)")
	void insert(@Bind("tenant_id") String tenantId, @BindBean AnomalyCategoriesNTT category);

	@SqlUpdate("update pacl_anomaly_categories set level = :level, fl_exclude = :fl_exclude"
			+ " where tenant_id = :tenant_id and group_code = :group_code and code = :code")
	void update(@Bind("tenant_id") String tenantId, @BindBean AnomalyCategoriesNTT category);

	@SqlUpdate("delete from pacl_anomaly_categories where tenant_id = :tenant_id and group_code = :group_code and code = :code")
	void deleteByTenantGroupCodeAndCode(@Bind("tenant_id") String tenantId, @Bind("group_code") String groupCode, @Bind("code") String code);

	@SqlQuery("select group_code, \n"
			+ "       code, \n"
			+ "       \"level\", \n"
			+ "       fl_exclude "
			+ "from \n"
			+ "       pacl_anomaly_categories \n"
			+ "where \n"
			+ "       tenant_id = :tenant_id \n"
			+ "       and group_code = :group_code \n"
			+ "       and code = :code")
	@RegisterBeanMapper(AnomalyCategoriesNTT.class)
	AnomalyCategoriesNTT findByTenantGroupCodeAndCode(@Bind("tenant_id") String tenantId, @Bind("group_code") String groupCode, @Bind("code") String code);
}
