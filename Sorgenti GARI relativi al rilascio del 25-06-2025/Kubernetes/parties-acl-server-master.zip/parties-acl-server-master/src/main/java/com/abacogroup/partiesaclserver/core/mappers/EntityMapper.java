package com.abacogroup.partiesaclserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.db.ntt.EntityNTT;
import com.abacogroup.partiesaclserver.resources.res.Entity;

@Mapper(uses = EntityTypeMapper.class)
public interface EntityMapper {
	
	EntityMapper INSTANCE = Mappers.getMapper(EntityMapper.class);
	
	@InheritInverseConfiguration()	
	@Mapping(source = "entity_id", target = "id")
	@Mapping(source = "entity_type", target = "entityType")
	@Mapping(source = "registry_party_id", target = "registryPartyId")
	@Mapping(source = "description", target = "description")
	@Mapping(source = "parent_id", target = "parentId")
	@Mapping(source = "parent_name", target = "parentName")
	@Mapping(source = "parent_code", target = "parentCode")
	@Mapping(source = "path", target = "path")
	@Mapping(source = "day_from", target = "dayFrom")
	@Mapping(source = "day_to", target = "dayTo")
	@Mapping(source = "current_user_role", target = "currentUserRole")
	@Mapping(target = "adminUsers", ignore = true)
	@Mapping(target = "closeDay", ignore = true)
	Entity entityTODto(EntityNTT entity);
	
	@Mapping(target = "pkid", ignore = true)
	@Mapping(target = "parent_name", ignore = true)
	@Mapping(target = "parent_code", ignore = true)
	@Mapping(source = "id", target = "entity_id")
	@Mapping(source = "description", target = "description")
	@Mapping(source = "parentId", target = "parent_id")
	@Mapping(source = "path", target = "path")
	@Mapping(source = "registryPartyId", target = "registry_party_id")
	@Mapping(source = "dayFrom", target = "day_from")
	@Mapping(source = "dayTo", target = "day_to")
	@Mapping(source = "entityType", target = "entity_type")
	@Mapping(source = "currentUserRole", target = "current_user_role")
	EntityNTT dtoToEntity(Entity dto);
	
}
