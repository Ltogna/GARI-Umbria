package com.abacogroup.partiesaclserver;

import com.abacogroup.partiesaclserver.rabbitmq.RabbitMqConfig;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.Configuration;
import io.dropwizard.db.DataSourceFactory;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public class PartiesACLServerConfiguration extends Configuration {

	private boolean cors;

	@Valid
	@NotNull
	private DataSourceFactory database;

	@NotEmpty
	private String sso2Url;
	
	@NotEmpty
	private String sso2AuthPhrase;
	
	@NotEmpty
	private String anomaliesRegistryUrl;
	
	@NotEmpty
	private String partiesRegistryUrl;

	@NotEmpty
	private String fileStoreUrl;

	private RabbitMqConfig rabbitMqConfig;

	private String bundlesConfigLocation;
	
	private String applicationConfigFile;
	
	private String dynamicDocumentsBucket;
	

	public boolean isCors() {
		return cors;
	}

	public void setCors(boolean cors) {
		this.cors = cors;
	}

	@JsonProperty("database")
	public DataSourceFactory getDatabase() {
		return database;
	}

	@Valid
	@NotNull
	private JerseyClientConfiguration jerseyClient = new JerseyClientConfiguration();

	@JsonProperty("jerseyClient")
	public JerseyClientConfiguration getJerseyClientConfiguration() {
		return jerseyClient;
	}

	@JsonProperty("jerseyClient")
	public void setJerseyClientConfiguration(JerseyClientConfiguration jerseyClient) {
		this.jerseyClient = jerseyClient;
	}

	@JsonProperty("database")
	public void setDatabase(DataSourceFactory database) {
		this.database = database;
	}

	public String getSso2Url() {
		return sso2Url;
	}

	public void setSso2Url(String sso2Url) {
		this.sso2Url = sso2Url;
	}
	
	public String getSso2AuthPhrase() {
		return sso2AuthPhrase;
	}
	
	public void setSso2AuthPhrase(String sso2AuthPhrase) {
		this.sso2AuthPhrase = sso2AuthPhrase;
	}
	
	public String getAnomaliesRegistryUrl() {
		return anomaliesRegistryUrl;
	}

	public void setAnomaliesRegistryUrl(String anomaliesRegistryUrl) {
		this.anomaliesRegistryUrl = anomaliesRegistryUrl;
	}
	
	public String getPartiesRegistryUrl() {
		return partiesRegistryUrl;
	}
	
	public void setPartiesRegistryUrl(String partiesRegistryUrl) {
		this.partiesRegistryUrl = partiesRegistryUrl;
	}
	
	public String getFileStoreUrl() {
		return fileStoreUrl;
	}
	
	public void setFileStoreUrl(String fileStoreUrl) {
		this.fileStoreUrl = fileStoreUrl;
	}

	public RabbitMqConfig getRabbitMqConfig() {
		return rabbitMqConfig;
	}

	public void setRabbitmqConfig(RabbitMqConfig rabbitMqConfig) {
		this.rabbitMqConfig = rabbitMqConfig;
	}

	public String getBundlesConfigLocation() {
		return bundlesConfigLocation;
	}

	public void setBundlesConfigLocation(String bundlesConfigLocation) {
		this.bundlesConfigLocation = bundlesConfigLocation;
	}
	
	public String getApplicationConfigFile() {
		return applicationConfigFile;
	}
	
	public void setApplicationConfigFile(String applicationConfigFile) {
		this.applicationConfigFile = applicationConfigFile;
	}
	
	public String getDynamicDocumentsBucket() {
		return dynamicDocumentsBucket;
	}
	
	public void setDynamicDocumentsBucket(String dynamicDocumentsBucket) {
		this.dynamicDocumentsBucket = dynamicDocumentsBucket;
	}

}
