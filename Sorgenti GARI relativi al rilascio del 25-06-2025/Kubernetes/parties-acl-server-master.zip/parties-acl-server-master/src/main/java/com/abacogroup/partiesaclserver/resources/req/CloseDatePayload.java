package com.abacogroup.partiesaclserver.resources.req;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class CloseDatePayload {	
	@Schema(description = "End validity date - format YYYYMMDD", type = "string", format = "YYYYMMDD")
	private AbsoluteDate dayTo;
	
	@Schema(description = "first closing day, if set override dayTo - format YYYYMMDD", type = "string", format = "YYYYMMDD")
	private AbsoluteDate closeDay;

	@Schema(description = "if true, revokes the mandate instead of close/extend, default false")
	@Builder.Default
	private Boolean revoke = false;
}
