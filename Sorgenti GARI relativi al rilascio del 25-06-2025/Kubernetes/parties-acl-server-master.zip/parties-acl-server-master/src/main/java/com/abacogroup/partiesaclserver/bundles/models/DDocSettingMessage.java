package com.abacogroup.partiesaclserver.bundles.models;

import com.abacogroup.partiesaclserver.core.enums.DocTypeRelationScope;
import com.abacogroup.partiesaclserver.core.enums.Revision;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class DDocSettingMessage {

	private Revision revisionCode;
	private DocTypeRelationScope scopeCode; 
	private Integer displayOrder; 
	private String entityTypeCode;
	private String partyTypeCode;
	private String definitionCode;
	
}