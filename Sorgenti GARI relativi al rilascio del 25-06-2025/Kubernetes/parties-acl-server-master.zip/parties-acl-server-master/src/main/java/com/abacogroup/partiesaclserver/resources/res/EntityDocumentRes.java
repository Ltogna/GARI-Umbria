package com.abacogroup.partiesaclserver.resources.res;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper=true)
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class EntityDocumentRes extends DocumentRes{
	
	private Long entityId;

}
