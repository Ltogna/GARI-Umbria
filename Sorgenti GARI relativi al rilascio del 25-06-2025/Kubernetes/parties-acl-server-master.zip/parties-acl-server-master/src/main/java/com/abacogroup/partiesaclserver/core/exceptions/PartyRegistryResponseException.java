package com.abacogroup.partiesaclserver.core.exceptions;

import java.util.Map;

import jakarta.ws.rs.core.Response.Status;

import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PartyRegistryResponseException extends AbstractException {

	private static final long serialVersionUID = -6125162414489758858L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.PARTY_REGISTRY_RESPONSE_ERROR;

	public PartyRegistryResponseException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang, String errorCode) {
		super(code, new NothingToUpdateExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
		
		if(errorCode != null && !errorCode.isBlank()) {
			log.error(errorCode);
		} else {
			log.error(this.getBody().getLogErrorMessage());
		}
		
	}

	@Schema(description = "Error in party registry response")
	public static class NothingToUpdateExceptionBody extends AbstractExceptionBody {

		private static final long serialVersionUID = -3030014857380857949L;

		public NothingToUpdateExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
