package com.abacogroup.partiesaclserver.resources.res;

import java.util.List;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TenantsList {
	@ArraySchema(schema = @Schema(description = "Tenant List ", implementation = String.class))
	private List<String> tenants;
}
