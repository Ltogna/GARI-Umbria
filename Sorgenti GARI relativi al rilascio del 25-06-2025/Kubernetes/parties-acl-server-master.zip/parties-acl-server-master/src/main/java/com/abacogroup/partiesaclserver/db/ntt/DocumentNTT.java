package com.abacogroup.partiesaclserver.db.ntt;

import com.abacogroup.partiesaclserver.core.enums.DocTypeRelationScope;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class DocumentNTT {
	private Long pkid;
	private Long entityId;
	private Long mandateId;
	private DocTypeRelationScope scopeCode;

	private String definitionCode;
	private Long documentId;

}
