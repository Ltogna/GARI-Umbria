package com.abacogroup.partiesaclserver.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.partiesaclserver.db.ntt.EntityNTT;
import com.abacogroup.partiesaclserver.db.ntt.I18nNTT;

@RegisterBeanMapper(EntityNTT.class)
@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface I18nDAO extends Transactional<I18nDAO>, EnhancedSqlObject {

	@SqlQuery("select * from pacl_i18n_values "
			+ " where upper(tenant_id) = upper(:tenant_id) "
			+ " and upper(table_name) = upper(:table_name) "
			+ " and upper(field_name) = upper(:field_name) "
			+ " and upper(i18n_value) = upper(:i18n_value) "
			+ " and upper(lang) = upper(:lang)")
	@RegisterBeanMapper(I18nNTT.class)
	I18nNTT findI18nByPaclI18nKeys(@BindBean I18nNTT entity);

	@SqlQuery("select * from pacl_i18n_values "
			+ " where upper(tenant_id) = upper(:tenant_id) "
			+ " and upper(table_name) = upper(:table_name) "
			+ " and upper(field_name) = upper(:field_name) "
			+ " and upper(i18n_value) = upper(:i18n_value) ")
	@RegisterBeanMapper(I18nNTT.class)
	List<I18nNTT> findAllI18nByPaclI18nKeys(@BindBean I18nNTT entity);

	@SqlQuery("select * from pacl_i18n_values "
			+ " where upper(tenant_id) = upper(:tenantId) "
			+ " and upper(table_name) = upper(:tableName) "
			+ " and upper(field_name) = upper(:fieldName)")
	@RegisterBeanMapper(I18nNTT.class)
	List<I18nNTT> findAllI18nByTenantTableAndField(@Bind("tenantId") String tenantId, @Bind("tableName") String tableName, @Bind("fieldName") String fieldName);

	@SqlQuery("select i18n_text from §i18n(:tenant_id, :table_name, :field_name, :i18n_value, :lang)§ t")
	String findI18nText(@BindBean I18nNTT entity);

	@SqlUpdate("insert into pacl_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text) "
			+ " values (:tenant_id, :table_name, :field_name, :i18n_value, :lang, :i18n_text) ")
	void insert(@BindBean I18nNTT entity);

	@SqlUpdate("update pacl_i18n_values set "
			+ " i18n_text = :i18n_text "
			+ " where upper(tenant_id) = upper(:tenant_id) "
			+ " and upper(table_name) = upper(:table_name) "
			+ " and upper(field_name) = upper(:field_name) "
			+ " and upper(i18n_value) = upper(:i18n_value) "
			+ " and upper(lang) = upper(:lang)")
	void updateI18nText(@BindBean I18nNTT entity);

	@SqlUpdate("delete from pacl_i18n_values where tenant_id = :tenant_id and table_name = :table_name and field_name = :field_name and i18n_value = :i18n_value and lang =:lang")
	void deleteI18nLang(@BindBean I18nNTT entity);

	@SqlUpdate("delete from pacl_i18n_values where tenant_id = :tenant_id and table_name = :table_name and field_name = :field_name and i18n_value = :i18n_value")
	void deleteAllI18n(@BindBean I18nNTT entity);

	@SqlQuery("select s.* \n"
			+ "from pacl_i18n_values s \n"
			+ "left join pacl_i18n_values t on t.tenant_id = :targetTenant and t.table_name = s.table_name "
			+ "		and t.field_name = s.field_name and t.i18n_value = s.i18n_value and t.lang = s.lang\n"
			+ "where s.tenant_id = :sourceTenant \n"
			+ "and t.i18n_text is null \n")
	@RegisterBeanMapper(I18nNTT.class)
	List<I18nNTT> findTenantDifference(@Bind("sourceTenant")String sourceTenant, @Bind("targetTenant")String targetTenant);
	
	
}