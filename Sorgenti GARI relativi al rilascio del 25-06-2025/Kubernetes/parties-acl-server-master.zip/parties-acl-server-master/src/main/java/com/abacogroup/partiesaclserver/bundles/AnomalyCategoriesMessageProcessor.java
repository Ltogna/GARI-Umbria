package com.abacogroup.partiesaclserver.bundles;

import java.io.File;
import java.nio.file.Path;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.partiesaclserver.bundles.models.AnomalyCategoriesMessageList;
import com.abacogroup.partiesaclserver.core.enums.AnomalyLevel;
import com.abacogroup.partiesaclserver.core.exceptions.bundles.BundleAnomaliesCategoriesException;
import com.abacogroup.partiesaclserver.db.dao.AnomalyCategoriesDAO;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.ntt.AnomalyCategoriesNTT;
import com.fasterxml.jackson.databind.ObjectMapper;


public class AnomalyCategoriesMessageProcessor implements ConfigMessageProcessor {

	private final ObjectMapper objectMapper;

	private AnomalyCategoriesDAO anomalyCategoriesDAO;

	private static final Logger log = LoggerFactory.getLogger(AnomalyCategoriesMessageProcessor.class);

	public AnomalyCategoriesMessageProcessor(DAOContainer dc) {
		this.anomalyCategoriesDAO = dc.getAnomalyCategoriesDAO();
		objectMapper = new ObjectMapper();
	}

	@Override
	public String getDomainName() {
		return "anomaly-categories";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> deleteAnomalyCategoryMessage(message.getTenantId(), file));

		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
				&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> insertOrUpdateAnomalyCategoryMessage(message.getTenantId(), file));
	}

	private void insertOrUpdateAnomalyCategoryMessage(String tenantId, File file) {
		try {
			AnomalyCategoriesMessageList anomalyCategoriesMessageList = objectMapper.readValue(file, AnomalyCategoriesMessageList.class);

			if (anomalyCategoriesMessageList == null || anomalyCategoriesMessageList.getAnomaly_categorie_list() == null 
					|| anomalyCategoriesMessageList.getAnomaly_categorie_list().isEmpty()) {
				return;
			}

			anomalyCategoriesMessageList.getAnomaly_categorie_list().stream().forEach(message -> {
				try {
					AnomalyCategoriesNTT anomalyCategoryMessage = AnomalyCategoriesNTT.builder()
							.code(message.getCode())
							.fl_exclude(message.getFl_exclude() != null && message.getFl_exclude() ? 1 : 0)
							.group_code(message.getGroup_code())
							.level(message.getLevel())
							.build();

					AnomalyCategoriesNTT anomalyCategory = anomalyCategoriesDAO.findByTenantGroupCodeAndCode(tenantId, message.getGroup_code(),
							message.getCode());

					if (anomalyCategory == null) {
						insertMessage(tenantId, anomalyCategoryMessage);
					} else if (!anomalyCategoryMessage.equals(anomalyCategory)) {
						updateMessage(tenantId, anomalyCategoryMessage);
					}

				} catch (Exception e) {
					throw new BundleAnomaliesCategoriesException("Error during insert or update anomaly category with group-code '" + message.getGroup_code() + "' and code '" + message.getCode() + "'.\n" + e.getMessage());
				}
			});
		} catch (Exception e) {
			throw new BundleAnomaliesCategoriesException("Error processing file " + file.getName() + " for tenant " + tenantId + ".\n" + e.getMessage());
		}
	}

	private void insertMessage(String tenantId, AnomalyCategoriesNTT message) {

		if (message.getLevel().equals(AnomalyLevel.UNCATEGORIZED)) {
			throw new IllegalStateException("UNCATEGORIZED level must not exist on pacl_anomaly_categories!");
		}

		anomalyCategoriesDAO.insert(tenantId, message);
		log.info("Anomaly with group-code '{}' and code '{}' added for tenant '{}'. ", message.getGroup_code(), message.getCode(), tenantId);

	}

	private void updateMessage(String tenantId, AnomalyCategoriesNTT message) {

		if (message.getLevel().equals(AnomalyLevel.UNCATEGORIZED)) {
			throw new IllegalStateException("UNCATEGORIZED level must not exist on pacl_anomaly_categories!");
		}

		anomalyCategoriesDAO.update(tenantId, message);
		log.info("Anomaly with group-code '{}' and code '{}' updated for tenant '{}'. ", message.getGroup_code(), message.getCode(), tenantId);

	}

	private void deleteAnomalyCategoryMessage(String tenantId, File file) {
		try {
			AnomalyCategoriesMessageList anomalyCategoriesMessageList = objectMapper.readValue(file, AnomalyCategoriesMessageList.class);

			if (anomalyCategoriesMessageList == null || anomalyCategoriesMessageList.getAnomaly_categorie_list() == null || anomalyCategoriesMessageList.getAnomaly_categorie_list().isEmpty()) {
				return;
			}

			anomalyCategoriesMessageList.getAnomaly_categorie_list().stream().forEach(message -> {

				AnomalyCategoriesNTT anomalyCategory = anomalyCategoriesDAO.findByTenantGroupCodeAndCode(tenantId, message.getGroup_code(),
						message.getCode());

				if (anomalyCategory != null) {
					anomalyCategoriesDAO.deleteByTenantGroupCodeAndCode(tenantId, message.getGroup_code(), message.getCode());
				}
				log.info("Anomaly with group-code '{}' and code '{}' deleted for tenant '{}'. ", message.getGroup_code(), message.getCode(), tenantId);
			});

		} catch (Exception e) {
			throw new BundleAnomaliesCategoriesException("Error processing file " + file.getName() + " for tenant " + tenantId + ".\n" + e.getMessage());
		}
	}
}
