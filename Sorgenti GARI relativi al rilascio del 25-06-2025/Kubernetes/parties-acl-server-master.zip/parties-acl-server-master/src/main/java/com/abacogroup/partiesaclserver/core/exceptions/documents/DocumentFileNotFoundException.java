package com.abacogroup.partiesaclserver.core.exceptions.documents;

import java.util.Map;

import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractException;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DocumentFileNotFoundException extends AbstractException {

	private static final long serialVersionUID = 5683637794083193490L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.DYNAMIC_DOCUMENT_FILE_NOT_FOUND;

	public DocumentFileNotFoundException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, 
			String lang, Long documentId, String fileId) {
		super(code, new InvalidPartyNameExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
		
		String msg = String.format(this.getBody().getMessage(), documentId, fileId);
		this.getBody().setMessage(msg);
		log.error(this.getBody().getLogErrorMessage());
	}

	@Schema(description = "The given document does not contains the file with given id")
	public static class InvalidPartyNameExceptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = -6196402541546172600L;

		public InvalidPartyNameExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
