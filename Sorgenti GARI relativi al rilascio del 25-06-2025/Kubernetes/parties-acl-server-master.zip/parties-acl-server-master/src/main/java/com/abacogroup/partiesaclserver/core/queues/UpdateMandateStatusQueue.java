package com.abacogroup.partiesaclserver.core.queues;


import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.Repository;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.partiesaclserver.core.UtilityService;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.resources.req.queues.UpdateMandateStatusPayload;
import com.codahale.metrics.MetricRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UpdateMandateStatusQueue implements QueueErrorListener<UpdateMandateStatusPayload>, ThrowingConsumer<UpdateMandateStatusPayload>{

	private static final String QUEUE_ID = "update-mandateStatus";
	
	private UtilityService utilityService;
	
	private WorkQueue<UpdateMandateStatusPayload> queue;
	
	public UpdateMandateStatusQueue(Repository repository, MetricRegistry metricRegistry, int numThreads, long timeoutMs, ObjectMapper objectMapper,
			UtilityService utilityService) {

		queue = WorkQueue.builder(QUEUE_ID, repository, UpdateMandateStatusPayload.class)
				.withConsumer(this)
				.withErrorListener(this)
				.withMetricsRegistry(metricRegistry)
				.withNumThreads(numThreads)
				.withTimeoutMs(timeoutMs)
				.build();

		queue.setObjectMapper(objectMapper);
		
		this.utilityService = utilityService;
		
	}
	
	public void start() {
		queue.start();
	}

	public void add(String tenant, String username, Long entityTypeId, Long partyTypeId) {
		UpdateMandateStatusPayload payload = UpdateMandateStatusPayload.builder()
				.tenantId(tenant)
				.username(username)
				.entityTypeId(entityTypeId)
				.partyTypeId(partyTypeId)
				.build();
		
		queue.add(payload, System.currentTimeMillis());
	}

	@Override
	public ErrorAction onJobError(UpdateMandateStatusPayload payload, Throwable t) {
		return ErrorAction.DELETE_FROM_QUEUE;
	}

	@Override
	public void accept(UpdateMandateStatusPayload payload) throws Exception {
		
		ServiceSupportEnv env = ServiceSupportEnv.builder()
				.tenantId(payload.getTenantId())
				.user(new User(payload.getUsername(), payload.getTenantId()))
				.build();

		utilityService.updateMandatesStatus(env, payload.getEntityTypeId(), payload.getPartyTypeId(), Operation.UPDATE_MANDATE_STATUS_QUEUE);
	}

}
