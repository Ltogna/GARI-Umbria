package com.abacogroup.partiesaclserver.core.exceptions.bundles;

public class BundleAnomaliesCategoriesException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public BundleAnomaliesCategoriesException(String message) {
		super(message);
	}
}
