package com.abacogroup.partiesaclserver.core;


import java.io.IOException;
import java.io.StringWriter;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import com.abacogroup.partiesaclserver.PartiesACLServerConfiguration;
import com.abacogroup.partiesaclserver.core.models.Config;
import com.abacogroup.partiesaclserver.core.models.InternalConfig;
import com.abacogroup.partiesaclserver.core.models.InternalConfigList;
import com.abacogroup.partiesaclserver.db.dao.ConfigDAO;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.ntt.ConfigNTT;
import com.abacogroup.partiesaclserver.rabbitmq.RabbitMqConfig;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class InternalConfigService extends AbstractConfigService {

	private ConfigDAO configDAO;
	private PartiesACLServerConfiguration configuration;

	private Map<String, InternalConfig> internalConfigurations = new HashMap<>();

	public InternalConfigService(DAOContainer dc, PartiesACLServerConfiguration configuration) {
		super();

		this.configDAO = dc.getConfigDAO();
		this.configuration = configuration;

		ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
		ObjectMapper mapperWr = new ObjectMapper();
		mapper.findAndRegisterModules();
		try {
			InternalConfigList list = mapper.readValue(Path.of(this.configuration.getApplicationConfigFile()).toFile(), InternalConfigList.class);
			list.getInternalConfig().stream().forEach(internalConfig -> {

				try {
					StringWriter writer = new StringWriter();
					mapperWr.writeValue(writer, internalConfig.getValue());
					
					internalConfig = buildInternalConfig(ConfigNTT.builder()
							.tenantId(null)
							.key(internalConfig.getKey())
							.value(writer.toString())
							.fl_client(Boolean.TRUE.equals(internalConfig.getFl_client()) ? 1 : 0)
							.name(internalConfig.getName())
							.build(),
							internalConfig.getKey(),
							internalConfig.getType(),
							internalConfig.getIs_array());
					
				} catch (Exception e) {
					log.error("Error in loading internal configuration key default data key '{}'\n", internalConfig.getKey(), e);
				}
				
				internalConfigurations.put(internalConfig.getKey(), internalConfig);
			});

		} catch (IOException | IllegalArgumentException e) {
			throw new IllegalStateException("Error during read internal configuration: " + e);
		}

	}

	/**
	* Gets the Rabbitmq configuration. This is used to configure the rabbitmq server to use a custom message queue.
	* 
	* 
	* @return RabbitmqConfig instance that is configured for the RabbitMQ server to use a custom message queue
	*/
	public RabbitMqConfig getRabbitMqConfig() {
		return configuration.getRabbitMqConfig();
	}

	/**
	* Returns the map of internal configurations. This is a copy of the map returned by #getConfigurations ().
	* 
	* 
	* @return the map of internal configurations or null if there are no internal configurations in this configurer's configuration
	*/
	public Map<String, InternalConfig> getInternalConfigurations() {
		return internalConfigurations;
	}

	/**
	* Get the InternalConfig associated with the tenant. This method is useful for obtaining tenant specific configuration for example to check if a tenant is configured to use internal services.
	* 
	* @param tenantId - Tenant ID for which to get the configuration.
	* 
	* @return Map of tenant configuration keys and values that are instances of InternalConfig ( or null if none ) are found
	*/
	public Map<String, InternalConfig> getInternalTenantConfiguration(String tenantId) {
		Map<String, InternalConfig> result = new HashMap<>();

		getTenantConfiguration(tenantId).forEach((key, config) -> {
			// Store the internal configuration in the result.
			if (config instanceof InternalConfig) {
				result.put(key, (InternalConfig) config);
			}
		});

		return result;
	}

	/**
	* Loads and returns the configuration for the given tenant. This is a copy of the configuration that was loaded from the database but without the need to add it to the config table
	* 
	* @param tenantId - the tenant for which to load the configuration
	* 
	* @return the configuration for the given tenant or null if none could be found in the database or there was an
	*/
	@Override
	protected Map<String, Config> loadConfiguration(String tenantId) {
		Map<String, Config> result = new HashMap<>();
		
		// Load all keys at once to optimize db calls
		Map<String, ConfigNTT> tenantConf = configDAO.getConfigByTenant(tenantId).stream().collect(Collectors.toMap(ConfigNTT::getKey, c -> c));
		
		internalConfigurations.keySet().forEach(key -> {
			InternalConfig internalConfigToPut = getConfValue(tenantConf.get(key), key);
			// Put the internal configuration to the result.
			if(internalConfigToPut != null)
				result.put(key, internalConfigToPut);
		});
		
		// Add all the ui_* configured key in lpis config table
		configDAO.getUIConfigsByTenant(tenantId).forEach(c -> {
			InternalConfig internalUIConfigToPut = getConfValue(c, c.getKey());
			// Put the internal UI configuration to the result.
			if(internalUIConfigToPut != null)
				result.put(c.getKey(), internalUIConfigToPut);
		});
		
		return result;
	}

	/**
	* Get the internal configuration for the given key. This is a helper method for #getConfig ( ConfigNTT String ) and should not be called directly.
	* 
	* @param configNTT - the config to look up. Can be null in which case the method will return the default value
	* @param key - the key for the configuration
	* 
	* @return the
	*/
	private InternalConfig getConfValue(ConfigNTT configNTT, String key) {
		
		InternalConfig internalConfigToPut = internalConfigurations.get(key);
		
		// Returns the internal configuration to put.
		if(configNTT == null)
			return internalConfigToPut;
		
		String type = internalConfigToPut != null && internalConfigToPut.getType() != null ? internalConfigToPut.getType() : String.class.getName();
		Boolean isArray = internalConfigToPut != null && internalConfigToPut.getIs_array() != null && internalConfigToPut.getIs_array();

		return buildInternalConfig(configNTT, key, type, isArray);
	}

	/**
	* Builds and returns InternalConfig for put / get. This method is used to build and return the internal config that will be used to send / receive data to Samza
	* 
	* @param configNTT - The config to get / put
	* @param key - The key of the config to put / get
	* @param type - The type of the config to put / get
	* @param isArray - True if we are dealing with an array
	* 
	* @return The config to put /
	*/
	private InternalConfig buildInternalConfig(ConfigNTT configNTT, String key, String type, Boolean isArray) {
		InternalConfig internalConfigToPut = null;
		ObjectMapper mapper = new ObjectMapper();

		String value = configNTT.getValue();

		// If is a string value it can be stored as it is
		if (value == null || ((type).equals(String.class.getName()) && (isArray == null || !isArray))) {
			internalConfigToPut = InternalConfig.builder()
					.fl_client(configNTT.getFl_client() == 1)
					.is_array(isArray)
					.key(key)
					.name(configNTT.getName())
					.type(type)
					.value(value != null ? value.replaceAll("^\"(.+)\"$", "$1") : value)
					.build();
			
		// If is an array of values 
		} else if (isArray != null && isArray) {
			
			List<Object> objects = new ArrayList<>();
			
			// Try to load the object array
			try {
				JavaType typeClassList = mapper.getTypeFactory().constructCollectionType(List.class, Class.forName(type));
				((List<?>) mapper.readValue(value, typeClassList))
				.stream()
				.filter(Objects::nonNull)
				.forEach(objects::add);
			} catch (ClassNotFoundException e) {
			    throw new IllegalStateException(String.format("Error during read db internal configuration '%s' (Class not found) with value '%s'", key, value), e);
			} catch (Exception e) {
				throw new IllegalStateException(String.format("General error during read db internal configuration '%s' with value '%s'", key, value), e);
			}
			
			internalConfigToPut = InternalConfig.builder()
					.fl_client(configNTT.getFl_client() == 1)
					.is_array(isArray)
					.key(key)
					.name(configNTT.getName())
					.type(type)
					.value(objects)
					.build();
			// if not array and not a simple string then load the object class from type
		} else {
			try {
				
				Object objectValue = mapper.readValue(value, Class.forName(type));
				internalConfigToPut = InternalConfig.builder()
						.fl_client(configNTT.getFl_client() == 1)
						.is_array(isArray)
						.key(key)
						.name(configNTT.getName())
						.type(type)
						.value(objectValue)
						.build();
				
			} catch (Exception e) {
				throw new IllegalStateException(String.format("Error during read db internal configuration '%s' with value '%s'", key, value), e);
			} 
		}

		return internalConfigToPut;
	}
	
}
