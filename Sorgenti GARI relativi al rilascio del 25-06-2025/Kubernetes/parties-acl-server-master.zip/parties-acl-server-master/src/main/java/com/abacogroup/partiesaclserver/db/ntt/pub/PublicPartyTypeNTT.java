package com.abacogroup.partiesaclserver.db.ntt.pub;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PublicPartyTypeNTT {
	private Long id;
	private String code;
	private Integer fl_exclusive;
	private Integer fl_manage;
	private String description;
}
