package com.abacogroup.partiesaclserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.db.ntt.RevisionHistoryNTT;
import com.abacogroup.partiesaclserver.resources.res.RevisionHistory;

@Mapper
public interface RevisionHistoryMapper {
	
	RevisionHistoryMapper INSTANCE = Mappers.getMapper(RevisionHistoryMapper.class);
	
	@InheritInverseConfiguration()
	@Mapping(source = "pkid", target = "id")
	@Mapping(source = "operation", target = "operation")
	@Mapping(source = "object_id", target = "objectId")
	@Mapping(source = "old_path", target = "oldPath")
	@Mapping(source = "new_path", target = "newPath")
	@Mapping(source = "object_data", target = "objectData")
	@Mapping(source = "revision_date", target = "revisionDate")
	RevisionHistory entityTODto(RevisionHistoryNTT entity);
	
	@Mapping(source = "id", target = "pkid")
	@Mapping(target = "tenant_id", ignore =  true)
	@Mapping(source = "operation", target = "operation")
	@Mapping(source = "objectId", target = "object_id")
	@Mapping(source = "oldPath", target = "old_path")
	@Mapping(source = "newPath", target = "new_path")
	@Mapping(source = "objectData", target = "object_data")
	@Mapping(source = "revisionDate", target = "revision_date")
	RevisionHistoryNTT dtoToEntity(RevisionHistory dto);
	
}
