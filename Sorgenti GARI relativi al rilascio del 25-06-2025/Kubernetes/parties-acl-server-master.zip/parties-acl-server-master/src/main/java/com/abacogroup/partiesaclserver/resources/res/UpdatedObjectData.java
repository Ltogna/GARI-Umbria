package com.abacogroup.partiesaclserver.resources.res;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;

@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class UpdatedObjectData {
	@Schema(description = "new start validity date - format YYYYMMDD", type = "string", format = "YYYYMMDD")
	private AbsoluteDate dayFrom;
	
	@Schema(description = "new end validity date - format YYYYMMDD ", type = "string", format = "YYYYMMDD")
	private AbsoluteDate dayTo;
	
	@Schema(description = "new role of an user or party", type = "string")
	private String newRole;
}
