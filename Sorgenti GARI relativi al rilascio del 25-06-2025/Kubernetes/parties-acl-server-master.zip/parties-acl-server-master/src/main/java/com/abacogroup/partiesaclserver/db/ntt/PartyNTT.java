package com.abacogroup.partiesaclserver.db.ntt;

import org.jdbi.v3.core.mapper.Nested;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partiesaclserver.core.enums.MandateStatus;
import com.abacogroup.partiesaclserver.core.enums.Revision;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class PartyNTT {
	private Long pkid;
	private Long mandate_id;
	private AbsoluteDate day_from;
	private AbsoluteDate day_to;
	private Long entity_id;
	private String party_id;
	private PartyTypeNTT party_type;
	private MandateStatus status;
	private Revision revision_code;
	
	@Nested("ppt")
	public PartyTypeNTT getParty_type() {
		return party_type;
	}
}
