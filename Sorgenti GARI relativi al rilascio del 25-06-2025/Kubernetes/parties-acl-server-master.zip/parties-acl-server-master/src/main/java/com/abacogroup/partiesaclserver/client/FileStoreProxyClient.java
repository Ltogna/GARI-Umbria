package com.abacogroup.partiesaclserver.client;

import jakarta.ws.rs.client.WebTarget;

public class FileStoreProxyClient extends ClientHelper {
	public FileStoreProxyClient(WebTarget webTarget) {
		super(webTarget);
	}
}
