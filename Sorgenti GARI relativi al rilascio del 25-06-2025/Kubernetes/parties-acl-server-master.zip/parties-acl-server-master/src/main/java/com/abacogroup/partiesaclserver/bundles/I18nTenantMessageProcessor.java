package com.abacogroup.partiesaclserver.bundles;

import java.util.List;

import com.abacogroup.bundles.db.dao.TenantDAO;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.partiesaclserver.core.exceptions.bundles.I18nMessageException;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.I18nDAO;
import com.abacogroup.partiesaclserver.db.ntt.I18nNTT;


public class I18nTenantMessageProcessor implements PartiesACLTenantMessageProcessor {

	private static final String TEMPLATE_TENANT_ID = "*";

	private TenantDAO tenantDAO;
	private I18nDAO i18nDAO;

	public I18nTenantMessageProcessor(DAOContainer dc) {
		this.tenantDAO= dc.getTenantDAO();
		this.i18nDAO = dc.getI18nDAO();
	}

	@Override
	public void onMessage(TenantMessage message) {
		String tenantId = message.getTenantId();

		if (tenantId.equals(TEMPLATE_TENANT_ID)) {
			return;
		}

		List<I18nNTT> i18nNTTList = i18nDAO.findTenantDifference(TEMPLATE_TENANT_ID, tenantId);

		i18nNTTList.forEach(i18n -> {
			i18n.setTenant_id(tenantId);
			try {
				i18nDAO.insert(i18n);
			} catch (Exception e) {
				throw new I18nMessageException("Error during insert or update i18n message " + i18n.toString() + " for tenant " + tenantId + ".\n" + e);
			}
		});

	}

	@Override
	public void syncAllTenant() {
		tenantDAO.findAll().forEach(t -> onMessage(new TenantMessage().setTenantId(t.getTenantId())));
	}
}
