package com.abacogroup.partiesaclserver.resources.pub;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidEndDateException.InvalidEndDateExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.PastDateNotallowedException.PastDateNotallowedExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.ValidationDateException;
import com.abacogroup.partiesaclserver.core.exceptions.ValidationDateException.ValidationDateExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.ValidationDatesConflictException.ValidationDatesConflictExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityNotFoundExecption.EntityNotFoundExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.ExclusivePartyException.ExclusivePartyExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.PartyInEntityException.PartyInEntityExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.UserInEntityException.UserInEntityExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.security.UserNotAllowedExecption.UserNotAllowedExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeNotCompatibleExecption.TypeNotCompatibleExecptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeNotFoundExecption.TypeNotFoundExecptionBody;
import com.abacogroup.partiesaclserver.core.pub.MandatesV1Service;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.resources.ResourceConstants;
import com.abacogroup.partiesaclserver.resources.pub.req.AddMandatorUserPayloadV1;
import com.abacogroup.partiesaclserver.resources.pub.req.AddPartyPayloadV1;
import com.abacogroup.partiesaclserver.resources.pub.req.PartyEntitySearchFiltersV1;
import com.abacogroup.partiesaclserver.resources.pub.req.PartySearchFilters;
import com.abacogroup.partiesaclserver.resources.pub.res.HasManageV1Res;
import com.abacogroup.partiesaclserver.resources.pub.res.MandatorUserV1;
import com.abacogroup.partiesaclserver.resources.pub.res.PartySearchV1ResponseInfinite;
import com.abacogroup.partiesaclserver.resources.pub.res.PartyV1;
import com.abacogroup.partiesaclserver.resources.pub.res.PartyWithEntityV1;
import com.abacogroup.partiesaclserver.resources.pub.res.UserPartyAuthV1;
import com.abacogroup.partiesaclserver.resources.pub.res.UserPartyV1;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.PermitAll;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PUB)
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "public", description = "Public resources")
public class PublicMandatesResources {

	private MandatesV1Service mandatesService;
	
	public PublicMandatesResources(MandatesV1Service mandatesService) {
		this.mandatesService = mandatesService;
	}
	
	
	@GET
	@Path("/parties/{partyId}/manage")
	@PermitAll
	@Operation(description = "Get flag flManage for current user id on party id", tags = { "public" })
	@ApiResponse(responseCode = "200", description = "GET flag flManage for current user id on party id", useReturnTypeSchema = true)
	public HasManageV1Res hasManage(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Party id") @PathParam("partyId") String partyId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.hasManage(env, partyId);
	}
	
	@GET
	@Path("/parties/{partyId}/auth")
	@PermitAll
	@Operation(description = "Get authorization for current user id on party id", tags = { "public" })
	@ApiResponse(responseCode = "200", description = "GET flag flManage for current user id on party id", useReturnTypeSchema = true)
	public UserPartyAuthV1 getAuthorizationsByPartyIdAndUser(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Party id") @PathParam("partyId") String partyId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate) {
		
		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();
		
		return mandatesService.getAuthorizations(env, partyId);
	}
	
	@GET
	@Path("/mandates")
	@PermitAll
	@Operation(description = "Get all mandates by user id", tags = { "public" })
	@ApiResponse(responseCode = "200", description = "GET flag flManage for current user id on party id", useReturnTypeSchema = true)
	public InfiniteListResults<UserPartyV1> getAllMandatesByUserId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("next_key") String nextKey) {
		
		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();
		
		return mandatesService.getAllMandatesByUserId(env, nextKey);
	}
	
	@POST
	@Path("/entities/{entityId}/users")
	@PermitAll
	@Operation(description = "Add user to Entity", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "User added successfully", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			EntityNotFoundExecptionBody.class, UserNotAllowedExecptionBody.class, PastDateNotallowedExceptionBody.class,
			ValidationDateException.class, ValidationDatesConflictExceptionBody.class, UserInEntityExecptionBody.class})))
	public Boolean addUsersToEntity(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity id") @PathParam("entityId") Long entityId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@NotNull @Valid AddMandatorUserPayloadV1 payload) {
		
		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();
		
		return mandatesService.addUsersToEntity(env, entityId, payload, false, false);
	}
	
	@GET
	@Path("/entities/{entityId}/users")
	@PermitAll
	@Operation(description = "GET users by entity id", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "GET users by entity id", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			UserNotAllowedExecptionBody.class})))
	public InfiniteListResults<MandatorUserV1> getAllUsersByEntityId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity id") @PathParam("entityId") Long entityId,
			@Parameter(description = "Filter by username") @QueryParam("username") String usernameFilter,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("next_key") String nextKey) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.getAllUsersByEntityId(env, entityId, usernameFilter, nextKey);
	}

	@GET
	@Path("/proxy/parties")
	@PermitAll
	@Operation(description = "Get all mandates by user id", tags = { "public" })
	@ApiResponse(responseCode = "200", description = "GET flag flManage for current user id on party id", useReturnTypeSchema = true)
	public PartySearchV1ResponseInfinite seracheParties(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
			@BeanParam @Valid PartySearchFilters partySearchReq) {
		
		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.searchParties(env, partySearchReq, nextKey);
	}
	
	@GET
	@Path("/entities/{entityCode}/parties")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "GET parties by entity id", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "GET parties by entity code", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			UserNotAllowedExecptionBody.class})))
	public InfiniteListResults<PartyV1> getAllPartiesByEntityCode(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity code") @PathParam("entityCode") String entityCode,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "Set true to get history") @DefaultValue("false")@QueryParam("history") Boolean history,
			@Parameter(description = "If true includes parties of children") @DefaultValue("false")@QueryParam("include_children") Boolean includeChildren,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("next_key") String nextKey) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.getAllPartiesByEntityId(env, entityCode, history, includeChildren, nextKey);
	}

	@GET
	@Path("/parties/{partyId}/entities")
	// TODO fix the permission to use a "good" service user then restore: @RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@PermitAll
	@Operation(description = "GET entities by party id", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "GET entities by party id", useReturnTypeSchema = true)
	public InfiniteListResults<PartyWithEntityV1> getAllEntitiesByPartyId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Party id") @PathParam("partyId") String partyId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("next_key") String nextKey,
			@BeanParam PartyEntitySearchFiltersV1 filters) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.getAllEntitiesByPartyId(env, partyId, filters, nextKey);
	}
	
	@POST
	@Path("/entities/{entityId}/parties")
	@PermitAll
	@Operation(description = "Add parties to Entity", tags = { "mandates" })
	@ApiResponse(responseCode = "200", description = "Parties added successfully, return mandateId", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "400", description = "Read schemas for more details", content = @Content(schema = @Schema(oneOf = {
			EntityNotFoundExecptionBody.class, UserNotAllowedExecptionBody.class, TypeNotFoundExecptionBody.class,
			TypeNotCompatibleExecptionBody.class, ExclusivePartyExecptionBody.class, PartyInEntityExecptionBody.class,
			PastDateNotallowedExceptionBody.class, ValidationDateExceptionBody.class, ValidationDatesConflictExceptionBody.class,
			InvalidEndDateExceptionBody.class})))
	public Long addPartyToEntity(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity id") @PathParam("entityId") Long entityId,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@NotNull @Valid AddPartyPayloadV1 payload) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return mandatesService.addPartyToEntity(env, entityId, payload);
	}
	
}
