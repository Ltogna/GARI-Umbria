package com.abacogroup.partiesaclserver.resources;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.partiesaclserver.core.SupportService;
import com.abacogroup.partiesaclserver.core.exceptions.support.InternalConfigNotFoundException;
import com.abacogroup.partiesaclserver.resources.res.ClientConfigurationList;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PRIV + "/support")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "support", description = "Support operations of project")
public class SupportResources {

	private SupportService supportService;
	
	public SupportResources(SupportService supportService) {
		this.supportService = supportService;
	}
	
	@GET
	@Path("/config")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "Get config codes", tags = { "support" })
			@ApiResponse(responseCode = "200", description = "Get config codes", useReturnTypeSchema = true)
	        @ApiResponse(responseCode = "404", description = "Config key not found", content = @Content(schema = @Schema(implementation = InternalConfigNotFoundException.class)))
		public ClientConfigurationList getClientConfigs(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "config key") @QueryParam("key") String key) {

		return supportService.getClientConfig(tenantId, lang, key);
	}
	
	@GET
	@Path("/config/{configKey}")
	@RolesAllowed({"PACL|ADMIN", "PACL|EDITOR", "PACL|VIEWER"})
	@Operation(description = "Get config codes", tags = { "support" })
	@ApiResponse(responseCode = "200", description = "Get config key string value", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "404", description = "Config key not found", content = @Content(schema = @Schema(implementation = InternalConfigNotFoundException.class)))
	public String getClientConfigKey(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "config key") @PathParam("configKey") String configKey) {
		
		return supportService.getClientConfig(tenantId, lang, configKey).getClient_configuration().get(0).getValue().toString();
	}
}
