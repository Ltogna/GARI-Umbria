package com.abacogroup.partiesaclserver.core.exceptions.bundles;

public class BundleDynamicDocException extends RuntimeException{

	private static final long serialVersionUID = -2023135975329772974L;

	public BundleDynamicDocException(String message) {
		super(message);
	}
}
