package com.abacogroup.partiesaclserver.core.exceptions.mandate;

import java.util.Map;

import jakarta.ws.rs.core.Response.Status;

import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractException;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UserInEntityException extends AbstractException{

	private static final long serialVersionUID = 4723230731377004051L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.USER_ALREADY_EXISTS;

	public UserInEntityException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang, String user, String entity) {
		super(code, new UserInEntityExecptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
		
		String msg = String.format(this.getBody().getMessage(), user, entity);
		this.getBody().setMessage(msg);
		log.error(this.getBody().getLogErrorMessage());
	}

	@Schema(description = "User already exists in the given entity id")
	public static class UserInEntityExecptionBody extends AbstractExceptionBody {

		private static final long serialVersionUID = -2393938688163350093L;

		public UserInEntityExecptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
