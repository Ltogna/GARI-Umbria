package com.abacogroup.partiesaclserver.bundles.models;

import com.abacogroup.partiesaclserver.core.enums.AnomalyLevel;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AnomalyCategoriesMessage {
	private String group_code;
	private String code;
	private AnomalyLevel level;
	private Boolean fl_exclude;
}
