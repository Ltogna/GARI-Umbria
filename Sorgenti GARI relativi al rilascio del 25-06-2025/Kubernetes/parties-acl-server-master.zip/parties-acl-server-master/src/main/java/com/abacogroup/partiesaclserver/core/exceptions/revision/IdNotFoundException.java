package com.abacogroup.partiesaclserver.core.exceptions.revision;

import java.util.Map;

import jakarta.ws.rs.core.Response.Status;

import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractException;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class IdNotFoundException extends AbstractException{

	private static final long serialVersionUID = 4723230731377004051L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.ID_NOT_FOUND;

	public IdNotFoundException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang, Long fromId, Long lastId) {
		super(code, new IdNotFoundExecptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang, lastId));
		
		String msg = String.format(this.getBody().getMessage(), fromId);
		this.getBody().setMessage(msg);
		log.error(this.getBody().getLogErrorMessage());
	}

	@Schema(description = "Revision id not found")
	public static class IdNotFoundExecptionBody extends AbstractExceptionBody {

		private static final long serialVersionUID = -2393938688163350093L;

		public IdNotFoundExecptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang, Long lastId) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang, lastId);
		}
	}
}
