package com.abacogroup.partiesaclserver.core.exceptions.bundles;

public class BundleEntityTypeException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public BundleEntityTypeException(String message) {
		super(message);
	}
}
