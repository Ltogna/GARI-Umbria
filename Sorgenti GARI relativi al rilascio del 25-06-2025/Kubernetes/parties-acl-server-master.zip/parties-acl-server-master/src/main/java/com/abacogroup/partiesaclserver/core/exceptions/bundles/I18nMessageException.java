package com.abacogroup.partiesaclserver.core.exceptions.bundles;

public class I18nMessageException extends RuntimeException{

	private static final long serialVersionUID = 6900095482205284136L;

	public I18nMessageException(String message) {
		super(message);
	}
}
