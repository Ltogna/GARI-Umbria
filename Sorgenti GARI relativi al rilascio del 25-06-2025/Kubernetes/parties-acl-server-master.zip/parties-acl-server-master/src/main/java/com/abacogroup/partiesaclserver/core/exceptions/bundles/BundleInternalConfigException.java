package com.abacogroup.partiesaclserver.core.exceptions.bundles;

public class BundleInternalConfigException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public BundleInternalConfigException(String message) {
		super(message);
	}
}
