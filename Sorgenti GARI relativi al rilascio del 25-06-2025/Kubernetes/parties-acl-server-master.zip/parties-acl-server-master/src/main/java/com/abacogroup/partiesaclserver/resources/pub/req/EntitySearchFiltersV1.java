package com.abacogroup.partiesaclserver.resources.pub.req;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.QueryParam;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class EntitySearchFiltersV1 {
	
	@Parameter(in = ParameterIn.QUERY, description = "Entity name filter")
	@QueryParam("name")
	private String name;
	
	@Parameter(in = ParameterIn.QUERY, description = "Entity code filter")
	@QueryParam("code")
	private String code;
	
	@Parameter(in = ParameterIn.QUERY, description = "Id of  registry Id")
	@QueryParam("registryId")
	private String registryId;
	
	@Parameter(in = ParameterIn.QUERY, description = "Entity type code filter")
	@QueryParam("entityTypeCode")
	private String entityTypeCode;
	
	@Parameter(in = ParameterIn.QUERY, description = "Reference date")
	@QueryParam("referenceDate")
	private AbsoluteDate referenceDate;
	
	@Parameter(in = ParameterIn.QUERY, description = "if false show only valid entities")
	@QueryParam("history")
	@DefaultValue("false")
	private Boolean history;

	@Parameter(in = ParameterIn.QUERY, description = "if true skip entities permission check")
	@QueryParam("skipPermissionCheck")
	@DefaultValue("true")
	private Boolean skipPermissionCheck;
}
