package com.abacogroup.partiesaclserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.db.ntt.UserPartyNTT;
import com.abacogroup.partiesaclserver.resources.res.UserParty;

@Mapper(uses = {PartyTypeMapper.class, PartyMapper.class})
public interface UserPartyMapper {

	UserPartyMapper INSTANCE = Mappers.getMapper(UserPartyMapper.class);

	@InheritInverseConfiguration()
	@Mapping(source = "party_id", target = "id")
	@Mapping(source = "entity_id", target = "entityId")
	@Mapping(source = "party_type", target = "partyType")
	@Mapping(source = "day_from", target = "dayFrom")
	@Mapping(source = "day_to", target = "dayTo")
	@Mapping(source = "mandate_id", target = "mandateId")
	UserParty entityTODto(UserPartyNTT entity);

	@Mapping(source = "id", target = "party_id")
	@Mapping(source = "entityId", target = "entity_id")
	@Mapping(source = "partyType", target = "party_type")
	@Mapping(source = "dayFrom", target = "day_from")
	@Mapping(source = "dayTo", target = "day_to")
	@Mapping(source = "mandateId", target = "mandate_id")
	UserPartyNTT dtoToEntity(UserParty dto);

}