package com.abacogroup.partiesaclserver.core.pub;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partiesaclserver.core.TypesService;
import com.abacogroup.partiesaclserver.core.mappers.pub.EntityTypeV1ResponseMapper;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.resources.pub.res.EntityTypeV1;

public class TypesV1Service {

	private TypesService typesService;

	/**
	 * The TypesV1Service class provides methods to manage types.
	 * It provides methods to retrieve entity types and party types based on filters.
	 */
	public TypesV1Service(TypesService typesService) {
		this.typesService = typesService;
	}

	public InfiniteListResults<EntityTypeV1> getAllEntityTypes(ServiceSupportEnv env, String code, String nextKey) {
		return typesService.getAllEntityTypes(env, code, false, nextKey)
				.map(EntityTypeV1ResponseMapper.INSTANCE::toResponseV1);
	}
}