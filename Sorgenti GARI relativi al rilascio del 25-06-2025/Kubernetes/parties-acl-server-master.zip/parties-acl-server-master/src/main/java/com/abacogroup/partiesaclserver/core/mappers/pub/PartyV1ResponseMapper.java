package com.abacogroup.partiesaclserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.resources.pub.res.PartyV1;
import com.abacogroup.partiesaclserver.resources.res.Party;

@Mapper(uses = PartyTypeV1ResponseMapper.class)
public interface PartyV1ResponseMapper {
	
	PartyV1ResponseMapper INSTANCE = Mappers.getMapper(PartyV1ResponseMapper.class);
	
	@InheritInverseConfiguration()
	PartyV1 toResponseV1(Party entity);
	
}
