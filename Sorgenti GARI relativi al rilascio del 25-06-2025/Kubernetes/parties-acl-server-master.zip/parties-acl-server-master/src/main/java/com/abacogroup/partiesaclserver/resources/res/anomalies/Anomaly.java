package com.abacogroup.partiesaclserver.resources.res.anomalies;

import java.time.LocalDateTime;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class Anomaly {
	@Schema(description = "Entity code", type = "string")
	private String entityCode;

	@Schema(description = "Entity id", type = "string")
	private String entityId;

	@Schema(description = "Date of insertion of anomaly", type = "string", format = "date-time")
	private LocalDateTime dt_insert;
	
	@Schema(description = "Type of anomaly", implementation = AnomalyType.class)
	private AnomalyType type;
	
}
