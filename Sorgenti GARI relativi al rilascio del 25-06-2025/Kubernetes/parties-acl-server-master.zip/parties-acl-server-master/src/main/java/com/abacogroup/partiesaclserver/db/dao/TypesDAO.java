package com.abacogroup.partiesaclserver.db.dao;

import java.util.List;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.ntt.EntityTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyTypeNTT;

@RegisterBeanMapper(EntityTypeNTT.class)
@RegisterBeanMapper(PartyTypeNTT.class)
public interface TypesDAO extends Transactional<TypesDAO>, EnhancedSqlObject {

	@SqlQuery("§select_nextval(pacl_entity_types_sequence)§")
	Long nextSequenceValEntityTypes();
	
	@SqlQuery("§select_nextval(pacl_party_types_sequence)§")
	Long nextSequenceValPartyTypes();

	@SqlUpdate("INSERT INTO pacl_entity_types (id, tenant_id, code, fl_entity_code_mandatory, fl_single_relation, fl_hidden) "
			+ "VALUES(:id, :tenantId, :code, :fl_entity_code_mandatory, :fl_single_relation, :fl_hidden)")
	void insertEntityType(@Bind("tenantId")String tenantId, @BindBean EntityTypeNTT entityTypeNTT);
	
	@SqlUpdate("INSERT INTO pacl_party_types (id, tenant_id, code, fl_exclusive, fl_manage) "
			+ "VALUES(:id, :tenantId, :code, :fl_exclusive, :fl_manage)")
	void insertPartyType(@Bind("tenantId")String tenantId, @BindBean PartyTypeNTT partyTypeNTT);
	
	@SqlUpdate("UPDATE \n"
			+ "   pacl_entity_types pet \n"
			+ "SET \n"
			+ "   fl_entity_code_mandatory = :fl_entity_code_mandatory, \n"
			+ "   fl_single_relation = :fl_single_relation, \n"
			+ "   fl_hidden = :fl_hidden \n"
			+ "where \n"
			+ "   pet.tenant_id = :tenantId \n"
			+ "   and pet.id = :id \n"
			+ "   and pet.code = :code \n"
			+ "")
	void updateEntityType(@Bind("tenantId")String tenantId, @BindBean EntityTypeNTT entityTypeNTT);
	
	@SqlUpdate("UPDATE \n"
			+ "   pacl_party_types ppt \n"
			+ "SET \n"
			+ "   fl_exclusive = :fl_exclusive, \n"
			+ "   fl_manage = :fl_manage \n"
			+ "where \n"
			+ "   ppt.tenant_id = :tenantId \n"
			+ "   and :party_type_id = ppt.id \n"
			+ "")
	void updatePartyType(@Bind("tenantId")String tenantId, @Bind("party_type_id")Long partyTypeId, 
			@Bind("fl_exclusive")Integer fl_exclusive, @Bind("fl_manage")Integer fl_manage);

	@SqlUpdate("INSERT INTO pacl_entity_party_type_links (party_type_id, entity_type_id) "
			+ "VALUES(:party_type_id, :entity_type_id)")
	void insertEntityPartyTypeLink(@Bind("party_type_id")Long partyTypeId, @Bind("entity_type_id")Long entityTypeId);

	@SqlQuery("select s_pet.id, \n"
			+ "    s_pet.code, \n"
			+ "    s_pet.fl_entity_code_mandatory, \n"
			+ "    s_pet.fl_single_relation, \n"
			+ "    s_pet.fl_hidden \n"
			+ "from pacl_entity_types s_pet \n"
			+ "left join pacl_entity_types t_pet on s_pet.code = t_pet.code and t_pet.tenant_id = :targetTenant  \n"
			+ "where s_pet.tenant_id = :sourceTenant \n"
			+ "and t_pet.code is null \n")
	List<EntityTypeNTT> findTenantEntityTypeDifference(@Bind("sourceTenant")String sourceTenant, @Bind("targetTenant")String targetTenant);
	
	@SqlQuery("select pet.id, \n"
			+ "    pet.code, \n"
			+ "    pet.fl_entity_code_mandatory, \n"
			+ "    pet.fl_single_relation, \n"
			+ "    pet.fl_hidden,  \n"
			+ "    coalesce(§i18n(:tenantId, 'pacl_entity_types', 'code', pet.code, :lang)§ , pet.code) as description \n"
			+ "from \n"
			+ "    pacl_entity_types pet \n"
			+ "where \n"
			+ "    pet.tenant_id = :tenantId \n"
			+ "    and pet.id = :entity_type_id \n"
			+ "order by pet.code \n"
			+ "")
	EntityTypeNTT getEntityTypeById(@BindBean ServiceSupportEnv env, @Bind("entity_type_id")Long entityTypeId);
	
	@SqlQuery("select pet.id, \n"
			+ "    pet.code, \n"
			+ "    pet.fl_entity_code_mandatory, \n"
			+ "    pet.fl_single_relation, \n"
			+ "    pet.fl_hidden, \n"
			+ "    coalesce(§i18n(:tenantId, 'pacl_entity_types', 'code', pet.code, :lang)§ , pet.code) as description \n"
			+ "from \n"
			+ "    pacl_entity_types pet \n"
			+ "where \n"
			+ "    pet.tenant_id = :tenantId \n"
			+ "    and pet.code = :entity_type_code \n"
			+ "order by pet.code"
			+ "")
	EntityTypeNTT getEntityTypeByCode(@BindBean ServiceSupportEnv env, @Bind("entity_type_code")String entityTypeCode);
	
	@SqlQuery("select pet.id, \n"
			+ "    pet.code, \n"
			+ "    pet.fl_entity_code_mandatory, \n"
			+ "    pet.fl_single_relation, \n"
			+ "    pet.fl_hidden, \n"
			+ "    coalesce(§i18n(:tenantId, 'pacl_entity_types', 'code', pet.code, :lang)§ , pet.code) as description \n"
			+ "from \n"
			+ "    pacl_entity_types pet \n"
			+ "where \n"
			+ "    pet.tenant_id = :tenantId \n"
			+ "    and coalesce(:entity_type_code, pet.code) = pet.code \n"
			+ "    and pet.fl_hidden = 0 \n"
			+ "order by pet.code"
			+ "")
	ResultIterator<EntityTypeNTT> getAllEntityType(@BindBean ServiceSupportEnv env, @Bind("entity_type_code")String entityTypeCode);
	
	@SqlQuery("Select \n"
			+ "    count(*) \n"
			+ "from \n"
			+ "    pacl_entity_party_type_links pl \n"
			+ "where \n"
			+ "    pl.party_type_id = :partyTypeId \n"
			+ "    and pl.entity_type_id = :entityTypeId \n"
			+ "")
	Integer checkEntityPartyTypeLink(@Bind("partyTypeId")Long partyTypeId, @Bind("entityTypeId")Long entityTypeId);

	@SqlQuery("Select \n"
			+ "    count(distinct ped.entity_id) \n"
			+ "from \n"
			+ "    pacl_entity_types pet \n"
			+ "    inner join pacl_entities_details ped on ped.entity_type_id = pet.id \n"
			+ "where \n"
			+ "    pet.tenant_id = :tenantId \n"
			+ "    and :entity_type_id = pet.id \n"
			+ "    and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ "")
	Long countEntitiesByType(@Bind("tenantId")String tenantId, @Bind("entity_type_id")Long entityTypeId);
	
	@SqlUpdate("DELETE \n"
			 + "FROM \n"
			 + "    pacl_entity_types pet\n"
			 + "where \n"
			 + "    pet.tenant_id = :tenantId \n"
			 + "    and :entity_type_id = pet.id \n"
			 + "")
	void deleteEntityType(@Bind("tenantId")String tenantId, @Bind("entity_type_id")Long entityTypeId);
	
	@SqlQuery("select \n"
			+ "   s_ppt.id,\n"
			+ "   s_ppt.code,\n"
			+ "   s_ppt.fl_exclusive,\n"
			+ "   s_ppt.fl_manage \n"
			+ "from pacl_party_types s_ppt \n"
			+ "left join pacl_party_types t_ppt on s_ppt.code = t_ppt.code and t_ppt.tenant_id = :targetTenant  \n"
			+ "where s_ppt.tenant_id = :sourceTenant \n"
			+ "and t_ppt.code is null \n")
	List<PartyTypeNTT> findTenantPartyTypeDifference(@Bind("sourceTenant")String sourceTenant, @Bind("targetTenant")String targetTenant);

	@SqlQuery("select\n"
			+ "   ppt.id,\n"
			+ "   ppt.code,\n"
			+ "   ppt.fl_exclusive,\n"
			+ "   ppt.fl_manage,"
			+ "   coalesce(§i18n(:tenantId, 'pacl_party_types', 'code', ppt.code, :lang)§ , ppt.code) as description \n"
			+ "from \n"
			+ "   pacl_party_types ppt \n"
			+ "where \n"
			+ "   ppt.tenant_id = :tenantId \n"
			+ "   and coalesce(:party_type_code, ppt.code) = ppt.code \n"
			+ "")
	ResultIterator<PartyTypeNTT> getAllPartyType(@BindBean ServiceSupportEnv env, @Bind("party_type_code")String partyTypeCode);
	
	@SqlQuery("select\n"
			+ "   ppt.id,\n"
			+ "   ppt.code,\n"
			+ "   ppt.fl_exclusive,\n"
			+ "   ppt.fl_manage, \n"
			+ "   coalesce(§i18n(:tenantId, 'pacl_party_types', 'code', ppt.code, :lang)§ , ppt.code) as description \n"
			+ "from \n"
			+ "   pacl_party_types ppt \n"
			+ "where \n"
			+ "   ppt.tenant_id = :tenantId \n"
			+ "   and ppt.id = :party_type_id \n"
			+ "")
	PartyTypeNTT getPartyTypeById(@BindBean ServiceSupportEnv env, @Bind("party_type_id")Long partyTypeId);
	
	@SqlQuery("select\n"
			+ "   ppt.id,\n"
			+ "   ppt.code,\n"
			+ "   ppt.fl_exclusive,\n"
			+ "   ppt.fl_manage, \n"
			+ "   coalesce(§i18n(:tenantId, 'pacl_party_types', 'code', ppt.code, :lang)§ , ppt.code) as description \n"
			+ "from \n"
			+ "   pacl_party_types ppt \n"
			+ "where \n"
			+ "   ppt.tenant_id = :tenantId \n"
			+ "   and ppt.code = :party_type_code \n"
			+ "")
	PartyTypeNTT getPartyTypeByCode(@BindBean ServiceSupportEnv env, @Bind("party_type_code")String partyTypeCode);

	@SqlQuery("Select \n"
			+ "   count(distinct pep.mandate_id) \n"
			+ "from \n"
			+ "   pacl_party_types ppt \n"
			+ "   inner join pacl_entities_parties pep on pep.party_type_id = ppt.id \n"
			+ "where \n"
			+ "   pep.tenant_id = :tenantId \n"
			+ "   and :party_type_id = ppt.id \n"
			+ "   and §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
			+ "")
	Integer countPartiesByType(@Bind("tenantId")String tenantId, @Bind("party_type_id")Long partyTypeId);
	
	@SqlUpdate("DELETE \n"
			 + "FROM \n"
			 + "   pacl_party_types ppt\n"
			 + "where \n"
			 + "   ppt.tenant_id = :tenantId \n"
			 + "   and :party_type_id = ppt.id \n"
			 + "")
	void deletePartyType(@Bind("tenantId")String tenantId, @Bind("party_type_id")Long partyTypeId);
	
	@SqlUpdate("DELETE \n"
			 + "FROM \n"
			 + "   pacl_entity_party_type_links pl \n"
			 + "where \n"
			 + "   pl.entity_type_id = :entity_type_id \n"
			 + "   and pl.party_type_id = :party_type_id \n"
			 + "")
	void deleteEntityPartyTypeLink(@Bind("party_type_id")Long partyTypeId, @Bind("entity_type_id")Long entityTypeId);
	
	@SqlUpdate("DELETE \n"
			 + "FROM \n"
			 + "   pacl_entity_party_type_links pl \n"
			 + "where \n"
			 + "   pl.party_type_id = :party_type_id \n"
			 + "   and pl.party_type_id in ( \n"
			 + "   select \n"
			 + "      ppt.id \n"
			 + "   from \n"
			 + "      pacl_party_types ppt \n"
			 + "   where \n"
			 + "      ppt.tenant_id = :tenantId)\n"
			 + "")
	void removeLinksWithPartyId(@Bind("tenantId")String tenantId, @Bind("party_type_id")Long partyTypeId);
	
	@SqlQuery("select\n"
			+ "   ppt.id,\n"
			+ "   ppt.code,\n"
			+ "   ppt.fl_exclusive,\n"
			+ "   ppt.fl_manage, \n"
			+ "   coalesce(§i18n(:tenantId, 'pacl_party_types', 'code', ppt.code, :lang)§ , ppt.code) as description \n"
			+ "from \n"
			+ "    pacl_party_types ppt \n"
			+ "    inner join pacl_entity_party_type_links pl on pl.party_type_id = ppt.id \n"
			+ "where \n"
			+ "    ppt.tenant_id = :tenantId \n"
			+ "    and pl.entity_type_id = :entityTypeId \n"
			+ "")
	List<PartyTypeNTT> getPartyTypeWithEntityType(@BindBean ServiceSupportEnv env, @Bind("entityTypeId")Long entityTypeId);
	
	@SqlQuery("select pet.id, \n"
			+ "    pet.code, \n"
			+ "    pet.fl_entity_code_mandatory, \n"
			+ "    pet.fl_single_relation, \n"
			+ "    pet.fl_hidden, \n"
			+ "    coalesce(§i18n(:tenantId, 'pacl_entity_types', 'code', pet.code, :lang)§ , pet.code) as description \n"
			+ "from \n"
			+ "    pacl_entity_types pet \n"
			+ "    inner join pacl_entity_party_type_links pl on pl.entity_type_id = pet.id \n"
			+ "where \n"
			+ "    pet.tenant_id = :tenantId \n"
			+ "    and pl.party_type_id = :partyTypeId \n"
			+ "")
	List<EntityTypeNTT> getEntityTypeWithPartyType(@BindBean ServiceSupportEnv env, @Bind("partyTypeId")Long partyTypeId);	
}
