package com.abacogroup.partiesaclserver.resources.req;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class CreateEntityPayload {
	@Schema(description = "Code of Entity", type = "string")
	private String code;

	@Schema(description = "Code of parent Entity (if any)", type = "string")
	private String parentCode;

	@Schema(description = "Entity's name", type = "string")
	private String name;

	@Schema(description = "Description of the entity", type = "string")
	private String description;

	@Schema(description = "Code of Entity type", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String entityTypeCode;

	@Schema(description = "registry party id", type = "string")
	private String registryPartyId;

	@Schema(description = "Start validity date - format YYYYMMDD", type = "string", format = "YYYYMMDD", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private AbsoluteDate dayFrom;

	@Schema(description = "End validity date - format YYYYMMDD", type = "string", format = "YYYYMMDD")
	private AbsoluteDate dayTo;

}
