package com.abacogroup.partiesaclserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.resources.pub.res.PartySearchV1Response;
import com.abacogroup.partiesaclserver.resources.res.PaclPartySearchResponse;

@Mapper
public interface PartySearchV1ResponseMapper {
	
	PartySearchV1ResponseMapper INSTANCE = Mappers.getMapper(PartySearchV1ResponseMapper.class);
	
	@InheritInverseConfiguration()
	PartySearchV1Response toResponseV1(PaclPartySearchResponse entity);
	
}
