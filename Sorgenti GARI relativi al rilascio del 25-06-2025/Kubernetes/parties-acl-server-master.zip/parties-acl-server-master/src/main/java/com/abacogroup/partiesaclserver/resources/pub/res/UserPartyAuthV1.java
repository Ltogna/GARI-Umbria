package com.abacogroup.partiesaclserver.resources.pub.res;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class UserPartyAuthV1 {
	
	@Schema(description = "true if the user has at least a mandate on the party", type = "boolean", nullable = false)
	@NotNull
	private boolean hasManadates;
	
	@Schema(description = "true if the user has at least a management mandate on the party", type = "boolean", nullable = false)
	@NotNull
	private boolean canManage;
	
	@Schema(description = "the max of the roles over the various mandates (ADMIN, STD or null if has no mandates)", type = "string", nullable = true)
	private String userRole;
	
}
