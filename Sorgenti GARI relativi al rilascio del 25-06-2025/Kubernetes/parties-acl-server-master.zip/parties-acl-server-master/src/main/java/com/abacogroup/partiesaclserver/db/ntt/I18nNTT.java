package com.abacogroup.partiesaclserver.db.ntt;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class I18nNTT {
	private String tenant_id;
	private String table_name;
	private String field_name;
	private String i18n_value;
	private String lang;
	private String i18n_text;
}
