package com.abacogroup.partiesaclserver.resources.res;

import java.util.LinkedHashMap;
import java.util.List;

import com.abacogroup.dynamicdocuments.bean.SummaryFieldDefinition;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder(setterPrefix = "set")
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class DocumentRes {
	
	private Long entityId;

	private String definitionCode;
	private Long documentId;

	private String bucketName;

	private List<SummaryFieldDefinition> summaryFieldDefinitions;
	private LinkedHashMap<String, Object> data;

}
