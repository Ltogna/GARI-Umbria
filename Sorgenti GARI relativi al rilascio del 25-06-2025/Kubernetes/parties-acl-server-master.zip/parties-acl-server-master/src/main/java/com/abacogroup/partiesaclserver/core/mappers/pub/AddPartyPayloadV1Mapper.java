package com.abacogroup.partiesaclserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.resources.pub.req.AddPartyPayloadV1;
import com.abacogroup.partiesaclserver.resources.req.AddPartyPayload;

@Mapper
public interface AddPartyPayloadV1Mapper {

	AddPartyPayloadV1Mapper INSTANCE = Mappers.getMapper(AddPartyPayloadV1Mapper.class);

	@InheritInverseConfiguration()
	AddPartyPayload toResponse(AddPartyPayloadV1 payload);

	
	AddPartyPayloadV1 toResponseV1(AddPartyPayload dto);

}