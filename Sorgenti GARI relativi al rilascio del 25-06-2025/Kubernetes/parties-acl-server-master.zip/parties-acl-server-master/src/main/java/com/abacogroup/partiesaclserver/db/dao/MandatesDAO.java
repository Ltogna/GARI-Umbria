package com.abacogroup.partiesaclserver.db.dao;

import java.sql.DatabaseMetaData;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.core.mapper.reflect.BeanMapper;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.core.statement.Query;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.partiesaclserver.core.enums.MandateStatus;
import com.abacogroup.partiesaclserver.core.enums.Revision;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.ntt.EntityNTT;
import com.abacogroup.partiesaclserver.db.ntt.EntityTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.MandatorUserNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyWithEntityNTT;
import com.abacogroup.partiesaclserver.db.ntt.UserPartyAuthNTT;
import com.abacogroup.partiesaclserver.db.ntt.UserPartyNTT;
import com.abacogroup.partiesaclserver.db.ntt.pub.MandatesCountNTT;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
@RegisterBeanMapper(PartyNTT.class)
@RegisterBeanMapper(PartyTypeNTT.class)
@RegisterBeanMapper(MandatorUserNTT.class)
public interface MandatesDAO extends Transactional<MandatesDAO>, EnhancedSqlObject {

	@SqlQuery("§select_nextval(pacl_entities_parties_sequence)§")
	Long nextSequenceValEntitiesParties();
	
	@SqlQuery("§select_nextval(pacl_entities_users_sequence)§")
	Long nextSequenceValEntitiesUsers();
	
	@SqlQuery("§select_nextval(pacl_entities_parties_mandate_id_sequence)§")
	Long nextSequenceValMandateId();

	@SqlUpdate("INSERT INTO pacl_entities_parties (pkid, tenant_id, mandate_id, day_from, day_to, entity_id, party_id, party_type_id, user_id_insert, user_id_delete, dt_insert, dt_delete, status, revision_code) "
			+ "VALUES(:pkid, :tenantId, :mandate_id, :day_from, :day_to, :entity_id, :party_id, :party_type.id, :user.userId, NULL, "
			+ "§current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :status, :revision_code)")
	void addPartyToEntity(@BindBean ServiceSupportEnv env, @BindBean PartyNTT partyNTT);
	
	@SqlUpdate("INSERT INTO pacl_entities_users (pkid, tenant_id, entity_id, user_id, role_code, description, user_id_insert, user_id_delete, dt_insert, dt_delete, username) "
			+ "VALUES(:pkid, :tenantId, :entity_id, :user_id, :role_code, :description, :user.userId, NULL, "
			+ "§current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :username)")
	void addUserToEntity(@BindBean ServiceSupportEnv env, @BindBean MandatorUserNTT userNTT);
	
	@SqlQuery("Select \n"
			+ "   count(*) \n"
			+ "from \n"
			+ "   pacl_entities_parties pep \n"
			+ "where \n"
			+ "   pep.tenant_id = :tenantId \n"
			+ "   and pep.entity_id = :entityId \n"
			+ "   and pep.party_id = :partyId \n"
			+ "   and ((:dayFrom between pep.day_from and pep.day_to) \n"
			+ "        or (:dayTo between pep.day_from and pep.day_to) \n"
			+ "        or (:dayFrom <= pep.day_from and :dayTo >= pep.day_to)) \n"
			+ "   and §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
			+ "")
	Integer checkPartyInEntity(@Bind("tenantId")String tenantId, @Bind("entityId")Long entityId, @Bind("partyId")String partyId,
			@Bind("dayFrom") AbsoluteDate dayFrom, @Bind("dayTo") AbsoluteDate dayTo);
	
	@SqlUpdate("UPDATE \n"
			+ "   pacl_entities_parties pep \n"
			+ "SET \n"
			+ "   revision_code = :revisionCode, \n"
			+ "   dt_delete = §current_timestamp§, \n"
			+ "   user_id_delete = :user.userId \n"
			+ "where \n"
			+ "   pep.tenant_id = :tenantId \n"
			+ "   and pep.mandate_id = :mandateId \n"
			+ "   and §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
			+ "")
	void outdateMandateFromEntity(@BindBean ServiceSupportEnv env, @Bind("mandateId")Long mandateId, @Bind("revisionCode") Revision revision);
	
	@SqlQuery("Select \n"
			+ "   count(*) \n"
			+ "from \n"
			+ "   pacl_entities_users pu \n"
			+ "where \n"
			+ "   pu.tenant_id = :tenantId \n"
			+ "   and pu.entity_id = :entityId \n"
			+ "   and upper(pu.user_id) = upper(:mandatorUserId) \n"
			+ "   and §current_timestamp§ between pu.dt_insert and pu.dt_delete \n"
			+ "")
	Integer checkUserInEntity(@Bind("tenantId")String tenantId, @Bind("entityId")Long entityId, @Bind("mandatorUserId")String mandatorUserId);
	
	@SqlUpdate("UPDATE \n"
			+ "   pacl_entities_users peu \n"
			+ "SET \n"
			+ "   dt_delete = §current_timestamp§, \n"
			+ "   user_id_delete = :user.userId \n"
			+ "where \n"
			+ "   peu.tenant_id = :tenantId \n"
			+ "   and peu.entity_id = :entityId \n"
			+ "   and upper(peu.user_id) = upper(:mandatorUserId) \n"
			+ "   and §current_timestamp§ between peu.dt_insert and peu.dt_delete \n"
			+ "")
	void outdateUserFromEntity(@BindBean ServiceSupportEnv env, @Bind("entityId")Long entityId, @Bind("mandatorUserId")String mandatorUserId);
	
	@SqlQuery("select \n"
			+ "   pep.entity_id \n"
			+ "from \n"
			+ "   pacl_entity_types pet \n"
			+ "   inner join pacl_entities_details ped on ped.entity_type_id = pet.id \n"
			+ "   inner join pacl_entities_parties pep on ped.entity_id = pep.entity_id \n"
			+ "where \n"
			+ "   pet.fl_single_relation = 1 \n"
			+ "   and pet.fl_hidden = 1 \n"
			+ "   and pep.party_id = :partyId \n"
			+ "   and pep.tenant_id = :tenantId \n"
			+ "   and §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
			+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ "")
	Long getSinglePartyEntityId(@Bind("tenantId")String tenantId, 
			@Bind("partyId")String partyId);
	
	@SqlQuery("select \n"
			+ "   pep.party_id, "
			+ "   pep.day_from, "
			+ "   pep.day_to, "
			+ "   pep.entity_id, "
			+ "   pep.mandate_id, "
			+ "   case when least(pep.day_to, ped.day_to) < :referenceDate then 'CLOSED' else pep.status end as status, "
			+ "   pep.revision_code, \n"
			+ "   ppt.id as ppt_id, "
			+ "   ppt.code as ppt_code, "
			+ "   ppt.fl_exclusive as ppt_fl_exclusive, \n"
			+ "   ppt.fl_manage as ppt_fl_manage, \n"
			+ "   coalesce(§i18n(:tenantId, 'pacl_party_types', 'code', ppt.code, :lang)§ , ppt.code) as ppt_description, \n"
			+ "from \n"
			+ "   pacl_entity_types pet \n"
			+ "   inner join pacl_entities_details ped on ped.entity_type_id = pet.id \n"
			+ "   inner join pacl_entities_parties pep on ped.entity_id = pep.entity_id \n"
			+ "   inner join pacl_party_types ppt on ppt.id = pep.party_type_id \n"
			+ "where \n"
			+ "   pet.fl_single_relation = 0 \n"
			+ "   and pet.fl_hidden = 0 \n"
			+ "   and pep.party_id = :partyId \n"
			+ "   and pep.entity_id = :entityId \n"
			+ "   and pep.tenant_id = :tenantId \n"
			+ "   and :referenceDate between pep.day_from and pep.day_to\n"
			+ "   and :referenceDate between ped.day_from and ped.day_to\n"
			+ "   and §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
			+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ "")
	PartyNTT getEntityParty(@BindBean ServiceSupportEnv env, @Bind("entityId")Long entityId, @Bind("partyId")String partyId);
	
	@SqlQuery("select \n"
			+ "   pep.party_id, "
			+ "   pep.day_from, "
			+ "   pep.day_to, "
			+ "   pep.entity_id, "
			+ "   pep.mandate_id, "
			+ "   case when least(pep.day_to, ped.day_to) < :referenceDate then 'CLOSED' else pep.status end as status, "
			+ "   pep.revision_code, \n"
			+ "   ppt.id as ppt_id, "
			+ "   ppt.code as ppt_code, "
			+ "   ppt.fl_exclusive as ppt_fl_exclusive, \n"
			+ "   ppt.fl_manage as ppt_fl_manage, \n"
			+ "   coalesce(§i18n(:tenantId, 'pacl_party_types', 'code', ppt.code, :lang)§ , ppt.code) as ppt_description \n"
			+ "from \n"
			+ "   pacl_entity_types pet \n"
			+ "   inner join pacl_entities_details ped on ped.entity_type_id = pet.id \n"
			+ "   inner join pacl_entities_parties pep on ped.entity_id = pep.entity_id \n"
			+ "   inner join pacl_party_types ppt on ppt.id = pep.party_type_id \n"
			+ "where \n"
			+ "   pep.mandate_id = :mandateId \n"
			+ "   and pep.tenant_id = :tenantId \n"
			+ "   and §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
			+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ "")
	PartyNTT getPartyByMandateId(@BindBean ServiceSupportEnv env, @Bind("mandateId")Long mandateId);

	@SqlQuery("select \n"
			+ "   peu.pkid,\n"
			+ "   peu.entity_id,\n"
			+ "   peu.user_id,\n"
			+ "   peu.role_code,\n"
			+ "   peu.username, \n"
			+ "   peu.description \n"
			+ "from \n"
			+ "   pacl_entity_types pet \n"
			+ "   inner join pacl_entities_details ped on ped.entity_type_id = pet.id \n"
			+ "   inner join pacl_entities_users peu on ped.entity_id = peu.entity_id \n"
			+ "where \n"
			+ "   pet.fl_single_relation = :fl_single_relation \n"
			+ "   and pet.fl_hidden = :fl_hidden \n"
			+ "   and upper(peu.user_id) = upper(:userId) \n"
			+ "   and peu.entity_id = :entityId \n"
			+ "   and peu.tenant_id = :tenantId \n"
			+ "   and §current_timestamp§ between peu.dt_insert and peu.dt_delete \n"
			+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ "")
	MandatorUserNTT getUserById(@Bind("tenantId")String tenantId, @Bind("entityId")Long entityId, @Bind("userId")String userId,
			@Bind("fl_single_relation")Integer flSingleRelation, @Bind("fl_hidden")Integer fl_hidden);
	
	default List<MandatorUserNTT> getParentHierarchy(String tenantId, Long entityId, String mandatorUserId, Integer isAdmin, 
			Integer includeLevels) {
		String dbType = withHandle(h -> h.queryMetadata(DatabaseMetaData::getDatabaseProductName));

		Boolean isPostgres = dbType.toLowerCase().contains("postgresql");
		
		String sql = "with " + (Boolean.TRUE.equals(isPostgres) ? "recursive" : "") + " parentEntity (entity_id, parent_id, lvl) as ( \n"
				+ "    select \n"
				+ "        ped.entity_id, \n"
				+ "        ped.parent_id, \n"
				+ "        0 as lvl \n"
				+ "    from \n"
				+ "        pacl_entities pe \n"
				+ "        inner join pacl_entities_details ped on pe.id = ped.entity_id and pe.tenant_id = :tenantId \n"
				+ "   where \n"
				+ "        §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "        and ped.entity_id = :entityId \n"
				+ "union all \n"
				+ "    select \n"
				+ "         ped.entity_id, \n"
				+ "         ped.parent_id, \n"
				+ "         ep.lvl + 1 \n"
				+ "    from \n"
				+ "         pacl_entities pe \n"
				+ "         inner join pacl_entities_details ped on pe.id = ped.entity_id and pe.tenant_id = :tenantId \n"
				+ "         join parentEntity ep on ep.parent_id = ped.entity_id \n"
				+ "   where \n"
				+ "         §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ ") \n" 
				+ ""
				+ "select pe.entity_id, \n"
				+ "       case when :isAdmin = 1 \n"
				+ "            then 'ADMIN'\n"
				+ "            else (select role_code \n"
				+ "                   from pacl_entities_users u \n"
				+ "                   where u.entity_id = pe.entity_id \n"
				+ "                   and upper(u.user_id) = upper(:mandatorUserId) \n"
				+ "                   and current_timestamp between u.dt_insert and u.dt_delete) \n"
				+ "            end as role_code \n"
				+ "from parentEntity pe \n"
				+ "where lvl <= :includeLevels or :includeLevels = -1 \n"
				;

		return withHandle(h -> 
		h.createQuery(sql)
		.bind("tenantId", tenantId) 
		.bind("mandatorUserId", mandatorUserId) 
		.bind("entityId", entityId)
		.bind("isAdmin", isAdmin)
		.bind("includeLevels", includeLevels)
		.registerRowMapper(BeanMapper.factory(MandatorUserNTT.class))
		.mapTo(MandatorUserNTT.class)
		.collect(Collectors.toList()));
	}

	@SqlQuery("select \n"
			+ "   count(distinct pep.mandate_id) \n"
			+ "from \n"
			+ "   pacl_entities_parties pep \n"
			+ "   inner join pacl_party_types ppt on ppt.id = pep.party_type_id \n"
			+ "where \n"
			+ "   pep.tenant_id = :tenantId \n"
			+ "   and ppt.fl_exclusive = 1 \n"
			+ "   and pep.party_id = :partyId \n"
			+ "   and pep.entity_id <> :entityId \n"
			+ "   and ((:dayFrom between pep.day_from and pep.day_to) \n"
			+ "        or (:dayTo between pep.day_from and pep.day_to) \n"
			+ "        or (:dayFrom <= pep.day_from and :dayTo >= pep.day_to)) \n"
			+ "   and §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
			+ "")
	Integer checkExclusiveParty(@Bind("tenantId")String tenantId, @Bind("entityId")Long entityId, @Bind("partyId") String partyId,  
			@Bind("dayFrom") AbsoluteDate dayFrom, @Bind("dayTo") AbsoluteDate dayTo);
	
	@SqlQuery("select \n"
			+ "   count(distinct pep.mandate_id) \n"
			+ "from \n"
			+ "   pacl_entities_parties pep \n"
			+ "   inner join pacl_party_types ppt on ppt.id = pep.party_type_id \n"
			+ "where \n"
			+ "   pep.tenant_id = :tenantId \n"
			+ "   and ppt.fl_exclusive = 1 \n"
			+ "   and pep.entity_id = :entityId \n"
			+ "   and :endDate < pep.day_to"
			+ "   and §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
			+ "")
	Integer checkExclusivePartiesAfterDate(@Bind("tenantId")String tenantId, @Bind("entityId")Long entityId, @Bind("endDate") AbsoluteDate endDate);
	
	@SqlQuery("select \n"
			+ "   peu.pkid,\n"
			+ "   peu.entity_id,\n"
			+ "   peu.user_id,\n"
			+ "   peu.role_code,\n"
			+ "   peu.username, \n"
			+ "   peu.description \n"
			+ "from \n"
			+ "   pacl_entities_users peu \n"
			+ "where \n"
			+ "   peu.tenant_id = :tenantId \n"
			+ "   and peu.entity_id = :entityId \n"
			+ "   and upper(peu.user_id) = upper(:userId) \n"
			+ "   and peu.role_code = 'ADMIN' \n"
			+ "   and §current_timestamp§ between peu.dt_insert and peu.dt_delete \n"
			+ "")
	MandatorUserNTT findAdmin(@BindBean ServiceSupportEnv env, @Bind("entityId")Long entityId, @Bind("userId")String userId);
	
	default ResultIterator<UserPartyNTT> getAllPartiesByUserId(ServiceSupportEnv env, String mandatorUserId, String partyId,
			Integer isAdmin, Integer includeLevels, Integer inheritManagement, List<MandateStatus> status){
		String dbType = withHandle(h -> h.queryMetadata(DatabaseMetaData::getDatabaseProductName));

		Boolean isPostgres = dbType.toLowerCase().contains("postgresql");
		
		String sql = "with " + (Boolean.TRUE.equals(isPostgres) ? "recursive" : "") + " parentEntity (entity_id, parent_id, lvl) as ( \n"
				+ "    select \n"
				+ "        ped.entity_id, \n"
				+ "        ped.parent_id, \n"
				+ "        0 as lvl \n"
				+ "    from \n"
				+ "        pacl_entities pe \n"
				+ "        inner join pacl_entities_details ped on pe.id = ped.entity_id and pe.tenant_id = :tenantId \n"
				+ "   where \n"
				+ "        §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "        and (:isAdmin = 1 or ped.entity_id in ("
				+ "                          select distinct ped.entity_id \n"
				+ "                            from pacl_entities_users pu \n"
				+ "                           where pu.tenant_id = :tenantId \n"
				+ "                             and upper(pu.user_id) = upper(:user.userId) \n"
				+ "                             and §current_timestamp§ between pu.dt_insert and pu.dt_delete \n"
				+ "                         ))\n"
				+ "union all \n"
				+ "    select \n"
				+ "         ped.entity_id, \n"
				+ "         ped.parent_id, \n"
				+ "         ep.lvl + 1 \n"
				+ "    from \n"
				+ "         pacl_entities pe \n"
				+ "         inner join pacl_entities_details ped on pe.id = ped.entity_id and pe.tenant_id = :tenantId \n"
				+ "         join parentEntity ep on ep.entity_id = ped.parent_id \n"
				+ "   where \n"
				+ "         §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "), \n" 
				+ "child_entities as (select entity_id from parentEntity where lvl <= :includeLevels or :includeLevels = -1), \n"
				+ "user_entities as ( \n"
				+ "      select ped.entity_type_id  as type_id,"
				+ "             ped.entity_id as id \n"
				+ "        from pacl_entities_users pu \n"
				+ "           inner join pacl_entities_details ped on pu.entity_id = ped.entity_id and pu.tenant_id = :tenantId \n"
				+ "       where (upper(pu.user_id) = upper(:user.userId) or :isAdmin = 1) \n"
				+ "         and §current_timestamp§ between pu.dt_insert and pu.dt_delete \n"
				+ "         and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ ") \n"
				+ ""
			    + "select \n"
				+ "   pep.party_id, \n"
				+ "   pep.day_from, \n"
				+ "   pep.day_to, \n"
				+ "   pep.entity_id,\n"
				+ "   pep.mandate_id, \n"
				+ "   case when least(pep.day_to, ped.day_to) < :referenceDate then 'CLOSED' else pep.status end as status, \n"
				+ "   pep.revision_code, \n"
				+ "   ppt.id as ppt_id, \n"
				+ "   ppt.code as ppt_code, \n"
				+ "   ppt.fl_exclusive as ppt_fl_exclusive, \n"
				+ "   case \n"
				+ "       when pep.entity_id in (select distinct id from user_entities) then ppt.fl_manage \n"
				+ "       when pep.entity_id in (select distinct entity_id from child_entities) and :inherit_management = 1 then ppt.fl_manage \n"
				+ "       else 0 end as ppt_fl_manage, \n"
				+ "   coalesce(§i18n(:tenantId, 'pacl_party_types', 'code', ppt.code, :lang)§ , ppt.code) as ppt_description, \n"
				+ "   (Select peu.user_id from pacl_entities_users peu where upper(peu.user_id) = upper(:userId) and peu.entity_id = pep.entity_id and §current_timestamp§ between peu.dt_insert and peu.dt_delete) as userId, \n"
				+ "   (Select peu.role_code from pacl_entities_users peu where upper(peu.user_id) = upper(:userId) and peu.entity_id = pep.entity_id and §current_timestamp§ between peu.dt_insert and peu.dt_delete) as userRole \n"
				+ "from \n"
				+ "   pacl_entities_users peu \n"
				+ "   inner join pacl_entities_details ped on ped.entity_id = peu.entity_id and peu.tenant_id = :tenantId \n"
				+ "   inner join pacl_entities_parties pep on pep.entity_id = ped.entity_id and pep.tenant_id = :tenantId \n"
				+ "   inner join pacl_party_types ppt on ppt.id = pep.party_type_id and pep.tenant_id = :tenantId \n"
				+ "where \n"
				+ "   upper(peu.user_id) = upper(:userId)\n"
				+ "   and coalesce(:partyId, pep.party_id) = pep.party_id \n"
				+ "   and :referenceDate between ped.day_from and ped.day_to \n"
				+ "   and :referenceDate between pep.day_from and pep.day_to \n"
				+ "   and ((<status>) is null or pep.status in (<status>)) \n"
				+ "   and §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
				+ "   and §current_timestamp§ between peu.dt_insert and peu.dt_delete \n"
				+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "   and peu.entity_id in (Select id from child_entities) \n"
				+ ""
				;
		
		return withHandle(h -> 
		h.createQuery(sql)
		.bindBean(env)
		.bind("userId", mandatorUserId)
		.bind("partyId", partyId)
		.bind("isAdmin", isAdmin)
		.bind("includeLevels", includeLevels)
		.bind("inherit_management", inheritManagement)
		.bindList("status", status)
		.registerRowMapper(BeanMapper.factory(UserPartyNTT.class))
		.registerRowMapper(BeanMapper.factory(PartyTypeNTT.class))
		.mapTo(UserPartyNTT.class)
		.iterator());
	}

	@SqlQuery("select \n"
			+ "   peu.pkid, \n"
			+ "   peu.tenant_id, \n"
			+ "   peu.entity_id, \n"
			+ "   peu.user_id, \n"
			+ "   peu.role_code, \n"
			+ "   peu.username, \n"
			+ "   peu.description \n"
			+ "from \n"
			+ "   pacl_entities_users peu \n"
			+ "where \n"
			+ "   peu.tenant_id = :tenantId \n"
			+ "   and peu.entity_id  = :entityId \n"
			+ "   and peu.role_code = 'ADMIN'"
			+ "   and §current_timestamp§ between peu.dt_insert and peu.dt_delete \n"
			+ "order by peu.user_id \n"
			+ "")
	List<MandatorUserNTT> getAllAdminByEntityId(@BindBean ServiceSupportEnv env, @Bind("entityId")Long entityId);
	
	@SqlQuery("select \n"
			+ "   peu.pkid, \n"
			+ "   peu.tenant_id, \n"
			+ "   peu.entity_id, \n"
			+ "   peu.user_id, \n"
			+ "   peu.role_code, \n"
			+ "   peu.username, \n"
			+ "   peu.description \n"
			+ "from \n"
			+ "   pacl_entities_users peu \n"
			+ "where \n"
			+ "   peu.tenant_id = :tenantId \n"
			+ "   and peu.entity_id  = :entityId \n"
			+ "   and upper(peu.username) like '%' || upper(coalesce (:usernameFilter, peu.username)) || '%' \n"
			+ "   and §current_timestamp§ between peu.dt_insert and peu.dt_delete \n"
			+ "order by peu.user_id \n"
			+ "")
	ResultIterator<MandatorUserNTT> getAllUsersByEntityId(@BindBean ServiceSupportEnv env, @Bind("entityId")Long entityId,
			@Bind("usernameFilter")String usernameFilter);

	
	default ResultIterator<PartyNTT> getAllPartiesIdByEntityId(ServiceSupportEnv env, Long entityId, Integer showOutdate, Integer includeLevels,
			Integer inheritManagement, List<MandateStatus> status){
		String dbType = withHandle(h -> h.queryMetadata(DatabaseMetaData::getDatabaseProductName));

		Boolean isPostgres = dbType.toLowerCase().contains("postgresql");
		String sql = "with " + (Boolean.TRUE.equals(isPostgres) ? "recursive" : "") + " parentEntity (entity_id, parent_id, lvl) as ( \n"
				+ "      select ped.entity_id, \n"
				+ "             ped.parent_id, \n"
				+ "             0 as lvl"
				+ "        from pacl_entities pe \n"
				+ "       inner join pacl_entities_details ped on pe.id = ped.entity_id \n"
				+ "       where ped.entity_id = :entityId \n"
				+ "          and pe.tenant_id = :tenantId \n"
				+ "          and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "          "
				+ "    union all \n"
				+ "      select ped.entity_id, \n"
				+ "             ped.parent_id, \n"
				+ "             ep.lvl + 1"
				+ "        from pacl_entities pe \n"
				+ "       inner join pacl_entities_details ped on pe.id = ped.entity_id \n"
				+ "        join parentEntity ep on ep.entity_id = ped.parent_id \n"
				+ "       where pe.tenant_id = :tenantId \n"
				+ "         and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "), \n"
				+ "child_entities as (select distinct entity_id from parentEntity where lvl <= :includeLevels or :includeLevels = -1) \n"
				+ ""
				+ "select \n"
				+ "   pep.party_id, \n"
				+ "   pep.day_from, \n"
				+ "   pep.day_to, \n"
				+ "   pep.entity_id, \n"
				+ "   pep.mandate_id, \n"
				+ "   case when least(pep.day_to, ped.day_to) < :referenceDate then 'CLOSED' else pep.status end as status, \n"
				+ "   pep.revision_code, \n"
				+ "   ppt.id as ppt_id, \n"
				+ "   ppt.code as ppt_code, \n"
				+ "   ppt.fl_exclusive as ppt_fl_exclusive, \n"
				+ "   case \n"
				+ "       when pep.entity_id = :entityId then ppt.fl_manage \n"
				+ "       when pep.entity_id in (select distinct entity_id from child_entities) and :inherit_management = 1 then ppt.fl_manage \n"
				+ "       else 0 end as ppt_fl_manage, \n"
				+ "   coalesce(§i18n(:tenantId, 'pacl_party_types', 'code', ppt.code, :lang)§ , ppt.code) as ppt_description \n"
				+ "from \n"
				+ "   pacl_entities_parties pep \n"
				+ "   inner join pacl_party_types ppt on ppt.id = pep.party_type_id \n"
				+ "   inner join pacl_entities_details ped on pep.entity_id = ped.entity_id \n"
				+ "where \n"
				+ "   pep.tenant_id = :tenantId \n"
				+ "   and pep.entity_id  in (select entity_id from child_entities) \n"
				+ "   and ((:referenceDate <= pep.day_to) or :showOutdate = 1) \n"
				+ "   and ((:referenceDate <= ped.day_to) or :showOutdate = 1) \n"
				+ "   and ((<status>) is null or pep.status in (<status>)) \n"
				+ "   and §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
				+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "order by pep.party_id, ppt.code \n"
				+ "";
		
		return withHandle(h -> h.createQuery(sql)
					.bindBean(env)
					.bind("entityId", entityId)
					.bind("showOutdate", showOutdate)
					.bindList("status", status)
					.bind("includeLevels", includeLevels)
					.bind("inherit_management", inheritManagement)
					.registerRowMapper(BeanMapper.factory(PartyNTT.class))
					.registerRowMapper(BeanMapper.factory(PartyTypeNTT.class))
					.mapTo(PartyNTT.class)
					.iterator()
					);
		
	}


	 default ResultIterator<PartyWithEntityNTT> getAllEntitiesByPartyId(ServiceSupportEnv env, Integer isAdmin, Integer includeLevels, 
			 Integer inheritManagement, Criteria criteria){
		
		String dbType = withHandle(h -> h.queryMetadata(DatabaseMetaData::getDatabaseProductName));

		Boolean isPostgres = dbType.toLowerCase().contains("postgresql");

		String internalCriteria = Optional.ofNullable(criteria)
				.map(Criteria::toSqlFragment)
				.filter(StringUtils::isNotBlank)
				.map(sql -> " AND "+sql)
				.orElse("");
		
		String sql = "with "+ (Boolean.TRUE.equals(isPostgres) ? "recursive" : "") + " parentEntity (entity_id, parent_id, role_code, lvl) as ( \n"
				+ "    select \n"
				+ "        ped.entity_id, \n"
				+ "        ped.parent_id, \n"
				+ "        case when :isAdmin = 1 "
				+ "             then 'ADMIN'"
				+ "             else (select role_code "
				+ "                   from pacl_entities_users u "
				+ "                   where u.entity_id = ped.entity_id "
				+ "                   and upper(u.user_id) = upper(:user.userId) "
				+ "                   and §current_timestamp§ between u.dt_insert and u.dt_delete) \n" 
				+ "             end as role_code, \n" 
				+ "        0 as lvl \n"
				+ "    from \n"
				+ "        pacl_entities pe \n"
				+ "        inner join pacl_entities_details ped on pe.id = ped.entity_id and pe.tenant_id = :tenantId \n"
				+ "   where \n"
				+ "        §current_timestamp§ between ped.dt_insert and ped.dt_delete \n";
				
				if(isAdmin != 1) {
					sql += "        and ped.entity_id in ("
					    + "                          select distinct ped.entity_id \n"
					    + "                            from pacl_entities_users pu \n"
					    + "                           where pu.tenant_id = :tenantId \n"
					    + "                             and upper(pu.user_id) = upper(:user.userId) \n"
					    + "                             and §current_timestamp§ between pu.dt_insert and pu.dt_delete \n"
					    + "                         )\n";
				}
				sql += "union all \n"
				+ "    select \n"
				+ "         ped.entity_id, \n"
				+ "         ped.parent_id, \n"
				+ "         ep.role_code, \n"
				+ "         ep.lvl + 1 \n"
				+ "    from \n"
				+ "         pacl_entities pe \n"
				+ "         inner join pacl_entities_details ped on pe.id = ped.entity_id and pe.tenant_id = :tenantId \n"
				+ "         join parentEntity ep on ep.entity_id = ped.parent_id \n"
				+ "   where \n"
				+ "         §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "), \n" 
				+ "child_entities as (select entity_id, role_code from parentEntity where lvl <= :includeLevels or :includeLevels = -1), \n"
				+ "user_entities as ( \n"
				+ "      select ped.entity_type_id  as type_id,"
				+ "             ped.entity_id as id \n"
				+ "        from pacl_entities_users pu \n"
				+ "           inner join pacl_entities_details ped on pu.entity_id = ped.entity_id and pu.tenant_id = :tenantId \n"
				+ "       where pu.user_id = upper(:user.userId) \n"
				+ "         and §current_timestamp§ between pu.dt_insert and pu.dt_delete \n"
				+ "         and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ ") \n"
				+ ""
				+ "select t.*, \n"
				+ "       (select description from pacl_entities_details where entity_id = t.entity_id and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as ped_description \n"  // clob data are not searchable
				+ "  from ("
				+ "      select \n"
				+ "         pep.party_id, "
				+ "         pep.day_from, "
				+ "         pep.day_to, "
				+ "         pep.entity_id, "
				+ "         pep.mandate_id, "
				+ "         case when least(pep.day_to, ped.day_to) < :referenceDate then 'CLOSED' else pep.status end as status, "
				+ "         pep.revision_code, \n"
				+ "         ppt.id as ppt_id, "
				+ "         ppt.code as ppt_code, "
				+ "         ppt.fl_exclusive as ppt_fl_exclusive, \n";
				
				if(isAdmin == 1) {
					sql += "         ppt.fl_manage as ppt_fl_manage, \n";
				} else {
					sql += "         case \n"
					+ "             when pep.entity_id in (select distinct id from user_entities) then ppt.fl_manage \n"
					+ "             when pep.entity_id in (select distinct entity_id from child_entities) and :inherit_management = 1 then ppt.fl_manage \n"
					+ "             else 0 end as ppt_fl_manage, \n";
				}
				
				sql += "         coalesce(§i18n(:tenantId, 'pacl_party_types', 'code', ppt.code, :lang)§ , ppt.code) as ppt_description, \n"
				+ "         ped.pkid as ped_pkid,\n"
				+ "         ped.entity_id as ped_entity_id,\n"
				+ "         ped.name as ped_name,\n"
				+ "         ped.code as ped_code,\n"
				+ "         ped.registry_party_id as ped_registry_party_id,\n"
				+ "         ped.parent_id as ped_parent_id,\n"
				+ "         (select name from pacl_entities_details where entity_id = coalesce(ped.parent_id, -1) and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as ped_parent_name, \n"
				+ "         (select code from pacl_entities_details where entity_id = coalesce(ped.parent_id, -1) and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as ped_parent_code, \n"
				+ "         ped.path as ped_path,\n"
				+ "         ped.day_from as ped_day_from,\n"
				+ "         ped.day_to as ped_day_to,\n"
				+ "         pet.id as ped_pet_id, \n"
				+ "         pet.code as ped_pet_code, \n"
				+ "         pet.fl_entity_code_mandatory as ped_pet_fl_entity_code_mandatory, \n"
				+ "         pet.fl_single_relation as ped_pet_fl_single_relation, \n"
				+ "         pet.fl_hidden as ped_pet_fl_hidden, \n"
				+ "         coalesce(§i18n(:tenantId, 'pacl_entity_types', 'code', pet.code, :lang)§ , pet.code) as ped_pet_description, \n"
				+ "         (Select peu.role_code from pacl_entities_users peu where peu.user_id = upper(:user.userId) and peu.entity_id = ped.entity_id and §current_timestamp§ between peu.dt_insert and peu.dt_delete) as ped_current_user_role, \n"
				+ "         case when pep.entity_id in (select distinct entity_id from child_entities where role_code = 'ADMIN') and least(pep.day_to, ped.day_to) >= :referenceDate then 1 else 0 end as editable, \n"
				+ "         case when ped.day_to >= :referenceDate then 0 else 1 end as ped_closed \n"
				+ "      from \n"
				+ "         pacl_entity_types pet"
				+ "         inner join pacl_entities_details ped on pet.id = ped.entity_type_id and pet.tenant_id = :tenantId \n"
				+ "         inner join pacl_entities_parties pep on pep.entity_id = ped.entity_id and pep.tenant_id = :tenantId\n"
				+ "         inner join pacl_party_types ppt on ppt.id = pep.party_type_id and ppt.tenant_id = :tenantId \n"
				+ "      where \n"
				+ "         §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
				+ "         and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ 			internalCriteria
				+ (isAdmin == 1 ? "" :"   and ped.entity_type_id in (select type_id from user_entities) \n")
				+ "      order by ppt_code, day_from desc \n"
				+ "   ) t \n"
				+ "";
				
				String finalSql = sql;
		
		return withHandle(h -> {
			Query query = h.createQuery(finalSql)
					.bindBean(env)
					.bind("isAdmin", isAdmin)
					.bind("includeLevels", includeLevels)
					.bind("inherit_management", inheritManagement);

			if (null != criteria) {
				criteria.bindTo(query);
			}

			return query
					.registerRowMapper(BeanMapper.factory(EntityNTT.class))
					.registerRowMapper(BeanMapper.factory(EntityTypeNTT.class))
					.registerRowMapper(BeanMapper.factory(PartyWithEntityNTT.class))
					.mapTo(PartyWithEntityNTT.class)
					.iterator();
		});
	}
	

	default PartyWithEntityNTT getPartyWithEntityByMandateId(ServiceSupportEnv env, Long mandateId, Integer isAdmin, Integer includeLevels, 
			Integer inheritManagement) {
		String dbType = withHandle(h -> h.queryMetadata(DatabaseMetaData::getDatabaseProductName));

		Boolean isPostgres = dbType.toLowerCase().contains("postgresql");		
		
		String sql = "with " + (Boolean.TRUE.equals(isPostgres) ? "recursive" : "") + " parentEntity (entity_id, parent_id, role_code, lvl) as ( \n"
				+ "    select \n"
				+ "        ped.entity_id, \n"
				+ "        ped.parent_id, \n"
				+ "        case when :isAdmin = 1 then 'ADMIN'"
				+ "             else (select role_code "
				+ "                   from pacl_entities_users u "
				+ "                   where u.entity_id = ped.entity_id "
				+ "                   and upper(u.user_id) = upper(:user.userId) "
				+ "                   and §current_timestamp§ between u.dt_insert and u.dt_delete) "
				+ "             end as role_code, \n" 
				+ "        0 as lvl \n"
				+ "    from \n"
				+ "        pacl_entities pe \n"
				+ "        inner join pacl_entities_details ped on pe.id = ped.entity_id and pe.tenant_id = :tenantId \n"
				+ "   where \n"
				+ "        §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "        and (:isAdmin = 1 or ped.entity_id in ("
				+ "                          select distinct ped.entity_id \n"
				+ "                            from pacl_entities_users pu \n"
				+ "                           where pu.tenant_id = :tenantId \n"
				+ "                             and upper(pu.user_id) = upper(:user.userId) \n"
				+ "                             and §current_timestamp§ between pu.dt_insert and pu.dt_delete \n"
				+ "                         ))\n"
				+ "union all \n"
				+ "    select \n"
				+ "         ped.entity_id, \n"
				+ "         ped.parent_id, \n"
				+ "         ep.role_code, \n"
				+ "         ep.lvl + 1 \n"
				+ "    from \n"
				+ "         pacl_entities pe \n"
				+ "         inner join pacl_entities_details ped on pe.id = ped.entity_id and pe.tenant_id = :tenantId \n"
				+ "         join parentEntity ep on ep.entity_id = ped.parent_id \n"
				+ "   where \n"
				+ "         §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "), \n"
				+ "child_entities as (select distinct entity_id, role_code from parentEntity where lvl <= :includeLevels or :includeLevels = -1) \n"
				+ ""
				+"select \n"
				+ "   pep.party_id, "
				+ "   pep.day_from, "
				+ "   pep.day_to, "
				+ "   pep.entity_id, "
				+ "   pep.mandate_id, "
				+ "   case when least(pep.day_to, ped.day_to) < :referenceDate then 'CLOSED' else pep.status end as status, "
				+ "   pep.revision_code, \n"
				+ "   ppt.id as ppt_id, "
				+ "   ppt.code as ppt_code, "
				+ "   ppt.fl_exclusive as ppt_fl_exclusive, \n"
				+ "   ppt.fl_manage as ppt_fl_manage, \n"
				+ "   coalesce(§i18n(:tenantId, 'pacl_party_types', 'code', ppt.code, :lang)§ , ppt.code) as ppt_description, \n"
				+ "   ped.pkid as ped_pkid,\n"
				+ "   ped.entity_id as ped_entity_id,\n"
				+ "   ped.name as ped_name,\n"
				+ "   ped.code as ped_code,\n"
				+ "   ped.registry_party_id as ped_registry_party_id,\n"
				+ "   ped.description as ped_description,\n"
				+ "   ped.parent_id as ped_parent_id,\n"
				+ "   (select name from pacl_entities_details where entity_id = coalesce(ped.parent_id, -1) and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as ped_parent_name, \n"
				+ "   (select code from pacl_entities_details where entity_id = coalesce(ped.parent_id, -1) and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as ped_parent_code, \n"
				+ "   ped.path as ped_path,\n"
				+ "   ped.day_from as ped_day_from,\n"
				+ "   ped.day_to as ped_day_to,\n"
				+ "   pet.id as ped_pet_id, \n"
				+ "   pet.code as ped_pet_code, \n"
				+ "   pet.fl_entity_code_mandatory as ped_pet_fl_entity_code_mandatory, \n"
				+ "   pet.fl_single_relation as ped_pet_fl_single_relation, \n"
				+ "   pet.fl_hidden as ped_pet_fl_hidden, \n"
				+ "   coalesce(§i18n(:tenantId, 'pacl_entity_types', 'code', pet.code, :lang)§ , pet.code) as ped_pet_description, \n"
				+ "   (Select peu.role_code from pacl_entities_users peu where upper(peu.user_id) = upper(:user.userId) and peu.entity_id = ped.entity_id and §current_timestamp§ between peu.dt_insert and peu.dt_delete) as ped_current_user_role, \n"
				+ "   case when pep.entity_id in (select distinct entity_id from child_entities where upper(role_code) = 'ADMIN') and least(pep.day_to, ped.day_to) >= :referenceDate then 1 else 0 end as editable, \n"
				+ "   case when ped.day_to >= :referenceDate then 0 else 1 end as ped_closed \n"
				+ "from \n"
				+ "   pacl_entity_types pet"
				+ "   inner join pacl_entities_details ped on pet.id = ped.entity_type_id and pet.tenant_id = :tenantId \n"
				+ "   inner join pacl_entities_parties pep on pep.entity_id = ped.entity_id and pep.tenant_id = :tenantId\n"
				+ "   inner join pacl_party_types ppt on ppt.id = pep.party_type_id and ppt.tenant_id = :tenantId \n"
				+ "where \n"
				+ "   pep.mandate_id  = :mandateId \n"
				+ "   and §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
				+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "";
		
		return withHandle(h -> h.createQuery(sql)
					.bindBean(env)
					.bind("mandateId", mandateId)
					.bind("isAdmin", isAdmin)
					.bind("includeLevels", includeLevels)
					.bind("inherit_management", inheritManagement)
					.registerRowMapper(BeanMapper.factory(EntityNTT.class))
					.registerRowMapper(BeanMapper.factory(EntityTypeNTT.class))
					.registerRowMapper(BeanMapper.factory(PartyWithEntityNTT.class))
					.mapTo(PartyWithEntityNTT.class)
					.first());
		}
	

	default List<PartyWithEntityNTT> getPartyByEntityTypeIdAndPartyTypeId(ServiceSupportEnv env, Long entityTypeId, Long partyTypeId, 
			Integer isAdmin, Integer includeLevels, Integer inheritManagement){
		String dbType = withHandle(h -> h.queryMetadata(DatabaseMetaData::getDatabaseProductName));

		Boolean isPostgres = dbType.toLowerCase().contains("postgresql");		
		
		String sql = "with " + (Boolean.TRUE.equals(isPostgres) ? "recursive" : "") + " parentEntity (entity_id, parent_id, role_code, lvl) as ( \n"
				+ "    select \n"
				+ "        ped.entity_id, \n"
				+ "        ped.parent_id, \n"
				+ "        case when :isAdmin = 1 "
				+ "             then 'ADMIN'"
				+ "             else (select role_code "
				+ "                   from pacl_entities_users u "
				+ "                   where u.entity_id = ped.entity_id "
				+ "                   and upper(u.user_id) = upper(:user.userId) "
				+ "                   and §current_timestamp§ between u.dt_insert and u.dt_delete) \n" 
				+ "             end as role_code, \n" 
				+ "        0 as lvl \n"
				+ "    from \n"
				+ "        pacl_entities pe \n"
				+ "        inner join pacl_entities_details ped on pe.id = ped.entity_id and pe.tenant_id = :tenantId \n"
				+ "   where \n"
				+ "        §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "        and (:isAdmin = 1 or ped.entity_id in ("
				+ "                          select distinct ped.entity_id \n"
				+ "                            from pacl_entities_users pu \n"
				+ "                           where pu.tenant_id = :tenantId \n"
				+ "                             and upper(pu.user_id) = upper(:user.userId) \n"
				+ "                             and §current_timestamp§ between pu.dt_insert and pu.dt_delete \n"
				+ "                         ))\n"
				+ "union all \n"
				+ "    select \n"
				+ "         ped.entity_id, \n"
				+ "         ped.parent_id, \n"
				+ "         ep.role_code, \n"
				+ "         ep.lvl + 1 \n"
				+ "    from \n"
				+ "         pacl_entities pe \n"
				+ "         inner join pacl_entities_details ped on pe.id = ped.entity_id and pe.tenant_id = :tenantId \n"
				+ "         join parentEntity ep on ep.entity_id = ped.parent_id \n"
				+ "   where \n"
				+ "         §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "), \n" 
				+ "child_entities as (select distinct entity_id, role_code from parentEntity where lvl <= :includeLevels or :includeLevels = -1) \n"
				+ ""
				+ ""
				+"select \n"
				+ "   pep.party_id, "
				+ "   pep.day_from, "
				+ "   pep.day_to, "
				+ "   pep.entity_id, "
				+ "   pep.mandate_id, "
				+ "   case when least(pep.day_to, ped.day_to) < :referenceDate then 'CLOSED' else pep.status end as status, "
				+ "   pep.revision_code, \n"
				+ "   ppt.id as ppt_id, "
				+ "   ppt.code as ppt_code, "
				+ "   ppt.fl_exclusive as ppt_fl_exclusive, \n"
				+ "   ppt.fl_manage as ppt_fl_manage, \n"
				+ "   coalesce(§i18n(:tenantId, 'pacl_party_types', 'code', ppt.code, :lang)§ , ppt.code) as ppt_description, \n"
				+ "   ped.pkid as ped_pkid,\n"
				+ "   ped.entity_id as ped_entity_id,\n"
				+ "   ped.name as ped_name,\n"
				+ "   ped.code as ped_code,\n"
				+ "   ped.registry_party_id as ped_registry_party_id,\n"
				+ "   ped.description as ped_description,\n"
				+ "   ped.parent_id as ped_parent_id,\n"
				+ "   (select name from pacl_entities_details where entity_id = coalesce(ped.parent_id, -1) and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as ped_parent_name, \n"
				+ "   (select code from pacl_entities_details where entity_id = coalesce(ped.parent_id, -1) and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as ped_parent_code, \n"
				+ "   ped.path as ped_path,\n"
				+ "   ped.day_from as ped_day_from,\n"
				+ "   ped.day_to as ped_day_to,\n"
				+ "   pet.id as ped_pet_id, \n"
				+ "   pet.code as ped_pet_code, \n"
				+ "   pet.fl_entity_code_mandatory as ped_pet_fl_entity_code_mandatory, \n"
				+ "   pet.fl_single_relation as ped_pet_fl_single_relation, \n"
				+ "   pet.fl_hidden as ped_pet_fl_hidden, \n"
				+ "   coalesce(§i18n(:tenantId, 'pacl_entity_types', 'code', pet.code, :lang)§ , pet.code) as ped_pet_description, \n"
				+ "   (Select peu.role_code from pacl_entities_users peu where upper(peu.user_id) = upper(:user.userId) and peu.entity_id = ped.entity_id and §current_timestamp§ between peu.dt_insert and peu.dt_delete) as ped_current_user_role, \n"
				+ "   case when pep.entity_id in (select distinct entity_id from child_entities where upper(role_code) = 'ADMIN') and least(pep.day_to, ped.day_to) >= :referenceDate then 1 else 0 end as editable, \n"
				+ "   case when ped.day_to >= :referenceDate then 0 else 1 end as ped_closed \n"
				+ "from \n"
				+ "   pacl_entity_types pet \n"
				+ "   inner join pacl_entities_details ped on ped.entity_type_id = pet.id and pet.tenant_id = :tenantId \n"
				+ "   inner join pacl_entities_parties pep on ped.entity_id = pep.entity_id and pep.tenant_id = :tenantId \n"
				+ "   inner join pacl_party_types ppt on ppt.id = pep.party_type_id and ppt.tenant_id = :tenantId\n"
				+ "where \n"
				+ "   pep.party_type_id  = :partyTypeId \n"
				+ "   and ped.entity_type_id  = :entityTypeId \n"
				+ "   and :referenceDate <= ped.day_to \n"
				+ "   and :referenceDate <= pep.day_to \n"
				+ "   and §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
				+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "";
		
		
		return withHandle(h -> h.createQuery(sql)
				.bindBean(env)
				.bind("entityTypeId", entityTypeId)
				.bind("partyTypeId", partyTypeId)
				.bind("isAdmin", isAdmin)
				.bind("includeLevels", includeLevels)
				.bind("inherit_management", inheritManagement)
				.registerRowMapper(BeanMapper.factory(EntityNTT.class))
				.registerRowMapper(BeanMapper.factory(EntityTypeNTT.class))
				.registerRowMapper(BeanMapper.factory(PartyWithEntityNTT.class))
				.mapTo(PartyWithEntityNTT.class)
				.collect(Collectors.toList()));
		
	}
	
	@SqlQuery("select case when count(*) > 0 then 1 else 0 end \n"
			+ "  from pacl_entities_details ped \n"
			+ " inner join pacl_entities_users peu on ped.path like '%/'||peu.entity_id||'/%' \n"
			+ " inner join pacl_entities_parties pep on ped.entity_id = pep.entity_id \n"
			+ " inner join pacl_party_types ppt on pep.party_type_id = ppt.id \n"
			+ " where peu.tenant_id = :tenantId \n"
			+ "   and upper(peu.user_id) = upper(:user.userId) \n"
			+ "   and ppt.fl_manage = 1 \n"
			+ "   and (pep.party_id = :partyId or pep.party_id = '*') \n"
			+ "   and :referenceDate between ped.day_from and ped.day_to \n"
			+ "   and :referenceDate between pep.day_from and pep.day_to \n"
			+ "   and pep.status = 'VALID' \n"
			+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ "   and §current_timestamp§ between peu.dt_insert and peu.dt_delete \n"
			+ "   and §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
			+ "")
	Boolean hasManage(@BindBean ServiceSupportEnv env, @Bind("partyId") String partyId);
	
	@SqlQuery("select case when mandatesCount = 0 then 0 else 1 end as hasManadates, \n"
			+ "       case when maxManage = 1 then 1 else 0 end as canManage, \n"
			+ "       case when maxRole = 1 then 'ADMIN' when maxRole = 0 then 'STD' else null end as userRole \n"
			+ "  from ( \n"
			+ "    select count(*) as mandatesCount, \n"
			+ "           max(fl_manage) as maxManage, \n"
			+ "           max(case when peu.role_code = 'ADMIN' then 1 when peu.role_code = 'STD' then 0 else null end) as maxRole \n"
			+ "      from pacl_entities_details ped \n"
			+ "     inner join pacl_entities_users peu on ped.path like '%/'||peu.entity_id||'/%' \n"
			+ "     inner join pacl_entities_parties pep on ped.entity_id = pep.entity_id \n"
			+ "     inner join pacl_party_types ppt on pep.party_type_id = ppt.id \n"
			+ "     where peu.tenant_id = :tenantId \n"
			+ "       and upper(peu.user_id) = upper(:user.userId) \n"
			+ "       and (pep.party_id = :partyId or pep.party_id = '*') \n"
			+ "       and pep.status = 'VALID' \n"
			+ "       and :referenceDate between ped.day_from and ped.day_to \n"
			+ "       and :referenceDate between pep.day_from and pep.day_to \n"
			+ "       and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ "       and §current_timestamp§ between peu.dt_insert and peu.dt_delete \n"
			+ "       and §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
			+ ") findPermission")
	@RegisterBeanMapper(UserPartyAuthNTT.class)
	UserPartyAuthNTT findPermissionByUserAndParty(@BindBean ServiceSupportEnv env, @Bind("partyId") String partyId);

	default MandatesCountNTT getMandatesCount(ServiceSupportEnv env, String partyId, 
			Integer isAdmin, Integer includeLevels, Integer inheritManagement){
		
		String dbType = withHandle(h -> h.queryMetadata(DatabaseMetaData::getDatabaseProductName));

		Boolean isPostgres = dbType.toLowerCase().contains("postgresql");
		
		String sql = "with " + (Boolean.TRUE.equals(isPostgres) ? "recursive" : "") + " parentEntity (entity_id, parent_id, lvl) as ( \n"
				+ "    select \n"
				+ "        ped.entity_id, \n"
				+ "        ped.parent_id, \n"
				+ "        0 as lvl \n"
				+ "    from \n"
				+ "        pacl_entities pe \n"
				+ "        inner join pacl_entities_details ped on pe.id = ped.entity_id and pe.tenant_id = :tenantId \n"
				+ "   where \n"
				+ "        §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "        and (:isAdmin = 1 or ped.entity_id in ("
				+ "                          select distinct ped.entity_id \n"
				+ "                            from pacl_entities_users pu \n"
				+ "                           where pu.tenant_id = :tenantId \n"
				+ "                             and upper(pu.user_id) = upper(:user.userId) \n"
				+ "                             and §current_timestamp§ between pu.dt_insert and pu.dt_delete \n"
				+ "                         ))\n"
				+ "union all \n"
				+ "    select \n"
				+ "         ped.entity_id, \n"
				+ "         ped.parent_id, \n"
				+ "         ep.lvl + 1 \n"
				+ "    from \n"
				+ "         pacl_entities pe \n"
				+ "         inner join pacl_entities_details ped on pe.id = ped.entity_id and pe.tenant_id = :tenantId \n"
				+ "         join parentEntity ep on ep.entity_id = ped.parent_id \n"
				+ "   where \n"
				+ "         §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "), \n" 
				+ "ranked_data as ( \n"
				+ "   select type_id, id, role_code, lvl, row_number() over (partition by type_id, id order by lvl desc) as rn \n"
				+ "   from ("
				+ "      select ped.entity_type_id  as type_id,"
				+ "             ped.entity_id as id, \n"
				+ "             pu.role_code, \n"
				+ "             case \n"
				+ "     		     when pu.role_code = 'ADMIN' then 2  \n"
				+ "     		     when pu.role_code = 'STD' then 1  \n"
				+ "     		     when pu.role_code is null then 0  \n"
				+ "             end as lvl"
				+ "        from pacl_entities_users pu \n"
				+ "           inner join pacl_entities_details ped on pu.entity_id = ped.entity_id and pu.tenant_id = :tenantId \n"
				+ "       where (upper(pu.user_id) = upper(:user.userId) or :isAdmin = 1) \n"
				+ "         and §current_timestamp§ between pu.dt_insert and pu.dt_delete \n"
				+ "         and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "   ) t"
				+ "), \n"
				+ "user_entities as (select type_id, id, role_code from ranked_data where rn = 1 ), \n"
				+ "child_entities as (select entity_id from parentEntity where lvl <= :includeLevels or :includeLevels = -1) \n"
				+ ""
				+ "select \n"
				+ "    count(*) as mandatesCount, \n"
				+ "    count(case when fl_manage = 1 then 1 end) as manageCount, \n"
				+ "    count(case when fl_exclusive = 1 then 1 end) as exclusiveCount \n"
				+ "from ( \n"
				+ "select \n"
				+ "    pep.mandate_id, \n"
				+ "    case \n"
				+ "        when pep.entity_id in (select distinct id from user_entities) then ppt.fl_manage \n"
				+ "        when pep.entity_id in (select distinct entity_id from child_entities) and :inherit_management = 1 then ppt.fl_manage \n"
				+ "        else 0 end as fl_manage, \n"
				+ "    ppt.fl_exclusive \n"
				+ "from \n"
				+ "    pacl_party_types ppt \n"
				+ "    inner join pacl_entities_parties pep on ppt.tenant_id = :tenantId and ppt.id = pep.party_type_id and pep.tenant_id = :tenantId \n"
				+ "    inner join pacl_entities_details ped on pep.entity_id = ped.entity_id \n"
				+ "    inner join pacl_entities pe on pe.id = ped.entity_id and pe.tenant_id = :tenantId \n"
				+ "where "
				+ "    pep.party_id  = :partyId \n"
				+ "    and pep.status = 'VALID' \n"
				+ "    and :referenceDate <= pep.day_to \n"
				+ "    and :referenceDate <= ped.day_to \n"
				+ "    and §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
				+ "    and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "    and ped.entity_type_id in (select type_id from user_entities)"
				+ ") rec"
				+ "";
		
		return withHandle(h -> 
		h.createQuery(sql)
		.bindBean(env)
		.bind("partyId", partyId)
		.bind("isAdmin", isAdmin)
		.bind("includeLevels", includeLevels)
		.bind("inherit_management", inheritManagement)
		.registerRowMapper(BeanMapper.factory(MandatesCountNTT.class))
		.mapTo(MandatesCountNTT.class)
		.first());
	}
	
	
}
