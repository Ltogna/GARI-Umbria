package com.abacogroup.partiesaclserver.resources.res;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class HasManageRes {
	private Boolean canRead;
}
