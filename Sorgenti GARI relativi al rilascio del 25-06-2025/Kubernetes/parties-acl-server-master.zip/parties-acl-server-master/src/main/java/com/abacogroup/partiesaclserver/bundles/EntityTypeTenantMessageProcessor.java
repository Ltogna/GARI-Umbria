package com.abacogroup.partiesaclserver.bundles;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.db.dao.TenantDAO;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.partiesaclserver.core.exceptions.bundles.BundleEntityTypeException;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.TypesDAO;
import com.abacogroup.partiesaclserver.db.ntt.EntityTypeNTT;


public class EntityTypeTenantMessageProcessor implements PartiesACLTenantMessageProcessor {

	private static final String TEMPLATE_TENANT_ID = "*";

	private TenantDAO tenantDAO;
	private TypesDAO typesDAO;

	private static final Logger log = LoggerFactory.getLogger(EntityTypeTenantMessageProcessor.class);

	public EntityTypeTenantMessageProcessor(DAOContainer dc) {
		this.tenantDAO= dc.getTenantDAO();
		this.typesDAO = dc.getTypesDAO();
	}

	@Override
	public void onMessage(TenantMessage message) {
		String tenantId = message.getTenantId();

		if (tenantId.equals(TEMPLATE_TENANT_ID)) {
			return;
		}

		List<EntityTypeNTT> entityTypeList = typesDAO.findTenantEntityTypeDifference(TEMPLATE_TENANT_ID, tenantId);

		ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).build();

		entityTypeList.stream()
		.filter(t -> typesDAO.getPartyTypeByCode(env, t.getCode()) == null)
		.forEach(type -> {
			type.setId(typesDAO.nextSequenceValEntityTypes());
			try {
				typesDAO.insertEntityType(tenantId, type);
			} catch (Exception e) {
				throw new BundleEntityTypeException("Error during insert entity type message " + message.toString() + " for tenant " + tenantId + ".\n" + e.getMessage());
			}
		});

	}

	@Override
	public void syncAllTenant() {
		tenantDAO.findAll().forEach(t -> onMessage(new TenantMessage().setTenantId(t.getTenantId())));
	}
}
