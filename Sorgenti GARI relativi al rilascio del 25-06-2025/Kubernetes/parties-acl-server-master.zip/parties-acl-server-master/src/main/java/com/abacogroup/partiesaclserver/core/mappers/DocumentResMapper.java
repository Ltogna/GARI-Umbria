package com.abacogroup.partiesaclserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.db.ntt.DocumentNTT;
import com.abacogroup.partiesaclserver.resources.res.EntityDocumentRes;
import com.abacogroup.partiesaclserver.resources.res.MandateDocumentRes;

@Mapper
public interface DocumentResMapper {
	
	DocumentResMapper INSTANCE = Mappers.getMapper(DocumentResMapper.class);
	
	@InheritInverseConfiguration()	
	@Mapping(target = "bucketName", ignore = true)
	@Mapping(target = "data", ignore = true)
	@Mapping(target = "summaryFieldDefinitions", ignore = true)
	MandateDocumentRes toMandateDocumentRes(DocumentNTT entity);

	@InheritInverseConfiguration()	
	@Mapping(target = "bucketName", ignore = true)
	@Mapping(target = "data", ignore = true)
	@Mapping(target = "summaryFieldDefinitions", ignore = true)
	EntityDocumentRes toEntityDocumentRes(DocumentNTT entity);
}