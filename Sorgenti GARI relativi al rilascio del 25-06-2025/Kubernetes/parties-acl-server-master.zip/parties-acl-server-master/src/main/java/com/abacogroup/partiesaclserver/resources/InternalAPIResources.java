package com.abacogroup.partiesaclserver.resources;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partiesaclserver.core.InternalAPIService;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.resources.res.ClientConfiguration;
import com.abacogroup.partiesaclserver.resources.res.PathDetails;
import com.abacogroup.partiesaclserver.resources.res.RevisionHistory;
import com.abacogroup.partiesaclserver.resources.res.TenantsList;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.constraints.NotBlank;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_INTERNAL)
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class InternalAPIResources {
	
	private InternalAPIService internalAPIService;
	
	public InternalAPIResources(InternalAPIService internalAPIService) {
		this.internalAPIService = internalAPIService;
	}

	@GET
	@Hidden
	@Path("/{tenant}/revisions")
	/**
	 * Get revision history starting from the id in query param
	 * @param lang
	 * @param tenantId: The tenant to search
	 * @param fromId: The initial id for history, if not found respond 404 with the lastId in revisions table
	 * @param nextKey: next page id for infinite pagination
	 * @return status 200 if a valid id with the list of new revisions, 
	 *         status 404 when "fromId" not found, in the error response there will be the last revision id valid 
	 */
	public InfiniteListResults<RevisionHistory> getHistoryWithLastId(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@PathParam("tenant") String tenantId,
			@QueryParam("fromId") Long fromId,
			@QueryParam("nextKey") String nextKey) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(null)
				.lang(lang)
				.tenantId(tenantId)
				.build();

		return internalAPIService.getHistoryWithLastId(env, fromId, nextKey);
	}
	
	@GET
	@Hidden
	@Path("/{tenant}/mandates")
	/**
	 * Get full flat configuration for users paties mandates 
	 * @param lang
	 * @param tenantId: The tenant to search
	 * @param nextKey: next page id for infinite pagination
	 * @return status 200 with the full flat path configuration of mandates
	 */
	public InfiniteListResults<PathDetails> getFullRevisionHistory(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@PathParam("tenant") String tenantId,
			@QueryParam("nextKey") String nextKey) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(null)
				.lang(lang)
				.tenantId(tenantId)
				.build();

		return internalAPIService.getFullRevisionHistory(env, nextKey);
	}
		
	@GET
	@Hidden
	@Path("/tenants")
	/**
	 * Get full list of configured tenants from pacl_entities 
	 * @param lang
	 * @return status 200 with the list of configured tenants from pacl_entities
	 */
	public TenantsList getTenantsList(@HeaderParam("accept-language") @DefaultValue("en") String lang) {
		return internalAPIService.getTenantsList();
	}
	
	@GET
	@Hidden
	@Path("/{tenant}/config")
	public ClientConfiguration getClientConfigKey(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "config key") @QueryParam("configKey") @NotBlank String configKey) {
		
		return internalAPIService.getClientConfigKey(tenantId, lang, configKey);
	}
	
}
