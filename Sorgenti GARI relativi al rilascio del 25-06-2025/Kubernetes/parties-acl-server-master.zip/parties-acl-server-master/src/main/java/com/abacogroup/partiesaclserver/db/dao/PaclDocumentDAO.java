package com.abacogroup.partiesaclserver.db.dao;

import java.util.Optional;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.partiesaclserver.core.enums.DocTypeRelationScope;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.ntt.DocumentNTT;

public interface PaclDocumentDAO extends Transactional<PaclDocumentDAO>, EnhancedSqlObject {
	
	@SqlQuery("§select_nextval(pacl_documents_sequence)§")
	Long nextSequenceVal();

	@SqlUpdate("INSERT INTO pacl_documents (pkid, scope_code, entity_id, mandate_id, definition_code, document_id, user_id_insert, user_id_delete, dt_insert, dt_delete) "
					+ " VALUES (:pkid, :scopeCode, :entityId, :mandateId, :definitionCode, :documentId, :user.userId, NULL, \n"
					+ " §current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	@RegisterBeanMapper(DocumentNTT.class)
	void insert(@BindBean ServiceSupportEnv env, @BindBean DocumentNTT documentNTT);
	
	@SqlUpdate("update pacl_documents set dt_delete = §current_timestamp§, user_id_delete=:user.userId where pkid = :pkid")
	void expireRow(@BindBean ServiceSupportEnv env, @Bind("pkid") Long pkid);


	@SqlQuery("select count(*) "
			+ "FROM pacl_documents pd "
			+ "where pd.scope_code = :scopeCode \n"
			+ "   and pd.entity_id = :entityId \n"
			+ "   and pd.mandate_id = :mandateId \n"
			+ "   and pd.definition_code = :definitionCode \n"
			+ "   and §current_timestamp§ between pd.dt_insert and pd.dt_delete \n")
	Long countByDefinitionCodeEntityIdAndMandateId(
			@Bind("tenantId") String tenantId, 
			@Bind("scopeCode") DocTypeRelationScope scopeCode,
			@Bind("entityId") Long entityId, 
			@Bind("mandateId") Long mandateId, 
			@Bind("definitionCode") String code);

	
	@SqlQuery("select pd.pkid, \n"
			+ "   pd.scope_code, \n"
			+ "   pd.entity_id, \n"
			+ "   pd.mandate_id, \n"
			+ "   pd.definition_code, \n"
			+ "   pd.document_id \n"
			+ " FROM pacl_documents pd "
			+ " where pd.scope_code = :scopeCode "
			+ " and pd.entity_id = :entityId "
			+ " and pd.mandate_id = :mandateId "
			+ " and pd.document_id = :documentId "
			+ " and (§current_timestamp§ between pd.dt_insert and pd.dt_delete) "
			+ " ORDER BY pd.scope_code, pd.definition_code, pd.entity_id, pd.mandate_id ")
	@RegisterBeanMapper(DocumentNTT.class)
	Optional<DocumentNTT> getByDocumentIdEntityIdAndMandateId(
			@Bind("scopeCode") DocTypeRelationScope scopeCode,
			@Bind("entityId") Long entityId, 
			@Bind("mandateId") Long mandateId, 
			@Bind("documentId") Long documentId);
	
	@SqlQuery("select pd.pkid, \n"
			+ "   pd.scope_code, \n"
			+ "   pd.entity_id, \n"
			+ "   pd.mandate_id, \n"
			+ "   pd.definition_code, \n"
			+ "   pd.document_id \n"
			+ " FROM pacl_documents pd "
			+ " where pd.scope_code = :scopeCode "
			+ " and pd.entity_id = :entityId "
			+ " and pd.mandate_id = :mandateId "
			+ " and coalesce(:definitionCode, pd.definition_code) = pd.definition_code "
			+ " and (§current_timestamp§ between pd.dt_insert and pd.dt_delete) "
			+ " ORDER BY pd.scope_code, pd.definition_code, pd.entity_id, pd.mandate_id ")
	@RegisterBeanMapper(DocumentNTT.class)
	ResultIterator<DocumentNTT> search(
			@Bind("scopeCode") DocTypeRelationScope scopeCode,
			@Bind("entityId") Long entityId, 
			@Bind("mandateId") Long mandateId,
			@Bind("definitionCode") String code);
}