package com.abacogroup.partiesaclserver.db.ntt;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EntityTypeNTT {
	private Long id;
	private String code;
	private String description;
	private Integer fl_entity_code_mandatory;
	private Integer fl_single_relation;
	private Integer fl_hidden;
}
