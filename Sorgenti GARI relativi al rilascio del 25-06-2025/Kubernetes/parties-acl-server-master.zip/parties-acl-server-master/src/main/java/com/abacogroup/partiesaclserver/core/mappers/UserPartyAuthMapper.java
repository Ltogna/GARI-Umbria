package com.abacogroup.partiesaclserver.core.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.db.ntt.UserPartyAuthNTT;
import com.abacogroup.partiesaclserver.resources.res.UserPartyAuth;

@Mapper
public interface UserPartyAuthMapper {

	UserPartyAuthMapper INSTANCE = Mappers.getMapper(UserPartyAuthMapper.class);
	
	UserPartyAuth entityTODto(UserPartyAuthNTT type);
	
	UserPartyAuthNTT dtoToEntity(UserPartyAuth dto);
	
}
