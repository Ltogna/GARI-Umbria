package com.abacogroup.partiesaclserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.resources.pub.req.CreateEntityPayloadV1;
import com.abacogroup.partiesaclserver.resources.req.CreateEntityPayload;

@Mapper
public interface CreateEntityPayloadV1Mapper {

	CreateEntityPayloadV1Mapper INSTANCE = Mappers.getMapper(CreateEntityPayloadV1Mapper.class);

	@InheritInverseConfiguration()
	CreateEntityPayload toResponse(CreateEntityPayloadV1 payload);

	
	CreateEntityPayloadV1 toResponseV1(CreateEntityPayload dto);

}