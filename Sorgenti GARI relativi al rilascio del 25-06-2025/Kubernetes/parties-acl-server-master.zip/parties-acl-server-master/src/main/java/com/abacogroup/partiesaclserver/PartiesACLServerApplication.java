package com.abacogroup.partiesaclserver;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.sql.DatabaseMetaData;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.jdbi.v3.core.Jdbi;

import com.abacogroup.bundles.db.dao.TenantDAO;
import com.abacogroup.bundles.initializer.BundleInitServiceBuilder;
import com.abacogroup.bundles.initializer.InitService;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.listener.ListenerBuilder;
import com.abacogroup.bundles.listener.configdata.builder.ConfigDataConsumerBuilder;
import com.abacogroup.bundles.listener.tenant.builder.NewTenantEventConsumerBuilder;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.SsoAuthorizer;
import com.abacogroup.dynamicdocuments.auth.impl.Sso2AuthenticatorProvider;
import com.abacogroup.dynamicdocuments.files.AbacoFileStore;
import com.abacogroup.dynamicdocuments.files.FileStoreSupport;
import com.abacogroup.dynamicdocuments.http.JaxRsClient;
import com.abacogroup.dynamicdocuments.http.RestClient;
import com.abacogroup.dynamicdocuments.http.Sso2AuthenticationProvider;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.embeddedqueue.AbstractWorkQueue;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisher;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisherWorkQueue;
import com.abacogroup.filestore.client.FileStoreClient;
import com.abacogroup.jdbi.OraJdbiPlugin;
import com.abacogroup.jdbi.OraJdbiPlugin.OraJdbiPluginParams;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.jdbi.config.AbacoJdbiConfig;
import com.abacogroup.partiesaclserver.bundles.*;
import com.abacogroup.partiesaclserver.core.*;
import com.abacogroup.partiesaclserver.core.pub.EntitiesV1Service;
import com.abacogroup.partiesaclserver.core.pub.MandatesV1Service;
import com.abacogroup.partiesaclserver.core.pub.TypesV1Service;
import com.abacogroup.partiesaclserver.core.queues.UpdateMandateStatusQueue;
import com.abacogroup.partiesaclserver.db.dao.*;
import com.abacogroup.partiesaclserver.dispatch.payload.UpdatePACLPayload;
import com.abacogroup.partiesaclserver.rabbitmq.RabbitMqConfig;
import com.abacogroup.partiesaclserver.rabbitmq.RabbitMqUtils;
import com.abacogroup.partiesaclserver.resources.*;
import com.abacogroup.partiesaclserver.resources.pub.PublicEntitiesResources;
import com.abacogroup.partiesaclserver.resources.pub.PublicMandatesResources;
import com.abacogroup.partiesaclserver.resources.pub.PublicTypesResources;
import com.abacogroup.tracing.dropwizard.AbacoApplication;
import com.abacogroup.tracing.jaxrs.client.AddRequestId;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;

import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.jdbi3.JdbiFactory;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import io.dropwizard.migrations.MigrationsBundle;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import io.swagger.v3.oas.integration.SwaggerConfiguration;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration.Dynamic;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleConnection;

@Slf4j
public class PartiesACLServerApplication extends AbacoApplication<PartiesACLServerConfiguration> {

	public static final String PARTIES_ACL_SERVER_NAME = "parties-acl-server";
	private static final int UPDATE_MANDATES_QUEUE_NUM_THREADS = 1; // Execute only one queue at a time to avoid conflicts
	private static final long TIMEOUT_MS = 1800000;

	public static void main(final String[] args) throws Exception {
		new PartiesACLServerApplication().run(args);
	}

	@Override
	public String getName() {
		return PARTIES_ACL_SERVER_NAME;
	}

	@Override
	public void initialize(final Bootstrap<PartiesACLServerConfiguration> bootstrap) {

		bootstrap.addBundle(new MigrationsBundle<>() {
			@Override
			public DataSourceFactory getDataSourceFactory(PartiesACLServerConfiguration configuration) {
				return configuration.getDatabase();
			}
		});

		SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
				new EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);

	}

	@Override
	public void doRun(final PartiesACLServerConfiguration configuration, final Environment environment) throws IOException {

		Jdbi jdbi = jdbi(configuration, environment);

		ObjectMapper objectMapper = environment.getObjectMapper();
		configure(objectMapper);

		// http client
		JerseyClientConfiguration clientConfig = configuration.getJerseyClientConfiguration();
		final Client client = new JerseyClientBuilder(environment).using(clientConfig).build(getName());
		client.register(new AddRequestId());

		Sso2Client sso2Client = new Sso2Client(configuration.getSso2AuthPhrase(), client.target(configuration.getSso2Url()));

		final WebTarget anomaliesRegistryWT = client.target(configuration.getAnomaliesRegistryUrl());
		final WebTarget partiesRegistryWT = client.target(configuration.getPartiesRegistryUrl());
		final WebTarget fileStoreWT = client.target(configuration.getFileStoreUrl());
		final WebTarget sso2ServerWT = client.target(configuration.getSso2Url());

		FileStoreClient fileStoreClient = new FileStoreClient(URI.create(configuration.getFileStoreUrl()), objectMapper);

		FileStoreSupport fileStoreSupport = this.register(new AbacoFileStore(fileStoreClient, new Sso2AuthenticatorProvider(sso2Client)));
		RestClient restClient = this.register(this.initRestClient(configuration, environment, sso2Client));

		final DAOContainer daoContainer = DAOContainer.builder()
				.mandatesDAO(jdbi.onDemand(MandatesDAO.class))
				.entityDAO(jdbi.onDemand(EntityDAO.class))
				.revisionHistoryDAO(jdbi.onDemand(RevisionHistoryDAO.class))
				.typesDAO(jdbi.onDemand(TypesDAO.class))
				.i18nDAO(jdbi.onDemand(I18nDAO.class))
				.configDAO(jdbi.onDemand(ConfigDAO.class))
				.anomalyCategoriesDAO(jdbi.onDemand(AnomalyCategoriesDAO.class))
				.tenantDAO(jdbi.onDemand(TenantDAO.class))
				.docTypeRelationDAO(jdbi.onDemand(DocTypeRelationDAO.class))
				.paclDocumentDAO(jdbi.onDemand(PaclDocumentDAO.class))
				.build();

		Connection rabbitMqConnection = RabbitMqUtils.createRabbitMqConnection(configuration.getRabbitMqConfig());

		final AbstractWorkQueue<UpdatePACLPayload, ?> updateMessageQueue = createUpdateMessageQueue(environment, jdbi, objectMapper, rabbitMqConnection);

		final InternalConfigService internalConfigService = this.register(new InternalConfigService(daoContainer, configuration));
		final ErrorDescriptionsService errorDescriptionsService = this.register(new ErrorDescriptionsService(daoContainer));

		final RevisionService revisionService = this.register(new RevisionService(daoContainer, updateMessageQueue));

		final SecurityService securityService = this.register(new SecurityService(daoContainer, errorDescriptionsService, sso2Client, sso2ServerWT));
		final UtilityService utilityService = this
				.register(new UtilityService(daoContainer, securityService, revisionService, internalConfigService, errorDescriptionsService));

		final AnomaliesService anomaliesService = this
				.register(new AnomaliesService(daoContainer, anomaliesRegistryWT, internalConfigService, utilityService, errorDescriptionsService));
		final PartyRegistryClientService partyRegistryClientService = this.register(new PartyRegistryClientService(daoContainer, partiesRegistryWT,
				utilityService, internalConfigService, securityService, errorDescriptionsService));
		final TypesService typesService = this.register(new TypesService(daoContainer, utilityService, errorDescriptionsService));
		final MandatesService mandatesService = this.register(new MandatesService(daoContainer, securityService, revisionService, internalConfigService,
				anomaliesService, errorDescriptionsService, utilityService));
		final EntitiesService entitiesService = this.register(new EntitiesService(daoContainer, securityService, revisionService, internalConfigService,
				utilityService, partyRegistryClientService, errorDescriptionsService));
		final SupportService supportService = this.register(new SupportService(internalConfigService, errorDescriptionsService));
		final DocumentTypeService documentTypeService = this.register(new DocumentTypeService(jdbi));
		final DocumentService documentService = register(
				DocumentService.create(documentTypeService, restClient, fileStoreSupport, configuration.getDynamicDocumentsBucket()));
		final FileStoreProxyClientService fileStoreClientService = this.register(new FileStoreProxyClientService(sso2Client, fileStoreWT));
		final MandateDocumentService mandateDocumentsService = this.register(new MandateDocumentService(daoContainer, utilityService, documentService,
				documentTypeService, errorDescriptionsService, fileStoreClientService, configuration.getDynamicDocumentsBucket()));
		final DocTypeService docTypeService = this.register(new DocTypeService(daoContainer, utilityService, errorDescriptionsService, mandateDocumentsService,
				documentTypeService, securityService, configuration.getDynamicDocumentsBucket()));

		final UpdateMandateStatusQueue updateMandateStatusQueue = createUpdateMandateStatusQueue(environment, jdbi, objectMapper, utilityService);

		List<Object> resources = new ArrayList<>();
		resources.add(new UtilityResources());
		resources.add(new MandatesResources(mandatesService));
		resources.add(new EntitiesResources(entitiesService));
		resources.add(new TypesResources(typesService));
		resources.add(new SupportResources(supportService));
		resources.add(new AnomaliesResources(anomaliesService));
		resources.add(new DocTypeResource(docTypeService));
		resources.add(new MandateDocumentsResource(mandateDocumentsService));
		// ... ...

		// #######################################################################
		// ### PUBLIC RESOURCES AND SERVICES ###################################
		// #######################################################################

		final TypesV1Service typesV1Service = this.register(new TypesV1Service(typesService));
		final EntitiesV1Service entitiesV1Service = this.register(new EntitiesV1Service(entitiesService));
		final MandatesV1Service mandatesV1Service = this.register(new MandatesV1Service(entitiesService, mandatesService, partyRegistryClientService));

		resources.add(new PublicTypesResources(typesV1Service));
		resources.add(new PublicEntitiesResources(entitiesV1Service));
		resources.add(new PublicMandatesResources(mandatesV1Service));

		// ### LOAD RESOURCES ##################################################
		resources.forEach(environment.jersey()::register);

		// #######################################################################
		// ### Unauthenticated not exposed Internal API
		final InternalAPIService internalAPIService = this.register(new InternalAPIService(daoContainer, internalConfigService, errorDescriptionsService));
		environment.jersey().register(new InternalAPIResources(internalAPIService));
		environment.jersey().register(new OldInternalAPIResources(internalAPIService));
		// #######################################################################

		createBundleInfrastructure(rabbitMqConnection, jdbi, daoContainer, configuration, documentTypeService, updateMandateStatusQueue);

		syncAllTenant(daoContainer);

		initAuth(environment, sso2Client);

		initMultiTenant(environment);
		initOpenApi(environment.jersey());
		setupCORS(configuration, environment);

	}

	private RestClient initRestClient(PartiesACLServerConfiguration configuration, Environment environment, Sso2Client sso2Client) {
		final Client client = new JerseyClientBuilder(environment)
				.using(configuration.getJerseyClientConfiguration())
				.build("restclient");
		client.register(new AddRequestId());

		return new JaxRsClient(client, new Sso2AuthenticationProvider(sso2Client));
	}

	private void createBundleInfrastructure(Connection rabbitMqConnection, Jdbi jdbi, DAOContainer daoContainer, PartiesACLServerConfiguration configuration,
			DocumentTypeService documentTypeService, UpdateMandateStatusQueue updateMandateStatusQueue) {
		if (rabbitMqConnection == null) {
			log.info("NOT CONNECTED TO RABBITMQ; bundles infrastructure is disabled");
			return;
		}

		final String serviceName = PARTIES_ACL_SERVER_NAME;

		try {
			ListenerBuilder.newBuilder(rabbitMqConnection)
					.withConfigDataConsumer(ConfigDataConsumerBuilder.newBuilder(jdbi, rabbitMqConnection)
							.route(serviceName)
							.processors(
									new InternalConfigMessageProcessor(daoContainer),
									new EntityTypeMessageProcessor(daoContainer),
									new PartyTypeMessageProcessor(daoContainer),
									new I18nMessageProcessor(daoContainer),
									new AnomalyCategoriesMessageProcessor(daoContainer),
									new DynamicDocConfigMessageProcessor(daoContainer, documentTypeService, updateMandateStatusQueue))
							.build())
					.withNewTenantEventConsumer(NewTenantEventConsumerBuilder.newBuilder(jdbi).route(serviceName)
							.processors(
									new InternalConfigTenantMessageProcessor(daoContainer),
									new EntityTypeTenantMessageProcessor(daoContainer),
									new PartyTypeTenantMessageProcessor(daoContainer),
									new I18nTenantMessageProcessor(daoContainer))
							.build())
					.buildListener()
					.start();

			InitService bundleInitService = BundleInitServiceBuilder
					.producer(this.register(new BundleInitServiceProducer(rabbitMqConnection)))
					.configLocation(configuration.getBundlesConfigLocation())
					// .baseTempDir()
					.build();
			bundleInitService.start();
		} catch (Exception e) {
			throw new IllegalStateException("Error starting rabbitmq listener \n" + e.getMessage());
		}
	}

	private void syncAllTenant(DAOContainer daoContainer) {
		new EntityTypeTenantMessageProcessor(daoContainer).syncAllTenant();
		new PartyTypeTenantMessageProcessor(daoContainer).syncAllTenant();
		new I18nTenantMessageProcessor(daoContainer).syncAllTenant();
	}

	protected <T> T register(T service) {
		return service;
	}

	protected Jdbi jdbi(final PartiesACLServerConfiguration configuration, final Environment environment) {
		final JdbiFactory factory = new JdbiFactory();
		final Jdbi jdbi = factory.build(environment, configuration.getDatabase(), "PartiesACLServerApplication");

		jdbi.configure(AbacoJdbiConfig.class, cfg -> cfg.setTablesPrefix("pacl"));

		boolean isPostgres = jdbi.withHandle(h -> {
			String db = h.queryMetadata(DatabaseMetaData::getDatabaseProductName);
			log.info("Database connection is '{}'", db);
			return db.toLowerCase().contains("postgresql");
		});

		if (isPostgres) {
			jdbi.installPlugin(new PgJdbiPlugin());
		} else {
			OraJdbiPluginParams params = new OraJdbiPluginParams(cnn -> cnn.unwrap(OracleConnection.class), true);
			jdbi.installPlugin(new OraJdbiPlugin(params));
		}

		return jdbi;
	}

	private void configure(ObjectMapper objectMapper) {
		objectMapper
				.setTimeZone(TimeZone.getDefault())
				.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

		SimpleModule module = new SimpleModule("custom-deserializers", Version.unknownVersion());
		objectMapper.registerModule(module);
	}

	private AbstractWorkQueue<UpdatePACLPayload, ?> createUpdateMessageQueue(Environment environment, Jdbi jdbi,
			ObjectMapper objectMapper, Connection rabbitMqConnection) throws IOException {
		if (rabbitMqConnection == null)
			return null;

		RabbitMqPublisherWorkQueue<UpdatePACLPayload> queue = RabbitMqPublisherWorkQueue
				.builder(RabbitMqConfig.QUEUE_ID, new JdbiRepository(jdbi), UpdatePACLPayload.class)
				.build();

		queue.setMetricRegistry(environment.metrics());

		RabbitMqPublisher<UpdatePACLPayload> consumer = new RabbitMqPublisher<UpdatePACLPayload>(rabbitMqConnection) {

			@Override
			public String getRoutingKey(UpdatePACLPayload arg0) {
				return RabbitMqConfig.ROUTING_KEY;
			}

			@Override
			public String getExchangeName() {
				return getName();
			}

			@Override
			public void declareExchange(Channel channel) throws IOException {
				channel.exchangeDeclare(getExchangeName(), BuiltinExchangeType.FANOUT, true);
			}
		};

		consumer.setObjectMapper(objectMapper);
		queue.setConsumer(consumer);

		queue.start();

		return queue;
	}

	private UpdateMandateStatusQueue createUpdateMandateStatusQueue(Environment environment, Jdbi jdbi,
			ObjectMapper objectMapper, UtilityService utilityService) {

		UpdateMandateStatusQueue queue = new UpdateMandateStatusQueue(new JdbiRepository(jdbi), environment.metrics(), UPDATE_MANDATES_QUEUE_NUM_THREADS,
				TIMEOUT_MS, objectMapper, utilityService);

		queue.start();

		return queue;
	}

	private void initAuth(Environment environment, Sso2Client sso2Client) {

		AuthUtils.installAuthFilter(
				environment,
				sso2Client,
				new SsoAuthorizer(sso2Client));
	}

	private void initMultiTenant(Environment environment) {
		environment.jersey().register(new MultitenantFilter("tenant"));
	}

	private void initOpenApi(JerseyEnvironment jersey) {
		OpenAPI oas = new OpenAPI();
		oas.info(new Info()
				.title("ABACO")
				// .termsOfService("http://example.com/terms")
				.contact(new Contact().email("info@abacogroup.eu")));

		// If exist try to set swagger openapi infos from pom.xml data
		try {
			Properties prop = new Properties();
			InputStream input = PartiesACLServerApplication.class.getResourceAsStream("/partiesACLServer.properties");
			prop.load(input);
			String name = prop.getProperty("api.name");
			String description = prop.getProperty("api.description");
			String version = prop.getProperty("api.version");

			oas.setInfo(new Info()
					.title("ABACO-" + name)
					.description(description)
					.version(version));

		} catch (Exception ex) {
			log.warn("Error during read openapi properties file: ", ex);
		}

		SwaggerConfiguration oasConfig = new SwaggerConfiguration()
				.openAPI(oas)
				.prettyPrint(true)
				.resourcePackages(Stream.of("com.abacogroup.partiesaclserver")
						.collect(Collectors.toSet()));

		jersey.register(new OpenApiResource()
				.openApiConfiguration(oasConfig));
	}

	private void setupCORS(PartiesACLServerConfiguration configuration, Environment environment) {
		if (!configuration.isCors()) {
			log.info("CORS is disabled");
			return;
		}

		log.info("CORS is enabled");

		Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,DELETE");

		// Add URL mapping
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");

	}

}
