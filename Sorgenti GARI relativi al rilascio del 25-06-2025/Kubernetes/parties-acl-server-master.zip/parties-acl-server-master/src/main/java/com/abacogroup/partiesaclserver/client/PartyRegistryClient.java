package com.abacogroup.partiesaclserver.client;

import jakarta.ws.rs.client.WebTarget;

public class PartyRegistryClient extends ClientHelper {
	public PartyRegistryClient(WebTarget webTarget) {
		super(webTarget);
	}
}
