package com.abacogroup.partiesaclserver.resources.res;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class RevisionHistory {
	@Schema(description = "revision id", type = "integer", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Long id;
	
	@Schema(description = "ADD_USER | ADD_PARTY | REMOVE_USER | REMOVE_PARTY | TRUNC_PATH | EXT_PATH", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String operation;
	
	@Schema(description = "Id of modified object (USER | PARTY)", type = "string")
	private String objectId;
	
	@Schema(description = "Old tree path of the Entity", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String oldPath;
	
	@Schema(description = "New tree path of the Entity", type = "string")
	private String newPath;
	
	@Schema(description = "updated object data", type = "string")
	private Object objectData;
	
	@Schema(description = "revision date", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private AbsoluteDate revisionDate;
	
}


