package com.abacogroup.partiesaclserver.core.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PartyRegistryResponse {

	private String lastName;
	private String firstName;

}
