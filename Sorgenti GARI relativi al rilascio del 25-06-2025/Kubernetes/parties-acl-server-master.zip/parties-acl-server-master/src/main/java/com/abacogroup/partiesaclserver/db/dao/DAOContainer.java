package com.abacogroup.partiesaclserver.db.dao;

import com.abacogroup.bundles.db.dao.TenantDAO;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DAOContainer {

	private MandatesDAO mandatesDAO;
	private EntityDAO entityDAO;
	private RevisionHistoryDAO revisionHistoryDAO;
	private TypesDAO typesDAO;
	private I18nDAO i18nDAO;
	private ConfigDAO configDAO;
	private AnomalyCategoriesDAO anomalyCategoriesDAO;
	private TenantDAO tenantDAO;
	private PaclDocumentDAO paclDocumentDAO;
	private DocTypeRelationDAO docTypeRelationDAO;
}
