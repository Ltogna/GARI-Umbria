package com.abacogroup.partiesaclserver.bundles;

import java.util.List;

import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import com.abacogroup.partiesaclserver.core.exceptions.bundles.BundleInternalConfigException;
import com.abacogroup.partiesaclserver.db.dao.ConfigDAO;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.ntt.ConfigNTT;


public class InternalConfigTenantMessageProcessor implements TenantMessageProcessor {

	private static final String TEMPLATE_TENANT_ID = "*";

	private ConfigDAO configDAO;

	public InternalConfigTenantMessageProcessor(DAOContainer dc) {
		this.configDAO = dc.getConfigDAO();
	}

	@Override
	public void onMessage(TenantMessage message) {
		String tenantId = message.getTenantId();

		if (tenantId.equals(TEMPLATE_TENANT_ID)) {
			return;
		}

		if (configDAO.getAllTenants().contains(tenantId)) {
			return;
		}

		List<ConfigNTT> generalConfig = configDAO.getConfigByTenant(TEMPLATE_TENANT_ID);

		if (generalConfig != null) {
			generalConfig.forEach(config -> {
				try {
					configDAO.insert(
							ConfigNTT.builder()
									.tenantId(tenantId)
									.key(config.getKey())
									.value(config.getValue())
									.fl_client(config.getFl_client())
									.name(config.getName())
									.build());
				} catch (Exception e) {
					throw new BundleInternalConfigException("Error during insert of internal config key '" + config.getKey() + "' with value '" + config.getValue() + "'.\n" + e.getMessage());
				}
			});
		}
	}
}
