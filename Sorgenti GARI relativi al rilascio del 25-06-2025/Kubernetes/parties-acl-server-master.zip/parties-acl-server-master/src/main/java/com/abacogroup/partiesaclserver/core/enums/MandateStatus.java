package com.abacogroup.partiesaclserver.core.enums;

public enum MandateStatus {
	 VALID,
	 NOT_VALID,
	 CLOSED;
}
