package com.abacogroup.partiesaclserver.resources.res;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PaclPartySearchResponseInfinite {
	
	private String nextKey;
	private List<PaclPartySearchResponse> records;
	private Long count; 

}
