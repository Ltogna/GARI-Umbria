package com.abacogroup.partiesaclserver.core;

import java.util.List;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.UserFunction;
import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.security.UserNotAllowedExecption;
import com.abacogroup.partiesaclserver.core.exceptions.security.UserNotFoundExecption;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.MandatesDAO;
import com.abacogroup.partiesaclserver.db.ntt.MandatorUserNTT;
import com.abacogroup.partiesaclserver.resources.res.UserData;

import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class SecurityService {

	private ErrorDescriptionsService errorDescriptionsService;
	private MandatesDAO mandatesDAO;
	private Sso2Client sso2Client;
	private WebTarget sso2ServerWT;
	
	private static final String CONTEXT_ID_PACL = "PACL";
	private static final String ADMIN = "ADMIN";
	

	public SecurityService(DAOContainer container, ErrorDescriptionsService errorDescriptionsService, Sso2Client sso2Client, WebTarget sso2ServerWT) {
		this.errorDescriptionsService = errorDescriptionsService;
		this.mandatesDAO = container.getMandatesDAO();
		this.sso2Client = sso2Client;
		this.sso2ServerWT = sso2ServerWT;
	}

	public void checkPermission(ServiceSupportEnv env, Long entityId, Boolean canEdit, Operation operation, ErrorField errorField) {
		if(Operation.UPDATE_MANDATE_STATUS_QUEUE.equals(operation)) {
			return;
		}

		if(env == null || env.getUser() == null || env.getUser().getUserId() == null || entityId == null || entityId < 0) {
			throw new UserNotAllowedExecption(Status.FORBIDDEN, operation, errorField,
					this.errorDescriptionsService.getTenantErrorDescriptions("master"), "en", "user");
		}

		//if user has permission of PACL|ADMIN can do anything
		if(sso2Client != null && sso2Client.isFunctionEnabled(env.getUser(), new UserFunction(CONTEXT_ID_PACL, ADMIN))) {
			return;
		}

		List<MandatorUserNTT> entityUsersNTT = mandatesDAO.getParentHierarchy(env.getTenantId(), entityId, env.getUser().getUserId(), 0, 0);

		if(entityUsersNTT.isEmpty() || entityUsersNTT.stream().allMatch(e -> e.getRole_code() == null)) {
			throw new UserNotAllowedExecption(Status.FORBIDDEN, operation, errorField,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), env.getUser().getUserId());
		}

		if(Boolean.TRUE.equals(canEdit) && entityUsersNTT.stream().noneMatch(e -> e.getRole_code().equals(ADMIN))) {
			throw new UserNotAllowedExecption(Status.FORBIDDEN, operation, errorField,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), env.getUser().getUserId());
		}
	}

	public Boolean checkAdminPermission(ServiceSupportEnv env, Operation operation) {

		if(env == null || env.getUser() == null || env.getUser().getUserId() == null) {
			throw new UserNotAllowedExecption(Status.FORBIDDEN, operation, ErrorField.USERID,
					this.errorDescriptionsService.getTenantErrorDescriptions("master"), "en", "user");
		}
		
		if(env.getUser().getUserId().equals("importFromBundle")) {
			return true;
		}

		//if user has permission of PACL|ADMIN
		return (sso2Client != null && sso2Client.isFunctionEnabled(env.getUser(), new UserFunction(CONTEXT_ID_PACL, ADMIN)));

	}

	public String getUserId(ServiceSupportEnv env, String username, Operation operation) {
		
		Response response = null;

		response = sso2ServerWT
				.path("/{tenant}/public/v1/users/{username}")
				.resolveTemplate("tenant", env.getTenantId())
				.resolveTemplate("username", username)
				
				.request(MediaType.APPLICATION_JSON_TYPE)
				.accept(MediaType.APPLICATION_JSON_TYPE)
				.header("accept-language", env.getLang())
				.header("Authorization", String.format("JWT %s", env.getUser().getAuthToken()))
				.get();

		UserData userData = null;

		if (response.getStatus() == 200) {
			response.bufferEntity();
			userData = response.readEntity(UserData.class);
		}

		if(userData == null) {
			throw new UserNotFoundExecption(Status.NOT_FOUND, operation, ErrorField.USERID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), username);
		}

		return userData.getUserId();
	}
}

