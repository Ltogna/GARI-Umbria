package com.abacogroup.partiesaclserver.core;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;

import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.bean.SummaryFieldDefinition;
import com.abacogroup.dynamicdocuments.bean.SummaryFieldValue;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.documents.DocumentNotFoundException;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.resources.res.DocumentRes;

import jakarta.ws.rs.core.Response.Status;

public class DocumentMapper {

	public static <T extends DocumentRes> T addSummaryFields(ServiceSupportEnv env, T documentRes,
			DocumentTypeService documentTypeService, DocumentService documentService, String dynamicDocumentsBucket) {
		Document document = documentService.getDocumentFromId(documentRes.getDocumentId());
		Optional<DocumentDefinition> def = documentTypeService
				.getDocumentDefinition(env.getTenantId(), documentRes.getDefinitionCode());

		List<SummaryFieldDefinition> summaryFields = null;
		if (def.isPresent()) {
			summaryFields = documentTypeService.getSummaryFields(def.get(), env.getLang());

			List<SummaryFieldValue> listValues = documentService.getSummaryValues(def.get(), document, env.getLang());
			LinkedHashMap<String, Object> summaryFieldsData = new LinkedHashMap<>();
			listValues.forEach(
					summaryFieldValue -> summaryFieldsData.put(summaryFieldValue.getCode(), summaryFieldValue.getValue())
			);
			documentRes.setSummaryFieldDefinitions(summaryFields);
			documentRes.setData(summaryFieldsData);
			documentRes.setBucketName(dynamicDocumentsBucket);
		}
		return documentRes;
	}

	public static <T extends DocumentRes> T addData(ServiceSupportEnv env, T documentRes, DocumentService documentService, 
			ErrorDescriptionsService errorDescriptionsService, String dynamicDocumentsBucket, Operation operation) {
		Document document = Optional.ofNullable(documentService.getDocumentFromId(documentRes.getDocumentId()))
				.orElseThrow(() -> new DocumentNotFoundException(Status.BAD_REQUEST, operation, ErrorField.DOCUMENT_ID,
						errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang()));
		documentRes.setData(new LinkedHashMap<>(document.getFields()));
		documentRes.setBucketName(dynamicDocumentsBucket);
		return documentRes;
	}
}