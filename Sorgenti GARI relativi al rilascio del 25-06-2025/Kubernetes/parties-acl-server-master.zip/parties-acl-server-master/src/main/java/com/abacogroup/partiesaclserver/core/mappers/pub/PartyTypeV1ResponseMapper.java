package com.abacogroup.partiesaclserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.resources.pub.res.PartyTypeV1;
import com.abacogroup.partiesaclserver.resources.res.PartyType;

@Mapper
public interface PartyTypeV1ResponseMapper {
	
	PartyTypeV1ResponseMapper INSTANCE = Mappers.getMapper(PartyTypeV1ResponseMapper.class);
	
	@InheritInverseConfiguration()
	PartyTypeV1 toResponseV1(PartyType entity);

}
