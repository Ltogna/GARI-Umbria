package com.abacogroup.partiesaclserver.db.dao;

import java.sql.DatabaseMetaData;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.core.mapper.reflect.BeanMapper;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.criteria.BindCriteria;
import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.ntt.EntityNTT;
import com.abacogroup.partiesaclserver.db.ntt.EntityTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyTypeNTT;

@RegisterBeanMapper(EntityNTT.class)
@RegisterBeanMapper(EntityTypeNTT.class)
@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface EntityDAO extends Transactional<EntityDAO>, EnhancedSqlObject {

	@SqlQuery("§select_nextval(pacl_entities_sequence)§")
	Long nextSequenceValEntityId();

	@SqlQuery("§select_nextval(pacl_entities_details_sequence)§")
	Long nextSequenceValEntityDetailsId();

	@SqlUpdate("INSERT INTO pacl_entities (id, tenant_id) "
			+ "VALUES(:id, :tenant_id)")
	void insertEntity(@Bind("id")Long id, @Bind("tenant_id")String tenantId);

	@SqlUpdate("INSERT INTO pacl_entities_details (pkid, day_from, day_to, entity_id, name, code, entity_type_id, registry_party_id, description, parent_id, path, user_id_insert, user_id_delete, dt_insert, dt_delete) "
			+ "VALUES(:pkid, :day_from, :day_to, :entity_id, :name, :code, :entity_type.id, :registry_party_id, :description, :parent_id, :path, :user_id_insert, NULL, "
			+ "§current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insertEntityDetails(@BindBean EntityNTT entityNTT, @Bind("user_id_insert")String userId);

	@SqlQuery("select \n"
			+ "   ped.pkid,\n"
			+ "   ped.entity_id,\n"
			+ "   ped.name,\n"
			+ "   ped.code,\n"
			+ "   ped.registry_party_id,\n"
			+ "   ped.description,\n"
			+ "   ped.parent_id,\n"
			+ "   (select name from pacl_entities_details where entity_id = coalesce(ped.parent_id, -1) and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as parent_name, \n"
			+ "   (select code from pacl_entities_details where entity_id = coalesce(ped.parent_id, -1) and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as parent_code, \n"
			+ "   ped.path,\n"
			+ "   ped.day_from,\n"
			+ "   ped.day_to, \n"
			+ "   pet.id as pet_id, \n"
			+ "   pet.code as pet_code, \n"
			+ "   pet.fl_entity_code_mandatory as pet_fl_entity_code_mandatory, \n"
			+ "   pet.fl_single_relation as pet_fl_single_relation, \n"
			+ "   pet.fl_hidden as pet_fl_hidden, \n"
			+ "   coalesce(§i18n(:tenantId, 'pacl_entity_types', 'code', pet.code, :lang)§ , pet.code) as pet_description,"
			+ "   peu.role_code as current_user_role, \n"
			+ "   case when (:isAdmin = 1 or peu.role_code = 'ADMIN') and ped.day_to >= :referenceDate then 1 else 0 end as editable, \n"
			+ "   case when ped.day_to >= :referenceDate then 0 else 1 end as closed \n"
			+ "from \n"
			+ "   pacl_entities pe\n"
			+ "   inner join pacl_entities_details ped on pe.id = ped.entity_id \n"
			+ "   inner join pacl_entity_types pet on pet.id = ped.entity_type_id \n"
			+ "   left join pacl_entities_users peu on peu.entity_id = pe.id and upper(peu.user_id) = upper(:mandatorUserId) and §current_timestamp§ between peu.dt_insert and peu.dt_delete \n"
			+ "where \n"
			+ "   pe.tenant_id = :tenantId \n"
			+ "   and (:isAdmin = 1 or upper(peu.user_id) = upper(:mandatorUserId)) \n"
			+ "   and pet.fl_single_relation = coalesce (:fl_single_relation, pet.fl_single_relation) \n"
			+ "   and pet.fl_hidden = coalesce (:fl_hidden, pet.fl_hidden) \n"
			+ "   and ped.entity_id = :id \n"
			+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ "")
	EntityNTT getEntityByID(@BindBean ServiceSupportEnv env, @Bind("id")Long id, @Bind("mandatorUserId") String mandatorUserId,
			@Bind("fl_single_relation")Integer flSingleRelation, @Bind("fl_hidden")Integer flHidden, @Bind("isAdmin")Integer isAdmin); 

	@SqlQuery("select \n"
			+ "   ped.pkid,\n"
			+ "   ped.entity_id,\n"
			+ "   ped.name,\n"
			+ "   ped.code,\n"
			+ "   ped.registry_party_id,\n"
			+ "   ped.description,\n"
			+ "   ped.parent_id,\n"
			+ "   (select name from pacl_entities_details where entity_id = coalesce(ped.parent_id, -1) and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as parent_name, \n"
			+ "   (select code from pacl_entities_details where entity_id = coalesce(ped.parent_id, -1) and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as parent_code, \n"
			+ "   ped.path,\n"
			+ "   ped.day_from,\n"
			+ "   ped.day_to, \n"
			+ "   pet.id as pet_id, \n"
			+ "   pet.code as pet_code, \n"
			+ "   pet.fl_entity_code_mandatory as pet_fl_entity_code_mandatory, \n"
			+ "   pet.fl_single_relation as pet_fl_single_relation, \n"
			+ "   pet.fl_hidden as pet_fl_hidden, \n"
			+ "   coalesce(§i18n(:tenantId, 'pacl_entity_types', 'code', pet.code, :lang)§ , pet.code) as pet_description,"
			+ "   peu.role_code as current_user_role, \n"
			+ "   case when (:isAdmin = 1 or peu.role_code = 'ADMIN') and ped.day_to >= :referenceDate then 1 else 0 end as editable, \n"
			+ "   case when ped.day_to >= :referenceDate then 0 else 1 end as closed \n"
			+ "from \n"
			+ "   pacl_entities pe\n"
			+ "   inner join pacl_entities_details ped on pe.id = ped.entity_id \n"
			+ "   inner join pacl_entity_types pet on pet.id = ped.entity_type_id \n"
			+ "   left join pacl_entities_users peu on peu.entity_id = pe.id and upper(peu.user_id) = upper(:mandatorUserId) and §current_timestamp§ between peu.dt_insert and peu.dt_delete \n"
			+ "where \n"
			+ "   pe.tenant_id = :tenantId \n"
			+ "   and (:isAdmin = 1 or upper(peu.user_id) = upper(:mandatorUserId)) \n"
			+ "   and pet.fl_single_relation = coalesce (:fl_single_relation, pet.fl_single_relation) \n"
			+ "   and pet.fl_hidden = coalesce (:fl_hidden, pet.fl_hidden) \n"
			+ "   and ped.code = :entityCode \n"
			+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ "")
	EntityNTT getEntityByCode(@BindBean ServiceSupportEnv env, @Bind("entityCode")String entityCode, @Bind("mandatorUserId") String mandatorUserId,
			@Bind("fl_single_relation")Integer flSingleRelation, @Bind("fl_hidden")Integer flHidden, @Bind("isAdmin")Integer isAdmin);

	@SqlQuery("Select \n"
			+ "   count(*) \n"
			+ "from \n"
			+ "   pacl_entities pe \n"
			+ "   inner join pacl_entities_details ped on pe.id = ped.entity_id \n"
			+ "where \n"
			+ "   pe.tenant_id = :tenant_id \n"
			+ "   and ped.parent_id = :id \n"
			+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ "")
	Long countChildrenById(@Bind("tenant_id")String tenant_id, @Bind("id")Long parentId);

	@SqlQuery("select t.*, \n"
			+ "       (select description from pacl_entities_details where entity_id = t.entity_id and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as description, \n"  // clob data are not searchable
			+ "       (select name from pacl_entities_details where entity_id = coalesce(parent_id, -1) and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as parent_name, \n"
			+ "       (select code from pacl_entities_details where entity_id = coalesce(parent_id, -1) and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as parent_code \n"  
			+ "  from ("
			+ "     select distinct ped.entity_id,\n"
			+ "        ped.name,\n"
			+ "        ped.code,\n"
			+ "        ped.registry_party_id,\n"
			+ "        ped.parent_id,\n"
			+ "        ped.path,\n"
			+ "        ped.day_from,\n"
			+ "        ped.day_to,\n"
			+ "        pet.id as pet_id, \n"
			+ "        pet.code as pet_code, \n"
			+ "        pet.fl_entity_code_mandatory as pet_fl_entity_code_mandatory, \n"
			+ "        pet.fl_single_relation as pet_fl_single_relation, \n"
			+ "        pet.fl_hidden as pet_fl_hidden, \n"
			+ "        coalesce(§i18n(:tenantId, 'pacl_entity_types', 'code', pet.code, :lang)§ , pet.code) as pet_description, \n"
			+ "        (Select peu.role_code from pacl_entities_users peu where upper(peu.user_id) = upper(:user.userId) and peu.entity_id = ped.entity_id and §current_timestamp§ between peu.dt_insert and peu.dt_delete) as current_user_role, \n"
			+ "        case when ped.day_to >= :referenceDate then 0 else 1 end as closed \n"
			+ "       from pacl_entities pe\n"
			+ "      inner join pacl_entities_details ped on pe.id = ped.entity_id \n"
			+ "      inner join pacl_entity_types pet on pet.id = ped.entity_type_id \n"
			+ "       left join pacl_entities_users peu on peu.entity_id = pe.id and §current_timestamp§ between peu.dt_insert and peu.dt_delete \n"
			+ "      where pe.tenant_id = :tenantId \n"
			+ "        and pet.fl_single_relation = 0 \n"
			+ "        and pet.fl_hidden = 0 \n"
			+ "        and ((:referenceDate <= ped.day_to) or :showOutdate = 1) \n"
			+ "        and (:isAdmin = 1 or upper(peu.user_id) = upper(:mandatorUserId)) \n"
			+ "        and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ "        and <criteria>"
			+ "      order by ped.code, pet.code asc \n"
			+ ") t") 
	ResultIterator<EntityNTT> getAllEntitiesInfinite(@BindBean ServiceSupportEnv env, @Bind("mandatorUserId") String mandatorUserId, @BindCriteria Criteria criteria,
			@Bind("showOutdate") Integer showOutdate, @Bind("isAdmin")Integer isAdmin);
	
	default List<Long> getAllAdminEntitiesIds(ServiceSupportEnv env, String mandatorUserId, Criteria criteria, Integer showOutdate, Integer isAdmin,
			Integer includeLevels){
		
		String dbType = withHandle(h -> h.queryMetadata(DatabaseMetaData::getDatabaseProductName));

		Boolean isPostgres = dbType.toLowerCase().contains("postgresql");
		
		String internalCriteria = Optional.ofNullable(criteria)
				.map(Criteria::toSqlFragment)
				.filter(StringUtils::isNotBlank)
				.map(sql -> " AND "+sql)
				.orElse("");
		
		String sql = "with user_entities as ("
				+ "        select distinct ped.entity_id\n"
				+ "          from pacl_entities pe\n"
				+ "         inner join pacl_entities_details ped on pe.id = ped.entity_id \n"
				+ "         inner join pacl_entity_types pet on pet.id = ped.entity_type_id \n"
				+ "          left join pacl_entities_users peu on peu.entity_id = pe.id and §current_timestamp§ between peu.dt_insert and peu.dt_delete \n"
				+ "         where pe.tenant_id = :tenantId \n"
				+ "           and pet.fl_single_relation = 0 \n"
				+ "           and pet.fl_hidden = 0 \n"
				+ "           and ((:referenceDate <= ped.day_to) or :showOutdate = 1) \n"
				+ "           and (:isAdmin = 1 or (upper(peu.user_id) = upper(:mandatorUserId) and upper(peu.role_code) = 'ADMIN')) \n"
				+ "           and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ internalCriteria
				+ ") \n"
				+ ""
				+ "select entity_id from("
				+ "with " + (Boolean.TRUE.equals(isPostgres) ? "recursive" : "") + " parentEntity (entity_id, parent_id, lvl) as ( \n"
				+ "           select \n"
				+ "               ped.entity_id, \n"
				+ "               ped.parent_id, \n"
				+ "               0 as lvl \n"
				+ "           from \n"
				+ "               pacl_entities pe \n"
				+ "               inner join pacl_entities_details ped on pe.id = ped.entity_id \n"
				+ "          where \n"
				+ "               ped.entity_id in (select entity_id from user_entities)\n"
				+ "               and pe.tenant_id = :tenantId \n"
				+ "               and ((:referenceDate <= ped.day_to) or :showOutdate = 1) \n"
				+ "               and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "       union all \n"
				+ "           select \n"
				+ "                ped.entity_id, \n"
				+ "                ped.parent_id, \n"
				+ "                ep.lvl + 1 \n"
				+ "           from \n"
				+ "                pacl_entities pe \n"
				+ "                inner join pacl_entities_details ped on pe.id = ped.entity_id \n"
				+ "                join parentEntity ep on ep.entity_id = ped.parent_id \n"
				+ "          where \n"
				+ "                pe.tenant_id = :tenantId \n"
				+ "                and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
				+ "                and ((:referenceDate <= ped.day_to) or :showOutdate = 1) \n"
				+ "   ) \n"
				+ "   select entity_id from parentEntity where lvl <= :includeLevels or :includeLevels = -1 \n"
				+ ") t"
				+ " \n";

			return withHandle(h -> 
			h.createQuery(sql)
			.bindBean(env)
			.bind("mandatorUserId", mandatorUserId) 
			.bind("showOutdate", showOutdate) 
			.bind("isAdmin", isAdmin)
			.bind("includeLevels", includeLevels)
			.mapTo(Long.class)
			.collect(Collectors.toList()));
	}
	
	@SqlUpdate("UPDATE \n"
			+ "   pacl_entities_details ped \n"
			+ "SET \n"
			+ "   dt_delete = §current_timestamp§, \n"
			+ "   user_id_delete = :user_id_delete \n"
			+ "where \n"
			+ "   ped.entity_id = :entityId \n"
			+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ "   and :entityId in ("
			+ "      select \n"
			+ "         pe.id \n"
			+ "      from \n"
			+ "         pacl_entities pe \n"
			+ "      where \n"
			+ "         pe.tenant_id = :tenantId)"
			+ "")
	void outdateEntityById(@Bind("tenantId")String tenantId, @Bind("user_id_delete") String userId, @Bind("entityId")Long entityId);

	@SqlQuery("select t.*, \n"
			+ "       (select description from pacl_entities_details where entity_id = t.entity_id and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as description, \n"
			+ "       (select name from pacl_entities_details where entity_id = coalesce(parent_id, -1) and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as parent_name, \n"
			+ "       (select code from pacl_entities_details where entity_id = coalesce(parent_id, -1) and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as parent_code \n"
			+ "  from ("
			+ "     select distinct ped.entity_id,\n"
			+ "            ped.name,\n"
			+ "            ped.code,\n"
			+ "            ped.registry_party_id,\n"
			+ "            ped.parent_id,\n"
			+ "            ped.path,\n"
			+ "            ped.day_from,\n"
			+ "            ped.day_to,\n"
			+ "            pet.id as pet_id, \n"
			+ "            pet.code as pet_code, \n"
			+ "            pet.fl_entity_code_mandatory as pet_fl_entity_code_mandatory, \n"
			+ "            pet.fl_single_relation as pet_fl_single_relation, \n"
			+ "            pet.fl_hidden as pet_fl_hidden, \n"
			+ "            coalesce(§i18n(:tenantId, 'pacl_entity_types', 'code', pet.code, :lang)§ , pet.code) as pet_description, \n"
			+ "            case when ped.day_to >= :referenceDate then 0 else 1 end as closed \n"
			+ "       from pacl_entities pe \n"
			+ "      inner join pacl_entities_details ped on pe.id = ped.entity_id \n"
			+ "      inner join pacl_entity_types pet on pet.id = ped.entity_type_id \n"
			+ "      where pe.tenant_id = :tenantId \n"
			+ "        and ped.parent_id = :id \n"
			+ "        and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ ") t")
	List<EntityNTT> getChild(@BindBean ServiceSupportEnv env, @Bind("id")Long parentId);


	@SqlQuery("select \n"
			+ "   ppt.id,\n"
			+ "   ppt.code,\n"
			+ "   ppt.fl_exclusive,\n"
			+ "   ppt.fl_manage \n"
			+ "from \n"
			+ "   pacl_entities_parties pep \n"
			+ "   inner join pacl_party_types ppt on ppt.id = pep.party_type_id \n"
			+ "where \n"
			+ "   pep.tenant_id = :tenantId \n"
			+ "   and pep.entity_id = :entityId \n"
			+ "   and §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
			+ "")
	@RegisterBeanMapper(PartyTypeNTT.class)
	List<PartyTypeNTT> getPartyTypesByEntityId(@Bind("tenantId")String tenantId, @Bind("entityId")Long entityId);

	@SqlQuery("Select \n"
			+ "   count(distinct ped.entity_id) \n"
			+ "from \n"
			+ "   pacl_entities pe \n"
			+ "   inner join pacl_entities_details ped on pe.id = ped.entity_id \n"
			+ "where \n"
			+ "   pe.tenant_id = :tenantId "
			+ "   and ped.registry_party_id = :registryPartyId \n"
			+ "   and ((:dayFrom between ped.day_from and ped.day_to) \n"
			+ "        or (:dayTo between ped.day_from and ped.day_to) \n"
			+ "        or (:dayFrom <= ped.day_from and :dayTo >= ped.day_to)) \n"
			+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ "")
	Integer checkEntityByRegistryPartyId(@BindBean ServiceSupportEnv env, @Bind("registryPartyId")String registryPartyId,
			@Bind("dayFrom") AbsoluteDate dayFrom, @Bind("dayTo") AbsoluteDate dayTo);

	@SqlQuery("Select \n"
			+ "   count(distinct ped.entity_id) \n"
			+ "from \n"
			+ "   pacl_entities pe \n"
			+ "   inner join pacl_entities_details ped on pe.id = ped.entity_id \n"
			+ "where \n"
			+ "   pe.tenant_id = :tenantId "
			+ "   and ped.code = :code \n"
			+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ "")
	Integer checkEntityByEntityCode(@Bind("tenantId")String tenantId, @Bind("code")String EntityCode);

	default ResultIterator<EntityNTT> getAllChildbyParentId(ServiceSupportEnv env, Long parentId, Integer includeLevels){
		String dbType = withHandle(h -> h.queryMetadata(DatabaseMetaData::getDatabaseProductName));

		Boolean isPostgres = dbType.toLowerCase().contains("postgresql");

		String sql = 
				"select t.*, \n"
						+ "       (select description from pacl_entities_details where pkid = t.pkid) as description, \n"
						+ "       (select name from pacl_entities_details where entity_id = coalesce(parent_id, -1) and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as parent_name, \n"
						+ "       (select code from pacl_entities_details where entity_id = coalesce(parent_id, -1) and §current_timestamp§ between dt_insert and dt_delete order by dt_insert desc fetch first row only) as parent_code \n"
						+ "  from ("
						+ "select distinct ped.pkid, \n"
						+ "   ped.entity_id, \n"
						+ "   ped.name, \n"
						+ "   ped.code, \n"
						+ "   ped.registry_party_id, \n" 
						+ "   ped.parent_id, \n"
						+ "   ped.path, \n"
						+ "   ped.day_from, \n"
						+ "   ped.day_to, \n"
						+ "   pet.id as pet_id, \n"
						+ "   pet.code as pet_code, \n"
						+ "   pet.fl_entity_code_mandatory as pet_fl_entity_code_mandatory, \n"
						+ "   pet.fl_single_relation as pet_fl_single_relation, \n"
						+ "   pet.fl_hidden as pet_fl_hidden, \n"
						+ "   coalesce(§i18n(:tenantId, 'pacl_entity_types', 'code', pet.code, :lang)§ , pet.code) as pet_description, \n"
						+ "   (Select \n"
						+ "      peu.role_code \n"
						+ "   from \n"
						+ "      pacl_entities_users peu \n"
						+ "   where \n"
						+ "      peu.entity_id = ped.entity_id \n"
						+ "      and upper(peu.user_id) = upper(:user.userId)"
						+ "      and §current_timestamp§ between peu.dt_insert and peu.dt_delete"
						+ "   ) as current_user_role, \n"
						+ "   case when ped.day_to >= :referenceDate then 0 else 1 end as closed \n"
						+ "  from pacl_entities pe \n"
						+ " inner join pacl_entities_details ped on pe.id = ped.entity_id \n"
						+ " inner join pacl_entity_types pet on pet.id = ped.entity_type_id \n"
						+ " inner join ( \n"
						+ "      with " + (Boolean.TRUE.equals(isPostgres) ? "recursive" : "") + " parentEntity (entity_id, parent_id, lvl) as ( \n"
						+ "         select ped.entity_id, \n"
						+ "                ped.parent_id, \n"
						+ "                1 as lvl"
						+ "           from pacl_entities pe \n"
						+ "          inner join pacl_entities_details ped on pe.id = ped.entity_id \n"
						+ "          where ped.parent_id = :parentId \n"
						+ "             and pe.tenant_id = :tenantId \n"
						+ "             and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
						+ "             "
						+ "       union all \n"
						+ "         select ped.entity_id, \n"
						+ "                ped.parent_id, \n"
						+ "                ep.lvl + 1"
						+ "           from pacl_entities pe \n"
						+ "          inner join pacl_entities_details ped on pe.id = ped.entity_id \n"
						+ "           join parentEntity ep on ep.entity_id = ped.parent_id \n"
						+ "          where pe.tenant_id = :tenantId \n"
						+ "            and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
						+ "   ) \n"
						+ "   select distinct entity_id from parentEntity where lvl <= :includeLevels or :includeLevels = -1 \n"
						+ ") ep on ep.entity_id = ped.entity_id \n"
						+ " where pe.tenant_id = :tenantId \n"
						+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
						+ "order by ped.pkid desc"
						+ ") t";

		return withHandle(h -> 
		h.createQuery(sql)
		.bindBean(env)
		.bind("parentId", parentId)
		.bind("includeLevels", includeLevels)
		.registerRowMapper(BeanMapper.factory(EntityNTT.class))
		.mapTo(EntityNTT.class)
		.iterator());
	}

}
