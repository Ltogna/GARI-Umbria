package com.abacogroup.partiesaclserver.resources.pub;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partiesaclserver.core.pub.TypesV1Service;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.resources.ResourceConstants;
import com.abacogroup.partiesaclserver.resources.pub.res.EntityTypeV1;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path(ResourceConstants.API_PUB)
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = "public", description = "Public resources")
public class PublicTypesResources {

	private TypesV1Service typesService;

	public PublicTypesResources(TypesV1Service typesService) {
		this.typesService = typesService;
	}
	
	@GET
	@Path("/entities/types")
	@Operation(description = "Get all Entity types", tags = { "public" })
	@ApiResponse(responseCode = "200", description = "Get all Entity types", useReturnTypeSchema = true)
	public InfiniteListResults<EntityTypeV1> getAllEntityTypes(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Entity type code") @QueryParam("code") String code,
			@Parameter(description = "Reference date") @QueryParam("referenceDate") AbsoluteDate referenceDate,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("next_key") String nextKey) {

		ServiceSupportEnv env = ServiceSupportEnv
				.builder()
				.user(user)
				.lang(lang)
				.tenantId(tenantId)
				.referenceDate(referenceDate)
				.build();

		return typesService.getAllEntityTypes(env, code, nextKey);
	}
	
}