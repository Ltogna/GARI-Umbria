package com.abacogroup.partiesaclserver.db.ntt;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ConfigNTT {
	private String tenantId;
	private String key;
	private String value;
	private Integer fl_client;
	private String name;
}
