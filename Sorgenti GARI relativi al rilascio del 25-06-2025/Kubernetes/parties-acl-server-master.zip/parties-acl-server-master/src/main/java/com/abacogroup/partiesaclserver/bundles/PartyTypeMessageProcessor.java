package com.abacogroup.partiesaclserver.bundles;

import java.io.File;
import java.nio.file.Path;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.partiesaclserver.bundles.models.PartyType;
import com.abacogroup.partiesaclserver.bundles.models.PartyTypeCodeList;
import com.abacogroup.partiesaclserver.bundles.models.PartyTypeList;
import com.abacogroup.partiesaclserver.core.exceptions.bundles.BundleEntityTypeException;
import com.abacogroup.partiesaclserver.core.exceptions.bundles.BundlePartyTypeException;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.I18nDAO;
import com.abacogroup.partiesaclserver.db.dao.TypesDAO;
import com.abacogroup.partiesaclserver.db.ntt.EntityTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.I18nNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyTypeNTT;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PartyTypeMessageProcessor implements ConfigMessageProcessor {

	private final ObjectMapper objectMapper;

	private TypesDAO typesDAO;
	private I18nDAO i18nDAO;

	public PartyTypeMessageProcessor(DAOContainer dc) {
		this.typesDAO = dc.getTypesDAO();
		this.i18nDAO = dc.getI18nDAO();
		objectMapper = new ObjectMapper();
	}

	@Override
	public String getDomainName() {
		return "party-type";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> deleteMessage(message.getTenantId(), file));

		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
				&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> insertOrUpdateMessage(message.getTenantId(), file));
	}

	private void insertOrUpdateMessage(String tenantId, File file) {
		try {
			PartyTypeList partyTypeList = objectMapper.readValue(file, PartyTypeList.class);

			if (partyTypeList == null || partyTypeList.getParty_type_list() == null || partyTypeList.getParty_type_list().isEmpty()) {
				return;
			}

			partyTypeList.getParty_type_list().stream().forEach(message -> {

				ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).build();

				PartyTypeNTT type = typesDAO.getPartyTypeByCode(env, message.getCode());

				try {
					if(type == null) {
						insertPartyType(env, message);
					} else {
						updatePartyType(env, type, message);
					}

				} catch (Exception e) {
					throw new BundlePartyTypeException("Error during insert or update entity type message " + message.toString() + " for tenant " + tenantId);
				}

				if(message.getTranslations() != null) {
					message.getTranslations().forEach((lang, text) -> {
						I18nNTT messageNTT = I18nNTT.builder()
								.field_name("code")
								.i18n_text(text)
								.i18n_value(message.getCode())
								.lang(lang)
								.table_name("pacl_party_types")
								.tenant_id(tenantId)
								.build();

						I18nNTT toFind = i18nDAO.findI18nByPaclI18nKeys(messageNTT);

						if (toFind == null) {
							i18nDAO.insert(messageNTT);
						} else if (!toFind.getI18n_text().equals(text)) {
							i18nDAO.updateI18nText(messageNTT);
						}
					});
				}
				log.info("Party type with code '{}' is valid for tenant '{}'. ", message.getCode(), tenantId);
			});
		} catch (Exception e) {
			throw new BundlePartyTypeException("Error processing file " + file.getName() + " for tenant " + tenantId + ".\n" + e.getMessage());
		}
	}

	private void insertPartyType (ServiceSupportEnv env, PartyType message) {
		PartyTypeNTT partyTypeNTT = PartyTypeNTT.builder()
				.id(typesDAO.nextSequenceValPartyTypes())
				.code(message.getCode())
				.fl_exclusive(booleanToInteger(message.getFl_exclusive()))
				.fl_manage(booleanToInteger(message.getFl_manage()))
				.build();

		typesDAO.insertPartyType(env.getTenantId(), partyTypeNTT);

		message.getEntity_type_codes().stream().distinct().forEach(code -> {
			EntityTypeNTT entityTypeNTT = typesDAO.getEntityTypeByCode(env, code);
			if(entityTypeNTT == null) {
				throw new BundleEntityTypeException("Entity type with code '" + code + "' does not exists for tenant '" + env.getTenantId() + "'.\n");
			}
			typesDAO.insertEntityPartyTypeLink(partyTypeNTT.getId(), entityTypeNTT.getId());
		});
	}

	private void updatePartyType (ServiceSupportEnv env, PartyTypeNTT oldType, PartyType message) {
		Integer fl_exclusive = message.getFl_exclusive() != null ? booleanToInteger(message.getFl_exclusive()) : oldType.getFl_exclusive();
		Integer fl_manage = message.getFl_manage() != null ? booleanToInteger(message.getFl_manage()) : oldType.getFl_manage();

		typesDAO.updatePartyType(env.getTenantId(), oldType.getId(), fl_exclusive, fl_manage);		

		//update entity-party type links
		if(message.getEntity_type_codes() != null) {
			typesDAO.removeLinksWithPartyId(env.getTenantId(), oldType.getId());
			message.getEntity_type_codes().stream().distinct().forEach(code -> {
				EntityTypeNTT entityTypeNTT = typesDAO.getEntityTypeByCode(env, code);
				if(entityTypeNTT == null) {
					throw new BundlePartyTypeException("Entity type with code'" + code + " does not exists for tenant '" + env.getTenantId() + "'.\n");
				}
				typesDAO.insertEntityPartyTypeLink(oldType.getId(), entityTypeNTT.getId());
			});
		}
	}

	private void deleteMessage(String tenantId, File file) {
		try {
			PartyTypeCodeList partyTypeCodeList = objectMapper.readValue(file, PartyTypeCodeList.class);

			if (partyTypeCodeList == null || partyTypeCodeList.getParty_type_code_list() == null || partyTypeCodeList.getParty_type_code_list().isEmpty()) {
				return;
			}

			partyTypeCodeList.getParty_type_code_list().stream().forEach(code -> {

				ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).build();

				PartyTypeNTT type = typesDAO.getPartyTypeByCode(env, code);
				if(type == null) {
					throw new BundleEntityTypeException("Party type with code '" + code + "' does not exists for tenant '" + tenantId + "'.\n");
				}

				Integer count = typesDAO.countPartiesByType(tenantId, type.getId());
				if(count != 0) {
					throw new BundleEntityTypeException("Parties exists with party type with code '" + code + "' for tenant '" + tenantId + "'.\n");
				}

				I18nNTT row = I18nNTT.builder()
						.tenant_id(tenantId)
						.table_name("pacl_party_types")
						.field_name("code")
						.i18n_value(code)
						.build();

				typesDAO.deletePartyType(tenantId, type.getId());
				i18nDAO.deleteAllI18n(row);
				log.info("Party type with code '{}' deleted for tenant '{}'. ", code, tenantId);
			});

		} catch (Exception e) {
			throw new BundleEntityTypeException("Error processing file " + file.getName() + " for tenant " + tenantId + ".\n" + e.getMessage());
		}
	}

	private Integer booleanToInteger(Boolean x) {
		return Boolean.TRUE.equals(x) ? 1 : 0;
	}
}
