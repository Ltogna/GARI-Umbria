package com.abacogroup.partiesaclserver.resources.res;

import java.util.List;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class PathDetails {	
	@Schema(description = "Entity's tree path", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String path;
	
	@ArraySchema(schema = @Schema(description = " ", implementation = PathUser.class, requiredMode = RequiredMode.REQUIRED))
	@NotNull
	@Valid
	private List<PathUser> mandatorUsersList;
	
	@ArraySchema(schema = @Schema(description = " ", implementation = PathParty.class, requiredMode = RequiredMode.REQUIRED))
	@NotNull
	@Valid
	private List<PathParty> PartiesList;
}
