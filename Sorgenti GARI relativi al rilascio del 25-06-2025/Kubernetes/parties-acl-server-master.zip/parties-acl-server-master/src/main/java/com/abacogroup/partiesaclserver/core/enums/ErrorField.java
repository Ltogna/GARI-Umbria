package com.abacogroup.partiesaclserver.core.enums;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Client error field")
public enum ErrorField {
	ENTITY,
	MANDATE,
	TYPE, 
	TYPE_ID, 
	REVISION,
	PARTY_REGISTRY,
	ANOMALIES,
	SECURITY,
	ENV,
	CONFIG, 
	ID,
	USERID,
	PARTY_ID_LIST,
	VALIDATION_DATES,
	DOCUMENT_DEFINITION, 
	DOCUMENT, 
	DOCUMENT_CODE, 
	DOCUMENT_ID, 
	FILE_ID; 
}