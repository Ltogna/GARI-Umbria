package com.abacogroup.partiesaclserver.db.dao;

import java.util.List;

import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.partiesaclserver.db.ntt.PathPartyNTT;
import com.abacogroup.partiesaclserver.db.ntt.PathUserNTT;
import com.abacogroup.partiesaclserver.db.ntt.RevisionHistoryNTT;
import com.abacogroup.partiesaclserver.resources.res.PathDetails;

@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateMapper.class)
public interface RevisionHistoryDAO extends Transactional<RevisionHistoryDAO>, EnhancedSqlObject {

	@SqlQuery("§select_nextval(pacl_revision_history_sequence)§")
	Long nextSequenceVal();

	@SqlUpdate("INSERT INTO pacl_revision_history (pkid, tenant_id, operation, object_id, old_path, new_path, object_data, revision_date) "
			+ "VALUES(:pkid, :tenant_id, :operation, :object_id, :old_path, :new_path, :object_data, :revision_date)")
	void insertOperation(@BindBean RevisionHistoryNTT history);

	@SqlQuery("select h.pkid, \n"
			+ "       h.tenant_id, \n"
			+ "       h.operation, \n"
			+ "       h.object_id, \n"
			+ "       h.old_path, \n"
			+ "       h.new_path, \n"
			+ "       cast(h.object_data as varchar(4000)) as object_data, \n"
			+ "       h.revision_date \n"
			+ "  from pacl_revision_history h \n"
			+ " where h.tenant_id = :tenantId \n"
			+ "   and h.pkid > :fromId \n"
			+ " order by h.pkid asc \n"
			+ "")
	@RegisterBeanMapper(RevisionHistoryNTT.class)
	ResultIterator<RevisionHistoryNTT> getFromId(@Bind("tenantId")String tenantId, @Bind("fromId")Long fromId);

	@SqlQuery("select h.pkid, \n"
			+ "       h.tenant_id, \n"
			+ "       h.operation, \n"
			+ "       h.object_id, \n"
			+ "       h.old_path, \n"
			+ "       h.new_path, \n"
			+ "       cast(h.object_data as varchar(4000)) as object_data, \n"
			+ "       h.revision_date \n"
			+ "  from pacl_revision_history h \n"
			+ " where h.tenant_id = :tenantId \n"
			+ "   and h.pkid = :id \n"
			+ "")	
	@RegisterBeanMapper(RevisionHistoryNTT.class)
	RevisionHistoryNTT getById(@Bind("tenantId")String tenantId, @Bind("id")Long id);
	
	@SqlQuery("select max(h.pkid) \n"
			+ "  from pacl_revision_history h  \n"
			+ " where h.tenant_id = :tenantId  \n"
			+ "")	
	@RegisterBeanMapper(RevisionHistoryNTT.class)
	Long getLastId(@Bind("tenantId")String tenantId);

	
	@SqlQuery("select distinct ped.path \n"
			+ "  from pacl_entities pe  \n"
			+ " inner join pacl_entities_details ped on pe.id = ped.entity_id  \n"
			+ " where pe.tenant_id = :tenantId \n"
			+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ " order by ped.path \n"
			+ "")
	@RegisterBeanMapper(PathDetails.class)
	ResultIterator<PathDetails> getAllPath(@Bind("tenantId")String tenantId);
	
	@SqlQuery("select distinct peu.user_id as id, \n"
			+ "       peu.role_code as role  \n"
			+ "  from pacl_entities pe \n"
			+ " inner join pacl_entities_details ped on pe.id = ped.entity_id  \n"
			+ " inner join pacl_entities_users peu on peu.entity_id = ped.entity_id  \n"
			+ " where pe.tenant_id = :tenantId  \n"
			+ "   and ped.path = :path  \n"
			+ "   and §current_timestamp§ between peu.dt_insert and peu.dt_delete \n"
			+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ " order by peu.user_id \n"
			+ "")
	@RegisterBeanMapper(PathUserNTT.class)
	List<PathUserNTT> getUsersByPath(@Bind("tenantId")String tenantId, @Bind("path")String path);

	@SqlQuery("select distinct pep.party_id as party_id, \n"
			+ "       pep.mandate_id as mandate_id, \n"
			+ "       pep.party_type_id, \n"
			+ "       pep.day_from, \n"
			+ "       pep.day_to, \n"
			+ "       ppt.id,\n"
			+ "       ppt.code,\n"
			+ "       ppt.fl_exclusive,\n"
			+ "       ppt.fl_manage \n"
			+ "  from pacl_entities pe \n"
			+ " inner join pacl_entities_details ped on pe.id = ped.entity_id  \n"
			+ " inner join pacl_entities_parties pep on pep.entity_id = ped.entity_id  \n"
			+ " inner join pacl_party_types ppt on ppt.id = pep.party_type_id  \n"
			+ " where pe.tenant_id = :tenantId  \n"
			+ "   and ped.path = :path  \n"
			+ "   and pep.status = 'VALID' \n"
			+ "   and §current_timestamp§ between pep.dt_insert and pep.dt_delete \n"
			+ "   and §current_timestamp§ between ped.dt_insert and ped.dt_delete \n"
			+ " order by pep.party_id, pep.day_from, pep.day_to \n"
			+ "")
	@RegisterBeanMapper(PathPartyNTT.class)
	List<PathPartyNTT> getPartiesByPath(@Bind("tenantId")String tenantId, @Bind("path")String path);
	
	@SqlQuery("select distinct tenant_id from pacl_entities where tenant_id <> '*'")
	List<String> findTenants();

}
