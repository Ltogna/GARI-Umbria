package com.abacogroup.partiesaclserver.core.exceptions;

import java.util.Map;

import jakarta.ws.rs.core.Response.Status;

import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class InvalidRequestException extends AbstractException {

	private static final long serialVersionUID = 6109087759320531383L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_REQUEST;

	public InvalidRequestException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new InvalidPayloadExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
		
		log.error(this.getBody().getLogErrorMessage());
	}

	@Schema(description = "Invalid request")
	public static class InvalidPayloadExceptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = -23079654148980005L;

		public InvalidPayloadExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
