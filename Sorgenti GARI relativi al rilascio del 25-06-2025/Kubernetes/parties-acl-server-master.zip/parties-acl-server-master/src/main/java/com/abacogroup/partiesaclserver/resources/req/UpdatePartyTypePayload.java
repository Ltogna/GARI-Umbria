package com.abacogroup.partiesaclserver.resources.req;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class UpdatePartyTypePayload {
	@Schema(description = "1: if party is exclusive", type = "boolean")
	private Boolean fl_exclusive;
	
	@Schema(description = "1: if party can be managed", type = "boolean")
	private Boolean fl_manage;
	
	@ArraySchema(schema = @Schema(description = "List of entity type code to link with party type", implementation = String.class))
	@Valid
	private List<String> entityTypeCodes;
	
	@ArraySchema(schema = @Schema(description = "translations"))
	@Valid
	private Map<String, String> translations;
	
	public Boolean isEmtpy() {
		return this.fl_exclusive == null && this.fl_manage == null && (this.entityTypeCodes == null || this.entityTypeCodes.isEmpty())
				&& (this.translations == null || this.translations.isEmpty());
	}
}
