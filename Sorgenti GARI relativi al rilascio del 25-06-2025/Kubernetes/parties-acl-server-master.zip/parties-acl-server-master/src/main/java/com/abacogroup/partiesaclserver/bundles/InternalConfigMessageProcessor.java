package com.abacogroup.partiesaclserver.bundles;

import java.io.File;
import java.nio.file.Path;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.partiesaclserver.bundles.models.InternalConfigListMessage;
import com.abacogroup.partiesaclserver.core.exceptions.bundles.BundleInternalConfigException;
import com.abacogroup.partiesaclserver.db.dao.ConfigDAO;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.ntt.ConfigNTT;
import com.fasterxml.jackson.databind.ObjectMapper;


public class InternalConfigMessageProcessor implements ConfigMessageProcessor {

	private final ObjectMapper objectMapper;

	private ConfigDAO configDAO;

	private static final Logger log = LoggerFactory.getLogger(InternalConfigMessageProcessor.class);

	public InternalConfigMessageProcessor(DAOContainer dc) {
		this.configDAO = dc.getConfigDAO();
		objectMapper = new ObjectMapper();
	}

	@Override
	public String getDomainName() {
		return "internal-config";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> deleteInternalConfigMessage(message.getTenantId(), file));

		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
				&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> insertOrUpdateInternalConfigMessage(message.getTenantId(), file));
	}

	private void insertOrUpdateInternalConfigMessage(String tenantId, File file) {
		try {
			InternalConfigListMessage internalConfigListMessage = objectMapper.readValue(file, InternalConfigListMessage.class);

			if (internalConfigListMessage == null || internalConfigListMessage.getInternalConfig() == null 
					|| internalConfigListMessage.getInternalConfig().isEmpty()) {
				return;
			}

			internalConfigListMessage.getInternalConfig().stream().forEach(message -> {
				try {
					ConfigNTT savedConfig = configDAO.getConfigByTenantAndKey(tenantId, message.getKey());

					Integer configFlClient = message.getFl_client() != null && message.getFl_client() ? 1 : 0;

					ConfigNTT configToInsertOrUpdate = ConfigNTT.builder()
							.tenantId(tenantId)
							.key(message.getKey())
							.value(String.valueOf(message.getValue()))
							.fl_client(configFlClient)
							.name(message.getName())
							.build();

					if (savedConfig == null) {
						configDAO.insert(configToInsertOrUpdate);
						log.info("Internal config with key '{}' added for tenant '{}'. ", message.getKey(), tenantId);
					} else if (!savedConfig.equals(configToInsertOrUpdate)) {
						configDAO.updateValue(configToInsertOrUpdate);
						log.info("Internal config with key '{}' updated for tenant '{}'. ", message.getKey(), tenantId);
					}
				} catch (Exception e) {
					throw new BundleInternalConfigException("Error during insert or update of internal config with key '" + message.getKey() + "'.\n" + e.getMessage());
				}
			});
		} catch (Exception e) {
			throw new BundleInternalConfigException("Error processing file " + file.getName() + " for tenant " + tenantId + ".\n" + e.getMessage());
		}
	}

	private void deleteInternalConfigMessage(String tenantId, File file) {
		try {
			InternalConfigListMessage internalConfigListMessage = objectMapper.readValue(file, InternalConfigListMessage.class);

			if (internalConfigListMessage == null || internalConfigListMessage.getInternalConfig() == null || internalConfigListMessage.getInternalConfig().isEmpty()) {
				return;
			}

			internalConfigListMessage.getInternalConfig().stream().forEach(message -> {
				try {
					configDAO.deleteByTenantAndKey(tenantId, message.getKey());
					log.info("Internal config with key '{}' deleted for tenant '{}'. ", message.getKey(), tenantId);
				} catch (Exception e) {
					throw new BundleInternalConfigException("Error during delete internal config with key '" + message.getKey() + "'.\n" + e.getMessage());
				}});

		} catch (Exception e) {
			throw new BundleInternalConfigException("Error processing file " + file.getName() + " for tenant " + tenantId + ".\n" + e.getMessage());
		}
	}
}
