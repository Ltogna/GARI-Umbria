package com.abacogroup.partiesaclserver.core;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidPayloadException;
import com.abacogroup.partiesaclserver.core.exceptions.type.EntitiesWithTypeExecption;
import com.abacogroup.partiesaclserver.core.exceptions.type.PartiesWithTypeExecption;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeAlreadyExistExecption;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeNotFoundExecption;
import com.abacogroup.partiesaclserver.core.mappers.EntityTypeMapper;
import com.abacogroup.partiesaclserver.core.mappers.PartyTypeMapper;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.I18nDAO;
import com.abacogroup.partiesaclserver.db.dao.TypesDAO;
import com.abacogroup.partiesaclserver.db.ntt.EntityTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.I18nNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyTypeNTT;
import com.abacogroup.partiesaclserver.resources.req.AddEntityTypePayload;
import com.abacogroup.partiesaclserver.resources.req.AddPartyTypePayload;
import com.abacogroup.partiesaclserver.resources.req.UpdatePartyTypePayload;
import com.abacogroup.partiesaclserver.resources.res.EntityType;
import com.abacogroup.partiesaclserver.resources.res.PartyType;

import jakarta.ws.rs.core.Response.Status;

/**
 * TypesService is responsible for managing entity and party types.
 * It uses an instance of TypesDAO, which is used to interact with the database 
 * to perform CRUD operations on the different types of entities and parties,
 *  an instance of I18nDAO, which is used to interact with the database to perform 
 *  CRUD operations on the translations of the different types of entities and 
 *  an instance of ErrorDescriptionsService, which is used to fetch the error descriptions for different error scenarios.
 */
public class TypesService {

	private ErrorDescriptionsService errorDescriptionsService;
	private UtilityService utilityService;
	private TypesDAO typesDAO;
	private I18nDAO i18nDAO;
	
	private static final String ENTITY_TYPE_TABLE_NAME = "pacl_entity_types";
	private static final String PARTY_TYPE_TABLE_NAME = "pacl_party_types";
	private static final String ENTITY_TYPE_FIELD_CODE = "code";
	private static final String PARTY_TYPE_FIELD_CODE = "code";
	
	private static final int DEFAULT_PAGE_SIZE = 10;

	/**
	 * Creates a new TypesService instance with the specified DAO container and error descriptions service.
	 *
	 * @param daoContainer the DAO container to use for accessing the database
	 * @param errorDescriptionsService the error descriptions service to use for retrieving error descriptions
	 */
	public TypesService(DAOContainer daoContainer, UtilityService utilityService, ErrorDescriptionsService errorDescriptionsService) {
		this.errorDescriptionsService = errorDescriptionsService;
		this.utilityService = utilityService;
		this.typesDAO = daoContainer.getTypesDAO();
		this.i18nDAO = daoContainer.getI18nDAO();
	}

	/**
	 * Adds an entity type al§§§§ong with its translations to the database. 
	 * If a type with the same code already exists, it throws a TypeAlreadyExistExecption.
	 *
	 * @param env 
	 * @param payload the payload containing the information for the new entity type
	 * @return true if the entity type was added successfully, false otherwise
	 * @throws TypeAlreadyExistExecption if the entity type already exists
	 * @throws InvalidPayloadException if the payload is invalid
	 */
	public Boolean addEntityTypes(ServiceSupportEnv e, AddEntityTypePayload payload) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		EntityTypeNTT type = typesDAO.getEntityTypeByCode(env, payload.getCode());

		if(type != null) {
			throw new TypeAlreadyExistExecption(Status.CONFLICT, Operation.ADD_ENTITY_TYPE, ErrorField.TYPE, 
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), 
					utilityService.getFormatedErrorMsg(type.getCode(), type.getDescription()));
		}

		typesDAO.useTransaction(dao -> {				
			EntityTypeNTT entityTypeNTT = EntityTypeNTT.builder()
					.code(payload.getCode())
					.fl_entity_code_mandatory(Boolean.TRUE.equals(payload.getFlEntityCodeMandatory()) ? 1 : 0)
					.fl_hidden(Boolean.TRUE.equals(payload.getFlHidden()) ? 1 : 0)
					.fl_single_relation(Boolean.TRUE.equals(payload.getFlSingleRelation()) ? 1 : 0)
					.id(typesDAO.nextSequenceValEntityTypes())
					.build();

			typesDAO.insertEntityType(env.getTenantId(), entityTypeNTT);

			payload.getTranslations().forEach((lang, text) -> {
				I18nNTT row = I18nNTT.builder()
						.table_name(ENTITY_TYPE_TABLE_NAME)
						.field_name(ENTITY_TYPE_FIELD_CODE)
						.i18n_text(text)
						.i18n_value(payload.getCode())
						.lang(lang)
						.tenant_id(env.getTenantId())
						.build();

				I18nNTT toFind = i18nDAO.findI18nByPaclI18nKeys(row);

				if (toFind == null) {
					i18nDAO.insert(row);
				} else if (!toFind.getI18n_text().equals(text)) {
					i18nDAO.updateI18nText(row);
				}
			});
		});

		return true;
	}

	/**
	 * Deletes an entity type along with its translations from the database. If the type does not exist or is associated with 
	 * some entities, it throws a TypeNotFoundExecption or EntitiesWithTypeExecption respectively.
	 *
	 * @param env the service support environment
	 * @param id the ID of the entity type to delete
	 * @return true if the entity type was deleted successfully, false otherwise
	 * @throws TypeNotFoundExecption if the entity type was not found
	 * @throws EntitiesWithTypeExecption if there are entities associated with the specified entity type
	 */
	public Boolean deleteEntitytype(ServiceSupportEnv e, Long id) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		EntityTypeNTT type = typesDAO.getEntityTypeById(env, id);
		if(type == null) {
			throw new TypeNotFoundExecption(Status.NOT_FOUND, Operation.REMOVE_ENTITY_TYPE, ErrorField.TYPE, 
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), id.toString());
		}

		Long count = typesDAO.countEntitiesByType(env.getTenantId(), id);
		if(count != 0) {
			throw new EntitiesWithTypeExecption(Status.BAD_REQUEST, Operation.REMOVE_ENTITY_TYPE, ErrorField.TYPE, 
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}


		I18nNTT row = I18nNTT.builder()
				.tenant_id(env.getTenantId())
				.table_name(ENTITY_TYPE_TABLE_NAME)
				.field_name(ENTITY_TYPE_FIELD_CODE)
				.i18n_value(type.getCode())
				.build();

		typesDAO.deleteEntityType(env.getTenantId(), id);
		i18nDAO.deleteAllI18n(row);

		return true;
	}

	/**
	 * Gets a list of all entity types, filtered by code, if specified.
	 * returns a paginated list of entity types.
	 *
	 * @param env 
	 * @param id the ID of the entity type to get (optional)
	 * @param code the code of the entity type to get (optional)
	 * @return the entity type list
	 */
	public InfiniteListResults<EntityType> getAllEntityTypes(ServiceSupportEnv e, String code, Boolean partyTypesList, String nextKey) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		InfiniteListResults<EntityType> list = this.typesDAO.infinite(() -> typesDAO.getAllEntityType(env, code),
				nextKey, 
				DEFAULT_PAGE_SIZE)
				.map(EntityTypeMapper.INSTANCE::entityTODto);

		if(Boolean.TRUE.equals(partyTypesList)) {
			list.getRecords().parallelStream().forEach(rec -> {
				List<PartyType> partyTypes = typesDAO.getPartyTypeWithEntityType(env, rec.getId())
						.stream()
						.map(PartyTypeMapper.INSTANCE::entityTODto)
						.collect(Collectors.toList());

				rec.setPartyTypesList(partyTypes != null ? partyTypes : new ArrayList<>());
			});
		}

		return list;
	}

	/**
	 * Retrieves the entity type with the specified ID.
	 *
	 * @param env            
	 * @param entityTypeId   The ID of the entity type to retrieve.
	 * @param partyTypesList Flag indicating whether to include party types in the result.
	 * @return The EntityType object representing the retrieved entity type.
	 * @throws TypeNotFoundExecption If the entity type is not found.
	 */
	public EntityType getEntityTypeById(ServiceSupportEnv e, Long entityTypeId, Boolean partyTypesList) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		EntityTypeNTT entityTypeNTT = typesDAO.getEntityTypeById(env, entityTypeId);

		if(entityTypeNTT == null) {
			throw new TypeNotFoundExecption(Status.NOT_FOUND, Operation.GET_ENTITY_TYPE, ErrorField.TYPE, 
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), entityTypeId.toString());
		}

		EntityType type = EntityTypeMapper.INSTANCE.entityTODto(entityTypeNTT);

		if(Boolean.TRUE.equals(partyTypesList)) {
			List<PartyType> partyTypes = typesDAO.getPartyTypeWithEntityType(env, type.getId())
					.stream()
					.map(PartyTypeMapper.INSTANCE::entityTODto)
					.collect(Collectors.toList());

			type.setPartyTypesList(partyTypes != null ? partyTypes : new ArrayList<>());
		}

		return type;
	}

	/**
	 * Adds a new party type with the specified payload to the database. 
	 * If a type with the same code already exists, it throws a TypeAlreadyExistExecption.
	 *
	 * @param env the service support environment
	 * @param payload the payload containing the information for the new party type
	 * @return true if the party type was added successfully, false otherwise
	 * @throws TypeAlreadyExistExecption if the party type already exists
	 * @throws InvalidPayloadException if the payload is invalid
	 */
	public Boolean addPartyType(ServiceSupportEnv e, AddPartyTypePayload payload) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		PartyTypeNTT type = typesDAO.getPartyTypeByCode(env, payload.getCode());

		if(type != null) {
			throw new TypeAlreadyExistExecption(Status.CONFLICT, Operation.ADD_PARTY_TYPE, ErrorField.TYPE, 
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), 
					utilityService.getFormatedErrorMsg(type.getCode(), type.getDescription()));
		}

		typesDAO.useTransaction(dao -> {
			PartyTypeNTT partyTypeNTT = PartyTypeNTT.builder()
					.id(dao.nextSequenceValPartyTypes())
					.code(payload.getCode())
					.fl_exclusive(Boolean.TRUE.equals(payload.getFl_exclusive()) ? 1 : 0)
					.fl_manage(Boolean.TRUE.equals(payload.getFl_manage()) ? 1 : 0)
					.build();

			dao.insertPartyType(env.getTenantId(), partyTypeNTT);

			payload.getTranslations().forEach((lang, text) -> {
				I18nNTT row = I18nNTT.builder()
						.table_name(PARTY_TYPE_TABLE_NAME)
						.field_name(PARTY_TYPE_FIELD_CODE)
						.i18n_text(text)
						.i18n_value(payload.getCode())
						.lang(lang)
						.tenant_id(env.getTenantId())
						.build();

				I18nNTT toFind = i18nDAO.findI18nByPaclI18nKeys(row);

				if (toFind == null) {
					i18nDAO.insert(row);
				} else if (!toFind.getI18n_text().equals(text)) {
					i18nDAO.updateI18nText(row);
				}
			});

			insertEntityPartyTypeLink(env, partyTypeNTT.getId(), payload.getEntityTypeCodes());
		});
		return true;
	}

	protected void insertEntityPartyTypeLink(ServiceSupportEnv e, Long partyTypeId, List<String> EntityTypeCodes) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		EntityTypeCodes.stream().distinct().forEach(code -> {
			EntityTypeNTT entityTypeNTT = typesDAO.getEntityTypeByCode(env, code);
			if(entityTypeNTT == null) {
				throw new TypeNotFoundExecption(Status.NOT_FOUND, Operation.ADD_PARTY_TYPE, ErrorField.TYPE, 
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), code);
			}
			typesDAO.insertEntityPartyTypeLink(partyTypeId, entityTypeNTT.getId());
		});
	}

	/**
	 * Deletes the party type with the specified ID along with its translations from the database. 
	 * If the type does not exist or is associated with 
	 * some parties, it throws a TypeNotFoundExecption or PartiesWithTypeExecption respectively.
	 *
	 * @param env 
	 * @param id the ID of the party type to delete
	 * @return true if the party type was deleted successfully, false otherwise
	 * @throws TypeNotFoundExecption if the party type was not found
	 * @throws PartiesWithTypeExecption if there are parties associated with the specified party type
	 */
	public Boolean deletePartytype(ServiceSupportEnv e, Long id) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		PartyTypeNTT type = typesDAO.getPartyTypeById(env, id);
		if(type == null) {
			throw new TypeNotFoundExecption(Status.NOT_FOUND, Operation.REMOVE_PARTY_TYPE, ErrorField.TYPE, 
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), id.toString());
		}

		Integer count = typesDAO.countPartiesByType(env.getTenantId(), id);
		if(count != 0) {
			throw new PartiesWithTypeExecption(Status.BAD_REQUEST, Operation.REMOVE_PARTY_TYPE, ErrorField.TYPE, 
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		I18nNTT row = I18nNTT.builder()
				.tenant_id(env.getTenantId())
				.table_name(PARTY_TYPE_TABLE_NAME)
				.field_name(PARTY_TYPE_FIELD_CODE)
				.i18n_value(type.getCode())
				.build();

		typesDAO.deletePartyType(env.getTenantId(), id);
		i18nDAO.deleteAllI18n(row);

		return true;
	}

	/**
	 * Updates a party type with the given payload.
	 * 
	 * @param env
	 * @param partyTypeId The ID of the party type to update.
	 * @param payload The payload containing the new party type data.
	 * @return true if the update was successful, false otherwise.
	 * @throws InvalidPayloadException if the payload is empty.
	 * @throws TypeNotFoundExecption if the party type is not found.
	 */
	public Boolean updatePartyType(ServiceSupportEnv e, Long partyTypeId, UpdatePartyTypePayload payload) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		if(Boolean.TRUE.equals(payload.isEmtpy())) {
			throw new InvalidPayloadException(Status.BAD_REQUEST, Operation.UPDATE_PARTY_TYPE, ErrorField.TYPE, 
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		PartyTypeNTT partyTypeNTT = typesDAO.getPartyTypeById(env, partyTypeId);

		if(partyTypeNTT == null) {
			throw new TypeNotFoundExecption(Status.NOT_FOUND, Operation.UPDATE_PARTY_TYPE, ErrorField.TYPE, 
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), partyTypeId.toString());
		}

		Integer fl_exclusive = payload.getFl_exclusive() != null ? booleanToInteger(payload.getFl_exclusive()) : partyTypeNTT.getFl_exclusive();
		Integer fl_manage = payload.getFl_manage() != null ? booleanToInteger(payload.getFl_manage()) : partyTypeNTT.getFl_manage();

		typesDAO.updatePartyType(env.getTenantId(), partyTypeId, fl_exclusive, fl_manage);

		typesDAO.useTransaction(transaction  -> {
			//update i18n values
			payload.getTranslations().forEach((lang, text) -> {
				I18nNTT row = I18nNTT.builder()
						.table_name(PARTY_TYPE_TABLE_NAME)
						.field_name(PARTY_TYPE_FIELD_CODE)
						.i18n_text(text)
						.i18n_value(partyTypeNTT.getCode())
						.lang(lang)
						.tenant_id(env.getTenantId())
						.build();

				I18nNTT toFind = i18nDAO.findI18nByPaclI18nKeys(row);

				if (toFind == null) {
					i18nDAO.insert(row);
				} else if (!toFind.getI18n_text().equals(text)) {
					i18nDAO.updateI18nText(row);
				}
			});			

			//update entity-party type links
			typesDAO.removeLinksWithPartyId(env.getTenantId(), partyTypeId);
			insertEntityPartyTypeLink(env, partyTypeId, payload.getEntityTypeCodes());
		});

		return true;
	}

	/**
	 * Retrieves a list of party types filtered by code, if specified.
	 * 
	 * @param env
	 * @param id The ID of the party type to retrieve, or null to retrieve all party types.
	 * @param code The code of the party type to retrieve, or null to retrieve all party types.
	 * @return A PartyTypeList containing the retrieved party types.
	 * @throws TypeNotFoundExecption if the party type is not found.
	 */
	public InfiniteListResults<PartyType> getAllPartyTypes(ServiceSupportEnv e, String code, String nextKey) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		return this.typesDAO.infinite(() -> typesDAO.getAllPartyType(env, code),
				nextKey,
				DEFAULT_PAGE_SIZE)
				.map(PartyTypeMapper.INSTANCE::entityTODto);
	}

	/**
	 * Retrieves the party type with the specified ID.
	 *
	 * @param env           
	 * @param partyTypeId   The ID of the party type to retrieve.
	 * @return The PartyType object representing the requested party type.
	 * @throws TypeNotFoundExecption   If the party type was not found.
	 */
	public PartyType getPartyTypeById(ServiceSupportEnv e, Long partyTypeId) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		PartyTypeNTT partyTypeNTT = typesDAO.getPartyTypeById(env, partyTypeId);

		if(partyTypeNTT == null) {
			throw new TypeNotFoundExecption(Status.NOT_FOUND, Operation.GET_ENTITY_TYPE, ErrorField.TYPE, 
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), partyTypeId.toString());
		}

		return PartyTypeMapper.INSTANCE.entityTODto(partyTypeNTT);
	}

	private Integer booleanToInteger(Boolean x) {
		return Boolean.TRUE.equals(x) ? 1 : 0;
	}
}
