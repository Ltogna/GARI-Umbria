package com.abacogroup.partiesaclserver.core;

import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.support.InternalConfigNotFoundException;
import com.abacogroup.partiesaclserver.core.models.InternalConfig;
import com.abacogroup.partiesaclserver.resources.res.ClientConfiguration;
import com.abacogroup.partiesaclserver.resources.res.ClientConfigurationList;

import jakarta.ws.rs.core.Response.Status;

public class SupportService {
	
	protected InternalConfigService internalConf;
	private ErrorDescriptionsService errorDescriptionsService;
	
	public SupportService(InternalConfigService internalConfigService, ErrorDescriptionsService errorDescriptionsService) {
		this.internalConf = internalConfigService;
		this.errorDescriptionsService = errorDescriptionsService;
	}
	

	public ClientConfigurationList getClientConfig(String tenantId, String lang, String configKey) {

		ClientConfigurationList result = ClientConfigurationList.builder().client_configuration(new ArrayList<>()).build();

		Map<String, InternalConfig> configuration = this.internalConf.getInternalTenantConfiguration(tenantId);
		
		configuration.forEach((key, config) -> {
			if (Boolean.TRUE.equals(config.getFl_client()) || config.getKey().equals(configKey)) {
				String name = StringUtils.isNotBlank(config.getName()) ? config.getName() : config.getKey();

				result.getClient_configuration().add(
						ClientConfiguration.builder()
								.name(name)
								.value(config.getValue())
								.build());
			}
		});

		if(configKey != null) {
			result.setClient_configuration(
					result.getClient_configuration()
						.stream()
						.filter(c -> configKey.equals(c.getName()))
						.collect(toList())
			);
		}
		
		if(result == null || result.getClient_configuration() == null || result.getClient_configuration().isEmpty()) {
			throw new InternalConfigNotFoundException(Status.NOT_FOUND, Operation.GET_INTERNAL_CONFIG, ErrorField.CONFIG,
					this.errorDescriptionsService.getTenantErrorDescriptions(tenantId), lang);
		}
		
		return result;
	
	}

}
