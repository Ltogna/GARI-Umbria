package com.abacogroup.partiesaclserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.resources.pub.res.EntityTypeV1;
import com.abacogroup.partiesaclserver.resources.res.EntityType;

@Mapper
public interface EntityTypeV1ResponseMapper {
	
	EntityTypeV1ResponseMapper INSTANCE = Mappers.getMapper(EntityTypeV1ResponseMapper.class);
	
	@InheritInverseConfiguration()
	EntityTypeV1 toResponseV1(EntityType type);	
}
