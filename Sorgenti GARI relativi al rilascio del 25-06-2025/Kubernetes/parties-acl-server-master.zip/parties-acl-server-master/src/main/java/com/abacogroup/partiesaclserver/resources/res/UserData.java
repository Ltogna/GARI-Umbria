package com.abacogroup.partiesaclserver.resources.res;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class UserData {
	private String userId;
	private String tenant;
	private String userName;
	private String description;
}