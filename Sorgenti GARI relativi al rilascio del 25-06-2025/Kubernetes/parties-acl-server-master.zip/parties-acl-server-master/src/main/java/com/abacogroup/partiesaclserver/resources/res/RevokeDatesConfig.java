package com.abacogroup.partiesaclserver.resources.res;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RevokeDatesConfig {
	@Schema(description = "Party type code", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String partyTypeCode;
	
	@Schema(description = "Entity type code", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String entityTypeCode;
	
	@Schema(description = "Start validity date - format MMDD", type = "string", format = "YYYYMMDD", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String dayFrom;
	
	@Schema(description = "End validity date - format MMDD", type = "string", format = "YYYYMMDD", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String dayTo;
}


