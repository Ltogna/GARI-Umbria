package com.abacogroup.partiesaclserver.resources.pub.req;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.QueryParam;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class PartyEntitySearchFiltersV1 {

	@Parameter(in = ParameterIn.QUERY, description = "Set true to get history")
	@DefaultValue("false")
	@QueryParam("history")
	@Default
	private Boolean history = false;
	
	@Parameter(in = ParameterIn.QUERY, description = "Entity type code filter")
	@QueryParam("entityTypeCode")
	private String entityTypeCode;	
	
	@Parameter(in = ParameterIn.QUERY, description = "min date filter")
	@QueryParam("minDate")
	private AbsoluteDate minDate;

	@Parameter(in = ParameterIn.QUERY, description = "max date filter")
	@QueryParam("maxDate")
	private AbsoluteDate maxDate;
	
	@Parameter(in = ParameterIn.QUERY, description = "if true returns only exclusive mandates filter")
	@QueryParam("onlyExclusive")
	private Boolean onlyExclusive;
	
	@Parameter(in = ParameterIn.QUERY, description = "define with manage level")
	@QueryParam("withManage") 
	@Default
	private Integer withManage = 1;
	
}
