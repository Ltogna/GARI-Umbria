package com.abacogroup.partiesaclserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.resources.pub.req.PartyEntitySearchFiltersV1;
import com.abacogroup.partiesaclserver.resources.req.PartyEntitySearchFilters;

@Mapper
public interface PartyEntitySearchFiltersV1Mapper {

	PartyEntitySearchFiltersV1Mapper INSTANCE = Mappers.getMapper(PartyEntitySearchFiltersV1Mapper.class);

	@InheritInverseConfiguration()
	PartyEntitySearchFilters fromFiltersV1(PartyEntitySearchFiltersV1 filters);

}
