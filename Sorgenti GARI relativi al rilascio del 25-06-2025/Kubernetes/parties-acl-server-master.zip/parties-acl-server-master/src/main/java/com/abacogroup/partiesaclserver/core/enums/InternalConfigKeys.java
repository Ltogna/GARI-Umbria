package com.abacogroup.partiesaclserver.core.enums;

public enum InternalConfigKeys {
	ALLOW_PAST_DATE("allow_past_date"),
	ALLOW_PAST_CLOSE_DATE("allow_past_close_date"),
	PARTY_REGISTRY_URL("party_registry_url"),
	ANOMALIES_REGISTRY_URL("anomalies_registry_url"),
	FL_SHOW_UNCATEGORIZED_ANOMALY_TYPES_KEY("fl_show_uncategorized_anomaly_types"),
	ANOMALIES_PARTY_CODE_KEY("anomalies_party_code_key"),
	ANOMALIES_ENTITY_CODE_KEY("anomalies_entity_code_key"),
	ANOMALIES_USER_CODE_KEY("anomalies_user_code_key"),
	MAX_ANOMALY_LEVEL_ALLOWED_EDIT_ENTITY("max_anomly_level_allowed_edit_entity"),
	MAX_ANOMALY_LEVEL_ALLOWED_EDIT_PARTY("max_anomly_level_allowed_edit_party"),
	MAX_ANOMALY_LEVEL_ALLOWED_EDIT_USER("max_anomly_level_allowed_edit_user"),
	HIERARCHICAL_INHERITANCE_LEVEL("hierarchical_inheritance_level"),
	INHERIT_MANAGEMENT("inherit_management"),
	SHOW_CHRONOLOGICAL_DUE_DATE("show_chronological_due_date"),
	REVOKE_MANDATE_CONFIG("revoke_mandate_config"),
	PARTY_REGISTRY_SEARCH_ADDITIONAL_QUERY_PARAM("party_registry_search_additional_query_param"),
	EXTERNAL_CHECK_BEFORE_CLOSE("external_check_before_close");	


	private final String key;

	private InternalConfigKeys(String key) {
		this.key = key;
	}

	public String getKey() {
		return key;
	}
}
