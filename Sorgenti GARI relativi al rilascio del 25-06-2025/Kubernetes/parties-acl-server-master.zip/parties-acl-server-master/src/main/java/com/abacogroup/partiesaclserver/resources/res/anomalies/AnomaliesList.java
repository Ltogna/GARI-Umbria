package com.abacogroup.partiesaclserver.resources.res.anomalies;

import java.util.List;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class AnomaliesList {
	@ArraySchema(schema = @Schema(description = "List of Anomalies", implementation = Anomaly.class))
	private List<Anomaly> anomalies_list;

	@Schema(description = "Error code", type = "string")
	private String error;
}
