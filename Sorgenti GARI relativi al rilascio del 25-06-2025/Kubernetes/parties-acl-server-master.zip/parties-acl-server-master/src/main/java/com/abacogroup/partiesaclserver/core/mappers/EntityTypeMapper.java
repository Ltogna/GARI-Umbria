package com.abacogroup.partiesaclserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.db.ntt.EntityTypeNTT;
import com.abacogroup.partiesaclserver.resources.res.EntityType;

@Mapper
public interface EntityTypeMapper {
	
	EntityTypeMapper INSTANCE = Mappers.getMapper(EntityTypeMapper.class);
	
	@InheritInverseConfiguration()
	@Mapping(target = "partyTypesList", ignore = true)
	@Mapping(target = "flEntityCodeMandatory", expression = "java(type.getFl_entity_code_mandatory() == 1)")
	EntityType entityTODto(EntityTypeNTT type);
	
	@Mapping(target = "fl_single_relation", ignore = true)
	@Mapping(target = "fl_hidden", ignore = true)
	@Mapping(target = "fl_entity_code_mandatory", expression = "java(dto.getFlEntityCodeMandatory() ? 1 : 0)")
	EntityTypeNTT dtoToEntity(EntityType dto);
	
}
