package com.abacogroup.partiesaclserver.core.exceptions.entity;

import java.util.Map;

import jakarta.ws.rs.core.Response.Status;

import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractException;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EntityWithoutParentExecption extends AbstractException{

	private static final long serialVersionUID = 7007786789585903405L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.ENTITY_WITHOUT_PARENT;

	public EntityWithoutParentExecption(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang, String entity) {
		super(code, new EntityWithoutParentExecptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
		
		String msg = String.format(this.getBody().getMessage(), entity);
		this.getBody().setMessage(msg);
		log.error(this.getBody().getLogErrorMessage());
	}

	@Schema(description = "Entity does not have parent")
	public static class EntityWithoutParentExecptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = 1128890989334439638L;

		public EntityWithoutParentExecptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
