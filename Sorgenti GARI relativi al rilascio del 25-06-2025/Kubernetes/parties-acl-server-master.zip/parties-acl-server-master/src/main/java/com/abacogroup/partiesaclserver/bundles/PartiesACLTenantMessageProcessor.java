package com.abacogroup.partiesaclserver.bundles;

import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;

public interface PartiesACLTenantMessageProcessor extends TenantMessageProcessor {

	void syncAllTenant();
}
