package com.abacogroup.partiesaclserver.resources.res;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class PathUser {	
	@Schema(description = "User id", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String id;
	
	@Schema(description = "User's role", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String role;
}
