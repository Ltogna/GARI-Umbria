package com.abacogroup.partiesaclserver.core.exceptions;

import java.util.Map;

import jakarta.ws.rs.core.Response.Status;

import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class InvalidEndDateException extends AbstractException {

	private static final long serialVersionUID = -6829106613358855577L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_END_DATE;

	public InvalidEndDateException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new InvalidEndDateExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
		
		log.error(this.getBody().getLogErrorMessage());
	}

	@Schema(description = "Invalid end date")
	public static class InvalidEndDateExceptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = -6196402541546172600L;

		public InvalidEndDateExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
