package com.abacogroup.partiesaclserver.db.ntt;

import com.abacogroup.partiesaclserver.core.enums.DocTypeRelationScope;
import com.abacogroup.partiesaclserver.core.enums.Revision;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DocTypeRelationNTT {

	private Long pkid;
	private Revision revisionCode;
	private DocTypeRelationScope scopeCode;
	private Integer displayOrder;
	private Long entityTypeId;
	private Long partyTypeId;
	private String definitionCode;
	private String definitionCodeI18n;

}
