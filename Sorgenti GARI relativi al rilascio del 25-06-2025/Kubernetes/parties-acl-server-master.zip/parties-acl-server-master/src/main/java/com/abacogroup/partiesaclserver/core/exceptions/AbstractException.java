package com.abacogroup.partiesaclserver.core.exceptions;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public abstract class AbstractException extends WebApplicationException {
	
	private static final long serialVersionUID = -8703954980614804145L;
	
	private final AbstractExceptionBody body;

	protected AbstractException(Status status, AbstractExceptionBody body){
		super(Response.status(status)
				.entity(body)
				.build());

		this.body = body;
	}

}
