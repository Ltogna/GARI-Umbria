package com.abacogroup.partiesaclserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.resources.pub.res.UserPartyV1;
import com.abacogroup.partiesaclserver.resources.res.UserParty;

@Mapper(uses = {PartyTypeV1ResponseMapper.class, PartyV1ResponseMapper.class})
public interface UserPartyV1ResponseMapper {

	UserPartyV1ResponseMapper INSTANCE = Mappers.getMapper(UserPartyV1ResponseMapper.class);

	@InheritInverseConfiguration()
	UserPartyV1 toResponseV1(UserParty entity);
	
}