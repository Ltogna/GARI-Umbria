package com.abacogroup.partiesaclserver.core.exceptions.type;

import static org.apache.commons.text.StringEscapeUtils.escapeHtml4;

import java.util.Map;

import jakarta.ws.rs.core.Response.Status;

import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractException;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TypeNotFoundExecption extends AbstractException{

	private static final long serialVersionUID = -7042838456954883313L;

	private static final ErrorCode ERROR_CODE = ErrorCode.TYPE_NOT_FOUND;

	public TypeNotFoundExecption(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang, String typeCode) {
		super(code, new TypeNotFoundExecptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));

		String msg = String.format(this.getBody().getMessage(), escapeHtml4(typeCode));
		this.getBody().setMessage(msg);

		log.error(this.getBody().getLogErrorMessage());
	}

	@Schema(description = "Type code or id not found")
	public static class TypeNotFoundExecptionBody extends AbstractExceptionBody {

		private static final long serialVersionUID = -230796541489800056L;

		public TypeNotFoundExecptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
