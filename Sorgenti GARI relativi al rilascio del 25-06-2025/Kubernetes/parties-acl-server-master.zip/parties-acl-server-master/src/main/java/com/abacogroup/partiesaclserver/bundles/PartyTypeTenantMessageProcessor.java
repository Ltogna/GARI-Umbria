package com.abacogroup.partiesaclserver.bundles;

import java.util.List;

import com.abacogroup.bundles.db.dao.TenantDAO;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.partiesaclserver.core.exceptions.bundles.BundleEntityTypeException;
import com.abacogroup.partiesaclserver.core.exceptions.bundles.BundlePartyTypeException;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.TypesDAO;
import com.abacogroup.partiesaclserver.db.ntt.EntityTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyTypeNTT;


public class PartyTypeTenantMessageProcessor implements PartiesACLTenantMessageProcessor {

	private static final String TEMPLATE_TENANT_ID = "*";

	private TenantDAO tenantDAO;
	private TypesDAO typesDAO;

	public PartyTypeTenantMessageProcessor(DAOContainer dc) {
		this.tenantDAO= dc.getTenantDAO();
		this.typesDAO = dc.getTypesDAO();
	}

	@Override
	public void onMessage(TenantMessage message) {
		String tenantId = message.getTenantId();

		if (tenantId.equals(TEMPLATE_TENANT_ID)) {
			return;
		}

		List<PartyTypeNTT> partyTypeList = typesDAO.findTenantPartyTypeDifference(TEMPLATE_TENANT_ID, tenantId);

		ServiceSupportEnv starEnv = ServiceSupportEnv.builder().tenantId(TEMPLATE_TENANT_ID).build();
		ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).build();
		partyTypeList.stream()
		.filter(t -> typesDAO.getPartyTypeByCode(env, t.getCode()) == null)
		.forEach(partyType -> {
			Long oldId = partyType.getId();
			partyType.setId(typesDAO.nextSequenceValPartyTypes());
			try {
				typesDAO.insertPartyType(tenantId, partyType);
			} catch (Exception e) {
				throw new BundlePartyTypeException("Error during insert party type message " + message.toString() + " for tenant " + tenantId + ".\n" + e.getMessage());
			}
			
			typesDAO.getEntityTypeWithPartyType(starEnv, oldId).forEach(entityType -> {
				EntityTypeNTT newEntityType = typesDAO.getEntityTypeByCode(env, entityType.getCode());
				if(newEntityType == null) {
					throw new BundleEntityTypeException("Entity type with code '" + entityType.getCode() + "' does not exists for tenant '" + env.getTenantId() + "'.\n");
				}
				typesDAO.insertEntityPartyTypeLink(partyType.getId(), newEntityType.getId());
			});
		});

	}

	@Override
	public void syncAllTenant() {
		tenantDAO.findAll().forEach(t -> onMessage(new TenantMessage().setTenantId(t.getTenantId())));
	}
}
