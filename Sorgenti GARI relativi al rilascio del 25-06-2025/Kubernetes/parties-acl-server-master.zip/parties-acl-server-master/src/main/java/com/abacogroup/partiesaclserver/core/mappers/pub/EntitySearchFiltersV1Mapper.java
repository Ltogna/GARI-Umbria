package com.abacogroup.partiesaclserver.core.mappers.pub;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.resources.pub.req.EntitySearchFiltersV1;
import com.abacogroup.partiesaclserver.resources.req.EntitySearchFilters;

@Mapper
public interface EntitySearchFiltersV1Mapper {

	EntitySearchFiltersV1Mapper INSTANCE = Mappers.getMapper(EntitySearchFiltersV1Mapper.class);

	@InheritInverseConfiguration()
	EntitySearchFilters toResponse(EntitySearchFiltersV1 filter);

}