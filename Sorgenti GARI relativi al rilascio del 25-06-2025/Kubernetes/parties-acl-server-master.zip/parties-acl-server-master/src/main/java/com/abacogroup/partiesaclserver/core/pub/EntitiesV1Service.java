package com.abacogroup.partiesaclserver.core.pub;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partiesaclserver.core.EntitiesService;
import com.abacogroup.partiesaclserver.core.mappers.pub.CreateEntityPayloadV1Mapper;
import com.abacogroup.partiesaclserver.core.mappers.pub.EntitySearchFiltersV1Mapper;
import com.abacogroup.partiesaclserver.core.mappers.pub.EntityV1ResponseMapper;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.resources.pub.req.CreateEntityPayloadV1;
import com.abacogroup.partiesaclserver.resources.pub.req.EntitySearchFiltersV1;
import com.abacogroup.partiesaclserver.resources.pub.res.EntityV1;

public class EntitiesV1Service {

	private final EntitiesService entitiesService;

	/**
	 * The PublicEntitiesService class provides methods to manage entities.
	 * It provides methods to create entities, retrieve entities based on filters, and manage entity hierarchy.
	 */
	public EntitiesV1Service(EntitiesService entitiesService) {
		this.entitiesService = entitiesService;
	}
	
	public Long createEntity(ServiceSupportEnv e, CreateEntityPayloadV1 payload) {
		return entitiesService.createEntity(e, CreateEntityPayloadV1Mapper.INSTANCE.toResponse(payload));
	}

	/**
	 * Retrieves an entity by its Code.
	 *
	 * @param e      the service support environment
	 * @param entityCode the code of the entity to retrieve
	 * @param skipPermissionCheck if true, skip permission check when retrieving entity data
	 * @return the retrieved entity
	 */
	public EntityV1 getEntityByCode(ServiceSupportEnv e, String entityCode, boolean skipPermissionCheck) {
		return EntityV1ResponseMapper.INSTANCE.toResponseV1(entitiesService.getEntityByCode(e, entityCode, skipPermissionCheck));
	}

	public InfiniteListResults<EntityV1> getAllEntities(ServiceSupportEnv e, EntitySearchFiltersV1 filter, String nextKey) {
		e.setReferenceDate(filter.getReferenceDate());
		
		return entitiesService.getEntities(e, EntitySearchFiltersV1Mapper.INSTANCE.toResponse(filter), filter.getSkipPermissionCheck(), nextKey)
				.map(EntityV1ResponseMapper.INSTANCE::toResponseV1);
	}
}
