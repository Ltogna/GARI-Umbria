package com.abacogroup.partiesaclserver.resources.req;

import java.util.Map;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class AddEntityTypePayload {
	@Schema(description = "Code of Entity type", type = "string", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private String code;
	
	@Schema(description = "true if Entity code is mandatory", type = "boolean", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Boolean flEntityCodeMandatory;
	
	@Schema(description = "1 if entity has only one party", type = "boolean", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Boolean flSingleRelation;
	
	@Schema(description = "1 if entity is hidden", type = "boolean", requiredMode = RequiredMode.REQUIRED)
	@NotNull
	private Boolean flHidden;
	
	@ArraySchema(schema = @Schema(description = "translations", requiredMode = RequiredMode.REQUIRED))
	@NotNull
	@Size(min = 1)
	@Valid
	private Map<String, String> translations;
}
