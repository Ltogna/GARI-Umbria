package com.abacogroup.partiesaclserver.bundles.models;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EntityType {
	private String code;
	private Boolean fl_entity_code_mandatory;
	private Boolean fl_single_relation;
	private Boolean fl_hidden;
	private Map<String, String> translations;
}
