package com.abacogroup.partiesaclserver.core;

import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.dynamicdocuments.bean.Document;
import com.abacogroup.dynamicdocuments.bean.DocumentDefinition;
import com.abacogroup.dynamicdocuments.bean.InsertDocument;
import com.abacogroup.dynamicdocuments.bean.documentdefinition.fieldset.field.FieldType;
import com.abacogroup.dynamicdocuments.exceptions.UnknownDocumentException;
import com.abacogroup.dynamicdocuments.services.DocumentService;
import com.abacogroup.dynamicdocuments.services.DocumentTypeService;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partiesaclserver.core.enums.DocTypeRelationScope;
import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.MandateStatus;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.enums.Revision;
import com.abacogroup.partiesaclserver.core.exceptions.documents.DocumentFileNotFoundException;
import com.abacogroup.partiesaclserver.core.exceptions.documents.DocumentNotFoundException;
import com.abacogroup.partiesaclserver.core.exceptions.documents.InvalidDocumentCodeException;
import com.abacogroup.partiesaclserver.core.exceptions.documents.MaxOccursException;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.MandateNotEditableException;
import com.abacogroup.partiesaclserver.core.mappers.DocumentResMapper;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.PaclDocumentDAO;
import com.abacogroup.partiesaclserver.db.ntt.DocumentNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyWithEntityNTT;
import com.abacogroup.partiesaclserver.resources.res.MandateDocumentRes;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class MandateDocumentService {
	
	private final PaclDocumentDAO documentDAO;
	
	private final DocumentService documentService;
	private final DocumentTypeService documentTypeService;
	private final UtilityService utilityService;
	private final ErrorDescriptionsService errorDescriptionsService;
	private final FileStoreProxyClientService fileStoreProxyClientService;
	
	private final String dynamicDocumentsBucket;
	
	private static final AbsoluteDate INFINITE = AbsoluteDate.of("99991231");
	
	public MandateDocumentService(DAOContainer container, UtilityService utilityService, DocumentService documentService,
			DocumentTypeService documentTypeService, ErrorDescriptionsService errorDescriptionsService, 
			FileStoreProxyClientService fileStoreProxyClientService, String dynamicDocumentsBucket) {
		this.documentDAO = container.getPaclDocumentDAO();
		this.documentTypeService = documentTypeService;
		this.documentService = documentService;
		this.utilityService = utilityService;
		this.errorDescriptionsService = errorDescriptionsService;
		this.dynamicDocumentsBucket = dynamicDocumentsBucket;
		this.fileStoreProxyClientService = fileStoreProxyClientService;
	}

	public MandateDocumentRes insert(ServiceSupportEnv env, Long mandateId, @NotNull @Valid InsertDocument document) {

		if (StringUtils.isBlank(document.getDefCode())) {
			throw new InvalidDocumentCodeException(Status.BAD_REQUEST, Operation.ADD_MANDATE_DOC, ErrorField.DOCUMENT_CODE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), "");
		}

		PartyWithEntityNTT mandate = utilityService.getPartyWithEntityNTT(env, mandateId, Operation.ADD_MANDATE_DOC);
		
		if(Boolean.FALSE.equals(mandate.getEditable())) {
			throw new MandateNotEditableException(Status.BAD_REQUEST, Operation.ADD_MANDATE_DOC, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}
		
		//XXX giusto cosi?
		document.setBusinessId(mandate.getMandate_id());

		String definitionCode = document.getDefCode();
		DocumentDefinition definition = this.documentTypeService.getDocumentDefinition(env.getTenantId(), definitionCode)
				.orElseThrow(() -> new InvalidDocumentCodeException(Status.BAD_REQUEST, Operation.ADD_MANDATE_DOC, ErrorField.DOCUMENT_CODE,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), definitionCode));

		int maxOccurs = 0;
		if (null != definition.getMetadata()) {
			maxOccurs = Optional.ofNullable(definition.getMetadata().getMaxOccurs()).orElse(0);
		}
		if (maxOccurs <= this.countDocumentsByEntityIdMandateIdAndDefinitionCode(env, mandate.getEntity().getEntity_id(), mandate.getMandate_id(), definitionCode)) {
			throw new MaxOccursException(Status.BAD_REQUEST, Operation.ADD_MANDATE_DOC, ErrorField.DOCUMENT,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		Long documentId = documentDAO.inTransaction(handle -> {
			Long id = store(env, document.getDoc(), document.getDefCode(), env.getUser().getUserId(),
					document.getBusinessId(), document.getLabel());

			DocumentNTT documentNTT = DocumentNTT.builder()
					.setPkid(documentDAO.nextSequenceVal())
					.setEntityId(mandate.getEntity().getEntity_id())
					.setMandateId(mandate.getMandate_id())
					.setScopeCode(DocTypeRelationScope.MANDATES)
					.setDefinitionCode(document.getDefCode())
					.setDocumentId(id)
					.build();
			
			documentDAO.insert(env, documentNTT);
			return id;
		});
		
		List<Revision> revList = new ArrayList<>(Arrays.asList(Revision.ADD_MANDATE));
		if(!mandate.getDay_to().equals(INFINITE)) {
			revList.add(Revision.REMOVE_MANDATE);
		}
		
		MandateStatus status = utilityService.checkMandateStatus(env, mandate.getEntity(), mandate, revList);
		if(!status.equals(mandate.getStatus())) {
			utilityService.updateMandateStatus(env, mandate, status, Operation.ADD_MANDATE_DOC);
		}
		
		return getMandateDocument(env, mandateId, documentId);
	}

	private Long store(ServiceSupportEnv env, Document document, String definitionCode, String userID, Long mandateId, String label) {
		
		document.setValidFrom(Optional.ofNullable(document.getValidFrom()).orElse(OffsetDateTime.now()));
		document.setValidTo(Optional.ofNullable(document.getValidTo())
				.orElse(OffsetDateTime.of(INFINITE.toLocalDate(), LocalTime.MIN, ZoneOffset.UTC)));
		
		return documentService.insertDocument(env.getTenantId(), definitionCode, document, userID, mandateId, label);
	}
	
	public MandateDocumentRes getMandateDocument(ServiceSupportEnv env, Long mandateId, Long documentId) {
		PartyWithEntityNTT mandate = utilityService.getPartyWithEntityNTT(env, mandateId, Operation.GET_DOCUMENT);
		return documentDAO.getByDocumentIdEntityIdAndMandateId(DocTypeRelationScope.MANDATES, mandate.getEntity().getEntity_id(), mandateId, documentId)
				.map(DocumentResMapper.INSTANCE::toMandateDocumentRes)
				.map(document -> DocumentMapper.addData(env, document, documentService, errorDescriptionsService, dynamicDocumentsBucket, Operation.GET_DOCUMENT))
				.orElseThrow(() -> new DocumentNotFoundException(Status.BAD_REQUEST, Operation.GET_DOCUMENT, ErrorField.DOCUMENT_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang()));
	}

	public InfiniteListResults<MandateDocumentRes> search(ServiceSupportEnv env, Long mandateId, String definitionCode, 
			String nextKey, Integer pageSize) {
		PartyWithEntityNTT mandate = utilityService.getPartyWithEntityNTT(env, mandateId, Operation.GET_DOCUMENTS);

		return documentDAO.infinite(() -> 
		documentDAO.search(DocTypeRelationScope.MANDATES, mandate.getEntity().getEntity_id(), mandateId, definitionCode), nextKey, pageSize)
				.map(DocumentResMapper.INSTANCE::toMandateDocumentRes)
				.map(pd -> DocumentMapper.addSummaryFields(env, pd, documentTypeService, documentService, dynamicDocumentsBucket));
	}

	public void expire(ServiceSupportEnv env, Long mandateId, Long documentId) {
		PartyWithEntityNTT mandate = utilityService.getPartyWithEntityNTT(env, mandateId, Operation.REMOVE_MANDATE_DOC);
		if(Boolean.FALSE.equals(mandate.getEditable())) {
			throw new MandateNotEditableException(Status.BAD_REQUEST, Operation.REMOVE_MANDATE_DOC, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}
		
		Long entityId = mandate.getEntity().getEntity_id();
		DocumentNTT documentNTT = documentDAO.getByDocumentIdEntityIdAndMandateId(DocTypeRelationScope.MANDATES, entityId, mandateId, documentId)
				.orElseThrow(() -> new DocumentNotFoundException(Status.BAD_REQUEST, Operation.REMOVE_MANDATE_DOC, ErrorField.DOCUMENT_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang()));

		Document doc = Optional.of(documentService.getDocumentFromId(documentId))
				.orElseThrow(() -> new DocumentNotFoundException(Status.BAD_REQUEST, Operation.REMOVE_MANDATE_DOC, ErrorField.DOCUMENT_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang()));

		doc.setValidTo(OffsetDateTime.now());
		documentDAO.useTransaction(handle -> {
			documentService.updateDocument(documentId, doc, env.getUser().getUserId());
			documentDAO.expireRow(env, documentNTT.getPkid());
		});
		
		List<Revision> revList = new ArrayList<>(Arrays.asList(Revision.ADD_MANDATE));
		if(!mandate.getDay_to().equals(INFINITE)) {
			revList.add(Revision.REMOVE_MANDATE);
		}
		
		MandateStatus status = utilityService.checkMandateStatus(env, mandate.getEntity(), mandate, revList);
		if(status.equals(mandate.getStatus())) {
			return;
		}
		
		utilityService.updateMandateStatus(env, mandate, status, Operation.REMOVE_MANDATE_DOC);
	}

	public MandateDocumentRes update(ServiceSupportEnv env, Long mandateId, Long documentId, @NotNull @Valid Document updateReq) {
		PartyWithEntityNTT mandate = utilityService.getPartyWithEntityNTT(env, mandateId, Operation.UPDATE_MANDATE_DOC);
		
		if(Boolean.FALSE.equals(mandate.getEditable())) {
			throw new MandateNotEditableException(Status.BAD_REQUEST, Operation.UPDATE_MANDATE_DOC, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}
		
		Long entityId = mandate.getEntity().getEntity_id();
		DocumentNTT documentNTT = documentDAO.getByDocumentIdEntityIdAndMandateId(DocTypeRelationScope.MANDATES, entityId, mandateId, documentId)
				.orElseThrow(() -> new DocumentNotFoundException(Status.BAD_REQUEST, Operation.UPDATE_MANDATE_DOC, ErrorField.DOCUMENT_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang()));

		Document doc = Optional.of(documentService.getDocumentFromId(documentId))
				.orElseThrow(() -> new DocumentNotFoundException(Status.BAD_REQUEST, Operation.UPDATE_MANDATE_DOC, ErrorField.DOCUMENT_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang()));

		doc.setValidFrom(Optional.ofNullable(updateReq.getValidFrom()).orElse(doc.getValidFrom()));
		doc.setValidTo(Optional.ofNullable(updateReq.getValidTo()).orElse(doc.getValidTo()));
		doc.setFields(Optional.ofNullable(updateReq.getFields()).orElse(doc.getFields()));
		documentNTT.setMandateId(mandateId);
		documentNTT.setEntityId(entityId);
		documentNTT.setDocumentId(documentId);

		documentDAO.useTransaction(handle -> {
			documentService.updateDocument(documentId, doc, env.getUser().getUserId());
			documentDAO.expireRow(env, documentNTT.getPkid());
			
			documentNTT.setPkid(documentDAO.nextSequenceVal());
			documentDAO.insert(env, documentNTT);
		});

		return getMandateDocument(env, mandateId, documentId);
	}

	public Response getDocumentFileContent(ServiceSupportEnv env, Long mandateId, Long documentId, String fileId) {
		this.validateCanReadFile(env, mandateId, documentId, fileId, Operation.GET_DOC_ATTACHMENT);
		return fileStoreProxyClientService.getFileContent(env, dynamicDocumentsBucket, fileId);
	}

	public Response getDocumentFileMetadata(ServiceSupportEnv env, Long mandateId, Long documentId, String fileId) {
		this.validateCanReadFile(env, mandateId, documentId, fileId, Operation.GET_DOC_METADATA);
		return fileStoreProxyClientService.getFileMetadata(env, dynamicDocumentsBucket, fileId);
	}

	public Long countDocumentsByEntityIdMandateIdAndDefinitionCode(ServiceSupportEnv env, Long entityId, Long mandateId, String code) {
		return documentDAO.countByDefinitionCodeEntityIdAndMandateId(env.getTenantId(), DocTypeRelationScope.MANDATES, entityId, mandateId, code);
	}
	
	private void validateCanReadFile(ServiceSupportEnv env, Long mandateId, Long documentId, String fileId, Operation operation) {
		PartyWithEntityNTT mandate = utilityService.getPartyWithEntityNTT(env, mandateId, operation);
		Long entityId = mandate.getEntity().getEntity_id();
		DocumentNTT documentNTT = documentDAO.getByDocumentIdEntityIdAndMandateId(DocTypeRelationScope.MANDATES, entityId, mandateId, documentId)
				.orElseThrow(() -> new DocumentNotFoundException(Status.BAD_REQUEST, operation, ErrorField.DOCUMENT_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang()));


		Document document;
		try {
			document = documentService.getDocumentFromId(documentNTT.getDocumentId());
		} catch (UnknownDocumentException ude) {
			throw new DocumentNotFoundException(Status.BAD_REQUEST, operation, ErrorField.DOCUMENT_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}
		DocumentDefinition definition = documentTypeService.getDocumentDefinition(env.getTenantId(), documentNTT.getDefinitionCode())
				.orElseThrow(() -> new DocumentNotFoundException(Status.BAD_REQUEST, operation, ErrorField.DOCUMENT_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang()));

		boolean containsFileId = definition.getFieldSets().stream()
				.flatMap(fieldSet -> fieldSet.getFields().stream())
				.filter(field -> FieldType.FILE.equals(field.getType()))
				.map(field -> document.getFields().get(field.getCode()))
				.filter(Objects::nonNull)
				.flatMap(fieldValue -> fieldValue instanceof Collection ? ((Collection<?>) fieldValue).stream() : Stream.of(fieldValue))
				.anyMatch(fileId::equals);

		if (!containsFileId) {
			throw new DocumentFileNotFoundException(Status.BAD_REQUEST, operation, ErrorField.FILE_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), documentId, fileId);
		}
	}
}

