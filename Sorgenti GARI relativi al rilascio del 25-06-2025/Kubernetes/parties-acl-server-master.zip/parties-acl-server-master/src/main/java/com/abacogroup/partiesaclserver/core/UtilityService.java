package com.abacogroup.partiesaclserver.core;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partiesaclserver.core.enums.AnomalyLevel;
import com.abacogroup.partiesaclserver.core.enums.DocTypeRelationScope;
import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.InternalConfigKeys;
import com.abacogroup.partiesaclserver.core.enums.MandateStatus;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.enums.Revision;
import com.abacogroup.partiesaclserver.core.exceptions.InternalConfigException;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidRequestException;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityNotFoundExecption;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.MandateNotEditableException;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.MandateNotFoundException;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeNotCompatibleExecption;
import com.abacogroup.partiesaclserver.core.exceptions.type.TypeNotFoundExecption;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.DocTypeRelationDAO;
import com.abacogroup.partiesaclserver.db.dao.EntityDAO;
import com.abacogroup.partiesaclserver.db.dao.MandatesDAO;
import com.abacogroup.partiesaclserver.db.dao.PaclDocumentDAO;
import com.abacogroup.partiesaclserver.db.dao.TypesDAO;
import com.abacogroup.partiesaclserver.db.ntt.DocTypeRelationNTT;
import com.abacogroup.partiesaclserver.db.ntt.EntityNTT;
import com.abacogroup.partiesaclserver.db.ntt.EntityTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyWithEntityNTT;
import com.abacogroup.partiesaclserver.db.ntt.UpdatedObjectDataNTT;
import com.abacogroup.partiesaclserver.resources.res.RevokeDatesConfig;

import jakarta.ws.rs.core.Response.Status;

public class UtilityService {

	private final EntityDAO entityDAO;
	private final MandatesDAO mandatesDAO;
	private final DocTypeRelationDAO docTypeRelationDAO;
	private final PaclDocumentDAO documentDAO;
	private final TypesDAO typesDAO;
	private final ErrorDescriptionsService errorDescriptionsService;
	private final InternalConfigService internalConfigService;
	private final SecurityService securityService;
	private final RevisionService revisionService;
	
	private static final AbsoluteDate INFINITE = AbsoluteDate.of("99991231");
	
	public UtilityService(DAOContainer container, SecurityService securityService, RevisionService revisionService,
			InternalConfigService internalConfigService, ErrorDescriptionsService errorDescriptionsService) {
		this.entityDAO = container.getEntityDAO();
		this.mandatesDAO = container.getMandatesDAO();
		this.docTypeRelationDAO = container.getDocTypeRelationDAO();
		this.documentDAO = container.getPaclDocumentDAO();
		this.typesDAO = container.getTypesDAO();
		this.errorDescriptionsService = errorDescriptionsService;
		this.internalConfigService = internalConfigService;
		this.securityService = securityService;
		this.revisionService = revisionService;
	}

	public EntityNTT getEntityById(ServiceSupportEnv env, Long entityId, Boolean flSingleRelation, Boolean flHidden, Operation operation) {
		
		Boolean isAdmin = securityService.checkAdminPermission(env, operation);
		
		EntityNTT entityNTT = entityDAO.getEntityByID(env, entityId, env.getUser().getUserId(), booleanToInteger(flSingleRelation), booleanToInteger(flHidden), booleanToInteger(isAdmin));
		
		if(entityNTT == null) {
			throw new EntityNotFoundExecption(Status.NOT_FOUND, operation, ErrorField.ENTITY,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), entityId.toString());
		}

		return entityNTT;
	}

	public PartyWithEntityNTT getPartyWithEntityNTT(ServiceSupportEnv env, Long mandateId, Operation operation) {
		Boolean isAdmin = securityService.checkAdminPermission(env, operation);
		Integer includeLevels = internalConfigService.getIntegerValue(env.getTenantId(), InternalConfigKeys.HIERARCHICAL_INHERITANCE_LEVEL.getKey());
		Boolean inheritManagement = internalConfigService.getBooleanValue(env.getTenantId(), InternalConfigKeys.INHERIT_MANAGEMENT.getKey());

		PartyWithEntityNTT partyWithEntityNTT = mandatesDAO.getPartyWithEntityByMandateId(env, mandateId, booleanToInteger(isAdmin), includeLevels, 
				booleanToInteger(inheritManagement));
		if(partyWithEntityNTT == null) {
			throw new MandateNotFoundException(Status.BAD_REQUEST, operation, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}
		
		partyWithEntityNTT.setRevocable(checkIfRevocable(env, partyWithEntityNTT, operation));
		
		return partyWithEntityNTT;
	}
	
	public Boolean checkIfRevocable(ServiceSupportEnv env, PartyWithEntityNTT partyWithEntityNTT, Operation operation) {
		
		if(!MandateStatus.VALID.equals(partyWithEntityNTT.getStatus())) {
			return false;
		}
		
		String entitytypeCode = Optional.ofNullable(partyWithEntityNTT.getEntity().getEntity_type().getCode()).orElse(null);
		String partyTypeCode = Optional.ofNullable(partyWithEntityNTT.getParty_type().getCode()).orElse(null);
		RevokeDatesConfig config = Optional.ofNullable(internalConfigService.getValuesList(env.getTenantId(), RevokeDatesConfig.class, InternalConfigKeys.REVOKE_MANDATE_CONFIG.getKey()))
				.orElse(new ArrayList<>())
				.stream()
				.filter(c -> (StringUtils.isBlank(c.getEntityTypeCode()) || c.getEntityTypeCode().equals(entitytypeCode)) 
						&& (StringUtils.isBlank(c.getPartyTypeCode()) || c.getPartyTypeCode().equals(partyTypeCode)))
				.findFirst()
				.orElse(null);

		if(config == null) {
			return false;
		}

		if(config.getDayFrom().length() != 4 || config.getDayTo().length() != 4) {
			throw new InternalConfigException(Status.BAD_REQUEST, operation, ErrorField.CONFIG,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),InternalConfigKeys.REVOKE_MANDATE_CONFIG.getKey());
		}

		LocalDate referenceDate = env.getReferenceDate().toLocalDate();
		int currMonthDay = referenceDate.getMonthValue() * 100 + referenceDate.getDayOfMonth();

		int dayFrom = Integer.parseInt(config.getDayFrom());
		int dayTo = Integer.parseInt(config.getDayTo());

		return currMonthDay >= dayFrom 
				&& currMonthDay <= dayTo 
				&& isAdminByEntityType(env, env.getUser().getUserId(), partyWithEntityNTT.getEntity().getEntity_type().getId(), operation);
	}

	public AnomalyLevel getMaxLevel(ServiceSupportEnv env, InternalConfigKeys key, Operation operation) {
		String level = internalConfigService.getStringValue(env.getTenantId(), key.getKey());

		AnomalyLevel maxLevel;
		if(level != null) {
			try {
				maxLevel = AnomalyLevel.valueOf(level);
			} catch (Exception e) {
				throw new InternalConfigException(Status.NOT_FOUND, operation, ErrorField.CONFIG,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), InternalConfigKeys.MAX_ANOMALY_LEVEL_ALLOWED_EDIT_PARTY.getKey());
			}		
		} else {
			maxLevel = null;
		}

		return maxLevel;
	}
	
	public ServiceSupportEnv checkEnv (ServiceSupportEnv env) {
		
		if(env == null) {
			throw new InvalidRequestException(Status.BAD_REQUEST, Operation.REQUEST_API, ErrorField.ENV, 
					this.errorDescriptionsService.getTenantErrorDescriptions("master"), "en");
		}
		
		if(env.getReferenceDate() == null) {
			env.setReferenceDate(AbsoluteDate.of(getCurrentLocalDate()));
		}
		return env;
	}
	
	public LocalDate getCurrentLocalDate() {
		return entityDAO.getCurrentTimestamp().toLocalDate();
	}

	private Integer booleanToInteger(Boolean x) {
		return Boolean.TRUE.equals(x) ? 1 : 0;
	}
	
	public String getFormatedErrorMsg(String code, String description) {
		if(StringUtils.isBlank(code) && StringUtils.isBlank(description)) {
			return "";
		} else if(StringUtils.isBlank(code) && !StringUtils.isBlank(description)) {
			return description;
		} else if(!StringUtils.isBlank(code) && StringUtils.isBlank(description)) {
			return code;
		} 

		return String.format("(%s) %s", code, description);
	}
	
	public MandateStatus checkMandateStatus(ServiceSupportEnv env, EntityNTT entityNTT, PartyNTT partyNTT, List<Revision> revisionCodes) {
		
		Long entityTypeId = entityNTT.getEntity_type().getId();
		Long partyTypeId = partyNTT.getParty_type().getId();
		List<DocTypeRelationNTT> filteredRelationList = docTypeRelationDAO.getByEntityTypeIdPartyTypeIdAndScopeCode(env, entityTypeId, partyTypeId, DocTypeRelationScope.MANDATES).stream()
				.filter(rel -> rel.getRevisionCode() != null && (revisionCodes == null || revisionCodes.isEmpty() ||  revisionCodes.contains(rel.getRevisionCode())))
				.collect(Collectors.toList());
		
		MandateStatus status = MandateStatus.VALID;
		for (DocTypeRelationNTT rel : filteredRelationList) {			
			if(documentDAO.countByDefinitionCodeEntityIdAndMandateId(env.getTenantId(), DocTypeRelationScope.MANDATES, entityNTT.getEntity_id(), partyNTT.getMandate_id(), rel.getDefinitionCode()) < 1) {
					status = MandateStatus.NOT_VALID;
			}
		}
		
		return status;
	}

	public void updateMandatesStatus(ServiceSupportEnv env, Long entityTypeId, Long partyTypeId, Operation operation) {
		Boolean isAdmin = securityService.checkAdminPermission(env, operation);
		Integer includeLevels = internalConfigService.getIntegerValue(env.getTenantId(), InternalConfigKeys.HIERARCHICAL_INHERITANCE_LEVEL.getKey());
		Boolean inheritManagement = internalConfigService.getBooleanValue(env.getTenantId(), InternalConfigKeys.INHERIT_MANAGEMENT.getKey());

		List<PartyWithEntityNTT> mandatesList = mandatesDAO.getPartyByEntityTypeIdAndPartyTypeId(env, entityTypeId, partyTypeId, booleanToInteger(isAdmin),
				includeLevels, booleanToInteger(inheritManagement));

		mandatesList.stream()
		.filter(m -> !MandateStatus.CLOSED.equals(m.getStatus()))
		.forEach(mandate -> {
			List<Revision> revList = new ArrayList<>(Arrays.asList(Revision.ADD_MANDATE));
			if(!mandate.getDay_to().equals(INFINITE)) {
				revList.add(Revision.REMOVE_MANDATE);
			}

			MandateStatus newStatus = checkMandateStatus(env, mandate.getEntity(), mandate, revList);
			if(!newStatus.equals(mandate.getStatus())) {
				updateMandateStatus(env, mandate, newStatus, operation);
			}
		});
	}

	public void updateMandateStatus(ServiceSupportEnv e, PartyWithEntityNTT mandate, MandateStatus status, Operation operation) {
		ServiceSupportEnv env = checkEnv(e);
		
		if(MandateStatus.CLOSED.equals(status) || mandate.getStatus().equals(status)) {
			return;
		}
		
		if(Boolean.FALSE.equals(mandate.getEditable())) {
			throw new MandateNotEditableException(Status.BAD_REQUEST, operation, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		EntityNTT entityNTT = mandate.getEntity();

		String partyId = mandate.getParty_id();

		mandatesDAO.useTransaction(transaction -> {
			//remove old record
			mandatesDAO.outdateMandateFromEntity(env, mandate.getMandate_id(), Revision.UPDATE_MANDATE);
			UpdatedObjectDataNTT data = UpdatedObjectDataNTT.builder()
					.mandateId(mandate.getMandate_id())
					.partyTypeCode(mandate.getParty_type().getCode())
					.flManage(mandate.getParty_type().getFl_manage() == 1)
					.dayFrom(mandate.getDay_from())
					.dayTo(mandate.getDay_to())
					.build();

			//update revision history table
			revisionService.insertOperation(env, Revision.REMOVE_MANDATE, partyId, entityNTT.getPath(), null, data);

			mandate.setPkid(mandatesDAO.nextSequenceValEntitiesParties());
			mandate.setStatus(status);
			mandate.setRevision_code(Revision.UPDATE_MANDATE);

			mandatesDAO.addPartyToEntity(env, mandate);
			if(MandateStatus.VALID.equals(status)) {
				UpdatedObjectDataNTT updateData = UpdatedObjectDataNTT.builder()
						.mandateId(mandate.getMandate_id())	
						.partyTypeCode(mandate.getParty_type().getCode())
						.flManage(mandate.getParty_type().getFl_manage() == 1)
						.dayFrom(mandate.getDay_from())
						.dayTo(mandate.getDay_to())
						.build();
				revisionService.insertOperation(env, Revision.ADD_MANDATE, partyId, entityNTT.getPath(), null, updateData);
			}
		});
	}
	
	public InfiniteListResults<EntityNTT> getEntitiesByUserIdInfinite(ServiceSupportEnv env, String userId, Criteria criteria, 
			Boolean history, Boolean isAdmin, String nextKey, Integer pageSize){
		
		final Criteria finalCriteria;
		if(criteria == null) {
			finalCriteria = CriteriaBuilder.number("1").eq(1);
		} else {
			finalCriteria = criteria;
		}
		
		return mandatesDAO.infinite(() -> entityDAO.getAllEntitiesInfinite(env, userId, finalCriteria, booleanToInteger(history), booleanToInteger(isAdmin)),
				nextKey,
				pageSize);
	}
	
	public List<Long> getAdminEntitiesIdsByUserId(ServiceSupportEnv env, String userId, Criteria criteria,
			Boolean history, Boolean isAdmin){
		
		Integer includeLevels = internalConfigService.getIntegerValue(env.getTenantId(), InternalConfigKeys.HIERARCHICAL_INHERITANCE_LEVEL.getKey());
		
		return entityDAO.getAllAdminEntitiesIds(env, userId, criteria, booleanToInteger(history), booleanToInteger(isAdmin), includeLevels);
		
	}
	public List<EntityNTT> getEntitiesByUserIdList(ServiceSupportEnv env, String userId, Criteria criteria, 
			Boolean history, Boolean isAdmin){
		
		List<EntityNTT> result = new ArrayList<>();
		if(criteria == null) {
			criteria = CriteriaBuilder.number("1").eq(1);
		}
		String nextKey = null;
		do {
			InfiniteListResults<EntityNTT> infiniteListResult = getEntitiesByUserIdInfinite(env, userId, criteria, history, isAdmin, nextKey, 100);
			result.addAll(infiniteListResult.getRecords());
			nextKey = infiniteListResult.getNextKey();
		} while (nextKey != null);

		return result;
	}
	
	public boolean isAdminByEntityType(ServiceSupportEnv env, String userId, Long entityTypeId, Operation operation) {
		Boolean isAdmin = securityService.checkAdminPermission(env, operation);
		
		if(Boolean.TRUE.equals(isAdmin)) {
			return true;
		}
		
		List<Long> userEntitytypeIds = getEntitiesByUserIdList(env, userId, null, false, isAdmin).stream()
				.filter(e -> "ADMIN".equals(e.getCurrent_user_role()))
				.map(e -> e.getEntity_type().getId())
				.collect(Collectors.toSet())
				.stream()
				.collect(Collectors.toList());

		return userEntitytypeIds.contains(entityTypeId);
	}
	
	public PartyTypeNTT getPartyTypeNTTByCode(ServiceSupportEnv env, String partyTypeCode, Operation operation) {
		PartyTypeNTT partyTypeNTT = typesDAO.getPartyTypeByCode(env, partyTypeCode);

		if(partyTypeNTT == null) {
			throw new TypeNotFoundExecption(Status.NOT_FOUND, operation, ErrorField.TYPE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), partyTypeCode);
		}
		return partyTypeNTT;
	}
	
	public EntityTypeNTT getEntityTypeNTTByCode(ServiceSupportEnv env, String entityTypeCode, Operation operation) {
		EntityTypeNTT entityTypeNTT = typesDAO.getEntityTypeByCode(env, entityTypeCode);
		
		if(entityTypeNTT == null) {
			throw new TypeNotFoundExecption(Status.NOT_FOUND, operation, ErrorField.TYPE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), entityTypeCode);
		}
		return entityTypeNTT;
	}
	
	public void checkEntityPartyTypeCompatibility(ServiceSupportEnv env, PartyTypeNTT partyTypeNTT, EntityTypeNTT entityTypeNTT, 
			Operation operation) {
		Integer count = typesDAO.checkEntityPartyTypeLink(partyTypeNTT.getId(), entityTypeNTT.getId());
		if(count != 1) {
			throw new TypeNotCompatibleExecption(Status.CONFLICT, operation, ErrorField.TYPE_ID, 
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), 
					env.getLang(), 
					getFormatedErrorMsg(partyTypeNTT.getCode(), partyTypeNTT.getDescription()),
					getFormatedErrorMsg(entityTypeNTT.getCode(), entityTypeNTT.getDescription()));
		}
	}
}
