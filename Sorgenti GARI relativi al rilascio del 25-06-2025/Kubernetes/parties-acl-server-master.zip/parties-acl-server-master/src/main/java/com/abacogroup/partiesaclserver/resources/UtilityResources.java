package com.abacogroup.partiesaclserver.resources;

import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;

import com.abacogroup.partiesaclserver.PartiesACLServerApplication;
import com.abacogroup.partiesaclserver.core.models.ApiVersion;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.PermitAll;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;

@Path(ResourceConstants.API_PRIV + "/utility")
@Tag(name = "utility", description = "Utility Resources")
@PermitAll
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Slf4j
public class UtilityResources {

	@GET
	@Path("/api.version")
	@Operation(description = "Get the version of the server API")
			@ApiResponse(responseCode = "200", description = "Get the version of the server API", useReturnTypeSchema = true)
		public ApiVersion getApiVersion(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId) {

		String name = "...";
		String description = "...";
		String version = "...";
		String buildtime = "...";
		String commitId = "";

		try {
			Properties prop = new Properties();

			InputStream input = PartiesACLServerApplication.class.getResourceAsStream("/partiesACLServer.properties");
			prop.load(input);
			name = prop.getProperty("api.name");
			description = prop.getProperty("api.description");
			version = prop.getProperty("api.version");
			buildtime = prop.getProperty("api.buildtime");

		} catch (Exception ex) {
			log.warn("Error reading api version: ", ex);
		}

		try {
			Properties prop = new Properties();

			InputStream input = PartiesACLServerApplication.class.getResourceAsStream("/git.properties");
			prop.load(input);

			commitId = prop.getProperty("git.commit.id.abbrev");

		} catch (Exception ex) {
			log.warn("Error reading git properties: ", ex);
		}

		return ApiVersion.builder()
				.name("ABACO-" + name)
				.description(description)
				.version(version)
				.commitId(StringUtils.isNotBlank(commitId) ? commitId : StringUtils.EMPTY)
				.buildtime(buildtime)
				.build();
	}
	
}
