package com.abacogroup.partiesaclserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.db.ntt.DocTypeRelationNTT;
import com.abacogroup.partiesaclserver.resources.res.DocTypeRelation;

@Mapper
public interface DocTypeRelationMapper {
	
	DocTypeRelationMapper INSTANCE = Mappers.getMapper(DocTypeRelationMapper.class);
	
	@InheritInverseConfiguration()	
	@Mapping(target = "entityId", ignore =  true)
	@Mapping(target = "mandateId", ignore =  true)
	@Mapping(target = "flDocPresent", ignore =  true)
	@Mapping(target = "multiple", ignore =  true)
	@Mapping(source = "scopeCode", target = "scope")
	@Mapping(target = "summaryFieldDefinitions", ignore =  true)
	DocTypeRelation entityTODto(DocTypeRelationNTT entity);
}