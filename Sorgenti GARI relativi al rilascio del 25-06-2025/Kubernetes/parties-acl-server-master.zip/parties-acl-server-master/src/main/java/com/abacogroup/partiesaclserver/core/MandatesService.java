package com.abacogroup.partiesaclserver.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.criteria.CriteriaBuilder;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListStatementCustomizer;
import com.abacogroup.partiesaclserver.core.enums.AnomalyLevel;
import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.InternalConfigKeys;
import com.abacogroup.partiesaclserver.core.enums.MandateStatus;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.enums.Revision;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidEndDateException;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidPayloadException;
import com.abacogroup.partiesaclserver.core.exceptions.InvalidRequestException;
import com.abacogroup.partiesaclserver.core.exceptions.NothingToUpdateException;
import com.abacogroup.partiesaclserver.core.exceptions.PastDateNotallowedException;
import com.abacogroup.partiesaclserver.core.exceptions.ValidationDateException;
import com.abacogroup.partiesaclserver.core.exceptions.ValidationDatesConflictException;
import com.abacogroup.partiesaclserver.core.exceptions.documents.CloseMandateDocumentNotFoundException;
import com.abacogroup.partiesaclserver.core.exceptions.documents.ExtendMandateDocumentNotFoundException;
import com.abacogroup.partiesaclserver.core.exceptions.documents.RevokeMandateDocumentNotFoundException;
import com.abacogroup.partiesaclserver.core.exceptions.entity.EntityWithoutAdminExecption;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.ExclusivePartyException;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.MandateNotEditableException;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.PartyAnomalyException;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.PartyInEntityException;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.UserInEntityException;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.UserNotAssociatedWithEntityException;
import com.abacogroup.partiesaclserver.core.exceptions.mandate.UserNotAssociatedWithPartyException;
import com.abacogroup.partiesaclserver.core.exceptions.security.UserNotAllowedExecption;
import com.abacogroup.partiesaclserver.core.mappers.EntityMapper;
import com.abacogroup.partiesaclserver.core.mappers.MandatorUserMapper;
import com.abacogroup.partiesaclserver.core.mappers.PartyMapper;
import com.abacogroup.partiesaclserver.core.mappers.PartyWithEntityMapper;
import com.abacogroup.partiesaclserver.core.mappers.UserPartyAuthMapper;
import com.abacogroup.partiesaclserver.core.mappers.UserPartyMapper;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.EntityDAO;
import com.abacogroup.partiesaclserver.db.dao.MandatesDAO;
import com.abacogroup.partiesaclserver.db.ntt.EntityNTT;
import com.abacogroup.partiesaclserver.db.ntt.EntityTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.MandatorUserNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.PartyWithEntityNTT;
import com.abacogroup.partiesaclserver.db.ntt.UpdatedObjectDataNTT;
import com.abacogroup.partiesaclserver.resources.req.AddMandatorUserPayload;
import com.abacogroup.partiesaclserver.resources.req.AddPartyPayload;
import com.abacogroup.partiesaclserver.resources.req.CloseDatePayload;
import com.abacogroup.partiesaclserver.resources.req.PartyEntitySearchFilters;
import com.abacogroup.partiesaclserver.resources.req.UpdateEntityUserPayload;
import com.abacogroup.partiesaclserver.resources.res.Entity;
import com.abacogroup.partiesaclserver.resources.res.HasManageRes;
import com.abacogroup.partiesaclserver.resources.res.MandatorUser;
import com.abacogroup.partiesaclserver.resources.res.Party;
import com.abacogroup.partiesaclserver.resources.res.PartyWithEntity;
import com.abacogroup.partiesaclserver.resources.res.UserParty;
import com.abacogroup.partiesaclserver.resources.res.UserPartyAuth;

import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response.Status;

public class MandatesService {

	private MandatesDAO mandatesDAO;
	private EntityDAO entityDAO;
	private UtilityService utilityService;
	private RevisionService revisionService;
	private SecurityService securityService;
	private AnomaliesService anomaliesService;
	private InternalConfigService internalConfigService;
	private ErrorDescriptionsService errorDescriptionsService;

	private static final int DEFAULT_PAGE_SIZE = 10;
	private static final AbsoluteDate INFINITE = AbsoluteDate.of("99991231");

	private static final String HIDDEN_SINGLE_PARTY = "HIDDEN_SINGLE_PARTY";

	public MandatesService(DAOContainer daoContainer, SecurityService securityService, RevisionService revisionService,
			InternalConfigService internalConfigService, AnomaliesService anomaliesService,
			ErrorDescriptionsService errorDescriptionsService, UtilityService utilityService) {
		this.mandatesDAO = daoContainer.getMandatesDAO();
		this.entityDAO = daoContainer.getEntityDAO();
		this.revisionService = revisionService;
		this.securityService = securityService;
		this.internalConfigService = internalConfigService;
		this.errorDescriptionsService = errorDescriptionsService;
		this.anomaliesService = anomaliesService;
		this.utilityService = utilityService;
	}

	public Long addPartyToEntity(@NotNull ServiceSupportEnv e, Long entityId, AddPartyPayload payload) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		EntityNTT entityNTT = utilityService.getEntityById(env, entityId, false, false, Operation.ADD_MANDATE);

		// security check
		securityService.checkPermission(env, entityId, true, Operation.ADD_MANDATE, ErrorField.MANDATE);

		PartyTypeNTT partyTypeNTT = utilityService.getPartyTypeNTTByCode(env, payload.getPartyTypeCode(), Operation.ADD_MANDATE);

		utilityService.checkEntityPartyTypeCompatibility(env, partyTypeNTT, entityNTT.getEntity_type(), Operation.ADD_MANDATE);
		if (payload.getDayTo() == null) {
			payload.setDayTo(INFINITE);
		}

		if (partyTypeNTT.getFl_exclusive() == 1
				&& mandatesDAO.checkExclusiveParty(env.getTenantId(), entityId, payload.getId(), payload.getDayFrom(), payload.getDayTo()) != 0) {
			throw new ExclusivePartyException(Status.CONFLICT, Operation.ADD_MANDATE, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					utilityService.getFormatedErrorMsg(entityNTT.getCode(), entityNTT.getName()));
		}

		Boolean pastDateAllowed = internalConfigService.getBooleanValue(env.getTenantId(), InternalConfigKeys.ALLOW_PAST_DATE.getKey());
		if (Boolean.FALSE.equals(pastDateAllowed) && payload.getDayFrom().toLocalDate().isBefore(env.getReferenceDate().toLocalDate())) {
			throw new PastDateNotallowedException(Status.BAD_REQUEST, Operation.ADD_MANDATE, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		if ((entityNTT.getDay_from().toLocalDate().isAfter(payload.getDayFrom().toLocalDate()))
				|| entityNTT.getDay_to().toLocalDate().isBefore(payload.getDayFrom().toLocalDate())
				|| (!payload.getDayTo().equals(INFINITE) && entityNTT.getDay_to().toLocalDate().isBefore(payload.getDayTo().toLocalDate()))) {
			throw new ValidationDatesConflictException(Status.CONFLICT, Operation.ADD_MANDATE, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		if (mandatesDAO.checkPartyInEntity(env.getTenantId(), entityId, payload.getId(), payload.getDayFrom(), payload.getDayTo()) != 0) {
			throw new PartyInEntityException(Status.BAD_REQUEST, Operation.ADD_MANDATE, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					utilityService.getFormatedErrorMsg(entityNTT.getCode(), entityNTT.getName()));
		}

		Boolean pastDateCloseAllowed = internalConfigService.getBooleanValue(env.getTenantId(), InternalConfigKeys.ALLOW_PAST_CLOSE_DATE.getKey());
		if (Boolean.FALSE.equals(pastDateCloseAllowed) && payload.getDayTo().toLocalDate().isBefore(env.getReferenceDate().toLocalDate())) {
			throw new InvalidEndDateException(Status.BAD_REQUEST, Operation.ADD_MANDATE, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		if (payload.getDayFrom().toLocalDate().isAfter(payload.getDayTo().toLocalDate())
				|| payload.getDayFrom().toLocalDate().isEqual(payload.getDayTo().toLocalDate())) {
			throw new ValidationDateException(Status.BAD_REQUEST, Operation.ADD_MANDATE, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		Long mandateId = mandatesDAO.nextSequenceValMandateId();

		PartyNTT partyNTT = PartyNTT.builder()
				.pkid(mandatesDAO.nextSequenceValEntitiesParties())
				.mandate_id(mandateId)
				.day_from(payload.getDayFrom())
				.day_to(payload.getDayTo())
				.entity_id(entityId)
				.party_id(payload.getId())
				.party_type(partyTypeNTT)
				.status(MandateStatus.NOT_VALID)
				.revision_code(Revision.ADD_MANDATE)
				.build();

		MandateStatus status = utilityService.checkMandateStatus(env, entityNTT, partyNTT, List.of(Revision.ADD_MANDATE));
		partyNTT.setStatus(status);

		mandatesDAO.addPartyToEntity(env, partyNTT);

		if (partyNTT.getStatus().equals(MandateStatus.VALID)) {
			UpdatedObjectDataNTT data = UpdatedObjectDataNTT.builder()
					.mandateId(mandateId)
					.partyTypeCode(payload.getPartyTypeCode())
					.entityTypeCode(entityNTT.getEntity_type().getCode())
					.flManage(partyTypeNTT.getFl_manage() == 1)
					.dayFrom(partyNTT.getDay_from())
					.dayTo(partyNTT.getDay_to())
					.build();
			revisionService.insertOperation(env, Revision.ADD_MANDATE, partyNTT.getParty_id(), entityNTT.getPath(), null, data);
		}

		return mandateId;
	}

	private Long removeMandateFromEntityInternal(ServiceSupportEnv env, Long mandateId, PartyWithEntityNTT partyWithEntityNTT, Revision revision) {
		// anomalies check
		checkPartyAnomalies(env, partyWithEntityNTT.getParty_id(), Operation.REMOVE_MANDATE);

		mandatesDAO.outdateMandateFromEntity(env, mandateId, revision);

		UpdatedObjectDataNTT data = UpdatedObjectDataNTT.builder()
				.mandateId(mandateId)
				.partyTypeCode(partyWithEntityNTT.getParty_type().getCode())
				.entityTypeCode(partyWithEntityNTT.getEntity().getEntity_type().getCode())
				.flManage(partyWithEntityNTT.getParty_type().getFl_manage() == 1)
				.dayFrom(partyWithEntityNTT.getDay_from())
				.dayTo(partyWithEntityNTT.getDay_to())
				.build();

		// update revision history table
		revisionService.insertOperation(env, revision, partyWithEntityNTT.getParty_id(), partyWithEntityNTT.getEntity().getPath(), null, data);

		return mandateId;
	}

	public Boolean closeMandate(ServiceSupportEnv e, Long mandateId, CloseDatePayload payload) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		if (payload.getCloseDay() != null) {
			payload.setDayTo(AbsoluteDate.of(payload.getCloseDay().toLocalDate().minusDays(1)));
		}

		PartyWithEntityNTT partyWithEntityNTT = utilityService.getPartyWithEntityNTT(env, mandateId, Operation.REMOVE_MANDATE);

		EntityNTT entityNTT = partyWithEntityNTT.getEntity();

		if (payload.getDayTo() == null) {
			payload.setDayTo(INFINITE);
		}

		if (Boolean.TRUE.equals(payload.getRevoke())) {
			checkCanRevokeMandate(env, payload, partyWithEntityNTT, entityNTT);
		} else {
			// security check
			securityService.checkPermission(env, partyWithEntityNTT.getEntity().getEntity_id(), true, Operation.CLOSE_MANDATE, ErrorField.MANDATE);

			checkCanCloseOrExtendMandate(env, payload, partyWithEntityNTT, entityNTT);
			if (payload.getDayTo().toLocalDate().isBefore(partyWithEntityNTT.getDay_from().toLocalDate())) {
				return removeMandateFromEntityInternal(env, mandateId, partyWithEntityNTT, Revision.REMOVE_MANDATE).equals(mandateId);
			}
		}

		final Revision revisionCode;
		if (Boolean.TRUE.equals(payload.getRevoke())) {
			revisionCode = Revision.REVOKE_MANDATE;
		} else if (partyWithEntityNTT.getDay_to().toLocalDate().isBefore(payload.getDayTo().toLocalDate())) {
			revisionCode = Revision.EXTEND_MANDATE;
		} else {
			revisionCode = Revision.REMOVE_MANDATE;
		}

		mandatesDAO.useTransaction(dao -> {
			// remove old record
			mandatesDAO.outdateMandateFromEntity(env, mandateId, revisionCode);
			PartyNTT partyNTT = PartyNTT.builder()
					.pkid(mandatesDAO.nextSequenceValEntitiesParties())
					.mandate_id(partyWithEntityNTT.getMandate_id())
					.day_from(partyWithEntityNTT.getDay_from())
					.day_to(payload.getDayTo())
					.entity_id(partyWithEntityNTT.getEntity().getEntity_id())
					.party_id(partyWithEntityNTT.getParty_id())
					.party_type(partyWithEntityNTT.getParty_type())
					.status(partyWithEntityNTT.getStatus())
					.revision_code(revisionCode)
					.build();

			UpdatedObjectDataNTT updateData = UpdatedObjectDataNTT.builder()
					.mandateId(mandateId)
					.partyTypeCode(partyNTT.getParty_type().getCode())
					.entityTypeCode(entityNTT.getEntity_type().getCode())
					.flManage(partyNTT.getParty_type().getFl_manage() == 1)
					.dayFrom(partyNTT.getDay_from())
					.dayTo(payload.getDayTo())
					.build();

			mandatesDAO.addPartyToEntity(env, partyNTT);
			// update revision history table
			revisionService.insertOperation(env, Revision.UPDATE_MANDATE, partyNTT.getParty_id(), entityNTT.getPath(), null, updateData);
		});
		return true;
	}

	private void checkCanCloseOrExtendMandate(ServiceSupportEnv env, CloseDatePayload payload, PartyWithEntityNTT partyWithEntityNTT, EntityNTT entityNTT) {

		// close mandate
		if (partyWithEntityNTT.getDay_to().equals(INFINITE) || partyWithEntityNTT.getDay_to().toLocalDate().isAfter(payload.getDayTo().toLocalDate())) {
			if (!utilityService.checkMandateStatus(env, entityNTT, partyWithEntityNTT, List.of(Revision.REMOVE_MANDATE)).equals(MandateStatus.VALID)) {
				throw new CloseMandateDocumentNotFoundException(Status.BAD_REQUEST, Operation.CLOSE_MANDATE, ErrorField.DOCUMENT_ID,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
			}

			// anomalies check
			checkPartyAnomalies(env, partyWithEntityNTT.getParty_id(), Operation.CLOSE_MANDATE);
		}

		// extend mandate
		if (partyWithEntityNTT.getDay_to().toLocalDate().isBefore(payload.getDayTo().toLocalDate())
				&& !utilityService.checkMandateStatus(env, entityNTT, partyWithEntityNTT, List.of(Revision.EXTEND_MANDATE)).equals(MandateStatus.VALID)) {
			throw new ExtendMandateDocumentNotFoundException(Status.BAD_REQUEST, Operation.EXTEND_MANDATE, ErrorField.DOCUMENT_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		Boolean pastDateCloseAllowed = internalConfigService.getBooleanValue(env.getTenantId(), InternalConfigKeys.ALLOW_PAST_CLOSE_DATE.getKey());
		if (Boolean.FALSE.equals(pastDateCloseAllowed) && payload.getDayTo().toLocalDate().isBefore(env.getReferenceDate().toLocalDate().minusDays(1))) {
			throw new InvalidEndDateException(Status.BAD_REQUEST, Operation.UPDATE_MANDATE, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		if (entityNTT.getDay_to().toLocalDate().isBefore(payload.getDayTo().toLocalDate())) {
			throw new ValidationDatesConflictException(Status.CONFLICT, Operation.UPDATE_MANDATE, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		if (mandatesDAO.checkPartyInEntity(env.getTenantId(), entityNTT.getEntity_id(), partyWithEntityNTT.getParty_id(), partyWithEntityNTT.getDay_from(),
				payload.getDayTo()) != 1) {
			throw new InvalidEndDateException(Status.CONFLICT, Operation.UPDATE_MANDATE, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		if (partyWithEntityNTT.getParty_type().getFl_exclusive() == 1
				&& mandatesDAO.checkExclusiveParty(env.getTenantId(), entityNTT.getEntity_id(), partyWithEntityNTT.getParty_id(),
						partyWithEntityNTT.getDay_from(), payload.getDayTo()) != 0) {
			throw new ExclusivePartyException(Status.CONFLICT, Operation.UPDATE_MANDATE, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					utilityService.getFormatedErrorMsg(entityNTT.getCode(), entityNTT.getName()));
		}
	}

	private void checkCanRevokeMandate(ServiceSupportEnv env, CloseDatePayload payload, PartyWithEntityNTT partyWithEntityNTT, EntityNTT entityNTT) {
		if (Boolean.FALSE.equals(utilityService.checkIfRevocable(env, partyWithEntityNTT, Operation.REVOKE_MANDATE))) {
			throw new InvalidRequestException(Status.BAD_REQUEST, Operation.REVOKE_MANDATE, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		if (!utilityService.isAdminByEntityType(env, env.getUser().getUserId(), entityNTT.getEntity_type().getId(), Operation.REVOKE_MANDATE)) {
			throw new InvalidRequestException(Status.BAD_REQUEST, Operation.REVOKE_MANDATE, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		if (!utilityService.checkMandateStatus(env, entityNTT, partyWithEntityNTT, List.of(Revision.REVOKE_MANDATE)).equals(MandateStatus.VALID)) {
			throw new RevokeMandateDocumentNotFoundException(Status.BAD_REQUEST, Operation.REVOKE_MANDATE, ErrorField.DOCUMENT_ID,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		if (payload.getDayTo() == null) {
			throw new InvalidPayloadException(Status.BAD_REQUEST, Operation.REVOKE_MANDATE, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		if (partyWithEntityNTT.getDay_from().toLocalDate().isAfter(payload.getDayTo().toLocalDate())) {
			throw new ValidationDateException(Status.BAD_REQUEST, Operation.REVOKE_MANDATE, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}
	}

	public Boolean addUsersToEntity(ServiceSupportEnv e, Long entityId, AddMandatorUserPayload payload, Boolean flSinglerelation, Boolean flHidden) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		// security check
		securityService.checkPermission(env, entityId, true, Operation.ADD_USER, ErrorField.MANDATE);

		EntityNTT entityNTT = utilityService.getEntityById(env, entityId, flSinglerelation, flHidden, Operation.ADD_USER);

		String userId = securityService.getUserId(env, payload.getUsername(), Operation.ADD_USER);

		if (mandatesDAO.checkUserInEntity(env.getTenantId(), entityId, userId) != 0) {
			throw new UserInEntityException(Status.BAD_REQUEST, Operation.ADD_USER, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					payload.getUsername(),
					utilityService.getFormatedErrorMsg(entityNTT.getCode(), entityNTT.getName()));
		}

		MandatorUserNTT userNTT = MandatorUserNTT.builder()
				.pkid(mandatesDAO.nextSequenceValEntitiesUsers())
				.entity_id(entityId)
				.user_id(userId)
				.username(payload.getUsername())
				.role_code(payload.getRole())
				.description(payload.getDescription())
				.build();

		mandatesDAO.addUserToEntity(env, userNTT);

		// update revision history table
		UpdatedObjectDataNTT data = UpdatedObjectDataNTT.builder()
				.userRole(payload.getRole())
				.build();

		revisionService.insertOperation(env, Revision.ADD_USER, userNTT.getUser_id(), entityNTT.getPath(), null, data);

		return true;
	}

	public String removeUserFromEntity(ServiceSupportEnv e, Long entityId, String mandatorUserId, Boolean flSinglerelation, Boolean flHidden) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		EntityNTT entityNTT = utilityService.getEntityById(env, entityId, flSinglerelation, flHidden, Operation.REMOVE_USER);

		// check if user is associated with entity
		MandatorUserNTT entityUserNTT = mandatesDAO.getUserById(env.getTenantId(), entityId, mandatorUserId, booleanToInteger(flSinglerelation),
				booleanToInteger(flHidden));

		if (entityUserNTT == null) {
			throw new UserNotAssociatedWithEntityException(Status.BAD_REQUEST, Operation.REMOVE_USER, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					mandatorUserId, utilityService.getFormatedErrorMsg(entityNTT.getCode(), entityNTT.getName()));
		}

		// security check
		securityService.checkPermission(env, entityId, true, Operation.REMOVE_USER, ErrorField.MANDATE);

		if (entityUserNTT.getUser_id().equals(env.getUser().getUserId())) {
			throw new UserNotAllowedExecption(Status.BAD_REQUEST, Operation.REMOVE_USER, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), env.getUser().getName());
		}

		mandatesDAO.outdateUserFromEntity(env, entityId, mandatorUserId);

		// update revision history table
		UpdatedObjectDataNTT data = UpdatedObjectDataNTT.builder()
				.userRole(entityUserNTT.getRole_code())
				.build();
		revisionService.insertOperation(env, Revision.REMOVE_USER, mandatorUserId, entityNTT.getPath(), null, data);

		return mandatorUserId;
	}

	public Boolean updateEntityUser(ServiceSupportEnv e, Long entityId, String mandatorUserId, UpdateEntityUserPayload payload, Boolean flSinglerelation,
			Boolean flHidden) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		if (payload.getRole() == null && payload.getDescription() == null) {
			throw new InvalidPayloadException(Status.BAD_REQUEST, Operation.UPDATE_USER, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		EntityNTT entityNTT = utilityService.getEntityById(env, entityId, false, false, Operation.UPDATE_USER);

		MandatorUserNTT oldEntityUserNTT = mandatesDAO.getUserById(env.getTenantId(), entityId, mandatorUserId, booleanToInteger(flSinglerelation),
				booleanToInteger(flHidden));

		if (oldEntityUserNTT == null) {
			throw new UserNotAssociatedWithEntityException(Status.BAD_REQUEST, Operation.UPDATE_USER, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					mandatorUserId, utilityService.getFormatedErrorMsg(entityNTT.getCode(), entityNTT.getName()));
		}

		// security check
		securityService.checkPermission(env, entityId, true, Operation.UPDATE_USER, ErrorField.MANDATE);

		String newRole = payload.getRole() != null ? payload.getRole() : oldEntityUserNTT.getRole_code();
		String newDescription = payload.getDescription() != null ? payload.getDescription() : oldEntityUserNTT.getDescription();

		if (payload.getRole() != null
				&& !payload.getRole().equals("ADMIN")
				&& oldEntityUserNTT.getRole_code().equals("ADMIN")
				&& env.getUser().getUserId().equals(mandatorUserId)) {

			throw new EntityWithoutAdminExecption(Status.BAD_REQUEST, Operation.UPDATE_USER, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					utilityService.getFormatedErrorMsg(entityNTT.getCode(), entityNTT.getName()));
		}

		if (oldEntityUserNTT.getRole_code().equals(newRole) && Objects.equals(oldEntityUserNTT.getDescription(), payload.getDescription())) {
			throw new NothingToUpdateException(Status.BAD_REQUEST, Operation.UPDATE_USER, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		mandatesDAO.useTransaction(transaction -> {
			mandatesDAO.outdateUserFromEntity(env, entityId, mandatorUserId);

			// update revision history table
			UpdatedObjectDataNTT data = UpdatedObjectDataNTT.builder()
					.userRole(oldEntityUserNTT.getRole_code())
					.build();
			revisionService.insertOperation(env, Revision.REMOVE_USER, mandatorUserId, entityNTT.getPath(), null, data);

			MandatorUserNTT userNTT = MandatorUserNTT.builder()
					.pkid(mandatesDAO.nextSequenceValEntitiesUsers())
					.entity_id(entityId)
					.user_id(mandatorUserId)
					.username(oldEntityUserNTT.getUsername())
					.role_code(newRole)
					.description(newDescription)
					.build();

			mandatesDAO.addUserToEntity(env, userNTT);

			// update revision history table
			UpdatedObjectDataNTT updateData = UpdatedObjectDataNTT.builder()
					.userRole(newRole)
					.build();

			revisionService.insertOperation(env, Revision.ADD_USER, userNTT.getUser_id(), entityNTT.getPath(), null, updateData);
		});

		return true;
	}

	public Boolean addUserToSingleParty(ServiceSupportEnv e, String partyId, AddMandatorUserPayload payload) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		// check if single party entity exists
		Long entityId = mandatesDAO.getSinglePartyEntityId(env.getTenantId(), partyId);

		if (entityId == null) {

			if (Boolean.FALSE.equals(securityService.checkAdminPermission(env, Operation.ADD_USER))) {
				throw new UserNotAllowedExecption(Status.FORBIDDEN, Operation.ADD_USER, ErrorField.MANDATE,
						this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), env.getUser().getName());
			}

			EntityTypeNTT entityTypeNTT = utilityService.getEntityTypeNTTByCode(env, HIDDEN_SINGLE_PARTY, Operation.ADD_USER);
			PartyTypeNTT partyTypeNTT = utilityService.getPartyTypeNTTByCode(env, HIDDEN_SINGLE_PARTY, Operation.ADD_USER);

			entityId = entityDAO.nextSequenceValEntityId();
			EntityNTT entityNTT = EntityNTT.builder()
					.pkid(entityDAO.nextSequenceValEntityDetailsId())
					.entity_id(entityId)
					.day_from(AbsoluteDate.of(utilityService.getCurrentLocalDate()))
					.day_to(INFINITE)
					.code(null)
					.name("PARTY_ID: " + partyId)
					.entity_type(entityTypeNTT)
					.registry_party_id(partyId)
					.description(partyId)
					.parent_id(null)
					.path("/" + entityId + "/")
					.build();

			entityDAO.insertEntity(entityId, env.getTenantId());
			entityDAO.insertEntityDetails(entityNTT, env.getUser().getUserId());

			Long mandateId = mandatesDAO.nextSequenceValMandateId();

			PartyNTT partyNTT = PartyNTT.builder()
					.pkid(mandatesDAO.nextSequenceValEntitiesParties())
					.mandate_id(mandateId)
					.day_from(AbsoluteDate.of(utilityService.getCurrentLocalDate()))
					.day_to(INFINITE)
					.entity_id(entityId)
					.party_id(partyId)
					.party_type(partyTypeNTT)
					.revision_code(Revision.ADD_MANDATE)
					.status(MandateStatus.VALID) // TODO(omar) is this ok or do we need to apply some logic?
					.build();

			mandatesDAO.addPartyToEntity(env, partyNTT);

			UpdatedObjectDataNTT data = UpdatedObjectDataNTT.builder()
					.mandateId(mandateId)
					.partyTypeCode(partyTypeNTT.getCode())
					.flManage(partyTypeNTT.getFl_manage() == 1)
					.dayFrom(partyNTT.getDay_from())
					.dayTo(partyNTT.getDay_to())
					.build();

			revisionService.insertOperation(env, Revision.ADD_MANDATE, partyNTT.getParty_id(), entityNTT.getPath(), null, data);

		}

		return addUsersToEntity(env, entityId, payload, true, true);
	}

	public String removeUserFromSingleParty(ServiceSupportEnv e, String partyId, String mandatorUserId) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		// check if single party entity exists
		Long entityId = mandatesDAO.getSinglePartyEntityId(env.getTenantId(), partyId);

		if (entityId == null) {
			throw new UserNotAssociatedWithPartyException(Status.BAD_REQUEST, Operation.ADD_USER, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), mandatorUserId);
		}

		return removeUserFromEntity(env, entityId, mandatorUserId, true, true);
	}

	public Boolean updateSinglePartyUser(ServiceSupportEnv e, String partyId, String mandatorUserId, UpdateEntityUserPayload payload) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		// check if single party entity exists
		Long entityId = mandatesDAO.getSinglePartyEntityId(env.getTenantId(), partyId);

		if (entityId == null) {
			throw new UserNotAssociatedWithPartyException(Status.BAD_REQUEST, Operation.ADD_USER, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), mandatorUserId);
		}

		return updateEntityUser(env, entityId, mandatorUserId, payload, true, true);
	}

	public InfiniteListResults<UserParty> getAllPartiesByUserId(ServiceSupportEnv e, String mandatorUserId, String partyId, List<MandateStatus> status,
			String nextKey) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		// TODO permessi????
		Boolean isAdmin = securityService.checkAdminPermission(env, Operation.GET_PARTY);
		Integer includeLevels = internalConfigService.getIntegerValue(env.getTenantId(), InternalConfigKeys.HIERARCHICAL_INHERITANCE_LEVEL.getKey());
		Boolean inheritManagement = internalConfigService.getBooleanValue(env.getTenantId(), InternalConfigKeys.INHERIT_MANAGEMENT.getKey());

		InfiniteListResults<UserParty> list = this.mandatesDAO.infinite(() -> mandatesDAO.getAllPartiesByUserId(env, mandatorUserId, partyId,
				booleanToInteger(isAdmin), includeLevels, booleanToInteger(inheritManagement), status),
				nextKey,
				DEFAULT_PAGE_SIZE)
				.map(UserPartyMapper.INSTANCE::entityTODto);

		if (partyId != null && list.getRecords().isEmpty()) {
			throw new UserNotAllowedExecption(Status.BAD_REQUEST, Operation.GET_PARTY, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), mandatorUserId);
		}

		return list;
	}

	public InfiniteListResults<MandatorUser> getAllUsersByEntityId(ServiceSupportEnv e, Long entityId, String usernameFilter, String nextKey) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		securityService.checkPermission(env, entityId, false, Operation.GET_USER, ErrorField.MANDATE);
		return this.mandatesDAO.infinite(() -> mandatesDAO.getAllUsersByEntityId(env, entityId, usernameFilter),
				nextKey,
				DEFAULT_PAGE_SIZE)
				.map(MandatorUserMapper.INSTANCE::entityTODto);
	}

	public MandatorUser getUserByEntityId(ServiceSupportEnv e, Long entityId, String userId) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		securityService.checkPermission(env, entityId, false, Operation.GET_USER, ErrorField.MANDATE);
		MandatorUserNTT userNTT = mandatesDAO.getUserById(env.getTenantId(), entityId, userId, 0, 0);
		EntityNTT entityNTT = utilityService.getEntityById(env, entityId, false, false, Operation.GET_USER);
		if (userNTT == null) {
			throw new UserNotAssociatedWithEntityException(Status.BAD_REQUEST, Operation.GET_USER, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(),
					userId, utilityService.getFormatedErrorMsg(entityNTT.getCode(), entityNTT.getName()));
		}

		return MandatorUserMapper.INSTANCE.entityTODto(userNTT);

	}

	public InfiniteListResults<Party> getAllPartiesByEntityId(ServiceSupportEnv e, Long entityId, Boolean history, Boolean includeChildren,
			List<MandateStatus> status, String nextKey) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		securityService.checkPermission(env, entityId, false, Operation.GET_PARTY, ErrorField.MANDATE);

		Integer includeLevels = Boolean.TRUE.equals(includeChildren)
				? internalConfigService.getIntegerValue(env.getTenantId(), InternalConfigKeys.HIERARCHICAL_INHERITANCE_LEVEL.getKey())
				: 0;
		Boolean inheritManagement = internalConfigService.getBooleanValue(env.getTenantId(), InternalConfigKeys.INHERIT_MANAGEMENT.getKey());

		return this.mandatesDAO.infinite(() -> mandatesDAO.getAllPartiesIdByEntityId(env, entityId, booleanToInteger(history), includeLevels,
				booleanToInteger(inheritManagement), status),
				nextKey,
				DEFAULT_PAGE_SIZE)
				.map(PartyMapper.INSTANCE::entityTODto);
	}

	public InfiniteListResults<PartyWithEntity> getAllEntitiesByPartyId(final ServiceSupportEnv env, String partyId, PartyEntitySearchFilters filters,
			List<MandateStatus> status, String nextKey) {
		utilityService.checkEnv(env);

		// TODO withManage = -1 isAdmin it should be fixed??
		if (null == filters.getWithManage()) {
			filters.setWithManage(1);
		}
		Boolean isAdmin = filters.getWithManage() == -1 || securityService.checkAdminPermission(env, Operation.GET_PARTY);

		Integer includeLevels = internalConfigService.getIntegerValue(env.getTenantId(), InternalConfigKeys.HIERARCHICAL_INHERITANCE_LEVEL.getKey());
		Boolean inheritManagement = internalConfigService.getBooleanValue(env.getTenantId(), InternalConfigKeys.INHERIT_MANAGEMENT.getKey());

		Criteria criteria = getCriteria(env, partyId, filters, status);

		return this.mandatesDAO
				.infinite(
						() -> mandatesDAO.getAllEntitiesByPartyId(env, booleanToInteger(isAdmin), includeLevels, booleanToInteger(inheritManagement), criteria),
						nextKey,
						DEFAULT_PAGE_SIZE)
				.map(p -> {
					p.setRevocable(utilityService.checkIfRevocable(env, p, Operation.GET_PARTY));
					return p;
				})
				.map(PartyWithEntityMapper.INSTANCE::entityTODto);
	}

	private Criteria getCriteria(ServiceSupportEnv env, String partyId, PartyEntitySearchFilters filters, List<MandateStatus> status) {

		if ((filters.getMinDate() != null && filters.getMaxDate() == null)
				|| (filters.getMinDate() == null && filters.getMaxDate() != null)) {
			throw new InvalidPayloadException(Status.BAD_REQUEST, Operation.GET_ENTITY, ErrorField.VALIDATION_DATES,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		List<Criteria> criteriaList = new ArrayList<>();

		Optional.ofNullable(filters.getEntityTypeCode())
				.map(typeCode -> utilityService.getEntityTypeNTTByCode(env, typeCode, Operation.GET_ENTITY))
				.map(entityTypeNTT -> CriteriaBuilder.number("pet.id").eq(entityTypeNTT.getId()))
				.ifPresent(criteriaList::add);

		criteriaList.add(CriteriaBuilder.string("pep.tenant_id").eq(env.getTenantId()));
		criteriaList.add(CriteriaBuilder.string("pep.party_id").eq(partyId));
		criteriaList.add(CriteriaBuilder.number("pet.fl_hidden").eq(0));

		if (status != null) {
			List<String> statusList = status.stream().map(Object::toString).collect(Collectors.toList());
			criteriaList.add(CriteriaBuilder.string("pep.status").in(statusList));
		}

		if (filters.getMinDate() != null) {
			String minDate = filters.getMinDate().toString();
			String maxDate = filters.getMaxDate().toString();
			Criteria minDateCriteria = CriteriaBuilder.and(CriteriaBuilder.string("pep.day_to").ge(minDate),
					CriteriaBuilder.string("ped.day_to").ge(minDate));
			Criteria maxDateCriteria = CriteriaBuilder.and(CriteriaBuilder.string("pep.day_from").le(maxDate),
					CriteriaBuilder.string("ped.day_from").le(maxDate));

			criteriaList.add(CriteriaBuilder.or(minDateCriteria, maxDateCriteria));
		} else {
			if (Boolean.FALSE.equals(filters.getHistory())) {
				criteriaList.add(CriteriaBuilder.string("pep.day_to").ge(env.getReferenceDate().toString()));
				criteriaList.add(CriteriaBuilder.string("ped.day_to").ge(env.getReferenceDate().toString()));
			} else {
				List<Criteria> list = new ArrayList<>();
				list.add(CriteriaBuilder.string("pep.day_to").lt(env.getReferenceDate().toString()));
				list.add(CriteriaBuilder.string("ped.day_to").lt(env.getReferenceDate().toString()));
				criteriaList.add(CriteriaBuilder.or(list.toArray(new Criteria[0])));
			}
		}

		if (Boolean.TRUE.equals(filters.getOnlyExclusive())) {
			criteriaList.add(CriteriaBuilder.number("ppt.fl_exclusive").eq(1));
		}

		return CriteriaBuilder.and(criteriaList.toArray(new Criteria[0]));
	}

	public PartyWithEntity getEntityByMandateId(ServiceSupportEnv e, Long mandateId) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		PartyWithEntityNTT partyWithEntityNTT = utilityService.getPartyWithEntityNTT(env, mandateId, Operation.GET_PARTY);

		return PartyWithEntityMapper.INSTANCE.entityTODto(partyWithEntityNTT);
	}

	public InfiniteListResults<Entity> getEntitiesByUserId(ServiceSupportEnv e, String userId, Boolean history, String nextKey) {
		ServiceSupportEnv env = utilityService.checkEnv(e);
		return utilityService.getEntitiesByUserIdInfinite(env, userId, null, history, false, nextKey, DEFAULT_PAGE_SIZE)
				.map(EntityMapper.INSTANCE::entityTODto);
	}

	public void updateMandateStatus(ServiceSupportEnv e, Long mandateId, MandateStatus status) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		PartyWithEntityNTT partyWithEntityNTT = utilityService.getPartyWithEntityNTT(env, mandateId, Operation.UPDATE_MANDATE);

		if (Boolean.FALSE.equals(partyWithEntityNTT.getEditable())) {
			throw new MandateNotEditableException(Status.BAD_REQUEST, Operation.UPDATE_MANDATE, ErrorField.MANDATE,
					this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang());
		}

		if (partyWithEntityNTT.getStatus().equals(status)) {
			return;
		}

		EntityNTT entityNTT = partyWithEntityNTT.getEntity();

		// security check
		securityService.checkPermission(env, entityNTT.getEntity_id(), true, Operation.UPDATE_MANDATE, ErrorField.MANDATE);

		String partyId = partyWithEntityNTT.getParty_id();

		mandatesDAO.useTransaction(transaction -> {
			// remove old record
			mandatesDAO.outdateMandateFromEntity(env, mandateId, Revision.UPDATE_MANDATE);
			UpdatedObjectDataNTT data = UpdatedObjectDataNTT.builder()
					.mandateId(mandateId)
					.partyTypeCode(partyWithEntityNTT.getParty_type().getCode())
					.flManage(partyWithEntityNTT.getParty_type().getFl_manage() == 1)
					.dayFrom(partyWithEntityNTT.getDay_from())
					.dayTo(partyWithEntityNTT.getDay_to())
					.build();

			// update revision history table
			revisionService.insertOperation(env, Revision.REMOVE_MANDATE, partyId, entityNTT.getPath(), null, data);

			partyWithEntityNTT.setPkid(mandatesDAO.nextSequenceValEntitiesParties());
			partyWithEntityNTT.setStatus(status);
			partyWithEntityNTT.setRevision_code(Revision.UPDATE_MANDATE);

			UpdatedObjectDataNTT updateData = UpdatedObjectDataNTT.builder()
					.mandateId(partyWithEntityNTT.getMandate_id())
					.partyTypeCode(partyWithEntityNTT.getParty_type().getCode())
					.flManage(partyWithEntityNTT.getParty_type().getFl_manage() == 1)
					.dayFrom(partyWithEntityNTT.getDay_from())
					.dayTo(partyWithEntityNTT.getDay_to())
					.build();
			mandatesDAO.addPartyToEntity(env, partyWithEntityNTT);
			revisionService.insertOperation(env, Revision.ADD_MANDATE, partyId, entityNTT.getPath(), null, updateData);

		});
	}

	private void checkPartyAnomalies(ServiceSupportEnv e, String partyId, Operation operation) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		Boolean checkAnomalies = internalConfigService.getBooleanValue(env.getTenantId(), InternalConfigKeys.EXTERNAL_CHECK_BEFORE_CLOSE.getKey());

		if (Boolean.FALSE.equals(checkAnomalies)) {
			return;
		}
		// anomalies check
		final AnomalyLevel maxLevel = utilityService.getMaxLevel(env, InternalConfigKeys.MAX_ANOMALY_LEVEL_ALLOWED_EDIT_PARTY, operation);

		if (maxLevel != null) {
			anomaliesService.getPartyAnomalies(env, partyId).getAnomalies_list()
					.stream()
					.filter(a -> a.getType().getLevel().ordinal() > maxLevel.ordinal())
					.findAny()
					.ifPresent(a -> {
						throw new PartyAnomalyException(Status.BAD_REQUEST, operation, ErrorField.MANDATE,
								this.errorDescriptionsService.getTenantErrorDescriptions(env.getTenantId()), env.getLang(), maxLevel.name());
					});
		}
	}

	private Integer booleanToInteger(Boolean x) {
		return Boolean.TRUE.equals(x) ? 1 : 0;
	}

	public HasManageRes hasManage(ServiceSupportEnv env, String partyId) {
		env = utilityService.checkEnv(env);
		Boolean checkManage = mandatesDAO.hasManage(env, partyId);
		return new HasManageRes(Boolean.TRUE.equals(checkManage != null && checkManage));
	}

	public UserPartyAuth getAuthorizations(ServiceSupportEnv env, String partyId) {
		env = utilityService.checkEnv(env);
		return UserPartyAuthMapper.INSTANCE.entityTODto(mandatesDAO.findPermissionByUserAndParty(env, partyId));

	}

	public Long removeMandateFromEntity(ServiceSupportEnv e, Long mandateId) {
		ServiceSupportEnv env = utilityService.checkEnv(e);

		PartyWithEntityNTT partyWithEntityNTT = utilityService.getPartyWithEntityNTT(env, mandateId, Operation.REMOVE_MANDATE);

		// security check
		securityService.checkPermission(env, partyWithEntityNTT.getEntity().getEntity_id(), true, Operation.REMOVE_MANDATE, ErrorField.MANDATE);

		return removeMandateFromEntityInternal(env, mandateId, partyWithEntityNTT, Revision.REMOVE_MANDATE);
	}

}
