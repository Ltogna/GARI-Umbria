package com.abacogroup.partiesaclserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.db.ntt.PartyTypeNTT;
import com.abacogroup.partiesaclserver.resources.res.PartyType;

@Mapper
public interface PartyTypeMapper {
	
	PartyTypeMapper INSTANCE = Mappers.getMapper(PartyTypeMapper.class);
	
	@InheritInverseConfiguration()
	@Mapping(target = "flExclusive", expression = "java(entity.getFl_exclusive() == 1)")
    @Mapping(target = "flManage", expression = "java(entity.getFl_manage() == 1)")
	PartyType entityTODto(PartyTypeNTT entity);
	
	@Mapping(target = "fl_exclusive", expression = "java(dto.getFlExclusive() ? 1 : 0)")
    @Mapping(target = "fl_manage", expression = "java(dto.getFlManage() ? 1 : 0)")
	PartyTypeNTT dtoToEntity(PartyType dto);
	
}
