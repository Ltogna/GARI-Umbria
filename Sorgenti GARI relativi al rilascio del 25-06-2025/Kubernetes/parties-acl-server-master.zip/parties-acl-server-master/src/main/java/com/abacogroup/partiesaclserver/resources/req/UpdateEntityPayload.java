package com.abacogroup.partiesaclserver.resources.req;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class UpdateEntityPayload {	
	@Schema(description = "End validity date - format YYYYMMDD", type = "string", format = "YYYYMMDD")
	private AbsoluteDate dayTo;
	
	@Schema(description = "Description of the entity", type = "string")
	private String description;
	
	@Schema(description = "Code of Entity type", type = "string")
	private String entityTypeCode;

	@Schema(description = "registry party id", type = "string")
	private String registryPartyId;
	
	@Schema(description = "Code of Entity", type = "string")
	private String code;
	
	@Schema(description = "Entity's name", type = "string")
	private String name;
	
	
	public Boolean isEmpty() {
		return this.description == null && this.entityTypeCode == null && this.registryPartyId == null
				&& this.dayTo == null && this.code == null && this.name == null;
	}
}
