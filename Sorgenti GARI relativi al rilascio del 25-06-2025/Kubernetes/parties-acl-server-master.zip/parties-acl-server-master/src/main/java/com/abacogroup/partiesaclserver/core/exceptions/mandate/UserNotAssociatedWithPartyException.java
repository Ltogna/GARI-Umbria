package com.abacogroup.partiesaclserver.core.exceptions.mandate;

import java.util.Map;

import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractException;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UserNotAssociatedWithPartyException extends AbstractException{

	private static final long serialVersionUID = 4723230731377004051L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.USER_NOT_ASSOCIATED_WITH_PARTY;

	public UserNotAssociatedWithPartyException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang, String user) {
		super(code, new UserNotAssociatedWithPartyExecptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
		
		String msg = String.format(this.getBody().getMessage(), user);
		this.getBody().setMessage(msg);
		log.error(this.getBody().getLogErrorMessage());
	}

	@Schema(description = "User id not associated with given Party id")
	public static class UserNotAssociatedWithPartyExecptionBody extends AbstractExceptionBody {

		private static final long serialVersionUID = -2393938688163350093L;

		public UserNotAssociatedWithPartyExecptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
