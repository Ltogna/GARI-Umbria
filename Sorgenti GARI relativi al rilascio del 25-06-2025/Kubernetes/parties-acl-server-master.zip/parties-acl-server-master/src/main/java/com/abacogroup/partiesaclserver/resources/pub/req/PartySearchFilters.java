package com.abacogroup.partiesaclserver.resources.pub.req;

import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PartySearchFilters {

	@QueryParam("code")
	private String code;

	@QueryParam("fullName")
	private String fullName;

}
