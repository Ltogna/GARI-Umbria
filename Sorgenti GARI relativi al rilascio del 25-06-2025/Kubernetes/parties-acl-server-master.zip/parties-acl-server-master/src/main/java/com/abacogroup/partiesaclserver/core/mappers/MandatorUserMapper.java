package com.abacogroup.partiesaclserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.db.ntt.MandatorUserNTT;
import com.abacogroup.partiesaclserver.resources.res.MandatorUser;

@Mapper
public interface MandatorUserMapper {
	
	MandatorUserMapper INSTANCE = Mappers.getMapper(MandatorUserMapper.class);
	
	@InheritInverseConfiguration()
	@Mapping(source = "user_id", target = "id")
	@Mapping(source = "role_code", target = "role")
	@Mapping(source = "description", target = "description")
	MandatorUser entityTODto(MandatorUserNTT userNTT);
	
	@Mapping(source = "id", target = "user_id")
	@Mapping(source = "role", target = "role_code")
	@Mapping(source = "description", target = "description")
	@Mapping(target = "pkid", ignore = true)
	@Mapping(target = "entity_id", ignore = true)
	MandatorUserNTT dtoToEntity(MandatorUser dto);
	
}
