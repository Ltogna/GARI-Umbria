package com.abacogroup.partiesaclserver.core.exceptions.entity;

import java.util.Map;

import jakarta.ws.rs.core.Response.Status;

import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractException;
import com.abacogroup.partiesaclserver.core.exceptions.AbstractExceptionBody;
import com.abacogroup.partiesaclserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class InvalidPartyNameException extends AbstractException {

	private static final long serialVersionUID = -6829106613358855577L;
	
	private static final ErrorCode ERROR_CODE = ErrorCode.INVALID_PARTY_NAME;

	public InvalidPartyNameException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang, String errorCode) {
		super(code, new InvalidPartyNameExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
		
		if(errorCode != null && !errorCode.isBlank()) {
			log.error(errorCode);
		} else {
			log.error(this.getBody().getLogErrorMessage());
		}
	}

	@Schema(description = "Can not retrieve party name")
	public static class InvalidPartyNameExceptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = -6196402541546172600L;

		public InvalidPartyNameExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
