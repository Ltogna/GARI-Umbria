package com.abacogroup.partiesaclserver.core;

import com.abacogroup.embeddedqueue.AbstractWorkQueue;
import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.abacogroup.partiesaclserver.core.enums.Revision;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.RevisionHistoryDAO;
import com.abacogroup.partiesaclserver.db.ntt.RevisionHistoryNTT;
import com.abacogroup.partiesaclserver.db.ntt.UpdatedObjectDataNTT;
import com.abacogroup.partiesaclserver.dispatch.payload.UpdatePACLPayload;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RevisionService {

	private RevisionHistoryDAO revisionHistoryDAO;
	private AbstractWorkQueue<UpdatePACLPayload, ?> updateMessageQueue;
	private final ObjectMapper objectMapper;

	public RevisionService(DAOContainer container, AbstractWorkQueue<UpdatePACLPayload, ?> updateMessageQueue) {
		this.revisionHistoryDAO = container.getRevisionHistoryDAO();
		this.updateMessageQueue = updateMessageQueue;
		this.objectMapper = new ObjectMapper();
	}

	public void insertOperation(ServiceSupportEnv env, Revision operation, String object_id, String old_path, String new_path,
			UpdatedObjectDataNTT data) {
		RevisionHistoryNTT revisionRow;
		try {
			revisionRow = RevisionHistoryNTT.builder()
					.pkid(revisionHistoryDAO.nextSequenceVal())
					.tenant_id(env.getTenantId())
					.operation(operation.getExtRevisionCode())
					.object_id(object_id)
					.old_path(old_path)
					.new_path(new_path)
					.object_data(objectMapper.writeValueAsString(data))
					.revision_date(AbsoluteDate.of(revisionHistoryDAO.getCurrentTimestamp()))
					.build();

			revisionHistoryDAO.insertOperation(revisionRow);

			//public notification via rabbitMq
			enqueueUpdateMessage(env, revisionRow);

		} catch (JsonProcessingException e) {
			log.error(e.getLocalizedMessage());
		}
	}

	private void enqueueUpdateMessage(ServiceSupportEnv env, RevisionHistoryNTT revisionRow) {
		log.info("Sending rabbitMQ notification {}", revisionRow);
		if (updateMessageQueue != null && env != null && revisionRow != null) {
			updateMessageQueue.add(UpdatePACLPayload.builder().tenantId(env.getTenantId()).dtOperation(revisionHistoryDAO.getCurrentTimestamp()).lastKey(revisionRow.getPkid()).notes(revisionRow.getOperation()).build(), System.currentTimeMillis());
		}
	}

}
