package com.abacogroup.partiesaclserver.core.exceptions;

import java.util.Map;

import jakarta.ws.rs.core.Response.Status;

import com.abacogroup.partiesaclserver.core.enums.ErrorField;
import com.abacogroup.partiesaclserver.core.enums.Operation;
import com.abacogroup.partiesaclserver.core.exceptions.enums.ErrorCode;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ValidationDateException extends AbstractException {

	private static final long serialVersionUID = 8316497686965964901L;

	private static final ErrorCode ERROR_CODE = ErrorCode.VALIDATION_DATE_ERROR;

	public ValidationDateException(Status code, Operation operation, ErrorField errorField, Map<String, Map<String, String>> errorDescriptions, String lang) {
		super(code, new ValidationDateExceptionBody(code.getStatusCode(), ERROR_CODE, operation, errorField, errorDescriptions, lang));
		
		log.error(this.getBody().getLogErrorMessage());
	}

	@Schema(description = "Start date should be before end date")
	public static class ValidationDateExceptionBody extends AbstractExceptionBody {
		
		private static final long serialVersionUID = -230796541489800056L;

		public ValidationDateExceptionBody(Integer code, ErrorCode errorCode, Operation operation, ErrorField errorField,
				Map<String, Map<String, String>> errorDescriptions, String lang) {
			super(code, errorCode, operation, errorField, errorDescriptions, lang);
		}
	}
}
