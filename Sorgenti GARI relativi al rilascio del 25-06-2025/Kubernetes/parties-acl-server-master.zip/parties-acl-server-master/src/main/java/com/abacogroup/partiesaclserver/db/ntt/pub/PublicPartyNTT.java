package com.abacogroup.partiesaclserver.db.ntt.pub;

import org.jdbi.v3.core.mapper.Nested;

import com.abacogroup.jdbi.datatype.AbsoluteDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class PublicPartyNTT {
	private Long pkid;
	private Long mandate_id;
	private AbsoluteDate day_from;
	private AbsoluteDate day_to;
	private Long entity_id;
	private String party_id;
	private PublicPartyTypeNTT party_type;
	
	@Nested("ppt")
	public PublicPartyTypeNTT getParty_type() {
		return party_type;
	}
}
