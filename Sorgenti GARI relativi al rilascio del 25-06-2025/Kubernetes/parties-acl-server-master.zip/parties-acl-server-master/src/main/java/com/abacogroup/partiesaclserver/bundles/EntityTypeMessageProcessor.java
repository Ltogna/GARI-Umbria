package com.abacogroup.partiesaclserver.bundles;

import java.io.File;
import java.nio.file.Path;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.partiesaclserver.bundles.models.EntityType;
import com.abacogroup.partiesaclserver.bundles.models.EntityTypeCodeList;
import com.abacogroup.partiesaclserver.bundles.models.EntityTypeList;
import com.abacogroup.partiesaclserver.core.exceptions.bundles.BundleEntityTypeException;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.dao.DAOContainer;
import com.abacogroup.partiesaclserver.db.dao.I18nDAO;
import com.abacogroup.partiesaclserver.db.dao.TypesDAO;
import com.abacogroup.partiesaclserver.db.ntt.EntityTypeNTT;
import com.abacogroup.partiesaclserver.db.ntt.I18nNTT;
import com.fasterxml.jackson.databind.ObjectMapper;


public class EntityTypeMessageProcessor implements ConfigMessageProcessor {

	private final ObjectMapper objectMapper;

	private TypesDAO typesDAO;
	private I18nDAO i18nDAO;

	private static final Logger log = LoggerFactory.getLogger(EntityTypeMessageProcessor.class);

	public EntityTypeMessageProcessor(DAOContainer dc) {
		this.typesDAO = dc.getTypesDAO();
		this.i18nDAO = dc.getI18nDAO();
		objectMapper = new ObjectMapper();
	}

	@Override
	public String getDomainName() {
		return "entity-type";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> deleteMessage(message.getTenantId(), file));

		message.getConfigFiles().stream()
		.map(Path::toFile)
		.filter(file -> !file.isDirectory() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("json")
				&& !StringUtils.endsWithIgnoreCase(file.getAbsolutePath(), ".delete.json"))
		.forEach(file -> insertMessage(message.getTenantId(), file));
	}

	private void insertMessage(String tenantId, File file) {
		try {
			EntityTypeList entityTypeList = objectMapper.readValue(file, EntityTypeList.class);

			if (entityTypeList == null || entityTypeList.getEntity_type_list() == null || entityTypeList.getEntity_type_list().isEmpty()) {
				return;
			}

			entityTypeList.getEntity_type_list().stream().forEach(message -> {
				try {
					ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).build();
					EntityTypeNTT oldType = typesDAO.getEntityTypeByCode(env, message.getCode());

					EntityTypeNTT entityTypeToInsert = EntityTypeNTT.builder()
							.code(message.getCode())
							.fl_entity_code_mandatory(booleanToInteger(message.getFl_entity_code_mandatory()))
							.fl_hidden(booleanToInteger(message.getFl_hidden()))
							.fl_single_relation(booleanToInteger(message.getFl_single_relation()))
							.build();

					if(oldType == null) {
						entityTypeToInsert.setId(typesDAO.nextSequenceValEntityTypes());
						typesDAO.insertEntityType(tenantId, entityTypeToInsert);
					} else {
						entityTypeToInsert.setId(oldType.getId());
						typesDAO.updateEntityType(tenantId, entityTypeToInsert);
					}

					if(message.getTranslations() != null && !message.getTranslations().isEmpty()) {
						message.getTranslations().forEach((lang, text) -> {
							I18nNTT messageNTT = I18nNTT.builder()
									.field_name("code")
									.i18n_text(text)
									.i18n_value(message.getCode())
									.lang(lang)
									.table_name("pacl_entity_types")
									.tenant_id(tenantId)
									.build();

							I18nNTT toFind = i18nDAO.findI18nByPaclI18nKeys(messageNTT);

							if (toFind == null) {
								i18nDAO.insert(messageNTT);
							} else if (!toFind.getI18n_text().equals(text)) {
								i18nDAO.updateI18nText(messageNTT);
							}
						});
					}
					log.info("Entity type with code '{}' is valid for tenant '{}'. ", message.getCode(), tenantId);
				} catch (Exception e) {
					throw new BundleEntityTypeException("Error during insert or update entity type message " + message.toString() + " for tenant " + tenantId + ".\n" + e.getMessage());
				}

			});
		} catch (Exception e) {
			throw new BundleEntityTypeException("Error processing file " + file.getName() + " for tenant " + tenantId + ".\n" + e.getMessage());
		}
	}

	private void deleteMessage(String tenantId, File file) {
		try {
			EntityTypeCodeList entityTypeCodeList = objectMapper.readValue(file, EntityTypeCodeList.class);

			if (entityTypeCodeList == null || entityTypeCodeList.getEntity_type_code_list() == null || entityTypeCodeList.getEntity_type_code_list().isEmpty()) {
				return;
			}

			entityTypeCodeList.getEntity_type_code_list().stream().forEach(code -> {

				ServiceSupportEnv env = ServiceSupportEnv.builder().tenantId(tenantId).build();

				EntityTypeNTT type = typesDAO.getEntityTypeByCode(env, code);
				if(type == null) {
					throw new BundleEntityTypeException("Entity type with code '" + code + "' does not exists for tenant '" + tenantId + "'.\n");
				}

				Long count = typesDAO.countEntitiesByType(tenantId, type.getId());
				if(count != 0) {
					throw new BundleEntityTypeException("Entities exists with entity type with code '" + code + "' for tenant '" + tenantId + "'.\n");
				}

				I18nNTT row = I18nNTT.builder()
						.tenant_id(tenantId)
						.table_name("pacl_entity_types")
						.field_name("code")
						.i18n_value(code)
						.build();

				typesDAO.deleteEntityType(tenantId, type.getId());
				i18nDAO.deleteAllI18n(row);
				log.info("Entity type with code '{}' deleted for tenant '{}'. ", code, tenantId);
			});

		} catch (Exception e) {
			throw new BundleEntityTypeException("Error processing file " + file.getName() + " for tenant " + tenantId + ".\n" + e.getMessage());
		}
	}

	private Integer booleanToInteger(Boolean x) {
		return Boolean.TRUE.equals(x) ? 1 : 0;
	}
}
