package com.abacogroup.partiesaclserver.rabbitmq;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import org.apache.commons.lang3.StringUtils;

import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class RabbitMqUtils {

	private RabbitMqUtils() { }

	public static Connection createRabbitMqConnection(RabbitMqConfig rabbitMqConfig) {
		if (rabbitMqConfig == null) {
			return null;
		}

		if (StringUtils.isBlank(rabbitMqConfig.getHost())) {
			return null;
		}

		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(rabbitMqConfig.getHost());

		if (!StringUtils.isBlank(rabbitMqConfig.getUser())) {
			factory.setUsername(rabbitMqConfig.getUser());
		}
		if (!StringUtils.isBlank(rabbitMqConfig.getPassword())) {
			factory.setPassword(rabbitMqConfig.getPassword());
		}
		if (!StringUtils.isBlank(rabbitMqConfig.getVirtualhost())) {
			factory.setVirtualHost(rabbitMqConfig.getVirtualhost());
		}
		if (rabbitMqConfig.getPort() != null) {
			factory.setPort(rabbitMqConfig.getPort());
		}
		factory.setAutomaticRecoveryEnabled(true);

		try {
			return factory.newConnection();
		} catch (IOException | TimeoutException e) {
			throw new IllegalStateException("Cannot connect to rabbit mq", e);
		}
	}
}
