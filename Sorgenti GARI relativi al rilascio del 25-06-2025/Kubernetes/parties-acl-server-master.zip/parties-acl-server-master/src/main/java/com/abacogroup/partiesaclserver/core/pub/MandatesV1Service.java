package com.abacogroup.partiesaclserver.core.pub;

import static java.util.stream.Collectors.toList;

import java.util.List;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.partiesaclserver.core.EntitiesService;
import com.abacogroup.partiesaclserver.core.MandatesService;
import com.abacogroup.partiesaclserver.core.PartyRegistryClientService;
import com.abacogroup.partiesaclserver.core.enums.MandateStatus;
import com.abacogroup.partiesaclserver.core.mappers.pub.AddMandatorUserPayloadV1Mapper;
import com.abacogroup.partiesaclserver.core.mappers.pub.AddPartyPayloadV1Mapper;
import com.abacogroup.partiesaclserver.core.mappers.pub.HasManageV1ResponseMapper;
import com.abacogroup.partiesaclserver.core.mappers.pub.MandatorUserV1ResponseMapper;
import com.abacogroup.partiesaclserver.core.mappers.pub.PartyEntitySearchFiltersV1Mapper;
import com.abacogroup.partiesaclserver.core.mappers.pub.PartySearchV1ResponseMapper;
import com.abacogroup.partiesaclserver.core.mappers.pub.PartyV1ResponseMapper;
import com.abacogroup.partiesaclserver.core.mappers.pub.PartyWithEntityV1ResponseMapper;
import com.abacogroup.partiesaclserver.core.mappers.pub.UserPartyAuthV1ResponseMapper;
import com.abacogroup.partiesaclserver.core.mappers.pub.UserPartyV1ResponseMapper;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.resources.pub.req.AddMandatorUserPayloadV1;
import com.abacogroup.partiesaclserver.resources.pub.req.AddPartyPayloadV1;
import com.abacogroup.partiesaclserver.resources.pub.req.PartyEntitySearchFiltersV1;
import com.abacogroup.partiesaclserver.resources.pub.req.PartySearchFilters;
import com.abacogroup.partiesaclserver.resources.pub.res.HasManageV1Res;
import com.abacogroup.partiesaclserver.resources.pub.res.MandatorUserV1;
import com.abacogroup.partiesaclserver.resources.pub.res.PartySearchV1ResponseInfinite;
import com.abacogroup.partiesaclserver.resources.pub.res.PartyV1;
import com.abacogroup.partiesaclserver.resources.pub.res.PartyWithEntityV1;
import com.abacogroup.partiesaclserver.resources.pub.res.UserPartyAuthV1;
import com.abacogroup.partiesaclserver.resources.pub.res.UserPartyV1;
import com.abacogroup.partiesaclserver.resources.req.AddPartyPayload;
import com.abacogroup.partiesaclserver.resources.req.PartyEntitySearchFilters;
import com.abacogroup.partiesaclserver.resources.res.Entity;
import com.abacogroup.partiesaclserver.resources.res.PaclPartySearchResponseInfinite;
import com.abacogroup.partiesaclserver.resources.res.PartyWithEntity;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

public class MandatesV1Service {

	private final EntitiesService entitiesService;
	private final MandatesService mandatesService;
	private final PartyRegistryClientService partyRegistryClientService;

	public MandatesV1Service(EntitiesService entitiesService, MandatesService mandatesService, 
			PartyRegistryClientService partyRegistryClientService) {
		this.entitiesService = entitiesService;
		this.mandatesService = mandatesService;
		this.partyRegistryClientService = partyRegistryClientService;
	}

	public HasManageV1Res hasManage(ServiceSupportEnv env, String partyId) {
		return HasManageV1ResponseMapper.INSTANCE.toResponseV1(mandatesService.hasManage(env, partyId));
	}

	public UserPartyAuthV1 getAuthorizations(ServiceSupportEnv env, String partyId) {
		return UserPartyAuthV1ResponseMapper.INSTANCE.toResponseV1(mandatesService.getAuthorizations(env, partyId));
	}

	public InfiniteListResults<UserPartyV1> getAllMandatesByUserId(ServiceSupportEnv e, String nextKey) {
		return mandatesService.getAllPartiesByUserId(e, e.getUser().getUserId(), e.getPartyId(), List.of(MandateStatus.VALID), nextKey)
				.map(UserPartyV1ResponseMapper.INSTANCE::toResponseV1);
	}

	public Boolean addUsersToEntity(ServiceSupportEnv e, Long entityId, AddMandatorUserPayloadV1 payload, Boolean flSinglerelation, Boolean flHidden) {
		return mandatesService.addUsersToEntity(e, entityId, AddMandatorUserPayloadV1Mapper.INSTANCE.toResponse(payload), flSinglerelation, flHidden);
	}


	public PartySearchV1ResponseInfinite searchParties(ServiceSupportEnv env,
			PartySearchFilters partySearchReq, String nextKey) {
		PaclPartySearchResponseInfinite response = partyRegistryClientService.searchParties(env, partySearchReq, nextKey);
		return PartySearchV1ResponseInfinite.builder()
				.nextKey(response.getNextKey())
				.records(response.getRecords().stream().map(PartySearchV1ResponseMapper.INSTANCE::toResponseV1).collect(toList()))
				.count(response.getCount())
				.build();
	}

	public InfiniteListResults<MandatorUserV1> getAllUsersByEntityId(ServiceSupportEnv env, Long entityId,
			String usernameFilter, String nextKey) {
		return mandatesService.getAllUsersByEntityId(env, entityId, usernameFilter, nextKey)
				.map(MandatorUserV1ResponseMapper.INSTANCE::toResponseV1);
	}

	public InfiniteListResults<PartyV1> getAllPartiesByEntityId(ServiceSupportEnv env, String entityCode,
			Boolean history, Boolean includeChildren, String nextKey) {
		Entity entity = entitiesService.getEntityByCode(env, entityCode, false);
		return mandatesService.getAllPartiesByEntityId(env, entity.getId(), history, includeChildren, List.of(MandateStatus.VALID), nextKey)
				.map(PartyV1ResponseMapper.INSTANCE::toResponseV1);
	}

	public InfiniteListResults<PartyWithEntityV1> getAllEntitiesByPartyId(ServiceSupportEnv e, String partyId, PartyEntitySearchFiltersV1 filters, String nextKey) {
		PartyEntitySearchFilters partyEntitySearchFilters = PartyEntitySearchFiltersV1Mapper.INSTANCE.fromFiltersV1(filters);
		InfiniteListResults<PartyWithEntity> res = mandatesService.getAllEntitiesByPartyId(e, partyId, partyEntitySearchFilters, List.of(MandateStatus.VALID), nextKey);
		return PartyWithEntityV1ResponseMapper.INSTANCE.toResponseV1InfiniteList(res);
	}

	public Long addPartyToEntity(ServiceSupportEnv env, Long entityId, @NotNull @Valid AddPartyPayloadV1 payload) {
		AddPartyPayload privPayload = AddPartyPayloadV1Mapper.INSTANCE.toResponse(payload);
		return mandatesService.addPartyToEntity(env, entityId, privPayload);
	}
}
