package com.abacogroup.partiesaclserver.resources.res;

import java.util.List;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class ClientConfigurationList {
	@ArraySchema(schema = @Schema(description = "List of client configs", implementation = ClientConfiguration.class))
	private List<ClientConfiguration> client_configuration;
}
