package com.abacogroup.partiesaclserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.db.ntt.PathUserNTT;
import com.abacogroup.partiesaclserver.resources.res.PathUser;

@Mapper
public interface PathUserMapper {
	
	PathUserMapper INSTANCE = Mappers.getMapper(PathUserMapper.class);
	
	@InheritInverseConfiguration()
	PathUser entityTODto(PathUserNTT entity);

	PathUserNTT dtoToEntity(PathUser dto);
	
}
