package com.abacogroup.partiesaclserver.core;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abacogroup.partiesaclserver.core.enums.InternalConfigKeys;
import com.abacogroup.partiesaclserver.core.models.Config;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;

public abstract class AbstractConfigService {

	private LoadingCache<String, Map<String, Config>> configCache;

	protected AbstractConfigService() {
		configCache = Caffeine.newBuilder()
				.maximumSize(500)
				.expireAfterWrite(Duration.ofMinutes(30))
				.build(this::loadConfiguration);
	}
	
	/**
	 * Gets the key value for tenant.
	 * 
	 * @param tenantId - The id of the tenant for which the value is to be retrieved
	 * @param key - The key of the value to be retrieved
	 * 
	 * @return The Object value associated with the key
	 */
	public Object getValue(String tenantId, String key) {
		return configCache.get(tenantId).get(key).getValue();
	}
	
	/**
	 * Gets the key value for tenant as generic list
	 * 
	 * @param tenantId - The id of the tenant for which the value is to be retrieved
	 * @param clazz - The class of the generic
	 * @param key - The key of the value to be retrieved
	 * 
	 * @return The List of Objects in the value associated with the key
	 */
	@SuppressWarnings("unchecked")
	public<T> List<T> getValuesList(String tenantId, Class<T> clazz, String key) {
		return (List<T>) configCache.get(tenantId).get(key).getValue();
	}

	/**
	* Gets a double value. This method is useful for obtaining a value that is in the form of a double.
	* 
	* @param tenantId - The id of the tenant for which the value is to be retrieved
	* @param key - The key of the value to be retrieved
	* 
	* @return The value associated with the key as a double or null if the key does not exist or cannot be
	*/
	public Double getDoubleValue(String tenantId, String key) {
		return Double.parseDouble(getStringValue(tenantId, key));
	}

	/**
	* Gets an integer value. This method is useful for getting a value that is stored as integer in the configuration file.
	* 
	* @param tenantId - The tenant to get the value from.
	* @param key - The key of the value to get. If the key is prefixed with'@'it will be looked up in the configuration file otherwise it will be
	*/
	public Integer getIntegerValue(String tenantId, String key) {
		return Integer.parseInt(getStringValue(tenantId, key));
	}

	/**
	* Gets a boolean value. This method is useful for getting values that are stored as Boolean in XML files.
	* 
	* @param tenantId - The tenant to look up the value in
	* @param key - The key of the value to retrieve
	* 
	* @return The boolean value associated with the key or null if there is no such key in the XML file or if the value could not be
	*/
	public Boolean getBooleanValue(String tenantId, String key) {
		return Boolean.valueOf(getStringValue(tenantId, key));
	}
	
	
	public Boolean getBooleanValue(String tenantId, InternalConfigKeys confKey) {
		return Boolean.valueOf(getStringValue(tenantId, confKey.getKey()));
	}

	/**
	* Gets a string value. This method is useful for getting values that are stored in the config file and can be used to set defaults.
	* 
	* @param tenantId - tenant id for the config file. This should be the same as the tenant id used in #getConfig ( String )
	* @param key - key for the
	*/
	public String getStringValue(String tenantId, String key) {
		String val = String.valueOf(configCache.get(tenantId).get(key).getValue());
		return val.equals("null") ? "" : val;
	}

	/**
	* Get the tenant configuration. This method is called by #getTenant ( String ) to get the tenant configuration for a tenant.
	* 
	* @param tenantId - The id of the tenant. This can be null in which case the configuration is returned for the root tenant.
	* 
	* @return The map of tenant configuration or null if none exists for the tenant id in the cache ( which is the case if there is no configuration
	*/
	protected Map<String, Config> getTenantConfiguration(String tenantId) {
		return configCache.get(tenantId);
	}

	/**
	* Returns the configuration for the given tenant as a Map. This method is useful for debugging purposes. If you want to get the tenant's configuration for a specific tenant use getTenantConfiguration ( String )
	* 
	* @param tenantId - the id of the tenant
	* 
	* @return the configuration for the given tenant as a Map or null if there is no configuration for the given tenant
	*/
	public Map<String, Object> getConfigurationToMap(String tenantId) {
		Map<String, Config> tenantConfiguration = getTenantConfiguration(tenantId);

		Map<String, Object> result = new HashMap<>();
		tenantConfiguration.forEach((key, config) -> result.put(key, config.getValue()));

		return result;
	}

	/**
	* Loads the configuration for the given tenant. This method is called by #load ( String ) to load the configuration for the given tenant.
	* 
	* @param tenantId - the tenant for which to load the configuration
	* 
	* @return the configuration for the given tenant or null if none could be found in the configuration file for the given
	*/
	protected abstract Map<String, Config> loadConfiguration(String tenantId);
}
