package com.abacogroup.partiesaclserver.bundles.models;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AnomalyCategoriesMessageList {
	private List<AnomalyCategoriesMessage> anomaly_categorie_list;
}
