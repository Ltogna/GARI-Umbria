package com.abacogroup.partiesaclserver.core;

import java.util.HashMap;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.partiesaclserver.client.FileStoreProxyClient;
import com.abacogroup.partiesaclserver.client.ReqContext;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;

import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;

public class FileStoreProxyClientService {

	private final Sso2Client sso2Client;
	private final FileStoreProxyClient fileStoreProxyClient;
	
	private static final String TENANT = "tenantId";
	private static final String GET_FILE_CONTENT_PATH = "/{tenantId}/public/v1/files/{bucketName}/{id}";

	public FileStoreProxyClientService(Sso2Client sso2Client, WebTarget fileStoreWT) {
		this.sso2Client = sso2Client;
		this.fileStoreProxyClient = new FileStoreProxyClient(fileStoreWT);
	}

	public Response getFileContent(ServiceSupportEnv env, String bucket, String fileId) {
		
		String tenantId = env.getTenantId();

		sso2Client.ensureLongLivingAuthToken(env.getUser());
		
		HashMap<String, Object> pathVariables = new HashMap<>();
		pathVariables.put(TENANT, tenantId);
		pathVariables.put("bucketName", bucket);
		pathVariables.put("id", fileId);
		
		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		
		ReqContext reqContext = new ReqContext(env.getUser(), env.getLang());

		return fileStoreProxyClient.get(GET_FILE_CONTENT_PATH, reqContext, 
					pathVariables, 
					queryParams, 
					new GenericType<>() { });
	}

	public Response getFileMetadata(ServiceSupportEnv env, String bucket, String fileId) {
		
		String tenantId = env.getTenantId();

		sso2Client.ensureLongLivingAuthToken(env.getUser());
		
		HashMap<String, Object> pathVariables = new HashMap<>();
		pathVariables.put(TENANT, tenantId);
		pathVariables.put("bucketName", bucket);
		pathVariables.put("id", fileId);
		
		MultivaluedMap<String, Object> queryParams = new MultivaluedHashMap<>();
		
		ReqContext reqContext = new ReqContext(env.getUser(), env.getLang());

		return fileStoreProxyClient.head(GET_FILE_CONTENT_PATH, reqContext, 
					pathVariables, 
					queryParams);
	}

}
