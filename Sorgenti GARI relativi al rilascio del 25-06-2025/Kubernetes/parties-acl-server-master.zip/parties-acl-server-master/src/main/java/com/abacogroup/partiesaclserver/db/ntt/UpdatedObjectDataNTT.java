package com.abacogroup.partiesaclserver.db.ntt;

import com.abacogroup.jdbi.datatype.AbsoluteDate;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class UpdatedObjectDataNTT {
	private String partyTypeCode;
	private String entityTypeCode;
	private String userRole;
	private Long mandateId;
	private Boolean flManage;
	private AbsoluteDate dayFrom;
	private AbsoluteDate dayTo;
}
