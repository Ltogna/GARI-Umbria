package com.abacogroup.partiesaclserver.core.exceptions.enums;

public enum ErrorCode {

	PAST_DATE_NOT_ALLOWED("Past date insert not allowed"),
	VALIDATION_DATE_ERROR("Start date should be before end date"),
	VALIDATION_DATES_CONFLICT("Validation dates should be between Group's validation dates"),
	CODE_REQUIRED("Group code is required for the given group type"), 
	CODE_UNIQUE("Group already exists with given code"), 
	NAME_REQUIRED("Group name is required"), 
	ENTITY_NOT_FOUND("Group not found"),
	ENTITY_WITH_PARENT("Group has parent"),
	ENTITY_WITH_USERS("Group has one or more users"),
	ENTITY_WITH_PARTIES("Group has one or more mandates"),
	ENTITY_WITH_EXCLUSIVE_PARTY("Group has an exclusive mandate"),
	ENTITY_WITHOUT_PARENT("Group does not have parent"),
	ENTITY_WITHOUT_ADMIN("Group does not have an admin user"),
	ENTITY_EXISTS_WITH_REGISTRY_PARTY_ID("Group already exists with given registry-party id"),
	PARENT_NOT_VALID("Parent group is not valid for child"),
	HIERARCHICAL_LOOP("Parent group creates a hierarchical loop with child"),
	INVALID_PAYLOAD("Invalid payload"), 
	INVALID_REQUEST("Invalid request"), 
	INVALID_END_DATE("Invalid end date"),
	INVALID_USER("Invalid user"),
	INVALID_PARTY_NAME("Can not retrieve party name"),
	EXCLUSIVE_PARTY_ALREADY_EXISTS("Exclusive mandate already exists in the given group id and validation date interval"),
	PARTY_ALREADY_EXISTS("Party already has a mandate in the given group and given validation date interval"),
	PARTY_NOT_ASSOCIATED("Party id not associated with given group id"),
	MANDATE_NOT_FOUND("Mandate not found"),
	MANDATE_NOT_EDITABLE("Mandate not editable"),
	USER_ALREADY_EXISTS("User already exists in the given group id"),
	USER_NOT_ASSOCIATED_WITH_ENTITY("User id not associated with given group id"),
	USER_NOT_ASSOCIATED_WITH_PARTY("User id not associated with given party id"),
	NOTHING_TO_UPDATE("no new value to update"),
	GENERIC_TYPE_ERROR("Generic type error!"),
	TYPES_NOT_COMPATIBLE("Mandate type and group type are not compatible"), 
	ENTITY_TYPES_NOT_COMPATIBLE("Parent group type and child group type are not compatible"), 
	TYPE_NOT_FOUND("Type code or id not found"),
	TYPE_ALREADY_EXISTS("Type code already exists"),
	USER_NOT_ALLOWED("User not allowed"),
	USER_NOT_FOUND("User not found"),
	ENTITIES_WTIH_TYPE("One or more group exist with the given type"), 
	PARTIES_WTIH_TYPE("One or more mandates exist with the given type"), 
	ID_NOT_FOUND("Revision id not found"),
	INTERNAL_CONFIG_NOT_FOUND("Internal config not found!"), 
	INVALID_ID("Invalid Id"),
	PARTY_WITH_ANOMALY("Party with anomaly"),
	USER_WITH_ANOMALY("User with anomaly"),
	ENTITY_WITH_ANOMALY("Group with anomaly"),
	CONFIGURATION_ERROR("Error in configuration key"),
	PARTY_REGISTRY_RESPONSE_ERROR("Error in party registry response"), 
	INVALID_DOCUMENT_DEFINITION("Error loading definition"), 
	INVALID_DOCUMENT_CODE("Invalid document code!"),
	DOC_OVER_MAX_OCCURS("Over max occurs"), 
	DYNAMIC_DOCUMENT_NOT_FOUND("Document not found!"), 
	CLOSE_MANDATE_DOCUMENT_NOT_FOUND("Close mandate document not found!"), 
	EXTEND_MANDATE_DOCUMENT_NOT_FOUND("Extend mandate document not found!"), 
	REVOKE_MANDATE_DOCUMENT_NOT_FOUND("Revoke mandate document not found!"), 
	DYNAMIC_DOCUMENT_FILE_NOT_FOUND("The given document does not contains the file with given id");
	
	private String description;

	private ErrorCode(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

}
