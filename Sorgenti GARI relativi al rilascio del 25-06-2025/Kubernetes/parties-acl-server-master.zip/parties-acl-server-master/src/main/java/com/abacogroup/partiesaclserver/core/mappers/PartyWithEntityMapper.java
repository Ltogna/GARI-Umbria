package com.abacogroup.partiesaclserver.core.mappers;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.partiesaclserver.db.ntt.PartyWithEntityNTT;
import com.abacogroup.partiesaclserver.resources.res.PartyWithEntity;

@Mapper(uses = {EntityMapper.class, PartyMapper.class, PartyTypeMapper.class})
public interface PartyWithEntityMapper {
	
	PartyWithEntityMapper INSTANCE = Mappers.getMapper(PartyWithEntityMapper.class);
	
	@InheritInverseConfiguration()
	@Mapping(source = "party_id", target = "id")
	@Mapping(source = "day_from", target = "dayFrom")
	@Mapping(source = "day_to", target = "dayTo")
	@Mapping(source = "party_type", target = "partyType")
	@Mapping(source = "mandate_id", target = "mandateId")
	@Mapping(source = "status", target = "status")
	PartyWithEntity entityTODto(PartyWithEntityNTT entity);
	
	
	@Mapping(target = "pkid", ignore = true)
	@Mapping(target = "entity_id", ignore = true)
	@Mapping(source = "dayFrom", target = "day_from")
	@Mapping(source = "dayTo", target = "day_to")
	@Mapping(source = "partyType", target = "party_type")
	@Mapping(source = "id", target = "party_id")
	@Mapping(source = "mandateId", target = "mandate_id")
	PartyWithEntityNTT dtoToEntity(PartyWithEntity dto);
	
}
