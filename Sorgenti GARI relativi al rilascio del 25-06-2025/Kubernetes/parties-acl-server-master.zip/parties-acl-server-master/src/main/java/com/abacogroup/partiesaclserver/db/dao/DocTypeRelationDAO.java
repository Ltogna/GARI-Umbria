package com.abacogroup.partiesaclserver.db.dao;

import java.util.List;
import java.util.Optional;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.partiesaclserver.core.enums.DocTypeRelationScope;
import com.abacogroup.partiesaclserver.core.enums.Revision;
import com.abacogroup.partiesaclserver.core.support.ServiceSupportEnv;
import com.abacogroup.partiesaclserver.db.ntt.DocTypeRelationNTT;

public interface DocTypeRelationDAO extends Transactional<DocTypeRelationDAO>, EnhancedSqlObject {
	
	@SqlQuery("§select_nextval(pacl_doc_type_relations_sequence)§")
	Long nextSequenceVal();
	
	@SqlUpdate("INSERT INTO pacl_doc_type_relations(pkid, tenant_id, revision_code, scope_code, entity_type_id, party_type_id, definition_code, "
			+ "user_id_insert, user_id_delete, dt_insert, dt_delete, display_order) "
			+ "VALUES (:pkid, :tenantId, :revisionCode, :scopeCode, :entityTypeId, :partyTypeId, :definitionCode, "
			+ ":userIdInsert, null, §current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :displayOrder)")
	void insert(@Bind("tenantId") String tenantId, @Bind("userIdInsert") String userIdInsert, @BindBean DocTypeRelationNTT entity);
	
	@SqlQuery("select pdtr.revision_code, \n"
			+ "   pdtr.scope_code, \n"
			+ "   pdtr.display_order, \n"
			+ "   pdtr.entity_type_id, \n"
			+ "   pdtr.party_type_id, \n"
			+ "   pdtr.definition_code, \n"
			+ "   coalesce (§i18n(:tenantId, 'pacl_doc_type_relations', 'definition_code', pdtr.definition_code, :lang)§, pdtr.definition_code) as definition_code_i18n \n"
			+ "from pacl_doc_type_relations pdtr \n"
			+ "where pdtr.tenant_id= :tenantId"
			+ "  and pdtr.scope_code = :scopeCode "
			+ "  and (pdtr.entity_type_id = :entityTypeId or pdtr.entity_type_id is null) "
			+ "  and (pdtr.party_type_id = :partyTypeId or pdtr.party_type_id is null) "
			+ "  and §current_timestamp§ between pdtr.dt_insert and pdtr.dt_delete \n"
			+ " order by display_order ")
	@RegisterBeanMapper(DocTypeRelationNTT.class)
	List<DocTypeRelationNTT> getByEntityTypeIdPartyTypeIdAndScopeCode(
			@BindBean ServiceSupportEnv env, 
			@Bind("entityTypeId") Long entityTypeId,
			@Bind("partyTypeId") Long partyTypeId,
			@Bind("scopeCode") DocTypeRelationScope scopeCode);
	
	@SqlQuery("select pdtr.pkid, \n"
			+ "   pdtr.revision_code, \n"
			+ "   pdtr.scope_code, \n"
			+ "   pdtr.display_order, \n"
			+ "   pdtr.entity_type_id, \n"
			+ "   pdtr.party_type_id, \n"
			+ "   pdtr.definition_code, \n"
			+ "   coalesce (§i18n(:tenantId, 'pacl_doc_type_relations', 'definition_code', pdtr.definition_code, :lang)§, pdtr.definition_code) as definition_code_i18n \n"
			+ "from pacl_doc_type_relations pdtr \n"
			+ "where pdtr.tenant_id= :tenantId"
			+ "   and ((:revisionCode is not null AND pdtr.revision_code = :revisionCode) "
			+ "      or (:revisionCode is null and pdtr.revision_code is null)) "
			+ "   and ((:entityTypeId is not null AND pdtr.entity_type_id = :entityTypeId) "
			+ "      or (:entityTypeId is null and pdtr.entity_type_id is null)) "
			+ "   and ((:partyTypeId is not null AND pdtr.party_type_id = :partyTypeId) "
			+ "      or (:partyTypeId is null and pdtr.party_type_id is null)) "
			+ "   and pdtr.definition_code = :defCode " 
			+ "   and pdtr.scope_code = :scopeCode "
			+ "   and §current_timestamp§ between pdtr.dt_insert and pdtr.dt_delete \n"
			+ " order by display_order ")
	@RegisterBeanMapper(DocTypeRelationNTT.class)
	Optional<DocTypeRelationNTT> findByTypeIdsScopeCodeRevisionCodeAndDefCode(
			@BindBean ServiceSupportEnv env, 
			@Bind("entityTypeId") Long entityTypeId,
			@Bind("partyTypeId") Long partyTypeId,
			@Bind("scopeCode") DocTypeRelationScope scopeCode, 
			@Bind("revisionCode") Revision revisionCode, 
			@Bind("defCode") String defCode);
	
	@SqlUpdate("update pacl_doc_type_relations set dt_delete = §current_timestamp§, user_id_delete = :userIdDelete where pkid = :pkid")
	void expireRow(@BindBean DocTypeRelationNTT entity, @Bind("userIdDelete") String userIdDelete);

}
