package com.abacogroup.partiesaclserver.core.enums;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Operation to insert in Revision History table")
public enum Revision {
	//
	
	 ADD_USER("ADD_USER"),
	 ADD_MANDATE("ADD_MANDATE"),
	 REMOVE_USER("REMOVE_USER"),
	 REMOVE_MANDATE("REMOVE_MANDATE"),
	 REMOVE_ENTITY("REMOVE_ENTITY"),
	 TRUNC_PATH("TRUNC_PATH"),
	 EXT_PATH("EXT_PATH"),
	 UPDATE_PATH("UPDATE_PATH"),
	 UPDATE_ENTITY("UPDATE_ENTITY"),
	 UPDATE_MANDATE("UPDATE_MANDATE"), 
	 EXTEND_MANDATE("UPDATE_MANDATE"),
	 REVOKE_MANDATE("REMOVE_MANDATE");
	
	private String extRevisionCode;

	Revision(String rev) {
		this.extRevisionCode = rev;
	}
	
	public String getExtRevisionCode() {
		return this.extRevisionCode;
	}
}
