# Vector Data Layer
_version: v2.2.6_

[TOC]

## Environment
Since version 1.3.0 the way the data sources are configured changed.
Now we don't read anymore database connections from VDL_ADDITIONAL_DATA_SOURCES but from env variables.

To know which datasource are needed for the project to work correctly, you need to look into VDL_SOURCES table 
and select all the unique values of the column DATASOURCE that are not null (if it's null it means the database 
configured on config.yml will be used).

Once you have all the data sources names, you'll need to set the corresponding environmental variables.
For a database connection to work you will need to set these env variables:

```
VDLDS_<datasource>_JDBC_URL
VDLDS_<datasource>_JDBC_DRIVER
VDLDS_<datasource>_USER
VDLDS_<datasource>_PASSWORD
VDLDS_<datasource>_VALIDATION_QUERY
```

for all the data sources you found on the VDL_SOURCES table.

### Source sql tips
:warning: sql select sources must not contains columns named `id` and `label` becose are "special" names used in program!!!!


### Practical example:
At the time this doc has been written, VDL_SOURCES contained 2 record, one with datasource column equal to null, and the second 
one with the datasource column equal to 'siti'.
As previously stated, the record with datasource column equal to null must be skipped since it means that this query
can be run on vector_data_layers database.

For the data source named 'siti', you will need to set the 5 environmental variables as stated before, replacing 
'<datasource>' with the datasource name in uppercase (in this example it will be 'SITI'.

The end result will be:
```
VDLDS_SITI_JDBC_URL="a working connection string"
VDLDS_SITI_JDBC_DRIVER="a driver class, postgres or oracle"
VDLDS_SITI_USER="a valid user"
VDLDS_SITI_PASSWORD=="a valid password"
VDLDS_SITI_VALIDATION_QUERY=="a valid validation query"
```

If there are more than 1 data sources, you will need to configure it one by one like the example above.

If you use IntelliJ IDE you can set environmental variables for development purposes through file or manually 
by using this [plugin](https://plugins.jetbrains.com/plugin/7861-envfile):

## OpenAPI ##

[openapi.yaml](openapi.yaml)
use `mvn swagger:resolve` to generate new openapi.yaml

[openapi.json from local server](`http://localhost:8080/vector-data-layers/openapi.json`)   
[swagger per testare l'output](https://editor-next.swagger.io/)

## Bundles format

The application can be conencted to a RabbitMQ instance usign this configuration snippet:

```yaml
    rabbitmqConfig:
      host: ${RMQ_HOST}
      user: ${RMQ_USER}
      password: ${RMQ_PASSWORD}
      virtualhost: ${RMQ_VHOST}
      port: ${RMQ_PORT}
```

If the connection is configured, the bundles infrastructure will be automatically setup to allow automatic configuration.

The application module id is `vector-data-layers` and the supported changeset domains are:

```
📂 vector-data-layers
┗━📂 <client-id>-<nnnnn>
  ┣━📂 data-sources
  ┃ ┣━📜 <any file>.json
  ┃ ┗━📜 <any file>.delete.json
  ┣━📂 sources
  ┃ ┣━📜 <any file>.json
  ┃ ┗━📜 <any file>.delete.json
  ┗━📂 layer-styles
    ┣━📜 <any file>.json
    ┗━📜 <any file>.delete.json
  
```

Execution order:
1. [`layer-styles`](#layer-styles-domain-folder)
1. [`data-sources`](#data-sources-domain-folder)
1. [`sources`](#sources-domain-folder)

In the same bundle I can add a **datasource** and a **source** that uses it. 
To delete a **datasource** I must first have deleted all the **sources** that use it in a previous bundle

### `sources` domain folder

The `sources` domain allows to insert, update and delete the sources.

#### Upsert
.json files are used to insert a new source or update an existing one. If the ID already exists the update is executed otherwise a new record is inserted. 

They must follow this schema:
[SourceInsertOrUpdate.schema.json](docs%2Fbundles%2FSourceInsertOrUpdate.schema.json)

`data.srs` can also be valorised with:
- `none`: does not re-project geometry when calling the `/wms` api
- `param:{param_name}`: re-projects geometry by looking up the srs from the query param `{param_name}` when calling the `/wms` api

Example:

with optional properties

```json
{
  "ID": {
    "sourceCode": "mstr-5"
  },
  "data": {
    "sqlSelect": "SELECT gid, geom, code FROM public.zvn_2023_utm_32n where tenant_id={tenant} and {spatial_where_clause} and gid<14 and (:foo is null or foo = :foo) ",
    "datasource": "main",
    "filterGeometryColumn": "geom",
    "geometryColumn": "geom",
    "identifierColumn": "gid",
    "labelColumn": "nome_zvn",
    "fillColor": "#00FF007F",
    "fillStyle": "SQUARES",
    "borderColor": "#7F007F",
    "fontColor": "#D1C0FA",
    "borderThick": 1,
    "fontSize": 12,
    "geometryType": "POLYGONAL",
    "srs": "EPSG:32632",
    "styleCode": "styleCode1",
    "styleRefColumn": "code",
    "modules": [
      "module1",
      "module2"
    ]
  },
  "additionalQueryParams": [
    {
      "queryParamName": "foo",
      "type": "String",
      "description": "example"
    }
  ],
  "description": {
    "en": "Example",
    "it": "Esempio"
  }
}
```

#### Delete

.delete.json files are used to remove an existing ID. If the ID doesn't exists they do nothing.

They must follow this schema:
[SourceID.schema.json](docs%2Fbundles%2FSourceID.schema.json)

Example:

```json
{
    "sourceCode" : "mstr-5"
}
```

### `data-sources` domain folder

The `data-sources` domain allows to insert and delete additional db dataSources.

#### Insert
.json files are used to insert a new data source. If the data source code already exists the operation will fail.

They must follow this schema:
[DataSourceList.schema.json](docs/bundles/DataSourceList.schema.json)

Example:

```json
{
  "dataSources": ["ds1", "ds2"]
}
```

#### Delete

.delete.json files are used to remove an existing ID. If the data source code doesn't exist the operation will fail.
**If a [source](#sources-domain-folder) is using the datasource, the procedure will fail.**

They must follow this schema:
[DataSourceList.schema.json](docs/bundles/DataSourceList.schema.json)

Example:

```json
{
  "dataSources": ["ds1", "ds2"]
}
```

### `layer-styles` domain folder

The `layer-styles` domain allows to insert, update and delete layer styles in vdl_layer_styles

#### Upsert
.json files are used to insert a new layer styles or update an existing one. If the style code already exists the update is executed otherwise a new record is inserted.

They must follow this schema:
[LayerStyleList.schema.json](docs%2Fbundles%2FLayerStyleList.schema.json)

Example:

```json
{
	"layerStyles": [
		{
			"styleCode": "styleCode1",
			"styles": [
				{
					"refCode": "refCode1",
					"fillColor": "#66CC8044",
					"borderColor": "#66CC8099",
					"borderThick": 2,
					"fontColor": "#66CC8099",
					"fontSize": 15
				}
			]
		}
	]
}
```

#### Delete

.delete.json files are used to remove an existing style code. If the style code doesn't exists they do nothing.

They must follow this schema:
[LayerStyleDeleteList.schema.json](docs%2Fbundles%2FLayerStyleDeleteList.schema.json)

Example:

```json
{
	"layerStyles": [
		{
			"styleCode": "styleCode1"
		}
	]
}
```


