#!/bin/sh
umask 0002 && \
java -Djava.security.egd=file:/dev/./urandom -XX:MaxRAMPercentage=60 -jar original-${project.build.finalName}.jar server config.yml