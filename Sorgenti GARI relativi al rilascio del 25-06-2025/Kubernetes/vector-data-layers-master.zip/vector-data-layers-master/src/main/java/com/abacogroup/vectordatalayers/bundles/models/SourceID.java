package com.abacogroup.vectordatalayers.bundles.models;

import com.fasterxml.jackson.annotation.JsonClassDescription;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ConfigurationBundlePojo()
@JsonClassDescription("identify a unique source for sources domanin management")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SourceID {
	//private String tenantId; //declared once in bundles.config.json

	@JsonProperty(required = true)
	@JsonPropertyDescription("The unique code of the vector data layer source")
	@NotBlank
	private String sourceCode;
}
