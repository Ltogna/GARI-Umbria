package com.abacogroup.vectordatalayers.db.dao;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;


public interface VdlSourceModuleDAO extends Transactional<VdlSourceModuleDAO>, EnhancedSqlObject {

	@SqlUpdate("DELETE FROM vdl_sources_modules "
			+ " WHERE tenant_id = :tenantId  "
			+ " and code = :sourceCode "
			+ " and (:module is null or module = :module) \n")
	void deleteSourceModuleBySourceCode(@Bind("tenantId") String tenantId, @Bind("sourceCode") String code, @Bind("module") String module);

	@SqlUpdate("INSERT INTO vdl_sources_modules (tenant_id, code, module)"
			+ " VALUES (:tenantId, :sourceCode, :module)")
	void insertSourceModule(@Bind("tenantId") String tenantId, @Bind("sourceCode") String sourceCode, @Bind("module") String module);
	
}
