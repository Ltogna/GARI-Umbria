package com.abacogroup.vectordatalayers.core.impl;

import java.awt.Color;
import java.awt.Font;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.core.result.ResultIterator;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.geometryeditor.GeometryTransform;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.vectordatalayers.api.Layer;
import com.abacogroup.vectordatalayers.api.LayerGeometry;
import com.abacogroup.vectordatalayers.common.resources.ReqContext;
import com.abacogroup.vectordatalayers.common.resources.ResourceConstants;
import com.abacogroup.vectordatalayers.core.DaoProvider;
import com.abacogroup.vectordatalayers.core.LayerService;
import com.abacogroup.vectordatalayers.core.dto.CustomFilterValue;
import com.abacogroup.vectordatalayers.core.dto.CustomWMSParams;
import com.abacogroup.vectordatalayers.core.exceptions.VdlSourceException;
import com.abacogroup.vectordatalayers.core.exceptions.VdlSourceException.ErrEnum;
import com.abacogroup.vectordatalayers.core.utlis.DrawFeatureBuilder;
import com.abacogroup.vectordatalayers.db.dao.DAOContainer;
import com.abacogroup.vectordatalayers.db.dao.LayerDAO;
import com.abacogroup.vectordatalayers.db.dao.LayerStyleDAO;
import com.abacogroup.vectordatalayers.db.dao.VdlSourceDAO;
import com.abacogroup.vectordatalayers.db.ntt.LayerStyleEntity;
import com.abacogroup.vectordatalayers.db.ntt.VdlQueryParamEntity;
import com.abacogroup.vectordatalayers.db.ntt.VdlSourceEntity;
import com.abacogroup.wms4j.layers.LayerDefinition;
import com.abacogroup.wms4j.layers.LayerRequest;
import com.abacogroup.wms4j.renderer.DrawFeature;
import com.abacogroup.wms4j.renderer.GeometryDrawerStyle;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;

import jakarta.ws.rs.core.MultivaluedMap;

public class LayerServiceImpl implements LayerService {

	private static final int LAYER_PEN_THICK = 2;
	private static final Color LAYER_PEN_COLOR = new Color(1.0f, 0.0f, 0.0f);
	private static final Color LAYER_FILL_COLOR = new Color(0.0f, 0.0f, 1.0f, 0.4f);

	protected static final String DEFAULT_FONT_NAME = "Arial";
	protected static final int DEFAULT_FONT_STYLE = Font.PLAIN;

	protected static final String TRANSPARENT = "#FFFFFF00";

	public static final String SRS_NONE = "none";
	public static final String SRS_PARAM_PREFIX = "param:";

	private final VdlSourceDAO vdlSourceDAO;
	private final LayerStyleDAO layerStyleDAO;
	private final DaoProvider<LayerDAO> layerDaoProvider;

	private LoadingCache<String, Map<String, LayerStyleEntity>> layerStyleCache; // key: tenant|styleCode

	public LayerServiceImpl(DAOContainer daoContainer, DaoProvider<LayerDAO> layerDaoProvider) {
		this.vdlSourceDAO = daoContainer.getVdlSourceDAO();
		this.layerStyleDAO = daoContainer.getLayerStyleDAO();
		this.layerDaoProvider = layerDaoProvider;

		layerStyleCache = Caffeine.newBuilder()
				.maximumSize(314)
				.expireAfterWrite(Duration.ofMinutes(120))
				.build(this::loadLayerStyleData);
	}

	@Override
	public InfiniteListResults<Layer> getLayers(ReqContext reqContext, String nextKey, Integer pageSize) {
		return vdlSourceDAO.infinite(() -> vdlSourceDAO.search(reqContext),
				nextKey, getPageSize(pageSize));
	}

	@Override
	public InfiniteListResults<LayerGeometry> getLayerGeometries(ReqContext reqContext, String sourceCode, Geometry touchingGeometry,
			boolean getIntersectedGeometries, MultivaluedMap<String, String> queryParameters, String nextKey, Integer pageSize) {
		VdlSourceEntity sourceData = vdlSourceDAO.findSourceByTenantAndCode(reqContext.getTenantId(), reqContext.getLang(), sourceCode);
		if (null == sourceData) {
			throw new VdlSourceException(ErrEnum.SOURCE_NOT_FOUND, String.format("layer with code '%s' not found", sourceCode));
		}

		List<VdlQueryParamEntity> queryParamEntities = vdlSourceDAO.findQueryParamsByTenantAndSourceCode(reqContext.getTenantId(), sourceCode);

		Map<String, CustomFilterValue<?>> additionalFilters = this.extractAdditionalFilters(queryParamEntities, queryParameters);

		LayerDAO layerDAO = layerDaoProvider.fromDatasource(sourceData.getDatasource());

		String querySrs = gerSrsFromQueryParams(queryParameters);
		String layerSrs = getSourceSrs(sourceData, queryParameters);
		if (querySrs != null) {
			touchingGeometry = this.transformGeometry(touchingGeometry, querySrs, layerSrs);
		}

		final Geometry finalGeom = touchingGeometry;
		return layerDAO.infinite(() -> layerDAO.getByGeometryWithInfo(sourceData, finalGeom, additionalFilters, getIntersectedGeometries),
				nextKey, getPageSize(pageSize));
	}

	private String gerSrsFromQueryParams(MultivaluedMap<String, String> queryParameters) {
		String targetSrs = queryParameters.getFirst(CustomWMSParams.PARAM_SRS_ALIAS);
		if (StringUtils.isBlank(targetSrs)) {
			targetSrs = queryParameters.getFirst(CustomWMSParams.PARAM_SRS);
		}
		return StringUtils.isBlank(targetSrs) ? null : targetSrs;
	}

	@Override
	public List<LayerDefinition> getWMSLayers() {
		List<LayerDefinition> layers = new ArrayList<>();
		vdlSourceDAO.consumeIdentifiers(layer -> layers.add(createLayer(layer.getTenantId(), layer.getCode())));
		return layers;
	}

	@Override
	public List<LayerDefinition> getWMSLayers(String tenantId) {
		List<LayerDefinition> layers = new ArrayList<>();
		vdlSourceDAO.consumeIdentifiersByTenant(tenantId, layer -> layers.add(createLayer(tenantId, layer.getCode())));
		return layers;
	}

	@Override
	public LayerDefinition createLayer(String tenantId, String code) {
		return new LayerDefinition(
				tenantId,
				code,
				new LayerDefinition.Range(null, null),
				new GeometryDrawerStyle(LAYER_PEN_COLOR, LAYER_FILL_COLOR, LAYER_PEN_THICK),
				this::provide);
	}

	protected void provide(LayerRequest layerRequest, Consumer<DrawFeature> consumer) {
		VdlSourceEntity vdlSourceEntity = vdlSourceDAO.findSourceByTenantAndCode(layerRequest.getTenant(), "en", layerRequest.getLayerName());
		if (vdlSourceEntity == null) {
			return;
		}

		List<VdlQueryParamEntity> queryParamEntities = vdlSourceDAO.findQueryParamsByTenantAndSourceCode(layerRequest.getTenant(),
				layerRequest.getLayerName());

		MultivaluedMap<String, String> queryParameters = layerRequest.getUriInfo().getQueryParameters();
		CustomWMSParams customWMSParams = CustomWMSParams.fromQueryParams(queryParameters);
		String sourceSrs = this.getSourceSrs(vdlSourceEntity, queryParameters);
		Map<String, CustomFilterValue<?>> additionalFilters = this.extractAdditionalFilters(queryParamEntities, queryParameters);

		LayerDAO layerDAO = layerDaoProvider.fromDatasource(vdlSourceEntity.getDatasource());
		layerDAO.useTransaction(h -> {

			Geometry areaOfInterest = this.transformGeometry(layerRequest.getAreaOfInterest(),
					customWMSParams.getRequestedSrs(), sourceSrs).getEnvelope();

			ResultIterator<LayerGeometry> resultIterator = h.getByGeometryWithInfo(vdlSourceEntity, areaOfInterest, additionalFilters, true);

			while (resultIterator.hasNext()) {
				LayerGeometry layerGeometry = resultIterator.next();

				consumer.accept(toDrawFeature(layerRequest.getTenant(), vdlSourceEntity, layerGeometry, customWMSParams, sourceSrs));
			}
		});
	}

	private DrawFeature toDrawFeature(String tenantId, VdlSourceEntity vdlSourceEntity, LayerGeometry layerGeometry,
			CustomWMSParams customWMSParams, String sourceSrs) {
		if (layerGeometry == null || layerGeometry.getGeometry() == null) {
			return null;
		}

		DrawFeatureBuilder drawFeatureBuilder = buildDrawFeature(tenantId, vdlSourceEntity,
				layerGeometry.getFields().get("style_ref_code"), customWMSParams.getOutline(), customWMSParams.getFill());

		Geometry geometry = this.transformGeometry(layerGeometry.getGeometry(), sourceSrs, customWMSParams.getRequestedSrs());

		return drawFeatureBuilder.build(geometry, layerGeometry.getLabel(), customWMSParams.getLabels());
	}

	private DrawFeatureBuilder buildDrawFeature(String tenantId, VdlSourceEntity vdlSourceEntity, String refCode, Boolean outline, Boolean fill) {

		if (vdlSourceEntity.getStyleCode() == null || StringUtils.isBlank(refCode)) {
			return DrawFeatureBuilder.fromSource(vdlSourceEntity, outline, fill);
		}

		String key = tenantId + "|" + vdlSourceEntity.getStyleCode();
		Map<String, LayerStyleEntity> layerStyleMap = layerStyleCache.get(key);

		if (layerStyleMap == null || layerStyleMap.getOrDefault(refCode, null) == null) {
			return DrawFeatureBuilder.fromSource(vdlSourceEntity, outline, fill);
		}

		LayerStyleEntity layerStyle = layerStyleMap.getOrDefault(refCode, null);
		return DrawFeatureBuilder.fromLayerStyle(layerStyle, vdlSourceEntity.getFillStyle(), outline, fill);

	}

	private String getSourceSrs(VdlSourceEntity vdlSourceEntity, MultivaluedMap<String, String> queryParameters) {
		return Optional.ofNullable(vdlSourceEntity.getSrs())
				.map(srs -> {
					if (SRS_NONE.equalsIgnoreCase(srs)) {
						return null;
					}
					if (StringUtils.startsWithIgnoreCase(srs, SRS_PARAM_PREFIX)) {
						String paramName = StringUtils.removeStartIgnoreCase(srs, SRS_PARAM_PREFIX);

						if (!queryParameters.containsKey(paramName)) {
							throw new VdlSourceException(
									ErrEnum.UNREADABLE_QUERY_PARAMETER,
									String.format("missing srs query parameter '%s'", paramName));
						}

						return queryParameters.getFirst(paramName);
					}
					return srs;
				}).orElse(null);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Map<String, CustomFilterValue<?>> extractAdditionalFilters(List<VdlQueryParamEntity> queryParamEntities,
			MultivaluedMap<String, String> queryParameters) {
		Map<String, CustomFilterValue<?>> additionalFilters = new HashMap<>();
		for (VdlQueryParamEntity queryParamEntity : queryParamEntities) {
			String rowValue = Optional.ofNullable(queryParameters)
					.map(qp -> qp.get(queryParamEntity.getQueryParamName()))
					.filter(values -> !values.isEmpty())
					.map(values -> values.get(0))
					.orElse(null);

			try {
				Object convertValue = queryParamEntity.getType().convert(rowValue);
				additionalFilters.put(queryParamEntity.getQueryParamName(),
						new CustomFilterValue(queryParamEntity.getType().getClazz(), convertValue));
			} catch (IllegalArgumentException iae) {
				throw new VdlSourceException(
						ErrEnum.UNREADABLE_QUERY_PARAMETER,
						String.format("query parameter '%s' cannot be converted to type '%s'",
								queryParamEntity.getQueryParamName(), queryParamEntity.getType()));
			}
		}

		return additionalFilters;
	}

	private Map<String, LayerStyleEntity> loadLayerStyleData(String key) {
		if (key == null || key.split("\\|").length < 2)
			return new HashMap<>(0);

		return layerStyleDAO.findByTenantAndStyleCode(key.split("\\|")[0], key.split("\\|")[1])
				.stream()
				.collect(Collectors.toMap(LayerStyleEntity::getRefCode, Function.identity()));

	}

	private Geometry transformGeometry(Geometry geom, String sourceSrs, String targetSrs) {
		if (StringUtils.isBlank(targetSrs) || StringUtils.isBlank(sourceSrs)
				|| StringUtils.equalsIgnoreCase(sourceSrs, targetSrs)) {
			return geom;
		}

		try {
			GeometryTransform gt = new GeometryTransform();
			return gt.transform(geom, sourceSrs, targetSrs);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	private int getPageSize(Integer pageSize) {
		if (pageSize == null || pageSize <= 0 || pageSize > ResourceConstants.MAX_PAGE_SIZE) {
			return ResourceConstants.DEFAULT_PAGE_SIZE;
		}
		return pageSize;
	}

}
