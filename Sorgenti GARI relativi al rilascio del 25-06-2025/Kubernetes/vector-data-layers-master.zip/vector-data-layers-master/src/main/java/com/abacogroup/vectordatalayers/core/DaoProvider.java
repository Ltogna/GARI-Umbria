package com.abacogroup.vectordatalayers.core;

@FunctionalInterface
public interface DaoProvider<T> {

	T fromDatasource(String datasource);

}
