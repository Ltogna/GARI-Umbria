package com.abacogroup.vectordatalayers.api;

import lombok.Getter;

@Getter
public enum VdlFillStyle {

	VERTICAL_LINES("patterns/vert.png"),
	HORIZONTAL_LINES("patterns/horiz.png"),
	SQUARES("patterns/square.png"),
	SQUARES_LARGE("patterns/square_big.png"),
	DIAGONAL_UP("patterns/diag_up.png"),
	DIAGONAL_DOWN("patterns/diag_down.png"),
	DIAGONAL_SQUARES("patterns/diag_square.png"),
	DIAGONAL_SQUARES_LARGE("patterns/diag_square_big.png"),
	;

	private final String textureFile;

	VdlFillStyle(String textureFile) {
		this.textureFile = textureFile;
	}
}
