package com.abacogroup.vectordatalayers.core.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CustomFilterValue<T> {

	private Class<T> type;
	private T value;

}
