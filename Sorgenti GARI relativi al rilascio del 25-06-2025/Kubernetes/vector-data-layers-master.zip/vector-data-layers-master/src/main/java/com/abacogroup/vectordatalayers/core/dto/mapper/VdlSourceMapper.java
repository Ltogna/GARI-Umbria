package com.abacogroup.vectordatalayers.core.dto.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.abacogroup.vectordatalayers.api.VdlSource;
import com.abacogroup.vectordatalayers.db.ntt.VdlSourceEntity;

@Mapper(uses = VdlQueryParamMapper.class)
public interface VdlSourceMapper {

    VdlSourceMapper INSTANCE = Mappers.getMapper(VdlSourceMapper.class);

    @Mapping(source = "datasource", target = "datasource", defaultValue = "VECTOR_DATA_LAYER")
    VdlSource fromEntity(VdlSourceEntity entity);

}
