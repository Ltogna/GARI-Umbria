package com.abacogroup.vectordatalayers.core;

import java.util.List;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.vectordatalayers.api.VdlQueryParam;
import com.abacogroup.vectordatalayers.api.VdlSource;
import com.abacogroup.vectordatalayers.api.req.CreateVdlQueryParamPayload;
import com.abacogroup.vectordatalayers.api.req.CreateVdlSourcePayload;
import com.abacogroup.vectordatalayers.api.req.UpdateVdlSourcePayload;
import com.abacogroup.vectordatalayers.common.resources.ReqContext;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response;

public interface VdlSourceService {
	//	List<VdlSource> getTenantSources(ReqContext reqContext);

	//	VdlSource getSourceData(ReqContext reqContext, String code);

	VdlSource createVdlSource(ReqContext reqContext, CreateVdlSourcePayload payload);

	VdlSource updateVdlSource(ReqContext reqContext, String code, @NotNull @Valid UpdateVdlSourcePayload payload);

	VdlSource getVdlSourceByCode(ReqContext reqContext, String sourceCode);

	InfiniteListResults<VdlSource> getAllVdlSources(ReqContext reqContext, String filterSourceCode, String nextKey, Integer pageSize, String module);

	List<String> getAllVdlDataSources(ReqContext reqContext);

	List<VdlQueryParam> getAllVdlQueryParam(ReqContext reqContext, String sourceCode);

	VdlQueryParam createVdlQueryParam(ReqContext reqContext, String sourceCode, @NotNull @Valid CreateVdlQueryParamPayload payload);

	Response deleteVdlQueryParam(ReqContext reqContext, String sourceCode, String paramName);

	List<String> getAllVdlFillStyles(ReqContext reqContext);

	byte[] getFillStylePreview(Integer width, Integer height, String styleCode, String color);

}
