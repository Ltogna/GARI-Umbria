package com.abacogroup.vectordatalayers.resources;

public final class ResourceConstants {

	private ResourceConstants() {
	}

	public static final String API_PRIV = "/{tenant}/api-priv/v1";
	public static final String API_PUB = "/{tenant}/public/v1";
	
}
