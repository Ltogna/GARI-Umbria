package com.abacogroup.vectordatalayers.db.dao;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DAOContainer {
	
	private I18nDAO i18nDAO;
	private LayerDAO layerDAO;
	private LayerStyleDAO layerStyleDAO;
	private VdlDataSourceDAO vdlDataSourceDAO;
	private VdlSourceDAO vdlSourceDAO;
	private VdlSourceModuleDAO vdlSourceModuleDAO;

}
