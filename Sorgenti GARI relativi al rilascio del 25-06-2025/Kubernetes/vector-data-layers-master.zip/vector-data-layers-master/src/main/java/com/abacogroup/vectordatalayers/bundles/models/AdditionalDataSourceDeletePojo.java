package com.abacogroup.vectordatalayers.bundles.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@ConfigurationBundlePojo(jsonArray = true)
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class AdditionalDataSourceDeletePojo {

	@JsonProperty(required = true)
	@JsonPropertyDescription("datasource identifier")
	@NotBlank
	@Pattern(regexp = "^[\\w-]+$")
	@Size(min = 1, max = 255)
	private String dsKey;

}
