package com.abacogroup.vectordatalayers.api.req;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.locationtech.jts.geom.Geometry;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LayerGeometriesSearchReq {

	@NotNull
	@Schema(implementation = String.class, example = "POLYGON ((100 200, 200 200, 200 100, 100 100, 100 200))")
	private Geometry touchingGeometry;

}
