package com.abacogroup.vectordatalayers.api.req;

import com.abacogroup.vectordatalayers.api.VdlFillStyle;
import com.abacogroup.vectordatalayers.api.VdlGeometryType;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class UpdateVdlSourcePayload {
	
	@Schema(description = "The vdl data scource code")
	@NotBlank
	private String datasource;

	@Schema(description = "The vdl source code decritpion")
	@NotBlank
	private String description;

	@Schema(description = "The sql query")
	@NotBlank
	private String sqlSelect;
	
	@Schema(description = "The geometry column to be used by the spatial filter where clause")
	@NotBlank
	private String filterGeometryColumn;

	@Schema(description = "The output geometry column")
	@NotBlank
	private String geometryColumn;
	
	@Schema(description = "The output column to be used as unique identifier")
	@NotBlank
	private String identifierColumn;
	
	@Schema(description = "The geomtery type can be: LINEAL, POLYGONAL, PUNTAL")
	@NotNull
	private VdlGeometryType geometryType; 

	@Schema(description = "The original shape's spatial reference system. "
						  + "if srs = ‘none’, no re-projection is performed when call wms. "
						  + "if srs = ‘param:{param_name}’ the srs value is taken from the query param {param_name} to be passed to the wms call. ")
	@NotBlank
	private String srs;

	@Schema(description = "The fill color for render, if null then no fill is applied")
	private String fillColor;
	
	@Schema(description = "The fill style")
	private VdlFillStyle fillStyle;
	
	@Schema(description = "The border color for render, if null then no border is drawn")
	private String borderColor;

	@Schema(description = "the border line thick for render")
	@Default
	private int borderThick = 0;
	
	@Schema(description = "The output column to be used for label text, if null then no label is applied")
	private String labelColumn;
	
	@Schema(description = "The size of the font used for the label")
	@Default
	private int fontSize = 0;

	@Schema(description = "The color of the font used for the label")
	private String fontColor;
	
	@Schema(description = "The style code")
	private String styleCode;
	
	@Schema(description = "The style reference column")
	private String styleRefColumn;
	
}
