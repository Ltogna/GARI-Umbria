package com.abacogroup.vectordatalayers.api;

import java.util.function.Function;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

/**
 * https:// jdbi. org/#_named_arguments
 */
public enum QueryParamType {

	Long(Long.class, java.lang.Long::valueOf),
	Double(Double.class, java.lang.Double::valueOf),
	String(String.class, Function.identity()),
	;

	@Getter
	private final Class<?> clazz;
	private final Function<String, ?> converter;

	<T> QueryParamType(Class<T> clazz, Function<String, T> converter) {
		this.clazz = clazz;
		this.converter = converter;
	}

	public Object convert(String value) {
		try {
			if (null == value) {
				return null;
			} else if (StringUtils.isBlank(value) && !java.lang.String.class.equals(clazz)) {
				return null;
			} else {
				return converter.apply(value);
			}
		} catch (Exception e) {
			throw new IllegalArgumentException(java.lang.String.format("Cannot convert %s to %s", value, clazz), e);
		}
	}



}
