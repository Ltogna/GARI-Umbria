package com.abacogroup.vectordatalayers.core.utlis;

import com.abacogroup.vectordatalayers.api.VdlFillStyle;
import com.abacogroup.vectordatalayers.api.VdlSourceData;
import com.abacogroup.vectordatalayers.db.ntt.LayerStyleEntity;
import com.abacogroup.vectordatalayers.db.ntt.VdlSourceEntity;
import com.abacogroup.wms4j.renderer.DrawFeature;
import com.abacogroup.wms4j.renderer.GeometryDrawerStyle;
import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.TexturePaint;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Objects;
import javax.imageio.ImageIO;
import org.locationtech.jts.geom.Geometry;

public class DrawFeatureBuilder {

	private Paint paint;

	private Color penColor;
	private int penThick;

	private Color fontColor;
	private Font font;
	
	protected static final String TRANSPARENT = "#FFFFFF00";

	public DrawFeatureBuilder() {
	}

	public static DrawFeatureBuilder fromSource(VdlSourceData sourceData) {
		DrawFeatureBuilder builder = new DrawFeatureBuilder();
		return builder.withStyle(sourceData);
	}

	public static DrawFeatureBuilder fromSource(VdlSourceEntity sourceData, Boolean outline, Boolean fill) {
		DrawFeatureBuilder builder = new DrawFeatureBuilder();

		if (null == sourceData) {
			return builder;
		}

		return builder
				.withPaint(fill ? sourceData.getFillColor() : TRANSPARENT, sourceData.getFillStyle())
				.withBorder(outline ? sourceData.getBorderColor() : TRANSPARENT, sourceData.getBorderThick())
				.withFont(sourceData.getFontColor(), sourceData.getFontSize());
	}
	
	public static DrawFeatureBuilder fromLayerStyle(LayerStyleEntity layerStyle, VdlFillStyle fillStyle, Boolean outline, Boolean fill) {
		DrawFeatureBuilder builder = new DrawFeatureBuilder();
		
		if (null == layerStyle) {
			return builder;
		}
		
		return builder
				.withPaint(fill ? layerStyle.getFillColor() : TRANSPARENT, fillStyle)
				.withBorder(outline ? layerStyle.getBorderColor() : TRANSPARENT, layerStyle.getBorderThick())
				.withFont(layerStyle.getFontColor(), layerStyle.getFontSize());
	}

	@Deprecated
	public DrawFeatureBuilder withStyle(VdlSourceData sourceData) {
		if (null != sourceData) {
			withPaint(sourceData.getFillColor(), sourceData.getFillStyle());
			withBorder(sourceData.getBorderColor(), sourceData.getBorderThick());
			withFont(sourceData.getFontColor(), sourceData.getFontSize());
		}

		return this;
	}

	public DrawFeatureBuilder withFont(String fontColor, int fontSize) {
		this.fontColor = this.createColor(fontColor);
		this.font = this.getFont(fontSize);

		return this;
	}

	public DrawFeatureBuilder withBorder(String borderColor, int borderThick) {
		this.penColor = this.createColor(borderColor);
		this.penThick = borderThick;

		return this;
	}

	public DrawFeatureBuilder withPaint(String fillColor, VdlFillStyle fillStyle) {
		Color color = this.createColor(fillColor);

		if (null != fillStyle) {
			this.paint = this.createTexture(fillStyle, color);
		} else {
			this.paint = color;
		}

		return this;
	}

	public DrawFeature build(Geometry geometry, String label, Boolean showLabels) {

		DrawFeature df = new DrawFeature(geometry);
		
		if (showLabels) {
			df.setText(label);
		}

		df.setSpecificStyle(new GeometryDrawerStyle(
				penColor,
				paint,
				penThick,
				font,
				null == fontColor ? Color.BLACK : fontColor));

		return df;
	}

	private TexturePaint createTexture(VdlFillStyle fillStyle, Color color) {
		BufferedImage texture;
		try {
			texture = ImageIO.read(Objects.requireNonNull(this.getClass().getClassLoader().getResource(fillStyle.getTextureFile())));
		} catch (NullPointerException | IOException e) {
			throw new IllegalArgumentException(String.format("missing pattern image for %s", fillStyle), e);
		}

		int width = texture.getWidth();
		int height = texture.getHeight();

		int newColor = color == null ? 0 : color.getRGB();

		for (int x = 0; x < width; x++) {
			for (int y = 0; y < height; y++) {

				int alpha = (texture.getRGB(x, y) >> 24) & 0xff;
				if (alpha != 0) {
					texture.setRGB(x, y, (alpha << 24) | (newColor & 0x00ffffff));
				}
			}
		}

		return new TexturePaint(texture, new Rectangle(0, 0, texture.getWidth(), texture.getHeight()));
	}

	private Color createColor(String rgbaCode) {
		if (null != rgbaCode && !rgbaCode.isEmpty()) {
			try {
				int r = Integer.parseInt(rgbaCode.substring(1, 3), 16);
				int g = Integer.parseInt(rgbaCode.substring(3, 5), 16);
				int b = Integer.parseInt(rgbaCode.substring(5, 7), 16);
				int a = rgbaCode.length() != 9 ? 255 : Integer.parseInt(rgbaCode.substring(7, 9), 16);

				return new Color(r, g, b, a);
			} catch (IndexOutOfBoundsException | NumberFormatException ioobe) {
				return null;
			}
		}
		return null;
	}

	private Font getFont(int fontSize) {
		return new Font("Arial", Font.PLAIN, fontSize);
	}

}
