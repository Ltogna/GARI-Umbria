package com.abacogroup.vectordatalayers.common.resources.req;

import com.abacogroup.jdbi.criteria.Criteria;
import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.vectordatalayers.common.resources.ReqContext;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;

public interface BaseSearchReq {

	@JsonIgnore
	@Schema(hidden = true)
	int getPageSize();

	@JsonIgnore
	@Schema(hidden = true)
	Criteria getCriteria(ReqContext reqContext);

	@JsonIgnore
	@Schema(hidden = true)
	OrderBy getSort();
}
