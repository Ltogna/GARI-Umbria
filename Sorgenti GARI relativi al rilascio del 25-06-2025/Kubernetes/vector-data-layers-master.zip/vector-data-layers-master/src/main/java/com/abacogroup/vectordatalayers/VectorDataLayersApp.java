package com.abacogroup.vectordatalayers;

import static com.abacogroup.vectordatalayers.core.DatasourceHelper.jdbiName;

import com.abacogroup.bundles.initializer.BundleInitServiceBuilder;
import com.abacogroup.bundles.listener.ListenerBuilder;
import com.abacogroup.bundles.listener.configdata.ProcessorOrderPolicyEnum;
import com.abacogroup.bundles.listener.configdata.builder.ConfigDataConsumerBuilder;
import com.abacogroup.bundles.listener.tenant.builder.NewTenantEventConsumerBuilder;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.SsoAuthorizer;
import com.abacogroup.tracing.dropwizard.AbacoApplication;
import com.abacogroup.tracing.jaxrs.client.AddRequestId;
import com.abacogroup.vectordatalayers.VectorDataLayersConfig.BundleConfig;
import com.abacogroup.vectordatalayers.VectorDataLayersConfig.RabbitmqConfig;
import com.abacogroup.vectordatalayers.bundles.config.ConfigSourceProcessor;
import com.abacogroup.vectordatalayers.bundles.config.DataSourceProcessor;
import com.abacogroup.vectordatalayers.bundles.config.LayerStyleProcessor;
import com.abacogroup.vectordatalayers.bundles.config.i18n.I18nHelper;
import com.abacogroup.vectordatalayers.bundles.tenant.I18nTenantMessageProcessor;
import com.abacogroup.vectordatalayers.common.jackson.WKTGeometryDeserializer;
import com.abacogroup.vectordatalayers.common.jackson.WKTGeometrySerializer;
import com.abacogroup.vectordatalayers.core.DatasourceHelper;
import com.abacogroup.vectordatalayers.core.JdbiHelper;
import com.abacogroup.vectordatalayers.core.LayerService;
import com.abacogroup.vectordatalayers.core.VdlSourceService;
import com.abacogroup.vectordatalayers.core.VdlSourceV1Service;
import com.abacogroup.vectordatalayers.core.WmsSynchronizer;
import com.abacogroup.vectordatalayers.core.impl.LayerServiceImpl;
import com.abacogroup.vectordatalayers.core.impl.VdlSourceServiceImpl;
import com.abacogroup.vectordatalayers.core.impl.VdlSourceV1ServiceImpl;
import com.abacogroup.vectordatalayers.db.dao.DAOContainer;
import com.abacogroup.vectordatalayers.db.dao.I18nDAO;
import com.abacogroup.vectordatalayers.db.dao.LayerDAO;
import com.abacogroup.vectordatalayers.db.dao.LayerStyleDAO;
import com.abacogroup.vectordatalayers.db.dao.VdlDataSourceDAO;
import com.abacogroup.vectordatalayers.db.dao.VdlSourceDAO;
import com.abacogroup.vectordatalayers.db.dao.VdlSourceModuleDAO;
import com.abacogroup.vectordatalayers.resources.DevtoolsResource;
import com.abacogroup.vectordatalayers.resources.VdlSourceResources;
import com.abacogroup.vectordatalayers.resources.pub.LayerPublicResources;
import com.abacogroup.vectordatalayers.resources.pub.VdlSourcePublicResources;
import com.abacogroup.wms4j.resources.WmsResourceTenantAware;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.db.PooledDataSourceFactory;
import io.dropwizard.forms.MultiPartBundle;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import io.dropwizard.migrations.MigrationsBundle;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import io.swagger.v3.oas.integration.ClasspathOpenApiConfigurationLoader;
import io.swagger.v3.oas.integration.api.OpenAPIConfiguration;
import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration.Dynamic;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import java.io.IOException;
import java.util.EnumSet;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeoutException;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.jdbi.v3.core.Jdbi;
import org.locationtech.jts.geom.Geometry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VectorDataLayersApp extends AbacoApplication<VectorDataLayersConfig> {

	private static final Logger log = LoggerFactory.getLogger(VectorDataLayersApp.class);

	@Override
	public String getName() {
		return "vector-data-layers";
	}

	@Override
	public void initialize(Bootstrap<VectorDataLayersConfig> bootstrap) {
		bootstrap.addBundle(new MigrationsBundle<>() {
			@Override
			public PooledDataSourceFactory getDataSourceFactory(VectorDataLayersConfig configuration) {
				return configuration.getDatabase();
			}
		});

		SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
				new EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);
		bootstrap.addBundle(new MultiPartBundle());
	}

	@Override
	public void doRun(VectorDataLayersConfig configuration, Environment environment) throws Exception {
		ObjectMapper objectMapper = environment.getObjectMapper();
		configureObjectMapper(objectMapper);

		var jersey = environment.jersey();

		Jdbi jdbi = createJdbi(configuration.getDatabase(), environment, jdbiName(getName()), configuration.isEnableSpatialVectorAcceleration());
		
		DAOContainer daoContainer = DAOContainer.builder()
				.i18nDAO(jdbi.onDemand(I18nDAO.class))
				.vdlSourceDAO(jdbi.onDemand(VdlSourceDAO.class))
				.vdlDataSourceDAO(jdbi.onDemand(VdlDataSourceDAO.class))
				.layerStyleDAO(jdbi.onDemand(LayerStyleDAO.class))
				.vdlSourceModuleDAO(jdbi.onDemand(VdlSourceModuleDAO.class))
				.build();

		JdbiHelper jdbiHelper = this.register(new JdbiHelper(daoContainer.getVdlDataSourceDAO(), jdbi));
		DatasourceHelper datasourceHelper = this.register(new DatasourceHelper(daoContainer.getVdlDataSourceDAO()));

		this.createAdditionalJdbis(jdbiHelper, datasourceHelper.getAdditionalDataSources(), environment, configuration.isEnableSpatialVectorAcceleration());
		this.createAdditionalJdbis(jdbiHelper, configuration.getAdditionalDataSources(), environment, configuration.isEnableSpatialVectorAcceleration());

		jdbiHelper.datasourceCheck();

		VdlSourceService vdlSourceService = this.register(new VdlSourceServiceImpl(daoContainer));
		VdlSourceV1Service vdlSourceV1Service = this.register(new VdlSourceV1ServiceImpl(vdlSourceService));
		LayerService layerService = this.register(new LayerServiceImpl(daoContainer, datasource -> jdbiHelper.getDao(datasource, LayerDAO.class)));

		jersey.register(new VdlSourceResources(vdlSourceService));
		jersey.register(new VdlSourcePublicResources(vdlSourceV1Service));
		jersey.register(new LayerPublicResources(layerService));
		WmsResourceTenantAware wmsResource = this.createWmsResource(layerService);
		jersey.register(wmsResource);

		Sso2Client sso2Client = initSso2Client(configuration, environment);
		AuthUtils.installAuthFilter(environment, sso2Client, new SsoAuthorizer(sso2Client));
		initMultitenantCapabilities(jersey);

        initOpenApi(jersey);
        setupCORS(environment);

		Connection rabbitmqConnection = createRabbitmqConnection(configuration.getRabbitmqConfig());
		this.startWmsSynchronizer(configuration, environment, datasourceHelper, jdbiHelper,
				layerService, wmsResource, rabbitmqConnection);
		createBundleInfrastructure(rabbitmqConnection, jdbi, jdbiHelper, datasourceHelper, daoContainer,
				objectMapper, configuration.getBundleConfig());

		if (configuration.isDevToolsEnabled()) {
			log.info("DEVTOOLS ENABLED");
			jersey.register(new DevtoolsResource(rabbitmqConnection, jdbi));
		}

		environment.lifecycle().addServerLifecycleListener( server -> {
				log.info("Server started");
				listener.event();
		});
	}

	protected Connection createRabbitmqConnection(RabbitmqConfig rabbitmqConfig) {
		if (rabbitmqConfig == null)
		{
			return null;
		}

		if (StringUtils.isBlank(rabbitmqConfig.getHost()))
		{
			return null;
		}

		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(rabbitmqConfig.getHost());

		if (!StringUtils.isBlank(rabbitmqConfig.getUser()))
		{
			factory.setUsername(rabbitmqConfig.getUser());
		}
		if (!StringUtils.isBlank(rabbitmqConfig.getPassword()))
		{
			factory.setPassword(rabbitmqConfig.getPassword());
		}
		if (!StringUtils.isBlank(rabbitmqConfig.getVirtualhost()))
		{
			factory.setVirtualHost(rabbitmqConfig.getVirtualhost());
		}
		if ((rabbitmqConfig.getPort()<0)||(rabbitmqConfig.getPort()>65535))
		{
			log.error("Invalid Port: "+rabbitmqConfig.getPort());
			return null;
		}
		factory.setPort(rabbitmqConfig.getPort());		
		factory.setAutomaticRecoveryEnabled(true);

		try
		{
			return factory.newConnection();
		}
		catch (IOException | TimeoutException e)
		{
			throw new IllegalStateException("Cannot connect to rabbit mq", e);
		}
	}

	protected void startWmsSynchronizer(VectorDataLayersConfig configuration, Environment environment,
			DatasourceHelper datasourceHelper, JdbiHelper jdbiHelper, LayerService layerService, WmsResourceTenantAware wmsResource, Connection rabbitmqConnection) throws IOException {
		WmsSynchronizer wmsSynchronizer = new WmsSynchronizer(configuration, environment, datasourceHelper, jdbiHelper, layerService, wmsResource, rabbitmqConnection);
		wmsSynchronizer.start();
	}
	
	protected void createBundleInfrastructure(Connection rabbitmqConnection, Jdbi jdbi, JdbiHelper jdbiHelper, DatasourceHelper datasourceHelper,
			DAOContainer daoContainer, ObjectMapper objectMapper, BundleConfig bundleConfig)
	{
		if (rabbitmqConnection == null)
		{
			log.info("NOT CONNECTED TO RABBITMQ; bundles infrastructure is disabled");
			return;
		}
		try
		{
			I18nHelper i18nHelper = this.register(new I18nHelper(daoContainer.getI18nDAO()));

			ListenerBuilder.newBuilder(rabbitmqConnection)
				.withConfigDataConsumer(ConfigDataConsumerBuilder.newBuilder(jdbi, rabbitmqConnection)
						.route(getName())
						.processors(
								this.register(new LayerStyleProcessor(daoContainer, objectMapper)),
								this.register(new DataSourceProcessor(daoContainer, datasourceHelper, objectMapper)),
								this.register(new ConfigSourceProcessor(daoContainer, i18nHelper, jdbiHelper, objectMapper))
								)
						.withOrderPolicy(ProcessorOrderPolicyEnum.PROCESSOR)
						.build())
				.withNewTenantEventConsumer(NewTenantEventConsumerBuilder.newBuilder(jdbi)
						.route(getName())
						.processor(this.register(new I18nTenantMessageProcessor(daoContainer.getI18nDAO())))
						.build())
				.buildListener()
				.start();

			if (null != bundleConfig) {
				BundleInitServiceBuilder.producer(rabbitmqConnection)
						.configLocation(bundleConfig.getConfigLocation())
						//.baseTempDir()
						.build()
						.start();
			}
		}
		catch (Exception e)
		{
			throw new IllegalStateException("Error starting rabbitmq listener", e);
		}
	}	

	private Sso2Client initSso2Client(VectorDataLayersConfig configuration, Environment environment) {
		JerseyClientConfiguration jerseyConfig = configuration.getJerseyClient();

		final Client client = new JerseyClientBuilder(environment)
				//				.using((HostnameVerifier) (hostname, session) -> true)
				.using(jerseyConfig)
				.build("sso2-client");
		client.register(new AddRequestId());

		WebTarget webTarget = client.target(configuration.getSso2Config().getUrl());
		return new Sso2Client(configuration.getSso2Config().getTokensAuthSecret(), webTarget);
	}

	protected WmsResourceTenantAware createWmsResource(LayerService wmsService) {
		WmsResourceTenantAware wmsResource = new WmsResourceTenantAware();
		wmsService.getWMSLayers().forEach(wmsResource::addLayer);

		return wmsResource;
	}

	protected Jdbi createJdbi(DataSourceFactory dsf, final Environment environment, String name, boolean enableSpatialVectorAcceleration) {
		return DatasourceHelper.createJdbi(dsf, environment, name, enableSpatialVectorAcceleration);
	}

	protected void createAdditionalJdbis(JdbiHelper jdbiHelper, Map<String, DataSourceFactory> additionalDatasources,
			Environment environment, boolean enableSpatialVectorAcceleration) {
		if (null == additionalDatasources) {
			return;
		}

		additionalDatasources.forEach((name, dsf) -> {
			Jdbi jdbi = this.createJdbi(dsf, environment, jdbiName(name), enableSpatialVectorAcceleration);

			jdbiHelper.putIfAbsent(name, jdbi);
		});
	}

	private void initMultitenantCapabilities(JerseyEnvironment jersey) {
		jersey.register(new MultitenantFilter("tenantId"));
	}

	protected <T> T register(T service) {
		return service;
	}

	protected void initOpenApi(JerseyEnvironment jersey) throws IOException {
		OpenAPIConfiguration oasConfig = new ClasspathOpenApiConfigurationLoader()
				.load("openapi-configuration.yaml");
		jersey.register(new OpenApiResource().openApiConfiguration(oasConfig));
	}

	private void setupCORS(Environment environment) {
		Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,DELETE,PATCH");
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

	protected void configureObjectMapper(ObjectMapper objectMapper) {
		objectMapper.registerModule(new JavaTimeModule());
		objectMapper
				.setTimeZone(TimeZone.getDefault())
				.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

		SimpleModule module = new SimpleModule("custom-deserializers", Version.unknownVersion());
		module.addSerializer(Geometry.class, new WKTGeometrySerializer());
		module.addDeserializer(Geometry.class, new WKTGeometryDeserializer());
		objectMapper.registerModule(module);
	}

	public static void main(String[] args) {
		try {
			new VectorDataLayersApp().run(args);
		} catch (Exception e) {
			log.error("Error during run vector-data-layers application: ", e);
			System.exit(1);
		}
	}
	public static interface Listener {
		void event();
	}
	
	private Listener listener = ()->{};
	public void setStartListener(Listener listener) {
		this.listener = listener; 
		
	}
	

}
