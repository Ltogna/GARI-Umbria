package com.abacogroup.vectordatalayers.resources;

import java.util.List;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.vectordatalayers.api.VdlQueryParam;
import com.abacogroup.vectordatalayers.api.VdlSource;
import com.abacogroup.vectordatalayers.api.req.CreateVdlQueryParamPayload;
import com.abacogroup.vectordatalayers.api.req.CreateVdlSourcePayload;
import com.abacogroup.vectordatalayers.api.req.UpdateVdlSourcePayload;
import com.abacogroup.vectordatalayers.common.resources.ReqContext;
import com.abacogroup.vectordatalayers.core.VdlSourceService;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Timed
@Path(ResourceConstants.API_PRIV + "/vdl")
@Tag(name = "Vector Data Layers Sources", description = "Operations on Vector Data Layers Sources")
public class VdlSourceResources {
	private final VdlSourceService vdlSourceService;

	public VdlSourceResources(VdlSourceService vdlSourceService) {

		this.vdlSourceService = vdlSourceService;
	}

	@POST
	@Path("/sources")
	@RolesAllowed({ "VECTOR_DATA_LAYERS|WRITE" })
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Create source", description = "Create source")
	@ApiResponse(responseCode = "200", description = "vector data layer source created", useReturnTypeSchema = true)
	public VdlSource createVdlSource(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@NotNull @Valid CreateVdlSourcePayload payload) {
		ReqContext reqContext = new ReqContext(user, lang);

		return vdlSourceService.createVdlSource(reqContext, payload);
	}

	@PUT
	@RolesAllowed({ "VECTOR_DATA_LAYERS|WRITE" })
	@Path("/sources/{code}")
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Update source", description = "Update source")
	@ApiResponse(responseCode = "200", description = "vector data layer source updated", useReturnTypeSchema = true)
	public VdlSource updateVdlSource(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "The unique code of the vector data layer source") @PathParam("code") String sourceCode,
			@NotNull @Valid UpdateVdlSourcePayload payload) {
		ReqContext reqContext = new ReqContext(user, lang);

		return vdlSourceService.updateVdlSource(reqContext, sourceCode, payload);
	}

	@GET
	@Path("/sources/{code}")
	@RolesAllowed({ "VECTOR_DATA_LAYERS|READ", "VECTOR_DATA_LAYERS|WRITE" })
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "get vdl source", description = "get vdl source by code")
	@ApiResponse(responseCode = "200", description = "get vdl source by code", useReturnTypeSchema = true)
	public VdlSource getVdlSourceByCode(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "The unique code of the vector data layer source") @PathParam("code") String sourceCode) {
		ReqContext reqContext = new ReqContext(user, lang);

		return vdlSourceService.getVdlSourceByCode(reqContext, sourceCode);
	}

	@GET
	@Path("/sources")
	@RolesAllowed({ "VECTOR_DATA_LAYERS|READ", "VECTOR_DATA_LAYERS|WRITE" })
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "get vdl sources", description = "get vdl source")
	@ApiResponse(responseCode = "200", description = "get vdl source by code", useReturnTypeSchema = true)
	public InfiniteListResults<VdlSource> getAllVdlSources(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "The unique code of the vector data layer source") @QueryParam("filter") String filterSourceCode,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("next_key") String nextKey,
			@Parameter(description = "Page size for infinite pagination") @QueryParam("page_size") @DefaultValue("10") Integer pageSize) {
		ReqContext reqContext = new ReqContext(user, lang);

		return vdlSourceService.getAllVdlSources(reqContext, filterSourceCode, nextKey, pageSize, null);
	}

	@POST
	@Path("/sources/{code}/params")
	@RolesAllowed({ "VECTOR_DATA_LAYERS|WRITE" })
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Create source query parameter", description = "Create source query parameter")
	@ApiResponse(responseCode = "200", description = "source query parameter created", useReturnTypeSchema = true)
	public VdlQueryParam createVdlQueryParam(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "The unique code of the vector data layer source") @PathParam("code") String sourceCode,
			@NotNull @Valid CreateVdlQueryParamPayload payload) {
		ReqContext reqContext = new ReqContext(user, lang);

		return vdlSourceService.createVdlQueryParam(reqContext, sourceCode, payload);
	}

	@GET
	@Path("/sources/{code}/params")
	@RolesAllowed({ "VECTOR_DATA_LAYERS|READ", "VECTOR_DATA_LAYERS|WRITE" })
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Get all source query parameters", description = "Get all source query parameters")
	@ApiResponse(responseCode = "200", description = "Get all source query parameters", useReturnTypeSchema = true)
	public List<VdlQueryParam> getAllVdlQueryParam(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "The unique code of the vector data layer source") @PathParam("code") String sourceCode) {
		ReqContext reqContext = new ReqContext(user, lang);

		return vdlSourceService.getAllVdlQueryParam(reqContext, sourceCode);
	}

	@DELETE
	@Path("/sources/{code}/params")
	@RolesAllowed({ "VECTOR_DATA_LAYERS|WRITE" })
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "delete source query parameter by name", description = "delete source query parameter by name")
	@ApiResponse(responseCode = "200", description = "source query parameter deleted", useReturnTypeSchema = true)
	public Response deleteVdlQueryParam(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "The unique code of the vector data layer source") @PathParam("code") String sourceCode,
			@Parameter(description = "The custom source query param name") @QueryParam("param_name") String paramName) {
		ReqContext reqContext = new ReqContext(user, lang);

		return vdlSourceService.deleteVdlQueryParam(reqContext, sourceCode, paramName);
	}

	@GET
	@Path("/data-sources")
	@RolesAllowed({ "VECTOR_DATA_LAYERS|READ", "VECTOR_DATA_LAYERS|WRITE" })
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Get List of all Data sources", description = "Get List of all Data sources")
	@ApiResponse(responseCode = "200", description = "Get List of all Data sources", useReturnTypeSchema = true)
	public List<String> getAllVdlDataSources(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId) {
		ReqContext reqContext = new ReqContext(user, lang);

		return vdlSourceService.getAllVdlDataSources(reqContext);
	}

	@GET
	@Path("/fill-styles")
	@RolesAllowed({ "VECTOR_DATA_LAYERS|READ", "VECTOR_DATA_LAYERS|WRITE" })
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Get List of all fill styles", description = "Get List of all fill styles available")
	@ApiResponse(responseCode = "200", description = "Get List of all fill styles", useReturnTypeSchema = true)
	public List<String> getAllVdlFillStyles(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId) {
		ReqContext reqContext = new ReqContext(user, lang);

		return vdlSourceService.getAllVdlFillStyles(reqContext);
	}

	@GET
	@Produces("image/png")
	@Path("/fill-styles/{style}.png")
	@RolesAllowed({ "VECTOR_DATA_LAYERS|READ", "VECTOR_DATA_LAYERS|WRITE" })
	@Operation(summary = "Get a preview of a fille style", description = "Get a preview of a fille style")
	@ApiResponse(responseCode = "200", description = "Get List of all fill styles", useReturnTypeSchema = true)
	public Response wmsRequest(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The fill style") @PathParam("style") String styleCode,
			@Parameter(description = "Image width (default 100)") @QueryParam("width") @DefaultValue("100") Integer width,
			@Parameter(description = "Image height (default 100)") @QueryParam("height") @DefaultValue("100") Integer height,
			@Parameter(description = "Color (#RRGGBB, default #000000)") @QueryParam("color") @DefaultValue("#000000") String color) {

		byte b[] = vdlSourceService.getFillStylePreview(width, height, styleCode, color);
		return Response.ok(b).build();

	}

}
