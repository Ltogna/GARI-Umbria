package com.abacogroup.vectordatalayers.api.req;

import com.abacogroup.vectordatalayers.api.QueryParamType;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class CreateVdlQueryParamPayload {

	@Schema(description = "The custom query param name")
	@NotBlank
	private String queryParamName;

	@Schema(description = "query param type")
	@NotNull
	private QueryParamType type;
	
	@Schema(description = "free text description")
	private String description;

}
