package com.abacogroup.vectordatalayers.common.resources;

public interface ResourceConstants {

	int DEFAULT_PAGE_SIZE = 10;
	int MAX_PAGE_SIZE = 100;

	String API_PRIV = "/{tenant}/api-priv/v1";
}
