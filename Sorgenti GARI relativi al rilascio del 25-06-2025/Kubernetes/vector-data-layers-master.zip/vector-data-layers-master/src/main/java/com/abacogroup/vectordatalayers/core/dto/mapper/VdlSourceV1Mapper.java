package com.abacogroup.vectordatalayers.core.dto.mapper;

import com.abacogroup.vectordatalayers.api.VdlSource;
import com.abacogroup.vectordatalayers.api.pub.VdlSourceV1;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(uses = VdlQueryParamV1Mapper.class)
public interface VdlSourceV1Mapper {

    VdlSourceV1Mapper INSTANCE = Mappers.getMapper(VdlSourceV1Mapper.class);

    VdlSourceV1 toResV1(VdlSource entity);

}
