package com.abacogroup.vectordatalayers.core.dto;

import static com.abacogroup.vectordatalayers.core.impl.LayerServiceImpl.SRS_NONE;

import jakarta.ws.rs.core.MultivaluedMap;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomWMSParams {

	// nuovi query params per wms vanno documentati in resources/openapi-configuration.yaml
	public static final String PARAM_LABELS = "labels";
	public static final String PARAM_OUTLINE = "outline";
	public static final String PARAM_FILL = "fill";
	public static final String PARAM_SRS = "SRS";
	public static final String PARAM_SRS_ALIAS = "srs";

	private Boolean labels;
	private Boolean outline;
	private Boolean fill;
	private String requestedSrs;

	public static CustomWMSParams fromQueryParams(MultivaluedMap<String, String> queryParams) {
		CustomWMSParams customWMSParams = new CustomWMSParams();

		customWMSParams.setLabels(customWMSParams.buildBooleanUrlQueryParam(queryParams, PARAM_LABELS));
		customWMSParams.setOutline(customWMSParams.buildBooleanUrlQueryParam(queryParams, PARAM_OUTLINE));
		customWMSParams.setFill(customWMSParams.buildBooleanUrlQueryParam(queryParams, PARAM_FILL));
		customWMSParams.setRequestedSrs(customWMSParams.buildRequestedSrs(queryParams));

		return customWMSParams;
	}

	private Boolean buildBooleanUrlQueryParam(MultivaluedMap<String, String> urlQParams, String paramKey) {
		return urlQParams.getFirst(paramKey) == null ? Boolean.TRUE : Boolean.TRUE.toString().equalsIgnoreCase(urlQParams.getFirst(paramKey));
	}

	private String buildRequestedSrs(MultivaluedMap<String, String> queryParameters) {
		return Optional.ofNullable(queryParameters)
				.map(qp -> qp.getFirst(PARAM_SRS))
				.or(() -> Optional.ofNullable(queryParameters)
						.map(qp -> qp.getFirst(PARAM_SRS_ALIAS)))
				.map(StringUtils::trimToNull)
				.filter(srs -> !SRS_NONE.equalsIgnoreCase(srs))
				.orElse(null);
	}
}
