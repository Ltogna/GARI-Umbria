package com.abacogroup.vectordatalayers.bundles.config;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.vectordatalayers.bundles.models.LayerStyleList;
import com.abacogroup.vectordatalayers.bundles.models.LayerStyleMessage;
import com.abacogroup.vectordatalayers.db.dao.DAOContainer;
import com.abacogroup.vectordatalayers.db.dao.LayerStyleDAO;
import com.abacogroup.vectordatalayers.db.ntt.LayerStyleEntity;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validation;
import jakarta.validation.ValidatorFactory;

public class LayerStyleProcessor implements ConfigMessageProcessor {
	private static final Logger log = LoggerFactory.getLogger(LayerStyleProcessor.class);
	private static final String DELETE = "delete";
	private static final String UPSERT = "upsert";
	private static final String BUNDLE_USERID = "bundle";

	private final LayerStyleDAO layerStyleDAO;

	private final ObjectMapper objectMapper;

	public LayerStyleProcessor(DAOContainer daoContainer, ObjectMapper objectMapper) {
		this.layerStyleDAO = daoContainer.getLayerStyleDAO();
		this.objectMapper = objectMapper;
	}


	@Override
	public String getDomainName() {
		return "layer-styles";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		log.debug("Ricevuto {}",message);	
		if (message==null) {
			return;
		}

		Map<String, List<Path>> filesByOperation = collectFilesByOperation(message);

		filesByOperation.getOrDefault(DELETE, new ArrayList<>())
		.forEach(path -> this.onDelete(message.getTenantId(), path));
		filesByOperation.getOrDefault(UPSERT, new ArrayList<>())
		.forEach(path -> this.onUpsert(message.getTenantId(), path));
	}

	private void onUpsert(String tenantId, Path currentPath) {
		try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory()) {
			log.debug("Esecuzione di {}", currentPath);

			LayerStyleList layerStyleList = objectMapper.readValue(currentPath.toFile(), LayerStyleList.class);
			Set<ConstraintViolation<LayerStyleList>> constraintViolations = validatorFactory.getValidator().validate(layerStyleList);
			if (!constraintViolations.isEmpty()) {
				throw new ConstraintViolationException(constraintViolations);
			}

			if(layerStyleList == null || layerStyleList.getLayerStyles() == null || layerStyleList.getLayerStyles().isEmpty()) {
				throw new BundleException(String.format("Empty layer styles in %s", currentPath));
			}

			layerStyleList.getLayerStyles().forEach(layerStyle -> {
				this.delete(tenantId, layerStyle);
				this.insert(tenantId, layerStyle);
			});

			log.debug("Processato {}", currentPath);
		} catch (Exception e) {
			throw new BundleException(String.format("Error processing file %s for tenant %s", currentPath, tenantId), e);
		}
	}

	private void onDelete(String tenantId, Path currentPath) {
		try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory()) {
			log.debug("Esecuzione di {}", currentPath);

			LayerStyleList layerStyleList = objectMapper.readValue(currentPath.toFile(), LayerStyleList.class);
			Set<ConstraintViolation<LayerStyleList>> constraintViolations = validatorFactory.getValidator().validate(layerStyleList);
			if (!constraintViolations.isEmpty()) {
				throw new ConstraintViolationException(constraintViolations);
			}

			if(layerStyleList == null || layerStyleList.getLayerStyles() == null || layerStyleList.getLayerStyles().isEmpty()) {
				throw new BundleException(String.format("Empty layer styles in %s", currentPath));
			}

			layerStyleList.getLayerStyles().forEach(layerStyle -> delete(tenantId, layerStyle));

			log.debug("Processato {}", currentPath);
		} catch (Exception e) {
			throw new BundleException(String.format("Error processing file %s for tenant %s", currentPath, tenantId), e);
		}
	}

	private void insert(String tenantId, LayerStyleMessage layerStyle) {
		if (layerStyle.getStyles() == null || layerStyle.getStyles().isEmpty()) {
			throw new BundleException(String.format("Layer style code %s with empty style list", layerStyle.getStyleCode()));
		}

		layerStyle.getStyles().forEach(styleCode -> {
			LayerStyleEntity entity = LayerStyleEntity.builder()
					.styleCode(layerStyle.getStyleCode())
					.refCode(styleCode.getRefCode())
					.fillColor(styleCode.getFillColor())
					.borderColor(styleCode.getBorderColor())
					.borderThick(styleCode.getBorderThick())
					.fontColor(styleCode.getFontColor())
					.fontSize(styleCode.getFontSize())
					.build();

			layerStyleDAO.insert(tenantId, BUNDLE_USERID, entity);
		});
	}

	private void delete(String tenantId, LayerStyleMessage layerStyle) {
		layerStyleDAO.deleteByTenantAndStyleCode(tenantId, BUNDLE_USERID, layerStyle.getStyleCode());
	}

	private Map<String, List<Path>> collectFilesByOperation(ConfigDataMessage message) {
		Function<String, String> groupingPredicate = x -> x.endsWith(".delete.json") ? DELETE : UPSERT;

		return message.getConfigFiles().stream()
				.filter(p -> FilenameUtils.isExtension(FilenameUtils.getName(p.getFileName().toString()).toLowerCase(), "json"))
				.collect(Collectors.groupingBy(x -> groupingPredicate.apply(x.toString()),
						Collectors.toCollection(ArrayList::new)));
	}

}
