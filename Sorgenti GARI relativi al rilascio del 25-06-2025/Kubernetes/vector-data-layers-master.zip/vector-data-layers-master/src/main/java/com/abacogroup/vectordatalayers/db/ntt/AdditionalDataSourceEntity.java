package com.abacogroup.vectordatalayers.db.ntt;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AdditionalDataSourceEntity {

	private String dsKey;
	private String driverClass;
	private String dbUrl;
	private String dbUser;
	private String dbPasswordEncoded;
	private String validationQuery;
	private Integer minSize;
	private Integer initialSize;

}
