package com.abacogroup.vectordatalayers.db.ntt;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class LayerStyleEntity {

	private String styleCode;
	private String refCode;
	private String fillColor;
	private String borderColor;
	private int borderThick;
	private String fontColor;
	private int fontSize;
	
}