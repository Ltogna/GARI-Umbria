package com.abacogroup.vectordatalayers.bundles.config.i18n;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class I18nMap {

	@JsonAnyGetter
	@JsonAnySetter
	private Map<String, String> i18nMap = new HashMap<>();

	@JsonIgnore
	public Set<I18nEntry> getI18n() {
		return i18nMap.entrySet().stream()
				.map(e -> I18nEntry.builder().setLang(e.getKey()).setCode(e.getValue()).build())
				.collect(Collectors.toSet());
	}

}
