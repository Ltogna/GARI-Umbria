package com.abacogroup.vectordatalayers.bundles.models;

import java.util.List;

import com.abacogroup.vectordatalayers.api.VdlFillStyle;
import com.abacogroup.vectordatalayers.api.VdlGeometryType;
import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonClassDescription;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

@ConfigurationBundlePojo()
@JsonClassDescription("identify the data part of a Source")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
public class SourceData {

	@JsonProperty(required = true)
	@JsonPropertyDescription("Se sql select to obtain records for the source.Must contain a placeholder string {spatial_where_clause}")
	@NotBlank
	private String sqlSelect;
	
	@JsonProperty(required = true)
	@JsonPropertyDescription("The geometry column to be used by the spatial filter where clause")
	@NotBlank
	private String filterGeometryColumn;
	
	@JsonProperty(required = true)
	@JsonPropertyDescription("The output geometry column")
	@NotBlank
	private String geometryColumn;
	
	@JsonProperty(required = true)
	@JsonPropertyDescription("The output column to be used as unique identifier")
	@NotBlank
	private String identifierColumn;
	
	@JsonPropertyDescription("The output column to be used for label text, if null then no label is applied")
	private String labelColumn;

	@JsonPropertyDescription("datasource identifier from additional datasources. null values will use application datasource")
	private String datasource;

	@JsonPropertyDescription("The fill color for render")
	@Pattern(regexp = "^#[a-fA-F0-9]{6}([a-fA-F0-9]{2})?$")
	private String fillColor;
	
	@JsonPropertyDescription("geometry fill pattern. null value will use a uniform fill")
	private VdlFillStyle fillStyle;
	
	@JsonPropertyDescription("The border color for render")
	@Pattern(regexp = "^#[a-fA-F0-9]{6}([a-fA-F0-9]{2})?$")
	private String borderColor;
	
	@JsonPropertyDescription("The color of the font used for the label")
	@Pattern(regexp = "^#[a-fA-F0-9]{6}([a-fA-F0-9]{2})?$")
	private String fontColor;

	@JsonAlias("borderTick")
	@JsonPropertyDescription("the border line thick for render")
	@Min(0)
	@Default
	private int borderThick = 0;
	
	@JsonPropertyDescription("The size of the font used for the label")
	@Min(0)
	@Default
	private int fontSize = 0;

	@JsonProperty(required = true)
	@JsonPropertyDescription("the type of geometry")
	@NotNull
	private VdlGeometryType geometryType;
	
	@JsonProperty(required = true)
	@JsonPropertyDescription("The geometry spatial reference system. "
							 + "if srs = ‘none’, no re-projection is performed when call wms. "
							 + "if srs = ‘param:{param_name}’ the srs value is taken from the query param {param_name} to be passed to the wms call. ")
	@NotBlank
	private String srs;

	@JsonPropertyDescription("The style code to use for wms")
	private String styleCode;
	
	@JsonPropertyDescription("the column to be used as a ref code")
	private String styleRefColumn;
	
	@JsonPropertyDescription("the list module codes of the source")
	private List<String> modules;

}
