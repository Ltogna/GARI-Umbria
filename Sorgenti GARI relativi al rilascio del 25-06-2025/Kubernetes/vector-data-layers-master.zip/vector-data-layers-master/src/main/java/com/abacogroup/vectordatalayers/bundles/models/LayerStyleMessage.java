package com.abacogroup.vectordatalayers.bundles.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonClassDescription;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@ConfigurationBundlePojo()
@JsonClassDescription("Identify the data to be inserted or replaced in the vector data layer sources")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LayerStyleMessage {
    
    @JsonProperty(required = true)
    @JsonPropertyDescription("The style code")
    @NotBlank
    @Valid
    private String styleCode;

    @JsonProperty(required = true)
    @JsonPropertyDescription("The style details")
    @Valid
    private List<Style> styles;

    @Data
    @SuperBuilder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonClassDescription("Details of the style configuration")
    public static class Style {
        
        @JsonProperty(required = true)
        @JsonPropertyDescription("The reference code")
        @NotBlank
        @Valid
        private String refCode;

        @JsonPropertyDescription("The fill color")
        private String fillColor;

        @JsonPropertyDescription("The border color")
        private String borderColor;

        @JsonPropertyDescription("The border thickness")
        private int borderThick;

        @JsonPropertyDescription("The font color")
        private String fontColor;

        @JsonPropertyDescription("The font size")
        private int fontSize;
    }
}
