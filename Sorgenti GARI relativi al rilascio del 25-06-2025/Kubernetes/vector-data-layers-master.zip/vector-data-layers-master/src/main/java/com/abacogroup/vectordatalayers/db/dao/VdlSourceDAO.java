package com.abacogroup.vectordatalayers.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.vectordatalayers.api.Layer;
import com.abacogroup.vectordatalayers.common.resources.ReqContext;
import com.abacogroup.vectordatalayers.core.dto.VdlSourceIdentifier;
import com.abacogroup.vectordatalayers.db.ntt.VdlQueryParamEntity;
import com.abacogroup.vectordatalayers.db.ntt.VdlSourceEntity;
import java.util.List;
import java.util.function.Consumer;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;


public interface VdlSourceDAO extends Transactional<VdlSourceDAO>, EnhancedSqlObject {

	@SqlQuery("SELECT s.code, \n"
			+ "       s.geometry_type, \n"
			+ "       coalesce(§i18n(:tenantId, 'vdl_sources', 'code', s.code, :lang)§, s.code) as description \n"
			+ " FROM vdl_sources s \n"
			+ " WHERE s.tenant_id = :tenantId "
			+ " ORDER BY s.code asc ")
	@RegisterBeanMapper(Layer.class)
	ResultIterator<Layer> search(@BindBean ReqContext ctx);

	@SqlQuery("SELECT code, \n"
			+ "       tenant_id \n"
			+ " from vdl_sources \n"
			+ " where tenant_id = :tenant_id \n")
	@RegisterBeanMapper(VdlSourceIdentifier.class)
	void consumeIdentifiersByTenant(@Bind("tenant_id") String tenantId, Consumer<VdlSourceIdentifier> consumer);
	
	@SqlQuery("select tenant_id as tenantId, code from vdl_sources")
	@RegisterBeanMapper(VdlSourceIdentifier.class)
	void consumeIdentifiers(Consumer<VdlSourceIdentifier> consumer);

	@SqlQuery("SELECT code, \n"
			+ "       tenant_id, \n"
			+ "       sql_select, \n"
			+ "       filter_geometry_column, \n"
			+ "       geometry_column, \n"
			+ "       label_column, \n"
			+ "       identifier_column, \n"
			+ "       datasource, \n"
			+ "       fill_color, \n"
			+ "       fill_style, \n"
			+ "       border_color, \n"
			+ "       font_color, \n"
			+ "       border_thick, \n"
			+ "       font_size, \n"
			+ "       geometry_type, \n"
			+ "       srs, \n"
			+ "       coalesce(§i18n(:tenant_id, 'vdl_sources', 'code', code, :lang)§ , code) as description, \n"
			+ "       style_code, \n"
			+ "       style_ref_column \n"
			+ " from vdl_sources \n"
			+ " where tenant_id = :tenant_id  and code = :code \n")
	@RegisterBeanMapper(VdlSourceEntity.class)
	VdlSourceEntity findSourceByTenantAndCode(@Bind("tenant_id") String tenantId, @Bind("lang") String lang,
			@Bind("code") String code);
	
	@SqlQuery("SELECT vs.code, \n"
			+ "       vs.tenant_id, \n"
			+ "       vs.sql_select, \n"
			+ "       vs.filter_geometry_column, \n"
			+ "       vs.geometry_column, \n"
			+ "       vs.label_column, \n"
			+ "       vs.identifier_column, \n"
			+ "       vs.datasource, \n"
			+ "       vs.fill_color, \n"
			+ "       vs.fill_style, \n"
			+ "       vs.border_color, \n"
			+ "       vs.font_color, \n"
			+ "       vs.border_thick, \n"
			+ "       vs.font_size, \n"
			+ "       vs.geometry_type, \n"
			+ "       vs.srs, \n"
			+ "       coalesce(§i18n(:tenant_id, 'vdl_sources', 'code', vs.code, :lang)§ , vs.code) as description, \n"
			+ "       vs.style_code, \n"
			+ "       vs.style_ref_column \n"
			+ " from vdl_sources vs \n"
			+ " left join vdl_sources_modules vsm "
			+ " on vsm.tenant_id = vs.tenant_id and vsm.code = vs.code \n"
			+ " where vs.tenant_id = :tenant_id \n"
			+ "       and (:filter is null or (upper(vs.code) like upper('%'||:filter||'%') escape '$')) \n"
			+ "       and (:module is null or vsm.module = :module) \n"
			+ " order by vs.code ")
	@RegisterBeanMapper(VdlSourceEntity.class)
	ResultIterator<VdlSourceEntity> findSourcesByTenant(@Bind("tenant_id") String tenantId, @Bind("lang") String lang,
			@Bind("filter") String filter, @Bind("module") String module);
	
	@SqlQuery("SELECT code, \n"
			+ "       tenant_id, \n"
			+ "       sql_select, \n"
			+ "       filter_geometry_column, \n"
			+ "       geometry_column, \n"
			+ "       label_column, \n"
			+ "       identifier_column, \n"
			+ "       datasource, \n"
			+ "       fill_color, \n"
			+ "       fill_style, \n"
			+ "       border_color, \n"
			+ "       font_color, \n"
			+ "       border_thick, \n"
			+ "       font_size, \n"
			+ "       geometry_type, \n"
			+ "       srs, \n"
			+ "       coalesce(§i18n(:tenant_id, 'vdl_sources', 'code', code, :lang)§ , code) as description, \n"
			+ "       style_code, \n"
			+ "       style_ref_column \n"
			+ " from vdl_sources \n"
			+ " where tenant_id = :tenant_id \n"
			+ " order by code ")
	@RegisterBeanMapper(VdlSourceEntity.class)
	List<VdlSourceEntity> findSourcesByTenantList(@Bind("tenant_id") String tenantId, @Bind("lang") String lang);

	@SqlQuery("SELECT * "
			+ "  from vdl_source_query_params "
			+ " where tenant_id = :tenantId  and source_code = :sourceCode "
			+ " order by source_code, query_param_name ")
	@RegisterBeanMapper(VdlQueryParamEntity.class)
	List<VdlQueryParamEntity> findQueryParamsByTenantAndSourceCode(@Bind("tenantId") String tenantId, @Bind("sourceCode") String sourceCode);
	
	@SqlQuery("SELECT * "
			+ "  from vdl_source_query_params "
			+ " where tenant_id = :tenantId  and source_code = :sourceCode and query_param_name = :paramName "
			+ " order by source_code, query_param_name ")
	@RegisterBeanMapper(VdlQueryParamEntity.class)
	VdlQueryParamEntity findQueryParamsByTenantSourceCodeAndParamName(@Bind("tenantId") String tenantId, @Bind("sourceCode") String sourceCode,
			@Bind("paramName") String paramName);

	@SqlQuery("SELECT * "
			+ "  from vdl_source_query_params "
			+ " where tenant_id = :tenantId "
			+ " order by source_code, query_param_name ")
	@RegisterBeanMapper(VdlQueryParamEntity.class)
	List<VdlQueryParamEntity> findQueryParamsByTenant(@Bind("tenantId") String tenantId);
		
	 @SqlUpdate("DELETE FROM vdl_sources WHERE tenant_id = :tenant_id  and code = :code \n")
	 void deleteSource(@Bind("tenant_id") String tenantId, @Bind("code") String code);

	@SqlUpdate("DELETE FROM vdl_source_query_params WHERE tenant_id = :tenant_id  and source_code = :code \n")
	void deleteQueryParams(@Bind("tenant_id") String tenantId, @Bind("code") String code);
	
	@SqlUpdate("DELETE FROM vdl_source_query_params "
			+ " WHERE tenant_id = :tenant_id  "
			+ " and source_code = :code "
			+ " and (:paramName is null or query_param_name = :paramName) \n")
	void deleteQueryParamByName(@Bind("tenant_id") String tenantId, @Bind("code") String code, @Bind("paramName") String paramName);

	@SqlUpdate("INSERT INTO vdl_sources "
			+ "(tenant_id, code, sql_select, filter_geometry_column, geometry_column, label_column, identifier_column, "
			+ " datasource, fill_color, fill_style, border_color, font_color, border_thick, font_size, geometry_type, "
			+ " srs, style_code, style_ref_column)"
			+ " VALUES "
			+ "(:tenantId, :code, :sqlSelect, :filterGeometryColumn, :geometryColumn, :labelColumn, :identifierColumn, "
			+ " upper(:datasource), :fillColor, :fillStyle, :borderColor, :fontColor, :borderThick, :fontSize, :geometryType, "
			+ " :srs, :styleCode, :styleRefColumn)")
	void insertSource(@BindBean VdlSourceEntity data);

	@SqlBatch("insert into vdl_source_query_params (tenant_id, source_code, query_param_name, type, description) "
			+ "values (:tenantId, :sourceCode, :queryParamName, :type, :description) ")
	void insertQueryParams(@BindBean VdlQueryParamEntity... queryParams);

	@SqlUpdate("update vdl_sources \n"
			+ "    set datasource = upper(:datasource), \n"
			+ "    sql_select = :sqlSelect, \n"
			+ "    filter_geometry_column = :filterGeometryColumn, \n"
			+ "    geometry_column = :geometryColumn, \n"
			+ "    identifier_column = :identifierColumn, \n"
			+ "    geometry_type = :geometryType, \n"
			+ "    srs = :srs, \n"
			+ "    fill_color = :fillColor, \n"
			+ "    fill_style = :fillStyle, \n"
			+ "    border_color = :borderColor, \n"
			+ "    border_thick = :borderThick, \n"
			+ "    label_column = :labelColumn, \n"
			+ "    font_size = :fontSize, \n"
			+ "    font_color = :fontColor, \n"
			+ "    style_code = :styleCode, \n"
			+ "    style_ref_column = :styleRefColumn \n"
			+ " where tenant_id = :tenant_id \n"
			+ "    and code = :code \n"
			+ "")
	void updateSource(@Bind("tenant_id") String tenantId, @BindBean VdlSourceEntity data);

}
