package com.abacogroup.vectordatalayers.common.resources;

import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.PrincipalImpl;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NonNull;
import lombok.ToString;

/**
 * dto per la propagazione delle informazioni di richiesta:
 *
 * <p>- user
 *
 * <p>- lang
 *
 * <p>- tenant
 *
 * <p>usato per la creazione di criteria, order e per la costruzione di query i18N
 *
 * <p>per limitazioni relative a @BeanParam deve essere creato nella resource:
 */
@Data
@AllArgsConstructor
public class ReqContext {

	@ToString.Exclude
	@NonNull
	private User user;

	private String lang;

	public ReqContext(String tenantId, String username, String lang) {
		this.user = new User(username, tenantId);
		this.lang = lang;
	}

	@ToString.Include(name = "username")
	public String getUsername() {
		return Optional.ofNullable(user).map(PrincipalImpl::getName).orElseThrow();
	}

	@ToString.Include(name = "tenantId")
	public String getTenantId() {
		return Optional.ofNullable(user).map(User::getTenant).orElseThrow();
	}

	public String getLang() {
		return Optional.ofNullable(lang).orElse("en");
	}
}
