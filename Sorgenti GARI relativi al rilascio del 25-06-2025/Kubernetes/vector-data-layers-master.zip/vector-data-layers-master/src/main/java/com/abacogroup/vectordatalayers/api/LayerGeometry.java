package com.abacogroup.vectordatalayers.api;

import java.util.Map;

import org.locationtech.jts.geom.Geometry;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode.Exclude;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LayerGeometry {

	private String id;
	@Schema(implementation = String.class, example = "POLYGON ((100 200, 200 200, 200 100, 100 100, 100 200))")
	private Geometry geometry;
	private String label;
	
	private String srs;
	private Double areaSqm;
	
	@Exclude
	private Map<String, String> fields;
	
}
