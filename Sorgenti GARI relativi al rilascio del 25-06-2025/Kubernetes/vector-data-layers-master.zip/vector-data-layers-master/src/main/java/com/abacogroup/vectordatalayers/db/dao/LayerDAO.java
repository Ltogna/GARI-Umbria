package com.abacogroup.vectordatalayers.db.dao;

import java.sql.DatabaseMetaData;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.core.statement.Query;
import org.jdbi.v3.core.statement.SqlStatements;
import org.jdbi.v3.sqlobject.transaction.Transactional;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.vectordatalayers.api.LayerGeometry;
import com.abacogroup.vectordatalayers.core.dto.CustomFilterValue;
import com.abacogroup.vectordatalayers.db.dao.mappers.LayerGeometryWithInfoMapper;
import com.abacogroup.vectordatalayers.db.ntt.VdlSourceEntity;

public interface LayerDAO extends Transactional<LayerDAO>, EnhancedSqlObject {

	default ResultIterator<LayerGeometry> getByGeometryWithInfo(VdlSourceEntity sourceData, Geometry touchingGeometry,
			Map<String, CustomFilterValue<?>> additionalFilters, boolean getIntersectedGeometry) {

		String dbType = withHandle(h -> h.queryMetadata(DatabaseMetaData::getDatabaseProductName));

		boolean isPostgres = dbType.toLowerCase().contains("postgresql");

		String baseSql = StringUtils.replace(sourceData.getSqlSelect(), "{spatial_where_clause}",
				String.format(" §geom_have_interactions(%s, :touchingGeometry)§ ", sourceData.getFilterGeometryColumn()));
		baseSql = StringUtils.replace(baseSql, "{tenant}", ":tenant");
		
		String internalSql = new StringBuilder("SELECT t_internal.*, ")
				.append(StringUtils.isBlank(sourceData.getIdentifierColumn())
						? " null as v_d_l_id "
						: String.format(" t_internal.%s as v_d_l_id ", sourceData.getIdentifierColumn()))
				.append(", ")
				.append(StringUtils.isBlank(sourceData.getGeometryColumn()) 
						? " null "
						: getIntersectedGeometry 
							? String.format(" §geom_intersection(t_internal.%s, :touchingGeometry)§ ", sourceData.getGeometryColumn())
							: String.format(" t_internal.%s ", sourceData.getGeometryColumn()))
				.append(" as v_d_l_wkt_geometry ")
				.append(", ")
				.append(StringUtils.isBlank(sourceData.getLabelColumn())
						? " null as v_d_l_label "
						: String.format(" t_internal.%s as v_d_l_label ", sourceData.getLabelColumn()))
				.append(", ")
				.append(StringUtils.isBlank(sourceData.getStyleRefColumn())
						? " null as style_ref_code "
								: String.format(" t_internal.%s as style_ref_code ", sourceData.getStyleRefColumn()))
				.append(" from ( ").append(baseSql)
				.append(" ) ")
				.append(isPostgres ? "as " : "").append(" t_internal ")
				.toString();

		String sql = new StringBuilder("SELECT t_external.*, ")
				.append(" §geom_area(t_external.v_d_l_wkt_geometry)§ as v_d_l_area_sqm ")
				.append(" from ( ")
				.append(internalSql)
				.append(" ) ")
				.append(isPostgres ? "as " : "").append(" t_external ")
				.append(" where t_external.v_d_l_wkt_geometry is not null ")
				.append(" order by v_d_l_id asc ")
				.toString();

		return withHandle(h -> {
			h.configure(SqlStatements.class, cfg -> cfg.setUnusedBindingAllowed(true));
			Query query = h.createQuery(sql)
					.bind("tenant", sourceData.getTenantId())
					.bind("touchingGeometry", touchingGeometry);

			if (additionalFilters != null && !additionalFilters.isEmpty()) {
				additionalFilters.forEach((name, value) -> query.bindByType(name, value.getValue(), value.getType()));
			}

			return query
					.map(new LayerGeometryWithInfoMapper(sourceData))
					.iterator();
		});
	}

}
