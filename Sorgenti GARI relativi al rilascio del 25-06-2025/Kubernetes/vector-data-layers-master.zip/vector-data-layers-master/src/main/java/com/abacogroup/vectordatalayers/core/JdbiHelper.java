package com.abacogroup.vectordatalayers.core;

import com.abacogroup.vectordatalayers.db.dao.VdlDataSourceDAO;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

@Slf4j
public class JdbiHelper {

	public static final String MAIN = "main";
	public static final String DATABASE = "database";

	private final VdlDataSourceDAO vdlDataSourceDAO;

	private final Map<String, Jdbi> jdbiMap;
	private final Jdbi jdbi;

	private final Map<Class<?>, Map<String, Object>> daosCache;

	public JdbiHelper(VdlDataSourceDAO vdlDataSourceDAO, Jdbi jdbi) {
		this.vdlDataSourceDAO = vdlDataSourceDAO;
		this.jdbiMap = new ConcurrentHashMap<>();
		this.jdbi = jdbi;
		this.daosCache = new ConcurrentHashMap<>();

		this.clearDataSources();
	}

	public void putIfAbsent(String key, Jdbi value) {
		if (MAIN.equals(key) || DATABASE.equals(key)) {
			throw new IllegalArgumentException(String.format("reserved key %s", key));
		}

		jdbiMap.putIfAbsent(key, value);
	}

	public void clearDataSources() {
		jdbiMap.clear();
		jdbiMap.put(MAIN, jdbi);
		jdbiMap.put(DATABASE, jdbi);
		daosCache.clear();
	}

	public boolean containsDatasource(String key) {
		if (null == key) {
			return true;
		}
		return jdbiMap.containsKey(key);
	}

	@SuppressWarnings("unchecked")
	public <E> E getDao(String key, Class<E> extensionType) {
		if (null == key) {
			key = MAIN;
		}

		return (E) daosCache.computeIfAbsent(extensionType, k -> new ConcurrentHashMap<>())
				.computeIfAbsent(key, k -> onDemand(k, extensionType));
	}

	private <E> E onDemand(String key, Class<E> extensionType) {
		if (null == key) {
			return jdbi.onDemand(extensionType);
		} else if (jdbiMap.containsKey(key)) {
			return jdbiMap.get(key).onDemand(extensionType);
		} else {
			throw new IllegalStateException(String.format("missing datasource %s", key));
		}
	}

	public Jdbi getJdbi(String key) {
		if (jdbiMap.containsKey(key)) {
			return jdbiMap.get(key);
		} else {
			throw new IllegalStateException(String.format("missing datasource %s", key));
		}
	}

	public void datasourceCheck() {
		log.info("known datasources: {}", jdbiMap.keySet());
		List<String> mappedDatasources = getMappedDataSources();
		log.info("mapped datasources: {}", mappedDatasources);
		mappedDatasources.removeAll(jdbiMap.keySet());

		// TODO useless until restore old check from v1.2.0

		// TODO: GNK
		// if (!mappedDatasources.isEmpty()) {
		// throw new IllegalStateException(String.format("missing datasources %s", mappedDatasources));
		// }
	}

	/// all datasources mapped to vdl sources
	public List<String> getMappedDataSources() {
		return vdlDataSourceDAO.getDatasourceNames(); // TODO restore v1.2.0
	}

	public List<String> getRegisteredAdditionalDataSources() {
		List<String> keys = new ArrayList<>(jdbiMap.keySet());
		keys.remove(DATABASE);
		keys.remove(MAIN);
		return keys;
	}
}
