package com.abacogroup.vectordatalayers.api;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class VdlQueryParam {

	@Schema(description = "The custom query param name")
	@NotBlank
	private String queryParamName;

	@Schema(description = "query param type")
	@NotNull
	private QueryParamType type;
	
	@Schema(description = "free text description")
	private String description;

}
