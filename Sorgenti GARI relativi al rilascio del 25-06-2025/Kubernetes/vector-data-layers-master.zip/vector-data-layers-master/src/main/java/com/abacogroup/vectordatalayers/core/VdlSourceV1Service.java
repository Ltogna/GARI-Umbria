package com.abacogroup.vectordatalayers.core;

import java.util.List;

import com.abacogroup.vectordatalayers.api.pub.VdlSourceDataV1;
import com.abacogroup.vectordatalayers.api.pub.VdlSourceV1;
import com.abacogroup.vectordatalayers.common.resources.ReqContext;

public interface VdlSourceV1Service {
	List<VdlSourceV1> getTenantSources(ReqContext reqContext, String module);

	VdlSourceDataV1 getSourceData(ReqContext reqContext, String code);
}
