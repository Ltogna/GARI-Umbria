package com.abacogroup.vectordatalayers;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.Configuration;
import io.dropwizard.db.DataSourceFactory;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.HashMap;
import java.util.Map;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class VectorDataLayersConfig extends Configuration {

	@NotNull
	@Valid
	private JerseyClientConfiguration jerseyClient;

	private boolean enableSpatialVectorAcceleration;
	
	@Valid
	private Sso2Config sso2Config;
	
	@Valid
	@NotNull
	private DataSourceFactory database;

	@Valid
	private Map<String, @NotNull @Valid DataSourceFactory> additionalDataSources = new HashMap<>();

	private RabbitmqConfig rabbitmqConfig;

	@Valid
	private BundleConfig bundleConfig;

	@JsonProperty(value = "devtools-enabled", defaultValue = "false")
	private boolean devToolsEnabled = false;

	@Data
	public static class Sso2Config {
		private String url;
		private String tokensAuthSecret;
	}
	
	@Data
	public static class RabbitmqConfig
	{
		private String host;
		private String user;
		private String password;
		private String virtualhost;
		private int port;
	}

	@Data
	public static class BundleConfig {

		@NotBlank
		private String configLocation;

		private String initBaseTempDir;

	}


}
