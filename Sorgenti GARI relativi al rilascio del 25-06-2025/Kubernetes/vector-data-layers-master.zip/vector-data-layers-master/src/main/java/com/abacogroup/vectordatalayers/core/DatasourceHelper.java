package com.abacogroup.vectordatalayers.core;

import java.nio.charset.StandardCharsets;
import java.sql.DatabaseMetaData;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.apache.hc.client5.http.utils.Base64;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.SqlStatements;

import com.abacogroup.jdbi.OraJdbiPlugin;
import com.abacogroup.jdbi.OraJdbiPlugin.OraJdbiPluginParams;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.jdbi.argument.AbsoluteDateArgumentFactory;
import com.abacogroup.jdbi.config.AbacoJdbiConfig;
import com.abacogroup.jdbi.config.SpatialVectorAcceleration;
import com.abacogroup.jdbi.mapper.AbsoluteDateMapper;
import com.abacogroup.vectordatalayers.core.dto.mapper.AdditionalDataSourceMapper;
import com.abacogroup.vectordatalayers.db.dao.VdlDataSourceDAO;
import com.abacogroup.vectordatalayers.db.ntt.AdditionalDataSourceEntity;

import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.jdbi3.JdbiFactory;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleConnection;

@Slf4j
@AllArgsConstructor
public class DatasourceHelper {
	private final VdlDataSourceDAO vdlDataSourceDAO;

	public Map<String, DataSourceFactory> getAdditionalDataSources() {
		List<String> dataSourcesNames = vdlDataSourceDAO.getDatasourceNames();
		List<AdditionalDataSourceEntity> additionalDataSources = buildAdditionalDataSourcesOrThrow(dataSourcesNames);
		return additionalDataSources.stream()
				.map(ds -> Map.entry(ds.getDsKey(), AdditionalDataSourceMapper.INSTANCE.fromEntity(ds)))
				.collect(Collectors.toMap(Entry::getKey, Entry::getValue));
	}

	public static Jdbi createJdbi(DataSourceFactory dsf, Environment environment, String name, boolean enableSpatialVectorAcceleration) {
		final JdbiFactory factory = new JdbiFactory();
		final Jdbi jdbi = factory.build(environment, dsf, name);

		DatasourceHelper.configureJdbi(jdbi, name, enableSpatialVectorAcceleration);
		return jdbi;
	}

	public static void configureJdbi(Jdbi jdbi, String name, boolean enableSpatialVectorAcceleration) {
		jdbi.getConfig(SqlStatements.class).setUnusedBindingAllowed(true);

		jdbi.configure(AbacoJdbiConfig.class, cfg -> cfg.setTablesPrefix("vdl"));
		if (enableSpatialVectorAcceleration)
			jdbi.configure(AbacoJdbiConfig.class, config -> config.setSpatalVectorAcceleration(SpatialVectorAcceleration.ENABLE_IF_POSSIBLE));

		boolean isPostgres = jdbi.withHandle(h -> {
			String db = h.queryMetadata(DatabaseMetaData::getDatabaseProductName);
			log.info("Database '{}' connection is '{}'", name, db);

			if (log.isDebugEnabled()) {
				String jdbcUrl = h.queryMetadata(DatabaseMetaData::getURL);
				log.debug("Database '{}' url is '{}'", name, jdbcUrl);
			}

			return db.toLowerCase().contains("postgresql");
		});

		if (isPostgres) {
			jdbi.installPlugin(new PgJdbiPlugin());
		} else {
			OraJdbiPluginParams params = new OraJdbiPluginParams(cnn -> cnn.unwrap(OracleConnection.class), true);
			jdbi.installPlugin(new OraJdbiPlugin(params));
		}

		jdbi.registerColumnMapper(new AbsoluteDateMapper());
		jdbi.registerArgument(new AbsoluteDateArgumentFactory());
	}

	public static String jdbiName(String name) {
		return name + "_jdbi";
	}

	public static boolean canConnect(AdditionalDataSourceEntity dsEntity) {
		return canConnect(dsEntity.getDsKey(), AdditionalDataSourceMapper.INSTANCE.fromEntity(dsEntity));
	}

	public static boolean canConnect(String dsKey, DataSourceFactory dataSourceFactory) {

		final Jdbi jdbi;
		if (null != dataSourceFactory.getUser() && null != dataSourceFactory.getPassword()) {
			jdbi = Jdbi.create(dataSourceFactory.getUrl(), dataSourceFactory.getUser(), dataSourceFactory.getPassword());
		} else {
			jdbi = Jdbi.create(dataSourceFactory.getUrl());
		}

		try (Handle handle = jdbi.open()) {
			if (dataSourceFactory.getValidationQuery().isPresent()) {
				handle.execute(dataSourceFactory.getValidationQuery().get());
			} else if (!handle.getConnection().isValid(dataSourceFactory.getValidationQueryTimeout()
					.map(d -> (int) d.toSeconds())
					.orElse(5))) {
				return false;
			}

			return true;
		} catch (Exception e) {
			log.error("Can't connect to '{}'", dsKey, e);
			return false;
		}
	}

	public List<AdditionalDataSourceEntity> buildAdditionalDataSourcesOrThrow(List<String> dataSourceNames) {
		String jdbcUrlPlaceHolder = "VDLDS_<datasource>_JDBC_URL";
		String jdbcDriverPlaceHolder = "VDLDS_<datasource>_JDBC_DRIVER";
		String databaseUserPlaceHolder = "VDLDS_<datasource>_USER";
		String databasePasswordPlaceHolder = "VDLDS_<datasource>_PASSWORD";
		String databaseValidationQueryPlaceHolder = "VDLDS_<datasource>_VALIDATION_QUERY";
		String needleToReplace = "<datasource>";

		List<String> errorMessages = new ArrayList<>();
		List<AdditionalDataSourceEntity> additionalDataSources = new ArrayList<>();

		for (String dataSourceName : dataSourceNames) {
			String dataSourceNameToUpperCase = dataSourceName.toUpperCase();
			String jdbcUrlEnvKey = jdbcUrlPlaceHolder.replace(needleToReplace, dataSourceNameToUpperCase);

			String jdbcDriverEnvKey = jdbcDriverPlaceHolder
					.replace(needleToReplace, dataSourceNameToUpperCase);

			String databaseUserEnvKey = databaseUserPlaceHolder
					.replace(needleToReplace, dataSourceNameToUpperCase);

			String databasePasswordEnvKey = databasePasswordPlaceHolder
					.replace(needleToReplace, dataSourceNameToUpperCase);

			String databaseValidationQueryEnvKey = databaseValidationQueryPlaceHolder
					.replace(needleToReplace, dataSourceNameToUpperCase);

			String jdbcUrl = System.getenv(jdbcUrlEnvKey);
			String jdbcDriver = System.getenv(jdbcDriverEnvKey);
			String databaseUser = System.getenv(databaseUserEnvKey);
			String databasePassword = System.getenv(databasePasswordEnvKey);
			String databaseValidationQuery = System.getenv(databaseValidationQueryEnvKey);

			if (jdbcUrl == null) {
				errorMessages.add("Env key: " + jdbcUrlEnvKey + " not found");
			}

			if (jdbcDriver == null) {
				errorMessages.add("Env key: " + jdbcDriverEnvKey + " not found");
			}

			if (databaseUser == null) {
				errorMessages.add("Env key: " + databaseUserEnvKey + " not found");
			}

			if (databasePassword == null) {
				errorMessages.add("Env key: " + databasePasswordEnvKey + " not found");
			}

			if (databaseValidationQuery == null) {
				errorMessages.add("Env key: " + databaseValidationQueryEnvKey + " not found");
			}

			if (!errorMessages.isEmpty()) {
				//throw new RuntimeException("Missing env keys for configured data sources: \n" + String.join(",\n", errorMessages));
				log.error("Missing env keys for configured data sources: \n" + String.join(",\n", errorMessages));
				continue;
			}

			AdditionalDataSourceEntity additionalDataSource = new AdditionalDataSourceEntity();
			additionalDataSource.setDsKey(dataSourceName);
			additionalDataSource.setDriverClass(jdbcDriver);
			additionalDataSource.setDbUrl(jdbcUrl);
			additionalDataSource.setDbUser(databaseUser);
			additionalDataSource.setDbPasswordEncoded(Base64.encodeBase64String(databasePassword.getBytes(StandardCharsets.UTF_8)));
			additionalDataSource.setValidationQuery(databaseValidationQuery);
			additionalDataSource.setMinSize(1);
			additionalDataSource.setInitialSize(1);

			additionalDataSources.add(additionalDataSource);
		}

		return additionalDataSources;
	}

}
