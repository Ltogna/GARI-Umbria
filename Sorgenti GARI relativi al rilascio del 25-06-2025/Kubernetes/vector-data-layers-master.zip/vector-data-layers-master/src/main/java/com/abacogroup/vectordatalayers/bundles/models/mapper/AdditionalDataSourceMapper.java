package com.abacogroup.vectordatalayers.bundles.models.mapper;

import com.abacogroup.vectordatalayers.bundles.models.AdditionalDataSourcePojo;
import com.abacogroup.vectordatalayers.db.ntt.AdditionalDataSourceEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AdditionalDataSourceMapper {

    AdditionalDataSourceMapper INSTANCE = Mappers.getMapper(AdditionalDataSourceMapper.class);

    @Mapping(target = "dsKey", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getDsKey()))")
    @Mapping(target = "driverClass", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getDriverClass()))")
    @Mapping(target = "dbUrl", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getUrl()))")
    @Mapping(target = "dbUser", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getUser()))")
    @Mapping(target = "dbPasswordEncoded", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getPasswordEncoded()))")
    @Mapping(target = "validationQuery", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getValidationQuery()))")
    @Mapping(target = "minSize", source = "minSize")
    @Mapping(target = "initialSize", source = "initialSize")
    AdditionalDataSourceEntity fromBundleData(AdditionalDataSourcePojo data);

}
