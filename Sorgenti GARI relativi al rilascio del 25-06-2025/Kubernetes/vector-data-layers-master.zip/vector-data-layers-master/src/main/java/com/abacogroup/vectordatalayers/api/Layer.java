package com.abacogroup.vectordatalayers.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Layer {

	private String code;
	private String description;

	private VdlGeometryType geometryType;

}
