package com.abacogroup.vectordatalayers.bundles.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonClassDescription;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ConfigurationBundlePojo()
@JsonClassDescription("identify the data to be inserted or replace in the vector data layer sources")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LayerStyleList {
	
	@JsonProperty(required = true)
	@NotEmpty
	@Valid
	private List<LayerStyleMessage> layerStyles;

}
