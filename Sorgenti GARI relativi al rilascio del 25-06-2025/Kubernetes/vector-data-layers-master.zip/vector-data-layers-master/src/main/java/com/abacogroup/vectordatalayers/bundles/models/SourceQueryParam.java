package com.abacogroup.vectordatalayers.bundles.models;

import com.abacogroup.vectordatalayers.api.QueryParamType;
import com.fasterxml.jackson.annotation.JsonClassDescription;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ConfigurationBundlePojo()
@JsonClassDescription("identify the data part of a Source")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
public class SourceQueryParam {

	@JsonProperty(required = true)
	@JsonPropertyDescription("query param name. must match a placeholder in data.sqlSelect")
	@NotBlank
	@Size(max = 100)
	@Pattern(regexp = "^[\\w-]+$")
	private String queryParamName;

	@JsonProperty(required = true)
	@NotNull
	private QueryParamType type;

	private String description;

}
