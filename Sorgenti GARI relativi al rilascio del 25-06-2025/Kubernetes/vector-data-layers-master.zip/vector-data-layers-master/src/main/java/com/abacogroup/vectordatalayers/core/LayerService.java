package com.abacogroup.vectordatalayers.core;

import java.util.List;

import org.locationtech.jts.geom.Geometry;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.vectordatalayers.api.Layer;
import com.abacogroup.vectordatalayers.api.LayerGeometry;
import com.abacogroup.vectordatalayers.common.resources.ReqContext;
import com.abacogroup.wms4j.layers.LayerDefinition;

import jakarta.ws.rs.core.MultivaluedMap;

public interface LayerService {
	InfiniteListResults<Layer> getLayers(ReqContext reqContext, String nextKey, Integer pageSize);

	InfiniteListResults<LayerGeometry> getLayerGeometries(ReqContext reqContext, String sourceCode, Geometry touchingGeometry, 
			boolean getIntersectedGeometries, MultivaluedMap<String, String> queryParameters, String nextKey, Integer pageSize);

	List<LayerDefinition> getWMSLayers();

	List<LayerDefinition> getWMSLayers(String tenantId);

	LayerDefinition createLayer(String tenantId, String code);
}
