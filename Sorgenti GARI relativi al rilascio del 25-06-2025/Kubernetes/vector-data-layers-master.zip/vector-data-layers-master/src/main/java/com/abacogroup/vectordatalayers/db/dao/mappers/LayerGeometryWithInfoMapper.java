package com.abacogroup.vectordatalayers.db.dao.mappers;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdbi.v3.core.mapper.ColumnMapper;
import org.jdbi.v3.core.mapper.ColumnMappers;
import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;
import org.locationtech.jts.geom.Geometry;

import com.abacogroup.vectordatalayers.api.LayerGeometry;
import com.abacogroup.vectordatalayers.core.exceptions.VdlSourceException;
import com.abacogroup.vectordatalayers.core.exceptions.VdlSourceException.ErrEnum;
import com.abacogroup.vectordatalayers.db.ntt.VdlSourceEntity;

public class LayerGeometryWithInfoMapper implements RowMapper<LayerGeometry> {

	private final VdlSourceEntity sourceData;

	public LayerGeometryWithInfoMapper(VdlSourceEntity sourceData) {
		this.sourceData = sourceData;
	}

	@Override
	public LayerGeometry map(ResultSet rs, StatementContext ctx) throws SQLException {
		// Get ResultSetMetaData to discover column names
		ResultSetMetaData metaData = rs.getMetaData();
		Map<String, String> dynamicColumns = new HashMap<>();

		List<String> skipedColumns = new ArrayList<>(List.of("v_d_l_id", "v_d_l_wkt_geometry", "v_d_l_label", "srs", "v_d_l_area_sqm", "r_o_w_n_u_m",
				sourceData.getIdentifierColumn().toLowerCase(), sourceData.getGeometryColumn().toLowerCase()));
		
		if(sourceData.getLabelColumn() != null) {
			skipedColumns.add(sourceData.getLabelColumn().toLowerCase());
		}

		ColumnMappers columnMappers = ctx.getConfig().get(ColumnMappers.class);
		ColumnMapper<Geometry> geometryMapper = columnMappers.findFor(Geometry.class)
				.orElseThrow(() -> new IllegalStateException("abaco-jdbi plugins not installed."));

		// Process all columns
		for (int i = 1; i <= metaData.getColumnCount(); i++) {
			String columnName = metaData.getColumnName(i).toLowerCase();

			// Skip known columns
			if (skipedColumns.contains(columnName.toLowerCase())) {
				continue;
			}

			// Add unknown columns to dynamic map
			dynamicColumns.put(columnName, rs.getObject(i) == null ? null : rs.getObject(i).toString());
		}

		try {
			Geometry geom = geometryMapper.map(rs, "v_d_l_wkt_geometry", ctx);
			return LayerGeometry.builder()
					.id(rs.getString("v_d_l_id"))
					.geometry(geom)
					.label(rs.getString("v_d_l_label"))
					.srs(getSrs(rs))
					.areaSqm(rs.getDouble("v_d_l_area_sqm"))
					.fields(dynamicColumns)
					.build();
		} catch (Exception e) {
			throw new VdlSourceException(
					ErrEnum.UNREADABLE_COLUMN_VALUE,
					String.format("Error in mapping object: %s", e.getMessage()));
		}

	}
	
	private String getSrs(ResultSet rs) {
		try {
			return rs.getString("srs");
		} catch (SQLException e) {
			return null;
		}
	}
}
