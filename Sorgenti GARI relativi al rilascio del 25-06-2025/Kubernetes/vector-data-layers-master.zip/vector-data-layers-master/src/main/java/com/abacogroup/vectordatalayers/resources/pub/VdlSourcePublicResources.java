package com.abacogroup.vectordatalayers.resources.pub;

import java.util.List;

import com.abacogroup.vectordatalayers.api.pub.VdlSourceDataV1;
import com.abacogroup.vectordatalayers.api.pub.VdlSourceV1;
import com.abacogroup.vectordatalayers.common.resources.ReqContext;
import com.abacogroup.vectordatalayers.core.VdlSourceV1Service;
import com.abacogroup.vectordatalayers.core.exceptions.VdlSourceException;
import com.abacogroup.vectordatalayers.resources.ResourceConstants;
import com.codahale.metrics.annotation.Timed;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.PermitAll;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Timed
@Path(ResourceConstants.API_PUB + "/vdl")
@PermitAll
@Tag(name = "Vector Data Layers Sources", description = "Operations on Vector Data Layers Sources")
public class VdlSourcePublicResources {
	private final VdlSourceV1Service vdlSourceService;

	public VdlSourcePublicResources(VdlSourceV1Service vdlSourceService) {
		this.vdlSourceService = vdlSourceService;
	}
	
	@GET
	@Path("/sources")
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "sources by tenant", description = "Get list of sources by tenant id")
	@ApiResponse(responseCode = "200", description = "list of sources", useReturnTypeSchema = true)
	public List<VdlSourceV1> sources(@PathParam("tenant") String tenId,
	@QueryParam("module") String module) {
		ReqContext reqContext = new ReqContext(tenId, null, null);

		return vdlSourceService.getTenantSources(reqContext, module);
	}

	@GET
	@Path("/sources/{code}")
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "source by code", description = "Get a source by tenant id and code")
	@ApiResponse(responseCode = "200", description = "source", useReturnTypeSchema = true)
	@ApiResponse(responseCode = "404", description = "source not found", content = @Content(mediaType = MediaType.APPLICATION_JSON,
			schema = @Schema(implementation = VdlSourceException.ErrorBody.class)))
	public VdlSourceDataV1 source(@PathParam("tenant") String tenId, @PathParam("code") String code) {
		ReqContext reqContext = new ReqContext(tenId, null, null);

		return vdlSourceService.getSourceData(reqContext, code);
	}

}
