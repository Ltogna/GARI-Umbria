package com.abacogroup.vectordatalayers.db.ntt;

import com.abacogroup.vectordatalayers.api.VdlFillStyle;
import com.abacogroup.vectordatalayers.api.VdlGeometryType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class VdlSourceEntity {
	private String code;
	private String tenantId;

	private String datasource;
	private String sqlSelect;
	private String filterGeometryColumn;
	private String geometryColumn;
	private String identifierColumn; // non usata
	private String labelColumn;

	private String fillColor;
	private VdlFillStyle fillStyle;
	private String borderColor;
	private int borderThick;
	private String fontColor;
	private int fontSize;

	private VdlGeometryType geometryType; // non usata ?
	private String srs;
	
	private String styleCode;
	private String styleRefColumn;
	
	private String description;
	
}
