package com.abacogroup.vectordatalayers.core.impl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.vectordatalayers.api.VdlFillStyle;
import com.abacogroup.vectordatalayers.api.VdlQueryParam;
import com.abacogroup.vectordatalayers.api.VdlSource;
import com.abacogroup.vectordatalayers.api.req.CreateVdlQueryParamPayload;
import com.abacogroup.vectordatalayers.api.req.CreateVdlSourcePayload;
import com.abacogroup.vectordatalayers.api.req.UpdateVdlSourcePayload;
import com.abacogroup.vectordatalayers.common.resources.ReqContext;
import com.abacogroup.vectordatalayers.common.resources.ResourceConstants;
import com.abacogroup.vectordatalayers.core.VdlSourceService;
import com.abacogroup.vectordatalayers.core.dto.mapper.VdlQueryParamMapper;
import com.abacogroup.vectordatalayers.core.dto.mapper.VdlSourceMapper;
import com.abacogroup.vectordatalayers.core.exceptions.VdlSourceException;
import com.abacogroup.vectordatalayers.core.exceptions.VdlSourceException.ErrEnum;
import com.abacogroup.vectordatalayers.core.utlis.DrawFeatureBuilder;
import com.abacogroup.vectordatalayers.db.dao.DAOContainer;
import com.abacogroup.vectordatalayers.db.dao.I18nDAO;
import com.abacogroup.vectordatalayers.db.dao.VdlDataSourceDAO;
import com.abacogroup.vectordatalayers.db.dao.VdlSourceDAO;
import com.abacogroup.vectordatalayers.db.ntt.I18nEntity;
import com.abacogroup.vectordatalayers.db.ntt.VdlQueryParamEntity;
import com.abacogroup.vectordatalayers.db.ntt.VdlSourceEntity;
import com.abacogroup.wms4j.renderer.DrawFeature;
import com.abacogroup.wms4j.renderer.WmsImage;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response;

public class VdlSourceServiceImpl implements VdlSourceService {

	private final VdlSourceDAO vdlSourceDAO;
	private final VdlDataSourceDAO vdlDataSourceDAO;
	private final I18nDAO i18nDAO;

	private static final String TABLE_NAME = "vdl_sources";
	private static final String FIELD_NAME = "code";

	private static final String INTERNAL_DATA_SOURCE_CODE = "VECTOR_DATA_LAYER";

	public VdlSourceServiceImpl(DAOContainer daoContainer) {
		this.vdlSourceDAO = daoContainer.getVdlSourceDAO();
		this.vdlDataSourceDAO = daoContainer.getVdlDataSourceDAO();
		this.i18nDAO = daoContainer.getI18nDAO();
	}

	@Override
	public VdlSource createVdlSource(ReqContext reqContext, CreateVdlSourcePayload payload) {

		VdlSourceEntity vdlSourceEntity = vdlSourceDAO.findSourceByTenantAndCode(reqContext.getTenantId(), reqContext.getLang(), payload.getCode());
		if (vdlSourceEntity != null) {
			throw new VdlSourceException(ErrEnum.SOURCE_ALREADY_EXISTS, String.format("Source with code '%s' already exists", payload.getCode()));
		}

		if (!INTERNAL_DATA_SOURCE_CODE.equalsIgnoreCase(payload.getDatasource())
				&& !vdlDataSourceDAO.checkIfPresent(payload.getDatasource())) {
			throw new VdlSourceException(ErrEnum.DATA_SOURCE_NOT_FOUND, String.format("Data source '%s' not found", payload.getDatasource()));
		}

		vdlSourceEntity = buildVdlSourceEntityFromPayload(reqContext.getTenantId(), payload.getCode(), payload);
		vdlSourceDAO.insertSource(vdlSourceEntity);

		insertDescription(reqContext, vdlSourceEntity.getCode(), payload.getDescription());

		return getVdlSourceByCode(reqContext, payload.getCode());
	}

	@Override
	public VdlSource updateVdlSource(ReqContext reqContext, String sourceCode, @NotNull @Valid UpdateVdlSourcePayload payload) {

		VdlSourceEntity vdlSourceEntity = vdlSourceDAO.findSourceByTenantAndCode(reqContext.getTenantId(), reqContext.getLang(), sourceCode);
		if (vdlSourceEntity == null) {
			throw new VdlSourceException(ErrEnum.SOURCE_NOT_FOUND, String.format("Source with code '%s' not found", sourceCode));
		}

		if (Boolean.FALSE.equals(vdlDataSourceDAO.checkIfPresent(payload.getDatasource()))) {
			throw new VdlSourceException(ErrEnum.DATA_SOURCE_NOT_FOUND, String.format("Data source '%s' not found", payload.getDatasource()));
		}

		VdlSourceEntity vdlToInsert = buildVdlSourceEntityFromPayload(reqContext.getTenantId(), sourceCode, payload);

		vdlSourceDAO.updateSource(reqContext.getTenantId(), vdlToInsert);
		insertDescription(reqContext, sourceCode, payload.getDescription());

		return getVdlSourceByCode(reqContext, sourceCode);
	}

	@Override
	public VdlSource getVdlSourceByCode(ReqContext reqContext, String sourceCode) {
		VdlSourceEntity vdlSourceEntity = vdlSourceDAO.findSourceByTenantAndCode(reqContext.getTenantId(), reqContext.getLang(), sourceCode);
		if (vdlSourceEntity == null) {
			throw new VdlSourceException(ErrEnum.SOURCE_NOT_FOUND, String.format("Source with code '%s' not found", sourceCode));
		}

		VdlSource vdlSource = VdlSourceMapper.INSTANCE.fromEntity(vdlSourceEntity);
		vdlSource.setCustomQueryParams(getAllVdlQueryParam(reqContext, sourceCode));

		return vdlSource;
	}

	@Override
	public InfiniteListResults<VdlSource> getAllVdlSources(ReqContext reqContext, String filterSourceCode, String nextKey, Integer pageSize, String module) {

		if (pageSize == null || pageSize <= 0 || pageSize > ResourceConstants.MAX_PAGE_SIZE) {
			pageSize = ResourceConstants.DEFAULT_PAGE_SIZE;
		}

		InfiniteListResults<VdlSource> result = vdlSourceDAO.infinite(
				() -> vdlSourceDAO.findSourcesByTenant(reqContext.getTenantId(), reqContext.getLang(), filterSourceCode, module),
				nextKey,
				pageSize)
				.map(VdlSourceMapper.INSTANCE::fromEntity);

		result.getRecords().forEach(rec -> rec.setCustomQueryParams(getAllVdlQueryParam(reqContext, rec.getCode())));

		return result;
	}

	@Override
	public List<String> getAllVdlDataSources(ReqContext reqContext) {
		List<String> dataSourceList = vdlDataSourceDAO.getDatasourceNames();
		dataSourceList.add(INTERNAL_DATA_SOURCE_CODE);
		dataSourceList.sort(String::compareTo);

		return dataSourceList;
	}

	@Override
	public List<VdlQueryParam> getAllVdlQueryParam(ReqContext reqContext, String sourceCode) {
		return VdlQueryParamMapper.INSTANCE.fromEntity(vdlSourceDAO.findQueryParamsByTenantAndSourceCode(reqContext.getTenantId(), sourceCode));
	}

	@Override
	public VdlQueryParam createVdlQueryParam(ReqContext reqContext, String sourceCode, @NotNull @Valid CreateVdlQueryParamPayload payload) {
		VdlSourceEntity vdlSourceEntity = vdlSourceDAO.findSourceByTenantAndCode(reqContext.getTenantId(), reqContext.getLang(), sourceCode);
		if (vdlSourceEntity == null) {
			throw new VdlSourceException(ErrEnum.SOURCE_NOT_FOUND, String.format("Source with code '%s' not found", sourceCode));
		}

		VdlQueryParamEntity vdlQueryParamEntity = vdlSourceDAO.findQueryParamsByTenantSourceCodeAndParamName(reqContext.getTenantId(), sourceCode,
				payload.getQueryParamName());
		if (vdlQueryParamEntity != null) {
			throw new VdlSourceException(ErrEnum.QUERY_PARAMETER_ALREADY_EXISTS,
					String.format("Query parameter '%s' for source '%s' already exists", payload.getQueryParamName(), sourceCode));
		}

		vdlQueryParamEntity = VdlQueryParamEntity.builder()
				.tenantId(reqContext.getTenantId())
				.sourceCode(sourceCode)
				.queryParamName(payload.getQueryParamName())
				.type(payload.getType())
				.description(payload.getDescription())
				.build();

		vdlSourceDAO.insertQueryParams(vdlQueryParamEntity);

		return VdlQueryParamMapper.INSTANCE.fromEntity(
				vdlSourceDAO.findQueryParamsByTenantSourceCodeAndParamName(reqContext.getTenantId(), sourceCode, vdlQueryParamEntity.getQueryParamName()));
	}

	@Override
	public Response deleteVdlQueryParam(ReqContext reqContext, String sourceCode, String paramName) {
		VdlSourceEntity vdlSourceEntity = vdlSourceDAO.findSourceByTenantAndCode(reqContext.getTenantId(), reqContext.getLang(), sourceCode);
		if (vdlSourceEntity == null) {
			throw new VdlSourceException(ErrEnum.SOURCE_NOT_FOUND, String.format("Source with code '%s' not found", sourceCode));
		}

		if (paramName != null) {
			VdlQueryParamEntity vdlQueryParamEntity = vdlSourceDAO.findQueryParamsByTenantSourceCodeAndParamName(reqContext.getTenantId(), sourceCode,
					paramName);
			if (vdlQueryParamEntity == null) {
				throw new VdlSourceException(ErrEnum.QUERY_PARAMETER_NOT_FOUND,
						String.format("Query parameter '%s' for source '%s' not found", paramName, sourceCode));
			}
		}

		vdlSourceDAO.deleteQueryParamByName(reqContext.getTenantId(), sourceCode, paramName);

		return Response.ok().build();
	}

	private <T extends UpdateVdlSourcePayload> VdlSourceEntity buildVdlSourceEntityFromPayload(String tenantId, String sourceCode, T payload) {
		return VdlSourceEntity.builder()
				.code(sourceCode)
				.tenantId(tenantId)
				.datasource(INTERNAL_DATA_SOURCE_CODE.equalsIgnoreCase(payload.getDatasource()) ? null : payload.getDatasource())
				.sqlSelect(payload.getSqlSelect())
				.filterGeometryColumn(payload.getFilterGeometryColumn())
				.geometryColumn(payload.getGeometryColumn())
				.identifierColumn(payload.getIdentifierColumn())
				.labelColumn(payload.getLabelColumn())
				.fillColor(payload.getFillColor())
				.fillStyle(payload.getFillStyle())
				.borderColor(payload.getBorderColor())
				.borderThick(payload.getBorderThick())
				.fontColor(payload.getFontColor())
				.fontSize(payload.getFontSize())
				.geometryType(payload.getGeometryType())
				.srs(payload.getSrs())
				.styleCode(payload.getStyleCode())
				.styleRefColumn(payload.getStyleRefColumn())
				.build();
	}

	private void insertDescription(ReqContext reqContext, String sourceCode, String description) {
		if (StringUtils.isBlank(description) || sourceCode == null) {
			return;
		}
		I18nEntity i18nEntity = I18nEntity.builder()
				.setTenantId(reqContext.getTenantId())
				.setTableName(TABLE_NAME)
				.setFieldName(FIELD_NAME)
				.setI18nValue(sourceCode)
				.setLang("en")
				.setI18nText(description)
				.build();

		i18nDAO.useTransaction(dao -> {
			i18nDAO.deleteBatch(i18nEntity);
			i18nDAO.insert(i18nEntity);
		});
	}

	@Override
	public List<String> getAllVdlFillStyles(ReqContext reqContext) {
		//returns VdlFillStyle enum values
		return Arrays.stream(VdlFillStyle.values())
				.map(VdlFillStyle::name)
				.collect(Collectors.toList());

	}

	@Override
	public byte[] getFillStylePreview(Integer width, Integer height, String styleCode, String color) {
		var reader = new WKTReader();
		Geometry geom;

		try {
			geom = reader.read("POLYGON ((0 0, 0 100, 100 100, 100 0, 0 0))");
		} catch (ParseException e) {
			throw new RuntimeException(e.getMessage(), e);
		}

		DrawFeature dfb = new DrawFeatureBuilder()
				.withBorder("#00000000", 0)
				.withPaint(color, VdlFillStyle.valueOf(styleCode))
				.build(geom, null, false);

		WmsImage wmsImage = new WmsImage(width, height, new Coordinate(0, 0), new Coordinate(100, 100));
		wmsImage.accept(dfb);

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			wmsImage.saveAsPng(baos);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		} finally {
			wmsImage.close();
		}
		return baos.toByteArray();

	}
}
