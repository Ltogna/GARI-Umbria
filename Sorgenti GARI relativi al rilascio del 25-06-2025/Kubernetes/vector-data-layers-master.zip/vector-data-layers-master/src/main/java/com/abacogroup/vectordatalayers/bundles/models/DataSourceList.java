package com.abacogroup.vectordatalayers.bundles.models;

import com.fasterxml.jackson.annotation.JsonClassDescription;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ConfigurationBundlePojo()
@JsonClassDescription("identify the data to be inserted or replace in the vector data layer sources")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DataSourceList {

	/*
	 * se si aggiorna questo bundle con nuovi campi tenere presente che ConfigSourceProcessor
	 * aggiunge direttamente dataSources anche se non aggiunti da questo bundle
	 */

	@JsonProperty(required = true)
	@JsonPropertyDescription("List of data source codes")
	@NotNull
	@NotEmpty
	@Valid
	private List<String> dataSources;

}
