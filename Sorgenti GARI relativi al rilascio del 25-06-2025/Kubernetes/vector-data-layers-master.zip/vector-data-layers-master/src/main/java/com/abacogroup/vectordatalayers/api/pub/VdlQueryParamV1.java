package com.abacogroup.vectordatalayers.api.pub;

import com.abacogroup.vectordatalayers.api.QueryParamType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class VdlQueryParamV1 {

	private String queryParamName;
	private QueryParamType type;
	private String description;

}
