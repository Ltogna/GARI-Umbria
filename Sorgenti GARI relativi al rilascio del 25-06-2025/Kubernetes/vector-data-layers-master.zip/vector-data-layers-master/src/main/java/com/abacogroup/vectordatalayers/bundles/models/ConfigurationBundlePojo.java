package com.abacogroup.vectordatalayers.bundles.models;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface ConfigurationBundlePojo {
	boolean jsonArray() default false;
}
