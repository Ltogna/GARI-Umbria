package com.abacogroup.vectordatalayers.bundles.models;

import com.abacogroup.vectordatalayers.bundles.config.i18n.I18nAware;
import com.abacogroup.vectordatalayers.bundles.config.i18n.I18nEntry;
import com.abacogroup.vectordatalayers.bundles.config.i18n.I18nMap;
import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonClassDescription;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

@ConfigurationBundlePojo()
@JsonClassDescription("identify the data to be inserted or replace in the vector data layer sources")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SourceInsertOrUpdate implements I18nAware {

	@JsonProperty(required = true)
	@JsonPropertyDescription("id of the source")
	@JsonAlias({"ID", "id"})
	@NotNull
	@Valid
	private SourceID ID;

	@JsonProperty(required = true)
	@JsonPropertyDescription("the data")
	@NotNull
	@Valid
	private SourceData data;

	@JsonPropertyDescription("additional custom query parameters. must match all placeholders in data.sqlSelect and there must be no duplicates")
	@Valid
	@Default
	private List<SourceQueryParam> additionalQueryParams  = new ArrayList<>();

	@JsonProperty(required = true)
	@JsonPropertyDescription("the i18n lang-description map")
	@NotNull
	@Default
	private I18nMap description = new I18nMap();

	@JsonIgnore
	@Override
	public String getI18nCode() {
		return getID().getSourceCode();
	}

	@JsonIgnore
	@Override
	public Set<I18nEntry> getI18n() {
		return getDescription().getI18n();
	}

}
