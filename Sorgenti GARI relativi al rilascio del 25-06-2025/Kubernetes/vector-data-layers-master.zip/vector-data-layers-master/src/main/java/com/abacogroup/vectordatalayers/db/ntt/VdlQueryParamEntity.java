package com.abacogroup.vectordatalayers.db.ntt;

import com.abacogroup.vectordatalayers.api.QueryParamType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VdlQueryParamEntity {

	private String tenantId;
	private String sourceCode;

	private String queryParamName;
	private QueryParamType type;
	private String description;

}
