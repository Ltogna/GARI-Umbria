package com.abacogroup.vectordatalayers.db.dao;

import com.abacogroup.jdbi.EnhancedSqlObject;
import java.util.List;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;


public interface VdlDataSourceDAO extends Transactional<VdlDataSourceDAO>, EnhancedSqlObject {
	
	@SqlUpdate("INSERT INTO vdl_data_sources(code) VALUES(upper(:code))")
	void insertDataSource(@Bind("code") String code);

	@SqlUpdate("DELETE FROM vdl_data_sources WHERE code = upper(:code)")
	void deleteDataSource(@Bind("code") String code);

	/**
	 * Get all distinct data sources on vdl_data_sources table.
	 * N.B: Before changing this query look where it's used on DatasourceHelper.getAdditionalDataSources and act accordingly to not
	 * break its behaviour.
	 * @return list of data sources names
	 */
	@SqlQuery("SELECT code from vdl_data_sources order by code")
	List<String> getDatasourceNames();
	
	@SqlQuery("SELECT case when count(*) > 0 then 1 else 0 end FROM vdl_data_sources WHERE upper(code) = upper(:code)")
	Boolean checkIfPresent(@Bind("code") String code);

}
