package com.abacogroup.vectordatalayers.db;

import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import com.abacogroup.vectordatalayers.api.VdlSourceData;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.lang.reflect.Type;
import org.jdbi.v3.sqlobject.customizer.SqlStatementCustomizerFactory;
import org.jdbi.v3.sqlobject.customizer.SqlStatementCustomizingAnnotation;
import org.jdbi.v3.sqlobject.customizer.SqlStatementParameterCustomizer;

@Retention(RUNTIME)
@Target({PARAMETER})
@SqlStatementCustomizingAnnotation(BindVdlSourceData.BindVdlSourceDataFactory.class)
public @interface BindVdlSourceData {
	class BindVdlSourceDataFactory implements SqlStatementCustomizerFactory {
		@Override
		public SqlStatementParameterCustomizer createForParameter(final Annotation annotation, final Class<?> sqlObjectType, final Method method, final Parameter param, final int index, final Type paramType) 
		{
			return (q, arg) -> {
				final VdlSourceData data = (VdlSourceData) arg;
				q.bind("sql_select", data.getSqlSelect());
				q.bind("filter_geometry_column",data.getFilterGeometryColumn());
				q.bind("geometry_column",data.getGeometryColumn());
				q.bind("identifier_column",data.getIdentifierColumn());
				q.bind("fill_color",data.getFillColor());
				q.bind("border_color",data.getBorderColor());
				q.bind("border_thick",data.getBorderThick());
				q.bind("geometry_type",data.getGeometryType());
				q.bind("srs",data.getSrs());
				q.bind("label_column",data.getLabelColumn());
				q.bind("font_size",data.getFontSize());
				q.bind("font_color",data.getFontColor());
			};
		}
	}
}
