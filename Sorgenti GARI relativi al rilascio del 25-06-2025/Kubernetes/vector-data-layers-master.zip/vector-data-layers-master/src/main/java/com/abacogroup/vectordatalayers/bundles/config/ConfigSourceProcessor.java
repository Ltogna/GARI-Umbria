package com.abacogroup.vectordatalayers.bundles.config;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.vectordatalayers.bundles.config.i18n.I18nHelper;
import com.abacogroup.vectordatalayers.bundles.models.SourceID;
import com.abacogroup.vectordatalayers.bundles.models.SourceInsertOrUpdate;
import com.abacogroup.vectordatalayers.bundles.models.SourceQueryParam;
import com.abacogroup.vectordatalayers.bundles.models.mapper.SourceDataMapper;
import com.abacogroup.vectordatalayers.core.JdbiHelper;
import com.abacogroup.vectordatalayers.db.dao.DAOContainer;
import com.abacogroup.vectordatalayers.db.dao.VdlDataSourceDAO;
import com.abacogroup.vectordatalayers.db.dao.VdlSourceDAO;
import com.abacogroup.vectordatalayers.db.dao.VdlSourceModuleDAO;
import com.abacogroup.vectordatalayers.db.ntt.VdlQueryParamEntity;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validation;
import jakarta.validation.ValidatorFactory;

public class ConfigSourceProcessor implements ConfigMessageProcessor {
	private static final Logger log = LoggerFactory.getLogger(ConfigSourceProcessor.class);
	private static final String DELETE = "delete";
	private static final String UPSERT = "upsert";
	private static final String TABLE_NAME = "vdl_sources";
	private static final String FIELD_NAME = "code";

	private final VdlSourceDAO vdlSourceDAO;
	private final VdlDataSourceDAO vdlDataSourceDAO;
	private final VdlSourceModuleDAO vdlSourceModuleDAO;
	private final I18nHelper i18nHelper;

	private final JdbiHelper jdbiHelper;

	private final ObjectMapper objectMapper;
	
	public ConfigSourceProcessor(DAOContainer daoContainer, I18nHelper i18nHelper,
								 JdbiHelper jdbiHelper, ObjectMapper objectMapper) {
		this.vdlSourceDAO = daoContainer.getVdlSourceDAO();
		this.vdlDataSourceDAO = daoContainer.getVdlDataSourceDAO();
		this.vdlSourceModuleDAO = daoContainer.getVdlSourceModuleDAO();
		this.i18nHelper = i18nHelper;
		this.jdbiHelper = jdbiHelper;
		this.objectMapper = objectMapper;
	}
	

	@Override
	public String getDomainName() {
		return "sources";
	}

	@Override
	public void onMessage(ConfigDataMessage message) {
		log.debug("Ricevuto {}",message);	
		if (message==null) {
			return;
		}

		Map<String, List<Path>> filesByOperation = collectFilesByOperation(message);

		filesByOperation.getOrDefault(DELETE, new ArrayList<>())
				.forEach(path -> this.onDelete(message.getTenantId(), path));
		filesByOperation.getOrDefault(UPSERT, new ArrayList<>())
				.forEach(path -> this.onUpsert(message.getTenantId(), path));
	}

	private void onUpsert(String tenantId, Path currentPath) {
		try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory()) {
			log.debug("Esecuzione di {}", currentPath);

			SourceInsertOrUpdate srciou = objectMapper.readValue(currentPath.toFile(), SourceInsertOrUpdate.class);
			Set<ConstraintViolation<SourceInsertOrUpdate>> constraintViolations = validatorFactory.getValidator().validate(srciou);
			if (!constraintViolations.isEmpty()) {
				throw new ConstraintViolationException(constraintViolations);
			}

			if (null != srciou.getAdditionalQueryParams() && !srciou.getAdditionalQueryParams().isEmpty()) {
				Set<String> uniqueQpNames = new HashSet<>();
				if (!srciou.getAdditionalQueryParams().stream().map(SourceQueryParam::getQueryParamName).allMatch(uniqueQpNames::add)) {
					throw new IllegalArgumentException("Duplicated additional query parameters");
				}
			}

			if(StringUtils.isNotBlank(srciou.getData().getDatasource())
			   && !vdlDataSourceDAO.checkIfPresent(srciou.getData().getDatasource())) {
				log.warn("Data source code '{}' not present. creating new, check if exists in environment!", srciou.getData().getDatasource());
				//throw new IllegalArgumentException(String.format("Data source code '%s' not present", srciou.getData().getDatasource()));

				/*
				 * se si aggiorna vdl_data_sources con nuovi campi tenere presente che questo non si potrà più fare
				 * ma il processor deve rimanere comunque retrocompatibile
				 */
				vdlDataSourceDAO.insertDataSource(srciou.getData().getDatasource());
			}

			// TODO validate query !!!

			this.delete(tenantId, srciou.getID());
			this.insert(tenantId, srciou);

			log.debug("Processato {}", currentPath);
		} catch (Exception e) {
			throw new BundleException(String.format("Error processing file %s for tenant %s", currentPath, tenantId), e);
		}
	}

	private void onDelete(String tenantId, Path currentPath) {
		try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory()) {
			log.debug("Esecuzione di {}", currentPath);

			SourceID srcID = objectMapper.readValue(currentPath.toFile(), SourceID.class);
			Set<ConstraintViolation<SourceID>> constraintViolations = validatorFactory.getValidator().validate(srcID);
			if (!constraintViolations.isEmpty()) {
				throw new ConstraintViolationException(constraintViolations);
			}

			this.delete(tenantId, srcID);

			log.debug("Processato {}", currentPath);
		} catch (Exception e) {
			throw new BundleException(String.format("Error processing file %s for tenant %s", currentPath, tenantId), e);
		}
	}

	private void insert(String tenantId, SourceInsertOrUpdate srciou) {
		vdlSourceDAO.insertSource(SourceDataMapper.INSTANCE.fromBundleData(srciou.getData(), tenantId, srciou.getID().getSourceCode()));

		if (null != srciou.getAdditionalQueryParams() && !srciou.getAdditionalQueryParams().isEmpty()) {
			List<VdlQueryParamEntity> vdlSourceQueryParamEntities = SourceDataMapper.INSTANCE.fromBundleQueryParams(
					srciou.getAdditionalQueryParams(), tenantId, srciou.getID().getSourceCode());
			vdlSourceDAO.insertQueryParams(vdlSourceQueryParamEntities.toArray(VdlQueryParamEntity[]::new));
		}
		
		if (srciou.getData().getModules() != null && !srciou.getData().getModules().isEmpty()) {
			srciou.getData().getModules().forEach(module -> {
				vdlSourceModuleDAO.insertSourceModule(tenantId, srciou.getID().getSourceCode(), module);
			});
		}

		i18nHelper.upsert(tenantId, TABLE_NAME, FIELD_NAME, srciou);
	}

	private void delete(String tenantId, SourceID sourceID) {
		i18nHelper.delete(tenantId, TABLE_NAME, FIELD_NAME, sourceID.getSourceCode());
		vdlSourceDAO.deleteQueryParams(tenantId, sourceID.getSourceCode());
		vdlSourceDAO.deleteSource(tenantId, sourceID.getSourceCode());
		vdlSourceModuleDAO.deleteSourceModuleBySourceCode(tenantId, sourceID.getSourceCode(), null);
	}

	private Map<String, List<Path>> collectFilesByOperation(ConfigDataMessage message) {
		Function<String, String> groupingPredicate = x -> x.endsWith(".delete.json") ? DELETE : UPSERT;

		return message.getConfigFiles().stream()
				.filter(p -> FilenameUtils.isExtension(FilenameUtils.getName(p.getFileName().toString()).toLowerCase(), "json"))
				.collect(Collectors.groupingBy(x -> groupingPredicate.apply(x.toString()),
						Collectors.toCollection(ArrayList::new)));
	}

}
