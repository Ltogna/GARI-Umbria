package com.abacogroup.vectordatalayers.core.dto.mapper;

import java.util.Collection;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.vectordatalayers.api.VdlQueryParam;
import com.abacogroup.vectordatalayers.api.pub.VdlQueryParamV1;

@Mapper
public interface VdlQueryParamV1Mapper {

    VdlQueryParamV1Mapper INSTANCE = Mappers.getMapper(VdlQueryParamV1Mapper.class);

    List<VdlQueryParamV1> toResV1(Collection<VdlQueryParam> queryParamEntities);

    VdlQueryParamV1 toResV1(VdlQueryParam queryParamEntity);

}
