package com.abacogroup.vectordatalayers.bundles.config;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.abacogroup.vectordatalayers.bundles.models.DataSourceList;
import com.abacogroup.vectordatalayers.core.DatasourceHelper;
import com.abacogroup.vectordatalayers.db.dao.DAOContainer;
import com.abacogroup.vectordatalayers.db.dao.VdlDataSourceDAO;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validation;
import jakarta.validation.ValidatorFactory;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DataSourceProcessor implements ConfigMessageProcessor {
	private static final Logger log = LoggerFactory.getLogger(DataSourceProcessor.class);
	private static final String DELETE = "delete";
	private static final String INSERT = "insert";

	private final VdlDataSourceDAO vdlDataSourceDAO;
	private final DatasourceHelper datasourceHelper;

	private final ObjectMapper objectMapper;

	public DataSourceProcessor(DAOContainer daoContainer, DatasourceHelper datasourceHelper, ObjectMapper objectMapper) {
		this.vdlDataSourceDAO = daoContainer.getVdlDataSourceDAO();
		this.datasourceHelper = datasourceHelper;
		this.objectMapper = objectMapper;
	}


	@Override
	public String getDomainName() {
		return "data-sources";
	}


	@Override
	public void onMessage(ConfigDataMessage message) {
		/*
		 * se si aggiorna questo bundle con nuovi campi tenere presente che ConfigSourceProcessor
		 * aggiunge direttamente dataSources anche se non aggiunti da questo bundle
		 */

		log.debug("Ricevuto {}",message);
		if (message==null) {
			return;
		}

		Map<String, List<Path>> filesByOperation = collectFilesByOperation(message);

		filesByOperation.getOrDefault(DELETE, new ArrayList<>())
		.forEach(path -> this.insertOrDeleteDataSources(path, DELETE));
		filesByOperation.getOrDefault(INSERT, new ArrayList<>())
		.forEach(path -> this.insertOrDeleteDataSources(path, INSERT));
	}

	private void insertOrDeleteDataSources(Path currentPath, String operation) {
		try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory()) {
			log.debug("Execution of {}", currentPath);

			DataSourceList dataSourceList = objectMapper.readValue(currentPath.toFile(), DataSourceList.class);
			Set<ConstraintViolation<DataSourceList>> constraintViolations = validatorFactory.getValidator().validate(dataSourceList);
			if (!constraintViolations.isEmpty()) {
				throw new ConstraintViolationException(constraintViolations);
			}

			datasourceHelper.buildAdditionalDataSourcesOrThrow(dataSourceList.getDataSources());

			List<String> presentDataSources = vdlDataSourceDAO.getDatasourceNames();


			dataSourceList.getDataSources().forEach(code -> {
				if(INSERT.equals(operation) && !presentDataSources.contains(code.toUpperCase())) {
					vdlDataSourceDAO.insertDataSource(code);
				} else if(DELETE.equals(operation) && presentDataSources.contains(code.toUpperCase())) {
					vdlDataSourceDAO.deleteDataSource(code);
				}
			});

			log.debug("Processed {}", currentPath);
		} catch (Exception e) {
			throw new BundleException(String.format("Error processing file %s", currentPath), e);
		}
	}

	private Map<String, List<Path>> collectFilesByOperation(ConfigDataMessage message) {
		Function<String, String> groupingPredicate = x -> x.endsWith(".delete.json") ? DELETE : INSERT;

		return message.getConfigFiles().stream()
				.filter(p -> FilenameUtils.isExtension(FilenameUtils.getName(p.getFileName().toString()).toLowerCase(), "json"))
				.collect(Collectors.groupingBy(x -> groupingPredicate.apply(x.toString()),
						Collectors.toCollection(ArrayList::new)));
	}

}
