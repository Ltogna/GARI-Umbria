package com.abacogroup.vectordatalayers.core.exceptions;

import com.abacogroup.vectordatalayers.common.exceptions.AbstractAppException;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response.Status;

public class VdlSourceException extends AbstractAppException {

	private static final long serialVersionUID = -6457470234269628323L;

	public VdlSourceException(ErrEnum code, String message) {
		super(new ErrorBody(code.name(), message), code.statusCode);
	}

	public enum ErrEnum {
		SOURCE_NOT_FOUND(Status.NOT_FOUND.getStatusCode()),
		SOURCE_ALREADY_EXISTS(Status.BAD_REQUEST.getStatusCode()),
		DATA_SOURCE_NOT_FOUND(Status.NOT_FOUND.getStatusCode()),
		QUERY_PARAMETER_NOT_FOUND(Status.NOT_FOUND.getStatusCode()),
		QUERY_PARAMETER_ALREADY_EXISTS(Status.BAD_REQUEST.getStatusCode()),
		UNREADABLE_QUERY_PARAMETER(Status.BAD_REQUEST.getStatusCode()),
		UNREADABLE_COLUMN_VALUE(Status.BAD_REQUEST.getStatusCode()),
		;

		private final int statusCode;

		ErrEnum(int statusCode) {
			this.statusCode = statusCode;
		}
	}

	@Schema(name = "VdlSourceExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private final String code;
		private final String message;

		public ErrorBody(String code, String message) {
			this.code = code;
			this.message = message;
		}

		@Override
		@Schema(allowableValues = {
				"SOURCE_NOT_FOUND",
				"UNREADABLE_QUERY_PARAMETER"
		})
		public String getErrorCode() {
			return code;
		}

		@Override
		@Schema
		public String getMessage() {
			return message;
		}
	}
}
