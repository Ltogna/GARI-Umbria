package com.abacogroup.vectordatalayers.core.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VdlSourceIdentifier {
	private String code;
	private String tenantId;
}
