package com.abacogroup.vectordatalayers.db.dao;

import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.vectordatalayers.db.ntt.LayerStyleEntity;

public interface LayerStyleDAO extends Transactional<LayerStyleDAO>, EnhancedSqlObject {
	

	@SqlUpdate("""
			INSERT INTO vdl_Layer_styles (tenant_id, style_code, ref_code, fill_color, border_color, border_thick, font_color, font_size, 
			 user_id_insert, user_id_delete, dt_insert, dt_delete) 
			VALUES (:tenantId, :styleCode, :refCode, :fillColor, :borderColor, :borderThick, :fontColor, :fontSize, 
			 :userInsert, null, §current_timestamp§, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))
			""")
	void insert(@Bind("tenantId") String tenantId, @Bind("userInsert") String userInsert, @BindBean LayerStyleEntity entity);	

	@SqlUpdate("""
			update vdl_layer_styles 
			   set user_id_delete = :userDelete, 
			   dt_delete = §current_timestamp§ 
			where tenant_id = :tenantId 
			   and style_code = :styleCode 
			   and ref_code = :refCode 
			   and §current_timestamp§ between dt_insert and dt_delete
			""")
	void deleteByTenantStyleCodeAndRefCode(@Bind("tenantId") String tenantId, @Bind("userDelete") String userDelete, @Bind("styleCode") String styleCode, @Bind("refCode") String refCode);

	@SqlUpdate("""
			update vdl_layer_styles 
			   set user_id_delete = :userDelete, 
			   dt_delete = §current_timestamp§ 
			where tenant_id = :tenantId 
			   and style_code = :styleCode  
			   and §current_timestamp§ between dt_insert and dt_delete
			""")
	void deleteByTenantAndStyleCode(@Bind("tenantId") String tenantId, @Bind("userDelete") String userDelete, @Bind("styleCode") String styleCode);

	@SqlUpdate("""
			update vdl_layer_styles 
			   set user_id_delete = :userDelete, 
			   dt_delete = §current_timestamp§ 
			where tenant_id = :tenantId 
			and §current_timestamp§ between dt_insert and dt_delete
			""")
	void deleteByTenantId(@Bind("tenantId") String tenantId, @Bind("userDelete") String userDelete);

	@SqlQuery("""
			select style_code, 
                   ref_code, 
                   fill_color, 
                   border_color, 
                   border_thick, 
                   font_color, 
                   font_size
              from vdl_layer_styles 
             where tenant_id = :tenantId 
               and style_code = :styleCode 
               and ref_code = :refCode 
               and §current_timestamp§ between dt_insert and dt_delete
            """)
	@RegisterBeanMapper(LayerStyleEntity.class)
	LayerStyleEntity findByTenantStyleCodeAndRefCode(@Bind("tenantId") String tenantId, @Bind("styleCode") String styleCode, @Bind("refCode") String refCode);
	
	@SqlQuery("""
			select style_code, 
                   ref_code, 
                   fill_color, 
                   border_color, 
                   border_thick, 
                   font_color, 
                   font_size 
              from vdl_layer_styles 
             where tenant_id = :tenantId 
               and style_code = :styleCode 
               and §current_timestamp§ between dt_insert and dt_delete
            """)
	@RegisterBeanMapper(LayerStyleEntity.class)
	List<LayerStyleEntity> findByTenantAndStyleCode(@Bind("tenantId") String tenantId, @Bind("styleCode") String styleCode);
	

}
