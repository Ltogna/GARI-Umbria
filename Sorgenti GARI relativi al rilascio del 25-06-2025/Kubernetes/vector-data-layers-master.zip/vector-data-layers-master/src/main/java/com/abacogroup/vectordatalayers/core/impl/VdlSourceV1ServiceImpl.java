package com.abacogroup.vectordatalayers.core.impl;

import java.util.ArrayList;
import java.util.List;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.vectordatalayers.api.VdlSource;
import com.abacogroup.vectordatalayers.api.pub.VdlSourceV1;
import com.abacogroup.vectordatalayers.common.resources.ReqContext;
import com.abacogroup.vectordatalayers.core.VdlSourceService;
import com.abacogroup.vectordatalayers.core.VdlSourceV1Service;
import com.abacogroup.vectordatalayers.core.dto.mapper.VdlSourceV1Mapper;

public class VdlSourceV1ServiceImpl implements VdlSourceV1Service {

	private final VdlSourceService vdlSourceService;

	public VdlSourceV1ServiceImpl(VdlSourceService vdlSourceService) {
		this.vdlSourceService = vdlSourceService;
	}

	@Override
	public List<VdlSourceV1> getTenantSources(ReqContext reqContext, String module) {

		List<VdlSourceV1> resut = new ArrayList<>();
		InfiniteListResults<VdlSource> vdlSourceInfinite = null;
		do {
			String nextkey = vdlSourceInfinite != null ? vdlSourceInfinite.getNextKey() : null;
			vdlSourceInfinite = vdlSourceService.getAllVdlSources(reqContext, null, nextkey, 100, module);
			
			resut.addAll(vdlSourceInfinite.map(VdlSourceV1Mapper.INSTANCE::toResV1).getRecords());
			
		} while (vdlSourceInfinite != null && vdlSourceInfinite.getNextKey() != null);
		
		return resut;
	}

	@Override
	public VdlSourceV1 getSourceData(ReqContext reqContext, String code) {
		return VdlSourceV1Mapper.INSTANCE.toResV1(vdlSourceService.getVdlSourceByCode(reqContext, code));
	}
	
}
