package com.abacogroup.vectordatalayers.core;

import static com.abacogroup.bundles.Constants.DEFAULT_EXCHANGE_NAME;
import static com.abacogroup.bundles.Constants.TOPIC_LOG_PREFIX;
import static com.abacogroup.vectordatalayers.core.DatasourceHelper.jdbiName;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.jdbi.v3.core.Jdbi;

import com.abacogroup.bundles.listener.configdata.ConfigDataLogMessage;
import com.abacogroup.vectordatalayers.VectorDataLayersConfig;
import com.abacogroup.wms4j.resources.core.BaseWmsResource;
import com.rabbitmq.client.AMQP.Queue.DeclareOk;
import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;

import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class WmsSynchronizer {

	private final VectorDataLayersConfig configuration;
	private final Environment environment;
	private final DatasourceHelper datasourceHelper;
	private final JdbiHelper jdbiHelper;
	private final LayerService layerService;
	private final BaseWmsResource wmsResource;
	private final Connection connection;

	private Channel singleChannel;

	public WmsSynchronizer(VectorDataLayersConfig configuration, Environment environment,
			DatasourceHelper datasourceHelper, JdbiHelper jdbiHelper,
			LayerService layerService, BaseWmsResource wmsResource,
			Connection connection) {
		this.configuration = configuration;
		this.environment = environment;
		this.datasourceHelper = datasourceHelper;
		this.jdbiHelper = jdbiHelper;
		this.layerService = layerService;
		this.wmsResource = wmsResource;
		this.connection = connection;
	}

	public void start() throws IOException {
		Channel channel = getOrCreateChannel();

		DeclareOk queueDeclare = channel.queueDeclare();
		channel.queueBind(queueDeclare.getQueue(), DEFAULT_EXCHANGE_NAME, String.format("%s.%s", TOPIC_LOG_PREFIX, "vector-data-layers"));

		channel.basicConsume(queueDeclare.getQueue(), true, (consumerTag, delivery) -> {
			String tenant = delivery.getProperties().getHeaders().get("tenant").toString();
			log.info("Received Sync Request from tenant '{}', waiting 1 sec...", tenant);
			log.debug("message: {}", new String(delivery.getBody(), StandardCharsets.UTF_8));

			ConfigDataLogMessage configDataLogMessage = environment.getObjectMapper().readValue(delivery.getBody(), ConfigDataLogMessage.class);

			if (!ConfigDataLogMessage.INFO.equals(configDataLogMessage.getLevel())) {
				log.warn("received config log message with level {}. skip sync", configDataLogMessage.getLevel());
				return;
			}

			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				return;
			}

			this.resyncWmsResource(tenant);
			this.resyncAdditionalDataSources();

		}, consumerTag -> {
		});

		log.info("wms sync started");

	}

	protected void resyncAdditionalDataSources() {
		List<String> registeredDataSources = jdbiHelper.getRegisteredAdditionalDataSources();
		jdbiHelper.clearDataSources();

		registeredDataSources.forEach(name -> environment.healthChecks().unregister(jdbiName(name)));

		Map<String, DataSourceFactory> additionalDataSources = new HashMap<>();
		Optional.ofNullable(configuration.getAdditionalDataSources())
				.ifPresent(additionalDataSources::putAll);

		Optional.ofNullable(datasourceHelper.getAdditionalDataSources())
				.ifPresent(additionalDataSources::putAll);

		additionalDataSources.forEach((name, dsf) -> {
			try {
				Jdbi jdbi = DatasourceHelper.createJdbi(dsf, environment, jdbiName(name), configuration.isEnableSpatialVectorAcceleration());

				jdbiHelper.putIfAbsent(name, jdbi);
			} catch (Exception e) {
				// TODO shutdown?
				log.error("error creating jdbi for additional datasource '{}'", name, e);
			}
		});

		log.info("Additional data sources synced");
		try {
			jdbiHelper.datasourceCheck();
		} catch (IllegalStateException ise) {
			log.error(ise.getMessage(), ise);
		}
	}

	protected void resyncWmsResource(String tenant) {
		wmsResource.getLayers().removeIf(l -> l.getTenantConstraint().equals(tenant));
		layerService.getWMSLayers(tenant).forEach(wmsResource::addLayer);
		log.info("WmsResource synced for tenant '{}'", tenant);
	}

	private Channel getOrCreateChannel() throws IOException {
		if (singleChannel == null) {
			Channel channel = connection.createChannel();
			channel.exchangeDeclare(DEFAULT_EXCHANGE_NAME, BuiltinExchangeType.TOPIC);

			this.singleChannel = channel;
		}

		return this.singleChannel;
	}

}
