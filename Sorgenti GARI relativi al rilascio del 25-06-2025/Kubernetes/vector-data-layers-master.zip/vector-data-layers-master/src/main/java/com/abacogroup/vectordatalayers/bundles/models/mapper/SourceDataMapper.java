package com.abacogroup.vectordatalayers.bundles.models.mapper;

import com.abacogroup.vectordatalayers.api.VdlSourceData;
import com.abacogroup.vectordatalayers.bundles.models.SourceData;
import com.abacogroup.vectordatalayers.bundles.models.SourceQueryParam;
import com.abacogroup.vectordatalayers.db.ntt.VdlQueryParamEntity;
import com.abacogroup.vectordatalayers.db.ntt.VdlSourceEntity;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface SourceDataMapper {

    SourceDataMapper INSTANCE = Mappers.getMapper(SourceDataMapper.class);

    @Mapping(target = "borderColor", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getBorderColor()))")
    @Mapping(target = "borderThick", source = "data.borderThick")
    @Mapping(target = "fillColor", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getFillColor()))")
    @Mapping(target = "fillStyle", source = "data.fillStyle")
    @Mapping(target = "filterGeometryColumn", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getFilterGeometryColumn()))")
    @Mapping(target = "geometryColumn", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getGeometryColumn()))")
    @Mapping(target = "geometryType", source = "data.geometryType")
    @Mapping(target = "identifierColumn", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getIdentifierColumn()))")
    @Mapping(target = "sqlSelect", source = "data.sqlSelect")
    @Mapping(target = "srs", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getSrs()))")
    @Mapping(target = "labelColumn", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getLabelColumn()))")
    @Mapping(target = "fontColor", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getFontColor()))")
    @Mapping(target = "fontSize", source = "data.fontSize")
    @Mapping(target = "datasource", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getDatasource()))")
    @Mapping(target = "customQueryParams", ignore = true)
    VdlSourceData fromBundleData(SourceData data);

    @Mapping(target = "borderColor", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getBorderColor()))")
    @Mapping(target = "borderThick", source = "data.borderThick")
    @Mapping(target = "fillColor", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getFillColor()))")
    @Mapping(target = "fillStyle", source = "data.fillStyle")
    @Mapping(target = "filterGeometryColumn", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getFilterGeometryColumn()))")
    @Mapping(target = "geometryColumn", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getGeometryColumn()))")
    @Mapping(target = "geometryType", source = "data.geometryType")
    @Mapping(target = "identifierColumn", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getIdentifierColumn()))")
    @Mapping(target = "sqlSelect", source = "data.sqlSelect")
    @Mapping(target = "srs", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getSrs()))")
    @Mapping(target = "labelColumn", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getLabelColumn()))")
    @Mapping(target = "fontColor", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getFontColor()))")
    @Mapping(target = "fontSize", source = "data.fontSize")
    @Mapping(target = "datasource", expression = "java(org.apache.commons.lang3.StringUtils.trimToNull(data.getDatasource()))")
    @Mapping(target = "description", ignore = true)
    VdlSourceEntity fromBundleData(SourceData data, String tenantId, String code);


    VdlQueryParamEntity fromBundleQueryParam(SourceQueryParam queryParam, String tenantId, String sourceCode);

	default List<VdlQueryParamEntity> fromBundleQueryParams(Collection<SourceQueryParam> queryParams, String tenantId, String code) {
        if (queryParams == null) {
            return null;
        }

		return queryParams.stream()
                .map(qp -> this.fromBundleQueryParam(qp, tenantId, code))
                .collect(Collectors.toList());
	}

}
