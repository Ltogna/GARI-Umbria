package com.abacogroup.vectordatalayers.api.pub;

import com.abacogroup.vectordatalayers.api.VdlFillStyle;
import com.abacogroup.vectordatalayers.api.VdlGeometryType;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class VdlSourceDataV1 {

	private String datasource;
	private String sqlSelect;
	private String filterGeometryColumn;
	private String geometryColumn;
	private String identifierColumn; // non usata
	private String labelColumn;

	private String fillColor;
	private VdlFillStyle fillStyle;
	private String borderColor;
	private String fontColor;
	private int fontSize;

	private VdlGeometryType geometryType; // non usata ?
	private String srs; // non usata ?

	private int borderThick;

	@Default
	private List<VdlQueryParamV1> customQueryParams = new ArrayList<>();

	@Deprecated
	public int getBorderTick() {
		return borderThick;
	}
}
