package com.abacogroup.vectordatalayers.bundles.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@ConfigurationBundlePojo(jsonArray = true)
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class AdditionalDataSourcePojo extends AdditionalDataSourceDeletePojo {

	private String driverClass;

	@JsonProperty(required = true)
	@NotBlank
	private String url;

	private String user;

	@JsonPropertyDescription("password encoded in base 64")
	@Pattern(regexp = "^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{4})$")
	private String passwordEncoded;

	private String validationQuery;

	@Min(0)
	private Integer minSize;

	@Min(0)
	private Integer initialSize;

}
