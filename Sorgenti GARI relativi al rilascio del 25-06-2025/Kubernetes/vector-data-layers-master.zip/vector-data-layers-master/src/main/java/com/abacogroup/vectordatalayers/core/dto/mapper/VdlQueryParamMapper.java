package com.abacogroup.vectordatalayers.core.dto.mapper;

import java.util.Collection;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.abacogroup.vectordatalayers.api.VdlQueryParam;
import com.abacogroup.vectordatalayers.db.ntt.VdlQueryParamEntity;

@Mapper
public interface VdlQueryParamMapper {

    VdlQueryParamMapper INSTANCE = Mappers.getMapper(VdlQueryParamMapper.class);

    List<VdlQueryParam> fromEntity(Collection<VdlQueryParamEntity> queryParamEntities);

    VdlQueryParam fromEntity(VdlQueryParamEntity queryParamEntity);

}
