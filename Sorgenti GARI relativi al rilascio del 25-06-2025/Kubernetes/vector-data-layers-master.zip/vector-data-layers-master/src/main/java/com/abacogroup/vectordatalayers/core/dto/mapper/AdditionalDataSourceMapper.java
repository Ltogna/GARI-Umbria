package com.abacogroup.vectordatalayers.core.dto.mapper;

import com.abacogroup.vectordatalayers.db.ntt.AdditionalDataSourceEntity;
import io.dropwizard.db.DataSourceFactory;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.factory.Mappers;

@Mapper
public abstract class AdditionalDataSourceMapper {

    public static final AdditionalDataSourceMapper INSTANCE = Mappers.getMapper(AdditionalDataSourceMapper.class);

    @Mapping(target = "driverClass", source = "driverClass", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
    @Mapping(target = "url", source = "dbUrl")
    @Mapping(target = "user", source = "dbUser", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
    @Mapping(target = "password", source = "dbPasswordEncoded", qualifiedByName = "decodePassword", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
    @Mapping(target = "validationQuery", source = "validationQuery", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
    @Mapping(target = "minSize", source = "minSize", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
    @Mapping(target = "initialSize", source = "initialSize", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
    public abstract DataSourceFactory fromEntity(AdditionalDataSourceEntity entity);

    @Named("decodePassword")
    protected String decodePassword(String passwordEncoded) {
        return new String(Base64.getDecoder().decode(passwordEncoded), StandardCharsets.UTF_8);
    }

}
