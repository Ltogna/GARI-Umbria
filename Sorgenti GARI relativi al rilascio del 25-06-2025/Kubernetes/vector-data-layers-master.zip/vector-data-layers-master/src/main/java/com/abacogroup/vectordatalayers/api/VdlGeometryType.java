package com.abacogroup.vectordatalayers.api;

public enum VdlGeometryType {

	LINEAL, POLYGONAL, PUNTAL;

}
