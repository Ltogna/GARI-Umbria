package com.abacogroup.vectordatalayers.resources.pub;

import java.util.Map;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.vectordatalayers.api.Layer;
import com.abacogroup.vectordatalayers.api.LayerGeometry;
import com.abacogroup.vectordatalayers.api.req.LayerGeometriesSearchReq;
import com.abacogroup.vectordatalayers.common.resources.ReqContext;
import com.abacogroup.vectordatalayers.core.LayerService;
import com.abacogroup.vectordatalayers.resources.ResourceConstants;
import com.codahale.metrics.annotation.Timed;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.security.PermitAll;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.UriInfo;

@Timed
@Path(ResourceConstants.API_PUB + "/layers")
@PermitAll
@Tag(name = "Layers", description = "Operations on Layers")
public class LayerPublicResources {

	private final LayerService layerService;

	public LayerPublicResources(LayerService layerService) {
		this.layerService = layerService;
	}

	@GET
	//@Path("/")
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "layers by tenant", description = "Get infinite list of layers by tenant id")
	@ApiResponse(responseCode = "200", description = "list of layers", useReturnTypeSchema = true)
	public InfiniteListResults<Layer> getLayers(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
			@Parameter(description = "page size") @QueryParam("pageSize") @DefaultValue("10") Integer pageSize
	) {
		ReqContext reqContext = new ReqContext(tenantId, null, lang);

		return layerService.getLayers(reqContext, nextKey, pageSize);
	}

	@POST
	@Path("/{layerCode}/geometries")
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "layer geometries", description = "Get infinite list of layer geometries by layer code and tenant id",
			parameters = {
					@Parameter(name = "additionalFilters", in = ParameterIn.QUERY, schema=@Schema(implementation = Map.class), example = "{\"foo\": \"bar\"}")
			})
	@ApiResponse(responseCode = "200", description = "list of layer geometries", useReturnTypeSchema = true)
	public InfiniteListResults<LayerGeometry> getLayerGeometries(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "layer code") @PathParam("layerCode") String layerCode,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
			@Parameter(description = "page size") @QueryParam("pageSize") @DefaultValue("10") Integer pageSize,
			@Context UriInfo uriInfo,
			@Valid @NotNull LayerGeometriesSearchReq searchReq
	) {
		ReqContext reqContext = new ReqContext(tenantId, null, lang);

		return layerService.getLayerGeometries(reqContext, layerCode, searchReq.getTouchingGeometry(), false, uriInfo.getQueryParameters(), nextKey, pageSize);
	}
	
	@POST
	@Path("/{layerCode}/geometries/intersection")
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "intersected layer geometries", description = "Get infinite list of layer intersected geometries by layer code and tenant id",
	parameters = {
			@Parameter(name = "additionalFilters", in = ParameterIn.QUERY, schema=@Schema(implementation = Map.class), example = "{\"foo\": \"bar\"}")
	})
	@ApiResponse(responseCode = "200", description = "list of layer geometries", useReturnTypeSchema = true)
	public InfiniteListResults<LayerGeometry> getLayerIntersectedGeometries(
			@HeaderParam("accept-language") @DefaultValue("en") String lang,
			@Parameter(description = "tenant id") @PathParam("tenant") String tenantId,
			@Parameter(description = "layer code") @PathParam("layerCode") String layerCode,
			@Parameter(description = "Next key used for infinite pagination") @QueryParam("nextKey") String nextKey,
			@Parameter(description = "page size") @QueryParam("pageSize") @DefaultValue("10") Integer pageSize,
			@Context UriInfo uriInfo,
			@Valid @NotNull LayerGeometriesSearchReq searchReq
			) {
		ReqContext reqContext = new ReqContext(tenantId, null, lang);
		
		return layerService.getLayerGeometries(reqContext, layerCode, searchReq.getTouchingGeometry(), true, uriInfo.getQueryParameters(), nextKey, pageSize);
	}

}
