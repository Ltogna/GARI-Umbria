insert into vdl_sources (tenant_id, code,
                         sql_select,
                         filter_geometry_column, geometry_column, identifier_column, label_column,
                         fill_color, border_thick, border_color, font_size, font_color, geometry_type, srs)
values (:test_tenant, 'TEST_1',
        'select "group", id as test_id, geom, "group" || ''_'' || name as custom_name from test_layers where "group" = ''1'' and {spatial_where_clause}',
        'geom', 'geom', 'test_id', 'custom_name',
        '#FFFF11', 1, '#000011', 11, '#FF0011', 'POLYGONAL', 'EPSG:32632');

insert into vdl_sources (tenant_id, code,
                         sql_select,
                         filter_geometry_column, geometry_column, identifier_column, label_column,
                         fill_color, border_thick, border_color, font_size, font_color, geometry_type, srs)
values (:test_tenant, 'TEST_2',
        'select "group", id as test_id, geom, name from test_layers where "group" = ''2'' and {spatial_where_clause}',
        'geom', 'geom', 'test_id', 'name',
        '#FFFF22', 2, '#000022', 12, '#FF0022', 'POLYGONAL', 'EPSG:32632');

insert into vdl_sources (tenant_id, code,
                         sql_select,
                         filter_geometry_column, geometry_column, identifier_column, label_column,
                         fill_color, border_thick, border_color, font_size, font_color, geometry_type, srs)
values (:test_tenant, 'TEST_3',
        'select "group", id as test_id, geom from test_layers where "group" = ''3'' and {spatial_where_clause}',
        'geom', 'geom', 'test_id', null,
        null, 3, null, null, null, 'LINEAL', 'EPSG:32632');

insert into vdl_sources (tenant_id, code,
                         sql_select,
                         filter_geometry_column, geometry_column, identifier_column, label_column,
                         fill_color, border_thick, border_color, font_size, font_color, geometry_type, srs)
values ('*', 'TEST_4',
        'select "group", id as test_id, geom, name from test_layers where "group" = ''4'' and {spatial_where_clause}',
        'geom', 'geom', 'test_id', 'name',
        null, 4, '#000044', 14, '#FF0044', 'PUNTAL', 'EPSG:32632');

insert into vdl_sources (tenant_id, code,
                         sql_select,
                         filter_geometry_column, geometry_column, identifier_column, label_column,
                         fill_color, border_thick, border_color, font_size, font_color, geometry_type, srs)
values (:test_tenant, 'TEST_5',
        'select "group", id as test_id, geom from test_layers where "group" = ''5'' and {spatial_where_clause}',
        'geom', 'geom', 'test_id', null,
        null, 5, '#000055', null, null, 'PUNTAL', 'EPSG:32632');

-- I18N --
insert into vdl_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'vdl_sources', 'code', 'TEST_1', 'it', 'Test Uno');
insert into vdl_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'vdl_sources', 'code', 'TEST_2', 'it', 'Test Due');
insert into vdl_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'vdl_sources', 'code', 'TEST_3', 'it', 'Test Tre');
insert into vdl_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values ('*'         , 'vdl_sources', 'code', 'TEST_4', 'it', 'Test Quattro');
insert into vdl_i18n_values (tenant_id, table_name, field_name, i18n_value, lang, i18n_text)
values (:test_tenant, 'vdl_sources', 'code', 'TEST_5', 'it', 'Test Cinque');



