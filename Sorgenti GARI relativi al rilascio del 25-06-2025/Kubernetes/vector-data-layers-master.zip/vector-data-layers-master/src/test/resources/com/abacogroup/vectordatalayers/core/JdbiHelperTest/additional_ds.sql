
INSERT INTO vdl_data_sources(code)
values (upper('main'));

INSERT INTO vdl_data_sources(code)
values (upper('ds1'));

INSERT INTO vdl_data_sources(code)
values (upper('ds2'));

INSERT INTO vdl_data_sources(code)
values (upper('ds3'));

INSERT INTO vdl_data_sources(code)
values (upper('ds4'));
