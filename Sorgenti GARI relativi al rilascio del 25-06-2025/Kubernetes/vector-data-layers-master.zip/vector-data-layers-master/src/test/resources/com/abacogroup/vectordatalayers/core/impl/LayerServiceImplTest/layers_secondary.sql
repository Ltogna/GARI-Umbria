insert into test_layers_secondary (id, tenant_id, name, "group", geom)
values (2001, :test_tenant, 'a', '2', :p01);
insert into test_layers_secondary (id, tenant_id, name, "group", geom)
values (2002, :test_tenant, 'b', '2', :p02);
insert into test_layers_secondary (id, tenant_id, name, "group", geom)
values (2003, :test_tenant, 'c', '2', :p03);
insert into test_layers_secondary (id, tenant_id, name, "group", geom)
values (2004, :test_tenant, 'd', '2', :p04);
insert into test_layers_secondary (id, tenant_id, name, "group", geom)
values (2005, :test_tenant, 'e', '2', :p05);
insert into test_layers_secondary (id, tenant_id, name, "group", geom)
values (2006, :test_tenant, 'f', '2', :p06);



