insert into vdl_sources (tenant_id, code,
                         sql_select, datasource,
                         filter_geometry_column, geometry_column, identifier_column, label_column,
                         geometry_type, srs)
values (:test_tenant, 'TEST_1',
        'select * from table', upper('main'),
        'geom', 'geom', 'test_id', 'label',
        'POLYGONAL', 'EPSG:32632');

insert into vdl_sources (tenant_id, code,
                         sql_select, datasource,
                         filter_geometry_column, geometry_column, identifier_column, label_column,
                         geometry_type, srs)
values (:test_tenant, 'TEST_2',
    'select * from table', upper('ds1'),
        'geom', 'geom', 'test_id', 'label',
        'POLYGONAL', 'EPSG:32632');

insert into vdl_sources (tenant_id, code,
                         sql_select, datasource,
                         filter_geometry_column, geometry_column, identifier_column, label_column,
                         geometry_type, srs)
values (:test_tenant, 'TEST_3',
    'select * from table', upper('ds2'),
        'geom', 'geom', 'test_id', 'label',
        'POLYGONAL', 'EPSG:32632');

insert into vdl_sources (tenant_id, code,
                         sql_select, datasource,
                         filter_geometry_column, geometry_column, identifier_column, label_column,
                         geometry_type, srs)
values (:test_tenant, 'TEST_4',
    'select * from table', upper('ds1'),
        'geom', 'geom', 'test_id', 'label',
        'POLYGONAL', 'EPSG:32632');

insert into vdl_sources (tenant_id, code,
                         sql_select, datasource,
                         filter_geometry_column, geometry_column, identifier_column, label_column,
                         geometry_type, srs)
values (:test_tenant, 'TEST_5',
    'select * from table', upper('main'),
        'geom', 'geom', 'test_id', 'label',
        'POLYGONAL', 'EPSG:32632');

insert into vdl_sources (tenant_id, code,
                         sql_select, datasource,
                         filter_geometry_column, geometry_column, identifier_column, label_column,
                         geometry_type, srs)
values (:test_tenant, 'TEST_6',
    'select * from table', upper('main'),
        'geom', 'geom', 'test_id', 'label',
        'POLYGONAL', 'EPSG:32632');




