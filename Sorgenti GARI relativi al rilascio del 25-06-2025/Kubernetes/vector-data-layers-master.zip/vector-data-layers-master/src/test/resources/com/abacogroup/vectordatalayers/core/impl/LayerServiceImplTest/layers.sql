insert into test_layers (id, tenant_id, name, "group", geom)
values (1001, :test_tenant, 'a', '1', :p01);
insert into test_layers (id, tenant_id, name, "group", geom)
values (1002, :test_tenant, 'b', '1', :p02);
insert into test_layers (id, tenant_id, name, "group", geom)
values (1003, :test_tenant, 'c', '1', :p03);
insert into test_layers (id, tenant_id, name, "group", geom)
values (1004, :test_tenant, 'd', '1', :p04);
insert into test_layers (id, tenant_id, name, "group", geom)
values (1005, :test_tenant, 'e', '1', :p05);
insert into test_layers (id, tenant_id, name, "group", geom)
values (1006, :test_tenant, 'f', '1', :p06);

insert into test_layers (id, tenant_id, name, "group", geom)
values (3001, :test_tenant, null, '3', :l01);
insert into test_layers (id, tenant_id, name, "group", geom)
values (3002, :test_tenant, null, '3', :l02);
insert into test_layers (id, tenant_id, name, "group", geom)
values (3003, :test_tenant, null, '3', :l03);
insert into test_layers (id, tenant_id, name, "group", geom)
values (3004, :test_tenant, null, '3', :l04);
insert into test_layers (id, tenant_id, name, "group", geom)
values (3005, :test_tenant, null, '3', :l05);
insert into test_layers (id, tenant_id, name, "group", geom)
values (3006, :test_tenant, null, '3', :l06);


