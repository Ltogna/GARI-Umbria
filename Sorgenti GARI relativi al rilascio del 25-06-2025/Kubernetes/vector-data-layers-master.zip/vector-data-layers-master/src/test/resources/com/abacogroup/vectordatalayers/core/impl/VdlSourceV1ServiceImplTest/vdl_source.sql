insert into vdl_sources (tenant_id, code,
                         datasource, sql_select,
                         filter_geometry_column, geometry_column, identifier_column, label_column,
                         fill_color, border_thick, border_color, font_size, font_color, geometry_type, srs)
values (:test_tenant, 'TEST_1',
        upper('ds1'), 'select id as test_id, geom, descr from geom_table_one where {spatial_where_clause}',
        'geom', 'geom', 'test_id', 'descr',
        '#FFFF11', 1, '#000011', 11, '#FF0011', 'POLYGONAL', 'EPSG:32632');

insert into vdl_sources (tenant_id, code,
                         datasource, sql_select,
                         filter_geometry_column, geometry_column, identifier_column, label_column,
                         fill_color, border_thick, border_color, font_size, font_color, geometry_type, srs)
values (:test_tenant, 'TEST_2',
        upper('main'), 'select id as test_id, geom, descr from geom_table_two where {spatial_where_clause}',
        'geom', 'geom', 'test_id', 'descr',
        '#FFFF22', 2, '#000022', 12, '#FF0022', 'POLYGONAL', 'EPSG:32632');

insert into vdl_source_query_params (tenant_id, source_code, query_param_name, type, description)
values (:test_tenant, 'TEST_2', 'p1', 'Long', 'd1');
insert into vdl_source_query_params (tenant_id, source_code, query_param_name, type, description)
values (:test_tenant, 'TEST_2', 'p2', 'String', 'd2');

insert into vdl_sources (tenant_id, code,
                         datasource, sql_select,
                         filter_geometry_column, geometry_column, identifier_column, label_column,
                         fill_color, border_thick, border_color, font_size, font_color, geometry_type, srs)
values (:test_tenant, 'TEST_3',
        upper('ds3'), 'select id as test_id, geom from geom_table_three where {spatial_where_clause}',
        'geom', 'geom', 'test_id', null,
        null, 3, null, null, null, 'LINEAL', 'EPSG:32632');

insert into vdl_sources (tenant_id, code,
                         datasource, sql_select,
                         filter_geometry_column, geometry_column, identifier_column, label_column,
                         fill_color, border_thick, border_color, font_size, font_color, geometry_type, srs)
values ('*', 'TEST_4',
        upper('ds1'), 'select id as test_id, geom, descr from geom_table_two where {spatial_where_clause}',
        'geom', 'geom', 'test_id', 'descr',
        null, 4, '#000044', 14, '#FF0044', 'PUNTAL', 'EPSG:32632');

insert into vdl_sources (tenant_id, code,
                         datasource, sql_select,
                         filter_geometry_column, geometry_column, identifier_column, label_column,
                         fill_color, border_thick, border_color, font_size, font_color, geometry_type, srs)
values (:test_tenant, 'TEST_5',
        upper('main'), 'select id as test_id, geom from geom_table_two where {spatial_where_clause}',
        'geom', 'geom', 'test_id', null,
        null, 5, '#000055', null, null, 'PUNTAL', 'EPSG:32632');
