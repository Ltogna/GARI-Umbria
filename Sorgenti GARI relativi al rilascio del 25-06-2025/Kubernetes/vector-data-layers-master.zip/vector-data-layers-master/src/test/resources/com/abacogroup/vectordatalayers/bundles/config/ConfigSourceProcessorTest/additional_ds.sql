INSERT INTO vdl_data_sources(code)
values (upper('not_in_use'));

INSERT INTO vdl_data_sources(code)
values (upper('ds1'));
