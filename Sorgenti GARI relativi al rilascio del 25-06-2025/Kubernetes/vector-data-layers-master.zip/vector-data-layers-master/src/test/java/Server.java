import com.abacogroup.vectordatalayers.VectorDataLayersApp;

public class Server {
	public static void main(String[] args) throws Exception {
		VectorDataLayersApp.main(new String[] {
				"server", "config-iacs-dev.yml"
		});
	}
}
