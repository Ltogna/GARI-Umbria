import com.abacogroup.vectordatalayers.VectorDataLayersApp;

public class DbMigrate {
	public static void main(String[] args) throws Exception {
		VectorDataLayersApp.main(new String[] {
				"db", "migrate", "config.yml"
		});
	}
}
