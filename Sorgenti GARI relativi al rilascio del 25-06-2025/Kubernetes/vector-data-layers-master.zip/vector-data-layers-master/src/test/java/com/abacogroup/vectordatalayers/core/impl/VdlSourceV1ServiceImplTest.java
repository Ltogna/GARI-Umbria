package com.abacogroup.vectordatalayers.core.impl;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.vectordatalayers.api.QueryParamType;
import static com.abacogroup.vectordatalayers.api.VdlGeometryType.POLYGONAL;
import com.abacogroup.vectordatalayers.api.pub.VdlQueryParamV1;
import com.abacogroup.vectordatalayers.api.pub.VdlSourceDataV1;
import com.abacogroup.vectordatalayers.api.pub.VdlSourceV1;
import com.abacogroup.vectordatalayers.common.JdbiTest;
import com.abacogroup.vectordatalayers.common.ReqContextUtils;
import com.abacogroup.vectordatalayers.core.exceptions.VdlSourceException;
import com.abacogroup.vectordatalayers.core.exceptions.VdlSourceException.ErrEnum;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;

@ExtendWith(DropwizardExtensionsSupport.class)
class VdlSourceV1ServiceImplTest extends JdbiTest {

	private final ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	private final VdlSourceV1ServiceImpl vdlSourceService = getService(VdlSourceV1ServiceImpl.class);

	// ----- getTenantSources -----
	@Test
	void test_getTenantSources_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of("additional_ds", "vdl_source"), ctx.getTestScriptParams());

			// tested
			List<VdlSourceV1> tenantSources = vdlSourceService.getTenantSources(ctx.getReqContext(), null);

			assertThat(tenantSources).hasSize(4)
					.extracting(VdlSourceV1::getCode)
					.containsExactlyInAnyOrder("TEST_1", "TEST_2", "TEST_3", "TEST_5");

			handle.rollback();
		});
	}

	// ----- getSourceData -----
	@Test
	void test_getSourceData_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of("additional_ds", "vdl_source"), ctx.getTestScriptParams());

			// tested
			VdlSourceDataV1 sourceData = vdlSourceService.getSourceData(ctx.getReqContext(), "TEST_2");

			assertThat(sourceData).isNotNull()
					.isEqualTo(VdlSourceV1.builder()
							.code("TEST_2")
							.datasource("MAIN")
							.sqlSelect("select id as test_id, geom, descr from geom_table_two where {spatial_where_clause}")
							.filterGeometryColumn("geom")
							.geometryColumn("geom")
							.identifierColumn("test_id")
							.labelColumn("descr")
							.fillColor("#FFFF22")
							.borderThick(2)
							.borderColor("#000022")
							.fontSize(12)
							.fontColor("#FF0022")
							.geometryType(POLYGONAL)
							.srs("EPSG:32632")
							.customQueryParams(List.of(
									new VdlQueryParamV1("p1", QueryParamType.Long, "d1"),
									new VdlQueryParamV1("p2", QueryParamType.String, "d2")
							))
							.description("TEST_2")
							.build());

			handle.rollback();
		});
	}

	@Test
	void test_getSourceData_notFound() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of("additional_ds", "vdl_source"), ctx.getTestScriptParams());

			// tested
			VdlSourceException vdlException = assertThrows(VdlSourceException.class, () -> vdlSourceService.getSourceData(ctx.getReqContext(), "TEST_000"));

			assertThat(vdlException).isNotNull()
					.extracting(VdlSourceException::getCode)
					.isEqualTo(ErrEnum.SOURCE_NOT_FOUND.toString());

			handle.rollback();
		});
	}
}
