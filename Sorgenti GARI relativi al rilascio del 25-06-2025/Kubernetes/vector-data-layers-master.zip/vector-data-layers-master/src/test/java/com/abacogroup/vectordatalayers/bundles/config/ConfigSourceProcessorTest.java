package com.abacogroup.vectordatalayers.bundles.config;

import static com.abacogroup.vectordatalayers.api.VdlGeometryType.POLYGONAL;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import com.abacogroup.bundles.initializer.impl.exceptions.BundleException;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.vectordatalayers.api.QueryParamType;
import com.abacogroup.vectordatalayers.api.VdlFillStyle;
import com.abacogroup.vectordatalayers.bundles.config.i18n.I18nHelper;
import com.abacogroup.vectordatalayers.common.JdbiTest;
import com.abacogroup.vectordatalayers.common.ReqContextUtils;
import com.abacogroup.vectordatalayers.core.JdbiHelper;
import com.abacogroup.vectordatalayers.db.dao.DAOContainer;
import com.abacogroup.vectordatalayers.db.dao.I18nDAO;
import com.abacogroup.vectordatalayers.db.dao.VdlDataSourceDAO;
import com.abacogroup.vectordatalayers.db.dao.VdlSourceDAO;
import com.abacogroup.vectordatalayers.db.dao.VdlSourceModuleDAO;
import com.abacogroup.vectordatalayers.db.ntt.VdlQueryParamEntity;
import com.abacogroup.vectordatalayers.db.ntt.VdlSourceEntity;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import jakarta.validation.ConstraintViolationException;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class ConfigSourceProcessorTest extends JdbiTest {

	private ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	private VdlSourceDAO vectorDataLayersDAO = spy(getDAO(VdlSourceDAO.class));
	private VdlDataSourceDAO VdlDataSourceDAO = spy(getDAO(VdlDataSourceDAO.class));
	private VdlSourceModuleDAO vdlSourceModuleDAO = spy(getDAO(VdlSourceModuleDAO.class));
	private I18nDAO i18nDAO = getDAO(I18nDAO.class);
	private I18nHelper i18nHelper = new I18nHelper(i18nDAO);
	private JdbiHelper jdbiHelper = getService(JdbiHelper.class);
	
	private DAOContainer daoContainer = DAOContainer.builder()
			.vdlSourceDAO(vectorDataLayersDAO)
			.vdlDataSourceDAO(VdlDataSourceDAO)
			.vdlSourceModuleDAO(vdlSourceModuleDAO)
			.i18nDAO(i18nDAO)
			.build();

	private ConfigSourceProcessor configSourceProcessor = new ConfigSourceProcessor(daoContainer, i18nHelper, jdbiHelper, getMapper());

	@Test
	void testOnMessageWithNullInput() {
		assertDoesNotThrow(() -> configSourceProcessor.onMessage(null));
	}

	@Test
	void testOnMessageWithEmptyInputDoesntUseDAO() {
		// devo verificare che non sia chiamato il dao per nessun motivo usando questo config message
		ConfigDataMessage configDataMessage = new ConfigDataMessage();
		configSourceProcessor.onMessage(configDataMessage);

		verifyNoInteractions(vectorDataLayersDAO);
	}
	@Test
	void testOnMessageNotExistingFile() {
		ConfigDataMessage configDataMessage = new ConfigDataMessage();
		List<Path> lst = List.of(Path.of("TestFile.json"));
		configDataMessage.setConfigFiles(lst);
		assertThrows(BundleException.class, () -> configSourceProcessor.onMessage(configDataMessage));
	}

	// ----- onMessage -----
	@Test
	void test_onMessage_ok() throws IOException {
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of("vdl_source", "additional_ds"), ctx.getTestScriptParams());

			assertThat(vectorDataLayersDAO.findSourcesByTenantList(ctx.getTenantId(), ctx.getLang()))
					.hasSize(4)
					.extracting(VdlSourceEntity::getCode)
					.containsExactlyInAnyOrder("TEST_1", "TEST_2", "TEST_3", "TEST_5");
			assertThat(VdlDataSourceDAO.checkIfPresent("not_prensent_in_vdl_data_sources")).isFalse();

			ConfigDataMessage message = new ConfigDataMessage()
					.setTenantId(ctx.getTenantId())
					.setConfigFiles(List.of(
							file2Path.apply("vdl_insert_test_2.json"),
							file2Path.apply("vdl_new_test_99.json"),
							file2Path.apply("vdl_new_test_98.json"),
							file2Path.apply("vdl_delete_test_2.delete.json"),
							file2Path.apply("vdl_update_test_3.json"),
							file2Path.apply("vdl_new_test_97.json"),
							file2Path.apply("vdl_new_test_96.json"),
							file2Path.apply("vdl_delete_test_1.delete.json")
					));

			// tested
			configSourceProcessor.onMessage(message);

			verify(vectorDataLayersDAO).deleteSource(eq(ctx.getTenantId()), eq("TEST_1"));
			verify(vectorDataLayersDAO, times(2)).deleteSource(eq(ctx.getTenantId()), eq("TEST_2"));
			verify(vectorDataLayersDAO).deleteSource(eq(ctx.getTenantId()), eq("TEST_3"));
			verify(vectorDataLayersDAO, never()).deleteSource(eq(ctx.getTenantId()), eq("TEST_5"));

			assertThat(vectorDataLayersDAO.findSourcesByTenantList(ctx.getTenantId(), ctx.getLang()))
					.hasSize(7)
					.extracting(VdlSourceEntity::getCode)
					.containsExactlyInAnyOrder("TEST_96", "TEST_97", "TEST_98", "TEST_99", "TEST_2", "TEST_3", "TEST_5");

			assertThat(vectorDataLayersDAO.findSourceByTenantAndCode(ctx.getTenantId(), ctx.getLang(), "TEST_99"))
					.isNotNull()
					.isEqualTo(VdlSourceEntity.builder()
							.code("TEST_99")
							.tenantId(ctx.getTenantId())
							.sqlSelect("SELECT gid, geometry, name FROM geometry_table_test where {spatial_where_clause}")
							.datasource("DS1")
							.filterGeometryColumn("geometry")
							.geometryColumn("geometry")
							.identifierColumn("gid")
							.labelColumn("name")
							.fillColor("#999999")
							.fillStyle(VdlFillStyle.SQUARES)
							.borderColor("#009900")
							.fontColor("#FF99FF")
							.borderThick(1)
							.fontSize(9)
							.geometryType(POLYGONAL)
							.srs("EPSG:32632")
							.description("Test ninety-nine")
							.build());

			assertThat(vectorDataLayersDAO.findSourceByTenantAndCode(ctx.getTenantId(), ctx.getLang(), "TEST_2"))
					.isNotNull()
					.isEqualTo(VdlSourceEntity.builder()
							.tenantId(ctx.getTenantId())
							.code("TEST_2")
							.sqlSelect("SELECT gid, geometry, name FROM geometry_table_two where {spatial_where_clause}")
							.datasource(null)
							.filterGeometryColumn("geometry")
							.geometryColumn("geometry")
							.identifierColumn("gid")
							.labelColumn("name")
							.fillColor("#222222")
							.borderColor("#002200")
							.fontColor("#FF22FF")
							.borderThick(2)
							.fontSize(22)
							.geometryType(POLYGONAL)
							.srs("EPSG:32632")
							.description("TEST_2")
							.build());

			assertThat(vectorDataLayersDAO.findQueryParamsByTenantAndSourceCode(ctx.getTenantId(), "TEST_1")).hasSize(0);
			assertThat(vectorDataLayersDAO.findQueryParamsByTenantAndSourceCode(ctx.getTenantId(), "TEST_3")).hasSize(0);
			assertThat(vectorDataLayersDAO.findQueryParamsByTenantAndSourceCode(ctx.getTenantId(), "TEST_97")).hasSize(3)
					.extracting(VdlQueryParamEntity::getQueryParamName, VdlQueryParamEntity::getType)
					.containsExactlyInAnyOrder(
							tuple("foo", QueryParamType.String),
							tuple("bar", QueryParamType.Double),
							tuple("zzz", QueryParamType.Long)
					);

			assertThat(i18nDAO.searchLabel(ctx.getTenantId(), "vdl_sources", "code", "TEST_1", "it"))
					.isNull();

			assertThat(i18nDAO.searchLabel(ctx.getTenantId(), "vdl_sources", "code", "TEST_3", "en"))
					.isNotNull().isEqualTo("Three Test");
			assertThat(i18nDAO.searchLabel(ctx.getTenantId(), "vdl_sources", "code", "TEST_3", "it"))
					.isNotNull().isEqualTo("Tre Test");

			assertThat(i18nDAO.searchLabel(ctx.getTenantId(), "vdl_sources", "code", "TEST_99", "en"))
					.isNotNull().isEqualTo("Test ninety-nine");
			assertThat(i18nDAO.searchLabel(ctx.getTenantId(), "vdl_sources", "code", "TEST_99", "it"))
					.isNotNull().isEqualTo("Test novantanove");
			assertThat(i18nDAO.searchLabel(ctx.getTenantId(), "vdl_sources", "code", "TEST_98", "it"))
					.isNotNull().isEqualTo("Test novantotto");

			assertThat(VdlDataSourceDAO.checkIfPresent("not_prensent_in_vdl_data_sources")).isTrue();

			handle.rollback();
		});
	}

	@Test
	void test_onMessage_notValidK0() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			BundleException bundleException1 = assertThrows(BundleException.class, () -> configSourceProcessor.onMessage(new ConfigDataMessage()
					.setTenantId(ctx.getTenantId())
					.setConfigFiles(List.of(
							file2Path.apply("vdl_invalid1.json")
					))));

			assertThat(bundleException1)
					//.satisfies(Throwable::printStackTrace)
					.hasCauseInstanceOf(ConstraintViolationException.class);

			//---

			BundleException bundleException2 = assertThrows(BundleException.class, () -> configSourceProcessor.onMessage(new ConfigDataMessage()
					.setTenantId(ctx.getTenantId())
					.setConfigFiles(List.of(
							file2Path.apply("vdl_invalid2.json")
					))));

			assertThat(bundleException2)
					//.satisfies(Throwable::printStackTrace)
					.hasCauseInstanceOf(ConstraintViolationException.class);

			//---

			BundleException bundleException3 = assertThrows(BundleException.class, () -> configSourceProcessor.onMessage(new ConfigDataMessage()
					.setTenantId(ctx.getTenantId())
					.setConfigFiles(List.of(
							file2Path.apply("vdl_invalid3.json")
					))));

			assertThat(bundleException3)
					//.satisfies(Throwable::printStackTrace)
					.hasCauseInstanceOf(InvalidFormatException.class);

			//---

			BundleException bundleException4 = assertThrows(BundleException.class, () -> configSourceProcessor.onMessage(new ConfigDataMessage()
					.setTenantId(ctx.getTenantId())
					.setConfigFiles(List.of(
							file2Path.apply("vdl_invalid4.json")
					))));

			assertThat(bundleException4)
					//.satisfies(Throwable::printStackTrace)
					.hasCauseInstanceOf(ConstraintViolationException.class);

		/* // --- now supports not existing dataources

		BundleException bundleException5 = assertThrows(BundleException.class, () -> configSourceProcessor.onMessage(new ConfigDataMessage()
				.setTenantId(ctx.getTenantId())
				.setConfigFiles(List.of(
						file2Path.apply("vdl_invalid5.json")
				))));

		assertThat(bundleException5)
				//.satisfies(Throwable::printStackTrace)
				.hasCauseInstanceOf(IllegalArgumentException.class);
		// --- */

			BundleException bundleException6 = assertThrows(BundleException.class, () -> configSourceProcessor.onMessage(new ConfigDataMessage()
					.setTenantId(ctx.getTenantId())
					.setConfigFiles(List.of(
							file2Path.apply("vdl_invalid6.json")
					))));

			assertThat(bundleException6)
					//.satisfies(Throwable::printStackTrace)
					.hasCauseInstanceOf(IllegalArgumentException.class);
			//---


			verifyNoInteractions(vectorDataLayersDAO);
			handle.rollback();
		});
	}


}
