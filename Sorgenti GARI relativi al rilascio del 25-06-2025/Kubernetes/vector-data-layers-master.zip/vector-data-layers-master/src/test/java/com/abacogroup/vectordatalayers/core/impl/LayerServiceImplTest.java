package com.abacogroup.vectordatalayers.core.impl;

import static com.abacogroup.vectordatalayers.api.VdlGeometryType.LINEAL;
import static com.abacogroup.vectordatalayers.api.VdlGeometryType.POLYGONAL;
import static com.abacogroup.vectordatalayers.api.VdlGeometryType.PUNTAL;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.assertj.core.api.InstanceOfAssertFactories;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Polygonal;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;

import com.abacogroup.geometryeditor.GeometryTransform;
import com.abacogroup.geometryeditor.op.Utils;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.vectordatalayers.api.Layer;
import com.abacogroup.vectordatalayers.api.LayerGeometry;
import com.abacogroup.vectordatalayers.common.JdbiTest;
import com.abacogroup.vectordatalayers.common.ReqContextUtils;
import com.abacogroup.vectordatalayers.common.resources.ReqContext;
import com.abacogroup.vectordatalayers.core.JdbiHelper;
import com.abacogroup.vectordatalayers.core.LayerService;
import com.abacogroup.vectordatalayers.core.exceptions.VdlSourceException;
import com.abacogroup.vectordatalayers.core.exceptions.VdlSourceException.ErrEnum;
import com.abacogroup.wms4j.layers.LayerRequest;
import com.abacogroup.wms4j.renderer.DrawFeature;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.UriInfo;

@ExtendWith(DropwizardExtensionsSupport.class)
class LayerServiceImplTest extends JdbiTest {

	private final ReqContextUtils ctx = new ReqContextUtils(this.getClass());
	private final WKTReader reader = new WKTReader();

	private final LayerService layerService = getService(LayerServiceImpl.class);
	
	private final Integer DEFAULT_PAGE_SIZE = 10;

	// ----- getLayers -----
	@Test
	void test_getLayers_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of("additional_ds", "vdl_source"), ctx.getTestScriptParams());

			ReqContext reqContext = ctx.getReqContext();
			reqContext.setLang("it");

			// tested
			InfiniteListResults<Layer> layers = layerService.getLayers(reqContext, null, DEFAULT_PAGE_SIZE);

			assertThat(layers).isNotNull()
					.extracting(InfiniteListResults::getRecords)
					.asInstanceOf(InstanceOfAssertFactories.LIST).hasSize(5)
					.containsExactly(
							new Layer("TEST_1", "Test Uno", POLYGONAL),
							new Layer("TEST_2", "Test Due", POLYGONAL),
							new Layer("TEST_3", "Test Tre", LINEAL),
							new Layer("TEST_5", "Test Cinque", PUNTAL),
							new Layer("TEST_6", "TEST_6", POLYGONAL)
					);

			handle.rollback();
		});
	}

	// ----- getLayerGeometries -----
	@Test
	void test_getLayerGeometries_polygonsWithLabelOk() throws Exception {
		getJdbi().useHandle(handle -> {
			handle.begin();

			Map<String, Object> testScriptParams = withGeoms();
			execSqlFiles(this.getClass(), List.of("additional_ds", "vdl_source", "layers"), testScriptParams);

			ReqContext reqContext = ctx.getReqContext();
			reqContext.setLang("it");

			// tested
			InfiniteListResults<LayerGeometry> layerGeometries = layerService.getLayerGeometries(reqContext, "TEST_1",
					reader.read("POLYGON ((250 250, 350 250, 350 150, 250 150, 250 250))"), false, new MultivaluedHashMap<>(), null, DEFAULT_PAGE_SIZE);

			assertThat(layerGeometries).isNotNull()
			.extracting(InfiniteListResults::getRecords)
			.asInstanceOf(InstanceOfAssertFactories.LIST).hasSize(4)
			.containsExactly(
					LayerGeometry.builder()
					.id("1002")
					.geometry((Geometry) testScriptParams.get("p02"))
					.label("1_b")
					.srs(null)
					.areaSqm(10000.0)
					.fields(Map.of("style_ref_code", "null", "group", "1"))
					.build(),
					LayerGeometry.builder()
					.id("1004")
					.geometry((Geometry) testScriptParams.get("p04"))
					.label("1_d")
					.srs(null)
					.areaSqm(10000.0)
					.fields(Map.of("style_ref_code", "null", "group", "1"))
					.build(),
					LayerGeometry.builder()
					.id("1005")
					.geometry((Geometry) testScriptParams.get("p05"))
					.label("1_e")
					.srs(null)
					.areaSqm(10000.0)
					.fields(Map.of("style_ref_code", "null", "group", "1"))
					.build(),
					LayerGeometry.builder()
					.id("1006")
					.geometry((Geometry) testScriptParams.get("p06"))
					.label("1_f")
					.srs(null)
					.areaSqm(10000.0)
					.fields(Map.of("style_ref_code", "null", "group", "1"))
					.build()
					);

			handle.rollback();
		});
	}

	@Test
	void test_getLayerGeometries_additionalFiltersOk() throws Exception {
		getJdbi().useHandle(handle -> {
			handle.begin();

			Map<String, Object> testScriptParams = withGeoms();
			execSqlFiles(this.getClass(), List.of("additional_ds", "vdl_source", "layers"), testScriptParams);

			ReqContext reqContext = ctx.getReqContext();
			reqContext.setLang("it");

			// tested
			MultivaluedHashMap<String, String> queryParameters = new MultivaluedHashMap<>();
			queryParameters.putSingle("notName", "b");
			queryParameters.putSingle("maxId", "1005");
			InfiniteListResults<LayerGeometry> layerGeometries = layerService.getLayerGeometries(reqContext, "TEST_1",
					reader.read("POLYGON ((250 250, 350 250, 350 150, 250 150, 250 250))"), false, queryParameters, null, DEFAULT_PAGE_SIZE);
			
			assertThat(layerGeometries).isNotNull()
					.extracting(InfiniteListResults::getRecords)
					.asInstanceOf(InstanceOfAssertFactories.LIST).hasSize(2)
					.containsExactly(
//							LayerGeometry.builder()
//							.id("1002")
//							.geometry((Geometry) testScriptParams.get("p02"))
//							.label("1_b")
//							.srs(null)
//							.areaSqm(10000.0)
//							.fields(Map.of("style_ref_code", "null", "group", "1"))
//							.build(),
							LayerGeometry.builder()
							.id("1004")
							.geometry((Geometry) testScriptParams.get("p04"))
							.label("1_d")
							.srs(null)
							.areaSqm(10000.0)
							.fields(Map.of("style_ref_code", "null", "group", "1"))
							.build(),
							LayerGeometry.builder()
							.id("1005")
							.geometry((Geometry) testScriptParams.get("p05"))
							.label("1_e")
							.srs(null)
							.areaSqm(10000.0)
							.fields(Map.of("style_ref_code", "null", "group", "1"))
							.build()
//							LayerGeometry.builder()
//							.id("1006")
//							.geometry((Geometry) testScriptParams.get("p06"))
//							.label("1_f")
//							.srs(null)
//							.areaSqm(10000.0)
//							.fields(Map.of("style_ref_code", "null", "group", "1"))
//							.build()
							
					);

			handle.rollback();
		});
	}

	@Test
	void test_getLayerGeometries_fromSecondaryDsOk() throws Exception {
		getJdbi().useHandle(handle -> {
			handle.begin();

			Map<String, Object> testScriptParams = withGeoms();
			execSqlFiles(this.getClass(), List.of("additional_ds", "vdl_source", "layers"), testScriptParams);

			Jdbi secondary = getService(JdbiHelper.class).getJdbi("secondary");
			secondary.useHandle(secondaryHandle -> {
				secondaryHandle.begin();

				execSqlFiles(this.getClass(), List.of("layers_secondary"), testScriptParams, secondary);

				ReqContext reqContext = ctx.getReqContext();
				reqContext.setLang("it");

				// tested
				InfiniteListResults<LayerGeometry> layerGeometries = layerService.getLayerGeometries(reqContext, "TEST_2",
						reader.read("POLYGON ((250 250, 350 250, 350 150, 250 150, 250 250))"), false, new MultivaluedHashMap<>(), null, DEFAULT_PAGE_SIZE);

				assertThat(layerGeometries).isNotNull()
						.extracting(InfiniteListResults::getRecords)
						.asInstanceOf(InstanceOfAssertFactories.LIST).hasSize(4)
						.containsExactly(
								LayerGeometry.builder()
								.id("2002")
								.geometry((Geometry) testScriptParams.get("p02"))
								.label("b")
								.srs(null)
								.areaSqm(10000.0)
								.fields(Map.of("style_ref_code", "null", "group", "2"))
								.build(),
								LayerGeometry.builder()
								.id("2004")
								.geometry((Geometry) testScriptParams.get("p04"))
								.label("d")
								.srs(null)
								.areaSqm(10000.0)
								.fields(Map.of("style_ref_code", "null", "group", "2"))
								.build(),
								LayerGeometry.builder()
								.id("2005")
								.geometry((Geometry) testScriptParams.get("p05"))
								.label("e")
								.srs(null)
								.areaSqm(10000.0)
								.fields(Map.of("style_ref_code", "null", "group", "2"))
								.build(),
								LayerGeometry.builder()
								.id("2006")
								.geometry((Geometry) testScriptParams.get("p06"))
								.label("f")
								.srs(null)
								.areaSqm(10000.0)
								.fields(Map.of("style_ref_code", "null", "group", "2"))
								.build()
						);

				secondaryHandle.rollback();
			});

			handle.rollback();
		});
	}

	@Test
	void test_getLayerGeometries_LineStringsWithoutLabelOk() throws Exception {
		getJdbi().useHandle(handle -> {
			handle.begin();

			Map<String, Object> testScriptParams = withGeoms();
			execSqlFiles(this.getClass(), List.of("additional_ds", "vdl_source", "layers"), testScriptParams);

			ReqContext reqContext = ctx.getReqContext();
			reqContext.setLang("it");

			// tested
			InfiniteListResults<LayerGeometry> layerGeometries = layerService.getLayerGeometries(reqContext, "TEST_3",
					reader.read("POLYGON ((250 250, 350 250, 350 150, 250 150, 250 250))"), false, new MultivaluedHashMap<>(), null, DEFAULT_PAGE_SIZE);

			assertThat(layerGeometries).isNotNull()
					.extracting(InfiniteListResults::getRecords)
					.asInstanceOf(InstanceOfAssertFactories.LIST).hasSize(4)
					.containsExactly(
							LayerGeometry.builder()
							.id("3002")
							.geometry((Geometry) testScriptParams.get("l02"))
							.label(null)
							.srs(null)
							.areaSqm(0.0)
							.fields(Map.of("style_ref_code", "null", "group", "3"))
							.build(),
							LayerGeometry.builder()
							.id("3004")
							.geometry((Geometry) testScriptParams.get("l04"))
							.label(null)
							.srs(null)
							.areaSqm(0.0)
							.fields(Map.of("style_ref_code", "null", "group", "3"))
							.build(),
							LayerGeometry.builder()
							.id("3005")
							.geometry((Geometry) testScriptParams.get("l05"))
							.label(null)
							.srs(null)
							.areaSqm(0.0)
							.fields(Map.of("style_ref_code", "null", "group", "3"))
							.build(),
							LayerGeometry.builder()
							.id("3006")
							.geometry((Geometry) testScriptParams.get("l06"))
							.label(null)
							.srs(null)
							.areaSqm(0.0)
							.fields(Map.of("style_ref_code", "null", "group", "3"))
							.build()
					);

			handle.rollback();
		});
	}

	@Test
	void test_getLayerGeometries_notTouchingGeomEmptyRes() throws Exception {
		getJdbi().useHandle(handle -> {
			handle.begin();

			Map<String, Object> testScriptParams = withGeoms();
			execSqlFiles(this.getClass(), List.of("additional_ds", "vdl_source", "layers"), testScriptParams);

			ReqContext reqContext = ctx.getReqContext();
			reqContext.setLang("it");

			// tested
			InfiniteListResults<LayerGeometry> layerGeometries = layerService.getLayerGeometries(reqContext, "TEST_1",
					reader.read("POLYGON ((1250 1250, 1350 1250, 1350 1150, 1250 1150, 1250 1250))"), false, new MultivaluedHashMap<>(), null, DEFAULT_PAGE_SIZE);

			assertThat(layerGeometries).isNotNull()
					.extracting(InfiniteListResults::getRecords)
					.asInstanceOf(InstanceOfAssertFactories.LIST).isEmpty();

			handle.rollback();
		});
	}

	@Test
	void test_getLayerGeometries_sourceNotExisting404() throws Exception {
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of("additional_ds", "vdl_source"), ctx.getTestScriptParams());

			ReqContext reqContext = ctx.getReqContext();
			reqContext.setLang("it");

			// tested
			VdlSourceException vdlSourceException = assertThrows(VdlSourceException.class,
					() -> layerService.getLayerGeometries(reqContext, "TEST_000",
							reader.read("POLYGON ((250 250, 350 250, 350 150, 250 150, 250 250))"), false, new MultivaluedHashMap<>(), null, DEFAULT_PAGE_SIZE));

			assertThat(vdlSourceException).isNotNull()
					.extracting(VdlSourceException::getCode)
					.isEqualTo(ErrEnum.SOURCE_NOT_FOUND.toString());

			handle.rollback();
		});
	}

	@Test
	void test_getLayerGeometries_additionalFiltersTypeMismatchKoBadRequest() throws Exception {
		getJdbi().useHandle(handle -> {
			handle.begin();

			Map<String, Object> testScriptParams = withGeoms();
			execSqlFiles(this.getClass(), List.of("additional_ds", "vdl_source", "layers"), testScriptParams);

			ReqContext reqContext = ctx.getReqContext();
			reqContext.setLang("it");

			// tested
			MultivaluedHashMap<String, String> queryParameters = new MultivaluedHashMap<>();
			queryParameters.putSingle("notName", "b");
			queryParameters.putSingle("maxId", "lol");
			VdlSourceException vdlSourceException = assertThrows(VdlSourceException.class,
					() -> layerService.getLayerGeometries(reqContext, "TEST_1",
							reader.read("POLYGON ((250 250, 350 250, 350 150, 250 150, 250 250))"), false, queryParameters, null, DEFAULT_PAGE_SIZE));

			assertThat(vdlSourceException).isNotNull()
					.extracting(VdlSourceException::getCode)
					.isEqualTo(ErrEnum.UNREADABLE_QUERY_PARAMETER.toString());

			handle.rollback();
		});
	}

	// ----- provide -----
	@Test
	void test_provide_ok() throws ParseException {
		getJdbi().useHandle(handle -> {
			handle.begin();

			Map<String, Object> testScriptParams = withGeoms();
			execSqlFiles(this.getClass(), List.of("additional_ds", "vdl_source", "layers"), testScriptParams);

			ReqContext reqContext = ctx.getReqContext();
			reqContext.setLang("it");
			Geometry geometry = reader.read("POLYGON ((250 250, 350 250, 350 150, 250 150, 250 250))");
			UriInfo uriInfo = mock(UriInfo.class);
			LayerRequest layerRequest = new LayerRequest(ctx.getTenantId(), "TEST_1", uriInfo, geometry, 10.);

			MultivaluedHashMap<String, String> queryParams = new MultivaluedHashMap<>();
			queryParams.putSingle("SRS", "none");
			given(uriInfo.getQueryParameters()).willReturn(queryParams);

			// tested
			List<DrawFeature> drawFeatureList = new ArrayList<>();
			((LayerServiceImpl) layerService).provide(layerRequest, drawFeatureList::add);

			assertThat(drawFeatureList).isNotNull()
					.hasSize(4)
					.extracting(DrawFeature::getGeometry, DrawFeature::getText)
					.containsExactly(
							tuple(reader.read("POLYGON ((300 200, 300 150, 250 150, 250 200, 300 200))"), "1_b"),
							tuple(reader.read("POLYGON ((300 200, 250 200, 250 250, 300 250, 300 200))"), "1_d"),
							tuple(reader.read("POLYGON ((350 200, 350 150, 300 150, 300 200, 350 200))"), "1_e"),
							tuple(reader.read("POLYGON ((300 200, 300 250, 350 250, 350 200, 300 200))"), "1_f")
					);
			assertThat(drawFeatureList)
					.extracting(DrawFeature::getSpecificStyle)
					.allSatisfy(gds -> {
						assertThat(gds.getPaint()).isEqualTo(Color.RED);
						assertThat(gds.getPenColor()).isEqualTo(Color.BLUE);
						assertThat(gds.getTextColor()).isEqualTo(Color.GREEN);
						assertThat(gds.getPenThick()).isEqualTo(1);
						assertThat(gds.getFont()).isEqualTo(new Font("Arial", Font.PLAIN, 11));
					});

			handle.rollback();
		});
	}

	@Test
	void test_provide_reprojectWithSourceSrsFromReqOk() throws Exception {
		getJdbi().useHandle(handle -> {
			handle.begin();

			Map<String, Object> testScriptParams = withGeoms();
			execSqlFiles(this.getClass(), List.of("additional_ds", "vdl_source", "layers"), testScriptParams);

			ReqContext reqContext = ctx.getReqContext();
			reqContext.setLang("it");
			Geometry geometry = reader.read("POLYGON ((0.0022457882102988 0.0022457882097268, 0.0031441034944183 0.0022457882097268, 0.0031441034944183 0.0013474729260473, 0.0022457882102988 0.0013474729260473, 0.0022457882102988 0.0022457882097268))");
			UriInfo uriInfo = mock(UriInfo.class);
			LayerRequest layerRequest = new LayerRequest(ctx.getTenantId(), "TEST_6", uriInfo, geometry, 10.);

			String srcSrs = "EPSG:3857";
			String outSrs = "EPSG:4326";
			MultivaluedHashMap<String, String> queryParams = new MultivaluedHashMap<>();
			queryParams.putSingle("SRS", outSrs);
			queryParams.putSingle("sourceSrs", srcSrs);
			given(uriInfo.getQueryParameters()).willReturn(queryParams);

			// tested
			List<DrawFeature> drawFeatureList = new ArrayList<>();
			((LayerServiceImpl) layerService).provide(layerRequest, drawFeatureList::add);

			assertThat(drawFeatureList).isNotNull()
					.hasSize(4)
					.extracting(DrawFeature::getGeometry, DrawFeature::getText)
					.satisfies(tuples -> {
						Map<String, Geometry> map = tuples.stream()
								.map(t -> Map.entry((String)t.toList().get(1), (Geometry)t.toList().get(0)))
								.collect(Collectors.toMap(Entry::getKey, Entry::getValue));

						assertThat(map.keySet()).containsExactly("1_b", "1_d", "1_e", "1_f");

						GeometryTransform gt = new GeometryTransform();
						assertTrue(Utils.equalsSnapped(
								(Polygonal) gt.transform(map.get("1_b"), outSrs, srcSrs),
								(Polygonal) reader.read("POLYGON ((300 200, 300 150, 250 150, 250 200, 300 200))")));
						assertTrue(Utils.equalsSnapped(
								(Polygonal) gt.transform(map.get("1_d"), outSrs, srcSrs),
								(Polygonal) reader.read("POLYGON ((300 200, 250 200, 250 250, 300 250, 300 200))")));
						assertTrue(Utils.equalsSnapped(
								(Polygonal) gt.transform(map.get("1_e"), outSrs, srcSrs),
								(Polygonal) reader.read("POLYGON ((350 200, 350 150, 300 150, 300 200, 350 200))")));
						assertTrue(Utils.equalsSnapped(
								(Polygonal) gt.transform(map.get("1_f"), outSrs, srcSrs),
								(Polygonal) reader.read("POLYGON ((300 200, 300 250, 350 250, 350 200, 300 200))")));
					});
			assertThat(drawFeatureList)
					.extracting(DrawFeature::getSpecificStyle)
					.allSatisfy(gds -> {
						assertThat(gds.getPaint()).isEqualTo(Color.RED);
						assertThat(gds.getPenColor()).isEqualTo(Color.BLUE);
						assertThat(gds.getTextColor()).isEqualTo(Color.GREEN);
						assertThat(gds.getPenThick()).isEqualTo(1);
						assertThat(gds.getFont()).isEqualTo(new Font("Arial", Font.PLAIN, 11));
					});

			handle.rollback();
		});
	}

	@Test
	void test_provide_sameSrsNoReprojectionAndCustomFiltersOk() throws ParseException {
		getJdbi().useHandle(handle -> {
			handle.begin();

			Map<String, Object> testScriptParams = withGeoms();
			execSqlFiles(this.getClass(), List.of("additional_ds", "vdl_source", "layers"), testScriptParams);

			ReqContext reqContext = ctx.getReqContext();
			reqContext.setLang("it");
			Geometry geometry = reader.read("POLYGON ((250 250, 350 250, 350 150, 250 150, 250 250))");
			UriInfo uriInfo = mock(UriInfo.class);
			LayerRequest layerRequest = new LayerRequest(ctx.getTenantId(), "TEST_1", uriInfo, geometry, 10.);

			String outSrs = "EPSG:32632";
			MultivaluedHashMap<String, String> queryParams = new MultivaluedHashMap<>();
			queryParams.putSingle("SRS", outSrs);
			queryParams.putSingle("notName", "b");
			given(uriInfo.getQueryParameters()).willReturn(queryParams);

			// tested
			List<DrawFeature> drawFeatureList = new ArrayList<>();
			((LayerServiceImpl) layerService).provide(layerRequest, drawFeatureList::add);

			assertThat(drawFeatureList).isNotNull()
					.hasSize(3)
					.extracting(DrawFeature::getGeometry, DrawFeature::getText)
					.containsExactly(
							tuple(reader.read("POLYGON ((300 200, 250 200, 250 250, 300 250, 300 200))"), "1_d"),
							tuple(reader.read("POLYGON ((350 200, 350 150, 300 150, 300 200, 350 200))"), "1_e"),
							tuple(reader.read("POLYGON ((300 200, 300 250, 350 250, 350 200, 300 200))"), "1_f")
					);
			assertThat(drawFeatureList)
					.extracting(DrawFeature::getSpecificStyle)
					.allSatisfy(gds -> {
						assertThat(gds.getPaint()).isEqualTo(Color.RED);
						assertThat(gds.getPenColor()).isEqualTo(Color.BLUE);
						assertThat(gds.getTextColor()).isEqualTo(Color.GREEN);
						assertThat(gds.getPenThick()).isEqualTo(1);
						assertThat(gds.getFont()).isEqualTo(new Font("Arial", Font.PLAIN, 11));
					});

			handle.rollback();
		});
	}


	private Map<String, Object> withGeoms() throws ParseException {

		Map<String, Object> testScriptParams = new HashMap<>(ctx.getTestScriptParams());

		testScriptParams.put("p01", reader.read("POLYGON ((100 200, 200 200, 200 100, 100 100, 100 200))"));
		testScriptParams.put("p02", reader.read("POLYGON ((200 200, 300 200, 300 100, 200 100, 200 200))"));
		testScriptParams.put("p03", reader.read("POLYGON ((100 300, 200 300, 200 200, 100 200, 100 300))"));
		testScriptParams.put("p04", reader.read("POLYGON ((200 300, 300 300, 300 200, 200 200, 200 300))"));
		testScriptParams.put("p05", reader.read("POLYGON ((300 200, 400 200, 400 100, 300 100, 300 200))"));
		testScriptParams.put("p06", reader.read("POLYGON ((300 300, 400 300, 400 200, 300 200, 300 300))"));

		testScriptParams.put("l01", reader.read("LINESTRING (100 200, 200 200, 200 100, 100 100, 100 200)"));
		testScriptParams.put("l02", reader.read("LINESTRING (200 200, 300 200, 300 100, 200 100, 200 200)"));
		testScriptParams.put("l03", reader.read("LINESTRING (100 300, 200 300, 200 200, 100 200, 100 300)"));
		testScriptParams.put("l04", reader.read("LINESTRING (200 300, 300 300, 300 200, 200 200, 200 300)"));
		testScriptParams.put("l05", reader.read("LINESTRING (300 200, 400 200, 400 100, 300 100, 300 200)"));
		testScriptParams.put("l06", reader.read("LINESTRING (300 300, 400 300, 400 200, 300 200, 300 300)"));

		return testScriptParams;
	}
}
