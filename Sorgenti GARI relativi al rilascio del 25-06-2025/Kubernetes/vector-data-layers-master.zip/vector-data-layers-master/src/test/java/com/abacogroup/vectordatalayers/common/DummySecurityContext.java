package com.abacogroup.vectordatalayers.common;

import static com.abacogroup.vectordatalayers.common.WebCliHelper.createFakeToken;

import com.abacogroup.dropwizard.auth.sso2.User;
import jakarta.ws.rs.core.SecurityContext;
import java.security.Principal;

public class DummySecurityContext implements SecurityContext {

	private User user;

	public DummySecurityContext(String tenant, String userId) {
		String authToken = createFakeToken(tenant, userId);
		this.user = new User(userId, authToken, tenant, userId);
	}

	public DummySecurityContext(User user) {
		this.user = user;
	}

	@Override
	public Principal getUserPrincipal() {
		return user;
	}

	@Override
	public boolean isUserInRole(String role) {
		return false;
	}

	@Override
	public boolean isSecure() {
		return false;
	}

	@Override
	public String getAuthenticationScheme() {
		return null;
	}
}
