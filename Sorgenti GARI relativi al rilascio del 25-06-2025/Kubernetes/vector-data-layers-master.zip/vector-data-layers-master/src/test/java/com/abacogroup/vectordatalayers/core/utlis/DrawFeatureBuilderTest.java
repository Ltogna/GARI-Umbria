package com.abacogroup.vectordatalayers.core.utlis;

import static org.junit.Assert.assertTrue;

import com.abacogroup.vectordatalayers.api.VdlFillStyle;
import com.abacogroup.wms4j.renderer.DrawFeature;
import com.abacogroup.wms4j.renderer.WmsImage;
import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;

class DrawFeatureBuilderTest {

	private final WKTReader reader = new WKTReader();

	// ----- build -----
	@Test
	@Disabled("creates an image with all fill styles")
	void print() throws ParseException, IOException {

		List<DrawFeature> drawFeatures = List.of(
				new DrawFeatureBuilder().withPaint(toHex(Color.ORANGE)+"55", null).withBorder("#000000", 3).withFont("#000000", 10)
						.build(reader.read("POLYGON ((200 500, 200 400, 300 500, 200 500))"), "plain", true),
				new DrawFeatureBuilder().withPaint(toHex(Color.red), VdlFillStyle.SQUARES).withBorder("#FFFFFF", 3).withFont("#FFFFFF", 10)
						.build(reader.read("POLYGON ((300 500, 300 400, 200 400, 300 500))"), "SQUARES", true),
				new DrawFeatureBuilder().withPaint(toHex(Color.blue), VdlFillStyle.DIAGONAL_SQUARES_LARGE).withBorder("#000000", 3).withFont("#000000", 10)
						.build(reader.read("POLYGON ((200 400, 200 300, 300 300, 300 400, 200 400))"), "DIAGONAL_SQUARES_LARGE", true),
				new DrawFeatureBuilder().withPaint(toHex(Color.cyan.brighter())+"55", VdlFillStyle.DIAGONAL_UP).withBorder("#00FF00", 3).withFont("#000000", 10)
						.build(reader.read("POLYGON ((300 500, 400 400, 300 400, 300 500))"), "DIAGONAL_UP", true),
				new DrawFeatureBuilder().withPaint(toHex(Color.darkGray), VdlFillStyle.VERTICAL_LINES).withBorder("#0000FF", 1).withFont("#0000FF", 10)
						.build(reader.read("POLYGON ((300 500, 400 500, 400 400, 300 500))"), "VERTICAL_LINES", true),
				new DrawFeatureBuilder().withPaint(toHex(Color.yellow), VdlFillStyle.SQUARES_LARGE).withBorder("#FF0000", 5).withFont("#FF0000", 10)
						.build(reader.read("POLYGON ((400 500, 500 500, 500 400, 400 400, 400 500))"), "SQUARES_LARGE", true),
				new DrawFeatureBuilder().withPaint(toHex(Color.green), VdlFillStyle.HORIZONTAL_LINES).withBorder("#000000", 3).withFont("#000000", 10)
						.build(reader.read("POLYGON ((300 300, 400 300, 400 400, 300 300))"), "HORIZONTAL_LINES", true),
				new DrawFeatureBuilder().withBorder("#00FFFF", 7).withFont("#00FFFF", 10)
						.build(reader.read("POLYGON ((400 400, 300 400, 300 300, 400 400))"), "empty", true),
				new DrawFeatureBuilder().withPaint(toHex(Color.magenta), VdlFillStyle.DIAGONAL_SQUARES).withFont("#000000", 10)
						.build(reader.read("POLYGON ((400 400, 400 300, 500 300, 400 400))"), "DIAGONAL_SQUARES", true),
				new DrawFeatureBuilder().withPaint(toHex(Color.magenta), VdlFillStyle.DIAGONAL_DOWN).withBorder(null, 0)
						.build(reader.read("POLYGON ((500 300, 500 400, 400 400, 500 300))"), "DIAGONAL_DOWN", true)
		);

		WmsImage image = new WmsImage((520-180)*5, (520-280)*5, new Coordinate(180, 280), new Coordinate(520, 520));

		drawFeatures.forEach(image);

		File tempFile = new File("target", "test-"+System.currentTimeMillis()+".png");
		FileOutputStream fos = new FileOutputStream(tempFile);
		image.saveAsPng(fos);
		fos.close();

		assertTrue(true);
	}

	private String toHex(Color color) {
		return String.format("#%06X", (0xFFFFFF & color.getRGB()));
	}
}
