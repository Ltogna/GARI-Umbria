package com.abacogroup.vectordatalayers.resources.pub;

import static com.abacogroup.vectordatalayers.common.WebCliHelper.TENANT;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;
import org.mockito.Mockito;

import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.vectordatalayers.api.Layer;
import com.abacogroup.vectordatalayers.api.LayerGeometry;
import com.abacogroup.vectordatalayers.api.VdlGeometryType;
import com.abacogroup.vectordatalayers.api.req.LayerGeometriesSearchReq;
import com.abacogroup.vectordatalayers.common.WebCliHelper;
import com.abacogroup.vectordatalayers.common.resources.ReqContext;
import com.abacogroup.vectordatalayers.core.LayerService;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.UriBuilder;

@ExtendWith(DropwizardExtensionsSupport.class)
class LayerPublicResourcesTest {

	private final LayerService service = Mockito.mock(LayerService.class);

	private final LayerPublicResources resource = new LayerPublicResources(service);
	private final ResourceExtension EXT = WebCliHelper.createEXT(resource);

	private final WKTReader reader = new WKTReader();

	// ----- getLayers -----
	@Test
	void test_getLayers_ok() {
		String nextKey = "101";
		Integer pageSize = 10;

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass());//.path(resource.getClass(), "getLayers");
		Map<String, Object> queryMap = new HashMap<>();
		queryMap.put("nextKey", nextKey);
		queryMap.forEach(uriBuilder::queryParam);
		String uri = uriBuilder.build(TENANT).toString();
		System.out.println(uri);

		Layer mockRes = new Layer("TEST_1", "Test One", VdlGeometryType.POLYGONAL);

		given(service.getLayers(any(), any(), any()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(mockRes), "201"));

		InfiniteListResultsImpl<Layer> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header(HttpHeaders.AUTHORIZATION, WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.hasFieldOrPropertyWithValue("nextKey", "201")
				.extracting(InfiniteListResults::getRecords)
				.isEqualTo(List.of(mockRes));

		verify(service).getLayers(new ReqContext(TENANT, null, "en"), nextKey, pageSize);
	}

	// ----- getLayerGeometries -----
	@Test
	void test_getLayerGeometries_ok() throws ParseException {
		String nextKey = "101";
		Integer pageSize = 10;
		String layerCode = "TEST_1";

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "getLayerGeometries");
		Map<String, Object> queryMap = new HashMap<>();
		queryMap.put("nextKey", nextKey);
		queryMap.put("foo", "bar");
		queryMap.forEach(uriBuilder::queryParam);
		String uri = uriBuilder.build(TENANT, layerCode).toString();
		System.out.println(uri);

		Geometry touchingGeometry = reader.read("POLYGON ((250 250, 350 250, 350 150, 250 150, 250 250))");
		LayerGeometriesSearchReq searchReq = new LayerGeometriesSearchReq(touchingGeometry);

		Geometry geometry = reader.read("POLYGON ((200 200, 300 200, 300 100, 200 100, 200 200))");
		LayerGeometry mockRes = LayerGeometry.builder()
				.id("111")
				.geometry(geometry)
				.label("geom 1")
				.build();

		given(service.getLayerGeometries(any(), any(), any(), anyBoolean(), any(), any(), any()))
				.willReturn(new InfiniteListResultsImpl<>(List.of(mockRes), "201"));

		InfiniteListResultsImpl<LayerGeometry> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header(HttpHeaders.AUTHORIZATION, WebCliHelper.JWT_MOCK_CREDENTIALS)
//				.post(Entity.json(searchReq), new GenericType<>() {
				.post(Entity.entity("{\"touchingGeometry\": \"POLYGON ((250 250, 350 250, 350 150, 250 150, 250 250))\"}", MediaType.APPLICATION_JSON_TYPE), new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.hasFieldOrPropertyWithValue("nextKey", "201")
				.extracting(InfiniteListResults::getRecords)
				.isEqualTo(List.of(mockRes));

		MultivaluedHashMap<String, String> queryParameters = new MultivaluedHashMap<>();
		queryParameters.add("nextKey", nextKey);
		queryParameters.add("foo", "bar");
		verify(service).getLayerGeometries(new ReqContext(TENANT, null, "en"), layerCode, touchingGeometry, false, queryParameters, nextKey, pageSize);
	}
}
