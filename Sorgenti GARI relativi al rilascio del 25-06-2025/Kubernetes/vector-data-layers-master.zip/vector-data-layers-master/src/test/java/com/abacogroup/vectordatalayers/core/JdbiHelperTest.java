package com.abacogroup.vectordatalayers.core;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.atMostOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import com.abacogroup.vectordatalayers.common.JdbiTest;
import com.abacogroup.vectordatalayers.common.ReqContextUtils;
import com.abacogroup.vectordatalayers.db.dao.LayerDAO;
import com.abacogroup.vectordatalayers.db.dao.VdlDataSourceDAO;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.util.List;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(DropwizardExtensionsSupport.class)
class JdbiHelperTest extends JdbiTest {

	private final ReqContextUtils ctx = new ReqContextUtils(this.getClass());
	private JdbiHelper jdbiHelper;

	@BeforeEach
	void setUp() {
		jdbiHelper = new JdbiHelper(this.getJdbi().onDemand(VdlDataSourceDAO.class), this.getJdbi());
	}

	// ----- putIfAbsent -----
	@Test
	void test_putIfAbsent_ok() {
		Jdbi mockJdbi = mock(Jdbi.class);

		assertThat(jdbiHelper.containsDatasource("test")).isFalse();

		// test
		jdbiHelper.putIfAbsent("test", mockJdbi);

		assertThat(jdbiHelper.containsDatasource("test")).isTrue();
	}

	@Test
	void test_putIfAbsent_Ko() {
		Jdbi mockJdbi = mock(Jdbi.class);

		// test
		assertThrows(IllegalArgumentException.class, () -> jdbiHelper.putIfAbsent("main", mockJdbi));
		assertThrows(IllegalArgumentException.class, () -> jdbiHelper.putIfAbsent("database", mockJdbi));
	}

	// ----- getDao -----
	@Test
	void test_getDao_ok() {
		Jdbi mockJdbi = mock(Jdbi.class);
		LayerDAO layerDAO = mock(LayerDAO.class);

		given(mockJdbi.onDemand(any())).willReturn(layerDAO);

		jdbiHelper.putIfAbsent("test", mockJdbi);

		assertThat(jdbiHelper.getDao("test", LayerDAO.class))
				.isSameAs(layerDAO)
				.isSameAs(jdbiHelper.getDao("test", LayerDAO.class));

		verify(mockJdbi, atMostOnce()).onDemand(LayerDAO.class);
	}

	@Test
	void test_getDao_nullKeyOk() {
		assertThat(jdbiHelper.getDao(null, LayerDAO.class))
				.isNotNull()
				.isSameAs(jdbiHelper.getDao("main", LayerDAO.class));
	}

	@Test
	void test_getDao_missingDsKO() {
		Jdbi mockJdbi = mock(Jdbi.class);
		LayerDAO layerDAO = mock(LayerDAO.class);

		given(mockJdbi.onDemand(any())).willReturn(layerDAO);

		assertThrows(IllegalStateException.class, () -> jdbiHelper.getDao("test", LayerDAO.class));
	}

	// ----- datasourceCheck -----
	@Test
	void test_datasourceCheck_ok() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of("additional_ds", "vdl_source"), ctx.getTestScriptParams());

			Jdbi mockJdbi1 = mock(Jdbi.class);
			Jdbi mockJdbi2 = mock(Jdbi.class);

			jdbiHelper.putIfAbsent("DS1", mockJdbi1);
			jdbiHelper.putIfAbsent("DS2", mockJdbi2);

			// test
			jdbiHelper.datasourceCheck();

			handle.rollback();
		});
		
		assertTrue(true);
	}

	@Test
	@Disabled("cannot fail since this check is useless after v1.3.0")
	void test_datasourceCheck_KO() {
		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of("vdl_source"), ctx.getTestScriptParams());

			Jdbi mockJdbi2 = mock(Jdbi.class);

			jdbiHelper.putIfAbsent("ds2", mockJdbi2);

			// test
			assertThrows(IllegalStateException.class, () -> jdbiHelper.datasourceCheck());

			handle.rollback();
		});
	}
}
