package com.abacogroup.vectordatalayers.core;

import static com.abacogroup.vectordatalayers.core.DatasourceHelper.jdbiName;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;

import com.abacogroup.vectordatalayers.VectorDataLayersConfig;
import com.abacogroup.vectordatalayers.api.VdlGeometryType;
import com.abacogroup.vectordatalayers.common.JdbiTest;
import com.abacogroup.vectordatalayers.common.ReqContextUtils;
import com.abacogroup.vectordatalayers.core.impl.LayerServiceImpl;
import com.abacogroup.vectordatalayers.db.dao.LayerDAO;
import com.abacogroup.vectordatalayers.db.dao.VdlSourceDAO;
import com.abacogroup.vectordatalayers.db.ntt.AdditionalDataSourceEntity;
import com.abacogroup.vectordatalayers.db.ntt.AdditionalDataSourceEntity.AdditionalDataSourceEntityBuilder;
import com.abacogroup.vectordatalayers.db.ntt.VdlSourceEntity;
import com.abacogroup.wms4j.layers.LayerDefinition;
import com.abacogroup.wms4j.resources.WmsResourceTenantAware;
import com.rabbitmq.client.Connection;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.apache.hc.client5.http.utils.Base64;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;

@ExtendWith(DropwizardExtensionsSupport.class)
class WmsSynchronizerTest extends JdbiTest {

	private final ReqContextUtils ctx = new ReqContextUtils(this.getClass());

	private final VectorDataLayersConfig config = getConfiguration();
	private final Environment environment = EXT.getEnvironment();

	private final JdbiHelper jdbiHelper = getService(JdbiHelper.class);
	private final DatasourceHelper datasourceHelper = spy(getService(DatasourceHelper.class));

	private final LayerService wmsService = getService(LayerServiceImpl.class);
	private final WmsResourceTenantAware wmsResourceTenantAware = new WmsResourceTenantAware();

	private final WmsSynchronizer wmsSynchronizer = new WmsSynchronizer(config, environment,
			datasourceHelper, jdbiHelper, wmsService, wmsResourceTenantAware, mock(Connection.class));

	@AfterEach
	void tearDown() throws NoSuchFieldException, IllegalAccessException {
		Field daosCacheField = JdbiHelper.class.getDeclaredField("daosCache");
		daosCacheField.setAccessible(true);
		Map<Class<?>, Map<String, Object>> daosCache = (Map<Class<?>, Map<String, Object>>) daosCacheField.get(jdbiHelper);

		daosCache.clear();

		Field jdbiMapField = JdbiHelper.class.getDeclaredField("jdbiMap");
		jdbiMapField.setAccessible(true);
		Map<String, Jdbi> jdbiMap = (Map<String, Jdbi>) jdbiMapField.get(jdbiHelper);

		for (String key : List.of("DS1", "DS2", "DS3", "DS4", "DSKO", "DSREMOVED")) {
			jdbiMap.remove(key);
			environment.healthChecks().unregister(jdbiName(key));
		}

		Mockito.reset(datasourceHelper);
	}

	// ----- resyncWmsResource -----
	@Test
	void test_resyncWmsResource_ok() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			execSqlFiles(this.getClass(), List.of("vdl_source"), ctx.getTestScriptParams());

			wmsService.getWMSLayers().forEach(wmsResourceTenantAware::addLayer);
			assertThat(wmsResourceTenantAware.getLayers()).hasSize(5);

			VdlSourceDAO vdlSourceDAO = handle.attach(VdlSourceDAO.class);
			vdlSourceDAO.deleteSource(ctx.getTenantId(), "TEST_1");
			vdlSourceDAO.deleteSource(ctx.getTenantId(), "TEST_2");
			vdlSourceDAO.insertSource(VdlSourceEntity.builder()
					.tenantId(ctx.getTenantId())
					.code("TEST_99")
					.sqlSelect("select 1 from dual")
					.filterGeometryColumn("geom")
					.geometryColumn("geom")
					.identifierColumn("id")
					.geometryType(VdlGeometryType.POLYGONAL)
					.srs("srs")
					.build());

			// tested
			wmsSynchronizer.resyncWmsResource(ctx.getTenantId());

			assertThat(wmsResourceTenantAware.getLayers()).hasSize(4)
					.extracting(LayerDefinition::getLayerName, LayerDefinition::getTenantConstraint)
					.containsExactlyInAnyOrder(
						tuple("TEST_99", ctx.getTenantId()),
						tuple("TEST_3", ctx.getTenantId()),
						tuple("TEST_4", "*"),
						tuple("TEST_5", ctx.getTenantId())
					);

			handle.rollback();
		});

	}

	// ----- resyncAdditionalDataSources -----
	@Test
	void test_resyncAdditionalDataSources_ok() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			given(datasourceHelper.buildAdditionalDataSourcesOrThrow(anyList()))
					.willAnswer(i -> {
						List<String> keys = i.getArgument(0);

						return keys.stream().map(key -> givenDataSource(key, config.getDatabase()).build()).collect(Collectors.toList());
					});

			execSqlFiles(this.getClass(), List.of("vdl_source", "additional_ds"), ctx.getTestScriptParams());

			jdbiHelper.putIfAbsent("DS1", DatasourceHelper.createJdbi(config.getDatabase(), environment, "DS1_jdbi", config.isEnableSpatialVectorAcceleration()));
			jdbiHelper.putIfAbsent("DSREMOVED", DatasourceHelper.createJdbi(config.getDatabase(), environment, "DSREMOVED_jdbi", config.isEnableSpatialVectorAcceleration()));
			assertThat(jdbiHelper.getDao("DS1", LayerDAO.class)).isNotNull();
			assertThat(jdbiHelper.getDao("DSREMOVED", LayerDAO.class)).isNotNull();

			wmsSynchronizer.resyncAdditionalDataSources();

			assertThat(jdbiHelper.getRegisteredAdditionalDataSources())
					.containsExactlyInAnyOrder("secondary", "DS1", "DS2", "DS3", "DS4", "MAIN");

			assertThrows(IllegalStateException.class, () -> jdbiHelper.getJdbi("DSREMOVED"));
			assertThrows(IllegalStateException.class, () -> jdbiHelper.getDao("DSREMOVED", LayerDAO.class));
			assertThat(jdbiHelper.getJdbi("DS1")).isNotNull();
			assertThat(jdbiHelper.getJdbi("DS2")).isNotNull();
			assertThat(jdbiHelper.getJdbi("DS3")).isNotNull();
			assertThat(jdbiHelper.getDao("DS3", LayerDAO.class)).isNotNull();

			handle.rollback();
		});
	}

	@Test
	void test_resyncAdditionalDataSources_KO() {

		getJdbi().useHandle(handle -> {
			handle.begin();

			given(datasourceHelper.buildAdditionalDataSourcesOrThrow(anyList()))
					.willAnswer(i -> {
						List<String> keys = i.getArgument(0);

						return keys.stream().map(key -> {
							if ("DS4".equalsIgnoreCase(key)) {
								return AdditionalDataSourceEntity.builder()
										.dsKey("DS4")
										.dbUser("user")
										.dbPasswordEncoded(Base64.encodeBase64String("pass".getBytes(StandardCharsets.UTF_8)))
										.dbUrl("jdbc:postgresql://localhost:5432/dbKO")
										.build();
							}

							return givenDataSource(key, config.getDatabase()).build();
						}).collect(Collectors.toList());
					});

			execSqlFiles(this.getClass(), List.of("vdl_source", "additional_ds"), ctx.getTestScriptParams());

			jdbiHelper.putIfAbsent("DS1", DatasourceHelper.createJdbi(config.getDatabase(), environment, "DS1_jdbi", config.isEnableSpatialVectorAcceleration()));
			jdbiHelper.putIfAbsent("DSREMOVED", DatasourceHelper.createJdbi(config.getDatabase(), environment, "DSREMOVED_jdbi", config.isEnableSpatialVectorAcceleration()));
			assertThat(jdbiHelper.getDao("DS1", LayerDAO.class)).isNotNull();
			assertThat(jdbiHelper.getDao("DSREMOVED", LayerDAO.class)).isNotNull();

			wmsSynchronizer.resyncAdditionalDataSources();

			assertThat(jdbiHelper.getRegisteredAdditionalDataSources())
					.containsExactlyInAnyOrder("secondary", "DS1", "DS2", "DS3", "MAIN");

			assertThrows(IllegalStateException.class, () -> jdbiHelper.getJdbi("DSREMOVED"));
			assertThrows(IllegalStateException.class, () -> jdbiHelper.getDao("DSREMOVED", LayerDAO.class));
			assertThrows(IllegalStateException.class, () -> jdbiHelper.getJdbi("DS4"));
			assertThrows(IllegalStateException.class, () -> jdbiHelper.getDao("DS4", LayerDAO.class));
			assertThat(jdbiHelper.getJdbi("DS1")).isNotNull();
			assertThat(jdbiHelper.getJdbi("DS3")).isNotNull();
			assertThat(jdbiHelper.getDao("DS3", LayerDAO.class)).isNotNull();

			handle.rollback();
		});
	}


	private AdditionalDataSourceEntityBuilder givenDataSource(String key, DataSourceFactory database) {
		return AdditionalDataSourceEntity.builder()
				.dsKey(key)
				.driverClass(database.getDriverClass())
				.dbUrl(database.getUrl())
				.dbUser(database.getUser())
				.dbPasswordEncoded(Base64.encodeBase64String(database.getPassword().getBytes(StandardCharsets.UTF_8)))
				.validationQuery(database.getValidationQuery().orElse(null))
				.initialSize(database.getInitialSize())
				.minSize(database.getMinSize());
	}
}
