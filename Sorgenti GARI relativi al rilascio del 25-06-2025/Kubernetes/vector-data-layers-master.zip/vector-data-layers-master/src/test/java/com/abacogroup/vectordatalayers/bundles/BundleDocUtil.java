package com.abacogroup.vectordatalayers.bundles;

import static com.abacogroup.vectordatalayers.VectorDataLayersTestApplication.getObjectMapper;

import com.abacogroup.vectordatalayers.bundles.models.ConfigurationBundlePojo;
import com.fasterxml.jackson.annotation.JsonClassDescription;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.module.jsonSchema.jakarta.JsonSchema;
import com.fasterxml.jackson.module.jsonSchema.jakarta.JsonSchemaGenerator;
import com.fasterxml.jackson.module.jsonSchema.jakarta.customProperties.ValidationSchemaFactoryWrapper;
import com.fasterxml.jackson.module.jsonSchema.jakarta.factories.JsonSchemaFactory;
import com.fasterxml.jackson.module.jsonSchema.jakarta.types.ArraySchema;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;
import org.reflections.Reflections;

public class BundleDocUtil {

	public static void main(String[] args) throws IOException {

		Reflections reflections = new Reflections("com.abacogroup.vectordatalayers.bundles.models");
		Set<Class<?>> pojoClasses = reflections.getTypesAnnotatedWith(ConfigurationBundlePojo.class);

		ObjectMapper objectMapper = getObjectMapper();

		for (Class<?> pojoClass : pojoClasses) {
			ValidationSchemaFactoryWrapper visitor = new ValidationSchemaFactoryWrapper();
			JsonSchemaGenerator schemaGen = new JsonSchemaGenerator(objectMapper, visitor);

			JsonSchema schema = schemaGen.generateSchema(pojoClass);
			schema.set$schema("https://json-schema.org/draft/2020-12/schema");
			if (pojoClass.isAnnotationPresent(JsonClassDescription.class)) {
				schema.setDescription(pojoClass.getAnnotation(JsonClassDescription.class).value());
			}
			if (pojoClass.getAnnotation(ConfigurationBundlePojo.class).jsonArray()) {
				ArraySchema arraySchema = new JsonSchemaFactory().arraySchema();
				arraySchema.setItemsSchema(schema);
				schema = arraySchema;
			}


			String jsonSchemaString = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(schema);

			Path filePath = Path.of("docs", "bundles", pojoClass.getSimpleName() + ".schema.json");
			Files.writeString(filePath, jsonSchemaString);
		}
	}
}
