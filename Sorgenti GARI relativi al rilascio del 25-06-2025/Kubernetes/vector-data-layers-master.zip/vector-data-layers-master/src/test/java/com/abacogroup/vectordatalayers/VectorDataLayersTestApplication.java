package com.abacogroup.vectordatalayers;

import static com.abacogroup.vectordatalayers.core.DatasourceHelper.jdbiName;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Map;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.Slf4JSqlLogger;
import org.mockito.Mockito;

import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.abacogroup.bundles.listener.configdata.ConfigDataLogProducer;
import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.vectordatalayers.VectorDataLayersConfig.BundleConfig;
import com.abacogroup.vectordatalayers.VectorDataLayersConfig.RabbitmqConfig;
import com.abacogroup.vectordatalayers.common.ApplicationTestSupport;
import com.abacogroup.vectordatalayers.common.TestApplication;
import com.abacogroup.vectordatalayers.core.DatasourceHelper;
import com.abacogroup.vectordatalayers.core.JdbiHelper;
import com.abacogroup.vectordatalayers.core.LayerService;
import com.abacogroup.vectordatalayers.db.dao.DAOContainer;
import com.abacogroup.wms4j.resources.WmsResourceTenantAware;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Connection;

import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class VectorDataLayersTestApplication extends VectorDataLayersApp implements TestApplication {

	public static Jdbi jdbi;
	public static JdbiHelper jdbiHelper;

	private ApplicationTestSupport applicationTestSupport = new ApplicationTestSupport(this.getName());

	public static ObjectMapper getObjectMapper() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		// brutto, ma consente di accentrare la configurazione senza snaturare application
		new VectorDataLayersApp().configureObjectMapper(mapper);
		return mapper;
	}

	@Override
	public ApplicationTestSupport getAppTestSupport() {
		return applicationTestSupport;
	}

	@Override
	public Jdbi getJdbi() {
		return jdbi;
	}

	public JdbiHelper getJdbiHelper() {
		return jdbiHelper;
	}

	@Override
	protected Jdbi createJdbi(DataSourceFactory dsf, Environment environment, String name, boolean enableSpatialVectorAcceleration) {
		Jdbi jdbi = super.createJdbi(dsf, environment, name, enableSpatialVectorAcceleration);
		jdbi.setSqlLogger(new Slf4JSqlLogger());
		VectorDataLayersTestApplication.jdbi = jdbi;

		applicationTestSupport.execMigrations(environment, dsf);
		return jdbi;
	}

	protected void createAdditionalJdbis(JdbiHelper jdbiHelper, Map<String, DataSourceFactory> additionalDatasources,
			Environment environment, boolean enableSpatialVectorAcceleration) {
		VectorDataLayersTestApplication.jdbiHelper = jdbiHelper;
		if (null == additionalDatasources) {
			return;
		}

		additionalDatasources.forEach((name, dsf) -> {
			Jdbi jdbi = super.createJdbi(dsf, environment, jdbiName(name), enableSpatialVectorAcceleration);
			jdbi.setSqlLogger(new Slf4JSqlLogger());

			applicationTestSupport.execMigrations(environment, dsf, String.format("migrations-test-%s.xml", name));

			jdbiHelper.putIfAbsent(name, jdbi);
		});
	}

	@Override
	protected <T> T register(T service) {
		if (isBetterToMock(service)) {
			service = (T) Mockito.mock(service.getClass());
		}

		applicationTestSupport.register(service);
		return super.register(service);
	}

	private <T> boolean isBetterToMock(T service) {
		return !applicationTestSupport.isInitRabbit() &&
				(service instanceof ConfigDataLogProducer
				|| service instanceof BundleInitServiceProducer);
	}

//	@Override
//	protected ConfigDataLogProducer configDataLogProducerBean(ObjectMapper objectMapper, Connection rabbitmqConnection) {
//		if (!applicationTestSupport.isInitRabbit()) {
//			return Mockito.mock(ConfigDataLogProducer.class);
//		}
//		return super.configDataLogProducerBean(objectMapper, rabbitmqConnection);
//	}

	@Override
	protected void initOpenApi(JerseyEnvironment jersey) {
		log.info("OPEN-API DISABELD");
	}

	@Override
	protected void startWmsSynchronizer(VectorDataLayersConfig configuration, Environment environment,
			DatasourceHelper datasourceHelper, JdbiHelper jdbiHelper, LayerService layerService, WmsResourceTenantAware wmsResource, Connection rabbitmqConnection) throws IOException {
		if (!applicationTestSupport.isInitRabbit()) {
			System.out.println("wms synchronizer OFF");
		} else {
			super.startWmsSynchronizer(configuration, environment, datasourceHelper, jdbiHelper, layerService, wmsResource, rabbitmqConnection);
		}

	}

	@Override
	protected void createBundleInfrastructure(Connection rabbitmqConnection, Jdbi jdbi, JdbiHelper jdbiHelper, DatasourceHelper datasourceHelper,
			DAOContainer daoContainer, ObjectMapper objectMapper, BundleConfig bundleConfig) {
		if (!applicationTestSupport.isInitRabbit()) {
			System.out.println("bundle infrastructure OFF");
		} else {
			super.createBundleInfrastructure(rabbitmqConnection, jdbi, jdbiHelper, datasourceHelper, daoContainer,
					objectMapper, bundleConfig);
		}
	}

	@Override
	public void doRun(VectorDataLayersConfig configuration, Environment environment) throws Exception {
		super.doRun(configuration, environment);
		if (!applicationTestSupport.isExecMigrations()) {
			return;
		}
		try {
			applicationTestSupport.installBundle(jdbi, String.format("%s.%s", this.getName(), "zip"));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	protected static <T, M> void injectMockByField(T target, String filedName) {
		try {
			Class<T> targetClazz = (Class<T>) target.getClass();
			Field field = Arrays.stream(FieldUtils.getAllFields(targetClazz))
					.filter(f -> f.getName().equals(filedName))
					.findFirst()
					.orElseThrow();

			FieldUtils.writeField(target, field.getName(), Mockito.mock(field.getType()), true);
		} catch (IllegalAccessException ex) {
			throw new RuntimeException("errore in inject", ex);
		}
	}

	@Override
	protected Connection createRabbitmqConnection(RabbitmqConfig rabbitmqConfig) {
		if (applicationTestSupport.isInitRabbit()) {
			return super.createRabbitmqConnection(rabbitmqConfig);
		} else {
			log.info("RABBIT CONNECTION DISABLED");
			return null;
		}
	}

	@Override
	protected WmsResourceTenantAware createWmsResource(LayerService wmsService) {
		return new WmsResourceTenantAware();
	}

	private void initMultiTenant(Environment environment) {
		environment.jersey().register(new MultitenantFilter("tenant"));
	}


}
