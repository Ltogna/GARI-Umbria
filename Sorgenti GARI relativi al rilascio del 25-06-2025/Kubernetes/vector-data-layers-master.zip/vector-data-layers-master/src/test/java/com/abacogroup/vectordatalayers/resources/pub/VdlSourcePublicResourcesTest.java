package com.abacogroup.vectordatalayers.resources.pub;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import org.mockito.Mockito;
import static org.mockito.Mockito.verify;

import static com.abacogroup.vectordatalayers.api.VdlGeometryType.POLYGONAL;
import com.abacogroup.vectordatalayers.api.pub.VdlSourceDataV1;
import com.abacogroup.vectordatalayers.api.pub.VdlSourceV1;
import com.abacogroup.vectordatalayers.api.pub.VdlSourceV1.VdlSourceV1Builder;
import com.abacogroup.vectordatalayers.common.WebCliHelper;
import static com.abacogroup.vectordatalayers.common.WebCliHelper.TENANT;
import com.abacogroup.vectordatalayers.common.resources.ReqContext;
import com.abacogroup.vectordatalayers.core.VdlSourceV1Service;

import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.UriBuilder;

@ExtendWith(DropwizardExtensionsSupport.class)
class VdlSourcePublicResourcesTest {

	private final VdlSourceV1Service service = Mockito.mock(VdlSourceV1Service.class);

	private final VdlSourcePublicResources resource = new VdlSourcePublicResources(service);
	private final ResourceExtension EXT = WebCliHelper.createEXT(resource);


	// ----- sources -----
	@Test
	void test_sources_ok() {

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "sources");
		String uri = uriBuilder.build(TENANT).toString();
		System.out.println(uri);

		VdlSourceV1 mockRes = givenSource("TEST").build();

		given(service.getTenantSources(any(), any()))
				.willReturn(List.of(mockRes));

		List<VdlSourceV1> res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header(HttpHeaders.AUTHORIZATION, WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.isEqualTo(List.of(mockRes));

		verify(service).getTenantSources(new ReqContext(TENANT, null, null), null);
	}

	// ----- source -----
	@Test
	void test_source_ok() {
		String code = "TEST";

		UriBuilder uriBuilder = UriBuilder.fromResource(resource.getClass()).path(resource.getClass(), "source");
		String uri = uriBuilder.build(TENANT, code).toString();
		System.out.println(uri);

		VdlSourceV1 mockRes = givenSource(code).build();

		given(service.getSourceData(any(), any()))
				.willReturn(mockRes);

		VdlSourceDataV1 res = EXT.getJerseyTest().client()
				.target(UriBuilder.fromUri(uri))
				.request()
				.header(HttpHeaders.AUTHORIZATION, WebCliHelper.JWT_MOCK_CREDENTIALS)
				.get(new GenericType<>() {
				});

		assertThat(res).isNotNull()
				.usingRecursiveComparison()
				.ignoringFields("code")
				.isEqualTo(mockRes);

		verify(service).getSourceData(new ReqContext(TENANT, null, null), code);
	}

	private VdlSourceV1Builder<?, ?> givenSource(String code) {
		return VdlSourceV1.builder()
				.code(code)
				.sqlSelect("select id as test_id, geom, descr from geom_table_two where {spatial_where_clause}")
				.filterGeometryColumn("geom")
				.geometryColumn("geom")
				.identifierColumn("test_id")
				.labelColumn("descr")
				.fillColor("#FFFF22")
				.borderThick(2)
				.borderColor("#000022")
				.fontSize(12)
				.fontColor("#FF0022")
				.geometryType(POLYGONAL)
				.srs("EPSG:32632");
	}

}
