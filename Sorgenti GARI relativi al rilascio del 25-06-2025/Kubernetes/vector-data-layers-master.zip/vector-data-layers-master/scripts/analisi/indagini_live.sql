select * from equ_jobs ej order by pkid;
select * from domains_sync_locks dsl ;



update equ_jobs set fl_status = 9 where fl_status =8 and pkid = 4024;

update equ_jobs set fl_status=0 where pkid=10405 and fl_status = 9;


select * from domains_isole_geom dig where party_id = 29577 and sector_code = 'M190';

select st_area(st_geomfromtext('POLYGON ((325267.48 5093576.32, 325267.49 5093576.33, 325267.85 5093576.24, 325267.48 5093576.32))')); 