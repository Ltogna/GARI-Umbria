--- query varie

select * from cll_land_link_detail;

select * from cll_group cg , cll_land_link_detail clld 
where clld.group_id = cg.id  and clld.party_id <> cg.party_id ;

select count(*),clld.party_id, clld.sector_code  from cll_land_link_detail clld 
where localtimestamp between clld.dt_insert and clld.dt_delete 
and '20240515' between clld.day_from  and clld.day_to 
group by clld.party_id, clld.sector_code  ;

select clld.party_id, clld.parcel_id, count(*) 
from cll_land_link_detail clld
where localtimestamp between clld.dt_insert and clld.dt_delete 
and '20240515' between clld.day_from  and clld.day_to
group by clld.party_id, clld.parcel_id;


select * from cll_land_link_detail clld where parcel_id =1490572;

--------------------------------------------------------

--- elenco soggetti ad una data
select clld.party_id, count(*) 
from cll_land_link_detail clld 
where  localtimestamp between clld.dt_insert and clld.dt_delete 
and '20240515' between clld.day_from  and clld.day_to
group by clld.party_id ;

--- elenco settori di un soggetto ad una data
select clld.sector_code 
from cll_land_link_detail clld 
where party_id=52742
and localtimestamp between clld.dt_insert and clld.dt_delete 
and '20240515' between clld.day_from  and clld.day_to
group by clld.sector_code;

--- elenco particelle di un soggetto ad una data in un settore
select clld.parcel_id, max(clld.day_from) as day_from, min(clld.day_to) as day_to, (CASE WHEN sum(clld.title_type_perc) < 100 then 1 else 0 end) as fg_shared
from cll_land_link_detail clld
where party_id=52742
and localtimestamp between clld.dt_insert and clld.dt_delete 
and '20240515' between clld.day_from  and clld.day_to
and clld.sector_code = 'A028'
group by clld.parcel_id;


