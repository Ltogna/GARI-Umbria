select ST_SRID(shape_prif) from domains_npr;
select ST_SRID(shape_prif) from tmp_domains_npr;

update domains_npr set shape_prif=ST_SetSRID(shape_prif,0);
update tmp_domains_npr set shape_prif=ST_SetSRID(shape_prif,0);

delete from domains_npr_isole_geom ;
delete from domains_isole_geom ;
delete from domains_sync  ;
delete from domains_sync_locks  ;
delete from equ_jobs ;


select * from domains_npr_isole_geom ;
select * from domains_isole_geom ;
select * from domains_sync  ;
select * from domains_sync_locks  ;
select * from equ_jobs order by fl_status desc;

select st_area(dnig.geom),dnig.* from domains_npr_isole_geom dnig 
where dnig.npr_id is null
and st_area(dnig.geom)>1
and srs='EPSG:32633'
;

select * from domains_npr_isole_geom dnig where party_id=17016;
select * from domains_npr dn where dn.id_prif in (163366621,163606021); --163606021 the big one
select * from domains_isole_geom dig where dig.id = 5882;

select * from domains_npr_isole_geom dnig where party_id =17016;
select * from domains_isole_geom dig where party_id =17016;
update domains_isole_geom set user_id_delete = 'ZILO', dt_delete = localtimestamp where localtimestamp between dt_insert and dt_delete and party_id =17016;


delete from domains_sync_locks  ;
delete from equ_jobs ;


select * from domains_isole_geom dig where party_id =55065;
select * from domains_npr_isole_geom dnig where party_id =55065 and sector_code='F266';


select * from equ_jobs order by fl_status desc, dt_lock;


select * from domains_sync ds where ds.party_id = 17016;
select * from domains_isole_geom dig where dig.party_id = 17016;
select * from domains_npr_isole_geom dig where dig.party_id = 17016;

update domains_isole_geom set geom_hash_code = '*'||geom_hash_code where localtimestamp between dt_insert and dt_delete and party_id =17016;
delete from domains_npr_isole_geom where party_id = 17016 and not (localtimestamp between dt_insert and dt_delete) ;
delete from domains_isole_geom where party_id = 17016 and not (localtimestamp between dt_insert and dt_delete) ;

select * from equ_jobs ej ;
select * from domains_isole_geom dig where party_id = 1112136 and sector_code = 'C699';

select * from domains_sync ds 
where ds.sync_type = 'ISOLE'
and not exists 
(select * from domains_sync ds2
where ds2.sync_type = 'NPRISOLE'
and ds2.party_id=ds.party_id
and ds2.sector_code=ds.sector_code)
;

select distinct st_geometrytype(geom) from domains_isole_geom dig ;
select * from domains_isole_geom dig where st_geometrytype(geom)<>'ST_Polygon';


update equ_jobs set fl_status = 9 where fl_status =8 and pkid = 4024;

delete from domains_npr_isole_geom where dt_delete<localtimestamp;
delete from domains_isole_geom where dt_delete<localtimestamp;

select * from domains_isole_geom where dt_delete < localtimestamp; 
select * from domains_isole_geom order by dt_insert desc; 

select distinct isola_geom_id,dt_delete  from domains_npr_isole_geom dnig where dt_delete < clock_timestamp(); 
select dnig.isola_geom_id,dnig.dt_insert  from domains_npr_isole_geom dnig group by dnig.isola_geom_id,dnig.dt_insert order by dnig.dt_insert desc; 


