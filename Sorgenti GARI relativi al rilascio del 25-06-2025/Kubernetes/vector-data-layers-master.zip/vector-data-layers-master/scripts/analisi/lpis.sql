select * from lpis_parcel_details lpd ;
select * from lpis_parcels lp where id=1563791;
select * from lpis_sector_blocks lsb where id=10568;

-- dati di una particella
select lpd.day_from, lpd.day_to, lpd.srs, lpd.geom
from lpis_parcel_details lpd 
where lpd.parcel_id = 2958315
and localtimestamp between lpd.dt_insert and lpd.dt_delete 
and '20240515' between lpd.day_from  and lpd.day_to;