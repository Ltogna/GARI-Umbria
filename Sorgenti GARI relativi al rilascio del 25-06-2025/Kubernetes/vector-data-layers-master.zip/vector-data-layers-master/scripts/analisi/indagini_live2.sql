select * from equ_jobs order by fl_status ;	
update equ_jobs set fl_status=9 where fl_status =1;
update equ_jobs set dt_lock=null;

SELECT * FROM domains_npr dn where dn.id_prif =163360174;


select * from domains_sync ds order by dt_sync;
select * from domains_npr_isole_geom dnig  order by dt_insert desc;


select dt_insert,count(*) from domains_npr_isole_geom group by dt_insert order by 1;

select count(*) from domains_npr_isole_geom where dt_insert < '2024-04-09 00:00:00.000'
union 
select count(*) from domains_npr_isole_geom where dt_insert > '2024-04-09 00:00:00.000'


select * from domains_sync ds where ds.party_id =1112136 and ds.sector_code ='C699';

select payload::json ->> 'partyId' as party_ID, payload::json ->> 'sectorCode' as sector_code from equ_jobs ej 
where fl_status = 9;


select * from domains_sync ds 
where (''||ds.party_id, ds.sector_code) in 
(
select payload::json ->> 'partyId' as party_ID, payload::json ->> 'sectorCode' as sector_code from equ_jobs ej 
where fl_status = 9
);


select * from domains_sync ds 
where ''||ds.party_id in 
(
select payload::json ->> 'partyId' as party_ID from equ_jobs ej 
where fl_status = 9
);


select * from domains_sync_locks dsl 
where (''||dsl.party_id, dsl.sector_code) in 
(
select payload::json ->> 'partyId' as party_ID, payload::json ->> 'sectorCode' as sector_code from equ_jobs ej 
where fl_status = 9
);

delete from domains_sync_locks ;

select * from domains_isole_geom dig order by dt_delete asc;
select * from domains_npr_isole_geom dig order by dt_delete asc;

select * from domains_sync ds where ds.sync_type = 'ISOLE'
and not exists (
select * from domains_sync ds2 where ds2.sync_type = 'NPRISOLE'
and ds.party_id =ds2.party_id
and ds.sector_code =ds2.sector_code
);

select * from domains_sync_locks dsl ;
select * from equ_jobs_lock ejl ;
select queue_id,count(*),fl_status from equ_jobs ej 
group by fl_status , queue_id ;