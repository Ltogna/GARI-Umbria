select * from spatial_ref_sys where srid in ('3003','3004','993003','993004');
select * from spatial_ref_sys where srid in ('32632','32633');--utm32 utm33
select * from spatial_ref_sys where srid in ('993003','993004');

select st_transform(geom,'EPSG:3004', 'EPSG:32633') from appe_dett_2023_friuli adf ;


--questa
select geom,st_transform(st_setsrid(geom,993004), 32633) as custom,st_transform(st_setsrid(geom,3004), 32633) as orig from appe_dett_2023_friuli adf ;
select 'string',st_transform(geom,'+proj=tmerc +lat_0=0 +lon_0=15 +k=0.9996 +x_0=2520000 +y_0=0 +ellps=intl +nadgrids=36100630_47201840_R40_S89.gsb +units=m +wktext', 'EPSG:32633') from appe_dett_2023_friuli adf where gid=706599
union 
select 'orig',st_transform(geom,'EPSG:3004', 'EPSG:32633') from appe_dett_2023_friuli adf where gid=706599
union 
select 'srid',st_transform(st_setsrid(geom,993004), 32633) from appe_dett_2023_friuli adf where gid=706599
;


select * from appe_dett_2023_friuli where gid=706599;

select st_transform(geom,'EPSG:3004', 'EPSG:32633') from appe_dett_2023_friuli ;
select st_transform(geom,'+proj=tmerc +lat_0=0 +lon_0=15 +k=0.9996 +x_0=2520000 +y_0=0 +ellps=intl +nadgrids=36100630_47201840_R40_S89.gsb +units=m +wktext', 'EPSG:32633') from appe_dett_2023_friuli ;

select st_setsrid(st_transform(geom,'EPSG:3004', 'EPSG:32633'),32633) as standard, st_setsrid(st_transform(geom,'+proj=tmerc +lat_0=0 +lon_0=15 +k=0.9996 +x_0=2520000 +y_0=0 +ellps=intl +nadgrids=36100630_47201840_R40_S89.gsb +units=m +wktext', 'EPSG:32633'),32633) as custom from appe_dett_2023_friuli ;


create table zzz_appe_standard as select gid, st_transform(geom,'EPSG:3004', 'EPSG:32633') as geom from appe_dett_2023_friuli ;
create table zzz_appe_custom as select gid, st_transform(geom,'+proj=tmerc +lat_0=0 +lon_0=15 +k=0.9996 +x_0=2520000 +y_0=0 +ellps=intl +nadgrids=36100630_47201840_R40_S89.gsb +units=m +wktext', 'EPSG:32633') as geom from appe_dett_2023_friuli ;

select st_geometryfromtext('MULTIPOLYGON (((2362276.01 5088656.2787,2362068.7715 5088547.6831,2362064.8982 5088553.6516,2362052.8341 5088547.8098,2362056.3264 5088541.7779,2361792.0585 5088401.3305,2361739.1972 5088492.3825,2361741.9585 5088498.9125,2361777.3334 5088520.354,2361738.5504 5088586.857,2361779.1139 5088692.096,2361801.4004 5088749.5279,2361925.0259 5088822.6763,2362115.4405 5088932.8987,2362276.01 5088656.2787)))'); 

select st_transform(st_geometryfromtext('MULTIPOLYGON (((2362276.01 5088656.2787,2362068.7715 5088547.6831,2362064.8982 5088553.6516,2362052.8341 5088547.8098,2362056.3264 5088541.7779,2361792.0585 5088401.3305,2361739.1972 5088492.3825,2361741.9585 5088498.9125,2361777.3334 5088520.354,2361738.5504 5088586.857,2361779.1139 5088692.096,2361801.4004 5088749.5279,2361925.0259 5088822.6763,2362115.4405 5088932.8987,2362276.01 5088656.2787)))'),'EPSG:3004', 'EPSG:32633'); 
select st_transform(st_geometryfromtext('MULTIPOLYGON (((2362276.01 5088656.2787,2362068.7715 5088547.6831,2362064.8982 5088553.6516,2362052.8341 5088547.8098,2362056.3264 5088541.7779,2361792.0585 5088401.3305,2361739.1972 5088492.3825,2361741.9585 5088498.9125,2361777.3334 5088520.354,2361738.5504 5088586.857,2361779.1139 5088692.096,2361801.4004 5088749.5279,2361925.0259 5088822.6763,2362115.4405 5088932.8987,2362276.01 5088656.2787)))'),'+proj=tmerc +lat_0=0 +lon_0=15 +k=0.9996 +x_0=2520000 +y_0=0 +ellps=intl +nadgrids=36100630_47201840_R40_S89.gsb +units=m +wktext', 'EPSG:32633'); 