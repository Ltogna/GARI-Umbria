CREATE TABLE DOMAINS_NPR
(
    ID_PRIF            int8 NOT null primary key,
    CODI_PRIF          VARCHAR(100) NOT NULL,
    CODI_REFR          VARCHAR(100) NOT NULL,
    SUPE_PRIF          numeric,
    DATA_INSE_PRIF     timestamp NOT NULL,
    DATA_SCAD_PRIF     timestamp NOT NULL,
    USER_INSE_PRIF     VARCHAR(100),
    USER_SCAD_PRIF     VARCHAR(100),
    COD_REGI           int4,
    ID_QUAD            int8,
    FUSO               varchar(100),
    ID_QUAD_SHAPE      int8,
    CODI_ENTE_PRIF     VARCHAR(100),
    SIGLA_REGI_PRIF    VARCHAR(100),
    ID_ORPA_PRIF       int8,
    ANNO_INIZ_PRIF     int2,
    ANNO_FINE_PRIF     int2,
    CODI_EVENT_INSE    VARCHAR(100),
    CODI_EVENT_SCAD    VARCHAR(100),
    SHAPE_PRIF         geometry
);

COMMENT ON TABLE DOMAINS_NPR IS 'Tabella delle parcelle di riferimento';

COMMENT ON COLUMN DOMAINS_NPR.ID_PRIF IS
    'Id della partcella di riferimento';

COMMENT ON COLUMN DOMAINS_NPR.CODI_PRIF IS
    'Codifica alfanumerica della particella di riferimento';

COMMENT ON COLUMN DOMAINS_NPR.CODI_REFR IS
    'Codifica del tipo di suolo per la partcella di riferimento';

COMMENT ON COLUMN DOMAINS_NPR.SUPE_PRIF IS
    'Superficie della partcella di riferimento';

COMMENT ON COLUMN DOMAINS_NPR.DATA_INSE_PRIF IS
    'Data di caricamento della partcella di riferimento';

COMMENT ON COLUMN DOMAINS_NPR.DATA_SCAD_PRIF IS
    'Data di scadenza della partcella di riferimento';

COMMENT ON COLUMN DOMAINS_NPR.USER_INSE_PRIF IS
    'Utente che ha caricato il record';

COMMENT ON COLUMN DOMAINS_NPR.ID_QUAD IS
    'Id per il riquadro della partcella di riferimento';

COMMENT ON COLUMN DOMAINS_NPR.FUSO IS
    'Fuso per la geometria della partcella di riferimento';

COMMENT ON COLUMN DOMAINS_NPR.ID_QUAD_SHAPE IS
    'Id per il riquadro proiettato della partcella di riferimento';

COMMENT ON COLUMN DOMAINS_NPR.SHAPE_PRIF IS
    'Geometria della partcella di riferimento';

CREATE UNIQUE INDEX DOMAINS_NPR_IX1
    ON DOMAINS_NPR (CODI_PRIF);
   
CREATE INDEX DOMAINS_NPR_IX2
    ON DOMAINS_NPR (ID_QUAD_SHAPE);

CREATE INDEX DOMAINS_NPR_SX1 ON DOMAINS_NPR USING gist (SHAPE_PRIF);

CREATE INDEX DOMAINS_NPR_IX3
    ON DOMAINS_NPR (CODI_EVENT_INSE);

CREATE INDEX DOMAINS_NPR_IX4
    ON DOMAINS_NPR (CODI_EVENT_SCAD);

CREATE INDEX DOMAINS_NPR_IX5
    ON DOMAINS_NPR (COD_REGI);
          
