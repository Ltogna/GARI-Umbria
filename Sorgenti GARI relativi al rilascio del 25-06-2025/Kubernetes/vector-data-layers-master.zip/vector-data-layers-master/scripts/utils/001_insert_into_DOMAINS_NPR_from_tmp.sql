INSERT INTO domains_npr
(id_prif, codi_prif, codi_refr, supe_prif, data_inse_prif, data_scad_prif, user_inse_prif, user_scad_prif, cod_regi, id_quad, fuso, id_quad_shape, codi_ente_prif, sigla_regi_prif, id_orpa_prif, anno_iniz_prif, anno_fine_prif, codi_event_inse, codi_event_scad, shape_prif)
SELECT id_prif, codi_prif, codi_refr, supe_prif, TO_TIMESTAMP(data_inse_, 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP(data_scad_, 'YYYY-MM-DD HH24:MI:SS'), user_inse_, user_scad_, cod_regi, id_quad, fuso, id_quad_sh, codi_ente_, sigla_regi, id_orpa_pr, anno_iniz_, anno_fine_, codi_event, codi_even1, ST_SetSRID(shape_prif,0)
FROM tmp_domains_npr;

commit;