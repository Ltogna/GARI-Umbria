# Changelog

## [v2.2.7](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v2.2.5...v2.2.6) (2025-06-24)

### Features

* :sparkles: support reprojection in geometries intersection

## [v2.2.6](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v2.2.5...v2.2.6) (2025-06-20)

### Features

* :sparkles: added pageSize query param to public apis

## [v2.2.5](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v2.2.4...v2.2.5) (2025-05-12)

### Features

* :sparkles: added source modules list in SourceData bundle
* :sparkles: add module parameter to VdlSource methods and update related queries

### Fixes

* :bug: fixed query in LayerDAO
* :bug: fixed new table name

## [v2.2.4](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v2.2.3...v2.2.4) (2025-04-02)

### Fixes

 * Resolve "#170384 - Fix bundle vector data layers"

## [v2.2.3](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v2.2.2...v2.2.3) (2025-03-27) Test FIX

### Other
* :memo: update readme


### [v2.2.2](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v2.2.1...v2.2.2) (2025-03-27)

### Fixes
* :bug: fixed data source processor exception trying inserting a data source already inserted
* :bug: fix issue in additional column responses



### [v2.2.i](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v2.2.0...v2.2.1) (2025-01-29)

### Features
* support for ‘none’ as the value of the SRS parameter of /wms

### Fixes
* Fix CI


### [v2.2.0](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v2.1.1...v2.2.0) (2025-01-23)

### Features

* :sparkles: added support to reprojection

### [v2.1.1](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v2.1.0...v2.1.1) (2025-01-10)

### Fixes

* **dao:** :bug: fix issue in object value elaboration in LayerGeometryWithInfoMapper

### Other

* :wrench: some notes in config file

### [v2.1.0](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v2.0.3...v2.1.0) (2024-12-23)

### Features

* :sparkles: added layer style, closes [#159444](https://abacogroup.easyredmine.com/issues/159444)

### Build

* :arrow_up: upgrade dropwizard with protocolUpgradeEnabled false

### Documentation

* :memo: update README.md

### [v2.0.3](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v2.0.2..v2.0.3) (2024-12-18)

### Build

* pom: :arrow_down: downgrade dropwizard version to v4.0.8

### [v2.0.2](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v2.0.1...v2.0.2) (2024-12-18)

### Build

* pom: :arrow_up: upgrade dropwizard version to v4.0.11

### [v2.0.1](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v2.0.0...v2.0.1) (2024-12-10)

### Fixes

* :bug: fixed a bug in LayerGeometryWithInfoMapper

### [v2.0.0](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.4.4...v2.0.0) (2024-11-29)

### Features
* :sparkles: Added new APIs to manage vector data layers

#### Fixes

* :bug: fixed sso2 auth filter
* :bug: update mappings and improve datasource handling in VdlSourceMapper and VdlSourceServiceImpl
* :bug: fixed a query
* :green_heart: fix CI typo
* :bug: fix issue in fvg-dev values

### [v1.4.4](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.4.3...v1.4.4) (2024-11-15)

#### Build

* pom: :arrow_up:  upgrade simple-wms-4j version to 6.0.0

#### Fixes

* :bug: Fixed sonarqube findings

### [v1.4.3](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.4.2...v1.4.3) (2024-11-10)

#### Fixes

* :bug: Using snake case field names

### [v1.4.2](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.4.1...v1.4.2) (2024-11-08)

#### Fixes

* :bug: Using abaco-jdbi column mapper


### [v1.4.1](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.4.0...fca4e6ababc2dc49d72126c8416d27b4873deece) (2024-11-08)

### Fix
* :bug: fix typo in query for intersected api


## [v1.4.0](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.3.4...v1.4.0) (2024-11-08)

### Features
* :sparkles: Allow the use of {tenant} as a placeholder

### Fix
* Fix CI


## [v1.3.4](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.3.3...v1.3.4) (2024-10-31)

### Features
* :sparkles: added new api to get intersected geometries by touching geom, closes [#143071](https://abacogroup.easyredmine.com/issues/143071)
* **sources:** :closed_lock_with_key: add lpis db env for additional data source, closes [#143071](https://abacogroup.easyredmine.com/issues/143071)

### Other
* :see_no_evil: update git ignore

### [v1.3.3](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.3.2...v1.3.3) (2024-10-02)

### Other
* update abaco-jdbi version for rendering timeout api

### [v1.3.2](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.3.1...v1.3.2) (2024-09-25)

### Other
* fix build script for shade plugin and dependency inject

### [v1.3.1](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.3.0...v1.3.1) (2024-09-25)

## Fix
* fix sonar issues

## [v1.3.0](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.2.0...v1.3.0) (2024-09-24)

## [v1.2.0](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.1.4...v1.2.0) (2024-07-17)

### [v1.1.4](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.1.3...v1.1.4) (2024-06-17)

### [v1.1.3](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.1.2...v1.1.3) (2024-06-05)

### [v1.1.2](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.1.1...v1.1.2) (2024-06-04)

### [v1.1.1](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.1.0...v1.1.1) (2024-06-04)

## [v1.1.0](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.0.2...v1.1.0) (2024-06-03)

### [v1.0.2](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.0.1...v1.0.2) (2024-05-24)

### [v1.0.1](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v1.0.0...v1.0.1) (2024-05-24)

## [v1.0.0](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v0.0.3...v1.0.0) (2024-05-24)

### [v0.0.3](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v0.0.2...v0.0.3) (2024-05-22)

### [v0.0.2](https://gitlab.fe.abacogroup.eu/new-agri/vector-data-layers/compare/v0.0.1...v0.0.2) (2024-05-21)

### v0.0.1 (2024-05-21)

