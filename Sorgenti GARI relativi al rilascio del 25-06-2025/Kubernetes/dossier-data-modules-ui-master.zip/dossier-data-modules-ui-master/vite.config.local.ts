import vue from "@vitejs/plugin-vue";
import vueJsx from "@vitejs/plugin-vue-jsx";
import { execSync } from "child_process";
import { fileURLToPath, URL } from "url";
import { defineConfig, loadEnv, type ConfigEnv } from "vite";
import { viteStaticCopy } from "vite-plugin-static-copy";
import nodePackage from "./package.json";

export default function (config: ConfigEnv) {
    process.env = {
        ...process.env,
        ...loadEnv(config.mode, process.cwd(), ["VITE"]),
        VITE_APP_VERSION: nodePackage.version,
        VITE_APP_GIT_COMMIT: execSync("git rev-parse --short=8 HEAD")
            .toString()
            .trim(),
    };

    // https://vitejs.dev/config/
    return defineConfig({
        base: process.env.VITE_BASE,
        plugins: [
            viteStaticCopy({
                targets: [
                    {
                        src: "node_modules/bootstrap-italia/dist/**/*",
                        dest: "bootstrap-italia/dist",
                    },
                ],
            }),
            vue(),
            vueJsx(),
        ],
        resolve: {
            alias: {
                "@": fileURLToPath(new URL("./src", import.meta.url)),
            },
        },
        build: {
            rollupOptions: {
                output: {
                    entryFileNames: "[name].[hash].js",
                    // assetFileNames: "app-[name].[hash].css",
                    // chunkFileNames: "chunk-[name].[hash].js",
                    // manualChunks: undefined,
                },
            },
        },
        server: {
            port: 3000,
            proxy: {
                "/vine-gis-server": {
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    target: "https://iacs-dev.fe.abacogroup.eu",
                    secure: false,
                    changeOrigin: true,
                },
                "/customer-vine-link": {
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    target: "https://iacs-dev.fe.abacogroup.eu",
                    secure: false,
                    changeOrigin: true,
                },
                "/dossier-data-modules": {
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    target: "https://iacs-dev.fe.abacogroup.eu",
                    secure: false,
                    changeOrigin: true,
                },
                "/file-store": {
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    target: "https://iacs-dev.fe.abacogroup.eu",
                    secure: false,
                    changeOrigin: true,
                },
                "/sso2": {
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    target: "https://iacs-dev.fe.abacogroup.eu",
                    secure: false,
                    changeOrigin: true,
                },
                "/party-registry": {
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    target: "https://iacs-dev.fe.abacogroup.eu",
                    changeOrigin: true,
                    secure: false,
                },
                "/avepa-vine-authorizations": {
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    //target: "http://iacs-dev.fe.abacogroup.eu",
                    target: "http://localhost:18914",
                    changeOrigin: true,
                    secure: false,
                },
                // "/avepa-legacy": {
                //     target: "https://iacs-dev.fe.abacogroup.eu",
                //     secure: false,
                //     changeOrigin: true,
                // },
            },
        },
    });
}
