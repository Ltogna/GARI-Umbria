/**
 * Gets the base URL of the portal.
 * @returns {string} The base URL of the portal.
 */
export function getPortalBaseURL() {
    const parentModuleDeployDir = "dossier";
    const basePath =
        window.location.href.indexOf(`/${parentModuleDeployDir}`) > -1
            ? window.location.href.split(`/${parentModuleDeployDir}`)[0]
            : window.location.origin;
    return basePath;
}
