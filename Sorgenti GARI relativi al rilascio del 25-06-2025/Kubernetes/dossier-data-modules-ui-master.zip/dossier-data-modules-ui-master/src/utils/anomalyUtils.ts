import type { AnomalySearchModel } from "@/models/anomalyLevel";

/**
 * Gets the maximum anomaly level from a list of anomalies.
 * @param {AnomalySearchModel[]} anomalyList - The list of anomalies.
 * @returns {string} The maximum anomaly level ("danger", "warning", or "info").
 */
export function getAnomalyMaxLevel(anomalyList: AnomalySearchModel[]) {
    const curLevels = anomalyList.flatMap((anomaly) => anomaly.type.level);
    if (curLevels.some((l) => l === "DANGER")) return "danger";
    if (curLevels.some((l) => l === "WARN")) return "warning";
    return "info";
}

/**
 * Icons for different anomaly levels.
 * @type {Object.<string, string>}
 */
export const anomalyIcons: {
    [key: string]: string;
} = {
    danger: "minus-circle",
    warn: "exclamation-triangle",
    info: "circle-info",
};
