/**
 * Determines if the application is running in standalone mode.
 * @type {boolean}
 */
export const isStandalone =
    import.meta.env.MODE === "standalone" ||
    import.meta.env.MODE === "schedario";
