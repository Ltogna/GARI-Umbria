const label = "ha";
const DATE_PATTERN = /^(?<year>\d{4})(?<month>\d{2})(?<day>\d{2})$/;

import { i18n } from "../i18n";
import { z } from "zod";

export const intlNumberFormatOptions: Intl.NumberFormatOptions = {
    minimumFractionDigits: 4,
    maximumFractionDigits: 4,
};

/**
 * Converts area from square meters to hectares.
 * @param {number} x - The area in square meters.
 * @returns {string} The area in hectares formatted as a string.
 * @example
 * ```javascript
 *  Utils.areaSQMInHA(123456);
 * // 12.3456
 * ```
 */
export const areaSQMInHA = function (x: number): string {
    return i18n.global.n(x / 10_000, intlNumberFormatOptions);
};

/**
 * Converts area from square meters to hectares and appends the unit label.
 * @param {number} x - The area in square meters.
 * @returns {string} The area in hectares with the unit label.
 * @example
 * ```javascript
 *  Utils.areaSQMInHAWithLabel(123456);
 * // 12.3456 (ha)
 * ```
 */
export const areaSQMInHAWithLabel = function (x: number): string {
    return `${areaSQMInHA(x)} (${label})`;
};

/**
 * Converts a string or any value to a Date object.
 * @param {any} val - The value to convert.
 * @returns {Date | null} The converted Date object or null if conversion fails.
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const toDate = (val: any): Date | null => {
    if (val !== null) {
        if (typeof val === "string") {
            const year = parseInt(val.substring(0, 4));
            const month = parseInt(val.substring(4, 6)) - 1;
            const day = parseInt(val.substring(6));
            const date = new Date(year, month, day, 0, 0, 0, 0);
            const timezone = date.getTimezoneOffset() * 60_000;
            return new Date(date.getTime() - timezone);
        }
        console.warn(`Cannot convert ${val} of type ${typeof val} to Date`);
    }
    return null;
};

/**
 * Converts a date string to a Date object.
 * @param {string} dt - The date string to convert.
 * @returns {Date | null} The converted Date object or null if conversion fails.
 */
export function convertToDate(dt: string) {
    return toDate(dt);
}

/**
 * Formats a Date object to a string in the format YYYYMMDD.
 * @param {Date} date - The Date object to format.
 * @returns {string} The formatted date string.
 */
export function formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, "0");
    const day = date.getDate().toString().padStart(2, "0");

    return `${year}${month}${day}`;
}

/**
 * Formats a Date object to a string in the format DD/MM/YYYY.
 * @param {Date} date - The Date object to format.
 * @returns {string} The formatted date string.
 */
export function dateToString(date: Date): string {
    const day: string = String(date.getDate()).padStart(2, "0");
    const month: string = String(date.getMonth() + 1).padStart(2, "0");
    const year: number = date.getFullYear();
    return `${day}/${month}/${year}`;
}

/**
 * Returns a placeholder string if the value is null, undefined, or an empty string.
 * @param {string | number | null | undefined} value - The value to check.
 * @returns {string} The value as a string or a placeholder.
 */
export const emptyFieldPlaceholder = (
    value: string | number | null | undefined,
): string => {
    if (typeof value === "string" && value.length) {
        return value;
    }

    if (value) return value.toString();

    return "-";
};

/**
 * Prints date information based on the given precision.
 * @param {Date | string} [dateString] - The date string or Date object.
 * @param {string} [datePrecision="YMD"] - The precision of the date (Y, YM, YMD).
 * @returns {[string, string, string]} An array containing the year, month, and day as strings.
 */
export const printDateInfo = (
    dateString?: Date | string,
    datePrecision = "YMD",
): [string, string, string] => {
    const result: [string, string, string] = ["-", "-", "-"];
    if (dateString) {
        if (dateString instanceof Date) {
            switch (datePrecision) {
                case "Y":
                    result[0] = dateString.getFullYear().toString();
                    break;
                case "YM":
                    result[0] = dateString.getFullYear().toString();
                    result[1] = (dateString.getMonth() + 1)
                        .toString()
                        .padStart(2, "0");
                    break;
                default:
                    result[0] = dateString.getFullYear().toString();
                    result[1] = (dateString.getMonth() + 1)
                        .toString()
                        .padStart(2, "0");
                    // #136934 fixed display day of month
                    result[2] = dateString
                        .getDate()
                        .toString()
                        .padStart(2, "0");
                    break;
            }
        }

        if (typeof dateString === "string") {
            switch (datePrecision) {
                case "Y":
                    result[0] = dateString.substring(0, 4);
                    break;
                case "YM":
                    result[0] = dateString.substring(0, 4);
                    result[1] = dateString.substring(4, 6).padStart(2, "0");

                    break;
                default:
                    result[0] = dateString.substring(0, 4);
                    result[1] = dateString.substring(4, 6);
                    result[2] = dateString.substring(6, 8).padStart(2, "0");
                    break;
            }
        }
    }

    return result;
};

/**
 * Removes properties with null or blank ("") values from an object.
 * @param {any} obj - The object from which to remove null or blank properties.
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function removeNullsOrBlanksFromObject(obj: any) {
    if (obj) {
        Object.keys(obj).forEach((k) => {
            if (obj && (obj[k] === "" || obj[k] == null)) {
                delete obj[k];
            }
        });
    }
}

/**
 * Converts an absolute date string to ISO format (YYYY-MM-DD) using a regex pattern.
 * Returns null if the input does not match the expected pattern.
 */
export const absoluteDateToISODate = z.preprocess((arg) => {
    if (typeof arg === "string") {
        const match = arg.match(DATE_PATTERN)?.groups;
        if (!match) {
            return null;
        }

        return `${match.year}-${match.month}-${match.day}`;
    }
    return null;
}, z.string());

/**
 * Converts hectares to square meters.
 * @param {number | null} ha - The area in hectares.
 * @returns {number} The area in square meters.
 */
export function toSquareMeters(ha: number | null): number {
    return (ha ?? 0) * 10000;
}

/**
 * Converts square meters to hectares.
 * @param {number | null} m2 - The area in square meters.
 * @returns {number} The area in hectares.
 */
export function toHectares(m2: number | null): number {
    return (m2 ?? 0) / 10000;
}

/**
 * Validates whether a date string falls within an optional min and/or max range.
 * Returns a formatted error message if invalid, otherwise null.
 * @param {Object} params - Parameters for validation.
 * @param {string} params.dateStr - The date string to validate.
 * @param {Date} [params.minDate] - The optional minimum allowed date.
 * @param {Date} [params.maxDate] - The optional maximum allowed date.
 * @param {(params: { min?: string; max?: string }) => string} [params.errorMessage] - Function to return a custom error message.
 * @returns {string | null} The error message if validation fails, otherwise null.
 */
export function validateDateInRange({
    dateStr,
    minDate,
    maxDate,
    errorMessage,
}: {
    dateStr: string;
    minDate?: Date;
    maxDate?: Date;
    errorMessage?: (params: { min?: string; max?: string }) => string;
}): string | null {
    if (!dateStr) return null;

    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return "Data non valida";

    let isInvalid = false;

    if (minDate && date < minDate) {
        isInvalid = true;
    }

    if (maxDate && date > maxDate) {
        isInvalid = true;
    }

    if (isInvalid && errorMessage) {
        return errorMessage({
            min: minDate ? dateToString(minDate) : undefined,
            max: maxDate ? dateToString(maxDate) : undefined,
        });
    }

    return null;
}

/**
 * Formats a given area (in square meters) as a string in hectares with four decimal places,
 * using a comma as the decimal separator.
 * @param {number | null} area - The area in square meters.
 * @returns {string} The formatted area in hectares.
 */
export function formatArea(area: number | null) {
    if (area) {
        return (area / 10000).toFixed(4).replace(".", ",");
    } else {
        return parseInt("0").toFixed(4).replace(".", ",");
    }
}
