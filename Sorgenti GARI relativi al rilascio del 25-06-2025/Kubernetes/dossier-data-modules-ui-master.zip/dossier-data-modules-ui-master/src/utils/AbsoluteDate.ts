export class AbsoluteDate {
    private static readonly DATE_PATTERN = "yyyyMMdd";
    private static readonly FORMATTER = new Intl.DateTimeFormat("en-CA", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
    });
    private readonly value: string;

    private constructor(value: string) {
        if (!value) throw new Error("Value cannot be null");
        this.value = value;
    }

    private static formatDate(date: Date): string {
        const [year, month, day] = [
            date.getFullYear(),
            ("0" + (date.getMonth() + 1)).slice(-2),
            ("0" + date.getDate()).slice(-2),
        ];
        return `${year}${month}${day}`;
    }

    private static parseDateString(date: string, delimiter: string): string {
        const parts = date.split(delimiter);
        if (delimiter === "/") {
            const [day, month, year] = parts;
            if (day.length !== 2 || month.length !== 2 || year.length !== 4) {
                throw new Error(
                    "Invalid date string format. Please use 'dd/MM/yyyy'.",
                );
            }
            return `${year}${month}${day}`;
        } else if (delimiter === "-") {
            const [year, month, day] = parts;
            if (day.length !== 2 || month.length !== 2 || year.length !== 4) {
                throw new Error(
                    "Invalid date string format. Please use 'yyyy-MM-dd'.",
                );
            }
            return `${year}${month}${day}`;
        } else {
            throw new Error(
                "Unsupported date string format. Please use 'dd/MM/yyyy' or 'yyyy-MM-dd'.",
            );
        }
    }

    public static of(date: Date | string | null): AbsoluteDate | null {
        if (date == null) return null;
        if (typeof date === "string") {
            let formattedDate: string;
            if (date.includes("/")) {
                formattedDate = this.parseDateString(date, "/");
            } else if (date.includes("-")) {
                formattedDate = this.parseDateString(date, "-");
            } else {
                throw new Error(
                    "Unsupported date string format. Please use 'dd/MM/yyyy' or 'yyyy-MM-dd'.",
                );
            }
            return new AbsoluteDate(formattedDate);
        } else {
            return new AbsoluteDate(this.formatDate(date));
        }
    }

    public static valueOf(val: string): AbsoluteDate | null {
        return this.of(val);
    }

    public getValue(): string {
        return this.value;
    }

    public toLocalDate(): Date {
        const year = parseInt(this.value.substring(0, 4), 10);
        const month = parseInt(this.value.substring(4, 6), 10) - 1;
        const day = parseInt(this.value.substring(6, 8), 10);
        return new Date(year, month, day);
    }

    public toString(): string {
        return this.value;
    }

    public equals(o: object): boolean {
        if (this === o) return true;
        if (!(o instanceof AbsoluteDate)) return false;
        return this.value === o.value;
    }

    public hashCode(): number {
        let hash = 0;
        for (let i = 0; i < this.value.length; i++) {
            const char = this.value.charCodeAt(i);
            hash = (hash << 5) - hash + char;
            hash |= 0; // Convert to 32bit integer
        }
        return hash;
    }
}
