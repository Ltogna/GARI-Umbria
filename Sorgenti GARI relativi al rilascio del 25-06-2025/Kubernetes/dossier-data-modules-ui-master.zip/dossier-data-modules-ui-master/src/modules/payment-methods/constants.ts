export const PAYMENT_METHODS_ID = "payment-methods";
export const PAYMENT_REGEX_KEY = "payment_regex_validation";
export const PAGE_SIZE = 6;
