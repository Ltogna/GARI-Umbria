<script setup lang="ts">
import TopBar from "@/components/TopBar.vue";
import TitleBar from "@/components/TitleBar.vue";
import AlertMessage from "@/components/AlertMessage.vue";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { computed, onMounted, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import { useMessageStore } from "@/stores/messageStore";
import { useI18n } from "vue-i18n";
import { PAYMENT_METHODS_ID } from "@/modules/payment-methods/constants";
import AnomaliesModal from "@/components/anomaly/AnomaliesModal.vue";
import { usePaymentMedhodStore } from "@/modules/payment-methods/stores/paymentMethods";
import { PaymentMethodsRouteName } from "@/modules/payment-methods/models/routes";
import { DDM_MODULE_ID } from "@/constants";
import usePermissions from "@/composables/usePermissions";

const route = useRoute();
const router = useRouter();

const store = usePaymentMedhodStore();
const messageStore = useMessageStore();
const { t } = useI18n();

const showAnomaliesModal = ref(false);
const { canEditPaymentsMethods } = usePermissions();

onMounted(async () => {
    document.title = t(`${DDM_MODULE_ID}.payment_method`);
    if (+route.params.partyId) {
        store.fetchBankAccountList(+route.params.partyId);
    } else {
        messageStore.setMessage({
            message: t(
                `${PAYMENT_METHODS_ID}.errors.unable_to_retrieve_party_registry_id`,
            ),
            level: "danger",
        });
    }
    const urlParams = new URLSearchParams(window.location.search);
    const backUrl = urlParams.get("backUrl");
    if (backUrl != null)
        sessionStorage.setItem(`${DDM_MODULE_ID}.backUrl`, backUrl);
});

function goToNewBankAccountForm() {
    router.push({
        name: PaymentMethodsRouteName.BANK_ACCOUNT_NEW,
        params: { partyId: +route.params.partyId },
    });
}

const showLeftTitle = computed(() => {
    return (
        router.currentRoute.value.name !==
        PaymentMethodsRouteName.BANK_ACCOUNT_LIST
    );
});

const target = computed(() => {
    return (
        store.bankAccounts.find((a) => a.id === +route.params.accountId) ?? null
    );
});

const hasAnomalies = computed(() => {
    if (!+route.params.accountId) return false;
    if (
        target.value?.anomalies?.DANGER?.length ||
        target.value?.anomalies?.WARN?.length ||
        target.value?.anomalies?.INFO?.length
    )
        return true;
    return false;
});

const anomaliesCount = computed(() => {
    if (!+route.params.accountId) return 0;
    return (
        (target.value?.anomalies?.DANGER?.length ?? 0) +
        (target.value?.anomalies?.WARN?.length ?? 0) +
        (target.value?.anomalies?.INFO?.length ?? 0)
    );
});

const buttonColor = computed(() => {
    if (target.value?.anomalies?.maxLevel === "DANGER") return "danger";
    else if (target.value?.anomalies?.maxLevel === "INFO") return "info";
    else return "warning";
});
</script>

<template>
    <div class="my-5 container payment-methods-module">
        <AnomaliesModal
            v-if="hasAnomalies"
            v-model="showAnomaliesModal"
            :anomalies="target?.anomalies ?? null"
        ></AnomaliesModal>
        <BiCard :extra-classes="['card-bg', 'rounded', 'no-after']">
            <template #card-header>
                <div class="px-4 card-header">
                    <TopBar :title="t(`${PAYMENT_METHODS_ID}.payment_method`)">
                        <template #actions>
                            <BiButton
                                v-if="
                                    router.currentRoute.value.name ==
                                        PaymentMethodsRouteName.BANK_ACCOUNT_DETAIL &&
                                    hasAnomalies
                                "
                                :color="buttonColor"
                                class="btn-me"
                                @click="showAnomaliesModal = true"
                            >
                                {{
                                    t(`${PAYMENT_METHODS_ID}.anomalies`) +
                                    ` (${anomaliesCount})`
                                }}
                            </BiButton>
                            <BiButton
                                v-if="
                                    router.currentRoute.value.name ==
                                        PaymentMethodsRouteName.BANK_ACCOUNT_LIST &&
                                    canEditPaymentsMethods
                                "
                                color="primary"
                                class="btn-me"
                                isOutlined
                                @click="goToNewBankAccountForm"
                            >
                                {{
                                    t(`${PAYMENT_METHODS_ID}.new_bank_account`)
                                }}
                            </BiButton>
                        </template>
                    </TopBar>
                </div>
            </template>
            <template #card-body>
                <AlertMessage
                    v-model="messageStore.open"
                    :level="messageStore.level"
                >
                    {{ messageStore.message }}
                </AlertMessage>
                <TitleBar
                    :leftBarTitle="t(`${PAYMENT_METHODS_ID}.payment_method`)"
                    :showLeftTitle="showLeftTitle"
                />
                <div class="mt-1 row">
                    <div class="p-3 col-md-3" v-if="showLeftTitle">
                        <router-view name="colLeft"></router-view>
                    </div>
                    <div
                        :class="{
                            'col-md-12': !showLeftTitle,
                            'col-md-9': showLeftTitle,
                        }"
                        class="p-4"
                    >
                        <router-view></router-view>
                    </div>
                </div>
            </template>
        </BiCard>
    </div>
</template>
