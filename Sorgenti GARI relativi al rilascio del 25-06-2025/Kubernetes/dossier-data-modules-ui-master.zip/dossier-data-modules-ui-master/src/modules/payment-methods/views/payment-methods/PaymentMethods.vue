<script setup lang="ts">
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import AlertMessage from "@/components/AlertMessage.vue";
import { useI18n } from "vue-i18n";
import { useDdmStore } from "@/stores/ddmStore";
import { useMessageStore } from "@/stores/messageStore";
import { onMounted, ref } from "vue";
import { getDefaultBankAccount } from "@/modules/payment-methods/resources/api/bankAccounts";
import { DDM_MODULE_ID } from "@/constants";
import { PAYMENT_METHODS_ID } from "@/modules/payment-methods/constants";
import { AnomalyLevelSchema } from "@/models/anomalyLevel";
import { getPortalBaseURL } from "@/utils/urlUtils";

const { t } = useI18n();

const ddmStore = useDdmStore();
const messageStore = useMessageStore();

const defaultBankAccount = ref();

onMounted(async () => {
    const url = new URL(window.location.href);
    if (url.searchParams.has("partyId") && url.searchParams.get("partyId")) {
        ddmStore.partyId = +url.searchParams.get("partyId")!;
        defaultBankAccount.value = await getDefaultBankAccount(
            ddmStore.partyId,
        );
        if (!defaultBankAccount.value)
            messageStore.setMessage({
                message: t(
                    `${PAYMENT_METHODS_ID}.errors.no_defauld_bank_account_found`,
                ),
                level: "info",
            });
    } else {
        messageStore.setMessage({
            message: t(
                `${DDM_MODULE_ID}.errors.unable_to_retrieve_party_registry_id`,
            ),
            level: "danger",
        });
    }
});

function goToBankAccountList() {
    if (ddmStore.partyId == null) return;
    const basePath = getPortalBaseURL(),
        detailUrl = `${basePath}/${DDM_MODULE_ID}/payment-methods/${ddmStore.partyId}/accounts/`,
        targetUrl = window.location.href.replace(window.location.origin, ""); // Get current url without domain
    window.location.assign(
        detailUrl + `?backUrl=${encodeURIComponent(targetUrl)}`,
    );
}

function goToBankAccountDetail(id: number) {
    if (ddmStore.partyId == null) return;

    const basePath = getPortalBaseURL(),
        detailUrl = `${basePath}/${DDM_MODULE_ID}/payment-methods/${ddmStore.partyId}/accounts/${id}/detail`,
        targetUrl = window.location.href.replace(window.location.origin, ""); // Get current url without domain
    window.location.assign(
        detailUrl + `?backUrl=${encodeURIComponent(targetUrl)}`,
    );
}
</script>

<template>
    <div class="container payment-methods-module">
        <div class="mt-3 row">
            <div class="my-3 col-12">
                <h4 class="fw-bold text-primary">
                    <BiIcon
                        icon="file-lines"
                        class="mx-2 fa-lg fa-solid"
                    ></BiIcon>
                    {{ t(`${PAYMENT_METHODS_ID}.payment_method`) }}
                </h4>
            </div>
            <div class="mx-2 my-3 col-12">
                <AlertMessage
                    v-model="messageStore.open"
                    :level="messageStore.level"
                >
                    {{ messageStore.message }}
                </AlertMessage>
                <BiTable
                    isRowHover
                    isResponsive
                    isHeaderLight
                    v-if="!!defaultBankAccount"
                >
                    <template #head>
                        <tr class="text-primary">
                            <th scope="col">
                                {{ t(`${PAYMENT_METHODS_ID}.area_network`) }}
                            </th>
                            <th scope="col">
                                {{
                                    t(
                                        `${PAYMENT_METHODS_ID}.iban_account_number`,
                                    )
                                }}
                            </th>
                            <th scope="col">
                                {{ t(`${PAYMENT_METHODS_ID}.institute`) }}
                            </th>
                            <th scope="col">
                                {{ t(`${PAYMENT_METHODS_ID}.branch`) }}
                            </th>
                            <th scope="col">
                                {{ t(`${PAYMENT_METHODS_ID}.anomalies`) }}
                            </th>

                            <th scope="col"></th>
                        </tr>
                    </template>
                    <template #body>
                        <tr class="align-middle">
                            <td>
                                <small>{{ defaultBankAccount.network }}</small>
                            </td>
                            <td>
                                <small>{{ defaultBankAccount.iban }}</small>
                            </td>
                            <td>
                                <small>{{ defaultBankAccount.bankName }}</small>
                            </td>
                            <td>
                                <small>{{
                                    defaultBankAccount.bankBranch
                                }}</small>
                            </td>
                            <td>
                                <BiIcon
                                    v-if="
                                        defaultBankAccount.anomalies?.DANGER &&
                                        defaultBankAccount.anomalies.maxLevel ==
                                            AnomalyLevelSchema.Enum.DANGER
                                    "
                                    icon="minus-circle"
                                    color="danger"
                                />
                                <BiIcon
                                    v-if="
                                        defaultBankAccount.anomalies?.WARN &&
                                        defaultBankAccount.anomalies.maxLevel ==
                                            AnomalyLevelSchema.Enum.WARN
                                    "
                                    icon="exclamation-triangle"
                                    color="warning"
                                />
                                <BiIcon
                                    v-if="
                                        defaultBankAccount.anomalies?.INFO &&
                                        defaultBankAccount.anomalies.maxLevel ==
                                            AnomalyLevelSchema.Enum.INFO
                                    "
                                    icon="circle-info"
                                    size="lg"
                                    color="info"
                                />
                            </td>

                            <td class="text-end">
                                <BiIconButton
                                    class="mx-1"
                                    icon="arrow-right"
                                    iconStyle="fas"
                                    color="primary"
                                    isOutlined
                                    @click="
                                        () =>
                                            goToBankAccountDetail(
                                                defaultBankAccount!.id,
                                            )
                                    "
                                />
                            </td>
                        </tr>
                    </template>
                </BiTable>
            </div>
            <div class="mt-5 text-center col-12">
                <BiButton
                    class="mx-1"
                    color="success"
                    @click="goToBankAccountList"
                >
                    {{ t(`${PAYMENT_METHODS_ID}.detail`) }}
                </BiButton>
            </div>
        </div>
    </div>
</template>
