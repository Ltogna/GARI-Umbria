import {
    type BankAccountResListModel,
    type BankAccount,
    BankAccountResSchema,
    makePaginateListSchema,
    type BankAccountCreate,
    type BankAccountUpdateReqModel,
} from "@/modules/payment-methods/models/bankAccounts";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { dossierDataModulesHTTPClient } from "@/resources/api/http";
import { useMessageStore } from "@/stores/messageStore";
import { ZodError } from "zod";
import { AnomalyResponseSchema, type Anomaly } from "@/models/anomalyLevel";

export const getBankAccountsList = async (
    partyId: number,
): Promise<BankAccountResListModel> => {
    const list: BankAccountResListModel = [];

    let nextKey: string | null = null;
    do {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const params: any = nextKey ? { nextKey: nextKey } : {};

        const res = await dossierDataModulesHTTPClient.getJson(
            makePaginateListSchema(BankAccountResSchema),
            `/api-priv/v1/payment-methods/parties/${partyId}/accounts`,
            { params },
        );
        if (res.errorType !== ErrorType.NONE) {
            if (
                res.errorType === ErrorType.OTHER &&
                res.err instanceof ZodError
            )
                console.error(res.err);
            else useMessageStore().handleApiErrorAndShowAlert(res);
            return [];
        }
        list.push(...res.data.records);
        nextKey = res.data.nextKey;
    } while (nextKey);

    return list;
};

export const getBankAccountById = async (
    partyId: number,
    accountId: number,
): Promise<BankAccount | null> => {
    const response = await dossierDataModulesHTTPClient.getJson(
        BankAccountResSchema,
        `/api-priv/v1/payment-methods/parties/${partyId}/accounts/${accountId}`,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data;
};

export const createNewBankAccount = async (
    partyId: number,
    newBankAccount: BankAccountCreate,
): Promise<BankAccount | null> => {
    const response = await dossierDataModulesHTTPClient.postJson(
        BankAccountResSchema,
        `/api-priv/v1/payment-methods/parties/${partyId}/accounts`,
        newBankAccount,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data;
};

export const updateBankAccount = async (
    partyId: number,
    accountId: number,
    update: BankAccountUpdateReqModel,
): Promise<BankAccount | null> => {
    const response = await dossierDataModulesHTTPClient.putJson(
        BankAccountResSchema,
        `/api-priv/v1/payment-methods/parties/${partyId}/accounts/${accountId}`,
        update,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data;
};

export const updateDayTo = async (
    partyId: number | null,
    accountId: number,
    dayTo: string,
): Promise<BankAccount | null> => {
    const response = await dossierDataModulesHTTPClient.putJson(
        BankAccountResSchema,
        `/api-priv/v1/payment-methods/parties/${partyId}/accounts/${accountId}/day-to`,
        { dayTo },
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data;
};

export const getPartyAnomalies = async (
    partyId: number,
): Promise<Anomaly | null> => {
    const response = await dossierDataModulesHTTPClient.getJson(
        AnomalyResponseSchema,
        `/api-priv/v1/payment-methods/parties/${partyId}/anomalies`,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data;
};

export const getAccountAnomalies = async (
    partyId: number,
    accountId: number,
): Promise<Anomaly | null> => {
    const response = await dossierDataModulesHTTPClient.getJson(
        AnomalyResponseSchema,
        `/api-priv/v1/payment-methods/parties/${partyId}/accounts/${accountId}/anomalies`,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data;
};

export const getDefaultBankAccount = async (
    partyId: number,
): Promise<BankAccount | null> => {
    const response = await dossierDataModulesHTTPClient.getJson(
        BankAccountResSchema.nullable(), // 204 -> no response
        `/api-priv/v1/payment-methods/parties/${partyId}/accounts/default`,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data ?? null;
};
