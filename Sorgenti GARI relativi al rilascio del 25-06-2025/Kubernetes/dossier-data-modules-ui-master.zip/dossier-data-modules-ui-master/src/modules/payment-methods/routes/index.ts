import { PaymentMethodsRouteName } from "@/modules/payment-methods/models/routes";
import { usePartyStore } from "@/modules/units/stores/party";
import { getParty } from "@/resources/api/party-public-api";
import type { NavigationGuard, RouteRecordRaw } from "vue-router";

const beforeEnter: NavigationGuard = async (to) => {
    try {
        const partyId = +to.params.partyId;
        if (!partyId) {
            throw "cuaa_not_found";
        }
        const party = await getParty(+to.params.partyId);
        if (!party) {
            throw "cuaa_not_found";
        }

        usePartyStore().party = party;

        return true;
    } catch (error) {
        console.error(error);
        if (typeof error === "string") {
            return {
                name: "NotFound",
                // preserve current path and remove the first char to avoid the target URL starting with `//`
                params: { pathMatch: to.path.substring(1).split("/") },
                // preserve existing query and hash if any
                query: { ...to.query, error },
                hash: to.hash,
            };
        }
        return {
            name: "NotFound",
            // preserve current path and remove the first char to avoid the target URL starting with `//`
            params: { pathMatch: to.path.substring(1).split("/") },
            // preserve existing query and hash if any
            query: to.query,
            hash: to.hash,
        };
    }
};

const PaymentMethods = () =>
    import(
        "@/modules/payment-methods/views/payment-methods/PaymentMethods.vue"
    );

const DynamicDocumentWrapper = () =>
    import(
        "@/modules/payment-methods/components/dynamic-document/DynamicDocumentWrapper.vue"
    );

const LeftSidebar = () =>
    import("@/modules/payment-methods/components/LeftSidebar.vue");

const paymentMethodsRoutes: RouteRecordRaw[] = [
    {
        path: "/payment-methods/",
        name: PaymentMethodsRouteName.PAYMENT_METHODS,
        component: PaymentMethods,
    },
    {
        path: "/payment-methods/:partyId/",
        beforeEnter,
        name: PaymentMethodsRouteName.PAYMENT_METHODS_MANAGEMENT,
        redirect: {
            name: PaymentMethodsRouteName.BANK_ACCOUNT_LIST,
            replace: true,
        },
        component: () =>
            import(
                "@/modules/payment-methods/views/payment-methods/PaymentMethodsManagement.vue"
            ),
        children: [
            {
                path: "accounts/",
                name: PaymentMethodsRouteName.BANK_ACCOUNT_LIST,
                component: () =>
                    import(
                        "@/modules/payment-methods/components/BankAccountList.vue"
                    ),
            },
            {
                path: "accounts/filter",
                name: PaymentMethodsRouteName.BANK_ACCOUNT_FILTER,
                component: () =>
                    import(
                        "@/modules/payment-methods/components/FilterBankAccounts.vue"
                    ),
            },
            {
                path: "accounts/new/",
                name: PaymentMethodsRouteName.BANK_ACCOUNT_NEW,
                component: () =>
                    import(
                        "@/modules/payment-methods/components/NewBankAccountForm.vue"
                    ),
            },
            {
                path: "accounts/:accountId/detail/",
                name: PaymentMethodsRouteName.BANK_ACCOUNT_DETAIL,
                components: {
                    colLeft: LeftSidebar,
                    default: () =>
                        import(
                            "@/modules/payment-methods/components/BankAccountDetail.vue"
                        ),
                },
            },
            {
                path: "accounts/:accountId/detail/doc/:docType",
                components: {
                    colLeft: LeftSidebar,
                    default: () =>
                        import(
                            "@/modules/payment-methods/components/dynamic-document/DynamicDocumentRouteView.vue"
                        ),
                },
                children: [
                    {
                        path: "",
                        name: PaymentMethodsRouteName.EDIT_DOC,
                        component: DynamicDocumentWrapper,
                    },
                    {
                        path: "new",
                        name: PaymentMethodsRouteName.NEW_MULTIPLE_DOC,
                        component: DynamicDocumentWrapper,
                    },
                    {
                        path: "edit/:docId",
                        name: PaymentMethodsRouteName.EDIT_MULTIPLE_DOC,
                        component: DynamicDocumentWrapper,
                    },
                ],
            },
        ],
    },
];

export default paymentMethodsRoutes;
