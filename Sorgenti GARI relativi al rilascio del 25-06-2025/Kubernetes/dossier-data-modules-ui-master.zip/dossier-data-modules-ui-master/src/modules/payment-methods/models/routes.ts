export enum PaymentMethodsRouteName {
    PAYMENT_METHODS = `pm:paymentMethods`,
    PAYMENT_METHODS_MANAGEMENT = `pm:paymentMethodsManagement`,
    BANK_ACCOUNT_LIST = `pm:bankAccountList`,
    BANK_ACCOUNT_FILTER = `pm:bankAccountFilter`,
    BANK_ACCOUNT_DETAIL = `pm:bankAccountDetail`,
    BANK_ACCOUNT_NEW = `pm:bankAccountNew`,
    EDIT_DOC = `${BANK_ACCOUNT_DETAIL}:doc`,
    NEW_MULTIPLE_DOC = `${BANK_ACCOUNT_DETAIL}:multiple:doc:new`,
    EDIT_MULTIPLE_DOC = `${BANK_ACCOUNT_DETAIL}:multiple:doc:edit`,
}
