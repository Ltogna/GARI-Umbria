import { z } from "zod";
import { AnomalyResponseSchema } from "@/models/anomalyLevel";

export enum NetworksEnum {
    SEPA = "SEPA",
    SWIFT = "SWIFT",
}

export enum ActiveEnum {
    only_active = "only_active",
    not_active = "not_active",
}
export interface BankAccountFilter {
    active: ActiveEnum;
    area_network: NetworksEnum;
    iban_account_number: string;
    description: string;
}

export const BankAccountResSchema = z.object({
    id: z.number(),
    partyId: z.number(),
    network: z.nativeEnum(NetworksEnum),
    iban: z.string(),
    swiftBic: z.string().nullish(),
    bicExtraSepa: z.string().nullish(),
    bankCountry: z.string().nullish(),
    bankName: z.string().nullish(),
    bankBranch: z.string().nullish(),
    description: z.string().nullish(),
    defaultBankAccount: z.boolean().optional(),
    dayFrom: z.string(),
    dayTo: z.string().nullish(),
    active: z.boolean().default(false),
    anomalies: z.optional(AnomalyResponseSchema),
});

export const BankAccountResListSchema = z.array(BankAccountResSchema);
export function makePaginateListSchema<ItemType extends z.ZodTypeAny>(
    itemSchema: ItemType,
) {
    return z.object({
        count: z.number(),
        records: z.array(itemSchema),
        nextKey: z.string().nullable(),
    });
}

export const InfiniteListResultsBankAccountResSchema = z.object({
    count: z.number(),
    records: z.array(BankAccountResSchema),
    nextKey: z.string(),
});

export const BankAccountCreateResSchema = z.object({
    description: z.string().nullish(),
    defaultBankAccount: z.boolean().optional(),
    network: z.nativeEnum(NetworksEnum).nullish(),
    iban: z.string().nullish(),
    swiftBic: z.string().nullish(),
    bicExtraSepa: z.string().nullish(),
    bankCountry: z.string().nullish(),
    bankName: z.string().nullish(),
    bankBranch: z.string().nullish(),
    dayFrom: z.string().nullish(),
});

export const BankAccountUpdateReqSchema = z.object({
    description: z.string().nullish(),
    defaultBankAccount: z.boolean().optional(),
});

export type BankAccount = z.infer<typeof BankAccountResSchema>;
export type BankAccountResListModel = z.infer<typeof BankAccountResListSchema>;
export type BankAccountCreate = z.infer<typeof BankAccountCreateResSchema>;
export type BankAccountUpdateReqModel = z.infer<
    typeof BankAccountUpdateReqSchema
>;
