import { z } from "zod";
import { ConfigResponseSchema } from "@/models/config";

export const RegexConfigResponseSchema = ConfigResponseSchema.extend({
    configuration: z.object({ regexes: z.string().array() }),
});

export type RegexConfigResponse = z.infer<typeof RegexConfigResponseSchema>;
