<script setup lang="ts">
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import { useI18n } from "vue-i18n";
import { useDocumentTypeStore } from "@/stores/documentTypes";
import { onMounted } from "vue";
import { useRoute } from "vue-router";
import { PAYMENT_METHODS_ID } from "@/modules/payment-methods/constants";
import { PaymentMethodsRouteName } from "../models/routes";

const documentTypeStore = useDocumentTypeStore();

const { t } = useI18n();
const route = useRoute();

onMounted(async () => {
    const accountId = route.params.accountId as string;
    await documentTypeStore.getDocumentTypes(accountId);
});
</script>
<template>
    <BiAccordion
        v-if="documentTypeStore.documentTypes.length"
        colorBgHeader="primary"
        colorHeader="white"
        bodyExtraClass="p-0"
        :title="t(`${PAYMENT_METHODS_ID}.documents`)"
        headerArrowExtraClass="py-0"
    >
        <div class="it-list-wrapper">
            <ul class="pt-2 pb-2 border it-list ps-3">
                <li
                    v-for="docType in documentTypeStore.documentTypes"
                    :key="docType.definitionCode"
                >
                    <RouterLink
                        :to="{
                            name: PaymentMethodsRouteName.EDIT_DOC,
                            params: { docType: docType.definitionCode },
                        }"
                        replace
                        :class="'text-decoration-none d-flex justify-content-between py-2'"
                        :active-class="'fw-semibold text-black'"
                    >
                        <span>{{ docType.definitionCodeI18n }}</span>
                        <div class="pe-2">
                            <BiIcon
                                v-if="!docType.docPresent"
                                size="lg"
                                :icon="'pen-circle'"
                                :icon-style="'regular'"
                                :color="'info'"
                                class="underline ms-auto"
                            />
                            <BiIcon
                                v-else
                                size="lg"
                                :icon="'circle-check'"
                                :icon-style="'regular'"
                                :color="'success'"
                                class="underline ms-auto"
                            />
                        </div>
                    </RouterLink>
                </li>
            </ul>
        </div>
    </BiAccordion>
</template>
