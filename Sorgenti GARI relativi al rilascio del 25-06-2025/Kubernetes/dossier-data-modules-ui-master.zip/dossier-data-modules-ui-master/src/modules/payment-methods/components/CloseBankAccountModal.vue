<script setup lang="ts">
import { ref, computed, defineEmits, defineProps } from "vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { useI18n } from "vue-i18n";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import { PAYMENT_METHODS_ID } from "@/modules/payment-methods/constants";

const { t } = useI18n();

const props = defineProps<{
    modelValue: boolean;
    dayFrom: Date;
}>();

const emits = defineEmits<{
    (e: "update:modelValue", val: boolean): void;
    (e: "update:dayTo", val: string): void;
}>();

const model = computed({
    get() {
        return props.modelValue;
    },
    set(value: boolean) {
        emits("update:modelValue", value);
    },
});

const maxAllowedDay = computed(() => {
    const date = new Date();
    return date.setDate(date.getDate() - 1);
});
const dayTo = ref("");
</script>
<template>
    <BiModal
        :title="t(`${PAYMENT_METHODS_ID}.closing_bank_account`)"
        size="lg"
        v-model="model"
    >
        <template #body>
            <p>{{ t(`${PAYMENT_METHODS_ID}.set_end_validity_date`) }}</p>
            <BiDatepicker
                class="mt-5"
                :label="t(`${PAYMENT_METHODS_ID}.end_validity_date`)"
                :min="dayFrom"
                :max="maxAllowedDay"
                v-model="dayTo"
            />
            <p class="mt-3">
                <strong class="text-danger">
                    {{ t(`${PAYMENT_METHODS_ID}.day_to_mandatory_condition`) }}
                </strong>
            </p>
        </template>
        <template #footer>
            <div class="vw-100 d-flex justify-content-center">
                <BiButton
                    class="me-2"
                    color="primary"
                    isOutlined
                    @click="model = false"
                >
                    {{ t(`${PAYMENT_METHODS_ID}.close`) }}
                </BiButton>
                <BiButton color="success" @click="emits('update:dayTo', dayTo)">
                    {{ t(`${PAYMENT_METHODS_ID}.confirm`) }}
                </BiButton>
            </div>
        </template>
    </BiModal>
</template>
