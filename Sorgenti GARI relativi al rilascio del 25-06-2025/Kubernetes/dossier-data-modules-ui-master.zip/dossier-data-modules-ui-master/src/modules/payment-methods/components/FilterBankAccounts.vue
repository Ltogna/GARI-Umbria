<script setup lang="ts">
import { useI18n } from "vue-i18n";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import { computed, ref } from "vue";
import {
    NetworksEnum,
    ActiveEnum,
} from "@/modules/payment-methods/models/bankAccounts";
import { useMessageStore } from "@/stores/messageStore";
import { PAYMENT_METHODS_ID } from "@/modules/payment-methods/constants";
import { usePaymentMedhodStore } from "@/modules/payment-methods/stores/paymentMethods";
import { useRoute, useRouter } from "vue-router";
import { PaymentMethodsRouteName } from "@/modules/payment-methods/models/routes";

const { t } = useI18n();

const route = useRoute();
const router = useRouter();

const store = usePaymentMedhodStore();
const messageStore = useMessageStore();

const filterForm = ref({ ...store.bankAccountFilter });

const bankAccounts = Object.keys(ActiveEnum).map((key) => {
    return {
        id: key,
        text: t(`${PAYMENT_METHODS_ID}.filter.` + key),
    };
});

const areaNetwork = Object.keys(NetworksEnum).map((key) => {
    return {
        id: key,
        text: t(`${PAYMENT_METHODS_ID}.filter.` + key),
    };
});

const atLeastOneField = computed(() => {
    return Object.keys(filterForm.value).some((key) => {
        if (Array.isArray((filterForm.value as Record<string, unknown>)[key])) {
            const valid = !!(
                (filterForm.value as Record<string, unknown>)[key] as unknown[]
            ).length;
            return valid;
        }
        return !!(filterForm.value as Record<string, unknown>)[key];
    });
});

function resetFilters() {
    filterForm.value = { active: ActiveEnum.only_active };
}

function applyFilters() {
    store.bankAccountFilter = filterForm.value;
    !store.getFilteredBankAccounts.length
        ? messageStore.setMessage({
              message: t(
                  `${PAYMENT_METHODS_ID}.errors.no_filtered_bank_account_found`,
              ),
              level: "warning",
          })
        : backToList();
}

function backToList() {
    router.push({
        name: PaymentMethodsRouteName.BANK_ACCOUNT_LIST,
        params: { partyId: route.params.partyId },
        query: { backUrl: "" },
    });
}
</script>
<template>
    <div>
        <h4 class="text-primary">
            {{ t(`${PAYMENT_METHODS_ID}.filter_bank_accounts`) }}
        </h4>
        <div class="row mt-5">
            <div class="col-6 field-required">
                <BiSelect
                    :items="bankAccounts"
                    :label="
                        t(`${PAYMENT_METHODS_ID}.bank_accounts_visualisation`)
                    "
                    v-model="filterForm.active"
                />
            </div>
            <div class="col-6">
                <BiInput
                    :label="t(`${PAYMENT_METHODS_ID}.iban_account_number`)"
                    v-model="filterForm.iban_account_number"
                />
            </div>
        </div>
        <div class="row my-5">
            <div class="col-6">
                <BiSelect
                    :items="areaNetwork"
                    :label="t(`${PAYMENT_METHODS_ID}.area_network`)"
                    v-model="filterForm.area_network"
                />
            </div>
            <div class="col-6">
                <BiInput
                    :label="t(`${PAYMENT_METHODS_ID}.description`)"
                    v-model="filterForm.description"
                />
            </div>
        </div>
        <!-- Buttons  -->
        <div class="row my-5 pt-5">
            <div class="col-4 d-flex justify-content-start">
                <BiButton color="primary" isOutlined @click="backToList()">
                    <BiIcon icon="arrow-left" class="me-1" />
                    {{ t(`${PAYMENT_METHODS_ID}.back_to_list`) }}
                </BiButton>
            </div>
            <div class="col-8 d-flex justify-content-start">
                <BiButton
                    color="primary"
                    class="me-2"
                    isOutlined
                    @click="resetFilters"
                >
                    {{ t(`${PAYMENT_METHODS_ID}.reset`) }}
                </BiButton>
                <BiButton
                    :is-disabled="!atLeastOneField"
                    color="success"
                    @click="applyFilters"
                >
                    {{ t(`${PAYMENT_METHODS_ID}.apply_filters`) }}
                </BiButton>
            </div>
        </div>
        <!-- End buttons -->
    </div>
</template>

<style lang="scss">
.field-required label::after {
    color: red;
    content: " *";
}
</style>
