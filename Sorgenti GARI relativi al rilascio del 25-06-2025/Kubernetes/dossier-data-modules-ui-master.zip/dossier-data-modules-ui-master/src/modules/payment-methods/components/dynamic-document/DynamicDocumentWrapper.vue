<script lang="ts" setup>
import useEmitter from "@/composables/useEmitter";
import { type DocumentTypeModel } from "@/models/documentTypes";
import type {
    DocumentDataRecordModel,
    DynamiDocumentDataModel,
    DynamiDocumentMapModel,
    DynamiDocumentModel,
} from "@/models/dynamicDocuments";
import { getDocumentTypeByDefinitionCode } from "@/resources/api/documentTypes";
import {
    createDocument,
    deleteDocument,
    getDocument,
    getDocuments,
    updateDocument,
} from "@/resources/api/dynamicDocuments";
import { useDocumentTypeStore } from "@/stores/documentTypes";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities";
import type { DocumentSchemaType } from "@abaco/dynamic-documents/src/resources/models";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import isEqual from "lodash/isEqual";
import { computed, ref, toRaw, watch } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";
import DynamicDocumentForm from "./DynamicDocumentForm.vue";
import DynamicDocumentList from "./DynamicDocumentList.vue";
import { PaymentMethodsRouteName } from "@/modules/payment-methods/models/routes";

import { useMessageStore } from "@/stores/messageStore";
import usePermissions from "@/composables/usePermissions";
import type { BankAccount } from "@/modules/payment-methods/models/bankAccounts";
import { PAYMENT_METHODS_ID } from "@/modules/payment-methods/constants";

import { getAccountAnomalies } from "@/modules/payment-methods/resources/api/bankAccounts";
import { usePaymentMedhodStore } from "@/modules/payment-methods/stores/paymentMethods";

enum ActionType {
    CREATE = "CREATE",
    EDIT = "EDIT",
    DELETE = "DELETE",
}

const { t } = useI18n();
const route = useRoute();
const router = useRouter();
const documentTypeStore = useDocumentTypeStore();
const emitter = useEmitter();
const store = usePaymentMedhodStore();
const { canEditPaymentsMethods } = usePermissions();

const showModal = ref(false);
const docType = ref<DocumentTypeModel | null>(null);

const currentDefinition = ref<DocumentSchemaType | null>(null);
const currentDocument = ref<DynamiDocumentDataModel>({});
let currentDocumentPrevData: DynamiDocumentDataModel = {};

const documentList = ref<DynamiDocumentModel[]>([]);
const modalBodyText = ref("");
const action = ref<ActionType>(ActionType.CREATE);

const processingDocument = ref<DynamiDocumentMapModel>();
const loading = ref<boolean>(true);
const nextKey = ref<string | null>(null);
const totalCounts = ref<number>(0);

const confirmAction = ref<boolean>(false);
const curBankAccount = computed(() => {
    return store.bankAccounts.find(
        (a: BankAccount) => a.id == +route.params.accountId,
    );
});

const canEdit = computed(() => {
    return canEditPaymentsMethods && curBankAccount.value?.active;
});

function goBack() {
    if (
        route.name === PaymentMethodsRouteName.NEW_MULTIPLE_DOC ||
        route.name === PaymentMethodsRouteName.EDIT_MULTIPLE_DOC
    ) {
        router.replace({ name: PaymentMethodsRouteName.EDIT_DOC });
    } else {
        router.replace({ name: PaymentMethodsRouteName.BANK_ACCOUNT_DETAIL });
    }
}

function onDocumentChanged(changes: DocumentDataRecordModel) {
    if ("data" in currentDocumentPrevData && currentDocumentPrevData.data) {
        if (!isEqual(currentDocumentPrevData.data, changes)) {
            emitter.emit("is:dirty", true);
        } else {
            emitter.emit("is:dirty", false);
        }
    }
}

const isMultiple = computed(() => {
    if (route.name === PaymentMethodsRouteName.NEW_MULTIPLE_DOC) {
        return false;
    }
    if (route.name === PaymentMethodsRouteName.EDIT_MULTIPLE_DOC) {
        return false;
    }
    return docType.value?.multiple ?? false;
});

async function loadDocuments(append = false) {
    if (docType.value) {
        const accountId = route.params.accountId as string;
        const partyId = route.params.partyId as string;
        const defCode = docType.value.definitionCode as string;
        const resp = await getDocuments(
            partyId,
            accountId,
            defCode,
            nextKey.value,
        );
        if (resp.errorType === ErrorType.NONE) {
            if (append) {
                documentList.value = [
                    ...documentList.value,
                    ...resp.data.records,
                ];
            } else {
                documentList.value = resp.data.records;
            }
            nextKey.value = resp.data.nextKey;
            totalCounts.value = resp.data.count;
        } else {
            useMessageStore().handleApiErrorAndShowAlert(resp);
        }
    }
}

async function recalcAnomalies() {
    const partyId = route.params.partyId as string | undefined;
    const accountId = route.params.accountId as string | undefined;
    if (partyId && accountId) {
        const anomalies = await getAccountAnomalies(+partyId, +accountId);
        if (anomalies && curBankAccount.value)
            curBankAccount.value.anomalies = anomalies;
    }
}

watch(
    () => route.params,
    async (params) => {
        loading.value = true;
        currentDocument.value = {};

        // reset valuse
        documentList.value = [];
        nextKey.value = null;
        totalCounts.value = 0;
        const accountId = params.accountId as string | undefined;
        const partyId = params.partyId as string | undefined;
        const docTypeParam = params.docType as string | undefined;

        if (accountId && partyId && docTypeParam) {
            const docResp = await getDocumentTypeByDefinitionCode(docTypeParam);
            if (docResp.errorType === ErrorType.NONE) {
                currentDefinition.value = docResp.data;
            } else {
                useMessageStore().handleApiErrorAndShowAlert(docResp);
            }

            await documentTypeStore.getDocumentTypes(accountId);
            if (!documentTypeStore.error) {
                docType.value =
                    documentTypeStore.documentTypes.find(
                        (v) => v.definitionCode === docTypeParam,
                    ) ?? null;
                if (docType.value && docType.value.docPresent) {
                    await loadDocuments();
                    const docId = params.docId as string | undefined;
                    if (
                        documentList.value.length &&
                        (!docType.value.multiple || docId)
                    ) {
                        const docResp = await getDocument(
                            partyId,
                            accountId,
                            docId ?? documentList.value[0].documentId,
                        );
                        if (docResp.errorType === ErrorType.NONE) {
                            currentDocument.value = docResp.data;
                        } else {
                            useMessageStore().handleApiErrorAndShowAlert(
                                docResp,
                            );
                        }
                    }
                }
            }
        }

        currentDocumentPrevData = structuredClone(toRaw(currentDocument.value));
        emitter.emit("is:dirty", false);
        loading.value = false;
    },
    { immediate: true },
);

async function handleModalClose() {
    // if (action.value === ActionType.DELETE || action.value === ActionType.EDIT) {
    //   if (route.name === "cll:group-edit-doc" && docType.value?.multiple) {
    //     await loadDocuments();
    //   } else if (
    //     route.name === "cll:group-edit-doc" &&
    //     confirmAction.value === true
    //   ) {
    //     router.replace({ name: "cll:group-edit-doc" });
    //   } else if (
    //     route.name === "cll:group-edit-multiple-doc" &&
    //     confirmAction.value === true
    //   ) {
    //     router.replace({ name: "cll:group-edit-multiple-doc" });
    //   } else {
    //     goBack();
    //   }
    //   confirmAction.value = false;
    // }

    if (confirmAction.value) {
        switch (action.value) {
            case ActionType.CREATE:
                break;
            case ActionType.EDIT:
                goBack();
                break;
            case ActionType.DELETE:
                if (
                    route.name === PaymentMethodsRouteName.EDIT_DOC &&
                    docType.value?.multiple
                ) {
                    await loadDocuments();
                } else {
                    goBack();
                }
                break;
        }
    }
    recalcAnomalies();
    confirmAction.value = false;
}

function handleDismissModal() {
    processingDocument.value = undefined;
    showModal.value = false;
}

async function handleConfirmAction() {
    const partyId = route.params.partyId as string;
    const accountId = route.params.accountId as string;
    if (processingDocument.value === undefined) {
        return;
    }
    const { documentId } = processingDocument.value;
    if (typeof documentId !== "number") {
        return;
    }
    switch (action.value) {
        case ActionType.CREATE:
            break;
        case ActionType.EDIT:
            {
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                const resp = await updateDocument(
                    partyId,
                    accountId,
                    documentId.toString(),
                    {
                        fields: processingDocument.value.data,
                    },
                );
                await documentTypeStore.getDocumentTypes(accountId, true);
                currentDocumentPrevData = structuredClone(
                    toRaw(currentDocument.value),
                );
                emitter.emit("is:dirty", false);
                // useNotificationStore().setMessage(resp);
            }
            break;
        case ActionType.DELETE:
            {
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                const resp = await deleteDocument(
                    partyId,
                    accountId,
                    documentId,
                );
                await documentTypeStore.getDocumentTypes(accountId, true);
                currentDocumentPrevData = structuredClone(
                    toRaw(currentDocument.value),
                );
                emitter.emit("is:dirty", false);
                confirmAction.value = true;
                // useNotificationStore().setMessage(resp);
            }
            break;
    }
    showModal.value = false;
}

async function onCreateDocument(documentData: DynamiDocumentMapModel) {
    action.value = ActionType.CREATE;
    processingDocument.value = documentData;
    const accountId = route.params.accountId as string;
    const partyId = route.params.partyId as string;

    const resp = await createDocument(partyId, accountId, documentData);
    await documentTypeStore.getDocumentTypes(accountId, true);
    showModal.value = false;
    currentDocumentPrevData = structuredClone(toRaw(currentDocument.value));
    emitter.emit("is:dirty", false);
    if (resp) {
        recalcAnomalies();
        goBack();
    }
}

function onConfirmUpdate(documentData: DynamiDocumentMapModel) {
    action.value = ActionType.EDIT;
    processingDocument.value = documentData;
    modalBodyText.value = t(
        `${PAYMENT_METHODS_ID}.dynamic_docs.form.confirmMessage.EDIT`,
    );
    modalTitle.value = [
        t(`${PAYMENT_METHODS_ID}.dynamic_docs.form.updateConfirm`),
        docType.value?.definitionCodeI18n ?? "",
    ].join(" ");
    showModal.value = true;
}

async function onConfirmDelete(documentData: DynamiDocumentMapModel) {
    action.value = ActionType.DELETE;
    processingDocument.value = documentData;
    modalBodyText.value = t(
        `${PAYMENT_METHODS_ID}.dynamic_docs.form.confirmMessage.DELETE`,
    );
    modalTitle.value = [
        t(`${PAYMENT_METHODS_ID}.dynamic_docs.form.deleteConfirm`),
        docType.value?.definitionCodeI18n ?? "",
    ].join(" ");
    showModal.value = true;
}

const modalTitle = ref<string>("");

async function onLoadMore() {
    await loadDocuments(true);
}
</script>

<template>
    <template v-if="docType && currentDefinition">
        <DynamicDocumentForm
            v-if="!isMultiple && !loading"
            :docDefinition="currentDefinition"
            v-model="currentDocument"
            :readonly="!canEdit"
            @create-document="onCreateDocument"
            @update-document="onConfirmUpdate"
            @delete-document="onConfirmDelete"
            @change-document="onDocumentChanged"
        />
        <DynamicDocumentList
            v-if="isMultiple && !loading"
            :documentList="documentList"
            :docType="docType"
            :docDefinition="currentDefinition"
            :readonly="!canEdit"
            :showLoadMore="!!nextKey"
            @delete-document="onConfirmDelete"
            @load-more="onLoadMore"
        />
    </template>

    <BiModal
        size="lg"
        ariaLabelledby="confirm-modal-document"
        :id="getUUID()"
        v-model="showModal"
        :title="modalTitle"
        data-keyboard="true"
        data-backdrop="static"
        extra-body-class="pt-5"
        @hidden-modal="handleModalClose()"
    >
        <template #body> {{ modalBodyText }} </template>
        <template #footer>
            <div
                class="customer-land-link__modal-footer text-center pt-5 pb-5 w-100"
            >
                <BiButton
                    @click="handleDismissModal"
                    is-outlined
                    color="primary"
                >
                    {{ t(`${PAYMENT_METHODS_ID}.cancel`) }}
                </BiButton>

                <BiButton
                    v-if="docType?.docPresent && action === ActionType.DELETE"
                    @click="handleConfirmAction"
                    color="danger"
                >
                    {{
                        t(
                            `${PAYMENT_METHODS_ID}.dynamic_docs.form.deleteConfirm`,
                        )
                    }}
                </BiButton>
                <BiButton
                    @click="handleConfirmAction"
                    color="success"
                    v-if="
                        !docType?.docPresent ||
                        (docType?.docPresent && action === ActionType.EDIT)
                    "
                >
                    {{
                        t(
                            `${PAYMENT_METHODS_ID}.dynamic_docs.form.updateConfirm`,
                        )
                    }}
                </BiButton>
            </div>
        </template>
    </BiModal>
</template>

<style lang="scss">
.customer-land-link {
    &__modal-footer {
        button {
            &:not(:last-child) {
                margin-right: 16px;
            }
        }
    }
}
</style>
@/modules/payment-methods/models/bankAccounts@/modules/payment-methods/resources/api/bankAccounts@/modules/payment-methods/stores/paymentMethods
