<script setup lang="ts">
import { ref, onMounted, computed } from "vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiToggle from "@abaco/bootstrap-italia-components/src/components/form/BiToggle.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";
import { PaymentMethodsRouteName } from "@/modules/payment-methods/models/routes";
import type {
    BankAccount,
    BankAccountUpdateReqModel,
} from "@/modules/payment-methods/models/bankAccounts";
import {
    updateBankAccount,
    updateDayTo,
} from "@/modules/payment-methods/resources/api/bankAccounts";
import CloseBankAccountModal from "./CloseBankAccountModal.vue";
import { useMessageStore } from "@/stores/messageStore";
import { convertToDate } from "@/utils/utils";
import { format } from "date-fns";
import { CLIENT_DATE_FORMAT } from "@/constants";
import ConfirmModal from "@/components/ConfirmModal.vue";
import usePermissions from "@/composables/usePermissions";
import { PAYMENT_METHODS_ID } from "@/modules/payment-methods/constants";

import { usePaymentMedhodStore } from "@/modules/payment-methods/stores/paymentMethods";

const { t } = useI18n();

const route = useRoute();
const router = useRouter();
const { canEditPaymentsMethods } = usePermissions();
const store = usePaymentMedhodStore();
const messageStore = useMessageStore();

const update = ref<Partial<BankAccountUpdateReqModel>>({});

const editable = computed(() => {
    return canEditPaymentsMethods && bankAccountDetail.value?.active;
});

const bankAccountDetail = ref<Partial<BankAccount>>({});

const flShowSuccessMessage = computed(() => {
    return (
        sessionStorage.getItem(`${PAYMENT_METHODS_ID}.showSuccessMessage`) ===
        "1"
    );
});

function goToBankAccountList(showSuccessMessage: boolean) {
    if (showSuccessMessage)
        sessionStorage.setItem(`${PAYMENT_METHODS_ID}.showSuccessMessage`, "1");
    router.push({
        name: PaymentMethodsRouteName.BANK_ACCOUNT_LIST,
        params: { partyId: +route.params.partyId },
    });
}

onMounted(async () => {
    if (+route.params.accountId && +route.params.partyId) {
        if (flShowSuccessMessage.value) {
            messageStore.open = false;
            await new Promise((r) => setTimeout(r, 200));
            messageStore.setMessage({
                message: t(`${PAYMENT_METHODS_ID}.success_action`),
                level: "success",
            });
            sessionStorage.setItem(
                `${PAYMENT_METHODS_ID}.showSuccessMessage`,
                "0",
            );
        }
        let targetAccount: BankAccount | null =
            store.bankAccounts.find(
                (account) => account.id === +route.params.accountId,
            ) ?? null;
        if (!targetAccount) {
            targetAccount =
                (await store.fetchBankAccountById(
                    +route.params.partyId,
                    +route.params.accountId,
                )) ?? null;
            if (targetAccount) {
                store.updateBankAccountList(targetAccount);
            }
        }
        if (!targetAccount) {
            messageStore.setMessage({
                message: t(`${PAYMENT_METHODS_ID}.errors.account_not_found`),
                level: "danger",
            });
            return;
        }
        bankAccountDetail.value = targetAccount;
        update.value = {
            description: bankAccountDetail.value.description,
            defaultBankAccount: bankAccountDetail.value.defaultBankAccount,
        };
    } else {
        messageStore.setMessage({
            message: t(
                `${PAYMENT_METHODS_ID}.errors.unable_to_retrieve_party_registry_id`,
            ),
            level: "danger",
        });
    }
});

const changesPending = computed(() => {
    if (!bankAccountDetail.value) return false;
    if (!bankAccountDetail.value.defaultBankAccount) {
        if (update.value.defaultBankAccount) return true;
    } else if (bankAccountDetail.value.defaultBankAccount) {
        if (!update.value.defaultBankAccount) return true;
    }
    if (!bankAccountDetail.value.description) {
        if (update.value.description) return true;
    } else if (bankAccountDetail.value.description) {
        if (!update.value.description) return true;
        if (update.value.description !== bankAccountDetail.value.description)
            return true;
    }
    return false;
});

async function closeAccount(
    partyId: number | null,
    accountId: number,
    dayTo: string,
) {
    if (!+route.params.partyId) return;
    if (!dayTo) return;
    store.loadingCounter++;
    const resp = await updateDayTo(
        partyId,
        accountId,
        dayTo.split("-").join(""),
    );
    if (resp) {
        store.updateBankAccountList(resp);
    }
    store.loadingCounter--;
    goToBankAccountList(true);
}

const isCloseShown = ref(false);

const isEditShown = ref(false);

function showCloseModal() {
    isCloseShown.value = !isCloseShown.value;
}

async function confirmOrShowModal() {
    if (
        update.value.defaultBankAccount === true &&
        bankAccountDetail.value?.defaultBankAccount === false
    ) {
        isEditShown.value = true;
    } else {
        if (!+route.params.partyId) return;
        store.loadingCounter++;
        const resp = await updateBankAccount(
            +route.params.partyId,
            +route.params.accountId,
            update.value,
        );
        store.loadingCounter--;
        if (resp) {
            store.updateBankAccountList(resp);
            goToBankAccountList(true);
        }
    }
}

async function editBankAccount(
    partyId: number | null,
    accountId: number,
    data: BankAccountUpdateReqModel,
) {
    if (!partyId) return;
    const res = await updateBankAccount(partyId, accountId, data);
    if (res) {
        if (isEditShown.value) {
            // In that case is better not to update bank account list locally because LAST default bank account should be updated too
            store.loadingCounter++;
            await store.fetchBankAccountList(+route.params.partyId);
            store.loadingCounter--;
            isEditShown.value = false;
        } else {
            store.loadingCounter++;
            await store.updateBankAccountList(res);
            store.loadingCounter--;
        }
        goToBankAccountList(true);
    }
}
</script>

<template>
    <div class="row justify-content-center">
        <div class="col-12 d-flex justify-content-between align-items-center">
            <div class="d-flex justify-content-start">
                <h4 class="text-primary">
                    {{ t(`${PAYMENT_METHODS_ID}.bank_account_detail`) }}
                </h4>
            </div>
            <div class="d-flex justify-content-end">
                <BiButton
                    v-if="editable && !bankAccountDetail?.defaultBankAccount"
                    color="danger"
                    isOutlined
                    @click="showCloseModal"
                >
                    {{ t(`${PAYMENT_METHODS_ID}.close_bank_account`) }}
                </BiButton>
            </div>
        </div>
        <div class="col-12">
            <div class="mt-3" v-if="bankAccountDetail">
                <ul class="list-unstyled">
                    <li>
                        <strong
                            >{{ t(`${PAYMENT_METHODS_ID}.area_network`) }}:
                        </strong>
                        {{ bankAccountDetail.network }}
                    </li>
                    <li>
                        <strong>
                            {{
                                t(`${PAYMENT_METHODS_ID}.iban_account_number`)
                            }}:
                        </strong>
                        {{ bankAccountDetail.iban }}
                    </li>
                    <li>
                        <strong>
                            {{ t(`${PAYMENT_METHODS_ID}.swift_bic`) }}:
                        </strong>
                        {{ bankAccountDetail.swiftBic }}
                    </li>
                    <li>
                        <strong>
                            {{ t(`${PAYMENT_METHODS_ID}.bic`) }}:
                        </strong>
                        {{ bankAccountDetail.bicExtraSepa }}
                    </li>
                    <li>
                        <strong
                            >{{ t(`${PAYMENT_METHODS_ID}.country`) }}:
                        </strong>
                        {{ bankAccountDetail.bankCountry }}
                    </li>
                    <li>
                        <strong
                            >{{ t(`${PAYMENT_METHODS_ID}.institute`) }}:
                        </strong>
                        {{ bankAccountDetail.bankName }}
                    </li>
                    <li>
                        <strong
                            >{{ t(`${PAYMENT_METHODS_ID}.branch`) }}:
                        </strong>
                        {{ bankAccountDetail.bankBranch }}
                    </li>
                    <li>
                        <strong>
                            {{
                                t(`${PAYMENT_METHODS_ID}.validity_start_date`)
                            }}:
                        </strong>
                        {{
                            bankAccountDetail.dayFrom
                                ? format(
                                      convertToDate(bankAccountDetail.dayFrom)!,
                                      CLIENT_DATE_FORMAT,
                                  )
                                : ""
                        }}
                    </li>
                    <li
                        v-if="
                            bankAccountDetail.dayTo && !bankAccountDetail.active
                        "
                    >
                        <strong>
                            {{ t(`${PAYMENT_METHODS_ID}.validity_end_date`) }}:
                        </strong>
                        {{
                            bankAccountDetail.dayTo
                                ? format(
                                      convertToDate(bankAccountDetail.dayTo)!,
                                      CLIENT_DATE_FORMAT,
                                  )
                                : ""
                        }}
                    </li>
                </ul>
                <BiInput
                    v-model="update.description"
                    class="my-5"
                    type="text"
                    :disabled="!editable"
                    :label="t(`${PAYMENT_METHODS_ID}.description`)"
                />
                <div class="d-flex">
                    <BiToggle
                        v-if="editable"
                        v-model="update.defaultBankAccount"
                        size="lg"
                        :label="t(`${PAYMENT_METHODS_ID}.set_as_default`)"
                    ></BiToggle>
                </div>
                <div class="row my-5">
                    <div class="col-12 d-flex justify-content-center">
                        <BiButton
                            color="primary"
                            class="me-3"
                            isOutlined
                            @click="goToBankAccountList(false)"
                        >
                            <BiIcon icon="arrow-left" class="me-1" />
                            {{ t(`${PAYMENT_METHODS_ID}.back_to_list`) }}
                        </BiButton>
                        <BiButton
                            v-if="editable"
                            color="success"
                            :is-disabled="!changesPending"
                            @click="confirmOrShowModal"
                        >
                            {{ t(`${PAYMENT_METHODS_ID}.save`) }}
                        </BiButton>
                    </div>
                </div>
            </div>
        </div>

        <CloseBankAccountModal
            v-if="bankAccountDetail?.dayFrom"
            v-model="isCloseShown"
            :dayFrom="convertToDate(bankAccountDetail.dayFrom)!"
            @update:day-to="
                (value) =>
                    closeAccount(
                        +route.params.partyId,
                        +route.params.accountId,
                        value,
                    )
            "
        />

        <ConfirmModal
            v-model="isEditShown"
            :modalTitle="t(`${PAYMENT_METHODS_ID}.warning.warning`)"
            :modalBody="
                t(`${PAYMENT_METHODS_ID}.warning.bank_account_will_set_default`)
            "
            confirmBtnColor="success"
            @confirm="
                editBankAccount(
                    +route.params.partyId,
                    +route.params.accountId,
                    update,
                )
            "
        />
    </div>
</template>
