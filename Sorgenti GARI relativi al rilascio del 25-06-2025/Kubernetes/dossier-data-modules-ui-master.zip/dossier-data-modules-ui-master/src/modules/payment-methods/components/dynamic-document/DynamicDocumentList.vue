<script setup lang="ts">
import type { DocumentTypeModel } from "@/models/documentTypes";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import type { DocumentSchemaType } from "@abaco/dynamic-documents/src/resources/models";
import { format } from "date-fns";
import { computed, withDefaults, defineProps, defineEmits } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";
import type {
    DynamiDocumentModel,
    DynamiDocumentMapModel,
} from "@/models/dynamicDocuments";
import { PaymentMethodsRouteName } from "@/modules/payment-methods/models/routes";
import BiHiddenContent from "@abaco/bootstrap-italia-components/src/components/BiHiddenContent/BiHiddenContent.vue";
import { CLIENT_DATE_FORMAT } from "@/constants";
import { PAYMENT_METHODS_ID } from "@/modules/payment-methods/constants";

const props = withDefaults(
    defineProps<{
        documentList: DynamiDocumentModel[];
        docType: DocumentTypeModel;
        docDefinition: DocumentSchemaType;
        showLoadMore?: boolean;
        readonly: boolean;
    }>(),
    { showLoadMore: false },
);

const emit = defineEmits<{
    (e: "load-more"): void;
    (e: "delete-document", value: DynamiDocumentMapModel): void;
}>();

const { t } = useI18n();

const { getColor } = useColors();

const router = useRouter();
const route = useRoute();
const fieldDefinitions = computed(() => props.docType.summaryFieldDefinitions);

function newDocument(): void {
    router.replace({ name: PaymentMethodsRouteName.NEW_MULTIPLE_DOC });
}

async function editDocument(document: DynamiDocumentModel) {
    router.replace({
        name: PaymentMethodsRouteName.EDIT_MULTIPLE_DOC,
        params: {
            docId: document.documentId,
        },
    });
}

function loadMore() {
    emit("load-more");
}

function formatField(fieldCode: string, doc: DynamiDocumentModel) {
    const fieldType =
        doc.summaryFieldDefinitions?.find((it) => it.code === fieldCode)
            ?.fieldType || "string";
    const fieldValue = doc.data[fieldCode];
    if (fieldType === "date") {
        return format(new Date(fieldValue as string), CLIENT_DATE_FORMAT);
    }
    return fieldValue;
}

function deleteDocument(document: DynamiDocumentModel) {
    emit("delete-document", document as unknown as DynamiDocumentMapModel);
}

function goBackToAccountDetail() {
    router.push({
        name: PaymentMethodsRouteName.BANK_ACCOUNT_DETAIL,
        params: { accountId: +route.params.accountId },
    });
}
</script>

<template>
    <BiTable
        class="table mb-0"
        extraTableClasses="table-head-bg"
        is-custom
        responsive-breakpoint="md"
        is-row-hover
        isResponsive
    >
        <template #head>
            <tr class="bg-light" :class="getColor('text', 'secondary')">
                <th
                    v-for="(item, i) in fieldDefinitions"
                    :key="i"
                    :class="{ 'text-center': item.fieldType === 'file' }"
                    :id="'field' + i"
                >
                    {{ item.description }}
                </th>
                <th id="action">
                    <BiHiddenContent
                        :text="t(`${PAYMENT_METHODS_ID}.action`, 2)"
                    >
                    </BiHiddenContent>
                </th>
            </tr>
        </template>
        <template #body>
            <tr v-for="(doc, trIndex) in documentList" :key="trIndex">
                <td
                    v-for="(field, tdIndex) in fieldDefinitions"
                    :key="tdIndex"
                    :class="{
                        'text-center':
                            field.fieldType === 'file' && doc.data[field.code],
                    }"
                >
                    <BiIcon
                        v-if="
                            field.fieldType === 'file' && doc.data[field.code]
                        "
                        icon="check"
                    />
                    <span v-else>{{ formatField(field.code, doc) }}</span>
                </td>
                <td class="text-end">
                    <BiButton
                        color="success"
                        is-outlined
                        is-icon
                        :width="35"
                        class="btn-me"
                        @click="editDocument(doc)"
                    >
                        <BiIcon
                            v-if="!readonly"
                            icon="pencil"
                            size="lg"
                        ></BiIcon>
                        <BiIcon v-else icon="eye"></BiIcon>
                    </BiButton>
                    <BiButton
                        v-if="!readonly"
                        color="danger"
                        is-outlined
                        is-icon
                        :width="35"
                        @click="deleteDocument(doc)"
                    >
                        <BiIcon
                            icon="trash-can"
                            color="danger"
                            size="lg"
                        ></BiIcon>
                    </BiButton>
                </td>
            </tr>
        </template>
    </BiTable>
    <div class="d-flex justify-content-end my-2" v-if="showLoadMore">
        <BiButton :is-outlined="true" color="primary" @click="loadMore">
            {{ t(`${PAYMENT_METHODS_ID}.dynamic_docs.list.loadMore`) }}
        </BiButton>
    </div>
    <div class="col-md-12 mt-4 text-center">
        <BiButton
            color="primary"
            class="me-3"
            isOutlined
            @click="goBackToAccountDetail()"
        >
            <BiIcon icon="arrow-left" class="me-1" />
            {{ t(`${PAYMENT_METHODS_ID}.back_to_detail`) }}
        </BiButton>
        <BiButton
            v-if="!readonly"
            :is-outlined="true"
            color="primary"
            @click="newDocument"
        >
            {{ t(`${PAYMENT_METHODS_ID}.dynamic_docs.list.new`, 2) }}
            {{ docType.definitionCodeI18n?.toLowerCase() }}
        </BiButton>
    </div>
</template>
