<script setup lang="ts">
import { computed, onMounted, ref, watch } from "vue";
import AlertMessage from "@/components/AlertMessage.vue";
import CustomChip from "@/components/CustomChip.vue";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";
import { PaymentMethodsRouteName } from "@/modules/payment-methods/models/routes";
import { useMessageStore } from "@/stores/messageStore";
import { format } from "date-fns";
import { convertToDate } from "@/utils/utils";
import AnomalyIcon from "@/components/anomaly/AnomalyIcon.vue";
import {
    CLIENT_DATE_FORMAT,
    DATE_TO_DEFAULT,
    DDM_MODULE_ID,
} from "@/constants";
import {
    PAGE_SIZE,
    PAYMENT_METHODS_ID,
} from "@/modules/payment-methods/constants";

import { usePaymentMedhodStore } from "@/modules/payment-methods/stores/paymentMethods";

const { t } = useI18n();

const router = useRouter();
const store = usePaymentMedhodStore();
const messageStore = useMessageStore();
const route = useRoute();

const showFilters = ref(false);
const flShowSuccessMessage = computed(() => {
    return (
        sessionStorage.getItem(`${PAYMENT_METHODS_ID}.showSuccessMessage`) ===
        "1"
    );
});

onMounted(async () => {
    if (flShowSuccessMessage.value) {
        messageStore.open = false;
        await new Promise((r) => setTimeout(r, 200));
        messageStore.setMessage({
            message: t(`${PAYMENT_METHODS_ID}.success_action`),
            level: "success",
        });
        sessionStorage.setItem(`${PAYMENT_METHODS_ID}.showSuccessMessage`, "0");
    }
});

const onShowFilters = () => {
    router.push({
        name: PaymentMethodsRouteName.BANK_ACCOUNT_FILTER,
        params: { partyId: route.params.partyId },
        query: { backUrl: "" },
    });
};

const shownAccountLenght = computed(() => {
    return store.getFilteredBankAccounts.length;
});

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const accountsDisplayed = computed(() => {
    const curLength =
        store.listLength <= store.getFilteredBankAccounts.length
            ? store.listLength
            : store.getFilteredBankAccounts.length;
    return (
        `${curLength} ` +
        t(`${PAYMENT_METHODS_ID}.of`) +
        ` ${store.getFilteredBankAccounts.length}`
    );
});

watch(
    () => +route.params.partyId,
    () => {
        if (+route.params.partyId) {
            store.fetchBankAccountList(+route.params.partyId);
        } else {
            messageStore.setMessage({
                message: t(
                    `${PAYMENT_METHODS_ID}.errors.unable_to_retrieve_party_registry_id`,
                ),
                level: "danger",
            });
        }
    },
);

watch(
    () => store.getFilteredBankAccounts.length,
    () => {
        store.listLength = PAGE_SIZE;
    },
);

function goToBankAccountDetail(id: number) {
    router.push({
        name: PaymentMethodsRouteName.BANK_ACCOUNT_DETAIL,
        params: { partyId: route.params.partyId, accountId: id },
        query: { backUrl: "" },
    });
}

function removeFilterOption(key: string) {
    if (key !== "active") {
        type ObjectKey = keyof typeof store.bankAccountFilter;
        const objKey = key as ObjectKey;
        store.bankAccountFilter[objKey] = undefined;
    }
}

function getPeriodText(dayFrom: string, dayTo: string) {
    if (dayTo !== "31/12/9999") return `${dayFrom} - ${dayTo}`;
    else return `${dayFrom}`;
}
</script>

<template>
    <div class="d-flex justify-content-between align-items-center">
        <div class="d-flex justify-content-start">
            <h4 class="text-primary">
                {{ t(`${PAYMENT_METHODS_ID}.bank_accounts`) }}
            </h4>
        </div>
        <div class="d-flex justify-content-end" v-if="!showFilters">
            <BiButton color="primary" isOutlined @click="onShowFilters">
                {{ t(`${PAYMENT_METHODS_ID}.filter_bank_accounts`) }}
            </BiButton>
        </div>
    </div>

    <div v-if="!showFilters">
        <div class="d-flex mt-3">
            <template
                v-for="(value, key) in store.bankAccountFilter"
                :key="key"
            >
                <CustomChip
                    v-if="!!value"
                    :label="
                        t(`${PAYMENT_METHODS_ID}.filter.${key}`) +
                        `: ${
                            ['active', 'area_network'].includes(key)
                                ? t(`${PAYMENT_METHODS_ID}.filter.${value}`)
                                : value
                        }`
                    "
                    :is-delete="key != 'active'"
                    class="truncate-target me-2"
                    @delete="removeFilterOption(key)"
                />
            </template>
        </div>
        <BiTable isRowHover isResponsive isHeaderLight class="mt-3">
            <template #head>
                <tr class="text-primary">
                    <th scope="col">
                        {{ t(`${PAYMENT_METHODS_ID}.area_network`) }}
                    </th>
                    <th scope="col">
                        {{ t(`${PAYMENT_METHODS_ID}.iban_account_number`) }}
                    </th>
                    <th scope="col">
                        {{ t(`${PAYMENT_METHODS_ID}.description`) }}
                    </th>
                    <th scope="col">
                        {{ t(`${PAYMENT_METHODS_ID}.period`) }}
                    </th>
                    <th scope="col">
                        {{ t(`${PAYMENT_METHODS_ID}.default`) }}
                    </th>
                    <th scope="col">
                        {{ t(`${PAYMENT_METHODS_ID}.anomalies`) }}
                    </th>
                    <th scope="col"></th>
                </tr>
            </template>
            <template #body>
                <tr
                    v-for="account in store.getFilteredBankAccounts.slice(
                        0,
                        store.listLength,
                    )"
                    :key="account.id"
                    class="align-middle"
                >
                    <td>
                        <small>{{ account.network }}</small>
                    </td>
                    <td>
                        <small>{{ account.iban }}</small>
                    </td>
                    <td>
                        <small>{{ account.description }}</small>
                    </td>
                    <td>
                        <small>{{
                            getPeriodText(
                                format(
                                    convertToDate(account.dayFrom)!,
                                    CLIENT_DATE_FORMAT,
                                ),
                                account.dayTo &&
                                    account.dayTo != DATE_TO_DEFAULT
                                    ? format(
                                          convertToDate(account.dayTo)!,
                                          CLIENT_DATE_FORMAT,
                                      )
                                    : "",
                            )
                        }}</small>
                    </td>
                    <td>
                        <BiIcon
                            v-if="account.defaultBankAccount === true"
                            icon="check"
                            color="success"
                        />
                    </td>
                    <td>
                        <AnomalyIcon
                            v-if="account.anomalies"
                            :account="account"
                        />
                    </td>
                    <td class="text-end">
                        <BiIconButton
                            class="mx-1"
                            icon="arrow-right"
                            iconStyle="fas"
                            color="primary"
                            isOutlined
                            @click="goToBankAccountDetail(account.id)"
                        />
                    </td>
                </tr>
            </template>
        </BiTable>
        <div class="mt-5">
            <AlertMessage
                :modelValue="!store.getFilteredBankAccounts.length"
                :dismissable="false"
                :level="'info'"
            >
                {{ t(`${DDM_MODULE_ID}.message.empty_list`) }}
            </AlertMessage>
        </div>
        <!-- <div
            class="w-full d-flex justify-content-center mt-3"
            v-if="store.filteredBankAccounts.length"
        >
            <span>
                {{ accountsDisplayed }}
            </span>
        </div> -->
        <div class="w-full d-flex justify-content-center mt-5">
            <BiButton
                v-if="store.listLength < shownAccountLenght"
                color="primary"
                isOutlined
                @click="store.listLength += PAGE_SIZE"
            >
                {{ t(`${PAYMENT_METHODS_ID}.load_more`) }}
            </BiButton>
        </div>
    </div>
</template>
