<script setup lang="ts">
import { ref, reactive, onMounted } from "vue";
import { useI18n } from "vue-i18n";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiToggle from "@abaco/bootstrap-italia-components/src/components/form/BiToggle.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import { useRoute, useRouter } from "vue-router";
import { PaymentMethodsRouteName } from "@/modules/payment-methods/models/routes";
import {
    NetworksEnum,
    type BankAccountCreate,
} from "@/modules/payment-methods/models/bankAccounts";
import { createNewBankAccount } from "@/modules/payment-methods/resources/api/bankAccounts";
import { useField, useForm } from "vee-validate";
import { toTypedSchema } from "@vee-validate/zod";
import z from "zod";
import ConfirmModal from "@/components/ConfirmModal.vue";
import {
    PAYMENT_METHODS_ID,
    PAYMENT_REGEX_KEY,
} from "@/modules/payment-methods/constants";

import { usePaymentMedhodStore } from "@/modules/payment-methods/stores/paymentMethods";
import {
    RegexConfigResponseSchema,
    type RegexConfigResponse,
} from "../models/config";
import { getConfigurationByKey } from "@/resources/api/config";

const { t } = useI18n();

const router = useRouter();
const route = useRoute();
const store = usePaymentMedhodStore();

const isShown = ref(false);

const redirectToEdit = ref(false);

function showModal() {
    isShown.value = !isShown.value;
}

const bankAccountForm = reactive<Partial<BankAccountCreate>>({});
const ibanValidation = ref<RegexConfigResponse | null>(null);

onMounted(async () => {
    store.loadingCounter++;
    const res = await getConfigurationByKey(PAYMENT_REGEX_KEY);
    ibanValidation.value = RegexConfigResponseSchema.parse(res);
    store.loadingCounter--;
});

function goToBankAccountList(showSuccessMessage: boolean) {
    if (showSuccessMessage) {
        sessionStorage.setItem(`${PAYMENT_METHODS_ID}.showSuccessMessage`, "1");
    }
    router.push({
        name: PaymentMethodsRouteName.BANK_ACCOUNT_LIST,
        params: { partyId: +route.params.partyId },
    });
}

function goToBankAccountDetail(id: number) {
    sessionStorage.setItem(`${PAYMENT_METHODS_ID}.showSuccessMessage`, "1");
    router.push({
        name: PaymentMethodsRouteName.BANK_ACCOUNT_DETAIL,
        params: { partyId: +route.params.partyId, accountId: id },
    });
}

async function createBankAccount(
    partyId: number | null,
    newbankAccount: BankAccountCreate,
) {
    if (!partyId) return;
    const response = await createNewBankAccount(partyId, {
        ...newbankAccount,
        dayFrom: newbankAccount.dayFrom?.split("-").join(""),
    });
    if (response) {
        store.updateBankAccountList(response);
        return response;
    } else {
        return null;
    }
}

const { handleSubmit, setErrors, isSubmitting, resetForm, errors } =
    useForm<BankAccountCreate>({
        initialValues: {
            network: null,
            iban: null,
            dayFrom: null,
        },
    });

const { value: network } = useField<string | null>(
    "network",
    toTypedSchema(z.string().nullable()),
);
const { value: iban } = useField<string | null>(
    "iban",
    toTypedSchema(z.string().nullable()),
);
const { value: dayFrom } = useField<string | null>(
    "dayFrom",
    toTypedSchema(z.string().nullable()),
);

const areaNetwork = Object.keys(NetworksEnum).map((key) => {
    return {
        id: key,
        text: t(`${PAYMENT_METHODS_ID}.filter.` + key),
    };
});

const validateForm = (values: BankAccountCreate) => {
    if (!values.network) {
        setErrors({
            network: t(`${PAYMENT_METHODS_ID}.errors.fieldRequired`),
        });
    }
    if (values.iban == undefined || values.iban == null) {
        setErrors({
            iban: t(`${PAYMENT_METHODS_ID}.errors.fieldRequired`),
        });
    } else if (ibanValidation.value) {
        const regExpRules = ibanValidation.value.configuration.regexes.map(
            (o) => new RegExp(o),
        );
        const iban = values.iban;
        const valid = regExpRules.some((regex) => regex.test(iban));
        if (!valid)
            setErrors({
                iban: t(`${PAYMENT_METHODS_ID}.errors.customRegexp`),
            });
    }
    if (!values.dayFrom) {
        setErrors({
            dayFrom: t(`${PAYMENT_METHODS_ID}.errors.fieldRequired`),
        });
    }
};

const onSubmit = handleSubmit.withControlled(async (values) => {
    validateForm(values);

    if (errors.value.iban || errors.value.network || errors.value.dayFrom) {
        return;
    } else {
        if (bankAccountForm.defaultBankAccount === true) {
            showModal();
        } else {
            store.loadingCounter++;
            const response = await createBankAccount(+route.params.partyId, {
                ...bankAccountForm,
                network: values.network as NetworksEnum,
                iban: values.iban,
                dayFrom: values.dayFrom,
            });
            store.loadingCounter--;

            if (response) {
                if (redirectToEdit.value) {
                    redirectToEdit.value = false;
                    goToBankAccountDetail(response.id);
                } else goToBankAccountList(true);
            }
        }
    }
    return true;
});

const onConfirm = handleSubmit.withControlled(async (values) => {
    store.loadingCounter++;
    const res = await createBankAccount(+route.params.partyId, {
        ...bankAccountForm,
        network: values.network as NetworksEnum,
        iban: values.iban,
        dayFrom: values.dayFrom,
    });
    store.loadingCounter--;
    if (res) {
        if (isShown.value) {
            // In that case is better not to update bank account list locally because LAST default bank account should be updated too
            store.loadingCounter++;
            await store.fetchBankAccountList(+route.params.partyId);
            store.loadingCounter--;
            isShown.value = false;
        } else {
            store.updateBankAccountList(res);
        }

        if (redirectToEdit.value) {
            redirectToEdit.value = false;
            goToBankAccountDetail(res.id);
        } else goToBankAccountList(true);
    }
    isShown.value = false;
});

/**
 * ### Reset form
 */
function clearForm() {
    resetForm({
        values: {
            network: null,
            iban: null,
        },
    });
}
</script>
<template>
    <h4 class="text-primary">
        {{ t(`${PAYMENT_METHODS_ID}.new_bank_account`) }}
    </h4>
    <form
        action="#"
        id="bankAccountForm"
        name="bankAccountForm"
        @submit.prevent="onSubmit"
        @reset.prevent="clearForm"
        class="dossier-data-modules__form"
    >
        <div class="row mt-5">
            <div class="col-md-3 field-required">
                <BiSelect
                    v-model="network"
                    id="areaNetwork"
                    name="areaNetwork"
                    :required="true"
                    :items="areaNetwork"
                    :errors="errors.network ? [errors.network] : []"
                    :label="t(`${PAYMENT_METHODS_ID}.area_network`)"
                />
            </div>
            <div class="col-md-3 field-required">
                <BiInput
                    v-model="iban"
                    id="iban"
                    name="iban"
                    type="text"
                    :required="true"
                    :errors="errors.iban ? [errors.iban] : []"
                    :label="t(`${PAYMENT_METHODS_ID}.iban_account_number`)"
                />
            </div>
            <div class="col-md-3">
                <BiInput
                    v-model="bankAccountForm.swiftBic"
                    type="text"
                    :label="t(`${PAYMENT_METHODS_ID}.swift_bic`)"
                />
            </div>
            <div class="col-md-3">
                <BiInput
                    v-model="bankAccountForm.bicExtraSepa"
                    type="text"
                    :label="t(`${PAYMENT_METHODS_ID}.bic`)"
                />
            </div>
        </div>
        <div class="row my-5">
            <div class="col-md-3">
                <BiInput
                    v-model="bankAccountForm.bankCountry"
                    type="text"
                    :label="t(`${PAYMENT_METHODS_ID}.country`)"
                />
            </div>
            <div class="col-md-3">
                <BiInput
                    v-model="bankAccountForm.bankName"
                    type="text"
                    :label="t(`${PAYMENT_METHODS_ID}.institute`)"
                />
            </div>
            <div class="col-md-3">
                <BiInput
                    v-model="bankAccountForm.bankBranch"
                    type="text"
                    :label="t(`${PAYMENT_METHODS_ID}.branch`)"
                />
            </div>
            <div class="col-md-3 field-required">
                <BiDatepicker
                    id="dayFrom"
                    name="dayFrom"
                    :max="new Date()"
                    v-model="dayFrom"
                    :errors="errors.dayFrom ? [errors.dayFrom] : []"
                    :label="t(`${PAYMENT_METHODS_ID}.validity_start_date`)"
                />
            </div>
        </div>
        <div class="row justify-content-start">
            <div class="col-md-6">
                <BiInput
                    v-model="bankAccountForm.description"
                    type="text"
                    :label="t(`${PAYMENT_METHODS_ID}.description`)"
                />
            </div>
            <div class="col-md-3">
                <div class="h-100 d-flex flex-row">
                    <BiToggle
                        class="mt-auto"
                        v-model="bankAccountForm.defaultBankAccount"
                        :label="t(`${PAYMENT_METHODS_ID}.set_as_default`)"
                    ></BiToggle>
                </div>
            </div>
        </div>
    </form>
    <!-- Buttons  -->
    <div class="row my-5 pt-5">
        <div class="col-6 d-flex justify-content-end">
            <BiButton
                color="primary"
                class="me-3"
                isOutlined
                @click="goToBankAccountList(false)"
                :is-disabled="isSubmitting"
            >
                <BiIcon icon="arrow-left" class="me-1" />
                {{ t(`${PAYMENT_METHODS_ID}.back_to_list`) }}
            </BiButton>
            <BiButton
                color="success"
                type="submit"
                @click="onSubmit"
                :is-disabled="isSubmitting"
            >
                {{ t(`${PAYMENT_METHODS_ID}.save`) }}
            </BiButton>
        </div>
        <div class="col-6 d-flex justify-content-end">
            <BiButton
                color="success"
                isOutlined
                :is-disabled="isSubmitting"
                @click="
                    () => {
                        redirectToEdit = true;
                        onSubmit();
                    }
                "
            >
                {{ t(`${PAYMENT_METHODS_ID}.save_continue`) }}
                <BiIcon icon="arrow-right" class="ms-1" />
            </BiButton>
        </div>
    </div>
    <!-- End buttons  -->
    <ConfirmModal
        v-model="isShown"
        @confirm="onConfirm"
        confirmBtnColor="success"
        :modalTitle="t(`${PAYMENT_METHODS_ID}.warning.warning`)"
        :modalBody="
            t(`${PAYMENT_METHODS_ID}.warning.bank_account_will_set_default`)
        "
    />
</template>
