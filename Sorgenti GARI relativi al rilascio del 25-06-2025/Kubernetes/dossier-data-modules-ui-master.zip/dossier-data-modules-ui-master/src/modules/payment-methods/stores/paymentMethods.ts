import {
    ActiveEnum,
    type BankAccountFilter,
    type BankAccount,
} from "@/modules/payment-methods/models/bankAccounts";
import {
    getAccountAnomalies,
    getBankAccountById,
    getBankAccountsList,
} from "@/modules/payment-methods/resources/api/bankAccounts";
import { defineStore } from "pinia";
import { PAGE_SIZE } from "../constants";

export interface State {
    loadingCounter: number;
    bankAccountFilter: Partial<BankAccountFilter>;
    bankAccounts: BankAccount[];
    listLength: number;
    filteredBankAccounts: BankAccount[];
}

const initialState: State = {
    loadingCounter: 0,
    bankAccountFilter: {
        active: ActiveEnum.only_active,
    },
    bankAccounts: [],
    listLength: PAGE_SIZE,
    filteredBankAccounts: [],
};

const state: State = structuredClone(initialState);

export const usePaymentMedhodStore = defineStore({
    id: "PaymentMedhod",
    state: (): State => state,
    getters: {
        getFilteredBankAccounts(): BankAccount[] {
            const filter = this.bankAccountFilter;
            return this.bankAccounts
                .filter((ba) => {
                    if (
                        filter.active == ActiveEnum.only_active &&
                        ba.active == false
                    )
                        return false;
                    if (
                        filter.active == ActiveEnum.not_active &&
                        ba.active == true
                    )
                        return false;
                    if (
                        filter.iban_account_number &&
                        filter.iban_account_number !== ba.iban
                    )
                        return false;
                    if (
                        filter.description &&
                        filter.description !== ba.description
                    )
                        return false;
                    if (
                        filter.area_network &&
                        filter.area_network !== ba.network
                    )
                        return false;
                    return true;
                })
                .sort((a, b) => {
                    if (a.defaultBankAccount === true) {
                        return -1;
                    }
                    if (b.defaultBankAccount === true) {
                        return 1;
                    }
                    return 0;
                });
        },
    },
    actions: {
        updateBankAccountList(bankAccount: BankAccount) {
            this.bankAccounts = [
                ...this.bankAccounts.filter((ba) => ba.id != bankAccount.id),
                bankAccount,
            ];
        },
        async loadAccountsAnomalies(partyId: number) {
            this.loadingCounter++;
            this.bankAccounts.map(async (a) => {
                const res = await getAccountAnomalies(partyId, a.id);
                if (res) a.anomalies = res;
            });
            this.loadingCounter--;
        },

        async fetchBankAccountList(partyId: number) {
            if (!partyId) return;
            this.loadingCounter++;
            this.bankAccounts = await getBankAccountsList(partyId);
            this.loadingCounter--;
        },

        async fetchBankAccountById(partyId: number, accountId: number) {
            if (!partyId) return;
            this.loadingCounter++;
            const targetAccount = await getBankAccountById(partyId, accountId);
            this.loadingCounter--;
            return targetAccount;
        },

        $reset() {
            this.$state = structuredClone(initialState);
        },
    },
});
