<script setup lang="ts">
import AlertMessage from "@/components/AlertMessage.vue";
import { DDM_MODULE_ID } from "@/constants";
import { useOliveUnitStore } from "@/modules/units/stores/oliveUnit";
import t from "@/modules/units/utils/i18n";
import { useMessageStore } from "@/stores/messageStore";
import { areaSQMInHA, formatDate } from "@/utils/utils";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { defineProps, onMounted } from "vue";
import { goToParcelSummary } from "../utils/navigate";

const props = defineProps<{
    partyId: number;
}>();

const messageStore = useMessageStore();
const oliveUnitStore = useOliveUnitStore();

onMounted(async () => {
    if (props.partyId && !isNaN(props.partyId)) {
        oliveUnitStore.partyId = props.partyId;
        await oliveUnitStore.fetchOliveUnitBySector(
            oliveUnitStore.partyId,
            formatDate(oliveUnitStore.curDate),
        );
    } else {
        messageStore.setMessage({
            message: t(
                `${DDM_MODULE_ID}.errors.unable_to_retrieve_party_registry_id`,
            ),
            level: "danger",
        });
    }
});
function goToParcelSummaryHandler() {
    const partyId = oliveUnitStore.partyId;
    if (!partyId) return null;
    goToParcelSummary(`/olive-register/${partyId}/parcels/summary`);
}
</script>
<template>
    <div class="mx-3 row units-module">
        <div class="mt-3 px-3 col-12">
            <h3 class="text-primary">
                <BiIcon icon="file-lines"></BiIcon>
                {{ t(`register`) }}
            </h3>
        </div>
        <div class="mt-5 px-3 col-12">
            <AlertMessage
                v-model="messageStore.open"
                :level="messageStore.level"
            >
                {{ messageStore.message }}
            </AlertMessage>
            <BiTable
                is-row-hover
                is-header-light
                is-custom
                responsive-breakpoint="md"
            >
                <template #head>
                    <tr class="text-primary">
                        <th scope="col"></th>
                        <th scope="col">
                            {{ t(`parcels.count`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.area`) }}
                        </th>
                        <th scope="col"></th>
                    </tr>
                </template>
                <template #body>
                    <tr class="align-middle">
                        <td :data-label="t(`parcels.type`)">
                            <small>
                                {{ t(`parcels.type_parcels`) }}
                            </small>
                        </td>
                        <td :data-label="t(`parcels.count`)">
                            <small>{{ oliveUnitStore.totalParcels }}</small>
                        </td>
                        <td :data-label="t(`parcels.area`)">
                            <small>
                                {{
                                    areaSQMInHA(
                                        oliveUnitStore.totalOliveUnitsAreaSqm,
                                    )
                                }}
                            </small>
                        </td>
                        <td class="text-end">
                            <BiIconButton
                                class="mx-1"
                                icon="arrow-right"
                                iconStyle="fas"
                                color="primary"
                                isOutlined
                                @click="goToParcelSummaryHandler"
                            />
                        </td>
                    </tr>
                </template>
            </BiTable>
        </div>
    </div>
    <div class="mt-5 text-center col-12">
        <BiButton
            class="mx-1"
            color="success"
            @click="goToParcelSummaryHandler"
        >
            {{ t(`parcels.detail`) }}
        </BiButton>
    </div>
</template>
