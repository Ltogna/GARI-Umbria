<script setup lang="ts">
import AlertMessage from "@/components/AlertMessage.vue";
import TitleBar from "@/components/TitleBar.vue";
import TopBar from "@/components/TopBar.vue";
import { DDM_MODULE_ID } from "@/constants";
import LeftSidebar from "@/modules/units/components/LeftSidebar.vue";
import t from "@/modules/units/utils/i18n";
import { useMessageStore } from "@/stores/messageStore";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import { computed, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";
import { UnitRouteName } from "../models/routes";
import { useOliveUnitStore } from "../stores/oliveUnit";
import { useUnitConfigStore } from "../stores/unitConfig";

const router = useRouter();
const route = useRoute();
const oliveUnitStore = useOliveUnitStore();
const configStore = useUnitConfigStore();
const messageStore = useMessageStore();

onMounted(async () => {
    try {
        document.title = t(`register`);
        const urlParams = new URLSearchParams(window.location.search);
        const backUrl = urlParams.get("backUrl");
        if (backUrl != null)
            sessionStorage.setItem(`${DDM_MODULE_ID}.backUrl`, backUrl);

        oliveUnitStore.loadingCounter++;
        await configStore.fetchConfig();
    } catch (error) {
        // TODO - HANDLE ERROR
        console.error(error);
    } finally {
        oliveUnitStore.loadingCounter--;
    }
});

const showBackButton = computed(() => {
    return (
        route.name !== UnitRouteName.OLIVE_PARCEL_SUMMARY &&
        // route.name !== UnitRouteName.OLIVE_AUTHORIZATIONS_SUMMARY &&
        // route.name !== UnitRouteName.OLIVE_APTITUDES_SUMMARY &&
        // route.name !== UnitRouteName.OLIVE_QUOTAS_SUMMARY &&
        // route.name !== UnitRouteName.OLIVE_AUTHORIZATION_DETAIL &&
        !oliveUnitStore.showParcelFilter
    );
});
</script>

<template>
    <div class="my-5 container units-module">
        <BiCard :extra-classes="['card-bg', 'rounded', 'no-after']">
            <template #card-header>
                <div class="px-4 card-header">
                    <TopBar :title="t(`corporate_register`)" />
                </div>
            </template>
            <template #card-body>
                <AlertMessage
                    v-model="messageStore.open"
                    :level="messageStore.level"
                >
                    {{ messageStore.message }}
                </AlertMessage>
                <TitleBar leftBarTitle="" :showLeftTitle="false" />
                <div class="mt-1 row">
                    <div class="p-3 col-md-3">
                        <LeftSidebar />
                    </div>
                    <div class="p-4 col-md-9">
                        <router-view></router-view>
                    </div>
                    <div
                        v-if="showBackButton"
                        class="d-flex justify-content-center p-3 col-9 offset-3"
                    >
                        <BiButton
                            color="primary"
                            isOutlined
                            @click="router.go(-1)"
                        >
                            {{ t(`${DDM_MODULE_ID}.go_back`) }}
                        </BiButton>
                    </div>
                </div>
            </template>
        </BiCard>
    </div>
</template>
