<script setup lang="ts">
import t from "@/modules/units/utils/i18n";
import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import { computed } from "vue";
import { UnitRouteName } from "../models/routes";
import { useUnitConfigStore } from "../stores/unitConfig";

const configStore = useUnitConfigStore();

const vineNavigation = computed(() => [
    {
        route: UnitRouteName.VINE_PARCEL_SUMMARY,
        name: t(`parcels.parcels`),
        active: configStore.mode === "vine",
    },
    {
        route: UnitRouteName.OLIVE_PARCEL_SUMMARY,
        name: t(`parcels.parcels`),
        active: configStore.mode === "olive",
    },
    {
        route: UnitRouteName.FRUIT_PARCEL_SUMMARY,
        name: t(`parcels.parcels`),
        active: configStore.mode === "fruit",
    },
    {
        route: UnitRouteName.VINE_AUTHORIZATIONS_SUMMARY,
        name: t(`authorizations.authorizations`),
        active: configStore.authorizationsEnabled,
    },
    {
        route: UnitRouteName.VINE_APTITUDES_SUMMARY,
        name: t(`aptitudes.aptitudes_do_igt`),
        active: configStore.aptitudesEnabled,
    },
    {
        route: UnitRouteName.VINE_QUOTAS_SUMMARY,
        name: t(`quotas.quotas_do_igt`),
        active: configStore.doIgtQuotasEnabled,
    },
    {
        route: UnitRouteName.VINE_APPLICATIONS_SUMMARY,
        name: t(`applications.applications`),
        active: configStore.applicationsEnabled,
    },
]);
</script>
<template>
    <BiAccordion
        :model-value="true"
        colorBgHeader="primary"
        colorHeader="white"
        bodyExtraClass="p-0"
        :title="t(`register`)"
        headerArrowExtraClass="py-0"
    >
        <div class="it-list-wrapper">
            <ul class="p-4 border it-list">
                <li
                    v-for="(value, key) in vineNavigation.filter(
                        (v) => v.active,
                    )"
                    :key="key"
                >
                    <RouterLink
                        class="text-decoration-none"
                        :to="{ name: value.route }"
                    >
                        {{ value.name }}
                    </RouterLink>
                </li>
            </ul>
        </div>
    </BiAccordion>
</template>
