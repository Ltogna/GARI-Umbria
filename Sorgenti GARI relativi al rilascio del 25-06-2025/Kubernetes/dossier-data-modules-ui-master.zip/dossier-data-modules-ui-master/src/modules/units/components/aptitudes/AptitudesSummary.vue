<script setup lang="ts">
import AlertMessage from "@/components/AlertMessage.vue";
import { DDM_MODULE_ID } from "@/constants";
import { UnitRouteName } from "@/modules/units/models/routes";
import t from "@/modules/units/utils/i18n";
import { useDdmStore } from "@/stores/ddmStore";
import { areaSQMInHA } from "@/utils/utils";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { computed, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";
import { useVineUnitStore } from "../../stores/vineUnit";

const router = useRouter();
const route = useRoute();

const vineUnitStore = useVineUnitStore();
const ddmStore = useDdmStore();

onMounted(async () => {
    try {
        vineUnitStore.loadingCounter++;
        await vineUnitStore.fetchAptitudeSummaryList(+route.params.partyId);
    } catch (error) {
        // TODO - HANDLE ERROR
        console.error(error);
    } finally {
        vineUnitStore.loadingCounter--;
    }
});

const isErrorEmptyShown = computed(() => {
    return (
        !vineUnitStore.aptitudesSummary.length &&
        vineUnitStore.loadingCounter === 0 &&
        ddmStore.loadingCounter === 0
    );
});

function goToAptitudesUvList(doIgtCode: string) {
    router.push({
        name: UnitRouteName.VINE_APTITUDES_UV_LIST,
        params: { doIgtCode },
    });
}
</script>
<template>
    <div class="row">
        <div class="col-12">
            <h4>{{ t(`aptitudes.aptitudes_do_igt`) }}</h4>
            <BiTable
                is-row-hover
                is-header-light
                is-custom
                responsive-breakpoint="md"
                class="mt-5"
            >
                <template #head>
                    <tr class="text-primary">
                        <th scope="col">
                            {{ t(`aptitudes.category`) }}
                        </th>
                        <th scope="col">
                            {{ t(`aptitudes.name`) }}
                        </th>
                        <th scope="col">
                            {{ t(`code`) }}
                        </th>
                        <th scope="col">
                            {{ t(`aptitudes.typology`) }}
                        </th>
                        <th scope="col">
                            {{ t(`aptitudes.surface`) }}
                        </th>
                        <th scope="col">
                            {{ t(`aptitudes.block_surface_typology`) }}
                        </th>
                        <th scope="col">
                            {{ t(`aptitudes.block_surface_claims`) }}
                        </th>
                        <th scope="col">
                            {{ t(`aptitudes.block_surface_eligibility`) }}
                        </th>
                        <th scope="col"></th>
                    </tr>
                </template>
                <template #body>
                    <tr
                        v-for="aptitude in vineUnitStore.aptitudesSummary"
                        :key="aptitude.doIgt.id"
                        class="align-middle"
                    >
                        <td :data-label="t(`aptitudes.category`)">
                            <small>
                                {{ aptitude.doIgt.category_description }}
                            </small>
                        </td>
                        <td :data-label="t(`aptitudes.name`)">
                            <small>{{ aptitude.doIgt.name_description }}</small>
                        </td>
                        <td :data-label="t(`code`)">
                            <small>{{ aptitude.doIgt.code }}</small>
                        </td>
                        <td :data-label="t(`aptitudes.typology`)">
                            <small>{{ aptitude.doIgt.description }}</small>
                        </td>
                        <td :data-label="t(`aptitudes.surface`)">
                            <small>{{ areaSQMInHA(aptitude.areaSqm) }}</small>
                        </td>
                        <td :data-label="t(`aptitudes.block_surface_typology`)">
                            <small>
                                {{ areaSQMInHA(aptitude.areaTypology) }}
                            </small>
                        </td>
                        <td :data-label="t(`aptitudes.block_surface_claims`)">
                            <small>
                                {{ areaSQMInHA(aptitude.areaClaims) }}
                            </small>
                        </td>
                        <td
                            :data-label="
                                t(`aptitudes.block_surface_eligibility`)
                            "
                        >
                            <small>
                                {{ areaSQMInHA(aptitude.areaSuitability) }}
                            </small>
                        </td>
                        <td class="text-end">
                            <BiIconButton
                                class="mx-1"
                                icon="arrow-right"
                                iconStyle="fas"
                                color="primary"
                                isOutlined
                                @click="
                                    goToAptitudesUvList(aptitude.doIgt.code)
                                "
                            />
                        </td>
                    </tr>
                </template>
            </BiTable>

            <AlertMessage
                :modelValue="isErrorEmptyShown"
                :dismissable="false"
                :level="'info'"
            >
                {{ t(`${DDM_MODULE_ID}.message.empty_list`) }}
            </AlertMessage>
        </div>
    </div>
</template>
