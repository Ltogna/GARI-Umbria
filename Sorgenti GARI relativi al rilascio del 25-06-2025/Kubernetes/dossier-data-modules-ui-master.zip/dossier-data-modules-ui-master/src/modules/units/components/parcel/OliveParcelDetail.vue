<script setup lang="ts">
import AlertMessage from "@/components/AlertMessage.vue";
import useDateFormat from "@/composables/useDateFormat";
import useQueryFilter from "@/composables/useQueryFilter";
import type {
    OliveUnitListModel,
    Parcel,
    ParcelLandLink,
} from "@/modules/units/models/oliveUnit";
import { UnitRouteName } from "@/modules/units/models/routes";
import {
    getParcelById,
    getParcelLandLink,
} from "@/modules/units/resources/api/oliveUnit";
import { useOliveUnitStore } from "@/modules/units/stores/oliveUnit";
import t from "@/modules/units/utils/i18n";
import { areaSQMInHA, convertToDate } from "@/utils/utils";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { parseISO } from "date-fns";
import { computed, onMounted, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import { MONTH_YEAR_FORMAT } from "@/constants";
import ConductingDetailHeader from "./OliveConductingDetailHeader.vue";

const { dateFormat } = useDateFormat();
const router = useRouter();
const route = useRoute();

const oliveUnitStore = useOliveUnitStore();

const { filter: dateFilter } = useQueryFilter("date");

const curParcel = ref<Parcel | null>(null);
const curParcelLandLink = ref<ParcelLandLink | null>(null);
const oliveUnitList = computed(() => {
    const oliveUnits: OliveUnitListModel = [];
    curParcel.value?.landcovers_list.forEach((l) => {
        oliveUnits.push(...l.olive_units);
    });

    return oliveUnits;
});

const referenceDate = parseISO(dateFilter.value);

onMounted(async () => {
    oliveUnitStore.loadingCounter++;
    curParcel.value = await getParcelById(
        referenceDate,
        +route.params.parcelId,
        true,
        true,
        true
    );
    curParcelLandLink.value = await getParcelLandLink(
        referenceDate,
        +route.params.parcelId,
        +route.params.partyId,
    );
    oliveUnitStore.loadingCounter--;
});

function goToOliveUnitDetail(oliveUnitId: number, landCoverId: number) {
    router.push({
        name: UnitRouteName.OLIVE_UNIT_DETAIL,
        query: {
            date: route.query.date,
        },
        params: {
            oliveUnitId: oliveUnitId,
            landCoverId: landCoverId,
            parcelId: +route.params.parcelId,
        },
    });
}
</script>
<template>
    <ConductingDetailHeader
        :is-conductin-detail-button-visible="false"
        :cur-parcel="curParcel"
        :cur-parcel-land-link="curParcelLandLink"
    />
    <div class="mt-3 row">
        <div class="col-12">
            <h6>{{ t(`parcels.units`) }}</h6>
        </div>
        <div v-if="oliveUnitList.length" class="col-12">
            <BiTable
                is-row-hover
                is-header-light
                is-custom
                responsive-breakpoint="md"
            >
                <template #head>
                    <tr class="text-primary">
                        <th scope="col">
                            {{ t(`parcels.vu`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.variety`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.month_year_plant`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.planting_layout`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.breeding`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.destination`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.area`) }}
                        </th>
                        <th scope="col"></th>
                    </tr>
                </template>
                <template #body>
                    <tr
                        v-for="oliveUnit in oliveUnitList"
                        :key="oliveUnit.id"
                        class="align-middle"
                    >
                        <td :data-label="t(`parcels.vu`)">
                            <small>{{ oliveUnit.code }}</small>
                        </td>
                        <td :data-label="t(`parcels.variety`)">
                            <small>{{ oliveUnit.variety.description }}</small>
                        </td>
                        <td :data-label="t(`parcels.month_year_plant`)">
                            <small>{{
                                dateFormat(
                                    convertToDate(oliveUnit.planting_day),
                                    MONTH_YEAR_FORMAT
                                )
                            }}</small>
                        </td>
                        <td :data-label="t(`parcels.planting_layout`)">
                            <small>
                                {{ oliveUnit.distance_on_the_row_cm }}x{{
                                    oliveUnit.distance_between_rows_cm
                                }}
                            </small>
                        </td>
                        <td :data-label="t(`parcels.breeding`)">
                            <small>
                                {{ oliveUnit.farming_form?.description }}
                            </small>
                        </td>

                        <td :data-label="t(`parcels.destination`)">
                            <small>{{
                                oliveUnit.product_destination.description
                            }}</small>
                        </td>
                        <td :data-label="t(`parcels.area`)">
                            <small>{{ areaSQMInHA(oliveUnit.area_sqm) }}</small>
                        </td>
                        <td>
                            <small>
                                <BiIconButton
                                    class="mx-1"
                                    icon="arrow-right"
                                    iconStyle="fas"
                                    color="primary"
                                    isOutlined
                                    @click="
                                        goToOliveUnitDetail(
                                            oliveUnit.id,
                                            oliveUnit.land_cover_id,
                                        )
                                    "
                                />
                            </small>
                        </td>
                    </tr>
                </template>
            </BiTable>
        </div>
        <div v-else class="col-12">
            <AlertMessage
                :modelValue="true"
                :dismissable="false"
                :level="'info'"
            >
                {{ t(`no_units`) }}
            </AlertMessage>
        </div>
    </div>
</template>
