<script setup lang="ts">
import t from "@/modules/units/utils/i18n";
import { onMounted, ref } from "vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import { useRoute, useRouter } from "vue-router";
import { UnitRouteName } from "../../models/routes";
import BiInputFixed from "./BiInputFixed.vue";
import SubjectSearchForm from "./SubjectSearchForm.vue";
import {
    getAuthorizationDetailById,
    getTransferCauses,
    transferAuthorizationToCuaa,
} from "../../resources/api/authorizations";
import { usePartyStore } from "../../stores/party";
import { type AuthorizationTransferToCuaa } from "../../models/authorization";
import type { PartyModel } from "../../models/application";
import {
    convertToDate,
    validateDateInRange,
    formatArea,
    toHectares,
    toSquareMeters,
} from "@/utils/utils";

const isLoading = ref<boolean>(false);
const isError = ref<boolean>(false);

const router = useRouter();
const route = useRoute();

const transferredSurfaceTouched = ref(false);
const residualSurfaceTouched = ref(false);

const errors = ref<Record<string, string | undefined>>({});

const defaultData = {
    targetPartyId: null,
    transferredSurface: null,
    transferCause: null,
    transferDate: null,
    notes: null,
    authorizationId: null,
    nationalAuthorizationId: null,
    targetCuaa: null,
    residualSurface: null,
};

const formData = ref<AuthorizationTransferToCuaa>(defaultData);

const partyStore = usePartyStore();

const authorizationDetail = ref();

const reasonList = ref();

const today = new Date().toISOString().split("T")[0];
const release = ref();

const datePickerValue = ref();
onMounted(async () => {
    clearForm();
    isLoading.value = true;
    datePickerValue.value = document.getElementById("transferDateId");
    try {
        authorizationDetail.value = await getAuthorizationDetailById(
            +route.params.partyId,
            +route.params.authorizationId,
        );
        if (authorizationDetail.value) {
            isLoading.value = false;
            release.value = convertToDate(
                authorizationDetail.value?.releaseDate,
            );
        } else {
            isError.value = true;
            isLoading.value = false;
        }
        reasonList.value = await getTransferCauses();
        if (reasonList.value) {
            isLoading.value = false;
        } else {
            isError.value = true;
            isLoading.value = false;
        }

        formData.value = {
            targetPartyId: partyStore.getPartyId,
            transferredSurface: null,
            transferCause: "",
            transferDate: null,
            notes: null,
            authorizationId: authorizationDetail.value!.authorizationId,
            nationalAuthorizationId:
                authorizationDetail.value.nationalAuthorizationId ?? null,
            targetCuaa: null,
            residualSurface: toHectares(
                authorizationDetail.value!.residualSurface,
            ),
        };
    } catch (error) {
        console.error(error);
    } finally {
        isLoading.value = false;
    }
});

function validateForm(): boolean {
    errors.value = {};

    if (!formData.value.targetCuaa) {
        errors.value.targetCuaa = t("errors.form_not_completed");
    } else if (
        authorizationDetail.value &&
        formData.value.targetCuaa === authorizationDetail.value.cuaa
    ) {
        errors.value.targetCuaa = t("unit.errors.SAME_PARTY_ERROR");
    }

    if (
        !formData.value.transferredSurface &&
        formData.value.transferredSurface !== 0
    ) {
        errors.value.transferredSurface = t("errors.form_not_completed");
    } else if (formData.value.transferredSurface <= 0) {
        errors.value.transferredSurface = t(
            "errors.transferred_surface_gt_zero",
        );
    }

    if (!formData.value.transferCause) {
        errors.value.transferCause = t("errors.form_not_completed");
    }

    if (!formData.value.transferDate) {
        errors.value.transferDate = t("errors.form_not_completed");
    }

    const residual = parseFloat(String(formData.value.residualSurface)) || 0;
    const transferred =
        parseFloat(String(formData.value.transferredSurface)) || 0;
    if (transferredSurfaceTouched.value && residual <= transferred) {
        errors.value.transferredSurface = t(
            `errors.transferred_surface_overflow`,
            {
                initialParams: residual,
            },
        );
    }

    return Object.keys(errors.value).length === 0;
}

async function goBackToAuthList() {
    router.push({
        name: UnitRouteName.VINE_AUTHORIZATIONS_SUMMARY,
    });
}

async function goBackToDetailAuth() {
    router.back();
}

async function submitForm() {
    if (!validateForm()) {
        window.scrollTo({ top: 0, behavior: "smooth" });
        return;
    }

    formData.value.transferDate = String(
        formData.value.transferDate,
    ).replaceAll("-", "");
    isLoading.value = true;

    formData.value.transferredSurface = toSquareMeters(
        formData.value.transferredSurface,
    );
    formData.value.residualSurface = toSquareMeters(
        formData.value.residualSurface,
    );

    const response = await transferAuthorizationToCuaa(
        route.params.partyId as string,
        route.params.authorizationId as string,
        formData.value,
    );
    if (response) {
        isLoading.value = false;
        goBackToDetailAuth();
    } else {
        isError.value = true;
        window.scrollTo({
            top: 0,
            behavior: "smooth",
        });
    }
}

function clearForm() {
    formData.value = defaultData;
}

function setCuaa(msg: PartyModel) {
    formData.value.targetCuaa = msg.code;
    formData.value.targetPartyId = msg.partyId;
}

const searchFormVisible = ref<boolean>(false);

function getSearchFormVisibility(value: boolean) {
    searchFormVisible.value = value;
}
function checkResetData() {
    const datepickerElement = document.getElementById(
        "transferDateId",
    ) as HTMLInputElement | null;

    if (datepickerElement) {
        const transferDateStr = datepickerElement.value;

        const error = validateDateInRange({
            dateStr: transferDateStr,
            minDate: new Date(release.value),
            maxDate: new Date(today),
            errorMessage: ({ min }) =>
                t("errors.transfer_date_overflow", {
                    release: min,
                }),
        });

        errors.value.transferDate = error ?? "";
    }
}

async function handleTransferredSurfaceConstraint(e: Event) {
    transferredSurfaceTouched.value = true;
    const target = e.target as HTMLInputElement;
    if (target) {
        const nvalue = target.value.replace(/[^0-9-]/g, "");
        if (parseInt(nvalue) < 0) {
            formData.value.transferredSurface = null;
        }
    }
}
</script>

<template>
    <div v-if="!isLoading && !isError">
        <div class="row">
            <div class="row">
                <div class="col-6">
                    <h4>
                        {{ t(`authorizations.authorizations_to_cuaa`) }}
                    </h4>
                </div>

                <form @submit.prevent="submitForm">
                    <!-- ID Autorizzazione -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiInput
                            v-model="formData.authorizationId"
                            :label="t(`authorizations.authorization_id`)"
                            readonly
                            type="text"
                        ></BiInput>
                    </div>

                    <!-- ID Autorizzazione Nazionale -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiInput
                            v-model="formData.nationalAuthorizationId"
                            :label="
                                t(`authorizations.national_authorization_id`)
                            "
                            readonly
                        ></BiInput>
                    </div>

                    <!-- CUAA -->
                    <SubjectSearchForm
                        @search-form-visible="getSearchFormVisibility"
                        @selectedSubject="setCuaa"
                        :error="
                            errors.targetCuaa ? [errors.targetCuaa] : undefined
                        "
                        :value-cuaa="formData.targetCuaa"
                    ></SubjectSearchForm>

                    <!-- ID Superficie residua -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiInputFixed
                            v-model="formData.residualSurface"
                            :max="
                                parseFloat(formatArea(formData.residualSurface))
                            "
                            :label="t(`authorizations.residual_surface`) + '*'"
                            :placeholder="' '"
                            :step="0.0001"
                            :min="0.0"
                            :hide-arrows="false"
                            @input="residualSurfaceTouched = true"
                        />
                    </div>

                    <!-- Sup. Trasferita (Ha) -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiInputFixed
                            v-model="formData.transferredSurface"
                            :max="
                                parseFloat(
                                    formatArea(formData.transferredSurface),
                                )
                            "
                            :label="
                                t(`authorizations.transferred_surface`) + '*'
                            "
                            :placeholder="' '"
                            :step="0.0001"
                            :min="0.0"
                            :hide-arrows="false"
                            @input="handleTransferredSurfaceConstraint"
                            :errors="
                                errors.transferredSurface
                                    ? [errors.transferredSurface]
                                    : []
                            "
                        />
                    </div>

                    <!-- Motivo trasferimento -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiSelect
                            v-model="formData.transferCause"
                            :label="
                                t(`authorizations.reason_for_transfer`) + '*'
                            "
                            :items="reasonList || []"
                            item-value="id"
                            item-title="text"
                            required
                            :errors="
                                errors.transferCause
                                    ? [errors.transferCause]
                                    : undefined
                            "
                        />
                    </div>

                    <!-- Data trasferimento -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiDatepicker
                            id="transferDateId"
                            v-model="formData.transferDate"
                            :label="t(`authorizations.transferred_date`) + '*'"
                            required
                            class="mt-5"
                            :min="release"
                            :max="today"
                            :errors="
                                errors.transferDate
                                    ? [errors.transferDate]
                                    : undefined
                            "
                            @change="checkResetData"
                        />
                    </div>

                    <!-- Note -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiInput
                            v-model="formData.notes"
                            :label="t(`authorizations.notes`)"
                        ></BiInput>
                    </div>

                    <div class="text-start mt-5">
                        <BiButton
                            class="mt-3 me-2"
                            is-outlined
                            color="secondary"
                            @click="goBackToAuthList"
                        >
                            {{ t(`authorizations.cancel`) }}
                        </BiButton>
                        <BiButton
                            class="mt-3"
                            color="primary"
                            @click="submitForm"
                        >
                            {{ t(`authorizations.save`) }}
                        </BiButton>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div
        v-else-if="isLoading && !isError"
        class="d-flex col-12 justify-content-center mb-5"
    >
        <BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
    </div>
</template>
