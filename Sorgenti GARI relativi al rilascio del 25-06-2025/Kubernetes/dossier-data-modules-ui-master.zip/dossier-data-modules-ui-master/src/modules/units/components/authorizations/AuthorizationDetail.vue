<script setup lang="ts">
import AlertMessage from "@/components/AlertMessage.vue";
import useDateFormat from "@/composables/useDateFormat";
import { DDM_MODULE_ID } from "@/constants";
import t from "@/modules/units/utils/i18n";
import { areaSQMInHA, emptyFieldPlaceholder } from "@/utils/utils";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { onMounted, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import { convertToDate } from "@/utils/utils";
import { UnitRouteName } from "../../models/routes";
import { getAuthorizationDetailById } from "../../resources/api/authorizations";
import { useVineUnitStore } from "../../stores/vineUnit";
import { usePartyStore } from "../../stores/party";
import type { Authorization } from "../../models/authorization";

const { dateFormat } = useDateFormat();
const router = useRouter();
const route = useRoute();

const vineUnitStore = useVineUnitStore();
const partyStore = usePartyStore();

const authorizationDetail = ref<Authorization | null>(null);

onMounted(async () => {
    try {
        vineUnitStore.loadingCounter++;
        if (!vineUnitStore.aptitudesSummary.length) {
            await vineUnitStore.fetchAuthorizationSummaryList(
                +route.params.partyId,
                null,
            );
        }
        if (!vineUnitStore.aptitudesUvList.length) {
            await vineUnitStore.fetchAuthorizationsList(
                +route.params.partyId,
                route.params.authTypeCode.toString(),
                false,
                null,
            );
        }

        authorizationDetail.value = await getAuthorizationDetailById(
            +route.params.partyId,
            +route.params.authorizationId,
        );
    } catch (error) {
        console.error(error);
    } finally {
        vineUnitStore.loadingCounter--;
    }
});

function goToAuthorizationOrigin(authorizationDetailId: number | null) {
    if (authorizationDetailId) {
        router.push({
            name: UnitRouteName.VINE_AUTHORIZATION_ORIGIN,
            params: { authorizationDetailId },
        });
    }
}

function goToAuthorizationLinkedQuestion(authorizationDetailId: number | null) {
    if (authorizationDetailId) {
        router.push({
            name: UnitRouteName.VINE_AUTHORIZATION_LINKED_QUESTION,
            params: { authorizationDetailId },
        });
    }
}
</script>
<template>
    <template v-if="!authorizationDetail && vineUnitStore.loadingCounter === 0">
        <AlertMessage :modelValue="true" :dismissable="false" :level="'info'">
            {{ $t(`${DDM_MODULE_ID}.message.empty_list`) }}
        </AlertMessage>
    </template>
    <template v-else-if="authorizationDetail">
        <div class="row">
            <div class="col-12">
                <h4>
                    {{ t(`authorizations.authorization_detail`) }}
                </h4>
            </div>

            <div class="mt-3 row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.authorization_id`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Id Autorizzazione -->
                    {{ authorizationDetail.authorizationId }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.national_authorization_id`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Id Autorizzazione Nazionale -->
                    {{
                        emptyFieldPlaceholder(
                            authorizationDetail.nationalAuthorizationId,
                        )
                    }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.authorization_type`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Tipo autorizzazione -->
                    {{ authorizationDetail.authorizationType }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.cuaa`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- CUAA -->
                    {{ emptyFieldPlaceholder(partyStore.getCuaa) }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.origin_authorization_id`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Id Autorizzazione di provenienza -->
                    {{
                        emptyFieldPlaceholder(
                            authorizationDetail.originAuthorizationId,
                        )
                    }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{
                            t(`authorizations.origin_national_authorization_id`)
                        }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Id Autorizzazione Nazionale di provenienza -->
                    {{
                        emptyFieldPlaceholder(
                            authorizationDetail.nationalAuthorizationId,
                        )
                    }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.origin_right_id`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Id Diritto Provenienza -->
                    {{
                        emptyFieldPlaceholder(authorizationDetail.rightOriginId)
                    }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.region_origin`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Regione di provenienza -->
                    {{
                        emptyFieldPlaceholder(
                            authorizationDetail.originRegionCode,
                        )
                    }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.region_reference`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Regione di riferimento -->
                    {{
                        emptyFieldPlaceholder(
                            authorizationDetail.referredRegionCode,
                        )
                    }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.province_reference`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Provincia di riferimento -->
                    {{
                        emptyFieldPlaceholder(
                            authorizationDetail.referredProvinceCode,
                        )
                    }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.authorization_surface`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Sup. autorizzazione (ha) -->
                    {{
                        authorizationDetail.authorizationSurface
                            ? areaSQMInHA(
                                  authorizationDetail.authorizationSurface,
                              )
                            : "-"
                    }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.planted_surface`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Sup. impiantata (ha) -->
                    {{ areaSQMInHA(authorizationDetail.plantedSurface) }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.transferred_surface`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Sup. trasferita (ha) -->
                    {{ areaSQMInHA(authorizationDetail.transferredSurface) }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.residual_surface`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Sup. residua (ha) -->
                    {{ areaSQMInHA(authorizationDetail.residualSurface) }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.protocol_id`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Identificativo protocollo -->
                    {{ authorizationDetail.protocolId ?? "-" }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.protocol_date`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Data protocollo -->
                    {{
                        authorizationDetail.protocolDate
                            ? dateFormat(
                                  convertToDate(
                                      authorizationDetail.protocolDate,
                                  ),
                              )
                            : "-"
                    }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.typology_application`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Tipologia domanda -->
                    {{ authorizationDetail.applicationTypeCode ?? "-" }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.conversion_date`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Data conversione -->
                    {{
                        authorizationDetail.conversionDate
                            ? dateFormat(
                                  convertToDate(
                                      authorizationDetail.conversionDate,
                                  ),
                              )
                            : "-"
                    }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.application_id`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Id domanda -->
                    {{
                        emptyFieldPlaceholder(
                            authorizationDetail.authorizationId,
                        )
                    }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.notes`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Note -->
                    {{ emptyFieldPlaceholder(authorizationDetail.notes) }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.release_date`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Data rilascio -->
                    {{
                        dateFormat(
                            convertToDate(authorizationDetail.releaseDate),
                        )
                    }}
                </div>
            </div>
            <div class="row">
                <div class="col-3">
                    <p>
                        {{ t(`authorizations.expiration_date`) }}
                    </p>
                </div>
                <div class="col-9">
                    <!-- Data scadenza -->
                    {{
                        dateFormat(
                            convertToDate(authorizationDetail.expirationDate),
                        )
                    }}
                </div>
            </div>
        </div>

        <div class="mt-1 row">
            <div class="d-flex justify-content-center gap-4 p-3">
                <BiButton color="primary" isOutlined @click="router.go(-1)">
                    {{ t(`${DDM_MODULE_ID}.go_back`) }}
                </BiButton>

                <BiButton
                    color="primary"
                    isOutlined
                    @click="
                        goToAuthorizationOrigin(
                            authorizationDetail.authorizationId,
                        )
                    "
                >
                    {{ t(`authorizations.origin`) }}
                </BiButton>

                <BiButton
                    color="primary"
                    isOutlined
                    @click="
                        goToAuthorizationLinkedQuestion(
                            authorizationDetail.authorizationId,
                        )
                    "
                >
                    {{ t(`authorizations.linked_application`) }}
                </BiButton>
            </div>
        </div>
    </template>
</template>
