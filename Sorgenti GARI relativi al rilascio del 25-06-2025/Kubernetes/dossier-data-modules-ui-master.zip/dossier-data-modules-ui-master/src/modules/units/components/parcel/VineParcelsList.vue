<script setup lang="ts">
import useDateFormat from "@/composables/useDateFormat";
import useQueryFilter from "@/composables/useQueryFilter";
import { UnitRouteName } from "@/modules/units/models/routes";
import type { Parcel } from "@/modules/units/models/vineUnit";
import { getParcels } from "@/modules/units/resources/api/vineUnit";
import { useVineUnitStore } from "@/modules/units/stores/vineUnit";
import t from "@/modules/units/utils/i18n";
import { getPortalBaseURL } from "@/utils/urlUtils";
import { areaSQMInHA, formatDate } from "@/utils/utils";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiChip from "@abaco/bootstrap-italia-components/src/components/BiChip/BiChip.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { parseISO } from "date-fns";
import { onMounted, ref, watch } from "vue";
import { useRoute, useRouter } from "vue-router";
import AnomaliesIcon from "./AnomaliesIcon.vue";
import FilterParcels from "./VineFilterParcels.vue";
import { usePermissionsStore } from "../../stores/unitPermissions";

const { dateFormat } = useDateFormat();
const route = useRoute();
const router = useRouter();

const vineUnitStore = useVineUnitStore();
const permissionsStore = usePermissionsStore();
const parcels = ref<Parcel[]>([]);
const nextKey = ref<string | null>(null);

const { filter: dateFilter } = useQueryFilter("date");
const { filter: sector, hasValue: hasSector } = useQueryFilter("sector");
const { filter: sheet, hasValue: hasSheet } = useQueryFilter("sheet");
const { filter: code, hasValue: hasCode } = useQueryFilter("code");
const { filter: variety, hasValue: hasVariety } = useQueryFilter("variety");

onMounted(async () => {
    if (!vineUnitStore.sectorSummary.length)
        await vineUnitStore.fetchVineUnitBySector(
            +route.params.partyId,
            formatDate(vineUnitStore.curDate),
        );
    if (!vineUnitStore.varietySummary.length)
        await vineUnitStore.fetchVineUnitByVariety(
            +route.params.partyId,
            formatDate(vineUnitStore.curDate),
        );
    fetchParcelList(nextKey.value, false);
});

function onShowParcelFilter() {
    vineUnitStore.showParcelFilter = true;
}

function getVineUnitsCount(parcel: Parcel) {
    let count = 0;
    parcel.landcovers_list.forEach((l) => (count += l.vine_units.length));
    return count;
}

function getVarietyWithHighestArea(parcel: Parcel): string | undefined {
    const res = new Map<string, number>();

    parcel.landcovers_list.forEach((l) => {
        l.vine_units.forEach((v) => {
            if (v.variety)
                if (res.has(v.variety.description)) {
                    res.set(
                        v.variety.description,
                        res.get(v.variety.description)! + v.area_sqm,
                    );
                } else {
                    res.set(v.variety.description, v.area_sqm);
                }
        });
    });

    let maxArea = 0;
    let mainVariety: string | undefined;

    res.forEach((area, variety) => {
        if (area > maxArea) {
            maxArea = area;
            mainVariety = variety;
        }
    });

    return mainVariety;
}

function onParcelsFilter(response: {
    count: number;
    records: Parcel[];
    nextKey: string | null;
}) {
    parcels.value = response.records;
    vineUnitStore.showParcelFilter = false;
    nextKey.value = null;
}

async function fetchParcelList(nk: string | null, loadMore: boolean) {
    vineUnitStore.loadingCounter++;
    const res = await getParcels(
        {
            parcelCode: null,
            parcelSheet: null,
            referenceDate: null,
            sector: sector.value,
            variety: variety.value,
            anomalyCode: null,
        },
        +route.params.partyId,
        nk,
    );
    if (loadMore) parcels.value.push(...res.records);
    else parcels.value = res.records;
    nextKey.value = res.nextKey;
    vineUnitStore.loadingCounter--;
}

function goToDetail(id: number) {
    router.push({
        name: UnitRouteName.VINE_PARCELS_DETAIL,
        query: {
            date: route.query.date,
        },
        params: { parcelId: id },
    });
}

// Open in readOnly
function openViewerUrl(sectorCode: string, parcelId: string | number) {
    const backUrl = window.location.href.replace(window.location.origin, "");
    window.location.assign(
        `${getPortalBaseURL()}/lpis-vine-viewer/party/${+route.params.partyId}/sector/${sectorCode}/parcel/${parcelId}?backUrl=${encodeURIComponent(backUrl)}`,
    );
}

// Open is editModel
function openEditorUrl(parcelId: number) {
    const backUrl = window.location.href.replace(window.location.origin, "");
    window.location.assign(
        `${getPortalBaseURL()}/vine-editor/parcel/${parcelId}?backUrl=${encodeURIComponent(backUrl)}`,
    );
}

watch([hasSector, hasSheet, hasCode, hasVariety], async () => {
    if (!vineUnitStore.showParcelFilter) {
        await fetchParcelList(nextKey.value, false);
    }
});
</script>

<template>
    <FilterParcels
        v-if="vineUnitStore.showParcelFilter"
        @back:to:list="vineUnitStore.showParcelFilter = false"
        @filter:parcels="(p) => onParcelsFilter(p)"
    />
    <div v-else>
        <div class="row">
            <div class="d-flex justify-content-between col-12">
                <h4>{{ t(`parcels.parcels`) }}</h4>
                <BiButton
                    color="primary"
                    isOutlined
                    @click="onShowParcelFilter"
                >
                    {{ t(`parcels.filter.filter_parcels`) }}
                </BiButton>
            </div>
            <div class="col-12">
                <div class="d-flex mt-3">
                    <BiChip
                        :label="`${t(`filter.referenceDate`)}: ${dateFormat(parseISO(dateFilter))}`"
                    />
                    <BiChip
                        v-model="hasSector"
                        isDelete
                        :label="`${t(`filter.sector`)}: ${vineUnitStore.sectorSummary.find((s) => s.sector.sector_code === sector)?.sector.description}`"
                    />

                    <BiChip
                        v-model="hasSheet"
                        isDelete
                        :label="`${t(`filter.parcelSheet`)}: ${sheet}`"
                    />

                    <BiChip
                        v-model="hasCode"
                        isDelete
                        :label="`${t(`filter.parcelCode`)}: ${code}`"
                    />

                    <BiChip
                        v-model="hasVariety"
                        isDelete
                        :label="`${t(`filter.variety`)}: ${vineUnitStore.varietySummary.find((v) => v.variety.code === variety)?.variety.description}`"
                    />
                </div>
                <BiTable
                    is-row-hover
                    is-header-light
                    is-custom
                    responsive-breakpoint="md"
                    :next-key="nextKey"
                    :load-more-label="t(`load_more`)"
                    @load-more="fetchParcelList(nextKey, true)"
                    class="mt-3"
                >
                    <template #head>
                        <tr class="text-primary">
                            <th scope="col">
                                {{ t(`parcels.parcel_code`) }}
                            </th>
                            <th scope="col">
                                {{ t(`parcels.area`) }}
                            </th>
                            <th scope="col">
                                {{ t(`parcels.vu_num`) }}
                            </th>
                            <th scope="col">
                                {{ t(`parcels.main_variety`) }}
                            </th>
                            <th scope="col">
                                {{ t(`parcels.anomalies`) }}
                            </th>
                            <th scope="col"></th>
                        </tr>
                    </template>
                    <template #body>
                        <tr
                            v-for="parcel in parcels"
                            :key="parcel.id"
                            class="align-middle"
                        >
                            <td :data-label="t(`parcels.parcel_code`)">
                                <small>
                                    {{ parcel.sector.sector_code }} -
                                    {{ parcel.sector.short_descr }} -
                                    {{ parcel.block.short_descr }} -
                                    {{ parcel.parcel }}
                                </small>
                            </td>
                            <td :data-label="t(`parcels.area`)">
                                <small>{{
                                    parcel.area_sqm
                                        ? areaSQMInHA(parcel.area_sqm)
                                        : ""
                                }}</small>
                            </td>
                            <td :data-label="t(`parcels.vu_num`)">
                                <small>{{ getVineUnitsCount(parcel) }}</small>
                            </td>
                            <td :data-label="t(`parcels.main_variety`)">
                                <small>{{
                                    getVarietyWithHighestArea(parcel)
                                }}</small>
                            </td>
                            <td :data-label="t(`parcels.anomalies`)">
                                <AnomaliesIcon
                                    :anomalies="
                                        parcel.anomalies?.anomalies_list
                                    "
                                />
                            </td>
                            <td>
                                <small class="d-flex justify-content-end">
                                    
                                    <BiIconButton
                                        v-if="permissionsStore.vineGisViewer"
                                        class="mx-1"
                                        icon="map"
                                        iconStyle="fas"
                                        color="primary"
                                        isOutlined
                                        @click="
                                            openViewerUrl(
                                                parcel.sector.sector_code,
                                                parcel.id,
                                            )
                                        "
                                    />
                                    <BiIconButton
                                        v-if="permissionsStore.vineGisEditor"
                                        class="mx-1"
                                        icon="pen"
                                        iconStyle="fas"
                                        color="primary"
                                        isOutlined
                                        @click="openEditorUrl(parcel.id)"
                                    />
                                    <BiIconButton
                                        class="mx-1"
                                        icon="arrow-right"
                                        iconStyle="fas"
                                        color="primary"
                                        isOutlined
                                        @click="goToDetail(parcel.id)"
                                    />
                                </small>
                            </td>
                        </tr>
                    </template>
                </BiTable>
            </div>
        </div>
    </div>
</template>
