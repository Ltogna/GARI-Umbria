<script setup lang="ts">
import useDateFormat from "@/composables/useDateFormat";
import t from "@/modules/units/utils/i18n";
import { convertToDate } from "@/utils/utils";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import { ref } from "vue";

const { dateFormat } = useDateFormat();
const selectedModule = ref<string>("1");

const modules = [
    {
        id: "1",
        text: "(Tutti)",
    },
    {
        id: "2",
        text: "Test 1",
    },
    {
        id: "3",
        text: "Test 3",
    },
];

const applications = [
    {
        id: 1,
        module: "ESTIRPO - REIMPIANTO ANTICIPATO",
        dtCreation: "20240904",
        dtLastMovement: "20240604",
        status: "AUTORIZZATA",
    },
];

function goToQuestionDetail(linkedQuestionId: number) {
    // TODO - NAVIGATE TO LINKEDQUESTIONDETAIL
    console.log(linkedQuestionId);
    // router.push({
    //     name: VineUnitRouteName.APTITUDES_DETAIL,
    //     params: { parcelId, landCoverId, vineUnitId, vineAptitudeId },
    // });
}
</script>
<template>
    <div class="row">
        <div class="col-12">
            <h4>
                {{ t(`applications.sector_applications`) }}
            </h4>
        </div>
    </div>
    <div class="mt-3 row">
        <div class="col-3">
            <BiSelect
                :items="modules"
                :label="t(`applications.filter_module`)"
                v-model="selectedModule"
            />
        </div>
    </div>
    <div class="mt-3 row">
        <div class="col-12">
            <BiTable
                is-row-hover
                is-header-light
                is-custom
                responsive-breakpoint="md"
            >
                <template #head>
                    <tr class="text-primary">
                        <th scope="col">
                            {{ t(`applications.module`) }}
                        </th>
                        <th scope="col">
                            {{ t(`applications.dt_creation`) }}
                        </th>
                        <th scope="col">
                            {{ t(`applications.dt_last_movement`) }}
                        </th>
                        <th scope="col">
                            {{ t(`applications.status`) }}
                        </th>
                        <th scope="col"></th>
                    </tr>
                </template>
                <template #body>
                    <tr
                        v-for="application in applications"
                        :key="application.id"
                        class="align-middle"
                    >
                        <td :data-label="t(`applications.module`)">
                            <small> {{ application.module }}</small>
                        </td>
                        <td :data-label="t(`applications.dt_creation`)">
                            <small>
                                {{
                                    dateFormat(
                                        convertToDate(application.dtCreation),
                                    )
                                }}
                            </small>
                        </td>
                        <td :data-label="t(`applications.dt_last_movement`)">
                            <small>
                                {{
                                    dateFormat(
                                        convertToDate(
                                            application.dtLastMovement,
                                        ),
                                    )
                                }}
                            </small>
                        </td>
                        <td :data-label="t(`applications.status`)">
                            <small> {{ application.status }}</small>
                        </td>
                        <!-- TODO - PROBABLY THIS BTN WILL BE HIDE FOR THE v1.2 -->
                        <td class="text-end">
                            <BiIconButton
                                class="mx-1"
                                icon="arrow-right"
                                iconStyle="fas"
                                color="primary"
                                isOutlined
                                @click="goToQuestionDetail(application.id)"
                            />
                        </td>
                    </tr>
                </template>
            </BiTable>
        </div>
    </div>
</template>
