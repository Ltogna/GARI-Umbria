<script setup lang="ts">
import AlertMessage from "@/components/AlertMessage.vue";
import { DDM_MODULE_ID } from "@/constants";
import { UnitRouteName } from "@/modules/units/models/routes";
import t from "@/modules/units/utils/i18n";
import { useDdmStore } from "@/stores/ddmStore";
import { getPortalBaseURL } from "@/utils/urlUtils";
import { areaSQMInHA, formatDate } from "@/utils/utils";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { computed, onMounted, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import { VineUnitStatusEnum } from "../../models/vineUnit";
import { getAptitudesUvListByCode } from "../../resources/api/aptitudes";
import { useVineUnitStore } from "../../stores/vineUnit";
import { usePermissionsStore } from "../../stores/unitPermissions";

const router = useRouter();
const route = useRoute();

const vineUnitStore = useVineUnitStore();
const permissionsStore = usePermissionsStore();
const ddmStore = useDdmStore();
const nextKey = ref<string | null>(null);

onMounted(async () => {
    try {
        vineUnitStore.loadingCounter++;
        if (!vineUnitStore.aptitudesSummary.length) {
            await vineUnitStore.fetchAptitudeSummaryList(+route.params.partyId);
        }

        await fetchAptitudesUvList(nextKey.value, false);
    } catch (error) {
        // TODO - HANDLE ERROR
        console.error(error);
    } finally {
        vineUnitStore.loadingCounter--;
    }
});

const isErrorEmptyShown = computed(() => {
    return (
        !vineUnitStore.aptitudesUvList.length &&
        vineUnitStore.loadingCounter === 0 &&
        ddmStore.loadingCounter === 0
    );
});

const title = computed(() => {
    const currentAptitude = vineUnitStore.aptitudesSummary.find(
        (aptitude) => aptitude.doIgt.code === route.params.doIgtCode.toString(),
    );

    if (currentAptitude) {
        return `
            ${t(`aptitudes.aptitude`)}:
            ${currentAptitude.doIgt.code} -
            ${currentAptitude.doIgt.category_description} -
            ${currentAptitude.doIgt.name_description} -
            ${currentAptitude.doIgt.description}
        `;
    }

    // TODO - ELABORARE UNA FALLBACK
    return `Error on retrieving aptitude`;
});

async function fetchAptitudesUvList(nk: string | null, loadMore: boolean) {
    vineUnitStore.loadingCounter++;
    const res = await getAptitudesUvListByCode(
        +route.params.partyId,
        formatDate(vineUnitStore.curDate),
        route.params.doIgtCode.toString(),
        nk,
    );
    if (loadMore) vineUnitStore.aptitudesUvList.push(...res.records);
    else vineUnitStore.aptitudesUvList = res.records;
    nextKey.value = res.nextKey;
    vineUnitStore.loadingCounter--;
}

function goToAptitudeDetail(
    parcelId: number,
    landCoverId: number,
    vineUnitId: number,
    vineAptitudeId: number,
) {
    router.push({
        name: UnitRouteName.VINE_APTITUDES_DETAIL,
        params: { parcelId, landCoverId, vineUnitId, vineAptitudeId },
    });
}

function openViewerUrl(sectorCode: string, parcelId: string | number) {
    const backUrl = window.location.href.replace(window.location.origin, "");
    window.location.assign(
        `${getPortalBaseURL()}/lpis-vine-viewer/party/${+route.params.partyId}/sector/${sectorCode}/parcel/${parcelId}?backUrl=${encodeURIComponent(backUrl)}`,
    );
}

/**
 * Opens the URL for the attitude detail page for a specific parcel.
 *
 * @param {number} parcelId - The ID of the parcel.
 */
function openEditorUrl(
    parcelId: number,
    // landCoverId: number,
    // vineUnitId: number,
    // aptitudeId: number,
) {
    const backUrl = window.location.href.replace(window.location.origin, "");
    window.location.assign(
        `${getPortalBaseURL()}/vine-editor/parcel/${parcelId}?backUrl=${encodeURIComponent(backUrl)}`,
    );
}
</script>
<template>
    <div class="row">
        <div class="col-12">
            <h4>
                {{ title }}
            </h4>

            <p class="mt-5 mb-2">
                <strong>
                    {{ t(`aptitudes.units`) }}
                </strong>
            </p>
            <BiTable
                is-row-hover
                is-header-light
                is-custom
                responsive-breakpoint="md"
                :next-key="nextKey"
                :load-more-label="t(`load_more`)"
                @load-more="fetchAptitudesUvList(nextKey, true)"
            >
                <template #head>
                    <tr class="text-primary">
                        <th scope="col">
                            {{ t(`parcels.parcel_code`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.vu`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.variety`) }}
                        </th>
                        <th scope="col">
                            {{ t(`aptitudes.surface`) }}
                        </th>
                        <th scope="col">
                            {{ t(`aptitudes.registered_surface`) }}
                        </th>
                        <th scope="col">
                            {{ t(`aptitudes.block_typology`) }}
                        </th>
                        <th scope="col">
                            {{ t(`aptitudes.block_claims`) }}
                        </th>
                        <th scope="col">
                            {{ t(`aptitudes.block_eligibility`) }}
                        </th>
                        <!-- TODO - Reintroduce when we will get the property from the BE -->
                        <!-- <th scope="col">
                            {{ t(`aptitudes.drawing`) }}
                        </th> -->
                        <th scope="col"></th>
                    </tr>
                </template>
                <template #body>
                    <tr
                        v-for="aptitudeUv in vineUnitStore.aptitudesUvList"
                        :key="aptitudeUv.vineUnitId"
                        class="align-middle"
                    >
                        <td :data-label="t(`parcels.parcel_code`)">
                            <small>
                                {{ aptitudeUv.sector.sector_code }} -
                                {{ aptitudeUv.sector.short_descr }} -
                                {{ aptitudeUv.block.short_descr }} -
                                {{ aptitudeUv.parcelCode }}
                            </small>
                        </td>
                        <td :data-label="t(`parcels.vu`)">
                            <small>{{ aptitudeUv.vineUnitCode }}</small>
                        </td>
                        <td :data-label="t(`parcels.variety`)">
                            <small>{{ aptitudeUv.variety.description }}</small>
                        </td>
                        <td :data-label="t(`aptitudes.surface`)">
                            <small>{{ areaSQMInHA(aptitudeUv.areaSqm) }}</small>
                        </td>
                        <td :data-label="t(`aptitudes.registered_surface`)">
                            <small>{{
                                areaSQMInHA(aptitudeUv.registeredAreaSmq)
                            }}</small>
                        </td>
                        <td :data-label="t(`aptitudes.block_typology`)">
                            <small>{{
                                aptitudeUv.preventTypology
                                    ? VineUnitStatusEnum.YES
                                    : VineUnitStatusEnum.NO
                            }}</small>
                        </td>
                        <td :data-label="t(`aptitudes.block_claims`)">
                            <small>{{
                                aptitudeUv.preventClaim
                                    ? VineUnitStatusEnum.YES
                                    : VineUnitStatusEnum.NO
                            }}</small>
                        </td>
                        <td :data-label="t(`aptitudes.block_eligibility`)">
                            <small>{{
                                aptitudeUv.preventSuitability
                                    ? VineUnitStatusEnum.YES
                                    : VineUnitStatusEnum.NO
                            }}</small>
                        </td>
                        <!-- TODO - Reintroduce when we will get the property from the BE -->
                        <!-- <td">
                            <small>{{ aptitudeUv.drawing }}</small>
                        </td> -->
                        <td>
                            <small class="d-flex justify-content-end">
                                <BiIconButton
                                    v-if="permissionsStore.vineGisViewer"
                                    class="mx-1"
                                    icon="map"
                                    iconStyle="fas"
                                    color="primary"
                                    isOutlined
                                    @click="
                                        openViewerUrl(
                                            aptitudeUv.sector.sector_code,
                                            aptitudeUv.parcelId,
                                        )
                                    "
                                />
                                <BiIconButton
                                    v-if="permissionsStore.vineGisEditor"
                                    class="mx-1"
                                    icon="pen"
                                    iconStyle="fas"
                                    color="primary"
                                    isOutlined
                                    @click="openEditorUrl(aptitudeUv.parcelId)"
                                />
                                <BiIconButton
                                    class="mx-1"
                                    icon="arrow-right"
                                    iconStyle="fas"
                                    color="primary"
                                    isOutlined
                                    @click="
                                        goToAptitudeDetail(
                                            aptitudeUv.parcelId,
                                            aptitudeUv.landCoverId,
                                            aptitudeUv.vineUnitId,
                                            aptitudeUv.vineAptitudeId,
                                        )
                                    "
                                />
                            </small>
                        </td>
                    </tr>
                </template>
            </BiTable>

            <AlertMessage
                :modelValue="isErrorEmptyShown"
                :dismissable="false"
                :level="'info'"
            >
                {{ t(`${DDM_MODULE_ID}.message.empty_list`) }}
            </AlertMessage>
        </div>
    </div>
</template>
