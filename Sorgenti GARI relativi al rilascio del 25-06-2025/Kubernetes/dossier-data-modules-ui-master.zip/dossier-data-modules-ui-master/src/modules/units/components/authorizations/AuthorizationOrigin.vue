<script setup lang="ts">
import t from "@/modules/units/utils/i18n";
import { areaSQMInHA } from "@/utils/utils";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { onMounted, ref } from "vue";
import { useRoute } from "vue-router";
import type { AptitudeSummaryList } from "../../models/vineUnit";
import { getAuthorizationDetailById } from "../../resources/api/authorizations";
import { useVineUnitStore } from "../../stores/vineUnit";
import type { Authorization } from "../../models/authorization";

const route = useRoute();

const vineUnitStore = useVineUnitStore();
const authorizationDetail = ref<Authorization | null>(null);

onMounted(async () => {
    try {
        vineUnitStore.loadingCounter++;
        if (!vineUnitStore.aptitudesSummary.length) {
            await vineUnitStore.fetchAuthorizationSummaryList(
                +route.params.partyId,
                null,
            );
        }
        if (!vineUnitStore.aptitudesUvList.length) {
            await vineUnitStore.fetchAuthorizationsList(
                +route.params.partyId,
                route.params.authTypeCode.toString(),
                false,
                null,
            );
        }

        authorizationDetail.value = await getAuthorizationDetailById(
            +route.params.partyId,
            +route.params.authorizationId,
        );
    } catch (error) {
        console.error(error);
    } finally {
        vineUnitStore.loadingCounter--;
    }
});

const applications = [
    {
        id: 1,
        code: "123456",
        parcelCode: "C957 CONEGLIANO (TV) - 1 - 1",
        uv: "1",
        variety: "GLERA",
        monthYearImplant: "3/2012",
        plantingLayout: "100x300",
        breeding: "SPLLIERA - SYLVOZ",
        authorizedSurface: "1.0144",
    },
];

const originAptitudeDoIgtList: AptitudeSummaryList = [
    {
        doIgt: {
            id: 1,
            code: "DOC",
            description: "",
            category_code: "B399X2001",
            category_description: "PROSECCO DI CONEGLIANO",
            name_code: "",
            name_description: "PROSECCO",
            visible: false,
        },
        areaSqm: 30454,
        areaTypology: 66,
        areaClaims: 0,
        areaSuitability: 0,
    },
    {
        doIgt: {
            id: 2,
            code: "IGT",
            description: "",
            category_code: "B420X8881",
            category_description: "VENEZIA BIANCO",
            name_code: "",
            name_description: "VENEZIA",
            visible: false,
        },
        areaSqm: 4562,
        areaTypology: 0,
        areaClaims: 0,
        areaSuitability: 0,
    },
];
</script>
<template>
    <div class="row">
        <div class="block col-12">
            <h4>
                {{ t(`authorizations.origin`) }}
                {{ t(`authorizations.authorization`) }}
            </h4>
        </div>
    </div>
    <div class="row">
        <div class="col-3">
            <p>{{ t(`authorizations.authorization_id`) }}</p>
        </div>
        <div class="col-9">{{ authorizationDetail?.authorizationId }}</div>
    </div>
    <div class="row">
        <div class="col-3">
            <p>
                {{ t(`authorizations.national_authorization_id`) }}
            </p>
        </div>
        <div class="col-9">
            {{ authorizationDetail?.nationalAuthorizationId }}
        </div>
    </div>
    <div class="mt-3 row">
        <div class="col-12">
            <BiTable
                is-row-hover
                is-header-light
                is-custom
                responsive-breakpoint="md"
            >
                <template #head>
                    <tr class="text-primary">
                        <th scope="col">
                            {{ t(`authorizations.application`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.parcel`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.uv`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.variety`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.month_year_implant`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.planting_layout`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.breeding`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.authorized_surface`) }}
                        </th>
                    </tr>
                </template>
                <template #body>
                    <tr
                        v-for="application in applications"
                        :key="application.id"
                        class="align-middle"
                    >
                        <td :data-label="t(`authorizations.application`)">
                            <small> {{ application.code }}</small>
                        </td>
                        <td :data-label="t(`parcels.parcel`)">
                            <small> {{ application.parcelCode }}</small>
                        </td>
                        <td :data-label="t(`authorizations.uv`)">
                            <small> {{ application.uv }}</small>
                        </td>
                        <td :data-label="t(`parcels.variety`)">
                            <small> {{ application.variety }}</small>
                        </td>
                        <td
                            :data-label="t(`authorizations.month_year_implant`)"
                        >
                            <small> {{ application.monthYearImplant }}</small>
                        </td>
                        <td :data-label="t(`authorizations.planting_layout`)">
                            <small> {{ application.plantingLayout }}</small>
                        </td>
                        <td :data-label="t(`authorizations.breeding`)">
                            <small> {{ application.breeding }}</small>
                        </td>
                        <td
                            :data-label="t(`authorizations.authorized_surface`)"
                        >
                            <small> {{ application.authorizedSurface }}</small>
                        </td>
                    </tr>
                </template>
            </BiTable>
        </div>
    </div>

    <div class="mt-5 row">
        <div class="col-12">
            <h4>
                {{ t(`aptitudes.do_igt_origin_attitudes`) }}
            </h4>
        </div>
        <div class="col-12">
            <BiTable
                is-row-hover
                is-header-light
                is-custom
                responsive-breakpoint="md"
            >
                <template #head>
                    <tr class="text-primary">
                        <th scope="col">
                            {{ t(`aptitudes.category`) }}
                        </th>
                        <th scope="col">
                            {{ t(`aptitudes.name`) }}
                        </th>
                        <th scope="col">
                            {{ t(`code`) }}
                        </th>
                        <th scope="col">
                            {{ t(`aptitudes.typology`) }}
                        </th>
                        <th scope="col">
                            {{ t(`aptitudes.surface`) }}
                        </th>
                        <th scope="col">
                            {{ t(`aptitudes.block_surface_typology`) }}
                        </th>
                        <th scope="col">
                            {{ t(`aptitudes.block_surface_claims`) }}
                        </th>
                        <th scope="col">
                            {{ t(`aptitudes.block_surface_eligibility`) }}
                        </th>
                    </tr>
                </template>
                <template #body>
                    <tr
                        v-for="originAptitudeDoIgt in originAptitudeDoIgtList"
                        :key="originAptitudeDoIgt.doIgt.id"
                        class="align-middle"
                    >
                        <td :data-label="t(`aptitudes.category`)">
                            <small>
                                {{
                                    originAptitudeDoIgt.doIgt
                                        .category_description
                                }}
                            </small>
                        </td>
                        <td :data-label="t(`aptitudes.name`)">
                            <small>
                                {{ originAptitudeDoIgt.doIgt.name_description }}
                            </small>
                        </td>
                        <td :data-label="t(`code`)">
                            <small>{{ originAptitudeDoIgt.doIgt.code }}</small>
                        </td>
                        <td :data-label="t(`aptitudes.typology`)">
                            <small>
                                {{ originAptitudeDoIgt.doIgt.description }}
                            </small>
                        </td>
                        <td :data-label="t(`aptitudes.surface`)">
                            <small>
                                {{ areaSQMInHA(originAptitudeDoIgt.areaSqm) }}
                            </small>
                        </td>
                        <td :data-label="t(`aptitudes.block_surface_typology`)">
                            <small>
                                {{
                                    areaSQMInHA(
                                        originAptitudeDoIgt.areaTypology,
                                    )
                                }}
                            </small>
                        </td>
                        <td :data-label="t(`aptitudes.block_surface_claims`)">
                            <small>
                                {{
                                    areaSQMInHA(originAptitudeDoIgt.areaClaims)
                                }}
                            </small>
                        </td>
                        <td
                            :data-label="
                                t(`aptitudes.block_surface_eligibility`)
                            "
                        >
                            <small>{{
                                areaSQMInHA(originAptitudeDoIgt.areaSuitability)
                            }}</small>
                        </td>
                    </tr>
                </template>
            </BiTable>
        </div>
    </div>
</template>
