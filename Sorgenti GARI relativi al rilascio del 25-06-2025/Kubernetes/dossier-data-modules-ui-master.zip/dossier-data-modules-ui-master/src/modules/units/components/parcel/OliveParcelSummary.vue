<script setup lang="ts">
import useDateFormat from "@/composables/useDateFormat";
import useQueryFilter from "@/composables/useQueryFilter";
import type { CodeDescriptionPair } from "@/modules/units/models/oliveUnit";
import { UnitRouteName } from "@/modules/units/models/routes";
import { useOliveUnitStore } from "@/modules/units/stores/oliveUnit";
import t from "@/modules/units/utils/i18n";
import { formatDate } from "@/utils/utils";
import BiChip from "@abaco/bootstrap-italia-components/src/components/BiChip/BiChip.vue";
import BiRadiobutton from "@abaco/bootstrap-italia-components/src/components/form/BiRadiobutton.vue";
import { formatISO, isValid, parseISO } from "date-fns";
import { onMounted, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import TerritorySummary from "./summaries/TerritorySummary.vue";
import VarietySummary from "./summaries/VarietySummary.vue";

const { dateFormat } = useDateFormat();
const router = useRouter();
const route = useRoute();
const oliveUnitStore = useOliveUnitStore();

const { filter: dateFilter } = useQueryFilter("date");

const radioValue = {
    territory: t(`parcels.territory`),
    variety: t(`parcels.variety`),
};

onMounted(async () => {
    if (dateFilter.value === "" || !isValid(parseISO(dateFilter.value))) {
        dateFilter.value = formatISO(oliveUnitStore.curDate, {
            representation: "date",
        });
    }

    selectValue.value = radioValue.territory;
    await oliveUnitStore.fetchOliveUnitBySector(
        +route.params.partyId,
        formatDate(oliveUnitStore.curDate),
    );
    await oliveUnitStore.fetchOliveUnitByVariety(
        +route.params.partyId,
        formatDate(oliveUnitStore.curDate),
    );
});

const selectValue = ref("");

function goToList(value: CodeDescriptionPair) {
    if (!value) return;
    switch (selectValue.value) {
        case radioValue.variety:
            router.push({
                name: UnitRouteName.OLIVE_PARCELS,
                query: {
                    ...route.query,
                    variety: value.code,
                },
            });
            break;
        case radioValue.territory:
            router.push({
                name: UnitRouteName.OLIVE_PARCELS,
                query: {
                    ...route.query,
                    sector: value.code,
                },
            });
            break;
    }
}
</script>
<template>
    <div class="row">
        <div class="col-12">
            <h4>{{ t(`parcels.parcels`) }}</h4>
        </div>
    </div>
    <div class="row">
        <div class="my-3 col-12">
            <BiChip
                v-if="dateFilter"
                :label="
                    t(`conduction_to_date`) +
                    `: ${dateFormat(parseISO(dateFilter))}`
                "
            />
        </div>
    </div>
    <div class="row">
        <div class="d-flex align-items-center col-4">
            <div>
                <div>
                    <strong>
                        {{ t(`parcels.count_parcels`) }}:
                        {{ oliveUnitStore.totalParcels }}
                    </strong>
                </div>
                <div>
                    <strong>
                        {{ t(`parcels.count_vu`) }}:
                        {{ oliveUnitStore.totalOliveUnits }}
                    </strong>
                </div>
            </div>
        </div>
        <div class="d-flex align-items-center col-4">
            <div>{{ t(`view`) }}:</div>
            <div class="ms-3">
                <BiRadiobutton
                    v-model="selectValue"
                    :name="radioValue.territory"
                    :label="t(`parcels.territory`)"
                    :value="radioValue.territory"
                />
                <BiRadiobutton
                    v-model="selectValue"
                    :name="radioValue.variety"
                    :label="t(`parcels.variety`)"
                    :value="radioValue.variety"
                />
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <TerritorySummary
                v-if="selectValue === radioValue.territory"
                :sector-summary-list="oliveUnitStore.sectorSummary"
                :loading-counter="oliveUnitStore.loadingCounter"
                @go:to:list="(value) => goToList(value)"
            />

            <VarietySummary
                v-else
                :variety-summary-list="oliveUnitStore.varietySummary"
                :loading-counter="oliveUnitStore.loadingCounter"
                @go:to:list="(value) => goToList(value)"
            />
        </div>
    </div>
</template>
