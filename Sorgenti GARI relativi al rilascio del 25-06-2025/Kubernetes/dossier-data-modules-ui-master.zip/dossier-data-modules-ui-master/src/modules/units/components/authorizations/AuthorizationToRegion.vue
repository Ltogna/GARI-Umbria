<script setup lang="ts">
import t from "@/modules/units/utils/i18n";
import { onMounted, ref } from "vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import { useRoute, useRouter } from "vue-router";
import { UnitRouteName } from "../../models/routes";
import {
    authToRegionTransfer,
    getAuthorizationByPartyId,
    getItalianRegions,
} from "../../resources/api/authorizations";
import type { AuthorizationToRegionType } from "../../models/authorization";
import BiInputFixed from "./BiInputFixed.vue";
import {
    convertToDate,
    validateDateInRange,
    toHectares,
    formatArea,
    toSquareMeters,
} from "@/utils/utils";

const isLoading = ref<boolean>(false);
const isError = ref<boolean>(false);

const router = useRouter();
const route = useRoute();

const transferredSurfaceTouched = ref(false);
const errors = ref<Record<string, string | undefined>>({});

const today = new Date().toISOString().split("T")[0];
const release = ref();

let authorizationId: string;

const datePickerValue = ref();

const formData = ref<AuthorizationToRegionType>({
    authorizationId: null,
    nationalAuthorizationId: null,
    regionReference: null,
    residualSurface: null,
    transferredSurface: null,
    transferredDate: null,
    note: null,
});

const regionList = ref();
const authorizationDetail = ref();

onMounted(async () => {
    authorizationId = route.params.authorizationId?.toString();
    datePickerValue.value = document.getElementById("transferDateId");

    isLoading.value = true;
    regionList.value = await getItalianRegions();
    if (regionList.value) {
        isLoading.value = false;
    } else {
        isError.value = true;
    }

    const authorizationData = await getAuthorizationByPartyId(
        route.params.partyId.toString(),
        authorizationId.toString(),
    );
    if (authorizationData) {
        isLoading.value = false;
        release.value = convertToDate(authorizationData.releaseDate);
    } else {
        isError.value = true;
    }

    if (authorizationData) {
        formData.value.authorizationId = authorizationData.authorizationId;
        formData.value.nationalAuthorizationId =
            authorizationData.nationalAuthorizationId;
        formData.value.regionReference = authorizationData.referredRegionCode;
        formData.value.residualSurface = toHectares(
            authorizationData.residualSurface,
        );
        formData.value.transferredSurface = null;
        formData.value.note = null;
    }

    authorizationDetail.value = authorizationData;
});

async function goBackToAuthList() {
    await router.push({
        name: UnitRouteName.VINE_AUTHORIZATIONS_SUMMARY,
    });
}

async function goBackToDetailAuth() {
    await router.back();
}

function validateForm(): boolean {
    errors.value = {};

    if (
        !formData.value.transferredSurface &&
        formData.value.transferredSurface !== 0
    ) {
        errors.value.transferredSurface = t("errors.form_not_completed");
    } else if (formData.value.transferredSurface <= 0) {
        errors.value.transferredSurface = t(
            "errors.transferred_surface_gt_zero",
        );
    }
    if (!formData.value.transferredDate) {
        errors.value.transferredDate = t("errors.form_not_completed");
    }

    const residual = parseFloat(String(formData.value.residualSurface)) || 0;
    const transferred =
        parseFloat(String(formData.value.transferredSurface)) || 0;
    if (transferredSurfaceTouched.value && residual <= transferred) {
        errors.value.transferredSurface = t(
            `errors.transferred_surface_overflow`,
            {
                initialParams: residual,
            },
        );
    }

    return Object.keys(errors.value).length === 0;
}

async function submitForm() {
    if (!validateForm()) {
        window.scrollTo({ top: 0, behavior: "smooth" });
        return;
    }

    isLoading.value = true;

    formData.value.transferredSurface = toSquareMeters(
        formData.value.transferredSurface,
    );
    formData.value.residualSurface = toSquareMeters(
        formData.value.residualSurface,
    );

    const response = await authToRegionTransfer(
        route.params.partyId.toString(),
        authorizationId,
        formData.value,
    );
    if (response) {
        isLoading.value = false;
        goBackToDetailAuth();
    } else {
        isError.value = true;
    }
}

function checkResetData() {
    const datepickerElement = document.getElementById(
        "transferDateId",
    ) as HTMLInputElement | null;

    if (datepickerElement) {
        const transferDateStr = datepickerElement.value;
        console.log(transferDateStr);

        const error = validateDateInRange({
            dateStr: transferDateStr,
            minDate: new Date(release.value),
            maxDate: new Date(today),
            errorMessage: ({ min }) =>
                t("errors.transfer_date_overflow", {
                    release: min,
                }),
        });

        errors.value.transferredDate = error ?? "";
    }
}

async function handleTransferredSurfaceConstraint(e: Event) {
    transferredSurfaceTouched.value = true;
    const target = e.target as HTMLInputElement;
    if (target) {
        const nvalue = target.value.replace(/[^0-9-]/g, "");
        if (parseInt(nvalue) < 0) {
            formData.value.transferredSurface = null;
        }
    }
}
</script>

<template>
    <div v-if="!isLoading && !isError">
        <div class="row">
            <div class="row">
                <div class="col-6">
                    <h4>
                        {{ t(`authorizations.authorizations_to_region`) }}
                    </h4>
                </div>

                <form @submit.prevent="submitForm">
                    <!-- ID Autorizzazione -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiInput
                            v-model="formData.authorizationId"
                            :label="t(`authorizations.authorization_id`)"
                            readonly
                            type="text"
                        ></BiInput>
                    </div>

                    <!-- ID Autorizzazione Nazionale -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiInput
                            v-model="formData.nationalAuthorizationId"
                            :label="
                                t(`authorizations.national_authorization_id`)
                            "
                            readonly
                            type="text"
                        ></BiInput>
                    </div>

                    <!-- Regione di riferimento -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiSelect
                            v-model="formData.regionReference"
                            item-value="id"
                            item-title="text"
                            :items="regionList"
                            :label="t(`authorizations.region_reference`)"
                            :emptyOption="t(`authorizations.no_selection`)"
                        />
                    </div>

                    <!-- ID Superficie residua -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiInputFixed
                            v-model="formData.residualSurface"
                            :label="t(`authorizations.residual_surface`)"
                            readonly
                            :max="
                                parseFloat(formatArea(formData.residualSurface))
                            "
                            :placeholder="' '"
                            :step="0.0001"
                            :min="0.0"
                            :hide-arrows="false"
                        ></BiInputFixed>
                    </div>

                    <!-- Superficie trasferita -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiInputFixed
                            v-model="formData.transferredSurface"
                            :max="
                                parseFloat(
                                    formatArea(formData.transferredSurface),
                                )
                            "
                            :label="
                                t(`authorizations.transferred_surface`) + '*'
                            "
                            :placeholder="' '"
                            :step="0.0001"
                            :min="0.0"
                            :hide-arrows="false"
                            @input="handleTransferredSurfaceConstraint"
                            :errors="
                                errors.transferredSurface
                                    ? [errors.transferredSurface]
                                    : undefined
                            "
                        ></BiInputFixed>
                    </div>

                    <!-- Data trasferimento -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiDatepicker
                            id="transferDateId"
                            v-model="formData.transferredDate"
                            :label="t(`authorizations.transferred_date`) + '*'"
                            required
                            class="mt-5"
                            :min="release"
                            :max="today"
                            :errors="
                                errors.transferredDate
                                    ? [errors.transferredDate]
                                    : undefined
                            "
                            @change="checkResetData"
                        />
                    </div>

                    <!-- Note -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiInput
                            v-model="formData.note"
                            :label="t(`authorizations.notes`)"
                        ></BiInput>
                    </div>

                    <div class="text-start mt-5">
                        <BiButton
                            class="mt-3 me-2"
                            is-outlined
                            color="secondary"
                            @click="goBackToAuthList"
                        >
                            {{ t(`authorizations.cancel`) }}
                        </BiButton>
                        <BiButton
                            class="mt-3"
                            color="primary"
                            @click="submitForm"
                        >
                            {{ t(`authorizations.save`) }}
                        </BiButton>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div
        v-else-if="isLoading && !isError"
        class="d-flex col-12 justify-content-center mb-5"
    >
        <BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
    </div>
</template>
