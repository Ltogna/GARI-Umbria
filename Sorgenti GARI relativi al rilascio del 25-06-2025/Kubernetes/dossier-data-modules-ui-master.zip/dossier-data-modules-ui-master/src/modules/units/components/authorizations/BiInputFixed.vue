<script setup lang="ts">
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import { ref, watch } from "vue";

const props = withDefaults(
    defineProps<{
        modelValue: number | null;
        fixedNumber?: number;
        step?: number;
        min?: number;
        max?: number;
        isReadOnly?: boolean;
        hideArrow?: boolean;
        maxFixedNumber?: number; // massimo numero di decimali digitabili
        showCurrency?: boolean; // mostra il simbolo della valuta
    }>(),
    {
        fixedNumber: 4,
        maxFixedNumber: 4,
        showCurrency: false,
    },
);

const value = ref<string | null>(null);

watch(
    () => props.modelValue,
    (val) => {
        if (typeof val === "number") {
            value.value = val.toFixed(props.fixedNumber).replaceAll(".", ",");
            formatValue();
        } else {
            value.value = null;
        }
    },
    { immediate: true },
);

const emits = defineEmits<{
    (e: "update:modelValue", value: number | null): void;
}>();

function emitsValue() {
    const num = formatValue();
    if (num || num === 0) {
        emits("update:modelValue", +num);
    } else {
        emits("update:modelValue", null);
    }
}

function fixValue(evt: KeyboardEvent) {
    if (!evt) return;
    const target = evt.target as HTMLInputElement;
    const digit = evt.key as string;
    const separatorChar = ",";
    //const pointPosition = target.value.indexOf(".");
    const commaPosition = target.value.indexOf(",");
    const separatorPosition = target.value.indexOf(separatorChar);
    const caretPosition = target.selectionStart || 0;

    const controlKeys = [
        "Backspace",
        "ArrowLeft",
        "ArrowRight",
        "Delete",
        "Tab",
    ];
    if (
        controlKeys.includes(digit) ||
        evt.code.startsWith("Numpad") ||
        evt.code.startsWith("Digit")
    ) {
        return;
    }

    if (
        /[a-zA-Z.]/.test(digit) ||
        //digit == "," ||
        (digit == separatorChar && separatorPosition !== -1)
    ) {
        if (digit == "." && commaPosition === -1) {
            const first = target.value.slice(0, caretPosition);
            const last = target.value.slice(caretPosition);
            target.value = first + "," + last;
            target.setSelectionRange(caretPosition + 1, caretPosition + 1);
        }
        evt.preventDefault();
        return;
    }

    if (
        caretPosition > separatorPosition &&
        separatorPosition !== -1 &&
        target.value.split(separatorChar)[1].length == props.maxFixedNumber
    ) {
        evt.preventDefault();
        return;
    }
    //value.value = (+target.value).toFixed(props.fixedNumber);
}

function formatValue() {
    const num = value.value ? parseFloat(value.value.replace(",", ".")) : null;
    if (!num && num !== 0) return null;
    value.value = new Intl.NumberFormat("it-IT", {
        style: "decimal",
        minimumFractionDigits: props.fixedNumber,
        maximumFractionDigits: props.maxFixedNumber,
    }).format(num);
    return num;
}

function normalizedValue() {
    if (!props.isReadOnly && value.value) {
        value.value = value.value.replaceAll(".", "");
    }
}
</script>

<template>
    <BiInput
        v-model="value"
        type="text"
        :readonly="isReadOnly"
        :max="max"
        :step="step"
        :min="min"
        :hide-arrows="hideArrow"
        @blur="emitsValue"
        @keydown="fixValue"
        @focus="normalizedValue"
    />
</template>
