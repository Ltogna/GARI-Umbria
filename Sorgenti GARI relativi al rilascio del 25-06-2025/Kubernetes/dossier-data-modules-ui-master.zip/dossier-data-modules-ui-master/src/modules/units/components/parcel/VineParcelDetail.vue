<script setup lang="ts">
import AlertMessage from "@/components/AlertMessage.vue";
import useQueryFilter from "@/composables/useQueryFilter";
import { UnitRouteName } from "@/modules/units/models/routes";
import type {
    Parcel,
    ParcelLandLink,
    VineUnitListModel,
} from "@/modules/units/models/vineUnit";
import {
    getParcelById,
    getParcelLandLink,
} from "@/modules/units/resources/api/vineUnit";
import { useVineUnitStore } from "@/modules/units/stores/vineUnit";
import { areaSQMInHA, convertToDate } from "@/utils/utils";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { parseISO } from "date-fns";
import { computed, onMounted, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import ConductingDetailHeader from "./VineConductingDetailHeader.vue";
import t from "@/modules/units/utils/i18n";
import useDateFormat from "@/composables/useDateFormat";
import { MONTH_YEAR_FORMAT } from "@/constants";


const { dateFormat } = useDateFormat();
const router = useRouter();
const route = useRoute();

const vineUnitStore = useVineUnitStore();

const { filter: dateFilter } = useQueryFilter("date");

const curParcel = ref<Parcel | null>(null);
const curParcelLandLink = ref<ParcelLandLink | null>(null);
const vineUnitList = computed(() => {
    const vineUnits: VineUnitListModel = [];
    curParcel.value?.landcovers_list.forEach((l) => {
        vineUnits.push(...l.vine_units);
    });
    return vineUnits;
});

const referenceDate = parseISO(dateFilter.value);

onMounted(async () => {
    vineUnitStore.loadingCounter++;
    curParcel.value = await getParcelById(
        referenceDate,
        +route.params.parcelId,
        true,
        true,
        true
    );
    curParcelLandLink.value = await getParcelLandLink(
        referenceDate,
        +route.params.parcelId,
        +route.params.partyId,
    );
    vineUnitStore.loadingCounter--;
});

function goToVineUnitDetail(vineUnitId: number, landCoverId: number) {
    router.push({
        name: UnitRouteName.VINE_UNIT_DETAIL,
        query: {
            date: route.query.date,
        },
        params: {
            vineUnitId: vineUnitId,
            landCoverId: landCoverId,
            parcelId: +route.params.parcelId,
        },
    });
}
</script>
<template>
    <ConductingDetailHeader :is-conductin-detail-button-visible="false" :cur-parcel="curParcel"
        :cur-parcel-land-link="curParcelLandLink" />
    <div class="mt-3 row">
        <div class="col-12">
            <h6>{{ t(`parcels.units`) }}</h6>
        </div>
        <div v-if="vineUnitList.length" class="col-12">
            <BiTable is-row-hover is-header-light is-custom responsive-breakpoint="md">
                <template #head>
                    <tr class="text-primary">
                        <th scope="col">
                            {{ t(`parcels.vu`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.variety`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.month_year_plant`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.planting_layout`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.breeding`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.destination`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.area`) }}
                        </th>
                        <th scope="col"></th>
                    </tr>
                </template>
                <template #body>
                    <tr v-for="vineUnit in vineUnitList" :key="vineUnit.id" class="align-middle">
                        <td :data-label="t(`parcels.vu`)">
                            <small>{{ vineUnit.code }}</small>
                        </td>
                        <td :data-label="t(`parcels.variety`)">
                            <small>{{ vineUnit.variety.description }}</small>
                        </td>
                        <td :data-label="t(`parcels.month_year_plant`)">
                            <small>
                                {{
                                    dateFormat(
                                        convertToDate(vineUnit.planting_day),
                                        MONTH_YEAR_FORMAT
                                    )
                                }}
                            </small>
                        </td>
                        <td :data-label="t(`parcels.planting_layout`)">
                            <small>
                                {{ vineUnit.distance_on_the_row_cm }}x{{
                                    vineUnit.distance_between_rows_cm
                                }}
                            </small>
                        </td>
                        <td :data-label="t(`parcels.breeding`)">
                            <small>
                                {{ vineUnit.farming_form?.description }}
                            </small>
                        </td>

                        <td :data-label="t(`parcels.destination`)">
                            <small>{{
                                vineUnit.product_destination.description
                            }}</small>
                        </td>
                        <td :data-label="t(`parcels.area`)">
                            <small>{{ areaSQMInHA(vineUnit.area_sqm) }}</small>
                        </td>
                        <td>
                            <small>
                                <BiIconButton class="mx-1" icon="arrow-right" iconStyle="fas" color="primary" isOutlined
                                    @click="
                                        goToVineUnitDetail(
                                            vineUnit.id,
                                            vineUnit.land_cover_id,
                                        )
                                        " />
                            </small>
                        </td>
                    </tr>
                </template>
            </BiTable>
        </div>
        <div v-else class="col-12">
            <AlertMessage :modelValue="true" :dismissable="false" :level="'info'">
                {{ t(`no_units`) }}
            </AlertMessage>
        </div>
    </div>
</template>
