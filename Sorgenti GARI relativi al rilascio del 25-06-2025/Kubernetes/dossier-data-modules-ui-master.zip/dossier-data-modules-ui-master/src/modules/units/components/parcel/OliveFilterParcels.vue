<script setup lang="ts">
import useQueryFilter from "@/composables/useQueryFilter";
import { AnomalyLevelSchema } from "@/models/anomalyLevel";
import { type Parcel } from "@/modules/units/models/oliveUnit";
import { getParcels } from "@/modules/units/resources/api/oliveUnit";
import { useOliveUnitStore } from "@/modules/units/stores/oliveUnit";
import t from "@/modules/units/utils/i18n";
import { useMessageStore } from "@/stores/messageStore";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import type { SelectItem } from "@abaco/bootstrap-italia-components/src/models";
import { formatISO, parseISO } from "date-fns";
import { defineEmits, onMounted, ref } from "vue";
import { useRoute } from "vue-router";

const emits = defineEmits<{
    (e: "back:to:list"): void;
    (
        e: "filter:parcels",
        res: { count: number; records: Parcel[]; nextKey: string | null },
    ): void;
}>();

const oliveUnitStore = useOliveUnitStore();
const messageStore = useMessageStore();

const route = useRoute();

const { filter: sector } = useQueryFilter("sector");
const { filter: variety } = useQueryFilter("variety");
const { filter: sheet } = useQueryFilter("sheet");
const { filter: code } = useQueryFilter("code");
const { filter: date } = useQueryFilter("date");

const varietyItems = ref<SelectItem[]>([]);
const sectorItems = ref<SelectItem[]>([]);
const anomalies = ref();

onMounted(async () => {
    varietyItems.value = oliveUnitStore.varietySummary.map((variety) => {
        return {
            id: variety.variety.code,
            text: variety.variety.description,
        } as SelectItem;
    });
    sectorItems.value = oliveUnitStore.sectorSummary.map((sector) => {
        return {
            id: sector.sector.sector_code,
            text: sector.sector.description,
        } as SelectItem;
    });
    anomalies.value = Object.keys(AnomalyLevelSchema.Enum).map((key) => {
        return {
            id: key,
            text: t(`anomalies_select.${key.toLocaleLowerCase()}`),
        } as SelectItem;
    });
});

async function applyFilters() {
    oliveUnitStore.loadingCounter++;
    const res = await getParcels(
        {
            parcelSheet: sheet.value,
            parcelCode: code.value,
            referenceDate: parseISO(date.value),
            sector: sector.value,
            variety: variety.value,
            anomalyCode: null,
        },
        +route.params.partyId,
        null,
    );
    oliveUnitStore.loadingCounter--;
    if (!res.count)
        messageStore.setMessage({
            message: t(`errors.no_parcels_found`),
            level: "warning",
        });
    else {
        messageStore.open = false;
        emits("filter:parcels", res);
    }
}

function resetFilters() {
    date.value = formatISO(oliveUnitStore.curDate, { representation: "date" });
    sector.value = "";
    sheet.value = "";
    code.value = "";
    variety.value = "";
    messageStore.open = false;
}
</script>

<template>
    <div class="row">
        <div class="col-12">
            <h4>{{ t(`parcels.filter.filter_parcels`) }}</h4>
        </div>
    </div>
    <form @submit.prevent="applyFilters" class="dossier-data-modules__form">
        <div class="mt-5 row">
            <div class="col-4">
                <BiSelect
                    v-model="sector"
                    :items="sectorItems"
                    item-value="id"
                    item-title="text"
                    :label="t(`parcels.city`)"
                    :emptyOption="t(`parcels.filter.no_filter`)"
                />
            </div>
            <div class="col-4">
                <BiInput v-model="sheet" :label="t(`parcels.sheet`)" />
            </div>
            <div class="col-4">
                <BiInput v-model="code" :label="t(`parcels.parcel`)" />
            </div>
        </div>
        <div class="mt-5 row">
            <div class="col-4 field-required">
                <BiDatepicker
                    v-model="date"
                    :label="t(`parcels.conductions_to_date`)"
                    :isRequired="true"
                />
            </div>
            <div class="col-4">
                <BiSelect
                    v-model="variety"
                    :items="varietyItems"
                    :label="t(`parcels.variety`)"
                    :emptyOption="t(`parcels.filter.no_filter`)"
                />
            </div>
            <!-- <div class="col-4">
                <BiSelect
                    v-model="filterForm.anomalyCode"
                    :label="t(`parcels.anomalies`)"
                    :emptyOption="t(`parcels.filter.no_filter`)"
                    :items="anomalies"
                />
            </div> -->
        </div>
        <div class="my-5 row">
            <div class="d-flex justify-content-center col-12">
                <BiButton
                    color="primary"
                    isOutlined
                    @click="emits('back:to:list')"
                >
                    <BiIcon icon="arrow-left" class="me-1" />
                    {{ t(`back_to_list`) }}
                </BiButton>
                <BiButton
                    class="mx-3"
                    color="primary"
                    @click="resetFilters"
                    isOutlined
                >
                    {{ t(`reset`) }}
                </BiButton>

                <BiButton color="primary" type="submit">
                    {{ t(`parcels.filter.apply_filters`) }}
                </BiButton>
            </div>
        </div>
    </form>
</template>
