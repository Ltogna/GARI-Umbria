<script setup lang="ts">
import useDateFormat from "@/composables/useDateFormat";
import useQueryFilter from "@/composables/useQueryFilter";
import type { AnomalySearchModel } from "@/models/anomalyLevel";
import type { Parcel, VineUnitModel } from "@/modules/units/models/vineUnit";
import {
    getParcelById,
    getUnitById,
} from "@/modules/units/resources/api/vineUnit";
import { useVineUnitStore } from "@/modules/units/stores/vineUnit";
import t from "@/modules/units/utils/i18n";
import { areaSQMInHAWithLabel, printDateInfo } from "@/utils/utils";
import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import { parseISO } from "date-fns";
import { computed, onMounted, ref } from "vue";
import { useRoute } from "vue-router";
import DescriptionListItem from "./summaries/DescriptionListItem.vue";

const { dateFormat } = useDateFormat();
const vineUnitStore = useVineUnitStore();
const route = useRoute();

const { filter: dateFilter } = useQueryFilter("date");

const curParcel = ref<Parcel | null>(null);
const targetUnit = ref<VineUnitModel | null>();

onMounted(async () => {
    try {
        vineUnitStore.loadingCounter++;
        curParcel.value = await getParcelById(
            parseISO(dateFilter.value),
            +route.params.parcelId,
            true,
            true,
            true
        );
        targetUnit.value = await getUnitById(
            parseISO(dateFilter.value),
            +route.params.parcelId,
            +route.params.landCoverId,
            +route.params.vineUnitId,
        );
        if (targetUnit.value) {
            targetUnit.value.unit_type = t(`units.type`);
        }
    } catch (error) {
        // TODO - HANDLE ERROR
        console.error(error);
    } finally {
        vineUnitStore.loadingCounter--;
    }
});

const title = computed(() => {
    if (targetUnit.value && curParcel.value) {
        return `
            ${t(`parcels.parcel_detail`)}
            ${curParcel.value.sector.sector_code} -
            ${curParcel.value.sector.short_descr} -
            ${curParcel.value.block.description} -
            ${curParcel.value.parcel} -
            ${t(`parcels.vu`)}: ${targetUnit.value.code}
        `;
    }
    return "";
});

const plantingDay = computed(() => {
    return printDateInfo(
        targetUnit.value?.planting_day,
        targetUnit.value?.planting_day_precision,
    );
});

const anomalies = computed(() => {
    if (!targetUnit.value || !targetUnit.value.anomalies?.length) return null;

    const distinctAnomaliesList = new Set<AnomalySearchModel>();
    targetUnit.value.anomalies.map((anomaly) =>
        distinctAnomaliesList.add(anomaly),
    );

    return [...distinctAnomaliesList].map((it) => it.type.code).join(", ");
});

const lastUpdate = computed(() => {
    if (targetUnit.value?.last_update) {
        return dateFormat(targetUnit.value?.last_update ?? null);
    }
    return "-";
});
</script>
<template>
    <div class="row">
        <div class="col-12">
            <h4>
                {{ title }}
            </h4>
            <div class="mt-3">
                <BiAccordion :modelValue="true" :title="t(`parcels.vu_card`)">
                    <dl class="ps-4 row" v-if="targetUnit">
                        <DescriptionListItem
                            i18nKey="parcels.type"
                            :value="targetUnit.unit_type"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.variety"
                            :value="targetUnit.variety"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.area"
                            :value="areaSQMInHAWithLabel(targetUnit.area_sqm)"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.planting_year"
                            :value="plantingDay[0]"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.planting_month"
                            :value="plantingDay[1]"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.planting_day"
                            :value="plantingDay[2]"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.distance_on_the_row_cm"
                            :value="targetUnit.distance_on_the_row_cm"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.distance_between_rows_cm"
                            :value="targetUnit.distance_between_rows_cm"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.stumps_number"
                            :value="targetUnit.stumps_number"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.stump_density_ha"
                            :value="targetUnit.stumps_density100"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.farming_form"
                            :value="targetUnit.farming_form"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.irrigation_type"
                            :value="targetUnit.irrigation"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.production_destination"
                            :value="targetUnit.product_destination"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.variation_type"
                            :value="targetUnit.variation_type"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.cultivation_status"
                            :value="targetUnit.cultivation_status"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.terracing"
                            :value="targetUnit.terracing"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.failures_perc"
                            :value="targetUnit.failures_perc"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.terrain_slope"
                            :value="targetUnit.soil_layering_perc"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.altitude"
                            :value="targetUnit.altitude_above_sea_level"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.poles_weaving"
                            :value="targetUnit.poles_weaving"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.poles_distance_cm"
                            :value="targetUnit.poles_distance_cm"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.support_wires"
                            :value="targetUnit.support_wires"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.header_anchoring"
                            :value="targetUnit.header_anchoring"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.poles_header"
                            :value="targetUnit.poles_header"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.poles_header"
                            :value="targetUnit.poles_header"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.last_edit_date"
                            :value="lastUpdate"
                        />
                    </dl>
                </BiAccordion>
            </div>
            <div v-if="anomalies" class="mt-3">
                <BiAccordion :modelValue="true" :title="t(`parcels.anomalies`)">
                    <ul class="list-unstyled">
                        <li>
                            {{ anomalies }}
                        </li>
                    </ul>
                </BiAccordion>
            </div>
            <div class="mt-3">
                <BiAccordion
                    :modelValue="true"
                    :title="t(`aptitudes.aptitudes_do_igt`)"
                >
                    <dl class="ps-4 row" v-if="targetUnit">
                        <DescriptionListItem
                            v-for="aptitude in targetUnit.vine_aptitudes"
                            :key="aptitude.id"
                            :i18nKey="aptitude.doigt.category_description"
                            :value="aptitude.doigt.description"
                        />
                    </dl>
                </BiAccordion>
            </div>
        </div>
    </div>
</template>
