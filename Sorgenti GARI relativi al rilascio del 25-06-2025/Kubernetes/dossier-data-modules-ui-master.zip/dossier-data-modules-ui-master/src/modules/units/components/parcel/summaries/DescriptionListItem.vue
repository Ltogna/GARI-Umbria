<script setup lang="ts">
import { UNIT_ID } from "@/modules/units/constants";
import type { CodeDescriptionModel } from "@/modules/units/models/vineUnit";
import { useUnitConfigStore } from "@/modules/units/stores/unitConfig";
import t from "@/modules/units/utils/i18n";
import { computed, defineProps } from "vue";
import { useI18n } from "vue-i18n";

const props = defineProps<{
    i18nKey: string;
    value?: string | number | CodeDescriptionModel | null;
}>();

const { te } = useI18n();
const mode = useUnitConfigStore().mode;

const val = computed(() => {
    if (props.value === null || props.value === undefined) {
        return "-";
    }
    switch (typeof props.value) {
        case "string":
        case "number":
            return props.value;
        case "object":
            return props.value.description;
        default:
            return "-";
    }
});

const key = computed(() => {
    if (te(`${UNIT_ID}.${props.i18nKey}`) || te(`${mode}.${props.i18nKey}`)) {
        return t(`${props.i18nKey}`);
    }
    return props.i18nKey;
});
</script>
<template>
    <dt class="col-sm-3">
        {{ key }}
    </dt>
    <dd class="col-sm-9">
        {{ val }}
    </dd>
</template>
