<script setup lang="ts">
import useDateFormat from "@/composables/useDateFormat";
import t from "@/modules/units/utils/i18n";
import {
    convertToDate,
    formatArea,
    toHectares,
    toSquareMeters,
} from "@/utils/utils";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import { computed, onMounted, ref, watch } from "vue";
import { useRoute, useRouter } from "vue-router";
import type { AuthorizationData } from "../../models/authorization";
import { UnitRouteName } from "../../models/routes";
import {
    getAuthorizationByPartyId,
    getAuthTypes,
    getItalianRegions,
    getProvinces,
    newAuth,
    updateAuth,
} from "../../resources/api/authorizations";
import BiInputFixed from "./BiInputFixed.vue";

const isLoading = ref<boolean>(false);
const isError = ref<boolean>(false);

const editMode = ref(true);

const route = useRoute();
const router = useRouter();

const authorizationId = ref();
const authTypeCode = ref();
const { dateFormat } = useDateFormat();

const nationalAuthorizationIdTouched = ref(false);
const originalNationalAuthorizationIdTouched = ref(false);
const surfaceTouched = ref(false);

const today = new Date().toISOString().split("T")[0];

const authorizationTypeList = ref();
const releaseDateKey = ref(0);
const regionList = ref();
const provinceList = ref();

const authorizationData = ref();

const errors = ref<Record<string, string>>({});

onMounted(async () => {
    authorizationId.value = route.params.authorizationId?.toString();
    authTypeCode.value = route.params.authTypeCode?.toString();

    editMode.value = authorizationId.value ? true : false;

    isLoading.value = true;
    authorizationTypeList.value = await getAuthTypes();
    regionList.value = await getItalianRegions();

    if (authorizationTypeList.value && regionList.value) {
        isLoading.value = false;
    } else {
        isError.value = true;
    }

    if (editMode.value) {
        isLoading.value = true;
        authorizationData.value = await getAuthorizationByPartyId(
            route.params.partyId.toString(),
            authorizationId.value.toString(),
        );

        if (authorizationData.value) {
            isLoading.value = false;
        } else {
            isError.value = true;
        }

        if (authorizationData.value) {
            formData.value.authorizationId =
                authorizationData.value.authorizationId;
            formData.value.nationalAuthorizationId =
                authorizationData.value.nationalAuthorizationId;

            formData.value.authorizationType =
                authorizationData.value.authorizationTypeCode;

            formData.value.originAuthorizationId =
                authorizationData.value.originAuthorizationId;

            formData.value.originNationalAuthorizationId =
                authorizationData.value.originNationalAuthorizationId;

            formData.value.rightOriginId =
                authorizationData.value.rightOriginId;

            formData.value.regionOrigin =
                authorizationData.value.originRegionCode;

            formData.value.regionReference =
                authorizationData.value.referredRegionCode;

            formData.value.provinceReference =
                authorizationData.value.referredProvinceCode;

            formData.value.authorizationSurface = toHectares(
                authorizationData.value.authorizationSurface,
            );

            formData.value.plantedSurface = toHectares(
                authorizationData.value.plantedSurface,
            );

            formData.value.transferredSurface = toHectares(
                authorizationData.value.transferredSurface,
            );

            formData.value.residualSurface = 0;

            formData.value.protocolId = authorizationData.value.protocolId;
            formData.value.protocolDate = dateFormat(
                convertToDate(authorizationData.value.protocolDate),
            );
            formData.value.typologyApplication =
                authorizationData.value.applicationTypeDesc;
            formData.value.conversionDate = dateFormat(
                convertToDate(authorizationData.value.conversionDate),
            );
            formData.value.applicationId =
                authorizationData.value.applicationId;
            formData.value.note = authorizationData.value.notes;

            formData.value.releaseDate = convertToDate(
                authorizationData.value.releaseDate,
            );
        }
    }
    isLoading.value = false;
});

const formData = ref<AuthorizationData>({
    authorizationId: 0,
    nationalAuthorizationId: null,
    authorizationType: null,
    originAuthorizationId: null,
    originNationalAuthorizationId: null,
    rightOriginId: null,
    regionOrigin: null,
    regionReference: null,
    provinceReference: null,
    authorizationSurface: null,
    plantedSurface: null,
    transferredSurface: null,
    residualSurface: null,
    protocolId: null,
    protocolDate: null,
    typologyApplication: null,
    conversionDate: null,
    applicationId: null,
    note: null,
    releaseDate: null,
    expirationDate: null,
});

const isNationalAuthorizationIdValid = computed(() => {
    if (formData.value.nationalAuthorizationId)
        return /^[A-Z]\d{13}$/.test(formData.value.nationalAuthorizationId);
    else return null;
});

const isOriginNationalAuthorizationIdValid = computed(() => {
    if (formData.value.originNationalAuthorizationId)
        return /^[A-Z]\d{13}$/.test(
            formData.value.originNationalAuthorizationId,
        );
    return true;
});

const isSurfaceValid = computed(() => {
    const planted = parseFloat(String(formData.value.plantedSurface)) || 0;
    const transferred =
        parseFloat(String(formData.value.transferredSurface)) || 0;
    const authorized =
        parseFloat(String(formData.value.authorizationSurface)) || 0;

    return planted + transferred <= authorized;
});

// Validation Form
function validateForm() {
    errors.value = {};

    const requiredFields = [
        "nationalAuthorizationId",
        "authorizationType",
        "regionOrigin",
        "regionReference",
        "authorizationSurface",
        "plantedSurface",
        "transferredSurface",
        "releaseDate",
    ];

    for (const field of requiredFields) {
        const val = formData.value[field as keyof AuthorizationData];
        if (val === null || val === "") {
            errors.value[field] = t(`errors.fieldRequired`);
        }
    }

    return Object.keys(errors.value).length === 0;
}

const watchField = (field: keyof AuthorizationData) => {
    watch(
        () => formData.value[field],
        (val) => {
            if (val !== null && val !== undefined && val !== "") {
                delete errors.value[field];
            }
        },
    );
};
// clear errors if field is filled
[
    "nationalAuthorizationId",
    "authorizationType",
    "regionOrigin",
    "regionReference",
    "authorizationSurface",
    "plantedSurface",
    "transferredSurface",
    "releaseDate",
].forEach((field) => watchField(field as keyof AuthorizationData));

// return residual surface updated
watch(
    [
        () => formData.value.authorizationSurface,
        () => formData.value.plantedSurface,
        () => formData.value.transferredSurface,
    ],
    ([auth, planted, transferred]: [
        number | null,
        number | null,
        number | null,
    ]) => {
        const a = auth ?? 0;
        const p = planted ?? 0;
        const t = transferred ?? 0;

        let residual = a - p - t;
        if (residual < 0) residual = 0;

        formData.value.residualSurface = residual;
    },
);

const formattedResidualSurface = computed(() =>
    formData.value.residualSurface !== null
        ? formData.value.residualSurface.toFixed(4).replace(".", ",")
        : "0,0000",
);

watch(
    () => formData.value.releaseDate,
    (newReleaseDate, oldReleaseDate) => {
        if (!newReleaseDate) {
            formData.value.expirationDate = null;
            return;
        }
        if (
            authorizationData.value &&
            authorizationData.value.expirationDate &&
            oldReleaseDate === null
        ) {
            formData.value.expirationDate = dateFormat(
                convertToDate(authorizationData.value.expirationDate),
            );
            return;
        }
        const release = new Date(newReleaseDate);
        release.setFullYear(release.getFullYear() + 3);
        release.setDate(release.getDate() - 1);
        formData.value.expirationDate = release.toLocaleDateString("it-IT");
    },
);

watch(
    () => formData.value.regionReference,
    async (newRegionId, oldRegionId) => {
        if (oldRegionId !== null && newRegionId !== oldRegionId) {
            provinceList.value = [];
            formData.value.provinceReference = null;
        }

        if (newRegionId) {
            try {
                provinceList.value = [];
                const provinces = await getProvinces(newRegionId);
                provinceList.value = provinces;
            } catch (err) {
                console.error(err);
                provinceList.value = [];
            }
        } else {
            provinceList.value = [];
        }
    },
);

// Save or update form
async function submitForm() {
    if (!validateForm()) {
        return;
    }

    formData.value.authorizationSurface = toSquareMeters(
        formData.value.authorizationSurface,
    );
    formData.value.plantedSurface = toSquareMeters(
        formData.value.plantedSurface,
    );
    formData.value.transferredSurface = toSquareMeters(
        formData.value.transferredSurface,
    );

    if (editMode.value) {
        isLoading.value = true;
        const response = await updateAuth(
            route.params.partyId.toString(),
            authorizationId.value,
            formData.value,
        );
        if (response) {
            authorizationData.value = await getAuthorizationByPartyId(
                route.params.partyId.toString(),
                authorizationId.value.toString(),
            );
            formData.value.authorizationSurface = toHectares(
                authorizationData.value?.authorizationSurface,
            );

            formData.value.plantedSurface = toHectares(
                authorizationData.value?.plantedSurface,
            );

            formData.value.transferredSurface = toHectares(
                authorizationData.value?.transferredSurface,
            );

            isLoading.value = false;
            window.scrollTo({
                top: 0,
                behavior: "smooth",
            });
        } else {
            isError.value = true;
        }
    } else {
        const response = await newAuth(
            route.params.partyId.toString(),
            formData.value,
        );
        if (response) {
            goBackToAuthNewList();
        }
    }
}

function navigateTo(name: string, params?: Record<string, string | number>) {
    router.push({ name, params });
}

function goBackToAuthList() {
    navigateTo(UnitRouteName.VINE_AUTHORIZATIONS_SUMMARY);
}

function goBackToAuthNewList() {
    const paramPrefix = route.params.authTypeCode.toString().split("|")[0];
    const param = paramPrefix + "|" + formData.value.authorizationType;
    navigateTo(UnitRouteName.VINE_AUTHORIZATIONS_LIST, { authTypeCode: param });
}

function goToAuthorizationOrigin(authorizationId: number | null) {
    if (authorizationId) {
        navigateTo(UnitRouteName.VINE_AUTHORIZATION_ORIGIN, {
            authorizationId,
        });
    }
}

function goToLinkedApplication(authorizationId: number | null) {
    if (authorizationId) {
        navigateTo(UnitRouteName.VINE_AUTHORIZATION_LINKED_QUESTION, {
            authorizationId,
        });
    }
}

function goToTransferToCUAA(authorizationId: number | null) {
    if (authorizationId) {
        navigateTo(UnitRouteName.VINE_AUTHORIZATION_TO_CUAA, {
            authorizationId,
        });
    }
}

function goToTransferToRegion(authorizationId: number | null) {
    if (authorizationId) {
        navigateTo(UnitRouteName.VINE_AUTHORIZATION_TO_REGION, {
            authorizationId,
        });
    }
}

function goToEditExpirationDate(authorizationId: number | null) {
    if (authorizationId) {
        navigateTo(UnitRouteName.VINE_AUTHORIZATION_EDIT_EXPIRATION_DATE, {
            authorizationId,
        });
    }
}
</script>

<template>
    <div v-if="!isLoading && !isError">
        <div class="row mb-5">
            <div class="col-auto">
                <h4>{{ t(`authorizations.authorization_detail`) }}</h4>
            </div>
            <div class="col-auto" v-if="editMode">
                <BiButton
                    class="me-2"
                    color="primary"
                    isOutlined
                    @click="goToAuthorizationOrigin(formData.authorizationId)"
                >
                    {{ t(`authorizations.origin`) }}
                </BiButton>
                <BiButton
                    class="me-2"
                    color="primary"
                    isOutlined
                    @click="goToLinkedApplication(formData.authorizationId)"
                >
                    {{ t(`applications.linked_applications`) }}
                </BiButton>
                <BiButton
                    class="me-2"
                    color="primary"
                    isOutlined
                    @click="goToTransferToCUAA(formData.authorizationId)"
                >
                    {{ t(`authorizations.transfer_to_cuaa`) }}
                </BiButton>
                <BiButton
                    class="me-2"
                    color="primary"
                    isOutlined
                    @click="goToTransferToRegion(formData.authorizationId)"
                >
                    {{ t(`authorizations.transfer_to_region`) }}
                </BiButton>
                <BiButton
                    color="primary"
                    isOutlined
                    @click="goToEditExpirationDate(formData.authorizationId)"
                >
                    {{ t(`authorizations.edit_expiration_date`) }}
                </BiButton>
            </div>
        </div>

        <form @submit.prevent="submitForm" class="dossier-data-modules__form">
            <!-- ID Autorizzazione -->
            <div class="mb-3 row align-items-center" v-if="editMode">
                <div class="col-6">
                    <BiInput
                        v-model="formData.authorizationId"
                        type="text"
                        :label="t(`authorizations.authorization_id`)"
                        :readonly="editMode"
                    />
                </div>
            </div>

            <!-- ID Autorizzazione Nazionale -->
            <div class="mb-3 row align-items-center">
                <div class="col-6">
                    <BiInput
                        v-model="formData.nationalAuthorizationId"
                        type="text"
                        :label="
                            t(`authorizations.national_authorization_id`) + '*'
                        "
                        @blur="nationalAuthorizationIdTouched = true"
                        :errors="
                            errors.nationalAuthorizationId
                                ? [errors.nationalAuthorizationId]
                                : []
                        "
                    />
                </div>
            </div>
            <p
                v-if="
                    !isNationalAuthorizationIdValid &&
                    nationalAuthorizationIdTouched &&
                    formData.nationalAuthorizationId != ''
                "
                class="text-danger"
            >
                {{ t(`authorizations.authorization_id_format`) }}
            </p>

            <!-- Tipo autorizzazione -->
            <div class="mb-3 row align-items-center">
                <div class="col-6">
                    <BiSelect
                        v-model="formData.authorizationType"
                        item-value="id"
                        item-title="text"
                        :items="authorizationTypeList || []"
                        :label="t(`authorizations.authorization_type`) + '*'"
                        :errors="
                            errors.authorizationType
                                ? [errors.authorizationType]
                                : []
                        "
                    />
                </div>
            </div>

            <!-- ID Autorizzazione di provenienza -->
            <div class="mb-3 row align-items-center" v-if="editMode">
                <div class="col-6">
                    <BiInput
                        v-model="formData.originAuthorizationId"
                        type="text"
                        :label="t(`authorizations.origin_authorization_id`)"
                        :readonly="editMode"
                    />
                </div>
            </div>

            <!-- Id Autorizzazione Nazionale di provenienza -->
            <div class="mb-3 row align-items-center">
                <div class="col-6">
                    <BiInput
                        v-model="formData.originNationalAuthorizationId"
                        type="text"
                        :label="
                            t(`authorizations.origin_national_authorization_id`)
                        "
                        @blur="originalNationalAuthorizationIdTouched = true"
                    />
                </div>
            </div>
            <p
                v-if="
                    !isOriginNationalAuthorizationIdValid &&
                    originalNationalAuthorizationIdTouched &&
                    formData.originNationalAuthorizationId != ''
                "
                class="text-danger"
            >
                {{ t(`authorizations.authorization_id_format`) }}
            </p>

            <!-- ID Diritto di provenienza -->
            <div class="mb-3 row align-items-center" v-if="editMode">
                <div class="col-6">
                    <BiInput
                        v-model="formData.rightOriginId"
                        type="text"
                        :label="t(`authorizations.right_origin_id`)"
                        :readonly="editMode"
                    />
                </div>
            </div>

            <!-- Regione di provenienza -->
            <div class="mb-3 row align-items-center">
                <div class="col-6">
                    <BiSelect
                        v-model="formData.regionOrigin"
                        item-value="id"
                        item-title="text"
                        :items="regionList || []"
                        :label="t(`authorizations.region_origin`) + '*'"
                        :errors="
                            errors.regionOrigin ? [errors.regionOrigin] : []
                        "
                    />
                </div>
            </div>

            <!-- Regione di riferimento -->
            <div class="mb-3 row align-items-center">
                <div class="col-6">
                    <BiSelect
                        v-model="formData.regionReference"
                        item-value="id"
                        item-title="text"
                        :items="regionList || []"
                        :label="t(`authorizations.region_reference`) + '*'"
                        :errors="
                            errors.regionReference
                                ? [errors.regionReference]
                                : []
                        "
                    />
                </div>
            </div>

            <!-- Provincia di riferimento -->
            <div class="mb-3 row align-items-center">
                <div class="col-6">
                    <BiSelect
                        v-model="formData.provinceReference"
                        item-value="id"
                        item-title="text"
                        :items="provinceList || []"
                        :label="t(`authorizations.province_reference`)"
                        :emptyOption="t(`authorizations.no_selection`)"
                    />
                </div>
            </div>

            <!-- Sup. Autorizzazione (Ha) -->
            <div class="mb-3 row align-items-center">
                <div class="col-6">
                    <BiInputFixed
                        v-model="formData.authorizationSurface"
                        :max="
                            parseFloat(
                                formatArea(formData.authorizationSurface),
                            )
                        "
                        :label="t(`authorizations.authorization_surface`) + '*'"
                        :placeholder="' '"
                        :step="0.0001"
                        :min="0.0"
                        :hide-arrows="false"
                        @input="surfaceTouched = true"
                        :errors="
                            errors.authorizationSurface
                                ? [errors.authorizationSurface]
                                : []
                        "
                    />
                </div>
            </div>

            <!-- Sup. Impiantata (Ha) -->
            <div class="mb-3 row align-items-center">
                <div class="col-6">
                    <BiInputFixed
                        v-model="formData.plantedSurface"
                        :max="parseFloat(formatArea(formData.plantedSurface))"
                        :label="t(`authorizations.planted_surface`) + '*'"
                        :placeholder="' '"
                        :step="0.0001"
                        :min="0.0"
                        :hide-arrows="false"
                        @input="surfaceTouched = true"
                        :errors="
                            errors.plantedSurface ? [errors.plantedSurface] : []
                        "
                    />
                </div>
            </div>

            <p v-if="surfaceTouched && !isSurfaceValid" class="text-danger">
                {{ t(`errors.implanted_and_trasferred_exceedes_error`) }}
            </p>

            <!-- Sup. Trasferita (Ha) -->
            <div class="mb-3 row align-items-center">
                <div class="col-6">
                    <BiInputFixed
                        v-model="formData.transferredSurface"
                        :max="
                            parseFloat(formatArea(formData.transferredSurface))
                        "
                        :label="t(`authorizations.transferred_surface`) + '*'"
                        :placeholder="' '"
                        :step="0.0001"
                        :min="0.0"
                        :hide-arrows="false"
                        @input="surfaceTouched = true"
                        :errors="
                            errors.transferredSurface
                                ? [errors.transferredSurface]
                                : []
                        "
                    />
                </div>
            </div>

            <p v-if="surfaceTouched && !isSurfaceValid" class="text-danger">
                {{ t(`errors.implanted_and_trasferred_exceedes_error`) }}
            </p>

            <!-- Superficie residua -->

            <div class="mb-3 row align-items-center" v-if="editMode">
                <div class="col-6">
                    <BiInput
                        v-model="formattedResidualSurface"
                        type="text"
                        :label="t(`authorizations.residual_surface`)"
                        :readonly="editMode"
                    />
                </div>
            </div>

            <!-- Identificativo protocollo -->
            <div class="mb-3 row align-items-center" v-if="editMode">
                <div class="col-6">
                    <BiInput
                        v-model="formData.protocolId"
                        type="text"
                        :label="t(`authorizations.protocol_id`)"
                        :readonly="editMode"
                    />
                </div>
            </div>

            <!-- Data Protocollo -->
            <div class="mb-3 row align-items-center" v-if="editMode">
                <div class="col-6">
                    <BiInput
                        v-model="formData.protocolDate"
                        class="mt-5"
                        :label="t(`authorizations.protocol_date`)"
                        readonly
                    />
                </div>
            </div>

            <!-- Tipologia domanda -->
            <div class="mb-3 row align-items-center" v-if="editMode">
                <div class="col-6">
                    <BiInput
                        v-model="formData.typologyApplication"
                        type="text"
                        :placeholder="' '"
                        :label="t(`authorizations.typology_application`)"
                        readonly
                    />
                </div>
            </div>

            <!-- Data Conversione -->
            <div class="mb-3 row align-items-center" v-if="editMode">
                <div class="col-6">
                    <BiInput
                        v-model="formData.conversionDate"
                        class="mt-5"
                        :label="t(`authorizations.conversion_date`)"
                        readonly
                    />
                </div>
            </div>

            <!-- Id domanda -->
            <div class="mb-3 row align-items-center" v-if="editMode">
                <div class="col-6">
                    <BiInput
                        v-model="formData.applicationId"
                        type="text"
                        :placeholder="' '"
                        :label="t(`authorizations.application_id`)"
                        readonly
                    />
                </div>
            </div>

            <!-- Note -->
            <div class="mb-3 row align-items-center">
                <div class="col-6">
                    <BiInput
                        v-model="formData.note"
                        type="text"
                        :placeholder="' '"
                        :label="t(`authorizations.notes`)"
                    />
                </div>
            </div>

            <!-- Data Rilascio -->
            <div class="mb-3 row align-items-center">
                <div class="col-6">
                    <BiDatepicker
                        v-model="formData.releaseDate"
                        :key="releaseDateKey"
                        class="mt-5"
                        :max="today"
                        :label="t(`authorizations.release_date`) + '*'"
                        :errors="errors.releaseDate ? [errors.releaseDate] : []"
                    />
                </div>
            </div>

            <!-- Data Scadenza -->

            <div class="mb-3 row align-items-center">
                <div class="col-6">
                    <BiInput
                        v-model="formData.expirationDate"
                        class="mt-5"
                        :label="t(`authorizations.expiration_date`)"
                        readonly
                    />
                </div>
            </div>

            <div class="text-start mt-5">
                <BiButton
                    color="secondary"
                    is-outlined
                    class="mt-3 me-2"
                    @click="goBackToAuthList"
                >
                    {{ t(`authorizations.cancel`) }}
                </BiButton>
                <BiButton class="mt-3" color="primary" @click="submitForm">
                    {{ t(`authorizations.save`) }}
                </BiButton>
            </div>
        </form>
    </div>

    <div
        v-else-if="isLoading && !isError"
        class="d-flex col-12 justify-content-center mb-5"
    >
        <BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
    </div>
</template>
