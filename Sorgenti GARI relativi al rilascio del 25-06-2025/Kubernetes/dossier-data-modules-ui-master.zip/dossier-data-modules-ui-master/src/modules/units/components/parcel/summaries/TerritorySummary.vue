<script setup lang="ts">
import type {
    CodeDescriptionPair,
    SectorSummaryList,
} from "@/modules/units/models/vineUnit";
import t from "@/modules/units/utils/i18n";
import { useDdmStore } from "@/stores/ddmStore";
import { areaSQMInHA } from "@/utils/utils";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { computed, defineEmits, defineProps } from "vue";
import AnomaliesIcon from "../AnomaliesIcon.vue";

const ddmStore = useDdmStore();

const props = defineProps<{
    sectorSummaryList: SectorSummaryList;
    loadingCounter: number;
}>();

const isErrorEmptyShown = computed(() => {
    return (
        !props.sectorSummaryList.length &&
        props.loadingCounter === 0 &&
        ddmStore.loadingCounter === 0
    );
});

const emits = defineEmits<{
    (e: "go:to:list", sector: CodeDescriptionPair): void;
}>();
</script>
<template>
    <BiTable is-row-hover is-header-light is-custom responsive-breakpoint="md">
        <template #head>
            <tr class="text-primary">
                <th scope="col">
                    {{ t(`parcels.city`) }}
                </th>
                <th scope="col">
                    {{ t(`parcels.num_parcels`) }}
                </th>
                <th scope="col">
                    {{ t(`parcels.vu_num`) }}
                </th>
                <th scope="col">
                    {{ t(`parcels.area`) }}
                </th>
                <th scope="col">
                    {{ t(`parcels.anomalies`) }}
                </th>
                <th scope="col"></th>
            </tr>
        </template>
        <template #body>
            <tr v-if="isErrorEmptyShown" class="align-middle">
                <td :colspan="6" class="py-3 text-center">
                    {{ t(`errors.no_data_available`) }}
                </td>
            </tr>
            <tr
                v-else
                v-for="sector in sectorSummaryList"
                :key="sector.sector.id"
                class="align-middle"
            >
                <td :data-label="t(`parcels.city`)">
                    <small>{{ sector.sector.short_descr }}</small>
                </td>
                <td :data-label="t(`parcels.num_parcels`)">
                    <small>{{ sector.num_parcel }}</small>
                </td>
                <td :data-label="t(`parcels.vu_num`)">
                    <small>{{ sector.num_units }}</small>
                </td>
                <td :data-label="t(`parcels.area`)">
                    <small>
                        {{ areaSQMInHA(sector.total_unit_area_sqm) }}
                    </small>
                </td>
                <td :data-label="t(`parcels.anomalies`)">
                    <AnomaliesIcon :anomalies="sector.anomalies_list" />
                </td>
                <td class="text-end">
                    <BiIconButton
                        class="mx-1"
                        icon="arrow-right"
                        iconStyle="fas"
                        color="primary"
                        isOutlined
                        @click="
                            emits('go:to:list', {
                                code: sector.sector.sector_code,
                                description: sector.sector.description,
                            })
                        "
                    />
                </td>
            </tr>
        </template>
    </BiTable>
</template>
