<script setup lang="ts">
import type {
    CodeDescriptionPair,
    VarietySummaryList,
} from "@/modules/units/models/vineUnit";
import t from "@/modules/units/utils/i18n";
import { useDdmStore } from "@/stores/ddmStore";
import { anomalyIcons, getAnomalyMaxLevel } from "@/utils/anomalyUtils";
import { areaSQMInHA } from "@/utils/utils";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { computed, defineEmits, defineProps } from "vue";

const ddmStore = useDdmStore();

const props = defineProps<{
    varietySummaryList: VarietySummaryList;
    loadingCounter: number;
}>();

const isErrorEmptyShown = computed(() => {
    return (
        !props.varietySummaryList.length &&
        props.loadingCounter === 0 &&
        ddmStore.loadingCounter === 0
    );
});

const emits = defineEmits<{
    (e: "go:to:list", variety: CodeDescriptionPair): void;
}>();
</script>
<template>
    <BiTable is-row-hover is-header-light is-custom responsive-breakpoint="md">
        <template #head>
            <tr class="text-primary">
                <th scope="col">
                    {{ t(`parcels.variety`) }}
                </th>
                <th scope="col">
                    {{ t(`parcels.num_parcels`) }}
                </th>
                <th scope="col">
                    {{ t(`parcels.vu_num`) }}
                </th>
                <th scope="col">
                    {{ t(`parcels.area`) }}
                </th>
                <th scope="col">
                    {{ t(`parcels.anomalies`) }}
                </th>
                <th scope="col"></th>
            </tr>
        </template>
        <template #body>
            <tr v-if="isErrorEmptyShown" class="align-middle">
                <td :colspan="6" class="py-3 text-center">
                    {{ t(`errors.no_data_available`) }}
                </td>
            </tr>
            <tr
                v-else
                v-for="variety in varietySummaryList"
                :key="variety.variety.code"
            >
                <td :data-label="t(`parcels.variety`)">
                    <small>{{ variety.variety.description }}</small>
                </td>
                <td :data-label="t(`parcels.num_parcels`)">
                    <small>{{ variety.num_parcel }}</small>
                </td>
                <td :data-label="t(`parcels.vu_num`)">
                    <small>{{ variety.num_units }}</small>
                </td>
                <td :data-label="t(`parcels.area`)">
                    <small>
                        {{ areaSQMInHA(variety.total_unit_area_sqm) }}
                    </small>
                </td>
                <td :data-label="t(`parcels.anomalies`)">
                    <BiIcon
                        v-if="variety.anomalies_list.length"
                        :icon="
                            anomalyIcons[
                                getAnomalyMaxLevel(variety.anomalies_list)
                            ]
                        "
                        class="mx-2 fa-lg fa-solid"
                        :color="getAnomalyMaxLevel(variety.anomalies_list)"
                    />
                </td>
                <td class="text-end">
                    <BiIconButton
                        class="mx-1"
                        icon="arrow-right"
                        iconStyle="fas"
                        color="primary"
                        isOutlined
                        @click="
                            emits('go:to:list', {
                                code: variety.variety.code,
                                description: variety.variety.description,
                            })
                        "
                    />
                </td>
            </tr>
        </template>
    </BiTable>
</template>
