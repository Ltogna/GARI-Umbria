<script setup lang="ts">
import AlertMessage from "@/components/AlertMessage.vue";
import { DDM_MODULE_ID } from "@/constants";
import t from "@/modules/units/utils/i18n";
import { useDdmStore } from "@/stores/ddmStore";
import { areaSQMInHA } from "@/utils/utils";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { computed, onMounted, ref } from "vue";
import { useRoute } from "vue-router";
import { getQuotasSummary } from "../../resources/api/vineUnit";
import { useVineUnitStore } from "../../stores/vineUnit";

const route = useRoute();

const vineUnitStore = useVineUnitStore();
const ddmStore = useDdmStore();
const nextKey = ref<string | null>(null);

onMounted(async () => {
    try {
        vineUnitStore.loadingCounter++;
        await fetchQuotasSummaryList(nextKey.value, false);
    } catch (error) {
        // TODO - HANDLE ERROR
        console.error(error);
    } finally {
        vineUnitStore.loadingCounter--;
    }
});

const isErrorEmptyShown = computed(() => {
    return (
        !vineUnitStore.quotasSummary.length &&
        vineUnitStore.loadingCounter === 0 &&
        ddmStore.loadingCounter === 0
    );
});

async function fetchQuotasSummaryList(nk: string | null, loadMore: boolean) {
    vineUnitStore.loadingCounter++;
    const res = await getQuotasSummary(+route.params.partyId, nk);
    if (loadMore) vineUnitStore.quotasSummary.push(...res.records);
    else vineUnitStore.quotasSummary = res.records;
    nextKey.value = res.nextKey;
    vineUnitStore.loadingCounter--;
}
</script>
<template>
    <div class="row">
        <div class="col-12">
            <h4>{{ t(`quotas.quotas_do_igt`) }}</h4>
            <BiTable
                is-row-hover
                is-header-light
                is-custom
                responsive-breakpoint="md"
                :next-key="nextKey"
                :load-more-label="t(`load_more`)"
                @load-more="fetchQuotasSummaryList(nextKey, true)"
                class="mt-5"
            >
                <template #head>
                    <tr class="text-primary">
                        <th scope="col">
                            {{ t(`quotas.tender`) }}
                        </th>
                        <th scope="col">
                            {{ t(`quotas.tot_assigned_quota`) }}
                        </th>
                        <th scope="col">
                            {{ t(`quotas.used_quota`) }}
                        </th>
                        <th scope="col">
                            {{ t(`quotas.revoked_quota`) }}
                        </th>
                        <th scope="col">
                            {{ t(`quotas.residual_quota`) }}
                        </th>
                    </tr>
                </template>

                <template #body>
                    <tr
                        v-for="(quota, index) in vineUnitStore.quotasSummary"
                        :key="index"
                        class="align-middle"
                    >
                        <td :data-label="t(`quotas.tender`)">
                            <small>{{ quota.wineQuota }}</small>
                        </td>
                        <td :data-label="t(`quotas.tot_assigned_quota`)">
                            <small>{{
                                areaSQMInHA(quota.assignedQuota)
                            }}</small>
                        </td>
                        <td :data-label="t(`quotas.used_quota`)">
                            <small>{{ areaSQMInHA(quota.usedQuota) }}</small>
                        </td>
                        <td :data-label="t(`quotas.revoked_quota`)">
                            <small>{{ areaSQMInHA(quota.revokedQuota) }}</small>
                        </td>
                        <td :data-label="t(`quotas.residual_quota`)">
                            <small>{{
                                areaSQMInHA(quota.residualQuote)
                            }}</small>
                        </td>
                    </tr>
                </template>
            </BiTable>
            <AlertMessage
                :modelValue="isErrorEmptyShown"
                :dismissable="false"
                :level="'info'"
            >
                {{ t(`${DDM_MODULE_ID}.message.empty_list`) }}
            </AlertMessage>
        </div>
    </div>
</template>
