<script setup lang="ts">
import useQueryFilter from "@/composables/useQueryFilter";
import type { AnomalySearchModel } from "@/models/anomalyLevel";
import type { Parcel, OliveUnitModel } from "@/modules/units/models/oliveUnit";
import {
    getParcelById,
    getUnitById,
} from "@/modules/units/resources/api/oliveUnit";
import { useOliveUnitStore } from "@/modules/units/stores/oliveUnit";
import t from "@/modules/units/utils/i18n";
import { areaSQMInHAWithLabel, printDateInfo } from "@/utils/utils";
import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import { parseISO } from "date-fns";
import { computed, onMounted, ref } from "vue";
import { useRoute } from "vue-router";
import DescriptionListItem from "./summaries/DescriptionListItem.vue";
import useDateFormat from "@/composables/useDateFormat";

const { dateFormat } = useDateFormat();
const oliveUnitStore = useOliveUnitStore();
const route = useRoute();

const { filter: dateFilter } = useQueryFilter("date");

const curParcel = ref<Parcel | null>(null);
const targetUnit = ref<OliveUnitModel | null>();

onMounted(async () => {
    try {
        oliveUnitStore.loadingCounter++;
        curParcel.value = await getParcelById(
            parseISO(dateFilter.value),
            +route.params.parcelId,
            true,
            true,
            true
        );
        targetUnit.value = await getUnitById(
            parseISO(dateFilter.value),
            +route.params.parcelId,
            +route.params.landCoverId,
            +route.params.oliveUnitId,
        );
        if (targetUnit.value) {
            targetUnit.value.unit_type = t(`units.type`);
        }
    } catch (error) {
        // TODO - HANDLE ERROR
        console.error(error);
    } finally {
        oliveUnitStore.loadingCounter--;
    }
});

const title = computed(() => {
    if (targetUnit.value && curParcel.value) {
        return `
            ${t(`parcels.parcel_detail`)}
            ${curParcel.value.sector.sector_code} -
            ${curParcel.value.sector.short_descr} -
            ${curParcel.value.block.description} -
            ${curParcel.value.parcel} -
            ${t(`parcels.vu`)}: ${targetUnit.value.code}
        `;
    }
    return "";
});

const plantingDay = computed(() => {
    return printDateInfo(
        targetUnit.value?.planting_day,
        targetUnit.value?.planting_day_precision,
    );
});

const anomalies = computed(() => {
    if (!targetUnit.value || !targetUnit.value.anomalies?.length) return null;

    const distinctAnomaliesList = new Set<AnomalySearchModel>();
    targetUnit.value.anomalies.map((anomaly) =>
        distinctAnomaliesList.add(anomaly),
    );

    return [...distinctAnomaliesList].map((it) => it.type.code).join(", ");
});

const lastUpdate = computed(() => {
    if (targetUnit.value?.last_update) {
        return dateFormat(targetUnit.value?.last_update ?? null);
    }
    return "-";
});
</script>
<template>
    <div class="row">
        <div class="col-12">
            <h4>
                {{ title }}
            </h4>
            <div class="mt-3">
                <BiAccordion :modelValue="true" :title="t(`parcels.vu_card`)">
                    <dl class="ps-4 row" v-if="targetUnit">
                        <DescriptionListItem
                            i18nKey="parcels.type"
                            :value="targetUnit.unit_type"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.variety"
                            :value="targetUnit.variety"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.area"
                            :value="areaSQMInHAWithLabel(targetUnit.area_sqm)"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.planting_year"
                            :value="plantingDay[0]"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.planting_month"
                            :value="plantingDay[1]"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.planting_type"
                            :value="targetUnit.planting_type"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.distance_on_the_row_cm"
                            :value="targetUnit.distance_on_the_row_cm"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.distance_between_rows_cm"
                            :value="targetUnit.distance_between_rows_cm"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.farming_form"
                            :value="targetUnit.farming_form"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.irrigation_type"
                            :value="targetUnit.irrigation"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.production_destination"
                            :value="targetUnit.product_destination"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.altitude"
                            :value="targetUnit.altitude_above_sea_level"
                        />
                        <DescriptionListItem
                            :i18n-key="'parcels.plants_number'"
                            :value="targetUnit.plants_number"
                        />
                        <DescriptionListItem
                            :i18n-key="'parcels.adherence_quality_system'"
                            :value="targetUnit.quality_system"
                        />
                        <DescriptionListItem
                            :i18n-key="'parcels.protection_structures'"
                            :value="targetUnit.protection_structure"
                        />
                        <DescriptionListItem
                            i18nKey="parcels.last_edit_date"
                            :value="lastUpdate"
                        />
                    </dl>
                </BiAccordion>
            </div>
            <div v-if="anomalies" class="mt-3">
                <BiAccordion :modelValue="true" :title="t(`parcels.anomalies`)">
                    <ul class="list-unstyled">
                        <li>
                            {{ anomalies }}
                        </li>
                    </ul>
                </BiAccordion>
            </div>
        </div>
    </div>
</template>
