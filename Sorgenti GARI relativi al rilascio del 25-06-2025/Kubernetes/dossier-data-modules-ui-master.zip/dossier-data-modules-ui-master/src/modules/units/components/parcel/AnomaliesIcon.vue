<script setup lang="ts">
import type { AnomalySearchModel } from "@/models/anomalyLevel";
import { anomalyIcons, getAnomalyMaxLevel } from "@/utils/anomalyUtils";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { defineProps } from "vue";

defineProps<{
    anomalies?: AnomalySearchModel[] | null;
}>();
</script>
<template>
    <span v-if="anomalies && anomalies.length">
        <BiIcon
            :icon="anomalyIcons[getAnomalyMaxLevel(anomalies)]"
            :size="'xl'"
            class="adjusted-icon"
            :color="getAnomalyMaxLevel(anomalies)"
        />
    </span>
</template>
