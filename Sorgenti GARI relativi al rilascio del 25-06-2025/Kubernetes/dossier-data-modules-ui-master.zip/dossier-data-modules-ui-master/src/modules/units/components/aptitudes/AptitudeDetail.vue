<script setup lang="ts">
import AlertMessage from "@/components/AlertMessage.vue";
import useDateFormat from "@/composables/useDateFormat";
import { DDM_MODULE_ID } from "@/constants";
import t from "@/modules/units/utils/i18n";
import {
    convertToDate,
    emptyFieldPlaceholder,
    formatDate,
} from "@/utils/utils";
import { computed, onMounted, ref } from "vue";
import { useRoute } from "vue-router";
import { VineUnitStatusEnum, type AptitudeDetail } from "../../models/vineUnit";
import { getAptitudeDetailById } from "../../resources/api/aptitudes";
import { useVineUnitStore } from "../../stores/vineUnit";

const { dateFormat } = useDateFormat();
const route = useRoute();

const vineUnitStore = useVineUnitStore();
const aptitudeDetail = ref<AptitudeDetail | null>(null);

onMounted(async () => {
    try {
        vineUnitStore.loadingCounter++;
        if (!vineUnitStore.aptitudesSummary.length) {
            await vineUnitStore.fetchAptitudeSummaryList(+route.params.partyId);
        }
        if (!vineUnitStore.aptitudesUvList.length) {
            await vineUnitStore.fetchAptitudesUvList(
                +route.params.partyId,
                route.params.doIgtCode.toString(),
                null,
            );
        }

        aptitudeDetail.value = await getAptitudeDetailById(
            formatDate(vineUnitStore.curDate),
            +route.params.parcelId,
            +route.params.landCoverId,
            +route.params.vineUnitId,
            +route.params.vineAptitudeId,
        );
    } catch (error) {
        // TODO - HANDLE ERROR
        console.error(error);
    } finally {
        vineUnitStore.loadingCounter--;
    }
});

const title = computed(() => {
    const currentAptitudeUv = vineUnitStore.aptitudesUvList.find(
        (aptitudeUv) =>
            aptitudeUv.vineAptitudeId.toString() ===
            route.params.vineAptitudeId,
    );

    if (currentAptitudeUv) {
        return `${currentAptitudeUv.sector.sector_code} - ${currentAptitudeUv.sector.short_descr} - ${currentAptitudeUv.block.short_descr} - ${currentAptitudeUv.parcelCode} UV:${currentAptitudeUv.vineUnitCode}`;
    }
    return "";
});

const isDateRovocationShown = computed(() => {
    if (aptitudeDetail.value) {
        const date = convertToDate(aptitudeDetail.value.day_to)!;
        const noRevokedDate = new Date("9999-12-31");

        if (date.getTime() === noRevokedDate.getTime()) return false;
    }

    return true;
});
</script>
<template>
    <template v-if="!aptitudeDetail && vineUnitStore.loadingCounter === 0">
        <AlertMessage :modelValue="true" :dismissable="false" :level="'info'">
            {{ t(`${DDM_MODULE_ID}.message.empty_list`) }}
        </AlertMessage>
    </template>
    <template v-else-if="aptitudeDetail">
        <div class="row">
            <div class="col-12">
                <h4>{{ title }}</h4>
            </div>
            <div class="mt-3 col-12">
                <strong>
                    {{ t(`aptitudes.aptitudes_do_igt`) }}
                </strong>
            </div>
        </div>
        <div class="mt-3 row">
            <div class="col-3">
                <p>{{ t(`aptitudes.code`) }}*</p>
            </div>
            <div class="col-9">
                {{ aptitudeDetail!.doigt.code }}
            </div>
        </div>
        <div class="row">
            <div class="col-3">
                <p>{{ t(`aptitudes.category`) }}</p>
            </div>
            <div class="col-9">
                {{
                    emptyFieldPlaceholder(
                        aptitudeDetail!.doigt.category_description,
                    )
                }}
            </div>
        </div>
        <div class="row">
            <div class="col-3">
                <p>{{ t(`aptitudes.name`) }}</p>
            </div>
            <div class="col-9">
                {{
                    emptyFieldPlaceholder(
                        aptitudeDetail!.doigt.name_description,
                    )
                }}
            </div>
        </div>
        <div class="row">
            <div class="col-3">
                <p>{{ t(`aptitudes.typology`) }}</p>
            </div>
            <div class="col-9">
                {{ emptyFieldPlaceholder(aptitudeDetail!.doigt.description) }}
            </div>
        </div>
        <div class="row">
            <div class="col-3">
                <p>{{ t(`aptitudes.date_start`) }}*</p>
            </div>
            <div class="col-9">
                {{
                    aptitudeDetail!.day_from
                        ? dateFormat(convertToDate(aptitudeDetail!.day_from))
                        : "-"
                }}
            </div>
        </div>
        <div v-if="isDateRovocationShown" class="row">
            <div class="col-3">
                <p>{{ t(`aptitudes.date_revocation`) }}</p>
            </div>
            <div class="col-9">
                {{
                    aptitudeDetail!.day_to
                        ? dateFormat(convertToDate(aptitudeDetail!.day_to))
                        : "-"
                }}
            </div>
        </div>
        <div class="row">
            <div class="col-3">
                <p>{{ t(`aptitudes.block_typology`) }}*</p>
            </div>
            <div class="col-9">
                {{
                    aptitudeDetail!.prevent_typology
                        ? VineUnitStatusEnum.YES
                        : VineUnitStatusEnum.NO
                }}
            </div>
        </div>
        <div class="row">
            <div class="col-3">
                <p>{{ t(`aptitudes.block_claims`) }}*</p>
            </div>
            <div class="col-9">
                {{
                    aptitudeDetail!.prevent_claim
                        ? VineUnitStatusEnum.YES
                        : VineUnitStatusEnum.NO
                }}
            </div>
        </div>
        <div class="row">
            <div class="col-3">
                <p>{{ t(`aptitudes.block_eligibility`) }}*</p>
            </div>
            <div class="col-9">
                {{
                    aptitudeDetail!.prevent_suitability
                        ? VineUnitStatusEnum.YES
                        : VineUnitStatusEnum.NO
                }}
            </div>
        </div>
        <!-- TODO - Enable on v 1.2 -->
        <!-- <div class="row">
            <div class="col-3">
                <p>{{ t(`aptitudes.mention`) }}</p>
            </div>
            <div class="col-9">COMBO BOX</div>
        </div> -->
    </template>
</template>
