<script setup lang="ts">
import { computed, ref, watch } from "vue";
import t from "@/modules/units/utils/i18n";

import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiCollapse from "@abaco/bootstrap-italia-components/src/components/BiCollapse/BiCollapse.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";

import type { PartyModel, SubjectFilter } from "../../models/application";
import type { ValidatedInput } from "../../models/form";
import { checkMaxLength, verifyField } from "../../utils/formUtils";
import { useApplicationStore } from "../../stores/applicationStore";

const { getColor } = useColors();
const applicationStore = useApplicationStore();

const openSearchSubjectModal = ref<boolean>(false);
const showNoSubjectsAlert = ref<boolean>(false);
const showResult = ref<boolean>(false);

const partyRegistryUrlNotExist = false;
computed(() => applicationStore.getTenantConfigPartyRegistryError);

const isLoading = applicationStore.getIsLoading;

const emit = defineEmits<{
    (e: "searchFormVisible", value: boolean): void;
    (e: "selectedSubject", val: PartyModel): void;
}>();

const props = defineProps<{
    error?: string[];
    valueCuaa?: string | null;
}>();

const modalForm = ref<SubjectFilter>({
    cuaa: "",
    denomination: "",
    partyId: "",
});

const searchFormValidators = ref<Record<string, ValidatedInput<string>>>({
    cuaa: {
        val: modalForm.value.cuaa,
        errors: [],
    },
    denomination: {
        val: modalForm.value.denomination,
        errors: [],
    },
    partyId: {
        val: modalForm.value.partyId,
        errors: [],
    },
});

const resultSubjects = computed(() => applicationStore.subjectList?.records);
const applicationFilter = computed(
    () => applicationStore.applicationListStatusFilter,
);

watch(
    () => props.valueCuaa,
    () => {
        if (props.valueCuaa === null) {
            applicationStore.setApplicationListFilter({
                referenceSubject: "",
                applicationNumber: "",
            });
        }
    },
    { immediate: true, deep: true },
);

function onSelectSubject(subject: PartyModel) {
    applicationStore.setApplicationListFilter({
        referenceSubject: subject.code || "",
        applicationNumber: "",
    });
    applicationStore.setSelectedSubject(subject);
    emit("selectedSubject", subject);

    onCloseModal();
}

async function searchSubjectList() {
    searchFormValidators.value.cuaa.val = modalForm.value.cuaa;
    searchFormValidators.value.denomination.val = modalForm.value.denomination;
    const maxLengthErrorMessage = t(`authorizations.general.maxLength`);
    const errors: boolean[] = [];
    errors.push(
        verifyField(
            [
                () =>
                    checkMaxLength(
                        searchFormValidators.value.cuaa,
                        50,
                        maxLengthErrorMessage,
                    ),
            ],
            searchFormValidators.value.cuaa,
        ),
    );

    errors.push(
        verifyField(
            [
                () =>
                    checkMaxLength(
                        searchFormValidators.value.denomination,
                        150,
                        maxLengthErrorMessage,
                    ),
            ],
            searchFormValidators.value.denomination,
        ),
    );

    if (errors.findIndex((x: boolean) => x) !== -1) return;

    showNoSubjectsAlert.value = false;
    applicationStore.clearSubjectList();
    await callSearchSubject();
    if (
        (applicationStore.hasError &&
            applicationStore.getErrorResponse?.response.status === 404) ||
        (applicationStore.subjectList?.count || 0) === 0
    ) {
        applicationStore.clearSubjectList();
        showNoSubjectsAlert.value = true;
    } else {
        showResult.value = true;
    }
}

async function callSearchSubject() {
    await applicationStore.searchSubjects(
        modalForm.value.cuaa,
        modalForm.value.denomination,
    );
}

function openSearchModal() {
    emit("searchFormVisible", true);
    openSearchSubjectModal.value = true;
}

function onCloseModal() {
    emit("searchFormVisible", false);
    openSearchSubjectModal.value = false;
    applicationStore.clearSubjectList();
    modalForm.value.partyId = "";
    modalForm.value.cuaa = "";
    modalForm.value.denomination = "";
    searchFormValidators.value.cuaa.errors = [];
    searchFormValidators.value.denomination.errors = [];
    showNoSubjectsAlert.value = false;
}

watch(
    () => modalForm.value.cuaa,
    () => {
        if (modalForm.value.cuaa == "") return;
        modalForm.value.denomination = "";
        searchFormValidators.value.denomination.errors = [];
    },
);

watch(
    () => modalForm.value.denomination,
    () => {
        if (modalForm.value.denomination == "") return;
        modalForm.value.cuaa = "";
        searchFormValidators.value.cuaa.errors = [];
    },
);
</script>
<template>
    <div class="row">
        <div class="col-4 mb-3 row align-items-center">
            <BiInput
                v-model="applicationFilter.referenceSubject"
                :label="t(`authorizations.cuaa`) + '*'"
                required
                :errors="props.error"
                readonly
            ></BiInput>
        </div>
        <div class="col-2 mb-3 row align-items-center">
            <BiButton
                v-if="!isLoading && !partyRegistryUrlNotExist"
                class="mt-3"
                is-outlined
                color="primary"
                @click.stop="openSearchModal()"
            >
                {{ t(`authorizations.search`) }}
            </BiButton>
        </div>
    </div>

    <BiModal
        :disabled-teleport="true"
        :modelValue="openSearchSubjectModal"
        :ariaLabelledby="t(`authorizations.search_cuaa_modal_title`)"
        :title="t(`authorizations.search_cuaa_modal_title`)"
        :size="'lg'"
        :preventDismiss="true"
        :extra-footer-class="'justify-content-center'"
        ><template v-slot:body>
            <form
                id="subjectSearchForm"
                ref="subjectSearchFormRef"
                @submit.prevent="() => {}"
            >
                <div class="form-group mt-5 w-100">
                    <BiInput
                        :label="t(`authorizations.cuaa`)"
                        :placeholder="t(`authorizations.input_code`)"
                        v-model="modalForm.cuaa"
                        class="mb-4"
                        :errors="searchFormValidators.cuaa.errors"
                    />
                </div>
                <div class="form-group w-100">
                    <BiInput
                        :label="t(`authorizations.denomination`)"
                        :placeholder="t(`authorizations.textToSearch`)"
                        v-model="modalForm.denomination"
                        class="mb-4"
                        :errors="searchFormValidators.denomination.errors"
                    />
                </div>
            </form>
        </template>
        <template v-slot:footer>
            <div class="d-flex flex-column">
                <div v-if="showNoSubjectsAlert" class="row">
                    <div class="col-3"></div>
                    <div class="my-3">
                        <BiAlert isWarn>
                            <template #body>
                                {{
                                    t(`unit.errors.NO_PARTY_FOUND_EXCEPTION`)
                                }}</template
                            >
                        </BiAlert>
                    </div>
                    <div class="col-3"></div>
                </div>
                <div>
                    <div
                        v-if="!applicationStore.loading"
                        class="mt-0 mb-5 d-flex justify-content-center"
                    >
                        <BiButton
                            size="lg"
                            class="btn"
                            :class="getColor('button', 'secondary', 'outline')"
                            @click.stop="onCloseModal"
                        >
                            {{ t(`authorizations.cancel`) }}
                        </BiButton>
                        <BiButton
                            :is-disabled="
                                !modalForm.cuaa && !modalForm.denomination
                            "
                            type="submit"
                            form="subjectSearchForm"
                            isPrimary
                            size="lg"
                            class="ms-3 btn"
                            :class="getColor('button', 'success')"
                            @click.stop="searchSubjectList()"
                            >{{ t(`authorizations.search`) }}</BiButton
                        >
                    </div>

                    <div
                        v-else
                        class="d-flex col-12 justify-content-center mb-5"
                    >
                        <BiProgressIndicator
                            :type="'spinner'"
                        ></BiProgressIndicator>
                    </div>
                </div>
            </div>

            <div id="table-collapse" class="w-100">
                <BiTable
                    v-if="resultSubjects"
                    isRowHover
                    class="table-hover mb-4 table-responsive w-100"
                    extraTableClasses="table-head-bg"
                    isResponsive
                >
                    <template v-slot:head>
                        <tr
                            class="bg-light"
                            :class="getColor('text', 'secondary')"
                        >
                            <th scope="col">
                                {{ t(`authorizations.denomination`) }}
                            </th>
                            <th scope="col">
                                {{ t(`authorizations.cuaa`) }}
                            </th>
                            <th scope="col"></th>
                        </tr>
                    </template>
                    <template v-slot:body>
                        <tr v-for="(subject, i) in resultSubjects" :key="i">
                            <td :data-label="t(`authorizations.denomination`)">
                                {{ subject.description }}
                            </td>
                            <td :data-label="t(`authorizations.cuaa`)">
                                {{ subject.code }}
                            </td>
                            <td class="actions">
                                <div class="d-flex justify-content-center">
                                    <BiButton
                                        :width="40"
                                        @click.stop="onSelectSubject(subject)"
                                        :class="`${getColor('button', 'info', 'outline')}`"
                                    >
                                        <BiIcon
                                            icon="plus"
                                            color="primary"
                                            size="lg"
                                        />
                                    </BiButton>
                                </div>
                            </td>
                        </tr>
                    </template>
                </BiTable>
                <div
                    class="d-flex col-12 justify-content-center mb-5"
                    @click.stop
                    v-if="resultSubjects"
                >
                    <BiButton
                        v-if="
                            !applicationStore.loading &&
                            !applicationStore.hasError &&
                            applicationStore.subjectList?.nextKey &&
                            parseInt(applicationStore.subjectList?.nextKey) > 0
                        "
                        @click="callSearchSubject()"
                        :class="getColor('button', 'primary', 'outline')"
                    >
                        {{ t(`authorizations.loadMore`) }}
                    </BiButton>
                    <BiProgressIndicator
                        v-if="
                            applicationStore.loading &&
                            applicationStore.subjectList?.nextKey &&
                            parseInt(applicationStore.subjectList?.nextKey) > 0
                        "
                        :type="'spinner'"
                    ></BiProgressIndicator>
                </div>
            </div>
            <BiCollapse
                class="d-none"
                :model-value="showResult"
                :targetSelector="'#table-collapse'"
            >
            </BiCollapse>
        </template>
    </BiModal>
</template>
