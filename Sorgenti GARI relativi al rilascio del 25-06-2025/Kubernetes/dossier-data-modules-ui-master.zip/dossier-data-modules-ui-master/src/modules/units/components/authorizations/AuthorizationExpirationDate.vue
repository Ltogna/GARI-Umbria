<script setup lang="ts">
import t from "@/modules/units/utils/i18n";
import { convertToDate, validateDateInRange } from "@/utils/utils";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import { onMounted, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import type { AuthorizationExpirationDateType } from "../../models/authorization";
import { UnitRouteName } from "../../models/routes";
import {
    getAuthorizationByPartyId,
    getAuthTypes,
    updateAuthExpirationDate,
} from "../../resources/api/authorizations";

const isLoading = ref<boolean>(false);
const isError = ref<boolean>(false);

const router = useRouter();
const route = useRoute();

const authorizationId = ref<string>("");

const errors = ref<Record<string, string | undefined>>({});
const datePickerValue = ref();

const formData = ref<AuthorizationExpirationDateType>({
    authorizationId: null,
    nationalAuthorizationId: null,
    currentExpirationDate: new Date(),
    updateCauseCode: null,
    newExpirationDate: null,
    releaseDate: new Date(),
    note: null,
});

const updateCauseList = ref();

onMounted(async () => {
    getData();
});

function validateForm(): boolean {
    const newErrors: Record<string, string | undefined> = {};

    if (!formData.value.updateCauseCode) {
        newErrors.updateCauseCode = t("errors.form_not_completed");
    }

    if (!formData.value.newExpirationDate) {
        newErrors.newExpirationDate = t("errors.form_not_completed");
    }

    errors.value = newErrors;

    return Object.keys(newErrors).length === 0;
}

async function getData() {
    authorizationId.value = route.params.authorizationId?.toString();
    datePickerValue.value = document.getElementById("newExpirationDateId");

    isLoading.value = true;
    const authorizationData = await getAuthorizationByPartyId(
        route.params.partyId.toString(),
        authorizationId.value.toString(),
    );
    if (authorizationData) {
        isLoading.value = false;
    } else {
        isError.value = true;
    }

    isLoading.value = true;
    updateCauseList.value = await getAuthTypes();
    if (updateCauseList.value) {
        isLoading.value = false;
    } else {
        isError.value = true;
    }

    if (authorizationData) {
        formData.value.authorizationId = authorizationData.authorizationId;
        formData.value.nationalAuthorizationId =
            authorizationData.nationalAuthorizationId;
        formData.value.currentExpirationDate =
            convertToDate(authorizationData.expirationDate) ?? new Date();

        formData.value.note = null;
        formData.value.releaseDate =
            convertToDate(authorizationData.releaseDate) ?? new Date();

        formData.value.newExpirationDate = null;
    }
}

async function goBackToAuthList() {
    await router.push({
        name: UnitRouteName.VINE_AUTHORIZATIONS_SUMMARY,
    });
}

async function goBackToDetailAuth() {
    router.back();
}

async function submitForm() {
    if (!validateForm()) {
        window.scrollTo({ top: 0, behavior: "smooth" });
        return;
    }

    isLoading.value = true;
    const response = await updateAuthExpirationDate(
        route.params.partyId.toString(),
        authorizationId.value,
        formData.value,
    );
    if (response) {
        isLoading.value = false;
        goBackToDetailAuth();
    } else {
        isError.value = true;
    }
}

function checkResetData() {
    const datepickerElement = document.getElementById(
        "newExpirationDateId",
    ) as HTMLInputElement | null;

    if (datepickerElement) {
        const transferDateStr = datepickerElement.value;
        console.log(transferDateStr);

        const error = validateDateInRange({
            dateStr: transferDateStr,
            minDate: new Date(formData.value.releaseDate),
            maxDate: new Date(formData.value.currentExpirationDate),
               errorMessage: ({ min, max }) =>
                t("errors.transfer_exact_date_overflow", {
                    release: min,
                    endDate: max,
                }),
        });

        errors.value.newExpirationDate = error ?? "";
    }
}
</script>

<template>
    <div v-if="!isLoading && !isError">
        <div class="row">
            <div class="row">
                <div class="col-6">
                    <h4>
                        {{ t(`authorizations.authorization_expiration_date`) }}
                    </h4>
                </div>

                <form @submit.prevent="submitForm">
                    <!-- ID Autorizzazione -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiInput
                            v-model="formData.authorizationId"
                            :label="t(`authorizations.authorization_id`)"
                            readonly
                            type="text"
                        ></BiInput>
                    </div>

                    <!-- ID Autorizzazione Nazionale -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiInput
                            v-model="formData.nationalAuthorizationId"
                            :label="
                                t(`authorizations.national_authorization_id`)
                            "
                            readonly
                            type="text"
                        ></BiInput>
                    </div>
                    <!-- Data scadenza attuale -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiDatepicker
                            v-model="formData.currentExpirationDate"
                            :label="t(`authorizations.current_expiration_date`)"
                            :is-readonly="true"
                            type="text"
                        ></BiDatepicker>
                    </div>

                    <!-- Motivo cambio data -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiSelect
                            v-model="formData.updateCauseCode"
                            item-value="id"
                            item-title="text"
                            :items="updateCauseList"
                            :label="
                                t(
                                    `authorizations.expiration_date_update_cause`,
                                ) + '*'
                            "
                            :errors="
                                errors.updateCauseCode
                                    ? [errors.updateCauseCode]
                                    : undefined
                            "
                        />
                    </div>
                    <!-- Nuova data scadenza -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiDatepicker
                            id="newExpirationDateId"
                            v-model="formData.newExpirationDate"
                            :label="
                                t(`authorizations.new_expiration_date`) + '*'
                            "
                            required
                            class="mt-5"
                            :min="formData.releaseDate"
                            :max="formData.currentExpirationDate"
                            :errors="
                                errors.newExpirationDate
                                    ? [errors.newExpirationDate]
                                    : undefined
                            "
                            @change="checkResetData"
                        />
                    </div>

                    <!-- Note -->
                    <div class="col-6 mb-3 row align-items-center">
                        <BiInput
                            v-model="formData.note"
                            :label="t(`authorizations.notes`)"
                        ></BiInput>
                    </div>

                    <div class="text-start mt-5">
                        <BiButton
                            class="mt-3 me-2"
                            is-outlined
                            color="secondary"
                            @click="goBackToAuthList"
                        >
                            {{ t(`authorizations.cancel`) }}
                        </BiButton>
                        <BiButton class="mt-3" color="primary" type="submit">
                            {{ t(`authorizations.save`) }}
                        </BiButton>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div
        v-else-if="isLoading && !isError"
        class="d-flex col-12 justify-content-center mb-5"
    >
        <BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
    </div>
</template>
