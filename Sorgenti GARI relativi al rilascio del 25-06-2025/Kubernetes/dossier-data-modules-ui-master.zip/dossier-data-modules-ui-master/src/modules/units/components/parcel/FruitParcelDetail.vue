<script setup lang="ts">
import AlertMessage from "@/components/AlertMessage.vue";
import useDateFormat from "@/composables/useDateFormat";
import useQueryFilter from "@/composables/useQueryFilter";
import type {
    FruitUnitListModel,
    Parcel,
    ParcelLandLink,
} from "@/modules/units/models/fruitUnit";
import { UnitRouteName } from "@/modules/units/models/routes";
import {
    getParcelById,
    getParcelLandLink,
} from "@/modules/units/resources/api/fruitUnit";
import { useFruitUnitStore } from "@/modules/units/stores/fruitUnit";
import t from "@/modules/units/utils/i18n";
import { areaSQMInHA, convertToDate } from "@/utils/utils";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { parseISO } from "date-fns";
import { computed, onMounted, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import ConductingDetailHeader from "./FruitConductingDetailHeader.vue";
import { MONTH_YEAR_FORMAT } from "@/constants";

const { dateFormat } = useDateFormat();
const router = useRouter();
const route = useRoute();

const fruitUnitStore = useFruitUnitStore();

const { filter: dateFilter } = useQueryFilter("date");

const curParcel = ref<Parcel | null>(null);
const curParcelLandLink = ref<ParcelLandLink | null>(null);
const fruitUnitList = computed(() => {
    const fruitUnits: FruitUnitListModel = [];
    curParcel.value?.landcovers_list.forEach((l) => {
        fruitUnits.push(...l.fruit_units);
    });

    return fruitUnits;
});

const referenceDate = parseISO(dateFilter.value);

onMounted(async () => {
    fruitUnitStore.loadingCounter++;
    curParcel.value = await getParcelById(
        referenceDate,
        +route.params.parcelId,
        true,
        true,
        true
    );
    curParcelLandLink.value = await getParcelLandLink(
        referenceDate,
        +route.params.parcelId,
        +route.params.partyId,
    );
    fruitUnitStore.loadingCounter--;
});

function goToFruitUnitDetail(fruitUnitId: number, landCoverId: number) {
    router.push({
        name: UnitRouteName.FRUIT_UNIT_DETAIL,
        query: {
            date: route.query.date,
        },
        params: {
            fruitUnitId: fruitUnitId,
            landCoverId: landCoverId,
            parcelId: +route.params.parcelId,
        },
    });
}
</script>
<template>
    <ConductingDetailHeader :is-conductin-detail-button-visible="false" :cur-parcel="curParcel"
        :cur-parcel-land-link="curParcelLandLink" />
    <div class="mt-3 row">
        <div class="col-12">
            <h6>{{ t(`parcels.units`) }}</h6>
        </div>
        <div v-if="fruitUnitList.length" class="col-12">
            <BiTable is-row-hover is-header-light is-custom responsive-breakpoint="md">
                <template #head>
                    <tr class="text-primary">
                        <th scope="col">
                            {{ t(`parcels.vu`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.variety`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.month_year_plant`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.planting_layout`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.breeding`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.area`) }}
                        </th>
                        <th scope="col"></th>
                    </tr>
                </template>
                <template #body>
                    <tr v-for="fruitUnit in fruitUnitList" :key="fruitUnit.id" class="align-middle">
                        <td :data-label="t(`parcels.vu`)">
                            <small>{{ fruitUnit.code }}</small>
                        </td>
                        <td :data-label="t(`parcels.variety`)">
                            <small>{{ fruitUnit.variety.description }}</small>
                        </td>
                        <td :data-label="t(`parcels.month_year_plant`)">
                            <small>
                                {{
                                    dateFormat(
                                        convertToDate(fruitUnit.planting_day),
                                        MONTH_YEAR_FORMAT
                                    )
                                }}
                            </small>
                        </td>
                        <td :data-label="t(`parcels.planting_layout`)">
                            <small>
                                {{ fruitUnit.distance_on_the_row_cm }}x{{
                                    fruitUnit.distance_between_rows_cm
                                }}
                            </small>
                        </td>
                        <td :data-label="t(`parcels.breeding`)">
                            <small>
                                {{ fruitUnit.farming_form?.description }}
                            </small>
                        </td>

                        <td :data-label="t(`parcels.area`)">
                            <small>{{ areaSQMInHA(fruitUnit.area_sqm) }}</small>
                        </td>
                        <td>
                            <small>
                                <BiIconButton class="mx-1" icon="arrow-right" iconStyle="fas" color="primary" isOutlined
                                    @click="
                                        goToFruitUnitDetail(
                                            fruitUnit.id,
                                            fruitUnit.land_cover_id,
                                        )
                                        " />
                            </small>
                        </td>
                    </tr>
                </template>
            </BiTable>
        </div>
        <div v-else class="col-12">
            <AlertMessage :modelValue="true" :dismissable="false" :level="'info'">
                {{ t(`no_units`) }}
            </AlertMessage>
        </div>
    </div>
</template>
