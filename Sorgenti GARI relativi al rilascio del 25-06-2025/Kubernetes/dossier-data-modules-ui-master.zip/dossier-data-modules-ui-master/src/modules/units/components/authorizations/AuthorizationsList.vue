<script setup lang="ts">
import AlertMessage from "@/components/AlertMessage.vue";
import useDateFormat from "@/composables/useDateFormat";
import { DDM_MODULE_ID } from "@/constants";
import t from "@/modules/units/utils/i18n";
import { useDdmStore } from "@/stores/ddmStore";
import { areaSQMInHA, emptyFieldPlaceholder } from "@/utils/utils";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiCheckbox from "@abaco/bootstrap-italia-components/src/components/form/BiCheckbox.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { computed, onMounted, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import { UnitRouteName } from "../../models/routes";
import { getAuthorizationsList } from "../../resources/api/authorizations";
import { useVineUnitStore } from "../../stores/vineUnit";
import { usePermissionsStore } from "../../stores/unitPermissions";

const { dateFormat } = useDateFormat();
const router = useRouter();
const route = useRoute();

const vineUnitStore = useVineUnitStore();
const permissionsStore = usePermissionsStore();
const ddmStore = useDdmStore();
const includeExpired = ref<boolean>(false);
const nextKey = ref<string | null>(null);

onMounted(async () => {
    try {
        vineUnitStore.loadingCounter++;
        if (!vineUnitStore.authorizationsSummary.length) {
            await vineUnitStore.fetchAuthorizationSummaryList(
                +route.params.partyId,
                null,
            );
        }

        await fetchAuthorizationsList(nextKey.value, false);
    } catch (error) {
        // TODO - HANDLE ERROR
        console.error(error);
    } finally {
        vineUnitStore.loadingCounter--;
    }
});

const isErrorEmptyShown = computed(() => {
    return (
        !vineUnitStore.authorizationsList.length &&
        vineUnitStore.loadingCounter === 0 &&
        ddmStore.loadingCounter === 0
    );
});

async function onIncludeExpiredChange(value: boolean) {
    includeExpired.value = value;

    await fetchAuthorizationsList(nextKey.value, false);
}

async function fetchAuthorizationsList(nk: string | null, loadMore: boolean) {
    vineUnitStore.loadingCounter++;
    const res = await getAuthorizationsList(
        +route.params.partyId,
        route.params.authTypeCode.toString(),
        includeExpired.value,
        nk,
    );
    if (loadMore) vineUnitStore.authorizationsList.push(...res.records);
    else vineUnitStore.authorizationsList = res.records;
    nextKey.value = res.nextKey;
    vineUnitStore.loadingCounter--;
}

function goToAuthorizationDetail(authorizationId: number) {
    if (permissionsStore.vineAuth.viewer) {
        router.push({
            name: UnitRouteName.VINE_AUTHORIZATION_DETAIL,
            params: { authorizationId },
        });
    }
    if (permissionsStore.vineAuth.editor) {
        router.push({
            name: UnitRouteName.VINE_AUTHORIZATION_EDIT,
            params: { authorizationId },
        });
    }
}

function goToCreateNewAuthorization() {
    router.push({
        name: UnitRouteName.VINE_AUTHORIZATION_NEW,
    });
}
</script>

<template>
    <div class="row">
        <div class="row">
            <div class="col-6">
                <h4>
                    {{ t(`authorizations.authorizations_list`) }}
                </h4>
            </div>
            <div class="d-flex align-items-center justify-content-end col-2">
                <BiButton
                    v-show="permissionsStore.vineAuth.editor || true"
                    color="primary"
                    is-outlined
                    @click="goToCreateNewAuthorization"
                >
                    {{ t(`authorizations.new_authorization`) }}
                </BiButton>
            </div>
            <div class="text-end col-4">
                <BiCheckbox
                    :label="t(`authorizations.show_expired`)"
                    :value="includeExpired"
                    @update:model-value="onIncludeExpiredChange"
                ></BiCheckbox>
            </div>
        </div>
        <div class="col-12">
            <BiTable
                is-row-hover
                is-header-light
                is-custom
                responsive-breakpoint="md"
                :next-key="nextKey"
                :load-more-label="t(`load_more`)"
                @load-more="fetchAuthorizationsList(nextKey, true)"
                class="mt-5"
            >
                <template #head>
                    <tr class="text-primary">
                        <th scope="col">
                            {{ t(`authorizations.authorization_id`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.province`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.authorization_type`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.authorization_surface`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.planted_surface`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.transferred_surface`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.residual_surface`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.release_date`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.expiration_date`) }}
                        </th>
                        <th scope="col"></th>
                    </tr>
                </template>
                <template #body>
                    <tr
                        v-for="authorization in vineUnitStore.authorizationsList"
                        :key="authorization.authorizationId"
                        class="align-middle"
                    >
                        <td :data-label="t(`authorizations.authorization_id`)">
                            <small>{{ authorization.authorizationId }}</small>
                        </td>
                        <td :data-label="t(`authorizations.province`)">
                            <small>
                                {{
                                    emptyFieldPlaceholder(
                                        authorization.denoProv,
                                    )
                                }}
                            </small>
                        </td>
                        <td
                            :data-label="t(`authorizations.authorization_type`)"
                        >
                            <small>{{ authorization.authorizationType }}</small>
                        </td>
                        <td
                            :data-label="
                                t(`authorizations.authorization_surface`)
                            "
                        >
                            <small>{{
                                authorization.surfaceAuthorization
                                    ? areaSQMInHA(
                                          authorization.surfaceAuthorization,
                                      )
                                    : "-"
                            }}</small>
                        </td>
                        <td :data-label="t(`authorizations.planted_surface`)">
                            <small>
                                {{ areaSQMInHA(authorization.plantedSurface) }}
                            </small>
                        </td>
                        <td
                            :data-label="
                                t(`authorizations.transferred_surface`)
                            "
                        >
                            <small>{{
                                areaSQMInHA(authorization.transferredSurface)
                            }}</small>
                        </td>
                        <td :data-label="t(`authorizations.residual_surface`)">
                            <small>{{
                                areaSQMInHA(authorization.residualSurface)
                            }}</small>
                        </td>
                        <td :data-label="t(`authorizations.release_date`)">
                            <small>
                                {{
                                    dateFormat(new Date(authorization.dtStart))
                                }}
                            </small>
                        </td>
                        <td :data-label="t(`authorizations.expiration_date`)">
                            <small>
                                {{ dateFormat(new Date(authorization.dtEnd)) }}
                            </small>
                        </td>
                        <td class="text-end">
                            <BiIconButton
                                class="mx-1"
                                icon="arrow-right"
                                iconStyle="fas"
                                color="primary"
                                isOutlined
                                @click="
                                    goToAuthorizationDetail(
                                        authorization.authorizationId,
                                    )
                                "
                            />
                        </td>
                    </tr>
                </template>
            </BiTable>

            <AlertMessage
                :modelValue="isErrorEmptyShown"
                :dismissable="false"
                :level="'info'"
            >
                {{ t(`${DDM_MODULE_ID}.message.empty_list`) }}
            </AlertMessage>
        </div>
    </div>
</template>
