<script setup lang="ts">
import t from "@/modules/units/utils/i18n";
import { onMounted, ref } from "vue";
import { useRoute } from "vue-router";
import { getAuthorizationDetailById } from "../../resources/api/authorizations";
import { useVineUnitStore } from "../../stores/vineUnit";
import type { Authorization } from "../../models/authorization";

const route = useRoute();

const vineUnitStore = useVineUnitStore();
const authorizationDetail = ref<Authorization | null>(null);

onMounted(async () => {
    try {
        vineUnitStore.loadingCounter++;
        if (!vineUnitStore.aptitudesSummary.length) {
            await vineUnitStore.fetchAuthorizationSummaryList(
                +route.params.partyId,
                null,
            );
        }
        if (!vineUnitStore.aptitudesUvList.length) {
            await vineUnitStore.fetchAuthorizationsList(
                +route.params.partyId,
                route.params.authTypeCode.toString(),
                false,
                null,
            );
        }

        authorizationDetail.value = await getAuthorizationDetailById(
            +route.params.partyId,
            +route.params.authorizationId,
        );
    } catch (error) {
        console.error(error);
    } finally {
        vineUnitStore.loadingCounter--;
    }
});
</script>
<template>
    <div class="row">
        <div class="col-12">
            <h4>{{ t(`applications.linked_applications`) }}</h4>
        </div>
    </div>
    <div class="row">
        <div class="col-3">
            <p>{{ t(`authorizations.authorization_id`) }}</p>
        </div>
        <div class="col-9">{{ authorizationDetail?.authorizationId }}</div>
    </div>
    <div class="row">
        <div class="col-3">
            <p>
                {{ t(`authorizations.national_authorization_id`) }}
            </p>
        </div>
        <div class="col-9">
            {{ authorizationDetail?.nationalAuthorizationId }}
        </div>
    </div>
</template>
