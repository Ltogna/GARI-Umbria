<script setup lang="ts">
import AlertMessage from "@/components/AlertMessage.vue";
import useQueryFilter from "@/composables/useQueryFilter";
import t from "@/modules/units/utils/i18n";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { parseISO } from "date-fns";
import { computed, onMounted, ref } from "vue";
import { useRoute } from "vue-router";
import type { Parcel, ParcelLandLink } from "../../models/fruitUnit";
import {
    getParcelById,
    getParcelLandLink,
} from "../../resources/api/fruitUnit";
import { useFruitUnitStore } from "../../stores/fruitUnit";
import ConductingDetailHeader from "./FruitConductingDetailHeader.vue";

const route = useRoute();

const fruitUnitStore = useFruitUnitStore();

const { filter: dateFilter } = useQueryFilter("date");

const curParcel = ref<Parcel | null>(null);
const curParcelLandLink = ref<ParcelLandLink | null>(null);
const referenceDate = parseISO(dateFilter.value);

const conductingDetailList = [
    {
        id: 1,
        cadastral_references: "A061 - CONEGLIANO (TV) - 1 - 00001",
        surface_gis: "2.0137",
        management: "PROPRIETA' 100%",
        surface_management: "2.0137",
        management_period: "20230310",
        intersection: "35%",
    },
    {
        id: 2,
        cadastral_references: "A061 - CONEGLIANO (TV) - 1 - 00002",
        surface_gis: "0.3220",
        management: "PROPRIETA' 100%",
        surface_management: "0.3220",
        management_period: "20210611",
        intersection: "29%",
    },
];

onMounted(async () => {
    fruitUnitStore.loadingCounter++;
    curParcel.value = await getParcelById(
        referenceDate,
        +route.params.parcelId,
        true,
        true,
        true
    );
    curParcelLandLink.value = await getParcelLandLink(
        referenceDate,
        +route.params.parcelId,
        +route.params.partyId,
    );
    fruitUnitStore.loadingCounter--;
});

const isRemoveManagementShown = computed(() => {
    if (!curParcel.value || !curParcel.value.anomalies?.anomalies_list.length)
        return false;

    // TODO - IT MIGHT BE APPROPRIATE TO CREATE A STATIC OBJECT TO ENTER ALL ANOMALY CODES SO THAT YOU DO NOT HAVE TO ENTER THEM MANUALLY EACH TIME
    return curParcel.value.anomalies.anomalies_list.some(
        (it) => it.type.code === "SV03",
    );
});
</script>
<template>
    <ConductingDetailHeader
        :cur-parcel="curParcel"
        :cur-parcel-land-link="curParcelLandLink"
    />
    <div class="mt-3 row">
        <div class="col-12">
            <h6>
                {{ t(`parcels.intersected_cadastral_parcels`) }}
            </h6>
        </div>

        <div v-if="conductingDetailList" class="col-12">
            <BiTable
                is-row-hover
                is-header-light
                is-custom
                responsive-breakpoint="md"
            >
                <template #head>
                    <tr class="text-primary">
                        <th scope="col">
                            {{ t(`parcels.cadastral_references`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.sur_gis_ha`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.management`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.sur_management_ha`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.management_period`) }}
                        </th>
                        <th scope="col">
                            {{ t(`parcels.intersection`) }}
                        </th>
                    </tr>
                </template>

                <template #body>
                    <tr
                        v-for="conductingDetail in conductingDetailList"
                        :key="conductingDetail.id"
                        class="align-middle"
                    >
                        <td :data-label="t(`parcels.cadastral_references`)">
                            <small>
                                {{ conductingDetail.cadastral_references }}
                            </small>
                        </td>
                        <td :data-label="t(`parcels.sur_gis_ha`)">
                            <small>
                                {{ conductingDetail.surface_gis }}
                            </small>
                        </td>
                        <td :data-label="t(`parcels.management`)">
                            <small>
                                {{ conductingDetail.management }}
                            </small>
                        </td>
                        <td :data-label="t(`parcels.sur_management_ha`)">
                            <small>
                                {{ conductingDetail.surface_management }}
                            </small>
                        </td>
                        <td :data-label="t(`parcels.management_period`)">
                            <small>
                                {{ conductingDetail.management_period }}
                            </small>
                        </td>
                        <td :data-label="t(`parcels.intersection`)">
                            <small>
                                {{ conductingDetail.intersection }}
                            </small>
                        </td>
                    </tr>
                </template>
            </BiTable>
        </div>
        <div v-else class="col-12">
            <AlertMessage
                :modelValue="true"
                :dismissable="false"
                :level="'info'"
            >
                {{ t(`error.no_intersected_cadastral_parcel_found`) }}
            </AlertMessage>
        </div>

        <div class="mt-3 col-12">
            Percentuale di superficie intersecata: <strong>64%</strong>
        </div>
    </div>
    <div class="mt-3 row">
        <div class="d-flex col-12">
            <BiButton class="me-2" color="primary" isOutlined @click="() => {}">
                {{ t(`parcels.update_management`) }}
            </BiButton>

            <BiButton
                v-if="isRemoveManagementShown"
                class="me-2"
                color="primary"
                isOutlined
                @click="() => {}"
            >
                {{ t(`parcels.remove_management`) }}
            </BiButton>
        </div>
    </div>
</template>
