<script setup lang="ts">
import useDateFormat from "@/composables/useDateFormat";
import useQueryFilter from "@/composables/useQueryFilter";
import { DATE_TO_DEFAULT } from "@/constants";
import type { AnomalySearchModel } from "@/models/anomalyLevel";
import t from "@/modules/units/utils/i18n";
import { areaSQMInHA, convertToDate } from "@/utils/utils";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { parseISO } from "date-fns";
import { computed, defineProps, withDefaults } from "vue";
import { useRoute, useRouter } from "vue-router";
import { UnitRouteName } from "../../models/routes";
import type { Parcel, ParcelLandLink } from "../../models/vineUnit";

const { dateFormat } = useDateFormat();
const props = withDefaults(
    defineProps<{
        isConductinDetailButtonVisible?: boolean;
        curParcel: Parcel | null;
        curParcelLandLink: ParcelLandLink | null;
    }>(),
    {
        isConductinDetailButtonVisible: false,
        curParcel: null,
        curParcelLandLink: null,
    },
);

const router = useRouter();
const route = useRoute();

const { filter: dateFilter } = useQueryFilter("date");

const clientReferenceDate = dateFormat(parseISO(dateFilter.value));

const dayFrom = computed(() => {
    if (props.curParcelLandLink?.dayFrom) {
        const dayFrom = convertToDate(props.curParcelLandLink?.dayFrom);
        if (dayFrom) return dateFormat(dayFrom);
    }
    return "";
});

const dayTo = computed(() => {
    if (props.curParcelLandLink?.dayTo) {
        if (props.curParcelLandLink?.dayTo === DATE_TO_DEFAULT) return "";
        const dayTo = convertToDate(props.curParcelLandLink.dayTo);
        if (dayTo) return dateFormat(dayTo);
    }
    return "";
});

const title = computed(() => {
    if (!props.curParcel) return "";
    return `
        ${t(`parcels.parcel_detail`)}
        ${props.curParcel.sector.sector_code} -
        ${props.curParcel.sector.short_descr} -
        ${props.curParcel.block.description} -
        ${props.curParcel.parcel}
    `;
});

const anomalies = computed(() => {
    if (!props.curParcel || !props.curParcel.anomalies?.anomalies_list.length)
        return null;

    const distinctAnomaliesList = new Set<AnomalySearchModel>();
    props.curParcel.anomalies.anomalies_list.map((anomaly) =>
        distinctAnomaliesList.add(anomaly),
    );

    return [...distinctAnomaliesList].map((it) => it.type.code).join(", ");
});

function goToConductingDetail() {
    router.push({
        name: UnitRouteName.VINE_PARCEL_CONDUCTING_DETAIL,
        query: {
            date: route.query.date,
        },
    });
}
</script>
<template>
    <div class="row">
        <div class="col-12">
            <h4>
                {{ title }}
            </h4>
        </div>
        <div class="mt-3 col-12">
            <p>
                {{ t(`parcels.conductions_to_date`) }}:
                <strong>
                    {{ clientReferenceDate }}
                </strong>
            </p>
        </div>
    </div>
    <div class="row">
        <div class="col-3">
            <p>
                {{ t(`parcels.conduction_title`) }}
                <strong>
                    <p>
                        {{ curParcelLandLink?.titleType.code ?? "" }}
                    </p>
                </strong>
            </p>
        </div>
        <div class="col-3">
            <p>
                {{ t(`parcels.conduction_start`) }}
                <strong>
                    <p>
                        {{ dayFrom }}
                    </p>
                </strong>
            </p>
        </div>
        <div class="col-3">
            <p>
                {{ t(`parcels.conduction_end`) }}
                <strong>
                    <p>
                        {{ dayTo }}
                    </p>
                </strong>
            </p>
        </div>
        <div v-if="props.isConductinDetailButtonVisible" class="col-3">
            <BiButton
                class="me-2"
                color="primary"
                isOutlined
                @click="goToConductingDetail"
            >
                {{ t(`parcels.conducting_detail`) }}
            </BiButton>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <p>
                {{ t(`parcels.graphic_area`) }} (ha):
                <strong>
                    {{
                        curParcel?.area_sqm
                            ? areaSQMInHA(curParcel?.area_sqm)
                            : ""
                    }}
                </strong>
            </p>
        </div>
    </div>
    <div v-if="anomalies" class="row">
        <div class="col-12">
            <strong>{{ t(`parcels.anomalies`) }}</strong>
        </div>
        <div class="col-12">{{ anomalies }}</div>
    </div>
</template>
