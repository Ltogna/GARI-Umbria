<script setup lang="ts">
import AlertMessage from "@/components/AlertMessage.vue";
import { DDM_MODULE_ID } from "@/constants";
import { UnitRouteName } from "@/modules/units/models/routes";
import t from "@/modules/units/utils/i18n";
import { useDdmStore } from "@/stores/ddmStore";
import { areaSQMInHA } from "@/utils/utils";
import BiIconButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiIconButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { computed, onMounted, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import { getAuthorizationsSummary } from "../../resources/api/authorizations";
import { useVineUnitStore } from "../../stores/vineUnit";

const router = useRouter();
const route = useRoute();

const vineUnitStore = useVineUnitStore();
const ddmStore = useDdmStore();
const nextKey = ref<string | null>(null);

onMounted(async () => {
    try {
        vineUnitStore.loadingCounter++;
        await fetchAuthorizationSummaryList(nextKey.value, false);
    } catch (error) {
        // TODO - HANDLE ERROR
        console.error(error);
    } finally {
        vineUnitStore.loadingCounter--;
    }
});

const isErrorEmptyShown = computed(() => {
    return (
        !vineUnitStore.authorizationsSummary.length &&
        vineUnitStore.loadingCounter === 0 &&
        ddmStore.loadingCounter === 0
    );
});

async function fetchAuthorizationSummaryList(
    nk: string | null,
    loadMore: boolean,
) {
    vineUnitStore.loadingCounter++;
    const res = await getAuthorizationsSummary(+route.params.partyId, nk);
    if (loadMore) vineUnitStore.authorizationsSummary.push(...res.records);
    else vineUnitStore.authorizationsSummary = res.records;
    nextKey.value = res.nextKey;
    vineUnitStore.loadingCounter--;
}

function goToAuthorizationSummary(authTypeCode: string) {
    router.push({
        name: UnitRouteName.VINE_AUTHORIZATIONS_LIST,
        params: { authTypeCode },
    });
}
</script>
<template>
    <div class="row">
        <div class="col-12">
            <h4>
                {{ t(`authorizations.authorizations`) }}
            </h4>
        </div>
        <div class="col-12">
            <BiTable
                is-row-hover
                is-header-light
                is-custom
                responsive-breakpoint="md"
                :next-key="nextKey"
                :load-more-label="t(`load_more`)"
                @load-more="fetchAuthorizationSummaryList(nextKey, true)"
                class="mt-5"
            >
                <template #head>
                    <tr class="text-primary">
                        <th scope="col">
                            {{ t(`authorizations.authorization_type`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.number`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.authorization_surface`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.planted_surface`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.transferred_surface`) }}
                        </th>
                        <th scope="col">
                            {{ t(`authorizations.residual_surface`) }}
                        </th>
                        <th scope="col"></th>
                    </tr>
                </template>
                <template #body>
                    <tr
                        v-for="authorizationSummary in vineUnitStore.authorizationsSummary"
                        :key="authorizationSummary.authorizationTypeCode"
                        class="align-middle"
                    >
                        <td
                            :data-label="t(`authorizations.authorization_type`)"
                        >
                            <small>{{
                                authorizationSummary.authorizationType
                            }}</small>
                        </td>
                        <td :data-label="t(`authorizations.number`)">
                            <small>{{ authorizationSummary.counter }}</small>
                        </td>
                        <td
                            :data-label="
                                t(`authorizations.authorization_surface`)
                            "
                        >
                            <small>
                                {{
                                    areaSQMInHA(
                                        authorizationSummary.authorizationSurface,
                                    )
                                }}
                            </small>
                        </td>
                        <td :data-label="t(`authorizations.planted_surface`)">
                            <small>
                                {{
                                    areaSQMInHA(
                                        authorizationSummary.plantedSurface,
                                    )
                                }}
                            </small>
                        </td>
                        <td
                            :data-label="
                                t(`authorizations.transferred_surface`)
                            "
                        >
                            <small>
                                {{
                                    areaSQMInHA(
                                        authorizationSummary.transferredSurface,
                                    )
                                }}
                            </small>
                        </td>
                        <td :data-label="t(`authorizations.residual_surface`)">
                            <small>
                                {{
                                    areaSQMInHA(
                                        authorizationSummary.residualSurface,
                                    )
                                }}
                            </small>
                        </td>
                        <td class="text-end">
                            <BiIconButton
                                class="mx-1"
                                icon="arrow-right"
                                iconStyle="fas"
                                color="primary"
                                isOutlined
                                @click="
                                    goToAuthorizationSummary(
                                        authorizationSummary.authorizationTypeCode,
                                    )
                                "
                            />
                        </td>
                    </tr>
                </template>
            </BiTable>

            <AlertMessage
                :modelValue="isErrorEmptyShown"
                :dismissable="false"
                :level="'info'"
            >
                {{ t(`${DDM_MODULE_ID}.message.empty_list`) }}
            </AlertMessage>
        </div>
    </div>
</template>
