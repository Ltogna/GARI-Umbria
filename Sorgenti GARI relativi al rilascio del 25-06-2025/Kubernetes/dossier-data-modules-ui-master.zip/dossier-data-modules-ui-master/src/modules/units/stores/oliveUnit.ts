import type {
    AuthorizationSummaryList,
    AuthorizationsList,
    QuotaSummaryList,
    OliveUnitListModel,
} from "@/modules/units/models/oliveUnit";
import {
    getUnitsList,
    getUnitsSummaryBySector,
    getUnitsSummaryByVariety,
    getQuotasSummary,
} from "@/modules/units/resources/api/oliveUnit";
import { defineStore } from "pinia";
import type {
    SectorSummaryList,
    VarietySummaryList,
} from "../models/oliveUnit";
import {
    getAuthorizationsSummary,
    getAuthorizationsList,
} from "../resources/api/authorizations";

export interface State {
    partyId: number | null;
    cuaa: string | null;
    loadingCounter: number;
    curDate: Date;
    sectorSummary: SectorSummaryList;
    varietySummary: VarietySummaryList;
    authorizationsSummary: AuthorizationSummaryList;
    authorizationsList: AuthorizationsList;
    quotasSummary: QuotaSummaryList;
    oliveUnitList: OliveUnitListModel;
    showParcelFilter: boolean;
}

const initialState: Readonly<State> = {
    partyId: null,
    cuaa: null,
    curDate: new Date(),
    loadingCounter: 0,
    varietySummary: [],
    sectorSummary: [],
    authorizationsSummary: [],
    authorizationsList: [],
    quotasSummary: [],
    oliveUnitList: [],
    showParcelFilter: false,
};

const state: State = structuredClone(initialState);

export const useOliveUnitStore = defineStore("OliveUnit", {
    state: (): State => state,
    getters: {
        totalParcels(state) {
            const numParcelSum = state.sectorSummary.reduce(
                (total, sectorSummary) => {
                    return total + sectorSummary.num_parcel;
                },
                0,
            );
            return numParcelSum;
        },
        totalOliveUnitsAreaSqm(state) {
            const numParcelSum = state.sectorSummary.reduce(
                (total, sectorSummary) => {
                    return total + sectorSummary.total_unit_area_sqm;
                },
                0,
            );
            return numParcelSum;
        },
        totalOliveUnits(state) {
            const oliveUnitSum = state.sectorSummary.reduce(
                (total, varietySummary) => {
                    return total + varietySummary.num_units;
                },
                0,
            );
            return oliveUnitSum;
        },
    },
    actions: {
        async fetchOliveUnitBySector(partyId: number, referenceDate: string) {
            this.loadingCounter++;
            this.sectorSummary = await getUnitsSummaryBySector(
                partyId,
                referenceDate,
            );
            this.loadingCounter--;
        },
        async fetchOliveUnitByVariety(partyId: number, referenceDate: string) {
            this.loadingCounter++;
            this.varietySummary = await getUnitsSummaryByVariety(
                partyId,
                referenceDate,
            );
            this.loadingCounter--;
        },
        async fetchOliveUnitList(
            referenceDate: string,
            parcelId: number | null,
            landCoversId: number | null,
        ) {
            this.loadingCounter++;
            this.oliveUnitList = await getUnitsList(
                referenceDate,
                parcelId,
                landCoversId,
            );
            this.loadingCounter--;
        },
        async fetchAuthorizationSummaryList(
            partyId: number,
            nextKey: string | null,
        ) {
            this.loadingCounter++;
            this.authorizationsSummary = (
                await getAuthorizationsSummary(partyId, nextKey)
            ).records;
            this.loadingCounter--;
        },
        async fetchAuthorizationsList(
            partyId: number,
            authTypeCode: string,
            includeExpired = false,
            nextKey: string | null,
        ) {
            this.loadingCounter++;
            this.authorizationsList = (
                await getAuthorizationsList(
                    partyId,
                    authTypeCode,
                    includeExpired,
                    nextKey,
                )
            ).records;
            this.loadingCounter--;
        },
        async fetchQuotasSummaryList(partyId: number, nextKey: string | null) {
            this.loadingCounter++;
            this.quotasSummary = (
                await getQuotasSummary(partyId, nextKey)
            ).records;
            this.loadingCounter--;
        },
        $reset() {
            this.$state = structuredClone(initialState);
        },
    },
});
