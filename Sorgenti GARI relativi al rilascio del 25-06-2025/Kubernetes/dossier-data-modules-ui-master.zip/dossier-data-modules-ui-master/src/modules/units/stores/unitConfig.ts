import { getConfigurationByKey } from "@/resources/api/config";
import { defineStore } from "pinia";
import { UNIT_CONFIG_KEY } from "../constants";
import {
    UnitConfigurationSchema,
    templateOptions,
    type UnitConfiguration,
} from "../models/config";
import { template, type TemplateExecutor } from "lodash";

interface State {
    configFetched: boolean;
    _configurationKey: string | null;
    _config: UnitConfiguration;
}

const initialState: Readonly<State> = {
    configFetched: false,
    _configurationKey: null,
    _config: {
        AUTH_ENABLED: false,
    },
};
const state: State = structuredClone(initialState);

export const useUnitConfigStore = defineStore("unitConfig", {
    state: () => state,
    getters: {
        authorizationsEnabled(state) {
            return !!state._config.AUTH_ENABLED;
        },
        doIgtQuotasEnabled(state) {
            return !!state._config.DO_IGT_QUOTAS_ENABLED;
        },
        applicationsEnabled(state) {
            return !!state._config.APPLICATIONS_ENABLED;
        },
        aptitudesEnabled(state) {
            return !!state._config.APTITUDES_ENABLED;
        },
        partyRegistryDirectoryUrl: (state): TemplateExecutor => {
            return template(
                state._config.PARTY_REGISTRY_DIRECTORY_URL ??
                    `/party-registry/{tenant}/public/v1/parties/{party_id}`,
                templateOptions,
            );
        },
        mode(state) {
            return state._config.MODE ?? "vine";
        },
        configurationKey(state) {
            return state._configurationKey;
        },
    },

    actions: {
        async fetchConfig(forceFetch?: boolean) {
            if (this.configFetched && !forceFetch) return;
            const response = await getConfigurationByKey(UNIT_CONFIG_KEY);
            if (response) {
                this._configurationKey = response.configurationKey;
                try {
                    const _conf = new Map<string, unknown>();
                    for (const [key, value] of Object.entries(
                        response.configuration,
                    )) {
                        _conf.set(key.toLocaleUpperCase(), value);
                    }
                    this._config = UnitConfigurationSchema.parse(
                        Object.fromEntries(_conf),
                    );
                    this.configFetched = true;
                } catch (error) {
                    console.error("Dev - parsing error:" + error);
                    return;
                }
            }
        },

        $reset() {
            this.$state = structuredClone(initialState);
        },
    },
});
