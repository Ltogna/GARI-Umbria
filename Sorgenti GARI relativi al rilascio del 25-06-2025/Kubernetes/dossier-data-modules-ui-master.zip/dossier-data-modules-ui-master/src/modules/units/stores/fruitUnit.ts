import type {
    AuthorizationSummaryList,
    AuthorizationsList,
    QuotaSummaryList,
    FruitUnitListModel,
} from "@/modules/units/models/fruitUnit";
import {
    getUnitsList,
    getUnitsSummaryBySector,
    getUnitsSummaryByVariety,
    getQuotasSummary,
} from "@/modules/units/resources/api/fruitUnit";
import { defineStore } from "pinia";
import type {
    SectorSummaryList,
    VarietySummaryList,
} from "../models/fruitUnit";
import {
    getAuthorizationsSummary,
    getAuthorizationsList,
} from "../resources/api/authorizations";

export interface State {
    partyId: number | null;
    loadingCounter: number;
    curDate: Date;
    sectorSummary: SectorSummaryList;
    varietySummary: VarietySummaryList;
    authorizationsSummary: AuthorizationSummaryList;
    authorizationsList: AuthorizationsList;
    quotasSummary: QuotaSummaryList;
    fruitUnitList: FruitUnitListModel;
    showParcelFilter: boolean;
}

const initialState: Readonly<State> = {
    partyId: null,
    curDate: new Date(),
    loadingCounter: 0,
    varietySummary: [],
    sectorSummary: [],
    authorizationsSummary: [],
    authorizationsList: [],
    quotasSummary: [],
    fruitUnitList: [],
    showParcelFilter: false,
};

const state: State = structuredClone(initialState);

export const useFruitUnitStore = defineStore("FruitUnit", {
    state: (): State => state,
    getters: {
        totalParcels(state) {
            const numParcelSum = state.sectorSummary.reduce(
                (total, sectorSummary) => {
                    return total + sectorSummary.num_parcel;
                },
                0,
            );
            return numParcelSum;
        },
        totalFruitUnitsAreaSqm(state) {
            const numParcelSum = state.sectorSummary.reduce(
                (total, sectorSummary) => {
                    return total + sectorSummary.total_unit_area_sqm;
                },
                0,
            );
            return numParcelSum;
        },
        totalFruitUnits(state) {
            const fruitUnitSum = state.sectorSummary.reduce(
                (total, varietySummary) => {
                    return total + varietySummary.num_units;
                },
                0,
            );
            return fruitUnitSum;
        },
    },
    actions: {
        async fetchFruitUnitBySector(partyId: number, referenceDate: string) {
            this.loadingCounter++;
            this.sectorSummary = await getUnitsSummaryBySector(
                partyId,
                referenceDate,
            );
            this.loadingCounter--;
        },
        async fetchFruitUnitByVariety(partyId: number, referenceDate: string) {
            this.loadingCounter++;
            this.varietySummary = await getUnitsSummaryByVariety(
                partyId,
                referenceDate,
            );
            this.loadingCounter--;
        },
        async fetchFruitUnitList(
            referenceDate: string,
            parcelId: number | null,
            landCoversId: number | null,
        ) {
            this.loadingCounter++;
            this.fruitUnitList = await getUnitsList(
                referenceDate,
                parcelId,
                landCoversId,
            );
            this.loadingCounter--;
        },
        async fetchAuthorizationSummaryList(
            partyId: number,
            nextKey: string | null,
        ) {
            this.loadingCounter++;
            this.authorizationsSummary = (
                await getAuthorizationsSummary(partyId, nextKey)
            ).records;
            this.loadingCounter--;
        },
        async fetchAuthorizationsList(
            partyId: number,
            authTypeCode: string,
            includeExpired = false,
            nextKey: string | null,
        ) {
            this.loadingCounter++;
            this.authorizationsList = (
                await getAuthorizationsList(
                    partyId,
                    authTypeCode,
                    includeExpired,
                    nextKey,
                )
            ).records;
            this.loadingCounter--;
        },
        async fetchQuotasSummaryList(partyId: number, nextKey: string | null) {
            this.loadingCounter++;
            this.quotasSummary = (
                await getQuotasSummary(partyId, nextKey)
            ).records;
            this.loadingCounter--;
        },
        $reset() {
            this.$state = structuredClone(initialState);
        },
    },
});
