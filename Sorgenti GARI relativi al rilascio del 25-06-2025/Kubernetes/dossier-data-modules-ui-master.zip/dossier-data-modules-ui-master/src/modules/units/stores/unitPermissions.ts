import { userHasPermission } from "@abaco/safe-rest/src/sso2";
import { defineStore } from "pinia";

export interface State {
    vineGis: {
        viewer: boolean;
        editor: boolean;
    };
    oliveGis: {
        viewer: boolean;
        editor: boolean;
    };
    fruitGis: {
        viewer: boolean;
        editor: boolean;
    };
    vineAuth: {
        viewer: boolean;
        editor: boolean;
    };
}

const initialState: Readonly<State> = {
    vineGis: {
        viewer: false,
        editor: false,
    },
    oliveGis: {
        viewer: false,
        editor: false,
    },
    fruitGis: {
        viewer: false,
        editor: false,
    },
    vineAuth: {
        viewer: false,
        editor: false,
    },
};
const state: State = structuredClone(initialState);

export const usePermissionsStore = defineStore("unitPermissions", {
    state: () => state,
    getters: {
        // Getter for VINE-GIS-SERVER
        vineGisViewer: (state) => state.vineGis.viewer,
        vineGisEditor: (state) => state.vineGis.editor,

        // Getter for OLIVE-GIS-SERVER
        oliveGisViewer: (state) => state.oliveGis.viewer,
        oliveGisEditor: (state) => state.oliveGis.editor,

        // Getter for FRUIT-GIS-SERVER
        fruitGisViewer: (state) => state.fruitGis.viewer,
        fruitGisEditor: (state) => state.fruitGis.editor,

        // Getter for VINE-AUTH-SERVER
        vineAuthViewer: (state) => state.vineAuth.viewer,
        vineAuthEditor: (state) => state.vineAuth.editor,
    },
    actions: {
        /**
         * Method to `fetch` all permissions.
         * It will be called in the `beforeEnter` on routes management.
         */
        fetchPermissions() {
            this.vineGis.viewer = userHasPermission(
                "VINE-GIS-SERVER",
                "VIEWER",
            );
            this.vineGis.editor = userHasPermission(
                "VINE-GIS-SERVER",
                "EDITOR",
            );

            this.oliveGis.viewer = userHasPermission(
                "OLIVE-GIS-SERVER",
                "VIEWER",
            );
            this.oliveGis.editor = userHasPermission(
                "OLIVE-GIS-SERVER",
                "EDITOR",
            );

            this.fruitGis.viewer = userHasPermission(
                "FRUIT-GIS-SERVER",
                "VIEWER",
            );
            this.fruitGis.editor = userHasPermission(
                "FRUIT-GIS-SERVER",
                "EDITOR",
            );

            this.vineAuth.viewer = userHasPermission("AV_AUTH", "VIEWER");
            this.vineAuth.editor = userHasPermission("AV_AUTH", "EDITOR");
        },
        $reset() {
            this.$state = structuredClone(initialState);
        },
    },
});
