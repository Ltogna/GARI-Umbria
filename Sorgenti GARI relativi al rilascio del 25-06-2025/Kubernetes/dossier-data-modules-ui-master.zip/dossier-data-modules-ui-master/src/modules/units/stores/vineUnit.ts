import type {
    AptitudeSummaryList,
    AuthorizationSummaryList,
    AuthorizationsList,
    QuotaSummaryList,
    VineUnitListModel,
    AptitudeUvList,
    SelectValue,
} from "@/modules/units/models/vineUnit";
import {
    getUnitsList,
    getUnitsSummaryBySector,
    getUnitsSummaryByVariety,
    getQuotasSummary,
} from "@/modules/units/resources/api/vineUnit";
import { defineStore } from "pinia";
import type { SectorSummaryList, VarietySummaryList } from "../models/vineUnit";
import { formatDate } from "@/utils/utils";
import {
    getAptitudesSummary,
    getAptitudesUvListByCode,
} from "../resources/api/aptitudes";
import {
    getAuthorizationsSummary,
    getAuthorizationsList,
} from "../resources/api/authorizations";

export interface State {
    partyId: number | null;
    cuaa: string | null;
    loadingCounter: number;
    curDate: Date;
    sectorSummary: SectorSummaryList;
    varietySummary: VarietySummaryList;
    authorizationsSummary: AuthorizationSummaryList;
    authorizationsList: AuthorizationsList;
    aptitudesSummary: AptitudeSummaryList;
    aptitudesUvList: AptitudeUvList;
    quotasSummary: QuotaSummaryList;
    vineUnitList: VineUnitListModel;
    showParcelFilter: boolean;
    reasonList: SelectValue[];
}

const initialState: Readonly<State> = {
    partyId: null,
    cuaa: null,
    curDate: new Date(),
    loadingCounter: 0,
    varietySummary: [],
    sectorSummary: [],
    authorizationsSummary: [],
    authorizationsList: [],
    aptitudesSummary: [],
    aptitudesUvList: [],
    quotasSummary: [],
    vineUnitList: [],
    showParcelFilter: false,
    reasonList: [],
};

const state: State = structuredClone(initialState);

export const useVineUnitStore = defineStore("VineUnit", {
    state: (): State => state,
    getters: {
        totalParcels(state) {
            const numParcelSum = state.sectorSummary.reduce(
                (total, sectorSummary) => {
                    return total + sectorSummary.num_parcel;
                },
                0,
            );
            return numParcelSum;
        },
        totalVineUnitsAreaSqm(state) {
            const numParcelSum = state.sectorSummary.reduce(
                (total, sectorSummary) => {
                    return total + sectorSummary.total_unit_area_sqm;
                },
                0,
            );
            return numParcelSum;
        },
        totalVineUnits(state) {
            const vineUnitSum = state.sectorSummary.reduce(
                (total, varietySummary) => {
                    return total + varietySummary.num_units;
                },
                0,
            );
            return vineUnitSum;
        },
    },
    actions: {
        async fetchVineUnitBySector(partyId: number, referenceDate: string) {
            this.loadingCounter++;
            this.sectorSummary = await getUnitsSummaryBySector(
                partyId,
                referenceDate,
            );
            this.loadingCounter--;
        },
        async fetchVineUnitByVariety(partyId: number, referenceDate: string) {
            this.loadingCounter++;
            this.varietySummary = await getUnitsSummaryByVariety(
                partyId,
                referenceDate,
            );
            this.loadingCounter--;
        },
        async fetchVineUnitList(
            referenceDate: string,
            parcelId: number | null,
            landCoversId: number | null,
        ) {
            this.loadingCounter++;
            this.vineUnitList = await getUnitsList(
                referenceDate,
                parcelId,
                landCoversId,
            );
            this.loadingCounter--;
        },
        async fetchAuthorizationSummaryList(
            partyId: number,
            nextKey: string | null,
        ) {
            this.loadingCounter++;
            this.authorizationsSummary = (
                await getAuthorizationsSummary(partyId, nextKey)
            ).records;
            this.loadingCounter--;
        },
        async fetchAuthorizationsList(
            partyId: number,
            authTypeCode: string,
            includeExpired = false,
            nextKey: string | null,
        ) {
            this.loadingCounter++;
            this.authorizationsList = (
                await getAuthorizationsList(
                    partyId,
                    authTypeCode,
                    includeExpired,
                    nextKey,
                )
            ).records;
            this.loadingCounter--;
        },
        async fetchAptitudeSummaryList(partyId: number) {
            this.loadingCounter++;
            this.aptitudesSummary = await getAptitudesSummary(
                partyId,
                formatDate(this.curDate),
            );
            this.loadingCounter--;
        },
        async fetchAptitudesUvList(
            partyId: number,
            code: string,
            nextKey: string | null,
        ) {
            this.loadingCounter++;
            this.aptitudesUvList = (
                await getAptitudesUvListByCode(
                    partyId,
                    formatDate(this.curDate),
                    code,
                    nextKey,
                )
            ).records;
            this.loadingCounter--;
        },
        async fetchQuotasSummaryList(partyId: number, nextKey: string | null) {
            this.loadingCounter++;
            this.quotasSummary = (
                await getQuotasSummary(partyId, nextKey)
            ).records;
            this.loadingCounter--;
        },
        $reset() {
            this.$state = structuredClone(initialState);
        },
    },
});
