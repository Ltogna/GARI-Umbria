import {
    ErrorType,
    type HttpResponseError,
} from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";
import type {
    AmendmentModulesResponse,
    ApplicationAnomalyResponseModel,
    ApplicationDetailsModel,
    ApplicationFilter,
    ApplicationHistoryModel,
    ApplicationIsInTransitionModel,
    ApplicationModulesResponse,
    ApplicationSummaryDetailResponse,
    ApplicationSummaryListModel,
    ApplicationTransitionsModel,
    CreateAmendmentResponseModel,
    CreateApplicationResponseModel,
    PartyListModel,
    PartyModel,
    PartyRegistryListModel,
    PrintHistoryResponseModel,
    TenantConfigModel,
} from "../models/application";
import {
    getParties,
    loadTenantConfigsAPI,
} from "../resources/api/applicationApi";
import {
    mapSubjectsData,
    handleApiErrorAndShowAlert,
    handleErrorCode,
} from "../utils/utils";
import type { UserFunctionArrayModel } from "../resources/api/login";

export enum RegistryEnvironment {
    LEGACY = "legacy",
    PARTYREGISTRY = "party-registry",
    PARTY_REGISTRY_DIRECTORY_URL = "party_registry_directory_url",
    PARTY_REGISTRY_DIRECTORY_SEARCH_URL = "party_registry_directory_search_url",
    PARTY_REGISTRY_ENABLE_SEARCH_FOR_CODE = "party_registry_enable_search_for_code",
    DISABLE_NEW_APPLICATION_BUTTON_CONTEXT_FUNCTION = "disable_new_application_button_context_function",
}
interface ApplicationInformation {
    transitionData: ApplicationIsInTransitionModel | null;
    transitionStatus?: string;
    applicationTransitions: ApplicationTransitionsModel | null;
    applicationHistory: ApplicationHistoryModel | null;
    applicationDetails: ApplicationDetailsModel | null;
    applicationModules: ApplicationModulesResponse | null;
    amendmentModules: AmendmentModulesResponse | null;
    printHistory: PrintHistoryResponseModel | null;
    ongoingPrints: PrintHistoryResponseModel | null;
    loadingOngoingPrints: boolean;
 
    loadingOngoingCalculations: boolean;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    calculationDetails: any;
}

interface State {
    applicationSummaryList: ApplicationSummaryListModel | null;
    applicationSummaryDetailList: ApplicationSummaryDetailResponse | null;
    applicationListStatusFilter: ApplicationFilter;
    subjectList: PartyListModel | null;
    createApplicationResponse: CreateApplicationResponseModel | null;
    createAmendmentResponse: CreateAmendmentResponseModel | null;
    loading: boolean;
    hasError: boolean;
    errorResponse?: HttpResponseError;
    selectedSubject: PartyModel | null;
    application: { [key: string]: ApplicationInformation };
    routeApplicationId: string;
    applicationAnomalies: { [key: string]: ApplicationAnomalyResponseModel };
    registryEnvironment: string;
    tenantConfigs: Record<string, string | number | boolean>;
    userFunctions: UserFunctionArrayModel | null;
    isFunctionReadOnly: boolean;
}

// Spostare le constanti nel file constants.ts
export const NOT_ALLOWED_MULTIPLE_APPLICATIONS_ERROR =
    "NOT_ALLOWED_MULTIPLE_APPLICATIONS_ERROR";
export const APPLICATION_CREATION_ERROR = "APPLICATION_CREATION_ERROR";
export const ALREADY_AMENDED_APPLICATION_ERROR_CODE =
    "ALREADY_AMENDED_APPLICATION_ERROR_CODE";
export const WAIVED_APPLICATION_ERROR_CODE = "WAIVED_APPLICATION_ERROR_CODE";

export const useApplicationStore = defineStore({
    id: "applicationStore",
    state: () =>
        ({
            applicationSummaryList: null,
            applicationSummaryDetailList: null,
            applicationListStatusFilter: {
                referenceSubject: "",
                applicationNumber: "",
            },
            selectedSubject: null,
            subjectList: null,
            createApplicationResponse: null,
            createAmendmentResponse: null,
            loading: false,
            hasError: false,
            errorResponse: undefined,
            application: {},
            routeApplicationId: "",
            applicationAnomalies: {},
            tenantConfigs: {},
            userFunctions: null,
            isFunctionReadOnly: false,
        }) as State,
    getters: {
 
        getApplicationListStatusFilter: (state: State) => {
            return state.applicationListStatusFilter;
        },
 
        getSelectedSubject: (state: State) => {
            return state.selectedSubject;
        },
        getSubjectList: (state: State) => {
            return state.subjectList?.records;
        },
 
 
        getErrorResponse: (state: State) => {
            return state.errorResponse;
        },
 
        getIsLoading: (state: State) => {
            return state.loading;
        },
        getTenantConfigPartyRegistryError: (state: State) => {
            return !!state.tenantConfigs["PARTY_REGISTRY_LOADING_ERROR"];
        },
        gettenantconfigPartyRegistryEnableSearchForCode: (state: State) => {
            const data: "true" | "false" =
                (state.tenantConfigs[
                    RegistryEnvironment.PARTY_REGISTRY_ENABLE_SEARCH_FOR_CODE
                ] as "false") ?? "true";

            return data.toString() === "false" ? false : true;
        },
  
    },
    actions: {
        async searchSubjects(cuaa?: string | null, partyDesc?: string | null) {
            this.loading = true;
            this.hasError = false;
            const useCuaa = cuaa?.trimEnd();
            const usePartyDesc = partyDesc?.trimEnd();
            const actualNextKey = this.subjectList?.nextKey;

            const url = "/avepa-legacy/{tenant}/public/v1/parties/directory";
            const response = await getParties(
                url,
                useCuaa,
                usePartyDesc,
                actualNextKey,
            );

            if (response.errorType !== ErrorType.NONE) {
                this.hasError = true;
                this.errorResponse = response as HttpResponseError;
            } else {
                if (this.subjectList) {
                    this.subjectList.records.push(
                        ...mapSubjectsData(
                            response.data.records,
                            this.registryEnvironment,
                        ),
                    );
                    this.subjectList.nextKey = response.data.nextKey;
                } else {
                    const notMappedData:
                        | PartyListModel
                        | PartyRegistryListModel = response.data;
                    notMappedData.records = mapSubjectsData(
                        notMappedData.records,
                        this.registryEnvironment,
                    );
                    const mappedData: PartyListModel =
                        notMappedData as PartyListModel;
                    this.subjectList = mappedData;
                }
            }
            this.loading = false;
        },
      
        async loadParty() { // Da rivedere
            this.loading = true;
            if (
                !this.tenantConfigs[
                    RegistryEnvironment.PARTY_REGISTRY_DIRECTORY_URL
                ]
            ) {
                await this.loadTenantConfigs();
            }
            this.loading = false;
        },
        
        async loadTenantConfigs() {// Non si può gestire con le config dei bundles?
            this.loading = true;
            this.hasError = false;
            const response = await loadTenantConfigsAPI();
            if (response.errorType !== ErrorType.NONE) {
                this.hasError = true;
                this.errorResponse = response as HttpResponseError;
                handleApiErrorAndShowAlert(response);
            } else {
                response.data.forEach((config: TenantConfigModel) => {
                    this.tenantConfigs[config.key] = config.value;
                });
                if (
                    !this.tenantConfigs[
                        RegistryEnvironment.PARTY_REGISTRY_DIRECTORY_SEARCH_URL
                    ]
                ) {
                    handleErrorCode("CONFIG_NOT_FOUND_ERROR");
                    this.tenantConfigs["PARTY_REGISTRY_LOADING_ERROR"] = true;
                } else {
                    if (
                        (
                            this.tenantConfigs[
                                RegistryEnvironment
                                    .PARTY_REGISTRY_DIRECTORY_SEARCH_URL
                            ] as string
                        ).includes(RegistryEnvironment.PARTYREGISTRY)
                    ) {
                        this.setRegistryEnvironment(
                            RegistryEnvironment.PARTYREGISTRY,
                        );
                    } else
                        this.setRegistryEnvironment(RegistryEnvironment.LEGACY);
                }
            }
            this.loading = false;
        },
        setSelectedSubject(subject: PartyModel | null) {
            this.selectedSubject = subject;
        },
        setApplicationListFilter(statusFilter: ApplicationFilter) {
            this.applicationListStatusFilter = statusFilter;
        },
   
        setRegistryEnvironment(key: string) {
            this.registryEnvironment = key;
        },
    
        clearSubjectList() {
            this.subjectList = null;
        },
        clearApplicationStatusFilters() {
            this.applicationListStatusFilter = {
                referenceSubject: "",
                applicationNumber: "",
            };
        },
 
  
    },
});
