export const applicationsBaseUrl = (tenant: string) =>
  `/applications/${tenant}/api-priv/v1/applications`;
