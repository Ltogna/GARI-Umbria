import { i18n } from "../../../i18n/index";
import { UNIT_ID } from "../constants";
import { useUnitConfigStore } from "../stores/unitConfig";

type Args = Parameters<typeof i18n.global.t>;

export default function customI18n(...args: Partial<Args>) {
    const mode = useUnitConfigStore().mode;
    const t = i18n.global.t;
    const te = i18n.global.te;

    const [key, params = {}, locale = "en"] = args;

    if (te(`${mode}.${key}`)) {
        return t(`${mode}.${key}`, { ...params, locale });
    }
    if (te(`${UNIT_ID}.${key}`)) {
        return t(`${UNIT_ID}.${key}`, { ...params, locale });
    }
    return t(`${key}`, { ...params, locale });
}
