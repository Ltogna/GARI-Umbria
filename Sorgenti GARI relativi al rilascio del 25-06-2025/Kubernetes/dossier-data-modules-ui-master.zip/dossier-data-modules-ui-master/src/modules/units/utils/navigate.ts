import { AV_AUTH_MODULE_ID } from "@/constants";

export function goToParcelSummary(path: string) {
    const parentModuleDeployDir = "dossier",
        basePath =
            window.location.href.indexOf(`/${parentModuleDeployDir}`) > -1
                ? window.location.href.split(`/${parentModuleDeployDir}`)[0]
                : window.location.origin,
        summaryUrl = `${basePath}/${AV_AUTH_MODULE_ID}${path}`;

    window.location.assign(summaryUrl);
}
