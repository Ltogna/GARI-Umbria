import type { ValidatedInput } from "../models/form";

export function verifyField(
    validatingFunctions: (() => boolean)[],
    field: ValidatedInput<string | null>,
    flush = true,
): boolean {
    if (flush) {
        field.errors = [];
    }
    for (const valFunc of validatingFunctions) {
        const res = valFunc();
        if (res) {
            return res;
        }
    }
    return false;
}

export function checkMaxLength(
    field: ValidatedInput<string | null>,
    maxLength: number,
    errorMessage: string,
) {
    if (field.val && field.val.length > maxLength) {
        field.errors.push(errorMessage);
        return true;
    }
    return false;
}
