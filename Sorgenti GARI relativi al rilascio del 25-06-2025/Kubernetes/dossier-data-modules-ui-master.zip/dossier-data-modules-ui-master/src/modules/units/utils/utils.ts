/* eslint-disable @typescript-eslint/no-explicit-any */
import { useAlertsStore } from "@abaco/bootstrap-italia-components/src/stores/alertsStore";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { type ErrorModel } from "@abaco/bootstrap-italia-components/src/models/index";
import { z } from "zod";
import i18n from "@/i18n/index.js";
import type { PartyRegistryModel } from "../models/application";

const moduleId = "application";

const t = i18n.global.t;

export const ResponseSchema = z.object({
    status: z.number(),
});

export type ResponseModel = z.infer<typeof ResponseSchema>;

export function removeNullsOrBlanksFromObject(obj: any) {
    if (obj) {
        Object.keys(obj).forEach((k) => {
            if (obj && (obj[k] === "" || obj[k] == null)) {
                delete obj[k];
            }
        });
    }
}

export function handleErrorCode(errorCode: string) {
    const alertsStore = useAlertsStore();
    alertsStore.setError({
        errorCode: t(`${moduleId}.errors.${errorCode}`),
    });
}

export function handleApiErrorAndShowAlert(response: any, exposeAlert = true) {
    // Duplicato, c'è già nel messageStore
    const alertsStore = useAlertsStore();
    if (response.errorType === ErrorType.HTTP_STATUS) {
        if (
            response.response.status === 403 &&
            response.response.statusText === "Forbidden"
        ) {
            console.error(response.response.statusText);
            if (exposeAlert) {
                alertsStore.setError({
                    errorCode: t(`${moduleId}.errors.NOT_AUTHORIZED`),
                });
            }
        } else {
            response.response
                .json()
                .then((errMsg: ErrorModel) => {
                    const e: ErrorModel = {
                        errorCode: "GENERIC_ERROR",
                    };
                    if (errMsg.errorCode) {
                        e.errorCode = t(
                            `${moduleId}.errors.${errMsg.errorCode}`,
                        );
                        e.message = errMsg.message;
                    }
                    console.error(e);
                    e.message = undefined;
                    if (exposeAlert) {
                        alertsStore.setError(e);
                    }
                })
                .catch((err: any) => {
                    alertsStore.setGenericError();
                    console.error("generic error", err);
                });
        }
    } else {
        alertsStore.setGenericError();
    }
}

export function cleanBasePath(basePath: string) {
    let useBasePath = "";
    if (basePath) {
        useBasePath = basePath.endsWith("/")
            ? basePath.substring(0, basePath.length - 1)
            : basePath;
    }
    return useBasePath;
}

export function mapSubjectsData(data: any, registryEnvironment: string) {
    if (registryEnvironment === "party-registry")
        return data.map((el: PartyRegistryModel) =>
            mapSingleElementData(el, registryEnvironment),
        );
    else return data;
}

export function mapSingleElementData(
    element: any,
    registryEnvironment: string,
) {
    if (registryEnvironment === "party-registry")
        return {
            partyId: element.id,
            code: element.code,
            description:
                element.lastName +
                (element.firstName ? " " + element.firstName : ""),
        };
    else return element;
}
