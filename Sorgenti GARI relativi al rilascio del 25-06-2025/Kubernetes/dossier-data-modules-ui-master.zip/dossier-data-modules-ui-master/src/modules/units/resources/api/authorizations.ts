import t from "@/modules/units/utils/i18n";
import {
    PaginatedAuthorizationListSchema,
    PaginatedAuthorizationSummaryListSchema,
    type PaginatedAuthorizationListModel,
    type PaginatedAuthorizationSummaryListModel,
} from "@/modules/units/models/vineUnit";
import { useMessageStore } from "@/stores/messageStore";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { ZodError } from "zod";
import { vineAuthServerHTTPClient } from "../../../../resources/api/http";
import { AbsoluteDate } from "@/utils/AbsoluteDate";
import {
    AuthorizationVineSchema,
    AuthTypesResponseSchema,
    provincesResponseSchema,
    regionsResponseSchema,
    TransferAuthorizationToCuaaSchema,
    transferCauseResponseSchema,
    updateExpirationDateCausesSchema,
    type Authorization,
    type AuthorizationData,
    type AuthorizationExpirationDateType,
    type AuthorizationToRegionType,
    type AuthorizationTransferToCuaa,
    type SelectControl,
    type TransferAuthorizationToCuaa,
} from "../../models/authorization";
import { ErrorCode } from "../../models/errors";

export const getAuthorizationsSummary = async (
    partyId: number,
    nextKey: string | null,
): Promise<PaginatedAuthorizationSummaryListModel> => {
    const response = await vineAuthServerHTTPClient.getJson(
        PaginatedAuthorizationSummaryListSchema,
        `/api-priv/v1/vine-auth/parties/${partyId}`,
        { params: { ...(nextKey !== null && { nextKey }) } },
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        ) {
            console.error(response.err);
        } else {
            useMessageStore().handleApiErrorAndShowAlert(response);
        }
        return {
            count: 0,
            records: [],
            nextKey: null,
        };
    }
    return response.data;
};

export const getAuthorizationsList = async (
    partyId: number,
    authTypeCode: string,
    includeExpired: boolean,
    nextKey: string | null,
): Promise<PaginatedAuthorizationListModel> => {
    const response = await vineAuthServerHTTPClient.getJson(
        PaginatedAuthorizationListSchema,
        `/api-priv/v1/vine-auth/parties/${partyId}/authorization-types/${authTypeCode}`,
        { params: { includeExpired, ...(nextKey !== null && { nextKey }) } },
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        ) {
            console.error(response.err);
        } else {
            useMessageStore().handleApiErrorAndShowAlert(response);
        }

        return {
            count: 0,
            records: [],
            nextKey: null,
        };
    }
    return response.data;
};

export const getAuthorizationDetailById = async (
    partyId: number,
    authorizationId: number,
): Promise<Authorization | null> => {
    const response = await vineAuthServerHTTPClient.getJson(
        AuthorizationVineSchema,
        `/api-priv/v1/vine-auth/parties/${partyId}/authorizations/${authorizationId}`,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        ) {
            console.error(response.err);
        } else {
            useMessageStore().handleApiErrorAndShowAlert(response);
        }
        return null;
    }
    return response.data;
};

export const getAuthTypes = async (): Promise<SelectControl[] | null> => {
    const response = await vineAuthServerHTTPClient.getJson(
        AuthTypesResponseSchema,
        `/api-priv/v1/vine-auth/authorization-types`,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }

    const mappedAuthType = response.data.authorizationTypes.map((authType) => ({
        text: authType.description,
        id: authType.code,
    }));
    return mappedAuthType;
};

export const getItalianRegions = async (): Promise<
    SelectControl[] | undefined
> => {
    const response = await vineAuthServerHTTPClient.getJson(
        regionsResponseSchema,
        `/api-priv/v1/vine-auth/regions`,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return undefined;
    }

    const mappedRegions = response.data.regions.map((region) => ({
        text: region.description,
        id: region.code,
    }));

    const sortedRegionList = mappedRegions.sort((a, b) =>
        a.text.localeCompare(b.text, "it", { sensitivity: "base" }),
    );
    return sortedRegionList;
};

export const getProvinces = async (
    regionCode?: string,
): Promise<SelectControl[] | null> => {
    const params = {
        regionCode: regionCode ? regionCode : "0",
    };
    const response = await vineAuthServerHTTPClient.getJson(
        provincesResponseSchema,
        `/api-priv/v1/vine-auth/regions/${regionCode}/provinces`,
        { params },
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }

    const mappedProvinces = response.data.provinces.map((province) => ({
        text: province.description,
        id: province.code.toString(),
    }));

    const sortedProvinceList = mappedProvinces.sort((a, b) =>
        a.text.localeCompare(b.text, "it", { sensitivity: "base" }),
    );

    return sortedProvinceList;
};

export const getTransferCauses = async (): Promise<SelectControl[] | null> => {
    const response = await vineAuthServerHTTPClient.getJson(
        transferCauseResponseSchema,
        `/api-priv/v1/vine-auth/transfer-causes`,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }

    const mapped = response.data.transferCauses.map((v) => ({
        text: v.description,
        id: v.code,
    }));
    return mapped;
};

export const getExpirationDateUpdateCauses = async (): Promise<
    SelectControl[] | null
> => {
    const response = await vineAuthServerHTTPClient.getJson(
        updateExpirationDateCausesSchema,
        `/api-priv/v1/vine-auth/expiration-date-update-causes`,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    const mapped = response.data.expirationDateUpdateCauses.map((v) => ({
        text: v.description,
        id: v.code,
    }));
    return mapped;
};

export const authToRegionTransfer = async (
    partyId: string,
    authorizationId: string,
    payload: AuthorizationToRegionType,
): Promise<Authorization | null> => {
    const mappedPayload = {
        referredRegionCode: payload.regionReference,
        transferredSurface: payload.transferredSurface,
        transferDate: payload.transferredDate
            ? toAbsoluteDateString(payload.transferredDate)
            : null,
        notes: payload.note,
    };
    const response = await vineAuthServerHTTPClient.patchJson(
        AuthorizationVineSchema,
        `/api-priv/v1/vine-auth/parties/${partyId}/authorizations/${authorizationId}/transfer-to-region`,
        mappedPayload,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data;
};

export const updateAuthExpirationDate = async (
    partyId: string,
    authorizationId: string,
    payload: AuthorizationExpirationDateType,
): Promise<Authorization | null> => {
    const mappedPayload = {
        updateCauseCode: payload.updateCauseCode,
        expirationDate: payload.newExpirationDate
            ? toAbsoluteDateString(payload.newExpirationDate)
            : null,
        notes: payload.note,
    };
    const response = await vineAuthServerHTTPClient.patchJson(
        AuthorizationVineSchema,
        `/api-priv/v1/vine-auth/parties/${partyId}/authorizations/${authorizationId}/update-expiration-date`,
        mappedPayload,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data;
};

export const updateAuth = async (
    partyId: string,
    authorizationId: string,
    payload: AuthorizationData,
): Promise<Authorization | null> => {
    const mappedPayload = {
        nationalAuthorizationId: payload.nationalAuthorizationId,
        authorizationTypeCode: payload.authorizationType,
        originNationalAuthorizationId: payload.originNationalAuthorizationId,
        originRegionCode: payload.regionOrigin,
        referredRegionCode: payload.regionReference,
        referredProvinceCode: payload.provinceReference,
        authorizationSurface: payload.authorizationSurface,
        plantedSurface: payload.plantedSurface,
        transferredSurface: payload.transferredSurface,
        notes: payload.note,
        releaseDate: toAbsoluteDateString(payload.releaseDate),
        expirationDate: toAbsoluteDateString(payload.expirationDate),
    };
    const response = await vineAuthServerHTTPClient.patchJson(
        AuthorizationVineSchema,
        `/api-priv/v1/vine-auth/parties/${partyId}/authorizations/${authorizationId}`,
        mappedPayload,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data;
};

export const newAuth = async (
    partyId: string,
    payload: AuthorizationData,
): Promise<Authorization | null> => {
    const mappedPayload = {
        nationalAuthorizationId: payload.nationalAuthorizationId,
        authorizationTypeCode: payload.authorizationType,
        originNationalAuthorizationId: payload.originNationalAuthorizationId,
        originRegionCode: payload.regionOrigin,
        referredRegionCode: payload.regionReference,
        referredProvinceCode: payload.provinceReference,
        authorizationSurface: payload.authorizationSurface,
        plantedSurface: payload.plantedSurface,
        transferredSurface: payload.transferredSurface,
        notes: payload.note,
        releaseDate: toAbsoluteDateString(payload.releaseDate),
        expirationDate: toAbsoluteDateString(payload.expirationDate),
    };
    const response = await vineAuthServerHTTPClient.postJson(
        AuthorizationVineSchema,
        `/api-priv/v1/vine-auth/parties/${partyId}/authorizations`,
        mappedPayload,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data;
};

const toAbsoluteDateString = (
    dateString: string | Date | null,
): string | null => {
    const date = AbsoluteDate.of(dateString);
    if (date === null) return null;
    return date.toString();
};

export const transferAuthorizationToCuaa = async (
    partyId: string,
    authorizationId: string,
    payload: AuthorizationTransferToCuaa,
): Promise<TransferAuthorizationToCuaa | null> => {
    const response = await vineAuthServerHTTPClient.patchJson(
        TransferAuthorizationToCuaaSchema,
        `/api-priv/v1/vine-auth/parties/${partyId}/authorizations/${authorizationId}/transfer-to-cuaa`,
        payload,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (response.errorType === ErrorType.HTTP_STATUS) {
            try {
                const err = await response.response.clone().json();
                if (err.errorCode === ErrorCode.SAME_PARTY_ERROR) {
                    useMessageStore().setMessage({
                        message: t(`unit.errors.SAME_PARTY_ERROR`),
                        level: "danger",
                    });
                } else {
                    useMessageStore().handleApiErrorAndShowAlert(response);
                }
            } catch (err) {
                console.warn(err);
                useMessageStore().handleApiErrorAndShowAlert(response);
            }
        }
        return null;
    }
    return response.data;
};

export const getAuthorizationByPartyId = async (
    partyId: string,
    authorizationId: string,
): Promise<Authorization | null> => {
    const response = await vineAuthServerHTTPClient.getJson(
        AuthorizationVineSchema,
        `/api-priv/v1/vine-auth/parties/${partyId}/authorizations/${authorizationId}`,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data;
};
