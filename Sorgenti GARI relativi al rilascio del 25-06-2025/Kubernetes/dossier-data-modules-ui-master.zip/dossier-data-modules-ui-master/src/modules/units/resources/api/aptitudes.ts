import {
    AptitudeDetailSchema,
    AptitudeSummaryListSchema,
    PaginatedAptitudeUvListSchema,
    type AptitudeDetail,
    type AptitudeSummaryList,
    type PaginatedAptitudeUvListModel,
} from "@/modules/units/models/vineUnit";
import { useMessageStore } from "@/stores/messageStore";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { ZodError } from "zod";
import { dossierDataModulesHTTPClient } from "../../../../resources/api/http";

export const getAptitudesSummary = async (
    partyId: number,
    referenceDate: string,
): Promise<AptitudeSummaryList> => {
    const response = await dossierDataModulesHTTPClient.getJson(
        AptitudeSummaryListSchema,
        `/api-priv/v1/vine-aptitudes/${partyId}/summary/aptitudes/${referenceDate}`,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        ) {
            console.error(response.err);
        } else {
            useMessageStore().handleApiErrorAndShowAlert(response);
        }
        return [];
    }
    return response.data;
};

export const getAptitudesUvListByCode = async (
    partyId: number,
    referenceDate: string,
    code: string,
    nextKey: string | null,
): Promise<PaginatedAptitudeUvListModel> => {
    const response = await dossierDataModulesHTTPClient.getJson(
        PaginatedAptitudeUvListSchema,
        `/api-priv/v1/vine-aptitudes/${partyId}/summary/aptitudes/${referenceDate}/${code}`,
        { params: { ...(nextKey !== null && { nextKey }) } },
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        ) {
            console.error(response.err);
        } else {
            useMessageStore().handleApiErrorAndShowAlert(response);
        }

        return {
            count: 0,
            records: [],
            nextKey: null,
        };
    }
    return response.data;
};

export const getAptitudeDetailById = async (
    referenceDate: string,
    parcelId: number,
    landCoversId: number,
    vineUnitId: number,
    vineAptitudeId: number,
): Promise<AptitudeDetail | null> => {
    const response = await dossierDataModulesHTTPClient.getJson(
        AptitudeDetailSchema,
        `/api-priv/v1/vine-aptitudes/aptitude/${referenceDate}/${parcelId}/land-covers/${landCoversId}/units/vine-unit/${vineUnitId}/aptitudes/${vineAptitudeId}`,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        ) {
            console.error(response.err);
        } else {
            useMessageStore().handleApiErrorAndShowAlert(response);
        }
        return null;
    }
    return response.data;
};
