import {
    ErrorType,
    type HttpJsonResult,
    type RequestConfig,
} from "@abaco/safe-rest/src/HTTPClient";

import { getUserData } from "@abaco/safe-rest/src/sso2";
import { z } from "zod";
import { http } from "@/resources/api/http";
import { applicationsBaseUrl } from "../../utils/apiUtils";
import { removeNullsOrBlanksFromObject } from "../../utils/utils";
import {
    type PartyListModel,
    type PartyRegistryListModel,
    PartyListModelSchema,
    PartyRegistryListSchema,
    PartyModelSchema,
    PartyRegistryDetailsSchema,
    type TenantConfigListModel,
    TenantConfigListSchema,
} from "../../models/application";


export const getParties = async (
    url: string,
    cuaa?: string | null,
    partyDesc?: string | null,
    nextKey?: string | null,
): Promise<HttpJsonResult<PartyListModel | PartyRegistryListModel>> => {
  const user = getUserData(); // Non serve, questo controllo viene già fatto  da httpClient
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

    const requestConfig: RequestConfig = {};

    requestConfig.params = {
        search_code: cuaa && cuaa.replace(/-/g, ""),
        search_description: partyDesc,
        next_key: nextKey,
    };
    removeNullsOrBlanksFromObject(requestConfig.params);

    return http.getJson(
        z.union([PartyListModelSchema, PartyRegistryListSchema]),
        url.replace("{tenant}", user.tenant),
        requestConfig,
    );
};

export const getParty = async ( // Credo che non serva dato che non viene usata inoltre c'è già l'api analoga in party-public-api
  partyId: number,
  url: string,
// ): Promise<HttpJsonResult<PartyModel | PartyRegistryDetailsModel>> => {
)  => {
  const user = getUserData(); // Non serve, questo controllo viene già fatto  da httpClient
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

    return http.getJson(
        z.union([PartyModelSchema, PartyRegistryDetailsSchema]),
        url
            .replace("{tenant}", user.tenant)
            .replace("{partyId}", partyId.toString()),
    );
};
 
 
export const loadTenantConfigsAPI = async (): Promise<
    HttpJsonResult<TenantConfigListModel>
> => {
  const user = getUserData(); // Non serve, questo controllo viene già fatto  da httpClient
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }
  return http.getJson(
    TenantConfigListSchema,
    `${applicationsBaseUrl(user.tenant)}/environments`,
  );
};


 