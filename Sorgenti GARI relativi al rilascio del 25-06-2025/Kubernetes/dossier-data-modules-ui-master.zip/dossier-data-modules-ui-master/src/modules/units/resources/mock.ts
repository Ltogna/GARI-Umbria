export function getSubjects() {
    const res =  [
            {
                "partyId": 115520,
                "code": "02969130240",
                "description": "\" LA CUCCA S.S.\""
            },
            {
                "partyId": 88407,
                "code": "00740570288",
                "description": "\"SEI - F DI SANTINON GIUSEPPE & C. SNC\""
            },
            {
                "partyId": 109439,
                "code": "LZZGDU49R24I418D",
                "description": "' AI GIARDINI ' DI LAZZARO GUIDO"
            },

        ];

    return res;    
}