import { SERVER_DATE_FORMAT } from "@/constants";
import {
    PaginatedParcelLandLinkListSchema,
    PaginatedParcelListSchema,
    PaginatedQuotaSummaryListSchema,
    PaginatedOliveUnitListSchema,
    ParcelSchema,
    SectorSummaryListSchema,
    VarietySummaryListSchema,
    OliveUnitSchema,
    type PaginatedParcelListModel,
    type Parcel,
    type ParcelFilter,
    type ParcelLandLink,
    type QuotaSummaryList,
    type SectorSummaryList,
    type VarietySummaryList,
    type OliveUnitListModel,
    type OliveUnitModel,
} from "@/modules/units/models/oliveUnit";
import { useMessageStore } from "@/stores/messageStore";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { format } from "date-fns";
import { ZodError } from "zod";
import {
    customerOliveLinkHTTPClient,
    dossierDataModulesHTTPClient,
    oliveGisHTTPClient,
} from "../../../../resources/api/http";
import { PAGE_SIZE } from "../../constants";

export const getUnitsSummaryBySector = async (
    partyId: number,
    referenceDate: string,
): Promise<SectorSummaryList> => {
    const response = await oliveGisHTTPClient.getJson(
        SectorSummaryListSchema,
        `/public/v1/lpis/units/olive-unit/party/${partyId}/summary/sectors/${referenceDate}`,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return [];
    }
    return response.data;
};

export const getUnitsSummaryByVariety = async (
    partyId: number,
    referenceDate: string,
): Promise<VarietySummaryList> => {
    const response = await oliveGisHTTPClient.getJson(
        VarietySummaryListSchema,
        `/public/v1/lpis/units/olive-unit/party/${partyId}/summary/varieties/${referenceDate}`,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return [];
    }
    return response.data;
};

export const getUnitById = async (
    referenceDate: Date,
    parcelId: number,
    landCoversId: number,
    unitId: number,
): Promise<OliveUnitModel | null> => {
    const formattedReferenceDate = format(referenceDate, SERVER_DATE_FORMAT);

    const response = await oliveGisHTTPClient.getJson(
        OliveUnitSchema,
        `/public/v1/lpis/parcels/${formattedReferenceDate}/${parcelId}/land-covers/${landCoversId}/units/olive-unit/${unitId}`,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data;
};

export const getUnitsList = async (
    referenceDate: string,
    parcelId: number | null,
    landCoversId: number | null,
): Promise<OliveUnitListModel> => {
    const list: OliveUnitListModel = [];

    let nextKey: string | null = null;

    do {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const params: any = {
            page_size: PAGE_SIZE,
            ...(nextKey !== null && { next_key: nextKey }),
        };
        const response = await oliveGisHTTPClient.getJson(
            PaginatedOliveUnitListSchema,
            `/api-priv/v1/lpis/parcels/${referenceDate}/${parcelId}/land-covers/${landCoversId}/units/olive-unit`,
            { params },
        );
        if (response.errorType !== ErrorType.NONE) {
            if (
                response.errorType === ErrorType.OTHER &&
                response.err instanceof ZodError
            )
                console.error(response.err);
            else useMessageStore().handleApiErrorAndShowAlert(response);
            return [];
        }
        list.push(...response.data.records);
        nextKey = response.data.nextKey;
    } while (nextKey);

    return list;
};

export const getParcels = async (
    parcelFilter: ParcelFilter,
    partyId: number,
    nextKey: string | null,
): Promise<PaginatedParcelListModel> => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const list: Parcel[] = [];

    const params: { [key: string]: unknown } = {
        ...(parcelFilter?.sector && {
            sector_descr_filter: parcelFilter.sector,
        }),
        ...(parcelFilter?.parcelSheet && {
            block_descr_filter: parcelFilter.parcelSheet,
        }),
        ...(parcelFilter?.parcelCode && {
            parcel_filter: parcelFilter.parcelCode,
        }),
        ...(parcelFilter?.variety && {
            variety_code: parcelFilter.variety,
        }),
        // ...(parcelFilter?.anomalyCode && {
        //     anomaly_code: parcelFilter.anomalyCode,
        // }),
        include_anomalies: true,
        include_landcovers: true,
        include_units: true,
        ...(nextKey !== null && { next_key: nextKey }),
        page_size: PAGE_SIZE,
    };

    const referenceDate = format(
        parcelFilter.referenceDate ?? new Date(),
        SERVER_DATE_FORMAT,
    );

    const response = await oliveGisHTTPClient.getJson(
        PaginatedParcelListSchema,
        `/public/v1/lpis/units/olive-unit/party/${partyId}/parcels/${referenceDate}`,
        { params },
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return {
            count: 0,
            records: [],
            nextKey: null,
        };
    }

    return response.data;
};

export const getParcelById = async (
    referenceDate: Date,
    parcelId: number,
    include_landcovers: boolean,
    include_units: boolean,
    include_anomalies: boolean,
): Promise<Parcel | null> => {
    const formattedReferenceDate = format(referenceDate, SERVER_DATE_FORMAT);

    const params = {
        include_landcovers: include_landcovers,
        include_units: include_units,
        include_anomalies: include_anomalies,
    };
    const response = await oliveGisHTTPClient.getJson(
        ParcelSchema,
        `/public/v1/lpis/parcels/${formattedReferenceDate}/${parcelId}`,
        { params },
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data;
};

export const getParcelLandLink = async (
    referenceDate: Date,
    parcelId: number,
    partyId: number,
): Promise<ParcelLandLink | null> => {
    const formattedReferenceDate = format(referenceDate, SERVER_DATE_FORMAT);

    const params = {
        parcelId: parcelId,
        page_size: PAGE_SIZE,
    };
    const response = await customerOliveLinkHTTPClient.getJson(
        PaginatedParcelLandLinkListSchema,
        `/public/v1/parties/${partyId}/land-links/${formattedReferenceDate}`,
        { params },
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data.records[0]; // Supposed to be only one landLink for unique parcelId and partyId
};

export const getQuotasSummary = async (
    partyId: number,
    nextKey: string | null,
): Promise<{
    count: number;
    records: QuotaSummaryList;
    nextKey: string | null;
}> => {
    const response = await dossierDataModulesHTTPClient.getJson(
        PaginatedQuotaSummaryListSchema,
        `/api-priv/v1/doigt-quotas/${partyId}`,
        { params: { ...(nextKey !== null && { next_key: nextKey }) } },
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        ) {
            console.error(response.err);
        } else {
            useMessageStore().handleApiErrorAndShowAlert(response);
        }
        return {
            count: 0,
            records: [],
            nextKey: null,
        };
    }
    return response.data;
};
