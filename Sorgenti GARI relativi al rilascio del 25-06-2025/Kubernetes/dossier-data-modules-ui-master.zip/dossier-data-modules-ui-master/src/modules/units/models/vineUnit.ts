import {
    AnomalySearchSchema,
    type AnomalyLevelModel,
} from "@/models/anomalyLevel";
import { getNextPagedResultsSchema } from "@abaco/safe-rest/src/pagination";
import { z } from "zod";
export interface CodeDescriptionPair {
    code: string;
    description: string;
}
export interface ParcelFilter {
    parcelSheet: string | null;
    parcelCode: string | null;
    referenceDate: Date | null;
    sector: string | null;
    variety: string | null;
    anomalyCode: AnomalyLevelModel | null;
}

export interface SelectValue {
    id: string;
    text: string;
}

// SECTOR
export const SectorSchema = z.object({
    id: z.number(),
    description: z.string(),
    short_descr: z.string(),
    sector_code: z.string(),
    srs: z.string().nullable(),
    geom: z.string().nullable(),
    world_geom: z.string().nullable(),
});

export const SectorSummarySchema = z.object({
    sector: SectorSchema,
    num_parcel: z.number(),
    num_units: z.number(),
    total_unit_area_sqm: z.number(),
    anomalies_list: z.array(AnomalySearchSchema),
});

export const SectorSummaryListSchema = z.array(SectorSummarySchema);

// VARIETY
export const CodeDescriptionSchema = z.object({
    code: z.string(),
    description: z.string(),
    visible: z.boolean(),
});

export type CodeDescriptionModel = z.infer<typeof CodeDescriptionSchema>;

export const VarietySummarySchema = z.object({
    variety: CodeDescriptionSchema,
    num_parcel: z.number(),
    num_units: z.number(),
    total_unit_area_sqm: z.number(),
    anomalies_list: z.array(AnomalySearchSchema),
});

export const VarietySummaryListSchema = z.array(VarietySummarySchema);

// APTITUDES
export const DoIgtSchema = z.object({
    id: z.number(),
    code: z.string(),
    description: z.string(),
    category_code: z.string(),
    category_description: z.string(),
    name_code: z.string(),
    name_description: z.string(),
    visible: z.boolean(),
});

export const VineAptitudeSchema = z.object({
    id: z.number(),
    unit_id: z.number(),
    doigt: DoIgtSchema,
    day_from_precision: z.string(),
    day_to: z.string(),
    prevent_typology: z.boolean(),
    prevent_claim: z.boolean(),
    prevent_suitability: z.boolean(),
});

export const VineAptitudeListSchema = z.array(VineAptitudeSchema);

export const VarietySchema = z.object({
    code: z.string(),
    description: z.string(),
    visible: z.boolean(),
});

export const BlockSchema = z.object({
    id: z.number().nullish(),
    sector_id: z.number().nullish(),
    description: z.string().nullish(),
    short_descr: z.string().nullish(),
    block_code: z.string().nullish(),
    srs: z.string().nullish(),
    geom: z.string().nullish(),
    world_geom: z.string().nullish(),
});

export const VineUnitSchema = z.object({
    id: z.number(),
    land_cover_id: z.number(),
    code: z.string().nullish(),
    variety: CodeDescriptionSchema,
    area_sqm: z.number(),
    planting_day: z.string(),
    planting_day_precision: z.string(),
    eradicate_day: z.string().nullable(),
    distance_on_the_row_cm: z.number(),
    distance_between_rows_cm: z.number(),
    stumps_number: z.number(),
    stumps_density100: z.number(),
    farming_form: CodeDescriptionSchema,
    irrigation: CodeDescriptionSchema,
    product_destination: CodeDescriptionSchema,
    variation_type: CodeDescriptionSchema,
    cultivation_status: CodeDescriptionSchema.nullable(),
    terracing: CodeDescriptionSchema.nullable(),
    failures_perc: z.number().nullable(),
    soil_layering_perc: z.number().nullable(),
    altitude_above_sea_level: z.number().nullable(),
    poles_weaving: CodeDescriptionSchema.nullable(),
    poles_distance_cm: z.number().nullable(),
    support_wires: CodeDescriptionSchema.nullable(),
    header_anchoring: CodeDescriptionSchema.nullable(),
    poles_header: CodeDescriptionSchema.nullable(),
    external_code: z.string().nullable(),
    vine_aptitudes: VineAptitudeListSchema,
    unit_type: z.string().nullish(), // set client side
    last_update: z.coerce.date().nullish(),
    anomalies: AnomalySearchSchema.array().nullable(),
});

export const PaginatedVineUnitListSchema =
    getNextPagedResultsSchema(VineUnitSchema);
export type PaginatedVineUnitListModel = z.infer<
    typeof PaginatedVineUnitListSchema
>;

export const VineUnitListSchema = z.array(VineUnitSchema);

export const ErrorSchema = z.object({
    anomalies_list: z.array(AnomalySearchSchema),
    error: z.string().nullable(),
});

export const ParcelSchema = z.object({
    id: z.number(),
    parcel: z.string(),
    day_from: z.string(),
    day_to: z.string(),
    total_land_covers_area_sqm: z.number().nullish(),
    area_sqm: z.number(),
    block: BlockSchema,
    sector: SectorSchema,
    source_code: z.string().nullish(),
    sde_code: z.string().nullish(),
    landcovers_list: z.array(
        z.object({
            id: z.number(),
            code: z.string(),
            description: z.string().nullish(),
            parcel_id: z.number(),
            day_from: z.string(),
            day_to: z.string(),
            area_sqm: z.number(),
            vine_units: z.array(VineUnitSchema),
        }),
    ),
    anomalies: ErrorSchema.nullable(),
});

export const PaginatedParcelListSchema =
    getNextPagedResultsSchema(ParcelSchema);
export type PaginatedParcelListModel = z.infer<
    typeof PaginatedParcelListSchema
>;

export const ParcelLandLinkSchema = z.object({
    id: z.number(),
    partyId: z.number(),
    titleType: z.object({
        id: z.number().nullable(),
        code: z.string().nullable(),
        dayToReq: z.boolean().nullable(),
        i18nCode: z.string().nullable(),
    }),
    titleTypePerc: z.number().nullable(),
    parcel: z.object({
        id: z.number().nullable(),
        parcel: z.string().nullable(),
        dayFrom: z.string().nullable(),
        dayTo: z.string().nullable(),
        srs: z.string().nullable().nullable(),
        areaSqm: z.number().nullable(),
        block: z.object({
            id: z.number().nullable(),
            description: z.string().nullable(),
            shortDescr: z.string().nullable(),
            blockCode: z.string().nullable(),
        }),
        sector: z.object({
            id: z.number().nullable(),
            description: z.string().nullable(),
            shortDescr: z.string().nullable(),
            sectorCode: z.string().nullable(),
        }),
        geom: z.string().nullable().nullable(),
        worldGeom: z.string().nullable().nullable(),
    }),
    dayFrom: z.string().nullable(),
    dayTo: z.string().nullable(),
    anomalyCount: z.number().nullable(),
});

export const PaginatedParcelLandLinkListSchema =
    getNextPagedResultsSchema(ParcelLandLinkSchema);
export type PaginatedParcelLandLinkListModel = z.infer<
    typeof PaginatedParcelLandLinkListSchema
>;

export const AuthorizationSummarySchema = z.object({
    authorizationType: z.string(),
    authorizationTypeCode: z.string(),
    counter: z.number(),
    authorizationSurface: z.number(),
    plantedSurface: z.number(),
    transferredSurface: z.number(),
    residualSurface: z.number(),
});

export const PaginatedAuthorizationSummaryListSchema =
    getNextPagedResultsSchema(AuthorizationSummarySchema);
export type PaginatedAuthorizationSummaryListModel = z.infer<
    typeof PaginatedAuthorizationSummaryListSchema
>;

export const AuthorizationSummaryListSchema = z.array(
    AuthorizationSummarySchema,
);

export const AuthorizationSchema = z.object({
    /**
     * Id
     */
    id: z.number(),
    /**
     * Id Autorizzazione
     */
    authorizationId: z.number(),
    /**
     *  Id Autorizzazione Nazionale
     */
    nationalAuthorizationId: z.string().nullable(),
    /**
     * Tipo autorizzazione
     */
    authorizationType: z.string(),
    // NOT IN USE authorizationTypeCode: z.string(),
    /**
     * Id Autorizzazione di provenienza
     */
    surfaceAuthorizationId: z.number().nullable(),
    /**
     * Id Autorizzazione Nazionale di provenienza
     */
    surfaceNationalAuthorizationId: z.string().nullable(),
    /**
     * Id Diritto Provenienza
     */
    rightOriginId: z.number().nullable(),
    // NOT IN USE authorizationIstatRp: z.string().nullable(),
    /**
     * Regione di provenienza
     */
    denoAuthorizationIstatRp: z.string().nullable(),
    // NOT IN USE authorizationIstatR: z.string(),
    /**
     * Regione di riferimento
     */
    denoAuthorizationIstatR: z.string().nullable(),
    // NOT IN USE authorizationIstatP: z.string().nullable(),
    /**
     * Provincia di riferimento
     */
    denoProv: z.string().nullable(),
    /**
     * Sup. autorizzazione (ha)
     */
    surfaceAuthorization: z.number(),
    /**
     * Sup. impiantata (ha)
     */
    plantedSurface: z.number(),
    /**
     * Sup. trasferita (ha)
     */
    transferredSurface: z.number(),
    /**
     * Sup. residua (ha)
     */
    residualSurface: z.number(),
    /**
     * Identificativo protocollo
     */
    protocolId: z.number().nullable(),
    /**
     * Data protocollo
     */
    protocolDt: z.string().nullable(),
    /**
     * Tipologia domanda
     */
    questionType: z.string().nullable(),
    /**
     * Data conversione
     */
    conversionDt: z.coerce.date().nullable(),
    /**
     * Id domanda
     */
    questionId: z.number().nullable(),
    /**
     * Note
     */
    note: z.string().nullable(),
    /**
     * Data rilascio
     */
    dtStart: z.coerce.date(),
    /**
     *  Data scadenza
     */
    dtEnd: z.coerce.date(),
});

export const PaginatedAuthorizationListSchema =
    getNextPagedResultsSchema(AuthorizationSchema);
export type PaginatedAuthorizationListModel = z.infer<
    typeof PaginatedAuthorizationListSchema
>;

export const AuthorizationsListSchema = z.array(AuthorizationSchema);

export const AptitudeSummarySchema = z.object({
    doIgt: DoIgtSchema,
    areaSqm: z.number(),
    areaTypology: z.number(),
    areaClaims: z.number(),
    areaSuitability: z.number(),
});

export const AptitudeSummaryListSchema = z.array(AptitudeSummarySchema);

export const AptitudeUvSchema = z.object({
    parcelId: z.number(),
    landCoverId: z.number(),
    vineUnitId: z.number(),
    vineUnitCode: z.string(),
    areaSqm: z.number(),
    registeredAreaSmq: z.number(),
    parcelCode: z.string(),
    vineAptitudeId: z.number(),
    preventTypology: z.boolean(),
    preventClaim: z.boolean(),
    preventSuitability: z.boolean(),
    variety: VarietySchema,
    block: BlockSchema,
    sector: SectorSchema,
});

export const PaginatedAptitudeUvListSchema =
    getNextPagedResultsSchema(AptitudeUvSchema);
export type PaginatedAptitudeUvListModel = z.infer<
    typeof PaginatedAptitudeUvListSchema
>;

export const AptitudeUvListSchema = z.array(AptitudeUvSchema);

export const AptitudeDetailSchema = z.object({
    id: z.number(),
    unit_id: z.number(),
    doigt: DoIgtSchema,
    vineyard: z.string().nullable(),
    day_from: z.string(),
    day_from_precision: z.string(),
    day_to: z.string(),
    prevent_typology: z.boolean(),
    prevent_claim: z.boolean(),
    prevent_suitability: z.boolean(),
});

export const QuotaSummarySchema = z.object({
    wineQuota: z.string(),
    assignedQuota: z.number(),
    usedQuota: z.number(),
    revokedQuota: z.number(),
    residualQuote: z.number(),
});

export const PaginatedQuotaSummaryListSchema =
    getNextPagedResultsSchema(QuotaSummarySchema);
export type PaginatedQuotaSummaryListModel = z.infer<
    typeof PaginatedQuotaSummaryListSchema
>;

export const QuotaSummaryListSchema = z.array(QuotaSummarySchema);

//TYPES
export type VineUnitModel = z.infer<typeof VineUnitSchema>;
export type VineUnitListModel = z.infer<typeof VineUnitListSchema>;

export type SectorSummary = z.infer<typeof SectorSummarySchema>;
export type SectorSummaryList = z.infer<typeof SectorSummaryListSchema>;

export type VarietySummary = z.infer<typeof VarietySummarySchema>;
export type VarietySummaryList = z.infer<typeof VarietySummaryListSchema>;

export type VineAptitudeList = z.infer<typeof VineAptitudeListSchema>;
export type VineAptitude = z.infer<typeof VineAptitudeSchema>;
export type Parcel = z.infer<typeof ParcelSchema>;
export type ParcelLandLink = z.infer<typeof ParcelLandLinkSchema>;

export type AuthorizationSummary = z.infer<typeof AuthorizationSummarySchema>;
export type AuthorizationSummaryList = z.infer<
    typeof AuthorizationSummaryListSchema
>;
export type AuthorizationsList = z.infer<typeof AuthorizationsListSchema>;

export type AptitudeSummary = z.infer<typeof AptitudeSummarySchema>;
export type AptitudeSummaryList = z.infer<typeof AptitudeSummaryListSchema>;
export type AptitudeUv = z.infer<typeof AptitudeUvSchema>;
export type AptitudeUvList = z.infer<typeof AptitudeUvListSchema>;
export type AptitudeDetail = z.infer<typeof AptitudeDetailSchema>;

export type QuotaSummary = z.infer<typeof QuotaSummarySchema>;
export type QuotaSummaryList = z.infer<typeof QuotaSummaryListSchema>;

export enum VineUnitStatusEnum {
    YES = "S",
    NO = "N",
}

 