import type { TemplateOptions } from "lodash";
import { z } from "zod";

export const templateOptions: TemplateOptions = {
    interpolate: /\{([\s\S]+?)\}/g,
};

export const UnitConfigurationSchema = z.object({
    AUTH_ENABLED: z.boolean().nullish(),
    DO_IGT_QUOTAS_ENABLED: z.boolean().nullish(),
    APPLICATIONS_ENABLED: z.boolean().nullish(),
    APTITUDES_ENABLED: z.boolean().nullish(),
    PARTY_REGISTRY_DIRECTORY_URL: z.string().nullish(),
    MODE: z
        .union([z.literal("vine"), z.literal("olive"), z.literal("fruit")])
        .nullish(),
});

export type UnitConfiguration = z.infer<typeof UnitConfigurationSchema>;
