import { z } from "zod";

export interface AuthorizationData {
    authorizationId: number | null;
    nationalAuthorizationId: string | null;
    authorizationType: string | null;
    originAuthorizationId: string | null;
    originNationalAuthorizationId: string | null;
    rightOriginId: string | null;
    regionOrigin: string | null;
    regionReference: string | null;
    provinceReference: string | null;
    authorizationSurface: number | null;
    plantedSurface: number | null;
    transferredSurface: number | null;
    residualSurface: number | null;
    protocolId: string | null;
    protocolDate: string | null;
    typologyApplication: string | null;
    conversionDate: string | null;
    applicationId: number | null;
    note: string | null;
    releaseDate: Date | null;
    expirationDate: string | null;
}

export const AuthorizationToRegionTypeSchema = z.object({
    authorizationId: z.number().nullable(),
    nationalAuthorizationId: z.string().nullable(),
    regionReference: z.string().nullable(),
    residualSurface: z.number().nullable(),
    transferredSurface: z.number().nullable(),
    transferredDate: z.string().nullable(),
    note: z.string().nullable(),
});
export type AuthorizationToRegionType = z.infer<
    typeof AuthorizationToRegionTypeSchema
>;

export const AuthorizationExpirationDateTypeSchema = z.object({
    authorizationId: z.number().nullable(),
    nationalAuthorizationId: z.string().nullable(),
    currentExpirationDate: z.date(),
    updateCauseCode: z.string().nullable(),
    newExpirationDate: z.string().nullable(),
    releaseDate: z.date(),
    note: z.string().nullable(),
});
export type AuthorizationExpirationDateType = z.infer<
    typeof AuthorizationExpirationDateTypeSchema
>;

/**
 * Schema for authorization search.
 */
export const AuthorizationVineSchema = z.object({
    authorizationId: z.number().nullable(),
    nationalAuthorizationId: z.string(),
    authorizationTypeCode: z.string(),
    authorizationType: z.string(),
    cuaa: z.string(),
    originAuthorizationId: z.string().nullable(),
    originNationalAuthorizationId: z.string().nullable(),
    rightOriginId: z.string().nullable(),
    originRegionCode: z.string().nullable(),
    originRegionDesc: z.string().nullable(),
    referredRegionCode: z.string(),
    referredRegionDesc: z.string(),
    referredProvinceCode: z.string().nullable(),
    referredProvinceDesc: z.string().nullable(),
    authorizationSurface: z.number(),
    plantedSurface: z.number(),
    transferredSurface: z.number(),
    residualSurface: z.number(),
    protocolId: z.string().nullable(),
    protocolDate: z.string().nullable(),
    applicationTypeCode: z.string().nullable(),
    applicationTypeDesc: z.string().nullable(),
    conversionDate: z.string().nullable(),
    applicationId: z.number().nullable(),
    notes: z.string().nullable(),
    releaseDate: z.string(),
    expirationDate: z.string(),
});
// To verify
export type Authorization = z.infer<typeof AuthorizationVineSchema>;

/**
 * Schema for region response.
 */
export const regionSchema = z.object({
    description: z.string(),
    code: z.string(),
});

export const regionsResponseSchema = z.object({
    regions: z.array(regionSchema),
});

/**
 * Schema for province response.
 */
export const provinceSchema = z.object({
    description: z.string(),
    abbreviation: z.string(),
    code: z.number(),
    regionCode: z.string(),
});

export const provincesResponseSchema = z.object({
    provinces: z.array(provinceSchema),
});

export const SelectSchema = z.object({
    text: z.string(),
    id: z.string(),
});
export type SelectControl = z.infer<typeof SelectSchema>;

/**
 * Schema for transferAuthorizationToCuaaSchema
 */
export const TransferAuthorizationToCuaaSchema = z.object({
    authorizationId: z.number(),
    nationalAuthorizationId: z.string(),
    authorizationTypeCode: z.string(),
    authorizationType: z.string(),
    cuaa: z.string(),
    originAuthorizationId: z.number().nullable(),
    originNationalAuthorizationId: z.string().nullable(),
    rightOriginId: z.number().nullable(),
    originRegionCode: z.string().nullable(),
    originRegionDesc: z.string().nullable(),
    referredRegionCode: z.string(),
    referredRegionDesc: z.string(),
    referredProvinceCode: z.string().nullable(),
    referredProvinceDesc: z.string().nullable(),
    authorizationSurface: z.number(),
    plantedSurface: z.number(),
    transferredSurface: z.number(),
    residualSurface: z.number(),
    protocolId: z.number().nullable(),
    protocolDate: z.number().nullable(),
    applicationTypeCode: z.string().nullable(),
    applicationTypeDesc: z.string().nullable(),
    conversionDate: z.number().nullable(),
    applicationId: z.number().nullable(),
    notes: z.string().nullable(),
    releaseDate: z.string(),
    expirationDate: z.string(),
});

export type TransferAuthorizationToCuaa = z.infer<
    typeof TransferAuthorizationToCuaaSchema
>;

export const AuthorizationTransferToCuaaSchema = z.object({
    targetPartyId: z.number().nullable(),
    transferredSurface: z.number().nullable(),
    transferCause: z.string().nullable(),
    transferDate: z.string().nullable(),
    notes: z.string().nullable(),
    authorizationId: z.number().nullable(),
    nationalAuthorizationId: z.string().nullable(),
    targetCuaa: z.string().nullable(),
    residualSurface: z.number().nullable(),
});

export type AuthorizationTransferToCuaa = z.infer<
    typeof AuthorizationTransferToCuaaSchema
>;

/**
 * Schema for authorization type response.
 */
export const AuthTypeSchema = z.object({
    description: z.string(),
    code: z.string(),
});

export const AuthTypesResponseSchema = z.object({
    authorizationTypes: z.array(AuthTypeSchema),
});
export type AuthorizationType = z.infer<typeof AuthTypeSchema>;
export type AuthorizationTypeList = z.infer<typeof AuthTypesResponseSchema>;

/**
 * Schema for transferCause response.
 */
export const transferCausesSchema = z.object({
    description: z.string(),
    code: z.string(),
});

export const transferCauseResponseSchema = z.object({
    transferCauses: z.array(transferCausesSchema),
});

/**
 * Schema for updateExpirationDateCause response.
 */
export const updateExpirationDateCauseSchema = z.object({
    description: z.string(),
    code: z.string(),
});

export const updateExpirationDateCausesSchema = z.object({
    expirationDateUpdateCauses: z.array(updateExpirationDateCauseSchema),
});
