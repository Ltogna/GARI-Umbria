import { z } from "zod";

export const PartyModelSchema = z
  .object({
    partyId: z.number(),
    code: z.string(),
    description: z.nullable(z.string()),
  })
  .passthrough();

const MunicipalityDetailsSchema = z.object({
  code: z.string(),
  tenantId: z.string(),
  districtCode: z.string(),
  shortDescr: z.string(),
  active: z.boolean(),
  i18nName: z.string(),
  district: z.object({
    code: z.string(),
    tenantId: z.string(),
    regionCode: z.string(),
    shortDescr: z.string(),
    active: z.boolean(),
    i18nName: z.string(),
    region: z.object({
      code: z.string(),
      tenantId: z.string(),
      countryCode: z.string(),
      shortDescr: z.string(),
      active: z.boolean(),
      i18nName: z.string(),
      country: z.object({
        code: z.string(),
        tenantId: z.string(),
        active: z.boolean(),
        i18nName: z.string(),
      }),
    }),
  }),
});

const AddressResidentialSchema = z.object({
  id: z.number(),
  municipality: z.string().nullable(),
  locality: z.string().nullable(),
  street: z.string().nullable(),
  houseNumber: z.string().nullable(),
  postcode: z.string().nullable(),
  details: z.string().nullable(),
  note: z.string().nullable(),
  municipalityI18nCode: z.string().nullable(),
  municipalityDetail: MunicipalityDetailsSchema.nullable(),
});

export const PartyRegistrySchema = z.object({
  id: z.number(),
  partyType: z.string().nullable(),
  lastName: z.string().nullable(),
  firstName: z.string().nullable(),
  taxCode: z.string().nullable(),
  vatNumber: z.string().nullable(),
  code: z.string().nullable(),
  birthDate: z.string().nullable(),
  deathDate: z.string().nullable(),
  birthMunicipality: z.string().nullable(),
  birthMunicipalityDetail: MunicipalityDetailsSchema.nullable(),
  nationality: z.string().nullable(),
  addressResidential: AddressResidentialSchema.nullable(),
  archived: z.boolean().nullable(),
});

export const PartyListModelSchema = z.object({
  count: z.number(),
  records: z.array(PartyModelSchema),
  nextKey: z.nullable(z.string()),
});

export const PartyRegistryListSchema = z.object({
  count: z.number(),
  records: z.array(PartyRegistrySchema),
  nextKey: z.nullable(z.string()),
});

export const tagSchema = z.object({
  id: z.number(),
  code: z.string(),
  i18nCode: z.string(),
});

export const PartyRegistryDetailsSchema = z.object({
  id: z.number(),
  partyType: z.string(),
  gender: z.string().nullable(),
  lastName: z.string(),
  firstName: z.string().nullable(),
  taxCode: z.string().nullable(),
  vatNumber: z.string().nullable(),
  code: z.string().nullable(),
  birthDate: z.string().nullable(),
  deathDate: z.string().nullable(),
  birthMunicipality: z.string().nullable(),
  birthMunicipalityDetail: MunicipalityDetailsSchema.nullable(),
  nationality: z.string().nullable(),
  addressResidential: AddressResidentialSchema.nullable(),
  addressHome: AddressResidentialSchema.nullable(),
  addressBilling: AddressResidentialSchema.nullable(),
  tags: z.array(tagSchema),
  archived: z.boolean(),
});

export const ApplicationSummaryModelSchema = z
  .object({
    year: z.number(),
    applicationsNumber: z.number(),
  })
  .passthrough();

export const ApplicationSummaryListModelSchema = z.object({
  partyId: z.number(),
  applicationsSummaryByYear: z.array(ApplicationSummaryModelSchema),
});

export const ApplicationModuleSchema = z.nullable(
  z
    .object({
      year: z.nullable(z.number()),
      moduleCode: z.string(),
      moduleShortDescription: z.nullable(z.string()),
      sectorCode: z.string(),
      sectorShortDescription: z.nullable(z.string()),
    })
    .passthrough(),
);

export const ApplicationModulesResponseSchema = z
  .object({
    records: z.array(ApplicationModuleSchema),
    nextKey: z.nullable(z.string()),
    count: z.number(),
  })
  .passthrough();

export const AmendmentModuleSchema = z.nullable(
  z
    .object({
      sectorCode: z.string(),
      sectorDescription: z.string(),
      moduleCode: z.string(),
      moduleDescription: z.string(),
      flAmendModule: z.boolean(),
      annuality: z.number(),
    })
    .passthrough(),
);

export const AmendmentModulesResponseSchema = z.nullable(
  z.object({
    records: z.array(AmendmentModuleSchema),
    count: z.number(),
    nextKey: z.nullable(z.string()),
  }),
);

export const ApplicationSummaryDetailModelSchema = z.nullable(
  z
    .object({
      partyId: z.number(),
      year: z.number(),
      sectorCode: z.string(),
      sectorDescription: z.string(),
      moduleCode: z.string(),
      moduleDescription: z.string().nullable(),
      applicationCode: z.string(),
      applicationId: z.number(),
      processStatus: z.string().nullable(),
      processStatusDescription: z.string().nullable(),
      dtPresentation: z.string().nullable(),
      flAmendable: z.optional(z.boolean()),
      applicationProfilesDescription: z.string().optional().nullable(),
    })
    .passthrough(),
);

export const ApplicationSummaryDetailResponseSchema = z
  .object({
    records: z.nullable(
      z.array(z.nullable(ApplicationSummaryDetailModelSchema)),
    ),
    nextKey: z.nullable(z.string()),
    count: z.number(),
  })
  .passthrough();

export const CreateApplicationModelSchema = z
  .object({
    partyId: z.number(),
    year: z.number(),
    moduleCode: z.string(),
    sectorCode: z.string(),
  })
  .passthrough();

export const CreateAmendmentModelSchema = z
  .object({
    partyId: z.number(),
    year: z.number(),
    moduleCode: z.string(),
    sectorCode: z.string(),
  })
  .passthrough();

export const CreateApplicationResponseSchema = z
  .object({
    applicationId: z.nullable(z.number().optional()),
    applicationCode: z.nullable(z.string().optional()),
    anomalies: z.array(
      z.object({
        code: z.string(),
        message: z.string(),
      }),
    ),
  })
  .passthrough();

export const CreateAmendmentResponseSchema = z
  .object({
    applicationId: z.nullable(z.number().optional()),
    applicationCode: z.nullable(z.string().optional()),
    rectifiesApplicationId: z.nullable(z.number().optional()),
    anomalies: z.array(
      z.object({
        code: z.string(),
        message: z.string(),
      }),
    ),
  })
  .passthrough();

export const FormDetailsSchema = z
  .object({
    formConfigId: z.number(),
    formCode: z.string(),
    formName: z.string().nullable(),
    softwareUrl: z.string(),
    routerUrl: z.string().nullable(),
    flReadOnly: z.number(),
    sortOrder: z.number(),
    compileStatusIdentifier: z.string().nullable(),
    compileStatus: z.string().nullable(),
    params: z.record(z.string(), z.string()),
  })
  .passthrough();

export const GroupSchema = z
  .object({
    groupCode: z.string(),
    groupName: z.string().nullable(),
  })
  .passthrough();

export const FormSchema = z
  .object({
    groups: z.array(GroupSchema),
    formDetails: FormDetailsSchema,
  })
  .passthrough();

export const CompileStatusSchema = z
  .object({
    compileStatusIdentifier: z.string(),
    status: z.string(),
    statusDescription: z.string().nullable(),
  })
  .passthrough();

export const ProfileSchema = z
  .object({
    profileCode: z.string(),
    profileCodeDescription: z.string().nullable(),
  })
  .passthrough();

export const PrintSchema = z.object({
  printCode: z.string(),
  printDescription: z.string(),
  sortOrder: z.number(),
  params: z.record(z.string(), z.string()),
  lastPrint: z.nullable(
    z.object({
      printDate: z.number().or(z.string()),
      fileId: z.string(),
    }),
  ),
});

export const ApplicationDetailsCalculationsSchema = z.object({
  calculationCode: z.string(),
  calculationDescription: z.string(),
  sortOrder: z.number(),
  params: z.record(z.string(), z.string()),
  lastCalculation: z.nullable(
    z.object({
      calculationDate: z.number().or(z.string()),
      calculationJobUuid: z.string(),
      calculationStatus: z.string().nullable().optional(),
    }),
  ),
});

export const ApplicationDetailsSchema = z
  .object({
    partyId: z.number(),
    referredYear: z.number(),
    processId: z.number(),
    dtInsert: z.string(),
    applicationCode: z.string(),
    applicationId: z.number(),
    processStatus: z.string(),
    processStatusDescription: z.string().nullable(),
    dtPresentation: z.string().nullable(),
    sectorDescription: z.string().nullable(),
    moduleDescription: z.string().nullable(),
    moduleYear: z.number().nullable().optional(),
    forms: z.array(FormSchema),
    prints: z.nullable(z.array(PrintSchema)),
    profileList: z.array(ProfileSchema),
    lastMovement: z.nullable(z.string()),
    isClosed: z.nullable(z.boolean()),
    protocolCode: z.string().nullable().optional(),
    dtProtocolRequest: z.string().nullable().optional(),
    dtProtocolResponse: z.string().nullable().optional(),
    amendmentApplicationId: z.number().nullable().optional(),
    amendedApplicationId: z.number().nullable().optional(),
    calculations: z.array(ApplicationDetailsCalculationsSchema),
    applicationProfilesDescription: z.string().nullable().optional(),
  })
  .passthrough();

export const ApplicationHistorySchema = z.array(
  z
    .object({
      id: z.number(),
      startDate: z.number().or(z.string()),
      endDate: z.number().or(z.string()),
      userId: z.string(),
      processId: z.number(),
      transitionId: z.number(),
      notes: z.string().nullable(),
      failed: z.boolean(),
      description: z.string(),
      fromNode: z.string(),
      fromNodeDescription: z.string().nullable(),
      toNode: z.string(),
      toNodeDescription: z.string().nullable(),
      messages: z.array(
        z
          .object({
            code: z.string(),
            description: z.string(),
            type: z.enum(["ERROR", "INFO", "WARNING"]),
          })
          .transform((data) => {
            let errorLevel = 0;

            switch (data.type) {
              case "ERROR":
                errorLevel = 1;
                break;
              case "WARNING":
                errorLevel = 2;
                break;
              case "INFO":
                errorLevel = 3;
                break;
              default:
                errorLevel = 0;
                break;
            }
            return {
              ...data,
              errorLevel,
            };
          }),
      ),
    })
    .passthrough(),
);

export const ApplicationTransitionSchema = z
  .object({
    id: z.number(),
    fromNode: z.string(),
    toNode: z.string(),
    description: z.string(),
    scope: z.null(),
    tags: z.array(z.string()),
    notesRequired: z.boolean(),
  })
  .passthrough();

export const ApplicationTransitionsSchema = z.array(
  ApplicationTransitionSchema,
);

const TransitionMessageSchema = z
  .object({
    code: z.string(),
    description: z.string(),
    type: z.enum(["ERROR", "INFO", "WARNING"]),
  })
  .transform((data) => {
    let errorLevel = 0;

    switch (data.type) {
      case "ERROR":
        errorLevel = 1;
        break;
      case "WARNING":
        errorLevel = 2;
        break;
      case "INFO":
        errorLevel = 3;
        break;
      default:
        errorLevel = 0;
        break;
    }

    return {
      ...data,
      errorLevel,
    };
  });

export type TransitionMessage = z.infer<typeof TransitionMessageSchema>;

export const ApplicationIsInTransitionModelSchema = z.object({
  inTransition: z.boolean(),
  lastTransitionLog: z.nullable(
    z
      .object({
        id: z.number(),
        startDate: z.string().or(z.number()),
        endDate: z.string().or(z.number()),
        userId: z.string(),
        processId: z.number(),
        transitionId: z.number(),
        notes: z.nullable(z.string()),
        failed: z.boolean(),
        description: z.string(),
        fromNode: z.string(),
        fromNodeDescription: z.nullable(z.string()),
        toNode: z.string(),
        toNodeDescription: z.nullable(z.string()),
        messages: z.array(TransitionMessageSchema),
      })
      .passthrough(),
  ),
});

export const GeneratedPrintSchema = z.object({
  processStatus: z.string(),
  printCode: z.string(),
  printDescription: z.nullable(z.string()),
  printDate: z.number().or(z.string()),
  printJobUuid: z.nullable(z.string()),
  fileId: z.nullable(z.string()),
  username: z.string(),
  printStatus: z.nullable(z.string()),
});

export const PrintHistoryResponseSchema = z.array(GeneratedPrintSchema);

export const ApplicationAnomalySchema = z.object({
  pkid: z.number(),
  anomalyCode: z.string(),
  anomalyDesc: z.string(),
  severity: z.string(),
  dtInsert: z.string().or(z.number()),
});

export const ApplicationAnomalyResponseSchema = z.array(
  ApplicationAnomalySchema,
);

export const TenantConfigSchema = z.object({
  key: z.string(),
  value: z.union([z.string(), z.boolean(), z.number()]),
});

export const TenantConfigListSchema = z.array(TenantConfigSchema);

export const GeneratedCalculationSchema = z.object({
  processStatus: z.string(),
  processDescription: z.string().nullable(),
  calculationCode: z.string(),
  calculationDescription: z.nullable(z.string()),
  calculationDate: z.number().or(z.string()),
  calculationJobUuid: z.nullable(z.string()),
  username: z.string(),
  calculationStatus: z.nullable(z.string()),
  notes: z.string().nullable(),
});

export const GeneratedCalculationListSchema = z.array(
  GeneratedCalculationSchema,
);

export const CalculationSchema = z.object({
  result: z.any(),
});

export interface ApplicationFilter {
  referenceSubject: string;
  applicationNumber: string;
}
export interface SubjectFilter {
  cuaa: string;
  denomination: string;
  partyId: string;
}
export type ApplicationSummaryModel = z.infer<
  typeof ApplicationSummaryModelSchema
>;
export type ApplicationSummaryListModel = z.infer<
  typeof ApplicationSummaryListModelSchema
>;
export type ApplicationModuleModel = z.infer<typeof ApplicationModuleSchema>;
export type ApplicationModulesResponse = z.infer<
  typeof ApplicationModulesResponseSchema
>;
export type AmendmentModule = z.infer<typeof AmendmentModuleSchema>;
export type AmendmentModulesResponse = z.infer<
  typeof AmendmentModulesResponseSchema
>;
export type ApplicationSummaryDetailModel = z.infer<
  typeof ApplicationSummaryDetailModelSchema
>;
export type ApplicationSummaryDetailResponse = z.infer<
  typeof ApplicationSummaryDetailResponseSchema
>;
export type PartyModel = z.infer<typeof PartyModelSchema>;
export type PartyListModel = z.infer<typeof PartyListModelSchema>;
export type PartyRegistryModel = z.infer<typeof PartyRegistrySchema>;
export type PartyRegistryListModel = z.infer<typeof PartyRegistryListSchema>;
export type PartyRegistryDetailsModel = z.infer<
  typeof PartyRegistryDetailsSchema
>;
export type CreateApplicationModel = z.infer<
  typeof CreateApplicationModelSchema
>;
export type CreateAmendmentModel = z.infer<typeof CreateAmendmentModelSchema>;
export type CreateApplicationResponseModel = z.infer<
  typeof CreateApplicationResponseSchema
>;
export type CreateAmendmentResponseModel = z.infer<
  typeof CreateAmendmentResponseSchema
>;
export type FormModel = z.infer<typeof FormSchema>;
export type ApplicationDetailsModel = z.infer<typeof ApplicationDetailsSchema>;

export type FormGroupModel = z.infer<typeof GroupSchema>;
export type FormDetailsModel = z.infer<typeof FormDetailsSchema>;
export type ApplicationHistoryModel = z.infer<typeof ApplicationHistorySchema>;
export type ApplicationHistoryElementModel = z.infer<
  typeof ApplicationHistorySchema.element
>;
export type ApplicationTransitionModel = z.infer<
  typeof ApplicationTransitionSchema
>;
export type ApplicationTransitionsModel = z.infer<
  typeof ApplicationTransitionsSchema
>;
export type ApplicationIsInTransitionModel = z.infer<
  typeof ApplicationIsInTransitionModelSchema
>;
export type PrintModel = z.infer<typeof PrintSchema>;
export type GeneratedPrintModel = z.infer<typeof GeneratedPrintSchema>;
export type PrintHistoryResponseModel = z.infer<
  typeof PrintHistoryResponseSchema
>;
export type ApplicationAnomalyModel = z.infer<typeof ApplicationAnomalySchema>;
export type ApplicationAnomalyResponseModel = z.infer<
  typeof ApplicationAnomalyResponseSchema
>;
export type TenantConfigModel = z.infer<typeof TenantConfigSchema>;
export type TenantConfigListModel = z.infer<typeof TenantConfigListSchema>;

export type GeneratedCalculationModel = z.infer<
  typeof GeneratedCalculationSchema
>;
export type GeneratedCalculationListModel = z.infer<
  typeof GeneratedCalculationListSchema
>;
export type CalculationModel = z.infer<typeof CalculationSchema>;
export type ApplicationDetailsCalculationsModel = z.infer<
  typeof ApplicationDetailsCalculationsSchema
>;

/**
 * Types needed to represent forms with a tree structure
 */
export enum CardState {
  IN_PROGRESS = "IN_PROGRESS",
  COMPLETED = "COMPLETED",
  TO_BE_COMPILED = "TO_BE_COMPILED",
}

export enum MessageType {
  ERROR = "ERROR",
  WARNING = "WARNING",
  INFO = "INFO",
}

export interface CardNode {
  id: string;
  name: string;
  children?: CardNode[];
  formConfigId?: number;
  softwareUrl?: string;
  routerUrl?: string;
  compileStatus?: CardState;
  compileStatusIdentifier?: string;
  formCode?: string;
  sortOrder?: number;
  flReadOnly?: number;
  params?: Record<string, string>;
  isOpen?: boolean;
  partyId?: number;
  partyCode?: string;
}

export interface Anomalies {
  code: string;
  message: string;
}
export type PickedSelectedCard = Pick<
  CardNode,
  | "id"
  | "formConfigId"
  | "softwareUrl"
  | "routerUrl"
  | "params"
  | "flReadOnly"
  | "compileStatus"
  | "compileStatusIdentifier"
  | "formCode"
  | "partyId"
  | "partyCode"
>;
export type SelectedCard = PickedSelectedCard & {
  clicked?: boolean;
};

export function fromFormDetailsModelToSelectedCard(
  formDetail: FormDetailsModel,
  partyId: number,
  partyCode: string,
): SelectedCard {
  return {
    id: formDetail.formCode,
    name: formDetail.formName ? formDetail.formName : "",
    softwareUrl: formDetail.softwareUrl,
    routerUrl: formDetail.routerUrl ? formDetail.routerUrl : undefined,
    params: formDetail.params,
    flReadOnly: formDetail.flReadOnly,
    compileStatusIdentifier: formDetail.compileStatusIdentifier,
    formConfigId: formDetail.formConfigId,
    formCode: formDetail.formCode,
    compileStatus: formDetail.compileStatus
      ? (formDetail.compileStatus as CardState)
      : undefined,
    partyId: partyId,
    partyCode: partyCode,
  } as SelectedCard;
}
