export enum ErrorCode {
    SAME_PARTY_ERROR = "SAME_PARTY_ERROR",
  }