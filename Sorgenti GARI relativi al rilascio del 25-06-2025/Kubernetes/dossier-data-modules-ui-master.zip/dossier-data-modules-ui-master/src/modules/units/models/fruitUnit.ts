import {
    AnomalySearchSchema,
    type AnomalyLevelModel,
} from "@/models/anomalyLevel";
import { getNextPagedResultsSchema } from "@abaco/safe-rest/src/pagination";
import { z } from "zod";

export interface CodeDescriptionPair {
    code: string;
    description: string;
}
export interface ParcelFilter {
    parcelSheet: string | null;
    parcelCode: string | null;
    referenceDate: Date | null;
    sector: string | null;
    variety: string | null;
    anomalyCode: AnomalyLevelModel | null;
}

// SECTOR
export const SectorSchema = z.object({
    id: z.number(),
    description: z.string(),
    short_descr: z.string(),
    sector_code: z.string(),
    srs: z.string().nullable(),
    geom: z.string().nullable(),
    world_geom: z.string().nullable(),
});

export const SectorSummarySchema = z.object({
    sector: SectorSchema,
    num_parcel: z.number(),
    num_units: z.number(),
    total_unit_area_sqm: z.number(),
    anomalies_list: z.array(AnomalySearchSchema),
});

export const SectorSummaryListSchema = z.array(SectorSummarySchema);

// VARIETY
export const CodeDescriptionSchema = z.object({
    code: z.string(),
    description: z.string(),
    visible: z.boolean(),
});

export type CodeDescriptionModel = z.infer<typeof CodeDescriptionSchema>;

export const VarietySummarySchema = z.object({
    variety: CodeDescriptionSchema,
    num_parcel: z.number(),
    num_units: z.number(),
    total_unit_area_sqm: z.number(),
    anomalies_list: z.array(AnomalySearchSchema),
});

export const VarietySummaryListSchema = z.array(VarietySummarySchema);

// APTITUDES
export const DoIgtSchema = z.object({
    id: z.number(),
    code: z.string(),
    description: z.string(),
    category_code: z.string(),
    category_description: z.string(),
    name_code: z.string(),
    name_description: z.string(),
    visible: z.boolean(),
});

export const VarietySchema = z.object({
    code: z.string(),
    description: z.string(),
    visible: z.boolean(),
});

export const BlockSchema = z.object({
    id: z.number().nullish(),
    sector_id: z.number().nullish(),
    description: z.string().nullish(),
    short_descr: z.string().nullish(),
    block_code: z.string().nullish(),
    srs: z.string().nullish(),
    geom: z.string().nullish(),
    world_geom: z.string().nullish(),
});

export const FruitUnitSchema = z.object({
    id: z.number(),
    land_cover_id: z.number(),
    area_sqm: z.number(),
    variety: CodeDescriptionSchema,
    code: z.string().nullable(),
    planting_day: z.string(),
    planting_day_precision: z.string(),
    eradicate_day: z.string().nullable(),
    planting_type: CodeDescriptionSchema.nullable(),
    distance_on_the_row_cm: z.number().nullable(),
    distance_between_rows_cm: z.number().nullable(),
    plants_number: z.number().nullable(),
    farming_form: CodeDescriptionSchema.nullable(),
    irrigation: CodeDescriptionSchema.nullable(),
    altitude_above_sea_level: z.number().nullable(),
    quality_system: CodeDescriptionSchema.nullable(),
    protection_structure: CodeDescriptionSchema.nullable(),
    last_update: z.coerce.date().nullable(),
    unit_type: z.string().nullish(), // set client side
    last_update_user: z.string().nullable(),
    anomalies: AnomalySearchSchema.array().nullable(),
});

export const PaginatedFruitUnitListSchema =
    getNextPagedResultsSchema(FruitUnitSchema);
export type PaginatedFruitUnitListModel = z.infer<
    typeof PaginatedFruitUnitListSchema
>;

export const FruitUnitListSchema = z.array(FruitUnitSchema);

export const ErrorSchema = z.object({
    anomalies_list: z.array(AnomalySearchSchema),
    error: z.string().nullable(),
});

export const ParcelSchema = z.object({
    id: z.number(),
    parcel: z.string(),
    day_from: z.string(),
    day_to: z.string(),
    total_land_covers_area_sqm: z.number().nullish(),
    area_sqm: z.number(),
    block: BlockSchema,
    sector: SectorSchema,
    source_code: z.string().nullish(),
    sde_code: z.string().nullish(),
    landcovers_list: z.array(
        z.object({
            id: z.number(),
            code: z.string(),
            description: z.string().nullish(),
            parcel_id: z.number(),
            day_from: z.string(),
            day_to: z.string(),
            area_sqm: z.number(),
            fruit_units: z.array(FruitUnitSchema),
        }),
    ),
    anomalies: ErrorSchema.nullable(),
});

export const PaginatedParcelListSchema =
    getNextPagedResultsSchema(ParcelSchema);
export type PaginatedParcelListModel = z.infer<
    typeof PaginatedParcelListSchema
>;

export const ParcelLandLinkSchema = z.object({
    id: z.number(),
    partyId: z.number(),
    titleType: z.object({
        id: z.number().nullable(),
        code: z.string().nullable(),
        dayToReq: z.boolean().nullable(),
        i18nCode: z.string().nullable(),
    }),
    titleTypePerc: z.number().nullable(),
    parcel: z.object({
        id: z.number().nullable(),
        parcel: z.string().nullable(),
        dayFrom: z.string().nullable(),
        dayTo: z.string().nullable(),
        srs: z.string().nullable().nullable(),
        areaSqm: z.number().nullable(),
        block: z.object({
            id: z.number().nullable(),
            description: z.string().nullable(),
            shortDescr: z.string().nullable(),
            blockCode: z.string().nullable(),
        }),
        sector: z.object({
            id: z.number().nullable(),
            description: z.string().nullable(),
            shortDescr: z.string().nullable(),
            sectorCode: z.string().nullable(),
        }),
        geom: z.string().nullable().nullable(),
        worldGeom: z.string().nullable().nullable(),
    }),
    dayFrom: z.string().nullable(),
    dayTo: z.string().nullable(),
    anomalyCount: z.number().nullable(),
});

export const PaginatedParcelLandLinkListSchema =
    getNextPagedResultsSchema(ParcelLandLinkSchema);
export type PaginatedParcelLandLinkListModel = z.infer<
    typeof PaginatedParcelLandLinkListSchema
>;

export const AuthorizationSummarySchema = z.object({
    authorizationType: z.string(),
    authorizationTypeCode: z.string(),
    counter: z.number(),
    authorizationSurface: z.number(),
    plantedSurface: z.number(),
    transferredSurface: z.number(),
    residualSurface: z.number(),
});

export const AuthorizationSummaryListSchema = z.array(
    AuthorizationSummarySchema,
);

export const AuthorizationSchema = z.object({
    /**
     * Id
     */
    id: z.number(),
    /**
     * Id Autorizzazione
     */
    authorizationId: z.number(),
    /**
     *  Id Autorizzazione Nazionale
     */
    nationalAuthorizationId: z.string().nullable(),
    /**
     * Tipo autorizzazione
     */
    authorizationType: z.string(),
    // NOT IN USE authorizationTypeCode: z.string(),
    /**
     * Id Autorizzazione di provenienza
     */
    surfaceAuthorizationId: z.number().nullable(),
    /**
     * Id Autorizzazione Nazionale di provenienza
     */
    surfaceNationalAuthorizationId: z.string().nullable(),
    /**
     * Id Diritto Provenienza
     */
    rightOriginId: z.number().nullable(),
    // NOT IN USE authorizationIstatRp: z.string().nullable(),
    /**
     * Regione di provenienza
     */
    denoAuthorizationIstatRp: z.string().nullable(),
    // NOT IN USE authorizationIstatR: z.string(),
    /**
     * Regione di riferimento
     */
    denoAuthorizationIstatR: z.string().nullable(),
    // NOT IN USE authorizationIstatP: z.string().nullable(),
    /**
     * Provincia di riferimento
     */
    denoProv: z.string().nullable(),
    /**
     * Sup. autorizzazione (ha)
     */
    surfaceAuthorization: z.number(),
    /**
     * Sup. impiantata (ha)
     */
    plantedSurface: z.number(),
    /**
     * Sup. trasferita (ha)
     */
    transferredSurface: z.number(),
    /**
     * Sup. residua (ha)
     */
    residualSurface: z.number(),
    /**
     * Identificativo protocollo
     */
    protocolId: z.number().nullable(),
    /**
     * Data protocollo
     */
    protocolDt: z.string().nullable(),
    /**
     * Tipologia domanda
     */
    questionType: z.string().nullable(),
    /**
     * Data conversione
     */
    conversionDt: z.coerce.date().nullable(),
    /**
     * Id domanda
     */
    questionId: z.number().nullable(),
    /**
     * Note
     */
    note: z.string().nullable(),
    /**
     * Data rilascio
     */
    dtStart: z.coerce.date(),
    /**
     *  Data scadenza
     */
    dtEnd: z.coerce.date(),
});

export const AuthorizationsListSchema = z.array(AuthorizationSchema);

export const QuotaSummarySchema = z.object({
    wineQuota: z.string(),
    assignedQuota: z.number(),
    usedQuota: z.number(),
    revokedQuota: z.number(),
    residualQuote: z.number(),
});

export const PaginatedQuotaSummaryListSchema =
    getNextPagedResultsSchema(QuotaSummarySchema);
export type PaginatedQuotaSummaryListModel = z.infer<
    typeof PaginatedQuotaSummaryListSchema
>;

export const QuotaSummaryListSchema = z.array(QuotaSummarySchema);

//TYPES
export type FruitUnitModel = z.infer<typeof FruitUnitSchema>;
export type FruitUnitListModel = z.infer<typeof FruitUnitListSchema>;

export type SectorSummary = z.infer<typeof SectorSummarySchema>;
export type SectorSummaryList = z.infer<typeof SectorSummaryListSchema>;

export type VarietySummary = z.infer<typeof VarietySummarySchema>;
export type VarietySummaryList = z.infer<typeof VarietySummaryListSchema>;

export type Parcel = z.infer<typeof ParcelSchema>;
export type ParcelLandLink = z.infer<typeof ParcelLandLinkSchema>;

export type AuthorizationSummary = z.infer<typeof AuthorizationSummarySchema>;
export type AuthorizationSummaryList = z.infer<
    typeof AuthorizationSummaryListSchema
>;
export type Authorization = z.infer<typeof AuthorizationSchema>;
export type AuthorizationsList = z.infer<typeof AuthorizationsListSchema>;

export type QuotaSummary = z.infer<typeof QuotaSummarySchema>;
export type QuotaSummaryList = z.infer<typeof QuotaSummaryListSchema>;

export enum FruitUnitStatusEnum {
    YES = "S",
    NO = "N",
}
