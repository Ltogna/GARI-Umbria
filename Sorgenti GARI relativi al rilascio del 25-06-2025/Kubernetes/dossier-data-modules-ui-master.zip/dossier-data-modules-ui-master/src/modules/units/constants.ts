export const UNIT_ID = "unit";
export const UNIT_CONFIG_KEY = "units";
export const PAGE_SIZE = 20;
