import type { NavigationGuard, RouteRecordRaw } from "vue-router";
import { UnitRouteName } from "@/modules/units/models/routes";
import { useUnitConfigStore } from "../stores/unitConfig";
import { usePartyStore } from "../stores/party";
import { usePermissionsStore } from "../stores/unitPermissions";
import { getParty } from "@/resources/api/party-public-api";

const beforeEnter: NavigationGuard = async (to) => {
    await useUnitConfigStore().fetchConfig();
    try {
        const partyId = +to.params.partyId;
        if (!partyId) {
            throw "cuaa_not_found";
        }
        const party = await getParty(+to.params.partyId);
        if (!party) {
            throw "cuaa_not_found";
        }

        usePartyStore().party = party;

        const cuaa = party.code;
        if (!cuaa) {
            throw "cuaa_not_found";
        }
        // Get permissions
        await usePermissionsStore().fetchPermissions();
        return true;
    } catch (error) {
        console.error(error);
        if (typeof error === "string") {
            console.log(error);
            return {
                name: "NotFound",
                // preserve current path and remove the first char to avoid the target URL starting with `//`
                params: { pathMatch: to.path.substring(1).split("/") },
                // preserve existing query and hash if any
                query: { ...to.query, error },
                hash: to.hash,
            };
        }
        return {
            name: "NotFound",
            // preserve current path and remove the first char to avoid the target URL starting with `//`
            params: { pathMatch: to.path.substring(1).split("/") },
            // preserve existing query and hash if any
            query: to.query,
            hash: to.hash,
        };
    }
};

const unitRoutes: RouteRecordRaw[] = [
    {
        path: "/vine-register/",
        beforeEnter,
        children: [
            {
                path: "",
                name: UnitRouteName.VINE_REGISTER,
                props(to) {
                    return { partyId: Number(to.query.partyId) };
                },
                component: () =>
                    import("@/modules/units/views/VineRegister.vue"),
            },
            {
                path: ":partyId/",
                redirect: {
                    name: UnitRouteName.VINE_PARCEL_SUMMARY,
                    replace: true,
                },
                component: () =>
                    import("@/modules/units/views/VineRegisterManagement.vue"),
                children: [
                    {
                        path: "parcels/",
                        children: [
                            {
                                path: "summary/",
                                name: UnitRouteName.VINE_PARCEL_SUMMARY,
                                component: () =>
                                    import(
                                        "@/modules/units/components/parcel/ViteParcelSummary.vue"
                                    ),
                            },
                            {
                                path: "list/",
                                name: UnitRouteName.VINE_PARCELS,
                                component: () =>
                                    import(
                                        "@/modules/units/components/parcel/VineParcelsList.vue"
                                    ),
                            },
                            {
                                path: "detail/:parcelId/",
                                name: UnitRouteName.VINE_PARCELS_DETAIL,
                                component: () =>
                                    import(
                                        "@/modules/units/components/parcel/VineParcelDetail.vue"
                                    ),
                            },
                            {
                                path: "detail/:parcelId/conducting-detail",
                                name: UnitRouteName.VINE_PARCEL_CONDUCTING_DETAIL,
                                component: () =>
                                    import(
                                        "@/modules/units/components/parcel/VineConductingDetail.vue"
                                    ),
                            },
                            {
                                path: ":parcelId/land-cover/:landCoverId/units/detail/:vineUnitId",
                                name: UnitRouteName.VINE_UNIT_DETAIL,
                                component: () =>
                                    import(
                                        "@/modules/units/components/parcel/VineUnitDetail.vue"
                                    ),
                            },
                        ],
                    },
                    {
                        path: "authorizations/",
                        children: [
                            {
                                path: "summary/",
                                name: UnitRouteName.VINE_AUTHORIZATIONS_SUMMARY,
                                component: () =>
                                    import(
                                        "@/modules/units/components/authorizations/AuthorizationsSummary.vue"
                                    ),
                            },
                            {
                                path: ":authTypeCode/",
                                name: UnitRouteName.VINE_AUTHORIZATIONS_LIST,
                                component: () =>
                                    import(
                                        "@/modules/units/components/authorizations/AuthorizationsList.vue"
                                    ),
                            },
                            {
                                path: ":authTypeCode/new",
                                name: UnitRouteName.VINE_AUTHORIZATION_NEW,
                                component: () =>
                                    import(
                                        "@/modules/units/components/authorizations/AuthorizationNew.vue"
                                    ),
                            },
                            {
                                path: ":authTypeCode/edit/:authorizationId",
                                name: UnitRouteName.VINE_AUTHORIZATION_EDIT,
                                component: () =>
                                    import(
                                        "@/modules/units/components/authorizations/AuthorizationNew.vue"
                                    ),
                            },
                            {
                                path: ":authTypeCode/detail/:authorizationId",
                                name: UnitRouteName.VINE_AUTHORIZATION_DETAIL,
                                component: () =>
                                    import(
                                        "@/modules/units/components/authorizations/AuthorizationDetail.vue"
                                    ),
                            },
                            {
                                path: ":authTypeCode/detail/:authorizationId/authorization-to-region",
                                name: UnitRouteName.VINE_AUTHORIZATION_TO_REGION,
                                component: () =>
                                    import(
                                        "@/modules/units/components/authorizations/AuthorizationToRegion.vue"
                                    ),
                            },
                            {
                                path: ":authTypeCode/detail/:authorizationId/origin",
                                name: UnitRouteName.VINE_AUTHORIZATION_ORIGIN,
                                component: () =>
                                    import(
                                        "@/modules/units/components/authorizations/AuthorizationOrigin.vue"
                                    ),
                            },
                            {
                                path: ":authTypeCode/detail/:authorizationId/linked-application",
                                name: UnitRouteName.VINE_AUTHORIZATION_LINKED_QUESTION,
                                component: () =>
                                    import(
                                        "@/modules/units/components/authorizations/AuthorizationLinkedQuestion.vue"
                                    ),
                            },
                            {
                                path: ":authTypeCode/detail/:authorizationId/authorization-to-cuaa",
                                name: UnitRouteName.VINE_AUTHORIZATION_TO_CUAA,
                                component: () =>
                                    import(
                                        "@/modules/units/components/authorizations/AuthorizationToCUAA.vue"
                                    ),
                            },
                            {
                                path: ":authTypeCode/detail/:authorizationId/authorization-expiration-date",
                                name: UnitRouteName.VINE_AUTHORIZATION_EDIT_EXPIRATION_DATE,
                                component: () =>
                                    import(
                                        "@/modules/units/components/authorizations/AuthorizationExpirationDate.vue"
                                    ),
                            },                            
                        ],
                        async beforeEnter() {
                            return useUnitConfigStore().authorizationsEnabled;
                        },
                    },
                    {
                        path: "aptitudes/",
                        children: [
                            {
                                path: "summary/",
                                name: UnitRouteName.VINE_APTITUDES_SUMMARY,
                                component: () =>
                                    import(
                                        "@/modules/units/components/aptitudes/AptitudesSummary.vue"
                                    ),
                            },
                            {
                                path: ":doIgtCode/",
                                name: UnitRouteName.VINE_APTITUDES_UV_LIST,
                                component: () =>
                                    import(
                                        "@/modules/units/components/aptitudes/AptitudesUvList.vue"
                                    ),
                            },
                            {
                                path: ":doIgtCode/:parcelId/:landCoverId/:vineUnitId/detail/:vineAptitudeId",
                                name: UnitRouteName.VINE_APTITUDES_DETAIL,
                                component: () =>
                                    import(
                                        "@/modules/units/components/aptitudes/AptitudeDetail.vue"
                                    ),
                            },
                        ],
                    },
                    {
                        path: "quotas/",
                        name: UnitRouteName.VINE_QUOTAS_SUMMARY,
                        component: () =>
                            import(
                                "@/modules/units/components/quotas/QuotasSummary.vue"
                            ),
                    },
                    {
                        path: "applications/",
                        name: UnitRouteName.VINE_APPLICATIONS_SUMMARY,
                        component: () =>
                            import(
                                "@/modules/units/components/applications/ApplicationsSummary.vue"
                            ),
                    },
                ],
            },
        ],
    },

    {
        path: "/fruit-register/",
        beforeEnter,
        children: [
            {
                path: "",
                name: UnitRouteName.FRUIT_REGISTER,
                props(to) {
                    return { partyId: Number(to.query.partyId) };
                },
                component: () =>
                    import("@/modules/units/views/FruitRegister.vue"),
            },
            {
                path: ":partyId/",
                redirect: {
                    name: UnitRouteName.FRUIT_PARCEL_SUMMARY,
                    replace: true,
                },
                component: () =>
                    import("@/modules/units/views/FruitRegisterManagement.vue"),
                children: [
                    {
                        path: "parcels/",
                        children: [
                            {
                                path: "summary/",
                                name: UnitRouteName.FRUIT_PARCEL_SUMMARY,
                                component: () =>
                                    import(
                                        "@/modules/units/components/parcel/FruitParcelSummary.vue"
                                    ),
                            },
                            {
                                path: "list/",
                                name: UnitRouteName.FRUIT_PARCELS,
                                component: () =>
                                    import(
                                        "@/modules/units/components/parcel/FruitParcelsList.vue"
                                    ),
                            },
                            {
                                path: "detail/:parcelId/",
                                name: UnitRouteName.FRUIT_PARCELS_DETAIL,
                                component: () =>
                                    import(
                                        "@/modules/units/components/parcel/FruitParcelDetail.vue"
                                    ),
                            },
                            {
                                path: "detail/:parcelId/conducting-detail",
                                name: UnitRouteName.FRUIT_PARCEL_CONDUCTING_DETAIL,
                                component: () =>
                                    import(
                                        "@/modules/units/components/parcel/FruitConductingDetail.vue"
                                    ),
                            },
                            {
                                path: ":parcelId/land-cover/:landCoverId/units/detail/:fruitUnitId",
                                name: UnitRouteName.FRUIT_UNIT_DETAIL,
                                component: () =>
                                    import(
                                        "@/modules/units/components/parcel/FruitUnitDetail.vue"
                                    ),
                            },
                        ],
                    },
                ],
            },
        ],
    },

    {
        path: "/olive-register/",
        beforeEnter,
        children: [
            {
                path: "",
                name: UnitRouteName.OLIVE_REGISTER,
                props(to) {
                    return { partyId: Number(to.query.partyId) };
                },
                component: () =>
                    import("@/modules/units/views/OliveRegister.vue"),
            },
            {
                path: ":partyId/",
                redirect: {
                    name: UnitRouteName.OLIVE_PARCEL_SUMMARY,
                    replace: true,
                },
                component: () =>
                    import("@/modules/units/views/OliveRegisterManagement.vue"),
                children: [
                    {
                        path: "parcels/",
                        children: [
                            {
                                path: "summary/",
                                name: UnitRouteName.OLIVE_PARCEL_SUMMARY,
                                component: () =>
                                    import(
                                        "@/modules/units/components/parcel/OliveParcelSummary.vue"
                                    ),
                            },
                            {
                                path: "list/",
                                name: UnitRouteName.OLIVE_PARCELS,
                                component: () =>
                                    import(
                                        "@/modules/units/components/parcel/OliveParcelsList.vue"
                                    ),
                            },
                            {
                                path: "detail/:parcelId/",
                                name: UnitRouteName.OLIVE_PARCELS_DETAIL,
                                component: () =>
                                    import(
                                        "@/modules/units/components/parcel/OliveParcelDetail.vue"
                                    ),
                            },
                            {
                                path: "detail/:parcelId/conducting-detail",
                                name: UnitRouteName.OLIVE_PARCEL_CONDUCTING_DETAIL,
                                component: () =>
                                    import(
                                        "@/modules/units/components/parcel/OliveConductingDetail.vue"
                                    ),
                            },
                            {
                                path: ":parcelId/land-cover/:landCoverId/units/detail/:oliveUnitId",
                                name: UnitRouteName.OLIVE_UNIT_DETAIL,
                                component: () =>
                                    import(
                                        "@/modules/units/components/parcel/OliveUnitDetail.vue"
                                    ),
                            },
                        ],
                    },
                ],
            },
        ],
    },
];

export default unitRoutes;
