import type { NavigationGuard, RouteRecordRaw } from "vue-router";
import { usePartyStore } from "../stores/party";
import { getParty } from "@/resources/api/party-public-api";
import { HeirsRouteName } from "../models/routes";
import { useConfigStore } from "../stores/config";

const beforeEnter: NavigationGuard = async (to) => {
    try {
        await useConfigStore().fetchConfig();
        const partyId = +(to.params.partyId ?? to.query.partyId);
        if (!partyId) {
            throw "cuaa_not_found";
        }
        const party = await getParty(partyId);
        if (!party) {
            throw "cuaa_not_found";
        }

        usePartyStore().party = party;

        const cuaa = party.code;
        if (!cuaa) {
            throw "cuaa_not_found";
        }

        return true;
    } catch (error) {
        console.error(error);
        if (typeof error === "string") {
            return {
                name: "NotFound",
                // preserve current path and remove the first char to avoid the target URL starting with `//`
                params: { pathMatch: to.path.substring(1).split("/") },
                // preserve existing query and hash if any
                query: { ...to.query, error },
                hash: to.hash,
            };
        }
        return {
            name: "NotFound",
            // preserve current path and remove the first char to avoid the target URL starting with `//`
            params: { pathMatch: to.path.substring(1).split("/") },
            // preserve existing query and hash if any
            query: to.query,
            hash: to.hash,
        };
    }
};

const heirsRoutes: RouteRecordRaw[] = [
    {
        path: "/heirs/",
        beforeEnter,
        children: [
            {
                path: "",
                name: HeirsRouteName.HEIRS_HOME,
                props(to) {
                    return {
                        partyId: Number(to.query.partyId),
                        partyCode: to.query.partyCode,
                    };
                },
                component: () => import("../views/HeirsView.vue"),
            },
            // {
            //     path: ":partyId/",
            //     redirect: {
            //         name: HeirsRouteName.HEIRS_EDIT,
            //         replace: true,
            //     },
            //     component: () => import("../views/heirsLayout.vue"),
            //     children: [
            //         {
            //             path: "edit/",
            //             name: HeirsRouteName.HEIRS_EDIT,
            //             component: () => import("../views/heirsEdit.vue"),
            //         },
            //     ],
            // },
        ],
    },
];

export default heirsRoutes;
