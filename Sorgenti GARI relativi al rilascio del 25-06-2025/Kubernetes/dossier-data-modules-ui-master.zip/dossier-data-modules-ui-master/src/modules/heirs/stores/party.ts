import { defineStore } from "pinia";
import type { PartyModel } from "@/models/party";

interface State {
    party: PartyModel | null;
}

const initialState: Readonly<State> = {
    party: null,
};
const state: State = structuredClone(initialState);

export const usePartyStore = defineStore("partyStore", {
    state: () => state,
    getters: {
        getCuaa(state): string | null {
            return state.party?.code ?? null;
        },
    },

    actions: {
        $reset() {
            this.$state = structuredClone(initialState);
        },
    },
});
