import { getConfigurationByKey } from "@/resources/api/config";
import { defineStore } from "pinia";
import { Configuration, templateOptions } from "../models/config";
import { template, type TemplateExecutor } from "lodash";

interface State {
    configFetched: boolean;
    _config: Configuration;
}

const initialState: Readonly<State> = {
    configFetched: false,
    _config: {},
};
const state: State = structuredClone(initialState);

export const useConfigStore = defineStore("config", {
    state: () => state,
    getters: {
        partyRegistryDirectoryUrl: (state): TemplateExecutor => {
            return template(
                state._config.PARTY_REGISTRY_DIRECTORY_URL ??
                    `/party-registry/{tenant}/public/v1/parties?taxOrVat={query}`,
                templateOptions,
            );
        },
        partyRegexFiscalCode: (state): RegExp => {
            return new RegExp(
                state._config.PARTY_REGEX_FISCAL_CODE ??
                    `^[A-Z]{6}[0-9]{2}[A-EHLMPRST][0-9]{2}[A-Z][0-9A-Z]{3}[A-Z]$`,
                "i",
            );
        },
    },

    actions: {
        async fetchConfig(forceFetch?: boolean) {
            if (this.configFetched && !forceFetch) return;
            const response = await getConfigurationByKey("heir");
            if (response) {
                try {
                    const _conf = new Map<string, unknown>();
                    for (const [key, value] of Object.entries(
                        response.configuration,
                    )) {
                        _conf.set(key.toLocaleUpperCase(), value);
                    }
                    this._config = Configuration.parse(
                        Object.fromEntries(_conf),
                    );
                    this.configFetched = true;
                } catch (error) {
                    console.error("Dev - parsing error:" + error);
                    return;
                }
            }
        },

        $reset() {
            this.$state = structuredClone(initialState);
        },
    },
});
