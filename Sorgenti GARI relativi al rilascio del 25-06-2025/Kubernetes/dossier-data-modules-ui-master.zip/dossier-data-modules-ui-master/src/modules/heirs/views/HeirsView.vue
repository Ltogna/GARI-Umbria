<script setup lang="ts">
import AlertMessage from "@/components/AlertMessage.vue";
import { DDM_MODULE_ID } from "@/constants";
import { HEIRS_ID } from "../constants";
import { useMessageStore } from "@/stores/messageStore";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import {
    computed,
    defineAsyncComponent,
    defineProps,
    onMounted,
    ref,
} from "vue";
import { useI18n } from "vue-i18n";
import { VueQueryDevtools } from "@tanstack/vue-query-devtools";
import type { Heir } from "../models/heir";
import usePermissions from "@/composables/usePermissions";

const props = defineProps<{
    partyId: number;
    partyCode: string;
}>();

enum ViewsEnum {
    HeirsEditForm = "HeirsEditForm",
    HeirsSummary = "HeirsSummary",
}

const currentView = ref(ViewsEnum.HeirsSummary);
const currentHeir = ref<Heir | null>(null);

async function importForm() {
    return import(
        /* webpackChunkName: "heirs-edit-form" */
        `../components/HeirsEditForm.vue`
    );
}
async function importSummary() {
    return import(
        /* webpackChunkName: "heirs-summary" */
        `../components/HeirsSummary.vue`
    );
}

const HeirsEditForm = defineAsyncComponent(importForm);
const HeirsSummary = defineAsyncComponent(importSummary);

const { t } = useI18n();
const messageStore = useMessageStore();
const { canEditHeir } = usePermissions();

const isReadOnly = computed(() => {
    return !canEditHeir;
});

onMounted(async () => {
    if (props.partyId && !isNaN(props.partyId)) {
    } else {
        messageStore.setMessage({
            message: t(
                `${DDM_MODULE_ID}.errors.unable_to_retrieve_party_registry_id`,
            ),
            level: "danger",
        });
    }
});

function getViewTitle() {
    const baseTitle = t(`${HEIRS_ID}.heir`, 2);

    if (currentView.value === ViewsEnum.HeirsEditForm) {
        const key = currentHeir.value
            ? `${HEIRS_ID}.heir_summary`
            : `${HEIRS_ID}.add_heir`;
        return `${baseTitle} - ${t(key)}`;
    }

    return baseTitle;
}

function goToDetail(heir: Heir) {
    currentHeir.value = heir;
    currentView.value = ViewsEnum.HeirsEditForm;
}

function onGoToHeirsSummary() {
    currentView.value = ViewsEnum.HeirsSummary;
    currentHeir.value = null;
}
</script>
<template>
    <div class="mx-3 row units-module">
        <div class="mt-3 px-3 col-12">
            <h3 class="text-primary">
                <BiIcon icon="file-lines"></BiIcon>
                {{ getViewTitle() }}
            </h3>
        </div>
        <div class="mt-5 px-3 col-12">
            <AlertMessage
                v-model="messageStore.open"
                :level="messageStore.level"
                @close="messageStore.clearMessage()"
            >
                {{ messageStore.message }}
            </AlertMessage>

            <HeirsSummary
                v-if="currentView === ViewsEnum.HeirsSummary"
                :party-code="partyCode"
                :is-read-only="isReadOnly"
                @load-edit-form="importForm"
                @go-to-detail="goToDetail"
                @goto-edit-form="currentView = ViewsEnum.HeirsEditForm"
            />

            <HeirsEditForm
                v-else-if="currentView === ViewsEnum.HeirsEditForm"
                :party-code="partyCode"
                :is-read-only="isReadOnly"
                :heir="currentHeir"
                @goto-heirs-summary="onGoToHeirsSummary"
                @load-heirs-summary="importSummary"
            />
        </div>
    </div>
    <VueQueryDevtools />
</template>
