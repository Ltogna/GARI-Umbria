import { dossierDataModulesHTTPClient } from "@/resources/api/http";
import {
    HeirSchema,
    UpdatePayloadSchema,
    type CreatePayloadSchema,
    type HeirList,
} from "../models/heir";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { makePaginateListSchema } from "@/modules/payment-methods/models/bankAccounts";
import { useMessageStore } from "@/stores/messageStore";
import { ZodError } from "zod";

export const heirsListGetAll = async (partyCode: string): Promise<HeirList> => {
    const list: HeirList = [];

    let nextKey: string | null = null;
    do {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const params: any = nextKey ? { nextKey: nextKey } : {};

        const res = await dossierDataModulesHTTPClient.getJson(
            makePaginateListSchema(HeirSchema),
            `/api-priv/v1/heirs-methods/parties/${encodeURIComponent(partyCode)}/heirs`,
            { params },
        );

        if (res.errorType !== ErrorType.NONE) {
            if (
                res.errorType === ErrorType.OTHER &&
                res.err instanceof ZodError
            )
                console.error(res.err);
            else useMessageStore().handleApiErrorAndShowAlert(res);
            return [];
        }

        list.push(...res.data.records);
        nextKey = res.data.nextKey;
    } while (nextKey);

    return list;
};

export async function createHeir(
    partyCode: string,
    payload: CreatePayloadSchema,
) {
    const res = await dossierDataModulesHTTPClient.postJson(
        HeirSchema,
        `/api-priv/v1/heirs-methods/parties/${encodeURIComponent(partyCode)}/heirs`,
        payload,
    );

    if (res.errorType !== ErrorType.NONE) {
        if (res.errorType === ErrorType.OTHER && res.err instanceof ZodError)
            console.error(res.err);
        else useMessageStore().handleApiErrorAndShowAlert(res);
        throw res;
    }

    return res.data;
}

export async function updateHeir(
    partyCode: string,
    heirId: number,
    payload: UpdatePayloadSchema,
) {
    const res = await dossierDataModulesHTTPClient.putJson(
        HeirSchema,
        `/api-priv/v1/heirs-methods/parties/${partyCode}/heirs/${heirId}`,
        payload,
    );

    if (res.errorType !== ErrorType.NONE) {
        if (res.errorType === ErrorType.OTHER && res.err instanceof ZodError)
            console.error(res.err);
        else useMessageStore().handleApiErrorAndShowAlert(res);
        throw res;
    }

    return res.data;
}

export async function deleteHeir(partyCode: string, heirId: number) {
    const res = await dossierDataModulesHTTPClient.delete(
        `/api-priv/v1/heirs-methods/parties/${encodeURIComponent(partyCode)}/heirs/${heirId}`,
    );

    if (res.errorType !== ErrorType.NONE) {
        if (res.errorType === ErrorType.OTHER && res.err instanceof ZodError)
            console.error(res.err);
        else useMessageStore().handleApiErrorAndShowAlert(res);
        throw res;
    }

    return res;
}
