import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { http } from "../../../resources/api/http";
import { getUserData } from "@abaco/safe-rest/src/sso2";
import { useConfigStore } from "../stores/config";
import { PartyListSchema } from "@/models/party";

export const getParties = async (query: string) => {
    const user = getUserData(); // Get user data

    const url = useConfigStore().partyRegistryDirectoryUrl({
        tenant: user?.tenant,
        query: encodeURIComponent(query),
    });

    const response = await http.getJson(PartyListSchema, url);

    if (response.errorType !== ErrorType.NONE) {
        throw response;
    }
    return response.data.records ?? [];
};
