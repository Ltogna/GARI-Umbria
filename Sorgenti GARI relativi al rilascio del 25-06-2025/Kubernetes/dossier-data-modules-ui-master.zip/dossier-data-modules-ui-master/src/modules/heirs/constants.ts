export const HEIRS_ID = "heirs";
export const HEIRS_REGEX_KEY = "heirs_regex_validation";
export const PAGE_SIZE = 6;
