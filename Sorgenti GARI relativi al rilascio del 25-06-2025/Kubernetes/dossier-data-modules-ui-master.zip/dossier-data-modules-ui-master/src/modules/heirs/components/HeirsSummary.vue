<script setup lang="ts">
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { ref } from "vue";
import { useI18n } from "vue-i18n";
import { HEIRS_ID } from "../constants";
import type { Heir, HeirList } from "../models/heir";
import HDocumentList from "./documentList/HDocumentList.vue";
import HeirsList from "./HeirsList.vue";

defineProps<{
    partyCode: string;
    isReadOnly: boolean;
}>();

const emits = defineEmits<{
    gotoEditForm: [];
    loadEditForm: [];
    goToDetail: [heir: HeirList[number]];
}>();

const { t } = useI18n();

const documentListRef = ref<InstanceType<typeof HDocumentList> | null>(null);

function forwardNewDocument() {
    documentListRef.value?.newDocument();
}
</script>

<template>
    <HeirsList
        :partyCode="partyCode"
        :is-read-only="isReadOnly"
        @go-to-detail="(heir: Heir) => emits('goToDetail', heir)"
    />

    <HDocumentList
        ref="documentListRef"
        :party-code="partyCode"
        :is-read-only="isReadOnly"
    />

    <!-- Action buttons -->
    <div class="mt-4 d-flex gap-4 justify-content-center">
        <BiButton
            v-if="!isReadOnly"
            color="primary"
            is-outlined
            @mouseover="emits('loadEditForm')"
            @click="emits('gotoEditForm')"
        >
            {{ t(`${HEIRS_ID}.add_heir`) }}
        </BiButton>

        <BiButton
            v-if="!isReadOnly"
            :is-outlined="true"
            color="primary"
            @click="forwardNewDocument"
        >
            {{ t(`${HEIRS_ID}.add_attachment`, 2) }}
        </BiButton>
    </div>
</template>
