<script setup lang="ts">
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import { toTypedSchema } from "@vee-validate/zod";
import { useForm } from "vee-validate";
import { computed, onMounted, ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import { HEIRS_ID } from "../constants";
import SearchPartyForm from "./SearchPartyForm.vue";
import BiToggle from "@abaco/bootstrap-italia-components/src/components/form/BiToggle.vue";
import { useFormErrors } from "../composables/useFormErrors";
import {
    CreateFormSchema,
    CreatePayloadSchema,
    type Heir,
} from "../models/heir";
import { useCreateHeirMutation } from "../composables/useCreateHeirMutation";
import { useMessageStore } from "@/stores/messageStore";
import { convertToDate } from "@/utils/utils";
import { useDdmStore } from "@/stores/ddmStore";
import { useUpdateHeirMutation } from "../composables/useUpdateHeirMutation";
import { PartyResponseSchema, type PartyModel } from "@/models/party";

const props = defineProps<{
    partyCode: string;
    isReadOnly: boolean;
    heir: Heir | null;
}>();
const emits = defineEmits<{
    gotoHeirsSummary: [];
    loadHeirsSummary: [];
}>();

const { t } = useI18n();
const { printError } = useFormErrors();
const ddmStore = useDdmStore();
const messageStore = useMessageStore();

const party = ref<PartyModel | null>(null);
const { mutate: createHeir } = useCreateHeirMutation(() => props.partyCode);
const { mutate: updateHeir } = useUpdateHeirMutation(
    () => props.partyCode,
    () => props.heir?.heirId || -1,
);

const { handleSubmit, resetForm, defineField, errors, submitCount } = useForm({
    validationSchema: toTypedSchema(CreateFormSchema),
    initialValues: {
        successionDate: new Date().toISOString(),
    },
});

const [successionDate] = defineField("successionDate");
const [hasDelegation] = defineField("hasDelegation");
const [heirCuaa] = defineField("heirCuaa");

const isEditMode = computed(() => !!props.heir);

const onSubmit = handleSubmit((values) => {
    const parsed = CreatePayloadSchema.parse(values);

    ddmStore.incrementLoadingQueue();
    if (isEditMode.value) {
        updateHeir(
            {
                hasDelegation: parsed.hasDelegation,
                successionDate: parsed.successionDate,
            },
            {
                onSuccess() {
                    messageStore.setMessage({
                        message: t(`${HEIRS_ID}.success_edit_heir`),
                        level: "success",
                        autoDismiss: true,
                    });
                    ddmStore.decrementLoadingQueue();
                    emits("gotoHeirsSummary");
                },
                onSettled() {
                    ddmStore.decrementLoadingQueue();
                },
            },
        );
    } else {
        createHeir(parsed, {
            onSuccess() {
                messageStore.setMessage({
                    message: t(`${HEIRS_ID}.success_create_heir`),
                    level: "success",
                    autoDismiss: true,
                });
                ddmStore.decrementLoadingQueue();
                emits("gotoHeirsSummary");
            },
            onSettled() {
                ddmStore.decrementLoadingQueue();
            },
        });
    }
});

const onReset = () => {
    resetForm();
    emits("gotoHeirsSummary");
};

watch(party, () => {
    heirCuaa.value = party.value?.code ?? undefined;
});

onMounted(() => {
    if (props.heir) {
        party.value = PartyResponseSchema.parse({
            code: props.heir.cuaa,
            firstName: props.heir.firstName,
            lastName: props.heir.lastName,
            birthDate: props.heir.birthDate,
            taxCode: props.heir.taxCode,
        });

        resetForm({
            values: {
                heirCuaa: props.heir?.heirCuaa ?? undefined,
                hasDelegation: props.heir?.hasDelegation ?? false,
                successionDate: props.heir?.successionDate
                    ? convertToDate(props.heir.successionDate)?.toISOString()
                    : undefined,
            },
        });
    }
});
</script>

<template>
    <div>
        <!-- Zilocchi Mario ZLCMRO10D10E999I - DLCDMN53H28B077H - BTALRN75E52D014D -->
        <BiInput
            v-if="isEditMode"
            :label="t(`${HEIRS_ID}.tax_code`)"
            :disabled="true"
            :model-value="party?.taxCode"
            class="mb-2"
        />
        <SearchPartyForm
            v-else
            v-model="party"
            :form-errors="printError(submitCount, errors.heirCuaa)"
            class="mb-3"
        />
        <form @submit.prevent="onSubmit" @reset.prevent="onReset" class="row">
            <div class="col-12 mb-2">
                <BiInput
                    :label="t(`${HEIRS_ID}.first_name`)"
                    :disabled="true"
                    :model-value="party?.firstName"
                />
            </div>
            <div class="col-12 mb-2">
                <BiInput
                    :label="t(`${HEIRS_ID}.last_name`)"
                    :disabled="true"
                    :model-value="party?.lastName"
                />
            </div>
            <div class="col-12 mb-3">
                <BiDatepicker
                    :model-value="party?.birthDate"
                    :is-disabled="true"
                    :label="t(`${HEIRS_ID}.birth_date`)"
                />
            </div>
            <div class="col-12 mb-2">
                <BiToggle
                    v-model="hasDelegation"
                    :label="t(`${HEIRS_ID}.delegation`)"
                    :is-disabled="isReadOnly"
                />
            </div>
            <div class="col-12 mb-2">
                <BiDatepicker
                    v-model="successionDate"
                    :label="t(`${HEIRS_ID}.succession_date`)"
                    :is-disabled="isReadOnly"
                    :errors="printError(submitCount, errors.successionDate)"
                />
            </div>
            <div class="col-12 d-flex mt-5">
                <BiButton
                    type="reset"
                    color="primary"
                    class="me-2"
                    is-outlined
                    @mouseover="emits('loadHeirsSummary')"
                >
                    {{
                        isEditMode
                            ? t(`${HEIRS_ID}.back`)
                            : t(`${HEIRS_ID}.cancel`)
                    }}
                </BiButton>
                <BiButton
                    v-if="!isReadOnly"
                    type="submit"
                    color="success"
                    @mouseover="emits('loadHeirsSummary')"
                >
                    {{
                        isEditMode
                            ? t(`${HEIRS_ID}.edit`)
                            : t(`${HEIRS_ID}.save`)
                    }}
                </BiButton>
            </div>
        </form>
    </div>
</template>
