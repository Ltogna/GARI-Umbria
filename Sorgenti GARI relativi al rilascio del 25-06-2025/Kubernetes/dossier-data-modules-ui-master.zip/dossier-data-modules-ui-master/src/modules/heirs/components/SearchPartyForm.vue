<script setup lang="ts">
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import { toTypedSchema } from "@vee-validate/zod";
import { useForm } from "vee-validate";
import { computed, ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import { z } from "zod";
import { usePartyMutation } from "../composables/usePartyMutation";
import { HEIRS_ID } from "../constants";
import { requiredMessage } from "../models/heir";
import { useConfigStore } from "../stores/config";
import type { PartyModel } from "@/models/party";

const { t } = useI18n();
const configStore = useConfigStore();
const isSearching = ref(false);
const err: Set<string> = new Set();


const Schema = z.object({
    regCode: z
        .string({
            required_error: t(requiredMessage),
            message: t(requiredMessage),
        })
        .trim()
        .regex(configStore.partyRegexFiscalCode, {
            message: t(`${HEIRS_ID}.errors.tax_code_not_valid`),
        }),
});

const props = defineProps<{ formErrors?: string[] }>();

const model = defineModel<PartyModel | null>({ default: null });

const { handleSubmit, resetForm, defineField, errors, submitCount } = useForm({
    validationSchema: toTypedSchema(Schema),
});

const [regCode] = defineField("regCode");

const mutation = usePartyMutation();

const onSubmit = handleSubmit((values) => {
    isSearching.value = true;
    mutation.mutate(values.regCode, {
        onSuccess: (data) => {
            if (data && data.length > 0) {
                err.clear();
                model.value = data[0];
            } else if (data && data.length === 0) {
                err.clear();
                err.add(t(`${HEIRS_ID}.errors.no_party_found`));
            } else {
                model.value = null;
            }
        },
        onError: (error) => {
            console.error("Error:", error);
        },
        onSettled: () => {
            isSearching.value = false;
        },
    });
});
const onReset = () => {
    resetForm();
};

const regCodeErrors = computed<string[]>(() => {
    if (!isSearching.value) {
        if (submitCount.value > 0 && errors.value.regCode) {
            err.add(errors.value.regCode);
        } else if (props.formErrors && props.formErrors.length > 0) {
            props.formErrors.forEach((error) => err.add(error));
        }
    }

    return [...err];
});

watch(
    () => regCode.value,
    () => {
        err.clear();
    },
    { immediate: true },
);
</script>

<template>
    <form
        @submit.prevent="onSubmit"
        @reset.prevent="onReset"
        novalidate
        class="row"
    >
        <div class="col-12 d-flex flex-nowrap" :class="regCodeErrors.length ? 'align-items-center' : 'align-items-baseline'">
            <div class="flex-grow-1">
                <BiInput
                    :label="t(`${HEIRS_ID}.tax_code`)"
                    v-model="regCode"
                    :errors="regCodeErrors"
                    :default-return-if-not-value="'undefined'"
                />
            </div>
            <div class="ms-2">
                <BiButton
                    type="submit"
                    color="primary"
                    is-outlined
                >
                    {{ t(`${HEIRS_ID}.search`) }}
                </BiButton>
            </div>
        </div>
    </form>
</template>
