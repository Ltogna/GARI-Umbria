<template>
    <!-- if overflow, mount BiTooltip -->
    <BiTooltip
        v-if="overflow"
        :key="resolvedText"
        :title="resolvedText"
        :placement="placement"
        extraClasses="d-inline-block text-truncate text-dark"
        :extraCss="`max-width:${maxWidth};`"
    >
        {{ resolvedText }}
    </BiTooltip>

    <!-- otherwise mount truncated span -->
    <span
        v-else
        ref="wrapper"
        class="d-inline-block text-truncate"
        :style="`max-width:${maxWidth};`"
    >
        {{ resolvedText }}
    </span>
</template>

<script setup lang="ts">
import { ref, onMounted, watch, nextTick } from "vue";
import BiTooltip from "@abaco/bootstrap-italia-components/src/components/BiTooltip/BiTooltip.vue";

const props = withDefaults(
    defineProps<{
        /** text to show/truncate */
        text: string | Promise<string>;
        /** max width, e.g. "200px" or "100%" */
        maxWidth?: string;
        /** prop for BiTooltip */
        placement?: "top" | "bottom" | "left" | "right";
    }>(),
    {
        maxWidth: "100%",
        placement: "top",
    },
);

const wrapper = ref<HTMLElement | null>(null);
const overflow = ref<boolean>(false);
const resolvedText = ref<string>("");

async function resolveText() {
    try {
        if (props.text instanceof Promise) {
            resolvedText.value = await props.text;
        } else {
            resolvedText.value = props.text;
        }
    } catch (error) {
        console.error("Error resolving text:", error);
        resolvedText.value = "";
    }

    nextTick(() => {
        if (wrapper.value) {
            overflow.value =
                wrapper.value.scrollWidth > wrapper.value.clientWidth;
        }
    });
}

watch(
    () => props.text,
    async () => {
        await resolveText();
    },
    { immediate: true },
);

onMounted(() => {
    // Detecting overflowing
    if (wrapper.value) {
        overflow.value = wrapper.value.scrollWidth > wrapper.value.clientWidth;
    }
});
</script>
