<script setup lang="ts">
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import DocumentBuilder from "@abaco/dynamic-documents/src/components/DocumentBuilder.vue";
import type { FileUploadConfig } from "@abaco/dynamic-documents/src/resources/composables/useFiles";
import type { DocumentDataDocSchemaType } from "@abaco/dynamic-documents/src/resources/models/document";
import { getUserData } from "@abaco/safe-rest/src/sso2";
import { useI18n } from "vue-i18n";
import { computed, onMounted, ref, watch } from "vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import type {
    DocumentModel,
    DynamicDocumentResponse,
    NewDynamicDocumentModel,
} from "../../models/dynamicDocument";
import { useDynamicDocumentStore } from "@/stores/dynamicDocumentStore";
import { HEIRS_ID } from "../../constants";

const { t, locale } = useI18n({});
const dynamicDocumentStore = useDynamicDocumentStore();

const props = withDefaults(
    defineProps<{
        multiple?: boolean;
        mode: ModalModeEnum;
        partyCode: string;
        isReadOnly: boolean;
        modelValue?: DynamicDocumentResponse;
    }>(),
    { multiple: false },
);

enum ModalModeEnum {
    NEW = "NEW",
    EDIT = "EDIT",
    DELETE = "DELETE",
}

const emit = defineEmits<{
    (e: "form-reset"): void;
    (e: "create-document", value: NewDynamicDocumentModel): void;
    (e: "update-document", value: DocumentModel): void;
    (e: "delete-document", value: DocumentModel): void;
}>();

const docDefinitionCode = ref<string>("");
const docDefinition = computed(
    () => dynamicDocumentStore.getDocumentDefinition,
);
const formValues = ref<DocumentDataDocSchemaType>();
const isValid = ref(false);
const language = ref(locale.value);
const showErrors = ref(false);
const formConfirmBtn = computed(() =>
    props.mode === "EDIT"
        ? t(`${HEIRS_ID}.update_confirm`)
        : t(`${HEIRS_ID}.save`),
);

watch(
    () => props.modelValue,
    (value) => {
        formValues.value = { ...formValues.value, fields: { ...value?.data } };
    },
    { immediate: true },
);

watch(
    () => docDefinitionCode.value,
    async () => {
        if (props.mode !== "NEW") {
            const docTypeField = docDefinition.value?.fieldSets[0].fields.find(
                (el: { code: string }) => el.code === "documentType",
            );
            docTypeField && (docTypeField.readonly = true);
        }
    },
    {},
);

watch(
    () => formValues.value?.fields?.documentType,
    (val) => {
        val && (docDefinitionCode.value = val as string);

        // reset form value when documentType dropdown changes
        const tempFields = { ...formValues.value?.fields };
        for (const key in tempFields) {
            key !== "documentType" &&
                delete tempFields[key as keyof typeof tempFields];
        }
        formValues.value &&
            formValues.value.fields &&
            (formValues.value.fields = tempFields);
    },
);

onMounted(async () => {
    docDefinitionCode.value = docDefinition.value?.code ?? "";

    formValues.value = {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        fields: props.modelValue?.data ? (props.modelValue?.data as any) : null,
    };
});

function formReset() {
    emit("form-reset");
}
function formConfirm() {
    const modalActions = {
        NEW: () => emit("create-document", mapCreateRequest()),
        EDIT: () => emit("update-document", mapRequest()),
        DELETE: () => onDeleteDocument(),
    };

    showErrors.value = !isValid.value;

    if (isValid.value) {
        modalActions[props.mode]();
    }
}
function mapCreateRequest() {
    return {
        defCode: docDefinition.value?.code,
        doc: {
            ...formValues.value,
        },
    } as NewDynamicDocumentModel;
}
function mapRequest() {
    if (!formValues.value) {
        return {} as DocumentModel;
    }
    return {
        ...props.modelValue,
        data: {
            ...(formValues.value as Record<string, unknown>),
        },
    } as DocumentModel;
}
function onDeleteDocument() {
    emit("delete-document", mapRequest());
}

const fileUploadConfigComputed = computed<FileUploadConfig | undefined>(() => {
    const bucketName = docDefinition.value?.bucketName;
    return {
        bucketName: bucketName as string,
        readUrl: `/dossier-data-modules/${getUserData()?.tenant}/api-priv/v1/heirs-methods/parties/${props.partyCode}/documents/${props.modelValue?.documentId}/attachments`,
        tenantId: getUserData()?.tenant as string,
    };
});
</script>
<template>
    <div
        v-if="dynamicDocumentStore.getLoading"
        class="d-flex row justify-content-center mb-3"
    >
        <div class="d-flex col-2 justify-content-center px-0">
            <BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
        </div>
    </div>
    <template v-else>
        <DocumentBuilder
            v-if="docDefinition"
            v-model="formValues"
            v-model:lang="language"
            :schema="docDefinition"
            :show-errors="showErrors"
            doc-title-hide
            :file-upload-config="fileUploadConfigComputed"
            :readonly="mode === 'DELETE' || isReadOnly"
            @update:valid="(value) => (isValid = value)"
            @update:model-value="
                (value: any) => {
                    formValues = value;
                }
            "
        />
        <div v-if="!isReadOnly" class="text-center mt-4 pb-5">
            <BiButton
                @click="formReset"
                is-outlined
                color="primary"
                class="btn-me"
            >
                {{ t(`${HEIRS_ID}.cancel`) }}
            </BiButton>
            <BiButton
                v-if="mode === 'NEW' || mode === 'EDIT'"
                @click="formConfirm"
                color="success"
            >
                {{ formConfirmBtn }}
            </BiButton>
            <BiButton
                v-if="mode === 'DELETE'"
                @click="onDeleteDocument"
                color="danger"
            >
                {{ t(`${HEIRS_ID}.delete_document`) }}
            </BiButton>
        </div>
    </template>
</template>
