<script setup lang="ts">
import { computed, ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { HEIRS_ID } from "../constants";
import { convertToDate } from "@/utils/utils";
import useDateFormat from "@/composables/useDateFormat";
import type { Heir, HeirList } from "../models/heir";
import { useDeleteHeirMutation } from "../composables/useDeleteHeirMutation";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import { useHerisListGetQuery } from "../composables/useHeirsList";
import { useDdmStore } from "@/stores/ddmStore";
import { useMessageStore } from "@/stores/messageStore";

const props = defineProps<{
    partyCode: string;
    isReadOnly: boolean;
}>();

const emits = defineEmits<{
    gotoEditForm: [];
    loadEditForm: [];
    goToDetail: [heir: HeirList[number]];
}>();

const { t } = useI18n();
const { dateFormat } = useDateFormat();
const ddmStore = useDdmStore();
const messageStore = useMessageStore();

const heirToDelete = ref<Heir | null>(null);
const showDeleteHeirModal = computed(() => !!heirToDelete.value);

const heirId = computed(() => heirToDelete.value?.heirId ?? 0);

const { data: heirsList, isFetching: isFetchingHeirs } = useHerisListGetQuery(
    props.partyCode,
);
const { mutate: deleteHeir } = useDeleteHeirMutation(props.partyCode, heirId);

function handleDeleteHeir() {
    if (!heirToDelete.value) return;
    deleteHeir(undefined, {
        onSuccess() {
            heirToDelete.value = null;
            messageStore.setMessage({
                message: t(`${HEIRS_ID}.success_delete_heir`),
                level: "success",
                autoDismiss: true,
            });
        },
    });
}

watch(
    () => isFetchingHeirs.value,
    (isFetching) => {
        if (isFetching) {
            ddmStore.incrementLoadingQueue();
        } else {
            ddmStore.decrementLoadingQueue();
        }
    },
    { immediate: true },
);
</script>

<template>
    <div class="container">
        <h4 class="mb-3">{{ t(`${HEIRS_ID}.heirs_list`) }}</h4>
        <BiTable
            v-if="heirsList?.length"
            class="table-responsive"
            extraTableClasses="table-head-bg"
            isResponsive
        >
            <template v-slot:head>
                <tr class="bg-light text-start">
                    <th>{{ t(`${HEIRS_ID}.name`) }}</th>
                    <th>{{ t(`${HEIRS_ID}.surname`) }}</th>
                    <th>{{ t(`${HEIRS_ID}.tax_code`) }}</th>
                    <th>{{ t(`${HEIRS_ID}.presence_file`) }}</th>
                    <th>{{ t(`${HEIRS_ID}.delegation`) }}</th>
                    <th>{{ t(`${HEIRS_ID}.succession_date`) }}</th>
                    <!-- Actions -->
                    <th></th>
                </tr>
            </template>

            <template v-slot:body>
                <template v-if="heirsList?.length">
                    <tr v-for="(heir, index) in heirsList" :key="index">
                        <td>{{ heir.firstName }}</td>
                        <td>{{ heir.lastName }}</td>
                        <td>{{ heir.taxCode }}</td>
                        <td>
                            {{
                                heir.hasDossier
                                    ? t(`${HEIRS_ID}.yes`)
                                    : t(`${HEIRS_ID}.no`)
                            }}
                        </td>
                        <td>
                            {{
                                heir.hasDelegation
                                    ? t(`${HEIRS_ID}.yes`)
                                    : t(`${HEIRS_ID}.no`)
                            }}
                        </td>
                        <td>
                            {{
                                heir.successionDate
                                    ? dateFormat(
                                          convertToDate(heir.successionDate),
                                      )
                                    : ""
                            }}
                        </td>
                        <!-- Actions -->
                        <td class="text-end">
                            <BiButton
                                :color="!isReadOnly ? 'success' : 'primary'"
                                is-outlined
                                is-icon
                                class="p-2"
                                @mouseover="emits('loadEditForm')"
                                @click="emits('goToDetail', heir)"
                            >
                                <BiIcon
                                    :icon="!isReadOnly ? 'arrow-right' : 'eye'"
                                />
                            </BiButton>
                            <BiButton
                                v-if="!isReadOnly"
                                color="danger"
                                is-outlined
                                is-icon
                                class="ms-2 p-2"
                                @click="heirToDelete = heir"
                            >
                                <BiIcon icon="trash" />
                            </BiButton>
                        </td>
                    </tr>
                </template>
            </template>
        </BiTable>
        <div v-else class="card-body pt-3">
            <BiAlert :title="t(`${HEIRS_ID}.no_data`)"></BiAlert>
        </div>
    </div>

    <BiModal
        v-model="showDeleteHeirModal"
        :title="t(`${HEIRS_ID}.delete_heir`)"
        extraFooterClass="d-flex justify-content-center"
    >
        <template #body> {{ t(`${HEIRS_ID}.message_delete_heir`) }} </template>
        <template #footer>
            <BiButton color="primary" is-outlined @click="heirToDelete = null">
                {{ t(`${HEIRS_ID}.close`) }}
            </BiButton>
            <BiButton color="danger" is-outlined @click="handleDeleteHeir()">
                {{ t(`${HEIRS_ID}.delete`) }}
            </BiButton>
        </template>
    </BiModal>
</template>
