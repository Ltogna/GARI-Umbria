<script setup lang="ts">
import { ref, computed, onMounted, watch, nextTick } from "vue";
import { useI18n } from "vue-i18n";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import useDateFormat from "@/composables/useDateFormat";
import { getUUID } from "@abaco/bootstrap-italia-components/src/utilities/index";
import DynamicDocumentForm from "./HDynamicDocumentForm.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import type {
    DocumentModel,
    DocumentTypeModel,
    DynamicDocumentResponse,
    NewDynamicDocumentModel,
} from "../../models/dynamicDocument";
import { useDynamicDocumentStore } from "@/stores/dynamicDocumentStore";
import type { DocumentDataDocSchemaType } from "@abaco/dynamic-documents/src/resources/models";
import { HEIRS_ID } from "../../constants";
import OverflowTooltip from "../OverflowTooltip.vue";

const props = defineProps<{
    partyCode: string;
    isReadOnly: boolean;
}>();

// Exposes the method to make it accessible to the parent
defineExpose({
    newDocument,
});

const { t } = useI18n({});
const { getColor } = useColors();
const { dateFormat } = useDateFormat();

const dynamicDocumentStore = useDynamicDocumentStore();
const documentTypeList = computed(
    () => dynamicDocumentStore.getDocumentTypeList,
);
const currentDocument = ref<DynamicDocumentResponse>();
const showModal = ref<boolean>(false);
const docType = ref<DocumentTypeModel | null>(null);
const forceRenderTableKey = ref<number>(0);

enum ModalModeEnum {
    NEW = "NEW",
    EDIT = "EDIT",
    DELETE = "DELETE",
}
const modalMode = ref(ModalModeEnum.NEW);

const fieldDefinitions = computed(() =>
    dynamicDocumentStore.getDocumentTypeList &&
    dynamicDocumentStore.getDocumentTypeList[0] &&
    dynamicDocumentStore.getDocumentTypeList[0].summaryFieldDefinitions
        ? dynamicDocumentStore.getDocumentTypeList[0].summaryFieldDefinitions
        : [],
);

const modalTitle = computed(() => {
    if (modalMode.value === ModalModeEnum.NEW) {
        return [t(`${HEIRS_ID}.new_document`, 2)].join(" ");
    }
    if (modalMode.value === ModalModeEnum.EDIT) {
        return [t(`${HEIRS_ID}.edit_document`)].join(" ");
    }
    if (modalMode.value === ModalModeEnum.DELETE) {
        return [t(`${HEIRS_ID}.delete_document`)].join(" ");
    }
    return "";
});

async function formatField(fieldCode: string, doc: DocumentModel) {
    const fieldValue = doc?.data[fieldCode];

    const fieldType =
        doc?.summaryFieldDefinitions?.find(
            (field: { code: string }) => field.code === fieldCode,
        )?.fieldType || "string";

    const lookup = dynamicDocumentStore.getLookupDetails.find(
        (lookup) => lookup.code === fieldCode,
    );
    if (lookup)
        return dynamicDocumentStore.getAttachmentDescription(
            fieldValue,
            lookup.detailsUrl,
        );

    if (fieldCode === "documentType") {
        const documentType = dynamicDocumentStore.getDocumentTypeList?.find(
            (item) => item?.definitionCode === fieldValue,
        );

        if (documentType) {
            docType.value = documentType;
            return documentType.definitionCodeI18n;
        }
    }

    if (fieldType === "date") {
        return dateFormat(new Date(fieldValue), undefined, false);
    }
    return fieldValue || "";
}

function dismissModal() {
    showModal.value = false;
    currentDocument.value = undefined;
}

async function loadMore() {
    await dynamicDocumentStore.loadDocumentList(props.partyCode, false);
}

// pencil icon, trash icon and 'new document' button
async function newDocument() {
    await dynamicDocumentStore.loadDocumentDefinition(
        dynamicDocumentStore.getDocumentTypeList?.[0]?.definitionCode ?? "",
    );
    currentDocument.value = undefined;
    modalMode.value = ModalModeEnum.NEW;
    showModal.value = true;
}

async function editDocument(document: DocumentModel) {
    await dynamicDocumentStore.loadDocumentDefinition(
        document?.definitionCode ?? "",
    );
    await dynamicDocumentStore.loadDocument(
        props.partyCode,
        document?.documentId ?? 0,
    );
    currentDocument.value = dynamicDocumentStore.getDocument;
    modalMode.value = ModalModeEnum.EDIT;
    showModal.value = true;
}

async function deleteDocument(document: DocumentModel) {
    await dynamicDocumentStore.loadDocumentDefinition(
        document?.definitionCode ?? "",
    );
    await dynamicDocumentStore.loadDocument(
        props.partyCode,
        document?.documentId ?? 0,
    );
    currentDocument.value = dynamicDocumentStore.getDocument;
    modalMode.value = ModalModeEnum.DELETE;
    showModal.value = true;
}

// emitted from DynamicDocumentForm component
async function onCreateDocument(documentData: NewDynamicDocumentModel) {
    await dynamicDocumentStore.createDocument(props.partyCode, documentData);
    await dynamicDocumentStore.loadDocumentList(props.partyCode, true);
    showModal.value = false;
}

async function onUpdateDocument(documentData: DocumentModel) {
    await dynamicDocumentStore.updateDocument(
        props.partyCode,
        documentData?.documentId?.toString() ?? "",
        (documentData?.data as DocumentDataDocSchemaType) ?? {},
    );
    await dynamicDocumentStore.loadDocumentList(props.partyCode, true);
    showModal.value = false;
}

async function onDeleteDocument(documentData: DocumentModel) {
    await dynamicDocumentStore.deleteDocument(
        props.partyCode,
        documentData?.documentId?.toString() ?? "",
    );
    await dynamicDocumentStore.loadDocumentList(props.partyCode, true);
    showModal.value = false;
}

watch(
    () => documentTypeList.value,
    (list) =>
        list?.forEach(
            (type) =>
                type?.definitionCode &&
                dynamicDocumentStore.mapLookupDetails(type.definitionCode),
        ),
    { immediate: true },
);

onMounted(async () => {
    await dynamicDocumentStore.loadDocumentList(props.partyCode, true);
    await dynamicDocumentStore.loadDocumentTypeList(props.partyCode);

    nextTick(() => {
        forceRenderTableKey.value++;
    });
});
</script>
<template>
    <div class="container">
        <h4 class="mb-3">{{ t(`${HEIRS_ID}.attached_documents`) }}</h4>

        <BiTable
            v-if="
                dynamicDocumentStore.getDocumentList &&
                dynamicDocumentStore.getDocumentList.count
            "
            :key="forceRenderTableKey"
            class="table-responsive"
            extraTableClasses="table-head-bg"
            is-row-hover
            isResponsive
        >
            <template v-slot:head>
                <tr class="bg-light" :class="getColor('text', 'secondary')">
                    <th
                        scope="col"
                        v-for="(item, i) in fieldDefinitions"
                        :key="i"
                        :class="{ 'text-center': item.fieldType === 'file' }"
                        style="vertical-align: middle"
                    >
                        {{ item.description }}
                    </th>
                    <th></th>
                </tr>
            </template>
            <template v-slot:body>
                <tr
                    v-for="(doc, trIndex) in dynamicDocumentStore
                        .getDocumentList?.records ?? []"
                    :key="trIndex"
                >
                    <td
                        v-for="(field, tdIndex) in doc?.summaryFieldDefinitions"
                        :key="tdIndex"
                        :class="{
                            'text-center':
                                field.fieldType === 'file' &&
                                (doc?.data as any)[field.code],
                        }"
                        style="max-width: 200px"
                    >
                        <BiIcon
                            v-if="
                                field.fieldType === 'file' &&
                                (doc?.data as any)[field.code]
                            "
                            icon="check"
                        />
                        <template v-else>
                            <OverflowTooltip
                                :text="formatField(field.code, doc)"
                                max-width="100%"
                                placement="top"
                            />
                        </template>
                    </td>
                    <td class="text-end align-middle">
                        <BiButton
                            :color="!isReadOnly ? 'success' : 'primary'"
                            is-outlined
                            is-icon
                            class="p-2"
                            @click="editDocument(doc)"
                            :isDisabled="dynamicDocumentStore.getLoading"
                        >
                            <BiIcon :icon="!isReadOnly ? 'pencil' : 'eye'" />
                        </BiButton>
                        <BiButton
                            v-if="!isReadOnly"
                            color="danger"
                            is-outlined
                            is-icon
                            class="ms-2 p-2"
                            @click="deleteDocument(doc)"
                            :isDisabled="dynamicDocumentStore.getLoading"
                        >
                            <BiIcon icon="trash" />
                        </BiButton>
                    </td>
                </tr>
            </template>
        </BiTable>
        <div v-else class="card-body pt-3">
            <BiAlert :title="t(`${HEIRS_ID}.no_data`)"></BiAlert>
        </div>
        <div
            class="d-flex justify-content-center mb-4"
            v-if="
                dynamicDocumentStore.getDocumentList.nextKey &&
                !dynamicDocumentStore.getLoading
            "
        >
            <BiButton :is-outlined="true" color="primary" @click="loadMore">
                {{ t(`${HEIRS_ID}.load_more`) }}
            </BiButton>
        </div>

        <BiModal
            :disabled-teleport="true"
            size="lg"
            :id="getUUID()"
            v-model="showModal"
            :title="modalTitle"
        >
            <template #body>
                <DynamicDocumentForm
                    v-if="showModal"
                    v-model="currentDocument"
                    multiple
                    :mode="modalMode"
                    :party-code="props.partyCode"
                    :is-read-only="isReadOnly"
                    @form-reset="dismissModal"
                    @create-document="onCreateDocument"
                    @update-document="onUpdateDocument"
                    @delete-document="onDeleteDocument"
                />
            </template>
        </BiModal>
    </div>
</template>

<style lang="scss">
table {
    width: 100%;
    table-layout: fixed;
}

@media screen and (max-width: 992px) {
    .first-col {
        width: 100% !important;
    }
    .second-col {
        width: 100% !important;
    }
    .third-col {
        width: 100% !important;
    }
    .fourth-col {
        width: 100% !important;
    }
}

.first-col {
    word-wrap: break-word;
    width: 30%;
}

.second-col {
    word-wrap: break-word;
    width: 30%;
}

.third-col {
    word-wrap: break-word;
    width: 30%;
}

.fourth-col {
    word-wrap: break-word;
    width: 10%;
}
</style>
