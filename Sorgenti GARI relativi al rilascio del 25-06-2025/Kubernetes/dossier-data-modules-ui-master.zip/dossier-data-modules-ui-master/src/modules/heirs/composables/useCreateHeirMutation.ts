import type {
    GenericResponseError,
    HttpResponseError,
} from "@abaco/safe-rest/src/HTTPClient";
import { useMutation, useQueryClient } from "@tanstack/vue-query";
import { toValue, type MaybeRefOrGetter } from "vue";
import { createHeir } from "../api/heir";
import type { HeirSchema } from "../models/heir";
import type { CreatePayloadSchema } from "../models/heir";

export const useCreateHeirMutation = (partyCode: MaybeRefOrGetter<string>) => {
    const queryClient = useQueryClient();
    return useMutation<
        HeirSchema,
        HttpResponseError | GenericResponseError,
        MaybeRefOrGetter<CreatePayloadSchema>
    >({
        mutationFn: (query) => createHeir(toValue(partyCode), toValue(query)),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ["herisList"] });
        },
    });
};
