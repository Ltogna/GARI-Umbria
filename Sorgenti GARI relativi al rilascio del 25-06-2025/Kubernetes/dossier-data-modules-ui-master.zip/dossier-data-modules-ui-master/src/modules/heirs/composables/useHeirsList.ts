import { useQuery } from "@tanstack/vue-query";
import { heirsListGetAll } from "../api/heir";

export const useHerisListGetQuery = (partyCode: string) => {
    return useQuery({
        queryKey: ["herisList"],
        queryFn: () => heirsListGetAll(partyCode),
        enabled: true,
    });
};
