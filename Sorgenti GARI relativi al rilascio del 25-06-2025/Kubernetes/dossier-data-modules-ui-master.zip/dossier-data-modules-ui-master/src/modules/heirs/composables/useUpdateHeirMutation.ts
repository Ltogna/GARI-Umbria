import type {
    GenericResponseError,
    HttpResponseError,
} from "@abaco/safe-rest/src/HTTPClient";
import { useMutation, useQueryClient } from "@tanstack/vue-query";
import { toValue, type MaybeRefOrGetter } from "vue";
import { HeirSchema, UpdatePayloadSchema } from "../models/heir";
import { updateHeir } from "../api/heir";

export const useUpdateHeirMutation = (
    partyCode: MaybeRefOrGetter<string>,
    heirId: MaybeRefOrGetter<number>,
) => {
    const queryClient = useQueryClient();
    return useMutation<
        HeirSchema,
        HttpResponseError | GenericResponseError,
        MaybeRefOrGetter<UpdatePayloadSchema>
    >({
        mutationFn: (query) =>
            updateHeir(toValue(partyCode), toValue(heirId), toValue(query)),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ["herisList"] });
        },
    });
};
