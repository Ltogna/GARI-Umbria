import type {
    GenericResponseError,
    HttpResponseError,
} from "@abaco/safe-rest/src/HTTPClient";
import { useMutation } from "@tanstack/vue-query";
import { toValue, type MaybeRefOrGetter } from "vue";
import { getParties } from "../api/party";
import type { PartyModel } from "@/models/party";

export const usePartyMutation = () => {
    return useMutation<
        PartyModel[],
        HttpResponseError | GenericResponseError,
        MaybeRefOrGetter<string>
    >({
        mutationFn: (query) => getParties(toValue(query)),
    });
};
