import type {
    GenericResponseError,
    HttpResponseError,
} from "@abaco/safe-rest/src/HTTPClient";
import { useQuery } from "@tanstack/vue-query";
import { toValue, type MaybeRefOrGetter } from "vue";
import { getParties } from "../api/party";
import type { PartyModel } from "@/models/party";

export const useParties = (query: MaybeRefOrGetter<string>) => {
    return useQuery<PartyModel[], HttpResponseError | GenericResponseError>({
        queryKey: ["parties", query],
        queryFn: () => getParties(toValue(query)),
        enabled: () => !!toValue(query),
        refetchOnWindowFocus: false,
        retry: false,
        staleTime: 1000 * 60 * 5, // 5 minutes
    });
};
