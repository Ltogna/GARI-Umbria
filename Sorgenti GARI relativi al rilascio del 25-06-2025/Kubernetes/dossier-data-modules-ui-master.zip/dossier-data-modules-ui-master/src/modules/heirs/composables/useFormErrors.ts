import { toValue, type MaybeRefOrGetter } from "vue";
import { useI18n } from "vue-i18n";

export function useFormErrors() {
    const { te, t } = useI18n();

    function printError(
        submitCout: MaybeRefOrGetter<number>,
        data?: string,
    ): string[] {
        const errors = new Set<string>();
        if (data && toValue(submitCout) > 0) {
            errors.add(te(data) ? t(data) : data);
        }

        return [...errors];
    }

    return { printError };
}
