import { useMutation, useQueryClient } from "@tanstack/vue-query";
import { toValue, type MaybeRefOrGetter } from "vue";
import { deleteHeir } from "../api/heir";

export const useDeleteHeirMutation = (
    partyCode: MaybeRefOrGetter<string>,
    heirId: MaybeRefOrGetter<number>,
) => {
    const queryClient = useQueryClient();
    return useMutation({
        mutationFn: () => deleteHeir(toValue(partyCode), toValue(heirId)),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ["herisList"] });
        },
    });
};
