import { z } from "zod";
import { ISODateToAbsoluteDate } from "./util";
import { HEIRS_ID } from "../constants";
import { formatDate } from "@/utils/utils";

export const requiredMessage = `${HEIRS_ID}.errors.required`;

export const errorsMessages = {
    required_error: requiredMessage,
    message: requiredMessage,
};

export const CreateFormSchema = z.object({
    successionDate: z.string(errorsMessages).default(formatDate(new Date())),
    hasDelegation: z.boolean(errorsMessages).default(false),
    heirCuaa: z.string(errorsMessages).min(1, { message: requiredMessage }),
});
export type CreateFormSchema = z.infer<typeof CreateFormSchema>;

export const CreatePayloadSchema = CreateFormSchema.extend({
    successionDate: ISODateToAbsoluteDate,
});

export type CreatePayloadSchema = z.infer<typeof CreatePayloadSchema>;

export const UpdatePayloadSchema = z.object({
    hasDelegation: z.boolean(errorsMessages),
    successionDate: ISODateToAbsoluteDate,
});
export type UpdatePayloadSchema = z.infer<typeof UpdatePayloadSchema>;

export const SuccessionTypeSchema = z.object({
    code: z.string().nullish(),
    description: z.string().nullish(),
});

export const HeirSchema = z.object({
    cuaa: z.string(),
    heirId: z.number(),
    successionType: SuccessionTypeSchema.nullish(),
    heirCuaa: z.string().nullish(),
    firstName: z.string().nullish(),
    lastName: z.string().nullish(),
    taxCode: z.string().nullish(),
    birthDate: z.string().nullish(),
    successionDate: z.string().nullish(),
    hasDossier: z.boolean().nullish(),
    hasDelegation: z.boolean().nullish(),
});

export type HeirSchema = z.infer<typeof HeirSchema>;

export const HeirListSchema = z.array(HeirSchema);

export type Heir = z.infer<typeof HeirSchema>;
export type HeirList = z.infer<typeof HeirListSchema>;
