import type { TemplateOptions } from "lodash";
import { z } from "zod";

export const templateOptions: TemplateOptions = {
    interpolate: /\{([\s\S]+?)\}/g,
};

export const Configuration = z.object({
    PARTY_REGISTRY_DIRECTORY_URL: z.string().nullish(),
    PARTY_REGEX_FISCAL_CODE: z.string().nullish(),
});

export type Configuration = z.infer<typeof Configuration>;
