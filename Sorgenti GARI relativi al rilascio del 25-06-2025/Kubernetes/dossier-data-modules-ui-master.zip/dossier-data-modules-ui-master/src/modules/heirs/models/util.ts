import { format, isValid, parseISO } from "date-fns";
import { z } from "zod";

/**
 * Accepts a `yyyy-MM-dd` date string, an ISO timestamp string,
 * a Date instance, or a numeric timestamp, and returns a `yyyyMMdd` string.
 */
export const ISODateToAbsoluteDate = z.preprocess((arg) => {
    if (typeof arg === "string") {
        const isoPattern =
            /^\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?)?$/;
        if (isoPattern.test(arg)) {
            const dt = parseISO(arg);
            if (isValid(dt)) {
                return format(dt, "yyyyMMdd");
            }
        }
        return arg.replace(/-/g, "");
    } else if (arg instanceof Date) {
        return format(arg, "yyyyMMdd");
    } else if (typeof arg === "number") {
        return format(new Date(arg), "yyyyMMdd");
    }
    return null;
}, z.string());
