import { z } from "zod";
import {
    DocumentDataDocSchema,
    DocumentLookupsSchema,
    metadataSchema,
    TranslationsSchema,
} from "@abaco/dynamic-documents/src/resources/models";
import {
    DocumentRestLookupsSchema,
    fieldSetSchema,
} from "@abaco/dynamic-documents/src/resources/models/documentSchema";

export const FieldTypeModelSchema = z.enum([
    "string",
    "long",
    "double",
    "date",
    "file",
]);

export const SummaryFieldDefinitionsModelSchema = z.object({
    code: z.string(),
    description: z.nullable(z.string()),
    fieldType: z.nullable(FieldTypeModelSchema),
});

export const DocumentTypeModelSchema = z.nullable(
    z.object({
        definitionCode: z.nullable(z.string()),
        definitionCodeI18n: z.nullable(z.string()),
        required: z.nullable(z.boolean()),
        docPresent: z.nullable(z.boolean()),
        multiple: z.nullable(z.boolean()),
        summaryFieldDefinitions: z.nullable(
            z.array(SummaryFieldDefinitionsModelSchema),
        ),
    }),
);
export const DocumentTypeListModelSchema = z.nullable(
    z.array(DocumentTypeModelSchema),
);

export const DocumentModelSchema = z.nullable(
    z.object({
        cuaa: z.string(),
        definitionCode: z.string(),
        documentId: z.number(),
        bucketName: z.string().nullable().optional(),
        data: z.record(z.any()),
        summaryFieldDefinitions: z.optional(
            z.nullable(z.array(SummaryFieldDefinitionsModelSchema)),
        ),
    }),
);
export const DocumentListModelSchema = z.object({
    nextKey: z.nullable(z.string()),
    records: z.array(DocumentModelSchema),
    count: z.nullable(z.number()),
});

export const LookupDetailsModelSchema = z.object({
    code: z.string(),
    detailsUrl: z.string(),
})

export const LookupDescriptionModelSchema = z.object({
    code: z.string(),
    description: z.string(),
});

export const DocumentDefinitionModelSchema = z.nullable(
    z.object({
        code: z.string(),
        version: z.string(),
        description: z.string(),
        title: TranslationsSchema,
        metadata: metadataSchema,
        fieldSets: z.array(fieldSetSchema),
        lookups: z.array(DocumentLookupsSchema).nullable().optional(),
        restLookups: z.array(DocumentRestLookupsSchema).nullable().optional(),
        bucketName: z.string().nullable().optional(),
        onSaveApiCalls: z.optional(z.nullable(z.array(z.any()))),
    }),
);

export const NewDynamicDocumentModelSchema = z.object({
    businessId: z.number(),
    label: z.string(),
    defCode: z.string(),
    doc: DocumentDataDocSchema,
});

export const DynamicDocumentResponseSchema = z.nullable(
    z.object({
        definitionCode: z.string(),
        documentId: z.number(),
        bucketName: z.string(),
        data: z.any(),
    }),
);

// TODO - CAPIRE SE SERVONO
export type FieldTypeModel = z.infer<typeof FieldTypeModelSchema>;
export type SummaryFieldDefinitionsModel = z.infer<
    typeof SummaryFieldDefinitionsModelSchema
>;
export type DocumentTypeModel = z.infer<typeof DocumentTypeModelSchema>;
export type DocumentTypeListModel = z.infer<typeof DocumentTypeListModelSchema>;
export type DocumentModel = z.infer<typeof DocumentModelSchema>;
export type DocumentListModel = z.infer<typeof DocumentListModelSchema>;
export type LookupDetailsModel = z.infer<typeof LookupDetailsModelSchema>;
export type LookupDescriptionModel = z.infer<typeof LookupDescriptionModelSchema>;
export type DocumentDefinitionModel = z.infer<
    typeof DocumentDefinitionModelSchema
>;
export type NewDynamicDocumentModel = z.infer<
    typeof NewDynamicDocumentModelSchema
>;
export type DynamicDocumentResponse = z.infer<
    typeof DynamicDocumentResponseSchema
>;
