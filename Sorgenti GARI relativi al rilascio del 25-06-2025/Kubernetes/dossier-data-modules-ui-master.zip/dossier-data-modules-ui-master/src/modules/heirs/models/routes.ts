export enum HeirsRouteName {
    HEIRS_HOME = `heirs:home`,
    HEIRS_EDIT = `heirs:edit`,
}
