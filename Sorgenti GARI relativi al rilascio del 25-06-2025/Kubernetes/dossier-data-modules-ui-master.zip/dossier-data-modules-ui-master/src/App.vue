<script setup lang="ts">
import { RouterView, useRoute } from "vue-router";
import { useMessageStore } from "./stores/messageStore";
import { watch } from "vue";
import LoaderComponent from "@/components/LoaderComponent.vue";

// Get the current route
const route = useRoute();
// Access the message store
const messageStore = useMessageStore();

/**
 * Watches for changes in the route's fullPath and closes the message store when it changes.
 */
watch(
    () => route.fullPath,
    () => {
        // Close the message store when the route changes
        messageStore.open = false;
    },
);
</script>

<template>
    <main class="dossier-data-modules">
        <!-- Loader component -->
        <LoaderComponent />
        <!-- Router view for displaying matched components -->
        <RouterView />
    </main>
</template>
