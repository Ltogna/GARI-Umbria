<template>
    <div class="my-5 container units-module">
        <BiCard :extra-classes="['card-bg', 'rounded', 'no-after']">
            <template #card-header>
                <div class="px-4 card-header">
                    <TopBar :title />
                </div>
            </template>
            <template #card-body>
                <div class="mt-1 row">
                    <div class="p-4 col-sm-12">
                        <BiAlert
                            v-if="error === 'party_not_found'"
                            is-error
                            :title="
                                t(`${DDM_MODULE_ID}.errors.party_not_found`)
                            "
                        />
                        <BiAlert
                            v-else-if="error === 'cuaa_not_found'"
                            is-error
                            :title="
                                t(`${DDM_MODULE_ID}.errors.party_not_found`)
                            "
                        />
                        <BiAlert
                            v-else
                            is-error
                            :title="t(`${DDM_MODULE_ID}.errors.generic`)"
                        />
                    </div>
                </div>
            </template>
        </BiCard>
    </div>
</template>
<script setup lang="ts">
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import { useI18n } from "vue-i18n";
import { computed, defineProps } from "vue";
import { DDM_MODULE_ID } from "../constants";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import TopBar from "@/components/TopBar.vue";

const props = defineProps<{
    error?: "party_not_found" | "cuaa_not_found";
}>();

const { t } = useI18n();

const title = computed(() => {
    switch (props.error) {
        default:
            return t(`${DDM_MODULE_ID}.errors.generic`);
    }
});
</script>
