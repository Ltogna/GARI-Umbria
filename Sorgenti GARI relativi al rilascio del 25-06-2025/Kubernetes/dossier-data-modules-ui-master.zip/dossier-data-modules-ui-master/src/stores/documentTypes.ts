import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";
import { ZodError } from "zod";
import type { DocumentTypeListModel } from "@/models/documentTypes";
import { getDocumentTypes } from "@/resources/api/documentTypes";
import { useMessageStore } from "./messageStore";

export interface State {
    documentTypes: DocumentTypeListModel;
    accountId: string | null;
    loading: boolean;
    error: boolean;
}

/**
 * Store for managing document types.
 */
export const useDocumentTypeStore = defineStore({
    id: "documentTypes",
    /**
     * State of the document type store.
     * @returns {State} The state object.
     */
    state: () =>
        ({
            documentTypes: [],
            loading: false,
            accountId: null,
            error: false,
        }) as State,
    getters: {},
    actions: {
        /**
         * Fetches document types for a given account ID.
         * @param {string} accountId - The account ID to fetch document types for.
         * @param {boolean} [force=false] - Whether to force fetch the document types.
         */
        async getDocumentTypes(accountId: string, force = false) {
            if (this.accountId !== accountId || force) {
                this.accountId === accountId;
                this.loading = true;
                const resp = await getDocumentTypes(accountId);
                if (resp.errorType === ErrorType.NONE) {
                    this.documentTypes = resp.data;
                } else {
                    if (
                        resp.errorType === ErrorType.OTHER &&
                        resp.err instanceof ZodError
                    ) {
                        console.warn(resp.err);
                    } else useMessageStore().handleApiErrorAndShowAlert(resp);
                    this.error = true;
                }
                this.loading = false;
            }
        },
    },
});
