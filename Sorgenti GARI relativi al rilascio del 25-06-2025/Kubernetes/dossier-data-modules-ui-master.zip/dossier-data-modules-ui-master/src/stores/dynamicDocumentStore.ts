import {
    ErrorType,
    type HttpResponseError,
} from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";
import type { DocumentDataDocSchemaType } from "@abaco/dynamic-documents/src/resources/models";
import type {
    DocumentDefinitionModel,
    DocumentListModel,
    DynamicDocumentResponse,
    NewDynamicDocumentModel,
    DocumentTypeListModel,
    LookupDetailsModel,
} from "@/modules/heirs/models/dynamicDocument";
import { useMessageStore } from "./messageStore";
import {
    createDocumentAPI,
    deleteDocumentAPI,
    getDocumentAPI,
    getDocumentDefinitionAPI,
    getDocumentListAPI,
    getDocumentTypeListAPI,
    getLookupDescription,
    updateDocumentAPI,
} from "@/resources/api/dynamic-document-api";
import { useDdmStore } from "@/stores/ddmStore";

interface State {
    hasError: boolean;
    errorResponse?: HttpResponseError;
    documentTypeList: DocumentTypeListModel;
    documentList: DocumentListModel;
    document: DynamicDocumentResponse;
    documentDefinition: DocumentDefinitionModel;
    lookupDetails: LookupDetailsModel[];
}

export const useDynamicDocumentStore = defineStore({
    id: "dynamicDocument",
    state: () =>
        ({
            hasError: false,
            errorResponse: undefined,
            protocolList: null,
            documentTypeList: null,
            documentList: {
                nextKey: null,
                records: [],
                count: 0,
            },
            document: null,
            documentDefinition: null,
            lookupDetails: [],
        }) as State,
    getters: {
        getLoading: () => {
            const store = useDdmStore();
            return store.getLoading;
        },
        getHasError: (state: State) => {
            return state.hasError;
        },
        getErrorResponse: (state: State) => {
            return state.errorResponse;
        },
        getDocumentTypeList: (state: State) => {
            return state.documentTypeList;
        },
        getDocumentList: (state: State) => {
            return state.documentList;
        },
        getDocument: (state: State) => {
            return state.document;
        },
        getDocumentDefinition: (state: State) => {
            return state.documentDefinition;
        },
        getLookupDetails: (state: State) => {
            return state.lookupDetails;
        },
    },
    actions: {
        async incrementLoadingQueue() {
            const store = useDdmStore();
            store.incrementLoadingQueue();
        },
        async decrementLoadingQueue() {
            const store = useDdmStore();
            store.decrementLoadingQueue();
        },
        async loadDocumentTypeList(partyCode: string) {
            this.documentTypeList = null;
            this.incrementLoadingQueue();
            this.hasError = false;
            const response = await getDocumentTypeListAPI(partyCode);

            if (response.errorType !== ErrorType.NONE) {
                this.hasError = true;
                this.errorResponse = response as HttpResponseError;
                console.error(this.errorResponse);
                useMessageStore().handleApiErrorAndShowAlert(response);
            } else if (response.data) {
                this.documentTypeList = response.data;
            } else {
                this.documentTypeList = null;
            }
            this.decrementLoadingQueue();
        },
        async mapLookupDetails(definitionCode: string) {
            await this.loadDocumentDefinition(definitionCode);

            const definition = this.documentDefinition;
            if (!definition?.restLookups || !definition.fieldSets) {
                this.lookupDetails = [];
                this.documentDefinition = null;
                return;
            }

            const lookupDetails = definition.restLookups
                .filter((lookup) => !!lookup.detailsUrl)
                .map((lookup) => {
                    const updatedCode = definition.fieldSets
                        .flatMap((fs) => fs.fields)
                        .find((field) => field.lookupCode === lookup.code)?.code || lookup.code;

                    return {
                        code: updatedCode,
                        detailsUrl: lookup.detailsUrl || "",
                    };
                });

            this.lookupDetails = lookupDetails;
            this.documentDefinition = null;
        },
        async getAttachmentDescription(code: string, url: string) {
            const res = await getLookupDescription(code, url);

            if (res.errorType !== ErrorType.NONE) {
                this.hasError = true;
                this.errorResponse = res as HttpResponseError;
                console.error(this.errorResponse);
                useMessageStore().handleApiErrorAndShowAlert(res);

                return "";
            } else {
                return res.data.description;
            }

        },
        async loadDocumentList(partyCode: string, resetList: boolean) {
            this.incrementLoadingQueue();
            this.hasError = false;
            const response = await getDocumentListAPI(
                partyCode,
                !resetList ? (this.documentList?.nextKey ?? null) : null,
            );
            if (response.errorType !== ErrorType.NONE) {
                this.hasError = true;
                this.errorResponse = response as HttpResponseError;
                console.error(this.errorResponse);
                useMessageStore().handleApiErrorAndShowAlert(response);
            } else {
                if (resetList) {
                    this.documentList = response.data;
                } else {
                    // concat records
                    this.documentList.count = response.data.count;
                    this.documentList.nextKey = response.data.nextKey;
                    this.documentList && this.documentList.records
                        ? this.documentList.records.push(
                            ...(response.data.records || []),
                        )
                        : (this.documentList.records = response.data.records);
                }
            }
            this.decrementLoadingQueue();
        },
        async loadDocument(partyCode: string, documentId: number) {
            this.incrementLoadingQueue();
            this.hasError = false;
            const response = await getDocumentAPI(partyCode, documentId);
            if (response.errorType !== ErrorType.NONE) {
                this.hasError = true;
                this.errorResponse = response as HttpResponseError;
                console.error(this.errorResponse);
                useMessageStore().handleApiErrorAndShowAlert(response);
            } else {
                this.document = response.data;
            }
            this.decrementLoadingQueue();
        },
        async loadDocumentDefinition(definitionCode: string) {
            this.documentDefinition = null;
            this.incrementLoadingQueue();
            this.hasError = false;
            const response = await getDocumentDefinitionAPI(definitionCode);
            if (response.errorType !== ErrorType.NONE) {
                this.hasError = true;
                this.errorResponse = response as HttpResponseError;
                console.error(this.errorResponse);
                useMessageStore().handleApiErrorAndShowAlert(response);
            } else {
                if (response.data && response.data) {
                    this.documentDefinition = response.data;
                } else {
                    this.documentDefinition = null;
                }
            }
            this.decrementLoadingQueue();
        },
        async createDocument(
            partyCode: string,
            newDocument: NewDynamicDocumentModel,
        ) {
            this.incrementLoadingQueue();
            this.hasError = false;
            const response = await createDocumentAPI(partyCode, newDocument);
            if (response.errorType !== ErrorType.NONE) {
                this.hasError = true;
                this.errorResponse = response as HttpResponseError;
                console.error(this.errorResponse);
                useMessageStore().handleApiErrorAndShowAlert(response);
            } else {
                // TODO
            }
            this.decrementLoadingQueue();
        },
        async updateDocument(
            partyCode: string,
            documentId: string,
            document: DocumentDataDocSchemaType,
        ) {
            this.incrementLoadingQueue();
            this.hasError = false;
            const response = await updateDocumentAPI(
                partyCode,
                documentId,
                document,
            );
            if (response.errorType !== ErrorType.NONE) {
                this.hasError = true;
                this.errorResponse = response as HttpResponseError;
                console.error(this.errorResponse);
                useMessageStore().handleApiErrorAndShowAlert(response);
            } else {
                // TODO
            }
            this.decrementLoadingQueue();
        },
        async deleteDocument(partyCode: string, documentId: string) {
            this.incrementLoadingQueue();
            this.hasError = false;
            const response = await deleteDocumentAPI(partyCode, documentId);
            if (response.errorType !== ErrorType.NONE) {
                this.hasError = true;
                this.errorResponse = response as HttpResponseError;
                console.error(this.errorResponse);
                useMessageStore().handleApiErrorAndShowAlert(response);
            } else {
                // TODO
            }
            this.decrementLoadingQueue();
        },
    },
});
