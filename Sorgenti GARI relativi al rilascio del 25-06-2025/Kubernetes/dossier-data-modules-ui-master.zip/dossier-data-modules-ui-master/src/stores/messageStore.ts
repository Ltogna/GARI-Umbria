import { PAYMENT_METHODS_ID } from "@/modules/payment-methods/constants";

import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";
import i18n from "@/i18n/index.js";
import type { ErrorModel } from "@abaco/bootstrap-italia-components/src/models/error";

const t = i18n.global.t;
const te = i18n.global.te;

interface Message {
    message: string;
    level: "info" | "success" | "warning" | "danger";
    autoDismiss?: boolean;
}

interface State extends Message {
    open: boolean;
    dismissTimer: ReturnType<typeof setTimeout> | null;
}

/**
 * Store for managing error messages.
 */
export const useMessageStore = defineStore("errorMessage", {
    /**
     * State of the message store.
     * @returns {State} The state object.
     */
    state: (): State => ({
        message: "",
        open: false,
        level: "warning",
        dismissTimer: null,
    }),
    getters: {},

    actions: {
        /**
         * Sets the message in the store.
         * @param {Message} message - The message object containing the message and level.
         */
        setMessage(message: Message) {
            // cancello eventuale timeout precedente
            if (this.dismissTimer) {
                clearTimeout(this.dismissTimer);
                this.dismissTimer = null;
            }

            this.message = message.message;
            this.level = message.level ?? "warning";
            this.autoDismiss = message.autoDismiss;
            this.open = true;

            if (message.autoDismiss) {
                this.dismissTimer = setTimeout(() => {
                    this.open = false;
                    this.dismissTimer = null;
                }, 5000);
            }
        },

        /**
         * Clear the message and the timer in the store.
         */
        clearMessage() {
            if (this.dismissTimer) {
                clearTimeout(this.dismissTimer);
                this.dismissTimer = null;
            }
            this.open = false;
            this.autoDismiss = false;
        },

        /**
         * Handles API errors and shows an alert message.
         * @param {any} response - The API response object.
         */
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        handleApiErrorAndShowAlert(response: any) {
            if (response.errorType === ErrorType.HTTP_STATUS) {
                if (
                    response.response.status === 403 &&
                    response.response.statusText === "Forbidden"
                ) {
                    console.error(response.response.statusText);
                    this.setMessage({
                        message: t(
                            `${PAYMENT_METHODS_ID}.errors.forbidden_action`,
                        ),
                        level: "warning",
                    });
                } else {
                    response.response
                        .json()
                        .then((errMsg: ErrorModel) => {
                            const e: ErrorModel = {
                                errorCode: "GENERIC_ERROR",
                            };
                            const key = `${PAYMENT_METHODS_ID}.errors.${errMsg.errorCode}`;
                            if (errMsg.errorCode) {
                                e.errorCode = t(key);
                            }

                            if (errMsg.message) {
                                const str =
                                    typeof errMsg.message === "string"
                                        ? errMsg.message
                                        : [...errMsg.message].join("\n");
                                e.message = str.replace(/^\w/, (c) =>
                                    c.toUpperCase(),
                                );
                            }

                            if (typeof e.message === "string") {
                                this.setMessage({
                                    message: e.message,
                                    level: "warning",
                                });
                            } else if (te(key)) {
                                this.setMessage({
                                    message: t(key),
                                    level: "warning",
                                });
                            } else {
                                this.setMessage({
                                    message: t(
                                        `${PAYMENT_METHODS_ID}.errors.GENERIC_ERROR`,
                                    ),
                                    level: "danger",
                                });
                            }
                        })
                        // eslint-disable-next-line @typescript-eslint/no-explicit-any
                        .catch((err: any) => {
                            this.setMessage({
                                message: t(
                                    `${PAYMENT_METHODS_ID}.errors.GENERIC_ERROR`,
                                ),
                                level: "danger",
                            });
                            console.error(err);
                        });
                }
            } else {
                this.setMessage({
                    message: t(`${PAYMENT_METHODS_ID}.errors.GENERIC_ERROR`),
                    level: "danger",
                });
            }
        },
    },
});
