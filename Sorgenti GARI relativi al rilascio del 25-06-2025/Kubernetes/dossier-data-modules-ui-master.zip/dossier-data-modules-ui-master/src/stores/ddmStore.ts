import { defineStore } from "pinia";

export interface State {
    loadingCounter: number;
    partyId: number | null;
    listLength: number;
    // partyRegistry: PartyModel | null;
}

/**
 * Store for managing DDM state.
 */
export const useDdmStore = defineStore({
    id: "Ddm",
    /**
     * State of the DDM store.
     * @returns {State} The state object.
     */
    state: () =>
        ({
            loadingCounter: 0,
            partyId: null,
        }) as State,
    getters: {
        getLoading: (state: State) => {
            return state.loadingCounter > 0;
        },
        getPartyId: (state: State) => {
            return state.partyId;
        },
        getListLength: (state: State) => {
            return state.listLength;
        },
    },
    actions: {
        incrementLoadingQueue() {
            this.loadingCounter++;
        },
        decrementLoadingQueue() {
            if (this.loadingCounter > 0) this.loadingCounter--;
        },
    },
});
