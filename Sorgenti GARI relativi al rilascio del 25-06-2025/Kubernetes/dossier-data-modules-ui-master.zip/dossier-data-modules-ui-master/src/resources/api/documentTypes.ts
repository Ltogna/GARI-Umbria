import {
    DocumentTypeListSchema,
    type DocumentTypeListModel,
} from "@/models/documentTypes";
import {
    DocumentSchema,
    type DocumentSchemaType,
} from "@abaco/dynamic-documents/src/resources/models/documentSchema";
import { type HttpJsonResult } from "@abaco/safe-rest/src/HTTPClient";
import { dossierDataModulesHTTPClient } from "./http";

/**
 * Retrieves a list of document types for the specified account.
 *
 * @param {string} accountId - The ID of the account.
 * @returns {Promise<HttpJsonResult<DocumentTypeListModel>>} - A promise that resolves to the list of document types.
 */
export async function getDocumentTypes(
    accountId: string,
): Promise<HttpJsonResult<DocumentTypeListModel>> {
    return await dossierDataModulesHTTPClient.getJson(
        DocumentTypeListSchema,
        `/api-priv/v1/payment-methods/doc-types`,
        {
            params: { accountId },
        },
    );
}

/**
 * Retrieves a specific document type by its definition code.
 *
 * @param {string} definitionCode - The definition code of the document type.
 * @returns {Promise<HttpJsonResult<DocumentSchemaType>>} - A promise that resolves to the document type.
 */
export async function getDocumentTypeByDefinitionCode(
    definitionCode: string,
): Promise<HttpJsonResult<DocumentSchemaType>> {
    return await dossierDataModulesHTTPClient.getJson(
        DocumentSchema,
        `/api-priv/v1/payment-methods/doc-types/${definitionCode}`,
    );
}
