import { FORCED_CONTEXT } from "@/constants";
import {
    ErrorType,
    HTTPClient,
    type HTTPClientOptions,
    type HttpResult,
    type RequestConfig,
} from "@abaco/safe-rest/src/HTTPClient";
import {
    getUserData,
    installSso2RequestConfigProvider,
} from "@abaco/safe-rest/src/sso2";

/**
 * Creates an array of HTTPClient instances based on the provided base paths.
 *
 * @param {string[]} basePaths - The base paths for the HTTP clients.
 * @returns {HTTPClient[]} - An array of HTTPClient instances.
 */
function createHTTPClient(basePaths: string[]): HTTPClient[] {
    const clients: HTTPClient[] = [];

    basePaths.forEach((basePath) => {
        const httpClient = new (class extends HTTPClient {
            constructor(config: HTTPClientOptions = {}) {
                super(config);
            }

            /**
             * Provides the request configuration.
             *
             * @param {RequestConfig} [config] - The request configuration.
             * @returns {Promise<RequestConfig>} - A promise that resolves to the request configuration.
             */
            public async provideConfig(
                config?: RequestConfig,
            ): Promise<RequestConfig> {
                const provide = await super.provideConfig(config);
                if (
                    import.meta.env.DEV &&
                    provide.params &&
                    provide.params._nc
                ) {
                    delete provide.params._nc;
                }
                return provide;
            }

            /**
             * Performs the HTTP call.
             *
             * @param {string} method - The HTTP method.
             * @param {string} url - The URL for the request.
             * @param {RequestConfig} [config] - The request configuration.
             * @param {BodyInit} [body] - The request body.
             * @returns {Promise<HttpResult>} - A promise that resolves to the result of the HTTP call.
             */
            protected async performCall(
                method: string,
                url: string,
                config?: RequestConfig | undefined,
                body?: BodyInit | undefined,
            ): Promise<HttpResult> {
                const user = getUserData();
                if (!user) {
                    return {
                        errorType: ErrorType.OTHER,
                        err: 401,
                    };
                }
                if (basePath === "") {
                    return super.performCall(method, `${url}`, config, body);
                } else {
                    return super.performCall(
                        method,
                        `${basePath}/${user.tenant}${url}`,
                        config,
                        body,
                    );
                }
            }
        })({
            forcedContext: FORCED_CONTEXT,
        });

        installSso2RequestConfigProvider(httpClient, "/sso2");

        clients.push(httpClient);
    });

    return clients;
}

export const [
    http,
    vineGisHTTPClient,
    oliveGisHTTPClient,
    fruitGisHTTPClient,
    dossierDataModulesHTTPClient,
    customerVineLinkHTTPClient,
    customerOliveLinkHTTPClient,
    customerFruitLinkHTTPClient,
    vineAlignHTTPClient,
    vineAuthServerHTTPClient
] = createHTTPClient([
    "",
    "/vine-gis-server",
    "/olive-gis-server",
    "/fruit-gis-server",
    "/dossier-data-modules",
    "/customer-vine-link",
    "/customer-olive-link",
    "/customer-fruit-link",
    "/vinealign-server",
    "/avepa-vine-authorizations"
]);

// export const http = new HTTPClient({ forcedContext: FORCED_CONTEXT });
// installSso2RequestConfigProvider(http, "/sso2");
