import { type PartyModel, PartyResponseSchema } from "@/models/party";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { http } from "./http";
import { useMessageStore } from "@/stores/messageStore";
import { ZodError } from "zod";
import { getUserData } from "@abaco/safe-rest/src/sso2";
import { useUnitConfigStore } from "@/modules/units/stores/unitConfig";

/**
 * Fetches party information based on the provided party ID.
 *
 * @param {number} partyId - The ID of the party to fetch.
 * @returns {Promise<PartyModel | null>} - A promise that resolves to the party information or null if an error occurs.
 */
export const getParty = async (partyId: number): Promise<PartyModel | null> => {
    const user = getUserData(); // Get user data

    const res = await http.getJson(
        PartyResponseSchema,
        useUnitConfigStore().partyRegistryDirectoryUrl({
            tenant: user?.tenant,
            party_id: partyId,
        }),
    );

    if (res.errorType !== ErrorType.NONE) {
        if (res.errorType === ErrorType.OTHER && res.err instanceof ZodError)
            console.error(res.err); // Log ZodError
        else useMessageStore().handleApiErrorAndShowAlert(res); // Handle other errors
        return null;
    }
    return res.data; // Return party data
};
