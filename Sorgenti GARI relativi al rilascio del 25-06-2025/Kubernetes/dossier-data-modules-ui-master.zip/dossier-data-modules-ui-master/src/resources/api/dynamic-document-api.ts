import {
    DocumentDefinitionModelSchema,
    DocumentListModelSchema,
    DocumentModelSchema,
    DocumentTypeListModelSchema,
    DynamicDocumentResponseSchema,
    type DocumentDefinitionModel,
    type DocumentListModel,
    type DocumentModel,
    type DynamicDocumentResponse,
    type NewDynamicDocumentModel,
    type DocumentTypeListModel,
    LookupDescriptionModelSchema,
    type LookupDescriptionModel,
} from "@/modules/heirs/models/dynamicDocument";
import { removeNullsOrBlanksFromObject } from "@/utils/utils";
import type {
    HttpJsonResult,
    HttpResult,
    RequestConfig,
} from "@abaco/safe-rest/src/HTTPClient";
import { dossierDataModulesHTTPClient } from "@/resources/api/http";
import type { DocumentDataDocSchemaType } from "@abaco/dynamic-documents/src/resources/models";

// DONE!
export const getDocumentTypeListAPI = async (
    partyCode: string,
): Promise<HttpJsonResult<DocumentTypeListModel>> => {
    const requestConfig: RequestConfig = {};
    requestConfig.params = {
        partyCode,
    };
    removeNullsOrBlanksFromObject(requestConfig.params);

    return dossierDataModulesHTTPClient.getJson(
        DocumentTypeListModelSchema,
        `/api-priv/v1/heirs-methods/doc-types`,
        requestConfig,
    );
};

export const getLookupDescription = async (code: string, url: string): Promise<HttpJsonResult<LookupDescriptionModel>> => {
    const prefix = "/dossier-data-modules/master";
    let  newUrl = url.startsWith(prefix) ? url.substring(prefix.length) : url;
    newUrl = newUrl.replace("{this}", code);

    return dossierDataModulesHTTPClient.getJson(
        LookupDescriptionModelSchema,
        `${newUrl}`,
    );
}

// DONE!
export const getDocumentListAPI = async (
    partyCode: string,
    nextKey: string | null,
): Promise<HttpJsonResult<DocumentListModel>> => {
    const requestConfig: RequestConfig = {};
    requestConfig.params = {
        nextKey: nextKey,
    };
    removeNullsOrBlanksFromObject(requestConfig.params);

    return dossierDataModulesHTTPClient.getJson(
        DocumentListModelSchema,
        `/api-priv/v1/heirs-methods/parties/${partyCode}/documents`,
        requestConfig,
    );
};

// DONE!
export const getDocumentAPI = async (
    partyCode: string,
    documentId: number,
): Promise<HttpJsonResult<DynamicDocumentResponse>> => {
    return dossierDataModulesHTTPClient.getJson(
        DynamicDocumentResponseSchema,
        `/api-priv/v1/heirs-methods/parties/${partyCode}/documents/${documentId}`,
    );
};

// DONE!
export const getDocumentDefinitionAPI = async (
    definitionCode: string,
): Promise<HttpJsonResult<DocumentDefinitionModel>> => {
    return dossierDataModulesHTTPClient.getJson(
        DocumentDefinitionModelSchema,
        `/api-priv/v1/heirs-methods/doc-types/${definitionCode}`,
    );
};

// DONE!
export const createDocumentAPI = async (
    partyCode: string,
    newDocument: NewDynamicDocumentModel,
): Promise<HttpJsonResult<DocumentModel>> => {
    return dossierDataModulesHTTPClient.postJson(
        DocumentModelSchema,
        `/api-priv/v1/heirs-methods/parties/${partyCode}/documents`,
        newDocument,
    );
};

// DONE!
export const updateDocumentAPI = async (
    partyCode: string,
    documentId: string,
    document: DocumentDataDocSchemaType,
): Promise<HttpJsonResult<DocumentModel>> => {
    return dossierDataModulesHTTPClient.putJson(
        DocumentModelSchema,
        `/api-priv/v1/heirs-methods/parties/${partyCode}/documents/${documentId}`,
        document,
    );
};

// DONE!
export const deleteDocumentAPI = async (
    partyCode: string,
    documentId: string,
): Promise<HttpResult> => {
    return dossierDataModulesHTTPClient.delete(
        `/api-priv/v1/heirs-methods/parties/${partyCode}/documents/${documentId}`,
    );
};
