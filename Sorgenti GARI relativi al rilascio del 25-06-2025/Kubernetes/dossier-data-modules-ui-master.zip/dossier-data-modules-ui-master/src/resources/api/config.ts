import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { dossierDataModulesHTTPClient } from "@/resources/api/http";
import { useMessageStore } from "@/stores/messageStore";
import { ZodError } from "zod";
import { ConfigResponseSchema, type Configuration } from "@/models/config";

/**
 * Retrieves the configuration by the specified key.
 *
 * @param {string} key - The key of the configuration to retrieve.
 * @returns {Promise<Configuration | null>} - A promise that resolves to the configuration or null if an error occurs.
 */
export const getConfigurationByKey = async (
    key: string,
): Promise<Configuration | null> => {
    const response = await dossierDataModulesHTTPClient.getJson(
        ConfigResponseSchema,
        `/api-priv/v1/configurations/${key}`,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data;
};
