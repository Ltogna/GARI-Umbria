import {
    DynamiDocumentListSchema,
    DynamiDocumentSchema,
    type DynamiDocumentListModel,
    type DynamiDocumentModel,
} from "@/models/dynamicDocuments";
import { useMessageStore } from "@/stores/messageStore";
import {
    ErrorType,
    type HttpJsonResult,
    type HttpResult,
} from "@abaco/safe-rest/src/HTTPClient";
import { z, ZodError } from "zod";
import { dossierDataModulesHTTPClient } from "./http";

/**
 * Creates a new document for the specified party and account.
 *
 * @param {string} partyId - The ID of the party.
 * @param {string} accountId - The ID of the account.
 * @param {any} doc - The document data.
 * @returns {Promise<any | null>} - A promise that resolves to the created document or null if an error occurs.
 */
export async function createDocument(
    partyId: string,
    accountId: string,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    doc: any,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
): Promise<any | null> {
    const response = await dossierDataModulesHTTPClient.postJson(
        z.any(),
        `/api-priv/v1/payment-methods/parties/${partyId}/accounts/${accountId}/documents`,
        doc,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data;
}

/**
 * Updates an existing document for the specified party and account.
 *
 * @param {string} partyId - The ID of the party.
 * @param {string} accountId - The ID of the account.
 * @param {string} documentId - The ID of the document.
 * @param {any} doc - The document data.
 * @returns {Promise<any | null>} - A promise that resolves to the updated document or null if an error occurs.
 */
export async function updateDocument(
    partyId: string,
    accountId: string,
    documentId: string,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    doc: any,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
): Promise<any | null> {
    const response = await dossierDataModulesHTTPClient.putJson(
        z.any(),
        `/api-priv/v1/payment-methods/parties/${partyId}/accounts/${accountId}/documents/${documentId}`,
        doc,
    );
    if (response.errorType !== ErrorType.NONE) {
        if (
            response.errorType === ErrorType.OTHER &&
            response.err instanceof ZodError
        )
            console.error(response.err);
        else useMessageStore().handleApiErrorAndShowAlert(response);
        return null;
    }
    return response.data;
}

/**
 * Retrieves a list of documents for the specified party and account.
 *
 * @param {string} partyId - The ID of the party.
 * @param {string} accountId - The ID of the account.
 * @param {string} [definitionCode] - The definition code for filtering documents.
 * @param {string | null} [nextKey] - The key for pagination.
 * @returns {Promise<HttpJsonResult<DynamiDocumentListModel>>} - A promise that resolves to the list of documents.
 */
export async function getDocuments(
    partyId: string,
    accountId: string,
    definitionCode?: string,
    nextKey?: string | null,
): Promise<HttpJsonResult<DynamiDocumentListModel>> {
    const params: Record<string, string> = {};

    if (definitionCode) {
        params["definitionCode"] = definitionCode;
    }
    if (nextKey) {
        params["nextKey"] = nextKey;
    }

    return await dossierDataModulesHTTPClient.getJson(
        DynamiDocumentListSchema,
        `/api-priv/v1/payment-methods/parties/${partyId}/accounts/${accountId}/documents`,
        {
            params,
        },
    );
}

/**
 * Retrieves a specific document for the specified party and account.
 *
 * @param {string} partyId - The ID of the party.
 * @param {string} accountId - The ID of the account.
 * @param {string | number | undefined | null} documentId - The ID of the document.
 * @returns {Promise<HttpJsonResult<DynamiDocumentModel>>} - A promise that resolves to the document.
 */
export async function getDocument(
    partyId: string,
    accountId: string,
    documentId: string | number | undefined | null,
): Promise<HttpJsonResult<DynamiDocumentModel>> {
    return await dossierDataModulesHTTPClient.getJson(
        DynamiDocumentSchema,
        `/api-priv/v1/payment-methods/parties/${partyId}/accounts/${accountId}/documents/${documentId}`,
    );
}

/**
 * Deletes a specific document for the specified party and account.
 *
 * @param {string} partyId - The ID of the party.
 * @param {string} accountId - The ID of the account.
 * @param {string | number} documentId - The ID of the document.
 * @returns {Promise<HttpResult>} - A promise that resolves to the result of the deletion.
 */
export async function deleteDocument(
    partyId: string,
    accountId: string,
    documentId: string | number,
): Promise<HttpResult> {
    return await dossierDataModulesHTTPClient.delete(
        `/api-priv/v1/payment-methods/parties/${partyId}/accounts/${accountId}/documents/${documentId}`,
    );
}
