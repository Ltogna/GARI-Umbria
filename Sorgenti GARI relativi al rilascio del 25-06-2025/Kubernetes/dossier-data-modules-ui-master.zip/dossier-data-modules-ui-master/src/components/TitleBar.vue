<script setup lang="ts">
import { computed, withDefaults, defineProps } from "vue";

import { usePartyStore } from "@/modules/units/stores/party";

const partyStore = usePartyStore();

const props = withDefaults(
    defineProps<{
        leftBarTitle: string;
        showLeftTitle: boolean;
    }>(),
    {
        leftBarTitle: "",
        showLeftTitle: true,
    },
);

const factoryName = computed(() => {
    const { description, taxCode } = partyStore.party ?? {};
    const returnName = [];
    taxCode && returnName.push(taxCode);
    description && returnName.push(description);
    return returnName.join(" - ");
});
</script>
<template>
    <div class="row">
        <div v-if="props.showLeftTitle" class="col-md-3">
            <div class="d-flex align-items-center bg-primary px-3 py-2 h-100">
                <h6 class="text-white">
                    <strong>
                        {{ props.leftBarTitle }}
                    </strong>
                </h6>
            </div>
        </div>
        <div
            :class="{
                'col-md-12': !showLeftTitle,
                'col-md-9': showLeftTitle,
            }"
        >
            <div class="d-flex align-items-center bg-primary px-3 py-2">
                <h6 class="text-white">
                    <strong>
                        {{ factoryName }}
                    </strong>
                </h6>
            </div>
        </div>
    </div>
</template>
