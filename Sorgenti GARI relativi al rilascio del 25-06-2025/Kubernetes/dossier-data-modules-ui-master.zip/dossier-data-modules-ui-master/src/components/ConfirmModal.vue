<script setup lang="ts">
import { ref, computed, defineEmits, defineProps, withDefaults } from "vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { useI18n } from "vue-i18n";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { useDdmStore } from "@/stores/ddmStore";
import { DDM_MODULE_ID } from "@/constants";
import type { ButtonColor } from "@abaco/bootstrap-italia-components/src/models";
import { useVineUnitStore } from "@/modules/units/stores/vineUnit";
import { usePaymentMedhodStore } from "@/modules/payment-methods/stores/paymentMethods";

const { t } = useI18n();
const ddmStore = useDdmStore();
const vineUnitStore = useVineUnitStore();
const paymentMedhodStore = usePaymentMedhodStore();

const props = withDefaults(
    defineProps<{
        modelValue: boolean;
        modalTitle: string;
        modalBody: string;
        confirmBtnColor?: ButtonColor;
        closeBtnColor?: ButtonColor;
    }>(),
    {
        confirmBtnColor: "primary",
        closeBtnColor: "primary",
    },
);

const model = computed({
    get() {
        return props.modelValue;
    },
    set(value: boolean) {
        emits("update:modelValue", value);
    },
});

const isConfirmBtnDisabled = computed(() => {
    return (
        ddmStore.loadingCounter > 0 ||
        vineUnitStore.loadingCounter > 0 ||
        paymentMedhodStore.loadingCounter > 0
    );
});

const modalTitle = ref(props.modalTitle);
const modalBody = ref(props.modalBody);
const emits = defineEmits<{
    (e: "update:modelValue", val: boolean): void;
    (e: "confirm"): void;
}>();
</script>
<template>
    <BiModal :title="modalTitle" size="lg" v-model="model">
        <template #body>
            {{ modalBody }}
        </template>
        <template #footer>
            <div class="d-flex justify-content-center mt-3 vw-100">
                <BiButton
                    class="me-2"
                    :color="closeBtnColor"
                    isOutlined
                    @click="() => (model = false)"
                >
                    {{ t(`${DDM_MODULE_ID}.close`) }}
                </BiButton>

                <BiButton
                    :color="confirmBtnColor"
                    @click="emits('confirm')"
                    :is-disabled="isConfirmBtnDisabled"
                >
                    {{ t(`${DDM_MODULE_ID}.confirm`) }}
                </BiButton>
            </div>
        </template>
    </BiModal>
</template>
