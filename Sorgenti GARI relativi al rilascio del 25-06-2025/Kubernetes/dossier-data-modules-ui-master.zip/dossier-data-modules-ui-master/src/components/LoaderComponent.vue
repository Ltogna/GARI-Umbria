<script setup lang="ts">
import { useDdmStore } from "@/stores/ddmStore";
import { usePaymentMedhodStore } from "@/modules/payment-methods/stores/paymentMethods";
import { useVineUnitStore } from "@/modules/units/stores/vineUnit";

const ddmStore = useDdmStore();
const vineUnitStore = useVineUnitStore();
const paymentMethodsStore = usePaymentMedhodStore();
</script>

<template>
    <Transition name="opacityAnimation">
        <div
            v-if="
                ddmStore.loadingCounter > 0 ||
                vineUnitStore.loadingCounter > 0 ||
                paymentMethodsStore.loadingCounter > 0
            "
            class="d-flex justify-content-center align-items-center wrapper"
        >
            <div
                class="progress-spinner progress-spinner-active progress-spinner-double"
            >
                <div class="progress-spinner-inner"></div>
                <div class="progress-spinner-inner"></div>
            </div>
        </div>
    </Transition>
</template>
<style scoped lang="scss">
.wrapper {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(200, 200, 200, 0.5);
    z-index: 1000;
}
</style>
