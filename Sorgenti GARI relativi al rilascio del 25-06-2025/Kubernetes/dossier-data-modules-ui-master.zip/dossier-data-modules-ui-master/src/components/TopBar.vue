<script setup lang="ts">
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
import { computed, withDefaults, defineProps } from "vue";
import { DDM_MODULE_ID } from "@/constants";

const props = withDefaults(
    defineProps<{
        title: string;
    }>(),
    {
        title: "",
    },
);
const backUrl = computed(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const backUrl = urlParams.get("backUrl");
    if (backUrl) return backUrl;
    return sessionStorage.getItem(`${DDM_MODULE_ID}.backUrl`);
});

function goBack() {
    if (backUrl.value) location.assign(decodeURIComponent(backUrl.value));
}
</script>
<template>
    <div class="d-flex justify-content-between align-items-center">
        <div class="d-flex justify-content-start">
            <BiBackButton v-if="backUrl" @click="goBack" class="btn-me" />
            <h3 class="text-primary m-0">
                {{ props.title }}
            </h3>
        </div>

        <div class="d-flex justify-content-end">
            <slot name="actions"></slot>
        </div>
    </div>
</template>
