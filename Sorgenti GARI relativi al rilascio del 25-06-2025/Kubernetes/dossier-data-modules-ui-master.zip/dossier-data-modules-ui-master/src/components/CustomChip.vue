<script setup lang="ts">
import { useI18n } from "vue-i18n";
import { computed, withDefaults, defineProps } from "vue";
import { DDM_MODULE_ID } from "@/constants";

const { t } = useI18n();

const props = withDefaults(
    defineProps<{
        /**
         * Displayed text inside chip
         */
        label?: string;
        /**
         * Make the chip bigger
         */
        isChipLarge?: boolean;
        /**
         * Set chip style
         */
        chipType?: "primary" | "secondary" | "success" | "danger" | "warning";
        /**
         * Set the chip in disabled mode
         */
        isDisabled?: boolean;
        /**
         * Make the chip deletable
         */
        isDelete?: boolean;
        /**
         * Add extra classes (separated by spaces)
         */
        extraClasses?: string;
    }>(),
    { extraClasses: "", extraCss: "" },
);

const chipClasses = computed(() => {
    return `chip${!props.isDelete ? " chip-simple" : ""}${
        props.isChipLarge ? " chip-lg" : ""
    }${props.chipType ? " chip-" + props.chipType : ""}${
        props.isDisabled ? " chip-disabled" : ""
    }${props.extraClasses ? " " + props.extraClasses : ""}`;
});
</script>
<template>
    <div class="chip d-flex align-items-center" :class="chipClasses">
        <span class="chip-label">
            {{ label }}
        </span>
        <button type="button" @click="$emit('delete')">
            <svg
                v-if="isDelete"
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                xmlns:xlink="http://www.w3.org/1999/xlink"
                x="0px"
                y="0px"
                viewBox="0 0 24 24"
                style="enable-background: new 0 0 24 24"
                xml:space="preserve"
                class="icon me-1"
            >
                <g>
                    <path
                        d="M12.7,12l3.7,3.6l-0.8,0.8L12,12.7l-3.6,3.7l-0.8-0.8l3.7-3.6L7.6,8.4l0.8-0.8l3.6,3.7l3.6-3.7l0.8,0.8L12.7,12z"
                    />
                </g>
            </svg>
            <!-- <BiIcon icon="xmark" class="icon mx-1" /> -->
            <span class="visually-hidden" v-if="isDelete">
                {{ t(`${DDM_MODULE_ID}.delete`) }}
            </span>
        </button>
    </div>
</template>
