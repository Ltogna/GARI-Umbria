<script setup lang="ts">
import type {
    AnomalyLevelModel,
    AnomalySearchModel,
} from "@/models/anomalyLevel";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import type { AlertType } from "@abaco/bootstrap-italia-components/src/models";
import { computed, defineProps } from "vue";
import { useI18n } from "vue-i18n";
import { DDM_MODULE_ID } from "@/constants";

const props = defineProps<{
    anomalies: AnomalySearchModel[];
    type: AnomalyLevelModel;
}>();

const { t } = useI18n();

const variant = computed<AlertType>(() => {
    if (props.type === "INFO") {
        return "info";
    } else if (props.type === "DANGER") {
        return "error";
    } else {
        return "warning";
    }
});
</script>

<template>
    <BiAlert
        :variant="variant"
        :title="
            t(`${DDM_MODULE_ID}.anomalies_modal.title_${type.toLowerCase()}`)
        "
    >
        <template #body>
            <ul class="border-top mt-3">
                <li
                    v-for="(anomaly, index) in anomalies"
                    :key="`anomaly-item-${type}-${index}`"
                    class="mt-3"
                >
                    <strong>{{ anomaly.type.code }}</strong> -
                    {{ anomaly.type.i18nCode }}
                </li>
            </ul>
        </template>
    </BiAlert>
</template>
