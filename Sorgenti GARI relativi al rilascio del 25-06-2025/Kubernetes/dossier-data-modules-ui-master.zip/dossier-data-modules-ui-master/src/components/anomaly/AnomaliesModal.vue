<script setup lang="ts">
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { useVModel } from "@vueuse/core";
import { useI18n } from "vue-i18n";
import AnomalyAlert from "./AnomalyAlert.vue";
import type { Anomaly } from "@/models/anomalyLevel";
import { DDM_MODULE_ID } from "@/constants";
import { defineEmits, defineProps } from "vue";
/**
 * TODO: better implmentation
 */

const props = defineProps<{
    modelValue: boolean;
    anomalies: Anomaly | null;
}>();

const emits = defineEmits<{
    (e: "update:modelValue"): void;
}>();

const { t } = useI18n();

const showAnomaliesModal = useVModel(props, "modelValue", emits);
</script>

<template>
    <BiModal
        v-model="showAnomaliesModal"
        :title="t(`${DDM_MODULE_ID}.anomalies`)"
        size="xl"
        extraFooterClass="d-flex justify-content-center"
    >
        <template #body>
            <AnomalyAlert
                v-if="props.anomalies?.DANGER"
                type="DANGER"
                :anomalies="props.anomalies.DANGER"
            />
            <AnomalyAlert
                v-if="props.anomalies?.WARN"
                type="WARN"
                :anomalies="props.anomalies.WARN"
            />
            <AnomalyAlert
                v-if="props.anomalies?.INFO"
                type="INFO"
                :anomalies="props.anomalies.INFO"
            />
        </template>
        <template #footer>
            <BiButton
                color="primary"
                is-outlined
                @click="showAnomaliesModal = false"
            >
                {{ t(`${DDM_MODULE_ID}.close`) }}
            </BiButton>
        </template>
    </BiModal>
</template>
