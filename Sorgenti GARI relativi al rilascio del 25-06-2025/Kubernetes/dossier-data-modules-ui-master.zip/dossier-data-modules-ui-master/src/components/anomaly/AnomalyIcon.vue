<script setup lang="ts">
import type { BankAccount } from "@/modules/payment-methods/models/bankAccounts";
import { AnomalyLevelSchema } from "@/models/anomalyLevel";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { defineProps } from "vue";

defineProps<{
    account: BankAccount;
}>();
</script>
<template>
    <BiIcon
        v-if="
            account.anomalies?.DANGER &&
            account.anomalies.maxLevel == AnomalyLevelSchema.Enum.DANGER
        "
        icon="minus-circle"
        color="danger"
    ></BiIcon>
    <BiIcon
        v-if="
            account.anomalies?.WARN &&
            account.anomalies.maxLevel == AnomalyLevelSchema.Enum.WARN
        "
        icon="exclamation-triangle"
        color="warning"
    ></BiIcon>
    <BiIcon
        v-if="
            account.anomalies?.INFO &&
            account.anomalies.maxLevel === AnomalyLevelSchema.Enum.INFO
        "
        icon="circle-info"
        size="lg"
        color="info"
    ></BiIcon>
</template>
