<template>
    <div class="ddm__alert my-3" v-if="model">
        <div
            ref="alertEl"
            class="alert bg-white w-100 d-flex m-0"
            :class="alertClasses"
            role="alert"
        >
            <p class="m-0" :class="{ 'me-2': dismissable }"><slot /></p>
            <button
                v-if="dismissable"
                type="button"
                class="btn-close ms-auto"
                data-bs-dismiss="alert"
                :aria-label="t(`${DDM_MODULE_ID}.close`)"
            />
        </div>
    </div>
</template>
<script lang="ts" setup>
import {
    ref,
    computed,
    onUnmounted,
    watch,
    withDefaults,
    defineProps,
    defineEmits,
} from "vue";
import { useI18n } from "vue-i18n";
import { DDM_MODULE_ID } from "@/constants";

const props = withDefaults(
    defineProps<{
        additionalPaddingBottom?: number;
        dismissable?: boolean;
        fade?: boolean;
        level?: "info" | "success" | "warning" | "danger";
        modelValue: boolean;
    }>(),
    {
        additionalPaddingBottom: 0,
        dismissable: true,
        fade: true,
        level: "info",
        modelValue: false,
    },
);

const { t } = useI18n();

const emit = defineEmits<{
    (e: "closed"): void;
    (e: "close"): void;
    (e: "update:modelValue", value: boolean): void;
}>();

const model = computed({
    get() {
        return props.modelValue;
    },
    set(value: boolean) {
        emit("update:modelValue", value);
    },
});

const alertEl = ref<HTMLDivElement>();

function onClose() {
    emit("close");
}
function onClosed() {
    emit("closed");
    model.value = false;
}

watch(
    [model, alertEl],
    ([val, el]) => {
        if (el) {
            if (val) {
                el.addEventListener("closed.bs.alert", onClosed);
                el.addEventListener("close.bs.alert", onClose);
            } else {
                const alert = window.bootstrap.Alert.getOrCreateInstance(el);
                alert.close();
            }
        }
    },
    { immediate: true },
);

onUnmounted(() => {
    if (alertEl.value) {
        const alert = window.bootstrap.Alert.getOrCreateInstance(alertEl.value);
        alertEl.value.removeEventListener("closed.bs.alert", onClosed);
        alertEl.value.removeEventListener("close.bs.alert", onClose);
        alert?.dispose();
    }
});

const alertClasses = computed(() => {
    return [
        {
            "alert-dismissable": props.dismissable,
            fade: props.dismissable && props.fade,
            show: props.dismissable,
        },
        [`alert-${props.level}`],
    ];
});
</script>
