import { inject } from "vue";
import { useI18n } from "vue-i18n";

export default function (key: string): string {
    const { t } = useI18n();
    return t(`${inject("moduleId") as string}.${key}`);
}
