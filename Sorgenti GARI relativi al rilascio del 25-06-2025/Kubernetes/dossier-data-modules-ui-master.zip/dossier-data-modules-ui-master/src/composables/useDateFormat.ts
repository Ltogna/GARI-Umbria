import { getUserData } from "@abaco/safe-rest/src/sso2";
import { format } from "date-fns";
import { CLIENT_DATE_FORMAT } from "@/constants";

export default function () {
    function dateFormat(date: Date | null, dateFormat?: string, withTime?: boolean): string | null {
        if (!date) {
            return null;
        }
        let pattern = dateFormat ? dateFormat : getUserData()?.dateFormat ?? CLIENT_DATE_FORMAT;

        if (withTime) {
            pattern += " HH:mm:ss";
        }
        return format(date, pattern);
    }

    return {
        dateFormat,
    };
}
