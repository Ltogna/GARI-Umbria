import { useRouteQuery } from "@vueuse/router";
import { computed } from "vue";

export default function (name: string, defaultValue = "") {
    const filter = useRouteQuery(name, defaultValue);

    const hasValue = computed({
        get() {
            return !!filter.value;
        },
        set(value: boolean) {
            if (!value) {
                filter.value = "";
            }
        },
    });

    return { filter, hasValue };
}
