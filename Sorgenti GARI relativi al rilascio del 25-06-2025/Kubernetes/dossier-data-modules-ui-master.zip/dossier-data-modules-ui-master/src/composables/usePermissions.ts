import { inject } from "vue";

export default function () {
    const isEdit = inject("userHasEditPermission") as boolean;
    const canReadPaymentsMethods = inject("canReadPaymentMethods") as boolean;
    const canEditPaymentsMethods = inject("canWritePaymentMethods") as boolean;
    const canReadHeir = inject("canReadHeir") as boolean;
    const canEditHeir = inject("canWriteHeir") as boolean;

    return {
        /**
         * is edit
         */
        isEdit,
        /**
         * can read only in payments methods
         */
        canReadPaymentsMethods,
        /**
         * can write/edit in payments methods
         */
        canEditPaymentsMethods,
        /**
         * can read only in heir
         */
        canEditHeir,
        /**
         * can write/edit in heir
         */
        canReadHeir,
    };
}
