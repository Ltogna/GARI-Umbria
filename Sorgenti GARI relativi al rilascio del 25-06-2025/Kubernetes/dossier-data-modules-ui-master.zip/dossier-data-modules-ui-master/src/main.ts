import "@/assets/dossier-data-modules.scss";
import createBootstrapItaliaPlugin from "@abaco/bootstrap-italia-components/src/components/BootstrapItaliaComponentPlugin";
import { onModuleLoaded } from "@abaco/micro-frontend/src/Application";
import { createAbcRouter } from "@abaco/micro-frontend/src/Utility";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import {
    getUserData,
    login,
    userHasPermission,
} from "@abaco/safe-rest/src/sso2";
import mitt from "mitt";
import { createPinia } from "pinia";
import { createApp, type App as VueApp } from "vue";
import { createRouter, createWebHistory } from "vue-router";
import App from "./App.vue";
import { BASE, DDM_MODULE_ID } from "./constants";
import i18n, { loadLocaleMessages } from "./i18n";
import routes from "./routes";
import { isStandalone } from "./utils/isStandalone";
import { VueQueryPlugin } from "@tanstack/vue-query";

console.log(
    `dossier-data-modules: v${import.meta.env.VITE_APP_VERSION}-${
        import.meta.env.VITE_APP_GIT_COMMIT
    }`,
);

/**
 * Authenticates the user using credentials from environment variables.
 * @throws Will throw an error if VITE_TENANT, VITE_USERNAME, or VITE_PASSWORD are missing or if login fails.
 */
async function authenticate() {
    try {
        const { VITE_TENANT, VITE_USERNAME, VITE_PASSWORD } = import.meta.env;

        if (!VITE_TENANT || !VITE_USERNAME || !VITE_PASSWORD) {
            throw new Error(
                "Missing VITE_TENANT, VITE_USERNAME, or VITE_PASSWORD",
            );
        }

        const credentials = {
            tenant: VITE_TENANT,
            username: VITE_USERNAME,
            password: VITE_PASSWORD,
        };

        const resp = await login(credentials, "/sso2");

        if (resp.errorType !== ErrorType.NONE) {
            throw new Error("Login failed");
        }
    } catch (err) {
        console.warn(err);
    }
}

export const IS_DEV = import.meta.env.DEV;

if (isStandalone) {
    await authenticate();
    window.bootstrap.loadFonts(BASE + "bootstrap-italia/dist/fonts");
    await import("@/assets/index.scss");
    const router = createRouter({
        history: createWebHistory(import.meta.env.BASE_URL),
        routes,
    });
    const app = createApp(App);
    app.use(router);
    await init(app);
    app.mount("#app");
} else {
    let appModule: VueApp<Element> | null;

    onModuleLoaded(DDM_MODULE_ID, {
        /**
         * Starts the application module.
         * @param {HTMLElement} node - The DOM node to mount the app on.
         * @param {string} [basePath] - The base path for the router.
         */
        async start(node, basePath?: string) {
            appModule = createApp(App);
            const router = createAbcRouter(routes, basePath);
            appModule.use(router);

            await init(appModule, basePath);
            appModule.mount(node);
        },
        /**
         * Returns the CSS configuration for the module.
         * @returns {Object} The CSS configuration object.
         */
        css() {
            return { index: `${BASE}assets/index.css.json` };
        },
        /**
         * Stops the application module.
         */
        async stop() {
            appModule?.unmount();
        },
    });
}

/**
 * Initializes the Vue application with necessary plugins and configurations.
 * @param {VueApp} app - The Vue application instance.
 * @param {string} [basePath] - The base path for the router.
 * @returns {Promise<VueApp>} The initialized Vue application instance.
 */
async function init(app: VueApp, basePath?: string) {
    const emitter = mitt();
    const pinia = createPinia();
    app.use(VueQueryPlugin);
    app.use(pinia);
    const bootstrapItaliaComponentPlugin = await createBootstrapItaliaPlugin({
        includeGlobalComponent: false,
        includeFontAwesome: isStandalone,
    });

    const user = getUserData();

    const lang = user?.locale ?? window.navigator.language;
    const canWritePaymentMethods = userHasPermission(
        "DDM_PAYMENT_METHODS",
        "EDITOR",
    );
    const canReadPaymentMethods = userHasPermission(
        "DDM_PAYMENT_METHODS",
        "VIEWER",
    );
    const canReadHeir = userHasPermission("DDM_HEIR_METHODS", "VIEWER");
    const canWriteHeir = userHasPermission("DDM_HEIR_METHODS", "EDITOR");
    const userHasEditPermission = userHasPermission("DOSSIERS", "USER");
    await loadLocaleMessages(lang);
    app.config.globalProperties.$emitter = emitter;

    app.use(i18n);
    app.use(bootstrapItaliaComponentPlugin);
    app.provide("moduleId", DDM_MODULE_ID);
    app.provide("userHasEditPermission", userHasEditPermission);
    app.provide("basePath", basePath);
    app.provide("emitter", emitter);
    app.provide("canReadPaymentMethods", canReadPaymentMethods);
    app.provide("canWritePaymentMethods", canWritePaymentMethods);
    app.provide("canReadHeir", canReadHeir);
    app.provide("canWriteHeir", canWriteHeir);
    return app;
}
