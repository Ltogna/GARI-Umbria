import paymentMethodsRoutes from "@/modules/payment-methods/routes";
import unitRoutes from "@/modules/units/routes";
import heirsRoutes from "@/modules/heirs/routes";
import type { RouteRecordRaw } from "vue-router";
export default [
    ...paymentMethodsRoutes,
    ...unitRoutes,
    ...heirsRoutes,
    {
        path: "/:pathMatch(.*)*",
        name: "NotFound",
        props(to) {
            return {
                error: to.query.error,
            };
        },
        component: () => import("../views/NotFound.vue"),
    },
] as RouteRecordRaw[];
