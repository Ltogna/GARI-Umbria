import z from "zod";

/**
 * Schema for validating environment variables.
 */
const envSchema = z.object({
    VITE_BASE: z.string().min(1),
    VITE_FORCED_CONTEXT: z.string().default(""),
});

/**
 * Parsed environment variables.
 */
const env = envSchema.parse(import.meta.env);

/**
 * Forced context for the application.
 * @type {string}
 */
export const FORCED_CONTEXT = env.VITE_FORCED_CONTEXT;

/**
 * Base URL for the application.
 * @type {string}
 */
export const BASE = `${FORCED_CONTEXT}${env.VITE_BASE}`;

/**
 * Module ID for the dossier data modules.
 * @type {string}
 */
export const DDM_MODULE_ID = "dossier-data-modules";

/**
 * Module ID for the avepa vine authorizations module
 * @type {string}
 */
export const AV_AUTH_MODULE_ID = "avepa-vine-authorizations";

/**
 * Date format used by the server.
 * @type {string}
 */
export const SERVER_DATE_FORMAT = "yyyyMMdd";

/**
 * Date format used by the client.
 * @type {string}
 */
export const CLIENT_DATE_FORMAT = "dd/MM/yyyy";

/**
 * Month and year format.
 * @type {string}
 */
export const MONTH_YEAR_FORMAT = "MM/yyyy";

/**
 * Default date value.
 * @type {string}
 */
export const DATE_TO_DEFAULT = "99991231";
