import { absoluteDateToISODate } from "@/utils/utils";
import { getNextPagedResultsSchema } from "@abaco/safe-rest/src/pagination";
import { z } from "zod";

/**
 * N = Natural
 * L = Legal
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const PartyTypeEnumSchema = z.enum(["N", "L"]);
export type PartyTypeEnum = z.infer<typeof PartyTypeEnumSchema>;

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const GenderEnumSchema = z.enum(["M", "F"]);
export type GenderEnum = z.infer<typeof GenderEnumSchema>;

/**
 *
 * Schema for country search response.
 */
export const CountrySearchResponseSchema = z.object({
    code: z.string(),
    tenantId: z.string(),
    active: z.nullable(z.boolean()),
    i18nName: z.nullable(z.string()),
});

/**
 * Schema for region search response.
 */
export const RegionSearchResponseSchema = CountrySearchResponseSchema.extend({
    countryCode: z.string(),
    shortDescr: z.string(),
    country: CountrySearchResponseSchema,
});

/**
 * Schema for district search response.
 */
export const DistrictSearchResponseSchema = CountrySearchResponseSchema.extend({
    regionCode: z.string(),
    shortDescr: z.string(),
    region: RegionSearchResponseSchema,
});

/**
 * Schema for municipality search response.
 */
export const MunicipalitySearchResponseSchema =
    CountrySearchResponseSchema.extend({
        districtCode: z.string(),
        shortDescr: z.string(),
        district: DistrictSearchResponseSchema,
    });

/**
 * Schema for address.
 */
export const AddressSchema = z.object({
    id: z.number(),
    municipality: z.string().nullable(),
    locality: z.string().nullable(),
    street: z.string().nullable(),
    houseNumber: z.string().nullable(),
    postcode: z.string().nullable(),
    details: z.string().nullable(),
    note: z.string().nullable(),
    municipalityI18nCode: z.string().nullable(),
    districtShortDescr: z.string().nullable().optional(),
    municipalityDetail: MunicipalitySearchResponseSchema.nullable().optional(),
});

/**
 * Schema for tag response.
 */
export const TagResponseSchema = z.object({
    id: z.number(),
    code: z.string(),
    i18nCode: z.nullable(z.string()),
});

/**
 * Schema for party response.
 */
export const PartyResponseSchema = z
    .object({
        id: z.number().nullish(),
        partyId: z.number().default(-1),
        code: z.string(),
        description: z.string().default(""),
        birthDate: absoluteDateToISODate.nullish(),
        lastName: z.string().nullish(),
        firstName: z.string().nullish(),
        taxCode: z.string().nullish(),
    })
    .superRefine((p) => {
        if (p.partyId === -1 && typeof p.id === "number") p.partyId = p.id;
        p.description = [p.description, p.lastName, p.firstName]
            .filter((f) => f)
            .join(" ")
            .trim();
        return p;
    });
export type PartyModel = z.infer<typeof PartyResponseSchema>;
export const PartyListSchema = getNextPagedResultsSchema(PartyResponseSchema);
export type PartyList = z.infer<typeof PartyListSchema>;
