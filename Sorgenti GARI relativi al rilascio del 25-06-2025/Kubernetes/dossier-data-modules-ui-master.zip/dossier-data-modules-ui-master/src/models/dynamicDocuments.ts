import { getNextPagedResultsSchema } from "@abaco/safe-rest/src/pagination";
import { z } from "zod";
import {
    DocumentDataFieldSchema,
    DocumentDataSchema,
} from "@abaco/dynamic-documents/src/resources/models";

/**
 * Schema for summary field definition.
 */
export const SummaryFieldDefinitionSchema = z.object({
    code: z.string(),
    description: z.string(),
    fieldType: z.string(),
});

/**
 * Schema for dynamic document data.
 */
export const DynamiDocumentDataSchema = z.record(
    z.string().min(1),
    z.unknown(),
);

/**
 * Schema for dynamic document.
 */
export const DynamiDocumentSchema = z.object({
    groupId: z.number().nullable().optional(),
    definitionCode: z.string().nullable().optional(),
    documentId: z.number().nullable().optional(),
    bucketName: z.string().nullable().optional(),
    summaryFieldDefinitions: z.array(SummaryFieldDefinitionSchema).nullish(),
    data: DynamiDocumentDataSchema,
});

/**
 * Schema for dynamic document list.
 */
export const DynamiDocumentListSchema =
    getNextPagedResultsSchema(DynamiDocumentSchema);

/**
 * Schema for dynamic document map.
 */
export const DynamiDocumentMap = DocumentDataSchema.extend({
    id: z.string().nullish(),
    documentId: z.number().nullable().optional(),
    data: DynamiDocumentDataSchema,
});

/**
 * Schema for document data record.
 */
export const DocumentDataRecordSchema = z.record(
    z.string().min(1),
    z.union([DocumentDataFieldSchema, z.array(DocumentDataFieldSchema)]),
);

export type DynamiDocumentDataModel = z.infer<typeof DynamiDocumentDataSchema>;
export type DynamiDocumentModel = z.infer<typeof DynamiDocumentSchema>;
export type DynamiDocumentListModel = z.infer<typeof DynamiDocumentListSchema>;
export type DynamiDocumentMapModel = z.infer<typeof DynamiDocumentMap>;
export type DocumentDataRecordModel = z.infer<typeof DocumentDataRecordSchema>;
