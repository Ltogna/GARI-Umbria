import { z } from "zod";

/**
 * Schema for summary field definition.
 */
export const SummaryFieldDefinitionSchema = z.object({
    code: z.string(),
    description: z.string(),
    fieldType: z.string(),
});

/**
 * Base schema for document type.
 */
export const BaseDocumentTypeSchema = z.object({
    definitionCode: z.string(),
    definitionCodeI18n: z.string(),
    namespace: z.string(),
    required: z.boolean(),
    docPresent: z.boolean(),
    summaryFieldDefinitions: z.array(SummaryFieldDefinitionSchema),
});

/**
 * Schema for multiple document type.
 */
export const MultipleDocumentTypeSchema = BaseDocumentTypeSchema.extend({
    multiple: z.literal(true),
});

/**
 * Schema for single document type.
 */
export const SingleDocumentTypeSchema = MultipleDocumentTypeSchema.extend({
    multiple: z.literal(false),
    documentId: z.number().nullish(),
});

/**
 * Schema for document type.
 */
export const DocumentTypeSchema = z.discriminatedUnion("multiple", [
    MultipleDocumentTypeSchema,
    SingleDocumentTypeSchema,
]);

/**
 * Schema for document type list.
 */
export const DocumentTypeListSchema = z.array(DocumentTypeSchema);

export type DocumentTypeModel = z.infer<typeof DocumentTypeSchema>;
export type DocumentTypeListModel = z.infer<typeof DocumentTypeListSchema>;
