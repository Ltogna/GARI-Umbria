import { z } from "zod";

/**
 * Schema for anomaly level.
 */
export const AnomalyLevelSchema = z.enum(["DANGER", "WARN", "INFO"]);

export type AnomalyLevelModel = z.infer<typeof AnomalyLevelSchema>;

/**
 * Schema for anomaly type.
 */
export const AnomalyTypeSchema = z.object({
    groupCode: z.string(),
    code: z.string(),
    i18nCode: z.string().nullable(),
    level: z.string().nullable().optional(),
});

/**
 * Schema for anomaly search.
 */
export const AnomalySearchSchema = z.object({
    entityCode: z.string(),
    entityId: z.string(),
    type: AnomalyTypeSchema,
});

export type AnomalySearchModel = z.infer<typeof AnomalySearchSchema>;

/**
 * Schema for anomaly response.
 */
export const AnomalyResponseSchema = z.object({
    INFO: z.array(AnomalySearchSchema).optional(),
    WARN: z.array(AnomalySearchSchema).optional(),
    DANGER: z.array(AnomalySearchSchema).optional(),
    maxLevel: AnomalyLevelSchema.nullable(),
});

export type Anomaly = z.infer<typeof AnomalyResponseSchema>;
