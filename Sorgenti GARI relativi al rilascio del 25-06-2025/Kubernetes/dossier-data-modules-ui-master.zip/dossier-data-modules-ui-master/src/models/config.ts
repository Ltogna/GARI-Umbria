import { z } from "zod";

/**
 * Schema for configuration response.
 */
export const ConfigResponseSchema = z.object({
    configurationKey: z.string(),
    configuration: z.record(z.string(), z.unknown()),
});

export type Configuration = z.infer<typeof ConfigResponseSchema>;
