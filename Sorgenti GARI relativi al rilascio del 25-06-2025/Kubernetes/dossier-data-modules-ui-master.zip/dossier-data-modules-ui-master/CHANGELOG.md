# Changelog

## [Unreleased]

# [2.5.6](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.5.5...v2.5.6) - 2025-05-26

### Fixed

- Fixed error with fields with value 0 [#175520](https://abacogroup.easyredmine.com/issues/175520)

- Fixed provinces reporting on authorisations summary [#175614](https://abacogroup.easyredmine.com/issues/175614)

- Add error mesages for unspecified mandatory fields on transfer to CUAA feature [#175654](https://abacogroup.easyredmine.com/issues/175654)

- Solved problem with filling the EXPIRY DATE field [#175745](https://abacogroup.easyredmine.com/issues/175745)

- Fixed issue with incorrect residual surface value and new handling of surface fields with comma and comment methods in utils 
[#175845](https://abacogroup.easyredmine.com/issues/175845)

- Add error message for invalidate transferred date on Transfer to CUAA/Transfer to Region [#175852](https://abacogroup.easyredmine.com/issues/175852)

- remove values in filed fields [#175855](https://abacogroup.easyredmine.com/issues/175855)

- Show error message for the same CUAA [#175862](https://abacogroup.easyredmine.com/issues/175862)

- show message for transferredSurface grater then 0 and less than the residual surface[#175877](https://abacogroup.easyredmine.com/issues/175877)

- enabled button save and show error message for invalidate input [#175943](https://abacogroup.easyredmine.com/issues/175943)

- Add error message for invalidate new date and change expiry date [#175944](https://abacogroup.easyredmine.com/issues/175944)


# [2.5.5](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.5.4...v2.5.5) - 2025-05-21

### Fixed

- fixed expiration date Authorization [#175745](https://abacogroup.easyredmine.com/issues/175745)

- fixed release date when updated [#175637](https://abacogroup.easyredmine.com/issues/175637)

- numerical fields accept decimal in authorizations [#175015](https://abacogroup.easyredmine.com/issues/175015)

- Resolved generic error on implanted superfix fields and transfer surfaces to authorizations [#175604](https://abacogroup.easyredmine.com/issues/175604)

- improved control of mandatory fields [#175520](https://abacogroup.easyredmine.com/issues/175520)

- Resolved date mismatch on presentation between authorizations summary and detail [#175737](https://abacogroup.easyredmine.com/issues/175737)

# [2.5.4](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.5.3...v2.5.4) - 2025-05-19

### Fixed

- Heirs: fix wrong BiTooltip's text and cropped table on Firebox

# [2.5.3](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.5.2...v2.5.3) - 2025-04-30

- fix(models): correct date field types in authorizations

### Added

- Heirs: add isReadOnly status on Heir [#173616](https://abacogroup.easyredmine.com/issues/173616)

# [2.5.2](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.5.0...v2.5.2) - 2025-04-30

### Changed

- Heirs: added allert with no data message in HeirsList [#173853](https://abacogroup.easyredmine.com/issues/173853)

### Fixed

- Heirs: Remove duplicate Party model and schema [#164627](https://abacogroup.easyredmine.com/issues/164627)

- Upgraded dynamic-documents-ui: [#173698](https://abacogroup.easyredmine.com/issues/173698)

# [2.5.0](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.4.0...v2.5.0) - 2025-04-30

### Fixed

- Heirs:

    - getViewTitle based on currentView [#173701](https://abacogroup.easyredmine.com/issues/173701)

    - Keep search button aligned when input gives error [#173702](https://abacogroup.easyredmine.com/issues/173702)

    - Handle input erros while compiling or searching [#173707](https://abacogroup.easyredmine.com/issues/173707)

    - Change it labels [#173709](https://abacogroup.easyredmine.com/issues/173709)

    - Fixed restLookups reload [#173700](https://abacogroup.easyredmine.com/issues/173700)

    - Create lookupDetails props in store, mapLookupDetails and getAttachmentDescription actions to get lookup descriptions from getLookupDescription APi GET
      [#164627](https://abacogroup.easyredmine.com/issues/164627)

    - Added watcher to mapLookupDetails in component and getAttachmentDescription in formatField function [#164627](https://abacogroup.easyredmine.com/issues/164627)

    - Change "text" prop type in OverflowTooltip to handle Promise and show resolvedText in component [#164627](https://abacogroup.easyredmine.com/issues/164627)

    - Change PartySchema and remove date conversion [#164627](https://abacogroup.easyredmine.com/issues/164627)

# [2.4.0](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.3.0...v2.4.0) - 2025-04-24

### Fixed

- Heirs module release [#164627](https://abacogroup.easyredmine.com/issues/164627)

# [2.3.0](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.2.4...v2.3.0) - 2025-04-18

### Fixed

- Authorizations management release [#167278](https://abacogroup.easyredmine.com/issues/167278)

# [2.2.4](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.2.3...v2.2.4) - 2025-02-28

### Fixed

- AptitudesUvList: openViewerUrl url to open vine-viewer [#163193](https://abacogroup.easyredmine.com/issues/163193)
- Include anomalies in getParcels API's [#162793](https://abacogroup.easyredmine.com/issues/162793)

# [2.2.3](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.2.2...v2.2.3) - 2025-02-27

### Changed

- Removed alert on alignment is in progress [#164331](https://abacogroup.easyredmine.com/issues/164331)

# [2.2.2](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.1.3...v2.2.2) - 2025-02-25

### Added

- vine|olive|fruit list and aptitude list:
- Added links to the respective viewer or editor module; actions availability are based on user's permissions [#163193](https://abacogroup.easyredmine.com/issues/163193)

### Changed

- Added alert on alignment is in progress [#164331](https://abacogroup.easyredmine.com/issues/164331)

# [2.1.3](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.1.1...v2.1.3) - 2025-01-31

### Fixed

- Include anomalies in getParcels API's [#162793](https://abacogroup.easyredmine.com/issues/162793)

# [2.1.1](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.1.0...v2.1.1) - 2025-01-29

### Fixed

- UI fix [#162274](https://abacogroup.easyredmine.com/issues/162274)

# [2.1.0](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.0.8...v2.1.0) - 2025-01-29

### Fixed

- Fixed sonarqube issues [#162124](https://abacogroup.easyredmine.com/issues/162124)

### Changed

- Added FORCED_CONTEXT to BASE constant

# [2.0.8](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.0.6...v2.0.8') - 2025-01-21

### Changed

- Changed openViewerUrl's redirect url

# [2.0.6](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.0.5...v2.0.6) - 2025-01-07

### Fixed

- Update i18n labels [#160407](https://abacogroup.easyredmine.com/issues/160407)

- Fixed planting day format in ParcelDetail's views [#160413](https://abacogroup.easyredmine.com/issues/160413)

# [2.0.5](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.0.4...v2.0.5) - 2024-12-19

### Changed

- Update event binding from :onclick to @click in PaymentMethods components [#160034](https://abacogroup.easyredmine.com/issues/160034)

# [2.0.4](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.0.3...v2.0.4) - 2024-12-19

### Changed

- Update dependencies [#160034](https://abacogroup.easyredmine.com/issues/160034)

# [2.0.3](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v2.0.2...v2.0.3) - 2024-12-18

### Added

- Added dynamism for modes of variety and territory summary

### Fixed

- openAttitudeDetailUrl: changed redirect url [#156157](https://abacogroup.easyredmine.com/issues/156157)
- Update models for consistency in unit summaries

# [1.4.6](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.4.5...v1.4.6) - 2024-11-11

### Changed

- openAttitudeDetailUrl: changed redirect url [#156157](https://abacogroup.easyredmine.com/issues/156157)

# [1.4.5](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.4.2...v1.4.5) - 2024-11-07

### Added

- Generalized the translation file and created ad hoc translations for each type: FRUIT|OLIVE|VINE variants
- Standardized the layout of VineUnitDetails with LPIS Viewer [#156151](https://abacogroup.easyredmine.com/issues/156151)
- Fixed model data [#156152](https://abacogroup.easyredmine.com/issues/156152)

### Changed

- Fixed vine-gis-server resources query params [#156147](https://abacogroup.easyredmine.com/issues/156147)

### Fixed

- Change labels and visibility [#156153](https://abacogroup.easyredmine.com/issues/156153)

# [1.4.2](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.4.0...v1.4.2) - 2024-11-05

### Changed

- Hide condicting detail section

# [1.4.0](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.3.0...v1.4.0) - 2024-10-22

### Added

- Readonly payment methods, the user requires DDM_PAYMENT_METHODS|EDITOR to activate editing capabilities. [#154445](https://abacogroup.easyredmine.com/issues/154445)

# [1.3.0](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.40...v1.3.0) - 2024-10-10

### Added

- Templating v1.2 [#144523](https://abacogroup.easyredmine.com/issues/144523)

### Fixed

- vine-unit: fixed titles [#153616](https://abacogroup.easyredmine.com/issues/153616)

# [1.2.40](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.39...v1.2.40) - 2024-08-02

### Added

- Moved and added PAGE_SIZE constant

# [1.2.39](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.38...v1.2.39) - 2024-08-01

### Fixed

- confirmModal button's color property

# [1.2.38](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.37...v1.2.38) - 2024-07-31

### Added

- Vine unit: added load more button in paginate lists tables

### Changed

- Upgrade dependencies

# [1.2.37](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.35...v1.2.37) - 2024-07-31

### Changed

- Aptitudes Uv list: Fixed area sqm to area ha

# [1.2.35](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.34...v1.2.35) - 2024-07-30

### Changed

- Update main_variety intrnationalization

# [1.2.34](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.33...v1.2.34) - 2024-07-26

### Added

- Task [#144522](https://abacogroup.easyredmine.com/issues/144522):
    - Converted on AuthorizationSummary mock-up methods to real ones, modified interfaces
    - Remaining Authorisation APIs added and hooked up
    - Converted on QuotasSummary mock-up methods to real ones, modified interfaces, added and hookead up APIs
    - Converted on Aptitudes mock-up methods to real ones, modified interfaces, added and hookead up APIs
    - Modified Aptitudes templates and EPs
    - Convert y/n status to enum and add emptyFieldPlaceholder and AlertMessage where needed
    - Update dependency and add 'load-more' button on paginated responses

### Fixed

- NewBankAccountForm: fixed confirm modal's confirm button color [#141722](https://abacogroup.easyredmine.com/issues/141722)

# [1.2.33](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.32...v1.2.33) - 2024-05-08

### Fixed

- Fixed icon [#138613](https://abacogroup.easyredmine.com/issues/138613)

# [1.2.32](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.31...v1.2.32) - 2024-05-03

### Fixed

- Use server date format when calling vine unit endpoints [#138562](https://abacogroup.easyredmine.com/issues/138562)

# [1.2.31](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.30...v1.2.31) - 2024-05-02

### Fixed

- show title inside TopBar [#138154](https://abacogroup.easyredmine.com/issues/138154)

### Added

- add and use vine unit translations instead of tree units [#137890](https://abacogroup.easyredmine.com/issues/137890)
- store parcel filters as url query params [#137710](https://abacogroup.easyredmine.com/issues/137710)

# [1.2.30](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.29...v1.2.30) - 2024-04-29

### Fixed

- Add back url to map icon button [#137710](https://abacogroup.easyredmine.com/issues/137710)

# [1.2.29](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.28...v1.2.29) - 2024-04-29

### Fixed

- Anomalous behaviour when navigating backwards [#137081](https://abacogroup.easyredmine.com/issues/137081)

# [1.2.28](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.27...v1.2.28) - 2024-04-22

### Fixed

- Show sector and block inside parcels list [#137078](https://abacogroup.easyredmine.com/issues/137078)
- Sort parcels and vine units by code [#137068]
- Show vine unit code instead of id [#137084](https://abacogroup.easyredmine.com/issues/137084)

# [1.2.27](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.26...v1.2.27) - 2024-03-13

### Fixed

- Fixed sonarqube issues [#133766](https://abacogroup.easyredmine.com/issues/133766)

# [1.2.26](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.22...v1.2.26) - 2024-03-05

### Fixed

- Fixed translations:
    - [#132890](https://abacogroup.easyredmine.com/issues/132890)
    - [#132889](https://abacogroup.easyredmine.com/issues/132889)

# [1.2.22](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.21...v1.2.22) - 2024-02-26

### Fixed

- Fixed duoble "/" inloadLocaleMessages

# [1.2.21](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.19...v1.2.21) - 2024-02-26

### Changed

- Parcels filter: "reset" button resets form without applying filters [#131758](https://abacogroup.easyredmine.com/issues/131758)

- Removed anomaly filter [#131758](https://abacogroup.easyredmine.com/issues/131758)

- Bank accounts filter: "reset" button resets form without applying filters

# [1.2.18](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.17...v1.2.18) - 2024-02-23

### Changed

- Fixed parcels filter reset [#131758](https://abacogroup.easyredmine.com/issues/131758)

# [1.2.17](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.16...v1.2.17) - 2024-02-15

### Changed

- Refactored NewBankAccounForm validation [#129553](https://abacogroup.easyredmine.com/issues/129553)

# [1.2.16](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.15...v1.2.16) - 2024-02-13

### Added

- PaymentMethods -> NewBankAccounForm, added regex validation for iban [#129553](https://abacogroup.easyredmine.com/issues/129553)

# [1.2.13](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.12...v1.2.13) - 2024-01-31

### Changed

- Major refactor: better modules separation

# [1.2.12](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.11...v1.2.12) - 2024-01-26

### Changed

- Refactored TitleBar

### Fixed

- Fixed parcel and vine unit title's

# [1.2.10](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.9...v1.2.10) - 2024-01-25

### Fixed

- Fixed type check

# [1.2.9](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.8...v1.2.9) - 2024-01-25

### Changed

- Refactor VineUnitSchema

# [1.2.8](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.7...v1.2.8) - 2024-01-24

### Changed

- Refactor openViewerUrl

# [1.2.7](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.6...v1.2.7) - 2024-01-24

### Changed

- Remove empty string filter parameters in getParcels

# [1.2.5](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.4...v1.2.5) - 2024-01-18

### Added

- Handle forced context fron env variables

# [1.2.4](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.3...v1.2.4) - 2023-12-11

### Fixed

- Fixed backUrl

# [1.2.0](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.2.0...v1.2.0) - 2023-11-24

### Changed

- Upgraded abaco to safe-rest: 2.1.3

# [1.1.0](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.0.4...v1.1.0) - 2023-11-24

### Changed

- Upgraded to micro-frontend-http-server:v1.2.2

# [1.0.4'](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.0.3...v1.0.4) - 2023-11-21

### Fixed

- Fixed ui [#123760](https://abacogroup.easyredmine.com/issues/123760)

# [1.0.3'](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.0.2...v1.0.3) - 2023-11-15

### Fixed

- Fixed ui and bank account detail bugs

### Changed

- Major refactor due to new modules implementation (ex: vite-unit)

# [1.0.2'](https://gitlab.fe.abacogroup.eu/new-agri/dossier-data-modules-ui/-/compare/v1.0.1...v1.0.2) - 2023-11-13

### Fixed

- Fixed multiple bank account creation on double click

### Added

- Show success operation message on edit operation
- Anomalies are recalculated on Dynamic Documents change [#121863](https://abacogroup.easyredmine.com/issues/121863)
