import vue from "@vitejs/plugin-vue";
import { execSync } from "child_process";
import { fileURLToPath, URL } from "url";
import { defineConfig, loadEnv, type ConfigEnv } from "vite";
import { viteStaticCopy } from "vite-plugin-static-copy";
import nodePackage from "./package.json";
import VueDevTools from "vite-plugin-vue-devtools";

export default function (config: ConfigEnv) {
    process.env = {
        ...process.env,
        ...loadEnv(config.mode, process.cwd(), ["VITE"]),
        VITE_APP_VERSION: nodePackage.version,
        VITE_APP_GIT_COMMIT: execSync("git rev-parse --short=8 HEAD")
            .toString()
            .trim(),
    };
    const forceContext = process.env.VITE_FORCED_CONTEXT ?? "";
    // https://vitejs.dev/config/
    return defineConfig({
        base: forceContext + process.env.VITE_BASE,
        plugins: [
            viteStaticCopy({
                targets: [
                    {
                        src: "node_modules/bootstrap-italia/dist/**/*",
                        dest: "bootstrap-italia/dist",
                    },
                ],
            }),
            vue(),
            VueDevTools(),
        ],
        resolve: {
            alias: {
                "@": fileURLToPath(new URL("./src", import.meta.url)),
            },
        },
        css: {
            devSourcemap: true,
        },
        build: {
            rollupOptions: {
                output: {
                    entryFileNames: "[name].[hash].js",
                    assetFileNames: "assets/[name].[hash].[ext]",
                },
            },
        },
        server: {
            port: 3000,
            proxy: {
                [forceContext + "/vine-gis-server"]: {
                    target: "https://iacs-dev.fe.abacogroup.eu/",
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    secure: false,
                    changeOrigin: true,
                },
                [forceContext + "/olive-gis-server"]: {
                    target: "https://iacs-dev.fe.abacogroup.eu/",
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    secure: false,
                    changeOrigin: true,
                },
                [forceContext + "/customer-vine-link"]: {
                    target: "https://iacs-dev.fe.abacogroup.eu/",
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    secure: false,
                    changeOrigin: true,
                },
                [forceContext + "/customer-olive-link"]: {
                    target: "https://iacs-dev.fe.abacogroup.eu/",
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    secure: false,
                    changeOrigin: true,
                },
                [forceContext + "/dossier-data-modules"]: {
                    target: "https://iacs-dev.fe.abacogroup.eu/",
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    secure: false,
                    changeOrigin: true,
                },
                [forceContext + "/file-store"]: {
                    target: "https://iacs-dev.fe.abacogroup.eu/",
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    secure: false,
                    changeOrigin: true,
                },
                [forceContext + "/sso2"]: {
                    target: "https://iacs-dev.fe.abacogroup.eu/",
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    secure: false,
                    changeOrigin: true,
                },
                [forceContext + "/party-registry"]: {
                    target: "https://iacs-dev.fe.abacogroup.eu/",
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    changeOrigin: true,
                    secure: false,
                },
                [forceContext + "/avepa-legacy"]: {
                    target: "https://iacs-dev.fe.abacogroup.eu/",
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    changeOrigin: true,
                    secure: false,
                },
                [forceContext + "/fruit-gis-server"]: {
                    target: "https://iacs-dev.fe.abacogroup.eu/",
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    secure: false,
                    changeOrigin: true,
                },
                [forceContext + "/vinealign-server"]: {
                    target: "https://iacs-dev.fe.abacogroup.eu/",
                    // target: "https://agea-dev.fe.abacogroup.eu",
                    secure: false,
                    changeOrigin: true,
                },
            },
        },
    });
}
