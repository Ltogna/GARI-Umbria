<script setup lang="ts">
import { computed, inject, onMounted } from "vue";
import { useRouter } from "vue-router";
import { useI18n } from "vue-i18n";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { useApplicationStore } from "@/stores/applicationStore";
import SubjectSearchForm from "@/components/ApplicationSearch/SubjectSearchForm.vue";
import TopBar from "@/components/TopBar.vue";

const moduleId = inject("moduleId");
const router = useRouter();
const { getColor } = useColors();
const applicationStore = useApplicationStore();
const { t } = useI18n({});
const selectedSubject = computed(() => applicationStore.getSelectedSubject);

onMounted(async () => {
  applicationStore.setSelectedSubject(null);
  applicationStore.clearApplicationStatusFilters();
});

async function goBack() {
  applicationStore.clearApplicationStatusFilters();
  router.push({
    name: "applicationList",
  });
}

async function goToCreateApplication() {
  router.push({
    name: "createApplication",
    params: {
      partyId: selectedSubject.value?.partyId,
    },
  });
}
</script>

<template>
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded']">
      <template #card-header>
        <TopBar
          :isBackButton="true"
          :backButtonFunction="() => goBack()"
          :title="t(`${moduleId}.searchForm.newApplication`)"
        />
      </template>
      <template #card-body>
        <div
          id="searchContainer"
          class="row col-12 px-3 pt-5 justify-content-center"
        >
          <div class="col-1"></div>
          <div id="searchContainer" class="row col-11 justify-content-center">
            <SubjectSearchForm> </SubjectSearchForm>
          </div>
        </div>
        <div class="d-flex justify-content-center">
          <BiButton
            :is-disabled="selectedSubject == null"
            type="submit"
            isPrimary
            size="lg"
            class="btn"
            :class="getColor('button', 'success')"
            @click.stop="goToCreateApplication()"
            >{{ t(`${moduleId}.general.proceed`) }}</BiButton
          >
        </div>
      </template>
    </BiCard>
  </div>
</template>
