<script setup lang="ts">
import { inject, ref, onMounted, computed, watch } from "vue";
import { useRouter } from "vue-router";
import { useI18n } from "vue-i18n";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { useApplicationStore } from "@/stores/applicationStore";
import SubjectSearchForm from "@/components/ApplicationSearch/SubjectSearchForm.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import TopBar from "@/components/TopBar.vue";
import { checkMaxLength, verifyField } from "@/utils/formUtils";
import type { ValidatedInput } from "@/models/form";

const moduleId = inject("moduleId");
const router = useRouter();
const { getColor } = useColors();
const applicationStore = useApplicationStore();
const { t } = useI18n({});
const showNoApplicationAlert = ref<boolean>(false);
const searchFormVisible = ref<boolean>(false);

const searchFormRef = ref();

const applicationFilter = computed(
  () => applicationStore.getApplicationListStatusFilter,
);

const selectedSubject = computed(() => applicationStore.getSelectedSubject);

const applicationList = computed(() => applicationStore.getApplicationList);

const applicationDetails = computed(
  () => applicationStore.getApplicationDetails,
);

const searchFormValidators = ref<Record<string, ValidatedInput<string>>>({
  application_number: {
    val: applicationFilter.value.applicationNumber,
    errors: [],
  },
});

onMounted(async () => {
  applicationStore.setSelectedSubject(null);
  applicationStore.clearApplicationStatusFilters();
});

function navigateToCreateNewApplication() {
  applicationStore.clearApplicationStatusFilters();
  router.push({
    name: "newApplication",
  });
}

async function searchApplicationList() {
  searchFormValidators.value.application_number.val =
    applicationFilter.value.applicationNumber;

  const maxLengthErrorMessage = t(`${moduleId}.general.maxLength`);
  const errors: boolean[] = [];
  errors.push(
    verifyField(
      [
        () =>
          checkMaxLength(
            searchFormValidators.value.application_number,
            12,
            maxLengthErrorMessage,
          ),
      ],
      searchFormValidators.value.application_number,
    ),
  );

  if (errors.findIndex((x: boolean) => x) !== -1) return;

  showNoApplicationAlert.value = false;
  applicationStore.clearApplicationSummaryList();
  applicationStore.clearApplicationSummaryDetailList();
  if (applicationFilter.value.referenceSubject && selectedSubject.value) {
    await applicationStore.loadApplicationSummaryList(
      selectedSubject.value.partyId,
    );

    if (
      applicationStore.hasError &&
      applicationStore.getErrorResponse?.response.status === 404
    ) {
      showNoApplicationAlert.value = true;
    } else if (
      applicationList.value &&
      applicationList.value.applicationsSummaryByYear.length >= 1
    )
      router.push({
        name: "applicationListResults",
        params: {
          partyId: selectedSubject.value.partyId,
        },
        query: { backUrl: "" },
      });
  } else if (applicationFilter.value.applicationNumber) {
    await applicationStore.loadApplicationDetails(
      parseInt(applicationFilter.value.applicationNumber),
    );
    if (
      applicationStore.hasError &&
      applicationStore.getErrorResponse?.response.status === 404
    ) {
      showNoApplicationAlert.value = true;
    } else if (applicationDetails.value != null) {
      window.sessionStorage.setItem("backTo", "searchForm");
      router.push({
        name: "applicationDetail",
        params: {
          applicationId: applicationFilter.value.applicationNumber,
        },
        query: { backUrl: "" },
      });
    }
  }
}

function getSearchFormVisibility(value: boolean) {
  searchFormVisible.value = value;
  if (value === false) showNoApplicationAlert.value = false;
}

const disableButton = computed(() => {
  return (
    applicationStore.getIsLoading === true ||
    applicationStore.getTenantConfigPartyRegistryError ||
    (applicationFilter.value.referenceSubject === "" &&
      applicationFilter.value.applicationNumber === "")
  );
});

function clearAllFilters() {
  applicationStore.clearApplicationStatusFilters();
  searchFormValidators.value.application_number.errors = [];
}

watch(
  () => applicationFilter.value.applicationNumber,
  () => {
    if (applicationFilter.value.applicationNumber !== "") {
      applicationStore.setApplicationListFilter({
        referenceSubject: "",
        applicationNumber: applicationFilter.value.applicationNumber,
      });
    } else {
      searchFormValidators.value.application_number.errors = [];
    }
  },
);
</script>

<template>
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded']">
      <template #card-header>
        <TopBar
          :title="t(`${moduleId}.searchForm.applications`)"
          :buttonList="[
            {
              hideButton: applicationStore.isFunctionReadOnly,
              text: t(`${moduleId}.searchForm.newApplication`),
              classes: `${getColor('button', 'primary', 'outline')} py-2`,
              callback: navigateToCreateNewApplication,
            },
          ]"
        />
      </template>
      <template #card-body>
        <div class="container col-12 px-3 mx-0">
          <form
            id="taskSearchForm"
            class="needs-validation pt-5"
            ref="searchFormRef"
            @submit.prevent="() => {}"
          >
            <div id="searchContainer" class="row">
              <SubjectSearchForm
                @search-form-visible="getSearchFormVisibility"
              ></SubjectSearchForm>
              <div class="form-group col-xs-12 col-sm-12 col-md-4 col-lg-4">
                <BiInput
                  type="number"
                  hideArrows
                  :label="t(`${moduleId}.searchForm.applicationNumber`)"
                  :placeholder="t(`${moduleId}.general.insertCode`)"
                  v-model="applicationFilter.applicationNumber"
                  :errors="searchFormValidators.application_number.errors"
                />
              </div>
            </div>
          </form>

          <div v-if="showNoApplicationAlert" class="row">
            <div class="col-3"></div>
            <div class="mt-3 col-6">
              <BiAlert isWarn>
                <template #body>{{
                  t(
                    `${moduleId}.searchForm.errors.NO_APPLICATION_FOUND_EXCEPTION`,
                  )
                }}</template>
              </BiAlert>
            </div>
            <div class="col-3"></div>
          </div>

          <div
            class="d-flex justify-content-center"
            v-if="applicationStore.loading && !searchFormVisible"
          >
            <BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
          </div>

          <div class="mt-0 mb-1 d-flex justify-content-center pt-md-5">
            <BiButton
              size="lg"
              class="btn"
              :class="getColor('button', 'secondary', 'outline')"
              @click.stop="clearAllFilters()"
            >
              {{ t(`${moduleId}.general.cancel`) }}
            </BiButton>
            <BiButton
              :is-disabled="disableButton"
              type="submit"
              form="taskSearchForm"
              isPrimary
              size="lg"
              class="ms-3 btn"
              :class="getColor('button', 'success')"
              @click.stop="searchApplicationList()"
              >{{ t(`${moduleId}.general.search`) }}</BiButton
            >
          </div>
        </div>
      </template>
    </BiCard>
  </div>
</template>
