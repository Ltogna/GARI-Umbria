<script setup lang="ts">
// Vue
import { inject, ref } from "vue";
import { useI18n } from "vue-i18n";

//Boootstrap Italia components
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import BiTextarea from "@abaco/bootstrap-italia-components/src/components/form/BiTextarea.vue";
import BiUpload from "@/components/tempComponent/BiUpload.vue";

const moduleId = inject("moduleId");
const { t } = useI18n({});
const { getColor } = useColors();

const isAddModalOpen = ref<boolean>(false);
const isEditModalOpen = ref<boolean>(false);

const attachmentTypeList = ref([
  {
    id: "1",
    text: "type 1",
  },
  {
    id: "2",
    text: "type 2",
  },
]);

const formValue = ref({
  attachmentType: "",
  notes: "",
  attachment: null,
});

const mockResponse = ref([
  {
    attachmentType: "Documento di riconoscimento",
    notes: "",
  },
  {
    attachmentType: "Domanda cartacea firmata",
    notes: "Copia del certificato 123",
  },
]);
</script>
<template>
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded']">
      <template #card-header> </template>
      <template #card-body>
        <div class="container col-12 px-3 mx-0">
          <BiTable
            class="table-responsive"
            extraTableClasses="table-head-bg"
            isResponsive
          >
            <template v-slot:head>
              <tr
                class="bg-light text-start"
                :class="getColor('text', 'secondary')"
              >
                <th scope="col">
                  {{ t(`${moduleId}.attachmentsCard.table.attachmentType`) }}
                </th>
                <th scope="col">
                  {{ t(`${moduleId}.attachmentsCard.table.notes`) }}
                </th>
                <th scope="col"></th>
              </tr>
            </template>
            <template
              v-slot:body
              v-if="mockResponse && mockResponse.length > 0"
            >
              <tr
                class="align-middle"
                v-for="element in mockResponse"
                :key="JSON.stringify(element)"
              >
                <td
                  :data-label="
                    t(`${moduleId}.attachmentsCard.table.attachmentType`)
                  "
                  class="text-start"
                >
                  {{ element.attachmentType || "" }}
                </td>
                <td
                  :data-label="t(`${moduleId}.attachmentsCard.table.notes`)"
                  class="text-start"
                >
                  {{ element.notes || "" }}
                </td>
                <td class="text-end">
                  <BiButton
                    :isIcon="true"
                    @click.stop="() => {}"
                    :width="40"
                    class="mx-1 my-0"
                    :class="`${getColor('button', 'primary', 'outline')}`"
                  >
                    <BiIcon icon="download" size="xl" icon-style="regular" />
                  </BiButton>
                  <BiButton
                    :isIcon="true"
                    @click.stop="isEditModalOpen = true"
                    :width="40"
                    class="mx-1 my-0"
                    :class="`${getColor('button', 'success', 'outline')}`"
                  >
                    <BiIcon icon="pencil" size="xl" icon-style="regular" />
                  </BiButton>
                  <BiButton
                    :isIcon="true"
                    @click.stop="() => {}"
                    isPrimary
                    :width="40"
                    class="mx-1 my-0"
                    :class="`${getColor('button', 'danger', 'outline')}`"
                  >
                    <BiIcon icon="trash" size="xl" icon-style="regular" />
                  </BiButton>
                </td>
              </tr>
            </template>
          </BiTable>
          <div class="w-100 text-center">
            <BiButton
              @click.stop="isAddModalOpen = true"
              class="mx-1 my-0"
              :class="`${getColor('button', 'primary', 'outline')}`"
            >
              {{ t(`${moduleId}.attachmentsCard.newAttachment`) }}
            </BiButton>
          </div>
        </div>
      </template>
    </BiCard>
  </div>

  <!-- Add Attachment Modal -->
  <BiModal
    :disabled-teleport="true"
    :extra-footer-class="'justify-content-center'"
    v-model="isAddModalOpen"
    :aria-labelledby="t(`${moduleId}.attachmentsCard.addModal.title`)"
    :title="t(`${moduleId}.attachmentsCard.addModal.title`)"
    :prevent-dismiss="false"
  >
    <template #body>
      <div class="col-12 mb-5">
        <BiSelect
          name="attachmentType"
          :id="'attachmentType'"
          :isMultiple="false"
          :isAutocomplete="false"
          :emptyOption="
            t(`${moduleId}.attachmentsCard.addModal.form.attachmentType`)
          "
          :items="attachmentTypeList ?? []"
          v-model="formValue.attachmentType"
        ></BiSelect>
      </div>
      <div class="col-12 mb-5">
        <BiTextarea
          :label="t(`${moduleId}.attachmentsCard.addModal.form.notes`)"
          v-model="formValue.notes"
        />
      </div>
      <div class="col-12 mb-5">
        <BiUpload></BiUpload>
      </div>
    </template>
    <template #footer>
      <div class="mt-3 mb-5 d-flex justify-content-center w-100">
        <BiButton
          class="mx-1"
          :class="getColor('button', 'secondary', 'outline')"
          @click.stop="isAddModalOpen = false"
          >{{ t(`${moduleId}.general.cancel`) }}
        </BiButton>
        <BiButton
          class="mx-1"
          isPrimary
          :class="getColor('button', 'success')"
          @click.stop="isAddModalOpen = false"
          >{{ t(`${moduleId}.general.save`) }}
        </BiButton>
      </div>
    </template>
  </BiModal>
  <!-- Add Attachment Modal -->

  <!-- Edit Attachment Modal -->
  <BiModal
    :disabled-teleport="true"
    :extra-footer-class="'justify-content-center'"
    v-model="isEditModalOpen"
    :aria-labelledby="t(`${moduleId}.attachmentsCard.editModal.title`)"
    :title="t(`${moduleId}.attachmentsCard.editModal.title`)"
    :prevent-dismiss="false"
  >
    <template #body>
      <div class="col-12 mb-5">
        <BiSelect
          name="attachmentType"
          :id="'attachmentType'"
          :isMultiple="false"
          :isAutocomplete="false"
          :emptyOption="
            t(`${moduleId}.attachmentsCard.editModal.form.attachmentType`)
          "
          :items="attachmentTypeList ?? []"
          v-model="formValue.attachmentType"
        ></BiSelect>
      </div>
      <div class="col-12 mb-5">
        <BiTextarea
          :label="t(`${moduleId}.attachmentsCard.editModal.form.notes`)"
          v-model="formValue.notes"
        />
      </div>
    </template>
    <template #footer>
      <div class="mt-3 mb-5 d-flex justify-content-center w-100">
        <BiButton
          class="mx-1"
          :class="getColor('button', 'secondary', 'outline')"
          @click.stop="isEditModalOpen = false"
          >{{ t(`${moduleId}.general.cancel`) }}</BiButton
        >
        <BiButton
          class="mx-1"
          isPrimary
          :class="getColor('button', 'success')"
          @click.stop="isEditModalOpen = false"
          >{{
            t(`${moduleId}.attachmentsCard.editModal.confirmEdit`)
          }}</BiButton
        >
      </div>
    </template>
  </BiModal>
  <!-- Edit Attachment Modal -->
</template>
