<script setup lang="ts">
import { inject } from "vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { useRoute } from "vue-router";
import { useI18n } from "vue-i18n";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
const { t } = useI18n();
const moduleId = inject("moduleId");
const { getColor } = useColors();

const route = useRoute();

const partyId = parseInt(route.query?.partyId as string) || null;

function goToDetail() {
  const parentModuleDeployDir = "dossier",
    basePath =
      window.location.href.indexOf(`/${parentModuleDeployDir}`) > -1
        ? window.location.href.split(`/${parentModuleDeployDir}`)[0]
        : window.location.origin,
    detailUrl = `${basePath}/${moduleId}/applicationlist/party/${partyId}/result`,
    targetUrl = window.location.href.replace(window.location.origin, "");
  window.location.assign(
    detailUrl + `?backUrl=${encodeURIComponent(targetUrl)}`,
  );
}
</script>

<template>
  <div class="container">
    <div class="row my-3 justify-content-start">
      <div class="col-12 my-3">
        <h4 class="fw-bold" :class="getColor('text', 'primary')">
          <BiIcon class="mx-2" icon="file-lines" size="lg" />
          {{ t(`${moduleId}.dossiersSummary.title`) }}
        </h4>
      </div>
    </div>
    <BiAlert isInfo class="mb-5">
      <template #body>{{
        t(`${moduleId}.dossiersSummary.noSummaryDataAlert`)
      }}</template>
    </BiAlert>
    <div class="row mt-5">
      <div class="col-12 d-flex justify-content-center">
        <BiButton color="success" @click="goToDetail()">
          {{ t(`${moduleId}.dossiersSummary.detail`) }}
        </BiButton>
      </div>
    </div>
  </div>
</template>
