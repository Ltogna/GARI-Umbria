<script setup lang="ts">
// Vue
import {
  inject,
  computed,
  onBeforeUnmount,
  watchEffect,
  onMounted,
  ref,
  type Ref,
} from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";

//Boootstrap Italia components
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";

//State manager
import { useApplicationStore } from "@/stores/applicationStore";
import ApplicationList from "@/components/ApplicationList/ApplicationList.vue";
import TopBar from "@/components/TopBar.vue";

const moduleId = inject("moduleId");
const applicationStore = useApplicationStore();
const router = useRouter();
const route = useRoute();
const { t } = useI18n({});
const { getColor } = useColors();

const backUrl: Ref<string | null> = ref(null);

const partyIdRoute = computed(() => parseInt(route.params.partyId as string));

const applicationList = computed(
  () => applicationStore.getApplicationList?.applicationsSummaryByYear ?? [],
);

const backFromDetail = computed(() => {
  return parseInt(route.query.backFromDetail as string);
});

const partyId = computed(() => {
  return applicationStore.getSelectedSubject?.partyId || partyIdRoute.value;
});
const cuaa = computed(() => {
  return applicationStore.getSelectedSubject?.code ?? null;
});
const name = computed(() => {
  return applicationStore.getSelectedSubject?.description ?? null;
});

onMounted(async () => {
  if (backFromDetail.value) {
    await applicationStore.loadApplicationSummaryList(partyId.value);
  }
  //
  if (route.query.backUrl != null) {
    sessionStorage.setItem(
      `${moduleId}.backUrl`,
      route.query.backUrl as string,
    );
  }
  backUrl.value = sessionStorage.getItem(`${moduleId}.backUrl`);
});

watchEffect(async () => {
  if (partyIdRoute.value && !applicationStore.getApplicationList) {
    await Promise.allSettled([
      applicationStore.loadParty(partyIdRoute.value),
      applicationStore.loadApplicationSummaryList(partyIdRoute.value),
    ]);
  }
});

function goBack() {
  if (backUrl.value) {
    location.assign(decodeURIComponent(backUrl.value));
  } else {
    applicationStore.clearApplicationStatusFilters();
    router.push({
      name: "applicationList",
    });
  }
}

function goToNewApplication() {
  router.push({
    name: "createApplication",
    params: {
      partyId: partyIdRoute.value,
    },
  });
}

onBeforeUnmount(() => {
  // TODO Check this
  // applicationStore.clearApplicationSummaryList();
  // applicationStore.clearApplicationSummaryDetailList();
});
</script>
<template>
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded']">
      <template #card-header>
        <TopBar
          :isBackButton="true"
          :backButtonFunction="() => goBack()"
          :title="
            t(`${moduleId}.list.title`, {
              cuaa: cuaa,
              name: name,
            })
          "
          :buttonList="[
            {
              hideButton: applicationStore.isFunctionReadOnly,
              text: t(`${moduleId}.searchForm.newApplication`),
              classes: getColor('button', 'primary', 'outline'),
              callback: () => goToNewApplication(),
            },
          ]"
        />
      </template>
      <template #card-body>
        <div class="container col-12 px-3 mx-0">
          <div v-if="partyId && applicationList && applicationList.length > 0">
            <ApplicationList
              :applicationList="applicationList"
              :party-id="partyId"
            ></ApplicationList>
          </div>
        </div>
      </template>
    </BiCard>
  </div>
</template>
