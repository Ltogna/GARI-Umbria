<script setup lang="ts">
import { computed, inject, onMounted, watchEffect } from "vue";
import { useI18n } from "vue-i18n";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import { useApplicationStore } from "@/stores/applicationStore";
import CreateApplication from "@/components/CreateApplication/CreateApplication.vue";
import { useRoute, useRouter } from "vue-router";
import TopBar from "@/components/TopBar.vue";

const moduleId = inject("moduleId");
const router = useRouter();
const { t } = useI18n({});
const applicationStore = useApplicationStore();
const selectedSubject = computed(() => applicationStore.getSelectedSubject);
const route = useRoute();

const partyIdRoute = computed(() => parseInt(route.params.partyId as string));

watchEffect(async () => {
  if (partyIdRoute.value && !applicationStore.getApplicationModules) {
    await Promise.all([
      fetchData(),
      applicationStore.loadParty(partyIdRoute.value),
    ]);
  }
});

async function fetchData() {
  await applicationStore.loadApplicationModules();
}

onMounted(async () => {
  await fetchData();
});

function backToApplicationResult() {
  router.back();
}
</script>

<template>
  <div class="container my-5">
    <BiCard :extra-classes="['card-bg', 'rounded']">
      <template #card-header>
        <TopBar
          :isBackButton="true"
          :backButtonFunction="() => backToApplicationResult()"
          :title="
            t(`${moduleId}.cardContainer.header`, {
              cuaa: selectedSubject?.code,
              companyName: selectedSubject?.description,
            })
          "
        />
      </template>
      <template #card-body>
        <div class="container col-12 px-3 mx-0">
          <CreateApplication></CreateApplication>
        </div>
      </template>
    </BiCard>
  </div>
</template>
