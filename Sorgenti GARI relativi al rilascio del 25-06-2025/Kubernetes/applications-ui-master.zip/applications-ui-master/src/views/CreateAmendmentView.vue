<script setup lang="ts">
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import { useApplicationStore } from "@/stores/applicationStore";
import CreateAmendment from "@/components/CreateAmendment/CreateAmendment.vue";
import { useRoute, useRouter } from "vue-router";
import TopBar from "@/components/TopBar.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";

const moduleId = inject("moduleId");
const router = useRouter();
const { t } = useI18n({});
const applicationStore = useApplicationStore();
const selectedSubject = computed(() => applicationStore.getSelectedSubject);
const route = useRoute();

const applicationId = route.query.applicationId as string;

const partyIdRoute = computed(() => parseInt(route.params.partyId as string));

const applicationDetails = computed(
  () => applicationStore.getApplicationDetails,
);

/* watchEffect(async () => {
  if (partyIdRoute.value && !applicationStore.getApplicationModules) {
    await Promise.all([
      fetchData(),
      applicationStore.loadParty(partyIdRoute.value),
    ]);
  }
}); */

const isMounted = ref<boolean>(false);

async function fetchData() {
  await applicationStore.loadApplicationDetails(parseInt(applicationId));
  await applicationStore.loadAmendmentModules(parseInt(applicationId));
  isMounted.value = true;
}

onMounted(async () => {
  await fetchData();
});

function backToApplicationResult() {
  router.push({
    name: "applicationListResults",
    params: {
      partyId: partyIdRoute.value,
    },
    query: {
      backFromDetail: "1",
    },
  });
}
</script>

<template>
  <div class="container my-5">
    <BiCard v-if="isMounted" :extra-classes="['card-bg', 'rounded']">
      <template #card-header>
        <TopBar
          :isBackButton="true"
          :backButtonFunction="() => backToApplicationResult()"
          :title="
            t(`${moduleId}.applicationDetails.title`, {
              moduleDescription: applicationDetails?.moduleDescription ?? '',
              id: applicationId,
            }) +
            (applicationDetails?.referredYear
              ? t(`${moduleId}.applicationDetails.titleYear`, {
                  year: applicationDetails.referredYear,
                })
              : '')
          "
        />
      </template>
      <template #card-body>
        <div class="container col-12 px-3 mx-0">
          <CreateAmendment
            :application-id="applicationId"
            :partyId="selectedSubject?.partyId"
          ></CreateAmendment>
        </div>
      </template>
    </BiCard>
    <div v-else class="d-flex justify-content-center px-0">
      <BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
    </div>
  </div>
</template>
