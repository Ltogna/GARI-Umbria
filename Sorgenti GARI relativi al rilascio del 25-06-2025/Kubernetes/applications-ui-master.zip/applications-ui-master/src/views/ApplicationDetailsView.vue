<script setup lang="ts">
import ApplicationCalculationsModal from "@/components/ApplicationDetails/ApplicationCalculationsModal.vue";
import ApplicationChangeStatusModal from "@/components/ApplicationDetails/ApplicationChangeStatusModal.vue";
import CalculationsHistory from "@/components/ApplicationDetails/ApplicationHistory/CalculationsHistory.vue";
import MovementHistory from "@/components/ApplicationDetails/ApplicationHistory/MovementHistory.vue";
import PrintHistory from "@/components/ApplicationDetails/ApplicationHistory/PrintHistory.vue";
import ApplicationPrintModal from "@/components/ApplicationDetails/ApplicationPrintModal.vue";
import CalculationDetails from "@/components/ApplicationDetails/CalculationDetails.vue";
import CardCentralBox from "@/components/ApplicationDetails/CardCentralBox.vue";
import SecondLevelCard from "@/components/ApplicationDetails/CardMenu/SecondLevelCard.vue";
import SecondLevelCardAccordion from "@/components/ApplicationDetails/CardMenu/SecondLevelCardAccordion.vue";
import GenericApplicationInfo from "@/components/ApplicationDetails/GenericApplicationInfo.vue";
import TopBar from "@/components/TopBar.vue";
import {
  CardState,
  fromFormDetailsModelToSelectedCard,
  type ApplicationAnomalyModel,
  type CardNode,
  type FormDetailsModel,
  type FormGroupModel,
  type FormModel,
  type SelectedCard,
} from "@/models/application";
import { cleanBasePath } from "@/models/utils";
import { useApplicationStore } from "@/stores/applicationStore";
import { getFormattedDate } from "@/utils/dateUtils";
import { extractModuleId, wait } from "@/utils/formUtils";
import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiCard from "@abaco/bootstrap-italia-components/src/components/BiCard/BiCard.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import {
  computed,
  inject,
  onMounted,
  onUnmounted,
  ref,
  watch,
  type Ref,
} from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";
import CentralBoxHeader from "../components/ApplicationDetails/CentralBoxHeader.vue";
import type { AllowedTextPurposeType } from "@abaco/bootstrap-italia-components/src/models/colors";

enum AnomalySeverity {
  BLOCKING = "BLOCKING",
  NOT_BLOCKING = "NOT_BLOCKING",
  INFO = "INFO",
}

enum StaticRoutes {
  APPLICATION_HISTORY = "history",
  PRINT_HISTORY = "print-history",
  CALCULATIONS_HISTORY = "calculations-history",
  CALCULATION = "calculation",
}

interface AnomalyCount {
  blocking: number;
  notBlocking: number;
  info: number;
}

interface AnomalyButtonInfo {
  style: string;
  count: number;
}

const router = useRouter();
const route = useRoute();
const { getColor } = useColors();
const { t } = useI18n({});
const moduleId = inject("moduleId");
const basePath = inject("basePath");
const showAnomaliesModal = ref<boolean>(false);
// Summary of anomalies
const anomaliesCount = ref<AnomalyCount>({
  blocking: 0,
  notBlocking: 0,
  info: 0,
});
// Anomalies divided by categories
const blockingAnomalies = ref<ApplicationAnomalyModel[]>([]);
const notBlockingAnomalies = ref<ApplicationAnomalyModel[]>([]);
const infoAnomalies = ref<ApplicationAnomalyModel[]>([]);
const lastAnomaliesRecalcDate = computed(() => {
  if (
    applicationStore.getApplicationAnomalies &&
    applicationStore.getApplicationAnomalies.length > 0
  ) {
    const tmp = JSON.parse(
      JSON.stringify(applicationStore.getApplicationAnomalies),
    );
    const sorted = tmp.sort(
      (x: ApplicationAnomalyModel, y: ApplicationAnomalyModel) =>
        new Date(x.dtInsert).getTime() - new Date(y.dtInsert).getTime(),
    );
    return sorted[0].dtInsert;
  } else return null;
});

const selectedCardInfo = ref<SelectedCard | null>(null);
const showGenericApplicationData = ref<boolean>(true);
const showPrintHistory = ref<boolean>(false);
const showMovementHistory = ref<boolean>(false);
const showCalculationsHistory = ref<boolean>(false);
const showCalculationDetails = ref<boolean>(false);
const calculationJobUuidSelected = ref<string>();
const backUrl: Ref<string | null> = ref(null);

const openPrintModal = ref<boolean>(false);
const openCalculationsModal = ref<boolean>(false);
const prints = computed(
  () => applicationStore.getApplicationDetails?.prints || [],
);
const calculations = computed(
  () => applicationStore.getApplicationDetails?.calculations || [],
);
const componentTree = ref<CardNode[]>([]);
const applicationStore = useApplicationStore();
const changeStatusComponentVisible = ref<boolean>(false);
const applicationId = computed(() =>
  parseInt(route.params.applicationId as string),
);
const isLoadingTransitionData = ref<boolean>(false);
const cuaa = computed(() => {
  return applicationStore.getSelectedSubject?.code ?? "";
});

const utilityAccordionOpened = ref<boolean>(false);

const transitions = computed(() => applicationStore.getApplicationTransitions);

const applicationAnomalies = computed(
  () => applicationStore.getApplicationAnomalies,
);
const formList = computed(() => {
  return applicationStore.getApplicationDetails;
});

const anomaliesButtonInfo = computed(() => {
  let colorName: AllowedTextPurposeType = "success";
  let count = 0;
  if (anomaliesCount.value.blocking > 0) {
    colorName = "danger";
    count = anomaliesCount.value.blocking;
  } else if (anomaliesCount.value.notBlocking > 0) {
    colorName = "warning";
    count = anomaliesCount.value.notBlocking;
  } else if (anomaliesCount.value.info > 0) {
    colorName = "info";
    count = anomaliesCount.value.info;
  }
  return {
    style: `${getColor("button", colorName)}`,
    count: count,
  } as AnomalyButtonInfo;
});

const isInTransitionMessages = computed(
  () => applicationStore.getTransitionData,
);

watch(
  () => applicationId.value,
  async () => {
    await initPageLogic();
  },
);

const fixedRouteChunk = computed(() => {
  return `${cleanBasePath(basePath as string)}/applicationlist/result/${
    applicationId.value
  }/applicationDetails`;
});

//function that open application main data and close other view
function goToMainData(event?: Event, fromOpenCorrectPage?: boolean) {
  if (fromOpenCorrectPage) {
    showPrintHistory.value = false;
    showGenericApplicationData.value = true;
    showMovementHistory.value = false;
    showCalculationsHistory.value = false;
    showCalculationDetails.value = false;
  } else {
    router
      .push({
        path: `${fixedRouteChunk.value}`,
      })
      .then((value) => {
        if (!value) {
          showPrintHistory.value = false;
          showGenericApplicationData.value = true;
          showMovementHistory.value = false;
          showCalculationsHistory.value = false;
          showCalculationDetails.value = false;
        }
      });
  }
}

function showPrintHistoryView(event?: Event, fromOpenCorrectPage?: boolean) {
  if (fromOpenCorrectPage) {
    showGenericApplicationData.value = false;
    showPrintHistory.value = true;
    showMovementHistory.value = false;
    showCalculationsHistory.value = false;
    showCalculationDetails.value = false;
    utilityAccordionOpened.value = true;
  } else {
    router
      .push({
        path: `${fixedRouteChunk.value}/${StaticRoutes.PRINT_HISTORY}`,
      })
      .then((value) => {
        if (!value) {
          showGenericApplicationData.value = false;
          showPrintHistory.value = true;
          showMovementHistory.value = false;
          showCalculationsHistory.value = false;
          showCalculationDetails.value = false;
          utilityAccordionOpened.value = true;
        }
      });
  }
}
function showMovementView(event?: Event, fromOpenCorrectPage?: boolean) {
  if (fromOpenCorrectPage) {
    showPrintHistory.value = false;
    showGenericApplicationData.value = false;
    showMovementHistory.value = true;
    showCalculationsHistory.value = false;
    showCalculationDetails.value = false;
    utilityAccordionOpened.value = true;
  } else {
    router
      .push({
        path: `${fixedRouteChunk.value}/${StaticRoutes.APPLICATION_HISTORY}`,
      })
      .then((value) => {
        if (!value) {
          showPrintHistory.value = false;
          showGenericApplicationData.value = false;
          showMovementHistory.value = true;
          showCalculationsHistory.value = false;
          showCalculationDetails.value = false;
          utilityAccordionOpened.value = true;
        }
      });
  }
}

function showCalculationsHistoryView(
  event?: Event,
  fromOpenCorrectPage?: boolean,
) {
  if (fromOpenCorrectPage) {
    showPrintHistory.value = false;
    showGenericApplicationData.value = false;
    showMovementHistory.value = false;
    showCalculationsHistory.value = true;
    showCalculationDetails.value = false;
    utilityAccordionOpened.value = true;
  } else {
    router
      .push({
        path: `${fixedRouteChunk.value}/${StaticRoutes.CALCULATIONS_HISTORY}`,
      })
      .then((value) => {
        if (!value) {
          showPrintHistory.value = false;
          showGenericApplicationData.value = false;
          showMovementHistory.value = false;
          showCalculationsHistory.value = true;
          showCalculationDetails.value = false;
          utilityAccordionOpened.value = true;
        }
      });
  }
}

function openCard(cardInfo: SelectedCard, fromInit?: boolean) {
  const cardInfoUpdated = Object.assign({}, cardInfo);
  cardInfoUpdated.partyCode = cuaa.value;

  showGenericApplicationData.value = false;
  showGenericApplicationData.value = false;
  showMovementHistory.value = false;
  showPrintHistory.value = false;
  showCalculationDetails.value = false;
  showCalculationsHistory.value = false;
  selectedCardInfo.value = cardInfoUpdated;
  let urlToRoute = selectedCardInfo.value.routerUrl ?? "";
  if (urlToRoute && !urlToRoute.startsWith("/")) {
    urlToRoute = "/" + urlToRoute;
  }
  const pathToRoute = `${cleanBasePath(
    basePath as string,
  )}/applicationlist/result/${
    applicationId.value
  }/applicationDetails/${extractModuleId(cardInfo.softwareUrl)}${urlToRoute}`;

  if (!fromInit && pathToRoute !== route.path) {
    const routeToNavigate = router.currentRoute.value;
    delete routeToNavigate.query["tab"];
    delete routeToNavigate.query["operationCode"];
    router.replace({
      ...routeToNavigate,
    });
  }
}

function showCalculationDetailsView(
  event?: Event,
  fromOpenCorrectPage?: boolean,
  calculationJobUuid?: string,
) {
  calculationJobUuidSelected.value = calculationJobUuid;
  if (fromOpenCorrectPage) {
    showPrintHistory.value = false;
    showGenericApplicationData.value = false;
    showMovementHistory.value = false;
    showCalculationsHistory.value = false;
    showCalculationDetails.value = true;
    utilityAccordionOpened.value = true;
  } else {
    router
      .push({
        path: `${fixedRouteChunk.value}/${StaticRoutes.CALCULATION}/${calculationJobUuid}`,
      })
      .then((value) => {
        if (!value) {
          showPrintHistory.value = false;
          showGenericApplicationData.value = false;
          showMovementHistory.value = false;
          showCalculationsHistory.value = false;
          showCalculationDetails.value = true;
          utilityAccordionOpened.value = true;
        }
        openCalculationsModal.value = false;
      });
  }
}

watch(
  () => formList,
  () => {
    if (formList.value) {
      fromFormTotree();
    }
  },
  { deep: true },
);

function extractDestination(
  softwareUrl: string | undefined,
  destination: string,
) {
  const splitted = (softwareUrl ?? "").split("/");
  if (splitted.length > 0) {
    const appForms = splitted.indexOf(destination);
    if (appForms > -1) {
      const urlArray = [];
      for (let i = appForms + 1; i < splitted.length; i++) {
        urlArray.push(splitted[i]);
      }
      return "/" + urlArray.join("/");
    }
  }
  return undefined;
}

function extractModule(softwareUrl: string | undefined, moduleId: string) {
  const splitted = (softwareUrl ?? "").split("/");
  if (splitted.length > 0) {
    const appForms = splitted.indexOf(moduleId);
    if (appForms > -1) {
      return splitted[appForms + 1];
    }
  }
  return undefined;
}

async function goBack() {
  if (backUrl.value) {
    location.assign(decodeURIComponent(backUrl.value));
  } else {
    const backTo = window.sessionStorage.getItem("backTo");
    if (backTo === "applicationsList") {
      router.push({
        name: "applicationListResults",
        params: {
          partyId: formList.value.partyId,
        },
        query: {
          backFromDetail: "1",
        },
      });
    } else {
      router.push({
        name: "applicationList",
      });
    }
  }
}

function handleCloseModal(reloadData = true) {
  changeStatusComponentVisible.value = false;
  if (reloadData) {
    executeTransitionPolling(true);
  }
}

async function waitForCloseModalAndReload() {
  changeStatusComponentVisible.value = false;
}

async function initAnomaliesData() {
  await applicationStore.loadApplicationAnomalies(applicationId.value);
  notBlockingAnomalies.value = [];
  infoAnomalies.value = [];
  blockingAnomalies.value = [];
  anomaliesCount.value = {
    blocking: 0,
    notBlocking: 0,
    info: 0,
  } as AnomalyCount;
  if (applicationAnomalies.value && applicationAnomalies.value.length > 0) {
    applicationAnomalies.value.forEach((anomaly: ApplicationAnomalyModel) => {
      switch (anomaly.severity) {
        case AnomalySeverity.NOT_BLOCKING:
          notBlockingAnomalies.value.push(anomaly);
          break;
        case AnomalySeverity.INFO:
          infoAnomalies.value.push(anomaly);
          break;
        case AnomalySeverity.BLOCKING:
        default:
          blockingAnomalies.value.push(anomaly);
          break;
      }
    });
    anomaliesCount.value = {
      blocking: blockingAnomalies.value.length,
      notBlocking: notBlockingAnomalies.value.length,
      info: infoAnomalies.value.length,
    } as AnomalyCount;
  }
}

function isOpenPath(
  destinationUrl: string | undefined,
  destinationPath: FormDetailsModel,
): boolean {
  let isOpen = false;
  if (
    destinationUrl !== undefined &&
    destinationPath.routerUrl !== null &&
    destinationPath.routerUrl.includes(destinationUrl)
  ) {
    isOpen = true;
  }
  return isOpen;
}
/**
 * Function that allows you to hang a new branch in the right position within the tree
 * @param groupPath Branch to be integrated into the tree
 */
function appendPath(
  groupPath: (FormDetailsModel | FormGroupModel)[],
  destinationUrl?: string,
) {
  const destinationPath: FormDetailsModel = groupPath[
    groupPath.length - 1
  ] as FormDetailsModel;
  const isOpen = isOpenPath(destinationUrl, destinationPath);
  let curTree: CardNode[] | undefined = componentTree.value;
  let groupNode: FormDetailsModel | FormGroupModel | null = null;
  for (let i = 0; i < groupPath.length; i++) {
    groupNode = groupPath[i];
    const foundNode: CardNode | undefined = curTree?.find(
      (treeNode: CardNode) => {
        if (
          groupNode &&
          (groupNode as FormGroupModel).groupCode !== undefined
        ) {
          return (groupNode as FormGroupModel).groupCode == treeNode.id;
        }
      },
    ) as CardNode;
    if (foundNode) {
      curTree = foundNode.children;
    } else {
      let genericNode: CardNode;
      if ((groupNode as FormGroupModel).groupCode !== undefined) {
        const actGroup = groupNode as FormGroupModel;
        genericNode = {
          id: actGroup.groupCode,
          name: actGroup.groupName ? actGroup.groupName : "",
          isOpen: isOpen,
          children: [],
        };
      } else {
        const leafNode = groupNode as FormDetailsModel;
        genericNode = {
          id: leafNode.formCode,
          formConfigId: leafNode.formConfigId
            ? leafNode.formConfigId
            : undefined,
          name: leafNode.formName ? leafNode.formName : "",
          softwareUrl: leafNode.softwareUrl,
          routerUrl: leafNode.routerUrl ? leafNode.routerUrl : undefined,
          compileStatus: leafNode.compileStatus
            ? (leafNode.compileStatus as CardState)
            : undefined,
          compileStatusIdentifier: leafNode.compileStatusIdentifier
            ? leafNode.compileStatusIdentifier
            : undefined,
          formCode: leafNode.formCode ? leafNode.formCode : undefined,
          sortOrder: leafNode.sortOrder,
          params: leafNode.params,
          flReadOnly: leafNode.flReadOnly,
          partyId: formList.value.partyId,
          partyCode: cuaa.value,
        };
      }
      curTree?.push(genericNode);
      if (i < groupPath.length - 1 && curTree) {
        curTree = (curTree[curTree.length - 1] as CardNode).children;
      }
      if (isOpen && curTree) {
        componentTree.value.forEach((x) => {
          if (x.isOpen !== undefined) {
            x.isOpen = true;
          }
          recursiveOpenTree(x.children);
        });
      }
    }
  }
}

function recursiveOpenTree(children?: CardNode[]) {
  if (children && children.length > 0) {
    children.forEach((x) => {
      if (x.isOpen !== undefined) {
        x.isOpen = true;
      }
      recursiveOpenTree(x.children);
    });
  }
}

interface NodeTreePath {
  path: (FormDetailsModel | FormGroupModel)[];
}

function openCorrectPage(): string | undefined {
  const moduleId = extractModule(route.fullPath, "applicationDetails");
  let destinationUrl = undefined;
  if (
    moduleId &&
    moduleId !== StaticRoutes.APPLICATION_HISTORY &&
    moduleId !== StaticRoutes.PRINT_HISTORY &&
    moduleId !== StaticRoutes.CALCULATIONS_HISTORY &&
    moduleId !== StaticRoutes.CALCULATION
  )
    destinationUrl = extractDestination(route.fullPath, moduleId);

  //if destination url is not a form
  if (destinationUrl === undefined) {
    const genericParams = route.params["p"];
    let destination = extractDestination(route.fullPath, "applicationDetails");
    let calculationJobUuid = undefined;

    if (destination?.startsWith(`/${StaticRoutes.CALCULATION}/`)) {
      if (
        !genericParams ||
        genericParams.length < 2 ||
        genericParams[1] === ""
      ) {
        destination = "main";
      } else {
        calculationJobUuid = genericParams[1];
        destination = "calculation";
      }
    }

    switch (destination?.replace(/\//g, "")) {
      case StaticRoutes.PRINT_HISTORY:
        showPrintHistoryView(undefined, true);
        break;
      case StaticRoutes.APPLICATION_HISTORY:
        showMovementView(undefined, true);
        break;
      case StaticRoutes.CALCULATIONS_HISTORY:
        showCalculationsHistoryView(undefined, true);
        break;
      case StaticRoutes.CALCULATION:
        showCalculationDetailsView(undefined, true, calculationJobUuid);
        break;
      default:
        goToMainData(undefined, true);
        break;
    }
  }
  return destinationUrl;
}

function fromFormTotree() {
  componentTree.value = [];
  const completePath: NodeTreePath[] = [];
  formList.value.forms.forEach((form) => {
    let nodeAndLeaf: (FormDetailsModel | FormGroupModel)[] = [];
    nodeAndLeaf = nodeAndLeaf.concat(form.groups);
    nodeAndLeaf = nodeAndLeaf.concat(form.formDetails);
    completePath.push({ path: nodeAndLeaf });
  });
  const destinationUrl = openCorrectPage()?.split("?")[0];
  completePath.forEach((branch: NodeTreePath) => {
    appendPath(branch.path, destinationUrl);
  });
}
async function refreshData(routePage = true) {
  infoAnomalies.value = [];
  blockingAnomalies.value = [];
  notBlockingAnomalies.value = [];
  infoAnomalies.value = [];
  await applicationStore.loadApplicationDetails(applicationId.value);
  componentTree.value = [];
  await applicationStore.loadApplicationTransitions(applicationId.value);
  fromFormTotree();
  await initAnomaliesData();

  if (showMovementHistory.value)
    applicationStore.loadApplicationHistory(applicationId.value, true);

  if (routePage) {
    conditionallyRoutePage();
  }
}

// function that execute polling
async function executeTransitionPolling(forceReload = false) {
  isLoadingTransitionData.value = true;
  const isInTransition = applicationStore.getIsInTransition;
  if (isInTransition && !forceReload) {
    let condition = true;
    while (condition) {
      // eslint-disable-next-line @typescript-eslint/no-unused-expressions
      import.meta.env.DEV && console.log("start while");
      if (formList.value && formList.value.applicationId) {
        // eslint-disable-next-line @typescript-eslint/no-unused-expressions
        import.meta.env.DEV && console.log("doing call");
        condition = await doCall(formList);
      }
      // eslint-disable-next-line @typescript-eslint/no-unused-expressions
      import.meta.env.DEV && console.log("awaiting");
      await wait(5000);
    }
  } else {
    await refreshData();
    goToMainData();
  }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function doCall(formList: any) {
  await applicationStore.loadIsInTransition(formList.value.applicationId);
  if (applicationStore.getIsInTransition === false) {
    isLoadingTransitionData.value = false;
    await refreshData();
    goToMainData();
    return false;
  }
  return true;
}

function openFormPage(destination: string, fromInit?: boolean) {
  const url = new URL(destination, window.location.origin);
  const forms = formList.value.forms;

  const selectedForm = forms.find((form: FormModel) => {
    if (form.formDetails.formCode === url.searchParams.get("formCode")) {
      return true;
    }
  });
  // The form was found
  if (selectedForm?.formDetails) {
    const selectedFormsDetails = JSON.parse(
      JSON.stringify(selectedForm.formDetails),
    );
    selectedFormsDetails.routerUrl = url.pathname;
    const localCardInfo: SelectedCard = fromFormDetailsModelToSelectedCard(
      selectedFormsDetails,
      formList.value.partyId,
      cuaa.value,
    );
    openCard(localCardInfo, fromInit);
  }
}

//TODO: To do the if that will contain the verification of the presence or absence of the application
//TODO: Enter the correct value in the API call
onMounted(async () => {
  if (route.query.backUrl != null) {
    sessionStorage.setItem(
      `${moduleId}.backUrl`,
      route.query.backUrl as string,
    );
  }
  backUrl.value = sessionStorage.getItem(`${moduleId}.backUrl`);
  //
  await initPageLogic();
});

async function initPageLogic() {
  if (applicationId?.value != null) {
    await applicationStore.loadApplicationTransitions(applicationId.value);
  }
  if (formList.value === null && applicationId?.value) {
    await applicationStore.loadApplicationDetails(applicationId.value);
  } else {
    if (formList.value && formList.value.partyId) {
      await applicationStore.loadParty(formList.value.partyId);
    }
    fromFormTotree();
  }
  if (cuaa.value == "" && formList.value && formList.value.partyId) {
    await applicationStore.loadParty(formList.value.partyId);
  }
  conditionallyRoutePage(true);
  await initAnomaliesData();
  // Code needed to know if the application is transitioning
  await applicationStore.loadIsInTransition(formList.value.applicationId);
  if (applicationStore.getIsInTransition === true) {
    executeTransitionPolling();
  }
}

function conditionallyRoutePage(fromInit?: boolean) {
  const pageToOpen = openCorrectPage();
  if (pageToOpen) {
    openFormPage(pageToOpen || "", fromInit);
  }
}

function callRefreshDataWithoutRouting() {
  refreshData(false);
}
// this is needed to update forms compile statuses: application-forms-ui (should) sends "form-compiled" event whenever a form is compiled
window.addEventListener("form-compiled", callRefreshDataWithoutRouting);

onUnmounted(() => {
  window.removeEventListener("form-compiled", callRefreshDataWithoutRouting);
});

watch(openPrintModal, () => {
  if (openPrintModal.value === false) {
    document.body.classList.remove("modal-open");
    document.body.style.removeProperty("overflow");
    document.body.style.removeProperty("padding-right");
  }
});

watch(openCalculationsModal, () => {
  if (openCalculationsModal.value === false) {
    document.body.classList.remove("modal-open");
    document.body.style.removeProperty("overflow");
    document.body.style.removeProperty("padding-right");
  }
});
</script>

<style scoped>
.align-center {
  display: flex;
  flex-direction: column;
  align-items: center;
}
.cursor-pointer {
  cursor: pointer;
}
.underline-hover:hover {
  text-decoration: underline;
}
.text-small {
  font-size: 0.88889rem;
}

.second-level-card {
  font-weight: 600;
}

.no-dot {
  list-style-type: none;
}
.title {
  font-weight: bold;
  font-size: 1.111em;
}
.slot-whitespace {
  white-space: break-spaces !important;
}
</style>

<template>
  <div class="my-5 container">
    <BiCard :extra-classes="['card-bg', 'rounded', 'px-0']">
      <template #card-header>
        <TopBar
          :isBackButton="true"
          :backButtonFunction="() => goBack()"
          :title="
            (formList?.applicationProfilesDescription
              ? formList?.applicationProfilesDescription + ' - '
              : '') +
            t(`${moduleId}.applicationDetails.title`, {
              moduleDescription: formList?.moduleDescription
                ? formList.moduleDescription + ' -'
                : '',
              id: applicationId ? applicationId : '',
            }) +
            (formList?.moduleYear
              ? t(`${moduleId}.applicationDetails.titleYear`, {
                  year: formList.moduleYear,
                })
              : '')
          "
          :buttonList="[
            {
              hideButton:
                anomaliesCount.blocking +
                  anomaliesCount.notBlocking +
                  anomaliesCount.info <=
                0,
              text: t(`${moduleId}.applicationDetails.actions.anomaly`, {
                count: anomaliesButtonInfo.count,
              }),
              classes: `${anomaliesButtonInfo.style} ms-2 text-nowrap`,
              callback: () => {
                showAnomaliesModal = true;
              },
            },
            {
              hideButton:
                calculations.length === 0 ||
                applicationStore.isFunctionReadOnly,
              text: t(`${moduleId}.applicationDetails.actions.calculations`),
              classes: `${getColor(
                'button',
                'primary',
                'outline',
              )} ms-2 text-nowrap`,
              callback: () => {
                openCalculationsModal = true;
              },
            },
            {
              hideButton:
                prints.length === 0 || applicationStore.isFunctionReadOnly,
              text: t(`${moduleId}.applicationDetails.actions.print`),
              classes: `${getColor(
                'button',
                'primary',
                'outline',
              )} ms-2 text-nowrap`,
              callback: () => {
                openPrintModal = true;
              },
            },
            {
              text: t(`${moduleId}.applicationDetails.actions.stateTransition`),
              hideButton:
                !transitions ||
                transitions.length === 0 ||
                applicationStore.isFunctionReadOnly,
              classes: `${getColor(
                'button',
                'primary',
                'outline',
              )} text-nowrap ms-2`,
              callback: () => {
                changeStatusComponentVisible = true;
              },
            },
          ]"
        />
      </template>
      <template #card-body>
        <div class="m-0 px-0 container row">
          <div class="mb-3 col-12 col-lg-3 pe-0 pe-lg-2 ps-0">
            <!--Main data "group" -->
            <div
              class="mb-3 p-2 w-100 text-uppercase application-module__group-detail-header ps-3"
              :class="getColor('text', 'white')"
              @click="goToMainData"
              tabIndex="0"
              @keyup.enter="goToMainData"
              @keydown.space.stop.prevent="
                () => {
                  goToMainData();
                }
              "
            >
              <span class="underline-hover cursor-pointer"
                >{{ t(`${moduleId}.cardMenu.mainData`) }}
              </span>
            </div>

            <!-- Main card group example: scheda domanda, utilities ... -->
            <div class="mb-3" v-for="node in componentTree" :key="node.id">
              <BiAccordion
                :model-value="node.isOpen"
                :title="node.name"
                :body-extra-class="'border pe-0 pt-0 pb-0 ps-0'"
                header-extra-class="application-module__group-detail-header text-uppercase application-module__accordion-header-padding"
                color-bg-header="primary"
                color-header="white"
                headerArrowExtraClass="py-2"
              >
                <!-- Second level - sub group of cards  -->
                <template
                  v-if="node && node.children && node.children.length > 0"
                >
                  <template v-for="(subNode, i) in node.children" :key="i">
                    <!-- Second level accordion - sub card group -->
                    <template
                      v-if="
                        subNode &&
                        subNode.children &&
                        subNode.children.length > 0
                      "
                    >
                      <SecondLevelCardAccordion
                        @openCard="openCard($event)"
                        :node="subNode"
                        :selectedCardId="
                          selectedCardInfo ? selectedCardInfo.id : null
                        "
                      />
                    </template>
                    <!-- Second level card - no sub card group-->
                    <template v-else>
                      <SecondLevelCard
                        :key="i"
                        @openCard="openCard($event)"
                        :node="subNode"
                        :selectedCardId="
                          selectedCardInfo ? selectedCardInfo.id : null
                        "
                      />
                    </template>
                  </template>
                </template>
              </BiAccordion>
            </div>

            <BiAccordion
              :title="t(`${moduleId}.applicationDetails.utilities.title`)"
              :body-extra-class="'border pe-0 pt-0 mb-3 ps-0 pb-0'"
              header-extra-class="application-module__group-detail-header text-uppercase application-module__accordion-header-padding"
              :model-value="utilityAccordionOpened"
              color-bg-header="primary"
              color-header="white"
              headerArrowExtraClass="py-2"
            >
              <!-- Movement history-->
              <div
                class="pt-2 pb-2 border-bottom underline-hover cursor-pointer ps-3 second-level-card"
                :class="
                  showMovementHistory == true ? 'text-decoration-underline' : ''
                "
                tabIndex="0"
                @keyup.enter="showMovementView"
                @keydown.space.stop.prevent="
                  () => {
                    showMovementView();
                  }
                "
                @click="showMovementView"
              >
                {{ t(`${moduleId}.applicationDetails.movementHistory.title`) }}
              </div>
              <!-- Print history -->
              <div
                class="pt-2 pb-2 border-bottom underline-hover cursor-pointer ps-3 second-level-card"
                :class="
                  showPrintHistory == true ? 'text-decoration-underline' : ''
                "
                tabIndex="0"
                @keyup.enter="showPrintHistoryView"
                @keydown.space.stop.prevent="
                  () => {
                    showPrintHistoryView();
                  }
                "
                @click="showPrintHistoryView"
              >
                {{ t(`${moduleId}.applicationDetails.printHistory.title`) }}
              </div>
              <!-- Calculations history -->
              <div
                class="pt-2 pb-2 border-bottom underline-hover cursor-pointer ps-3 second-level-card"
                :class="
                  showCalculationsHistory == true
                    ? 'text-decoration-underline'
                    : ''
                "
                @click="showCalculationsHistoryView"
                tabIndex="0"
                @keyup.enter="showCalculationsHistoryView"
                @keydown.space.stop.prevent="
                  () => {
                    showCalculationsHistoryView();
                  }
                "
              >
                {{
                  t(`${moduleId}.applicationDetails.calculationsHistory.title`)
                }}
              </div>
            </BiAccordion>
          </div>
          <div class="col-12 col-lg-9 pe-0 ps-0 ps-lg-2">
            <CentralBoxHeader
              :applicationProcessStatus="
                formList &&
                formList.processStatusDescription &&
                formList.processStatusDescription
                  ? formList.processStatusDescription
                  : ''
              "
            />
            <CardCentralBox
              v-if="selectedCardInfo !== null"
              :cardInfo="selectedCardInfo"
            ></CardCentralBox>
            <GenericApplicationInfo
              v-if="showGenericApplicationData && formList"
              :application="formList"
            />
            <MovementHistory v-if="showMovementHistory" />
            <PrintHistory v-if="showPrintHistory" />
            <CalculationsHistory
              v-if="showCalculationsHistory"
              @viewResults="
                (calculationJobUuid: string) =>
                  showCalculationDetailsView(
                    undefined,
                    undefined,
                    calculationJobUuid,
                  )
              "
            />
            <CalculationDetails
              v-if="calculationJobUuidSelected && showCalculationDetails"
              :calculation-job-uuid="calculationJobUuidSelected"
            />
          </div>
        </div>
      </template>
    </BiCard>
  </div>
  <!-- :title="t(`${moduleId}.applicationDetails.anomalies`)" -->
  <BiModal
    :disabled-teleport="true"
    v-model="showAnomaliesModal"
    ariaLabelledby="noMembers"
    size="xl"
  >
    <template #body>
      <div class="d-flex mt-3 mb-3 row">
        <div class="col-12 col-lg-7 col-md-6 col-xl-7">
          <h4 class="title" :class="getColor('text', 'primary')">
            {{ t(`${moduleId}.applicationDetails.anomalies`) }}
          </h4>
        </div>
      </div>
      <div class="mb-3 text-secondary text-small">
        <span
          ><strong
            >{{
              t(`${moduleId}.applicationDetails.anomaliesModal.lastRecalcDate`)
            }}: </strong
          >{{
            lastAnomaliesRecalcDate
              ? getFormattedDate(lastAnomaliesRecalcDate, true)
              : ""
          }}</span
        >
      </div>
      <BiTable
        class="pt-3 table-responsive"
        extraTableClasses="table-head-bg"
        isResponsive
      >
        <template v-slot:head>
          <tr
            class="bg-light text-start"
            :class="getColor('text', 'secondary')"
          >
            <th scope="col" class="text-center">
              {{ t(`${moduleId}.applicationDetails.anomaliesModal.severity`) }}
            </th>
            <th scope="col" class="text-center">
              {{ t(`${moduleId}.applicationDetails.anomaliesModal.code`) }}
            </th>
            <th scope="col" class="text-start">
              {{
                t(`${moduleId}.applicationDetails.anomaliesModal.description`)
              }}
            </th>
          </tr>
        </template>
        <template v-slot:body>
          <tr
            v-for="(anomaly, i) in [
              ...blockingAnomalies,
              ...notBlockingAnomalies,
              ...infoAnomalies,
            ]"
            :key="i"
            class="align-middle"
          >
            <td
              :data-label="
                t(`${moduleId}.applicationDetails.anomaliesModal.severity`)
              "
              class="text-center"
            >
              <BiIcon
                :icon="
                  anomaly.severity === AnomalySeverity.BLOCKING
                    ? 'circle-exclamation'
                    : anomaly.severity === AnomalySeverity.NOT_BLOCKING
                      ? 'triangle-exclamation'
                      : 'circle-info'
                "
                :color="
                  anomaly.severity === AnomalySeverity.BLOCKING
                    ? 'danger'
                    : anomaly.severity === AnomalySeverity.NOT_BLOCKING
                      ? 'warning'
                      : 'info'
                "
                size="xl"
                icon-style="solid"
              />
            </td>
            <td
              :data-label="
                t(`${moduleId}.applicationDetails.anomaliesModal.code`)
              "
              class="text-center"
            >
              {{ anomaly.anomalyCode }}
            </td>
            <td
              :data-label="
                t(`${moduleId}.applicationDetails.anomaliesModal.description`)
              "
              class="text-start"
            >
              {{ anomaly.anomalyDesc }}
            </td>
          </tr>
        </template>
      </BiTable>
      <div
        v-if="isInTransitionMessages?.lastTransitionLog?.messages.length !== 0"
        class="d-flex mt-5 mb-1 row"
      >
        <div class="col-12 col-lg-7 col-md-6 col-xl-7">
          <h4 class="title" :class="getColor('text', 'primary')">
            {{ t(`${moduleId}.applicationDetails.messages`) }}
          </h4>
        </div>
      </div>
      <BiTable
        v-if="isInTransitionMessages?.lastTransitionLog?.messages.length !== 0"
        class="pt-3 table-responsive"
        extraTableClasses="table-head-bg"
        isResponsive
      >
        <template v-slot:head>
          <tr
            class="bg-light text-start"
            :class="getColor('text', 'secondary')"
          >
            <th scope="col">
              {{ t(`${moduleId}.applicationDetails.anomaliesModal.message`) }}
            </th>
          </tr>
        </template>
        <template v-slot:body>
          <tr
            v-for="message in isInTransitionMessages?.lastTransitionLog
              ?.messages"
            class="align-middle"
            :key="JSON.stringify(message)"
          >
            <td
              :data-label="
                t(`${moduleId}.applicationDetails.anomaliesModal.message`)
              "
              class="text-start slot-whitespace"
            >
              {{ message.code + " - " + message.description }}
            </td>
          </tr>
        </template>
      </BiTable>
    </template>
    <template #footer>
      <div class="mb-5 text-center col">
        <BiButton
          :class="getColor('button', 'primary', 'outline')"
          @click.stop="() => (showAnomaliesModal = false)"
        >
          {{ t(`${moduleId}.general.close`) }}
        </BiButton>
      </div>
    </template>
  </BiModal>
  <!-- Print modal -->
  <BiModal
    v-if="openPrintModal"
    :disabled-teleport="true"
    v-model="openPrintModal"
    :ariaLabelledby="t(`${moduleId}.applicationDetails.printModal.title`)"
    :title="t(`${moduleId}.applicationDetails.printModal.title`)"
    :extra-footer-class="'justify-content-center'"
    size="lg"
  >
    <template #body>
      <ApplicationPrintModal :applicationId="applicationId" />
    </template>
    <template #footer>
      <BiButton
        :class="getColor('button', 'primary', 'outline')"
        @click.stop="() => (openPrintModal = false)"
      >
        {{ t(`${moduleId}.general.close`) }}
      </BiButton>
    </template>
  </BiModal>
  <!-- Calculations modal -->
  <BiModal
    v-if="openCalculationsModal"
    :disabled-teleport="true"
    v-model="openCalculationsModal"
    :ariaLabelledby="
      t(`${moduleId}.applicationDetails.calculationsModal.title`)
    "
    :title="t(`${moduleId}.applicationDetails.calculationsModal.title`)"
    :extra-footer-class="'justify-content-center'"
    size="lg"
  >
    <template #body>
      <ApplicationCalculationsModal
        :applicationId="applicationId"
        @viewResults="
          (calculationJobUuid: string) =>
            showCalculationDetailsView(undefined, undefined, calculationJobUuid)
        "
      />
    </template>
    <template #footer>
      <BiButton
        :class="getColor('button', 'primary', 'outline')"
        @click.stop="() => (openCalculationsModal = false)"
      >
        {{ t(`${moduleId}.general.close`) }}
      </BiButton>
    </template>
  </BiModal>
  <ApplicationChangeStatusModal
    v-if="changeStatusComponentVisible"
    :open-modal="changeStatusComponentVisible"
    @close-modal="handleCloseModal"
    :transition-list="transitions"
    @hidden-progress-status-done="waitForCloseModalAndReload"
    :application-id="applicationId"
    :application="formList"
  />
</template>
