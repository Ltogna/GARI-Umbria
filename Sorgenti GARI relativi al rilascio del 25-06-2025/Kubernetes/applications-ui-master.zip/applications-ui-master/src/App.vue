<script setup lang="ts">
import { RouterView } from "vue-router";
import RootAlerts from "@abaco/bootstrap-italia-components/src/components/Alerts/RootAlerts.vue";
import { inject, onMounted } from "vue";
import { useUserAdminStore } from "./stores/userAdminStore";
import { login } from "./resources/api/login";
import { http } from "./resources/api/http";
import { getUserData } from "@abaco/safe-rest/src/sso2";
import { loadLocaleMessages } from "./i18n";
import { useApplicationStore } from "./stores/applicationStore";

const userAdminStore = useUserAdminStore();
const applicationStore = useApplicationStore();

const isDev = inject("isDev");

onMounted(async () => {
  try {
    if (isDev) {
      await login({
        tenant: "master",
        username: "admin",
        password: "welcome",
      });
    }
    await loadLocaleMessages(getUserData()?.locale || "it");
    http.setLanguage(getUserData()?.locale || "it");
    userAdminStore.fetchMyUsername();
    userAdminStore.setReady();
    await applicationStore.loadTenantConfigs();
    await applicationStore.loadUserFunctions();
  } catch (err) {
    console.error(err);
  }
});
</script>

<template>
  <div class="application-module">
    <RootAlerts :dismissOnRouteChange="true"></RootAlerts>
    <RouterView v-if="userAdminStore.getIsReady" />
  </div>
</template>
