import type {
  ApplicationAnomalyResponseModel,
  ApplicationDetailsModel,
  ApplicationFilter,
  ApplicationHistoryModel,
  ApplicationIsInTransitionModel,
  ApplicationModulesResponse,
  ApplicationSummaryDetailResponse,
  ApplicationSummaryListModel,
  ApplicationTransitionsModel,
  CreateApplicationModel,
  CreateApplicationResponseModel,
  CreateAmendmentResponseModel,
  PartyListModel,
  PartyModel,
  PartyRegistryListModel,
  PrintHistoryResponseModel,
  AmendmentModulesResponse,
  TenantConfigModel,
  CreateAmendmentModel,
  GeneratedCalculationListModel,
} from "@/models/application";
import {
  handleApiErrorAndShowAlert,
  handleErrorCode,
  mapSingleElementData,
  mapSubjectsData,
} from "@/models/utils";
import {
  createApplicationApi,
  downloadPrint,
  generatePrint,
  getApplicationAnomalies,
  getApplicationDetails,
  getApplicationHistory,
  getApplicationModules,
  getApplicationPrintHistory,
  getApplicationSummaryDetailList,
  getApplicationSummaryList,
  getApplicationTransitions,
  getIsInTransition,
  getOngoingPrints,
  getParties,
  getParty,
  getAmendmentModules,
  loadTenantConfigsAPI,
  updateApplicationStatus,
  createAmendmentApi,
  loadApplicationCalculationsHistoryAPI,
  loadOngoingCalculationsAPI,
  startCalculationAPI,
  loadCalculationDetailsAPI,
  loadUserFunctionsAPI,
} from "@/resources/api/applicationApi";
import type { UserFunctionArrayModel } from "@/resources/api/login";
import {
  ErrorType,
  type HttpResponseError,
} from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";

export enum RegistryEnvironment {
  LEGACY = "legacy",
  PARTYREGISTRY = "party-registry",
  PARTY_REGISTRY_DIRECTORY_URL = "party_registry_directory_url",
  PARTY_REGISTRY_DIRECTORY_SEARCH_URL = "party_registry_directory_search_url",
  PARTY_REGISTRY_ENABLE_SEARCH_FOR_CODE = "party_registry_enable_search_for_code",
  DISABLE_NEW_APPLICATION_BUTTON_CONTEXT_FUNCTION = "disable_new_application_button_context_function",
}
interface ApplicationInformation {
  transitionData: ApplicationIsInTransitionModel | null;
  transitionStatus?: string;
  applicationTransitions: ApplicationTransitionsModel | null;
  applicationHistory: ApplicationHistoryModel | null;
  applicationDetails: ApplicationDetailsModel | null;
  applicationModules: ApplicationModulesResponse | null;
  amendmentModules: AmendmentModulesResponse | null;
  printHistory: PrintHistoryResponseModel | null;
  ongoingPrints: PrintHistoryResponseModel | null;
  loadingOngoingPrints: boolean;
  calculationsHistory: GeneratedCalculationListModel | null;
  ongoingCalculations: GeneratedCalculationListModel | null;
  loadingOngoingCalculations: boolean;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  calculationDetails: any;
}

interface State {
  applicationSummaryList: ApplicationSummaryListModel | null;
  applicationSummaryDetailList: ApplicationSummaryDetailResponse | null;
  applicationListStatusFilter: ApplicationFilter;
  subjectList: PartyListModel | null;
  createApplicationResponse: CreateApplicationResponseModel | null;
  createAmendmentResponse: CreateAmendmentResponseModel | null;
  loading: boolean;
  hasError: boolean;
  errorResponse?: HttpResponseError;
  selectedSubject: PartyModel | null;
  application: { [key: string]: ApplicationInformation };
  routeApplicationId: string;
  applicationAnomalies: { [key: string]: ApplicationAnomalyResponseModel };
  registryEnvironment: string;
  tenantConfigs: Record<string, string | number | boolean>;
  userFunctions: UserFunctionArrayModel | null;
  isFunctionReadOnly: boolean;
}
export const NOT_ALLOWED_MULTIPLE_APPLICATIONS_ERROR =
  "NOT_ALLOWED_MULTIPLE_APPLICATIONS_ERROR";
export const APPLICATION_CREATION_ERROR = "APPLICATION_CREATION_ERROR";
export const ALREADY_AMENDED_APPLICATION_ERROR_CODE =
  "ALREADY_AMENDED_APPLICATION_ERROR_CODE";
export const WAIVED_APPLICATION_ERROR_CODE = "WAIVED_APPLICATION_ERROR_CODE";

export const useApplicationStore = defineStore("applicationStore", {
  state: () =>
    ({
      applicationSummaryList: null,
      applicationSummaryDetailList: null,
      applicationListStatusFilter: {
        referenceSubject: "",
        applicationNumber: "",
      },
      selectedSubject: null,
      subjectList: null,
      createApplicationResponse: null,
      createAmendmentResponse: null,
      loading: false,
      hasError: false,
      errorResponse: undefined,
      application: {},
      routeApplicationId: "",
      applicationAnomalies: {},
      tenantConfigs: {},
      userFunctions: null,
      isFunctionReadOnly: false,
    }) as State,
  getters: {
    getApplicationList: (state: State) => {
      return state.applicationSummaryList;
    },
    getApplicationDetailList: (state: State) => {
      return state.applicationSummaryDetailList;
    },
    getApplicationListStatusFilter: (state: State) => {
      return state.applicationListStatusFilter;
    },
    getApplicationModules: (state: State) => {
      return state.application[state.routeApplicationId]?.applicationModules;
    },
    getAmendmentModules: (state: State) => {
      return state.application[state.routeApplicationId]?.amendmentModules;
    },
    getSelectedSubject: (state: State) => {
      return state.selectedSubject;
    },
    getSubjectList: (state: State) => {
      return state.subjectList?.records;
    },
    getCreateApplicationResponse: (state: State) => {
      return state.createApplicationResponse;
    },
    getCreateAmendmentResponse: (state: State) => {
      return state.createAmendmentResponse;
    },
    getApplicationDetails: (state: State): ApplicationDetailsModel => {
      return state.application[state.routeApplicationId]
        .applicationDetails as ApplicationDetailsModel;
    },
    getApplicationHistory: (state: State): ApplicationHistoryModel => {
      return state.application[state.routeApplicationId]
        .applicationHistory as ApplicationHistoryModel;
    },
    getApplicationTransitions: (state: State): ApplicationTransitionsModel => {
      return state.application[state.routeApplicationId]
        .applicationTransitions as ApplicationTransitionsModel;
    },
    getApplicationAnomalies: (
      state: State,
    ): ApplicationAnomalyResponseModel => {
      return state.applicationAnomalies[
        state.routeApplicationId
      ] as ApplicationAnomalyResponseModel;
    },
    getErrorResponse: (state: State) => {
      return state.errorResponse;
    },
    getIsInTransition: (state: State) => {
      return state.application[state.routeApplicationId].transitionData
        ?.inTransition;
    },
    getTransitionStatus: (state: State) => {
      return state.application[state.routeApplicationId]?.transitionStatus;
    },
    getTransitionData: (state: State) => {
      return state.application[state.routeApplicationId].transitionData;
    },
    getPrintHistory: (state: State) => {
      return state.application[state.routeApplicationId].printHistory;
    },
    getOngoingPrints: (state: State) => {
      return state.application[state.routeApplicationId].ongoingPrints;
    },
    getLoadingOnGoingPrints: (state: State) => {
      return state.application[state.routeApplicationId].loadingOngoingPrints;
    },
    getIsLoading: (state: State) => {
      return state.loading;
    },
    getTenantConfigPartyRegistryError: (state: State) => {
      return !!state.tenantConfigs["PARTY_REGISTRY_LOADING_ERROR"];
    },
    gettenantconfigPartyRegistryEnableSearchForCode: (state: State) => {
      const data: "true" | "false" =
        (state.tenantConfigs[
          RegistryEnvironment.PARTY_REGISTRY_ENABLE_SEARCH_FOR_CODE
        ] as "false") ?? "true";

      return data.toString() === "false" ? false : true;
    },
    getCalculationsHistory: (state: State) => {
      return state.application[state.routeApplicationId].calculationsHistory;
    },
    getOngoingCalculations: (state: State) => {
      return state.application[state.routeApplicationId].ongoingCalculations;
    },
    getLoadingOnGoingCalculations: (state: State) => {
      return state.application[state.routeApplicationId]
        .loadingOngoingCalculations;
    },
    getCalculationDetails: (state: State) => {
      return state.application[state.routeApplicationId].calculationDetails;
    },
    getUserFunctions: (state: State) => {
      return state.userFunctions;
    },
    getIsFunctionReadOnly: (state: State) => {
      return state.isFunctionReadOnly;
    },
  },
  actions: {
    async searchSubjects(cuaa?: string | null, partyDesc?: string | null) {
      this.loading = true;
      this.hasError = false;
      const useCuaa = cuaa?.trimEnd();
      const usePartyDesc = partyDesc?.trimEnd();
      const actualNextKey = this.subjectList?.nextKey;
      const response = await getParties(
        this.registryEnvironment,
        this.tenantConfigs[
          RegistryEnvironment.PARTY_REGISTRY_DIRECTORY_SEARCH_URL
        ] as string,
        useCuaa,
        usePartyDesc,
        actualNextKey,
        this.gettenantconfigPartyRegistryEnableSearchForCode,
      );

      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
      } else {
        if (this.subjectList) {
          this.subjectList.records.push(
            ...mapSubjectsData(response.data.records, this.registryEnvironment),
          );
          this.subjectList.nextKey = response.data.nextKey;
        } else {
          const notMappedData: PartyListModel | PartyRegistryListModel =
            response.data;
          notMappedData.records = mapSubjectsData(
            notMappedData.records,
            this.registryEnvironment,
          );
          const mappedData: PartyListModel = notMappedData as PartyListModel;
          this.subjectList = mappedData;
        }
      }
      this.loading = false;
    },
    async loadApplicationSummaryList(partyId: number) {
      this.loading = true;
      this.hasError = false;
      const response = await getApplicationSummaryList(partyId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
      } else {
        // set response and sort array
        this.applicationSummaryList = {
          partyId: response.data.partyId || 0,
          applicationsSummaryByYear:
            response.data.applicationsSummaryByYear &&
            Array.isArray(response.data.applicationsSummaryByYear) &&
            response.data.applicationsSummaryByYear.length > 0
              ? response.data.applicationsSummaryByYear.sort((x, y) => {
                  return y.year - x.year;
                })
              : [],
        };
      }
      this.loading = false;
    },
    async loadApplicationSummaryDetailList(
      partyId: number,
      year: number,
      nextKey: string | null,
    ) {
      this.loading = true;
      this.hasError = false;
      const response = await getApplicationSummaryDetailList(
        partyId,
        year,
        nextKey || null,
      );
      if (response.errorType !== ErrorType.NONE) {
        this.applicationSummaryDetailList = null;
        this.hasError = true;
        handleApiErrorAndShowAlert(response);
      } else {
        this.applicationSummaryDetailList = response.data;
        // if (resetList) {
        //   this.applicationSummaryDetailList = response.data;
        // } else {
        //   this.applicationSummaryDetailList &&
        //     (this.applicationSummaryDetailList.count = response.data.count);
        //   this.applicationSummaryDetailList &&
        //     (this.applicationSummaryDetailList.nextKey = response.data.nextKey);
        //   this.applicationSummaryDetailList?.records?.push(
        //     ...(response?.data?.records ?? [])
        //   );
        // }
      }
      this.loading = false;
    },
    async loadApplicationModules(point_in_time?: string, nextKey?: string) {
      this.loading = true;
      this.hasError = false;
      const response = await getApplicationModules(point_in_time, nextKey);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        handleApiErrorAndShowAlert(response);
      } else {
        if (
          this.application[this.routeApplicationId] &&
          this.application[this.routeApplicationId].applicationModules &&
          nextKey
        ) {
          (
            this.application[this.routeApplicationId]
              .applicationModules as ApplicationModulesResponse
          ).records.push(...response.data.records);
          (
            this.application[this.routeApplicationId]
              .applicationModules as ApplicationModulesResponse
          ).count = response.data.count;
          (
            this.application[this.routeApplicationId]
              .applicationModules as ApplicationModulesResponse
          ).nextKey = response.data.nextKey;
        } else {
          this.application[this.routeApplicationId].applicationModules =
            response.data;
        }
      }
      this.loading = false;
    },
    async loadAmendmentModules(applicationId: number) {
      this.loading = true;
      this.hasError = false;
      const response = await getAmendmentModules(applicationId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        handleApiErrorAndShowAlert(response);
      } else {
        this.application[this.routeApplicationId].amendmentModules =
          response.data;
      }
      this.loading = false;
    },
    setTransitionData(input: ApplicationIsInTransitionModel) {
      this.application[this.routeApplicationId].transitionData = input;
    },
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    setDefaultErrorTransition(defaultErrorMsg?: any) {
      this.setTransitionData({
        inTransition: false,
        lastTransitionLog: {
          id: 0,
          startDate: new Date().getTime(),
          endDate: 0,
          userId: "",
          processId: 0,
          transitionId: 0,
          notes: null,
          failed: true,
          description: "",
          fromNode: "",
          fromNodeDescription: null,
          toNode: "",
          toNodeDescription: null,
          messages: defaultErrorMsg
            ? Array.isArray(defaultErrorMsg)
              ? defaultErrorMsg
              : [defaultErrorMsg]
            : [],
        },
      });
    },
    async createApplication(newApplication: CreateApplicationModel) {
      this.hasError = false;
      this.createApplicationResponse = null;
      const defaultErrorMsg = {
        code: APPLICATION_CREATION_ERROR,
        description: APPLICATION_CREATION_ERROR,
        type: "ERROR",
      };
      const response = await createApplicationApi(newApplication);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.setDefaultErrorTransition(defaultErrorMsg);
        handleApiErrorAndShowAlert(response, false);
      } else {
        if (response.data.anomalies && response.data.anomalies.length > 0) {
          if (
            response.data.anomalies.find(
              (x) => x.code === NOT_ALLOWED_MULTIPLE_APPLICATIONS_ERROR,
            )
          ) {
            defaultErrorMsg.code = NOT_ALLOWED_MULTIPLE_APPLICATIONS_ERROR;
            defaultErrorMsg.description =
              NOT_ALLOWED_MULTIPLE_APPLICATIONS_ERROR;
          }
          this.setDefaultErrorTransition(defaultErrorMsg);
        } else {
          this.createApplicationResponse = response.data;
        }
      }
    },
    async createAmendment(
      newAmendment: CreateAmendmentModel,
      applicationId: string,
    ) {
      this.hasError = false;
      this.createAmendmentResponse = null;
      const response = await createAmendmentApi(newAmendment, applicationId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        handleApiErrorAndShowAlert(response, false);
      } else {
        if (response.data.anomalies && response.data.anomalies.length > 0) {
          this.setDefaultErrorTransition(
            response.data.anomalies.map((el) => {
              return { code: el.code, description: el.message, type: "ERROR" };
            }),
          );
        } else {
          this.createAmendmentResponse = response.data;
        }
      }
    },
    async loadApplicationDetails(applicationId: number) {
      this.loading = true;
      this.hasError = false;
      const response = await getApplicationDetails(applicationId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        if (this.errorResponse.response.status !== 404) {
          handleApiErrorAndShowAlert(response);
        }
      } else {
        this.setRouteApplicationId(applicationId.toString());
        this.application[this.routeApplicationId].applicationDetails =
          response.data;
      }
      this.loading = false;
    },
    async loadApplicationHistory(applicationId: number, handleError = false) {
      this.loading = true;
      this.hasError = false;
      const response = await getApplicationHistory(applicationId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        if (handleError) {
          handleApiErrorAndShowAlert(response);
        }
      } else {
        this.application[this.routeApplicationId].applicationHistory =
          response.data;
      }
      this.loading = false;
    },
    async loadApplicationAnomalies(applicationId: number, handleError = false) {
      this.loading = true;
      this.hasError = false;
      const response = await getApplicationAnomalies(applicationId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        if (handleError) {
          handleApiErrorAndShowAlert(response);
        }
      } else {
        this.setRouteApplicationId(applicationId.toString());
        this.applicationAnomalies[this.routeApplicationId] = response.data;
      }
      this.loading = false;
    },
    async loadParty(partyId: number) {
      this.loading = true;
      if (
        !this.tenantConfigs[RegistryEnvironment.PARTY_REGISTRY_DIRECTORY_URL]
      ) {
        await this.loadTenantConfigs();
      }
      const response = await getParty(
        partyId,
        this.tenantConfigs[
          RegistryEnvironment.PARTY_REGISTRY_DIRECTORY_URL
        ] as string,
      );
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.loading = false;
        handleApiErrorAndShowAlert(response);
        return response;
      } else {
        this.hasError = false;
        this.selectedSubject = mapSingleElementData(
          response.data,
          this.registryEnvironment,
        );
      }
      this.loading = false;
    },
    async loadApplicationTransitions(applicationId: number) {
      this.loading = true;
      const response = await getApplicationTransitions(applicationId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
      } else {
        this.hasError = false;
        this.application[this.routeApplicationId].applicationTransitions =
          response.data;
      }
      this.loading = false;
    },
    async loadIsInTransition(applicationId: number) {
      this.loading = true;
      const response = await getIsInTransition(applicationId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.loading = false;
        handleApiErrorAndShowAlert(response);
        return response;
      } else {
        this.hasError = false;
        this.application[this.routeApplicationId].transitionData =
          response.data;
      }
      this.loading = false;
    },
    async loadApplicationPrintHistory(
      applicationId: number,
      handleError = false,
    ) {
      this.loading = true;
      this.hasError = false;
      const response = await getApplicationPrintHistory(applicationId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        if (handleError) {
          handleApiErrorAndShowAlert(response);
        }
      } else {
        this.application[this.routeApplicationId].printHistory = response.data;
      }
      this.loading = false;
    },
    async loadOngoingPrints(handleError = false) {
      this.loading = true;
      this.hasError = false;
      const response = await getOngoingPrints(
        Number.parseInt(this.routeApplicationId),
      );
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        if (handleError) {
          handleApiErrorAndShowAlert(response);
        }
      } else {
        this.application[this.routeApplicationId].ongoingPrints = response.data;
      }
      this.loading = false;
    },
    async loadTenantConfigs() {
      this.loading = true;
      this.hasError = false;
      const response = await loadTenantConfigsAPI();
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        handleApiErrorAndShowAlert(response);
      } else {
        response.data.forEach((config: TenantConfigModel) => {
          this.tenantConfigs[config.key] = config.value;
        });
        if (
          !this.tenantConfigs[
            RegistryEnvironment.PARTY_REGISTRY_DIRECTORY_SEARCH_URL
          ]
        ) {
          handleErrorCode("CONFIG_NOT_FOUND_ERROR");
          this.tenantConfigs["PARTY_REGISTRY_LOADING_ERROR"] = true;
        } else {
          if (
            (
              this.tenantConfigs[
                RegistryEnvironment.PARTY_REGISTRY_DIRECTORY_SEARCH_URL
              ] as string
            ).includes(RegistryEnvironment.PARTYREGISTRY)
          ) {
            this.setRegistryEnvironment(RegistryEnvironment.PARTYREGISTRY);
          } else this.setRegistryEnvironment(RegistryEnvironment.LEGACY);
        }
      }
      this.loading = false;
    },
    setSelectedSubject(subject: PartyModel | null) {
      this.selectedSubject = subject;
    },
    setApplicationListFilter(statusFilter: ApplicationFilter) {
      this.applicationListStatusFilter = statusFilter;
    },
    setTransitionStatus(transitionStatus: string) {
      this.application[this.routeApplicationId].transitionStatus =
        transitionStatus;
    },
    setRouteApplicationId(applicationId: string) {
      this.routeApplicationId = applicationId;
      if (
        !this.application[this.routeApplicationId] ||
        applicationId === "new"
      ) {
        this.application[this.routeApplicationId] = {
          applicationDetails: null,
          applicationHistory: null,
          applicationModules: null,
          amendmentModules: null,
          applicationTransitions: null,
          transitionData: null,
          printHistory: null,
          ongoingPrints: null,
          loadingOngoingPrints: false,
          calculationsHistory: null,
          ongoingCalculations: null,
          loadingOngoingCalculations: false,
          calculationDetails: null,
        };
      }
    },
    setLoadingOngoingPrints(value: boolean) {
      this.application[this.routeApplicationId].loadingOngoingPrints = value;
    },
    setLoadingOngoingCalculations(value: boolean) {
      this.application[this.routeApplicationId].loadingOngoingCalculations =
        value;
    },
    setRegistryEnvironment(key: string) {
      this.registryEnvironment = key;
    },
    setIsFunctionReadOnly(val: boolean) {
      this.isFunctionReadOnly = val;
    },
    clearApplicationSummaryList() {
      this.applicationSummaryList = null;
    },
    clearApplicationSummaryDetailList() {
      this.applicationSummaryDetailList = null;
    },
    clearSubjectList() {
      this.subjectList = null;
    },
    clearApplicationStatusFilters() {
      this.applicationListStatusFilter = {
        referenceSubject: "",
        applicationNumber: "",
      };
    },
    /**
     *  Function needed to change status
     */
    async changeStatus(
      applicationId: number,
      transition_id: string,
      notes?: string,
    ) {
      this.loading = true;
      this.hasError = false;
      const response = await updateApplicationStatus(
        applicationId,
        transition_id,
        notes,
      );
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
      } else {
        this.hasError = false;
      }
      this.loading = false;
      if (this.hasError) {
        throw new Error("error calling progress");
      }
    },
    async doDownloadPrint(fileId: string) {
      this.loading = true;
      this.hasError = false;
      const response = await downloadPrint(
        Number.parseInt(this.routeApplicationId),
        fileId,
      );

      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        handleApiErrorAndShowAlert(response);
        this.loading = false;
      } else {
        const _blob = await response.response.blob();
        this.loading = false;
        return {
          url: URL.createObjectURL(_blob),
          header: response.response.headers.get("Content-Disposition") || null,
        };
      }
    },
    async doGeneratePrint(printCode: string) {
      const response = await generatePrint(
        Number.parseInt(this.routeApplicationId),
        printCode,
      );
      if (response.errorType !== ErrorType.NONE) {
        throw new Error("print error");
      } else {
        return response.data;
      }
    },
    async loadApplicationCalculationsHistory(
      applicationId: number,
      handleError = false,
    ) {
      this.loading = true;
      this.hasError = false;
      const response =
        await loadApplicationCalculationsHistoryAPI(applicationId);
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        if (handleError) {
          handleApiErrorAndShowAlert(response);
        }
      } else {
        this.application[this.routeApplicationId].calculationsHistory =
          response.data;
      }
      this.loading = false;
    },
    async loadOngoingCalculations(handleError = false) {
      this.loading = true;
      this.hasError = false;
      const response = await loadOngoingCalculationsAPI(
        Number.parseInt(this.routeApplicationId),
      );
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        if (handleError) {
          handleApiErrorAndShowAlert(response);
        }
      } else {
        this.application[this.routeApplicationId].ongoingCalculations =
          response.data;
      }
      this.loading = false;
    },
    async loadCalculationDetails(calculationJobUuid: string) {
      this.loading = true;
      this.hasError = false;
      this.application[this.routeApplicationId].calculationDetails = null;
      const response = await loadCalculationDetailsAPI(
        Number.parseInt(this.routeApplicationId),
        calculationJobUuid,
      );
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        handleApiErrorAndShowAlert(response);
        this.loading = false;
      } else {
        this.application[this.routeApplicationId].calculationDetails =
          response.data;
      }
      this.loading = false;
    },
    async startCalculation(calculationCode: string) {
      const response = await startCalculationAPI(
        Number.parseInt(this.routeApplicationId),
        calculationCode,
      );
      if (response.errorType !== ErrorType.NONE) {
        throw new Error("calculation error");
      } else {
        return response.data;
      }
    },
    async loadUserFunctions(handleError = false) {
      this.loading = true;
      this.hasError = false;
      const response = await loadUserFunctionsAPI();
      if (response.errorType !== ErrorType.NONE) {
        this.hasError = true;
        this.errorResponse = response as HttpResponseError;
        if (handleError) {
          handleApiErrorAndShowAlert(response);
        }
      } else {
        const toSplit =
          this.tenantConfigs[
            RegistryEnvironment.DISABLE_NEW_APPLICATION_BUTTON_CONTEXT_FUNCTION
          ];
        if (toSplit !== undefined && toSplit !== null) {
          const ctxFnc = (toSplit as string).split("|");
          if (ctxFnc && ctxFnc.length === 2) {
            const context = ctxFnc[0];
            const func = ctxFnc[1];
            this.userFunctions = response.data;
            if (this.userFunctions) {
              const getuserFunctionReadOnly = this.userFunctions.find(
                (x) => x.context_id === context && x.function_name === func,
              );
              this.setIsFunctionReadOnly(!!getuserFunctionReadOnly);
            }
          }
        }
      }
      this.loading = false;
    },
  },
});
