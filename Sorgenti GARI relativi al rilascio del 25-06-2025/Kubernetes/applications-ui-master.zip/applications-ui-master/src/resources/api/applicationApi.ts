import {
  AmendmentModulesResponseSchema,
  ApplicationAnomalyResponseSchema,
  ApplicationDetailsSchema,
  ApplicationHistorySchema,
  ApplicationIsInTransitionModelSchema,
  ApplicationModulesResponseSchema,
  ApplicationSummaryDetailResponseSchema,
  ApplicationSummaryListModelSchema,
  ApplicationTransitionsSchema,
  CalculationSchema,
  CreateAmendmentResponseSchema,
  CreateApplicationResponseSchema,
  GeneratedCalculationListSchema,
  GeneratedCalculationSchema,
  GeneratedPrintSchema,
  PartyListModelSchema,
  PartyModelSchema,
  PartyRegistryDetailsSchema,
  PartyRegistryListSchema,
  PrintHistoryResponseSchema,
  TenantConfigListSchema,
  type AmendmentModulesResponse,
  type ApplicationAnomalyResponseModel,
  type ApplicationDetailsModel,
  type ApplicationHistoryModel,
  type ApplicationIsInTransitionModel,
  type ApplicationModulesResponse,
  type ApplicationSummaryDetailResponse,
  type ApplicationSummaryListModel,
  type ApplicationTransitionsModel,
  type CalculationModel,
  type CreateAmendmentModel,
  type CreateAmendmentResponseModel,
  type CreateApplicationModel,
  type CreateApplicationResponseModel,
  type GeneratedCalculationListModel,
  type GeneratedCalculationModel,
  type GeneratedPrintModel,
  type PartyListModel,
  type PartyModel,
  type PartyRegistryDetailsModel,
  type PartyRegistryListModel,
  type PrintHistoryResponseModel,
  type TenantConfigListModel,
} from "@/models/application";
import { UserFunctionArraySchema } from "./login";
import { removeNullsOrBlanksFromObject } from "@/models/utils";
import {
  ErrorType,
  type HttpJsonResult,
  type HttpResult,
  type RequestConfig,
} from "@abaco/safe-rest/src/HTTPClient";

import { RegistryEnvironment } from "@/stores/applicationStore";
import { getUserData } from "@abaco/safe-rest/src/sso2";
import { z } from "zod";
import { http } from "./http";
import { applicationsBaseUrl } from "@/utils/apiUtils";
import type { UserFunctionArrayModel } from "./login";

// eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unused-vars
function standardMockResponse(data: any): any {
  return new Promise((res) => {
    setTimeout(() => {
      res({
        response: {
          ok: true,
          redirected: false,
          status: 200,
          statusText: "OK",
          type: "default",
          url: "",
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          headers: null as any,
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          clone: null as any,
          body: null,
          bodyUsed: false,
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          arrayBuffer: null as any,
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          blob: null as any,
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          formData: null as any,
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          json: null as any,
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          text: null as any,
        },
        data: data,
        errorType: ErrorType.NONE,
      });
    }, 1000);
  });
}

const defaultHeader = {
  headers: {
    "Content-Type": "application/json",
  },
};

export const getApplicationSummaryList = async (
  partyId: number,
): Promise<HttpJsonResult<ApplicationSummaryListModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    ApplicationSummaryListModelSchema,
    `${applicationsBaseUrl(user.tenant)}/parties/${partyId}/summary`,
  );
};

export const getApplicationSummaryDetailList = async (
  partyId: number,
  year: number,
  nextKey: string | null,
): Promise<HttpJsonResult<ApplicationSummaryDetailResponse>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  const requestConfig: RequestConfig = {};
  requestConfig.params = {
    nextKey: nextKey,
  };
  removeNullsOrBlanksFromObject(requestConfig.params);

  return http.getJson(
    ApplicationSummaryDetailResponseSchema,
    `${applicationsBaseUrl(user.tenant)}/parties/${partyId}/years/${year}`,
    requestConfig,
  );
};

export const getParties = async (
  registryEnvironment: string,
  url: string,
  cuaa?: string | null,
  partyDesc?: string | null,
  nextKey?: string | null,
  hasCode = true,
): Promise<HttpJsonResult<PartyListModel | PartyRegistryListModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  const requestConfig: RequestConfig = {};

  requestConfig.params =
    registryEnvironment === RegistryEnvironment.LEGACY
      ? {
          search_code: cuaa && cuaa.replace(/-/g, ""),
          search_description: partyDesc,
          next_key: nextKey,
        }
      : {
          code: cuaa && cuaa.replace(/-/g, ""),
          fullName: partyDesc,
          nextKey,
          hasCode: hasCode ? true : undefined, // XXX REMOVE param if false
        };

  removeNullsOrBlanksFromObject(requestConfig.params);

  return http.getJson(
    z.union([PartyListModelSchema, PartyRegistryListSchema]),
    url.replace("{tenant}", user.tenant),
    requestConfig,
  );
};

export const getParty = async (
  partyId: number,
  url: string,
): Promise<HttpJsonResult<PartyModel | PartyRegistryDetailsModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    z.union([PartyModelSchema, PartyRegistryDetailsSchema]),
    url
      .replace("{tenant}", user.tenant)
      .replace("{partyId}", partyId.toString()),
  );
};

export const getApplicationModules = async (
  point_in_time?: string,
  nextKey?: string,
): Promise<HttpJsonResult<ApplicationModulesResponse>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  const requestConfig: RequestConfig = {};
  requestConfig.params = {
    point_in_time: point_in_time,
    nextKey: nextKey,
  };
  removeNullsOrBlanksFromObject(requestConfig.params);

  return http.getJson(
    ApplicationModulesResponseSchema,
    `/applications/${user.tenant}/api-priv/v1/modules`,
    requestConfig,
  );
};

export const getAmendmentModules = async (
  applicationId: number,
): Promise<HttpJsonResult<AmendmentModulesResponse>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    AmendmentModulesResponseSchema,
    `${applicationsBaseUrl(user.tenant)}/${applicationId}/amendment/modules`,
  );
};

export const createApplicationApi = async (
  newApplication: CreateApplicationModel,
): Promise<HttpJsonResult<CreateApplicationResponseModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.postJson(
    CreateApplicationResponseSchema,
    `${applicationsBaseUrl(user.tenant)}-async`,
    newApplication,
  );
};

export const createAmendmentApi = async (
  newAmendment: CreateAmendmentModel,
  applicationId: string,
): Promise<HttpJsonResult<CreateAmendmentResponseModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  const payload = { ...newAmendment, amendmentApplicationId: applicationId };

  return http.postJson(
    CreateAmendmentResponseSchema,
    `${applicationsBaseUrl(user.tenant)}-async/amendment-application`,
    payload,
  );
};

export const getApplicationDetails = async (
  applicationId: number,
): Promise<HttpJsonResult<ApplicationDetailsModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    ApplicationDetailsSchema,
    `${applicationsBaseUrl(user.tenant)}/${applicationId}`,
  );
};

export const getApplicationAnomalies = async (
  applicationId: number,
): Promise<HttpJsonResult<ApplicationAnomalyResponseModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    ApplicationAnomalyResponseSchema,
    `${applicationsBaseUrl(user.tenant)}/${applicationId}/anomalies`,
  );
};

export const getApplicationHistory = async (
  applicationId: number,
): Promise<HttpJsonResult<ApplicationHistoryModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    ApplicationHistorySchema,
    `${applicationsBaseUrl(user.tenant)}/${applicationId}/movement-history`,
  );
};

export const getApplicationPrintHistory = async (
  applicationId: number,
): Promise<HttpJsonResult<PrintHistoryResponseModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    PrintHistoryResponseSchema,
    `${applicationsBaseUrl(user.tenant)}/${applicationId}/print-history`,
  );
};

export const getOngoingPrints = async (
  applicationId: number,
): Promise<HttpJsonResult<PrintHistoryResponseModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    PrintHistoryResponseSchema,
    `${applicationsBaseUrl(user.tenant)}/${applicationId}/on-going-prints`,
  );
};

export const downloadPrint = async (
  applicationId: number,
  fileId: string,
   
): Promise<HttpResult> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }
  return http.get(
    `${applicationsBaseUrl(user.tenant)}/${applicationId}/prints/${fileId}`,
  );
};

export const generatePrint = async (
  applicationId: number,
  printCode: string,
   
): Promise<HttpJsonResult<GeneratedPrintModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }
  return http.postJson(
    GeneratedPrintSchema,
    `${applicationsBaseUrl(user.tenant)}/${applicationId}/prints/${printCode}`,
  );
};

export const getApplicationTransitions = async (
  applicationId: number,
): Promise<HttpJsonResult<ApplicationTransitionsModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }
  return http.getJson(
    ApplicationTransitionsSchema,
    `${applicationsBaseUrl(user.tenant)}/${applicationId}/transitions`,
  );
};

export const getIsInTransition = async (
  applicationId: number,
): Promise<HttpJsonResult<ApplicationIsInTransitionModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }
  return http.getJson(
    ApplicationIsInTransitionModelSchema,
    `${applicationsBaseUrl(user.tenant)}/${applicationId}/is-in-transition`,
  );
};

export const updateApplicationStatus = async (
  applicationId: number,
  transition_id: string,
  notes?: string,
): Promise<HttpResult> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }
  return http.put(
    `${applicationsBaseUrl(
      user.tenant,
    )}/${applicationId}/progress/${transition_id}`,
    JSON.stringify({ notes }),
    defaultHeader,
  );
};

export const loadTenantConfigsAPI = async (): Promise<
  HttpJsonResult<TenantConfigListModel>
> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }
  return http.getJson(
    TenantConfigListSchema,
    `${applicationsBaseUrl(user.tenant)}/environments`,
  );
};

export const loadApplicationCalculationsHistoryAPI = async (
  applicationId: number,
): Promise<HttpJsonResult<GeneratedCalculationListModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    GeneratedCalculationListSchema,
    `${applicationsBaseUrl(user.tenant)}/${applicationId}/calculation-history`,
  );
};

export const loadOngoingCalculationsAPI = async (
  applicationId: number,
): Promise<HttpJsonResult<GeneratedCalculationListModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }

  return http.getJson(
    GeneratedCalculationListSchema,
    `${applicationsBaseUrl(
      user.tenant,
    )}/${applicationId}/on-going-calculations`,
  );
};

export const startCalculationAPI = async (
  applicationId: number,
  calculationCode: string,
): Promise<HttpJsonResult<GeneratedCalculationModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }
  return http.postJson(
    GeneratedCalculationSchema,
    `${applicationsBaseUrl(
      user.tenant,
    )}/${applicationId}/calculations/${calculationCode}`,
  );
};

export const loadCalculationDetailsAPI = async (
  applicationId: number,
  calculationJobUuid: string,
): Promise<HttpJsonResult<CalculationModel>> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }
  return http.getJson(
    CalculationSchema,
    `${applicationsBaseUrl(
      user.tenant,
    )}/${applicationId}/calculations/${calculationJobUuid}/render`,
  );
};

export const loadUserFunctionsAPI = async (): Promise<
  HttpJsonResult<UserFunctionArrayModel>
> => {
  const user = getUserData();
  if (!user) {
    return {
      errorType: ErrorType.OTHER,
      err: 401,
    };
  }
  return http.getJson(
    UserFunctionArraySchema,
    `/sso2/${user.tenant}/public/v1/user-functions`,
  );
};
