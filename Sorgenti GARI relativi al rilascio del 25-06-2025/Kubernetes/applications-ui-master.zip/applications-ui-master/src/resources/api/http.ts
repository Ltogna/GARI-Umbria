import { FORCED_CONTEXT } from "@/constants";
import {
  HTTPClient,
  type HTTPClientOptions,
  type RequestConfig,
} from "@abaco/safe-rest/src/HTTPClient";
import { installSso2RequestConfigProvider } from "@abaco/safe-rest/src/sso2";

class ExtendedHTTPClient extends HTTPClient {
  constructor(config: HTTPClientOptions = {}) {
    super(config);
  }

  public async provideConfig(config?: RequestConfig): Promise<RequestConfig> {
    const provide = await super.provideConfig(config);
    if (import.meta.env.DEV && provide.params && provide.params._nc) {
      delete provide.params._nc;
    }
    return provide;
  }
}

export const http = new ExtendedHTTPClient({
  forcedContext: FORCED_CONTEXT,
});
installSso2RequestConfigProvider(http, "/sso2");
