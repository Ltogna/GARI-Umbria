import type { DynamicModulesState } from "@abaco/micro-frontend/src/model";
import type { RouteRecordRaw } from "vue-router";

export const modulesState: DynamicModulesState = {
  modules: {},
};

const routes: RouteRecordRaw[] = [];

routes.push(
  {
    redirect: { name: "applicationList" },
    path: "/",
  },
  // List of task
  {
    path: "/applicationList",
    name: "applicationList",
    component: () => import("../views/ApplicationSearchView.vue"),
  },
  {
    path: "/applicationlist/party/:partyId/result",
    name: "applicationListResults",
    component: () => import("../views/ApplicationViewResultView.vue"),
  },
  {
    path: "/newApplication",
    name: "newApplication",
    component: () => import("../views/NewApplicationView.vue"),
  },
  {
    path: "/createApplication/party/:partyId",
    name: "createApplication",
    component: () => import("../views/CreateApplicationView.vue"),
  },
  {
    path: "/createAmendment/party/:partyId",
    name: "createAmendment",
    component: () => import("../views/CreateAmendmentView.vue"),
  },
  {
    path: "/applicationlist/result/:applicationId/applicationDetails/:p*",
    name: "applicationDetail",
    component: () => import("../views/ApplicationDetailsView.vue"),
  },
  {
    path: "/dossier-applicationlist",
    name: "dossierApplicationsSummaryList",
    component: () => import("../views/DossierApplicationSummaryListView.vue"),
  },
  // ,
  // {
  //   path: "/applicationlist/result/:applicationId/applicationDetails/:formRoute*",
  //   name: "applicationDetailForm",
  //   component: () => import("../views/ApplicationDetailsView.vue"),
  // }
);

export default routes;
