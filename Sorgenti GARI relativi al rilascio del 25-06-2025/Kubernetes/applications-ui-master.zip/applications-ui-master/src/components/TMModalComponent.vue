<script setup lang="ts">
// Vue
import {
  onUnmounted,
  ref,
  watch,
  watchEffect,
  defineProps,
  withDefaults,
  defineEmits,
} from "vue";
// Boootstrap Italia components
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
//State manager

const { getColor } = useColors();

const props = withDefaults(
  defineProps<{
    openModal: boolean;
    isLoading: boolean;
    ariaLabelledBy: string;
    modalTitleText: string;
    cancelButtonText: string;
    confirmButtonText: string;
    confirmFunction: () => void;
    cancelFunction: () => void;
    preventDismiss?: boolean;
  }>(),
  {
    preventDismiss: true,
  },
);

const emit = defineEmits(["closeModal", "hiddenModal"]);
const openModalRef = ref<boolean>(false);
watchEffect(() => {
  openModalRef.value = props.openModal;
});

watch(openModalRef, () => {
  if (!openModalRef.value) {
    closeModal();
  }
});

function closeModal() {
  openModalRef.value = false;
  props.cancelFunction();
  emit("closeModal");
}

function emitHiddenModal() {
  emit("hiddenModal");
}

onUnmounted(() => {
  document.body.classList.remove("modal-open");
  document.body.style.removeProperty("overflow");
  document.body.style.removeProperty("padding-right");
});
</script>

<template>
  <BiModal
    :disabled-teleport="true"
    :extra-footer-class="'d-flex justify-content-center'"
    v-model="openModalRef"
    :aria-labelledby="props.ariaLabelledBy"
    :title="props.modalTitleText"
    :preventDismiss="props.preventDismiss"
    @hidden-modal="emitHiddenModal()"
  >
    <template #body>
      <slot name="body"></slot>
    </template>
    <template #footer>
      <BiButton
        v-if="!props.isLoading"
        size="lg"
        :class="getColor('button', 'success', 'outline')"
        @click.stop="closeModal"
      >
        {{ cancelButtonText }}
      </BiButton>
      <BiButton
        v-if="!props.isLoading"
        isPrimary
        size="lg"
        :class="getColor('button', 'success')"
        @click.stop="confirmFunction"
        >{{ props.confirmButtonText }}</BiButton
      >
      <BiProgressIndicator
        :type="'spinner'"
        v-if="props.isLoading"
      ></BiProgressIndicator>
    </template>
  </BiModal>
</template>
