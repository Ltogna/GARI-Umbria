<script setup lang="ts">
import { MessageType, type TransitionMessage } from "@/models/application";
import {
  ALREADY_AMENDED_APPLICATION_ERROR_CODE,
  APPLICATION_CREATION_ERROR,
  NOT_ALLOWED_MULTIPLE_APPLICATIONS_ERROR,
  WAIVED_APPLICATION_ERROR_CODE,
} from "@/stores/applicationStore";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import { computed, defineProps, inject } from "vue";
import { useI18n } from "vue-i18n";

const moduleId = inject("moduleId");
const { t } = useI18n({});

const props = defineProps<{
  messages: TransitionMessage[];
}>();

const messagesSorted = computed(() =>
  [...props.messages].sort((a, b) => a.errorLevel - b.errorLevel),
);

function getErrorMessage(message: TransitionMessage) {
  switch (message.code) {
    case APPLICATION_CREATION_ERROR:
      return t(`${moduleId}.errors.createApplicationFailed`);
    case NOT_ALLOWED_MULTIPLE_APPLICATIONS_ERROR:
      return t(`${moduleId}.errors.NOT_ALLOWED_MULTIPLE_APPLICATIONS_ERROR`);
    case ALREADY_AMENDED_APPLICATION_ERROR_CODE:
      return t(`${moduleId}.errors.ALREADY_AMENDED_APPLICATION_ERROR_CODE`);
    case WAIVED_APPLICATION_ERROR_CODE:
      return t(`${moduleId}.errors.WAIVED_APPLICATION_ERROR_CODE`);
    default:
      return message.description;
  }
}
</script>

<template>
  <div v-for="(message, i) in messagesSorted" :key="i">
    <BiAlert isSuccess v-if="message.type === MessageType.INFO">
      <template #body
        ><div class="slot-whitespace">
          {{ message.description }}
        </div></template
      >
    </BiAlert>
    <BiAlert isWarn v-if="message.type === MessageType.WARNING">
      <template #body
        ><div class="slot-whitespace">
          {{ message.description }}
        </div></template
      >
    </BiAlert>
    <BiAlert isError v-if="message.type === MessageType.ERROR">
      <template #body>
        <div class="slot-whitespace">
          {{ getErrorMessage(message) }}
        </div>
      </template>
    </BiAlert>
  </div>
</template>

<style scoped>
.slot-whitespace {
  white-space: break-spaces !important;
}
</style>
