<script setup lang="ts">
import { computed, inject, ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import { type PartyModel } from "@/models/application";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiCollapse from "@abaco/bootstrap-italia-components/src/components/BiCollapse/BiCollapse.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { useApplicationStore } from "@/stores/applicationStore";
import { type SubjectFilter } from "@/models/application";
import { type ValidatedInput } from "@/models/form";
import { checkMaxLength, verifyField } from "@/utils/formUtils";

const moduleId = inject("moduleId");
const { getColor } = useColors();
const { t } = useI18n({});
const applicationStore = useApplicationStore();
const openSearchSubjectModal = ref<boolean>(false);
const showNoSubjectsAlert = ref<boolean>(false);
const showResult = ref<boolean>(false);

const partyRegistryUrlNotExist = computed(
  () => applicationStore.getTenantConfigPartyRegistryError,
);

const isLoading = computed(() => applicationStore.getIsLoading);

const emit = defineEmits<{
  (e: "searchFormVisible", value: boolean): void;
}>();

const modalForm = ref<SubjectFilter>({
  cuaa: "",
  denomination: "",
});

const searchFormValidators = ref<Record<string, ValidatedInput<string>>>({
  cuaa: {
    val: modalForm.value.cuaa,
    errors: [],
  },
  denomination: {
    val: modalForm.value.denomination,
    errors: [],
  },
});

const resultSubjects = computed(() => applicationStore.getSubjectList);

const applicationFilter = computed(
  () => applicationStore.getApplicationListStatusFilter,
);

function onSelectSubject(subject: PartyModel) {
  applicationStore.setApplicationListFilter({
    referenceSubject: subject.description || "",
    applicationNumber: "",
  });
  applicationStore.setSelectedSubject(subject);
  onCloseModal();
}

async function searchSubjectList() {
  searchFormValidators.value.cuaa.val = modalForm.value.cuaa;
  searchFormValidators.value.denomination.val = modalForm.value.denomination;

  const maxLengthErrorMessage = t(`${moduleId}.general.maxLength`);
  const errors: boolean[] = [];
  errors.push(
    verifyField(
      [
        () =>
          checkMaxLength(
            searchFormValidators.value.cuaa,
            50,
            maxLengthErrorMessage,
          ),
      ],
      searchFormValidators.value.cuaa,
    ),
  );

  errors.push(
    verifyField(
      [
        () =>
          checkMaxLength(
            searchFormValidators.value.denomination,
            150,
            maxLengthErrorMessage,
          ),
      ],
      searchFormValidators.value.denomination,
    ),
  );

  if (errors.findIndex((x: boolean) => x) !== -1) return;

  showNoSubjectsAlert.value = false;
  applicationStore.clearSubjectList();
  await callSearchSubject();
  if (
    (applicationStore.hasError &&
      applicationStore.getErrorResponse?.response.status === 404) ||
    (applicationStore.subjectList?.count || 0) === 0
  ) {
    applicationStore.clearSubjectList();
    showNoSubjectsAlert.value = true;
  } else {
    showResult.value = true;
  }
}

async function callSearchSubject() {
  await applicationStore.searchSubjects(
    modalForm.value.cuaa,
    modalForm.value.denomination,
  );
}

function openSearchModal() {
  emit("searchFormVisible", true);
  openSearchSubjectModal.value = true;
}

function onCloseModal() {
  emit("searchFormVisible", false);
  openSearchSubjectModal.value = false;
  applicationStore.clearSubjectList();
  modalForm.value.cuaa = "";
  modalForm.value.denomination = "";
  searchFormValidators.value.cuaa.errors = [];
  searchFormValidators.value.denomination.errors = [];
  showNoSubjectsAlert.value = false;
}

watch(
  () => modalForm.value.cuaa,
  () => {
    if (modalForm.value.cuaa == "") return;
    modalForm.value.denomination = "";
    searchFormValidators.value.denomination.errors = [];
  },
);

watch(
  () => modalForm.value.denomination,
  () => {
    if (modalForm.value.denomination == "") return;
    modalForm.value.cuaa = "";
    searchFormValidators.value.cuaa.errors = [];
  },
);
</script>
<template>
  <div class="form-group col-xs-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">
    <BiInput
      :label="t(`${moduleId}.searchForm.referenceSubject`)"
      :placeholder="t(`${moduleId}.searchForm.searchSubject`)"
      v-model="applicationFilter.referenceSubject"
      :disabled="true"
      class="mb-4"
    />
  </div>
  <div class="form-group col-xs-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">
    <BiButton
      v-if="!isLoading && !partyRegistryUrlNotExist"
      class="mt-4 py-1"
      :class="getColor('button', 'primary', 'outline')"
      @click.stop="openSearchModal()"
    >
      {{ t(`${moduleId}.searchForm.searchSubject`) }}
    </BiButton>
  </div>

  <BiModal
    :disabled-teleport="true"
    :modelValue="openSearchSubjectModal"
    :ariaLabelledby="t(`${moduleId}.searchForm.searchSubject`)"
    :title="t(`${moduleId}.searchForm.searchSubject`)"
    :size="'lg'"
    :preventDismiss="true"
    :extra-footer-class="'justify-content-center'"
    ><template v-slot:body>
      <form
        id="subjectSearchForm"
        ref="subjectSearchFormRef"
        @submit.prevent="() => {}"
      >
        <div class="form-group mt-5 w-100">
          <BiInput
            :label="t(`${moduleId}.searchForm.cuaaLabel`)"
            :placeholder="t(`${moduleId}.general.insertCode`)"
            v-model="modalForm.cuaa"
            class="mb-4"
            :errors="searchFormValidators.cuaa.errors"
          />
        </div>
        <div class="form-group w-100">
          <BiInput
            :label="t(`${moduleId}.searchForm.denominationLabel`)"
            :placeholder="t(`${moduleId}.general.textToSearch`)"
            v-model="modalForm.denomination"
            class="mb-4"
            :errors="searchFormValidators.denomination.errors"
          />
        </div>
      </form>
    </template>
    <template v-slot:footer>
      <div class="d-flex flex-column">
        <div v-if="showNoSubjectsAlert" class="row">
          <div class="col-3"></div>
          <div class="my-3">
            <BiAlert isWarn>
              <template #body>{{
                t(`${moduleId}.searchForm.errors.NO_PARTY_FOUND_EXCEPTION`)
              }}</template>
            </BiAlert>
          </div>
          <div class="col-3"></div>
        </div>
        <div>
          <div
            v-if="!applicationStore.loading"
            class="mt-0 mb-5 d-flex justify-content-center"
          >
            <BiButton
              size="lg"
              class="btn"
              :class="getColor('button', 'secondary', 'outline')"
              @click.stop="onCloseModal"
            >
              {{ t(`${moduleId}.general.cancel`) }}
            </BiButton>
            <BiButton
              :is-disabled="!modalForm.cuaa && !modalForm.denomination"
              type="submit"
              form="subjectSearchForm"
              isPrimary
              size="lg"
              class="ms-3 btn"
              :class="getColor('button', 'success')"
              @click.stop="searchSubjectList()"
              >{{ t(`${moduleId}.general.search`) }}</BiButton
            >
          </div>

          <div v-else class="d-flex col-12 justify-content-center mb-5">
            <BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
          </div>
        </div>
      </div>

      <div id="table-collapse" class="w-100">
        <BiTable
          v-if="resultSubjects"
          isRowHover
          class="table-hover mb-4 table-responsive w-100"
          extraTableClasses="table-head-bg"
          isResponsive
        >
          <template v-slot:head>
            <tr class="bg-light" :class="getColor('text', 'secondary')">
              <th scope="col">
                {{ t(`${moduleId}.searchForm.denominationLabel`) }}
              </th>
              <th scope="col">
                {{ t(`${moduleId}.searchForm.cuaaLabel`) }}
              </th>
              <th scope="col"></th>
            </tr>
          </template>
          <template v-slot:body>
            <tr v-for="(subject, i) in resultSubjects" :key="i">
              <td :data-label="t(`${moduleId}.searchForm.denominationLabel`)">
                {{ subject.description }}
              </td>
              <td :data-label="t(`${moduleId}.searchForm.cuaaLabel`)">
                {{ subject.code }}
              </td>
              <td class="actions">
                <div class="d-flex justify-content-center">
                  <BiButton
                    :width="40"
                    @click.stop="onSelectSubject(subject)"
                    :class="`${getColor('button', 'info', 'outline')}`"
                  >
                    <BiIcon icon="plus" color="primary" size="lg" />
                  </BiButton>
                </div>
              </td>
            </tr>
          </template>
        </BiTable>
        <div
          class="d-flex col-12 justify-content-center mb-5"
          @click.stop
          v-if="resultSubjects"
        >
          <BiButton
            v-if="
              !applicationStore.loading &&
              !applicationStore.hasError &&
              applicationStore.subjectList?.nextKey &&
              parseInt(applicationStore.subjectList?.nextKey) > 0
            "
            @click="callSearchSubject()"
            :class="getColor('button', 'primary', 'outline')"
          >
            {{ t(`${moduleId}.list.loadMore`) }}
          </BiButton>
          <BiProgressIndicator
            v-if="
              applicationStore.loading &&
              applicationStore.subjectList?.nextKey &&
              parseInt(applicationStore.subjectList?.nextKey) > 0
            "
            :type="'spinner'"
          ></BiProgressIndicator>
        </div>
      </div>
      <BiCollapse
        class="d-none"
        :model-value="showResult"
        :targetSelector="'#table-collapse'"
      >
      </BiCollapse>
    </template>
  </BiModal>
</template>
