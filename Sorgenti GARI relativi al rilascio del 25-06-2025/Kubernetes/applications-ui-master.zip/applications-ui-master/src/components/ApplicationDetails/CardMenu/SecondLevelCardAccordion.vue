<script setup lang="ts">
import {
  CardState,
  type CardNode,
  type SelectedCard,
} from "@/models/application";
import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import CardStateIcon from "./CardStateIcon.vue";

const emit = defineEmits(["openCard"]);
defineProps<{
  node: CardNode;
  selectedCardId: string | null;
}>();

function selectCard(node: CardNode, isClicked = false) {
  const selectedCardInfo: SelectedCard = {
    id: node.id,
    softwareUrl: node.softwareUrl,
    routerUrl: node.routerUrl,
    params: node.params,
    flReadOnly: node.flReadOnly,
    compileStatusIdentifier: node.compileStatusIdentifier,
    compileStatus: node.compileStatus,
    formConfigId: node.formConfigId,
    formCode: node.formCode,
    partyId: node.partyId,
    partyCode: node.partyCode,
    clicked: isClicked,
  };
  emit("openCard", selectedCardInfo);
}
</script>
<style scoped>
.cursor-pointer {
  cursor: pointer;
}
</style>
<template>
  <BiAccordion
    :model-value="node.isOpen"
    :title="node.name"
    :body-extra-class="'ps-1 pe-2 pb-0'"
    hide-arrow
    header-extra-class="w-100 border-bottom border-top-0 ps-0"
  >
    <ul class="no-dot ps-3">
      <li
        v-for="(leaf, i) in node.children"
        :key="i"
        class="cursor-pointer mb-2 d-flex justify-content-between ps-2"
        @click="selectCard(leaf, true)"
      >
        <div
          class="application-module__underline_hover_card"
          :class="
            selectedCardId !== null && leaf.id === selectedCardId
              ? 'text-decoration-underline'
              : ''
          "
        >
          {{ leaf.name }}
        </div>
        <div v-if="leaf.compileStatus">
          <CardStateIcon :stateType="leaf.compileStatus as CardState" />
        </div>
      </li>
    </ul>
  </BiAccordion>
</template>
