<!-- eslint-disable @typescript-eslint/no-explicit-any -->
<script setup lang="ts">
import type {
  GeneratedPrintModel,
  PrintHistoryResponseModel,
  PrintModel,
} from "@/models/application";
import { useApplicationStore } from "@/stores/applicationStore";
import { parse } from "@/utils/contentDisposition";
import { getFormattedDate } from "@/utils/dateUtils";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { computed, defineProps, inject, onMounted, ref, watch } from "vue";
import { useI18n } from "vue-i18n";

export type PrintModelWithOngoingPrint = {
  ongoingPrint?: GeneratedPrintModel;
  hasError?: boolean;
  fileId: string;
  printCode: string;
  printDate: string | number;
  printDescription: string;
  sortOrder: number;
  params: Record<string, string>;
  isGenerating: boolean;
};

const props = defineProps<{
  applicationId: number;
}>();
const { getColor } = useColors();
const { t } = useI18n({});
const moduleId = inject("moduleId");
const applicationStore = useApplicationStore();
const prints = ref<Record<string, PrintModelWithOngoingPrint>>({});
const isMounting = ref<boolean>(true);
const onGoingPrints = ref<PrintHistoryResponseModel | null | undefined>(
  undefined,
);
const loadingOnGoingPrints = computed(
  () => applicationStore.getLoadingOnGoingPrints,
);
const applicationDetailsPrints = computed(
  () => applicationStore.getApplicationDetails.prints || [],
);

watch(onGoingPrints, async (current, prev) => {
  if (prev !== undefined && JSON.stringify(current) !== JSON.stringify(prev))
    await applicationStore.loadApplicationDetails(props.applicationId);
  recalculateOngoingPrintsData();
  if ((onGoingPrints.value || []).length === 0) {
    applicationStore.setLoadingOngoingPrints(false);
  } else {
    setTimeout(async () => {
      applicationStore.setLoadingOngoingPrints(false);
      checkOngoingPrintsCallback();
    }, 5000);
  }
});

onMounted(async () => {
  await applicationStore.loadApplicationPrintHistory(props.applicationId);
  let alreadyLoadedPrints = false;
  if (!loadingOnGoingPrints.value) {
    await applicationStore.loadOngoingPrints();
    alreadyLoadedPrints = true;
    await applicationStore.loadApplicationDetails(props.applicationId);
  }
  const printHistory = applicationStore.getPrintHistory;
  onGoingPrints.value = applicationStore.getOngoingPrints;
  const appDetailsPrints = applicationDetailsPrints.value;
  appDetailsPrints.sort((a, b) => {
    return a.sortOrder < b.sortOrder ? 1 : -1;
  });
  prints.value = appDetailsPrints.reduce(
    (
      acc: Record<string, PrintModelWithOngoingPrint>,
      currentValue: PrintModel,
    ) => {
      const ongoingPrint = onGoingPrints.value?.find((el) => {
        // eslint-disable-next-line @typescript-eslint/no-unused-expressions
        el.printCode === currentValue.printCode;
      });
      let printDate: string | number = "";
      if (!currentValue.lastPrint && printHistory) {
        const oldPrint = printHistory.find(
          (print) => print.printCode === currentValue.printCode,
        );
        if (oldPrint) printDate = oldPrint.printDate;
      }
      const a = acc;
      a[currentValue.printCode] = {
        ongoingPrint: ongoingPrint,
        hasError: false,
        fileId: currentValue.lastPrint?.fileId || "",
        printCode: currentValue.printCode,
        printDate: currentValue.lastPrint?.printDate ?? printDate,
        printDescription: currentValue.printDescription,
        sortOrder: currentValue.sortOrder,
        params: currentValue.params,
        isGenerating: !!ongoingPrint,
      };
      return a;
    },
    {},
  );
  isMounting.value = false;
  if ((onGoingPrints.value?.length || 0 > 0) && !alreadyLoadedPrints)
    await checkOngoingPrintsCallback();
});

async function openPdf(printCode: string) {
  if (printCode) {
    const applicationDetails = applicationStore.getApplicationDetails;
    if (applicationDetails && applicationDetails.prints) {
      const printElem = applicationDetails.prints.find(
        (el) => el.printCode === printCode,
      );

      const fileUrl = await applicationStore.doDownloadPrint(
        printElem?.lastPrint?.fileId as string,
      );

      let fileName = printElem?.printDescription
        ? `${printElem?.printDescription}.pdf`
        : "unnamed.txt";

      if (fileUrl?.header) {
        try {
          const parsed = parse(fileUrl?.header);
          if (
            parsed.type === "attachment" &&
            typeof parsed.parameters.filename === "string"
          ) {
            fileName = parsed.parameters.filename;
          }
        } catch (e) {
          console.warn(e);
        }
      }

      if (fileUrl) {
        const fileLink = document.createElement("a");
        fileLink.href = fileUrl.url ?? "unnamed.txt";
        fileLink.download = fileName;
        fileLink.click();
      }
    }
  }
}

const DUMMY = "dummy";

function dummyOngoindPrintBuilder(printItem: PrintModelWithOngoingPrint) {
  return {
    printCode: printItem.printCode,
    printDate: new Date().getTime(),
    printJobUuid: DUMMY,
    processStatus: DUMMY,
    fileId: null,
    username: DUMMY,
    printStatus: DUMMY,
    printDescription: DUMMY,
  };
}

function recalculateOngoingPrintsData() {
  onGoingPrints.value?.forEach((print) => {
    prints.value[print.printCode].isGenerating = true;
  });
  Object.keys(prints.value).forEach((key) => {
    if (
      prints.value[key].isGenerating &&
      onGoingPrints.value?.findIndex((el) => el.printCode === key) === -1
    ) {
      const detailsPrint = applicationDetailsPrints.value.find(
        (print) => print.printCode === key,
      );
      prints.value[key].fileId = detailsPrint?.lastPrint?.fileId || "";
      prints.value[key].printDate = detailsPrint?.lastPrint?.printDate || "";
      prints.value[key].isGenerating = false;
    }
  });
}

async function checkOngoingPrintsCallback() {
  if (!loadingOnGoingPrints.value) {
    applicationStore.setLoadingOngoingPrints(true);
    await applicationStore.loadOngoingPrints();
    onGoingPrints.value = applicationStore.getOngoingPrints;
  }
}

async function generatePdf(printItem: PrintModelWithOngoingPrint) {
  printItem.ongoingPrint = dummyOngoindPrintBuilder(printItem);
  try {
    printItem.isGenerating = true;
    printItem.ongoingPrint = await applicationStore.doGeneratePrint(
      printItem.printCode,
    );
    printItem.hasError = false;
    await checkOngoingPrintsCallback();
  } catch (err) {
    console.error(err);
    delete printItem.ongoingPrint;
    printItem.isGenerating = false;
    printItem.hasError = true;
  }
}
</script>

<style scoped>
.subtext-size {
  font-size: 12px;
}
.cursor-pointer {
  cursor: pointer;
}
</style>

<template>
  <div>
    <div v-if="isMounting" class="d-flex justify-content-center">
      <BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
    </div>
    <BiTable v-else extraHeaderClasses="d-none border-0" :isRowHover="true">
      <template v-slot:head>
        <tr class="" :class="getColor('text', 'secondary')">
          <th scope="col"></th>
          <th scope="col"></th>
        </tr>
      </template>
      <template #body>
        <tr v-for="(printItem, key, index) in prints" :key="index">
          <td scope="row">
            <div>
              <div class="text-end text-lg-start">
                {{ printItem.printDescription }}
              </div>
              <div v-if="printItem.printDate || printItem.hasError">
                <div class="subtext-size mt-4">
                  <div v-if="!printItem.hasError">
                    {{
                      t(
                        `${moduleId}.applicationDetails.printModal.lastExecution`,
                        {
                          date: getFormattedDate(
                            printItem.printDate.toLocaleString(),
                            true,
                          ),
                        },
                      )
                    }}
                  </div>
                  <div v-else>
                    <span
                      >{{
                        t(
                          `${moduleId}.applicationDetails.printModal.lastExecutionInError`,
                        ) + " "
                      }}
                    </span>
                    <BiIcon
                      :icon="'circle-xmark'"
                      :icon-style="'light'"
                      :class="getColor('text', 'danger')"
                      size="1x"
                    >
                    </BiIcon>
                  </div>
                </div>
              </div>
            </div>
          </td>
          <td style="vertical-align: top">
            <div class="d-flex flex-row-reverse">
              <div class="d-flex flex-column">
                <BiButton
                  v-if="!printItem.isGenerating"
                  @click="generatePdf(printItem)"
                  :class="getColor('button', 'secondary')"
                  class="me-2"
                >
                  {{
                    t(`${moduleId}.applicationDetails.printModal.generatePdf`)
                  }}
                </BiButton>
                <BiProgressIndicator
                  v-else
                  style="padding-right: 2rem"
                  :type="'spinner'"
                ></BiProgressIndicator>
                <BiButton
                  v-if="
                    !isMounting &&
                    !printItem.isGenerating &&
                    !printItem.hasError &&
                    printItem.fileId
                  "
                  @click="openPdf(printItem.printCode)"
                  :class="getColor('button', 'secondary', 'outline')"
                  class="me-2 mt-2"
                >
                  {{ t(`${moduleId}.applicationDetails.printModal.openPdf`) }}
                </BiButton>
              </div>
            </div>
          </td>
        </tr>
      </template>
    </BiTable>
  </div>
</template>
