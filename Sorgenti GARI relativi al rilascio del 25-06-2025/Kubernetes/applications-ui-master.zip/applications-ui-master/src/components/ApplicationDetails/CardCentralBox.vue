<script setup lang="ts">
import { type SelectedCard } from "@/models/application";
import { useRoute, useRouter } from "vue-router";
import { dynamicModuleRouteBuilder } from "@abaco/micro-frontend/src/resources/microRouterHelpers";
import { modulesState } from "../../routes/index";
import { computed, inject, onMounted, ref, watch } from "vue";
import { cleanBasePath } from "@/models/utils";
import { useApplicationStore } from "@/stores/applicationStore";
import { extractModuleId } from "@/utils/formUtils";
import { FORCED_CONTEXT } from "@/constants";

//Component needed to open the cards
const props = defineProps<{
  cardInfo: SelectedCard;
}>();

const router = useRouter();
const route = useRoute();
const applicationStore = useApplicationStore();
const applicationId = computed(() => route.params.applicationId);
const isApplicationClosed = computed(
  () => applicationStore.getApplicationDetails.isClosed,
);
const externalModules = modulesState;
const basePath = inject("basePath");

const isVisible = ref<boolean>(true);

watch(
  () => props.cardInfo,
  () => {
    loadRoute();
  },
);

const APPLICATION_DETAIL_ROUTE = "applicationDetail";

function loadRoute() {
  const moduleId = extractModuleId(props.cardInfo.softwareUrl);
  if (moduleId && !externalModules.modules[moduleId]) {
    externalModules.modules[moduleId] = {
      url: FORCED_CONTEXT + (props.cardInfo.softwareUrl ?? ""),
    };
  }
  if (
    (router.getRoutes().find((r) => r.name === APPLICATION_DETAIL_ROUTE)
      ?.children.length ?? 0) === 0 &&
    moduleId
  ) {
    router.addRoute(
      APPLICATION_DETAIL_ROUTE,
      dynamicModuleRouteBuilder(moduleId, moduleId, externalModules),
    );
  }
  let urlToRoute = props.cardInfo.routerUrl ?? "";
  if (urlToRoute && !urlToRoute.startsWith("/")) {
    urlToRoute = "/" + urlToRoute;
  }
  if (urlToRoute) {
    let query = {
      readOnly: !isApplicationClosed.value
        ? props.cardInfo.flReadOnly
          ? 1
          : 0
        : 1,
      partyId: props.cardInfo.partyId,
      compileStatusIdentifier: props.cardInfo.compileStatusIdentifier,
      formConfigId: props.cardInfo.formConfigId,
      formCode: props.cardInfo.formCode,
      partyCode: props.cardInfo.partyCode,
    };
    query = { ...query, ...props.cardInfo.params };
    const pathToRoute = `${cleanBasePath(
      basePath as string,
    )}/applicationlist/result/${
      applicationId.value
    }/applicationDetails/${moduleId}${urlToRoute}`;

    if (
      pathToRoute !== route.path ||
      JSON.stringify(route.query) !==
        JSON.stringify({
          readOnly: query.readOnly.toString(),
          partyId: query.partyId?.toString(),
          compileStatusIdentifier: query.compileStatusIdentifier,
          formConfigId: query.formConfigId?.toString(),
          formCode: query.formCode,
          partyCode: query.partyCode,
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          document_code: (query as any).document_code,
        })
    ) {
      isVisible.value = false;
      // eslint-disable-next-line @typescript-eslint/no-unused-expressions
      import.meta.env.DEV && console.log("is different!");
      router.push({
        path: pathToRoute,
        query: query,
      });
      isVisible.value = true;
    } else if (!props.cardInfo.clicked) {
      // eslint-disable-next-line @typescript-eslint/no-unused-expressions
      import.meta.env.DEV && console.log("is not clicked!");
      router.push({
        path: pathToRoute,
        query: query,
      });
    }
  }
}

onMounted(() => {
  loadRoute();
});
</script>

<template>
  <RouterView v-if="isVisible"></RouterView>
</template>
