<script setup lang="ts">
import { useApplicationStore } from "@/stores/applicationStore";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute } from "vue-router";
import MovementHistoryRow from "./MovementHistoryRow.vue";

const moduleId = inject("moduleId");
const { getColor } = useColors();
const { t } = useI18n({});
const route = useRoute();
const applicationStore = useApplicationStore();
const applicationId = ref<number>(
  parseInt(route.params.applicationId as string),
);

const applicationHistory = computed(
  () => applicationStore.getApplicationHistory ?? [],
);

onMounted(async () => {
  await applicationStore.loadApplicationHistory(applicationId.value, true);
});
</script>
<template>
  <div class="container">
    <div class="w-100 d-flex mb-3 mt-4">
      <h4 class="fw-bold" :class="getColor('text', 'primary')">
        <BiIcon icon="list" size="lg" />
        {{ t(`${moduleId}.applicationDetails.movementHistory.title`) }}
      </h4>
    </div>
    <BiTable
      class="table-hover table-responsive collapsable-table"
      extraTableClasses="table-head-bg mb-0"
      @click.stop
    >
      <template v-slot:head>
        <tr class="bg-light" :class="getColor('text', 'secondary')">
          <th scope="col">
            {{
              t(`${moduleId}.applicationDetails.movementHistory.movementName`)
            }}
          </th>
          <th scope="col">
            {{
              t(`${moduleId}.applicationDetails.movementHistory.arrivalStatus`)
            }}
          </th>
          <th scope="col">
            {{
              t(`${moduleId}.applicationDetails.movementHistory.executionDate`)
            }}
          </th>
          <th scope="col">
            {{ t(`${moduleId}.applicationDetails.movementHistory.user`) }}
          </th>
          <th scope="col">
            {{
              t(
                `${moduleId}.applicationDetails.movementHistory.movementOutcome`,
              )
            }}
          </th>
          <th scope="col"></th>
        </tr>
      </template>
      <template v-slot:body>
        <MovementHistoryRow
          v-for="movement in applicationHistory"
          :key="movement.id"
          :movement="movement"
        />
      </template>
    </BiTable>
  </div>
</template>
