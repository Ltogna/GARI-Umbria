<script setup lang="ts">
import { useApplicationStore } from "@/stores/applicationStore";
import { parse } from "@/utils/contentDisposition";
import { getFormattedDate } from "@/utils/dateUtils";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute } from "vue-router";

const moduleId = inject("moduleId");
const { t } = useI18n({});
const { getColor } = useColors();
const route = useRoute();
const applicationStore = useApplicationStore();
const applicationId = ref<number>(
  parseInt(route.params.applicationId as string),
);
const printList = computed(() => {
  const printHistory = applicationStore.getPrintHistory;
  if (printHistory) {
    printHistory.sort((a, b) => {
      return new Date(a.printDate).getTime() > new Date(b.printDate).getTime()
        ? -1
        : 1;
    });
  }
  return printHistory;
});

onMounted(async () => {
  await applicationStore.loadApplicationPrintHistory(applicationId.value);
});

async function openPdf(fileId?: string | null) {
  if (fileId) {
    if (fileId && printList.value) {
      const printElem = printList.value.find((el) => el.fileId === fileId);
      const fileData = await applicationStore.doDownloadPrint(fileId);

      let fileName = printElem?.printDescription
        ? `${printElem?.printDescription}.pdf`
        : "unnamed.txt";

      if (fileData?.header) {
        try {
          const parsed = parse(fileData?.header);
          if (
            parsed.type === "attachment" &&
            typeof parsed.parameters.filename === "string"
          ) {
            fileName = parsed.parameters.filename;
          }
        } catch (e) {
          console.warn(e);
        }
      }

      if (fileData) {
        const fileLink = document.createElement("a");
        fileLink.href = fileData.url ?? "unnamed.txt";
        fileLink.download = fileName;
        fileLink.click();
      }
    }
  }
}
</script>

<style scoped>
.utilities-text {
  font-size: 1em !important;
}
</style>

<template>
  <div class="container">
    <div class="w-100 d-flex mb-3 mt-4">
      <h4 class="fw-bold" :class="getColor('text', 'primary')">
        <BiIcon icon="list" size="lg" />
        {{ t(`${moduleId}.applicationDetails.printHistory.title`) }}
      </h4>
    </div>
    <BiTable
      :isRowHover="true"
      class="table-hover table-responsive"
      extraTableClasses="table-head-bg mb-0"
      @click.stop
    >
      <template v-slot:head>
        <tr class="bg-light" :class="getColor('text', 'secondary')">
          <th scope="col">
            {{ t(`${moduleId}.applicationDetails.printHistory.printName`) }}
          </th>
          <th scope="col">
            {{ t(`${moduleId}.applicationDetails.printHistory.executionDate`) }}
          </th>
          <th scope="col">
            {{
              t(`${moduleId}.applicationDetails.printHistory.applicationState`)
            }}
          </th>
          <th scope="col">
            {{ t(`${moduleId}.applicationDetails.printHistory.user`) }}
          </th>
          <th scope="col"></th>
        </tr>
      </template>
      <template v-slot:body>
        <tr v-for="(print, i) in printList ?? []" :key="i">
          <td
            :data-label="
              t(`${moduleId}.applicationDetails.printHistory.printName`)
            "
          >
            {{ print?.printDescription }}
          </td>
          <td
            :data-label="
              t(`${moduleId}.applicationDetails.printHistory.executionDate`)
            "
          >
            {{ getFormattedDate(print?.printDate.toLocaleString(), true) }}
          </td>
          <td
            class="text-uppercase"
            :data-label="
              t(`${moduleId}.applicationDetails.printHistory.applicationState`)
            "
          >
            {{ print?.processStatus }}
          </td>
          <td
            class="text-uppercase"
            :data-label="t(`${moduleId}.applicationDetails.printHistory.user`)"
          >
            {{ print?.username }}
          </td>
          <td class="actions">
            <div class="d-flex justify-content-center">
              <div>
                <BiButton
                  v-if="print.printStatus === 'READY'"
                  @click="openPdf(print.fileId)"
                  color="secondary"
                  :width="35"
                  :height="24"
                  class="w-100 text-nowrap pt-1"
                >
                  {{ t(`${moduleId}.applicationDetails.printHistory.openPdf`) }}
                </BiButton>
                <BiIcon
                  v-else
                  :icon="'circle-xmark'"
                  :icon-style="'light'"
                  :class="getColor('text', 'danger')"
                  size="2x"
                >
                </BiIcon>
              </div>
            </div>
          </td>
        </tr>
      </template>
    </BiTable>
  </div>
</template>
