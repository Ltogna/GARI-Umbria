<script setup lang="ts">
import {
  MessageType,
  type ApplicationHistoryElementModel,
} from "@/models/application";
import { getFormattedDate } from "@/utils/dateUtils";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiCollapse from "@abaco/bootstrap-italia-components/src/components/BiCollapse/BiCollapse.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { defineProps, inject, ref, computed } from "vue";
import { useI18n } from "vue-i18n";

const props = defineProps<{
  movement: ApplicationHistoryElementModel;
}>();

const messages = computed(() => {
  return [...props.movement.messages].sort(
    (a, b) => a.errorLevel - b.errorLevel,
  );
});

const moduleId = inject("moduleId");
const { getColor } = useColors();
const { t } = useI18n({});
const isOpen = ref<boolean>(false);

function toggleRow() {
  isOpen.value = !isOpen.value;
}
</script>
<template>
  <tr>
    <td
      class="text-uppercase"
      :data-label="
        t(`${moduleId}.applicationDetails.movementHistory.movementName`)
      "
    >
      {{ movement.description }}
    </td>
    <td
      class="text-uppercase"
      :data-label="
        t(`${moduleId}.applicationDetails.movementHistory.arrivalStatus`)
      "
    >
      {{ movement.failed ? "" : movement.toNodeDescription }}
    </td>
    <td
      :data-label="
        t(`${moduleId}.applicationDetails.movementHistory.executionDate`)
      "
    >
      {{ getFormattedDate(movement.startDate, true, true) }}
    </td>
    <td
      class="text-uppercase"
      :data-label="t(`${moduleId}.applicationDetails.movementHistory.user`)"
    >
      {{ movement.userId }}
    </td>
    <td
      class="text-uppercase fw-bold"
      :class="
        movement.failed
          ? getColor('text', 'danger')
          : getColor('text', 'success')
      "
      :data-label="
        t(`${moduleId}.applicationDetails.movementHistory.movementOutcome`)
      "
    >
      {{
        movement.failed
          ? t(`${moduleId}.applicationDetails.movementHistory.fail`)
          : t(`${moduleId}.applicationDetails.movementHistory.success`)
      }}
    </td>

    <td>
      <BiCollapse
        v-if="messages.length > 0 || (movement.notes && movement.notes !== '')"
        color="secondary"
        :tag="BiIcon"
        class="cursor-pointer animated-icon fa-chevron-down"
        :class="{ open: isOpen }"
        :targetSelector="`#collapseDetail-${movement.id}`"
        @click="toggleRow"
      >
      </BiCollapse>
    </td>
  </tr>
  <tr
    v-if="messages.length > 0 || (movement.notes && movement.notes !== '')"
    class="p-0 collapse-tr"
    :class="{ 'border-0': !isOpen }"
  >
    <td
      colspan="12"
      class="p-0 border-0"
      :class="
        !movement.notes || movement.notes == '' ? 'content-center-box' : ''
      "
    >
      <div
        :id="`collapseDetail-${movement.id}`"
        :class="!movement.notes || movement.notes == '' ? 'w-100' : ''"
      >
        <div class="w-90 ms-auto me-auto mt-3 mb-3">
          <div
            v-if="movement.notes && movement.notes !== ''"
            class="pe-3 pt-2 pb-2"
          >
            <span
              >{{
                t(`${moduleId}.applicationDetails.movementHistory.note`)
              }}:</span
            >
            <div
              class="w-100"
              :id="`note-${movement.id}`"
              :aria-describedby="`note-${movement.id}.`"
            >
              {{ movement.notes }}
            </div>
          </div>
          <div
            v-for="(message, index) in messages"
            :key="index"
            class="ps-3 pe-3 pt-3 pb-3 w-100 ms-auto me-auto"
            :class="index != 0 ? 'border-top ' : ''"
          >
            <BiAlert
              class="w-100"
              :isWarn="message.type == MessageType.WARNING"
              :isError="message.type == MessageType.ERROR"
              :isInfo="message.type == MessageType.INFO"
              ><template #body>
                <div class="slot-whitespace">
                  {{ message.description }}
                </div>
              </template>
            </BiAlert>
          </div>
        </div>
      </div>
    </td>
  </tr>
</template>
<style scoped>
.cursor-pointer {
  cursor: pointer;
}
.w-90 {
  width: 90% !important;
}
.content-center-box {
  justify-content: center;
}

.fa-chevron-down {
  transition: transform 0.3s;
  transform: scale();
}

.fa-chevron-down.open {
  transform: scale(-1);
  transition: transform 0.3s;
}

.slot-whitespace {
  white-space: break-spaces !important;
}
</style>
