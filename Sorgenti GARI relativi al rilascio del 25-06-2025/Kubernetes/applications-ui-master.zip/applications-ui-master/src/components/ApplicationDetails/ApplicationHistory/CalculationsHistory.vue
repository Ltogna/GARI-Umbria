<script setup lang="ts">
import { computed, inject, onMounted, ref, defineEmits } from "vue";
import { useI18n } from "vue-i18n";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { useApplicationStore } from "@/stores/applicationStore";
import { useRoute } from "vue-router";
import { handleErrorCode } from "@/models/utils";
import { getFormattedDate } from "@/utils/dateUtils";

const moduleId = inject("moduleId");
const { t } = useI18n({});
const { getColor } = useColors();
const route = useRoute();

const emit = defineEmits<{
  viewResults: [string];
}>();

const applicationStore = useApplicationStore();
const applicationId = ref<number>(
  parseInt(route.params.applicationId as string),
);
const calculationsList = computed(() => {
  const calculationsHistory = applicationStore.getCalculationsHistory;
  if (calculationsHistory) {
    calculationsHistory.sort((a, b) => {
      return new Date(a.calculationDate).getTime() >
        new Date(b.calculationDate).getTime()
        ? -1
        : 1;
    });
  }
  return calculationsHistory;
});

onMounted(async () => {
  await applicationStore.loadApplicationCalculationsHistory(
    applicationId.value,
  );
});

async function showResults(calculationJobUuid: string | null) {
  if (calculationJobUuid) {
    await applicationStore.loadCalculationDetails(calculationJobUuid);
    if (applicationStore.getCalculationDetails)
      emit("viewResults", calculationJobUuid);
    else handleErrorCode("OBJECT_NOT_FOUND_ERROR");
  }
}
</script>

<style scoped>
.utilities-text {
  font-size: 1em !important;
}
</style>

<template>
  <div class="container">
    <div class="w-100 d-flex mb-3 mt-4">
      <h4 class="fw-bold" :class="getColor('text', 'primary')">
        <BiIcon icon="list" size="lg" />
        {{ t(`${moduleId}.applicationDetails.calculationsHistory.title`) }}
      </h4>
    </div>
    <BiTable
      :isRowHover="true"
      class="table-hover table-responsive"
      extraTableClasses="table-head-bg mb-0"
      @click.stop
    >
      <template v-slot:head>
        <tr class="bg-light" :class="getColor('text', 'secondary')">
          <th scope="col">
            {{ t(`${moduleId}.applicationDetails.calculationsHistory.name`) }}
          </th>
          <th scope="col">
            {{
              t(
                `${moduleId}.applicationDetails.calculationsHistory.executionDate`,
              )
            }}
          </th>
          <th scope="col">
            {{
              t(
                `${moduleId}.applicationDetails.calculationsHistory.applicationState`,
              )
            }}
          </th>
          <th scope="col">
            {{ t(`${moduleId}.applicationDetails.calculationsHistory.user`) }}
          </th>
          <th scope="col">
            {{ t(`${moduleId}.applicationDetails.calculationsHistory.notes`) }}
          </th>
          <th scope="col"></th>
        </tr>
      </template>
      <template v-slot:body>
        <tr v-for="(calculation, i) in calculationsList ?? []" :key="i">
          <td
            :data-label="
              t(`${moduleId}.applicationDetails.calculationsHistory.name`)
            "
          >
            {{ calculation?.calculationDescription }}
          </td>
          <td
            :data-label="
              t(
                `${moduleId}.applicationDetails.calculationsHistory.executionDate`,
              )
            "
          >
            {{
              getFormattedDate(
                calculation?.calculationDate.toLocaleString(),
                true,
              )
            }}
          </td>
          <td
            class="text-uppercase"
            :data-label="
              t(
                `${moduleId}.applicationDetails.calculationsHistory.applicationState`,
              )
            "
          >
            {{ calculation?.processDescription || calculation?.processStatus }}
          </td>
          <td
            class="text-uppercase"
            :data-label="
              t(`${moduleId}.applicationDetails.calculationsHistory.user`)
            "
          >
            {{ calculation?.username }}
          </td>
          <td
            class="text-uppercase"
            :data-label="
              t(`${moduleId}.applicationDetails.calculationsHistory.notes`)
            "
          >
            {{ calculation?.notes }}
          </td>
          <td class="actions">
            <div class="d-flex justify-content-center">
              <div>
                <BiButton
                  v-if="
                    calculation.calculationStatus === 'READY' &&
                    calculation.calculationJobUuid
                  "
                  @click="showResults(calculation.calculationJobUuid)"
                  color="secondary"
                  :width="35"
                  :height="24"
                  class="w-100 text-nowrap pt-1"
                >
                  {{
                    t(
                      `${moduleId}.applicationDetails.calculationsHistory.showResults`,
                    )
                  }}
                </BiButton>
                <BiIcon
                  v-else
                  :icon="'circle-xmark'"
                  :icon-style="'light'"
                  :class="getColor('text', 'danger')"
                  size="2x"
                >
                </BiIcon>
              </div>
            </div>
          </td>
        </tr>
      </template>
    </BiTable>
  </div>
</template>
