<script setup lang="ts">
import { inject, computed, defineProps } from "vue";
import { useI18n } from "vue-i18n";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { useApplicationStore } from "@/stores/applicationStore";

const moduleId = inject("moduleId");

const applicationStore = useApplicationStore();
const { getColor } = useColors();
const { t } = useI18n({});
const cuaa = computed(() => {
  return applicationStore.getSelectedSubject?.code ?? "";
});
const companyName = computed(() => {
  return applicationStore.getSelectedSubject?.description ?? "";
});

defineProps<{
  applicationProcessStatus: string;
}>();
</script>
<style scoped>
@media (min-width: 500px) {
  .status-nowrap {
    white-space: nowrap !important;
  }
}
</style>

<template>
  <div
    class="w-100 d-flex col-12 justify-content-between p-2 application-module__group-detail-header"
    :class="getColor('text', 'white')"
  >
    <div class="text-left px-2">
      {{
        t(`${moduleId}.cardContainer.header`, {
          cuaa: cuaa,
          companyName: companyName,
        })
      }}
    </div>
    <div class="justify-content-end pe-sm-2 status-nowrap">
      {{ t(`${moduleId}.cardContainer.state`) }}:
      {{ applicationProcessStatus }}
    </div>
  </div>
</template>
