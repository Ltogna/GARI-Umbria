<script setup lang="ts">
import { inject, computed, defineProps } from "vue";
import { useI18n } from "vue-i18n";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import RegistryApplicationInfo from "./RegistryApplicationInfo.vue";
import type { ApplicationDetailsModel } from "@/models/application";
import { useApplicationStore } from "@/stores/applicationStore";
import { getFormattedDate } from "@/utils/dateUtils";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { useRouter } from "vue-router";

/* enum AnomalySeverity {
  BLOCKING = "BLOCKING",
  NOT_BLOCKING = "NOT_BLOCKING",
  INFO = "INFO",
}

interface Anomaly {
  code: string;
  message: string;
  isBlocking: AnomalySeverity;
}

interface AnomaliesByCategory {
  category: string;
  anomalies: Anomaly[];
}

interface Application {
  id: number;
  year: number;
  name: string;
  sector: string;
  module: string;
  creationDate: Date;
  submissionDate: Date;
  lastMovement: string;
  anomalies: AnomaliesByCategory[];
} */

const router = useRouter();
const moduleId = inject("moduleId");
const { getColor } = useColors();
const applicationStore = useApplicationStore();
const cuaa = computed(() => {
  return applicationStore.getSelectedSubject?.code ?? "";
});
const companyName = computed(() => {
  return applicationStore.getSelectedSubject?.description ?? "";
});
const { t } = useI18n({});
defineProps<{
  application: ApplicationDetailsModel;
}>();

function goToAmendment(id?: number | null) {
  if (id) {
    router.push({
      name: "applicationDetail",
      params: { applicationId: id },
    });
  }
}
</script>

<style scoped>
.sub-title-dim {
  font-size: 1.111em;
}

.cursor-pointer {
  cursor: pointer;
}
</style>
<template>
  <div class="container">
    <div class="mb-2 mt-4">
      <h4 class="fw-bold" :class="getColor('text', 'primary')">
        <BiIcon icon="file-lines" size="lg" />
        {{ t(`${moduleId}.genericDetail.applicationForm`) }}
      </h4>
    </div>
    <RegistryApplicationInfo
      :cuaa="cuaa"
      :name="companyName ? companyName : ''"
      :sector="application.sectorDescription"
      :module="application.moduleDescription"
      :year="application.moduleYear"
    />
    <!-- Detail information -->
    <div class="mb-2 mt-5">
      <h4 class="fw-bold" :class="getColor('text', 'primary')">
        <BiIcon icon="file-lines" size="lg" />
        {{ t(`${moduleId}.genericDetail.detailedInformation`) }}
      </h4>
    </div>
    <div>
      <strong class="text-secondary me-1"
        >{{ t(`${moduleId}.genericDetail.creationDate`) }}:</strong
      >
      <span class="text-secondary">{{
        application.dtInsert ? getFormattedDate(application.dtInsert, true) : ""
      }}</span>
    </div>
    <div>
      <strong class="text-secondary me-1"
        >{{ t(`${moduleId}.genericDetail.submissionDate`) }}:</strong
      >
      <span class="text-secondary">{{
        application.dtPresentation
          ? getFormattedDate(application.dtPresentation, true)
          : ""
      }}</span>
    </div>
    <div>
      <strong class="text-secondary me-1"
        >{{ t(`${moduleId}.genericDetail.lastMovement`) }}:</strong
      >
      <span class="text-secondary">
        {{ application.lastMovement }}
      </span>
    </div>
    <div v-if="application.dtProtocolRequest">
      <strong class="text-secondary me-1"
        >{{ t(`${moduleId}.genericDetail.protocolRequestDate`) }}:</strong
      >
      <span class="text-secondary">
        {{ getFormattedDate(application.dtProtocolRequest, true) }}
      </span>
    </div>
    <div v-if="application.dtProtocolResponse">
      <strong class="text-secondary me-1"
        >{{ t(`${moduleId}.genericDetail.protocolDate`) }}:</strong
      >
      <span class="text-secondary">
        {{ getFormattedDate(application.dtProtocolResponse) }}
      </span>
    </div>
    <div v-if="application.protocolCode">
      <strong class="text-secondary me-1"
        >{{ t(`${moduleId}.genericDetail.protocolCode`) }}:</strong
      >
      <span class="text-secondary">
        {{ application.protocolCode }}
      </span>
    </div>
    <div v-if="application.amendmentApplicationId">
      <strong class="text-secondary me-1"
        >{{ t(`${moduleId}.genericDetail.idRequestAmendment`) }}:</strong
      >
      <span class="text-secondary">
        <a
          class="underline cursor-pointer"
          @click.stop="goToAmendment(application.amendmentApplicationId)"
          >{{ application.amendmentApplicationId }}
          {{ t(`${moduleId}.genericDetail.goToApplication`) }}</a
        >
      </span>
    </div>
    <div v-if="application.amendedApplicationId">
      <strong class="text-secondary me-1"
        >{{ t(`${moduleId}.genericDetail.adjustedApplicationId`) }}:</strong
      >
      <span class="text-secondary">
        <a
          class="underline cursor-pointer"
          @click.stop="goToAmendment(application.amendedApplicationId)"
          >{{ application.amendedApplicationId }}
          {{ t(`${moduleId}.genericDetail.goToApplication`) }}</a
        >
      </span>
    </div>
  </div>
</template>
