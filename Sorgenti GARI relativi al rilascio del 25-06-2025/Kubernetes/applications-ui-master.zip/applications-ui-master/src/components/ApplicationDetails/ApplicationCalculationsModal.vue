<!-- eslint-disable @typescript-eslint/no-explicit-any -->
<script setup lang="ts">
import {
  computed,
  inject,
  onMounted,
  ref,
  watch,
  defineProps,
  defineEmits,
} from "vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { useI18n } from "vue-i18n";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import { getFormattedDate } from "@/utils/dateUtils";
import type {
  ApplicationDetailsCalculationsModel,
  GeneratedCalculationListModel,
  GeneratedCalculationModel,
} from "@/models/application";
import { useApplicationStore } from "@/stores/applicationStore";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { handleErrorCode } from "@/models/utils";

const CALCULATION_ERROR_CODE = "ERROR";

export type CalculationModelWithOngoingCalculation = {
  ongoingCalculation?: GeneratedCalculationModel;
  hasError?: boolean;
  calculationJobUuid: string;
  calculationCode: string;
  calculationDate: string | number;
  calculationDescription: string;
  sortOrder: number;
  params: Record<string, string>;
  isGenerating: boolean;
};

const props = defineProps<{
  applicationId: number;
}>();
const emit = defineEmits<{
  viewResults: [string];
}>();

const { getColor } = useColors();
const { t } = useI18n({});
const moduleId = inject("moduleId");
const applicationStore = useApplicationStore();
const calculations = ref<
  Record<string, CalculationModelWithOngoingCalculation>
>({});
const isMounting = ref<boolean>(true);
const onGoingCalculations = ref<
  GeneratedCalculationListModel | null | undefined
>(undefined);
const loadingOnGoingCalculations = computed(
  () => applicationStore.getLoadingOnGoingCalculations,
);
const applicationDetailsCalculations = computed(
  () => applicationStore.getApplicationDetails.calculations || [],
);

watch(onGoingCalculations, async (current, prev) => {
  if (prev !== undefined && JSON.stringify(current) !== JSON.stringify(prev))
    await applicationStore.loadApplicationDetails(props.applicationId);
  recalculateOngoingCalculationsData();
  if ((onGoingCalculations.value || []).length === 0) {
    applicationStore.setLoadingOngoingCalculations(false);
  } else {
    setTimeout(async () => {
      applicationStore.setLoadingOngoingCalculations(false);
      checkOngoingCalculationsCallback();
    }, 5000);
  }
});

onMounted(async () => {
  await applicationStore.loadApplicationCalculationsHistory(
    props.applicationId,
  );
  let alreadyLoadedCalculations = false;
  if (!loadingOnGoingCalculations.value) {
    await applicationStore.loadOngoingCalculations();
    alreadyLoadedCalculations = true;
    await applicationStore.loadApplicationDetails(props.applicationId);
  }
  const calculationsHistory = applicationStore.getCalculationsHistory;
  onGoingCalculations.value = applicationStore.getOngoingCalculations;
  const appDetailsCalculations = applicationDetailsCalculations.value;
  appDetailsCalculations.sort((a, b) => {
    return a.sortOrder < b.sortOrder ? 1 : -1;
  });
  calculations.value = appDetailsCalculations.reduce(
    (
      acc: Record<string, CalculationModelWithOngoingCalculation>,
      currentValue: ApplicationDetailsCalculationsModel,
    ) => {
      const ongoingCalculations = onGoingCalculations.value?.find((el) => {
        // eslint-disable-next-line @typescript-eslint/no-unused-expressions
        el.calculationCode === currentValue.calculationCode;
      });
      let calculationDate: string | number = "";
      let hasError = false;
      if (calculationsHistory) {
        const oldPrint = calculationsHistory.find(
          (print) => print.calculationCode === currentValue.calculationCode,
        );
        if (oldPrint) {
          if (!currentValue.lastCalculation)
            calculationDate = oldPrint.calculationDate;
          hasError = oldPrint.calculationStatus === CALCULATION_ERROR_CODE;
        }
      }
      const a = acc;
      a[currentValue.calculationCode] = {
        ongoingCalculation: ongoingCalculations,
        hasError: hasError,
        calculationJobUuid:
          currentValue.lastCalculation?.calculationJobUuid || "",
        calculationCode: currentValue.calculationCode,
        calculationDate:
          currentValue.lastCalculation?.calculationDate ?? calculationDate,
        calculationDescription: currentValue.calculationDescription,
        sortOrder: currentValue.sortOrder,
        params: currentValue.params,
        isGenerating: !!ongoingCalculations,
      };
      return a;
    },
    {},
  );
  isMounting.value = false;
  if (
    (onGoingCalculations.value?.length || 0 > 0) &&
    !alreadyLoadedCalculations
  )
    await checkOngoingCalculationsCallback();
});

async function showResults(calculationJobUuid: string) {
  if (calculationJobUuid) {
    await applicationStore.loadCalculationDetails(calculationJobUuid);
    if (applicationStore.getCalculationDetails)
      emit("viewResults", calculationJobUuid);
    else handleErrorCode("OBJECT_NOT_FOUND_ERROR");
  }
}

const DUMMY = "dummy";

function dummyOngoindCalculationBuilder(
  calculationItem: CalculationModelWithOngoingCalculation,
) {
  return {
    calculationCode: calculationItem.calculationCode,
    calculationDate: new Date().getTime(),
    calculationsCode: DUMMY,
    processStatus: DUMMY,
    calculationJobUuid: null,
    username: DUMMY,
    calculationStatus: DUMMY,
    calculationDescription: DUMMY,
    processDescription: DUMMY,
    notes: null,
  };
}

function recalculateOngoingCalculationsData() {
  onGoingCalculations.value?.forEach((print) => {
    calculations.value[print.calculationCode].isGenerating = true;
  });
  Object.keys(calculations.value).forEach((key) => {
    if (
      calculations.value[key].isGenerating &&
      onGoingCalculations.value?.findIndex(
        (el) => el.calculationCode === key,
      ) === -1
    ) {
      const detailsCalculation = applicationDetailsCalculations.value.find(
        (calculation) => calculation.calculationCode === key,
      );
      calculations.value[key].calculationJobUuid =
        detailsCalculation?.lastCalculation?.calculationJobUuid || "";
      calculations.value[key].calculationDate =
        detailsCalculation?.lastCalculation?.calculationDate || "";
      calculations.value[key].isGenerating = false;
      calculations.value[key].hasError =
        detailsCalculation?.lastCalculation?.calculationStatus !== "READY";
    }
  });
}

async function checkOngoingCalculationsCallback() {
  if (!loadingOnGoingCalculations.value) {
    applicationStore.setLoadingOngoingCalculations(true);
    await applicationStore.loadOngoingCalculations();
    onGoingCalculations.value = applicationStore.getOngoingCalculations;
  }
}

async function startCalculationJob(
  calculationItem: CalculationModelWithOngoingCalculation,
) {
  calculationItem.ongoingCalculation =
    dummyOngoindCalculationBuilder(calculationItem);
  try {
    calculationItem.isGenerating = true;
    calculationItem.ongoingCalculation =
      await applicationStore.startCalculation(calculationItem.calculationCode);
    calculationItem.hasError = false;
    await checkOngoingCalculationsCallback();
  } catch (err) {
    console.error(err);
    delete calculationItem.ongoingCalculation;
    calculationItem.isGenerating = false;
    calculationItem.hasError = true;
  }
}
</script>

<style scoped>
.subtext-size {
  font-size: 12px;
}
.cursor-pointer {
  cursor: pointer;
}
</style>

<template>
  <div>
    <div v-if="isMounting" class="d-flex justify-content-center">
      <BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
    </div>
    <BiTable v-else extraHeaderClasses="d-none border-0" :isRowHover="true">
      <template v-slot:head>
        <tr class="" :class="getColor('text', 'secondary')">
          <th scope="col"></th>
          <th scope="col"></th>
        </tr>
      </template>
      <template #body>
        <tr v-for="(calculationItem, key, index) in calculations" :key="index">
          <td scope="row">
            <div>
              <div class="text-end text-lg-start">
                {{ calculationItem.calculationDescription }}
              </div>
              <div
                v-if="
                  calculationItem.calculationDate || calculationItem.hasError
                "
              >
                <div class="subtext-size mt-4">
                  <div v-if="!calculationItem.hasError">
                    {{
                      t(
                        `${moduleId}.applicationDetails.calculationsModal.lastExecution`,
                        {
                          date: getFormattedDate(
                            calculationItem.calculationDate.toLocaleString(),
                            true,
                          ),
                        },
                      )
                    }}
                  </div>
                  <div v-else>
                    <span
                      >{{
                        t(
                          `${moduleId}.applicationDetails.calculationsModal.lastExecutionInError`,
                        ) + " "
                      }}
                    </span>
                    <BiIcon
                      :icon="'circle-xmark'"
                      :icon-style="'light'"
                      :class="getColor('text', 'danger')"
                      size="1x"
                    >
                    </BiIcon>
                  </div>
                </div>
              </div>
            </div>
          </td>
          <td style="vertical-align: top">
            <div class="d-flex flex-row-reverse">
              <div class="d-flex flex-column">
                <BiButton
                  v-if="!calculationItem.isGenerating"
                  @click="startCalculationJob(calculationItem)"
                  :class="getColor('button', 'secondary')"
                  class="me-2"
                >
                  {{
                    t(
                      `${moduleId}.applicationDetails.calculationsModal.calculate`,
                    )
                  }}
                </BiButton>
                <BiProgressIndicator
                  v-else
                  style="padding-right: 2rem"
                  :type="'spinner'"
                ></BiProgressIndicator>
                <BiButton
                  v-if="
                    !isMounting &&
                    !calculationItem.isGenerating &&
                    !calculationItem.hasError &&
                    calculationItem.calculationJobUuid
                  "
                  @click="showResults(calculationItem.calculationJobUuid)"
                  :class="getColor('button', 'secondary', 'outline')"
                  class="me-2 mt-2"
                >
                  {{
                    t(
                      `${moduleId}.applicationDetails.calculationsModal.showResults`,
                    )
                  }}
                </BiButton>
              </div>
            </div>
          </td>
        </tr>
      </template>
    </BiTable>
  </div>
</template>
