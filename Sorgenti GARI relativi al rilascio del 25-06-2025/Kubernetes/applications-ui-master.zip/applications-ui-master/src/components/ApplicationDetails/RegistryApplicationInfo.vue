<script setup lang="ts">
import { inject, defineProps } from "vue";
import { useI18n } from "vue-i18n";

const moduleId = inject("moduleId");
const { t } = useI18n({});

defineProps<{
  cuaa?: string | null;
  name?: string | null;
  sector?: string | null;
  module?: string | null;
  year?: number | null;
}>();
</script>

<template>
  <div>
    <strong class="text-secondary me-1"
      >{{ t(`${moduleId}.genericDetail.cuaa`) }}:</strong
    >
    <span class="text-secondary">{{ cuaa }}</span>
  </div>
  <div>
    <strong class="text-secondary me-1"
      >{{ t(`${moduleId}.genericDetail.name`) }}:</strong
    >
    <span class="text-secondary">{{ name }}</span>
  </div>
  <div>
    <strong class="text-secondary me-1"
      >{{ t(`${moduleId}.genericDetail.sector`) }}:</strong
    >
    <span class="text-secondary">{{ sector }}</span>
  </div>
  <div>
    <strong class="text-secondary me-1"
      >{{ t(`${moduleId}.genericDetail.module`) }}:</strong
    >
    <span class="text-secondary">{{ module }}</span>
  </div>
  <div v-if="year">
    <strong class="text-secondary me-1"
      >{{ t(`${moduleId}.genericDetail.year`) }}:</strong
    >
    <span class="text-secondary">{{ year }}</span>
  </div>
</template>
