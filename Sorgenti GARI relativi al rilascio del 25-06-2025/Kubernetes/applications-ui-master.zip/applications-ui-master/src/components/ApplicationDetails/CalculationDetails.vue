<script setup lang="ts">
import { useApplicationStore } from "@/stores/applicationStore";
import { computed, onMounted, defineProps } from "vue";
import CalculatorEngine from "@abaco/calculator-engine/src/components/CalculatorEngine.vue";

const props = defineProps<{
  calculationJobUuid: string;
}>();

const applicationStore = useApplicationStore();

const calculationDetails = computed(
  () => applicationStore.getCalculationDetails,
);

onMounted(() => {
  if (!calculationDetails.value)
    applicationStore.loadCalculationDetails(props.calculationJobUuid);
});
</script>
<template>
  <div class="container pt-4">
    <CalculatorEngine
      v-if="calculationDetails"
      :data="calculationDetails.result"
    ></CalculatorEngine>
  </div>
</template>
