<script setup lang="ts">
// Vue
import { inject, onMounted, ref, watch, defineProps, defineEmits } from "vue";
import { useI18n } from "vue-i18n";
// Boootstrap Italia components
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiTextarea from "@abaco/bootstrap-italia-components/src/components/form/BiTextarea.vue";
import BiRadiobutton from "@abaco/bootstrap-italia-components/src/components/form/BiRadiobutton.vue";
import { useApplicationStore } from "@/stores/applicationStore";
import { checkMaxLength, verifyField } from "@/utils/formUtils";
import type { ValidatedInput } from "@/models/form";

// State manager
import ApplicationServiceModal from "../ApplicationServiceModal.vue";
import type {
  ApplicationDetailsModel,
  ApplicationTransitionModel,
  ApplicationTransitionsModel,
} from "@/models/application";

const applicationStore = useApplicationStore();
const ignoreLastTransitionLog = ref<boolean>(false);

const props = defineProps<{
  openModal: boolean;
  transitionList: ApplicationTransitionsModel;
  applicationId?: number;
  application?: ApplicationDetailsModel;
}>();

const emit = defineEmits(["closeModal", "hiddenProgressStatusDone"]);

const { getColor } = useColors();
const { t } = useI18n({});
const moduleId = inject("moduleId");

enum Steps {
  first,
  second,
  third,
}
const mutex = ref<Steps>(Steps.first);

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const changeStatus = ref<any>({
  status: null,
  newStatusName: null,
  notes: null,
  transitionId: null,
  notesRequired: false,
  description: null,
});

const searchFormValidators = ref<Record<string, ValidatedInput<string>>>({
  notes: {
    val: changeStatus.value.notes,
    errors: [],
  },
});

function emitCloseModal(reload = false) {
  changeStatus.value.notes = null;
  searchFormValidators.value.notes.errors = [];
  emit("closeModal", reload);
}

function updateRadioModelValueForStatus(newValue: string) {
  changeStatus.value.status = newValue;
  const transition = props.transitionList.find(
    (x: ApplicationTransitionModel) => x.id.toString() === newValue,
  );
  changeStatus.value.newStatusName = transition?.toNode;
  changeStatus.value.notesRequired = transition?.notesRequired;
  changeStatus.value.transitionId = transition?.id;
  changeStatus.value.description = transition?.description;
}

const modalViewStatus = ref<boolean>(false);
const modalViewProgressStatus = ref<boolean>(false);

onMounted(async () => {
  if (props.applicationId) {
    await applicationStore.loadIsInTransition(props.applicationId);
    if (!applicationStore.getIsInTransition) modalViewStatus.value = true;
    else modalViewProgressStatus.value = true;
  }
});

const statusHasChanged = ref<boolean>(false);
const statusHasError = ref<boolean>(false);
async function editStatus() {
  searchFormValidators.value.notes.val = changeStatus.value.notes;

  const maxLengthErrorMessage = t(`${moduleId}.general.maxLength`);
  const errors: boolean[] = [];
  errors.push(
    verifyField(
      [
        () =>
          checkMaxLength(
            searchFormValidators.value.notes,
            4000,
            maxLengthErrorMessage,
          ),
      ],
      searchFormValidators.value.notes,
    ),
  );

  if (errors.findIndex((x: boolean) => x) !== -1) return;

  statusHasError.value = false;
  statusHasChanged.value = false;
  if (
    changeStatus.value.status &&
    changeStatus.value.newStatusName &&
    changeStatus.value.transitionId &&
    props.applicationId
  ) {
    mutex.value = Steps.third;
    modalViewStatus.value = false;
    modalViewProgressStatus.value = true;
    ignoreLastTransitionLog.value = false;
    try {
      applicationStore.setTransitionStatus(changeStatus.value.description);
      await applicationStore.changeStatus(
        props.applicationId,
        changeStatus.value.transitionId,
        changeStatus.value.notes,
      );
    } catch (err) {
      console.error("progress status error", err);
      statusHasError.value = true;
      ignoreLastTransitionLog.value = true;
    }
    statusHasChanged.value = true;
  }
}

// watch(modalViewStatus, () => {
//   if (
//     modalViewStatus.value === false &&
//     modalViewProgressStatus.value === false
//   ) {
//     emitCloseModal();
//   }
// });

function closeComponent(reloadData = false) {
  mutex.value = Steps.second;
  modalViewStatus.value = false;
  modalViewProgressStatus.value = false;
  handleCLoseFirstModal(reloadData);
}

function closeFirstModal() {
  mutex.value = Steps.first;
  modalViewStatus.value = false;
}

function handleCLoseFirstModal(reloadData = false) {
  if (mutex.value === Steps.second) {
    emitCloseModal(reloadData);
  }
  if (mutex.value === Steps.first) {
    closeComponent();
  }
}

watch(
  () => props.openModal,
  () => {
    if (!applicationStore.getIsInTransition && props.openModal)
      modalViewStatus.value = true;
    else if (props.openModal) modalViewProgressStatus.value = true;
  },
);
</script>

<style scoped>
.aligned-in-column {
  display: flex;
  flex-direction: column;
  align-content: center;
  align-items: center;
  gap: 2rem;
}

.aligned-in-row {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}

.text-orange {
  color: orange;
}

.text-green {
  color: green;
}

.padding-top-3 {
  padding-top: 3rem;
}
</style>

<template>
  <BiModal
    :disabled-teleport="true"
    :model-value="modalViewStatus && openModal"
    ariaLabelledby="changeStatus"
    :title="t(`${moduleId}.serviceModal.statusChangeModal.title`)"
    :preventDismiss="true"
    :size="'lg'"
    @hidden-modal="handleCLoseFirstModal"
  >
    <template #body>
      <div class="container pt-2">
        <div class="row">
          <div class="col-6 col-xs-12 col-sm-12 col-md-12 col-lg-6">
            <div class="fw-bold pb-2">
              {{ t(`${moduleId}.serviceModal.movementList`) }}
            </div>
            <BiRadiobutton
              v-for="(transition, i) in props.transitionList"
              :key="i"
              :id="transition.toNode"
              :label="
                transition.description
                  ? transition.description
                  : transition.toNode
              "
              :value="transition.id.toString()"
              :modelValue="''"
              :name="'radioButtonsGroup'"
              @update:model-value="updateRadioModelValueForStatus"
            >
            </BiRadiobutton>
          </div>
          <div class="col-6 col-xs-12 col-sm-12 col-md-12 col-lg-6">
            <div class="fw-bold pb-2">
              {{ t(`${moduleId}.applicationDetails.statusModal.notes`) }}
            </div>
            <BiTextarea
              :rows="5"
              :placeholder="
                t(`${moduleId}.applicationDetails.statusModal.enterNotes`)
              "
              v-model="changeStatus.notes"
              :errors="searchFormValidators.notes.errors"
            />
          </div>
        </div>
      </div>
    </template>
    <template #footer>
      <div class="d-flex justify-content-center w-100 padding-top-3">
        <BiButton
          size="lg"
          class="mx-1"
          :class="getColor('button', 'success', 'outline')"
          @click="closeFirstModal"
        >
          {{ t(`${moduleId}.general.cancel`) }}
        </BiButton>
        <BiButton
          isPrimary
          class="mx-1"
          size="lg"
          :is-disabled="changeStatus.notesRequired && !changeStatus.notes"
          :class="getColor('button', 'success')"
          @click="editStatus()"
          >{{ t(`${moduleId}.general.proceed`) }}</BiButton
        >
      </div>
    </template>
  </BiModal>

  <ApplicationServiceModal
    :open-modal="modalViewProgressStatus && openModal"
    @close="closeComponent(true)"
    :party="applicationStore.getSelectedSubject"
    :module="{
      moduleShortDescription: application?.moduleDescription,
      sectorShortDescription: application?.sectorDescription,
      year: application?.referredYear,
    }"
    :is-create-application="false"
    :translation-module="'statusChangeModal'"
    :application-id="applicationId"
    :application="application"
    :ignoreLastTransitionLog="ignoreLastTransitionLog"
  ></ApplicationServiceModal>
</template>
