<script setup lang="ts">
import {
  type AmendmentModule,
  type ApplicationDetailsModel,
  type ApplicationModuleModel,
  type PartyModel,
} from "@/models/application";
import { useApplicationStore } from "@/stores/applicationStore";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { computed, defineEmits, defineProps, inject, ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import RegistryApplicationInfo from "./ApplicationDetails/RegistryApplicationInfo.vue";
import ApplicationServiceModalMesssage from "./ApplicationServiceModalMesssage.vue";

const moduleId = inject("moduleId");
const { getColor } = useColors();
const { t } = useI18n({});

const onLoading = ref<boolean>(false);
const applicationStore = useApplicationStore();

const props = defineProps<{
  openModal: boolean;
  party: PartyModel | null;
  module: Partial<ApplicationModuleModel> | AmendmentModule | null;
  isCreateApplication: boolean;
  translationModule: string;
  applicationId?: number | null;
  application?: ApplicationDetailsModel;
  ignoreLastTransitionLog?: boolean;
}>();

const internalValue = ref<boolean>(props.openModal);
const initialStatus = ref<string>("");

const transitionData = computed(() => applicationStore.getTransitionData);

const emit = defineEmits<{
  (e: "close", value?: boolean): void;
}>();

const goToDetail = ref<boolean>(false);

function closeModal() {
  emit("close", goToDetail.value);
}

watch(
  () => props.openModal,
  () => {
    internalValue.value = props.openModal;
    if (props.openModal) {
      if (props.application && props.application.processStatusDescription) {
        initialStatus.value = props.application.processStatusDescription;
      } else {
        initialStatus.value = "";
      }
      if (props.applicationId) {
        onLoading.value = true;
        loadTransitionData(2000, 2000);
      }
    }
  },
);

function loadTransitionData(previousTime: number, timeToWait: number) {
  setTimeout(async () => {
    if (props.applicationId) {
      await applicationStore.loadIsInTransition(props.applicationId);
      if (applicationStore.getIsInTransition === false) {
        onLoading.value = false;
      } else {
        loadTransitionData(timeToWait, timeToWait + previousTime);
      }
    }
  }, timeToWait);
}
</script>
<style scoped>
.w-fit {
  width: fit-content;
}

.slot-whitespace {
  white-space: break-spaces !important;
}
</style>
<template>
  <BiModal
    :modelValue="internalValue"
    :disabled-teleport="true"
    @hidden-modal="closeModal"
    :ariaLabelledby="`${t(
      `${moduleId}.serviceModal.${translationModule}.title`,
    )}`"
    :title="`${t(`${moduleId}.serviceModal.${translationModule}.title`)}`"
    :size="'lg'"
    :prevent-dismiss="true"
    :extra-footer-class="'justify-content-center'"
    ><template v-slot:body>
      <RegistryApplicationInfo
        :cuaa="party?.code"
        :name="party?.description"
        :sector="
          (module?.sectorShortDescription ??
            module?.sectorDescription) as string
        "
        :module="
          (module?.moduleShortDescription ??
            module?.moduleDescription) as string
        "
        :year="(module?.year ?? module?.annuality) as number"
      />

      <div class="grid mt-4">
        <div class="d-flex row">
          <div
            v-if="onLoading && !ignoreLastTransitionLog"
            class="d-flex justify-content-center mb-2"
          >
            <h4 :class="getColor('text', 'secondary')">
              <strong>
                {{
                  t(
                    `${moduleId}.serviceModal.${translationModule}.processInProgress`,
                  )
                }}
              </strong>
            </h4>
          </div>

          <div
            v-if="!onLoading || ignoreLastTransitionLog"
            class="d-flex justify-content-center mb-3"
          >
            <h4 :class="getColor('text', 'secondary')">
              <strong
                v-if="
                  !ignoreLastTransitionLog &&
                  !transitionData?.lastTransitionLog?.failed
                "
              >
                {{
                  t(
                    `${moduleId}.serviceModal.${translationModule}.processSuccess`,
                  )
                }}
              </strong>
              <strong
                v-if="
                  transitionData?.lastTransitionLog?.failed ||
                  applicationStore.hasError ||
                  ignoreLastTransitionLog
                "
              >
                {{
                  t(
                    `${moduleId}.serviceModal.${translationModule}.processFailed`,
                  )
                }}
              </strong>
            </h4>
          </div>
        </div>
        <div
          v-if="onLoading && !ignoreLastTransitionLog"
          class="d-flex row justify-content-center mb-3"
        >
          <div class="d-flex col-2 justify-content-center px-0">
            <BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
          </div>
        </div>

        <div
          v-if="!onLoading || ignoreLastTransitionLog"
          class="d-flex row justify-content-center mb-3"
        >
          <div class="d-flex col-2 justify-content-center px-0">
            <BiIcon
              :icon="
                !ignoreLastTransitionLog &&
                !transitionData?.lastTransitionLog?.failed
                  ? 'circle-check'
                  : 'circle-xmark'
              "
              :icon-style="'light'"
              :class="
                getColor(
                  'text',
                  !transitionData?.lastTransitionLog?.failed
                    ? 'success'
                    : 'danger',
                )
              "
              size="5x"
            ></BiIcon>
          </div>
        </div>
        <BiTable
          class="table-responsive w-100"
          extraTableClasses="table-head-bg"
          isResponsive
        >
          <template v-slot:head>
            <tr class="bg-light" :class="getColor('text', 'secondary')">
              <th scope="col">
                {{ t(`${moduleId}.serviceModal.currentState`) }}
              </th>
              <th v-if="onLoading" scope="col">
                {{ t(`${moduleId}.serviceModal.movements`) }}
              </th>
              <th v-else-if="!onLoading" scope="col">
                {{
                  !transitionData?.lastTransitionLog?.failed
                    ? t(`${moduleId}.serviceModal.movementComplete`)
                    : t(`${moduleId}.serviceModal.movementFailed`)
                }}
              </th>
            </tr>
          </template>
          <template v-slot:body>
            <tr>
              <td :data-label="t(`${moduleId}.serviceModal.currentState`)">
                {{
                  transitionData?.lastTransitionLog &&
                  !transitionData?.lastTransitionLog?.failed &&
                  !onLoading
                    ? transitionData?.lastTransitionLog.toNodeDescription?.toUpperCase()
                    : initialStatus.toUpperCase()
                }}
              </td>
              <td :data-label="t(`${moduleId}.serviceModal.movements`)">
                {{
                  applicationStore.getTransitionStatus
                    ? applicationStore.getTransitionStatus.toUpperCase()
                    : ""
                }}
              </td>
            </tr>
          </template>
        </BiTable>
        <BiAlert isError v-if="ignoreLastTransitionLog">
          <template #body>{{
            t(`${moduleId}.errors.errorChangeStatusAlert`)
          }}</template>
        </BiAlert>
        <div
          v-if="
            !ignoreLastTransitionLog &&
            !onLoading &&
            transitionData &&
            transitionData.lastTransitionLog &&
            transitionData.lastTransitionLog.messages &&
            transitionData.lastTransitionLog.messages.length > 0
          "
          class="row"
        >
          <ApplicationServiceModalMesssage
            :messages="transitionData.lastTransitionLog.messages"
          />
        </div>

        <div
          class="row"
          v-if="!onLoading && transitionData?.lastTransitionLog?.notes"
        >
          <strong class="text-secondary me-1"
            >{{
              t(`${moduleId}.applicationDetails.statusModal.notes`)
            }}:</strong
          >
          <span class="text-secondary">{{
            transitionData?.lastTransitionLog?.notes
              ? transitionData.lastTransitionLog.notes
              : ""
          }}</span>
        </div>
      </div>
    </template>
    <template v-slot:footer>
      <div class="mt-3 mb-5 d-flex justify-content-center w-100">
        <BiButton
          class="mx-2 w-fit"
          :class="getColor('button', 'secondary', 'outline')"
          @click.stop="
            goToDetail = false;
            internalValue = false;
          "
          size="lg"
          >{{ t(`${moduleId}.general.close`) }}</BiButton
        >
        <BiButton
          v-if="
            !onLoading &&
            !transitionData?.lastTransitionLog?.failed &&
            isCreateApplication
          "
          class="mx-2 w-fit"
          isPrimary
          :class="getColor('button', 'success', 'outline')"
          @click.stop="
            goToDetail = true;
            internalValue = false;
          "
          size="lg"
          >{{ t(`${moduleId}.serviceModal.goToApplication`) }}</BiButton
        >
      </div>
    </template>
  </BiModal>
</template>
