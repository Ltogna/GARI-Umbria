<script setup lang="ts">
import { inject, ref, computed } from "vue";
import { useI18n } from "vue-i18n";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";

import { useApplicationStore } from "@/stores/applicationStore";
import ApplicationServiceModal from "../ApplicationServiceModal.vue";
import { type ApplicationModuleModel } from "@/models/application";
import RegistryApplicationInfo from "../ApplicationDetails/RegistryApplicationInfo.vue";
import { useRouter } from "vue-router";

const moduleId = inject("moduleId");
const applicationStore = useApplicationStore();
const { getColor } = useColors();
const { t } = useI18n({});
const router = useRouter();
const isServiceModalVisible = ref(false);
const isCreationModalVisible = ref(false);
const selectedModule = ref<ApplicationModuleModel>(null);
const selectedSubject = computed(() => applicationStore.getSelectedSubject);
const createApplicationResponse = computed(
  () => applicationStore.getCreateApplicationResponse,
);

const applicationModules = computed(
  () => applicationStore.getApplicationModules,
);

async function loadMore() {
  if (!applicationModules.value?.nextKey) return;
  await applicationStore.loadApplicationModules(
    undefined,
    applicationModules.value?.nextKey,
  );
}

function onOpenCreationModal(module: ApplicationModuleModel) {
  selectedModule.value = module;
  isCreationModalVisible.value = true;
}

async function createApplication() {
  if (!selectedSubject.value || !selectedModule.value) return;

  const newApplication = {
    partyId: selectedSubject.value.partyId,
    year: selectedModule.value.year || 0,
    moduleCode: selectedModule.value.moduleCode,
    sectorCode: selectedModule.value.sectorCode,
  };
  applicationStore.setTransitionStatus(t(`${moduleId}.serviceModal.creation`));
  await applicationStore.createApplication(newApplication);

  isCreationModalVisible.value = false;
  isServiceModalVisible.value = true;
}

function onCloseServiceModal(redirect?: boolean) {
  isServiceModalVisible.value = false;
  if (redirect) {
    router.push({
      name: "applicationDetail",
      params: {
        applicationId: createApplicationResponse?.value?.applicationCode,
      },
    });
  }
}
</script>
<style scoped>
.w-fit {
  width: fit-content;
}
</style>
<template>
  <!--<div class="container my-5" v-if="canOperate">Create Application</div>-->
  <BiTable
    isRowHover
    class="table-hover mb-0 table-responsive"
    extraTableClasses="table-head-bg"
    isResponsive
  >
    <template v-slot:head>
      <tr class="bg-light" :class="getColor('text', 'secondary')">
        <th scope="col">
          {{ t(`${moduleId}.createApplication.year`) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.createApplication.sector`) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.createApplication.module`) }}
        </th>
        <th scope="col"></th>
      </tr>
    </template>
    <template v-slot:body>
      <tr v-for="(module, i) in applicationModules?.records" :key="i">
        <td :data-label="t(`${moduleId}.createApplication.year`)">
          {{ module?.year }}
        </td>
        <td :data-label="t(`${moduleId}.createApplication.sector`)">
          {{ module?.sectorShortDescription }}
        </td>
        <td :data-label="t(`${moduleId}.createApplication.module`)">
          {{ module?.moduleShortDescription }}
        </td>
        <td
          class="actions"
          :data-label="t(`${moduleId}.createApplication.createApplication`)"
        >
          <div class="d-flex justify-content-center">
            <BiButton
              @click.stop="onOpenCreationModal(module)"
              isPrimary
              :class="`${getColor('button', 'success')}`"
              class="me-2"
              :isIcon="true"
            >
              {{ t(`${moduleId}.createApplication.createApplication`) }}
            </BiButton>
          </div>
        </td>
      </tr>
    </template>
  </BiTable>
  <div class="w-100 text-center" @click.stop>
    <BiButton
      v-if="applicationModules?.nextKey"
      @click="loadMore()"
      :class="getColor('button', 'primary', 'outline')"
    >
      {{ t(`${moduleId}.list.loadMore`) }}
    </BiButton>
  </div>
  <BiModal
    :disabled-teleport="true"
    :extra-footer-class="'justify-content-center'"
    v-model="isCreationModalVisible"
    :aria-labelledby="t(`${moduleId}.searchForm.createApplication`)"
    :title="t(`${moduleId}.searchForm.createApplication`)"
    :prevent-dismiss="true"
    :size="'lg'"
  >
    <template #body>
      <p class="mb-3">
        <strong>
          {{ t(`${moduleId}.serviceModal.newApplicationInfo`) }}:
        </strong>
      </p>
      <RegistryApplicationInfo
        :cuaa="selectedSubject?.code"
        :name="selectedSubject?.description"
        :sector="selectedModule?.sectorShortDescription"
        :module="selectedModule?.moduleShortDescription"
        :year="selectedModule?.year"
      />
    </template>
    <template #footer>
      <div class="mt-3 mb-5 d-flex justify-content-center">
        <BiButton
          class="mx-2 w-fit"
          size="lg"
          :class="getColor('button', 'secondary', 'outline')"
          @click.stop="isCreationModalVisible = false"
        >
          {{ t(`${moduleId}.general.cancel`) }}
        </BiButton>
        <BiButton
          class="mx-2 w-fit"
          isPrimary
          size="lg"
          :class="getColor('button', 'success')"
          @click.stop="createApplication()"
          >{{ t(`${moduleId}.general.confirm`) }}</BiButton
        >
      </div>
    </template>
  </BiModal>
  <ApplicationServiceModal
    :open-modal="isServiceModalVisible"
    :party="selectedSubject"
    :module="selectedModule"
    :is-create-application="true"
    @close="onCloseServiceModal"
    :translation-module="'createApplicationModal'"
    :application-id="createApplicationResponse?.applicationId"
  ></ApplicationServiceModal>
</template>
