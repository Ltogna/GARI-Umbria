<template>
  <input
    type="file"
    :name="_id"
    :id="_id"
    class="upload"
    @change="onChangeFile"
    :multiple="false"
    color="danger"
    ref="upload"
    aria-label="file"
  />
  <label :for="_id" :class="extraClasses">
    <div class="row mx-0 px-0">
      <div class="col-auto ms-0 me-1 px-0">
        <BiIcon :icon="icon"></BiIcon>
      </div>
      <div class="col-auto mx-0 px-0">{{ label }}</div>
    </div>
  </label>
  <ul class="upload-file-list d-flex">
    <li v-if="!state && showFileName && fileObj" class="upload-file">
      <BiIcon icon="file" icon-style="regular"></BiIcon>
      <p class="me-2">
        <span class="visually-hidden">File caricato:</span>
        {{ fileObj?.name ?? "" }}
        <!-- <span class="upload-file-weight">
          {{
            `${fileObj && fileObj.size ? fileObj.size / 1024 / 1024 : "NaN"} MB`
          }}
        </span> -->
      </p>
      <span>
        <span class="visually-hidden">{{ t(`${moduleId}.general.file`) }}</span>
      </span>
    </li>
    <li
      v-if="state && state === 'success' && fileObj"
      class="upload-file success"
    >
      <BiIcon
        icon="file"
        icon-style="regular"
        :class="`${getColor('text', 'success')}`"
      ></BiIcon>
      <p class="me-2" :class="`${getColor('text', 'success')}`">
        <span class="visually-hidden">File caricato:</span>
        {{ fileObj?.name ?? "" }}
        <!-- <span class="upload-file-weight">
          {{
            `${fileObj && fileObj.size ? fileObj.size / 1024 / 1024 : "NaN"} MB`
          }}
        </span> -->
      </p>
      <span>
        <span class="visually-hidden">Caricamento ultimato</span>
        <BiIcon
          icon="check"
          icon-style="regular"
          :class="`${getColor('text', 'success')}`"
        ></BiIcon>
      </span>
    </li>
    <li v-if="state && state === 'error' && fileObj" class="upload-file error">
      <BiIcon
        icon="file"
        icon-style="regular"
        :class="`${getColor('text', 'danger')}`"
      />
      <p class="me-2" :class="`${getColor('text', 'danger')}`">
        <span class="visually-hidden">Errore caricamento file:</span>
        {{ fileObj?.name ?? "" }}
        <!-- <span class="upload-file-weight"></span> -->
      </p>
      <span>
        <span class="visually-hidden">Errore nel caricamento</span>
        <BiIcon
          icon="exclamation"
          icon-style="regular"
          :class="`${getColor('text', 'danger')}`"
        ></BiIcon>
      </span>
    </li>
  </ul>
</template>

<script setup lang="ts">
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { ref, defineProps, withDefaults, defineEmits, inject } from "vue";
import ID from "./ID";
import { useI18n } from "vue-i18n";

const moduleId = inject("moduleId");
const { getColor } = useColors();
const { t } = useI18n({});

const _id = ID.next();

const fileObj = ref<File>();

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const props = withDefaults(
  defineProps<{
    label?: string;
    icon?: string;
    extraClasses?: string;
    showFileName?: boolean;
    state?: "success" | "error";
  }>(),
  {
    label: "Upload",
    icon: "upload",
    extraClasses: "",
  },
);

const emit = defineEmits(["fileChanged"]);

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function onChangeFile(event: any) {
  if (event && event.target && event.target.files) {
    fileObj.value = event.target.files[0];
    emit("fileChanged", fileObj.value);
  }
}
</script>

<style lang="scss" scoped></style>
