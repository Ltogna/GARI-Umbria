<script setup lang="ts">
// Vue
import { inject, ref } from "vue";
import { useI18n } from "vue-i18n";
//Boootstrap Italia components
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import BiAccordion from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordion.vue";
import BiAccordionGroup from "@abaco/bootstrap-italia-components/src/components/BiAccordion/BiAccordionGroup.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
//Model
import {
  type ApplicationSummaryModel,
  type ApplicationSummaryDetailResponse,
} from "@/models/application";
// Store
import { useApplicationStore } from "@/stores/applicationStore";
import { useRouter } from "vue-router";
// utils
import { getFormattedDate } from "@/utils/dateUtils";

const router = useRouter();
const moduleId = inject("moduleId");
const applicationStore = useApplicationStore();
const { getColor } = useColors();
const { t } = useI18n({});

const props = withDefaults(
  defineProps<{
    applicationList: ApplicationSummaryModel[] | null;
    partyId: number;
    winLocationBase?: string;
    winLocationQuery?: { [key: string]: string };
  }>(),
  {
    applicationList: null,
    partyId: 0,
  },
);

const modelValueArray = ref<boolean[]>(
  Array(props.applicationList?.length).fill(false),
);

const applicationDetailListArray = ref<ApplicationSummaryDetailResponse[]>(
  Array(props.applicationList?.length).fill(null),
);

function closeOtherAccordions(selectedAccordionIndex: number) {
  const _val = modelValueArray.value[selectedAccordionIndex];
  modelValueArray.value.fill(false);
  modelValueArray.value[selectedAccordionIndex] = _val;
}

async function onAccordionToggle(index: number, year: number | null) {
  closeOtherAccordions(index);
  modelValueArray.value[index] = !modelValueArray.value[index];
  if (year) {
    if (
      modelValueArray.value[index] &&
      applicationDetailListArray.value[index] === null
    ) {
      await applicationStore.loadApplicationSummaryDetailList(
        props.partyId,
        year,
        null,
      );
      applicationDetailListArray.value[index] =
        JSON.parse(
          JSON.stringify(applicationStore?.getApplicationDetailList),
        ) ?? null;
    }
  }
}

async function loadMore(index: number, year: number | null) {
  if (year) {
    await applicationStore.loadApplicationSummaryDetailList(
      props.partyId,
      year,
      applicationDetailListArray.value[index].nextKey ?? null,
    );
    applicationDetailListArray.value[index].records?.push(
      ...JSON.parse(
        JSON.stringify(
          applicationStore?.getApplicationDetailList?.records ?? [],
        ),
      ),
    );
    applicationDetailListArray.value[index].nextKey = JSON.parse(
      JSON.stringify(
        applicationStore?.getApplicationDetailList?.nextKey ?? null,
      ),
    );
  }
}

async function goToDetailPage(applicationCode: string | null) {
  if (!applicationCode) return;
  if (props.winLocationBase) {
    const queryParams =
      props.winLocationQuery && Object.entries(props.winLocationQuery).length
        ? Object.entries(props.winLocationQuery)
            .map(([k, v]) => `${k}=${v}`)
            .reduce((out, cur) => out + (out === "" ? "?" : "&") + cur, "")
        : "";
    location.assign(
      `${props.winLocationBase}/applicationlist/result/${applicationCode}/applicationDetails${queryParams}`,
    );
  } else {
    window.sessionStorage.setItem("backTo", "applicationsList");
    router.push({
      name: "applicationDetail",
      params: { applicationId: applicationCode },
    });
  }
}

function goToNewAmendment(applicationCode?: string) {
  router.push({
    name: "createAmendment",
    query: {
      applicationId: applicationCode,
    },
  });
}
</script>

<template>
  <div
    class="my-5 container"
    v-if="applicationList && applicationList.length > 0"
  >
    <BiAccordionGroup group-id="applicationList" class="w-100">
      <BiAccordion
        v-for="(application, index) in applicationList"
        bodyExtraClass="p-0 m-0"
        :modelValue="modelValueArray[index]"
        @click.stop="onAccordionToggle(index, application?.year || null)"
        :key="application?.year"
        :title="
          t(`${moduleId}.list.accordionHeader`, {
            year: application?.year,
            applicationNumber: application?.applicationsNumber || 0,
          })
        "
        groupId="applicationList"
      >
        <div class="px-4 pt-3 w-100" @click.stop="">
          <BiTable
            v-if="applicationDetailListArray[index]"
            :isRowHover="true"
            class="table-hover table-responsive"
            extraTableClasses="table-head-bg mb-0"
            @click.stop
          >
            <template v-slot:head>
              <tr class="bg-light" :class="getColor('text', 'secondary')">
                <th scope="col">
                  {{ t(`${moduleId}.list.table.sector`) }}
                </th>
                <th scope="col">
                  {{ t(`${moduleId}.list.table.form`) }}
                </th>
                <th scope="col">
                  {{ t(`${moduleId}.list.table.applicationId`) }}
                </th>
                <th scope="col">
                  {{ t(`${moduleId}.list.table.status`) }}
                </th>
                <th scope="col">
                  {{ t(`${moduleId}.list.table.date`) }}
                </th>
                <th scope="col"></th>
                <th scope="col"></th>
              </tr>
            </template>
            <template v-slot:body>
              <tr
                class="align-middle"
                v-for="(item, i) in applicationDetailListArray[index]
                  ?.records ?? []"
                :key="i"
              >
                <td :data-label="t(`${moduleId}.list.table.sector`)">
                  {{ item?.sectorDescription }}
                </td>
                <td :data-label="t(`${moduleId}.list.table.form`)">
                  {{
                    item?.applicationProfilesDescription
                      ? item?.applicationProfilesDescription + " - "
                      : ""
                  }}{{ item?.moduleDescription }}
                </td>
                <td :data-label="t(`${moduleId}.list.table.applicationId`)">
                  {{ item?.applicationId }}
                </td>
                <td :data-label="t(`${moduleId}.list.table.status`)">
                  {{
                    item?.processStatusDescription
                      ? item?.processStatusDescription
                      : item?.processStatus
                      ? item?.processStatus
                      : ""
                  }}
                </td>
                <td :data-label="t(`${moduleId}.list.table.date`)">
                  {{
                    item?.dtPresentation &&
                    getFormattedDate(item.dtPresentation)
                  }}
                </td>
                <td>
                  <BiButton
                    v-if="
                      item?.flAmendable && !applicationStore.isFunctionReadOnly
                    "
                    class="my-1"
                    :class="getColor('button', 'warning', 'outline')"
                    @click.stop="
                      () => {
                        goToNewAmendment(item?.applicationCode);
                      }
                    "
                  >
                    {{ t(`${moduleId}.list.table.amendment`) }}
                  </BiButton>
                </td>
                <td
                  class="actions"
                  :data-label="t(`${moduleId}.list.table.open`)"
                >
                  <div class="d-flex justify-content-end">
                    <BiButton
                      @click.stop="
                        () => {
                          goToDetailPage(item?.applicationCode ?? null);
                        }
                      "
                      isPrimary
                      :width="48"
                      class="me-2"
                      :isIcon="true"
                    >
                      <BiIcon
                        icon="arrow-right"
                        size="xl"
                        :class="`${getColor('text', 'success')}`"
                      />
                    </BiButton>
                  </div>
                </td>
              </tr>
            </template>
          </BiTable>
          <div
            v-if="applicationStore.loading"
            class="d-flex justify-content-center mb-3 row"
          >
            <div class="d-flex justify-content-center px-0 col-2">
              <BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
            </div>
          </div>
        </div>
        <div class="my-3 w-100 text-center" @click.stop>
          <BiButton
            v-if="
              applicationDetailListArray[index] &&
              applicationDetailListArray[index]?.nextKey !== null &&
              !applicationStore.loading
            "
            @click="loadMore(index, application?.year ?? null)"
            :class="getColor('button', 'primary', 'outline')"
          >
            {{ t(`${moduleId}.list.loadMore`) }}
          </BiButton>
        </div>
      </BiAccordion>
    </BiAccordionGroup>
  </div>
</template>
