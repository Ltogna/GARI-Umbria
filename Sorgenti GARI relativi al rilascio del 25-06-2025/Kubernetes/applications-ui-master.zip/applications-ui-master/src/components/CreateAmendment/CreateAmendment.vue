<!-- eslint-disable @typescript-eslint/no-explicit-any -->
<script setup lang="ts">
import { inject, computed, ref } from "vue";
import { useI18n } from "vue-i18n";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";

import { useApplicationStore } from "@/stores/applicationStore";
import ApplicationServiceModal from "../ApplicationServiceModal.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import { type AmendmentModule } from "@/models/application";
import RegistryApplicationInfo from "../ApplicationDetails/RegistryApplicationInfo.vue";
import { useRouter } from "vue-router";
/* import { useRouter } from "vue-router"; */

const props = defineProps<{
  applicationId: string;
  partyId?: number;
}>();

const moduleId = inject("moduleId");
const applicationStore = useApplicationStore();
const { getColor } = useColors();
const { t } = useI18n({});
const isServiceModalVisible = ref<boolean>(false);
const isCreationModalVisible = ref<boolean>(false);
const selectedModule = ref<AmendmentModule>(null);
const selectedSubject = computed(() => applicationStore.getSelectedSubject);
const router = useRouter();

const amendmentModules = computed(() => applicationStore.getAmendmentModules);

const createAmendmentResponse = computed(
  () => applicationStore.getCreateAmendmentResponse,
);

async function loadMore() {
  if (!amendmentModules.value?.nextKey) return;
  await applicationStore.loadApplicationModules(
    undefined,
    amendmentModules.value?.nextKey,
  );
}

function onOpenCreationModal(module: any) {
  selectedModule.value = module;
  isCreationModalVisible.value = true;
}

async function createAmendment() {
  if (!selectedSubject.value || !selectedModule.value) return;
  const newApplication = {
    partyId: selectedSubject.value.partyId,
    year: selectedModule.value.annuality || 0,
    moduleCode: selectedModule.value.moduleCode,
    sectorCode: selectedModule.value.sectorCode,
  };
  applicationStore.setTransitionStatus(t(`${moduleId}.serviceModal.creation`));
  await applicationStore.createAmendment(newApplication, props.applicationId);
  isCreationModalVisible.value = false;
  isServiceModalVisible.value = true;
}

function onCloseServiceModal(redirect?: boolean) {
  isServiceModalVisible.value = false;
  if (redirect) {
    router.push({
      name: "applicationDetail",
      params: {
        applicationId: createAmendmentResponse?.value?.applicationCode,
      },
    });
  }
}
</script>
<style scoped></style>
<template>
  <!--<div class="container my-5" v-if="canOperate">Create Application</div>-->
  <BiTable
    isRowHover
    class="table-hover mb-0 table-responsive"
    extraTableClasses="table-head-bg"
    isResponsive
  >
    <template v-slot:head>
      <tr class="bg-light" :class="getColor('text', 'secondary')">
        <th scope="col">
          {{ t(`${moduleId}.createAmendment.year`) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.createAmendment.sector`) }}
        </th>
        <th scope="col">
          {{ t(`${moduleId}.createAmendment.module`) }}
        </th>
        <th scope="col"></th>
      </tr>
    </template>
    <template v-slot:body>
      <tr v-for="(module, i) in amendmentModules?.records" :key="i">
        <td :data-label="t(`${moduleId}.createAmendment.year`)">
          {{ module?.annuality }}
        </td>
        <td :data-label="t(`${moduleId}.createAmendment.sector`)">
          {{ module?.sectorDescription }}
        </td>
        <td :data-label="t(`${moduleId}.createAmendment.module`)">
          {{ module?.moduleDescription }}
        </td>
        <td
          class="actions"
          :data-label="t(`${moduleId}.createAmendment.createAmendment`)"
        >
          <div class="d-flex justify-content-center">
            <BiButton
              @click.stop="onOpenCreationModal(module)"
              isPrimary
              :class="`${getColor('button', 'success')}`"
              class="me-2"
              :isIcon="true"
            >
              {{ t(`${moduleId}.createAmendment.createAmendment`) }}
            </BiButton>
          </div>
        </td>
      </tr>
    </template>
  </BiTable>
  <div class="w-100 text-center" @click.stop>
    <BiButton
      v-if="amendmentModules?.nextKey"
      @click="loadMore()"
      :class="getColor('button', 'primary', 'outline')"
    >
      {{ t(`${moduleId}.list.loadMore`) }}
    </BiButton>
  </div>
  <BiModal
    :disabled-teleport="true"
    :extra-footer-class="'justify-content-center'"
    v-model="isCreationModalVisible"
    :aria-labelledby="t(`${moduleId}.searchForm.createApplication`)"
    :title="t(`${moduleId}.searchForm.createApplication`)"
    :prevent-dismiss="true"
    :size="'lg'"
  >
    <template #body>
      <p class="mb-3">
        <strong>
          {{ t(`${moduleId}.serviceModal.newApplicationInfo`) }}:
        </strong>
      </p>
      <RegistryApplicationInfo
        :cuaa="selectedSubject?.code"
        :name="selectedSubject?.description"
        :sector="selectedModule?.sectorDescription"
        :module="selectedModule?.moduleDescription"
        :year="selectedModule?.annuality"
      />
    </template>
    <template #footer>
      <div class="mt-3 mb-5 d-flex justify-content-center">
        <BiButton
          class="mx-2 w-fit"
          size="lg"
          :class="getColor('button', 'secondary', 'outline')"
          @click.stop="isCreationModalVisible = false"
        >
          {{ t(`${moduleId}.general.cancel`) }}
        </BiButton>
        <BiButton
          class="mx-2 w-fit"
          isPrimary
          size="lg"
          :class="getColor('button', 'success')"
          @click.stop="createAmendment()"
          >{{ t(`${moduleId}.general.confirm`) }}</BiButton
        >
      </div>
    </template>
  </BiModal>
  <ApplicationServiceModal
    :open-modal="isServiceModalVisible"
    :party="selectedSubject"
    :module="selectedModule"
    :is-create-application="true"
    @close="onCloseServiceModal"
    :translation-module="'createApplicationModal'"
    :application-id="createAmendmentResponse?.applicationId"
  ></ApplicationServiceModal>
</template>
