<script lang="ts">
interface ButtonInterface {
  text: string;
  classes?: string;
  callback: (() => void) | void;
  hideButton?: boolean;
}
</script>
<script setup lang="ts">
// Boootstrap Italia components
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import { useApplicationStore } from "@/stores/applicationStore";
import { computed } from "vue";
import BiBackButton from "@abaco/bootstrap-italia-components/src/components/BiBackButton/BiBackButton.vue";
//State manager
const { getColor } = useColors();
const applicationStore = useApplicationStore();

const isLoading = computed(() => applicationStore.getIsLoading);

const props = withDefaults(
  defineProps<{
    isBackButton?: boolean;
    backButtonFunction?: (() => void) | void;
    title?: string;
    titleClasses?: string;
    buttonList?: ButtonInterface[];
  }>(),
  {
    backButtonFunction: () => null,
    title: "",
  },
);
</script>

<template>
  <div
    class="row mx-0 d-flex flex-row px-2 card-header py-3 border-bottom-2 border-primary align-items-center justify-content-between"
  >
    <div class="col-md-7 d-flex align-items-center my-1 my-md-0">
      <div v-if="props.isBackButton">
        <!-- <BiButton
          :isIcon="true"
          @click.stop="
            () => {
              props.backButtonFunction && props.backButtonFunction();
            }
          "
          :is-disabled="isLoading"
          isPrimary
          :width="40"
          class="me-3 my-0 back-button-card"
          :class="`${getColor('button', 'primary', 'outline')}`"
        >
          <BiIcon
            icon="arrow-left"
            color="primary"
            size="xl"
            icon-style="regular"
          />
        </BiButton> -->
        <BiBackButton
          class="me-3 my-0 back-button-card"
          @click="
            () => {
              !isLoading &&
                props.backButtonFunction &&
                props.backButtonFunction();
            }
          "
        />
      </div>
      <div>
        <h3
          class="mb-0"
          :class="`${getColor('text', 'primary')} ${
            props.titleClasses ? props.titleClasses : ''
          }`"
        >
          {{ props.title }}
        </h3>
      </div>
    </div>
    <div
      v-if="props.buttonList && props.buttonList.length > 0"
      class="col-md-5 text-center text-md-end my-1 my-md-0"
    >
      <template v-for="button in buttonList" :key="JSON.stringify(button)">
        <BiButton
          v-if="!button.hideButton"
          @click="
            () => {
              button.callback && button.callback();
            }
          "
          :class="button.classes || ''"
          class="my-1"
        >
          {{ button.text }}
        </BiButton>
      </template>
    </div>
  </div>
</template>
