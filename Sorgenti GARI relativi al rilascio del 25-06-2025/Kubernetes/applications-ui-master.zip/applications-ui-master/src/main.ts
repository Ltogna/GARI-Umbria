import { createPinia } from "pinia";
import { createApp } from "vue";
import i18n, { loadLocaleMessages } from "./i18n";
import { isStandalone } from "./utils/isStandalone";
import createBootstrapItaliaPlugin from "@abaco/bootstrap-italia-components/src/components/BootstrapItaliaComponentPlugin";
import App from "./App.vue";
import type { App as VueApp } from "vue";
import routes from "./routes";
import { useUserAdminStore } from "./stores/userAdminStore";
import { onModuleLoaded } from "@abaco/micro-frontend/src/Application";
import { createAbcRouter } from "@abaco/micro-frontend/src/Utility";
import { useApplicationStore } from "./stores/applicationStore";
import { ROUTE_LEAVE_CONFIRM_COMPONENT_NAME } from "@abaco/micro-frontend/src/model";
import AskExitConfirmDialoag from "./components/AskExitConfirmDialog.vue";
import { BASE } from "./constants";

export const MODULE_ID = "application";
export const IS_DEV = import.meta.env.DEV;

// XXX do this only for test
if (IS_DEV && import.meta.env.VITE_USER_CONFIG) {
  sessionStorage.setItem("sso2data", import.meta.env.VITE_USER_CONFIG);
}
import("@/assets/applicationModule.scss");

async function initApplication(isStandalone: boolean, basePath?: string) {
  const router = createAbcRouter(routes, basePath);
  const bootstrapItaliaComponentPlugin = await createBootstrapItaliaPlugin({
    includeGlobalComponent: false,
    includeFontAwesome: isStandalone ? true : false,
  });
  const app = createApp(App);
  await loadLocaleMessages(window.navigator.language);
  app.use(i18n);
  app.use(bootstrapItaliaComponentPlugin);
  app.use(createPinia());
  app.use(router);
  app.provide("moduleId", MODULE_ID);
  app.provide("isDev", IS_DEV);
  app.provide("basePath", basePath);
  app.component(ROUTE_LEAVE_CONFIRM_COMPONENT_NAME, AskExitConfirmDialoag);
  const applicationStore = useApplicationStore();

  router.beforeEach((to) => {
    const routeApplicationId = to.params.applicationId as string;
    if (routeApplicationId) {
      applicationStore.setRouteApplicationId(routeApplicationId);
    } else if (to.name === "createApplication") {
      applicationStore.setRouteApplicationId("new");
    }
  });

  return app;
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
let dirtyState = false;
if (isStandalone) {
  window.bootstrap.loadFonts(
    `${import.meta.env.BASE_URL}bootstrap-italia/dist/fonts`,
  );
  await import("@/assets/index.scss");
  initApplication(isStandalone, import.meta.env.BASE_URL).then((app) => {
    app.mount("#app");
    useUserAdminStore().fetchMyUsername();
  });
} else {
  let appModule: VueApp<Element> | null;

  onModuleLoaded(MODULE_ID, {
    async start(node: string | Element, basePath?: string) {
      const app = await initApplication(isStandalone, basePath);
      app.mount(node);
      appModule = app;
    },

    css() {
      return {
        index: BASE + "assets/index.css.json",
      };
    },
    async canStop() {
      // if (dirtyState) {
      //   return {
      //     title: i18n.global.t(`${MODULE_ID}.micro.askForExitTitle`),
      //     message: i18n.global.t(`${MODULE_ID}.micro.askForExitMessage`),
      //   };
      // } else {
      return true;
      // }
    },
    async stop() {
      appModule?.unmount();
    },
  });
}

window.addEventListener("forms-dirty-state", ((event: CustomEvent) => {
  dirtyState = event.detail.formDirtyState;
}) as EventListener);
