export const FORCED_CONTEXT = "";
export const BASE = `${FORCED_CONTEXT}/ui/application/`;
// export const BASE = `${FORCED_CONTEXT}/`; //use this for local development
