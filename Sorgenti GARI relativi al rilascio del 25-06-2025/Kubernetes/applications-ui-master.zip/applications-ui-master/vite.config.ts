import { fileURLToPath, URL } from "url";

import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";
import { BASE } from "./src/constants";
import { viteStaticCopy } from "vite-plugin-static-copy";
import vueDevTools from "vite-plugin-vue-devtools";

// https://vitejs.dev/config/
export default defineConfig({
  base: BASE,
  plugins: [
    vue(),
    viteStaticCopy({
      targets: [
        {
          src: "node_modules/bootstrap-italia/dist/**/*",
          dest: "bootstrap-italia/dist",
        },
      ],
    }),
    vueDevTools(),
  ],
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  build: {
    rollupOptions: {
      output: {
        entryFileNames: "[name].[hash].js",
        assetFileNames: "assets/[name].[hash].[ext]",
      },
    },
  },
  server: {
    port: 3000,
    proxy: {
      "/applications": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        // target: "https://schedario-api-gateway-devel.cdpks01.sian.it/schedario",
        // target: "https://georgianfa-dev.fe.abacogroup.eu",
        secure: false,
        changeOrigin: true,
      },
      "/party-registry": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        // target: "https://schedario-api-gateway-devel.cdpks01.sian.it/schedario",
        // target: "https://georgianfa-dev.fe.abacogroup.eu",
        secure: false,
        changeOrigin: true,
      },
      "/application-forms": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        // target: "https://schedario-api-gateway-devel.cdpks01.sian.it/schedario",
        // target: "https://georgianfa-dev.fe.abacogroup.eu",
        secure: false,
        changeOrigin: true,
      },
      "/ui/app-forms": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        // target: "https://schedario-api-gateway-devel.cdpks01.sian.it/schedario",
        // target: "https://georgianfa-dev.fe.abacogroup.eu",
        secure: false,
        changeOrigin: true,
      },
      "/ui/rrv-app-forms": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        // target: "https://schedario-api-gateway-devel.cdpks01.sian.it/schedario",
        // target: "https://georgianfa-dev.fe.abacogroup.eu",
        secure: false,
        changeOrigin: true,
      },
      "/ui/georgia-nfa-inspection-ui": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        // target: "https://schedario-api-gateway-devel.cdpks01.sian.it/schedario",
        // target: "http://localhost:3003",
        secure: false,
        changeOrigin: true,
      },
      "/georgia-nfa-inspection": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        // target: "https://schedario-api-gateway-devel.cdpks01.sian.it/schedario",
        // target: "https://georgianfa-dev.fe.abacogroup.eu",
        secure: false,
        changeOrigin: true,
      },
      "/rrv-application-forms": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        // target: "https://schedario-api-gateway-devel.cdpks01.sian.it/schedario",
        // target: "https://georgianfa-dev.fe.abacogroup.eu",
        secure: false,
        changeOrigin: true,
      },
      "/sso2": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        // target: "https://schedario-api-gateway-devel.cdpks01.sian.it/schedario",
        // target: "https://georgianfa-dev.fe.abacogroup.eu",
        secure: false,
        changeOrigin: true,
      },
      "/agea-legacy": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        // target: "https://schedario-api-gateway-devel.cdpks01.sian.it/schedario",
        // target: "https://georgianfa-dev.fe.abacogroup.eu",
        secure: false,
        changeOrigin: true,
      },
      "/avepa-legacy": {
        target: "https://iacs-dev.fe.abacogroup.eu/",
        // target: "https://schedario-api-gateway-devel.cdpks01.sian.it/schedario",
        // target: "https://georgianfa-dev.fe.abacogroup.eu",
        secure: false,
        changeOrigin: true,
      },
    },
  },
});
