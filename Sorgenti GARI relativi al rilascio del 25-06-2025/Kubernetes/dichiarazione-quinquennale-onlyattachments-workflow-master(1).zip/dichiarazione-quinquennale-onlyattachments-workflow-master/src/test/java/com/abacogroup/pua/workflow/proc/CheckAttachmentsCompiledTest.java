package com.abacogroup.pua.workflow.proc;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.ArgumentMatchers.any;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.abacogroup.pua.workflow.util.Const;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage.Type;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
class CheckAttachmentsCompiledTest {

    @Test
    void testCheckAttachementsCompiled_OK() {
    	
    	CheckAttachmentsCompiled proc = new CheckAttachmentsCompiled();
        
        List<String> profiles = proc.getFormCodesToCheck();
        
        assertThat(profiles, containsInAnyOrder(Const.PUA_ALLEGATI));
 
        WorkflowMessage workflowMessage = proc.createMessage( Const.PUA_ALLEGATI, Const.PUA_ALLEGATI, any(), any());
        
        assertThat(workflowMessage.getCode(), containsString(Const.PUA_ALLEGATI_INCOMPLETED));
        assertThat(workflowMessage.getDescription(), containsString("Non è stato inserito alcun alllegato oppure sono presenti uno o più allegati non validi"));
        assertEquals(workflowMessage.getType(), Type.ERROR);
         
    }
    
    @Test
    void testCheckAttachementsCompiled_KO() {
    	
    	CheckAttachmentsCompiled proc = new CheckAttachmentsCompiled();
        
        WorkflowMessage workflowMessage = proc.createMessage( Const.PUA_ALLEGATI, Const.PUA_ALLEGATI, any(), any());
        
        assertNotEquals(workflowMessage.getCode(), Const.PUA_FINAL_DECLARATION_INCOMPLETED);
    }
 
}
