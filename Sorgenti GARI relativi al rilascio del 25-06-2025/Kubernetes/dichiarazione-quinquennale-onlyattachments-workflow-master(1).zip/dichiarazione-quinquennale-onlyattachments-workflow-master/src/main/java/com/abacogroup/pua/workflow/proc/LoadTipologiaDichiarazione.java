package com.abacogroup.pua.workflow.proc;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.pua.workflow.model.TipologiaDichiarazione;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LoadTipologiaDichiarazione extends BaseProcedure {

	@Override
	protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {
		log.debug("[dichiarazione-quinquennale-onlyattachments-workflow] LoadTipologiaDichiarazione started");

		TipologiaDichiarazione tipologiaDichiarazione = puaAppRequest(TipologiaDichiarazione.class, "tipologia-dichiarazione");

		processData.getGlobalVars().put(TipologiaDichiarazione.KEY, tipologiaDichiarazione);
		log.debug("[dichiarazione-quinquennale-onlyattachments-workflow] Setting global var {} = {}", TipologiaDichiarazione.KEY, tipologiaDichiarazione);
	}
}
