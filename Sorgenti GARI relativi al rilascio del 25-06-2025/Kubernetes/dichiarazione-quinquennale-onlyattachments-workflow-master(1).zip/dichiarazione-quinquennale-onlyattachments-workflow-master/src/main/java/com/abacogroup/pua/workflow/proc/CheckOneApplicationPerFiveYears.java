package com.abacogroup.pua.workflow.proc;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.applicationworkflowsdk.model.GetApplicationFilters;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.pua.workflow.model.TipologiaDichiarazione;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Optional;

@Slf4j
public class CheckOneApplicationPerFiveYears extends BaseProcedure {

    private static final String APP_MODULE_CODE = "DICHIARAZIONE_QUINQUENNALE_ONLYATTACHMENT";
    private static final String APP_MODULE_CODE_RECTIFIED = "DICHIARAZIONE_QUINQUENNALE_ONLYATTACHMENT_RECTIFIED";

    @Override
    protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {
        TipologiaDichiarazione tipologiaDichiarazione = processData.<TipologiaDichiarazione>getGlobalVar(TipologiaDichiarazione.KEY)
                .orElseThrow();
        
        log.debug("Starting CheckOneApplicationPerFiveYears procedure execution");
        
        log.debug("Retrieved TipologiaDichiarazione with year: {}", tipologiaDichiarazione.getYear());

        ApplicationsWorkflowParams params = getApplicationsWorkflowParams();
        
        Long amendedApplicationId = params.getAmendedApplicationId();
        log.debug("Amended application ID: {}", amendedApplicationId);
		
    	if(amendedApplicationId != null){
			
    		int thisAppYear = tipologiaDichiarazione.getYear();
            log.debug("Current application year: {}", thisAppYear);

    		int amendedAppYear = 
					getTipologiaDichiarazioneYear(amendedApplicationId, processData, env).get(); // rectified App
		    
            log.debug("Amended application year: {}", amendedAppYear);
		
			if ( thisAppYear != amendedAppYear ) {
                log.debug("Year mismatch detected - current: {}, amended: {}", thisAppYear, amendedAppYear);
				String code = "APP_YEAR_CANNOT_BE_DIFFERENT_AS_RECTIFIED";
				String description = "Non puoi inserire un anno differente rispetto a l'anno della domanda che stai rettificando (%s).";
				var workflowMessage = new WorkflowMessage(code, String.format(description, amendedAppYear), WorkflowMessage.Type.ERROR);
				processData.getWorkflowMessages().add(workflowMessage);
			} else {
                log.debug("Year validation passed for amended application");
            }
		}

        String currentModuleCode = env.getApplicationDetailsService().retrieveApplicationDetails(processData.getTenantId(),
                params.getApplicationId(), (User) processData.getAuthContext().getPrincipal()).getModuleCode();
        
        log.debug("Current application module code: {}", currentModuleCode);

        if(APP_MODULE_CODE_RECTIFIED.equals(env.getApplicationDetailsService().retrieveApplicationDetails(processData.getTenantId(),
                params.getApplicationId(), (User) processData.getAuthContext().getPrincipal()).getModuleCode())){
            return;
        }

        List<ApplicationDetailsPublicDTO> apps = env.getApplicationDetailsService().getApplicationsByParty(processData.getTenantId(), params.getPartyId(),
                GetApplicationFilters.builder().moduleCode(APP_MODULE_CODE).build(),
                (User) processData.getAuthContext().getPrincipal());

        boolean found = apps.stream()
                .filter(a -> !a.getApplicationId().equals(params.getApplicationId())) // Not the current app
                .filter(a -> "PROTOCOLLED".equals(a.getProcessStatus()) || "RECTIFIED".equals(a.getProcessStatus()))
                .anyMatch(a -> lessThanFiveYearsDifference(tipologiaDichiarazione.getYear(),
                        Optional.ofNullable(puaAppRequest(TipologiaDichiarazione.class, "tipologia-dichiarazione", a.getApplicationId()).getYear())));

        if (found) {
            processData.getWorkflowMessages()
                    .add(new WorkflowMessage("APP_ALREADY_EXIST", "Esiste già una domanda quinquennale comprendente l'anno selezionato", WorkflowMessage.Type.ERROR));
        }
    }

    private boolean lessThanFiveYearsDifference(Integer year, Optional<Integer> other) {
        if (year == null && other.isEmpty()) {
            return true;
        }

        if (year == null || other.isEmpty()) {
            return false;
        }

        return year >= other.get() && year <= other.get() + 5;
    }

    public Optional<Integer> getTipologiaDichiarazioneYear(Long applicationId, ProcessData processData, IAgriProcedureEnvironment env) {
        
        log.debug("Retrieving TipologiaDichiarazione year for application ID: {}", applicationId);
        
        String url = env.getProperty("puaAppFormsUrl").orElseThrow().toString();
        log.debug("Using PUA app forms URL: {}", url);

        Client client = env.getJerseyClient().orElseThrow();
        WebTarget target = processData.getAuthContext()
                .getAuthenticatedWebTarget(client, url)
                .path("/master/v1/applications/")
                .path(applicationId.toString())
                .path("tipologia-dichiarazione");
        
        log.debug("Making GET request to: {}", target.getUri());
        
        try (Response response = target.request(MediaType.APPLICATION_JSON).get()) {
            int status = response.getStatus();
            log.debug("HTTP response status: {}", status);
            
            if (status == 404) {
                log.debug("TipologiaDichiarazione not found for application {}", applicationId);
                return Optional.empty();
            }

            if (status < 200 || status > 299) {
                log.debug("Bad HTTP response status {} for application {}", status, applicationId);
                throw new IllegalStateException("Got a bad response loading 'tipologia dichiarazione' for app" + applicationId + "; status is: " + status);
            }

            TipologiaDichiarazione tipologiaDichiarazione = response.readEntity(TipologiaDichiarazione.class);
            Integer year = tipologiaDichiarazione.getYear();
            log.debug("Retrieved year {} for application {}", year, applicationId);
            return Optional.ofNullable(year);
            
        } catch (Exception e) {
            log.error("Exception during loading of tipologia dichiarazione for app {}: {}", applicationId, e.getMessage(), e);
            throw e;
        }
    }

}
