package com.abacogroup.pua.workflow.proc;

import com.abacogroup.applicationworkflowsdk.v2.procedures.ApplicationProcedure;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.proc.StopTransitionException;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;

@Slf4j
public abstract class BaseProcedure extends ApplicationProcedure {
	protected <T> T puaAppRequest(Class<T> classType, String apiPath) {
		return puaAppRequest(classType, apiPath, getApplicationsWorkflowParams().getApplicationId());
	}

	protected <T> T puaAppRequest(Class<T> classType, String apiPath, Long applicationId) {
		return internalServiceGetRequest(classType, getProcedureEnvironment().getProperty("puaAppFormsUrl").orElseThrow().toString(), "/master/v1/applications/",
				applicationId + "/" + apiPath);
	}
	protected <T> T lpisServerGetRequest(Class<T> classType, String apiPath) {
		return internalServiceGetRequest(classType, getProcedureEnvironment().getProperty("lpisServerUrl").orElseThrow().toString(), "/master/public/v1/lpis/",
				apiPath);
	}
	protected <T> T lpisServerPostRequest(Class<T> classType, String apiPath, Map<String, Object> queryParams, Map<String, List<String>> payload) {
		return internalServicePostRequest(classType, getProcedureEnvironment().getProperty("lpisServerUrl").orElseThrow().toString(),
				"/master/public/v1/lpis/", apiPath, queryParams, payload);
	}
	protected <T> T internalServicePostRequest(Class<T> classType, String hostAndContextRoot, String internalService, String apiPath,
			Map<String, Object> queryParams, Map<String, List<String>> payload) {
		WebTarget target = getWebTarget(hostAndContextRoot, internalService, apiPath);

		Entity<Map<String, List<String>>> entity = Entity.entity(payload, MediaType.APPLICATION_JSON_TYPE);
		log.debug("[dichiarazione-quinquennale-onlyattachments-workflow] Preparing WebTarget for POST request");
		for(var queryParam: queryParams.entrySet()){
			target.queryParam(queryParam.getKey(),queryParam.getValue());
		}
		try (Response response = target.request(MediaType.APPLICATION_JSON).post(entity)) {
			handleHttpResponse(response);
			log.debug("POST response is: {}", response);
			log.debug("Classtype is: {}", classType);

			return response.readEntity(classType);
		}
	}

	protected <T> T internalServiceGetRequest(Class<T> classType, String hostAndContextRoot, String internalService, String apiPath) {
		WebTarget target = getWebTarget(hostAndContextRoot, internalService, apiPath);

		log.debug("[dichiarazione-quinquennale-onlyattachments-workflow] Preparing WebTarget for GET request");
		try (Response response = target.request(MediaType.APPLICATION_JSON).get()) {
			handleHttpResponse(response);
			log.debug("GET response is: ", response);

			return response.readEntity(classType);
		}
	}

	private void handleHttpResponse(Response response) {
		int status = response.getStatus();
		if (status == 404) {
			getProcessData().getWorkflowMessages()
					.add(new WorkflowMessage("FORM_NOT_PRESENT", "Compilare la form per procedere", WorkflowMessage.Type.ERROR));

			throw new StopTransitionException();
		}

		if (status < 200 || status > 299) {
			throw new IllegalStateException("Got a bad response; status is: " + status);
		}
	}

	private WebTarget getWebTarget(String hostAndContextRoot, String internalService, String apiPath) {
		Client client = getProcedureEnvironment().getJerseyClient().orElseThrow();
		WebTarget target = getProcessData().getAuthContext()
				.getAuthenticatedWebTarget(client, hostAndContextRoot)
				.path(internalService)
				.path(apiPath);
		log.debug("[dichiarazione-quinquennale-onlyattachments-workflow] URL is {}{}{}", hostAndContextRoot, internalService, apiPath);
		return target;
	}

}
