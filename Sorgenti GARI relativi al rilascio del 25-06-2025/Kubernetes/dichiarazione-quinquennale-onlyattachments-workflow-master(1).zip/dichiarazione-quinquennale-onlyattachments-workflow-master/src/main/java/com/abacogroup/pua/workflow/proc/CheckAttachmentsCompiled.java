package com.abacogroup.pua.workflow.proc;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.v2.procedures.CheckFormsAreCompiledProcedure;
import com.abacogroup.pua.workflow.util.Const;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;

import lombok.extern.slf4j.Slf4j;

/**
 * Check if mandatory modules had been compiled
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class CheckAttachmentsCompiled extends CheckFormsAreCompiledProcedure {

	@Override
	protected WorkflowMessage createMessage(String formId, String formName, ProcessData processData,
			IAgriProcedureEnvironment env) {
 
		// error message based on the form id that is not filled out ("status identifier" verification)  
		
		String msg = null;
		String  code = null;
		
		log.debug("formId = {} and formName = {}", formId, formName);
		
		if (Const.PUA_ALLEGATI.equals(formId)) {
			msg = "Non è stato inserito alcun alllegato oppure sono presenti uno o più allegati non validi";
			code = Const.PUA_ALLEGATI_INCOMPLETED;
		}
		else {
			msg = "Errore non gestito";
			code = Const.PUA_UNHANDLED_ERROR;
		}
		
		log.debug("error message: code = {} and description = {}", code, msg);
		
		return new WorkflowMessage(code, msg, WorkflowMessage.Type.ERROR);
	}

	@Override
	protected List<String> getFormCodesToCheck() {
		 
		// list of mandatory forms (form codes are defined in the question bundle)

		List<String> formCodesToCheck = Arrays.asList(Const.PUA_ALLEGATI);
		
		log.debug("FormCodesToCheck = {}", formCodesToCheck);

		return formCodesToCheck;
	}

	@Override
	protected Set<String> getAllowedProfiles() {

		// check will be performed only if the profile(s) exist(s)
		// as null the "Signature Compiled" check will be performed for all profiles
		return null;
	}

}
