package com.abacogroup.pua.workflow.util;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
public final class Const {
 
	public static final String PUA_DICHIARAZIONE_QUINQUENNALE_ONLYATTACMENTS = "PUA_DICHIARAZIONE_QUINQUENNALE_ONLYATTACMENTS";
	public static final String PUA_DICHIARAZIONE_FINALE = "PUA_DICHIARAZIONE_FINALE";
	public static final String PUA_ALLEGATI = "PUA_ALLEGATI";

	public static final String PUA_DICHIARAZIONE_QUINQUENNALE_ONLYATTACMENTS_INCOMPLETED = "PUA_DICHIARAZIONE_QUINQUENNALE_ONLYATTACMENTS_INCOMPLETED";
	public static final String PUA_FINAL_DECLARATION_INCOMPLETED = "PUA_FINAL_DECLARATION_INCOMPLETED";
	public static final String PUA_ALLEGATI_INCOMPLETED = "PUA_ALLEGATI_INCOMPLETED";

	public static final String PUA_UNHANDLED_ERROR = "PUA_UNHANDLED_ERROR";
	
	private Const() {
	}

}
