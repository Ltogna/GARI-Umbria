package com.abacogroup.pua.workflow.proc;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.ArgumentMatchers.any;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.pua.workflow.util.Const;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage.Type;
import com.abacogroup.workflow.sdk.profiles.ProfilesManager;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@ExtendWith(MockitoExtension.class)
class CheckProfileAllevamentiCompiledTest {
	
	@Mock
	private ProcessData processData;

	@Mock
	private ProfilesManager profilesManager;

	@Mock
	private IAgriProcedureEnvironment env;

    @Test
    void testCheckProfileSempliceCompiled_OK() {
    	
    	CheckProfileAllevamentiCompiled proc = new CheckProfileAllevamentiCompiled();
        
        List<String> profiles = proc.getFormCodesToCheck();
        
        assertThat(profiles, containsInAnyOrder(
				 Const.PUA_DICHIARAZIONE_CONSISTENZA_ANIMALI,
				 Const.PUA_DICHIARAZIONE_FINALE));
 
        WorkflowMessage workflowMessage = proc.createMessage( Const.PUA_DICHIARAZIONE_CONSISTENZA_ANIMALI, 
        		Const.PUA_DICHIARAZIONE_CONSISTENZA_ANIMALI, processData, env);
        
        assertThat(workflowMessage.getCode(), containsString(Const.PUA_DICHIARAZIONE_CONSISTENZA_ANIMALI_INCOMPLETED));
        assertThat(workflowMessage.getDescription(), containsString("Dichiarazione consistenza animali incompleta"));
        assertEquals(workflowMessage.getType(), Type.ERROR);
         
    }
    
    @Test
    void testCheckProfileSempliceCompiled_KO() {
    	
    	CheckProfileAllevamentiCompiled proc = new CheckProfileAllevamentiCompiled();
        
        WorkflowMessage workflowMessage = proc.createMessage( Const.PUA_DICHIARAZIONE_CONSISTENZA_ANIMALI, 
        		Const.PUA_DICHIARAZIONE_CONSISTENZA_ANIMALI, processData, env);
        
        assertNotEquals(workflowMessage.getCode(), Const.PUA_FINAL_DECLARATION_INCOMPLETED);
    }
 
}
