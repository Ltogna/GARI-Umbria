package com.abacogroup.pua.workflow.proc;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;

import com.abacogroup.pua.workflow.model.TipologiaDichirazione;

public class ComputeAndSetProfilesTest {

    @Test
    void testComputeProfiles() {
        ComputeAndSetProfiles proc = new ComputeAndSetProfiles();
        TipologiaDichirazione td;
        List<String> profiles;

        td = new TipologiaDichirazione(2024, false, false);
        profiles = proc.computeProfiles(td, Set.of("Y2024"));
        assertThat(profiles, containsInAnyOrder("SEMPLICE", "Y2024"));

        td = new TipologiaDichirazione(2024, true, false);
        profiles = proc.computeProfiles(td, Set.of("Y2024"));
        assertThat(profiles, containsInAnyOrder("FERT_ORGANICI", "Y2024"));

//        td = new TipologiaDichirazione(2024, false, true);
//        profiles = proc.computeProfiles(td, Set.of("Y2024"));
//        assertThat(profiles, containsInAnyOrder("ALLEVAMENTI", "Y2024"));

        td = new TipologiaDichirazione(2024, true, true);
        profiles = proc.computeProfiles(td, Set.of("Y2024"));
        assertThat(profiles, containsInAnyOrder("FERT_ORGANICI", "ALLEVAMENTI", "Y2024"));
    }

    @Test
    void testErrorWhenYearProfileIsMissing() {
        ComputeAndSetProfiles proc = new ComputeAndSetProfiles();
        TipologiaDichirazione td = new TipologiaDichirazione(2025, false, false);
        assertThrows(IllegalStateException.class, () -> proc.computeProfiles(td, Set.of("Y2024")));
    }
}
