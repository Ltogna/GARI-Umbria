package com.abacogroup.pua.workflow.proc;

import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationProfilePublicDTO;
import com.abacogroup.applicationworkflowsdk.v2.services.ApplicationProfilesService;
import com.abacogroup.workflow.sdk.auth.AuthContext;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.proc.StopTransitionException;
import com.sun.net.httpserver.HttpServer;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.WebTarget;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@ExtendWith(MockitoExtension.class)
public class AggiornaImpiantiNPuaTest {

	@Mock
    private ProcessData processData;
    
    @Mock
    private AuthContext authContext;
    
    @Mock
    private IAgriProcedureEnvironment env;
     
    @Mock
	private ApplicationsWorkflowParams applicationsWorkflowParams;
     
    @Mock
	private ApplicationProfilesService applicationProfilesService;
 
    private static final int SERVER_PORT = 8089;
    
    private static final String BASE_URL = "http://localhost";

	private static final String URL = BASE_URL + ":" + 
			SERVER_PORT + "/mock-pua-app/master/v1/applications/123/aggiorna-impianti-n-pua";

	private static final String TENANT = "master";

	private static final Long APPLICATION_ID = 123L;
   
	private static HttpServer httpServer;

	private AggiornaImpiantiNPua aggiornaImpiantiNPua;

	@BeforeAll
    static void setUp() throws IOException {
    	
        // start local HTTP server
        httpServer = HttpServer.create(new InetSocketAddress(SERVER_PORT), 0);
        httpServer.start();
    }

    @AfterAll
    static void tearDown() {
        httpServer.stop(0);
    }
    
    @BeforeEach
    void initTest() {
    	
    	ApplicationProfilePublicDTO applicationProfilePublicDTO = new ApplicationProfilePublicDTO("ALLEVAMENTI", "ALLEVAMENTI");
    	List<ApplicationProfilePublicDTO> profiles = Collections.singletonList(applicationProfilePublicDTO);
    	
        Client client = ClientBuilder.newClient();
    	WebTarget webTarget = client.target(URL);
    	
    	when(processData.getGlobalVar("workflowParams")).thenReturn(Optional.ofNullable(applicationsWorkflowParams));
    	when(applicationsWorkflowParams.getApplicationId()).thenReturn(APPLICATION_ID);
    	when(applicationsWorkflowParams.getTenant()).thenReturn(TENANT);

    	when(env.getApplicationProfilesService()).thenReturn(applicationProfilesService);
    	when(applicationProfilesService.getAllApplicationProfiles(processData, TENANT, APPLICATION_ID))
    			.thenReturn(profiles);
    	
    	when(env.getProperty("call.aggiorna.impianti.npua")).thenReturn(null/*Optional.ofNullable("true")*/);
    	
    	when(env.getProperty("puaAppFormsUrl")).thenReturn(Optional.ofNullable(URL));
    	when(env.getProperty("call.aggiorna.impianti.npua")).thenReturn(Optional.ofNullable("true"));
    	
    	when(processData.getAuthContext()).thenReturn(authContext);
    	when(authContext.getAuthenticatedWebTarget(any(), any())).thenReturn(webTarget);
    }
    
//    @Test
    void testSuccessfulExecution_with_success_http_resp_200() throws Exception {
    	 
    	try {

    		aggiornaImpiantiNPua = new AggiornaImpiantiNPua();
    		
    		Client client = ClientBuilder.newClient();
            when(env.getJerseyClient()).thenReturn(Optional.ofNullable(client));
    		
    		// /{tenant}/v1/applications/{applicationId}/fert-spreading-declarations/{partyId}/aggiorna-impianti-n-pua
	   		httpServer.createContext("/mock-pua-app/master/v1/applications/123/aggiorna-impianti-n-pua", 
    				exchange -> {
    					
    					exchange.getResponseHeaders().add("Content-Type", "application/json");
    					
    					String jsonResponse = """
    							{
								    "message": "OK",
								    "errore": "",
								    "dati": {
								        "ElencoAppezzamenti": [
								            {
								                "message": "OK",
								                "errore": "",
								                "Chiave_Appezzamento": "7349"
								            },
								            {
								                "message": "OK",
								                "errore": "",
								                "Chiave_Appezzamento": "7544"
								            }
								        ]
								    }
								}
    							""";
    			        
    			        // CORRETTO: calcola la lunghezza reale
    			        byte[] responseBytes = jsonResponse.getBytes();
    			        exchange.sendResponseHeaders(200, responseBytes.length);
    			        
    			        // Scrivi il JSON nel response body
    			        try (OutputStream os = exchange.getResponseBody()) {
    			            os.write(responseBytes);
    			            os.flush();
    			        }
    					 
    				});

    	} catch (Exception e) {
    		fail("ERROR IN testSuccessfulExecution_with_success_http_resp_200", e);
    	}
    	
    	
    	try {
			
    		aggiornaImpiantiNPua.doExecute(processData, env);
    		
    		// SUCCEDED: waited no Exception and HTTP 200
    		
		} catch (Exception e) {
			e.printStackTrace();
    		fail("ERROR IN testSuccessfulExecution_with_success_http_resp_200", e);
    	}
    }
    
//    @Test
    void testSuccessfulExecution_with_http_error_400() throws Exception {
    	 
    	try {

    		aggiornaImpiantiNPua = new AggiornaImpiantiNPua();
    		
    		Client client = ClientBuilder.newClient();
            when(env.getJerseyClient()).thenReturn(Optional.ofNullable(client));
    		
    		// /{tenant}/v1/applications/{applicationId}/fert-spreading-declarations/{partyId}/aggiorna-impianti-n-pua
	   		httpServer.createContext("/mock-pua-app/master/v1/applications/123/aggiorna-impianti-n-pua", 
    				exchange -> {
    					
    					exchange.getResponseHeaders().add("Content-Type", "application/json");
    					
    					// SET ERROR RESPONSE 404
    					exchange.sendResponseHeaders(404, 1);
    					 
    				});

    	} catch (Exception e) {
    		fail("ERROR IN testSuccessfulExecution_with_http_error_400", e);
    	}
    	 
    	try {
			
    		aggiornaImpiantiNPua.doExecute(processData, env);
    		
		} catch (StopTransitionException e) {
			
			// SUCCEDED: waited StopTransitionException with HTTP ERROR 404
			
			
		}catch (Exception e) {
    		fail("ERROR IN testSuccessfulExecution_with_http_error_400", e);
    	}
    }
    
//    @Test
    void testSuccessfulExecution_with_response_http_error_305() throws Exception {
    	 
    	try {

    		aggiornaImpiantiNPua = new AggiornaImpiantiNPua();
    		
    		Client client = ClientBuilder.newClient();
            when(env.getJerseyClient()).thenReturn(Optional.ofNullable(client));
    		
    		// /{tenant}/v1/applications/{applicationId}/fert-spreading-declarations/{partyId}/aggiorna-impianti-n-pua
	   		httpServer.createContext("/mock-pua-app/master/v1/applications/123/aggiorna-impianti-n-pua", 
    				exchange -> {
    					
    					exchange.getResponseHeaders().add("Content-Type", "application/json");
    					
    					// SET ERROR RESPONSE 305
    					exchange.sendResponseHeaders(305, 1);
    					 
    				});

    	} catch (Exception e) {
    		fail("ERROR IN testSuccessfulExecution_with_response_http_error_305", e);
    	}
    	 
    	try {
			
    		aggiornaImpiantiNPua.doExecute(processData, env);
    		
		} catch (IllegalStateException e) {
			
			// SUCCEDED: waited IllegalStateException with HTTP ERROR 305
			
		}catch (Exception e) {
    		fail("ERROR IN testSuccessfulExecution_with_response_http_error_305", e);
    	}
    }
}
