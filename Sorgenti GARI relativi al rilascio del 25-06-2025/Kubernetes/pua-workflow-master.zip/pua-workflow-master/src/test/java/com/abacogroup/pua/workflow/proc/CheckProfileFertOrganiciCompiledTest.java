package com.abacogroup.pua.workflow.proc;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.v2.procedures.CheckFormsAreCompiledProcedure;
import com.abacogroup.pua.workflow.util.Const;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage.Type;
import com.abacogroup.workflow.sdk.profiles.ProfilesManager;

/**
 * 
 * @author Emanuele Crocilla
 *
 */
@ExtendWith(MockitoExtension.class)
class CheckProfileFertOrganiciCompiledTest {
	
	@Mock
	private ProcessData processData;

	@Mock
	private ProfilesManager profilesManager;

	@Mock
	private IAgriProcedureEnvironment env;

    @Test
    void testCheckProfileFertOrganiciCompiled_OK() throws Exception {
    	
    	CheckProfileFertOrganiciCompiled proc = new CheckProfileFertOrganiciCompiled();
    	  
        // Configura il comportamento dei mock
        when(processData.getProfilesManager()).thenReturn(profilesManager);
        when(profilesManager.haveAllOf(Const.ALLEVAMENTI)).thenReturn(true);
        
        Field processDataField = proc.getClass().getSuperclass().getSuperclass().getDeclaredField("processData");
        processDataField.setAccessible(true);
        processDataField.set(proc, processData);
        
        List<String> profiles = proc.getFormCodesToCheck();
         
        assertThat(profiles, containsInAnyOrder(
				 Const.PUA_DICHIARAZIONE_CON_FERTILIZZANTI));

        Set<String> allowedProfiles = proc.getAllowedProfiles();
        assertThat(allowedProfiles, containsInAnyOrder(Const.FERT_ORGANICI));
        
        WorkflowMessage workflowMessage = proc.createMessage( Const.PUA_DICHIARAZIONE_CON_FERTILIZZANTI, 
        		Const.PUA_DICHIARAZIONE_CON_FERTILIZZANTI, processData, env);
        
        assertThat(workflowMessage.getCode(), containsString(Const.PUA_DICHIARAZIONE_CON_FERTILIZZANTI_INCOMPLETED));
        assertThat(workflowMessage.getDescription(), containsString("Dichiarazione con fertilizzanti organici incompleta"));
        assertEquals(workflowMessage.getType(), Type.ERROR);
         
    }
    
    @Test
    void testCheckProfileFertOrganiciCompiled_KO() {
    	
    	CheckProfileFertOrganiciCompiled proc = new CheckProfileFertOrganiciCompiled();
        
        WorkflowMessage workflowMessage = proc.createMessage( Const.PUA_DICHIARAZIONE_CON_FERTILIZZANTI, 
        		Const.PUA_DICHIARAZIONE_CON_FERTILIZZANTI, processData, env);
        
        assertNotEquals(workflowMessage.getCode(), Const.PUA_FINAL_DECLARATION_INCOMPLETED);
    }
 
}
