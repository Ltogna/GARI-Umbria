package com.abacogroup.pua.workflow.proc;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationProfilePublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import com.abacogroup.applicationworkflowsdk.v2.procedures.ApplicationProcedure;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.pua.workflow.model.TipologiaDichirazione;
import com.abacogroup.pua.workflow.util.Const;
import com.abacogroup.workflow.sdk.beans.ProcessData;

public class ComputeAndSetProfiles extends ApplicationProcedure {

    private static Set<String> allowedYearProfiles;

    @Override
    protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {
        TipologiaDichirazione formData = processData.<TipologiaDichirazione>getGlobalVar(TipologiaDichirazione.KEY)
                .orElseThrow();

        var yearProfiles = getYearProfiles(processData, env);

        
        var profiles = computeProfiles(formData, yearProfiles);
        applyNewApplicationProfiles(profiles, processData, env);
    }

    // Visible for testing
    List<String> computeProfiles(TipologiaDichirazione formData, Set<String> yearProfiles) {
        List<String> profiles = new ArrayList<>();

        if (formData.isOrganicFertilizers()) {
            profiles.add(Const.FERT_ORGANICI);
            if (formData.isLivestocks()) {
                profiles.add(Const.ALLEVAMENTI);
            }
        } else {
            profiles.add(Const.SEMPLICE);
        }

        // Add years profiles
        String year = "Y" + formData.getYear();
        if (!yearProfiles.contains(year)) {
            throw new IllegalStateException("There is no profile for year " + formData.getYear());
        }

        profiles.add(year);

        return profiles;
    }

    private void applyNewApplicationProfiles(List<String> profiles, ProcessData processData, IAgriProcedureEnvironment env) {
        List<ApplicationProfilePublicDTO> allCurrentApplicationProfiles = env.getApplicationProfilesService()
                .getAllApplicationProfiles(processData, processData.getTenantId(), getApplicationsWorkflowParams().getApplicationId());
        for(var applicationProfile: allCurrentApplicationProfiles){
            env.getApplicationProfilesService().deleteApplicationProfile(processData.getTenantId(), getApplicationsWorkflowParams().getApplicationId(),
                    applicationProfile.getProfileCode(), (User) processData.getAuthContext().getPrincipal());
        }
        env.getApplicationProfilesService()
                .upsertApplicationProfiles(processData.getTenantId(), getApplicationsWorkflowParams().getApplicationId(), profiles,
                        (User) processData.getAuthContext().getPrincipal());
    }

    private synchronized Set<String> getYearProfiles(ProcessData processData, IAgriProcedureEnvironment env) {
        if (allowedYearProfiles != null) {
            return allowedYearProfiles;
        }

        var params = getApplicationsWorkflowParams();
        List<ModuleProfileDTO> allProfiles = env.getApplicationProfilesService().getAllModuleProfiles(processData.getTenantId(),
                params.getApplicationId(), params.getLocale());

        return allProfiles.stream()
                .map(ModuleProfileDTO::getProfileCode)
                .filter(p -> p.startsWith("Y") && p.length() == 5)
                .filter(p -> {
                    try {
                        Integer.valueOf(p.substring(1));
                        return true;
                    } catch (NumberFormatException e) {
                        return false;
                    }
                })
                .collect(Collectors.toSet());
    }
}
