package com.abacogroup.pua.workflow.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Value;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
 
/**
 * JsonUtils variant 2
 * 
 * @author Emanuele Crocilla
 *
 */
public final class JsonUtils {
	
	@SuppressWarnings("unused")
	private class MyJsonMapper extends ObjectMapper {
		
		private static final long serialVersionUID = 1L;

		public MyJsonMapper() {
		}
		
		public MyJsonMapper(Include include) {
			this.setSerializationInclusion(include.getValue());
		}
 
		/**
		 * 
		 * @param writeNullMapValues determines whether Map entries with null values are
	     * to be serialized (true) or not (false).
	     * It is enabled by default.
	     * 
		 */
		public MyJsonMapper(boolean writeNullMapValues) {
			 
			this.enable(SerializationFeature.INDENT_OUTPUT);
			
			if (writeNullMapValues) {
				this.setDefaultPropertyInclusion(JsonInclude.Include.ALWAYS);
			}
			else {
				this.configOverride(Map.class).setInclude(
						Value.construct(JsonInclude.Include.NON_NULL, JsonInclude.Include.NON_NULL));
			}

		}
	}
	
	/** Only static methods exposed outside */
	private JsonUtils() {
	}

	public static String convertToJson(Object object) throws JsonProcessingException {
		return convertToJson(object, false);
	}
	
	public static String convertToJson(Object object, boolean prettyPrint) throws JsonProcessingException {
		//Convert object to JSON string
		if(!prettyPrint)
			return new JsonUtils().new MyJsonMapper().writeValueAsString(object);

		//Convert object to JSON string and pretty print
		else
			return new JsonUtils().new MyJsonMapper().writerWithDefaultPrettyPrinter().writeValueAsString(object);
	}

	public static ObjectNode convertToJsonObject(Object object) throws JsonProcessingException  {
		String jsonAsString = convertToJson(object);
		return fromJsonAsStringToObjectNode(jsonAsString);
	}

	public static Map<String, Object> jsonToMap(ObjectNode json) throws JsonProcessingException {
		Map<String, Object> retMap = new HashMap<>();

		if(json != null && !json.isNull()) {
			retMap = toMap(json);
		}
		return retMap;
	}
	
	public static Map<String, Object> jsonToMap(ObjectNode json, boolean skipNullValues) throws JsonProcessingException {
		Map<String, Object> retMap = new HashMap<>();

		if(json != null && !json.isNull()) {
			retMap = toMap(json, skipNullValues);
		}
		return retMap;
	}

	public static Map<String, Object> toMap(ObjectNode object) throws JsonProcessingException {
		return toMap(object, false);
	}
	
	public static Map<String, Object> toMap(ObjectNode object, boolean skipNullValues) throws JsonProcessingException {
		Map<String, Object> map = new HashMap<>();

		Iterator<String> keysItr = object.fieldNames();
		while(keysItr.hasNext()) {
			String key = keysItr.next();
			JsonNode valueNode = object.get(key);
			Object value = getNodeValue(valueNode);
			
			if (!skipNullValues || (value != null && !valueNode.isNull())) {
				
				if(valueNode.isArray()) {
					value = toList((ArrayNode) valueNode, skipNullValues);
				}

				else if(valueNode.isObject()) {
					value = toMap((ObjectNode) valueNode, skipNullValues);
				}
				map.put(key, value);
			}
		}
		return map;
	}

	public static <T> Map<String, T> toMap(ObjectNode object, Class<T> t) throws JsonProcessingException {
		Map<String, T> map = new HashMap<>();

		Iterator<String> keysItr = object.fieldNames();
		while(keysItr.hasNext()) {
			String key = keysItr.next();
			JsonNode valueNode = object.get(key);
			Object value = getNodeValue(valueNode);

			if(valueNode.isArray()) {
				value = toList((ArrayNode) valueNode, t);
			}

			else if(valueNode.isObject()) {
				value = toMap((ObjectNode) valueNode, t);
			}
			map.put(key, (T)value);
		}
		return map;
	}

	public static List<Object> toList(ArrayNode array) throws JsonProcessingException {
		List<Object> list = new ArrayList<Object>();
		for(int i = 0; i < array.size(); i++) {
			JsonNode valueNode = array.get(i);
			Object value = getNodeValue(valueNode);
			
			if(valueNode.isArray()) {
				value = toList((ArrayNode) valueNode);
			}

			else if(valueNode.isObject()) {
				value = toMap((ObjectNode) valueNode);
			}
			list.add(value);
		}
		return list;
	}
	
	public static List<Object> toList(ArrayNode array, boolean skipNullValues) throws JsonProcessingException {
		List<Object> list = new ArrayList<Object>();

		for(int i = 0; i < array.size(); i++) {
			
			JsonNode valueNode = array.get(i);
			Object value = getNodeValue(valueNode);
			
			if (!skipNullValues || (value != null && !valueNode.isNull())) {
				
				if(valueNode.isArray()) {
					value = toList((ArrayNode) valueNode, skipNullValues);
				}

				else if(valueNode.isObject()) {
					value = toMap((ObjectNode) valueNode, skipNullValues);
				}
				list.add(value);
				
			}
		}

		return list;
	}

	public static <T> List<T> toList(ArrayNode array, Class<T> t) throws JsonProcessingException {
		List<T> list = new ArrayList<T>();
		for(int i = 0; i < array.size(); i++) {
			JsonNode valueNode = array.get(i);
			Object value = getNodeValue(valueNode);
			
			if(valueNode.isArray()) {
				value = toList((ArrayNode) valueNode, t);
			}

			else if(valueNode.isObject()) {
				value = toMap((ObjectNode) valueNode, t);
			}
			list.add((T)value);
		}
		return list;
	}

	public static ObjectNode fromJsonAsStringToObjectNode(String jsonAsString) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		return (ObjectNode) mapper.readTree(jsonAsString);
	}

	public static ArrayNode fromJsonAsStringToArrayNode(String jsonAsString) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		return (ArrayNode) mapper.readTree(jsonAsString);
	}

	public static <T> T fromJsonAsStringToObject(String jsonAsString, Class<T> clazz) throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		 
		return objectMapper.readValue(jsonAsString, clazz);
	}

	public static <T> T extractField(String json, String fieldName, T defaultValue) {

		try {
			if(json == null) return defaultValue;
			JsonNode root = new ObjectMapper().readTree(json);
			return extractField(root, fieldName, defaultValue);

		} catch (Exception e) {
			return defaultValue;
		}

	}

	@SuppressWarnings("unchecked")
	public static <T> T extractField(JsonNode root, String fieldName, T defaultValue) {

		try {
			JsonNode field = root.get(fieldName);
			if(field != null) {
				if (field.isNull() || field.isTextual() && field.asText().equals("null")) return defaultValue;
				Object value = getNodeValue(field);
				return (T) value;
			} 
			else return defaultValue;

		} catch (Exception e) {
			return defaultValue;
		}

	}

	private static Object getNodeValue(final JsonNode node) {
		if (node.isInt())
			return node.asInt();

		if (node.isLong())
			return node.asLong();
		
		if (node.isDouble() || node.isFloat())
			return node.asDouble();

		if (node.isBoolean())
			return node.asBoolean();

		if (node.isObject()) {
			Map<String, Object> parameters = new LinkedHashMap<>();

			for (Iterator<String> iterator = node.fieldNames(); iterator.hasNext();) {
				String field = iterator.next();

				parameters.put(field, getNodeValue(node.get(field)));
			}

			return parameters;
		}

		if (node.isArray()){

			List<Object> list = new ArrayList<>();

			for (JsonNode jsonNode : node) {

				list.add(getNodeValue(jsonNode));
			}

			return list;

		}
		
		if (node.isNull()) {
			return null;
		}

		return node.asText();
	}

	public static <T> T extractFieldOrNull(String json, String fieldName) {
		return extractField(json, fieldName, null);
	}

	public static MapWrapper newMapWrapperInstance() {
		return new JsonUtils().new MapWrapper();
	}

	public static MapWrapper newMapWrapperInstance(String k, Object v) {
		return new JsonUtils().new MapWrapper().put(k, v);
	}

	public class MapWrapper {
		private MapWrapper(){}
		private Map<String, Object> map = new LinkedHashMap<>();
		public MapWrapper put(String k, Object v) { map.put(k, v); return this; }
		public String toJson() { return JsonUtils.toJson(map); }
	}
	
	public static String toJson(final Map<String, Object> map) {

    	try{
    		ObjectMapper mapper = new ObjectMapper();
    		ObjectNode parametersNode = JsonNodeFactory.instance.objectNode();
    		
    		for (Map.Entry<String, Object> entry : map.entrySet()) {
    			String key = entry.getKey();
    			Object val = entry.getValue();
    			parametersNode.set(key, mapper.valueToTree(val));
			}

    		return parametersNode.toString();
    	}
    	catch (Exception e) {
    		return null;
    	}
    }
	
	public static String beautify(String json) throws IOException {
	    ObjectMapper mapper = new ObjectMapper();
	    Object obj = mapper.readValue(json, Object.class);
	    return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(obj);
	}
	
	public enum Include {
		
		/**
         * Value that indicates that property is to be always included,
         * independent of value of the property.
         */
		ALWAYS(com.fasterxml.jackson.annotation.JsonInclude.Include.ALWAYS), 
		
		 /**
         * Meaning of this setting depends on context: whether annotation is
         * specified for POJO type (class), or not. In latter case annotation
         * is either used as the global default, or as property override.
         *<p>
         * When used for a POJO, definition is that only values that differ from
         * the default values of POJO properties are included. This is done
         * by creating an instance of POJO using zero-argument constructor,
         * and accessing property values: value is used as the default value
         * by using <code>equals()</code> method, except for the case where property
         * has `null` value in which straight null check is used.
         *<p>
         * When NOT used for a POJO (that is, as a global default, or as property
         * override), definition is such that:
         *<ul>
         * <li>All values considered "empty" (as per {@link #NON_EMPTY}) are excluded</li>
         * <li>Primitive/wrapper default values are excluded</li>
         * <li>Date/time values that have timestamp (`long` value of milliseconds since
         *   epoch, see {@link java.util.Date}) of `0L` are excluded</li>
         * </ul>
         */
		NON_DEFAULT(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_DEFAULT), 
		
		/**
         * Value that indicates that only properties with null value,
         * or what is considered empty, are not to be included.
         * Definition of emptiness is data type specific; see below
         * for details on actual handling.
         *<p>
         * Default emptiness for all types includes:
         *<ul>
         * <li><code>Null</code> values.</li>
         * <li>"Absent" values (see {@link #NON_ABSENT})</li>
         *</ul>
         * so that as baseline, "empty" set includes values that would be
         * excluded by both {@link #NON_NULL} and {@link #NON_ABSENT}.
         * <br />
         * Additionally following types have additional empty values:
         *<ul>
         * <li>For {@link java.util.Collection}s and {@link java.util.Map}s,
         *    method <code>isEmpty()</code> is called;
         *   </li>
         * <li>For Java arrays, empty arrays are ones with length of 0
         *   </li>
         * <li>For Java {@link java.lang.String}s, <code>length()</code> is called,
         *   and return value of 0 indicates empty String (note that <code>String.isEmpty()</code>
         *   was added in Java 1.6 and as such can not be used by Jackson
         *   </li>
         * </ul>
         *  and for other types, null values are excluded but other exclusions (if any).
         *<p>
         * Note that this default handling can be overridden by custom
         * <code>JsonSerializer</code> implementation: if method <code>isEmpty()</code>
         * is overridden, it will be called to see if non-null values are
         * considered empty (null is always considered empty).
         *<p>
         * Compatibility note: Jackson 2.6 included a wider range of "empty" values than
         * either earlier (up to 2.5) or later (2.7 and beyond) types; specifically:
         *<ul>
         * <li>Default values of primitive types (like <code>0</code> for `int`/`java.lang.Integer`
         *  and `false` for `bool`/`Boolean`)
         *  </li>
         * <li>Timestamp 0 for date/time types
         *  </li>
         *</ul>
         * With 2.7, definition has been tightened back to only containing types explained
         * above (null, absent, empty String, empty containers), and now
         * extended definition may be specified using {@link #NON_DEFAULT}.
         */
		NON_EMPTY(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY), 
		
		 /**
         * Value that indicates that only properties with non-null
         * values are to be included.
         */
		NON_NULL(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL), 
		
		 /**
         * Value that indicates that properties are included unless their value
         * is:
         *<ul>
         *  <li>null</li>
         *  <li>"absent" value of a referential type (like Java 8 `Optional`, or
         *     {link java.utl.concurrent.atomic.AtomicReference}); that is, something
         *     that would not deference to a non-null value.
         * </ul>
         * This option is mostly used to work with "Optional"s (Java 8, Guava).
         *
         */
		NON_ABSENT(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_ABSENT);
		
		private com.fasterxml.jackson.annotation.JsonInclude.Include value;
		
		private Include(com.fasterxml.jackson.annotation.JsonInclude.Include value) {
			this.value = value;
		}
		
		public com.fasterxml.jackson.annotation.JsonInclude.Include getValue() {
			return this.value;
		}
	}
}