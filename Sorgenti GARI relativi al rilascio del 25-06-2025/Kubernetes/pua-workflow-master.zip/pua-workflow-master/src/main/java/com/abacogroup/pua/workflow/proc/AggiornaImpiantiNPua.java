package com.abacogroup.pua.workflow.proc;

import java.util.Optional;

import com.abacogroup.applicationworkflowsdk.environment.IAgriProcedureEnvironment;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.applicationworkflowsdk.v2.procedures.ApplicationProcedure;
import com.abacogroup.pua.workflow.model.AgronicaResponse;
import com.abacogroup.pua.workflow.util.JsonUtils;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.sdk.proc.StopTransitionException;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;


/**
 * 
 * @author Emanuele Crocilla
 *
 */
@Slf4j
public class AggiornaImpiantiNPua extends ApplicationProcedure {

    @Override
    protected void doExecute(ProcessData processData, IAgriProcedureEnvironment env) throws Exception {
    	
    	log.debug("[pua-workflow] starting with AggiornaImpiantiNPua.doExecute..");
    	
    	log.debug("[pua-workflow] Check if the procedure AggiornaImpiantiNPua has to be executed " +
    			"considering the value of 'call.aggiorna.impianti.npua' environment property");
    	
    	// retrieve the value of env property "call.aggiorna.impianti.npua" 
    	boolean callAggiornaImpiantiNPua = mustCallAggiornaImpiantiNPua(env);
    	
    	log.debug("[pua-workflow] callAggiornaImpiantiNPua value: {}", callAggiornaImpiantiNPua);
    	
    	if (callAggiornaImpiantiNPua) {
    		
    		log.debug("[pua-workflow] executing procedure AggiornaImpiantiNPua because the value of " +
    				"environment property 'call.aggiorna.impianti.npua' is 'TRUE'");

        	ApplicationsWorkflowParams applicationsWorkflowParams = 
        			(ApplicationsWorkflowParams)processData.getGlobalVar("workflowParams").orElseThrow();
        	
        	Long applicationId = applicationsWorkflowParams.getApplicationId();
        	
        	log.debug("[pua-workflow] using applicationId: {} ", applicationId);
        	
        	String tenant = applicationsWorkflowParams.getTenant();
        	
        	log.debug("[pua-workflow] using tenant: {} ", tenant);
        	
        	// will be send for both "fertilizzanti chimici" and "fertilizzanti organici"
        	sendData(processData, env, applicationId, tenant);

        	/**
        	List<ApplicationProfilePublicDTO> profiles = 
        			env.getApplicationProfilesService().getAllApplicationProfiles(processData, tenant, applicationId);
        	
        	log.debug("[pua-workflow] profiles value: {} ", profiles);
        	
        	List<ApplicationProfilePublicDTO>  filteredProfiles = profiles.stream().filter(e -> 
        				Const.SEMPLICE.equals(e.getProfileCode()) ||
        				Const.FERT_ORGANICI.equals(e.getProfileCode()) ||
        				Const.ALLEVAMENTI.equals(e.getProfileCode())).toList();
        	
        	log.debug("[pua-workflow] filteredProfiles value: {} ", filteredProfiles);
        	
        	ApplicationProfilePublicDTO allevamentiProfile = 
        			filteredProfiles.stream().filter(e -> Const.ALLEVAMENTI.equals(e.getProfileCode())).findFirst().orElseGet(null);
        	
        	log.debug("[pua-workflow] allevamentiProfile value: {} ", allevamentiProfile);
        	 
        	// execution must be performed ONLY for: 
        	//  - SEMPLICE profile 
        	//  - FERT_ORGANICI profile (NOT for FERT_ORGANICI + ALLEVAMENTI)
    		if(filteredProfiles.size() > 0 && allevamentiProfile == null) {
    			sendData(processData, env, applicationId, tenant);
    		}
        	*/
		}
    	else {
    		log.debug("[pua-workflow] The procedure AggiornaImpiantiNPua has not be executed because the value of 'call.aggiorna.impianti.npua' environment property is 'FALSE'");
    	}
    	
    	log.debug("[pua-workflow] ..end of AggiornaImpiantiNPua.doExecute");
    }
	
	private void sendData(ProcessData processData, IAgriProcedureEnvironment env, Long applicationId, String tenant) throws Exception {
		
		log.debug("[pua-workflow] AggiornaImpiantiNPua started");
        String url = env.getProperty("puaAppFormsUrl").orElseThrow().toString();

        Client client = env.getJerseyClient().orElseThrow();

        log.debug("[pua-workflow] Preparing WebTarget");
        
        WebTarget target = getWebTarget(processData, tenant, applicationId, client, url);
        
        try (Response response = target.request(MediaType.APPLICATION_JSON).get()) {

        	int status = response.getStatus();
        	log.debug("[pua-workflow] Response status: {}", status);

        	if (status < 200 || status > 299) {

        		log.error("[pua-workflow] Bad response status: {}", status);
        		processData.getWorkflowMessages()
        		.add(new WorkflowMessage("GIAS_AGGIORNA_IMPIANTI_COMUNICATION_FAILED",
        				"Si è verificato un errore imprevisto nell'aggiornamento degli impianti in GIAS. "
        						+ "Si prega di riprovare più tardi", WorkflowMessage.Type.ERROR));

        		throw new StopTransitionException();
        	}

        	AgronicaResponse<?> agronicaResponse = response.readEntity(AgronicaResponse.class);
        	String agronicaResponseMessage = agronicaResponse.getMessage();
        	String agronicaResponseError = agronicaResponse.getErrore();

        	log.debug("AgronicaResponse returned message = |{}| ", agronicaResponseMessage);
        	log.debug("AgronicaResponse returned error = |{}| ", agronicaResponseError);
        	
        	if (log.isDebugEnabled()) {
        		log.debug("The response from Agronica (Aggiorna_Impianti_N_Pua) is: \n" + 
        				JsonUtils.convertToJson(agronicaResponse, true));
        	}

        	if (agronicaResponseError  != null && !agronicaResponseError.isBlank()) {
        		processData.getWorkflowMessages()
        		.add(new WorkflowMessage("GIAS_AGGIORNA_IMPIANTI_COMUNICATION_FAILED",
        				agronicaResponseError, WorkflowMessage.Type.ERROR));

        		log.debug("[pua-workflow] Send data to 'aggiorna impianti-N-Pua' "
        				+ "but Agronica answred with this error: " + agronicaResponseError);
        	}
        	else if(log.isDebugEnabled()){
        		
        		log.debug("[pua-workflow] Successfully wrote data, "
        				+ "writing operation of 'aggiorna impianti-N-Pua completed. "
        				+ "Agronica answred with this message: " + agronicaResponseMessage);
        	}
        }
        catch (Exception e) {
			log.error("Error during import of AggiornaImpiantiNPua to NewAgri ");
			throw e;
		}
	}
	
	private WebTarget getWebTarget(ProcessData processData, String tenant, Long applicationId, Client client, String url) {
		return processData.getAuthContext()
                .getAuthenticatedWebTarget(client, url)
                .path(tenant)
                .path("/v1/applications/")
                .path(String.valueOf(applicationId))
                .path("aggiorna-impianti-n-pua");
	}
	
	private boolean mustCallAggiornaImpiantiNPua(IAgriProcedureEnvironment env) throws Exception {
    	
    	log.debug("[pua-workflow] Attempting to retrieve 'call.aggiorna.impianti.npua' property");
    	
    	// retrieve the value of env property "call.aggiorna.impianti.npua" 
    	try {
    		Optional<String> prop = env.getProperty("call.aggiorna.impianti.npua");
    		String propVal = prop.orElse("false");
    		log.debug("[pua-workflow] Vaue of 'call.aggiorna.impianti.npua' property: '{}'", propVal);
        	return "true".equalsIgnoreCase(propVal.trim());
		} 
    	catch (Exception e) {
			String systemErrorMsg = "[pua-workflow] "
					+ "Unable to fetch value of the environment property 'call.aggiorna.impianti.npua', " 
					+ "so the procedure SendSpreadingComunicationToGias will not be executed";
			
			log.error(systemErrorMsg, e);
			
			throw new Exception(systemErrorMsg, e);
		}
	}
}

