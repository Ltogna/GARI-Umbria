package com.abacogroup.pua.workflow.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * 
 * @author Emanuele Crocilla
 *
 * @param <T>
 * 
 * 
 * 
 * 
 * 
 */
@Data
public class AgronicaResponse<T> {
	
	@JsonProperty("message")
	private String message;

	@JsonProperty("errore")
	private String errore;

	@JsonProperty("dati")
	private T dati;
 
}
