#!/bin/sh
umask 0002 && \
java -XX:MaxRAMPercentage=50 -jar ${project.build.finalName}.jar
