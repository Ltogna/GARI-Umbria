package com.abacogroup.apigateway.controller.model.envoy;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;

import com.abacogroup.apigateway.controller.model.ServiceRouteSpec.DirectResponse;
import com.abacogroup.apigateway.controller.model.ServiceRouteSpec.Match;
import com.abacogroup.apigateway.controller.model.ServiceRouteSpec.Route;
import com.abacogroup.apigateway.controller.model.ServiceRouteSpec.RouteDefinition;
import com.abacogroup.apigateway.controller.model.ServiceRouteSpec.UpgradeConfigs;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Value;

@Data
public class ConnectionManagerTypedDefnition implements TypedConfig {

	private String stat_prefix = "abaco_apigateway";
	private List<HttpFilter> http_filters;
	private RouteConfig route_config;

	public ConnectionManagerTypedDefnition(List<HttpFilter> filters, List<VirtualHost> virtualhosts, Header cspHeader) {
		http_filters = filters;
		route_config = new RouteConfig(virtualhosts, cspHeader);
	}

	@Override
	public String getAtType() {
		return "type.googleapis.com/envoy.extensions.filters.network.http_connection_manager.v3.HttpConnectionManager";
	}

	@Data
	@AllArgsConstructor
	public static class HttpFilter {
		private String name;
		private TypedConfig typed_config;
	}

	@Data
	public static class RouteConfig {
		private String name = "k8s_route";
		private List<Header> response_headers_to_add;
		private List<VirtualHost> virtual_hosts;

		public RouteConfig(List<VirtualHost> virtual_hosts, Header cspHeader) {
			this.virtual_hosts = virtual_hosts;

			response_headers_to_add = new ArrayList<>();
			if (cspHeader != null) {
				response_headers_to_add.add(cspHeader);
			}
			response_headers_to_add.add(new Header("Referrer-Policy", "strict-origin"));
			response_headers_to_add.add(new Header("Strict-Transport-Security", "max-age=31536000"));
			response_headers_to_add.add(new Header("X-Content-Type-Options", "nosniff"));
			response_headers_to_add.add(new Header("X-Frame-Options", "SAMEORIGIN"));
			response_headers_to_add.add(new Header("X-Permitted-Cross-Domain-Policies", "none"));
		}
	}

	@Value
	public static class Header {
		private Map<String, String> header;

		public Header(String key, String value) {
			header = Map.of("key", key, "value", value);
		}
	}

	@Data
	@JsonInclude(Include.NON_NULL)
	public static class VirtualHost {
		private String name = "k8s_service";
		private List<String> domains;
		private Map<String, TypedConfig> typed_per_filter_config;
		private ArrayList<EnvoyRouteDefinition> routes = new ArrayList<>();

		public VirtualHost(String domain) {
			domains = List.of(domain);
		}

		public void putTypedPerFilterConfig(String name, TypedConfig config) {
			if (config == null) {
				return;
			}
			Objects.requireNonNull(name);

			if (typed_per_filter_config == null) {
				typed_per_filter_config = new TreeMap<>();
			}

			typed_per_filter_config.put(name, config);
		}
	}

	@Data
	@JsonInclude(Include.NON_NULL)
	public static class EnvoyRouteDefinition implements Comparable<EnvoyRouteDefinition> {
		private EnvoyMatch match;
		private EnvoyRoute route;
		private EnvoyDirectResponse direct_response;
		private DisableAuthPerRoute typed_per_filter_config;

		public EnvoyRouteDefinition(RouteDefinition spec) {
			this.match = new EnvoyMatch(spec.getMatch());

			Route route = spec.getRoute();
			if (route.getClusterId() != null) {
				this.route = new EnvoyRoute(route.getClusterId(), route.getPrefix_rewrite(), route.getRegex_rewrite(),
						route.getTimeout(), EnvoyUpgradeConfigs.buildFrom(route.getUpgrade_configs()));
				if (route.isDisable_auth()) {
					typed_per_filter_config = new DisableAuthPerRoute();
				}
			}

			this.direct_response = EnvoyDirectResponse.buildFrom(route.getDirect_response());
		}

		@Override
		public int compareTo(EnvoyRouteDefinition other) {
			return match.compareTo(other.match);
		}
	}

	@Data
	@JsonInclude(Include.NON_NULL)
	public static class EnvoyMatch implements Comparable<EnvoyMatch> {
		private String path_separated_prefix;
		private String prefix;
		private String path;
		private Map<String, Object> safe_regex;

		public EnvoyMatch(Match match) {
			this.path_separated_prefix = match.getPath_separated_prefix();
			this.prefix = match.getPrefix();
			this.path = match.getPath();
			if (match.getSafe_regex() != null && !match.getSafe_regex().isBlank()) {
				/*
				 * safe_regex = Map.of("google_re2", EMPTY_MAP, "regex", match.getSafe_regex());
				 */
				safe_regex = Map.of("regex", match.getSafe_regex());
			}
		}

		@Override
		public int compareTo(EnvoyMatch other) {
			// We return -cmp to have longest paths first
			// because envoy stops routes processing at first match

			int cmp = nvl(path).compareTo(nvl(other.path));
			if (cmp != 0) {
				return -cmp;
			}

			cmp = nvl(path_separated_prefix).compareTo(nvl(other.path_separated_prefix));
			if (cmp != 0) {
				return -cmp;
			}

			String myRegex = safe_regex == null ? "" : nvl((String) safe_regex.get("regex"));
			String otherRegex = other.safe_regex == null ? "" : nvl((String) other.safe_regex.get("regex"));

			cmp = myRegex.length() - otherRegex.length();
			if (cmp != 0) {
				return -cmp;
			}

			return -(nvl(prefix).compareTo(nvl(other.prefix)));
		}

		private String nvl(String str) {
			return str == null ? "" : str;
		}
	}

	@Data
	@JsonInclude(Include.NON_NULL)
	public static class EnvoyDirectResponse {
		private Integer status;
		private Map<String, Object> body;

		public static EnvoyDirectResponse buildFrom(DirectResponse response) {
			if (response == null) {
				return null;
			}

			EnvoyDirectResponse ret = new EnvoyDirectResponse();
			ret.status = response.getStatus();

			if (response.getInline_string() != null) {
				ret.body = Map.of("inline_string", response.getInline_string());
			}

			return ret;
		}
	}

	@Data
	@JsonInclude(Include.NON_NULL)
	public static class EnvoyUpgradeConfigs {
		private String upgrade_type;

		public static EnvoyUpgradeConfigs buildFrom(UpgradeConfigs upgradeConfig) {
			if (upgradeConfig == null) {
				return null;
			}
			EnvoyUpgradeConfigs ret = new EnvoyUpgradeConfigs();
			ret.upgrade_type = upgradeConfig.getUpgrade_type();
			return ret;
		}
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@JsonInclude(Include.NON_NULL)
	public static class EnvoyRoute {
		private String cluster;
		private String prefix_rewrite;
		private String regex_rewrite;
		private String timeout;
		private EnvoyUpgradeConfigs upgrade_configs;

		@JsonProperty("idle_timeout")
		public String getIdleTimeout() {
			return timeout;
		}
	}

	public static class DisableAuthPerRoute {
		@JsonProperty("envoy.filters.http.ext_authz")
		private Map<String, Object> extAuthz = Map.of("@type",
				"type.googleapis.com/envoy.extensions.filters.http.ext_authz.v3.ExtAuthzPerRoute", "disabled", true);
	}

}
