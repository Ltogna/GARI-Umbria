package com.abacogroup.apigateway.controller.model;

import io.fabric8.kubernetes.api.model.Namespaced;
import io.fabric8.kubernetes.client.CustomResource;
import io.fabric8.kubernetes.model.annotation.Group;
import io.fabric8.kubernetes.model.annotation.Plural;
import io.fabric8.kubernetes.model.annotation.Version;

@Version("v1")
@Group("apigateway.abacogroup.com")
@Plural("contentsecuritypolicies")
public class ContentSecurityPolicy extends CustomResource<ContentSecurityPolicySpec, Void> implements Namespaced {
	private static final long serialVersionUID = 4263774843525933882L;
}
