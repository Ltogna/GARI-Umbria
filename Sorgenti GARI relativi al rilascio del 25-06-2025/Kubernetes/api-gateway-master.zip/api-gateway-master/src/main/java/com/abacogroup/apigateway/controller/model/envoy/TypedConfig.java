package com.abacogroup.apigateway.controller.model.envoy;

import com.fasterxml.jackson.annotation.JsonProperty;

public interface TypedConfig {
	@JsonProperty("@type")
	public String getAtType();
}
