package com.abacogroup.apigateway.controller.model.envoy;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
public class EnvoyLds {

	private List<Resource> resources;

	@Data
	@Builder
	public static class Resource {
		@JsonProperty("@type")
		private String type;
		private String name;
		private Address address;
		private List<FilterChain> filter_chains;
	}

	@Data
	@AllArgsConstructor
	public static class Address {
		private SocketAddress socket_address;
	}

	@Data
	@AllArgsConstructor
	public static final class SocketAddress {
		private String address;
		private int port_value;
	}

	@Data
	@AllArgsConstructor
	public static class FilterChain {
		private List<Filter> filters;
	}

	@Data
	@AllArgsConstructor
	public static class Filter {
		private String name;
		private TypedConfig typed_config;
	}

}
