package com.abacogroup.apigateway.controller.model.envoy.httpfilter;

import com.abacogroup.apigateway.controller.model.envoy.TypedConfig;

import lombok.Data;

@Data
public class GizpCompressor implements TypedConfig {

	private GzipCompressorLibrary compressor_library = new GzipCompressorLibrary();
	private boolean disable_on_etag_header = true;

	@Override
	public String getAtType() {
		return "type.googleapis.com/envoy.extensions.filters.http.compressor.v3.Compressor";
	}

	@Data
	public static class GzipCompressorLibrary {
		// See
		// https://www.envoyproxy.io/docs/envoy/latest/api-v3/extensions/filters/http/compressor/v3/compressor.proto#extensions-filters-http-compressor-v3-compressor
		// we do not allow to change defaults but it could be useful to do so in the
		// future

		private String name = "gzip_compressor";
		private TypedConfig typed_config = new TypedConfig() {
			@Override
			public String getAtType() {
				return "type.googleapis.com/envoy.extensions.compression.gzip.compressor.v3.Gzip";
			}
		};
	}
}
