package com.abacogroup.apigateway.controller.model.envoy.httpfilter;

import java.util.List;

import com.abacogroup.apigateway.controller.model.ExternalAuthSpec;
import com.abacogroup.apigateway.controller.model.envoy.TypedConfig;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
public class ExtAuthz implements TypedConfig {
	@Builder.Default
	private WithRequestBody with_request_body = new WithRequestBody();

	private HttpService http_service;

	@Builder.Default
	private AllowedHeaders allowed_headers = new AllowedHeaders(List.of(AllowedHeaderPattern.builder().safe_regex(new SafeRegex(".+")).build()));

	@Builder.Default
	private boolean failure_mode_allow = false;

	@Builder.Default
	private boolean include_peer_certificate = true;

	@Builder.Default
	private String transport_api_version = "V3";

	@Override
	public String getAtType() {
		return "type.googleapis.com/envoy.extensions.filters.http.ext_authz.v3.ExtAuthz";
	}

	@Data
	public static class WithRequestBody {
		private int max_request_bytes = 1024;
		private boolean allow_partial_message = true;
		// private boolean pack_as_bytes = false;
	}

	@Data
	public static class HttpService {
		private ServerUri server_uri;

		// private AuthorizationRequest authorization_request = new AuthorizationRequest(
		// new AllowedHeaders(List.of(AllowedHeaderPattern.builder().safe_regex(new SafeRegex(".+")).build())));

		private AuthorizationResponse authorization_response = new AuthorizationResponse(
				new AllowedHeaders(
						List.of(AllowedHeaderPattern.builder().exact("Authorization").ignore_case(true).build(),
								AllowedHeaderPattern.builder().safe_regex(new SafeRegex("X-ABACO-.*")).build())),
				new AllowedHeaders(List.of(AllowedHeaderPattern.builder().exact("Set-Cookie").ignore_case(true).build())));

		public HttpService(ServerUri server_uri) {
			this.server_uri = server_uri;
		}
	}

	@Data
	@NoArgsConstructor
	public static class ServerUri {
		private String uri;
		private String cluster;
		private String timeout = "1s";

		public ServerUri(ExternalAuthSpec spec) {
			this.uri = spec.getService() + ':' + spec.getPort();
			this.cluster = spec.getClusterId();
			this.timeout = spec.getTimeout();
		}

	}

	@Data
	@AllArgsConstructor
	public static class AuthorizationRequest {
		private AllowedHeaders allowed_headers;
	}

	@Data
	@AllArgsConstructor
	public static class AuthorizationResponse {
		private AllowedHeaders allowed_upstream_headers;
		private AllowedHeaders allowed_client_headers_on_success;
	}

	@Data
	@AllArgsConstructor
	public static class AllowedHeaders {
		private List<AllowedHeaderPattern> patterns;
	}

	@Data
	@Builder
	@JsonInclude(Include.NON_NULL)
	public static class AllowedHeaderPattern {
		private SafeRegex safe_regex;

		private String exact;

		private Boolean ignore_case;
	}

	@Data
	@AllArgsConstructor
	public static class SafeRegex {
		private String regex;
	}
}
