package com.abacogroup.apigateway.controller.model;

import com.abacogroup.apigateway.controller.model.envoy.Cluster;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ExternalAuthSpec {
	private String service;
	private int port;
	private String timeout = "1s";

	public ExternalAuthSpec(ExternalAuthSpec other) {
		this.service = other.service;
		this.port = other.port;
		this.timeout = other.timeout;
	}

	@JsonIgnore
	public String getClusterId() {
		return Cluster.createClusterId(service, port);
	}
}
