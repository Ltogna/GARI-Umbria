package com.abacogroup.apigateway.controller.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CorsGlobalFilterSpec {
	private List<String> allow_origin_regexes;
	private String allow_methods = "GET,POST,PUT,PATCH,DELETE,HEAD";
	private String allow_headers = "DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Cookie,Content-Type,Range,Authorization,Access-Control-Allow-Origin";
	private String expose_headers;
	private String max_age = "60"; // Seconds
	private boolean allow_credentials = true;

	public CorsGlobalFilterSpec(CorsGlobalFilterSpec other) {
		this.allow_origin_regexes = new ArrayList<>(other.allow_origin_regexes);
		this.allow_methods = other.allow_methods;
		this.allow_headers = other.allow_headers;
		this.expose_headers = other.expose_headers;
		this.max_age = other.max_age;
		this.allow_credentials = other.allow_credentials;
	}
}
