package com.abacogroup.apigateway.controller.model;

import io.fabric8.kubernetes.api.model.Namespaced;
import io.fabric8.kubernetes.client.CustomResource;
import io.fabric8.kubernetes.model.annotation.Group;
import io.fabric8.kubernetes.model.annotation.Plural;
import io.fabric8.kubernetes.model.annotation.Version;

@Version("v1")
@Group("apigateway.abacogroup.com")
@Plural("externalauth")
public class ExternalAuth extends CustomResource<ExternalAuthSpec, Void> implements Namespaced {
	private static final long serialVersionUID = -4228006479493114412L;
}
