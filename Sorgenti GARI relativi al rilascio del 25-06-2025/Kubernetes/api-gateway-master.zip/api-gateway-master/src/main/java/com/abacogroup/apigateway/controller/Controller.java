package com.abacogroup.apigateway.controller;

import static java.util.stream.Collectors.toList;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.DigestOutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.apigateway.controller.model.ContentSecurityPolicy;
import com.abacogroup.apigateway.controller.model.ContentSecurityPolicySpec;
import com.abacogroup.apigateway.controller.model.CorsGlobalFilter;
import com.abacogroup.apigateway.controller.model.CorsGlobalFilterSpec;
import com.abacogroup.apigateway.controller.model.ExternalAuth;
import com.abacogroup.apigateway.controller.model.ExternalAuthSpec;
import com.abacogroup.apigateway.controller.model.ServiceRoute;
import com.abacogroup.apigateway.controller.model.ServiceRouteSpec;
import com.abacogroup.apigateway.controller.model.ServiceRouteSpec.RouteDefinition;
import com.abacogroup.apigateway.controller.model.envoy.Cluster;
import com.abacogroup.apigateway.controller.model.envoy.Cluster.Endpoint;
import com.abacogroup.apigateway.controller.model.envoy.Cluster.LoadAssignment;
import com.abacogroup.apigateway.controller.model.envoy.ConnectionManagerTypedDefnition;
import com.abacogroup.apigateway.controller.model.envoy.ConnectionManagerTypedDefnition.EnvoyRouteDefinition;
import com.abacogroup.apigateway.controller.model.envoy.ConnectionManagerTypedDefnition.Header;
import com.abacogroup.apigateway.controller.model.envoy.ConnectionManagerTypedDefnition.HttpFilter;
import com.abacogroup.apigateway.controller.model.envoy.ConnectionManagerTypedDefnition.VirtualHost;
import com.abacogroup.apigateway.controller.model.envoy.EnvoyLds;
import com.abacogroup.apigateway.controller.model.envoy.EnvoyLds.Address;
import com.abacogroup.apigateway.controller.model.envoy.EnvoyLds.Filter;
import com.abacogroup.apigateway.controller.model.envoy.EnvoyLds.FilterChain;
import com.abacogroup.apigateway.controller.model.envoy.EnvoyLds.Resource;
import com.abacogroup.apigateway.controller.model.envoy.EnvoyLds.SocketAddress;
import com.abacogroup.apigateway.controller.model.envoy.httpfilter.Cors;
import com.abacogroup.apigateway.controller.model.envoy.httpfilter.CorsPolicy;
import com.abacogroup.apigateway.controller.model.envoy.httpfilter.CorsPolicy.AllowedOrigin;
import com.abacogroup.apigateway.controller.model.envoy.httpfilter.ExtAuthz;
import com.abacogroup.apigateway.controller.model.envoy.httpfilter.ExtAuthz.HttpService;
import com.abacogroup.apigateway.controller.model.envoy.httpfilter.ExtAuthz.ServerUri;
import com.abacogroup.apigateway.controller.model.envoy.httpfilter.GizpCompressor;
import com.abacogroup.apigateway.controller.model.envoy.httpfilter.Router;
import com.fasterxml.jackson.dataformat.yaml.YAMLMapper;

import io.fabric8.kubernetes.api.model.ObjectMeta;
import io.fabric8.kubernetes.client.CustomResource;
import io.fabric8.kubernetes.client.informers.ResourceEventHandler;
import io.fabric8.kubernetes.client.informers.SharedIndexInformer;
import io.fabric8.kubernetes.client.informers.cache.Cache;
import io.fabric8.kubernetes.client.informers.cache.Lister;

public class Controller {
	private static final Logger log = LoggerFactory.getLogger(Controller.class.getSimpleName());
	private static final String CONFIG_PATH = "/config";

	private String configPath = CONFIG_PATH;

	private Lister<ServiceRoute> routesLister;
	private Lister<ExternalAuth> externalAuthLister;
	private Lister<CorsGlobalFilter> corsLister;
	private Lister<ContentSecurityPolicy> cspLister;
	private String namespace;
	private ArrayBlockingQueue<String> routesWorkqueue;
	private ArrayBlockingQueue<String> externalAuthWorkqueue;
	private ArrayBlockingQueue<String> corsWorkqueue;
	private ArrayBlockingQueue<String> cspWorkqueue;
	private SharedIndexInformer<ServiceRoute> httpRouteInformer;
	private SharedIndexInformer<ExternalAuth> externalAuthInformer;
	private SharedIndexInformer<CorsGlobalFilter> corsInformer;
	private SharedIndexInformer<ContentSecurityPolicy> cspInformer;

	private ScheduledExecutorService executor;
	private ScheduledFuture<?> scheduled;
	private ConcurrentHashMap<String, ServiceRouteSpec> currentRoutes;
	private ConcurrentHashMap<String, ExternalAuthSpec> currentExternalAuths;
	private ConcurrentHashMap<String, CorsGlobalFilterSpec> currentCorsGlobalFilter;
	private ConcurrentHashMap<String, ContentSecurityPolicySpec> currentCsp;

	private byte[] ldsHash = new byte[16];
	private byte[] cdsHash = new byte[16];

	private YAMLMapper mapper;

	// to update the status: MixedOperation<HTTPRoute,
	// KubernetesResourceList<HTTPRoute>, Resource<HTTPRoute>> client

	public Controller(SharedIndexInformer<ServiceRoute> httpRouteInformer,
			SharedIndexInformer<ExternalAuth> externalAuthInformer,
			SharedIndexInformer<CorsGlobalFilter> corsInformer,
			SharedIndexInformer<ContentSecurityPolicy> cspInformer,
			String namespace) {
		this.corsInformer = corsInformer;
		this.cspInformer = cspInformer;

		this.routesLister = new Lister<>(httpRouteInformer.getIndexer(), namespace);
		this.externalAuthLister = new Lister<>(externalAuthInformer.getIndexer(), namespace);
		this.corsLister = new Lister<>(corsInformer.getIndexer(), namespace);
		this.cspLister = new Lister<>(cspInformer.getIndexer(), namespace);

		this.httpRouteInformer = httpRouteInformer;
		this.externalAuthInformer = externalAuthInformer;
		this.routesWorkqueue = new ArrayBlockingQueue<>(1024);
		this.externalAuthWorkqueue = new ArrayBlockingQueue<>(128);
		this.corsWorkqueue = new ArrayBlockingQueue<>(128);
		this.cspWorkqueue = new ArrayBlockingQueue<>(128);
		this.namespace = namespace;

		this.mapper = new YAMLMapper();

		this.executor = Executors.newScheduledThreadPool(1);
		this.currentRoutes = new ConcurrentHashMap<>();
		this.currentExternalAuths = new ConcurrentHashMap<>();
		this.currentCorsGlobalFilter = new ConcurrentHashMap<>();
		this.currentCsp = new ConcurrentHashMap<>();

		initInformerEventHandlers();
	}

	public void run() {
		log.info("Starting {} controller", Controller.class.getSimpleName());
		writeFiles();

		while (!httpRouteInformer.hasSynced() && !externalAuthInformer.hasSynced() && !corsInformer.hasSynced()
				&& !cspInformer.hasSynced()) {
			// Wait till Informers sync
			try {
				Thread.sleep(5);
			} catch (InterruptedException e) {
				log.error("controller interrupted while waiting for informer to be in sync..");
				Thread.currentThread().interrupt();
				return;
			}
		}

		new Thread(() -> processingLoop(externalAuthWorkqueue, this::reconcileExternalAuth)).start();
		new Thread(() -> processingLoop(corsWorkqueue, this::reconcileCorsGlobalFilter)).start();
		new Thread(() -> processingLoop(cspWorkqueue, this::reconcileCsp)).start();

		processingLoop(routesWorkqueue, this::reconcileRoutes);
	}

	public void setConfigPath(String configPath) {
		this.configPath = configPath;
	}

	private void processingLoop(ArrayBlockingQueue<String> queue, Consumer<String> reconciler) {
		while (!Thread.currentThread().isInterrupted()) {
			try {
				String key = queue.take();
				Objects.requireNonNull(key, "key can't be null");
				log.debug("Got key {}", key);
				if (key.isEmpty() || (!key.contains("/"))) {
					log.warn("invalid key: {}", key);
					continue;
				}

				// Get the resource's name from key which is in format namespace/name
				String name = key.split("/")[1];
				reconciler.accept(name);

			} catch (InterruptedException interruptedException) {
				Thread.currentThread().interrupt();
				System.exit(1);
			}
		}
	}

	private void reconcileRoutes(String routeName) {
		ServiceRoute route = routesLister.get(routeName);
		if (route == null) {
			log.info("Deleting HTTPRoute {}", routeName);
			currentRoutes.remove(routeName);
		} else {
			log.info("Adding HTTPRoute {}", routeName);
			ServiceRouteSpec spec = new ServiceRouteSpec(route.getSpec());
			currentRoutes.put(routeName, spec);
		}

		scheduleWriteFiles();
	}

	private void reconcileExternalAuth(String externalAuthName) {
		ExternalAuth externalAuth = externalAuthLister.get(externalAuthName);
		if (externalAuth == null) {
			log.info("Deleting ExternalAuth {}", externalAuthName);
			currentExternalAuths.remove(externalAuthName);
		} else {
			log.info("Adding ExternalAuth {}", externalAuthName);
			ExternalAuthSpec spec = new ExternalAuthSpec(externalAuth.getSpec());
			currentExternalAuths.put(externalAuthName, spec);
		}

		scheduleWriteFiles();
	}

	private void reconcileCorsGlobalFilter(String corsGlobalFitlerName) {
		CorsGlobalFilter corsFilter = corsLister.get(corsGlobalFitlerName);
		if (corsFilter == null) {
			log.info("Deleting corsGlobalFitlerName {}", corsGlobalFitlerName);
			currentExternalAuths.remove(corsGlobalFitlerName);
		} else {
			log.info("Adding CorsGlobalFilter {}", corsGlobalFitlerName);
			CorsGlobalFilterSpec spec = new CorsGlobalFilterSpec(corsFilter.getSpec());
			currentCorsGlobalFilter.put(corsGlobalFitlerName, spec);
		}

		scheduleWriteFiles();
	}

	private void reconcileCsp(String cspName) {
		ContentSecurityPolicy csp = cspLister.get(cspName);
		if (csp == null) {
			log.info("Deleting cspName {}", cspName);
			currentCsp.remove(cspName);
		} else {
			log.info("Adding ContentSecurityPolicy {}", cspName);
			ContentSecurityPolicySpec spec = new ContentSecurityPolicySpec(csp.getSpec());
			currentCsp.put(cspName, spec);
		}

		scheduleWriteFiles();
	}

	private synchronized void scheduleWriteFiles() {
		if (scheduled != null) {
			scheduled.cancel(false);
		}

		scheduled = executor.schedule(this::writeFiles, 1, TimeUnit.SECONDS);
	}

	private void writeFiles() {
		writeCDS();

		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}

		writeLDS();
	}

	private void writeLDS() {
		try {
			ConnectionManagerTypedDefnition connectionManager = createConnectionManagerDefinition();

			List<Resource> resources = List.of(Resource.builder()
					.address(new Address(new SocketAddress("0.0.0.0", 10000)))
					.filter_chains(List.of(new FilterChain(
							List.of(new Filter("envoy.filters.network.http_connection_manager", connectionManager)))))
					.name("listener")
					.type("type.googleapis.com/envoy.config.listener.v3.Listener")
					.build());

			ldsHash = updateConfigIfNeeded(new EnvoyLds(resources), ldsHash, "lds.yaml");

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	private void writeCDS() {
		try {
			List<Cluster> authClusters = currentExternalAuths.values().stream()
					.map(spec -> Cluster.builder().connect_timeout(spec.getTimeout())
							.load_assignment(LoadAssignment.builder().cluster_name(spec.getClusterId())
									.endpoint(Endpoint.fromSocket(spec.getService(), spec.getPort())).build())
							.name(spec.getClusterId()).build())
					.collect(toList());

			List<Cluster> routeClusters = currentRoutes.values().stream()
					.flatMap(httpRouteSpec -> httpRouteSpec.getRoutes().stream())
					.map(RouteDefinition::getRoute)
					.filter(route -> route.getClusterId() != null)
					.map(route -> Cluster.builder()
							.load_assignment(LoadAssignment.builder()
									.cluster_name(route.getClusterId())
									.endpoint(Endpoint.fromSocket(route.getService(), route.getPort()))
									.build())
							.name(route.getClusterId()).build())
					.collect(toList());

			Set<Cluster> clusters = new TreeSet<>();
			clusters.addAll(authClusters);
			clusters.addAll(routeClusters);

			cdsHash = updateConfigIfNeeded(Map.of("resources", clusters), cdsHash, "cds.yaml");

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	private byte[] updateConfigIfNeeded(Object config, byte[] currentHash, String fileName)
			throws IOException, NoSuchAlgorithmException {
		byte[] hash = null;
		boolean moveFile = false;
		File tempFile = File.createTempFile("apigw", fileName, new File(configPath));
		try (var out = new DigestOutputStream(new FileOutputStream(tempFile), MessageDigest.getInstance("MD5"))) {
			mapper.writeValue(out, config);

			out.flush();
			hash = out.getMessageDigest().digest();
			if (!Arrays.equals(hash, currentHash)) {
				moveFile = true;
			}
		}

		if (moveFile) {
			Files.move(tempFile.toPath(), Path.of(configPath, fileName), StandardCopyOption.REPLACE_EXISTING);
		} else {
			tempFile.delete();
		}

		return hash;
	}

	private ConnectionManagerTypedDefnition createConnectionManagerDefinition() {
		// The order of filters matters
		List<HttpFilter> httpFitlers = new ArrayList<>();

		CorsPolicy corsPolicy = createCorsGlobalFilterPolicy();
		if (corsPolicy != null) {
			httpFitlers.add(new HttpFilter("envoy.filters.http.cors", new Cors()));
		}
		httpFitlers.add(new HttpFilter("envoy.filters.http.compressor", new GizpCompressor()));
		httpFitlers.addAll(createExternalAuthFilters());
		httpFitlers.add(new HttpFilter("envoy.filters.http.router", new Router()));

		Map<String, VirtualHost> virtualhosts = new TreeMap<>();
		currentRoutes.values().stream()
				.flatMap(httpRouteSpec -> httpRouteSpec.getRoutes().stream())
				.sorted((a, b) -> a.getMatch().getDomain().compareTo(b.getMatch().getDomain()))
				.forEach(e -> {
					VirtualHost vh = virtualhosts.computeIfAbsent(e.getMatch().getDomain(), VirtualHost::new);
					vh.putTypedPerFilterConfig("envoy.filters.http.cors", corsPolicy);
					vh.getRoutes().add(new EnvoyRouteDefinition(e));
				});

		// Sort VirtualHosts routes...
		virtualhosts.values()
				.forEach(vh -> vh.getRoutes().sort(EnvoyRouteDefinition::compareTo));

		Header cspHeader = createCspHeader();
		return new ConnectionManagerTypedDefnition(httpFitlers, new ArrayList<>(virtualhosts.values()), cspHeader);
	}

	private CorsPolicy createCorsGlobalFilterPolicy() {
		Optional<CorsPolicy> corsPolicy = currentCorsGlobalFilter.values()
				.stream()
				.map(spec -> CorsPolicy.builder()
						.allow_credentials(spec.isAllow_credentials())
						.allow_headers(spec.getAllow_headers())
						.allow_methods(spec.getAllow_methods())
						.allow_origin_string_match(spec.getAllow_origin_regexes()
								.stream()
								.map(AllowedOrigin::new)
								.collect(toList()))
						.max_age(spec.getMax_age())
						.build())
				.findAny();

		log.info("Setting CORS Global Filter policy");

		return corsPolicy
				.orElse(null);
	}

	private Header createCspHeader() {

		String csp = currentCsp.values()
				.stream()
				.map(spec -> spec.getCsp_header())
				.map(String::trim)
				.findAny()
				.orElseGet(() -> "default-src 'self';"
						+ " img-src 'self' https: data:;"
						+ " style-src 'self' https: 'unsafe-inline';" // 'unsafe-inline' is needed by bootstrap-italia to load fonts
						+ " script-src 'self' 'unsafe-eval';" // unsafe-eval is needed by vue-i18n
						+ " font-src 'self' data:;");

		if (csp.isEmpty()) {
			log.info("CSP enforcing is disabled");
			return null;
		}

		log.info("Setting CSP: {}", csp);
		Header cspHeader = new Header("Content-Security-Policy", csp);
		return cspHeader;
	}

	private Collection<? extends HttpFilter> createExternalAuthFilters() {
		return currentExternalAuths.values().stream()
				.map(spec -> ExtAuthz.builder().http_service(new HttpService(new ServerUri(spec))).build())
				.map(extAuthz -> new HttpFilter("envoy.filters.http.ext_authz", extAuthz)).collect(toList());
	}

	private void initInformerEventHandlers() {
		// Set up an event handler for when HTTPRoute resources change
		setupEventHandler(httpRouteInformer, routesWorkqueue);

		// Set up an event handler for when ExternalAuth resources change
		setupEventHandler(externalAuthInformer, externalAuthWorkqueue);

		// Set up an event handler for when CorsGlobalFilter resources change
		setupEventHandler(corsInformer, corsWorkqueue);

		// Set up an event handler for when ContentSecurityPolicy resources change
		setupEventHandler(cspInformer, cspWorkqueue);
	}

	private <T extends CustomResource<?, ?>> void setupEventHandler(SharedIndexInformer<T> informer,
			ArrayBlockingQueue<String> queue) {
		informer.addEventHandler(new ResourceEventHandler<T>() {
			@Override
			public void onAdd(T resource) {
				enqueue(resource, queue);
			}

			@Override
			public void onUpdate(T resource, T newResource) {
				enqueue(newResource, queue);
			}

			@Override
			public void onDelete(T resource, boolean b) {
				enqueue(resource, queue);
			}
		});
	}

	private void enqueue(CustomResource<?, ?> resource, ArrayBlockingQueue<String> queue) {
		ObjectMeta metadata = resource.getMetadata();

		if (!metadata.getNamespace().equals(namespace)) {
			log.debug("Skipping {}/{} because it comes from a different namespace", resource.getKind(),
					metadata.getName());
			return;
		}

		log.debug("enqueue({}={})", resource.getKind(), metadata.getName());
		String key = Cache.metaNamespaceKeyFunc(resource);

		log.debug("Going to enqueue {} {}", resource.getKind(), key);
		if (key != null && !key.isEmpty()) {
			queue.add(key);
		}
	}

}
