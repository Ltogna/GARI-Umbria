package com.abacogroup.apigateway.controller.model.envoy.httpfilter;

import com.abacogroup.apigateway.controller.model.envoy.TypedConfig;

public class Router implements TypedConfig {
	@Override
	public String getAtType() {
		return "type.googleapis.com/envoy.extensions.filters.http.router.v3.Router";
	};
}
