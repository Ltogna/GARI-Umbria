package com.abacogroup.apigateway.controller.model.envoy.httpfilter;

import com.abacogroup.apigateway.controller.model.envoy.TypedConfig;

public class Cors implements TypedConfig {

	@Override
	public String getAtType() {
		return "type.googleapis.com/envoy.extensions.filters.http.cors.v3.Cors";
	}

}
