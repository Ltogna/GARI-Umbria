package com.abacogroup.apigateway.controller.model;

import static java.util.stream.Collectors.toList;

import java.util.List;

import com.abacogroup.apigateway.controller.model.envoy.Cluster;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ServiceRouteSpec {
	private List<RouteDefinition> routes;

	public ServiceRouteSpec(ServiceRouteSpec other) {
		if (other.routes == null) {
			return;
		}

		this.routes = other.routes.stream().map(RouteDefinition::new).collect(toList());
	}

	@Data
	@NoArgsConstructor
	public static class RouteDefinition {
		private Match match;
		private Route route;

		public RouteDefinition(RouteDefinition other) {
			this.match = new Match(other.match);
			this.route = new Route(other.route);
		}
	}

	@Data
	@JsonInclude(Include.NON_NULL)
	public static class Match {
		private static final String DEFAULT_DOMAIN = "*";

		private String domain;
		private String path_separated_prefix;
		private String prefix;
		private String path;
		private String safe_regex;

		public Match() {
			domain = DEFAULT_DOMAIN;
		}

		public Match(Match other) {
			this.domain = other.domain;
			this.path_separated_prefix = other.path_separated_prefix;
			this.prefix = other.prefix;
			this.path = other.path;
			this.safe_regex = other.safe_regex;
		}

		public void setDomain(String domain) {
			if (domain == null || domain.isBlank()) {
				domain = DEFAULT_DOMAIN;
			}

			this.domain = domain;
		}
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@JsonInclude(Include.NON_NULL)
	public static class Route {
		private String service;
		private int port;
		private String prefix_rewrite;
		private String regex_rewrite;
		private boolean disable_auth;
		private String timeout;
		private DirectResponse direct_response;
		private UpgradeConfigs upgrade_configs;

		public Route(Route other) {
			this(other.service, other.port, other.prefix_rewrite, other.regex_rewrite, other.disable_auth, other.timeout, other.direct_response, other.upgrade_configs);
		}

		@JsonIgnore
		public String getClusterId() {
			return Cluster.createClusterId(service, port);
		}
	}

	@Data
	@JsonInclude(Include.NON_NULL)
	public static class DirectResponse {
		private Integer status;
		private String inline_string;
	}
	
	@Data
	@JsonInclude(Include.NON_NULL)
	public static class UpgradeConfigs {
		private String upgrade_type;
	}

}
