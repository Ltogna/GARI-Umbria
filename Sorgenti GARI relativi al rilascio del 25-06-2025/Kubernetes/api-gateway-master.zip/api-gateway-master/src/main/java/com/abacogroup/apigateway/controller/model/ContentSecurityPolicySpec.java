package com.abacogroup.apigateway.controller.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ContentSecurityPolicySpec {
	private String csp_header;

	public ContentSecurityPolicySpec(ContentSecurityPolicySpec other) {
		this.csp_header = other.csp_header;
	}
}
