package com.abacogroup.apigateway.controller.model.envoy.httpfilter;

import java.util.List;

import com.abacogroup.apigateway.controller.model.envoy.TypedConfig;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(Include.NON_NULL)
public class CorsPolicy implements TypedConfig {

	private List<AllowedOrigin> allow_origin_string_match;
	private String allow_methods;
	private String allow_headers;
	private boolean allow_credentials;
	private String max_age;

	@Override
	public String getAtType() {
		return "type.googleapis.com/envoy.extensions.filters.http.cors.v3.CorsPolicy";
	}

	@Data
	@AllArgsConstructor
	public static class AllowedOrigin {
		private SafeRegex safe_regex;

		public AllowedOrigin(String regex) {
			this(new SafeRegex(regex));
		}
	}

	@Data
	@AllArgsConstructor
	public static class SafeRegex {
		private String regex;
	}
}
