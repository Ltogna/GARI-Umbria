package com.abacogroup.apigateway.controller.model.envoy;

import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Singular;

@Data
@Builder
@JsonInclude(Include.NON_NULL)
public class Cluster implements TypedConfig, Comparable<Cluster> {

	private String name;

	private String connect_timeout;

	@Builder.Default
	private String type = "STRICT_DNS";

	@Builder.Default
	private String lb_policy = "ROUND_ROBIN";

	private LoadAssignment load_assignment;

	public static String createClusterId(String service, int port) {
		if (service == null) {
			return null;
		}
		return service.replaceAll("\\.", "_") + "_" + port;
	}

	@Override
	public String getAtType() {
		return "type.googleapis.com/envoy.config.cluster.v3.Cluster";
	};

	@Override
	public int compareTo(Cluster other) {
		return name.compareTo(other.name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Cluster other = (Cluster) obj;
		return Objects.equals(name, other.name);
	}

	@Override
	public int hashCode() {
		return Objects.hash(name);
	}

	@Data
	@Builder
	public static class LoadAssignment {
		private String cluster_name;

		@Singular
		private List<Endpoint> endpoints;
	}

	@Data
	@AllArgsConstructor
	public static class Endpoint {
		private List<LbEndpoint> lb_endpoints;

		public static Endpoint fromSocket(String address, int port) {
			return new Endpoint(List.of(new LbEndpoint(ClusterAddress.fromSocket(address, port))));
		}
	}

	@Data
	@AllArgsConstructor
	public static class LbEndpoint {
		private LbEndpointElement endpoint;

		public LbEndpoint(ClusterAddress address) {
			endpoint = new LbEndpointElement(address);
		}
	}

	@Data
	@AllArgsConstructor
	public static class LbEndpointElement {
		private ClusterAddress address;
	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static class ClusterAddress {
		private SocketAddress socket_address;

		public static ClusterAddress fromSocket(String address, int port) {
			return new ClusterAddress(new SocketAddress(address, port));
		}
	}

	@Data
	@AllArgsConstructor
	public static class SocketAddress {
		private String address;
		private int port_value;
	}
}
