package com.abacogroup.apigateway.controller;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.apigateway.controller.model.ContentSecurityPolicy;
import com.abacogroup.apigateway.controller.model.CorsGlobalFilter;
import com.abacogroup.apigateway.controller.model.ExternalAuth;
import com.abacogroup.apigateway.controller.model.ServiceRoute;

import io.fabric8.kubernetes.api.model.HasMetadata;
import io.fabric8.kubernetes.api.model.KubernetesResourceList;
import io.fabric8.kubernetes.client.KubernetesClient;
import io.fabric8.kubernetes.client.KubernetesClientBuilder;
import io.fabric8.kubernetes.client.KubernetesClientException;
import io.fabric8.kubernetes.client.dsl.Informable;
import io.fabric8.kubernetes.client.dsl.MixedOperation;
import io.fabric8.kubernetes.client.dsl.NonNamespaceOperation;
import io.fabric8.kubernetes.client.dsl.Resource;
import io.fabric8.kubernetes.client.informers.SharedIndexInformer;

public class Application {
	public static final Logger logger = LoggerFactory.getLogger(Application.class.getSimpleName());

	private static final long RESYNC_MS = 15 * 60 * 1000;

	public static void main(String[] args) {
		try (KubernetesClient client = new KubernetesClientBuilder().build()) {
			String namespace = client.getNamespace();
			if (namespace == null) {
				logger.debug("No namespace found via config, assuming default.");
				namespace = "default";
			}

			logger.info("Working in namespace: {}", namespace);

			SharedIndexInformer<ServiceRoute> httpRouteSharedIndexInformer = createSharedIndexInformer(client, namespace, ServiceRoute.class, RESYNC_MS);
			registerStopHandler(httpRouteSharedIndexInformer, 2);

			SharedIndexInformer<ExternalAuth> externalAuthSharedIndexInformer = createSharedIndexInformer(client, namespace, ExternalAuth.class, RESYNC_MS);
			registerStopHandler(externalAuthSharedIndexInformer, 3);

			SharedIndexInformer<CorsGlobalFilter> corsSharedIndexInformer = createSharedIndexInformer(client, namespace, CorsGlobalFilter.class, RESYNC_MS);
			registerStopHandler(corsSharedIndexInformer, 4);

			SharedIndexInformer<ContentSecurityPolicy> cspSharedIndexInformer = createSharedIndexInformer(client, namespace, ContentSecurityPolicy.class,
					RESYNC_MS);
			registerStopHandler(cspSharedIndexInformer, 4);

			Controller controller = new Controller(httpRouteSharedIndexInformer, externalAuthSharedIndexInformer, corsSharedIndexInformer,
					cspSharedIndexInformer, namespace);

			var startFuture = CompletableFuture.allOf(
					httpRouteSharedIndexInformer.start().toCompletableFuture(),
					externalAuthSharedIndexInformer.start().toCompletableFuture(),
					corsSharedIndexInformer.start().toCompletableFuture(),
					cspSharedIndexInformer.start().toCompletableFuture());
			startFuture.get();

			logger.info("Starting Controller");
			controller.run();
		} catch (KubernetesClientException exception) {
			logger.error("Kubernetes Client Exception : ", exception);
		} catch (ExecutionException executionException) {
			logger.info("Exception in starting all registered informers ", executionException);
		} catch (InterruptedException interruptedException) {
			logger.info("Interrupted: ", interruptedException);
			Thread.currentThread().interrupt();
			interruptedException.printStackTrace();
		}
	}

	private static void registerStopHandler(SharedIndexInformer<?> informer, int exitCode) {
		informer.stopped().exceptionally(exception -> {
			logger.error("Exception occurred", exception);
			System.exit(exitCode);
			return null;
		});
	}

	private static <T extends HasMetadata> SharedIndexInformer<T> createSharedIndexInformer(KubernetesClient client, String namespace, Class<T> apiTypeClass,
			long resyncPeriodInMillis) {
		MixedOperation<T, KubernetesResourceList<T>, Resource<T>> resources = client.resources(apiTypeClass);

		Informable<T> informable = null;

		NonNamespaceOperation<T, KubernetesResourceList<T>, Resource<T>> nonNamespaceOp = resources
				.inNamespace(namespace);
		informable = nonNamespaceOp;

		return informable.runnableInformer(resyncPeriodInMillis);
	}
}
