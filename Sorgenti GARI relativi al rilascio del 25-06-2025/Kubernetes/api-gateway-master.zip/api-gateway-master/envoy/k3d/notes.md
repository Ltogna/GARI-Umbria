# Createa cluster

```bash
k3d cluster create externalauth --k3s-arg "--disable=traefik@server:0"
```

helm upgrade --install ingress-nginx ingress-nginx --repo https://kubernetes.github.io/ingress-nginx --namespace ingress-nginx --create-namespace