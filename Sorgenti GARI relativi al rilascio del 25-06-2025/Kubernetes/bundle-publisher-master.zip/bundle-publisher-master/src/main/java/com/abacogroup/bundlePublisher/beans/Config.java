package com.abacogroup.bundlePublisher.beans;

public class Config
{
	private RabbitmqConfig rabbitmqConfig;

	public class RabbitmqConfig
	{
		private String host;
		private String user;
		private String password;
		private String virtualhost;
		private Integer port;
		public String getHost()
		{
			return host;
		}
		public void setHost(String host)
		{
			this.host = host;
		}
		public String getUser()
		{
			return user;
		}
		public void setUser(String user)
		{
			this.user = user;
		}
		public String getPassword()
		{
			return password;
		}
		public void setPassword(String password)
		{
			this.password = password;
		}
		public String getVirtualhost()
		{
			return virtualhost;
		}
		public void setVirtualhost(String virtualhost)
		{
			this.virtualhost = virtualhost;
		}
		public Integer getPort()
		{
			return port;
		}
		public void setPort(Integer port)
		{
			this.port = port;
		}
	}

	public RabbitmqConfig getRabbitmqConfig()
	{
		return rabbitmqConfig;
	}

	public void setRabbitmqConfig(RabbitmqConfig rabbitmqConfig)
	{
		this.rabbitmqConfig = rabbitmqConfig;
	}

}
