package com.abacogroup.bundlePublisher;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeoutException;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionGroup;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.bundlePublisher.beans.Config;
import com.abacogroup.bundles.Constants;
import com.abacogroup.bundles.initializer.BundleInitServiceBuilder;
import com.abacogroup.bundles.initializer.impl.BundleInitServiceProducer;
import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;

public class MainClass
{

	@SuppressWarnings("unused")
	private static final Logger logger = LoggerFactory.getLogger(MainClass.class);

	public static void main(String[] args) throws StreamReadException, DatabindException, IOException, TimeoutException
	{
		Options options = new Options();

		options.addRequiredOption("c", "config", true, "The YAML configuration file to use");
		
		OptionGroup og = new OptionGroup();
		
		og.addOption(new Option("b", "bundle", true, "The bundle folder"));
		og.addOption(new Option("t", "tenant", true, "The tenant name to be created"));
		og.addOption(new Option("tf", "tenantFile", true, "The file that contain a list of tenant name to be created"));
		og.setRequired(true);
		
		options.addOptionGroup(og);

		CommandLineParser parser = new DefaultParser();
		CommandLine line;
		try
		{
			line = parser.parse(options, args);
		}
		catch (ParseException e)
		{
			System.out.println(e.getLocalizedMessage());
			printHelp(options);
			return;
		}

		String bundle = line.getOptionValue("bundle");
		String tenant = line.getOptionValue("tenant");
		String tenantFile = line.getOptionValue("tenantFile");

		/*int numOfOptions = (bundle != null ? 1 : 0) + (tenant != null ? 1 : 0) + (tenantFile != null ? 1 : 0);

		if (numOfOptions > 1)
		{
			System.out.println("You cannot specify more than one option among --bundle --tenant --tenantFile");
			printHelp(options);
			return;
		}
		if (numOfOptions < 1)
		{
			System.out.println("You have to specify --bundle or --tenant or --tenantFile");
			printHelp(options);
			return;
		}*/

		Config config = new ConfigurationLoader().loadConfiguration(new File(line.getOptionValue("config")),
			Config.class);

		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(config.getRabbitmqConfig().getHost());
		factory.setUsername(config.getRabbitmqConfig().getUser());
		factory.setPassword(config.getRabbitmqConfig().getPassword());
		factory.setVirtualHost(config.getRabbitmqConfig().getVirtualhost());
		factory.setPort(config.getRabbitmqConfig().getPort());
		factory.setAutomaticRecoveryEnabled(true);

		Connection connection = factory.newConnection();

		// createTestConsumer(connection);

		if (bundle != null)
			publishBundle(connection, new File(bundle));
		if (tenant != null)
			publishTenant(connection, tenant);
		if (tenantFile != null)
			publishTenantFile(connection, new File(tenantFile));

		connection.close();

		System.out.println("DONE!");
		System.exit(0);

	}

	private static void printHelp(Options options)
	{
		HelpFormatter formatter = new HelpFormatter();
		formatter.printHelp("bundle-publisher", options, true);
	}

	private static void publishBundle(Connection rabbitmqConnection, File bundlePath)
	{

		if (!bundlePath.isDirectory())
			throw new RuntimeException("Expected a directory [" + bundlePath.getAbsolutePath() + "]");

		File bundleConfig = new File(bundlePath, "bundles.config.json");
		if (bundleConfig.exists())
		{
			System.out.println("Publishing bundle folder: " + bundlePath.getAbsolutePath());
			var initService = BundleInitServiceBuilder
				.producer(new BundleInitServiceProducer(rabbitmqConnection))
				.configLocation(bundlePath.getAbsolutePath())
				.build();

			initService.start();
			return;
		}

		File[] children = bundlePath.listFiles();
		Arrays.sort(children);

		for (File child : children)
		{
			publishBundle(rabbitmqConnection, child);
		}

	}

	private static void publishTenantFile(Connection rabbitmqConnection, File file) throws FileNotFoundException, IOException
	{
		try (BufferedReader br = new BufferedReader(new FileReader(file)))
		{
			String line;
			while ((line = br.readLine()) != null)
			{
				publishTenant(rabbitmqConnection, line);
			}
		}
	}

	private static void publishTenant(Connection rabbitmqConnection, String tenant)
	{
		System.out.println("Publishing tenant: " + tenant);
		String exchangeName = Constants.DEFAULT_EXCHANGE_NAME;

		try (Channel channel = rabbitmqConnection.createChannel())
		{
			channel.exchangeDeclare(exchangeName, BuiltinExchangeType.TOPIC);

			String topic = String.format("%s.%s", Constants.TOPIC_PREFIX, "newtenant");

			Map<String, Object> headers = Map.of("tenant", tenant);
			AMQP.BasicProperties properties = new AMQP.BasicProperties.Builder()
				.deliveryMode(2) // persistent
				.correlationId(UUID.randomUUID().toString())
				.contentType("application/octet-stream")
				.headers(headers)
				.build();
			channel.basicPublish(exchangeName, topic, properties, tenant.getBytes(StandardCharsets.UTF_8));
			logger.debug("'{}' pushed to exchange {} with topic {} and headers {}", tenant, exchangeName, topic,
				headers);
		}
		catch (TimeoutException | IOException e)
		{
			throw new RuntimeException(e);
		}
	}

	private static void createTestConsumer(Connection connection) throws IOException
	{
		Channel channel = connection.createChannel();
		channel.exchangeDeclare(Constants.DEFAULT_EXCHANGE_NAME, BuiltinExchangeType.TOPIC, false);

		channel.queueDeclare("test_queue", true, false, false, null);
		channel.queueBind("test_queue", Constants.DEFAULT_EXCHANGE_NAME, "#");
		System.out.println(" [*] Waiting for messages. To exit press CTRL+C");

		DeliverCallback deliverCallback = (consumerTag, delivery) -> {
			String message = new String(delivery.getBody(), StandardCharsets.UTF_8);
			System.out.println(" [x] Received '" + message + "'");
		};
		channel.basicConsume("test_queue", true, deliverCallback, consumerTag -> {
			System.out.println("CENCELLED");
		});

	}

}
