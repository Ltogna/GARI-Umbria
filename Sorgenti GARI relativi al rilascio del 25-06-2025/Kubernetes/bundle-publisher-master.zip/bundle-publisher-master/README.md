# Bundle Publisher

### tre righe fatte male per sapere come usarlo localmente

cloni il progetto "https://gitlab.fe.abacogroup.eu/abaco-standard/bundle-publisher"

lo compili con "mvn clean package"

prepari una directory personale per le prove, per esempio "prove_bundles", che non serve poi caricarla sul progetto

all'interno poi puoi creare un elenco delle configurazioni che ti servono, per esempio io faccio una directory per ogni simulazione che devo fare, come un nuovo "ambiente", semplicemente nella sotto-directory serve creare un json `bundles.config.json`
```json
{
    "tenant": "master"
}
```
dove definisci su che tenant vuoi che il bundle venga importato


Non mi ricordo se serve, ma tu fallo lo stesso, il file `tenants.txt` con dentro l'elenco dei tenant "usabili"
```
master

```

devi aver avviato rabbitmq sul tuo computer, ed il server che deve ricevere il tuo bundle collegato ad un tuo DB, così da evitare di "sballare" qualche db reale

il config.yaml, è già giusto se usi una configurazione di rabbitmq "standard"

dentro la sotto-directory dell'ambiente di prova, per esempio "prove-nuove-matrici", crei la struttura per l'invio dei bundle, che sono:

* nome-server (nel nostro caso "lpis-gis-server")
    * "numero bundle" lo vedi spesso nei progetti dei bundles, puoi fare tipo: "lpis-00999-update-matrix-cropplan"
        * nome-dominio (nel nostro caso quello che ci eravamo detti, mi pare "matrix-update")
            * il tuo json da importare

Esempio:


```
📜 tenants.txt
📂 prove_bundles
┣ 📂 prove-nuove-matrici
  ┣ 📜 bundles.config.json
  ┣ 📂 lpis-gis-server
    ┣ 📂 lpis-00999-update-matrix-cropplan
      ┣ 📜 aggiorna_la_matrice_cropplan.json
      ┣ 📜 elimina_dalla_matrice_cropplan.delete.json
```

Quindi esegui il publisher:

java -jar target/bundle-publisher-1.0.4.jar -c config.yaml -b prove_bundles/prove-nuove-matrici

Questo prende la struttura di "prove-nuove-matrici" crea lo zip "lpis-00999-update-matrix-cropplan.zip" con dentro i tuoi file e lo invia, via rabbitmq, usando l'exchange "lpis-gis-server" e la coda "config-queue-lpis-gis-server" al tuo server in ascolto sullo stesso rabbit