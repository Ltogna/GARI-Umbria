#!/bin/sh

java -jar bundle-publisher.jar -c config.yml "$@"
