package com.abacogroup.agri.dossiers.core.caller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;

import static com.abacogroup.jaxrsutils.GenericCallerService.GET_METHOD;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class GetUserByTenantTest {
    private GetUserByTenant getUserByTenant;

    private static final String USERNAME = "USERNAME";
    private static final String URL = "URL";
    private static final String TENANT = "TENANT";
    private static final String TOKEN = "TOKEN";

    @BeforeEach
    void init() {
        getUserByTenant = GetUserByTenant.builder()
                .url(URL)
                .tenant(TENANT)
                .token(TOKEN)
                .username(USERNAME)
                .build();
    }

    @Test
    void of_ok() {
        GetUserByTenant expectedOutput = GetUserByTenant.builder()
                .url(URL)
                .tenant(TENANT)
                .token(TOKEN)
                .username(USERNAME)
                .build();

        GetUserByTenant result = GetUserByTenant.of(TENANT, USERNAME, URL, TOKEN);

        assertEquals(expectedOutput, result);
    }

    @Test
    void getPathVariablesMap_ok() {
        Map<String, Object> expectedOutput = Map.of("username", USERNAME,
                "tenant", TENANT);

        Map<String, Object> result = getUserByTenant.getPathVariablesMap();

        assertEquals(expectedOutput, result);
    }

    @Test
    void provideAuthToken_ok() {
        String result = getUserByTenant.provideAuthToken();

        assertEquals(TOKEN, result);
    }

    @Test
    void getHttpMethod_ok() {
        String result = getUserByTenant.getHttpMethod();

        assertEquals(GET_METHOD, result);
    }
}
