package com.abacogroup.agri.dossiers.bundles.processor.workflow;

import com.abacogroup.agri.dossiers.core.services.workflow.DossiersWorkflowService;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.HandleConsumer;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class WorkflowNewTenantProcessorTest {

	protected static final String TEMPLATE_TENANT_ID = "*";
	private final ConfigDataMessage configDataMessage = new ConfigDataMessage();

	@Mock
	private Jdbi jdbi;
	@Mock
	private WorkflowsBundleWorker workflowsBundleWorker;
	@Mock
	private DossiersWorkflowService taskManagerWorkflowService;
	@InjectMocks
	private WorkflowNewTenantProcessor workflowsNewTenantProcessor;

	@BeforeEach
	void init() {
		configDataMessage.setTenantId(TEMPLATE_TENANT_ID);
		workflowsNewTenantProcessor = new WorkflowNewTenantProcessor(jdbi, workflowsBundleWorker);
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_onMessage() {
		try {
			ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);
			TenantMessage message = new TenantMessage();
			message.setTenantId(TEMPLATE_TENANT_ID);

			when(workflowsBundleWorker.exposeDossierWorkflowService()).thenReturn(taskManagerWorkflowService);
			workflowsNewTenantProcessor.onMessage(message);
			verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useHandle(jdbi.open());
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

}
