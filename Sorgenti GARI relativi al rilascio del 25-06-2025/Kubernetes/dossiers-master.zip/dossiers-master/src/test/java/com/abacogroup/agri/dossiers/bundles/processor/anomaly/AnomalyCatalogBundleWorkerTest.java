package com.abacogroup.agri.dossiers.bundles.processor.anomaly;

import com.abacogroup.agri.dossiers.bundles.model.I18nPair;
import com.abacogroup.agri.dossiers.bundles.model.anomaly.BundleAnomalyCatalogInDTO;
import com.abacogroup.agri.dossiers.bundles.model.anomaly.BundleAnomalyCatalogMessage;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.AnomalyCatalogDTO;
import com.abacogroup.agri.dossiers.core.services.crud.AnomalyCatalogCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.ModuleCrudService;
import com.abacogroup.agri.dossiers.db.ntt.dossiers.RsI18N;
import com.abacogroup.agri.dossiers.db.ntt.compoundkeys.AnomalyCatalogKey;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.when;

/**
 * The type Anomaly catalog bundle worker test.
 *
 * @author Carlo Sindico
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
public class AnomalyCatalogBundleWorkerTest {

	private static final String TENANT = "tenant";

	private static final String ANOMALY_CODE = "anomaly_code";

	private static final Long MODULE_ID = 1L;

	private static final String MODULE_CODE = "module_code";

	private static final String SEVERITY = "severity";

	private final I18nPair i18nPairMock = I18nPair.builder()
			.lang("lang")
			.description("lang")
			.build();

	private final RsI18N rsI18NMock = RsI18N.builder()
			.field_name("lang")
			.lang("lang")
			.i18n_text("lang")
			.tenant_id(TENANT)
			.i18n_value("lang")
			.table_name("lang")
			.build();

	private final BundleAnomalyCatalogInDTO bundleAnomalyCatalogInDTOMock = BundleAnomalyCatalogInDTO.builder()
			.anomalyCode(ANOMALY_CODE)
			.moduleCode(MODULE_CODE)
			.severity(SEVERITY)
			.i18n(List.of(i18nPairMock))
			.build();
	private final BundleAnomalyCatalogMessage bundleAnomalyCatalogMessageMock = BundleAnomalyCatalogMessage.builder()
			.anomalies(List.of(bundleAnomalyCatalogInDTOMock))
			.build();

	private final AnomalyCatalogDTO anomalyCatalogDTOMock = AnomalyCatalogDTO.builder()
			.anomalyCode(ANOMALY_CODE)
			.moduleId(MODULE_ID)
			.severity(SEVERITY)
			.build();

	private final ModuleDTO moduleDTOMock = ModuleDTO.builder()
			.moduleId(MODULE_ID)
			.moduleCode(MODULE_CODE)
			.build();

	private static final AnomalyCatalogKey ANOMALY_CATALOG_KEY = new AnomalyCatalogKey(ANOMALY_CODE, MODULE_ID);

	@Mock
	private AnomalyCatalogCrudService anomalyCatalogCrudService;

	@Mock
	private ModuleCrudService moduleCrudService;

	@InjectMocks
	private AnomalyCatalogBundleWorker anomalyCatalogBundleWorker;

	@BeforeEach
	void init() {
		anomalyCatalogBundleWorker = new AnomalyCatalogBundleWorker(anomalyCatalogCrudService, moduleCrudService);
	}

	@Test
	void test_upsertBundleAnomalyCatalogAndWithException() {
		try {
			when(moduleCrudService.findByCode(TENANT, MODULE_CODE)).thenReturn(Optional.of(moduleDTOMock));
			when(anomalyCatalogCrudService.findById(ANOMALY_CATALOG_KEY)).thenReturn(anomalyCatalogDTOMock);

			anomalyCatalogBundleWorker.upsertBundleAnomalyCatalog(TENANT, bundleAnomalyCatalogMessageMock);

			when(anomalyCatalogCrudService.findById(ANOMALY_CATALOG_KEY)).thenThrow(new ObjectNotFoundException("anomaly not found"));

			anomalyCatalogBundleWorker.upsertBundleAnomalyCatalog(TENANT, bundleAnomalyCatalogMessageMock);
		} catch (Exception e) {
			Assertions.fail();
		}
	}

	@Test
	void test_exposeAnomalyCatalogCrudService() {
		try {
			anomalyCatalogBundleWorker.exposeAnomalyCatalogCrudService();
		} catch (Exception e) {
			Assertions.fail();
		}
	}

	@Test
	void test_deleteAnomalyCatalog() {
		try {
			when(moduleCrudService.findByCode(TENANT, MODULE_CODE)).thenReturn(Optional.of(moduleDTOMock));
			when(anomalyCatalogCrudService.getAllAnomalyCatalogI18NByTenantAndCode(TENANT, ANOMALY_CODE)).thenReturn(List.of(rsI18NMock));

			anomalyCatalogBundleWorker.deleteAnomalyCatalog(TENANT, bundleAnomalyCatalogMessageMock);
		} catch (Exception e) {
			Assertions.fail();
		}
	}

}
