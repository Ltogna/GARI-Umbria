package com.abacogroup.agri.dossiers.core.services.workflow;

import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.workflow.server.model.NodeType;
import com.abacogroup.workflow.server.model.WorkflowNode;
import com.abacogroup.workflow.server.services.WorkflowService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

/**
 * The type Dossiers workflow utils test.
 * @author Carlo Sindico
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
class DossiersWorkflowUtilsTest {

    private static final Integer ID = 1;

    private static final String TENANT = "tenant";

    private static final String WORKFLOW_CODE = "workflow_code";

    private static final String ACTION = "action";

    private static final String NAME = "name";

    private static final NodeType NODE_TYPE = NodeType.start;

    private static final String LOCALE = MDC.get(MDCPreFilter.LOCALE);

    private final Map<String, Object> metadataMock = new HashMap<>();

    private final WorkflowNode workflowNodeMock = WorkflowNode.builder()
            .id(ID)
            .action(ACTION)
            .name(NAME)
            .type(NODE_TYPE)
            .metadata(metadataMock)
            .build();

    @Mock
    private WorkflowService workflowService;

    @InjectMocks
    DossiersWorkflowUtils dossiersWorkflowUtils;

    @BeforeEach
    void init() {
        dossiersWorkflowUtils = new DossiersWorkflowUtils(workflowService);
        metadataMock.put("first", "value");
        metadataMock.put("second", "value");
    }

    @Test
    void test_getNodeMetadata() {
        when(workflowService.getWorkflowNode(TENANT, WORKFLOW_CODE, NAME, LOCALE)).thenReturn(workflowNodeMock);

        Map<String, Object> result = dossiersWorkflowUtils.getNodeMetadata(TENANT, WORKFLOW_CODE, NAME, LOCALE);

        assertEquals(workflowNodeMock.getMetadata().get("first"), result.get("first"));
    }

}
