package com.abacogroup.agri.dossiers.bundles.processor.sector;

import com.abacogroup.agri.dossiers.bundles.model.I18nPair;
import com.abacogroup.agri.dossiers.bundles.model.sector.BundleSectorInDTO;
import com.abacogroup.agri.dossiers.bundles.model.sector.BundleSectorsMessage;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

@Slf4j
@ExtendWith(MockitoExtension.class)
class BundleSectorsProcessorTest {

	protected static final String TEMPLATE_TENANT_ID = "*";
	protected static final String DOMAIN_NAME = "sectors";

	protected static final String SECTOR_CODE = "sector_code";
	private static final String DESCRIPTION = "description";
	private static final String LANG = "lang";

	private static final Path PATH = new File("test.json").toPath();

	private final I18nPair sectorI18nMock = I18nPair.builder()
			.description(DESCRIPTION)
			.lang(LANG)
			.build();

	private final BundleSectorInDTO bundleSectorInDTOMock = BundleSectorInDTO.builder()
			.sectorCode(SECTOR_CODE)
			.i18n(List.of(sectorI18nMock))
			.build();

	private final BundleSectorsMessage bundleSectorsMessageMock = BundleSectorsMessage.builder()
			.sectors(List.of(bundleSectorInDTOMock))
			.build();

	private final ConfigDataMessage configDataMessage = new ConfigDataMessage();
	@Mock
	private SectorsBundleWorker sectorsBundleWorker;
	@Mock
	private ObjectMapper objectMapper;
	@Mock
	private Jdbi jdbi;
	@InjectMocks
	private BundleSectorsProcessor bundleSectorsProcessor;

	@BeforeEach
	void init() {
		configDataMessage.setTenantId(TEMPLATE_TENANT_ID);
		bundleSectorsProcessor = new BundleSectorsProcessor(objectMapper, sectorsBundleWorker, jdbi);
	}

	@Test
	void test_getDomainName() {
		assertEquals(DOMAIN_NAME, bundleSectorsProcessor.getDomainName());
	}

	@Test
	void test_getTypeReference() {
		assertEquals(new TypeReference<BundleSectorsMessage>() {
		}.getType(), bundleSectorsProcessor.getTypeReference().getType());
	}

	@Test
	void onMessageInTransaction() {
		try {
			configDataMessage.setConfigFiles(List.of(PATH));
			bundleSectorsProcessor.onMessageInTransaction(configDataMessage);
			verify(objectMapper).readValue(eq(PATH.toFile()), any(TypeReference.class));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_doInsertOrUpdate() {
		bundleSectorsProcessor.doInsertOrUpdate(TEMPLATE_TENANT_ID, bundleSectorsMessageMock);
		verify(sectorsBundleWorker).upsertBundleSectors(TEMPLATE_TENANT_ID, bundleSectorsMessageMock);
	}

	// TODO when delete method is implemented
	@Test
	void test_delete() {
		bundleSectorsProcessor.delete(TEMPLATE_TENANT_ID, bundleSectorsMessageMock);
		assert true;
	}
}
