package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.mappers.AmendableModuleMapper;
import com.abacogroup.agri.dossiers.core.model.dto.AmendableModuleDTO;
import com.abacogroup.agri.dossiers.db.dao.AmendableModuleDAO;
import com.abacogroup.agri.dossiers.db.ntt.AmendableModuleNTT;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AmendableModuleCrudServiceTest {

	private static final String TENANT_ID = "ADMIN";
	private static final Long PKID = 1L;
	private static final Long MODULE_ID = 5L;
	private static final Long AMENDABLE_MODULE_ID = 10L;
	private static final LocalDateTime DEFAULT_NOT_DELETED_DATE = LocalDateTime.ofInstant(Instant.ofEpochSecond(253402300799L), ZoneOffset.UTC);
	private static final LocalDateTime NOW = LocalDateTime.now();
	private static final String USER_ID = "Username";
	private static final AmendableModuleDTO AMENDABLE_MODULE_DTO = AmendableModuleDTO.builder()
			.pkid(PKID)
			.moduleId(MODULE_ID)
			.amendableModuleId(AMENDABLE_MODULE_ID)
			.userIdInsert(USER_ID)
			.userIdDelete(null)
			.dtInsert(NOW)
			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.build();
	private static final AmendableModuleNTT AMENDABLE_MODULE_NTT = AmendableModuleNTT.builder()
			.pkid(PKID)
			.module_id(MODULE_ID)
			.user_id_insert(USER_ID)
			.amendable_module_id(AMENDABLE_MODULE_ID)
			.user_id_delete(null)
			.dt_insert(NOW)
			.dt_delete(DEFAULT_NOT_DELETED_DATE)
			.build();

	@Mock
	private AmendableModuleDAO dao;
	@Mock
	private AmendableModuleMapper amendableModuleMapper;
	@InjectMocks
	private AmendableModuleCrudService amendableModuleCrudService;

	@Test
	void hasPrimaryKey_ok() {
		assertTrue(amendableModuleCrudService.hasPrimaryKey());
	}

	@Test
	void retrieveCustomKeyByResultSet() {
		assertNull(amendableModuleCrudService.retrieveCustomKeyByResultSet(AMENDABLE_MODULE_NTT));
	}

	@Test
	void findRsByCustomKey_ok() {
		assertEquals(Optional.empty(), amendableModuleCrudService.findRsByCustomKey(null));
	}

	@Test
	void findById_ok() {
		try {
			when(dao.findById(PKID))
					.thenReturn(List.of(AMENDABLE_MODULE_NTT));
			when(amendableModuleMapper.entityToDto(AMENDABLE_MODULE_NTT))
					.thenReturn(AMENDABLE_MODULE_DTO);

			AmendableModuleDTO result = amendableModuleCrudService.findById(PKID);

			assertEquals(AMENDABLE_MODULE_DTO, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void findByModuleId_ok() {
		when(dao.findByModuleId(MODULE_ID))
				.thenReturn(List.of(AMENDABLE_MODULE_NTT));
		when(amendableModuleMapper.entityToDto(AMENDABLE_MODULE_NTT))
				.thenReturn(AMENDABLE_MODULE_DTO);

		List<AmendableModuleDTO> result = amendableModuleCrudService.findByModuleId(MODULE_ID);

		assertEquals(List.of(AMENDABLE_MODULE_DTO), result);
	}

	@Test
	void findByAmendableModuleId_ok() {
		when(dao.findByAmendableModuleId(TENANT_ID, AMENDABLE_MODULE_ID))
				.thenReturn(List.of(AMENDABLE_MODULE_NTT));
		when(amendableModuleMapper.entityToDto(AMENDABLE_MODULE_NTT))
				.thenReturn(AMENDABLE_MODULE_DTO);

		List<AmendableModuleDTO> result = amendableModuleCrudService.findByAmendableModuleId(TENANT_ID, AMENDABLE_MODULE_ID);

		assertEquals(List.of(AMENDABLE_MODULE_DTO), result);
	}

	@Test
	void findByModuleIdAndAmendableModuleId_ok() {
		try {
			when(dao.findByModuleIdAndAmendableModuleId(AMENDABLE_MODULE_ID, MODULE_ID))
					.thenReturn(AMENDABLE_MODULE_NTT);
			when(amendableModuleMapper.entityToDto(AMENDABLE_MODULE_NTT))
					.thenReturn(AMENDABLE_MODULE_DTO);

			AmendableModuleDTO result = amendableModuleCrudService.findByModuleIdAndAmendableModuleId(MODULE_ID, AMENDABLE_MODULE_ID);

			assertEquals(AMENDABLE_MODULE_DTO, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void findAllByTenant_ok() {
		when(dao.findAllByTenant(TENANT_ID))
				.thenReturn(List.of(AMENDABLE_MODULE_NTT));
		when(amendableModuleMapper.entityToDto(AMENDABLE_MODULE_NTT))
				.thenReturn(AMENDABLE_MODULE_DTO);

		List<AmendableModuleDTO> result = amendableModuleCrudService.findAllByTenant(TENANT_ID);

		assertEquals(List.of(AMENDABLE_MODULE_DTO), result);
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void insert_ok() {
		AmendableModuleDTO in = AmendableModuleDTO.builder()
				.amendableModuleId(AMENDABLE_MODULE_ID)
				.moduleId(MODULE_ID)
				.build();

		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.nextSequenceVal())
					.thenReturn(MODULE_ID);
			when(dao.findById(MODULE_ID))
					.thenReturn(List.of(AMENDABLE_MODULE_NTT));
			when(amendableModuleMapper.dtoToEntity(in))
					.thenReturn(AMENDABLE_MODULE_NTT);
			when(amendableModuleMapper.entityToDto(AMENDABLE_MODULE_NTT))
					.thenReturn(AMENDABLE_MODULE_DTO);

			amendableModuleCrudService.insert(in, USER_ID);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
			AmendableModuleDTO result = (AmendableModuleDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(AMENDABLE_MODULE_DTO, result);

		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void update_ok() {
		AmendableModuleDTO in = AmendableModuleDTO.builder()
				.amendableModuleId(AMENDABLE_MODULE_ID)
				.moduleId(MODULE_ID)
				.build();
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(dao.getCurrentTimestamp())
					.thenReturn(LocalDateTime.now());
			when(dao.inTransaction(handleConsumerLambdaCaptor.capture()))
					.thenReturn(AMENDABLE_MODULE_DTO);

			amendableModuleCrudService.update(MODULE_ID, in, USER_ID);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
			AmendableModuleDTO result = (AmendableModuleDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(AMENDABLE_MODULE_DTO, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void delete_ok() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			amendableModuleCrudService.delete(MODULE_ID, USER_ID);

			verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useTransaction(dao);

			verify(dao, times(1)).logicallyDeleteById(eq(MODULE_ID), eq(USER_ID), any());
		} catch (Exception e) {
			fail(e);
		}
	}

}
