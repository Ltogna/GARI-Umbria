package com.abacogroup.agri.dossiers.core.model;

import com.abacogroup.agri.dossiers.db.dao.IGenericHistoricizationFieldsDAO;
import com.abacogroup.agri.dossiers.db.ntt.AmendableModuleNTT;
import com.abacogroup.agri.dossiers.db.ntt.DossierNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;

import java.time.LocalDateTime;
import java.util.List;

// Mock DAO for unit tests
public interface MockGenericHistoricizationFieldsDAO extends IGenericHistoricizationFieldsDAO<DossierNTT, Long, Long> {

    @Override
    Long nextSequenceVal();

    @Override
    void insert(@BindBean DossierNTT rs, @Bind("user_id") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

    @Override
    @RegisterBeanMapper(AmendableModuleNTT.class)
    List<DossierNTT> findById(@Bind("id") Long id);

    @Override
    void logicallyDeleteByCustomKey(@Bind("custom_key") Long customKey, @Bind("user_id_delete") String userIdDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);
}
