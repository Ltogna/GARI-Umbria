package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.mappers.ModuleProfileMapper;
import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import com.abacogroup.agri.dossiers.core.services.I18NService;
import com.abacogroup.agri.dossiers.db.dao.ModuleProfileDAO;
import com.abacogroup.agri.dossiers.db.ntt.ModuleProfileNTT;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static com.abacogroup.agri.dossiers.core.services.crud.ModuleProfilesCrudService.I18N_DOSSIER_PROFILES_TABLE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ModuleProfilesCrudServiceTest  {

	private static final String TENANT_ID_1 = "tenant_1";
	private static final Long PK_ID_1 = 1L;
	private static final String USER_ID = "user1";
	private static final String PROFILE_CODE_1 = "code1";
	private static final Long MODULE_ID_1 = 1L;
	private static final String MODULE_CODE_1 = "modulecode";
	private static final String SECTOR_CODE_1 = "sectorcode";
	private static final String LANG = "lang";
	private static final String TEXT = "text";
	private static final AbsoluteDate POINT_IN_TIME = new AbsoluteDate(LocalDate.now());

	private final ModuleProfileDTO moduleProfileDTO = ModuleProfileDTO.builder()
			.pkid(PK_ID_1)
			.profileCode(PROFILE_CODE_1)
			.moduleId(MODULE_ID_1)
			.build();
	private final ModuleProfileNTT moduleProfileNTT = ModuleProfileNTT.builder()
			.profile_code(PROFILE_CODE_1)
			.pkid(PK_ID_1)
			.module_id(MODULE_ID_1)
			.build();

	@Mock
	private I18NService i18NService;
	@Mock
	private ModuleProfileDAO dao;
	@Mock
	private ModuleProfileMapper dossierProfileMapper;
	@InjectMocks
	private ModuleProfilesCrudService moduleProfilesCrudService;

	@Test
	void test_hasPrimaryKey() {
		assertTrue(moduleProfilesCrudService.hasPrimaryKey());
	}

	@Test
	void test_retrieveCustomKeyByResultSet() {
		assertNull(moduleProfilesCrudService.retrieveCustomKeyByResultSet(moduleProfileNTT));
	}

	@Test
	void test_findRsByCustomKey() {
		assertEquals(Optional.empty(), moduleProfilesCrudService.findRsByCustomKey(null));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_insert() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.nextSequenceVal())
					.thenReturn(PK_ID_1);
			when(dao.findById(PK_ID_1))
					.thenReturn(List.of(moduleProfileNTT));
			when(dossierProfileMapper.dtoToEntity(moduleProfileDTO))
					.thenReturn(moduleProfileNTT);
			when(dossierProfileMapper.entityToDto(moduleProfileNTT))
					.thenReturn(moduleProfileDTO);

			moduleProfilesCrudService.insert(moduleProfileDTO, USER_ID);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			ModuleProfileDTO result = (ModuleProfileDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(moduleProfileDTO, result);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_update() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(dao.getCurrentTimestamp())
					.thenReturn(LocalDateTime.now());
			when(dao.inTransaction(handleConsumerLambdaCaptor.capture()))
					.thenReturn(moduleProfileDTO);

			moduleProfilesCrudService.update(PK_ID_1, moduleProfileDTO, USER_ID);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			ModuleProfileDTO result = (ModuleProfileDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(moduleProfileDTO, result);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findByModuleId() {
		try {
			when(dao.findByModuleId(TENANT_ID_1, MODULE_ID_1, null))
					.thenReturn(List.of(moduleProfileNTT));
			when(dossierProfileMapper.entityToDto(moduleProfileNTT))
					.thenReturn(moduleProfileDTO);

			assertEquals(List.of(moduleProfileDTO), moduleProfilesCrudService.find(TENANT_ID_1, MODULE_ID_1));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findByCode() {
		try {
			when(dao.infinite(any(), any(), anyInt()))
					.thenReturn(new InfiniteListResultsImpl<>(List.of(moduleProfileNTT), null));
			when(dossierProfileMapper.entityToDto(moduleProfileNTT))
					.thenReturn(moduleProfileDTO);

			assertEquals(List.of(moduleProfileDTO),
					moduleProfilesCrudService.find(TENANT_ID_1, SECTOR_CODE_1, MODULE_CODE_1, POINT_IN_TIME, null).getRecords());
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_delete() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			when(dao.getCurrentTimestamp())
					.thenReturn(LocalDateTime.now());

			moduleProfilesCrudService.delete(PK_ID_1, USER_ID);

			verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useTransaction(dao);

			verify(dao).logicallyDeleteById(eq(PK_ID_1), eq(USER_ID), any(LocalDateTime.class));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_deleteByModuleId() {
		try {
			moduleProfilesCrudService.deleteByModuleId(MODULE_ID_1, USER_ID);

			verify(dao).logicallyDeleteByModuleId(eq(MODULE_ID_1), eq(USER_ID), any(LocalDateTime.class));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_insertModuleProfileI18N() {
		try {
			moduleProfilesCrudService.insertModuleProfileI18N(TENANT_ID_1, PROFILE_CODE_1, LANG, TEXT);

			verify(i18NService).insertI18N(TENANT_ID_1, I18N_DOSSIER_PROFILES_TABLE,
					ModuleProfilesCrudService.DOSSIER_PROFILES_I18N.PROFILE_CODE.getCode(),
					LANG, PROFILE_CODE_1,
					TEXT);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_verifyI18NIsPresent() {
		when(i18NService.isI18NPresent(TENANT_ID_1, I18N_DOSSIER_PROFILES_TABLE,
				ModuleProfilesCrudService.DOSSIER_PROFILES_I18N.PROFILE_CODE.getCode(),
				PROFILE_CODE_1, LANG, TEXT))
				.thenReturn(true);

		assertTrue(moduleProfilesCrudService.verifyI18NIsPresent(TENANT_ID_1, PROFILE_CODE_1, LANG, TEXT));
	}

	@Test
	void test_deleteModuleProfileI18N() {
		try {
			moduleProfilesCrudService.deleteModuleProfileI18N(TENANT_ID_1, PROFILE_CODE_1, LANG);

			verify(i18NService).deleteI18N(TENANT_ID_1, I18N_DOSSIER_PROFILES_TABLE,
					ModuleProfilesCrudService.DOSSIER_PROFILES_I18N.PROFILE_CODE.getCode(), PROFILE_CODE_1,
					LANG);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_getAllModuleProfileI18NByTenantAndCode() {
		try {
			moduleProfilesCrudService.getAllModuleProfileI18NByTenantAndCode(TENANT_ID_1, PROFILE_CODE_1);

			verify(i18NService).getAllI18NbyCode(TENANT_ID_1, I18N_DOSSIER_PROFILES_TABLE, PROFILE_CODE_1);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findById() {
		try {
			when(dao.findById(PK_ID_1))
					.thenReturn(List.of(moduleProfileNTT));
			when(dossierProfileMapper.entityToDto(moduleProfileNTT))
					.thenReturn(moduleProfileDTO);

			assertEquals(moduleProfileDTO, moduleProfilesCrudService.findById(PK_ID_1));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}

	}

	@Test
	void test_find() {
		when(dao.findByModuleIdAndProfileCode(TENANT_ID_1, MODULE_ID_1, PROFILE_CODE_1))
				.thenReturn(List.of(moduleProfileNTT));
		when(dossierProfileMapper.entityToDto(moduleProfileNTT))
				.thenReturn(moduleProfileDTO);

		assertEquals(moduleProfileDTO, moduleProfilesCrudService.find(TENANT_ID_1, MODULE_ID_1, PROFILE_CODE_1));
	}

	@Test
	void findWithLocale_ok() {
		when(dao.findByModuleId(TENANT_ID_1, MODULE_ID_1, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(moduleProfileNTT));
		when(dossierProfileMapper.entityToDto(moduleProfileNTT))
				.thenReturn(moduleProfileDTO);

		List<ModuleProfileDTO> result = moduleProfilesCrudService.findWithLocale(TENANT_ID_1, MODULE_ID_1, MDC.get(MDCPreFilter.LOCALE));

		assertEquals(List.of(moduleProfileDTO), result);
	}
}
