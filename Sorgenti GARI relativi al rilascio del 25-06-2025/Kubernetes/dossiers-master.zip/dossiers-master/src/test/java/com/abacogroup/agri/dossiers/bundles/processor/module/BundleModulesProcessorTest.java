package com.abacogroup.agri.dossiers.bundles.processor.module;

import com.abacogroup.agri.dossiers.bundles.model.I18nPair;
import com.abacogroup.agri.dossiers.bundles.model.module.BundleModuleInDTO;
import com.abacogroup.agri.dossiers.bundles.model.module.BundleModulesMessage;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

@Slf4j
@ExtendWith(MockitoExtension.class)
class BundleModulesProcessorTest {

	protected static final String TEMPLATE_TENANT_ID = "*";
	protected static final String DOMAIN_NAME = "modules";

	protected static final String SECTOR_CODE = "module_code";
	private static final String DESCRIPTION = "description";
	private static final String LANG = "lang";

	private static final Path PATH = new File("test.json").toPath();

	private final I18nPair moduleI18nMock = I18nPair.builder()
			.description(DESCRIPTION)
			.lang(LANG)
			.build();

	private final BundleModuleInDTO bundleModuleInDTOMock = BundleModuleInDTO.builder()
			.moduleCode(SECTOR_CODE)
			.i18n(List.of(moduleI18nMock))
			.build();

	private final BundleModulesMessage bundleModulesMessageMock = BundleModulesMessage.builder()
			.modules(List.of(bundleModuleInDTOMock))
			.build();

	private final ConfigDataMessage configDataMessage = new ConfigDataMessage();
	@Mock
	private ModulesBundleWorker modulesBundleWorker;
	@Mock
	private ObjectMapper objectMapper;
	@Mock
	private Jdbi jdbi;
	@InjectMocks
	private BundleModulesProcessor bundleModulesProcessor;

	@BeforeEach
	void init() {
		configDataMessage.setTenantId(TEMPLATE_TENANT_ID);
		bundleModulesProcessor = new BundleModulesProcessor(objectMapper, modulesBundleWorker, jdbi);
	}

	@Test
	void test_getDomainName() {
		assertEquals(DOMAIN_NAME, bundleModulesProcessor.getDomainName());
	}

	@Test
	void test_getTypeReference() {
		assertEquals(new TypeReference<BundleModulesMessage>() {
		}.getType(), bundleModulesProcessor.getTypeReference().getType());
	}

	@Test
	void onMessageInTransaction() {
		try {
			configDataMessage.setConfigFiles(List.of(PATH));
			bundleModulesProcessor.onMessageInTransaction(configDataMessage);
			verify(objectMapper).readValue(eq(PATH.toFile()), any(TypeReference.class));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_doInsertOrUpdate() {
		bundleModulesProcessor.doInsertOrUpdate(TEMPLATE_TENANT_ID, bundleModulesMessageMock);
		verify(modulesBundleWorker).insertBundleModules(TEMPLATE_TENANT_ID, bundleModulesMessageMock);
	}

	// TODO when delete method is implemented
	@Test
	void test_delete() {
		bundleModulesProcessor.delete(TEMPLATE_TENANT_ID, bundleModulesMessageMock);
		assert true;
	}
}
