package com.abacogroup.agri.dossiers.core.caller;

import com.abacogroup.jaxrsutils.GenericCallerService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class GetPartiesRegistryCallerTest {
    @Test
    void constructor_ok() {
        GenericCallerService genericCallerService = mock(GenericCallerService.class);

        GetPartiesRegistryCaller getPartiesRegistryCaller = new GetPartiesRegistryCaller(genericCallerService);

        assertNotNull(getPartiesRegistryCaller);
    }
}