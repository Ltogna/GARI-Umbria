package com.abacogroup.agri.dossiers.core.services;

import com.abacogroup.agri.dossiers.core.exceptions.DossierNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.model.dto.AmendableModuleDTO;
import com.abacogroup.agri.dossiers.core.model.dto.DossierDetailsDTO;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleDTO;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleWithDetailDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierWithDetailsDTO;
import com.abacogroup.agri.dossiers.core.services.crud.AmendableModuleCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossierDetailsCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.ModuleCrudService;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import jakarta.ws.rs.core.SecurityContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AmendmentServiceTest {
	@Mock
	DossiersCrudService dossiersCrudService;
	@Mock
	ModuleCrudService moduleCrudService;
	@Mock
	AmendableModuleCrudService amendableModuleCrudService;
	@Mock
	DossierDetailsCrudService dossierDetailsCrudService;

	@InjectMocks
	AmendmentService amendmentService;

	private static final String TENANT = "ADMIN";
	private static final Long DOSSIER_ID = 5L;
	private static final Long AMENDED_DOSSIER_ID = 20L;
	private static final String PROCESS_STATUS_DELETED = "DELETED";
	private static final String PROCESS_STATUS_PROTOCOLED = "PROTOCOLED";
	private static final String PROCESS_STATUS_COMPLIANT = "COMPLIANT";
	private static final String PROCESS_STATUS_IN_COMPILATION = "IN_COMPILATION";
	private static final Integer FIND_ONLY_AMEND_MODULES = 1;
	private static final Long MODULE_ID = 10L;
	private static final Long AMENDABLE_MODULE_ID = 20L;
	private static final Long SECTOR_ID = 15L;
	private static final Long PKID = 1L;
	private static final String MODULE_CODE = "Module Code";
	private static final String WORKFLOW_CODE = "Workflow Code";
	private static final Integer REFERRED_YEAR = 2023;
	private static final String NEXT_KEY = "Next Key";

	private final DossierDetailsDTO dossierDetailsProtocoled = DossierDetailsDTO.builder()
			.pkid(PKID)
			.dossierId(DOSSIER_ID)
			.dossierCode(DOSSIER_ID.toString())
			.processStatus(PROCESS_STATUS_PROTOCOLED)
			.build();
	private final DossierDetailsDTO dossierDetailsCompliant = DossierDetailsDTO.builder()
			.pkid(PKID)
			.dossierId(DOSSIER_ID)
			.dossierCode(DOSSIER_ID.toString())
			.processStatus(PROCESS_STATUS_COMPLIANT)
			.build();
	private final DossierDetailsDTO dossierDetailsInCompilation = DossierDetailsDTO.builder()
			.pkid(PKID)
			.dossierId(DOSSIER_ID)
			.dossierCode(DOSSIER_ID.toString())
			.processStatus(PROCESS_STATUS_IN_COMPILATION)
			.build();
	private final ModuleDTO module = ModuleDTO.builder()
			.moduleId(MODULE_ID)
			.sectorId(SECTOR_ID)
			.moduleCode(MODULE_CODE)
			.workflowCode(WORKFLOW_CODE)
			.flAmendModule(false)
			.build();
	private final AmendableModuleDTO amendableModule = AmendableModuleDTO.builder()
			.moduleId(MODULE_ID)
			.amendableModuleId(AMENDABLE_MODULE_ID)
			.build();
	private final ModuleWithDetailDTO moduleWithDetail = ModuleWithDetailDTO.builder()
			.moduleId(MODULE_ID)
			.moduleCode(MODULE_CODE)
			.workflowCode(WORKFLOW_CODE)
			.sectorId(SECTOR_ID)
			.annuality(REFERRED_YEAR)
			.build();
	private final ModuleWithDetailDTO moduleWithDetailWithContextFunction = ModuleWithDetailDTO.builder()
			.moduleId(MODULE_ID)
			.moduleCode(MODULE_CODE)
			.workflowCode(WORKFLOW_CODE)
			.sectorId(SECTOR_ID)
			.annuality(REFERRED_YEAR)
			.contextFunction(SecurityContext.BASIC_AUTH)
			.build();
	private final DossierWithDetailsDTO dossierWithDetailsInCompilation = DossierWithDetailsDTO.builder()
			.dossierId(DOSSIER_ID)
			.dossierCode(DOSSIER_ID.toString())
			.moduleId(MODULE_ID)
			.referredYear(REFERRED_YEAR)
			.processStatus(PROCESS_STATUS_IN_COMPILATION)
			.build();
	private final DossierWithDetailsDTO dossierWithDetails = DossierWithDetailsDTO.builder()
			.dossierId(DOSSIER_ID)
			.dossierCode(DOSSIER_ID.toString())
			.moduleId(MODULE_ID)
			.referredYear(REFERRED_YEAR)
			.processStatus(PROCESS_STATUS_PROTOCOLED)
			.amendedDossierId(AMENDED_DOSSIER_ID)
			.build();
	private final DossierWithDetailsDTO amendedDossierWithDetails = DossierWithDetailsDTO.builder()
			.dossierId(AMENDED_DOSSIER_ID)
			.dossierCode(AMENDED_DOSSIER_ID.toString())
			.moduleId(MODULE_ID)
			.referredYear(REFERRED_YEAR)
			.processStatus(PROCESS_STATUS_PROTOCOLED)
			.build();
	private final DossierWithDetailsDTO dossierWithDetailsDeleted = DossierWithDetailsDTO.builder()
			.dossierId(DOSSIER_ID)
			.dossierCode(DOSSIER_ID.toString())
			.moduleId(MODULE_ID)
			.referredYear(REFERRED_YEAR)
			.processStatus(PROCESS_STATUS_DELETED)
			.build();
	private final DossierDTO dossier = DossierDTO.builder()
			.dossierId(DOSSIER_ID)
			.referredYear(REFERRED_YEAR)
			.moduleId(MODULE_ID)
			.build();

	@Test
	void checkAmendmentStatus_protocoled_true_ok() {
		try {
			when(dossierDetailsCrudService.findDossierDetailById(TENANT, DOSSIER_ID))
					.thenReturn(dossierDetailsProtocoled);
			when(moduleCrudService.findByCode(TENANT, MODULE_CODE))
					.thenReturn(Optional.of(module));
			when(amendableModuleCrudService.findByAmendableModuleId(TENANT, MODULE_ID))
					.thenReturn(List.of(amendableModule));
			when(moduleCrudService.findValidAmendModulesWithDetailByModuleId(eq(TENANT), eq(MODULE_ID), eq(FIND_ONLY_AMEND_MODULES), any()))
					.thenReturn(List.of(moduleWithDetail));

			assertTrue(amendmentService.checkAmendmentStatus(TENANT, DOSSIER_ID, MODULE_CODE));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkAmendmentStatus_compliant_true_ok() {
		try {
			when(dossierDetailsCrudService.findDossierDetailById(TENANT, DOSSIER_ID))
					.thenReturn(dossierDetailsCompliant);
			when(moduleCrudService.findByCode(TENANT, MODULE_CODE))
					.thenReturn(Optional.of(module));
			when(amendableModuleCrudService.findByAmendableModuleId(TENANT, MODULE_ID))
					.thenReturn(List.of(amendableModule));
			when(moduleCrudService.findValidAmendModulesWithDetailByModuleId(eq(TENANT), eq(MODULE_ID), eq(FIND_ONLY_AMEND_MODULES), any()))
					.thenReturn(List.of(moduleWithDetail));

			assertTrue(amendmentService.checkAmendmentStatus(TENANT, DOSSIER_ID, MODULE_CODE));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkAmendmentStatus_inCompilation_false_ok() {
		try {
			when(dossierDetailsCrudService.findDossierDetailById(TENANT, DOSSIER_ID))
					.thenReturn(dossierDetailsInCompilation);
			when(moduleCrudService.findByCode(TENANT, MODULE_CODE))
					.thenReturn(Optional.of(module));
			when(amendableModuleCrudService.findByAmendableModuleId(TENANT, MODULE_ID))
					.thenReturn(List.of(amendableModule));
			when(moduleCrudService.findValidAmendModulesWithDetailByModuleId(eq(TENANT), eq(MODULE_ID), eq(FIND_ONLY_AMEND_MODULES), any()))
					.thenReturn(List.of(moduleWithDetail));

			assertFalse(amendmentService.checkAmendmentStatus(TENANT, DOSSIER_ID, MODULE_CODE));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkAmendmentStatus_moduleNotPresent_false_ok() {
		try {
			when(dossierDetailsCrudService.findDossierDetailById(TENANT, DOSSIER_ID))
					.thenReturn(dossierDetailsInCompilation);
			when(moduleCrudService.findByCode(TENANT, MODULE_CODE))
					.thenReturn(Optional.empty());

			assertFalse(amendmentService.checkAmendmentStatus(TENANT, DOSSIER_ID, MODULE_CODE));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkAmendmentStatus_ko() {
		try {
			when(dossierDetailsCrudService.findDossierDetailById(TENANT, DOSSIER_ID))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(ObjectNotFoundRuntimeException.class, () ->
					amendmentService.checkAmendmentStatus(TENANT, DOSSIER_ID, MODULE_CODE));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void isAmendModule_true_ok() {
		when(moduleCrudService.findValidAmendModulesWithDetailByModuleId(eq(TENANT), eq(MODULE_ID), eq(FIND_ONLY_AMEND_MODULES), any()))
				.thenReturn(List.of(moduleWithDetail));

		assertTrue(amendmentService.isAmendModule(TENANT, MODULE_ID));
	}

	@Test
	void isAmendModule_false_ok() {
		when(moduleCrudService.findValidAmendModulesWithDetailByModuleId(eq(TENANT), eq(MODULE_ID), eq(FIND_ONLY_AMEND_MODULES), any()))
				.thenReturn(List.of());

		assertFalse(amendmentService.isAmendModule(TENANT, MODULE_ID));
	}

	@Test
	void isDossierAmendable_true_ok() {
		try {
			when(dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID))
					.thenReturn(dossierWithDetailsInCompilation);

			assertTrue(amendmentService.isDossierAmendable(TENANT, DOSSIER_ID));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void isDossierAmendable_notPresent_false_ok() {
		try {
			when(dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID))
					.thenReturn(null);

			assertFalse(amendmentService.isDossierAmendable(TENANT, DOSSIER_ID));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void isDossierAmendable_deleted_false_ok() {
		try {
			when(dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID))
					.thenReturn(dossierWithDetailsDeleted);

			assertFalse(amendmentService.isDossierAmendable(TENANT, DOSSIER_ID));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void isDossierAmendable_DossierNotFoundRuntimeException_false_ok() {
		try {
			when(dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID))
					.thenThrow(DossierNotFoundRuntimeException.class);

			assertFalse(amendmentService.isDossierAmendable(TENANT, DOSSIER_ID));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void getAmendmentModules_ok() {
		SecurityContext securityContext = mock(SecurityContext.class);

		when(dossiersCrudService.findById(DOSSIER_ID))
				.thenReturn(Optional.of(dossier));
		when(amendableModuleCrudService.findByAmendableModuleId(TENANT, MODULE_ID))
				.thenReturn(List.of(amendableModule));
		when(moduleCrudService.findModulesWithDetailByModuleIds(eq(TENANT), eq(List.of(MODULE_ID)), eq(FIND_ONLY_AMEND_MODULES), any()))
				.thenReturn(List.of(moduleWithDetail, moduleWithDetailWithContextFunction));
		when(securityContext.isUserInRole(SecurityContext.BASIC_AUTH))
				.thenReturn(true);

		InfiniteListResults<ModuleWithDetailDTO> result =
				amendmentService.getAmendmentModules(TENANT, DOSSIER_ID, NEXT_KEY, securityContext);

		assertEquals(List.of(moduleWithDetail, moduleWithDetailWithContextFunction), result.getRecords());
	}

	@Test
	void getAmendmentModules_ko() {
		SecurityContext securityContext = mock(SecurityContext.class);

		when(dossiersCrudService.findById(DOSSIER_ID))
				.thenReturn(Optional.empty());

		assertThrows(DossierNotFoundRuntimeException.class, () ->
				amendmentService.getAmendmentModules(TENANT, DOSSIER_ID, NEXT_KEY, securityContext));
	}

	@Test
	void getOriginalAmendedDossierId_ok() {
		when(dossiersCrudService.findWithDetailsByDossierId(TENANT, AMENDED_DOSSIER_ID))
				.thenReturn(dossierWithDetails, amendedDossierWithDetails);

		Long result = amendmentService.getOriginalAmendedDossierId(dossierWithDetails, TENANT);

		assertEquals(AMENDED_DOSSIER_ID, result);
	}

	@Test
	void getOriginalAmendedDossierId_null_ok() {
		assertNull(amendmentService.getOriginalAmendedDossierId(amendedDossierWithDetails, TENANT));
	}
}
