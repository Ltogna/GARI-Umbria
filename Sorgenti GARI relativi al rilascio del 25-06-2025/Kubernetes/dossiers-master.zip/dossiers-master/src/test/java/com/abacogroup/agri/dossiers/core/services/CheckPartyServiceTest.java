package com.abacogroup.agri.dossiers.core.services;

import com.abacogroup.agri.dossiers.core.caller.CheckCanReadPartyCaller;
import com.abacogroup.agri.dossiers.core.exceptions.ActionNotAuthorizedRuntimeException;
import com.abacogroup.agri.dossiers.core.model.CheckCanReadConfig;
import com.abacogroup.agri.dossiers.core.model.CheckCanReadDTO;
import com.abacogroup.agri.dossiers.core.model.dto.DossierEnvDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierEnvCrudService;
import com.abacogroup.agri.dossiers.db.ntt.compoundkeys.DossierEnvKey;
import com.abacogroup.dropwizard.auth.sso2.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * The type Check party service test.
 *
 * @author Carlo Sindico
 */
@ExtendWith(MockitoExtension.class)
class CheckPartyServiceTest {

    private static final String TENANT = "tenant";
    private static final Long PARTY_ID = 1L;
    private static final String CHECK_CAN_READ_CONFIG_KEY = "CHECK_CAN_READ_CONFIG_KEY";
    private static final String CHECK_CAN_READ_CONFIG_VALUE = "CHECK_CAN_READ_CONFIG_VALUE";

    private final User userMock = new User("name", TENANT);

    private final DossierEnvKey dossierEnvKeyMock = DossierEnvKey.builder()
            .key_(CHECK_CAN_READ_CONFIG_KEY)
            .tenant_id(TENANT)
            .fl_client(0)
            .build();

    private final DossierEnvDTO dossierEnvDTOMock = DossierEnvDTO.builder()
            .key(CHECK_CAN_READ_CONFIG_KEY)
            .tenant(TENANT)
            .value(CHECK_CAN_READ_CONFIG_VALUE)
            .flClient(0)
            .build();

    private final CheckCanReadDTO checkCanReadDTO = CheckCanReadDTO.builder()
            .canRead(true)
            .build();

    private final CheckCanReadDTO checkCanReadDTOKo = CheckCanReadDTO.builder()
            .canRead(false)
            .build();

    @Mock
    private CheckCanReadPartyCaller checkCanReadPartyCaller;
    @Mock
    private DossierEnvCrudService dossierEnvCrudService;
    @Mock
    private CheckCanReadConfig checkCanReadConfig;
    @Mock
    private CheckCanReadConfig checkCanReadAllPartiesConfig;

    @InjectMocks
    private CheckPartyService checkPartyService;

    @BeforeEach
    void init() {
        checkPartyService = new CheckPartyService(checkCanReadPartyCaller, dossierEnvCrudService, checkCanReadConfig, checkCanReadAllPartiesConfig);
    }

    @Test
    void test_makeCall_ok() {
        try {
            when(checkCanReadConfig.getActive()).thenReturn(true);
            when(checkCanReadConfig.getKey()).thenReturn(CHECK_CAN_READ_CONFIG_KEY);
            when(dossierEnvCrudService.findEnvironmentByKey(dossierEnvKeyMock)).thenReturn(dossierEnvDTOMock);
            when(checkCanReadPartyCaller.makeCall(any())).thenReturn(checkCanReadDTO);

            checkPartyService.checkCanReadParty(TENANT, PARTY_ID, userMock);
        } catch (Exception e) {
            fail();
        }
    }

    @Test
    void test_makeCall_ko() {
        try {
            when(checkCanReadConfig.getActive()).thenReturn(true);
            when(checkCanReadConfig.getKey()).thenReturn(CHECK_CAN_READ_CONFIG_KEY);
            when(dossierEnvCrudService.findEnvironmentByKey(dossierEnvKeyMock)).thenReturn(dossierEnvDTOMock);
            when(checkCanReadPartyCaller.makeCall(any())).thenReturn(checkCanReadDTOKo);

            assertThrows(ActionNotAuthorizedRuntimeException.class, () -> checkPartyService.checkCanReadParty(TENANT, PARTY_ID, userMock));
        } catch (Exception e) {
            fail();
        }
    }

}
