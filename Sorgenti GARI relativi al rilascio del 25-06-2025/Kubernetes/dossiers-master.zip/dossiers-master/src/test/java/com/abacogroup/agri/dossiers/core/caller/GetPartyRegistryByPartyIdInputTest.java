package com.abacogroup.agri.dossiers.core.caller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;

import static com.abacogroup.jaxrsutils.GenericCallerService.GET_METHOD;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class GetPartyRegistryByPartyIdInputTest {
    private GetPartyRegistryByPartyIdInput getPartyRegistryByPartyIdInput;

    private static final String TENANT = "ADMIN";
    private static final Long PARTY_ID = 123456789L;
    private static final String AUTH_TOKEN = "Auth Token";
    private static final String PARTY_REGISTRY_URL = "Party Registry URL";
    private static final String RESOURCE_URL = "Resource URL";

    @BeforeEach
    void init() {
        getPartyRegistryByPartyIdInput =
                new GetPartyRegistryByPartyIdInput(TENANT, PARTY_ID, AUTH_TOKEN, PARTY_REGISTRY_URL, RESOURCE_URL);
    }

    @Test
    void getPathVariablesMap_ok() {
        Map<String, Object> expectedOutput = Map.of("tenant", TENANT,
                "partyId", PARTY_ID);

        Map<String, Object> result = getPartyRegistryByPartyIdInput.getPathVariablesMap();

        assertEquals(expectedOutput, result);
    }

    @Test
    void provideAuthToken_ok() {
        String result = getPartyRegistryByPartyIdInput.provideAuthToken();

        assertEquals(AUTH_TOKEN, result);
    }

    @Test
    void getQueryParamsMap_ok() {
        Map<String, Object> result = getPartyRegistryByPartyIdInput.getQueryParamsMap();

        assertEquals(Map.of(), result);
    }

    @Test
    void getUrl_ok() {
        String expectedOutput = PARTY_REGISTRY_URL + RESOURCE_URL;

        String result = getPartyRegistryByPartyIdInput.getUrl();

        assertEquals(expectedOutput, result);
    }

    @Test
    void getHttpMethod_ok() {
        String result = getPartyRegistryByPartyIdInput.getHttpMethod();

        assertEquals(GET_METHOD, result);
    }
}