package com.abacogroup.agri.dossiers.core.services.workflow;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.model.DossiersCommitPayload;
import com.abacogroup.agri.dossiers.core.model.ProcessTransitionEnum;
import com.abacogroup.agri.dossiers.core.services.crud.DossierDetailsCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.embeddedqueue.AbstractWorkQueue;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;
import java.util.Map;

import static com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService.FIND_EXPIRED;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.*;
@Disabled
@ExtendWith(MockitoExtension.class)
class DossierProcessListenerTest {
	@Mock
	private DossiersCrudService dossiersCrudServiceMock;
	@Mock
	private DossierDetailsCrudService dossierDetailsCrudServiceMock;
	@Mock
	private DossiersWorkflowService dossiersWorkflowServiceMock;
	@Mock
	private AbstractWorkQueue<DossiersCommitPayload, ?> msgQueue;
	@Mock
	private Jdbi jdbiMock;

	@InjectMocks
	DossierProcessListener dossierProcessListener;

	private static final Long PROCESS_ID = 1L;
	private static final String CURRENT_NODE = "current_node";
	private static final String EXCPTION_MESSAGE = "exception message thrown";

	@Test
	void onProcessCreated_ok() {
		Map<String, Object> globalVars = Map.of(ApplicationsWorkflowParams.KEY, new ApplicationsWorkflowParams());
		ProcessTransitionResult.TransitionLog transitionLogMock = mock(ProcessTransitionResult.TransitionLog.class);
		transitionLogMock.getStartDate();
		List<WorkflowMessage> messages = List.of(new WorkflowMessage());
		ProcessTransitionResult processTransitionResult = ProcessTransitionResult.builder()
				.processId(PROCESS_ID)
				.currentNode(CURRENT_NODE)
				.globalVars(globalVars)
				.lastTransitionLog(transitionLogMock)
				.messages(messages)
				.build();
		ApplicationsWorkflowParams params = (ApplicationsWorkflowParams) globalVars.get(ApplicationsWorkflowParams.KEY);

		try {
			dossierProcessListener.onProcessCreated(processTransitionResult);

			verify(dossiersCrudServiceMock, times(1))
					.getDossierAndUpdateProcessId(params.getTenant(), params.getApplicationId(), processTransitionResult.getProcessId(), FIND_EXPIRED);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void onTransitionCompleted_ok() {
		Map<String, Object> globalVars = Map.of(ApplicationsWorkflowParams.KEY, new ApplicationsWorkflowParams());
		ProcessTransitionResult.TransitionLog transitionLogMock = mock(ProcessTransitionResult.TransitionLog.class);
		lenient().when(transitionLogMock.getStartDate()).thenReturn(Instant.ofEpochSecond(0));
		List<WorkflowMessage> messages = List.of(new WorkflowMessage());
		ProcessTransitionResult processTransitionResult = ProcessTransitionResult.builder()
				.processId(PROCESS_ID)
				.currentNode(CURRENT_NODE)
				.globalVars(globalVars)
				.lastTransitionLog(transitionLogMock)
				.messages(messages)
				.build();
		ApplicationsWorkflowParams params = (ApplicationsWorkflowParams) globalVars.get(ApplicationsWorkflowParams.KEY);

		try {
			dossierProcessListener.onTransitionCompleted(processTransitionResult);

			verify(dossierDetailsCrudServiceMock, times(1))
					.updateProcessStatusAndFlTransition(params.getTenant(), params.getApplicationId(),
							processTransitionResult.getCurrentNode(), params.getUsername(),
							ProcessTransitionEnum.NOT_IN_TRANSITION);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void onProcessCreated_ko() {
		Map<String, Object> globalVars = Map.of(ApplicationsWorkflowParams.KEY, new ApplicationsWorkflowParams());
		ProcessTransitionResult.TransitionLog transitionLogMock = mock(ProcessTransitionResult.TransitionLog.class);
		lenient().when(transitionLogMock.getStartDate()).thenReturn(Instant.ofEpochSecond(0));
		List<WorkflowMessage> messages = List.of(new WorkflowMessage());
		ProcessTransitionResult processTransitionResult = ProcessTransitionResult.builder()
				.processId(PROCESS_ID)
				.currentNode(CURRENT_NODE)
				.globalVars(globalVars)
				.lastTransitionLog(transitionLogMock)
				.messages(messages)
				.build();
		ApplicationsWorkflowParams params = (ApplicationsWorkflowParams) globalVars.get(ApplicationsWorkflowParams.KEY);

		try {
			doThrow(new ObjectNotFoundException(EXCPTION_MESSAGE))
					.when(dossiersCrudServiceMock)
					.getDossierAndUpdateProcessId(params.getTenant(), params.getApplicationId(),
							processTransitionResult.getProcessId(), FIND_EXPIRED);

			dossierProcessListener.onProcessCreated(processTransitionResult);
		} catch (Exception e) {
			assertEquals(EXCPTION_MESSAGE, e.getMessage());
		}
	}

	@Test
	void onTransitionCompleted_ko() {
		Map<String, Object> globalVars = Map.of(ApplicationsWorkflowParams.KEY, new ApplicationsWorkflowParams());
		ProcessTransitionResult.TransitionLog transitionLogMock = mock(ProcessTransitionResult.TransitionLog.class);
		lenient().when(transitionLogMock.getStartDate()).thenReturn(Instant.ofEpochSecond(0));
		List<WorkflowMessage> messages = List.of(new WorkflowMessage());
		ProcessTransitionResult processTransitionResult = ProcessTransitionResult.builder()
				.processId(PROCESS_ID)
				.currentNode(CURRENT_NODE)
				.globalVars(globalVars)
				.lastTransitionLog(transitionLogMock)
				.messages(messages)
				.build();
		ApplicationsWorkflowParams params = (ApplicationsWorkflowParams) globalVars.get(ApplicationsWorkflowParams.KEY);

		try {
			doThrow(new ObjectNotFoundException(EXCPTION_MESSAGE))
					.when(dossierDetailsCrudServiceMock)
					.updateProcessStatusAndFlTransition(params.getTenant(), params.getApplicationId(),
							processTransitionResult.getCurrentNode(), params.getUsername(),
							ProcessTransitionEnum.NOT_IN_TRANSITION);

			dossierProcessListener.onTransitionCompleted(processTransitionResult);
		} catch (Exception e) {
			assertEquals(EXCPTION_MESSAGE, e.getMessage());
		}
	}
}
