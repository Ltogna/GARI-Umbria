package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.mappers.ModuleFormConfigsMapper;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleFormConfigsDTO;
import com.abacogroup.agri.dossiers.core.services.I18NService;
import com.abacogroup.agri.dossiers.db.dao.ModuleFormConfigsDAO;
import com.abacogroup.agri.dossiers.db.ntt.ModuleFormConfigsNTT;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ModuleFormConfigsCrudServiceTest {

	private static final String TEMPLATE_TENANT_ID = "*";
	private static final Long MODULE_ID_1 = 1L;
	private static final Long FORM_ID = 1L;
	private static final Long FORM_GROUP_ID = 1L;
	private static final String COMPILE_STATUS_IDENTIFIER = "CODE_1";

	private static final Long FORM_MODULE_CONFIG_ID = 1L;
	private static final String REQUIRED_PROFILE_CODE = "DEFAULT_PROFILE";
	private static final Integer FL_READ_ONLY = 0;
	private static final Integer SORT_ORDER = 1;
	private static final String PROCESS_STATUS = "TODO";

	private final ModuleFormConfigsDTO moduleFormConfigsDTOInMock = ModuleFormConfigsDTO.builder()
			.moduleId(MODULE_ID_1)
			.formId(FORM_ID)
			.formGroupId(FORM_GROUP_ID)
			.processStatus(PROCESS_STATUS)
			.flReadOnly(FL_READ_ONLY)
			.sortOrder(SORT_ORDER)
			.compileStatusIdentifier(COMPILE_STATUS_IDENTIFIER)
			.build();

	private final ModuleFormConfigsDTO moduleFormConfigsDTOOutMock = ModuleFormConfigsDTO.builder()
			.id(FORM_MODULE_CONFIG_ID)
			.moduleId(MODULE_ID_1)
			.formId(FORM_ID)
			.formGroupId(FORM_GROUP_ID)
			.processStatus(PROCESS_STATUS)
			.flReadOnly(FL_READ_ONLY)
			.sortOrder(SORT_ORDER)
			.compileStatusIdentifier(COMPILE_STATUS_IDENTIFIER)
			.build();

	private final ModuleFormConfigsNTT moduleFormConfigsNTTMock = ModuleFormConfigsNTT.builder()
			.id(FORM_MODULE_CONFIG_ID)
			.module_id(MODULE_ID_1)
			.form_id(FORM_ID)
			.form_group_id(FORM_GROUP_ID)
			.process_status(PROCESS_STATUS)
			.fl_readonly(FL_READ_ONLY)
			.sort_order(SORT_ORDER)
			.compile_status_identifier(COMPILE_STATUS_IDENTIFIER)
			.build();

	private final ModuleFormConfigsMapper moduleFormConfigsMapper = ModuleFormConfigsMapper.INSTANCE;
	@Mock
	private ModuleFormConfigsDAO moduleFormConfigsDAO;
	@Mock
	private I18NService i18NService;
	@InjectMocks
	private ModuleFormConfigsCrudService moduleFormConfigsCrudService;

	@BeforeEach
	protected void init() {
		moduleFormConfigsCrudService = new ModuleFormConfigsCrudService(moduleFormConfigsDAO, moduleFormConfigsMapper, i18NService);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_insert() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(moduleFormConfigsDAO.nextSequenceVal()).thenReturn(MODULE_ID_1);
			when(moduleFormConfigsDAO.findById(MODULE_ID_1)).thenReturn(List.of(moduleFormConfigsNTTMock));
			moduleFormConfigsCrudService.insert(moduleFormConfigsDTOInMock);

			verify(moduleFormConfigsDAO).inTransaction(handleConsumerLambdaCaptor.capture());

			ModuleFormConfigsDTO actual = (ModuleFormConfigsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(moduleFormConfigsDAO);

			assertEquals(moduleFormConfigsDTOOutMock, actual);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_update() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(moduleFormConfigsDAO.findById(MODULE_ID_1)).thenReturn(List.of(moduleFormConfigsNTTMock));
			moduleFormConfigsCrudService.update(MODULE_ID_1, moduleFormConfigsDTOInMock);

			verify(moduleFormConfigsDAO).inTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().inTransaction(moduleFormConfigsDAO);

			verify(moduleFormConfigsDAO, times(1)).inTransaction(handleConsumerLambdaCaptor.capture());

			ModuleFormConfigsDTO actual = (ModuleFormConfigsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(moduleFormConfigsDAO);

			assertEquals(moduleFormConfigsDTOOutMock, actual);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_delete() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);
			moduleFormConfigsCrudService.delete(MODULE_ID_1);

			verify(moduleFormConfigsDAO).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useTransaction(moduleFormConfigsDAO);
			verify(moduleFormConfigsDAO).deleteById(MODULE_ID_1);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findAllModuleFormConfigs() {
		try {
			when(moduleFormConfigsDAO.findAllModuleFormConfigsByTenant(TEMPLATE_TENANT_ID))
					.thenReturn(List.of(moduleFormConfigsNTTMock));

			List<ModuleFormConfigsDTO> result = moduleFormConfigsCrudService.findAllModuleFormConfigs(TEMPLATE_TENANT_ID);

			assertEquals(List.of(moduleFormConfigsDTOOutMock), result);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findAllModuleFormConfigs_withModuleId() {
		when(moduleFormConfigsDAO.findAllModuleFormConfigs(TEMPLATE_TENANT_ID, MODULE_ID_1))
				.thenReturn(List.of(moduleFormConfigsNTTMock));

		List<ModuleFormConfigsDTO> result = moduleFormConfigsCrudService.findAllModuleFormConfigs(TEMPLATE_TENANT_ID, MODULE_ID_1);

		assertEquals(List.of(moduleFormConfigsDTOOutMock), result);
	}

	@Test
	void test_findRsByCustomKey() {
		Optional<ModuleFormConfigsNTT> result = moduleFormConfigsCrudService.findRsByCustomKey(MODULE_ID_1);

		assertEquals(Optional.empty(), result);
	}

	@Test
	void test_deleteByCustomKey() {
		assertThrows(NotImplementedException.class, () ->
				moduleFormConfigsCrudService.deleteByCustomKey(MODULE_ID_1));
	}

	@Test
	void test_setCustomSearchKey() {
		assertThrows(NotImplementedException.class, () ->
				moduleFormConfigsCrudService.setCustomSearchKey(moduleFormConfigsNTTMock, MODULE_ID_1));
	}

	@Test
	void test_findById() {
		try {
			when(moduleFormConfigsDAO.findById(TEMPLATE_TENANT_ID, FORM_MODULE_CONFIG_ID)).thenReturn(List.of(moduleFormConfigsNTTMock));
			assertEquals(moduleFormConfigsDTOOutMock, moduleFormConfigsCrudService.findById(TEMPLATE_TENANT_ID, FORM_MODULE_CONFIG_ID));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_find_withProfileCodeList() {
		try {
			when(moduleFormConfigsDAO.find(TEMPLATE_TENANT_ID, MODULE_ID_1, PROCESS_STATUS, List.of(REQUIRED_PROFILE_CODE)))
					.thenReturn(List.of(moduleFormConfigsNTTMock));

			List<ModuleFormConfigsDTO> result =
					moduleFormConfigsCrudService.find(TEMPLATE_TENANT_ID, MODULE_ID_1, PROCESS_STATUS, List.of(REQUIRED_PROFILE_CODE));

			assertEquals(List.of(moduleFormConfigsDTOOutMock), result);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	private final static String CONTEXT_FUNCTION = "CONTEXT_FUNCTION";

	@Test
	void test_find_withoutProfileCodeList() {
		when(moduleFormConfigsDAO.find(TEMPLATE_TENANT_ID, MODULE_ID_1, PROCESS_STATUS, CONTEXT_FUNCTION))
				.thenReturn(List.of(moduleFormConfigsNTTMock));

		List<ModuleFormConfigsDTO> result = moduleFormConfigsCrudService.find(TEMPLATE_TENANT_ID, MODULE_ID_1, PROCESS_STATUS, CONTEXT_FUNCTION);

		assertEquals(List.of(moduleFormConfigsDTOOutMock), result);
	}

}
