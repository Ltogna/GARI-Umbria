package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.model.DossierAnomaly;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierWithDetailsDTO;
import com.abacogroup.agri.dossiers.core.services.AnomaliesService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.ModuleCrudService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CheckForMultipleDossierImplTest {
    @Mock
    private AnomaliesService anomaliesService;
    @Mock
    private DossiersCrudService dossiersCrudService;
    @Mock
    private ModuleCrudService moduleCrudService;

    @InjectMocks
    private CheckForMultipleDossierImpl checkForMultipleDossier;

    private static final String TENANT = "ADMIN";
    private static final Long DOSSIER_ID = 5L;
    private static final Long PARTY_ID = 123456789L;
    private static final Integer REFERRED_YEAR = 2023;
    private static final Long MODULE_ID = 10L;
    private static final String MODULE_CODE = "Module Code";
    private static final String ANOMALY_CODE = "Anomaly Code";
    private static final String ANOMALY_MESSAGE = "Anomaly Message";

    private final DossierWithDetailsDTO dossierWithDetailsDTO = DossierWithDetailsDTO.builder()
            .moduleId(MODULE_ID)
            .dossierId(DOSSIER_ID)
            .referredYear(REFERRED_YEAR)
            .partyId(PARTY_ID)
            .build();
    private final ModuleDTO moduleDTO = ModuleDTO.builder()
            .moduleId(MODULE_ID)
            .moduleCode(MODULE_CODE)
            .build();
    private final DossierAnomaly dossierAnomaly = DossierAnomaly.builder()
            .code(ANOMALY_CODE)
            .message(ANOMALY_MESSAGE)
            .build();

    @Test
    void checkForMultipleApplications_withAnomalies_ok() {
        when(dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID))
                .thenReturn(dossierWithDetailsDTO);
        when(moduleCrudService.findById(MODULE_ID))
                .thenReturn(Optional.of(moduleDTO));
        when(anomaliesService.checkForMultipleDossier(TENANT, moduleDTO, PARTY_ID, REFERRED_YEAR, DOSSIER_ID))
                .thenReturn(List.of(dossierAnomaly));

        assertFalse(checkForMultipleDossier.checkForMultipleApplications(TENANT, DOSSIER_ID, PARTY_ID, REFERRED_YEAR));
    }

    @Test
    void checkForMultipleApplications_withoutAnomalies_ok() {
        when(dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID))
                .thenReturn(dossierWithDetailsDTO);
        when(moduleCrudService.findById(MODULE_ID))
                .thenReturn(Optional.of(moduleDTO));
        when(anomaliesService.checkForMultipleDossier(TENANT, moduleDTO, PARTY_ID, REFERRED_YEAR, DOSSIER_ID))
                .thenReturn(List.of());

        assertTrue(checkForMultipleDossier.checkForMultipleApplications(TENANT, DOSSIER_ID, PARTY_ID, REFERRED_YEAR));
    }

    @Test
    void checkForMultipleApplications_moduleNotPresent_ok() {
        when(dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID))
                .thenReturn(dossierWithDetailsDTO);
        when(moduleCrudService.findById(MODULE_ID))
                .thenReturn(Optional.empty());

        assertFalse(checkForMultipleDossier.checkForMultipleApplications(TENANT, DOSSIER_ID, PARTY_ID, REFERRED_YEAR));
    }
}