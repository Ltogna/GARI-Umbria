package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.*;
import com.abacogroup.agri.dossiers.core.mappers.DossierGeneratedPrintMapper;
import com.abacogroup.agri.dossiers.core.model.TestImplAbstractCrudService;
import com.abacogroup.agri.dossiers.core.model.TestImplAbstractCrudServiceWithHasPrimaryKeyFalse;
import com.abacogroup.agri.dossiers.core.model.dto.DossierGeneratedPrintDTO;
import com.abacogroup.agri.dossiers.db.dao.DossierGeneratedPrintDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierGeneratedPrintNTT;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.PagedResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.jdbi.paging.impl.PagedResultsImpl;
import org.jdbi.v3.core.statement.StatementContext;
import org.jdbi.v3.core.statement.StatementException;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AbstractCrudServiceTest {
    @Mock
    private DossierGeneratedPrintDAO dao;
    @Mock
    private DossierGeneratedPrintMapper mapper;

    private AbstractCrudService<DossierGeneratedPrintNTT, Long, DossierGeneratedPrintDTO, DossierGeneratedPrintMapper, Void> abstractCrudService;

    private static final Long PKID = 1L;
    private static final Long DOSSIER_ID = 5L;
    private static final String STATUS = "Status";
    private static final String PRINT_CODE = "Print Code";
    private static final String PRINT_DESCRIPTION = "Print Description";
    private static final LocalDateTime PRINT_DATE = LocalDateTime.now();
    private static final String FILE_ID = "File ID";
    private static final Supplier<StatementException> STATEMENT_EXCEPTION_SUPPLIER = () -> new StatementException("Statement Exception Supplier") {
        @Override
        public StatementContext getStatementContext() {
            return super.getStatementContext();
        }
    };

    private final DossierGeneratedPrintNTT dossierGeneratedPrintNTT = DossierGeneratedPrintNTT.builder()
            .pkid(PKID)
            .dossier_id(DOSSIER_ID)
            .status(STATUS)
            .print_code(PRINT_CODE)
            .file_id(FILE_ID)
            .print_date(PRINT_DATE)
            .print_description(PRINT_DESCRIPTION)
            .build();
    private final DossierGeneratedPrintDTO dossierGeneratedPrintDTO = DossierGeneratedPrintDTO.builder()
            .pkid(PKID)
            .dossierId(DOSSIER_ID)
            .printStatus(STATUS)
            .printCode(PRINT_CODE)
            .fileId(FILE_ID)
            .printDate(PRINT_DATE)
            .printDate(PRINT_DATE)
            .build();

    @BeforeEach
    void init() {
        abstractCrudService = new TestImplAbstractCrudService(dao, mapper);
    }

    @Test
    void retrievePrimaryKey_ok() {
        when(dao.nextSequenceVal())
                .thenReturn(PKID);

        Long result = abstractCrudService.retrievePrimaryKey(null);

        assertEquals(PKID, result);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_StatementException_ko() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(mapper.dtoToEntity(dossierGeneratedPrintDTO))
                    .thenReturn(dossierGeneratedPrintNTT);
            doThrow(STATEMENT_EXCEPTION_SUPPLIER.get()).when(dao)
                    .insert(dossierGeneratedPrintNTT);

            assertThrows(InsertExceptionRuntimeException.class, () -> {
                abstractCrudService.insert(dossierGeneratedPrintDTO, null);

                verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
                handleConsumerLambdaCaptor.getValue().inTransaction(dao);
            });
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_ObjectNotFoundException_ko() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(dao.nextSequenceVal())
                    .thenReturn(PKID);
            when(mapper.dtoToEntity(dossierGeneratedPrintDTO))
                    .thenReturn(dossierGeneratedPrintNTT);
            when(dao.findById(PKID))
                    .thenReturn(List.of());

            assertThrows(ObjectNotFoundRuntimeException.class, () -> {
                abstractCrudService.insert(dossierGeneratedPrintDTO, null);

                verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
                handleConsumerLambdaCaptor.getValue().inTransaction(dao);
            });
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_Exception_ko() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(mapper.dtoToEntity(dossierGeneratedPrintDTO))
                    .thenReturn(dossierGeneratedPrintNTT);
            doThrow(RuntimeException.class).when(dao)
                    .insert(dossierGeneratedPrintNTT);

            assertThrows(AgriDossiersRuntimeException.class, () -> {
                abstractCrudService.insert(dossierGeneratedPrintDTO, null);

                verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
                handleConsumerLambdaCaptor.getValue().inTransaction(dao);
            });
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void delete_StatementException_ko() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

            doThrow(STATEMENT_EXCEPTION_SUPPLIER.get()).when(dao)
                    .deleteById(PKID);

            assertThrows(StatementExceptionRuntimeException.class, () -> {
                abstractCrudService.delete(PKID, null);

                verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());
                handleConsumerLambdaCaptor.getValue().useTransaction(dao);
            });
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void delete_ObjectNotFoundException_ko() {
        // using the new concrete class only in this case to testing the ObjectNotFound case (didn't work mocking the throw of exception)
        abstractCrudService = new TestImplAbstractCrudServiceWithHasPrimaryKeyFalse(dao, mapper);

        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

            assertThrows(ObjectNotFoundRuntimeException.class, () -> {
                abstractCrudService.delete(PKID, null);

                verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());
                handleConsumerLambdaCaptor.getValue().useTransaction(dao);
            });
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void delete_Exception_ko() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

            doThrow(RuntimeException.class).when(dao)
                    .deleteById(PKID);

            assertThrows(AgriDossiersRuntimeException.class, () -> {
                abstractCrudService.delete(PKID, null);

                verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());
                handleConsumerLambdaCaptor.getValue().useTransaction(dao);
            });
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void update_StatementException_ko() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(mapper.dtoToEntity(dossierGeneratedPrintDTO))
                    .thenReturn(dossierGeneratedPrintNTT);
            doThrow(STATEMENT_EXCEPTION_SUPPLIER.get()).when(dao)
                    .update(dossierGeneratedPrintNTT);

            assertThrows(StatementExceptionRuntimeException.class, () -> {
                abstractCrudService.update(PKID, dossierGeneratedPrintDTO, null);

                verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
                handleConsumerLambdaCaptor.getValue().inTransaction(dao);
            });
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void update_ObjectNotFoundException_ko() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(mapper.dtoToEntity(dossierGeneratedPrintDTO))
                    .thenReturn(dossierGeneratedPrintNTT);
            when(dao.findById(PKID))
                    .thenReturn(List.of());

            assertThrows(ObjectNotFoundRuntimeException.class, () -> {
                abstractCrudService.update(PKID, dossierGeneratedPrintDTO, null);

                verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
                handleConsumerLambdaCaptor.getValue().inTransaction(dao);
            });
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void update_Exception_ko() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(mapper.dtoToEntity(dossierGeneratedPrintDTO))
                    .thenReturn(dossierGeneratedPrintNTT);
            doThrow(RuntimeException.class).when(dao)
                    .update(dossierGeneratedPrintNTT);

            assertThrows(AgriDossiersRuntimeException.class, () -> {
                abstractCrudService.update(PKID, dossierGeneratedPrintDTO, null);

                verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
                handleConsumerLambdaCaptor.getValue().inTransaction(dao);
            });
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void returnPagedResults_ok() {
        int totalCount = 2;
        int offset = 10;

        PagedResults<DossierGeneratedPrintNTT> dossierGeneratedPrintNTTPagedResults =
                new PagedResultsImpl<>(totalCount, offset, List.of(dossierGeneratedPrintNTT));

        when(mapper.entityToDto(dossierGeneratedPrintNTT))
                .thenReturn(dossierGeneratedPrintDTO);

        PagedResults<DossierGeneratedPrintDTO> result = abstractCrudService.returnPagedResults(dossierGeneratedPrintNTTPagedResults);

        assertEquals(List.of(dossierGeneratedPrintDTO), result.getRecords());
        assertEquals(totalCount, result.getTotalcount());
        assertEquals(offset, result.getOffset());
    }

    @Test
    void returnInfiniteResults_ok() {
        String nextKey = "Next Key";

        InfiniteListResults<DossierGeneratedPrintNTT> dossierGeneratedPrintNTTInfiniteListResults =
                new InfiniteListResultsImpl<>(List.of(dossierGeneratedPrintNTT), nextKey);

        when(mapper.entityToDto(dossierGeneratedPrintNTT))
                .thenReturn(dossierGeneratedPrintDTO);

        InfiniteListResults<DossierGeneratedPrintDTO> result =
                abstractCrudService.returnInfiniteResults(dossierGeneratedPrintNTTInfiniteListResults, mapper::entityToDto);

        assertEquals(List.of(dossierGeneratedPrintDTO), result.getRecords());
        assertEquals(nextKey, result.getNextKey());
    }
}