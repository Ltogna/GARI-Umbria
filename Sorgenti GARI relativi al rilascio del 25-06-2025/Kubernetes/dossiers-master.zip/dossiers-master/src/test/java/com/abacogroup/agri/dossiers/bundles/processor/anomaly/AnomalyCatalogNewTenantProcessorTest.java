package com.abacogroup.agri.dossiers.bundles.processor.anomaly;

import com.abacogroup.agri.dossiers.core.services.crud.AnomalyCatalogCrudService;
import com.abacogroup.agri.dossiers.db.ntt.AnomalyCatalogWIthModuleCodeNTT;
import com.abacogroup.agri.dossiers.db.ntt.dossiers.RsI18N;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.HandleConsumer;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.*;

/**
 * The type Anomaly catalog new tenant processor test.
 * @author Carlo Sindico
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
public class AnomalyCatalogNewTenantProcessorTest {

    private static final String TEMPLATE_TENANT_ID = "*";

    private static final String ANOMALY_CODE = "anomaly_code";

    private static final String MODULE_CODE = "module_code";

    private static final String SEVERITY = "severity";

    private final AnomalyCatalogWIthModuleCodeNTT anomalyCatalogWIthModuleCodeNTTMock = AnomalyCatalogWIthModuleCodeNTT.builder()
            .anomaly_code(ANOMALY_CODE)
            .module_code(MODULE_CODE)
            .severity(SEVERITY)
            .build();

    private final RsI18N rsI18NMock = RsI18N.builder()
            .field_name("lang")
            .lang("lang")
            .i18n_text("lang")
            .tenant_id(TEMPLATE_TENANT_ID)
            .i18n_value("lang")
            .table_name("lang")
            .build();

    @Mock
    private Jdbi jdbi;

    @Mock
    private Handle handle;

    @Mock
    private AnomalyCatalogCrudService anomalyCatalogCrudService;

    @Mock
    private AnomalyCatalogBundleWorker anomalyCatalogBundleWorker;

    @InjectMocks
    private AnomalyCatalogNewTenantProcessor anomalyCatalogNewTenantProcessor;

    @BeforeEach
    void init() {
        anomalyCatalogNewTenantProcessor = new AnomalyCatalogNewTenantProcessor(jdbi, anomalyCatalogBundleWorker);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_onMessage() {
        try {
            ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

            TenantMessage message = new TenantMessage();
            message.setTenantId(TEMPLATE_TENANT_ID);
            when(anomalyCatalogBundleWorker.exposeAnomalyCatalogCrudService()).thenReturn(anomalyCatalogCrudService);
            when(anomalyCatalogCrudService.findAllByTenant(TEMPLATE_TENANT_ID)).thenReturn(List.of(anomalyCatalogWIthModuleCodeNTTMock));
            when(anomalyCatalogCrudService.getAllAnomalyCatalogI18NByTenantAndCode(TEMPLATE_TENANT_ID, ANOMALY_CODE)).thenReturn(List.of(rsI18NMock));

            anomalyCatalogNewTenantProcessor.onMessage(message);

            verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());

            handleConsumerLambdaCaptor.getValue().useHandle(handle);
        } catch (Exception e) {
            fail(e.getMessage(), e);
        }
    }

}
