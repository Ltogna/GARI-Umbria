package com.abacogroup.agri.dossiers.core.caller;

import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static com.abacogroup.jaxrsutils.GenericCallerService.GET_METHOD;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GetPartiesCallerTest {
    private static final String TENANT = "ADMIN";
    private static final Long PARTY_ID = 123456789L;
    private static final String AUTH_TOKEN = "Auth Token";
    private static final String LEGACY_URL = "Legacy URL";
    private static final String SEARCH_CODE = "Search Code";
    private static final String SEARCH_DESCRIPTION = "Search Description";

    private final GetPartiesOutput getPartiesOutput = GetPartiesOutput.builder()
            .partyId(PARTY_ID)
            .code(SEARCH_CODE)
            .description(SEARCH_DESCRIPTION)
            .build();

    @Test
    void constructor_ok() {
        GenericCallerService genericCallerService = mock(GenericCallerService.class);

        GetPartiesCaller getPartiesCaller = new GetPartiesCaller(genericCallerService);

        assertNotNull(getPartiesCaller);
    }

    @Test
    void makeCall_ok() {
        GenericCallerService genericCallerService = mock(GenericCallerService.class);

        GetPartiesCaller getPartiesCaller = new GetPartiesCaller(genericCallerService);

        GetPartiesInput getPartiesInput = new GetPartiesInput(TENANT, PARTY_ID, AUTH_TOKEN, LEGACY_URL,
                SEARCH_CODE, SEARCH_DESCRIPTION);

        when(genericCallerService.makeCall(any(), anyString(), eq(GET_METHOD), any(), any(), eq(AUTH_TOKEN),
                eq(null), eq(null), eq(null)))
                .thenReturn(new InfiniteListResultsImpl<>(List.of(getPartiesOutput), null));

        InfiniteListResults<GetPartiesOutput> result = getPartiesCaller.makeCall(getPartiesInput);

        assertEquals(List.of(getPartiesOutput), result.getRecords());
    }
}