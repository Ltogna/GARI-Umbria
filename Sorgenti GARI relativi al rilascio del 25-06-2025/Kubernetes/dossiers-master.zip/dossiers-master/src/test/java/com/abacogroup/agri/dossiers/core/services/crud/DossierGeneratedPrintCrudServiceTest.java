package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.mappers.DossierGeneratedPrintMapper;
import com.abacogroup.agri.dossiers.core.model.dto.DossierGeneratedPrintDTO;
import com.abacogroup.agri.dossiers.db.dao.DossierGeneratedPrintDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierGeneratedPrintNTT;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import org.apache.commons.lang3.NotImplementedException;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static com.abacogroup.agri.dossiers.core.services.crud.DossierGeneratedPrintCrudService.DEFINITIVE_PRINT;
import static com.abacogroup.agri.dossiers.core.services.crud.DossierGeneratedPrintCrudService.ON_GOING_PRINT;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DossierGeneratedPrintCrudServiceTest {
    @Mock
    DossierGeneratedPrintDAO dossierGeneratedPrintDAOMock;
    @Mock
    DossierGeneratedPrintMapper dossierGeneratedPrintMapperMock;

    @InjectMocks
    DossierGeneratedPrintCrudService dossierGeneratedPrintCrudService;

    private static final String TENANT = "ADMIN";
    private static final String USERNAME = "Username";
    private static final Long DOSSIER_ID = 5L;
    private static final Long PKID = 1L;
    private static final String PRINT_CODE = "Print Code";
    private static final String PRINT_DESCRIPTION = "Print Description";
    private static final String PROCESS_STATUS = "Process Status";
    private static final LocalDateTime NOW = LocalDateTime.now();
    private static final String FILE_ID = "File ID";
    private static final String PRINT_JOB_UUID = "Print Job UUID";
    private static final String PRINT_STATUS = "Print Status";

    private final DossierGeneratedPrintDTO dossierGeneratedPrintDTO = DossierGeneratedPrintDTO.builder()
            .pkid(PKID)
            .dossierId(DOSSIER_ID)
            .printCode(PRINT_CODE)
            .processStatus(PROCESS_STATUS)
            .username(USERNAME)
            .printDate(NOW)
            .fileId(FILE_ID)
            .printJobUuid(PRINT_JOB_UUID)
            .printDescription(PRINT_DESCRIPTION)
            .printStatus(PRINT_STATUS)
            .build();
    private final DossierGeneratedPrintNTT dossierGeneratedPrintNTT = DossierGeneratedPrintNTT.builder()
            .pkid(PKID)
            .dossier_id(DOSSIER_ID)
            .print_code(PRINT_CODE)
            .print_description(PRINT_DESCRIPTION)
            .print_date(NOW)
            .file_id(FILE_ID)
            .print_job_uuid(PRINT_JOB_UUID)
            .process_status(PROCESS_STATUS)
            .username(USERNAME)
            .status(PRINT_STATUS)
            .build();

    @Test
    void findAllGeneratedPrints_ok() {
        when(dossierGeneratedPrintDAOMock.findCompletedPrintsByDossierId(TENANT, DOSSIER_ID, MDC.get(MDCPreFilter.LOCALE)))
                .thenReturn(List.of(dossierGeneratedPrintNTT));
        when(dossierGeneratedPrintMapperMock.entityToDto(dossierGeneratedPrintNTT))
                .thenReturn(dossierGeneratedPrintDTO);

        List<DossierGeneratedPrintDTO> result = dossierGeneratedPrintCrudService.findAllGeneratedPrints(TENANT, DOSSIER_ID);

        assertEquals(List.of(dossierGeneratedPrintDTO), result);
    }

    @Test
    void findPrintByDossierIdAndFileId_ok() {
        when(dossierGeneratedPrintDAOMock.findByDossierIdAndFileId(TENANT, DOSSIER_ID, MDC.get(MDCPreFilter.LOCALE), FILE_ID))
                .thenReturn(List.of(dossierGeneratedPrintNTT));
        when(dossierGeneratedPrintMapperMock.entityToDto(dossierGeneratedPrintNTT))
                .thenReturn(dossierGeneratedPrintDTO);

        Optional<DossierGeneratedPrintDTO> result = dossierGeneratedPrintCrudService.findPrintByDossierIdAndFileId(TENANT, DOSSIER_ID, FILE_ID);

        assertEquals(Optional.ofNullable(dossierGeneratedPrintDTO), result);
    }

    @Test
    void findLastGeneratedPrintByCode_ok() {
        when(dossierGeneratedPrintDAOMock.findLastGeneratedPrintByCode(TENANT, DOSSIER_ID, PRINT_CODE, MDC.get(MDCPreFilter.LOCALE), DEFINITIVE_PRINT))
                .thenReturn(List.of(dossierGeneratedPrintNTT));
        when(dossierGeneratedPrintMapperMock.entityToDto(dossierGeneratedPrintNTT))
                .thenReturn(dossierGeneratedPrintDTO);

        Optional<DossierGeneratedPrintDTO> result = dossierGeneratedPrintCrudService.findLastGeneratedPrintByCode(TENANT, DOSSIER_ID, PRINT_CODE);

        assertEquals(Optional.ofNullable(dossierGeneratedPrintDTO), result);
    }

    @Test
    void findOngoingPrintByCode_ok() {
        when(dossierGeneratedPrintDAOMock.findLastGeneratedPrintByCode(TENANT, DOSSIER_ID, PRINT_CODE, MDC.get(MDCPreFilter.LOCALE), ON_GOING_PRINT))
                .thenReturn(List.of(dossierGeneratedPrintNTT));
        when(dossierGeneratedPrintMapperMock.entityToDto(dossierGeneratedPrintNTT))
                .thenReturn(dossierGeneratedPrintDTO);

        List<DossierGeneratedPrintDTO> result = dossierGeneratedPrintCrudService.findOngoingPrintByCode(TENANT, DOSSIER_ID, PRINT_CODE);

        assertEquals(List.of(dossierGeneratedPrintDTO), result);
    }

    @Test
    void findByUuid_ok() {
        when(dossierGeneratedPrintDAOMock.findByUuid(PRINT_JOB_UUID))
                .thenReturn(dossierGeneratedPrintNTT);
        when(dossierGeneratedPrintMapperMock.entityToDto(dossierGeneratedPrintNTT))
                .thenReturn(dossierGeneratedPrintDTO);

        DossierGeneratedPrintDTO result = dossierGeneratedPrintCrudService.findByUuid(PRINT_JOB_UUID);

        assertEquals(dossierGeneratedPrintDTO, result);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_ok() {
        DossierGeneratedPrintDTO in = DossierGeneratedPrintDTO.builder()
                .dossierId(DOSSIER_ID)
                .printDescription(PRINT_DESCRIPTION)
                .fileId(FILE_ID)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(dossierGeneratedPrintDAOMock.nextSequenceVal())
                    .thenReturn(PKID);
            when(dossierGeneratedPrintMapperMock.dtoToEntity(in))
                    .thenReturn(dossierGeneratedPrintNTT);
            when(dossierGeneratedPrintDAOMock.findById(PKID))
                    .thenReturn(List.of(dossierGeneratedPrintNTT));
            when(dossierGeneratedPrintMapperMock.entityToDto(dossierGeneratedPrintNTT))
                    .thenReturn(dossierGeneratedPrintDTO);

            dossierGeneratedPrintCrudService.insert(in);

            verify(dossierGeneratedPrintDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());

            DossierGeneratedPrintDTO result = (DossierGeneratedPrintDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dossierGeneratedPrintDAOMock);

            assertEquals(dossierGeneratedPrintDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void update_ok() {
        DossierGeneratedPrintDTO in = DossierGeneratedPrintDTO.builder()
                .dossierId(DOSSIER_ID)
                .printDescription(PRINT_DESCRIPTION)
                .fileId(FILE_ID)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
            when(dossierGeneratedPrintMapperMock.dtoToEntity(in))
                    .thenReturn(dossierGeneratedPrintNTT);
            when(dossierGeneratedPrintDAOMock.inTransaction(handleConsumerLambdaCaptor.capture()))
                    .thenReturn(dossierGeneratedPrintDTO);
            when(dossierGeneratedPrintDAOMock.findById(PKID))
                    .thenReturn(List.of(dossierGeneratedPrintNTT));
            when(dossierGeneratedPrintMapperMock.entityToDto(dossierGeneratedPrintNTT))
                    .thenReturn(dossierGeneratedPrintDTO);

            dossierGeneratedPrintCrudService.update(PKID, in);

            verify(dossierGeneratedPrintDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());
            DossierGeneratedPrintDTO result = (DossierGeneratedPrintDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dossierGeneratedPrintDAOMock);

            assertEquals(dossierGeneratedPrintDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void delete_ok() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

            dossierGeneratedPrintCrudService.delete(PKID);

            verify(dossierGeneratedPrintDAOMock).useTransaction(handleConsumerLambdaCaptor.capture());
            handleConsumerLambdaCaptor.getValue().useTransaction(dossierGeneratedPrintDAOMock);

            verify(dossierGeneratedPrintDAOMock, times(1)).deleteById(PKID);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void findRsByCustomKey_ok() {
        Optional<DossierGeneratedPrintNTT> result = dossierGeneratedPrintCrudService.findRsByCustomKey(null);

        assertEquals(Optional.empty(), result);
    }

    @Test
    void deleteByCustomKey_ok() {
        assertThrows(NotImplementedException.class, () -> dossierGeneratedPrintCrudService.deleteByCustomKey(null));
    }

    @Test
    void setCustomSearchKey_ok() {
        assertThrows(NotImplementedException.class, () -> dossierGeneratedPrintCrudService.setCustomSearchKey(dossierGeneratedPrintNTT, null));
    }
}