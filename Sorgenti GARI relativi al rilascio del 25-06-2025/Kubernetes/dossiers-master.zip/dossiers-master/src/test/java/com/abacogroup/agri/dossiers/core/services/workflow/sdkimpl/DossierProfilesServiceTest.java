package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.exceptions.ProfileCodeNotExistsRuntimeException;
import com.abacogroup.agri.dossiers.core.model.dto.DossierProfileDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierWithDetailsDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierProfilesCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.ModuleProfilesCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.HandleConsumer;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class DossierProfilesServiceTest {

	@Mock
	private Jdbi jdbi;
	@Mock
	private DossiersCrudService dossiersCrudService;
	@Mock
	private DossierProfilesCrudService dossierProfilesCrudService;
	@Mock
	private ModuleProfilesCrudService moduleProfilesCrudService;
	@InjectMocks
	private DossierProfilesService dossierProfilesService;

	private static final String TENANT_1 = "tenant_1";
	private static final Long DOSSIER_ID_1 = 30L;
	private static final Long MODULE_ID_1 = 1L;
	private static final String USER_1 = "user_1";
	private static final User logged_user1 = new User(USER_1, TENANT_1);
	private static final String PROFILE_CODE_1 = "code1";
	private static final String PROFILE_CODE_2 = "code2";
	private static final Long PK_ID_1 = 1L;

	private static final ModuleProfileDTO moduleProfileDTO = ModuleProfileDTO.builder()
			.profileCode(PROFILE_CODE_1)
			.moduleId(MODULE_ID_1)
			.pkid(PK_ID_1)
			.build();

	@BeforeEach
	protected void init() {
		dossierProfilesService = new DossierProfilesService(
				jdbi,
				dossiersCrudService,
				dossierProfilesCrudService,
				moduleProfilesCrudService);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_putDossierProfile_ok() throws Exception {
		DossierProfileDTO dossierProfile = DossierProfileDTO.builder()
				.dossierId(DOSSIER_ID_1)
				.pkid(PK_ID_1)
				.profileCode(PROFILE_CODE_1)
				.build();
		DossierProfileDTO dossierProfileIn = DossierProfileDTO.builder()
				.dossierId(DOSSIER_ID_1)
				.profileCode(PROFILE_CODE_1)
				.build();

		InfiniteListResultsImpl<DossierProfileDTO> infiniteListResults = new InfiniteListResultsImpl<>();
		infiniteListResults.setRecords(List.of(dossierProfile));

		DossierWithDetailsDTO dossier = DossierWithDetailsDTO.builder()
				.dossierId(DOSSIER_ID_1)
				.moduleId(MODULE_ID_1)
				.build();

		when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1)).thenReturn(dossier);
		when(moduleProfilesCrudService.find(TENANT_1, MODULE_ID_1)).thenReturn(List.of(moduleProfileDTO));
		ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

		dossierProfilesService.putDossierProfiles(TENANT_1, DOSSIER_ID_1, new ArrayList<>(List.of(PROFILE_CODE_1)), logged_user1);

		verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());
		handleConsumerLambdaCaptor.getValue().useHandle(jdbi.open());

		verify(dossierProfilesCrudService, times(1)).bulkLogicallyDeleteByDossierId(TENANT_1, DOSSIER_ID_1, USER_1);

		verify(dossierProfilesCrudService, times(1)).insert(dossierProfileIn, USER_1);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_putDossierProfile_profile_code_not_found_ok() {
		DossierProfileDTO dossierProfile = DossierProfileDTO.builder()
				.dossierId(DOSSIER_ID_1)
				.pkid(PK_ID_1)
				.profileCode(PROFILE_CODE_1)
				.build();

		InfiniteListResultsImpl<DossierProfileDTO> infiniteListResults = new InfiniteListResultsImpl<>();
		infiniteListResults.setRecords(List.of(dossierProfile));

		DossierWithDetailsDTO dossier = DossierWithDetailsDTO.builder()
				.dossierId(DOSSIER_ID_1)
				.moduleId(MODULE_ID_1)
				.build();

		when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1)).thenReturn(dossier);
		when(moduleProfilesCrudService.find(TENANT_1, MODULE_ID_1)).thenReturn(List.of(moduleProfileDTO));
		ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

		try {
			dossierProfilesService.putDossierProfiles(TENANT_1, DOSSIER_ID_1, new ArrayList<>(List.of(PROFILE_CODE_2)), logged_user1);
			verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useHandle(jdbi.open());
		} catch (Exception e) {
			assertTrue(e instanceof ProfileCodeNotExistsRuntimeException);
		}

		verify(dossierProfilesCrudService, times(1)).bulkLogicallyDeleteByDossierId(TENANT_1, DOSSIER_ID_1, USER_1);
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void putDossierProfiles_upsertTrue_ok() {
		try {
			ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			DossierProfileDTO dossierProfile = DossierProfileDTO.builder()
					.dossierId(DOSSIER_ID_1)
					.pkid(PK_ID_1)
					.profileCode(PROFILE_CODE_1)
					.build();
			DossierProfileDTO in = DossierProfileDTO.builder()
					.pkid(PK_ID_1)
					.dossierId(DOSSIER_ID_1)
					.profileCode(PROFILE_CODE_1)
					.build();

			InfiniteListResultsImpl<DossierProfileDTO> infiniteListResults = new InfiniteListResultsImpl<>();
			infiniteListResults.setRecords(List.of(dossierProfile));

			DossierWithDetailsDTO dossier = DossierWithDetailsDTO.builder()
					.dossierId(DOSSIER_ID_1)
					.moduleId(MODULE_ID_1)
					.build();

			when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossier);
			when(moduleProfilesCrudService.find(TENANT_1, MODULE_ID_1))
					.thenReturn(List.of(moduleProfileDTO));
			when(dossierProfilesCrudService.findByUnique(TENANT_1, DOSSIER_ID_1, PROFILE_CODE_1))
					.thenReturn(Optional.of(dossierProfile));

			dossierProfilesService.putDossierProfiles(TENANT_1, DOSSIER_ID_1, new ArrayList<>(List.of(PROFILE_CODE_1)), logged_user1, true);

			verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useHandle(jdbi.open());

			verify(dossierProfilesCrudService, times(1)).update(PK_ID_1, in, USER_1);
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void putDossierProfiles_upsertTrue_dossierProfileNotFound_ok() {
		try {
			ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			DossierProfileDTO dossierProfile = DossierProfileDTO.builder()
					.dossierId(DOSSIER_ID_1)
					.pkid(PK_ID_1)
					.profileCode(PROFILE_CODE_1)
					.build();
			DossierProfileDTO in = DossierProfileDTO.builder()
					.dossierId(DOSSIER_ID_1)
					.profileCode(PROFILE_CODE_1)
					.build();

			InfiniteListResultsImpl<DossierProfileDTO> infiniteListResults = new InfiniteListResultsImpl<>();
			infiniteListResults.setRecords(List.of(dossierProfile));

			DossierWithDetailsDTO dossier = DossierWithDetailsDTO.builder()
					.dossierId(DOSSIER_ID_1)
					.moduleId(MODULE_ID_1)
					.build();

			when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossier);
			when(moduleProfilesCrudService.find(TENANT_1, MODULE_ID_1))
					.thenReturn(List.of(moduleProfileDTO));
			when(dossierProfilesCrudService.findByUnique(TENANT_1, DOSSIER_ID_1, PROFILE_CODE_1))
					.thenReturn(Optional.empty());

			dossierProfilesService.putDossierProfiles(TENANT_1, DOSSIER_ID_1, new ArrayList<>(List.of(PROFILE_CODE_1)), logged_user1, true);

			verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useHandle(jdbi.open());

			verify(dossierProfilesCrudService, times(1)).insert(in, USER_1);
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void upsertApplicationProfiles_ok() {
		try {
			ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			DossierProfileDTO dossierProfile = DossierProfileDTO.builder()
					.dossierId(DOSSIER_ID_1)
					.pkid(PK_ID_1)
					.profileCode(PROFILE_CODE_1)
					.build();
			DossierProfileDTO in = DossierProfileDTO.builder()
					.pkid(PK_ID_1)
					.dossierId(DOSSIER_ID_1)
					.profileCode(PROFILE_CODE_1)
					.build();

			InfiniteListResultsImpl<DossierProfileDTO> infiniteListResults = new InfiniteListResultsImpl<>();
			infiniteListResults.setRecords(List.of(dossierProfile));

			DossierWithDetailsDTO dossier = DossierWithDetailsDTO.builder()
					.dossierId(DOSSIER_ID_1)
					.moduleId(MODULE_ID_1)
					.build();

			when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossier);
			when(moduleProfilesCrudService.find(TENANT_1, MODULE_ID_1))
					.thenReturn(List.of(moduleProfileDTO));
			when(dossierProfilesCrudService.findByUnique(TENANT_1, DOSSIER_ID_1, PROFILE_CODE_1))
					.thenReturn(Optional.of(dossierProfile));

			dossierProfilesService.upsertApplicationProfiles(TENANT_1, DOSSIER_ID_1, new ArrayList<>(List.of(PROFILE_CODE_1)), logged_user1);

			verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useHandle(jdbi.open());

			verify(dossierProfilesCrudService, times(1)).update(PK_ID_1, in, USER_1);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void deleteApplicationProfile_ok() {
		DossierProfileDTO dossierProfile = DossierProfileDTO.builder()
				.dossierId(DOSSIER_ID_1)
				.pkid(PK_ID_1)
				.profileCode(PROFILE_CODE_1)
				.build();

		when(dossierProfilesCrudService.findByUnique(TENANT_1, DOSSIER_ID_1, PROFILE_CODE_1))
				.thenReturn(Optional.of(dossierProfile));

		dossierProfilesService.deleteApplicationProfile(TENANT_1, DOSSIER_ID_1, PROFILE_CODE_1, logged_user1);

		verify(dossierProfilesCrudService, times(1)).delete(PK_ID_1, USER_1);
	}
}
