package com.abacogroup.agri.dossiers.core.services.factory;

import com.abacogroup.agri.dossiers.services.factory.ProcedureEnvironmentFactory;
import com.abacogroup.workflow.sdk.proc.ProcedureEnvironment;
import com.abacogroup.workflow.server.services.ProcessService;
import jakarta.ws.rs.client.Client;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class ProcedureEnvironmentFactoryTest {

	@Mock
	private Jdbi jdbi;
	@Mock
	private Client client;
	@InjectMocks
	private ProcedureEnvironmentFactory procedureEnvironmentFactory;

	private String environmentId = "DEV";

	@BeforeEach
	protected void init() {
		procedureEnvironmentFactory = new ProcedureEnvironmentFactory(jdbi, Map.of("X", jdbi), client, environmentId);
	}

	@Test
	void test_createProcedureEnvironent() {
		ProcedureEnvironment actual = procedureEnvironmentFactory.createProcedureEnvironment(new HashMap<>());
		assertEquals(Optional.of(client), actual.getJerseyClient());
		assertEquals(Optional.of(jdbi), actual.getJdbi("X"));
	}

}
