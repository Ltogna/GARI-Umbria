package com.abacogroup.agri.dossiers.core.model;

import com.abacogroup.agri.dossiers.core.mappers.DossierMapper;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierDTO;
import com.abacogroup.agri.dossiers.core.services.crud.AbstractHistoricizationFieldsCrudService;
import com.abacogroup.agri.dossiers.db.dao.IGenericHistoricizationFieldsDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierNTT;

import java.util.Optional;

public class TestImplAbstractHistoricizationFieldsCrudService<K> extends AbstractHistoricizationFieldsCrudService<DossierNTT, Long, DossierDTO, DossierMapper, K> {
    public TestImplAbstractHistoricizationFieldsCrudService(IGenericHistoricizationFieldsDAO<DossierNTT, Long, K> dao, DossierMapper mapper) {
        super(dao, mapper);
    }

    @Override
    protected boolean hasPrimaryKey() {
        return true;
    }

    @Override
    protected K retrieveCustomKeyByResultSet(DossierNTT rs) {
        return null;
    }

    @Override
    protected DossierNTT adjustR(DossierNTT rs) {
        return rs;
    }

    @Override
    protected Optional<DossierNTT> findRsByCustomKey(K customKey) {
        return Optional.empty();
    }
}
