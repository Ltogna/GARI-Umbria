package com.abacogroup.agri.dossiers.core.caller;

import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.util.Map;

import static com.abacogroup.jaxrsutils.GenericCallerService.POST_METHOD;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class CreatePrintJobInputTest {
    CreatePrintJobInput createPrintJobInput;

    private static final String TENANT = "TENANT";
    private static final String URL = "URL";
    private static final String TOKEN = "TOKEN";
    private static final String BUCKET_NAME = "BUCKET NAME";
    private static final String DESTINATION = "DESTINATION";
    private static final String LOCALE = MDC.get(MDCPreFilter.LOCALE);
    private static final String PRINT_CODE = "PRINT CODE";

    private final Map<String, Object> params = Map.of("KEY", "VALUE");


    @BeforeEach
    void init() {
        createPrintJobInput = CreatePrintJobInput.builder()
                .tenant(TENANT)
                .url(URL)
                .token(TOKEN)
                .bucketName(BUCKET_NAME)
                .destination(DESTINATION)
                .locale(LOCALE)
                .params(params)
                .printCode(PRINT_CODE)
                .build();
    }

    @Test
    void providePayload_ok() {
        Map<String, Object> expectedOutput = Map.of("_params", params);

        Object result = createPrintJobInput.providePayload();

        assertEquals(expectedOutput, result);
    }

    @Test
    void getPathVariablesMap_ok() {
        Map<String, Object> expectedOutput = Map.of("TENANT_ID", TENANT,
                "PRINT_TYPE_NAME", PRINT_CODE);

        Map<String, Object> result = createPrintJobInput.getPathVariablesMap();

        assertEquals(expectedOutput, result);

    }

    @Test
    void getQueryParamsMap_ok() {
        Map<String, Object> expectedOutput = Map.of("bucket", BUCKET_NAME,
                "dest", DESTINATION);

        Map<String, Object> result = createPrintJobInput.getQueryParamsMap();

        assertEquals(expectedOutput, result);

    }

    @Test
    void provideAuthToken_ok() {
        String result = createPrintJobInput.provideAuthToken();

        assertEquals(TOKEN, result);
    }

    @Test
    void getUrl_ok() {
        String expectedOutput = URL + "/{TENANT_ID}/public/v1/{PRINT_TYPE_NAME}";

        String result = createPrintJobInput.getUrl();

        assertEquals(expectedOutput, result);
    }

    @Test
    void getHttpMethod_ok() {
        String result = createPrintJobInput.getHttpMethod();

        assertEquals(POST_METHOD, result);
    }

    @Test
    void locale_ok() {
        String result = createPrintJobInput.locale();

        assertEquals(LOCALE, result);

    }
}
