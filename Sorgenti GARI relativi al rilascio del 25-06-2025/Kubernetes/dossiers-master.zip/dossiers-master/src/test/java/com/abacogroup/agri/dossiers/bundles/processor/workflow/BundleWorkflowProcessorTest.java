package com.abacogroup.agri.dossiers.bundles.processor.workflow;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.verify;

@Slf4j
@ExtendWith(MockitoExtension.class)
class BundleWorkflowProcessorTest {

	protected static final String TEMPLATE_TENANT_ID = "*";
	protected static final String DOMAIN_NAME = "workflows";
	private final File workflowFileInputMock = new File("TMWorkflow_A.zip");
	private final File workflowFileInputMock_toDelete = new File("TMWorkflow_A.delete.zip");
	private final Path PATH = workflowFileInputMock.toPath();
	private final Path PATH_toDelete = workflowFileInputMock_toDelete.toPath();
	private final ConfigDataMessage configDataMessage = new ConfigDataMessage();

	@Mock
	private WorkflowsBundleWorker workflowsBundleWorker;

	@Mock
	private Jdbi jdbi;
	@InjectMocks
	private BundleWorkflowsProcessor bundleWorkflowsProcessor;

	@BeforeEach
	void init() {
		configDataMessage.setTenantId(TEMPLATE_TENANT_ID);
		bundleWorkflowsProcessor = new BundleWorkflowsProcessor(workflowsBundleWorker, jdbi);
	}

	@Test
	void test_getDomainName() {
		assertEquals(DOMAIN_NAME, bundleWorkflowsProcessor.getDomainName());
	}

	@Test
	void test_getTypeReference() {
		assertEquals(null, bundleWorkflowsProcessor.getTypeReference());
	}

	@Test
	void onMessageInTransaction_ok_doInsertOrUpdate() {
		try {
			configDataMessage.setConfigFiles(List.of(PATH));
			bundleWorkflowsProcessor.onMessageInTransaction(configDataMessage);
			verify(workflowsBundleWorker).insertBundleWorkflow(TEMPLATE_TENANT_ID, workflowFileInputMock);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void onMessageInTransaction_ok_delete() {
		try {
			configDataMessage.setConfigFiles(List.of(PATH_toDelete));
			bundleWorkflowsProcessor.onMessageInTransaction(configDataMessage);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}
/* // TODO when delete method is implemented
	@Test
	void test_delete() {
		bundleWorkflowsProcessor.delete(TEMPLATE_TENANT_ID, workflowFileInputMock_toDelete);
		assert true;
	}
*/
}
