package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.DossierNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.DossierMapper;
import com.abacogroup.agri.dossiers.core.mappers.DossiersByPartyAndYearMapper;
import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DosByPartyAndYearDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierByPartyDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierWithDetailsDTO;
import com.abacogroup.agri.dossiers.db.dao.DossierDAO;
import com.abacogroup.agri.dossiers.db.ntt.*;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.abacogroup.agri.dossiers.utils.PagingParamsFactory.DEFAULT_PAGE_SIZE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class DossiersCrudServiceTest {

	private static final String TENANT = "tenantId";
	private static final String DOSSIER_CODE = "code";
	private static final Long DOSSIER_ID_1 = 1L;
	private static final String DOSSIER_CODE_1 = "app_code_1";
	private static final Long MODULE_ID_1 = 1L;
	private static final String MODULE_CODE_1 = "module_code_1";
	private static final String SECTOR_CODE_1 = "sector_code_1";
	private static final String PROCESS_STATUS_1 = "status_1";
	private static final Integer REFERRED_YEAR = LocalDateTime.now().getYear();
	private static final Long PARTY_ID_1 = 1L;
	private static final Long PROCESS_ID_1 = 1L;
	private static final String USER_1 = "user_1";
	private static final String TENANT_1 = "tenant1";
	private static final String LANG = "LANG";
	private static final LocalDateTime NOW = LocalDateTime.now();
	private static final String PROCESS_STATUS = "start";
	private static final LocalDateTime DEFAULT_NOT_DELETED_DATE = LocalDateTime.ofInstant(Instant.ofEpochSecond(253402300799L), ZoneOffset.UTC);

	private final DossierDTO dossierDTOIn = DossierDTO.builder()
			.moduleId(MODULE_ID_1)
			.referredYear(REFERRED_YEAR)
			.partyId(PARTY_ID_1)
			.processId(PROCESS_ID_1)
			.userIdInsert(USER_1)
			.userIdDelete(null)
			.dtInsert(NOW)
			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.build();

	private final DossierDTO dossierDTOOut = DossierDTO.builder()
			.dossierId(DOSSIER_ID_1)
			.moduleId(MODULE_ID_1)
			.referredYear(REFERRED_YEAR)
			.partyId(PARTY_ID_1)
			.processId(PROCESS_ID_1)
			.userIdInsert(USER_1)
			.userIdDelete(null)
			.dtInsert(NOW)
			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.build();

	private final DossierByPartyNTT dossierByPartyNTT = DossierByPartyNTT.builder()
			.dossier_code(DOSSIER_CODE)
			.dossier_id(DOSSIER_ID_1)
			.party_id(PARTY_ID_1)
			.dt_closed(DEFAULT_NOT_DELETED_DATE.toLocalDate())
			.module_code(MODULE_CODE_1)
			.process_id(PROCESS_ID_1)
			.process_status(PROCESS_STATUS)
			.sector_code(SECTOR_CODE_1)
			.referred_year(REFERRED_YEAR)
			.build();
	private final DossierByPartyDTO dossierByPartyDTO = DossierByPartyDTO.builder()
			.dossierCode(DOSSIER_CODE)
			.dossierId(DOSSIER_ID_1)
			.partyId(PARTY_ID_1)
			.dtClosed(new AbsoluteDate(DEFAULT_NOT_DELETED_DATE.toLocalDate()))
			.moduleCode(MODULE_CODE_1)
			.processId(PROCESS_ID_1)
			.processStatus(PROCESS_STATUS)
			.sectorCode(SECTOR_CODE_1)
			.year(REFERRED_YEAR)
			.build();

	private final DossierNTT dossierNTTMock = DossierNTT.builder()
			.id(DOSSIER_ID_1)
			.module_id(MODULE_ID_1)
			.referred_year(REFERRED_YEAR)
			.party_id(PARTY_ID_1)
			.process_id(PROCESS_ID_1)
			.user_id_insert(USER_1)
			.user_id_delete(null)
			.dt_insert(NOW)
			.dt_delete(DEFAULT_NOT_DELETED_DATE)
			.build();

	private final DossierWithDetailsDTO dossierWithDetailsDTO = DossierWithDetailsDTO.builder()
			.dossierId(DOSSIER_ID_1)
			.moduleId(MODULE_ID_1)
			.referredYear(REFERRED_YEAR)
			.partyId(PARTY_ID_1)
			.processId(PROCESS_ID_1)
			.dossierCode(DOSSIER_CODE)
			.dtClosed(null)
			.processStatus(PROCESS_STATUS)
			.userIdInsert(USER_1)
			.userIdDelete(null)
			.dtInsert(NOW)
			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.build();

	private final DossierWithDetailsNTT dossierWithDetailsNTT = DossierWithDetailsNTT.builder()
			.id(DOSSIER_ID_1)
			.module_id(MODULE_ID_1)
			.referred_year(REFERRED_YEAR)
			.party_id(PARTY_ID_1)
			.process_id(PROCESS_ID_1)
			.dossier_code(DOSSIER_CODE)
			.dt_closed(null)
			.process_status(PROCESS_STATUS)
			.user_id_insert(USER_1)
			.user_id_delete(null)
			.dt_insert(NOW)
			.dt_delete(DEFAULT_NOT_DELETED_DATE)
			.build();

	private final DosByPartyAndYearDTO dosByPartyAndYearDTOMock = DosByPartyAndYearDTO.builder()
			.dossierCode(DOSSIER_CODE_1)
			.dtClosed(null)
			.moduleCode(MODULE_CODE_1)
			.moduleDescription(null)
			.partyId(PARTY_ID_1)
			.sectorCode(SECTOR_CODE_1)
			.sectorDescription(null)
			.year(REFERRED_YEAR)
			.processStatus(PROCESS_STATUS_1)
			.dossierId(DOSSIER_ID_1)
			.build();

	private final DossierByPartyAndYearNTT dossierByPartyAndYearNTT = DossiersByPartyAndYearMapper.INSTANCE
			.dtoToEntity(dosByPartyAndYearDTOMock);

	@Mock
	private DossierMapper dossierMapper;

	@Mock
	private DossierDAO dossierDAO;
	@InjectMocks
	private DossiersCrudService dossiersCrudService;

	@BeforeEach
	protected void init() {
		dossiersCrudService = new DossiersCrudService(dossierDAO, dossierMapper);
	}

	@Test
	void test_retrieveCustomKeyByResultSet() {
		assertNull(dossiersCrudService.retrieveCustomKeyByResultSet(dossierNTTMock));
	}

	@Test
	void test_findRsByCustomKey() {
		Optional<DossierNTT> result = dossiersCrudService.findRsByCustomKey(null);

		assertEquals(Optional.empty(), result);
	}

	@Test
	void test_findById_optional() {
		when(dossierDAO.findById(MODULE_ID_1))
				.thenReturn(List.of(dossierNTTMock));
		when(dossierMapper.entityToDto(dossierNTTMock))
				.thenReturn(dossierDTOOut);

		Optional<DossierDTO> result = dossiersCrudService.findById(MODULE_ID_1);

		assertEquals(Optional.of(dossierDTOOut), result);
	}

	@Test
	void test_findByCode() {
		try {
			when(dossierDAO.findByCode(TENANT, DOSSIER_CODE))
					.thenReturn(List.of(dossierNTTMock));
			when(dossierMapper.entityToDto(dossierNTTMock))
					.thenReturn(dossierDTOOut);

			DossierDTO result = dossiersCrudService.findByCode(TENANT, DOSSIER_CODE);

			assertEquals(dossierDTOOut, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findById() {
		try {
			when(dossierDAO.findById(TENANT, DOSSIER_ID_1))
					.thenReturn(List.of(dossierNTTMock));
			when(dossierMapper.entityToDto(dossierNTTMock))
					.thenReturn(dossierDTOOut);

			DossierDTO result = dossiersCrudService.findById(TENANT, DOSSIER_ID_1);

			assertEquals(dossierDTOOut, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findByCode_ko() {
		try {
			when(dossierDAO.findByCode(TENANT, DOSSIER_CODE))
					.thenReturn(List.of());

			assertThrows(ObjectNotFoundException.class, () ->
					dossiersCrudService.findByCode(TENANT, DOSSIER_CODE));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findById_ko() {
		try {
			when(dossierDAO.findById(TENANT, DOSSIER_ID_1))
					.thenReturn(List.of());

			assertThrows(ObjectNotFoundException.class, () ->
					dossiersCrudService.findById(TENANT, DOSSIER_ID_1));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void findByIdAlsoExpired_ok() {
		try {
			when(dossierDAO.findByIdAlsoExpired(TENANT, DOSSIER_ID_1))
					.thenReturn(List.of(dossierNTTMock));
			when(dossierMapper.entityToDto(dossierNTTMock))
					.thenReturn(dossierDTOOut);

			DossierDTO result = dossiersCrudService.findByIdAlsoExpired(TENANT, DOSSIER_ID_1);

			assertEquals(dossierDTOOut, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void findByIdAlsoExpired_ko() {
		try {
			when(dossierDAO.findByIdAlsoExpired(TENANT, DOSSIER_ID_1))
					.thenReturn(List.of());

			assertThrows(ObjectNotFoundException.class, () ->
					dossiersCrudService.findByIdAlsoExpired(TENANT, DOSSIER_ID_1));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void find_ok() {
		when(dossierDAO.infinite(any(), eq(null), eq(DEFAULT_PAGE_SIZE)))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(dossierByPartyNTT), null));

		InfiniteListResults<DossierByPartyDTO> results = dossiersCrudService.find(TENANT, PARTY_ID_1, 0, List.of(), null);

		assertEquals(List.of(dossierByPartyDTO), results.getRecords());
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_insert() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(dossierDAO.nextSequenceVal()).thenReturn(MODULE_ID_1);
			when(dossierDAO.findById(MODULE_ID_1)).thenReturn(List.of(dossierNTTMock));
			dossiersCrudService.insert(dossierDTOIn, USER_1);
			when(dossierMapper.dtoToEntity(dossierDTOIn)).thenReturn(dossierNTTMock);
			when(dossierMapper.entityToDto(dossierNTTMock)).thenReturn(dossierDTOOut);

			verify(dossierDAO).inTransaction(handleConsumerLambdaCaptor.capture());

			DossierDTO actual = (DossierDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dossierDAO);

			assertEquals(dossierDTOOut, actual);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_update() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(dossierDAO.nextSequenceVal()).thenReturn(MODULE_ID_1);
			when(dossierDAO.getCurrentTimestamp()).thenReturn(LocalDateTime.now());
			when(dossierDAO.findById(MODULE_ID_1)).thenReturn(List.of(dossierNTTMock));
			dossiersCrudService.update(MODULE_ID_1, dossierDTOIn, USER_1);
			when(dossierMapper.dtoToEntity(dossierDTOIn)).thenReturn(dossierNTTMock);
			when(dossierMapper.entityToDto(dossierNTTMock)).thenReturn(dossierDTOOut);

			verify(dossierDAO).inTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().inTransaction(dossierDAO);

			verify(dossierDAO, times(2)).inTransaction(handleConsumerLambdaCaptor.capture());

			DossierDTO actual = (DossierDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dossierDAO);

			assertEquals(dossierDTOOut, actual);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_delete() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);
			dossiersCrudService.delete(MODULE_ID_1, USER_1);

			verify(dossierDAO).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useTransaction(dossierDAO);
			verify(dossierDAO).logicallyDeleteById(eq(MODULE_ID_1), eq(USER_1), any());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findWithDetailsByDossierCode_ok() {
		try {
			when(dossierDAO.findWithDetailByCode(TENANT, DOSSIER_CODE, null)).thenReturn(List.of(dossierWithDetailsNTT));
			assertEquals(dossierWithDetailsDTO, dossiersCrudService.findWithDetailsByDossierCode(TENANT, DOSSIER_CODE));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findWithDetailsByDossierId_ok() {
		when(dossierDAO.findWithDetailById(TENANT, DOSSIER_ID_1, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(dossierWithDetailsNTT));

		DossierWithDetailsDTO result = dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID_1);

		assertEquals(dossierWithDetailsDTO, result);
	}

	@Test
	void test_findWithDetailsByDossierId_ko_DossierNotFoundRuntimeException() {
		when(dossierDAO.findWithDetailById(TENANT, DOSSIER_ID_1, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of());

		assertThrows(DossierNotFoundRuntimeException.class, () ->
				dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID_1));
	}

	@Test
	void test_findWithDetailsByDossierCode_ko_DossierNotFoundByCodeRuntimeException() {
		try {
			when(dossierDAO.findWithDetailByCode(TENANT, DOSSIER_CODE, MDC.get(MDCPreFilter.LOCALE)))
					.thenReturn(Collections.emptyList());

			assertThrows(DossierNotFoundRuntimeException.class, () ->
					dossiersCrudService.findWithDetailsByDossierCode(TENANT, DOSSIER_CODE));

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findAllByPartyId_ok() {
		when(dossierDAO.findAllByPartyId(TENANT_1, PARTY_ID_1)).thenReturn(List.of(dossierNTTMock));
		when(dossierMapper.entityToDto(dossierNTTMock)).thenReturn(dossierDTOOut);

		List<DossierDTO> expectedResults = List.of(dossierDTOOut);

		List<DossierDTO> results = dossiersCrudService.findAllByPartyId(TENANT_1, PARTY_ID_1);

		assertEquals(expectedResults, results);
	}

	@Test
	void test_find_by_party_and_year() {
		when(dossierDAO.infinite(any(), any(), anyInt())).thenReturn(new InfiniteListResultsImpl<>(List.of(dossierByPartyAndYearNTT), null));

		InfiniteListResults<DosByPartyAndYearDTO> results = dossiersCrudService.find(TENANT_1, PARTY_ID_1, REFERRED_YEAR, LANG);

		assertEquals(List.of(dosByPartyAndYearDTOMock), results.getRecords());
	}

	@Test
	void test_findWithModuleCode() {
		when(dossierDAO.find(TENANT, PARTY_ID_1, REFERRED_YEAR, MODULE_CODE_1, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(dossierByPartyAndYearNTT));

		List<DosByPartyAndYearDTO> result = dossiersCrudService.findWithModuleCode(TENANT, PARTY_ID_1, REFERRED_YEAR, MODULE_CODE_1);

		assertEquals(List.of(dosByPartyAndYearDTOMock), result);
	}

	@Test
	void findInfiniteResults_ok() {
		InfiniteListResults<Object> mockResult = new InfiniteListResultsImpl<>(List.of(dossierByPartyAndYearNTT), null);
		when(dossierDAO.infinite(any(), any(), anyInt())).thenReturn(mockResult);
			List<DosByPartyAndYearDTO> result =
				dossiersCrudService.findInfiniteResults(TENANT, MODULE_CODE_1, PARTY_ID_1, REFERRED_YEAR, PROCESS_STATUS, List.of(DOSSIER_ID_1), null)
						.getRecords();
			assertEquals(List.of(dosByPartyAndYearDTOMock), result);
	}

	@Test
	void test_findAllByModuleId() {
		when(dossierDAO.findAllByModuleId(TENANT, MODULE_ID_1))
				.thenReturn(List.of(dossierNTTMock));
		when(dossierMapper.entityToDto(dossierNTTMock))
				.thenReturn(dossierDTOOut);

		List<DossierDTO> result = dossiersCrudService.findAllByModuleId(TENANT, MODULE_ID_1);

		assertEquals(List.of(dossierDTOOut), result);
	}

	@Test
	void test_findAllByModuleIdAndPartyIdAndReferredYear() {
		when(dossierDAO.findAllByModuleIdAndPartyIdAndReferredYear(TENANT, MODULE_ID_1, PARTY_ID_1, REFERRED_YEAR))
				.thenReturn(List.of(dossierWithDetailsNTT));

		List<DossierWithDetailsDTO> result =
				dossiersCrudService.findAllByModuleIdAndPartyIdAndReferredYear(TENANT, MODULE_ID_1, PARTY_ID_1, REFERRED_YEAR);

		assertEquals(List.of(dossierWithDetailsDTO), result);
	}

	@Test
	void test_getDossierAndUpdateProcessId_findById() {
		try {
			when(dossierDAO.findById(TENANT, DOSSIER_ID_1))
					.thenReturn(List.of(dossierNTTMock));
			when(dossierMapper.entityToDto(dossierNTTMock))
					.thenReturn(dossierDTOOut);

			dossiersCrudService.getDossierAndUpdateProcessId(TENANT, DOSSIER_ID_1, PROCESS_ID_1, false);

			verify(dossierDAO, times(1)).updateProcessId(DOSSIER_ID_1, PROCESS_ID_1);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getDossierAndUpdateProcessId_findByIdAlsoExpired() {
		try {
			when(dossierDAO.findByIdAlsoExpired(TENANT, DOSSIER_ID_1))
					.thenReturn(List.of(dossierNTTMock));
			when(dossierMapper.entityToDto(dossierNTTMock))
					.thenReturn(dossierDTOOut);

			dossiersCrudService.getDossierAndUpdateProcessId(TENANT, DOSSIER_ID_1, PROCESS_ID_1, true);

			verify(dossierDAO, times(1)).updateProcessId(DOSSIER_ID_1, PROCESS_ID_1);
		} catch (Exception e) {
			fail(e);
		}
	}

}
