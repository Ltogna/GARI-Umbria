package com.abacogroup.agri.dossiers.bundles.processor.env;

import com.abacogroup.agri.dossiers.bundles.model.env.BundleDossierEnvInDTO;
import com.abacogroup.agri.dossiers.bundles.model.env.BundleDossierEnvMessage;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

@Slf4j
@ExtendWith(MockitoExtension.class)
class BundleDossierEnvProcessorTest {

	protected static final String TEMPLATE_TENANT_ID = "*";
	protected static final String DOMAIN_NAME = "dossiers-env";
	private static final String ENV_KEY = "env_key";
	private static final String VALUE = "value";
	private static final Integer FL_CLIENT = 1;

	private static final Path PATH = new File("test.json").toPath();
	private final BundleDossierEnvInDTO bundleDossierEnvInDTO = BundleDossierEnvInDTO.builder()
			.key(ENV_KEY)
			.value(VALUE)
			.flClient(FL_CLIENT)
			.build();

	private final BundleDossierEnvMessage bundleDossierEnvMessage = BundleDossierEnvMessage.builder()
			.bundleDossierEnvInDTOList(List.of(bundleDossierEnvInDTO))
			.build();

	private final ConfigDataMessage configDataMessage = new ConfigDataMessage();
	@Mock
	private DossierEnvBundleWorker dossierEnvBundleWorker;
	@Mock
	private ObjectMapper objectMapper;
	@Mock
	private Jdbi jdbi;
	@InjectMocks
	private BundleDossierEnvProcessor bundleDossierEnvProcessor;

	@BeforeEach
	void init() {
		configDataMessage.setTenantId(TEMPLATE_TENANT_ID);
		bundleDossierEnvProcessor = new BundleDossierEnvProcessor(objectMapper, dossierEnvBundleWorker, jdbi);
	}

	@Test
	void test_getDomainName() {
		assertEquals(DOMAIN_NAME, bundleDossierEnvProcessor.getDomainName());
	}

	@Test
	void test_getTypeReference() {
		assertEquals(new TypeReference<BundleDossierEnvMessage>() {
		}.getType(), bundleDossierEnvProcessor.getTypeReference().getType());
	}

	@Test
	void onMessageInTransaction() {
		try {
			configDataMessage.setConfigFiles(List.of(PATH));
			bundleDossierEnvProcessor.onMessageInTransaction(configDataMessage);
			verify(objectMapper).readValue(eq(PATH.toFile()), any(TypeReference.class));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_doInsertOrUpdate() {
		bundleDossierEnvProcessor.doInsertOrUpdate(TEMPLATE_TENANT_ID, bundleDossierEnvMessage);
		verify(dossierEnvBundleWorker).upsertDossierEnvironments(TEMPLATE_TENANT_ID, bundleDossierEnvMessage);
	}

	// TODO when delete method is implemented
	@Test
	void test_delete() {
		bundleDossierEnvProcessor.delete(TEMPLATE_TENANT_ID, bundleDossierEnvMessage);
		assert true;
	}
}
