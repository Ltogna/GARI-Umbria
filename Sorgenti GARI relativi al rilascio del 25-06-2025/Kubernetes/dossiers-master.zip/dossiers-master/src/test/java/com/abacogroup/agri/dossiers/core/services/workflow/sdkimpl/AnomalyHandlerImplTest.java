package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.model.dto.publics.AnomalyDTO;
import com.abacogroup.agri.dossiers.core.services.crud.AnomaliesCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.AnomalyOutDTO;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class AnomalyHandlerImplTest {

	private static final Long PK_ID_1 = 1L;
	private static final Long DOSSIER_ID_1 = 30L;
	private static final String ANOMALY_CODE = "anomaly code";
	private static final String ANOMALY_DESCRIPTION = "anomaly description";
	private static final String SEVERITY = "severity";
	private static final String TENANT_1 = "tenant_1";
	private static final String USER_1 = "user_1";

	private final AnomalyDTO anomaly = AnomalyDTO.builder()
			.pkid(PK_ID_1)
			.severity(SEVERITY)
			.anomalyCode(ANOMALY_CODE)
			.anomalyDesc(ANOMALY_DESCRIPTION)
			.build();

	@Mock
	private AnomaliesCrudService anomaliesCrudService;

	@InjectMocks
	AnomalyHandlerImpl anomalyHandler;

	@Test
	void test_getAllAnomalies_ok() {
		List<AnomalyDTO> expectedOutput = List.of(AnomalyDTO.builder()
				.pkid(PK_ID_1)
				.dossierId(DOSSIER_ID_1)
				.anomalyCode(ANOMALY_CODE)
				.anomalyDesc(ANOMALY_DESCRIPTION)
				.severity(SEVERITY)
				.build());

		when(anomaliesCrudService.find(TENANT_1, DOSSIER_ID_1))
				.thenReturn(expectedOutput);

		List<AnomalyDTO> result = anomalyHandler.getAnomaliesForApp(TENANT_1, DOSSIER_ID_1);

		assertEquals(expectedOutput, result);
	}

	@Test
	void test_deleteAnomaly_ok() {
		anomalyHandler.deleteAnomaly(TENANT_1, DOSSIER_ID_1, ANOMALY_CODE, USER_1);

		verify(anomaliesCrudService, times(1)).deleteByAnomalyCode(TENANT_1, DOSSIER_ID_1, ANOMALY_CODE, USER_1);
	}

	@Test
	void test_createAnomaly_insert_ok() {
		AnomalyDTO insertAnomaly = AnomalyDTO.builder()
				.anomalyCode(ANOMALY_CODE)
				.dossierId(DOSSIER_ID_1)
				.build();

		when(anomaliesCrudService.find(TENANT_1, DOSSIER_ID_1, ANOMALY_CODE))
				.thenReturn(Optional.empty());

		anomalyHandler.insertAnomaly(TENANT_1, DOSSIER_ID_1, ANOMALY_CODE, USER_1);

		verify(anomaliesCrudService, times(1)).insert(insertAnomaly, USER_1);
	}

	@Test
	void test_createAnomaly_update_ok() {
		AnomalyDTO updateAnomaly = AnomalyDTO.builder()
				.anomalyCode(ANOMALY_CODE)
				.dossierId(DOSSIER_ID_1)
				.build();
		AnomalyDTO existingAnomaly = AnomalyDTO.builder()
				.pkid(PK_ID_1)
				.build();

		when(anomaliesCrudService.find(TENANT_1, DOSSIER_ID_1, ANOMALY_CODE))
				.thenReturn(Optional.of(existingAnomaly));

		anomalyHandler.insertAnomaly(TENANT_1, DOSSIER_ID_1, ANOMALY_CODE, USER_1);

		verify(anomaliesCrudService, times(1)).update(PK_ID_1, updateAnomaly, USER_1);
	}

	@Test
	void test_createAnomaly_catchException_ok() {
		AnomalyDTO updateAnomaly = AnomalyDTO.builder()
				.anomalyCode(ANOMALY_CODE)
				.dossierId(DOSSIER_ID_1)
				.build();
		AnomalyDTO existingAnomaly = AnomalyDTO.builder()
				.pkid(PK_ID_1)
				.build();

		when(anomaliesCrudService.find(TENANT_1, DOSSIER_ID_1, ANOMALY_CODE))
				.thenReturn(Optional.of(existingAnomaly));
		when(anomaliesCrudService.update(PK_ID_1, updateAnomaly, USER_1))
				.thenThrow(ObjectNotFoundRuntimeException.class);

		anomalyHandler.insertAnomaly(TENANT_1, DOSSIER_ID_1, ANOMALY_CODE, USER_1);

		verify(anomaliesCrudService, times(0)).insert(any(), anyString());
	}

	@Test
	void getAnomalies_ok() {
		when(anomaliesCrudService.find(TENANT_1, DOSSIER_ID_1))
				.thenReturn(List.of(anomaly));

		AnomalyOutDTO expectedOutput = AnomalyOutDTO.builder()
				.pkid(PK_ID_1)
				.severity(SEVERITY)
				.anomalyCode(ANOMALY_CODE)
				.anomalyDesc(ANOMALY_DESCRIPTION)
				.build();

		List<AnomalyOutDTO> result = anomalyHandler.getAnomalies(TENANT_1, DOSSIER_ID_1);

		assertEquals(List.of(expectedOutput), result);
	}
}
