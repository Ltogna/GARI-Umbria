package com.abacogroup.agri.dossiers.bundles.processor;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.HandleConsumer;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AbstractBundleDossiersProcessorTest {

	private static final String TENANT_ID = "*";
	private static final String MESSAGE = "message";
	private static final File FILE = new File("test.json");
	private static final File FILE_TO_DELETE = new File("test.delete.json");

	@Mock
	private ObjectMapper objectMapper;
	@Mock
	private Jdbi jdbi;
	@Mock
	private ConfigDataMessage configDataMessage;
	@InjectMocks
	private AbstractBundleDossiersProcessorImpl abstractBundleDossiersProcessor;
	@Mock
	private Handle handle;

	@BeforeEach
	void init() {
		abstractBundleDossiersProcessor = new AbstractBundleDossiersProcessorImpl(objectMapper, jdbi);
	}

	@Test
	void test_processFile_doInsertOrUpdate_ok() {
		try {
			when(objectMapper.readValue(eq(FILE), any(TypeReference.class))).thenReturn(MESSAGE);
			abstractBundleDossiersProcessor.processFile(TENANT_ID, FILE);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_processFile_delete_ok() {
		try {
			when(objectMapper.readValue(eq(FILE_TO_DELETE), any(TypeReference.class))).thenReturn(MESSAGE);
			abstractBundleDossiersProcessor.processFile(TENANT_ID, FILE_TO_DELETE);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_processFile_doInsertOrUpdate_IllegalStateException_ko() throws IOException {
		File file = new File("test.json");
		when(objectMapper.readValue(eq(file), any(TypeReference.class))).thenThrow(new IOException());
		assertThrows(IllegalStateException.class, () -> {
			abstractBundleDossiersProcessor.processFile(TENANT_ID, file);
		});
	}

	@Test
	void test_onMessage() {
		try {
			ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);
			abstractBundleDossiersProcessor.onMessage(configDataMessage);
			verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useHandle(handle);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	private static class AbstractBundleDossiersProcessorImpl extends AbstractBundleDossiersProcessor<String> {

		private AbstractBundleDossiersProcessorImpl(ObjectMapper objectMapper, Jdbi jdbi) {
			super(objectMapper, jdbi);
		}

		@Override
		protected TypeReference<String> getTypeReference() {
			return new TypeReference<>() {
			};
		}

		@Override
		protected void onMessageInTransaction(ConfigDataMessage message) {

		}

		@Override
		protected void delete(String tenantId, String message) {

		}

		@Override
		protected void doInsertOrUpdate(String tenantId, String message) {

		}

		@Override
		public String getDomainName() {
			return "agri-task-manager";
		}
	}
}
