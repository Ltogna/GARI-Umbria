package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.mappers.ModuleMapper;
import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleDTO;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleWithDetailDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.ModuleByPointInTimeDTO;
import com.abacogroup.agri.dossiers.core.services.I18NService;
import com.abacogroup.agri.dossiers.db.dao.ModuleDAO;
import com.abacogroup.agri.dossiers.db.ntt.ModuleNTT;
import com.abacogroup.agri.dossiers.db.ntt.ModuleWithDetailNTT;
import com.abacogroup.agri.dossiers.db.ntt.dossiers.RsI18N;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;

import static com.abacogroup.agri.dossiers.core.services.crud.ModuleCrudService.I18N_MODULES_TABLE;
import static com.abacogroup.agri.dossiers.utils.PagingParamsFactory.DEFAULT_PAGE_SIZE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ModuleCrudServiceTest {

	private static final String TENANT_ID = "*";
	private static final Long MODULE_ID_1 = 1L;
	private static final String MODULE_CODE_1 = "module_code_1";
	private static final Long SECTOR_ID_1 = 1L;
	private static final String SECTOR_CODE_1 = "sector_code_1";
	private static final String WORKFLOW_CODE = "workflow_code";
	private static final String USER_1 = "user_1";
	private static final LocalDateTime NOW = LocalDateTime.now();
	private static final LocalDateTime DEFAULT_NOT_DELETED_DATE = LocalDateTime.ofInstant(Instant.ofEpochSecond(253402300799L), ZoneOffset.UTC);
	private static final AbsoluteDate POINT_IN_TIME = new AbsoluteDate("20230101");
	private static final AbsoluteDate DT_VALIDITY = new AbsoluteDate(LocalDate.now());

	private final ModuleDTO moduleDTOIn = ModuleDTO.builder()
			.moduleCode(MODULE_CODE_1)
			.sectorId(SECTOR_ID_1)
			.workflowCode(WORKFLOW_CODE)
			//			.userIdInsert(USER_1)
			//			.userIdDelete(null)
			//			.dtInsert(NOW)
			//			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.build();

	private final ModuleDTO moduleDTOOut = ModuleDTO.builder()
			.moduleId(MODULE_ID_1)
			.moduleCode(MODULE_CODE_1)
			.sectorId(SECTOR_ID_1)
			.workflowCode(WORKFLOW_CODE)
			.flAmendModule(false)
			//			.userIdInsert(USER_1)
			//			.userIdDelete(null)
			//			.dtInsert(NOW)
			//			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.build();

	private final ModuleWithDetailDTO moduleWithDetailDTOOut = ModuleWithDetailDTO.builder()
			.moduleId(MODULE_ID_1)
			.moduleCode(MODULE_CODE_1)
			.sectorId(SECTOR_ID_1)
			.flAmendModule(false)
			.workflowCode(WORKFLOW_CODE)
			//			.userIdInsert(USER_1)
			//			.userIdDelete(null)
			//			.dtInsert(NOW)
			//			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.build();

	private final ModuleNTT moduleNTTMock = ModuleNTT.builder()
			.id(MODULE_ID_1)
			.module_code(MODULE_CODE_1)
			.sector_id(SECTOR_ID_1)
			.workflow_code(WORKFLOW_CODE)
			.user_id_insert(USER_1)
			.user_id_delete(null)
			.dt_insert(NOW)
			.dt_delete(DEFAULT_NOT_DELETED_DATE)
			.fl_amend_module(0)
			.build();

	private final ModuleWithDetailNTT moduleWithDetailNTT = ModuleWithDetailNTT.builder()
			.id(MODULE_ID_1)
			.module_code(MODULE_CODE_1)
			.sector_id(SECTOR_ID_1)
			.workflow_code(WORKFLOW_CODE)
			.user_id_insert(USER_1)
			.user_id_delete(null)
			.dt_insert(NOW)
			.dt_delete(DEFAULT_NOT_DELETED_DATE)
			.fl_amend_module(0)
			.build();

	private final RsI18N rsI18NMock = RsI18N.builder()
			.tenant_id(TENANT_ID)
			.i18n_text("text")
			.i18n_value("value")
			.field_name("field_name")
			.table_name("table_name")
			.lang("lang")
			.build();
	private final ModuleByPointInTimeDTO moduleByPointInTimeDTO = ModuleByPointInTimeDTO.builder()
			.moduleCode(MODULE_CODE_1)
			.flAmendModule(1)
			.sectorCode(SECTOR_CODE_1)
			.build();

	private final ModuleMapper moduleDetailsMapper = ModuleMapper.INSTANCE;
	@Mock
	private ModuleDAO moduleDAO;
	@Mock
	private I18NService i18NService;
	@InjectMocks
	private ModuleCrudService moduleCrudService;

	@BeforeEach
	protected void init() {
		moduleCrudService = new ModuleCrudService(moduleDAO, moduleDetailsMapper, i18NService);
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_insert() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(moduleDAO.nextSequenceVal()).thenReturn(MODULE_ID_1);
			when(moduleDAO.findById(MODULE_ID_1)).thenReturn(List.of(moduleNTTMock));
			moduleCrudService.insert(moduleDTOIn, USER_1);

			verify(moduleDAO).inTransaction(handleConsumerLambdaCaptor.capture());

			ModuleDTO actual = (ModuleDTO) handleConsumerLambdaCaptor.getValue().inTransaction(moduleDAO);

			assertEquals(moduleDTOOut, actual);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_update() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(moduleDAO.nextSequenceVal()).thenReturn(MODULE_ID_1);
			when(moduleDAO.getCurrentTimestamp()).thenReturn(LocalDateTime.now());
			when(moduleDAO.findById(MODULE_ID_1)).thenReturn(List.of(moduleNTTMock));
			moduleCrudService.update(MODULE_ID_1, moduleDTOIn, USER_1);

			verify(moduleDAO).inTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().inTransaction(moduleDAO);

			verify(moduleDAO, times(2)).inTransaction(handleConsumerLambdaCaptor.capture());

			ModuleDTO actual = (ModuleDTO) handleConsumerLambdaCaptor.getValue().inTransaction(moduleDAO);

			assertEquals(moduleDTOOut, actual);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_delete() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);
			moduleCrudService.delete(MODULE_ID_1, USER_1);

			verify(moduleDAO).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useTransaction(moduleDAO);
			verify(moduleDAO).logicallyDeleteById(eq(MODULE_ID_1), eq(USER_1), any());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findAllModulesWithDetail() {
		try {
			when(moduleDAO.findAllModulesWithDetail(TENANT_ID)).thenReturn(List.of(moduleWithDetailNTT));
			assertEquals(List.of(moduleWithDetailDTOOut), moduleCrudService.findAllModulesWithDetail(TENANT_ID));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_getAllModuleI18NByTenantAndCode() {
		try {
			when(i18NService.getAllI18NbyCode(TENANT_ID, I18N_MODULES_TABLE, MODULE_CODE_1)).thenReturn(List.of(rsI18NMock));
			assertEquals(List.of(rsI18NMock), moduleCrudService.getAllModuleI18NByTenantAndCode(TENANT_ID, MODULE_CODE_1));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_insertModuleI18N() {
		try {
			moduleCrudService.insertModuleI18N(TENANT_ID, MODULE_CODE_1, "lang", "text");
			verify(i18NService).insertI18N(TENANT_ID, I18N_MODULES_TABLE, ModuleCrudService.MODULE_I18N.MODULE_CODE.getCode(), "lang", MODULE_CODE_1, "text");
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_deleteModuleI18N() {
		try {
			moduleCrudService.deleteModuleI18N(TENANT_ID, MODULE_CODE_1, "lang");
			verify(i18NService).deleteI18N(TENANT_ID, I18N_MODULES_TABLE, ModuleCrudService.MODULE_I18N.MODULE_CODE.getCode(), MODULE_CODE_1, "lang");
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findAllModulesBySectorId() {
		try {
			when(moduleDAO.findAllModulesBySectorId(TENANT_ID, SECTOR_ID_1)).thenReturn(List.of(moduleNTTMock));
			assertEquals(List.of(moduleDTOOut), moduleCrudService.findAllModulesBySectorId(TENANT_ID, SECTOR_ID_1));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findById() {
		try {
			when(moduleDAO.findById(MODULE_ID_1)).thenReturn(List.of(moduleNTTMock));
			assertEquals(Optional.of(moduleDTOOut), moduleCrudService.findById(MODULE_ID_1));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findByCode() {
		try {
			when(moduleDAO.findByCode(TENANT_ID, MODULE_CODE_1)).thenReturn(List.of(moduleNTTMock));
			assertEquals(Optional.of(moduleDTOOut), moduleCrudService.findByCode(TENANT_ID, MODULE_CODE_1));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findByModuleCodeAndSectorCode() {
		try {
			when(moduleDAO.findByModuleCodeAndSectorCode(TENANT_ID, MODULE_CODE_1, SECTOR_CODE_1)).thenReturn(List.of(moduleNTTMock));
			assertEquals(Optional.of(moduleDTOOut), moduleCrudService.findByModuleCodeAndSectorCode(TENANT_ID, MODULE_CODE_1, SECTOR_CODE_1));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findInfinite() {
		try {
			InfiniteListResults<Object> infiniteListNttResults = new InfiniteListResultsImpl<>(List.of(moduleNTTMock), null);
			when(moduleDAO.infinite(any(), eq(null), eq(DEFAULT_PAGE_SIZE))).thenReturn(infiniteListNttResults);
			assertEquals(infiniteListNttResults.getRecords(), moduleCrudService.find(TENANT_ID, POINT_IN_TIME, null, null).getRecords());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e.getMessage(), e);
		}
	}

	@Test
	void find_ok() {
		when(moduleDAO.findByDateAndAmendFl(TENANT_ID, POINT_IN_TIME, 1, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(moduleByPointInTimeDTO));

		List<ModuleByPointInTimeDTO> result = moduleCrudService.find(TENANT_ID, POINT_IN_TIME, 1);

		assertEquals(List.of(moduleByPointInTimeDTO), result);
	}

	@Test
	void test_retrieveCustomKeyByResultSet() {
		assertNull(moduleCrudService.retrieveCustomKeyByResultSet(moduleNTTMock));
	}

	@Test
	void test_findRsByCustomKey() {
		Optional<ModuleNTT> result = moduleCrudService.findRsByCustomKey(null);

		assertEquals(Optional.empty(), result);
	}

	@Test
	void updateWorkflwoCode_ok() {
		moduleCrudService.updateWorkflwoCode(MODULE_ID_1, WORKFLOW_CODE);
		verify(moduleDAO, times(1)).updateWorkflowCode(MODULE_ID_1, WORKFLOW_CODE);
	}

	@Test
	void findValidAmendModulesWithDetailByModuleId_ok() {
		when(moduleDAO.findValidModulesWithDetailByModuleId(TENANT_ID, MODULE_ID_1, DT_VALIDITY, 0, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(moduleWithDetailNTT));

		List<ModuleWithDetailDTO> result = moduleCrudService.findValidAmendModulesWithDetailByModuleId(TENANT_ID, MODULE_ID_1, 0, DT_VALIDITY);

		assertEquals(List.of(moduleWithDetailDTOOut), result);
	}

	@Test
	void findModulesWithDetailByModuleIds_ok() {
		when(moduleDAO.findModulesWithDetailByModuleIds(TENANT_ID, List.of(MODULE_ID_1), DT_VALIDITY, 0, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(moduleWithDetailNTT));

		List<ModuleWithDetailDTO> result = moduleCrudService.findModulesWithDetailByModuleIds(TENANT_ID, List.of(MODULE_ID_1), 0, DT_VALIDITY);

		assertEquals(List.of(moduleWithDetailDTOOut), result);
	}

	@Test
	void findModulesWithDetailByModuleIds_nullModuleList_ok() {
		List<ModuleWithDetailDTO> result = moduleCrudService.findModulesWithDetailByModuleIds(TENANT_ID, null, 0, DT_VALIDITY);

		assertEquals(List.of(), result);
	}

	@Test
	void findModulesWithDetailByModuleIds_emptyModuleList_ok() {
		List<ModuleWithDetailDTO> result = moduleCrudService.findModulesWithDetailByModuleIds(TENANT_ID, List.of(), 0, DT_VALIDITY);

		assertEquals(List.of(), result);
	}

	@Test
	void findAllModulesWithDetailBySectorId_ok() {
		when(moduleDAO.findAllModulesWithDetailBySectorId(TENANT_ID, SECTOR_ID_1))
				.thenReturn(List.of(moduleWithDetailNTT));

		List<ModuleWithDetailDTO> result = moduleCrudService.findAllModulesWithDetailBySectorId(TENANT_ID, SECTOR_ID_1);

		assertEquals(List.of(moduleWithDetailDTOOut), result);
	}
}
