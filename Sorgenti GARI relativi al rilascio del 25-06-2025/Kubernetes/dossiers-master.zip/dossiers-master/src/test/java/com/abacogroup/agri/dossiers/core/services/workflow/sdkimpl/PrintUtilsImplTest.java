package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.model.dto.DossierProfileDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierWithDetailsDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.PrintDetailsOutDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierProfilesCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.agri.dossiers.core.services.print.PrintService;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import jakarta.ws.rs.core.SecurityContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith({MockitoExtension.class})
class PrintUtilsImplTest {
    @Mock
    private DossiersCrudService dossiersCrudService;
    @Mock
    private DossierProfilesCrudService dossierProfilesCrudService;
    @Mock
    private PrintService printService;
    @Mock
    private Sso2Client sso2Client;

    @InjectMocks
    private PrintUtilsImpl printUtils;

    private static final String TENANT = "ADMIN";
    private static final Long DOSSIER_ID = 5L;
    private static final String PRINT_CODE = "Print Code";
    private static final String PRINT_DESCRIPTION = "Print Description";
    private static final String LOCALE = MDC.get(MDCPreFilter.LOCALE);
    private static final String USERNAME = "Username";
    private static final User USER = new User(USERNAME, TENANT);
    private static final Long PROCESS_ID = 10L;
    private static final String PROCESS_STATUS = "Process Status";
    private static final Long MODULE_ID = 15L;
    private static final Long PARTY_ID = 123456789L;
    private static final Integer REFERRED_YEAR = 2023;
    private static final Long PKID = 1L;
    private static final String PROFILE_CODE = "Profile Code";
    private static final String PROFILE_CODE_DESCRIPTION = "Profile Code Description";
    private static final Long PRINT_CONFIG_ID = 7L;

    private final DossierWithDetailsDTO dossierWithDetailsDTO = DossierWithDetailsDTO.builder()
            .dossierId(DOSSIER_ID)
            .dossierCode(DOSSIER_ID.toString())
            .processId(PROCESS_ID)
            .processStatus(PROCESS_STATUS)
            .moduleId(MODULE_ID)
            .partyId(PARTY_ID)
            .referredYear(REFERRED_YEAR)
            .build();
    private final DossierProfileDTO dossierProfileDTO = DossierProfileDTO.builder()
            .pkid(PKID)
            .profileCode(PROFILE_CODE)
            .profileCodeDescription(PROFILE_CODE_DESCRIPTION)
            .dossierId(DOSSIER_ID)
            .build();
    private final PrintDetailsOutDTO printDetailsOutDTO = PrintDetailsOutDTO.builder()
            .printConfigId(PRINT_CONFIG_ID)
            .printCode(PRINT_CODE)
            .printDescription(PRINT_DESCRIPTION)
            .build();

    @Test
    void startPrint_forceProcessStatus_ok() {
        try {
            SecurityContext sc = mock(SecurityContext.class);

            when(dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID))
                    .thenReturn(dossierWithDetailsDTO);
            when(dossierProfilesCrudService.findAll(TENANT, DOSSIER_ID, LOCALE))
                    .thenReturn(List.of(dossierProfileDTO));
            when(sso2Client.createSecurityContextFromUserName(TENANT, USERNAME))
                    .thenReturn(sc);
            when(printService.getPrintsByModuleIdAndProcessStatus(TENANT, DOSSIER_ID, MODULE_ID, PROCESS_STATUS,
                    List.of(PROFILE_CODE), sc))
                    .thenReturn(List.of(printDetailsOutDTO));

            printUtils.startPrint(TENANT, DOSSIER_ID, PRINT_CODE, LOCALE, USER, Boolean.TRUE, PROCESS_STATUS);

            verify(printService, times(1)).startPrintJob(TENANT, DOSSIER_ID, PARTY_ID,
                    PROCESS_STATUS, List.of(printDetailsOutDTO), PRINT_CODE, USER, LOCALE);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void startPrint_notForceProcessStatus_ok() {
        try {
            SecurityContext sc = mock(SecurityContext.class);

            when(dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID))
                    .thenReturn(dossierWithDetailsDTO);
            when(dossierProfilesCrudService.findAll(TENANT, DOSSIER_ID, LOCALE))
                    .thenReturn(List.of(dossierProfileDTO));
            when(sso2Client.createSecurityContextFromUserName(TENANT, USERNAME))
                    .thenReturn(sc);
            when(printService.getPrintsByModuleIdAndProcessStatus(TENANT, DOSSIER_ID, MODULE_ID, PROCESS_STATUS,
                    List.of(PROFILE_CODE), sc))
                    .thenReturn(List.of(printDetailsOutDTO));

            printUtils.startPrint(TENANT, DOSSIER_ID, PRINT_CODE, LOCALE, USER, Boolean.FALSE, PROCESS_STATUS);

            verify(printService, times(1)).startPrintJob(TENANT, DOSSIER_ID, PARTY_ID,
                    PROCESS_STATUS, List.of(printDetailsOutDTO), PRINT_CODE, USER, LOCALE);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void startPrint_withoutRequiredProfileCodes_ok() {
        try {
            DossierProfileDTO dossierProfileWithoutProfileCode = DossierProfileDTO.builder()
                    .pkid(PKID)
                    .profileCodeDescription(PROFILE_CODE_DESCRIPTION)
                    .dossierId(DOSSIER_ID)
                    .build();

            SecurityContext sc = mock(SecurityContext.class);

            when(dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID))
                    .thenReturn(dossierWithDetailsDTO);
            when(dossierProfilesCrudService.findAll(TENANT, DOSSIER_ID, LOCALE))
                    .thenReturn(List.of(dossierProfileWithoutProfileCode));
            when(sso2Client.createSecurityContextFromUserName(TENANT, USERNAME))
                    .thenReturn(sc);
            when(printService.getPrintsByModuleIdAndProcessStatus(TENANT, DOSSIER_ID, MODULE_ID, PROCESS_STATUS,
                    List.of(""), sc))
                    .thenReturn(List.of(printDetailsOutDTO));

            printUtils.startPrint(TENANT, DOSSIER_ID, PRINT_CODE, LOCALE, USER, Boolean.TRUE, PROCESS_STATUS);

            verify(printService, times(1)).startPrintJob(TENANT, DOSSIER_ID, PARTY_ID,
                    PROCESS_STATUS, List.of(printDetailsOutDTO), PRINT_CODE, USER, LOCALE);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void startPrint_withoutModulesPrint_ok() {
        try {
            SecurityContext sc = mock(SecurityContext.class);

            when(dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID))
                    .thenReturn(dossierWithDetailsDTO);
            when(dossierProfilesCrudService.findAll(TENANT, DOSSIER_ID, LOCALE))
                    .thenReturn(List.of(dossierProfileDTO));
            when(sso2Client.createSecurityContextFromUserName(TENANT, USERNAME))
                    .thenReturn(sc);
            when(printService.getPrintsByModuleIdAndProcessStatus(TENANT, DOSSIER_ID, MODULE_ID, PROCESS_STATUS,
                    List.of(PROFILE_CODE), sc))
                    .thenReturn(List.of());

            printUtils.startPrint(TENANT, DOSSIER_ID, PRINT_CODE, LOCALE, USER, Boolean.TRUE, PROCESS_STATUS);

            verify(printService, times(0)).startPrintJob(anyString(), anyLong(), anyLong(),
                    anyString(), anyList(), anyString(), any(), anyString());
        } catch (Exception e) {
            fail(e);
        }
    }
}