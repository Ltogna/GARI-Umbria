package com.abacogroup.agri.dossiers.core.services;

import com.abacogroup.agri.dossiers.core.exceptions.DossierNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import com.abacogroup.agri.dossiers.core.model.DossierAnomaly;
import com.abacogroup.agri.dossiers.core.model.dto.DossierDetailsDTO;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleDTO;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleDetailsDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierWithDetailsDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierDetailsCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.ModuleCrudService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.*;
import java.util.*;

import static com.abacogroup.agri.dossiers.core.services.AnomaliesService.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AnomaliesServiceTest {

	private static final String TENANT_ID_1 = "tenant_1";
	private static final Long MODULE_ID_1 = 1L;
	private static final String MODULE_CODE_1 = "module_code_1";
	private static final Long SECTOR_ID_1 = 1L;
	private static final Long DOSSIER_ID_1 = 1L;
	private static final Long AMENDED_BY_ID = 2L;
	private static final String DOSSIER_CODE = "code";
	private static final String WORKFLOW_CODE = "workflow_code";
	private static final Long PARTY_ID = 1L;
	private static final Integer REFERRED_YEAR = 2022;
	private static final Long PROCESS_ID_1 = 1L;
	private static final String PROCESS_STATUS = "start";
	private static final String PROCESS_STATUS_DELETED = "DELETED";
	private static final String PROCESS_STATUS_WAIVED = "WAIVED";
	private static final String PROCESS_STATUS_DESCRIPTION = "Inizio Workflow";
	private static final String USER_1 = "user_1";
	private static final LocalDateTime NOW = LocalDateTime.now();
	private static final AbsoluteDate DT_VALIDITY_START = new AbsoluteDate(LocalDate.now());
	private static final AbsoluteDate DT_VALIDITY_START_EMPTY = new AbsoluteDate(LocalDate.of(2020, Month.JANUARY, 1));
	private static final AbsoluteDate DT_VALIDITY_END = new AbsoluteDate(LocalDate.MAX);
	public static final String MODULE_VALIDITY_EXPIRED_ERROR_CODE = "CREATING_DOSSIER_NOT_IN_VALIDITY_PERIOD_ERROR_CODE";
	public static final String MODULE_VALIDITY_EXPIRED_ERROR_MSG = "This module's validity is expired";
	private static final Map<String, Object> METADATA_with_multipleApps = Map
			.of(METADATA_KEY_MULTIPLE_DOSSIERS, ALLOWED_MULTIPLE_DOSSIERS_VALUE);
	private static final Map<String, Object> METADATA_without_multipleApps = Map
			.of(AnomaliesService.METADATA_KEY_MULTIPLE_DOSSIERS, NOT_ALLOWED_MULTIPLE_DOSSIERS_VALUE);
	private static final LocalDateTime DEFAULT_NOT_DELETED_DATE = LocalDateTime.ofInstant(Instant.ofEpochSecond(253402300799L), ZoneOffset.UTC);
	private final ModuleDTO moduleDTOOut = ModuleDTO.builder()
			.moduleId(MODULE_ID_1)
			.moduleCode(MODULE_CODE_1)
			.sectorId(SECTOR_ID_1)
			.workflowCode(WORKFLOW_CODE)
			.build();
	private final ModuleDTO notAmendModule = ModuleDTO.builder()
			.moduleId(MODULE_ID_1)
			.moduleCode(MODULE_CODE_1)
			.sectorId(SECTOR_ID_1)
			.workflowCode(WORKFLOW_CODE)
			.flAmendModule(false)
			.build();
	private final ModuleDTO amendModule = ModuleDTO.builder()
			.moduleId(MODULE_ID_1)
			.moduleCode(MODULE_CODE_1)
			.sectorId(SECTOR_ID_1)
			.workflowCode(WORKFLOW_CODE)
			.flAmendModule(true)
			.build();

	private final DossierWithDetailsDTO dossierWithDetailsDTO = DossierWithDetailsDTO.builder()
			.dossierId(DOSSIER_ID_1)
			.moduleId(MODULE_ID_1)
			.referredYear(REFERRED_YEAR)
			.partyId(PARTY_ID)
			.processId(PROCESS_ID_1)
			.dossierCode(DOSSIER_CODE)
			.dtClosed(null)
			.processStatus(PROCESS_STATUS)
			.processStatusDescription(PROCESS_STATUS_DESCRIPTION)
			.userIdInsert(USER_1)
			.userIdDelete(null)
			.dtInsert(NOW)
			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.build();
	private final DossierDetailsDTO dossierDetails = DossierDetailsDTO.builder()
			.dossierId(DOSSIER_ID_1)
			.dossierCode(DOSSIER_CODE)
			.amendedById(AMENDED_BY_ID)
			.processStatus(PROCESS_STATUS)
			.build();
	private final DossierDetailsDTO dossierDetailsWaived = DossierDetailsDTO.builder()
			.dossierId(DOSSIER_ID_1)
			.dossierCode(DOSSIER_CODE)
			.amendedById(AMENDED_BY_ID)
			.processStatus(PROCESS_STATUS_WAIVED)
			.build();
	private final DossierDetailsDTO dossierDetailsWithoutAmendedById = DossierDetailsDTO.builder()
			.dossierId(DOSSIER_ID_1)
			.dossierCode(DOSSIER_CODE)
			.processStatus(PROCESS_STATUS)
			.build();
	private final DossierDetailsDTO deletedDossierDetails = DossierDetailsDTO.builder()
			.dossierId(DOSSIER_ID_1)
			.dossierCode(DOSSIER_CODE)
			.amendedById(AMENDED_BY_ID)
			.processStatus(PROCESS_STATUS_DELETED)
			.build();

	@Mock
	private DossiersService dossiersService;
	@Mock
	private ModuleCrudService moduleCrudService;
	@Mock
	private DossiersCrudService dossiersCrudService;
	@Mock
	private DossierDetailsCrudService dossierDetailsCrudService;

	@InjectMocks
	private AnomaliesService anomaliesService;

	@BeforeEach
	void init() {
		anomaliesService = new AnomaliesService(dossiersService, moduleCrudService, dossiersCrudService, dossierDetailsCrudService);
	}

	@Test
	void test_ok_checkForModuleDateValidity() {
		ModuleDetailsDTO moduleDetails = ModuleDetailsDTO.builder()
				.dtValidityStart(DT_VALIDITY_START)
				.dtValidityEnd(DT_VALIDITY_END)
				.build();

		List<DossierAnomaly> expectedOutput = List.of(DossierAnomaly.builder()
				.code(MODULE_VALIDITY_EXPIRED_ERROR_CODE)
				.message(MODULE_VALIDITY_EXPIRED_ERROR_MSG)
				.build());

		List<DossierAnomaly> result = anomaliesService.checkForModuleDateValidity(moduleDetails);

		assertEquals(expectedOutput, result);
	}

	@Test
	void test_ok_checkForModuleDateValidity_empty() {
		ModuleDetailsDTO moduleDetails = ModuleDetailsDTO.builder()
				.dtValidityStart(DT_VALIDITY_START_EMPTY)
				.dtValidityEnd(DT_VALIDITY_END)
				.build();

		List<DossierAnomaly> result = anomaliesService.checkForModuleDateValidity(moduleDetails);

		assertEquals(List.of(), result);
	}

	@Test
	void test_ok_checkForMultipleDossier_no_anomalies() {
		when(moduleCrudService.findByCode(TENANT_ID_1, MODULE_CODE_1)).thenReturn(Optional.of(moduleDTOOut));
		when(dossiersCrudService.findAllByModuleIdAndPartyIdAndReferredYear(TENANT_ID_1, MODULE_ID_1, PARTY_ID, REFERRED_YEAR)).thenReturn(
				List.of(dossierWithDetailsDTO));
		when(dossiersService.checkForMetadata(TENANT_ID_1, dossierWithDetailsDTO)).thenReturn(METADATA_with_multipleApps);
		assertEquals(Collections.emptyList(), anomaliesService.checkForMultipleDossier(TENANT_ID_1, MODULE_CODE_1, PARTY_ID, REFERRED_YEAR));
	}

	@Test
	void test_ok_checkForMultipleDossier_with_anomalies() {
		when(moduleCrudService.findByCode(TENANT_ID_1, MODULE_CODE_1)).thenReturn(Optional.of(moduleDTOOut));
		when(dossiersCrudService.findAllByModuleIdAndPartyIdAndReferredYear(TENANT_ID_1, MODULE_ID_1, PARTY_ID, REFERRED_YEAR)).thenReturn(
				List.of(dossierWithDetailsDTO));
		when(dossiersService.checkForMetadata(TENANT_ID_1, dossierWithDetailsDTO)).thenReturn(METADATA_without_multipleApps);
		assertEquals(List.of(DossierAnomaly.builder()
				.code(AnomaliesService.MULTIPLE_DOSSIERS_ERROR_CODE)
				.message(AnomaliesService.MULTIPLE_DOSSIERS_ERROR_MSG)
				.build()), anomaliesService.checkForMultipleDossier(TENANT_ID_1, MODULE_CODE_1, PARTY_ID, REFERRED_YEAR));
	}

	@Test
	void test_ko_checkForMultipleDossier_moduleNotFound() {
		when(moduleCrudService.findByCode(TENANT_ID_1, MODULE_CODE_1)).thenReturn(Optional.empty());
		assertThrows(ObjectNotFoundRuntimeException.class, () ->
				anomaliesService.checkForMultipleDossier(TENANT_ID_1, MODULE_CODE_1, PARTY_ID, REFERRED_YEAR));
	}

	@Test
	void checkForAmendmentModule_withAnomalies_ok() {
		DossierAnomaly expectedOutput = DossierAnomaly.builder()
				.code(NOT_AMENDMENT_MODULE_ERROR_CODE)
				.message(NOT_AMENDMENT_MODULE_ERROR_MSG)
				.build();

		List<DossierAnomaly> result = anomaliesService.checkForAmendmentModule(notAmendModule);

		assertEquals(List.of(expectedOutput), result);
	}

	@Test
	void checkForAmendmentModule_withoutAnomalies_ok() {
		List<DossierAnomaly> result = anomaliesService.checkForAmendmentModule(amendModule);

		assertEquals(List.of(), result);
	}

	@Test
	void checkForDossierNotAmended_ok() {
		try {
			DossierAnomaly expectedOutput = DossierAnomaly.builder()
					.code(ALREADY_AMENDED_DOSSIER_ERROR_CODE)
					.message(ALREADY_AMENDED_DOSSIER_ERROR_MSG)
					.build();

			when(dossierDetailsCrudService.findDossierDetailById(TENANT_ID_1, DOSSIER_ID_1))
					.thenReturn(dossierDetails);
			when(dossierDetailsCrudService.findDossierDetailById(TENANT_ID_1, AMENDED_BY_ID))
					.thenReturn(dossierDetails);

			List<DossierAnomaly> result = anomaliesService.checkForDossierNotAmended(TENANT_ID_1, DOSSIER_ID_1);

			assertEquals(List.of(expectedOutput), result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkForDossierNotAmended_withoutAmendedById_ok() {
		try {
			when(dossierDetailsCrudService.findDossierDetailById(TENANT_ID_1, DOSSIER_ID_1))
					.thenReturn(dossierDetailsWithoutAmendedById);

			List<DossierAnomaly> result = anomaliesService.checkForDossierNotAmended(TENANT_ID_1, DOSSIER_ID_1);

			assertEquals(List.of(), result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkForDossierNotAmended_deletedDossier_ok() {
		try {
			when(dossierDetailsCrudService.findDossierDetailById(TENANT_ID_1, DOSSIER_ID_1))
					.thenReturn(dossierDetails);
			when(dossierDetailsCrudService.findDossierDetailById(TENANT_ID_1, AMENDED_BY_ID))
					.thenReturn(deletedDossierDetails);

			List<DossierAnomaly> result = anomaliesService.checkForDossierNotAmended(TENANT_ID_1, DOSSIER_ID_1);

			assertEquals(List.of(), result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkForDossierNotAmended_ko() {
		try {
			when(dossierDetailsCrudService.findDossierDetailById(TENANT_ID_1, DOSSIER_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(DossierNotFoundRuntimeException.class, () ->
					anomaliesService.checkForDossierNotAmended(TENANT_ID_1, DOSSIER_ID_1));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkForDossierWaived_ok() {
		try {
			DossierAnomaly expectedOutput = DossierAnomaly.builder()
					.code(WAIVED_DOSSIER_ERROR_CODE)
					.message(WAIVED_DOSSIER_ERROR_MSG)
					.build();

			when(dossierDetailsCrudService.findDossierDetailById(TENANT_ID_1, DOSSIER_ID_1))
					.thenReturn(dossierDetailsWaived);

			List<DossierAnomaly> result = anomaliesService.checkForDossierWaived(TENANT_ID_1, DOSSIER_ID_1);

			assertEquals(List.of(expectedOutput), result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkForDossierWaived_notWaived_ok() {
		try {
			when(dossierDetailsCrudService.findDossierDetailById(TENANT_ID_1, DOSSIER_ID_1))
					.thenReturn(dossierDetails);

			List<DossierAnomaly> result = anomaliesService.checkForDossierWaived(TENANT_ID_1, DOSSIER_ID_1);

			assertEquals(List.of(), result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void checkForDossierWaived_ko() {
		try {
			when(dossierDetailsCrudService.findDossierDetailById(TENANT_ID_1, DOSSIER_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(DossierNotFoundRuntimeException.class, () ->
					anomaliesService.checkForDossierWaived(TENANT_ID_1, DOSSIER_ID_1));
		} catch (Exception e) {
			fail(e);
		}
	}
}
