package com.abacogroup.agri.dossiers.core.model;

import com.abacogroup.agri.dossiers.core.mappers.DossierGeneratedPrintMapper;
import com.abacogroup.agri.dossiers.db.dao.DossierGeneratedPrintDAO;

// This concrete class is only used for the ObjectNotFoundException test case for delete method.
// Overriding the hasPrimaryKey() setting to false was the only way to test the catch of ObjectNotFoundException
public class TestImplAbstractCrudServiceWithHasPrimaryKeyFalse extends TestImplAbstractCrudService {

    public TestImplAbstractCrudServiceWithHasPrimaryKeyFalse(DossierGeneratedPrintDAO dao, DossierGeneratedPrintMapper mapper) {
        super(dao, mapper);
    }

    @Override
    protected boolean hasPrimaryKey() {
        return false;
    }

}
