package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.DossierCompileStatusMapper;
import com.abacogroup.agri.dossiers.db.dao.DossierCompileStatusDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierCompileStatusNTT;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusDTO;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DossierCompileStatusCrudServiceTest  {

	private static final Long DOSSIER_ID_1 = 48L;
	private static final String DOSSIER_CODE_1 = "48";
	private static final String COMPILE_STATUS_IDENTIFIER_1 = "60L";
	private static final String STATUS_1 = "compiling";
	private static final Long APP_COMPILE_STATUS_PKID_1 = 24L;
	private static final LocalDateTime DT_INSERT = LocalDateTime.now();
	private static final LocalDateTime DT_DELETE = LocalDateTime.ofInstant(Instant.ofEpochSecond(253402300799L), ZoneOffset.UTC);

	private static final String USERNAME_ID_1 = "user1";

	private static final ApplicationCompileStatusDTO dossierCompileStatusInDtoMock = ApplicationCompileStatusDTO.builder()
			.applicationId(DOSSIER_ID_1)
			.compileStatusIdentifier(COMPILE_STATUS_IDENTIFIER_1)
			.status(STATUS_1)
			.build();
	private static final ApplicationCompileStatusDTO dossierCompileStatusDtoMock = ApplicationCompileStatusDTO.builder()
			.pkid(APP_COMPILE_STATUS_PKID_1)
			.applicationId(DOSSIER_ID_1)
			.compileStatusIdentifier(COMPILE_STATUS_IDENTIFIER_1)
			.status(STATUS_1)
			.build();
	private static final DossierCompileStatusNTT dossierCompileStatusNttMock = DossierCompileStatusNTT.builder()
			.pkid(APP_COMPILE_STATUS_PKID_1)
			.dossier_id(DOSSIER_ID_1)
			.compile_status_identifier(COMPILE_STATUS_IDENTIFIER_1)
			.status(STATUS_1)
			.dt_insert(DT_INSERT)
			.dt_delete(DT_DELETE)
			.user_id_insert(USERNAME_ID_1)
			.build();
	private static final DossierCompileStatusNTT dossierCompileStatusNttDeletedMock = DossierCompileStatusNTT.builder()
			.pkid(APP_COMPILE_STATUS_PKID_1)
			.dossier_id(DOSSIER_ID_1)
			.compile_status_identifier(COMPILE_STATUS_IDENTIFIER_1)
			.status(STATUS_1)
			.dt_insert(DT_INSERT)
			.dt_delete(DT_INSERT)
			.user_id_insert(USERNAME_ID_1)
			.user_id_delete(USERNAME_ID_1)
			.build();
	private static final String TENANT_ID_1 = "tenant1";

	@Mock
	private DossierCompileStatusDAO dao;
	@Spy
	private DossierCompileStatusMapper dossierCompileStatusMapper = DossierCompileStatusMapper.INSTANCE;
	@InjectMocks
	private DossierCompileStatusCrudService dossierCompileStatusCrudService;

	@Test
	void test_hasPrimaryKey() {
		assertTrue(dossierCompileStatusCrudService.hasPrimaryKey());
	}

	@Test
	void test_findRsByCustomKey() {
		assertEquals(Optional.empty(), dossierCompileStatusCrudService.findRsByCustomKey(null));
	}

	@Test
	void test_retrieveCustomKeyByResultSet() {
		assertNull(dossierCompileStatusCrudService.retrieveCustomKeyByResultSet(null));
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_insert() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.nextSequenceVal()).thenReturn(DOSSIER_ID_1);
			when(dao.findById(DOSSIER_ID_1)).thenReturn(List.of(dossierCompileStatusNttMock));

			dossierCompileStatusCrudService.insert(dossierCompileStatusInDtoMock, USERNAME_ID_1);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			ApplicationCompileStatusDTO result = (ApplicationCompileStatusDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(dossierCompileStatusDtoMock, result);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_update() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(dao.nextSequenceVal()).thenReturn(APP_COMPILE_STATUS_PKID_1);
			when(dao.getCurrentTimestamp()).thenReturn(LocalDateTime.now());
			when(dao.findById(APP_COMPILE_STATUS_PKID_1)).thenReturn(List.of(dossierCompileStatusNttMock));
			when(dossierCompileStatusMapper.dtoToEntity(dossierCompileStatusInDtoMock)).thenReturn(dossierCompileStatusNttMock);
			when(dossierCompileStatusMapper.entityToDto(dossierCompileStatusNttMock)).thenReturn(dossierCompileStatusDtoMock);
			dossierCompileStatusCrudService.update(APP_COMPILE_STATUS_PKID_1, dossierCompileStatusInDtoMock, USERNAME_ID_1);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().inTransaction(dao);
			verify(dao, times(2)).inTransaction(handleConsumerLambdaCaptor.capture());

			ApplicationCompileStatusDTO result = (ApplicationCompileStatusDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(dossierCompileStatusDtoMock, result);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_delete() {
		try {
			dossierCompileStatusCrudService.delete(APP_COMPILE_STATUS_PKID_1, USERNAME_ID_1);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findById() throws ObjectNotFoundException {
		when(dao.findById(APP_COMPILE_STATUS_PKID_1)).thenReturn(List.of(dossierCompileStatusNttMock));
		assertEquals(dossierCompileStatusDtoMock, dossierCompileStatusCrudService.findById(APP_COMPILE_STATUS_PKID_1));
	}

	@Test
	void test_find() {
		when(dao.findByDossierId(TENANT_ID_1, APP_COMPILE_STATUS_PKID_1)).thenReturn(List.of(dossierCompileStatusNttMock));

		assertEquals(List.of(dossierCompileStatusDtoMock), dossierCompileStatusCrudService.find(TENANT_ID_1, APP_COMPILE_STATUS_PKID_1));

		MDC.remove(MDCPreFilter.LOCALE);
	}

	@Test
	void test_find_infiniteList_withDossierCode() {
		when(dao.infinite(any(), any(), anyInt()))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(dossierCompileStatusNttMock), null));

		List<ApplicationCompileStatusDTO> result =
				dossierCompileStatusCrudService.find(TENANT_ID_1, DOSSIER_CODE_1, null).getRecords();

		assertEquals(List.of(dossierCompileStatusDtoMock), result);

	}

	@Test
	void test_find_infiniteList_withDossierId() {
		when(dao.infinite(any(), any(), anyInt()))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(dossierCompileStatusNttMock), null));

		List<ApplicationCompileStatusDTO> result =
				dossierCompileStatusCrudService.find(TENANT_ID_1, DOSSIER_ID_1, null).getRecords();

		assertEquals(List.of(dossierCompileStatusDtoMock), result);

	}

	@Test
	void test_findById_withTenant() {
		try {
			when(dao.findById(APP_COMPILE_STATUS_PKID_1))
					.thenReturn(List.of(dossierCompileStatusNttMock));

			ApplicationCompileStatusDTO result =
					dossierCompileStatusCrudService.findById(TENANT_ID_1, APP_COMPILE_STATUS_PKID_1);

			assertEquals(dossierCompileStatusDtoMock, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findByCompileStatusIdentifier() {
		try {
			when(dao.findByDossierIdAndCompileStatus(TENANT_ID_1, DOSSIER_ID_1, COMPILE_STATUS_IDENTIFIER_1))
					.thenReturn(List.of(dossierCompileStatusNttMock));
			when(dossierCompileStatusMapper.entityToDto(dossierCompileStatusNttMock))
					.thenReturn(dossierCompileStatusDtoMock);

			ApplicationCompileStatusDTO result =
					dossierCompileStatusCrudService.findByCompileStatusIdentifier(TENANT_ID_1, DOSSIER_ID_1, COMPILE_STATUS_IDENTIFIER_1);

			assertEquals(dossierCompileStatusDtoMock, result);
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_findByTenantAndPrimaryKey() {
		try {
			when(dao.findByTenantAndId(TENANT_ID_1, APP_COMPILE_STATUS_PKID_1))
					.thenReturn(List.of(dossierCompileStatusNttMock));
			when(dossierCompileStatusMapper.entityToDto(dossierCompileStatusNttMock))
					.thenReturn(dossierCompileStatusDtoMock);

			ApplicationCompileStatusDTO result =
					dossierCompileStatusCrudService.findByTenantAndPrimaryKey(TENANT_ID_1, APP_COMPILE_STATUS_PKID_1);

			assertEquals(dossierCompileStatusDtoMock, result);
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_findByCompileStatusIdentifier_ko() {
		try {
			when(dao.findByDossierIdAndCompileStatus(TENANT_ID_1, DOSSIER_ID_1, COMPILE_STATUS_IDENTIFIER_1))
					.thenReturn(List.of(dossierCompileStatusNttDeletedMock));

			assertThrows(ObjectNotFoundException.class, () ->
					dossierCompileStatusCrudService.findByCompileStatusIdentifier(TENANT_ID_1, DOSSIER_ID_1, COMPILE_STATUS_IDENTIFIER_1));
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_findByTenantAndPrimaryKey_ko() {
		try {
			when(dao.findByTenantAndId(TENANT_ID_1, APP_COMPILE_STATUS_PKID_1))
					.thenReturn(List.of(dossierCompileStatusNttDeletedMock));

			assertThrows(ObjectNotFoundException.class, () ->
					dossierCompileStatusCrudService.findByTenantAndPrimaryKey(TENANT_ID_1, APP_COMPILE_STATUS_PKID_1));
		} catch (Exception e) {
			fail(e);
		}

	}

}
