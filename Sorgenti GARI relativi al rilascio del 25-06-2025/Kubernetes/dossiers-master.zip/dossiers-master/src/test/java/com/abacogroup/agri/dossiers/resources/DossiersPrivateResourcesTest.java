package com.abacogroup.agri.dossiers.resources;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.security.Principal;
import java.util.List;

import com.abacogroup.agri.dossiers.core.services.DossiersService;
import jakarta.ws.rs.core.SecurityContext;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abacogroup.agri.dossiers.core.model.dto.publics.DossiersSummaryByYearOutDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.CreateDossierInDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.CreateDossierOutDTO;
import com.abacogroup.dropwizard.auth.sso2.User;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(MockitoExtension.class)
class DossiersPrivateResourcesTest {

	@Mock
	private DossiersService dossiersService;
	@InjectMocks
	private DossiersPrivateResources dossiersPrivateResources;

	private static final String TENANT_1 = "tenant1";
	private static final Long PARTY_ID_1 = 12L;
	private static final String USERNAME = "username";
	private static final User logged_user1 = new User(USERNAME);
	private final SecurityContext sc = mock(SecurityContext.class);

	{
		Principal p = mock(Principal.class);
		when(sc.getUserPrincipal()).thenReturn(p);
		when(p.getName()).thenReturn(USERNAME);
	}

	@Test
	void getDossiersSummary_ok() {
		DossiersSummaryByYearOutDTO results = DossiersSummaryByYearOutDTO.builder()
				.partyId(PARTY_ID_1)
				.dossiersSummaryByYear(List.of())
				.build();
		when(dossiersService.getDossiersSummaryByYear(any(), any(), any())).thenReturn(results);

		assertEquals(results, dossiersPrivateResources.getDossiersSummary(TENANT_1, PARTY_ID_1, new User(USERNAME, TENANT_1), sc));
	}

	@Test
	void createDossier_ok() {
		CreateDossierInDTO createDossierInDTO = CreateDossierInDTO.builder()
				.partyId(PARTY_ID_1)
				.moduleCode("0001")
				.build();

		CreateDossierOutDTO createDossierOutDTO = CreateDossierOutDTO.builder()
				.dossierCode("2000")
				.build();

		when(dossiersService.createDossierAsync(TENANT_1, logged_user1, createDossierInDTO)).thenReturn(createDossierOutDTO);

		assertEquals(createDossierOutDTO,
				dossiersPrivateResources.createDossierAsync(TENANT_1, new User(USERNAME, TENANT_1), createDossierInDTO, sc));
	}
}
