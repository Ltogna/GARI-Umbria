package com.abacogroup.agri.dossiers.core.model;

import com.abacogroup.agri.dossiers.core.mappers.DossierGeneratedPrintMapper;
import com.abacogroup.agri.dossiers.core.model.dto.DossierGeneratedPrintDTO;
import com.abacogroup.agri.dossiers.core.services.crud.AbstractCrudService;
import com.abacogroup.agri.dossiers.db.dao.DossierGeneratedPrintDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierGeneratedPrintNTT;

import java.util.Optional;

public class TestImplAbstractCrudService extends AbstractCrudService<DossierGeneratedPrintNTT, Long, DossierGeneratedPrintDTO, DossierGeneratedPrintMapper, Void> {

    public TestImplAbstractCrudService(DossierGeneratedPrintDAO dao, DossierGeneratedPrintMapper mapper) {
        super(dao, mapper);
    }

    @Override
    protected boolean hasPrimaryKey() {
        return true;
    }

    @Override
    protected Optional<DossierGeneratedPrintNTT> findRsByCustomKey(Void customKey) {
        return Optional.empty();
    }

    @Override
    protected void deleteByCustomKey(Void customKey) {

    }

    @Override
    protected void setCustomSearchKey(DossierGeneratedPrintNTT rs, Void customKey) {

    }
}
