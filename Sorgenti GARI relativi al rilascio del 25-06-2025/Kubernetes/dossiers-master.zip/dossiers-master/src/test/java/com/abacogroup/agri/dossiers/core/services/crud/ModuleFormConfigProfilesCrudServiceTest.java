package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.ModuleFormConfigProfileMapper;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleFormConfigProfileDTO;
import com.abacogroup.agri.dossiers.db.dao.ModuleFormConfigProfileDAO;
import com.abacogroup.agri.dossiers.db.ntt.ModuleFormConfigProfileNTT;
import com.abacogroup.agri.dossiers.db.ntt.compoundkeys.FormConfigProfileKey;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ModuleFormConfigProfilesCrudServiceTest  {

	private static final String TENANT_ID_1 = "tenant_1";
	private static final Long FORM_CONFIG_ID_1 = 1L;
	private static final String REQUIRED_PROFILE_CODE = "DEFAULT_PROFILE_CODE";

	private final FormConfigProfileKey formConfigProfileKey = FormConfigProfileKey.builder()
			.module_form_config_id(FORM_CONFIG_ID_1)
			.required_profile_code(REQUIRED_PROFILE_CODE)
			.build();
	private final ModuleFormConfigProfileNTT moduleFormConfigProfileNTT = ModuleFormConfigProfileNTT.builder()
			.module_form_config_id(FORM_CONFIG_ID_1)
			.required_profile_code(REQUIRED_PROFILE_CODE)
			.build();
	private final ModuleFormConfigProfileDTO moduleFormConfigProfileDTO = ModuleFormConfigProfileDTO.builder()
			.moduleFormConfigId(FORM_CONFIG_ID_1)
			.requiredProfileCode(REQUIRED_PROFILE_CODE)
			.build();

	@Mock
	private ModuleFormConfigProfileDAO dao;
	@Mock
	private ModuleFormConfigProfileMapper formGroupMapper;

	@InjectMocks
	private ModuleFormConfigProfilesCrudService moduleFormConfigProfilesCrudService;


	@Test
	void test_hasPrimaryKey() {
		assertFalse(moduleFormConfigProfilesCrudService.hasPrimaryKey());
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_insert() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.findById(FORM_CONFIG_ID_1, REQUIRED_PROFILE_CODE))
					.thenReturn(List.of(moduleFormConfigProfileNTT));
			when(formGroupMapper.dtoToEntity(moduleFormConfigProfileDTO))
					.thenReturn(moduleFormConfigProfileNTT);
			when(formGroupMapper.entityToDto(moduleFormConfigProfileNTT))
					.thenReturn(moduleFormConfigProfileDTO);

			moduleFormConfigProfilesCrudService.insert(moduleFormConfigProfileDTO);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			ModuleFormConfigProfileDTO result = (ModuleFormConfigProfileDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(moduleFormConfigProfileDTO, result);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_update() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.findById(FORM_CONFIG_ID_1, REQUIRED_PROFILE_CODE))
					.thenReturn(List.of(moduleFormConfigProfileNTT));
			when(formGroupMapper.dtoToEntity(moduleFormConfigProfileDTO))
					.thenReturn(moduleFormConfigProfileNTT);
			when(formGroupMapper.entityToDto(moduleFormConfigProfileNTT))
					.thenReturn(moduleFormConfigProfileDTO);

			moduleFormConfigProfilesCrudService.update(moduleFormConfigProfileDTO);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			ModuleFormConfigProfileDTO result = (ModuleFormConfigProfileDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(moduleFormConfigProfileDTO, result);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_delete() throws Exception {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			moduleFormConfigProfilesCrudService.delete(formConfigProfileKey);

			verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useTransaction(dao);

			verify(dao, times(1)).deleteById(formConfigProfileKey.getModule_form_config_id(), formConfigProfileKey.getRequired_profile_code());
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findById() throws ObjectNotFoundException {
		try {
			when(dao.findById(TENANT_ID_1, FORM_CONFIG_ID_1, REQUIRED_PROFILE_CODE))
					.thenReturn(List.of(moduleFormConfigProfileNTT));
			when(formGroupMapper.entityToDto(moduleFormConfigProfileNTT))
					.thenReturn(moduleFormConfigProfileDTO);

			assertEquals(moduleFormConfigProfileDTO, moduleFormConfigProfilesCrudService.findById(TENANT_ID_1, formConfigProfileKey));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findAllById() {
		try {
			when(dao.find(TENANT_ID_1, FORM_CONFIG_ID_1))
					.thenReturn(List.of(moduleFormConfigProfileNTT));
			when(formGroupMapper.entityToDto(moduleFormConfigProfileNTT))
					.thenReturn(moduleFormConfigProfileDTO);

			assertEquals(List.of(moduleFormConfigProfileDTO), moduleFormConfigProfilesCrudService.find(TENANT_ID_1, FORM_CONFIG_ID_1));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_deleteByModuleFormConfigId() {
		try {
			moduleFormConfigProfilesCrudService.deleteByModuleFormConfigId(FORM_CONFIG_ID_1);

			verify(dao).deleteByModuleFormConfigId(FORM_CONFIG_ID_1);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

}
