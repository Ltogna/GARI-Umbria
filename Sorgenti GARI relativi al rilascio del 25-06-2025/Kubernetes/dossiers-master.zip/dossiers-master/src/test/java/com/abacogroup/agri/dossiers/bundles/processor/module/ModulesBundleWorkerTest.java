package com.abacogroup.agri.dossiers.bundles.processor.module;

import com.abacogroup.agri.dossiers.bundles.BundleConstants;
import com.abacogroup.agri.dossiers.bundles.model.I18nPair;
import com.abacogroup.agri.dossiers.bundles.model.form.*;
import com.abacogroup.agri.dossiers.bundles.model.module.BundleModuleInDTO;
import com.abacogroup.agri.dossiers.bundles.model.module.BundleModulesMessage;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import com.abacogroup.agri.dossiers.core.model.dto.*;
import com.abacogroup.agri.dossiers.core.services.FormConfigService;
import com.abacogroup.agri.dossiers.core.services.crud.*;
import com.abacogroup.agri.dossiers.db.ntt.dossiers.RsI18N;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ModulesBundleWorkerTest {

	private static final String TEMPLATE_TENANT_ID = "*";
	private static final Long MODULE_ID = 1L;
	private static final String MODULE_CODE = "module_code";
	private static final Long SECTOR_ID = 1L;
	private static final String SECTOR_CODE = "sector_code";
	private static final Long FORM_ID = 1L;
	private static final String FORM_CODE = "form_code";
	private static final Long FORM_GROUP_ID = 1L;
	private static final String FORM_GROUP_CODE = "form_group_code";
	private static final String SOFTWARE_URL = "software-url";
	private static final String COMPILE_STATUS_IDENTIFIER = "CODE_1";

	private static final Long FORM_MODULE_CONFIG_ID = 1L;
	private static final String REQUIRED_PROFILE_CODE = "DEFAULT_PROFILE";
	private static final Integer ANNUALITY = 2022;
	private static final AbsoluteDate VALIDITY_START = new AbsoluteDate("20220101");
	private static final AbsoluteDate VALIDITY_END = new AbsoluteDate("20230101");
	private static final String WORKFLOW_CODE = "workflow_code";
	private static final Integer FL_READ_ONLY = 0;
	private static final Integer SORT_ORDER = 1;
	private static final String PROCESS_STATUS = "TODO";
	private static final String PARAM_KEY = "name";
	private static final String PARAM_VALUE = "John";
	private static final Map<String, String> FORM_MODULE_CONFIG_PARAMS = Map.of(PARAM_KEY, PARAM_VALUE);
	private static final String I18N_FIELD_NAME = "description";
	private static final String I18N_LANG = "lang";
	private static final String I18N_TEXT = "text";

	private final ModuleWithDetailDTO modulesOutDTOMock = ModuleWithDetailDTO.builder()
			.moduleId(MODULE_ID)
			.sectorId(SECTOR_ID)
			.moduleCode(MODULE_CODE)
			.annuality(ANNUALITY)
			.dtValidityStart(new AbsoluteDate("20220101"))
			.dtValidityEnd(new AbsoluteDate("20230101"))
			.workflowCode(WORKFLOW_CODE)
			.build();

	private final ModuleDTO moduleDTOInMock = ModuleDTO.builder()
			.sectorId(SECTOR_ID)
			.moduleCode(MODULE_CODE)
			.workflowCode(WORKFLOW_CODE)
			.flAmendModule(false)
			.build();

	private final ModuleDTO moduleDTOOutMock = ModuleDTO.builder()
			.moduleId(MODULE_ID)
			.sectorId(SECTOR_ID)
			.moduleCode(MODULE_CODE)
			.workflowCode(WORKFLOW_CODE)
			.build();

	private final ConfigDataMessage configDataMessage = new ConfigDataMessage();
	private final RsI18N rsI18NMock = RsI18N.builder()
			.tenant_id(TEMPLATE_TENANT_ID)
			.i18n_text(I18N_TEXT)
			.i18n_value("value")
			.field_name(I18N_FIELD_NAME)
			.table_name("table_name")
			.lang(I18N_LANG)
			.build();

	private final I18nPair moduleI18nMock = I18nPair.builder()
			.description(I18N_TEXT)
			.lang(I18N_LANG)
			.build();

	private final I18nPair formCatalogI18nMock = I18nPair.builder()
			.description(I18N_TEXT)
			.lang(I18N_LANG)
			.build();

	private final I18nPair formGroupI18nMock = I18nPair.builder()
			.description(I18N_TEXT)
			.lang(I18N_LANG)
			.build();

	private final I18nPair moduleProfileI18nMock = I18nPair.builder()
			.description(I18N_TEXT)
			.lang(I18N_LANG)
			.build();

	private final SectorDTO sectorDTOMock = SectorDTO.builder()
			.tenantId(TEMPLATE_TENANT_ID)
			.sectorId(SECTOR_ID)
			.sectorCode(SECTOR_CODE)
			.build();

	private final FormCatalogDTO formCatalogInDTOMock = FormCatalogDTO.builder()
			.tenantId(TEMPLATE_TENANT_ID)
			.formCode(FORM_CODE)
			.softwareUrl(SOFTWARE_URL)
			.build();

	private final FormCatalogDTO formCatalogOutDTOMock = FormCatalogDTO.builder()
			.id(FORM_ID)
			.tenantId(TEMPLATE_TENANT_ID)
			.formCode(FORM_CODE)
			.softwareUrl(SOFTWARE_URL)
			.build();

	private final FormGroupDTO formGroupDTOMock = FormGroupDTO.builder()
			.tenantId(TEMPLATE_TENANT_ID)
			.formGroupCode(FORM_GROUP_CODE)
			.build();

	private final ModuleFormConfigsDTO moduleFormConfigsDTOMock = ModuleFormConfigsDTO.builder()
			.id(FORM_MODULE_CONFIG_ID)
			.moduleId(MODULE_ID)
			.formId(FORM_ID)
			.formGroupId(FORM_GROUP_ID)
			.compileStatusIdentifier(COMPILE_STATUS_IDENTIFIER)
			.flReadOnly(FL_READ_ONLY)
			.sortOrder(SORT_ORDER)
			.processStatus(PROCESS_STATUS)
			.build();

	private final ModuleFormConfigProfileDTO moduleFormConfigProfileDTOMock = ModuleFormConfigProfileDTO.builder()
			.moduleFormConfigId(FORM_MODULE_CONFIG_ID)
			.requiredProfileCode(REQUIRED_PROFILE_CODE)
			.build();

	private final ModuleFormConfigParamDTO moduleFormConfigParamDTOMock = ModuleFormConfigParamDTO.builder()
			.moduleFormConfigId(FORM_MODULE_CONFIG_ID)
			.parameterName(PARAM_KEY)
			.parameterValue(PARAM_VALUE)
			.build();

	private final BundleFormCatalogInDTO bundleFormCatalogInDTOMock = BundleFormCatalogInDTO.builder()
			.formCode(FORM_CODE)
			.softwareUrl(SOFTWARE_URL)
			.i18n(List.of(formCatalogI18nMock))
			.build();

	private final BundleModuleProfileInDTO bundleModuleProfileInDTOMock = BundleModuleProfileInDTO.builder()
			.prfCode(REQUIRED_PROFILE_CODE)
			.i18n(List.of(moduleProfileI18nMock))
			.build();

	private final BundleModuleFormConfigsInDTO bundleModuleFormConfigsInDTOMock = BundleModuleFormConfigsInDTO.builder()
			.moduleCode(MODULE_CODE)
			.formCode(FORM_CODE)
			.formGroupCode(FORM_GROUP_CODE)
			.flReadOnly(FL_READ_ONLY)
			.sortOrder(SORT_ORDER)
			.processStatus(PROCESS_STATUS)
			.compileStatusIdentifier(COMPILE_STATUS_IDENTIFIER)
			.params(FORM_MODULE_CONFIG_PARAMS)
			.requiredProfiles(List.of(REQUIRED_PROFILE_CODE))
			.build();

	private final BundleFormGroupInDTO bundleFormGroupInDTOMock = BundleFormGroupInDTO.builder()
			.formGroupCode(FORM_GROUP_CODE)
			.formGroupChildren(Collections.emptyList())
			.i18n(List.of(formGroupI18nMock))
			.build();

	private final BundleFormsInDTO bundleFormsInDTOMock = BundleFormsInDTO.builder()
			.formCatalogs(List.of(bundleFormCatalogInDTOMock))
			.formGroups(List.of(bundleFormGroupInDTOMock))
			.moduleFormConfigs(List.of(bundleModuleFormConfigsInDTOMock))
			.build();

	private final BundleModuleInDTO bundleModuleInDTOMock = BundleModuleInDTO.builder()
			.moduleCode(MODULE_CODE)
			.sectorCode(SECTOR_CODE)
			.annuality(ANNUALITY)
			.dtValidityStart(VALIDITY_START)
			.dtValidityEnd(VALIDITY_END)
			.workflowCode(WORKFLOW_CODE)
			.forms(bundleFormsInDTOMock)
			.i18n(List.of(moduleI18nMock))
			.moduleProfiles(List.of(bundleModuleProfileInDTOMock))
			.build();

	private final BundleModulesMessage bundleModulesMessageMock = BundleModulesMessage.builder()
			.modules(List.of(bundleModuleInDTOMock))
			.build();

	private final ModuleDetailsDTO moduleDetailsInDTOMock = ModuleDetailsDTO.builder()
			.moduleId(MODULE_ID)
			.dtValidityStart(VALIDITY_START)
			.dtValidityEnd(VALIDITY_END)
			.annuality(ANNUALITY)
			.build();

	private final ModuleDetailsDTO moduleDetailsOutDTOMock = ModuleDetailsDTO.builder()
			.pkid(1L)
			.moduleId(MODULE_ID)
			.dtValidityStart(VALIDITY_START)
			.dtValidityEnd(VALIDITY_END)
			.annuality(ANNUALITY)
			.build();

	private final FormGroupDTO formGroupDTOInDTOMock = FormGroupDTO.builder()
			.tenantId(TEMPLATE_TENANT_ID)
			.formGroupCode(FORM_GROUP_CODE)
			.build();

	private final FormGroupDTO formGroupDTOOutDTOMock = FormGroupDTO.builder()
			.id(FORM_GROUP_ID)
			.formGroupCode(FORM_GROUP_CODE)
			.build();

	private final ModuleFormConfigsDTO moduleFormConfigsDTOInMock = ModuleFormConfigsDTO.builder()
			.moduleId(MODULE_ID)
			.formId(FORM_ID)
			.formGroupId(FORM_GROUP_ID)
			.processStatus(PROCESS_STATUS)
			.flReadOnly(FL_READ_ONLY)
			.sortOrder(SORT_ORDER)
			.compileStatusIdentifier(COMPILE_STATUS_IDENTIFIER)
			.build();

	private final ModuleFormConfigsDTO moduleFormConfigsDTOOutMock = ModuleFormConfigsDTO.builder()
			.id(FORM_MODULE_CONFIG_ID)
			.moduleId(MODULE_ID)
			.formId(FORM_ID)
			.formGroupId(FORM_GROUP_ID)
			.processStatus(PROCESS_STATUS)
			.flReadOnly(FL_READ_ONLY)
			.sortOrder(SORT_ORDER)
			.compileStatusIdentifier(COMPILE_STATUS_IDENTIFIER)
			.build();

	private final ModuleProfileDTO moduleProfileDTOInMock = ModuleProfileDTO.builder()
			.moduleId(MODULE_ID)
			.profileCode(REQUIRED_PROFILE_CODE)
			.build();

	private final ModuleProfileDTO moduleProfileDTOOutMock = ModuleProfileDTO.builder()
			.pkid(1L)
			.moduleId(MODULE_ID)
			.profileCode(REQUIRED_PROFILE_CODE)
			.build();

	@InjectMocks
	private ModulesBundleWorker modulesBundleWorker;
	@Mock
	private ModuleCrudService modulesCrudService;
	@Mock
	private SectorsCrudService sectorsCrudService;
	@Mock
	private ModuleDetailsCrudService moduleDetailsCrudService;
	@Mock
	private FormCatalogsCrudService formCatalogsCrudService;
	@Mock
	private FormGroupsCrudService formGroupsCrudService;
	@Mock
	private ModuleFormConfigsCrudService moduleFormConfigsCrudService;
	@Mock
	private ModuleFormConfigParamCrudService moduleFormConfigParamCrudService;
	@Mock
	private ModuleFormConfigProfilesCrudService moduleFormConfigProfilesCrudService;
	@Mock
	private ModuleProfilesCrudService moduleProfilesCrudService;

	@Mock
	private ModulePrintConfigsCrudService modulePrintConfigsCrudService;
	@Mock
	private ModulePrintConfigParamCrudService modulePrintConfigParamCrudService;
	@Mock
	private ModulePrintConfigProfilesCrudService modulePrintConfigProfilesCrudService;
	@Mock
	private FormConfigService formConfigService;

	@BeforeEach
	void init() {
		configDataMessage.setTenantId(TEMPLATE_TENANT_ID);
		modulesBundleWorker = new ModulesBundleWorker(modulesCrudService, moduleDetailsCrudService, sectorsCrudService, formCatalogsCrudService,
				formGroupsCrudService, moduleFormConfigsCrudService, moduleFormConfigParamCrudService, moduleFormConfigProfilesCrudService,
				modulePrintConfigsCrudService, modulePrintConfigParamCrudService, modulePrintConfigProfilesCrudService, moduleProfilesCrudService,
				formConfigService);
	}

	@Test
	void test_insertBundleModules_ok() {
		try {
			when(modulesCrudService.findByModuleCodeAndSectorCode(TEMPLATE_TENANT_ID, MODULE_CODE, SECTOR_CODE)).thenReturn(Optional.empty());
			when(modulesCrudService.insert(moduleDTOInMock, BundleConstants.BUNDLE_SYSTEM_USERNAME)).thenReturn(moduleDTOOutMock);
			when(sectorsCrudService.findSectorByCode(TEMPLATE_TENANT_ID, SECTOR_CODE)).thenReturn(sectorDTOMock);
			when(moduleDetailsCrudService.insert(moduleDetailsInDTOMock, BundleConstants.BUNDLE_SYSTEM_USERNAME)).thenReturn(moduleDetailsOutDTOMock);
			when(formGroupsCrudService.insert(formGroupDTOInDTOMock)).thenReturn(formGroupDTOOutDTOMock);
			when(formGroupsCrudService.findFormGroupByCode(TEMPLATE_TENANT_ID, FORM_GROUP_CODE)).thenReturn(formGroupDTOOutDTOMock);
			when(moduleFormConfigsCrudService.insert(moduleFormConfigsDTOInMock)).thenReturn(moduleFormConfigsDTOOutMock);
			when(formCatalogsCrudService.findByCodeNullable(TEMPLATE_TENANT_ID, FORM_CODE)).thenReturn(null);
			when(formCatalogsCrudService.findByCode(TEMPLATE_TENANT_ID, FORM_CODE)).thenReturn(formCatalogOutDTOMock);
			when(formCatalogsCrudService.insert(formCatalogInDTOMock)).thenReturn(formCatalogOutDTOMock);
			when(formGroupsCrudService.findFormGroupByCodeNullable(TEMPLATE_TENANT_ID, FORM_GROUP_CODE)).thenReturn(null);
			modulesBundleWorker.insertBundleModules(TEMPLATE_TENANT_ID, bundleModulesMessageMock);

			verify(modulesCrudService).insertModuleI18N(TEMPLATE_TENANT_ID, MODULE_CODE, I18N_LANG, I18N_TEXT);
			verify(formCatalogsCrudService).insert(formCatalogInDTOMock);
			verify(formCatalogsCrudService).insertFormCatalogI18N(TEMPLATE_TENANT_ID, FORM_CODE, I18N_LANG, I18N_TEXT);
			verify(formGroupsCrudService).insertFormGroupI18N(TEMPLATE_TENANT_ID, FORM_GROUP_CODE, I18N_LANG, I18N_TEXT);
			verify(moduleFormConfigParamCrudService).insert(moduleFormConfigParamDTOMock);
			verify(moduleProfilesCrudService).insert(moduleProfileDTOInMock, BundleConstants.BUNDLE_SYSTEM_USERNAME);
			verify(moduleFormConfigProfilesCrudService).insert(moduleFormConfigProfileDTOMock);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_insertBundleModules_ko_findSectorByCodeNotFound() {
		try {
			when(modulesCrudService.findByModuleCodeAndSectorCode(TEMPLATE_TENANT_ID, MODULE_CODE, SECTOR_CODE)).thenReturn(Optional.empty());
			when(sectorsCrudService.findSectorByCode(TEMPLATE_TENANT_ID, SECTOR_CODE)).thenThrow(new ObjectNotFoundException("err"));
			assertThrows(ObjectNotFoundRuntimeException.class, () -> modulesBundleWorker.insertBundleModules(TEMPLATE_TENANT_ID, bundleModulesMessageMock));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_insertBundleModules_ko_findFormCatalogByCodeNotFound() {
		try {
			when(modulesCrudService.findByModuleCodeAndSectorCode(TEMPLATE_TENANT_ID, MODULE_CODE, SECTOR_CODE)).thenReturn(Optional.empty());
			when(modulesCrudService.insert(moduleDTOInMock, BundleConstants.BUNDLE_SYSTEM_USERNAME)).thenReturn(moduleDTOOutMock);
			when(sectorsCrudService.findSectorByCode(TEMPLATE_TENANT_ID, SECTOR_CODE)).thenReturn(sectorDTOMock);
			when(moduleDetailsCrudService.insert(moduleDetailsInDTOMock, BundleConstants.BUNDLE_SYSTEM_USERNAME)).thenReturn(moduleDetailsOutDTOMock);
			when(formGroupsCrudService.insert(formGroupDTOInDTOMock)).thenReturn(formGroupDTOOutDTOMock);
			when(formCatalogsCrudService.findByCodeNullable(TEMPLATE_TENANT_ID, FORM_CODE)).thenReturn(null);
			when(formCatalogsCrudService.findByCode(TEMPLATE_TENANT_ID, FORM_CODE)).thenThrow(new ObjectNotFoundException("err"));
			when(formCatalogsCrudService.insert(formCatalogInDTOMock)).thenReturn(formCatalogOutDTOMock);
			when(formGroupsCrudService.findFormGroupByCodeNullable(TEMPLATE_TENANT_ID, FORM_GROUP_CODE)).thenReturn(null);
			assertThrows(ObjectNotFoundRuntimeException.class, () -> modulesBundleWorker.insertBundleModules(TEMPLATE_TENANT_ID, bundleModulesMessageMock));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_updateBundleModules_ok() {
		try {
			when(modulesCrudService.findByModuleCodeAndSectorCode(TEMPLATE_TENANT_ID, MODULE_CODE, SECTOR_CODE)).thenReturn(Optional.of(moduleDTOOutMock));
			when(formGroupsCrudService.findFormGroupByCode(TEMPLATE_TENANT_ID, FORM_GROUP_CODE)).thenReturn(formGroupDTOOutDTOMock);
			when(moduleFormConfigsCrudService.insert(moduleFormConfigsDTOInMock)).thenReturn(moduleFormConfigsDTOOutMock);
			when(formCatalogsCrudService.findByCodeNullable(TEMPLATE_TENANT_ID, FORM_CODE)).thenReturn(formCatalogOutDTOMock);
			when(formCatalogsCrudService.findByCode(TEMPLATE_TENANT_ID, FORM_CODE)).thenReturn(formCatalogOutDTOMock);
			when(formGroupsCrudService.findFormGroupByCodeNullable(TEMPLATE_TENANT_ID, FORM_GROUP_CODE)).thenReturn(formGroupDTOOutDTOMock);
			when(moduleProfilesCrudService.find(TEMPLATE_TENANT_ID, MODULE_ID, REQUIRED_PROFILE_CODE)).thenReturn(moduleProfileDTOOutMock);
			when(moduleDetailsCrudService.findByModuleId(TEMPLATE_TENANT_ID, MODULE_ID)).thenReturn(moduleDetailsOutDTOMock);
			modulesBundleWorker.insertBundleModules(TEMPLATE_TENANT_ID, bundleModulesMessageMock);

			verify(modulesCrudService).insertModuleI18N(TEMPLATE_TENANT_ID, MODULE_CODE, I18N_LANG, I18N_TEXT);
			verify(formCatalogsCrudService).insertFormCatalogI18N(TEMPLATE_TENANT_ID, FORM_CODE, I18N_LANG, I18N_TEXT);
			verify(formGroupsCrudService).insertFormGroupI18N(TEMPLATE_TENANT_ID, FORM_GROUP_CODE, I18N_LANG, I18N_TEXT);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_deleteBundleModules_ok() {
		try {
			when(modulesCrudService.findByModuleCodeAndSectorCode(TEMPLATE_TENANT_ID, MODULE_CODE, SECTOR_CODE)).thenReturn(Optional.of(moduleDTOOutMock));
			modulesBundleWorker.deleteBundleModules(TEMPLATE_TENANT_ID, bundleModulesMessageMock);

			verify(modulesCrudService).delete(MODULE_ID, BundleConstants.BUNDLE_SYSTEM_USERNAME);
			verify(moduleDetailsCrudService).deleteByModuleId(MODULE_ID, BundleConstants.BUNDLE_SYSTEM_USERNAME);
			verify(moduleProfilesCrudService).deleteByModuleId(MODULE_ID, BundleConstants.BUNDLE_SYSTEM_USERNAME);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_exposeModulesService() {
		assertEquals(modulesCrudService, modulesBundleWorker.exposeModuleCrudService());
	}

	@Test
	void test_exposeModuleFormConfigsCrudService() {
		assertEquals(moduleFormConfigsCrudService, modulesBundleWorker.exposeModuleFormConfigsCrudService());
	}

	@Test
	void test_sectorsCrudService() {
		assertEquals(sectorsCrudService, modulesBundleWorker.exposeSectorsCrudService());
	}

	@Test
	void test_exposeFormGroupsCrudService() {
		assertEquals(formGroupsCrudService, modulesBundleWorker.exposeFormGroupsCrudService());
	}

	@Test
	void test_exposeFormCatalogsCrudService() {
		assertEquals(formCatalogsCrudService, modulesBundleWorker.exposeFormCatalogsCrudService());
	}

	@Test
	void test_exposeModuleProfilesCrudService() {
		assertEquals(moduleProfilesCrudService, modulesBundleWorker.exposeModuleProfilesCrudService());
	}

	@Test
	void test_exposeModuleFormConfigParamCrudService() {
		assertEquals(moduleFormConfigParamCrudService, modulesBundleWorker.exposeModuleFormConfigParamCrudService());
	}

	@Test
	void test_exposeModuleFormConfigProfilesCrudService() {
		assertEquals(moduleFormConfigProfilesCrudService, modulesBundleWorker.exposeModuleFormConfigProfilesCrudService());
	}

}
