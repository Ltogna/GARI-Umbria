package com.abacogroup.agri.dossiers.bundles.processor.amendable;

import com.abacogroup.agri.dossiers.bundles.model.amendable.BundleAmendableModuleInDTO;
import com.abacogroup.agri.dossiers.bundles.model.amendable.BundleAmendableModulesMessage;
import com.abacogroup.agri.dossiers.core.model.dto.*;
import com.abacogroup.agri.dossiers.core.services.crud.*;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class AmendableModulesBundleWorkerTest {

	private static final String TEMPLATE_TENANT_ID = "*";
	private static final Long MODULE_ID = 1L;
	private static final Long AMENDABLE_MODULE_ID = 2L;
	private static final String MODULE_CODE = "module_code";
	private static final String USER = "user";
	private static final String AMENDABLE_MODULE_CODE = "AMENDABLE_MODULE_CODE";
	private static final Long SECTOR_ID = 1L;
	private static final Long SECTOR_ID_2 = 2L;

	private static final String WORKFLOW_CODE = "workflow_code";

	private final ModuleDTO moduleDTOInMock = ModuleDTO.builder()
			.moduleId(MODULE_ID)
			.sectorId(SECTOR_ID)
			.moduleCode(MODULE_CODE)
			.workflowCode(WORKFLOW_CODE)
			.flAmendModule(false)
			.build();

	private final ModuleDTO amendableModuleDTOInMock = ModuleDTO.builder()
			.moduleId(AMENDABLE_MODULE_ID)
			.sectorId(SECTOR_ID_2)
			.moduleCode(AMENDABLE_MODULE_CODE)
			.workflowCode(WORKFLOW_CODE)
			.flAmendModule(true)
			.build();

	private final AmendableModuleDTO amendableModuleDTO = AmendableModuleDTO.builder()
			.amendableModuleId(AMENDABLE_MODULE_ID)
			.moduleId(MODULE_ID)
			.userIdInsert(USER)
			.build();

	private final ConfigDataMessage configDataMessage = new ConfigDataMessage();

	private final BundleAmendableModuleInDTO bundleAmendableModuleInDTO = BundleAmendableModuleInDTO.builder()
			.amendableModuleCode(AMENDABLE_MODULE_CODE)
			.moduleCode(MODULE_CODE)
			.build();

	private final BundleAmendableModulesMessage bundleAmendableModulesMessage = BundleAmendableModulesMessage.builder()
			.amendableModules(List.of(bundleAmendableModuleInDTO))
			.build();

	@InjectMocks
	private AmendableModulesBundleWorker amendableModulesBundleWorker;
	@Mock
	private AmendableModuleCrudService amendableModuleCrudService;
	@Mock
	private ModuleCrudService moduleCrudService;
	@Mock
	private ModuleDetailsCrudService moduleDetailsCrudService;


	@BeforeEach
	void init() {
		configDataMessage.setTenantId(TEMPLATE_TENANT_ID);
		amendableModulesBundleWorker = new AmendableModulesBundleWorker(amendableModuleCrudService, moduleCrudService, moduleDetailsCrudService);
	}

	@Test
	void test_insertAmendableModuleFound_ok() {
		try {
			when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, MODULE_CODE)).thenReturn(Optional.of(moduleDTOInMock));

			when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, AMENDABLE_MODULE_CODE)).thenReturn(Optional.of(amendableModuleDTOInMock));

			when(amendableModuleCrudService.findByModuleIdAndAmendableModuleId(MODULE_ID, AMENDABLE_MODULE_ID)).thenReturn(amendableModuleDTO);

			amendableModulesBundleWorker.insertBundleModules(TEMPLATE_TENANT_ID, bundleAmendableModulesMessage);

			AmendableModuleDTO moduleDTO = AmendableModuleDTO.builder()
					.amendableModuleId(AMENDABLE_MODULE_ID)
					.moduleId(MODULE_ID)
					.build();

			verify(amendableModuleCrudService, times(1)).update(AMENDABLE_MODULE_ID, moduleDTO, USER);


		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

//	@Test
//	void test_insertAmendableModuleNotFound_ok() {
//		try {
//			when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, MODULE_CODE)).thenReturn(Optional.of(moduleDTOInMock));
//
//			when(moduleCrudService.findByCode(TEMPLATE_TENANT_ID, AMENDABLE_MODULE_CODE)).thenThrow(new ObjectNotFoundRuntimeException(MessageFormat.format("Module with code: {0} not found", AMENDABLE_MODULE_CODE)));
//
//			when(moduleDetailsCrudService.findByModuleCode(TEMPLATE_TENANT_ID, MODULE_CODE)).thenReturn(moduleDetailsInDTOMock);
//
//			amendableModulesBundleWorker.insertBundleModules(TEMPLATE_TENANT_ID, bundleAmendableModulesMessage);
//
//			AmendableModuleDTO moduleDTO = AmendableModuleDTO.builder()
//					.amendableModuleId(AMENDABLE_MODULE_ID)
//					.moduleId(MODULE_ID)
//					.build();
//
//			verify(amendableModuleCrudService, times(1)).insert(moduleDTO, BundleConstants.BUNDLE_SYSTEM_USERNAME);
//
//		} catch (Exception e) {
//			fail(e.getMessage(), e);
//		}
//	}


	@Test
	void test_exposeModulesService() {
		assertEquals(moduleCrudService, amendableModulesBundleWorker.exposeModuleCrudService());
	}

	@Test
	void test_exposeModuleDetailsCrudService() {
		assertEquals(moduleDetailsCrudService, amendableModulesBundleWorker.exposeModuleDetailsCrudService());
	}

	@Test
	void test_exposeAmendableModuleDetailsCrudService() {
		assertEquals(amendableModuleCrudService, amendableModulesBundleWorker.exposeAmendableModuleCrudService());
	}

}
