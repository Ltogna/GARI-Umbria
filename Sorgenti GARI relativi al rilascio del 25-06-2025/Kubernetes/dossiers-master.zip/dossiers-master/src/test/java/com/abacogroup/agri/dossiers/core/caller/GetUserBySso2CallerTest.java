package com.abacogroup.agri.dossiers.core.caller;

import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import static org.mockito.Mockito.verify;

@Slf4j
@ExtendWith(MockitoExtension.class)
class GetUserBySso2CallerTest {

	private static final String TENANT_ID_1 = "tenant_1";
	private static final String URL = "url";
	private static final String USERNAME = "username";
	private static final String TOKEN = "token";

	private final GetUserByTenant getUserByTenantMock = GetUserByTenant.of(TENANT_ID_1, USERNAME, URL, TOKEN);

	@Mock
	private GenericCallerService genericCallerService;
	@InjectMocks
	private GetUserBySso2Caller getUserBySso2Caller;

	@BeforeEach
	protected void init() {
		getUserBySso2Caller = new GetUserBySso2Caller(genericCallerService);
	}

	@Test
	void test_makeCall() {
		getUserBySso2Caller.makeCall(getUserByTenantMock);
		verify(genericCallerService).makeCall(Void.class, getUserByTenantMock.getUrl(), getUserByTenantMock.getHttpMethod(),
				getUserByTenantMock.getPathVariablesMap(),
				getUserByTenantMock.getQueryParamsMap(), getUserByTenantMock.getToken(), getUserByTenantMock.provideApiKey(),
				getUserByTenantMock.providePayload(),
				MDC.get(MDCPreFilter.LOCALE));
	}

}
