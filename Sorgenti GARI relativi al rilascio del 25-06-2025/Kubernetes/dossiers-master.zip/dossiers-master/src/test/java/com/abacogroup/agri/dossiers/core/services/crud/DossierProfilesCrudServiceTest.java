package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.DossierProfileMapper;
import com.abacogroup.agri.dossiers.core.model.dto.DossierProfileDTO;
import com.abacogroup.agri.dossiers.core.services.I18NService;
import com.abacogroup.agri.dossiers.db.dao.DossierProfileDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierProfileNTT;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static com.abacogroup.agri.dossiers.utils.PagingParamsFactory.DEFAULT_PAGE_SIZE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DossierProfilesCrudServiceTest  {

	private static final String TENANT_ID_1 = "tenant_1";
	private static final Long PK_ID_1 = 1L;
	private static final String USER_ID = "user1";
	private static final String PROFILE_CODE_1 = "code1";
	private static final Long DOSSIER_ID_1 = 1L;
	private static final String DOSSIER_CODE_1 = "1L";
	private static final String LANG_1 = "pl";
	private static final String PROFILE_DESCRIPTION_1 = "profile-desc-1";

	private static final DossierProfileDTO dossierProfileDTO = DossierProfileDTO.builder()
			.profileCode(PROFILE_CODE_1)
			.dossierId(DOSSIER_ID_1)
			.build();
	private static final DossierProfileDTO dossierProfileDTOResult = DossierProfileDTO.builder()
			.profileCode(PROFILE_CODE_1)
			.dossierId(DOSSIER_ID_1)
			.pkid(PK_ID_1)
			.build();
	private static final DossierProfileNTT dossierProfileNTT = DossierProfileNTT.builder()
			.profile_code(PROFILE_CODE_1)
			.pkid(PK_ID_1)
			.dossier_id(DOSSIER_ID_1)
			.build();

	@Mock
	private DossierProfileDAO dao;
	@Spy
	private DossierProfileMapper dossierProfileMapper = DossierProfileMapper.INSTANCE;
	@Mock
	private I18NService i18NService;
	@InjectMocks
	private DossierProfilesCrudService dossierProfilesCrudService;

	@Test
	void test_hasPrimaryKey() {
		assertTrue(dossierProfilesCrudService.hasPrimaryKey());
	}

	@Test
	void test_retrieveCustomKeyByResultSet() {
		assertNull(dossierProfilesCrudService.retrieveCustomKeyByResultSet(dossierProfileNTT));
	}

	@Test
	void test_findRsByCustomKey() {
		assertEquals(Optional.empty(), dossierProfilesCrudService.findRsByCustomKey(null));
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_insert() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.nextSequenceVal()).thenReturn(PK_ID_1);
			when(dao.findById(PK_ID_1)).thenReturn(List.of(dossierProfileNTT));

			dossierProfilesCrudService.insert(dossierProfileDTO, USER_ID);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			DossierProfileDTO result = (DossierProfileDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(dossierProfileDTOResult, result);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_update() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(dao.getCurrentTimestamp())
					.thenReturn(LocalDateTime.now());
			when(dao.inTransaction(handleConsumerLambdaCaptor.capture()))
					.thenReturn(dossierProfileDTO);

			dossierProfilesCrudService.update(PK_ID_1, dossierProfileDTO, USER_ID);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			DossierProfileDTO result = (DossierProfileDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(dossierProfileDTO, result);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findById() throws ObjectNotFoundException {
		when(dao.find(TENANT_ID_1, DOSSIER_CODE_1, null)).thenReturn(List.of(dossierProfileNTT));
		assertEquals(List.of(dossierProfileDTOResult), dossierProfilesCrudService.find(TENANT_ID_1, DOSSIER_CODE_1));
	}

	@Test
	void findByUnique_ok() {
		when(dao.findByUnique(TENANT_ID_1, DOSSIER_ID_1, PROFILE_CODE_1))
				.thenReturn(List.of(dossierProfileNTT));
		when(dossierProfileMapper.entityToDto(dossierProfileNTT))
				.thenReturn(dossierProfileDTO);

		Optional<DossierProfileDTO> result = dossierProfilesCrudService.findByUnique(TENANT_ID_1, DOSSIER_ID_1, PROFILE_CODE_1);

		assertEquals(Optional.of(dossierProfileDTO), result);
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_delete_ok() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			dossierProfilesCrudService.delete(PK_ID_1, USER_ID);

			verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useTransaction(dao);

			verify(dao, times(1))
					.logicallyDeleteById(eq(DOSSIER_ID_1), eq(USER_ID), any());
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_insertModuleI18N_ok() {
		dossierProfilesCrudService.insertModuleI18N(TENANT_ID_1, PROFILE_CODE_1, LANG_1, PROFILE_DESCRIPTION_1);

		verify(i18NService, times(1)).insertI18N(TENANT_ID_1, DossierProfilesCrudService.I18N_DOSSIER_PROFILES_TABLE,
				DossierProfilesCrudService.DOSSIER_PROFILES_I18N.DESCRIPTION.getCode(), LANG_1, PROFILE_CODE_1, PROFILE_DESCRIPTION_1);
	}

	@Test
	void test_findById_ok() {
		when(dao.findById(PK_ID_1)).thenReturn(List.of(dossierProfileNTT));
		when(dossierProfileMapper.entityToDto(dossierProfileNTT)).thenReturn(dossierProfileDTO);

		try {
			assertEquals(dossierProfileDTO, dossierProfilesCrudService.findById(PK_ID_1));
		} catch (ObjectNotFoundException e) {
			fail(e);
		}
	}

	@Test
	void test_findById_ko() {
		when(dao.findById(PK_ID_1)).thenReturn(List.of());

		assertThrows(ObjectNotFoundException.class, () -> dossierProfilesCrudService.findById(PK_ID_1));
	}

	@Test
	void test_bulkLogicallyDeleteByDossierCode_ok() {
		dossierProfilesCrudService.bulkLogicallyDeleteByDossierCode(TENANT_ID_1, DOSSIER_CODE_1, USER_ID);

		verify(dao, times(1)).bulkLogicallyDeleteByDossierCode(TENANT_ID_1, DOSSIER_CODE_1, USER_ID);
	}

	@Test
	void test_bulkLogicallyDeleteByDossierId_ok() {
		dossierProfilesCrudService.bulkLogicallyDeleteByDossierId(TENANT_ID_1, DOSSIER_ID_1, USER_ID);

		verify(dao, times(1))
				.bulkLogicallyDeleteByDossierId(TENANT_ID_1, DOSSIER_ID_1, USER_ID);
	}

	@Test
	void test_find_ok() {
		when(dao.find(TENANT_ID_1, DOSSIER_ID_1))
				.thenReturn(List.of(dossierProfileNTT));
		when(dossierProfileMapper.entityToDto(dossierProfileNTT))
				.thenReturn(dossierProfileDTO);

		List<DossierProfileDTO> result = dossierProfilesCrudService.find(TENANT_ID_1, DOSSIER_ID_1);

		assertEquals(List.of(dossierProfileDTO), result);
	}

	@Test
	void findAll_ok() {
		when(dao.find(TENANT_ID_1, DOSSIER_ID_1, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(dossierProfileNTT));
		when(dossierProfileMapper.entityToDto(dossierProfileNTT))
				.thenReturn(dossierProfileDTO);

		List<DossierProfileDTO> result = dossierProfilesCrudService.findAll(TENANT_ID_1, DOSSIER_ID_1, MDC.get(MDCPreFilter.LOCALE));

		assertEquals(List.of(dossierProfileDTO), result);
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_find_infiniteList_withDossierCode_ok() {
		InfiniteListResults<Object> infiniteListNttResults = new InfiniteListResultsImpl<>();
		((InfiniteListResultsImpl) infiniteListNttResults).setRecords(List.of(dossierProfileNTT));

		DossierProfileDTO expectedDossierProfileDTO = DossierProfileDTO.builder()
				.dossierId(DOSSIER_ID_1)
				.pkid(PK_ID_1)
				.profileCode(PROFILE_CODE_1)
				.build();

		InfiniteListResults<DossierProfileDTO> expectedInfiniteListResults = new InfiniteListResultsImpl<>();
		((InfiniteListResultsImpl) expectedInfiniteListResults).setRecords(List.of(expectedDossierProfileDTO));

		when(dao.infinite(any(), eq(null), eq(DEFAULT_PAGE_SIZE))).thenReturn(infiniteListNttResults);

		assertEquals(expectedInfiniteListResults.getRecords(), dossierProfilesCrudService.find(TENANT_ID_1, DOSSIER_CODE_1, null).getRecords());
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_find_infiniteList_withDossierId_ok() {
		InfiniteListResults<Object> infiniteListNttResults = new InfiniteListResultsImpl<>();
		((InfiniteListResultsImpl) infiniteListNttResults).setRecords(List.of(dossierProfileNTT));

		DossierProfileDTO expectedDossierProfileDTO = DossierProfileDTO.builder()
				.dossierId(DOSSIER_ID_1)
				.pkid(PK_ID_1)
				.profileCode(PROFILE_CODE_1)
				.build();

		InfiniteListResults<DossierProfileDTO> expectedInfiniteListResults = new InfiniteListResultsImpl<>();
		((InfiniteListResultsImpl) expectedInfiniteListResults).setRecords(List.of(expectedDossierProfileDTO));

		when(dao.infinite(any(), eq(null), eq(DEFAULT_PAGE_SIZE))).thenReturn(infiniteListNttResults);

		assertEquals(expectedInfiniteListResults.getRecords(), dossierProfilesCrudService.find(TENANT_ID_1, DOSSIER_ID_1, null).getRecords());
	}

/*
	public InfiniteListResults<DossierProfileDTO> find(String tenant, String dossierCode, String nextKey) {
		log.info("Invoking findCategoryByTenantAndCode with params tenant: {} sectorCode: {}", tenant, dossierCode);
		return returnInfiniteResults(
				this.dao.infinite(() -> ((DossierProfileDAO) this.dao).findInfinite(tenant, dossierCode, MDC.get(MDCPreFilter.LOCALE)),
						nextKey,
						DEFAULT_PAGE_SIZE
				),
				mapper::entityToDto);
	}

		protected <Y, A> InfiniteListResults<A> returnInfiniteResults(InfiniteListResults<Y> infiniteListResults, Function<Y, A> customMapper) {
		return new InfiniteListResultsImpl<>(
				infiniteListResults.getRecords()
						.stream()
						.map(customMapper)
						.collect(Collectors.toList()),
				infiniteListResults.getNextKey());
	}

 */
}
