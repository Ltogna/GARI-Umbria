package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.ModulePrintConfigsMapper;
import com.abacogroup.agri.dossiers.core.model.dto.ModulePrintConfigsDTO;
import com.abacogroup.agri.dossiers.core.services.I18NService;
import com.abacogroup.agri.dossiers.db.dao.ModulePrintConfigsDAO;
import com.abacogroup.agri.dossiers.db.ntt.ModulePrintConfigsNTT;
import com.abacogroup.agri.dossiers.db.ntt.dossiers.RsI18N;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import org.apache.commons.lang3.NotImplementedException;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ModulePrintConfigsCrudServiceTest {
    @Mock
    private I18NService i18NServiceMock;
    @Mock
    private ModulePrintConfigsDAO modulePrintConfigsDAOMock;
    @Mock
    private ModulePrintConfigsMapper modulePrintConfigsMapperMock;
    
    @InjectMocks
    private ModulePrintConfigsCrudService modulePrintConfigsCrudService;

    private static final String TENANT = "ADMIN";
    private static final String I18N_DOSSIER_PRINTS_TABLE = "doss_module_print_configs";
    private static final Long MODULE_PRINT_CONFIG_ID = 12L;
    private static final Long MODULE_ID = 5L;
    private static final String PROCESS_STATUS = "process status";
    private static final String PRINT_CODE = "print code";
    private static final String PRINT_DESCRIPTION = "print description";
    private static final Integer SORT_ORDER = 1;
    private static final String CONTEXT_FUNCTION = "context function";
    private static final String PROFILE_CODE = "profile code";
    private static final String LANG = "Language";
    private static final String TEXT = "text";
    private static final String VALUE = "value";
    private static final String FIELD_NAME = "field_name";

    private final ModulePrintConfigsNTT modulePrintConfigsNTT = ModulePrintConfigsNTT.builder()
            .id(MODULE_PRINT_CONFIG_ID)
            .module_id(MODULE_ID)
            .process_status(PROCESS_STATUS)
            .print_code(PRINT_CODE)
            .print_description(PRINT_DESCRIPTION)
            .sort_order(SORT_ORDER)
            .context_function(CONTEXT_FUNCTION)
            .build();
    private final ModulePrintConfigsDTO modulePrintConfigsDTO = ModulePrintConfigsDTO.builder()
            .id(MODULE_PRINT_CONFIG_ID)
            .moduleId(MODULE_ID)
            .processStatus(PROCESS_STATUS)
            .printCode(PRINT_CODE)
            .printDescription(PRINT_DESCRIPTION)
            .sortOrder(SORT_ORDER)
            .contextFunction(CONTEXT_FUNCTION)
            .build();
    private final RsI18N rsI18N = RsI18N.builder()
            .tenant_id(TENANT)
            .i18n_text(TEXT)
            .i18n_value(VALUE)
            .field_name(FIELD_NAME)
            .table_name(I18N_DOSSIER_PRINTS_TABLE)
            .lang(LANG)
            .build();
    
    @Test
    void findAllModulePrintConfigsByTenant_ok() {
        when(modulePrintConfigsDAOMock.findAllModulePrintConfigsByTenant(TENANT))
                .thenReturn(List.of(modulePrintConfigsNTT));
        when(modulePrintConfigsMapperMock.entityToDto(modulePrintConfigsNTT))
                .thenReturn(modulePrintConfigsDTO);

        List<ModulePrintConfigsDTO> result = modulePrintConfigsCrudService.findAllModulePrintConfigsByTenant(TENANT);

        assertEquals(List.of(modulePrintConfigsDTO), result);
    }

    @Test
    void findAllModulePrintConfigs_ok() {
        when(modulePrintConfigsDAOMock.findAllModulePrintConfigs(TENANT, MODULE_ID))
                .thenReturn(List.of(modulePrintConfigsNTT));
        when(modulePrintConfigsMapperMock.entityToDto(modulePrintConfigsNTT))
                .thenReturn(modulePrintConfigsDTO);

        List<ModulePrintConfigsDTO> result = modulePrintConfigsCrudService.findAllModulePrintConfigs(TENANT, MODULE_ID);

        assertEquals(List.of(modulePrintConfigsDTO), result);
    }

    @Test
    void findRsByCustomKey_ok() {
        Optional<ModulePrintConfigsNTT> result = modulePrintConfigsCrudService.findRsByCustomKey(null);

        assertEquals(Optional.empty(), result);
    }

    @Test
    void deleteByCustomKey_ok() {
        assertThrows(NotImplementedException.class, () ->
                modulePrintConfigsCrudService.deleteByCustomKey(null));
    }

    @Test
    void setCustomSearchKey_ok() {
        assertThrows(NotImplementedException.class, () ->
                modulePrintConfigsCrudService.setCustomSearchKey(modulePrintConfigsNTT, null));
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_insert() {
        ModulePrintConfigsDTO payload = ModulePrintConfigsDTO.builder()
                .id(MODULE_PRINT_CONFIG_ID)
                .moduleId(MODULE_ID)
                .processStatus(PROCESS_STATUS)
                .printCode(PRINT_CODE)
                .contextFunction(CONTEXT_FUNCTION)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(modulePrintConfigsDAOMock.nextSequenceVal())
                    .thenReturn(MODULE_ID);
            when(modulePrintConfigsDAOMock.findById(MODULE_ID))
                    .thenReturn(List.of(modulePrintConfigsNTT));
            when(modulePrintConfigsMapperMock.entityToDto(modulePrintConfigsNTT))
                    .thenReturn(modulePrintConfigsDTO);
            when(modulePrintConfigsMapperMock.dtoToEntity(payload))
                    .thenReturn(modulePrintConfigsNTT);

            modulePrintConfigsCrudService.insert(payload);

            verify(modulePrintConfigsDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());
            ModulePrintConfigsDTO actual = (ModulePrintConfigsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(modulePrintConfigsDAOMock);

            assertEquals(modulePrintConfigsDTO, actual);
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_update() {
        ModulePrintConfigsDTO payload = ModulePrintConfigsDTO.builder()
                .id(MODULE_PRINT_CONFIG_ID)
                .moduleId(MODULE_ID)
                .processStatus(PROCESS_STATUS)
                .printCode(PRINT_CODE)
                .contextFunction(CONTEXT_FUNCTION)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(modulePrintConfigsDAOMock.findById(MODULE_ID))
                    .thenReturn(List.of(modulePrintConfigsNTT));
            when(modulePrintConfigsMapperMock.entityToDto(modulePrintConfigsNTT))
                    .thenReturn(modulePrintConfigsDTO);
            when(modulePrintConfigsMapperMock.dtoToEntity(payload))
                    .thenReturn(modulePrintConfigsNTT);

            modulePrintConfigsCrudService.update(MODULE_ID, payload);

            verify(modulePrintConfigsDAOMock).inTransaction(handleConsumerLambdaCaptor.capture());
            handleConsumerLambdaCaptor.getValue().inTransaction(modulePrintConfigsDAOMock);

            verify(modulePrintConfigsDAOMock, times(1)).inTransaction(handleConsumerLambdaCaptor.capture());

            ModulePrintConfigsDTO actual = (ModulePrintConfigsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(modulePrintConfigsDAOMock);

            assertEquals(modulePrintConfigsDTO, actual);
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_delete() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

            modulePrintConfigsCrudService.delete(MODULE_ID);

            verify(modulePrintConfigsDAOMock).useTransaction(handleConsumerLambdaCaptor.capture());
            handleConsumerLambdaCaptor.getValue().useTransaction(modulePrintConfigsDAOMock);

            verify(modulePrintConfigsDAOMock, times(1)).deleteById(MODULE_ID);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void findById_ok() {
        try {
            when(modulePrintConfigsDAOMock.findById(TENANT, MODULE_PRINT_CONFIG_ID, MDC.get(MDCPreFilter.LOCALE)))
                    .thenReturn(List.of(modulePrintConfigsNTT));
            when(modulePrintConfigsMapperMock.entityToDto(modulePrintConfigsNTT))
                    .thenReturn(modulePrintConfigsDTO);

            ModulePrintConfigsDTO result = modulePrintConfigsCrudService.findById(TENANT, MODULE_PRINT_CONFIG_ID);

            assertEquals(modulePrintConfigsDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void findById_ko() {
            when(modulePrintConfigsDAOMock.findById(TENANT, MODULE_PRINT_CONFIG_ID, MDC.get(MDCPreFilter.LOCALE)))
                    .thenReturn(List.of());

            assertThrows(ObjectNotFoundException.class, () ->
                    modulePrintConfigsCrudService.findById(TENANT, MODULE_PRINT_CONFIG_ID));
    }

    @Test
    void find_withProfileCodeList_ok() {
        List<String> profileCodeList = List.of(PROFILE_CODE);

        when(modulePrintConfigsDAOMock.find(TENANT, MODULE_ID, PROCESS_STATUS, profileCodeList, MDC.get(MDCPreFilter.LOCALE)))
                .thenReturn(List.of(modulePrintConfigsNTT));
        when(modulePrintConfigsMapperMock.entityToDto(modulePrintConfigsNTT))
                .thenReturn(modulePrintConfigsDTO);

        List<ModulePrintConfigsDTO> result = modulePrintConfigsCrudService.find(TENANT, MODULE_ID, PROCESS_STATUS, profileCodeList);

        assertEquals(List.of(modulePrintConfigsDTO), result);
    }

    @Test
    void find_withoutProfileCodeList_ok() {
        when(modulePrintConfigsDAOMock.find(TENANT, MODULE_ID, PRINT_CODE, PROCESS_STATUS))
                .thenReturn(List.of(modulePrintConfigsNTT));
        when(modulePrintConfigsMapperMock.entityToDto(modulePrintConfigsNTT))
                .thenReturn(modulePrintConfigsDTO);

        Optional<ModulePrintConfigsDTO> result = modulePrintConfigsCrudService.find(TENANT, MODULE_ID, PRINT_CODE, PROCESS_STATUS);

        assertEquals(Optional.of(modulePrintConfigsDTO), result);
    }

    @Test
    void insertPrintCodeI18N_ok() {
        modulePrintConfigsCrudService.insertPrintCodeI18N(TENANT, PRINT_CODE, LANG, PRINT_DESCRIPTION);

        verify(i18NServiceMock, times(1)).insertI18N(TENANT, I18N_DOSSIER_PRINTS_TABLE,
                ModulePrintConfigsCrudService.PRINT_CODE_I18N.PROFILE_CODE.getCode(), LANG, PRINT_CODE, PRINT_DESCRIPTION);
    }

    @Test
    void deletePrintCodeI18N_ok() {
        modulePrintConfigsCrudService.deletePrintCodeI18N(TENANT, PRINT_CODE, LANG);

        verify(i18NServiceMock, times(1)).deleteI18N(TENANT, I18N_DOSSIER_PRINTS_TABLE,
                ModulePrintConfigsCrudService.PRINT_CODE_I18N.PROFILE_CODE.getCode(), PRINT_CODE, LANG);
    }

    @Test
    void getAllPrintCodeI18NByTenantAndCode_ok() {
        when(i18NServiceMock.getAllI18NbyCode(TENANT, I18N_DOSSIER_PRINTS_TABLE, PRINT_CODE))
                .thenReturn(List.of(rsI18N));

        List<RsI18N> result = modulePrintConfigsCrudService.getAllPrintCodeI18NByTenantAndCode(TENANT, PRINT_CODE);

        assertEquals(List.of(rsI18N), result);
    }
}
