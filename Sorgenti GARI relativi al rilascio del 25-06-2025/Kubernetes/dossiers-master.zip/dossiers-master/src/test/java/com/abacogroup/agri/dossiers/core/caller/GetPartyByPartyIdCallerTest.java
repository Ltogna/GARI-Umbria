package com.abacogroup.agri.dossiers.core.caller;

import com.abacogroup.jaxrsutils.GenericCallerService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.abacogroup.jaxrsutils.GenericCallerService.GET_METHOD;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GetPartyByPartyIdCallerTest {
    @Mock
    GenericCallerService genericCallerService;

    @InjectMocks
    GetPartyByPartyIdCaller getPartyByPartyIdCaller;

    private static final String TENANT = "ADMIN";
    private static final Long PARTY_ID = 123456789L;
    private static final String AUTH_TOKEN = "Auth Token";
    private static final String RESOURCE_URL = "Resource URL";
    private static final String SEARCH_CODE = "Search Code";
    private static final String SEARCH_DESCRIPTION = "Search Description";

    private final GetPartyByPartyIdInput getPartyByPartyIdInput =
            new GetPartyByPartyIdInput(TENANT, PARTY_ID, AUTH_TOKEN, RESOURCE_URL);
    private final GetPartiesOutput getPartiesOutput = GetPartiesOutput.builder()
            .partyId(PARTY_ID)
            .code(SEARCH_CODE)
            .description(SEARCH_DESCRIPTION)
            .build();

    @Test
    void makeCall_ok() {
        when(genericCallerService.makeCall(any(), anyString(), eq(GET_METHOD), any(), any(), eq(AUTH_TOKEN),
                eq(null), eq(null), eq(null)))
                .thenReturn(getPartiesOutput);

        GetPartiesOutput result = getPartyByPartyIdCaller.makeCall(getPartyByPartyIdInput);

        assertEquals(getPartiesOutput, result);
    }
}