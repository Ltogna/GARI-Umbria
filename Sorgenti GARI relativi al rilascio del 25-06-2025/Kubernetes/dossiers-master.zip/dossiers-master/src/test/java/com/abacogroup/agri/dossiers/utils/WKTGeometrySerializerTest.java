package com.abacogroup.agri.dossiers.utils;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.locationtech.jts.geom.*;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class WKTGeometrySerializerTest {
    private final WKTGeometrySerializer wktGeometrySerializer = new WKTGeometrySerializer();

    @Test
    void serialize_ok() {
        try {
            JsonGenerator gen = mock(JsonGenerator.class);
            SerializerProvider provider = mock(SerializerProvider.class);

            GeometryFactory geometryFactory = new GeometryFactory();
            Coordinate[] coordinates = new Coordinate[]{
                    new Coordinate(0, 0), new Coordinate(0, 1),
                    new Coordinate(1, 1), new Coordinate(0, 0)
            };
            LinearRing linearRing = geometryFactory.createLinearRing(coordinates);
            Polygon polygon = geometryFactory.createPolygon(linearRing);
            Geometry geometry = geometryFactory.createGeometry(polygon);

            String wktString = "POLYGON ((0 0, 0 1, 1 1, 0 0))";

            wktGeometrySerializer.serialize(geometry, gen, provider);

            verify(gen, times(1)).writeString(wktString);
        } catch (Exception e) {
            fail(e);
        }
    }
}