package com.abacogroup.agri.dossiers.jackson;

import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class AbsoluteDateSerializerTest {
    private final AbsoluteDateSerializer absoluteDateSerializer = new AbsoluteDateSerializer();

    private static final AbsoluteDate DATE = new AbsoluteDate(LocalDate.now());

    @Test
    void serialize_ok() {
        JsonGenerator jsonGenerator = Mockito.mock(JsonGenerator.class);
        SerializerProvider serializerProvider = Mockito.mock(SerializerProvider.class);

        try {
            absoluteDateSerializer.serialize(DATE, jsonGenerator, serializerProvider);

            verify(jsonGenerator, times(1)).writeString(DATE.toString());
        } catch (Exception e) {
            fail(e);
        }
    }
}