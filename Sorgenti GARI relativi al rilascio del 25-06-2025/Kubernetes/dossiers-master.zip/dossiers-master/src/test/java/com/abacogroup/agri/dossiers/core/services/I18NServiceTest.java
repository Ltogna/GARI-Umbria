package com.abacogroup.agri.dossiers.core.services;

import com.abacogroup.agri.dossiers.db.dao.I18NDAO;
import com.abacogroup.agri.dossiers.db.ntt.dossiers.RsI18N;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class I18NServiceTest {

	private static final String TENANT_1 = "tenant_1";
	private static final String TEXT = "text";
	private static final String VALUE = "value";
	private static final String FIELD_NAME = "field_name";
	private static final String TABLE_NAME = "table_name";
	private static final String LANG = "tenant_1";
	private static final String CODE = "code";
	@Mock
	private I18NDAO i18NDAO;
	@InjectMocks
	private I18NService i18NService;

	private final RsI18N rsI18NMock = RsI18N.builder()
			.tenant_id(TENANT_1)
			.i18n_text(TEXT)
			.i18n_value(VALUE)
			.field_name(FIELD_NAME)
			.table_name(TABLE_NAME)
			.lang(LANG)
			.build();

	@BeforeEach
	protected void init() {
		i18NService = new I18NService(i18NDAO);
	}

	@Test
	void test_insertI18N() {
		try {
			i18NService.insertI18N(TENANT_1, TABLE_NAME, FIELD_NAME, LANG, CODE, TEXT);
			verify(i18NDAO).insertI18N(TENANT_1, TABLE_NAME, FIELD_NAME, CODE, LANG, TEXT);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	@Test
	void test_getI18NByLang() {
		try {
			when(i18NDAO.getI18NByLang(TENANT_1, TABLE_NAME, FIELD_NAME, CODE, LANG)).thenReturn(List.of(rsI18NMock));
			assertEquals(rsI18NMock, i18NService.getI18NByLang(TENANT_1, TABLE_NAME, FIELD_NAME, LANG, CODE));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	@Test
	void test_getAllI18NbyCode() {
		try {
			when(i18NDAO.getAllI18N(TENANT_1, TABLE_NAME, CODE)).thenReturn(List.of(rsI18NMock));
			assertEquals(List.of(rsI18NMock), i18NService.getAllI18NbyCode(TENANT_1, TABLE_NAME, CODE));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	@Test
	void test_deleteI18N_ok() {
		i18NService.deleteI18N(TENANT_1, TABLE_NAME, FIELD_NAME, CODE, LANG);

		verify(i18NDAO, times(1)).deleteI18N(TENANT_1, TABLE_NAME, FIELD_NAME, CODE, LANG);
	}

	@Test
	void test_isI18NPresent_true_ok() {
		when(i18NDAO.getI18NByAllFields(TENANT_1, TABLE_NAME, FIELD_NAME, CODE, LANG, TEXT))
				.thenReturn(List.of(rsI18NMock));

		boolean result = i18NService.isI18NPresent(TENANT_1, TABLE_NAME, FIELD_NAME, CODE, LANG, TEXT);

		assertTrue(result);
	}

	@Test
	void test_isI18NPresent_false_ok() {
		when(i18NDAO.getI18NByAllFields(TENANT_1, TABLE_NAME, FIELD_NAME, CODE, LANG, TEXT))
				.thenReturn(List.of());

		boolean result = i18NService.isI18NPresent(TENANT_1, TABLE_NAME, FIELD_NAME, CODE, LANG, TEXT);

		assertFalse(result);
	}

}
