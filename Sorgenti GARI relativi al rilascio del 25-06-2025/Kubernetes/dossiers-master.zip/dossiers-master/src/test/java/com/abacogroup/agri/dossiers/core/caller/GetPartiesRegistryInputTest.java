package com.abacogroup.agri.dossiers.core.caller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;

import static com.abacogroup.jaxrsutils.GenericCallerService.GET_METHOD;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class GetPartiesRegistryInputTest {
    private GetPartiesRegistryInput getPartiesRegistryInput;

    private static final String TENANT = "ADMIN";
    private static final Long PARTY_ID = 123456789L;
    private static final String AUTH_TOKEN = "Auth Token";
    private static final String RESOURCE_URL = "Resource URL";
    private static final String SEARCH_CODE = "Search Code";
    private static final String SEARCH_DESCRIPTION = "Search Description";
    private static final String PARTY_REGISTRY_URL = "Party Registry URL";

    @BeforeEach
    void init() {
        getPartiesRegistryInput = new GetPartiesRegistryInput(TENANT, PARTY_ID, AUTH_TOKEN, SEARCH_CODE,
                SEARCH_DESCRIPTION, PARTY_REGISTRY_URL, RESOURCE_URL);
    }

    @Test
    void getPathVariablesMap_ok() {
        Map<String, Object> expectedOutput = Map.of("tenant", TENANT);

        Map<String, Object> result = getPartiesRegistryInput.getPathVariablesMap();

        assertEquals(expectedOutput, result);
    }

    @Test
    void provideAuthToken_ok() {
        String result = getPartiesRegistryInput.provideAuthToken();

        assertEquals(AUTH_TOKEN, result);
    }

    @Test
    void getQueryParamsMap_ok() {
        Map<String, Object> expectedOutput = Map.of("code", SEARCH_CODE,
                "fullName", SEARCH_DESCRIPTION);

        Map<String, Object> result = getPartiesRegistryInput.getQueryParamsMap();

        assertEquals(expectedOutput, result);
    }

    @Test
    void getUrl_ok() {
        String expectedOutput = PARTY_REGISTRY_URL + RESOURCE_URL;

        String result = getPartiesRegistryInput.getUrl();

        assertEquals(expectedOutput, result);
    }

    @Test
    void getHttpMethod_ok() {
        String result = getPartiesRegistryInput.getHttpMethod();

        assertEquals(GET_METHOD, result);
    }
}