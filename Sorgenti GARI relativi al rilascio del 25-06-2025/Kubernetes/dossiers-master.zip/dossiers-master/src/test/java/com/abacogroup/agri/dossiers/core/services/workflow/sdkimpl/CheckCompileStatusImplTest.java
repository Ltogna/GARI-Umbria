package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.services.crud.DossierCompileStatusCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CheckCompileStatusImplTest {
    @Mock
    private DossierCompileStatusCrudService dossierCompileStatusCrudService;

    @InjectMocks
    private CheckCompileStatusImpl checkCompileStatus;

    private static final String TENANT = "ADMIN";
    private static final Long DOSSIER_ID = 5L;
    private static final Long PKID = 1L;
    private static final String STATUS = "Status";
    private static final String COMPILE_STATUS_IDENTIFIER = "Compile Status Identifier";

    ApplicationCompileStatusDTO applicationCompileStatusDTO = ApplicationCompileStatusDTO.builder()
            .applicationId(DOSSIER_ID)
            .compileStatusIdentifier(COMPILE_STATUS_IDENTIFIER)
            .status(STATUS)
            .pkid(PKID)
            .build();

    @Test
    void getStatuses_ok() {
        when(dossierCompileStatusCrudService.find(TENANT, DOSSIER_ID))
                .thenReturn(List.of(applicationCompileStatusDTO));

        List<ApplicationCompileStatusDTO> result = checkCompileStatus.getStatuses(TENANT, DOSSIER_ID);

        assertEquals(List.of(applicationCompileStatusDTO), result);
    }
}