package com.abacogroup.agri.dossiers.core.caller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;
import java.util.Objects;

import static com.abacogroup.jaxrsutils.GenericCallerService.GET_METHOD;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class GetPartyByPartyIdInputTest {
    private GetPartyByPartyIdInput getPartyByPartyIdInput;

    private static final String TENANT = "ADMIN";
    private static final Long PARTY_ID = 123546789L;
    private static final String AUTH_TOKEN = "Auth Token";
    private static final String RESOURCE_URL = "Resource URL";

    @BeforeEach
    void init() {
        getPartyByPartyIdInput = new GetPartyByPartyIdInput(TENANT, PARTY_ID, AUTH_TOKEN, RESOURCE_URL);
    }

    @Test
    void getPathVariablesMap_ok() {
        Map<String, Object> expectedOutput = Map.of("TENANT", TENANT,
                "PARTY_ID", PARTY_ID);

        Map<String, Object> result = getPartyByPartyIdInput.getPathVariablesMap();

        assertEquals(expectedOutput, result);
    }

    @Test
    void provideAuthToken_oK() {
        String result = getPartyByPartyIdInput.provideAuthToken();

        assertEquals(AUTH_TOKEN, result);
    }

    @Test
    void getQueryParamsMap_ok() {
        Map<String, Object> result = getPartyByPartyIdInput.getQueryParamsMap();

        assertEquals(Map.of(), result);
    }

    @Test
    void getUrl_ok() {
        String result = getPartyByPartyIdInput.getUrl();

        assertEquals(RESOURCE_URL, result);
    }

    @Test
    void getHttpMethod_ok() {
        String result = getPartyByPartyIdInput.getHttpMethod();

        assertEquals(GET_METHOD, result);
    }

    @Test
    void equals_true_ok() {
        GetPartyByPartyIdInput newInstance = new GetPartyByPartyIdInput(TENANT, PARTY_ID, AUTH_TOKEN, RESOURCE_URL);

        boolean result = getPartyByPartyIdInput.equals(newInstance);

        assertTrue(result);
    }

    @Test
    void equals_differentTenant_false_ok() {
        GetPartyByPartyIdInput newInstance =
                new GetPartyByPartyIdInput("Different Tenant", PARTY_ID, AUTH_TOKEN, RESOURCE_URL);

        boolean result = getPartyByPartyIdInput.equals(newInstance);

        assertFalse(result);
    }

    @Test
    void equals_differentParty_false_ok() {
        GetPartyByPartyIdInput newInstance = new GetPartyByPartyIdInput(TENANT, 0L, AUTH_TOKEN, RESOURCE_URL);

        boolean result = getPartyByPartyIdInput.equals(newInstance);

        assertFalse(result);
    }

    @Test
    void equals_sameObject_true_ok() {
        boolean result = getPartyByPartyIdInput.equals(getPartyByPartyIdInput);

        assertTrue(result);
    }

    @Test
    void equals_differentInstance_false_ok() {
        CheckCanReadPartyInput checkCanReadPartyInput = CheckCanReadPartyInput.builder()
                .url(RESOURCE_URL)
                .tenant(TENANT)
                .partyId(PARTY_ID)
                .authToken(AUTH_TOKEN)
                .build();

        boolean result = getPartyByPartyIdInput.equals(checkCanReadPartyInput);

        assertFalse(result);
    }

    @Test
    void hashCode_ok() {
        Integer expectedOutput = Objects.hash(TENANT, PARTY_ID);

        Integer result = getPartyByPartyIdInput.hashCode();

        assertEquals(expectedOutput, result);
    }
}