package com.abacogroup.agri.dossiers.utils;

import com.abacogroup.agri.dossiers.core.mappers.AmendableModuleMapper;
import com.abacogroup.agri.dossiers.core.model.dto.AmendableModuleDTO;
import com.abacogroup.agri.dossiers.db.ntt.AmendableModuleNTT;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class GenericUtilityTest {
    private static final String KEY = "Key";
    private static final String VALUE = "Value";
    private static final Long PKID = 1L;
    private static final Long MODULE_ID = 5L;
    private static final Long AMENDABLE_MODULE_ID = 10L;

    private final AmendableModuleNTT amendableModuleNTT = AmendableModuleNTT.builder()
            .pkid(PKID)
            .module_id(MODULE_ID)
            .amendable_module_id(AMENDABLE_MODULE_ID)
            .build();
    private final AmendableModuleDTO amendableModuleDTO = AmendableModuleDTO.builder()
            .pkid(PKID)
            .moduleId(MODULE_ID)
            .amendableModuleId(AMENDABLE_MODULE_ID)
            .build();

    @Test
    void getValueFromInIfIsNotNull_ok() {
        Map<String, String> map = Map.of(KEY, VALUE);

        Collection<String> result = GenericUtility.getValueFromInIfIsNotNull(map::values, map::keySet);

        assertEquals(map.values(), result);
    }

    @Test
    void returnInfiniteResults_ok() {
        InfiniteListResults<AmendableModuleNTT> amendableModules =
                new InfiniteListResultsImpl<>(List.of(amendableModuleNTT), null);

        InfiniteListResults<AmendableModuleDTO> result =
                GenericUtility.returnInfiniteResults(amendableModules, AmendableModuleMapper.INSTANCE::entityToDto);

        assertEquals(List.of(amendableModuleDTO), result.getRecords());
    }

    @Test
    void returnOptionalFromList_ok() {
        Optional<AmendableModuleDTO> result =
                GenericUtility.returnOptionalFromList(List.of(amendableModuleNTT), AmendableModuleMapper.INSTANCE::entityToDto);

        assertEquals(Optional.of(amendableModuleDTO), result);
    }

    @Test
    void returnMappedList_ok() {
        List<AmendableModuleDTO> result =
                GenericUtility.returnMappedList(List.of(amendableModuleNTT), AmendableModuleMapper.INSTANCE::entityToDto);

        assertEquals(List.of(amendableModuleDTO), result);
    }
}