package com.abacogroup.agri.dossiers.resources;

import com.abacogroup.agri.dossiers.core.services.workflow.DossiersWorkflowService;
import com.abacogroup.dropwizard.auth.sso2.User;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import jakarta.ws.rs.core.Response;

import java.io.InputStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class WorkflowResourcesTest {

	@Mock
	private DossiersWorkflowService taskManagerWorkflowService;

	@InjectMocks
	private WorkflowResources workflowResources;

	private static final String TENANT_1 = "tenant1";
	private static final String USER_ID_1 = "user1";

	/**
	 * USERS
	 */
	private static final User loggedUser_1 = new User(USER_ID_1, TENANT_1);

	@BeforeEach
	void init() {
		workflowResources = new WorkflowResources(taskManagerWorkflowService);
	}

	@Test
	void test_installWorkflow() {
		try {
			assertEquals(Response.Status.OK.getStatusCode(), workflowResources.installWorkflow(TENANT_1, loggedUser_1, mock(InputStream.class)).getStatus());
			verify(taskManagerWorkflowService).addOrUpdateWorkflowFromInputStream(eq(TENANT_1), any());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e);
		}
	}

}
