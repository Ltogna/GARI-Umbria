package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AbsoluteDateMapperTest {
    private final AbsoluteDateMapper absoluteDateMapper = new AbsoluteDateMapper();

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");

    @Test
    void asString_ok() {
        AbsoluteDate absoluteDate = new AbsoluteDate(LocalDate.of(2023, 8, 4));

        String expectedOutput = "20230804";

        String result = absoluteDateMapper.asString(absoluteDate);

        assertEquals(expectedOutput, result);
    }

    @Test
    void asString_nullInput_ok() {
        String result = absoluteDateMapper.asString(null);

        assertNull(result);
    }

    @Test
    void asString_catchException_ok() {
        AbsoluteDate invalidAbsoluteDate = mock(AbsoluteDate.class);

        when(invalidAbsoluteDate.toString())
                .thenThrow(DateTimeParseException.class);

        String result = absoluteDateMapper.asString(invalidAbsoluteDate);

        assertNull(result);
    }

    @Test
    void asLocalDate_ok() {
        AbsoluteDate absoluteDate = new AbsoluteDate(LocalDate.of(2023, 8, 4));

        LocalDate expectedOutput = LocalDate.of(2023, 8, 4);

        LocalDate result = absoluteDateMapper.asLocalDate(absoluteDate);

        assertEquals(expectedOutput, result);
    }

    @Test
    void asLocalDate_nullInput() {
        LocalDate result = absoluteDateMapper.asLocalDate(null);

        assertNull(result);
    }

    @Test
    void asLocalDate_catchException_ok() {
        AbsoluteDate invalidAbsoluteDate = mock(AbsoluteDate.class);

        when(invalidAbsoluteDate.get())
                .thenThrow(DateTimeParseException.class);

        LocalDate result = absoluteDateMapper.asLocalDate(invalidAbsoluteDate);

        assertNull(result);
    }

    @Test
    void asAbsoluteDate_fromString_ok() {
        String date = "20230804";

        AbsoluteDate expectedOutput = new AbsoluteDate(date);

        AbsoluteDate result = absoluteDateMapper.asAbsoluteDate(date);

        assertEquals(expectedOutput, result);
    }

    @Test
    void asAbsoluteDate_fromString_nullInput_ok() {
        AbsoluteDate result = absoluteDateMapper.asAbsoluteDate((String) null);

        assertNull(result);
    }

    @Test
    void asAbsoluteDate_fromString_blankInput_ok() {
        AbsoluteDate result = absoluteDateMapper.asAbsoluteDate("");

        assertNull(result);
    }

    @Test
    void asAbsoluteDate_fromString_catchException_ok() {
        String invalidDate = "Invalid Date";

        AbsoluteDate result = absoluteDateMapper.asAbsoluteDate(invalidDate);

        assertNull(result);
    }

    @Test
    void asAbsoluteDate_fromLocalDate_ok() {
        LocalDate date = LocalDate.now();

        AbsoluteDate expectedOutput = new AbsoluteDate(date);

        AbsoluteDate result = absoluteDateMapper.asAbsoluteDate(date);

        assertEquals(expectedOutput, result);
    }

    @Test
    void asAbsoluteDate_fromLocalDate_nullInput_ok() {
        AbsoluteDate result = absoluteDateMapper.asAbsoluteDate((LocalDate) null);

        assertNull(result);
    }

    @Test
    void asAbsoluteDate_fromLocalDate_catchException_ok() {
        LocalDate invalidDate = mock(LocalDate.class);

        when(invalidDate.format(FORMATTER))
                .thenThrow(DateTimeException.class);

        AbsoluteDate result = absoluteDateMapper.asAbsoluteDate(invalidDate);

        assertNull(result);
    }
}