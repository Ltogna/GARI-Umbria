package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.DossierDetailsMapper;
import com.abacogroup.agri.dossiers.core.model.ProcessTransitionEnum;
import com.abacogroup.agri.dossiers.core.model.dto.DossierDetailsDTO;
import com.abacogroup.agri.dossiers.db.dao.DossierDetailsDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierDetailsNTT;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DossierDetailsCrudServiceTest {

	private static final String TENANT_ID_1 = "tenant_1";
	private static final Long DOSSIER_ID_1 = 1L;
	private static final String DOSSIER_CODE_1 = "dossierCode_1";
	private static final LocalDateTime DOSSIER_DT_CLOSED_1 = LocalDateTime.of(2022, 9, 19, 12, 0);
	private static final LocalDateTime DEFAULT_NOT_DELETED_DATE = LocalDateTime.ofInstant(Instant.ofEpochSecond(253402300799L), ZoneOffset.UTC);
	private static final LocalDateTime NOW = LocalDateTime.now();
	private static final String DOSSIER_PROCESS_STATUS_1 = "1L";
	private static final String USER_ID = "user1";
	private static final DossierDetailsDTO dossierDetailsDTO = DossierDetailsDTO.builder()
			.dossierCode(DOSSIER_CODE_1)
			.dossierId(DOSSIER_ID_1)
			.dtClosed(DOSSIER_DT_CLOSED_1)
			.pkid(DOSSIER_ID_1)
			.processStatus(DOSSIER_PROCESS_STATUS_1)
			.userIdInsert(USER_ID)
			.userIdDelete(null)
			.dtInsert(NOW)
			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.flInTransition(1)
			.build();
	private static final DossierDetailsDTO dossierDetailsDTOResult = DossierDetailsDTO.builder()
			.dossierCode(DOSSIER_CODE_1)
			.dossierId(DOSSIER_ID_1)
			.dtClosed(DOSSIER_DT_CLOSED_1)
			.pkid(DOSSIER_ID_1)
			.processStatus(DOSSIER_PROCESS_STATUS_1)
			.userIdInsert(USER_ID)
			.userIdDelete(null)
			.dtInsert(NOW)
			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.flInTransition(1)
			.build();
	private static final DossierDetailsNTT dossierDetailsNTT = DossierDetailsNTT.builder()
			.dossier_code(DOSSIER_CODE_1)
			.dossier_id(DOSSIER_ID_1)
			.dt_closed(DOSSIER_DT_CLOSED_1)
			.pkid(DOSSIER_ID_1)
			.process_status(DOSSIER_PROCESS_STATUS_1)
			.user_id_insert(USER_ID)
			.user_id_delete(null)
			.dt_insert(NOW)
			.dt_delete(DEFAULT_NOT_DELETED_DATE)
			.fl_in_transition(1)
			.build();

	@Mock
	private DossierDetailsDAO dao;
	@Mock
	private DossierDetailsMapper dossierDetailsMapper;
	@InjectMocks
	private DossierDetailsCrudService dossierDetailsService;

	@Test
	void test_hasPrimaryKey_ok() {
		assertTrue(dossierDetailsService.hasPrimaryKey());
	}

	@Test
	void test_retrieveCustomKeyByResultSet() {
		assertNull(dossierDetailsService.retrieveCustomKeyByResultSet(dossierDetailsNTT));
	}

	@Test
	void test_findRsByCustomKey_ok() {
		assertEquals(Optional.empty(), dossierDetailsService.findRsByCustomKey(null));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_insert_ok() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

			when(dao.nextSequenceVal()).thenReturn(DOSSIER_ID_1);
			when(dao.findById(DOSSIER_ID_1)).thenReturn(List.of(dossierDetailsNTT));
			when(dossierDetailsMapper.dtoToEntity(dossierDetailsDTO)).thenReturn(dossierDetailsNTT);
			when(dossierDetailsMapper.entityToDto(dossierDetailsNTT)).thenReturn(dossierDetailsDTO);

			dossierDetailsService.insert(dossierDetailsDTO, USER_ID);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			DossierDetailsDTO result = (DossierDetailsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(dossierDetailsDTOResult, result);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_update_ok() {
		try {
			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(dao.nextSequenceVal()).thenReturn(DOSSIER_ID_1);
			when(dao.getCurrentTimestamp()).thenReturn(LocalDateTime.now());
			when(dao.findById(DOSSIER_ID_1)).thenReturn(List.of(dossierDetailsNTT));
			when(dossierDetailsMapper.dtoToEntity(dossierDetailsDTO)).thenReturn(dossierDetailsNTT);
			when(dossierDetailsMapper.entityToDto(dossierDetailsNTT)).thenReturn(dossierDetailsDTO);

			dossierDetailsService.update(DOSSIER_ID_1, dossierDetailsDTO, USER_ID);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());

			handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			verify(dao, times(2)).inTransaction(handleConsumerLambdaCaptor.capture());

			DossierDetailsDTO actual = (DossierDetailsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			assertEquals(dossierDetailsDTO, actual);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_delete_ok() {
		try {
			ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

			dossierDetailsService.delete(DOSSIER_ID_1, USER_ID);

			verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useTransaction(dao);
			verify(dao, times(1)).logicallyDeleteById(eq(DOSSIER_ID_1), eq(USER_ID), any());
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_findDossierDetailByCode() {
		try {
			when(dao.findByCode(TENANT_ID_1, DOSSIER_CODE_1))
					.thenReturn(List.of(dossierDetailsNTT));
			when(dossierDetailsMapper.entityToDto(dossierDetailsNTT))
					.thenReturn(dossierDetailsDTO);

			DossierDetailsDTO result = dossierDetailsService.findDossierDetailByCode(TENANT_ID_1, DOSSIER_CODE_1);

			assertEquals(dossierDetailsDTO, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findDossierDetailById() {
		try {
			when(dao.findByDossierId(TENANT_ID_1, DOSSIER_ID_1))
					.thenReturn(List.of(dossierDetailsNTT));
			when(dossierDetailsMapper.entityToDto(dossierDetailsNTT))
					.thenReturn(dossierDetailsDTO);
			when(dao.findFirstDtInsert(TENANT_ID_1, DOSSIER_ID_1))
					.thenReturn(NOW);

			DossierDetailsDTO result = dossierDetailsService.findDossierDetailById(TENANT_ID_1, DOSSIER_ID_1);

			assertEquals(dossierDetailsDTO, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findDossierDetailByCode_ko() {
		try {
			when(dao.findByCode(TENANT_ID_1, DOSSIER_CODE_1))
					.thenReturn(List.of());

			assertThrows(ObjectNotFoundException.class, () ->
					dossierDetailsService.findDossierDetailByCode(TENANT_ID_1, DOSSIER_CODE_1));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findDossierDetailById_ko() {
		try {
			when(dao.findByDossierId(TENANT_ID_1, DOSSIER_ID_1))
					.thenReturn(List.of());

			assertThrows(ObjectNotFoundException.class, () ->
					dossierDetailsService.findDossierDetailById(TENANT_ID_1, DOSSIER_ID_1));
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_updateProcessStatusAndFlTransition() {
		try {
			when(dao.findByDossierIdAlsoExpired(TENANT_ID_1, DOSSIER_ID_1))
					.thenReturn(List.of(dossierDetailsNTT));
			when(dossierDetailsMapper.entityToDto(dossierDetailsNTT))
					.thenReturn(dossierDetailsDTO);
			when(dao.findFirstDtInsert(TENANT_ID_1, DOSSIER_ID_1))
					.thenReturn(NOW);

			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(dao.getCurrentTimestamp()).thenReturn(LocalDateTime.now());

			dossierDetailsService.updateProcessStatusAndFlTransition(TENANT_ID_1, DOSSIER_ID_1,
					DOSSIER_PROCESS_STATUS_1, USER_ID, ProcessTransitionEnum.IN_TRANSITION);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			verify(dao, times(2)).inTransaction(handleConsumerLambdaCaptor.capture());
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_updateFlTransition() {
		try {
			when(dao.findByDossierId(TENANT_ID_1, DOSSIER_ID_1))
					.thenReturn(List.of(dossierDetailsNTT));
			when(dossierDetailsMapper.entityToDto(dossierDetailsNTT))
					.thenReturn(dossierDetailsDTO);
			when(dao.findFirstDtInsert(TENANT_ID_1, DOSSIER_ID_1))
					.thenReturn(NOW);

			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(dao.getCurrentTimestamp()).thenReturn(LocalDateTime.now());

			dossierDetailsService.updateFlTransition(TENANT_ID_1, DOSSIER_ID_1, USER_ID, ProcessTransitionEnum.IN_TRANSITION);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().inTransaction(dao);

			verify(dao, times(2)).inTransaction(handleConsumerLambdaCaptor.capture());
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void cancelAmendedBy_ok() {
		try {
			when(dao.findByDossierId(TENANT_ID_1, DOSSIER_ID_1))
					.thenReturn(List.of(dossierDetailsNTT));
			when(dossierDetailsMapper.entityToDto(dossierDetailsNTT))
					.thenReturn(dossierDetailsDTO);
			when(dao.findFirstDtInsert(TENANT_ID_1, DOSSIER_ID_1))
					.thenReturn(NOW);

			ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
			when(dao.getCurrentTimestamp()).thenReturn(LocalDateTime.now());

			dossierDetailsService.cancelAmendedBy(TENANT_ID_1, DOSSIER_ID_1, USER_ID);

			verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().inTransaction(dao);
		} catch (Exception e) {
			fail(e);
		}
	}
}
