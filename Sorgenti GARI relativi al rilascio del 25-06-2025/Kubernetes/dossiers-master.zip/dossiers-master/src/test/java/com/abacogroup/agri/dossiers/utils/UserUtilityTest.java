package com.abacogroup.agri.dossiers.utils;

import jakarta.ws.rs.core.SecurityContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.security.Principal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserUtilityTest {
    private static final String NAME = "Name";

    @Test
    void getUserIdFromSecurityContext_ok() {
        Principal principal = mock(Principal.class);
        SecurityContext context = mock(SecurityContext.class);

        when(context.getUserPrincipal())
                .thenReturn(principal);
        when(principal.getName())
                .thenReturn(NAME);

        Optional<String> result = UserUtility.getUserIdFromSecurityContext(context);

        assertEquals(Optional.of(NAME), result);
    }

    @Test
    void getUserIdFromSecurityContext_nullPrincipal_ok() {
        SecurityContext context = mock(SecurityContext.class);

        when(context.getUserPrincipal())
                .thenReturn(null);

        Optional<String> result = UserUtility.getUserIdFromSecurityContext(context);

        assertEquals(Optional.empty(), result);
    }

    @Test
    void getUserIdFromSecurityContext_nullContext_ok() {
        Optional<String> result = UserUtility.getUserIdFromSecurityContext(null);

        assertEquals(Optional.empty(), result);
    }
}