package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.model.dto.DossierProfileDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierWithDetailsDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierProfilesCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.ModuleProfilesCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationProfilePublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GetDossierProfilesImplTest {
    @Mock
    private DossiersCrudService dossiersCrudService;
    @Mock
    private ModuleProfilesCrudService moduleProfilesCrudService;
    @Mock
    private DossierProfilesCrudService dossierProfilesCrudService;

    @InjectMocks
    private GetDossierProfilesImpl getDossierProfiles;

    private static final String TENANT = "ADMIN";
    private static final Long DOSSIER_ID = 5L;
    private static final Long PKID = 1L;
    private static final String PROFILE_CODE = "Profile Code";
    private static final String PROFILE_CODE_DESCRIPTION = "Profile Code Description";
    private static final Long PROCESS_ID = 10L;
    private static final String PROCESS_STATUS = "Process Status";
    private static final Long PARTY_ID = 123456789L;
    private static final Long MODULE_ID = 20L;
    private static final Integer REFERRED_YEAR = 2023;

    private final DossierProfileDTO dossierProfileDTO = DossierProfileDTO.builder()
            .dossierId(DOSSIER_ID)
            .pkid(PKID)
            .profileCode(PROFILE_CODE)
            .profileCodeDescription(PROFILE_CODE_DESCRIPTION)
            .build();
    private final DossierWithDetailsDTO dossierWithDetailsDTO = DossierWithDetailsDTO.builder()
            .dossierId(DOSSIER_ID)
            .dossierCode(DOSSIER_ID.toString())
            .referredYear(REFERRED_YEAR)
            .moduleId(MODULE_ID)
            .partyId(PARTY_ID)
            .processStatus(PROCESS_STATUS)
            .processId(PROCESS_ID)
            .build();
    private final ModuleProfileDTO moduleProfileDTO = ModuleProfileDTO.builder()
            .profileCode(PROFILE_CODE)
            .profileCodeDescription(PROFILE_CODE_DESCRIPTION)
            .moduleId(MODULE_ID)
            .pkid(PKID)
            .build();

    @Test
    void getAllApplicationProfiles_ok() {
        ApplicationProfilePublicDTO expectedOutput = ApplicationProfilePublicDTO.builder()
                .profileCode(PROFILE_CODE)
                .profileCodeDescription(PROFILE_CODE_DESCRIPTION)
                .build();

        when(dossierProfilesCrudService.findAll(TENANT, DOSSIER_ID, MDC.get(MDCPreFilter.LOCALE)))
                .thenReturn(List.of(dossierProfileDTO));

        List<ApplicationProfilePublicDTO> result = getDossierProfiles.getAllApplicationProfiles(TENANT, DOSSIER_ID, MDC.get(MDCPreFilter.LOCALE));

        assertEquals(List.of(expectedOutput), result);
    }

    @Test
    void getAllModuleProfiles_ok() {
        when(dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID))
                .thenReturn(dossierWithDetailsDTO);
        when(moduleProfilesCrudService.findWithLocale(TENANT, MODULE_ID, MDC.get(MDCPreFilter.LOCALE)))
                .thenReturn(List.of(moduleProfileDTO));

        List<ModuleProfileDTO> result = getDossierProfiles.getAllModuleProfiles(TENANT, DOSSIER_ID, MDC.get(MDCPreFilter.LOCALE));

        assertEquals(List.of(moduleProfileDTO), result);
    }
}