package com.abacogroup.agri.dossiers.bundles.processor.env;

import com.abacogroup.agri.dossiers.bundles.model.env.BundleDossierEnvInDTO;
import com.abacogroup.agri.dossiers.bundles.model.env.BundleDossierEnvMessage;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.model.dto.DossierEnvDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierEnvCrudService;
import com.abacogroup.agri.dossiers.db.ntt.compoundkeys.DossierEnvKey;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class DossierEnvBundleWorkerTest {

	private static final String TEMPLATE_TENANT_ID = "*";
	private static final String ENV_KEY = "env_key";
	private static final String VALUE = "value";
	private static final Integer FL_CLIENT = 1;

	private final DossierEnvDTO dossierEnvDTO = DossierEnvDTO.builder()
			.tenant(TEMPLATE_TENANT_ID)
			.key(ENV_KEY)
			.value(VALUE)
			.flClient(FL_CLIENT)
			.build();

	private final ConfigDataMessage configDataMessage = new ConfigDataMessage();

	private final BundleDossierEnvInDTO bundleDossierEnvInDTO = BundleDossierEnvInDTO.builder()
			.key(ENV_KEY)
			.value(VALUE)
			.flClient(FL_CLIENT)
			.build();

	private final BundleDossierEnvMessage bundleDossierEnvMessage = BundleDossierEnvMessage.builder()
			.bundleDossierEnvInDTOList(List.of(bundleDossierEnvInDTO))
			.build();

	@InjectMocks
	private DossierEnvBundleWorker dossierEnvBundleWorker;
	@Mock
	private DossierEnvCrudService dossierEnvCrudService;


	@BeforeEach
	void init() {
		configDataMessage.setTenantId(TEMPLATE_TENANT_ID);
		dossierEnvBundleWorker = new DossierEnvBundleWorker(dossierEnvCrudService);
	}

	@Test
	void test_upsertDossierEnvironments_update_ok() {
		try {

			DossierEnvKey key = DossierEnvKey.builder()
					.tenant_id(TEMPLATE_TENANT_ID)
					.key_(ENV_KEY)
					.fl_client(FL_CLIENT)
					.build();

			when(dossierEnvCrudService.findEnvironmentByKey(key)).thenReturn(dossierEnvDTO);

			dossierEnvBundleWorker.upsertDossierEnvironments(TEMPLATE_TENANT_ID, bundleDossierEnvMessage);
			verify(dossierEnvCrudService, times(1)).update(key, dossierEnvDTO);


		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_insertDossierEnvironments_ok() {
		try {

			DossierEnvKey key = DossierEnvKey.builder()
					.tenant_id(TEMPLATE_TENANT_ID)
					.key_(ENV_KEY)
					.fl_client(FL_CLIENT)
					.build();

			when(dossierEnvCrudService.findEnvironmentByKey(key)).thenThrow(ObjectNotFoundException.class);

			dossierEnvBundleWorker.upsertDossierEnvironments(TEMPLATE_TENANT_ID, bundleDossierEnvMessage);

			verify(dossierEnvCrudService, times(1)).insert(dossierEnvDTO);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_deleteDossierEnvironments_ok() {
		try {

			DossierEnvKey key = DossierEnvKey.builder()
					.tenant_id(TEMPLATE_TENANT_ID)
					.key_(ENV_KEY)
					.build();

			when(dossierEnvCrudService.findEnvironmentByKey(key)).thenReturn(dossierEnvDTO);

			dossierEnvBundleWorker.deleteDossierEnvironments(TEMPLATE_TENANT_ID, bundleDossierEnvMessage);

			verify(dossierEnvCrudService, times(1)).delete(key);

		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_exposeDossierEnvCrudServicee() {
		assertEquals(dossierEnvCrudService, dossierEnvBundleWorker.exposeDossierEnvCrudService());
	}

}
