package com.abacogroup.agri.dossiers.utils;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.locationtech.jts.geom.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class WKTGeometryDeserializerTest {
    private final WKTGeometryDeserializer wktGeometryDeserializer = new WKTGeometryDeserializer();

    @Test
    void deserialize_ok() {
        try {
            JsonParser p = mock(JsonParser.class);
            DeserializationContext ctxt = mock(DeserializationContext.class);

            String wktString = "POLYGON ((0 0, 0 1, 1 1, 0 0))";

            GeometryFactory geometryFactory = new GeometryFactory();
            Coordinate[] coordinates = new Coordinate[] {
                    new Coordinate(0, 0), new Coordinate(0, 1),
                    new Coordinate(1, 1), new Coordinate(0, 0)
            };
            LinearRing linearRing = geometryFactory.createLinearRing(coordinates);
            Polygon polygon = geometryFactory.createPolygon(linearRing);
            Geometry expectedOutput = geometryFactory.createGeometry(polygon);

            when(p.readValueAs(String.class))
                    .thenReturn(wktString);

            Geometry result = wktGeometryDeserializer.deserialize(p, ctxt);

            assertEquals(expectedOutput, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void deserialize_ko() {
        try {
            JsonParser p = mock(JsonParser.class);
            DeserializationContext ctxt = mock(DeserializationContext.class);

            String invalidWktString = "Invalid WKT String";

            when(p.readValueAs(String.class))
                    .thenReturn(invalidWktString);

            assertThrows(IOException.class, () ->
                wktGeometryDeserializer.deserialize(p, ctxt));
        } catch (Exception e) {
            fail(e);
        }
    }
}