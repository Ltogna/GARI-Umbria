package com.abacogroup.agri.dossiers.utils;

import jakarta.ws.rs.container.ContainerRequestContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.security.Principal;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class DevAuthorizerTest {
    private DevAuthorizer<Principal> devAuthorizer;

    private static final String ROLE = "Role";

    @BeforeEach
    void init() {
        devAuthorizer = new DevAuthorizer<>(Boolean.TRUE);
    }

    @Test
    void authorize_ok() {
        Principal principal = mock(Principal.class);
        ContainerRequestContext containerRequestContext = mock(ContainerRequestContext.class);

        assertTrue(devAuthorizer.authorize(principal, ROLE, containerRequestContext));
    }
}