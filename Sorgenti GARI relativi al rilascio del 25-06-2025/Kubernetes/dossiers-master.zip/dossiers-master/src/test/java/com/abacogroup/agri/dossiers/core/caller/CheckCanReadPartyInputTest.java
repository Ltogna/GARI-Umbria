package com.abacogroup.agri.dossiers.core.caller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;

import static com.abacogroup.jaxrsutils.GenericCallerService.GET_METHOD;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class CheckCanReadPartyInputTest {
    private CheckCanReadPartyInput checkCanReadPartyInput;

    private static final String URL = "Avepa Legacy URL";
    private static final String TENANT = "ADMIN";
    private static final Long PARTY_ID = 123456789L;
    private static final String AUTH_TOKEN = "Auth Token";

    @BeforeEach
    void init() {
        checkCanReadPartyInput = CheckCanReadPartyInput.builder()
                .url(URL)
                .tenant(TENANT)
                .partyId(PARTY_ID)
                .authToken(AUTH_TOKEN)
                .build();
    }

    @Test
    void getPathVariablesMap_ok() {
        Map<String, Object> expectedOutput = Map.of("TENANT", TENANT, "PARTY_ID", PARTY_ID);

        Map<String, Object> result = checkCanReadPartyInput.getPathVariablesMap();

        assertEquals(expectedOutput, result);
    }

    @Test
    void getHttpMethod_ok() {
        String result = checkCanReadPartyInput.getHttpMethod();

        assertEquals(GET_METHOD, result);
    }

    @Test
    void provideAuthToken_ok() {
        String result = checkCanReadPartyInput.provideAuthToken();

        assertEquals(AUTH_TOKEN, result);
    }
}