package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.model.dto.DossierProfileDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierWithDetailsDTO;
import com.abacogroup.agri.dossiers.core.services.FormConfigService;
import com.abacogroup.agri.dossiers.core.services.crud.DossierCompileStatusCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossierProfilesCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormDetailsPublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormGroupPublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormWithGroupHierarchyPublicDTO;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GetFormConfigsImplTest {
    @Mock
    private DossiersCrudService dossiersCrudService;
    @Mock
    private DossierProfilesCrudService dossierProfilesCrudService;
    @Mock
    private DossierCompileStatusCrudService dossierCompileStatusCrudService;
    @Mock
    private FormConfigService formConfigService;
    @Mock
    private Sso2Client sso2Client;

    @InjectMocks
    private GetFormConfigsImpl getFormConfigs;

    private static final String TENANT = "ADMIN";
    private static final Long DOSSIER_ID = 5L;
    private static final Long PROCESS_ID = 10L;
    private static final String PROFILE_CODE = "Profile Code";
    private static final String PROFILE_CODE_DESCRIPTION = "Profile Code Description";
    private static final Long PKID = 1L;
    private static final String COMPILE_STATUS_IDENTIFIER = "Compile Status Identifier";
    private static final String STATUS = "Status";
    private static final Long FORM_CONFIG_ID = 15L;
    private static final String FORM_CODE = "Form Code";
    private static final String FORM_NAME = "Form Name";
    private static final String GROUP_NAME = "Group Name";
    private static final String GROUP_CODE = "Group Code";
    private static final Long MODULE_ID = 20L;
    private static final String PROCESS_STATUS = "Process Status";
    private static final String USERNAME = "Username";
    private static final User USER = new User(USERNAME, TENANT);

    private final DossierWithDetailsDTO dossierWithDetailsDTO = DossierWithDetailsDTO.builder()
            .dossierId(DOSSIER_ID)
            .dossierCode(DOSSIER_ID.toString())
            .processId(PROCESS_ID)
            .moduleId(MODULE_ID)
            .processStatus(PROCESS_STATUS)
            .build();
    private final ApplicationCompileStatusDTO applicationCompileStatusDTO = ApplicationCompileStatusDTO.builder()
            .pkid(PKID)
            .applicationId(DOSSIER_ID)
            .compileStatusIdentifier(COMPILE_STATUS_IDENTIFIER)
            .status(STATUS)
            .build();
    private final DossierProfileDTO dossierProfileDTO = DossierProfileDTO.builder()
            .dossierId(DOSSIER_ID)
            .pkid(PKID)
            .profileCode(PROFILE_CODE)
            .profileCodeDescription(PROFILE_CODE_DESCRIPTION)
            .build();
    private final FormDetailsPublicDTO formDetailsPublicDTO = FormDetailsPublicDTO.builder()
            .formConfigId(FORM_CONFIG_ID)
            .formCode(FORM_CODE)
            .formName(FORM_NAME)
            .compileStatusIdentifier(COMPILE_STATUS_IDENTIFIER)
            .build();
    private final FormGroupPublicDTO formGroupPublicDTO = FormGroupPublicDTO.builder()
            .groupCode(GROUP_CODE)
            .groupName(GROUP_NAME)
            .build();
    private final FormWithGroupHierarchyPublicDTO formWithGroupHierarchyPublicDTO = FormWithGroupHierarchyPublicDTO.builder()
            .formDetails(formDetailsPublicDTO)
            .groups(List.of(formGroupPublicDTO))
            .build();

    @Test
    void getForms_ok() {
        try {
            when(dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID))
                    .thenReturn(dossierWithDetailsDTO);
            when(dossierCompileStatusCrudService.find(TENANT, DOSSIER_ID))
                    .thenReturn(List.of(applicationCompileStatusDTO));
            when(dossierProfilesCrudService.findAll(TENANT, DOSSIER_ID, MDC.get(MDCPreFilter.LOCALE)))
                    .thenReturn(List.of(dossierProfileDTO));
            when(formConfigService.getFormsByModuleIdAndProcessStatus(TENANT, MODULE_ID, PROCESS_STATUS,
                    List.of(applicationCompileStatusDTO), List.of(PROFILE_CODE), null, MDC.get(MDCPreFilter.LOCALE)))
                    .thenReturn(List.of(formWithGroupHierarchyPublicDTO));

            List<FormWithGroupHierarchyPublicDTO> result = getFormConfigs.getForms(TENANT, DOSSIER_ID, USER, MDC.get(MDCPreFilter.LOCALE));

            assertEquals(List.of(formWithGroupHierarchyPublicDTO), result);
        }
        catch (Exception e){
            fail(e.getMessage(), e);
        }
    }

    @Test
    void getFormsByProcessStatus_ok() {
        try {
            when(dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID))
                    .thenReturn(dossierWithDetailsDTO);
            when(dossierCompileStatusCrudService.find(TENANT, DOSSIER_ID))
                    .thenReturn(List.of(applicationCompileStatusDTO));
            when(dossierProfilesCrudService.findAll(TENANT, DOSSIER_ID, MDC.get(MDCPreFilter.LOCALE)))
                    .thenReturn(List.of(dossierProfileDTO));
            when(formConfigService.getFormsByModuleIdAndProcessStatus(TENANT, MODULE_ID, PROCESS_STATUS,
                    List.of(applicationCompileStatusDTO), List.of(PROFILE_CODE), null, MDC.get(MDCPreFilter.LOCALE)))
                    .thenReturn(List.of(formWithGroupHierarchyPublicDTO));

            List<FormWithGroupHierarchyPublicDTO> result = getFormConfigs.getFormsByProcessStatus(TENANT, DOSSIER_ID, PROCESS_STATUS, USER,
                    MDC.get(MDCPreFilter.LOCALE));

            assertEquals(List.of(formWithGroupHierarchyPublicDTO), result);
        }
        catch (Exception e){
        fail(e.getMessage(), e);
    }
    }

    @Test
    void getFormsByProcessStatus_emptyRequiredProfileCodes_ok() {
        try {
            DossierProfileDTO dossierProfileWithoutProfileCode = DossierProfileDTO.builder()
                    .dossierId(DOSSIER_ID)
                    .pkid(PKID)
                    .build();

            when(dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID))
                    .thenReturn(dossierWithDetailsDTO);
            when(dossierCompileStatusCrudService.find(TENANT, DOSSIER_ID))
                    .thenReturn(List.of(applicationCompileStatusDTO));
            when(dossierProfilesCrudService.findAll(TENANT, DOSSIER_ID, MDC.get(MDCPreFilter.LOCALE)))
                    .thenReturn(List.of(dossierProfileWithoutProfileCode));
            when(formConfigService.getFormsByModuleIdAndProcessStatus(TENANT, MODULE_ID, PROCESS_STATUS,
                    List.of(applicationCompileStatusDTO), List.of(""), null, MDC.get(MDCPreFilter.LOCALE)))
                    .thenReturn(List.of(formWithGroupHierarchyPublicDTO));

            List<FormWithGroupHierarchyPublicDTO> result = getFormConfigs.getFormsByProcessStatus(TENANT, DOSSIER_ID, PROCESS_STATUS, USER,
                    MDC.get(MDCPreFilter.LOCALE));

            assertEquals(List.of(formWithGroupHierarchyPublicDTO), result);
        }
        catch (Exception e){
            fail(e.getMessage(), e);
        }
    }
    }
