package com.abacogroup.agri.dossiers.core.services;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.model.dto.DossierEnvDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierEnvPublicDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierEnvCrudService;
import com.abacogroup.agri.dossiers.db.ntt.compoundkeys.DossierEnvKey;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ConfigServiceTest {
    @Mock
    DossierEnvCrudService dossierEnvCrudService;

    @InjectMocks
    ConfigService configService;

    private static final String TENANT = "ADMIN";
    private static final String SEARCH_KEY = "Search Key";
    private static final Integer FL_CLIENT = 1;
    private static final String VALUE = "Value";

    private final DossierEnvKey key = DossierEnvKey.builder()
            .tenant_id(TENANT)
            .key_(SEARCH_KEY)
            .fl_client(FL_CLIENT)
            .build();
    private final DossierEnvDTO dossierEnvDTO = DossierEnvDTO.builder()
            .tenant(TENANT)
            .flClient(FL_CLIENT)
            .key(SEARCH_KEY)
            .value(VALUE)
            .build();
    private final DossierEnvDTO dossierEnvDTOFalseFlClient = DossierEnvDTO.builder()
            .tenant(TENANT)
            .flClient(0)
            .key(SEARCH_KEY)
            .value(VALUE)
            .build();

    @Test
    void getConfig_ok() {
        try {
            when(dossierEnvCrudService.findEnvironmentByKey(key))
                    .thenReturn(dossierEnvDTO);

            DossierEnvPublicDTO expectedOutput = DossierEnvPublicDTO.builder()
                    .key(SEARCH_KEY)
                    .value(VALUE)
                    .build();

            List<DossierEnvPublicDTO> result = configService.getConfig(TENANT, SEARCH_KEY);

            assertEquals(List.of(expectedOutput), result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void getConfig_nullSearchKey_ok() {
            when(dossierEnvCrudService.findAllByTenant(TENANT))
                    .thenReturn(List.of(dossierEnvDTO));

            DossierEnvPublicDTO expectedOutput = DossierEnvPublicDTO.builder()
                    .key(SEARCH_KEY)
                    .value(VALUE)
                    .build();

            List<DossierEnvPublicDTO> result = configService.getConfig(TENANT, null);

            assertEquals(List.of(expectedOutput), result);
    }

    @Test
    void getConfig_flClientFalse_ok() {
            when(dossierEnvCrudService.findAllByTenant(TENANT))
                    .thenReturn(List.of(dossierEnvDTOFalseFlClient));

            List<DossierEnvPublicDTO> result = configService.getConfig(TENANT, null);

            assertEquals(List.of(), result);
    }

    @Test
    void getConfig_ko() {
        try {
            when(dossierEnvCrudService.findEnvironmentByKey(key))
                    .thenThrow(ObjectNotFoundException.class);

            assertThrows(ObjectNotFoundRuntimeException.class, () ->
                    configService.getConfig(TENANT, SEARCH_KEY));
        } catch (Exception e) {
            fail(e);
        }
    }
}