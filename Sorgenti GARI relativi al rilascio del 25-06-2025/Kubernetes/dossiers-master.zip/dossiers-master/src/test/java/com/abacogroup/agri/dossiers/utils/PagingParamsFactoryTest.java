package com.abacogroup.agri.dossiers.utils;

import com.abacogroup.jdbi.paging.PagingParams;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class PagingParamsFactoryTest {
    private final PagingParamsFactory pagingParamsFactory = new PagingParamsFactory();

    @Test
    void getPagingParams_ok() {
        int OFFSET = 0;
        int LIMIT = 100;

        PagingParams expectedOutput = new PagingParams(OFFSET, LIMIT);
        PagingParams result = pagingParamsFactory.getPagingParams(OFFSET, LIMIT);

        assertEquals(expectedOutput.getOffset(), result.getOffset());
        assertEquals(expectedOutput.getLimit(), result.getLimit());
        assertEquals(expectedOutput.getLast(), result.getLast());
    }
}