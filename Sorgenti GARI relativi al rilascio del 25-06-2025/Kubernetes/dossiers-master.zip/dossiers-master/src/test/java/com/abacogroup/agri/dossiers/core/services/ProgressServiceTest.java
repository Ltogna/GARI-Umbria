package com.abacogroup.agri.dossiers.core.services;

import com.abacogroup.agri.dossiers.core.exceptions.DossierNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.NoTransitionFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.model.ProcessTransitionEnum;
import com.abacogroup.agri.dossiers.core.model.ProgressTypeEnum;
import com.abacogroup.agri.dossiers.core.model.dto.DossierDetailsDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.ProgressDossierDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierDetailsCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.agri.dossiers.core.services.embededqueue.CreateProcessQueue;
import com.abacogroup.agri.dossiers.core.services.embededqueue.UpdateProcessQueue;
import com.abacogroup.agri.dossiers.core.services.embededqueue.model.QueueWorkflowParams;
import com.abacogroup.agri.dossiers.core.services.workflow.DossiersWorkflowService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.server.model.DetailedTransitionLog;
import com.abacogroup.workflow.server.model.Transition;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.HandleConsumer;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ProgressServiceTest {

	@Mock
	private Jdbi jdbi;
	@Mock
	private DossiersWorkflowService dossiersWorkflowService;
	@Mock
	private DossierDetailsCrudService dossierDetailsCrudService;
	@Mock
	private DossiersCrudService dossiersCrudService;
	@Mock
	private UpdateProcessQueue updateProcessQueue;
	@Mock
	private ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService;
	@Mock
	private Handle handle;
	@InjectMocks
	private ProgressService progressService;

	private static final String TENANT_1 = "tenant_1";
	private static final Long PARTY_ID_1 = 24L;
	private static final Integer YEAR_1 = 2022;
	private static final Long DOSSIER_ID_1 = 30L;
	private static final String SCOPE = "scope";
	private static final Long MODULE_ID_1 = 1L;
	private static final Integer TRANSITION_ID = 5;
	private static final String NODE_FROM = "node from";
	private static final String NODE_TO = "node to";
	private static final String NOTES = "notes";
	private static final Long PROCESS_ID_1 = 1L;
	private static final String USER_1 = "user_1";
	private static final LocalDateTime NOW = LocalDateTime.now();
	private static final String PROCESS_STATUS = "start";
	private static final User logged_user1 = new User(USER_1, TENANT_1);
	private static final LocalDateTime DEFAULT_NOT_DELETED_DATE = LocalDateTime.ofInstant(Instant.ofEpochSecond(253402300799L), ZoneOffset.UTC);
	private static final String DOSSIER_CODE_1 = "30";
	private static final Long DOSSIER_DETAILS_ID_1 = 36L;
	private static final User USER = new User(USER_1, TENANT_1);

	@BeforeEach
	protected void init() {
		progressService = new ProgressService(
				jdbi,
				dossiersWorkflowService,
				dossiersCrudService,
				dossierDetailsCrudService,
				forceReadOnlyContextCheckerService,
				updateProcessQueue);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_progress_async_ok() {
		try {
			ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			DossierDTO dossierDTO = DossierDTO.builder()
					.moduleId(MODULE_ID_1)
					.dossierId(DOSSIER_ID_1)
					.referredYear(YEAR_1)
					.partyId(PARTY_ID_1)
					.processId(PROCESS_ID_1)
					.build();
			List<String> tags = List.of("Tag - 1", "Tag - 2", "Tag - 3", "Tag - 4");
			Transition transition = Transition.builder()
					.scope(SCOPE)
					.id(TRANSITION_ID)
					.notesRequired(false)
					.fromNode(NODE_FROM)
					.toNode(NODE_TO)
					.tags(tags)
					.build();
			ProgressDossierDTO progressDossierDTO = ProgressDossierDTO.builder()
					.notes(NOTES)
					.build();
			DossierDetailsDTO dossierDetailsDTO = DossierDetailsDTO.builder()
					.dossierCode(DOSSIER_CODE_1)
					.dossierId(DOSSIER_ID_1)
					.dtDelete(DEFAULT_NOT_DELETED_DATE)
					.dtInsert(NOW)
					.pkid(DOSSIER_DETAILS_ID_1)
					.processStatus(PROCESS_STATUS)
					.userIdInsert(USER_1)
					.build();
			QueueWorkflowParams queueWorkflowParams = QueueWorkflowParams.builder()
					.processId(PROCESS_ID_1)
					.dossierId(DOSSIER_ID_1)
					.tenant(TENANT_1)
					.transitionId(TRANSITION_ID)
					.username(USER_1)
					.locale(Optional.ofNullable(MDC.get(MDCPreFilter.LOCALE)).orElse("it"))
					.scope(SCOPE)
					.notes(progressDossierDTO.getNotes())
					.build();

			when(dossiersCrudService.findById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDTO);
			when(dossiersWorkflowService.getUserAvailableTransitions(PROCESS_ID_1, logged_user1, SCOPE))
					.thenReturn(List.of(transition));
			when(dossierDetailsCrudService.findDossierDetailById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDetailsDTO);

			progressService.progress(TENANT_1, DOSSIER_ID_1, "Tag - 1", logged_user1, SCOPE, progressDossierDTO, ProgressTypeEnum.ASYNC);

			verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useHandle(handle);

			verify(dossierDetailsCrudService, times(1))
					.updateProcessStatusAndFlTransition(TENANT_1, DOSSIER_ID_1, PROCESS_STATUS, USER_1, ProcessTransitionEnum.IN_TRANSITION);
			verify(updateProcessQueue, times(1))
					.add(eq(queueWorkflowParams), anyLong());
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_progress_sync_ok() {
		try {
			ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			DossierDTO dossierDTO = DossierDTO.builder()
					.moduleId(MODULE_ID_1)
					.dossierId(DOSSIER_ID_1)
					.referredYear(YEAR_1)
					.partyId(PARTY_ID_1)
					.processId(PROCESS_ID_1)
					.build();
			List<String> tags = List.of("Tag - 1", "Tag - 2", "Tag - 3", "Tag - 4");
			Transition transition = Transition.builder()
					.scope(SCOPE)
					.id(TRANSITION_ID)
					.notesRequired(false)
					.fromNode(NODE_FROM)
					.toNode(NODE_TO)
					.tags(tags)
					.build();
			ProgressDossierDTO progressDossierDTO = ProgressDossierDTO.builder()
					.notes(NOTES)
					.build();
			DossierDetailsDTO dossierDetailsDTO = DossierDetailsDTO.builder()
					.dossierCode(DOSSIER_CODE_1)
					.dossierId(DOSSIER_ID_1)
					.dtDelete(DEFAULT_NOT_DELETED_DATE)
					.dtInsert(NOW)
					.pkid(DOSSIER_DETAILS_ID_1)
					.processStatus(PROCESS_STATUS)
					.userIdInsert(USER_1)
					.build();
			QueueWorkflowParams queueWorkflowParams = QueueWorkflowParams.builder()
					.processId(PROCESS_ID_1)
					.dossierId(DOSSIER_ID_1)
					.tenant(TENANT_1)
					.transitionId(TRANSITION_ID)
					.username(USER_1)
					.locale(Optional.ofNullable(MDC.get(MDCPreFilter.LOCALE)).orElse("it"))
					.scope(SCOPE)
					.notes(progressDossierDTO.getNotes())
					.build();

			when(dossiersCrudService.findById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDTO);
			when(dossiersWorkflowService.getUserAvailableTransitions(PROCESS_ID_1, logged_user1, SCOPE))
					.thenReturn(List.of(transition));
			when(dossierDetailsCrudService.findDossierDetailById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDetailsDTO);

			progressService.progress(TENANT_1, DOSSIER_ID_1, "Tag - 1", logged_user1, SCOPE, progressDossierDTO, ProgressTypeEnum.SYNC);

			verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());
			handleConsumerLambdaCaptor.getValue().useHandle(handle);

			verify(dossierDetailsCrudService, times(1))
					.updateProcessStatusAndFlTransition(TENANT_1, DOSSIER_ID_1, PROCESS_STATUS, USER_1, ProcessTransitionEnum.IN_TRANSITION);
			verify(updateProcessQueue, times(1))
					.executeTransition(queueWorkflowParams, null);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_progress_DossierNotFoundRuntimeException() {
		try {
			ProgressDossierDTO progressDossierDTO = ProgressDossierDTO.builder()
					.notes(NOTES)
					.build();

			when(dossiersCrudService.findById(TENANT_1, DOSSIER_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(DossierNotFoundRuntimeException.class,
					() -> progressService
							.progress(TENANT_1, DOSSIER_ID_1, "Tag - 1", logged_user1, SCOPE, progressDossierDTO, ProgressTypeEnum.ASYNC));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_progress_NoTransitionFoundRuntimeException() {
		try {
			DossierDTO dossierDTO = DossierDTO.builder()
					.moduleId(MODULE_ID_1)
					.dossierId(DOSSIER_ID_1)
					.referredYear(YEAR_1)
					.partyId(PARTY_ID_1)
					.processId(PROCESS_ID_1)
					.build();
			ProgressDossierDTO progressDossierDTO = ProgressDossierDTO.builder()
					.notes(NOTES)
					.build();

			when(dossiersCrudService.findById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDTO);
			when(dossiersWorkflowService.getUserAvailableTransitions(PROCESS_ID_1, logged_user1, SCOPE))
					.thenReturn(List.of());

			assertThrows(NoTransitionFoundRuntimeException.class,
					() -> progressService
							.progress(TENANT_1, DOSSIER_ID_1, "Tag - 1", logged_user1, SCOPE, progressDossierDTO, ProgressTypeEnum.ASYNC));
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_progress_JDBI_DossierNotFoundRuntimeException() {
		try {
			ArgumentCaptor<HandleConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			ProgressDossierDTO progressDossierDTO = ProgressDossierDTO.builder()
					.notes(NOTES)
					.build();

			when(dossiersCrudService.findById(any(), any())).thenReturn(DossierDTO.builder().build());
			when(dossierDetailsCrudService.findDossierDetailById(TENANT_1, DOSSIER_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(DossierNotFoundRuntimeException.class, () -> {
				progressService.progress(TENANT_1, DOSSIER_ID_1, TRANSITION_ID, logged_user1, SCOPE, progressDossierDTO, ProgressTypeEnum.ASYNC);

				verify(jdbi).useTransaction(handleConsumerLambdaCaptor.capture());
				handleConsumerLambdaCaptor.getValue().useHandle(handle);
			});
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void lastTransitionHasError_ok() {
		WorkflowMessage workflowMessage = new WorkflowMessage("Code", "Description", WorkflowMessage.Type.ERROR);
		DetailedTransitionLog detailedTransitionLog = mock(DetailedTransitionLog.class);
		try {
			when(dossiersCrudService.findById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(DossierDTO.builder()
							.processId(PROCESS_ID_1)
							.build());
			when(dossiersWorkflowService.getProcessTransitionHistory(TENANT_1, PROCESS_ID_1, USER))
					.thenReturn(List.of(detailedTransitionLog));
			when(detailedTransitionLog.getMessages())
					.thenReturn(List.of(workflowMessage));

			assertTrue(progressService.lastTransitionHasError(TENANT_1, DOSSIER_ID_1, USER));
		} catch (Exception e) {
			fail(e);
		}
	}
}
