package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.exceptions.DossierNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.model.dto.DossierDetailsDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierDetailsCrudService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class SetClosureDateServiceImplTest {

	private static final Long PK_ID_1 = 1L;
	private static final Long DOSSIER_ID_1 = 30L;
	private static final String PROCESS_STATUS_1 = "status_1";
	private static final String TENANT_1 = "tenant_1";
	private static final String USERNAME = "Username";

	@Mock
	private DossierDetailsCrudService dossierDetailsCrudService;

	@InjectMocks
	private SetClosureDateServiceImpl setClosureDateService;

	@Test
	void test_conditionallySetPresentationDate_ok() {
		try {
			DossierDetailsDTO dossierDetailsDTO = DossierDetailsDTO.builder()
					.pkid(PK_ID_1)
					.dossierId(DOSSIER_ID_1)
					.processStatus(PROCESS_STATUS_1)
					.flInTransition(1)
					.build();

			when(dossierDetailsCrudService.findDossierDetailById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDetailsDTO);

			setClosureDateService.conditionallySetClosureDate(TENANT_1, DOSSIER_ID_1, USERNAME);

			verify(dossierDetailsCrudService, times(1)).update(PK_ID_1, dossierDetailsDTO, USERNAME);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_conditionallySetPresentationDate_presentDtClosed_ok() {
		try {
			DossierDetailsDTO dossierDetailsDTO = DossierDetailsDTO.builder()
					.pkid(PK_ID_1)
					.dossierId(DOSSIER_ID_1)
					.processStatus(PROCESS_STATUS_1)
					.flInTransition(1)
					.dtClosed(LocalDateTime.now())
					.build();

			when(dossierDetailsCrudService.findDossierDetailById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDetailsDTO);

			assertDoesNotThrow(() -> setClosureDateService.conditionallySetClosureDate(TENANT_1, DOSSIER_ID_1, USERNAME));
			verify(dossierDetailsCrudService, times(0)).update(anyLong(), any(), anyString());
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_conditionallySetPresentationDate_ko() {
		try {
			when(dossierDetailsCrudService.findDossierDetailById(TENANT_1, DOSSIER_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(DossierNotFoundRuntimeException.class,
					() -> setClosureDateService.conditionallySetClosureDate(TENANT_1, DOSSIER_ID_1, USERNAME));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_setPresentationDate_ok() {
		try {
			DossierDetailsDTO dossierDetailsDTO = DossierDetailsDTO.builder()
					.pkid(PK_ID_1)
					.dossierId(DOSSIER_ID_1)
					.processStatus(PROCESS_STATUS_1)
					.flInTransition(1)
					.build();

			when(dossierDetailsCrudService.findDossierDetailById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDetailsDTO);

			setClosureDateService.setClosureDate(TENANT_1, DOSSIER_ID_1, USERNAME);

			verify(dossierDetailsCrudService, times(1)).update(PK_ID_1, dossierDetailsDTO, USERNAME);
		} catch (Exception e) {
			fail(e);
		}
	}
}
