package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.exceptions.NoTransitionFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.model.ProgressTypeEnum;
import com.abacogroup.agri.dossiers.core.model.dto.publics.ProgressDossierDTO;
import com.abacogroup.agri.dossiers.core.services.ProgressService;
import com.abacogroup.agri.dossiers.core.services.crud.DossierDetailsCrudService;
import com.abacogroup.applicationworkflowsdk.model.exception.AmendException;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.testsupport.ProcessDataTestSupport;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DossierAmendImplTest {
    @Mock
    private ProgressService progressService;
    @Mock
    private DossierDetailsCrudService dossierDetailsCrudService;

    @InjectMocks
    private DossierAmendImpl dossierAmend;

    private static final String TENANT = "ADMIN";
    private static final Long DOSSIER_ID = 5L;
    private static final String USERNAME = "Username";
    private static final User USER = new User(USERNAME, TENANT);
    private static final String TAG_NAME = "Tag Name";
    private static final String SCOPE = "Scope";

    @Test
    void amendDossier_ok() {
        try {
            ProcessData processData = new ProcessDataTestSupport();

            when(progressService.lastTransitionHasError(TENANT, DOSSIER_ID, USER))
                    .thenReturn(false);

            dossierAmend.amendApplication(TENANT, DOSSIER_ID, USER, TAG_NAME, SCOPE, processData);

            verify(progressService, times(1))
                    .progress(TENANT, DOSSIER_ID, TAG_NAME, USER, SCOPE, ProgressDossierDTO.builder().build(), ProgressTypeEnum.SYNC, processData);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void amendDossier_transitionError_ko() {
        try {
            when(progressService.lastTransitionHasError(TENANT, DOSSIER_ID, USER))
                    .thenReturn(true);

            assertThrows(AmendException.class, () ->
                    dossierAmend.amendApplication(TENANT, DOSSIER_ID, USER, TAG_NAME, SCOPE, new ProcessDataTestSupport()));
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void amendDossier_ko() {
        try {
            doThrow(NoTransitionFoundRuntimeException.class).when(progressService)
                    .progress(TENANT, DOSSIER_ID, TAG_NAME, USER, SCOPE, new ProgressDossierDTO(), ProgressTypeEnum.SYNC);

            assertThrows(AmendException.class, () ->
                    dossierAmend.amendApplication(TENANT, DOSSIER_ID, USER, TAG_NAME, SCOPE, new ProcessDataTestSupport()));
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void cancelAmendedById_ok() {
        try {
            dossierAmend.cancelAmendedById(TENANT, DOSSIER_ID, USER);

            verify(dossierDetailsCrudService, times(1)).cancelAmendedBy(TENANT, DOSSIER_ID, USERNAME);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void cancelAmendedById_ko() {
        try {
            doThrow(ObjectNotFoundException.class).when(dossierDetailsCrudService)
                    .cancelAmendedBy(TENANT, DOSSIER_ID, USERNAME);

            assertThrows(ObjectNotFoundRuntimeException.class, () ->
                    dossierAmend.cancelAmendedById(TENANT, DOSSIER_ID, USER));
        } catch (Exception e) {
            fail(e);
        }
    }
}